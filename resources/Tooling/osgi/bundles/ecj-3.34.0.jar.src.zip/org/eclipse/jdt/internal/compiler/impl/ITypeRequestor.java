/*    */ package org.eclipse.jdt.internal.compiler.impl;
/*    */ 
/*    */ import org.eclipse.jdt.internal.compiler.env.AccessRestriction;
/*    */ import org.eclipse.jdt.internal.compiler.env.IBinaryType;
/*    */ import org.eclipse.jdt.internal.compiler.env.ICompilationUnit;
/*    */ import org.eclipse.jdt.internal.compiler.env.IModule;
/*    */ import org.eclipse.jdt.internal.compiler.env.ISourceModule;
/*    */ import org.eclipse.jdt.internal.compiler.env.ISourceType;
/*    */ import org.eclipse.jdt.internal.compiler.lookup.BinaryModuleBinding;
/*    */ import org.eclipse.jdt.internal.compiler.lookup.LookupEnvironment;
/*    */ import org.eclipse.jdt.internal.compiler.lookup.PackageBinding;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface ITypeRequestor
/*    */ {
/*    */   void accept(IBinaryType paramIBinaryType, PackageBinding paramPackageBinding, AccessRestriction paramAccessRestriction);
/*    */   
/*    */   void accept(ICompilationUnit paramICompilationUnit, AccessRestriction paramAccessRestriction);
/*    */   
/*    */   void accept(ISourceType[] paramArrayOfISourceType, PackageBinding paramPackageBinding, AccessRestriction paramAccessRestriction);
/*    */   
/*    */   default void accept(IModule module, LookupEnvironment environment) {
/* 58 */     if (module instanceof ISourceModule) {
/* 59 */       ICompilationUnit compilationUnit = ((ISourceModule)module).getCompilationUnit();
/* 60 */       if (compilationUnit != null) {
/* 61 */         accept(compilationUnit, (AccessRestriction)null);
/*    */       }
/*    */     } else {
/*    */       
/* 65 */       BinaryModuleBinding.create(module, environment);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\impl\ITypeRequestor.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */