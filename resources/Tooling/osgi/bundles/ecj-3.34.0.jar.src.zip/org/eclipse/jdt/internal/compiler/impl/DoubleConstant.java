/*    */ package org.eclipse.jdt.internal.compiler.impl;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DoubleConstant
/*    */   extends Constant
/*    */ {
/*    */   private double value;
/*    */   
/*    */   public static Constant fromValue(double value) {
/* 21 */     return new DoubleConstant(value);
/*    */   }
/*    */   
/*    */   private DoubleConstant(double value) {
/* 25 */     this.value = value;
/*    */   }
/*    */ 
/*    */   
/*    */   public byte byteValue() {
/* 30 */     return (byte)(int)this.value;
/*    */   }
/*    */ 
/*    */   
/*    */   public char charValue() {
/* 35 */     return (char)(int)this.value;
/*    */   }
/*    */ 
/*    */   
/*    */   public double doubleValue() {
/* 40 */     return this.value;
/*    */   }
/*    */ 
/*    */   
/*    */   public float floatValue() {
/* 45 */     return (float)this.value;
/*    */   }
/*    */ 
/*    */   
/*    */   public int intValue() {
/* 50 */     return (int)this.value;
/*    */   }
/*    */ 
/*    */   
/*    */   public long longValue() {
/* 55 */     return (long)this.value;
/*    */   }
/*    */ 
/*    */   
/*    */   public short shortValue() {
/* 60 */     return (short)(int)this.value;
/*    */   }
/*    */ 
/*    */   
/*    */   public String stringValue() {
/* 65 */     return String.valueOf(this.value);
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 70 */     if (this == NotAConstant)
/* 71 */       return "(Constant) NotAConstant"; 
/* 72 */     return "(double)" + this.value;
/*    */   }
/*    */ 
/*    */   
/*    */   public int typeID() {
/* 77 */     return 8;
/*    */   }
/*    */ 
/*    */   
/*    */   public int hashCode() {
/* 82 */     long temp = Double.doubleToLongBits(this.value);
/* 83 */     return (int)(temp ^ temp >>> 32L);
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean equals(Object obj) {
/* 88 */     if (this == obj) {
/* 89 */       return true;
/*    */     }
/* 91 */     if (obj == null) {
/* 92 */       return false;
/*    */     }
/* 94 */     if (getClass() != obj.getClass()) {
/* 95 */       return false;
/*    */     }
/* 97 */     DoubleConstant other = (DoubleConstant)obj;
/* 98 */     return (Double.doubleToLongBits(this.value) == Double.doubleToLongBits(other.value));
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\impl\DoubleConstant.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */