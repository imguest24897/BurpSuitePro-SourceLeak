/*    */ package org.eclipse.jdt.internal.compiler.classfmt;
/*    */ 
/*    */ import org.eclipse.jdt.internal.compiler.env.IBinaryTypeAnnotation;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class AnnotationMethodInfoWithTypeAnnotations
/*    */   extends AnnotationMethodInfoWithAnnotations
/*    */ {
/*    */   private TypeAnnotationInfo[] typeAnnotations;
/*    */   
/*    */   AnnotationMethodInfoWithTypeAnnotations(MethodInfo methodInfo, Object defaultValue, AnnotationInfo[] annotations, TypeAnnotationInfo[] typeAnnotations) {
/* 22 */     super(methodInfo, defaultValue, annotations);
/* 23 */     this.typeAnnotations = typeAnnotations;
/*    */   }
/*    */   
/*    */   public IBinaryTypeAnnotation[] getTypeAnnotations() {
/* 27 */     return (IBinaryTypeAnnotation[])this.typeAnnotations;
/*    */   }
/*    */ 
/*    */   
/*    */   protected void initialize() {
/* 32 */     for (int i = 0, l = (this.typeAnnotations == null) ? 0 : this.typeAnnotations.length; i < l; i++) {
/* 33 */       this.typeAnnotations[i].initialize();
/*    */     }
/* 35 */     super.initialize();
/*    */   }
/*    */   
/*    */   protected void reset() {
/* 39 */     for (int i = 0, l = (this.typeAnnotations == null) ? 0 : this.typeAnnotations.length; i < l; i++) {
/* 40 */       this.typeAnnotations[i].reset();
/*    */     }
/* 42 */     super.reset();
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\classfmt\AnnotationMethodInfoWithTypeAnnotations.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */