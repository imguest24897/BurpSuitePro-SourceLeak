/*    */ package org.eclipse.jdt.internal.compiler.ast;
/*    */ 
/*    */ import org.eclipse.jdt.internal.compiler.impl.LongConstant;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class LongLiteralMinValue
/*    */   extends LongLiteral
/*    */ {
/* 20 */   static final char[] CharValue = new char[] { '-', '9', '2', '2', '3', '3', '7', '2', '0', '3', '6', '8', '5', '4', '7', '7', '5', '8', '0', '8', 'L' };
/*    */   
/*    */   public LongLiteralMinValue(char[] token, char[] reducedForm, int start, int end) {
/* 23 */     super(token, reducedForm, start, end);
/* 24 */     this.constant = LongConstant.fromValue(Long.MIN_VALUE);
/*    */   }
/*    */   
/*    */   public void computeConstant() {}
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\ast\LongLiteralMinValue.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */