/*      */ package org.eclipse.jdt.internal.compiler.impl;
/*      */ 
/*      */ import java.io.UnsupportedEncodingException;
/*      */ import java.util.HashMap;
/*      */ import java.util.Map;
/*      */ import org.eclipse.jdt.core.compiler.CharOperation;
/*      */ import org.eclipse.jdt.internal.compiler.Compiler;
/*      */ import org.eclipse.jdt.internal.compiler.util.Util;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class CompilerOptions
/*      */ {
/*      */   public static final String OPTION_LocalVariableAttribute = "org.eclipse.jdt.core.compiler.debug.localVariable";
/*      */   public static final String OPTION_LineNumberAttribute = "org.eclipse.jdt.core.compiler.debug.lineNumber";
/*      */   public static final String OPTION_SourceFileAttribute = "org.eclipse.jdt.core.compiler.debug.sourceFile";
/*      */   public static final String OPTION_PreserveUnusedLocal = "org.eclipse.jdt.core.compiler.codegen.unusedLocal";
/*      */   public static final String OPTION_MethodParametersAttribute = "org.eclipse.jdt.core.compiler.codegen.methodParameters";
/*      */   public static final String OPTION_LambdaGenericSignature = "org.eclipse.jdt.core.compiler.codegen.lambda.genericSignature";
/*      */   public static final String OPTION_DocCommentSupport = "org.eclipse.jdt.core.compiler.doc.comment.support";
/*      */   public static final String OPTION_ReportMethodWithConstructorName = "org.eclipse.jdt.core.compiler.problem.methodWithConstructorName";
/*      */   public static final String OPTION_ReportOverridingPackageDefaultMethod = "org.eclipse.jdt.core.compiler.problem.overridingPackageDefaultMethod";
/*      */   public static final String OPTION_ReportDeprecation = "org.eclipse.jdt.core.compiler.problem.deprecation";
/*      */   public static final String OPTION_ReportTerminalDeprecation = "org.eclipse.jdt.core.compiler.problem.terminalDeprecation";
/*      */   public static final String OPTION_ReportDeprecationInDeprecatedCode = "org.eclipse.jdt.core.compiler.problem.deprecationInDeprecatedCode";
/*      */   public static final String OPTION_ReportDeprecationWhenOverridingDeprecatedMethod = "org.eclipse.jdt.core.compiler.problem.deprecationWhenOverridingDeprecatedMethod";
/*      */   public static final String OPTION_ReportHiddenCatchBlock = "org.eclipse.jdt.core.compiler.problem.hiddenCatchBlock";
/*      */   public static final String OPTION_ReportUnusedLocal = "org.eclipse.jdt.core.compiler.problem.unusedLocal";
/*      */   public static final String OPTION_ReportUnusedParameter = "org.eclipse.jdt.core.compiler.problem.unusedParameter";
/*      */   public static final String OPTION_ReportUnusedExceptionParameter = "org.eclipse.jdt.core.compiler.problem.unusedExceptionParameter";
/*      */   public static final String OPTION_ReportUnusedParameterWhenImplementingAbstract = "org.eclipse.jdt.core.compiler.problem.unusedParameterWhenImplementingAbstract";
/*      */   public static final String OPTION_ReportUnusedParameterWhenOverridingConcrete = "org.eclipse.jdt.core.compiler.problem.unusedParameterWhenOverridingConcrete";
/*      */   public static final String OPTION_ReportUnusedParameterIncludeDocCommentReference = "org.eclipse.jdt.core.compiler.problem.unusedParameterIncludeDocCommentReference";
/*      */   public static final String OPTION_ReportUnusedImport = "org.eclipse.jdt.core.compiler.problem.unusedImport";
/*      */   public static final String OPTION_ReportSyntheticAccessEmulation = "org.eclipse.jdt.core.compiler.problem.syntheticAccessEmulation";
/*      */   public static final String OPTION_ReportNoEffectAssignment = "org.eclipse.jdt.core.compiler.problem.noEffectAssignment";
/*      */   public static final String OPTION_ReportLocalVariableHiding = "org.eclipse.jdt.core.compiler.problem.localVariableHiding";
/*      */   public static final String OPTION_ReportSpecialParameterHidingField = "org.eclipse.jdt.core.compiler.problem.specialParameterHidingField";
/*      */   public static final String OPTION_ReportFieldHiding = "org.eclipse.jdt.core.compiler.problem.fieldHiding";
/*      */   public static final String OPTION_ReportTypeParameterHiding = "org.eclipse.jdt.core.compiler.problem.typeParameterHiding";
/*      */   public static final String OPTION_ReportPossibleAccidentalBooleanAssignment = "org.eclipse.jdt.core.compiler.problem.possibleAccidentalBooleanAssignment";
/*      */   public static final String OPTION_ReportNonExternalizedStringLiteral = "org.eclipse.jdt.core.compiler.problem.nonExternalizedStringLiteral";
/*      */   public static final String OPTION_ReportIncompatibleNonInheritedInterfaceMethod = "org.eclipse.jdt.core.compiler.problem.incompatibleNonInheritedInterfaceMethod";
/*      */   public static final String OPTION_ReportUnusedPrivateMember = "org.eclipse.jdt.core.compiler.problem.unusedPrivateMember";
/*      */   public static final String OPTION_ReportNoImplicitStringConversion = "org.eclipse.jdt.core.compiler.problem.noImplicitStringConversion";
/*      */   public static final String OPTION_ReportAssertIdentifier = "org.eclipse.jdt.core.compiler.problem.assertIdentifier";
/*      */   public static final String OPTION_ReportEnumIdentifier = "org.eclipse.jdt.core.compiler.problem.enumIdentifier";
/*      */   public static final String OPTION_ReportNonStaticAccessToStatic = "org.eclipse.jdt.core.compiler.problem.staticAccessReceiver";
/*      */   public static final String OPTION_ReportIndirectStaticAccess = "org.eclipse.jdt.core.compiler.problem.indirectStaticAccess";
/*      */   public static final String OPTION_ReportEmptyStatement = "org.eclipse.jdt.core.compiler.problem.emptyStatement";
/*      */   public static final String OPTION_ReportUnnecessaryTypeCheck = "org.eclipse.jdt.core.compiler.problem.unnecessaryTypeCheck";
/*      */   public static final String OPTION_ReportUnnecessaryElse = "org.eclipse.jdt.core.compiler.problem.unnecessaryElse";
/*      */   public static final String OPTION_ReportUndocumentedEmptyBlock = "org.eclipse.jdt.core.compiler.problem.undocumentedEmptyBlock";
/*      */   public static final String OPTION_ReportInvalidJavadoc = "org.eclipse.jdt.core.compiler.problem.invalidJavadoc";
/*      */   public static final String OPTION_ReportInvalidJavadocTags = "org.eclipse.jdt.core.compiler.problem.invalidJavadocTags";
/*      */   public static final String OPTION_ReportInvalidJavadocTagsDeprecatedRef = "org.eclipse.jdt.core.compiler.problem.invalidJavadocTagsDeprecatedRef";
/*      */   public static final String OPTION_ReportInvalidJavadocTagsNotVisibleRef = "org.eclipse.jdt.core.compiler.problem.invalidJavadocTagsNotVisibleRef";
/*      */   public static final String OPTION_ReportInvalidJavadocTagsVisibility = "org.eclipse.jdt.core.compiler.problem.invalidJavadocTagsVisibility";
/*      */   public static final String OPTION_ReportMissingJavadocTags = "org.eclipse.jdt.core.compiler.problem.missingJavadocTags";
/*      */   public static final String OPTION_ReportMissingJavadocTagsVisibility = "org.eclipse.jdt.core.compiler.problem.missingJavadocTagsVisibility";
/*      */   public static final String OPTION_ReportMissingJavadocTagsOverriding = "org.eclipse.jdt.core.compiler.problem.missingJavadocTagsOverriding";
/*      */   public static final String OPTION_ReportMissingJavadocTagsMethodTypeParameters = "org.eclipse.jdt.core.compiler.problem.missingJavadocTagsMethodTypeParameters";
/*      */   public static final String OPTION_ReportMissingJavadocComments = "org.eclipse.jdt.core.compiler.problem.missingJavadocComments";
/*      */   public static final String OPTION_ReportMissingJavadocTagDescription = "org.eclipse.jdt.core.compiler.problem.missingJavadocTagDescription";
/*      */   public static final String OPTION_ReportMissingJavadocCommentsVisibility = "org.eclipse.jdt.core.compiler.problem.missingJavadocCommentsVisibility";
/*      */   public static final String OPTION_ReportMissingJavadocCommentsOverriding = "org.eclipse.jdt.core.compiler.problem.missingJavadocCommentsOverriding";
/*      */   public static final String OPTION_ReportFinallyBlockNotCompletingNormally = "org.eclipse.jdt.core.compiler.problem.finallyBlockNotCompletingNormally";
/*      */   public static final String OPTION_ReportUnusedDeclaredThrownException = "org.eclipse.jdt.core.compiler.problem.unusedDeclaredThrownException";
/*      */   public static final String OPTION_ReportUnusedDeclaredThrownExceptionWhenOverriding = "org.eclipse.jdt.core.compiler.problem.unusedDeclaredThrownExceptionWhenOverriding";
/*      */   public static final String OPTION_ReportUnusedDeclaredThrownExceptionIncludeDocCommentReference = "org.eclipse.jdt.core.compiler.problem.unusedDeclaredThrownExceptionIncludeDocCommentReference";
/*      */   public static final String OPTION_ReportUnusedDeclaredThrownExceptionExemptExceptionAndThrowable = "org.eclipse.jdt.core.compiler.problem.unusedDeclaredThrownExceptionExemptExceptionAndThrowable";
/*      */   public static final String OPTION_ReportUnqualifiedFieldAccess = "org.eclipse.jdt.core.compiler.problem.unqualifiedFieldAccess";
/*      */   public static final String OPTION_ReportUnavoidableGenericTypeProblems = "org.eclipse.jdt.core.compiler.problem.unavoidableGenericTypeProblems";
/*      */   public static final String OPTION_ReportUncheckedTypeOperation = "org.eclipse.jdt.core.compiler.problem.uncheckedTypeOperation";
/*      */   public static final String OPTION_ReportRawTypeReference = "org.eclipse.jdt.core.compiler.problem.rawTypeReference";
/*      */   public static final String OPTION_ReportFinalParameterBound = "org.eclipse.jdt.core.compiler.problem.finalParameterBound";
/*      */   public static final String OPTION_ReportMissingSerialVersion = "org.eclipse.jdt.core.compiler.problem.missingSerialVersion";
/*      */   public static final String OPTION_ReportVarargsArgumentNeedCast = "org.eclipse.jdt.core.compiler.problem.varargsArgumentNeedCast";
/*      */   public static final String OPTION_ReportUnusedTypeArgumentsForMethodInvocation = "org.eclipse.jdt.core.compiler.problem.unusedTypeArgumentsForMethodInvocation";
/*      */   public static final String OPTION_Source = "org.eclipse.jdt.core.compiler.source";
/*      */   public static final String OPTION_TargetPlatform = "org.eclipse.jdt.core.compiler.codegen.targetPlatform";
/*      */   public static final String OPTION_Compliance = "org.eclipse.jdt.core.compiler.compliance";
/*      */   public static final String OPTION_Release = "org.eclipse.jdt.core.compiler.release";
/*      */   public static final String OPTION_Encoding = "org.eclipse.jdt.core.encoding";
/*      */   public static final String OPTION_MaxProblemPerUnit = "org.eclipse.jdt.core.compiler.maxProblemPerUnit";
/*      */   public static final String OPTION_TaskTags = "org.eclipse.jdt.core.compiler.taskTags";
/*      */   public static final String OPTION_TaskPriorities = "org.eclipse.jdt.core.compiler.taskPriorities";
/*      */   public static final String OPTION_TaskCaseSensitive = "org.eclipse.jdt.core.compiler.taskCaseSensitive";
/*      */   public static final String OPTION_InlineJsr = "org.eclipse.jdt.core.compiler.codegen.inlineJsrBytecode";
/*      */   public static final String OPTION_ShareCommonFinallyBlocks = "org.eclipse.jdt.core.compiler.codegen.shareCommonFinallyBlocks";
/*      */   public static final String OPTION_ReportNullReference = "org.eclipse.jdt.core.compiler.problem.nullReference";
/*      */   public static final String OPTION_ReportPotentialNullReference = "org.eclipse.jdt.core.compiler.problem.potentialNullReference";
/*      */   public static final String OPTION_ReportRedundantNullCheck = "org.eclipse.jdt.core.compiler.problem.redundantNullCheck";
/*      */   public static final String OPTION_ReportAutoboxing = "org.eclipse.jdt.core.compiler.problem.autoboxing";
/*      */   public static final String OPTION_ReportAnnotationSuperInterface = "org.eclipse.jdt.core.compiler.problem.annotationSuperInterface";
/*      */   public static final String OPTION_ReportMissingOverrideAnnotation = "org.eclipse.jdt.core.compiler.problem.missingOverrideAnnotation";
/*      */   public static final String OPTION_ReportMissingOverrideAnnotationForInterfaceMethodImplementation = "org.eclipse.jdt.core.compiler.problem.missingOverrideAnnotationForInterfaceMethodImplementation";
/*      */   public static final String OPTION_ReportMissingDeprecatedAnnotation = "org.eclipse.jdt.core.compiler.problem.missingDeprecatedAnnotation";
/*      */   public static final String OPTION_ReportIncompleteEnumSwitch = "org.eclipse.jdt.core.compiler.problem.incompleteEnumSwitch";
/*      */   public static final String OPTION_ReportMissingEnumCaseDespiteDefault = "org.eclipse.jdt.core.compiler.problem.missingEnumCaseDespiteDefault";
/*      */   public static final String OPTION_ReportMissingDefaultCase = "org.eclipse.jdt.core.compiler.problem.missingDefaultCase";
/*      */   public static final String OPTION_ReportForbiddenReference = "org.eclipse.jdt.core.compiler.problem.forbiddenReference";
/*      */   public static final String OPTION_ReportDiscouragedReference = "org.eclipse.jdt.core.compiler.problem.discouragedReference";
/*      */   public static final String OPTION_SuppressWarnings = "org.eclipse.jdt.core.compiler.problem.suppressWarnings";
/*      */   public static final String OPTION_SuppressOptionalErrors = "org.eclipse.jdt.core.compiler.problem.suppressOptionalErrors";
/*      */   public static final String OPTION_ReportUnhandledWarningToken = "org.eclipse.jdt.core.compiler.problem.unhandledWarningToken";
/*      */   public static final String OPTION_ReportUnusedTypeParameter = "org.eclipse.jdt.core.compiler.problem.unusedTypeParameter";
/*      */   public static final String OPTION_ReportUnusedWarningToken = "org.eclipse.jdt.core.compiler.problem.unusedWarningToken";
/*      */   public static final String OPTION_ReportUnusedLabel = "org.eclipse.jdt.core.compiler.problem.unusedLabel";
/*      */   public static final String OPTION_FatalOptionalError = "org.eclipse.jdt.core.compiler.problem.fatalOptionalError";
/*      */   public static final String OPTION_ReportParameterAssignment = "org.eclipse.jdt.core.compiler.problem.parameterAssignment";
/*      */   public static final String OPTION_ReportFallthroughCase = "org.eclipse.jdt.core.compiler.problem.fallthroughCase";
/*      */   public static final String OPTION_ReportOverridingMethodWithoutSuperInvocation = "org.eclipse.jdt.core.compiler.problem.overridingMethodWithoutSuperInvocation";
/*      */   public static final String OPTION_GenerateClassFiles = "org.eclipse.jdt.core.compiler.generateClassFiles";
/*      */   public static final String OPTION_Process_Annotations = "org.eclipse.jdt.core.compiler.processAnnotations";
/*      */   public static final String OPTION_Store_Annotations = "org.eclipse.jdt.core.compiler.storeAnnotations";
/*      */   public static final String OPTION_EmulateJavacBug8031744 = "org.eclipse.jdt.core.compiler.emulateJavacBug8031744";
/*      */   public static final String OPTION_ReportRedundantSuperinterface = "org.eclipse.jdt.core.compiler.problem.redundantSuperinterface";
/*      */   public static final String OPTION_ReportComparingIdentical = "org.eclipse.jdt.core.compiler.problem.comparingIdentical";
/*      */   public static final String OPTION_ReportMissingSynchronizedOnInheritedMethod = "org.eclipse.jdt.core.compiler.problem.missingSynchronizedOnInheritedMethod";
/*      */   public static final String OPTION_ReportMissingHashCodeMethod = "org.eclipse.jdt.core.compiler.problem.missingHashCodeMethod";
/*      */   public static final String OPTION_ReportDeadCode = "org.eclipse.jdt.core.compiler.problem.deadCode";
/*      */   public static final String OPTION_ReportDeadCodeInTrivialIfStatement = "org.eclipse.jdt.core.compiler.problem.deadCodeInTrivialIfStatement";
/*      */   public static final String OPTION_ReportTasks = "org.eclipse.jdt.core.compiler.problem.tasks";
/*      */   public static final String OPTION_ReportUnusedObjectAllocation = "org.eclipse.jdt.core.compiler.problem.unusedObjectAllocation";
/*      */   public static final String OPTION_IncludeNullInfoFromAsserts = "org.eclipse.jdt.core.compiler.problem.includeNullInfoFromAsserts";
/*      */   public static final String OPTION_ReportMethodCanBeStatic = "org.eclipse.jdt.core.compiler.problem.reportMethodCanBeStatic";
/*      */   public static final String OPTION_ReportMethodCanBePotentiallyStatic = "org.eclipse.jdt.core.compiler.problem.reportMethodCanBePotentiallyStatic";
/*      */   public static final String OPTION_ReportRedundantSpecificationOfTypeArguments = "org.eclipse.jdt.core.compiler.problem.redundantSpecificationOfTypeArguments";
/*      */   public static final String OPTION_ReportUnclosedCloseable = "org.eclipse.jdt.core.compiler.problem.unclosedCloseable";
/*      */   public static final String OPTION_ReportPotentiallyUnclosedCloseable = "org.eclipse.jdt.core.compiler.problem.potentiallyUnclosedCloseable";
/*      */   public static final String OPTION_ReportExplicitlyClosedAutoCloseable = "org.eclipse.jdt.core.compiler.problem.explicitlyClosedAutoCloseable";
/*      */   public static final String OPTION_ReportNullSpecViolation = "org.eclipse.jdt.core.compiler.problem.nullSpecViolation";
/*      */   public static final String OPTION_ReportNullAnnotationInferenceConflict = "org.eclipse.jdt.core.compiler.problem.nullAnnotationInferenceConflict";
/*      */   public static final String OPTION_ReportNullUncheckedConversion = "org.eclipse.jdt.core.compiler.problem.nullUncheckedConversion";
/*      */   public static final String OPTION_ReportRedundantNullAnnotation = "org.eclipse.jdt.core.compiler.problem.redundantNullAnnotation";
/*      */   public static final String OPTION_AnnotationBasedNullAnalysis = "org.eclipse.jdt.core.compiler.annotation.nullanalysis";
/*      */   public static final String OPTION_NullableAnnotationName = "org.eclipse.jdt.core.compiler.annotation.nullable";
/*      */   public static final String OPTION_NonNullAnnotationName = "org.eclipse.jdt.core.compiler.annotation.nonnull";
/*      */   public static final String OPTION_NonNullByDefaultAnnotationName = "org.eclipse.jdt.core.compiler.annotation.nonnullbydefault";
/*      */   public static final String OPTION_NullableAnnotationSecondaryNames = "org.eclipse.jdt.core.compiler.annotation.nullable.secondary";
/*      */   public static final String OPTION_NonNullAnnotationSecondaryNames = "org.eclipse.jdt.core.compiler.annotation.nonnull.secondary";
/*      */   public static final String OPTION_NonNullByDefaultAnnotationSecondaryNames = "org.eclipse.jdt.core.compiler.annotation.nonnullbydefault.secondary";
/*      */   public static final String OPTION_ReportUninternedIdentityComparison = "org.eclipse.jdt.core.compiler.problem.uninternedIdentityComparison";
/*  188 */   static final char[][] DEFAULT_NULLABLE_ANNOTATION_NAME = CharOperation.splitOn('.', "org.eclipse.jdt.annotation.Nullable".toCharArray());
/*  189 */   static final char[][] DEFAULT_NONNULL_ANNOTATION_NAME = CharOperation.splitOn('.', "org.eclipse.jdt.annotation.NonNull".toCharArray());
/*  190 */   static final char[][] DEFAULT_NONNULLBYDEFAULT_ANNOTATION_NAME = CharOperation.splitOn('.', "org.eclipse.jdt.annotation.NonNullByDefault".toCharArray());
/*      */   
/*      */   public static final String OPTION_ReportMissingNonNullByDefaultAnnotation = "org.eclipse.jdt.core.compiler.annotation.missingNonNullByDefaultAnnotation";
/*      */   
/*      */   public static final String OPTION_SyntacticNullAnalysisForFields = "org.eclipse.jdt.core.compiler.problem.syntacticNullAnalysisForFields";
/*      */   
/*      */   public static final String OPTION_InheritNullAnnotations = "org.eclipse.jdt.core.compiler.annotation.inheritNullAnnotations";
/*      */   
/*      */   public static final String OPTION_ReportNonnullParameterAnnotationDropped = "org.eclipse.jdt.core.compiler.problem.nonnullParameterAnnotationDropped";
/*      */   
/*      */   public static final String OPTION_PessimisticNullAnalysisForFreeTypeVariables = "org.eclipse.jdt.core.compiler.problem.pessimisticNullAnalysisForFreeTypeVariables";
/*      */   
/*      */   public static final String OPTION_ReportNonNullTypeVariableFromLegacyInvocation = "org.eclipse.jdt.core.compiler.problem.nonnullTypeVariableFromLegacyInvocation";
/*      */   
/*      */   public static final String OPTION_ReportAnnotatedTypeArgumentToUnannotated = "org.eclipse.jdt.core.compiler.problem.annotatedTypeArgumentToUnannotated";
/*      */   
/*      */   public static final String OPTION_ReportUnlikelyCollectionMethodArgumentType = "org.eclipse.jdt.core.compiler.problem.unlikelyCollectionMethodArgumentType";
/*      */   
/*      */   public static final String OPTION_ReportUnlikelyCollectionMethodArgumentTypeStrict = "org.eclipse.jdt.core.compiler.problem.unlikelyCollectionMethodArgumentTypeStrict";
/*      */   
/*      */   public static final String OPTION_ReportUnlikelyEqualsArgumentType = "org.eclipse.jdt.core.compiler.problem.unlikelyEqualsArgumentType";
/*      */   
/*      */   public static final String OPTION_ReportAPILeak = "org.eclipse.jdt.core.compiler.problem.APILeak";
/*      */   
/*      */   public static final String OPTION_ReportUnstableAutoModuleName = "org.eclipse.jdt.core.compiler.problem.unstableAutoModuleName";
/*      */   
/*      */   public static final String OPTION_EnablePreviews = "org.eclipse.jdt.core.compiler.problem.enablePreviewFeatures";
/*      */   
/*      */   public static final String OPTION_ReportPreviewFeatures = "org.eclipse.jdt.core.compiler.problem.reportPreviewFeatures";
/*      */   
/*      */   public static final String OPTION_ReportSuppressWarningNotFullyAnalysed = "org.eclipse.jdt.core.compiler.problem.suppressWarningsNotFullyAnalysed";
/*      */   
/*      */   public static final String OPTION_JdtDebugCompileMode = "org.eclipse.jdt.internal.debug.compile.mode";
/*      */   public static final String OPTION_IgnoreUnnamedModuleForSplitPackage = "org.eclipse.jdt.core.compiler.ignoreUnnamedModuleForSplitPackage";
/*      */   public static final String GENERATE = "generate";
/*      */   public static final String DO_NOT_GENERATE = "do not generate";
/*      */   public static final String PRESERVE = "preserve";
/*      */   public static final String OPTIMIZE_OUT = "optimize out";
/*      */   public static final String VERSION_1_1 = "1.1";
/*      */   public static final String VERSION_1_2 = "1.2";
/*      */   public static final String VERSION_1_3 = "1.3";
/*      */   public static final String VERSION_1_4 = "1.4";
/*      */   public static final String VERSION_JSR14 = "jsr14";
/*      */   public static final String VERSION_CLDC1_1 = "cldc1.1";
/*      */   public static final String VERSION_1_5 = "1.5";
/*      */   public static final String VERSION_1_6 = "1.6";
/*      */   public static final String VERSION_1_7 = "1.7";
/*      */   public static final String VERSION_1_8 = "1.8";
/*      */   public static final String VERSION_9 = "9";
/*      */   public static final String VERSION_10 = "10";
/*      */   public static final String VERSION_11 = "11";
/*      */   public static final String VERSION_12 = "12";
/*      */   public static final String VERSION_13 = "13";
/*      */   public static final String VERSION_14 = "14";
/*      */   public static final String VERSION_15 = "15";
/*      */   public static final String VERSION_16 = "16";
/*      */   public static final String VERSION_17 = "17";
/*      */   public static final String VERSION_18 = "18";
/*      */   public static final String VERSION_19 = "19";
/*      */   public static final String VERSION_20 = "20";
/*      */   public static final String ERROR = "error";
/*      */   public static final String WARNING = "warning";
/*      */   public static final String INFO = "info";
/*      */   public static final String IGNORE = "ignore";
/*      */   public static final String ENABLED = "enabled";
/*      */   public static final String DISABLED = "disabled";
/*      */   public static final String PUBLIC = "public";
/*      */   public static final String PROTECTED = "protected";
/*      */   public static final String DEFAULT = "default";
/*      */   public static final String PRIVATE = "private";
/*      */   public static final String RETURN_TAG = "return_tag";
/*      */   public static final String NO_TAG = "no_tag";
/*      */   public static final String ALL_STANDARD_TAGS = "all_standard_tags";
/*  263 */   private static final String[] NO_STRINGS = new String[0];
/*      */   
/*      */   public static final int MethodWithConstructorName = 1;
/*      */   
/*      */   public static final int OverriddenPackageDefaultMethod = 2;
/*      */   
/*      */   public static final int UsingDeprecatedAPI = 4;
/*      */   
/*      */   public static final int MaskedCatchBlock = 8;
/*      */   
/*      */   public static final int UnusedLocalVariable = 16;
/*      */   
/*      */   public static final int UnusedArgument = 32;
/*      */   
/*      */   public static final int NoImplicitStringConversion = 64;
/*      */   
/*      */   public static final int AccessEmulation = 128;
/*      */   
/*      */   public static final int NonExternalizedString = 256;
/*      */   
/*      */   public static final int AssertUsedAsAnIdentifier = 512;
/*      */   
/*      */   public static final int UnusedImport = 1024;
/*      */   
/*      */   public static final int NonStaticAccessToStatic = 2048;
/*      */   
/*      */   public static final int Task = 4096;
/*      */   
/*      */   public static final int NoEffectAssignment = 8192;
/*      */   
/*      */   public static final int IncompatibleNonInheritedInterfaceMethod = 16384;
/*      */   
/*      */   public static final int UnusedPrivateMember = 32768;
/*      */   
/*      */   public static final int LocalVariableHiding = 65536;
/*      */   
/*      */   public static final int FieldHiding = 131072;
/*      */   
/*      */   public static final int AccidentalBooleanAssign = 262144;
/*      */   
/*      */   public static final int EmptyStatement = 524288;
/*      */   
/*      */   public static final int MissingJavadocComments = 1048576;
/*      */   
/*      */   public static final int MissingJavadocTags = 2097152;
/*      */   
/*      */   public static final int UnqualifiedFieldAccess = 4194304;
/*      */   
/*      */   public static final int UnusedDeclaredThrownException = 8388608;
/*      */   
/*      */   public static final int FinallyBlockNotCompleting = 16777216;
/*      */   
/*      */   public static final int InvalidJavadoc = 33554432;
/*      */   
/*      */   public static final int UnnecessaryTypeCheck = 67108864;
/*      */   
/*      */   public static final int UndocumentedEmptyBlock = 134217728;
/*      */   
/*      */   public static final int IndirectStaticAccess = 268435456;
/*      */   
/*      */   public static final int UnnecessaryElse = 536870913;
/*      */   
/*      */   public static final int UncheckedTypeOperation = 536870914;
/*      */   
/*      */   public static final int FinalParameterBound = 536870916;
/*      */   
/*      */   public static final int MissingSerialVersion = 536870920;
/*      */   
/*      */   public static final int EnumUsedAsAnIdentifier = 536870928;
/*      */   
/*      */   public static final int ForbiddenReference = 536870944;
/*      */   
/*      */   public static final int VarargsArgumentNeedCast = 536870976;
/*      */   
/*      */   public static final int NullReference = 536871040;
/*      */   
/*      */   public static final int AutoBoxing = 536871168;
/*      */   
/*      */   public static final int AnnotationSuperInterface = 536871424;
/*      */   
/*      */   public static final int TypeHiding = 536871936;
/*      */   
/*      */   public static final int MissingOverrideAnnotation = 536872960;
/*      */   
/*      */   public static final int MissingEnumConstantCase = 536875008;
/*      */   
/*      */   public static final int MissingDeprecatedAnnotation = 536879104;
/*      */   
/*      */   public static final int DiscouragedReference = 536887296;
/*      */   
/*      */   public static final int UnhandledWarningToken = 536903680;
/*      */   
/*      */   public static final int RawTypeReference = 536936448;
/*      */   
/*      */   public static final int UnusedLabel = 537001984;
/*      */   
/*      */   public static final int ParameterAssignment = 537133056;
/*      */   
/*      */   public static final int FallthroughCase = 537395200;
/*      */   
/*      */   public static final int OverridingMethodWithoutSuperInvocation = 537919488;
/*      */   
/*      */   public static final int PotentialNullReference = 538968064;
/*      */   
/*      */   public static final int RedundantNullCheck = 541065216;
/*      */   
/*      */   public static final int MissingJavadocTagDescription = 545259520;
/*      */   
/*      */   public static final int UnusedTypeArguments = 553648128;
/*      */   
/*      */   public static final int UnusedWarningToken = 570425344;
/*      */   
/*      */   public static final int RedundantSuperinterface = 603979776;
/*      */   
/*      */   public static final int ComparingIdentical = 671088640;
/*      */   
/*      */   public static final int MissingSynchronizedModifierInInheritedMethod = 805306368;
/*      */   
/*      */   public static final int ShouldImplementHashcode = 1073741825;
/*      */   
/*      */   public static final int DeadCode = 1073741826;
/*      */   
/*      */   public static final int Tasks = 1073741828;
/*      */   
/*      */   public static final int UnusedObjectAllocation = 1073741832;
/*      */   
/*      */   public static final int MethodCanBeStatic = 1073741840;
/*      */   
/*      */   public static final int MethodCanBePotentiallyStatic = 1073741856;
/*      */   
/*      */   public static final int RedundantSpecificationOfTypeArguments = 1073741888;
/*      */   
/*      */   public static final int UnclosedCloseable = 1073741952;
/*      */   
/*      */   public static final int PotentiallyUnclosedCloseable = 1073742080;
/*      */   
/*      */   public static final int ExplicitlyClosedAutoCloseable = 1073742336;
/*      */   
/*      */   public static final int NullSpecViolation = 1073742848;
/*      */   
/*      */   public static final int NullAnnotationInferenceConflict = 1073743872;
/*      */   
/*      */   public static final int NullUncheckedConversion = 1073745920;
/*      */   
/*      */   public static final int RedundantNullAnnotation = 1073750016;
/*      */   
/*      */   public static final int MissingNonNullByDefaultAnnotation = 1073758208;
/*      */   
/*      */   public static final int MissingDefaultCase = 1073774592;
/*      */   
/*      */   public static final int UnusedTypeParameter = 1073807360;
/*      */   
/*      */   public static final int NonnullParameterAnnotationDropped = 1073872896;
/*      */   
/*      */   public static final int UnusedExceptionParameter = 1074003968;
/*      */   
/*      */   public static final int PessimisticNullAnalysisForFreeTypeVariables = 1074266112;
/*      */   
/*      */   public static final int NonNullTypeVariableFromLegacyInvocation = 1074790400;
/*      */   
/*      */   public static final int UnlikelyCollectionMethodArgumentType = 1075838976;
/*      */   
/*      */   public static final int UnlikelyEqualsArgumentType = 1077936128;
/*      */   
/*      */   public static final int UsingTerminallyDeprecatedAPI = 1082130432;
/*      */   
/*      */   public static final int APILeak = 1090519040;
/*      */   
/*      */   public static final int UnstableAutoModuleName = 1107296256;
/*      */   
/*      */   public static final int PreviewFeatureUsed = 1140850688;
/*      */   
/*      */   public static final int SuppressWarningsNotAnalysed = 1207959552;
/*      */   
/*      */   public static final int AnnotatedTypeArgumentToUnannotated = 1342177280;
/*      */   
/*      */   protected IrritantSet errorThreshold;
/*      */   
/*      */   protected IrritantSet warningThreshold;
/*      */   
/*      */   protected IrritantSet infoThreshold;
/*      */   
/*      */   public int produceDebugAttributes;
/*      */   
/*      */   public boolean produceMethodParameters;
/*      */   
/*      */   public boolean generateGenericSignatureForLambdaExpressions;
/*      */   
/*      */   public long complianceLevel;
/*      */   
/*      */   public long originalComplianceLevel;
/*      */   
/*      */   public long sourceLevel;
/*      */   
/*      */   public long originalSourceLevel;
/*      */   
/*      */   public long targetJDK;
/*      */   public String defaultEncoding;
/*      */   public boolean verbose;
/*      */   public boolean produceReferenceInfo;
/*      */   public boolean preserveAllLocalVariables;
/*      */   public boolean parseLiteralExpressionsAsConstants;
/*      */   public int maxProblemsPerUnit;
/*      */   public char[][] taskTags;
/*      */   public char[][] taskPriorities;
/*      */   public boolean isTaskCaseSensitive;
/*      */   public boolean reportDeprecationInsideDeprecatedCode;
/*      */   public boolean reportDeprecationWhenOverridingDeprecatedMethod;
/*      */   public boolean reportUnusedParameterWhenImplementingAbstract;
/*      */   public boolean reportUnusedParameterWhenOverridingConcrete;
/*      */   public boolean reportUnusedParameterIncludeDocCommentReference;
/*      */   public boolean reportUnusedDeclaredThrownExceptionWhenOverriding;
/*      */   public boolean reportUnusedDeclaredThrownExceptionIncludeDocCommentReference;
/*      */   public boolean reportUnusedDeclaredThrownExceptionExemptExceptionAndThrowable;
/*      */   public boolean reportSpecialParameterHidingField;
/*      */   public boolean reportDeadCodeInTrivialIfStatement;
/*      */   public boolean docCommentSupport;
/*      */   public boolean reportInvalidJavadocTags;
/*      */   public int reportInvalidJavadocTagsVisibility;
/*      */   public boolean reportInvalidJavadocTagsDeprecatedRef;
/*      */   public boolean reportInvalidJavadocTagsNotVisibleRef;
/*      */   public String reportMissingJavadocTagDescription;
/*      */   public int reportMissingJavadocTagsVisibility;
/*      */   public boolean reportMissingJavadocTagsOverriding;
/*      */   public boolean reportMissingJavadocTagsMethodTypeParameters;
/*      */   public int reportMissingJavadocCommentsVisibility;
/*      */   public boolean reportMissingJavadocCommentsOverriding;
/*      */   public boolean inlineJsrBytecode;
/*      */   public boolean shareCommonFinallyBlocks;
/*      */   public boolean suppressWarnings;
/*      */   public boolean suppressOptionalErrors;
/*      */   public boolean treatOptionalErrorAsFatal;
/*      */   public boolean performMethodsFullRecovery;
/*      */   public boolean performStatementsRecovery;
/*      */   public boolean processAnnotations;
/*      */   public boolean storeAnnotations;
/*      */   public boolean reportMissingOverrideAnnotationForInterfaceMethodImplementation;
/*      */   public boolean generateClassFiles;
/*      */   public boolean ignoreMethodBodies;
/*      */   public boolean includeNullInfoFromAsserts;
/*      */   public boolean reportUnavoidableGenericTypeProblems;
/*      */   public boolean ignoreSourceFolderWarningOption;
/*      */   public boolean isAnnotationBasedNullAnalysisEnabled;
/*      */   public char[][] nullableAnnotationName;
/*      */   public char[][] nonNullAnnotationName;
/*      */   public char[][] nonNullByDefaultAnnotationName;
/*  509 */   public String[] nullableAnnotationSecondaryNames = NO_STRINGS;
/*      */   
/*  511 */   public String[] nonNullAnnotationSecondaryNames = NO_STRINGS;
/*      */   
/*  513 */   public String[] nonNullByDefaultAnnotationSecondaryNames = NO_STRINGS; public long intendedDefaultNonNullness; public boolean analyseResourceLeaks;
/*      */   public boolean reportMissingEnumCaseDespiteDefault;
/*      */   public boolean reportUnlikelyCollectionMethodArgumentTypeStrict;
/*      */   public static boolean tolerateIllegalAmbiguousVarargsInvocation;
/*      */   public boolean inheritNullAnnotations;
/*      */   public boolean enableSyntacticNullAnalysisForFields;
/*      */   public boolean pessimisticNullAnalysisForFreeTypeVariablesEnabled;
/*      */   public boolean complainOnUninternedIdentityComparison;
/*      */   public boolean emulateJavacBug8031744;
/*      */   public Boolean useNullTypeAnnotations;
/*      */   public boolean enablePreviewFeatures;
/*      */   public boolean enableJdtDebugCompileMode;
/*      */   public boolean ignoreUnnamedModuleForSplitPackage;
/*      */   
/*      */   public CompilerOptions(Map<String, String> settings) {
/*  528 */     String tolerateIllegalAmbiguousVarargs = System.getProperty("tolerateIllegalAmbiguousVarargsInvocation");
/*  529 */     tolerateIllegalAmbiguousVarargsInvocation = (tolerateIllegalAmbiguousVarargs != null && tolerateIllegalAmbiguousVarargs.equalsIgnoreCase("true"));
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  541 */     this.emulateJavacBug8031744 = true;
/*      */ 
/*      */     
/*  544 */     this.useNullTypeAnnotations = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  600 */     resetDefaults();
/*  601 */     if (settings != null)
/*  602 */       set(settings); 
/*      */   }
/*      */   public static final String[] warningTokens = new String[] { 
/*      */       "all", "boxing", "cast", "dep-ann", "deprecation", "exports", "fallthrough", "finally", "hiding", "incomplete-switch", 
/*      */       "javadoc", "module", "nls", "null", "rawtypes", "removal", "resource", "restriction", "serial", "static-access", 
/*      */       "static-method", "super", "synthetic-access", "sync-override", "unchecked", "unlikely-arg-type", "unqualified-field-access", "unused", "preview" };
/*      */   
/*      */   public CompilerOptions(Map<String, String> settings, boolean parseLiteralExpressionsAsConstants) {
/*  610 */     this(settings);
/*  611 */     this.parseLiteralExpressionsAsConstants = parseLiteralExpressionsAsConstants;
/*      */   }
/*      */   public CompilerOptions() {
/*      */     this(null);
/*      */   }
/*      */   
/*      */   public static String getLatestVersion() {
/*  618 */     return "20";
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String optionKeyFromIrritant(int irritant) {
/*  627 */     switch (irritant) {
/*      */       case 1:
/*  629 */         return "org.eclipse.jdt.core.compiler.problem.methodWithConstructorName";
/*      */       case 2:
/*  631 */         return "org.eclipse.jdt.core.compiler.problem.overridingPackageDefaultMethod";
/*      */       case 4:
/*      */       case 33554436:
/*  634 */         return "org.eclipse.jdt.core.compiler.problem.deprecation";
/*      */       case 1082130432:
/*      */       case 1115684864:
/*  637 */         return "org.eclipse.jdt.core.compiler.problem.terminalDeprecation";
/*      */       case 8:
/*  639 */         return "org.eclipse.jdt.core.compiler.problem.hiddenCatchBlock";
/*      */       case 16:
/*  641 */         return "org.eclipse.jdt.core.compiler.problem.unusedLocal";
/*      */       case 32:
/*  643 */         return "org.eclipse.jdt.core.compiler.problem.unusedParameter";
/*      */       case 1074003968:
/*  645 */         return "org.eclipse.jdt.core.compiler.problem.unusedExceptionParameter";
/*      */       case 64:
/*  647 */         return "org.eclipse.jdt.core.compiler.problem.noImplicitStringConversion";
/*      */       case 128:
/*  649 */         return "org.eclipse.jdt.core.compiler.problem.syntheticAccessEmulation";
/*      */       case 256:
/*  651 */         return "org.eclipse.jdt.core.compiler.problem.nonExternalizedStringLiteral";
/*      */       case 512:
/*  653 */         return "org.eclipse.jdt.core.compiler.problem.assertIdentifier";
/*      */       case 1024:
/*  655 */         return "org.eclipse.jdt.core.compiler.problem.unusedImport";
/*      */       case 2048:
/*  657 */         return "org.eclipse.jdt.core.compiler.problem.staticAccessReceiver";
/*      */       case 4096:
/*  659 */         return "org.eclipse.jdt.core.compiler.taskTags";
/*      */       case 8192:
/*  661 */         return "org.eclipse.jdt.core.compiler.problem.noEffectAssignment";
/*      */       case 16384:
/*  663 */         return "org.eclipse.jdt.core.compiler.problem.incompatibleNonInheritedInterfaceMethod";
/*      */       case 32768:
/*  665 */         return "org.eclipse.jdt.core.compiler.problem.unusedPrivateMember";
/*      */       case 65536:
/*  667 */         return "org.eclipse.jdt.core.compiler.problem.localVariableHiding";
/*      */       case 131072:
/*  669 */         return "org.eclipse.jdt.core.compiler.problem.fieldHiding";
/*      */       case 262144:
/*  671 */         return "org.eclipse.jdt.core.compiler.problem.possibleAccidentalBooleanAssignment";
/*      */       case 524288:
/*  673 */         return "org.eclipse.jdt.core.compiler.problem.emptyStatement";
/*      */       case 1048576:
/*  675 */         return "org.eclipse.jdt.core.compiler.problem.missingJavadocComments";
/*      */       case 2097152:
/*  677 */         return "org.eclipse.jdt.core.compiler.problem.missingJavadocTags";
/*      */       case 4194304:
/*  679 */         return "org.eclipse.jdt.core.compiler.problem.unqualifiedFieldAccess";
/*      */       case 8388608:
/*  681 */         return "org.eclipse.jdt.core.compiler.problem.unusedDeclaredThrownException";
/*      */       case 16777216:
/*  683 */         return "org.eclipse.jdt.core.compiler.problem.finallyBlockNotCompletingNormally";
/*      */       case 33554432:
/*  685 */         return "org.eclipse.jdt.core.compiler.problem.invalidJavadoc";
/*      */       case 67108864:
/*  687 */         return "org.eclipse.jdt.core.compiler.problem.unnecessaryTypeCheck";
/*      */       case 134217728:
/*  689 */         return "org.eclipse.jdt.core.compiler.problem.undocumentedEmptyBlock";
/*      */       case 268435456:
/*  691 */         return "org.eclipse.jdt.core.compiler.problem.indirectStaticAccess";
/*      */       case 536870913:
/*  693 */         return "org.eclipse.jdt.core.compiler.problem.unnecessaryElse";
/*      */       case 536870914:
/*  695 */         return "org.eclipse.jdt.core.compiler.problem.uncheckedTypeOperation";
/*      */       case 536870916:
/*  697 */         return "org.eclipse.jdt.core.compiler.problem.finalParameterBound";
/*      */       case 536870920:
/*  699 */         return "org.eclipse.jdt.core.compiler.problem.missingSerialVersion";
/*      */       case 536870928:
/*  701 */         return "org.eclipse.jdt.core.compiler.problem.enumIdentifier";
/*      */       case 536870944:
/*  703 */         return "org.eclipse.jdt.core.compiler.problem.forbiddenReference";
/*      */       case 536870976:
/*  705 */         return "org.eclipse.jdt.core.compiler.problem.varargsArgumentNeedCast";
/*      */       case 536871040:
/*  707 */         return "org.eclipse.jdt.core.compiler.problem.nullReference";
/*      */       case 538968064:
/*  709 */         return "org.eclipse.jdt.core.compiler.problem.potentialNullReference";
/*      */       case 541065216:
/*  711 */         return "org.eclipse.jdt.core.compiler.problem.redundantNullCheck";
/*      */       case 536871168:
/*  713 */         return "org.eclipse.jdt.core.compiler.problem.autoboxing";
/*      */       case 536871424:
/*  715 */         return "org.eclipse.jdt.core.compiler.problem.annotationSuperInterface";
/*      */       case 536871936:
/*  717 */         return "org.eclipse.jdt.core.compiler.problem.typeParameterHiding";
/*      */       case 536872960:
/*  719 */         return "org.eclipse.jdt.core.compiler.problem.missingOverrideAnnotation";
/*      */       case 536875008:
/*  721 */         return "org.eclipse.jdt.core.compiler.problem.incompleteEnumSwitch";
/*      */       case 1073774592:
/*  723 */         return "org.eclipse.jdt.core.compiler.problem.missingDefaultCase";
/*      */       case 536879104:
/*  725 */         return "org.eclipse.jdt.core.compiler.problem.missingDeprecatedAnnotation";
/*      */       case 536887296:
/*  727 */         return "org.eclipse.jdt.core.compiler.problem.discouragedReference";
/*      */       case 536903680:
/*  729 */         return "org.eclipse.jdt.core.compiler.problem.unhandledWarningToken";
/*      */       case 536936448:
/*  731 */         return "org.eclipse.jdt.core.compiler.problem.rawTypeReference";
/*      */       case 537001984:
/*  733 */         return "org.eclipse.jdt.core.compiler.problem.unusedLabel";
/*      */       case 537133056:
/*  735 */         return "org.eclipse.jdt.core.compiler.problem.parameterAssignment";
/*      */       case 537395200:
/*  737 */         return "org.eclipse.jdt.core.compiler.problem.fallthroughCase";
/*      */       case 537919488:
/*  739 */         return "org.eclipse.jdt.core.compiler.problem.overridingMethodWithoutSuperInvocation";
/*      */       case 545259520:
/*  741 */         return "org.eclipse.jdt.core.compiler.problem.missingJavadocTagDescription";
/*      */       case 553648128:
/*  743 */         return "org.eclipse.jdt.core.compiler.problem.unusedTypeArgumentsForMethodInvocation";
/*      */       case 1073807360:
/*  745 */         return "org.eclipse.jdt.core.compiler.problem.unusedTypeParameter";
/*      */       case 570425344:
/*  747 */         return "org.eclipse.jdt.core.compiler.problem.unusedWarningToken";
/*      */       case 603979776:
/*  749 */         return "org.eclipse.jdt.core.compiler.problem.redundantSuperinterface";
/*      */       case 671088640:
/*  751 */         return "org.eclipse.jdt.core.compiler.problem.comparingIdentical";
/*      */       case 805306368:
/*  753 */         return "org.eclipse.jdt.core.compiler.problem.missingSynchronizedOnInheritedMethod";
/*      */       case 1073741825:
/*  755 */         return "org.eclipse.jdt.core.compiler.problem.missingHashCodeMethod";
/*      */       case 1073741826:
/*  757 */         return "org.eclipse.jdt.core.compiler.problem.deadCode";
/*      */       case 1073741832:
/*  759 */         return "org.eclipse.jdt.core.compiler.problem.unusedObjectAllocation";
/*      */       case 1073741840:
/*  761 */         return "org.eclipse.jdt.core.compiler.problem.reportMethodCanBeStatic";
/*      */       case 1073741856:
/*  763 */         return "org.eclipse.jdt.core.compiler.problem.reportMethodCanBePotentiallyStatic";
/*      */       case 1073758208:
/*  765 */         return "org.eclipse.jdt.core.compiler.annotation.missingNonNullByDefaultAnnotation";
/*      */       case 1073741888:
/*  767 */         return "org.eclipse.jdt.core.compiler.problem.redundantSpecificationOfTypeArguments";
/*      */       case 1073741952:
/*  769 */         return "org.eclipse.jdt.core.compiler.problem.unclosedCloseable";
/*      */       case 1073742080:
/*  771 */         return "org.eclipse.jdt.core.compiler.problem.potentiallyUnclosedCloseable";
/*      */       case 1073742336:
/*  773 */         return "org.eclipse.jdt.core.compiler.problem.explicitlyClosedAutoCloseable";
/*      */       case 1073742848:
/*  775 */         return "org.eclipse.jdt.core.compiler.problem.nullSpecViolation";
/*      */       case 1073743872:
/*  777 */         return "org.eclipse.jdt.core.compiler.problem.nullAnnotationInferenceConflict";
/*      */       case 1073745920:
/*  779 */         return "org.eclipse.jdt.core.compiler.problem.nullUncheckedConversion";
/*      */       case 1073750016:
/*  781 */         return "org.eclipse.jdt.core.compiler.problem.redundantNullAnnotation";
/*      */       case 1073872896:
/*  783 */         return "org.eclipse.jdt.core.compiler.problem.nonnullParameterAnnotationDropped";
/*      */       case 1074266112:
/*  785 */         return "org.eclipse.jdt.core.compiler.problem.pessimisticNullAnalysisForFreeTypeVariables";
/*      */       case 1074790400:
/*  787 */         return "org.eclipse.jdt.core.compiler.problem.nonnullTypeVariableFromLegacyInvocation";
/*      */       case 1342177280:
/*  789 */         return "org.eclipse.jdt.core.compiler.problem.annotatedTypeArgumentToUnannotated";
/*      */       case 1075838976:
/*  791 */         return "org.eclipse.jdt.core.compiler.problem.unlikelyCollectionMethodArgumentType";
/*      */       case 1077936128:
/*  793 */         return "org.eclipse.jdt.core.compiler.problem.unlikelyEqualsArgumentType";
/*      */       case 1090519040:
/*  795 */         return "org.eclipse.jdt.core.compiler.problem.APILeak";
/*      */       case 1107296256:
/*  797 */         return "org.eclipse.jdt.core.compiler.problem.unstableAutoModuleName";
/*      */       case 1140850688:
/*  799 */         return "org.eclipse.jdt.core.compiler.problem.reportPreviewFeatures";
/*      */       case 1207959552:
/*  801 */         return "org.eclipse.jdt.core.compiler.problem.suppressWarningsNotFullyAnalysed";
/*      */     } 
/*  803 */     return null;
/*      */   }
/*      */   
/*      */   public static String versionFromJdkLevel(long jdkLevel) {
/*  807 */     int major = (int)(jdkLevel >> 16L);
/*  808 */     switch (major) {
/*      */       case 45:
/*  810 */         if (jdkLevel == 2949123L) {
/*  811 */           return "1.1";
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  856 */         return Util.EMPTY_STRING;case 46: if (jdkLevel == 3014656L) return "1.2";  return Util.EMPTY_STRING;case 47: if (jdkLevel == 3080192L) return "1.3";  return Util.EMPTY_STRING;case 48: if (jdkLevel == 3145728L) return "1.4";  return Util.EMPTY_STRING;case 49: if (jdkLevel == 3211264L) return "1.5";  return Util.EMPTY_STRING;case 50: if (jdkLevel == 3276800L) return "1.6";  return Util.EMPTY_STRING;case 51: if (jdkLevel == 3342336L) return "1.7";  return Util.EMPTY_STRING;case 52: if (jdkLevel == 3407872L) return "1.8";  return Util.EMPTY_STRING;case 53: if (jdkLevel == 3473408L) return "9";  return Util.EMPTY_STRING;case 54: if (jdkLevel == 3538944L) return "10";  return Util.EMPTY_STRING;
/*      */     } 
/*      */     if (major > 54)
/*      */       return major - 44; 
/*  860 */     return Util.EMPTY_STRING; } public static long releaseToJDKLevel(String release) { if (release != null && release.length() > 0) {
/*  861 */       int major = Integer.parseInt(release) + 44;
/*  862 */       if (major <= 64) {
/*  863 */         long jdkLevel = (major << 16L) + 0L;
/*  864 */         return jdkLevel;
/*      */       } 
/*      */     } 
/*  867 */     return 0L; }
/*      */   
/*      */   public static long versionToJdkLevel(String versionID) {
/*  870 */     return versionToJdkLevel(versionID, true);
/*      */   }
/*      */   public static long versionToJdkLevel(String versionID, boolean supportUnreleased) {
/*  873 */     String version = versionID;
/*      */     
/*  875 */     if (version != null && version.length() > 0) {
/*  876 */       if (version.length() >= 3 && version.charAt(0) == '1' && version.charAt(1) == '.') {
/*  877 */         switch (version.charAt(2)) {
/*      */           case '1':
/*  879 */             return 2949123L;
/*      */           case '2':
/*  881 */             return 3014656L;
/*      */           case '3':
/*  883 */             return 3080192L;
/*      */           case '4':
/*  885 */             return 3145728L;
/*      */           case '5':
/*  887 */             return 3211264L;
/*      */           case '6':
/*  889 */             return 3276800L;
/*      */           case '7':
/*  891 */             return 3342336L;
/*      */           case '8':
/*  893 */             return 3407872L;
/*      */         } 
/*  895 */         return 0L;
/*      */       } 
/*      */       
/*      */       try {
/*  899 */         int index = version.indexOf('.');
/*  900 */         if (index != -1) {
/*  901 */           version = version.substring(0, index);
/*      */         } else {
/*  903 */           index = version.indexOf('-');
/*  904 */           if (index != -1)
/*  905 */             version = version.substring(0, index); 
/*      */         } 
/*  907 */         int major = Integer.parseInt(version) + 44;
/*  908 */         if (major > 64)
/*  909 */           if (supportUnreleased) {
/*  910 */             major = 64;
/*      */           } else {
/*  912 */             return 0L;
/*      */           }  
/*  914 */         return (major << 16L) + 0L;
/*  915 */       } catch (NumberFormatException numberFormatException) {}
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  920 */     if ("jsr14".equals(versionID)) {
/*  921 */       return 3145728L;
/*      */     }
/*  923 */     if ("cldc1.1".equals(versionID)) {
/*  924 */       return 2949124L;
/*      */     }
/*  926 */     return 0L;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String[] warningOptionNames() {
/*  934 */     String[] result = { 
/*  935 */         "org.eclipse.jdt.core.compiler.problem.annotationSuperInterface", 
/*  936 */         "org.eclipse.jdt.core.compiler.problem.assertIdentifier", 
/*  937 */         "org.eclipse.jdt.core.compiler.problem.autoboxing", 
/*  938 */         "org.eclipse.jdt.core.compiler.problem.comparingIdentical", 
/*  939 */         "org.eclipse.jdt.core.compiler.problem.deadCode", 
/*  940 */         "org.eclipse.jdt.core.compiler.problem.deadCodeInTrivialIfStatement", 
/*  941 */         "org.eclipse.jdt.core.compiler.problem.deprecation", 
/*  942 */         "org.eclipse.jdt.core.compiler.problem.deprecationInDeprecatedCode", 
/*  943 */         "org.eclipse.jdt.core.compiler.problem.deprecationWhenOverridingDeprecatedMethod", 
/*  944 */         "org.eclipse.jdt.core.compiler.problem.discouragedReference", 
/*  945 */         "org.eclipse.jdt.core.compiler.problem.emptyStatement", 
/*  946 */         "org.eclipse.jdt.core.compiler.problem.enumIdentifier", 
/*  947 */         "org.eclipse.jdt.core.compiler.problem.fallthroughCase", 
/*  948 */         "org.eclipse.jdt.core.compiler.problem.fieldHiding", 
/*  949 */         "org.eclipse.jdt.core.compiler.problem.finallyBlockNotCompletingNormally", 
/*  950 */         "org.eclipse.jdt.core.compiler.problem.finalParameterBound", 
/*  951 */         "org.eclipse.jdt.core.compiler.problem.forbiddenReference", 
/*  952 */         "org.eclipse.jdt.core.compiler.problem.hiddenCatchBlock", 
/*  953 */         "org.eclipse.jdt.core.compiler.problem.incompatibleNonInheritedInterfaceMethod", 
/*  954 */         "org.eclipse.jdt.core.compiler.problem.missingDefaultCase", 
/*  955 */         "org.eclipse.jdt.core.compiler.problem.incompleteEnumSwitch", 
/*  956 */         "org.eclipse.jdt.core.compiler.problem.missingEnumCaseDespiteDefault", 
/*  957 */         "org.eclipse.jdt.core.compiler.problem.indirectStaticAccess", 
/*  958 */         "org.eclipse.jdt.core.compiler.problem.invalidJavadoc", 
/*  959 */         "org.eclipse.jdt.core.compiler.problem.invalidJavadocTags", 
/*  960 */         "org.eclipse.jdt.core.compiler.problem.invalidJavadocTagsDeprecatedRef", 
/*  961 */         "org.eclipse.jdt.core.compiler.problem.invalidJavadocTagsNotVisibleRef", 
/*  962 */         "org.eclipse.jdt.core.compiler.problem.invalidJavadocTagsVisibility", 
/*  963 */         "org.eclipse.jdt.core.compiler.problem.localVariableHiding", 
/*  964 */         "org.eclipse.jdt.core.compiler.problem.reportMethodCanBePotentiallyStatic", 
/*  965 */         "org.eclipse.jdt.core.compiler.problem.reportMethodCanBeStatic", 
/*  966 */         "org.eclipse.jdt.core.compiler.problem.methodWithConstructorName", 
/*  967 */         "org.eclipse.jdt.core.compiler.problem.missingDeprecatedAnnotation", 
/*  968 */         "org.eclipse.jdt.core.compiler.problem.missingHashCodeMethod", 
/*  969 */         "org.eclipse.jdt.core.compiler.problem.missingJavadocComments", 
/*  970 */         "org.eclipse.jdt.core.compiler.problem.missingJavadocCommentsOverriding", 
/*  971 */         "org.eclipse.jdt.core.compiler.problem.missingJavadocCommentsVisibility", 
/*  972 */         "org.eclipse.jdt.core.compiler.problem.missingJavadocTagDescription", 
/*  973 */         "org.eclipse.jdt.core.compiler.problem.missingJavadocTags", 
/*  974 */         "org.eclipse.jdt.core.compiler.problem.missingJavadocTagsMethodTypeParameters", 
/*  975 */         "org.eclipse.jdt.core.compiler.problem.missingJavadocTagsOverriding", 
/*  976 */         "org.eclipse.jdt.core.compiler.problem.missingJavadocTagsVisibility", 
/*  977 */         "org.eclipse.jdt.core.compiler.problem.missingOverrideAnnotation", 
/*  978 */         "org.eclipse.jdt.core.compiler.problem.missingOverrideAnnotationForInterfaceMethodImplementation", 
/*  979 */         "org.eclipse.jdt.core.compiler.problem.missingSerialVersion", 
/*  980 */         "org.eclipse.jdt.core.compiler.problem.missingSynchronizedOnInheritedMethod", 
/*  981 */         "org.eclipse.jdt.core.compiler.problem.noEffectAssignment", 
/*  982 */         "org.eclipse.jdt.core.compiler.problem.noImplicitStringConversion", 
/*  983 */         "org.eclipse.jdt.core.compiler.problem.nonExternalizedStringLiteral", 
/*  984 */         "org.eclipse.jdt.core.compiler.problem.staticAccessReceiver", 
/*  985 */         "org.eclipse.jdt.core.compiler.problem.nullReference", 
/*  986 */         "org.eclipse.jdt.core.compiler.problem.overridingMethodWithoutSuperInvocation", 
/*  987 */         "org.eclipse.jdt.core.compiler.problem.overridingPackageDefaultMethod", 
/*  988 */         "org.eclipse.jdt.core.compiler.problem.parameterAssignment", 
/*  989 */         "org.eclipse.jdt.core.compiler.problem.possibleAccidentalBooleanAssignment", 
/*  990 */         "org.eclipse.jdt.core.compiler.problem.potentialNullReference", 
/*  991 */         "org.eclipse.jdt.core.compiler.problem.rawTypeReference", 
/*  992 */         "org.eclipse.jdt.core.compiler.problem.redundantNullCheck", 
/*  993 */         "org.eclipse.jdt.core.compiler.problem.redundantSuperinterface", 
/*  994 */         "org.eclipse.jdt.core.compiler.problem.redundantSpecificationOfTypeArguments", 
/*  995 */         "org.eclipse.jdt.core.compiler.problem.specialParameterHidingField", 
/*  996 */         "org.eclipse.jdt.core.compiler.problem.syntheticAccessEmulation", 
/*  997 */         "org.eclipse.jdt.core.compiler.problem.tasks", 
/*  998 */         "org.eclipse.jdt.core.compiler.problem.typeParameterHiding", 
/*  999 */         "org.eclipse.jdt.core.compiler.problem.unavoidableGenericTypeProblems", 
/* 1000 */         "org.eclipse.jdt.core.compiler.problem.uncheckedTypeOperation", 
/* 1001 */         "org.eclipse.jdt.core.compiler.problem.undocumentedEmptyBlock", 
/* 1002 */         "org.eclipse.jdt.core.compiler.problem.unhandledWarningToken", 
/* 1003 */         "org.eclipse.jdt.core.compiler.problem.unnecessaryElse", 
/* 1004 */         "org.eclipse.jdt.core.compiler.problem.unnecessaryTypeCheck", 
/* 1005 */         "org.eclipse.jdt.core.compiler.problem.unqualifiedFieldAccess", 
/* 1006 */         "org.eclipse.jdt.core.compiler.problem.unusedDeclaredThrownException", 
/* 1007 */         "org.eclipse.jdt.core.compiler.problem.unusedDeclaredThrownExceptionExemptExceptionAndThrowable", 
/* 1008 */         "org.eclipse.jdt.core.compiler.problem.unusedDeclaredThrownExceptionIncludeDocCommentReference", 
/* 1009 */         "org.eclipse.jdt.core.compiler.problem.unusedDeclaredThrownExceptionWhenOverriding", 
/* 1010 */         "org.eclipse.jdt.core.compiler.problem.unusedImport", 
/* 1011 */         "org.eclipse.jdt.core.compiler.problem.unusedLabel", 
/* 1012 */         "org.eclipse.jdt.core.compiler.problem.unusedLocal", 
/* 1013 */         "org.eclipse.jdt.core.compiler.problem.unusedObjectAllocation", 
/* 1014 */         "org.eclipse.jdt.core.compiler.problem.unusedParameter", 
/* 1015 */         "org.eclipse.jdt.core.compiler.problem.unusedExceptionParameter", 
/* 1016 */         "org.eclipse.jdt.core.compiler.problem.unusedParameterIncludeDocCommentReference", 
/* 1017 */         "org.eclipse.jdt.core.compiler.problem.unusedParameterWhenImplementingAbstract", 
/* 1018 */         "org.eclipse.jdt.core.compiler.problem.unusedParameterWhenOverridingConcrete", 
/* 1019 */         "org.eclipse.jdt.core.compiler.problem.unusedPrivateMember", 
/* 1020 */         "org.eclipse.jdt.core.compiler.problem.unusedTypeArgumentsForMethodInvocation", 
/* 1021 */         "org.eclipse.jdt.core.compiler.problem.unusedWarningToken", 
/* 1022 */         "org.eclipse.jdt.core.compiler.problem.varargsArgumentNeedCast", 
/* 1023 */         "org.eclipse.jdt.core.compiler.problem.unclosedCloseable", 
/* 1024 */         "org.eclipse.jdt.core.compiler.problem.potentiallyUnclosedCloseable", 
/* 1025 */         "org.eclipse.jdt.core.compiler.problem.explicitlyClosedAutoCloseable", 
/* 1026 */         "org.eclipse.jdt.core.compiler.annotation.nullanalysis", 
/* 1027 */         "org.eclipse.jdt.core.compiler.annotation.nonnull", 
/* 1028 */         "org.eclipse.jdt.core.compiler.annotation.nullable", 
/* 1029 */         "org.eclipse.jdt.core.compiler.annotation.nonnullbydefault", 
/* 1030 */         "org.eclipse.jdt.core.compiler.annotation.missingNonNullByDefaultAnnotation", 
/* 1031 */         "org.eclipse.jdt.core.compiler.problem.nullSpecViolation", 
/* 1032 */         "org.eclipse.jdt.core.compiler.problem.nullAnnotationInferenceConflict", 
/* 1033 */         "org.eclipse.jdt.core.compiler.problem.nullUncheckedConversion", 
/* 1034 */         "org.eclipse.jdt.core.compiler.problem.redundantNullAnnotation", 
/* 1035 */         "org.eclipse.jdt.core.compiler.problem.syntacticNullAnalysisForFields", 
/* 1036 */         "org.eclipse.jdt.core.compiler.problem.unusedTypeParameter", 
/* 1037 */         "org.eclipse.jdt.core.compiler.annotation.inheritNullAnnotations", 
/* 1038 */         "org.eclipse.jdt.core.compiler.problem.nonnullParameterAnnotationDropped", 
/* 1039 */         "org.eclipse.jdt.core.compiler.problem.annotatedTypeArgumentToUnannotated", 
/* 1040 */         "org.eclipse.jdt.core.compiler.problem.unlikelyCollectionMethodArgumentType", 
/* 1041 */         "org.eclipse.jdt.core.compiler.problem.unlikelyEqualsArgumentType", 
/* 1042 */         "org.eclipse.jdt.core.compiler.problem.APILeak", 
/* 1043 */         "org.eclipse.jdt.core.compiler.problem.reportPreviewFeatures", 
/* 1044 */         "org.eclipse.jdt.core.compiler.problem.suppressWarningsNotFullyAnalysed" };
/*      */     
/* 1046 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String warningTokenFromIrritant(int irritant) {
/* 1054 */     switch (irritant) {
/*      */       case 4:
/*      */       case 33554436:
/* 1057 */         return "deprecation";
/*      */       case 1082130432:
/*      */       case 1115684864:
/* 1060 */         return "removal";
/*      */       case 16777216:
/* 1062 */         return "finally";
/*      */       case 8:
/*      */       case 65536:
/*      */       case 131072:
/* 1066 */         return "hiding";
/*      */       case 256:
/* 1068 */         return "nls";
/*      */       case 67108864:
/* 1070 */         return "cast";
/*      */       case 2048:
/*      */       case 268435456:
/* 1073 */         return "static-access";
/*      */       case 128:
/* 1075 */         return "synthetic-access";
/*      */       case 4194304:
/* 1077 */         return "unqualified-field-access";
/*      */       case 536870914:
/* 1079 */         return "unchecked";
/*      */       case 536870920:
/* 1081 */         return "serial";
/*      */       case 536871168:
/* 1083 */         return "boxing";
/*      */       case 536871936:
/* 1085 */         return "hiding";
/*      */       case 536875008:
/*      */       case 1073774592:
/* 1088 */         return "incomplete-switch";
/*      */       case 536879104:
/* 1090 */         return "dep-ann";
/*      */       case 536936448:
/* 1092 */         return "rawtypes";
/*      */       case 16:
/*      */       case 32:
/*      */       case 1024:
/*      */       case 32768:
/*      */       case 8388608:
/*      */       case 537001984:
/*      */       case 553648128:
/*      */       case 603979776:
/*      */       case 1073741826:
/*      */       case 1073741832:
/*      */       case 1073741888:
/*      */       case 1073807360:
/*      */       case 1074003968:
/* 1106 */         return "unused";
/*      */       case 536870944:
/*      */       case 536887296:
/* 1109 */         return "restriction";
/*      */       case 536871040:
/*      */       case 538968064:
/*      */       case 541065216:
/*      */       case 1073742848:
/*      */       case 1073743872:
/*      */       case 1073745920:
/*      */       case 1073750016:
/*      */       case 1073758208:
/*      */       case 1073872896:
/*      */       case 1074266112:
/*      */       case 1074790400:
/*      */       case 1342177280:
/* 1122 */         return "null";
/*      */       case 537395200:
/* 1124 */         return "fallthrough";
/*      */       case 537919488:
/* 1126 */         return "super";
/*      */       case 1073741840:
/*      */       case 1073741856:
/* 1129 */         return "static-method";
/*      */       case 1073741952:
/*      */       case 1073742080:
/*      */       case 1073742336:
/* 1133 */         return "resource";
/*      */       case 1048576:
/*      */       case 2097152:
/*      */       case 33554432:
/* 1137 */         return "javadoc";
/*      */       case 805306368:
/* 1139 */         return "sync-override";
/*      */       case 1075838976:
/*      */       case 1077936128:
/* 1142 */         return "unlikely-arg-type";
/*      */       case 1090519040:
/* 1144 */         return "exports";
/*      */       case 1107296256:
/* 1146 */         return "module";
/*      */       case 1140850688:
/* 1148 */         return "preview";
/*      */     } 
/* 1150 */     return null;
/*      */   }
/*      */ 
/*      */   
/*      */   public static IrritantSet warningTokenToIrritants(String warningToken) {
/* 1155 */     if (warningToken == null || warningToken.length() == 0) return null; 
/* 1156 */     switch (warningToken.charAt(0)) {
/*      */       case 'a':
/* 1158 */         if ("all".equals(warningToken))
/* 1159 */           return IrritantSet.ALL; 
/*      */         break;
/*      */       case 'b':
/* 1162 */         if ("boxing".equals(warningToken))
/* 1163 */           return IrritantSet.BOXING; 
/*      */         break;
/*      */       case 'c':
/* 1166 */         if ("cast".equals(warningToken))
/* 1167 */           return IrritantSet.CAST; 
/*      */         break;
/*      */       case 'd':
/* 1170 */         if ("deprecation".equals(warningToken))
/* 1171 */           return IrritantSet.DEPRECATION; 
/* 1172 */         if ("dep-ann".equals(warningToken))
/* 1173 */           return IrritantSet.DEP_ANN; 
/*      */         break;
/*      */       case 'e':
/* 1176 */         if ("exports".equals(warningToken))
/* 1177 */           return IrritantSet.API_LEAK; 
/*      */         break;
/*      */       case 'f':
/* 1180 */         if ("fallthrough".equals(warningToken))
/* 1181 */           return IrritantSet.FALLTHROUGH; 
/* 1182 */         if ("finally".equals(warningToken))
/* 1183 */           return IrritantSet.FINALLY; 
/*      */         break;
/*      */       case 'h':
/* 1186 */         if ("hiding".equals(warningToken))
/* 1187 */           return IrritantSet.HIDING; 
/*      */         break;
/*      */       case 'i':
/* 1190 */         if ("incomplete-switch".equals(warningToken))
/* 1191 */           return IrritantSet.INCOMPLETE_SWITCH; 
/*      */         break;
/*      */       case 'j':
/* 1194 */         if ("javadoc".equals(warningToken))
/* 1195 */           return IrritantSet.JAVADOC; 
/*      */         break;
/*      */       case 'm':
/* 1198 */         if ("module".equals(warningToken))
/* 1199 */           return IrritantSet.MODULE; 
/*      */         break;
/*      */       case 'n':
/* 1202 */         if ("nls".equals(warningToken))
/* 1203 */           return IrritantSet.NLS; 
/* 1204 */         if ("null".equals(warningToken))
/* 1205 */           return IrritantSet.NULL; 
/*      */         break;
/*      */       case 'p':
/* 1208 */         if ("preview".equals(warningToken)) {
/* 1209 */           return IrritantSet.PREVIEW;
/*      */         }
/*      */         break;
/*      */       case 'r':
/* 1213 */         if ("rawtypes".equals(warningToken))
/* 1214 */           return IrritantSet.RAW; 
/* 1215 */         if ("resource".equals(warningToken))
/* 1216 */           return IrritantSet.RESOURCE; 
/* 1217 */         if ("restriction".equals(warningToken))
/* 1218 */           return IrritantSet.RESTRICTION; 
/* 1219 */         if ("removal".equals(warningToken))
/* 1220 */           return IrritantSet.TERMINAL_DEPRECATION; 
/*      */         break;
/*      */       case 's':
/* 1223 */         if ("serial".equals(warningToken))
/* 1224 */           return IrritantSet.SERIAL; 
/* 1225 */         if ("static-access".equals(warningToken))
/* 1226 */           return IrritantSet.STATIC_ACCESS; 
/* 1227 */         if ("static-method".equals(warningToken))
/* 1228 */           return IrritantSet.STATIC_METHOD; 
/* 1229 */         if ("synthetic-access".equals(warningToken))
/* 1230 */           return IrritantSet.SYNTHETIC_ACCESS; 
/* 1231 */         if ("super".equals(warningToken)) {
/* 1232 */           return IrritantSet.SUPER;
/*      */         }
/* 1234 */         if ("sync-override".equals(warningToken))
/* 1235 */           return IrritantSet.SYNCHRONIZED; 
/*      */         break;
/*      */       case 'u':
/* 1238 */         if ("unused".equals(warningToken))
/* 1239 */           return IrritantSet.UNUSED; 
/* 1240 */         if ("unchecked".equals(warningToken))
/* 1241 */           return IrritantSet.UNCHECKED; 
/* 1242 */         if ("unqualified-field-access".equals(warningToken))
/* 1243 */           return IrritantSet.UNQUALIFIED_FIELD_ACCESS; 
/* 1244 */         if ("unlikely-arg-type".equals(warningToken))
/* 1245 */           return IrritantSet.UNLIKELY_ARGUMENT_TYPE; 
/*      */         break;
/*      */     } 
/* 1248 */     return null;
/*      */   }
/*      */ 
/*      */   
/*      */   public Map<String, String> getMap() {
/* 1253 */     Map<String, String> optionsMap = new HashMap<>(30);
/* 1254 */     optionsMap.put("org.eclipse.jdt.core.compiler.debug.localVariable", ((this.produceDebugAttributes & 0x4) != 0) ? "generate" : "do not generate");
/* 1255 */     optionsMap.put("org.eclipse.jdt.core.compiler.debug.lineNumber", ((this.produceDebugAttributes & 0x2) != 0) ? "generate" : "do not generate");
/* 1256 */     optionsMap.put("org.eclipse.jdt.core.compiler.debug.sourceFile", ((this.produceDebugAttributes & 0x1) != 0) ? "generate" : "do not generate");
/* 1257 */     optionsMap.put("org.eclipse.jdt.core.compiler.codegen.methodParameters", this.produceMethodParameters ? "generate" : "do not generate");
/* 1258 */     optionsMap.put("org.eclipse.jdt.core.compiler.codegen.lambda.genericSignature", this.generateGenericSignatureForLambdaExpressions ? "generate" : "do not generate");
/* 1259 */     optionsMap.put("org.eclipse.jdt.core.compiler.codegen.unusedLocal", this.preserveAllLocalVariables ? "preserve" : "optimize out");
/* 1260 */     optionsMap.put("org.eclipse.jdt.core.compiler.doc.comment.support", this.docCommentSupport ? "enabled" : "disabled");
/* 1261 */     optionsMap.put("org.eclipse.jdt.core.compiler.problem.methodWithConstructorName", getSeverityString(1));
/* 1262 */     optionsMap.put("org.eclipse.jdt.core.compiler.problem.overridingPackageDefaultMethod", getSeverityString(2));
/* 1263 */     optionsMap.put("org.eclipse.jdt.core.compiler.problem.deprecation", getSeverityString(4));
/* 1264 */     optionsMap.put("org.eclipse.jdt.core.compiler.problem.terminalDeprecation", getSeverityString(1082130432));
/* 1265 */     optionsMap.put("org.eclipse.jdt.core.compiler.problem.deprecationInDeprecatedCode", this.reportDeprecationInsideDeprecatedCode ? "enabled" : "disabled");
/* 1266 */     optionsMap.put("org.eclipse.jdt.core.compiler.problem.deprecationWhenOverridingDeprecatedMethod", this.reportDeprecationWhenOverridingDeprecatedMethod ? "enabled" : "disabled");
/* 1267 */     optionsMap.put("org.eclipse.jdt.core.compiler.problem.hiddenCatchBlock", getSeverityString(8));
/* 1268 */     optionsMap.put("org.eclipse.jdt.core.compiler.problem.unusedLocal", getSeverityString(16));
/* 1269 */     optionsMap.put("org.eclipse.jdt.core.compiler.problem.unusedParameter", getSeverityString(32));
/* 1270 */     optionsMap.put("org.eclipse.jdt.core.compiler.problem.unusedExceptionParameter", getSeverityString(1074003968));
/* 1271 */     optionsMap.put("org.eclipse.jdt.core.compiler.problem.unusedImport", getSeverityString(1024));
/* 1272 */     optionsMap.put("org.eclipse.jdt.core.compiler.problem.syntheticAccessEmulation", getSeverityString(128));
/* 1273 */     optionsMap.put("org.eclipse.jdt.core.compiler.problem.noEffectAssignment", getSeverityString(8192));
/* 1274 */     optionsMap.put("org.eclipse.jdt.core.compiler.problem.nonExternalizedStringLiteral", getSeverityString(256));
/* 1275 */     optionsMap.put("org.eclipse.jdt.core.compiler.problem.noImplicitStringConversion", getSeverityString(64));
/* 1276 */     optionsMap.put("org.eclipse.jdt.core.compiler.problem.staticAccessReceiver", getSeverityString(2048));
/* 1277 */     optionsMap.put("org.eclipse.jdt.core.compiler.problem.indirectStaticAccess", getSeverityString(268435456));
/* 1278 */     optionsMap.put("org.eclipse.jdt.core.compiler.problem.incompatibleNonInheritedInterfaceMethod", getSeverityString(16384));
/* 1279 */     optionsMap.put("org.eclipse.jdt.core.compiler.problem.unusedPrivateMember", getSeverityString(32768));
/* 1280 */     optionsMap.put("org.eclipse.jdt.core.compiler.problem.localVariableHiding", getSeverityString(65536));
/* 1281 */     optionsMap.put("org.eclipse.jdt.core.compiler.problem.fieldHiding", getSeverityString(131072));
/* 1282 */     optionsMap.put("org.eclipse.jdt.core.compiler.problem.typeParameterHiding", getSeverityString(536871936));
/* 1283 */     optionsMap.put("org.eclipse.jdt.core.compiler.problem.possibleAccidentalBooleanAssignment", getSeverityString(262144));
/* 1284 */     optionsMap.put("org.eclipse.jdt.core.compiler.problem.emptyStatement", getSeverityString(524288));
/* 1285 */     optionsMap.put("org.eclipse.jdt.core.compiler.problem.assertIdentifier", getSeverityString(512));
/* 1286 */     optionsMap.put("org.eclipse.jdt.core.compiler.problem.enumIdentifier", getSeverityString(536870928));
/* 1287 */     optionsMap.put("org.eclipse.jdt.core.compiler.problem.undocumentedEmptyBlock", getSeverityString(134217728));
/* 1288 */     optionsMap.put("org.eclipse.jdt.core.compiler.problem.unnecessaryTypeCheck", getSeverityString(67108864));
/* 1289 */     optionsMap.put("org.eclipse.jdt.core.compiler.problem.unnecessaryElse", getSeverityString(536870913));
/* 1290 */     optionsMap.put("org.eclipse.jdt.core.compiler.problem.autoboxing", getSeverityString(536871168));
/* 1291 */     optionsMap.put("org.eclipse.jdt.core.compiler.problem.annotationSuperInterface", getSeverityString(536871424));
/* 1292 */     optionsMap.put("org.eclipse.jdt.core.compiler.problem.incompleteEnumSwitch", getSeverityString(536875008));
/* 1293 */     optionsMap.put("org.eclipse.jdt.core.compiler.problem.missingEnumCaseDespiteDefault", this.reportMissingEnumCaseDespiteDefault ? "enabled" : "disabled");
/* 1294 */     optionsMap.put("org.eclipse.jdt.core.compiler.problem.missingDefaultCase", getSeverityString(1073774592));
/* 1295 */     optionsMap.put("org.eclipse.jdt.core.compiler.problem.invalidJavadoc", getSeverityString(33554432));
/* 1296 */     optionsMap.put("org.eclipse.jdt.core.compiler.problem.invalidJavadocTagsVisibility", getVisibilityString(this.reportInvalidJavadocTagsVisibility));
/* 1297 */     optionsMap.put("org.eclipse.jdt.core.compiler.problem.invalidJavadocTags", this.reportInvalidJavadocTags ? "enabled" : "disabled");
/* 1298 */     optionsMap.put("org.eclipse.jdt.core.compiler.problem.invalidJavadocTagsDeprecatedRef", this.reportInvalidJavadocTagsDeprecatedRef ? "enabled" : "disabled");
/* 1299 */     optionsMap.put("org.eclipse.jdt.core.compiler.problem.invalidJavadocTagsNotVisibleRef", this.reportInvalidJavadocTagsNotVisibleRef ? "enabled" : "disabled");
/* 1300 */     optionsMap.put("org.eclipse.jdt.core.compiler.problem.missingJavadocTags", getSeverityString(2097152));
/* 1301 */     optionsMap.put("org.eclipse.jdt.core.compiler.problem.missingJavadocTagsVisibility", getVisibilityString(this.reportMissingJavadocTagsVisibility));
/* 1302 */     optionsMap.put("org.eclipse.jdt.core.compiler.problem.missingJavadocTagsOverriding", this.reportMissingJavadocTagsOverriding ? "enabled" : "disabled");
/* 1303 */     optionsMap.put("org.eclipse.jdt.core.compiler.problem.missingJavadocTagsMethodTypeParameters", this.reportMissingJavadocTagsMethodTypeParameters ? "enabled" : "disabled");
/* 1304 */     optionsMap.put("org.eclipse.jdt.core.compiler.problem.missingJavadocComments", getSeverityString(1048576));
/* 1305 */     optionsMap.put("org.eclipse.jdt.core.compiler.problem.missingJavadocTagDescription", this.reportMissingJavadocTagDescription);
/* 1306 */     optionsMap.put("org.eclipse.jdt.core.compiler.problem.missingJavadocCommentsVisibility", getVisibilityString(this.reportMissingJavadocCommentsVisibility));
/* 1307 */     optionsMap.put("org.eclipse.jdt.core.compiler.problem.missingJavadocCommentsOverriding", this.reportMissingJavadocCommentsOverriding ? "enabled" : "disabled");
/* 1308 */     optionsMap.put("org.eclipse.jdt.core.compiler.problem.finallyBlockNotCompletingNormally", getSeverityString(16777216));
/* 1309 */     optionsMap.put("org.eclipse.jdt.core.compiler.problem.unusedDeclaredThrownException", getSeverityString(8388608));
/* 1310 */     optionsMap.put("org.eclipse.jdt.core.compiler.problem.unusedDeclaredThrownExceptionWhenOverriding", this.reportUnusedDeclaredThrownExceptionWhenOverriding ? "enabled" : "disabled");
/* 1311 */     optionsMap.put("org.eclipse.jdt.core.compiler.problem.unusedDeclaredThrownExceptionIncludeDocCommentReference", this.reportUnusedDeclaredThrownExceptionIncludeDocCommentReference ? "enabled" : "disabled");
/* 1312 */     optionsMap.put("org.eclipse.jdt.core.compiler.problem.unusedDeclaredThrownExceptionExemptExceptionAndThrowable", this.reportUnusedDeclaredThrownExceptionExemptExceptionAndThrowable ? "enabled" : "disabled");
/* 1313 */     optionsMap.put("org.eclipse.jdt.core.compiler.problem.unqualifiedFieldAccess", getSeverityString(4194304));
/* 1314 */     optionsMap.put("org.eclipse.jdt.core.compiler.problem.unavoidableGenericTypeProblems", this.reportUnavoidableGenericTypeProblems ? "enabled" : "disabled");
/* 1315 */     optionsMap.put("org.eclipse.jdt.core.compiler.problem.uncheckedTypeOperation", getSeverityString(536870914));
/* 1316 */     optionsMap.put("org.eclipse.jdt.core.compiler.problem.rawTypeReference", getSeverityString(536936448));
/* 1317 */     optionsMap.put("org.eclipse.jdt.core.compiler.problem.finalParameterBound", getSeverityString(536870916));
/* 1318 */     optionsMap.put("org.eclipse.jdt.core.compiler.problem.missingSerialVersion", getSeverityString(536870920));
/* 1319 */     optionsMap.put("org.eclipse.jdt.core.compiler.problem.forbiddenReference", getSeverityString(536870944));
/* 1320 */     optionsMap.put("org.eclipse.jdt.core.compiler.problem.discouragedReference", getSeverityString(536887296));
/* 1321 */     optionsMap.put("org.eclipse.jdt.core.compiler.problem.varargsArgumentNeedCast", getSeverityString(536870976));
/* 1322 */     optionsMap.put("org.eclipse.jdt.core.compiler.problem.missingOverrideAnnotation", getSeverityString(536872960));
/* 1323 */     optionsMap.put("org.eclipse.jdt.core.compiler.problem.missingOverrideAnnotationForInterfaceMethodImplementation", this.reportMissingOverrideAnnotationForInterfaceMethodImplementation ? "enabled" : "disabled");
/* 1324 */     optionsMap.put("org.eclipse.jdt.core.compiler.problem.missingDeprecatedAnnotation", getSeverityString(536879104));
/* 1325 */     optionsMap.put("org.eclipse.jdt.core.compiler.problem.unusedLabel", getSeverityString(537001984));
/* 1326 */     optionsMap.put("org.eclipse.jdt.core.compiler.problem.unusedTypeArgumentsForMethodInvocation", getSeverityString(553648128));
/* 1327 */     optionsMap.put("org.eclipse.jdt.core.compiler.compliance", versionFromJdkLevel(this.complianceLevel));
/* 1328 */     optionsMap.put("org.eclipse.jdt.core.compiler.release", "disabled");
/* 1329 */     optionsMap.put("org.eclipse.jdt.core.compiler.source", versionFromJdkLevel(this.sourceLevel));
/* 1330 */     optionsMap.put("org.eclipse.jdt.core.compiler.codegen.targetPlatform", versionFromJdkLevel(this.targetJDK));
/* 1331 */     optionsMap.put("org.eclipse.jdt.core.compiler.problem.fatalOptionalError", this.treatOptionalErrorAsFatal ? "enabled" : "disabled");
/* 1332 */     if (this.defaultEncoding != null) {
/* 1333 */       optionsMap.put("org.eclipse.jdt.core.encoding", this.defaultEncoding);
/*      */     }
/* 1335 */     optionsMap.put("org.eclipse.jdt.core.compiler.taskTags", (this.taskTags == null) ? Util.EMPTY_STRING : new String(CharOperation.concatWith(this.taskTags, ',')));
/* 1336 */     optionsMap.put("org.eclipse.jdt.core.compiler.taskPriorities", (this.taskPriorities == null) ? Util.EMPTY_STRING : new String(CharOperation.concatWith(this.taskPriorities, ',')));
/* 1337 */     optionsMap.put("org.eclipse.jdt.core.compiler.taskCaseSensitive", this.isTaskCaseSensitive ? "enabled" : "disabled");
/* 1338 */     optionsMap.put("org.eclipse.jdt.core.compiler.problem.unusedParameterWhenImplementingAbstract", this.reportUnusedParameterWhenImplementingAbstract ? "enabled" : "disabled");
/* 1339 */     optionsMap.put("org.eclipse.jdt.core.compiler.problem.unusedParameterWhenOverridingConcrete", this.reportUnusedParameterWhenOverridingConcrete ? "enabled" : "disabled");
/* 1340 */     optionsMap.put("org.eclipse.jdt.core.compiler.problem.unusedParameterIncludeDocCommentReference", this.reportUnusedParameterIncludeDocCommentReference ? "enabled" : "disabled");
/* 1341 */     optionsMap.put("org.eclipse.jdt.core.compiler.problem.specialParameterHidingField", this.reportSpecialParameterHidingField ? "enabled" : "disabled");
/* 1342 */     optionsMap.put("org.eclipse.jdt.core.compiler.maxProblemPerUnit", String.valueOf(this.maxProblemsPerUnit));
/* 1343 */     optionsMap.put("org.eclipse.jdt.core.compiler.codegen.inlineJsrBytecode", this.inlineJsrBytecode ? "enabled" : "disabled");
/* 1344 */     optionsMap.put("org.eclipse.jdt.core.compiler.codegen.shareCommonFinallyBlocks", this.shareCommonFinallyBlocks ? "enabled" : "disabled");
/* 1345 */     optionsMap.put("org.eclipse.jdt.core.compiler.problem.nullReference", getSeverityString(536871040));
/* 1346 */     optionsMap.put("org.eclipse.jdt.core.compiler.problem.potentialNullReference", getSeverityString(538968064));
/* 1347 */     optionsMap.put("org.eclipse.jdt.core.compiler.problem.redundantNullCheck", getSeverityString(541065216));
/* 1348 */     optionsMap.put("org.eclipse.jdt.core.compiler.problem.suppressWarnings", this.suppressWarnings ? "enabled" : "disabled");
/* 1349 */     optionsMap.put("org.eclipse.jdt.core.compiler.problem.suppressOptionalErrors", this.suppressOptionalErrors ? "enabled" : "disabled");
/* 1350 */     optionsMap.put("org.eclipse.jdt.core.compiler.problem.unhandledWarningToken", getSeverityString(536903680));
/* 1351 */     optionsMap.put("org.eclipse.jdt.core.compiler.problem.unusedWarningToken", getSeverityString(570425344));
/* 1352 */     optionsMap.put("org.eclipse.jdt.core.compiler.problem.parameterAssignment", getSeverityString(537133056));
/* 1353 */     optionsMap.put("org.eclipse.jdt.core.compiler.problem.fallthroughCase", getSeverityString(537395200));
/* 1354 */     optionsMap.put("org.eclipse.jdt.core.compiler.problem.overridingMethodWithoutSuperInvocation", getSeverityString(537919488));
/* 1355 */     optionsMap.put("org.eclipse.jdt.core.compiler.generateClassFiles", this.generateClassFiles ? "enabled" : "disabled");
/* 1356 */     optionsMap.put("org.eclipse.jdt.core.compiler.processAnnotations", this.processAnnotations ? "enabled" : "disabled");
/* 1357 */     optionsMap.put("org.eclipse.jdt.core.compiler.storeAnnotations", this.storeAnnotations ? "enabled" : "disabled");
/* 1358 */     optionsMap.put("org.eclipse.jdt.core.compiler.emulateJavacBug8031744", this.emulateJavacBug8031744 ? "enabled" : "disabled");
/* 1359 */     optionsMap.put("org.eclipse.jdt.core.compiler.problem.redundantSuperinterface", getSeverityString(603979776));
/* 1360 */     optionsMap.put("org.eclipse.jdt.core.compiler.problem.comparingIdentical", getSeverityString(671088640));
/* 1361 */     optionsMap.put("org.eclipse.jdt.core.compiler.problem.missingSynchronizedOnInheritedMethod", getSeverityString(805306368));
/* 1362 */     optionsMap.put("org.eclipse.jdt.core.compiler.problem.missingHashCodeMethod", getSeverityString(1073741825));
/* 1363 */     optionsMap.put("org.eclipse.jdt.core.compiler.problem.deadCode", getSeverityString(1073741826));
/* 1364 */     optionsMap.put("org.eclipse.jdt.core.compiler.problem.deadCodeInTrivialIfStatement", this.reportDeadCodeInTrivialIfStatement ? "enabled" : "disabled");
/* 1365 */     optionsMap.put("org.eclipse.jdt.core.compiler.problem.tasks", getSeverityString(1073741828));
/* 1366 */     optionsMap.put("org.eclipse.jdt.core.compiler.problem.unusedObjectAllocation", getSeverityString(1073741832));
/* 1367 */     optionsMap.put("org.eclipse.jdt.core.compiler.problem.includeNullInfoFromAsserts", this.includeNullInfoFromAsserts ? "enabled" : "disabled");
/* 1368 */     optionsMap.put("org.eclipse.jdt.core.compiler.problem.reportMethodCanBeStatic", getSeverityString(1073741840));
/* 1369 */     optionsMap.put("org.eclipse.jdt.core.compiler.problem.reportMethodCanBePotentiallyStatic", getSeverityString(1073741856));
/* 1370 */     optionsMap.put("org.eclipse.jdt.core.compiler.problem.redundantSpecificationOfTypeArguments", getSeverityString(1073741888));
/* 1371 */     optionsMap.put("org.eclipse.jdt.core.compiler.problem.unclosedCloseable", getSeverityString(1073741952));
/* 1372 */     optionsMap.put("org.eclipse.jdt.core.compiler.problem.potentiallyUnclosedCloseable", getSeverityString(1073742080));
/* 1373 */     optionsMap.put("org.eclipse.jdt.core.compiler.problem.explicitlyClosedAutoCloseable", getSeverityString(1073742336));
/* 1374 */     optionsMap.put("org.eclipse.jdt.core.compiler.annotation.nullanalysis", this.isAnnotationBasedNullAnalysisEnabled ? "enabled" : "disabled");
/* 1375 */     optionsMap.put("org.eclipse.jdt.core.compiler.problem.nullSpecViolation", getSeverityString(1073742848));
/* 1376 */     optionsMap.put("org.eclipse.jdt.core.compiler.problem.nullAnnotationInferenceConflict", getSeverityString(1073743872));
/* 1377 */     optionsMap.put("org.eclipse.jdt.core.compiler.problem.nullUncheckedConversion", getSeverityString(1073745920));
/* 1378 */     optionsMap.put("org.eclipse.jdt.core.compiler.problem.redundantNullAnnotation", getSeverityString(1073750016));
/* 1379 */     optionsMap.put("org.eclipse.jdt.core.compiler.annotation.nullable", String.valueOf(CharOperation.concatWith(this.nullableAnnotationName, '.')));
/* 1380 */     optionsMap.put("org.eclipse.jdt.core.compiler.annotation.nonnull", String.valueOf(CharOperation.concatWith(this.nonNullAnnotationName, '.')));
/* 1381 */     optionsMap.put("org.eclipse.jdt.core.compiler.annotation.nonnullbydefault", String.valueOf(CharOperation.concatWith(this.nonNullByDefaultAnnotationName, '.')));
/* 1382 */     optionsMap.put("org.eclipse.jdt.core.compiler.annotation.nullable.secondary", nameListToString(this.nullableAnnotationSecondaryNames));
/* 1383 */     optionsMap.put("org.eclipse.jdt.core.compiler.annotation.nonnull.secondary", nameListToString(this.nonNullAnnotationSecondaryNames));
/* 1384 */     optionsMap.put("org.eclipse.jdt.core.compiler.annotation.nonnullbydefault.secondary", nameListToString(this.nonNullByDefaultAnnotationSecondaryNames));
/* 1385 */     optionsMap.put("org.eclipse.jdt.core.compiler.annotation.missingNonNullByDefaultAnnotation", getSeverityString(1073758208));
/* 1386 */     optionsMap.put("org.eclipse.jdt.core.compiler.problem.unusedTypeParameter", getSeverityString(1073807360));
/* 1387 */     optionsMap.put("org.eclipse.jdt.core.compiler.problem.syntacticNullAnalysisForFields", this.enableSyntacticNullAnalysisForFields ? "enabled" : "disabled");
/* 1388 */     optionsMap.put("org.eclipse.jdt.core.compiler.annotation.inheritNullAnnotations", this.inheritNullAnnotations ? "enabled" : "disabled");
/* 1389 */     optionsMap.put("org.eclipse.jdt.core.compiler.problem.nonnullParameterAnnotationDropped", getSeverityString(1073872896));
/* 1390 */     optionsMap.put("org.eclipse.jdt.core.compiler.problem.uninternedIdentityComparison", this.complainOnUninternedIdentityComparison ? "enabled" : "disabled");
/* 1391 */     optionsMap.put("org.eclipse.jdt.core.compiler.problem.pessimisticNullAnalysisForFreeTypeVariables", getSeverityString(1074266112));
/* 1392 */     optionsMap.put("org.eclipse.jdt.core.compiler.problem.nonnullTypeVariableFromLegacyInvocation", getSeverityString(1074790400));
/* 1393 */     optionsMap.put("org.eclipse.jdt.core.compiler.problem.annotatedTypeArgumentToUnannotated", getSeverityString(1342177280));
/* 1394 */     optionsMap.put("org.eclipse.jdt.core.compiler.problem.unlikelyCollectionMethodArgumentType", getSeverityString(1075838976));
/* 1395 */     optionsMap.put("org.eclipse.jdt.core.compiler.problem.unlikelyCollectionMethodArgumentTypeStrict", this.reportUnlikelyCollectionMethodArgumentTypeStrict ? "enabled" : "disabled");
/* 1396 */     optionsMap.put("org.eclipse.jdt.core.compiler.problem.unlikelyEqualsArgumentType", getSeverityString(1077936128));
/* 1397 */     optionsMap.put("org.eclipse.jdt.core.compiler.problem.APILeak", getSeverityString(1090519040));
/* 1398 */     optionsMap.put("org.eclipse.jdt.core.compiler.problem.unstableAutoModuleName", getSeverityString(1107296256));
/* 1399 */     optionsMap.put("org.eclipse.jdt.core.compiler.problem.enablePreviewFeatures", this.enablePreviewFeatures ? "enabled" : "disabled");
/* 1400 */     optionsMap.put("org.eclipse.jdt.core.compiler.problem.reportPreviewFeatures", getSeverityString(1140850688));
/* 1401 */     optionsMap.put("org.eclipse.jdt.core.compiler.problem.suppressWarningsNotFullyAnalysed", getSeverityString(1207959552));
/* 1402 */     optionsMap.put("org.eclipse.jdt.core.compiler.ignoreUnnamedModuleForSplitPackage", this.ignoreUnnamedModuleForSplitPackage ? "enabled" : "disabled");
/* 1403 */     return optionsMap;
/*      */   }
/*      */   
/*      */   public int getSeverity(int irritant) {
/* 1407 */     if (this.errorThreshold.isSet(irritant)) {
/* 1408 */       if ((irritant & 0xE2000000) == 570425344) {
/* 1409 */         return 33;
/*      */       }
/* 1411 */       return this.treatOptionalErrorAsFatal ? 
/* 1412 */         161 : 
/* 1413 */         33;
/*      */     } 
/* 1415 */     if (this.warningThreshold.isSet(irritant)) {
/* 1416 */       return 32;
/*      */     }
/* 1418 */     if (this.infoThreshold.isSet(irritant)) {
/* 1419 */       return 1056;
/*      */     }
/* 1421 */     return 256;
/*      */   }
/*      */   
/*      */   public String getSeverityString(int irritant) {
/* 1425 */     if (this.errorThreshold.isSet(irritant))
/* 1426 */       return "error"; 
/* 1427 */     if (this.warningThreshold.isSet(irritant))
/* 1428 */       return "warning"; 
/* 1429 */     if (this.infoThreshold.isSet(irritant)) {
/* 1430 */       return "info";
/*      */     }
/* 1432 */     return "ignore";
/*      */   }
/*      */   public String getVisibilityString(int level) {
/* 1435 */     switch (level & 0x7) {
/*      */       case 1:
/* 1437 */         return "public";
/*      */       case 4:
/* 1439 */         return "protected";
/*      */       case 2:
/* 1441 */         return "private";
/*      */     } 
/* 1443 */     return "default";
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isAnyEnabled(IrritantSet irritants) {
/* 1448 */     return !(!this.warningThreshold.isAnySet(irritants) && !this.errorThreshold.isAnySet(irritants) && 
/* 1449 */       !this.infoThreshold.isAnySet(irritants));
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public int getIgnoredIrritant(IrritantSet irritants) {
/* 1455 */     int[] bits = irritants.getBits();
/* 1456 */     for (int i = 0; i < 3; i++) {
/* 1457 */       int bit = bits[i];
/* 1458 */       for (int b = 0; b < 29; b++) {
/* 1459 */         int single = bit & 1 << b;
/* 1460 */         if (single > 0) {
/* 1461 */           single |= i << 29;
/* 1462 */           if (single != 1073758208)
/*      */           {
/* 1464 */             if (!this.warningThreshold.isSet(single) && !this.errorThreshold.isSet(single) && !this.infoThreshold.isSet(single))
/* 1465 */               return single; 
/*      */           }
/*      */         } 
/*      */       } 
/*      */     } 
/* 1470 */     return 0;
/*      */   }
/*      */ 
/*      */   
/*      */   protected void resetDefaults() {
/* 1475 */     this.errorThreshold = new IrritantSet(IrritantSet.COMPILER_DEFAULT_ERRORS);
/* 1476 */     this.warningThreshold = new IrritantSet(IrritantSet.COMPILER_DEFAULT_WARNINGS);
/* 1477 */     this.infoThreshold = new IrritantSet(IrritantSet.COMPILER_DEFAULT_INFOS);
/*      */ 
/*      */     
/* 1480 */     this.produceDebugAttributes = 3;
/* 1481 */     this.complianceLevel = this.originalComplianceLevel = 3145728L;
/* 1482 */     this.sourceLevel = this.originalSourceLevel = 3080192L;
/* 1483 */     this.targetJDK = 3014656L;
/*      */     
/* 1485 */     this.defaultEncoding = null;
/*      */ 
/*      */     
/* 1488 */     this.verbose = Compiler.DEBUG;
/*      */     
/* 1490 */     this.produceReferenceInfo = false;
/*      */ 
/*      */     
/* 1493 */     this.preserveAllLocalVariables = false;
/*      */     
/* 1495 */     this.produceMethodParameters = false;
/*      */ 
/*      */     
/* 1498 */     this.parseLiteralExpressionsAsConstants = true;
/*      */ 
/*      */     
/* 1501 */     this.maxProblemsPerUnit = 100;
/*      */ 
/*      */     
/* 1504 */     this.taskTags = null;
/* 1505 */     this.taskPriorities = null;
/* 1506 */     this.isTaskCaseSensitive = true;
/*      */ 
/*      */     
/* 1509 */     this.reportDeprecationInsideDeprecatedCode = false;
/* 1510 */     this.reportDeprecationWhenOverridingDeprecatedMethod = false;
/*      */ 
/*      */     
/* 1513 */     this.reportUnusedParameterWhenImplementingAbstract = false;
/* 1514 */     this.reportUnusedParameterWhenOverridingConcrete = false;
/* 1515 */     this.reportUnusedParameterIncludeDocCommentReference = true;
/*      */ 
/*      */     
/* 1518 */     this.reportUnusedDeclaredThrownExceptionWhenOverriding = false;
/* 1519 */     this.reportUnusedDeclaredThrownExceptionIncludeDocCommentReference = true;
/* 1520 */     this.reportUnusedDeclaredThrownExceptionExemptExceptionAndThrowable = true;
/*      */ 
/*      */     
/* 1523 */     this.reportSpecialParameterHidingField = false;
/*      */     
/* 1525 */     this.reportUnavoidableGenericTypeProblems = true;
/*      */ 
/*      */     
/* 1528 */     this.reportInvalidJavadocTagsVisibility = 1;
/* 1529 */     this.reportInvalidJavadocTags = false;
/* 1530 */     this.reportInvalidJavadocTagsDeprecatedRef = false;
/* 1531 */     this.reportInvalidJavadocTagsNotVisibleRef = false;
/* 1532 */     this.reportMissingJavadocTagDescription = "return_tag";
/*      */ 
/*      */     
/* 1535 */     this.reportMissingJavadocTagsVisibility = 1;
/* 1536 */     this.reportMissingJavadocTagsOverriding = false;
/* 1537 */     this.reportMissingJavadocTagsMethodTypeParameters = false;
/*      */ 
/*      */     
/* 1540 */     this.reportMissingJavadocCommentsVisibility = 1;
/* 1541 */     this.reportMissingJavadocCommentsOverriding = false;
/*      */ 
/*      */     
/* 1544 */     this.inlineJsrBytecode = false;
/* 1545 */     this.shareCommonFinallyBlocks = false;
/*      */ 
/*      */     
/* 1548 */     this.docCommentSupport = false;
/*      */ 
/*      */     
/* 1551 */     this.suppressWarnings = true;
/*      */ 
/*      */     
/* 1554 */     this.suppressOptionalErrors = false;
/*      */ 
/*      */     
/* 1557 */     this.treatOptionalErrorAsFatal = false;
/*      */ 
/*      */     
/* 1560 */     this.performMethodsFullRecovery = true;
/*      */ 
/*      */     
/* 1563 */     this.performStatementsRecovery = true;
/*      */ 
/*      */     
/* 1566 */     this.storeAnnotations = false;
/*      */ 
/*      */     
/* 1569 */     this.generateClassFiles = true;
/*      */ 
/*      */     
/* 1572 */     this.processAnnotations = false;
/*      */ 
/*      */     
/* 1575 */     this.reportMissingOverrideAnnotationForInterfaceMethodImplementation = true;
/*      */ 
/*      */     
/* 1578 */     this.reportDeadCodeInTrivialIfStatement = false;
/*      */ 
/*      */     
/* 1581 */     this.ignoreMethodBodies = false;
/*      */     
/* 1583 */     this.ignoreSourceFolderWarningOption = false;
/*      */ 
/*      */     
/* 1586 */     this.includeNullInfoFromAsserts = false;
/*      */     
/* 1588 */     this.isAnnotationBasedNullAnalysisEnabled = false;
/* 1589 */     this.nullableAnnotationName = DEFAULT_NULLABLE_ANNOTATION_NAME;
/* 1590 */     this.nonNullAnnotationName = DEFAULT_NONNULL_ANNOTATION_NAME;
/* 1591 */     this.nonNullByDefaultAnnotationName = DEFAULT_NONNULLBYDEFAULT_ANNOTATION_NAME;
/* 1592 */     this.intendedDefaultNonNullness = 0L;
/* 1593 */     this.enableSyntacticNullAnalysisForFields = false;
/* 1594 */     this.inheritNullAnnotations = false;
/*      */     
/* 1596 */     this.analyseResourceLeaks = true;
/*      */     
/* 1598 */     this.reportMissingEnumCaseDespiteDefault = false;
/*      */     
/* 1600 */     this.complainOnUninternedIdentityComparison = false;
/* 1601 */     this.enablePreviewFeatures = false;
/*      */     
/* 1603 */     this.enableJdtDebugCompileMode = false;
/* 1604 */     this.ignoreUnnamedModuleForSplitPackage = false;
/*      */   }
/*      */   
/*      */   public void set(Map<String, String> optionsMap) {
/*      */     String optionValue;
/* 1609 */     if ((optionValue = optionsMap.get("org.eclipse.jdt.core.compiler.debug.localVariable")) != null) {
/* 1610 */       if ("generate".equals(optionValue)) {
/* 1611 */         this.produceDebugAttributes |= 0x4;
/* 1612 */       } else if ("do not generate".equals(optionValue)) {
/* 1613 */         this.produceDebugAttributes &= 0xFFFFFFFB;
/*      */       } 
/*      */     }
/* 1616 */     if ((optionValue = optionsMap.get("org.eclipse.jdt.core.compiler.debug.lineNumber")) != null) {
/* 1617 */       if ("generate".equals(optionValue)) {
/* 1618 */         this.produceDebugAttributes |= 0x2;
/* 1619 */       } else if ("do not generate".equals(optionValue)) {
/* 1620 */         this.produceDebugAttributes &= 0xFFFFFFFD;
/*      */       } 
/*      */     }
/* 1623 */     if ((optionValue = optionsMap.get("org.eclipse.jdt.core.compiler.debug.sourceFile")) != null) {
/* 1624 */       if ("generate".equals(optionValue)) {
/* 1625 */         this.produceDebugAttributes |= 0x1;
/* 1626 */       } else if ("do not generate".equals(optionValue)) {
/* 1627 */         this.produceDebugAttributes &= 0xFFFFFFFE;
/*      */       } 
/*      */     }
/* 1630 */     if ((optionValue = optionsMap.get("org.eclipse.jdt.core.compiler.codegen.unusedLocal")) != null) {
/* 1631 */       if ("preserve".equals(optionValue)) {
/* 1632 */         this.preserveAllLocalVariables = true;
/* 1633 */       } else if ("optimize out".equals(optionValue)) {
/* 1634 */         this.preserveAllLocalVariables = false;
/*      */       } 
/*      */     }
/* 1637 */     if ((optionValue = optionsMap.get("org.eclipse.jdt.core.compiler.problem.deprecationInDeprecatedCode")) != null) {
/* 1638 */       if ("enabled".equals(optionValue)) {
/* 1639 */         this.reportDeprecationInsideDeprecatedCode = true;
/* 1640 */       } else if ("disabled".equals(optionValue)) {
/* 1641 */         this.reportDeprecationInsideDeprecatedCode = false;
/*      */       } 
/*      */     }
/* 1644 */     if ((optionValue = optionsMap.get("org.eclipse.jdt.core.compiler.problem.deprecationWhenOverridingDeprecatedMethod")) != null) {
/* 1645 */       if ("enabled".equals(optionValue)) {
/* 1646 */         this.reportDeprecationWhenOverridingDeprecatedMethod = true;
/* 1647 */       } else if ("disabled".equals(optionValue)) {
/* 1648 */         this.reportDeprecationWhenOverridingDeprecatedMethod = false;
/*      */       } 
/*      */     }
/* 1651 */     if ((optionValue = optionsMap.get("org.eclipse.jdt.core.compiler.problem.unusedDeclaredThrownExceptionWhenOverriding")) != null) {
/* 1652 */       if ("enabled".equals(optionValue)) {
/* 1653 */         this.reportUnusedDeclaredThrownExceptionWhenOverriding = true;
/* 1654 */       } else if ("disabled".equals(optionValue)) {
/* 1655 */         this.reportUnusedDeclaredThrownExceptionWhenOverriding = false;
/*      */       } 
/*      */     }
/* 1658 */     if ((optionValue = optionsMap.get("org.eclipse.jdt.core.compiler.problem.unusedDeclaredThrownExceptionIncludeDocCommentReference")) != null) {
/* 1659 */       if ("enabled".equals(optionValue)) {
/* 1660 */         this.reportUnusedDeclaredThrownExceptionIncludeDocCommentReference = true;
/* 1661 */       } else if ("disabled".equals(optionValue)) {
/* 1662 */         this.reportUnusedDeclaredThrownExceptionIncludeDocCommentReference = false;
/*      */       } 
/*      */     }
/* 1665 */     if ((optionValue = optionsMap.get("org.eclipse.jdt.core.compiler.problem.unusedDeclaredThrownExceptionExemptExceptionAndThrowable")) != null) {
/* 1666 */       if ("enabled".equals(optionValue)) {
/* 1667 */         this.reportUnusedDeclaredThrownExceptionExemptExceptionAndThrowable = true;
/* 1668 */       } else if ("disabled".equals(optionValue)) {
/* 1669 */         this.reportUnusedDeclaredThrownExceptionExemptExceptionAndThrowable = false;
/*      */       } 
/*      */     }
/* 1672 */     if ((optionValue = optionsMap.get("org.eclipse.jdt.core.compiler.compliance")) != null) {
/* 1673 */       long level = versionToJdkLevel(optionValue);
/* 1674 */       if (level != 0L) this.complianceLevel = this.originalComplianceLevel = level; 
/*      */     } 
/* 1676 */     if ((optionValue = optionsMap.get("org.eclipse.jdt.core.compiler.source")) != null) {
/* 1677 */       long level = versionToJdkLevel(optionValue);
/* 1678 */       if (level != 0L) this.sourceLevel = this.originalSourceLevel = level; 
/*      */     } 
/* 1680 */     if ((optionValue = optionsMap.get("org.eclipse.jdt.core.compiler.codegen.targetPlatform")) != null) {
/* 1681 */       long level = versionToJdkLevel(optionValue);
/* 1682 */       if (level != 0L) {
/* 1683 */         if (this.enablePreviewFeatures) {
/* 1684 */           level |= 0xFFFFL;
/*      */         }
/* 1686 */         this.targetJDK = level;
/*      */       } 
/* 1688 */       if (this.targetJDK >= 3211264L) this.inlineJsrBytecode = true; 
/*      */     } 
/* 1690 */     if ((optionValue = optionsMap.get("org.eclipse.jdt.core.encoding")) != null) {
/* 1691 */       this.defaultEncoding = null;
/* 1692 */       String stringValue = optionValue;
/* 1693 */       if (stringValue.length() > 0) {
/*      */         
/*      */         try {
/* 1696 */           this.defaultEncoding = stringValue;
/* 1697 */         } catch (UnsupportedEncodingException unsupportedEncodingException) {}
/*      */       }
/*      */     } 
/*      */ 
/*      */     
/* 1702 */     if ((optionValue = optionsMap.get("org.eclipse.jdt.core.compiler.problem.unusedParameterWhenImplementingAbstract")) != null) {
/* 1703 */       if ("enabled".equals(optionValue)) {
/* 1704 */         this.reportUnusedParameterWhenImplementingAbstract = true;
/* 1705 */       } else if ("disabled".equals(optionValue)) {
/* 1706 */         this.reportUnusedParameterWhenImplementingAbstract = false;
/*      */       } 
/*      */     }
/* 1709 */     if ((optionValue = optionsMap.get("org.eclipse.jdt.core.compiler.problem.unusedParameterWhenOverridingConcrete")) != null) {
/* 1710 */       if ("enabled".equals(optionValue)) {
/* 1711 */         this.reportUnusedParameterWhenOverridingConcrete = true;
/* 1712 */       } else if ("disabled".equals(optionValue)) {
/* 1713 */         this.reportUnusedParameterWhenOverridingConcrete = false;
/*      */       } 
/*      */     }
/* 1716 */     if ((optionValue = optionsMap.get("org.eclipse.jdt.core.compiler.problem.unusedParameterIncludeDocCommentReference")) != null) {
/* 1717 */       if ("enabled".equals(optionValue)) {
/* 1718 */         this.reportUnusedParameterIncludeDocCommentReference = true;
/* 1719 */       } else if ("disabled".equals(optionValue)) {
/* 1720 */         this.reportUnusedParameterIncludeDocCommentReference = false;
/*      */       } 
/*      */     }
/* 1723 */     if ((optionValue = optionsMap.get("org.eclipse.jdt.core.compiler.problem.specialParameterHidingField")) != null) {
/* 1724 */       if ("enabled".equals(optionValue)) {
/* 1725 */         this.reportSpecialParameterHidingField = true;
/* 1726 */       } else if ("disabled".equals(optionValue)) {
/* 1727 */         this.reportSpecialParameterHidingField = false;
/*      */       } 
/*      */     }
/* 1730 */     if ((optionValue = optionsMap.get("org.eclipse.jdt.core.compiler.problem.unavoidableGenericTypeProblems")) != null) {
/* 1731 */       if ("enabled".equals(optionValue)) {
/* 1732 */         this.reportUnavoidableGenericTypeProblems = true;
/* 1733 */       } else if ("disabled".equals(optionValue)) {
/* 1734 */         this.reportUnavoidableGenericTypeProblems = false;
/*      */       } 
/*      */     }
/* 1737 */     if ((optionValue = optionsMap.get("org.eclipse.jdt.core.compiler.problem.deadCodeInTrivialIfStatement")) != null) {
/* 1738 */       if ("enabled".equals(optionValue)) {
/* 1739 */         this.reportDeadCodeInTrivialIfStatement = true;
/* 1740 */       } else if ("disabled".equals(optionValue)) {
/* 1741 */         this.reportDeadCodeInTrivialIfStatement = false;
/*      */       } 
/*      */     }
/* 1744 */     if ((optionValue = optionsMap.get("org.eclipse.jdt.core.compiler.maxProblemPerUnit")) != null) {
/* 1745 */       String stringValue = optionValue;
/*      */       try {
/* 1747 */         int val = Integer.parseInt(stringValue);
/* 1748 */         if (val >= 0) this.maxProblemsPerUnit = val; 
/* 1749 */       } catch (NumberFormatException numberFormatException) {}
/*      */     } 
/*      */ 
/*      */     
/* 1753 */     if ((optionValue = optionsMap.get("org.eclipse.jdt.core.compiler.taskTags")) != null) {
/* 1754 */       String stringValue = optionValue;
/* 1755 */       if (stringValue.length() == 0) {
/* 1756 */         this.taskTags = null;
/*      */       } else {
/* 1758 */         this.taskTags = CharOperation.splitAndTrimOn(',', stringValue.toCharArray());
/*      */       } 
/*      */     } 
/* 1761 */     if ((optionValue = optionsMap.get("org.eclipse.jdt.core.compiler.taskPriorities")) != null) {
/* 1762 */       String stringValue = optionValue;
/* 1763 */       if (stringValue.length() == 0) {
/* 1764 */         this.taskPriorities = null;
/*      */       } else {
/* 1766 */         this.taskPriorities = CharOperation.splitAndTrimOn(',', stringValue.toCharArray());
/*      */       } 
/*      */     } 
/* 1769 */     if ((optionValue = optionsMap.get("org.eclipse.jdt.core.compiler.taskCaseSensitive")) != null) {
/* 1770 */       if ("enabled".equals(optionValue)) {
/* 1771 */         this.isTaskCaseSensitive = true;
/* 1772 */       } else if ("disabled".equals(optionValue)) {
/* 1773 */         this.isTaskCaseSensitive = false;
/*      */       } 
/*      */     }
/* 1776 */     if ((optionValue = optionsMap.get("org.eclipse.jdt.core.compiler.codegen.inlineJsrBytecode")) != null && 
/* 1777 */       this.targetJDK < 3211264L) {
/* 1778 */       if ("enabled".equals(optionValue)) {
/* 1779 */         this.inlineJsrBytecode = true;
/* 1780 */       } else if ("disabled".equals(optionValue)) {
/* 1781 */         this.inlineJsrBytecode = false;
/*      */       } 
/*      */     }
/*      */     
/* 1785 */     if ((optionValue = optionsMap.get("org.eclipse.jdt.core.compiler.codegen.shareCommonFinallyBlocks")) != null) {
/* 1786 */       if ("enabled".equals(optionValue)) {
/* 1787 */         this.shareCommonFinallyBlocks = true;
/* 1788 */       } else if ("disabled".equals(optionValue)) {
/* 1789 */         this.shareCommonFinallyBlocks = false;
/*      */       } 
/*      */     }
/* 1792 */     if ((optionValue = optionsMap.get("org.eclipse.jdt.core.compiler.codegen.methodParameters")) != null) {
/* 1793 */       if ("generate".equals(optionValue)) {
/* 1794 */         this.produceMethodParameters = true;
/* 1795 */       } else if ("do not generate".equals(optionValue)) {
/* 1796 */         this.produceMethodParameters = false;
/*      */       } 
/*      */     }
/* 1799 */     if ((optionValue = optionsMap.get("org.eclipse.jdt.core.compiler.codegen.lambda.genericSignature")) != null) {
/* 1800 */       if ("generate".equals(optionValue)) {
/* 1801 */         this.generateGenericSignatureForLambdaExpressions = true;
/* 1802 */       } else if ("do not generate".equals(optionValue)) {
/* 1803 */         this.generateGenericSignatureForLambdaExpressions = false;
/*      */       } 
/*      */     }
/* 1806 */     if ((optionValue = optionsMap.get("org.eclipse.jdt.core.compiler.problem.suppressWarnings")) != null) {
/* 1807 */       if ("enabled".equals(optionValue)) {
/* 1808 */         this.suppressWarnings = true;
/* 1809 */       } else if ("disabled".equals(optionValue)) {
/* 1810 */         this.suppressWarnings = false;
/*      */       } 
/*      */     }
/* 1813 */     if ((optionValue = optionsMap.get("org.eclipse.jdt.core.compiler.problem.suppressOptionalErrors")) != null) {
/* 1814 */       if ("enabled".equals(optionValue)) {
/* 1815 */         this.suppressOptionalErrors = true;
/* 1816 */       } else if ("disabled".equals(optionValue)) {
/* 1817 */         this.suppressOptionalErrors = false;
/*      */       } 
/*      */     }
/* 1820 */     if ((optionValue = optionsMap.get("org.eclipse.jdt.core.compiler.problem.fatalOptionalError")) != null) {
/* 1821 */       if ("enabled".equals(optionValue)) {
/* 1822 */         this.treatOptionalErrorAsFatal = true;
/* 1823 */       } else if ("disabled".equals(optionValue)) {
/* 1824 */         this.treatOptionalErrorAsFatal = false;
/*      */       } 
/*      */     }
/* 1827 */     if ((optionValue = optionsMap.get("org.eclipse.jdt.core.compiler.problem.missingOverrideAnnotationForInterfaceMethodImplementation")) != null) {
/* 1828 */       if ("enabled".equals(optionValue)) {
/* 1829 */         this.reportMissingOverrideAnnotationForInterfaceMethodImplementation = true;
/* 1830 */       } else if ("disabled".equals(optionValue)) {
/* 1831 */         this.reportMissingOverrideAnnotationForInterfaceMethodImplementation = false;
/*      */       } 
/*      */     }
/* 1834 */     if ((optionValue = optionsMap.get("org.eclipse.jdt.core.compiler.problem.includeNullInfoFromAsserts")) != null) {
/* 1835 */       if ("enabled".equals(optionValue)) {
/* 1836 */         this.includeNullInfoFromAsserts = true;
/* 1837 */       } else if ("disabled".equals(optionValue)) {
/* 1838 */         this.includeNullInfoFromAsserts = false;
/*      */       } 
/*      */     }
/* 1841 */     if ((optionValue = optionsMap.get("org.eclipse.jdt.core.compiler.problem.methodWithConstructorName")) != null) updateSeverity(1, optionValue); 
/* 1842 */     if ((optionValue = optionsMap.get("org.eclipse.jdt.core.compiler.problem.overridingPackageDefaultMethod")) != null) updateSeverity(2, optionValue); 
/* 1843 */     if ((optionValue = optionsMap.get("org.eclipse.jdt.core.compiler.problem.deprecation")) != null) updateSeverity(4, optionValue); 
/* 1844 */     if ((optionValue = optionsMap.get("org.eclipse.jdt.core.compiler.problem.terminalDeprecation")) != null) updateSeverity(1082130432, optionValue); 
/* 1845 */     if ((optionValue = optionsMap.get("org.eclipse.jdt.core.compiler.problem.hiddenCatchBlock")) != null) updateSeverity(8, optionValue); 
/* 1846 */     if ((optionValue = optionsMap.get("org.eclipse.jdt.core.compiler.problem.unusedLocal")) != null) updateSeverity(16, optionValue); 
/* 1847 */     if ((optionValue = optionsMap.get("org.eclipse.jdt.core.compiler.problem.unusedParameter")) != null) updateSeverity(32, optionValue); 
/* 1848 */     if ((optionValue = optionsMap.get("org.eclipse.jdt.core.compiler.problem.unusedExceptionParameter")) != null) updateSeverity(1074003968, optionValue); 
/* 1849 */     if ((optionValue = optionsMap.get("org.eclipse.jdt.core.compiler.problem.unusedImport")) != null) updateSeverity(1024, optionValue); 
/* 1850 */     if ((optionValue = optionsMap.get("org.eclipse.jdt.core.compiler.problem.unusedPrivateMember")) != null) updateSeverity(32768, optionValue); 
/* 1851 */     if ((optionValue = optionsMap.get("org.eclipse.jdt.core.compiler.problem.unusedDeclaredThrownException")) != null) updateSeverity(8388608, optionValue); 
/* 1852 */     if ((optionValue = optionsMap.get("org.eclipse.jdt.core.compiler.problem.noImplicitStringConversion")) != null) updateSeverity(64, optionValue); 
/* 1853 */     if ((optionValue = optionsMap.get("org.eclipse.jdt.core.compiler.problem.syntheticAccessEmulation")) != null) updateSeverity(128, optionValue); 
/* 1854 */     if ((optionValue = optionsMap.get("org.eclipse.jdt.core.compiler.problem.localVariableHiding")) != null) updateSeverity(65536, optionValue); 
/* 1855 */     if ((optionValue = optionsMap.get("org.eclipse.jdt.core.compiler.problem.fieldHiding")) != null) updateSeverity(131072, optionValue); 
/* 1856 */     if ((optionValue = optionsMap.get("org.eclipse.jdt.core.compiler.problem.typeParameterHiding")) != null) updateSeverity(536871936, optionValue); 
/* 1857 */     if ((optionValue = optionsMap.get("org.eclipse.jdt.core.compiler.problem.possibleAccidentalBooleanAssignment")) != null) updateSeverity(262144, optionValue); 
/* 1858 */     if ((optionValue = optionsMap.get("org.eclipse.jdt.core.compiler.problem.emptyStatement")) != null) updateSeverity(524288, optionValue); 
/* 1859 */     if ((optionValue = optionsMap.get("org.eclipse.jdt.core.compiler.problem.nonExternalizedStringLiteral")) != null) updateSeverity(256, optionValue); 
/* 1860 */     if ((optionValue = optionsMap.get("org.eclipse.jdt.core.compiler.problem.assertIdentifier")) != null) updateSeverity(512, optionValue); 
/* 1861 */     if ((optionValue = optionsMap.get("org.eclipse.jdt.core.compiler.problem.enumIdentifier")) != null) updateSeverity(536870928, optionValue); 
/* 1862 */     if ((optionValue = optionsMap.get("org.eclipse.jdt.core.compiler.problem.staticAccessReceiver")) != null) updateSeverity(2048, optionValue); 
/* 1863 */     if ((optionValue = optionsMap.get("org.eclipse.jdt.core.compiler.problem.indirectStaticAccess")) != null) updateSeverity(268435456, optionValue); 
/* 1864 */     if ((optionValue = optionsMap.get("org.eclipse.jdt.core.compiler.problem.incompatibleNonInheritedInterfaceMethod")) != null) updateSeverity(16384, optionValue); 
/* 1865 */     if ((optionValue = optionsMap.get("org.eclipse.jdt.core.compiler.problem.undocumentedEmptyBlock")) != null) updateSeverity(134217728, optionValue); 
/* 1866 */     if ((optionValue = optionsMap.get("org.eclipse.jdt.core.compiler.problem.unnecessaryTypeCheck")) != null) updateSeverity(67108864, optionValue); 
/* 1867 */     if ((optionValue = optionsMap.get("org.eclipse.jdt.core.compiler.problem.unnecessaryElse")) != null) updateSeverity(536870913, optionValue); 
/* 1868 */     if ((optionValue = optionsMap.get("org.eclipse.jdt.core.compiler.problem.finallyBlockNotCompletingNormally")) != null) updateSeverity(16777216, optionValue); 
/* 1869 */     if ((optionValue = optionsMap.get("org.eclipse.jdt.core.compiler.problem.unqualifiedFieldAccess")) != null) updateSeverity(4194304, optionValue); 
/* 1870 */     if ((optionValue = optionsMap.get("org.eclipse.jdt.core.compiler.problem.noEffectAssignment")) != null) updateSeverity(8192, optionValue); 
/* 1871 */     if ((optionValue = optionsMap.get("org.eclipse.jdt.core.compiler.problem.uncheckedTypeOperation")) != null) updateSeverity(536870914, optionValue); 
/* 1872 */     if ((optionValue = optionsMap.get("org.eclipse.jdt.core.compiler.problem.rawTypeReference")) != null) updateSeverity(536936448, optionValue); 
/* 1873 */     if ((optionValue = optionsMap.get("org.eclipse.jdt.core.compiler.problem.finalParameterBound")) != null) updateSeverity(536870916, optionValue); 
/* 1874 */     if ((optionValue = optionsMap.get("org.eclipse.jdt.core.compiler.problem.missingSerialVersion")) != null) updateSeverity(536870920, optionValue); 
/* 1875 */     if ((optionValue = optionsMap.get("org.eclipse.jdt.core.compiler.problem.forbiddenReference")) != null) updateSeverity(536870944, optionValue); 
/* 1876 */     if ((optionValue = optionsMap.get("org.eclipse.jdt.core.compiler.problem.discouragedReference")) != null) updateSeverity(536887296, optionValue); 
/* 1877 */     if ((optionValue = optionsMap.get("org.eclipse.jdt.core.compiler.problem.varargsArgumentNeedCast")) != null) updateSeverity(536870976, optionValue); 
/* 1878 */     if ((optionValue = optionsMap.get("org.eclipse.jdt.core.compiler.problem.nullReference")) != null) updateSeverity(536871040, optionValue); 
/* 1879 */     if ((optionValue = optionsMap.get("org.eclipse.jdt.core.compiler.problem.potentialNullReference")) != null) updateSeverity(538968064, optionValue); 
/* 1880 */     if ((optionValue = optionsMap.get("org.eclipse.jdt.core.compiler.problem.redundantNullCheck")) != null) updateSeverity(541065216, optionValue); 
/* 1881 */     if ((optionValue = optionsMap.get("org.eclipse.jdt.core.compiler.problem.autoboxing")) != null) updateSeverity(536871168, optionValue); 
/* 1882 */     if ((optionValue = optionsMap.get("org.eclipse.jdt.core.compiler.problem.annotationSuperInterface")) != null) updateSeverity(536871424, optionValue); 
/* 1883 */     if ((optionValue = optionsMap.get("org.eclipse.jdt.core.compiler.problem.missingOverrideAnnotation")) != null) updateSeverity(536872960, optionValue); 
/* 1884 */     if ((optionValue = optionsMap.get("org.eclipse.jdt.core.compiler.problem.missingDeprecatedAnnotation")) != null) updateSeverity(536879104, optionValue); 
/* 1885 */     if ((optionValue = optionsMap.get("org.eclipse.jdt.core.compiler.problem.incompleteEnumSwitch")) != null) updateSeverity(536875008, optionValue); 
/* 1886 */     if ((optionValue = optionsMap.get("org.eclipse.jdt.core.compiler.problem.missingEnumCaseDespiteDefault")) != null) {
/* 1887 */       if ("enabled".equals(optionValue)) {
/* 1888 */         this.reportMissingEnumCaseDespiteDefault = true;
/* 1889 */       } else if ("disabled".equals(optionValue)) {
/* 1890 */         this.reportMissingEnumCaseDespiteDefault = false;
/*      */       } 
/*      */     }
/* 1893 */     if ((optionValue = optionsMap.get("org.eclipse.jdt.core.compiler.problem.missingDefaultCase")) != null) updateSeverity(1073774592, optionValue); 
/* 1894 */     if ((optionValue = optionsMap.get("org.eclipse.jdt.core.compiler.problem.unhandledWarningToken")) != null) updateSeverity(536903680, optionValue); 
/* 1895 */     if ((optionValue = optionsMap.get("org.eclipse.jdt.core.compiler.problem.unusedWarningToken")) != null) updateSeverity(570425344, optionValue); 
/* 1896 */     if ((optionValue = optionsMap.get("org.eclipse.jdt.core.compiler.problem.unusedLabel")) != null) updateSeverity(537001984, optionValue); 
/* 1897 */     if ((optionValue = optionsMap.get("org.eclipse.jdt.core.compiler.problem.parameterAssignment")) != null) updateSeverity(537133056, optionValue); 
/* 1898 */     if ((optionValue = optionsMap.get("org.eclipse.jdt.core.compiler.problem.fallthroughCase")) != null) updateSeverity(537395200, optionValue); 
/* 1899 */     if ((optionValue = optionsMap.get("org.eclipse.jdt.core.compiler.problem.overridingMethodWithoutSuperInvocation")) != null) updateSeverity(537919488, optionValue); 
/* 1900 */     if ((optionValue = optionsMap.get("org.eclipse.jdt.core.compiler.problem.unusedTypeArgumentsForMethodInvocation")) != null) updateSeverity(553648128, optionValue); 
/* 1901 */     if ((optionValue = optionsMap.get("org.eclipse.jdt.core.compiler.problem.redundantSuperinterface")) != null) updateSeverity(603979776, optionValue); 
/* 1902 */     if ((optionValue = optionsMap.get("org.eclipse.jdt.core.compiler.problem.comparingIdentical")) != null) updateSeverity(671088640, optionValue); 
/* 1903 */     if ((optionValue = optionsMap.get("org.eclipse.jdt.core.compiler.problem.missingSynchronizedOnInheritedMethod")) != null) updateSeverity(805306368, optionValue); 
/* 1904 */     if ((optionValue = optionsMap.get("org.eclipse.jdt.core.compiler.problem.missingHashCodeMethod")) != null) updateSeverity(1073741825, optionValue); 
/* 1905 */     if ((optionValue = optionsMap.get("org.eclipse.jdt.core.compiler.problem.deadCode")) != null) updateSeverity(1073741826, optionValue); 
/* 1906 */     if ((optionValue = optionsMap.get("org.eclipse.jdt.core.compiler.problem.tasks")) != null) updateSeverity(1073741828, optionValue); 
/* 1907 */     if ((optionValue = optionsMap.get("org.eclipse.jdt.core.compiler.problem.unusedObjectAllocation")) != null) updateSeverity(1073741832, optionValue); 
/* 1908 */     if ((optionValue = optionsMap.get("org.eclipse.jdt.core.compiler.problem.reportMethodCanBeStatic")) != null) updateSeverity(1073741840, optionValue); 
/* 1909 */     if ((optionValue = optionsMap.get("org.eclipse.jdt.core.compiler.problem.reportMethodCanBePotentiallyStatic")) != null) updateSeverity(1073741856, optionValue); 
/* 1910 */     if ((optionValue = optionsMap.get("org.eclipse.jdt.core.compiler.problem.redundantSpecificationOfTypeArguments")) != null) updateSeverity(1073741888, optionValue); 
/* 1911 */     if ((optionValue = optionsMap.get("org.eclipse.jdt.core.compiler.problem.unclosedCloseable")) != null) updateSeverity(1073741952, optionValue); 
/* 1912 */     if ((optionValue = optionsMap.get("org.eclipse.jdt.core.compiler.problem.potentiallyUnclosedCloseable")) != null) updateSeverity(1073742080, optionValue); 
/* 1913 */     if ((optionValue = optionsMap.get("org.eclipse.jdt.core.compiler.problem.explicitlyClosedAutoCloseable")) != null) updateSeverity(1073742336, optionValue); 
/* 1914 */     if ((optionValue = optionsMap.get("org.eclipse.jdt.core.compiler.problem.unusedTypeParameter")) != null) updateSeverity(1073807360, optionValue); 
/* 1915 */     if ((optionValue = optionsMap.get("org.eclipse.jdt.core.compiler.problem.unlikelyCollectionMethodArgumentType")) != null) updateSeverity(1075838976, optionValue); 
/* 1916 */     if ((optionValue = optionsMap.get("org.eclipse.jdt.core.compiler.problem.unlikelyCollectionMethodArgumentTypeStrict")) != null) {
/* 1917 */       this.reportUnlikelyCollectionMethodArgumentTypeStrict = "enabled".equals(optionValue);
/*      */     }
/* 1919 */     if ((optionValue = optionsMap.get("org.eclipse.jdt.core.compiler.problem.unlikelyEqualsArgumentType")) != null) updateSeverity(1077936128, optionValue); 
/* 1920 */     if (getSeverity(1073741952) == 256 && 
/* 1921 */       getSeverity(1073742080) == 256 && 
/* 1922 */       getSeverity(1073742336) == 256) {
/* 1923 */       this.analyseResourceLeaks = false;
/*      */     } else {
/* 1925 */       this.analyseResourceLeaks = true;
/*      */     } 
/* 1927 */     if ((optionValue = optionsMap.get("org.eclipse.jdt.core.compiler.problem.APILeak")) != null) updateSeverity(1090519040, optionValue); 
/* 1928 */     if ((optionValue = optionsMap.get("org.eclipse.jdt.core.compiler.problem.unstableAutoModuleName")) != null) updateSeverity(1107296256, optionValue); 
/* 1929 */     if ((optionValue = optionsMap.get("org.eclipse.jdt.core.compiler.annotation.nullanalysis")) != null) {
/* 1930 */       this.isAnnotationBasedNullAnalysisEnabled = "enabled".equals(optionValue);
/*      */     }
/* 1932 */     if (this.isAnnotationBasedNullAnalysisEnabled) {
/* 1933 */       this.storeAnnotations = true;
/* 1934 */       if ((optionValue = optionsMap.get("org.eclipse.jdt.core.compiler.problem.nullSpecViolation")) != null) {
/* 1935 */         if ("error".equals(optionValue)) {
/* 1936 */           this.errorThreshold.set(1073742848);
/* 1937 */           this.warningThreshold.clear(1073742848);
/* 1938 */         } else if ("warning".equals(optionValue)) {
/* 1939 */           this.errorThreshold.clear(1073742848);
/* 1940 */           this.warningThreshold.set(1073742848);
/*      */         } 
/*      */       }
/*      */       
/* 1944 */       if ((optionValue = optionsMap.get("org.eclipse.jdt.core.compiler.problem.nullAnnotationInferenceConflict")) != null) updateSeverity(1073743872, optionValue); 
/* 1945 */       if ((optionValue = optionsMap.get("org.eclipse.jdt.core.compiler.problem.nullUncheckedConversion")) != null) updateSeverity(1073745920, optionValue); 
/* 1946 */       if ((optionValue = optionsMap.get("org.eclipse.jdt.core.compiler.problem.redundantNullAnnotation")) != null) updateSeverity(1073750016, optionValue); 
/* 1947 */       if ((optionValue = optionsMap.get("org.eclipse.jdt.core.compiler.annotation.nullable")) != null) {
/* 1948 */         this.nullableAnnotationName = CharOperation.splitAndTrimOn('.', optionValue.toCharArray());
/*      */       }
/* 1950 */       if ((optionValue = optionsMap.get("org.eclipse.jdt.core.compiler.annotation.nonnull")) != null) {
/* 1951 */         this.nonNullAnnotationName = CharOperation.splitAndTrimOn('.', optionValue.toCharArray());
/*      */       }
/* 1953 */       if ((optionValue = optionsMap.get("org.eclipse.jdt.core.compiler.annotation.nonnullbydefault")) != null) {
/* 1954 */         this.nonNullByDefaultAnnotationName = CharOperation.splitAndTrimOn('.', optionValue.toCharArray());
/*      */       }
/* 1956 */       if ((optionValue = optionsMap.get("org.eclipse.jdt.core.compiler.annotation.nullable.secondary")) != null) {
/* 1957 */         this.nullableAnnotationSecondaryNames = stringToNameList(optionValue);
/*      */       }
/* 1959 */       if ((optionValue = optionsMap.get("org.eclipse.jdt.core.compiler.annotation.nonnull.secondary")) != null) {
/* 1960 */         this.nonNullAnnotationSecondaryNames = stringToNameList(optionValue);
/*      */       }
/* 1962 */       if ((optionValue = optionsMap.get("org.eclipse.jdt.core.compiler.annotation.nonnullbydefault.secondary")) != null) {
/* 1963 */         this.nonNullByDefaultAnnotationSecondaryNames = stringToNameList(optionValue);
/*      */       }
/* 1965 */       if ((optionValue = optionsMap.get("org.eclipse.jdt.core.compiler.annotation.missingNonNullByDefaultAnnotation")) != null) updateSeverity(1073758208, optionValue); 
/* 1966 */       if ((optionValue = optionsMap.get("org.eclipse.jdt.core.compiler.problem.syntacticNullAnalysisForFields")) != null) {
/* 1967 */         this.enableSyntacticNullAnalysisForFields = "enabled".equals(optionValue);
/*      */       }
/* 1969 */       if ((optionValue = optionsMap.get("org.eclipse.jdt.core.compiler.annotation.inheritNullAnnotations")) != null) {
/* 1970 */         this.inheritNullAnnotations = "enabled".equals(optionValue);
/*      */       }
/* 1972 */       if ((optionValue = optionsMap.get("org.eclipse.jdt.core.compiler.problem.nonnullParameterAnnotationDropped")) != null) updateSeverity(1073872896, optionValue); 
/* 1973 */       if ((optionValue = optionsMap.get("org.eclipse.jdt.core.compiler.problem.annotatedTypeArgumentToUnannotated")) != null) updateSeverity(1342177280, optionValue); 
/* 1974 */       if ((optionValue = optionsMap.get("org.eclipse.jdt.core.compiler.problem.pessimisticNullAnalysisForFreeTypeVariables")) != null) updateSeverity(1074266112, optionValue); 
/* 1975 */       if (getSeverity(1074266112) == 256) {
/* 1976 */         this.pessimisticNullAnalysisForFreeTypeVariablesEnabled = false;
/*      */       } else {
/* 1978 */         this.pessimisticNullAnalysisForFreeTypeVariablesEnabled = true;
/*      */       } 
/* 1980 */       if ((optionValue = optionsMap.get("org.eclipse.jdt.core.compiler.problem.nonnullTypeVariableFromLegacyInvocation")) != null) updateSeverity(1074790400, optionValue);
/*      */     
/*      */     } 
/*      */     
/* 1984 */     if ((optionValue = optionsMap.get("org.eclipse.jdt.core.compiler.doc.comment.support")) != null) {
/* 1985 */       if ("enabled".equals(optionValue)) {
/* 1986 */         this.docCommentSupport = true;
/* 1987 */       } else if ("disabled".equals(optionValue)) {
/* 1988 */         this.docCommentSupport = false;
/*      */       } 
/*      */     }
/* 1991 */     if ((optionValue = optionsMap.get("org.eclipse.jdt.core.compiler.problem.invalidJavadoc")) != null) {
/* 1992 */       updateSeverity(33554432, optionValue);
/*      */     }
/* 1994 */     if ((optionValue = optionsMap.get("org.eclipse.jdt.core.compiler.problem.invalidJavadocTagsVisibility")) != null) {
/* 1995 */       if ("public".equals(optionValue)) {
/* 1996 */         this.reportInvalidJavadocTagsVisibility = 1;
/* 1997 */       } else if ("protected".equals(optionValue)) {
/* 1998 */         this.reportInvalidJavadocTagsVisibility = 4;
/* 1999 */       } else if ("default".equals(optionValue)) {
/* 2000 */         this.reportInvalidJavadocTagsVisibility = 0;
/* 2001 */       } else if ("private".equals(optionValue)) {
/* 2002 */         this.reportInvalidJavadocTagsVisibility = 2;
/*      */       } 
/*      */     }
/* 2005 */     if ((optionValue = optionsMap.get("org.eclipse.jdt.core.compiler.problem.invalidJavadocTags")) != null) {
/* 2006 */       if ("enabled".equals(optionValue)) {
/* 2007 */         this.reportInvalidJavadocTags = true;
/* 2008 */       } else if ("disabled".equals(optionValue)) {
/* 2009 */         this.reportInvalidJavadocTags = false;
/*      */       } 
/*      */     }
/* 2012 */     if ((optionValue = optionsMap.get("org.eclipse.jdt.core.compiler.problem.invalidJavadocTagsDeprecatedRef")) != null) {
/* 2013 */       if ("enabled".equals(optionValue)) {
/* 2014 */         this.reportInvalidJavadocTagsDeprecatedRef = true;
/* 2015 */       } else if ("disabled".equals(optionValue)) {
/* 2016 */         this.reportInvalidJavadocTagsDeprecatedRef = false;
/*      */       } 
/*      */     }
/* 2019 */     if ((optionValue = optionsMap.get("org.eclipse.jdt.core.compiler.problem.invalidJavadocTagsNotVisibleRef")) != null) {
/* 2020 */       if ("enabled".equals(optionValue)) {
/* 2021 */         this.reportInvalidJavadocTagsNotVisibleRef = true;
/* 2022 */       } else if ("disabled".equals(optionValue)) {
/* 2023 */         this.reportInvalidJavadocTagsNotVisibleRef = false;
/*      */       } 
/*      */     }
/* 2026 */     if ((optionValue = optionsMap.get("org.eclipse.jdt.core.compiler.problem.missingJavadocTags")) != null) {
/* 2027 */       updateSeverity(2097152, optionValue);
/*      */     }
/* 2029 */     if ((optionValue = optionsMap.get("org.eclipse.jdt.core.compiler.problem.missingJavadocTagsVisibility")) != null) {
/* 2030 */       if ("public".equals(optionValue)) {
/* 2031 */         this.reportMissingJavadocTagsVisibility = 1;
/* 2032 */       } else if ("protected".equals(optionValue)) {
/* 2033 */         this.reportMissingJavadocTagsVisibility = 4;
/* 2034 */       } else if ("default".equals(optionValue)) {
/* 2035 */         this.reportMissingJavadocTagsVisibility = 0;
/* 2036 */       } else if ("private".equals(optionValue)) {
/* 2037 */         this.reportMissingJavadocTagsVisibility = 2;
/*      */       } 
/*      */     }
/* 2040 */     if ((optionValue = optionsMap.get("org.eclipse.jdt.core.compiler.problem.missingJavadocTagsOverriding")) != null) {
/* 2041 */       if ("enabled".equals(optionValue)) {
/* 2042 */         this.reportMissingJavadocTagsOverriding = true;
/* 2043 */       } else if ("disabled".equals(optionValue)) {
/* 2044 */         this.reportMissingJavadocTagsOverriding = false;
/*      */       } 
/*      */     }
/* 2047 */     if ((optionValue = optionsMap.get("org.eclipse.jdt.core.compiler.problem.missingJavadocTagsMethodTypeParameters")) != null) {
/* 2048 */       if ("enabled".equals(optionValue)) {
/* 2049 */         this.reportMissingJavadocTagsMethodTypeParameters = true;
/* 2050 */       } else if ("disabled".equals(optionValue)) {
/* 2051 */         this.reportMissingJavadocTagsMethodTypeParameters = false;
/*      */       } 
/*      */     }
/* 2054 */     if ((optionValue = optionsMap.get("org.eclipse.jdt.core.compiler.problem.missingJavadocComments")) != null) {
/* 2055 */       updateSeverity(1048576, optionValue);
/*      */     }
/* 2057 */     if ((optionValue = optionsMap.get("org.eclipse.jdt.core.compiler.problem.missingJavadocTagDescription")) != null) {
/* 2058 */       this.reportMissingJavadocTagDescription = optionValue;
/*      */     }
/* 2060 */     if ((optionValue = optionsMap.get("org.eclipse.jdt.core.compiler.problem.missingJavadocCommentsVisibility")) != null) {
/* 2061 */       if ("public".equals(optionValue)) {
/* 2062 */         this.reportMissingJavadocCommentsVisibility = 1;
/* 2063 */       } else if ("protected".equals(optionValue)) {
/* 2064 */         this.reportMissingJavadocCommentsVisibility = 4;
/* 2065 */       } else if ("default".equals(optionValue)) {
/* 2066 */         this.reportMissingJavadocCommentsVisibility = 0;
/* 2067 */       } else if ("private".equals(optionValue)) {
/* 2068 */         this.reportMissingJavadocCommentsVisibility = 2;
/*      */       } 
/*      */     }
/* 2071 */     if ((optionValue = optionsMap.get("org.eclipse.jdt.core.compiler.problem.missingJavadocCommentsOverriding")) != null) {
/* 2072 */       if ("enabled".equals(optionValue)) {
/* 2073 */         this.reportMissingJavadocCommentsOverriding = true;
/* 2074 */       } else if ("disabled".equals(optionValue)) {
/* 2075 */         this.reportMissingJavadocCommentsOverriding = false;
/*      */       } 
/*      */     }
/* 2078 */     if ((optionValue = optionsMap.get("org.eclipse.jdt.core.compiler.generateClassFiles")) != null) {
/* 2079 */       if ("enabled".equals(optionValue)) {
/* 2080 */         this.generateClassFiles = true;
/* 2081 */       } else if ("disabled".equals(optionValue)) {
/* 2082 */         this.generateClassFiles = false;
/*      */       } 
/*      */     }
/* 2085 */     if ((optionValue = optionsMap.get("org.eclipse.jdt.core.compiler.processAnnotations")) != null)
/* 2086 */       if ("enabled".equals(optionValue)) {
/* 2087 */         this.processAnnotations = true;
/* 2088 */         this.storeAnnotations = true;
/* 2089 */       } else if ("disabled".equals(optionValue)) {
/* 2090 */         this.processAnnotations = false;
/* 2091 */         if (!this.isAnnotationBasedNullAnalysisEnabled) {
/* 2092 */           this.storeAnnotations = false;
/*      */         }
/*      */       }  
/* 2095 */     if ((optionValue = optionsMap.get("org.eclipse.jdt.core.compiler.storeAnnotations")) != null) {
/* 2096 */       if ("enabled".equals(optionValue)) {
/* 2097 */         this.storeAnnotations = true;
/* 2098 */       } else if ("disabled".equals(optionValue) && 
/* 2099 */         !this.isAnnotationBasedNullAnalysisEnabled && !this.processAnnotations) {
/* 2100 */         this.storeAnnotations = false;
/*      */       } 
/*      */     }
/* 2103 */     if ((optionValue = optionsMap.get("org.eclipse.jdt.core.compiler.emulateJavacBug8031744")) != null) {
/* 2104 */       if ("enabled".equals(optionValue)) {
/* 2105 */         this.emulateJavacBug8031744 = true;
/* 2106 */       } else if ("disabled".equals(optionValue)) {
/* 2107 */         this.emulateJavacBug8031744 = false;
/*      */       } 
/*      */     }
/* 2110 */     if ((optionValue = optionsMap.get("org.eclipse.jdt.core.compiler.problem.uninternedIdentityComparison")) != null) {
/* 2111 */       if ("enabled".equals(optionValue)) {
/* 2112 */         this.complainOnUninternedIdentityComparison = true;
/* 2113 */       } else if ("disabled".equals(optionValue)) {
/* 2114 */         this.complainOnUninternedIdentityComparison = false;
/*      */       } 
/*      */     }
/* 2117 */     if ((optionValue = optionsMap.get("org.eclipse.jdt.core.compiler.problem.enablePreviewFeatures")) != null) {
/* 2118 */       if ("enabled".equals(optionValue)) {
/* 2119 */         this.enablePreviewFeatures = true;
/* 2120 */         if (this.targetJDK != 0L)
/* 2121 */           this.targetJDK |= 0xFFFFL; 
/* 2122 */       } else if ("disabled".equals(optionValue)) {
/* 2123 */         this.enablePreviewFeatures = false;
/*      */       } 
/*      */     }
/* 2126 */     if ((optionValue = optionsMap.get("org.eclipse.jdt.core.compiler.problem.reportPreviewFeatures")) != null)
/* 2127 */       updateSeverity(1140850688, optionValue); 
/* 2128 */     if ((optionValue = optionsMap.get("org.eclipse.jdt.core.compiler.problem.suppressWarningsNotFullyAnalysed")) != null) {
/* 2129 */       updateSeverity(1207959552, optionValue);
/*      */     }
/* 2131 */     if ((optionValue = optionsMap.get("org.eclipse.jdt.internal.debug.compile.mode")) != null) {
/* 2132 */       if ("enabled".equals(optionValue)) {
/* 2133 */         this.enableJdtDebugCompileMode = true;
/* 2134 */       } else if ("disabled".equals(optionValue)) {
/* 2135 */         this.enableJdtDebugCompileMode = false;
/*      */       } 
/*      */     }
/*      */     
/* 2139 */     if ((optionValue = optionsMap.get("org.eclipse.jdt.core.compiler.ignoreUnnamedModuleForSplitPackage")) != null) {
/* 2140 */       if ("enabled".equals(optionValue)) {
/* 2141 */         this.ignoreUnnamedModuleForSplitPackage = true;
/* 2142 */       } else if ("disabled".equals(optionValue)) {
/* 2143 */         this.ignoreUnnamedModuleForSplitPackage = false;
/*      */       } 
/*      */     }
/*      */   }
/*      */   
/*      */   private String[] stringToNameList(String optionValue) {
/* 2149 */     String[] result = optionValue.split(",");
/* 2150 */     if (result == null)
/* 2151 */       return NO_STRINGS; 
/* 2152 */     for (int i = 0; i < result.length; i++)
/* 2153 */       result[i] = result[i].trim(); 
/* 2154 */     return result;
/*      */   }
/*      */   
/*      */   String nameListToString(String[] names) {
/* 2158 */     if (names == null) return ""; 
/* 2159 */     return String.join(String.valueOf(','), (CharSequence[])names);
/*      */   }
/*      */ 
/*      */   
/*      */   public String toString() {
/* 2164 */     StringBuilder buf = new StringBuilder("CompilerOptions:");
/* 2165 */     buf.append("\n\t- local variables debug attributes: ").append(((this.produceDebugAttributes & 0x4) != 0) ? "ON" : " OFF");
/* 2166 */     buf.append("\n\t- line number debug attributes: ").append(((this.produceDebugAttributes & 0x2) != 0) ? "ON" : " OFF");
/* 2167 */     buf.append("\n\t- source debug attributes: ").append(((this.produceDebugAttributes & 0x1) != 0) ? "ON" : " OFF");
/* 2168 */     buf.append("\n\t- MethodParameters attributes: ").append(this.produceMethodParameters ? "generate" : "do not generate");
/* 2169 */     buf.append("\n\t- Generic signature for lambda expressions: ").append(this.generateGenericSignatureForLambdaExpressions ? "generate" : "do not generate");
/* 2170 */     buf.append("\n\t- preserve all local variables: ").append(this.preserveAllLocalVariables ? "ON" : " OFF");
/* 2171 */     buf.append("\n\t- method with constructor name: ").append(getSeverityString(1));
/* 2172 */     buf.append("\n\t- overridden package default method: ").append(getSeverityString(2));
/* 2173 */     buf.append("\n\t- deprecation: ").append(getSeverityString(4));
/* 2174 */     buf.append("\n\t- removal: ").append(getSeverityString(1082130432));
/* 2175 */     buf.append("\n\t- masked catch block: ").append(getSeverityString(8));
/* 2176 */     buf.append("\n\t- unused local variable: ").append(getSeverityString(16));
/* 2177 */     buf.append("\n\t- unused parameter: ").append(getSeverityString(32));
/* 2178 */     buf.append("\n\t- unused exception parameter: ").append(getSeverityString(1074003968));
/* 2179 */     buf.append("\n\t- unused import: ").append(getSeverityString(1024));
/* 2180 */     buf.append("\n\t- synthetic access emulation: ").append(getSeverityString(128));
/* 2181 */     buf.append("\n\t- assignment with no effect: ").append(getSeverityString(8192));
/* 2182 */     buf.append("\n\t- non externalized string: ").append(getSeverityString(256));
/* 2183 */     buf.append("\n\t- static access receiver: ").append(getSeverityString(2048));
/* 2184 */     buf.append("\n\t- indirect static access: ").append(getSeverityString(268435456));
/* 2185 */     buf.append("\n\t- incompatible non inherited interface method: ").append(getSeverityString(16384));
/* 2186 */     buf.append("\n\t- unused private member: ").append(getSeverityString(32768));
/* 2187 */     buf.append("\n\t- local variable hiding another variable: ").append(getSeverityString(65536));
/* 2188 */     buf.append("\n\t- field hiding another variable: ").append(getSeverityString(131072));
/* 2189 */     buf.append("\n\t- type hiding another type: ").append(getSeverityString(536871936));
/* 2190 */     buf.append("\n\t- possible accidental boolean assignment: ").append(getSeverityString(262144));
/* 2191 */     buf.append("\n\t- superfluous semicolon: ").append(getSeverityString(524288));
/* 2192 */     buf.append("\n\t- uncommented empty block: ").append(getSeverityString(134217728));
/* 2193 */     buf.append("\n\t- unnecessary type check: ").append(getSeverityString(67108864));
/* 2194 */     buf.append("\n\t- javadoc comment support: ").append(this.docCommentSupport ? "ON" : " OFF");
/* 2195 */     buf.append("\n\t\t+ invalid javadoc: ").append(getSeverityString(33554432));
/* 2196 */     buf.append("\n\t\t+ report invalid javadoc tags: ").append(this.reportInvalidJavadocTags ? "enabled" : "disabled");
/* 2197 */     buf.append("\n\t\t\t* deprecated references: ").append(this.reportInvalidJavadocTagsDeprecatedRef ? "enabled" : "disabled");
/* 2198 */     buf.append("\n\t\t\t* not visible references: ").append(this.reportInvalidJavadocTagsNotVisibleRef ? "enabled" : "disabled");
/* 2199 */     buf.append("\n\t\t+ visibility level to report invalid javadoc tags: ").append(getVisibilityString(this.reportInvalidJavadocTagsVisibility));
/* 2200 */     buf.append("\n\t\t+ missing javadoc tags: ").append(getSeverityString(2097152));
/* 2201 */     buf.append("\n\t\t+ visibility level to report missing javadoc tags: ").append(getVisibilityString(this.reportMissingJavadocTagsVisibility));
/* 2202 */     buf.append("\n\t\t+ report missing javadoc tags for method type parameters: ").append(this.reportMissingJavadocTagsMethodTypeParameters ? "enabled" : "disabled");
/* 2203 */     buf.append("\n\t\t+ report missing javadoc tags in overriding methods: ").append(this.reportMissingJavadocTagsOverriding ? "enabled" : "disabled");
/* 2204 */     buf.append("\n\t\t+ missing javadoc comments: ").append(getSeverityString(1048576));
/* 2205 */     buf.append("\n\t\t+ report missing tag description option: ").append(this.reportMissingJavadocTagDescription);
/* 2206 */     buf.append("\n\t\t+ visibility level to report missing javadoc comments: ").append(getVisibilityString(this.reportMissingJavadocCommentsVisibility));
/* 2207 */     buf.append("\n\t\t+ report missing javadoc comments in overriding methods: ").append(this.reportMissingJavadocCommentsOverriding ? "enabled" : "disabled");
/* 2208 */     buf.append("\n\t- finally block not completing normally: ").append(getSeverityString(16777216));
/* 2209 */     buf.append("\n\t- report unused declared thrown exception: ").append(getSeverityString(8388608));
/* 2210 */     buf.append("\n\t- report unused declared thrown exception when overriding: ").append(this.reportUnusedDeclaredThrownExceptionWhenOverriding ? "enabled" : "disabled");
/* 2211 */     buf.append("\n\t- report unused declared thrown exception include doc comment reference: ").append(this.reportUnusedDeclaredThrownExceptionIncludeDocCommentReference ? "enabled" : "disabled");
/* 2212 */     buf.append("\n\t- report unused declared thrown exception exempt exception and throwable: ").append(this.reportUnusedDeclaredThrownExceptionExemptExceptionAndThrowable ? "enabled" : "disabled");
/* 2213 */     buf.append("\n\t- unnecessary else: ").append(getSeverityString(536870913));
/* 2214 */     buf.append("\n\t- JDK compliance level: " + versionFromJdkLevel(this.complianceLevel));
/* 2215 */     buf.append("\n\t- JDK source level: " + versionFromJdkLevel(this.sourceLevel));
/* 2216 */     buf.append("\n\t- JDK target level: " + versionFromJdkLevel(this.targetJDK));
/* 2217 */     buf.append("\n\t- verbose : ").append(this.verbose ? "ON" : "OFF");
/* 2218 */     buf.append("\n\t- produce reference info : ").append(this.produceReferenceInfo ? "ON" : "OFF");
/* 2219 */     buf.append("\n\t- parse literal expressions as constants : ").append(this.parseLiteralExpressionsAsConstants ? "ON" : "OFF");
/* 2220 */     buf.append("\n\t- encoding : ").append((this.defaultEncoding == null) ? "<default>" : this.defaultEncoding);
/* 2221 */     buf.append("\n\t- task tags: ").append((this.taskTags == null) ? Util.EMPTY_STRING : new String(CharOperation.concatWith(this.taskTags, ',')));
/* 2222 */     buf.append("\n\t- task priorities : ").append((this.taskPriorities == null) ? Util.EMPTY_STRING : new String(CharOperation.concatWith(this.taskPriorities, ',')));
/* 2223 */     buf.append("\n\t- report deprecation inside deprecated code : ").append(this.reportDeprecationInsideDeprecatedCode ? "enabled" : "disabled");
/* 2224 */     buf.append("\n\t- report deprecation when overriding deprecated method : ").append(this.reportDeprecationWhenOverridingDeprecatedMethod ? "enabled" : "disabled");
/* 2225 */     buf.append("\n\t- report unused parameter when implementing abstract method : ").append(this.reportUnusedParameterWhenImplementingAbstract ? "enabled" : "disabled");
/* 2226 */     buf.append("\n\t- report unused parameter when overriding concrete method : ").append(this.reportUnusedParameterWhenOverridingConcrete ? "enabled" : "disabled");
/* 2227 */     buf.append("\n\t- report unused parameter include doc comment reference : ").append(this.reportUnusedParameterIncludeDocCommentReference ? "enabled" : "disabled");
/* 2228 */     buf.append("\n\t- report constructor/setter parameter hiding existing field : ").append(this.reportSpecialParameterHidingField ? "enabled" : "disabled");
/* 2229 */     buf.append("\n\t- inline JSR bytecode : ").append(this.inlineJsrBytecode ? "enabled" : "disabled");
/* 2230 */     buf.append("\n\t- share common finally blocks : ").append(this.shareCommonFinallyBlocks ? "enabled" : "disabled");
/* 2231 */     buf.append("\n\t- report unavoidable generic type problems : ").append(this.reportUnavoidableGenericTypeProblems ? "enabled" : "disabled");
/* 2232 */     buf.append("\n\t- unsafe type operation: ").append(getSeverityString(536870914));
/* 2233 */     buf.append("\n\t- unsafe raw type: ").append(getSeverityString(536936448));
/* 2234 */     buf.append("\n\t- final bound for type parameter: ").append(getSeverityString(536870916));
/* 2235 */     buf.append("\n\t- missing serialVersionUID: ").append(getSeverityString(536870920));
/* 2236 */     buf.append("\n\t- varargs argument need cast: ").append(getSeverityString(536870976));
/* 2237 */     buf.append("\n\t- forbidden reference to type with access restriction: ").append(getSeverityString(536870944));
/* 2238 */     buf.append("\n\t- discouraged reference to type with access restriction: ").append(getSeverityString(536887296));
/* 2239 */     buf.append("\n\t- null reference: ").append(getSeverityString(536871040));
/* 2240 */     buf.append("\n\t- potential null reference: ").append(getSeverityString(538968064));
/* 2241 */     buf.append("\n\t- redundant null check: ").append(getSeverityString(541065216));
/* 2242 */     buf.append("\n\t- autoboxing: ").append(getSeverityString(536871168));
/* 2243 */     buf.append("\n\t- annotation super interface: ").append(getSeverityString(536871424));
/* 2244 */     buf.append("\n\t- missing @Override annotation: ").append(getSeverityString(536872960));
/* 2245 */     buf.append("\n\t- missing @Override annotation for interface method implementation: ").append(this.reportMissingOverrideAnnotationForInterfaceMethodImplementation ? "enabled" : "disabled");
/* 2246 */     buf.append("\n\t- missing @Deprecated annotation: ").append(getSeverityString(536879104));
/* 2247 */     buf.append("\n\t- incomplete enum switch: ").append(getSeverityString(536875008));
/* 2248 */     buf.append("\n\t- raise null related warnings for variables tainted in assert statements: ").append(this.includeNullInfoFromAsserts ? "enabled" : "disabled");
/* 2249 */     buf.append("\n\t- suppress warnings: ").append(this.suppressWarnings ? "enabled" : "disabled");
/* 2250 */     buf.append("\n\t- suppress optional errors: ").append(this.suppressOptionalErrors ? "enabled" : "disabled");
/* 2251 */     buf.append("\n\t- unhandled warning token: ").append(getSeverityString(536903680));
/* 2252 */     buf.append("\n\t- unused warning token: ").append(getSeverityString(570425344));
/* 2253 */     buf.append("\n\t- unused label: ").append(getSeverityString(537001984));
/* 2254 */     buf.append("\n\t- treat optional error as fatal: ").append(this.treatOptionalErrorAsFatal ? "enabled" : "disabled");
/* 2255 */     buf.append("\n\t- parameter assignment: ").append(getSeverityString(537133056));
/* 2256 */     buf.append("\n\t- generate class files: ").append(this.generateClassFiles ? "enabled" : "disabled");
/* 2257 */     buf.append("\n\t- process annotations: ").append(this.processAnnotations ? "enabled" : "disabled");
/* 2258 */     buf.append("\n\t- unused type arguments for method/constructor invocation: ").append(getSeverityString(553648128));
/* 2259 */     buf.append("\n\t- redundant superinterface: ").append(getSeverityString(603979776));
/* 2260 */     buf.append("\n\t- comparing identical expr: ").append(getSeverityString(671088640));
/* 2261 */     buf.append("\n\t- missing synchronized on inherited method: ").append(getSeverityString(805306368));
/* 2262 */     buf.append("\n\t- should implement hashCode() method: ").append(getSeverityString(1073741825));
/* 2263 */     buf.append("\n\t- dead code: ").append(getSeverityString(1073741826));
/* 2264 */     buf.append("\n\t- dead code in trivial if statement: ").append(this.reportDeadCodeInTrivialIfStatement ? "enabled" : "disabled");
/* 2265 */     buf.append("\n\t- tasks severity: ").append(getSeverityString(1073741828));
/* 2266 */     buf.append("\n\t- unused object allocation: ").append(getSeverityString(1073741832));
/* 2267 */     buf.append("\n\t- method can be static: ").append(getSeverityString(1073741840));
/* 2268 */     buf.append("\n\t- method can be potentially static: ").append(getSeverityString(1073741856));
/* 2269 */     buf.append("\n\t- redundant specification of type arguments: ").append(getSeverityString(1073741888));
/* 2270 */     buf.append("\n\t- resource is not closed: ").append(getSeverityString(1073741952));
/* 2271 */     buf.append("\n\t- resource may not be closed: ").append(getSeverityString(1073742080));
/* 2272 */     buf.append("\n\t- resource should be handled by try-with-resources: ").append(getSeverityString(1073742336));
/* 2273 */     buf.append("\n\t- Unused Type Parameter: ").append(getSeverityString(1073807360));
/* 2274 */     buf.append("\n\t- pessimistic null analysis for free type variables: ").append(getSeverityString(1074266112));
/* 2275 */     buf.append("\n\t- report unsafe nonnull return from legacy method: ").append(getSeverityString(1074790400));
/* 2276 */     buf.append("\n\t- unlikely argument type for collection methods: ").append(getSeverityString(1075838976));
/* 2277 */     buf.append("\n\t- unlikely argument type for collection methods, strict check against expected type: ").append(this.reportUnlikelyCollectionMethodArgumentTypeStrict ? "enabled" : "disabled");
/* 2278 */     buf.append("\n\t- unlikely argument types for equals(): ").append(getSeverityString(1077936128));
/* 2279 */     buf.append("\n\t- API leak: ").append(getSeverityString(1090519040));
/* 2280 */     buf.append("\n\t- unstable auto module name: ").append(getSeverityString(1107296256));
/* 2281 */     buf.append("\n\t- SuppressWarnings not fully analysed: ").append(getSeverityString(1207959552));
/* 2282 */     buf.append("\n\t- ignore package from unnamed module: ").append(this.ignoreUnnamedModuleForSplitPackage ? "enabled" : "disabled");
/* 2283 */     return buf.toString();
/*      */   }
/*      */   
/*      */   protected void updateSeverity(int irritant, Object severityString) {
/* 2287 */     if ("error".equals(severityString)) {
/* 2288 */       this.errorThreshold.set(irritant);
/* 2289 */       this.warningThreshold.clear(irritant);
/* 2290 */       this.infoThreshold.clear(irritant);
/* 2291 */     } else if ("warning".equals(severityString)) {
/* 2292 */       this.errorThreshold.clear(irritant);
/* 2293 */       this.warningThreshold.set(irritant);
/* 2294 */       this.infoThreshold.clear(irritant);
/* 2295 */     } else if ("info".equals(severityString)) {
/* 2296 */       this.errorThreshold.clear(irritant);
/* 2297 */       this.warningThreshold.clear(irritant);
/* 2298 */       this.infoThreshold.set(irritant);
/* 2299 */     } else if ("ignore".equals(severityString)) {
/* 2300 */       this.errorThreshold.clear(irritant);
/* 2301 */       this.warningThreshold.clear(irritant);
/* 2302 */       this.infoThreshold.clear(irritant);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean usesNullTypeAnnotations() {
/* 2310 */     if (this.useNullTypeAnnotations != null)
/* 2311 */       return this.useNullTypeAnnotations.booleanValue(); 
/* 2312 */     return (this.isAnnotationBasedNullAnalysisEnabled && 
/* 2313 */       this.sourceLevel >= 3407872L);
/*      */   }
/*      */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\impl\CompilerOptions.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */