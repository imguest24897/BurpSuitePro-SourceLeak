/*    */ package org.eclipse.jdt.internal.compiler.ast;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class NumberLiteral
/*    */   extends Literal
/*    */ {
/*    */   char[] source;
/*    */   
/*    */   public NumberLiteral(char[] token, int s, int e) {
/* 21 */     this(s, e);
/* 22 */     this.source = token;
/*    */   }
/*    */   
/*    */   public NumberLiteral(int s, int e) {
/* 26 */     super(s, e);
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean isValidJavaStatement() {
/* 31 */     return false;
/*    */   }
/*    */ 
/*    */   
/*    */   public char[] source() {
/* 36 */     return this.source;
/*    */   }
/*    */   protected static char[] removePrefixZerosAndUnderscores(char[] token, boolean isLong) {
/* 39 */     int max = token.length;
/* 40 */     int start = 0;
/* 41 */     int end = max - 1;
/* 42 */     if (isLong) {
/* 43 */       end--;
/*    */     }
/* 45 */     if (max > 1 && token[0] == '0') {
/* 46 */       if (max > 2 && (token[1] == 'x' || token[1] == 'X')) {
/* 47 */         start = 2;
/* 48 */       } else if (max > 2 && (token[1] == 'b' || token[1] == 'B')) {
/* 49 */         start = 2;
/*    */       } else {
/* 51 */         start = 1;
/*    */       } 
/*    */     }
/* 54 */     boolean modified = false;
/* 55 */     boolean ignore = true;
/* 56 */     for (int i = start; i < max; i++) {
/* 57 */       char currentChar = token[i];
/* 58 */       switch (currentChar) {
/*    */         
/*    */         case '0':
/* 61 */           if (ignore && !modified && i < end) {
/* 62 */             modified = true;
/*    */           }
/*    */           break;
/*    */         case '_':
/* 66 */           modified = true;
/*    */           break;
/*    */         default:
/* 69 */           ignore = false; break;
/*    */       } 
/*    */     } 
/* 72 */     if (!modified) {
/* 73 */       return token;
/*    */     }
/* 75 */     ignore = true;
/* 76 */     StringBuilder buffer = new StringBuilder();
/* 77 */     buffer.append(token, 0, start);
/* 78 */     for (int j = start; j < max; j++) {
/* 79 */       char currentChar = token[j];
/* 80 */       switch (currentChar) {
/*    */         case '0':
/* 82 */           if (ignore && j < end) {
/*    */             break;
/*    */           }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */           
/* 92 */           buffer.append(currentChar); break;case '_': break;default: ignore = false; buffer.append(currentChar); break;
/*    */       } 
/* 94 */     }  return buffer.toString().toCharArray();
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\ast\NumberLiteral.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */