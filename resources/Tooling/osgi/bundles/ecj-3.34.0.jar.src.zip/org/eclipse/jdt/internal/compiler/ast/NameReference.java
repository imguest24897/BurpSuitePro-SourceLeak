/*     */ package org.eclipse.jdt.internal.compiler.ast;
/*     */ 
/*     */ import java.util.function.Predicate;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.Binding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.FieldBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.InferenceContext18;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.InvocationSite;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.ReferenceBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.Scope;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.TypeBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.VariableBinding;
/*     */ import org.eclipse.jdt.internal.compiler.problem.AbortMethod;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class NameReference
/*     */   extends Reference
/*     */   implements InvocationSite
/*     */ {
/*     */   public Binding binding;
/*     */   public TypeBinding actualReceiverType;
/*     */   
/*     */   public NameReference() {
/*  41 */     this.bits |= 0x7;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public FieldBinding fieldBinding() {
/*  53 */     return (FieldBinding)this.binding;
/*     */   }
/*     */ 
/*     */   
/*     */   public FieldBinding lastFieldBinding() {
/*  58 */     if ((this.bits & 0x7) == 1)
/*  59 */       return fieldBinding(); 
/*  60 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public InferenceContext18 freshInferenceContext(Scope scope) {
/*  65 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isSuperAccess() {
/*  70 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isTypeAccess() {
/*  76 */     return !(this.binding != null && (this.binding.kind() & 0x4) == 0);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isTypeReference() {
/*  81 */     return this.binding instanceof ReferenceBinding;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setActualReceiverType(ReferenceBinding receiverType) {
/*  86 */     if (receiverType == null)
/*  87 */       return;  this.actualReceiverType = (TypeBinding)receiverType;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setDepth(int depth) {
/*  92 */     this.bits &= 0xFFFFE01F;
/*  93 */     if (depth > 0) {
/*  94 */       this.bits |= (depth & 0xFF) << 5;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setFieldIndex(int index) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean checkEffectiveFinality(VariableBinding localBinding, Scope scope) {
/* 114 */     Predicate<VariableBinding> test = local -> 
/* 115 */       (!paramVariableBinding1.isFinal() && !paramVariableBinding1.isEffectivelyFinal());
/*     */     
/* 117 */     if ((this.bits & 0x80000) != 0) {
/* 118 */       if (test.test(localBinding)) {
/* 119 */         scope.problemReporter().cannotReferToNonEffectivelyFinalOuterLocal(localBinding, this);
/* 120 */         throw new AbortMethod((scope.referenceCompilationUnit()).compilationResult, null);
/*     */       } 
/* 122 */       return true;
/* 123 */     }  if ((this.bits & 0x40) != 0 && 
/* 124 */       test.test(localBinding)) {
/* 125 */       scope.problemReporter().cannotReferToNonFinalLocalInGuard(localBinding, this);
/* 126 */       throw new AbortMethod((scope.referenceCompilationUnit()).compilationResult, null);
/*     */     } 
/*     */     
/* 129 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isType() {
/* 134 */     return ((this.bits & 0x4) != 0);
/*     */   }
/*     */   
/*     */   public abstract String unboundReferenceErrorName();
/*     */   
/*     */   public abstract char[][] getName();
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\ast\NameReference.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */