/*     */ package org.eclipse.jdt.internal.compiler.ast;
/*     */ 
/*     */ import org.eclipse.jdt.internal.compiler.ASTVisitor;
/*     */ import org.eclipse.jdt.internal.compiler.codegen.CodeStream;
/*     */ import org.eclipse.jdt.internal.compiler.flow.FlowContext;
/*     */ import org.eclipse.jdt.internal.compiler.flow.FlowInfo;
/*     */ import org.eclipse.jdt.internal.compiler.impl.Constant;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.BlockScope;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.LocalVariableBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.MethodBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.MethodScope;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.Scope;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.TypeBinding;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ReturnStatement
/*     */   extends Statement
/*     */ {
/*     */   public Expression expression;
/*     */   public SubRoutineStatement[] subroutines;
/*     */   public LocalVariableBinding saveValueVariable;
/*  58 */   public int initStateIndex = -1;
/*     */   private boolean implicitReturn;
/*     */   
/*     */   public ReturnStatement(Expression expression, int sourceStart, int sourceEnd) {
/*  62 */     this(expression, sourceStart, sourceEnd, false);
/*     */   }
/*     */   
/*     */   public ReturnStatement(Expression expression, int sourceStart, int sourceEnd, boolean implicitReturn) {
/*  66 */     this.sourceStart = sourceStart;
/*  67 */     this.sourceEnd = sourceEnd;
/*  68 */     this.expression = expression;
/*  69 */     this.implicitReturn = implicitReturn;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public FlowInfo analyseCode(BlockScope currentScope, FlowContext flowContext, FlowInfo flowInfo) {
/*  78 */     if (this.expression instanceof FunctionalExpression && (
/*  79 */       this.expression.resolvedType == null || !this.expression.resolvedType.isValidBinding())) {
/*     */ 
/*     */ 
/*     */       
/*  83 */       flowContext.recordAbruptExit();
/*  84 */       return (FlowInfo)FlowInfo.DEAD_END;
/*     */     } 
/*     */ 
/*     */     
/*  88 */     MethodScope methodScope = currentScope.methodScope();
/*  89 */     if (this.expression != null) {
/*  90 */       flowInfo = this.expression.analyseCode(currentScope, flowContext, flowInfo);
/*  91 */       this.expression.checkNPEbyUnboxing(currentScope, flowContext, flowInfo);
/*  92 */       if (flowInfo.reachMode() == 0 && (currentScope.compilerOptions()).isAnnotationBasedNullAnalysisEnabled)
/*  93 */         checkAgainstNullAnnotation(currentScope, flowContext, flowInfo, this.expression); 
/*  94 */       if ((currentScope.compilerOptions()).analyseResourceLeaks) {
/*  95 */         FakedTrackingVariable trackingVariable = FakedTrackingVariable.getCloseTrackingVariable(this.expression, flowInfo, flowContext);
/*  96 */         if (trackingVariable != null) {
/*  97 */           if (methodScope != trackingVariable.methodScope) {
/*  98 */             trackingVariable.markClosedInNestedMethod();
/*     */           }
/* 100 */           flowInfo = FakedTrackingVariable.markPassedToOutside(currentScope, this.expression, flowInfo, flowContext, true);
/*     */         } 
/*     */         
/* 103 */         FakedTrackingVariable.cleanUpUnassigned(currentScope, this.expression, flowInfo);
/*     */       } 
/*     */     } 
/* 106 */     this.initStateIndex = 
/* 107 */       methodScope.recordInitializationStates(flowInfo);
/*     */     
/* 109 */     FlowContext traversedContext = flowContext;
/* 110 */     int subCount = 0;
/* 111 */     boolean saveValueNeeded = false;
/* 112 */     boolean hasValueToSave = needValueStore();
/* 113 */     boolean noAutoCloseables = true;
/*     */     do {
/*     */       SubRoutineStatement sub;
/* 116 */       if ((sub = traversedContext.subroutine()) != null) {
/* 117 */         if (this.subroutines == null) {
/* 118 */           this.subroutines = new SubRoutineStatement[5];
/*     */         }
/* 120 */         if (subCount == this.subroutines.length) {
/* 121 */           System.arraycopy(this.subroutines, 0, this.subroutines = new SubRoutineStatement[subCount * 2], 0, subCount);
/*     */         }
/* 123 */         this.subroutines[subCount++] = sub;
/* 124 */         if (sub.isSubRoutineEscaping()) {
/* 125 */           saveValueNeeded = false;
/* 126 */           this.bits |= 0x20000000;
/*     */           break;
/*     */         } 
/* 129 */         if (sub instanceof TryStatement && 
/* 130 */           ((TryStatement)sub).resources.length > 0) {
/* 131 */           noAutoCloseables = false;
/*     */         }
/*     */       } 
/*     */       
/* 135 */       traversedContext.recordReturnFrom(flowInfo.unconditionalInits());
/*     */       
/* 137 */       if (traversedContext instanceof org.eclipse.jdt.internal.compiler.flow.InsideSubRoutineFlowContext) {
/* 138 */         ASTNode node = traversedContext.associatedNode;
/* 139 */         if (node instanceof SynchronizedStatement) {
/* 140 */           this.bits |= 0x40000000;
/* 141 */         } else if (node instanceof TryStatement) {
/* 142 */           TryStatement tryStatement = (TryStatement)node;
/* 143 */           flowInfo.addInitializationsFrom((FlowInfo)tryStatement.subRoutineInits);
/* 144 */           if (hasValueToSave) {
/* 145 */             if (this.saveValueVariable == null) {
/* 146 */               prepareSaveValueLocation(tryStatement);
/*     */             }
/* 148 */             saveValueNeeded = true;
/* 149 */             this.initStateIndex = 
/* 150 */               methodScope.recordInitializationStates(flowInfo);
/*     */           } 
/*     */         } 
/* 153 */       } else if (traversedContext instanceof org.eclipse.jdt.internal.compiler.flow.InitializationFlowContext) {
/* 154 */         currentScope.problemReporter().cannotReturnInInitializer(this);
/* 155 */         return (FlowInfo)FlowInfo.DEAD_END;
/*     */       } 
/* 157 */     } while ((traversedContext = traversedContext.getLocalParent()) != null);
/*     */ 
/*     */     
/* 160 */     if (this.subroutines != null && subCount != this.subroutines.length) {
/* 161 */       System.arraycopy(this.subroutines, 0, this.subroutines = new SubRoutineStatement[subCount], 0, subCount);
/*     */     }
/*     */ 
/*     */     
/* 165 */     if (saveValueNeeded) {
/* 166 */       if (this.saveValueVariable != null) {
/* 167 */         this.saveValueVariable.useFlag = 1;
/*     */       }
/*     */     } else {
/* 170 */       this.saveValueVariable = null;
/* 171 */       if ((this.bits & 0x40000000) == 0 && this.expression != null && TypeBinding.equalsEquals(this.expression.resolvedType, (TypeBinding)TypeBinding.BOOLEAN) && 
/* 172 */         noAutoCloseables) {
/* 173 */         this.expression.bits |= 0x10;
/*     */       }
/*     */     } 
/*     */     
/* 177 */     currentScope.checkUnclosedCloseables(flowInfo, flowContext, this, currentScope);
/*     */     
/* 179 */     flowContext.recordAbruptExit();
/* 180 */     flowContext.expireNullCheckedFieldInfo();
/* 181 */     return (FlowInfo)FlowInfo.DEAD_END;
/*     */   }
/*     */   
/*     */   public boolean doesNotCompleteNormally() {
/* 185 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean canCompleteNormally() {
/* 190 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void generateCode(BlockScope currentScope, CodeStream codeStream) {
/* 203 */     if ((this.bits & Integer.MIN_VALUE) == 0) {
/*     */       return;
/*     */     }
/* 206 */     int pc = codeStream.position;
/* 207 */     boolean alreadyGeneratedExpression = false;
/*     */     
/* 209 */     if (needValueStore()) {
/* 210 */       alreadyGeneratedExpression = true;
/* 211 */       this.expression.generateCode(currentScope, codeStream, needValue());
/* 212 */       generateStoreSaveValueIfNecessary((Scope)currentScope, codeStream);
/*     */     } 
/*     */ 
/*     */     
/* 216 */     if (this.subroutines != null) {
/* 217 */       Object reusableJSRTarget = (this.expression == null) ? TypeBinding.VOID : this.expression.reusableJSRTarget();
/* 218 */       for (int i = 0, max = this.subroutines.length; i < max; i++) {
/* 219 */         SubRoutineStatement sub = this.subroutines[i];
/* 220 */         boolean didEscape = sub.generateSubRoutineInvocation(currentScope, codeStream, reusableJSRTarget, this.initStateIndex, this.saveValueVariable);
/* 221 */         if (didEscape) {
/* 222 */           codeStream.recordPositionsFrom(pc, this.sourceStart);
/* 223 */           SubRoutineStatement.reenterAllExceptionHandlers(this.subroutines, i, codeStream);
/*     */           return;
/*     */         } 
/*     */       } 
/*     */     } 
/* 228 */     if (this.saveValueVariable != null) {
/* 229 */       codeStream.load(this.saveValueVariable);
/*     */     }
/* 231 */     if (this.expression != null && !alreadyGeneratedExpression) {
/* 232 */       this.expression.generateCode(currentScope, codeStream, true);
/*     */       
/* 234 */       generateStoreSaveValueIfNecessary((Scope)currentScope, codeStream);
/*     */     } 
/*     */     
/* 237 */     generateReturnBytecode(codeStream);
/* 238 */     if (this.saveValueVariable != null) {
/* 239 */       codeStream.removeVariable(this.saveValueVariable);
/*     */     }
/* 241 */     if (this.initStateIndex != -1) {
/* 242 */       codeStream.removeNotDefinitelyAssignedVariables((Scope)currentScope, this.initStateIndex);
/* 243 */       codeStream.addDefinitelyAssignedVariables((Scope)currentScope, this.initStateIndex);
/*     */     } 
/* 245 */     codeStream.recordPositionsFrom(pc, this.sourceStart);
/* 246 */     SubRoutineStatement.reenterAllExceptionHandlers(this.subroutines, -1, codeStream);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void generateReturnBytecode(CodeStream codeStream) {
/* 254 */     codeStream.generateReturnBytecode(this.expression);
/*     */   }
/*     */   
/*     */   public void generateStoreSaveValueIfNecessary(Scope scope, CodeStream codeStream) {
/* 258 */     if (this.saveValueVariable != null) {
/* 259 */       codeStream.store(this.saveValueVariable, false);
/*     */       
/* 261 */       codeStream.addVariable(this.saveValueVariable);
/*     */     } 
/*     */   }
/*     */   
/*     */   private boolean needValueStore() {
/* 266 */     return (this.expression != null && (
/* 267 */       this.expression.constant == Constant.NotAConstant || (this.expression.implicitConversion & 0x200) != 0) && 
/* 268 */       !(this.expression instanceof NullLiteral));
/*     */   }
/*     */   
/*     */   public boolean needValue() {
/* 272 */     return !(this.saveValueVariable == null && (
/* 273 */       this.bits & 0x40000000) == 0 && (
/* 274 */       this.bits & 0x20000000) != 0);
/*     */   }
/*     */   
/*     */   public void prepareSaveValueLocation(TryStatement targetTryStatement) {
/* 278 */     this.saveValueVariable = targetTryStatement.secretReturnValue;
/*     */   }
/*     */ 
/*     */   
/*     */   public StringBuffer printStatement(int tab, StringBuffer output) {
/* 283 */     printIndent(tab, output).append("return ");
/* 284 */     if (this.expression != null)
/* 285 */       this.expression.printExpression(0, output); 
/* 286 */     return output.append(';');
/*     */   }
/*     */ 
/*     */   
/*     */   public void resolve(BlockScope scope) {
/* 291 */     MethodScope methodScope = scope.methodScope();
/* 292 */     MethodBinding methodBinding = null;
/* 293 */     LambdaExpression lambda = (methodScope.referenceContext instanceof LambdaExpression) ? (LambdaExpression)methodScope.referenceContext : null;
/* 294 */     TypeBinding methodType = 
/* 295 */       (lambda != null) ? lambda.expectedResultType() : (
/* 296 */       (methodScope.referenceContext instanceof AbstractMethodDeclaration) ? (
/* 297 */       ((methodBinding = ((AbstractMethodDeclaration)methodScope.referenceContext).binding) == null) ? 
/* 298 */       null : 
/* 299 */       methodBinding.returnType) : 
/* 300 */       (TypeBinding)TypeBinding.VOID);
/*     */ 
/*     */     
/* 303 */     if (methodBinding != null && methodBinding.isCompactConstructor()) {
/* 304 */       scope.problemReporter().recordCompactConstructorHasReturnStatement(this);
/*     */     }
/* 306 */     if (this.expression != null) {
/* 307 */       this.expression.setExpressionContext(ExpressionContext.ASSIGNMENT_CONTEXT);
/* 308 */       this.expression.setExpectedType(methodType);
/* 309 */       if (lambda != null && lambda.argumentsTypeElided() && this.expression instanceof CastExpression) {
/* 310 */         this.expression.bits |= 0x20;
/*     */       }
/*     */     } 
/*     */     
/* 314 */     if (methodType == TypeBinding.VOID) {
/*     */       
/* 316 */       if (this.expression == null) {
/* 317 */         if (lambda != null)
/* 318 */           lambda.returnsExpression(null, (TypeBinding)TypeBinding.VOID); 
/*     */         return;
/*     */       } 
/* 321 */       TypeBinding typeBinding = this.expression.resolveType(scope);
/* 322 */       if (lambda != null)
/* 323 */         lambda.returnsExpression(this.expression, typeBinding); 
/* 324 */       if (this.implicitReturn && (typeBinding == TypeBinding.VOID || this.expression.statementExpression()))
/*     */         return; 
/* 326 */       if (typeBinding != null)
/* 327 */         scope.problemReporter().attemptToReturnNonVoidExpression(this, typeBinding); 
/*     */       return;
/*     */     } 
/* 330 */     if (this.expression == null) {
/* 331 */       if (lambda != null)
/* 332 */         lambda.returnsExpression(null, methodType); 
/* 333 */       if (methodType != null) scope.problemReporter().shouldReturn(methodType, this);
/*     */       
/*     */       return;
/*     */     } 
/* 337 */     TypeBinding expressionType = this.expression.resolveType(scope);
/* 338 */     if (lambda != null) {
/* 339 */       lambda.returnsExpression(this.expression, expressionType);
/*     */     }
/* 341 */     if (expressionType == null)
/* 342 */       return;  if (expressionType == TypeBinding.VOID) {
/* 343 */       scope.problemReporter().attemptToReturnVoidValue(this);
/*     */       return;
/*     */     } 
/* 346 */     if (methodType == null) {
/*     */       return;
/*     */     }
/* 349 */     if (lambda != null && methodType.isProperType(true))
/*     */     {
/* 351 */       if (lambda.updateLocalTypes())
/* 352 */         methodType = lambda.expectedResultType(); 
/*     */     }
/* 354 */     if (TypeBinding.notEquals(methodType, expressionType))
/* 355 */       scope.compilationUnitScope().recordTypeConversion(methodType, expressionType); 
/* 356 */     if (this.expression.isConstantValueOfTypeAssignableToType(expressionType, methodType) || 
/* 357 */       expressionType.isCompatibleWith(methodType, (Scope)scope)) {
/*     */       
/* 359 */       this.expression.computeConversion((Scope)scope, methodType, expressionType);
/* 360 */       if (expressionType.needsUncheckedConversion(methodType)) {
/* 361 */         scope.problemReporter().unsafeTypeConversion(this.expression, expressionType, methodType);
/*     */       }
/* 363 */       if (this.expression instanceof CastExpression) {
/* 364 */         if ((this.expression.bits & 0x4020) == 0) {
/* 365 */           CastExpression.checkNeedForAssignedCast(scope, methodType, (CastExpression)this.expression);
/* 366 */         } else if (lambda != null && lambda.argumentsTypeElided() && (this.expression.bits & 0x4000) != 0 && 
/* 367 */           TypeBinding.equalsEquals(((CastExpression)this.expression).expression.resolvedType, methodType)) {
/* 368 */           scope.problemReporter().unnecessaryCast((CastExpression)this.expression);
/*     */         } 
/*     */       }
/*     */       return;
/*     */     } 
/* 373 */     if (isBoxingCompatible(expressionType, methodType, this.expression, (Scope)scope)) {
/* 374 */       this.expression.computeConversion((Scope)scope, methodType, expressionType);
/* 375 */       if (this.expression instanceof CastExpression && (
/* 376 */         this.expression.bits & 0x4020) == 0)
/* 377 */         CastExpression.checkNeedForAssignedCast(scope, methodType, (CastExpression)this.expression); 
/*     */       return;
/*     */     } 
/* 380 */     if ((methodType.tagBits & 0x80L) == 0L)
/*     */     {
/* 382 */       scope.problemReporter().typeMismatchError(expressionType, methodType, this.expression, this);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void traverse(ASTVisitor visitor, BlockScope scope) {
/* 388 */     if (visitor.visit(this, scope) && 
/* 389 */       this.expression != null) {
/* 390 */       this.expression.traverse(visitor, scope);
/*     */     }
/* 392 */     visitor.endVisit(this, scope);
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\ast\ReturnStatement.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */