/*    */ package org.eclipse.jdt.internal.compiler.lookup;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AptSourceLocalVariableBinding
/*    */   extends LocalVariableBinding
/*    */ {
/*    */   public MethodBinding methodBinding;
/*    */   private LocalVariableBinding local;
/*    */   
/*    */   public AptSourceLocalVariableBinding(LocalVariableBinding localVariableBinding, MethodBinding methodBinding) {
/* 23 */     super(localVariableBinding.name, localVariableBinding.type, localVariableBinding.modifiers, true);
/* 24 */     this.constant = localVariableBinding.constant;
/* 25 */     this.declaration = localVariableBinding.declaration;
/* 26 */     this.declaringScope = localVariableBinding.declaringScope;
/* 27 */     this.id = localVariableBinding.id;
/* 28 */     this.resolvedPosition = localVariableBinding.resolvedPosition;
/* 29 */     this.tagBits = localVariableBinding.tagBits;
/* 30 */     this.useFlag = localVariableBinding.useFlag;
/* 31 */     this.initializationCount = localVariableBinding.initializationCount;
/* 32 */     this.initializationPCs = localVariableBinding.initializationPCs;
/* 33 */     this.methodBinding = methodBinding;
/* 34 */     this.local = localVariableBinding;
/*    */   }
/*    */ 
/*    */   
/*    */   public AnnotationBinding[] getAnnotations() {
/* 39 */     return this.local.getAnnotations();
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\lookup\AptSourceLocalVariableBinding.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */