/*     */ package org.eclipse.jdt.internal.compiler.ast;
/*     */ 
/*     */ import org.eclipse.jdt.internal.compiler.ASTVisitor;
/*     */ import org.eclipse.jdt.internal.compiler.impl.Constant;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.ArrayBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.BlockScope;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.ClassScope;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.Scope;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.TypeBinding;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JavadocImplicitTypeReference
/*     */   extends TypeReference
/*     */ {
/*     */   public char[] token;
/*     */   
/*     */   public JavadocImplicitTypeReference(char[] name, int pos) {
/*  28 */     this.token = name;
/*  29 */     this.sourceStart = pos;
/*  30 */     this.sourceEnd = pos;
/*     */   }
/*     */ 
/*     */   
/*     */   public TypeReference augmentTypeWithAdditionalDimensions(int additionalDimensions, Annotation[][] additionalAnnotations, boolean isVarargs) {
/*  35 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   protected TypeBinding getTypeBinding(Scope scope) {
/*  40 */     this.constant = Constant.NotAConstant;
/*  41 */     return this.resolvedType = (TypeBinding)scope.enclosingReceiverType();
/*     */   }
/*     */ 
/*     */   
/*     */   public char[] getLastToken() {
/*  46 */     return this.token;
/*     */   }
/*     */ 
/*     */   
/*     */   public char[][] getTypeName() {
/*  51 */     if (this.token != null) {
/*  52 */       char[][] tokens = { this.token };
/*  53 */       return tokens;
/*     */     } 
/*  55 */     return null;
/*     */   }
/*     */   
/*     */   public boolean isThis() {
/*  59 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected TypeBinding internalResolveType(Scope scope, int location) {
/*  69 */     this.constant = Constant.NotAConstant;
/*  70 */     if (this.resolvedType != null) {
/*  71 */       TypeBinding typeBinding; if (this.resolvedType.isValidBinding()) {
/*  72 */         return this.resolvedType;
/*     */       }
/*  74 */       switch (this.resolvedType.problemId()) {
/*     */         case 1:
/*     */         case 2:
/*  77 */           typeBinding = this.resolvedType.closestMatch();
/*  78 */           return typeBinding;
/*     */       } 
/*  80 */       return null;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/*  85 */     TypeBinding type = this.resolvedType = getTypeBinding(scope);
/*  86 */     if (type == null)
/*  87 */       return null;  boolean hasError;
/*  88 */     if (hasError = !type.isValidBinding()) {
/*  89 */       reportInvalidType(scope);
/*  90 */       switch (type.problemId()) {
/*     */         case 1:
/*     */         case 2:
/*  93 */           type = type.closestMatch();
/*  94 */           if (type == null) return null; 
/*     */           break;
/*     */         default:
/*  97 */           return null;
/*     */       } 
/*     */     } 
/* 100 */     if (type.isArrayType() && ((ArrayBinding)type).leafComponentType == TypeBinding.VOID) {
/* 101 */       scope.problemReporter().cannotAllocateVoidArray(this);
/* 102 */       return null;
/*     */     } 
/* 104 */     if (isTypeUseDeprecated(type, scope)) {
/* 105 */       reportDeprecatedType(type, scope);
/*     */     }
/*     */ 
/*     */     
/* 109 */     if (type.isGenericType() || type.isParameterizedType()) {
/* 110 */       type = scope.environment().convertToRawType(type, true);
/*     */     }
/*     */     
/* 113 */     if (hasError)
/*     */     {
/* 115 */       return type;
/*     */     }
/* 117 */     return this.resolvedType = type;
/*     */   }
/*     */ 
/*     */   
/*     */   protected void reportInvalidType(Scope scope) {
/* 122 */     scope.problemReporter().javadocInvalidType(this, this.resolvedType, scope.getDeclarationModifiers());
/*     */   }
/*     */   
/*     */   protected void reportDeprecatedType(TypeBinding type, Scope scope) {
/* 126 */     scope.problemReporter().javadocDeprecatedType(type, this, scope.getDeclarationModifiers());
/*     */   }
/*     */ 
/*     */   
/*     */   public void traverse(ASTVisitor visitor, BlockScope scope) {
/* 131 */     visitor.visit(this, scope);
/* 132 */     visitor.endVisit(this, scope);
/*     */   }
/*     */ 
/*     */   
/*     */   public void traverse(ASTVisitor visitor, ClassScope scope) {
/* 137 */     visitor.visit(this, scope);
/* 138 */     visitor.endVisit(this, scope);
/*     */   }
/*     */ 
/*     */   
/*     */   public StringBuffer printExpression(int indent, StringBuffer output) {
/* 143 */     return new StringBuffer();
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\ast\JavadocImplicitTypeReference.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */