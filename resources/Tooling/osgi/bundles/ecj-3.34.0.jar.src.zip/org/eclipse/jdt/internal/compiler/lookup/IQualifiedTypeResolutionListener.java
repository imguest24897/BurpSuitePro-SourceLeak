package org.eclipse.jdt.internal.compiler.lookup;

import org.eclipse.jdt.internal.compiler.ast.QualifiedTypeReference;

public interface IQualifiedTypeResolutionListener {
  void recordResolution(QualifiedTypeReference paramQualifiedTypeReference, TypeBinding paramTypeBinding);
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\lookup\IQualifiedTypeResolutionListener.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */