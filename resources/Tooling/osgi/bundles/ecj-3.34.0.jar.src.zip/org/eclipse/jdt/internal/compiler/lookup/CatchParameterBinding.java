/*    */ package org.eclipse.jdt.internal.compiler.lookup;
/*    */ 
/*    */ import org.eclipse.jdt.internal.compiler.ast.LocalDeclaration;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CatchParameterBinding
/*    */   extends LocalVariableBinding
/*    */ {
/* 20 */   TypeBinding[] preciseTypes = (TypeBinding[])Binding.NO_EXCEPTIONS;
/*    */   
/*    */   public CatchParameterBinding(LocalDeclaration declaration, TypeBinding type, int modifiers, boolean isArgument) {
/* 23 */     super(declaration, type, modifiers, isArgument);
/*    */   }
/*    */   
/*    */   public TypeBinding[] getPreciseTypes() {
/* 27 */     return this.preciseTypes;
/*    */   }
/*    */   
/*    */   public void setPreciseType(TypeBinding raisedException) {
/* 31 */     int length = this.preciseTypes.length;
/* 32 */     for (int i = 0; i < length; i++) {
/* 33 */       if (TypeBinding.equalsEquals(this.preciseTypes[i], raisedException))
/*    */         return; 
/*    */     } 
/* 36 */     System.arraycopy(this.preciseTypes, 0, this.preciseTypes = new TypeBinding[length + 1], 0, length);
/* 37 */     this.preciseTypes[length] = raisedException;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean isCatchParameter() {
/* 42 */     return true;
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\lookup\CatchParameterBinding.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */