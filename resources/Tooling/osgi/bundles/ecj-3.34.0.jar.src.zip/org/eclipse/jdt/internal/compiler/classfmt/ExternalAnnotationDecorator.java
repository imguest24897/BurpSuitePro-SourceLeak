/*     */ package org.eclipse.jdt.internal.compiler.classfmt;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.FileNotFoundException;
/*     */ import java.io.IOException;
/*     */ import java.net.URI;
/*     */ import java.util.zip.ZipEntry;
/*     */ import java.util.zip.ZipFile;
/*     */ import org.eclipse.jdt.internal.compiler.env.IBinaryAnnotation;
/*     */ import org.eclipse.jdt.internal.compiler.env.IBinaryField;
/*     */ import org.eclipse.jdt.internal.compiler.env.IBinaryMethod;
/*     */ import org.eclipse.jdt.internal.compiler.env.IBinaryNestedType;
/*     */ import org.eclipse.jdt.internal.compiler.env.IBinaryType;
/*     */ import org.eclipse.jdt.internal.compiler.env.IBinaryTypeAnnotation;
/*     */ import org.eclipse.jdt.internal.compiler.env.IRecordComponent;
/*     */ import org.eclipse.jdt.internal.compiler.env.ITypeAnnotationWalker;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.BinaryTypeBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.LookupEnvironment;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.TypeConstants;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ExternalAnnotationDecorator
/*     */   implements IBinaryType
/*     */ {
/*     */   private IBinaryType inputType;
/*     */   private ExternalAnnotationProvider annotationProvider;
/*     */   private boolean isFromSource;
/*     */   
/*     */   public ExternalAnnotationDecorator(IBinaryType toDecorate, ExternalAnnotationProvider externalAnnotationProvider) {
/*  50 */     if (toDecorate == null) {
/*  51 */       throw new NullPointerException("toDecorate");
/*     */     }
/*  53 */     this.inputType = toDecorate;
/*  54 */     this.annotationProvider = externalAnnotationProvider;
/*     */   }
/*     */   
/*     */   public ExternalAnnotationDecorator(IBinaryType toDecorate, boolean isFromSource) {
/*  58 */     if (toDecorate == null) {
/*  59 */       throw new NullPointerException("toDecorate");
/*     */     }
/*  61 */     this.isFromSource = isFromSource;
/*  62 */     this.inputType = toDecorate;
/*     */   }
/*     */ 
/*     */   
/*     */   public char[] getFileName() {
/*  67 */     return this.inputType.getFileName();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isBinaryType() {
/*  72 */     return this.inputType.isBinaryType();
/*     */   }
/*     */ 
/*     */   
/*     */   public IBinaryAnnotation[] getAnnotations() {
/*  77 */     return this.inputType.getAnnotations();
/*     */   }
/*     */ 
/*     */   
/*     */   public IBinaryTypeAnnotation[] getTypeAnnotations() {
/*  82 */     return this.inputType.getTypeAnnotations();
/*     */   }
/*     */ 
/*     */   
/*     */   public char[] getEnclosingMethod() {
/*  87 */     return this.inputType.getEnclosingMethod();
/*     */   }
/*     */ 
/*     */   
/*     */   public char[] getEnclosingTypeName() {
/*  92 */     return this.inputType.getEnclosingTypeName();
/*     */   }
/*     */ 
/*     */   
/*     */   public IBinaryField[] getFields() {
/*  97 */     return this.inputType.getFields();
/*     */   }
/*     */ 
/*     */   
/*     */   public IRecordComponent[] getRecordComponents() {
/* 102 */     return this.inputType.getRecordComponents();
/*     */   }
/*     */ 
/*     */   
/*     */   public char[] getGenericSignature() {
/* 107 */     return this.inputType.getGenericSignature();
/*     */   }
/*     */ 
/*     */   
/*     */   public char[][] getInterfaceNames() {
/* 112 */     return this.inputType.getInterfaceNames();
/*     */   }
/*     */ 
/*     */   
/*     */   public IBinaryNestedType[] getMemberTypes() {
/* 117 */     return this.inputType.getMemberTypes();
/*     */   }
/*     */ 
/*     */   
/*     */   public IBinaryMethod[] getMethods() {
/* 122 */     return this.inputType.getMethods();
/*     */   }
/*     */ 
/*     */   
/*     */   public char[][][] getMissingTypeNames() {
/* 127 */     return this.inputType.getMissingTypeNames();
/*     */   }
/*     */ 
/*     */   
/*     */   public char[] getName() {
/* 132 */     return this.inputType.getName();
/*     */   }
/*     */ 
/*     */   
/*     */   public char[] getSourceName() {
/* 137 */     return this.inputType.getSourceName();
/*     */   }
/*     */ 
/*     */   
/*     */   public char[] getSuperclassName() {
/* 142 */     return this.inputType.getSuperclassName();
/*     */   }
/*     */ 
/*     */   
/*     */   public long getTagBits() {
/* 147 */     return this.inputType.getTagBits();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isAnonymous() {
/* 152 */     return this.inputType.isAnonymous();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isLocal() {
/* 157 */     return this.inputType.isLocal();
/*     */   }
/*     */   
/*     */   public boolean isRecord() {
/* 161 */     return this.inputType.isRecord();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isMember() {
/* 166 */     return this.inputType.isMember();
/*     */   }
/*     */ 
/*     */   
/*     */   public char[] sourceFileName() {
/* 171 */     return this.inputType.sourceFileName();
/*     */   }
/*     */ 
/*     */   
/*     */   public int getModifiers() {
/* 176 */     return this.inputType.getModifiers();
/*     */   }
/*     */ 
/*     */   
/*     */   public char[] getModule() {
/* 181 */     return this.inputType.getModule();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ZipFile getAnnotationZipFile(String basePath, ZipFileProducer producer) throws IOException {
/* 200 */     File annotationBase = new File(basePath);
/* 201 */     if (!annotationBase.isFile()) {
/* 202 */       return null;
/*     */     }
/* 204 */     return (producer != null) ? producer.produce() : new ZipFile(annotationBase);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ExternalAnnotationProvider externalAnnotationProvider(String basePath, String qualifiedBinaryTypeName, ZipFile zipFile) throws IOException {
/* 225 */     String qualifiedBinaryFileName = String.valueOf(qualifiedBinaryTypeName) + ".eea";
/* 226 */     if (zipFile == null) {
/* 227 */       File annotationBase = new File(basePath);
/* 228 */       if (annotationBase.isDirectory()) {
/* 229 */         String filePath = String.valueOf(annotationBase.getAbsolutePath()) + '/' + qualifiedBinaryFileName;
/*     */         try {
/* 231 */           return new ExternalAnnotationProvider(new FileInputStream(filePath), qualifiedBinaryTypeName);
/* 232 */         } catch (FileNotFoundException fileNotFoundException) {
/*     */           
/* 234 */           return null;
/*     */         } 
/*     */       } 
/*     */     } else {
/* 238 */       ZipEntry entry = zipFile.getEntry(qualifiedBinaryFileName);
/* 239 */       if (entry != null) {
/* 240 */         Exception exception1 = null, exception2 = null; try {  }
/*     */         finally
/* 242 */         { exception2 = null; if (exception1 == null) { exception1 = exception2; } else if (exception1 != exception2) { exception1.addSuppressed(exception2); }  }
/*     */       
/*     */       } 
/* 245 */     }  return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static IBinaryType create(IBinaryType toDecorate, String basePath, String qualifiedBinaryTypeName, ZipFile zipFile) throws IOException {
/* 271 */     ExternalAnnotationProvider externalAnnotationProvider = externalAnnotationProvider(basePath, qualifiedBinaryTypeName, zipFile);
/* 272 */     if (externalAnnotationProvider == null)
/* 273 */       return toDecorate; 
/* 274 */     return new ExternalAnnotationDecorator(toDecorate, externalAnnotationProvider);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ITypeAnnotationWalker enrichWithExternalAnnotationsFor(ITypeAnnotationWalker walker, Object member, LookupEnvironment environment) {
/* 280 */     if (walker == ITypeAnnotationWalker.EMPTY_ANNOTATION_WALKER && this.annotationProvider != null) {
/* 281 */       if (member == null)
/* 282 */         return this.annotationProvider.forTypeHeader(environment); 
/* 283 */       if (member instanceof IBinaryField) {
/* 284 */         IBinaryField field = (IBinaryField)member;
/* 285 */         char[] fieldSignature = field.getGenericSignature();
/* 286 */         if (fieldSignature == null)
/* 287 */           fieldSignature = field.getTypeName(); 
/* 288 */         return this.annotationProvider.forField(field.getName(), fieldSignature, environment);
/* 289 */       }  if (member instanceof IBinaryMethod) {
/* 290 */         IBinaryMethod method = (IBinaryMethod)member;
/* 291 */         char[] methodSignature = method.getGenericSignature();
/* 292 */         if (methodSignature == null)
/* 293 */           methodSignature = method.getMethodDescriptor(); 
/* 294 */         return this.annotationProvider.forMethod(
/* 295 */             method.isConstructor() ? TypeConstants.INIT : method.getSelector(), methodSignature, 
/* 296 */             environment);
/*     */       } 
/*     */     } 
/* 299 */     return walker;
/*     */   }
/*     */ 
/*     */   
/*     */   public BinaryTypeBinding.ExternalAnnotationStatus getExternalAnnotationStatus() {
/* 304 */     if (this.annotationProvider == null) {
/* 305 */       if (this.isFromSource) {
/* 306 */         return BinaryTypeBinding.ExternalAnnotationStatus.FROM_SOURCE;
/*     */       }
/* 308 */       return BinaryTypeBinding.ExternalAnnotationStatus.NO_EEA_FILE;
/*     */     } 
/* 310 */     return BinaryTypeBinding.ExternalAnnotationStatus.TYPE_IS_ANNOTATED;
/*     */   }
/*     */ 
/*     */   
/*     */   public URI getURI() {
/* 315 */     return this.inputType.getURI();
/*     */   }
/*     */   
/*     */   public static interface ZipFileProducer {
/*     */     ZipFile produce() throws IOException;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\classfmt\ExternalAnnotationDecorator.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */