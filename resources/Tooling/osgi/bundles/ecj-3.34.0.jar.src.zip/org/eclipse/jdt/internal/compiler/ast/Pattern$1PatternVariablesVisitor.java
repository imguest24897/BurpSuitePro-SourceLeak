/*    */ package org.eclipse.jdt.internal.compiler.ast;
/*    */ 
/*    */ import org.eclipse.jdt.internal.compiler.ASTVisitor;
/*    */ import org.eclipse.jdt.internal.compiler.lookup.BlockScope;
/*    */ import org.eclipse.jdt.internal.compiler.lookup.Scope;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class PatternVariablesVisitor
/*    */   extends ASTVisitor
/*    */ {
/*    */   public boolean hasPatternVar = false;
/*    */   public boolean typeElidedVar = false;
/*    */   
/*    */   public boolean visit(TypePattern typePattern, BlockScope blockScope) {
/* 49 */     this.hasPatternVar = (typePattern.local != null);
/* 50 */     this.typeElidedVar |= typePattern.getType().isTypeNameVar((Scope)blockScope);
/* 51 */     return !(this.hasPatternVar && this.typeElidedVar);
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\ast\Pattern$1PatternVariablesVisitor.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */