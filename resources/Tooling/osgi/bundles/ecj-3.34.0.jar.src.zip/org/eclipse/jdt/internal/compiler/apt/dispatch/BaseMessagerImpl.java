/*     */ package org.eclipse.jdt.internal.compiler.apt.dispatch;
/*     */ 
/*     */ import javax.lang.model.element.AnnotationMirror;
/*     */ import javax.lang.model.element.AnnotationValue;
/*     */ import javax.lang.model.element.Element;
/*     */ import javax.lang.model.element.ElementKind;
/*     */ import javax.tools.Diagnostic;
/*     */ import org.eclipse.jdt.internal.compiler.CompilationResult;
/*     */ import org.eclipse.jdt.internal.compiler.apt.model.AnnotationMemberValue;
/*     */ import org.eclipse.jdt.internal.compiler.apt.model.AnnotationMirrorImpl;
/*     */ import org.eclipse.jdt.internal.compiler.apt.model.ExecutableElementImpl;
/*     */ import org.eclipse.jdt.internal.compiler.apt.model.ModuleElementImpl;
/*     */ import org.eclipse.jdt.internal.compiler.apt.model.TypeElementImpl;
/*     */ import org.eclipse.jdt.internal.compiler.apt.model.VariableElementImpl;
/*     */ import org.eclipse.jdt.internal.compiler.ast.AbstractMethodDeclaration;
/*     */ import org.eclipse.jdt.internal.compiler.ast.Annotation;
/*     */ import org.eclipse.jdt.internal.compiler.ast.ArrayInitializer;
/*     */ import org.eclipse.jdt.internal.compiler.ast.CompilationUnitDeclaration;
/*     */ import org.eclipse.jdt.internal.compiler.ast.Expression;
/*     */ import org.eclipse.jdt.internal.compiler.ast.FieldDeclaration;
/*     */ import org.eclipse.jdt.internal.compiler.ast.LocalDeclaration;
/*     */ import org.eclipse.jdt.internal.compiler.ast.MemberValuePair;
/*     */ import org.eclipse.jdt.internal.compiler.ast.TypeDeclaration;
/*     */ import org.eclipse.jdt.internal.compiler.impl.ReferenceContext;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.AnnotationBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.AptSourceLocalVariableBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.Binding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.FieldBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.MethodBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.ReferenceBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.SourceModuleBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.SourceTypeBinding;
/*     */ import org.eclipse.jdt.internal.compiler.util.Util;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BaseMessagerImpl
/*     */ {
/*  52 */   static final String[] NO_ARGUMENTS = new String[0];
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static AptProblem createProblem(Diagnostic.Kind kind, CharSequence msg, Element e, AnnotationMirror a, AnnotationValue v) {
/*     */     AbstractMethodDeclaration abstractMethodDeclaration;
/*     */     int severity;
/*  64 */     ReferenceContext referenceContext = null;
/*  65 */     Annotation[] elementAnnotations = null;
/*  66 */     int startPosition = 0;
/*  67 */     int endPosition = 0;
/*  68 */     if (e != null) {
/*  69 */       ModuleElementImpl moduleElementImpl; Binding moduleBinding; TypeElementImpl typeElementImpl; Binding typeBinding; ExecutableElementImpl executableElementImpl; Binding binding; VariableElementImpl variableElementImpl; switch (e.getKind()) {
/*     */         case MODULE:
/*  71 */           moduleElementImpl = (ModuleElementImpl)e;
/*  72 */           moduleBinding = moduleElementImpl._binding;
/*  73 */           if (moduleBinding instanceof SourceModuleBinding) {
/*  74 */             SourceModuleBinding sourceModuleBinding = (SourceModuleBinding)moduleBinding;
/*  75 */             CompilationUnitDeclaration unitDeclaration = (CompilationUnitDeclaration)sourceModuleBinding.scope.referenceContext();
/*  76 */             CompilationUnitDeclaration compilationUnitDeclaration1 = unitDeclaration;
/*  77 */             elementAnnotations = unitDeclaration.moduleDeclaration.annotations;
/*  78 */             startPosition = unitDeclaration.moduleDeclaration.sourceStart;
/*  79 */             endPosition = unitDeclaration.moduleDeclaration.sourceEnd;
/*     */           } 
/*     */           break;
/*     */         case ENUM:
/*     */         case CLASS:
/*     */         case null:
/*     */         case INTERFACE:
/*  86 */           typeElementImpl = (TypeElementImpl)e;
/*  87 */           typeBinding = typeElementImpl._binding;
/*  88 */           if (typeBinding instanceof SourceTypeBinding) {
/*  89 */             SourceTypeBinding sourceTypeBinding = (SourceTypeBinding)typeBinding;
/*  90 */             TypeDeclaration typeDeclaration = (TypeDeclaration)sourceTypeBinding.scope.referenceContext();
/*  91 */             TypeDeclaration typeDeclaration1 = typeDeclaration;
/*  92 */             elementAnnotations = typeDeclaration.annotations;
/*  93 */             startPosition = typeDeclaration.sourceStart;
/*  94 */             endPosition = typeDeclaration.sourceEnd;
/*     */           } 
/*     */           break;
/*     */ 
/*     */ 
/*     */         
/*     */         case METHOD:
/*     */         case CONSTRUCTOR:
/* 102 */           executableElementImpl = (ExecutableElementImpl)e;
/* 103 */           binding = executableElementImpl._binding;
/* 104 */           if (binding instanceof MethodBinding) {
/* 105 */             MethodBinding methodBinding = (MethodBinding)binding;
/* 106 */             AbstractMethodDeclaration sourceMethod = methodBinding.sourceMethod();
/* 107 */             if (sourceMethod != null) {
/* 108 */               abstractMethodDeclaration = sourceMethod;
/* 109 */               elementAnnotations = sourceMethod.annotations;
/* 110 */               startPosition = sourceMethod.sourceStart;
/* 111 */               endPosition = sourceMethod.sourceEnd;
/*     */             } 
/*     */           } 
/*     */           break;
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         case FIELD:
/*     */         case PARAMETER:
/* 121 */           variableElementImpl = (VariableElementImpl)e;
/* 122 */           binding = variableElementImpl._binding;
/* 123 */           if (binding instanceof FieldBinding) {
/* 124 */             FieldBinding fieldBinding = (FieldBinding)binding;
/* 125 */             FieldDeclaration fieldDeclaration = fieldBinding.sourceField();
/* 126 */             if (fieldDeclaration != null) {
/* 127 */               ReferenceBinding declaringClass = fieldBinding.declaringClass;
/* 128 */               if (declaringClass instanceof SourceTypeBinding) {
/* 129 */                 SourceTypeBinding sourceTypeBinding = (SourceTypeBinding)declaringClass;
/* 130 */                 TypeDeclaration typeDeclaration = (TypeDeclaration)sourceTypeBinding.scope.referenceContext();
/* 131 */                 TypeDeclaration typeDeclaration1 = typeDeclaration;
/*     */               } 
/* 133 */               elementAnnotations = fieldDeclaration.annotations;
/* 134 */               startPosition = fieldDeclaration.sourceStart;
/* 135 */               endPosition = fieldDeclaration.sourceEnd;
/*     */             }  break;
/* 137 */           }  if (binding instanceof AptSourceLocalVariableBinding) {
/* 138 */             AptSourceLocalVariableBinding parameterBinding = (AptSourceLocalVariableBinding)binding;
/* 139 */             LocalDeclaration parameterDeclaration = parameterBinding.declaration;
/* 140 */             if (parameterDeclaration != null) {
/* 141 */               MethodBinding methodBinding = parameterBinding.methodBinding;
/* 142 */               if (methodBinding != null) {
/* 143 */                 abstractMethodDeclaration = methodBinding.sourceMethod();
/*     */               }
/* 145 */               elementAnnotations = parameterDeclaration.annotations;
/* 146 */               startPosition = parameterDeclaration.sourceStart;
/* 147 */               endPosition = parameterDeclaration.sourceEnd;
/*     */             } 
/*     */           } 
/*     */           break;
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     } 
/* 161 */     StringBuilder builder = new StringBuilder();
/* 162 */     if (msg != null) {
/* 163 */       builder.append(msg);
/*     */     }
/* 165 */     if (a != null && elementAnnotations != null) {
/* 166 */       AnnotationBinding annotationBinding = ((AnnotationMirrorImpl)a)._binding;
/* 167 */       Annotation annotation = findAnnotation(elementAnnotations, annotationBinding);
/* 168 */       if (annotation != null) {
/* 169 */         startPosition = annotation.sourceStart;
/* 170 */         endPosition = annotation.sourceEnd;
/* 171 */         if (v != null && v instanceof AnnotationMemberValue) {
/* 172 */           MethodBinding methodBinding = ((AnnotationMemberValue)v).getMethodBinding();
/* 173 */           MemberValuePair[] memberValuePairs = annotation.memberValuePairs();
/* 174 */           MemberValuePair memberValuePair = null;
/* 175 */           for (int i = 0; memberValuePair == null && i < memberValuePairs.length; i++) {
/* 176 */             if (methodBinding == (memberValuePairs[i]).binding) {
/* 177 */               memberValuePair = memberValuePairs[i];
/*     */             }
/*     */           } 
/* 180 */           if (memberValuePair != null) {
/* 181 */             startPosition = memberValuePair.sourceStart;
/* 182 */             endPosition = memberValuePair.sourceEnd;
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/* 187 */     int lineNumber = 0;
/* 188 */     int columnNumber = 1;
/* 189 */     char[] fileName = null;
/* 190 */     if (abstractMethodDeclaration != null) {
/* 191 */       CompilationResult result = abstractMethodDeclaration.compilationResult();
/* 192 */       fileName = result.fileName;
/* 193 */       int[] lineEnds = null;
/* 194 */       lineNumber = (startPosition >= 0) ? 
/* 195 */         Util.getLineNumber(startPosition, lineEnds = result.getLineSeparatorPositions(), 0, lineEnds.length - 1) : 
/* 196 */         0;
/* 197 */       columnNumber = (startPosition >= 0) ? 
/* 198 */         Util.searchColumnNumber(result.getLineSeparatorPositions(), lineNumber, startPosition) : 
/* 199 */         0;
/*     */     } 
/*     */     
/* 202 */     switch (kind) {
/*     */       case null:
/* 204 */         severity = 1;
/*     */         break;
/*     */       case NOTE:
/*     */       case OTHER:
/* 208 */         severity = 1024;
/*     */         break;
/*     */       default:
/* 211 */         severity = 0;
/*     */         break;
/*     */     } 
/* 214 */     return new AptProblem(
/* 215 */         (ReferenceContext)abstractMethodDeclaration, 
/* 216 */         fileName, 
/* 217 */         String.valueOf(builder), 
/* 218 */         0, 
/* 219 */         NO_ARGUMENTS, 
/* 220 */         severity, 
/* 221 */         startPosition, 
/* 222 */         endPosition, 
/* 223 */         lineNumber, 
/* 224 */         columnNumber);
/*     */   }
/*     */   
/*     */   private static Annotation findAnnotation(Annotation[] elementAnnotations, AnnotationBinding annotationBinding) {
/* 228 */     for (int i = 0; i < elementAnnotations.length; i++) {
/* 229 */       Annotation annotation = findAnnotation(elementAnnotations[i], annotationBinding);
/* 230 */       if (annotation != null) {
/* 231 */         return annotation;
/*     */       }
/*     */     } 
/* 234 */     return null;
/*     */   }
/*     */   
/*     */   private static Annotation findAnnotation(Annotation elementAnnotation, AnnotationBinding annotationBinding) {
/* 238 */     if (annotationBinding == elementAnnotation.getCompilerAnnotation()) {
/* 239 */       return elementAnnotation;
/*     */     }
/*     */     
/* 242 */     MemberValuePair[] memberValuePairs = elementAnnotation.memberValuePairs(); byte b; int i; MemberValuePair[] arrayOfMemberValuePair1;
/* 243 */     for (i = (arrayOfMemberValuePair1 = memberValuePairs).length, b = 0; b < i; ) { MemberValuePair mvp = arrayOfMemberValuePair1[b];
/* 244 */       Expression v = mvp.value;
/* 245 */       if (v instanceof Annotation) {
/* 246 */         Annotation a = findAnnotation((Annotation)v, annotationBinding);
/* 247 */         if (a != null) {
/* 248 */           return a;
/*     */         }
/* 250 */       } else if (v instanceof ArrayInitializer) {
/* 251 */         Expression[] expressions = ((ArrayInitializer)v).expressions; byte b1; int j; Expression[] arrayOfExpression1;
/* 252 */         for (j = (arrayOfExpression1 = expressions).length, b1 = 0; b1 < j; ) { Expression e = arrayOfExpression1[b1];
/* 253 */           if (e instanceof Annotation) {
/* 254 */             Annotation a = findAnnotation((Annotation)e, annotationBinding);
/* 255 */             if (a != null)
/* 256 */               return a; 
/*     */           }  b1++; }
/*     */       
/*     */       } 
/*     */       b++; }
/*     */     
/* 262 */     return null;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\apt\dispatch\BaseMessagerImpl.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */