/*    */ package org.eclipse.jdt.internal.compiler.env;
/*    */ 
/*    */ import org.eclipse.jdt.internal.compiler.lookup.LookupEnvironment;
/*    */ import org.eclipse.jdt.internal.compiler.lookup.ModuleBinding;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface ICompilationUnit
/*    */   extends IDependent
/*    */ {
/*    */   char[] getContents();
/*    */   
/*    */   char[] getMainTypeName();
/*    */   
/*    */   char[][] getPackageName();
/*    */   
/*    */   default boolean ignoreOptionalProblems() {
/* 56 */     return false;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   default ModuleBinding module(LookupEnvironment environment) {
/* 64 */     return environment.getModule(getModuleName());
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   default char[] getModuleName() {
/* 72 */     return null;
/*    */   }
/*    */   default String getDestinationPath() {
/* 75 */     return null;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   default String getExternalAnnotationPath(String qualifiedTypeName) {
/* 81 */     return null;
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\env\ICompilationUnit.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */