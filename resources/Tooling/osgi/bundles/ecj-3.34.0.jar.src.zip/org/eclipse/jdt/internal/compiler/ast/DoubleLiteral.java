/*     */ package org.eclipse.jdt.internal.compiler.ast;
/*     */ 
/*     */ import org.eclipse.jdt.core.compiler.CharOperation;
/*     */ import org.eclipse.jdt.internal.compiler.ASTVisitor;
/*     */ import org.eclipse.jdt.internal.compiler.codegen.CodeStream;
/*     */ import org.eclipse.jdt.internal.compiler.impl.DoubleConstant;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.BlockScope;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.TypeBinding;
/*     */ import org.eclipse.jdt.internal.compiler.util.FloatUtil;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DoubleLiteral
/*     */   extends NumberLiteral
/*     */ {
/*     */   double value;
/*     */   
/*     */   public DoubleLiteral(char[] token, int s, int e) {
/*  28 */     super(token, s, e);
/*     */   }
/*     */ 
/*     */   
/*     */   public void computeConstant() {
/*     */     Double computedValue;
/*  34 */     boolean containsUnderscores = (CharOperation.indexOf('_', this.source) > 0);
/*  35 */     if (containsUnderscores)
/*     */     {
/*  37 */       this.source = CharOperation.remove(this.source, '_');
/*     */     }
/*     */     try {
/*  40 */       computedValue = Double.valueOf(String.valueOf(this.source));
/*  41 */     } catch (NumberFormatException numberFormatException) {
/*     */ 
/*     */       
/*     */       try {
/*  45 */         double v = FloatUtil.valueOfHexDoubleLiteral(this.source);
/*  46 */         if (v == Double.POSITIVE_INFINITY) {
/*     */           return;
/*     */         }
/*     */         
/*  50 */         if (Double.isNaN(v)) {
/*     */           return;
/*     */         }
/*     */         
/*  54 */         this.value = v;
/*  55 */         this.constant = DoubleConstant.fromValue(v);
/*  56 */       } catch (NumberFormatException numberFormatException1) {}
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/*  61 */     double doubleValue = computedValue.doubleValue();
/*  62 */     if (doubleValue > Double.MAX_VALUE) {
/*     */       return;
/*     */     }
/*     */     
/*  66 */     if (doubleValue < Double.MIN_VALUE) {
/*     */ 
/*     */ 
/*     */       
/*  70 */       boolean isHexaDecimal = false;
/*  71 */       for (int i = 0; i < this.source.length; i++) {
/*  72 */         switch (this.source[i]) {
/*     */           case '.':
/*     */           case '0':
/*     */             break;
/*     */           case 'X':
/*     */           case 'x':
/*  78 */             isHexaDecimal = true;
/*     */             break;
/*     */           case 'D':
/*     */           case 'E':
/*     */           case 'F':
/*     */           case 'd':
/*     */           case 'e':
/*     */           case 'f':
/*  86 */             if (isHexaDecimal) {
/*     */               return;
/*     */             }
/*     */             break;
/*     */           
/*     */           case 'P':
/*     */           case 'p':
/*     */             break;
/*     */           
/*     */           default:
/*     */             return;
/*     */         } 
/*     */       
/*     */       } 
/*     */     } 
/* 101 */     this.value = doubleValue;
/* 102 */     this.constant = DoubleConstant.fromValue(this.value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void generateCode(BlockScope currentScope, CodeStream codeStream, boolean valueRequired) {
/* 114 */     int pc = codeStream.position;
/* 115 */     if (valueRequired) {
/* 116 */       codeStream.generateConstant(this.constant, this.implicitConversion);
/*     */     }
/* 118 */     codeStream.recordPositionsFrom(pc, this.sourceStart);
/*     */   }
/*     */ 
/*     */   
/*     */   public TypeBinding literalType(BlockScope scope) {
/* 123 */     return (TypeBinding)TypeBinding.DOUBLE;
/*     */   }
/*     */ 
/*     */   
/*     */   public void traverse(ASTVisitor visitor, BlockScope scope) {
/* 128 */     visitor.visit(this, scope);
/* 129 */     visitor.endVisit(this, scope);
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\ast\DoubleLiteral.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */