package org.eclipse.jdt.internal.compiler.env;

import org.eclipse.jdt.internal.compiler.impl.Constant;

public interface IBinaryField extends IGenericField {
  IBinaryAnnotation[] getAnnotations();
  
  IBinaryTypeAnnotation[] getTypeAnnotations();
  
  Constant getConstant();
  
  char[] getGenericSignature();
  
  char[] getName();
  
  long getTagBits();
  
  char[] getTypeName();
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\env\IBinaryField.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */