/*     */ package org.eclipse.jdt.internal.compiler.ast;
/*     */ 
/*     */ import org.eclipse.jdt.core.compiler.CharOperation;
/*     */ import org.eclipse.jdt.internal.compiler.ASTVisitor;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.BlockScope;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.ClassScope;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.ReferenceBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.Scope;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.TypeBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.WildcardBinding;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Wildcard
/*     */   extends SingleTypeReference
/*     */ {
/*     */   public static final int UNBOUND = 0;
/*     */   public static final int EXTENDS = 1;
/*     */   public static final int SUPER = 2;
/*     */   public TypeReference bound;
/*     */   public int kind;
/*     */   
/*     */   public Wildcard(int kind) {
/*  41 */     super(WILDCARD_NAME, 0L);
/*  42 */     this.kind = kind;
/*     */   }
/*     */ 
/*     */   
/*     */   public char[][] getParameterizedTypeName() {
/*  47 */     switch (this.kind) {
/*     */       case 0:
/*  49 */         return new char[][] { WILDCARD_NAME };
/*     */       case 1:
/*  51 */         return new char[][] { CharOperation.concat(WILDCARD_NAME, WILDCARD_EXTENDS, CharOperation.concatWith(this.bound.getParameterizedTypeName(), '.')) };
/*     */     } 
/*  53 */     return new char[][] { CharOperation.concat(WILDCARD_NAME, WILDCARD_SUPER, CharOperation.concatWith(this.bound.getParameterizedTypeName(), '.')) };
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public char[][] getTypeName() {
/*  59 */     switch (this.kind) {
/*     */       case 0:
/*  61 */         return new char[][] { WILDCARD_NAME };
/*     */       case 1:
/*  63 */         return new char[][] { CharOperation.concat(WILDCARD_NAME, WILDCARD_EXTENDS, CharOperation.concatWith(this.bound.getTypeName(), '.')) };
/*     */     } 
/*  65 */     return new char[][] { CharOperation.concat(WILDCARD_NAME, WILDCARD_SUPER, CharOperation.concatWith(this.bound.getTypeName(), '.')) };
/*     */   }
/*     */ 
/*     */   
/*     */   private TypeBinding internalResolveType(Scope scope, ReferenceBinding genericType, int rank) {
/*  70 */     TypeBinding boundType = null;
/*  71 */     if (this.bound != null) {
/*  72 */       boundType = (scope.kind == 3) ? 
/*  73 */         this.bound.resolveType((ClassScope)scope, 256) : 
/*  74 */         this.bound.resolveType((BlockScope)scope, true, 256);
/*  75 */       this.bits |= this.bound.bits & 0x100000;
/*  76 */       if (boundType == null) {
/*  77 */         return null;
/*     */       }
/*     */     } 
/*  80 */     this.resolvedType = (TypeBinding)scope.environment().createWildcard(genericType, rank, boundType, null, this.kind);
/*  81 */     resolveAnnotations(scope, 0);
/*     */     
/*  83 */     if (scope.environment().usesNullTypeAnnotations()) {
/*  84 */       ((WildcardBinding)this.resolvedType).evaluateNullAnnotations(scope, this);
/*     */     }
/*     */     
/*  87 */     return this.resolvedType;
/*     */   }
/*     */ 
/*     */   
/*     */   public StringBuffer printExpression(int indent, StringBuffer output) {
/*  92 */     if (this.annotations != null && this.annotations[0] != null) {
/*  93 */       printAnnotations(this.annotations[0], output);
/*  94 */       output.append(' ');
/*     */     } 
/*  96 */     switch (this.kind)
/*     */     { case 0:
/*  98 */         output.append(WILDCARD_NAME);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 109 */         return output;case 1: output.append(WILDCARD_NAME).append(WILDCARD_EXTENDS); this.bound.printExpression(0, output); return output; }  output.append(WILDCARD_NAME).append(WILDCARD_SUPER); this.bound.printExpression(0, output); return output;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public TypeBinding resolveType(BlockScope scope, boolean checkBounds, int location) {
/* 115 */     if (this.bound != null) {
/* 116 */       this.bound.resolveType(scope, checkBounds, 256);
/* 117 */       this.bits |= this.bound.bits & 0x100000;
/*     */     } 
/* 119 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public TypeBinding resolveType(ClassScope scope, int location) {
/* 124 */     if (this.bound != null) {
/* 125 */       this.bound.resolveType(scope, 256);
/* 126 */       this.bits |= this.bound.bits & 0x100000;
/*     */     } 
/* 128 */     return null;
/*     */   }
/*     */   
/*     */   public TypeBinding resolveTypeArgument(BlockScope blockScope, ReferenceBinding genericType, int rank) {
/* 132 */     return internalResolveType((Scope)blockScope, genericType, rank);
/*     */   }
/*     */ 
/*     */   
/*     */   public TypeBinding resolveTypeArgument(ClassScope classScope, ReferenceBinding genericType, int rank) {
/* 137 */     return internalResolveType((Scope)classScope, genericType, rank);
/*     */   }
/*     */ 
/*     */   
/*     */   public void traverse(ASTVisitor visitor, BlockScope scope) {
/* 142 */     if (visitor.visit(this, scope)) {
/* 143 */       if (this.annotations != null) {
/* 144 */         Annotation[] typeAnnotations = this.annotations[0];
/* 145 */         for (int i = 0, length = (typeAnnotations == null) ? 0 : typeAnnotations.length; i < length; i++) {
/* 146 */           typeAnnotations[i].traverse(visitor, scope);
/*     */         }
/*     */       } 
/* 149 */       if (this.bound != null) {
/* 150 */         this.bound.traverse(visitor, scope);
/*     */       }
/*     */     } 
/* 153 */     visitor.endVisit(this, scope);
/*     */   }
/*     */ 
/*     */   
/*     */   public void traverse(ASTVisitor visitor, ClassScope scope) {
/* 158 */     if (visitor.visit(this, scope)) {
/* 159 */       if (this.annotations != null) {
/* 160 */         Annotation[] typeAnnotations = this.annotations[0];
/* 161 */         for (int i = 0, length = (typeAnnotations == null) ? 0 : typeAnnotations.length; i < length; i++) {
/* 162 */           typeAnnotations[i].traverse(visitor, scope);
/*     */         }
/*     */       } 
/* 165 */       if (this.bound != null) {
/* 166 */         this.bound.traverse(visitor, scope);
/*     */       }
/*     */     } 
/* 169 */     visitor.endVisit(this, scope);
/*     */   }
/*     */   
/*     */   public boolean isWildcard() {
/* 173 */     return true;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\ast\Wildcard.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */