/*     */ package org.eclipse.jdt.internal.compiler.ast;
/*     */ 
/*     */ import java.util.List;
/*     */ import org.eclipse.jdt.core.compiler.CategorizedProblem;
/*     */ import org.eclipse.jdt.core.compiler.CharOperation;
/*     */ import org.eclipse.jdt.internal.compiler.ASTVisitor;
/*     */ import org.eclipse.jdt.internal.compiler.ClassFile;
/*     */ import org.eclipse.jdt.internal.compiler.CompilationResult;
/*     */ import org.eclipse.jdt.internal.compiler.codegen.CodeStream;
/*     */ import org.eclipse.jdt.internal.compiler.flow.FlowInfo;
/*     */ import org.eclipse.jdt.internal.compiler.impl.ReferenceContext;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.AnnotationBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.Binding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.BlockScope;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.ClassScope;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.LocalVariableBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.LookupEnvironment;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.MethodBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.MethodScope;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.ReferenceBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.TypeBinding;
/*     */ import org.eclipse.jdt.internal.compiler.parser.Parser;
/*     */ import org.eclipse.jdt.internal.compiler.problem.AbortCompilation;
/*     */ import org.eclipse.jdt.internal.compiler.problem.AbortCompilationUnit;
/*     */ import org.eclipse.jdt.internal.compiler.problem.AbortMethod;
/*     */ import org.eclipse.jdt.internal.compiler.problem.AbortType;
/*     */ import org.eclipse.jdt.internal.compiler.problem.ProblemReporter;
/*     */ import org.eclipse.jdt.internal.compiler.problem.ProblemSeverities;
/*     */ import org.eclipse.jdt.internal.compiler.util.Util;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractMethodDeclaration
/*     */   extends ASTNode
/*     */   implements ProblemSeverities, ReferenceContext
/*     */ {
/*     */   public MethodScope scope;
/*     */   public char[] selector;
/*     */   public int declarationSourceStart;
/*     */   public int declarationSourceEnd;
/*     */   public int modifiers;
/*     */   public int modifiersSourceStart;
/*     */   public Annotation[] annotations;
/*     */   public Receiver receiver;
/*     */   public Argument[] arguments;
/*     */   public TypeReference[] thrownExceptions;
/*     */   public Statement[] statements;
/*     */   public int explicitDeclarations;
/*     */   public MethodBinding binding;
/*     */   public boolean ignoreFurtherInvestigation = false;
/*     */   public Javadoc javadoc;
/*     */   public int bodyStart;
/*  73 */   public int bodyEnd = -1;
/*     */   public CompilationResult compilationResult;
/*     */   public boolean containsSwitchWithTry = false;
/*     */   
/*     */   AbstractMethodDeclaration(CompilationResult compilationResult) {
/*  78 */     this.compilationResult = compilationResult;
/*  79 */     this.containsSwitchWithTry = false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void abort(int abortLevel, CategorizedProblem problem) {
/*  88 */     switch (abortLevel) {
/*     */       case 2:
/*  90 */         throw new AbortCompilation(this.compilationResult, problem);
/*     */       case 4:
/*  92 */         throw new AbortCompilationUnit(this.compilationResult, problem);
/*     */       case 8:
/*  94 */         throw new AbortType(this.compilationResult, problem);
/*     */     } 
/*  96 */     throw new AbortMethod(this.compilationResult, problem);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void createArgumentBindings() {
/* 105 */     createArgumentBindings(this.arguments, this.binding, this.scope);
/*     */   }
/*     */   
/*     */   static void createArgumentBindings(Argument[] arguments, MethodBinding binding, MethodScope scope) {
/* 109 */     boolean useTypeAnnotations = scope.environment().usesNullTypeAnnotations();
/* 110 */     if (arguments != null && binding != null) {
/* 111 */       for (int i = 0, length = arguments.length; i < length; i++) {
/* 112 */         Argument argument = arguments[i];
/* 113 */         binding.parameters[i] = argument.createBinding(scope, binding.parameters[i]);
/* 114 */         if (!useTypeAnnotations) {
/*     */ 
/*     */           
/* 117 */           long argTypeTagBits = argument.binding.tagBits & 0x180000000000000L;
/* 118 */           if (argTypeTagBits != 0L) {
/* 119 */             if (binding.parameterNonNullness == null) {
/* 120 */               binding.parameterNonNullness = new Boolean[arguments.length];
/* 121 */               binding.tagBits |= 0x1000L;
/*     */             } 
/* 123 */             binding.parameterNonNullness[i] = Boolean.valueOf((argTypeTagBits == 72057594037927936L));
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void bindArguments() {
/* 134 */     if (this.arguments != null) {
/*     */       
/* 136 */       if (this.binding == null) {
/* 137 */         for (int j = 0, k = this.arguments.length; j < k; j++) {
/* 138 */           this.arguments[j].bind(this.scope, (TypeBinding)null, true);
/*     */         }
/*     */         return;
/*     */       } 
/* 142 */       boolean used = !(!this.binding.isAbstract() && !this.binding.isNative());
/* 143 */       AnnotationBinding[][] paramAnnotations = null;
/* 144 */       for (int i = 0, length = this.arguments.length; i < length; i++) {
/* 145 */         Argument argument = this.arguments[i];
/* 146 */         this.binding.parameters[i] = argument.bind(this.scope, this.binding.parameters[i], used);
/* 147 */         if (argument.annotations != null) {
/* 148 */           if (paramAnnotations == null) {
/* 149 */             paramAnnotations = new AnnotationBinding[length][];
/* 150 */             for (int j = 0; j < i; j++) {
/* 151 */               paramAnnotations[j] = Binding.NO_ANNOTATIONS;
/*     */             }
/*     */           } 
/* 154 */           paramAnnotations[i] = argument.binding.getAnnotations();
/* 155 */         } else if (paramAnnotations != null) {
/* 156 */           paramAnnotations[i] = Binding.NO_ANNOTATIONS;
/*     */         } 
/*     */       } 
/* 159 */       if (paramAnnotations == null) {
/* 160 */         paramAnnotations = getPropagatedRecordComponentAnnotations();
/*     */       }
/*     */       
/* 163 */       if (paramAnnotations != null)
/* 164 */         this.binding.setParameterAnnotations(paramAnnotations); 
/*     */     } 
/*     */   }
/*     */   
/*     */   protected AnnotationBinding[][] getPropagatedRecordComponentAnnotations() {
/* 169 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void bindThrownExceptions() {
/* 177 */     if (this.thrownExceptions != null && 
/* 178 */       this.binding != null && 
/* 179 */       this.binding.thrownExceptions != null) {
/* 180 */       int thrownExceptionLength = this.thrownExceptions.length;
/* 181 */       int length = this.binding.thrownExceptions.length;
/* 182 */       if (length == thrownExceptionLength) {
/* 183 */         for (int i = 0; i < length; i++) {
/* 184 */           (this.thrownExceptions[i]).resolvedType = (TypeBinding)this.binding.thrownExceptions[i];
/*     */         }
/*     */       } else {
/* 187 */         int bindingIndex = 0;
/* 188 */         for (int i = 0; i < thrownExceptionLength && bindingIndex < length; i++) {
/* 189 */           TypeReference thrownException = this.thrownExceptions[i];
/* 190 */           ReferenceBinding thrownExceptionBinding = this.binding.thrownExceptions[bindingIndex];
/* 191 */           char[][] bindingCompoundName = thrownExceptionBinding.compoundName;
/* 192 */           if (bindingCompoundName != null) {
/* 193 */             if (thrownException instanceof SingleTypeReference) {
/*     */               
/* 195 */               int lengthName = bindingCompoundName.length;
/* 196 */               char[] thrownExceptionTypeName = thrownException.getTypeName()[0];
/* 197 */               if (CharOperation.equals(thrownExceptionTypeName, bindingCompoundName[lengthName - 1])) {
/* 198 */                 thrownException.resolvedType = (TypeBinding)thrownExceptionBinding;
/* 199 */                 bindingIndex++;
/*     */               }
/*     */             
/*     */             }
/* 203 */             else if (CharOperation.equals(thrownException.getTypeName(), bindingCompoundName)) {
/* 204 */               thrownException.resolvedType = (TypeBinding)thrownExceptionBinding;
/* 205 */               bindingIndex++;
/*     */             } 
/*     */           }
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static void analyseArguments(LookupEnvironment environment, FlowInfo flowInfo, Argument[] methodArguments, MethodBinding methodBinding) {
/* 217 */     if (methodArguments != null) {
/* 218 */       boolean usesNullTypeAnnotations = environment.usesNullTypeAnnotations();
/* 219 */       int length = Math.min(methodBinding.parameters.length, methodArguments.length);
/* 220 */       for (int i = 0; i < length; i++) {
/* 221 */         if (usesNullTypeAnnotations) {
/*     */           
/* 223 */           long tagBits = (methodBinding.parameters[i]).tagBits & 0x180000000000000L;
/* 224 */           if (tagBits == 72057594037927936L) {
/* 225 */             flowInfo.markAsDefinitelyNonNull((methodArguments[i]).binding);
/* 226 */           } else if (tagBits == 36028797018963968L) {
/* 227 */             flowInfo.markPotentiallyNullBit((methodArguments[i]).binding);
/* 228 */           } else if (methodBinding.parameters[i].isFreeTypeVariable()) {
/* 229 */             flowInfo.markNullStatus((methodArguments[i]).binding, 48);
/*     */           } 
/* 231 */         } else if (methodBinding.parameterNonNullness != null) {
/*     */           
/* 233 */           Boolean nonNullNess = methodBinding.parameterNonNullness[i];
/* 234 */           if (nonNullNess != null) {
/* 235 */             if (nonNullNess.booleanValue()) {
/* 236 */               flowInfo.markAsDefinitelyNonNull((methodArguments[i]).binding);
/*     */             } else {
/* 238 */               flowInfo.markPotentiallyNullBit((methodArguments[i]).binding);
/*     */             } 
/*     */           }
/*     */         } 
/* 242 */         if (!flowInfo.hasNullInfoFor((methodArguments[i]).binding)) {
/* 243 */           flowInfo.markNullStatus((methodArguments[i]).binding, 1);
/*     */         }
/* 245 */         flowInfo.markAsDefinitelyAssigned((methodArguments[i]).binding);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public CompilationResult compilationResult() {
/* 253 */     return this.compilationResult;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void generateCode(ClassScope classScope, ClassFile classFile) {
/* 263 */     classFile.codeStream.wideMode = false;
/* 264 */     if (this.ignoreFurtherInvestigation) {
/*     */       
/* 266 */       if (this.binding == null) {
/*     */         return;
/*     */       }
/* 269 */       CategorizedProblem[] problems = 
/* 270 */         (this.scope.referenceCompilationUnit()).compilationResult.getProblems(); int problemsLength;
/* 271 */       CategorizedProblem[] problemsCopy = new CategorizedProblem[problemsLength = problems.length];
/* 272 */       System.arraycopy(problems, 0, problemsCopy, 0, problemsLength);
/* 273 */       classFile.addProblemMethod(this, this.binding, problemsCopy);
/*     */       return;
/*     */     } 
/* 276 */     int problemResetPC = 0;
/* 277 */     CompilationResult unitResult = null;
/* 278 */     int problemCount = 0;
/* 279 */     if (classScope != null) {
/* 280 */       TypeDeclaration referenceContext = classScope.referenceContext;
/* 281 */       if (referenceContext != null) {
/* 282 */         unitResult = referenceContext.compilationResult();
/* 283 */         problemCount = unitResult.problemCount;
/*     */       } 
/*     */     } 
/* 286 */     boolean restart = false;
/* 287 */     boolean abort = false;
/*     */     
/*     */     do {
/*     */       try {
/* 291 */         problemResetPC = classFile.contentsOffset;
/* 292 */         generateCode(classFile);
/* 293 */         restart = false;
/* 294 */       } catch (AbortMethod e) {
/*     */         
/* 296 */         if (e.compilationResult == CodeStream.RESTART_IN_WIDE_MODE) {
/*     */           
/* 298 */           classFile.contentsOffset = problemResetPC;
/* 299 */           classFile.methodCount--;
/* 300 */           classFile.codeStream.resetInWideMode();
/*     */           
/* 302 */           if (unitResult != null) {
/* 303 */             unitResult.problemCount = problemCount;
/*     */           }
/* 305 */           restart = true;
/* 306 */         } else if (e.compilationResult == CodeStream.RESTART_CODE_GEN_FOR_UNUSED_LOCALS_MODE) {
/* 307 */           classFile.contentsOffset = problemResetPC;
/* 308 */           classFile.methodCount--;
/* 309 */           classFile.codeStream.resetForCodeGenUnusedLocals();
/*     */           
/* 311 */           if (unitResult != null) {
/* 312 */             unitResult.problemCount = problemCount;
/*     */           }
/* 314 */           restart = true;
/*     */         } else {
/* 316 */           restart = false;
/* 317 */           abort = true;
/*     */         } 
/*     */       } 
/* 320 */     } while (restart);
/*     */     
/* 322 */     if (abort) {
/*     */       
/* 324 */       CategorizedProblem[] problems = 
/* 325 */         (this.scope.referenceCompilationUnit()).compilationResult.getAllProblems(); int problemsLength;
/* 326 */       CategorizedProblem[] problemsCopy = new CategorizedProblem[problemsLength = problems.length];
/* 327 */       System.arraycopy(problems, 0, problemsCopy, 0, problemsLength);
/* 328 */       classFile.addProblemMethod(this, this.binding, problemsCopy, problemResetPC);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void generateCode(ClassFile classFile) {
/* 334 */     classFile.generateMethodInfoHeader(this.binding);
/* 335 */     int methodAttributeOffset = classFile.contentsOffset;
/* 336 */     int attributeNumber = classFile.generateMethodInfoAttributes(this.binding);
/* 337 */     if (!this.binding.isNative() && !this.binding.isAbstract()) {
/* 338 */       int codeAttributeOffset = classFile.contentsOffset;
/* 339 */       classFile.generateCodeAttributeHeader();
/* 340 */       CodeStream codeStream = classFile.codeStream;
/* 341 */       codeStream.reset(this, classFile);
/*     */       
/* 343 */       this.scope.computeLocalVariablePositions(this.binding.isStatic() ? 0 : 1, codeStream);
/*     */ 
/*     */       
/* 346 */       if (this.arguments != null) {
/* 347 */         for (int i = 0, max = this.arguments.length; i < max; i++) {
/*     */           LocalVariableBinding argBinding;
/* 349 */           codeStream.addVisibleLocalVariable(argBinding = (this.arguments[i]).binding);
/* 350 */           argBinding.recordInitializationStartPC(0);
/*     */         } 
/*     */       }
/* 353 */       if (this.statements != null) {
/* 354 */         byte b; int i; Statement[] arrayOfStatement; for (i = (arrayOfStatement = this.statements).length, b = 0; b < i; ) { Statement stmt = arrayOfStatement[b];
/* 355 */           stmt.generateCode((BlockScope)this.scope, codeStream);
/*     */           b++; }
/*     */       
/*     */       } 
/* 359 */       if (this.ignoreFurtherInvestigation) {
/* 360 */         throw new AbortMethod((this.scope.referenceCompilationUnit()).compilationResult, null);
/*     */       }
/* 362 */       if ((this.bits & 0x40) != 0) {
/* 363 */         codeStream.return_();
/*     */       }
/*     */       
/* 366 */       codeStream.exitUserScope((BlockScope)this.scope);
/* 367 */       codeStream.recordPositionsFrom(0, this.declarationSourceEnd);
/*     */       try {
/* 369 */         classFile.completeCodeAttribute(codeAttributeOffset, this.scope);
/* 370 */       } catch (NegativeArraySizeException negativeArraySizeException) {
/* 371 */         throw new AbortMethod((this.scope.referenceCompilationUnit()).compilationResult, null);
/*     */       } 
/* 373 */       attributeNumber++;
/*     */     } else {
/* 375 */       checkArgumentsSize();
/*     */     } 
/* 377 */     classFile.completeMethodInfo(this.binding, methodAttributeOffset, attributeNumber);
/*     */   }
/*     */ 
/*     */   
/*     */   public void getAllAnnotationContexts(int targetType, List allAnnotationContexts) {}
/*     */ 
/*     */   
/*     */   private void checkArgumentsSize() {
/* 385 */     TypeBinding[] parameters = this.binding.parameters;
/* 386 */     int size = 1;
/* 387 */     for (int i = 0, max = parameters.length; i < max; i++) {
/* 388 */       switch ((parameters[i]).id) {
/*     */         case 7:
/*     */         case 8:
/* 391 */           size += 2;
/*     */           break;
/*     */         default:
/* 394 */           size++;
/*     */           break;
/*     */       } 
/* 397 */       if (size > 255) {
/* 398 */         this.scope.problemReporter().noMoreAvailableSpaceForArgument(this.scope.locals[i], (this.scope.locals[i]).declaration);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public CompilationUnitDeclaration getCompilationUnitDeclaration() {
/* 405 */     if (this.scope != null) {
/* 406 */       return (this.scope.compilationUnitScope()).referenceContext;
/*     */     }
/* 408 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean hasErrors() {
/* 413 */     return this.ignoreFurtherInvestigation;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isAbstract() {
/* 418 */     if (this.binding != null)
/* 419 */       return this.binding.isAbstract(); 
/* 420 */     return ((this.modifiers & 0x400) != 0);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isAnnotationMethod() {
/* 425 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isClinit() {
/* 430 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isConstructor() {
/* 435 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isCanonicalConstructor() {
/* 440 */     return false;
/*     */   }
/*     */   
/*     */   public boolean isDefaultConstructor() {
/* 444 */     return false;
/*     */   }
/*     */   
/*     */   public boolean isDefaultMethod() {
/* 448 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isInitializationMethod() {
/* 453 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isMethod() {
/* 458 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isNative() {
/* 463 */     if (this.binding != null)
/* 464 */       return this.binding.isNative(); 
/* 465 */     return ((this.modifiers & 0x100) != 0);
/*     */   }
/*     */   
/*     */   public RecordComponent getRecordComponent() {
/* 469 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isStatic() {
/* 474 */     if (this.binding != null)
/* 475 */       return this.binding.isStatic(); 
/* 476 */     return ((this.modifiers & 0x8) != 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract void parseStatements(Parser paramParser, CompilationUnitDeclaration paramCompilationUnitDeclaration);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public StringBuffer print(int tab, StringBuffer output) {
/* 489 */     if (this.javadoc != null) {
/* 490 */       this.javadoc.print(tab, output);
/*     */     }
/* 492 */     printIndent(tab, output);
/* 493 */     printModifiers(this.modifiers, output);
/* 494 */     if (this.annotations != null) {
/* 495 */       printAnnotations(this.annotations, output);
/* 496 */       output.append(' ');
/*     */     } 
/*     */     
/* 499 */     TypeParameter[] typeParams = typeParameters();
/* 500 */     if (typeParams != null) {
/* 501 */       output.append('<');
/* 502 */       int max = typeParams.length - 1;
/* 503 */       for (int j = 0; j < max; j++) {
/* 504 */         typeParams[j].print(0, output);
/* 505 */         output.append(", ");
/*     */       } 
/* 507 */       typeParams[max].print(0, output);
/* 508 */       output.append('>');
/*     */     } 
/*     */     
/* 511 */     printReturnType(0, output).append(this.selector).append('(');
/* 512 */     if (this.receiver != null) {
/* 513 */       this.receiver.print(0, output);
/*     */     }
/* 515 */     if (this.arguments != null) {
/* 516 */       for (int i = 0; i < this.arguments.length; i++) {
/* 517 */         if (i > 0 || this.receiver != null) output.append(", "); 
/* 518 */         this.arguments[i].print(0, output);
/*     */       } 
/*     */     }
/* 521 */     output.append(')');
/* 522 */     if (this.thrownExceptions != null) {
/* 523 */       output.append(" throws ");
/* 524 */       for (int i = 0; i < this.thrownExceptions.length; i++) {
/* 525 */         if (i > 0) output.append(", "); 
/* 526 */         this.thrownExceptions[i].print(0, output);
/*     */       } 
/*     */     } 
/* 529 */     printBody(tab + 1, output);
/* 530 */     return output;
/*     */   }
/*     */ 
/*     */   
/*     */   public StringBuffer printBody(int indent, StringBuffer output) {
/* 535 */     if (isAbstract() || (this.modifiers & 0x1000000) != 0) {
/* 536 */       return output.append(';');
/*     */     }
/* 538 */     output.append(" {");
/* 539 */     if (this.statements != null) {
/* 540 */       for (int i = 0; i < this.statements.length; i++) {
/* 541 */         output.append('\n');
/* 542 */         this.statements[i].printStatement(indent, output);
/*     */       } 
/*     */     }
/* 545 */     output.append('\n');
/* 546 */     printIndent((indent == 0) ? 0 : (indent - 1), output).append('}');
/* 547 */     return output;
/*     */   }
/*     */ 
/*     */   
/*     */   public StringBuffer printReturnType(int indent, StringBuffer output) {
/* 552 */     return output;
/*     */   }
/*     */ 
/*     */   
/*     */   public void resolve(ClassScope upperScope) {
/* 557 */     if (this.binding == null) {
/* 558 */       this.ignoreFurtherInvestigation = true;
/*     */     }
/*     */     
/*     */     try {
/* 562 */       bindArguments();
/* 563 */       resolveReceiver();
/* 564 */       bindThrownExceptions();
/* 565 */       resolveAnnotations((BlockScope)this.scope, this.annotations, (Binding)this.binding, isConstructor());
/*     */       
/* 567 */       long sourceLevel = (this.scope.compilerOptions()).sourceLevel;
/* 568 */       if (sourceLevel < 3407872L) {
/* 569 */         validateNullAnnotations(this.scope.environment().usesNullTypeAnnotations());
/*     */       }
/* 571 */       resolveStatements();
/*     */       
/* 573 */       if (this.binding != null && (
/* 574 */         this.binding.getAnnotationTagBits() & 0x400000000000L) == 0L && (
/* 575 */         this.binding.modifiers & 0x100000) != 0 && 
/* 576 */         sourceLevel >= 3211264L) {
/* 577 */         this.scope.problemReporter().missingDeprecatedAnnotationForMethod(this);
/*     */       }
/* 579 */     } catch (AbortMethod abortMethod) {
/*     */       
/* 581 */       this.ignoreFurtherInvestigation = true;
/*     */     } 
/*     */   }
/*     */   
/*     */   public void resolveReceiver() {
/* 586 */     if (this.receiver == null)
/*     */       return; 
/* 588 */     if (this.receiver.modifiers != 0) {
/* 589 */       this.scope.problemReporter().illegalModifiers(this.receiver.declarationSourceStart, this.receiver.declarationSourceEnd);
/*     */     }
/*     */     
/* 592 */     TypeBinding resolvedReceiverType = this.receiver.type.resolvedType;
/* 593 */     if (this.binding == null || resolvedReceiverType == null || !resolvedReceiverType.isValidBinding()) {
/*     */       return;
/*     */     }
/*     */     
/* 597 */     ReferenceBinding declaringClass = this.binding.declaringClass;
/*     */     
/* 599 */     if (isStatic() || declaringClass.isAnonymousType()) {
/* 600 */       this.scope.problemReporter().disallowedThisParameter(this.receiver);
/*     */       
/*     */       return;
/*     */     } 
/* 604 */     ReferenceBinding enclosingReceiver = this.scope.enclosingReceiverType();
/* 605 */     if (isConstructor()) {
/*     */       
/* 607 */       if (declaringClass.isStatic() || (
/* 608 */         declaringClass.tagBits & 0x18L) == 0L) {
/* 609 */         this.scope.problemReporter().disallowedThisParameter(this.receiver);
/*     */         return;
/*     */       } 
/* 612 */       enclosingReceiver = enclosingReceiver.enclosingType();
/*     */     } 
/*     */     
/* 615 */     char[][] tokens = (this.receiver.qualifyingName == null) ? null : this.receiver.qualifyingName.getName();
/* 616 */     if (isConstructor()) {
/* 617 */       if (tokens == null || tokens.length > 1 || !CharOperation.equals(enclosingReceiver.sourceName(), tokens[0])) {
/* 618 */         this.scope.problemReporter().illegalQualifierForExplicitThis(this.receiver, (TypeBinding)enclosingReceiver);
/* 619 */         this.receiver.qualifyingName = null;
/*     */       } 
/* 621 */     } else if (tokens != null && tokens.length > 0) {
/* 622 */       this.scope.problemReporter().illegalQualifierForExplicitThis2(this.receiver);
/* 623 */       this.receiver.qualifyingName = null;
/*     */     } 
/*     */     
/* 626 */     if (TypeBinding.notEquals((TypeBinding)enclosingReceiver, resolvedReceiverType)) {
/* 627 */       this.scope.problemReporter().illegalTypeForExplicitThis(this.receiver, (TypeBinding)enclosingReceiver);
/*     */     }
/*     */     
/* 630 */     if (this.receiver.type.hasNullTypeAnnotation(TypeReference.AnnotationPosition.ANY)) {
/* 631 */       this.scope.problemReporter().nullAnnotationUnsupportedLocation(this.receiver.type);
/*     */     }
/*     */   }
/*     */   
/*     */   public void resolveJavadoc() {
/* 636 */     if (this.binding == null)
/* 637 */       return;  if (this.javadoc != null) {
/* 638 */       this.javadoc.resolve(this.scope);
/*     */       return;
/*     */     } 
/* 641 */     if (this.binding.declaringClass != null && !this.binding.declaringClass.isLocalType()) {
/*     */       
/* 643 */       int javadocVisibility = this.binding.modifiers & 0x7;
/* 644 */       ClassScope classScope = this.scope.classScope();
/* 645 */       ProblemReporter reporter = this.scope.problemReporter();
/* 646 */       int severity = reporter.computeSeverity(-1610612250);
/* 647 */       if (severity != 256) {
/* 648 */         if (classScope != null) {
/* 649 */           javadocVisibility = Util.computeOuterMostVisibility(classScope.referenceType(), javadocVisibility);
/*     */         }
/* 651 */         int javadocModifiers = this.binding.modifiers & 0xFFFFFFF8 | javadocVisibility;
/* 652 */         reporter.javadocMissing(this.sourceStart, this.sourceEnd, severity, javadocModifiers);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void resolveStatements() {
/* 659 */     if (this.statements != null) {
/* 660 */       for (int i = 0, length = this.statements.length; i < length; i++) {
/* 661 */         Statement stmt = this.statements[i];
/* 662 */         stmt.resolve((BlockScope)this.scope);
/*     */       } 
/* 664 */     } else if ((this.bits & 0x8) != 0 && (
/* 665 */       !isConstructor() || this.arguments != null)) {
/* 666 */       this.scope.problemReporter().undocumentedEmptyBlock(this.bodyStart - 1, this.bodyEnd + 1);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void tagAsHavingErrors() {
/* 673 */     this.ignoreFurtherInvestigation = true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void tagAsHavingIgnoredMandatoryErrors(int problemId) {}
/*     */ 
/*     */ 
/*     */   
/*     */   public void traverse(ASTVisitor visitor, ClassScope classScope) {}
/*     */ 
/*     */ 
/*     */   
/*     */   public TypeParameter[] typeParameters() {
/* 688 */     return null;
/*     */   }
/*     */   
/*     */   void validateNullAnnotations(boolean useTypeAnnotations) {
/* 692 */     if (this.binding == null)
/*     */       return; 
/* 694 */     if (!useTypeAnnotations) {
/* 695 */       if (this.binding.parameterNonNullness != null) {
/* 696 */         int length = this.binding.parameters.length;
/* 697 */         for (int i = 0; i < length; i++) {
/* 698 */           if (this.binding.parameterNonNullness[i] != null) {
/* 699 */             long nullAnnotationTagBit = this.binding.parameterNonNullness[i].booleanValue() ? 
/* 700 */               72057594037927936L : 36028797018963968L;
/* 701 */             if (!this.scope.validateNullAnnotation(nullAnnotationTagBit, (this.arguments[i]).type, (this.arguments[i]).annotations))
/* 702 */               this.binding.parameterNonNullness[i] = null; 
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } else {
/* 707 */       int length = this.binding.parameters.length;
/* 708 */       for (int i = 0; i < length; i++)
/* 709 */         this.scope.validateNullAnnotation((this.binding.parameters[i]).tagBits, (this.arguments[i]).type, (this.arguments[i]).annotations); 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\ast\AbstractMethodDeclaration.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */