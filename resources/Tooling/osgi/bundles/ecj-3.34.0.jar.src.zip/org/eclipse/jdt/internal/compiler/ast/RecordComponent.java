/*     */ package org.eclipse.jdt.internal.compiler.ast;
/*     */ 
/*     */ import java.util.List;
/*     */ import org.eclipse.jdt.internal.compiler.ASTVisitor;
/*     */ import org.eclipse.jdt.internal.compiler.codegen.AnnotationContext;
/*     */ import org.eclipse.jdt.internal.compiler.codegen.CodeStream;
/*     */ import org.eclipse.jdt.internal.compiler.flow.FlowContext;
/*     */ import org.eclipse.jdt.internal.compiler.flow.FlowInfo;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.Binding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.BlockScope;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.MethodBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.RecordComponentBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.SyntheticMethodBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.TypeBinding;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RecordComponent
/*     */   extends AbstractVariableDeclaration
/*     */ {
/*     */   public RecordComponentBinding binding;
/*     */   
/*     */   public RecordComponent(char[] name, int sourceStart, int sourceEnd) {
/*  33 */     this.name = name;
/*  34 */     this.sourceStart = sourceStart;
/*  35 */     this.sourceEnd = sourceEnd;
/*  36 */     this.declarationEnd = sourceEnd;
/*     */   }
/*     */   public RecordComponent(char[] name, long posNom, TypeReference tr, int modifiers) {
/*  39 */     this(name, (int)(posNom >>> 32L), (int)posNom);
/*  40 */     this.declarationSourceEnd = (int)posNom;
/*  41 */     this.modifiers = modifiers;
/*  42 */     this.type = tr;
/*  43 */     if (tr != null) {
/*  44 */       this.bits |= tr.bits & 0x100000;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public FlowInfo analyseCode(BlockScope currentScope, FlowContext flowContext, FlowInfo flowInfo) {
/*  51 */     return flowInfo;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void checkModifiers() {
/*  57 */     if ((this.modifiers & 0xFFFF & 0xFFFFFFEF) != 0)
/*     */     {
/*     */ 
/*     */ 
/*     */       
/*  62 */       this.modifiers = this.modifiers & 0xFFBFFFFF | 0x800000;
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void generateCode(BlockScope currentScope, CodeStream codeStream) {
/*  68 */     if ((this.bits & Integer.MIN_VALUE) == 0) {
/*     */       return;
/*     */     }
/*  71 */     codeStream.recordPositionsFrom(codeStream.position, this.sourceStart);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getKind() {
/*  79 */     return 7;
/*     */   }
/*     */   
/*     */   public void getAllAnnotationContexts(int targetType, List<AnnotationContext> allAnnotationContexts) {
/*  83 */     TypeReference.AnnotationCollector collector = new TypeReference.AnnotationCollector(this, targetType, allAnnotationContexts);
/*  84 */     traverse(collector, (BlockScope)null);
/*     */   }
/*     */   
/*     */   public boolean isVarArgs() {
/*  88 */     return (this.type != null && (this.type.bits & 0x4000) != 0);
/*     */   }
/*     */ 
/*     */   
/*     */   public void resolve(BlockScope scope) {
/*  93 */     resolveAnnotations(scope, this.annotations, (Binding)this.binding);
/*     */     
/*  95 */     if (this.annotations != null) {
/*  96 */       for (int i = 0, max = this.annotations.length; i < max; i++) {
/*  97 */         TypeBinding resolvedAnnotationType = (this.annotations[i]).resolvedType;
/*  98 */         if (resolvedAnnotationType != null && (resolvedAnnotationType.getAnnotationTagBits() & 0x20000000000000L) != 0L) {
/*  99 */           this.bits |= 0x100000;
/*     */           
/* 101 */           if (this.binding != null && this.binding.declaringRecord != null) {
/* 102 */             byte b; int j; MethodBinding[] arrayOfMethodBinding; for (j = (arrayOfMethodBinding = this.binding.declaringRecord.methods()).length, b = 0; b < j; ) { MethodBinding methodBinding = arrayOfMethodBinding[b];
/* 103 */               if (methodBinding instanceof SyntheticMethodBinding) {
/* 104 */                 SyntheticMethodBinding smb = (SyntheticMethodBinding)methodBinding;
/* 105 */                 if (smb.purpose == 1 && smb.recordComponentBinding == this.binding) {
/* 106 */                   smb.returnType = this.binding.type;
/*     */                   break;
/*     */                 } 
/*     */               } 
/*     */               b++; }
/*     */           
/*     */           } 
/*     */           break;
/*     */         } 
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void validateNullAnnotations(BlockScope scope) {
/* 125 */     if (!scope.validateNullAnnotation(this.binding.tagBits, this.type, this.annotations)) {
/* 126 */       this.binding.tagBits &= 0xFE7FFFFFFFFFFFFFL;
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public StringBuffer print(int indent, StringBuffer output) {
/* 132 */     printIndent(indent, output);
/* 133 */     printModifiers(this.modifiers, output);
/* 134 */     if (this.annotations != null) {
/* 135 */       printAnnotations(this.annotations, output);
/* 136 */       output.append(' ');
/*     */     } 
/*     */     
/* 139 */     if (this.type == null) {
/* 140 */       output.append("<no type> ");
/*     */     } else {
/* 142 */       this.type.print(0, output).append(' ');
/*     */     } 
/* 144 */     return output.append(this.name);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public StringBuffer printStatement(int indent, StringBuffer output) {
/* 150 */     return print(indent, output).append(';');
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void traverse(ASTVisitor visitor, BlockScope scope) {
/* 156 */     if (visitor.visit(this, scope)) {
/* 157 */       if (this.annotations != null) {
/* 158 */         int annotationsLength = this.annotations.length;
/* 159 */         for (int i = 0; i < annotationsLength; i++)
/* 160 */           this.annotations[i].traverse(visitor, scope); 
/*     */       } 
/* 162 */       this.type.traverse(visitor, scope);
/* 163 */       if (this.initialization != null)
/* 164 */         this.initialization.traverse(visitor, scope); 
/*     */     } 
/* 166 */     visitor.endVisit(this, scope);
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\ast\RecordComponent.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */