/*    */ package org.eclipse.jdt.internal.compiler.env;
/*    */ 
/*    */ import java.util.Arrays;
/*    */ import org.eclipse.jdt.core.compiler.CharOperation;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ClassSignature
/*    */ {
/*    */   char[] className;
/*    */   
/*    */   public ClassSignature(char[] className) {
/* 30 */     this.className = className;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public char[] getTypeName() {
/* 37 */     return this.className;
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 42 */     StringBuilder buffer = new StringBuilder();
/* 43 */     buffer.append(this.className);
/* 44 */     buffer.append(".class");
/* 45 */     return buffer.toString();
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public int hashCode() {
/* 51 */     int result = 1;
/* 52 */     result = 31 * result + CharOperation.hashCode(this.className);
/* 53 */     return result;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean equals(Object obj) {
/* 58 */     if (this == obj) {
/* 59 */       return true;
/*    */     }
/* 61 */     if (obj == null) {
/* 62 */       return false;
/*    */     }
/* 64 */     if (getClass() != obj.getClass()) {
/* 65 */       return false;
/*    */     }
/* 67 */     ClassSignature other = (ClassSignature)obj;
/* 68 */     return Arrays.equals(this.className, other.className);
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\env\ClassSignature.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */