/*     */ package org.eclipse.jdt.internal.compiler.apt.model;
/*     */ 
/*     */ import java.lang.reflect.Array;
/*     */ import java.lang.reflect.Field;
/*     */ import java.lang.reflect.InvocationHandler;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Proxy;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import javax.lang.model.element.AnnotationMirror;
/*     */ import javax.lang.model.element.AnnotationValue;
/*     */ import javax.lang.model.element.ExecutableElement;
/*     */ import javax.lang.model.type.DeclaredType;
/*     */ import javax.lang.model.type.MirroredTypeException;
/*     */ import javax.lang.model.type.MirroredTypesException;
/*     */ import javax.lang.model.type.TypeMirror;
/*     */ import org.eclipse.jdt.internal.compiler.apt.dispatch.BaseProcessingEnvImpl;
/*     */ import org.eclipse.jdt.internal.compiler.impl.Constant;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.AnnotationBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.ArrayBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.Binding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.ElementValuePair;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.FieldBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.MethodBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.ReferenceBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.TypeBinding;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AnnotationMirrorImpl
/*     */   implements AnnotationMirror, InvocationHandler
/*     */ {
/*     */   public final BaseProcessingEnvImpl _env;
/*     */   public final AnnotationBinding _binding;
/*     */   
/*     */   AnnotationMirrorImpl(BaseProcessingEnvImpl env, AnnotationBinding binding) {
/*  55 */     this._env = env;
/*  56 */     this._binding = binding;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object obj) {
/*  61 */     if (obj instanceof AnnotationMirrorImpl) {
/*  62 */       if (this._binding == null) {
/*  63 */         return (((AnnotationMirrorImpl)obj)._binding == null);
/*     */       }
/*  65 */       return equals(this._binding, ((AnnotationMirrorImpl)obj)._binding);
/*     */     } 
/*  67 */     return (obj == null) ? false : obj.equals(this);
/*     */   }
/*     */   
/*     */   private static boolean equals(AnnotationBinding annotationBinding, AnnotationBinding annotationBinding2) {
/*  71 */     if (annotationBinding.getAnnotationType() != annotationBinding2.getAnnotationType()) return false; 
/*  72 */     ElementValuePair[] elementValuePairs = annotationBinding.getElementValuePairs();
/*  73 */     ElementValuePair[] elementValuePairs2 = annotationBinding2.getElementValuePairs();
/*  74 */     int length = elementValuePairs.length;
/*  75 */     if (length != elementValuePairs2.length) return false; 
/*  76 */     for (int i = 0; i < length; i++)
/*  77 */     { ElementValuePair pair = elementValuePairs[i];
/*     */       
/*  79 */       int j = 0; while (true) { if (j >= length)
/*     */         {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 100 */           return false; }  ElementValuePair pair2 = elementValuePairs2[j]; if (pair.binding == pair2.binding) { if (pair.value == null) { if (pair2.value == null) break;  return false; }  if (pair2.value == null) return false;  if (pair2.value instanceof Object[] && pair.value instanceof Object[]) { if (!Arrays.equals((Object[])pair.value, (Object[])pair2.value))
/*     */               return false;  break; }  if (!pair2.value.equals(pair.value))
/* 102 */             return false;  break; }  j++; }  }  return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public DeclaredType getAnnotationType() {
/* 107 */     return (DeclaredType)this._env.getFactory().newTypeMirror((Binding)this._binding.getAnnotationType());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<? extends ExecutableElement, ? extends AnnotationValue> getElementValues() {
/* 116 */     if (this._binding == null) {
/* 117 */       return Collections.emptyMap();
/*     */     }
/* 119 */     ElementValuePair[] pairs = this._binding.getElementValuePairs();
/* 120 */     Map<ExecutableElement, AnnotationValue> valueMap = 
/* 121 */       new LinkedHashMap<>(pairs.length); byte b; int i; ElementValuePair[] arrayOfElementValuePair1;
/* 122 */     for (i = (arrayOfElementValuePair1 = pairs).length, b = 0; b < i; ) { ElementValuePair pair = arrayOfElementValuePair1[b];
/* 123 */       MethodBinding method = pair.getMethodBinding();
/* 124 */       if (method != null) {
/*     */ 
/*     */ 
/*     */         
/* 128 */         ExecutableElement e = new ExecutableElementImpl(this._env, method);
/* 129 */         AnnotationValue v = new AnnotationMemberValue(this._env, pair.getValue(), method);
/* 130 */         valueMap.put(e, v);
/*     */       }  b++; }
/* 132 */      return Collections.unmodifiableMap(valueMap);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<? extends ExecutableElement, ? extends AnnotationValue> getElementValuesWithDefaults() {
/* 141 */     if (this._binding == null) {
/* 142 */       return Collections.emptyMap();
/*     */     }
/* 144 */     ElementValuePair[] pairs = this._binding.getElementValuePairs();
/* 145 */     ReferenceBinding annoType = this._binding.getAnnotationType();
/* 146 */     Map<ExecutableElement, AnnotationValue> valueMap = 
/* 147 */       new LinkedHashMap<>(); byte b; int i; MethodBinding[] arrayOfMethodBinding;
/* 148 */     for (i = (arrayOfMethodBinding = annoType.methods()).length, b = 0; b < i; ) { MethodBinding method = arrayOfMethodBinding[b];
/*     */       
/* 150 */       boolean foundExplicitValue = false;
/* 151 */       for (int j = 0; j < pairs.length; j++) {
/* 152 */         MethodBinding explicitBinding = pairs[j].getMethodBinding();
/* 153 */         if (method == explicitBinding) {
/* 154 */           ExecutableElement e = new ExecutableElementImpl(this._env, explicitBinding);
/* 155 */           AnnotationValue v = new AnnotationMemberValue(this._env, pairs[j].getValue(), explicitBinding);
/* 156 */           valueMap.put(e, v);
/* 157 */           foundExplicitValue = true;
/*     */           
/*     */           break;
/*     */         } 
/*     */       } 
/* 162 */       if (!foundExplicitValue) {
/* 163 */         Object defaultVal = method.getDefaultValue();
/* 164 */         if (defaultVal != null) {
/* 165 */           ExecutableElement e = new ExecutableElementImpl(this._env, method);
/* 166 */           AnnotationValue v = new AnnotationMemberValue(this._env, defaultVal, method);
/* 167 */           valueMap.put(e, v);
/*     */         } 
/*     */       }  b++; }
/*     */     
/* 171 */     return Collections.unmodifiableMap(valueMap);
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 176 */     if (this._binding == null) return this._env.hashCode(); 
/* 177 */     return this._binding.hashCode();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object invoke(Object proxy, Method method, Object[] args) throws Throwable {
/* 195 */     if (this._binding == null) return null; 
/* 196 */     String methodName = method.getName();
/* 197 */     if (args == null || args.length == 0) {
/* 198 */       if (methodName.equals("hashCode")) {
/* 199 */         return Integer.valueOf(hashCode());
/*     */       }
/* 201 */       if (methodName.equals("toString")) {
/* 202 */         return toString();
/*     */       }
/* 204 */       if (methodName.equals("annotationType")) {
/* 205 */         return proxy.getClass().getInterfaces()[0];
/*     */       }
/*     */     }
/* 208 */     else if (args.length == 1 && methodName.equals("equals")) {
/* 209 */       return Boolean.valueOf(equals(args[0]));
/*     */     } 
/*     */ 
/*     */     
/* 213 */     if (args != null && args.length != 0) {
/* 214 */       throw new NoSuchMethodException("method " + method.getName() + formatArgs(args) + " does not exist on annotation " + toString());
/*     */     }
/* 216 */     MethodBinding methodBinding = getMethodBinding(methodName);
/* 217 */     if (methodBinding == null) {
/* 218 */       throw new NoSuchMethodException("method " + method.getName() + "() does not exist on annotation" + toString());
/*     */     }
/*     */     
/* 221 */     Object actualValue = null;
/* 222 */     boolean foundMethod = false;
/* 223 */     ElementValuePair[] pairs = this._binding.getElementValuePairs(); byte b; int i; ElementValuePair[] arrayOfElementValuePair1;
/* 224 */     for (i = (arrayOfElementValuePair1 = pairs).length, b = 0; b < i; ) { ElementValuePair pair = arrayOfElementValuePair1[b];
/* 225 */       if (methodName.equals(new String(pair.getName()))) {
/* 226 */         actualValue = pair.getValue();
/* 227 */         foundMethod = true; break;
/*     */       } 
/*     */       b++; }
/*     */     
/* 231 */     if (!foundMethod)
/*     */     {
/* 233 */       actualValue = methodBinding.getDefaultValue();
/*     */     }
/* 235 */     Class<?> expectedType = method.getReturnType();
/* 236 */     TypeBinding actualType = methodBinding.returnType;
/* 237 */     return getReflectionValue(actualValue, actualType, expectedType);
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 242 */     TypeMirror decl = getAnnotationType();
/* 243 */     StringBuilder sb = new StringBuilder();
/* 244 */     sb.append('@');
/* 245 */     sb.append(decl.toString());
/* 246 */     Map<? extends ExecutableElement, ? extends AnnotationValue> values = getElementValues();
/* 247 */     if (!values.isEmpty()) {
/* 248 */       sb.append('(');
/* 249 */       boolean first = true;
/* 250 */       for (Map.Entry<? extends ExecutableElement, ? extends AnnotationValue> e : values.entrySet()) {
/* 251 */         if (!first) {
/* 252 */           sb.append(", ");
/*     */         }
/* 254 */         first = false;
/* 255 */         sb.append(((ExecutableElement)e.getKey()).getSimpleName());
/* 256 */         sb.append(" = ");
/* 257 */         sb.append(((AnnotationValue)e.getValue()).toString());
/*     */       } 
/* 259 */       sb.append(')');
/*     */     } 
/* 261 */     return sb.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String formatArgs(Object[] args) {
/* 271 */     StringBuilder builder = new StringBuilder(args.length * 8 + 2);
/* 272 */     builder.append('(');
/* 273 */     for (int i = 0; i < args.length; i++) {
/*     */       
/* 275 */       if (i > 0)
/* 276 */         builder.append(", "); 
/* 277 */       builder.append(args[i].getClass().getName());
/*     */     } 
/* 279 */     builder.append(')');
/* 280 */     return builder.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private MethodBinding getMethodBinding(String name) {
/* 288 */     ReferenceBinding annoType = this._binding.getAnnotationType();
/* 289 */     MethodBinding[] methods = annoType.getMethods(name.toCharArray()); byte b; int i; MethodBinding[] arrayOfMethodBinding1;
/* 290 */     for (i = (arrayOfMethodBinding1 = methods).length, b = 0; b < i; ) { MethodBinding method = arrayOfMethodBinding1[b];
/*     */       
/* 292 */       if (method.parameters.length == 0)
/* 293 */         return method; 
/*     */       b++; }
/*     */     
/* 296 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Object getReflectionValue(Object actualValue, TypeBinding actualType, Class<?> expectedType) {
/* 315 */     if (expectedType == null)
/*     */     {
/* 317 */       return null;
/*     */     }
/* 319 */     if (actualValue == null)
/*     */     {
/* 321 */       return Factory.getMatchingDummyValue(expectedType);
/*     */     }
/* 323 */     if (expectedType.isArray()) {
/* 324 */       if (Class.class.equals(expectedType.getComponentType())) {
/*     */         
/* 326 */         if (actualType.isArrayType() && (((ArrayBinding)actualType).leafComponentType.erasure()).id == 16) {
/*     */           Object[] bindings;
/*     */           
/* 329 */           if (actualValue instanceof Object[]) {
/* 330 */             bindings = (Object[])actualValue;
/* 331 */           } else if (actualValue instanceof TypeBinding) {
/*     */             
/* 333 */             bindings = new Object[] { actualValue };
/*     */           } else {
/* 335 */             bindings = null;
/*     */           } 
/*     */           
/* 338 */           if (bindings != null) {
/* 339 */             List<TypeMirror> mirrors = new ArrayList<>(bindings.length);
/* 340 */             for (int i = 0; i < bindings.length; i++) {
/* 341 */               if (bindings[i] instanceof TypeBinding) {
/* 342 */                 mirrors.add(this._env.getFactory().newTypeMirror((Binding)bindings[i]));
/*     */               }
/*     */             } 
/* 345 */             throw new MirroredTypesException(mirrors);
/*     */           } 
/*     */         } 
/*     */         
/* 349 */         return null;
/*     */       } 
/*     */       
/* 352 */       return convertJDTArrayToReflectionArray(actualValue, actualType, expectedType);
/*     */     } 
/* 354 */     if (Class.class.equals(expectedType)) {
/*     */       
/* 356 */       if (actualValue instanceof TypeBinding) {
/* 357 */         TypeMirror mirror = this._env.getFactory().newTypeMirror((Binding)actualValue);
/* 358 */         throw new MirroredTypeException(mirror);
/*     */       } 
/*     */ 
/*     */       
/* 362 */       return null;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 367 */     return convertJDTValueToReflectionType(actualValue, actualType, expectedType);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Object convertJDTArrayToReflectionArray(Object jdtValue, TypeBinding jdtType, Class<?> expectedType) {
/*     */     Object[] jdtArray;
/* 385 */     assert expectedType != null && expectedType.isArray();
/* 386 */     if (!jdtType.isArrayType())
/*     */     {
/*     */       
/* 389 */       return null;
/*     */     }
/*     */ 
/*     */     
/* 393 */     if (jdtValue != null && !(jdtValue instanceof Object[])) {
/*     */       
/* 395 */       jdtArray = (Object[])Array.newInstance(jdtValue.getClass(), 1);
/* 396 */       jdtArray[0] = jdtValue;
/*     */     } else {
/* 398 */       jdtArray = (Object[])jdtValue;
/*     */     } 
/* 400 */     TypeBinding jdtLeafType = jdtType.leafComponentType();
/* 401 */     Class<?> expectedLeafType = expectedType.getComponentType();
/* 402 */     int length = jdtArray.length;
/* 403 */     Object returnArray = Array.newInstance(expectedLeafType, length);
/* 404 */     for (int i = 0; i < length; i++) {
/* 405 */       Object jdtElementValue = jdtArray[i];
/* 406 */       if (expectedLeafType.isPrimitive() || String.class.equals(expectedLeafType)) {
/* 407 */         if (jdtElementValue instanceof Constant) {
/* 408 */           if (boolean.class.equals(expectedLeafType)) {
/* 409 */             Array.setBoolean(returnArray, i, ((Constant)jdtElementValue).booleanValue());
/*     */           }
/* 411 */           else if (byte.class.equals(expectedLeafType)) {
/* 412 */             Array.setByte(returnArray, i, ((Constant)jdtElementValue).byteValue());
/*     */           }
/* 414 */           else if (char.class.equals(expectedLeafType)) {
/* 415 */             Array.setChar(returnArray, i, ((Constant)jdtElementValue).charValue());
/*     */           }
/* 417 */           else if (double.class.equals(expectedLeafType)) {
/* 418 */             Array.setDouble(returnArray, i, ((Constant)jdtElementValue).doubleValue());
/*     */           }
/* 420 */           else if (float.class.equals(expectedLeafType)) {
/* 421 */             Array.setFloat(returnArray, i, ((Constant)jdtElementValue).floatValue());
/*     */           }
/* 423 */           else if (int.class.equals(expectedLeafType)) {
/* 424 */             Array.setInt(returnArray, i, ((Constant)jdtElementValue).intValue());
/*     */           }
/* 426 */           else if (long.class.equals(expectedLeafType)) {
/* 427 */             Array.setLong(returnArray, i, ((Constant)jdtElementValue).longValue());
/*     */           }
/* 429 */           else if (short.class.equals(expectedLeafType)) {
/* 430 */             Array.setShort(returnArray, i, ((Constant)jdtElementValue).shortValue());
/*     */           }
/* 432 */           else if (String.class.equals(expectedLeafType)) {
/* 433 */             Array.set(returnArray, i, ((Constant)jdtElementValue).stringValue());
/*     */           }
/*     */         
/*     */         }
/*     */         else {
/*     */           
/* 439 */           Factory.setArrayMatchingDummyValue(returnArray, i, expectedLeafType);
/*     */         }
/*     */       
/* 442 */       } else if (expectedLeafType.isEnum()) {
/* 443 */         Object returnVal = null;
/* 444 */         if (jdtLeafType != null && jdtLeafType.isEnum() && jdtElementValue instanceof FieldBinding) {
/* 445 */           FieldBinding binding = (FieldBinding)jdtElementValue;
/*     */           try {
/* 447 */             Field returnedField = null;
/* 448 */             returnedField = expectedLeafType.getField(new String(binding.name));
/* 449 */             if (returnedField != null) {
/* 450 */               returnVal = returnedField.get(null);
/*     */             }
/*     */           }
/* 453 */           catch (NoSuchFieldException noSuchFieldException) {
/*     */ 
/*     */           
/* 456 */           } catch (IllegalAccessException illegalAccessException) {}
/*     */         } 
/*     */ 
/*     */         
/* 460 */         Array.set(returnArray, i, returnVal);
/*     */       }
/* 462 */       else if (expectedLeafType.isAnnotation()) {
/*     */         
/* 464 */         Object returnVal = null;
/* 465 */         if (jdtLeafType.isAnnotationType() && jdtElementValue instanceof AnnotationBinding) {
/* 466 */           AnnotationMirrorImpl annoMirror = 
/* 467 */             (AnnotationMirrorImpl)this._env.getFactory().newAnnotationMirror((AnnotationBinding)jdtElementValue);
/* 468 */           returnVal = Proxy.newProxyInstance(expectedLeafType.getClassLoader(), 
/* 469 */               new Class[] { expectedLeafType }, annoMirror);
/*     */         } 
/* 471 */         Array.set(returnArray, i, returnVal);
/*     */       } else {
/*     */         
/* 474 */         Array.set(returnArray, i, null);
/*     */       } 
/*     */     } 
/* 477 */     return returnArray;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Object convertJDTValueToReflectionType(Object jdtValue, TypeBinding actualType, Class<?> expectedType) {
/* 488 */     if (expectedType.isPrimitive() || String.class.equals(expectedType)) {
/* 489 */       if (jdtValue instanceof Constant) {
/* 490 */         if (boolean.class.equals(expectedType)) {
/* 491 */           return Boolean.valueOf(((Constant)jdtValue).booleanValue());
/*     */         }
/* 493 */         if (byte.class.equals(expectedType)) {
/* 494 */           return Byte.valueOf(((Constant)jdtValue).byteValue());
/*     */         }
/* 496 */         if (char.class.equals(expectedType)) {
/* 497 */           return Character.valueOf(((Constant)jdtValue).charValue());
/*     */         }
/* 499 */         if (double.class.equals(expectedType)) {
/* 500 */           return Double.valueOf(((Constant)jdtValue).doubleValue());
/*     */         }
/* 502 */         if (float.class.equals(expectedType)) {
/* 503 */           return Float.valueOf(((Constant)jdtValue).floatValue());
/*     */         }
/* 505 */         if (int.class.equals(expectedType)) {
/* 506 */           return Integer.valueOf(((Constant)jdtValue).intValue());
/*     */         }
/* 508 */         if (long.class.equals(expectedType)) {
/* 509 */           return Long.valueOf(((Constant)jdtValue).longValue());
/*     */         }
/* 511 */         if (short.class.equals(expectedType)) {
/* 512 */           return Short.valueOf(((Constant)jdtValue).shortValue());
/*     */         }
/* 514 */         if (String.class.equals(expectedType)) {
/* 515 */           return ((Constant)jdtValue).stringValue();
/*     */         }
/*     */       } 
/*     */ 
/*     */       
/* 520 */       return Factory.getMatchingDummyValue(expectedType);
/*     */     } 
/* 522 */     if (expectedType.isEnum()) {
/* 523 */       Object returnVal = null;
/* 524 */       if (actualType != null && actualType.isEnum() && jdtValue instanceof FieldBinding) {
/*     */         
/* 526 */         FieldBinding binding = (FieldBinding)jdtValue;
/*     */         try {
/* 528 */           Field returnedField = null;
/* 529 */           returnedField = expectedType.getField(new String(binding.name));
/* 530 */           if (returnedField != null) {
/* 531 */             returnVal = returnedField.get(null);
/*     */           }
/*     */         }
/* 534 */         catch (NoSuchFieldException noSuchFieldException) {
/*     */ 
/*     */         
/* 537 */         } catch (IllegalAccessException illegalAccessException) {}
/*     */       } 
/*     */ 
/*     */       
/* 541 */       return (returnVal == null) ? Factory.getMatchingDummyValue(expectedType) : returnVal;
/*     */     } 
/* 543 */     if (expectedType.isAnnotation()) {
/*     */       
/* 545 */       if (actualType.isAnnotationType() && jdtValue instanceof AnnotationBinding) {
/* 546 */         AnnotationMirrorImpl annoMirror = 
/* 547 */           (AnnotationMirrorImpl)this._env.getFactory().newAnnotationMirror((AnnotationBinding)jdtValue);
/* 548 */         return Proxy.newProxyInstance(expectedType.getClassLoader(), 
/* 549 */             new Class[] { expectedType }, annoMirror);
/*     */       } 
/*     */ 
/*     */       
/* 553 */       return null;
/*     */     } 
/*     */ 
/*     */     
/* 557 */     return Factory.getMatchingDummyValue(expectedType);
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\apt\model\AnnotationMirrorImpl.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */