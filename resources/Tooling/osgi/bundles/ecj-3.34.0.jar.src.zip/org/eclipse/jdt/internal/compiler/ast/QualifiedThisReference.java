/*     */ package org.eclipse.jdt.internal.compiler.ast;
/*     */ 
/*     */ import org.eclipse.jdt.internal.compiler.ASTVisitor;
/*     */ import org.eclipse.jdt.internal.compiler.codegen.CodeStream;
/*     */ import org.eclipse.jdt.internal.compiler.flow.FlowContext;
/*     */ import org.eclipse.jdt.internal.compiler.flow.FlowInfo;
/*     */ import org.eclipse.jdt.internal.compiler.impl.Constant;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.Binding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.BlockScope;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.ClassScope;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.MethodBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.MethodScope;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.ReferenceBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.Scope;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.TypeBinding;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class QualifiedThisReference
/*     */   extends ThisReference
/*     */ {
/*     */   public TypeReference qualification;
/*     */   ReferenceBinding currentCompatibleType;
/*     */   
/*     */   public QualifiedThisReference(TypeReference name, int sourceStart, int sourceEnd) {
/*  34 */     super(sourceStart, sourceEnd);
/*  35 */     this.qualification = name;
/*  36 */     name.bits |= 0x40000000;
/*  37 */     this.sourceStart = name.sourceStart;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public FlowInfo analyseCode(BlockScope currentScope, FlowContext flowContext, FlowInfo flowInfo) {
/*  46 */     return flowInfo;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public FlowInfo analyseCode(BlockScope currentScope, FlowContext flowContext, FlowInfo flowInfo, boolean valueRequired) {
/*  56 */     return flowInfo;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void generateCode(BlockScope currentScope, CodeStream codeStream, boolean valueRequired) {
/*  72 */     int pc = codeStream.position;
/*  73 */     if (valueRequired) {
/*  74 */       if ((this.bits & 0x1FE0) != 0) {
/*  75 */         Object[] emulationPath = 
/*  76 */           currentScope.getEmulationPath(this.currentCompatibleType, true, false);
/*  77 */         codeStream.generateOuterAccess(emulationPath, this, (Binding)this.currentCompatibleType, (Scope)currentScope);
/*     */       } else {
/*     */         
/*  80 */         codeStream.aload_0();
/*     */       } 
/*     */     }
/*  83 */     codeStream.recordPositionsFrom(pc, this.sourceStart);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public TypeBinding resolveType(BlockScope scope) {
/*  89 */     this.constant = Constant.NotAConstant;
/*     */     
/*  91 */     TypeBinding type = this.qualification.resolveType(scope, true);
/*  92 */     if (type == null || !type.isValidBinding()) return null;
/*     */     
/*  94 */     type = type.erasure();
/*     */ 
/*     */     
/*  97 */     if (type instanceof ReferenceBinding) {
/*  98 */       this.resolvedType = (TypeBinding)scope.environment().convertToParameterizedType((ReferenceBinding)type);
/*     */     } else {
/*     */       
/* 101 */       this.resolvedType = type;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 106 */     int depth = findCompatibleEnclosing((ReferenceBinding)(scope.referenceType()).binding, type, scope);
/* 107 */     this.bits &= 0xFFFFE01F;
/* 108 */     this.bits |= (depth & 0xFF) << 5;
/*     */     
/* 110 */     if (this.currentCompatibleType == null) {
/* 111 */       if (this.resolvedType.isValidBinding()) {
/* 112 */         scope.problemReporter().noSuchEnclosingInstance(type, this, false);
/*     */       }
/* 114 */       return this.resolvedType;
/*     */     } 
/* 116 */     scope.tagAsAccessingEnclosingInstanceStateOf(this.currentCompatibleType, false);
/*     */ 
/*     */ 
/*     */     
/* 120 */     if (depth == 0) {
/* 121 */       checkAccess(scope, (ReferenceBinding)null);
/*     */     }
/* 123 */     else if ((scope.compilerOptions()).complianceLevel >= 3932160L) {
/* 124 */       MethodScope ms = scope.methodScope();
/* 125 */       if (ms.isStatic)
/* 126 */         ms.problemReporter().errorThisSuperInStatic(this); 
/*     */     } 
/* 128 */     MethodScope methodScope = scope.namedMethodScope();
/* 129 */     if (methodScope != null) {
/* 130 */       MethodBinding method = methodScope.referenceMethodBinding();
/* 131 */       if (method != null) {
/* 132 */         TypeBinding receiver = method.receiver;
/* 133 */         while (receiver != null) {
/* 134 */           if (TypeBinding.equalsEquals(receiver, this.resolvedType))
/* 135 */             return this.resolvedType = receiver; 
/* 136 */           ReferenceBinding referenceBinding = receiver.enclosingType();
/*     */         } 
/*     */       } 
/*     */     } 
/* 140 */     return this.resolvedType;
/*     */   }
/*     */   
/*     */   int findCompatibleEnclosing(ReferenceBinding enclosingType, TypeBinding type, BlockScope scope) {
/* 144 */     int depth = 0;
/* 145 */     this.currentCompatibleType = enclosingType;
/* 146 */     while (this.currentCompatibleType != null && TypeBinding.notEquals((TypeBinding)this.currentCompatibleType, type)) {
/* 147 */       depth++;
/* 148 */       this.currentCompatibleType = this.currentCompatibleType.isStatic() ? null : this.currentCompatibleType.enclosingType();
/*     */     } 
/* 150 */     return depth;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public StringBuffer printExpression(int indent, StringBuffer output) {
/* 156 */     return this.qualification.print(0, output).append(".this");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void traverse(ASTVisitor visitor, BlockScope blockScope) {
/* 164 */     if (visitor.visit(this, blockScope)) {
/* 165 */       this.qualification.traverse(visitor, blockScope);
/*     */     }
/* 167 */     visitor.endVisit(this, blockScope);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void traverse(ASTVisitor visitor, ClassScope blockScope) {
/* 175 */     if (visitor.visit(this, blockScope)) {
/* 176 */       this.qualification.traverse(visitor, blockScope);
/*     */     }
/* 178 */     visitor.endVisit(this, blockScope);
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\ast\QualifiedThisReference.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */