/*     */ package org.eclipse.jdt.internal.compiler.ast;
/*     */ 
/*     */ import org.eclipse.jdt.internal.compiler.ASTVisitor;
/*     */ import org.eclipse.jdt.internal.compiler.codegen.BranchLabel;
/*     */ import org.eclipse.jdt.internal.compiler.codegen.CodeStream;
/*     */ import org.eclipse.jdt.internal.compiler.flow.FlowContext;
/*     */ import org.eclipse.jdt.internal.compiler.flow.FlowInfo;
/*     */ import org.eclipse.jdt.internal.compiler.flow.UnconditionalFlowInfo;
/*     */ import org.eclipse.jdt.internal.compiler.impl.Constant;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.BlockScope;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.LocalVariableBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.Scope;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.TypeBinding;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class IfStatement
/*     */   extends Statement
/*     */ {
/*     */   public Expression condition;
/*     */   public Statement thenStatement;
/*     */   public Statement elseStatement;
/*  38 */   int thenInitStateIndex = -1;
/*  39 */   int elseInitStateIndex = -1;
/*  40 */   int mergedInitStateIndex = -1;
/*     */   
/*     */   public IfStatement(Expression condition, Statement thenStatement, int sourceStart, int sourceEnd) {
/*  43 */     this.condition = condition;
/*  44 */     this.thenStatement = thenStatement;
/*     */     
/*  46 */     if (thenStatement instanceof EmptyStatement) thenStatement.bits |= 0x1; 
/*  47 */     this.sourceStart = sourceStart;
/*  48 */     this.sourceEnd = sourceEnd;
/*     */   }
/*     */   
/*     */   public IfStatement(Expression condition, Statement thenStatement, Statement elseStatement, int sourceStart, int sourceEnd) {
/*  52 */     this.condition = condition;
/*  53 */     this.thenStatement = thenStatement;
/*     */     
/*  55 */     if (thenStatement instanceof EmptyStatement) thenStatement.bits |= 0x1; 
/*  56 */     this.elseStatement = elseStatement;
/*  57 */     if (elseStatement instanceof IfStatement) elseStatement.bits |= 0x20000000; 
/*  58 */     if (elseStatement instanceof EmptyStatement) elseStatement.bits |= 0x1; 
/*  59 */     this.sourceStart = sourceStart;
/*  60 */     this.sourceEnd = sourceEnd;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public FlowInfo analyseCode(BlockScope currentScope, FlowContext flowContext, FlowInfo flowInfo) {
/*  66 */     FlowInfo conditionFlowInfo = this.condition.analyseCode(currentScope, flowContext, flowInfo);
/*  67 */     int initialComplaintLevel = ((flowInfo.reachMode() & 0x3) != 0) ? 1 : 0;
/*     */     
/*  69 */     Constant cst = this.condition.optimizedBooleanConstant();
/*  70 */     this.condition.checkNPEbyUnboxing(currentScope, flowContext, flowInfo);
/*  71 */     boolean isConditionOptimizedTrue = (cst != Constant.NotAConstant && cst.booleanValue());
/*  72 */     boolean isConditionOptimizedFalse = (cst != Constant.NotAConstant && !cst.booleanValue());
/*     */     
/*  74 */     flowContext.conditionalLevel++;
/*     */ 
/*     */     
/*  77 */     FlowInfo thenFlowInfo = conditionFlowInfo.safeInitsWhenTrue();
/*  78 */     if (isConditionOptimizedFalse) {
/*  79 */       thenFlowInfo.setReachMode(1);
/*     */     }
/*  81 */     FlowInfo elseFlowInfo = conditionFlowInfo.initsWhenFalse().copy();
/*  82 */     if (isConditionOptimizedTrue) {
/*  83 */       elseFlowInfo.setReachMode(1);
/*     */     }
/*  85 */     if ((flowInfo.tagBits & 0x3) == 0 && (
/*  86 */       thenFlowInfo.tagBits & 0x3) != 0) {
/*     */ 
/*     */       
/*  89 */       this.bits |= 0x100;
/*  90 */     } else if ((flowInfo.tagBits & 0x3) == 0 && (
/*  91 */       elseFlowInfo.tagBits & 0x3) != 0) {
/*     */ 
/*     */       
/*  94 */       this.bits |= 0x80;
/*     */     } 
/*  96 */     boolean reportDeadCodeForKnownPattern = !(isKnowDeadCodePattern(this.condition) && !(currentScope.compilerOptions()).reportDeadCodeInTrivialIfStatement);
/*  97 */     if (this.thenStatement != null) {
/*     */       
/*  99 */       this.thenInitStateIndex = currentScope.methodScope().recordInitializationStates(thenFlowInfo);
/* 100 */       if (isConditionOptimizedFalse || (this.bits & 0x100) != 0) {
/* 101 */         if (reportDeadCodeForKnownPattern) {
/* 102 */           this.thenStatement.complainIfUnreachable(thenFlowInfo, currentScope, initialComplaintLevel, false);
/*     */         }
/*     */         else {
/*     */           
/* 106 */           this.bits &= 0xFFFFFEFF;
/*     */         } 
/*     */       }
/* 109 */       this.condition.updateFlowOnBooleanResult(thenFlowInfo, true);
/* 110 */       thenFlowInfo = this.thenStatement.analyseCode(currentScope, flowContext, thenFlowInfo);
/* 111 */       if (!(this.thenStatement instanceof Block)) {
/* 112 */         flowContext.expireNullCheckedFieldInfo();
/*     */       }
/*     */     } 
/* 115 */     flowContext.expireNullCheckedFieldInfo();
/*     */     
/* 117 */     if ((thenFlowInfo.tagBits & 0x1) != 0) {
/* 118 */       this.bits |= 0x40000000;
/*     */     }
/*     */ 
/*     */     
/* 122 */     if (this.elseStatement != null) {
/*     */       
/* 124 */       if (thenFlowInfo == FlowInfo.DEAD_END && (
/* 125 */         this.bits & 0x20000000) == 0 && 
/* 126 */         !(this.elseStatement instanceof IfStatement)) {
/* 127 */         currentScope.problemReporter().unnecessaryElse(this.elseStatement);
/*     */       }
/*     */       
/* 130 */       this.elseInitStateIndex = currentScope.methodScope().recordInitializationStates(elseFlowInfo);
/* 131 */       if (isConditionOptimizedTrue || (this.bits & 0x80) != 0) {
/* 132 */         if (reportDeadCodeForKnownPattern) {
/* 133 */           this.elseStatement.complainIfUnreachable(elseFlowInfo, currentScope, initialComplaintLevel, false);
/*     */         }
/*     */         else {
/*     */           
/* 137 */           this.bits &= 0xFFFFFF7F;
/*     */         } 
/*     */       }
/* 140 */       this.condition.updateFlowOnBooleanResult(elseFlowInfo, false);
/* 141 */       elseFlowInfo = this.elseStatement.analyseCode(currentScope, flowContext, elseFlowInfo);
/* 142 */       if (!(this.elseStatement instanceof Block)) {
/* 143 */         flowContext.expireNullCheckedFieldInfo();
/*     */       }
/*     */     } 
/* 146 */     currentScope.correlateTrackingVarsIfElse(thenFlowInfo, elseFlowInfo);
/*     */     
/* 148 */     UnconditionalFlowInfo unconditionalFlowInfo = FlowInfo.mergedOptimizedBranchesIfElse(
/* 149 */         thenFlowInfo, 
/* 150 */         isConditionOptimizedTrue, 
/* 151 */         elseFlowInfo, 
/* 152 */         isConditionOptimizedFalse, 
/* 153 */         true, 
/* 154 */         flowInfo, 
/* 155 */         this, 
/* 156 */         reportDeadCodeForKnownPattern);
/* 157 */     this.mergedInitStateIndex = currentScope.methodScope().recordInitializationStates((FlowInfo)unconditionalFlowInfo);
/* 158 */     flowContext.conditionalLevel--;
/* 159 */     return (FlowInfo)unconditionalFlowInfo;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void generateCode(BlockScope currentScope, CodeStream codeStream) {
/* 169 */     if ((this.bits & Integer.MIN_VALUE) == 0) {
/*     */       return;
/*     */     }
/* 172 */     int pc = codeStream.position;
/* 173 */     BranchLabel endifLabel = new BranchLabel(codeStream);
/*     */     
/*     */     Constant cst;
/*     */     
/* 177 */     boolean hasThenPart = !(((
/* 178 */       cst = this.condition.optimizedBooleanConstant()) != Constant.NotAConstant && 
/* 179 */       !cst.booleanValue()) || 
/* 180 */       this.thenStatement == null || 
/* 181 */       this.thenStatement.isEmptyBlock());
/* 182 */     boolean hasElsePart = 
/* 183 */       !((cst != Constant.NotAConstant && cst.booleanValue()) || 
/* 184 */       this.elseStatement == null || 
/* 185 */       this.elseStatement.isEmptyBlock());
/* 186 */     if (hasThenPart) {
/* 187 */       BranchLabel falseLabel = null;
/*     */       
/* 189 */       if (cst != Constant.NotAConstant && cst.booleanValue()) {
/* 190 */         this.condition.generateCode(currentScope, codeStream, false);
/*     */       } else {
/* 192 */         this.condition.generateOptimizedBoolean(
/* 193 */             currentScope, 
/* 194 */             codeStream, 
/* 195 */             (BranchLabel)null, 
/* 196 */             hasElsePart ? (falseLabel = new BranchLabel(codeStream)) : endifLabel, 
/* 197 */             true);
/*     */       } 
/*     */       
/* 200 */       if (this.thenInitStateIndex != -1) {
/* 201 */         codeStream.removeNotDefinitelyAssignedVariables((Scope)currentScope, this.thenInitStateIndex);
/* 202 */         codeStream.addDefinitelyAssignedVariables((Scope)currentScope, this.thenInitStateIndex);
/*     */       } 
/*     */       
/* 205 */       this.thenStatement.generateCode(currentScope, codeStream);
/*     */       
/* 207 */       if (hasElsePart) {
/* 208 */         if ((this.bits & 0x40000000) == 0) {
/* 209 */           this.thenStatement.branchChainTo(endifLabel);
/* 210 */           int position = codeStream.position;
/* 211 */           codeStream.goto_(endifLabel);
/*     */           
/* 213 */           codeStream.recordPositionsFrom(position, this.thenStatement.sourceEnd);
/*     */         } 
/*     */ 
/*     */         
/* 217 */         if (this.elseInitStateIndex != -1) {
/* 218 */           codeStream.removeNotDefinitelyAssignedVariables(
/* 219 */               (Scope)currentScope, 
/* 220 */               this.elseInitStateIndex);
/* 221 */           codeStream.addDefinitelyAssignedVariables((Scope)currentScope, this.elseInitStateIndex);
/*     */         } 
/* 223 */         if (falseLabel != null) falseLabel.place(); 
/* 224 */         this.elseStatement.generateCode(currentScope, codeStream);
/*     */       } 
/* 226 */     } else if (hasElsePart) {
/*     */       
/* 228 */       if (cst != Constant.NotAConstant && !cst.booleanValue()) {
/* 229 */         this.condition.generateCode(currentScope, codeStream, false);
/*     */       } else {
/* 231 */         this.condition.generateOptimizedBoolean(
/* 232 */             currentScope, 
/* 233 */             codeStream, 
/* 234 */             endifLabel, 
/* 235 */             (BranchLabel)null, 
/* 236 */             true);
/*     */       } 
/*     */ 
/*     */       
/* 240 */       if (this.elseInitStateIndex != -1) {
/* 241 */         codeStream.removeNotDefinitelyAssignedVariables(
/* 242 */             (Scope)currentScope, 
/* 243 */             this.elseInitStateIndex);
/* 244 */         codeStream.addDefinitelyAssignedVariables((Scope)currentScope, this.elseInitStateIndex);
/*     */       } 
/* 246 */       this.elseStatement.generateCode(currentScope, codeStream);
/*     */     } else {
/*     */       
/* 249 */       if (this.condition.containsPatternVariable()) {
/* 250 */         this.condition.generateOptimizedBoolean(
/* 251 */             currentScope, 
/* 252 */             codeStream, 
/* 253 */             endifLabel, 
/* 254 */             (BranchLabel)null, 
/* 255 */             (cst == Constant.NotAConstant));
/*     */       } else {
/* 257 */         this.condition.generateCode(currentScope, codeStream, false);
/*     */       } 
/* 259 */       codeStream.recordPositionsFrom(pc, this.sourceStart);
/*     */     } 
/*     */     
/* 262 */     if (this.mergedInitStateIndex != -1) {
/* 263 */       codeStream.removeNotDefinitelyAssignedVariables(
/* 264 */           (Scope)currentScope, 
/* 265 */           this.mergedInitStateIndex);
/* 266 */       codeStream.addDefinitelyAssignedVariables((Scope)currentScope, this.mergedInitStateIndex);
/*     */     } 
/* 268 */     endifLabel.place();
/* 269 */     codeStream.recordPositionsFrom(pc, this.sourceStart);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public StringBuffer printStatement(int indent, StringBuffer output) {
/* 276 */     printIndent(indent, output).append("if (");
/* 277 */     this.condition.printExpression(0, output).append(")\n");
/* 278 */     this.thenStatement.printStatement(indent + 2, output);
/* 279 */     if (this.elseStatement != null) {
/* 280 */       output.append('\n');
/* 281 */       printIndent(indent, output);
/* 282 */       output.append("else\n");
/* 283 */       this.elseStatement.printStatement(indent + 2, output);
/*     */     } 
/* 285 */     return output;
/*     */   }
/*     */   private void resolveIfStatement(BlockScope scope) {
/* 288 */     TypeBinding type = this.condition.resolveTypeExpecting(scope, (TypeBinding)TypeBinding.BOOLEAN);
/* 289 */     this.condition.computeConversion((Scope)scope, type, type);
/* 290 */     if (this.thenStatement != null)
/* 291 */       this.thenStatement.resolve(scope); 
/* 292 */     if (this.elseStatement != null)
/* 293 */       this.elseStatement.resolve(scope); 
/*     */   }
/*     */   
/*     */   public void resolve(BlockScope scope) {
/* 297 */     if (containsPatternVariable()) {
/* 298 */       this.condition.collectPatternVariablesToScope((LocalVariableBinding[])null, scope);
/* 299 */       LocalVariableBinding[] patternVariablesInTrueScope = this.condition.getPatternVariablesWhenTrue();
/* 300 */       LocalVariableBinding[] patternVariablesInFalseScope = this.condition.getPatternVariablesWhenFalse();
/* 301 */       TypeBinding type = this.condition.resolveTypeExpecting(scope, (TypeBinding)TypeBinding.BOOLEAN);
/* 302 */       this.condition.computeConversion((Scope)scope, type, type);
/*     */       
/* 304 */       if (this.thenStatement != null) {
/* 305 */         this.thenStatement.resolveWithPatternVariablesInScope(patternVariablesInTrueScope, scope);
/*     */       }
/* 307 */       if (this.elseStatement != null) {
/* 308 */         this.elseStatement.resolveWithPatternVariablesInScope(patternVariablesInFalseScope, scope);
/*     */       }
/* 310 */       if (this.thenStatement != null)
/* 311 */         this.thenStatement.promotePatternVariablesIfApplicable(patternVariablesInFalseScope, 
/* 312 */             this.thenStatement::doesNotCompleteNormally); 
/* 313 */       if (this.elseStatement != null)
/* 314 */         this.elseStatement.promotePatternVariablesIfApplicable(patternVariablesInTrueScope, 
/* 315 */             this.elseStatement::doesNotCompleteNormally); 
/*     */     } else {
/* 317 */       resolveIfStatement(scope);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean containsPatternVariable() {
/* 323 */     return this.condition.containsPatternVariable();
/*     */   }
/*     */ 
/*     */   
/*     */   public void traverse(ASTVisitor visitor, BlockScope blockScope) {
/* 328 */     if (visitor.visit(this, blockScope)) {
/* 329 */       this.condition.traverse(visitor, blockScope);
/* 330 */       if (this.thenStatement != null)
/* 331 */         this.thenStatement.traverse(visitor, blockScope); 
/* 332 */       if (this.elseStatement != null)
/* 333 */         this.elseStatement.traverse(visitor, blockScope); 
/*     */     } 
/* 335 */     visitor.endVisit(this, blockScope);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean doesNotCompleteNormally() {
/* 340 */     return (this.thenStatement != null && this.thenStatement.doesNotCompleteNormally() && this.elseStatement != null && this.elseStatement.doesNotCompleteNormally());
/*     */   }
/*     */   
/*     */   public boolean completesByContinue() {
/* 344 */     return !((this.thenStatement == null || !this.thenStatement.completesByContinue()) && (this.elseStatement == null || !this.elseStatement.completesByContinue()));
/*     */   }
/*     */   
/*     */   public boolean canCompleteNormally() {
/* 348 */     return !(this.thenStatement != null && !this.thenStatement.canCompleteNormally() && 
/* 349 */       this.elseStatement != null && !this.elseStatement.canCompleteNormally());
/*     */   }
/*     */   
/*     */   public boolean continueCompletes() {
/* 353 */     return !((this.thenStatement == null || !this.thenStatement.continueCompletes()) && (
/* 354 */       this.elseStatement == null || !this.elseStatement.continueCompletes()));
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\ast\IfStatement.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */