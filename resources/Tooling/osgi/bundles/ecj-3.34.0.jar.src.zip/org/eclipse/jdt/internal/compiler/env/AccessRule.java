/*    */ package org.eclipse.jdt.internal.compiler.env;
/*    */ 
/*    */ import org.eclipse.jdt.core.compiler.CharOperation;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AccessRule
/*    */ {
/*    */   public static final int IgnoreIfBetter = 33554432;
/*    */   public final char[] pattern;
/*    */   public final int problemId;
/*    */   
/*    */   public AccessRule(char[] pattern, int problemId) {
/* 27 */     this(pattern, problemId, false);
/*    */   }
/*    */   
/*    */   public AccessRule(char[] pattern, int problemId, boolean keepLooking) {
/* 31 */     this.pattern = pattern;
/* 32 */     this.problemId = keepLooking ? (problemId | 0x2000000) : problemId;
/*    */   }
/*    */ 
/*    */   
/*    */   public int hashCode() {
/* 37 */     return this.problemId * 17 + CharOperation.hashCode(this.pattern);
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean equals(Object obj) {
/* 42 */     if (!(obj instanceof AccessRule)) return false; 
/* 43 */     AccessRule other = (AccessRule)obj;
/* 44 */     if (this.problemId != other.problemId) return false; 
/* 45 */     return CharOperation.equals(this.pattern, other.pattern);
/*    */   }
/*    */   
/*    */   public int getProblemId() {
/* 49 */     return this.problemId & 0xFDFFFFFF;
/*    */   }
/*    */   
/*    */   public boolean ignoreIfBetter() {
/* 53 */     return ((this.problemId & 0x2000000) != 0);
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 58 */     StringBuilder buffer = new StringBuilder();
/* 59 */     buffer.append("pattern=");
/* 60 */     buffer.append(this.pattern);
/* 61 */     switch (getProblemId()) {
/*    */       case 16777523:
/* 63 */         buffer.append(" (NON ACCESSIBLE");
/*    */         break;
/*    */       case 16777496:
/* 66 */         buffer.append(" (DISCOURAGED");
/*    */         break;
/*    */       default:
/* 69 */         buffer.append(" (ACCESSIBLE");
/*    */         break;
/*    */     } 
/* 72 */     if (ignoreIfBetter())
/* 73 */       buffer.append(" | IGNORE IF BETTER"); 
/* 74 */     buffer.append(')');
/* 75 */     return buffer.toString();
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\env\AccessRule.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */