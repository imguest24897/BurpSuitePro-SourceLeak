/*    */ package org.eclipse.jdt.internal.compiler.classfmt;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class ClassFileStruct
/*    */ {
/*    */   byte[] reference;
/*    */   int[] constantPoolOffsets;
/*    */   int structOffset;
/*    */   
/*    */   public ClassFileStruct(byte[] classFileBytes, int[] offsets, int offset) {
/* 21 */     this.reference = classFileBytes;
/* 22 */     this.constantPoolOffsets = offsets;
/* 23 */     this.structOffset = offset;
/*    */   }
/*    */   public double doubleAt(int relativeOffset) {
/* 26 */     return Double.longBitsToDouble(i8At(relativeOffset));
/*    */   }
/*    */   public float floatAt(int relativeOffset) {
/* 29 */     return Float.intBitsToFloat(i4At(relativeOffset));
/*    */   }
/*    */   public int i4At(int relativeOffset) {
/* 32 */     int position = relativeOffset + this.structOffset;
/* 33 */     return (this.reference[position++] & 0xFF) << 24 | (this.reference[position++] & 0xFF) << 16 | ((this.reference[position++] & 0xFF) << 8) + (this.reference[position] & 0xFF);
/*    */   }
/*    */   public long i8At(int relativeOffset) {
/* 36 */     int position = relativeOffset + this.structOffset;
/* 37 */     return (this.reference[position++] & 0xFF) << 56L | (
/* 38 */       this.reference[position++] & 0xFF) << 48L | (
/* 39 */       this.reference[position++] & 0xFF) << 40L | (
/* 40 */       this.reference[position++] & 0xFF) << 32L | (
/* 41 */       this.reference[position++] & 0xFF) << 24L | (
/* 42 */       this.reference[position++] & 0xFF) << 16L | (
/* 43 */       this.reference[position++] & 0xFF) << 8L | (
/* 44 */       this.reference[position++] & 0xFF);
/*    */   }
/*    */   protected void reset() {
/* 47 */     this.reference = null;
/* 48 */     this.constantPoolOffsets = null;
/*    */   }
/*    */   public int u1At(int relativeOffset) {
/* 51 */     return this.reference[relativeOffset + this.structOffset] & 0xFF;
/*    */   }
/*    */   public int u2At(int relativeOffset) {
/* 54 */     int position = relativeOffset + this.structOffset;
/* 55 */     return (this.reference[position++] & 0xFF) << 8 | this.reference[position] & 0xFF;
/*    */   }
/*    */   public long u4At(int relativeOffset) {
/* 58 */     int position = relativeOffset + this.structOffset;
/* 59 */     return (this.reference[position++] & 0xFFL) << 24L | ((this.reference[position++] & 0xFF) << 16) | ((this.reference[position++] & 0xFF) << 8) | (this.reference[position] & 0xFF);
/*    */   }
/*    */   public char[] utf8At(int relativeOffset, int bytesAvailable) {
/* 62 */     int length = bytesAvailable;
/* 63 */     char[] outputBuf = new char[bytesAvailable];
/* 64 */     int outputPos = 0;
/* 65 */     int readOffset = this.structOffset + relativeOffset;
/*    */     
/* 67 */     while (length != 0) {
/* 68 */       int x = this.reference[readOffset++] & 0xFF;
/* 69 */       length--;
/* 70 */       if ((0x80 & x) != 0) {
/* 71 */         if ((x & 0x20) != 0) {
/* 72 */           length -= 2;
/* 73 */           x = (x & 0xF) << 12 | (this.reference[readOffset++] & 0x3F) << 6 | this.reference[readOffset++] & 0x3F;
/*    */         } else {
/* 75 */           length--;
/* 76 */           x = (x & 0x1F) << 6 | this.reference[readOffset++] & 0x3F;
/*    */         } 
/*    */       }
/* 79 */       outputBuf[outputPos++] = (char)x;
/*    */     } 
/*    */     
/* 82 */     if (outputPos != bytesAvailable) {
/* 83 */       System.arraycopy(outputBuf, 0, outputBuf = new char[outputPos], 0, outputPos);
/*    */     }
/* 85 */     return outputBuf;
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\classfmt\ClassFileStruct.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */