/*    */ package org.eclipse.jdt.internal.compiler.flow;
/*    */ 
/*    */ import org.eclipse.jdt.internal.compiler.ast.ASTNode;
/*    */ import org.eclipse.jdt.internal.compiler.codegen.BranchLabel;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SwitchFlowContext
/*    */   extends FlowContext
/*    */ {
/*    */   public BranchLabel breakLabel;
/* 28 */   public UnconditionalFlowInfo initsOnBreak = FlowInfo.DEAD_END;
/*    */   public boolean isExpression = false;
/*    */   
/*    */   public SwitchFlowContext(FlowContext parent, ASTNode associatedNode, BranchLabel breakLabel, boolean isPreTest, boolean inheritNullFieldChecks) {
/* 32 */     super(parent, associatedNode, inheritNullFieldChecks);
/* 33 */     this.breakLabel = breakLabel;
/* 34 */     if (isPreTest && parent.conditionalLevel > -1) {
/* 35 */       this.conditionalLevel++;
/*    */     }
/*    */   }
/*    */ 
/*    */   
/*    */   public BranchLabel breakLabel() {
/* 41 */     return this.breakLabel;
/*    */   }
/*    */ 
/*    */   
/*    */   public String individualToString() {
/* 46 */     StringBuilder buffer = new StringBuilder("Switch flow context");
/* 47 */     buffer.append("[initsOnBreak -").append(this.initsOnBreak.toString()).append(']');
/* 48 */     return buffer.toString();
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean isBreakable() {
/* 53 */     return true;
/*    */   }
/*    */ 
/*    */   
/*    */   public void recordBreakFrom(FlowInfo flowInfo) {
/* 58 */     if ((this.initsOnBreak.tagBits & 0x1) == 0) {
/* 59 */       this.initsOnBreak = this.initsOnBreak.mergedWith(flowInfo.unconditionalInits());
/*    */     } else {
/*    */       
/* 62 */       this.initsOnBreak = flowInfo.unconditionalCopy();
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\flow\SwitchFlowContext.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */