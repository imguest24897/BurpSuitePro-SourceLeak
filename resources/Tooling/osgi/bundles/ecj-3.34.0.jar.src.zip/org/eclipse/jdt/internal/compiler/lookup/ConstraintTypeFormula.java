/*     */ package org.eclipse.jdt.internal.compiler.lookup;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.eclipse.jdt.internal.compiler.ast.Invocation;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class ConstraintTypeFormula
/*     */   extends ConstraintFormula
/*     */ {
/*     */   TypeBinding left;
/*     */   boolean isSoft;
/*     */   
/*     */   public static ConstraintTypeFormula create(TypeBinding exprType, TypeBinding right, int relation) {
/*  41 */     if (exprType == null || right == null)
/*  42 */       return FALSE; 
/*  43 */     return new ConstraintTypeFormula(exprType, right, relation, false);
/*     */   }
/*     */   
/*     */   public static ConstraintTypeFormula create(TypeBinding exprType, TypeBinding right, int relation, boolean isSoft) {
/*  47 */     if (exprType == null || right == null)
/*  48 */       return FALSE; 
/*  49 */     return new ConstraintTypeFormula(exprType, right, relation, isSoft);
/*     */   }
/*     */ 
/*     */   
/*     */   private ConstraintTypeFormula(TypeBinding exprType, TypeBinding right, int relation, boolean isSoft) {
/*  54 */     this.left = exprType;
/*  55 */     this.right = right;
/*  56 */     this.relation = relation;
/*  57 */     this.isSoft = isSoft;
/*     */   }
/*     */   
/*     */   ConstraintTypeFormula() {}
/*     */   
/*     */   public Object reduce(InferenceContext18 inferenceContext) {
/*     */     TypeBinding gs;
/*     */     WildcardBinding t;
/*     */     WildcardBinding s;
/*  66 */     switch (this.relation) {
/*     */       
/*     */       case 1:
/*  69 */         if (this.left.isProperType(true) && this.right.isProperType(true)) {
/*  70 */           return (this.left.isCompatibleWith(this.right, inferenceContext.scope) || this.left.isBoxingCompatibleWith(this.right, inferenceContext.scope)) ? TRUE : FALSE;
/*     */         }
/*  72 */         if (this.left.isPrimitiveType()) {
/*  73 */           TypeBinding sPrime = inferenceContext.environment.computeBoxingType(this.left);
/*  74 */           return create(sPrime, this.right, 1, this.isSoft);
/*     */         } 
/*  76 */         if (this.right.isPrimitiveType()) {
/*  77 */           TypeBinding tPrime = inferenceContext.environment.computeBoxingType(this.right);
/*  78 */           return create(this.left, tPrime, 4, this.isSoft);
/*     */         } 
/*  80 */         switch (this.right.kind()) {
/*     */           case 68:
/*  82 */             if (this.right.leafComponentType().kind() != 260) {
/*     */               break;
/*     */             }
/*     */ 
/*     */           
/*     */           case 260:
/*  88 */             gs = this.left.findSuperTypeOriginatingFrom(this.right);
/*  89 */             if (gs != null && gs.leafComponentType().isRawType()) {
/*  90 */               inferenceContext.recordUncheckedConversion(this);
/*  91 */               return TRUE;
/*     */             } 
/*     */             break;
/*     */         } 
/*     */         
/*  96 */         return create(this.left, this.right, 2, this.isSoft);
/*     */       
/*     */       case 2:
/*  99 */         return reduceSubType(inferenceContext.scope, this.left, this.right);
/*     */       
/*     */       case 3:
/* 102 */         return reduceSubType(inferenceContext.scope, this.right, this.left);
/*     */       case 4:
/* 104 */         if (inferenceContext.environment.globalOptions.isAnnotationBasedNullAnalysisEnabled && 
/* 105 */           !checkIVFreeTVmatch(this.left, this.right)) {
/* 106 */           checkIVFreeTVmatch(this.right, this.left);
/*     */         }
/* 108 */         return reduceTypeEquality(inferenceContext.object, inferenceContext);
/*     */       
/*     */       case 5:
/* 111 */         if (this.right.kind() != 516) {
/* 112 */           if (this.left.kind() != 516) {
/* 113 */             return create(this.left, this.right, 4, this.isSoft);
/*     */           }
/*     */           
/* 116 */           if (this.right instanceof InferenceVariable)
/* 117 */             return new TypeBound((InferenceVariable)this.right, this.left, 4, this.isSoft); 
/* 118 */           return FALSE;
/*     */         } 
/*     */         
/* 121 */         t = (WildcardBinding)this.right;
/* 122 */         if (t.boundKind == 0)
/* 123 */           return TRUE; 
/* 124 */         if (t.boundKind == 1) {
/* 125 */           if (this.left.kind() != 516) {
/* 126 */             return create(this.left, t.bound, 2, this.isSoft);
/*     */           }
/* 128 */           WildcardBinding wildcardBinding = (WildcardBinding)this.left;
/* 129 */           switch (wildcardBinding.boundKind) {
/*     */             case 0:
/* 131 */               return create(inferenceContext.object, t.bound, 2, this.isSoft);
/*     */             case 1:
/* 133 */               return create(wildcardBinding.bound, t.bound, 2, this.isSoft);
/*     */             case 2:
/* 135 */               return create(inferenceContext.object, t.bound, 4, this.isSoft);
/*     */           } 
/* 137 */           throw new IllegalArgumentException("Unexpected boundKind " + wildcardBinding.boundKind);
/*     */         } 
/*     */ 
/*     */         
/* 141 */         if (this.left.kind() != 516) {
/* 142 */           return create(t.bound, this.left, 2, this.isSoft);
/*     */         }
/* 144 */         s = (WildcardBinding)this.left;
/* 145 */         if (s.boundKind == 2) {
/* 146 */           return create(t.bound, s.bound, 2, this.isSoft);
/*     */         }
/* 148 */         return FALSE;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 153 */     throw new IllegalStateException("Unexpected relation kind " + this.relation);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   boolean checkIVFreeTVmatch(TypeBinding one, TypeBinding two) {
/* 159 */     if (one instanceof InferenceVariable && two.isTypeVariable() && (two.tagBits & 0x180000000000000L) == 0L) {
/*     */       
/* 161 */       ((InferenceVariable)one).nullHints = 108086391056891904L;
/* 162 */       return true;
/*     */     } 
/* 164 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   private Object reduceTypeEquality(TypeBinding object, InferenceContext18 inferenceContext) {
/* 169 */     if (this.left.kind() == 516) {
/* 170 */       if (this.right.kind() == 516)
/*     */       {
/* 172 */         WildcardBinding leftWC = (WildcardBinding)this.left;
/* 173 */         WildcardBinding rightWC = (WildcardBinding)this.right;
/* 174 */         if (leftWC.boundKind == 0 && rightWC.boundKind == 0)
/* 175 */           return TRUE; 
/* 176 */         if (leftWC.boundKind == 0 && rightWC.boundKind == 1)
/* 177 */           return create(object, rightWC.bound, 4, this.isSoft); 
/* 178 */         if (leftWC.boundKind == 1 && rightWC.boundKind == 0)
/* 179 */           return create(leftWC.bound, object, 4, this.isSoft); 
/* 180 */         if ((leftWC.boundKind == 1 && rightWC.boundKind == 1) || (
/* 181 */           leftWC.boundKind == 2 && rightWC.boundKind == 2))
/*     */         {
/* 183 */           return create(leftWC.bound, rightWC.bound, 4, this.isSoft);
/*     */         }
/*     */       }
/*     */     
/* 187 */     } else if (this.right.kind() != 516) {
/*     */       
/* 189 */       if (this.left.isProperType(true) && this.right.isProperType(true)) {
/* 190 */         if (TypeBinding.equalsEquals(this.left, this.right))
/* 191 */           return TRUE; 
/* 192 */         return FALSE;
/*     */       } 
/* 194 */       if (this.left.id == 12 || this.right.id == 12) {
/* 195 */         return FALSE;
/*     */       }
/* 197 */       if (this.left instanceof InferenceVariable && !this.right.isPrimitiveType()) {
/* 198 */         return new TypeBound((InferenceVariable)this.left, this.right, 4, this.isSoft);
/*     */       }
/* 200 */       if (this.right instanceof InferenceVariable && !this.left.isPrimitiveType()) {
/* 201 */         return new TypeBound((InferenceVariable)this.right, this.left, 4, this.isSoft);
/*     */       }
/* 203 */       if ((this.left.isClass() || this.left.isInterface()) && (
/* 204 */         this.right.isClass() || this.right.isInterface()) && 
/* 205 */         TypeBinding.equalsEquals(this.left.erasure(), this.right.erasure())) {
/*     */         
/* 207 */         TypeBinding[] leftParams = this.left.typeArguments();
/* 208 */         TypeBinding[] rightParams = this.right.typeArguments();
/* 209 */         if (leftParams == null || rightParams == null)
/* 210 */           return (leftParams == rightParams) ? TRUE : FALSE; 
/* 211 */         if (leftParams.length != rightParams.length)
/* 212 */           return FALSE; 
/* 213 */         int len = leftParams.length;
/* 214 */         ConstraintFormula[] constraints = new ConstraintFormula[len];
/* 215 */         for (int i = 0; i < len; i++) {
/* 216 */           constraints[i] = create(leftParams[i], rightParams[i], 4, this.isSoft);
/*     */         }
/* 218 */         return constraints;
/*     */       } 
/* 220 */       if (this.left.isArrayType() && this.right.isArrayType()) {
/* 221 */         if (this.left.dimensions() == this.right.dimensions())
/*     */         {
/* 223 */           return create(this.left.leafComponentType(), this.right.leafComponentType(), 4, this.isSoft); } 
/* 224 */         if (this.left.dimensions() > 0 && this.right.dimensions() > 0) {
/* 225 */           TypeBinding leftPrime = peelOneDimension(this.left, inferenceContext.environment);
/* 226 */           TypeBinding rightPrime = peelOneDimension(this.right, inferenceContext.environment);
/* 227 */           return create(leftPrime, rightPrime, 4, this.isSoft);
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 232 */     return FALSE;
/*     */   }
/*     */   
/*     */   private TypeBinding peelOneDimension(TypeBinding arrayType, LookupEnvironment env) {
/* 236 */     if (arrayType.dimensions() == 1)
/* 237 */       return arrayType.leafComponentType(); 
/* 238 */     return env.createArrayType(arrayType.leafComponentType(), arrayType.dimensions() - 1); } private Object reduceSubType(Scope scope, TypeBinding subCandidate, TypeBinding superCandidate) { List<ConstraintFormula> constraints; TypeBinding tPrime; boolean isFirst; ArrayBinding sPrimeArray; WildcardBinding intersection; TypeVariableBinding subTVB; TypeBinding sPrime; WildcardBinding variable; ReferenceBinding[] arrayOfReferenceBinding; ConstraintFormula[] result; int i;
/*     */     PolyTypeBinding poly;
/*     */     Invocation invocation;
/*     */     MethodBinding binding;
/*     */     TypeBinding returnType;
/* 243 */     if (subCandidate.isProperType(true) && superCandidate.isProperType(true)) {
/* 244 */       if (subCandidate.isSubtypeOf(superCandidate, true))
/* 245 */         return TRUE; 
/* 246 */       return FALSE;
/*     */     } 
/* 248 */     if (subCandidate.id == 12)
/* 249 */       return TRUE; 
/* 250 */     if (superCandidate.id == 12)
/* 251 */       return FALSE; 
/* 252 */     if (subCandidate instanceof InferenceVariable)
/* 253 */       return new TypeBound((InferenceVariable)subCandidate, superCandidate, 2, this.isSoft); 
/* 254 */     if (superCandidate instanceof InferenceVariable)
/* 255 */       return new TypeBound((InferenceVariable)superCandidate, subCandidate, 3, this.isSoft); 
/* 256 */     switch (superCandidate.kind()) {
/*     */       
/*     */       case 4:
/*     */       case 1028:
/*     */       case 2052:
/* 261 */         if (subCandidate.isSubtypeOf(superCandidate, true))
/* 262 */           return TRUE; 
/* 263 */         return FALSE;
/*     */ 
/*     */       
/*     */       case 260:
/* 267 */         constraints = new ArrayList<>();
/* 268 */         isFirst = true;
/* 269 */         while (superCandidate != null && superCandidate.kind() == 260 && subCandidate != null) {
/* 270 */           if (!addConstraintsFromTypeParameters(subCandidate, (ParameterizedTypeBinding)superCandidate, constraints) && 
/* 271 */             isFirst) return FALSE; 
/* 272 */           isFirst = false;
/*     */           
/* 274 */           superCandidate = superCandidate.enclosingType();
/* 275 */           subCandidate = subCandidate.enclosingType();
/*     */         } 
/* 277 */         switch (constraints.size()) { case 0:
/* 278 */             return TRUE;
/* 279 */           case 1: return constraints.get(0); }
/* 280 */          return constraints.toArray(new ConstraintFormula[constraints.size()]);
/*     */ 
/*     */       
/*     */       case 68:
/* 284 */         tPrime = ((ArrayBinding)superCandidate).elementsType();
/*     */         
/* 286 */         sPrimeArray = null;
/* 287 */         switch (subCandidate.kind()) {
/*     */           
/*     */           case 8196:
/* 290 */             intersection = (WildcardBinding)subCandidate;
/* 291 */             sPrimeArray = findMostSpecificSuperArray(intersection.bound, intersection.otherBounds, intersection);
/*     */             break;
/*     */           
/*     */           case 68:
/* 295 */             sPrimeArray = (ArrayBinding)subCandidate;
/*     */             break;
/*     */           
/*     */           case 4100:
/* 299 */             subTVB = (TypeVariableBinding)subCandidate;
/* 300 */             sPrimeArray = findMostSpecificSuperArray(subTVB.firstBound, subTVB.otherUpperBounds(), subTVB);
/*     */             break;
/*     */           
/*     */           default:
/* 304 */             return FALSE;
/*     */         } 
/* 306 */         if (sPrimeArray == null)
/* 307 */           return FALSE; 
/* 308 */         sPrime = sPrimeArray.elementsType();
/* 309 */         if (!tPrime.isPrimitiveType() && !sPrime.isPrimitiveType()) {
/* 310 */           return create(sPrime, tPrime, 2, this.isSoft);
/*     */         }
/* 312 */         return TypeBinding.equalsEquals(tPrime, sPrime) ? TRUE : FALSE;
/*     */ 
/*     */       
/*     */       case 516:
/* 316 */         if (subCandidate.kind() == 8196) {
/* 317 */           ReferenceBinding[] intersectingTypes = subCandidate.getIntersectingTypes();
/* 318 */           if (intersectingTypes != null)
/* 319 */             for (int j = 0; j < intersectingTypes.length; j++) {
/* 320 */               if (TypeBinding.equalsEquals(intersectingTypes[j], superCandidate))
/* 321 */                 return Boolean.valueOf(true); 
/*     */             }  
/* 323 */         }  variable = (WildcardBinding)superCandidate;
/* 324 */         if (variable.boundKind == 2)
/* 325 */           return create(subCandidate, variable.bound, 2, this.isSoft); 
/* 326 */         return FALSE;
/*     */       
/*     */       case 4100:
/* 329 */         if (subCandidate.kind() == 8196) {
/* 330 */           ReferenceBinding[] intersectingTypes = subCandidate.getIntersectingTypes();
/* 331 */           if (intersectingTypes != null)
/* 332 */             for (int j = 0; j < intersectingTypes.length; j++) {
/* 333 */               if (TypeBinding.equalsEquals(intersectingTypes[j], superCandidate))
/* 334 */                 return Boolean.valueOf(true); 
/*     */             }  
/* 336 */         }  if (superCandidate instanceof CaptureBinding) {
/* 337 */           CaptureBinding capture = (CaptureBinding)superCandidate;
/* 338 */           if (capture.lowerBound != null)
/* 339 */             return create(subCandidate, capture.lowerBound, 2, this.isSoft); 
/*     */         } 
/* 341 */         return FALSE;
/*     */       case 8196:
/* 343 */         superCandidate = ((WildcardBinding)superCandidate).allBounds();
/*     */       
/*     */       case 32772:
/* 346 */         arrayOfReferenceBinding = ((IntersectionTypeBinding18)superCandidate).intersectingTypes;
/* 347 */         result = new ConstraintFormula[arrayOfReferenceBinding.length];
/* 348 */         for (i = 0; i < arrayOfReferenceBinding.length; i++) {
/* 349 */           result[i] = create(subCandidate, arrayOfReferenceBinding[i], 2, this.isSoft);
/*     */         }
/* 351 */         return result;
/*     */       case 65540:
/* 353 */         poly = (PolyTypeBinding)superCandidate;
/* 354 */         invocation = (Invocation)poly.expression;
/* 355 */         binding = invocation.binding();
/* 356 */         if (binding == null || !binding.isValidBinding())
/* 357 */           return FALSE; 
/* 358 */         returnType = binding.isConstructor() ? binding.declaringClass : binding.returnType;
/* 359 */         return reduceSubType(scope, subCandidate, returnType.capture(scope, invocation.sourceStart(), invocation.sourceEnd()));
/*     */     } 
/* 361 */     throw new IllegalStateException("Unexpected RHS " + superCandidate); }
/*     */ 
/*     */   
/*     */   private ArrayBinding findMostSpecificSuperArray(TypeBinding firstBound, TypeBinding[] otherUpperBounds, TypeBinding theType) {
/* 365 */     int numArrayBounds = 0;
/* 366 */     ArrayBinding result = null;
/* 367 */     if (firstBound != null && firstBound.isArrayType()) {
/* 368 */       result = (ArrayBinding)firstBound;
/* 369 */       numArrayBounds++;
/*     */     } 
/* 371 */     for (int i = 0; i < otherUpperBounds.length; i++) {
/* 372 */       if (otherUpperBounds[i].isArrayType()) {
/* 373 */         result = (ArrayBinding)otherUpperBounds[i];
/* 374 */         numArrayBounds++;
/*     */       } 
/*     */     } 
/* 377 */     if (numArrayBounds == 0)
/* 378 */       return null; 
/* 379 */     if (numArrayBounds == 1)
/* 380 */       return result; 
/* 381 */     InferenceContext18.missingImplementation("Extracting array from intersection is not defined");
/* 382 */     return null;
/*     */   }
/*     */   
/*     */   boolean addConstraintsFromTypeParameters(TypeBinding subCandidate, ParameterizedTypeBinding ca, List<ConstraintFormula> constraints) {
/* 386 */     TypeBinding cb = subCandidate.findSuperTypeOriginatingFrom(ca);
/* 387 */     if (cb == null)
/* 388 */       return false; 
/* 389 */     if (TypeBinding.equalsEquals(ca, cb))
/* 390 */       return true; 
/* 391 */     if (!(cb instanceof ParameterizedTypeBinding))
/*     */     {
/* 393 */       return ca.isParameterizedWithOwnVariables();
/*     */     }
/* 395 */     TypeBinding[] bi = ((ParameterizedTypeBinding)cb).arguments;
/* 396 */     TypeBinding[] ai = ca.arguments;
/* 397 */     if (ai == null)
/* 398 */       return true; 
/* 399 */     if (cb.isRawType() || bi == null || bi.length == 0)
/* 400 */       return this.isSoft; 
/* 401 */     for (int i = 0; i < ai.length; i++)
/* 402 */       constraints.add(create(bi[i], ai[i], 5, this.isSoft)); 
/* 403 */     return true;
/*     */   }
/*     */   
/*     */   public boolean equalsEquals(ConstraintTypeFormula that) {
/* 407 */     return (that != null && this.relation == that.relation && this.isSoft == that.isSoft && 
/* 408 */       TypeBinding.equalsEquals(this.left, that.left) && TypeBinding.equalsEquals(this.right, that.right));
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean applySubstitution(BoundSet solutionSet, InferenceVariable[] variables) {
/* 413 */     super.applySubstitution(solutionSet, variables);
/* 414 */     for (int i = 0; i < variables.length; i++) {
/* 415 */       InferenceVariable variable = variables[i];
/* 416 */       TypeBinding instantiation = solutionSet.getInstantiation(variables[i], null);
/* 417 */       if (instantiation == null)
/* 418 */         return false; 
/* 419 */       this.left = this.left.substituteInferenceVariable(variable, instantiation);
/*     */     } 
/* 421 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 427 */     StringBuffer buf = new StringBuffer("Type Constraint:\n");
/* 428 */     buf.append('\t').append('⟨');
/* 429 */     appendTypeName(buf, this.left);
/* 430 */     buf.append(relationToString(this.relation));
/* 431 */     appendTypeName(buf, this.right);
/* 432 */     buf.append('⟩');
/* 433 */     return buf.toString();
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\lookup\ConstraintTypeFormula.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */