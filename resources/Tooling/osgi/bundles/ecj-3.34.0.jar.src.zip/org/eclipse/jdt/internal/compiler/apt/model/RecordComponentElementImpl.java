/*    */ package org.eclipse.jdt.internal.compiler.apt.model;
/*    */ 
/*    */ import javax.lang.model.element.ElementKind;
/*    */ import javax.lang.model.element.ElementVisitor;
/*    */ import javax.lang.model.element.ExecutableElement;
/*    */ import javax.lang.model.element.RecordComponentElement;
/*    */ import org.eclipse.jdt.internal.compiler.apt.dispatch.BaseProcessingEnvImpl;
/*    */ import org.eclipse.jdt.internal.compiler.lookup.MethodBinding;
/*    */ import org.eclipse.jdt.internal.compiler.lookup.RecordComponentBinding;
/*    */ import org.eclipse.jdt.internal.compiler.lookup.ReferenceBinding;
/*    */ import org.eclipse.jdt.internal.compiler.lookup.VariableBinding;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RecordComponentElementImpl
/*    */   extends VariableElementImpl
/*    */   implements RecordComponentElement
/*    */ {
/*    */   protected RecordComponentElementImpl(BaseProcessingEnvImpl env, RecordComponentBinding binding) {
/* 30 */     super(env, (VariableBinding)binding);
/*    */   }
/*    */ 
/*    */   
/*    */   public ElementKind getKind() {
/* 35 */     return ElementKind.RECORD_COMPONENT;
/*    */   }
/*    */ 
/*    */   
/*    */   public ExecutableElement getAccessor() {
/* 40 */     RecordComponentBinding comp = (RecordComponentBinding)this._binding;
/* 41 */     ReferenceBinding binding = comp.declaringRecord;
/* 42 */     MethodBinding accessor = binding.getRecordComponentAccessor(comp.name);
/* 43 */     if (accessor != null) {
/* 44 */       return new ExecutableElementImpl(this._env, accessor);
/*    */     }
/* 46 */     return null;
/*    */   }
/*    */ 
/*    */   
/*    */   public <R, P> R accept(ElementVisitor<R, P> visitor, P param) {
/* 51 */     return visitor.visitRecordComponent(this, param);
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\apt\model\RecordComponentElementImpl.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */