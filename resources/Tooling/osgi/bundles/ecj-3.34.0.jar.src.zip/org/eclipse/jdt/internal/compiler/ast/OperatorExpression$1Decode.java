/*     */ package org.eclipse.jdt.internal.compiler.ast;
/*     */ 
/*     */ import org.eclipse.jdt.internal.compiler.util.Util;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class Decode
/*     */ {
/*     */   public final String constant(int code) {
/*  69 */     switch (code) { case 5:
/*  70 */         return "true";
/*  71 */       case 3: return "((byte) 3)";
/*  72 */       case 2: return "'A'";
/*  73 */       case 8: return "300.0d";
/*  74 */       case 9: return "100.0f";
/*  75 */       case 10: return "1";
/*  76 */       case 7: return "7L";
/*  77 */       case 11: return "\"hello-world\"";
/*  78 */       case 12: return "null";
/*  79 */       case 4: return "((short) 5)";
/*  80 */       case 1: return "null"; }
/*  81 */      return Util.EMPTY_STRING;
/*     */   }
/*     */   public final String type(int code) {
/*  84 */     switch (code) { case 5:
/*  85 */         return "z";
/*  86 */       case 3: return "b";
/*  87 */       case 2: return "c";
/*  88 */       case 8: return "d";
/*  89 */       case 9: return "f";
/*  90 */       case 10: return "i";
/*  91 */       case 7: return "l";
/*  92 */       case 11: return "str";
/*  93 */       case 12: return "null";
/*  94 */       case 4: return "s";
/*  95 */       case 1: return "obj"; }
/*  96 */      return "xxx";
/*     */   }
/*     */   public final String operator(int operator) {
/*  99 */     switch (operator) { case 18:
/* 100 */         return "==";
/* 101 */       case 5: return "<=";
/* 102 */       case 7: return ">=";
/* 103 */       case 10: return "<<";
/* 104 */       case 17: return ">>";
/* 105 */       case 19: return ">>>";
/* 106 */       case 1: return "||";
/* 107 */       case 0: return "&&";
/* 108 */       case 14: return "+";
/* 109 */       case 13: return "-";
/* 110 */       case 11: return "!";
/* 111 */       case 16: return "%";
/* 112 */       case 8: return "^";
/* 113 */       case 2: return "&";
/* 114 */       case 15: return "*";
/* 115 */       case 3: return "|";
/* 116 */       case 12: return "~";
/* 117 */       case 9: return "/";
/* 118 */       case 6: return ">";
/* 119 */       case 4: return "<"; }
/* 120 */      return "????";
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\ast\OperatorExpression$1Decode.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */