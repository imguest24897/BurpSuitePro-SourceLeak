/*      */ package org.eclipse.jdt.internal.compiler.codegen;
/*      */ 
/*      */ import java.util.ArrayList;
/*      */ import java.util.Iterator;
/*      */ import java.util.LinkedHashMap;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.Set;
/*      */ import java.util.Stack;
/*      */ import java.util.function.Supplier;
/*      */ import org.eclipse.jdt.core.compiler.CharOperation;
/*      */ import org.eclipse.jdt.internal.compiler.ClassFile;
/*      */ import org.eclipse.jdt.internal.compiler.CompilationResult;
/*      */ import org.eclipse.jdt.internal.compiler.ast.ASTNode;
/*      */ import org.eclipse.jdt.internal.compiler.ast.AbstractMethodDeclaration;
/*      */ import org.eclipse.jdt.internal.compiler.ast.ArrayAllocationExpression;
/*      */ import org.eclipse.jdt.internal.compiler.ast.ExplicitConstructorCall;
/*      */ import org.eclipse.jdt.internal.compiler.ast.Expression;
/*      */ import org.eclipse.jdt.internal.compiler.ast.FieldDeclaration;
/*      */ import org.eclipse.jdt.internal.compiler.ast.FunctionalExpression;
/*      */ import org.eclipse.jdt.internal.compiler.ast.LambdaExpression;
/*      */ import org.eclipse.jdt.internal.compiler.ast.ReferenceExpression;
/*      */ import org.eclipse.jdt.internal.compiler.ast.TypeDeclaration;
/*      */ import org.eclipse.jdt.internal.compiler.ast.TypeReference;
/*      */ import org.eclipse.jdt.internal.compiler.impl.CompilerOptions;
/*      */ import org.eclipse.jdt.internal.compiler.impl.Constant;
/*      */ import org.eclipse.jdt.internal.compiler.lookup.ArrayBinding;
/*      */ import org.eclipse.jdt.internal.compiler.lookup.Binding;
/*      */ import org.eclipse.jdt.internal.compiler.lookup.BlockScope;
/*      */ import org.eclipse.jdt.internal.compiler.lookup.ClassScope;
/*      */ import org.eclipse.jdt.internal.compiler.lookup.FieldBinding;
/*      */ import org.eclipse.jdt.internal.compiler.lookup.IntersectionTypeBinding18;
/*      */ import org.eclipse.jdt.internal.compiler.lookup.LocalVariableBinding;
/*      */ import org.eclipse.jdt.internal.compiler.lookup.MethodBinding;
/*      */ import org.eclipse.jdt.internal.compiler.lookup.MethodScope;
/*      */ import org.eclipse.jdt.internal.compiler.lookup.NestedTypeBinding;
/*      */ import org.eclipse.jdt.internal.compiler.lookup.ReferenceBinding;
/*      */ import org.eclipse.jdt.internal.compiler.lookup.Scope;
/*      */ import org.eclipse.jdt.internal.compiler.lookup.SourceTypeBinding;
/*      */ import org.eclipse.jdt.internal.compiler.lookup.SyntheticArgumentBinding;
/*      */ import org.eclipse.jdt.internal.compiler.lookup.SyntheticMethodBinding;
/*      */ import org.eclipse.jdt.internal.compiler.lookup.TypeBinding;
/*      */ import org.eclipse.jdt.internal.compiler.lookup.TypeConstants;
/*      */ import org.eclipse.jdt.internal.compiler.lookup.TypeIds;
/*      */ import org.eclipse.jdt.internal.compiler.lookup.VariableBinding;
/*      */ import org.eclipse.jdt.internal.compiler.problem.AbortMethod;
/*      */ import org.eclipse.jdt.internal.compiler.util.Util;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class CodeStream
/*      */ {
/*   71 */   public static FieldBinding[] ImplicitThis = new FieldBinding[0];
/*      */   
/*      */   public static final int LABELS_INCREMENT = 5;
/*      */   public static final int LOCALS_INCREMENT = 10;
/*   75 */   public static final CompilationResult RESTART_IN_WIDE_MODE = new CompilationResult(null, 0, 0, 0);
/*   76 */   public static final CompilationResult RESTART_CODE_GEN_FOR_UNUSED_LOCALS_MODE = new CompilationResult(null, 0, 0, 0);
/*      */   
/*      */   public int allLocalsCounter;
/*      */   public byte[] bCodeStream;
/*      */   public ClassFile classFile;
/*      */   public int classFileOffset;
/*      */   public ConstantPool constantPool;
/*      */   public int countLabels;
/*   84 */   public ExceptionLabel[] exceptionLabels = new ExceptionLabel[5];
/*      */   public int exceptionLabelsCounter;
/*      */   public int generateAttributes;
/*      */   static final int L_UNKNOWN = 0;
/*      */   static final int L_OPTIMIZABLE = 2;
/*      */   static final int L_CANNOT_OPTIMIZE = 4;
/*   90 */   public BranchLabel[] labels = new BranchLabel[5];
/*      */   
/*      */   public int lastEntryPC;
/*      */   
/*      */   public int lastAbruptCompletion;
/*      */   
/*      */   public int[] lineSeparatorPositions;
/*      */   public int lineNumberStart;
/*      */   public int lineNumberEnd;
/*   99 */   public LocalVariableBinding[] locals = new LocalVariableBinding[10];
/*      */   public int maxFieldCount;
/*      */   public int maxLocals;
/*      */   public AbstractMethodDeclaration methodDeclaration;
/*      */   public LambdaExpression lambdaExpression;
/*  104 */   public int[] pcToSourceMap = new int[24];
/*      */   
/*      */   public int pcToSourceMapSize;
/*      */   
/*      */   public int position;
/*      */   
/*      */   public boolean preserveUnusedLocals;
/*      */   
/*      */   public int stackDepth;
/*      */   public int stackMax;
/*      */   public int startingClassFileOffset;
/*      */   protected long targetLevel;
/*  116 */   public LocalVariableBinding[] visibleLocals = new LocalVariableBinding[10];
/*      */ 
/*      */   
/*      */   int visibleLocalsCount;
/*      */   
/*      */   public boolean wideMode = false;
/*      */   
/*  123 */   public Stack<TypeBinding> switchSaveTypeBindings = new Stack<>();
/*  124 */   public int lastSwitchCumulativeSyntheticVars = 0;
/*      */   
/*      */   public CodeStream(ClassFile givenClassFile) {
/*  127 */     this.targetLevel = givenClassFile.targetJDK;
/*  128 */     this.generateAttributes = givenClassFile.produceAttributes;
/*  129 */     if ((givenClassFile.produceAttributes & 0x2) != 0) {
/*  130 */       this.lineSeparatorPositions = (givenClassFile.referenceBinding.scope.referenceCompilationUnit()).compilationResult.getLineSeparatorPositions();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int insertionIndex(int[] pcToSourceMap, int length, int pc) {
/*  145 */     int g = 0;
/*  146 */     int d = length - 2;
/*  147 */     int m = 0;
/*  148 */     while (g <= d) {
/*  149 */       m = (g + d) / 2;
/*      */       
/*  151 */       if ((m & 0x1) != 0)
/*  152 */         m--; 
/*  153 */       int currentPC = pcToSourceMap[m];
/*  154 */       if (pc < currentPC) {
/*  155 */         d = m - 2; continue;
/*      */       } 
/*  157 */       if (pc > currentPC) {
/*  158 */         g = m + 2; continue;
/*      */       } 
/*  160 */       return -1;
/*      */     } 
/*      */     
/*  163 */     if (pc < pcToSourceMap[m])
/*  164 */       return m; 
/*  165 */     return m + 2;
/*      */   }
/*      */   public static final void sort(int[] tab, int lo0, int hi0, int[] result) {
/*  168 */     int lo = lo0;
/*  169 */     int hi = hi0;
/*      */     
/*  171 */     if (hi0 > lo0) {
/*      */ 
/*      */ 
/*      */       
/*  175 */       int mid = tab[lo0 + (hi0 - lo0) / 2];
/*      */       
/*  177 */       while (lo <= hi) {
/*      */ 
/*      */ 
/*      */         
/*  181 */         while (lo < hi0 && tab[lo] < mid) {
/*  182 */           lo++;
/*      */         }
/*      */ 
/*      */         
/*  186 */         while (hi > lo0 && tab[hi] > mid) {
/*  187 */           hi--;
/*      */         }
/*  189 */         if (lo <= hi) {
/*  190 */           swap(tab, lo, hi, result);
/*  191 */           lo++;
/*  192 */           hi--;
/*      */         } 
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/*  198 */       if (lo0 < hi) {
/*  199 */         sort(tab, lo0, hi, result);
/*      */       }
/*      */ 
/*      */       
/*  203 */       if (lo < hi0) {
/*  204 */         sort(tab, lo, hi0, result);
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   private static final void swap(int[] a, int i, int j, int[] result) {
/*  211 */     int T = a[i];
/*  212 */     a[i] = a[j];
/*  213 */     a[j] = T;
/*  214 */     T = result[j];
/*  215 */     result[j] = result[i];
/*  216 */     result[i] = T;
/*      */   }
/*      */   
/*      */   public void aaload() {
/*  220 */     this.countLabels = 0;
/*  221 */     this.stackDepth--;
/*  222 */     if (this.classFileOffset >= this.bCodeStream.length) {
/*  223 */       resizeByteArray();
/*      */     }
/*  225 */     this.position++;
/*  226 */     this.bCodeStream[this.classFileOffset++] = 50;
/*  227 */     pushTypeBindingArray();
/*      */   }
/*      */   
/*      */   public void aastore() {
/*  231 */     this.countLabels = 0;
/*  232 */     this.stackDepth -= 3;
/*  233 */     if (this.classFileOffset >= this.bCodeStream.length) {
/*  234 */       resizeByteArray();
/*      */     }
/*  236 */     this.position++;
/*  237 */     this.bCodeStream[this.classFileOffset++] = 83;
/*  238 */     popTypeBinding(3);
/*      */   }
/*      */   
/*      */   public void aconst_null() {
/*  242 */     this.countLabels = 0;
/*  243 */     this.stackDepth++;
/*  244 */     if (this.stackDepth > this.stackMax) {
/*  245 */       this.stackMax = this.stackDepth;
/*      */     }
/*  247 */     if (this.classFileOffset >= this.bCodeStream.length) {
/*  248 */       resizeByteArray();
/*      */     }
/*  250 */     this.position++;
/*  251 */     this.bCodeStream[this.classFileOffset++] = 1;
/*  252 */     pushTypeBinding((TypeBinding)TypeBinding.NULL);
/*      */   }
/*      */ 
/*      */   
/*      */   public void addDefinitelyAssignedVariables(Scope scope, int initStateIndex) {
/*  257 */     if ((this.generateAttributes & 0x1C) == 0) {
/*      */       return;
/*      */     }
/*      */     
/*  261 */     for (int i = 0; i < this.visibleLocalsCount; i++) {
/*  262 */       LocalVariableBinding localBinding = this.visibleLocals[i];
/*  263 */       if (localBinding != null)
/*      */       {
/*  265 */         if (isDefinitelyAssigned(scope, initStateIndex, localBinding) && (
/*  266 */           localBinding.initializationCount == 0 || localBinding.initializationPCs[(localBinding.initializationCount - 1 << 1) + 1] != -1))
/*      */         {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  276 */           localBinding.recordInitializationStartPC(this.position);
/*      */         }
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public void addLabel(BranchLabel aLabel) {
/*  284 */     if (this.countLabels == this.labels.length)
/*  285 */       System.arraycopy(this.labels, 0, this.labels = new BranchLabel[this.countLabels + 5], 0, this.countLabels); 
/*  286 */     this.labels[this.countLabels++] = aLabel;
/*      */   }
/*      */ 
/*      */   
/*      */   public void addVariable(LocalVariableBinding localBinding) {}
/*      */ 
/*      */   
/*      */   public void addVisibleLocalVariable(LocalVariableBinding localBinding) {
/*  294 */     if ((this.generateAttributes & 0x1C) == 0) {
/*      */       return;
/*      */     }
/*      */ 
/*      */     
/*  299 */     if (this.visibleLocalsCount >= this.visibleLocals.length)
/*  300 */       System.arraycopy(this.visibleLocals, 0, this.visibleLocals = new LocalVariableBinding[this.visibleLocalsCount * 2], 0, this.visibleLocalsCount); 
/*  301 */     this.visibleLocals[this.visibleLocalsCount++] = localBinding;
/*      */   }
/*      */   
/*      */   public void aload(int iArg) {
/*  305 */     this.countLabels = 0;
/*  306 */     this.stackDepth++;
/*  307 */     if (this.stackDepth > this.stackMax)
/*  308 */       this.stackMax = this.stackDepth; 
/*  309 */     if (this.maxLocals <= iArg) {
/*  310 */       this.maxLocals = iArg + 1;
/*      */     }
/*  312 */     pushTypeBinding(iArg);
/*  313 */     if (iArg > 255) {
/*  314 */       if (this.classFileOffset + 3 >= this.bCodeStream.length) {
/*  315 */         resizeByteArray();
/*      */       }
/*  317 */       this.position += 2;
/*  318 */       this.bCodeStream[this.classFileOffset++] = -60;
/*  319 */       this.bCodeStream[this.classFileOffset++] = 25;
/*  320 */       writeUnsignedShort(iArg);
/*      */     } else {
/*      */       
/*  323 */       if (this.classFileOffset + 1 >= this.bCodeStream.length) {
/*  324 */         resizeByteArray();
/*      */       }
/*  326 */       this.position += 2;
/*  327 */       this.bCodeStream[this.classFileOffset++] = 25;
/*  328 */       this.bCodeStream[this.classFileOffset++] = (byte)iArg;
/*      */     } 
/*      */   }
/*      */   
/*      */   public void aload_0() {
/*  333 */     this.countLabels = 0;
/*  334 */     this.stackDepth++;
/*  335 */     pushTypeBinding(0);
/*  336 */     if (this.stackDepth > this.stackMax) {
/*  337 */       this.stackMax = this.stackDepth;
/*      */     }
/*  339 */     if (this.maxLocals == 0) {
/*  340 */       this.maxLocals = 1;
/*      */     }
/*  342 */     if (this.classFileOffset >= this.bCodeStream.length) {
/*  343 */       resizeByteArray();
/*      */     }
/*  345 */     this.position++;
/*  346 */     this.bCodeStream[this.classFileOffset++] = 42;
/*      */   }
/*      */   
/*      */   public void aload_1() {
/*  350 */     this.countLabels = 0;
/*  351 */     this.stackDepth++;
/*  352 */     pushTypeBinding(1);
/*  353 */     if (this.stackDepth > this.stackMax)
/*  354 */       this.stackMax = this.stackDepth; 
/*  355 */     if (this.maxLocals <= 1) {
/*  356 */       this.maxLocals = 2;
/*      */     }
/*  358 */     if (this.classFileOffset >= this.bCodeStream.length) {
/*  359 */       resizeByteArray();
/*      */     }
/*  361 */     this.position++;
/*  362 */     this.bCodeStream[this.classFileOffset++] = 43;
/*      */   }
/*      */   
/*      */   public void aload_2() {
/*  366 */     this.countLabels = 0;
/*  367 */     this.stackDepth++;
/*  368 */     pushTypeBinding(2);
/*  369 */     if (this.stackDepth > this.stackMax)
/*  370 */       this.stackMax = this.stackDepth; 
/*  371 */     if (this.maxLocals <= 2) {
/*  372 */       this.maxLocals = 3;
/*      */     }
/*  374 */     if (this.classFileOffset >= this.bCodeStream.length) {
/*  375 */       resizeByteArray();
/*      */     }
/*  377 */     this.position++;
/*  378 */     this.bCodeStream[this.classFileOffset++] = 44;
/*      */   }
/*      */   
/*      */   public void aload_3() {
/*  382 */     this.countLabels = 0;
/*  383 */     this.stackDepth++;
/*  384 */     pushTypeBinding(3);
/*  385 */     if (this.stackDepth > this.stackMax)
/*  386 */       this.stackMax = this.stackDepth; 
/*  387 */     if (this.maxLocals <= 3) {
/*  388 */       this.maxLocals = 4;
/*      */     }
/*  390 */     if (this.classFileOffset >= this.bCodeStream.length) {
/*  391 */       resizeByteArray();
/*      */     }
/*  393 */     this.position++;
/*  394 */     this.bCodeStream[this.classFileOffset++] = 45;
/*      */   }
/*      */   
/*      */   public void anewarray(TypeBinding typeBinding) {
/*  398 */     this.countLabels = 0;
/*  399 */     if (this.classFileOffset + 2 >= this.bCodeStream.length) {
/*  400 */       resizeByteArray();
/*      */     }
/*  402 */     this.position++;
/*  403 */     this.bCodeStream[this.classFileOffset++] = -67;
/*  404 */     writeUnsignedShort(this.constantPool.literalIndexForType(typeBinding));
/*  405 */     pushTypeBinding(1, typeBinding);
/*      */   }
/*      */   
/*      */   public void areturn() {
/*  409 */     this.countLabels = 0;
/*  410 */     this.stackDepth--;
/*  411 */     popTypeBinding();
/*      */     
/*  413 */     if (this.classFileOffset >= this.bCodeStream.length) {
/*  414 */       resizeByteArray();
/*      */     }
/*  416 */     this.position++;
/*  417 */     this.bCodeStream[this.classFileOffset++] = -80;
/*  418 */     this.lastAbruptCompletion = this.position;
/*      */   }
/*      */   
/*      */   public void arrayAt(int typeBindingID) {
/*  422 */     switch (typeBindingID) {
/*      */       case 10:
/*  424 */         iaload();
/*      */         return;
/*      */       case 3:
/*      */       case 5:
/*  428 */         baload();
/*      */         return;
/*      */       case 4:
/*  431 */         saload();
/*      */         return;
/*      */       case 2:
/*  434 */         caload();
/*      */         return;
/*      */       case 7:
/*  437 */         laload();
/*      */         return;
/*      */       case 9:
/*  440 */         faload();
/*      */         return;
/*      */       case 8:
/*  443 */         daload();
/*      */         return;
/*      */     } 
/*  446 */     aaload();
/*      */   }
/*      */ 
/*      */   
/*      */   public void arrayAtPut(int elementTypeID, boolean valueRequired) {
/*  451 */     switch (elementTypeID) {
/*      */       case 10:
/*  453 */         if (valueRequired)
/*  454 */           dup_x2(); 
/*  455 */         iastore();
/*      */         return;
/*      */       case 3:
/*      */       case 5:
/*  459 */         if (valueRequired)
/*  460 */           dup_x2(); 
/*  461 */         bastore();
/*      */         return;
/*      */       case 4:
/*  464 */         if (valueRequired)
/*  465 */           dup_x2(); 
/*  466 */         sastore();
/*      */         return;
/*      */       case 2:
/*  469 */         if (valueRequired)
/*  470 */           dup_x2(); 
/*  471 */         castore();
/*      */         return;
/*      */       case 7:
/*  474 */         if (valueRequired)
/*  475 */           dup2_x2(); 
/*  476 */         lastore();
/*      */         return;
/*      */       case 9:
/*  479 */         if (valueRequired)
/*  480 */           dup_x2(); 
/*  481 */         fastore();
/*      */         return;
/*      */       case 8:
/*  484 */         if (valueRequired)
/*  485 */           dup2_x2(); 
/*  486 */         dastore();
/*      */         return;
/*      */     } 
/*  489 */     if (valueRequired)
/*  490 */       dup_x2(); 
/*  491 */     aastore();
/*      */   }
/*      */ 
/*      */   
/*      */   public void arraylength() {
/*  496 */     this.countLabels = 0;
/*  497 */     if (this.classFileOffset >= this.bCodeStream.length) {
/*  498 */       resizeByteArray();
/*      */     }
/*  500 */     this.position++;
/*  501 */     this.bCodeStream[this.classFileOffset++] = -66;
/*  502 */     pushTypeBinding(1, (TypeBinding)TypeBinding.INT);
/*      */   }
/*      */   
/*      */   public void astore(int iArg) {
/*  506 */     this.countLabels = 0;
/*  507 */     this.stackDepth--;
/*  508 */     popTypeBinding();
/*  509 */     if (this.maxLocals <= iArg) {
/*  510 */       this.maxLocals = iArg + 1;
/*      */     }
/*  512 */     if (iArg > 255) {
/*  513 */       if (this.classFileOffset + 3 >= this.bCodeStream.length) {
/*  514 */         resizeByteArray();
/*      */       }
/*  516 */       this.position += 2;
/*  517 */       this.bCodeStream[this.classFileOffset++] = -60;
/*  518 */       this.bCodeStream[this.classFileOffset++] = 58;
/*  519 */       writeUnsignedShort(iArg);
/*      */     } else {
/*  521 */       if (this.classFileOffset + 1 >= this.bCodeStream.length) {
/*  522 */         resizeByteArray();
/*      */       }
/*  524 */       this.position += 2;
/*  525 */       this.bCodeStream[this.classFileOffset++] = 58;
/*  526 */       this.bCodeStream[this.classFileOffset++] = (byte)iArg;
/*      */     } 
/*      */   }
/*      */   
/*      */   public void astore_0() {
/*  531 */     this.countLabels = 0;
/*  532 */     this.stackDepth--;
/*  533 */     popTypeBinding();
/*  534 */     if (this.maxLocals == 0) {
/*  535 */       this.maxLocals = 1;
/*      */     }
/*  537 */     if (this.classFileOffset >= this.bCodeStream.length) {
/*  538 */       resizeByteArray();
/*      */     }
/*  540 */     this.position++;
/*  541 */     this.bCodeStream[this.classFileOffset++] = 75;
/*      */   }
/*      */   
/*      */   public void astore_1() {
/*  545 */     this.countLabels = 0;
/*  546 */     this.stackDepth--;
/*  547 */     popTypeBinding();
/*  548 */     if (this.maxLocals <= 1) {
/*  549 */       this.maxLocals = 2;
/*      */     }
/*  551 */     if (this.classFileOffset >= this.bCodeStream.length) {
/*  552 */       resizeByteArray();
/*      */     }
/*  554 */     this.position++;
/*  555 */     this.bCodeStream[this.classFileOffset++] = 76;
/*      */   }
/*      */   
/*      */   public void astore_2() {
/*  559 */     this.countLabels = 0;
/*  560 */     this.stackDepth--;
/*  561 */     popTypeBinding();
/*  562 */     if (this.maxLocals <= 2) {
/*  563 */       this.maxLocals = 3;
/*      */     }
/*  565 */     if (this.classFileOffset >= this.bCodeStream.length) {
/*  566 */       resizeByteArray();
/*      */     }
/*  568 */     this.position++;
/*  569 */     this.bCodeStream[this.classFileOffset++] = 77;
/*      */   }
/*      */   
/*      */   public void astore_3() {
/*  573 */     this.countLabels = 0;
/*  574 */     this.stackDepth--;
/*  575 */     popTypeBinding();
/*  576 */     if (this.maxLocals <= 3) {
/*  577 */       this.maxLocals = 4;
/*      */     }
/*  579 */     if (this.classFileOffset >= this.bCodeStream.length) {
/*  580 */       resizeByteArray();
/*      */     }
/*  582 */     this.position++;
/*  583 */     this.bCodeStream[this.classFileOffset++] = 78;
/*      */   }
/*      */   
/*      */   public void athrow() {
/*  587 */     this.countLabels = 0;
/*  588 */     this.stackDepth--;
/*  589 */     popTypeBinding();
/*  590 */     if (this.classFileOffset >= this.bCodeStream.length) {
/*  591 */       resizeByteArray();
/*      */     }
/*  593 */     this.position++;
/*  594 */     this.bCodeStream[this.classFileOffset++] = -65;
/*  595 */     this.lastAbruptCompletion = this.position;
/*      */   }
/*      */   
/*      */   public void baload() {
/*  599 */     this.countLabels = 0;
/*  600 */     this.stackDepth--;
/*  601 */     pushTypeBindingArray();
/*  602 */     if (this.classFileOffset >= this.bCodeStream.length) {
/*  603 */       resizeByteArray();
/*      */     }
/*  605 */     this.position++;
/*  606 */     this.bCodeStream[this.classFileOffset++] = 51;
/*      */   }
/*      */   
/*      */   public void bastore() {
/*  610 */     this.countLabels = 0;
/*  611 */     this.stackDepth -= 3;
/*  612 */     popTypeBinding(3);
/*  613 */     if (this.classFileOffset >= this.bCodeStream.length) {
/*  614 */       resizeByteArray();
/*      */     }
/*  616 */     this.position++;
/*  617 */     this.bCodeStream[this.classFileOffset++] = 84;
/*      */   }
/*      */   
/*      */   public void bipush(byte b) {
/*  621 */     this.countLabels = 0;
/*  622 */     this.stackDepth++;
/*  623 */     pushTypeBinding((TypeBinding)TypeBinding.BYTE);
/*  624 */     if (this.stackDepth > this.stackMax)
/*  625 */       this.stackMax = this.stackDepth; 
/*  626 */     if (this.classFileOffset + 1 >= this.bCodeStream.length) {
/*  627 */       resizeByteArray();
/*      */     }
/*  629 */     this.position += 2;
/*  630 */     this.bCodeStream[this.classFileOffset++] = 16;
/*  631 */     this.bCodeStream[this.classFileOffset++] = b;
/*      */   }
/*      */   
/*      */   public void caload() {
/*  635 */     this.countLabels = 0;
/*  636 */     this.stackDepth--;
/*  637 */     pushTypeBindingArray();
/*  638 */     if (this.classFileOffset >= this.bCodeStream.length) {
/*  639 */       resizeByteArray();
/*      */     }
/*  641 */     this.position++;
/*  642 */     this.bCodeStream[this.classFileOffset++] = 52;
/*      */   }
/*      */   
/*      */   public void castore() {
/*  646 */     this.countLabels = 0;
/*  647 */     this.stackDepth -= 3;
/*  648 */     popTypeBinding(3);
/*  649 */     if (this.classFileOffset >= this.bCodeStream.length) {
/*  650 */       resizeByteArray();
/*      */     }
/*  652 */     this.position++;
/*  653 */     this.bCodeStream[this.classFileOffset++] = 85;
/*      */   }
/*      */   
/*      */   public void checkcast(int baseId) {
/*  657 */     this.countLabels = 0;
/*  658 */     if (this.classFileOffset + 2 >= this.bCodeStream.length) {
/*  659 */       resizeByteArray();
/*      */     }
/*  661 */     this.position++;
/*  662 */     this.bCodeStream[this.classFileOffset++] = -64;
/*  663 */     switch (baseId) {
/*      */       case 3:
/*  665 */         writeUnsignedShort(this.constantPool.literalIndexForType(ConstantPool.JavaLangByteConstantPoolName));
/*      */         break;
/*      */       case 4:
/*  668 */         writeUnsignedShort(this.constantPool.literalIndexForType(ConstantPool.JavaLangShortConstantPoolName));
/*      */         break;
/*      */       case 2:
/*  671 */         writeUnsignedShort(this.constantPool.literalIndexForType(ConstantPool.JavaLangCharacterConstantPoolName));
/*      */         break;
/*      */       case 10:
/*  674 */         writeUnsignedShort(this.constantPool.literalIndexForType(ConstantPool.JavaLangIntegerConstantPoolName));
/*      */         break;
/*      */       case 7:
/*  677 */         writeUnsignedShort(this.constantPool.literalIndexForType(ConstantPool.JavaLangLongConstantPoolName));
/*      */         break;
/*      */       case 9:
/*  680 */         writeUnsignedShort(this.constantPool.literalIndexForType(ConstantPool.JavaLangFloatConstantPoolName));
/*      */         break;
/*      */       case 8:
/*  683 */         writeUnsignedShort(this.constantPool.literalIndexForType(ConstantPool.JavaLangDoubleConstantPoolName));
/*      */         break;
/*      */       case 5:
/*  686 */         writeUnsignedShort(this.constantPool.literalIndexForType(ConstantPool.JavaLangBooleanConstantPoolName)); break;
/*      */     } 
/*  688 */     pushTypeBinding(1, TypeBinding.wellKnownBaseType(baseId));
/*      */   }
/*      */   
/*      */   public void checkcast(TypeBinding typeBinding) {
/*  692 */     checkcast(null, typeBinding, -1);
/*      */   }
/*      */   
/*      */   public void checkcast(TypeReference typeReference, TypeBinding typeBinding, int currentPosition) {
/*  696 */     this.countLabels = 0;
/*  697 */     if (this.classFileOffset + 2 >= this.bCodeStream.length) {
/*  698 */       resizeByteArray();
/*      */     }
/*  700 */     this.position++;
/*  701 */     this.bCodeStream[this.classFileOffset++] = -64;
/*  702 */     writeUnsignedShort(this.constantPool.literalIndexForType(typeBinding));
/*  703 */     pushTypeBinding(1, typeBinding);
/*      */   }
/*      */ 
/*      */   
/*      */   public void d2f() {
/*  708 */     this.countLabels = 0;
/*  709 */     this.stackDepth--;
/*  710 */     pushTypeBinding(1, (TypeBinding)TypeBinding.FLOAT);
/*  711 */     if (this.classFileOffset >= this.bCodeStream.length) {
/*  712 */       resizeByteArray();
/*      */     }
/*  714 */     this.position++;
/*  715 */     this.bCodeStream[this.classFileOffset++] = -112;
/*      */   }
/*      */   
/*      */   public void d2i() {
/*  719 */     this.countLabels = 0;
/*  720 */     this.stackDepth--;
/*  721 */     pushTypeBinding(1, (TypeBinding)TypeBinding.INT);
/*  722 */     if (this.classFileOffset >= this.bCodeStream.length) {
/*  723 */       resizeByteArray();
/*      */     }
/*  725 */     this.position++;
/*  726 */     this.bCodeStream[this.classFileOffset++] = -114;
/*      */   }
/*      */   
/*      */   public void d2l() {
/*  730 */     this.countLabels = 0;
/*  731 */     if (this.classFileOffset >= this.bCodeStream.length) {
/*  732 */       resizeByteArray();
/*      */     }
/*  734 */     this.position++;
/*  735 */     this.bCodeStream[this.classFileOffset++] = -113;
/*  736 */     pushTypeBinding(1, (TypeBinding)TypeBinding.LONG);
/*      */   }
/*      */   
/*      */   public void dadd() {
/*  740 */     this.countLabels = 0;
/*  741 */     this.stackDepth -= 2;
/*  742 */     if (this.classFileOffset >= this.bCodeStream.length) {
/*  743 */       resizeByteArray();
/*      */     }
/*  745 */     this.position++;
/*  746 */     this.bCodeStream[this.classFileOffset++] = 99;
/*  747 */     pushTypeBinding(2, (TypeBinding)TypeBinding.DOUBLE);
/*      */   }
/*      */   
/*      */   public void daload() {
/*  751 */     this.countLabels = 0;
/*  752 */     if (this.classFileOffset >= this.bCodeStream.length) {
/*  753 */       resizeByteArray();
/*      */     }
/*  755 */     this.position++;
/*  756 */     this.bCodeStream[this.classFileOffset++] = 49;
/*  757 */     pushTypeBindingArray();
/*      */   }
/*      */   
/*      */   public void dastore() {
/*  761 */     this.countLabels = 0;
/*  762 */     this.stackDepth -= 4;
/*  763 */     if (this.classFileOffset >= this.bCodeStream.length) {
/*  764 */       resizeByteArray();
/*      */     }
/*  766 */     this.position++;
/*  767 */     this.bCodeStream[this.classFileOffset++] = 82;
/*  768 */     popTypeBinding(3);
/*      */   }
/*      */   
/*      */   public void dcmpg() {
/*  772 */     this.countLabels = 0;
/*  773 */     this.stackDepth -= 3;
/*  774 */     if (this.classFileOffset >= this.bCodeStream.length) {
/*  775 */       resizeByteArray();
/*      */     }
/*  777 */     this.position++;
/*  778 */     this.bCodeStream[this.classFileOffset++] = -104;
/*  779 */     pushTypeBinding(2, (TypeBinding)TypeBinding.INT);
/*      */   }
/*      */   
/*      */   public void dcmpl() {
/*  783 */     this.countLabels = 0;
/*  784 */     this.stackDepth -= 3;
/*  785 */     if (this.classFileOffset >= this.bCodeStream.length) {
/*  786 */       resizeByteArray();
/*      */     }
/*  788 */     this.position++;
/*  789 */     this.bCodeStream[this.classFileOffset++] = -105;
/*  790 */     pushTypeBinding(2, (TypeBinding)TypeBinding.INT);
/*      */   }
/*      */   
/*      */   public void dconst_0() {
/*  794 */     this.countLabels = 0;
/*  795 */     this.stackDepth += 2;
/*  796 */     pushTypeBinding((TypeBinding)TypeBinding.DOUBLE);
/*  797 */     if (this.stackDepth > this.stackMax)
/*  798 */       this.stackMax = this.stackDepth; 
/*  799 */     if (this.classFileOffset >= this.bCodeStream.length) {
/*  800 */       resizeByteArray();
/*      */     }
/*  802 */     this.position++;
/*  803 */     this.bCodeStream[this.classFileOffset++] = 14;
/*      */   }
/*      */   
/*      */   public void dconst_1() {
/*  807 */     this.countLabels = 0;
/*  808 */     this.stackDepth += 2;
/*  809 */     pushTypeBinding((TypeBinding)TypeBinding.DOUBLE);
/*  810 */     if (this.stackDepth > this.stackMax)
/*  811 */       this.stackMax = this.stackDepth; 
/*  812 */     if (this.classFileOffset >= this.bCodeStream.length) {
/*  813 */       resizeByteArray();
/*      */     }
/*  815 */     this.position++;
/*  816 */     this.bCodeStream[this.classFileOffset++] = 15;
/*      */   }
/*      */   
/*      */   public void ddiv() {
/*  820 */     this.countLabels = 0;
/*  821 */     this.stackDepth -= 2;
/*  822 */     pushTypeBinding(2, (TypeBinding)TypeBinding.DOUBLE);
/*  823 */     if (this.classFileOffset >= this.bCodeStream.length) {
/*  824 */       resizeByteArray();
/*      */     }
/*  826 */     this.position++;
/*  827 */     this.bCodeStream[this.classFileOffset++] = 111;
/*      */   }
/*      */   
/*      */   public void decrStackSize(int offset) {
/*  831 */     this.stackDepth -= offset;
/*      */   }
/*      */   
/*      */   public void dload(int iArg) {
/*  835 */     this.countLabels = 0;
/*  836 */     this.stackDepth += 2;
/*  837 */     if (this.stackDepth > this.stackMax)
/*  838 */       this.stackMax = this.stackDepth; 
/*  839 */     if (this.maxLocals < iArg + 2) {
/*  840 */       this.maxLocals = iArg + 2;
/*      */     }
/*  842 */     pushTypeBinding((TypeBinding)TypeBinding.DOUBLE);
/*  843 */     if (iArg > 255) {
/*  844 */       if (this.classFileOffset + 3 >= this.bCodeStream.length) {
/*  845 */         resizeByteArray();
/*      */       }
/*  847 */       this.position += 2;
/*  848 */       this.bCodeStream[this.classFileOffset++] = -60;
/*  849 */       this.bCodeStream[this.classFileOffset++] = 24;
/*  850 */       writeUnsignedShort(iArg);
/*      */     } else {
/*      */       
/*  853 */       if (this.classFileOffset + 1 >= this.bCodeStream.length) {
/*  854 */         resizeByteArray();
/*      */       }
/*  856 */       this.position += 2;
/*  857 */       this.bCodeStream[this.classFileOffset++] = 24;
/*  858 */       this.bCodeStream[this.classFileOffset++] = (byte)iArg;
/*      */     } 
/*      */   }
/*      */   
/*      */   public void dload_0() {
/*  863 */     this.countLabels = 0;
/*  864 */     this.stackDepth += 2;
/*  865 */     pushTypeBinding((TypeBinding)TypeBinding.DOUBLE);
/*  866 */     if (this.stackDepth > this.stackMax)
/*  867 */       this.stackMax = this.stackDepth; 
/*  868 */     if (this.maxLocals < 2) {
/*  869 */       this.maxLocals = 2;
/*      */     }
/*  871 */     if (this.classFileOffset >= this.bCodeStream.length) {
/*  872 */       resizeByteArray();
/*      */     }
/*  874 */     this.position++;
/*  875 */     this.bCodeStream[this.classFileOffset++] = 38;
/*      */   }
/*      */   
/*      */   public void dload_1() {
/*  879 */     this.countLabels = 0;
/*  880 */     this.stackDepth += 2;
/*  881 */     pushTypeBinding((TypeBinding)TypeBinding.DOUBLE);
/*  882 */     if (this.stackDepth > this.stackMax)
/*  883 */       this.stackMax = this.stackDepth; 
/*  884 */     if (this.maxLocals < 3) {
/*  885 */       this.maxLocals = 3;
/*      */     }
/*  887 */     if (this.classFileOffset >= this.bCodeStream.length) {
/*  888 */       resizeByteArray();
/*      */     }
/*  890 */     this.position++;
/*  891 */     this.bCodeStream[this.classFileOffset++] = 39;
/*      */   }
/*      */   
/*      */   public void dload_2() {
/*  895 */     this.countLabels = 0;
/*  896 */     this.stackDepth += 2;
/*  897 */     pushTypeBinding((TypeBinding)TypeBinding.DOUBLE);
/*  898 */     if (this.stackDepth > this.stackMax)
/*  899 */       this.stackMax = this.stackDepth; 
/*  900 */     if (this.maxLocals < 4) {
/*  901 */       this.maxLocals = 4;
/*      */     }
/*  903 */     if (this.classFileOffset >= this.bCodeStream.length) {
/*  904 */       resizeByteArray();
/*      */     }
/*  906 */     this.position++;
/*  907 */     this.bCodeStream[this.classFileOffset++] = 40;
/*      */   }
/*      */   
/*      */   public void dload_3() {
/*  911 */     this.countLabels = 0;
/*  912 */     this.stackDepth += 2;
/*  913 */     pushTypeBinding((TypeBinding)TypeBinding.DOUBLE);
/*  914 */     if (this.stackDepth > this.stackMax)
/*  915 */       this.stackMax = this.stackDepth; 
/*  916 */     if (this.maxLocals < 5) {
/*  917 */       this.maxLocals = 5;
/*      */     }
/*  919 */     if (this.classFileOffset >= this.bCodeStream.length) {
/*  920 */       resizeByteArray();
/*      */     }
/*  922 */     this.position++;
/*  923 */     this.bCodeStream[this.classFileOffset++] = 41;
/*      */   }
/*      */   
/*      */   public void dmul() {
/*  927 */     this.countLabels = 0;
/*  928 */     this.stackDepth -= 2;
/*  929 */     pushTypeBinding(2, (TypeBinding)TypeBinding.DOUBLE);
/*  930 */     if (this.classFileOffset >= this.bCodeStream.length) {
/*  931 */       resizeByteArray();
/*      */     }
/*  933 */     this.position++;
/*  934 */     this.bCodeStream[this.classFileOffset++] = 107;
/*      */   }
/*      */   
/*      */   public void dneg() {
/*  938 */     this.countLabels = 0;
/*  939 */     if (this.classFileOffset >= this.bCodeStream.length) {
/*  940 */       resizeByteArray();
/*      */     }
/*  942 */     this.position++;
/*  943 */     this.bCodeStream[this.classFileOffset++] = 119;
/*  944 */     pushTypeBinding(1, (TypeBinding)TypeBinding.DOUBLE);
/*      */   }
/*      */   
/*      */   public void drem() {
/*  948 */     this.countLabels = 0;
/*  949 */     pushTypeBinding(2, (TypeBinding)TypeBinding.DOUBLE);
/*  950 */     this.stackDepth -= 2;
/*  951 */     if (this.classFileOffset >= this.bCodeStream.length) {
/*  952 */       resizeByteArray();
/*      */     }
/*  954 */     this.position++;
/*  955 */     this.bCodeStream[this.classFileOffset++] = 115;
/*      */   }
/*      */   
/*      */   public void dreturn() {
/*  959 */     this.countLabels = 0;
/*  960 */     this.stackDepth -= 2;
/*  961 */     popTypeBinding();
/*      */     
/*  963 */     if (this.classFileOffset >= this.bCodeStream.length) {
/*  964 */       resizeByteArray();
/*      */     }
/*  966 */     this.position++;
/*  967 */     this.bCodeStream[this.classFileOffset++] = -81;
/*  968 */     this.lastAbruptCompletion = this.position;
/*      */   }
/*      */   
/*      */   public void dstore(int iArg) {
/*  972 */     this.countLabels = 0;
/*  973 */     this.stackDepth -= 2;
/*  974 */     popTypeBinding();
/*  975 */     if (this.maxLocals <= iArg + 1) {
/*  976 */       this.maxLocals = iArg + 2;
/*      */     }
/*  978 */     if (iArg > 255) {
/*  979 */       if (this.classFileOffset + 3 >= this.bCodeStream.length) {
/*  980 */         resizeByteArray();
/*      */       }
/*  982 */       this.position += 2;
/*  983 */       this.bCodeStream[this.classFileOffset++] = -60;
/*  984 */       this.bCodeStream[this.classFileOffset++] = 57;
/*  985 */       writeUnsignedShort(iArg);
/*      */     } else {
/*  987 */       if (this.classFileOffset + 1 >= this.bCodeStream.length) {
/*  988 */         resizeByteArray();
/*      */       }
/*  990 */       this.position += 2;
/*  991 */       this.bCodeStream[this.classFileOffset++] = 57;
/*  992 */       this.bCodeStream[this.classFileOffset++] = (byte)iArg;
/*      */     } 
/*      */   }
/*      */   
/*      */   public void dstore_0() {
/*  997 */     this.countLabels = 0;
/*  998 */     this.stackDepth -= 2;
/*  999 */     popTypeBinding();
/* 1000 */     if (this.maxLocals < 2) {
/* 1001 */       this.maxLocals = 2;
/*      */     }
/* 1003 */     if (this.classFileOffset >= this.bCodeStream.length) {
/* 1004 */       resizeByteArray();
/*      */     }
/* 1006 */     this.position++;
/* 1007 */     this.bCodeStream[this.classFileOffset++] = 71;
/*      */   }
/*      */   
/*      */   public void dstore_1() {
/* 1011 */     this.countLabels = 0;
/* 1012 */     this.stackDepth -= 2;
/* 1013 */     popTypeBinding();
/* 1014 */     if (this.maxLocals < 3) {
/* 1015 */       this.maxLocals = 3;
/*      */     }
/* 1017 */     if (this.classFileOffset >= this.bCodeStream.length) {
/* 1018 */       resizeByteArray();
/*      */     }
/* 1020 */     this.position++;
/* 1021 */     this.bCodeStream[this.classFileOffset++] = 72;
/*      */   }
/*      */   
/*      */   public void dstore_2() {
/* 1025 */     this.countLabels = 0;
/* 1026 */     this.stackDepth -= 2;
/* 1027 */     popTypeBinding();
/* 1028 */     if (this.maxLocals < 4) {
/* 1029 */       this.maxLocals = 4;
/*      */     }
/* 1031 */     if (this.classFileOffset >= this.bCodeStream.length) {
/* 1032 */       resizeByteArray();
/*      */     }
/* 1034 */     this.position++;
/* 1035 */     this.bCodeStream[this.classFileOffset++] = 73;
/*      */   }
/*      */   
/*      */   public void dstore_3() {
/* 1039 */     this.countLabels = 0;
/* 1040 */     this.stackDepth -= 2;
/* 1041 */     popTypeBinding();
/* 1042 */     if (this.maxLocals < 5) {
/* 1043 */       this.maxLocals = 5;
/*      */     }
/* 1045 */     if (this.classFileOffset >= this.bCodeStream.length) {
/* 1046 */       resizeByteArray();
/*      */     }
/* 1048 */     this.position++;
/* 1049 */     this.bCodeStream[this.classFileOffset++] = 74;
/*      */   }
/*      */   
/*      */   public void dsub() {
/* 1053 */     this.countLabels = 0;
/* 1054 */     this.stackDepth -= 2;
/* 1055 */     pushTypeBinding(2, (TypeBinding)TypeBinding.DOUBLE);
/* 1056 */     if (this.classFileOffset >= this.bCodeStream.length) {
/* 1057 */       resizeByteArray();
/*      */     }
/* 1059 */     this.position++;
/* 1060 */     this.bCodeStream[this.classFileOffset++] = 103;
/*      */   }
/*      */   
/*      */   public void dup() {
/* 1064 */     this.countLabels = 0;
/* 1065 */     this.stackDepth++;
/* 1066 */     if (isSwitchStackTrackingActive()) {
/* 1067 */       pushTypeBinding(this.switchSaveTypeBindings.peek());
/*      */     }
/* 1069 */     if (this.stackDepth > this.stackMax) {
/* 1070 */       this.stackMax = this.stackDepth;
/*      */     }
/* 1072 */     if (this.classFileOffset >= this.bCodeStream.length) {
/* 1073 */       resizeByteArray();
/*      */     }
/* 1075 */     this.position++;
/* 1076 */     this.bCodeStream[this.classFileOffset++] = 89;
/*      */   }
/*      */   
/*      */   private void adjustTypeBindingStackForDupX1() {
/* 1080 */     if (isSwitchStackTrackingActive()) {
/* 1081 */       TypeBinding[] topStack = { popTypeBinding(), popTypeBinding() };
/* 1082 */       pushTypeBinding(topStack[0]);
/* 1083 */       pushTypeBinding(topStack[1]);
/* 1084 */       pushTypeBinding(topStack[0]);
/*      */     } 
/*      */   }
/*      */   
/*      */   public void dup_x1() {
/* 1089 */     this.countLabels = 0;
/* 1090 */     this.stackDepth++;
/* 1091 */     adjustTypeBindingStackForDupX1();
/* 1092 */     if (this.stackDepth > this.stackMax)
/* 1093 */       this.stackMax = this.stackDepth; 
/* 1094 */     if (this.classFileOffset >= this.bCodeStream.length) {
/* 1095 */       resizeByteArray();
/*      */     }
/* 1097 */     this.position++;
/* 1098 */     this.bCodeStream[this.classFileOffset++] = 90;
/*      */   }
/*      */   
/*      */   private void adjustTypeBindingStackForDupX2() {
/* 1102 */     if (!isSwitchStackTrackingActive())
/*      */       return; 
/* 1104 */     TypeBinding val1 = popTypeBinding();
/* 1105 */     TypeBinding val2 = popTypeBinding();
/* 1106 */     if (TypeIds.getCategory(val1.id) == 1)
/* 1107 */       if (TypeIds.getCategory(val2.id) == 2) {
/* 1108 */         pushTypeBinding(val1);
/* 1109 */         pushTypeBinding(val2);
/* 1110 */         pushTypeBinding(val1);
/*      */       } else {
/* 1112 */         TypeBinding val3 = popTypeBinding();
/* 1113 */         if (TypeIds.getCategory(val3.id) == 1) {
/* 1114 */           pushTypeBinding(val1);
/* 1115 */           pushTypeBinding(val3);
/* 1116 */           pushTypeBinding(val2);
/* 1117 */           pushTypeBinding(val1);
/*      */         } 
/*      */       }  
/*      */   }
/*      */   
/*      */   public void dup_x2() {
/* 1123 */     this.countLabels = 0;
/* 1124 */     this.stackDepth++;
/* 1125 */     adjustTypeBindingStackForDupX2();
/* 1126 */     if (this.stackDepth > this.stackMax)
/* 1127 */       this.stackMax = this.stackDepth; 
/* 1128 */     if (this.classFileOffset >= this.bCodeStream.length) {
/* 1129 */       resizeByteArray();
/*      */     }
/* 1131 */     this.position++;
/* 1132 */     this.bCodeStream[this.classFileOffset++] = 91;
/*      */   }
/*      */   
/*      */   private void adjustTypeBindingStackForDup2() {
/* 1136 */     if (!isSwitchStackTrackingActive())
/*      */       return; 
/* 1138 */     TypeBinding val1 = popTypeBinding();
/* 1139 */     if (TypeIds.getCategory(val1.id) == 2) {
/* 1140 */       pushTypeBinding(val1);
/* 1141 */       pushTypeBinding(val1);
/*      */     } else {
/* 1143 */       TypeBinding val2 = popTypeBinding();
/* 1144 */       if (TypeIds.getCategory(val2.id) == 1) {
/* 1145 */         pushTypeBinding(val2);
/* 1146 */         pushTypeBinding(val1);
/* 1147 */         pushTypeBinding(val2);
/* 1148 */         pushTypeBinding(val1);
/*      */       } 
/*      */     } 
/*      */   }
/*      */   public void dup2() {
/* 1153 */     this.countLabels = 0;
/* 1154 */     this.stackDepth += 2;
/* 1155 */     adjustTypeBindingStackForDup2();
/* 1156 */     if (this.stackDepth > this.stackMax)
/* 1157 */       this.stackMax = this.stackDepth; 
/* 1158 */     if (this.classFileOffset >= this.bCodeStream.length) {
/* 1159 */       resizeByteArray();
/*      */     }
/* 1161 */     this.position++;
/* 1162 */     this.bCodeStream[this.classFileOffset++] = 92;
/*      */   }
/*      */   
/*      */   private void adjustTypeBindingStackForDup2X1() {
/* 1166 */     if (!isSwitchStackTrackingActive())
/*      */       return; 
/* 1168 */     TypeBinding val1 = popTypeBinding();
/* 1169 */     TypeBinding val2 = popTypeBinding();
/* 1170 */     if (TypeIds.getCategory(val1.id) == 2) {
/* 1171 */       if (TypeIds.getCategory(val2.id) == 1) {
/* 1172 */         pushTypeBinding(val1);
/* 1173 */         pushTypeBinding(val2);
/* 1174 */         pushTypeBinding(val1);
/*      */       }
/*      */     
/* 1177 */     } else if (TypeIds.getCategory(val2.id) == 1) {
/* 1178 */       TypeBinding val3 = popTypeBinding();
/* 1179 */       if (TypeIds.getCategory(val3.id) == 1) {
/* 1180 */         pushTypeBinding(val2);
/* 1181 */         pushTypeBinding(val1);
/* 1182 */         pushTypeBinding(val3);
/* 1183 */         pushTypeBinding(val2);
/* 1184 */         pushTypeBinding(val1);
/*      */       } 
/*      */     } 
/*      */   }
/*      */   
/*      */   public void dup2_x1() {
/* 1190 */     this.countLabels = 0;
/* 1191 */     this.stackDepth += 2;
/* 1192 */     adjustTypeBindingStackForDup2X1();
/* 1193 */     if (this.stackDepth > this.stackMax)
/* 1194 */       this.stackMax = this.stackDepth; 
/* 1195 */     if (this.classFileOffset >= this.bCodeStream.length) {
/* 1196 */       resizeByteArray();
/*      */     }
/* 1198 */     this.position++;
/* 1199 */     this.bCodeStream[this.classFileOffset++] = 93;
/*      */   }
/*      */   
/*      */   private void adjustTypeBindingStackForDup2X2() {
/* 1203 */     if (!isSwitchStackTrackingActive())
/*      */       return; 
/* 1205 */     TypeBinding val1 = popTypeBinding();
/* 1206 */     if (TypeIds.getCategory(val1.id) == 2) {
/* 1207 */       TypeBinding val2 = popTypeBinding();
/* 1208 */       if (TypeIds.getCategory(val2.id) == 2) {
/* 1209 */         pushTypeBinding(val1);
/* 1210 */         pushTypeBinding(val2);
/* 1211 */         pushTypeBinding(val1);
/*      */       } else {
/* 1213 */         TypeBinding val3 = popTypeBinding();
/* 1214 */         if (TypeIds.getCategory(val3.id) == 1) {
/* 1215 */           pushTypeBinding(val1);
/* 1216 */           pushTypeBinding(val3);
/* 1217 */           pushTypeBinding(val2);
/* 1218 */           pushTypeBinding(val1);
/*      */         } 
/*      */       } 
/* 1221 */       pushTypeBinding(val1);
/* 1222 */       pushTypeBinding(val1);
/*      */     } else {
/* 1224 */       TypeBinding val2 = popTypeBinding();
/* 1225 */       if (TypeIds.getCategory(val2.id) == 1) {
/* 1226 */         TypeBinding val3 = popTypeBinding();
/* 1227 */         if (TypeIds.getCategory(val3.id) == 2) {
/* 1228 */           pushTypeBinding(val2);
/* 1229 */           pushTypeBinding(val1);
/* 1230 */           pushTypeBinding(val3);
/* 1231 */           pushTypeBinding(val2);
/* 1232 */           pushTypeBinding(val1);
/*      */         } else {
/* 1234 */           TypeBinding val4 = popTypeBinding();
/* 1235 */           if (TypeIds.getCategory(val4.id) == 1) {
/* 1236 */             pushTypeBinding(val2);
/* 1237 */             pushTypeBinding(val1);
/* 1238 */             pushTypeBinding(val4);
/* 1239 */             pushTypeBinding(val3);
/* 1240 */             pushTypeBinding(val2);
/* 1241 */             pushTypeBinding(val1);
/*      */           } 
/*      */         } 
/*      */       } 
/*      */     } 
/*      */   }
/*      */   public void dup2_x2() {
/* 1248 */     this.countLabels = 0;
/* 1249 */     this.stackDepth += 2;
/* 1250 */     adjustTypeBindingStackForDup2X2();
/* 1251 */     if (this.stackDepth > this.stackMax)
/* 1252 */       this.stackMax = this.stackDepth; 
/* 1253 */     if (this.classFileOffset >= this.bCodeStream.length) {
/* 1254 */       resizeByteArray();
/*      */     }
/* 1256 */     this.position++;
/* 1257 */     this.bCodeStream[this.classFileOffset++] = 94;
/*      */   }
/*      */ 
/*      */   
/*      */   public void exitUserScope(BlockScope currentScope) {
/* 1262 */     if ((this.generateAttributes & 0x1C) == 0) {
/*      */       return;
/*      */     }
/*      */     
/* 1266 */     int index = this.visibleLocalsCount - 1;
/* 1267 */     while (index >= 0) {
/* 1268 */       LocalVariableBinding visibleLocal = this.visibleLocals[index];
/* 1269 */       if (visibleLocal == null || visibleLocal.declaringScope != currentScope) {
/*      */         
/* 1271 */         index--;
/*      */         
/*      */         continue;
/*      */       } 
/*      */       
/* 1276 */       if (visibleLocal.initializationCount > 0) {
/* 1277 */         visibleLocal.recordInitializationEndPC(this.position);
/*      */       }
/* 1279 */       this.visibleLocals[index--] = null;
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public void exitUserScope(BlockScope currentScope, LocalVariableBinding binding) {
/* 1285 */     if ((this.generateAttributes & 0x1C) == 0) {
/*      */       return;
/*      */     }
/*      */     
/* 1289 */     int index = this.visibleLocalsCount - 1;
/* 1290 */     while (index >= 0) {
/* 1291 */       LocalVariableBinding visibleLocal = this.visibleLocals[index];
/* 1292 */       if (visibleLocal == null || visibleLocal.declaringScope != currentScope || visibleLocal == binding) {
/*      */         
/* 1294 */         index--;
/*      */         
/*      */         continue;
/*      */       } 
/* 1298 */       if (visibleLocal.initializationCount > 0) {
/* 1299 */         visibleLocal.recordInitializationEndPC(this.position);
/*      */       }
/* 1301 */       this.visibleLocals[index--] = null;
/*      */     } 
/*      */   }
/*      */   
/*      */   public void f2d() {
/* 1306 */     this.countLabels = 0;
/* 1307 */     this.stackDepth++;
/* 1308 */     pushTypeBinding(1, (TypeBinding)TypeBinding.DOUBLE);
/* 1309 */     if (this.stackDepth > this.stackMax)
/* 1310 */       this.stackMax = this.stackDepth; 
/* 1311 */     if (this.classFileOffset >= this.bCodeStream.length) {
/* 1312 */       resizeByteArray();
/*      */     }
/* 1314 */     this.position++;
/* 1315 */     this.bCodeStream[this.classFileOffset++] = -115;
/*      */   }
/*      */   
/*      */   public void f2i() {
/* 1319 */     this.countLabels = 0;
/* 1320 */     if (this.classFileOffset >= this.bCodeStream.length) {
/* 1321 */       resizeByteArray();
/*      */     }
/* 1323 */     this.position++;
/* 1324 */     this.bCodeStream[this.classFileOffset++] = -117;
/* 1325 */     pushTypeBinding(1, (TypeBinding)TypeBinding.INT);
/*      */   }
/*      */   
/*      */   public void f2l() {
/* 1329 */     this.countLabels = 0;
/* 1330 */     this.stackDepth++;
/* 1331 */     pushTypeBinding(1, (TypeBinding)TypeBinding.LONG);
/* 1332 */     if (this.stackDepth > this.stackMax)
/* 1333 */       this.stackMax = this.stackDepth; 
/* 1334 */     if (this.classFileOffset >= this.bCodeStream.length) {
/* 1335 */       resizeByteArray();
/*      */     }
/* 1337 */     this.position++;
/* 1338 */     this.bCodeStream[this.classFileOffset++] = -116;
/*      */   }
/*      */   
/*      */   public void fadd() {
/* 1342 */     this.countLabels = 0;
/* 1343 */     this.stackDepth--;
/* 1344 */     pushTypeBinding(2, (TypeBinding)TypeBinding.FLOAT);
/* 1345 */     if (this.classFileOffset >= this.bCodeStream.length) {
/* 1346 */       resizeByteArray();
/*      */     }
/* 1348 */     this.position++;
/* 1349 */     this.bCodeStream[this.classFileOffset++] = 98;
/*      */   }
/*      */   
/*      */   public void faload() {
/* 1353 */     this.countLabels = 0;
/* 1354 */     this.stackDepth--;
/* 1355 */     pushTypeBindingArray();
/* 1356 */     if (this.classFileOffset >= this.bCodeStream.length) {
/* 1357 */       resizeByteArray();
/*      */     }
/* 1359 */     this.position++;
/* 1360 */     this.bCodeStream[this.classFileOffset++] = 48;
/*      */   }
/*      */   
/*      */   public void fastore() {
/* 1364 */     this.countLabels = 0;
/* 1365 */     this.stackDepth -= 3;
/* 1366 */     popTypeBinding(3);
/* 1367 */     if (this.classFileOffset >= this.bCodeStream.length) {
/* 1368 */       resizeByteArray();
/*      */     }
/* 1370 */     this.position++;
/* 1371 */     this.bCodeStream[this.classFileOffset++] = 81;
/*      */   }
/*      */   
/*      */   public void fcmpg() {
/* 1375 */     this.countLabels = 0;
/* 1376 */     this.stackDepth--;
/* 1377 */     pushTypeBinding(2, (TypeBinding)TypeBinding.FLOAT);
/* 1378 */     if (this.classFileOffset >= this.bCodeStream.length) {
/* 1379 */       resizeByteArray();
/*      */     }
/* 1381 */     this.position++;
/* 1382 */     this.bCodeStream[this.classFileOffset++] = -106;
/*      */   }
/*      */   
/*      */   public void fcmpl() {
/* 1386 */     this.countLabels = 0;
/* 1387 */     this.stackDepth--;
/* 1388 */     pushTypeBinding(2, (TypeBinding)TypeBinding.FLOAT);
/* 1389 */     if (this.classFileOffset >= this.bCodeStream.length) {
/* 1390 */       resizeByteArray();
/*      */     }
/* 1392 */     this.position++;
/* 1393 */     this.bCodeStream[this.classFileOffset++] = -107;
/*      */   }
/*      */   
/*      */   public void fconst_0() {
/* 1397 */     this.countLabels = 0;
/* 1398 */     this.stackDepth++;
/* 1399 */     pushTypeBinding((TypeBinding)TypeBinding.FLOAT);
/* 1400 */     if (this.stackDepth > this.stackMax)
/* 1401 */       this.stackMax = this.stackDepth; 
/* 1402 */     if (this.classFileOffset >= this.bCodeStream.length) {
/* 1403 */       resizeByteArray();
/*      */     }
/* 1405 */     this.position++;
/* 1406 */     this.bCodeStream[this.classFileOffset++] = 11;
/*      */   }
/*      */   
/*      */   public void fconst_1() {
/* 1410 */     this.countLabels = 0;
/* 1411 */     this.stackDepth++;
/* 1412 */     pushTypeBinding((TypeBinding)TypeBinding.FLOAT);
/* 1413 */     if (this.stackDepth > this.stackMax)
/* 1414 */       this.stackMax = this.stackDepth; 
/* 1415 */     if (this.classFileOffset >= this.bCodeStream.length) {
/* 1416 */       resizeByteArray();
/*      */     }
/* 1418 */     this.position++;
/* 1419 */     this.bCodeStream[this.classFileOffset++] = 12;
/*      */   }
/*      */   
/*      */   public void fconst_2() {
/* 1423 */     this.countLabels = 0;
/* 1424 */     this.stackDepth++;
/* 1425 */     pushTypeBinding((TypeBinding)TypeBinding.FLOAT);
/* 1426 */     if (this.stackDepth > this.stackMax)
/* 1427 */       this.stackMax = this.stackDepth; 
/* 1428 */     if (this.classFileOffset >= this.bCodeStream.length) {
/* 1429 */       resizeByteArray();
/*      */     }
/* 1431 */     this.position++;
/* 1432 */     this.bCodeStream[this.classFileOffset++] = 13;
/*      */   }
/*      */   
/*      */   public void fdiv() {
/* 1436 */     this.countLabels = 0;
/* 1437 */     this.stackDepth--;
/* 1438 */     pushTypeBinding(2, (TypeBinding)TypeBinding.FLOAT);
/* 1439 */     if (this.classFileOffset >= this.bCodeStream.length) {
/* 1440 */       resizeByteArray();
/*      */     }
/* 1442 */     this.position++;
/* 1443 */     this.bCodeStream[this.classFileOffset++] = 110;
/*      */   } public void fieldAccess(byte opcode, FieldBinding fieldBinding, TypeBinding declaringClass) {
/*      */     ReferenceBinding referenceBinding;
/*      */     int returnTypeSize;
/* 1447 */     if (declaringClass == null) referenceBinding = fieldBinding.declaringClass; 
/* 1448 */     if ((((TypeBinding)referenceBinding).tagBits & 0x800L) != 0L) {
/* 1449 */       Util.recordNestedType(this.classFile, (TypeBinding)referenceBinding);
/*      */     }
/* 1451 */     TypeBinding returnType = fieldBinding.type;
/*      */     
/* 1453 */     switch (returnType.id) {
/*      */       case 7:
/*      */       case 8:
/* 1456 */         returnTypeSize = 2;
/*      */         break;
/*      */       default:
/* 1459 */         returnTypeSize = 1;
/*      */         break;
/*      */     } 
/* 1462 */     fieldAccess(opcode, returnTypeSize, referenceBinding.constantPoolName(), fieldBinding.name, returnType.signature(), returnType.id, returnType);
/*      */   }
/*      */   
/*      */   private void fieldAccess(byte opcode, int returnTypeSize, char[] declaringClass, char[] fieldName, char[] signature, int typeId) {
/* 1466 */     fieldAccess(opcode, returnTypeSize, declaringClass, fieldName, signature, typeId, null);
/*      */   }
/*      */   private void fieldAccess(byte opcode, int returnTypeSize, char[] declaringClass, char[] fieldName, char[] signature, int typeId, TypeBinding typeBinding) {
/* 1469 */     this.countLabels = 0;
/* 1470 */     switch (opcode) {
/*      */       case -76:
/* 1472 */         if (returnTypeSize == 2) {
/* 1473 */           this.stackDepth++;
/*      */         }
/* 1475 */         pushTypeBinding(1, typeBinding);
/*      */         break;
/*      */       case -78:
/* 1478 */         if (returnTypeSize == 2) {
/* 1479 */           this.stackDepth += 2;
/* 1480 */           pushTypeBinding(typeBinding); break;
/*      */         } 
/* 1482 */         this.stackDepth++;
/* 1483 */         pushTypeBinding(typeBinding);
/*      */         break;
/*      */       
/*      */       case -75:
/* 1487 */         if (returnTypeSize == 2) {
/* 1488 */           this.stackDepth -= 3;
/* 1489 */           popTypeBinding(2); break;
/*      */         } 
/* 1491 */         this.stackDepth -= 2;
/* 1492 */         popTypeBinding(2);
/*      */         break;
/*      */       
/*      */       case -77:
/* 1496 */         if (returnTypeSize == 2) {
/* 1497 */           this.stackDepth -= 2;
/* 1498 */           popTypeBinding(); break;
/*      */         } 
/* 1500 */         this.stackDepth--;
/* 1501 */         popTypeBinding();
/*      */         break;
/*      */     } 
/* 1504 */     if (this.stackDepth > this.stackMax) {
/* 1505 */       this.stackMax = this.stackDepth;
/*      */     }
/* 1507 */     if (this.classFileOffset + 2 >= this.bCodeStream.length) {
/* 1508 */       resizeByteArray();
/*      */     }
/* 1510 */     this.position++;
/* 1511 */     this.bCodeStream[this.classFileOffset++] = opcode;
/* 1512 */     writeUnsignedShort(this.constantPool.literalIndexForField(declaringClass, fieldName, signature));
/*      */   }
/*      */   
/*      */   public void fload(int iArg) {
/* 1516 */     this.countLabels = 0;
/* 1517 */     this.stackDepth++;
/* 1518 */     if (this.maxLocals <= iArg) {
/* 1519 */       this.maxLocals = iArg + 1;
/*      */     }
/* 1521 */     pushTypeBinding((TypeBinding)TypeBinding.FLOAT);
/* 1522 */     if (this.stackDepth > this.stackMax)
/* 1523 */       this.stackMax = this.stackDepth; 
/* 1524 */     if (iArg > 255) {
/* 1525 */       if (this.classFileOffset + 3 >= this.bCodeStream.length) {
/* 1526 */         resizeByteArray();
/*      */       }
/* 1528 */       this.position += 2;
/* 1529 */       this.bCodeStream[this.classFileOffset++] = -60;
/* 1530 */       this.bCodeStream[this.classFileOffset++] = 23;
/* 1531 */       writeUnsignedShort(iArg);
/*      */     } else {
/* 1533 */       if (this.classFileOffset + 1 >= this.bCodeStream.length) {
/* 1534 */         resizeByteArray();
/*      */       }
/* 1536 */       this.position += 2;
/* 1537 */       this.bCodeStream[this.classFileOffset++] = 23;
/* 1538 */       this.bCodeStream[this.classFileOffset++] = (byte)iArg;
/*      */     } 
/*      */   }
/*      */   
/*      */   public void fload_0() {
/* 1543 */     this.countLabels = 0;
/* 1544 */     this.stackDepth++;
/* 1545 */     pushTypeBinding((TypeBinding)TypeBinding.FLOAT);
/* 1546 */     if (this.maxLocals == 0) {
/* 1547 */       this.maxLocals = 1;
/*      */     }
/* 1549 */     if (this.stackDepth > this.stackMax)
/* 1550 */       this.stackMax = this.stackDepth; 
/* 1551 */     if (this.classFileOffset >= this.bCodeStream.length) {
/* 1552 */       resizeByteArray();
/*      */     }
/* 1554 */     this.position++;
/* 1555 */     this.bCodeStream[this.classFileOffset++] = 34;
/*      */   }
/*      */   
/*      */   public void fload_1() {
/* 1559 */     this.countLabels = 0;
/* 1560 */     this.stackDepth++;
/* 1561 */     pushTypeBinding((TypeBinding)TypeBinding.FLOAT);
/* 1562 */     if (this.maxLocals <= 1) {
/* 1563 */       this.maxLocals = 2;
/*      */     }
/* 1565 */     if (this.stackDepth > this.stackMax)
/* 1566 */       this.stackMax = this.stackDepth; 
/* 1567 */     if (this.classFileOffset >= this.bCodeStream.length) {
/* 1568 */       resizeByteArray();
/*      */     }
/* 1570 */     this.position++;
/* 1571 */     this.bCodeStream[this.classFileOffset++] = 35;
/*      */   }
/*      */   
/*      */   public void fload_2() {
/* 1575 */     this.countLabels = 0;
/* 1576 */     this.stackDepth++;
/* 1577 */     pushTypeBinding((TypeBinding)TypeBinding.FLOAT);
/* 1578 */     if (this.maxLocals <= 2) {
/* 1579 */       this.maxLocals = 3;
/*      */     }
/* 1581 */     if (this.stackDepth > this.stackMax)
/* 1582 */       this.stackMax = this.stackDepth; 
/* 1583 */     if (this.classFileOffset >= this.bCodeStream.length) {
/* 1584 */       resizeByteArray();
/*      */     }
/* 1586 */     this.position++;
/* 1587 */     this.bCodeStream[this.classFileOffset++] = 36;
/*      */   }
/*      */   
/*      */   public void fload_3() {
/* 1591 */     this.countLabels = 0;
/* 1592 */     this.stackDepth++;
/* 1593 */     pushTypeBinding((TypeBinding)TypeBinding.FLOAT);
/* 1594 */     if (this.maxLocals <= 3) {
/* 1595 */       this.maxLocals = 4;
/*      */     }
/* 1597 */     if (this.stackDepth > this.stackMax)
/* 1598 */       this.stackMax = this.stackDepth; 
/* 1599 */     if (this.classFileOffset >= this.bCodeStream.length) {
/* 1600 */       resizeByteArray();
/*      */     }
/* 1602 */     this.position++;
/* 1603 */     this.bCodeStream[this.classFileOffset++] = 37;
/*      */   }
/*      */   
/*      */   public void fmul() {
/* 1607 */     this.countLabels = 0;
/* 1608 */     this.stackDepth--;
/* 1609 */     pushTypeBinding(2, (TypeBinding)TypeBinding.FLOAT);
/* 1610 */     if (this.classFileOffset >= this.bCodeStream.length) {
/* 1611 */       resizeByteArray();
/*      */     }
/* 1613 */     this.position++;
/* 1614 */     this.bCodeStream[this.classFileOffset++] = 106;
/*      */   }
/*      */   
/*      */   public void fneg() {
/* 1618 */     this.countLabels = 0;
/* 1619 */     if (this.classFileOffset >= this.bCodeStream.length) {
/* 1620 */       resizeByteArray();
/*      */     }
/* 1622 */     this.position++;
/* 1623 */     this.bCodeStream[this.classFileOffset++] = 118;
/* 1624 */     pushTypeBinding(1, (TypeBinding)TypeBinding.FLOAT);
/*      */   }
/*      */   
/*      */   public void frem() {
/* 1628 */     this.countLabels = 0;
/* 1629 */     this.stackDepth--;
/* 1630 */     pushTypeBinding(2, (TypeBinding)TypeBinding.FLOAT);
/* 1631 */     if (this.classFileOffset >= this.bCodeStream.length) {
/* 1632 */       resizeByteArray();
/*      */     }
/* 1634 */     this.position++;
/* 1635 */     this.bCodeStream[this.classFileOffset++] = 114;
/*      */   }
/*      */   
/*      */   public void freturn() {
/* 1639 */     this.countLabels = 0;
/* 1640 */     this.stackDepth--;
/* 1641 */     popTypeBinding();
/*      */     
/* 1643 */     if (this.classFileOffset >= this.bCodeStream.length) {
/* 1644 */       resizeByteArray();
/*      */     }
/* 1646 */     this.position++;
/* 1647 */     this.bCodeStream[this.classFileOffset++] = -82;
/* 1648 */     this.lastAbruptCompletion = this.position;
/*      */   }
/*      */   
/*      */   public void fstore(int iArg) {
/* 1652 */     this.countLabels = 0;
/* 1653 */     this.stackDepth--;
/* 1654 */     popTypeBinding();
/* 1655 */     if (this.maxLocals <= iArg) {
/* 1656 */       this.maxLocals = iArg + 1;
/*      */     }
/* 1658 */     if (iArg > 255) {
/* 1659 */       if (this.classFileOffset + 3 >= this.bCodeStream.length) {
/* 1660 */         resizeByteArray();
/*      */       }
/* 1662 */       this.position += 2;
/* 1663 */       this.bCodeStream[this.classFileOffset++] = -60;
/* 1664 */       this.bCodeStream[this.classFileOffset++] = 56;
/* 1665 */       writeUnsignedShort(iArg);
/*      */     } else {
/* 1667 */       if (this.classFileOffset + 1 >= this.bCodeStream.length) {
/* 1668 */         resizeByteArray();
/*      */       }
/* 1670 */       this.position += 2;
/* 1671 */       this.bCodeStream[this.classFileOffset++] = 56;
/* 1672 */       this.bCodeStream[this.classFileOffset++] = (byte)iArg;
/*      */     } 
/*      */   }
/*      */   
/*      */   public void fstore_0() {
/* 1677 */     this.countLabels = 0;
/* 1678 */     this.stackDepth--;
/* 1679 */     popTypeBinding();
/* 1680 */     if (this.maxLocals == 0) {
/* 1681 */       this.maxLocals = 1;
/*      */     }
/* 1683 */     if (this.classFileOffset >= this.bCodeStream.length) {
/* 1684 */       resizeByteArray();
/*      */     }
/* 1686 */     this.position++;
/* 1687 */     this.bCodeStream[this.classFileOffset++] = 67;
/*      */   }
/*      */   
/*      */   public void fstore_1() {
/* 1691 */     this.countLabels = 0;
/* 1692 */     this.stackDepth--;
/* 1693 */     popTypeBinding();
/* 1694 */     if (this.maxLocals <= 1) {
/* 1695 */       this.maxLocals = 2;
/*      */     }
/* 1697 */     if (this.classFileOffset >= this.bCodeStream.length) {
/* 1698 */       resizeByteArray();
/*      */     }
/* 1700 */     this.position++;
/* 1701 */     this.bCodeStream[this.classFileOffset++] = 68;
/*      */   }
/*      */   
/*      */   public void fstore_2() {
/* 1705 */     this.countLabels = 0;
/* 1706 */     this.stackDepth--;
/* 1707 */     popTypeBinding();
/* 1708 */     if (this.maxLocals <= 2) {
/* 1709 */       this.maxLocals = 3;
/*      */     }
/* 1711 */     if (this.classFileOffset >= this.bCodeStream.length) {
/* 1712 */       resizeByteArray();
/*      */     }
/* 1714 */     this.position++;
/* 1715 */     this.bCodeStream[this.classFileOffset++] = 69;
/*      */   }
/*      */   
/*      */   public void fstore_3() {
/* 1719 */     this.countLabels = 0;
/* 1720 */     this.stackDepth--;
/* 1721 */     popTypeBinding();
/* 1722 */     if (this.maxLocals <= 3) {
/* 1723 */       this.maxLocals = 4;
/*      */     }
/* 1725 */     if (this.classFileOffset >= this.bCodeStream.length) {
/* 1726 */       resizeByteArray();
/*      */     }
/* 1728 */     this.position++;
/* 1729 */     this.bCodeStream[this.classFileOffset++] = 70;
/*      */   }
/*      */   
/*      */   public void fsub() {
/* 1733 */     this.countLabels = 0;
/* 1734 */     this.stackDepth--;
/* 1735 */     pushTypeBinding(2, (TypeBinding)TypeBinding.FLOAT);
/* 1736 */     if (this.classFileOffset >= this.bCodeStream.length) {
/* 1737 */       resizeByteArray();
/*      */     }
/* 1739 */     this.position++;
/* 1740 */     this.bCodeStream[this.classFileOffset++] = 102;
/*      */   }
/*      */   
/*      */   public void generateBoxingConversion(int unboxedTypeID) {
/* 1744 */     switch (unboxedTypeID) {
/*      */       case 3:
/* 1746 */         if (this.targetLevel >= 3211264L) {
/*      */           
/* 1748 */           invoke((byte)
/* 1749 */               -72, 
/* 1750 */               1, 
/* 1751 */               1, 
/* 1752 */               ConstantPool.JavaLangByteConstantPoolName, 
/* 1753 */               ConstantPool.ValueOf, 
/* 1754 */               ConstantPool.byteByteSignature, 
/* 1755 */               unboxedTypeID, 
/* 1756 */               (TypeBinding)TypeBinding.BYTE);
/*      */           break;
/*      */         } 
/* 1759 */         newWrapperFor(unboxedTypeID);
/* 1760 */         dup_x1();
/* 1761 */         swap();
/* 1762 */         invoke((byte)
/* 1763 */             -73, 
/* 1764 */             2, 
/* 1765 */             0, 
/* 1766 */             ConstantPool.JavaLangByteConstantPoolName, 
/* 1767 */             ConstantPool.Init, 
/* 1768 */             ConstantPool.ByteConstrSignature, 
/* 1769 */             unboxedTypeID, 
/* 1770 */             (TypeBinding)TypeBinding.BYTE);
/*      */         break;
/*      */       
/*      */       case 4:
/* 1774 */         if (this.targetLevel >= 3211264L) {
/*      */           
/* 1776 */           invoke((byte)
/* 1777 */               -72, 
/* 1778 */               1, 
/* 1779 */               1, 
/* 1780 */               ConstantPool.JavaLangShortConstantPoolName, 
/* 1781 */               ConstantPool.ValueOf, 
/* 1782 */               ConstantPool.shortShortSignature, 
/* 1783 */               unboxedTypeID, 
/* 1784 */               (TypeBinding)TypeBinding.SHORT);
/*      */           break;
/*      */         } 
/* 1787 */         newWrapperFor(unboxedTypeID);
/* 1788 */         dup_x1();
/* 1789 */         swap();
/* 1790 */         invoke((byte)
/* 1791 */             -73, 
/* 1792 */             2, 
/* 1793 */             0, 
/* 1794 */             ConstantPool.JavaLangShortConstantPoolName, 
/* 1795 */             ConstantPool.Init, 
/* 1796 */             ConstantPool.ShortConstrSignature, 
/* 1797 */             unboxedTypeID, 
/* 1798 */             (TypeBinding)TypeBinding.SHORT);
/*      */         break;
/*      */       
/*      */       case 2:
/* 1802 */         if (this.targetLevel >= 3211264L) {
/*      */           
/* 1804 */           invoke((byte)
/* 1805 */               -72, 
/* 1806 */               1, 
/* 1807 */               1, 
/* 1808 */               ConstantPool.JavaLangCharacterConstantPoolName, 
/* 1809 */               ConstantPool.ValueOf, 
/* 1810 */               ConstantPool.charCharacterSignature, 
/* 1811 */               unboxedTypeID, 
/* 1812 */               (TypeBinding)TypeBinding.CHAR);
/*      */           break;
/*      */         } 
/* 1815 */         newWrapperFor(unboxedTypeID);
/* 1816 */         dup_x1();
/* 1817 */         swap();
/* 1818 */         invoke((byte)
/* 1819 */             -73, 
/* 1820 */             2, 
/* 1821 */             0, 
/* 1822 */             ConstantPool.JavaLangCharacterConstantPoolName, 
/* 1823 */             ConstantPool.Init, 
/* 1824 */             ConstantPool.CharConstrSignature, 
/* 1825 */             unboxedTypeID, 
/* 1826 */             (TypeBinding)TypeBinding.CHAR);
/*      */         break;
/*      */       
/*      */       case 10:
/* 1830 */         if (this.targetLevel >= 3211264L) {
/*      */           
/* 1832 */           invoke((byte)
/* 1833 */               -72, 
/* 1834 */               1, 
/* 1835 */               1, 
/* 1836 */               ConstantPool.JavaLangIntegerConstantPoolName, 
/* 1837 */               ConstantPool.ValueOf, 
/* 1838 */               ConstantPool.IntIntegerSignature, 
/* 1839 */               unboxedTypeID, 
/* 1840 */               (TypeBinding)TypeBinding.INT);
/*      */           break;
/*      */         } 
/* 1843 */         newWrapperFor(unboxedTypeID);
/* 1844 */         dup_x1();
/* 1845 */         swap();
/* 1846 */         invoke((byte)
/* 1847 */             -73, 
/* 1848 */             2, 
/* 1849 */             0, 
/* 1850 */             ConstantPool.JavaLangIntegerConstantPoolName, 
/* 1851 */             ConstantPool.Init, 
/* 1852 */             ConstantPool.IntConstrSignature, 
/* 1853 */             unboxedTypeID, 
/* 1854 */             (TypeBinding)TypeBinding.INT);
/*      */         break;
/*      */       
/*      */       case 7:
/* 1858 */         if (this.targetLevel >= 3211264L) {
/*      */           
/* 1860 */           invoke((byte)
/* 1861 */               -72, 
/* 1862 */               2, 
/* 1863 */               1, 
/* 1864 */               ConstantPool.JavaLangLongConstantPoolName, 
/* 1865 */               ConstantPool.ValueOf, 
/* 1866 */               ConstantPool.longLongSignature, 
/* 1867 */               unboxedTypeID, 
/* 1868 */               (TypeBinding)TypeBinding.LONG);
/*      */           break;
/*      */         } 
/* 1871 */         newWrapperFor(unboxedTypeID);
/* 1872 */         dup_x2();
/* 1873 */         dup_x2();
/* 1874 */         pop();
/* 1875 */         invoke((byte)
/* 1876 */             -73, 
/* 1877 */             3, 
/* 1878 */             0, 
/* 1879 */             ConstantPool.JavaLangLongConstantPoolName, 
/* 1880 */             ConstantPool.Init, 
/* 1881 */             ConstantPool.LongConstrSignature, 
/* 1882 */             unboxedTypeID, 
/* 1883 */             (TypeBinding)TypeBinding.LONG);
/*      */         break;
/*      */       
/*      */       case 9:
/* 1887 */         if (this.targetLevel >= 3211264L) {
/*      */           
/* 1889 */           invoke((byte)
/* 1890 */               -72, 
/* 1891 */               1, 
/* 1892 */               1, 
/* 1893 */               ConstantPool.JavaLangFloatConstantPoolName, 
/* 1894 */               ConstantPool.ValueOf, 
/* 1895 */               ConstantPool.floatFloatSignature, 
/* 1896 */               unboxedTypeID, 
/* 1897 */               (TypeBinding)TypeBinding.FLOAT);
/*      */           break;
/*      */         } 
/* 1900 */         newWrapperFor(unboxedTypeID);
/* 1901 */         dup_x1();
/* 1902 */         swap();
/* 1903 */         invoke((byte)
/* 1904 */             -73, 
/* 1905 */             2, 
/* 1906 */             0, 
/* 1907 */             ConstantPool.JavaLangFloatConstantPoolName, 
/* 1908 */             ConstantPool.Init, 
/* 1909 */             ConstantPool.FloatConstrSignature, 
/* 1910 */             unboxedTypeID, 
/* 1911 */             (TypeBinding)TypeBinding.FLOAT);
/*      */         break;
/*      */       
/*      */       case 8:
/* 1915 */         if (this.targetLevel >= 3211264L) {
/*      */           
/* 1917 */           invoke((byte)
/* 1918 */               -72, 
/* 1919 */               2, 
/* 1920 */               1, 
/* 1921 */               ConstantPool.JavaLangDoubleConstantPoolName, 
/* 1922 */               ConstantPool.ValueOf, 
/* 1923 */               ConstantPool.doubleDoubleSignature, 
/* 1924 */               unboxedTypeID, 
/* 1925 */               (TypeBinding)TypeBinding.DOUBLE);
/*      */           break;
/*      */         } 
/* 1928 */         newWrapperFor(unboxedTypeID);
/* 1929 */         dup_x2();
/* 1930 */         dup_x2();
/* 1931 */         pop();
/*      */         
/* 1933 */         invoke((byte)
/* 1934 */             -73, 
/* 1935 */             3, 
/* 1936 */             0, 
/* 1937 */             ConstantPool.JavaLangDoubleConstantPoolName, 
/* 1938 */             ConstantPool.Init, 
/* 1939 */             ConstantPool.DoubleConstrSignature, 
/* 1940 */             unboxedTypeID, 
/* 1941 */             (TypeBinding)TypeBinding.DOUBLE);
/*      */         break;
/*      */ 
/*      */       
/*      */       case 5:
/* 1946 */         if (this.targetLevel >= 3211264L) {
/*      */           
/* 1948 */           invoke((byte)
/* 1949 */               -72, 
/* 1950 */               1, 
/* 1951 */               1, 
/* 1952 */               ConstantPool.JavaLangBooleanConstantPoolName, 
/* 1953 */               ConstantPool.ValueOf, 
/* 1954 */               ConstantPool.booleanBooleanSignature, 
/* 1955 */               unboxedTypeID, 
/* 1956 */               (TypeBinding)TypeBinding.BOOLEAN);
/*      */           break;
/*      */         } 
/* 1959 */         newWrapperFor(unboxedTypeID);
/* 1960 */         dup_x1();
/* 1961 */         swap();
/* 1962 */         invoke((byte)
/* 1963 */             -73, 
/* 1964 */             2, 
/* 1965 */             0, 
/* 1966 */             ConstantPool.JavaLangBooleanConstantPoolName, 
/* 1967 */             ConstantPool.Init, 
/* 1968 */             ConstantPool.BooleanConstrSignature, 
/* 1969 */             unboxedTypeID, 
/* 1970 */             (TypeBinding)TypeBinding.BOOLEAN);
/*      */         break;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void generateClassLiteralAccessForType(Scope scope, TypeBinding accessedType, FieldBinding syntheticFieldBinding) {
/* 1979 */     if (accessedType.isBaseType() && accessedType != TypeBinding.NULL) {
/* 1980 */       getTYPE(accessedType.id);
/*      */       return;
/*      */     } 
/* 1983 */     if (this.targetLevel >= 3211264L) {
/*      */       
/* 1985 */       ldc(accessedType);
/*      */     } else {
/* 1987 */       BranchLabel endLabel = new BranchLabel(this);
/* 1988 */       if (syntheticFieldBinding != null) {
/* 1989 */         fieldAccess((byte)-78, syntheticFieldBinding, null);
/* 1990 */         dup();
/* 1991 */         ifnonnull(endLabel);
/* 1992 */         pop();
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2006 */       ExceptionLabel classNotFoundExceptionHandler = new ExceptionLabel(this, (TypeBinding)TypeBinding.NULL);
/* 2007 */       classNotFoundExceptionHandler.placeStart();
/* 2008 */       ldc((accessedType == TypeBinding.NULL) ? "java.lang.Object" : String.valueOf(accessedType.constantPoolName()).replace('/', '.'));
/* 2009 */       invokeClassForName();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2028 */       classNotFoundExceptionHandler.placeEnd();
/*      */       
/* 2030 */       if (syntheticFieldBinding != null) {
/* 2031 */         dup();
/* 2032 */         fieldAccess((byte)-77, syntheticFieldBinding, null);
/*      */       } 
/* 2034 */       goto_(endLabel);
/*      */       
/* 2036 */       int savedStackDepth = this.stackDepth;
/* 2037 */       int switchSaveTypeBindingsStackSize = this.switchSaveTypeBindings.size();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2044 */       pushExceptionOnStack((TypeBinding)scope.getJavaLangClassNotFoundException());
/* 2045 */       classNotFoundExceptionHandler.place();
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2050 */       newNoClassDefFoundError();
/* 2051 */       dup_x1();
/* 2052 */       swap();
/*      */ 
/*      */       
/* 2055 */       invokeThrowableGetMessage();
/*      */ 
/*      */       
/* 2058 */       invokeNoClassDefFoundErrorStringConstructor();
/* 2059 */       athrow();
/* 2060 */       endLabel.place();
/* 2061 */       this.stackDepth = savedStackDepth;
/* 2062 */       popTypeBinding(this.switchSaveTypeBindings.size() - switchSaveTypeBindingsStackSize);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void generateCodeAttributeForProblemMethod(String problemMessage) {
/* 2070 */     newJavaLangError();
/* 2071 */     dup();
/* 2072 */     ldc(problemMessage);
/* 2073 */     invokeJavaLangErrorConstructor();
/* 2074 */     athrow();
/*      */   }
/*      */   
/*      */   public void generateConstant(Constant constant, int implicitConversionCode) {
/* 2078 */     int targetTypeID = (implicitConversionCode & 0xFF) >> 4;
/* 2079 */     if (targetTypeID == 0) targetTypeID = constant.typeID(); 
/* 2080 */     switch (targetTypeID) {
/*      */       case 5:
/* 2082 */         generateInlinedValue(constant.booleanValue());
/*      */         break;
/*      */       case 2:
/* 2085 */         generateInlinedValue(constant.charValue());
/*      */         break;
/*      */       case 3:
/* 2088 */         generateInlinedValue(constant.byteValue());
/*      */         break;
/*      */       case 4:
/* 2091 */         generateInlinedValue(constant.shortValue());
/*      */         break;
/*      */       case 10:
/* 2094 */         generateInlinedValue(constant.intValue());
/*      */         break;
/*      */       case 7:
/* 2097 */         generateInlinedValue(constant.longValue());
/*      */         break;
/*      */       case 9:
/* 2100 */         generateInlinedValue(constant.floatValue());
/*      */         break;
/*      */       case 8:
/* 2103 */         generateInlinedValue(constant.doubleValue());
/*      */         break;
/*      */       case 11:
/* 2106 */         ldc(constant.stringValue()); break;
/*      */     } 
/* 2108 */     if ((implicitConversionCode & 0x200) != 0)
/*      */     {
/* 2110 */       generateBoxingConversion(targetTypeID);
/*      */     }
/*      */   }
/*      */   
/*      */   public void generateEmulatedReadAccessForField(FieldBinding fieldBinding) {
/* 2115 */     generateEmulationForField(fieldBinding);
/*      */     
/* 2117 */     swap();
/* 2118 */     invokeJavaLangReflectFieldGetter(fieldBinding.type);
/* 2119 */     if (!fieldBinding.type.isBaseType()) {
/* 2120 */       checkcast(fieldBinding.type);
/*      */     }
/*      */   }
/*      */   
/*      */   public void generateEmulatedWriteAccessForField(FieldBinding fieldBinding) {
/* 2125 */     invokeJavaLangReflectFieldSetter(fieldBinding.type);
/*      */   }
/*      */ 
/*      */   
/*      */   public void generateEmulationForConstructor(Scope scope, MethodBinding methodBinding) {
/* 2130 */     ldc(String.valueOf(methodBinding.declaringClass.constantPoolName()).replace('/', '.'));
/* 2131 */     invokeClassForName();
/* 2132 */     int paramLength = methodBinding.parameters.length;
/* 2133 */     generateInlinedValue(paramLength);
/* 2134 */     newArray(scope.createArrayType(scope.getType(TypeConstants.JAVA_LANG_CLASS, 3), 1));
/* 2135 */     if (paramLength > 0) {
/* 2136 */       dup();
/* 2137 */       for (int i = 0; i < paramLength; i++) {
/* 2138 */         generateInlinedValue(i);
/* 2139 */         TypeBinding parameter = methodBinding.parameters[i];
/* 2140 */         if (parameter.isBaseType()) {
/* 2141 */           getTYPE(parameter.id);
/* 2142 */         } else if (parameter.isArrayType()) {
/* 2143 */           ArrayBinding array = (ArrayBinding)parameter;
/* 2144 */           if (array.leafComponentType.isBaseType()) {
/* 2145 */             getTYPE(array.leafComponentType.id);
/*      */           } else {
/* 2147 */             ldc(String.valueOf(array.leafComponentType.constantPoolName()).replace('/', '.'));
/* 2148 */             invokeClassForName();
/*      */           } 
/* 2150 */           int dimensions = array.dimensions;
/* 2151 */           generateInlinedValue(dimensions);
/* 2152 */           newarray(10);
/* 2153 */           invokeArrayNewInstance();
/* 2154 */           invokeObjectGetClass();
/*      */         } else {
/*      */           
/* 2157 */           ldc(String.valueOf(methodBinding.declaringClass.constantPoolName()).replace('/', '.'));
/* 2158 */           invokeClassForName();
/*      */         } 
/* 2160 */         aastore();
/* 2161 */         if (i < paramLength - 1) {
/* 2162 */           dup();
/*      */         }
/*      */       } 
/*      */     } 
/* 2166 */     invokeClassGetDeclaredConstructor();
/* 2167 */     dup();
/* 2168 */     iconst_1();
/* 2169 */     invokeAccessibleObjectSetAccessible();
/*      */   }
/*      */ 
/*      */   
/*      */   public void generateEmulationForField(FieldBinding fieldBinding) {
/* 2174 */     ldc(String.valueOf(fieldBinding.declaringClass.constantPoolName()).replace('/', '.'));
/* 2175 */     invokeClassForName();
/* 2176 */     ldc(String.valueOf(fieldBinding.name));
/* 2177 */     invokeClassGetDeclaredField();
/* 2178 */     dup();
/* 2179 */     iconst_1();
/* 2180 */     invokeAccessibleObjectSetAccessible();
/*      */   }
/*      */ 
/*      */   
/*      */   public void generateEmulationForMethod(Scope scope, MethodBinding methodBinding) {
/* 2185 */     ldc(String.valueOf(methodBinding.declaringClass.constantPoolName()).replace('/', '.'));
/* 2186 */     invokeClassForName();
/* 2187 */     ldc(String.valueOf(methodBinding.selector));
/* 2188 */     int paramLength = methodBinding.parameters.length;
/* 2189 */     generateInlinedValue(paramLength);
/* 2190 */     newArray(scope.createArrayType(scope.getType(TypeConstants.JAVA_LANG_CLASS, 3), 1));
/* 2191 */     if (paramLength > 0) {
/* 2192 */       dup();
/* 2193 */       for (int i = 0; i < paramLength; i++) {
/* 2194 */         generateInlinedValue(i);
/* 2195 */         TypeBinding parameter = methodBinding.parameters[i];
/* 2196 */         if (parameter.isBaseType()) {
/* 2197 */           getTYPE(parameter.id);
/* 2198 */         } else if (parameter.isArrayType()) {
/* 2199 */           ArrayBinding array = (ArrayBinding)parameter;
/* 2200 */           if (array.leafComponentType.isBaseType()) {
/* 2201 */             getTYPE(array.leafComponentType.id);
/*      */           } else {
/* 2203 */             ldc(String.valueOf(array.leafComponentType.constantPoolName()).replace('/', '.'));
/* 2204 */             invokeClassForName();
/*      */           } 
/* 2206 */           int dimensions = array.dimensions;
/* 2207 */           generateInlinedValue(dimensions);
/* 2208 */           newarray(10);
/* 2209 */           invokeArrayNewInstance();
/* 2210 */           invokeObjectGetClass();
/*      */         } else {
/*      */           
/* 2213 */           ldc(String.valueOf(methodBinding.declaringClass.constantPoolName()).replace('/', '.'));
/* 2214 */           invokeClassForName();
/*      */         } 
/* 2216 */         aastore();
/* 2217 */         if (i < paramLength - 1) {
/* 2218 */           dup();
/*      */         }
/*      */       } 
/*      */     } 
/* 2222 */     invokeClassGetDeclaredMethod();
/* 2223 */     dup();
/* 2224 */     iconst_1();
/* 2225 */     invokeAccessibleObjectSetAccessible();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void generateImplicitConversion(int implicitConversionCode) {
/*      */     int runtimeType;
/* 2233 */     if ((implicitConversionCode & 0x400) != 0) {
/* 2234 */       int typeId = implicitConversionCode & 0xF;
/* 2235 */       generateUnboxingConversion(typeId);
/*      */     } 
/*      */     
/* 2238 */     switch (implicitConversionCode & 0xFF) {
/*      */       case 41:
/* 2240 */         f2i();
/* 2241 */         i2c();
/*      */         break;
/*      */       case 40:
/* 2244 */         d2i();
/* 2245 */         i2c();
/*      */         break;
/*      */       case 35:
/*      */       case 36:
/*      */       case 42:
/* 2250 */         i2c();
/*      */         break;
/*      */       case 39:
/* 2253 */         l2i();
/* 2254 */         i2c();
/*      */         break;
/*      */       case 146:
/*      */       case 147:
/*      */       case 148:
/*      */       case 154:
/* 2260 */         i2f();
/*      */         break;
/*      */       case 152:
/* 2263 */         d2f();
/*      */         break;
/*      */       case 151:
/* 2266 */         l2f();
/*      */         break;
/*      */       case 57:
/* 2269 */         f2i();
/* 2270 */         i2b();
/*      */         break;
/*      */       case 56:
/* 2273 */         d2i();
/* 2274 */         i2b();
/*      */         break;
/*      */       case 50:
/*      */       case 52:
/*      */       case 58:
/* 2279 */         i2b();
/*      */         break;
/*      */       case 55:
/* 2282 */         l2i();
/* 2283 */         i2b();
/*      */         break;
/*      */       case 130:
/*      */       case 131:
/*      */       case 132:
/*      */       case 138:
/* 2289 */         i2d();
/*      */         break;
/*      */       case 137:
/* 2292 */         f2d();
/*      */         break;
/*      */       case 135:
/* 2295 */         l2d();
/*      */         break;
/*      */       case 66:
/*      */       case 67:
/*      */       case 74:
/* 2300 */         i2s();
/*      */         break;
/*      */       case 72:
/* 2303 */         d2i();
/* 2304 */         i2s();
/*      */         break;
/*      */       case 71:
/* 2307 */         l2i();
/* 2308 */         i2s();
/*      */         break;
/*      */       case 73:
/* 2311 */         f2i();
/* 2312 */         i2s();
/*      */         break;
/*      */       case 168:
/* 2315 */         d2i();
/*      */         break;
/*      */       case 169:
/* 2318 */         f2i();
/*      */         break;
/*      */       case 167:
/* 2321 */         l2i();
/*      */         break;
/*      */       case 114:
/*      */       case 115:
/*      */       case 116:
/*      */       case 122:
/* 2327 */         i2l();
/*      */         break;
/*      */       case 120:
/* 2330 */         d2l();
/*      */         break;
/*      */       case 121:
/* 2333 */         f2l();
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 33:
/*      */       case 49:
/*      */       case 65:
/*      */       case 81:
/*      */       case 113:
/*      */       case 129:
/*      */       case 145:
/*      */       case 161:
/* 2346 */         runtimeType = (implicitConversionCode & 0xFF) >> 4;
/* 2347 */         checkcast(runtimeType);
/* 2348 */         generateUnboxingConversion(runtimeType);
/*      */         break;
/*      */     } 
/* 2351 */     if ((implicitConversionCode & 0x200) != 0) {
/*      */       
/* 2353 */       int typeId = (implicitConversionCode & 0xFF) >> 4;
/* 2354 */       generateBoxingConversion(typeId);
/*      */     } 
/*      */   }
/*      */   
/*      */   public void generateInlinedValue(boolean inlinedValue) {
/* 2359 */     if (inlinedValue) {
/* 2360 */       iconst_1();
/*      */     } else {
/* 2362 */       iconst_0();
/*      */     } 
/*      */   }
/*      */   public void generateInlinedValue(byte inlinedValue) {
/* 2366 */     switch (inlinedValue) {
/*      */       case -1:
/* 2368 */         iconst_m1();
/*      */         return;
/*      */       case 0:
/* 2371 */         iconst_0();
/*      */         return;
/*      */       case 1:
/* 2374 */         iconst_1();
/*      */         return;
/*      */       case 2:
/* 2377 */         iconst_2();
/*      */         return;
/*      */       case 3:
/* 2380 */         iconst_3();
/*      */         return;
/*      */       case 4:
/* 2383 */         iconst_4();
/*      */         return;
/*      */       case 5:
/* 2386 */         iconst_5();
/*      */         return;
/*      */     } 
/* 2389 */     if (Byte.MIN_VALUE <= inlinedValue && inlinedValue <= Byte.MAX_VALUE) {
/* 2390 */       bipush(inlinedValue);
/*      */       return;
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public void generateInlinedValue(char inlinedValue) {
/* 2397 */     switch (inlinedValue) {
/*      */       case '\000':
/* 2399 */         iconst_0();
/*      */         return;
/*      */       case '\001':
/* 2402 */         iconst_1();
/*      */         return;
/*      */       case '\002':
/* 2405 */         iconst_2();
/*      */         return;
/*      */       case '\003':
/* 2408 */         iconst_3();
/*      */         return;
/*      */       case '\004':
/* 2411 */         iconst_4();
/*      */         return;
/*      */       case '\005':
/* 2414 */         iconst_5();
/*      */         return;
/*      */     } 
/* 2417 */     if ('\006' <= inlinedValue && inlinedValue <= '') {
/* 2418 */       bipush((byte)inlinedValue);
/*      */       return;
/*      */     } 
/* 2421 */     if ('' <= inlinedValue && inlinedValue <= '翿') {
/* 2422 */       sipush(inlinedValue);
/*      */       return;
/*      */     } 
/* 2425 */     ldc(inlinedValue);
/*      */   }
/*      */ 
/*      */   
/*      */   public void generateInlinedValue(double inlinedValue) {
/* 2430 */     if (inlinedValue == 0.0D) {
/* 2431 */       if (Double.doubleToLongBits(inlinedValue) != 0L) {
/* 2432 */         ldc2_w(inlinedValue);
/*      */       } else {
/* 2434 */         dconst_0();
/*      */       }  return;
/*      */     } 
/* 2437 */     if (inlinedValue == 1.0D) {
/* 2438 */       dconst_1();
/*      */       return;
/*      */     } 
/* 2441 */     ldc2_w(inlinedValue);
/*      */   }
/*      */   
/*      */   public void generateInlinedValue(float inlinedValue) {
/* 2445 */     if (inlinedValue == 0.0F) {
/* 2446 */       if (Float.floatToIntBits(inlinedValue) != 0) {
/* 2447 */         ldc(inlinedValue);
/*      */       } else {
/* 2449 */         fconst_0();
/*      */       }  return;
/*      */     } 
/* 2452 */     if (inlinedValue == 1.0F) {
/* 2453 */       fconst_1();
/*      */       return;
/*      */     } 
/* 2456 */     if (inlinedValue == 2.0F) {
/* 2457 */       fconst_2();
/*      */       return;
/*      */     } 
/* 2460 */     ldc(inlinedValue);
/*      */   }
/*      */   
/*      */   public void generateInlinedValue(int inlinedValue) {
/* 2464 */     switch (inlinedValue) {
/*      */       case -1:
/* 2466 */         iconst_m1();
/*      */         return;
/*      */       case 0:
/* 2469 */         iconst_0();
/*      */         return;
/*      */       case 1:
/* 2472 */         iconst_1();
/*      */         return;
/*      */       case 2:
/* 2475 */         iconst_2();
/*      */         return;
/*      */       case 3:
/* 2478 */         iconst_3();
/*      */         return;
/*      */       case 4:
/* 2481 */         iconst_4();
/*      */         return;
/*      */       case 5:
/* 2484 */         iconst_5();
/*      */         return;
/*      */     } 
/* 2487 */     if (-128 <= inlinedValue && inlinedValue <= 127) {
/* 2488 */       bipush((byte)inlinedValue);
/*      */       return;
/*      */     } 
/* 2491 */     if (-32768 <= inlinedValue && inlinedValue <= 32767) {
/* 2492 */       sipush(inlinedValue);
/*      */       return;
/*      */     } 
/* 2495 */     ldc(inlinedValue);
/*      */   }
/*      */ 
/*      */   
/*      */   public void generateInlinedValue(long inlinedValue) {
/* 2500 */     if (inlinedValue == 0L) {
/* 2501 */       lconst_0();
/*      */       return;
/*      */     } 
/* 2504 */     if (inlinedValue == 1L) {
/* 2505 */       lconst_1();
/*      */       return;
/*      */     } 
/* 2508 */     ldc2_w(inlinedValue);
/*      */   }
/*      */   
/*      */   public void generateInlinedValue(short inlinedValue) {
/* 2512 */     switch (inlinedValue) {
/*      */       case -1:
/* 2514 */         iconst_m1();
/*      */         return;
/*      */       case 0:
/* 2517 */         iconst_0();
/*      */         return;
/*      */       case 1:
/* 2520 */         iconst_1();
/*      */         return;
/*      */       case 2:
/* 2523 */         iconst_2();
/*      */         return;
/*      */       case 3:
/* 2526 */         iconst_3();
/*      */         return;
/*      */       case 4:
/* 2529 */         iconst_4();
/*      */         return;
/*      */       case 5:
/* 2532 */         iconst_5();
/*      */         return;
/*      */     } 
/* 2535 */     if (-128 <= inlinedValue && inlinedValue <= 127) {
/* 2536 */       bipush((byte)inlinedValue);
/*      */       return;
/*      */     } 
/* 2539 */     sipush(inlinedValue);
/*      */   }
/*      */ 
/*      */   
/*      */   public void generateOuterAccess(Object[] mappingSequence, ASTNode invocationSite, Binding target, Scope scope) {
/* 2544 */     if (mappingSequence == null) {
/* 2545 */       if (target instanceof LocalVariableBinding) {
/* 2546 */         scope.problemReporter().needImplementation(invocationSite);
/*      */       } else {
/* 2548 */         scope.problemReporter().noSuchEnclosingInstance((TypeBinding)target, invocationSite, false);
/*      */       } 
/*      */       return;
/*      */     } 
/* 2552 */     if (mappingSequence == BlockScope.NoEnclosingInstanceInConstructorCall) {
/* 2553 */       scope.problemReporter().noSuchEnclosingInstance((TypeBinding)target, invocationSite, true); return;
/*      */     } 
/* 2555 */     if (mappingSequence == BlockScope.NoEnclosingInstanceInStaticContext) {
/* 2556 */       scope.problemReporter().noSuchEnclosingInstance((TypeBinding)target, invocationSite, false);
/*      */       
/*      */       return;
/*      */     } 
/* 2560 */     if (mappingSequence == BlockScope.EmulationPathToImplicitThis) {
/* 2561 */       aload_0(); return;
/*      */     } 
/* 2563 */     if (mappingSequence[0] instanceof FieldBinding) {
/* 2564 */       FieldBinding fieldBinding = (FieldBinding)mappingSequence[0];
/* 2565 */       aload_0();
/* 2566 */       fieldAccess((byte)-76, fieldBinding, null);
/*      */     } else {
/* 2568 */       load((LocalVariableBinding)mappingSequence[0]);
/*      */     } 
/* 2570 */     for (int i = 1, length = mappingSequence.length; i < length; i++) {
/* 2571 */       if (mappingSequence[i] instanceof FieldBinding) {
/* 2572 */         FieldBinding fieldBinding = (FieldBinding)mappingSequence[i];
/* 2573 */         fieldAccess((byte)-76, fieldBinding, null);
/*      */       } else {
/* 2575 */         invoke((byte)-72, (MethodBinding)mappingSequence[i], null);
/*      */       } 
/*      */     } 
/*      */   }
/*      */   
/*      */   public void generateReturnBytecode(Expression expression) {
/* 2581 */     if (expression == null) {
/* 2582 */       return_();
/*      */     } else {
/* 2584 */       int implicitConversion = expression.implicitConversion;
/* 2585 */       if ((implicitConversion & 0x200) != 0) {
/* 2586 */         areturn();
/*      */         return;
/*      */       } 
/* 2589 */       int runtimeType = (implicitConversion & 0xFF) >> 4;
/* 2590 */       switch (runtimeType) {
/*      */         case 5:
/*      */         case 10:
/* 2593 */           ireturn();
/*      */           return;
/*      */         case 9:
/* 2596 */           freturn();
/*      */           return;
/*      */         case 7:
/* 2599 */           lreturn();
/*      */           return;
/*      */         case 8:
/* 2602 */           dreturn();
/*      */           return;
/*      */       } 
/* 2605 */       areturn();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void generateStringConcatenationAppend(BlockScope blockScope, Expression oper1, Expression oper2) {
/* 2619 */     if (oper1 == null) {
/*      */ 
/*      */       
/* 2622 */       newStringContatenation();
/* 2623 */       dup_x1();
/* 2624 */       swap();
/*      */ 
/*      */       
/* 2627 */       invokeStringValueOf(1);
/* 2628 */       invokeStringConcatenationStringConstructor();
/*      */     } else {
/* 2630 */       int i = this.position;
/* 2631 */       oper1.generateOptimizedStringConcatenationCreation(blockScope, this, oper1.implicitConversion & 0xF);
/* 2632 */       recordPositionsFrom(i, oper1.sourceStart);
/*      */     } 
/* 2634 */     int pc = this.position;
/* 2635 */     oper2.generateOptimizedStringConcatenation(blockScope, this, oper2.implicitConversion & 0xF);
/* 2636 */     recordPositionsFrom(pc, oper2.sourceStart);
/* 2637 */     invokeStringConcatenationToString();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void generateSyntheticBodyForConstructorAccess(SyntheticMethodBinding accessBinding) {
/* 2644 */     initializeMaxLocals((MethodBinding)accessBinding);
/* 2645 */     MethodBinding constructorBinding = accessBinding.targetMethod;
/* 2646 */     TypeBinding[] parameters = constructorBinding.parameters;
/* 2647 */     int length = parameters.length;
/* 2648 */     int resolvedPosition = 1;
/* 2649 */     aload_0();
/*      */     
/* 2651 */     ReferenceBinding referenceBinding = constructorBinding.declaringClass;
/* 2652 */     if ((referenceBinding.erasure()).id == 41 || referenceBinding.isEnum()) {
/* 2653 */       aload_1();
/* 2654 */       iload_2();
/* 2655 */       resolvedPosition += 2;
/*      */     } 
/* 2657 */     if (referenceBinding.isNestedType()) {
/* 2658 */       NestedTypeBinding nestedType = (NestedTypeBinding)referenceBinding;
/* 2659 */       SyntheticArgumentBinding[] syntheticArguments = nestedType.syntheticEnclosingInstances();
/* 2660 */       for (int j = 0; j < ((syntheticArguments == null) ? 0 : syntheticArguments.length); j++) {
/*      */         TypeBinding type;
/* 2662 */         load(type = (syntheticArguments[j]).type, resolvedPosition);
/* 2663 */         switch (type.id) {
/*      */           case 7:
/*      */           case 8:
/* 2666 */             resolvedPosition += 2;
/*      */             break;
/*      */           default:
/* 2669 */             resolvedPosition++;
/*      */             break;
/*      */         } 
/*      */       } 
/*      */     } 
/* 2674 */     for (int i = 0; i < length; i++) {
/*      */       TypeBinding parameter;
/* 2676 */       load(parameter = parameters[i], resolvedPosition);
/* 2677 */       switch (parameter.id) {
/*      */         case 7:
/*      */         case 8:
/* 2680 */           resolvedPosition += 2;
/*      */           break;
/*      */         default:
/* 2683 */           resolvedPosition++;
/*      */           break;
/*      */       } 
/*      */     
/*      */     } 
/* 2688 */     if (referenceBinding.isNestedType()) {
/* 2689 */       NestedTypeBinding nestedType = (NestedTypeBinding)referenceBinding;
/* 2690 */       SyntheticArgumentBinding[] syntheticArguments = nestedType.syntheticOuterLocalVariables();
/* 2691 */       for (int j = 0; j < ((syntheticArguments == null) ? 0 : syntheticArguments.length); j++) {
/*      */         TypeBinding type;
/* 2693 */         load(type = (syntheticArguments[j]).type, resolvedPosition);
/* 2694 */         switch (type.id) {
/*      */           case 7:
/*      */           case 8:
/* 2697 */             resolvedPosition += 2;
/*      */             break;
/*      */           default:
/* 2700 */             resolvedPosition++;
/*      */             break;
/*      */         } 
/*      */       } 
/*      */     } 
/* 2705 */     invoke((byte)-73, constructorBinding, null);
/* 2706 */     return_();
/*      */   }
/*      */   public void generateSyntheticBodyForArrayConstructor(SyntheticMethodBinding methodBinding) {
/* 2709 */     initializeMaxLocals((MethodBinding)methodBinding);
/* 2710 */     iload_0();
/* 2711 */     newArray(null, null, (ArrayBinding)methodBinding.returnType);
/* 2712 */     areturn();
/*      */   }
/*      */   public void generateSyntheticBodyForArrayClone(SyntheticMethodBinding methodBinding) {
/* 2715 */     initializeMaxLocals((MethodBinding)methodBinding);
/* 2716 */     TypeBinding arrayType = methodBinding.parameters[0];
/* 2717 */     aload_0();
/* 2718 */     invoke((byte)
/* 2719 */         -74, 
/* 2720 */         1, 
/* 2721 */         1, 
/* 2722 */         arrayType.signature(), 
/* 2723 */         ConstantPool.Clone, 
/* 2724 */         ConstantPool.CloneSignature, 
/* 2725 */         getPopularBinding(ConstantPool.JavaLangObjectConstantPoolName));
/* 2726 */     checkcast(arrayType);
/* 2727 */     areturn();
/*      */   }
/*      */   public void generateSyntheticBodyForFactoryMethod(SyntheticMethodBinding methodBinding) {
/* 2730 */     initializeMaxLocals((MethodBinding)methodBinding);
/* 2731 */     MethodBinding constructorBinding = methodBinding.targetMethod;
/* 2732 */     TypeBinding[] parameters = methodBinding.parameters;
/* 2733 */     int length = parameters.length;
/*      */     
/* 2735 */     new_((TypeBinding)constructorBinding.declaringClass);
/* 2736 */     dup();
/*      */     
/* 2738 */     int resolvedPosition = 0; int i;
/* 2739 */     for (i = 0; i < length; i++) {
/*      */       TypeBinding parameter;
/* 2741 */       load(parameter = parameters[i], resolvedPosition);
/* 2742 */       switch (parameter.id) {
/*      */         case 7:
/*      */         case 8:
/* 2745 */           resolvedPosition += 2;
/*      */           break;
/*      */         default:
/* 2748 */           resolvedPosition++;
/*      */           break;
/*      */       } 
/*      */     } 
/* 2752 */     for (i = 0; i < methodBinding.fakePaddedParameters; i++) {
/* 2753 */       aconst_null();
/*      */     }
/* 2755 */     invoke((byte)-73, constructorBinding, null);
/* 2756 */     areturn();
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void generateSyntheticBodyForEnumValueOf(SyntheticMethodBinding methodBinding) {
/* 2762 */     initializeMaxLocals((MethodBinding)methodBinding);
/* 2763 */     ReferenceBinding declaringClass = methodBinding.declaringClass;
/* 2764 */     generateClassLiteralAccessForType((Scope)((SourceTypeBinding)methodBinding.declaringClass).scope, (TypeBinding)declaringClass, null);
/* 2765 */     aload_0();
/* 2766 */     invokeJavaLangEnumvalueOf(declaringClass);
/* 2767 */     checkcast((TypeBinding)declaringClass);
/* 2768 */     areturn();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void generateSyntheticBodyForDeserializeLambda(SyntheticMethodBinding methodBinding, SyntheticMethodBinding[] syntheticMethodBindings) {
/* 2780 */     initializeMaxLocals((MethodBinding)methodBinding);
/*      */ 
/*      */     
/* 2783 */     Map<Object, Object> hashcodesTosynthetics = new LinkedHashMap<>();
/* 2784 */     for (int i = 0, max = syntheticMethodBindings.length; i < max; i++) {
/* 2785 */       SyntheticMethodBinding syntheticMethodBinding = syntheticMethodBindings[i];
/* 2786 */       if ((syntheticMethodBinding.lambda != null && syntheticMethodBinding.lambda.isSerializable) || 
/* 2787 */         syntheticMethodBinding.serializableMethodRef != null) {
/*      */         
/* 2789 */         Integer hashcode = Integer.valueOf((new String(syntheticMethodBinding.selector)).hashCode());
/* 2790 */         List<SyntheticMethodBinding> syntheticssForThisHashcode = (List)hashcodesTosynthetics.get(hashcode);
/* 2791 */         if (syntheticssForThisHashcode == null) {
/* 2792 */           syntheticssForThisHashcode = new ArrayList();
/* 2793 */           hashcodesTosynthetics.put(hashcode, syntheticssForThisHashcode);
/*      */         } 
/* 2795 */         syntheticssForThisHashcode.add(syntheticMethodBinding);
/*      */       } 
/*      */     } 
/* 2798 */     ClassScope scope = ((SourceTypeBinding)methodBinding.declaringClass).scope;
/*      */ 
/*      */     
/* 2801 */     aload_0();
/* 2802 */     invoke((byte)-74, 1, 1, ConstantPool.JavaLangInvokeSerializedLambdaConstantPoolName, ConstantPool.GetImplMethodName, ConstantPool.GetImplMethodNameSignature, 
/* 2803 */         getPopularBinding(ConstantPool.JavaLangStringConstantPoolName));
/* 2804 */     astore_1();
/* 2805 */     LocalVariableBinding lvb1 = new LocalVariableBinding("hashcode".toCharArray(), (TypeBinding)scope.getJavaLangString(), 0, false);
/* 2806 */     lvb1.resolvedPosition = 1;
/* 2807 */     addVariable(lvb1);
/* 2808 */     iconst_m1();
/* 2809 */     istore_2();
/* 2810 */     LocalVariableBinding lvb2 = new LocalVariableBinding("id".toCharArray(), (TypeBinding)TypeBinding.INT, 0, false);
/* 2811 */     lvb2.resolvedPosition = 2;
/* 2812 */     addVariable(lvb2);
/* 2813 */     aload_1();
/* 2814 */     invokeStringHashCode();
/*      */     
/* 2816 */     BranchLabel label = new BranchLabel(this);
/* 2817 */     CaseLabel defaultLabel = new CaseLabel(this);
/* 2818 */     int numberOfHashcodes = hashcodesTosynthetics.size();
/* 2819 */     CaseLabel[] switchLabels = new CaseLabel[numberOfHashcodes];
/* 2820 */     int[] keys = new int[numberOfHashcodes];
/* 2821 */     int[] sortedIndexes = new int[numberOfHashcodes];
/* 2822 */     Set<Integer> hashcodes = hashcodesTosynthetics.keySet();
/* 2823 */     Iterator<Integer> hashcodeIterator = hashcodes.iterator();
/* 2824 */     int index = 0;
/* 2825 */     while (hashcodeIterator.hasNext()) {
/* 2826 */       Integer hashcode = hashcodeIterator.next();
/* 2827 */       switchLabels[index] = new CaseLabel(this);
/* 2828 */       keys[index] = hashcode.intValue();
/* 2829 */       sortedIndexes[index] = index;
/* 2830 */       index++;
/*      */     } 
/*      */     int[] localKeysCopy;
/* 2833 */     System.arraycopy(keys, 0, localKeysCopy = new int[numberOfHashcodes], 0, numberOfHashcodes);
/* 2834 */     sort(localKeysCopy, 0, numberOfHashcodes - 1, sortedIndexes);
/*      */     
/* 2836 */     lookupswitch(defaultLabel, keys, sortedIndexes, switchLabels);
/*      */     
/* 2838 */     hashcodeIterator = hashcodes.iterator();
/* 2839 */     index = 0;
/* 2840 */     while (hashcodeIterator.hasNext()) {
/* 2841 */       Integer hashcode = hashcodeIterator.next();
/* 2842 */       List<SyntheticMethodBinding> synthetics = (List)hashcodesTosynthetics.get(hashcode);
/* 2843 */       switchLabels[index].place();
/* 2844 */       BranchLabel nextOne = new BranchLabel(this);
/*      */ 
/*      */ 
/*      */       
/* 2848 */       for (int k = 0, m = synthetics.size(); k < m; k++) {
/* 2849 */         SyntheticMethodBinding syntheticMethodBinding = synthetics.get(k);
/* 2850 */         aload_1();
/* 2851 */         ldc(new String(syntheticMethodBinding.selector));
/* 2852 */         invokeStringEquals();
/* 2853 */         ifeq(nextOne);
/* 2854 */         loadInt(index);
/* 2855 */         istore_2();
/* 2856 */         goto_(label);
/* 2857 */         nextOne.place();
/* 2858 */         nextOne = new BranchLabel(this);
/*      */       } 
/* 2860 */       index++;
/* 2861 */       goto_(label);
/*      */     } 
/* 2863 */     defaultLabel.place();
/* 2864 */     label.place();
/* 2865 */     int syntheticsCount = hashcodes.size();
/*      */     
/* 2867 */     switchLabels = new CaseLabel[syntheticsCount];
/* 2868 */     keys = new int[syntheticsCount];
/* 2869 */     sortedIndexes = new int[syntheticsCount];
/* 2870 */     BranchLabel errorLabel = new BranchLabel(this);
/* 2871 */     defaultLabel = new CaseLabel(this);
/* 2872 */     iload_2();
/* 2873 */     for (int j = 0; j < syntheticsCount; j++) {
/* 2874 */       switchLabels[j] = new CaseLabel(this);
/* 2875 */       keys[j] = j;
/* 2876 */       sortedIndexes[j] = j;
/*      */     } 
/* 2878 */     System.arraycopy(keys, 0, localKeysCopy = new int[syntheticsCount], 0, syntheticsCount);
/*      */     
/* 2880 */     sort(localKeysCopy, 0, syntheticsCount - 1, sortedIndexes);
/*      */     
/* 2882 */     lookupswitch(defaultLabel, keys, sortedIndexes, switchLabels);
/* 2883 */     hashcodeIterator = hashcodes.iterator();
/* 2884 */     int hashcodeIndex = 0;
/* 2885 */     while (hashcodeIterator.hasNext()) {
/* 2886 */       Integer hashcode = hashcodeIterator.next();
/* 2887 */       List<SyntheticMethodBinding> synthetics = (List)hashcodesTosynthetics.get(hashcode);
/* 2888 */       switchLabels[hashcodeIndex++].place();
/* 2889 */       BranchLabel nextOne = (synthetics.size() > 1) ? new BranchLabel(this) : errorLabel;
/*      */       
/* 2891 */       for (int k = 0, count = synthetics.size(); k < count; k++) {
/* 2892 */         SyntheticMethodBinding syntheticMethodBinding = synthetics.get(k);
/*      */         
/* 2894 */         aload_0();
/* 2895 */         FunctionalExpression funcEx = (syntheticMethodBinding.lambda != null) ? (FunctionalExpression)syntheticMethodBinding.lambda : 
/* 2896 */           (FunctionalExpression)syntheticMethodBinding.serializableMethodRef;
/* 2897 */         MethodBinding mb = funcEx.binding;
/* 2898 */         invoke((byte)-74, 1, 1, ConstantPool.JavaLangInvokeSerializedLambdaConstantPoolName, 
/* 2899 */             ConstantPool.GetImplMethodKind, ConstantPool.GetImplMethodKindSignature, 10, 
/* 2900 */             (TypeBinding)TypeBinding.INT);
/* 2901 */         byte methodKind = 0;
/* 2902 */         if (mb.isStatic()) {
/* 2903 */           methodKind = 6;
/* 2904 */         } else if (mb.isPrivate()) {
/* 2905 */           methodKind = 7;
/* 2906 */         } else if (mb.isConstructor()) {
/* 2907 */           methodKind = 8;
/* 2908 */         } else if (mb.declaringClass.isInterface()) {
/* 2909 */           methodKind = 9;
/*      */         } else {
/* 2911 */           methodKind = 5;
/*      */         } 
/* 2913 */         bipush(methodKind);
/* 2914 */         if_icmpne(nextOne);
/*      */ 
/*      */         
/* 2917 */         aload_0();
/* 2918 */         invoke((byte)-74, 1, 1, ConstantPool.JavaLangInvokeSerializedLambdaConstantPoolName, 
/* 2919 */             ConstantPool.GetFunctionalInterfaceClass, ConstantPool.GetFunctionalInterfaceClassSignature, 
/* 2920 */             getPopularBinding(ConstantPool.JavaLangStringConstantPoolName));
/* 2921 */         String functionalInterface = null;
/* 2922 */         TypeBinding expectedType = funcEx.expectedType();
/* 2923 */         if (expectedType instanceof IntersectionTypeBinding18) {
/* 2924 */           functionalInterface = new String((
/* 2925 */               (IntersectionTypeBinding18)expectedType).getSAMType((Scope)scope).constantPoolName());
/*      */         } else {
/* 2927 */           functionalInterface = new String(expectedType.constantPoolName());
/*      */         } 
/* 2929 */         ldc(functionalInterface);
/* 2930 */         invokeObjectEquals();
/* 2931 */         ifeq(nextOne);
/*      */ 
/*      */         
/* 2934 */         aload_0();
/* 2935 */         invoke((byte)-74, 1, 1, ConstantPool.JavaLangInvokeSerializedLambdaConstantPoolName, 
/* 2936 */             ConstantPool.GetFunctionalInterfaceMethodName, 
/* 2937 */             ConstantPool.GetFunctionalInterfaceMethodNameSignature, 
/* 2938 */             getPopularBinding(ConstantPool.JavaLangStringConstantPoolName));
/* 2939 */         ldc(new String(funcEx.descriptor.selector));
/* 2940 */         invokeObjectEquals();
/* 2941 */         ifeq(nextOne);
/*      */ 
/*      */         
/* 2944 */         aload_0();
/* 2945 */         invoke((byte)-74, 1, 1, ConstantPool.JavaLangInvokeSerializedLambdaConstantPoolName, 
/* 2946 */             ConstantPool.GetFunctionalInterfaceMethodSignature, 
/* 2947 */             ConstantPool.GetFunctionalInterfaceMethodSignatureSignature, 
/* 2948 */             getPopularBinding(ConstantPool.JavaLangStringConstantPoolName));
/* 2949 */         ldc(new String(funcEx.descriptor.original().signature()));
/* 2950 */         invokeObjectEquals();
/* 2951 */         ifeq(nextOne);
/*      */ 
/*      */         
/* 2954 */         aload_0();
/* 2955 */         invoke((byte)-74, 1, 1, ConstantPool.JavaLangInvokeSerializedLambdaConstantPoolName, 
/* 2956 */             ConstantPool.GetImplClass, ConstantPool.GetImplClassSignature, 
/* 2957 */             getPopularBinding(ConstantPool.JavaLangStringConstantPoolName));
/* 2958 */         ldc(new String(mb.declaringClass.constantPoolName()));
/* 2959 */         invokeObjectEquals();
/* 2960 */         ifeq(nextOne);
/*      */ 
/*      */         
/* 2963 */         aload_0();
/* 2964 */         invoke((byte)-74, 1, 1, ConstantPool.JavaLangInvokeSerializedLambdaConstantPoolName, 
/* 2965 */             ConstantPool.GetImplMethodSignature, ConstantPool.GetImplMethodSignatureSignature, 
/* 2966 */             getPopularBinding(ConstantPool.JavaLangStringConstantPoolName));
/* 2967 */         ldc(new String(mb.original().signature()));
/* 2968 */         invokeObjectEquals();
/* 2969 */         ifeq(nextOne);
/*      */ 
/*      */         
/* 2972 */         StringBuilder sig = new StringBuilder("(");
/* 2973 */         index = 0;
/* 2974 */         boolean isLambda = funcEx instanceof LambdaExpression;
/* 2975 */         TypeBinding receiverType = null;
/* 2976 */         SyntheticArgumentBinding[] outerLocalVariables = null;
/* 2977 */         if (isLambda) {
/* 2978 */           LambdaExpression lambdaEx = (LambdaExpression)funcEx;
/* 2979 */           if (lambdaEx.shouldCaptureInstance)
/* 2980 */             ReferenceBinding referenceBinding = mb.declaringClass; 
/* 2981 */           outerLocalVariables = lambdaEx.outerLocalVariables;
/*      */         } else {
/* 2983 */           ReferenceExpression refEx = (ReferenceExpression)funcEx;
/* 2984 */           if (refEx.haveReceiver) {
/* 2985 */             receiverType = ((ReferenceExpression)funcEx).receiverType;
/*      */           }
/*      */         } 
/* 2988 */         if (receiverType != null) {
/* 2989 */           aload_0();
/* 2990 */           loadInt(index++);
/* 2991 */           invoke((byte)-74, 1, 1, 
/* 2992 */               ConstantPool.JavaLangInvokeSerializedLambdaConstantPoolName, 
/* 2993 */               ConstantPool.GetCapturedArg, ConstantPool.GetCapturedArgSignature, 
/* 2994 */               getPopularBinding(ConstantPool.JavaLangStringConstantPoolName));
/* 2995 */           checkcast(receiverType);
/* 2996 */           sig.append(receiverType.signature());
/*      */         } 
/* 2998 */         for (int p = 0, m = (outerLocalVariables == null) ? 0 : outerLocalVariables.length; p < m; p++) {
/* 2999 */           TypeBinding varType = (outerLocalVariables[p]).type;
/* 3000 */           aload_0();
/* 3001 */           loadInt(index);
/* 3002 */           invoke((byte)-74, 1, 1, 
/* 3003 */               ConstantPool.JavaLangInvokeSerializedLambdaConstantPoolName, 
/* 3004 */               ConstantPool.GetCapturedArg, ConstantPool.GetCapturedArgSignature, 
/* 3005 */               getPopularBinding(ConstantPool.JavaLangStringConstantPoolName));
/* 3006 */           if (varType.isBaseType()) {
/* 3007 */             checkcast(scope.boxing(varType));
/* 3008 */             generateUnboxingConversion(varType.id);
/* 3009 */             if (varType.id == 30 || varType.id == 32) {
/* 3010 */               index++;
/*      */             }
/*      */           } else {
/* 3013 */             checkcast(varType);
/*      */           } 
/* 3015 */           index++;
/* 3016 */           sig.append(varType.signature());
/*      */         } 
/* 3018 */         sig.append(")");
/* 3019 */         if (funcEx.resolvedType instanceof IntersectionTypeBinding18) {
/* 3020 */           sig.append(((IntersectionTypeBinding18)funcEx.resolvedType).getSAMType((Scope)scope).signature());
/*      */         } else {
/* 3022 */           sig.append(funcEx.resolvedType.signature());
/*      */         } 
/*      */         
/* 3025 */         invokeDynamic(funcEx.bootstrapMethodNumber, index, 1, funcEx.descriptor.selector, 
/* 3026 */             sig.toString().toCharArray(), funcEx.resolvedType.id, funcEx.resolvedType);
/* 3027 */         areturn();
/* 3028 */         if (k < count - 1) {
/* 3029 */           nextOne.place();
/* 3030 */           nextOne = (k < count - 2) ? new BranchLabel(this) : errorLabel;
/*      */         } 
/*      */       } 
/*      */     } 
/*      */     
/* 3035 */     removeVariable(lvb1);
/* 3036 */     removeVariable(lvb2);
/* 3037 */     defaultLabel.place();
/* 3038 */     errorLabel.place();
/*      */     
/* 3040 */     new_((TypeBinding)scope.getJavaLangIllegalArgumentException());
/* 3041 */     dup();
/* 3042 */     ldc("Invalid lambda deserialization");
/*      */     
/* 3044 */     invoke((byte)
/* 3045 */         -73, 
/* 3046 */         2, 
/* 3047 */         0, 
/* 3048 */         ConstantPool.JavaLangIllegalArgumentExceptionConstantPoolName, 
/* 3049 */         ConstantPool.Init, 
/* 3050 */         ConstantPool.IllegalArgumentExceptionConstructorSignature, 
/* 3051 */         null);
/* 3052 */     athrow();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void loadInt(int value) {
/* 3060 */     if (value < 6) {
/* 3061 */       if (value == 0) {
/* 3062 */         iconst_0();
/* 3063 */       } else if (value == 1) {
/* 3064 */         iconst_1();
/* 3065 */       } else if (value == 2) {
/* 3066 */         iconst_2();
/* 3067 */       } else if (value == 3) {
/* 3068 */         iconst_3();
/* 3069 */       } else if (value == 4) {
/* 3070 */         iconst_4();
/* 3071 */       } else if (value == 5) {
/* 3072 */         iconst_5();
/*      */       } 
/* 3074 */     } else if (value < 128) {
/*      */       
/* 3076 */       bipush((byte)value);
/*      */     } else {
/*      */       
/* 3079 */       ldc(value);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void generateSyntheticBodyForEnumValues(SyntheticMethodBinding methodBinding) {
/* 3091 */     ClassScope scope = ((SourceTypeBinding)methodBinding.declaringClass).scope;
/* 3092 */     initializeMaxLocals((MethodBinding)methodBinding);
/* 3093 */     TypeBinding enumArray = methodBinding.returnType;
/* 3094 */     fieldAccess((byte)-78, scope.referenceContext.enumValuesSyntheticfield, null);
/* 3095 */     dup();
/* 3096 */     astore_0();
/* 3097 */     iconst_0();
/* 3098 */     aload_0();
/* 3099 */     arraylength();
/* 3100 */     dup();
/* 3101 */     istore_1();
/* 3102 */     newArray((ArrayBinding)enumArray);
/* 3103 */     dup();
/* 3104 */     astore_2();
/* 3105 */     iconst_0();
/* 3106 */     iload_1();
/* 3107 */     invokeSystemArraycopy();
/* 3108 */     aload_2();
/* 3109 */     areturn();
/*      */   }
/*      */   
/*      */   public void generateSyntheticBodyForEnumInitializationMethod(SyntheticMethodBinding methodBinding) {
/* 3113 */     this.maxLocals = 0;
/*      */     
/* 3115 */     SourceTypeBinding sourceTypeBinding = (SourceTypeBinding)methodBinding.declaringClass;
/* 3116 */     TypeDeclaration typeDeclaration = sourceTypeBinding.scope.referenceContext;
/* 3117 */     MethodScope methodScope = typeDeclaration.staticInitializerScope;
/* 3118 */     FieldDeclaration[] fieldDeclarations = typeDeclaration.fields;
/* 3119 */     for (int i = methodBinding.startIndex, max = methodBinding.endIndex; i < max; i++) {
/* 3120 */       FieldDeclaration fieldDecl = fieldDeclarations[i];
/* 3121 */       if (fieldDecl.isStatic() && 
/* 3122 */         fieldDecl.getKind() == 3) {
/* 3123 */         fieldDecl.generateCode((BlockScope)methodScope, this);
/*      */       }
/*      */     } 
/*      */     
/* 3127 */     return_();
/*      */   }
/*      */   public void generateSyntheticBodyForFieldReadAccess(SyntheticMethodBinding accessMethod) {
/* 3130 */     initializeMaxLocals((MethodBinding)accessMethod);
/* 3131 */     FieldBinding fieldBinding = accessMethod.targetReadField;
/*      */     
/* 3133 */     ReferenceBinding referenceBinding = (accessMethod.purpose == 3) ? 
/* 3134 */       accessMethod.declaringClass.superclass() : 
/* 3135 */       accessMethod.declaringClass;
/* 3136 */     if (fieldBinding.isStatic()) {
/* 3137 */       fieldAccess((byte)-78, fieldBinding, (TypeBinding)referenceBinding);
/*      */     } else {
/* 3139 */       aload_0();
/* 3140 */       fieldAccess((byte)-76, fieldBinding, (TypeBinding)referenceBinding);
/*      */     } 
/* 3142 */     switch (fieldBinding.type.id) {
/*      */ 
/*      */ 
/*      */       
/*      */       case 2:
/*      */       case 3:
/*      */       case 4:
/*      */       case 5:
/*      */       case 10:
/* 3151 */         ireturn();
/*      */         return;
/*      */       case 7:
/* 3154 */         lreturn();
/*      */         return;
/*      */       case 9:
/* 3157 */         freturn();
/*      */         return;
/*      */       case 8:
/* 3160 */         dreturn();
/*      */         return;
/*      */     } 
/* 3163 */     areturn();
/*      */   }
/*      */ 
/*      */   
/*      */   public void generateSyntheticBodyForFieldWriteAccess(SyntheticMethodBinding accessMethod) {
/* 3168 */     initializeMaxLocals((MethodBinding)accessMethod);
/* 3169 */     FieldBinding fieldBinding = accessMethod.targetWriteField;
/*      */     
/* 3171 */     ReferenceBinding referenceBinding = (accessMethod.purpose == 4) ? 
/* 3172 */       accessMethod.declaringClass.superclass() : 
/* 3173 */       accessMethod.declaringClass;
/* 3174 */     if (fieldBinding.isStatic()) {
/* 3175 */       load(fieldBinding.type, 0);
/* 3176 */       fieldAccess((byte)-77, fieldBinding, (TypeBinding)referenceBinding);
/*      */     } else {
/* 3178 */       aload_0();
/* 3179 */       load(fieldBinding.type, 1);
/* 3180 */       fieldAccess((byte)-75, fieldBinding, (TypeBinding)referenceBinding);
/*      */     } 
/* 3182 */     return_();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void generateSyntheticBodyForMethodAccess(SyntheticMethodBinding accessMethod) {
/*      */     // Byte code:
/*      */     //   0: aload_0
/*      */     //   1: aload_1
/*      */     //   2: invokevirtual initializeMaxLocals : (Lorg/eclipse/jdt/internal/compiler/lookup/MethodBinding;)V
/*      */     //   5: aload_1
/*      */     //   6: getfield targetMethod : Lorg/eclipse/jdt/internal/compiler/lookup/MethodBinding;
/*      */     //   9: astore_2
/*      */     //   10: aload_2
/*      */     //   11: getfield parameters : [Lorg/eclipse/jdt/internal/compiler/lookup/TypeBinding;
/*      */     //   14: astore_3
/*      */     //   15: aload_3
/*      */     //   16: arraylength
/*      */     //   17: istore #4
/*      */     //   19: aload_1
/*      */     //   20: getfield purpose : I
/*      */     //   23: bipush #8
/*      */     //   25: if_icmpne -> 35
/*      */     //   28: aload_1
/*      */     //   29: getfield parameters : [Lorg/eclipse/jdt/internal/compiler/lookup/TypeBinding;
/*      */     //   32: goto -> 36
/*      */     //   35: aconst_null
/*      */     //   36: astore #5
/*      */     //   38: aload_2
/*      */     //   39: invokevirtual isStatic : ()Z
/*      */     //   42: ifeq -> 51
/*      */     //   45: iconst_0
/*      */     //   46: istore #6
/*      */     //   48: goto -> 58
/*      */     //   51: aload_0
/*      */     //   52: invokevirtual aload_0 : ()V
/*      */     //   55: iconst_1
/*      */     //   56: istore #6
/*      */     //   58: iconst_0
/*      */     //   59: istore #7
/*      */     //   61: goto -> 156
/*      */     //   64: aload_3
/*      */     //   65: iload #7
/*      */     //   67: aaload
/*      */     //   68: astore #8
/*      */     //   70: aload #5
/*      */     //   72: ifnull -> 109
/*      */     //   75: aload #5
/*      */     //   77: iload #7
/*      */     //   79: aaload
/*      */     //   80: astore #9
/*      */     //   82: aload_0
/*      */     //   83: aload #9
/*      */     //   85: iload #6
/*      */     //   87: invokevirtual load : (Lorg/eclipse/jdt/internal/compiler/lookup/TypeBinding;I)V
/*      */     //   90: aload #9
/*      */     //   92: aload #8
/*      */     //   94: invokestatic notEquals : (Lorg/eclipse/jdt/internal/compiler/lookup/TypeBinding;Lorg/eclipse/jdt/internal/compiler/lookup/TypeBinding;)Z
/*      */     //   97: ifeq -> 117
/*      */     //   100: aload_0
/*      */     //   101: aload #8
/*      */     //   103: invokevirtual checkcast : (Lorg/eclipse/jdt/internal/compiler/lookup/TypeBinding;)V
/*      */     //   106: goto -> 117
/*      */     //   109: aload_0
/*      */     //   110: aload #8
/*      */     //   112: iload #6
/*      */     //   114: invokevirtual load : (Lorg/eclipse/jdt/internal/compiler/lookup/TypeBinding;I)V
/*      */     //   117: aload #8
/*      */     //   119: getfield id : I
/*      */     //   122: tableswitch default -> 150, 7 -> 144, 8 -> 144
/*      */     //   144: iinc #6, 2
/*      */     //   147: goto -> 153
/*      */     //   150: iinc #6, 1
/*      */     //   153: iinc #7, 1
/*      */     //   156: iload #7
/*      */     //   158: iload #4
/*      */     //   160: if_icmplt -> 64
/*      */     //   163: aload_2
/*      */     //   164: invokevirtual isStatic : ()Z
/*      */     //   167: ifeq -> 184
/*      */     //   170: aload_0
/*      */     //   171: bipush #-72
/*      */     //   173: aload_2
/*      */     //   174: aload_1
/*      */     //   175: getfield declaringClass : Lorg/eclipse/jdt/internal/compiler/lookup/ReferenceBinding;
/*      */     //   178: invokevirtual invoke : (BLorg/eclipse/jdt/internal/compiler/lookup/MethodBinding;Lorg/eclipse/jdt/internal/compiler/lookup/TypeBinding;)V
/*      */     //   181: goto -> 275
/*      */     //   184: aload_2
/*      */     //   185: invokevirtual isConstructor : ()Z
/*      */     //   188: ifne -> 207
/*      */     //   191: aload_2
/*      */     //   192: invokevirtual isPrivate : ()Z
/*      */     //   195: ifne -> 207
/*      */     //   198: aload_1
/*      */     //   199: getfield purpose : I
/*      */     //   202: bipush #7
/*      */     //   204: if_icmpne -> 243
/*      */     //   207: aload_1
/*      */     //   208: getfield purpose : I
/*      */     //   211: bipush #7
/*      */     //   213: if_icmpne -> 225
/*      */     //   216: aload_0
/*      */     //   217: aload_1
/*      */     //   218: aload_2
/*      */     //   219: invokevirtual findDirectSuperTypeTowards : (Lorg/eclipse/jdt/internal/compiler/lookup/SyntheticMethodBinding;Lorg/eclipse/jdt/internal/compiler/lookup/MethodBinding;)Lorg/eclipse/jdt/internal/compiler/lookup/ReferenceBinding;
/*      */     //   222: goto -> 229
/*      */     //   225: aload_1
/*      */     //   226: getfield declaringClass : Lorg/eclipse/jdt/internal/compiler/lookup/ReferenceBinding;
/*      */     //   229: astore #7
/*      */     //   231: aload_0
/*      */     //   232: bipush #-73
/*      */     //   234: aload_2
/*      */     //   235: aload #7
/*      */     //   237: invokevirtual invoke : (BLorg/eclipse/jdt/internal/compiler/lookup/MethodBinding;Lorg/eclipse/jdt/internal/compiler/lookup/TypeBinding;)V
/*      */     //   240: goto -> 275
/*      */     //   243: aload_2
/*      */     //   244: getfield declaringClass : Lorg/eclipse/jdt/internal/compiler/lookup/ReferenceBinding;
/*      */     //   247: invokevirtual isInterface : ()Z
/*      */     //   250: ifeq -> 264
/*      */     //   253: aload_0
/*      */     //   254: bipush #-71
/*      */     //   256: aload_2
/*      */     //   257: aconst_null
/*      */     //   258: invokevirtual invoke : (BLorg/eclipse/jdt/internal/compiler/lookup/MethodBinding;Lorg/eclipse/jdt/internal/compiler/lookup/TypeBinding;)V
/*      */     //   261: goto -> 275
/*      */     //   264: aload_0
/*      */     //   265: bipush #-74
/*      */     //   267: aload_2
/*      */     //   268: aload_1
/*      */     //   269: getfield declaringClass : Lorg/eclipse/jdt/internal/compiler/lookup/ReferenceBinding;
/*      */     //   272: invokevirtual invoke : (BLorg/eclipse/jdt/internal/compiler/lookup/MethodBinding;Lorg/eclipse/jdt/internal/compiler/lookup/TypeBinding;)V
/*      */     //   275: aload_2
/*      */     //   276: getfield returnType : Lorg/eclipse/jdt/internal/compiler/lookup/TypeBinding;
/*      */     //   279: getfield id : I
/*      */     //   282: tableswitch default -> 367, 2 -> 339, 3 -> 339, 4 -> 339, 5 -> 339, 6 -> 332, 7 -> 346, 8 -> 360, 9 -> 353, 10 -> 339
/*      */     //   332: aload_0
/*      */     //   333: invokevirtual return_ : ()V
/*      */     //   336: goto -> 402
/*      */     //   339: aload_0
/*      */     //   340: invokevirtual ireturn : ()V
/*      */     //   343: goto -> 402
/*      */     //   346: aload_0
/*      */     //   347: invokevirtual lreturn : ()V
/*      */     //   350: goto -> 402
/*      */     //   353: aload_0
/*      */     //   354: invokevirtual freturn : ()V
/*      */     //   357: goto -> 402
/*      */     //   360: aload_0
/*      */     //   361: invokevirtual dreturn : ()V
/*      */     //   364: goto -> 402
/*      */     //   367: aload_1
/*      */     //   368: getfield returnType : Lorg/eclipse/jdt/internal/compiler/lookup/TypeBinding;
/*      */     //   371: invokevirtual erasure : ()Lorg/eclipse/jdt/internal/compiler/lookup/TypeBinding;
/*      */     //   374: astore #7
/*      */     //   376: aload_2
/*      */     //   377: getfield returnType : Lorg/eclipse/jdt/internal/compiler/lookup/TypeBinding;
/*      */     //   380: aload #7
/*      */     //   382: invokevirtual findSuperTypeOriginatingFrom : (Lorg/eclipse/jdt/internal/compiler/lookup/TypeBinding;)Lorg/eclipse/jdt/internal/compiler/lookup/TypeBinding;
/*      */     //   385: astore #8
/*      */     //   387: aload #8
/*      */     //   389: ifnonnull -> 398
/*      */     //   392: aload_0
/*      */     //   393: aload #7
/*      */     //   395: invokevirtual checkcast : (Lorg/eclipse/jdt/internal/compiler/lookup/TypeBinding;)V
/*      */     //   398: aload_0
/*      */     //   399: invokevirtual areturn : ()V
/*      */     //   402: return
/*      */     // Line number table:
/*      */     //   Java source line number -> byte code offset
/*      */     //   #3186	-> 0
/*      */     //   #3187	-> 5
/*      */     //   #3188	-> 10
/*      */     //   #3189	-> 15
/*      */     //   #3190	-> 19
/*      */     //   #3191	-> 28
/*      */     //   #3192	-> 35
/*      */     //   #3190	-> 36
/*      */     //   #3194	-> 38
/*      */     //   #3195	-> 45
/*      */     //   #3197	-> 51
/*      */     //   #3198	-> 55
/*      */     //   #3200	-> 58
/*      */     //   #3201	-> 64
/*      */     //   #3202	-> 70
/*      */     //   #3203	-> 75
/*      */     //   #3204	-> 82
/*      */     //   #3205	-> 90
/*      */     //   #3206	-> 100
/*      */     //   #3207	-> 106
/*      */     //   #3208	-> 109
/*      */     //   #3210	-> 117
/*      */     //   #3213	-> 144
/*      */     //   #3214	-> 147
/*      */     //   #3216	-> 150
/*      */     //   #3200	-> 153
/*      */     //   #3220	-> 163
/*      */     //   #3221	-> 170
/*      */     //   #3223	-> 184
/*      */     //   #3224	-> 191
/*      */     //   #3226	-> 198
/*      */     //   #3228	-> 207
/*      */     //   #3229	-> 216
/*      */     //   #3230	-> 225
/*      */     //   #3228	-> 229
/*      */     //   #3231	-> 231
/*      */     //   #3232	-> 240
/*      */     //   #3233	-> 243
/*      */     //   #3234	-> 253
/*      */     //   #3235	-> 261
/*      */     //   #3236	-> 264
/*      */     //   #3240	-> 275
/*      */     //   #3242	-> 332
/*      */     //   #3243	-> 336
/*      */     //   #3249	-> 339
/*      */     //   #3250	-> 343
/*      */     //   #3252	-> 346
/*      */     //   #3253	-> 350
/*      */     //   #3255	-> 353
/*      */     //   #3256	-> 357
/*      */     //   #3258	-> 360
/*      */     //   #3259	-> 364
/*      */     //   #3261	-> 367
/*      */     //   #3262	-> 376
/*      */     //   #3263	-> 387
/*      */     //   #3264	-> 392
/*      */     //   #3266	-> 398
/*      */     //   #3268	-> 402
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	descriptor
/*      */     //   0	403	0	this	Lorg/eclipse/jdt/internal/compiler/codegen/CodeStream;
/*      */     //   0	403	1	accessMethod	Lorg/eclipse/jdt/internal/compiler/lookup/SyntheticMethodBinding;
/*      */     //   10	393	2	targetMethod	Lorg/eclipse/jdt/internal/compiler/lookup/MethodBinding;
/*      */     //   15	388	3	parameters	[Lorg/eclipse/jdt/internal/compiler/lookup/TypeBinding;
/*      */     //   19	384	4	length	I
/*      */     //   38	365	5	arguments	[Lorg/eclipse/jdt/internal/compiler/lookup/TypeBinding;
/*      */     //   48	3	6	resolvedPosition	I
/*      */     //   58	345	6	resolvedPosition	I
/*      */     //   61	102	7	i	I
/*      */     //   70	83	8	parameter	Lorg/eclipse/jdt/internal/compiler/lookup/TypeBinding;
/*      */     //   82	24	9	argument	Lorg/eclipse/jdt/internal/compiler/lookup/TypeBinding;
/*      */     //   231	9	7	declaringClass	Lorg/eclipse/jdt/internal/compiler/lookup/TypeBinding;
/*      */     //   376	26	7	accessErasure	Lorg/eclipse/jdt/internal/compiler/lookup/TypeBinding;
/*      */     //   387	15	8	match	Lorg/eclipse/jdt/internal/compiler/lookup/TypeBinding;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   ReferenceBinding findDirectSuperTypeTowards(SyntheticMethodBinding accessMethod, MethodBinding targetMethod) {
/* 3272 */     ReferenceBinding currentType = accessMethod.declaringClass;
/* 3273 */     ReferenceBinding superclass = currentType.superclass();
/* 3274 */     if (targetMethod.isDefaultMethod()) {
/*      */       
/* 3276 */       ReferenceBinding targetType = targetMethod.declaringClass;
/* 3277 */       if (superclass.isCompatibleWith((TypeBinding)targetType))
/* 3278 */         return superclass; 
/* 3279 */       ReferenceBinding[] superInterfaces = currentType.superInterfaces();
/* 3280 */       if (superInterfaces != null)
/* 3281 */         for (int i = 0; i < superInterfaces.length; i++) {
/* 3282 */           ReferenceBinding superIfc = superInterfaces[i];
/* 3283 */           if (superIfc.isCompatibleWith((TypeBinding)targetType)) {
/* 3284 */             return superIfc;
/*      */           }
/*      */         }  
/* 3287 */       throw new RuntimeException("Assumption violated: some super type must be conform to the declaring class of a super method");
/*      */     } 
/*      */     
/* 3290 */     return superclass;
/*      */   }
/*      */ 
/*      */   
/*      */   public void generateSyntheticBodyForSwitchTable(SyntheticMethodBinding methodBinding) {
/* 3295 */     ClassScope scope = ((SourceTypeBinding)methodBinding.declaringClass).scope;
/* 3296 */     initializeMaxLocals((MethodBinding)methodBinding);
/* 3297 */     BranchLabel nullLabel = new BranchLabel(this);
/* 3298 */     FieldBinding syntheticFieldBinding = methodBinding.targetReadField;
/* 3299 */     fieldAccess((byte)-78, syntheticFieldBinding, null);
/* 3300 */     dup();
/* 3301 */     ifnull(nullLabel);
/* 3302 */     areturn();
/* 3303 */     pushOnStack(syntheticFieldBinding.type);
/* 3304 */     nullLabel.place();
/* 3305 */     pop();
/* 3306 */     ReferenceBinding enumBinding = (ReferenceBinding)methodBinding.targetEnumType;
/* 3307 */     ArrayBinding arrayBinding = scope.createArrayType((TypeBinding)enumBinding, 1);
/* 3308 */     invokeJavaLangEnumValues((TypeBinding)enumBinding, arrayBinding);
/* 3309 */     arraylength();
/* 3310 */     newarray(10);
/* 3311 */     astore_0();
/* 3312 */     LocalVariableBinding localVariableBinding = new LocalVariableBinding(" tab".toCharArray(), (TypeBinding)scope.createArrayType((TypeBinding)TypeBinding.INT, 1), 0, false);
/* 3313 */     addVariable(localVariableBinding);
/* 3314 */     FieldBinding[] fields = enumBinding.fields();
/* 3315 */     if (fields != null) {
/* 3316 */       for (int i = 0, max = fields.length; i < max; i++) {
/* 3317 */         FieldBinding fieldBinding = fields[i];
/* 3318 */         if ((fieldBinding.getAccessFlags() & 0x4000) != 0) {
/* 3319 */           BranchLabel endLabel = new BranchLabel(this);
/* 3320 */           ExceptionLabel anyExceptionHandler = new ExceptionLabel(this, (TypeBinding)TypeBinding.LONG);
/* 3321 */           anyExceptionHandler.placeStart();
/* 3322 */           aload_0();
/* 3323 */           fieldAccess((byte)-78, fieldBinding, null);
/* 3324 */           invokeEnumOrdinal(enumBinding.constantPoolName());
/* 3325 */           generateInlinedValue(fieldBinding.id + 1);
/* 3326 */           iastore();
/* 3327 */           anyExceptionHandler.placeEnd();
/* 3328 */           goto_(endLabel);
/*      */           
/* 3330 */           pushExceptionOnStack((TypeBinding)scope.getJavaLangNoSuchFieldError());
/* 3331 */           anyExceptionHandler.place();
/* 3332 */           pop();
/* 3333 */           endLabel.place();
/*      */         } 
/*      */       } 
/*      */     }
/* 3337 */     aload_0();
/* 3338 */     if ((scope.compilerOptions()).complianceLevel < 3473408L || !syntheticFieldBinding.isFinal()) {
/*      */       
/* 3340 */       dup();
/* 3341 */       fieldAccess((byte)-77, syntheticFieldBinding, null);
/*      */     } 
/* 3343 */     areturn();
/* 3344 */     removeVariable(localVariableBinding);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void generateSyntheticEnclosingInstanceValues(BlockScope currentScope, ReferenceBinding targetType, Expression enclosingInstance, ASTNode invocationSite) {
/* 3353 */     ReferenceBinding checkedTargetType = targetType.isAnonymousType() ? (ReferenceBinding)targetType.superclass().erasure() : targetType;
/* 3354 */     boolean hasExtraEnclosingInstance = (enclosingInstance != null);
/* 3355 */     if (hasExtraEnclosingInstance && (
/* 3356 */       !checkedTargetType.isNestedType() || checkedTargetType.isStatic())) {
/* 3357 */       currentScope.problemReporter().unnecessaryEnclosingInstanceSpecification(enclosingInstance, checkedTargetType);
/*      */       
/*      */       return;
/*      */     } 
/*      */     
/*      */     ReferenceBinding[] syntheticArgumentTypes;
/* 3363 */     if ((syntheticArgumentTypes = targetType.syntheticEnclosingInstanceTypes()) != null) {
/*      */       boolean denyEnclosingArgInConstructorCall;
/* 3365 */       ReferenceBinding targetEnclosingType = checkedTargetType.enclosingType();
/* 3366 */       long compliance = (currentScope.compilerOptions()).complianceLevel;
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 3371 */       if (compliance <= 3080192L) {
/* 3372 */         denyEnclosingArgInConstructorCall = invocationSite instanceof org.eclipse.jdt.internal.compiler.ast.AllocationExpression;
/* 3373 */       } else if (compliance == 3145728L) {
/* 3374 */         denyEnclosingArgInConstructorCall = !(!(invocationSite instanceof org.eclipse.jdt.internal.compiler.ast.AllocationExpression) && (
/* 3375 */           !(invocationSite instanceof ExplicitConstructorCall) || !((ExplicitConstructorCall)invocationSite).isSuperAccess()));
/* 3376 */       } else if (compliance < 3342336L) {
/*      */         
/* 3378 */         denyEnclosingArgInConstructorCall = ((invocationSite instanceof org.eclipse.jdt.internal.compiler.ast.AllocationExpression || (
/* 3379 */           invocationSite instanceof ExplicitConstructorCall && ((ExplicitConstructorCall)invocationSite).isSuperAccess())) && 
/* 3380 */           !targetType.isLocalType());
/*      */       
/*      */       }
/* 3383 */       else if (invocationSite instanceof org.eclipse.jdt.internal.compiler.ast.AllocationExpression) {
/* 3384 */         denyEnclosingArgInConstructorCall = !targetType.isLocalType();
/* 3385 */       } else if (invocationSite instanceof ExplicitConstructorCall && (
/* 3386 */         (ExplicitConstructorCall)invocationSite).isSuperAccess()) {
/* 3387 */         MethodScope enclosingMethodScope = currentScope.enclosingMethodScope();
/* 3388 */         denyEnclosingArgInConstructorCall = (!targetType.isLocalType() && enclosingMethodScope != null && 
/* 3389 */           enclosingMethodScope.isConstructorCall);
/*      */       } else {
/* 3391 */         denyEnclosingArgInConstructorCall = false;
/*      */       } 
/*      */ 
/*      */       
/* 3395 */       boolean complyTo14 = (compliance >= 3145728L);
/* 3396 */       for (int i = 0, max = syntheticArgumentTypes.length; i < max; i++) {
/* 3397 */         ReferenceBinding syntheticArgType = syntheticArgumentTypes[i];
/* 3398 */         if (hasExtraEnclosingInstance && TypeBinding.equalsEquals((TypeBinding)syntheticArgType, (TypeBinding)targetEnclosingType)) {
/* 3399 */           hasExtraEnclosingInstance = false;
/* 3400 */           enclosingInstance.generateCode(currentScope, this, true);
/* 3401 */           if (complyTo14) {
/* 3402 */             dup();
/* 3403 */             invokeObjectGetClass();
/* 3404 */             pop();
/*      */           } 
/*      */         } else {
/* 3407 */           Object[] emulationPath = currentScope.getEmulationPath(
/* 3408 */               syntheticArgType, 
/* 3409 */               false, 
/* 3410 */               denyEnclosingArgInConstructorCall);
/* 3411 */           generateOuterAccess(emulationPath, invocationSite, (Binding)syntheticArgType, (Scope)currentScope);
/*      */         } 
/*      */       } 
/* 3414 */       if (hasExtraEnclosingInstance) {
/* 3415 */         currentScope.problemReporter().unnecessaryEnclosingInstanceSpecification(enclosingInstance, checkedTargetType);
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void generateSyntheticOuterArgumentValues(BlockScope currentScope, ReferenceBinding targetType, ASTNode invocationSite) {
/*      */     SyntheticArgumentBinding[] syntheticArguments;
/* 3428 */     if ((syntheticArguments = targetType.syntheticOuterLocalVariables()) != null)
/* 3429 */       for (int i = 0, max = syntheticArguments.length; i < max; i++) {
/* 3430 */         LocalVariableBinding targetVariable = (syntheticArguments[i]).actualOuterLocalVariable;
/* 3431 */         VariableBinding[] emulationPath = currentScope.getEmulationPath(targetVariable);
/* 3432 */         generateOuterAccess((Object[])emulationPath, invocationSite, (Binding)targetVariable, (Scope)currentScope);
/*      */       }  
/*      */   }
/*      */   
/*      */   public void generateSyntheticBodyForRecordCanonicalConstructor(SyntheticMethodBinding canonConstructor) {
/* 3437 */     initializeMaxLocals((MethodBinding)canonConstructor);
/* 3438 */     SourceTypeBinding declaringClass = (SourceTypeBinding)canonConstructor.declaringClass;
/* 3439 */     ReferenceBinding superClass = declaringClass.superclass();
/* 3440 */     MethodBinding superCons = superClass.getExactConstructor(new TypeBinding[0]);
/* 3441 */     aload_0();
/* 3442 */     invoke((byte)-73, superCons, (TypeBinding)superClass);
/*      */     
/* 3444 */     FieldBinding[] fields = declaringClass.getImplicitComponentFields();
/* 3445 */     int len = (fields != null) ? fields.length : 0;
/* 3446 */     int resolvedPosition = 1;
/* 3447 */     for (int i = 0; i < len; i++) {
/* 3448 */       FieldBinding field = fields[i];
/* 3449 */       aload_0();
/* 3450 */       TypeBinding type = field.type;
/* 3451 */       load(type, resolvedPosition);
/* 3452 */       switch (type.id) {
/*      */         case 7:
/*      */         case 8:
/* 3455 */           resolvedPosition += 2;
/*      */           break;
/*      */         default:
/* 3458 */           resolvedPosition++;
/*      */           break;
/*      */       } 
/* 3461 */       fieldAccess((byte)-75, field, (TypeBinding)declaringClass);
/*      */     } 
/* 3463 */     return_();
/*      */   }
/*      */   public void generateSyntheticBodyForRecordEquals(SyntheticMethodBinding methodBinding, int index) {
/* 3466 */     initializeMaxLocals((MethodBinding)methodBinding);
/* 3467 */     aload_0();
/* 3468 */     aload_1();
/* 3469 */     String sig = new String(methodBinding.signature());
/* 3470 */     sig = String.valueOf(sig.substring(0, 1)) + new String(methodBinding.declaringClass.signature()) + sig.substring(1);
/* 3471 */     invokeDynamic(index, methodBinding.parameters.length, 1, methodBinding.selector, sig.toCharArray(), 
/* 3472 */         5, (TypeBinding)TypeBinding.BOOLEAN);
/* 3473 */     ireturn();
/*      */   }
/*      */   public void generateSyntheticBodyForRecordHashCode(SyntheticMethodBinding methodBinding, int index) {
/* 3476 */     initializeMaxLocals((MethodBinding)methodBinding);
/* 3477 */     aload_0();
/* 3478 */     String sig = new String(methodBinding.signature());
/* 3479 */     sig = String.valueOf(sig.substring(0, 1)) + new String(methodBinding.declaringClass.signature()) + sig.substring(1);
/* 3480 */     invokeDynamic(index, methodBinding.parameters.length, 1, methodBinding.selector, sig.toCharArray(), 
/* 3481 */         10, (TypeBinding)TypeBinding.INT);
/* 3482 */     ireturn();
/*      */   }
/*      */   public void generateSyntheticBodyForRecordToString(SyntheticMethodBinding methodBinding, int index) {
/* 3485 */     initializeMaxLocals((MethodBinding)methodBinding);
/* 3486 */     aload_0();
/* 3487 */     String sig = new String(methodBinding.signature());
/* 3488 */     sig = String.valueOf(sig.substring(0, 1)) + new String(methodBinding.declaringClass.signature()) + sig.substring(1);
/* 3489 */     invokeDynamic(index, methodBinding.parameters.length, 1, methodBinding.selector, sig.toCharArray(), 
/* 3490 */         1, getPopularBinding(ConstantPool.JavaLangStringConstantPoolName));
/* 3491 */     areturn();
/*      */   }
/*      */   
/*      */   public void generateUnboxingConversion(int unboxedTypeID) {
/* 3495 */     switch (unboxedTypeID) {
/*      */       
/*      */       case 3:
/* 3498 */         invoke((byte)
/* 3499 */             -74, 
/* 3500 */             1, 
/* 3501 */             1, 
/* 3502 */             ConstantPool.JavaLangByteConstantPoolName, 
/* 3503 */             ConstantPool.BYTEVALUE_BYTE_METHOD_NAME, 
/* 3504 */             ConstantPool.BYTEVALUE_BYTE_METHOD_SIGNATURE, 
/* 3505 */             unboxedTypeID, 
/* 3506 */             TypeBinding.wellKnownBaseType(unboxedTypeID));
/*      */         break;
/*      */       
/*      */       case 4:
/* 3510 */         invoke((byte)
/* 3511 */             -74, 
/* 3512 */             1, 
/* 3513 */             1, 
/* 3514 */             ConstantPool.JavaLangShortConstantPoolName, 
/* 3515 */             ConstantPool.SHORTVALUE_SHORT_METHOD_NAME, 
/* 3516 */             ConstantPool.SHORTVALUE_SHORT_METHOD_SIGNATURE, 
/* 3517 */             unboxedTypeID, 
/* 3518 */             TypeBinding.wellKnownBaseType(unboxedTypeID));
/*      */         break;
/*      */       
/*      */       case 2:
/* 3522 */         invoke((byte)
/* 3523 */             -74, 
/* 3524 */             1, 
/* 3525 */             1, 
/* 3526 */             ConstantPool.JavaLangCharacterConstantPoolName, 
/* 3527 */             ConstantPool.CHARVALUE_CHARACTER_METHOD_NAME, 
/* 3528 */             ConstantPool.CHARVALUE_CHARACTER_METHOD_SIGNATURE, 
/* 3529 */             unboxedTypeID, 
/* 3530 */             TypeBinding.wellKnownBaseType(unboxedTypeID));
/*      */         break;
/*      */       
/*      */       case 10:
/* 3534 */         invoke((byte)
/* 3535 */             -74, 
/* 3536 */             1, 
/* 3537 */             1, 
/* 3538 */             ConstantPool.JavaLangIntegerConstantPoolName, 
/* 3539 */             ConstantPool.INTVALUE_INTEGER_METHOD_NAME, 
/* 3540 */             ConstantPool.INTVALUE_INTEGER_METHOD_SIGNATURE, 
/* 3541 */             unboxedTypeID, 
/* 3542 */             TypeBinding.wellKnownBaseType(unboxedTypeID));
/*      */         break;
/*      */       
/*      */       case 7:
/* 3546 */         invoke((byte)
/* 3547 */             -74, 
/* 3548 */             1, 
/* 3549 */             2, 
/* 3550 */             ConstantPool.JavaLangLongConstantPoolName, 
/* 3551 */             ConstantPool.LONGVALUE_LONG_METHOD_NAME, 
/* 3552 */             ConstantPool.LONGVALUE_LONG_METHOD_SIGNATURE, 
/* 3553 */             unboxedTypeID, 
/* 3554 */             TypeBinding.wellKnownBaseType(unboxedTypeID));
/*      */         break;
/*      */       
/*      */       case 9:
/* 3558 */         invoke((byte)
/* 3559 */             -74, 
/* 3560 */             1, 
/* 3561 */             1, 
/* 3562 */             ConstantPool.JavaLangFloatConstantPoolName, 
/* 3563 */             ConstantPool.FLOATVALUE_FLOAT_METHOD_NAME, 
/* 3564 */             ConstantPool.FLOATVALUE_FLOAT_METHOD_SIGNATURE, 
/* 3565 */             unboxedTypeID, 
/* 3566 */             TypeBinding.wellKnownBaseType(unboxedTypeID));
/*      */         break;
/*      */       
/*      */       case 8:
/* 3570 */         invoke((byte)
/* 3571 */             -74, 
/* 3572 */             1, 
/* 3573 */             2, 
/* 3574 */             ConstantPool.JavaLangDoubleConstantPoolName, 
/* 3575 */             ConstantPool.DOUBLEVALUE_DOUBLE_METHOD_NAME, 
/* 3576 */             ConstantPool.DOUBLEVALUE_DOUBLE_METHOD_SIGNATURE, 
/* 3577 */             unboxedTypeID, 
/* 3578 */             TypeBinding.wellKnownBaseType(unboxedTypeID));
/*      */         break;
/*      */       
/*      */       case 5:
/* 3582 */         invoke((byte)
/* 3583 */             -74, 
/* 3584 */             1, 
/* 3585 */             1, 
/* 3586 */             ConstantPool.JavaLangBooleanConstantPoolName, 
/* 3587 */             ConstantPool.BOOLEANVALUE_BOOLEAN_METHOD_NAME, 
/* 3588 */             ConstantPool.BOOLEANVALUE_BOOLEAN_METHOD_SIGNATURE, 
/* 3589 */             unboxedTypeID, 
/* 3590 */             TypeBinding.wellKnownBaseType(unboxedTypeID));
/*      */         break;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void generateWideRevertedConditionalBranch(byte revertedOpcode, BranchLabel wideTarget) {
/* 3604 */     BranchLabel intermediate = new BranchLabel(this);
/* 3605 */     if (this.classFileOffset >= this.bCodeStream.length) {
/* 3606 */       resizeByteArray();
/*      */     }
/* 3608 */     this.position++;
/* 3609 */     this.bCodeStream[this.classFileOffset++] = revertedOpcode;
/* 3610 */     intermediate.branch();
/* 3611 */     goto_w(wideTarget);
/* 3612 */     intermediate.place();
/*      */   }
/*      */   
/*      */   public void getBaseTypeValue(int baseTypeID) {
/* 3616 */     switch (baseTypeID) {
/*      */       
/*      */       case 3:
/* 3619 */         invoke((byte)
/* 3620 */             -74, 
/* 3621 */             1, 
/* 3622 */             1, 
/* 3623 */             ConstantPool.JavaLangByteConstantPoolName, 
/* 3624 */             ConstantPool.BYTEVALUE_BYTE_METHOD_NAME, 
/* 3625 */             ConstantPool.BYTEVALUE_BYTE_METHOD_SIGNATURE, 
/* 3626 */             baseTypeID, 
/* 3627 */             TypeBinding.wellKnownBaseType(baseTypeID));
/*      */         break;
/*      */       
/*      */       case 4:
/* 3631 */         invoke((byte)
/* 3632 */             -74, 
/* 3633 */             1, 
/* 3634 */             1, 
/* 3635 */             ConstantPool.JavaLangShortConstantPoolName, 
/* 3636 */             ConstantPool.SHORTVALUE_SHORT_METHOD_NAME, 
/* 3637 */             ConstantPool.SHORTVALUE_SHORT_METHOD_SIGNATURE, 
/* 3638 */             baseTypeID, 
/* 3639 */             TypeBinding.wellKnownBaseType(baseTypeID));
/*      */         break;
/*      */       
/*      */       case 2:
/* 3643 */         invoke((byte)
/* 3644 */             -74, 
/* 3645 */             1, 
/* 3646 */             1, 
/* 3647 */             ConstantPool.JavaLangCharacterConstantPoolName, 
/* 3648 */             ConstantPool.CHARVALUE_CHARACTER_METHOD_NAME, 
/* 3649 */             ConstantPool.CHARVALUE_CHARACTER_METHOD_SIGNATURE, 
/* 3650 */             baseTypeID, 
/* 3651 */             TypeBinding.wellKnownBaseType(baseTypeID));
/*      */         break;
/*      */       
/*      */       case 10:
/* 3655 */         invoke((byte)
/* 3656 */             -74, 
/* 3657 */             1, 
/* 3658 */             1, 
/* 3659 */             ConstantPool.JavaLangIntegerConstantPoolName, 
/* 3660 */             ConstantPool.INTVALUE_INTEGER_METHOD_NAME, 
/* 3661 */             ConstantPool.INTVALUE_INTEGER_METHOD_SIGNATURE, 
/* 3662 */             baseTypeID, 
/* 3663 */             TypeBinding.wellKnownBaseType(baseTypeID));
/*      */         break;
/*      */       
/*      */       case 7:
/* 3667 */         invoke((byte)
/* 3668 */             -74, 
/* 3669 */             1, 
/* 3670 */             2, 
/* 3671 */             ConstantPool.JavaLangLongConstantPoolName, 
/* 3672 */             ConstantPool.LONGVALUE_LONG_METHOD_NAME, 
/* 3673 */             ConstantPool.LONGVALUE_LONG_METHOD_SIGNATURE, 
/* 3674 */             baseTypeID, 
/* 3675 */             TypeBinding.wellKnownBaseType(baseTypeID));
/*      */         break;
/*      */       
/*      */       case 9:
/* 3679 */         invoke((byte)
/* 3680 */             -74, 
/* 3681 */             1, 
/* 3682 */             1, 
/* 3683 */             ConstantPool.JavaLangFloatConstantPoolName, 
/* 3684 */             ConstantPool.FLOATVALUE_FLOAT_METHOD_NAME, 
/* 3685 */             ConstantPool.FLOATVALUE_FLOAT_METHOD_SIGNATURE, 
/* 3686 */             baseTypeID, 
/* 3687 */             TypeBinding.wellKnownBaseType(baseTypeID));
/*      */         break;
/*      */       
/*      */       case 8:
/* 3691 */         invoke((byte)
/* 3692 */             -74, 
/* 3693 */             1, 
/* 3694 */             2, 
/* 3695 */             ConstantPool.JavaLangDoubleConstantPoolName, 
/* 3696 */             ConstantPool.DOUBLEVALUE_DOUBLE_METHOD_NAME, 
/* 3697 */             ConstantPool.DOUBLEVALUE_DOUBLE_METHOD_SIGNATURE, 
/* 3698 */             baseTypeID, 
/* 3699 */             TypeBinding.wellKnownBaseType(baseTypeID));
/*      */         break;
/*      */       
/*      */       case 5:
/* 3703 */         invoke((byte)
/* 3704 */             -74, 
/* 3705 */             1, 
/* 3706 */             1, 
/* 3707 */             ConstantPool.JavaLangBooleanConstantPoolName, 
/* 3708 */             ConstantPool.BOOLEANVALUE_BOOLEAN_METHOD_NAME, 
/* 3709 */             ConstantPool.BOOLEANVALUE_BOOLEAN_METHOD_SIGNATURE, 
/* 3710 */             baseTypeID, 
/* 3711 */             TypeBinding.wellKnownBaseType(baseTypeID));
/*      */         break;
/*      */     } 
/*      */   }
/*      */   public final byte[] getContents() {
/*      */     byte[] contents;
/* 3717 */     System.arraycopy(this.bCodeStream, 0, contents = new byte[this.position], 0, this.position);
/* 3718 */     return contents;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static TypeBinding getConstantPoolDeclaringClass(Scope currentScope, FieldBinding codegenBinding, TypeBinding actualReceiverType, boolean isImplicitThisReceiver) {
/* 3730 */     ReferenceBinding constantPoolDeclaringClass = codegenBinding.declaringClass;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 3735 */     if (TypeBinding.notEquals((TypeBinding)constantPoolDeclaringClass, actualReceiverType.erasure()) && 
/* 3736 */       !actualReceiverType.isArrayType() && 
/* 3737 */       constantPoolDeclaringClass != null && 
/* 3738 */       codegenBinding.constant() == Constant.NotAConstant) {
/* 3739 */       CompilerOptions options = currentScope.compilerOptions();
/* 3740 */       if ((options.targetJDK >= 3014656L && (
/* 3741 */         options.complianceLevel >= 3145728L || !isImplicitThisReceiver || !codegenBinding.isStatic()) && 
/* 3742 */         constantPoolDeclaringClass.id != 1) || 
/* 3743 */         !constantPoolDeclaringClass.canBeSeenBy(currentScope))
/*      */       {
/* 3745 */         return actualReceiverType.erasure();
/*      */       }
/*      */     } 
/* 3748 */     return (TypeBinding)constantPoolDeclaringClass;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static TypeBinding getConstantPoolDeclaringClass(Scope currentScope, MethodBinding codegenBinding, TypeBinding actualReceiverType, boolean isImplicitThisReceiver) {
/*      */     TypeBinding typeBinding;
/* 3760 */     ReferenceBinding referenceBinding = codegenBinding.declaringClass;
/*      */ 
/*      */     
/* 3763 */     if (ArrayBinding.isArrayClone(actualReceiverType, codegenBinding)) {
/* 3764 */       CompilerOptions options = currentScope.compilerOptions();
/* 3765 */       if (options.sourceLevel > 3145728L) {
/* 3766 */         typeBinding = actualReceiverType.erasure();
/*      */ 
/*      */       
/*      */       }
/*      */ 
/*      */     
/*      */     }
/* 3773 */     else if (TypeBinding.notEquals(typeBinding, actualReceiverType.erasure()) && !actualReceiverType.isArrayType()) {
/* 3774 */       CompilerOptions options = currentScope.compilerOptions();
/*      */       
/* 3776 */       if ((options.targetJDK >= 3014656L && (
/* 3777 */         options.complianceLevel >= 3145728L || !isImplicitThisReceiver || !codegenBinding.isStatic()) && 
/* 3778 */         codegenBinding.declaringClass.id != 1) || 
/* 3779 */         !codegenBinding.declaringClass.canBeSeenBy(currentScope)) {
/* 3780 */         TypeBinding erasedReceiverType = actualReceiverType.erasure();
/* 3781 */         if (erasedReceiverType.isIntersectionType18()) {
/* 3782 */           actualReceiverType = erasedReceiverType;
/*      */         }
/* 3784 */         if (actualReceiverType.isIntersectionType18()) {
/* 3785 */           ReferenceBinding[] arrayOfReferenceBinding = ((IntersectionTypeBinding18)actualReceiverType).getIntersectingTypes();
/* 3786 */           for (int i = 0; i < arrayOfReferenceBinding.length; i++) {
/* 3787 */             if (arrayOfReferenceBinding[i].findSuperTypeOriginatingFrom(typeBinding) != null) {
/* 3788 */               typeBinding = arrayOfReferenceBinding[i].erasure();
/*      */               break;
/*      */             } 
/*      */           } 
/*      */         } else {
/* 3793 */           typeBinding = erasedReceiverType;
/*      */         } 
/*      */       } 
/*      */     } 
/*      */     
/* 3798 */     return typeBinding;
/*      */   }
/*      */   protected int getPosition() {
/* 3801 */     return this.position;
/*      */   }
/*      */   
/*      */   public void getTYPE(int baseTypeID) {
/* 3805 */     this.countLabels = 0;
/* 3806 */     switch (baseTypeID) {
/*      */       
/*      */       case 3:
/* 3809 */         fieldAccess((byte)
/* 3810 */             -78, 
/* 3811 */             1, 
/* 3812 */             ConstantPool.JavaLangByteConstantPoolName, 
/* 3813 */             ConstantPool.TYPE, 
/* 3814 */             ConstantPool.JavaLangClassSignature, 
/* 3815 */             baseTypeID);
/*      */         break;
/*      */       
/*      */       case 4:
/* 3819 */         fieldAccess((byte)
/* 3820 */             -78, 
/* 3821 */             1, 
/* 3822 */             ConstantPool.JavaLangShortConstantPoolName, 
/* 3823 */             ConstantPool.TYPE, 
/* 3824 */             ConstantPool.JavaLangClassSignature, 
/* 3825 */             baseTypeID);
/*      */         break;
/*      */       
/*      */       case 2:
/* 3829 */         fieldAccess((byte)
/* 3830 */             -78, 
/* 3831 */             1, 
/* 3832 */             ConstantPool.JavaLangCharacterConstantPoolName, 
/* 3833 */             ConstantPool.TYPE, 
/* 3834 */             ConstantPool.JavaLangClassSignature, 
/* 3835 */             baseTypeID);
/*      */         break;
/*      */       
/*      */       case 10:
/* 3839 */         fieldAccess((byte)
/* 3840 */             -78, 
/* 3841 */             1, 
/* 3842 */             ConstantPool.JavaLangIntegerConstantPoolName, 
/* 3843 */             ConstantPool.TYPE, 
/* 3844 */             ConstantPool.JavaLangClassSignature, 
/* 3845 */             baseTypeID);
/*      */         break;
/*      */       
/*      */       case 7:
/* 3849 */         fieldAccess((byte)
/* 3850 */             -78, 
/* 3851 */             1, 
/* 3852 */             ConstantPool.JavaLangLongConstantPoolName, 
/* 3853 */             ConstantPool.TYPE, 
/* 3854 */             ConstantPool.JavaLangClassSignature, 
/* 3855 */             baseTypeID);
/*      */         break;
/*      */       
/*      */       case 9:
/* 3859 */         fieldAccess((byte)
/* 3860 */             -78, 
/* 3861 */             1, 
/* 3862 */             ConstantPool.JavaLangFloatConstantPoolName, 
/* 3863 */             ConstantPool.TYPE, 
/* 3864 */             ConstantPool.JavaLangClassSignature, 
/* 3865 */             baseTypeID);
/*      */         break;
/*      */       
/*      */       case 8:
/* 3869 */         fieldAccess((byte)
/* 3870 */             -78, 
/* 3871 */             1, 
/* 3872 */             ConstantPool.JavaLangDoubleConstantPoolName, 
/* 3873 */             ConstantPool.TYPE, 
/* 3874 */             ConstantPool.JavaLangClassSignature, 
/* 3875 */             baseTypeID);
/*      */         break;
/*      */       
/*      */       case 5:
/* 3879 */         fieldAccess((byte)
/* 3880 */             -78, 
/* 3881 */             1, 
/* 3882 */             ConstantPool.JavaLangBooleanConstantPoolName, 
/* 3883 */             ConstantPool.TYPE, 
/* 3884 */             ConstantPool.JavaLangClassSignature, 
/* 3885 */             baseTypeID);
/*      */         break;
/*      */       
/*      */       case 6:
/* 3889 */         fieldAccess((byte)
/* 3890 */             -78, 
/* 3891 */             1, 
/* 3892 */             ConstantPool.JavaLangVoidConstantPoolName, 
/* 3893 */             ConstantPool.TYPE, 
/* 3894 */             ConstantPool.JavaLangClassSignature, 
/* 3895 */             baseTypeID);
/*      */         break;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void goto_(BranchLabel label) {
/* 3904 */     if (this.wideMode) {
/* 3905 */       goto_w(label);
/*      */       return;
/*      */     } 
/* 3908 */     if (this.classFileOffset >= this.bCodeStream.length) {
/* 3909 */       resizeByteArray();
/*      */     }
/* 3911 */     boolean chained = inlineForwardReferencesFromLabelsTargeting(label, this.position);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 3930 */     if (chained && this.lastAbruptCompletion == this.position) {
/* 3931 */       if (label.position != -1) {
/* 3932 */         int[] forwardRefs = label.forwardReferences();
/* 3933 */         for (int i = 0, max = label.forwardReferenceCount(); i < max; i++) {
/* 3934 */           writePosition(label, forwardRefs[i]);
/*      */         }
/* 3936 */         this.countLabels = 0;
/*      */       } 
/*      */       return;
/*      */     } 
/* 3940 */     this.position++;
/* 3941 */     this.bCodeStream[this.classFileOffset++] = -89;
/* 3942 */     label.branch();
/* 3943 */     this.lastAbruptCompletion = this.position;
/*      */   }
/*      */   
/*      */   public void goto_w(BranchLabel label) {
/* 3947 */     if (this.classFileOffset >= this.bCodeStream.length) {
/* 3948 */       resizeByteArray();
/*      */     }
/* 3950 */     this.position++;
/* 3951 */     this.bCodeStream[this.classFileOffset++] = -56;
/* 3952 */     label.branchWide();
/* 3953 */     this.lastAbruptCompletion = this.position;
/*      */   }
/*      */   
/*      */   public void i2b() {
/* 3957 */     this.countLabels = 0;
/* 3958 */     if (this.classFileOffset >= this.bCodeStream.length) {
/* 3959 */       resizeByteArray();
/*      */     }
/* 3961 */     this.position++;
/* 3962 */     this.bCodeStream[this.classFileOffset++] = -111;
/* 3963 */     pushTypeBinding(1, (TypeBinding)TypeBinding.INT);
/*      */   }
/*      */   
/*      */   public void i2c() {
/* 3967 */     this.countLabels = 0;
/* 3968 */     if (this.classFileOffset >= this.bCodeStream.length) {
/* 3969 */       resizeByteArray();
/*      */     }
/* 3971 */     this.position++;
/* 3972 */     this.bCodeStream[this.classFileOffset++] = -110;
/* 3973 */     pushTypeBinding(1, (TypeBinding)TypeBinding.INT);
/*      */   }
/*      */   
/*      */   public void i2d() {
/* 3977 */     this.countLabels = 0;
/* 3978 */     this.stackDepth++;
/* 3979 */     pushTypeBinding(1, (TypeBinding)TypeBinding.INT);
/* 3980 */     if (this.stackDepth > this.stackMax)
/* 3981 */       this.stackMax = this.stackDepth; 
/* 3982 */     if (this.classFileOffset >= this.bCodeStream.length) {
/* 3983 */       resizeByteArray();
/*      */     }
/* 3985 */     this.position++;
/* 3986 */     this.bCodeStream[this.classFileOffset++] = -121;
/*      */   }
/*      */   
/*      */   public void i2f() {
/* 3990 */     this.countLabels = 0;
/* 3991 */     if (this.classFileOffset >= this.bCodeStream.length) {
/* 3992 */       resizeByteArray();
/*      */     }
/* 3994 */     this.position++;
/* 3995 */     this.bCodeStream[this.classFileOffset++] = -122;
/* 3996 */     pushTypeBinding(1, (TypeBinding)TypeBinding.FLOAT);
/*      */   }
/*      */   
/*      */   public void i2l() {
/* 4000 */     this.countLabels = 0;
/* 4001 */     this.stackDepth++;
/* 4002 */     pushTypeBinding(1, (TypeBinding)TypeBinding.LONG);
/* 4003 */     if (this.stackDepth > this.stackMax)
/* 4004 */       this.stackMax = this.stackDepth; 
/* 4005 */     if (this.classFileOffset >= this.bCodeStream.length) {
/* 4006 */       resizeByteArray();
/*      */     }
/* 4008 */     this.position++;
/* 4009 */     this.bCodeStream[this.classFileOffset++] = -123;
/*      */   }
/*      */   
/*      */   public void i2s() {
/* 4013 */     this.countLabels = 0;
/* 4014 */     if (this.classFileOffset >= this.bCodeStream.length) {
/* 4015 */       resizeByteArray();
/*      */     }
/* 4017 */     this.position++;
/* 4018 */     this.bCodeStream[this.classFileOffset++] = -109;
/* 4019 */     pushTypeBinding(1, (TypeBinding)TypeBinding.INT);
/*      */   }
/*      */   
/*      */   public void iadd() {
/* 4023 */     this.countLabels = 0;
/* 4024 */     this.stackDepth--;
/* 4025 */     pushTypeBinding(2, (TypeBinding)TypeBinding.INT);
/* 4026 */     if (this.classFileOffset >= this.bCodeStream.length) {
/* 4027 */       resizeByteArray();
/*      */     }
/* 4029 */     this.position++;
/* 4030 */     this.bCodeStream[this.classFileOffset++] = 96;
/*      */   }
/*      */   
/*      */   public void iaload() {
/* 4034 */     this.countLabels = 0;
/* 4035 */     this.stackDepth--;
/* 4036 */     pushTypeBindingArray();
/* 4037 */     if (this.classFileOffset >= this.bCodeStream.length) {
/* 4038 */       resizeByteArray();
/*      */     }
/* 4040 */     this.position++;
/* 4041 */     this.bCodeStream[this.classFileOffset++] = 46;
/*      */   }
/*      */   
/*      */   public void iand() {
/* 4045 */     this.countLabels = 0;
/* 4046 */     this.stackDepth--;
/* 4047 */     pushTypeBinding(2, (TypeBinding)TypeBinding.INT);
/* 4048 */     if (this.classFileOffset >= this.bCodeStream.length) {
/* 4049 */       resizeByteArray();
/*      */     }
/* 4051 */     this.position++;
/* 4052 */     this.bCodeStream[this.classFileOffset++] = 126;
/*      */   }
/*      */   
/*      */   public void iastore() {
/* 4056 */     this.countLabels = 0;
/* 4057 */     this.stackDepth -= 3;
/* 4058 */     popTypeBinding(3);
/* 4059 */     if (this.classFileOffset >= this.bCodeStream.length) {
/* 4060 */       resizeByteArray();
/*      */     }
/* 4062 */     this.position++;
/* 4063 */     this.bCodeStream[this.classFileOffset++] = 79;
/*      */   }
/*      */   
/*      */   public void iconst_0() {
/* 4067 */     this.countLabels = 0;
/* 4068 */     this.stackDepth++;
/* 4069 */     pushTypeBinding((TypeBinding)TypeBinding.INT);
/* 4070 */     if (this.stackDepth > this.stackMax)
/* 4071 */       this.stackMax = this.stackDepth; 
/* 4072 */     if (this.classFileOffset >= this.bCodeStream.length) {
/* 4073 */       resizeByteArray();
/*      */     }
/* 4075 */     this.position++;
/* 4076 */     this.bCodeStream[this.classFileOffset++] = 3;
/*      */   }
/*      */   
/*      */   public void iconst_1() {
/* 4080 */     this.countLabels = 0;
/* 4081 */     this.stackDepth++;
/* 4082 */     pushTypeBinding((TypeBinding)TypeBinding.INT);
/* 4083 */     if (this.stackDepth > this.stackMax)
/* 4084 */       this.stackMax = this.stackDepth; 
/* 4085 */     if (this.classFileOffset >= this.bCodeStream.length) {
/* 4086 */       resizeByteArray();
/*      */     }
/* 4088 */     this.position++;
/* 4089 */     this.bCodeStream[this.classFileOffset++] = 4;
/*      */   }
/*      */   
/*      */   public void iconst_2() {
/* 4093 */     this.countLabels = 0;
/* 4094 */     this.stackDepth++;
/* 4095 */     pushTypeBinding((TypeBinding)TypeBinding.INT);
/* 4096 */     if (this.stackDepth > this.stackMax)
/* 4097 */       this.stackMax = this.stackDepth; 
/* 4098 */     if (this.classFileOffset >= this.bCodeStream.length) {
/* 4099 */       resizeByteArray();
/*      */     }
/* 4101 */     this.position++;
/* 4102 */     this.bCodeStream[this.classFileOffset++] = 5;
/*      */   }
/*      */   public void iconst_3() {
/* 4105 */     this.countLabels = 0;
/* 4106 */     this.stackDepth++;
/* 4107 */     pushTypeBinding((TypeBinding)TypeBinding.INT);
/* 4108 */     if (this.stackDepth > this.stackMax)
/* 4109 */       this.stackMax = this.stackDepth; 
/* 4110 */     if (this.classFileOffset >= this.bCodeStream.length) {
/* 4111 */       resizeByteArray();
/*      */     }
/* 4113 */     this.position++;
/* 4114 */     this.bCodeStream[this.classFileOffset++] = 6;
/*      */   }
/*      */   
/*      */   public void iconst_4() {
/* 4118 */     this.countLabels = 0;
/* 4119 */     this.stackDepth++;
/* 4120 */     pushTypeBinding((TypeBinding)TypeBinding.INT);
/* 4121 */     if (this.stackDepth > this.stackMax)
/* 4122 */       this.stackMax = this.stackDepth; 
/* 4123 */     if (this.classFileOffset >= this.bCodeStream.length) {
/* 4124 */       resizeByteArray();
/*      */     }
/* 4126 */     this.position++;
/* 4127 */     this.bCodeStream[this.classFileOffset++] = 7;
/*      */   }
/*      */   
/*      */   public void iconst_5() {
/* 4131 */     this.countLabels = 0;
/* 4132 */     this.stackDepth++;
/* 4133 */     pushTypeBinding((TypeBinding)TypeBinding.INT);
/* 4134 */     if (this.stackDepth > this.stackMax)
/* 4135 */       this.stackMax = this.stackDepth; 
/* 4136 */     if (this.classFileOffset >= this.bCodeStream.length) {
/* 4137 */       resizeByteArray();
/*      */     }
/* 4139 */     this.position++;
/* 4140 */     this.bCodeStream[this.classFileOffset++] = 8;
/*      */   }
/*      */   
/*      */   public void iconst_m1() {
/* 4144 */     this.countLabels = 0;
/* 4145 */     this.stackDepth++;
/* 4146 */     pushTypeBinding((TypeBinding)TypeBinding.INT);
/* 4147 */     if (this.stackDepth > this.stackMax)
/* 4148 */       this.stackMax = this.stackDepth; 
/* 4149 */     if (this.classFileOffset >= this.bCodeStream.length) {
/* 4150 */       resizeByteArray();
/*      */     }
/* 4152 */     this.position++;
/* 4153 */     this.bCodeStream[this.classFileOffset++] = 2;
/*      */   }
/*      */   
/*      */   public void idiv() {
/* 4157 */     this.countLabels = 0;
/* 4158 */     this.stackDepth--;
/* 4159 */     pushTypeBinding(2, (TypeBinding)TypeBinding.INT);
/* 4160 */     if (this.classFileOffset >= this.bCodeStream.length) {
/* 4161 */       resizeByteArray();
/*      */     }
/* 4163 */     this.position++;
/* 4164 */     this.bCodeStream[this.classFileOffset++] = 108;
/*      */   }
/*      */   
/*      */   public void if_acmpeq(BranchLabel lbl) {
/* 4168 */     this.countLabels = 0;
/* 4169 */     this.stackDepth -= 2;
/* 4170 */     popTypeBinding(2);
/* 4171 */     if (this.wideMode) {
/* 4172 */       generateWideRevertedConditionalBranch((byte)-90, lbl);
/*      */     } else {
/* 4174 */       if (this.classFileOffset >= this.bCodeStream.length) {
/* 4175 */         resizeByteArray();
/*      */       }
/* 4177 */       this.position++;
/* 4178 */       this.bCodeStream[this.classFileOffset++] = -91;
/* 4179 */       lbl.branch();
/*      */     } 
/*      */   }
/*      */   
/*      */   public void if_acmpne(BranchLabel lbl) {
/* 4184 */     this.countLabels = 0;
/* 4185 */     this.stackDepth -= 2;
/* 4186 */     popTypeBinding(2);
/* 4187 */     if (this.wideMode) {
/* 4188 */       generateWideRevertedConditionalBranch((byte)-91, lbl);
/*      */     } else {
/* 4190 */       if (this.classFileOffset >= this.bCodeStream.length) {
/* 4191 */         resizeByteArray();
/*      */       }
/* 4193 */       this.position++;
/* 4194 */       this.bCodeStream[this.classFileOffset++] = -90;
/* 4195 */       lbl.branch();
/*      */     } 
/*      */   }
/*      */   
/*      */   public void if_icmpeq(BranchLabel lbl) {
/* 4200 */     this.countLabels = 0;
/* 4201 */     this.stackDepth -= 2;
/* 4202 */     popTypeBinding(2);
/* 4203 */     if (this.wideMode) {
/* 4204 */       generateWideRevertedConditionalBranch((byte)-96, lbl);
/*      */     } else {
/* 4206 */       if (this.classFileOffset >= this.bCodeStream.length) {
/* 4207 */         resizeByteArray();
/*      */       }
/* 4209 */       this.position++;
/* 4210 */       this.bCodeStream[this.classFileOffset++] = -97;
/* 4211 */       lbl.branch();
/*      */     } 
/*      */   }
/*      */   
/*      */   public void if_icmpge(BranchLabel lbl) {
/* 4216 */     this.countLabels = 0;
/* 4217 */     this.stackDepth -= 2;
/* 4218 */     popTypeBinding(2);
/* 4219 */     if (this.wideMode) {
/* 4220 */       generateWideRevertedConditionalBranch((byte)-95, lbl);
/*      */     } else {
/* 4222 */       if (this.classFileOffset >= this.bCodeStream.length) {
/* 4223 */         resizeByteArray();
/*      */       }
/* 4225 */       this.position++;
/* 4226 */       this.bCodeStream[this.classFileOffset++] = -94;
/* 4227 */       lbl.branch();
/*      */     } 
/*      */   }
/*      */   
/*      */   public void if_icmpgt(BranchLabel lbl) {
/* 4232 */     this.countLabels = 0;
/* 4233 */     this.stackDepth -= 2;
/* 4234 */     popTypeBinding(2);
/* 4235 */     if (this.wideMode) {
/* 4236 */       generateWideRevertedConditionalBranch((byte)-92, lbl);
/*      */     } else {
/* 4238 */       if (this.classFileOffset >= this.bCodeStream.length) {
/* 4239 */         resizeByteArray();
/*      */       }
/* 4241 */       this.position++;
/* 4242 */       this.bCodeStream[this.classFileOffset++] = -93;
/* 4243 */       lbl.branch();
/*      */     } 
/*      */   }
/*      */   
/*      */   public void if_icmple(BranchLabel lbl) {
/* 4248 */     this.countLabels = 0;
/* 4249 */     this.stackDepth -= 2;
/* 4250 */     popTypeBinding(2);
/* 4251 */     if (this.wideMode) {
/* 4252 */       generateWideRevertedConditionalBranch((byte)-93, lbl);
/*      */     } else {
/* 4254 */       if (this.classFileOffset >= this.bCodeStream.length) {
/* 4255 */         resizeByteArray();
/*      */       }
/* 4257 */       this.position++;
/* 4258 */       this.bCodeStream[this.classFileOffset++] = -92;
/* 4259 */       lbl.branch();
/*      */     } 
/*      */   }
/*      */   
/*      */   public void if_icmplt(BranchLabel lbl) {
/* 4264 */     this.countLabels = 0;
/* 4265 */     this.stackDepth -= 2;
/* 4266 */     popTypeBinding(2);
/* 4267 */     if (this.wideMode) {
/* 4268 */       generateWideRevertedConditionalBranch((byte)-94, lbl);
/*      */     } else {
/* 4270 */       if (this.classFileOffset >= this.bCodeStream.length) {
/* 4271 */         resizeByteArray();
/*      */       }
/* 4273 */       this.position++;
/* 4274 */       this.bCodeStream[this.classFileOffset++] = -95;
/* 4275 */       lbl.branch();
/*      */     } 
/*      */   }
/*      */   
/*      */   public void if_icmpne(BranchLabel lbl) {
/* 4280 */     this.countLabels = 0;
/* 4281 */     this.stackDepth -= 2;
/* 4282 */     popTypeBinding(2);
/* 4283 */     if (this.wideMode) {
/* 4284 */       generateWideRevertedConditionalBranch((byte)-97, lbl);
/*      */     } else {
/* 4286 */       if (this.classFileOffset >= this.bCodeStream.length) {
/* 4287 */         resizeByteArray();
/*      */       }
/* 4289 */       this.position++;
/* 4290 */       this.bCodeStream[this.classFileOffset++] = -96;
/* 4291 */       lbl.branch();
/*      */     } 
/*      */   }
/*      */   
/*      */   public void ifeq(BranchLabel lbl) {
/* 4296 */     this.countLabels = 0;
/* 4297 */     this.stackDepth--;
/* 4298 */     popTypeBinding();
/* 4299 */     if (this.wideMode) {
/* 4300 */       generateWideRevertedConditionalBranch((byte)-102, lbl);
/*      */     } else {
/* 4302 */       if (this.classFileOffset >= this.bCodeStream.length) {
/* 4303 */         resizeByteArray();
/*      */       }
/* 4305 */       this.position++;
/* 4306 */       this.bCodeStream[this.classFileOffset++] = -103;
/* 4307 */       lbl.branch();
/*      */     } 
/*      */   }
/*      */   
/*      */   public void ifge(BranchLabel lbl) {
/* 4312 */     this.countLabels = 0;
/* 4313 */     this.stackDepth--;
/* 4314 */     popTypeBinding();
/* 4315 */     if (this.wideMode) {
/* 4316 */       generateWideRevertedConditionalBranch((byte)-101, lbl);
/*      */     } else {
/* 4318 */       if (this.classFileOffset >= this.bCodeStream.length) {
/* 4319 */         resizeByteArray();
/*      */       }
/* 4321 */       this.position++;
/* 4322 */       this.bCodeStream[this.classFileOffset++] = -100;
/* 4323 */       lbl.branch();
/*      */     } 
/*      */   }
/*      */   
/*      */   public void ifgt(BranchLabel lbl) {
/* 4328 */     this.countLabels = 0;
/* 4329 */     this.stackDepth--;
/* 4330 */     popTypeBinding();
/* 4331 */     if (this.wideMode) {
/* 4332 */       generateWideRevertedConditionalBranch((byte)-98, lbl);
/*      */     } else {
/* 4334 */       if (this.classFileOffset >= this.bCodeStream.length) {
/* 4335 */         resizeByteArray();
/*      */       }
/* 4337 */       this.position++;
/* 4338 */       this.bCodeStream[this.classFileOffset++] = -99;
/* 4339 */       lbl.branch();
/*      */     } 
/*      */   }
/*      */   
/*      */   public void ifle(BranchLabel lbl) {
/* 4344 */     this.countLabels = 0;
/* 4345 */     this.stackDepth--;
/* 4346 */     popTypeBinding();
/* 4347 */     if (this.wideMode) {
/* 4348 */       generateWideRevertedConditionalBranch((byte)-99, lbl);
/*      */     } else {
/* 4350 */       if (this.classFileOffset >= this.bCodeStream.length) {
/* 4351 */         resizeByteArray();
/*      */       }
/* 4353 */       this.position++;
/* 4354 */       this.bCodeStream[this.classFileOffset++] = -98;
/* 4355 */       lbl.branch();
/*      */     } 
/*      */   }
/*      */   
/*      */   public void iflt(BranchLabel lbl) {
/* 4360 */     this.countLabels = 0;
/* 4361 */     this.stackDepth--;
/* 4362 */     popTypeBinding();
/* 4363 */     if (this.wideMode) {
/* 4364 */       generateWideRevertedConditionalBranch((byte)-100, lbl);
/*      */     } else {
/* 4366 */       if (this.classFileOffset >= this.bCodeStream.length) {
/* 4367 */         resizeByteArray();
/*      */       }
/* 4369 */       this.position++;
/* 4370 */       this.bCodeStream[this.classFileOffset++] = -101;
/* 4371 */       lbl.branch();
/*      */     } 
/*      */   }
/*      */   
/*      */   public void ifne(BranchLabel lbl) {
/* 4376 */     this.countLabels = 0;
/* 4377 */     this.stackDepth--;
/* 4378 */     popTypeBinding();
/* 4379 */     if (this.wideMode) {
/* 4380 */       generateWideRevertedConditionalBranch((byte)-103, lbl);
/*      */     } else {
/* 4382 */       if (this.classFileOffset >= this.bCodeStream.length) {
/* 4383 */         resizeByteArray();
/*      */       }
/* 4385 */       this.position++;
/* 4386 */       this.bCodeStream[this.classFileOffset++] = -102;
/* 4387 */       lbl.branch();
/*      */     } 
/*      */   }
/*      */   
/*      */   public void ifnonnull(BranchLabel lbl) {
/* 4392 */     this.countLabels = 0;
/* 4393 */     this.stackDepth--;
/* 4394 */     popTypeBinding();
/* 4395 */     if (this.wideMode) {
/* 4396 */       generateWideRevertedConditionalBranch((byte)-58, lbl);
/*      */     } else {
/* 4398 */       if (this.classFileOffset >= this.bCodeStream.length) {
/* 4399 */         resizeByteArray();
/*      */       }
/* 4401 */       this.position++;
/* 4402 */       this.bCodeStream[this.classFileOffset++] = -57;
/* 4403 */       lbl.branch();
/*      */     } 
/*      */   }
/*      */   
/*      */   public void ifnull(BranchLabel lbl) {
/* 4408 */     this.countLabels = 0;
/* 4409 */     this.stackDepth--;
/* 4410 */     popTypeBinding();
/* 4411 */     if (this.wideMode) {
/* 4412 */       generateWideRevertedConditionalBranch((byte)-57, lbl);
/*      */     } else {
/* 4414 */       if (this.classFileOffset >= this.bCodeStream.length) {
/* 4415 */         resizeByteArray();
/*      */       }
/* 4417 */       this.position++;
/* 4418 */       this.bCodeStream[this.classFileOffset++] = -58;
/* 4419 */       lbl.branch();
/*      */     } 
/*      */   }
/*      */   
/*      */   public final void iinc(int index, int value) {
/* 4424 */     this.countLabels = 0;
/* 4425 */     if (index > 255 || value < -128 || value > 127) {
/* 4426 */       if (this.classFileOffset + 3 >= this.bCodeStream.length) {
/* 4427 */         resizeByteArray();
/*      */       }
/* 4429 */       this.position += 2;
/* 4430 */       this.bCodeStream[this.classFileOffset++] = -60;
/* 4431 */       this.bCodeStream[this.classFileOffset++] = -124;
/* 4432 */       writeUnsignedShort(index);
/* 4433 */       writeSignedShort(value);
/*      */     } else {
/* 4435 */       if (this.classFileOffset + 2 >= this.bCodeStream.length) {
/* 4436 */         resizeByteArray();
/*      */       }
/* 4438 */       this.position += 3;
/* 4439 */       this.bCodeStream[this.classFileOffset++] = -124;
/* 4440 */       this.bCodeStream[this.classFileOffset++] = (byte)index;
/* 4441 */       this.bCodeStream[this.classFileOffset++] = (byte)value;
/*      */     } 
/*      */   }
/*      */   
/*      */   public void iload(int iArg) {
/* 4446 */     this.countLabels = 0;
/* 4447 */     this.stackDepth++;
/* 4448 */     if (this.maxLocals <= iArg) {
/* 4449 */       this.maxLocals = iArg + 1;
/*      */     }
/* 4451 */     pushTypeBinding((TypeBinding)TypeBinding.INT);
/* 4452 */     if (this.stackDepth > this.stackMax)
/* 4453 */       this.stackMax = this.stackDepth; 
/* 4454 */     if (iArg > 255) {
/* 4455 */       if (this.classFileOffset + 3 >= this.bCodeStream.length) {
/* 4456 */         resizeByteArray();
/*      */       }
/* 4458 */       this.position += 2;
/* 4459 */       this.bCodeStream[this.classFileOffset++] = -60;
/* 4460 */       this.bCodeStream[this.classFileOffset++] = 21;
/* 4461 */       writeUnsignedShort(iArg);
/*      */     } else {
/* 4463 */       if (this.classFileOffset + 1 >= this.bCodeStream.length) {
/* 4464 */         resizeByteArray();
/*      */       }
/* 4466 */       this.position += 2;
/* 4467 */       this.bCodeStream[this.classFileOffset++] = 21;
/* 4468 */       this.bCodeStream[this.classFileOffset++] = (byte)iArg;
/*      */     } 
/*      */   }
/*      */   
/*      */   public void iload_0() {
/* 4473 */     this.countLabels = 0;
/* 4474 */     this.stackDepth++;
/* 4475 */     pushTypeBinding((TypeBinding)TypeBinding.INT);
/* 4476 */     if (this.maxLocals <= 0) {
/* 4477 */       this.maxLocals = 1;
/*      */     }
/* 4479 */     if (this.stackDepth > this.stackMax)
/* 4480 */       this.stackMax = this.stackDepth; 
/* 4481 */     if (this.classFileOffset >= this.bCodeStream.length) {
/* 4482 */       resizeByteArray();
/*      */     }
/* 4484 */     this.position++;
/* 4485 */     this.bCodeStream[this.classFileOffset++] = 26;
/*      */   }
/*      */   
/*      */   public void iload_1() {
/* 4489 */     this.countLabels = 0;
/* 4490 */     this.stackDepth++;
/* 4491 */     pushTypeBinding((TypeBinding)TypeBinding.INT);
/* 4492 */     if (this.maxLocals <= 1) {
/* 4493 */       this.maxLocals = 2;
/*      */     }
/* 4495 */     if (this.stackDepth > this.stackMax)
/* 4496 */       this.stackMax = this.stackDepth; 
/* 4497 */     if (this.classFileOffset >= this.bCodeStream.length) {
/* 4498 */       resizeByteArray();
/*      */     }
/* 4500 */     this.position++;
/* 4501 */     this.bCodeStream[this.classFileOffset++] = 27;
/*      */   }
/*      */   
/*      */   public void iload_2() {
/* 4505 */     this.countLabels = 0;
/* 4506 */     this.stackDepth++;
/* 4507 */     pushTypeBinding((TypeBinding)TypeBinding.INT);
/* 4508 */     if (this.maxLocals <= 2) {
/* 4509 */       this.maxLocals = 3;
/*      */     }
/* 4511 */     if (this.stackDepth > this.stackMax)
/* 4512 */       this.stackMax = this.stackDepth; 
/* 4513 */     if (this.classFileOffset >= this.bCodeStream.length) {
/* 4514 */       resizeByteArray();
/*      */     }
/* 4516 */     this.position++;
/* 4517 */     this.bCodeStream[this.classFileOffset++] = 28;
/*      */   }
/*      */   
/*      */   public void iload_3() {
/* 4521 */     this.countLabels = 0;
/* 4522 */     this.stackDepth++;
/* 4523 */     pushTypeBinding((TypeBinding)TypeBinding.INT);
/* 4524 */     if (this.maxLocals <= 3) {
/* 4525 */       this.maxLocals = 4;
/*      */     }
/* 4527 */     if (this.stackDepth > this.stackMax)
/* 4528 */       this.stackMax = this.stackDepth; 
/* 4529 */     if (this.classFileOffset >= this.bCodeStream.length) {
/* 4530 */       resizeByteArray();
/*      */     }
/* 4532 */     this.position++;
/* 4533 */     this.bCodeStream[this.classFileOffset++] = 29;
/*      */   }
/*      */   
/*      */   public void imul() {
/* 4537 */     this.countLabels = 0;
/* 4538 */     this.stackDepth--;
/* 4539 */     pushTypeBinding(2, (TypeBinding)TypeBinding.INT);
/* 4540 */     if (this.classFileOffset >= this.bCodeStream.length) {
/* 4541 */       resizeByteArray();
/*      */     }
/* 4543 */     this.position++;
/* 4544 */     this.bCodeStream[this.classFileOffset++] = 104;
/*      */   }
/*      */   
/*      */   public void ineg() {
/* 4548 */     this.countLabels = 0;
/* 4549 */     if (this.classFileOffset >= this.bCodeStream.length) {
/* 4550 */       resizeByteArray();
/*      */     }
/* 4552 */     this.position++;
/* 4553 */     this.bCodeStream[this.classFileOffset++] = 116;
/* 4554 */     pushTypeBinding(1, (TypeBinding)TypeBinding.INT);
/*      */   }
/*      */   
/*      */   public void init(ClassFile targetClassFile) {
/* 4558 */     this.classFile = targetClassFile;
/* 4559 */     this.constantPool = targetClassFile.constantPool;
/* 4560 */     this.bCodeStream = targetClassFile.contents;
/* 4561 */     this.classFileOffset = targetClassFile.contentsOffset;
/* 4562 */     this.startingClassFileOffset = this.classFileOffset;
/* 4563 */     this.pcToSourceMapSize = 0;
/* 4564 */     this.lastEntryPC = 0;
/* 4565 */     this.visibleLocalsCount = 0;
/*      */     
/* 4567 */     this.allLocalsCounter = 0;
/*      */     
/* 4569 */     this.exceptionLabelsCounter = 0;
/*      */     
/* 4571 */     this.countLabels = 0;
/* 4572 */     this.lastAbruptCompletion = -1;
/*      */     
/* 4574 */     this.stackMax = 0;
/* 4575 */     this.stackDepth = 0;
/* 4576 */     this.maxLocals = 0;
/* 4577 */     this.position = 0;
/*      */     
/* 4579 */     clearTypeBindingStack();
/* 4580 */     this.lastSwitchCumulativeSyntheticVars = 0;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void initializeMaxLocals(MethodBinding methodBinding) {
/* 4587 */     if (methodBinding == null) {
/* 4588 */       this.maxLocals = 0;
/*      */       return;
/*      */     } 
/* 4591 */     this.maxLocals = methodBinding.isStatic() ? 0 : 1;
/* 4592 */     ReferenceBinding declaringClass = methodBinding.declaringClass;
/*      */     
/* 4594 */     if (methodBinding.isConstructor() && declaringClass.isEnum()) {
/* 4595 */       this.maxLocals += 2;
/*      */     }
/*      */ 
/*      */     
/* 4599 */     if (methodBinding.isConstructor() && declaringClass.isNestedType()) {
/* 4600 */       this.maxLocals += declaringClass.getEnclosingInstancesSlotSize();
/* 4601 */       this.maxLocals += declaringClass.getOuterLocalVariablesSlotSize();
/*      */     } 
/*      */     TypeBinding[] parameterTypes;
/* 4604 */     if ((parameterTypes = methodBinding.parameters) != null) {
/* 4605 */       for (int i = 0, max = parameterTypes.length; i < max; i++) {
/* 4606 */         switch ((parameterTypes[i]).id) {
/*      */           case 7:
/*      */           case 8:
/* 4609 */             this.maxLocals += 2;
/*      */             break;
/*      */           default:
/* 4612 */             this.maxLocals++;
/*      */             break;
/*      */         } 
/*      */       } 
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean inlineForwardReferencesFromLabelsTargeting(BranchLabel targetLabel, int gotoLocation) {
/* 4622 */     if (targetLabel.delegate != null) return false; 
/* 4623 */     int chaining = 0;
/* 4624 */     for (int i = this.countLabels - 1; i >= 0; i--) {
/* 4625 */       BranchLabel currentLabel = this.labels[i];
/* 4626 */       if (currentLabel.position != gotoLocation)
/* 4627 */         break;  if (currentLabel == targetLabel) {
/* 4628 */         chaining |= 0x4;
/*      */       
/*      */       }
/* 4631 */       else if (currentLabel.isStandardLabel()) {
/* 4632 */         if (currentLabel.delegate == null) {
/* 4633 */           targetLabel.becomeDelegateFor(currentLabel);
/* 4634 */           chaining |= 0x2;
/*      */         } 
/*      */       } else {
/*      */         
/* 4638 */         chaining |= 0x4;
/*      */       } 
/* 4640 */     }  return ((chaining & 0x6) == 2);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void instance_of(TypeBinding typeBinding) {
/* 4648 */     instance_of(null, typeBinding);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void instance_of(TypeReference typeReference, TypeBinding typeBinding) {
/* 4656 */     this.countLabels = 0;
/* 4657 */     if (this.classFileOffset + 2 >= this.bCodeStream.length) {
/* 4658 */       resizeByteArray();
/*      */     }
/* 4660 */     this.position++;
/* 4661 */     this.bCodeStream[this.classFileOffset++] = -63;
/* 4662 */     writeUnsignedShort(this.constantPool.literalIndexForType(typeBinding));
/* 4663 */     pushTypeBinding(1, (TypeBinding)TypeBinding.INT);
/*      */   }
/*      */   
/*      */   protected void invoke(byte opcode, int receiverAndArgsSize, int returnTypeSize, char[] declaringClass, char[] selector, char[] signature, TypeBinding type) {
/* 4667 */     invoke(opcode, receiverAndArgsSize, returnTypeSize, declaringClass, selector, signature, 1, type);
/*      */   }
/*      */   
/*      */   protected void _invoke(byte opcode, int receiverAndArgsSize, int returnTypeSize, char[] declaringClass, char[] selector, char[] signature, int typeId) {}
/*      */   
/*      */   protected void invoke(byte opcode, int receiverAndArgsSize, int returnTypeSize, char[] declaringClass, char[] selector, char[] signature, int typeId, TypeBinding type) {
/* 4673 */     invoke18(opcode, receiverAndArgsSize, returnTypeSize, declaringClass, (opcode == -71), selector, signature, typeId, type);
/*      */   }
/*      */   
/*      */   private void popInvokeTypeBinding(int receiverAndArgsSize) {
/* 4677 */     if (!isSwitchStackTrackingActive())
/*      */       return; 
/* 4679 */     for (int i = 0; i < receiverAndArgsSize; ) {
/* 4680 */       TypeBinding typeBinding = popTypeBinding();
/*      */       
/* 4682 */       if (TypeIds.getCategory(typeBinding.id) == 2) {
/* 4683 */         i += 2; continue;
/*      */       } 
/* 4685 */       i++;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void invoke18(byte opcode, int receiverAndArgsSize, int returnTypeSize, char[] declaringClass, boolean isInterface, char[] selector, char[] signature, int typeId, TypeBinding type) {
/* 4695 */     this.countLabels = 0;
/* 4696 */     if (opcode == -71) {
/*      */       
/* 4698 */       if (this.classFileOffset + 4 >= this.bCodeStream.length) {
/* 4699 */         resizeByteArray();
/*      */       }
/* 4701 */       this.position += 3;
/* 4702 */       this.bCodeStream[this.classFileOffset++] = opcode;
/* 4703 */       writeUnsignedShort(this.constantPool.literalIndexForMethod(declaringClass, selector, signature, true));
/* 4704 */       this.bCodeStream[this.classFileOffset++] = (byte)receiverAndArgsSize;
/* 4705 */       this.bCodeStream[this.classFileOffset++] = 0;
/*      */     
/*      */     }
/*      */     else {
/*      */       
/* 4710 */       if (this.classFileOffset + 2 >= this.bCodeStream.length) {
/* 4711 */         resizeByteArray();
/*      */       }
/* 4713 */       this.position++;
/* 4714 */       this.bCodeStream[this.classFileOffset++] = opcode;
/* 4715 */       writeUnsignedShort(this.constantPool.literalIndexForMethod(declaringClass, selector, signature, isInterface));
/*      */     } 
/* 4717 */     this.stackDepth += returnTypeSize - receiverAndArgsSize;
/* 4718 */     popInvokeTypeBinding(receiverAndArgsSize);
/* 4719 */     if (returnTypeSize > 0) {
/* 4720 */       pushTypeBinding(type);
/*      */     }
/* 4722 */     if (this.stackDepth > this.stackMax) {
/* 4723 */       this.stackMax = this.stackDepth;
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   public void invokeDynamic(int bootStrapIndex, int argsSize, int returnTypeSize, char[] selector, char[] signature, int typeId, TypeBinding type) {
/* 4729 */     invokeDynamic(bootStrapIndex, argsSize, returnTypeSize, selector, signature, false, null, null, typeId, type);
/*      */   }
/*      */ 
/*      */   
/*      */   public void invokeDynamic(int bootStrapIndex, int argsSize, int returnTypeSize, char[] selector, char[] signature, boolean isConstructorReference, TypeReference lhsTypeReference, TypeReference[] typeArguments, int typeId, TypeBinding type) {
/* 4734 */     if (this.classFileOffset + 4 >= this.bCodeStream.length) {
/* 4735 */       resizeByteArray();
/*      */     }
/* 4737 */     int invokeDynamicIndex = this.constantPool.literalIndexForInvokeDynamic(bootStrapIndex, selector, signature);
/* 4738 */     this.position += 3;
/* 4739 */     this.bCodeStream[this.classFileOffset++] = -70;
/* 4740 */     writeUnsignedShort(invokeDynamicIndex);
/* 4741 */     this.bCodeStream[this.classFileOffset++] = 0;
/* 4742 */     this.bCodeStream[this.classFileOffset++] = 0;
/* 4743 */     this.stackDepth += returnTypeSize - argsSize;
/* 4744 */     popInvokeTypeBinding(argsSize);
/* 4745 */     if (returnTypeSize > 0) {
/* 4746 */       pushTypeBinding(type);
/*      */     }
/* 4748 */     if (this.stackDepth > this.stackMax) {
/* 4749 */       this.stackMax = this.stackDepth;
/*      */     }
/*      */   }
/*      */   
/*      */   public void invoke(byte opcode, MethodBinding methodBinding, TypeBinding declaringClass) {
/* 4754 */     invoke(opcode, methodBinding, declaringClass, null);
/*      */   } public void invoke(byte opcode, MethodBinding methodBinding, TypeBinding declaringClass, TypeReference[] typeArguments) {
/*      */     ReferenceBinding referenceBinding;
/*      */     int receiverAndArgsSize, returnTypeSize;
/* 4758 */     if (declaringClass == null) referenceBinding = methodBinding.declaringClass; 
/* 4759 */     if ((((TypeBinding)referenceBinding).tagBits & 0x800L) != 0L) {
/* 4760 */       Util.recordNestedType(this.classFile, (TypeBinding)referenceBinding);
/*      */     }
/*      */ 
/*      */     
/* 4764 */     switch (opcode) {
/*      */       case -72:
/* 4766 */         receiverAndArgsSize = 0;
/*      */         break;
/*      */       case -74:
/*      */       case -71:
/* 4770 */         receiverAndArgsSize = 1;
/*      */         break;
/*      */       case -73:
/* 4773 */         receiverAndArgsSize = 1;
/* 4774 */         if (methodBinding.isConstructor()) {
/* 4775 */           if (referenceBinding.isNestedType()) {
/* 4776 */             ReferenceBinding nestedType = referenceBinding;
/*      */             
/* 4778 */             receiverAndArgsSize += nestedType.getEnclosingInstancesSlotSize();
/*      */             
/* 4780 */             SyntheticArgumentBinding[] syntheticArguments = nestedType.syntheticOuterLocalVariables();
/* 4781 */             if (syntheticArguments != null) {
/* 4782 */               for (int j = 0, max = syntheticArguments.length; j < max; j++) {
/* 4783 */                 switch ((syntheticArguments[j]).id) {
/*      */                   case 7:
/*      */                   case 8:
/* 4786 */                     receiverAndArgsSize += 2;
/*      */                     break;
/*      */                   default:
/* 4789 */                     receiverAndArgsSize++;
/*      */                     break;
/*      */                 } 
/*      */               } 
/*      */             }
/*      */           } 
/* 4795 */           if (referenceBinding.isEnum())
/*      */           {
/* 4797 */             receiverAndArgsSize += 2;
/*      */           }
/*      */         } 
/*      */         break;
/*      */       
/*      */       default:
/*      */         return;
/*      */     } 
/* 4805 */     for (int i = methodBinding.parameters.length - 1; i >= 0; i--) {
/* 4806 */       switch ((methodBinding.parameters[i]).id) {
/*      */         case 7:
/*      */         case 8:
/* 4809 */           receiverAndArgsSize += 2;
/*      */           break;
/*      */         default:
/* 4812 */           receiverAndArgsSize++;
/*      */           break;
/*      */       } 
/*      */ 
/*      */     
/*      */     } 
/* 4818 */     switch (methodBinding.returnType.id) {
/*      */       case 7:
/*      */       case 8:
/* 4821 */         returnTypeSize = 2;
/*      */         break;
/*      */       case 6:
/* 4824 */         returnTypeSize = 0;
/*      */         break;
/*      */       default:
/* 4827 */         returnTypeSize = 1;
/*      */         break;
/*      */     } 
/* 4830 */     invoke18(
/* 4831 */         opcode, 
/* 4832 */         receiverAndArgsSize, 
/* 4833 */         returnTypeSize, 
/* 4834 */         referenceBinding.constantPoolName(), 
/* 4835 */         referenceBinding.isInterface(), 
/* 4836 */         methodBinding.selector, 
/* 4837 */         methodBinding.signature(this.classFile), 
/* 4838 */         methodBinding.returnType.id, 
/* 4839 */         methodBinding.returnType);
/*      */   }
/*      */ 
/*      */   
/*      */   protected void invokeAccessibleObjectSetAccessible() {
/* 4844 */     invoke((byte)
/* 4845 */         -74, 
/* 4846 */         2, 
/* 4847 */         0, 
/* 4848 */         ConstantPool.JAVALANGREFLECTACCESSIBLEOBJECT_CONSTANTPOOLNAME, 
/* 4849 */         ConstantPool.SETACCESSIBLE_NAME, 
/* 4850 */         ConstantPool.SETACCESSIBLE_SIGNATURE, 
/* 4851 */         null);
/*      */   }
/*      */ 
/*      */   
/*      */   protected void invokeArrayNewInstance() {
/* 4856 */     invoke((byte)
/* 4857 */         -72, 
/* 4858 */         2, 
/* 4859 */         1, 
/* 4860 */         ConstantPool.JAVALANGREFLECTARRAY_CONSTANTPOOLNAME, 
/* 4861 */         ConstantPool.NewInstance, 
/* 4862 */         ConstantPool.NewInstanceSignature, 
/* 4863 */         getPopularBinding(ConstantPool.JavaLangObjectConstantPoolName));
/*      */   }
/*      */   
/*      */   public void invokeClassForName() {
/* 4867 */     invoke((byte)
/* 4868 */         -72, 
/* 4869 */         1, 
/* 4870 */         1, 
/* 4871 */         ConstantPool.JavaLangClassConstantPoolName, 
/* 4872 */         ConstantPool.ForName, 
/* 4873 */         ConstantPool.ForNameSignature, 
/* 4874 */         getPopularBinding(ConstantPool.JavaLangClassConstantPoolName));
/*      */   }
/*      */ 
/*      */   
/*      */   protected void invokeClassGetDeclaredConstructor() {
/* 4879 */     invoke((byte)
/* 4880 */         -74, 
/* 4881 */         2, 
/* 4882 */         1, 
/* 4883 */         ConstantPool.JavaLangClassConstantPoolName, 
/* 4884 */         ConstantPool.GETDECLAREDCONSTRUCTOR_NAME, 
/* 4885 */         ConstantPool.GETDECLAREDCONSTRUCTOR_SIGNATURE, 
/* 4886 */         getPopularBinding(ConstantPool.JavaLangReflectConstructorConstantPoolName));
/*      */   }
/*      */ 
/*      */   
/*      */   protected void invokeClassGetDeclaredField() {
/* 4891 */     invoke((byte)
/* 4892 */         -74, 
/* 4893 */         2, 
/* 4894 */         1, 
/* 4895 */         ConstantPool.JavaLangClassConstantPoolName, 
/* 4896 */         ConstantPool.GETDECLAREDFIELD_NAME, 
/* 4897 */         ConstantPool.GETDECLAREDFIELD_SIGNATURE, 
/* 4898 */         getPopularBinding(ConstantPool.JAVALANGREFLECTFIELD_CONSTANTPOOLNAME));
/*      */   }
/*      */ 
/*      */   
/*      */   protected void invokeClassGetDeclaredMethod() {
/* 4903 */     invoke((byte)
/* 4904 */         -74, 
/* 4905 */         3, 
/* 4906 */         1, 
/* 4907 */         ConstantPool.JavaLangClassConstantPoolName, 
/* 4908 */         ConstantPool.GETDECLAREDMETHOD_NAME, 
/* 4909 */         ConstantPool.GETDECLAREDMETHOD_SIGNATURE, 
/* 4910 */         getPopularBinding(ConstantPool.JAVALANGREFLECTMETHOD_CONSTANTPOOLNAME));
/*      */   }
/*      */ 
/*      */   
/*      */   public void invokeEnumOrdinal(char[] enumTypeConstantPoolName) {
/* 4915 */     invoke((byte)
/* 4916 */         -74, 
/* 4917 */         1, 
/* 4918 */         1, 
/* 4919 */         enumTypeConstantPoolName, 
/* 4920 */         ConstantPool.Ordinal, 
/* 4921 */         ConstantPool.OrdinalSignature, 
/* 4922 */         10, 
/* 4923 */         (TypeBinding)TypeBinding.INT);
/*      */   }
/*      */ 
/*      */   
/*      */   public void invokeIterableIterator(TypeBinding iterableReceiverType) {
/* 4928 */     if ((iterableReceiverType.tagBits & 0x800L) != 0L) {
/* 4929 */       Util.recordNestedType(this.classFile, iterableReceiverType);
/*      */     }
/* 4931 */     invoke(
/* 4932 */         iterableReceiverType.isInterface() ? -71 : -74, 
/* 4933 */         1, 
/* 4934 */         1, 
/* 4935 */         iterableReceiverType.constantPoolName(), 
/* 4936 */         ConstantPool.ITERATOR_NAME, 
/* 4937 */         ConstantPool.ITERATOR_SIGNATURE, 
/* 4938 */         getPopularBinding(ConstantPool.JavaUtilIteratorConstantPoolName));
/*      */   }
/*      */ 
/*      */   
/*      */   public void invokeAutoCloseableClose(TypeBinding resourceType) {
/* 4943 */     invoke(
/* 4944 */         resourceType.erasure().isInterface() ? -71 : -74, 
/* 4945 */         1, 
/* 4946 */         0, 
/* 4947 */         resourceType.constantPoolName(), 
/* 4948 */         ConstantPool.Close, 
/* 4949 */         ConstantPool.CloseSignature, 
/* 4950 */         null);
/*      */   }
/*      */   
/*      */   public void invokeThrowableAddSuppressed() {
/* 4954 */     invoke((byte)-74, 
/* 4955 */         2, 
/* 4956 */         0, 
/* 4957 */         ConstantPool.JavaLangThrowableConstantPoolName, 
/* 4958 */         ConstantPool.AddSuppressed, 
/* 4959 */         ConstantPool.AddSuppressedSignature, 
/* 4960 */         null);
/*      */   }
/*      */ 
/*      */   
/*      */   public void invokeJavaLangAssertionErrorConstructor(int typeBindingID) {
/*      */     int receiverAndArgsSize;
/*      */     char[] signature;
/* 4967 */     switch (typeBindingID) {
/*      */       case 3:
/*      */       case 4:
/*      */       case 10:
/* 4971 */         signature = ConstantPool.IntConstrSignature;
/* 4972 */         receiverAndArgsSize = 2;
/*      */         break;
/*      */       case 7:
/* 4975 */         signature = ConstantPool.LongConstrSignature;
/* 4976 */         receiverAndArgsSize = 3;
/*      */         break;
/*      */       case 9:
/* 4979 */         signature = ConstantPool.FloatConstrSignature;
/* 4980 */         receiverAndArgsSize = 2;
/*      */         break;
/*      */       case 8:
/* 4983 */         signature = ConstantPool.DoubleConstrSignature;
/* 4984 */         receiverAndArgsSize = 3;
/*      */         break;
/*      */       case 2:
/* 4987 */         signature = ConstantPool.CharConstrSignature;
/* 4988 */         receiverAndArgsSize = 2;
/*      */         break;
/*      */       case 5:
/* 4991 */         signature = ConstantPool.BooleanConstrSignature;
/* 4992 */         receiverAndArgsSize = 2;
/*      */         break;
/*      */       case 1:
/*      */       case 11:
/*      */       case 12:
/* 4997 */         signature = ConstantPool.ObjectConstrSignature;
/* 4998 */         receiverAndArgsSize = 2;
/*      */         break;
/*      */       default:
/*      */         return;
/*      */     } 
/* 5003 */     invoke((byte)
/* 5004 */         -73, 
/* 5005 */         receiverAndArgsSize, 
/* 5006 */         0, 
/* 5007 */         ConstantPool.JavaLangAssertionErrorConstantPoolName, 
/* 5008 */         ConstantPool.Init, 
/* 5009 */         signature, 
/* 5010 */         null);
/*      */   }
/*      */ 
/*      */   
/*      */   public void invokeJavaLangAssertionErrorDefaultConstructor() {
/* 5015 */     invoke((byte)
/* 5016 */         -73, 
/* 5017 */         1, 
/* 5018 */         0, 
/* 5019 */         ConstantPool.JavaLangAssertionErrorConstantPoolName, 
/* 5020 */         ConstantPool.Init, 
/* 5021 */         ConstantPool.DefaultConstructorSignature, 
/* 5022 */         null);
/*      */   }
/*      */   
/*      */   public void invokeJavaLangIncompatibleClassChangeErrorDefaultConstructor() {
/* 5026 */     invoke((byte)
/* 5027 */         -73, 
/* 5028 */         1, 
/* 5029 */         0, 
/* 5030 */         ConstantPool.JavaLangIncompatibleClassChangeErrorConstantPoolName, 
/* 5031 */         ConstantPool.Init, 
/* 5032 */         ConstantPool.DefaultConstructorSignature, 
/* 5033 */         null);
/*      */   }
/*      */   
/*      */   public void invokeJavaLangClassDesiredAssertionStatus() {
/* 5037 */     invoke((byte)
/* 5038 */         -74, 
/* 5039 */         1, 
/* 5040 */         1, 
/* 5041 */         ConstantPool.JavaLangClassConstantPoolName, 
/* 5042 */         ConstantPool.DesiredAssertionStatus, 
/* 5043 */         ConstantPool.DesiredAssertionStatusSignature, 
/* 5044 */         5, 
/* 5045 */         (TypeBinding)TypeBinding.BOOLEAN);
/*      */   }
/*      */ 
/*      */   
/*      */   public void invokeJavaLangEnumvalueOf(ReferenceBinding binding) {
/* 5050 */     invoke((byte)
/* 5051 */         -72, 
/* 5052 */         2, 
/* 5053 */         1, 
/* 5054 */         ConstantPool.JavaLangEnumConstantPoolName, 
/* 5055 */         ConstantPool.ValueOf, 
/* 5056 */         ConstantPool.ValueOfStringClassSignature, 
/* 5057 */         getPopularBinding(ConstantPool.JavaLangEnumConstantPoolName));
/*      */   }
/*      */   
/*      */   public void invokeJavaLangEnumValues(TypeBinding enumBinding, ArrayBinding arrayBinding) {
/* 5061 */     char[] signature = "()".toCharArray();
/* 5062 */     signature = CharOperation.concat(signature, arrayBinding.constantPoolName());
/* 5063 */     invoke((byte)
/* 5064 */         -72, 
/* 5065 */         0, 
/* 5066 */         1, 
/* 5067 */         enumBinding.constantPoolName(), 
/* 5068 */         TypeConstants.VALUES, 
/* 5069 */         signature, 
/* 5070 */         (TypeBinding)arrayBinding);
/*      */   }
/*      */ 
/*      */   
/*      */   public void invokeJavaLangErrorConstructor() {
/* 5075 */     invoke((byte)
/* 5076 */         -73, 
/* 5077 */         2, 
/* 5078 */         0, 
/* 5079 */         ConstantPool.JavaLangErrorConstantPoolName, 
/* 5080 */         ConstantPool.Init, 
/* 5081 */         ConstantPool.StringConstructorSignature, 
/* 5082 */         null);
/*      */   }
/*      */ 
/*      */   
/*      */   public void invokeJavaLangReflectConstructorNewInstance() {
/* 5087 */     invoke((byte)
/* 5088 */         -74, 
/* 5089 */         2, 
/* 5090 */         1, 
/* 5091 */         ConstantPool.JavaLangReflectConstructorConstantPoolName, 
/* 5092 */         ConstantPool.NewInstance, 
/* 5093 */         ConstantPool.JavaLangReflectConstructorNewInstanceSignature, 
/* 5094 */         getPopularBinding(ConstantPool.JavaLangObjectSignature));
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected void invokeJavaLangReflectFieldGetter(TypeBinding type) {
/*      */     char[] selector, signature;
/* 5101 */     int returnTypeSize, typeID = type.id;
/* 5102 */     switch (typeID) {
/*      */       case 10:
/* 5104 */         selector = ConstantPool.GET_INT_METHOD_NAME;
/* 5105 */         signature = ConstantPool.GET_INT_METHOD_SIGNATURE;
/* 5106 */         returnTypeSize = 1;
/*      */         break;
/*      */       case 3:
/* 5109 */         selector = ConstantPool.GET_BYTE_METHOD_NAME;
/* 5110 */         signature = ConstantPool.GET_BYTE_METHOD_SIGNATURE;
/* 5111 */         returnTypeSize = 1;
/*      */         break;
/*      */       case 4:
/* 5114 */         selector = ConstantPool.GET_SHORT_METHOD_NAME;
/* 5115 */         signature = ConstantPool.GET_SHORT_METHOD_SIGNATURE;
/* 5116 */         returnTypeSize = 1;
/*      */         break;
/*      */       case 7:
/* 5119 */         selector = ConstantPool.GET_LONG_METHOD_NAME;
/* 5120 */         signature = ConstantPool.GET_LONG_METHOD_SIGNATURE;
/* 5121 */         returnTypeSize = 2;
/*      */         break;
/*      */       case 9:
/* 5124 */         selector = ConstantPool.GET_FLOAT_METHOD_NAME;
/* 5125 */         signature = ConstantPool.GET_FLOAT_METHOD_SIGNATURE;
/* 5126 */         returnTypeSize = 1;
/*      */         break;
/*      */       case 8:
/* 5129 */         selector = ConstantPool.GET_DOUBLE_METHOD_NAME;
/* 5130 */         signature = ConstantPool.GET_DOUBLE_METHOD_SIGNATURE;
/* 5131 */         returnTypeSize = 2;
/*      */         break;
/*      */       case 2:
/* 5134 */         selector = ConstantPool.GET_CHAR_METHOD_NAME;
/* 5135 */         signature = ConstantPool.GET_CHAR_METHOD_SIGNATURE;
/* 5136 */         returnTypeSize = 1;
/*      */         break;
/*      */       case 5:
/* 5139 */         selector = ConstantPool.GET_BOOLEAN_METHOD_NAME;
/* 5140 */         signature = ConstantPool.GET_BOOLEAN_METHOD_SIGNATURE;
/* 5141 */         returnTypeSize = 1;
/*      */         break;
/*      */       default:
/* 5144 */         selector = ConstantPool.GET_OBJECT_METHOD_NAME;
/* 5145 */         signature = ConstantPool.GET_OBJECT_METHOD_SIGNATURE;
/* 5146 */         returnTypeSize = 1;
/*      */         break;
/*      */     } 
/* 5149 */     invoke((byte)
/* 5150 */         -74, 
/* 5151 */         2, 
/* 5152 */         returnTypeSize, 
/* 5153 */         ConstantPool.JAVALANGREFLECTFIELD_CONSTANTPOOLNAME, 
/* 5154 */         selector, 
/* 5155 */         signature, 
/* 5156 */         typeID, 
/* 5157 */         type);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected void invokeJavaLangReflectFieldSetter(TypeBinding type) {
/*      */     char[] selector, signature;
/* 5164 */     int receiverAndArgsSize, typeID = type.id;
/* 5165 */     switch (typeID) {
/*      */       case 10:
/* 5167 */         selector = ConstantPool.SET_INT_METHOD_NAME;
/* 5168 */         signature = ConstantPool.SET_INT_METHOD_SIGNATURE;
/* 5169 */         receiverAndArgsSize = 3;
/*      */         break;
/*      */       case 3:
/* 5172 */         selector = ConstantPool.SET_BYTE_METHOD_NAME;
/* 5173 */         signature = ConstantPool.SET_BYTE_METHOD_SIGNATURE;
/* 5174 */         receiverAndArgsSize = 3;
/*      */         break;
/*      */       case 4:
/* 5177 */         selector = ConstantPool.SET_SHORT_METHOD_NAME;
/* 5178 */         signature = ConstantPool.SET_SHORT_METHOD_SIGNATURE;
/* 5179 */         receiverAndArgsSize = 3;
/*      */         break;
/*      */       case 7:
/* 5182 */         selector = ConstantPool.SET_LONG_METHOD_NAME;
/* 5183 */         signature = ConstantPool.SET_LONG_METHOD_SIGNATURE;
/* 5184 */         receiverAndArgsSize = 4;
/*      */         break;
/*      */       case 9:
/* 5187 */         selector = ConstantPool.SET_FLOAT_METHOD_NAME;
/* 5188 */         signature = ConstantPool.SET_FLOAT_METHOD_SIGNATURE;
/* 5189 */         receiverAndArgsSize = 3;
/*      */         break;
/*      */       case 8:
/* 5192 */         selector = ConstantPool.SET_DOUBLE_METHOD_NAME;
/* 5193 */         signature = ConstantPool.SET_DOUBLE_METHOD_SIGNATURE;
/* 5194 */         receiverAndArgsSize = 4;
/*      */         break;
/*      */       case 2:
/* 5197 */         selector = ConstantPool.SET_CHAR_METHOD_NAME;
/* 5198 */         signature = ConstantPool.SET_CHAR_METHOD_SIGNATURE;
/* 5199 */         receiverAndArgsSize = 3;
/*      */         break;
/*      */       case 5:
/* 5202 */         selector = ConstantPool.SET_BOOLEAN_METHOD_NAME;
/* 5203 */         signature = ConstantPool.SET_BOOLEAN_METHOD_SIGNATURE;
/* 5204 */         receiverAndArgsSize = 3;
/*      */         break;
/*      */       default:
/* 5207 */         selector = ConstantPool.SET_OBJECT_METHOD_NAME;
/* 5208 */         signature = ConstantPool.SET_OBJECT_METHOD_SIGNATURE;
/* 5209 */         receiverAndArgsSize = 3;
/*      */         break;
/*      */     } 
/* 5212 */     invoke((byte)
/* 5213 */         -74, 
/* 5214 */         receiverAndArgsSize, 
/* 5215 */         0, 
/* 5216 */         ConstantPool.JAVALANGREFLECTFIELD_CONSTANTPOOLNAME, 
/* 5217 */         selector, 
/* 5218 */         signature, 
/* 5219 */         typeID, 
/* 5220 */         type);
/*      */   }
/*      */ 
/*      */   
/*      */   public void invokeJavaLangReflectMethodInvoke() {
/* 5225 */     invoke((byte)
/* 5226 */         -74, 
/* 5227 */         3, 
/* 5228 */         1, 
/* 5229 */         ConstantPool.JAVALANGREFLECTMETHOD_CONSTANTPOOLNAME, 
/* 5230 */         ConstantPool.INVOKE_METHOD_METHOD_NAME, 
/* 5231 */         ConstantPool.INVOKE_METHOD_METHOD_SIGNATURE, 
/* 5232 */         getPopularBinding(ConstantPool.JavaLangObjectSignature));
/*      */   }
/*      */ 
/*      */   
/*      */   public void invokeJavaUtilIteratorHasNext() {
/* 5237 */     invoke((byte)
/* 5238 */         -71, 
/* 5239 */         1, 
/* 5240 */         1, 
/* 5241 */         ConstantPool.JavaUtilIteratorConstantPoolName, 
/* 5242 */         ConstantPool.HasNext, 
/* 5243 */         ConstantPool.HasNextSignature, 
/* 5244 */         5, 
/* 5245 */         (TypeBinding)TypeBinding.BOOLEAN);
/*      */   }
/*      */ 
/*      */   
/*      */   public void invokeJavaUtilIteratorNext() {
/* 5250 */     invoke((byte)
/* 5251 */         -71, 
/* 5252 */         1, 
/* 5253 */         1, 
/* 5254 */         ConstantPool.JavaUtilIteratorConstantPoolName, 
/* 5255 */         ConstantPool.Next, 
/* 5256 */         ConstantPool.NextSignature, 
/* 5257 */         getPopularBinding(ConstantPool.JavaLangObjectSignature));
/*      */   }
/*      */ 
/*      */   
/*      */   public void invokeJavaUtilObjectsrequireNonNull() {
/* 5262 */     invoke((byte)
/* 5263 */         -72, 
/* 5264 */         1, 
/* 5265 */         1, 
/* 5266 */         ConstantPool.JavaUtilObjectsConstantPoolName, 
/* 5267 */         ConstantPool.RequireNonNull, 
/* 5268 */         ConstantPool.RequireNonNullSignature, 
/* 5269 */         getPopularBinding(ConstantPool.JavaLangObjectSignature));
/*      */   }
/*      */ 
/*      */   
/*      */   public void invokeNoClassDefFoundErrorStringConstructor() {
/* 5274 */     invoke((byte)
/* 5275 */         -73, 
/* 5276 */         2, 
/* 5277 */         0, 
/* 5278 */         ConstantPool.JavaLangNoClassDefFoundErrorConstantPoolName, 
/* 5279 */         ConstantPool.Init, 
/* 5280 */         ConstantPool.StringConstructorSignature, 
/* 5281 */         null);
/*      */   }
/*      */ 
/*      */   
/*      */   public void invokeObjectGetClass() {
/* 5286 */     invoke((byte)
/* 5287 */         -74, 
/* 5288 */         1, 
/* 5289 */         1, 
/* 5290 */         ConstantPool.JavaLangObjectConstantPoolName, 
/* 5291 */         ConstantPool.GetClass, 
/* 5292 */         ConstantPool.GetClassSignature, 
/* 5293 */         getPopularBinding(ConstantPool.JavaLangClassConstantPoolName));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void invokeStringConcatenationAppendForType(int typeID) {
/*      */     int receiverAndArgsSize;
/* 5302 */     char[] declaringClass = null;
/* 5303 */     char[] selector = ConstantPool.Append;
/* 5304 */     char[] signature = null;
/* 5305 */     switch (typeID) {
/*      */       case 3:
/*      */       case 4:
/*      */       case 10:
/* 5309 */         if (this.targetLevel >= 3211264L) {
/* 5310 */           declaringClass = ConstantPool.JavaLangStringBuilderConstantPoolName;
/* 5311 */           signature = ConstantPool.StringBuilderAppendIntSignature;
/*      */         } else {
/* 5313 */           declaringClass = ConstantPool.JavaLangStringBufferConstantPoolName;
/* 5314 */           signature = ConstantPool.StringBufferAppendIntSignature;
/*      */         } 
/* 5316 */         receiverAndArgsSize = 2;
/*      */         break;
/*      */       case 7:
/* 5319 */         if (this.targetLevel >= 3211264L) {
/* 5320 */           declaringClass = ConstantPool.JavaLangStringBuilderConstantPoolName;
/* 5321 */           signature = ConstantPool.StringBuilderAppendLongSignature;
/*      */         } else {
/* 5323 */           declaringClass = ConstantPool.JavaLangStringBufferConstantPoolName;
/* 5324 */           signature = ConstantPool.StringBufferAppendLongSignature;
/*      */         } 
/* 5326 */         receiverAndArgsSize = 3;
/*      */         break;
/*      */       case 9:
/* 5329 */         if (this.targetLevel >= 3211264L) {
/* 5330 */           declaringClass = ConstantPool.JavaLangStringBuilderConstantPoolName;
/* 5331 */           signature = ConstantPool.StringBuilderAppendFloatSignature;
/*      */         } else {
/* 5333 */           declaringClass = ConstantPool.JavaLangStringBufferConstantPoolName;
/* 5334 */           signature = ConstantPool.StringBufferAppendFloatSignature;
/*      */         } 
/* 5336 */         receiverAndArgsSize = 2;
/*      */         break;
/*      */       case 8:
/* 5339 */         if (this.targetLevel >= 3211264L) {
/* 5340 */           declaringClass = ConstantPool.JavaLangStringBuilderConstantPoolName;
/* 5341 */           signature = ConstantPool.StringBuilderAppendDoubleSignature;
/*      */         } else {
/* 5343 */           declaringClass = ConstantPool.JavaLangStringBufferConstantPoolName;
/* 5344 */           signature = ConstantPool.StringBufferAppendDoubleSignature;
/*      */         } 
/* 5346 */         receiverAndArgsSize = 3;
/*      */         break;
/*      */       case 2:
/* 5349 */         if (this.targetLevel >= 3211264L) {
/* 5350 */           declaringClass = ConstantPool.JavaLangStringBuilderConstantPoolName;
/* 5351 */           signature = ConstantPool.StringBuilderAppendCharSignature;
/*      */         } else {
/* 5353 */           declaringClass = ConstantPool.JavaLangStringBufferConstantPoolName;
/* 5354 */           signature = ConstantPool.StringBufferAppendCharSignature;
/*      */         } 
/* 5356 */         receiverAndArgsSize = 2;
/*      */         break;
/*      */       case 5:
/* 5359 */         if (this.targetLevel >= 3211264L) {
/* 5360 */           declaringClass = ConstantPool.JavaLangStringBuilderConstantPoolName;
/* 5361 */           signature = ConstantPool.StringBuilderAppendBooleanSignature;
/*      */         } else {
/* 5363 */           declaringClass = ConstantPool.JavaLangStringBufferConstantPoolName;
/* 5364 */           signature = ConstantPool.StringBufferAppendBooleanSignature;
/*      */         } 
/* 5366 */         receiverAndArgsSize = 2;
/*      */         break;
/*      */       case 11:
/* 5369 */         if (this.targetLevel >= 3211264L) {
/* 5370 */           declaringClass = ConstantPool.JavaLangStringBuilderConstantPoolName;
/* 5371 */           signature = ConstantPool.StringBuilderAppendStringSignature;
/*      */         } else {
/* 5373 */           declaringClass = ConstantPool.JavaLangStringBufferConstantPoolName;
/* 5374 */           signature = ConstantPool.StringBufferAppendStringSignature;
/*      */         } 
/* 5376 */         receiverAndArgsSize = 2;
/*      */         break;
/*      */       default:
/* 5379 */         if (this.targetLevel >= 3211264L) {
/* 5380 */           declaringClass = ConstantPool.JavaLangStringBuilderConstantPoolName;
/* 5381 */           signature = ConstantPool.StringBuilderAppendObjectSignature;
/*      */         } else {
/* 5383 */           declaringClass = ConstantPool.JavaLangStringBufferConstantPoolName;
/* 5384 */           signature = ConstantPool.StringBufferAppendObjectSignature;
/*      */         } 
/* 5386 */         receiverAndArgsSize = 2;
/*      */         break;
/*      */     } 
/*      */     
/* 5390 */     TypeBinding type = (this.targetLevel >= 3801088L) ? 
/* 5391 */       getPopularBinding(ConstantPool.JavaLangStringBuilderConstantPoolName) : null;
/* 5392 */     invoke((byte)
/* 5393 */         -74, 
/* 5394 */         receiverAndArgsSize, 
/* 5395 */         1, 
/* 5396 */         declaringClass, 
/* 5397 */         selector, 
/* 5398 */         signature, 
/* 5399 */         typeID, 
/* 5400 */         type);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void invokeStringConcatenationDefaultConstructor() {
/*      */     char[] declaringClass;
/* 5407 */     if (this.targetLevel < 3211264L) {
/* 5408 */       declaringClass = ConstantPool.JavaLangStringBufferConstantPoolName;
/*      */     } else {
/* 5410 */       declaringClass = ConstantPool.JavaLangStringBuilderConstantPoolName;
/*      */     } 
/* 5412 */     invoke((byte)
/* 5413 */         -73, 
/* 5414 */         1, 
/* 5415 */         0, 
/* 5416 */         declaringClass, 
/* 5417 */         ConstantPool.Init, 
/* 5418 */         ConstantPool.DefaultConstructorSignature, 
/* 5419 */         null);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void invokeStringConcatenationStringConstructor() {
/*      */     char[] declaringClass;
/* 5426 */     if (this.targetLevel < 3211264L) {
/*      */       
/* 5428 */       declaringClass = ConstantPool.JavaLangStringBufferConstantPoolName;
/*      */     } else {
/*      */       
/* 5431 */       declaringClass = ConstantPool.JavaLangStringBuilderConstantPoolName;
/*      */     } 
/* 5433 */     invoke((byte)
/* 5434 */         -73, 
/* 5435 */         2, 
/* 5436 */         0, 
/* 5437 */         declaringClass, 
/* 5438 */         ConstantPool.Init, 
/* 5439 */         ConstantPool.StringConstructorSignature, 
/* 5440 */         null);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void invokeStringConcatenationToString() {
/*      */     char[] declaringClass;
/* 5447 */     if (this.targetLevel < 3211264L) {
/*      */       
/* 5449 */       declaringClass = ConstantPool.JavaLangStringBufferConstantPoolName;
/*      */     } else {
/*      */       
/* 5452 */       declaringClass = ConstantPool.JavaLangStringBuilderConstantPoolName;
/*      */     } 
/* 5454 */     invoke((byte)
/* 5455 */         -74, 
/* 5456 */         1, 
/* 5457 */         1, 
/* 5458 */         declaringClass, 
/* 5459 */         ConstantPool.ToString, 
/* 5460 */         ConstantPool.ToStringSignature, 
/* 5461 */         getPopularBinding(ConstantPool.JavaLangStringConstantPoolName));
/*      */   }
/*      */   
/*      */   public void invokeStringEquals() {
/* 5465 */     invoke((byte)
/* 5466 */         -74, 
/* 5467 */         2, 
/* 5468 */         1, 
/* 5469 */         ConstantPool.JavaLangStringConstantPoolName, 
/* 5470 */         ConstantPool.Equals, 
/* 5471 */         ConstantPool.EqualsSignature, 
/* 5472 */         5, 
/* 5473 */         (TypeBinding)TypeBinding.BOOLEAN);
/*      */   }
/*      */   
/*      */   public void invokeObjectEquals() {
/* 5477 */     invoke((byte)
/* 5478 */         -74, 
/* 5479 */         2, 
/* 5480 */         1, 
/* 5481 */         ConstantPool.JavaLangObjectConstantPoolName, 
/* 5482 */         ConstantPool.Equals, 
/* 5483 */         ConstantPool.EqualsSignature, 
/* 5484 */         5, 
/* 5485 */         (TypeBinding)TypeBinding.BOOLEAN);
/*      */   }
/*      */   
/*      */   public void invokeStringHashCode() {
/* 5489 */     invoke((byte)
/* 5490 */         -74, 
/* 5491 */         1, 
/* 5492 */         1, 
/* 5493 */         ConstantPool.JavaLangStringConstantPoolName, 
/* 5494 */         ConstantPool.HashCode, 
/* 5495 */         ConstantPool.HashCodeSignature, 
/* 5496 */         10, 
/* 5497 */         (TypeBinding)TypeBinding.INT);
/*      */   }
/*      */   
/*      */   public void invokeStringIntern() {
/* 5501 */     invoke((byte)
/* 5502 */         -74, 
/* 5503 */         1, 
/* 5504 */         1, 
/* 5505 */         ConstantPool.JavaLangStringConstantPoolName, 
/* 5506 */         ConstantPool.Intern, 
/* 5507 */         ConstantPool.InternSignature, 
/* 5508 */         getPopularBinding(ConstantPool.JavaLangStringConstantPoolName));
/*      */   }
/*      */   
/*      */   public void invokeStringValueOf(int typeID) {
/*      */     char[] signature;
/*      */     int receiverAndArgsSize;
/* 5514 */     switch (typeID) {
/*      */       case 3:
/*      */       case 4:
/*      */       case 10:
/* 5518 */         signature = ConstantPool.ValueOfIntSignature;
/* 5519 */         receiverAndArgsSize = 1;
/*      */         break;
/*      */       case 7:
/* 5522 */         signature = ConstantPool.ValueOfLongSignature;
/* 5523 */         receiverAndArgsSize = 2;
/*      */         break;
/*      */       case 9:
/* 5526 */         signature = ConstantPool.ValueOfFloatSignature;
/* 5527 */         receiverAndArgsSize = 1;
/*      */         break;
/*      */       case 8:
/* 5530 */         signature = ConstantPool.ValueOfDoubleSignature;
/* 5531 */         receiverAndArgsSize = 2;
/*      */         break;
/*      */       case 2:
/* 5534 */         signature = ConstantPool.ValueOfCharSignature;
/* 5535 */         receiverAndArgsSize = 1;
/*      */         break;
/*      */       case 5:
/* 5538 */         signature = ConstantPool.ValueOfBooleanSignature;
/* 5539 */         receiverAndArgsSize = 1;
/*      */         break;
/*      */       case 0:
/*      */       case 1:
/*      */       case 11:
/*      */       case 12:
/* 5545 */         signature = ConstantPool.ValueOfObjectSignature;
/* 5546 */         receiverAndArgsSize = 1;
/*      */         break;
/*      */       default:
/*      */         return;
/*      */     } 
/* 5551 */     invoke((byte)
/* 5552 */         -72, 
/* 5553 */         receiverAndArgsSize, 
/* 5554 */         1, 
/* 5555 */         ConstantPool.JavaLangStringConstantPoolName, 
/* 5556 */         ConstantPool.ValueOf, 
/* 5557 */         signature, 
/* 5558 */         typeID, 
/* 5559 */         getPopularBinding(ConstantPool.JavaLangStringConstantPoolName));
/*      */   }
/*      */ 
/*      */   
/*      */   public void invokeSystemArraycopy() {
/* 5564 */     invoke((byte)
/* 5565 */         -72, 
/* 5566 */         5, 
/* 5567 */         0, 
/* 5568 */         ConstantPool.JavaLangSystemConstantPoolName, 
/* 5569 */         ConstantPool.ArrayCopy, 
/* 5570 */         ConstantPool.ArrayCopySignature, 
/* 5571 */         null);
/*      */   }
/*      */ 
/*      */   
/*      */   public void invokeThrowableGetMessage() {
/* 5576 */     invoke((byte)
/* 5577 */         -74, 
/* 5578 */         1, 
/* 5579 */         1, 
/* 5580 */         ConstantPool.JavaLangThrowableConstantPoolName, 
/* 5581 */         ConstantPool.GetMessage, 
/* 5582 */         ConstantPool.GetMessageSignature, 
/* 5583 */         getPopularBinding(ConstantPool.JavaLangStringConstantPoolName));
/*      */   }
/*      */   
/*      */   public void ior() {
/* 5587 */     this.countLabels = 0;
/* 5588 */     this.stackDepth--;
/* 5589 */     pushTypeBinding(2, (TypeBinding)TypeBinding.INT);
/* 5590 */     if (this.classFileOffset >= this.bCodeStream.length) {
/* 5591 */       resizeByteArray();
/*      */     }
/* 5593 */     this.position++;
/* 5594 */     this.bCodeStream[this.classFileOffset++] = Byte.MIN_VALUE;
/*      */   }
/*      */   
/*      */   public void irem() {
/* 5598 */     this.countLabels = 0;
/* 5599 */     this.stackDepth--;
/* 5600 */     pushTypeBinding(2, (TypeBinding)TypeBinding.INT);
/* 5601 */     if (this.classFileOffset >= this.bCodeStream.length) {
/* 5602 */       resizeByteArray();
/*      */     }
/* 5604 */     this.position++;
/* 5605 */     this.bCodeStream[this.classFileOffset++] = 112;
/*      */   }
/*      */   
/*      */   public void ireturn() {
/* 5609 */     this.countLabels = 0;
/* 5610 */     this.stackDepth--;
/* 5611 */     popTypeBinding();
/*      */     
/* 5613 */     if (this.classFileOffset >= this.bCodeStream.length) {
/* 5614 */       resizeByteArray();
/*      */     }
/* 5616 */     this.position++;
/* 5617 */     this.bCodeStream[this.classFileOffset++] = -84;
/* 5618 */     this.lastAbruptCompletion = this.position;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isDefinitelyAssigned(Scope scope, int initStateIndex, LocalVariableBinding local) {
/* 5623 */     if ((local.tagBits & 0x400L) != 0L) {
/* 5624 */       return true;
/*      */     }
/* 5626 */     if (initStateIndex == -1)
/* 5627 */       return false; 
/* 5628 */     int localPosition = local.id + this.maxFieldCount;
/* 5629 */     MethodScope methodScope = scope.methodScope();
/*      */     
/* 5631 */     if (localPosition < 64) {
/* 5632 */       return ((methodScope.definiteInits[initStateIndex] & 1L << localPosition) != 0L);
/*      */     }
/*      */     
/* 5635 */     long[] extraInits = methodScope.extraDefiniteInits[initStateIndex];
/* 5636 */     if (extraInits == null)
/* 5637 */       return false; 
/*      */     int vectorIndex;
/* 5639 */     if ((vectorIndex = localPosition / 64 - 1) >= extraInits.length)
/* 5640 */       return false; 
/* 5641 */     return ((extraInits[vectorIndex] & 1L << localPosition % 64) != 0L);
/*      */   }
/*      */   
/*      */   public void ishl() {
/* 5645 */     this.countLabels = 0;
/* 5646 */     this.stackDepth--;
/* 5647 */     pushTypeBinding(2, (TypeBinding)TypeBinding.INT);
/* 5648 */     if (this.classFileOffset >= this.bCodeStream.length) {
/* 5649 */       resizeByteArray();
/*      */     }
/* 5651 */     this.position++;
/* 5652 */     this.bCodeStream[this.classFileOffset++] = 120;
/*      */   }
/*      */   
/*      */   public void ishr() {
/* 5656 */     this.countLabels = 0;
/* 5657 */     this.stackDepth--;
/* 5658 */     pushTypeBinding(2, (TypeBinding)TypeBinding.INT);
/* 5659 */     if (this.classFileOffset >= this.bCodeStream.length) {
/* 5660 */       resizeByteArray();
/*      */     }
/* 5662 */     this.position++;
/* 5663 */     this.bCodeStream[this.classFileOffset++] = 122;
/*      */   }
/*      */   
/*      */   public void istore(int iArg) {
/* 5667 */     this.countLabels = 0;
/* 5668 */     this.stackDepth--;
/* 5669 */     popTypeBinding();
/* 5670 */     if (this.maxLocals <= iArg) {
/* 5671 */       this.maxLocals = iArg + 1;
/*      */     }
/* 5673 */     if (iArg > 255) {
/* 5674 */       if (this.classFileOffset + 3 >= this.bCodeStream.length) {
/* 5675 */         resizeByteArray();
/*      */       }
/* 5677 */       this.position += 2;
/* 5678 */       this.bCodeStream[this.classFileOffset++] = -60;
/* 5679 */       this.bCodeStream[this.classFileOffset++] = 54;
/* 5680 */       writeUnsignedShort(iArg);
/*      */     } else {
/* 5682 */       if (this.classFileOffset + 1 >= this.bCodeStream.length) {
/* 5683 */         resizeByteArray();
/*      */       }
/* 5685 */       this.position += 2;
/* 5686 */       this.bCodeStream[this.classFileOffset++] = 54;
/* 5687 */       this.bCodeStream[this.classFileOffset++] = (byte)iArg;
/*      */     } 
/*      */   }
/*      */   
/*      */   public void istore_0() {
/* 5692 */     this.countLabels = 0;
/* 5693 */     this.stackDepth--;
/* 5694 */     popTypeBinding();
/* 5695 */     if (this.maxLocals == 0) {
/* 5696 */       this.maxLocals = 1;
/*      */     }
/* 5698 */     if (this.classFileOffset >= this.bCodeStream.length) {
/* 5699 */       resizeByteArray();
/*      */     }
/* 5701 */     this.position++;
/* 5702 */     this.bCodeStream[this.classFileOffset++] = 59;
/*      */   }
/*      */   
/*      */   public void istore_1() {
/* 5706 */     this.countLabels = 0;
/* 5707 */     this.stackDepth--;
/* 5708 */     popTypeBinding();
/* 5709 */     if (this.maxLocals <= 1) {
/* 5710 */       this.maxLocals = 2;
/*      */     }
/* 5712 */     if (this.classFileOffset >= this.bCodeStream.length) {
/* 5713 */       resizeByteArray();
/*      */     }
/* 5715 */     this.position++;
/* 5716 */     this.bCodeStream[this.classFileOffset++] = 60;
/*      */   }
/*      */   
/*      */   public void istore_2() {
/* 5720 */     this.countLabels = 0;
/* 5721 */     this.stackDepth--;
/* 5722 */     popTypeBinding();
/* 5723 */     if (this.maxLocals <= 2) {
/* 5724 */       this.maxLocals = 3;
/*      */     }
/* 5726 */     if (this.classFileOffset >= this.bCodeStream.length) {
/* 5727 */       resizeByteArray();
/*      */     }
/* 5729 */     this.position++;
/* 5730 */     this.bCodeStream[this.classFileOffset++] = 61;
/*      */   }
/*      */   
/*      */   public void istore_3() {
/* 5734 */     this.countLabels = 0;
/* 5735 */     this.stackDepth--;
/* 5736 */     popTypeBinding();
/* 5737 */     if (this.maxLocals <= 3) {
/* 5738 */       this.maxLocals = 4;
/*      */     }
/* 5740 */     if (this.classFileOffset >= this.bCodeStream.length) {
/* 5741 */       resizeByteArray();
/*      */     }
/* 5743 */     this.position++;
/* 5744 */     this.bCodeStream[this.classFileOffset++] = 62;
/*      */   }
/*      */   
/*      */   public void isub() {
/* 5748 */     this.countLabels = 0;
/* 5749 */     this.stackDepth--;
/* 5750 */     pushTypeBinding(2, (TypeBinding)TypeBinding.INT);
/* 5751 */     if (this.classFileOffset >= this.bCodeStream.length) {
/* 5752 */       resizeByteArray();
/*      */     }
/* 5754 */     this.position++;
/* 5755 */     this.bCodeStream[this.classFileOffset++] = 100;
/*      */   }
/*      */   
/*      */   public void iushr() {
/* 5759 */     this.countLabels = 0;
/* 5760 */     this.stackDepth--;
/* 5761 */     pushTypeBinding(2, (TypeBinding)TypeBinding.INT);
/* 5762 */     if (this.classFileOffset >= this.bCodeStream.length) {
/* 5763 */       resizeByteArray();
/*      */     }
/* 5765 */     this.position++;
/* 5766 */     this.bCodeStream[this.classFileOffset++] = 124;
/*      */   }
/*      */   
/*      */   public void ixor() {
/* 5770 */     this.countLabels = 0;
/* 5771 */     this.stackDepth--;
/* 5772 */     pushTypeBinding(2, (TypeBinding)TypeBinding.INT);
/* 5773 */     if (this.classFileOffset >= this.bCodeStream.length) {
/* 5774 */       resizeByteArray();
/*      */     }
/* 5776 */     this.position++;
/* 5777 */     this.bCodeStream[this.classFileOffset++] = -126;
/*      */   }
/*      */   
/*      */   public final void jsr(BranchLabel lbl) {
/* 5781 */     if (this.wideMode) {
/* 5782 */       jsr_w(lbl);
/*      */       return;
/*      */     } 
/* 5785 */     this.countLabels = 0;
/* 5786 */     if (this.classFileOffset >= this.bCodeStream.length) {
/* 5787 */       resizeByteArray();
/*      */     }
/* 5789 */     this.position++;
/* 5790 */     this.bCodeStream[this.classFileOffset++] = -88;
/* 5791 */     lbl.branch();
/*      */   }
/*      */   
/*      */   public final void jsr_w(BranchLabel lbl) {
/* 5795 */     this.countLabels = 0;
/* 5796 */     if (this.classFileOffset >= this.bCodeStream.length) {
/* 5797 */       resizeByteArray();
/*      */     }
/* 5799 */     this.position++;
/* 5800 */     this.bCodeStream[this.classFileOffset++] = -55;
/* 5801 */     lbl.branchWide();
/*      */   }
/*      */   
/*      */   public void l2d() {
/* 5805 */     this.countLabels = 0;
/* 5806 */     if (this.classFileOffset >= this.bCodeStream.length) {
/* 5807 */       resizeByteArray();
/*      */     }
/* 5809 */     this.position++;
/* 5810 */     this.bCodeStream[this.classFileOffset++] = -118;
/* 5811 */     pushTypeBinding(1, (TypeBinding)TypeBinding.DOUBLE);
/*      */   }
/*      */   
/*      */   public void l2f() {
/* 5815 */     this.countLabels = 0;
/* 5816 */     this.stackDepth--;
/* 5817 */     pushTypeBinding(1, (TypeBinding)TypeBinding.FLOAT);
/* 5818 */     if (this.classFileOffset >= this.bCodeStream.length) {
/* 5819 */       resizeByteArray();
/*      */     }
/* 5821 */     this.position++;
/* 5822 */     this.bCodeStream[this.classFileOffset++] = -119;
/*      */   }
/*      */   
/*      */   public void l2i() {
/* 5826 */     this.countLabels = 0;
/* 5827 */     this.stackDepth--;
/* 5828 */     pushTypeBinding(1, (TypeBinding)TypeBinding.INT);
/* 5829 */     if (this.classFileOffset >= this.bCodeStream.length) {
/* 5830 */       resizeByteArray();
/*      */     }
/* 5832 */     this.position++;
/* 5833 */     this.bCodeStream[this.classFileOffset++] = -120;
/*      */   }
/*      */   
/*      */   public void ladd() {
/* 5837 */     this.countLabels = 0;
/* 5838 */     this.stackDepth -= 2;
/* 5839 */     pushTypeBinding(2, (TypeBinding)TypeBinding.LONG);
/* 5840 */     if (this.classFileOffset >= this.bCodeStream.length) {
/* 5841 */       resizeByteArray();
/*      */     }
/* 5843 */     this.position++;
/* 5844 */     this.bCodeStream[this.classFileOffset++] = 97;
/*      */   }
/*      */   
/*      */   public void laload() {
/* 5848 */     this.countLabels = 0;
/* 5849 */     if (this.classFileOffset >= this.bCodeStream.length) {
/* 5850 */       resizeByteArray();
/*      */     }
/* 5852 */     this.position++;
/* 5853 */     this.bCodeStream[this.classFileOffset++] = 47;
/* 5854 */     pushTypeBindingArray();
/*      */   }
/*      */   
/*      */   public void land() {
/* 5858 */     this.countLabels = 0;
/* 5859 */     this.stackDepth -= 2;
/* 5860 */     pushTypeBinding(2, (TypeBinding)TypeBinding.LONG);
/* 5861 */     if (this.classFileOffset >= this.bCodeStream.length) {
/* 5862 */       resizeByteArray();
/*      */     }
/* 5864 */     this.position++;
/* 5865 */     this.bCodeStream[this.classFileOffset++] = Byte.MAX_VALUE;
/*      */   }
/*      */   
/*      */   public void lastore() {
/* 5869 */     this.countLabels = 0;
/* 5870 */     this.stackDepth -= 4;
/* 5871 */     popTypeBinding(3);
/* 5872 */     if (this.classFileOffset >= this.bCodeStream.length) {
/* 5873 */       resizeByteArray();
/*      */     }
/* 5875 */     this.position++;
/* 5876 */     this.bCodeStream[this.classFileOffset++] = 80;
/*      */   }
/*      */   
/*      */   public void lcmp() {
/* 5880 */     this.countLabels = 0;
/* 5881 */     this.stackDepth -= 3;
/* 5882 */     pushTypeBinding(2, (TypeBinding)TypeBinding.LONG);
/* 5883 */     if (this.classFileOffset >= this.bCodeStream.length) {
/* 5884 */       resizeByteArray();
/*      */     }
/* 5886 */     this.position++;
/* 5887 */     this.bCodeStream[this.classFileOffset++] = -108;
/*      */   }
/*      */   
/*      */   public void lconst_0() {
/* 5891 */     this.countLabels = 0;
/* 5892 */     this.stackDepth += 2;
/* 5893 */     pushTypeBinding((TypeBinding)TypeBinding.LONG);
/* 5894 */     if (this.stackDepth > this.stackMax)
/* 5895 */       this.stackMax = this.stackDepth; 
/* 5896 */     if (this.classFileOffset >= this.bCodeStream.length) {
/* 5897 */       resizeByteArray();
/*      */     }
/* 5899 */     this.position++;
/* 5900 */     this.bCodeStream[this.classFileOffset++] = 9;
/*      */   }
/*      */   
/*      */   public void lconst_1() {
/* 5904 */     this.countLabels = 0;
/* 5905 */     this.stackDepth += 2;
/* 5906 */     pushTypeBinding((TypeBinding)TypeBinding.LONG);
/* 5907 */     if (this.stackDepth > this.stackMax)
/* 5908 */       this.stackMax = this.stackDepth; 
/* 5909 */     if (this.classFileOffset >= this.bCodeStream.length) {
/* 5910 */       resizeByteArray();
/*      */     }
/* 5912 */     this.position++;
/* 5913 */     this.bCodeStream[this.classFileOffset++] = 10;
/*      */   }
/*      */   
/*      */   public void ldc(float constant) {
/* 5917 */     this.countLabels = 0;
/* 5918 */     int index = this.constantPool.literalIndex(constant);
/* 5919 */     this.stackDepth++;
/* 5920 */     pushTypeBinding((TypeBinding)TypeBinding.FLOAT);
/* 5921 */     if (this.stackDepth > this.stackMax)
/* 5922 */       this.stackMax = this.stackDepth; 
/* 5923 */     if (index > 255) {
/*      */       
/* 5925 */       if (this.classFileOffset + 2 >= this.bCodeStream.length) {
/* 5926 */         resizeByteArray();
/*      */       }
/* 5928 */       this.position++;
/* 5929 */       this.bCodeStream[this.classFileOffset++] = 19;
/* 5930 */       writeUnsignedShort(index);
/*      */     } else {
/*      */       
/* 5933 */       if (this.classFileOffset + 1 >= this.bCodeStream.length) {
/* 5934 */         resizeByteArray();
/*      */       }
/* 5936 */       this.position += 2;
/* 5937 */       this.bCodeStream[this.classFileOffset++] = 18;
/* 5938 */       this.bCodeStream[this.classFileOffset++] = (byte)index;
/*      */     } 
/*      */   }
/*      */   
/*      */   public void ldc(int constant) {
/* 5943 */     this.countLabels = 0;
/* 5944 */     int index = this.constantPool.literalIndex(constant);
/* 5945 */     this.stackDepth++;
/* 5946 */     pushTypeBinding((TypeBinding)TypeBinding.INT);
/* 5947 */     if (this.stackDepth > this.stackMax)
/* 5948 */       this.stackMax = this.stackDepth; 
/* 5949 */     if (index > 255) {
/*      */       
/* 5951 */       if (this.classFileOffset + 2 >= this.bCodeStream.length) {
/* 5952 */         resizeByteArray();
/*      */       }
/* 5954 */       this.position++;
/* 5955 */       this.bCodeStream[this.classFileOffset++] = 19;
/* 5956 */       writeUnsignedShort(index);
/*      */     } else {
/*      */       
/* 5959 */       if (this.classFileOffset + 1 >= this.bCodeStream.length) {
/* 5960 */         resizeByteArray();
/*      */       }
/* 5962 */       this.position += 2;
/* 5963 */       this.bCodeStream[this.classFileOffset++] = 18;
/* 5964 */       this.bCodeStream[this.classFileOffset++] = (byte)index;
/*      */     } 
/*      */   }
/*      */   
/*      */   public void ldc(String constant) {
/* 5969 */     this.countLabels = 0;
/* 5970 */     int currentCodeStreamPosition = this.position;
/* 5971 */     char[] constantChars = constant.toCharArray();
/* 5972 */     int index = this.constantPool.literalIndexForLdc(constantChars);
/* 5973 */     if (index > 0) {
/*      */ 
/*      */       
/* 5976 */       ldcForIndex(index);
/*      */     
/*      */     }
/*      */     else {
/*      */ 
/*      */       
/* 5982 */       this.position = currentCodeStreamPosition;
/* 5983 */       int i = 0;
/* 5984 */       int length = 0;
/* 5985 */       int constantLength = constant.length();
/* 5986 */       byte[] utf8encoding = new byte[Math.min(constantLength + 100, 65535)];
/* 5987 */       int utf8encodingLength = 0;
/* 5988 */       while (length < 65532 && i < constantLength) {
/* 5989 */         char current = constantChars[i];
/*      */         
/* 5991 */         if (length + 3 > (utf8encodingLength = utf8encoding.length)) {
/* 5992 */           System.arraycopy(utf8encoding, 0, utf8encoding = new byte[Math.min(utf8encodingLength + 100, 65535)], 0, length);
/*      */         }
/* 5994 */         if (current >= '\001' && current <= '') {
/*      */           
/* 5996 */           utf8encoding[length++] = (byte)current;
/*      */         }
/* 5998 */         else if (current > '߿') {
/*      */           
/* 6000 */           utf8encoding[length++] = (byte)(0xE0 | current >> 12 & 0xF);
/* 6001 */           utf8encoding[length++] = (byte)(0x80 | current >> 6 & 0x3F);
/* 6002 */           utf8encoding[length++] = (byte)(0x80 | current & 0x3F);
/*      */         }
/*      */         else {
/*      */           
/* 6006 */           utf8encoding[length++] = (byte)(0xC0 | current >> 6 & 0x1F);
/* 6007 */           utf8encoding[length++] = (byte)(0x80 | current & 0x3F);
/*      */         } 
/*      */         
/* 6010 */         i++;
/*      */       } 
/*      */ 
/*      */       
/* 6014 */       newStringContatenation();
/* 6015 */       dup();
/*      */       
/* 6017 */       char[] subChars = new char[i];
/* 6018 */       System.arraycopy(constantChars, 0, subChars, 0, i);
/* 6019 */       System.arraycopy(utf8encoding, 0, utf8encoding = new byte[length], 0, length);
/* 6020 */       index = this.constantPool.literalIndex(subChars, utf8encoding);
/* 6021 */       ldcForIndex(index);
/*      */       
/* 6023 */       invokeStringConcatenationStringConstructor();
/* 6024 */       while (i < constantLength) {
/* 6025 */         length = 0;
/* 6026 */         utf8encoding = new byte[Math.min(constantLength - i + 100, 65535)];
/* 6027 */         int startIndex = i;
/* 6028 */         while (length < 65532 && i < constantLength) {
/* 6029 */           char current = constantChars[i];
/*      */           
/* 6031 */           if (length + 3 > (utf8encodingLength = utf8encoding.length)) {
/* 6032 */             System.arraycopy(utf8encoding, 0, utf8encoding = new byte[Math.min(utf8encodingLength + 100, 65535)], 0, length);
/*      */           }
/* 6034 */           if (current >= '\001' && current <= '') {
/*      */             
/* 6036 */             utf8encoding[length++] = (byte)current;
/*      */           }
/* 6038 */           else if (current > '߿') {
/*      */             
/* 6040 */             utf8encoding[length++] = (byte)(0xE0 | current >> 12 & 0xF);
/* 6041 */             utf8encoding[length++] = (byte)(0x80 | current >> 6 & 0x3F);
/* 6042 */             utf8encoding[length++] = (byte)(0x80 | current & 0x3F);
/*      */           }
/*      */           else {
/*      */             
/* 6046 */             utf8encoding[length++] = (byte)(0xC0 | current >> 6 & 0x1F);
/* 6047 */             utf8encoding[length++] = (byte)(0x80 | current & 0x3F);
/*      */           } 
/*      */           
/* 6050 */           i++;
/*      */         } 
/*      */         
/* 6053 */         int newCharLength = i - startIndex;
/* 6054 */         subChars = new char[newCharLength];
/* 6055 */         System.arraycopy(constantChars, startIndex, subChars, 0, newCharLength);
/* 6056 */         System.arraycopy(utf8encoding, 0, utf8encoding = new byte[length], 0, length);
/* 6057 */         index = this.constantPool.literalIndex(subChars, utf8encoding);
/* 6058 */         ldcForIndex(index);
/*      */         
/* 6060 */         invokeStringConcatenationAppendForType(11);
/*      */       } 
/* 6062 */       invokeStringConcatenationToString();
/* 6063 */       invokeStringIntern();
/*      */     } 
/*      */   }
/*      */   
/*      */   public void ldc(TypeBinding typeBinding) {
/* 6068 */     this.countLabels = 0;
/* 6069 */     int index = this.constantPool.literalIndexForType(typeBinding);
/* 6070 */     this.stackDepth++;
/* 6071 */     pushTypeBinding(typeBinding);
/* 6072 */     if (this.stackDepth > this.stackMax)
/* 6073 */       this.stackMax = this.stackDepth; 
/* 6074 */     if (index > 255) {
/*      */       
/* 6076 */       if (this.classFileOffset + 2 >= this.bCodeStream.length) {
/* 6077 */         resizeByteArray();
/*      */       }
/* 6079 */       this.position++;
/* 6080 */       this.bCodeStream[this.classFileOffset++] = 19;
/* 6081 */       writeUnsignedShort(index);
/*      */     } else {
/*      */       
/* 6084 */       if (this.classFileOffset + 1 >= this.bCodeStream.length) {
/* 6085 */         resizeByteArray();
/*      */       }
/* 6087 */       this.position += 2;
/* 6088 */       this.bCodeStream[this.classFileOffset++] = 18;
/* 6089 */       this.bCodeStream[this.classFileOffset++] = (byte)index;
/*      */     } 
/*      */   }
/*      */   
/*      */   public void ldc2_w(double constant) {
/* 6094 */     this.countLabels = 0;
/* 6095 */     int index = this.constantPool.literalIndex(constant);
/* 6096 */     this.stackDepth += 2;
/* 6097 */     pushTypeBinding((TypeBinding)TypeBinding.DOUBLE);
/* 6098 */     if (this.stackDepth > this.stackMax) {
/* 6099 */       this.stackMax = this.stackDepth;
/*      */     }
/* 6101 */     if (this.classFileOffset + 2 >= this.bCodeStream.length) {
/* 6102 */       resizeByteArray();
/*      */     }
/* 6104 */     this.position++;
/* 6105 */     this.bCodeStream[this.classFileOffset++] = 20;
/* 6106 */     writeUnsignedShort(index);
/*      */   }
/*      */   
/*      */   public void ldc2_w(long constant) {
/* 6110 */     this.countLabels = 0;
/* 6111 */     int index = this.constantPool.literalIndex(constant);
/* 6112 */     this.stackDepth += 2;
/* 6113 */     pushTypeBinding((TypeBinding)TypeBinding.LONG);
/* 6114 */     if (this.stackDepth > this.stackMax) {
/* 6115 */       this.stackMax = this.stackDepth;
/*      */     }
/* 6117 */     if (this.classFileOffset + 2 >= this.bCodeStream.length) {
/* 6118 */       resizeByteArray();
/*      */     }
/* 6120 */     this.position++;
/* 6121 */     this.bCodeStream[this.classFileOffset++] = 20;
/* 6122 */     writeUnsignedShort(index);
/*      */   }
/*      */   
/*      */   public void ldcForIndex(int index) {
/* 6126 */     this.stackDepth++;
/* 6127 */     pushTypeBinding((TypeBinding)TypeBinding.INT);
/* 6128 */     if (this.stackDepth > this.stackMax) {
/* 6129 */       this.stackMax = this.stackDepth;
/*      */     }
/* 6131 */     if (index > 255) {
/*      */       
/* 6133 */       if (this.classFileOffset + 2 >= this.bCodeStream.length) {
/* 6134 */         resizeByteArray();
/*      */       }
/* 6136 */       this.position++;
/* 6137 */       this.bCodeStream[this.classFileOffset++] = 19;
/* 6138 */       writeUnsignedShort(index);
/*      */     } else {
/*      */       
/* 6141 */       if (this.classFileOffset + 1 >= this.bCodeStream.length) {
/* 6142 */         resizeByteArray();
/*      */       }
/* 6144 */       this.position += 2;
/* 6145 */       this.bCodeStream[this.classFileOffset++] = 18;
/* 6146 */       this.bCodeStream[this.classFileOffset++] = (byte)index;
/*      */     } 
/*      */   }
/*      */   
/*      */   public void ldiv() {
/* 6151 */     this.countLabels = 0;
/* 6152 */     this.stackDepth -= 2;
/* 6153 */     pushTypeBinding(2, (TypeBinding)TypeBinding.LONG);
/* 6154 */     if (this.classFileOffset >= this.bCodeStream.length) {
/* 6155 */       resizeByteArray();
/*      */     }
/* 6157 */     this.position++;
/* 6158 */     this.bCodeStream[this.classFileOffset++] = 109;
/*      */   }
/*      */   
/*      */   public void lload(int iArg) {
/* 6162 */     this.countLabels = 0;
/* 6163 */     this.stackDepth += 2;
/* 6164 */     if (this.maxLocals <= iArg + 1) {
/* 6165 */       this.maxLocals = iArg + 2;
/*      */     }
/* 6167 */     pushTypeBinding((TypeBinding)TypeBinding.LONG);
/* 6168 */     if (this.stackDepth > this.stackMax)
/* 6169 */       this.stackMax = this.stackDepth; 
/* 6170 */     if (iArg > 255) {
/* 6171 */       if (this.classFileOffset + 3 >= this.bCodeStream.length) {
/* 6172 */         resizeByteArray();
/*      */       }
/* 6174 */       this.position += 2;
/* 6175 */       this.bCodeStream[this.classFileOffset++] = -60;
/* 6176 */       this.bCodeStream[this.classFileOffset++] = 22;
/* 6177 */       writeUnsignedShort(iArg);
/*      */     } else {
/* 6179 */       if (this.classFileOffset + 1 >= this.bCodeStream.length) {
/* 6180 */         resizeByteArray();
/*      */       }
/* 6182 */       this.position += 2;
/* 6183 */       this.bCodeStream[this.classFileOffset++] = 22;
/* 6184 */       this.bCodeStream[this.classFileOffset++] = (byte)iArg;
/*      */     } 
/*      */   }
/*      */   
/*      */   public void lload_0() {
/* 6189 */     this.countLabels = 0;
/* 6190 */     this.stackDepth += 2;
/* 6191 */     pushTypeBinding((TypeBinding)TypeBinding.LONG);
/* 6192 */     if (this.maxLocals < 2) {
/* 6193 */       this.maxLocals = 2;
/*      */     }
/* 6195 */     if (this.stackDepth > this.stackMax)
/* 6196 */       this.stackMax = this.stackDepth; 
/* 6197 */     if (this.classFileOffset >= this.bCodeStream.length) {
/* 6198 */       resizeByteArray();
/*      */     }
/* 6200 */     this.position++;
/* 6201 */     this.bCodeStream[this.classFileOffset++] = 30;
/*      */   }
/*      */   
/*      */   public void lload_1() {
/* 6205 */     this.countLabels = 0;
/* 6206 */     this.stackDepth += 2;
/* 6207 */     pushTypeBinding((TypeBinding)TypeBinding.LONG);
/* 6208 */     if (this.maxLocals < 3) {
/* 6209 */       this.maxLocals = 3;
/*      */     }
/* 6211 */     if (this.stackDepth > this.stackMax)
/* 6212 */       this.stackMax = this.stackDepth; 
/* 6213 */     if (this.classFileOffset >= this.bCodeStream.length) {
/* 6214 */       resizeByteArray();
/*      */     }
/* 6216 */     this.position++;
/* 6217 */     this.bCodeStream[this.classFileOffset++] = 31;
/*      */   }
/*      */   
/*      */   public void lload_2() {
/* 6221 */     this.countLabels = 0;
/* 6222 */     this.stackDepth += 2;
/* 6223 */     pushTypeBinding((TypeBinding)TypeBinding.LONG);
/* 6224 */     if (this.maxLocals < 4) {
/* 6225 */       this.maxLocals = 4;
/*      */     }
/* 6227 */     if (this.stackDepth > this.stackMax)
/* 6228 */       this.stackMax = this.stackDepth; 
/* 6229 */     if (this.classFileOffset >= this.bCodeStream.length) {
/* 6230 */       resizeByteArray();
/*      */     }
/* 6232 */     this.position++;
/* 6233 */     this.bCodeStream[this.classFileOffset++] = 32;
/*      */   }
/*      */   
/*      */   public void lload_3() {
/* 6237 */     this.countLabels = 0;
/* 6238 */     this.stackDepth += 2;
/* 6239 */     pushTypeBinding((TypeBinding)TypeBinding.LONG);
/* 6240 */     if (this.maxLocals < 5) {
/* 6241 */       this.maxLocals = 5;
/*      */     }
/* 6243 */     if (this.stackDepth > this.stackMax)
/* 6244 */       this.stackMax = this.stackDepth; 
/* 6245 */     if (this.classFileOffset >= this.bCodeStream.length) {
/* 6246 */       resizeByteArray();
/*      */     }
/* 6248 */     this.position++;
/* 6249 */     this.bCodeStream[this.classFileOffset++] = 33;
/*      */   }
/*      */   
/*      */   public void lmul() {
/* 6253 */     this.countLabels = 0;
/* 6254 */     this.stackDepth -= 2;
/* 6255 */     pushTypeBinding(2, (TypeBinding)TypeBinding.LONG);
/* 6256 */     if (this.classFileOffset >= this.bCodeStream.length) {
/* 6257 */       resizeByteArray();
/*      */     }
/* 6259 */     this.position++;
/* 6260 */     this.bCodeStream[this.classFileOffset++] = 105;
/*      */   }
/*      */   
/*      */   public void lneg() {
/* 6264 */     this.countLabels = 0;
/* 6265 */     if (this.classFileOffset >= this.bCodeStream.length) {
/* 6266 */       resizeByteArray();
/*      */     }
/* 6268 */     this.position++;
/* 6269 */     this.bCodeStream[this.classFileOffset++] = 117;
/* 6270 */     pushTypeBinding(1, (TypeBinding)TypeBinding.LONG);
/*      */   }
/*      */   
/*      */   public final void load(LocalVariableBinding localBinding) {
/* 6274 */     load(localBinding.type, localBinding.resolvedPosition);
/*      */   }
/*      */   
/*      */   protected final void load(TypeBinding typeBinding, int resolvedPosition) {
/* 6278 */     this.countLabels = 0;
/*      */     
/* 6280 */     switch (typeBinding.id) {
/*      */       case 2:
/*      */       case 3:
/*      */       case 4:
/*      */       case 5:
/*      */       case 10:
/* 6286 */         switch (resolvedPosition) {
/*      */           case 0:
/* 6288 */             iload_0();
/*      */             return;
/*      */           case 1:
/* 6291 */             iload_1();
/*      */             return;
/*      */           case 2:
/* 6294 */             iload_2();
/*      */             return;
/*      */           case 3:
/* 6297 */             iload_3();
/*      */             return;
/*      */         } 
/*      */ 
/*      */ 
/*      */         
/* 6303 */         iload(resolvedPosition);
/*      */         return;
/*      */       
/*      */       case 9:
/* 6307 */         switch (resolvedPosition) {
/*      */           case 0:
/* 6309 */             fload_0();
/*      */             return;
/*      */           case 1:
/* 6312 */             fload_1();
/*      */             return;
/*      */           case 2:
/* 6315 */             fload_2();
/*      */             return;
/*      */           case 3:
/* 6318 */             fload_3();
/*      */             return;
/*      */         } 
/* 6321 */         fload(resolvedPosition);
/*      */         return;
/*      */       
/*      */       case 7:
/* 6325 */         switch (resolvedPosition) {
/*      */           case 0:
/* 6327 */             lload_0();
/*      */             return;
/*      */           case 1:
/* 6330 */             lload_1();
/*      */             return;
/*      */           case 2:
/* 6333 */             lload_2();
/*      */             return;
/*      */           case 3:
/* 6336 */             lload_3();
/*      */             return;
/*      */         } 
/* 6339 */         lload(resolvedPosition);
/*      */         return;
/*      */       
/*      */       case 8:
/* 6343 */         switch (resolvedPosition) {
/*      */           case 0:
/* 6345 */             dload_0();
/*      */             return;
/*      */           case 1:
/* 6348 */             dload_1();
/*      */             return;
/*      */           case 2:
/* 6351 */             dload_2();
/*      */             return;
/*      */           case 3:
/* 6354 */             dload_3();
/*      */             return;
/*      */         } 
/* 6357 */         dload(resolvedPosition);
/*      */         return;
/*      */     } 
/*      */     
/* 6361 */     switch (resolvedPosition) {
/*      */       case 0:
/* 6363 */         aload_0();
/*      */         return;
/*      */       case 1:
/* 6366 */         aload_1();
/*      */         return;
/*      */       case 2:
/* 6369 */         aload_2();
/*      */         return;
/*      */       case 3:
/* 6372 */         aload_3();
/*      */         return;
/*      */     } 
/* 6375 */     aload(resolvedPosition);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void lookupswitch(CaseLabel defaultLabel, int[] keys, int[] sortedIndexes, CaseLabel[] casesLabel) {
/* 6381 */     this.countLabels = 0;
/* 6382 */     this.stackDepth--;
/* 6383 */     popTypeBinding();
/* 6384 */     int length = keys.length;
/* 6385 */     int pos = this.position;
/* 6386 */     defaultLabel.placeInstruction(); int i;
/* 6387 */     for (i = 0; i < length; i++) {
/* 6388 */       casesLabel[i].placeInstruction();
/*      */     }
/* 6390 */     if (this.classFileOffset >= this.bCodeStream.length) {
/* 6391 */       resizeByteArray();
/*      */     }
/* 6393 */     this.position++;
/* 6394 */     this.bCodeStream[this.classFileOffset++] = -85;
/* 6395 */     for (i = 3 - (pos & 0x3); i > 0; i--) {
/* 6396 */       if (this.classFileOffset >= this.bCodeStream.length) {
/* 6397 */         resizeByteArray();
/*      */       }
/* 6399 */       this.position++;
/* 6400 */       this.bCodeStream[this.classFileOffset++] = 0;
/*      */     } 
/* 6402 */     defaultLabel.branch();
/* 6403 */     writeSignedWord(length);
/* 6404 */     for (i = 0; i < length; i++) {
/* 6405 */       writeSignedWord(keys[sortedIndexes[i]]);
/* 6406 */       casesLabel[sortedIndexes[i]].branch();
/*      */     } 
/*      */   }
/*      */   
/*      */   public void lor() {
/* 6411 */     this.countLabels = 0;
/* 6412 */     this.stackDepth -= 2;
/* 6413 */     pushTypeBinding(2, (TypeBinding)TypeBinding.LONG);
/* 6414 */     if (this.classFileOffset >= this.bCodeStream.length) {
/* 6415 */       resizeByteArray();
/*      */     }
/* 6417 */     this.position++;
/* 6418 */     this.bCodeStream[this.classFileOffset++] = -127;
/*      */   }
/*      */   
/*      */   public void lrem() {
/* 6422 */     this.countLabels = 0;
/* 6423 */     this.stackDepth -= 2;
/* 6424 */     pushTypeBinding(2, (TypeBinding)TypeBinding.LONG);
/* 6425 */     if (this.classFileOffset >= this.bCodeStream.length) {
/* 6426 */       resizeByteArray();
/*      */     }
/* 6428 */     this.position++;
/* 6429 */     this.bCodeStream[this.classFileOffset++] = 113;
/*      */   }
/*      */   
/*      */   public void lreturn() {
/* 6433 */     this.countLabels = 0;
/* 6434 */     this.stackDepth -= 2;
/* 6435 */     popTypeBinding();
/*      */     
/* 6437 */     if (this.classFileOffset >= this.bCodeStream.length) {
/* 6438 */       resizeByteArray();
/*      */     }
/* 6440 */     this.position++;
/* 6441 */     this.bCodeStream[this.classFileOffset++] = -83;
/* 6442 */     this.lastAbruptCompletion = this.position;
/*      */   }
/*      */   
/*      */   public void lshl() {
/* 6446 */     this.countLabels = 0;
/* 6447 */     this.stackDepth--;
/* 6448 */     pushTypeBinding(2, (TypeBinding)TypeBinding.LONG);
/* 6449 */     if (this.classFileOffset >= this.bCodeStream.length) {
/* 6450 */       resizeByteArray();
/*      */     }
/* 6452 */     this.position++;
/* 6453 */     this.bCodeStream[this.classFileOffset++] = 121;
/*      */   }
/*      */   
/*      */   public void lshr() {
/* 6457 */     this.countLabels = 0;
/* 6458 */     this.stackDepth--;
/* 6459 */     pushTypeBinding(2, (TypeBinding)TypeBinding.LONG);
/* 6460 */     if (this.classFileOffset >= this.bCodeStream.length) {
/* 6461 */       resizeByteArray();
/*      */     }
/* 6463 */     this.position++;
/* 6464 */     this.bCodeStream[this.classFileOffset++] = 123;
/*      */   }
/*      */   
/*      */   public void lstore(int iArg) {
/* 6468 */     this.countLabels = 0;
/* 6469 */     this.stackDepth -= 2;
/* 6470 */     popTypeBinding();
/* 6471 */     if (this.maxLocals <= iArg + 1) {
/* 6472 */       this.maxLocals = iArg + 2;
/*      */     }
/* 6474 */     if (iArg > 255) {
/* 6475 */       if (this.classFileOffset + 3 >= this.bCodeStream.length) {
/* 6476 */         resizeByteArray();
/*      */       }
/* 6478 */       this.position += 2;
/* 6479 */       this.bCodeStream[this.classFileOffset++] = -60;
/* 6480 */       this.bCodeStream[this.classFileOffset++] = 55;
/* 6481 */       writeUnsignedShort(iArg);
/*      */     } else {
/* 6483 */       if (this.classFileOffset + 1 >= this.bCodeStream.length) {
/* 6484 */         resizeByteArray();
/*      */       }
/* 6486 */       this.position += 2;
/* 6487 */       this.bCodeStream[this.classFileOffset++] = 55;
/* 6488 */       this.bCodeStream[this.classFileOffset++] = (byte)iArg;
/*      */     } 
/*      */   }
/*      */   
/*      */   public void lstore_0() {
/* 6493 */     this.countLabels = 0;
/* 6494 */     this.stackDepth -= 2;
/* 6495 */     popTypeBinding();
/* 6496 */     if (this.maxLocals < 2) {
/* 6497 */       this.maxLocals = 2;
/*      */     }
/* 6499 */     if (this.classFileOffset >= this.bCodeStream.length) {
/* 6500 */       resizeByteArray();
/*      */     }
/* 6502 */     this.position++;
/* 6503 */     this.bCodeStream[this.classFileOffset++] = 63;
/*      */   }
/*      */   
/*      */   public void lstore_1() {
/* 6507 */     this.countLabels = 0;
/* 6508 */     this.stackDepth -= 2;
/* 6509 */     popTypeBinding();
/* 6510 */     if (this.maxLocals < 3) {
/* 6511 */       this.maxLocals = 3;
/*      */     }
/* 6513 */     if (this.classFileOffset >= this.bCodeStream.length) {
/* 6514 */       resizeByteArray();
/*      */     }
/* 6516 */     this.position++;
/* 6517 */     this.bCodeStream[this.classFileOffset++] = 64;
/*      */   }
/*      */   
/*      */   public void lstore_2() {
/* 6521 */     this.countLabels = 0;
/* 6522 */     this.stackDepth -= 2;
/* 6523 */     popTypeBinding();
/* 6524 */     if (this.maxLocals < 4) {
/* 6525 */       this.maxLocals = 4;
/*      */     }
/* 6527 */     if (this.classFileOffset >= this.bCodeStream.length) {
/* 6528 */       resizeByteArray();
/*      */     }
/* 6530 */     this.position++;
/* 6531 */     this.bCodeStream[this.classFileOffset++] = 65;
/*      */   }
/*      */   
/*      */   public void lstore_3() {
/* 6535 */     this.countLabels = 0;
/* 6536 */     this.stackDepth -= 2;
/* 6537 */     popTypeBinding();
/* 6538 */     if (this.maxLocals < 5) {
/* 6539 */       this.maxLocals = 5;
/*      */     }
/* 6541 */     if (this.classFileOffset >= this.bCodeStream.length) {
/* 6542 */       resizeByteArray();
/*      */     }
/* 6544 */     this.position++;
/* 6545 */     this.bCodeStream[this.classFileOffset++] = 66;
/*      */   }
/*      */   
/*      */   public void lsub() {
/* 6549 */     this.countLabels = 0;
/* 6550 */     this.stackDepth -= 2;
/* 6551 */     pushTypeBinding(2, (TypeBinding)TypeBinding.LONG);
/* 6552 */     if (this.classFileOffset >= this.bCodeStream.length) {
/* 6553 */       resizeByteArray();
/*      */     }
/* 6555 */     this.position++;
/* 6556 */     this.bCodeStream[this.classFileOffset++] = 101;
/*      */   }
/*      */   
/*      */   public void lushr() {
/* 6560 */     this.countLabels = 0;
/* 6561 */     this.stackDepth--;
/* 6562 */     pushTypeBinding(2, (TypeBinding)TypeBinding.LONG);
/* 6563 */     if (this.classFileOffset >= this.bCodeStream.length) {
/* 6564 */       resizeByteArray();
/*      */     }
/* 6566 */     this.position++;
/* 6567 */     this.bCodeStream[this.classFileOffset++] = 125;
/*      */   }
/*      */   
/*      */   public void lxor() {
/* 6571 */     this.countLabels = 0;
/* 6572 */     this.stackDepth -= 2;
/* 6573 */     pushTypeBinding(2, (TypeBinding)TypeBinding.LONG);
/* 6574 */     if (this.classFileOffset >= this.bCodeStream.length) {
/* 6575 */       resizeByteArray();
/*      */     }
/* 6577 */     this.position++;
/* 6578 */     this.bCodeStream[this.classFileOffset++] = -125;
/*      */   }
/*      */   
/*      */   public void monitorenter() {
/* 6582 */     this.countLabels = 0;
/* 6583 */     this.stackDepth--;
/* 6584 */     popTypeBinding();
/* 6585 */     if (this.classFileOffset >= this.bCodeStream.length) {
/* 6586 */       resizeByteArray();
/*      */     }
/* 6588 */     this.position++;
/* 6589 */     this.bCodeStream[this.classFileOffset++] = -62;
/*      */   }
/*      */   
/*      */   public void monitorexit() {
/* 6593 */     this.countLabels = 0;
/* 6594 */     this.stackDepth--;
/* 6595 */     popTypeBinding();
/* 6596 */     if (this.classFileOffset >= this.bCodeStream.length) {
/* 6597 */       resizeByteArray();
/*      */     }
/* 6599 */     this.position++;
/* 6600 */     this.bCodeStream[this.classFileOffset++] = -61;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void multianewarray(TypeReference typeReference, TypeBinding typeBinding, int dimensions, ArrayAllocationExpression allocationExpression) {
/* 6608 */     this.countLabels = 0;
/* 6609 */     this.stackDepth += 1 - dimensions;
/* 6610 */     pushTypeBinding(dimensions, typeBinding);
/* 6611 */     if (this.classFileOffset + 3 >= this.bCodeStream.length) {
/* 6612 */       resizeByteArray();
/*      */     }
/* 6614 */     this.position += 2;
/* 6615 */     this.bCodeStream[this.classFileOffset++] = -59;
/* 6616 */     writeUnsignedShort(this.constantPool.literalIndexForType(typeBinding));
/* 6617 */     this.bCodeStream[this.classFileOffset++] = (byte)dimensions;
/*      */   }
/*      */ 
/*      */   
/*      */   public void new_(TypeBinding typeBinding) {
/* 6622 */     new_(null, typeBinding);
/*      */   }
/*      */ 
/*      */   
/*      */   public void new_(TypeReference typeReference, TypeBinding typeBinding) {
/* 6627 */     this.countLabels = 0;
/* 6628 */     this.stackDepth++;
/* 6629 */     pushTypeBinding(typeBinding);
/* 6630 */     if (this.stackDepth > this.stackMax)
/* 6631 */       this.stackMax = this.stackDepth; 
/* 6632 */     if (this.classFileOffset + 3 >= this.bCodeStream.length) {
/* 6633 */       resizeByteArray();
/*      */     }
/* 6635 */     this.position++;
/* 6636 */     this.bCodeStream[this.classFileOffset++] = -69;
/* 6637 */     writeUnsignedShort(this.constantPool.literalIndexForType(typeBinding));
/*      */   }
/*      */   
/*      */   public void newarray(int array_Type) {
/* 6641 */     this.countLabels = 0;
/* 6642 */     if (this.classFileOffset + 1 >= this.bCodeStream.length) {
/* 6643 */       resizeByteArray();
/*      */     }
/* 6645 */     this.position += 2;
/* 6646 */     this.bCodeStream[this.classFileOffset++] = -68;
/* 6647 */     this.bCodeStream[this.classFileOffset++] = (byte)array_Type;
/* 6648 */     pushTypeBinding(1, TypeBinding.wellKnownBaseType(array_Type));
/*      */   }
/*      */   
/*      */   public void newArray(ArrayBinding arrayBinding) {
/* 6652 */     newArray(null, null, arrayBinding);
/*      */   }
/*      */   
/*      */   public void newArray(TypeReference typeReference, ArrayAllocationExpression allocationExpression, ArrayBinding arrayBinding) {
/* 6656 */     TypeBinding component = arrayBinding.elementsType();
/* 6657 */     switch (component.id) {
/*      */       case 10:
/* 6659 */         newarray(10);
/*      */         return;
/*      */       case 3:
/* 6662 */         newarray(8);
/*      */         return;
/*      */       case 5:
/* 6665 */         newarray(4);
/*      */         return;
/*      */       case 4:
/* 6668 */         newarray(9);
/*      */         return;
/*      */       case 2:
/* 6671 */         newarray(5);
/*      */         return;
/*      */       case 7:
/* 6674 */         newarray(11);
/*      */         return;
/*      */       case 9:
/* 6677 */         newarray(6);
/*      */         return;
/*      */       case 8:
/* 6680 */         newarray(7);
/*      */         return;
/*      */     } 
/* 6683 */     anewarray(component);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void newJavaLangAssertionError() {
/* 6689 */     this.countLabels = 0;
/* 6690 */     this.stackDepth++;
/* 6691 */     pushTypeBinding(ConstantPool.JavaLangAssertionErrorConstantPoolName);
/* 6692 */     if (this.stackDepth > this.stackMax)
/* 6693 */       this.stackMax = this.stackDepth; 
/* 6694 */     if (this.classFileOffset + 2 >= this.bCodeStream.length) {
/* 6695 */       resizeByteArray();
/*      */     }
/* 6697 */     this.position++;
/* 6698 */     this.bCodeStream[this.classFileOffset++] = -69;
/* 6699 */     writeUnsignedShort(this.constantPool.literalIndexForType(ConstantPool.JavaLangAssertionErrorConstantPoolName));
/*      */   }
/*      */ 
/*      */   
/*      */   public void newJavaLangError() {
/* 6704 */     this.countLabels = 0;
/* 6705 */     this.stackDepth++;
/* 6706 */     pushTypeBinding(ConstantPool.JavaLangErrorConstantPoolName);
/* 6707 */     if (this.stackDepth > this.stackMax)
/* 6708 */       this.stackMax = this.stackDepth; 
/* 6709 */     if (this.classFileOffset + 2 >= this.bCodeStream.length) {
/* 6710 */       resizeByteArray();
/*      */     }
/* 6712 */     this.position++;
/* 6713 */     this.bCodeStream[this.classFileOffset++] = -69;
/* 6714 */     writeUnsignedShort(this.constantPool.literalIndexForType(ConstantPool.JavaLangErrorConstantPoolName));
/*      */   }
/*      */   
/*      */   public void newJavaLangIncompatibleClassChangeError() {
/* 6718 */     this.countLabels = 0;
/* 6719 */     this.stackDepth++;
/* 6720 */     pushTypeBinding(ConstantPool.JavaLangIncompatibleClassChangeErrorConstantPoolName);
/* 6721 */     if (this.stackDepth > this.stackMax)
/* 6722 */       this.stackMax = this.stackDepth; 
/* 6723 */     if (this.classFileOffset + 2 >= this.bCodeStream.length) {
/* 6724 */       resizeByteArray();
/*      */     }
/* 6726 */     this.position++;
/* 6727 */     this.bCodeStream[this.classFileOffset++] = -69;
/* 6728 */     writeUnsignedShort(this.constantPool.literalIndexForType(ConstantPool.JavaLangIncompatibleClassChangeErrorConstantPoolName));
/*      */   }
/*      */   
/*      */   public void newJavaLangMatchException() {
/* 6732 */     this.countLabels = 0;
/* 6733 */     this.stackDepth++;
/* 6734 */     pushTypeBinding(ConstantPool.JavaLangMatchExceptionConstantPoolName);
/* 6735 */     if (this.stackDepth > this.stackMax)
/* 6736 */       this.stackMax = this.stackDepth; 
/* 6737 */     if (this.classFileOffset + 2 >= this.bCodeStream.length) {
/* 6738 */       resizeByteArray();
/*      */     }
/* 6740 */     this.position++;
/* 6741 */     this.bCodeStream[this.classFileOffset++] = -69;
/* 6742 */     writeUnsignedShort(this.constantPool.literalIndexForType(ConstantPool.JavaLangMatchExceptionConstantPoolName));
/*      */   }
/*      */   
/*      */   public void invokeJavaLangMatchExceptionConstructor() {
/* 6746 */     invoke((byte)
/* 6747 */         -73, 
/* 6748 */         3, 
/* 6749 */         0, 
/* 6750 */         ConstantPool.JavaLangMatchExceptionConstantPoolName, 
/* 6751 */         ConstantPool.Init, 
/* 6752 */         ConstantPool.JavaLangMatchExceptionNewInstanceSignature, 
/* 6753 */         null);
/*      */   }
/*      */   
/*      */   public void newNoClassDefFoundError() {
/* 6757 */     this.countLabels = 0;
/* 6758 */     this.stackDepth++;
/* 6759 */     pushTypeBinding(ConstantPool.JavaLangNoClassDefFoundErrorConstantPoolName);
/* 6760 */     if (this.stackDepth > this.stackMax)
/* 6761 */       this.stackMax = this.stackDepth; 
/* 6762 */     if (this.classFileOffset + 2 >= this.bCodeStream.length) {
/* 6763 */       resizeByteArray();
/*      */     }
/* 6765 */     this.position++;
/* 6766 */     this.bCodeStream[this.classFileOffset++] = -69;
/* 6767 */     writeUnsignedShort(this.constantPool.literalIndexForType(ConstantPool.JavaLangNoClassDefFoundErrorConstantPoolName));
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void newStringContatenation() {
/* 6773 */     this.countLabels = 0;
/* 6774 */     this.stackDepth++;
/* 6775 */     pushTypeBinding(ConstantPool.JavaLangStringBufferConstantPoolName);
/* 6776 */     if (this.stackDepth > this.stackMax) {
/* 6777 */       this.stackMax = this.stackDepth;
/*      */     }
/* 6779 */     if (this.classFileOffset + 2 >= this.bCodeStream.length) {
/* 6780 */       resizeByteArray();
/*      */     }
/* 6782 */     this.position++;
/* 6783 */     this.bCodeStream[this.classFileOffset++] = -69;
/* 6784 */     if (this.targetLevel >= 3211264L) {
/* 6785 */       writeUnsignedShort(this.constantPool.literalIndexForType(ConstantPool.JavaLangStringBuilderConstantPoolName));
/*      */     } else {
/* 6787 */       writeUnsignedShort(this.constantPool.literalIndexForType(ConstantPool.JavaLangStringBufferConstantPoolName));
/*      */     } 
/*      */   }
/*      */   
/*      */   public void newWrapperFor(int typeID) {
/* 6792 */     this.countLabels = 0;
/* 6793 */     this.stackDepth++;
/* 6794 */     if (this.stackDepth > this.stackMax)
/* 6795 */       this.stackMax = this.stackDepth; 
/* 6796 */     if (this.classFileOffset + 2 >= this.bCodeStream.length) {
/* 6797 */       resizeByteArray();
/*      */     }
/* 6799 */     this.position++;
/* 6800 */     this.bCodeStream[this.classFileOffset++] = -69;
/* 6801 */     switch (typeID) {
/*      */       case 10:
/* 6803 */         writeUnsignedShort(this.constantPool.literalIndexForType(ConstantPool.JavaLangIntegerConstantPoolName));
/* 6804 */         pushTypeBinding(ConstantPool.JavaLangIntegerConstantPoolName);
/*      */         break;
/*      */       case 5:
/* 6807 */         writeUnsignedShort(this.constantPool.literalIndexForType(ConstantPool.JavaLangBooleanConstantPoolName));
/* 6808 */         pushTypeBinding(ConstantPool.JavaLangBooleanConstantPoolName);
/*      */         break;
/*      */       case 3:
/* 6811 */         writeUnsignedShort(this.constantPool.literalIndexForType(ConstantPool.JavaLangByteConstantPoolName));
/* 6812 */         pushTypeBinding(ConstantPool.JavaLangByteConstantPoolName);
/*      */         break;
/*      */       case 2:
/* 6815 */         writeUnsignedShort(this.constantPool.literalIndexForType(ConstantPool.JavaLangCharacterConstantPoolName));
/* 6816 */         pushTypeBinding(ConstantPool.JavaLangCharacterConstantPoolName);
/*      */         break;
/*      */       case 9:
/* 6819 */         writeUnsignedShort(this.constantPool.literalIndexForType(ConstantPool.JavaLangFloatConstantPoolName));
/* 6820 */         pushTypeBinding(ConstantPool.JavaLangFloatConstantPoolName);
/*      */         break;
/*      */       case 8:
/* 6823 */         writeUnsignedShort(this.constantPool.literalIndexForType(ConstantPool.JavaLangDoubleConstantPoolName));
/* 6824 */         pushTypeBinding(ConstantPool.JavaLangDoubleConstantPoolName);
/*      */         break;
/*      */       case 4:
/* 6827 */         writeUnsignedShort(this.constantPool.literalIndexForType(ConstantPool.JavaLangShortConstantPoolName));
/* 6828 */         pushTypeBinding(ConstantPool.JavaLangShortConstantPoolName);
/*      */         break;
/*      */       case 7:
/* 6831 */         writeUnsignedShort(this.constantPool.literalIndexForType(ConstantPool.JavaLangLongConstantPoolName));
/* 6832 */         pushTypeBinding(ConstantPool.JavaLangLongConstantPoolName);
/*      */         break;
/*      */       case 6:
/* 6835 */         writeUnsignedShort(this.constantPool.literalIndexForType(ConstantPool.JavaLangVoidConstantPoolName));
/* 6836 */         pushTypeBinding(ConstantPool.JavaLangVoidConstantPoolName);
/*      */         break;
/*      */     } 
/*      */   }
/*      */   public void nop() {
/* 6841 */     this.countLabels = 0;
/* 6842 */     if (this.classFileOffset >= this.bCodeStream.length) {
/* 6843 */       resizeByteArray();
/*      */     }
/* 6845 */     this.position++;
/* 6846 */     this.bCodeStream[this.classFileOffset++] = 0;
/*      */   }
/*      */   
/*      */   public void optimizeBranch(int oldPosition, BranchLabel lbl) {
/* 6850 */     for (int i = 0; i < this.countLabels; i++) {
/* 6851 */       BranchLabel label = this.labels[i];
/* 6852 */       if (oldPosition == label.position) {
/* 6853 */         label.position = this.position;
/* 6854 */         if (label instanceof CaseLabel) {
/* 6855 */           int offset = this.position - ((CaseLabel)label).instructionPosition;
/* 6856 */           int[] forwardRefs = label.forwardReferences();
/* 6857 */           for (int j = 0, length = label.forwardReferenceCount(); j < length; j++) {
/* 6858 */             int forwardRef = forwardRefs[j];
/* 6859 */             writeSignedWord(forwardRef, offset);
/*      */           } 
/*      */         } else {
/* 6862 */           int[] forwardRefs = label.forwardReferences();
/* 6863 */           for (int j = 0, length = label.forwardReferenceCount(); j < length; j++) {
/* 6864 */             int forwardRef = forwardRefs[j];
/* 6865 */             writePosition(lbl, forwardRef);
/*      */           } 
/*      */         } 
/*      */       } 
/*      */     } 
/*      */   }
/*      */   
/*      */   public void pop() {
/* 6873 */     this.countLabels = 0;
/* 6874 */     this.stackDepth--;
/* 6875 */     popTypeBinding();
/* 6876 */     if (this.classFileOffset >= this.bCodeStream.length) {
/* 6877 */       resizeByteArray();
/*      */     }
/* 6879 */     this.position++;
/* 6880 */     this.bCodeStream[this.classFileOffset++] = 87;
/*      */   }
/*      */   
/*      */   private void adjustTypeBindingStackForPop2() {
/* 6884 */     if (!isSwitchStackTrackingActive())
/*      */       return; 
/* 6886 */     TypeBinding v1 = this.switchSaveTypeBindings.peek();
/* 6887 */     if (TypeIds.getCategory(v1.id) == 1) {
/* 6888 */       TypeBinding v2 = this.switchSaveTypeBindings.peek();
/* 6889 */       if (TypeIds.getCategory(v2.id) == 1) {
/* 6890 */         popTypeBinding(2);
/*      */       }
/*      */     } else {
/* 6893 */       popTypeBinding();
/*      */     } 
/*      */   }
/*      */   public void pop2() {
/* 6897 */     this.countLabels = 0;
/* 6898 */     this.stackDepth -= 2;
/* 6899 */     adjustTypeBindingStackForPop2();
/* 6900 */     if (this.classFileOffset >= this.bCodeStream.length) {
/* 6901 */       resizeByteArray();
/*      */     }
/* 6903 */     this.position++;
/* 6904 */     this.bCodeStream[this.classFileOffset++] = 88;
/*      */   }
/*      */   
/*      */   public void pushExceptionOnStack(TypeBinding binding) {
/* 6908 */     this.stackDepth = 1;
/*      */     
/* 6910 */     pushTypeBinding(binding);
/* 6911 */     if (this.stackDepth > this.stackMax)
/* 6912 */       this.stackMax = this.stackDepth; 
/*      */   }
/*      */   
/*      */   public void pushOnStack(TypeBinding binding) {
/* 6916 */     if (++this.stackDepth > this.stackMax)
/* 6917 */       this.stackMax = this.stackDepth; 
/* 6918 */     pushTypeBinding(binding);
/*      */   }
/*      */   
/*      */   public void record(LocalVariableBinding local) {
/* 6922 */     if ((this.generateAttributes & 0x1C) == 0) {
/*      */       return;
/*      */     }
/*      */     
/* 6926 */     if (this.allLocalsCounter == this.locals.length)
/*      */     {
/* 6928 */       System.arraycopy(this.locals, 0, this.locals = new LocalVariableBinding[this.allLocalsCounter + 10], 0, this.allLocalsCounter);
/*      */     }
/* 6930 */     this.locals[this.allLocalsCounter++] = local;
/* 6931 */     local.initializationPCs = new int[4];
/* 6932 */     local.initializationCount = 0;
/*      */   }
/*      */ 
/*      */   
/*      */   public void recordExpressionType(TypeBinding typeBinding) {}
/*      */ 
/*      */   
/*      */   public void recordExpressionType(TypeBinding typeBinding, int delta, boolean adjustStackDepth) {}
/*      */   
/*      */   public void recordPositionsFrom(int startPC, int sourcePos) {
/* 6942 */     recordPositionsFrom(startPC, sourcePos, false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void recordPositionsFrom(int startPC, int sourcePos, boolean widen) {
/* 6951 */     if ((this.generateAttributes & 0x2) == 0 || 
/* 6952 */       sourcePos == 0 || (
/* 6953 */       startPC == this.position && !widen) || 
/* 6954 */       startPC > this.position) {
/*      */       return;
/*      */     }
/*      */     
/* 6958 */     if (this.pcToSourceMapSize + 4 > this.pcToSourceMap.length)
/*      */     {
/* 6960 */       System.arraycopy(this.pcToSourceMap, 0, this.pcToSourceMap = new int[this.pcToSourceMapSize << 1], 0, this.pcToSourceMapSize);
/*      */     }
/*      */     
/* 6963 */     if (this.pcToSourceMapSize > 0) {
/* 6964 */       int lineNumber = -1;
/* 6965 */       int previousLineNumber = this.pcToSourceMap[this.pcToSourceMapSize - 1];
/* 6966 */       if (this.lineNumberStart == this.lineNumberEnd) {
/*      */         
/* 6968 */         lineNumber = this.lineNumberStart;
/*      */       } else {
/*      */         
/* 6971 */         int[] lineSeparatorPositions2 = this.lineSeparatorPositions;
/* 6972 */         int length = lineSeparatorPositions2.length;
/* 6973 */         if (previousLineNumber == 1) {
/* 6974 */           if (sourcePos < lineSeparatorPositions2[0]) {
/* 6975 */             lineNumber = 1;
/* 6976 */           } else if (length == 1 || sourcePos < lineSeparatorPositions2[1]) {
/* 6977 */             lineNumber = 2;
/*      */           } 
/* 6979 */         } else if (previousLineNumber < length) {
/* 6980 */           if (lineSeparatorPositions2[previousLineNumber - 2] < sourcePos) {
/* 6981 */             if (sourcePos < lineSeparatorPositions2[previousLineNumber - 1]) {
/* 6982 */               lineNumber = previousLineNumber;
/* 6983 */             } else if (sourcePos < lineSeparatorPositions2[previousLineNumber]) {
/* 6984 */               lineNumber = previousLineNumber + 1;
/*      */             } 
/*      */           }
/* 6987 */         } else if (lineSeparatorPositions2[length - 1] < sourcePos) {
/* 6988 */           lineNumber = length + 1;
/*      */         } 
/* 6990 */         if (lineNumber == -1)
/*      */         {
/* 6992 */           lineNumber = Util.getLineNumber(sourcePos, lineSeparatorPositions2, this.lineNumberStart - 1, this.lineNumberEnd - 1);
/*      */         }
/*      */       } 
/*      */       
/* 6996 */       if (previousLineNumber != lineNumber) {
/* 6997 */         if (startPC <= this.lastEntryPC) {
/*      */ 
/*      */           
/* 7000 */           int insertionIndex = insertionIndex(this.pcToSourceMap, this.pcToSourceMapSize, startPC);
/* 7001 */           if (insertionIndex != -1) {
/*      */             
/* 7003 */             if (insertionIndex <= 1 || this.pcToSourceMap[insertionIndex - 1] != lineNumber) {
/* 7004 */               if (insertionIndex < this.pcToSourceMapSize && this.pcToSourceMap[insertionIndex + 1] == lineNumber) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */                 
/* 7015 */                 this.pcToSourceMap[insertionIndex] = startPC;
/*      */               } else {
/*      */                 
/* 7018 */                 System.arraycopy(this.pcToSourceMap, insertionIndex, this.pcToSourceMap, insertionIndex + 2, this.pcToSourceMapSize - insertionIndex);
/* 7019 */                 this.pcToSourceMap[insertionIndex++] = startPC;
/* 7020 */                 this.pcToSourceMap[insertionIndex] = lineNumber;
/* 7021 */                 this.pcToSourceMapSize += 2;
/*      */               } 
/*      */             }
/* 7024 */           } else if (this.position != this.lastEntryPC) {
/* 7025 */             if (this.lastEntryPC == startPC || this.lastEntryPC == this.pcToSourceMap[this.pcToSourceMapSize - 2]) {
/* 7026 */               this.pcToSourceMap[this.pcToSourceMapSize - 1] = lineNumber;
/*      */             } else {
/* 7028 */               this.pcToSourceMap[this.pcToSourceMapSize++] = this.lastEntryPC;
/* 7029 */               this.pcToSourceMap[this.pcToSourceMapSize++] = lineNumber;
/*      */             } 
/* 7031 */           } else if (this.pcToSourceMap[this.pcToSourceMapSize - 1] < lineNumber && widen) {
/*      */             
/* 7033 */             this.pcToSourceMap[this.pcToSourceMapSize - 1] = lineNumber;
/*      */           } 
/*      */         } else {
/*      */           
/* 7037 */           this.pcToSourceMap[this.pcToSourceMapSize++] = startPC;
/* 7038 */           this.pcToSourceMap[this.pcToSourceMapSize++] = lineNumber;
/*      */         
/*      */         }
/*      */ 
/*      */       
/*      */       }
/* 7044 */       else if (startPC < this.pcToSourceMap[this.pcToSourceMapSize - 2]) {
/* 7045 */         int insertionIndex = insertionIndex(this.pcToSourceMap, this.pcToSourceMapSize, startPC);
/* 7046 */         if (insertionIndex != -1)
/*      */         {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 7054 */           if (insertionIndex <= 1 || this.pcToSourceMap[insertionIndex - 1] != lineNumber) {
/* 7055 */             if (this.pcToSourceMap[insertionIndex + 1] != lineNumber) {
/* 7056 */               System.arraycopy(this.pcToSourceMap, insertionIndex, this.pcToSourceMap, insertionIndex + 2, this.pcToSourceMapSize - insertionIndex);
/* 7057 */               this.pcToSourceMap[insertionIndex++] = startPC;
/* 7058 */               this.pcToSourceMap[insertionIndex] = lineNumber;
/* 7059 */               this.pcToSourceMapSize += 2;
/*      */             } else {
/* 7061 */               this.pcToSourceMap[insertionIndex] = startPC;
/*      */             } 
/*      */           }
/*      */         }
/*      */       } 
/*      */       
/* 7067 */       this.lastEntryPC = this.position;
/*      */     } else {
/* 7069 */       int lineNumber = 0;
/* 7070 */       if (this.lineNumberStart == this.lineNumberEnd) {
/*      */         
/* 7072 */         lineNumber = this.lineNumberStart;
/*      */       } else {
/*      */         
/* 7075 */         lineNumber = Util.getLineNumber(sourcePos, this.lineSeparatorPositions, this.lineNumberStart - 1, this.lineNumberEnd - 1);
/*      */       } 
/*      */       
/* 7078 */       this.pcToSourceMap[this.pcToSourceMapSize++] = startPC;
/* 7079 */       this.pcToSourceMap[this.pcToSourceMapSize++] = lineNumber;
/* 7080 */       this.lastEntryPC = this.position;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void registerExceptionHandler(ExceptionLabel anExceptionLabel) {
/*      */     int length;
/* 7088 */     if (this.exceptionLabelsCounter == (length = this.exceptionLabels.length))
/*      */     {
/* 7090 */       System.arraycopy(this.exceptionLabels, 0, this.exceptionLabels = new ExceptionLabel[length + 5], 0, length);
/*      */     }
/*      */     
/* 7093 */     this.exceptionLabels[this.exceptionLabelsCounter++] = anExceptionLabel;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void removeNotDefinitelyAssignedVariables(Scope scope, int initStateIndex) {
/* 7099 */     if ((this.generateAttributes & 0x1C) == 0) {
/*      */       return;
/*      */     }
/*      */     
/* 7103 */     for (int i = 0; i < this.visibleLocalsCount; i++) {
/* 7104 */       LocalVariableBinding localBinding = this.visibleLocals[i];
/* 7105 */       if (localBinding != null && !isDefinitelyAssigned(scope, initStateIndex, localBinding) && localBinding.initializationCount > 0) {
/* 7106 */         localBinding.recordInitializationEndPC(this.position);
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void removeUnusedPcToSourceMapEntries() {
/* 7115 */     if (this.pcToSourceMapSize != 0)
/* 7116 */       while (this.pcToSourceMapSize >= 2 && this.pcToSourceMap[this.pcToSourceMapSize - 2] > this.position) {
/* 7117 */         this.pcToSourceMapSize -= 2;
/*      */       } 
/*      */   }
/*      */   
/*      */   public void removeVariable(LocalVariableBinding localBinding) {
/* 7122 */     if (localBinding == null)
/* 7123 */       return;  if (localBinding.initializationCount > 0) {
/* 7124 */       localBinding.recordInitializationEndPC(this.position);
/*      */     }
/* 7126 */     for (int i = this.visibleLocalsCount - 1; i >= 0; i--) {
/* 7127 */       LocalVariableBinding visibleLocal = this.visibleLocals[i];
/* 7128 */       if (visibleLocal == localBinding) {
/* 7129 */         this.visibleLocals[i] = null;
/*      */         return;
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void reset(AbstractMethodDeclaration referenceMethod, ClassFile targetClassFile) {
/* 7140 */     init(targetClassFile);
/* 7141 */     this.methodDeclaration = referenceMethod;
/* 7142 */     this.lambdaExpression = null;
/* 7143 */     int[] lineSeparatorPositions2 = this.lineSeparatorPositions;
/* 7144 */     if (lineSeparatorPositions2 != null) {
/* 7145 */       int length = lineSeparatorPositions2.length;
/* 7146 */       int lineSeparatorPositionsEnd = length - 1;
/* 7147 */       if (referenceMethod.isClinit() || 
/* 7148 */         referenceMethod.isConstructor()) {
/* 7149 */         this.lineNumberStart = 1;
/* 7150 */         this.lineNumberEnd = (length == 0) ? 1 : length;
/*      */       } else {
/* 7152 */         int start = Util.getLineNumber(referenceMethod.bodyStart, lineSeparatorPositions2, 0, lineSeparatorPositionsEnd);
/* 7153 */         this.lineNumberStart = start;
/* 7154 */         if (start > lineSeparatorPositionsEnd) {
/* 7155 */           this.lineNumberEnd = start;
/*      */         } else {
/* 7157 */           int end = Util.getLineNumber(referenceMethod.bodyEnd, lineSeparatorPositions2, start - 1, lineSeparatorPositionsEnd);
/* 7158 */           if (end >= lineSeparatorPositionsEnd) {
/* 7159 */             end = length;
/*      */           }
/* 7161 */           this.lineNumberEnd = (end == 0) ? 1 : end;
/*      */         } 
/*      */       } 
/*      */     } 
/* 7165 */     this.preserveUnusedLocals = (referenceMethod.scope.compilerOptions()).preserveAllLocalVariables;
/* 7166 */     initializeMaxLocals(referenceMethod.binding);
/*      */   }
/*      */   
/*      */   public void reset(LambdaExpression lambda, ClassFile targetClassFile) {
/* 7170 */     init(targetClassFile);
/* 7171 */     this.lambdaExpression = lambda;
/* 7172 */     this.methodDeclaration = null;
/* 7173 */     int[] lineSeparatorPositions2 = this.lineSeparatorPositions;
/* 7174 */     if (lineSeparatorPositions2 != null) {
/* 7175 */       int length = lineSeparatorPositions2.length;
/* 7176 */       int lineSeparatorPositionsEnd = length - 1;
/* 7177 */       int start = Util.getLineNumber((lambda.body()).sourceStart, lineSeparatorPositions2, 0, lineSeparatorPositionsEnd);
/* 7178 */       this.lineNumberStart = start;
/* 7179 */       if (start > lineSeparatorPositionsEnd) {
/* 7180 */         this.lineNumberEnd = start;
/*      */       } else {
/* 7182 */         int end = Util.getLineNumber((lambda.body()).sourceEnd, lineSeparatorPositions2, start - 1, lineSeparatorPositionsEnd);
/* 7183 */         if (end >= lineSeparatorPositionsEnd) {
/* 7184 */           end = length;
/*      */         }
/* 7186 */         this.lineNumberEnd = (end == 0) ? 1 : end;
/*      */       } 
/*      */     } 
/*      */     
/* 7190 */     this.preserveUnusedLocals = (lambda.scope.compilerOptions()).preserveAllLocalVariables;
/* 7191 */     initializeMaxLocals(lambda.binding);
/*      */   }
/*      */   
/*      */   public void reset(ClassFile givenClassFile) {
/* 7195 */     this.targetLevel = givenClassFile.targetJDK;
/* 7196 */     int produceAttributes = givenClassFile.produceAttributes;
/* 7197 */     this.generateAttributes = produceAttributes;
/* 7198 */     if ((produceAttributes & 0x2) != 0 && givenClassFile.referenceBinding != null) {
/* 7199 */       this.lineSeparatorPositions = (givenClassFile.referenceBinding.scope.referenceCompilationUnit()).compilationResult.getLineSeparatorPositions();
/*      */     } else {
/* 7201 */       this.lineSeparatorPositions = null;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void resetForProblemClinit(ClassFile targetClassFile) {
/* 7209 */     init(targetClassFile);
/* 7210 */     initializeMaxLocals(null);
/*      */   }
/*      */   
/*      */   public void resetInWideMode() {
/* 7214 */     this.wideMode = true;
/*      */   }
/*      */   
/*      */   public void resetForCodeGenUnusedLocals() {}
/*      */   
/*      */   private final void resizeByteArray() {
/* 7220 */     int length = this.bCodeStream.length;
/* 7221 */     int requiredSize = length + length;
/* 7222 */     if (this.classFileOffset >= requiredSize)
/*      */     {
/* 7224 */       requiredSize = this.classFileOffset + length;
/*      */     }
/* 7226 */     System.arraycopy(this.bCodeStream, 0, this.bCodeStream = new byte[requiredSize], 0, length);
/*      */   }
/*      */   
/*      */   public final void ret(int index) {
/* 7230 */     this.countLabels = 0;
/* 7231 */     if (index > 255) {
/* 7232 */       if (this.classFileOffset + 3 >= this.bCodeStream.length) {
/* 7233 */         resizeByteArray();
/*      */       }
/* 7235 */       this.position += 2;
/* 7236 */       this.bCodeStream[this.classFileOffset++] = -60;
/* 7237 */       this.bCodeStream[this.classFileOffset++] = -87;
/* 7238 */       writeUnsignedShort(index);
/*      */     } else {
/* 7240 */       if (this.classFileOffset + 1 >= this.bCodeStream.length) {
/* 7241 */         resizeByteArray();
/*      */       }
/* 7243 */       this.position += 2;
/* 7244 */       this.bCodeStream[this.classFileOffset++] = -87;
/* 7245 */       this.bCodeStream[this.classFileOffset++] = (byte)index;
/*      */     } 
/*      */   }
/*      */   
/*      */   public void return_() {
/* 7250 */     this.countLabels = 0;
/*      */     
/* 7252 */     if (this.classFileOffset >= this.bCodeStream.length) {
/* 7253 */       resizeByteArray();
/*      */     }
/* 7255 */     this.position++;
/* 7256 */     this.bCodeStream[this.classFileOffset++] = -79;
/* 7257 */     this.lastAbruptCompletion = this.position;
/*      */   }
/*      */   
/*      */   public void saload() {
/* 7261 */     this.countLabels = 0;
/* 7262 */     this.stackDepth--;
/* 7263 */     pushTypeBindingArray();
/* 7264 */     if (this.classFileOffset >= this.bCodeStream.length) {
/* 7265 */       resizeByteArray();
/*      */     }
/* 7267 */     this.position++;
/* 7268 */     this.bCodeStream[this.classFileOffset++] = 53;
/*      */   }
/*      */   
/*      */   public void sastore() {
/* 7272 */     this.countLabels = 0;
/* 7273 */     this.stackDepth -= 3;
/* 7274 */     popTypeBinding(3);
/* 7275 */     if (this.classFileOffset >= this.bCodeStream.length) {
/* 7276 */       resizeByteArray();
/*      */     }
/* 7278 */     this.position++;
/* 7279 */     this.bCodeStream[this.classFileOffset++] = 86;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void sendOperator(int operatorConstant, int type_ID) {
/* 7287 */     switch (type_ID) {
/*      */       case 2:
/*      */       case 3:
/*      */       case 4:
/*      */       case 5:
/*      */       case 10:
/* 7293 */         switch (operatorConstant) {
/*      */           case 14:
/* 7295 */             iadd();
/*      */             break;
/*      */           case 13:
/* 7298 */             isub();
/*      */             break;
/*      */           case 15:
/* 7301 */             imul();
/*      */             break;
/*      */           case 9:
/* 7304 */             idiv();
/*      */             break;
/*      */           case 16:
/* 7307 */             irem();
/*      */             break;
/*      */           case 10:
/* 7310 */             ishl();
/*      */             break;
/*      */           case 17:
/* 7313 */             ishr();
/*      */             break;
/*      */           case 19:
/* 7316 */             iushr();
/*      */             break;
/*      */           case 2:
/* 7319 */             iand();
/*      */             break;
/*      */           case 3:
/* 7322 */             ior();
/*      */             break;
/*      */           case 8:
/* 7325 */             ixor();
/*      */             break;
/*      */         } 
/*      */         break;
/*      */       case 7:
/* 7330 */         switch (operatorConstant) {
/*      */           case 14:
/* 7332 */             ladd();
/*      */             break;
/*      */           case 13:
/* 7335 */             lsub();
/*      */             break;
/*      */           case 15:
/* 7338 */             lmul();
/*      */             break;
/*      */           case 9:
/* 7341 */             ldiv();
/*      */             break;
/*      */           case 16:
/* 7344 */             lrem();
/*      */             break;
/*      */           case 10:
/* 7347 */             lshl();
/*      */             break;
/*      */           case 17:
/* 7350 */             lshr();
/*      */             break;
/*      */           case 19:
/* 7353 */             lushr();
/*      */             break;
/*      */           case 2:
/* 7356 */             land();
/*      */             break;
/*      */           case 3:
/* 7359 */             lor();
/*      */             break;
/*      */           case 8:
/* 7362 */             lxor();
/*      */             break;
/*      */         } 
/*      */         break;
/*      */       case 9:
/* 7367 */         switch (operatorConstant) {
/*      */           case 14:
/* 7369 */             fadd();
/*      */             break;
/*      */           case 13:
/* 7372 */             fsub();
/*      */             break;
/*      */           case 15:
/* 7375 */             fmul();
/*      */             break;
/*      */           case 9:
/* 7378 */             fdiv();
/*      */             break;
/*      */           case 16:
/* 7381 */             frem(); break;
/*      */         } 
/*      */         break;
/*      */       case 8:
/* 7385 */         switch (operatorConstant) {
/*      */           case 14:
/* 7387 */             dadd();
/*      */             break;
/*      */           case 13:
/* 7390 */             dsub();
/*      */             break;
/*      */           case 15:
/* 7393 */             dmul();
/*      */             break;
/*      */           case 9:
/* 7396 */             ddiv();
/*      */             break;
/*      */           case 16:
/* 7399 */             drem();
/*      */             break;
/*      */         } 
/*      */         break;
/*      */     } 
/*      */   } public void sipush(int s) {
/* 7405 */     this.countLabels = 0;
/* 7406 */     this.stackDepth++;
/* 7407 */     pushTypeBinding((TypeBinding)TypeBinding.SHORT);
/* 7408 */     if (this.stackDepth > this.stackMax)
/* 7409 */       this.stackMax = this.stackDepth; 
/* 7410 */     if (this.classFileOffset >= this.bCodeStream.length) {
/* 7411 */       resizeByteArray();
/*      */     }
/* 7413 */     this.position++;
/* 7414 */     this.bCodeStream[this.classFileOffset++] = 17;
/* 7415 */     writeSignedShort(s);
/*      */   }
/*      */   
/*      */   public void store(LocalVariableBinding localBinding, boolean valueRequired) {
/* 7419 */     int localPosition = localBinding.resolvedPosition;
/*      */     
/* 7421 */     switch (localBinding.type.id) {
/*      */       case 2:
/*      */       case 3:
/*      */       case 4:
/*      */       case 5:
/*      */       case 10:
/* 7427 */         if (valueRequired)
/* 7428 */           dup(); 
/* 7429 */         switch (localPosition) {
/*      */           case 0:
/* 7431 */             istore_0();
/*      */             return;
/*      */           case 1:
/* 7434 */             istore_1();
/*      */             return;
/*      */           case 2:
/* 7437 */             istore_2();
/*      */             return;
/*      */           case 3:
/* 7440 */             istore_3();
/*      */             return;
/*      */         } 
/*      */ 
/*      */ 
/*      */         
/* 7446 */         istore(localPosition);
/*      */         return;
/*      */       
/*      */       case 9:
/* 7450 */         if (valueRequired)
/* 7451 */           dup(); 
/* 7452 */         switch (localPosition) {
/*      */           case 0:
/* 7454 */             fstore_0();
/*      */             return;
/*      */           case 1:
/* 7457 */             fstore_1();
/*      */             return;
/*      */           case 2:
/* 7460 */             fstore_2();
/*      */             return;
/*      */           case 3:
/* 7463 */             fstore_3();
/*      */             return;
/*      */         } 
/* 7466 */         fstore(localPosition);
/*      */         return;
/*      */       
/*      */       case 8:
/* 7470 */         if (valueRequired)
/* 7471 */           dup2(); 
/* 7472 */         switch (localPosition) {
/*      */           case 0:
/* 7474 */             dstore_0();
/*      */             return;
/*      */           case 1:
/* 7477 */             dstore_1();
/*      */             return;
/*      */           case 2:
/* 7480 */             dstore_2();
/*      */             return;
/*      */           case 3:
/* 7483 */             dstore_3();
/*      */             return;
/*      */         } 
/* 7486 */         dstore(localPosition);
/*      */         return;
/*      */       
/*      */       case 7:
/* 7490 */         if (valueRequired)
/* 7491 */           dup2(); 
/* 7492 */         switch (localPosition) {
/*      */           case 0:
/* 7494 */             lstore_0();
/*      */             return;
/*      */           case 1:
/* 7497 */             lstore_1();
/*      */             return;
/*      */           case 2:
/* 7500 */             lstore_2();
/*      */             return;
/*      */           case 3:
/* 7503 */             lstore_3();
/*      */             return;
/*      */         } 
/* 7506 */         lstore(localPosition);
/*      */         return;
/*      */     } 
/*      */ 
/*      */     
/* 7511 */     if (valueRequired)
/* 7512 */       dup(); 
/* 7513 */     switch (localPosition) {
/*      */       case 0:
/* 7515 */         astore_0();
/*      */         return;
/*      */       case 1:
/* 7518 */         astore_1();
/*      */         return;
/*      */       case 2:
/* 7521 */         astore_2();
/*      */         return;
/*      */       case 3:
/* 7524 */         astore_3();
/*      */         return;
/*      */     } 
/* 7527 */     astore(localPosition);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void swap() {
/* 7533 */     this.countLabels = 0;
/* 7534 */     if (this.classFileOffset >= this.bCodeStream.length) {
/* 7535 */       resizeByteArray();
/*      */     }
/* 7537 */     this.position++;
/* 7538 */     this.bCodeStream[this.classFileOffset++] = 95;
/*      */   }
/*      */ 
/*      */   
/*      */   public void tableswitch(CaseLabel defaultLabel, int low, int high, int[] keys, int[] sortedIndexes, int[] mapping, CaseLabel[] casesLabel) {
/* 7543 */     this.countLabels = 0;
/* 7544 */     this.stackDepth--;
/* 7545 */     popTypeBinding();
/* 7546 */     int length = casesLabel.length;
/* 7547 */     int pos = this.position;
/* 7548 */     defaultLabel.placeInstruction(); int i;
/* 7549 */     for (i = 0; i < length; i++)
/* 7550 */       casesLabel[i].placeInstruction(); 
/* 7551 */     if (this.classFileOffset >= this.bCodeStream.length) {
/* 7552 */       resizeByteArray();
/*      */     }
/* 7554 */     this.position++;
/* 7555 */     this.bCodeStream[this.classFileOffset++] = -86;
/*      */     
/* 7557 */     for (i = 3 - (pos & 0x3); i > 0; i--) {
/* 7558 */       if (this.classFileOffset >= this.bCodeStream.length) {
/* 7559 */         resizeByteArray();
/*      */       }
/* 7561 */       this.position++;
/* 7562 */       this.bCodeStream[this.classFileOffset++] = 0;
/*      */     } 
/* 7564 */     defaultLabel.branch();
/* 7565 */     writeSignedWord(low);
/* 7566 */     writeSignedWord(high);
/* 7567 */     i = low; int j = 0;
/*      */ 
/*      */ 
/*      */     
/*      */     while (true) {
/* 7572 */       int index = sortedIndexes[j];
/* 7573 */       int key = keys[index];
/* 7574 */       if (key == i)
/* 7575 */       { casesLabel[mapping[index]].branch();
/* 7576 */         j++;
/* 7577 */         if (i == high)
/*      */           break;  }
/* 7579 */       else { defaultLabel.branch(); }
/*      */       
/* 7581 */       i++;
/*      */     } 
/*      */   }
/*      */   
/*      */   public void throwAnyException(LocalVariableBinding anyExceptionVariable) {
/* 7586 */     load(anyExceptionVariable);
/* 7587 */     athrow();
/*      */   }
/*      */ 
/*      */   
/*      */   public String toString() {
/* 7592 */     StringBuilder buffer = new StringBuilder("( position:");
/* 7593 */     buffer.append(this.position);
/* 7594 */     buffer.append(",\nstackDepth:");
/* 7595 */     buffer.append(this.stackDepth);
/* 7596 */     buffer.append(",\nmaxStack:");
/* 7597 */     buffer.append(this.stackMax);
/* 7598 */     buffer.append(",\nmaxLocals:");
/* 7599 */     buffer.append(this.maxLocals);
/* 7600 */     buffer.append(")");
/* 7601 */     return buffer.toString();
/*      */   }
/*      */   protected void writePosition(BranchLabel label) {
/* 7604 */     int offset = label.position - this.position + 1;
/* 7605 */     if (Math.abs(offset) > 32767 && !this.wideMode) {
/* 7606 */       throw new AbortMethod(RESTART_IN_WIDE_MODE, null);
/*      */     }
/* 7608 */     writeSignedShort(offset);
/* 7609 */     int[] forwardRefs = label.forwardReferences();
/* 7610 */     for (int i = 0, max = label.forwardReferenceCount(); i < max; i++) {
/* 7611 */       writePosition(label, forwardRefs[i]);
/*      */     }
/*      */   }
/*      */   
/*      */   protected void writePosition(BranchLabel label, int forwardReference) {
/* 7616 */     int offset = label.position - forwardReference + 1;
/* 7617 */     if (Math.abs(offset) > 32767 && !this.wideMode) {
/* 7618 */       throw new AbortMethod(RESTART_IN_WIDE_MODE, null);
/*      */     }
/* 7620 */     if (this.wideMode) {
/* 7621 */       if ((label.tagBits & 0x1) != 0) {
/* 7622 */         writeSignedWord(forwardReference, offset);
/*      */       } else {
/* 7624 */         writeSignedShort(forwardReference, offset);
/*      */       } 
/*      */     } else {
/* 7627 */       writeSignedShort(forwardReference, offset);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final void writeSignedShort(int value) {
/* 7637 */     if (this.classFileOffset + 1 >= this.bCodeStream.length) {
/* 7638 */       resizeByteArray();
/*      */     }
/* 7640 */     this.position += 2;
/* 7641 */     this.bCodeStream[this.classFileOffset++] = (byte)(value >> 8);
/* 7642 */     this.bCodeStream[this.classFileOffset++] = (byte)value;
/*      */   }
/*      */   
/*      */   private final void writeSignedShort(int pos, int value) {
/* 7646 */     int currentOffset = this.startingClassFileOffset + pos;
/* 7647 */     if (currentOffset + 1 >= this.bCodeStream.length) {
/* 7648 */       resizeByteArray();
/*      */     }
/* 7650 */     this.bCodeStream[currentOffset] = (byte)(value >> 8);
/* 7651 */     this.bCodeStream[currentOffset + 1] = (byte)value;
/*      */   }
/*      */ 
/*      */   
/*      */   protected final void writeSignedWord(int value) {
/* 7656 */     if (this.classFileOffset + 3 >= this.bCodeStream.length) {
/* 7657 */       resizeByteArray();
/*      */     }
/* 7659 */     this.position += 4;
/* 7660 */     this.bCodeStream[this.classFileOffset++] = (byte)((value & 0xFF000000) >> 24);
/* 7661 */     this.bCodeStream[this.classFileOffset++] = (byte)((value & 0xFF0000) >> 16);
/* 7662 */     this.bCodeStream[this.classFileOffset++] = (byte)((value & 0xFF00) >> 8);
/* 7663 */     this.bCodeStream[this.classFileOffset++] = (byte)(value & 0xFF);
/*      */   }
/*      */   
/*      */   protected void writeSignedWord(int pos, int value) {
/* 7667 */     int currentOffset = this.startingClassFileOffset + pos;
/* 7668 */     if (currentOffset + 3 >= this.bCodeStream.length) {
/* 7669 */       resizeByteArray();
/*      */     }
/* 7671 */     this.bCodeStream[currentOffset++] = (byte)((value & 0xFF000000) >> 24);
/* 7672 */     this.bCodeStream[currentOffset++] = (byte)((value & 0xFF0000) >> 16);
/* 7673 */     this.bCodeStream[currentOffset++] = (byte)((value & 0xFF00) >> 8);
/* 7674 */     this.bCodeStream[currentOffset++] = (byte)(value & 0xFF);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final void writeUnsignedShort(int value) {
/* 7683 */     this.position += 2;
/* 7684 */     this.bCodeStream[this.classFileOffset++] = (byte)(value >>> 8);
/* 7685 */     this.bCodeStream[this.classFileOffset++] = (byte)value;
/*      */   }
/*      */   
/*      */   protected void writeWidePosition(BranchLabel label) {
/* 7689 */     int labelPos = label.position;
/* 7690 */     int offset = labelPos - this.position + 1;
/* 7691 */     writeSignedWord(offset);
/* 7692 */     int[] forwardRefs = label.forwardReferences();
/* 7693 */     for (int i = 0, max = label.forwardReferenceCount(); i < max; i++) {
/* 7694 */       int forward = forwardRefs[i];
/* 7695 */       offset = labelPos - forward + 1;
/* 7696 */       writeSignedWord(forward, offset);
/*      */     } 
/*      */   }
/*      */   private boolean isSwitchStackTrackingActive() {
/* 7700 */     return (this.methodDeclaration != null && this.methodDeclaration.containsSwitchWithTry);
/*      */   }
/*      */   private TypeBinding retrieveLocalType(int currentPC, int resolvedPosition) {
/* 7703 */     for (int i = this.allLocalsCounter - 1; i >= 0; i--) {
/* 7704 */       LocalVariableBinding localVariable = this.locals[i];
/* 7705 */       if (localVariable != null && 
/* 7706 */         resolvedPosition == localVariable.resolvedPosition)
/* 7707 */         for (int j = 0; j < localVariable.initializationCount; j++) {
/* 7708 */           int startPC = localVariable.initializationPCs[j << 1];
/* 7709 */           int endPC = localVariable.initializationPCs[(j << 1) + 1];
/* 7710 */           if (currentPC >= startPC) {
/*      */             
/* 7712 */             if (endPC == -1)
/*      */             {
/* 7714 */               return localVariable.type; } 
/* 7715 */             if (currentPC < endPC)
/*      */             {
/* 7717 */               return localVariable.type;
/*      */             }
/*      */           } 
/*      */         }  
/*      */     } 
/* 7722 */     return null;
/*      */   } private void pushTypeBinding(int resolvedPosition) {
/*      */     ReferenceBinding referenceBinding;
/* 7725 */     if (!isSwitchStackTrackingActive())
/*      */       return; 
/* 7727 */     assert resolvedPosition < this.maxLocals;
/* 7728 */     TypeBinding type = retrieveLocalType(this.position, resolvedPosition);
/* 7729 */     if (type == null && resolvedPosition == 0 && !this.methodDeclaration.isStatic()) {
/* 7730 */       referenceBinding = this.methodDeclaration.binding.declaringClass;
/*      */     }
/* 7732 */     assert referenceBinding != null;
/* 7733 */     pushTypeBinding((TypeBinding)referenceBinding);
/*      */   }
/*      */   private void pushTypeBindingArray() {
/* 7736 */     if (!isSwitchStackTrackingActive())
/*      */       return; 
/* 7738 */     assert this.switchSaveTypeBindings.size() >= 2;
/* 7739 */     TypeBinding[] arrayref_t = { popTypeBinding(), popTypeBinding() };
/* 7740 */     TypeBinding type = arrayref_t[1];
/* 7741 */     assert type instanceof ArrayBinding;
/* 7742 */     pushTypeBinding(((ArrayBinding)type).leafComponentType);
/*      */   }
/*      */   private TypeBinding getPopularBinding(char[] typeName) {
/* 7745 */     ClassScope classScope = this.classFile.referenceBinding.scope;
/* 7746 */     assert classScope != null;
/* 7747 */     Supplier<ReferenceBinding> finder = classScope.getCommonReferenceBinding(typeName);
/* 7748 */     return (finder != null) ? (TypeBinding)finder.get() : (TypeBinding)TypeBinding.NULL;
/*      */   }
/*      */   
/*      */   private void pushTypeBinding(char[] typeName) {
/* 7752 */     if (!isSwitchStackTrackingActive())
/*      */       return; 
/* 7754 */     pushTypeBinding(getPopularBinding(typeName));
/*      */   }
/*      */   private void pushTypeBinding(TypeBinding typeBinding) {
/* 7757 */     if (isSwitchStackTrackingActive()) {
/* 7758 */       assert typeBinding != null;
/* 7759 */       this.switchSaveTypeBindings.push(typeBinding);
/*      */     } 
/*      */   }
/*      */   private void pushTypeBinding(int nPop, TypeBinding typeBinding) {
/* 7763 */     if (!isSwitchStackTrackingActive())
/*      */       return; 
/* 7765 */     popTypeBinding(nPop);
/* 7766 */     pushTypeBinding(typeBinding);
/*      */   }
/*      */   private TypeBinding popTypeBinding() {
/* 7769 */     return isSwitchStackTrackingActive() ? this.switchSaveTypeBindings.pop() : null;
/*      */   }
/*      */   private void popTypeBinding(int nPop) {
/* 7772 */     if (!isSwitchStackTrackingActive())
/*      */       return; 
/* 7774 */     for (int i = 0; i < nPop; i++)
/* 7775 */       popTypeBinding(); 
/*      */   }
/*      */   public void clearTypeBindingStack() {
/* 7778 */     if (!isSwitchStackTrackingActive())
/*      */       return; 
/* 7780 */     this.switchSaveTypeBindings.clear();
/*      */   }
/*      */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\codegen\CodeStream.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */