/*     */ package org.eclipse.jdt.internal.compiler.ast;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.Binding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.BlockScope;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.MethodBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.ModuleBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.ProblemReferenceBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.ReferenceBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.Scope;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.SourceModuleBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.TypeBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.TypeConstants;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ProvidesStatement
/*     */   extends ModuleStatement
/*     */ {
/*     */   public TypeReference serviceInterface;
/*     */   public TypeReference[] implementations;
/*     */   
/*     */   public boolean resolve(BlockScope scope) {
/*  38 */     ModuleDeclaration module = (scope.referenceCompilationUnit()).moduleDeclaration;
/*  39 */     SourceModuleBinding sourceModuleBinding = module.binding;
/*  40 */     TypeBinding infBinding = this.serviceInterface.resolveType(scope);
/*  41 */     boolean hasErrors = false;
/*  42 */     if (infBinding == null || !infBinding.isValidBinding()) {
/*  43 */       return false;
/*     */     }
/*  45 */     if (!infBinding.isClass() && !infBinding.isInterface() && !infBinding.isAnnotationType()) {
/*  46 */       scope.problemReporter().invalidServiceRef(8389924, this.serviceInterface);
/*     */     }
/*  48 */     ReferenceBinding intf = (ReferenceBinding)this.serviceInterface.resolvedType;
/*  49 */     Set<TypeBinding> impls = new HashSet<>();
/*  50 */     for (int i = 0; i < this.implementations.length; i++) {
/*  51 */       ReferenceBinding impl = (ReferenceBinding)this.implementations[i].resolveType(scope);
/*  52 */       if (impl == null || !impl.isValidBinding() || !impl.canBeSeenBy((Scope)scope)) {
/*  53 */         hasErrors = true;
/*     */       
/*     */       }
/*  56 */       else if (!impls.add(impl)) {
/*  57 */         scope.problemReporter().duplicateTypeReference(8389912, this.implementations[i]);
/*     */       } else {
/*     */         
/*  60 */         int problemId = 0;
/*  61 */         ModuleBinding declaringModule = impl.module();
/*     */         
/*  63 */         if (declaringModule != sourceModuleBinding) {
/*  64 */           problemId = 16778526;
/*  65 */         } else if (!impl.isClass() && !impl.isInterface()) {
/*  66 */           problemId = 8389925;
/*  67 */         } else if (impl.isNestedType() && !impl.isStatic()) {
/*  68 */           problemId = 16778525;
/*     */         } else {
/*  70 */           TypeBinding typeBinding; MethodBinding provider = impl.getExactMethod(TypeConstants.PROVIDER, Binding.NO_PARAMETERS, scope.compilationUnitScope());
/*  71 */           if (provider != null && (!provider.isValidBinding() || !provider.isPublic() || !provider.isStatic())) {
/*  72 */             provider = null;
/*     */           }
/*  74 */           ReferenceBinding referenceBinding = impl;
/*  75 */           if (provider != null) {
/*  76 */             typeBinding = provider.returnType;
/*  77 */             if (typeBinding instanceof ReferenceBinding && !typeBinding.canBeSeenBy((Scope)scope)) {
/*  78 */               ReferenceBinding referenceBinding1 = (ReferenceBinding)typeBinding;
/*  79 */               scope.problemReporter().invalidType(this.implementations[i], (TypeBinding)new ProblemReferenceBinding(
/*  80 */                     referenceBinding1.compoundName, referenceBinding1, 2));
/*  81 */               hasErrors = true;
/*     */             }
/*     */           
/*  84 */           } else if (impl.isAbstract()) {
/*  85 */             problemId = 16778522;
/*     */           } else {
/*  87 */             MethodBinding defaultConstructor = impl.getExactConstructor(Binding.NO_PARAMETERS);
/*  88 */             if (defaultConstructor == null || !defaultConstructor.isValidBinding()) {
/*  89 */               problemId = 16778523;
/*  90 */             } else if (!defaultConstructor.isPublic()) {
/*  91 */               problemId = 16778524;
/*     */             } 
/*     */           } 
/*     */           
/*  95 */           if (typeBinding.findSuperTypeOriginatingFrom((TypeBinding)intf) == null) {
/*  96 */             scope.problemReporter().typeMismatchError(typeBinding, (TypeBinding)intf, this.implementations[i], null);
/*  97 */             hasErrors = true;
/*     */           } 
/*     */         } 
/* 100 */         if (problemId != 0) {
/* 101 */           scope.problemReporter().invalidServiceRef(problemId, this.implementations[i]);
/* 102 */           hasErrors = true;
/*     */         } 
/*     */       } 
/* 105 */     }  return hasErrors;
/*     */   }
/*     */   
/*     */   public List<TypeBinding> getResolvedImplementations() {
/* 109 */     List<TypeBinding> resolved = new ArrayList<>();
/* 110 */     if (this.implementations != null) {
/* 111 */       byte b; int i; TypeReference[] arrayOfTypeReference; for (i = (arrayOfTypeReference = this.implementations).length, b = 0; b < i; ) { TypeReference implRef = arrayOfTypeReference[b];
/* 112 */         TypeBinding one = implRef.resolvedType;
/* 113 */         if (one != null)
/* 114 */           resolved.add(one);  b++; }
/*     */     
/*     */     } 
/* 117 */     return resolved;
/*     */   }
/*     */ 
/*     */   
/*     */   public StringBuffer print(int indent, StringBuffer output) {
/* 122 */     printIndent(indent, output);
/* 123 */     output.append("provides ");
/* 124 */     this.serviceInterface.print(0, output);
/*     */ 
/*     */     
/* 127 */     output.append(" with ");
/* 128 */     for (int i = 0; i < this.implementations.length; i++) {
/* 129 */       this.implementations[i].print(0, output);
/* 130 */       if (i < this.implementations.length - 1)
/* 131 */         output.append(", "); 
/*     */     } 
/* 133 */     output.append(";");
/* 134 */     return output;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\ast\ProvidesStatement.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */