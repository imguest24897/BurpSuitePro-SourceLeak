/*     */ package org.eclipse.jdt.internal.compiler.batch;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.util.function.Function;
/*     */ import org.eclipse.jdt.core.compiler.CharOperation;
/*     */ import org.eclipse.jdt.internal.compiler.env.ICompilationUnit;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.LookupEnvironment;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.ModuleBinding;
/*     */ import org.eclipse.jdt.internal.compiler.problem.AbortCompilationUnit;
/*     */ import org.eclipse.jdt.internal.compiler.util.Util;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CompilationUnit
/*     */   implements ICompilationUnit
/*     */ {
/*     */   public char[] contents;
/*     */   public char[] fileName;
/*     */   public char[] mainTypeName;
/*     */   String encoding;
/*     */   public String destinationPath;
/*     */   public char[] module;
/*     */   private boolean ignoreOptionalProblems;
/*     */   private ModuleBinding moduleBinding;
/*     */   private Function<String, String> annotationPathProvider;
/*     */   
/*     */   public CompilationUnit(char[] contents, String fileName, String encoding) {
/*  50 */     this(contents, fileName, encoding, null);
/*     */   }
/*     */   
/*     */   public CompilationUnit(char[] contents, String fileName, String encoding, String destinationPath) {
/*  54 */     this(contents, fileName, encoding, destinationPath, false, null);
/*     */   }
/*     */   
/*     */   public CompilationUnit(char[] contents, String fileName, String encoding, String destinationPath, boolean ignoreOptionalProblems, String modName) {
/*  58 */     this(contents, fileName, encoding, destinationPath, ignoreOptionalProblems, modName, null);
/*     */   }
/*     */ 
/*     */   
/*     */   public CompilationUnit(char[] contents, String fileName, String encoding, String destinationPath, boolean ignoreOptionalProblems, String modName, Function<String, String> annotationPathProvider) {
/*  63 */     this.annotationPathProvider = annotationPathProvider;
/*  64 */     this.contents = contents;
/*  65 */     if (modName != null)
/*  66 */       this.module = modName.toCharArray(); 
/*  67 */     char[] fileNameCharArray = fileName.toCharArray();
/*  68 */     switch (File.separatorChar) {
/*     */       case '/':
/*  70 */         if (CharOperation.indexOf('\\', fileNameCharArray) != -1) {
/*  71 */           CharOperation.replace(fileNameCharArray, '\\', '/');
/*     */         }
/*     */         break;
/*     */       case '\\':
/*  75 */         if (CharOperation.indexOf('/', fileNameCharArray) != -1)
/*  76 */           CharOperation.replace(fileNameCharArray, '/', '\\'); 
/*     */         break;
/*     */     } 
/*  79 */     this.fileName = fileNameCharArray;
/*  80 */     int start = CharOperation.lastIndexOf(File.separatorChar, fileNameCharArray) + 1;
/*     */     
/*  82 */     int end = CharOperation.lastIndexOf('.', fileNameCharArray);
/*  83 */     if (end == -1) {
/*  84 */       end = fileNameCharArray.length;
/*     */     }
/*     */     
/*  87 */     this.mainTypeName = CharOperation.subarray(fileNameCharArray, start, end);
/*  88 */     this.encoding = encoding;
/*  89 */     this.destinationPath = destinationPath;
/*  90 */     this.ignoreOptionalProblems = ignoreOptionalProblems;
/*     */   }
/*     */   
/*     */   public char[] getContents() {
/*  94 */     if (this.contents != null) {
/*  95 */       return this.contents;
/*     */     }
/*     */     
/*     */     try {
/*  99 */       return Util.getFileCharContent(new File(new String(this.fileName)), this.encoding);
/* 100 */     } catch (IOException e) {
/* 101 */       this.contents = CharOperation.NO_CHAR;
/* 102 */       throw new AbortCompilationUnit(null, e, this.encoding);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public char[] getFileName() {
/* 110 */     return this.fileName;
/*     */   }
/*     */   
/*     */   public char[] getMainTypeName() {
/* 114 */     return this.mainTypeName;
/*     */   }
/*     */   
/*     */   public char[][] getPackageName() {
/* 118 */     return null;
/*     */   }
/*     */   
/*     */   public boolean ignoreOptionalProblems() {
/* 122 */     return this.ignoreOptionalProblems;
/*     */   }
/*     */   
/*     */   public String toString() {
/* 126 */     return "CompilationUnit[" + new String(this.fileName) + "]";
/*     */   }
/*     */   
/*     */   public char[] getModuleName() {
/* 130 */     return this.module;
/*     */   }
/*     */   
/*     */   public ModuleBinding module(LookupEnvironment rootEnvironment) {
/* 134 */     if (this.moduleBinding != null)
/* 135 */       return this.moduleBinding; 
/* 136 */     this.moduleBinding = rootEnvironment.getModule(this.module);
/* 137 */     if (this.moduleBinding == null)
/* 138 */       throw new IllegalStateException("Module should be known"); 
/* 139 */     return this.moduleBinding;
/*     */   }
/*     */   
/*     */   public String getDestinationPath() {
/* 143 */     return this.destinationPath;
/*     */   }
/*     */   
/*     */   public String getExternalAnnotationPath(String qualifiedTypeName) {
/* 147 */     if (this.annotationPathProvider != null)
/* 148 */       return this.annotationPathProvider.apply(qualifiedTypeName); 
/* 149 */     return null;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\batch\CompilationUnit.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */