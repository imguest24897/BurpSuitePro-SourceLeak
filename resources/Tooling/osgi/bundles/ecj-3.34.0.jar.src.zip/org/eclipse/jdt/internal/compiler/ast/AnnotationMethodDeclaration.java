/*     */ package org.eclipse.jdt.internal.compiler.ast;
/*     */ 
/*     */ import org.eclipse.jdt.internal.compiler.ASTVisitor;
/*     */ import org.eclipse.jdt.internal.compiler.ClassFile;
/*     */ import org.eclipse.jdt.internal.compiler.CompilationResult;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.BlockScope;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.ClassScope;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.ElementValuePair;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.TypeBinding;
/*     */ import org.eclipse.jdt.internal.compiler.parser.Parser;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AnnotationMethodDeclaration
/*     */   extends MethodDeclaration
/*     */ {
/*     */   public Expression defaultValue;
/*     */   public int extendedDimensions;
/*     */   
/*     */   public AnnotationMethodDeclaration(CompilationResult compilationResult) {
/*  32 */     super(compilationResult);
/*     */   }
/*     */ 
/*     */   
/*     */   public void generateCode(ClassFile classFile) {
/*  37 */     classFile.generateMethodInfoHeader(this.binding);
/*  38 */     int methodAttributeOffset = classFile.contentsOffset;
/*  39 */     int attributeNumber = classFile.generateMethodInfoAttributes(this.binding, this);
/*  40 */     classFile.completeMethodInfo(this.binding, methodAttributeOffset, attributeNumber);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isAnnotationMethod() {
/*  46 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isMethod() {
/*  52 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void parseStatements(Parser parser, CompilationUnitDeclaration unit) {}
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public StringBuffer print(int tab, StringBuffer output) {
/*  64 */     printIndent(tab, output);
/*  65 */     printModifiers(this.modifiers, output);
/*  66 */     if (this.annotations != null) {
/*  67 */       printAnnotations(this.annotations, output);
/*  68 */       output.append(' ');
/*     */     } 
/*     */     
/*  71 */     TypeParameter[] typeParams = typeParameters();
/*  72 */     if (typeParams != null) {
/*  73 */       output.append('<');
/*  74 */       int max = typeParams.length - 1;
/*  75 */       for (int j = 0; j < max; j++) {
/*  76 */         typeParams[j].print(0, output);
/*  77 */         output.append(", ");
/*     */       } 
/*  79 */       typeParams[max].print(0, output);
/*  80 */       output.append('>');
/*     */     } 
/*     */     
/*  83 */     printReturnType(0, output).append(this.selector).append('(');
/*  84 */     if (this.arguments != null) {
/*  85 */       for (int i = 0; i < this.arguments.length; i++) {
/*  86 */         if (i > 0) output.append(", "); 
/*  87 */         this.arguments[i].print(0, output);
/*     */       } 
/*     */     }
/*  90 */     output.append(')');
/*  91 */     if (this.thrownExceptions != null) {
/*  92 */       output.append(" throws ");
/*  93 */       for (int i = 0; i < this.thrownExceptions.length; i++) {
/*  94 */         if (i > 0) output.append(", "); 
/*  95 */         this.thrownExceptions[i].print(0, output);
/*     */       } 
/*     */     } 
/*     */     
/*  99 */     if (this.defaultValue != null) {
/* 100 */       output.append(" default ");
/* 101 */       this.defaultValue.print(0, output);
/*     */     } 
/*     */     
/* 104 */     printBody(tab + 1, output);
/* 105 */     return output;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void resolveStatements() {
/* 111 */     super.resolveStatements();
/* 112 */     if (this.arguments != null || this.receiver != null) {
/* 113 */       this.scope.problemReporter().annotationMembersCannotHaveParameters(this);
/*     */     }
/* 115 */     if (this.typeParameters != null) {
/* 116 */       this.scope.problemReporter().annotationMembersCannotHaveTypeParameters(this);
/*     */     }
/* 118 */     if (this.extendedDimensions != 0) {
/* 119 */       this.scope.problemReporter().illegalExtendedDimensions(this);
/*     */     }
/* 121 */     if (this.binding == null)
/* 122 */       return;  TypeBinding returnTypeBinding = this.binding.returnType;
/* 123 */     if (returnTypeBinding != null) {
/*     */ 
/*     */ 
/*     */       
/* 127 */       TypeBinding leafReturnType = returnTypeBinding.leafComponentType();
/* 128 */       if (returnTypeBinding.dimensions() <= 1) {
/* 129 */         switch ((leafReturnType.erasure()).id) {
/*     */           case 2:
/*     */           case 3:
/*     */           case 4:
/*     */           case 5:
/*     */           case 7:
/*     */           case 8:
/*     */           case 9:
/*     */           case 10:
/*     */           case 11:
/*     */           case 16:
/*     */             break;
/*     */           default:
/* 142 */             if (leafReturnType.isEnum() || leafReturnType.isAnnotationType()) {
/*     */               break;
/*     */             }
/* 145 */             this.scope.problemReporter().invalidAnnotationMemberType(this); break;
/*     */         } 
/* 147 */         if (this.defaultValue != null) {
/* 148 */           MemberValuePair pair = new MemberValuePair(this.selector, this.sourceStart, this.sourceEnd, this.defaultValue);
/* 149 */           pair.binding = this.binding;
/* 150 */           if (pair.value.resolvedType == null)
/* 151 */             pair.resolveTypeExpecting((BlockScope)this.scope, returnTypeBinding); 
/* 152 */           this.binding.setDefaultValue(ElementValuePair.getValue(this.defaultValue));
/*     */         } else {
/* 154 */           this.binding.setDefaultValue(null);
/*     */         } 
/*     */         return;
/*     */       } 
/*     */     } else {
/*     */       return;
/*     */     } 
/*     */     this.scope.problemReporter().invalidAnnotationMemberType(this);
/*     */     break;
/*     */   } public void traverse(ASTVisitor visitor, ClassScope classScope) {
/* 164 */     if (visitor.visit(this, classScope)) {
/* 165 */       if (this.annotations != null) {
/* 166 */         int annotationsLength = this.annotations.length;
/* 167 */         for (int i = 0; i < annotationsLength; i++)
/* 168 */           this.annotations[i].traverse(visitor, (BlockScope)this.scope); 
/*     */       } 
/* 170 */       if (this.returnType != null) {
/* 171 */         this.returnType.traverse(visitor, (BlockScope)this.scope);
/*     */       }
/* 173 */       if (this.defaultValue != null) {
/* 174 */         this.defaultValue.traverse(visitor, (BlockScope)this.scope);
/*     */       }
/*     */     } 
/* 177 */     visitor.endVisit(this, classScope);
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\ast\AnnotationMethodDeclaration.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */