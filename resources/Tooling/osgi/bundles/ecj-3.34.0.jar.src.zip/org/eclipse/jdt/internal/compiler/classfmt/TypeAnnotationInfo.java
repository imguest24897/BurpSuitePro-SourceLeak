/*     */ package org.eclipse.jdt.internal.compiler.classfmt;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import org.eclipse.jdt.internal.compiler.env.IBinaryAnnotation;
/*     */ import org.eclipse.jdt.internal.compiler.env.IBinaryTypeAnnotation;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TypeAnnotationInfo
/*     */   extends ClassFileStruct
/*     */   implements IBinaryTypeAnnotation
/*     */ {
/*     */   private AnnotationInfo annotation;
/*  32 */   private int targetType = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int info;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int info2;
/*     */ 
/*     */ 
/*     */   
/*     */   private int[] typePath;
/*     */ 
/*     */ 
/*     */   
/*  50 */   int readOffset = 0;
/*     */ 
/*     */   
/*     */   TypeAnnotationInfo(byte[] classFileBytes, int[] contantPoolOffsets, int offset) {
/*  54 */     super(classFileBytes, contantPoolOffsets, offset);
/*     */   }
/*     */   
/*     */   TypeAnnotationInfo(byte[] classFileBytes, int[] contantPoolOffsets, int offset, boolean runtimeVisible, boolean populate) {
/*  58 */     this(classFileBytes, contantPoolOffsets, offset);
/*  59 */     this.readOffset = 0;
/*  60 */     this.targetType = u1At(0);
/*  61 */     switch (this.targetType) {
/*     */       case 0:
/*     */       case 1:
/*  64 */         this.info = u1At(1);
/*  65 */         this.readOffset += 2;
/*     */         break;
/*     */       
/*     */       case 16:
/*  69 */         this.info = u2At(1);
/*  70 */         this.readOffset += 3;
/*     */         break;
/*     */       
/*     */       case 17:
/*     */       case 18:
/*  75 */         this.info = u1At(1);
/*  76 */         this.info2 = u1At(2);
/*  77 */         this.readOffset += 3;
/*     */         break;
/*     */       
/*     */       case 19:
/*     */       case 20:
/*     */       case 21:
/*  83 */         this.readOffset++;
/*     */         break;
/*     */       
/*     */       case 22:
/*  87 */         this.info = u1At(1);
/*  88 */         this.readOffset += 2;
/*     */         break;
/*     */       
/*     */       case 23:
/*  92 */         this.info = u2At(1);
/*  93 */         this.readOffset += 3;
/*     */         break;
/*     */       
/*     */       default:
/*  97 */         throw new IllegalStateException("Target type not handled " + this.targetType);
/*     */     } 
/*  99 */     int typePathLength = u1At(this.readOffset);
/* 100 */     this.readOffset++;
/* 101 */     if (typePathLength == 0) {
/* 102 */       this.typePath = NO_TYPE_PATH;
/*     */     } else {
/* 104 */       this.typePath = new int[typePathLength * 2];
/* 105 */       int index = 0;
/* 106 */       for (int i = 0; i < typePathLength; i++) {
/* 107 */         this.typePath[index++] = u1At(this.readOffset++);
/* 108 */         this.typePath[index++] = u1At(this.readOffset++);
/*     */       } 
/*     */     } 
/* 111 */     this.annotation = new AnnotationInfo(classFileBytes, this.constantPoolOffsets, this.structOffset + this.readOffset, runtimeVisible, populate);
/* 112 */     this.readOffset += this.annotation.readOffset;
/*     */   }
/*     */ 
/*     */   
/*     */   public IBinaryAnnotation getAnnotation() {
/* 117 */     return this.annotation;
/*     */   }
/*     */   
/*     */   protected void initialize() {
/* 121 */     this.annotation.initialize();
/*     */   }
/*     */ 
/*     */   
/*     */   protected void reset() {
/* 126 */     this.annotation.reset();
/* 127 */     super.reset();
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 132 */     return BinaryTypeFormatter.annotationToString(this);
/*     */   }
/*     */ 
/*     */   
/*     */   public int getTargetType() {
/* 137 */     return this.targetType;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int getSupertypeIndex() {
/* 143 */     return this.info;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int getTypeParameterIndex() {
/* 149 */     return this.info;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int getBoundIndex() {
/* 155 */     return this.info2;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int getMethodFormalParameterIndex() {
/* 161 */     return this.info;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int getThrowsTypeIndex() {
/* 167 */     return this.info;
/*     */   }
/*     */ 
/*     */   
/*     */   public int[] getTypePath() {
/* 172 */     return this.typePath;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 178 */     int result = 1;
/* 179 */     result = 31 * result + this.targetType;
/* 180 */     result = 31 * result + this.info;
/* 181 */     result = 31 * result + this.info2;
/* 182 */     if (this.typePath != null) {
/* 183 */       for (int i = 0, max = this.typePath.length; i < max; i++) {
/* 184 */         result = 31 * result + this.typePath[i];
/*     */       }
/*     */     }
/* 187 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object obj) {
/* 192 */     if (this == obj) {
/* 193 */       return true;
/*     */     }
/* 195 */     if (obj == null) {
/* 196 */       return false;
/*     */     }
/* 198 */     if (getClass() != obj.getClass()) {
/* 199 */       return false;
/*     */     }
/*     */     
/* 202 */     TypeAnnotationInfo other = (TypeAnnotationInfo)obj;
/*     */     
/* 204 */     if (this.targetType != other.targetType) {
/* 205 */       return false;
/*     */     }
/*     */     
/* 208 */     if (this.info != other.info) {
/* 209 */       return false;
/*     */     }
/*     */     
/* 212 */     if (this.info2 != other.info2) {
/* 213 */       return false;
/*     */     }
/*     */     
/* 216 */     if (!Arrays.equals(this.typePath, other.typePath)) {
/* 217 */       return false;
/*     */     }
/*     */     
/* 220 */     return this.annotation.equals(other.annotation);
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\classfmt\TypeAnnotationInfo.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */