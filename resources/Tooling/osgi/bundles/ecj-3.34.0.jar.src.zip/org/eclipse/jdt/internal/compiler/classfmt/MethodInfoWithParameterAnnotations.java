/*    */ package org.eclipse.jdt.internal.compiler.classfmt;
/*    */ 
/*    */ import org.eclipse.jdt.internal.compiler.env.IBinaryAnnotation;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class MethodInfoWithParameterAnnotations
/*    */   extends MethodInfoWithAnnotations
/*    */ {
/*    */   private AnnotationInfo[][] parameterAnnotations;
/*    */   
/*    */   MethodInfoWithParameterAnnotations(MethodInfo methodInfo, AnnotationInfo[] annotations, AnnotationInfo[][] parameterAnnotations) {
/* 24 */     super(methodInfo, annotations);
/* 25 */     this.parameterAnnotations = parameterAnnotations;
/*    */   }
/*    */   
/*    */   public IBinaryAnnotation[] getParameterAnnotations(int index, char[] classFileName) {
/*    */     try {
/* 30 */       return (this.parameterAnnotations == null) ? null : (IBinaryAnnotation[])this.parameterAnnotations[index];
/* 31 */     } catch (ArrayIndexOutOfBoundsException aioobe) {
/*    */       
/* 33 */       StringBuilder message = new StringBuilder("Mismatching number of parameter annotations, ");
/* 34 */       message.append(index);
/* 35 */       message.append('>');
/* 36 */       message.append(this.parameterAnnotations.length - 1);
/* 37 */       message.append(" in ");
/* 38 */       message.append(getSelector());
/* 39 */       char[] desc = getGenericSignature();
/* 40 */       if (desc != null) {
/* 41 */         message.append(desc);
/*    */       } else {
/* 43 */         message.append(getMethodDescriptor());
/* 44 */       }  if (classFileName != null)
/* 45 */         message.append(" in ").append(classFileName); 
/* 46 */       throw new IllegalStateException(message.toString(), aioobe);
/*    */     } 
/*    */   }
/*    */   
/*    */   public int getAnnotatedParametersCount() {
/* 51 */     return (this.parameterAnnotations == null) ? 0 : this.parameterAnnotations.length;
/*    */   }
/*    */   
/*    */   protected void initialize() {
/* 55 */     for (int i = 0, l = (this.parameterAnnotations == null) ? 0 : this.parameterAnnotations.length; i < l; i++) {
/* 56 */       AnnotationInfo[] infos = this.parameterAnnotations[i];
/* 57 */       for (int j = 0, k = (infos == null) ? 0 : infos.length; j < k; j++)
/* 58 */         infos[j].initialize(); 
/*    */     } 
/* 60 */     super.initialize();
/*    */   }
/*    */   
/*    */   protected void reset() {
/* 64 */     for (int i = 0, l = (this.parameterAnnotations == null) ? 0 : this.parameterAnnotations.length; i < l; i++) {
/* 65 */       AnnotationInfo[] infos = this.parameterAnnotations[i];
/* 66 */       for (int j = 0, k = (infos == null) ? 0 : infos.length; j < k; j++)
/* 67 */         infos[j].reset(); 
/*    */     } 
/* 69 */     super.reset();
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\classfmt\MethodInfoWithParameterAnnotations.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */