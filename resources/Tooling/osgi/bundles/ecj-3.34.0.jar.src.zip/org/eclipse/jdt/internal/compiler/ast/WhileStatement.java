/*     */ package org.eclipse.jdt.internal.compiler.ast;
/*     */ 
/*     */ import org.eclipse.jdt.internal.compiler.ASTVisitor;
/*     */ import org.eclipse.jdt.internal.compiler.codegen.BranchLabel;
/*     */ import org.eclipse.jdt.internal.compiler.codegen.CodeStream;
/*     */ import org.eclipse.jdt.internal.compiler.flow.FlowContext;
/*     */ import org.eclipse.jdt.internal.compiler.flow.FlowInfo;
/*     */ import org.eclipse.jdt.internal.compiler.flow.LoopingFlowContext;
/*     */ import org.eclipse.jdt.internal.compiler.flow.UnconditionalFlowInfo;
/*     */ import org.eclipse.jdt.internal.compiler.impl.Constant;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.BlockScope;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.LocalVariableBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.Scope;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.TypeBinding;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class WhileStatement
/*     */   extends Statement
/*     */ {
/*     */   public Expression condition;
/*     */   public Statement action;
/*     */   private BranchLabel breakLabel;
/*     */   private BranchLabel continueLabel;
/*  34 */   int preCondInitStateIndex = -1;
/*  35 */   int condIfTrueInitStateIndex = -1;
/*  36 */   int mergedInitStateIndex = -1;
/*     */ 
/*     */   
/*     */   public WhileStatement(Expression condition, Statement action, int s, int e) {
/*  40 */     this.condition = condition;
/*  41 */     this.action = action;
/*     */     
/*  43 */     if (action instanceof EmptyStatement) action.bits |= 0x1; 
/*  44 */     this.sourceStart = s;
/*  45 */     this.sourceEnd = e;
/*     */   }
/*     */   
/*     */   public FlowInfo analyseCode(BlockScope currentScope, FlowContext flowContext, FlowInfo flowInfo) {
/*     */     FlowInfo actionInfo;
/*     */     UnconditionalFlowInfo unconditionalFlowInfo2;
/*  51 */     this.breakLabel = new BranchLabel();
/*  52 */     this.continueLabel = new BranchLabel();
/*  53 */     int initialComplaintLevel = ((flowInfo.reachMode() & 0x3) != 0) ? 1 : 0;
/*     */     
/*  55 */     Constant cst = this.condition.constant;
/*  56 */     boolean isConditionTrue = (cst != Constant.NotAConstant && cst.booleanValue());
/*  57 */     boolean isConditionFalse = (cst != Constant.NotAConstant && !cst.booleanValue());
/*     */     
/*  59 */     cst = this.condition.optimizedBooleanConstant();
/*  60 */     boolean isConditionOptimizedTrue = (cst != Constant.NotAConstant && cst.booleanValue());
/*  61 */     boolean isConditionOptimizedFalse = (cst != Constant.NotAConstant && !cst.booleanValue());
/*     */     
/*  63 */     this.preCondInitStateIndex = currentScope.methodScope().recordInitializationStates(flowInfo);
/*     */     
/*  65 */     UnconditionalFlowInfo unconditionalFlowInfo1 = flowInfo.nullInfoLessUnconditionalCopy();
/*     */ 
/*     */     
/*     */     LoopingFlowContext condLoopContext;
/*     */     
/*  70 */     FlowInfo flowInfo1 = this.condition.analyseCode(
/*  71 */         currentScope, 
/*  72 */         (FlowContext)(condLoopContext = 
/*  73 */         new LoopingFlowContext(flowContext, flowInfo, this, null, 
/*  74 */           null, (Scope)currentScope, true)), 
/*  75 */         (FlowInfo)unconditionalFlowInfo1);
/*  76 */     this.condition.checkNPEbyUnboxing(currentScope, flowContext, flowInfo);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  81 */     if (this.action == null || (
/*  82 */       this.action.isEmptyBlock() && (currentScope.compilerOptions()).complianceLevel <= 3080192L)) {
/*  83 */       condLoopContext.complainOnDeferredFinalChecks(currentScope, 
/*  84 */           flowInfo1);
/*  85 */       condLoopContext.complainOnDeferredNullChecks(currentScope, 
/*  86 */           (FlowInfo)flowInfo1.unconditionalInits());
/*  87 */       if (isConditionTrue) {
/*  88 */         return (FlowInfo)FlowInfo.DEAD_END;
/*     */       }
/*  90 */       FlowInfo mergedInfo = flowInfo.copy().addInitializationsFrom(flowInfo1.initsWhenFalse());
/*  91 */       if (isConditionOptimizedTrue) {
/*  92 */         mergedInfo.setReachMode(1);
/*     */       }
/*  94 */       this.mergedInitStateIndex = 
/*  95 */         currentScope.methodScope().recordInitializationStates(mergedInfo);
/*  96 */       return mergedInfo;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 101 */     LoopingFlowContext loopingContext = 
/* 102 */       new LoopingFlowContext(
/* 103 */         flowContext, 
/* 104 */         flowInfo, 
/* 105 */         this, 
/* 106 */         this.breakLabel, 
/* 107 */         this.continueLabel, 
/* 108 */         (Scope)currentScope, 
/* 109 */         true);
/* 110 */     loopingContext.copyNullCheckedFieldsFrom((FlowContext)condLoopContext);
/* 111 */     if (isConditionFalse) {
/* 112 */       unconditionalFlowInfo2 = FlowInfo.DEAD_END;
/*     */     } else {
/* 114 */       actionInfo = flowInfo1.initsWhenTrue().copy();
/* 115 */       if (isConditionOptimizedFalse) {
/* 116 */         actionInfo.setReachMode(1);
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 121 */     this.condIfTrueInitStateIndex = 
/* 122 */       currentScope.methodScope().recordInitializationStates(
/* 123 */         flowInfo1.initsWhenTrue());
/*     */     
/* 125 */     if (this.action.complainIfUnreachable(actionInfo, currentScope, initialComplaintLevel, true) < 2) {
/* 126 */       this.condition.updateFlowOnBooleanResult(actionInfo, true);
/* 127 */       actionInfo = this.action.analyseCode(currentScope, (FlowContext)loopingContext, actionInfo);
/*     */     } 
/*     */ 
/*     */     
/* 131 */     FlowInfo exitBranch = flowInfo.copy();
/*     */     
/* 133 */     int combinedTagBits = actionInfo.tagBits & loopingContext.initsOnContinue.tagBits;
/* 134 */     if ((combinedTagBits & 0x3) != 0) {
/* 135 */       if ((combinedTagBits & 0x1) != 0)
/* 136 */         this.continueLabel = null; 
/* 137 */       exitBranch.addInitializationsFrom(flowInfo1.initsWhenFalse());
/* 138 */       unconditionalFlowInfo2 = actionInfo.mergedWith(loopingContext.initsOnContinue.unconditionalInits());
/* 139 */       condLoopContext.complainOnDeferredNullChecks(currentScope, 
/* 140 */           (FlowInfo)unconditionalFlowInfo2, false);
/* 141 */       loopingContext.complainOnDeferredNullChecks(currentScope, 
/* 142 */           (FlowInfo)unconditionalFlowInfo2, false);
/*     */     } else {
/* 144 */       condLoopContext.complainOnDeferredFinalChecks(currentScope, 
/* 145 */           flowInfo1);
/* 146 */       unconditionalFlowInfo2 = unconditionalFlowInfo2.mergedWith(loopingContext.initsOnContinue.unconditionalInits());
/* 147 */       condLoopContext.complainOnDeferredNullChecks(currentScope, 
/* 148 */           (FlowInfo)unconditionalFlowInfo2);
/* 149 */       loopingContext.complainOnDeferredFinalChecks(currentScope, 
/* 150 */           (FlowInfo)unconditionalFlowInfo2);
/* 151 */       loopingContext.complainOnDeferredNullChecks(currentScope, 
/* 152 */           (FlowInfo)unconditionalFlowInfo2);
/* 153 */       exitBranch
/* 154 */         .addPotentialInitializationsFrom(
/* 155 */           (FlowInfo)unconditionalFlowInfo2.unconditionalInits())
/* 156 */         .addInitializationsFrom(flowInfo1.initsWhenFalse());
/*     */     } 
/* 158 */     if (loopingContext.hasEscapingExceptions()) {
/* 159 */       UnconditionalFlowInfo unconditionalFlowInfo; FlowInfo loopbackFlowInfo = flowInfo.copy();
/* 160 */       if (this.continueLabel != null)
/*     */       {
/* 162 */         unconditionalFlowInfo = loopbackFlowInfo.mergedWith(loopbackFlowInfo.unconditionalCopy().addNullInfoFrom((FlowInfo)unconditionalFlowInfo2).unconditionalInits());
/*     */       }
/* 164 */       loopingContext.simulateThrowAfterLoopBack((FlowInfo)unconditionalFlowInfo);
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 169 */     UnconditionalFlowInfo unconditionalFlowInfo3 = FlowInfo.mergedOptimizedBranches(
/* 170 */         ((loopingContext.initsOnBreak.tagBits & 
/* 171 */         0x3) != 0) ? 
/* 172 */         (FlowInfo)loopingContext.initsOnBreak : 
/* 173 */         flowInfo.addInitializationsFrom((FlowInfo)loopingContext.initsOnBreak), 
/* 174 */         isConditionOptimizedTrue, 
/* 175 */         exitBranch, 
/* 176 */         isConditionOptimizedFalse, 
/* 177 */         !isConditionTrue);
/* 178 */     this.mergedInitStateIndex = currentScope.methodScope().recordInitializationStates((FlowInfo)unconditionalFlowInfo3);
/* 179 */     this.condition.updateFlowOnBooleanResult((FlowInfo)unconditionalFlowInfo3, false);
/* 180 */     return (FlowInfo)unconditionalFlowInfo3;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void generateCode(BlockScope currentScope, CodeStream codeStream) {
/* 192 */     if ((this.bits & Integer.MIN_VALUE) == 0) {
/*     */       return;
/*     */     }
/* 195 */     if (containsPatternVariable()) {
/* 196 */       this.condition.addPatternVariables(currentScope, codeStream);
/*     */     }
/* 198 */     int pc = codeStream.position;
/* 199 */     Constant cst = this.condition.optimizedBooleanConstant();
/* 200 */     boolean isConditionOptimizedFalse = (cst != Constant.NotAConstant && !cst.booleanValue());
/* 201 */     if (isConditionOptimizedFalse) {
/* 202 */       this.condition.generateCode(currentScope, codeStream, false);
/*     */       
/* 204 */       if (this.mergedInitStateIndex != -1) {
/* 205 */         codeStream.removeNotDefinitelyAssignedVariables((Scope)currentScope, this.mergedInitStateIndex);
/* 206 */         codeStream.addDefinitelyAssignedVariables((Scope)currentScope, this.mergedInitStateIndex);
/*     */       } 
/* 208 */       codeStream.recordPositionsFrom(pc, this.sourceStart);
/*     */       
/*     */       return;
/*     */     } 
/* 212 */     this.breakLabel.initialize(codeStream);
/*     */ 
/*     */     
/* 215 */     if (this.continueLabel == null) {
/*     */       
/* 217 */       if (this.condition.constant == Constant.NotAConstant) {
/* 218 */         this.condition.generateOptimizedBoolean(
/* 219 */             currentScope, 
/* 220 */             codeStream, 
/* 221 */             (BranchLabel)null, 
/* 222 */             this.breakLabel, 
/* 223 */             true);
/*     */       }
/*     */     } else {
/* 226 */       this.continueLabel.initialize(codeStream);
/* 227 */       if ((this.condition.constant == Constant.NotAConstant || 
/* 228 */         !this.condition.constant.booleanValue()) && 
/* 229 */         this.action != null && 
/* 230 */         !this.action.isEmptyBlock()) {
/* 231 */         int jumpPC = codeStream.position;
/* 232 */         codeStream.goto_(this.continueLabel);
/* 233 */         codeStream.recordPositionsFrom(jumpPC, this.condition.sourceStart);
/*     */       } 
/*     */     } 
/*     */     
/* 237 */     BranchLabel actionLabel = new BranchLabel(codeStream);
/* 238 */     if (this.action != null) {
/* 239 */       actionLabel.tagBits |= 0x2;
/*     */       
/* 241 */       if (this.condIfTrueInitStateIndex != -1)
/*     */       {
/* 243 */         codeStream.addDefinitelyAssignedVariables(
/* 244 */             (Scope)currentScope, 
/* 245 */             this.condIfTrueInitStateIndex);
/*     */       }
/* 247 */       actionLabel.place();
/* 248 */       this.action.generateCode(currentScope, codeStream);
/*     */       
/* 250 */       if (this.preCondInitStateIndex != -1) {
/* 251 */         codeStream.removeNotDefinitelyAssignedVariables((Scope)currentScope, this.preCondInitStateIndex);
/*     */       }
/*     */     } else {
/* 254 */       actionLabel.place();
/*     */     } 
/*     */     
/* 257 */     if (this.continueLabel != null) {
/* 258 */       this.continueLabel.place();
/* 259 */       this.condition.generateOptimizedBoolean(
/* 260 */           currentScope, 
/* 261 */           codeStream, 
/* 262 */           actionLabel, 
/* 263 */           (BranchLabel)null, 
/* 264 */           true);
/*     */     } 
/*     */ 
/*     */     
/* 268 */     if (this.mergedInitStateIndex != -1) {
/* 269 */       codeStream.removeNotDefinitelyAssignedVariables((Scope)currentScope, this.mergedInitStateIndex);
/* 270 */       codeStream.addDefinitelyAssignedVariables((Scope)currentScope, this.mergedInitStateIndex);
/*     */     } 
/* 272 */     this.breakLabel.place();
/* 273 */     codeStream.recordPositionsFrom(pc, this.sourceStart);
/*     */   }
/*     */ 
/*     */   
/*     */   public void resolve(BlockScope scope) {
/* 278 */     if (containsPatternVariable()) {
/* 279 */       this.condition.collectPatternVariablesToScope((LocalVariableBinding[])null, scope);
/* 280 */       LocalVariableBinding[] patternVariablesInTrueScope = this.condition.getPatternVariablesWhenTrue();
/* 281 */       LocalVariableBinding[] patternVariablesInFalseScope = this.condition.getPatternVariablesWhenFalse();
/*     */       
/* 283 */       TypeBinding type = this.condition.resolveTypeExpecting(scope, (TypeBinding)TypeBinding.BOOLEAN);
/* 284 */       this.condition.computeConversion((Scope)scope, type, type);
/* 285 */       if (this.action != null) {
/* 286 */         this.action.resolveWithPatternVariablesInScope(patternVariablesInTrueScope, scope);
/* 287 */         this.action.promotePatternVariablesIfApplicable(patternVariablesInFalseScope, () -> !this.action.breaksOut((char[])null));
/*     */       } 
/*     */     } else {
/*     */       
/* 291 */       TypeBinding type = this.condition.resolveTypeExpecting(scope, (TypeBinding)TypeBinding.BOOLEAN);
/* 292 */       this.condition.computeConversion((Scope)scope, type, type);
/* 293 */       if (this.action != null) {
/* 294 */         this.action.resolve(scope);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean containsPatternVariable() {
/* 301 */     return (this.condition != null && this.condition.containsPatternVariable());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public StringBuffer printStatement(int tab, StringBuffer output) {
/* 307 */     printIndent(tab, output).append("while (");
/* 308 */     this.condition.printExpression(0, output).append(')');
/* 309 */     if (this.action == null) {
/* 310 */       output.append(';');
/*     */     } else {
/* 312 */       this.action.printStatement(tab + 1, output);
/* 313 */     }  return output;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void traverse(ASTVisitor visitor, BlockScope blockScope) {
/* 321 */     if (visitor.visit(this, blockScope)) {
/* 322 */       this.condition.traverse(visitor, blockScope);
/* 323 */       if (this.action != null)
/* 324 */         this.action.traverse(visitor, blockScope); 
/*     */     } 
/* 326 */     visitor.endVisit(this, blockScope);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean doesNotCompleteNormally() {
/* 331 */     Constant cst = this.condition.constant;
/* 332 */     boolean isConditionTrue = !(cst != null && (cst == Constant.NotAConstant || !cst.booleanValue()));
/* 333 */     cst = this.condition.optimizedBooleanConstant();
/* 334 */     boolean isConditionOptimizedTrue = (cst == null) ? true : ((cst != Constant.NotAConstant && cst.booleanValue()));
/* 335 */     return ((isConditionTrue || isConditionOptimizedTrue) && (this.action == null || !this.action.breaksOut((char[])null)));
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean completesByContinue() {
/* 340 */     return this.action.continuesAtOuterLabel();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean canCompleteNormally() {
/* 345 */     Constant cst = this.condition.constant;
/* 346 */     boolean isConditionTrue = !(cst != null && (cst == Constant.NotAConstant || !cst.booleanValue()));
/* 347 */     cst = this.condition.optimizedBooleanConstant();
/* 348 */     boolean isConditionOptimizedTrue = (cst == null) ? true : ((cst != Constant.NotAConstant && cst.booleanValue()));
/* 349 */     if (!isConditionTrue && !isConditionOptimizedTrue)
/* 350 */       return true; 
/* 351 */     return (this.action != null && this.action.breaksOut((char[])null));
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean continueCompletes() {
/* 356 */     return this.action.continuesAtOuterLabel();
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\ast\WhileStatement.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */