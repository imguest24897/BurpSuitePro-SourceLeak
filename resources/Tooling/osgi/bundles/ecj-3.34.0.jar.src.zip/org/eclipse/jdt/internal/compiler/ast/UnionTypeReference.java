/*     */ package org.eclipse.jdt.internal.compiler.ast;
/*     */ 
/*     */ import org.eclipse.jdt.internal.compiler.ASTVisitor;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.BlockScope;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.ClassScope;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.Scope;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.TypeBinding;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class UnionTypeReference
/*     */   extends TypeReference
/*     */ {
/*     */   public TypeReference[] typeReferences;
/*     */   
/*     */   public UnionTypeReference(TypeReference[] typeReferences) {
/*  30 */     this.bits |= 0x20000000;
/*  31 */     this.typeReferences = typeReferences;
/*  32 */     this.sourceStart = (typeReferences[0]).sourceStart;
/*  33 */     int length = typeReferences.length;
/*  34 */     this.sourceEnd = (typeReferences[length - 1]).sourceEnd;
/*     */   }
/*     */ 
/*     */   
/*     */   public char[] getLastToken() {
/*  39 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected TypeBinding getTypeBinding(Scope scope) {
/*  47 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public TypeBinding resolveType(BlockScope scope, boolean checkBounds, int location) {
/*  53 */     int length = this.typeReferences.length;
/*  54 */     TypeBinding[] allExceptionTypes = new TypeBinding[length];
/*  55 */     boolean hasError = false;
/*  56 */     for (int i = 0; i < length; i++) {
/*  57 */       TypeBinding exceptionType = this.typeReferences[i].resolveType(scope, checkBounds, location);
/*  58 */       if (exceptionType == null) {
/*  59 */         return null;
/*     */       }
/*  61 */       switch (exceptionType.kind()) {
/*     */         case 260:
/*  63 */           if (exceptionType.isBoundParameterizedType()) {
/*  64 */             hasError = true;
/*  65 */             scope.problemReporter().invalidParameterizedExceptionType(exceptionType, this.typeReferences[i]);
/*     */           } 
/*     */           break;
/*     */         
/*     */         case 4100:
/*  70 */           scope.problemReporter().invalidTypeVariableAsException(exceptionType, this.typeReferences[i]);
/*  71 */           hasError = true;
/*     */           break;
/*     */       } 
/*     */       
/*  75 */       if (exceptionType.findSuperTypeOriginatingFrom(21, true) == null && 
/*  76 */         exceptionType.isValidBinding()) {
/*  77 */         scope.problemReporter().cannotThrowType(this.typeReferences[i], exceptionType);
/*  78 */         hasError = true;
/*     */       } 
/*  80 */       allExceptionTypes[i] = exceptionType;
/*     */       
/*  82 */       for (int j = 0; j < i; j++) {
/*  83 */         if (allExceptionTypes[j].isCompatibleWith(exceptionType)) {
/*  84 */           scope.problemReporter().wrongSequenceOfExceptionTypes(
/*  85 */               this.typeReferences[j], 
/*  86 */               allExceptionTypes[j], 
/*  87 */               exceptionType);
/*  88 */           hasError = true;
/*  89 */         } else if (exceptionType.isCompatibleWith(allExceptionTypes[j])) {
/*  90 */           scope.problemReporter().wrongSequenceOfExceptionTypes(
/*  91 */               this.typeReferences[i], 
/*  92 */               exceptionType, 
/*  93 */               allExceptionTypes[j]);
/*  94 */           hasError = true;
/*     */         } 
/*     */       } 
/*     */     } 
/*  98 */     if (hasError) {
/*  99 */       return null;
/*     */     }
/*     */     
/* 102 */     return this.resolvedType = scope.lowerUpperBound(allExceptionTypes);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public char[][] getTypeName() {
/* 108 */     return this.typeReferences[0].getTypeName();
/*     */   }
/*     */ 
/*     */   
/*     */   public void traverse(ASTVisitor visitor, BlockScope scope) {
/* 113 */     if (visitor.visit(this, scope)) {
/* 114 */       int length = (this.typeReferences == null) ? 0 : this.typeReferences.length;
/* 115 */       for (int i = 0; i < length; i++) {
/* 116 */         this.typeReferences[i].traverse(visitor, scope);
/*     */       }
/*     */     } 
/* 119 */     visitor.endVisit(this, scope);
/*     */   }
/*     */ 
/*     */   
/*     */   public void traverse(ASTVisitor visitor, ClassScope scope) {
/* 124 */     if (visitor.visit(this, scope)) {
/* 125 */       int length = (this.typeReferences == null) ? 0 : this.typeReferences.length;
/* 126 */       for (int i = 0; i < length; i++) {
/* 127 */         this.typeReferences[i].traverse(visitor, scope);
/*     */       }
/*     */     } 
/* 130 */     visitor.endVisit(this, scope);
/*     */   }
/*     */ 
/*     */   
/*     */   public StringBuffer printExpression(int indent, StringBuffer output) {
/* 135 */     int length = (this.typeReferences == null) ? 0 : this.typeReferences.length;
/* 136 */     printIndent(indent, output);
/* 137 */     for (int i = 0; i < length; i++) {
/* 138 */       this.typeReferences[i].printExpression(0, output);
/* 139 */       if (i != length - 1) {
/* 140 */         output.append(" | ");
/*     */       }
/*     */     } 
/* 143 */     return output;
/*     */   }
/*     */   
/*     */   public boolean isUnionType() {
/* 147 */     return true;
/*     */   }
/*     */   
/*     */   public TypeReference augmentTypeWithAdditionalDimensions(int additionalDimensions, Annotation[][] additionalAnnotations, boolean isVarargs) {
/* 151 */     return this;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\ast\UnionTypeReference.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */