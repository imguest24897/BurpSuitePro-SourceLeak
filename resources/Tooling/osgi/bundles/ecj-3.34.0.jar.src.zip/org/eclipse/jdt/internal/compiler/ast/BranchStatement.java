/*    */ package org.eclipse.jdt.internal.compiler.ast;
/*    */ 
/*    */ import org.eclipse.jdt.internal.compiler.codegen.BranchLabel;
/*    */ import org.eclipse.jdt.internal.compiler.codegen.CodeStream;
/*    */ import org.eclipse.jdt.internal.compiler.lookup.BlockScope;
/*    */ import org.eclipse.jdt.internal.compiler.lookup.Scope;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class BranchStatement
/*    */   extends Statement
/*    */ {
/*    */   public char[] label;
/*    */   public BranchLabel targetLabel;
/*    */   public SubRoutineStatement[] subroutines;
/* 24 */   public int initStateIndex = -1;
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public BranchStatement(char[] label, int sourceStart, int sourceEnd) {
/* 30 */     this.label = label;
/* 31 */     this.sourceStart = sourceStart;
/* 32 */     this.sourceEnd = sourceEnd;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected void setSubroutineSwitchExpression(SubRoutineStatement sub) {}
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected void restartExceptionLabels(CodeStream codeStream) {}
/*    */ 
/*    */ 
/*    */   
/*    */   public void generateCode(BlockScope currentScope, CodeStream codeStream) {
/* 48 */     if ((this.bits & Integer.MIN_VALUE) == 0) {
/*    */       return;
/*    */     }
/* 51 */     int pc = codeStream.position;
/*    */ 
/*    */ 
/*    */     
/* 55 */     if (this.subroutines != null) {
/* 56 */       for (int i = 0, max = this.subroutines.length; i < max; i++) {
/* 57 */         SubRoutineStatement sub = this.subroutines[i];
/* 58 */         SwitchExpression se = sub.getSwitchExpression();
/* 59 */         setSubroutineSwitchExpression(sub);
/* 60 */         boolean didEscape = sub.generateSubRoutineInvocation(currentScope, codeStream, this.targetLabel, this.initStateIndex, null);
/* 61 */         sub.setSwitchExpression(se);
/* 62 */         if (didEscape) {
/* 63 */           codeStream.recordPositionsFrom(pc, this.sourceStart);
/* 64 */           SubRoutineStatement.reenterAllExceptionHandlers(this.subroutines, i, codeStream);
/* 65 */           if (this.initStateIndex != -1) {
/* 66 */             codeStream.removeNotDefinitelyAssignedVariables((Scope)currentScope, this.initStateIndex);
/* 67 */             codeStream.addDefinitelyAssignedVariables((Scope)currentScope, this.initStateIndex);
/*    */           } 
/* 69 */           restartExceptionLabels(codeStream);
/*    */           
/*    */           return;
/*    */         } 
/*    */       } 
/*    */     }
/* 75 */     codeStream.goto_(this.targetLabel);
/* 76 */     codeStream.recordPositionsFrom(pc, this.sourceStart);
/* 77 */     SubRoutineStatement.reenterAllExceptionHandlers(this.subroutines, -1, codeStream);
/* 78 */     if (this.initStateIndex != -1) {
/* 79 */       codeStream.removeNotDefinitelyAssignedVariables((Scope)currentScope, this.initStateIndex);
/* 80 */       codeStream.addDefinitelyAssignedVariables((Scope)currentScope, this.initStateIndex);
/*    */     } 
/*    */   }
/*    */   
/*    */   public void resolve(BlockScope scope) {}
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\ast\BranchStatement.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */