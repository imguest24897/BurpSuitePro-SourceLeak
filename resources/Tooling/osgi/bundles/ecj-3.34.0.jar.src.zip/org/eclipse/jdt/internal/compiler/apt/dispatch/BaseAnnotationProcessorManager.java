/*     */ package org.eclipse.jdt.internal.compiler.apt.dispatch;
/*     */ 
/*     */ import java.io.PrintWriter;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.eclipse.jdt.internal.compiler.AbstractAnnotationProcessorManager;
/*     */ import org.eclipse.jdt.internal.compiler.Compiler;
/*     */ import org.eclipse.jdt.internal.compiler.ast.CompilationUnitDeclaration;
/*     */ import org.eclipse.jdt.internal.compiler.env.ICompilationUnit;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.ModuleBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.ReferenceBinding;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class BaseAnnotationProcessorManager
/*     */   extends AbstractAnnotationProcessorManager
/*     */   implements IProcessorProvider
/*     */ {
/*     */   protected PrintWriter _out;
/*     */   protected PrintWriter _err;
/*     */   protected BaseProcessingEnvImpl _processingEnv;
/*     */   public boolean _isFirstRound = true;
/*  56 */   protected List<ProcessorInfo> _processors = new ArrayList<>();
/*     */ 
/*     */   
/*     */   protected boolean _printProcessorInfo = false;
/*     */ 
/*     */   
/*     */   protected boolean _printRounds = false;
/*     */ 
/*     */   
/*     */   protected int _round;
/*     */ 
/*     */   
/*     */   public void configure(Object batchCompiler, String[] options) {
/*  69 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void configureFromPlatform(Compiler compiler, Object compilationUnitLocator, Object javaProject, boolean isTestCode) {
/*  78 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   
/*     */   public List<ProcessorInfo> getDiscoveredProcessors() {
/*  83 */     return this._processors;
/*     */   }
/*     */ 
/*     */   
/*     */   public ICompilationUnit[] getDeletedUnits() {
/*  88 */     return this._processingEnv.getDeletedUnits();
/*     */   }
/*     */ 
/*     */   
/*     */   public ICompilationUnit[] getNewUnits() {
/*  93 */     return this._processingEnv.getNewUnits();
/*     */   }
/*     */ 
/*     */   
/*     */   public ReferenceBinding[] getNewClassFiles() {
/*  98 */     return this._processingEnv.getNewClassFiles();
/*     */   }
/*     */ 
/*     */   
/*     */   public void reset() {
/* 103 */     this._processingEnv.reset();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setErr(PrintWriter err) {
/* 111 */     this._err = err;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setOut(PrintWriter out) {
/* 119 */     this._out = out;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setProcessors(Object[] processors) {
/* 128 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void processAnnotations(CompilationUnitDeclaration[] units, ReferenceBinding[] referenceBindings, boolean isLastRound) {
/* 152 */     if (units != null) {
/* 153 */       byte b; int i; CompilationUnitDeclaration[] arrayOfCompilationUnitDeclaration; for (i = (arrayOfCompilationUnitDeclaration = units).length, b = 0; b < i; ) { CompilationUnitDeclaration declaration = arrayOfCompilationUnitDeclaration[b];
/* 154 */         if (declaration != null && declaration.scope != null) {
/* 155 */           ModuleBinding m = declaration.scope.module();
/* 156 */           if (m != null) {
/* 157 */             this._processingEnv._current_module = m; break;
/*     */           } 
/*     */         } 
/*     */         b++; }
/*     */     
/*     */     } 
/* 163 */     RoundEnvImpl roundEnv = new RoundEnvImpl(units, referenceBindings, isLastRound, this._processingEnv);
/* 164 */     PrintWriter out = this._out;
/* 165 */     PrintWriter traceProcessorInfo = this._printProcessorInfo ? out : null;
/* 166 */     PrintWriter traceRounds = this._printRounds ? out : null;
/* 167 */     if (traceRounds != null) {
/* 168 */       traceRounds.println("Round " + ++this._round + ':');
/*     */     }
/* 170 */     RoundDispatcher dispatcher = new RoundDispatcher(
/* 171 */         this, roundEnv, roundEnv.getRootAnnotations(), traceProcessorInfo, traceRounds);
/* 172 */     dispatcher.round();
/* 173 */     if (this._isFirstRound)
/* 174 */       this._isFirstRound = false; 
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\apt\dispatch\BaseAnnotationProcessorManager.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */