/*     */ package org.eclipse.jdt.internal.compiler.ast;
/*     */ 
/*     */ import org.eclipse.jdt.internal.compiler.ASTVisitor;
/*     */ import org.eclipse.jdt.internal.compiler.codegen.CodeStream;
/*     */ import org.eclipse.jdt.internal.compiler.flow.FlowContext;
/*     */ import org.eclipse.jdt.internal.compiler.flow.FlowInfo;
/*     */ import org.eclipse.jdt.internal.compiler.flow.UnconditionalFlowInfo;
/*     */ import org.eclipse.jdt.internal.compiler.impl.Constant;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.BlockScope;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.LocalVariableBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.LookupEnvironment;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.Scope;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.TypeBinding;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CompoundAssignment
/*     */   extends Assignment
/*     */   implements OperatorIds
/*     */ {
/*     */   public int operator;
/*     */   public int preAssignImplicitConversion;
/*     */   
/*     */   public CompoundAssignment(Expression lhs, Expression expression, int operator, int sourceEnd) {
/*  40 */     super(lhs, expression, sourceEnd);
/*  41 */     lhs.bits &= 0xFFFFDFFF;
/*  42 */     lhs.bits |= 0x10000;
/*  43 */     this.operator = operator;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public FlowInfo analyseCode(BlockScope currentScope, FlowContext flowContext, FlowInfo flowInfo) {
/*  52 */     if (this.resolvedType.id != 11) {
/*  53 */       this.lhs.checkNPE(currentScope, flowContext, flowInfo);
/*     */       
/*  55 */       flowContext.recordAbruptExit();
/*     */     } 
/*  57 */     this.expression.checkNPEbyUnboxing(currentScope, flowContext, flowInfo);
/*  58 */     UnconditionalFlowInfo unconditionalFlowInfo = ((Reference)this.lhs).analyseAssignment(currentScope, flowContext, flowInfo, this, true).unconditionalInits();
/*  59 */     if (this.resolvedType.id == 11) {
/*     */       
/*  61 */       LocalVariableBinding local = this.lhs.localVariableBinding();
/*  62 */       if (local != null) {
/*     */         
/*  64 */         unconditionalFlowInfo.markAsDefinitelyNonNull(local);
/*  65 */         flowContext.markFinallyNullStatus(local, 4);
/*     */       } 
/*     */     } 
/*  68 */     return (FlowInfo)unconditionalFlowInfo;
/*     */   }
/*     */   
/*     */   public boolean checkCastCompatibility() {
/*  72 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void generateCode(BlockScope currentScope, CodeStream codeStream, boolean valueRequired) {
/*  81 */     int pc = codeStream.position;
/*  82 */     ((Reference)this.lhs).generateCompoundAssignment(currentScope, codeStream, this.expression, this.operator, this.preAssignImplicitConversion, valueRequired);
/*  83 */     if (valueRequired) {
/*  84 */       codeStream.generateImplicitConversion(this.implicitConversion);
/*     */     }
/*  86 */     codeStream.recordPositionsFrom(pc, this.sourceStart);
/*     */   }
/*     */ 
/*     */   
/*     */   public int nullStatus(FlowInfo flowInfo, FlowContext flowContext) {
/*  91 */     return 4;
/*     */   }
/*     */ 
/*     */   
/*     */   public String operatorToString() {
/*  96 */     switch (this.operator) {
/*     */       case 14:
/*  98 */         return "+=";
/*     */       case 13:
/* 100 */         return "-=";
/*     */       case 15:
/* 102 */         return "*=";
/*     */       case 9:
/* 104 */         return "/=";
/*     */       case 2:
/* 106 */         return "&=";
/*     */       case 3:
/* 108 */         return "|=";
/*     */       case 8:
/* 110 */         return "^=";
/*     */       case 16:
/* 112 */         return "%=";
/*     */       case 10:
/* 114 */         return "<<=";
/*     */       case 17:
/* 116 */         return ">>=";
/*     */       case 19:
/* 118 */         return ">>>=";
/*     */     } 
/* 120 */     return "unknown operator";
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public StringBuffer printExpressionNoParenthesis(int indent, StringBuffer output) {
/* 126 */     this.lhs.printExpression(indent, output).append(' ').append(operatorToString()).append(' ');
/* 127 */     return this.expression.printExpression(0, output);
/*     */   }
/*     */ 
/*     */   
/*     */   public TypeBinding resolveType(BlockScope scope) {
/* 132 */     this.constant = Constant.NotAConstant;
/* 133 */     if (!(this.lhs instanceof Reference) || this.lhs.isThis()) {
/* 134 */       scope.problemReporter().expressionShouldBeAVariable(this.lhs);
/* 135 */       return null;
/*     */     } 
/* 137 */     boolean expressionIsCast = this.expression instanceof CastExpression;
/* 138 */     if (expressionIsCast)
/* 139 */       this.expression.bits |= 0x20; 
/* 140 */     TypeBinding originalLhsType = this.lhs.resolveType(scope);
/* 141 */     TypeBinding originalExpressionType = this.expression.resolveType(scope);
/* 142 */     if (originalLhsType == null || originalExpressionType == null) {
/* 143 */       return null;
/*     */     }
/* 145 */     LookupEnvironment env = scope.environment();
/* 146 */     TypeBinding lhsType = originalLhsType, expressionType = originalExpressionType;
/* 147 */     boolean use15specifics = ((scope.compilerOptions()).sourceLevel >= 3211264L);
/* 148 */     boolean unboxedLhs = false;
/* 149 */     if (use15specifics) {
/* 150 */       if (!lhsType.isBaseType() && expressionType.id != 11 && expressionType.id != 12) {
/* 151 */         TypeBinding unboxedType = env.computeBoxingType(lhsType);
/* 152 */         if (TypeBinding.notEquals(unboxedType, lhsType)) {
/* 153 */           lhsType = unboxedType;
/* 154 */           unboxedLhs = true;
/*     */         } 
/*     */       } 
/* 157 */       if (!expressionType.isBaseType() && lhsType.id != 11 && lhsType.id != 12) {
/* 158 */         expressionType = env.computeBoxingType(expressionType);
/*     */       }
/*     */     } 
/*     */     
/* 162 */     if (restrainUsageToNumericTypes() && !lhsType.isNumericType()) {
/* 163 */       scope.problemReporter().operatorOnlyValidOnNumericType(this, lhsType, expressionType);
/* 164 */       return null;
/*     */     } 
/* 166 */     int lhsID = lhsType.id;
/* 167 */     int expressionID = expressionType.id;
/* 168 */     if (lhsID > 15 || expressionID > 15) {
/* 169 */       if (lhsID != 11) {
/* 170 */         scope.problemReporter().invalidOperator(this, lhsType, expressionType);
/* 171 */         return null;
/*     */       } 
/* 173 */       expressionID = 1;
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 182 */     int result = OperatorExpression.OperatorSignatures[this.operator][(lhsID << 4) + expressionID];
/* 183 */     if (result == 0) {
/* 184 */       scope.problemReporter().invalidOperator(this, lhsType, expressionType);
/* 185 */       return null;
/*     */     } 
/* 187 */     if (this.operator == 14) {
/* 188 */       if (lhsID == 1 && (scope.compilerOptions()).complianceLevel < 3342336L) {
/*     */         
/* 190 */         scope.problemReporter().invalidOperator(this, lhsType, expressionType);
/* 191 */         return null;
/*     */       } 
/*     */       
/* 194 */       if ((lhsType.isNumericType() || lhsID == 5) && !expressionType.isNumericType()) {
/* 195 */         scope.problemReporter().invalidOperator(this, lhsType, expressionType);
/* 196 */         return null;
/*     */       } 
/*     */     } 
/*     */     
/* 200 */     TypeBinding resultType = TypeBinding.wellKnownType((Scope)scope, result & 0xF);
/* 201 */     if (checkCastCompatibility() && 
/* 202 */       originalLhsType.id != 11 && resultType.id != 11 && 
/* 203 */       !checkCastTypesCompatibility((Scope)scope, originalLhsType, resultType, (Expression)null, true)) {
/* 204 */       scope.problemReporter().invalidOperator(this, originalLhsType, expressionType);
/* 205 */       return null;
/*     */     } 
/*     */ 
/*     */     
/* 209 */     this.lhs.computeConversion((Scope)scope, TypeBinding.wellKnownType((Scope)scope, result >>> 16 & 0xF), originalLhsType);
/* 210 */     this.expression.computeConversion((Scope)scope, TypeBinding.wellKnownType((Scope)scope, result >>> 8 & 0xF), originalExpressionType);
/* 211 */     this.preAssignImplicitConversion = (unboxedLhs ? 512 : 0) | lhsID << 4 | result & 0xF;
/* 212 */     if (unboxedLhs) scope.problemReporter().autoboxing(this, lhsType, originalLhsType); 
/* 213 */     if (expressionIsCast)
/* 214 */       CastExpression.checkNeedForArgumentCasts(scope, this.operator, result, this.lhs, originalLhsType.id, false, this.expression, originalExpressionType.id, true); 
/* 215 */     return this.resolvedType = originalLhsType;
/*     */   }
/*     */   
/*     */   public boolean restrainUsageToNumericTypes() {
/* 219 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public void traverse(ASTVisitor visitor, BlockScope scope) {
/* 224 */     if (visitor.visit(this, scope)) {
/* 225 */       this.lhs.traverse(visitor, scope);
/* 226 */       this.expression.traverse(visitor, scope);
/*     */     } 
/* 228 */     visitor.endVisit(this, scope);
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\ast\CompoundAssignment.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */