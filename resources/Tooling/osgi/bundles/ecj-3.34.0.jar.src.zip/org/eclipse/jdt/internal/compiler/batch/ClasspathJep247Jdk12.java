/*     */ package org.eclipse.jdt.internal.compiler.batch;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.nio.file.FileVisitResult;
/*     */ import java.nio.file.FileVisitor;
/*     */ import java.nio.file.Files;
/*     */ import java.nio.file.Path;
/*     */ import java.nio.file.attribute.BasicFileAttributes;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.function.Function;
/*     */ import org.eclipse.jdt.core.compiler.CharOperation;
/*     */ import org.eclipse.jdt.internal.compiler.classfmt.ClassFileReader;
/*     */ import org.eclipse.jdt.internal.compiler.classfmt.ClassFormatException;
/*     */ import org.eclipse.jdt.internal.compiler.env.AccessRuleSet;
/*     */ import org.eclipse.jdt.internal.compiler.env.IBinaryModule;
/*     */ import org.eclipse.jdt.internal.compiler.env.IBinaryType;
/*     */ import org.eclipse.jdt.internal.compiler.env.IModule;
/*     */ import org.eclipse.jdt.internal.compiler.env.NameEnvironmentAnswer;
/*     */ import org.eclipse.jdt.internal.compiler.util.CtSym;
/*     */ import org.eclipse.jdt.internal.compiler.util.JRTUtil;
/*     */ import org.eclipse.jdt.internal.compiler.util.Util;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ClasspathJep247Jdk12
/*     */   extends ClasspathJep247
/*     */ {
/*     */   Map<String, IModule> modules;
/*  47 */   static String MODULE_INFO = "module-info.sig";
/*     */   
/*     */   public ClasspathJep247Jdk12(File jdkHome, String release, AccessRuleSet accessRuleSet) {
/*  50 */     super(jdkHome, release, accessRuleSet);
/*     */   }
/*     */   
/*     */   public List<FileSystem.Classpath> fetchLinkedJars(FileSystem.ClasspathSectionProblemReporter problemReporter) {
/*  54 */     return null;
/*     */   }
/*     */   
/*     */   public NameEnvironmentAnswer findClass(char[] typeName, String qualifiedPackageName, String moduleName, String qualifiedBinaryFileName) {
/*  58 */     return findClass(typeName, qualifiedPackageName, moduleName, qualifiedBinaryFileName, false);
/*     */   }
/*     */   
/*     */   public NameEnvironmentAnswer findClass(char[] typeName, String qualifiedPackageName, String moduleName, String qualifiedBinaryFileName, boolean asBinaryOnly) {
/*  62 */     if (!isPackage(qualifiedPackageName, moduleName)) {
/*  63 */       return null;
/*     */     }
/*     */     try {
/*  66 */       IBinaryType reader = null;
/*  67 */       Path p = null;
/*  68 */       byte[] content = null;
/*  69 */       char[] foundModName = null;
/*  70 */       qualifiedBinaryFileName = qualifiedBinaryFileName.replace(".class", ".sig");
/*  71 */       if (this.subReleases != null && this.subReleases.length > 0) {
/*  72 */         byte b; int i; String[] arrayOfString; for (i = (arrayOfString = this.subReleases).length, b = 0; b < i; ) { String rel = arrayOfString[b];
/*  73 */           if (moduleName == null) {
/*  74 */             Exception exception2; p = this.fs.getPath(rel, new String[0]);
/*  75 */             Exception exception1 = null;
/*     */ 
/*     */ 
/*     */ 
/*     */           
/*     */           }
/*     */           else {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */             
/*  87 */             p = this.fs.getPath(rel, new String[] { moduleName, qualifiedBinaryFileName });
/*  88 */             if (Files.exists(p, new java.nio.file.LinkOption[0])) {
/*  89 */               content = JRTUtil.safeReadBytes(p);
/*  90 */               if (content != null)
/*     */                 break; 
/*     */             } 
/*     */           }  b++; }
/*     */       
/*     */       } else {
/*  96 */         p = this.fs.getPath(this.releaseInHex, new String[] { qualifiedBinaryFileName });
/*  97 */         content = JRTUtil.safeReadBytes(p);
/*     */       } 
/*  99 */       if (content != null) {
/* 100 */         ClassFileReader classFileReader = new ClassFileReader(p.toUri(), content, qualifiedBinaryFileName.toCharArray());
/* 101 */         IBinaryType iBinaryType = maybeDecorateForExternalAnnotations(qualifiedBinaryFileName, (IBinaryType)classFileReader);
/* 102 */         char[] modName = (moduleName != null) ? moduleName.toCharArray() : foundModName;
/* 103 */         return new NameEnvironmentAnswer(iBinaryType, fetchAccessRestriction(qualifiedBinaryFileName), modName);
/*     */       } 
/* 105 */     } catch (ClassFormatException|IOException classFormatException) {}
/*     */ 
/*     */     
/* 108 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public void initialize() throws IOException {
/* 113 */     if (this.compliance == null) {
/*     */       return;
/*     */     }
/* 116 */     if (this.fs != null) {
/* 117 */       super.initialize();
/*     */       return;
/*     */     } 
/* 120 */     this.releaseInHex = CtSym.getReleaseCode(this.compliance);
/* 121 */     Path filePath = this.jdkHome.toPath().resolve("lib").resolve("ct.sym");
/* 122 */     if (!Files.exists(filePath, new java.nio.file.LinkOption[0])) {
/*     */       return;
/*     */     }
/* 125 */     this.fs = JRTUtil.getJarFileSystem(filePath);
/* 126 */     this.releasePath = this.fs.getPath("/", new String[0]);
/* 127 */     if (!Files.exists(this.fs.getPath(this.releaseInHex, new String[0]), new java.nio.file.LinkOption[0])) {
/* 128 */       throw new IllegalArgumentException("release " + this.compliance + " is not found in the system");
/*     */     }
/* 130 */     List<String> sub = new ArrayList<>(); try {
/* 131 */       Exception exception2, exception1 = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     }
/* 138 */     catch (IOException e) {
/* 139 */       String error = "Failed to walk subreleases for release " + this.releasePath + " in " + filePath;
/* 140 */       if (JRTUtil.PROPAGATE_IO_ERRORS) {
/* 141 */         throw new IllegalStateException(error, e);
/*     */       }
/* 143 */       System.err.println(error);
/* 144 */       e.printStackTrace();
/*     */     } 
/*     */     
/* 147 */     super.initialize();
/*     */   }
/*     */ 
/*     */   
/*     */   public void loadModules() {
/* 152 */     if (this.jdklevel <= 3407872L) {
/* 153 */       super.loadModules();
/*     */       return;
/*     */     } 
/* 156 */     Path modPath = this.fs.getPath(this.releaseInHex, new String[0]);
/* 157 */     this.modulePath = String.valueOf(this.file.getPath()) + "|" + modPath.toString();
/* 158 */     Map<String, IModule> cache = ModulesCache.computeIfAbsent(this.modulePath, key -> {
/*     */           HashMap<String, IModule> newCache = new HashMap<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/*     */           try {
/*     */             Exception exception2;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */             
/*     */             Exception exception1 = null;
/* 202 */           } catch (IOException e) {
/*     */             String error = "Failed to walk modules for " + key;
/*     */             
/*     */             if (JRTUtil.PROPAGATE_IO_ERRORS) {
/*     */               throw new IllegalStateException(error, e);
/*     */             }
/*     */             System.err.println(error);
/*     */             e.printStackTrace();
/*     */             return null;
/*     */           } 
/*     */           return newCache.isEmpty() ? null : Collections.<String, IModule>unmodifiableMap(newCache);
/*     */         });
/* 214 */     this.modules = cache;
/* 215 */     this.moduleNamesCache.addAll(cache.keySet());
/*     */   }
/*     */   
/*     */   public Collection<String> getModuleNames(Collection<String> limitModule, Function<String, IModule> getModule) {
/* 219 */     return selectModules(this.moduleNamesCache, limitModule, getModule);
/*     */   }
/*     */ 
/*     */   
/*     */   public IModule getModule(char[] moduleName) {
/* 224 */     if (this.jdklevel <= 3407872L) {
/* 225 */       return super.getModule(moduleName);
/*     */     }
/* 227 */     if (this.modules != null) {
/* 228 */       return this.modules.get(String.valueOf(moduleName));
/*     */     }
/* 230 */     return null;
/*     */   }
/*     */   void acceptModule(String name, byte[] content, Map<String, IModule> cache) {
/* 233 */     if (content == null) {
/*     */       return;
/*     */     }
/* 236 */     if (cache.containsKey(name)) {
/*     */       return;
/*     */     }
/* 239 */     ClassFileReader reader = null;
/*     */     try {
/* 241 */       reader = new ClassFileReader(content, "module-info.class".toCharArray());
/* 242 */     } catch (ClassFormatException e) {
/* 243 */       e.printStackTrace();
/*     */     } 
/* 245 */     if (reader != null) {
/* 246 */       acceptModule(reader, cache);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   void acceptModule(ClassFileReader reader, Map<String, IModule> cache) {
/* 252 */     if (this.jdklevel <= 3407872L) {
/* 253 */       super.acceptModule(reader, cache);
/*     */       return;
/*     */     } 
/* 256 */     if (reader != null) {
/* 257 */       IBinaryModule iBinaryModule = reader.getModuleDeclaration();
/* 258 */       if (iBinaryModule != null) {
/* 259 */         cache.put(String.valueOf(iBinaryModule.name()), iBinaryModule);
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   public synchronized char[][] getModulesDeclaringPackage(String qualifiedPackageName, String moduleName) {
/* 265 */     if (this.jdklevel >= 3473408L) {
/*     */       
/* 267 */       List<String> mods = JRTUtil.getModulesDeclaringPackage(this.file, qualifiedPackageName, moduleName);
/* 268 */       return CharOperation.toCharArrays(mods);
/*     */     } 
/* 270 */     if (this.packageCache == null) {
/* 271 */       this.packageCache = new HashSet<>(41);
/* 272 */       this.packageCache.add(Util.EMPTY_STRING); try {
/* 273 */         Exception exception2, exception1 = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       }
/* 309 */       catch (IOException e) {
/* 310 */         String error = "Failed to find module " + moduleName + " defining package " + qualifiedPackageName + 
/* 311 */           " in release " + this.releasePath + " in " + this;
/* 312 */         if (JRTUtil.PROPAGATE_IO_ERRORS) {
/* 313 */           throw new IllegalStateException(error, e);
/*     */         }
/* 315 */         System.err.println(error);
/* 316 */         e.printStackTrace();
/*     */       } 
/*     */     } 
/*     */     
/* 320 */     return singletonModuleNameIf(this.packageCache.contains(qualifiedPackageName));
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\batch\ClasspathJep247Jdk12.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */