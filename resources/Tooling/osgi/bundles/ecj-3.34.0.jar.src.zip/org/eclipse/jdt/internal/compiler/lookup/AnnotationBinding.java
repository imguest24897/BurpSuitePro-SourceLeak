/*     */ package org.eclipse.jdt.internal.compiler.lookup;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import org.eclipse.jdt.core.compiler.CharOperation;
/*     */ import org.eclipse.jdt.internal.compiler.ast.Annotation;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AnnotationBinding
/*     */ {
/*     */   ReferenceBinding type;
/*     */   ElementValuePair[] pairs;
/*     */   
/*     */   public static AnnotationBinding[] addStandardAnnotations(AnnotationBinding[] recordedAnnotations, long annotationTagBits, LookupEnvironment env) {
/*  41 */     if ((annotationTagBits & 0x77FFFFF840000000L) == 0L) {
/*  42 */       return recordedAnnotations;
/*     */     }
/*  44 */     boolean haveDeprecated = false;
/*  45 */     boolean hasTarget = false; byte b; int i; AnnotationBinding[] arrayOfAnnotationBinding1;
/*  46 */     for (i = (arrayOfAnnotationBinding1 = recordedAnnotations).length, b = 0; b < i; ) { AnnotationBinding ab = arrayOfAnnotationBinding1[b];
/*  47 */       ReferenceBinding type = ab.getAnnotationType();
/*  48 */       if (type.id == 44) {
/*  49 */         haveDeprecated = true;
/*  50 */       } else if (type.id == 50) {
/*  51 */         hasTarget = true;
/*     */       }  b++; }
/*     */     
/*  54 */     int count = 0;
/*  55 */     if (!hasTarget && (annotationTagBits & 0x20600FF840000000L) != 0L)
/*  56 */       count++; 
/*  57 */     if ((annotationTagBits & 0x300000000000L) != 0L)
/*  58 */       count++; 
/*  59 */     if (!haveDeprecated && (annotationTagBits & 0x400000000000L) != 0L)
/*  60 */       count++; 
/*  61 */     if ((annotationTagBits & 0x800000000000L) != 0L)
/*  62 */       count++; 
/*  63 */     if ((annotationTagBits & 0x1000000000000L) != 0L)
/*  64 */       count++; 
/*  65 */     if ((annotationTagBits & 0x2000000000000L) != 0L)
/*  66 */       count++; 
/*  67 */     if ((annotationTagBits & 0x4000000000000L) != 0L)
/*  68 */       count++; 
/*  69 */     if ((annotationTagBits & 0x10000000000000L) != 0L)
/*  70 */       count++; 
/*  71 */     if ((annotationTagBits & 0x8000000000000L) != 0L)
/*  72 */       count++; 
/*  73 */     if (count == 0)
/*     */     {
/*  75 */       return recordedAnnotations;
/*     */     }
/*     */     
/*  78 */     int index = recordedAnnotations.length;
/*  79 */     AnnotationBinding[] result = new AnnotationBinding[index + count];
/*  80 */     System.arraycopy(recordedAnnotations, 0, result, 0, index);
/*  81 */     if ((annotationTagBits & 0x20600FF840000000L) != 0L) {
/*     */       
/*  83 */       AnnotationBinding targetAnnot = buildTargetAnnotation(annotationTagBits, env);
/*  84 */       if (!hasTarget) {
/*  85 */         result[index++] = targetAnnot;
/*     */       }
/*     */     } 
/*  88 */     if ((annotationTagBits & 0x300000000000L) != 0L)
/*  89 */       result[index++] = buildRetentionAnnotation(annotationTagBits, env); 
/*  90 */     if (!haveDeprecated && (annotationTagBits & 0x400000000000L) != 0L)
/*  91 */       result[index++] = buildMarkerAnnotation(TypeConstants.JAVA_LANG_DEPRECATED, env.javaBaseModule(), env); 
/*  92 */     if ((annotationTagBits & 0x800000000000L) != 0L)
/*  93 */       result[index++] = buildMarkerAnnotation(TypeConstants.JAVA_LANG_ANNOTATION_DOCUMENTED, env.javaBaseModule(), env); 
/*  94 */     if ((annotationTagBits & 0x1000000000000L) != 0L)
/*  95 */       result[index++] = buildMarkerAnnotation(TypeConstants.JAVA_LANG_ANNOTATION_INHERITED, env.javaBaseModule(), env); 
/*  96 */     if ((annotationTagBits & 0x2000000000000L) != 0L)
/*  97 */       result[index++] = buildMarkerAnnotation(TypeConstants.JAVA_LANG_OVERRIDE, env.javaBaseModule(), env); 
/*  98 */     if ((annotationTagBits & 0x4000000000000L) != 0L)
/*  99 */       result[index++] = buildMarkerAnnotation(TypeConstants.JAVA_LANG_SUPPRESSWARNINGS, env.javaBaseModule(), env); 
/* 100 */     if ((annotationTagBits & 0x10000000000000L) != 0L)
/* 101 */       result[index++] = buildMarkerAnnotationForMemberType(TypeConstants.JAVA_LANG_INVOKE_METHODHANDLE_$_POLYMORPHICSIGNATURE, env.javaBaseModule(), env); 
/* 102 */     if ((annotationTagBits & 0x8000000000000L) != 0L)
/* 103 */       result[index++] = buildMarkerAnnotation(TypeConstants.JAVA_LANG_SAFEVARARGS, env.javaBaseModule(), env); 
/* 104 */     return result;
/*     */   }
/*     */   
/*     */   private static AnnotationBinding buildMarkerAnnotationForMemberType(char[][] compoundName, ModuleBinding module, LookupEnvironment env) {
/* 108 */     ReferenceBinding type = env.getResolvedType(compoundName, module, null, false);
/*     */ 
/*     */     
/* 111 */     if (!type.isValidBinding()) {
/* 112 */       type = ((ProblemReferenceBinding)type).closestMatch;
/*     */     }
/* 114 */     return env.createAnnotation(type, Binding.NO_ELEMENT_VALUE_PAIRS);
/*     */   }
/*     */   
/*     */   private static AnnotationBinding buildMarkerAnnotation(char[][] compoundName, ModuleBinding module, LookupEnvironment env) {
/* 118 */     ReferenceBinding type = env.getResolvedType(compoundName, module, null, false);
/* 119 */     return env.createAnnotation(type, Binding.NO_ELEMENT_VALUE_PAIRS);
/*     */   }
/*     */   
/*     */   private static AnnotationBinding buildRetentionAnnotation(long bits, LookupEnvironment env) {
/* 123 */     ReferenceBinding retentionPolicy = 
/* 124 */       env.getResolvedJavaBaseType(TypeConstants.JAVA_LANG_ANNOTATION_RETENTIONPOLICY, 
/* 125 */         null);
/* 126 */     Object value = null;
/* 127 */     if ((bits & 0x300000000000L) == 52776558133248L) {
/* 128 */       value = retentionPolicy.getField(TypeConstants.UPPER_RUNTIME, true);
/* 129 */     } else if ((bits & 0x200000000000L) != 0L) {
/* 130 */       value = retentionPolicy.getField(TypeConstants.UPPER_CLASS, true);
/* 131 */     } else if ((bits & 0x100000000000L) != 0L) {
/* 132 */       value = retentionPolicy.getField(TypeConstants.UPPER_SOURCE, true);
/*     */     } 
/* 134 */     return env.createAnnotation(
/* 135 */         env.getResolvedJavaBaseType(TypeConstants.JAVA_LANG_ANNOTATION_RETENTION, null), 
/* 136 */         new ElementValuePair[] {
/* 137 */           new ElementValuePair(TypeConstants.VALUE, value, null)
/*     */         });
/*     */   }
/*     */   
/*     */   private static AnnotationBinding buildTargetAnnotation(long bits, LookupEnvironment env) {
/* 142 */     ReferenceBinding target = env.getResolvedJavaBaseType(TypeConstants.JAVA_LANG_ANNOTATION_TARGET, null);
/* 143 */     if ((bits & 0x800000000L) != 0L) {
/* 144 */       return new AnnotationBinding(target, Binding.NO_ELEMENT_VALUE_PAIRS);
/*     */     }
/* 146 */     int arraysize = 0;
/* 147 */     if ((bits & 0x40000000000L) != 0L)
/* 148 */       arraysize++; 
/* 149 */     if ((bits & 0x10000000000L) != 0L)
/* 150 */       arraysize++; 
/* 151 */     if ((bits & 0x2000000000L) != 0L)
/* 152 */       arraysize++; 
/* 153 */     if ((bits & 0x20000000000L) != 0L)
/* 154 */       arraysize++; 
/* 155 */     if ((bits & 0x4000000000L) != 0L)
/* 156 */       arraysize++; 
/* 157 */     if ((bits & 0x80000000000L) != 0L)
/* 158 */       arraysize++; 
/* 159 */     if ((bits & 0x8000000000L) != 0L)
/* 160 */       arraysize++; 
/* 161 */     if ((bits & 0x1000000000L) != 0L)
/* 162 */       arraysize++; 
/* 163 */     if ((bits & 0x20000000000000L) != 0L)
/* 164 */       arraysize++; 
/* 165 */     if ((bits & 0x40000000000000L) != 0L)
/* 166 */       arraysize++; 
/* 167 */     if ((bits & 0x2000000000000000L) != 0L)
/* 168 */       arraysize++; 
/* 169 */     if ((bits & 0x40000000L) != 0L) {
/* 170 */       arraysize++;
/*     */     }
/* 172 */     Object[] value = new Object[arraysize];
/* 173 */     if (arraysize > 0) {
/* 174 */       ReferenceBinding elementType = env.getResolvedType(TypeConstants.JAVA_LANG_ANNOTATION_ELEMENTTYPE, null);
/* 175 */       int index = 0;
/* 176 */       if ((bits & 0x20000000000000L) != 0L)
/* 177 */         value[index++] = elementType.getField(TypeConstants.TYPE_USE_TARGET, true); 
/* 178 */       if ((bits & 0x40000000000L) != 0L)
/* 179 */         value[index++] = elementType.getField(TypeConstants.UPPER_ANNOTATION_TYPE, true); 
/* 180 */       if ((bits & 0x10000000000L) != 0L)
/* 181 */         value[index++] = elementType.getField(TypeConstants.UPPER_CONSTRUCTOR, true); 
/* 182 */       if ((bits & 0x2000000000L) != 0L)
/* 183 */         value[index++] = elementType.getField(TypeConstants.UPPER_FIELD, true); 
/* 184 */       if ((bits & 0x40000000L) != 0L)
/* 185 */         value[index++] = elementType.getField(TypeConstants.UPPER_RECORD_COMPONENT, true); 
/* 186 */       if ((bits & 0x4000000000L) != 0L)
/* 187 */         value[index++] = elementType.getField(TypeConstants.UPPER_METHOD, true); 
/* 188 */       if ((bits & 0x80000000000L) != 0L)
/* 189 */         value[index++] = elementType.getField(TypeConstants.UPPER_PACKAGE, true); 
/* 190 */       if ((bits & 0x8000000000L) != 0L)
/* 191 */         value[index++] = elementType.getField(TypeConstants.UPPER_PARAMETER, true); 
/* 192 */       if ((bits & 0x40000000000000L) != 0L)
/* 193 */         value[index++] = elementType.getField(TypeConstants.TYPE_PARAMETER_TARGET, true); 
/* 194 */       if ((bits & 0x1000000000L) != 0L)
/* 195 */         value[index++] = elementType.getField(TypeConstants.TYPE, true); 
/* 196 */       if ((bits & 0x20000000000L) != 0L)
/* 197 */         value[index++] = elementType.getField(TypeConstants.UPPER_LOCAL_VARIABLE, true); 
/*     */     } 
/* 199 */     return env.createAnnotation(
/* 200 */         target, 
/* 201 */         new ElementValuePair[] {
/* 202 */           new ElementValuePair(TypeConstants.VALUE, value, null)
/*     */         });
/*     */   }
/*     */   
/*     */   public AnnotationBinding(ReferenceBinding type, ElementValuePair[] pairs) {
/* 207 */     this.type = type;
/* 208 */     this.pairs = pairs;
/*     */   }
/*     */   
/*     */   AnnotationBinding(Annotation astAnnotation) {
/* 212 */     this((ReferenceBinding)astAnnotation.resolvedType, astAnnotation.computeElementValuePairs());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public char[] computeUniqueKey(char[] recipientKey) {
/* 221 */     char[] typeKey = this.type.computeUniqueKey(false);
/* 222 */     int recipientKeyLength = recipientKey.length;
/* 223 */     char[] uniqueKey = new char[recipientKeyLength + 1 + typeKey.length];
/* 224 */     System.arraycopy(recipientKey, 0, uniqueKey, 0, recipientKeyLength);
/* 225 */     uniqueKey[recipientKeyLength] = '@';
/* 226 */     System.arraycopy(typeKey, 0, uniqueKey, recipientKeyLength + 1, typeKey.length);
/* 227 */     return uniqueKey;
/*     */   }
/*     */   
/*     */   public ReferenceBinding getAnnotationType() {
/* 231 */     return this.type;
/*     */   }
/*     */ 
/*     */   
/*     */   public void resolve() {}
/*     */ 
/*     */   
/*     */   public ElementValuePair[] getElementValuePairs() {
/* 239 */     return this.pairs;
/*     */   }
/*     */ 
/*     */   
/*     */   public static void setMethodBindings(ReferenceBinding type, ElementValuePair[] pairs) {
/* 244 */     for (int i = pairs.length; --i >= 0; ) {
/* 245 */       ElementValuePair pair = pairs[i];
/* 246 */       MethodBinding[] methods = type.getMethods(pair.getName());
/*     */       
/* 248 */       if (methods != null && methods.length == 1) {
/* 249 */         pair.setMethodBinding(methods[0]);
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   public String toString() {
/* 255 */     StringBuilder buffer = new StringBuilder(5);
/* 256 */     buffer.append('@').append(this.type.sourceName);
/* 257 */     if (this.pairs != null && this.pairs.length > 0) {
/* 258 */       buffer.append('(');
/* 259 */       if (this.pairs.length == 1 && CharOperation.equals(this.pairs[0].getName(), TypeConstants.VALUE)) {
/* 260 */         buffer.append((this.pairs[0]).value);
/*     */       } else {
/* 262 */         for (int i = 0, max = this.pairs.length; i < max; i++) {
/* 263 */           if (i > 0) buffer.append(", "); 
/* 264 */           buffer.append(this.pairs[i]);
/*     */         } 
/*     */       } 
/* 267 */       buffer.append(')');
/*     */     } 
/* 269 */     return buffer.toString();
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 274 */     int result = 17;
/* 275 */     int c = getAnnotationType().hashCode();
/* 276 */     result = 31 * result + c;
/* 277 */     c = Arrays.hashCode((Object[])getElementValuePairs());
/* 278 */     result = 31 * result + c;
/* 279 */     return result;
/*     */   }
/*     */   
/*     */   public boolean equals(Object object) {
/* 283 */     if (this == object)
/* 284 */       return true; 
/* 285 */     if (!(object instanceof AnnotationBinding)) {
/* 286 */       return false;
/*     */     }
/* 288 */     AnnotationBinding that = (AnnotationBinding)object;
/* 289 */     if (getAnnotationType() != that.getAnnotationType()) {
/* 290 */       return false;
/*     */     }
/* 292 */     ElementValuePair[] thisElementValuePairs = getElementValuePairs();
/* 293 */     ElementValuePair[] thatElementValuePairs = that.getElementValuePairs();
/* 294 */     int length = thisElementValuePairs.length;
/* 295 */     if (length != thatElementValuePairs.length)
/* 296 */       return false; 
/* 297 */     for (int i = 0; i < length; i++)
/* 298 */     { ElementValuePair thisPair = thisElementValuePairs[i];
/* 299 */       int j = 0; while (true) { if (j >= length)
/*     */         {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 320 */           return false; }  ElementValuePair thatPair = thatElementValuePairs[j]; if (thisPair.binding == thatPair.binding) { if (thisPair.value == null) { if (thatPair.value == null) break;  return false; }  if (thatPair.value == null) return false;  if (thatPair.value instanceof Object[] && thisPair.value instanceof Object[]) { if (!Arrays.equals((Object[])thisPair.value, (Object[])thatPair.value))
/*     */               return false;  break; }  if (!thatPair.value.equals(thisPair.value))
/* 322 */             return false;  break; }  j++; }  }  return true;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\lookup\AnnotationBinding.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */