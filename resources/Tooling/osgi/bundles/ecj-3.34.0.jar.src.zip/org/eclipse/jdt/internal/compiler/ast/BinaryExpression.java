/*      */ package org.eclipse.jdt.internal.compiler.ast;
/*      */ 
/*      */ import org.eclipse.jdt.internal.compiler.ASTVisitor;
/*      */ import org.eclipse.jdt.internal.compiler.codegen.BranchLabel;
/*      */ import org.eclipse.jdt.internal.compiler.codegen.CodeStream;
/*      */ import org.eclipse.jdt.internal.compiler.flow.FlowContext;
/*      */ import org.eclipse.jdt.internal.compiler.flow.FlowInfo;
/*      */ import org.eclipse.jdt.internal.compiler.flow.UnconditionalFlowInfo;
/*      */ import org.eclipse.jdt.internal.compiler.impl.Constant;
/*      */ import org.eclipse.jdt.internal.compiler.lookup.ArrayBinding;
/*      */ import org.eclipse.jdt.internal.compiler.lookup.BlockScope;
/*      */ import org.eclipse.jdt.internal.compiler.lookup.LocalVariableBinding;
/*      */ import org.eclipse.jdt.internal.compiler.lookup.Scope;
/*      */ import org.eclipse.jdt.internal.compiler.lookup.TypeBinding;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class BinaryExpression
/*      */   extends OperatorExpression
/*      */ {
/*      */   public Expression left;
/*      */   public Expression right;
/*      */   public Constant optimizedBooleanConstant;
/*      */   
/*      */   public BinaryExpression(Expression left, Expression right, int operator) {
/*   45 */     this.left = left;
/*   46 */     this.right = right;
/*   47 */     this.bits |= operator << 8;
/*   48 */     this.sourceStart = left.sourceStart;
/*   49 */     this.sourceEnd = right.sourceEnd;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public BinaryExpression(BinaryExpression expression) {
/*   59 */     this.left = expression.left;
/*   60 */     this.right = expression.right;
/*   61 */     this.bits = expression.bits;
/*   62 */     this.sourceStart = expression.sourceStart;
/*   63 */     this.sourceEnd = expression.sourceEnd;
/*      */   }
/*      */ 
/*      */   
/*      */   public FlowInfo analyseCode(BlockScope currentScope, FlowContext flowContext, FlowInfo flowInfo) {
/*      */     try {
/*   69 */       if (this.resolvedType.id == 11) {
/*   70 */         return (FlowInfo)this.right.analyseCode(
/*   71 */             currentScope, flowContext, 
/*   72 */             (FlowInfo)this.left.analyseCode(currentScope, flowContext, flowInfo).unconditionalInits())
/*   73 */           .unconditionalInits();
/*      */       }
/*   75 */       UnconditionalFlowInfo unconditionalFlowInfo = this.left.analyseCode(currentScope, flowContext, flowInfo).unconditionalInits();
/*   76 */       this.left.checkNPE(currentScope, flowContext, (FlowInfo)unconditionalFlowInfo);
/*   77 */       if ((this.bits & 0x3F00) >> 8 != 2) {
/*   78 */         flowContext.expireNullCheckedFieldInfo();
/*      */       }
/*   80 */       unconditionalFlowInfo = this.right.analyseCode(currentScope, flowContext, (FlowInfo)unconditionalFlowInfo).unconditionalInits();
/*   81 */       this.right.checkNPE(currentScope, flowContext, (FlowInfo)unconditionalFlowInfo);
/*   82 */       if ((this.bits & 0x3F00) >> 8 != 2) {
/*   83 */         flowContext.expireNullCheckedFieldInfo();
/*      */       }
/*   85 */       return (FlowInfo)unconditionalFlowInfo;
/*      */     }
/*      */     finally {
/*      */       
/*   89 */       flowContext.recordAbruptExit();
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   protected void updateFlowOnBooleanResult(FlowInfo flowInfo, boolean result) {
/*   95 */     int operator = (this.bits & 0x3F00) >> 8;
/*   96 */     if (result ? (operator == 0) : (operator == 1)) {
/*   97 */       this.left.updateFlowOnBooleanResult(flowInfo, result);
/*   98 */       this.right.updateFlowOnBooleanResult(flowInfo, result);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public void computeConstant(BlockScope scope, int leftId, int rightId) {
/*  104 */     if (this.left.constant != Constant.NotAConstant && 
/*  105 */       this.right.constant != Constant.NotAConstant) {
/*      */       try {
/*  107 */         this.constant = 
/*  108 */           Constant.computeConstantOperation(
/*  109 */             this.left.constant, 
/*  110 */             leftId, (
/*  111 */             this.bits & 0x3F00) >> 8, 
/*  112 */             this.right.constant, 
/*  113 */             rightId);
/*  114 */       } catch (ArithmeticException arithmeticException) {
/*  115 */         this.constant = Constant.NotAConstant;
/*      */       }
/*      */     
/*      */     } else {
/*      */       
/*  120 */       this.constant = Constant.NotAConstant;
/*      */       
/*  122 */       optimizedBooleanConstant(
/*  123 */           leftId, (
/*  124 */           this.bits & 0x3F00) >> 8, 
/*  125 */           rightId);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public Constant optimizedBooleanConstant() {
/*  131 */     return (this.optimizedBooleanConstant == null) ? this.constant : this.optimizedBooleanConstant;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void generateCode(BlockScope currentScope, CodeStream codeStream, boolean valueRequired) {
/*      */     BranchLabel falseLabel;
/*  142 */     int pc = codeStream.position;
/*  143 */     if (this.constant != Constant.NotAConstant) {
/*  144 */       if (valueRequired)
/*  145 */         codeStream.generateConstant(this.constant, this.implicitConversion); 
/*  146 */       codeStream.recordPositionsFrom(pc, this.sourceStart);
/*      */       return;
/*      */     } 
/*  149 */     switch ((this.bits & 0x3F00) >> 8) {
/*      */       case 14:
/*  151 */         switch (this.bits & 0xF) {
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           case 11:
/*  157 */             codeStream.generateStringConcatenationAppend(currentScope, this.left, this.right);
/*  158 */             if (!valueRequired)
/*  159 */               codeStream.pop(); 
/*      */             break;
/*      */           case 10:
/*  162 */             this.left.generateCode(currentScope, codeStream, valueRequired);
/*  163 */             this.right.generateCode(currentScope, codeStream, valueRequired);
/*  164 */             if (valueRequired)
/*  165 */               codeStream.iadd(); 
/*      */             break;
/*      */           case 7:
/*  168 */             this.left.generateCode(currentScope, codeStream, valueRequired);
/*  169 */             this.right.generateCode(currentScope, codeStream, valueRequired);
/*  170 */             if (valueRequired)
/*  171 */               codeStream.ladd(); 
/*      */             break;
/*      */           case 8:
/*  174 */             this.left.generateCode(currentScope, codeStream, valueRequired);
/*  175 */             this.right.generateCode(currentScope, codeStream, valueRequired);
/*  176 */             if (valueRequired)
/*  177 */               codeStream.dadd(); 
/*      */             break;
/*      */           case 9:
/*  180 */             this.left.generateCode(currentScope, codeStream, valueRequired);
/*  181 */             this.right.generateCode(currentScope, codeStream, valueRequired);
/*  182 */             if (valueRequired)
/*  183 */               codeStream.fadd(); 
/*      */             break;
/*      */         } 
/*      */         break;
/*      */       case 13:
/*  188 */         switch (this.bits & 0xF) {
/*      */           case 10:
/*  190 */             this.left.generateCode(currentScope, codeStream, valueRequired);
/*  191 */             this.right.generateCode(currentScope, codeStream, valueRequired);
/*  192 */             if (valueRequired)
/*  193 */               codeStream.isub(); 
/*      */             break;
/*      */           case 7:
/*  196 */             this.left.generateCode(currentScope, codeStream, valueRequired);
/*  197 */             this.right.generateCode(currentScope, codeStream, valueRequired);
/*  198 */             if (valueRequired)
/*  199 */               codeStream.lsub(); 
/*      */             break;
/*      */           case 8:
/*  202 */             this.left.generateCode(currentScope, codeStream, valueRequired);
/*  203 */             this.right.generateCode(currentScope, codeStream, valueRequired);
/*  204 */             if (valueRequired)
/*  205 */               codeStream.dsub(); 
/*      */             break;
/*      */           case 9:
/*  208 */             this.left.generateCode(currentScope, codeStream, valueRequired);
/*  209 */             this.right.generateCode(currentScope, codeStream, valueRequired);
/*  210 */             if (valueRequired)
/*  211 */               codeStream.fsub(); 
/*      */             break;
/*      */         } 
/*      */         break;
/*      */       case 15:
/*  216 */         switch (this.bits & 0xF) {
/*      */           case 10:
/*  218 */             this.left.generateCode(currentScope, codeStream, valueRequired);
/*  219 */             this.right.generateCode(currentScope, codeStream, valueRequired);
/*  220 */             if (valueRequired)
/*  221 */               codeStream.imul(); 
/*      */             break;
/*      */           case 7:
/*  224 */             this.left.generateCode(currentScope, codeStream, valueRequired);
/*  225 */             this.right.generateCode(currentScope, codeStream, valueRequired);
/*  226 */             if (valueRequired)
/*  227 */               codeStream.lmul(); 
/*      */             break;
/*      */           case 8:
/*  230 */             this.left.generateCode(currentScope, codeStream, valueRequired);
/*  231 */             this.right.generateCode(currentScope, codeStream, valueRequired);
/*  232 */             if (valueRequired)
/*  233 */               codeStream.dmul(); 
/*      */             break;
/*      */           case 9:
/*  236 */             this.left.generateCode(currentScope, codeStream, valueRequired);
/*  237 */             this.right.generateCode(currentScope, codeStream, valueRequired);
/*  238 */             if (valueRequired)
/*  239 */               codeStream.fmul(); 
/*      */             break;
/*      */         } 
/*      */         break;
/*      */       case 9:
/*  244 */         switch (this.bits & 0xF) {
/*      */           case 10:
/*  246 */             this.left.generateCode(currentScope, codeStream, true);
/*  247 */             this.right.generateCode(currentScope, codeStream, true);
/*  248 */             codeStream.idiv();
/*  249 */             if (!valueRequired)
/*  250 */               codeStream.pop(); 
/*      */             break;
/*      */           case 7:
/*  253 */             this.left.generateCode(currentScope, codeStream, true);
/*  254 */             this.right.generateCode(currentScope, codeStream, true);
/*  255 */             codeStream.ldiv();
/*  256 */             if (!valueRequired)
/*  257 */               codeStream.pop2(); 
/*      */             break;
/*      */           case 8:
/*  260 */             this.left.generateCode(currentScope, codeStream, valueRequired);
/*  261 */             this.right.generateCode(currentScope, codeStream, valueRequired);
/*  262 */             if (valueRequired)
/*  263 */               codeStream.ddiv(); 
/*      */             break;
/*      */           case 9:
/*  266 */             this.left.generateCode(currentScope, codeStream, valueRequired);
/*  267 */             this.right.generateCode(currentScope, codeStream, valueRequired);
/*  268 */             if (valueRequired)
/*  269 */               codeStream.fdiv(); 
/*      */             break;
/*      */         } 
/*      */         break;
/*      */       case 16:
/*  274 */         switch (this.bits & 0xF) {
/*      */           case 10:
/*  276 */             this.left.generateCode(currentScope, codeStream, true);
/*  277 */             this.right.generateCode(currentScope, codeStream, true);
/*  278 */             codeStream.irem();
/*  279 */             if (!valueRequired)
/*  280 */               codeStream.pop(); 
/*      */             break;
/*      */           case 7:
/*  283 */             this.left.generateCode(currentScope, codeStream, true);
/*  284 */             this.right.generateCode(currentScope, codeStream, true);
/*  285 */             codeStream.lrem();
/*  286 */             if (!valueRequired)
/*  287 */               codeStream.pop2(); 
/*      */             break;
/*      */           case 8:
/*  290 */             this.left.generateCode(currentScope, codeStream, valueRequired);
/*  291 */             this.right.generateCode(currentScope, codeStream, valueRequired);
/*  292 */             if (valueRequired)
/*  293 */               codeStream.drem(); 
/*      */             break;
/*      */           case 9:
/*  296 */             this.left.generateCode(currentScope, codeStream, valueRequired);
/*  297 */             this.right.generateCode(currentScope, codeStream, valueRequired);
/*  298 */             if (valueRequired)
/*  299 */               codeStream.frem(); 
/*      */             break;
/*      */         } 
/*      */         break;
/*      */       case 2:
/*  304 */         switch (this.bits & 0xF) {
/*      */           
/*      */           case 10:
/*  307 */             if (this.left.constant != Constant.NotAConstant && 
/*  308 */               this.left.constant.typeID() == 10 && 
/*  309 */               this.left.constant.intValue() == 0) {
/*  310 */               this.right.generateCode(currentScope, codeStream, false);
/*  311 */               if (valueRequired)
/*  312 */                 codeStream.iconst_0(); 
/*      */               break;
/*      */             } 
/*  315 */             if (this.right.constant != Constant.NotAConstant && 
/*  316 */               this.right.constant.typeID() == 10 && 
/*  317 */               this.right.constant.intValue() == 0) {
/*  318 */               this.left.generateCode(currentScope, codeStream, false);
/*  319 */               if (valueRequired)
/*  320 */                 codeStream.iconst_0();  break;
/*      */             } 
/*  322 */             this.left.generateCode(currentScope, codeStream, valueRequired);
/*  323 */             this.right.generateCode(currentScope, codeStream, valueRequired);
/*  324 */             if (valueRequired) {
/*  325 */               codeStream.iand();
/*      */             }
/*      */             break;
/*      */ 
/*      */           
/*      */           case 7:
/*  331 */             if (this.left.constant != Constant.NotAConstant && 
/*  332 */               this.left.constant.typeID() == 7 && 
/*  333 */               this.left.constant.longValue() == 0L) {
/*  334 */               this.right.generateCode(currentScope, codeStream, false);
/*  335 */               if (valueRequired)
/*  336 */                 codeStream.lconst_0(); 
/*      */               break;
/*      */             } 
/*  339 */             if (this.right.constant != Constant.NotAConstant && 
/*  340 */               this.right.constant.typeID() == 7 && 
/*  341 */               this.right.constant.longValue() == 0L) {
/*  342 */               this.left.generateCode(currentScope, codeStream, false);
/*  343 */               if (valueRequired)
/*  344 */                 codeStream.lconst_0();  break;
/*      */             } 
/*  346 */             this.left.generateCode(currentScope, codeStream, valueRequired);
/*  347 */             this.right.generateCode(currentScope, codeStream, valueRequired);
/*  348 */             if (valueRequired) {
/*  349 */               codeStream.land();
/*      */             }
/*      */             break;
/*      */           
/*      */           case 5:
/*  354 */             generateLogicalAnd(currentScope, codeStream, valueRequired);
/*      */             break;
/*      */         } 
/*      */         break;
/*      */       case 3:
/*  359 */         switch (this.bits & 0xF) {
/*      */           
/*      */           case 10:
/*  362 */             if (this.left.constant != Constant.NotAConstant && 
/*  363 */               this.left.constant.typeID() == 10 && 
/*  364 */               this.left.constant.intValue() == 0) {
/*  365 */               this.right.generateCode(currentScope, codeStream, valueRequired);
/*      */               break;
/*      */             } 
/*  368 */             if (this.right.constant != Constant.NotAConstant && 
/*  369 */               this.right.constant.typeID() == 10 && 
/*  370 */               this.right.constant.intValue() == 0) {
/*  371 */               this.left.generateCode(currentScope, codeStream, valueRequired); break;
/*      */             } 
/*  373 */             this.left.generateCode(currentScope, codeStream, valueRequired);
/*  374 */             this.right.generateCode(currentScope, codeStream, valueRequired);
/*  375 */             if (valueRequired) {
/*  376 */               codeStream.ior();
/*      */             }
/*      */             break;
/*      */ 
/*      */           
/*      */           case 7:
/*  382 */             if (this.left.constant != Constant.NotAConstant && 
/*  383 */               this.left.constant.typeID() == 7 && 
/*  384 */               this.left.constant.longValue() == 0L) {
/*  385 */               this.right.generateCode(currentScope, codeStream, valueRequired);
/*      */               break;
/*      */             } 
/*  388 */             if (this.right.constant != Constant.NotAConstant && 
/*  389 */               this.right.constant.typeID() == 7 && 
/*  390 */               this.right.constant.longValue() == 0L) {
/*  391 */               this.left.generateCode(currentScope, codeStream, valueRequired); break;
/*      */             } 
/*  393 */             this.left.generateCode(currentScope, codeStream, valueRequired);
/*  394 */             this.right.generateCode(currentScope, codeStream, valueRequired);
/*  395 */             if (valueRequired) {
/*  396 */               codeStream.lor();
/*      */             }
/*      */             break;
/*      */           
/*      */           case 5:
/*  401 */             generateLogicalOr(currentScope, codeStream, valueRequired);
/*      */             break;
/*      */         } 
/*      */         break;
/*      */       case 8:
/*  406 */         switch (this.bits & 0xF) {
/*      */           
/*      */           case 10:
/*  409 */             if (this.left.constant != Constant.NotAConstant && 
/*  410 */               this.left.constant.typeID() == 10 && 
/*  411 */               this.left.constant.intValue() == 0) {
/*  412 */               this.right.generateCode(currentScope, codeStream, valueRequired);
/*      */               break;
/*      */             } 
/*  415 */             if (this.right.constant != Constant.NotAConstant && 
/*  416 */               this.right.constant.typeID() == 10 && 
/*  417 */               this.right.constant.intValue() == 0) {
/*  418 */               this.left.generateCode(currentScope, codeStream, valueRequired); break;
/*      */             } 
/*  420 */             this.left.generateCode(currentScope, codeStream, valueRequired);
/*  421 */             this.right.generateCode(currentScope, codeStream, valueRequired);
/*  422 */             if (valueRequired) {
/*  423 */               codeStream.ixor();
/*      */             }
/*      */             break;
/*      */ 
/*      */           
/*      */           case 7:
/*  429 */             if (this.left.constant != Constant.NotAConstant && 
/*  430 */               this.left.constant.typeID() == 7 && 
/*  431 */               this.left.constant.longValue() == 0L) {
/*  432 */               this.right.generateCode(currentScope, codeStream, valueRequired);
/*      */               break;
/*      */             } 
/*  435 */             if (this.right.constant != Constant.NotAConstant && 
/*  436 */               this.right.constant.typeID() == 7 && 
/*  437 */               this.right.constant.longValue() == 0L) {
/*  438 */               this.left.generateCode(currentScope, codeStream, valueRequired); break;
/*      */             } 
/*  440 */             this.left.generateCode(currentScope, codeStream, valueRequired);
/*  441 */             this.right.generateCode(currentScope, codeStream, valueRequired);
/*  442 */             if (valueRequired) {
/*  443 */               codeStream.lxor();
/*      */             }
/*      */             break;
/*      */           
/*      */           case 5:
/*  448 */             generateLogicalXor(currentScope, codeStream, valueRequired);
/*      */             break;
/*      */         } 
/*      */         break;
/*      */       case 10:
/*  453 */         switch (this.bits & 0xF) {
/*      */           case 10:
/*  455 */             this.left.generateCode(currentScope, codeStream, valueRequired);
/*  456 */             this.right.generateCode(currentScope, codeStream, valueRequired);
/*  457 */             if (valueRequired)
/*  458 */               codeStream.ishl(); 
/*      */             break;
/*      */           case 7:
/*  461 */             this.left.generateCode(currentScope, codeStream, valueRequired);
/*  462 */             this.right.generateCode(currentScope, codeStream, valueRequired);
/*  463 */             if (valueRequired)
/*  464 */               codeStream.lshl();  break;
/*      */         } 
/*      */         break;
/*      */       case 17:
/*  468 */         switch (this.bits & 0xF) {
/*      */           case 10:
/*  470 */             this.left.generateCode(currentScope, codeStream, valueRequired);
/*  471 */             this.right.generateCode(currentScope, codeStream, valueRequired);
/*  472 */             if (valueRequired)
/*  473 */               codeStream.ishr(); 
/*      */             break;
/*      */           case 7:
/*  476 */             this.left.generateCode(currentScope, codeStream, valueRequired);
/*  477 */             this.right.generateCode(currentScope, codeStream, valueRequired);
/*  478 */             if (valueRequired)
/*  479 */               codeStream.lshr();  break;
/*      */         } 
/*      */         break;
/*      */       case 19:
/*  483 */         switch (this.bits & 0xF) {
/*      */           case 10:
/*  485 */             this.left.generateCode(currentScope, codeStream, valueRequired);
/*  486 */             this.right.generateCode(currentScope, codeStream, valueRequired);
/*  487 */             if (valueRequired)
/*  488 */               codeStream.iushr(); 
/*      */             break;
/*      */           case 7:
/*  491 */             this.left.generateCode(currentScope, codeStream, valueRequired);
/*  492 */             this.right.generateCode(currentScope, codeStream, valueRequired);
/*  493 */             if (valueRequired)
/*  494 */               codeStream.lushr(); 
/*      */             break;
/*      */         } 
/*      */         break;
/*      */       case 6:
/*  499 */         generateOptimizedGreaterThan(
/*  500 */             currentScope, 
/*  501 */             codeStream, 
/*  502 */             (BranchLabel)null, 
/*  503 */             falseLabel = new BranchLabel(codeStream), 
/*  504 */             valueRequired);
/*  505 */         if (valueRequired) {
/*  506 */           codeStream.iconst_1();
/*  507 */           if ((this.bits & 0x10) != 0) {
/*  508 */             codeStream.generateImplicitConversion(this.implicitConversion);
/*  509 */             codeStream.generateReturnBytecode(this);
/*  510 */             falseLabel.place();
/*  511 */             codeStream.iconst_0(); break;
/*      */           }  BranchLabel endLabel;
/*  513 */           codeStream.goto_(endLabel = new BranchLabel(codeStream));
/*  514 */           codeStream.decrStackSize(1);
/*  515 */           falseLabel.place();
/*  516 */           codeStream.iconst_0();
/*  517 */           endLabel.place();
/*      */         } 
/*      */         break;
/*      */       
/*      */       case 7:
/*  522 */         generateOptimizedGreaterThanOrEqual(
/*  523 */             currentScope, 
/*  524 */             codeStream, 
/*  525 */             (BranchLabel)null, 
/*  526 */             falseLabel = new BranchLabel(codeStream), 
/*  527 */             valueRequired);
/*  528 */         if (valueRequired) {
/*  529 */           codeStream.iconst_1();
/*  530 */           if ((this.bits & 0x10) != 0) {
/*  531 */             codeStream.generateImplicitConversion(this.implicitConversion);
/*  532 */             codeStream.generateReturnBytecode(this);
/*  533 */             falseLabel.place();
/*  534 */             codeStream.iconst_0(); break;
/*      */           }  BranchLabel endLabel;
/*  536 */           codeStream.goto_(endLabel = new BranchLabel(codeStream));
/*  537 */           codeStream.decrStackSize(1);
/*  538 */           falseLabel.place();
/*  539 */           codeStream.iconst_0();
/*  540 */           endLabel.place();
/*      */         } 
/*      */         break;
/*      */       
/*      */       case 4:
/*  545 */         generateOptimizedLessThan(
/*  546 */             currentScope, 
/*  547 */             codeStream, 
/*  548 */             (BranchLabel)null, 
/*  549 */             falseLabel = new BranchLabel(codeStream), 
/*  550 */             valueRequired);
/*  551 */         if (valueRequired) {
/*  552 */           codeStream.iconst_1();
/*  553 */           if ((this.bits & 0x10) != 0) {
/*  554 */             codeStream.generateImplicitConversion(this.implicitConversion);
/*  555 */             codeStream.generateReturnBytecode(this);
/*  556 */             falseLabel.place();
/*  557 */             codeStream.iconst_0(); break;
/*      */           }  BranchLabel endLabel;
/*  559 */           codeStream.goto_(endLabel = new BranchLabel(codeStream));
/*  560 */           codeStream.decrStackSize(1);
/*  561 */           falseLabel.place();
/*  562 */           codeStream.iconst_0();
/*  563 */           endLabel.place();
/*      */         } 
/*      */         break;
/*      */       
/*      */       case 5:
/*  568 */         generateOptimizedLessThanOrEqual(
/*  569 */             currentScope, 
/*  570 */             codeStream, 
/*  571 */             (BranchLabel)null, 
/*  572 */             falseLabel = new BranchLabel(codeStream), 
/*  573 */             valueRequired);
/*  574 */         if (valueRequired) {
/*  575 */           codeStream.iconst_1();
/*  576 */           if ((this.bits & 0x10) != 0) {
/*  577 */             codeStream.generateImplicitConversion(this.implicitConversion);
/*  578 */             codeStream.generateReturnBytecode(this);
/*  579 */             falseLabel.place();
/*  580 */             codeStream.iconst_0(); break;
/*      */           }  BranchLabel endLabel;
/*  582 */           codeStream.goto_(endLabel = new BranchLabel(codeStream));
/*  583 */           codeStream.decrStackSize(1);
/*  584 */           falseLabel.place();
/*  585 */           codeStream.iconst_0();
/*  586 */           endLabel.place();
/*      */         } 
/*      */         break;
/*      */     } 
/*  590 */     if (valueRequired) {
/*  591 */       codeStream.generateImplicitConversion(this.implicitConversion);
/*      */     }
/*  593 */     codeStream.recordPositionsFrom(pc, this.sourceStart);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void generateOptimizedBoolean(BlockScope currentScope, CodeStream codeStream, BranchLabel trueLabel, BranchLabel falseLabel, boolean valueRequired) {
/*  602 */     if (this.constant != Constant.NotAConstant && this.constant.typeID() == 5) {
/*  603 */       super.generateOptimizedBoolean(
/*  604 */           currentScope, 
/*  605 */           codeStream, 
/*  606 */           trueLabel, 
/*  607 */           falseLabel, 
/*  608 */           valueRequired);
/*      */       return;
/*      */     } 
/*  611 */     switch ((this.bits & 0x3F00) >> 8) {
/*      */       case 4:
/*  613 */         generateOptimizedLessThan(
/*  614 */             currentScope, 
/*  615 */             codeStream, 
/*  616 */             trueLabel, 
/*  617 */             falseLabel, 
/*  618 */             valueRequired);
/*      */         return;
/*      */       case 5:
/*  621 */         generateOptimizedLessThanOrEqual(
/*  622 */             currentScope, 
/*  623 */             codeStream, 
/*  624 */             trueLabel, 
/*  625 */             falseLabel, 
/*  626 */             valueRequired);
/*      */         return;
/*      */       case 6:
/*  629 */         generateOptimizedGreaterThan(
/*  630 */             currentScope, 
/*  631 */             codeStream, 
/*  632 */             trueLabel, 
/*  633 */             falseLabel, 
/*  634 */             valueRequired);
/*      */         return;
/*      */       case 7:
/*  637 */         generateOptimizedGreaterThanOrEqual(
/*  638 */             currentScope, 
/*  639 */             codeStream, 
/*  640 */             trueLabel, 
/*  641 */             falseLabel, 
/*  642 */             valueRequired);
/*      */         return;
/*      */       case 2:
/*  645 */         generateOptimizedLogicalAnd(
/*  646 */             currentScope, 
/*  647 */             codeStream, 
/*  648 */             trueLabel, 
/*  649 */             falseLabel, 
/*  650 */             valueRequired);
/*      */         return;
/*      */       case 3:
/*  653 */         generateOptimizedLogicalOr(
/*  654 */             currentScope, 
/*  655 */             codeStream, 
/*  656 */             trueLabel, 
/*  657 */             falseLabel, 
/*  658 */             valueRequired);
/*      */         return;
/*      */       case 8:
/*  661 */         generateOptimizedLogicalXor(
/*  662 */             currentScope, 
/*  663 */             codeStream, 
/*  664 */             trueLabel, 
/*  665 */             falseLabel, 
/*  666 */             valueRequired);
/*      */         return;
/*      */     } 
/*  669 */     super.generateOptimizedBoolean(
/*  670 */         currentScope, 
/*  671 */         codeStream, 
/*  672 */         trueLabel, 
/*  673 */         falseLabel, 
/*  674 */         valueRequired);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void generateOptimizedGreaterThan(BlockScope currentScope, CodeStream codeStream, BranchLabel trueLabel, BranchLabel falseLabel, boolean valueRequired) {
/*  681 */     int promotedTypeID = (this.left.implicitConversion & 0xFF) >> 4;
/*      */     
/*  683 */     if (promotedTypeID == 10) {
/*      */       
/*  685 */       if (this.left.constant != Constant.NotAConstant && this.left.constant.intValue() == 0) {
/*  686 */         this.right.generateCode(currentScope, codeStream, valueRequired);
/*  687 */         if (valueRequired) {
/*  688 */           if (falseLabel == null) {
/*  689 */             if (trueLabel != null)
/*      */             {
/*  691 */               codeStream.iflt(trueLabel);
/*      */             }
/*      */           }
/*  694 */           else if (trueLabel == null) {
/*      */             
/*  696 */             codeStream.ifge(falseLabel);
/*      */           } 
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  703 */         codeStream.recordPositionsFrom(codeStream.position, this.sourceEnd);
/*      */         
/*      */         return;
/*      */       } 
/*  707 */       if (this.right.constant != Constant.NotAConstant && this.right.constant.intValue() == 0) {
/*  708 */         this.left.generateCode(currentScope, codeStream, valueRequired);
/*  709 */         if (valueRequired) {
/*  710 */           if (falseLabel == null) {
/*  711 */             if (trueLabel != null)
/*      */             {
/*  713 */               codeStream.ifgt(trueLabel);
/*      */             }
/*      */           }
/*  716 */           else if (trueLabel == null) {
/*      */             
/*  718 */             codeStream.ifle(falseLabel);
/*      */           } 
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  725 */         codeStream.recordPositionsFrom(codeStream.position, this.sourceEnd);
/*      */         
/*      */         return;
/*      */       } 
/*      */     } 
/*  730 */     this.left.generateCode(currentScope, codeStream, valueRequired);
/*  731 */     this.right.generateCode(currentScope, codeStream, valueRequired);
/*  732 */     if (valueRequired) {
/*  733 */       if (falseLabel == null) {
/*  734 */         if (trueLabel != null) {
/*      */           
/*  736 */           switch (promotedTypeID) {
/*      */             case 10:
/*  738 */               codeStream.if_icmpgt(trueLabel);
/*      */               break;
/*      */             case 9:
/*  741 */               codeStream.fcmpl();
/*  742 */               codeStream.ifgt(trueLabel);
/*      */               break;
/*      */             case 7:
/*  745 */               codeStream.lcmp();
/*  746 */               codeStream.ifgt(trueLabel);
/*      */               break;
/*      */             case 8:
/*  749 */               codeStream.dcmpl();
/*  750 */               codeStream.ifgt(trueLabel);
/*      */               break;
/*      */           } 
/*  753 */           codeStream.recordPositionsFrom(codeStream.position, this.sourceEnd);
/*      */           
/*      */           return;
/*      */         } 
/*  757 */       } else if (trueLabel == null) {
/*      */         
/*  759 */         switch (promotedTypeID) {
/*      */           case 10:
/*  761 */             codeStream.if_icmple(falseLabel);
/*      */             break;
/*      */           case 9:
/*  764 */             codeStream.fcmpl();
/*  765 */             codeStream.ifle(falseLabel);
/*      */             break;
/*      */           case 7:
/*  768 */             codeStream.lcmp();
/*  769 */             codeStream.ifle(falseLabel);
/*      */             break;
/*      */           case 8:
/*  772 */             codeStream.dcmpl();
/*  773 */             codeStream.ifle(falseLabel);
/*      */             break;
/*      */         } 
/*  776 */         codeStream.recordPositionsFrom(codeStream.position, this.sourceEnd);
/*      */         return;
/*      */       } 
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void generateOptimizedGreaterThanOrEqual(BlockScope currentScope, CodeStream codeStream, BranchLabel trueLabel, BranchLabel falseLabel, boolean valueRequired) {
/*  789 */     int promotedTypeID = (this.left.implicitConversion & 0xFF) >> 4;
/*      */     
/*  791 */     if (promotedTypeID == 10) {
/*      */       
/*  793 */       if (this.left.constant != Constant.NotAConstant && this.left.constant.intValue() == 0) {
/*  794 */         this.right.generateCode(currentScope, codeStream, valueRequired);
/*  795 */         if (valueRequired) {
/*  796 */           if (falseLabel == null) {
/*  797 */             if (trueLabel != null)
/*      */             {
/*  799 */               codeStream.ifle(trueLabel);
/*      */             }
/*      */           }
/*  802 */           else if (trueLabel == null) {
/*      */             
/*  804 */             codeStream.ifgt(falseLabel);
/*      */           } 
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  811 */         codeStream.recordPositionsFrom(codeStream.position, this.sourceEnd);
/*      */         
/*      */         return;
/*      */       } 
/*  815 */       if (this.right.constant != Constant.NotAConstant && this.right.constant.intValue() == 0) {
/*  816 */         this.left.generateCode(currentScope, codeStream, valueRequired);
/*  817 */         if (valueRequired) {
/*  818 */           if (falseLabel == null) {
/*  819 */             if (trueLabel != null)
/*      */             {
/*  821 */               codeStream.ifge(trueLabel);
/*      */             }
/*      */           }
/*  824 */           else if (trueLabel == null) {
/*      */             
/*  826 */             codeStream.iflt(falseLabel);
/*      */           } 
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  833 */         codeStream.recordPositionsFrom(codeStream.position, this.sourceEnd);
/*      */         
/*      */         return;
/*      */       } 
/*      */     } 
/*  838 */     this.left.generateCode(currentScope, codeStream, valueRequired);
/*  839 */     this.right.generateCode(currentScope, codeStream, valueRequired);
/*  840 */     if (valueRequired) {
/*  841 */       if (falseLabel == null) {
/*  842 */         if (trueLabel != null) {
/*      */           
/*  844 */           switch (promotedTypeID) {
/*      */             case 10:
/*  846 */               codeStream.if_icmpge(trueLabel);
/*      */               break;
/*      */             case 9:
/*  849 */               codeStream.fcmpl();
/*  850 */               codeStream.ifge(trueLabel);
/*      */               break;
/*      */             case 7:
/*  853 */               codeStream.lcmp();
/*  854 */               codeStream.ifge(trueLabel);
/*      */               break;
/*      */             case 8:
/*  857 */               codeStream.dcmpl();
/*  858 */               codeStream.ifge(trueLabel);
/*      */               break;
/*      */           } 
/*  861 */           codeStream.recordPositionsFrom(codeStream.position, this.sourceEnd);
/*      */           
/*      */           return;
/*      */         } 
/*  865 */       } else if (trueLabel == null) {
/*      */         
/*  867 */         switch (promotedTypeID) {
/*      */           case 10:
/*  869 */             codeStream.if_icmplt(falseLabel);
/*      */             break;
/*      */           case 9:
/*  872 */             codeStream.fcmpl();
/*  873 */             codeStream.iflt(falseLabel);
/*      */             break;
/*      */           case 7:
/*  876 */             codeStream.lcmp();
/*  877 */             codeStream.iflt(falseLabel);
/*      */             break;
/*      */           case 8:
/*  880 */             codeStream.dcmpl();
/*  881 */             codeStream.iflt(falseLabel);
/*      */             break;
/*      */         } 
/*  884 */         codeStream.recordPositionsFrom(codeStream.position, this.sourceEnd);
/*      */         return;
/*      */       } 
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void generateOptimizedLessThan(BlockScope currentScope, CodeStream codeStream, BranchLabel trueLabel, BranchLabel falseLabel, boolean valueRequired) {
/*  897 */     int promotedTypeID = (this.left.implicitConversion & 0xFF) >> 4;
/*      */     
/*  899 */     if (promotedTypeID == 10) {
/*      */       
/*  901 */       if (this.left.constant != Constant.NotAConstant && this.left.constant.intValue() == 0) {
/*  902 */         this.right.generateCode(currentScope, codeStream, valueRequired);
/*  903 */         if (valueRequired) {
/*  904 */           if (falseLabel == null) {
/*  905 */             if (trueLabel != null)
/*      */             {
/*  907 */               codeStream.ifgt(trueLabel);
/*      */             }
/*      */           }
/*  910 */           else if (trueLabel == null) {
/*      */             
/*  912 */             codeStream.ifle(falseLabel);
/*      */           } 
/*      */         }
/*      */ 
/*      */ 
/*      */         
/*  918 */         codeStream.recordPositionsFrom(codeStream.position, this.sourceEnd);
/*      */         
/*      */         return;
/*      */       } 
/*  922 */       if (this.right.constant != Constant.NotAConstant && this.right.constant.intValue() == 0) {
/*  923 */         this.left.generateCode(currentScope, codeStream, valueRequired);
/*  924 */         if (valueRequired) {
/*  925 */           if (falseLabel == null) {
/*  926 */             if (trueLabel != null)
/*      */             {
/*  928 */               codeStream.iflt(trueLabel);
/*      */             }
/*      */           }
/*  931 */           else if (trueLabel == null) {
/*      */             
/*  933 */             codeStream.ifge(falseLabel);
/*      */           } 
/*      */         }
/*      */ 
/*      */ 
/*      */         
/*  939 */         codeStream.recordPositionsFrom(codeStream.position, this.sourceEnd);
/*      */         
/*      */         return;
/*      */       } 
/*      */     } 
/*  944 */     this.left.generateCode(currentScope, codeStream, valueRequired);
/*  945 */     this.right.generateCode(currentScope, codeStream, valueRequired);
/*  946 */     if (valueRequired) {
/*  947 */       if (falseLabel == null) {
/*  948 */         if (trueLabel != null) {
/*      */           
/*  950 */           switch (promotedTypeID) {
/*      */             case 10:
/*  952 */               codeStream.if_icmplt(trueLabel);
/*      */               break;
/*      */             case 9:
/*  955 */               codeStream.fcmpg();
/*  956 */               codeStream.iflt(trueLabel);
/*      */               break;
/*      */             case 7:
/*  959 */               codeStream.lcmp();
/*  960 */               codeStream.iflt(trueLabel);
/*      */               break;
/*      */             case 8:
/*  963 */               codeStream.dcmpg();
/*  964 */               codeStream.iflt(trueLabel); break;
/*      */           } 
/*  966 */           codeStream.recordPositionsFrom(codeStream.position, this.sourceEnd);
/*      */           
/*      */           return;
/*      */         } 
/*  970 */       } else if (trueLabel == null) {
/*      */         
/*  972 */         switch (promotedTypeID) {
/*      */           case 10:
/*  974 */             codeStream.if_icmpge(falseLabel);
/*      */             break;
/*      */           case 9:
/*  977 */             codeStream.fcmpg();
/*  978 */             codeStream.ifge(falseLabel);
/*      */             break;
/*      */           case 7:
/*  981 */             codeStream.lcmp();
/*  982 */             codeStream.ifge(falseLabel);
/*      */             break;
/*      */           case 8:
/*  985 */             codeStream.dcmpg();
/*  986 */             codeStream.ifge(falseLabel); break;
/*      */         } 
/*  988 */         codeStream.recordPositionsFrom(codeStream.position, this.sourceEnd);
/*      */         return;
/*      */       } 
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void generateOptimizedLessThanOrEqual(BlockScope currentScope, CodeStream codeStream, BranchLabel trueLabel, BranchLabel falseLabel, boolean valueRequired) {
/* 1001 */     int promotedTypeID = (this.left.implicitConversion & 0xFF) >> 4;
/*      */     
/* 1003 */     if (promotedTypeID == 10) {
/*      */       
/* 1005 */       if (this.left.constant != Constant.NotAConstant && this.left.constant.intValue() == 0) {
/* 1006 */         this.right.generateCode(currentScope, codeStream, valueRequired);
/* 1007 */         if (valueRequired) {
/* 1008 */           if (falseLabel == null) {
/* 1009 */             if (trueLabel != null)
/*      */             {
/* 1011 */               codeStream.ifge(trueLabel);
/*      */             }
/*      */           }
/* 1014 */           else if (trueLabel == null) {
/*      */             
/* 1016 */             codeStream.iflt(falseLabel);
/*      */           } 
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1023 */         codeStream.recordPositionsFrom(codeStream.position, this.sourceEnd);
/*      */         
/*      */         return;
/*      */       } 
/* 1027 */       if (this.right.constant != Constant.NotAConstant && this.right.constant.intValue() == 0) {
/* 1028 */         this.left.generateCode(currentScope, codeStream, valueRequired);
/* 1029 */         if (valueRequired) {
/* 1030 */           if (falseLabel == null) {
/* 1031 */             if (trueLabel != null)
/*      */             {
/* 1033 */               codeStream.ifle(trueLabel);
/*      */             }
/*      */           }
/* 1036 */           else if (trueLabel == null) {
/*      */             
/* 1038 */             codeStream.ifgt(falseLabel);
/*      */           } 
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1045 */         codeStream.recordPositionsFrom(codeStream.position, this.sourceEnd);
/*      */         
/*      */         return;
/*      */       } 
/*      */     } 
/* 1050 */     this.left.generateCode(currentScope, codeStream, valueRequired);
/* 1051 */     this.right.generateCode(currentScope, codeStream, valueRequired);
/* 1052 */     if (valueRequired) {
/* 1053 */       if (falseLabel == null) {
/* 1054 */         if (trueLabel != null) {
/*      */           
/* 1056 */           switch (promotedTypeID) {
/*      */             case 10:
/* 1058 */               codeStream.if_icmple(trueLabel);
/*      */               break;
/*      */             case 9:
/* 1061 */               codeStream.fcmpg();
/* 1062 */               codeStream.ifle(trueLabel);
/*      */               break;
/*      */             case 7:
/* 1065 */               codeStream.lcmp();
/* 1066 */               codeStream.ifle(trueLabel);
/*      */               break;
/*      */             case 8:
/* 1069 */               codeStream.dcmpg();
/* 1070 */               codeStream.ifle(trueLabel);
/*      */               break;
/*      */           } 
/* 1073 */           codeStream.recordPositionsFrom(codeStream.position, this.sourceEnd);
/*      */           
/*      */           return;
/*      */         } 
/* 1077 */       } else if (trueLabel == null) {
/*      */         
/* 1079 */         switch (promotedTypeID) {
/*      */           case 10:
/* 1081 */             codeStream.if_icmpgt(falseLabel);
/*      */             break;
/*      */           case 9:
/* 1084 */             codeStream.fcmpg();
/* 1085 */             codeStream.ifgt(falseLabel);
/*      */             break;
/*      */           case 7:
/* 1088 */             codeStream.lcmp();
/* 1089 */             codeStream.ifgt(falseLabel);
/*      */             break;
/*      */           case 8:
/* 1092 */             codeStream.dcmpg();
/* 1093 */             codeStream.ifgt(falseLabel);
/*      */             break;
/*      */         } 
/* 1096 */         codeStream.recordPositionsFrom(codeStream.position, this.sourceEnd);
/*      */         return;
/*      */       } 
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void generateLogicalAnd(BlockScope currentScope, CodeStream codeStream, boolean valueRequired) {
/* 1110 */     if ((this.left.implicitConversion & 0xF) == 5) {
/* 1111 */       Constant condConst; if ((condConst = this.left.optimizedBooleanConstant()) != Constant.NotAConstant) {
/* 1112 */         if (condConst.booleanValue()) {
/*      */           
/* 1114 */           this.left.generateCode(currentScope, codeStream, false);
/* 1115 */           this.right.generateCode(currentScope, codeStream, valueRequired);
/*      */         } else {
/*      */           
/* 1118 */           this.left.generateCode(currentScope, codeStream, false);
/* 1119 */           this.right.generateCode(currentScope, codeStream, false);
/* 1120 */           if (valueRequired) {
/* 1121 */             codeStream.iconst_0();
/*      */           }
/*      */           
/* 1124 */           codeStream.recordPositionsFrom(codeStream.position, this.sourceEnd);
/*      */         } 
/*      */         return;
/*      */       } 
/* 1128 */       if ((condConst = this.right.optimizedBooleanConstant()) != Constant.NotAConstant) {
/* 1129 */         if (condConst.booleanValue()) {
/*      */           
/* 1131 */           this.left.generateCode(currentScope, codeStream, valueRequired);
/* 1132 */           this.right.generateCode(currentScope, codeStream, false);
/*      */         } else {
/*      */           
/* 1135 */           this.left.generateCode(currentScope, codeStream, false);
/* 1136 */           this.right.generateCode(currentScope, codeStream, false);
/* 1137 */           if (valueRequired) {
/* 1138 */             codeStream.iconst_0();
/*      */           }
/*      */           
/* 1141 */           codeStream.recordPositionsFrom(codeStream.position, this.sourceEnd);
/*      */         } 
/*      */         
/*      */         return;
/*      */       } 
/*      */     } 
/* 1147 */     this.left.generateCode(currentScope, codeStream, valueRequired);
/* 1148 */     this.right.generateCode(currentScope, codeStream, valueRequired);
/* 1149 */     if (valueRequired) {
/* 1150 */       codeStream.iand();
/*      */     }
/* 1152 */     codeStream.recordPositionsFrom(codeStream.position, this.sourceEnd);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void generateLogicalOr(BlockScope currentScope, CodeStream codeStream, boolean valueRequired) {
/* 1160 */     if ((this.left.implicitConversion & 0xF) == 5) {
/* 1161 */       Constant condConst; if ((condConst = this.left.optimizedBooleanConstant()) != Constant.NotAConstant) {
/* 1162 */         if (condConst.booleanValue()) {
/*      */           
/* 1164 */           this.left.generateCode(currentScope, codeStream, false);
/* 1165 */           this.right.generateCode(currentScope, codeStream, false);
/* 1166 */           if (valueRequired) {
/* 1167 */             codeStream.iconst_1();
/*      */           }
/* 1169 */           codeStream.recordPositionsFrom(codeStream.position, this.sourceEnd);
/*      */         } else {
/*      */           
/* 1172 */           this.left.generateCode(currentScope, codeStream, false);
/* 1173 */           this.right.generateCode(currentScope, codeStream, valueRequired);
/*      */         } 
/*      */         return;
/*      */       } 
/* 1177 */       if ((condConst = this.right.optimizedBooleanConstant()) != Constant.NotAConstant) {
/* 1178 */         if (condConst.booleanValue()) {
/*      */           
/* 1180 */           this.left.generateCode(currentScope, codeStream, false);
/* 1181 */           this.right.generateCode(currentScope, codeStream, false);
/* 1182 */           if (valueRequired) {
/* 1183 */             codeStream.iconst_1();
/*      */           }
/* 1185 */           codeStream.recordPositionsFrom(codeStream.position, this.sourceEnd);
/*      */         } else {
/*      */           
/* 1188 */           this.left.generateCode(currentScope, codeStream, valueRequired);
/* 1189 */           this.right.generateCode(currentScope, codeStream, false);
/*      */         } 
/*      */         
/*      */         return;
/*      */       } 
/*      */     } 
/* 1195 */     this.left.generateCode(currentScope, codeStream, valueRequired);
/* 1196 */     this.right.generateCode(currentScope, codeStream, valueRequired);
/* 1197 */     if (valueRequired) {
/* 1198 */       codeStream.ior();
/*      */     }
/* 1200 */     codeStream.recordPositionsFrom(codeStream.position, this.sourceEnd);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void generateLogicalXor(BlockScope currentScope, CodeStream codeStream, boolean valueRequired) {
/* 1208 */     if ((this.left.implicitConversion & 0xF) == 5) {
/* 1209 */       Constant condConst; if ((condConst = this.left.optimizedBooleanConstant()) != Constant.NotAConstant) {
/* 1210 */         if (condConst.booleanValue()) {
/*      */           
/* 1212 */           this.left.generateCode(currentScope, codeStream, false);
/* 1213 */           if (valueRequired) {
/* 1214 */             codeStream.iconst_1();
/*      */           }
/* 1216 */           this.right.generateCode(currentScope, codeStream, valueRequired);
/* 1217 */           if (valueRequired) {
/* 1218 */             codeStream.ixor();
/* 1219 */             codeStream.recordPositionsFrom(codeStream.position, this.sourceEnd);
/*      */           } 
/*      */         } else {
/*      */           
/* 1223 */           this.left.generateCode(currentScope, codeStream, false);
/* 1224 */           this.right.generateCode(currentScope, codeStream, valueRequired);
/*      */         } 
/*      */         return;
/*      */       } 
/* 1228 */       if ((condConst = this.right.optimizedBooleanConstant()) != Constant.NotAConstant) {
/* 1229 */         if (condConst.booleanValue()) {
/*      */           
/* 1231 */           this.left.generateCode(currentScope, codeStream, valueRequired);
/* 1232 */           this.right.generateCode(currentScope, codeStream, false);
/* 1233 */           if (valueRequired) {
/* 1234 */             codeStream.iconst_1();
/* 1235 */             codeStream.ixor();
/* 1236 */             codeStream.recordPositionsFrom(codeStream.position, this.sourceEnd);
/*      */           } 
/*      */         } else {
/*      */           
/* 1240 */           this.left.generateCode(currentScope, codeStream, valueRequired);
/* 1241 */           this.right.generateCode(currentScope, codeStream, false);
/*      */         } 
/*      */         
/*      */         return;
/*      */       } 
/*      */     } 
/* 1247 */     this.left.generateCode(currentScope, codeStream, valueRequired);
/* 1248 */     this.right.generateCode(currentScope, codeStream, valueRequired);
/* 1249 */     if (valueRequired) {
/* 1250 */       codeStream.ixor();
/*      */     }
/* 1252 */     codeStream.recordPositionsFrom(codeStream.position, this.sourceEnd);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void generateOptimizedLogicalAnd(BlockScope currentScope, CodeStream codeStream, BranchLabel trueLabel, BranchLabel falseLabel, boolean valueRequired) {
/* 1260 */     if ((this.left.implicitConversion & 0xF) == 5) {
/* 1261 */       Constant condConst; if ((condConst = this.left.optimizedBooleanConstant()) != Constant.NotAConstant) {
/* 1262 */         if (condConst.booleanValue()) {
/*      */           
/* 1264 */           this.left.generateOptimizedBoolean(
/* 1265 */               currentScope, 
/* 1266 */               codeStream, 
/* 1267 */               trueLabel, 
/* 1268 */               falseLabel, 
/* 1269 */               false);
/* 1270 */           this.right.generateOptimizedBoolean(
/* 1271 */               currentScope, 
/* 1272 */               codeStream, 
/* 1273 */               trueLabel, 
/* 1274 */               falseLabel, 
/* 1275 */               valueRequired);
/*      */         } else {
/*      */           
/* 1278 */           this.left.generateOptimizedBoolean(
/* 1279 */               currentScope, 
/* 1280 */               codeStream, 
/* 1281 */               trueLabel, 
/* 1282 */               falseLabel, 
/* 1283 */               false);
/* 1284 */           this.right.generateOptimizedBoolean(
/* 1285 */               currentScope, 
/* 1286 */               codeStream, 
/* 1287 */               trueLabel, 
/* 1288 */               falseLabel, 
/* 1289 */               false);
/* 1290 */           if (valueRequired && 
/* 1291 */             falseLabel != null)
/*      */           {
/* 1293 */             codeStream.goto_(falseLabel);
/*      */           }
/*      */           
/* 1296 */           codeStream.recordPositionsFrom(codeStream.position, this.sourceEnd);
/*      */         } 
/*      */         return;
/*      */       } 
/* 1300 */       if ((condConst = this.right.optimizedBooleanConstant()) != Constant.NotAConstant) {
/* 1301 */         if (condConst.booleanValue()) {
/*      */           
/* 1303 */           this.left.generateOptimizedBoolean(
/* 1304 */               currentScope, 
/* 1305 */               codeStream, 
/* 1306 */               trueLabel, 
/* 1307 */               falseLabel, 
/* 1308 */               valueRequired);
/* 1309 */           this.right.generateOptimizedBoolean(
/* 1310 */               currentScope, 
/* 1311 */               codeStream, 
/* 1312 */               trueLabel, 
/* 1313 */               falseLabel, 
/* 1314 */               false);
/*      */         } else {
/*      */           
/* 1317 */           BranchLabel internalTrueLabel = new BranchLabel(codeStream);
/* 1318 */           this.left.generateOptimizedBoolean(
/* 1319 */               currentScope, 
/* 1320 */               codeStream, 
/* 1321 */               internalTrueLabel, 
/* 1322 */               falseLabel, 
/* 1323 */               false);
/* 1324 */           internalTrueLabel.place();
/* 1325 */           this.right.generateOptimizedBoolean(
/* 1326 */               currentScope, 
/* 1327 */               codeStream, 
/* 1328 */               trueLabel, 
/* 1329 */               falseLabel, 
/* 1330 */               false);
/* 1331 */           if (valueRequired && 
/* 1332 */             falseLabel != null)
/*      */           {
/* 1334 */             codeStream.goto_(falseLabel);
/*      */           }
/*      */           
/* 1337 */           codeStream.recordPositionsFrom(codeStream.position, this.sourceEnd);
/*      */         } 
/*      */         
/*      */         return;
/*      */       } 
/*      */     } 
/* 1343 */     this.left.generateCode(currentScope, codeStream, valueRequired);
/* 1344 */     this.right.generateCode(currentScope, codeStream, valueRequired);
/* 1345 */     if (valueRequired) {
/* 1346 */       codeStream.iand();
/* 1347 */       if (falseLabel == null) {
/* 1348 */         if (trueLabel != null)
/*      */         {
/* 1350 */           codeStream.ifne(trueLabel);
/*      */         
/*      */         }
/*      */       }
/* 1354 */       else if (trueLabel == null) {
/* 1355 */         codeStream.ifeq(falseLabel);
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 1361 */     codeStream.recordPositionsFrom(codeStream.position, this.sourceEnd);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void generateOptimizedLogicalOr(BlockScope currentScope, CodeStream codeStream, BranchLabel trueLabel, BranchLabel falseLabel, boolean valueRequired) {
/* 1369 */     if ((this.left.implicitConversion & 0xF) == 5) {
/* 1370 */       Constant condConst; if ((condConst = this.left.optimizedBooleanConstant()) != Constant.NotAConstant) {
/* 1371 */         if (condConst.booleanValue()) {
/*      */           
/* 1373 */           this.left.generateOptimizedBoolean(
/* 1374 */               currentScope, 
/* 1375 */               codeStream, 
/* 1376 */               trueLabel, 
/* 1377 */               falseLabel, 
/* 1378 */               false);
/* 1379 */           BranchLabel internalFalseLabel = new BranchLabel(codeStream);
/* 1380 */           this.right.generateOptimizedBoolean(
/* 1381 */               currentScope, 
/* 1382 */               codeStream, 
/* 1383 */               trueLabel, 
/* 1384 */               internalFalseLabel, 
/* 1385 */               false);
/* 1386 */           internalFalseLabel.place();
/* 1387 */           if (valueRequired && 
/* 1388 */             trueLabel != null) {
/* 1389 */             codeStream.goto_(trueLabel);
/*      */           }
/*      */           
/* 1392 */           codeStream.recordPositionsFrom(codeStream.position, this.sourceEnd);
/*      */         } else {
/*      */           
/* 1395 */           this.left.generateOptimizedBoolean(
/* 1396 */               currentScope, 
/* 1397 */               codeStream, 
/* 1398 */               trueLabel, 
/* 1399 */               falseLabel, 
/* 1400 */               false);
/* 1401 */           this.right.generateOptimizedBoolean(
/* 1402 */               currentScope, 
/* 1403 */               codeStream, 
/* 1404 */               trueLabel, 
/* 1405 */               falseLabel, 
/* 1406 */               valueRequired);
/*      */         } 
/*      */         return;
/*      */       } 
/* 1410 */       if ((condConst = this.right.optimizedBooleanConstant()) != Constant.NotAConstant) {
/* 1411 */         if (condConst.booleanValue()) {
/*      */           
/* 1413 */           BranchLabel internalFalseLabel = new BranchLabel(codeStream);
/* 1414 */           this.left.generateOptimizedBoolean(
/* 1415 */               currentScope, 
/* 1416 */               codeStream, 
/* 1417 */               trueLabel, 
/* 1418 */               internalFalseLabel, 
/* 1419 */               false);
/* 1420 */           internalFalseLabel.place();
/* 1421 */           this.right.generateOptimizedBoolean(
/* 1422 */               currentScope, 
/* 1423 */               codeStream, 
/* 1424 */               trueLabel, 
/* 1425 */               falseLabel, 
/* 1426 */               false);
/* 1427 */           if (valueRequired && 
/* 1428 */             trueLabel != null) {
/* 1429 */             codeStream.goto_(trueLabel);
/*      */           }
/*      */           
/* 1432 */           codeStream.recordPositionsFrom(codeStream.position, this.sourceEnd);
/*      */         } else {
/*      */           
/* 1435 */           this.left.generateOptimizedBoolean(
/* 1436 */               currentScope, 
/* 1437 */               codeStream, 
/* 1438 */               trueLabel, 
/* 1439 */               falseLabel, 
/* 1440 */               valueRequired);
/* 1441 */           this.right.generateOptimizedBoolean(
/* 1442 */               currentScope, 
/* 1443 */               codeStream, 
/* 1444 */               trueLabel, 
/* 1445 */               falseLabel, 
/* 1446 */               false);
/*      */         } 
/*      */         
/*      */         return;
/*      */       } 
/*      */     } 
/* 1452 */     this.left.generateCode(currentScope, codeStream, valueRequired);
/* 1453 */     this.right.generateCode(currentScope, codeStream, valueRequired);
/* 1454 */     if (valueRequired) {
/* 1455 */       codeStream.ior();
/* 1456 */       if (falseLabel == null) {
/* 1457 */         if (trueLabel != null)
/*      */         {
/* 1459 */           codeStream.ifne(trueLabel);
/*      */         
/*      */         }
/*      */       }
/* 1463 */       else if (trueLabel == null) {
/* 1464 */         codeStream.ifeq(falseLabel);
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 1470 */     codeStream.recordPositionsFrom(codeStream.position, this.sourceEnd);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void generateOptimizedLogicalXor(BlockScope currentScope, CodeStream codeStream, BranchLabel trueLabel, BranchLabel falseLabel, boolean valueRequired) {
/* 1478 */     if ((this.left.implicitConversion & 0xF) == 5) {
/* 1479 */       Constant condConst; if ((condConst = this.left.optimizedBooleanConstant()) != Constant.NotAConstant) {
/* 1480 */         if (condConst.booleanValue()) {
/*      */           
/* 1482 */           this.left.generateOptimizedBoolean(
/* 1483 */               currentScope, 
/* 1484 */               codeStream, 
/* 1485 */               trueLabel, 
/* 1486 */               falseLabel, 
/* 1487 */               false);
/* 1488 */           this.right.generateOptimizedBoolean(
/* 1489 */               currentScope, 
/* 1490 */               codeStream, 
/* 1491 */               falseLabel, 
/* 1492 */               trueLabel, 
/* 1493 */               valueRequired);
/*      */         } else {
/*      */           
/* 1496 */           this.left.generateOptimizedBoolean(
/* 1497 */               currentScope, 
/* 1498 */               codeStream, 
/* 1499 */               trueLabel, 
/* 1500 */               falseLabel, 
/* 1501 */               false);
/* 1502 */           this.right.generateOptimizedBoolean(
/* 1503 */               currentScope, 
/* 1504 */               codeStream, 
/* 1505 */               trueLabel, 
/* 1506 */               falseLabel, 
/* 1507 */               valueRequired);
/*      */         } 
/*      */         return;
/*      */       } 
/* 1511 */       if ((condConst = this.right.optimizedBooleanConstant()) != Constant.NotAConstant) {
/* 1512 */         if (condConst.booleanValue()) {
/*      */           
/* 1514 */           this.left.generateOptimizedBoolean(
/* 1515 */               currentScope, 
/* 1516 */               codeStream, 
/* 1517 */               falseLabel, 
/* 1518 */               trueLabel, 
/* 1519 */               valueRequired);
/* 1520 */           this.right.generateOptimizedBoolean(
/* 1521 */               currentScope, 
/* 1522 */               codeStream, 
/* 1523 */               trueLabel, 
/* 1524 */               falseLabel, 
/* 1525 */               false);
/*      */         } else {
/*      */           
/* 1528 */           this.left.generateOptimizedBoolean(
/* 1529 */               currentScope, 
/* 1530 */               codeStream, 
/* 1531 */               trueLabel, 
/* 1532 */               falseLabel, 
/* 1533 */               valueRequired);
/* 1534 */           this.right.generateOptimizedBoolean(
/* 1535 */               currentScope, 
/* 1536 */               codeStream, 
/* 1537 */               trueLabel, 
/* 1538 */               falseLabel, 
/* 1539 */               false);
/*      */         } 
/*      */         
/*      */         return;
/*      */       } 
/*      */     } 
/* 1545 */     this.left.generateCode(currentScope, codeStream, valueRequired);
/* 1546 */     this.right.generateCode(currentScope, codeStream, valueRequired);
/* 1547 */     if (valueRequired) {
/* 1548 */       codeStream.ixor();
/* 1549 */       if (falseLabel == null) {
/* 1550 */         if (trueLabel != null)
/*      */         {
/* 1552 */           codeStream.ifne(trueLabel);
/*      */         
/*      */         }
/*      */       }
/* 1556 */       else if (trueLabel == null) {
/* 1557 */         codeStream.ifeq(falseLabel);
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 1563 */     codeStream.recordPositionsFrom(codeStream.position, this.sourceEnd);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void generateOptimizedStringConcatenation(BlockScope blockScope, CodeStream codeStream, int typeID) {
/* 1575 */     if ((this.bits & 0x3F00) >> 8 == 14 && (
/* 1576 */       this.bits & 0xF) == 11) {
/* 1577 */       if (this.constant != Constant.NotAConstant) {
/* 1578 */         codeStream.generateConstant(this.constant, this.implicitConversion);
/* 1579 */         codeStream.invokeStringConcatenationAppendForType(this.implicitConversion & 0xF);
/*      */       } else {
/* 1581 */         int pc = codeStream.position;
/* 1582 */         this.left.generateOptimizedStringConcatenation(
/* 1583 */             blockScope, 
/* 1584 */             codeStream, 
/* 1585 */             this.left.implicitConversion & 0xF);
/* 1586 */         codeStream.recordPositionsFrom(pc, this.left.sourceStart);
/* 1587 */         pc = codeStream.position;
/* 1588 */         this.right.generateOptimizedStringConcatenation(
/* 1589 */             blockScope, 
/* 1590 */             codeStream, 
/* 1591 */             this.right.implicitConversion & 0xF);
/* 1592 */         codeStream.recordPositionsFrom(pc, this.right.sourceStart);
/*      */       } 
/*      */     } else {
/* 1595 */       super.generateOptimizedStringConcatenation(blockScope, codeStream, typeID);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void generateOptimizedStringConcatenationCreation(BlockScope blockScope, CodeStream codeStream, int typeID) {
/* 1607 */     if ((this.bits & 0x3F00) >> 8 == 14 && (
/* 1608 */       this.bits & 0xF) == 11) {
/* 1609 */       if (this.constant != Constant.NotAConstant) {
/* 1610 */         codeStream.newStringContatenation();
/* 1611 */         codeStream.dup();
/* 1612 */         codeStream.ldc(this.constant.stringValue());
/* 1613 */         codeStream.invokeStringConcatenationStringConstructor();
/*      */       } else {
/*      */         
/* 1616 */         int pc = codeStream.position;
/* 1617 */         this.left.generateOptimizedStringConcatenationCreation(
/* 1618 */             blockScope, 
/* 1619 */             codeStream, 
/* 1620 */             this.left.implicitConversion & 0xF);
/* 1621 */         codeStream.recordPositionsFrom(pc, this.left.sourceStart);
/* 1622 */         pc = codeStream.position;
/* 1623 */         this.right.generateOptimizedStringConcatenation(
/* 1624 */             blockScope, 
/* 1625 */             codeStream, 
/* 1626 */             this.right.implicitConversion & 0xF);
/* 1627 */         codeStream.recordPositionsFrom(pc, this.right.sourceStart);
/*      */       } 
/*      */     } else {
/* 1630 */       super.generateOptimizedStringConcatenationCreation(blockScope, codeStream, typeID);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isCompactableOperation() {
/* 1636 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void nonRecursiveResolveTypeUpwards(BlockScope scope) {
/* 1649 */     TypeBinding leftType = this.left.resolvedType;
/*      */     boolean rightIsCast;
/* 1651 */     if (rightIsCast = this.right instanceof CastExpression) {
/* 1652 */       this.right.bits |= 0x20;
/*      */     }
/* 1654 */     TypeBinding rightType = this.right.resolveType(scope);
/*      */ 
/*      */     
/* 1657 */     if (leftType == null || rightType == null) {
/* 1658 */       this.constant = Constant.NotAConstant;
/*      */       
/*      */       return;
/*      */     } 
/* 1662 */     int leftTypeID = leftType.id;
/* 1663 */     int rightTypeID = rightType.id;
/*      */ 
/*      */     
/* 1666 */     boolean use15specifics = ((scope.compilerOptions()).sourceLevel >= 3211264L);
/* 1667 */     if (use15specifics) {
/* 1668 */       if (!leftType.isBaseType() && rightTypeID != 11 && rightTypeID != 12) {
/* 1669 */         leftTypeID = (scope.environment().computeBoxingType(leftType)).id;
/*      */       }
/* 1671 */       if (!rightType.isBaseType() && leftTypeID != 11 && leftTypeID != 12) {
/* 1672 */         rightTypeID = (scope.environment().computeBoxingType(rightType)).id;
/*      */       }
/*      */     } 
/* 1675 */     if (leftTypeID > 15 || 
/* 1676 */       rightTypeID > 15) {
/* 1677 */       if (leftTypeID == 11) {
/* 1678 */         rightTypeID = 1;
/* 1679 */       } else if (rightTypeID == 11) {
/* 1680 */         leftTypeID = 1;
/*      */       } else {
/* 1682 */         this.constant = Constant.NotAConstant;
/* 1683 */         scope.problemReporter().invalidOperator(this, leftType, rightType);
/*      */         return;
/*      */       } 
/*      */     }
/* 1687 */     if ((this.bits & 0x3F00) >> 8 == 14) {
/* 1688 */       if (leftTypeID == 11) {
/* 1689 */         this.left.computeConversion((Scope)scope, leftType, leftType);
/* 1690 */         if (rightType.isArrayType() && TypeBinding.equalsEquals(((ArrayBinding)rightType).elementsType(), (TypeBinding)TypeBinding.CHAR)) {
/* 1691 */           scope.problemReporter().signalNoImplicitStringConversionForCharArrayExpression(this.right);
/*      */         }
/*      */       } 
/* 1694 */       if (rightTypeID == 11) {
/* 1695 */         this.right.computeConversion((Scope)scope, rightType, rightType);
/* 1696 */         if (leftType.isArrayType() && TypeBinding.equalsEquals(((ArrayBinding)leftType).elementsType(), (TypeBinding)TypeBinding.CHAR)) {
/* 1697 */           scope.problemReporter().signalNoImplicitStringConversionForCharArrayExpression(this.left);
/*      */         }
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1709 */     int operator = (this.bits & 0x3F00) >> 8;
/* 1710 */     int operatorSignature = OperatorExpression.OperatorSignatures[operator][(leftTypeID << 4) + rightTypeID];
/*      */     
/* 1712 */     this.left.computeConversion((Scope)scope, TypeBinding.wellKnownType((Scope)scope, operatorSignature >>> 16 & 0xF), leftType);
/* 1713 */     this.right.computeConversion((Scope)scope, TypeBinding.wellKnownType((Scope)scope, operatorSignature >>> 8 & 0xF), rightType);
/* 1714 */     this.bits |= operatorSignature & 0xF;
/* 1715 */     switch (operatorSignature & 0xF) {
/*      */       
/*      */       case 5:
/* 1718 */         this.resolvedType = (TypeBinding)TypeBinding.BOOLEAN;
/*      */         break;
/*      */       case 3:
/* 1721 */         this.resolvedType = (TypeBinding)TypeBinding.BYTE;
/*      */         break;
/*      */       case 2:
/* 1724 */         this.resolvedType = (TypeBinding)TypeBinding.CHAR;
/*      */         break;
/*      */       case 8:
/* 1727 */         this.resolvedType = (TypeBinding)TypeBinding.DOUBLE;
/*      */         break;
/*      */       case 9:
/* 1730 */         this.resolvedType = (TypeBinding)TypeBinding.FLOAT;
/*      */         break;
/*      */       case 10:
/* 1733 */         this.resolvedType = (TypeBinding)TypeBinding.INT;
/*      */         break;
/*      */       case 7:
/* 1736 */         this.resolvedType = (TypeBinding)TypeBinding.LONG;
/*      */         break;
/*      */       case 11:
/* 1739 */         this.resolvedType = (TypeBinding)scope.getJavaLangString();
/*      */         break;
/*      */       default:
/* 1742 */         this.constant = Constant.NotAConstant;
/* 1743 */         scope.problemReporter().invalidOperator(this, leftType, rightType);
/*      */         return;
/*      */     } 
/*      */     
/*      */     boolean leftIsCast;
/* 1748 */     if ((leftIsCast = this.left instanceof CastExpression) || 
/* 1749 */       rightIsCast) {
/* 1750 */       CastExpression.checkNeedForArgumentCasts(scope, operator, operatorSignature, this.left, leftTypeID, leftIsCast, this.right, rightTypeID, rightIsCast);
/*      */     }
/*      */     
/* 1753 */     computeConstant(scope, leftTypeID, rightTypeID);
/*      */   }
/*      */   public void optimizedBooleanConstant(int leftId, int operator, int rightId) {
/*      */     Constant cst;
/* 1757 */     switch (operator) {
/*      */       case 2:
/* 1759 */         if (leftId != 5 || rightId != 5) {
/*      */           return;
/*      */         }
/*      */       
/*      */       case 0:
/* 1764 */         if ((cst = this.left.optimizedBooleanConstant()) != Constant.NotAConstant) {
/* 1765 */           if (!cst.booleanValue()) {
/* 1766 */             this.optimizedBooleanConstant = cst;
/*      */             return;
/*      */           } 
/* 1769 */           if ((cst = this.right.optimizedBooleanConstant()) != Constant.NotAConstant) {
/* 1770 */             this.optimizedBooleanConstant = cst;
/*      */           }
/*      */           
/*      */           return;
/*      */         } 
/*      */         
/* 1776 */         if ((cst = this.right.optimizedBooleanConstant()) != Constant.NotAConstant && 
/* 1777 */           !cst.booleanValue()) {
/* 1778 */           this.optimizedBooleanConstant = cst;
/*      */         }
/*      */         return;
/*      */       
/*      */       case 3:
/* 1783 */         if (leftId != 5 || rightId != 5) {
/*      */           return;
/*      */         }
/*      */       case 1:
/* 1787 */         if ((cst = this.left.optimizedBooleanConstant()) != Constant.NotAConstant) {
/* 1788 */           if (cst.booleanValue()) {
/* 1789 */             this.optimizedBooleanConstant = cst;
/*      */             return;
/*      */           } 
/* 1792 */           if ((cst = this.right.optimizedBooleanConstant()) != Constant.NotAConstant) {
/* 1793 */             this.optimizedBooleanConstant = cst;
/*      */           }
/*      */           
/*      */           return;
/*      */         } 
/* 1798 */         if ((cst = this.right.optimizedBooleanConstant()) != Constant.NotAConstant && 
/* 1799 */           cst.booleanValue()) {
/* 1800 */           this.optimizedBooleanConstant = cst;
/*      */         }
/*      */         break;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public StringBuffer printExpressionNoParenthesis(int indent, StringBuffer output) {
/* 1810 */     this.left.printExpression(indent, output).append(' ').append(operatorToString()).append(' ');
/* 1811 */     return this.right.printExpression(0, output);
/*      */   }
/*      */ 
/*      */   
/*      */   public void collectPatternVariablesToScope(LocalVariableBinding[] variables, BlockScope scope) {
/* 1816 */     addPatternVariablesWhenTrue(variables);
/* 1817 */     this.left.addPatternVariablesWhenTrue(variables);
/* 1818 */     this.left.collectPatternVariablesToScope(variables, scope);
/* 1819 */     this.right.addPatternVariablesWhenTrue(variables);
/* 1820 */     this.right.collectPatternVariablesToScope(variables, scope);
/*      */   }
/*      */   
/*      */   public void addPatternVariables(BlockScope scope, CodeStream codeStream) {
/* 1824 */     this.left.addPatternVariables(scope, codeStream);
/* 1825 */     this.right.addPatternVariables(scope, codeStream);
/*      */   }
/*      */   
/*      */   public boolean containsPatternVariable() {
/* 1829 */     return !(!this.left.containsPatternVariable() && !this.right.containsPatternVariable());
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public TypeBinding resolveType(BlockScope scope) {
/* 1835 */     if (this.patternVarsWhenFalse == null && this.patternVarsWhenTrue == null && 
/* 1836 */       containsPatternVariable())
/*      */     {
/*      */ 
/*      */       
/* 1840 */       collectPatternVariablesToScope((LocalVariableBinding[])null, scope);
/*      */     }
/*      */     boolean leftIsCast;
/* 1843 */     if (leftIsCast = this.left instanceof CastExpression) this.left.bits |= 0x20; 
/* 1844 */     TypeBinding leftType = this.left.resolveType(scope);
/*      */     boolean rightIsCast;
/* 1846 */     if (rightIsCast = this.right instanceof CastExpression) this.right.bits |= 0x20; 
/* 1847 */     TypeBinding rightType = this.right.resolveType(scope);
/*      */ 
/*      */     
/* 1850 */     if (leftType == null || rightType == null) {
/* 1851 */       this.constant = Constant.NotAConstant;
/* 1852 */       return null;
/*      */     } 
/*      */     
/* 1855 */     int leftTypeID = leftType.id;
/* 1856 */     int rightTypeID = rightType.id;
/*      */ 
/*      */     
/* 1859 */     boolean use15specifics = ((scope.compilerOptions()).sourceLevel >= 3211264L);
/* 1860 */     if (use15specifics) {
/* 1861 */       if (!leftType.isBaseType() && rightTypeID != 11 && rightTypeID != 12) {
/* 1862 */         leftTypeID = (scope.environment().computeBoxingType(leftType)).id;
/*      */       }
/* 1864 */       if (!rightType.isBaseType() && leftTypeID != 11 && leftTypeID != 12) {
/* 1865 */         rightTypeID = (scope.environment().computeBoxingType(rightType)).id;
/*      */       }
/*      */     } 
/* 1868 */     if (leftTypeID > 15 || 
/* 1869 */       rightTypeID > 15) {
/* 1870 */       if (leftTypeID == 11) {
/* 1871 */         rightTypeID = 1;
/* 1872 */       } else if (rightTypeID == 11) {
/* 1873 */         leftTypeID = 1;
/*      */       } else {
/* 1875 */         this.constant = Constant.NotAConstant;
/* 1876 */         scope.problemReporter().invalidOperator(this, leftType, rightType);
/* 1877 */         return null;
/*      */       } 
/*      */     }
/* 1880 */     if ((this.bits & 0x3F00) >> 8 == 14) {
/* 1881 */       if (leftTypeID == 11) {
/* 1882 */         this.left.computeConversion((Scope)scope, leftType, leftType);
/* 1883 */         if (rightType.isArrayType() && TypeBinding.equalsEquals(((ArrayBinding)rightType).elementsType(), (TypeBinding)TypeBinding.CHAR)) {
/* 1884 */           scope.problemReporter().signalNoImplicitStringConversionForCharArrayExpression(this.right);
/*      */         }
/*      */       } 
/* 1887 */       if (rightTypeID == 11) {
/* 1888 */         this.right.computeConversion((Scope)scope, rightType, rightType);
/* 1889 */         if (leftType.isArrayType() && TypeBinding.equalsEquals(((ArrayBinding)leftType).elementsType(), (TypeBinding)TypeBinding.CHAR)) {
/* 1890 */           scope.problemReporter().signalNoImplicitStringConversionForCharArrayExpression(this.left);
/*      */         }
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1902 */     int operator = (this.bits & 0x3F00) >> 8;
/* 1903 */     int operatorSignature = OperatorExpression.OperatorSignatures[operator][(leftTypeID << 4) + rightTypeID];
/*      */     
/* 1905 */     this.left.computeConversion((Scope)scope, TypeBinding.wellKnownType((Scope)scope, operatorSignature >>> 16 & 0xF), leftType);
/* 1906 */     this.right.computeConversion((Scope)scope, TypeBinding.wellKnownType((Scope)scope, operatorSignature >>> 8 & 0xF), rightType);
/* 1907 */     this.bits |= operatorSignature & 0xF;
/* 1908 */     switch (operatorSignature & 0xF) {
/*      */       
/*      */       case 5:
/* 1911 */         this.resolvedType = (TypeBinding)TypeBinding.BOOLEAN;
/*      */         break;
/*      */       case 3:
/* 1914 */         this.resolvedType = (TypeBinding)TypeBinding.BYTE;
/*      */         break;
/*      */       case 2:
/* 1917 */         this.resolvedType = (TypeBinding)TypeBinding.CHAR;
/*      */         break;
/*      */       case 8:
/* 1920 */         this.resolvedType = (TypeBinding)TypeBinding.DOUBLE;
/*      */         break;
/*      */       case 9:
/* 1923 */         this.resolvedType = (TypeBinding)TypeBinding.FLOAT;
/*      */         break;
/*      */       case 10:
/* 1926 */         this.resolvedType = (TypeBinding)TypeBinding.INT;
/*      */         break;
/*      */       case 7:
/* 1929 */         this.resolvedType = (TypeBinding)TypeBinding.LONG;
/*      */         break;
/*      */       case 11:
/* 1932 */         this.resolvedType = (TypeBinding)scope.getJavaLangString();
/*      */         break;
/*      */       default:
/* 1935 */         this.constant = Constant.NotAConstant;
/* 1936 */         scope.problemReporter().invalidOperator(this, leftType, rightType);
/* 1937 */         return null;
/*      */     } 
/*      */ 
/*      */     
/* 1941 */     if (leftIsCast || rightIsCast) {
/* 1942 */       CastExpression.checkNeedForArgumentCasts(scope, operator, operatorSignature, this.left, leftTypeID, leftIsCast, this.right, rightTypeID, rightIsCast);
/*      */     }
/*      */     
/* 1945 */     computeConstant(scope, leftTypeID, rightTypeID);
/* 1946 */     return this.resolvedType;
/*      */   }
/*      */ 
/*      */   
/*      */   public void traverse(ASTVisitor visitor, BlockScope scope) {
/* 1951 */     if (visitor.visit(this, scope)) {
/* 1952 */       this.left.traverse(visitor, scope);
/* 1953 */       this.right.traverse(visitor, scope);
/*      */     } 
/* 1955 */     visitor.endVisit(this, scope);
/*      */   }
/*      */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\ast\BinaryExpression.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */