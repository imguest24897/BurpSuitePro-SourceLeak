/*    */ package org.eclipse.jdt.internal.compiler.apt.model;
/*    */ 
/*    */ import javax.lang.model.type.PrimitiveType;
/*    */ import javax.lang.model.type.TypeKind;
/*    */ import javax.lang.model.type.TypeVisitor;
/*    */ import org.eclipse.jdt.internal.compiler.apt.dispatch.BaseProcessingEnvImpl;
/*    */ import org.eclipse.jdt.internal.compiler.lookup.BaseTypeBinding;
/*    */ import org.eclipse.jdt.internal.compiler.lookup.Binding;
/*    */ import org.eclipse.jdt.internal.compiler.lookup.TypeBinding;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PrimitiveTypeImpl
/*    */   extends TypeMirrorImpl
/*    */   implements PrimitiveType
/*    */ {
/* 33 */   public static final PrimitiveTypeImpl BOOLEAN = new PrimitiveTypeImpl(TypeBinding.BOOLEAN);
/* 34 */   public static final PrimitiveTypeImpl BYTE = new PrimitiveTypeImpl(TypeBinding.BYTE);
/* 35 */   public static final PrimitiveTypeImpl CHAR = new PrimitiveTypeImpl(TypeBinding.CHAR);
/* 36 */   public static final PrimitiveTypeImpl DOUBLE = new PrimitiveTypeImpl(TypeBinding.DOUBLE);
/* 37 */   public static final PrimitiveTypeImpl FLOAT = new PrimitiveTypeImpl(TypeBinding.FLOAT);
/* 38 */   public static final PrimitiveTypeImpl INT = new PrimitiveTypeImpl(TypeBinding.INT);
/* 39 */   public static final PrimitiveTypeImpl LONG = new PrimitiveTypeImpl(TypeBinding.LONG);
/* 40 */   public static final PrimitiveTypeImpl SHORT = new PrimitiveTypeImpl(TypeBinding.SHORT);
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   private PrimitiveTypeImpl(BaseTypeBinding binding) {
/* 48 */     super(null, (Binding)binding);
/*    */   }
/*    */ 
/*    */   
/*    */   PrimitiveTypeImpl(BaseProcessingEnvImpl env, BaseTypeBinding binding) {
/* 53 */     super(env, (Binding)binding);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public <R, P> R accept(TypeVisitor<R, P> v, P p) {
/* 59 */     return v.visitPrimitive(this, p);
/*    */   }
/*    */ 
/*    */   
/*    */   public TypeKind getKind() {
/* 64 */     return getKind((BaseTypeBinding)this._binding);
/*    */   }
/*    */   
/*    */   public static TypeKind getKind(BaseTypeBinding binding) {
/* 68 */     switch (binding.id) {
/*    */       case 5:
/* 70 */         return TypeKind.BOOLEAN;
/*    */       case 3:
/* 72 */         return TypeKind.BYTE;
/*    */       case 2:
/* 74 */         return TypeKind.CHAR;
/*    */       case 8:
/* 76 */         return TypeKind.DOUBLE;
/*    */       case 9:
/* 78 */         return TypeKind.FLOAT;
/*    */       case 10:
/* 80 */         return TypeKind.INT;
/*    */       case 7:
/* 82 */         return TypeKind.LONG;
/*    */       case 4:
/* 84 */         return TypeKind.SHORT;
/*    */     } 
/* 86 */     throw new IllegalArgumentException("BaseTypeBinding of unexpected id " + binding.id);
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\apt\model\PrimitiveTypeImpl.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */