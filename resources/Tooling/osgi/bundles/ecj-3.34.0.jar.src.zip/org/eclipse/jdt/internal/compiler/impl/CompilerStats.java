/*    */ package org.eclipse.jdt.internal.compiler.impl;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CompilerStats
/*    */   implements Comparable
/*    */ {
/*    */   public long startTime;
/*    */   public long endTime;
/*    */   public long overallTime;
/*    */   public long lineCount;
/*    */   public long parseTime;
/*    */   public long resolveTime;
/*    */   public long analyzeTime;
/*    */   public long generateTime;
/*    */   
/*    */   public long elapsedTime() {
/* 36 */     return this.overallTime;
/*    */   }
/*    */ 
/*    */   
/*    */   public int compareTo(Object o) {
/* 41 */     CompilerStats otherStats = (CompilerStats)o;
/* 42 */     long time1 = elapsedTime();
/* 43 */     long time2 = otherStats.elapsedTime();
/* 44 */     return (time1 < time2) ? -1 : ((time1 == time2) ? 0 : 1);
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\impl\CompilerStats.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */