/*     */ package org.eclipse.jdt.internal.compiler.apt.model;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import javax.lang.model.element.Element;
/*     */ import javax.lang.model.element.ElementKind;
/*     */ import javax.lang.model.element.ElementVisitor;
/*     */ import javax.lang.model.element.Modifier;
/*     */ import javax.lang.model.element.ModuleElement;
/*     */ import javax.lang.model.element.Name;
/*     */ import javax.lang.model.element.PackageElement;
/*     */ import javax.lang.model.element.TypeElement;
/*     */ import org.eclipse.jdt.internal.compiler.apt.dispatch.BaseProcessingEnvImpl;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.AnnotationBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.Binding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.ModuleBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.PackageBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.PlainPackageBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.TypeBinding;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ModuleElementImpl
/*     */   extends ElementImpl
/*     */   implements ModuleElement
/*     */ {
/*     */   ModuleBinding binding;
/*     */   private List<ModuleElement.Directive> directives;
/*  45 */   private static List<ModuleElement.Directive> EMPTY_DIRECTIVES = Collections.emptyList();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   ModuleElementImpl(BaseProcessingEnvImpl env, ModuleBinding binding) {
/*  53 */     super(env, (Binding)binding);
/*  54 */     this.binding = binding;
/*     */   }
/*     */ 
/*     */   
/*     */   public ElementKind getKind() {
/*  59 */     return ElementKind.MODULE;
/*     */   }
/*     */ 
/*     */   
/*     */   public Set<Modifier> getModifiers() {
/*  64 */     int modifiers = this.binding.modifiers;
/*  65 */     return Factory.getModifiers(modifiers, getKind(), false);
/*     */   }
/*     */ 
/*     */   
/*     */   public Name getQualifiedName() {
/*  70 */     return new NameImpl(this.binding.moduleName);
/*     */   }
/*     */ 
/*     */   
/*     */   public Name getSimpleName() {
/*  75 */     char[] simpleName = this.binding.moduleName;
/*  76 */     for (int i = simpleName.length - 1; i >= 0; i--) {
/*  77 */       if (simpleName[i] == '.') {
/*  78 */         simpleName = Arrays.copyOfRange(simpleName, i + 1, simpleName.length);
/*     */         break;
/*     */       } 
/*     */     } 
/*  82 */     return new NameImpl(simpleName);
/*     */   }
/*     */ 
/*     */   
/*     */   public List<? extends Element> getEnclosedElements() {
/*  87 */     ModuleBinding module = this.binding;
/*  88 */     Set<PlainPackageBinding> unique = new HashSet<>();
/*  89 */     for (PlainPackageBinding p : module.declaredPackages.values()) {
/*  90 */       if (!p.hasCompilationUnit(true))
/*     */         continue; 
/*  92 */       unique.add(p);
/*     */     } 
/*  94 */     if (module.isUnnamed()) {
/*  95 */       PlainPackageBinding def = module.environment.defaultPackage;
/*     */       
/*  97 */       if (def != null && def.hasCompilationUnit(true))
/*  98 */         unique.add(def); 
/*     */     } else {
/*     */       byte b; int i; PlainPackageBinding[] arrayOfPlainPackageBinding;
/* 101 */       for (i = (arrayOfPlainPackageBinding = this.binding.getExports()).length, b = 0; b < i; ) { PlainPackageBinding pBinding = arrayOfPlainPackageBinding[b];
/* 102 */         unique.add(pBinding); b++; }
/*     */       
/* 104 */       for (i = (arrayOfPlainPackageBinding = this.binding.getOpens()).length, b = 0; b < i; ) { PlainPackageBinding pBinding = arrayOfPlainPackageBinding[b];
/* 105 */         unique.add(pBinding); b++; }
/*     */     
/*     */     } 
/* 108 */     List<Element> enclosed = new ArrayList<>(unique.size());
/* 109 */     for (PlainPackageBinding p : unique) {
/* 110 */       PackageElement pElement = (PackageElement)this._env.getFactory().newElement((Binding)p);
/* 111 */       enclosed.add(pElement);
/*     */     } 
/* 113 */     return Collections.unmodifiableList(enclosed);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isOpen() {
/* 118 */     return ((this.binding.modifiers & 0x20) != 0);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isUnnamed() {
/* 123 */     return (this.binding.moduleName.length == 0);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Element getEnclosingElement() {
/* 129 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public List<? extends ModuleElement.Directive> getDirectives() {
/* 134 */     if (isUnnamed()) {
/* 135 */       return EMPTY_DIRECTIVES;
/*     */     }
/* 137 */     if (this.directives == null) {
/* 138 */       this.directives = new ArrayList<>();
/*     */     }
/* 140 */     PlainPackageBinding[] packs = this.binding.getExports(); byte b; int i; PlainPackageBinding[] arrayOfPlainPackageBinding1;
/* 141 */     for (i = (arrayOfPlainPackageBinding1 = packs).length, b = 0; b < i; ) { PlainPackageBinding exp = arrayOfPlainPackageBinding1[b];
/* 142 */       this.directives.add(new ExportsDirectiveImpl((PackageBinding)exp)); b++; }
/*     */     
/* 144 */     Set<ModuleBinding> transitive = new HashSet<>(); int j; ModuleBinding[] arrayOfModuleBinding1;
/* 145 */     for (j = (arrayOfModuleBinding1 = this.binding.getRequiresTransitive()).length, i = 0; i < j; ) { ModuleBinding mBinding = arrayOfModuleBinding1[i];
/* 146 */       transitive.add(mBinding); i++; }
/*     */     
/* 148 */     ModuleBinding[] required = this.binding.getRequires(); int k; ModuleBinding[] arrayOfModuleBinding2;
/* 149 */     for (k = (arrayOfModuleBinding2 = required).length, j = 0; j < k; ) { ModuleBinding mBinding = arrayOfModuleBinding2[j];
/* 150 */       if (transitive.contains(mBinding)) {
/* 151 */         this.directives.add(new RequiresDirectiveImpl(mBinding, true));
/*     */       } else {
/* 153 */         this.directives.add(new RequiresDirectiveImpl(mBinding, false));
/*     */       } 
/*     */       j++; }
/*     */     
/* 157 */     TypeBinding[] tBindings = this.binding.getUses(); int m; TypeBinding[] arrayOfTypeBinding1;
/* 158 */     for (m = (arrayOfTypeBinding1 = tBindings).length, k = 0; k < m; ) { TypeBinding tBinding = arrayOfTypeBinding1[k];
/* 159 */       this.directives.add(new UsesDirectiveImpl(tBinding)); k++; }
/*     */     
/* 161 */     tBindings = this.binding.getServices();
/* 162 */     for (m = (arrayOfTypeBinding1 = tBindings).length, k = 0; k < m; ) { TypeBinding tBinding = arrayOfTypeBinding1[k];
/* 163 */       this.directives.add(new ProvidesDirectiveImpl(tBinding)); k++; }
/*     */     
/* 165 */     packs = this.binding.getOpens(); PlainPackageBinding[] arrayOfPlainPackageBinding2;
/* 166 */     for (m = (arrayOfPlainPackageBinding2 = packs).length, k = 0; k < m; ) { PlainPackageBinding exp = arrayOfPlainPackageBinding2[k];
/* 167 */       this.directives.add(new OpensDirectiveImpl((PackageBinding)exp)); k++; }
/*     */     
/* 169 */     return this.directives;
/*     */   }
/*     */ 
/*     */   
/*     */   public <R, P> R accept(ElementVisitor<R, P> visitor, P param) {
/* 174 */     return visitor.visitModule(this, param);
/*     */   }
/*     */   
/*     */   protected AnnotationBinding[] getAnnotationBindings() {
/* 178 */     return ((ModuleBinding)this._binding).getAnnotations();
/*     */   }
/*     */   
/*     */   abstract class PackageDirectiveImpl {
/*     */     final PackageBinding binding1;
/*     */     List<ModuleElement> targets;
/*     */     
/*     */     PackageDirectiveImpl(PackageBinding pBinding) {
/* 186 */       this.binding1 = pBinding;
/*     */     }
/*     */     
/*     */     public PackageElement getPackage() {
/* 190 */       return ModuleElementImpl.this._env.getFactory().newPackageElement(this.binding1);
/*     */     }
/*     */     
/*     */     public List<? extends ModuleElement> getTargetModules(String[] restrictions) {
/* 194 */       if (this.targets != null) {
/* 195 */         return this.targets;
/*     */       }
/* 197 */       if (restrictions.length == 0) {
/* 198 */         return this.targets = null;
/*     */       }
/* 200 */       List<ModuleElement> targets1 = new ArrayList<>(restrictions.length); byte b; int i; String[] arrayOfString;
/* 201 */       for (i = (arrayOfString = restrictions).length, b = 0; b < i; ) { String string = arrayOfString[b];
/* 202 */         ModuleBinding target = ModuleElementImpl.this.binding.environment.getModule(string.toCharArray());
/* 203 */         if (target != null) {
/* 204 */           ModuleElement element = (ModuleElement)ModuleElementImpl.this._env.getFactory().newElement((Binding)target);
/* 205 */           targets1.add(element);
/*     */         }  b++; }
/*     */       
/* 208 */       return this.targets = Collections.unmodifiableList(targets1);
/*     */     }
/*     */   }
/*     */   
/*     */   class ExportsDirectiveImpl
/*     */     extends PackageDirectiveImpl implements ModuleElement.ExportsDirective {
/*     */     ExportsDirectiveImpl(PackageBinding pBinding) {
/* 215 */       super(pBinding);
/*     */     }
/*     */ 
/*     */     
/*     */     public <R, P> R accept(ModuleElement.DirectiveVisitor<R, P> visitor, P param) {
/* 220 */       return visitor.visitExports(this, param);
/*     */     }
/*     */ 
/*     */     
/*     */     public ModuleElement.DirectiveKind getKind() {
/* 225 */       return ModuleElement.DirectiveKind.EXPORTS;
/*     */     }
/*     */ 
/*     */     
/*     */     public PackageElement getPackage() {
/* 230 */       return ModuleElementImpl.this._env.getFactory().newPackageElement(this.binding1);
/*     */     }
/*     */     
/*     */     public List<? extends ModuleElement> getTargetModules() {
/* 234 */       if (this.targets != null) {
/* 235 */         return this.targets;
/*     */       }
/* 237 */       return getTargetModules(ModuleElementImpl.this.binding.getExportRestrictions(this.binding1));
/*     */     }
/*     */   }
/*     */   
/*     */   class RequiresDirectiveImpl
/*     */     implements ModuleElement.RequiresDirective {
/*     */     ModuleBinding dependency;
/*     */     boolean transitive;
/*     */     
/*     */     RequiresDirectiveImpl(ModuleBinding dependency, boolean transitive) {
/* 247 */       this.dependency = dependency;
/* 248 */       this.transitive = transitive;
/*     */     }
/*     */ 
/*     */     
/*     */     public <R, P> R accept(ModuleElement.DirectiveVisitor<R, P> visitor, P param) {
/* 253 */       return visitor.visitRequires(this, param);
/*     */     }
/*     */ 
/*     */     
/*     */     public ModuleElement.DirectiveKind getKind() {
/* 258 */       return ModuleElement.DirectiveKind.REQUIRES;
/*     */     }
/*     */ 
/*     */     
/*     */     public ModuleElement getDependency() {
/* 263 */       return (ModuleElement)ModuleElementImpl.this._env.getFactory().newElement((Binding)this.dependency, ElementKind.MODULE);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean isStatic() {
/* 269 */       return false;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isTransitive() {
/* 274 */       return this.transitive;
/*     */     }
/*     */   }
/*     */   
/*     */   class OpensDirectiveImpl
/*     */     extends PackageDirectiveImpl implements ModuleElement.OpensDirective {
/*     */     OpensDirectiveImpl(PackageBinding pBinding) {
/* 281 */       super(pBinding);
/*     */     }
/*     */ 
/*     */     
/*     */     public <R, P> R accept(ModuleElement.DirectiveVisitor<R, P> visitor, P param) {
/* 286 */       return visitor.visitOpens(this, param);
/*     */     }
/*     */ 
/*     */     
/*     */     public ModuleElement.DirectiveKind getKind() {
/* 291 */       return ModuleElement.DirectiveKind.OPENS;
/*     */     }
/*     */     
/*     */     public List<? extends ModuleElement> getTargetModules() {
/* 295 */       if (this.targets != null) {
/* 296 */         return this.targets;
/*     */       }
/* 298 */       return getTargetModules(ModuleElementImpl.this.binding.getOpenRestrictions(this.binding1));
/*     */     }
/*     */   }
/*     */   
/*     */   class UsesDirectiveImpl implements ModuleElement.UsesDirective {
/*     */     final TypeBinding binding1;
/*     */     
/*     */     UsesDirectiveImpl(TypeBinding binding) {
/* 306 */       this.binding1 = binding;
/*     */     }
/*     */ 
/*     */     
/*     */     public <R, P> R accept(ModuleElement.DirectiveVisitor<R, P> visitor, P param) {
/* 311 */       return visitor.visitUses(this, param);
/*     */     }
/*     */ 
/*     */     
/*     */     public ModuleElement.DirectiveKind getKind() {
/* 316 */       return ModuleElement.DirectiveKind.USES;
/*     */     }
/*     */ 
/*     */     
/*     */     public TypeElement getService() {
/* 321 */       return (TypeElement)ModuleElementImpl.this._env.getFactory().newElement((Binding)this.binding1);
/*     */     }
/*     */   }
/*     */   
/*     */   class ProvidesDirectiveImpl
/*     */     implements ModuleElement.ProvidesDirective
/*     */   {
/*     */     TypeBinding service;
/*     */     public List<? extends TypeElement> implementations;
/*     */     
/*     */     ProvidesDirectiveImpl(TypeBinding service) {
/* 332 */       this.service = service;
/*     */     }
/*     */ 
/*     */     
/*     */     public <R, P> R accept(ModuleElement.DirectiveVisitor<R, P> visitor, P param) {
/* 337 */       return visitor.visitProvides(this, param);
/*     */     }
/*     */ 
/*     */     
/*     */     public ModuleElement.DirectiveKind getKind() {
/* 342 */       return ModuleElement.DirectiveKind.PROVIDES;
/*     */     }
/*     */ 
/*     */     
/*     */     public List<? extends TypeElement> getImplementations() {
/* 347 */       if (this.implementations != null) {
/* 348 */         return this.implementations;
/*     */       }
/* 350 */       TypeBinding[] implementations2 = ModuleElementImpl.this.binding.getImplementations(this.service);
/* 351 */       if (implementations2.length == 0) {
/* 352 */         return this.implementations = Collections.emptyList();
/*     */       }
/*     */       
/* 355 */       List<TypeElement> list = new ArrayList<>(implementations2.length);
/* 356 */       Factory factory = ModuleElementImpl.this._env.getFactory(); byte b; int i; TypeBinding[] arrayOfTypeBinding1;
/* 357 */       for (i = (arrayOfTypeBinding1 = implementations2).length, b = 0; b < i; ) { TypeBinding type = arrayOfTypeBinding1[b];
/* 358 */         TypeElement element = (TypeElement)factory.newElement((Binding)type);
/* 359 */         list.add(element); b++; }
/*     */       
/* 361 */       return Collections.unmodifiableList(list);
/*     */     }
/*     */ 
/*     */     
/*     */     public TypeElement getService() {
/* 366 */       return (TypeElement)ModuleElementImpl.this._env.getFactory().newElement((Binding)this.service);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\apt\model\ModuleElementImpl.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */