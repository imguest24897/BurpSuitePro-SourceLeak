/*    */ package org.eclipse.jdt.internal.compiler.classfmt;
/*    */ 
/*    */ import org.eclipse.jdt.internal.compiler.env.IBinaryAnnotation;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MethodInfoWithAnnotations
/*    */   extends MethodInfo
/*    */ {
/*    */   protected AnnotationInfo[] annotations;
/*    */   
/*    */   MethodInfoWithAnnotations(MethodInfo methodInfo, AnnotationInfo[] annotations) {
/* 22 */     super(methodInfo.reference, methodInfo.constantPoolOffsets, methodInfo.structOffset, methodInfo.version);
/* 23 */     this.annotations = annotations;
/*    */     
/* 25 */     this.accessFlags = methodInfo.accessFlags;
/* 26 */     this.attributeBytes = methodInfo.attributeBytes;
/* 27 */     this.descriptor = methodInfo.descriptor;
/* 28 */     this.exceptionNames = methodInfo.exceptionNames;
/* 29 */     this.name = methodInfo.name;
/* 30 */     this.signature = methodInfo.signature;
/* 31 */     this.signatureUtf8Offset = methodInfo.signatureUtf8Offset;
/* 32 */     this.tagBits = methodInfo.tagBits;
/*    */   }
/*    */   
/*    */   public IBinaryAnnotation[] getAnnotations() {
/* 36 */     return (IBinaryAnnotation[])this.annotations;
/*    */   }
/*    */   
/*    */   protected void initialize() {
/* 40 */     for (int i = 0, l = (this.annotations == null) ? 0 : this.annotations.length; i < l; i++) {
/* 41 */       if (this.annotations[i] != null)
/* 42 */         this.annotations[i].initialize(); 
/* 43 */     }  super.initialize();
/*    */   }
/*    */   
/*    */   protected void reset() {
/* 47 */     for (int i = 0, l = (this.annotations == null) ? 0 : this.annotations.length; i < l; i++) {
/* 48 */       if (this.annotations[i] != null)
/* 49 */         this.annotations[i].reset(); 
/* 50 */     }  super.reset();
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\classfmt\MethodInfoWithAnnotations.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */