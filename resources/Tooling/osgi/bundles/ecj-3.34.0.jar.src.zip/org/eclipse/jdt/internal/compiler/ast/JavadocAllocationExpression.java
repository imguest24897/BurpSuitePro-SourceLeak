/*     */ package org.eclipse.jdt.internal.compiler.ast;
/*     */ 
/*     */ import org.eclipse.jdt.core.compiler.CharOperation;
/*     */ import org.eclipse.jdt.internal.compiler.ASTVisitor;
/*     */ import org.eclipse.jdt.internal.compiler.impl.Constant;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.Binding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.BlockScope;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.ClassScope;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.MethodBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.ParameterizedMethodBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.ProblemMethodBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.ReferenceBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.Scope;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.SourceTypeBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.TypeBinding;
/*     */ 
/*     */ 
/*     */ public class JavadocAllocationExpression
/*     */   extends AllocationExpression
/*     */ {
/*     */   public int tagSourceStart;
/*     */   public int tagSourceEnd;
/*     */   public int tagValue;
/*     */   public int memberStart;
/*     */   public char[][] qualification;
/*     */   
/*     */   public JavadocAllocationExpression(int start, int end) {
/*  28 */     this.sourceStart = start;
/*  29 */     this.sourceEnd = end;
/*  30 */     this.bits |= 0x8000;
/*     */   }
/*     */   public JavadocAllocationExpression(long pos) {
/*  33 */     this((int)(pos >>> 32L), (int)pos);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   TypeBinding internalResolveType(Scope scope) {
/*  39 */     this.constant = Constant.NotAConstant;
/*  40 */     if (this.type == null) {
/*  41 */       this.resolvedType = (TypeBinding)scope.enclosingSourceType();
/*  42 */     } else if (scope.kind == 3) {
/*  43 */       this.resolvedType = this.type.resolveType((ClassScope)scope);
/*     */     } else {
/*  45 */       this.resolvedType = this.type.resolveType((BlockScope)scope, true);
/*     */     } 
/*     */ 
/*     */     
/*  49 */     this.argumentTypes = Binding.NO_PARAMETERS;
/*  50 */     boolean hasTypeVarArgs = false;
/*  51 */     if (this.arguments != null) {
/*  52 */       this.argumentsHaveErrors = false;
/*  53 */       int length = this.arguments.length;
/*  54 */       this.argumentTypes = new TypeBinding[length];
/*  55 */       for (int i = 0; i < length; i++) {
/*  56 */         Expression argument = this.arguments[i];
/*  57 */         if (scope.kind == 3) {
/*  58 */           this.argumentTypes[i] = argument.resolveType((ClassScope)scope);
/*     */         } else {
/*  60 */           this.argumentTypes[i] = argument.resolveType((BlockScope)scope);
/*     */         } 
/*  62 */         if (this.argumentTypes[i] == null) {
/*  63 */           this.argumentsHaveErrors = true;
/*  64 */         } else if (!hasTypeVarArgs) {
/*  65 */           hasTypeVarArgs = this.argumentTypes[i].isTypeVariable();
/*     */         } 
/*     */       } 
/*  68 */       if (this.argumentsHaveErrors) {
/*  69 */         return null;
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/*  74 */     if (this.resolvedType == null) {
/*  75 */       return null;
/*     */     }
/*  77 */     this.resolvedType = scope.environment().convertToRawType(this.type.resolvedType, true);
/*  78 */     SourceTypeBinding enclosingType = scope.enclosingSourceType();
/*  79 */     if (enclosingType != null && enclosingType.isCompatibleWith(this.resolvedType)) {
/*  80 */       this.bits |= 0x4000;
/*     */     }
/*     */     
/*  83 */     ReferenceBinding allocationType = (ReferenceBinding)this.resolvedType;
/*  84 */     this.binding = scope.getConstructor(allocationType, this.argumentTypes, this);
/*  85 */     if (!this.binding.isValidBinding()) {
/*  86 */       ReferenceBinding enclosingTypeBinding = allocationType;
/*  87 */       MethodBinding contructorBinding = this.binding;
/*  88 */       while (!contructorBinding.isValidBinding() && (enclosingTypeBinding.isMemberType() || enclosingTypeBinding.isLocalType())) {
/*  89 */         enclosingTypeBinding = enclosingTypeBinding.enclosingType();
/*  90 */         contructorBinding = scope.getConstructor(enclosingTypeBinding, this.argumentTypes, this);
/*     */       } 
/*  92 */       if (contructorBinding.isValidBinding()) {
/*  93 */         this.binding = contructorBinding;
/*     */       }
/*     */     } 
/*  96 */     if (!this.binding.isValidBinding()) {
/*     */       
/*  98 */       MethodBinding methodBinding = scope.getMethod(this.resolvedType, this.resolvedType.sourceName(), this.argumentTypes, this);
/*  99 */       if (methodBinding.isValidBinding()) {
/* 100 */         this.binding = methodBinding;
/*     */       } else {
/* 102 */         if (this.binding.declaringClass == null) {
/* 103 */           this.binding.declaringClass = allocationType;
/*     */         }
/* 105 */         scope.problemReporter().javadocInvalidConstructor(this, this.binding, scope.getDeclarationModifiers());
/*     */       } 
/* 107 */       return this.resolvedType;
/* 108 */     }  if (this.binding.isVarargs()) {
/* 109 */       int length = this.argumentTypes.length;
/* 110 */       if (this.binding.parameters.length != length || !this.argumentTypes[length - 1].isArrayType()) {
/* 111 */         ProblemMethodBinding problemMethodBinding = new ProblemMethodBinding(this.binding, this.binding.selector, this.argumentTypes, 1);
/* 112 */         scope.problemReporter().javadocInvalidConstructor(this, (MethodBinding)problemMethodBinding, scope.getDeclarationModifiers());
/*     */       } 
/* 114 */     } else if (hasTypeVarArgs) {
/* 115 */       ProblemMethodBinding problemMethodBinding = new ProblemMethodBinding(this.binding, this.binding.selector, this.argumentTypes, 1);
/* 116 */       scope.problemReporter().javadocInvalidConstructor(this, (MethodBinding)problemMethodBinding, scope.getDeclarationModifiers());
/* 117 */     } else if (this.binding instanceof ParameterizedMethodBinding) {
/* 118 */       ParameterizedMethodBinding paramMethodBinding = (ParameterizedMethodBinding)this.binding;
/* 119 */       if (paramMethodBinding.hasSubstitutedParameters()) {
/* 120 */         int length = this.argumentTypes.length;
/* 121 */         for (int i = 0; i < length; i++) {
/* 122 */           if (TypeBinding.notEquals(paramMethodBinding.parameters[i], this.argumentTypes[i]) && 
/* 123 */             TypeBinding.notEquals(paramMethodBinding.parameters[i].erasure(), this.argumentTypes[i].erasure())) {
/* 124 */             ProblemMethodBinding problemMethodBinding = new ProblemMethodBinding(this.binding, this.binding.selector, this.argumentTypes, 1);
/* 125 */             scope.problemReporter().javadocInvalidConstructor(this, (MethodBinding)problemMethodBinding, scope.getDeclarationModifiers());
/*     */             break;
/*     */           } 
/*     */         } 
/*     */       } 
/* 130 */     } else if (this.resolvedType.isMemberType()) {
/* 131 */       int length = this.qualification.length;
/* 132 */       if (length > 1) {
/* 133 */         ReferenceBinding enclosingTypeBinding = allocationType;
/* 134 */         if (this.type instanceof JavadocQualifiedTypeReference && ((JavadocQualifiedTypeReference)this.type).tokens.length != length) {
/* 135 */           scope.problemReporter().javadocInvalidMemberTypeQualification(this.memberStart + 1, this.sourceEnd, scope.getDeclarationModifiers());
/*     */         } else {
/* 137 */           int idx = length; do {  }
/* 138 */           while (idx > 0 && CharOperation.equals(this.qualification[--idx], enclosingTypeBinding.sourceName) && (enclosingTypeBinding = enclosingTypeBinding.enclosingType()) != null);
/*     */ 
/*     */           
/* 141 */           if (idx > 0 || enclosingTypeBinding != null) {
/* 142 */             scope.problemReporter().javadocInvalidMemberTypeQualification(this.memberStart + 1, this.sourceEnd, scope.getDeclarationModifiers());
/*     */           }
/*     */         } 
/*     */       } 
/*     */     } 
/* 147 */     if (isMethodUseDeprecated(this.binding, scope, true, this)) {
/* 148 */       scope.problemReporter().javadocDeprecatedMethod(this.binding, this, scope.getDeclarationModifiers());
/*     */     }
/* 150 */     return (TypeBinding)allocationType;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isSuperAccess() {
/* 155 */     return ((this.bits & 0x4000) != 0);
/*     */   }
/*     */ 
/*     */   
/*     */   public TypeBinding resolveType(BlockScope scope) {
/* 160 */     return internalResolveType((Scope)scope);
/*     */   }
/*     */ 
/*     */   
/*     */   public TypeBinding resolveType(ClassScope scope) {
/* 165 */     return internalResolveType((Scope)scope);
/*     */   }
/*     */   
/*     */   public void traverse(ASTVisitor visitor, BlockScope scope) {
/* 169 */     if (visitor.visit(this, scope)) {
/* 170 */       if (this.typeArguments != null) {
/* 171 */         for (int i = 0, typeArgumentsLength = this.typeArguments.length; i < typeArgumentsLength; i++) {
/* 172 */           this.typeArguments[i].traverse(visitor, scope);
/*     */         }
/*     */       }
/* 175 */       if (this.type != null) {
/* 176 */         this.type.traverse(visitor, scope);
/*     */       }
/* 178 */       if (this.arguments != null)
/* 179 */         for (int i = 0, argumentsLength = this.arguments.length; i < argumentsLength; i++) {
/* 180 */           this.arguments[i].traverse(visitor, scope);
/*     */         } 
/*     */     } 
/* 183 */     visitor.endVisit(this, scope);
/*     */   }
/*     */   
/*     */   public void traverse(ASTVisitor visitor, ClassScope scope) {
/* 187 */     if (visitor.visit(this, scope)) {
/* 188 */       if (this.typeArguments != null) {
/* 189 */         for (int i = 0, typeArgumentsLength = this.typeArguments.length; i < typeArgumentsLength; i++) {
/* 190 */           this.typeArguments[i].traverse(visitor, scope);
/*     */         }
/*     */       }
/* 193 */       if (this.type != null) {
/* 194 */         this.type.traverse(visitor, scope);
/*     */       }
/* 196 */       if (this.arguments != null)
/* 197 */         for (int i = 0, argumentsLength = this.arguments.length; i < argumentsLength; i++) {
/* 198 */           this.arguments[i].traverse(visitor, scope);
/*     */         } 
/*     */     } 
/* 201 */     visitor.endVisit(this, scope);
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\ast\JavadocAllocationExpression.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */