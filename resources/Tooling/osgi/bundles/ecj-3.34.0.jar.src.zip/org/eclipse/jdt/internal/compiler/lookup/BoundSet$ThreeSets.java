/*     */ package org.eclipse.jdt.internal.compiler.lookup;
/*     */ 
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class ThreeSets
/*     */ {
/*     */   Set<TypeBound> superBounds;
/*     */   Set<TypeBound> sameBounds;
/*     */   Set<TypeBound> subBounds;
/*     */   TypeBinding instantiation;
/*     */   Map<InferenceVariable, TypeBound> inverseBounds;
/*     */   Set<InferenceVariable> dependencies;
/*     */   
/*     */   public boolean addBound(TypeBound bound) {
/*  75 */     boolean result = addBound1(bound);
/*  76 */     if (result) {
/*  77 */       Set<InferenceVariable> set = (this.dependencies == null) ? new LinkedHashSet<>() : this.dependencies;
/*  78 */       bound.right.collectInferenceVariables(set);
/*  79 */       if (this.dependencies == null && set.size() > 0) {
/*  80 */         this.dependencies = set;
/*     */       }
/*     */     } 
/*  83 */     return result;
/*     */   }
/*     */   private boolean addBound1(TypeBound bound) {
/*  86 */     switch (bound.relation) {
/*     */       case 3:
/*  88 */         if (this.superBounds == null) this.superBounds = new LinkedHashSet<>(); 
/*  89 */         return this.superBounds.add(bound);
/*     */       case 4:
/*  91 */         if (this.sameBounds == null) this.sameBounds = new LinkedHashSet<>(); 
/*  92 */         return this.sameBounds.add(bound);
/*     */       case 2:
/*  94 */         if (this.subBounds == null) this.subBounds = new LinkedHashSet<>(); 
/*  95 */         return this.subBounds.add(bound);
/*     */     } 
/*  97 */     throw new IllegalArgumentException("Unexpected bound relation in : " + bound);
/*     */   }
/*     */ 
/*     */   
/*     */   public TypeBinding[] lowerBounds(boolean onlyProper, InferenceVariable variable) {
/* 102 */     TypeBinding[] boundTypes = new TypeBinding[this.superBounds.size()];
/* 103 */     Iterator<TypeBound> it = this.superBounds.iterator();
/* 104 */     long nullHints = variable.nullHints;
/* 105 */     int i = 0;
/* 106 */     while (it.hasNext()) {
/* 107 */       TypeBound current = it.next();
/* 108 */       TypeBinding boundType = current.right;
/* 109 */       if (!onlyProper || boundType.isProperType(true)) {
/* 110 */         boundTypes[i++] = boundType;
/* 111 */         nullHints |= current.nullHints;
/*     */       } 
/*     */     } 
/* 114 */     if (i == 0)
/* 115 */       return Binding.NO_TYPES; 
/* 116 */     if (i < boundTypes.length)
/* 117 */       System.arraycopy(boundTypes, 0, boundTypes = new TypeBinding[i], 0, i); 
/* 118 */     useNullHints(nullHints, boundTypes, variable.environment);
/* 119 */     InferenceContext18.sortTypes(boundTypes);
/* 120 */     return boundTypes;
/*     */   }
/*     */   
/*     */   public TypeBinding[] upperBounds(boolean onlyProper, InferenceVariable variable) {
/* 124 */     TypeBinding[] rights = new TypeBinding[this.subBounds.size()];
/* 125 */     TypeBinding simpleUpper = null;
/* 126 */     Iterator<TypeBound> it = this.subBounds.iterator();
/* 127 */     long nullHints = variable.nullHints;
/* 128 */     int i = 0;
/* 129 */     while (it.hasNext()) {
/* 130 */       TypeBinding right = ((TypeBound)it.next()).right;
/* 131 */       if (!onlyProper || right.isProperType(true)) {
/* 132 */         if (right instanceof ReferenceBinding) {
/* 133 */           rights[i++] = right;
/* 134 */           nullHints |= right.tagBits & 0x180000000000000L; continue;
/*     */         } 
/* 136 */         if (simpleUpper != null)
/* 137 */           return Binding.NO_TYPES; 
/* 138 */         simpleUpper = right;
/*     */       } 
/*     */     } 
/*     */     
/* 142 */     if (i == 0) {
/* 143 */       (new TypeBinding[1])[0] = simpleUpper; return (simpleUpper != null) ? new TypeBinding[1] : Binding.NO_TYPES;
/* 144 */     }  if (i == 1 && simpleUpper != null)
/* 145 */       return new TypeBinding[] { simpleUpper }; 
/* 146 */     if (i < rights.length)
/* 147 */       System.arraycopy(rights, 0, rights = new TypeBinding[i], 0, i); 
/* 148 */     useNullHints(nullHints, rights, variable.environment);
/* 149 */     InferenceContext18.sortTypes(rights);
/* 150 */     return rights;
/*     */   }
/*     */   
/*     */   public boolean hasDependency(InferenceVariable beta) {
/* 154 */     if (this.dependencies != null && this.dependencies.contains(beta))
/* 155 */       return true; 
/* 156 */     if (this.inverseBounds != null && 
/* 157 */       this.inverseBounds.containsKey(beta))
/*     */     {
/* 159 */       return true;
/*     */     }
/*     */     
/* 162 */     return false;
/*     */   }
/*     */   
/*     */   public int size() {
/* 166 */     int size = 0;
/* 167 */     if (this.superBounds != null)
/* 168 */       size += this.superBounds.size(); 
/* 169 */     if (this.sameBounds != null)
/* 170 */       size += this.sameBounds.size(); 
/* 171 */     if (this.subBounds != null)
/* 172 */       size += this.subBounds.size(); 
/* 173 */     return size;
/*     */   }
/*     */   public int flattenInto(TypeBound[] collected, int idx) {
/* 176 */     if (this.superBounds != null) {
/* 177 */       int len = this.superBounds.size();
/* 178 */       System.arraycopy(this.superBounds.toArray(), 0, collected, idx, len);
/* 179 */       idx += len;
/*     */     } 
/* 181 */     if (this.sameBounds != null) {
/* 182 */       int len = this.sameBounds.size();
/* 183 */       System.arraycopy(this.sameBounds.toArray(), 0, collected, idx, len);
/* 184 */       idx += len;
/*     */     } 
/* 186 */     if (this.subBounds != null) {
/* 187 */       int len = this.subBounds.size();
/* 188 */       System.arraycopy(this.subBounds.toArray(), 0, collected, idx, len);
/* 189 */       idx += len;
/*     */     } 
/* 191 */     return idx;
/*     */   }
/*     */   public ThreeSets copy() {
/* 194 */     ThreeSets copy = new ThreeSets();
/* 195 */     if (this.superBounds != null)
/* 196 */       copy.superBounds = new LinkedHashSet<>(this.superBounds); 
/* 197 */     if (this.sameBounds != null)
/* 198 */       copy.sameBounds = new LinkedHashSet<>(this.sameBounds); 
/* 199 */     if (this.subBounds != null)
/* 200 */       copy.subBounds = new LinkedHashSet<>(this.subBounds); 
/* 201 */     copy.instantiation = this.instantiation;
/* 202 */     if (this.dependencies != null) {
/* 203 */       copy.dependencies = new LinkedHashSet<>(this.dependencies);
/*     */     }
/* 205 */     return copy;
/*     */   }
/*     */   public TypeBinding findSingleWrapperType() {
/* 208 */     if (this.instantiation != null && 
/* 209 */       this.instantiation.isProperType(true)) {
/* 210 */       switch (this.instantiation.id) {
/*     */         case 26:
/*     */         case 27:
/*     */         case 28:
/*     */         case 29:
/*     */         case 30:
/*     */         case 31:
/*     */         case 32:
/*     */         case 33:
/* 219 */           return this.instantiation;
/*     */       } 
/*     */     
/*     */     }
/* 223 */     if (this.subBounds != null) {
/* 224 */       Iterator<TypeBound> it = this.subBounds.iterator();
/* 225 */       while (it.hasNext()) {
/* 226 */         TypeBinding boundType = ((TypeBound)it.next()).right;
/* 227 */         if (boundType.isProperType(true)) {
/* 228 */           switch (boundType.id) {
/*     */             case 26:
/*     */             case 27:
/*     */             case 28:
/*     */             case 29:
/*     */             case 30:
/*     */             case 31:
/*     */             case 32:
/*     */             case 33:
/* 237 */               return boundType;
/*     */           } 
/*     */         }
/*     */       } 
/*     */     } 
/* 242 */     if (this.superBounds != null) {
/* 243 */       Iterator<TypeBound> it = this.superBounds.iterator();
/* 244 */       while (it.hasNext()) {
/* 245 */         TypeBinding boundType = ((TypeBound)it.next()).right;
/* 246 */         if (boundType.isProperType(true)) {
/* 247 */           switch (boundType.id) {
/*     */             case 26:
/*     */             case 27:
/*     */             case 28:
/*     */             case 29:
/*     */             case 30:
/*     */             case 31:
/*     */             case 32:
/*     */             case 33:
/* 256 */               return boundType;
/*     */           } 
/*     */         }
/*     */       } 
/*     */     } 
/* 261 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void useNullHints(long nullHints, TypeBinding[] boundTypes, LookupEnvironment environment) {
/* 270 */     if (nullHints == 108086391056891904L) {
/*     */       
/* 272 */       for (int i = 0; i < boundTypes.length; i++)
/* 273 */         boundTypes[i] = boundTypes[i].withoutToplevelNullAnnotation(); 
/*     */     } else {
/* 275 */       AnnotationBinding[] annot = environment.nullAnnotationsFromTagBits(nullHints);
/* 276 */       if (annot != null)
/*     */       {
/* 278 */         for (int i = 0; i < boundTypes.length; i++) {
/* 279 */           boundTypes[i] = environment.createAnnotatedType(boundTypes[i], annot);
/*     */         }
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   TypeBinding combineAndUseNullHints(TypeBinding type, long nullHints, LookupEnvironment environment) {
/* 287 */     if (this.sameBounds != null) {
/* 288 */       Iterator<TypeBound> it = this.sameBounds.iterator();
/* 289 */       while (it.hasNext())
/* 290 */         nullHints |= ((TypeBound)it.next()).nullHints; 
/*     */     } 
/* 292 */     if (this.superBounds != null) {
/* 293 */       Iterator<TypeBound> it = this.superBounds.iterator();
/* 294 */       while (it.hasNext())
/* 295 */         nullHints |= ((TypeBound)it.next()).nullHints; 
/*     */     } 
/* 297 */     if (this.subBounds != null) {
/* 298 */       Iterator<TypeBound> it = this.subBounds.iterator();
/* 299 */       while (it.hasNext())
/* 300 */         nullHints |= ((TypeBound)it.next()).nullHints; 
/*     */     } 
/* 302 */     if (nullHints == 108086391056891904L)
/* 303 */       return type.withoutToplevelNullAnnotation(); 
/* 304 */     AnnotationBinding[] annot = environment.nullAnnotationsFromTagBits(nullHints);
/* 305 */     if (annot != null)
/*     */     {
/* 307 */       return environment.createAnnotatedType(type, annot); } 
/* 308 */     return type;
/*     */   }
/*     */   public void setInstantiation(TypeBinding type, InferenceVariable variable, LookupEnvironment environment) {
/* 311 */     if (environment.globalOptions.isAnnotationBasedNullAnalysisEnabled) {
/* 312 */       long variableBits = variable.tagBits & 0x180000000000000L;
/* 313 */       long allBits = type.tagBits | variableBits;
/* 314 */       if (this.instantiation != null)
/* 315 */         allBits |= this.instantiation.tagBits; 
/* 316 */       allBits &= 0x180000000000000L;
/* 317 */       if (allBits == 108086391056891904L) {
/* 318 */         allBits = variableBits;
/*     */       }
/* 320 */       if (allBits != (type.tagBits & 0x180000000000000L)) {
/* 321 */         AnnotationBinding[] annot = environment.nullAnnotationsFromTagBits(allBits);
/* 322 */         if (annot != null) {
/* 323 */           type = environment.createAnnotatedType(type.withoutToplevelNullAnnotation(), annot);
/* 324 */         } else if (type.hasNullTypeAnnotations()) {
/* 325 */           type = type.withoutToplevelNullAnnotation();
/*     */         } 
/*     */       } 
/* 328 */     }  this.instantiation = type;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\lookup\BoundSet$ThreeSets.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */