/*    */ package org.eclipse.jdt.internal.compiler.codegen;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface AttributeNamesConstants
/*    */ {
/* 22 */   public static final char[] SyntheticName = "Synthetic".toCharArray();
/* 23 */   public static final char[] ConstantValueName = "ConstantValue".toCharArray();
/* 24 */   public static final char[] LineNumberTableName = "LineNumberTable".toCharArray();
/* 25 */   public static final char[] LocalVariableTableName = "LocalVariableTable".toCharArray();
/* 26 */   public static final char[] InnerClassName = "InnerClasses".toCharArray();
/* 27 */   public static final char[] CodeName = "Code".toCharArray();
/* 28 */   public static final char[] ExceptionsName = "Exceptions".toCharArray();
/* 29 */   public static final char[] SourceName = "SourceFile".toCharArray();
/* 30 */   public static final char[] DeprecatedName = "Deprecated".toCharArray();
/* 31 */   public static final char[] SignatureName = "Signature".toCharArray();
/* 32 */   public static final char[] LocalVariableTypeTableName = "LocalVariableTypeTable".toCharArray();
/* 33 */   public static final char[] EnclosingMethodName = "EnclosingMethod".toCharArray();
/* 34 */   public static final char[] ModuleName = "Module".toCharArray();
/* 35 */   public static final char[] ModuleMainClass = "ModuleMainClass".toCharArray();
/* 36 */   public static final char[] ModulePackages = "ModulePackages".toCharArray();
/* 37 */   public static final char[] AnnotationDefaultName = "AnnotationDefault".toCharArray();
/* 38 */   public static final char[] RuntimeInvisibleAnnotationsName = "RuntimeInvisibleAnnotations".toCharArray();
/* 39 */   public static final char[] RuntimeVisibleAnnotationsName = "RuntimeVisibleAnnotations".toCharArray();
/* 40 */   public static final char[] RuntimeInvisibleParameterAnnotationsName = "RuntimeInvisibleParameterAnnotations".toCharArray();
/* 41 */   public static final char[] RuntimeVisibleParameterAnnotationsName = "RuntimeVisibleParameterAnnotations".toCharArray();
/* 42 */   public static final char[] StackMapTableName = "StackMapTable".toCharArray();
/* 43 */   public static final char[] InconsistentHierarchy = "InconsistentHierarchy".toCharArray();
/* 44 */   public static final char[] VarargsName = "Varargs".toCharArray();
/* 45 */   public static final char[] StackMapName = "StackMap".toCharArray();
/* 46 */   public static final char[] MissingTypesName = "MissingTypes".toCharArray();
/* 47 */   public static final char[] BootstrapMethodsName = "BootstrapMethods".toCharArray();
/*    */   
/* 49 */   public static final char[] RuntimeVisibleTypeAnnotationsName = "RuntimeVisibleTypeAnnotations".toCharArray();
/* 50 */   public static final char[] RuntimeInvisibleTypeAnnotationsName = "RuntimeInvisibleTypeAnnotations".toCharArray();
/*    */   
/* 52 */   public static final char[] MethodParametersName = "MethodParameters".toCharArray();
/*    */   
/* 54 */   public static final char[] NestHost = "NestHost".toCharArray();
/* 55 */   public static final char[] NestMembers = "NestMembers".toCharArray();
/*    */   
/* 57 */   public static final char[] RecordClass = "Record".toCharArray();
/* 58 */   public static final char[] PermittedSubclasses = "PermittedSubclasses".toCharArray();
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\codegen\AttributeNamesConstants.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */