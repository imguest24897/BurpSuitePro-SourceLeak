/*     */ package org.eclipse.jdt.internal.compiler.apt.model;
/*     */ 
/*     */ import java.lang.reflect.Array;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import javax.lang.model.element.AnnotationMirror;
/*     */ import javax.lang.model.element.Element;
/*     */ import javax.lang.model.element.ElementKind;
/*     */ import javax.lang.model.element.Modifier;
/*     */ import javax.lang.model.element.Name;
/*     */ import javax.lang.model.element.NestingKind;
/*     */ import javax.lang.model.element.TypeParameterElement;
/*     */ import javax.lang.model.type.TypeKind;
/*     */ import javax.lang.model.type.TypeMirror;
/*     */ import org.eclipse.jdt.core.compiler.CharOperation;
/*     */ import org.eclipse.jdt.internal.compiler.apt.dispatch.BaseProcessingEnvImpl;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.PackageBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.ReferenceBinding;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ErrorTypeElement
/*     */   extends TypeElementImpl
/*     */ {
/*     */   ErrorTypeElement(BaseProcessingEnvImpl env, ReferenceBinding binding) {
/*  43 */     super(env, binding, (ElementKind)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<? extends TypeMirror> getInterfaces() {
/*  50 */     return Collections.emptyList();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public NestingKind getNestingKind() {
/*  58 */     return NestingKind.TOP_LEVEL;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Name getQualifiedName() {
/*     */     char[] qName;
/*  66 */     ReferenceBinding binding = (ReferenceBinding)this._binding;
/*     */     
/*  68 */     if (binding.isMemberType()) {
/*  69 */       qName = CharOperation.concatWith((binding.enclosingType()).compoundName, binding.sourceName, '.');
/*  70 */       CharOperation.replace(qName, '$', '.');
/*     */     } else {
/*  72 */       qName = CharOperation.concatWith(binding.compoundName, '.');
/*     */     } 
/*  74 */     return new NameImpl(qName);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TypeMirror getSuperclass() {
/*  82 */     return this._env.getFactory().getNoType(TypeKind.NONE);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<? extends TypeParameterElement> getTypeParameters() {
/*  90 */     return Collections.emptyList();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TypeMirror asType() {
/*  98 */     return this._env.getFactory().getErrorType((ReferenceBinding)this._binding);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <A extends java.lang.annotation.Annotation> A getAnnotation(Class<A> annotationType) {
/* 106 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<? extends AnnotationMirror> getAnnotationMirrors() {
/* 114 */     return Collections.emptyList();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public <A extends java.lang.annotation.Annotation> A[] getAnnotationsByType(Class<A> annotationType) {
/* 120 */     return (A[])Array.newInstance(annotationType, 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<? extends Element> getEnclosedElements() {
/* 129 */     return Collections.emptyList();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Element getEnclosingElement() {
/* 137 */     return this._env.getFactory().newPackageElement((PackageBinding)(this._env.getLookupEnvironment()).defaultPackage);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ElementKind getKind() {
/* 145 */     return ElementKind.CLASS;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Set<Modifier> getModifiers() {
/* 153 */     return Collections.emptySet();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Name getSimpleName() {
/* 161 */     ReferenceBinding binding = (ReferenceBinding)this._binding;
/* 162 */     return new NameImpl(binding.sourceName());
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\apt\model\ErrorTypeElement.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */