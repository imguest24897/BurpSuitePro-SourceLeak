/*     */ package org.eclipse.jdt.internal.compiler.classfmt;
/*     */ 
/*     */ import org.eclipse.jdt.internal.compiler.env.IBinaryNestedType;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class InnerClassInfo
/*     */   extends ClassFileStruct
/*     */   implements IBinaryNestedType
/*     */ {
/*  24 */   int innerClassNameIndex = -1;
/*  25 */   int outerClassNameIndex = -1;
/*  26 */   int innerNameIndex = -1;
/*     */   private char[] innerClassName;
/*     */   private char[] outerClassName;
/*     */   private char[] innerName;
/*  30 */   private int accessFlags = -1;
/*     */   private boolean readInnerClassName;
/*     */   private boolean readOuterClassName;
/*     */   private boolean readInnerName;
/*     */   
/*     */   public InnerClassInfo(byte[] classFileBytes, int[] offsets, int offset) {
/*  36 */     super(classFileBytes, offsets, offset);
/*  37 */     this.innerClassNameIndex = u2At(0);
/*  38 */     this.outerClassNameIndex = u2At(2);
/*  39 */     this.innerNameIndex = u2At(4);
/*     */   }
/*     */ 
/*     */   
/*     */   public char[] getEnclosingTypeName() {
/*  44 */     if (!this.readOuterClassName) {
/*     */       
/*  46 */       if (this.outerClassNameIndex != 0) {
/*  47 */         int utf8Offset = 
/*  48 */           this.constantPoolOffsets[u2At(
/*  49 */               this.constantPoolOffsets[this.outerClassNameIndex] - this.structOffset + 1)] - 
/*  50 */           this.structOffset;
/*  51 */         this.outerClassName = utf8At(utf8Offset + 3, u2At(utf8Offset + 1));
/*     */       } 
/*  53 */       this.readOuterClassName = true;
/*     */     } 
/*     */     
/*  56 */     return this.outerClassName;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getModifiers() {
/*  61 */     if (this.accessFlags == -1)
/*     */     {
/*  63 */       this.accessFlags = u2At(6);
/*     */     }
/*  65 */     return this.accessFlags;
/*     */   }
/*     */ 
/*     */   
/*     */   public char[] getName() {
/*  70 */     if (!this.readInnerClassName) {
/*     */       
/*  72 */       if (this.innerClassNameIndex != 0) {
/*  73 */         int classOffset = this.constantPoolOffsets[this.innerClassNameIndex] - this.structOffset;
/*  74 */         int utf8Offset = this.constantPoolOffsets[u2At(classOffset + 1)] - this.structOffset;
/*  75 */         this.innerClassName = utf8At(utf8Offset + 3, u2At(utf8Offset + 1));
/*     */       } 
/*  77 */       this.readInnerClassName = true;
/*     */     } 
/*  79 */     return this.innerClassName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public char[] getSourceName() {
/*  88 */     if (!this.readInnerName) {
/*  89 */       if (this.innerNameIndex != 0) {
/*  90 */         int utf8Offset = this.constantPoolOffsets[this.innerNameIndex] - this.structOffset;
/*  91 */         this.innerName = utf8At(utf8Offset + 3, u2At(utf8Offset + 1));
/*     */       } 
/*  93 */       this.readInnerName = true;
/*     */     } 
/*  95 */     return this.innerName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 103 */     StringBuilder buffer = new StringBuilder();
/* 104 */     if (getName() != null) {
/* 105 */       buffer.append(getName());
/*     */     }
/* 107 */     buffer.append("\n");
/* 108 */     if (getEnclosingTypeName() != null) {
/* 109 */       buffer.append(getEnclosingTypeName());
/*     */     }
/* 111 */     buffer.append("\n");
/* 112 */     if (getSourceName() != null) {
/* 113 */       buffer.append(getSourceName());
/*     */     }
/* 115 */     return buffer.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void initialize() {
/* 122 */     getModifiers();
/* 123 */     getName();
/* 124 */     getSourceName();
/* 125 */     getEnclosingTypeName();
/* 126 */     reset();
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\classfmt\InnerClassInfo.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */