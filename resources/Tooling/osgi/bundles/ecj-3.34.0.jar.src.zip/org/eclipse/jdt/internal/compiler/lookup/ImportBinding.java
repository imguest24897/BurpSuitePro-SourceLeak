/*    */ package org.eclipse.jdt.internal.compiler.lookup;
/*    */ 
/*    */ import org.eclipse.jdt.core.compiler.CharOperation;
/*    */ import org.eclipse.jdt.internal.compiler.ast.ImportReference;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ImportBinding
/*    */   extends Binding
/*    */ {
/*    */   public char[][] compoundName;
/*    */   public boolean onDemand;
/*    */   public ImportReference reference;
/*    */   public Binding resolvedImport;
/*    */   
/*    */   public ImportBinding(char[][] compoundName, boolean isOnDemand, Binding binding, ImportReference reference) {
/* 27 */     this.compoundName = compoundName;
/* 28 */     this.onDemand = isOnDemand;
/* 29 */     this.resolvedImport = binding;
/* 30 */     this.reference = reference;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public final int kind() {
/* 38 */     return 32;
/*    */   }
/*    */   public boolean isStatic() {
/* 41 */     return (this.reference != null && this.reference.isStatic());
/*    */   }
/*    */   public char[] getSimpleName() {
/* 44 */     if (this.reference != null) {
/* 45 */       return this.reference.getSimpleName();
/*    */     }
/* 47 */     return this.compoundName[this.compoundName.length - 1];
/*    */   }
/*    */ 
/*    */   
/*    */   public char[] readableName() {
/* 52 */     if (this.onDemand) {
/* 53 */       return CharOperation.concat(CharOperation.concatWith(this.compoundName, '.'), ".*".toCharArray());
/*    */     }
/* 55 */     return CharOperation.concatWith(this.compoundName, '.');
/*    */   }
/*    */   
/*    */   public String toString() {
/* 59 */     return "import : " + new String(readableName());
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\lookup\ImportBinding.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */