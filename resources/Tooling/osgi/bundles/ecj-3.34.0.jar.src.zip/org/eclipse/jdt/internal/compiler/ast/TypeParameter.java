/*     */ package org.eclipse.jdt.internal.compiler.ast;
/*     */ 
/*     */ import java.util.List;
/*     */ import org.eclipse.jdt.core.compiler.CharOperation;
/*     */ import org.eclipse.jdt.internal.compiler.ASTVisitor;
/*     */ import org.eclipse.jdt.internal.compiler.codegen.AnnotationContext;
/*     */ import org.eclipse.jdt.internal.compiler.codegen.CodeStream;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.AnnotationBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.Binding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.BlockScope;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.ClassScope;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.LookupEnvironment;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.MethodBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.MethodScope;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.Scope;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.TypeBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.TypeConstants;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.TypeVariableBinding;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TypeParameter
/*     */   extends AbstractVariableDeclaration
/*     */ {
/*     */   public TypeVariableBinding binding;
/*     */   public TypeReference[] bounds;
/*     */   
/*     */   public int getKind() {
/*  52 */     return 6;
/*     */   }
/*     */ 
/*     */   
/*     */   public void checkBounds(Scope scope) {
/*  57 */     if (this.type != null) {
/*  58 */       this.type.checkBounds(scope);
/*     */     }
/*  60 */     if (this.bounds != null) {
/*  61 */       for (int i = 0, length = this.bounds.length; i < length; i++) {
/*  62 */         this.bounds[i].checkBounds(scope);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public void getAllAnnotationContexts(int targetType, int typeParameterIndex, List<AnnotationContext> allAnnotationContexts) {
/*  68 */     TypeReference.AnnotationCollector collector = new TypeReference.AnnotationCollector(this, targetType, typeParameterIndex, allAnnotationContexts);
/*  69 */     if (this.annotations != null) {
/*  70 */       int annotationsLength = this.annotations.length;
/*  71 */       for (int i = 0; i < annotationsLength; i++)
/*  72 */         this.annotations[i].traverse(collector, (BlockScope)null); 
/*     */     } 
/*  74 */     switch (collector.targetType) {
/*     */       case 0:
/*  76 */         collector.targetType = 17;
/*     */         break;
/*     */       case 1:
/*  79 */         collector.targetType = 18; break;
/*     */     } 
/*  81 */     int boundIndex = 0;
/*  82 */     if (this.type != null) {
/*     */       
/*  84 */       if (this.type.resolvedType.isInterface())
/*  85 */         boundIndex = 1; 
/*  86 */       if ((this.type.bits & 0x100000) != 0) {
/*  87 */         collector.info2 = boundIndex;
/*  88 */         this.type.traverse(collector, (BlockScope)null);
/*     */       } 
/*     */     } 
/*  91 */     if (this.bounds != null) {
/*  92 */       int boundsLength = this.bounds.length;
/*  93 */       for (int i = 0; i < boundsLength; i++) {
/*  94 */         TypeReference bound = this.bounds[i];
/*  95 */         if ((bound.bits & 0x100000) != 0) {
/*     */ 
/*     */           
/*  98 */           collector.info2 = ++boundIndex;
/*  99 */           bound.traverse(collector, (BlockScope)null);
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */   private void internalResolve(Scope scope, boolean staticContext) {
/* 105 */     if (this.binding != null) {
/* 106 */       Binding existingType = scope.parent.getBinding(this.name, 4, this, false);
/* 107 */       if (existingType != null && 
/* 108 */         this.binding != existingType && 
/* 109 */         existingType.isValidBinding() && (
/* 110 */         existingType.kind() != 4100 || !staticContext)) {
/* 111 */         scope.problemReporter().typeHiding(this, existingType);
/*     */       }
/*     */     } 
/* 114 */     if (this.annotations != null || scope.environment().usesNullTypeAnnotations()) {
/* 115 */       resolveAnnotations(scope);
/*     */     }
/* 117 */     if (CharOperation.equals(this.name, TypeConstants.VAR)) {
/* 118 */       if ((scope.compilerOptions()).sourceLevel < 3538944L) {
/* 119 */         scope.problemReporter().varIsReservedTypeNameInFuture(this);
/*     */       } else {
/* 121 */         scope.problemReporter().varIsNotAllowedHere(this);
/*     */       } 
/*     */     }
/* 124 */     scope.problemReporter().validateRestrictedKeywords(this.name, this);
/*     */   }
/*     */ 
/*     */   
/*     */   public void resolve(BlockScope scope) {
/* 129 */     internalResolve((Scope)scope, (scope.methodScope()).isStatic);
/*     */   }
/*     */   
/*     */   public void resolve(ClassScope scope) {
/* 133 */     internalResolve((Scope)scope, scope.enclosingSourceType().isStatic());
/*     */   }
/*     */   
/*     */   public void resolveAnnotations(Scope scope) {
/* 137 */     BlockScope resolutionScope = Scope.typeAnnotationsResolutionScope(scope);
/* 138 */     if (resolutionScope != null) {
/* 139 */       AnnotationBinding[] annotationBindings = resolveAnnotations(resolutionScope, this.annotations, (Binding)this.binding, false);
/* 140 */       LookupEnvironment environment = scope.environment();
/* 141 */       boolean isAnnotationBasedNullAnalysisEnabled = environment.globalOptions.isAnnotationBasedNullAnalysisEnabled;
/* 142 */       if (annotationBindings != null && annotationBindings.length > 0) {
/* 143 */         this.binding.setTypeAnnotations(annotationBindings, isAnnotationBasedNullAnalysisEnabled);
/* 144 */         (scope.referenceCompilationUnit()).compilationResult.hasAnnotations = true;
/*     */       } 
/* 146 */       if (isAnnotationBasedNullAnalysisEnabled && 
/* 147 */         this.binding != null && this.binding.isValidBinding()) {
/* 148 */         if (scope.hasDefaultNullnessFor(128, sourceStart())) {
/* 149 */           if (this.binding.hasNullTypeAnnotations()) {
/* 150 */             if ((this.binding.tagBits & 0x100000000000000L) != 0L)
/* 151 */               scope.problemReporter().nullAnnotationIsRedundant(this); 
/*     */           } else {
/* 153 */             AnnotationBinding[] annots = { environment.getNonNullAnnotation() };
/* 154 */             TypeVariableBinding previousBinding = this.binding;
/* 155 */             this.binding = (TypeVariableBinding)environment.createAnnotatedType((TypeBinding)this.binding, annots);
/*     */             
/* 157 */             if (scope instanceof MethodScope) {
/*     */ 
/*     */ 
/*     */ 
/*     */               
/* 162 */               MethodScope methodScope = (MethodScope)scope;
/* 163 */               if (methodScope.referenceContext instanceof AbstractMethodDeclaration) {
/* 164 */                 MethodBinding methodBinding = ((AbstractMethodDeclaration)methodScope.referenceContext).binding;
/* 165 */                 if (methodBinding != null) {
/* 166 */                   methodBinding.updateTypeVariableBinding(previousBinding, this.binding);
/*     */                 }
/*     */               } 
/*     */             } 
/*     */           } 
/*     */         }
/* 172 */         this.binding.evaluateNullAnnotations(scope, this);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public StringBuffer printStatement(int indent, StringBuffer output) {
/* 180 */     if (this.annotations != null) {
/* 181 */       printAnnotations(this.annotations, output);
/* 182 */       output.append(' ');
/*     */     } 
/* 184 */     output.append(this.name);
/* 185 */     if (this.type != null) {
/* 186 */       output.append(" extends ");
/* 187 */       this.type.print(0, output);
/*     */     } 
/* 189 */     if (this.bounds != null) {
/* 190 */       for (int i = 0; i < this.bounds.length; i++) {
/* 191 */         output.append(" & ");
/* 192 */         this.bounds[i].print(0, output);
/*     */       } 
/*     */     }
/* 195 */     return output;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void generateCode(BlockScope currentScope, CodeStream codeStream) {}
/*     */ 
/*     */ 
/*     */   
/*     */   public void traverse(ASTVisitor visitor, BlockScope scope) {
/* 205 */     if (visitor.visit(this, scope)) {
/* 206 */       if (this.annotations != null) {
/* 207 */         int annotationsLength = this.annotations.length;
/* 208 */         for (int i = 0; i < annotationsLength; i++)
/* 209 */           this.annotations[i].traverse(visitor, scope); 
/*     */       } 
/* 211 */       if (this.type != null) {
/* 212 */         this.type.traverse(visitor, scope);
/*     */       }
/* 214 */       if (this.bounds != null) {
/* 215 */         int boundsLength = this.bounds.length;
/* 216 */         for (int i = 0; i < boundsLength; i++) {
/* 217 */           this.bounds[i].traverse(visitor, scope);
/*     */         }
/*     */       } 
/*     */     } 
/* 221 */     visitor.endVisit(this, scope);
/*     */   }
/*     */   
/*     */   public void traverse(ASTVisitor visitor, ClassScope scope) {
/* 225 */     if (visitor.visit(this, scope)) {
/* 226 */       if (this.annotations != null) {
/* 227 */         int annotationsLength = this.annotations.length;
/* 228 */         for (int i = 0; i < annotationsLength; i++)
/* 229 */           this.annotations[i].traverse(visitor, scope); 
/*     */       } 
/* 231 */       if (this.type != null) {
/* 232 */         this.type.traverse(visitor, scope);
/*     */       }
/* 234 */       if (this.bounds != null) {
/* 235 */         int boundsLength = this.bounds.length;
/* 236 */         for (int i = 0; i < boundsLength; i++) {
/* 237 */           this.bounds[i].traverse(visitor, scope);
/*     */         }
/*     */       } 
/*     */     } 
/* 241 */     visitor.endVisit(this, scope);
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\ast\TypeParameter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */