/*     */ package org.eclipse.jdt.internal.compiler.apt.model;
/*     */ 
/*     */ import javax.lang.model.type.TypeMirror;
/*     */ import org.eclipse.jdt.core.compiler.CharOperation;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.Binding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.MethodBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.ReferenceBinding;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class null
/*     */   implements TypesImpl.MemberInTypeFinder
/*     */ {
/*     */   public TypeMirror find(ReferenceBinding typeBinding, Binding memberBinding) {
/*  97 */     MethodBinding methodBinding = (MethodBinding)memberBinding; byte b; int i; MethodBinding[] arrayOfMethodBinding;
/*  98 */     for (i = (arrayOfMethodBinding = typeBinding.methods()).length, b = 0; b < i; ) { MethodBinding method = arrayOfMethodBinding[b];
/*  99 */       if (CharOperation.equals(method.selector, methodBinding.selector) && (
/* 100 */         method.original() == methodBinding || 
/* 101 */         method.areParameterErasuresEqual(methodBinding)))
/* 102 */         return TypesImpl.this._env.getFactory().newTypeMirror((Binding)method); 
/*     */       b++; }
/*     */     
/* 105 */     return null;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\apt\model\TypesImpl$1.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */