/*     */ package org.eclipse.jdt.internal.compiler.env;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.ModuleBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.ReferenceBinding;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class NameEnvironmentAnswer
/*     */ {
/*     */   IBinaryType binaryType;
/*     */   ICompilationUnit compilationUnit;
/*     */   ISourceType[] sourceTypes;
/*     */   ReferenceBinding binding;
/*     */   AccessRestriction accessRestriction;
/*     */   char[] moduleName;
/*     */   public ModuleBinding moduleBinding;
/*     */   String externalAnnotationPath;
/*     */   
/*     */   public NameEnvironmentAnswer(IBinaryType binaryType, AccessRestriction accessRestriction) {
/*  35 */     this(binaryType, accessRestriction, binaryType.getModule());
/*     */   }
/*     */   
/*     */   public NameEnvironmentAnswer(IBinaryType binaryType, AccessRestriction accessRestriction, char[] module) {
/*  39 */     this.binaryType = binaryType;
/*  40 */     this.accessRestriction = accessRestriction;
/*  41 */     this.moduleName = module;
/*     */   }
/*     */   public NameEnvironmentAnswer(ICompilationUnit compilationUnit, AccessRestriction accessRestriction) {
/*  44 */     this(compilationUnit, accessRestriction, compilationUnit.getModuleName());
/*     */   }
/*     */   public NameEnvironmentAnswer(ICompilationUnit compilationUnit, AccessRestriction accessRestriction, char[] module) {
/*  47 */     this.compilationUnit = compilationUnit;
/*  48 */     this.accessRestriction = accessRestriction;
/*  49 */     this.moduleName = module;
/*     */   }
/*     */   
/*     */   public NameEnvironmentAnswer(ISourceType[] sourceTypes, AccessRestriction accessRestriction, String externalAnnotationPath, char[] module) {
/*  53 */     this.sourceTypes = sourceTypes;
/*  54 */     this.accessRestriction = accessRestriction;
/*  55 */     this.externalAnnotationPath = externalAnnotationPath;
/*  56 */     this.moduleName = module;
/*     */   }
/*     */   
/*     */   public NameEnvironmentAnswer(ReferenceBinding binding, ModuleBinding module) {
/*  60 */     this.binding = binding;
/*  61 */     this.moduleBinding = module;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/*  66 */     String baseString = "";
/*  67 */     if (this.binaryType != null) {
/*  68 */       char[] fileNameChars = this.binaryType.getFileName();
/*  69 */       String fileName = (fileNameChars == null) ? "" : new String(fileNameChars);
/*  70 */       baseString = "IBinaryType " + fileName;
/*     */     } 
/*  72 */     if (this.compilationUnit != null) {
/*  73 */       baseString = "ICompilationUnit " + this.compilationUnit.toString();
/*     */     }
/*  75 */     if (this.sourceTypes != null) {
/*  76 */       baseString = Arrays.toString((Object[])this.sourceTypes);
/*     */     }
/*  78 */     if (this.accessRestriction != null) {
/*  79 */       baseString = String.valueOf(baseString) + " " + this.accessRestriction.toString();
/*     */     }
/*  81 */     if (this.externalAnnotationPath != null) {
/*  82 */       baseString = String.valueOf(baseString) + " extPath=" + this.externalAnnotationPath.toString();
/*     */     }
/*  84 */     if (this.moduleName != null) {
/*  85 */       baseString = String.valueOf(baseString) + " module=" + String.valueOf(this.moduleName);
/*     */     }
/*  87 */     return baseString;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AccessRestriction getAccessRestriction() {
/*  94 */     return this.accessRestriction;
/*     */   }
/*     */   
/*     */   public void setBinaryType(IBinaryType newType) {
/*  98 */     this.binaryType = newType;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IBinaryType getBinaryType() {
/* 106 */     return this.binaryType;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ICompilationUnit getCompilationUnit() {
/* 114 */     return this.compilationUnit;
/*     */   }
/*     */   
/*     */   public String getExternalAnnotationPath() {
/* 118 */     return this.externalAnnotationPath;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ISourceType[] getSourceTypes() {
/* 129 */     return this.sourceTypes;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ReferenceBinding getResolvedBinding() {
/* 136 */     return this.binding;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isBinaryType() {
/* 143 */     return (this.binaryType != null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isCompilationUnit() {
/* 150 */     return (this.compilationUnit != null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isSourceType() {
/* 157 */     return (this.sourceTypes != null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isResolvedBinding() {
/* 164 */     return (this.binding != null);
/*     */   }
/*     */   
/*     */   public boolean ignoreIfBetter() {
/* 168 */     return (this.accessRestriction != null && this.accessRestriction.ignoreIfBetter());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public char[] moduleName() {
/* 177 */     return this.moduleName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isBetter(NameEnvironmentAnswer otherAnswer) {
/* 186 */     if (otherAnswer == null) return true; 
/* 187 */     if (this.accessRestriction == null) return true; 
/* 188 */     return (otherAnswer.accessRestriction != null && 
/* 189 */       this.accessRestriction.getProblemId() < otherAnswer.accessRestriction.getProblemId());
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\env\NameEnvironmentAnswer.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */