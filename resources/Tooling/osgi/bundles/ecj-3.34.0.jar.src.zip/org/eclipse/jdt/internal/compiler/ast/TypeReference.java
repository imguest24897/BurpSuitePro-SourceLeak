/*     */ package org.eclipse.jdt.internal.compiler.ast;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.eclipse.jdt.core.compiler.CharOperation;
/*     */ import org.eclipse.jdt.internal.compiler.ASTVisitor;
/*     */ import org.eclipse.jdt.internal.compiler.codegen.AnnotationContext;
/*     */ import org.eclipse.jdt.internal.compiler.flow.FlowContext;
/*     */ import org.eclipse.jdt.internal.compiler.flow.FlowInfo;
/*     */ import org.eclipse.jdt.internal.compiler.impl.CompilerOptions;
/*     */ import org.eclipse.jdt.internal.compiler.impl.Constant;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.AnnotationBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.ArrayBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.BlockScope;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.ClassScope;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.LocalVariableBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.LookupEnvironment;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.ProblemReferenceBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.RecordComponentBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.ReferenceBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.Scope;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.SourceTypeBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.Substitution;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.TypeBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.TypeConstants;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class TypeReference
/*     */   extends Expression
/*     */ {
/*     */   public TypeReference() {
/* 357 */     this.annotations = null;
/*     */   }
/*     */   public static final TypeReference[] NO_TYPE_ARGUMENTS = new TypeReference[0];
/*     */   public Annotation[][] annotations;
/*     */   
/*     */   public enum AnnotationPosition {
/*     */     MAIN_TYPE, LEAF_TYPE, ANY; }
/*     */   
/* 365 */   public FlowInfo analyseCode(BlockScope currentScope, FlowContext flowContext, FlowInfo flowInfo) { return flowInfo; }
/*     */   static class AnnotationCollector extends ASTVisitor {
/*     */     List<AnnotationContext> annotationContexts;
/*     */     Expression typeReference;
/*     */     int targetType;
/*     */     int info = 0;
/*     */     int info2 = 0;
/*     */     LocalVariableBinding localVariable;
/*     */     Annotation[][] annotationsOnDimensions;
/*     */     int dimensions;
/*     */     Wildcard currentWildcard;
/*     */     RecordComponentBinding recordComponentBinding;
/*     */     public AnnotationCollector(TypeParameter typeParameter, int targetType, int typeParameterIndex, List<AnnotationContext> annotationContexts) { this.annotationContexts = annotationContexts; this.typeReference = typeParameter.type; this.targetType = targetType; this.info = typeParameterIndex; }
/* 378 */     public AnnotationCollector(LocalDeclaration localDeclaration, int targetType, LocalVariableBinding localVariable, List<AnnotationContext> annotationContexts) { this.annotationContexts = annotationContexts; this.typeReference = localDeclaration.type; this.targetType = targetType; this.localVariable = localVariable; } public AnnotationCollector(LocalDeclaration localDeclaration, int targetType, int parameterIndex, List<AnnotationContext> annotationContexts) { this.annotationContexts = annotationContexts; this.typeReference = localDeclaration.type; this.targetType = targetType; this.info = parameterIndex; } public AnnotationCollector(TypeReference typeReference, int targetType, List<AnnotationContext> annotationContexts) { this.annotationContexts = annotationContexts; this.typeReference = typeReference; this.targetType = targetType; } public AnnotationCollector(Expression typeReference, int targetType, int info, List<AnnotationContext> annotationContexts) { this.annotationContexts = annotationContexts; this.typeReference = typeReference; this.info = info; this.targetType = targetType; } public AnnotationCollector(TypeReference typeReference, int targetType, int info, int typeIndex, List<AnnotationContext> annotationContexts) { this.annotationContexts = annotationContexts; this.typeReference = typeReference; this.info = info; this.targetType = targetType; this.info2 = typeIndex; } public AnnotationCollector(TypeReference typeReference, int targetType, int info, List<AnnotationContext> annotationContexts, Annotation[][] annotationsOnDimensions, int dimensions) { this.annotationContexts = annotationContexts; this.typeReference = typeReference; this.info = info; this.targetType = targetType; this.annotationsOnDimensions = annotationsOnDimensions; this.dimensions = dimensions; } public AnnotationCollector(RecordComponent recordComponent, int targetType, List<AnnotationContext> annotationContexts) { this.annotationContexts = annotationContexts; this.typeReference = recordComponent.type; this.targetType = targetType; this.recordComponentBinding = recordComponent.binding; } private boolean internalVisit(Annotation annotation) { AnnotationContext annotationContext = null; if (annotation.isRuntimeTypeInvisible()) { annotationContext = new AnnotationContext(annotation, this.typeReference, this.targetType, 2); } else if (annotation.isRuntimeTypeVisible()) { annotationContext = new AnnotationContext(annotation, this.typeReference, this.targetType, 1); }  if (annotationContext != null) { annotationContext.wildcard = this.currentWildcard; switch (this.targetType) { case 0: case 1: case 16: case 22: case 23: case 66: case 67: case 68: case 69: case 70: annotationContext.info = this.info; break;case 64: case 65: annotationContext.variableBinding = this.localVariable; break;case 17: case 18: case 71: case 72: case 73: case 74: case 75: annotationContext.info2 = this.info2; annotationContext.info = this.info; break; }  this.annotationContexts.add(annotationContext); }  return true; } public boolean visit(MarkerAnnotation annotation, BlockScope scope) { return internalVisit(annotation); } public boolean visit(NormalAnnotation annotation, BlockScope scope) { return internalVisit(annotation); } public boolean visit(SingleMemberAnnotation annotation, BlockScope scope) { return internalVisit(annotation); } public boolean visit(Wildcard wildcard, BlockScope scope) { this.currentWildcard = wildcard; return true; } public boolean visit(Argument argument, BlockScope scope) { if ((argument.bits & 0x20000000) == 0) return true;  for (int i = 0, max = this.localVariable.initializationCount; i < max; i++) { int startPC = this.localVariable.initializationPCs[i << 1]; int endPC = this.localVariable.initializationPCs[(i << 1) + 1]; if (startPC != endPC) return true;  }  return false; } public boolean visit(Argument argument, ClassScope scope) { if ((argument.bits & 0x20000000) == 0) return true;  for (int i = 0, max = this.localVariable.initializationCount; i < max; i++) { int startPC = this.localVariable.initializationPCs[i << 1]; int endPC = this.localVariable.initializationPCs[(i << 1) + 1]; if (startPC != endPC) return true;  }  return false; } public boolean visit(LocalDeclaration localDeclaration, BlockScope scope) { for (int i = 0, max = this.localVariable.initializationCount; i < max; i++) { int startPC = this.localVariable.initializationPCs[i << 1]; int endPC = this.localVariable.initializationPCs[(i << 1) + 1]; if (startPC != endPC) return true;  }  return false; } public void endVisit(Wildcard wildcard, BlockScope scope) { this.currentWildcard = null; } } public static final TypeReference baseTypeReference(int baseType, int dim, Annotation[][] dimAnnotations) { if (dim == 0) { switch (baseType) { case 6: return new SingleTypeReference(TypeBinding.VOID.simpleName, 0L);case 5: return new SingleTypeReference(TypeBinding.BOOLEAN.simpleName, 0L);case 2: return new SingleTypeReference(TypeBinding.CHAR.simpleName, 0L);case 9: return new SingleTypeReference(TypeBinding.FLOAT.simpleName, 0L);case 8: return new SingleTypeReference(TypeBinding.DOUBLE.simpleName, 0L);case 3: return new SingleTypeReference(TypeBinding.BYTE.simpleName, 0L);case 4: return new SingleTypeReference(TypeBinding.SHORT.simpleName, 0L);case 10: return new SingleTypeReference(TypeBinding.INT.simpleName, 0L); }  return new SingleTypeReference(TypeBinding.LONG.simpleName, 0L); }  switch (baseType) { case 6: return new ArrayTypeReference(TypeBinding.VOID.simpleName, dim, dimAnnotations, 0L);case 5: return new ArrayTypeReference(TypeBinding.BOOLEAN.simpleName, dim, dimAnnotations, 0L);case 2: return new ArrayTypeReference(TypeBinding.CHAR.simpleName, dim, dimAnnotations, 0L);case 9: return new ArrayTypeReference(TypeBinding.FLOAT.simpleName, dim, dimAnnotations, 0L);case 8: return new ArrayTypeReference(TypeBinding.DOUBLE.simpleName, dim, dimAnnotations, 0L);case 3: return new ArrayTypeReference(TypeBinding.BYTE.simpleName, dim, dimAnnotations, 0L);case 4: return new ArrayTypeReference(TypeBinding.SHORT.simpleName, dim, dimAnnotations, 0L);case 10: return new ArrayTypeReference(TypeBinding.INT.simpleName, dim, dimAnnotations, 0L); }  return new ArrayTypeReference(TypeBinding.LONG.simpleName, dim, dimAnnotations, 0L); } public static final TypeReference baseTypeReference(int baseType, int dim) { return baseTypeReference(baseType, dim, (Annotation[][])null); } protected Annotation[][] getMergedAnnotationsOnDimensions(int additionalDimensions, Annotation[][] additionalAnnotations) { Annotation[][] annotationsOnDimensions = getAnnotationsOnDimensions(true);
/* 379 */     int dimensions = dimensions();
/*     */     
/* 381 */     if (annotationsOnDimensions == null && additionalAnnotations == null) {
/* 382 */       return null;
/*     */     }
/* 384 */     int totalDimensions = dimensions + additionalDimensions;
/* 385 */     Annotation[][] mergedAnnotations = new Annotation[totalDimensions][];
/* 386 */     if (annotationsOnDimensions != null) {
/* 387 */       System.arraycopy(annotationsOnDimensions, 0, mergedAnnotations, 0, dimensions);
/*     */     }
/* 389 */     if (additionalAnnotations != null) {
/* 390 */       for (int i = dimensions, j = 0; i < totalDimensions; i++, j++) {
/* 391 */         mergedAnnotations[i] = additionalAnnotations[j];
/*     */       }
/*     */     }
/* 394 */     return mergedAnnotations; }
/*     */    public void aboutToResolve(Scope scope) {} public void checkBounds(Scope scope) {}
/*     */   public abstract TypeReference augmentTypeWithAdditionalDimensions(int paramInt, Annotation[][] paramArrayOfAnnotation, boolean paramBoolean);
/*     */   public int dimensions() {
/* 398 */     return 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int extraDimensions() {
/* 411 */     return 0;
/*     */   }
/*     */   
/*     */   public AnnotationContext[] getAllAnnotationContexts(int targetType) {
/* 415 */     List<AnnotationContext> allAnnotationContexts = new ArrayList<>();
/* 416 */     AnnotationCollector collector = new AnnotationCollector(this, targetType, allAnnotationContexts);
/* 417 */     traverse(collector, (BlockScope)null);
/* 418 */     return allAnnotationContexts.<AnnotationContext>toArray(new AnnotationContext[allAnnotationContexts.size()]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void getAllAnnotationContexts(int targetType, int info, List<AnnotationContext> allAnnotationContexts) {
/* 427 */     AnnotationCollector collector = new AnnotationCollector(this, targetType, info, allAnnotationContexts);
/* 428 */     traverse(collector, (BlockScope)null);
/*     */   }
/*     */   public void getAllAnnotationContexts(int targetType, int info, List<AnnotationContext> allAnnotationContexts, Annotation[] se7Annotations) {
/* 431 */     AnnotationCollector collector = new AnnotationCollector(this, targetType, info, allAnnotationContexts);
/* 432 */     for (int i = 0, length = (se7Annotations == null) ? 0 : se7Annotations.length; i < length; i++) {
/* 433 */       Annotation annotation = se7Annotations[i];
/* 434 */       annotation.traverse(collector, (BlockScope)null);
/*     */     } 
/* 436 */     traverse(collector, (BlockScope)null);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void getAllAnnotationContexts(int targetType, int info, List<AnnotationContext> allAnnotationContexts, Annotation[][] annotationsOnDimensions, int dimensions) {
/* 442 */     AnnotationCollector collector = new AnnotationCollector(this, targetType, info, allAnnotationContexts, annotationsOnDimensions, dimensions);
/* 443 */     traverse(collector, (BlockScope)null);
/* 444 */     if (annotationsOnDimensions != null)
/* 445 */       for (int i = 0, max = annotationsOnDimensions.length; i < max; i++) {
/* 446 */         Annotation[] annotationsOnDimension = annotationsOnDimensions[i];
/* 447 */         if (annotationsOnDimension != null) {
/* 448 */           for (int j = 0, max2 = annotationsOnDimension.length; j < max2; j++) {
/* 449 */             annotationsOnDimension[j].traverse(collector, (BlockScope)null);
/*     */           }
/*     */         }
/*     */       }  
/*     */   }
/*     */   
/*     */   public void getAllAnnotationContexts(int targetType, int info, int typeIndex, List<AnnotationContext> allAnnotationContexts) {
/* 456 */     AnnotationCollector collector = new AnnotationCollector(this, targetType, info, typeIndex, allAnnotationContexts);
/* 457 */     traverse(collector, (BlockScope)null);
/*     */   }
/*     */   public void getAllAnnotationContexts(int targetType, List<AnnotationContext> allAnnotationContexts) {
/* 460 */     AnnotationCollector collector = new AnnotationCollector(this, targetType, allAnnotationContexts);
/* 461 */     traverse(collector, (BlockScope)null);
/*     */   }
/*     */   public Annotation[][] getAnnotationsOnDimensions() {
/* 464 */     return getAnnotationsOnDimensions(false);
/*     */   }
/*     */   
/*     */   public TypeReference[][] getTypeArguments() {
/* 468 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Annotation[][] getAnnotationsOnDimensions(boolean useSourceOrder) {
/* 480 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAnnotationsOnDimensions(Annotation[][] annotationsOnDimensions) {}
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract char[] getLastToken();
/*     */ 
/*     */ 
/*     */   
/*     */   public char[][] getParameterizedTypeName() {
/* 494 */     return getTypeName();
/*     */   }
/*     */ 
/*     */   
/*     */   protected abstract TypeBinding getTypeBinding(Scope paramScope);
/*     */ 
/*     */   
/*     */   public abstract char[][] getTypeName();
/*     */   
/*     */   protected TypeBinding internalResolveType(Scope scope, int location) {
/* 504 */     this.constant = Constant.NotAConstant;
/* 505 */     if (this.resolvedType != null) {
/* 506 */       TypeBinding typeBinding; if (this.resolvedType.isValidBinding()) {
/* 507 */         return this.resolvedType;
/*     */       }
/* 509 */       switch (this.resolvedType.problemId()) {
/*     */         case 1:
/*     */         case 2:
/*     */         case 5:
/* 513 */           typeBinding = this.resolvedType.closestMatch();
/* 514 */           if (typeBinding == null) return null; 
/* 515 */           return scope.environment().convertToRawType(typeBinding, false);
/*     */       } 
/* 517 */       return null;
/*     */     } 
/*     */ 
/*     */     
/* 521 */     boolean hasError = false;
/* 522 */     TypeBinding type = this.resolvedType = getTypeBinding(scope);
/* 523 */     if (type == null)
/* 524 */       return null; 
/* 525 */     if (hasError = !type.isValidBinding()) {
/* 526 */       if (isTypeNameVar(scope)) {
/* 527 */         reportVarIsNotAllowedHere(scope);
/* 528 */       } else if (!scope.problemReporter().validateRestrictedKeywords(getLastToken(), this)) {
/* 529 */         reportInvalidType(scope);
/*     */       } 
/* 531 */       switch (type.problemId()) {
/*     */         case 1:
/*     */         case 2:
/*     */         case 5:
/* 535 */           type = type.closestMatch();
/* 536 */           if (type == null) return null; 
/*     */           break;
/*     */         default:
/* 539 */           return null;
/*     */       } 
/*     */     } else {
/* 542 */       scope.problemReporter().validateRestrictedKeywords(getLastToken(), this);
/*     */     } 
/* 544 */     if (type.isArrayType() && ((ArrayBinding)type).leafComponentType == TypeBinding.VOID) {
/* 545 */       scope.problemReporter().cannotAllocateVoidArray(this);
/* 546 */       return null;
/*     */     } 
/* 548 */     if (!(this instanceof QualifiedTypeReference) && 
/* 549 */       isTypeUseDeprecated(type, scope)) {
/* 550 */       reportDeprecatedType(type, scope);
/*     */     }
/* 552 */     type = scope.environment().convertToRawType(type, false);
/* 553 */     if (type.leafComponentType().isRawType() && (
/* 554 */       this.bits & 0x40000000) == 0 && 
/* 555 */       scope.compilerOptions().getSeverity(536936448) != 256) {
/* 556 */       scope.problemReporter().rawTypeReference(this, type);
/*     */     }
/* 558 */     if (hasError) {
/* 559 */       resolveAnnotations(scope, 0);
/* 560 */       return type;
/*     */     } 
/*     */     
/* 563 */     this.resolvedType = type;
/* 564 */     resolveAnnotations(scope, location);
/* 565 */     return this.resolvedType;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isTypeReference() {
/* 570 */     return true;
/*     */   }
/*     */   public boolean isWildcard() {
/* 573 */     return false;
/*     */   }
/*     */   public boolean isUnionType() {
/* 576 */     return false;
/*     */   }
/*     */   public boolean isVarargs() {
/* 579 */     return ((this.bits & 0x4000) != 0);
/*     */   }
/*     */   public boolean isParameterizedTypeReference() {
/* 582 */     return false;
/*     */   }
/*     */   protected void reportDeprecatedType(TypeBinding type, Scope scope, int index) {
/* 585 */     scope.problemReporter().deprecatedType(type, this, index);
/*     */   }
/*     */   
/*     */   protected void reportDeprecatedType(TypeBinding type, Scope scope) {
/* 589 */     scope.problemReporter().deprecatedType(type, this, 2147483647);
/*     */   }
/*     */   
/*     */   protected void reportInvalidType(Scope scope) {
/* 593 */     scope.problemReporter().invalidType(this, this.resolvedType);
/*     */   }
/*     */   
/*     */   protected void reportVarIsNotAllowedHere(Scope scope) {
/* 597 */     scope.problemReporter().varIsNotAllowedHere(this);
/*     */   }
/*     */ 
/*     */   
/*     */   public TypeBinding resolveSuperType(ClassScope scope) {
/* 602 */     TypeBinding superType = resolveType(scope);
/* 603 */     if (superType == null) return null;
/*     */     
/* 605 */     if (superType.isTypeVariable()) {
/* 606 */       if (this.resolvedType.isValidBinding()) {
/* 607 */         this.resolvedType = (TypeBinding)new ProblemReferenceBinding(getTypeName(), (ReferenceBinding)this.resolvedType, 9);
/* 608 */         reportInvalidType((Scope)scope);
/*     */       } 
/* 610 */       return null;
/*     */     } 
/* 612 */     return superType;
/*     */   }
/*     */ 
/*     */   
/*     */   public final TypeBinding resolveType(BlockScope blockScope) {
/* 617 */     return resolveType(blockScope, true);
/*     */   }
/*     */   
/*     */   public TypeBinding resolveType(BlockScope scope, boolean checkBounds) {
/* 621 */     return resolveType(scope, checkBounds, 0);
/*     */   }
/*     */   
/*     */   public TypeBinding resolveType(BlockScope scope, boolean checkBounds, int location) {
/* 625 */     return internalResolveType((Scope)scope, location);
/*     */   }
/*     */ 
/*     */   
/*     */   public TypeBinding resolveType(ClassScope scope) {
/* 630 */     return resolveType(scope, 0);
/*     */   }
/*     */   
/*     */   public TypeBinding resolveType(ClassScope scope, int location) {
/* 634 */     return internalResolveType((Scope)scope, location);
/*     */   }
/*     */   
/*     */   public TypeBinding resolveTypeArgument(BlockScope blockScope, ReferenceBinding genericType, int rank) {
/* 638 */     return resolveType(blockScope, true, 64);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TypeBinding resolveTypeArgument(ClassScope classScope, ReferenceBinding genericType, int rank) {
/* 645 */     SourceTypeBinding sourceTypeBinding = classScope.referenceContext.binding;
/* 646 */     boolean pauseHierarchyCheck = false;
/*     */     try {
/* 648 */       if (sourceTypeBinding.isHierarchyBeingConnected()) {
/* 649 */         pauseHierarchyCheck = ((((ReferenceBinding)sourceTypeBinding).tagBits & 0x80000L) == 0L);
/* 650 */         ((ReferenceBinding)sourceTypeBinding).tagBits |= 0x80000L;
/*     */       } 
/* 652 */       return resolveType(classScope, 64);
/*     */     } finally {
/* 654 */       if (pauseHierarchyCheck) {
/* 655 */         ((ReferenceBinding)sourceTypeBinding).tagBits &= 0xFFFFFFFFFFF7FFFFL;
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public abstract void traverse(ASTVisitor paramASTVisitor, BlockScope paramBlockScope);
/*     */ 
/*     */   
/*     */   public abstract void traverse(ASTVisitor paramASTVisitor, ClassScope paramClassScope);
/*     */   
/*     */   protected void resolveAnnotations(Scope scope, int location) {
/* 667 */     Annotation[][] annotationsOnDimensions = getAnnotationsOnDimensions();
/* 668 */     if (this.annotations != null || annotationsOnDimensions != null) {
/* 669 */       BlockScope resolutionScope = Scope.typeAnnotationsResolutionScope(scope);
/* 670 */       if (resolutionScope != null) {
/* 671 */         int dimensions = dimensions();
/* 672 */         if (this.annotations != null) {
/* 673 */           TypeBinding leafComponentType = this.resolvedType.leafComponentType();
/* 674 */           leafComponentType = resolveAnnotations(resolutionScope, this.annotations, leafComponentType);
/* 675 */           this.resolvedType = (dimensions > 0) ? (TypeBinding)scope.environment().createArrayType(leafComponentType, dimensions) : leafComponentType;
/*     */         } 
/*     */         
/* 678 */         if (annotationsOnDimensions != null) {
/* 679 */           this.resolvedType = resolveAnnotations(resolutionScope, annotationsOnDimensions, this.resolvedType);
/* 680 */           if (this.resolvedType instanceof ArrayBinding) {
/* 681 */             long[] nullTagBitsPerDimension = ((ArrayBinding)this.resolvedType).nullTagBitsPerDimension;
/* 682 */             if (nullTagBitsPerDimension != null) {
/* 683 */               for (int i = 0; i < dimensions; i++) {
/* 684 */                 long nullTagBits = nullTagBitsPerDimension[i] & 0x180000000000000L;
/* 685 */                 if (nullTagBits == 108086391056891904L) {
/* 686 */                   scope.problemReporter().contradictoryNullAnnotations(annotationsOnDimensions[i]);
/* 687 */                   nullTagBitsPerDimension[i] = 0L;
/* 688 */                 } else if (nullTagBits == 72057594037927936L && 
/* 689 */                   scope.hasDefaultNullnessFor(512, this.sourceStart)) {
/* 690 */                   scope.problemReporter().nullAnnotationIsRedundant(this, annotationsOnDimensions[i]);
/*     */                 } 
/*     */               } 
/*     */             }
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/* 698 */     if ((scope.compilerOptions()).isAnnotationBasedNullAnalysisEnabled && 
/* 699 */       this.resolvedType != null && 
/* 700 */       !this.resolvedType.isTypeVariable() && 
/* 701 */       !this.resolvedType.isWildcard() && 
/* 702 */       location != 0 && 
/* 703 */       scope.hasDefaultNullnessForType(this.resolvedType, location, this.sourceStart)) {
/*     */       
/* 705 */       long nullTagBits = this.resolvedType.tagBits & 0x180000000000000L;
/* 706 */       if (nullTagBits == 0L) {
/* 707 */         if (location == 256 && this.resolvedType.id == 1) {
/* 708 */           scope.problemReporter().implicitObjectBoundNoNullDefault(this);
/*     */         } else {
/* 710 */           LookupEnvironment environment = scope.environment();
/* 711 */           AnnotationBinding[] annots = { environment.getNonNullAnnotation() };
/* 712 */           this.resolvedType = environment.createAnnotatedType(this.resolvedType, annots);
/*     */         } 
/* 714 */       } else if (nullTagBits == 72057594037927936L && 
/* 715 */         location != 8) {
/* 716 */         scope.problemReporter().nullAnnotationIsRedundant(this, getTopAnnotations());
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   public Annotation[] getTopAnnotations() {
/* 722 */     if (this.annotations != null)
/* 723 */       return this.annotations[getAnnotatableLevels() - 1]; 
/* 724 */     return new Annotation[0];
/*     */   }
/*     */   
/*     */   public int getAnnotatableLevels() {
/* 728 */     return 1;
/*     */   }
/*     */   
/*     */   protected void checkIllegalNullAnnotations(Scope scope, TypeReference[] typeArguments) {
/* 732 */     if (scope.environment().usesNullTypeAnnotations() && typeArguments != null)
/* 733 */       for (int i = 0; i < typeArguments.length; i++) {
/* 734 */         TypeReference arg = typeArguments[i];
/* 735 */         if (arg.resolvedType != null) {
/* 736 */           arg.checkIllegalNullAnnotation(scope);
/*     */         }
/*     */       }  
/*     */   }
/*     */   
/*     */   protected void checkNullConstraints(Scope scope, Substitution substitution, TypeBinding[] variables, int rank) {
/* 742 */     if (variables != null && variables.length > rank) {
/* 743 */       TypeBinding variable = variables[rank];
/* 744 */       if (variable.hasNullTypeAnnotations() && 
/* 745 */         NullAnnotationMatching.analyse(variable, this.resolvedType, null, substitution, -1, null, NullAnnotationMatching.CheckMode.BOUND_CHECK).isAnyMismatch()) {
/* 746 */         scope.problemReporter().nullityMismatchTypeArgument(variable, this.resolvedType, this);
/*     */       }
/*     */     } 
/* 749 */     checkIllegalNullAnnotation(scope);
/*     */   }
/*     */   protected void checkIllegalNullAnnotation(Scope scope) {
/* 752 */     if (this.resolvedType.leafComponentType().isBaseType() && hasNullTypeAnnotation(AnnotationPosition.LEAF_TYPE))
/* 753 */       scope.problemReporter().illegalAnnotationForBaseType(this, this.annotations[0], this.resolvedType.tagBits & 0x180000000000000L); 
/*     */   }
/*     */   
/*     */   public Annotation findAnnotation(long nullTagBits) {
/* 757 */     if (this.annotations != null) {
/* 758 */       Annotation[] innerAnnotations = this.annotations[this.annotations.length - 1];
/* 759 */       if (innerAnnotations != null) {
/* 760 */         int annBit = (nullTagBits == 72057594037927936L) ? 32 : 64;
/* 761 */         for (int i = 0; i < innerAnnotations.length; i++) {
/* 762 */           if (innerAnnotations[i] != null && innerAnnotations[i].hasNullBit(annBit))
/* 763 */             return innerAnnotations[i]; 
/*     */         } 
/*     */       } 
/*     */     } 
/* 767 */     return null;
/*     */   }
/*     */   public boolean hasNullTypeAnnotation(AnnotationPosition position) {
/* 770 */     if (this.annotations != null) {
/* 771 */       if (position == AnnotationPosition.MAIN_TYPE) {
/* 772 */         Annotation[] innerAnnotations = this.annotations[this.annotations.length - 1];
/* 773 */         return containsNullAnnotation(innerAnnotations);
/*     */       }  byte b; int i; Annotation[][] arrayOfAnnotation;
/* 775 */       for (i = (arrayOfAnnotation = this.annotations).length, b = 0; b < i; ) { Annotation[] someAnnotations = arrayOfAnnotation[b];
/* 776 */         if (containsNullAnnotation(someAnnotations))
/* 777 */           return true; 
/*     */         b++; }
/*     */     
/*     */     } 
/* 781 */     return false;
/*     */   }
/*     */   public static boolean containsNullAnnotation(Annotation[] annotations) {
/* 784 */     if (annotations != null)
/* 785 */       for (int i = 0; i < annotations.length; i++) {
/* 786 */         if (annotations[i] != null && annotations[i].hasNullBit(96)) {
/* 787 */           return true;
/*     */         }
/*     */       }  
/* 790 */     return false;
/*     */   }
/*     */   public TypeReference[] getTypeReferences() {
/* 793 */     return new TypeReference[] { this };
/*     */   }
/*     */   
/*     */   public boolean isBaseTypeReference() {
/* 797 */     return false;
/*     */   }
/*     */   private char[] getTypeName(int index) {
/* 800 */     char[][] typeName = getTypeName();
/* 801 */     return (typeName != null && typeName.length > index) ? typeName[index] : 
/* 802 */       CharOperation.NO_CHAR;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isTypeNameVar(Scope scope) {
/* 810 */     CompilerOptions compilerOptions = (scope != null) ? scope.compilerOptions() : null;
/* 811 */     if (compilerOptions != null && compilerOptions.sourceLevel < 3538944L) {
/* 812 */       return false;
/*     */     }
/* 814 */     return CharOperation.equals(getTypeName(0), TypeConstants.VAR);
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\ast\TypeReference.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */