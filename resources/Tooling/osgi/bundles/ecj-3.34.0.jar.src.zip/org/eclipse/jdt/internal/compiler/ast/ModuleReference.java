/*    */ package org.eclipse.jdt.internal.compiler.ast;
/*    */ 
/*    */ import org.eclipse.jdt.core.compiler.CharOperation;
/*    */ import org.eclipse.jdt.internal.compiler.lookup.ModuleBinding;
/*    */ import org.eclipse.jdt.internal.compiler.lookup.Scope;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ModuleReference
/*    */   extends ASTNode
/*    */ {
/*    */   public char[][] tokens;
/*    */   public long[] sourcePositions;
/*    */   public char[] moduleName;
/* 25 */   public ModuleBinding binding = null;
/*    */   
/*    */   public ModuleReference(char[][] tokens, long[] sourcePositions) {
/* 28 */     this.tokens = tokens;
/* 29 */     this.sourcePositions = sourcePositions;
/* 30 */     this.sourceEnd = (int)(sourcePositions[sourcePositions.length - 1] & 0xFFFFFFFFFFFFFFFFL);
/* 31 */     this.sourceStart = (int)(sourcePositions[0] >>> 32L);
/* 32 */     this.moduleName = CharOperation.concatWith(tokens, '.');
/*    */   }
/*    */ 
/*    */   
/*    */   public StringBuffer print(int indent, StringBuffer output) {
/* 37 */     for (int i = 0; i < this.tokens.length; i++) {
/* 38 */       if (i > 0) output.append('.'); 
/* 39 */       output.append(this.tokens[i]);
/*    */     } 
/* 41 */     return output;
/*    */   }
/*    */   
/*    */   public ModuleBinding resolve(Scope scope) {
/* 45 */     if (scope == null || this.binding != null)
/* 46 */       return this.binding; 
/* 47 */     return this.binding = scope.environment().getModule(this.moduleName);
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\ast\ModuleReference.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */