package org.eclipse.jdt.internal.compiler.lookup;

import org.eclipse.jdt.internal.compiler.env.IBinaryField;

abstract class VariableBindingInitialization<X extends VariableBinding> {
  abstract void setEmptyResult(BinaryTypeBinding paramBinaryTypeBinding);
  
  abstract X createBinding(BinaryTypeBinding paramBinaryTypeBinding, IBinaryField paramIBinaryField, TypeBinding paramTypeBinding);
  
  abstract X[] createResultArray(int paramInt);
  
  abstract void set(BinaryTypeBinding paramBinaryTypeBinding, X[] paramArrayOfX);
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\lookup\BinaryTypeBinding$VariableBindingInitialization.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */