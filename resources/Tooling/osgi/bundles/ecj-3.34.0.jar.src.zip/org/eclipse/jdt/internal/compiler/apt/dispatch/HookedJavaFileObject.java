/*     */ package org.eclipse.jdt.internal.compiler.apt.dispatch;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ import java.io.Writer;
/*     */ import javax.tools.ForwardingJavaFileObject;
/*     */ import javax.tools.JavaFileObject;
/*     */ import org.eclipse.jdt.core.compiler.CharOperation;
/*     */ import org.eclipse.jdt.internal.compiler.batch.CompilationUnit;
/*     */ import org.eclipse.jdt.internal.compiler.classfmt.ClassFileReader;
/*     */ import org.eclipse.jdt.internal.compiler.classfmt.ClassFormatException;
/*     */ import org.eclipse.jdt.internal.compiler.env.IBinaryType;
/*     */ import org.eclipse.jdt.internal.compiler.env.ICompilationUnit;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.BinaryTypeBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.ReferenceBinding;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class HookedJavaFileObject
/*     */   extends ForwardingJavaFileObject<JavaFileObject>
/*     */ {
/*     */   protected final BatchFilerImpl _filer;
/*     */   protected final String _fileName;
/*     */   
/*     */   private class ForwardingWriter
/*     */     extends Writer
/*     */   {
/*     */     private final Writer _w;
/*     */     
/*     */     ForwardingWriter(Writer w) {
/*  46 */       this._w = w;
/*     */     }
/*     */     
/*     */     public Writer append(char c) throws IOException {
/*  50 */       return this._w.append(c);
/*     */     }
/*     */ 
/*     */     
/*     */     public Writer append(CharSequence csq, int start, int end) throws IOException {
/*  55 */       return this._w.append(csq, start, end);
/*     */     }
/*     */     
/*     */     public Writer append(CharSequence csq) throws IOException {
/*  59 */       return this._w.append(csq);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void close() throws IOException {
/*  65 */       this._w.close();
/*  66 */       HookedJavaFileObject.this.closed();
/*     */     }
/*     */     
/*     */     public void flush() throws IOException {
/*  70 */       this._w.flush();
/*     */     }
/*     */     
/*     */     public void write(char[] cbuf) throws IOException {
/*  74 */       this._w.write(cbuf);
/*     */     }
/*     */     
/*     */     public void write(int c) throws IOException {
/*  78 */       this._w.write(c);
/*     */     }
/*     */ 
/*     */     
/*     */     public void write(String str, int off, int len) throws IOException {
/*  83 */       this._w.write(str, off, len);
/*     */     }
/*     */     
/*     */     public void write(String str) throws IOException {
/*  87 */       this._w.write(str);
/*     */     }
/*     */ 
/*     */     
/*     */     public void write(char[] cbuf, int off, int len) throws IOException {
/*  92 */       this._w.write(cbuf, off, len);
/*     */     }
/*     */     
/*     */     protected Object clone() throws CloneNotSupportedException {
/*  96 */       return new ForwardingWriter(this._w);
/*     */     }
/*     */     
/*     */     public int hashCode() {
/* 100 */       return this._w.hashCode();
/*     */     }
/*     */     
/*     */     public boolean equals(Object obj) {
/* 104 */       if (this == obj)
/* 105 */         return true; 
/* 106 */       if (obj == null)
/* 107 */         return false; 
/* 108 */       if (getClass() != obj.getClass())
/* 109 */         return false; 
/* 110 */       ForwardingWriter other = (ForwardingWriter)obj;
/* 111 */       if (this._w == null) {
/* 112 */         if (other._w != null)
/* 113 */           return false; 
/* 114 */       } else if (!this._w.equals(other._w)) {
/* 115 */         return false;
/* 116 */       }  return true;
/*     */     }
/*     */     
/*     */     public String toString() {
/* 120 */       return "ForwardingWriter wrapping " + this._w.toString();
/*     */     }
/*     */   }
/*     */   
/*     */   private class ForwardingOutputStream
/*     */     extends OutputStream
/*     */   {
/*     */     private final OutputStream _os;
/*     */     
/*     */     ForwardingOutputStream(OutputStream os) {
/* 130 */       this._os = os;
/*     */     }
/*     */ 
/*     */     
/*     */     public void close() throws IOException {
/* 135 */       this._os.close();
/* 136 */       HookedJavaFileObject.this.closed();
/*     */     }
/*     */     
/*     */     public void flush() throws IOException {
/* 140 */       this._os.flush();
/*     */     }
/*     */     
/*     */     public void write(byte[] b, int off, int len) throws IOException {
/* 144 */       this._os.write(b, off, len);
/*     */     }
/*     */     
/*     */     public void write(byte[] b) throws IOException {
/* 148 */       this._os.write(b);
/*     */     }
/*     */     
/*     */     public void write(int b) throws IOException {
/* 152 */       this._os.write(b);
/*     */     }
/*     */     
/*     */     protected Object clone() throws CloneNotSupportedException {
/* 156 */       return new ForwardingOutputStream(this._os);
/*     */     }
/*     */     
/*     */     public int hashCode() {
/* 160 */       return this._os.hashCode();
/*     */     }
/*     */     
/*     */     public boolean equals(Object obj) {
/* 164 */       if (this == obj)
/* 165 */         return true; 
/* 166 */       if (obj == null)
/* 167 */         return false; 
/* 168 */       if (getClass() != obj.getClass())
/* 169 */         return false; 
/* 170 */       ForwardingOutputStream other = (ForwardingOutputStream)obj;
/* 171 */       if (this._os == null) {
/* 172 */         if (other._os != null)
/* 173 */           return false; 
/* 174 */       } else if (!this._os.equals(other._os)) {
/* 175 */         return false;
/* 176 */       }  return true;
/*     */     }
/*     */     
/*     */     public String toString() {
/* 180 */       return "ForwardingOutputStream wrapping " + this._os.toString();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean _closed = false;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String _typeName;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public HookedJavaFileObject(JavaFileObject fileObject, String fileName, String typeName, BatchFilerImpl filer) {
/* 206 */     super(fileObject);
/* 207 */     this._filer = filer;
/* 208 */     this._fileName = fileName;
/* 209 */     this._typeName = typeName;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public OutputStream openOutputStream() throws IOException {
/* 215 */     return new ForwardingOutputStream(super.openOutputStream());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Writer openWriter() throws IOException {
/* 221 */     return new ForwardingWriter(super.openWriter());
/*     */   }
/*     */   
/*     */   protected void closed() {
/* 225 */     if (!this._closed) {
/* 226 */       CompilationUnit unit; IBinaryType binaryType; ClassFileReader classFileReader; this._closed = true;
/*     */       
/* 228 */       switch (getKind()) {
/*     */         case SOURCE:
/* 230 */           unit = new CompilationUnit(null, this._fileName, null, null, this._filer._env.shouldIgnoreOptionalProblems(this._fileName.toCharArray()), null);
/* 231 */           this._filer.addNewUnit((ICompilationUnit)unit);
/*     */           break;
/*     */         case null:
/* 234 */           binaryType = null;
/*     */           try {
/* 236 */             classFileReader = ClassFileReader.read(this._fileName);
/* 237 */           } catch (ClassFormatException classFormatException) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */             
/* 243 */             ReferenceBinding type = this._filer._env._compiler.lookupEnvironment.getType(CharOperation.splitOn('.', this._typeName.toCharArray()));
/* 244 */             if (type != null)
/* 245 */               this._filer.addNewClassFile(type); 
/* 246 */           } catch (IOException iOException) {}
/*     */ 
/*     */           
/* 249 */           if (classFileReader != null) {
/* 250 */             char[] name = classFileReader.getName();
/* 251 */             ReferenceBinding type = this._filer._env._compiler.lookupEnvironment.getType(CharOperation.splitOn('/', name));
/* 252 */             if (type != null && type.isValidBinding()) {
/* 253 */               if (type.isBinaryBinding()) {
/* 254 */                 this._filer.addNewClassFile(type); break;
/*     */               } 
/* 256 */               BinaryTypeBinding binaryBinding = new BinaryTypeBinding(type.getPackage(), (IBinaryType)classFileReader, this._filer._env._compiler.lookupEnvironment, true);
/* 257 */               if (binaryBinding != null)
/* 258 */                 this._filer.addNewClassFile((ReferenceBinding)binaryBinding); 
/*     */             } 
/*     */           } 
/*     */           break;
/*     */       } 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\apt\dispatch\HookedJavaFileObject.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */