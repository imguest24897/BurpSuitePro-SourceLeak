/*     */ package org.eclipse.jdt.internal.compiler.apt.model;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.Writer;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.regex.Matcher;
/*     */ import java.util.regex.Pattern;
/*     */ import javax.lang.model.SourceVersion;
/*     */ import javax.lang.model.element.AnnotationMirror;
/*     */ import javax.lang.model.element.AnnotationValue;
/*     */ import javax.lang.model.element.Element;
/*     */ import javax.lang.model.element.ElementKind;
/*     */ import javax.lang.model.element.ExecutableElement;
/*     */ import javax.lang.model.element.ModuleElement;
/*     */ import javax.lang.model.element.Name;
/*     */ import javax.lang.model.element.PackageElement;
/*     */ import javax.lang.model.element.TypeElement;
/*     */ import javax.lang.model.util.Elements;
/*     */ import org.eclipse.jdt.core.compiler.CharOperation;
/*     */ import org.eclipse.jdt.internal.compiler.apt.dispatch.BaseProcessingEnvImpl;
/*     */ import org.eclipse.jdt.internal.compiler.ast.AbstractMethodDeclaration;
/*     */ import org.eclipse.jdt.internal.compiler.ast.FieldDeclaration;
/*     */ import org.eclipse.jdt.internal.compiler.ast.Javadoc;
/*     */ import org.eclipse.jdt.internal.compiler.ast.TypeDeclaration;
/*     */ import org.eclipse.jdt.internal.compiler.impl.ReferenceContext;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.AnnotationBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.Binding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.FieldBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.LocalVariableBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.LookupEnvironment;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.MethodBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.MethodVerifier;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.ModuleBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.PackageBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.ParameterizedTypeBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.ReferenceBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.Scope;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.SourceTypeBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.TypeConstants;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ElementsImpl
/*     */   implements Elements
/*     */ {
/*  75 */   private static final Pattern INITIAL_DELIMITER = Pattern.compile("^\\s*/\\*+");
/*     */ 
/*     */ 
/*     */   
/*     */   protected final BaseProcessingEnvImpl _env;
/*     */ 
/*     */ 
/*     */   
/*     */   protected ElementsImpl(BaseProcessingEnvImpl env) {
/*  84 */     this._env = env;
/*     */   }
/*     */   
/*     */   public static ElementsImpl create(BaseProcessingEnvImpl env) {
/*  88 */     return (SourceVersion.latest().compareTo(SourceVersion.RELEASE_8) <= 0) ? new ElementsImpl(env) : new ElementsImpl9(env);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<? extends AnnotationMirror> getAllAnnotationMirrors(Element e) {
/* 100 */     if (e.getKind() == ElementKind.CLASS && e instanceof TypeElementImpl) {
/* 101 */       List<AnnotationBinding> annotations = new ArrayList<>();
/*     */       
/* 103 */       Set<ReferenceBinding> annotationTypes = new HashSet<>();
/* 104 */       ReferenceBinding binding = (ReferenceBinding)((TypeElementImpl)e)._binding;
/* 105 */       boolean checkIfInherited = false;
/* 106 */       while (binding != null) {
/* 107 */         if (binding instanceof ParameterizedTypeBinding)
/* 108 */           binding = ((ParameterizedTypeBinding)binding).genericType();  byte b; int i;
/*     */         AnnotationBinding[] arrayOfAnnotationBinding;
/* 110 */         for (i = (arrayOfAnnotationBinding = Factory.getPackedAnnotationBindings(binding.getAnnotations())).length, b = 0; b < i; ) { AnnotationBinding annotation = arrayOfAnnotationBinding[b];
/* 111 */           if (annotation != null) {
/* 112 */             ReferenceBinding annotationType = annotation.getAnnotationType();
/* 113 */             if (!checkIfInherited || (annotationType.getAnnotationTagBits() & 0x1000000000000L) != 0L)
/*     */             {
/* 115 */               if (!annotationTypes.contains(annotationType)) {
/* 116 */                 annotationTypes.add(annotationType);
/* 117 */                 annotations.add(annotation);
/*     */               }  } 
/*     */           }  b++; }
/* 120 */          binding = binding.superclass();
/* 121 */         checkIfInherited = true;
/*     */       } 
/* 123 */       List<AnnotationMirror> list = new ArrayList<>(annotations.size());
/* 124 */       for (AnnotationBinding annotation : annotations) {
/* 125 */         list.add(this._env.getFactory().newAnnotationMirror(annotation));
/*     */       }
/* 127 */       return Collections.unmodifiableList(list);
/*     */     } 
/*     */     
/* 130 */     return e.getAnnotationMirrors();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<? extends Element> getAllMembers(TypeElement type) {
/* 154 */     if (type == null || !(type instanceof TypeElementImpl)) {
/* 155 */       return Collections.emptyList();
/*     */     }
/* 157 */     ReferenceBinding binding = (ReferenceBinding)((TypeElementImpl)type)._binding;
/*     */     
/* 159 */     Map<String, ReferenceBinding> types = new HashMap<>();
/*     */     
/* 161 */     List<FieldBinding> fields = new ArrayList<>();
/*     */     
/* 163 */     Map<String, Set<MethodBinding>> methods = new HashMap<>();
/* 164 */     Set<ReferenceBinding> superinterfaces = new LinkedHashSet<>();
/* 165 */     boolean ignoreVisibility = true;
/* 166 */     while (binding != null) {
/* 167 */       addMembers(binding, ignoreVisibility, types, fields, methods);
/* 168 */       Set<ReferenceBinding> newfound = new LinkedHashSet<>();
/* 169 */       collectSuperInterfaces(binding, superinterfaces, newfound);
/* 170 */       for (ReferenceBinding superinterface : newfound) {
/* 171 */         addMembers(superinterface, false, types, fields, methods);
/*     */       }
/* 173 */       superinterfaces.addAll(newfound);
/* 174 */       binding = binding.superclass();
/* 175 */       ignoreVisibility = false;
/*     */     } 
/* 177 */     List<Element> allMembers = new ArrayList<>();
/* 178 */     for (ReferenceBinding nestedType : types.values()) {
/* 179 */       allMembers.add(this._env.getFactory().newElement((Binding)nestedType));
/*     */     }
/* 181 */     for (FieldBinding field : fields) {
/* 182 */       allMembers.add(this._env.getFactory().newElement((Binding)field));
/*     */     }
/* 184 */     for (Set<MethodBinding> sameNamedMethods : methods.values()) {
/* 185 */       for (MethodBinding method : sameNamedMethods) {
/* 186 */         allMembers.add(this._env.getFactory().newElement((Binding)method));
/*     */       }
/*     */     } 
/* 189 */     return allMembers;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void collectSuperInterfaces(ReferenceBinding type, Set<ReferenceBinding> existing, Set<ReferenceBinding> newfound) {
/*     */     byte b;
/*     */     int i;
/*     */     ReferenceBinding[] arrayOfReferenceBinding;
/* 202 */     for (i = (arrayOfReferenceBinding = type.superInterfaces()).length, b = 0; b < i; ) { ReferenceBinding superinterface = arrayOfReferenceBinding[b];
/* 203 */       if (!existing.contains(superinterface) && !newfound.contains(superinterface)) {
/* 204 */         newfound.add(superinterface);
/* 205 */         collectSuperInterfaces(superinterface, existing, newfound);
/*     */       } 
/*     */       b++; }
/*     */   
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void addMembers(ReferenceBinding binding, boolean directMembers, Map<String, ReferenceBinding> types, List<FieldBinding> fields, Map<String, Set<MethodBinding>> methods) {
/*     */     byte b;
/*     */     int i;
/*     */     ReferenceBinding[] arrayOfReferenceBinding;
/* 224 */     for (i = (arrayOfReferenceBinding = binding.memberTypes()).length, b = 0; b < i; ) { ReferenceBinding subtype = arrayOfReferenceBinding[b];
/* 225 */       if (directMembers || !subtype.isPrivate()) {
/* 226 */         String name = new String(subtype.sourceName());
/* 227 */         if (types.get(name) == null)
/* 228 */           types.put(name, subtype); 
/*     */       }  b++; }
/*     */     
/*     */     FieldBinding[] arrayOfFieldBinding;
/* 232 */     for (i = (arrayOfFieldBinding = binding.fields()).length, b = 0; b < i; ) { FieldBinding field = arrayOfFieldBinding[b];
/* 233 */       if (directMembers || !field.isPrivate())
/* 234 */         fields.add(field);  b++; }
/*     */     
/*     */     MethodBinding[] arrayOfMethodBinding;
/* 237 */     for (i = (arrayOfMethodBinding = binding.methods()).length, b = 0; b < i; ) { MethodBinding method = arrayOfMethodBinding[b];
/* 238 */       if (directMembers || !method.isStatic())
/*     */       {
/* 240 */         if (!method.isSynthetic() && (directMembers || (!method.isPrivate() && !method.isConstructor()))) {
/* 241 */           String methodName = new String(method.selector);
/* 242 */           Set<MethodBinding> sameNamedMethods = methods.get(methodName);
/* 243 */           if (sameNamedMethods == null) {
/*     */ 
/*     */             
/* 246 */             sameNamedMethods = new HashSet<>(4);
/* 247 */             methods.put(methodName, sameNamedMethods);
/* 248 */             sameNamedMethods.add(method);
/*     */           }
/*     */           else {
/*     */             
/* 252 */             boolean unique = true;
/* 253 */             if (!directMembers) {
/* 254 */               for (MethodBinding existing : sameNamedMethods) {
/* 255 */                 MethodVerifier verifier = this._env.getLookupEnvironment().methodVerifier();
/* 256 */                 if (verifier.doesMethodOverride(existing, method)) {
/* 257 */                   unique = false;
/*     */                   break;
/*     */                 } 
/*     */               } 
/*     */             }
/* 262 */             if (unique) {
/* 263 */               sameNamedMethods.add(method);
/*     */             }
/*     */           } 
/*     */         } 
/*     */       }
/*     */       b++; }
/*     */   
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Name getBinaryName(TypeElement type) {
/* 275 */     TypeElementImpl typeElementImpl = (TypeElementImpl)type;
/* 276 */     ReferenceBinding referenceBinding = (ReferenceBinding)typeElementImpl._binding;
/* 277 */     return new NameImpl(
/* 278 */         CharOperation.replaceOnCopy(referenceBinding.constantPoolName(), '/', '.'));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getConstantExpression(Object value) {
/* 286 */     if (!(value instanceof Integer) && 
/* 287 */       !(value instanceof Byte) && 
/* 288 */       !(value instanceof Float) && 
/* 289 */       !(value instanceof Double) && 
/* 290 */       !(value instanceof Long) && 
/* 291 */       !(value instanceof Short) && 
/* 292 */       !(value instanceof Character) && 
/* 293 */       !(value instanceof String) && 
/* 294 */       !(value instanceof Boolean)) {
/* 295 */       throw new IllegalArgumentException("Not a valid wrapper type : " + value.getClass());
/*     */     }
/* 297 */     if (value instanceof Character) {
/* 298 */       StringBuilder builder = new StringBuilder();
/* 299 */       builder.append('\'').append(value).append('\'');
/* 300 */       return String.valueOf(builder);
/* 301 */     }  if (value instanceof String) {
/* 302 */       StringBuilder builder = new StringBuilder();
/* 303 */       builder.append('"').append(value).append('"');
/* 304 */       return String.valueOf(builder);
/* 305 */     }  if (value instanceof Float) {
/* 306 */       StringBuilder builder = new StringBuilder();
/* 307 */       builder.append(value).append('f');
/* 308 */       return String.valueOf(builder);
/* 309 */     }  if (value instanceof Long) {
/* 310 */       StringBuilder builder = new StringBuilder();
/* 311 */       builder.append(value).append('L');
/* 312 */       return String.valueOf(builder);
/* 313 */     }  if (value instanceof Short) {
/* 314 */       StringBuilder builder = new StringBuilder();
/* 315 */       builder.append("(short)").append(value);
/* 316 */       return String.valueOf(builder);
/* 317 */     }  if (value instanceof Byte) {
/* 318 */       StringBuilder builder = new StringBuilder();
/* 319 */       builder.append("(byte)0x");
/* 320 */       int intValue = ((Byte)value).byteValue();
/* 321 */       String hexString = Integer.toHexString(intValue & 0xFF);
/* 322 */       if (hexString.length() < 2) {
/* 323 */         builder.append('0');
/*     */       }
/* 325 */       builder.append(hexString);
/* 326 */       return String.valueOf(builder);
/*     */     } 
/* 328 */     return String.valueOf(value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getDocComment(Element e) {
/* 336 */     char[] unparsed = getUnparsedDocComment(e);
/* 337 */     return formatJavadoc(unparsed); } private char[] getUnparsedDocComment(Element e) { TypeDeclaration typeDeclaration; TypeElementImpl typeElementImpl; ReferenceBinding referenceBinding; PackageElementImpl packageElementImpl;
/*     */     PackageBinding packageBinding;
/*     */     char[][] compoundName;
/*     */     ReferenceBinding type;
/*     */     ExecutableElementImpl executableElementImpl;
/*     */     MethodBinding methodBinding;
/*     */     AbstractMethodDeclaration sourceMethod;
/*     */     VariableElementImpl variableElementImpl;
/*     */     FieldBinding fieldBinding;
/*     */     FieldDeclaration sourceField;
/* 347 */     Javadoc javadoc = null;
/* 348 */     ReferenceContext referenceContext = null;
/* 349 */     switch (e.getKind()) {
/*     */       case ENUM:
/*     */       case CLASS:
/*     */       case null:
/*     */       case INTERFACE:
/*     */       case RECORD:
/* 355 */         typeElementImpl = (TypeElementImpl)e;
/* 356 */         referenceBinding = (ReferenceBinding)typeElementImpl._binding;
/* 357 */         if (referenceBinding instanceof SourceTypeBinding) {
/* 358 */           SourceTypeBinding sourceTypeBinding = (SourceTypeBinding)referenceBinding;
/* 359 */           typeDeclaration = sourceTypeBinding.scope.referenceContext;
/* 360 */           javadoc = typeDeclaration.javadoc;
/*     */         } 
/*     */         break;
/*     */       
/*     */       case PACKAGE:
/* 365 */         packageElementImpl = (PackageElementImpl)e;
/* 366 */         packageBinding = (PackageBinding)packageElementImpl._binding;
/* 367 */         compoundName = CharOperation.arrayConcat(packageBinding.compoundName, TypeConstants.PACKAGE_INFO_NAME);
/* 368 */         type = this._env.getLookupEnvironment().getType(compoundName);
/* 369 */         if (type != null && type.isValidBinding() && type instanceof SourceTypeBinding) {
/* 370 */           SourceTypeBinding sourceTypeBinding = (SourceTypeBinding)type;
/* 371 */           typeDeclaration = sourceTypeBinding.scope.referenceContext;
/* 372 */           javadoc = typeDeclaration.javadoc;
/*     */         } 
/*     */         break;
/*     */       case METHOD:
/*     */       case CONSTRUCTOR:
/* 377 */         executableElementImpl = (ExecutableElementImpl)e;
/* 378 */         methodBinding = (MethodBinding)executableElementImpl._binding;
/* 379 */         sourceMethod = methodBinding.sourceMethod();
/* 380 */         if (sourceMethod != null) {
/* 381 */           javadoc = sourceMethod.javadoc;
/* 382 */           AbstractMethodDeclaration abstractMethodDeclaration = sourceMethod;
/*     */         } 
/*     */         break;
/*     */       case ENUM_CONSTANT:
/*     */       case FIELD:
/*     */       case RECORD_COMPONENT:
/* 388 */         variableElementImpl = (VariableElementImpl)e;
/* 389 */         fieldBinding = (FieldBinding)variableElementImpl._binding;
/* 390 */         sourceField = fieldBinding.sourceField();
/* 391 */         if (sourceField != null) {
/* 392 */           javadoc = sourceField.javadoc;
/* 393 */           if (fieldBinding.declaringClass instanceof SourceTypeBinding) {
/* 394 */             SourceTypeBinding sourceTypeBinding = (SourceTypeBinding)fieldBinding.declaringClass;
/* 395 */             typeDeclaration = sourceTypeBinding.scope.referenceContext;
/*     */           } 
/*     */         } 
/*     */         break;
/*     */       default:
/* 400 */         return null;
/*     */     } 
/* 402 */     if (javadoc != null && typeDeclaration != null) {
/* 403 */       char[] contents = typeDeclaration.compilationResult().getCompilationUnit().getContents();
/* 404 */       if (contents != null) {
/* 405 */         return CharOperation.subarray(contents, javadoc.sourceStart, javadoc.sourceEnd - 1);
/*     */       }
/*     */     } 
/* 408 */     return null; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static String formatJavadoc(char[] unparsed) {
/* 420 */     if (unparsed == null || unparsed.length < 5) {
/* 421 */       return null;
/*     */     }
/*     */     
/* 424 */     String[] lines = (new String(unparsed)).split("\n");
/* 425 */     Matcher delimiterMatcher = INITIAL_DELIMITER.matcher(lines[0]);
/* 426 */     if (!delimiterMatcher.find()) {
/* 427 */       return null;
/*     */     }
/* 429 */     int iOpener = delimiterMatcher.end();
/* 430 */     lines[0] = lines[0].substring(iOpener);
/* 431 */     if (lines.length == 1) {
/*     */ 
/*     */       
/* 434 */       StringBuilder stringBuilder = new StringBuilder();
/* 435 */       char[] chars = lines[0].toCharArray();
/* 436 */       boolean startingWhitespaces = true; byte b; int i; char[] arrayOfChar1;
/* 437 */       for (i = (arrayOfChar1 = chars).length, b = 0; b < i; ) { char c = arrayOfChar1[b];
/* 438 */         if (Character.isWhitespace(c)) {
/* 439 */           if (!startingWhitespaces)
/*     */           {
/*     */             
/* 442 */             stringBuilder.append(c); } 
/*     */         } else {
/* 444 */           startingWhitespaces = false;
/* 445 */           stringBuilder.append(c);
/*     */         }  b++; }
/*     */       
/* 448 */       return stringBuilder.toString();
/*     */     } 
/*     */ 
/*     */     
/* 452 */     int firstLine = (lines[0].trim().length() > 0) ? 0 : 1;
/*     */ 
/*     */     
/* 455 */     int lastLine = (lines[lines.length - 1].trim().length() > 0) ? (lines.length - 1) : (lines.length - 2);
/*     */     
/* 457 */     StringBuilder sb = new StringBuilder();
/* 458 */     if (lines[0].length() != 0 && firstLine == 1)
/*     */     {
/* 460 */       sb.append('\n');
/*     */     }
/* 462 */     boolean preserveLineSeparator = (lines[0].length() == 0);
/* 463 */     for (int line = firstLine; line <= lastLine; line++) {
/* 464 */       char[] chars = lines[line].toCharArray();
/* 465 */       int starsIndex = getStars(chars);
/* 466 */       int leadingWhitespaces = 0;
/* 467 */       boolean recordLeadingWhitespaces = true;
/* 468 */       for (int i = 0, max = chars.length; i < max; i++) {
/* 469 */         char c = chars[i];
/* 470 */         switch (c) {
/*     */           case ' ':
/* 472 */             if (starsIndex == -1) {
/* 473 */               if (recordLeadingWhitespaces) {
/* 474 */                 leadingWhitespaces++; break;
/*     */               } 
/* 476 */               sb.append(c); break;
/*     */             } 
/* 478 */             if (i >= starsIndex) {
/* 479 */               sb.append(c);
/*     */             }
/*     */             break;
/*     */           
/*     */           default:
/* 484 */             recordLeadingWhitespaces = false;
/* 485 */             if (leadingWhitespaces != 0) {
/* 486 */               int numberOfTabs = leadingWhitespaces / 8;
/* 487 */               if (numberOfTabs != 0) {
/* 488 */                 for (int j = 0, max2 = numberOfTabs; j < max2; j++) {
/* 489 */                   sb.append("        ");
/*     */                 }
/* 491 */                 if (leadingWhitespaces % 8 >= 1) {
/* 492 */                   sb.append(' ');
/*     */                 }
/* 494 */               } else if (line != 0) {
/*     */                 
/* 496 */                 for (int j = 0, max2 = leadingWhitespaces; j < max2; j++) {
/* 497 */                   sb.append(' ');
/*     */                 }
/*     */               } 
/* 500 */               leadingWhitespaces = 0;
/* 501 */               sb.append(c); break;
/* 502 */             }  if (c == '\t') {
/* 503 */               if (i >= starsIndex)
/* 504 */                 sb.append(c);  break;
/*     */             } 
/* 506 */             if (c != '*' || i > starsIndex) {
/* 507 */               sb.append(c);
/*     */             }
/*     */             break;
/*     */         } 
/*     */       
/*     */       } 
/* 513 */       int end = lines.length - 1;
/* 514 */       if (line < end) {
/* 515 */         sb.append('\n');
/* 516 */       } else if (preserveLineSeparator && line == end) {
/* 517 */         sb.append('\n');
/*     */       } 
/*     */     } 
/* 520 */     return sb.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static int getStars(char[] line) {
/* 530 */     for (int i = 0, max = line.length; i < max; i++) {
/* 531 */       char c = line[i];
/* 532 */       if (!Character.isWhitespace(c)) {
/* 533 */         if (c == '*') {
/*     */ 
/*     */           
/* 536 */           for (int j = i + 1; j < max; j++) {
/* 537 */             if (line[j] != '*') {
/* 538 */               return j;
/*     */             }
/*     */           } 
/* 541 */           return max - 1;
/*     */         } 
/*     */         
/*     */         break;
/*     */       } 
/*     */     } 
/* 547 */     return -1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<? extends ExecutableElement, ? extends AnnotationValue> getElementValuesWithDefaults(AnnotationMirror a) {
/* 559 */     return ((AnnotationMirrorImpl)a).getElementValuesWithDefaults();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Name getName(CharSequence cs) {
/* 567 */     return new NameImpl(cs);
/*     */   }
/*     */ 
/*     */   
/*     */   public PackageElement getPackageElement(CharSequence name) {
/* 572 */     LookupEnvironment le = this._env.getLookupEnvironment();
/* 573 */     if (name.length() == 0) {
/* 574 */       return (PackageElement)this._env.getFactory().newElement((Binding)le.defaultPackage);
/*     */     }
/* 576 */     char[] packageName = name.toString().toCharArray();
/* 577 */     PackageBinding packageBinding = le.createPackage(CharOperation.splitOn('.', packageName));
/* 578 */     if (packageBinding == null) {
/* 579 */       return null;
/*     */     }
/* 581 */     return (PackageElement)this._env.getFactory().newElement((Binding)packageBinding); } public PackageElement getPackageOf(Element type) { TypeElementImpl typeElementImpl; ReferenceBinding referenceBinding; ExecutableElementImpl executableElementImpl;
/*     */     MethodBinding methodBinding;
/*     */     VariableElementImpl variableElementImpl;
/*     */     FieldBinding fieldBinding;
/*     */     LocalVariableBinding localVariableBinding;
/* 586 */     switch (type.getKind()) {
/*     */       case ENUM:
/*     */       case CLASS:
/*     */       case null:
/*     */       case INTERFACE:
/*     */       case RECORD:
/* 592 */         typeElementImpl = (TypeElementImpl)type;
/* 593 */         referenceBinding = (ReferenceBinding)typeElementImpl._binding;
/* 594 */         return (PackageElement)this._env.getFactory().newElement((Binding)referenceBinding.fPackage);
/*     */       case PACKAGE:
/* 596 */         return (PackageElement)type;
/*     */       case METHOD:
/*     */       case CONSTRUCTOR:
/* 599 */         executableElementImpl = (ExecutableElementImpl)type;
/* 600 */         methodBinding = (MethodBinding)executableElementImpl._binding;
/* 601 */         return (PackageElement)this._env.getFactory().newElement((Binding)methodBinding.declaringClass.fPackage);
/*     */       case ENUM_CONSTANT:
/*     */       case FIELD:
/*     */       case RECORD_COMPONENT:
/* 605 */         variableElementImpl = (VariableElementImpl)type;
/* 606 */         fieldBinding = (FieldBinding)variableElementImpl._binding;
/* 607 */         return (PackageElement)this._env.getFactory().newElement((Binding)fieldBinding.declaringClass.fPackage);
/*     */       case PARAMETER:
/* 609 */         variableElementImpl = (VariableElementImpl)type;
/* 610 */         localVariableBinding = (LocalVariableBinding)variableElementImpl._binding;
/* 611 */         return (PackageElement)this._env.getFactory().newElement((Binding)(localVariableBinding.declaringScope.classScope()).referenceContext.binding.fPackage);
/*     */       case LOCAL_VARIABLE:
/*     */       case EXCEPTION_PARAMETER:
/*     */       case STATIC_INIT:
/*     */       case INSTANCE_INIT:
/*     */       case TYPE_PARAMETER:
/*     */       case OTHER:
/* 618 */         return null;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 623 */     return null; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TypeElement getTypeElement(CharSequence name) {
/* 631 */     LookupEnvironment le = this._env.getLookupEnvironment();
/* 632 */     char[][] compoundName = CharOperation.splitOn('.', name.toString().toCharArray());
/* 633 */     ReferenceBinding binding = le.getType(compoundName);
/*     */ 
/*     */     
/* 636 */     if (binding == null) {
/* 637 */       ReferenceBinding topLevelBinding = null;
/* 638 */       int topLevelSegments = compoundName.length;
/* 639 */       while (--topLevelSegments > 0) {
/* 640 */         char[][] topLevelName = new char[topLevelSegments][];
/* 641 */         for (int j = 0; j < topLevelSegments; j++) {
/* 642 */           topLevelName[j] = compoundName[j];
/*     */         }
/* 644 */         topLevelBinding = le.getType(topLevelName);
/* 645 */         if (topLevelBinding != null) {
/*     */           break;
/*     */         }
/*     */       } 
/* 649 */       if (topLevelBinding == null) {
/* 650 */         return null;
/*     */       }
/* 652 */       binding = topLevelBinding;
/* 653 */       for (int i = topLevelSegments; binding != null && i < compoundName.length; i++) {
/* 654 */         binding = binding.getMemberType(compoundName[i]);
/*     */       }
/*     */     } 
/* 657 */     if (binding == null) {
/* 658 */       return null;
/*     */     }
/* 660 */     if ((binding.tagBits & 0x80L) != 0L) {
/* 661 */       return null;
/*     */     }
/* 663 */     return new TypeElementImpl(this._env, binding, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean hides(Element hider, Element hidden) {
/* 674 */     if (hidden == null)
/*     */     {
/* 676 */       throw new NullPointerException();
/*     */     }
/* 678 */     return ((ElementImpl)hider).hides(hidden);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isDeprecated(Element e) {
/* 686 */     if (!(e instanceof ElementImpl)) {
/* 687 */       return false;
/*     */     }
/* 689 */     return ((((ElementImpl)e)._binding.getAnnotationTagBits() & 0x400000000000L) != 0L);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean overrides(ExecutableElement overrider, ExecutableElement overridden, TypeElement type) {
/* 699 */     if (overridden == null || type == null) {
/* 700 */       throw new NullPointerException();
/*     */     }
/* 702 */     return ((ExecutableElementImpl)overrider).overrides(overridden, type);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void printElements(Writer w, Element... elements) {
/* 710 */     String lineSeparator = System.getProperty("line.separator"); byte b; int i; Element[] arrayOfElement;
/* 711 */     for (i = (arrayOfElement = elements).length, b = 0; b < i; ) { Element element = arrayOfElement[b];
/*     */       try {
/* 713 */         w.write(element.toString());
/* 714 */         w.write(lineSeparator);
/* 715 */       } catch (IOException iOException) {}
/*     */       
/*     */       b++; }
/*     */     
/*     */     try {
/* 720 */       w.flush();
/* 721 */     } catch (IOException iOException) {}
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isFunctionalInterface(TypeElement type) {
/* 728 */     if (type != null && type.getKind() == ElementKind.INTERFACE) {
/* 729 */       ReferenceBinding binding = (ReferenceBinding)((TypeElementImpl)type)._binding;
/* 730 */       if (binding instanceof SourceTypeBinding) {
/* 731 */         return binding.isFunctionalInterface((Scope)((SourceTypeBinding)binding).scope);
/*     */       }
/*     */     } 
/* 734 */     return false;
/*     */   }
/*     */   
/*     */   public boolean isAutomaticModule(ModuleElement module) {
/* 738 */     ModuleBinding binding = ((ModuleElementImpl)module).binding;
/* 739 */     return (binding != null) ? binding.isAutomatic() : false;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\apt\model\ElementsImpl.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */