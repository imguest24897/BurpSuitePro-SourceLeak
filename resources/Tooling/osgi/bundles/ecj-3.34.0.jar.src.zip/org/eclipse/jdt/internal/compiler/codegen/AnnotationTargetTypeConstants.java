package org.eclipse.jdt.internal.compiler.codegen;

public interface AnnotationTargetTypeConstants {
  public static final int CLASS_TYPE_PARAMETER = 0;
  
  public static final int METHOD_TYPE_PARAMETER = 1;
  
  public static final int CLASS_EXTENDS = 16;
  
  public static final int CLASS_TYPE_PARAMETER_BOUND = 17;
  
  public static final int METHOD_TYPE_PARAMETER_BOUND = 18;
  
  public static final int FIELD = 19;
  
  public static final int RECORD_COMPONENT = 19;
  
  public static final int METHOD_RETURN = 20;
  
  public static final int METHOD_RECEIVER = 21;
  
  public static final int METHOD_FORMAL_PARAMETER = 22;
  
  public static final int THROWS = 23;
  
  public static final int LOCAL_VARIABLE = 64;
  
  public static final int RESOURCE_VARIABLE = 65;
  
  public static final int EXCEPTION_PARAMETER = 66;
  
  public static final int INSTANCEOF = 67;
  
  public static final int NEW = 68;
  
  public static final int CONSTRUCTOR_REFERENCE = 69;
  
  public static final int METHOD_REFERENCE = 70;
  
  public static final int CAST = 71;
  
  public static final int CONSTRUCTOR_INVOCATION_TYPE_ARGUMENT = 72;
  
  public static final int METHOD_INVOCATION_TYPE_ARGUMENT = 73;
  
  public static final int CONSTRUCTOR_REFERENCE_TYPE_ARGUMENT = 74;
  
  public static final int METHOD_REFERENCE_TYPE_ARGUMENT = 75;
  
  public static final int NEXT_ARRAY_DIMENSION = 0;
  
  public static final int NEXT_NESTED_TYPE = 1;
  
  public static final int WILDCARD_BOUND = 2;
  
  public static final int TYPE_ARGUMENT = 3;
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\codegen\AnnotationTargetTypeConstants.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */