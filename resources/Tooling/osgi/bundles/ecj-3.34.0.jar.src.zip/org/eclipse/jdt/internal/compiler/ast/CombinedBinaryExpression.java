/*     */ package org.eclipse.jdt.internal.compiler.ast;
/*     */ 
/*     */ import org.eclipse.jdt.internal.compiler.ASTVisitor;
/*     */ import org.eclipse.jdt.internal.compiler.codegen.CodeStream;
/*     */ import org.eclipse.jdt.internal.compiler.flow.FlowContext;
/*     */ import org.eclipse.jdt.internal.compiler.flow.FlowInfo;
/*     */ import org.eclipse.jdt.internal.compiler.flow.UnconditionalFlowInfo;
/*     */ import org.eclipse.jdt.internal.compiler.impl.Constant;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.BlockScope;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.TypeBinding;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CombinedBinaryExpression
/*     */   extends BinaryExpression
/*     */ {
/*     */   public int arity;
/*     */   public int arityMax;
/*     */   public static final int ARITY_MAX_MAX = 160;
/*     */   public static final int ARITY_MAX_MIN = 20;
/*  89 */   public static int defaultArityMaxStartingValue = 20;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BinaryExpression[] referencesTable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CombinedBinaryExpression(Expression left, Expression right, int operator, int arity) {
/* 115 */     super(left, right, operator);
/* 116 */     initArity(left, arity);
/*     */   }
/*     */   public CombinedBinaryExpression(CombinedBinaryExpression expression) {
/* 119 */     super(expression);
/* 120 */     initArity(expression.left, expression.arity);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public FlowInfo analyseCode(BlockScope currentScope, FlowContext flowContext, FlowInfo flowInfo) {
/* 127 */     if (this.referencesTable == null) {
/* 128 */       return super.analyseCode(currentScope, flowContext, flowInfo);
/*     */     }
/*     */     
/*     */     try {
/* 132 */       BinaryExpression cursor = this.referencesTable[0];
/* 133 */       UnconditionalFlowInfo unconditionalFlowInfo = cursor.left.analyseCode(currentScope, flowContext, flowInfo)
/* 134 */         .unconditionalInits();
/* 135 */       if (cursor.resolvedType.id != 11) {
/* 136 */         cursor.left.checkNPE(currentScope, flowContext, (FlowInfo)unconditionalFlowInfo);
/*     */       }
/* 138 */       for (int i = 0, end = this.arity; i < end; i++) {
/* 139 */         cursor = this.referencesTable[i];
/* 140 */         unconditionalFlowInfo = cursor.right
/* 141 */           .analyseCode(currentScope, flowContext, (FlowInfo)unconditionalFlowInfo)
/* 142 */           .unconditionalInits();
/* 143 */         if (cursor.resolvedType.id != 11) {
/* 144 */           cursor.right.checkNPE(currentScope, flowContext, (FlowInfo)unconditionalFlowInfo);
/*     */         }
/*     */       } 
/* 147 */       unconditionalFlowInfo = this.right.analyseCode(currentScope, flowContext, (FlowInfo)unconditionalFlowInfo).unconditionalInits();
/* 148 */       if (this.resolvedType.id != 11) {
/* 149 */         this.right.checkNPE(currentScope, flowContext, (FlowInfo)unconditionalFlowInfo);
/*     */       }
/* 151 */       return (FlowInfo)unconditionalFlowInfo;
/*     */     } finally {
/*     */       
/* 154 */       flowContext.recordAbruptExit();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void generateOptimizedStringConcatenation(BlockScope blockScope, CodeStream codeStream, int typeID) {
/* 163 */     if (this.referencesTable == null) {
/* 164 */       super.generateOptimizedStringConcatenation(blockScope, codeStream, 
/* 165 */           typeID);
/*     */     } else {
/* 167 */       if ((this.bits & 0x3F00) >> 8 == 
/* 168 */         14)
/* 169 */         if ((this.bits & 0xF) == 11) {
/* 170 */           if (this.constant != Constant.NotAConstant) {
/* 171 */             codeStream.generateConstant(this.constant, this.implicitConversion);
/* 172 */             codeStream.invokeStringConcatenationAppendForType(
/* 173 */                 this.implicitConversion & 0xF);
/*     */           } else {
/* 175 */             BinaryExpression cursor = this.referencesTable[0];
/*     */             
/* 177 */             int restart = 0;
/*     */             
/* 179 */             int pc = codeStream.position;
/* 180 */             for (restart = this.arity - 1; restart >= 0; restart--) {
/* 181 */               if ((cursor = this.referencesTable[restart]).constant != 
/* 182 */                 Constant.NotAConstant) {
/* 183 */                 codeStream.generateConstant(cursor.constant, 
/* 184 */                     cursor.implicitConversion);
/* 185 */                 codeStream.invokeStringConcatenationAppendForType(
/* 186 */                     cursor.implicitConversion & 0xF);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */                 
/*     */                 break;
/*     */               } 
/*     */             } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */             
/* 207 */             restart++;
/* 208 */             if (restart == 0) {
/* 209 */               cursor.left.generateOptimizedStringConcatenation(
/* 210 */                   blockScope, 
/* 211 */                   codeStream, 
/* 212 */                   cursor.left.implicitConversion & 0xF);
/*     */             }
/*     */             
/* 215 */             for (int i = restart; i < this.arity; i++) {
/* 216 */               codeStream.recordPositionsFrom(pc, 
/* 217 */                   (cursor = this.referencesTable[i]).left.sourceStart);
/* 218 */               int pcAux = codeStream.position;
/* 219 */               cursor.right.generateOptimizedStringConcatenation(blockScope, 
/* 220 */                   codeStream, cursor.right.implicitConversion & 
/* 221 */                   0xF);
/* 222 */               codeStream.recordPositionsFrom(pcAux, cursor.right.sourceStart);
/*     */             } 
/* 224 */             codeStream.recordPositionsFrom(pc, this.left.sourceStart);
/* 225 */             pc = codeStream.position;
/* 226 */             this.right.generateOptimizedStringConcatenation(
/* 227 */                 blockScope, 
/* 228 */                 codeStream, 
/* 229 */                 this.right.implicitConversion & 0xF);
/* 230 */             codeStream.recordPositionsFrom(pc, this.right.sourceStart);
/*     */           }  return;
/*     */         }  
/* 233 */       super.generateOptimizedStringConcatenation(blockScope, codeStream, 
/* 234 */           typeID);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void generateOptimizedStringConcatenationCreation(BlockScope blockScope, CodeStream codeStream, int typeID) {
/* 244 */     if (this.referencesTable == null) {
/* 245 */       super.generateOptimizedStringConcatenationCreation(blockScope, 
/* 246 */           codeStream, typeID);
/*     */     } else {
/* 248 */       if ((this.bits & 0x3F00) >> 8 == 
/* 249 */         14)
/* 250 */         if ((this.bits & 0xF) == 
/* 251 */           11)
/* 252 */           if (this.constant == Constant.NotAConstant) {
/* 253 */             int pc = codeStream.position;
/* 254 */             BinaryExpression cursor = this.referencesTable[this.arity - 1];
/*     */             
/* 256 */             int restart = 0;
/* 257 */             for (restart = this.arity - 1; restart >= 0; restart--) {
/* 258 */               if (((cursor = this.referencesTable[restart]).bits & 
/* 259 */                 0x3F00) >> 8 == 
/* 260 */                 14)
/* 261 */                 if ((cursor.bits & 0xF) == 
/* 262 */                   11) {
/* 263 */                   if (cursor.constant != Constant.NotAConstant) {
/* 264 */                     codeStream.newStringContatenation();
/* 265 */                     codeStream.dup();
/* 266 */                     codeStream.ldc(cursor.constant.stringValue());
/* 267 */                     codeStream.invokeStringConcatenationStringConstructor();
/*     */                     break;
/*     */                   } 
/*     */                   continue;
/*     */                 }  
/* 272 */               cursor.generateOptimizedStringConcatenationCreation(blockScope, 
/* 273 */                   codeStream, cursor.implicitConversion & 
/* 274 */                   0xF);
/*     */               
/*     */               break;
/*     */             } 
/* 278 */             restart++;
/* 279 */             if (restart == 0) {
/* 280 */               cursor.left.generateOptimizedStringConcatenationCreation(
/* 281 */                   blockScope, 
/* 282 */                   codeStream, 
/* 283 */                   cursor.left.implicitConversion & 0xF);
/*     */             }
/*     */             
/* 286 */             for (int i = restart; i < this.arity; i++) {
/* 287 */               codeStream.recordPositionsFrom(pc, 
/* 288 */                   (cursor = this.referencesTable[i]).left.sourceStart);
/* 289 */               int pcAux = codeStream.position;
/* 290 */               cursor.right.generateOptimizedStringConcatenation(blockScope, 
/* 291 */                   codeStream, cursor.right.implicitConversion & 
/* 292 */                   0xF);
/* 293 */               codeStream.recordPositionsFrom(pcAux, cursor.right.sourceStart);
/*     */             } 
/* 295 */             codeStream.recordPositionsFrom(pc, this.left.sourceStart);
/* 296 */             pc = codeStream.position;
/* 297 */             this.right.generateOptimizedStringConcatenation(
/* 298 */                 blockScope, 
/* 299 */                 codeStream, 
/* 300 */                 this.right.implicitConversion & 0xF);
/* 301 */             codeStream.recordPositionsFrom(pc, this.right.sourceStart); return;
/*     */           }   
/* 303 */       super.generateOptimizedStringConcatenationCreation(blockScope, 
/* 304 */           codeStream, typeID);
/*     */     } 
/*     */   }
/*     */   
/*     */   private void initArity(Expression expression, int value) {
/* 309 */     this.arity = value;
/* 310 */     if (value > 1) {
/* 311 */       this.referencesTable = new BinaryExpression[value];
/* 312 */       this.referencesTable[value - 1] = (BinaryExpression)expression;
/* 313 */       for (int i = value - 1; i > 0; i--) {
/* 314 */         this.referencesTable[i - 1] = 
/* 315 */           (BinaryExpression)(this.referencesTable[i]).left;
/*     */       }
/*     */     } else {
/* 318 */       this.arityMax = defaultArityMaxStartingValue;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public StringBuffer printExpressionNoParenthesis(int indent, StringBuffer output) {
/* 328 */     if (this.referencesTable == null) {
/* 329 */       return super.printExpressionNoParenthesis(indent, output);
/*     */     }
/* 331 */     String operatorString = operatorToString(); int i;
/* 332 */     for (i = this.arity - 1; i >= 0; i--) {
/* 333 */       output.append('(');
/*     */     }
/* 335 */     output = (this.referencesTable[0]).left
/* 336 */       .printExpression(indent, output); int end;
/* 337 */     for (i = 0, end = this.arity; 
/* 338 */       i < end; i++) {
/* 339 */       output.append(' ').append(operatorString).append(' ');
/* 340 */       output = (this.referencesTable[i]).right
/* 341 */         .printExpression(0, output);
/* 342 */       output.append(')');
/*     */     } 
/* 344 */     output.append(' ').append(operatorString).append(' ');
/* 345 */     return this.right.printExpression(0, output);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public TypeBinding resolveType(BlockScope scope) {
/* 351 */     if (this.referencesTable == null) {
/* 352 */       return super.resolveType(scope);
/*     */     }
/*     */     BinaryExpression cursor;
/* 355 */     if ((cursor = this.referencesTable[0]).left instanceof CastExpression) {
/* 356 */       cursor.left.bits |= 0x20;
/*     */     }
/*     */     
/* 359 */     cursor.left.resolveType(scope);
/* 360 */     for (int i = 0, end = this.arity; i < end; i++) {
/* 361 */       this.referencesTable[i].nonRecursiveResolveTypeUpwards(scope);
/*     */     }
/* 363 */     nonRecursiveResolveTypeUpwards(scope);
/* 364 */     return this.resolvedType;
/*     */   }
/*     */ 
/*     */   
/*     */   public void traverse(ASTVisitor visitor, BlockScope scope) {
/* 369 */     if (this.referencesTable == null) {
/* 370 */       super.traverse(visitor, scope);
/*     */     } else {
/* 372 */       if (visitor.visit(this, scope)) {
/*     */         int restart;
/* 374 */         for (restart = this.arity - 1; 
/* 375 */           restart >= 0; 
/* 376 */           restart--) {
/* 377 */           if (!visitor.visit(
/* 378 */               this.referencesTable[restart], scope)) {
/* 379 */             visitor.endVisit(
/* 380 */                 this.referencesTable[restart], scope);
/*     */             break;
/*     */           } 
/*     */         } 
/* 384 */         restart++;
/*     */ 
/*     */         
/* 387 */         if (restart == 0) {
/* 388 */           (this.referencesTable[0]).left.traverse(visitor, scope);
/*     */         }
/* 390 */         for (int i = restart, end = this.arity; 
/* 391 */           i < end; i++) {
/* 392 */           (this.referencesTable[i]).right.traverse(visitor, scope);
/* 393 */           visitor.endVisit(this.referencesTable[i], scope);
/*     */         } 
/* 395 */         this.right.traverse(visitor, scope);
/*     */       } 
/* 397 */       visitor.endVisit(this, scope);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void tuneArityMax() {
/* 411 */     if (this.arityMax < 160)
/* 412 */       this.arityMax *= 2; 
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\ast\CombinedBinaryExpression.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */