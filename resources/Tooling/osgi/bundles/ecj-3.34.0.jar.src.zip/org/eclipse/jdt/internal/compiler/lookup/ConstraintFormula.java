/*    */ package org.eclipse.jdt.internal.compiler.lookup;
/*    */ 
/*    */ import java.util.Collection;
/*    */ import java.util.Collections;
/*    */ import java.util.LinkedHashSet;
/*    */ import java.util.List;
/*    */ import java.util.Set;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ abstract class ConstraintFormula
/*    */   extends ReductionResult
/*    */ {
/* 29 */   static final List<InferenceVariable> EMPTY_VARIABLE_LIST = Collections.emptyList();
/* 30 */   static final ConstraintFormula[] NO_CONSTRAINTS = (ConstraintFormula[])new ConstraintTypeFormula[0];
/*    */   
/*    */   static final char LEFT_ANGLE_BRACKET = '⟨';
/*    */   
/*    */   static final char RIGHT_ANGLE_BRACKET = '⟩';
/*    */   
/*    */   public abstract Object reduce(InferenceContext18 paramInferenceContext18) throws InferenceFailureException;
/*    */   
/*    */   Collection<InferenceVariable> inputVariables(InferenceContext18 context) {
/* 39 */     return EMPTY_VARIABLE_LIST;
/*    */   }
/*    */   
/*    */   Collection<InferenceVariable> outputVariables(InferenceContext18 context) {
/* 43 */     Set<InferenceVariable> variables = new LinkedHashSet<>();
/* 44 */     this.right.collectInferenceVariables(variables);
/* 45 */     if (!variables.isEmpty())
/* 46 */       variables.removeAll(inputVariables(context)); 
/* 47 */     return variables;
/*    */   }
/*    */   
/*    */   public boolean applySubstitution(BoundSet solutionSet, InferenceVariable[] variables) {
/* 51 */     for (int i = 0; i < variables.length; i++) {
/* 52 */       InferenceVariable variable = variables[i];
/* 53 */       TypeBinding instantiation = solutionSet.getInstantiation(variables[i], null);
/* 54 */       if (instantiation == null)
/* 55 */         return false; 
/* 56 */       this.right = this.right.substituteInferenceVariable(variable, instantiation);
/*    */     } 
/* 58 */     return true;
/*    */   }
/*    */ 
/*    */   
/*    */   protected void appendTypeName(StringBuffer buf, TypeBinding type) {
/* 63 */     if (type instanceof CaptureBinding18) {
/* 64 */       buf.append(type.toString());
/*    */     } else {
/* 66 */       buf.append(type.readableName());
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\lookup\ConstraintFormula.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */