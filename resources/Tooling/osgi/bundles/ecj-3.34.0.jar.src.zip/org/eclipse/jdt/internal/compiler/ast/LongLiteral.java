/*     */ package org.eclipse.jdt.internal.compiler.ast;
/*     */ 
/*     */ import org.eclipse.jdt.core.compiler.CharOperation;
/*     */ import org.eclipse.jdt.internal.compiler.ASTVisitor;
/*     */ import org.eclipse.jdt.internal.compiler.codegen.CodeStream;
/*     */ import org.eclipse.jdt.internal.compiler.impl.LongConstant;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.BlockScope;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.TypeBinding;
/*     */ import org.eclipse.jdt.internal.compiler.parser.ScannerHelper;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LongLiteral
/*     */   extends NumberLiteral
/*     */ {
/*  26 */   private static final char[] HEXA_MIN_VALUE = "0x8000000000000000L".toCharArray();
/*  27 */   private static final char[] HEXA_MINUS_ONE_VALUE = "0xffffffffffffffffL".toCharArray();
/*  28 */   private static final char[] OCTAL_MIN_VALUE = "01000000000000000000000L".toCharArray();
/*  29 */   private static final char[] OCTAL_MINUS_ONE_VALUE = "01777777777777777777777L".toCharArray();
/*  30 */   private static final char[] DECIMAL_MIN_VALUE = "9223372036854775808L".toCharArray();
/*  31 */   private static final char[] DECIMAL_MAX_VALUE = "9223372036854775807L".toCharArray();
/*     */   
/*     */   private char[] reducedForm;
/*     */ 
/*     */   
/*     */   public static LongLiteral buildLongLiteral(char[] token, int s, int e) {
/*  37 */     char[] longReducedToken = removePrefixZerosAndUnderscores(token, true);
/*  38 */     switch (longReducedToken.length) {
/*     */       
/*     */       case 19:
/*  41 */         if (CharOperation.equals(longReducedToken, HEXA_MIN_VALUE)) {
/*  42 */           return new LongLiteralMinValue(token, (longReducedToken != token) ? longReducedToken : null, s, e);
/*     */         }
/*     */         break;
/*     */       
/*     */       case 24:
/*  47 */         if (CharOperation.equals(longReducedToken, OCTAL_MIN_VALUE)) {
/*  48 */           return new LongLiteralMinValue(token, (longReducedToken != token) ? longReducedToken : null, s, e);
/*     */         }
/*     */         break;
/*     */     } 
/*  52 */     return new LongLiteral(token, (longReducedToken != token) ? longReducedToken : null, s, e);
/*     */   }
/*     */   
/*     */   LongLiteral(char[] token, char[] reducedForm, int start, int end) {
/*  56 */     super(token, start, end);
/*  57 */     this.reducedForm = reducedForm;
/*     */   }
/*     */   public LongLiteral convertToMinValue() {
/*  60 */     if ((this.bits & 0x1FE00000) >> 21 != 0) {
/*  61 */       return this;
/*     */     }
/*  63 */     char[] token = (this.reducedForm != null) ? this.reducedForm : this.source;
/*  64 */     switch (token.length) {
/*     */       
/*     */       case 20:
/*  67 */         if (CharOperation.equals(token, DECIMAL_MIN_VALUE, false)) {
/*  68 */           return new LongLiteralMinValue(this.source, this.reducedForm, this.sourceStart, this.sourceEnd);
/*     */         }
/*     */         break;
/*     */     } 
/*  72 */     return this;
/*     */   }
/*     */   
/*     */   public void computeConstant() {
/*  76 */     char[] token = (this.reducedForm != null) ? this.reducedForm : this.source;
/*  77 */     int tokenLength = token.length;
/*  78 */     int length = tokenLength - 1;
/*  79 */     int radix = 10;
/*  80 */     int j = 0;
/*  81 */     if (token[0] == '0') {
/*  82 */       if (length == 1) {
/*  83 */         this.constant = LongConstant.fromValue(0L);
/*     */         return;
/*     */       } 
/*  86 */       if (token[1] == 'x' || token[1] == 'X') {
/*  87 */         radix = 16;
/*  88 */         j = 2;
/*  89 */       } else if (token[1] == 'b' || token[1] == 'B') {
/*  90 */         radix = 2;
/*  91 */         j = 2;
/*     */       } else {
/*  93 */         radix = 8;
/*  94 */         j = 1;
/*     */       } 
/*     */     } 
/*  97 */     switch (radix) {
/*     */       case 2:
/*  99 */         if (length - 2 > 64) {
/*     */           return;
/*     */         }
/* 102 */         computeValue(token, length, radix, j);
/*     */         break;
/*     */       case 16:
/* 105 */         if (tokenLength <= 19) {
/* 106 */           if (CharOperation.equals(token, HEXA_MINUS_ONE_VALUE)) {
/* 107 */             this.constant = LongConstant.fromValue(-1L);
/*     */             return;
/*     */           } 
/* 110 */           computeValue(token, length, radix, j);
/*     */         } 
/*     */         break;
/*     */       case 10:
/* 114 */         if (tokenLength > DECIMAL_MAX_VALUE.length || (
/* 115 */           tokenLength == DECIMAL_MAX_VALUE.length && 
/* 116 */           CharOperation.compareTo(token, DECIMAL_MAX_VALUE, 0, length) > 0)) {
/*     */           return;
/*     */         }
/* 119 */         computeValue(token, length, radix, j);
/*     */         break;
/*     */       case 8:
/* 122 */         if (tokenLength <= 24) {
/* 123 */           if (tokenLength == 24 && token[j] > '1') {
/*     */             return;
/*     */           }
/* 126 */           if (CharOperation.equals(token, OCTAL_MINUS_ONE_VALUE)) {
/* 127 */             this.constant = LongConstant.fromValue(-1L);
/*     */             return;
/*     */           } 
/* 130 */           computeValue(token, length, radix, j);
/*     */         } 
/*     */         break;
/*     */     } 
/*     */   }
/*     */   
/*     */   private void computeValue(char[] token, int tokenLength, int radix, int j) {
/* 137 */     long computedValue = 0L;
/* 138 */     while (j < tokenLength) {
/* 139 */       int digitValue; if ((digitValue = ScannerHelper.digit(token[j++], radix)) < 0) {
/*     */         return;
/*     */       }
/* 142 */       computedValue = computedValue * radix + digitValue;
/*     */     } 
/* 144 */     this.constant = LongConstant.fromValue(computedValue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void generateCode(BlockScope currentScope, CodeStream codeStream, boolean valueRequired) {
/* 155 */     int pc = codeStream.position;
/* 156 */     if (valueRequired) {
/* 157 */       codeStream.generateConstant(this.constant, this.implicitConversion);
/*     */     }
/* 159 */     codeStream.recordPositionsFrom(pc, this.sourceStart);
/*     */   }
/*     */ 
/*     */   
/*     */   public TypeBinding literalType(BlockScope scope) {
/* 164 */     return (TypeBinding)TypeBinding.LONG;
/*     */   }
/*     */   
/*     */   public void traverse(ASTVisitor visitor, BlockScope scope) {
/* 168 */     visitor.visit(this, scope);
/* 169 */     visitor.endVisit(this, scope);
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\ast\LongLiteral.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */