/*     */ package org.eclipse.jdt.internal.compiler.batch;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.FilenameFilter;
/*     */ import java.io.IOException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.StringTokenizer;
/*     */ import java.util.jar.Manifest;
/*     */ import java.util.zip.ZipEntry;
/*     */ import java.util.zip.ZipFile;
/*     */ import org.eclipse.jdt.internal.compiler.CompilationResult;
/*     */ import org.eclipse.jdt.internal.compiler.ast.CompilationUnitDeclaration;
/*     */ import org.eclipse.jdt.internal.compiler.classfmt.ClassFileReader;
/*     */ import org.eclipse.jdt.internal.compiler.classfmt.ClassFormatException;
/*     */ import org.eclipse.jdt.internal.compiler.env.IModule;
/*     */ import org.eclipse.jdt.internal.compiler.env.PackageExportImpl;
/*     */ import org.eclipse.jdt.internal.compiler.parser.Parser;
/*     */ import org.eclipse.jdt.internal.compiler.util.JRTUtil;
/*     */ import org.eclipse.jdt.internal.compiler.util.Util;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ModuleFinder
/*     */ {
/*     */   public static List<FileSystem.Classpath> findModules(File f, String destinationPath, Parser parser, Map<String, String> options, boolean isModulepath, String release) {
/*  43 */     List<FileSystem.Classpath> collector = new ArrayList<>();
/*  44 */     scanForModules(destinationPath, parser, options, isModulepath, false, collector, f, release);
/*  45 */     return collector;
/*     */   }
/*     */ 
/*     */   
/*     */   protected static FileSystem.Classpath findModule(File file, String destinationPath, Parser parser, Map<String, String> options, boolean isModulepath, String release) {
/*  50 */     FileSystem.Classpath modulePath = FileSystem.getClasspath(file.getAbsolutePath(), null, !isModulepath, null, 
/*  51 */         (destinationPath == null) ? null : (String.valueOf(destinationPath) + File.separator + file.getName()), options, release);
/*  52 */     if (modulePath != null) {
/*  53 */       scanForModule(modulePath, file, parser, isModulepath, release);
/*     */     }
/*  55 */     return modulePath;
/*     */   }
/*     */   
/*     */   protected static void scanForModules(String destinationPath, Parser parser, Map<String, String> options, boolean isModulepath, boolean thisAnAutomodule, List<FileSystem.Classpath> collector, File file, String release) {
/*  59 */     FileSystem.Classpath entry = FileSystem.getClasspath(
/*  60 */         file.getAbsolutePath(), 
/*  61 */         null, 
/*  62 */         !isModulepath, 
/*  63 */         null, 
/*  64 */         (destinationPath == null) ? null : (String.valueOf(destinationPath) + File.separator + file.getName()), 
/*  65 */         options, 
/*  66 */         release);
/*  67 */     if (entry != null) {
/*  68 */       IModule module = scanForModule(entry, file, parser, thisAnAutomodule, release);
/*  69 */       if (module != null) {
/*  70 */         collector.add(entry);
/*     */       }
/*  72 */       else if (file.isDirectory()) {
/*  73 */         File[] files = file.listFiles(); byte b; int i; File[] arrayOfFile1;
/*  74 */         for (i = (arrayOfFile1 = files).length, b = 0; b < i; ) { File f = arrayOfFile1[b];
/*  75 */           scanForModules(destinationPath, parser, options, isModulepath, isModulepath, collector, f, release);
/*     */           b++; }
/*     */       
/*     */       } 
/*     */     } 
/*     */   }
/*     */   protected static IModule scanForModule(FileSystem.Classpath modulePath, final File file, Parser parser, boolean considerAutoModules, String release) {
/*  82 */     IModule module = null;
/*  83 */     if (file.isDirectory()) {
/*  84 */       String[] list = file.list(new FilenameFilter()
/*     */           {
/*     */             public boolean accept(File dir, String name) {
/*  87 */               if (dir == file && (name.equalsIgnoreCase("module-info.class") || 
/*  88 */                 name.equalsIgnoreCase("module-info.java"))) {
/*  89 */                 return true;
/*     */               }
/*  91 */               return false;
/*     */             }
/*     */           });
/*  94 */       if (list.length > 0) {
/*  95 */         String modName, fileName = list[0]; String str1;
/*  96 */         switch ((str1 = fileName).hashCode()) { case -563279303: if (!str1.equals("module-info.class"))
/*     */               break; 
/*  98 */             module = extractModuleFromClass(new File(file, fileName), modulePath); break;
/*     */           case 1921690945:
/*     */             if (!str1.equals("module-info.java"))
/* 101 */               break;  module = extractModuleFromSource(new File(file, fileName), parser, modulePath);
/* 102 */             if (module == null)
/* 103 */               return null; 
/* 104 */             modName = new String(module.name());
/* 105 */             if (!modName.equals(file.getName())) {
/* 106 */               throw new IllegalArgumentException("module name " + modName + " does not match expected name " + file.getName());
/*     */             }
/*     */             break; }
/*     */       
/*     */       } 
/*     */     } else {
/* 112 */       String moduleDescPath = getModulePathForArchive(file);
/* 113 */       if (moduleDescPath != null) {
/* 114 */         module = extractModuleFromArchive(file, modulePath, moduleDescPath, release);
/*     */       }
/*     */     } 
/* 117 */     if (considerAutoModules && module == null && !(modulePath instanceof ClasspathJrt) && 
/* 118 */       !file.isDirectory()) {
/* 119 */       String fileName = getFileName(file);
/* 120 */       if (!fileName.isEmpty()) {
/* 121 */         module = IModule.createAutomatic(fileName, file.isFile(), getManifest(file));
/*     */       }
/*     */     } 
/* 124 */     if (module != null)
/* 125 */       modulePath.acceptModule(module); 
/* 126 */     return module;
/*     */   }
/*     */   private static Manifest getManifest(File file) {
/* 129 */     if (getModulePathForArchive(file) == null)
/* 130 */       return null;  
/* 131 */     try { Exception exception1 = null, exception2 = null; try {  }
/*     */       finally
/* 133 */       { exception2 = null; if (exception1 == null) { exception1 = exception2; } else if (exception1 != exception2) { exception1.addSuppressed(exception2); }  }  } catch (IOException e)
/* 134 */     { String error = "Failed to read manifest from " + file;
/* 135 */       if (JRTUtil.PROPAGATE_IO_ERRORS) {
/* 136 */         throw new IllegalStateException(error, e);
/*     */       }
/* 138 */       System.err.println(error);
/* 139 */       e.printStackTrace();
/*     */       
/* 141 */       return null; }
/*     */   
/*     */   }
/*     */   private static String getFileName(File file) {
/* 145 */     String name = file.getName();
/* 146 */     int index = name.lastIndexOf('.');
/* 147 */     if (index == -1)
/* 148 */       return name; 
/* 149 */     return name.substring(0, index);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static String[] extractAddonRead(String option) {
/* 161 */     StringTokenizer tokenizer = new StringTokenizer(option, "=");
/* 162 */     String source = null;
/* 163 */     String target = null;
/* 164 */     if (tokenizer.hasMoreTokens()) {
/* 165 */       source = tokenizer.nextToken();
/*     */     } else {
/*     */       
/* 168 */       return null;
/*     */     } 
/* 170 */     if (tokenizer.hasMoreTokens()) {
/* 171 */       target = tokenizer.nextToken();
/*     */     } else {
/*     */       
/* 174 */       return null;
/*     */     } 
/* 176 */     return new String[] { source, target };
/*     */   }
/*     */ 
/*     */   
/*     */   static class AddExport
/*     */   {
/*     */     public final String sourceModuleName;
/*     */     
/*     */     public final IModule.IPackageExport export;
/*     */     
/*     */     public AddExport(String moduleName, IModule.IPackageExport export) {
/* 187 */       this.sourceModuleName = moduleName;
/* 188 */       this.export = export;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static AddExport extractAddonExport(String option) {
/* 206 */     StringTokenizer tokenizer = new StringTokenizer(option, "/");
/* 207 */     String source = null;
/* 208 */     String pack = null;
/* 209 */     List<String> targets = new ArrayList<>();
/* 210 */     if (tokenizer.hasMoreTokens()) {
/* 211 */       source = tokenizer.nextToken("/");
/*     */     } else {
/*     */       
/* 214 */       return null;
/*     */     } 
/* 216 */     if (tokenizer.hasMoreTokens()) {
/* 217 */       pack = tokenizer.nextToken("/=");
/*     */     } else {
/*     */       
/* 220 */       return null;
/*     */     } 
/* 222 */     while (tokenizer.hasMoreTokens()) {
/* 223 */       targets.add(tokenizer.nextToken("=,"));
/*     */     }
/* 225 */     PackageExportImpl export = new PackageExportImpl();
/* 226 */     export.pack = pack.toCharArray();
/* 227 */     export.exportedTo = new char[targets.size()][];
/* 228 */     for (int i = 0; i < export.exportedTo.length; i++) {
/* 229 */       export.exportedTo[i] = ((String)targets.get(i)).toCharArray();
/*     */     }
/* 231 */     return new AddExport(source, (IModule.IPackageExport)export);
/*     */   }
/*     */   
/*     */   private static String getModulePathForArchive(File file) {
/* 235 */     int format = Util.archiveFormat(file.getAbsolutePath());
/* 236 */     if (format == 0)
/* 237 */       return "module-info.class"; 
/* 238 */     if (format == 1) {
/* 239 */       return "classes/module-info.class";
/*     */     }
/* 241 */     return null;
/*     */   }
/*     */   private static IModule extractModuleFromArchive(File file, FileSystem.Classpath pathEntry, String path, String release) {
/* 244 */     ZipFile zipFile = null;
/*     */     try {
/* 246 */       zipFile = new ZipFile(file);
/* 247 */       if (release != null) {
/* 248 */         String releasePath = "META-INF/versions/" + release + "/" + path;
/* 249 */         ZipEntry entry = zipFile.getEntry(releasePath);
/* 250 */         if (entry != null) {
/* 251 */           path = releasePath;
/*     */         }
/*     */       } 
/* 254 */       ClassFileReader reader = ClassFileReader.read(zipFile, path);
/* 255 */       IModule module = getModule(reader);
/* 256 */       if (module != null) {
/* 257 */         return (IModule)reader.getModuleDeclaration();
/*     */       }
/* 259 */       return null;
/* 260 */     } catch (ClassFormatException classFormatException) {
/*     */     
/* 262 */     } catch (IOException e) {
/* 263 */       String error = "Failed to read module for path " + path + " and release " + release + " from " + file;
/* 264 */       if (JRTUtil.PROPAGATE_IO_ERRORS) {
/* 265 */         throw new IllegalStateException(error, e);
/*     */       }
/* 267 */       System.err.println(error);
/* 268 */       e.printStackTrace();
/*     */     } finally {
/*     */       
/* 271 */       if (zipFile != null) {
/*     */         try {
/* 273 */           zipFile.close();
/* 274 */         } catch (IOException iOException) {}
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 279 */     return null;
/*     */   }
/*     */   
/*     */   private static IModule extractModuleFromClass(File classfilePath, FileSystem.Classpath pathEntry) {
/*     */     try {
/* 284 */       ClassFileReader reader = ClassFileReader.read(classfilePath);
/* 285 */       IModule module = getModule(reader);
/* 286 */       if (module != null) {
/* 287 */         return (IModule)reader.getModuleDeclaration();
/*     */       }
/* 289 */       return null;
/* 290 */     } catch (ClassFormatException e) {
/* 291 */       e.printStackTrace();
/* 292 */     } catch (IOException e) {
/* 293 */       String error = "Failed to read module from " + classfilePath;
/* 294 */       if (JRTUtil.PROPAGATE_IO_ERRORS) {
/* 295 */         throw new IllegalStateException(error, e);
/*     */       }
/* 297 */       System.err.println(error);
/* 298 */       e.printStackTrace();
/*     */     } 
/*     */     
/* 301 */     return null;
/*     */   }
/*     */   private static IModule getModule(ClassFileReader classfile) {
/* 304 */     if (classfile != null) {
/* 305 */       return (IModule)classfile.getModuleDeclaration();
/*     */     }
/* 307 */     return null;
/*     */   }
/*     */   private static IModule extractModuleFromSource(File file, Parser parser, FileSystem.Classpath pathEntry) {
/* 310 */     CompilationUnit cu = new CompilationUnit(null, file.getAbsolutePath(), null, pathEntry.getDestinationPath());
/* 311 */     CompilationResult compilationResult = new CompilationResult(cu, 0, 1, 10);
/* 312 */     CompilationUnitDeclaration unit = parser.parse(cu, compilationResult);
/* 313 */     if (unit.isModuleInfo() && unit.moduleDeclaration != null) {
/* 314 */       cu.module = unit.moduleDeclaration.moduleName;
/* 315 */       return (IModule)new BasicModule(unit.moduleDeclaration, pathEntry);
/*     */     } 
/* 317 */     return null;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\batch\ModuleFinder.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */