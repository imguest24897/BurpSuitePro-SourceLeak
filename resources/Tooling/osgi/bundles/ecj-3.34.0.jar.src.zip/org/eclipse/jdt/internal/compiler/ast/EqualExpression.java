/*     */ package org.eclipse.jdt.internal.compiler.ast;
/*     */ 
/*     */ import org.eclipse.jdt.internal.compiler.ASTVisitor;
/*     */ import org.eclipse.jdt.internal.compiler.codegen.BranchLabel;
/*     */ import org.eclipse.jdt.internal.compiler.codegen.CodeStream;
/*     */ import org.eclipse.jdt.internal.compiler.flow.FlowContext;
/*     */ import org.eclipse.jdt.internal.compiler.flow.FlowInfo;
/*     */ import org.eclipse.jdt.internal.compiler.flow.UnconditionalFlowInfo;
/*     */ import org.eclipse.jdt.internal.compiler.impl.BooleanConstant;
/*     */ import org.eclipse.jdt.internal.compiler.impl.CompilerOptions;
/*     */ import org.eclipse.jdt.internal.compiler.impl.Constant;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.Binding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.BlockScope;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.FieldBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.LocalVariableBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.ReferenceBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.Scope;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.TypeBinding;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class EqualExpression
/*     */   extends BinaryExpression
/*     */ {
/*     */   public EqualExpression(Expression left, Expression right, int operator) {
/*  32 */     super(left, right, operator);
/*     */   }
/*     */ 
/*     */   
/*     */   private void checkNullComparison(BlockScope scope, FlowContext flowContext, FlowInfo flowInfo, FlowInfo initsWhenTrue, FlowInfo initsWhenFalse) {
/*  37 */     int rightStatus = this.right.nullStatus(flowInfo, flowContext);
/*  38 */     int leftStatus = this.left.nullStatus(flowInfo, flowContext);
/*     */     
/*  40 */     boolean leftNonNullChecked = false;
/*  41 */     boolean rightNonNullChecked = false;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  47 */     boolean checkEquality = ((this.bits & 0x3F00) >> 8 == 18);
/*  48 */     if ((flowContext.tagBits & 0xF000) == 0) {
/*  49 */       if (leftStatus == 4 && rightStatus == 2) {
/*  50 */         leftNonNullChecked = scope.problemReporter().expressionNonNullComparison(this.left, checkEquality);
/*  51 */       } else if (leftStatus == 2 && rightStatus == 4) {
/*  52 */         rightNonNullChecked = scope.problemReporter().expressionNonNullComparison(this.right, checkEquality);
/*     */       } 
/*     */     }
/*     */     
/*  56 */     int i = checkEquality ^ (((flowContext.tagBits & 0x4) != 0) ? 1 : 0);
/*     */     
/*  58 */     if (!leftNonNullChecked) {
/*  59 */       LocalVariableBinding local = this.left.localVariableBinding();
/*  60 */       if (local != null) {
/*  61 */         if ((local.type.tagBits & 0x2L) == 0L) {
/*  62 */           checkVariableComparison(scope, flowContext, flowInfo, initsWhenTrue, initsWhenFalse, local, rightStatus, this.left);
/*     */         }
/*  64 */       } else if (this.left instanceof Reference && (
/*  65 */         (i != 0) ? (rightStatus == 4) : (rightStatus == 2))) {
/*  66 */         if ((scope.compilerOptions()).enableSyntacticNullAnalysisForFields) {
/*     */           
/*  68 */           FieldBinding field = ((Reference)this.left).lastFieldBinding();
/*  69 */           if (field != null && (field.type.tagBits & 0x2L) == 0L)
/*  70 */             flowContext.recordNullCheckedFieldReference((Reference)this.left, 1); 
/*     */         } 
/*     */       } 
/*     */     } 
/*  74 */     if (!rightNonNullChecked) {
/*  75 */       LocalVariableBinding local = this.right.localVariableBinding();
/*  76 */       if (local != null) {
/*  77 */         if ((local.type.tagBits & 0x2L) == 0L) {
/*  78 */           checkVariableComparison(scope, flowContext, flowInfo, initsWhenTrue, initsWhenFalse, local, leftStatus, this.right);
/*     */         }
/*  80 */       } else if (this.right instanceof Reference && (
/*  81 */         (i != 0) ? (leftStatus == 4) : (leftStatus == 2))) {
/*  82 */         if ((scope.compilerOptions()).enableSyntacticNullAnalysisForFields) {
/*     */           
/*  84 */           FieldBinding field = ((Reference)this.right).lastFieldBinding();
/*  85 */           if (field != null && (field.type.tagBits & 0x2L) == 0L) {
/*  86 */             flowContext.recordNullCheckedFieldReference((Reference)this.right, 1);
/*     */           }
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/*  92 */     if (leftNonNullChecked || rightNonNullChecked)
/*     */     {
/*  94 */       if (checkEquality) {
/*  95 */         initsWhenTrue.setReachMode(2);
/*     */       } else {
/*  97 */         initsWhenFalse.setReachMode(2);
/*     */       }  } 
/*     */   }
/*     */   
/*     */   private void checkVariableComparison(BlockScope scope, FlowContext flowContext, FlowInfo flowInfo, FlowInfo initsWhenTrue, FlowInfo initsWhenFalse, LocalVariableBinding local, int nullStatus, Expression reference) {
/* 102 */     switch (nullStatus) {
/*     */       case 2:
/* 104 */         if ((this.bits & 0x3F00) >> 8 == 18) {
/* 105 */           flowContext.recordUsingNullReference((Scope)scope, local, reference, 
/* 106 */               256, flowInfo);
/* 107 */           initsWhenTrue.markAsComparedEqualToNull(local);
/* 108 */           initsWhenFalse.markAsComparedEqualToNonNull(local); break;
/*     */         } 
/* 110 */         flowContext.recordUsingNullReference((Scope)scope, local, reference, 
/* 111 */             512, flowInfo);
/* 112 */         initsWhenTrue.markAsComparedEqualToNonNull(local);
/* 113 */         initsWhenFalse.markAsComparedEqualToNull(local);
/*     */         break;
/*     */       
/*     */       case 4:
/* 117 */         if ((this.bits & 0x3F00) >> 8 == 18) {
/* 118 */           flowContext.recordUsingNullReference((Scope)scope, local, reference, 
/* 119 */               513, flowInfo);
/* 120 */           initsWhenTrue.markAsComparedEqualToNonNull(local); break;
/*     */         } 
/* 122 */         flowContext.recordUsingNullReference((Scope)scope, local, reference, 
/* 123 */             257, flowInfo);
/*     */         break;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void analyzeLocalVariable(Expression exp, FlowInfo flowInfo) {
/* 131 */     if (exp instanceof SingleNameReference && (exp.bits & 0x2) != 0) {
/* 132 */       LocalVariableBinding localBinding = (LocalVariableBinding)((SingleNameReference)exp).binding;
/* 133 */       if ((flowInfo.tagBits & 0x3) == 0) {
/* 134 */         localBinding.useFlag = 1;
/* 135 */       } else if (localBinding.useFlag == 0) {
/* 136 */         localBinding.useFlag = 2;
/*     */       } 
/*     */     } 
/*     */   }
/*     */   public FlowInfo analyseCode(BlockScope currentScope, FlowContext flowContext, FlowInfo flowInfo) {
/*     */     UnconditionalFlowInfo unconditionalFlowInfo;
/*     */     FlowInfo flowInfo1;
/* 143 */     if ((this.bits & 0x3F00) >> 8 == 18) {
/* 144 */       if (this.left.constant != Constant.NotAConstant && this.left.constant.typeID() == 5) {
/* 145 */         if (this.left.constant.booleanValue()) {
/*     */           
/* 147 */           flowInfo1 = this.right.analyseCode(currentScope, flowContext, flowInfo);
/*     */         } else {
/*     */           
/* 150 */           flowInfo1 = this.right.analyseCode(currentScope, flowContext, flowInfo).asNegatedCondition();
/* 151 */           analyzeLocalVariable(this.left, flowInfo);
/*     */         }
/*     */       
/* 154 */       } else if (this.right.constant != Constant.NotAConstant && this.right.constant.typeID() == 5) {
/* 155 */         if (this.right.constant.booleanValue()) {
/*     */           
/* 157 */           flowInfo1 = this.left.analyseCode(currentScope, flowContext, flowInfo);
/*     */         } else {
/*     */           
/* 160 */           flowInfo1 = this.left.analyseCode(currentScope, flowContext, flowInfo).asNegatedCondition();
/* 161 */           analyzeLocalVariable(this.right, flowInfo);
/*     */         } 
/*     */       } else {
/*     */         
/* 165 */         unconditionalFlowInfo = this.right.analyseCode(
/* 166 */             currentScope, flowContext, 
/* 167 */             (FlowInfo)this.left.analyseCode(currentScope, flowContext, flowInfo).unconditionalInits()).unconditionalInits();
/*     */       }
/*     */     
/* 170 */     } else if (this.left.constant != Constant.NotAConstant && this.left.constant.typeID() == 5) {
/* 171 */       if (!this.left.constant.booleanValue()) {
/*     */         
/* 173 */         flowInfo1 = this.right.analyseCode(currentScope, flowContext, flowInfo);
/* 174 */         analyzeLocalVariable(this.left, flowInfo);
/*     */       } else {
/*     */         
/* 177 */         flowInfo1 = this.right.analyseCode(currentScope, flowContext, flowInfo).asNegatedCondition();
/*     */       }
/*     */     
/* 180 */     } else if (this.right.constant != Constant.NotAConstant && this.right.constant.typeID() == 5) {
/* 181 */       if (!this.right.constant.booleanValue()) {
/*     */         
/* 183 */         flowInfo1 = this.left.analyseCode(currentScope, flowContext, flowInfo);
/* 184 */         analyzeLocalVariable(this.right, flowInfo);
/*     */       } else {
/*     */         
/* 187 */         flowInfo1 = this.left.analyseCode(currentScope, flowContext, flowInfo).asNegatedCondition();
/*     */       } 
/*     */     } else {
/*     */       
/* 191 */       unconditionalFlowInfo = this.right.analyseCode(
/* 192 */           currentScope, flowContext, 
/* 193 */           (FlowInfo)this.left.analyseCode(currentScope, flowContext, flowInfo).unconditionalInits())
/*     */         
/* 195 */         .unconditionalInits();
/*     */     } 
/*     */     
/* 198 */     if (unconditionalFlowInfo instanceof UnconditionalFlowInfo && (
/* 199 */       ((FlowInfo)unconditionalFlowInfo).tagBits & 0x3) == 0) {
/* 200 */       flowInfo1 = FlowInfo.conditional(unconditionalFlowInfo.copy(), unconditionalFlowInfo.copy());
/*     */     }
/*     */     
/* 203 */     checkNullComparison(currentScope, flowContext, flowInfo1, flowInfo1.initsWhenTrue(), flowInfo1.initsWhenFalse());
/* 204 */     return flowInfo1;
/*     */   }
/*     */   
/*     */   public final void computeConstant(TypeBinding leftType, TypeBinding rightType) {
/* 208 */     if (this.left.constant != Constant.NotAConstant && this.right.constant != Constant.NotAConstant) {
/* 209 */       this.constant = 
/* 210 */         Constant.computeConstantOperationEQUAL_EQUAL(
/* 211 */           this.left.constant, 
/* 212 */           leftType.id, 
/* 213 */           this.right.constant, 
/* 214 */           rightType.id);
/* 215 */       if ((this.bits & 0x3F00) >> 8 == 29)
/* 216 */         this.constant = BooleanConstant.fromValue(!this.constant.booleanValue()); 
/*     */     } else {
/* 218 */       this.constant = Constant.NotAConstant;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void generateCode(BlockScope currentScope, CodeStream codeStream, boolean valueRequired) {
/* 232 */     int pc = codeStream.position;
/* 233 */     if (this.constant != Constant.NotAConstant) {
/* 234 */       if (valueRequired)
/* 235 */         codeStream.generateConstant(this.constant, this.implicitConversion); 
/* 236 */       codeStream.recordPositionsFrom(pc, this.sourceStart);
/*     */       
/*     */       return;
/*     */     } 
/* 240 */     if ((this.left.implicitConversion & 0xF) == 5) {
/* 241 */       generateBooleanEqual(currentScope, codeStream, valueRequired);
/*     */     } else {
/* 243 */       generateNonBooleanEqual(currentScope, codeStream, valueRequired);
/*     */     } 
/* 245 */     if (valueRequired) {
/* 246 */       codeStream.generateImplicitConversion(this.implicitConversion);
/*     */     }
/* 248 */     codeStream.recordPositionsFrom(pc, this.sourceStart);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void generateOptimizedBoolean(BlockScope currentScope, CodeStream codeStream, BranchLabel trueLabel, BranchLabel falseLabel, boolean valueRequired) {
/* 257 */     if (this.constant != Constant.NotAConstant) {
/* 258 */       super.generateOptimizedBoolean(currentScope, codeStream, trueLabel, falseLabel, valueRequired);
/*     */       return;
/*     */     } 
/* 261 */     if ((this.bits & 0x3F00) >> 8 == 18) {
/* 262 */       if ((this.left.implicitConversion & 0xF) == 5) {
/* 263 */         generateOptimizedBooleanEqual(currentScope, codeStream, trueLabel, falseLabel, valueRequired);
/*     */       } else {
/* 265 */         generateOptimizedNonBooleanEqual(currentScope, codeStream, trueLabel, falseLabel, valueRequired);
/*     */       }
/*     */     
/* 268 */     } else if ((this.left.implicitConversion & 0xF) == 5) {
/* 269 */       generateOptimizedBooleanEqual(currentScope, codeStream, falseLabel, trueLabel, valueRequired);
/*     */     } else {
/* 271 */       generateOptimizedNonBooleanEqual(currentScope, codeStream, falseLabel, trueLabel, valueRequired);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void generateBooleanEqual(BlockScope currentScope, CodeStream codeStream, boolean valueRequired) {
/* 285 */     boolean isEqualOperator = ((this.bits & 0x3F00) >> 8 == 18);
/* 286 */     Constant cst = this.left.optimizedBooleanConstant();
/* 287 */     if (cst != Constant.NotAConstant) {
/* 288 */       Constant rightCst = this.right.optimizedBooleanConstant();
/* 289 */       if (rightCst != Constant.NotAConstant) {
/*     */ 
/*     */         
/* 292 */         this.left.generateCode(currentScope, codeStream, false);
/* 293 */         this.right.generateCode(currentScope, codeStream, false);
/* 294 */         if (valueRequired) {
/* 295 */           boolean leftBool = cst.booleanValue();
/* 296 */           boolean rightBool = rightCst.booleanValue();
/* 297 */           if (isEqualOperator) {
/* 298 */             if (leftBool == rightBool) {
/* 299 */               codeStream.iconst_1();
/*     */             } else {
/* 301 */               codeStream.iconst_0();
/*     */             }
/*     */           
/* 304 */           } else if (leftBool != rightBool) {
/* 305 */             codeStream.iconst_1();
/*     */           } else {
/* 307 */             codeStream.iconst_0();
/*     */           }
/*     */         
/*     */         } 
/* 311 */       } else if (cst.booleanValue() == isEqualOperator) {
/*     */         
/* 313 */         this.left.generateCode(currentScope, codeStream, false);
/* 314 */         this.right.generateCode(currentScope, codeStream, valueRequired);
/*     */       
/*     */       }
/* 317 */       else if (valueRequired) {
/* 318 */         BranchLabel falseLabel = new BranchLabel(codeStream);
/* 319 */         this.left.generateCode(currentScope, codeStream, false);
/* 320 */         this.right.generateOptimizedBoolean(currentScope, codeStream, (BranchLabel)null, falseLabel, valueRequired);
/*     */         
/* 322 */         codeStream.iconst_0();
/* 323 */         if ((this.bits & 0x10) != 0) {
/* 324 */           codeStream.generateImplicitConversion(this.implicitConversion);
/* 325 */           codeStream.generateReturnBytecode(this);
/*     */           
/* 327 */           falseLabel.place();
/* 328 */           codeStream.iconst_1();
/*     */         } else {
/* 330 */           BranchLabel endLabel = new BranchLabel(codeStream);
/* 331 */           codeStream.goto_(endLabel);
/* 332 */           codeStream.decrStackSize(1);
/*     */           
/* 334 */           falseLabel.place();
/* 335 */           codeStream.iconst_1();
/* 336 */           endLabel.place();
/*     */         } 
/*     */       } else {
/* 339 */         this.left.generateCode(currentScope, codeStream, false);
/* 340 */         this.right.generateCode(currentScope, codeStream, false);
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       return;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 351 */     cst = this.right.optimizedBooleanConstant();
/* 352 */     if (cst != Constant.NotAConstant) {
/* 353 */       if (cst.booleanValue() == isEqualOperator) {
/*     */         
/* 355 */         this.left.generateCode(currentScope, codeStream, valueRequired);
/* 356 */         this.right.generateCode(currentScope, codeStream, false);
/*     */       
/*     */       }
/* 359 */       else if (valueRequired) {
/* 360 */         BranchLabel falseLabel = new BranchLabel(codeStream);
/* 361 */         this.left.generateOptimizedBoolean(currentScope, codeStream, (BranchLabel)null, falseLabel, valueRequired);
/* 362 */         this.right.generateCode(currentScope, codeStream, false);
/*     */         
/* 364 */         codeStream.iconst_0();
/* 365 */         if ((this.bits & 0x10) != 0) {
/* 366 */           codeStream.generateImplicitConversion(this.implicitConversion);
/* 367 */           codeStream.generateReturnBytecode(this);
/*     */           
/* 369 */           falseLabel.place();
/* 370 */           codeStream.iconst_1();
/*     */         } else {
/* 372 */           BranchLabel endLabel = new BranchLabel(codeStream);
/* 373 */           codeStream.goto_(endLabel);
/* 374 */           codeStream.decrStackSize(1);
/*     */           
/* 376 */           falseLabel.place();
/* 377 */           codeStream.iconst_1();
/* 378 */           endLabel.place();
/*     */         } 
/*     */       } else {
/* 381 */         this.left.generateCode(currentScope, codeStream, false);
/* 382 */         this.right.generateCode(currentScope, codeStream, false);
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       return;
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 394 */     this.left.generateCode(currentScope, codeStream, valueRequired);
/* 395 */     this.right.generateCode(currentScope, codeStream, valueRequired);
/*     */     
/* 397 */     if (valueRequired) {
/* 398 */       if (isEqualOperator) {
/*     */         BranchLabel falseLabel;
/* 400 */         codeStream.if_icmpne(falseLabel = new BranchLabel(codeStream));
/*     */         
/* 402 */         codeStream.iconst_1();
/* 403 */         if ((this.bits & 0x10) != 0) {
/* 404 */           codeStream.generateImplicitConversion(this.implicitConversion);
/* 405 */           codeStream.generateReturnBytecode(this);
/*     */           
/* 407 */           falseLabel.place();
/* 408 */           codeStream.iconst_0();
/*     */         } else {
/* 410 */           BranchLabel endLabel = new BranchLabel(codeStream);
/* 411 */           codeStream.goto_(endLabel);
/* 412 */           codeStream.decrStackSize(1);
/*     */           
/* 414 */           falseLabel.place();
/* 415 */           codeStream.iconst_0();
/* 416 */           endLabel.place();
/*     */         } 
/*     */       } else {
/* 419 */         codeStream.ixor();
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void generateOptimizedBooleanEqual(BlockScope currentScope, CodeStream codeStream, BranchLabel trueLabel, BranchLabel falseLabel, boolean valueRequired) {
/* 432 */     if (this.left.constant != Constant.NotAConstant) {
/* 433 */       boolean inline = this.left.constant.booleanValue();
/* 434 */       this.right.generateOptimizedBoolean(currentScope, codeStream, inline ? trueLabel : falseLabel, inline ? falseLabel : trueLabel, valueRequired);
/*     */       return;
/*     */     } 
/* 437 */     if (this.right.constant != Constant.NotAConstant) {
/* 438 */       boolean inline = this.right.constant.booleanValue();
/* 439 */       this.left.generateOptimizedBoolean(currentScope, codeStream, inline ? trueLabel : falseLabel, inline ? falseLabel : trueLabel, valueRequired);
/*     */       
/*     */       return;
/*     */     } 
/* 443 */     this.left.generateCode(currentScope, codeStream, valueRequired);
/* 444 */     this.right.generateCode(currentScope, codeStream, valueRequired);
/* 445 */     int pc = codeStream.position;
/* 446 */     if (valueRequired) {
/* 447 */       if (falseLabel == null) {
/* 448 */         if (trueLabel != null)
/*     */         {
/* 450 */           codeStream.if_icmpeq(trueLabel);
/*     */         
/*     */         }
/*     */       }
/* 454 */       else if (trueLabel == null) {
/* 455 */         codeStream.if_icmpne(falseLabel);
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 461 */     codeStream.recordPositionsFrom(pc, this.sourceEnd);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void generateNonBooleanEqual(BlockScope currentScope, CodeStream codeStream, boolean valueRequired) {
/* 469 */     boolean isEqualOperator = ((this.bits & 0x3F00) >> 8 == 18);
/* 470 */     if ((this.left.implicitConversion & 0xFF) >> 4 == 10) {
/*     */       Constant cst;
/* 472 */       if ((cst = this.left.constant) != Constant.NotAConstant && cst.intValue() == 0) {
/*     */         
/* 474 */         this.right.generateCode(currentScope, codeStream, valueRequired);
/* 475 */         if (valueRequired) {
/* 476 */           BranchLabel falseLabel = new BranchLabel(codeStream);
/* 477 */           if (isEqualOperator) {
/* 478 */             codeStream.ifne(falseLabel);
/*     */           } else {
/* 480 */             codeStream.ifeq(falseLabel);
/*     */           } 
/*     */           
/* 483 */           codeStream.iconst_1();
/* 484 */           if ((this.bits & 0x10) != 0) {
/* 485 */             codeStream.generateImplicitConversion(this.implicitConversion);
/* 486 */             codeStream.generateReturnBytecode(this);
/*     */             
/* 488 */             falseLabel.place();
/* 489 */             codeStream.iconst_0();
/*     */           } else {
/* 491 */             BranchLabel endLabel = new BranchLabel(codeStream);
/* 492 */             codeStream.goto_(endLabel);
/* 493 */             codeStream.decrStackSize(1);
/*     */             
/* 495 */             falseLabel.place();
/* 496 */             codeStream.iconst_0();
/* 497 */             endLabel.place();
/*     */           } 
/*     */         } 
/*     */         return;
/*     */       } 
/* 502 */       if ((cst = this.right.constant) != Constant.NotAConstant && cst.intValue() == 0) {
/*     */         
/* 504 */         this.left.generateCode(currentScope, codeStream, valueRequired);
/* 505 */         if (valueRequired) {
/* 506 */           BranchLabel falseLabel = new BranchLabel(codeStream);
/* 507 */           if (isEqualOperator) {
/* 508 */             codeStream.ifne(falseLabel);
/*     */           } else {
/* 510 */             codeStream.ifeq(falseLabel);
/*     */           } 
/*     */           
/* 513 */           codeStream.iconst_1();
/* 514 */           if ((this.bits & 0x10) != 0) {
/* 515 */             codeStream.generateImplicitConversion(this.implicitConversion);
/* 516 */             codeStream.generateReturnBytecode(this);
/*     */             
/* 518 */             falseLabel.place();
/* 519 */             codeStream.iconst_0();
/*     */           } else {
/* 521 */             BranchLabel endLabel = new BranchLabel(codeStream);
/* 522 */             codeStream.goto_(endLabel);
/* 523 */             codeStream.decrStackSize(1);
/*     */             
/* 525 */             falseLabel.place();
/* 526 */             codeStream.iconst_0();
/* 527 */             endLabel.place();
/*     */           } 
/*     */         } 
/*     */         
/*     */         return;
/*     */       } 
/*     */     } 
/*     */     
/* 535 */     if (this.right instanceof NullLiteral) {
/* 536 */       if (this.left instanceof NullLiteral) {
/*     */         
/* 538 */         if (valueRequired) {
/* 539 */           if (isEqualOperator) {
/* 540 */             codeStream.iconst_1();
/*     */           } else {
/* 542 */             codeStream.iconst_0();
/*     */           } 
/*     */         }
/*     */       } else {
/*     */         
/* 547 */         this.left.generateCode(currentScope, codeStream, valueRequired);
/* 548 */         if (valueRequired) {
/* 549 */           BranchLabel falseLabel = new BranchLabel(codeStream);
/* 550 */           if (isEqualOperator) {
/* 551 */             codeStream.ifnonnull(falseLabel);
/*     */           } else {
/* 553 */             codeStream.ifnull(falseLabel);
/*     */           } 
/*     */           
/* 556 */           codeStream.iconst_1();
/* 557 */           if ((this.bits & 0x10) != 0) {
/* 558 */             codeStream.generateImplicitConversion(this.implicitConversion);
/* 559 */             codeStream.generateReturnBytecode(this);
/*     */             
/* 561 */             falseLabel.place();
/* 562 */             codeStream.iconst_0();
/*     */           } else {
/* 564 */             BranchLabel endLabel = new BranchLabel(codeStream);
/* 565 */             codeStream.goto_(endLabel);
/* 566 */             codeStream.decrStackSize(1);
/*     */             
/* 568 */             falseLabel.place();
/* 569 */             codeStream.iconst_0();
/* 570 */             endLabel.place();
/*     */           } 
/*     */         } 
/*     */       }  return;
/*     */     } 
/* 575 */     if (this.left instanceof NullLiteral) {
/*     */       
/* 577 */       this.right.generateCode(currentScope, codeStream, valueRequired);
/* 578 */       if (valueRequired) {
/* 579 */         BranchLabel falseLabel = new BranchLabel(codeStream);
/* 580 */         if (isEqualOperator) {
/* 581 */           codeStream.ifnonnull(falseLabel);
/*     */         } else {
/* 583 */           codeStream.ifnull(falseLabel);
/*     */         } 
/*     */         
/* 586 */         codeStream.iconst_1();
/* 587 */         if ((this.bits & 0x10) != 0) {
/* 588 */           codeStream.generateImplicitConversion(this.implicitConversion);
/* 589 */           codeStream.generateReturnBytecode(this);
/*     */           
/* 591 */           falseLabel.place();
/* 592 */           codeStream.iconst_0();
/*     */         } else {
/* 594 */           BranchLabel endLabel = new BranchLabel(codeStream);
/* 595 */           codeStream.goto_(endLabel);
/* 596 */           codeStream.decrStackSize(1);
/*     */           
/* 598 */           falseLabel.place();
/* 599 */           codeStream.iconst_0();
/* 600 */           endLabel.place();
/*     */         } 
/*     */       } 
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/* 607 */     this.left.generateCode(currentScope, codeStream, valueRequired);
/* 608 */     this.right.generateCode(currentScope, codeStream, valueRequired);
/* 609 */     if (valueRequired) {
/* 610 */       BranchLabel falseLabel = new BranchLabel(codeStream);
/* 611 */       if (isEqualOperator) {
/* 612 */         switch ((this.left.implicitConversion & 0xFF) >> 4) {
/*     */           case 10:
/* 614 */             codeStream.if_icmpne(falseLabel);
/*     */             break;
/*     */           case 9:
/* 617 */             codeStream.fcmpl();
/* 618 */             codeStream.ifne(falseLabel);
/*     */             break;
/*     */           case 7:
/* 621 */             codeStream.lcmp();
/* 622 */             codeStream.ifne(falseLabel);
/*     */             break;
/*     */           case 8:
/* 625 */             codeStream.dcmpl();
/* 626 */             codeStream.ifne(falseLabel);
/*     */             break;
/*     */           default:
/* 629 */             codeStream.if_acmpne(falseLabel); break;
/*     */         } 
/*     */       } else {
/* 632 */         switch ((this.left.implicitConversion & 0xFF) >> 4) {
/*     */           case 10:
/* 634 */             codeStream.if_icmpeq(falseLabel);
/*     */             break;
/*     */           case 9:
/* 637 */             codeStream.fcmpl();
/* 638 */             codeStream.ifeq(falseLabel);
/*     */             break;
/*     */           case 7:
/* 641 */             codeStream.lcmp();
/* 642 */             codeStream.ifeq(falseLabel);
/*     */             break;
/*     */           case 8:
/* 645 */             codeStream.dcmpl();
/* 646 */             codeStream.ifeq(falseLabel);
/*     */             break;
/*     */           default:
/* 649 */             codeStream.if_acmpeq(falseLabel);
/*     */             break;
/*     */         } 
/*     */       } 
/* 653 */       codeStream.iconst_1();
/* 654 */       if ((this.bits & 0x10) != 0) {
/* 655 */         codeStream.generateImplicitConversion(this.implicitConversion);
/* 656 */         codeStream.generateReturnBytecode(this);
/*     */         
/* 658 */         falseLabel.place();
/* 659 */         codeStream.iconst_0();
/*     */       } else {
/* 661 */         BranchLabel endLabel = new BranchLabel(codeStream);
/* 662 */         codeStream.goto_(endLabel);
/* 663 */         codeStream.decrStackSize(1);
/*     */         
/* 665 */         falseLabel.place();
/* 666 */         codeStream.iconst_0();
/* 667 */         endLabel.place();
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void generateOptimizedNonBooleanEqual(BlockScope currentScope, CodeStream codeStream, BranchLabel trueLabel, BranchLabel falseLabel, boolean valueRequired) {
/* 678 */     int pc = codeStream.position;
/*     */     Constant inline;
/* 680 */     if ((inline = this.right.constant) != Constant.NotAConstant)
/*     */     {
/* 682 */       if ((this.left.implicitConversion & 0xFF) >> 4 == 10 && inline.intValue() == 0) {
/* 683 */         this.left.generateCode(currentScope, codeStream, valueRequired);
/* 684 */         if (valueRequired) {
/* 685 */           if (falseLabel == null) {
/* 686 */             if (trueLabel != null)
/*     */             {
/* 688 */               codeStream.ifeq(trueLabel);
/*     */             
/*     */             }
/*     */           }
/* 692 */           else if (trueLabel == null) {
/* 693 */             codeStream.ifne(falseLabel);
/*     */           } 
/*     */         }
/*     */ 
/*     */ 
/*     */         
/* 699 */         codeStream.recordPositionsFrom(pc, this.sourceStart);
/*     */         return;
/*     */       } 
/*     */     }
/* 703 */     if ((inline = this.left.constant) != Constant.NotAConstant)
/*     */     {
/* 705 */       if ((this.left.implicitConversion & 0xFF) >> 4 == 10 && 
/* 706 */         inline.intValue() == 0) {
/* 707 */         this.right.generateCode(currentScope, codeStream, valueRequired);
/* 708 */         if (valueRequired) {
/* 709 */           if (falseLabel == null) {
/* 710 */             if (trueLabel != null)
/*     */             {
/* 712 */               codeStream.ifeq(trueLabel);
/*     */             
/*     */             }
/*     */           }
/* 716 */           else if (trueLabel == null) {
/* 717 */             codeStream.ifne(falseLabel);
/*     */           } 
/*     */         }
/*     */ 
/*     */ 
/*     */         
/* 723 */         codeStream.recordPositionsFrom(pc, this.sourceStart);
/*     */         
/*     */         return;
/*     */       } 
/*     */     }
/*     */     
/* 729 */     if (this.right instanceof NullLiteral) {
/* 730 */       if (this.left instanceof NullLiteral) {
/*     */         
/* 732 */         if (valueRequired && 
/* 733 */           falseLabel == null)
/*     */         {
/* 735 */           if (trueLabel != null) {
/* 736 */             codeStream.goto_(trueLabel);
/*     */           }
/*     */         }
/*     */       } else {
/*     */         
/* 741 */         this.left.generateCode(currentScope, codeStream, valueRequired);
/* 742 */         if (valueRequired) {
/* 743 */           if (falseLabel == null) {
/* 744 */             if (trueLabel != null)
/*     */             {
/* 746 */               codeStream.ifnull(trueLabel);
/*     */             
/*     */             }
/*     */           }
/* 750 */           else if (trueLabel == null) {
/* 751 */             codeStream.ifnonnull(falseLabel);
/*     */           } 
/*     */         }
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 758 */       codeStream.recordPositionsFrom(pc, this.sourceStart); return;
/*     */     } 
/* 760 */     if (this.left instanceof NullLiteral) {
/* 761 */       this.right.generateCode(currentScope, codeStream, valueRequired);
/* 762 */       if (valueRequired) {
/* 763 */         if (falseLabel == null) {
/* 764 */           if (trueLabel != null)
/*     */           {
/* 766 */             codeStream.ifnull(trueLabel);
/*     */           
/*     */           }
/*     */         }
/* 770 */         else if (trueLabel == null) {
/* 771 */           codeStream.ifnonnull(falseLabel);
/*     */         } 
/*     */       }
/*     */ 
/*     */ 
/*     */       
/* 777 */       codeStream.recordPositionsFrom(pc, this.sourceStart);
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/* 782 */     this.left.generateCode(currentScope, codeStream, valueRequired);
/* 783 */     this.right.generateCode(currentScope, codeStream, valueRequired);
/* 784 */     if (valueRequired) {
/* 785 */       if (falseLabel == null) {
/* 786 */         if (trueLabel != null)
/*     */         {
/* 788 */           switch ((this.left.implicitConversion & 0xFF) >> 4) {
/*     */             case 10:
/* 790 */               codeStream.if_icmpeq(trueLabel);
/*     */               break;
/*     */             case 9:
/* 793 */               codeStream.fcmpl();
/* 794 */               codeStream.ifeq(trueLabel);
/*     */               break;
/*     */             case 7:
/* 797 */               codeStream.lcmp();
/* 798 */               codeStream.ifeq(trueLabel);
/*     */               break;
/*     */             case 8:
/* 801 */               codeStream.dcmpl();
/* 802 */               codeStream.ifeq(trueLabel);
/*     */               break;
/*     */             default:
/* 805 */               codeStream.if_acmpeq(trueLabel);
/*     */               break;
/*     */           } 
/*     */         
/*     */         }
/* 810 */       } else if (trueLabel == null) {
/* 811 */         switch ((this.left.implicitConversion & 0xFF) >> 4) {
/*     */           case 10:
/* 813 */             codeStream.if_icmpne(falseLabel);
/*     */             break;
/*     */           case 9:
/* 816 */             codeStream.fcmpl();
/* 817 */             codeStream.ifne(falseLabel);
/*     */             break;
/*     */           case 7:
/* 820 */             codeStream.lcmp();
/* 821 */             codeStream.ifne(falseLabel);
/*     */             break;
/*     */           case 8:
/* 824 */             codeStream.dcmpl();
/* 825 */             codeStream.ifne(falseLabel);
/*     */             break;
/*     */           default:
/* 828 */             codeStream.if_acmpne(falseLabel);
/*     */             break;
/*     */         } 
/*     */ 
/*     */       
/*     */       } 
/*     */     }
/* 835 */     codeStream.recordPositionsFrom(pc, this.sourceStart);
/*     */   }
/*     */   
/*     */   public boolean isCompactableOperation() {
/* 839 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   protected Constant optimizedNullComparisonConstant() {
/* 844 */     int operator = (this.bits & 0x3F00) >> 8;
/* 845 */     if (operator == 18) {
/* 846 */       if (this.left instanceof NullLiteral && this.right instanceof NullLiteral) {
/* 847 */         return BooleanConstant.fromValue(true);
/*     */       }
/* 849 */     } else if (operator == 29 && 
/* 850 */       this.left instanceof NullLiteral && this.right instanceof NullLiteral) {
/* 851 */       return BooleanConstant.fromValue(false);
/*     */     } 
/*     */     
/* 854 */     return Constant.NotAConstant;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public TypeBinding resolveType(BlockScope scope) {
/*     */     boolean leftIsCast;
/* 861 */     if (leftIsCast = this.left instanceof CastExpression) this.left.bits |= 0x20; 
/* 862 */     TypeBinding originalLeftType = this.left.resolveType(scope);
/*     */     boolean rightIsCast;
/* 864 */     if (rightIsCast = this.right instanceof CastExpression) this.right.bits |= 0x20; 
/* 865 */     TypeBinding originalRightType = this.right.resolveType(scope);
/*     */ 
/*     */     
/* 868 */     if (originalLeftType == null || originalRightType == null) {
/* 869 */       this.constant = Constant.NotAConstant;
/* 870 */       return null;
/*     */     } 
/*     */     
/* 873 */     CompilerOptions compilerOptions = scope.compilerOptions();
/* 874 */     if (compilerOptions.complainOnUninternedIdentityComparison && originalRightType.hasTypeBit(16) && originalLeftType.hasTypeBit(16)) {
/* 875 */       scope.problemReporter().uninternedIdentityComparison(this, originalLeftType, originalRightType, scope.referenceCompilationUnit());
/*     */     }
/*     */     
/* 878 */     boolean use15specifics = (compilerOptions.sourceLevel >= 3211264L);
/* 879 */     TypeBinding leftType = originalLeftType, rightType = originalRightType;
/* 880 */     if (use15specifics) {
/* 881 */       if (leftType != TypeBinding.NULL && leftType.isBaseType()) {
/* 882 */         if (!rightType.isBaseType()) {
/* 883 */           rightType = scope.environment().computeBoxingType(rightType);
/*     */         }
/*     */       }
/* 886 */       else if (rightType != TypeBinding.NULL && rightType.isBaseType()) {
/* 887 */         leftType = scope.environment().computeBoxingType(leftType);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/* 892 */     if (leftType.isBaseType() && rightType.isBaseType()) {
/* 893 */       int leftTypeID = leftType.id;
/* 894 */       int rightTypeID = rightType.id;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 900 */       int operatorSignature = OperatorSignatures[18][(leftTypeID << 4) + rightTypeID];
/* 901 */       this.left.computeConversion((Scope)scope, TypeBinding.wellKnownType((Scope)scope, operatorSignature >>> 16 & 0xF), originalLeftType);
/* 902 */       this.right.computeConversion((Scope)scope, TypeBinding.wellKnownType((Scope)scope, operatorSignature >>> 8 & 0xF), originalRightType);
/* 903 */       this.bits |= operatorSignature & 0xF;
/* 904 */       if ((operatorSignature & 0xF) == 0) {
/* 905 */         this.constant = Constant.NotAConstant;
/* 906 */         scope.problemReporter().invalidOperator(this, leftType, rightType);
/* 907 */         return null;
/*     */       } 
/*     */       
/* 910 */       if (leftIsCast || rightIsCast) {
/* 911 */         CastExpression.checkNeedForArgumentCasts(scope, 18, operatorSignature, this.left, leftType.id, leftIsCast, this.right, rightType.id, rightIsCast);
/*     */       }
/* 913 */       computeConstant(leftType, rightType);
/*     */ 
/*     */       
/* 916 */       Binding leftDirect = Expression.getDirectBinding(this.left);
/* 917 */       if (leftDirect != null && leftDirect == Expression.getDirectBinding(this.right)) {
/* 918 */         if (leftTypeID != 8 && leftTypeID != 9 && 
/* 919 */           !(this.right instanceof Assignment))
/* 920 */           scope.problemReporter().comparingIdenticalExpressions(this); 
/* 921 */       } else if (this.constant != Constant.NotAConstant) {
/*     */         
/* 923 */         int operator = (this.bits & 0x3F00) >> 8;
/* 924 */         if ((operator == 18 && this.constant == BooleanConstant.fromValue(true)) || (
/* 925 */           operator == 29 && this.constant == BooleanConstant.fromValue(false)))
/* 926 */           scope.problemReporter().comparingIdenticalExpressions(this); 
/*     */       } 
/* 928 */       return this.resolvedType = (TypeBinding)TypeBinding.BOOLEAN;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 933 */     if ((!leftType.isBaseType() || leftType == TypeBinding.NULL) && (
/* 934 */       !rightType.isBaseType() || rightType == TypeBinding.NULL) && (
/* 935 */       checkCastTypesCompatibility((Scope)scope, leftType, rightType, (Expression)null, true) || 
/* 936 */       checkCastTypesCompatibility((Scope)scope, rightType, leftType, (Expression)null, true))) {
/*     */ 
/*     */       
/* 939 */       if (rightType.id == 11 && leftType.id == 11) {
/* 940 */         computeConstant(leftType, rightType);
/*     */       } else {
/* 942 */         this.constant = Constant.NotAConstant;
/*     */       } 
/* 944 */       ReferenceBinding referenceBinding = scope.getJavaLangObject();
/* 945 */       this.left.computeConversion((Scope)scope, (TypeBinding)referenceBinding, leftType);
/* 946 */       this.right.computeConversion((Scope)scope, (TypeBinding)referenceBinding, rightType);
/*     */       
/* 948 */       boolean unnecessaryLeftCast = ((this.left.bits & 0x4000) != 0);
/* 949 */       boolean unnecessaryRightCast = ((this.right.bits & 0x4000) != 0);
/* 950 */       if (unnecessaryLeftCast || unnecessaryRightCast) {
/* 951 */         TypeBinding alternateLeftType = unnecessaryLeftCast ? ((CastExpression)this.left).expression.resolvedType : leftType;
/* 952 */         TypeBinding alternateRightType = unnecessaryRightCast ? ((CastExpression)this.right).expression.resolvedType : rightType;
/*     */         
/* 954 */         if (!isCastNeeded(alternateLeftType, alternateRightType) && (
/* 955 */           checkCastTypesCompatibility((Scope)scope, alternateLeftType, alternateRightType, (Expression)null, false) || 
/* 956 */           checkCastTypesCompatibility((Scope)scope, alternateRightType, alternateLeftType, (Expression)null, false))) {
/* 957 */           if (unnecessaryLeftCast) scope.problemReporter().unnecessaryCast((CastExpression)this.left); 
/* 958 */           if (unnecessaryRightCast) scope.problemReporter().unnecessaryCast((CastExpression)this.right);
/*     */         
/*     */         } 
/*     */       } 
/*     */       
/* 963 */       Binding leftDirect = Expression.getDirectBinding(this.left);
/* 964 */       if (leftDirect != null && leftDirect == Expression.getDirectBinding(this.right) && 
/* 965 */         !(this.right instanceof Assignment)) {
/* 966 */         scope.problemReporter().comparingIdenticalExpressions(this);
/*     */       }
/*     */       
/* 969 */       return this.resolvedType = (TypeBinding)TypeBinding.BOOLEAN;
/*     */     } 
/* 971 */     this.constant = Constant.NotAConstant;
/* 972 */     scope.problemReporter().notCompatibleTypesError(this, leftType, rightType);
/* 973 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean isCastNeeded(TypeBinding leftType, TypeBinding rightType) {
/* 980 */     if (leftType.isParameterizedType()) {
/* 981 */       return rightType.isBaseType();
/*     */     }
/* 983 */     if (rightType.isParameterizedType()) {
/* 984 */       return leftType.isBaseType();
/*     */     }
/* 986 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public void traverse(ASTVisitor visitor, BlockScope scope) {
/* 991 */     if (visitor.visit(this, scope)) {
/* 992 */       this.left.traverse(visitor, scope);
/* 993 */       this.right.traverse(visitor, scope);
/*     */     } 
/* 995 */     visitor.endVisit(this, scope);
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\ast\EqualExpression.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */