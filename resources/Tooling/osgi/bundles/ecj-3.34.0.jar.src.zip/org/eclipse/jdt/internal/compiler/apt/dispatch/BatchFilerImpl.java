/*     */ package org.eclipse.jdt.internal.compiler.apt.dispatch;
/*     */ 
/*     */ import java.io.FileNotFoundException;
/*     */ import java.io.IOException;
/*     */ import java.net.URI;
/*     */ import java.util.HashSet;
/*     */ import javax.annotation.processing.Filer;
/*     */ import javax.annotation.processing.FilerException;
/*     */ import javax.lang.model.element.Element;
/*     */ import javax.lang.model.element.TypeElement;
/*     */ import javax.tools.FileObject;
/*     */ import javax.tools.JavaFileManager;
/*     */ import javax.tools.JavaFileObject;
/*     */ import javax.tools.StandardLocation;
/*     */ import org.eclipse.jdt.internal.compiler.env.ICompilationUnit;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.ReferenceBinding;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BatchFilerImpl
/*     */   implements Filer
/*     */ {
/*     */   protected final BaseAnnotationProcessorManager _dispatchManager;
/*     */   protected final BatchProcessingEnvImpl _env;
/*     */   protected final JavaFileManager _fileManager;
/*     */   protected final HashSet<URI> _createdFiles;
/*     */   
/*     */   public BatchFilerImpl(BaseAnnotationProcessorManager dispatchManager, BatchProcessingEnvImpl env) {
/*  51 */     this._dispatchManager = dispatchManager;
/*  52 */     this._fileManager = env._fileManager;
/*  53 */     this._env = env;
/*  54 */     this._createdFiles = new HashSet<>();
/*     */   }
/*     */   
/*     */   public void addNewUnit(ICompilationUnit unit) {
/*  58 */     this._env.addNewUnit(unit);
/*     */   }
/*     */   
/*     */   public void addNewClassFile(ReferenceBinding binding) {
/*  62 */     this._env.addNewClassFile(binding);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JavaFileObject createClassFile(CharSequence name, Element... originatingElements) throws IOException {
/*  71 */     JavaFileObject jfo = this._fileManager.getJavaFileForOutput(
/*  72 */         StandardLocation.CLASS_OUTPUT, name.toString(), JavaFileObject.Kind.CLASS, null);
/*  73 */     URI uri = jfo.toUri();
/*  74 */     if (this._createdFiles.contains(uri)) {
/*  75 */       throw new FilerException("Class file already created : " + name);
/*     */     }
/*     */     
/*  78 */     this._createdFiles.add(uri);
/*  79 */     return new HookedJavaFileObject(jfo, jfo.getName(), name.toString(), this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public FileObject createResource(JavaFileManager.Location location, CharSequence pkg, CharSequence relativeName, Element... originatingElements) throws IOException {
/*  89 */     validateName(relativeName);
/*  90 */     FileObject fo = this._fileManager.getFileForOutput(
/*  91 */         location, pkg.toString(), relativeName.toString(), null);
/*  92 */     URI uri = fo.toUri();
/*  93 */     if (this._createdFiles.contains(uri)) {
/*  94 */       throw new FilerException("Resource already created : " + location + '/' + pkg + '/' + relativeName);
/*     */     }
/*     */     
/*  97 */     this._createdFiles.add(uri);
/*  98 */     return fo;
/*     */   }
/*     */   
/*     */   private static void validateName(CharSequence relativeName) {
/* 102 */     int length = relativeName.length();
/* 103 */     if (length == 0) {
/* 104 */       throw new IllegalArgumentException("relative path cannot be empty");
/*     */     }
/* 106 */     String path = relativeName.toString();
/* 107 */     if (path.indexOf('\\') != -1)
/*     */     {
/* 109 */       path = path.replace('\\', '/');
/*     */     }
/* 111 */     if (path.charAt(0) == '/') {
/* 112 */       throw new IllegalArgumentException("relative path is absolute");
/*     */     }
/* 114 */     boolean hasDot = false;
/* 115 */     for (int i = 0; i < length; i++) {
/* 116 */       switch (path.charAt(i)) {
/*     */         case '/':
/* 118 */           if (hasDot) {
/* 119 */             throw new IllegalArgumentException("relative name " + relativeName + " is not relative");
/*     */           }
/*     */           break;
/*     */         case '.':
/* 123 */           hasDot = true;
/*     */           break;
/*     */         default:
/* 126 */           hasDot = false; break;
/*     */       } 
/*     */     } 
/* 129 */     if (hasDot) {
/* 130 */       throw new IllegalArgumentException("relative name " + relativeName + " is not relative");
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JavaFileObject createSourceFile(CharSequence name, Element... originatingElements) throws IOException {
/* 140 */     String moduleAndPkgString = name.toString();
/* 141 */     int slash = moduleAndPkgString.indexOf('/');
/* 142 */     String mod = null;
/* 143 */     if (slash != -1) {
/* 144 */       name = moduleAndPkgString.substring(slash + 1, name.length());
/* 145 */       mod = moduleAndPkgString.substring(0, slash);
/*     */     } 
/* 147 */     TypeElement typeElement = this._env._elementUtils.getTypeElement(name);
/* 148 */     if (typeElement != null) {
/* 149 */       throw new FilerException("Source file already exists : " + moduleAndPkgString);
/*     */     }
/* 151 */     JavaFileManager.Location location = (mod == null) ? StandardLocation.SOURCE_OUTPUT : this._fileManager.getLocationForModule(StandardLocation.SOURCE_OUTPUT, mod);
/* 152 */     JavaFileObject jfo = this._fileManager.getJavaFileForOutput(location, name.toString(), JavaFileObject.Kind.SOURCE, null);
/* 153 */     URI uri = jfo.toUri();
/* 154 */     if (this._createdFiles.contains(uri)) {
/* 155 */       throw new FilerException("Source file already created : " + name);
/*     */     }
/*     */     
/* 158 */     this._createdFiles.add(uri);
/*     */     
/* 160 */     return new HookedJavaFileObject(jfo, jfo.getName(), name.toString(), this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public FileObject getResource(JavaFileManager.Location location, CharSequence pkg, CharSequence relativeName) throws IOException {
/* 169 */     validateName(relativeName);
/* 170 */     FileObject fo = this._fileManager.getFileForInput(
/* 171 */         location, pkg.toString(), relativeName.toString());
/* 172 */     if (fo == null) {
/* 173 */       throw new FileNotFoundException("Resource does not exist : " + location + '/' + pkg + '/' + relativeName);
/*     */     }
/* 175 */     URI uri = fo.toUri();
/* 176 */     if (this._createdFiles.contains(uri)) {
/* 177 */       throw new FilerException("Resource already created : " + location + '/' + pkg + '/' + relativeName);
/*     */     }
/* 179 */     return fo;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\apt\dispatch\BatchFilerImpl.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */