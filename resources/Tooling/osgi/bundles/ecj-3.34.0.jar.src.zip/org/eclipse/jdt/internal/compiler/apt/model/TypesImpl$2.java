/*     */ package org.eclipse.jdt.internal.compiler.apt.model;
/*     */ 
/*     */ import javax.lang.model.type.TypeMirror;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.Binding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.ParameterizedTypeBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.ReferenceBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.TypeBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.TypeVariableBinding;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class null
/*     */   implements TypesImpl.MemberInTypeFinder
/*     */ {
/*     */   public TypeMirror find(ReferenceBinding typeBinding, Binding memberBinding) {
/* 117 */     if (typeBinding instanceof ParameterizedTypeBinding) {
/* 118 */       TypeVariableBinding variableBinding = (TypeVariableBinding)memberBinding;
/* 119 */       ReferenceBinding binding = ((ParameterizedTypeBinding)typeBinding).genericType();
/* 120 */       if (variableBinding.declaringElement == binding) {
/* 121 */         TypeVariableBinding[] typeVariables = binding.typeVariables();
/* 122 */         TypeBinding[] typeArguments = ((ParameterizedTypeBinding)typeBinding).typeArguments();
/* 123 */         if (typeVariables.length == typeArguments.length) {
/* 124 */           for (int i = 0; i < typeVariables.length; i++) {
/* 125 */             if (typeVariables[i] == memberBinding) {
/* 126 */               return TypesImpl.this._env.getFactory().newTypeMirror((Binding)typeArguments[i]);
/*     */             }
/*     */           } 
/*     */         }
/*     */       } 
/*     */     } 
/* 132 */     return null;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\apt\model\TypesImpl$2.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */