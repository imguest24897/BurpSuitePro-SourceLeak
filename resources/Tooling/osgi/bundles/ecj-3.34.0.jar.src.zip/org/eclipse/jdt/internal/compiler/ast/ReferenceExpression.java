/*      */ package org.eclipse.jdt.internal.compiler.ast;
/*      */ 
/*      */ import java.util.HashMap;
/*      */ import org.eclipse.jdt.core.compiler.CharOperation;
/*      */ import org.eclipse.jdt.internal.compiler.ASTVisitor;
/*      */ import org.eclipse.jdt.internal.compiler.CompilationResult;
/*      */ import org.eclipse.jdt.internal.compiler.IErrorHandlingPolicy;
/*      */ import org.eclipse.jdt.internal.compiler.codegen.CodeStream;
/*      */ import org.eclipse.jdt.internal.compiler.codegen.ConstantPool;
/*      */ import org.eclipse.jdt.internal.compiler.flow.FieldInitsFakingFlowContext;
/*      */ import org.eclipse.jdt.internal.compiler.flow.FlowContext;
/*      */ import org.eclipse.jdt.internal.compiler.flow.FlowInfo;
/*      */ import org.eclipse.jdt.internal.compiler.flow.UnconditionalFlowInfo;
/*      */ import org.eclipse.jdt.internal.compiler.impl.CompilerOptions;
/*      */ import org.eclipse.jdt.internal.compiler.impl.Constant;
/*      */ import org.eclipse.jdt.internal.compiler.impl.IrritantSet;
/*      */ import org.eclipse.jdt.internal.compiler.impl.ReferenceContext;
/*      */ import org.eclipse.jdt.internal.compiler.lookup.AnnotationBinding;
/*      */ import org.eclipse.jdt.internal.compiler.lookup.ArrayBinding;
/*      */ import org.eclipse.jdt.internal.compiler.lookup.Binding;
/*      */ import org.eclipse.jdt.internal.compiler.lookup.BlockScope;
/*      */ import org.eclipse.jdt.internal.compiler.lookup.ImplicitNullAnnotationVerifier;
/*      */ import org.eclipse.jdt.internal.compiler.lookup.InferenceContext18;
/*      */ import org.eclipse.jdt.internal.compiler.lookup.InvocationSite;
/*      */ import org.eclipse.jdt.internal.compiler.lookup.LocalTypeBinding;
/*      */ import org.eclipse.jdt.internal.compiler.lookup.LocalVariableBinding;
/*      */ import org.eclipse.jdt.internal.compiler.lookup.MethodBinding;
/*      */ import org.eclipse.jdt.internal.compiler.lookup.ParameterizedGenericMethodBinding;
/*      */ import org.eclipse.jdt.internal.compiler.lookup.ParameterizedMethodBinding;
/*      */ import org.eclipse.jdt.internal.compiler.lookup.ParameterizedTypeBinding;
/*      */ import org.eclipse.jdt.internal.compiler.lookup.PolyTypeBinding;
/*      */ import org.eclipse.jdt.internal.compiler.lookup.ProblemReferenceBinding;
/*      */ import org.eclipse.jdt.internal.compiler.lookup.ReferenceBinding;
/*      */ import org.eclipse.jdt.internal.compiler.lookup.Scope;
/*      */ import org.eclipse.jdt.internal.compiler.lookup.SourceTypeBinding;
/*      */ import org.eclipse.jdt.internal.compiler.lookup.SyntheticArgumentBinding;
/*      */ import org.eclipse.jdt.internal.compiler.lookup.TypeBinding;
/*      */ import org.eclipse.jdt.internal.compiler.lookup.TypeConstants;
/*      */ import org.eclipse.jdt.internal.compiler.lookup.TypeVariableBinding;
/*      */ import org.eclipse.jdt.internal.compiler.parser.Parser;
/*      */ import org.eclipse.jdt.internal.compiler.parser.Scanner;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class ReferenceExpression
/*      */   extends FunctionalExpression
/*      */   implements IPolyExpression, InvocationSite
/*      */ {
/*      */   private static final String SecretReceiverVariableName = " rec_";
/*  102 */   private static final char[] ImplicitArgName = " arg".toCharArray();
/*      */   
/*      */   public LocalVariableBinding receiverVariable;
/*      */   
/*      */   public Expression lhs;
/*      */   
/*      */   public TypeReference[] typeArguments;
/*      */   
/*      */   public char[] selector;
/*      */   public int nameSourceStart;
/*      */   public TypeBinding receiverType;
/*      */   public boolean haveReceiver;
/*      */   public TypeBinding[] resolvedTypeArguments;
/*      */   private boolean typeArgumentsHaveErrors;
/*      */   MethodBinding syntheticAccessor;
/*      */   private int depth;
/*      */   private MethodBinding exactMethodBinding;
/*      */   private boolean receiverPrecedesParameters = false;
/*      */   private TypeBinding[] freeParameters;
/*      */   private boolean checkingPotentialCompatibility;
/*  122 */   private MethodBinding[] potentialMethods = Binding.NO_METHODS;
/*      */   
/*      */   protected ReferenceExpression original;
/*      */   
/*      */   private HashMap<TypeBinding, ReferenceExpression> copiesPerTargetType;
/*      */   
/*      */   private HashMap<ParameterizedGenericMethodBinding, InferenceContext18> inferenceContexts;
/*      */   
/*      */   private Scanner scanner;
/*      */   
/*      */   public ReferenceExpression(Scanner scanner) {
/*  133 */     this.original = this;
/*  134 */     this.scanner = scanner;
/*      */   }
/*      */   
/*      */   public void initialize(CompilationResult result, Expression expression, TypeReference[] optionalTypeArguments, char[] identifierOrNew, int sourceEndPosition) {
/*  138 */     setCompilationResult(result);
/*  139 */     this.lhs = expression;
/*  140 */     this.typeArguments = optionalTypeArguments;
/*  141 */     this.selector = identifierOrNew;
/*  142 */     this.sourceStart = expression.sourceStart;
/*  143 */     this.sourceEnd = sourceEndPosition;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private ReferenceExpression copy() {
/*  150 */     Parser parser = new Parser(this.enclosingScope.problemReporter(), false);
/*  151 */     char[] source = new char[this.sourceEnd + 1];
/*  152 */     System.arraycopy(this.text, 0, source, this.sourceStart, this.sourceEnd - this.sourceStart + 1);
/*  153 */     parser.scanner = this.scanner;
/*  154 */     ReferenceExpression copy = (ReferenceExpression)parser.parseExpression(source, this.sourceStart, this.sourceEnd - this.sourceStart + 1, 
/*  155 */         this.enclosingScope.referenceCompilationUnit(), false);
/*  156 */     copy.original = this;
/*  157 */     copy.sourceStart = this.sourceStart;
/*  158 */     copy.sourceEnd = this.sourceEnd;
/*  159 */     copy.text = this.text;
/*  160 */     return copy;
/*      */   }
/*      */   
/*      */   private boolean shouldGenerateSecretReceiverVariable() {
/*  164 */     if (isMethodReference() && this.haveReceiver) {
/*  165 */       if (this.lhs instanceof Invocation) {
/*  166 */         return true;
/*      */       }
/*  168 */       return (new ASTVisitor()
/*      */         {
/*      */           boolean accessesnonFinalOuterLocals;
/*      */           
/*      */           public boolean visit(SingleNameReference name, BlockScope skope) {
/*  173 */             Binding local = skope.getBinding(name.getName(), ReferenceExpression.this);
/*  174 */             if (local instanceof LocalVariableBinding) {
/*  175 */               LocalVariableBinding localBinding = (LocalVariableBinding)local;
/*  176 */               if (!localBinding.isFinal() && !localBinding.isEffectivelyFinal()) {
/*  177 */                 this.accessesnonFinalOuterLocals = true;
/*      */               }
/*      */             } 
/*  180 */             return false;
/*      */           }
/*      */           
/*      */           public boolean accessesnonFinalOuterLocals() {
/*  184 */             ReferenceExpression.this.lhs.traverse(this, ReferenceExpression.this.enclosingScope);
/*  185 */             return this.accessesnonFinalOuterLocals;
/*      */           }
/*  187 */         }).accessesnonFinalOuterLocals();
/*      */     } 
/*      */     
/*  190 */     return false;
/*      */   }
/*      */   
/*      */   public void generateImplicitLambda(BlockScope currentScope, CodeStream codeStream, boolean valueRequired) {
/*  194 */     ReferenceExpression copy = copy();
/*      */     
/*  196 */     int argc = this.descriptor.parameters.length;
/*      */     
/*  198 */     LambdaExpression implicitLambda = new LambdaExpression(this.compilationResult, false, ((this.binding.modifiers & 0x40000000) != 0));
/*  199 */     Argument[] arguments = new Argument[argc];
/*  200 */     for (int i = 0; i < argc; i++)
/*  201 */       arguments[i] = new Argument(CharOperation.append(ImplicitArgName, Integer.toString(i).toCharArray()), 0L, null, 0, true); 
/*  202 */     implicitLambda.setArguments(arguments);
/*  203 */     implicitLambda.setExpressionContext(this.expressionContext);
/*  204 */     implicitLambda.setExpectedType(this.expectedType);
/*      */     
/*  206 */     int parameterShift = this.receiverPrecedesParameters ? 1 : 0;
/*  207 */     SingleNameReference[] arrayOfSingleNameReference = new SingleNameReference[argc - parameterShift];
/*  208 */     for (int j = 0, length = arrayOfSingleNameReference.length; j < length; j++) {
/*  209 */       char[] name = CharOperation.append(ImplicitArgName, Integer.toString(j + parameterShift).toCharArray());
/*  210 */       arrayOfSingleNameReference[j] = new SingleNameReference(name, 0L);
/*      */     } 
/*  212 */     boolean generateSecretReceiverVariable = shouldGenerateSecretReceiverVariable();
/*  213 */     if (isMethodReference()) {
/*  214 */       if (generateSecretReceiverVariable) {
/*  215 */         this.lhs.generateCode(currentScope, codeStream, true);
/*  216 */         codeStream.store(this.receiverVariable, false);
/*  217 */         codeStream.addVariable(this.receiverVariable);
/*      */       } 
/*  219 */       MessageSend message = new MessageSend();
/*  220 */       message.selector = this.selector;
/*  221 */       Expression receiver = generateSecretReceiverVariable ? new SingleNameReference(this.receiverVariable.name, 0L) : copy.lhs;
/*  222 */       message.receiver = this.receiverPrecedesParameters ? 
/*  223 */         new SingleNameReference(CharOperation.append(ImplicitArgName, Integer.toString(0).toCharArray()), 0L) : receiver;
/*  224 */       message.typeArguments = copy.typeArguments;
/*  225 */       message.arguments = (Expression[])arrayOfSingleNameReference;
/*  226 */       implicitLambda.setBody(message);
/*  227 */     } else if (isArrayConstructorReference()) {
/*      */       
/*  229 */       ArrayAllocationExpression arrayAllocationExpression = new ArrayAllocationExpression();
/*  230 */       arrayAllocationExpression.dimensions = new Expression[] { arrayOfSingleNameReference[0] };
/*  231 */       if (this.lhs instanceof ArrayTypeReference) {
/*  232 */         ArrayTypeReference arrayTypeReference = (ArrayTypeReference)this.lhs;
/*  233 */         arrayAllocationExpression.type = (arrayTypeReference.dimensions == 1) ? new SingleTypeReference(arrayTypeReference.token, 0L) : 
/*  234 */           new ArrayTypeReference(arrayTypeReference.token, arrayTypeReference.dimensions - 1, 0L);
/*      */       } else {
/*  236 */         ArrayQualifiedTypeReference arrayQualifiedTypeReference = (ArrayQualifiedTypeReference)this.lhs;
/*  237 */         arrayAllocationExpression.type = (arrayQualifiedTypeReference.dimensions == 1) ? new QualifiedTypeReference(arrayQualifiedTypeReference.tokens, arrayQualifiedTypeReference.sourcePositions) : 
/*  238 */           new ArrayQualifiedTypeReference(arrayQualifiedTypeReference.tokens, arrayQualifiedTypeReference.dimensions - 1, 
/*  239 */             arrayQualifiedTypeReference.sourcePositions);
/*      */       } 
/*  241 */       implicitLambda.setBody(arrayAllocationExpression);
/*      */     } else {
/*  243 */       AllocationExpression allocation = new AllocationExpression();
/*  244 */       if (this.lhs instanceof TypeReference) {
/*  245 */         allocation.type = (TypeReference)this.lhs;
/*  246 */       } else if (this.lhs instanceof SingleNameReference) {
/*  247 */         allocation.type = new SingleTypeReference(((SingleNameReference)this.lhs).token, 0L);
/*  248 */       } else if (this.lhs instanceof QualifiedNameReference) {
/*  249 */         allocation.type = new QualifiedTypeReference(((QualifiedNameReference)this.lhs).tokens, new long[((QualifiedNameReference)this.lhs).tokens.length]);
/*      */       } else {
/*  251 */         throw new IllegalStateException("Unexpected node type");
/*      */       } 
/*  253 */       allocation.typeArguments = copy.typeArguments;
/*  254 */       allocation.arguments = (Expression[])arrayOfSingleNameReference;
/*  255 */       implicitLambda.setBody(allocation);
/*      */     } 
/*      */ 
/*      */     
/*  259 */     BlockScope lambdaScope = (this.receiverVariable != null) ? this.receiverVariable.declaringScope : currentScope;
/*  260 */     IErrorHandlingPolicy oldPolicy = lambdaScope.problemReporter().switchErrorHandlingPolicy(silentErrorHandlingPolicy);
/*      */     try {
/*  262 */       implicitLambda.resolveType(lambdaScope, true);
/*  263 */       implicitLambda.analyseCode(lambdaScope, 
/*  264 */           (FlowContext)new FieldInitsFakingFlowContext(null, this, Binding.NO_EXCEPTIONS, null, lambdaScope, FlowInfo.DEAD_END), 
/*  265 */           (FlowInfo)UnconditionalFlowInfo.fakeInitializedFlowInfo((lambdaScope.outerMostMethodScope()).analysisIndex, (lambdaScope.referenceType()).maxFieldCount));
/*      */     } finally {
/*  267 */       lambdaScope.problemReporter().switchErrorHandlingPolicy(oldPolicy);
/*      */     } 
/*  269 */     SyntheticArgumentBinding[] outerLocals = this.receiverType.syntheticOuterLocalVariables();
/*  270 */     for (int k = 0, m = (outerLocals == null) ? 0 : outerLocals.length; k < m; k++) {
/*  271 */       implicitLambda.addSyntheticArgument((outerLocals[k]).actualOuterLocalVariable);
/*      */     }
/*  273 */     implicitLambda.generateCode(lambdaScope, codeStream, valueRequired);
/*  274 */     if (generateSecretReceiverVariable) {
/*  275 */       codeStream.removeVariable(this.receiverVariable);
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   private boolean shouldGenerateImplicitLambda(BlockScope currentScope) {
/*  281 */     return !(!this.binding.isVarargs() && (
/*  282 */       !isConstructorReference() || (this.receiverType.syntheticOuterLocalVariables() == null && !this.shouldCaptureInstance)) && 
/*  283 */       !requiresBridges() && 
/*  284 */       isDirectCodeGenPossible());
/*      */   }
/*      */   
/*      */   private boolean isDirectCodeGenPossible() {
/*  288 */     if (this.binding != null) {
/*  289 */       if (isMethodReference() && this.syntheticAccessor == null && 
/*  290 */         TypeBinding.notEquals((TypeBinding)this.binding.declaringClass, this.lhs.resolvedType.erasure()))
/*      */       {
/*      */ 
/*      */ 
/*      */         
/*  295 */         if (!this.binding.declaringClass.canBeSeenBy((Scope)this.enclosingScope)) {
/*  296 */           if (this.binding.isDefaultMethod())
/*  297 */             return false; 
/*  298 */           return !(this.binding.isFinal() || this.binding.isStatic());
/*      */         } 
/*      */       }
/*      */       
/*  302 */       TypeBinding[] descriptorParams = this.descriptor.parameters;
/*  303 */       if (descriptorParams.length > 0) {
/*  304 */         TypeBinding[] origParams = (this.binding.original()).parameters;
/*  305 */         TypeBinding[] origDescParams = (this.descriptor.original()).parameters;
/*  306 */         for (int i = 0; i < descriptorParams.length; i++) {
/*  307 */           TypeBinding descType = descriptorParams[i];
/*  308 */           TypeBinding origDescType = origDescParams[i];
/*  309 */           if (descType.isIntersectionType18() || (
/*  310 */             descType.isTypeVariable() && ((TypeVariableBinding)descType).boundsCount() > 1)) {
/*  311 */             boolean varargs = this.binding.original().isVarargs();
/*  312 */             TypeBinding origParam = this.receiverPrecedesParameters ? (
/*  313 */               (i == 0) ? this.receiverType : InferenceContext18.getParameter(origParams, i - 1, varargs)) : 
/*  314 */               InferenceContext18.getParameter(origParams, i, varargs);
/*  315 */             if (!CharOperation.equals(origDescType.signature(), origParam.signature()))
/*  316 */               return false; 
/*      */           } 
/*      */         } 
/*  319 */       } else if (this.haveReceiver && (
/*  320 */         this.receiverType.isIntersectionType18() || (
/*  321 */         this.receiverType.isTypeVariable() && ((TypeVariableBinding)this.receiverType).boundsCount() > 1)) && 
/*  322 */         !CharOperation.equals((this.binding.original()).declaringClass.signature(), this.receiverType.signature())) {
/*  323 */         return false;
/*      */       } 
/*      */     } 
/*      */     
/*  327 */     return true;
/*      */   }
/*      */   
/*      */   public void generateCode(BlockScope currentScope, CodeStream codeStream, boolean valueRequired) {
/*  331 */     this.actualMethodBinding = this.binding;
/*      */     
/*  333 */     if (shouldGenerateImplicitLambda(currentScope)) {
/*  334 */       generateImplicitLambda(currentScope, codeStream, valueRequired);
/*      */       return;
/*      */     } 
/*  337 */     SourceTypeBinding sourceType = currentScope.enclosingSourceType();
/*  338 */     if (this.receiverType.isArrayType()) {
/*  339 */       char[] lambdaName = CharOperation.concat(TypeConstants.ANONYMOUS_METHOD, Integer.toString(this.ordinal).toCharArray());
/*  340 */       if (isConstructorReference()) {
/*  341 */         this.actualMethodBinding = this.binding = (MethodBinding)sourceType.addSyntheticArrayMethod((ArrayBinding)this.receiverType, 14, lambdaName);
/*  342 */       } else if (CharOperation.equals(this.selector, TypeConstants.CLONE)) {
/*  343 */         this.actualMethodBinding = this.binding = (MethodBinding)sourceType.addSyntheticArrayMethod((ArrayBinding)this.receiverType, 15, lambdaName);
/*      */       } 
/*  345 */     } else if (this.syntheticAccessor != null) {
/*  346 */       if (this.lhs.isSuper() || isMethodReference()) {
/*  347 */         this.binding = this.syntheticAccessor;
/*      */       }
/*  349 */     } else if (this.binding != null && isMethodReference() && 
/*  350 */       TypeBinding.notEquals((TypeBinding)this.binding.declaringClass, this.lhs.resolvedType.erasure()) && 
/*  351 */       !this.binding.declaringClass.canBeSeenBy((Scope)currentScope)) {
/*  352 */       this.binding = new MethodBinding(this.binding.original(), (ReferenceBinding)this.lhs.resolvedType.erasure());
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  357 */     int pc = codeStream.position;
/*  358 */     StringBuilder buffer = new StringBuilder();
/*  359 */     int argumentsSize = 0;
/*  360 */     buffer.append('(');
/*  361 */     if (this.haveReceiver) {
/*  362 */       this.lhs.generateCode(currentScope, codeStream, true);
/*  363 */       if (isMethodReference() && !this.lhs.isThis() && !this.lhs.isSuper()) {
/*  364 */         MethodBinding mb = currentScope.getJavaLangObject().getExactMethod(TypeConstants.GETCLASS, 
/*  365 */             Binding.NO_PARAMETERS, currentScope.compilationUnitScope());
/*  366 */         codeStream.dup();
/*  367 */         codeStream.invoke((byte)-74, mb, (TypeBinding)mb.declaringClass);
/*  368 */         codeStream.pop();
/*      */       } 
/*  370 */       if (this.lhs.isSuper() && !this.actualMethodBinding.isPrivate()) {
/*  371 */         if (this.lhs instanceof QualifiedSuperReference) {
/*  372 */           QualifiedSuperReference qualifiedSuperReference = (QualifiedSuperReference)this.lhs;
/*  373 */           TypeReference qualification = qualifiedSuperReference.qualification;
/*  374 */           if (qualification.resolvedType.isInterface()) {
/*  375 */             buffer.append(sourceType.signature());
/*      */           } else {
/*  377 */             buffer.append(((QualifiedSuperReference)this.lhs).currentCompatibleType.signature());
/*      */           } 
/*      */         } else {
/*  380 */           buffer.append(sourceType.signature());
/*      */         } 
/*      */       } else {
/*  383 */         buffer.append(this.receiverType.signature());
/*      */       } 
/*  385 */       argumentsSize = 1;
/*      */     }
/*  387 */     else if (isConstructorReference()) {
/*  388 */       ReferenceBinding[] enclosingInstances = Binding.UNINITIALIZED_REFERENCE_TYPES;
/*  389 */       if (this.receiverType.isNestedType()) {
/*  390 */         ReferenceBinding nestedType = (ReferenceBinding)this.receiverType;
/*  391 */         if ((enclosingInstances = nestedType.syntheticEnclosingInstanceTypes()) != null) {
/*  392 */           int length = enclosingInstances.length;
/*  393 */           argumentsSize = length;
/*  394 */           for (int i = 0; i < length; i++) {
/*  395 */             ReferenceBinding syntheticArgumentType = enclosingInstances[i];
/*  396 */             buffer.append(syntheticArgumentType.signature());
/*  397 */             Object[] emulationPath = currentScope.getEmulationPath(
/*  398 */                 syntheticArgumentType, 
/*  399 */                 false, 
/*  400 */                 true);
/*  401 */             codeStream.generateOuterAccess(emulationPath, this, (Binding)syntheticArgumentType, (Scope)currentScope);
/*      */           } 
/*      */         } else {
/*  404 */           enclosingInstances = Binding.NO_REFERENCE_TYPES;
/*      */         } 
/*      */       } 
/*  407 */       if (this.syntheticAccessor != null) {
/*  408 */         char[] lambdaName = CharOperation.concat(TypeConstants.ANONYMOUS_METHOD, Integer.toString(this.ordinal).toCharArray());
/*  409 */         this.binding = (MethodBinding)sourceType.addSyntheticFactoryMethod(this.binding, this.syntheticAccessor, (TypeBinding[])enclosingInstances, lambdaName);
/*  410 */         this.syntheticAccessor = null;
/*      */       } 
/*      */     } 
/*      */     
/*  414 */     buffer.append(')');
/*  415 */     buffer.append('L');
/*  416 */     if (this.resolvedType.isIntersectionType18()) {
/*  417 */       buffer.append(this.descriptor.declaringClass.constantPoolName());
/*      */     } else {
/*  419 */       buffer.append(this.resolvedType.constantPoolName());
/*      */     } 
/*  421 */     buffer.append(';');
/*  422 */     if (this.isSerializable) {
/*  423 */       sourceType.addSyntheticMethod(this);
/*      */     }
/*  425 */     int invokeDynamicNumber = codeStream.classFile.recordBootstrapMethod(this);
/*  426 */     codeStream.invokeDynamic(invokeDynamicNumber, argumentsSize, 1, this.descriptor.selector, buffer.toString().toCharArray(), 
/*  427 */         isConstructorReference(), (this.lhs instanceof TypeReference) ? (TypeReference)this.lhs : null, this.typeArguments, 
/*  428 */         this.resolvedType.id, this.resolvedType);
/*  429 */     if (!valueRequired)
/*  430 */       codeStream.pop(); 
/*  431 */     codeStream.recordPositionsFrom(pc, this.sourceStart);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void cleanUp() {
/*  437 */     if (this.copiesPerTargetType != null)
/*  438 */       for (ReferenceExpression copy : this.copiesPerTargetType.values()) {
/*  439 */         copy.scanner = null;
/*      */       } 
/*  441 */     if (this.original != null && this.original != this) {
/*  442 */       this.original.cleanUp();
/*      */     }
/*  444 */     this.scanner = null;
/*  445 */     this.receiverVariable = null;
/*      */   }
/*      */ 
/*      */   
/*      */   public void manageSyntheticAccessIfNecessary(BlockScope currentScope, FlowInfo flowInfo) {
/*  450 */     if ((flowInfo.tagBits & 0x1) != 0 || this.binding == null || !this.binding.isValidBinding()) {
/*      */       return;
/*      */     }
/*  453 */     MethodBinding codegenBinding = this.binding.original();
/*  454 */     if (codegenBinding.isVarargs()) {
/*      */       return;
/*      */     }
/*  457 */     SourceTypeBinding enclosingSourceType = currentScope.enclosingSourceType();
/*      */     
/*  459 */     if (isConstructorReference()) {
/*  460 */       ReferenceBinding allocatedType = codegenBinding.declaringClass;
/*  461 */       if (codegenBinding.isPrivate() && 
/*  462 */         TypeBinding.notEquals((TypeBinding)enclosingSourceType, (TypeBinding)(allocatedType = codegenBinding.declaringClass))) {
/*  463 */         if ((allocatedType.tagBits & 0x10L) != 0L) {
/*  464 */           codegenBinding.tagBits |= 0x200L;
/*      */         } else {
/*  466 */           if (currentScope.enclosingSourceType().isNestmateOf(this.binding.declaringClass)) {
/*  467 */             this.syntheticAccessor = codegenBinding;
/*      */             return;
/*      */           } 
/*  470 */           this.syntheticAccessor = (MethodBinding)((SourceTypeBinding)allocatedType).addSyntheticMethod(codegenBinding, false);
/*  471 */           currentScope.problemReporter().needToEmulateMethodAccess(codegenBinding, this);
/*      */         } 
/*      */       }
/*      */       
/*      */       return;
/*      */     } 
/*      */     
/*  478 */     if (this.binding.isPrivate()) {
/*  479 */       if (TypeBinding.notEquals((TypeBinding)enclosingSourceType, (TypeBinding)codegenBinding.declaringClass)) {
/*  480 */         this.syntheticAccessor = (MethodBinding)((SourceTypeBinding)codegenBinding.declaringClass).addSyntheticMethod(codegenBinding, false);
/*  481 */         currentScope.problemReporter().needToEmulateMethodAccess(codegenBinding, this);
/*      */       } 
/*      */       
/*      */       return;
/*      */     } 
/*  486 */     if (this.lhs.isSuper()) {
/*  487 */       SourceTypeBinding destinationType = enclosingSourceType;
/*  488 */       if (this.lhs instanceof QualifiedSuperReference) {
/*  489 */         QualifiedSuperReference qualifiedSuperReference = (QualifiedSuperReference)this.lhs;
/*  490 */         TypeReference qualification = qualifiedSuperReference.qualification;
/*  491 */         if (!qualification.resolvedType.isInterface()) {
/*  492 */           destinationType = (SourceTypeBinding)qualifiedSuperReference.currentCompatibleType;
/*      */         }
/*      */       } 
/*  495 */       this.syntheticAccessor = (MethodBinding)destinationType.addSyntheticMethod(codegenBinding, true);
/*  496 */       currentScope.problemReporter().needToEmulateMethodAccess(codegenBinding, this);
/*      */       
/*      */       return;
/*      */     } 
/*  500 */     if (this.binding.isProtected() && (this.bits & 0x1FE0) != 0 && codegenBinding.declaringClass.getPackage() != enclosingSourceType.getPackage()) {
/*  501 */       SourceTypeBinding currentCompatibleType = (SourceTypeBinding)enclosingSourceType.enclosingTypeAt((this.bits & 0x1FE0) >> 5);
/*  502 */       this.syntheticAccessor = (MethodBinding)currentCompatibleType.addSyntheticMethod(codegenBinding, isSuperAccess());
/*  503 */       currentScope.problemReporter().needToEmulateMethodAccess(codegenBinding, this);
/*      */       return;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public FlowInfo analyseCode(BlockScope currentScope, FlowContext flowContext, FlowInfo flowInfo) {
/*  511 */     if (this.haveReceiver) {
/*  512 */       this.lhs.analyseCode(currentScope, flowContext, flowInfo, true);
/*  513 */       this.lhs.checkNPE(currentScope, flowContext, flowInfo);
/*  514 */     } else if (isConstructorReference()) {
/*  515 */       TypeBinding type = this.receiverType.leafComponentType();
/*  516 */       if (type.isNestedType() && 
/*  517 */         type instanceof ReferenceBinding && !((ReferenceBinding)type).isStatic()) {
/*  518 */         currentScope.tagAsAccessingEnclosingInstanceStateOf((ReferenceBinding)type, false);
/*  519 */         this.shouldCaptureInstance = true;
/*  520 */         ReferenceBinding allocatedTypeErasure = (ReferenceBinding)type.erasure();
/*  521 */         if (allocatedTypeErasure.isLocalType()) {
/*  522 */           ((LocalTypeBinding)allocatedTypeErasure).addInnerEmulationDependent(currentScope, false);
/*      */         }
/*      */       } 
/*      */     } 
/*      */     
/*  527 */     if (currentScope.compilerOptions().isAnyEnabled(IrritantSet.UNLIKELY_ARGUMENT_TYPE) && this.binding.isValidBinding() && 
/*  528 */       this.binding != null && this.binding.parameters != null) {
/*  529 */       if (this.binding.parameters.length == 1 && 
/*  530 */         this.descriptor.parameters.length == (this.receiverPrecedesParameters ? 2 : 1) && 
/*  531 */         !this.binding.isStatic()) {
/*  532 */         TypeBinding argumentType = this.descriptor.parameters[this.receiverPrecedesParameters ? 1 : 0];
/*  533 */         TypeBinding actualReceiverType = this.receiverPrecedesParameters ? this.descriptor.parameters[0] : (TypeBinding)this.binding.declaringClass;
/*  534 */         UnlikelyArgumentCheck argumentCheck = 
/*  535 */           UnlikelyArgumentCheck.determineCheckForNonStaticSingleArgumentMethod(argumentType, (Scope)currentScope, this.selector, 
/*  536 */             actualReceiverType, this.binding.parameters);
/*  537 */         if (argumentCheck != null && argumentCheck.isDangerous(currentScope)) {
/*  538 */           currentScope.problemReporter().unlikelyArgumentType(this, this.binding, argumentType, 
/*  539 */               argumentCheck.typeToReport, argumentCheck.dangerousMethod);
/*      */         }
/*  541 */       } else if (this.binding.parameters.length == 2 && this.descriptor.parameters.length == 2 && this.binding.isStatic()) {
/*  542 */         TypeBinding argumentType1 = this.descriptor.parameters[0];
/*  543 */         TypeBinding argumentType2 = this.descriptor.parameters[1];
/*  544 */         UnlikelyArgumentCheck argumentCheck = 
/*  545 */           UnlikelyArgumentCheck.determineCheckForStaticTwoArgumentMethod(argumentType2, (Scope)currentScope, this.selector, 
/*  546 */             argumentType1, this.binding.parameters, this.receiverType);
/*  547 */         if (argumentCheck != null && argumentCheck.isDangerous(currentScope)) {
/*  548 */           currentScope.problemReporter().unlikelyArgumentType(this, this.binding, argumentType2, 
/*  549 */               argumentCheck.typeToReport, argumentCheck.dangerousMethod);
/*      */         }
/*      */       } 
/*      */     }
/*      */     
/*  554 */     if ((currentScope.compilerOptions()).analyseResourceLeaks && 
/*  555 */       this.haveReceiver && CharOperation.equals(this.selector, TypeConstants.CLOSE)) {
/*  556 */       FakedTrackingVariable trackingVariable = FakedTrackingVariable.getCloseTrackingVariable(this.lhs, flowInfo, flowContext);
/*  557 */       if (trackingVariable != null) {
/*  558 */         trackingVariable.markClosedInNestedMethod();
/*      */       }
/*      */     } 
/*      */     
/*  562 */     manageSyntheticAccessIfNecessary(currentScope, flowInfo);
/*  563 */     return flowInfo;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean checkingPotentialCompatibility() {
/*  568 */     return this.checkingPotentialCompatibility;
/*      */   }
/*      */ 
/*      */   
/*      */   public void acceptPotentiallyCompatibleMethods(MethodBinding[] methods) {
/*  573 */     if (this.checkingPotentialCompatibility) {
/*  574 */       this.potentialMethods = methods;
/*      */     }
/*      */   }
/*      */   
/*      */   public TypeBinding resolveType(BlockScope scope) {
/*      */     TypeBinding lhsType;
/*  580 */     CompilerOptions compilerOptions = scope.compilerOptions();
/*      */     
/*  582 */     if (this.constant != Constant.NotAConstant) {
/*  583 */       this.constant = Constant.NotAConstant;
/*  584 */       this.enclosingScope = scope;
/*  585 */       if (this.original == this) {
/*  586 */         this.ordinal = recordFunctionalType((Scope)scope);
/*      */       }
/*  588 */       this.lhs.bits |= 0x40000000;
/*  589 */       lhsType = this.lhs.resolveType(scope);
/*  590 */       this.lhs.computeConversion((Scope)scope, lhsType, lhsType);
/*  591 */       if (this.typeArguments != null) {
/*  592 */         int length = this.typeArguments.length;
/*  593 */         this.typeArgumentsHaveErrors = (compilerOptions.sourceLevel < 3211264L);
/*  594 */         this.resolvedTypeArguments = new TypeBinding[length];
/*  595 */         for (int j = 0; j < length; j++) {
/*  596 */           TypeReference typeReference = this.typeArguments[j];
/*  597 */           this.resolvedTypeArguments[j] = typeReference.resolveType(scope, true); if (typeReference.resolveType(scope, true) == null) {
/*  598 */             this.typeArgumentsHaveErrors = true;
/*      */           }
/*  600 */           if (this.typeArgumentsHaveErrors && typeReference instanceof Wildcard) {
/*  601 */             scope.problemReporter().illegalUsageOfWildcard(typeReference);
/*      */           }
/*      */         } 
/*  604 */         if (this.typeArgumentsHaveErrors || lhsType == null)
/*  605 */           return this.resolvedType = null; 
/*  606 */         if (isConstructorReference() && lhsType.isRawType()) {
/*  607 */           scope.problemReporter().rawConstructorReferenceNotWithExplicitTypeArguments(this.typeArguments);
/*  608 */           return this.resolvedType = null;
/*      */         } 
/*      */       } 
/*  611 */       if (this.typeArgumentsHaveErrors || lhsType == null) {
/*  612 */         return this.resolvedType = null;
/*      */       }
/*  614 */       if (lhsType.problemId() == 21)
/*  615 */         lhsType = lhsType.closestMatch(); 
/*  616 */       if (lhsType == null || !lhsType.isValidBinding()) {
/*  617 */         return this.resolvedType = null;
/*      */       }
/*  619 */       this.receiverType = lhsType;
/*  620 */       this.haveReceiver = true;
/*  621 */       if (this.lhs instanceof NameReference) {
/*  622 */         if ((this.lhs.bits & 0x7) == 4) {
/*  623 */           this.haveReceiver = false;
/*  624 */         } else if (isConstructorReference()) {
/*  625 */           scope.problemReporter().invalidType(
/*  626 */               this.lhs, 
/*  627 */               (TypeBinding)new ProblemReferenceBinding(((NameReference)this.lhs).getName(), null, 
/*  628 */                 1));
/*  629 */           return this.resolvedType = null;
/*      */         } 
/*  631 */       } else if (this.lhs instanceof TypeReference) {
/*  632 */         this.haveReceiver = false;
/*      */       } 
/*  634 */       if (!this.haveReceiver && !this.lhs.isSuper() && !isArrayConstructorReference()) {
/*  635 */         this.receiverType = lhsType.capture((Scope)scope, this.sourceStart, this.sourceEnd);
/*      */       }
/*  637 */       if (!lhsType.isRawType()) {
/*  638 */         this.binding = this.exactMethodBinding = isMethodReference() ? scope.getExactMethod(lhsType, this.selector, this) : scope.getExactConstructor(lhsType, this);
/*      */       }
/*  640 */       if (isConstructorReference() && !lhsType.canBeInstantiated()) {
/*  641 */         scope.problemReporter().cannotInstantiate(this.lhs, lhsType);
/*  642 */         return this.resolvedType = null;
/*      */       } 
/*      */       
/*  645 */       if (this.lhs instanceof TypeReference && ((TypeReference)this.lhs).hasNullTypeAnnotation(TypeReference.AnnotationPosition.ANY)) {
/*  646 */         scope.problemReporter().nullAnnotationUnsupportedLocation((TypeReference)this.lhs);
/*      */       }
/*      */       
/*  649 */       if (isConstructorReference() && lhsType.isArrayType()) {
/*  650 */         TypeBinding leafComponentType = lhsType.leafComponentType();
/*  651 */         if (!leafComponentType.isReifiable()) {
/*  652 */           scope.problemReporter().illegalGenericArray(leafComponentType, this);
/*  653 */           return this.resolvedType = null;
/*      */         } 
/*  655 */         if (this.typeArguments != null) {
/*  656 */           scope.problemReporter().invalidTypeArguments(this.typeArguments);
/*  657 */           return this.resolvedType = null;
/*      */         } 
/*  659 */         this.binding = this.exactMethodBinding = scope.getExactConstructor(lhsType, this);
/*      */       } 
/*  661 */       if (isMethodReference() && this.haveReceiver && this.original == this) {
/*  662 */         this.receiverVariable = new LocalVariableBinding((
/*  663 */             " rec_" + this.nameSourceStart).toCharArray(), this.lhs.resolvedType, 
/*  664 */             0, false);
/*  665 */         scope.addLocalVariable(this.receiverVariable);
/*  666 */         this.receiverVariable.setConstant(Constant.NotAConstant);
/*  667 */         this.receiverVariable.useFlag = 1;
/*      */       } 
/*      */       
/*  670 */       if (this.expectedType == null && this.expressionContext == ExpressionContext.INVOCATION_CONTEXT) {
/*  671 */         if (compilerOptions.isAnnotationBasedNullAnalysisEnabled && this.binding != null) {
/*  672 */           ImplicitNullAnnotationVerifier.ensureNullnessIsKnown(this.binding, (Scope)scope);
/*      */         }
/*  674 */         return (TypeBinding)new PolyTypeBinding(this);
/*      */       } 
/*      */     } else {
/*      */       
/*  678 */       lhsType = this.lhs.resolvedType;
/*  679 */       if (this.typeArgumentsHaveErrors || lhsType == null) {
/*  680 */         return this.resolvedType = null;
/*      */       }
/*      */     } 
/*  683 */     super.resolveType(scope);
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  688 */     if (this.descriptor == null || !this.descriptor.isValidBinding()) {
/*  689 */       return this.resolvedType = null;
/*      */     }
/*      */     
/*  692 */     TypeBinding[] descriptorParameters = descriptorParametersAsArgumentExpressions();
/*      */     
/*  694 */     if (lhsType.isBaseType()) {
/*  695 */       scope.problemReporter().errorNoMethodFor(this.lhs, lhsType, this.selector, descriptorParameters);
/*  696 */       return this.resolvedType = null;
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  710 */     int parametersLength = descriptorParameters.length;
/*  711 */     if (isConstructorReference() && lhsType.isArrayType()) {
/*  712 */       if (parametersLength != 1 || scope.parameterCompatibilityLevel(descriptorParameters[0], (TypeBinding)TypeBinding.INT) == -1) {
/*  713 */         scope.problemReporter().invalidArrayConstructorReference(this, lhsType, descriptorParameters);
/*  714 */         return this.resolvedType = null;
/*      */       } 
/*  716 */       if (this.descriptor.returnType.isProperType(true) && !lhsType.isCompatibleWith(this.descriptor.returnType) && this.descriptor.returnType.id != 6) {
/*  717 */         scope.problemReporter().constructedArrayIncompatible(this, lhsType, this.descriptor.returnType);
/*  718 */         return this.resolvedType = null;
/*      */       } 
/*  720 */       checkNullAnnotations(scope);
/*  721 */       return this.resolvedType;
/*      */     } 
/*      */ 
/*      */     
/*  725 */     boolean isMethodReference = isMethodReference();
/*  726 */     this.depth = 0;
/*  727 */     this.freeParameters = descriptorParameters;
/*  728 */     MethodBinding someMethod = null;
/*  729 */     if (isMethodReference) {
/*  730 */       someMethod = scope.getMethod(this.receiverType, this.selector, descriptorParameters, this);
/*      */     } else {
/*  732 */       if (argumentsTypeElided() && this.receiverType.isRawType()) {
/*  733 */         boolean[] inferredReturnType = new boolean[1];
/*  734 */         someMethod = AllocationExpression.inferDiamondConstructor((Scope)scope, this, this.receiverType, this.descriptor.parameters, inferredReturnType);
/*      */       } 
/*  736 */       if (someMethod == null)
/*  737 */         someMethod = scope.getConstructor((ReferenceBinding)this.receiverType, descriptorParameters, this); 
/*      */     } 
/*  739 */     int someMethodDepth = this.depth, anotherMethodDepth = 0;
/*  740 */     if (someMethod != null && someMethod.isValidBinding() && 
/*  741 */       someMethod.isStatic() && (this.haveReceiver || this.receiverType.isParameterizedTypeWithActualArguments())) {
/*  742 */       scope.problemReporter().methodMustBeAccessedStatically(this, someMethod);
/*  743 */       return this.resolvedType = null;
/*      */     } 
/*      */ 
/*      */     
/*  747 */     if (this.lhs.isSuper() && this.lhs.resolvedType.isInterface()) {
/*  748 */       scope.checkAppropriateMethodAgainstSupers(this.selector, someMethod, this.descriptor.parameters, this);
/*      */     }
/*      */     
/*  751 */     MethodBinding anotherMethod = null;
/*  752 */     this.receiverPrecedesParameters = false;
/*  753 */     if (!this.haveReceiver && isMethodReference && parametersLength > 0) {
/*  754 */       TypeBinding potentialReceiver = descriptorParameters[0];
/*  755 */       if (potentialReceiver.isCompatibleWith(this.receiverType, (Scope)scope)) {
/*  756 */         TypeBinding typeToSearch = this.receiverType;
/*  757 */         if (this.receiverType.isRawType()) {
/*  758 */           TypeBinding superType = potentialReceiver.findSuperTypeOriginatingFrom(this.receiverType);
/*  759 */           if (superType != null)
/*  760 */             typeToSearch = superType.capture((Scope)scope, this.sourceStart, this.sourceEnd); 
/*      */         } 
/*  762 */         TypeBinding[] parameters = Binding.NO_PARAMETERS;
/*  763 */         if (parametersLength > 1) {
/*  764 */           parameters = new TypeBinding[parametersLength - 1];
/*  765 */           System.arraycopy(descriptorParameters, 1, parameters, 0, parametersLength - 1);
/*      */         } 
/*  767 */         this.depth = 0;
/*  768 */         this.freeParameters = parameters;
/*  769 */         anotherMethod = scope.getMethod(typeToSearch, this.selector, parameters, this);
/*  770 */         anotherMethodDepth = this.depth;
/*  771 */         this.depth = 0;
/*      */       } 
/*      */     } 
/*      */     
/*  775 */     if (someMethod != null && someMethod.isValidBinding() && someMethod.isStatic() && anotherMethod != null && anotherMethod.isValidBinding() && !anotherMethod.isStatic()) {
/*  776 */       scope.problemReporter().methodReferenceSwingsBothWays(this, anotherMethod, someMethod);
/*  777 */       return this.resolvedType = null;
/*      */     } 
/*      */     
/*  780 */     if (someMethod != null && someMethod.isValidBinding() && (anotherMethod == null || !anotherMethod.isValidBinding() || anotherMethod.isStatic())) {
/*  781 */       this.binding = someMethod;
/*  782 */       this.bits &= 0xFFFFE01F;
/*  783 */       if (someMethodDepth > 0) {
/*  784 */         this.bits |= (someMethodDepth & 0xFF) << 5;
/*      */       }
/*  786 */       if (!this.haveReceiver && 
/*  787 */         !someMethod.isStatic() && !someMethod.isConstructor()) {
/*  788 */         scope.problemReporter().methodMustBeAccessedWithInstance(this, someMethod);
/*  789 */         return this.resolvedType = null;
/*      */       }
/*      */     
/*  792 */     } else if (anotherMethod != null && anotherMethod.isValidBinding() && (someMethod == null || !someMethod.isValidBinding() || !someMethod.isStatic())) {
/*  793 */       this.binding = anotherMethod;
/*  794 */       this.receiverPrecedesParameters = true;
/*  795 */       this.bits &= 0xFFFFE01F;
/*  796 */       if (anotherMethodDepth > 0) {
/*  797 */         this.bits |= (anotherMethodDepth & 0xFF) << 5;
/*      */       }
/*  799 */       if (anotherMethod.isStatic()) {
/*  800 */         scope.problemReporter().methodMustBeAccessedStatically(this, anotherMethod);
/*  801 */         return this.resolvedType = null;
/*      */       } 
/*      */     } else {
/*  804 */       this.binding = null;
/*  805 */       this.bits &= 0xFFFFE01F;
/*      */     } 
/*      */     
/*  808 */     if (this.binding == null) {
/*  809 */       char[] visibleName = isConstructorReference() ? this.receiverType.sourceName() : this.selector;
/*  810 */       scope.problemReporter().danglingReference(this, this.receiverType, visibleName, descriptorParameters);
/*  811 */       return this.resolvedType = null;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  816 */     if (this.binding.isAbstract() && this.lhs.isSuper()) {
/*  817 */       scope.problemReporter().cannotDireclyInvokeAbstractMethod(this, this.binding);
/*      */     }
/*  819 */     if (this.binding.isStatic()) {
/*  820 */       if (TypeBinding.notEquals((TypeBinding)this.binding.declaringClass, this.receiverType))
/*  821 */         scope.problemReporter().indirectAccessToStaticMethod(this, this.binding); 
/*      */     } else {
/*  823 */       AbstractMethodDeclaration srcMethod = this.binding.sourceMethod();
/*  824 */       if (srcMethod != null && srcMethod.isMethod()) {
/*  825 */         srcMethod.bits &= 0xFFFFFEFF;
/*      */       }
/*      */     } 
/*  828 */     if (isMethodUseDeprecated(this.binding, (Scope)scope, true, this)) {
/*  829 */       scope.problemReporter().deprecatedMethod(this.binding, this);
/*      */     }
/*  831 */     if (this.typeArguments != null && (this.binding.original()).typeVariables == Binding.NO_TYPE_VARIABLES) {
/*  832 */       scope.problemReporter().unnecessaryTypeArgumentsForMethodInvocation(this.binding, this.resolvedTypeArguments, this.typeArguments);
/*      */     }
/*  834 */     if ((this.binding.tagBits & 0x80L) != 0L) {
/*  835 */       scope.problemReporter().missingTypeInMethod(this, this.binding);
/*      */     }
/*      */ 
/*      */     
/*  839 */     ReferenceBinding[] arrayOfReferenceBinding1 = this.binding.thrownExceptions;
/*  840 */     ReferenceBinding[] arrayOfReferenceBinding2 = this.descriptor.thrownExceptions;
/*  841 */     for (int i = 0, iMax = arrayOfReferenceBinding1.length; i < iMax; i++) {
/*  842 */       if (!arrayOfReferenceBinding1[i].isUncheckedException(false))
/*      */       
/*      */       { 
/*  845 */         int j = 0, jMax = arrayOfReferenceBinding2.length; while (true) { if (j >= jMax)
/*      */           
/*      */           { 
/*      */             
/*  849 */             scope.problemReporter().unhandledException((TypeBinding)arrayOfReferenceBinding1[i], this); break; }  if (arrayOfReferenceBinding1[i].isCompatibleWith((TypeBinding)arrayOfReferenceBinding2[j], (Scope)scope))
/*      */             break;  j++; }  } 
/*  851 */     }  checkNullAnnotations(scope);
/*  852 */     this.freeParameters = null;
/*      */     
/*  854 */     if (checkInvocationArguments(scope, null, this.receiverType, this.binding, null, descriptorParameters, false, this)) {
/*  855 */       this.bits |= 0x10000;
/*      */     }
/*  857 */     if (this.descriptor.returnType.id != 6) {
/*  858 */       TypeBinding returnType = null;
/*  859 */       if (this.binding.isConstructor()) {
/*  860 */         returnType = this.receiverType;
/*      */       }
/*  862 */       else if ((this.bits & 0x10000) != 0 && this.resolvedTypeArguments == null) {
/*  863 */         returnType = this.binding.returnType;
/*  864 */         if (returnType != null) {
/*  865 */           returnType = scope.environment().convertToRawType(returnType.erasure(), true);
/*      */         }
/*      */       } else {
/*  868 */         returnType = this.binding.returnType;
/*  869 */         if (returnType != null) {
/*  870 */           returnType = returnType.capture((Scope)scope, this.sourceStart, this.sourceEnd);
/*      */         }
/*      */       } 
/*      */       
/*  874 */       if (this.descriptor.returnType.isProperType(true) && 
/*  875 */         !returnType.isCompatibleWith(this.descriptor.returnType, (Scope)scope) && 
/*  876 */         !isBoxingCompatible(returnType, this.descriptor.returnType, this, (Scope)scope)) {
/*      */         
/*  878 */         scope.problemReporter().incompatibleReturnType(this, this.binding, this.descriptor.returnType);
/*  879 */         this.binding = null;
/*  880 */         this.resolvedType = null;
/*      */       } 
/*      */     } 
/*      */     
/*  884 */     return this.resolvedType;
/*      */   }
/*      */   
/*      */   protected void checkNullAnnotations(BlockScope scope) {
/*  888 */     CompilerOptions compilerOptions = scope.compilerOptions();
/*  889 */     if (compilerOptions.isAnnotationBasedNullAnalysisEnabled && (
/*  890 */       this.expectedType == null || !NullAnnotationMatching.hasContradictions(this.expectedType))) {
/*  891 */       int len; ImplicitNullAnnotationVerifier.ensureNullnessIsKnown(this.binding, (Scope)scope);
/*      */ 
/*      */       
/*  894 */       int expectedlen = this.binding.parameters.length;
/*  895 */       int providedLen = this.descriptor.parameters.length;
/*  896 */       if (this.receiverPrecedesParameters) {
/*  897 */         providedLen--;
/*      */         
/*  899 */         TypeBinding descriptorParameter = this.descriptor.parameters[0];
/*  900 */         if ((descriptorParameter.tagBits & 0x80000000000000L) != 0L) {
/*  901 */           TypeBinding receiver = scope.environment().createAnnotatedType((TypeBinding)this.binding.declaringClass, 
/*  902 */               new AnnotationBinding[] { scope.environment().getNonNullAnnotation() });
/*  903 */           scope.problemReporter().referenceExpressionArgumentNullityMismatch(this, receiver, descriptorParameter, this.descriptor, -1, NullAnnotationMatching.NULL_ANNOTATIONS_MISMATCH);
/*      */         } 
/*      */       } 
/*  906 */       boolean isVarArgs = false;
/*  907 */       if (this.binding.isVarargs()) {
/*  908 */         isVarArgs = (providedLen == expectedlen) ? (
/*  909 */           !this.descriptor.parameters[expectedlen - 1].isCompatibleWith(this.binding.parameters[expectedlen - 1])) : true;
/*      */         
/*  911 */         len = providedLen;
/*      */       } else {
/*  913 */         len = Math.min(expectedlen, providedLen);
/*      */       } 
/*  915 */       for (int i = 0; i < len; i++) {
/*  916 */         TypeBinding bindingParameterToCheck, descriptorParameter = this.descriptor.parameters[i + (this.receiverPrecedesParameters ? 1 : 0)];
/*  917 */         TypeBinding bindingParameter = InferenceContext18.getParameter(this.binding.parameters, i, isVarArgs);
/*      */         
/*  919 */         if (bindingParameter.isPrimitiveType() && !descriptorParameter.isPrimitiveType()) {
/*      */           
/*  921 */           bindingParameterToCheck = scope.environment().createAnnotatedType(scope.boxing(bindingParameter), 
/*  922 */               new AnnotationBinding[] { scope.environment().getNonNullAnnotation() });
/*      */         } else {
/*  924 */           bindingParameterToCheck = bindingParameter;
/*      */         } 
/*  926 */         NullAnnotationMatching annotationStatus = NullAnnotationMatching.analyse(bindingParameterToCheck, descriptorParameter, 1);
/*  927 */         if (annotationStatus.isAnyMismatch())
/*      */         {
/*  929 */           scope.problemReporter().referenceExpressionArgumentNullityMismatch(this, bindingParameter, descriptorParameter, this.descriptor, i, annotationStatus);
/*      */         }
/*      */       } 
/*  932 */       TypeBinding returnType = this.binding.returnType;
/*  933 */       if (!returnType.isPrimitiveType()) {
/*  934 */         if (this.binding.isConstructor()) {
/*  935 */           returnType = scope.environment().createAnnotatedType(this.receiverType, new AnnotationBinding[] { scope.environment().getNonNullAnnotation() });
/*      */         }
/*  937 */         NullAnnotationMatching annotationStatus = NullAnnotationMatching.analyse(this.descriptor.returnType, returnType, 1);
/*  938 */         if (annotationStatus.isAnyMismatch()) {
/*  939 */           scope.problemReporter().illegalReturnRedefinition(this, this.descriptor, annotationStatus.isUnchecked(), returnType);
/*      */         }
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private TypeBinding[] descriptorParametersAsArgumentExpressions() {
/*  948 */     if (this.descriptor == null || this.descriptor.parameters == null || this.descriptor.parameters.length == 0) {
/*  949 */       return Binding.NO_PARAMETERS;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  957 */     if (this.expectedType.isParameterizedType()) {
/*  958 */       ParameterizedTypeBinding type = (ParameterizedTypeBinding)this.expectedType;
/*  959 */       MethodBinding method = type.getSingleAbstractMethod((Scope)this.enclosingScope, true, this.sourceStart, this.sourceEnd);
/*  960 */       return method.parameters;
/*      */     } 
/*  962 */     return this.descriptor.parameters;
/*      */   }
/*      */   
/*      */   private boolean contextHasSyntaxError() {
/*  966 */     ReferenceContext referenceContext = this.enclosingScope.referenceContext();
/*  967 */     if (referenceContext instanceof AbstractMethodDeclaration && (
/*  968 */       ((AbstractMethodDeclaration)referenceContext).bits & 0x80000) != 0) {
/*  969 */       return true;
/*      */     }
/*  971 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private ReferenceExpression cachedResolvedCopy(TypeBinding targetType) {
/*  977 */     ReferenceExpression copy = (this.copiesPerTargetType != null) ? this.copiesPerTargetType.get(targetType) : null;
/*  978 */     if (copy != null) {
/*  979 */       return copy;
/*      */     }
/*  981 */     if (contextHasSyntaxError()) {
/*  982 */       return null;
/*      */     }
/*  984 */     IErrorHandlingPolicy oldPolicy = this.enclosingScope.problemReporter().switchErrorHandlingPolicy(silentErrorHandlingPolicy);
/*      */     try {
/*  986 */       copy = copy();
/*  987 */       if (copy == null) {
/*  988 */         return null;
/*      */       }
/*  990 */       copy.setExpressionContext(this.expressionContext);
/*  991 */       copy.setExpectedType(targetType);
/*  992 */       copy.resolveType(this.enclosingScope);
/*      */       
/*  994 */       if (this.copiesPerTargetType == null)
/*  995 */         this.copiesPerTargetType = new HashMap<>(); 
/*  996 */       this.copiesPerTargetType.put(targetType, copy);
/*      */       
/*  998 */       return copy;
/*      */     } finally {
/* 1000 */       this.enclosingScope.problemReporter().switchErrorHandlingPolicy(oldPolicy);
/*      */     } 
/*      */   }
/*      */   
/*      */   public void registerInferenceContext(ParameterizedGenericMethodBinding method, InferenceContext18 context) {
/* 1005 */     if (this.inferenceContexts == null)
/* 1006 */       this.inferenceContexts = new HashMap<>(); 
/* 1007 */     this.inferenceContexts.put(method, context);
/*      */   }
/*      */   
/*      */   public InferenceContext18 getInferenceContext(ParameterizedMethodBinding method) {
/* 1011 */     if (this.inferenceContexts == null)
/* 1012 */       return null; 
/* 1013 */     return this.inferenceContexts.get(method);
/*      */   }
/*      */ 
/*      */   
/*      */   public ReferenceExpression resolveExpressionExpecting(TypeBinding targetType, Scope scope, InferenceContext18 inferenceContext) {
/* 1018 */     if (this.exactMethodBinding != null) {
/* 1019 */       MethodBinding functionType = targetType.getSingleAbstractMethod(scope, true);
/* 1020 */       if (functionType == null || functionType.problemId() == 17)
/* 1021 */         return null; 
/* 1022 */       int n = functionType.parameters.length;
/* 1023 */       int k = this.exactMethodBinding.parameters.length;
/*      */       
/* 1025 */       if (!this.haveReceiver && isMethodReference() && !this.exactMethodBinding.isStatic()) {
/* 1026 */         k++;
/*      */       }
/* 1028 */       return (n == k) ? this : null;
/*      */     } 
/*      */     
/* 1031 */     ReferenceExpression copy = cachedResolvedCopy(targetType);
/* 1032 */     return (copy != null && copy.resolvedType != null && copy.resolvedType.isValidBinding() && copy.binding != null && copy.binding.isValidBinding()) ? copy : null;
/*      */   }
/*      */   
/*      */   public boolean isConstructorReference() {
/* 1036 */     return CharOperation.equals(this.selector, ConstantPool.Init);
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isExactMethodReference() {
/* 1041 */     return (this.exactMethodBinding != null);
/*      */   }
/*      */   
/*      */   public MethodBinding getExactMethod() {
/* 1045 */     return this.exactMethodBinding;
/*      */   }
/*      */   
/*      */   public boolean isMethodReference() {
/* 1049 */     return !CharOperation.equals(this.selector, ConstantPool.Init);
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isPertinentToApplicability(TypeBinding targetType, MethodBinding method) {
/* 1054 */     if (!isExactMethodReference()) {
/* 1055 */       return false;
/*      */     }
/* 1057 */     return super.isPertinentToApplicability(targetType, method);
/*      */   }
/*      */ 
/*      */   
/*      */   public TypeBinding[] genericTypeArguments() {
/* 1062 */     return this.resolvedTypeArguments;
/*      */   }
/*      */ 
/*      */   
/*      */   public InferenceContext18 freshInferenceContext(Scope scope) {
/* 1067 */     if (this.expressionContext != ExpressionContext.VANILLA_CONTEXT) {
/* 1068 */       Expression[] arguments = createPseudoExpressions(this.freeParameters);
/* 1069 */       return new InferenceContext18(scope, arguments, this, null);
/*      */     } 
/* 1071 */     return null;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isSuperAccess() {
/* 1076 */     return this.lhs.isSuper();
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isTypeAccess() {
/* 1081 */     return !this.haveReceiver;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void setActualReceiverType(ReferenceBinding receiverType) {}
/*      */ 
/*      */ 
/*      */   
/*      */   public void setDepth(int depth) {
/* 1091 */     this.depth = depth;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setFieldIndex(int depth) {}
/*      */ 
/*      */ 
/*      */   
/*      */   public StringBuffer printExpression(int tab, StringBuffer output) {
/* 1102 */     this.lhs.print(0, output);
/* 1103 */     output.append("::");
/* 1104 */     if (this.typeArguments != null) {
/* 1105 */       output.append('<');
/* 1106 */       int max = this.typeArguments.length - 1;
/* 1107 */       for (int j = 0; j < max; j++) {
/* 1108 */         this.typeArguments[j].print(0, output);
/* 1109 */         output.append(", ");
/*      */       } 
/* 1111 */       this.typeArguments[max].print(0, output);
/* 1112 */       output.append('>');
/*      */     } 
/* 1114 */     if (isConstructorReference()) {
/* 1115 */       output.append("new");
/*      */     } else {
/* 1117 */       output.append(this.selector);
/*      */     } 
/* 1119 */     return output;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void traverse(ASTVisitor visitor, BlockScope blockScope) {
/* 1125 */     if (visitor.visit(this, blockScope)) {
/*      */       
/* 1127 */       this.lhs.traverse(visitor, blockScope);
/*      */       
/* 1129 */       int length = (this.typeArguments == null) ? 0 : this.typeArguments.length;
/* 1130 */       for (int i = 0; i < length; i++) {
/* 1131 */         this.typeArguments[i].traverse(visitor, blockScope);
/*      */       }
/*      */     } 
/* 1134 */     visitor.endVisit(this, blockScope);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Expression[] createPseudoExpressions(TypeBinding[] p) {
/* 1142 */     Expression[] expressions = new Expression[p.length];
/* 1143 */     long pos = (this.sourceStart << 32L) + this.sourceEnd;
/* 1144 */     for (int i = 0; i < p.length; i++) {
/* 1145 */       expressions[i] = new SingleNameReference(("fakeArg" + i).toCharArray(), pos);
/* 1146 */       (expressions[i]).resolvedType = p[i];
/*      */     } 
/* 1148 */     return expressions;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isPotentiallyCompatibleWith(TypeBinding targetType, Scope scope) {
/* 1154 */     boolean isConstructorRef = isConstructorReference();
/* 1155 */     if (isConstructorRef) {
/* 1156 */       if (this.receiverType == null)
/* 1157 */         return false; 
/* 1158 */       if (this.receiverType.isArrayType()) {
/* 1159 */         TypeBinding leafComponentType = this.receiverType.leafComponentType();
/* 1160 */         if (!leafComponentType.isReifiable()) {
/* 1161 */           return false;
/*      */         }
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/* 1167 */     if (!super.isPertinentToApplicability(targetType, (MethodBinding)null))
/* 1168 */       return true; 
/* 1169 */     MethodBinding sam = targetType.getSingleAbstractMethod((Scope)this.enclosingScope, true);
/* 1170 */     if (sam == null || !sam.isValidBinding())
/* 1171 */       return false; 
/* 1172 */     if (this.typeArgumentsHaveErrors || this.receiverType == null || !this.receiverType.isValidBinding()) {
/* 1173 */       return false;
/*      */     }
/* 1175 */     int parametersLength = sam.parameters.length;
/* 1176 */     TypeBinding[] descriptorParameters = new TypeBinding[parametersLength];
/* 1177 */     for (int i = 0; i < parametersLength; i++) {
/* 1178 */       descriptorParameters[i] = (TypeBinding)new ReferenceBinding()
/*      */         {
/*      */ 
/*      */           
/*      */           public boolean isCompatibleWith(TypeBinding otherType, Scope captureScope)
/*      */           {
/* 1184 */             return true;
/*      */           }
/*      */           
/*      */           public TypeBinding findSuperTypeOriginatingFrom(TypeBinding otherType) {
/* 1188 */             return otherType;
/*      */           }
/*      */           
/*      */           public String toString() {
/* 1192 */             return "(wildcard)";
/*      */           }
/*      */         };
/*      */     } 
/*      */ 
/*      */     
/* 1198 */     this.freeParameters = descriptorParameters;
/* 1199 */     this.checkingPotentialCompatibility = true;
/*      */     
/* 1201 */     try { MethodBinding compileTimeDeclaration = getCompileTimeDeclaration(scope, isConstructorRef, descriptorParameters);
/*      */       
/* 1203 */       if (compileTimeDeclaration != null && compileTimeDeclaration.isValidBinding()) {
/* 1204 */         this.potentialMethods = new MethodBinding[] { compileTimeDeclaration };
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       int j, length;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1218 */       for (j = 0, length = this.potentialMethods.length; j < length; j++) {
/* 1219 */         if (this.potentialMethods[j].isStatic() || this.potentialMethods[j].isConstructor()) {
/* 1220 */           if (!this.haveReceiver) {
/* 1221 */             return true;
/*      */           }
/* 1223 */         } else if (this.haveReceiver) {
/* 1224 */           return true;
/*      */         } 
/*      */       } 
/*      */       
/* 1228 */       if (this.haveReceiver || parametersLength == 0) {
/* 1229 */         return false;
/*      */       }
/* 1231 */       System.arraycopy(descriptorParameters, 1, descriptorParameters = new TypeBinding[parametersLength - 1], 0, parametersLength - 1);
/* 1232 */       this.freeParameters = descriptorParameters;
/* 1233 */       this.potentialMethods = Binding.NO_METHODS;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */        }
/*      */     
/*      */     finally
/*      */     
/*      */     { 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1249 */       this.checkingPotentialCompatibility = false;
/* 1250 */       this.potentialMethods = Binding.NO_METHODS;
/* 1251 */       this.freeParameters = null; }  this.checkingPotentialCompatibility = false; this.potentialMethods = Binding.NO_METHODS; this.freeParameters = null;
/*      */     
/* 1253 */     return false;
/*      */   }
/*      */   
/*      */   MethodBinding getCompileTimeDeclaration(Scope scope, boolean isConstructorRef, TypeBinding[] parameters) {
/* 1257 */     if (this.exactMethodBinding != null)
/* 1258 */       return this.exactMethodBinding; 
/* 1259 */     if (this.receiverType.isArrayType())
/* 1260 */       return scope.findMethodForArray((ArrayBinding)this.receiverType, this.selector, Binding.NO_PARAMETERS, this); 
/* 1261 */     if (isConstructorRef) {
/* 1262 */       return scope.getConstructor((ReferenceBinding)this.receiverType, parameters, this);
/*      */     }
/* 1264 */     return scope.getMethod(this.receiverType, this.selector, parameters, this);
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isCompatibleWith(TypeBinding targetType, Scope scope) {
/* 1269 */     ReferenceExpression copy = cachedResolvedCopy(targetType);
/* 1270 */     if (copy == null)
/* 1271 */       return contextHasSyntaxError(); 
/* 1272 */     if (copy.resolvedType != null && copy.resolvedType.isValidBinding() && copy.binding != null && copy.binding.isValidBinding()) {
/* 1273 */       return true;
/*      */     }
/* 1275 */     boolean notPertinentToApplicability = (targetType instanceof ParameterizedTypeBinding && !isPertinentToApplicability(targetType, (MethodBinding)null));
/* 1276 */     return notPertinentToApplicability;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean sIsMoreSpecific(TypeBinding s, TypeBinding t, Scope scope) {
/* 1283 */     if (super.sIsMoreSpecific(s, t, scope)) {
/* 1284 */       return true;
/*      */     }
/* 1286 */     if (this.exactMethodBinding == null || t.findSuperTypeOriginatingFrom(s) != null) {
/* 1287 */       return false;
/*      */     }
/* 1289 */     s = s.capture((Scope)this.enclosingScope, this.sourceStart, this.sourceEnd);
/* 1290 */     MethodBinding sSam = s.getSingleAbstractMethod((Scope)this.enclosingScope, true);
/* 1291 */     if (sSam == null || !sSam.isValidBinding())
/* 1292 */       return false; 
/* 1293 */     TypeBinding r1 = sSam.returnType;
/*      */     
/* 1295 */     MethodBinding tSam = t.getSingleAbstractMethod((Scope)this.enclosingScope, true);
/* 1296 */     if (tSam == null || !tSam.isValidBinding())
/* 1297 */       return false; 
/* 1298 */     TypeBinding r2 = tSam.returnType;
/*      */     
/* 1300 */     TypeBinding[] sParams = sSam.parameters;
/* 1301 */     TypeBinding[] tParams = tSam.parameters;
/*      */     
/* 1303 */     for (int i = 0; i < sParams.length; i++) {
/* 1304 */       if (TypeBinding.notEquals(sParams[i], tParams[i]))
/* 1305 */         return false; 
/*      */     } 
/* 1307 */     if (r2.id == 6) {
/* 1308 */       return true;
/*      */     }
/* 1310 */     if (r1.id == 6) {
/* 1311 */       return false;
/*      */     }
/*      */     
/* 1314 */     if (r1.isCompatibleWith(r2, scope)) {
/* 1315 */       return true;
/*      */     }
/* 1317 */     return (r1.isBaseType() != r2.isBaseType() && r1.isBaseType() == this.exactMethodBinding.returnType.isBaseType());
/*      */   }
/*      */ 
/*      */   
/*      */   public MethodBinding getMethodBinding() {
/* 1322 */     if (this.actualMethodBinding == null)
/* 1323 */       this.actualMethodBinding = this.binding; 
/* 1324 */     return this.actualMethodBinding;
/*      */   }
/*      */   
/*      */   public boolean isArrayConstructorReference() {
/* 1328 */     return (isConstructorReference() && this.lhs.resolvedType != null && this.lhs.resolvedType.isArrayType());
/*      */   }
/*      */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\ast\ReferenceExpression.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */