/*     */ package org.eclipse.jdt.internal.compiler.apt.model;
/*     */ 
/*     */ import java.lang.reflect.Array;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import javax.lang.model.element.AnnotationMirror;
/*     */ import javax.lang.model.element.Element;
/*     */ import javax.lang.model.type.ErrorType;
/*     */ import javax.lang.model.type.TypeKind;
/*     */ import javax.lang.model.type.TypeMirror;
/*     */ import javax.lang.model.type.TypeVisitor;
/*     */ import org.eclipse.jdt.internal.compiler.apt.dispatch.BaseProcessingEnvImpl;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.Binding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.ParameterizedTypeBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.ReferenceBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.TypeBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.TypeVariableBinding;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ErrorTypeImpl
/*     */   extends DeclaredTypeImpl
/*     */   implements ErrorType
/*     */ {
/*     */   ErrorTypeImpl(BaseProcessingEnvImpl env, ReferenceBinding binding) {
/*  41 */     super(env, binding);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Element asElement() {
/*  49 */     return this._env.getFactory().newElement(this._binding);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TypeMirror getEnclosingType() {
/*  57 */     return NoTypeImpl.NO_TYPE_NONE;
/*     */   }
/*     */ 
/*     */   
/*     */   public List<? extends TypeMirror> getTypeArguments() {
/*  62 */     ReferenceBinding binding = (ReferenceBinding)this._binding;
/*  63 */     if (binding.isParameterizedType()) {
/*  64 */       ParameterizedTypeBinding ptb = (ParameterizedTypeBinding)this._binding;
/*  65 */       TypeBinding[] arguments = ptb.arguments;
/*  66 */       int length = (arguments == null) ? 0 : arguments.length;
/*  67 */       if (length == 0) return Collections.emptyList(); 
/*  68 */       List<TypeMirror> args = new ArrayList<>(length); byte b; int i; TypeBinding[] arrayOfTypeBinding1;
/*  69 */       for (i = (arrayOfTypeBinding1 = arguments).length, b = 0; b < i; ) { TypeBinding arg = arrayOfTypeBinding1[b];
/*  70 */         args.add(this._env.getFactory().newTypeMirror((Binding)arg)); b++; }
/*     */       
/*  72 */       return Collections.unmodifiableList(args);
/*     */     } 
/*  74 */     if (binding.isGenericType()) {
/*  75 */       TypeVariableBinding[] typeVariables = binding.typeVariables();
/*  76 */       List<TypeMirror> args = new ArrayList<>(typeVariables.length); byte b; int i; TypeVariableBinding[] arrayOfTypeVariableBinding1;
/*  77 */       for (i = (arrayOfTypeVariableBinding1 = typeVariables).length, b = 0; b < i; ) { TypeVariableBinding typeVariableBinding = arrayOfTypeVariableBinding1[b];
/*  78 */         args.add(this._env.getFactory().newTypeMirror((Binding)typeVariableBinding)); b++; }
/*     */       
/*  80 */       return Collections.unmodifiableList(args);
/*     */     } 
/*  82 */     return Collections.emptyList();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <R, P> R accept(TypeVisitor<R, P> v, P p) {
/*  91 */     return v.visitError(this, p);
/*     */   }
/*     */ 
/*     */   
/*     */   public List<? extends AnnotationMirror> getAnnotationMirrors() {
/*  96 */     return Factory.EMPTY_ANNOTATION_MIRRORS;
/*     */   }
/*     */ 
/*     */   
/*     */   public <A extends java.lang.annotation.Annotation> A getAnnotation(Class<A> annotationType) {
/* 101 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public <A extends java.lang.annotation.Annotation> A[] getAnnotationsByType(Class<A> annotationType) {
/* 107 */     return (A[])Array.newInstance(annotationType, 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TypeKind getKind() {
/* 115 */     return TypeKind.ERROR;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 120 */     return new String(this._binding.readableName());
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\apt\model\ErrorTypeImpl.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */