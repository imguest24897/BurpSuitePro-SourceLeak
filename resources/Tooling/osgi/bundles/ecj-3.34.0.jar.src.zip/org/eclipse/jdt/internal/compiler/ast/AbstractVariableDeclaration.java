/*     */ package org.eclipse.jdt.internal.compiler.ast;
/*     */ 
/*     */ import org.eclipse.jdt.internal.compiler.flow.FlowContext;
/*     */ import org.eclipse.jdt.internal.compiler.flow.FlowInfo;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.BlockScope;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.InferenceContext18;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.InvocationSite;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.ReferenceBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.Scope;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.TypeBinding;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractVariableDeclaration
/*     */   extends Statement
/*     */   implements InvocationSite
/*     */ {
/*     */   public int declarationEnd;
/*     */   public int declarationSourceEnd;
/*     */   public int declarationSourceStart;
/*     */   public int hiddenVariableDepth;
/*     */   public Expression initialization;
/*     */   public int modifiers;
/*     */   public int modifiersSourceStart;
/*     */   public Annotation[] annotations;
/*     */   public char[] name;
/*     */   public TypeReference type;
/*     */   public static final int FIELD = 1;
/*     */   public static final int INITIALIZER = 2;
/*     */   public static final int ENUM_CONSTANT = 3;
/*     */   public static final int LOCAL_VARIABLE = 4;
/*     */   public static final int PARAMETER = 5;
/*     */   public static final int TYPE_PARAMETER = 6;
/*     */   public static final int RECORD_COMPONENT = 7;
/*     */   
/*     */   public FlowInfo analyseCode(BlockScope currentScope, FlowContext flowContext, FlowInfo flowInfo) {
/*  49 */     return flowInfo;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TypeBinding[] genericTypeArguments() {
/*  66 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract int getKind();
/*     */ 
/*     */ 
/*     */   
/*     */   public InferenceContext18 freshInferenceContext(Scope scope) {
/*  76 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isSuperAccess() {
/*  81 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isTypeAccess() {
/*  86 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public StringBuffer printStatement(int indent, StringBuffer output) {
/*  91 */     printAsExpression(indent, output);
/*  92 */     switch (getKind()) {
/*     */       case 3:
/*  94 */         return output.append(',');
/*     */     } 
/*  96 */     return output.append(';');
/*     */   }
/*     */ 
/*     */   
/*     */   public StringBuffer printAsExpression(int indent, StringBuffer output) {
/* 101 */     printIndent(indent, output);
/* 102 */     printModifiers(this.modifiers, output);
/* 103 */     if (this.annotations != null) {
/* 104 */       printAnnotations(this.annotations, output);
/* 105 */       output.append(' ');
/*     */     } 
/*     */     
/* 108 */     if (this.type != null) {
/* 109 */       this.type.print(0, output).append(' ');
/*     */     }
/* 111 */     output.append(this.name);
/* 112 */     switch (getKind())
/*     */     { case 3:
/* 114 */         if (this.initialization != null) {
/* 115 */           this.initialization.printExpression(indent, output);
/*     */         }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 124 */         return output; }  if (this.initialization != null) { output.append(" = "); this.initialization.printExpression(indent, output); }  return output;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void resolve(BlockScope scope) {}
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setActualReceiverType(ReferenceBinding receiverType) {}
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDepth(int depth) {
/* 140 */     this.hiddenVariableDepth = depth;
/*     */   }
/*     */   
/*     */   public void setFieldIndex(int depth) {}
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\ast\AbstractVariableDeclaration.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */