/*     */ package org.eclipse.jdt.internal.compiler.classfmt;
/*     */ 
/*     */ import org.eclipse.jdt.core.compiler.CharOperation;
/*     */ import org.eclipse.jdt.internal.compiler.env.IBinaryAnnotation;
/*     */ import org.eclipse.jdt.internal.compiler.env.ITypeAnnotationWalker;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.LookupEnvironment;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TypeParametersAnnotationWalker
/*     */   extends ExternalAnnotationProvider.BasicAnnotationWalker
/*     */ {
/*     */   int[] rankStarts;
/*     */   int currentRank;
/*     */   
/*     */   TypeParametersAnnotationWalker(char[] source, int pos, int rank, int[] rankStarts, LookupEnvironment environment) {
/* 536 */     super(source, pos, environment);
/* 537 */     this.currentRank = rank;
/* 538 */     if (rankStarts != null) {
/* 539 */       this.rankStarts = rankStarts;
/*     */     } else {
/*     */       
/* 542 */       int length = source.length;
/* 543 */       rankStarts = new int[length];
/* 544 */       int curRank = 0;
/*     */       
/* 546 */       int depth = 0;
/* 547 */       boolean pendingVariable = true;
/*     */       
/* 549 */       for (int i = pos; i < length; i++) {
/* 550 */         switch (this.source[i]) {
/*     */           case '<':
/* 552 */             depth++;
/*     */             break;
/*     */           case '>':
/* 555 */             if (--depth < 0)
/*     */               break; 
/*     */             break;
/*     */           case ';':
/* 559 */             if (depth == 0 && i + 1 < length && this.source[i + 1] != ':')
/* 560 */               pendingVariable = true; 
/*     */             break;
/*     */           case ':':
/* 563 */             if (depth == 0) {
/* 564 */               pendingVariable = true;
/*     */             }
/* 566 */             i++;
/* 567 */             while (i < length && this.source[i] == '[')
/* 568 */               i++; 
/* 569 */             if (i < length && this.source[i] == 'L') {
/* 570 */               int currentdepth = depth;
/* 571 */               while (i < length && (currentdepth != depth || this.source[i] != ';')) {
/* 572 */                 if (this.source[i] == '<')
/* 573 */                   currentdepth++; 
/* 574 */                 if (this.source[i] == '>')
/* 575 */                   currentdepth--; 
/* 576 */                 i++;
/*     */               } 
/*     */             } 
/* 579 */             i--;
/*     */             break;
/*     */           default:
/* 582 */             if (pendingVariable) {
/* 583 */               pendingVariable = false;
/* 584 */               rankStarts[curRank++] = i;
/*     */             } 
/*     */             break;
/*     */         } 
/*     */       } 
/* 589 */       System.arraycopy(rankStarts, 0, this.rankStarts = new int[curRank], 0, curRank);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public ITypeAnnotationWalker toTypeParameter(boolean isClassTypeParameter, int rank) {
/* 595 */     if (rank == this.currentRank)
/* 596 */       return this; 
/* 597 */     if (rank < this.rankStarts.length)
/* 598 */       return new TypeParametersAnnotationWalker(this.source, this.rankStarts[rank], rank, this.rankStarts, this.environment); 
/* 599 */     return ITypeAnnotationWalker.EMPTY_ANNOTATION_WALKER;
/*     */   }
/*     */ 
/*     */   
/*     */   public ITypeAnnotationWalker toTypeParameterBounds(boolean isClassTypeParameter, int parameterRank) {
/* 604 */     return new TypeParametersAnnotationWalker(this.source, this.rankStarts[parameterRank], parameterRank, this.rankStarts, this.environment);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ITypeAnnotationWalker toTypeBound(short boundIndex) {
/* 611 */     int p = this.pos;
/* 612 */     int i = this.currentTypeBound;
/*     */     
/*     */     while (true) {
/* 615 */       int colon = CharOperation.indexOf(':', this.source, p);
/* 616 */       if (colon != -1)
/* 617 */         p = colon + 1; 
/* 618 */       if (++i > boundIndex)
/*     */         break; 
/* 620 */       p = wrapperWithStart(p).computeEnd() + 1;
/*     */     } 
/* 622 */     this.pos = p;
/* 623 */     this.currentTypeBound = boundIndex;
/* 624 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public ITypeAnnotationWalker toField() {
/* 629 */     throw new UnsupportedOperationException("Cannot navigate to fields");
/*     */   }
/*     */ 
/*     */   
/*     */   public ITypeAnnotationWalker toMethodReturn() {
/* 634 */     throw new UnsupportedOperationException("Cannot navigate to method return");
/*     */   }
/*     */ 
/*     */   
/*     */   public ITypeAnnotationWalker toMethodParameter(short index) {
/* 639 */     throw new UnsupportedOperationException("Cannot navigate to method parameter");
/*     */   }
/*     */ 
/*     */   
/*     */   public ITypeAnnotationWalker toThrows(int index) {
/* 644 */     throw new UnsupportedOperationException("Cannot navigate to throws");
/*     */   }
/*     */ 
/*     */   
/*     */   public IBinaryAnnotation[] getAnnotationsAtCursor(int currentTypeId, boolean mayApplyArrayContentsDefaultNullness) {
/* 649 */     if (this.pos != -1 && this.pos < this.source.length - 1) {
/* 650 */       switch (this.source[this.pos]) {
/*     */         case '0':
/* 652 */           return new IBinaryAnnotation[] { this.this$0.NULLABLE_ANNOTATION };
/*     */         case '1':
/* 654 */           return new IBinaryAnnotation[] { this.this$0.NONNULL_ANNOTATION };
/*     */       } 
/*     */     }
/* 657 */     return super.getAnnotationsAtCursor(currentTypeId, mayApplyArrayContentsDefaultNullness);
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\classfmt\ExternalAnnotationProvider$TypeParametersAnnotationWalker.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */