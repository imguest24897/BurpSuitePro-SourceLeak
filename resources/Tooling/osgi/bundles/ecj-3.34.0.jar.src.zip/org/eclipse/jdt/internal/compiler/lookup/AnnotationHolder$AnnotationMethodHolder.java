/*    */ package org.eclipse.jdt.internal.compiler.lookup;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class AnnotationMethodHolder
/*    */   extends AnnotationHolder.MethodHolder
/*    */ {
/*    */   Object defaultValue;
/*    */   LookupEnvironment env;
/*    */   
/*    */   AnnotationMethodHolder(AnnotationBinding[] annotations, AnnotationBinding[][] parameterAnnotations, Object defaultValue, LookupEnvironment optionalEnv) {
/* 84 */     super(annotations, parameterAnnotations);
/* 85 */     this.defaultValue = defaultValue;
/* 86 */     this.env = optionalEnv;
/*    */   }
/*    */   
/*    */   Object getDefaultValue() {
/* 90 */     if (this.defaultValue instanceof UnresolvedReferenceBinding) {
/* 91 */       if (this.env == null)
/* 92 */         throw new IllegalStateException(); 
/* 93 */       this.defaultValue = ((UnresolvedReferenceBinding)this.defaultValue).resolve(this.env, false);
/*    */     } 
/* 95 */     return this.defaultValue;
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\lookup\AnnotationHolder$AnnotationMethodHolder.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */