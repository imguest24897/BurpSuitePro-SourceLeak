/*     */ package org.eclipse.jdt.internal.compiler.classfmt;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.util.Map;
/*     */ import org.eclipse.jdt.core.compiler.CharOperation;
/*     */ import org.eclipse.jdt.internal.compiler.env.IBinaryAnnotation;
/*     */ import org.eclipse.jdt.internal.compiler.env.IBinaryElementValuePair;
/*     */ import org.eclipse.jdt.internal.compiler.env.ITypeAnnotationWalker;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.LookupEnvironment;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.SignatureWrapper;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ExternalAnnotationProvider
/*     */ {
/*     */   public static final String ANNOTATION_FILE_EXTENSION = "eea";
/*     */   public static final String CLASS_PREFIX = "class ";
/*     */   public static final String SUPER_PREFIX = "super ";
/*     */   public static final char NULLABLE = '0';
/*     */   public static final char NONNULL = '1';
/*     */   public static final char NO_ANNOTATION = '@';
/*     */   public static final String ANNOTATION_FILE_SUFFIX = ".eea";
/*     */   private static final String TYPE_PARAMETER_PREFIX = " <";
/*  59 */   private static final ExternalAnnotationProvider OUTER_FOR_PARTIAL_WALKERS = new ExternalAnnotationProvider();
/*     */   
/*     */   private String typeName;
/*     */   
/*     */   String typeParametersAnnotationSource;
/*     */   
/*     */   Map<String, String> supertypeAnnotationSources;
/*     */   
/*     */   private Map<String, String> methodAnnotationSources;
/*     */   
/*     */   private Map<String, String> fieldAnnotationSources;
/*     */   SingleMarkerAnnotation NULLABLE_ANNOTATION;
/*     */   SingleMarkerAnnotation NONNULL_ANNOTATION;
/*     */   
/*     */   public ExternalAnnotationProvider(InputStream input, String typeName) throws IOException {
/*  74 */     this.typeName = typeName;
/*  75 */     initialize(input);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ExternalAnnotationProvider() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void initialize(InputStream input) throws IOException {
/*     */     // Byte code:
/*     */     //   0: aconst_null
/*     */     //   1: astore_2
/*     */     //   2: aconst_null
/*     */     //   3: astore_3
/*     */     //   4: new java/io/LineNumberReader
/*     */     //   7: dup
/*     */     //   8: new java/io/InputStreamReader
/*     */     //   11: dup
/*     */     //   12: aload_1
/*     */     //   13: invokespecial <init> : (Ljava/io/InputStream;)V
/*     */     //   16: invokespecial <init> : (Ljava/io/Reader;)V
/*     */     //   19: astore #4
/*     */     //   21: aload #4
/*     */     //   23: invokevirtual readLine : ()Ljava/lang/String;
/*     */     //   26: aload_0
/*     */     //   27: getfield typeName : Ljava/lang/String;
/*     */     //   30: invokestatic assertClassHeader : (Ljava/lang/String;Ljava/lang/String;)V
/*     */     //   33: aload #4
/*     */     //   35: invokevirtual readLine : ()Ljava/lang/String;
/*     */     //   38: dup
/*     */     //   39: astore #5
/*     */     //   41: ifnonnull -> 55
/*     */     //   44: aload #4
/*     */     //   46: ifnull -> 54
/*     */     //   49: aload #4
/*     */     //   51: invokevirtual close : ()V
/*     */     //   54: return
/*     */     //   55: aload #5
/*     */     //   57: ldc ' <'
/*     */     //   59: invokevirtual startsWith : (Ljava/lang/String;)Z
/*     */     //   62: ifeq -> 133
/*     */     //   65: aload #4
/*     */     //   67: invokevirtual readLine : ()Ljava/lang/String;
/*     */     //   70: dup
/*     */     //   71: astore #5
/*     */     //   73: ifnonnull -> 87
/*     */     //   76: aload #4
/*     */     //   78: ifnull -> 86
/*     */     //   81: aload #4
/*     */     //   83: invokevirtual close : ()V
/*     */     //   86: return
/*     */     //   87: aload #5
/*     */     //   89: ldc ' <'
/*     */     //   91: invokevirtual startsWith : (Ljava/lang/String;)Z
/*     */     //   94: ifeq -> 133
/*     */     //   97: aload_0
/*     */     //   98: aload #5
/*     */     //   100: ldc ' <'
/*     */     //   102: invokevirtual length : ()I
/*     */     //   105: invokevirtual substring : (I)Ljava/lang/String;
/*     */     //   108: putfield typeParametersAnnotationSource : Ljava/lang/String;
/*     */     //   111: aload #4
/*     */     //   113: invokevirtual readLine : ()Ljava/lang/String;
/*     */     //   116: dup
/*     */     //   117: astore #5
/*     */     //   119: ifnonnull -> 133
/*     */     //   122: aload #4
/*     */     //   124: ifnull -> 132
/*     */     //   127: aload #4
/*     */     //   129: invokevirtual close : ()V
/*     */     //   132: return
/*     */     //   133: aconst_null
/*     */     //   134: astore #6
/*     */     //   136: aload #5
/*     */     //   138: invokevirtual trim : ()Ljava/lang/String;
/*     */     //   141: astore #5
/*     */     //   143: aload #5
/*     */     //   145: invokevirtual isEmpty : ()Z
/*     */     //   148: ifeq -> 154
/*     */     //   151: goto -> 790
/*     */     //   154: aconst_null
/*     */     //   155: astore #7
/*     */     //   157: aconst_null
/*     */     //   158: astore #8
/*     */     //   160: aload #5
/*     */     //   162: astore #9
/*     */     //   164: aload #9
/*     */     //   166: iconst_0
/*     */     //   167: invokevirtual charAt : (I)C
/*     */     //   170: invokestatic isJavaIdentifierStart : (C)Z
/*     */     //   173: ifne -> 252
/*     */     //   176: new java/lang/String
/*     */     //   179: dup
/*     */     //   180: getstatic org/eclipse/jdt/internal/compiler/lookup/TypeConstants.INIT : [C
/*     */     //   183: invokespecial <init> : ([C)V
/*     */     //   186: aload #9
/*     */     //   188: invokestatic trimTail : (Ljava/lang/String;)Ljava/lang/String;
/*     */     //   191: invokevirtual equals : (Ljava/lang/Object;)Z
/*     */     //   194: ifne -> 252
/*     */     //   197: new java/io/IOException
/*     */     //   200: dup
/*     */     //   201: new java/lang/StringBuilder
/*     */     //   204: dup
/*     */     //   205: ldc 'Illegal selector in external annotation file for '
/*     */     //   207: invokespecial <init> : (Ljava/lang/String;)V
/*     */     //   210: aload_0
/*     */     //   211: getfield typeName : Ljava/lang/String;
/*     */     //   214: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   217: ldc ' at line '
/*     */     //   219: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   222: aload #4
/*     */     //   224: invokevirtual getLineNumber : ()I
/*     */     //   227: invokevirtual append : (I)Ljava/lang/StringBuilder;
/*     */     //   230: ldc ': "'
/*     */     //   232: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   235: aload #9
/*     */     //   237: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   240: bipush #34
/*     */     //   242: invokevirtual append : (C)Ljava/lang/StringBuilder;
/*     */     //   245: invokevirtual toString : ()Ljava/lang/String;
/*     */     //   248: invokespecial <init> : (Ljava/lang/String;)V
/*     */     //   251: athrow
/*     */     //   252: aload #9
/*     */     //   254: ldc 'super '
/*     */     //   256: invokevirtual startsWith : (Ljava/lang/String;)Z
/*     */     //   259: istore #10
/*     */     //   261: iload #10
/*     */     //   263: ifeq -> 278
/*     */     //   266: aload #9
/*     */     //   268: ldc 'super '
/*     */     //   270: invokevirtual length : ()I
/*     */     //   273: invokevirtual substring : (I)Ljava/lang/String;
/*     */     //   276: astore #9
/*     */     //   278: iconst_m1
/*     */     //   279: istore #11
/*     */     //   281: ldc ''
/*     */     //   283: astore #12
/*     */     //   285: aload #4
/*     */     //   287: invokevirtual readLine : ()Ljava/lang/String;
/*     */     //   290: astore #5
/*     */     //   292: aload #5
/*     */     //   294: ifnull -> 372
/*     */     //   297: aload #5
/*     */     //   299: invokevirtual isEmpty : ()Z
/*     */     //   302: ifne -> 372
/*     */     //   305: aload #5
/*     */     //   307: iconst_0
/*     */     //   308: invokevirtual charAt : (I)C
/*     */     //   311: bipush #32
/*     */     //   313: if_icmpne -> 372
/*     */     //   316: aload #5
/*     */     //   318: iconst_1
/*     */     //   319: invokevirtual substring : (I)Ljava/lang/String;
/*     */     //   322: astore #7
/*     */     //   324: aload #7
/*     */     //   326: invokevirtual trim : ()Ljava/lang/String;
/*     */     //   329: invokestatic trimTail : (Ljava/lang/String;)Ljava/lang/String;
/*     */     //   332: astore #13
/*     */     //   334: aload_0
/*     */     //   335: aload #13
/*     */     //   337: iload #10
/*     */     //   339: invokevirtual isValidSignature : (Ljava/lang/String;Z)Z
/*     */     //   342: ifne -> 403
/*     */     //   345: new java/lang/StringBuilder
/*     */     //   348: dup
/*     */     //   349: ldc ': invalid signature "'
/*     */     //   351: invokespecial <init> : (Ljava/lang/String;)V
/*     */     //   354: aload #13
/*     */     //   356: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   359: bipush #34
/*     */     //   361: invokevirtual append : (C)Ljava/lang/StringBuilder;
/*     */     //   364: invokevirtual toString : ()Ljava/lang/String;
/*     */     //   367: astore #12
/*     */     //   369: goto -> 524
/*     */     //   372: aload #4
/*     */     //   374: invokevirtual getLineNumber : ()I
/*     */     //   377: istore #11
/*     */     //   379: new java/lang/StringBuilder
/*     */     //   382: dup
/*     */     //   383: ldc ': illegal signature line "'
/*     */     //   385: invokespecial <init> : (Ljava/lang/String;)V
/*     */     //   388: aload #5
/*     */     //   390: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   393: ldc '"'
/*     */     //   395: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   398: invokevirtual toString : ()Ljava/lang/String;
/*     */     //   401: astore #12
/*     */     //   403: aload #4
/*     */     //   405: invokevirtual readLine : ()Ljava/lang/String;
/*     */     //   408: astore #5
/*     */     //   410: aload #5
/*     */     //   412: ifnull -> 790
/*     */     //   415: aload #5
/*     */     //   417: invokevirtual isEmpty : ()Z
/*     */     //   420: ifeq -> 426
/*     */     //   423: goto -> 790
/*     */     //   426: aload #5
/*     */     //   428: iconst_0
/*     */     //   429: invokevirtual charAt : (I)C
/*     */     //   432: bipush #32
/*     */     //   434: if_icmpeq -> 444
/*     */     //   437: aload #5
/*     */     //   439: astore #6
/*     */     //   441: goto -> 790
/*     */     //   444: aload #5
/*     */     //   446: iconst_1
/*     */     //   447: invokevirtual substring : (I)Ljava/lang/String;
/*     */     //   450: astore #8
/*     */     //   452: aload #8
/*     */     //   454: invokevirtual trim : ()Ljava/lang/String;
/*     */     //   457: invokestatic trimTail : (Ljava/lang/String;)Ljava/lang/String;
/*     */     //   460: astore #13
/*     */     //   462: aload_0
/*     */     //   463: aload #13
/*     */     //   465: iload #10
/*     */     //   467: invokevirtual isValidSignature : (Ljava/lang/String;Z)Z
/*     */     //   470: ifne -> 524
/*     */     //   473: new java/lang/StringBuilder
/*     */     //   476: dup
/*     */     //   477: ldc ': invalid signature "'
/*     */     //   479: invokespecial <init> : (Ljava/lang/String;)V
/*     */     //   482: aload #13
/*     */     //   484: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   487: bipush #34
/*     */     //   489: invokevirtual append : (C)Ljava/lang/StringBuilder;
/*     */     //   492: invokevirtual toString : ()Ljava/lang/String;
/*     */     //   495: astore #12
/*     */     //   497: goto -> 524
/*     */     //   500: astore #13
/*     */     //   502: new java/lang/StringBuilder
/*     */     //   505: dup
/*     */     //   506: ldc ': '
/*     */     //   508: invokespecial <init> : (Ljava/lang/String;)V
/*     */     //   511: aload #13
/*     */     //   513: invokevirtual toString : ()Ljava/lang/String;
/*     */     //   516: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   519: invokevirtual toString : ()Ljava/lang/String;
/*     */     //   522: astore #12
/*     */     //   524: aload #7
/*     */     //   526: ifnull -> 542
/*     */     //   529: aload #8
/*     */     //   531: ifnull -> 542
/*     */     //   534: aload #12
/*     */     //   536: invokevirtual isEmpty : ()Z
/*     */     //   539: ifne -> 597
/*     */     //   542: iload #11
/*     */     //   544: iconst_m1
/*     */     //   545: if_icmpne -> 555
/*     */     //   548: aload #4
/*     */     //   550: invokevirtual getLineNumber : ()I
/*     */     //   553: istore #11
/*     */     //   555: new java/io/IOException
/*     */     //   558: dup
/*     */     //   559: new java/lang/StringBuilder
/*     */     //   562: dup
/*     */     //   563: ldc 'Illegal format in external annotation file for '
/*     */     //   565: invokespecial <init> : (Ljava/lang/String;)V
/*     */     //   568: aload_0
/*     */     //   569: getfield typeName : Ljava/lang/String;
/*     */     //   572: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   575: ldc ' at line '
/*     */     //   577: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   580: iload #11
/*     */     //   582: invokevirtual append : (I)Ljava/lang/StringBuilder;
/*     */     //   585: aload #12
/*     */     //   587: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   590: invokevirtual toString : ()Ljava/lang/String;
/*     */     //   593: invokespecial <init> : (Ljava/lang/String;)V
/*     */     //   596: athrow
/*     */     //   597: aload #8
/*     */     //   599: invokestatic trimTail : (Ljava/lang/String;)Ljava/lang/String;
/*     */     //   602: astore #8
/*     */     //   604: iload #10
/*     */     //   606: ifeq -> 672
/*     */     //   609: aload_0
/*     */     //   610: getfield supertypeAnnotationSources : Ljava/util/Map;
/*     */     //   613: ifnonnull -> 627
/*     */     //   616: aload_0
/*     */     //   617: new java/util/HashMap
/*     */     //   620: dup
/*     */     //   621: invokespecial <init> : ()V
/*     */     //   624: putfield supertypeAnnotationSources : Ljava/util/Map;
/*     */     //   627: aload_0
/*     */     //   628: getfield supertypeAnnotationSources : Ljava/util/Map;
/*     */     //   631: new java/lang/StringBuilder
/*     */     //   634: dup
/*     */     //   635: bipush #76
/*     */     //   637: invokestatic valueOf : (C)Ljava/lang/String;
/*     */     //   640: invokespecial <init> : (Ljava/lang/String;)V
/*     */     //   643: aload #9
/*     */     //   645: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   648: aload #7
/*     */     //   650: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   653: bipush #59
/*     */     //   655: invokevirtual append : (C)Ljava/lang/StringBuilder;
/*     */     //   658: invokevirtual toString : ()Ljava/lang/String;
/*     */     //   661: aload #8
/*     */     //   663: invokeinterface put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
/*     */     //   668: pop
/*     */     //   669: goto -> 790
/*     */     //   672: aload #7
/*     */     //   674: ldc '('
/*     */     //   676: invokevirtual contains : (Ljava/lang/CharSequence;)Z
/*     */     //   679: ifeq -> 735
/*     */     //   682: aload_0
/*     */     //   683: getfield methodAnnotationSources : Ljava/util/Map;
/*     */     //   686: ifnonnull -> 700
/*     */     //   689: aload_0
/*     */     //   690: new java/util/HashMap
/*     */     //   693: dup
/*     */     //   694: invokespecial <init> : ()V
/*     */     //   697: putfield methodAnnotationSources : Ljava/util/Map;
/*     */     //   700: aload_0
/*     */     //   701: getfield methodAnnotationSources : Ljava/util/Map;
/*     */     //   704: new java/lang/StringBuilder
/*     */     //   707: dup
/*     */     //   708: aload #9
/*     */     //   710: invokestatic valueOf : (Ljava/lang/Object;)Ljava/lang/String;
/*     */     //   713: invokespecial <init> : (Ljava/lang/String;)V
/*     */     //   716: aload #7
/*     */     //   718: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   721: invokevirtual toString : ()Ljava/lang/String;
/*     */     //   724: aload #8
/*     */     //   726: invokeinterface put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
/*     */     //   731: pop
/*     */     //   732: goto -> 790
/*     */     //   735: aload_0
/*     */     //   736: getfield fieldAnnotationSources : Ljava/util/Map;
/*     */     //   739: ifnonnull -> 753
/*     */     //   742: aload_0
/*     */     //   743: new java/util/HashMap
/*     */     //   746: dup
/*     */     //   747: invokespecial <init> : ()V
/*     */     //   750: putfield fieldAnnotationSources : Ljava/util/Map;
/*     */     //   753: aload_0
/*     */     //   754: getfield fieldAnnotationSources : Ljava/util/Map;
/*     */     //   757: new java/lang/StringBuilder
/*     */     //   760: dup
/*     */     //   761: aload #9
/*     */     //   763: invokestatic valueOf : (Ljava/lang/Object;)Ljava/lang/String;
/*     */     //   766: invokespecial <init> : (Ljava/lang/String;)V
/*     */     //   769: bipush #58
/*     */     //   771: invokevirtual append : (C)Ljava/lang/StringBuilder;
/*     */     //   774: aload #7
/*     */     //   776: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   779: invokevirtual toString : ()Ljava/lang/String;
/*     */     //   782: aload #8
/*     */     //   784: invokeinterface put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
/*     */     //   789: pop
/*     */     //   790: aload #6
/*     */     //   792: dup
/*     */     //   793: astore #5
/*     */     //   795: ifnonnull -> 133
/*     */     //   798: aload #4
/*     */     //   800: invokevirtual readLine : ()Ljava/lang/String;
/*     */     //   803: dup
/*     */     //   804: astore #5
/*     */     //   806: ifnonnull -> 133
/*     */     //   809: aload #4
/*     */     //   811: ifnull -> 857
/*     */     //   814: aload #4
/*     */     //   816: invokevirtual close : ()V
/*     */     //   819: goto -> 857
/*     */     //   822: astore_2
/*     */     //   823: aload #4
/*     */     //   825: ifnull -> 833
/*     */     //   828: aload #4
/*     */     //   830: invokevirtual close : ()V
/*     */     //   833: aload_2
/*     */     //   834: athrow
/*     */     //   835: astore_3
/*     */     //   836: aload_2
/*     */     //   837: ifnonnull -> 845
/*     */     //   840: aload_3
/*     */     //   841: astore_2
/*     */     //   842: goto -> 855
/*     */     //   845: aload_2
/*     */     //   846: aload_3
/*     */     //   847: if_acmpeq -> 855
/*     */     //   850: aload_2
/*     */     //   851: aload_3
/*     */     //   852: invokevirtual addSuppressed : (Ljava/lang/Throwable;)V
/*     */     //   855: aload_2
/*     */     //   856: athrow
/*     */     //   857: return
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #84	-> 0
/*     */     //   #85	-> 21
/*     */     //   #88	-> 33
/*     */     //   #168	-> 44
/*     */     //   #89	-> 54
/*     */     //   #91	-> 55
/*     */     //   #92	-> 65
/*     */     //   #168	-> 76
/*     */     //   #93	-> 86
/*     */     //   #94	-> 87
/*     */     //   #95	-> 97
/*     */     //   #96	-> 111
/*     */     //   #168	-> 122
/*     */     //   #97	-> 132
/*     */     //   #102	-> 133
/*     */     //   #103	-> 136
/*     */     //   #104	-> 143
/*     */     //   #105	-> 154
/*     */     //   #107	-> 160
/*     */     //   #108	-> 164
/*     */     //   #109	-> 197
/*     */     //   #111	-> 252
/*     */     //   #112	-> 261
/*     */     //   #113	-> 266
/*     */     //   #114	-> 278
/*     */     //   #115	-> 281
/*     */     //   #119	-> 285
/*     */     //   #120	-> 292
/*     */     //   #121	-> 316
/*     */     //   #122	-> 324
/*     */     //   #123	-> 334
/*     */     //   #124	-> 345
/*     */     //   #125	-> 369
/*     */     //   #128	-> 372
/*     */     //   #129	-> 379
/*     */     //   #132	-> 403
/*     */     //   #133	-> 410
/*     */     //   #134	-> 423
/*     */     //   #135	-> 426
/*     */     //   #136	-> 437
/*     */     //   #137	-> 441
/*     */     //   #139	-> 444
/*     */     //   #140	-> 452
/*     */     //   #141	-> 462
/*     */     //   #142	-> 473
/*     */     //   #143	-> 497
/*     */     //   #145	-> 502
/*     */     //   #147	-> 524
/*     */     //   #148	-> 542
/*     */     //   #149	-> 555
/*     */     //   #153	-> 597
/*     */     //   #154	-> 604
/*     */     //   #155	-> 609
/*     */     //   #156	-> 616
/*     */     //   #157	-> 627
/*     */     //   #158	-> 669
/*     */     //   #159	-> 682
/*     */     //   #160	-> 689
/*     */     //   #161	-> 700
/*     */     //   #162	-> 732
/*     */     //   #163	-> 735
/*     */     //   #164	-> 742
/*     */     //   #165	-> 753
/*     */     //   #167	-> 790
/*     */     //   #168	-> 809
/*     */     //   #169	-> 857
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	descriptor
/*     */     //   0	858	0	this	Lorg/eclipse/jdt/internal/compiler/classfmt/ExternalAnnotationProvider;
/*     */     //   0	858	1	input	Ljava/io/InputStream;
/*     */     //   21	812	4	reader	Ljava/io/LineNumberReader;
/*     */     //   41	768	5	line	Ljava/lang/String;
/*     */     //   136	673	6	pendingLine	Ljava/lang/String;
/*     */     //   157	633	7	rawSig	Ljava/lang/String;
/*     */     //   160	630	8	annotSig	Ljava/lang/String;
/*     */     //   164	626	9	selector	Ljava/lang/String;
/*     */     //   261	529	10	isSuper	Z
/*     */     //   281	509	11	errLine	I
/*     */     //   285	505	12	errDetail	Ljava/lang/String;
/*     */     //   334	38	13	trimmed	Ljava/lang/String;
/*     */     //   462	35	13	trimmed	Ljava/lang/String;
/*     */     //   502	22	13	ex	Ljava/lang/Exception;
/*     */     // Exception table:
/*     */     //   from	to	target	type
/*     */     //   4	54	835	finally
/*     */     //   21	44	822	finally
/*     */     //   55	76	822	finally
/*     */     //   55	86	835	finally
/*     */     //   87	122	822	finally
/*     */     //   87	132	835	finally
/*     */     //   133	809	822	finally
/*     */     //   133	835	835	finally
/*     */     //   285	369	500	java/lang/Exception
/*     */     //   372	423	500	java/lang/Exception
/*     */     //   426	441	500	java/lang/Exception
/*     */     //   444	497	500	java/lang/Exception
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean isValidSignature(String trim, boolean expectTypeArguments) {
/* 172 */     if (trim.length() > 0) {
/* 173 */       char first = trim.charAt(0);
/* 174 */       if (expectTypeArguments) {
/* 175 */         return (first == '<');
/*     */       }
/* 177 */       if (first == '(' || (first == '<' && trim.indexOf('(') != -1)) {
/* 178 */         return true;
/*     */       }
/* 180 */       return isValidTypeSignature(trim.toCharArray());
/*     */     } 
/* 182 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   private boolean isValidTypeSignature(char[] typeSignature) {
/* 187 */     if (typeSignature.length < 1) {
/* 188 */       return false;
/*     */     }
/* 190 */     char c = typeSignature[0];
/* 191 */     if (c == '<') {
/* 192 */       int count = 1;
/* 193 */       for (int i = 1, length = typeSignature.length; i < length; i++) {
/* 194 */         switch (typeSignature[i]) {
/*     */           case '<':
/* 196 */             count++;
/*     */             break;
/*     */           case '>':
/* 199 */             count--;
/*     */             break;
/*     */         } 
/* 202 */         if (count == 0) {
/* 203 */           if (i + 1 < length)
/* 204 */             c = typeSignature[i + 1]; 
/*     */           break;
/*     */         } 
/*     */       } 
/*     */     } 
/* 209 */     switch (c) {
/*     */       case '!':
/*     */       case '*':
/*     */       case '+':
/*     */       case '-':
/*     */       case 'B':
/*     */       case 'C':
/*     */       case 'D':
/*     */       case 'F':
/*     */       case 'I':
/*     */       case 'J':
/*     */       case 'L':
/*     */       case 'Q':
/*     */       case 'S':
/*     */       case 'T':
/*     */       case 'V':
/*     */       case 'Z':
/*     */       case '[':
/* 227 */         return true;
/*     */     } 
/* 229 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void assertClassHeader(String line, String typeName) throws IOException {
/* 237 */     if (line != null && line.startsWith("class ")) {
/* 238 */       line = line.substring("class ".length());
/*     */     } else {
/* 240 */       throw new IOException("missing class header in annotation file for " + typeName);
/*     */     } 
/* 242 */     if (!trimTail(line).equals(typeName)) {
/* 243 */       throw new IOException("mismatching class name in annotation file, expected " + typeName + ", but header said " + line);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String extractSignature(String line) {
/* 252 */     if (line == null || line.isEmpty() || line.charAt(0) != ' ')
/* 253 */       return null; 
/* 254 */     return trimTail(line.substring(1));
/*     */   }
/*     */ 
/*     */   
/*     */   protected static String trimTail(String line) {
/* 259 */     int tail = line.indexOf(' ');
/* 260 */     if (tail == -1)
/* 261 */       tail = line.indexOf('\t'); 
/* 262 */     if (tail != -1)
/* 263 */       return line.substring(0, tail); 
/* 264 */     return line;
/*     */   }
/*     */   
/*     */   public ITypeAnnotationWalker forTypeHeader(LookupEnvironment environment) {
/* 268 */     if (this.typeParametersAnnotationSource != null || this.supertypeAnnotationSources != null)
/* 269 */       return new DispatchingAnnotationWalker(environment); 
/* 270 */     return ITypeAnnotationWalker.EMPTY_ANNOTATION_WALKER;
/*     */   }
/*     */   
/*     */   public ITypeAnnotationWalker forMethod(char[] selector, char[] signature, LookupEnvironment environment) {
/* 274 */     Map<String, String> sources = this.methodAnnotationSources;
/* 275 */     if (sources != null) {
/* 276 */       String source = sources.get(String.valueOf(CharOperation.concat(selector, signature)));
/* 277 */       if (source != null)
/* 278 */         return new MethodAnnotationWalker(source.toCharArray(), 0, environment); 
/*     */     } 
/* 280 */     return ITypeAnnotationWalker.EMPTY_ANNOTATION_WALKER;
/*     */   }
/*     */   
/*     */   public ITypeAnnotationWalker forField(char[] selector, char[] signature, LookupEnvironment environment) {
/* 284 */     if (this.fieldAnnotationSources != null) {
/* 285 */       String source = this.fieldAnnotationSources.get(String.valueOf(CharOperation.concat(selector, signature, ':')));
/* 286 */       if (source != null)
/* 287 */         return new FieldAnnotationWalker(source.toCharArray(), 0, environment); 
/*     */     } 
/* 289 */     return ITypeAnnotationWalker.EMPTY_ANNOTATION_WALKER;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 294 */     StringBuilder sb = new StringBuilder();
/* 295 */     sb.append("External Annotations for ").append(this.typeName).append('\n');
/* 296 */     sb.append("Methods:\n");
/* 297 */     if (this.methodAnnotationSources != null)
/* 298 */       for (Map.Entry<String, String> e : this.methodAnnotationSources.entrySet())
/* 299 */         sb.append('\t').append(e.getKey()).append('\n');  
/* 300 */     return sb.toString();
/*     */   }
/*     */   
/*     */   static abstract class SingleMarkerAnnotation
/*     */     implements IBinaryAnnotation {
/*     */     public IBinaryElementValuePair[] getElementValuePairs() {
/* 306 */       return (IBinaryElementValuePair[])ElementValuePairInfo.NoMembers;
/*     */     }
/*     */     
/*     */     public boolean isExternalAnnotation() {
/* 310 */       return true;
/*     */     }
/*     */     protected char[] getBinaryTypeName(char[][] name) {
/* 313 */       return CharOperation.concat('L', CharOperation.concatWith(name, '/'), ';');
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   void initAnnotations(final LookupEnvironment environment) {
/* 320 */     if (this.NULLABLE_ANNOTATION == null)
/* 321 */       this.NULLABLE_ANNOTATION = new SingleMarkerAnnotation() { public char[] getTypeName() {
/* 322 */             return getBinaryTypeName(environment.getNullableAnnotationName());
/*     */           } }
/*     */         ; 
/* 325 */     if (this.NONNULL_ANNOTATION == null) {
/* 326 */       this.NONNULL_ANNOTATION = new SingleMarkerAnnotation() { public char[] getTypeName() {
/* 327 */             return getBinaryTypeName(environment.getNonNullAnnotationName());
/*     */           } }
/*     */         ;
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   class DispatchingAnnotationWalker
/*     */     implements ITypeAnnotationWalker
/*     */   {
/*     */     private LookupEnvironment environment;
/*     */     
/*     */     private ExternalAnnotationProvider.TypeParametersAnnotationWalker typeParametersWalker;
/*     */     
/*     */     public DispatchingAnnotationWalker(LookupEnvironment environment) {
/* 342 */       this.environment = environment;
/*     */     }
/*     */     
/*     */     public ITypeAnnotationWalker toTypeParameter(boolean isClassTypeParameter, int rank) {
/* 346 */       String source = ExternalAnnotationProvider.this.typeParametersAnnotationSource;
/* 347 */       if (source != null) {
/* 348 */         if (this.typeParametersWalker == null)
/* 349 */           this.typeParametersWalker = new ExternalAnnotationProvider.TypeParametersAnnotationWalker(source.toCharArray(), 0, 0, null, this.environment); 
/* 350 */         return this.typeParametersWalker.toTypeParameter(isClassTypeParameter, rank);
/*     */       } 
/* 352 */       return this;
/*     */     }
/*     */     
/*     */     public ITypeAnnotationWalker toTypeParameterBounds(boolean isClassTypeParameter, int parameterRank) {
/* 356 */       if (this.typeParametersWalker != null)
/* 357 */         return this.typeParametersWalker.toTypeParameterBounds(isClassTypeParameter, parameterRank); 
/* 358 */       return this;
/*     */     }
/*     */     
/*     */     public ITypeAnnotationWalker toSupertype(short index, char[] superTypeSignature) {
/* 362 */       Map<String, String> sources = ExternalAnnotationProvider.this.supertypeAnnotationSources;
/* 363 */       if (sources != null) {
/* 364 */         String source = sources.get(String.valueOf(superTypeSignature));
/* 365 */         if (source != null)
/* 366 */           return new ExternalAnnotationProvider.SuperTypesAnnotationWalker(source.toCharArray(), this.environment); 
/*     */       } 
/* 368 */       return this;
/*     */     }
/*     */     
/*     */     public ITypeAnnotationWalker toField() {
/* 372 */       return this;
/*     */     } public ITypeAnnotationWalker toThrows(int rank) {
/* 374 */       return this;
/*     */     } public ITypeAnnotationWalker toTypeArgument(int rank) {
/* 376 */       return this;
/*     */     } public ITypeAnnotationWalker toMethodParameter(short index) {
/* 378 */       return this;
/*     */     } public ITypeAnnotationWalker toTypeBound(short boundIndex) {
/* 380 */       return this;
/*     */     } public ITypeAnnotationWalker toMethodReturn() {
/* 382 */       return this;
/*     */     } public ITypeAnnotationWalker toReceiver() {
/* 384 */       return this;
/*     */     } public ITypeAnnotationWalker toWildcardBound() {
/* 386 */       return this;
/*     */     } public ITypeAnnotationWalker toNextArrayDimension() {
/* 388 */       return this;
/*     */     } public ITypeAnnotationWalker toNextNestedType() {
/* 390 */       return this;
/*     */     } public IBinaryAnnotation[] getAnnotationsAtCursor(int currentTypeId, boolean mayApplyArrayContentsDefaultNullness) {
/* 392 */       return NO_ANNOTATIONS;
/*     */     }
/*     */   }
/*     */   
/*     */   abstract class BasicAnnotationWalker implements ITypeAnnotationWalker {
/*     */     char[] source;
/*     */     SignatureWrapper wrapper;
/*     */     int pos;
/*     */     int prevTypeArgStart;
/*     */     int currentTypeBound;
/*     */     LookupEnvironment environment;
/*     */     
/*     */     BasicAnnotationWalker(char[] source, int pos, LookupEnvironment environment) {
/* 405 */       this.source = source;
/* 406 */       this.pos = pos;
/* 407 */       this.environment = environment;
/* 408 */       ExternalAnnotationProvider.this.initAnnotations(environment);
/*     */     }
/*     */     
/*     */     SignatureWrapper wrapperWithStart(int start) {
/* 412 */       if (this.wrapper == null)
/* 413 */         this.wrapper = new SignatureWrapper(this.source); 
/* 414 */       this.wrapper.start = start;
/* 415 */       this.wrapper.bracket = -1;
/* 416 */       return this.wrapper;
/*     */     }
/*     */ 
/*     */     
/*     */     public ITypeAnnotationWalker toReceiver() {
/* 421 */       return ITypeAnnotationWalker.EMPTY_ANNOTATION_WALKER;
/*     */     }
/*     */ 
/*     */     
/*     */     public ITypeAnnotationWalker toTypeParameter(boolean isClassTypeParameter, int rank) {
/* 426 */       return ITypeAnnotationWalker.EMPTY_ANNOTATION_WALKER;
/*     */     }
/*     */ 
/*     */     
/*     */     public ITypeAnnotationWalker toTypeParameterBounds(boolean isClassTypeParameter, int parameterRank) {
/* 431 */       return ITypeAnnotationWalker.EMPTY_ANNOTATION_WALKER;
/*     */     }
/*     */ 
/*     */     
/*     */     public ITypeAnnotationWalker toTypeBound(short boundIndex) {
/* 436 */       return ITypeAnnotationWalker.EMPTY_ANNOTATION_WALKER;
/*     */     }
/*     */ 
/*     */     
/*     */     public ITypeAnnotationWalker toSupertype(short index, char[] superTypeSignature) {
/* 441 */       return ITypeAnnotationWalker.EMPTY_ANNOTATION_WALKER;
/*     */     }
/*     */ 
/*     */     
/*     */     public ITypeAnnotationWalker toTypeArgument(int rank) {
/* 446 */       if (rank == 0) {
/* 447 */         int start = CharOperation.indexOf('<', this.source, this.pos) + 1;
/* 448 */         this.prevTypeArgStart = start;
/* 449 */         return new ExternalAnnotationProvider.MethodAnnotationWalker(this.source, start, this.environment);
/*     */       } 
/* 451 */       int next = this.prevTypeArgStart;
/* 452 */       switch (this.source[next])
/*     */       { case '*':
/* 454 */           next = skipNullAnnotation(next + 1);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 464 */           this.prevTypeArgStart = next;
/* 465 */           return new ExternalAnnotationProvider.MethodAnnotationWalker(this.source, next, this.environment);case '+': case '-': next = skipNullAnnotation(next + 1); break; }  next = wrapperWithStart(next).computeEnd(); this.prevTypeArgStart = ++next; return new ExternalAnnotationProvider.MethodAnnotationWalker(this.source, next, this.environment);
/*     */     }
/*     */     
/*     */     public ITypeAnnotationWalker toWildcardBound() {
/*     */       int newPos;
/* 470 */       switch (this.source[this.pos]) {
/*     */         case '+':
/*     */         case '-':
/* 473 */           newPos = skipNullAnnotation(this.pos + 1);
/* 474 */           return new ExternalAnnotationProvider.MethodAnnotationWalker(this.source, newPos, this.environment);
/*     */       } 
/* 476 */       return ITypeAnnotationWalker.EMPTY_ANNOTATION_WALKER;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public ITypeAnnotationWalker toNextArrayDimension() {
/* 482 */       if (this.source[this.pos] == '[') {
/* 483 */         int newPos = skipNullAnnotation(this.pos + 1);
/* 484 */         return new ExternalAnnotationProvider.MethodAnnotationWalker(this.source, newPos, this.environment);
/*     */       } 
/* 486 */       return ITypeAnnotationWalker.EMPTY_ANNOTATION_WALKER;
/*     */     }
/*     */ 
/*     */     
/*     */     public ITypeAnnotationWalker toNextNestedType() {
/* 491 */       return this;
/*     */     }
/*     */ 
/*     */     
/*     */     public IBinaryAnnotation[] getAnnotationsAtCursor(int currentTypeId, boolean mayApplyArrayContentsDefaultNullness) {
/* 496 */       if (this.pos != -1 && this.pos < this.source.length - 2)
/* 497 */         switch (this.source[this.pos]) {
/*     */           case '*':
/*     */           case '+':
/*     */           case '-':
/*     */           case 'L':
/*     */           case 'T':
/*     */           case '[':
/* 504 */             switch (this.source[this.pos + 1]) {
/*     */               case '0':
/* 506 */                 return new IBinaryAnnotation[] { this.this$0.NULLABLE_ANNOTATION };
/*     */               case '1':
/* 508 */                 return new IBinaryAnnotation[] { this.this$0.NONNULL_ANNOTATION };
/*     */             } 
/*     */             break;
/*     */         }  
/* 512 */       return NO_ANNOTATIONS;
/*     */     }
/*     */     int skipNullAnnotation(int cur) {
/* 515 */       if (cur >= this.source.length)
/* 516 */         return cur; 
/* 517 */       switch (this.source[cur]) {
/*     */         case '0':
/*     */         case '1':
/* 520 */           return cur + 1;
/*     */       } 
/* 522 */       return cur;
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public class TypeParametersAnnotationWalker
/*     */     extends BasicAnnotationWalker
/*     */   {
/*     */     int[] rankStarts;
/*     */     
/*     */     int currentRank;
/*     */ 
/*     */     
/*     */     TypeParametersAnnotationWalker(char[] source, int pos, int rank, int[] rankStarts, LookupEnvironment environment) {
/* 536 */       super(source, pos, environment);
/* 537 */       this.currentRank = rank;
/* 538 */       if (rankStarts != null) {
/* 539 */         this.rankStarts = rankStarts;
/*     */       } else {
/*     */         
/* 542 */         int length = source.length;
/* 543 */         rankStarts = new int[length];
/* 544 */         int curRank = 0;
/*     */         
/* 546 */         int depth = 0;
/* 547 */         boolean pendingVariable = true;
/*     */         
/* 549 */         for (int i = pos; i < length; i++) {
/* 550 */           switch (this.source[i]) {
/*     */             case '<':
/* 552 */               depth++;
/*     */               break;
/*     */             case '>':
/* 555 */               if (--depth < 0)
/*     */                 break; 
/*     */               break;
/*     */             case ';':
/* 559 */               if (depth == 0 && i + 1 < length && this.source[i + 1] != ':')
/* 560 */                 pendingVariable = true; 
/*     */               break;
/*     */             case ':':
/* 563 */               if (depth == 0) {
/* 564 */                 pendingVariable = true;
/*     */               }
/* 566 */               i++;
/* 567 */               while (i < length && this.source[i] == '[')
/* 568 */                 i++; 
/* 569 */               if (i < length && this.source[i] == 'L') {
/* 570 */                 int currentdepth = depth;
/* 571 */                 while (i < length && (currentdepth != depth || this.source[i] != ';')) {
/* 572 */                   if (this.source[i] == '<')
/* 573 */                     currentdepth++; 
/* 574 */                   if (this.source[i] == '>')
/* 575 */                     currentdepth--; 
/* 576 */                   i++;
/*     */                 } 
/*     */               } 
/* 579 */               i--;
/*     */               break;
/*     */             default:
/* 582 */               if (pendingVariable) {
/* 583 */                 pendingVariable = false;
/* 584 */                 rankStarts[curRank++] = i;
/*     */               } 
/*     */               break;
/*     */           } 
/*     */         } 
/* 589 */         System.arraycopy(rankStarts, 0, this.rankStarts = new int[curRank], 0, curRank);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public ITypeAnnotationWalker toTypeParameter(boolean isClassTypeParameter, int rank) {
/* 595 */       if (rank == this.currentRank)
/* 596 */         return this; 
/* 597 */       if (rank < this.rankStarts.length)
/* 598 */         return new TypeParametersAnnotationWalker(this.source, this.rankStarts[rank], rank, this.rankStarts, this.environment); 
/* 599 */       return ITypeAnnotationWalker.EMPTY_ANNOTATION_WALKER;
/*     */     }
/*     */ 
/*     */     
/*     */     public ITypeAnnotationWalker toTypeParameterBounds(boolean isClassTypeParameter, int parameterRank) {
/* 604 */       return new TypeParametersAnnotationWalker(this.source, this.rankStarts[parameterRank], parameterRank, this.rankStarts, this.environment);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ITypeAnnotationWalker toTypeBound(short boundIndex) {
/* 611 */       int p = this.pos;
/* 612 */       int i = this.currentTypeBound;
/*     */       
/*     */       while (true) {
/* 615 */         int colon = CharOperation.indexOf(':', this.source, p);
/* 616 */         if (colon != -1)
/* 617 */           p = colon + 1; 
/* 618 */         if (++i > boundIndex)
/*     */           break; 
/* 620 */         p = wrapperWithStart(p).computeEnd() + 1;
/*     */       } 
/* 622 */       this.pos = p;
/* 623 */       this.currentTypeBound = boundIndex;
/* 624 */       return this;
/*     */     }
/*     */ 
/*     */     
/*     */     public ITypeAnnotationWalker toField() {
/* 629 */       throw new UnsupportedOperationException("Cannot navigate to fields");
/*     */     }
/*     */ 
/*     */     
/*     */     public ITypeAnnotationWalker toMethodReturn() {
/* 634 */       throw new UnsupportedOperationException("Cannot navigate to method return");
/*     */     }
/*     */ 
/*     */     
/*     */     public ITypeAnnotationWalker toMethodParameter(short index) {
/* 639 */       throw new UnsupportedOperationException("Cannot navigate to method parameter");
/*     */     }
/*     */ 
/*     */     
/*     */     public ITypeAnnotationWalker toThrows(int index) {
/* 644 */       throw new UnsupportedOperationException("Cannot navigate to throws");
/*     */     }
/*     */ 
/*     */     
/*     */     public IBinaryAnnotation[] getAnnotationsAtCursor(int currentTypeId, boolean mayApplyArrayContentsDefaultNullness) {
/* 649 */       if (this.pos != -1 && this.pos < this.source.length - 1) {
/* 650 */         switch (this.source[this.pos]) {
/*     */           case '0':
/* 652 */             return new IBinaryAnnotation[] { this.this$0.NULLABLE_ANNOTATION };
/*     */           case '1':
/* 654 */             return new IBinaryAnnotation[] { this.this$0.NONNULL_ANNOTATION };
/*     */         } 
/*     */       }
/* 657 */       return super.getAnnotationsAtCursor(currentTypeId, mayApplyArrayContentsDefaultNullness);
/*     */     }
/*     */   }
/*     */   
/*     */   class SuperTypesAnnotationWalker
/*     */     extends BasicAnnotationWalker
/*     */   {
/*     */     SuperTypesAnnotationWalker(char[] source, LookupEnvironment environment) {
/* 665 */       super(source, 0, environment);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ITypeAnnotationWalker toField() {
/* 672 */       throw new UnsupportedOperationException("Supertype has no field annotations");
/*     */     }
/*     */ 
/*     */     
/*     */     public ITypeAnnotationWalker toMethodReturn() {
/* 677 */       throw new UnsupportedOperationException("Supertype has no method return");
/*     */     }
/*     */ 
/*     */     
/*     */     public ITypeAnnotationWalker toMethodParameter(short index) {
/* 682 */       throw new UnsupportedOperationException("Supertype has no method parameter");
/*     */     }
/*     */ 
/*     */     
/*     */     public ITypeAnnotationWalker toThrows(int index) {
/* 687 */       throw new UnsupportedOperationException("Supertype has no throws");
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   class MethodAnnotationWalker
/*     */     extends BasicAnnotationWalker
/*     */     implements IMethodAnnotationWalker
/*     */   {
/*     */     int prevParamStart;
/*     */     ExternalAnnotationProvider.TypeParametersAnnotationWalker typeParametersWalker;
/*     */     
/*     */     MethodAnnotationWalker(char[] source, int pos, LookupEnvironment environment) {
/* 700 */       super(source, pos, environment);
/*     */     }
/*     */     
/*     */     int typeEnd(int start) {
/* 704 */       while (this.source[start] == '[') {
/* 705 */         start++;
/* 706 */         start = skipNullAnnotation(start);
/*     */       } 
/* 708 */       SignatureWrapper wrapper1 = wrapperWithStart(start);
/* 709 */       int end = wrapper1.skipAngleContents(wrapper1.computeEnd());
/* 710 */       return end;
/*     */     }
/*     */ 
/*     */     
/*     */     public ITypeAnnotationWalker toTypeParameter(boolean isClassTypeParameter, int rank) {
/* 715 */       if (this.source[0] == '<') {
/* 716 */         if (this.typeParametersWalker == null)
/* 717 */           return this.typeParametersWalker = new ExternalAnnotationProvider.TypeParametersAnnotationWalker(this.source, this.pos + 1, rank, null, this.environment); 
/* 718 */         return this.typeParametersWalker.toTypeParameter(isClassTypeParameter, rank);
/*     */       } 
/* 720 */       return ITypeAnnotationWalker.EMPTY_ANNOTATION_WALKER;
/*     */     }
/*     */ 
/*     */     
/*     */     public ITypeAnnotationWalker toTypeParameterBounds(boolean isClassTypeParameter, int parameterRank) {
/* 725 */       if (this.typeParametersWalker != null)
/* 726 */         return this.typeParametersWalker.toTypeParameterBounds(isClassTypeParameter, parameterRank); 
/* 727 */       return ITypeAnnotationWalker.EMPTY_ANNOTATION_WALKER;
/*     */     }
/*     */ 
/*     */     
/*     */     public ITypeAnnotationWalker toMethodReturn() {
/* 732 */       int close = CharOperation.indexOf(')', this.source);
/* 733 */       if (close != -1) {
/*     */         
/* 735 */         this.pos = close + 1;
/* 736 */         return this;
/*     */       } 
/* 738 */       return ITypeAnnotationWalker.EMPTY_ANNOTATION_WALKER;
/*     */     }
/*     */ 
/*     */     
/*     */     public ITypeAnnotationWalker toMethodParameter(short index) {
/* 743 */       if (index == 0) {
/* 744 */         int start = CharOperation.indexOf('(', this.source) + 1;
/* 745 */         this.prevParamStart = start;
/*     */ 
/*     */         
/* 748 */         this.pos = start;
/* 749 */         return this;
/*     */       } 
/* 751 */       int end = typeEnd(this.prevParamStart);
/*     */       
/* 753 */       this.prevParamStart = ++end;
/*     */       
/* 755 */       this.pos = end;
/* 756 */       return this;
/*     */     }
/*     */ 
/*     */     
/*     */     public ITypeAnnotationWalker toThrows(int index) {
/* 761 */       return this;
/*     */     }
/*     */ 
/*     */     
/*     */     public ITypeAnnotationWalker toField() {
/* 766 */       throw new UnsupportedOperationException("Methods have no fields");
/*     */     }
/*     */ 
/*     */     
/*     */     public int getParameterCount() {
/* 771 */       int count = 0;
/* 772 */       int start = CharOperation.indexOf('(', this.source) + 1;
/* 773 */       while (start < this.source.length && this.source[start] != ')') {
/* 774 */         start = typeEnd(start) + 1;
/* 775 */         count++;
/*     */       } 
/* 777 */       return count;
/*     */     }
/*     */   }
/*     */   
/*     */   class FieldAnnotationWalker extends BasicAnnotationWalker {
/*     */     public FieldAnnotationWalker(char[] source, int pos, LookupEnvironment environment) {
/* 783 */       super(source, pos, environment);
/*     */     }
/*     */ 
/*     */     
/*     */     public ITypeAnnotationWalker toField() {
/* 788 */       return this;
/*     */     }
/*     */ 
/*     */     
/*     */     public ITypeAnnotationWalker toMethodReturn() {
/* 793 */       throw new UnsupportedOperationException("Field has no method return");
/*     */     }
/*     */ 
/*     */     
/*     */     public ITypeAnnotationWalker toMethodParameter(short index) {
/* 798 */       throw new UnsupportedOperationException("Field has no method parameter");
/*     */     }
/*     */ 
/*     */     
/*     */     public ITypeAnnotationWalker toThrows(int index) {
/* 803 */       throw new UnsupportedOperationException("Field has no throws");
/*     */     }
/*     */   }
/*     */   
/*     */   public static ITypeAnnotationWalker synthesizeForMethod(char[] source, LookupEnvironment env) {
/* 808 */     OUTER_FOR_PARTIAL_WALKERS.getClass(); return new MethodAnnotationWalker(source, 0, env);
/*     */   }
/*     */   
/*     */   public static interface IMethodAnnotationWalker extends ITypeAnnotationWalker {
/*     */     int getParameterCount();
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\classfmt\ExternalAnnotationProvider.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */