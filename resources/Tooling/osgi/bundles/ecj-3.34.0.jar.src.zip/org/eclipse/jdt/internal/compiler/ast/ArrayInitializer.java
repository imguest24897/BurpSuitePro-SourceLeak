/*     */ package org.eclipse.jdt.internal.compiler.ast;
/*     */ 
/*     */ import org.eclipse.jdt.internal.compiler.ASTVisitor;
/*     */ import org.eclipse.jdt.internal.compiler.codegen.CodeStream;
/*     */ import org.eclipse.jdt.internal.compiler.flow.FlowContext;
/*     */ import org.eclipse.jdt.internal.compiler.flow.FlowInfo;
/*     */ import org.eclipse.jdt.internal.compiler.flow.UnconditionalFlowInfo;
/*     */ import org.eclipse.jdt.internal.compiler.impl.CompilerOptions;
/*     */ import org.eclipse.jdt.internal.compiler.impl.Constant;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.ArrayBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.BlockScope;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.ReferenceBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.Scope;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.TypeBinding;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ArrayInitializer
/*     */   extends Expression
/*     */ {
/*     */   public Expression[] expressions;
/*     */   public ArrayBinding binding;
/*     */   
/*     */   public FlowInfo analyseCode(BlockScope currentScope, FlowContext flowContext, FlowInfo flowInfo) {
/*     */     FlowInfo flowInfo1;
/*  50 */     if (this.expressions != null) {
/*  51 */       CompilerOptions compilerOptions = currentScope.compilerOptions();
/*  52 */       boolean analyseResources = compilerOptions.analyseResourceLeaks;
/*  53 */       boolean evalNullTypeAnnotations = currentScope.environment().usesNullTypeAnnotations();
/*  54 */       for (int i = 0, max = this.expressions.length; i < max; i++) {
/*  55 */         UnconditionalFlowInfo unconditionalFlowInfo = this.expressions[i].analyseCode(currentScope, flowContext, flowInfo).unconditionalInits();
/*     */         
/*  57 */         if (analyseResources && FakedTrackingVariable.isAnyCloseable((this.expressions[i]).resolvedType)) {
/*  58 */           flowInfo1 = FakedTrackingVariable.markPassedToOutside(currentScope, this.expressions[i], (FlowInfo)unconditionalFlowInfo, flowContext, false);
/*     */         }
/*  60 */         if (evalNullTypeAnnotations) {
/*  61 */           checkAgainstNullTypeAnnotation(currentScope, this.binding.elementsType(), this.expressions[i], flowContext, flowInfo1);
/*     */         }
/*     */       } 
/*     */     } 
/*  65 */     return flowInfo1;
/*     */   }
/*     */ 
/*     */   
/*     */   public void generateCode(BlockScope currentScope, CodeStream codeStream, boolean valueRequired) {
/*  70 */     generateCode((TypeReference)null, (ArrayAllocationExpression)null, currentScope, codeStream, valueRequired);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void generateCode(TypeReference typeReference, ArrayAllocationExpression allocationExpression, BlockScope currentScope, CodeStream codeStream, boolean valueRequired) {
/*  79 */     int pc = codeStream.position;
/*  80 */     int expressionLength = (this.expressions == null) ? 0 : this.expressions.length;
/*  81 */     codeStream.generateInlinedValue(expressionLength);
/*  82 */     codeStream.newArray(typeReference, allocationExpression, this.binding);
/*  83 */     if (this.expressions != null) {
/*     */       
/*  85 */       int elementsTypeID = (this.binding.dimensions > 1) ? -1 : this.binding.leafComponentType.id;
/*  86 */       for (int i = 0; i < expressionLength; i++) {
/*     */         Expression expr;
/*  88 */         if ((expr = this.expressions[i]).constant != Constant.NotAConstant) {
/*  89 */           double constantValue; switch (elementsTypeID) {
/*     */             case 2:
/*     */             case 3:
/*     */             case 4:
/*     */             case 7:
/*     */             case 10:
/*  95 */               if (expr.constant.longValue() != 0L) {
/*  96 */                 codeStream.dup();
/*  97 */                 codeStream.generateInlinedValue(i);
/*  98 */                 expr.generateCode(currentScope, codeStream, true);
/*  99 */                 codeStream.arrayAtPut(elementsTypeID, false);
/*     */               } 
/*     */               break;
/*     */             case 8:
/*     */             case 9:
/* 104 */               constantValue = expr.constant.doubleValue();
/* 105 */               if (constantValue == -0.0D || constantValue != 0.0D) {
/* 106 */                 codeStream.dup();
/* 107 */                 codeStream.generateInlinedValue(i);
/* 108 */                 expr.generateCode(currentScope, codeStream, true);
/* 109 */                 codeStream.arrayAtPut(elementsTypeID, false);
/*     */               } 
/*     */               break;
/*     */             case 5:
/* 113 */               if (expr.constant.booleanValue()) {
/* 114 */                 codeStream.dup();
/* 115 */                 codeStream.generateInlinedValue(i);
/* 116 */                 expr.generateCode(currentScope, codeStream, true);
/* 117 */                 codeStream.arrayAtPut(elementsTypeID, false);
/*     */               } 
/*     */               break;
/*     */             default:
/* 121 */               if (!(expr instanceof NullLiteral)) {
/* 122 */                 codeStream.dup();
/* 123 */                 codeStream.generateInlinedValue(i);
/* 124 */                 expr.generateCode(currentScope, codeStream, true);
/* 125 */                 codeStream.arrayAtPut(elementsTypeID, false);
/*     */               }  break;
/*     */           } 
/* 128 */         } else if (!(expr instanceof NullLiteral)) {
/* 129 */           codeStream.dup();
/* 130 */           codeStream.generateInlinedValue(i);
/* 131 */           expr.generateCode(currentScope, codeStream, true);
/* 132 */           codeStream.arrayAtPut(elementsTypeID, false);
/*     */         } 
/*     */       } 
/*     */     } 
/* 136 */     if (valueRequired) {
/* 137 */       codeStream.generateImplicitConversion(this.implicitConversion);
/*     */     } else {
/* 139 */       codeStream.pop();
/*     */     } 
/* 141 */     codeStream.recordPositionsFrom(pc, this.sourceStart);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public StringBuffer printExpression(int indent, StringBuffer output) {
/* 147 */     output.append('{');
/* 148 */     if (this.expressions != null) {
/* 149 */       int j = 20;
/* 150 */       for (int i = 0; i < this.expressions.length; i++) {
/* 151 */         if (i > 0) output.append(", "); 
/* 152 */         this.expressions[i].printExpression(0, output);
/* 153 */         j--;
/* 154 */         if (j == 0) {
/* 155 */           output.append('\n');
/* 156 */           printIndent(indent + 1, output);
/* 157 */           j = 20;
/*     */         } 
/*     */       } 
/*     */     } 
/* 161 */     return output.append('}');
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TypeBinding resolveTypeExpecting(BlockScope scope, TypeBinding expectedType) {
/* 172 */     this.constant = Constant.NotAConstant;
/*     */     
/* 174 */     if (expectedType instanceof ArrayBinding) {
/*     */       
/* 176 */       if ((this.bits & 0x1) == 0) {
/*     */         
/* 178 */         TypeBinding leafComponentType = expectedType.leafComponentType();
/* 179 */         if (!leafComponentType.isReifiable()) {
/* 180 */           scope.problemReporter().illegalGenericArray(leafComponentType, this);
/*     */         }
/*     */       } 
/* 183 */       this.resolvedType = (TypeBinding)(this.binding = (ArrayBinding)expectedType);
/* 184 */       if (this.expressions == null)
/* 185 */         return (TypeBinding)this.binding; 
/* 186 */       TypeBinding elementType = this.binding.elementsType();
/* 187 */       for (int i = 0, length = this.expressions.length; i < length; i++) {
/* 188 */         Expression expression = this.expressions[i];
/* 189 */         expression.setExpressionContext(ExpressionContext.ASSIGNMENT_CONTEXT);
/* 190 */         expression.setExpectedType(elementType);
/* 191 */         TypeBinding expressionType = (expression instanceof ArrayInitializer) ? 
/* 192 */           expression.resolveTypeExpecting(scope, elementType) : 
/* 193 */           expression.resolveType(scope);
/* 194 */         if (expressionType != null) {
/*     */ 
/*     */ 
/*     */           
/* 198 */           if (TypeBinding.notEquals(elementType, expressionType)) {
/* 199 */             scope.compilationUnitScope().recordTypeConversion(elementType, expressionType);
/*     */           }
/* 201 */           if (expression.isConstantValueOfTypeAssignableToType(expressionType, elementType) || 
/* 202 */             expressionType.isCompatibleWith(elementType)) {
/* 203 */             expression.computeConversion((Scope)scope, elementType, expressionType);
/* 204 */           } else if (isBoxingCompatible(expressionType, elementType, expression, (Scope)scope)) {
/* 205 */             expression.computeConversion((Scope)scope, elementType, expressionType);
/*     */           } else {
/* 207 */             scope.problemReporter().typeMismatchError(expressionType, elementType, expression, null);
/*     */           } 
/*     */         } 
/* 210 */       }  return (TypeBinding)this.binding;
/*     */     } 
/*     */ 
/*     */     
/* 214 */     TypeBinding leafElementType = null;
/* 215 */     int dim = 1;
/* 216 */     if (this.expressions == null) {
/* 217 */       ReferenceBinding referenceBinding = scope.getJavaLangObject();
/*     */     } else {
/* 219 */       Expression expression = this.expressions[0];
/* 220 */       while (expression != null && expression instanceof ArrayInitializer) {
/* 221 */         dim++;
/* 222 */         Expression[] subExprs = ((ArrayInitializer)expression).expressions;
/* 223 */         if (subExprs == null) {
/* 224 */           ReferenceBinding referenceBinding = scope.getJavaLangObject();
/* 225 */           expression = null;
/*     */           break;
/*     */         } 
/* 228 */         expression = ((ArrayInitializer)expression).expressions[0];
/*     */       } 
/* 230 */       if (expression != null) {
/* 231 */         leafElementType = expression.resolveType(scope);
/*     */       }
/*     */       
/* 234 */       for (int i = 1, length = this.expressions.length; i < length; i++) {
/* 235 */         expression = this.expressions[i];
/* 236 */         if (expression != null)
/* 237 */           expression.resolveType(scope); 
/*     */       } 
/*     */     } 
/* 240 */     if (leafElementType != null) {
/* 241 */       this.resolvedType = (TypeBinding)scope.createArrayType(leafElementType, dim);
/* 242 */       if (expectedType != null)
/* 243 */         scope.problemReporter().typeMismatchError(this.resolvedType, expectedType, this, null); 
/*     */     } 
/* 245 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void traverse(ASTVisitor visitor, BlockScope scope) {
/* 251 */     if (visitor.visit(this, scope) && 
/* 252 */       this.expressions != null) {
/* 253 */       int expressionsLength = this.expressions.length;
/* 254 */       for (int i = 0; i < expressionsLength; i++) {
/* 255 */         this.expressions[i].traverse(visitor, scope);
/*     */       }
/*     */     } 
/* 258 */     visitor.endVisit(this, scope);
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\ast\ArrayInitializer.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */