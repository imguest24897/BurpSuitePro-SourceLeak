package org.eclipse.jdt.internal.compiler.env;

import java.util.Collection;

public interface IMultiModuleEntry extends IModulePathEntry {
  IModule getModule(char[] paramArrayOfchar);
  
  Collection<String> getModuleNames(Collection<String> paramCollection);
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\env\IMultiModuleEntry.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */