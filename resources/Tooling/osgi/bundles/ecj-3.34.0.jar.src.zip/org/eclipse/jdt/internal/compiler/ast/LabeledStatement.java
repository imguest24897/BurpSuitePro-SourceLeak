/*     */ package org.eclipse.jdt.internal.compiler.ast;
/*     */ 
/*     */ import org.eclipse.jdt.internal.compiler.ASTVisitor;
/*     */ import org.eclipse.jdt.internal.compiler.codegen.BranchLabel;
/*     */ import org.eclipse.jdt.internal.compiler.codegen.CodeStream;
/*     */ import org.eclipse.jdt.internal.compiler.flow.FlowContext;
/*     */ import org.eclipse.jdt.internal.compiler.flow.FlowInfo;
/*     */ import org.eclipse.jdt.internal.compiler.flow.LabelFlowContext;
/*     */ import org.eclipse.jdt.internal.compiler.flow.UnconditionalFlowInfo;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.BlockScope;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.Scope;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LabeledStatement
/*     */   extends Statement
/*     */ {
/*     */   public Statement statement;
/*     */   public char[] label;
/*     */   public BranchLabel targetLabel;
/*     */   public int labelEnd;
/*  29 */   int mergedInitStateIndex = -1;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LabeledStatement(char[] label, Statement statement, long labelPosition, int sourceEnd) {
/*  36 */     this.statement = statement;
/*     */     
/*  38 */     if (statement instanceof EmptyStatement) statement.bits |= 0x1; 
/*  39 */     this.label = label;
/*  40 */     this.sourceStart = (int)(labelPosition >>> 32L);
/*  41 */     this.labelEnd = (int)labelPosition;
/*  42 */     this.sourceEnd = sourceEnd;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public FlowInfo analyseCode(BlockScope currentScope, FlowContext flowContext, FlowInfo flowInfo) {
/*  53 */     if (this.statement == null) {
/*  54 */       return flowInfo;
/*     */     }
/*     */     
/*     */     LabelFlowContext labelContext;
/*  58 */     FlowInfo statementInfo = this.statement.analyseCode(
/*  59 */         currentScope, 
/*  60 */         (FlowContext)(labelContext = 
/*  61 */         new LabelFlowContext(
/*  62 */           flowContext, 
/*  63 */           this, 
/*  64 */           this.label, 
/*  65 */           this.targetLabel = new BranchLabel(), 
/*  66 */           currentScope)), 
/*  67 */         flowInfo);
/*  68 */     boolean reinjectNullInfo = ((statementInfo.tagBits & 0x3) != 0 && (
/*  69 */       labelContext.initsOnBreak.tagBits & 0x3) == 0);
/*  70 */     UnconditionalFlowInfo unconditionalFlowInfo = statementInfo.mergedWith(labelContext.initsOnBreak);
/*  71 */     if (reinjectNullInfo)
/*     */     {
/*  73 */       unconditionalFlowInfo.addNullInfoFrom((FlowInfo)flowInfo.unconditionalFieldLessCopy())
/*  74 */         .addNullInfoFrom((FlowInfo)labelContext.initsOnBreak.unconditionalFieldLessCopy());
/*     */     }
/*  76 */     this.mergedInitStateIndex = 
/*  77 */       currentScope.methodScope().recordInitializationStates((FlowInfo)unconditionalFlowInfo);
/*  78 */     if ((this.bits & 0x40) == 0) {
/*  79 */       currentScope.problemReporter().unusedLabel(this);
/*     */     }
/*  81 */     return (FlowInfo)unconditionalFlowInfo;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ASTNode concreteStatement() {
/*  89 */     return this.statement;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void generateCode(BlockScope currentScope, CodeStream codeStream) {
/* 103 */     if ((this.bits & Integer.MIN_VALUE) == 0) {
/*     */       return;
/*     */     }
/* 106 */     int pc = codeStream.position;
/* 107 */     if (this.targetLabel != null) {
/* 108 */       this.targetLabel.initialize(codeStream);
/* 109 */       if (this.statement != null) {
/* 110 */         this.statement.generateCode(currentScope, codeStream);
/*     */       }
/* 112 */       this.targetLabel.place();
/*     */     } 
/*     */     
/* 115 */     if (this.mergedInitStateIndex != -1) {
/* 116 */       codeStream.removeNotDefinitelyAssignedVariables((Scope)currentScope, this.mergedInitStateIndex);
/* 117 */       codeStream.addDefinitelyAssignedVariables((Scope)currentScope, this.mergedInitStateIndex);
/*     */     } 
/* 119 */     codeStream.recordPositionsFrom(pc, this.sourceStart);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public StringBuffer printStatement(int tab, StringBuffer output) {
/* 125 */     printIndent(tab, output).append(this.label).append(": ");
/* 126 */     if (this.statement == null) {
/* 127 */       output.append(';');
/*     */     } else {
/* 129 */       this.statement.printStatement(0, output);
/* 130 */     }  return output;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void resolve(BlockScope scope) {
/* 136 */     if (this.statement != null) {
/* 137 */       this.statement.resolve(scope);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void traverse(ASTVisitor visitor, BlockScope blockScope) {
/* 147 */     if (visitor.visit(this, blockScope) && 
/* 148 */       this.statement != null) this.statement.traverse(visitor, blockScope);
/*     */     
/* 150 */     visitor.endVisit(this, blockScope);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean doesNotCompleteNormally() {
/* 155 */     if (this.statement.breaksOut(this.label))
/* 156 */       return false; 
/* 157 */     return this.statement.doesNotCompleteNormally();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean completesByContinue() {
/* 162 */     return this.statement instanceof ContinueStatement;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean canCompleteNormally() {
/* 167 */     if (this.statement.canCompleteNormally())
/* 168 */       return true; 
/* 169 */     return this.statement.breaksOut(this.label);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean continueCompletes() {
/* 174 */     return this.statement instanceof ContinueStatement;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\ast\LabeledStatement.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */