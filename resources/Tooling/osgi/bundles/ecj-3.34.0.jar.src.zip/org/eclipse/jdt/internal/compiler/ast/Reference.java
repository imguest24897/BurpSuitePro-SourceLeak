/*     */ package org.eclipse.jdt.internal.compiler.ast;
/*     */ 
/*     */ import org.eclipse.jdt.internal.compiler.codegen.CodeStream;
/*     */ import org.eclipse.jdt.internal.compiler.flow.FlowContext;
/*     */ import org.eclipse.jdt.internal.compiler.flow.FlowInfo;
/*     */ import org.eclipse.jdt.internal.compiler.impl.Constant;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.BlockScope;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.FieldBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.LocalVariableBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.MethodBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.MethodScope;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.Scope;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.TypeBinding;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class Reference
/*     */   extends Expression
/*     */ {
/*     */   public abstract FlowInfo analyseAssignment(BlockScope paramBlockScope, FlowContext paramFlowContext, FlowInfo paramFlowInfo, Assignment paramAssignment, boolean paramBoolean);
/*     */   
/*     */   public FlowInfo analyseCode(BlockScope currentScope, FlowContext flowContext, FlowInfo flowInfo) {
/*  52 */     return flowInfo;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean checkNPE(BlockScope scope, FlowContext flowContext, FlowInfo flowInfo, int ttlForFieldCheck) {
/*  57 */     if (flowContext.isNullcheckedFieldAccess(this)) {
/*  58 */       return true;
/*     */     }
/*  60 */     return super.checkNPE(scope, flowContext, flowInfo, ttlForFieldCheck);
/*     */   }
/*     */   
/*     */   protected boolean checkNullableFieldDereference(Scope scope, FieldBinding field, long sourcePosition, FlowContext flowContext, int ttlForFieldCheck) {
/*  64 */     if (field != null) {
/*  65 */       if (ttlForFieldCheck > 0 && (scope.compilerOptions()).enableSyntacticNullAnalysisForFields) {
/*  66 */         flowContext.recordNullCheckedFieldReference(this, ttlForFieldCheck);
/*     */       }
/*  68 */       if ((field.type.tagBits & 0x80000000000000L) != 0L) {
/*  69 */         scope.problemReporter().dereferencingNullableExpression(sourcePosition, scope.environment());
/*  70 */         return true;
/*     */       } 
/*  72 */       if (field.type.isFreeTypeVariable()) {
/*  73 */         scope.problemReporter().fieldFreeTypeVariableReference(field, sourcePosition);
/*  74 */         return true;
/*     */       } 
/*  76 */       if ((field.tagBits & 0x80000000000000L) != 0L) {
/*  77 */         scope.problemReporter().nullableFieldDereference(field, sourcePosition);
/*  78 */         return true;
/*     */       } 
/*     */     } 
/*  81 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public FieldBinding fieldBinding() {
/*  87 */     return null;
/*     */   }
/*     */   
/*     */   public void fieldStore(Scope currentScope, CodeStream codeStream, FieldBinding fieldBinding, MethodBinding syntheticWriteAccessor, TypeBinding receiverType, boolean isImplicitThisReceiver, boolean valueRequired) {
/*  91 */     int pc = codeStream.position;
/*  92 */     if (fieldBinding.isStatic()) {
/*  93 */       if (valueRequired) {
/*  94 */         switch (fieldBinding.type.id) {
/*     */           case 7:
/*     */           case 8:
/*  97 */             codeStream.dup2();
/*     */             break;
/*     */           default:
/* 100 */             codeStream.dup();
/*     */             break;
/*     */         } 
/*     */       }
/* 104 */       if (syntheticWriteAccessor == null) {
/* 105 */         TypeBinding constantPoolDeclaringClass = CodeStream.getConstantPoolDeclaringClass(currentScope, fieldBinding, receiverType, isImplicitThisReceiver);
/* 106 */         codeStream.fieldAccess((byte)-77, fieldBinding, constantPoolDeclaringClass);
/*     */       } else {
/* 108 */         codeStream.invoke((byte)-72, syntheticWriteAccessor, null);
/*     */       } 
/*     */     } else {
/* 111 */       if (valueRequired) {
/* 112 */         switch (fieldBinding.type.id) {
/*     */           case 7:
/*     */           case 8:
/* 115 */             codeStream.dup2_x1();
/*     */             break;
/*     */           default:
/* 118 */             codeStream.dup_x1();
/*     */             break;
/*     */         } 
/*     */       }
/* 122 */       if (syntheticWriteAccessor == null) {
/* 123 */         TypeBinding constantPoolDeclaringClass = CodeStream.getConstantPoolDeclaringClass(currentScope, fieldBinding, receiverType, isImplicitThisReceiver);
/* 124 */         codeStream.fieldAccess((byte)-75, fieldBinding, constantPoolDeclaringClass);
/*     */       } else {
/* 126 */         codeStream.invoke((byte)-72, syntheticWriteAccessor, null);
/*     */       } 
/*     */     } 
/* 129 */     codeStream.recordPositionsFrom(pc, this.sourceStart);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract void generateAssignment(BlockScope paramBlockScope, CodeStream paramCodeStream, Assignment paramAssignment, boolean paramBoolean);
/*     */ 
/*     */   
/*     */   public abstract void generateCompoundAssignment(BlockScope paramBlockScope, CodeStream paramCodeStream, Expression paramExpression, int paramInt1, int paramInt2, boolean paramBoolean);
/*     */ 
/*     */   
/*     */   public abstract void generatePostIncrement(BlockScope paramBlockScope, CodeStream paramCodeStream, CompoundAssignment paramCompoundAssignment, boolean paramBoolean);
/*     */ 
/*     */   
/*     */   public boolean isEquivalent(Reference reference) {
/* 144 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public FieldBinding lastFieldBinding() {
/* 150 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public int nullStatus(FlowInfo flowInfo, FlowContext flowContext) {
/* 155 */     if ((this.implicitConversion & 0x200) != 0)
/* 156 */       return 4; 
/* 157 */     FieldBinding fieldBinding = lastFieldBinding();
/* 158 */     if (fieldBinding != null) {
/* 159 */       if (fieldBinding.isFinal() && fieldBinding.constant() != Constant.NotAConstant)
/* 160 */         return 4; 
/* 161 */       if (fieldBinding.isNonNull() || flowContext.isNullcheckedFieldAccess(this))
/* 162 */         return 4; 
/* 163 */       if (fieldBinding.isNullable())
/* 164 */         return 16; 
/* 165 */       if (fieldBinding.type.isFreeTypeVariable()) {
/* 166 */         return 48;
/*     */       }
/*     */     } 
/* 169 */     if (this.resolvedType != null) {
/* 170 */       return FlowInfo.tagBitsToNullStatus(this.resolvedType.tagBits);
/*     */     }
/* 172 */     return 1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void reportOnlyUselesslyReadPrivateField(BlockScope currentScope, FieldBinding fieldBinding, boolean valueRequired) {
/* 179 */     if (valueRequired) {
/*     */       
/* 181 */       fieldBinding.compoundUseFlag = 0;
/* 182 */       fieldBinding.modifiers |= 0x8000000;
/*     */     }
/* 184 */     else if (fieldBinding.isUsedOnlyInCompound()) {
/* 185 */       fieldBinding.compoundUseFlag--;
/* 186 */       if (fieldBinding.compoundUseFlag == 0 && 
/* 187 */         fieldBinding.isOrEnclosedByPrivateType() && (
/* 188 */         this.implicitConversion & 0x400) == 0)
/*     */       {
/*     */         
/* 191 */         currentScope.problemReporter().unusedPrivateField(fieldBinding.sourceField());
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static void reportOnlyUselesslyReadLocal(BlockScope currentScope, LocalVariableBinding localBinding, boolean valueRequired) {
/* 200 */     if (localBinding.declaration == null)
/*     */       return; 
/* 202 */     if ((localBinding.declaration.bits & 0x40000000) == 0)
/*     */       return; 
/* 204 */     if (localBinding.useFlag >= 1) {
/*     */       return;
/*     */     }
/* 207 */     if (valueRequired) {
/*     */       
/* 209 */       localBinding.useFlag = 1;
/*     */       return;
/*     */     } 
/* 212 */     localBinding.useFlag++;
/* 213 */     if (localBinding.useFlag != 0) {
/*     */       return;
/*     */     }
/*     */     
/* 217 */     if (localBinding.declaration instanceof Argument) {
/*     */       
/* 219 */       MethodScope methodScope = currentScope.methodScope();
/* 220 */       if (methodScope != null && !methodScope.isLambdaScope()) {
/* 221 */         MethodBinding method = ((AbstractMethodDeclaration)methodScope.referenceContext()).binding;
/*     */         
/* 223 */         boolean shouldReport = !method.isMain();
/* 224 */         if (method.isImplementing()) {
/* 225 */           shouldReport &= (currentScope.compilerOptions()).reportUnusedParameterWhenImplementingAbstract;
/* 226 */         } else if (method.isOverriding()) {
/* 227 */           shouldReport &= (currentScope.compilerOptions()).reportUnusedParameterWhenOverridingConcrete;
/*     */         } 
/*     */         
/* 230 */         if (shouldReport)
/*     */         {
/* 232 */           currentScope.problemReporter().unusedArgument(localBinding.declaration);
/*     */         }
/*     */       } 
/*     */     } else {
/*     */       
/* 237 */       currentScope.problemReporter().unusedLocalVariable(localBinding.declaration);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\ast\Reference.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */