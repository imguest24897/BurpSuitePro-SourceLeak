/*     */ package org.eclipse.jdt.internal.compiler.env;
/*     */ 
/*     */ import java.util.function.Predicate;
/*     */ import org.eclipse.jdt.core.compiler.CharOperation;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.ModuleBinding;
/*     */ import org.eclipse.jdt.internal.compiler.util.SimpleSetOfCharArray;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public interface IModuleAwareNameEnvironment
/*     */   extends INameEnvironment
/*     */ {
/*     */   public enum LookupStrategy
/*     */   {
/*  29 */     Named
/*     */     {
/*     */       public <T> boolean matchesWithName(T elem, Predicate<T> isNamed, Predicate<T> nameMatcher)
/*     */       {
/*  33 */         if (!LookupStrategy.$assertionsDisabled && nameMatcher == null) throw new AssertionError("name match needs a nameMatcher"); 
/*  34 */         return (isNamed.test(elem) && nameMatcher.test(elem));
/*     */       }
/*     */     },
/*  37 */     AnyNamed
/*     */     {
/*     */       public <T> boolean matchesWithName(T elem, Predicate<T> isNamed, Predicate<T> nameMatcher)
/*     */       {
/*  41 */         return isNamed.test(elem);
/*     */       }
/*     */     },
/*  44 */     Any
/*     */     {
/*     */       public <T> boolean matchesWithName(T elem, Predicate<T> isNamed, Predicate<T> nameMatcher)
/*     */       {
/*  48 */         return true;
/*     */       }
/*     */     },
/*  51 */     Unnamed
/*     */     {
/*     */       public <T> boolean matchesWithName(T elem, Predicate<T> isNamed, Predicate<T> nameMatcher)
/*     */       {
/*  55 */         return !isNamed.test(elem);
/*     */       }
/*     */     };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public <T> boolean matches(T elem, Predicate<T> isNamed) {
/*  73 */       return matchesWithName(elem, isNamed, t -> true);
/*     */     }
/*     */ 
/*     */     
/*     */     public static LookupStrategy get(char[] moduleName) {
/*  78 */       if (moduleName == ModuleBinding.ANY)
/*  79 */         return Any; 
/*  80 */       if (moduleName == ModuleBinding.ANY_NAMED)
/*  81 */         return AnyNamed; 
/*  82 */       if (moduleName == ModuleBinding.UNNAMED)
/*  83 */         return Unnamed; 
/*  84 */       return Named;
/*     */     }
/*     */     
/*     */     public static String getStringName(char[] moduleName) {
/*  88 */       switch (get(moduleName)) { case Named:
/*  89 */           return String.valueOf(moduleName); }
/*  90 */        return null;
/*     */     }
/*     */     
/*     */     public abstract <T> boolean matchesWithName(T param1T, Predicate<T> param1Predicate1, Predicate<T> param1Predicate2);
/*     */   }
/*     */   
/*     */   default NameEnvironmentAnswer findType(char[][] compoundTypeName) {
/*  97 */     return findType(compoundTypeName, ModuleBinding.ANY);
/*     */   }
/*     */   
/*     */   default NameEnvironmentAnswer findType(char[] typeName, char[][] packageName) {
/* 101 */     return findType(typeName, packageName, ModuleBinding.ANY);
/*     */   }
/*     */   
/*     */   default boolean isPackage(char[][] parentPackageName, char[] packageName) {
/* 105 */     return (getModulesDeclaringPackage(CharOperation.arrayConcat(parentPackageName, packageName), ModuleBinding.ANY) != null);
/*     */   }
/*     */   NameEnvironmentAnswer findType(char[][] paramArrayOfchar, char[] paramArrayOfchar1);
/*     */   NameEnvironmentAnswer findType(char[] paramArrayOfchar1, char[][] paramArrayOfchar, char[] paramArrayOfchar2);
/*     */   
/*     */   char[][] getModulesDeclaringPackage(char[][] paramArrayOfchar, char[] paramArrayOfchar1);
/*     */   
/*     */   default char[][] getUniqueModulesDeclaringPackage(char[][] packageName, char[] moduleName) {
/* 113 */     char[][] allNames = getModulesDeclaringPackage(packageName, moduleName);
/* 114 */     if (allNames != null && allNames.length > 1) {
/* 115 */       SimpleSetOfCharArray set = new SimpleSetOfCharArray(allNames.length); byte b; int i; char[][] arrayOfChar;
/* 116 */       for (i = (arrayOfChar = allNames).length, b = 0; b < i; ) { char[] oneName = arrayOfChar[b];
/* 117 */         set.add(oneName); b++; }
/* 118 */        allNames = new char[set.elementSize][];
/* 119 */       set.asArray((Object[])allNames);
/*     */     } 
/* 121 */     return allNames;
/*     */   }
/*     */   
/*     */   boolean hasCompilationUnit(char[][] paramArrayOfchar, char[] paramArrayOfchar1, boolean paramBoolean);
/*     */   
/*     */   IModule getModule(char[] paramArrayOfchar);
/*     */   
/*     */   char[][] getAllAutomaticModules();
/*     */   
/*     */   default void applyModuleUpdates(IUpdatableModule module, IUpdatableModule.UpdateKind kind) {}
/*     */   
/*     */   char[][] listPackages(char[] paramArrayOfchar);
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\env\IModuleAwareNameEnvironment.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */