/*     */ package org.eclipse.jdt.internal.compiler.ast;
/*     */ 
/*     */ import org.eclipse.jdt.core.compiler.CharOperation;
/*     */ import org.eclipse.jdt.internal.compiler.ASTVisitor;
/*     */ import org.eclipse.jdt.internal.compiler.impl.Constant;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.Binding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.BlockScope;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.ClassScope;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.ModuleBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.PackageBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.Scope;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.TypeBinding;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JavadocQualifiedTypeReference
/*     */   extends QualifiedTypeReference
/*     */   implements IJavadocTypeReference
/*     */ {
/*     */   public int tagSourceStart;
/*     */   public int tagSourceEnd;
/*     */   public PackageBinding packageBinding;
/*     */   public ModuleBinding moduleBinding;
/*     */   private boolean canBeModule;
/*     */   
/*     */   public JavadocQualifiedTypeReference(char[][] sources, long[] pos, int tagStart, int tagEnd) {
/*  38 */     this(sources, pos, tagStart, tagEnd, false);
/*     */   }
/*     */   
/*     */   public JavadocQualifiedTypeReference(char[][] sources, long[] pos, int tagStart, int tagEnd, boolean canBeModule) {
/*  42 */     super(sources, pos);
/*  43 */     this.tagSourceStart = tagStart;
/*  44 */     this.tagSourceEnd = tagEnd;
/*  45 */     this.bits |= 0x8000;
/*  46 */     this.canBeModule = canBeModule;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private TypeBinding internalResolveType(Scope scope, boolean checkBounds) {
/*  54 */     this.constant = Constant.NotAConstant;
/*  55 */     if (this.resolvedType != null) {
/*  56 */       return this.resolvedType.isValidBinding() ? this.resolvedType : this.resolvedType.closestMatch();
/*     */     }
/*  58 */     TypeBinding type = this.resolvedType = getTypeBinding(scope);
/*     */ 
/*     */ 
/*     */     
/*  62 */     if (type == null) return null; 
/*  63 */     if (!type.isValidBinding()) {
/*  64 */       Binding binding = scope.getTypeOrPackage(this.tokens);
/*  65 */       if (binding instanceof PackageBinding) {
/*  66 */         this.packageBinding = (PackageBinding)binding;
/*     */       } else {
/*     */         ModuleBinding moduleBinding;
/*  69 */         Binding modBinding = null;
/*  70 */         if (this.canBeModule) {
/*  71 */           char[] moduleName = CharOperation.concatWith(this.tokens, '.');
/*  72 */           moduleBinding = scope.environment().getModule(moduleName);
/*     */         } 
/*  74 */         if (moduleBinding instanceof ModuleBinding && 
/*  75 */           !moduleBinding.isUnnamed() && 
/*  76 */           moduleBinding.isValidBinding()) {
/*  77 */           this.moduleBinding = moduleBinding;
/*     */         } else {
/*  79 */           reportInvalidType(scope);
/*     */         } 
/*     */       } 
/*  82 */       return null;
/*     */     } 
/*     */ 
/*     */     
/*  86 */     if (type.isGenericType() || type.isParameterizedType()) {
/*  87 */       this.resolvedType = scope.environment().convertToRawType(type, true);
/*     */     }
/*  89 */     return this.resolvedType;
/*     */   }
/*     */   
/*     */   protected void reportDeprecatedType(TypeBinding type, Scope scope) {
/*  93 */     scope.problemReporter().javadocDeprecatedType(type, this, scope.getDeclarationModifiers());
/*     */   }
/*     */ 
/*     */   
/*     */   protected void reportDeprecatedType(TypeBinding type, Scope scope, int index) {
/*  98 */     scope.problemReporter().javadocDeprecatedType(type, this, scope.getDeclarationModifiers(), index);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void reportInvalidType(Scope scope) {
/* 103 */     scope.problemReporter().javadocInvalidType(this, this.resolvedType, scope.getDeclarationModifiers());
/*     */   }
/*     */   
/*     */   public TypeBinding resolveType(BlockScope blockScope, boolean checkBounds, int location) {
/* 107 */     return internalResolveType((Scope)blockScope, checkBounds);
/*     */   }
/*     */ 
/*     */   
/*     */   public TypeBinding resolveType(ClassScope classScope, int location) {
/* 112 */     return internalResolveType((Scope)classScope, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void traverse(ASTVisitor visitor, BlockScope scope) {
/* 121 */     visitor.visit(this, scope);
/* 122 */     visitor.endVisit(this, scope);
/*     */   }
/*     */ 
/*     */   
/*     */   public void traverse(ASTVisitor visitor, ClassScope scope) {
/* 127 */     visitor.visit(this, scope);
/* 128 */     visitor.endVisit(this, scope);
/*     */   }
/*     */ 
/*     */   
/*     */   public int getTagSourceStart() {
/* 133 */     return this.tagSourceStart;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getTagSourceEnd() {
/* 138 */     return this.tagSourceEnd;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\ast\JavadocQualifiedTypeReference.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */