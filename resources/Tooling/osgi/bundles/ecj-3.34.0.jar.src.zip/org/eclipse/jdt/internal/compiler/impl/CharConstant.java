/*    */ package org.eclipse.jdt.internal.compiler.impl;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CharConstant
/*    */   extends Constant
/*    */ {
/*    */   private char value;
/*    */   
/*    */   public static Constant fromValue(char value) {
/* 21 */     return new CharConstant(value);
/*    */   }
/*    */   
/*    */   private CharConstant(char value) {
/* 25 */     this.value = value;
/*    */   }
/*    */ 
/*    */   
/*    */   public byte byteValue() {
/* 30 */     return (byte)this.value;
/*    */   }
/*    */ 
/*    */   
/*    */   public char charValue() {
/* 35 */     return this.value;
/*    */   }
/*    */ 
/*    */   
/*    */   public double doubleValue() {
/* 40 */     return this.value;
/*    */   }
/*    */ 
/*    */   
/*    */   public float floatValue() {
/* 45 */     return this.value;
/*    */   }
/*    */ 
/*    */   
/*    */   public int intValue() {
/* 50 */     return this.value;
/*    */   }
/*    */ 
/*    */   
/*    */   public long longValue() {
/* 55 */     return this.value;
/*    */   }
/*    */ 
/*    */   
/*    */   public short shortValue() {
/* 60 */     return (short)this.value;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public String stringValue() {
/* 66 */     return String.valueOf(this.value);
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 71 */     return "(char)" + this.value;
/*    */   }
/*    */ 
/*    */   
/*    */   public int typeID() {
/* 76 */     return 2;
/*    */   }
/*    */ 
/*    */   
/*    */   public int hashCode() {
/* 81 */     return this.value;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean equals(Object obj) {
/* 86 */     if (this == obj) {
/* 87 */       return true;
/*    */     }
/* 89 */     if (obj == null) {
/* 90 */       return false;
/*    */     }
/* 92 */     if (getClass() != obj.getClass()) {
/* 93 */       return false;
/*    */     }
/* 95 */     CharConstant other = (CharConstant)obj;
/* 96 */     return (this.value == other.value);
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\impl\CharConstant.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */