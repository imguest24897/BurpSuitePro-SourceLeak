/*    */ package org.eclipse.jdt.internal.compiler.classfmt;
/*    */ 
/*    */ import java.util.Arrays;
/*    */ import org.eclipse.jdt.core.compiler.CharOperation;
/*    */ import org.eclipse.jdt.internal.compiler.env.IBinaryElementValuePair;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ElementValuePairInfo
/*    */   implements IBinaryElementValuePair
/*    */ {
/* 23 */   static final ElementValuePairInfo[] NoMembers = new ElementValuePairInfo[0];
/*    */   
/*    */   private char[] name;
/*    */   private Object value;
/*    */   
/*    */   public ElementValuePairInfo(char[] name, Object value) {
/* 29 */     this.name = name;
/* 30 */     this.value = value;
/*    */   }
/*    */   
/*    */   public char[] getName() {
/* 34 */     return this.name;
/*    */   }
/*    */   
/*    */   public Object getValue() {
/* 38 */     return this.value;
/*    */   }
/*    */   
/*    */   public String toString() {
/* 42 */     StringBuilder buffer = new StringBuilder();
/* 43 */     buffer.append(this.name);
/* 44 */     buffer.append('=');
/* 45 */     if (this.value instanceof Object[]) {
/* 46 */       Object[] values = (Object[])this.value;
/* 47 */       buffer.append('{');
/* 48 */       for (int i = 0, l = values.length; i < l; i++) {
/* 49 */         if (i > 0)
/* 50 */           buffer.append(", "); 
/* 51 */         buffer.append(values[i]);
/*    */       } 
/* 53 */       buffer.append('}');
/*    */     } else {
/* 55 */       buffer.append(this.value);
/*    */     } 
/* 57 */     return buffer.toString();
/*    */   }
/*    */ 
/*    */   
/*    */   public int hashCode() {
/* 62 */     int result = 1;
/* 63 */     result = 31 * result + CharOperation.hashCode(this.name);
/* 64 */     result = 31 * result + ((this.value == null) ? 0 : this.value.hashCode());
/* 65 */     return result;
/*    */   }
/*    */   
/*    */   public boolean equals(Object obj) {
/* 69 */     if (this == obj) {
/* 70 */       return true;
/*    */     }
/* 72 */     if (obj == null) {
/* 73 */       return false;
/*    */     }
/* 75 */     if (getClass() != obj.getClass()) {
/* 76 */       return false;
/*    */     }
/* 78 */     ElementValuePairInfo other = (ElementValuePairInfo)obj;
/* 79 */     if (!Arrays.equals(this.name, other.name)) {
/* 80 */       return false;
/*    */     }
/* 82 */     if (this.value == null) {
/* 83 */       if (other.value != null) {
/* 84 */         return false;
/*    */       }
/* 86 */     } else if (!this.value.equals(other.value)) {
/* 87 */       return false;
/*    */     } 
/* 89 */     return true;
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\classfmt\ElementValuePairInfo.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */