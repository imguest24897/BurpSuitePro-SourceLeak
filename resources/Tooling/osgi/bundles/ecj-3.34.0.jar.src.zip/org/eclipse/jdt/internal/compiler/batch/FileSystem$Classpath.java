/*     */ package org.eclipse.jdt.internal.compiler.batch;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.Collection;
/*     */ import java.util.List;
/*     */ import java.util.function.Function;
/*     */ import org.eclipse.jdt.internal.compiler.env.IModule;
/*     */ import org.eclipse.jdt.internal.compiler.env.IModulePathEntry;
/*     */ import org.eclipse.jdt.internal.compiler.env.NameEnvironmentAnswer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public interface Classpath
/*     */   extends IModulePathEntry
/*     */ {
/*     */   char[][][] findTypeNames(String paramString1, String paramString2);
/*     */   
/*     */   NameEnvironmentAnswer findClass(char[] paramArrayOfchar, String paramString1, String paramString2, String paramString3);
/*     */   
/*     */   NameEnvironmentAnswer findClass(char[] paramArrayOfchar, String paramString1, String paramString2, String paramString3, boolean paramBoolean);
/*     */   
/*     */   boolean isPackage(String paramString1, String paramString2);
/*     */   
/*     */   default boolean hasModule() {
/*  76 */     return (getModule() != null);
/*     */   } default boolean hasCUDeclaringPackage(String qualifiedPackageName, Function<CompilationUnit, String> pkgNameExtractor) {
/*  78 */     return hasCompilationUnit(qualifiedPackageName, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   List<Classpath> fetchLinkedJars(FileSystem.ClasspathSectionProblemReporter paramClasspathSectionProblemReporter);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void reset();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   char[] normalizedPath();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   String getPath();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void initialize() throws IOException;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean hasAnnotationFileFor(String paramString);
/*     */ 
/*     */ 
/*     */   
/*     */   void acceptModule(IModule paramIModule);
/*     */ 
/*     */ 
/*     */   
/*     */   String getDestinationPath();
/*     */ 
/*     */ 
/*     */   
/*     */   Collection<String> getModuleNames(Collection<String> paramCollection);
/*     */ 
/*     */ 
/*     */   
/*     */   Collection<String> getModuleNames(Collection<String> paramCollection, Function<String, IModule> paramFunction);
/*     */ 
/*     */ 
/*     */   
/*     */   default boolean forbidsExportFrom(String modName) {
/* 130 */     return false;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\batch\FileSystem$Classpath.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */