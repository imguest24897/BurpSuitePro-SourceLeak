/*    */ package org.eclipse.jdt.internal.compiler.ast;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class MagicLiteral
/*    */   extends Literal
/*    */ {
/*    */   public MagicLiteral(int start, int end) {
/* 20 */     super(start, end);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean isValidJavaStatement() {
/* 26 */     return false;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public char[] source() {
/* 32 */     return null;
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\ast\MagicLiteral.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */