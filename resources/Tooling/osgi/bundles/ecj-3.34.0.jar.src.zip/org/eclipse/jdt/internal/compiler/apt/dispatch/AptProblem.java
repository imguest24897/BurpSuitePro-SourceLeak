/*    */ package org.eclipse.jdt.internal.compiler.apt.dispatch;
/*    */ 
/*    */ import org.eclipse.jdt.internal.compiler.impl.ReferenceContext;
/*    */ import org.eclipse.jdt.internal.compiler.problem.DefaultProblem;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AptProblem
/*    */   extends DefaultProblem
/*    */ {
/*    */   private static final String MARKER_ID = "org.eclipse.jdt.apt.pluggable.core.compileProblem";
/*    */   public final ReferenceContext _referenceContext;
/*    */   
/*    */   public AptProblem(ReferenceContext referenceContext, char[] originatingFileName, String message, int id, String[] stringArguments, int severity, int startPosition, int endPosition, int line, int column) {
/* 50 */     super(originatingFileName, message, id, stringArguments, severity, startPosition, endPosition, line, column);
/* 51 */     this._referenceContext = referenceContext;
/*    */   }
/*    */ 
/*    */   
/*    */   public int getCategoryID() {
/* 56 */     return 0;
/*    */   }
/*    */ 
/*    */   
/*    */   public String getMarkerType() {
/* 61 */     return "org.eclipse.jdt.apt.pluggable.core.compileProblem";
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\apt\dispatch\AptProblem.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */