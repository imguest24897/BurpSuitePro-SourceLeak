/*     */ package org.eclipse.jdt.internal.compiler.ast;
/*     */ 
/*     */ import org.eclipse.jdt.core.compiler.CharOperation;
/*     */ import org.eclipse.jdt.internal.compiler.ASTVisitor;
/*     */ import org.eclipse.jdt.internal.compiler.impl.Constant;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.Binding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.BlockScope;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.ClassScope;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.FieldBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.MethodBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.ProblemFieldBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.ProblemMethodBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.ReferenceBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.Scope;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.TypeBinding;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JavadocFieldReference
/*     */   extends FieldReference
/*     */ {
/*     */   public int tagSourceStart;
/*     */   public int tagSourceEnd;
/*     */   public int tagValue;
/*     */   public MethodBinding methodBinding;
/*     */   
/*     */   public JavadocFieldReference(char[] source, long pos) {
/*  29 */     super(source, pos);
/*  30 */     this.bits |= 0x8000;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected TypeBinding internalResolveType(Scope scope) {
/*     */     FieldBinding fieldBinding1;
/*     */     ProblemFieldBinding problemFieldBinding;
/*  47 */     this.constant = Constant.NotAConstant;
/*  48 */     if (this.receiver == null) {
/*  49 */       this.actualReceiverType = (TypeBinding)scope.enclosingReceiverType();
/*  50 */     } else if (scope.kind == 3) {
/*  51 */       this.actualReceiverType = this.receiver.resolveType((ClassScope)scope);
/*     */     } else {
/*  53 */       this.actualReceiverType = this.receiver.resolveType((BlockScope)scope);
/*     */     } 
/*  55 */     if (this.actualReceiverType == null) {
/*  56 */       return null;
/*     */     }
/*     */     
/*  59 */     Binding fieldBinding = (this.receiver != null && this.receiver.isThis()) ? 
/*  60 */       scope.classScope().getBinding(this.token, this.bits & 0x7, this, true) : 
/*  61 */       (Binding)scope.getField(this.actualReceiverType, this.token, this);
/*  62 */     if (!fieldBinding.isValidBinding()) {
/*     */       FieldBinding closestMatch;
/*  64 */       switch (fieldBinding.problemId()) {
/*     */         case 5:
/*     */         case 6:
/*     */         case 7:
/*  68 */           closestMatch = ((ProblemFieldBinding)fieldBinding).closestMatch;
/*  69 */           if (closestMatch != null) {
/*  70 */             fieldBinding1 = closestMatch;
/*     */           }
/*     */           break;
/*     */       } 
/*     */     } 
/*  75 */     if (!fieldBinding1.isValidBinding() || !(fieldBinding1 instanceof FieldBinding)) {
/*  76 */       if (this.receiver.resolvedType instanceof org.eclipse.jdt.internal.compiler.lookup.ProblemReferenceBinding)
/*     */       {
/*  78 */         return null;
/*     */       }
/*  80 */       if (this.actualReceiverType instanceof ReferenceBinding) {
/*  81 */         ReferenceBinding refBinding = (ReferenceBinding)this.actualReceiverType;
/*  82 */         char[] selector = this.token;
/*  83 */         MethodBinding possibleMethod = null;
/*  84 */         if (CharOperation.equals(this.actualReceiverType.sourceName(), selector)) {
/*  85 */           possibleMethod = scope.getConstructor(refBinding, Binding.NO_TYPES, this);
/*     */         } else {
/*  87 */           possibleMethod = this.receiver.isThis() ? 
/*  88 */             scope.getImplicitMethod(selector, Binding.NO_TYPES, this) : 
/*  89 */             scope.getMethod((TypeBinding)refBinding, selector, Binding.NO_TYPES, this);
/*     */         } 
/*  91 */         if (possibleMethod.isValidBinding()) {
/*  92 */           this.methodBinding = possibleMethod;
/*     */         } else {
/*  94 */           ProblemMethodBinding problemMethodBinding = (ProblemMethodBinding)possibleMethod;
/*  95 */           if (problemMethodBinding.closestMatch == null) {
/*  96 */             if (fieldBinding1.isValidBinding())
/*     */             {
/*     */               
/*  99 */               problemFieldBinding = new ProblemFieldBinding(refBinding, fieldBinding1.readableName(), 1);
/*     */             }
/* 101 */             scope.problemReporter().javadocInvalidField(this, (Binding)problemFieldBinding, this.actualReceiverType, scope.getDeclarationModifiers());
/*     */           } else {
/* 103 */             this.methodBinding = problemMethodBinding.closestMatch;
/*     */           } 
/*     */         } 
/*     */       } 
/* 107 */       return null;
/*     */     } 
/* 109 */     this.binding = (FieldBinding)problemFieldBinding;
/*     */     
/* 111 */     if (isFieldUseDeprecated(this.binding, scope, this.bits)) {
/* 112 */       scope.problemReporter().javadocDeprecatedField(this.binding, this, scope.getDeclarationModifiers());
/*     */     }
/* 114 */     return this.resolvedType = this.binding.type;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isSuperAccess() {
/* 119 */     return ((this.bits & 0x4000) != 0);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public StringBuffer printExpression(int indent, StringBuffer output) {
/* 125 */     if (this.receiver != null) {
/* 126 */       this.receiver.printExpression(0, output);
/*     */     }
/* 128 */     output.append('#').append(this.token);
/* 129 */     return output;
/*     */   }
/*     */ 
/*     */   
/*     */   public TypeBinding resolveType(BlockScope scope) {
/* 134 */     return internalResolveType((Scope)scope);
/*     */   }
/*     */ 
/*     */   
/*     */   public TypeBinding resolveType(ClassScope scope) {
/* 139 */     return internalResolveType((Scope)scope);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void traverse(ASTVisitor visitor, BlockScope scope) {
/* 149 */     if (visitor.visit(this, scope) && 
/* 150 */       this.receiver != null) {
/* 151 */       this.receiver.traverse(visitor, scope);
/*     */     }
/*     */     
/* 154 */     visitor.endVisit(this, scope);
/*     */   }
/*     */ 
/*     */   
/*     */   public void traverse(ASTVisitor visitor, ClassScope scope) {
/* 159 */     if (visitor.visit(this, scope) && 
/* 160 */       this.receiver != null) {
/* 161 */       this.receiver.traverse(visitor, scope);
/*     */     }
/*     */     
/* 164 */     visitor.endVisit(this, scope);
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\ast\JavadocFieldReference.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */