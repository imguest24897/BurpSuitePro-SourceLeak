/*     */ package org.eclipse.jdt.internal.compiler.ast;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ enum Severity
/*     */ {
/*  98 */   OK,
/*     */   
/* 100 */   LEGACY_WARNING,
/*     */   
/* 102 */   UNCHECKED,
/*     */   
/* 104 */   UNCHECKED_TO_UNANNOTATED,
/*     */   
/* 106 */   MISMATCH;
/*     */ 
/*     */   
/*     */   public Severity max(Severity severity) {
/* 110 */     if (compareTo(severity) < 0)
/* 111 */       return severity; 
/* 112 */     return this;
/*     */   }
/*     */   
/*     */   public boolean isAnyMismatch() {
/* 116 */     return (compareTo(LEGACY_WARNING) > 0);
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\ast\NullAnnotationMatching$Severity.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */