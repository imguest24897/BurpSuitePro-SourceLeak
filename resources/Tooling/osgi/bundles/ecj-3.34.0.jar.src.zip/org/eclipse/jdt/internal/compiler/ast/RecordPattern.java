/*     */ package org.eclipse.jdt.internal.compiler.ast;
/*     */ 
/*     */ import org.eclipse.jdt.internal.compiler.ASTVisitor;
/*     */ import org.eclipse.jdt.internal.compiler.codegen.BranchLabel;
/*     */ import org.eclipse.jdt.internal.compiler.codegen.CodeStream;
/*     */ import org.eclipse.jdt.internal.compiler.flow.FlowContext;
/*     */ import org.eclipse.jdt.internal.compiler.flow.FlowInfo;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.BlockScope;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.InferenceContext18;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.LocalVariableBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.MethodBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.RecordComponentBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.ReferenceBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.Scope;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.TypeBinding;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RecordPattern
/*     */   extends TypePattern
/*     */ {
/*     */   public Pattern[] patterns;
/*     */   public TypeReference type;
/*  35 */   int thenInitStateIndex1 = -1;
/*  36 */   int thenInitStateIndex2 = -1;
/*     */   
/*     */   public RecordPattern(LocalDeclaration local) {
/*  39 */     super(local);
/*  40 */     this.type = local.type;
/*  41 */     this.sourceStart = local.sourceStart;
/*  42 */     this.sourceEnd = local.sourceEnd;
/*     */   }
/*     */   
/*     */   public RecordPattern(TypeReference type, int sourceStart, int sourceEnd) {
/*  46 */     this.type = type;
/*  47 */     this.sourceStart = sourceStart;
/*  48 */     this.sourceEnd = sourceEnd;
/*     */   }
/*     */   
/*     */   public TypeReference getType() {
/*  52 */     return this.type;
/*     */   }
/*     */   
/*     */   public void collectPatternVariablesToScope(LocalVariableBinding[] variables, BlockScope scope) {
/*  56 */     if (this.resolvedType == null) {
/*  57 */       resolveType(scope);
/*     */     }
/*  59 */     addPatternVariablesWhenTrue(variables);
/*  60 */     super.collectPatternVariablesToScope(variables, scope); byte b; int i; Pattern[] arrayOfPattern;
/*  61 */     for (i = (arrayOfPattern = this.patterns).length, b = 0; b < i; ) { Pattern p = arrayOfPattern[b];
/*  62 */       p.collectPatternVariablesToScope(this.patternVarsWhenTrue, scope);
/*  63 */       addPatternVariablesWhenTrue(p.patternVarsWhenTrue);
/*     */       b++; }
/*     */   
/*     */   }
/*     */   public boolean checkUnsafeCast(Scope scope, TypeBinding castType, TypeBinding expressionType, TypeBinding match, boolean isNarrowing) {
/*  68 */     if (!castType.isReifiable()) {
/*  69 */       return CastExpression.checkUnsafeCast(this, scope, castType, expressionType, match, isNarrowing);
/*     */     }
/*  71 */     return super.checkUnsafeCast(scope, castType, expressionType, match, isNarrowing);
/*     */   }
/*     */   
/*     */   public LocalDeclaration getPatternVariable() {
/*  75 */     return super.getPatternVariable();
/*     */   }
/*     */   
/*     */   public FlowInfo analyseCode(BlockScope currentScope, FlowContext flowContext, FlowInfo flowInfo) {
/*  79 */     this.thenInitStateIndex1 = currentScope.methodScope().recordInitializationStates(flowInfo);
/*  80 */     flowInfo = super.analyseCode(currentScope, flowContext, flowInfo); byte b; int i; Pattern[] arrayOfPattern;
/*  81 */     for (i = (arrayOfPattern = this.patterns).length, b = 0; b < i; ) { Pattern p = arrayOfPattern[b];
/*  82 */       flowInfo = p.analyseCode(currentScope, flowContext, flowInfo); b++; }
/*     */     
/*  84 */     flowInfo = flowInfo.safeInitsWhenTrue();
/*  85 */     this.thenInitStateIndex2 = currentScope.methodScope().recordInitializationStates(flowInfo);
/*  86 */     return flowInfo;
/*     */   }
/*     */   
/*     */   public boolean isTotalForType(TypeBinding t) {
/*  90 */     return false;
/*     */   }
/*     */   
/*     */   public void resolveWithExpression(BlockScope scope, Expression exp) {
/*  94 */     this.expression = exp;
/*  95 */     if (shouldInitiateRecordTypeInference()) {
/*  96 */       LocalVariableBinding localVariableBinding = exp.localVariableBinding();
/*  97 */       TypeBinding type1 = (localVariableBinding != null && localVariableBinding.type != null) ? 
/*  98 */         localVariableBinding.type : exp.resolvedType;
/*  99 */       if (type1 instanceof ReferenceBinding) {
/* 100 */         ReferenceBinding binding = inferRecordParameterization(scope, (ReferenceBinding)type1);
/* 101 */         if (binding == null || !binding.isValidBinding()) {
/* 102 */           scope.problemReporter().cannotInferRecordPatternTypes(this);
/* 103 */           this.resolvedType = null;
/*     */           return;
/*     */         } 
/* 106 */         this.resolvedType = (TypeBinding)binding;
/* 107 */         setAccessorsPlusInfuseInferredType(scope);
/*     */       } 
/*     */     } 
/*     */   }
/*     */   public TypeBinding resolveAtType(BlockScope scope, TypeBinding u) {
/*     */     byte b;
/*     */     int i;
/*     */     Pattern[] arrayOfPattern;
/* 115 */     for (i = (arrayOfPattern = this.patterns).length, b = 0; b < i; ) { Pattern p = arrayOfPattern[b];
/* 116 */       p.resolveAtType(scope, u); b++; }
/*     */     
/* 118 */     if (this.local != null) {
/* 119 */       this.resolvedType = super.resolveAtType(scope, u);
/*     */     }
/* 121 */     return this.resolvedType;
/*     */   }
/*     */   
/*     */   public TypeBinding resolveType(BlockScope scope, boolean isPatternVariable) {
/* 125 */     if (this.resolvedType != null)
/* 126 */       return this.resolvedType; 
/* 127 */     super.resolveType(scope, isPatternVariable);
/*     */     
/* 129 */     if (this.local != null) {
/* 130 */       this.resolvedType = resolveType(scope);
/*     */     } else {
/* 132 */       this.type.bits |= 0x40000000;
/* 133 */       this.resolvedType = this.type.resolveType(scope);
/*     */     } 
/* 135 */     if (this.resolvedType == null)
/*     */     {
/*     */       
/* 138 */       return null;
/*     */     }
/* 140 */     if (!this.resolvedType.isValidBinding()) {
/* 141 */       return this.resolvedType;
/*     */     }
/* 143 */     initSecretPatternVariable(scope);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 148 */     if (!this.resolvedType.isRecord()) {
/* 149 */       scope.problemReporter().unexpectedTypeinRecordPattern(this.resolvedType, this.type);
/* 150 */       return this.resolvedType;
/*     */     } 
/* 152 */     setAccessorsPlusInfuseInferredType(scope);
/* 153 */     return this.resolvedType;
/*     */   }
/*     */   private void setAccessorsPlusInfuseInferredType(BlockScope scope) {
/* 156 */     this.isTotalTypeNode = isTotalForType(this.resolvedType);
/* 157 */     RecordComponentBinding[] components = this.resolvedType.components();
/* 158 */     if (components.length != this.patterns.length) {
/* 159 */       scope.problemReporter().recordPatternSignatureMismatch(this.resolvedType, this);
/*     */     } else {
/* 161 */       for (int i = 0; i < components.length; i++) {
/* 162 */         Pattern p = this.patterns[i];
/* 163 */         if (p instanceof TypePattern) {
/*     */           
/* 165 */           TypePattern tp = (TypePattern)p;
/* 166 */           RecordComponentBinding componentBinding = components[i];
/* 167 */           if (p.getType().isTypeNameVar((Scope)scope)) {
/* 168 */             infuseInferredType(tp, componentBinding);
/* 169 */             if (tp.local.binding != null)
/* 170 */               tp.local.binding.type = componentBinding.type; 
/*     */           } 
/* 172 */           p.resolveType(scope, true);
/* 173 */           TypeBinding expressionType = componentBinding.type;
/* 174 */           if (p.isPatternTypeCompatible(expressionType, scope)) {
/* 175 */             p.isTotalTypeNode = p.isTotalForType(componentBinding.type);
/* 176 */             MethodBinding[] methods = this.resolvedType.getMethods(componentBinding.name);
/* 177 */             if (methods != null && methods.length > 0)
/* 178 */               p.accessorMethod = methods[0]; 
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */   private ReferenceBinding inferRecordParameterization(BlockScope scope, ReferenceBinding proposedMatchingType) {
/* 185 */     InferenceContext18 freshInferenceContext = new InferenceContext18((Scope)scope);
/*     */     try {
/* 187 */       return freshInferenceContext.inferRecordPatternParameterization(this, scope, (TypeBinding)proposedMatchingType);
/*     */     } finally {
/* 189 */       freshInferenceContext.cleanUp();
/*     */     } 
/*     */   }
/*     */   private boolean shouldInitiateRecordTypeInference() {
/* 193 */     ReferenceBinding binding = (this.resolvedType != null) ? this.resolvedType.actualType() : null;
/* 194 */     if (binding == null || !binding.isGenericType()) {
/* 195 */       return false;
/*     */     }
/* 197 */     if (this.resolvedType.isParameterizedType())
/* 198 */       return false; 
/* 199 */     if (this.containsTypeElidedPatternVar == null) {
/* 200 */       containsPatternVariable();
/*     */     }
/* 202 */     return this.containsTypeElidedPatternVar.booleanValue();
/*     */   }
/*     */   private void infuseInferredType(TypePattern tp, final RecordComponentBinding componentBinding) {
/* 205 */     SingleTypeReference ref = new SingleTypeReference(tp.local.type.getTypeName()[0], 
/* 206 */         tp.local.type.sourceStart, 
/* 207 */         tp.local.type.sourceEnd)
/*     */       {
/*     */         public TypeBinding resolveType(BlockScope scope, boolean checkBounds) {
/* 210 */           return componentBinding.type;
/*     */         }
/*     */       };
/* 213 */     tp.local.type = ref;
/*     */   }
/*     */   
/*     */   public boolean isAlwaysTrue() {
/* 217 */     return false;
/*     */   }
/*     */   
/*     */   public boolean dominates(Pattern p) {
/* 221 */     if (!this.resolvedType.isValidBinding())
/* 222 */       return false; 
/* 223 */     if (!super.isTotalForType(p.resolvedType)) {
/* 224 */       return false;
/*     */     }
/* 226 */     if (p instanceof RecordPattern) {
/* 227 */       RecordPattern rp = (RecordPattern)p;
/* 228 */       if (this.patterns.length != rp.patterns.length)
/* 229 */         return false; 
/* 230 */       for (int i = 0; i < this.patterns.length; i++) {
/* 231 */         if (!this.patterns[i].dominates(rp.patterns[i])) {
/* 232 */           return false;
/*     */         }
/*     */       } 
/*     */     } 
/* 236 */     return true;
/*     */   }
/*     */   
/*     */   public void generateOptimizedBoolean(BlockScope currentScope, CodeStream codeStream, BranchLabel trueLabel, BranchLabel falseLabel) {
/* 240 */     codeStream.checkcast(this.resolvedType);
/* 241 */     initializePatternVariables(currentScope, codeStream);
/* 242 */     generatePatternVariable(currentScope, codeStream, trueLabel, falseLabel);
/* 243 */     wrapupGeneration(codeStream);
/* 244 */     if (this.thenInitStateIndex2 != -1) {
/* 245 */       codeStream.removeNotDefinitelyAssignedVariables((Scope)currentScope, this.thenInitStateIndex2);
/* 246 */       codeStream.addDefinitelyAssignedVariables((Scope)currentScope, this.thenInitStateIndex2);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void generatePatternVariable(BlockScope currentScope, CodeStream codeStream, BranchLabel trueLabel, BranchLabel falseLabel) {
/*     */     byte b;
/*     */     int i;
/*     */     Pattern[] arrayOfPattern;
/* 257 */     for (i = (arrayOfPattern = this.patterns).length, b = 0; b < i; ) { Pattern p = arrayOfPattern[b];
/* 258 */       if (p.accessorMethod != null) {
/* 259 */         codeStream.load(this.secretPatternVariable);
/* 260 */         if (!this.isTotalTypeNode)
/* 261 */           codeStream.checkcast(this.resolvedType); 
/* 262 */         generateArguments(p.accessorMethod, (Expression[])null, currentScope, codeStream);
/* 263 */         codeStream.invoke((byte)-74, p.accessorMethod.original(), this.resolvedType, null);
/* 264 */         if (!p.accessorMethod.original().equals(p.accessorMethod))
/* 265 */           codeStream.checkcast(p.accessorMethod.returnType); 
/* 266 */         if (!p.isTotalTypeNode && 
/* 267 */           p instanceof TypePattern) {
/* 268 */           ((TypePattern)p).initializePatternVariables(currentScope, codeStream);
/* 269 */           codeStream.load(p.secretPatternVariable);
/* 270 */           codeStream.instance_of(p.resolvedType);
/* 271 */           BranchLabel target = (falseLabel != null) ? falseLabel : new BranchLabel(codeStream);
/* 272 */           codeStream.ifeq(target);
/* 273 */           codeStream.load(p.secretPatternVariable);
/*     */         } 
/*     */         
/* 276 */         p.generateOptimizedBoolean(currentScope, codeStream, trueLabel, falseLabel);
/*     */       }  b++; }
/*     */     
/* 279 */     super.generatePatternVariable(currentScope, codeStream, trueLabel, falseLabel); } public void wrapupGeneration(CodeStream codeStream) {
/*     */     byte b;
/*     */     int i;
/*     */     Pattern[] arrayOfPattern;
/* 283 */     for (i = (arrayOfPattern = this.patterns).length, b = 0; b < i; ) { Pattern p = arrayOfPattern[b];
/* 284 */       p.wrapupGeneration(codeStream); b++; }
/*     */     
/* 286 */     super.wrapupGeneration(codeStream);
/*     */   }
/*     */   
/*     */   public void suspendVariables(CodeStream codeStream, BlockScope scope) {
/* 290 */     codeStream.removeNotDefinitelyAssignedVariables((Scope)scope, this.thenInitStateIndex1);
/*     */   }
/*     */   
/*     */   public void resumeVariables(CodeStream codeStream, BlockScope scope) {
/* 294 */     codeStream.addDefinitelyAssignedVariables((Scope)scope, this.thenInitStateIndex2); } public void traverse(ASTVisitor visitor, BlockScope scope) {
/*     */     byte b;
/*     */     int i;
/*     */     Pattern[] arrayOfPattern;
/* 298 */     for (i = (arrayOfPattern = this.patterns).length, b = 0; b < i; ) { Pattern p = arrayOfPattern[b];
/* 299 */       visitor.visit(p, scope); b++; }
/*     */     
/* 301 */     if (visitor.visit(this, scope)) {
/* 302 */       if (this.local != null) {
/* 303 */         this.local.traverse(visitor, scope);
/* 304 */       } else if (this.type != null) {
/* 305 */         this.type.traverse(visitor, scope);
/*     */       } 
/* 307 */       for (i = (arrayOfPattern = this.patterns).length, b = 0; b < i; ) { Pattern p = arrayOfPattern[b];
/* 308 */         p.traverse(visitor, scope); b++; }
/*     */     
/*     */     } 
/* 311 */     visitor.endVisit(this, scope);
/*     */   }
/*     */ 
/*     */   
/*     */   public StringBuffer printExpression(int indent, StringBuffer output) {
/* 316 */     output.append(this.type).append('(');
/* 317 */     if (this.patterns != null) {
/* 318 */       for (int i = 0; i < this.patterns.length; i++) {
/* 319 */         if (i > 0) output.append(", "); 
/* 320 */         this.patterns[i].print(0, output);
/*     */       } 
/*     */     }
/* 323 */     output.append(')');
/* 324 */     if (this.local != null)
/* 325 */       output.append(' ').append(this.local.name); 
/* 326 */     return output;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\ast\RecordPattern.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */