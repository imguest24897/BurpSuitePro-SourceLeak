/*     */ package org.eclipse.jdt.internal.compiler.ast;
/*     */ 
/*     */ import org.eclipse.jdt.internal.compiler.ASTVisitor;
/*     */ import org.eclipse.jdt.internal.compiler.flow.FlowContext;
/*     */ import org.eclipse.jdt.internal.compiler.flow.FlowInfo;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.BlockScope;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ContinueStatement
/*     */   extends BranchStatement
/*     */ {
/*     */   public ContinueStatement(char[] label, int sourceStart, int sourceEnd) {
/*  25 */     super(label, sourceStart, sourceEnd);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public FlowInfo analyseCode(BlockScope currentScope, FlowContext flowContext, FlowInfo flowInfo) {
/*  35 */     FlowContext targetContext = (this.label == null) ? 
/*  36 */       flowContext.getTargetContextForDefaultContinue() : 
/*  37 */       flowContext.getTargetContextForContinueLabel(this.label);
/*     */     
/*  39 */     if (targetContext == null) {
/*  40 */       if (this.label == null) {
/*  41 */         currentScope.problemReporter().invalidContinue(this);
/*     */       } else {
/*  43 */         currentScope.problemReporter().undefinedLabel(this);
/*     */       } 
/*  45 */       return flowInfo;
/*     */     } 
/*     */     
/*  48 */     targetContext.recordAbruptExit();
/*  49 */     targetContext.expireNullCheckedFieldInfo();
/*     */     
/*  51 */     if (targetContext == FlowContext.NotContinuableContext) {
/*  52 */       currentScope.problemReporter().invalidContinue(this);
/*  53 */       return flowInfo;
/*     */     } 
/*  55 */     this.initStateIndex = 
/*  56 */       currentScope.methodScope().recordInitializationStates(flowInfo);
/*     */     
/*  58 */     this.targetLabel = targetContext.continueLabel();
/*  59 */     FlowContext traversedContext = flowContext;
/*  60 */     int subCount = 0;
/*  61 */     this.subroutines = new SubRoutineStatement[5];
/*     */     
/*     */     do {
/*     */       SubRoutineStatement sub;
/*  65 */       if ((sub = traversedContext.subroutine()) != null) {
/*  66 */         if (subCount == this.subroutines.length) {
/*  67 */           System.arraycopy(this.subroutines, 0, this.subroutines = new SubRoutineStatement[subCount * 2], 0, subCount);
/*     */         }
/*  69 */         this.subroutines[subCount++] = sub;
/*  70 */         if (sub.isSubRoutineEscaping()) {
/*     */           break;
/*     */         }
/*     */       } 
/*  74 */       traversedContext.recordReturnFrom(flowInfo.unconditionalInits());
/*     */       
/*  76 */       if (traversedContext instanceof org.eclipse.jdt.internal.compiler.flow.InsideSubRoutineFlowContext) {
/*  77 */         ASTNode node = traversedContext.associatedNode;
/*  78 */         if (node instanceof TryStatement) {
/*  79 */           TryStatement tryStatement = (TryStatement)node;
/*  80 */           flowInfo.addInitializationsFrom((FlowInfo)tryStatement.subRoutineInits);
/*     */         } 
/*  82 */       } else if (traversedContext == targetContext) {
/*     */         
/*  84 */         targetContext.recordContinueFrom(flowContext, flowInfo);
/*     */         break;
/*     */       } 
/*  87 */     } while ((traversedContext = traversedContext.getLocalParent()) != null);
/*     */ 
/*     */     
/*  90 */     if (subCount != this.subroutines.length) {
/*  91 */       System.arraycopy(this.subroutines, 0, this.subroutines = new SubRoutineStatement[subCount], 0, subCount);
/*     */     }
/*  93 */     return (FlowInfo)FlowInfo.DEAD_END;
/*     */   }
/*     */ 
/*     */   
/*     */   public StringBuffer printStatement(int tab, StringBuffer output) {
/*  98 */     printIndent(tab, output).append("continue ");
/*  99 */     if (this.label != null) output.append(this.label); 
/* 100 */     return output.append(';');
/*     */   }
/*     */ 
/*     */   
/*     */   public void traverse(ASTVisitor visitor, BlockScope blockScope) {
/* 105 */     visitor.visit(this, blockScope);
/* 106 */     visitor.endVisit(this, blockScope);
/*     */   }
/*     */   
/*     */   public boolean doesNotCompleteNormally() {
/* 110 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean completesByContinue() {
/* 115 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean canCompleteNormally() {
/* 120 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean continueCompletes() {
/* 125 */     return true;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\ast\ContinueStatement.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */