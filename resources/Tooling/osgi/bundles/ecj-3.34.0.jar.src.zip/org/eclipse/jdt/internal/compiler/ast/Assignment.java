/*     */ package org.eclipse.jdt.internal.compiler.ast;
/*     */ 
/*     */ import org.eclipse.jdt.internal.compiler.ASTVisitor;
/*     */ import org.eclipse.jdt.internal.compiler.codegen.CodeStream;
/*     */ import org.eclipse.jdt.internal.compiler.flow.FlowContext;
/*     */ import org.eclipse.jdt.internal.compiler.flow.FlowInfo;
/*     */ import org.eclipse.jdt.internal.compiler.flow.UnconditionalFlowInfo;
/*     */ import org.eclipse.jdt.internal.compiler.impl.CompilerOptions;
/*     */ import org.eclipse.jdt.internal.compiler.impl.Constant;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.Binding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.BlockScope;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.FieldBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.LocalVariableBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.Scope;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.TypeBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.VariableBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.WildcardBinding;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Assignment
/*     */   extends Expression
/*     */ {
/*     */   public Expression lhs;
/*     */   public Expression expression;
/*     */   
/*     */   public Assignment(Expression lhs, Expression expression, int sourceEnd) {
/*  54 */     this.lhs = lhs;
/*  55 */     lhs.bits |= 0x2000;
/*  56 */     this.expression = expression;
/*  57 */     this.sourceStart = lhs.sourceStart;
/*  58 */     this.sourceEnd = sourceEnd;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public FlowInfo analyseCode(BlockScope currentScope, FlowContext flowContext, FlowInfo flowInfo) {
/*     */     UnconditionalFlowInfo unconditionalFlowInfo2;
/*  66 */     LocalVariableBinding local = this.lhs.localVariableBinding();
/*  67 */     this.expression.checkNPEbyUnboxing(currentScope, flowContext, flowInfo);
/*     */     
/*  69 */     FlowInfo preInitInfo = null;
/*  70 */     CompilerOptions compilerOptions = currentScope.compilerOptions();
/*  71 */     boolean shouldAnalyseResource = (local != null && 
/*  72 */       flowInfo.reachMode() == 0 && 
/*  73 */       compilerOptions.analyseResourceLeaks && (
/*  74 */       FakedTrackingVariable.isAnyCloseable(this.expression.resolvedType) || 
/*  75 */       this.expression.resolvedType == TypeBinding.NULL));
/*  76 */     if (shouldAnalyseResource) {
/*  77 */       unconditionalFlowInfo2 = flowInfo.unconditionalCopy();
/*     */       
/*  79 */       FakedTrackingVariable.preConnectTrackerAcrossAssignment(this, local, this.expression, flowInfo);
/*     */     } 
/*     */     
/*  82 */     UnconditionalFlowInfo unconditionalFlowInfo1 = ((Reference)this.lhs)
/*  83 */       .analyseAssignment(currentScope, flowContext, flowInfo, this, false)
/*  84 */       .unconditionalInits();
/*     */     
/*  86 */     if (shouldAnalyseResource) {
/*  87 */       FakedTrackingVariable.handleResourceAssignment(currentScope, (FlowInfo)unconditionalFlowInfo2, (FlowInfo)unconditionalFlowInfo1, flowContext, this, this.expression, local);
/*     */     } else {
/*  89 */       FakedTrackingVariable.cleanUpAfterAssignment(currentScope, this.lhs.bits, this.expression);
/*     */     } 
/*  91 */     int nullStatus = this.expression.nullStatus((FlowInfo)unconditionalFlowInfo1, flowContext);
/*  92 */     if (local != null && (local.type.tagBits & 0x2L) == 0L && 
/*  93 */       nullStatus == 2) {
/*  94 */       flowContext.recordUsingNullReference((Scope)currentScope, local, this.lhs, 
/*  95 */           769, (FlowInfo)unconditionalFlowInfo1);
/*     */     }
/*     */     
/*  98 */     if (compilerOptions.isAnnotationBasedNullAnalysisEnabled) {
/*  99 */       VariableBinding var = this.lhs.nullAnnotatedVariableBinding((compilerOptions.sourceLevel >= 3407872L));
/* 100 */       if (var != null) {
/* 101 */         nullStatus = NullAnnotationMatching.checkAssignment(currentScope, flowContext, var, (FlowInfo)unconditionalFlowInfo1, nullStatus, this.expression, this.expression.resolvedType);
/* 102 */         if (nullStatus == 4 && 
/* 103 */           var instanceof FieldBinding && 
/* 104 */           this.lhs instanceof Reference && 
/* 105 */           compilerOptions.enableSyntacticNullAnalysisForFields) {
/*     */           
/* 107 */           int timeToLive = ((this.bits & 0x100000) != 0) ? 
/* 108 */             2 : 
/* 109 */             1;
/* 110 */           flowContext.recordNullCheckedFieldReference((Reference)this.lhs, timeToLive);
/*     */         } 
/*     */       } 
/*     */     } 
/* 114 */     if (local != null && (local.type.tagBits & 0x2L) == 0L) {
/* 115 */       unconditionalFlowInfo1.markNullStatus(local, nullStatus);
/* 116 */       flowContext.markFinallyNullStatus(local, nullStatus);
/*     */     } 
/* 118 */     return (FlowInfo)unconditionalFlowInfo1;
/*     */   }
/*     */   
/*     */   void checkAssignment(BlockScope scope, TypeBinding lhsType, TypeBinding rhsType) {
/* 122 */     FieldBinding leftField = getLastField(this.lhs);
/* 123 */     if (leftField != null && rhsType != TypeBinding.NULL && lhsType.kind() == 516 && ((WildcardBinding)lhsType).boundKind != 2) {
/* 124 */       scope.problemReporter().wildcardAssignment(lhsType, rhsType, this.expression);
/* 125 */     } else if (leftField != null && !leftField.isStatic() && leftField.declaringClass != null && leftField.declaringClass.isRawType()) {
/* 126 */       scope.problemReporter().unsafeRawFieldAssignment(leftField, rhsType, this.lhs);
/* 127 */     } else if (rhsType.needsUncheckedConversion(lhsType)) {
/* 128 */       scope.problemReporter().unsafeTypeConversion(this.expression, rhsType, lhsType);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void generateCode(BlockScope currentScope, CodeStream codeStream, boolean valueRequired) {
/* 138 */     int pc = codeStream.position;
/* 139 */     ((Reference)this.lhs).generateAssignment(currentScope, codeStream, this, valueRequired);
/*     */ 
/*     */     
/* 142 */     codeStream.recordPositionsFrom(pc, this.sourceStart);
/*     */   }
/*     */   
/*     */   FieldBinding getLastField(Expression someExpression) {
/* 146 */     if (someExpression instanceof SingleNameReference) {
/* 147 */       if ((someExpression.bits & 0x7) == 1)
/* 148 */         return (FieldBinding)((SingleNameReference)someExpression).binding; 
/*     */     } else {
/* 150 */       if (someExpression instanceof FieldReference)
/* 151 */         return ((FieldReference)someExpression).binding; 
/* 152 */       if (someExpression instanceof QualifiedNameReference) {
/* 153 */         QualifiedNameReference qName = (QualifiedNameReference)someExpression;
/* 154 */         if (qName.otherBindings == null) {
/* 155 */           if ((someExpression.bits & 0x7) == 1) {
/* 156 */             return (FieldBinding)qName.binding;
/*     */           }
/*     */         } else {
/* 159 */           return qName.otherBindings[qName.otherBindings.length - 1];
/*     */         } 
/*     */       } 
/* 162 */     }  return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public int nullStatus(FlowInfo flowInfo, FlowContext flowContext) {
/* 167 */     if ((this.implicitConversion & 0x200) != 0)
/* 168 */       return 4; 
/* 169 */     return this.expression.nullStatus(flowInfo, flowContext);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public StringBuffer print(int indent, StringBuffer output) {
/* 175 */     printIndent(indent, output);
/* 176 */     return printExpressionNoParenthesis(indent, output);
/*     */   }
/*     */ 
/*     */   
/*     */   public StringBuffer printExpression(int indent, StringBuffer output) {
/* 181 */     output.append('(');
/* 182 */     return printExpressionNoParenthesis(0, output).append(')');
/*     */   }
/*     */   
/*     */   public StringBuffer printExpressionNoParenthesis(int indent, StringBuffer output) {
/* 186 */     this.lhs.printExpression(indent, output).append(" = ");
/* 187 */     return this.expression.printExpression(0, output);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public StringBuffer printStatement(int indent, StringBuffer output) {
/* 193 */     return print(indent, output).append(';');
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public TypeBinding resolveType(BlockScope scope) {
/* 199 */     this.constant = Constant.NotAConstant;
/* 200 */     if (!(this.lhs instanceof Reference) || this.lhs.isThis()) {
/* 201 */       scope.problemReporter().expressionShouldBeAVariable(this.lhs);
/* 202 */       return null;
/*     */     } 
/* 204 */     TypeBinding lhsType = this.lhs.resolveType(scope);
/* 205 */     this.expression.setExpressionContext(ExpressionContext.ASSIGNMENT_CONTEXT);
/* 206 */     this.expression.setExpectedType(lhsType);
/* 207 */     if (lhsType != null) {
/* 208 */       this.resolvedType = lhsType.capture((Scope)scope, this.lhs.sourceStart, this.lhs.sourceEnd);
/*     */     }
/* 210 */     LocalVariableBinding localVariableBinding = this.lhs.localVariableBinding();
/* 211 */     if (localVariableBinding != null && (localVariableBinding.isCatchParameter() || localVariableBinding.isParameter())) {
/* 212 */       localVariableBinding.tagBits &= 0xFFFFFFFFFFFFF7FFL;
/*     */     }
/* 214 */     TypeBinding rhsType = this.expression.resolveType(scope);
/* 215 */     if (lhsType == null || rhsType == null) {
/* 216 */       return null;
/*     */     }
/*     */     
/* 219 */     Binding left = getDirectBinding(this.lhs);
/* 220 */     if (left != null && !left.isVolatile() && left == getDirectBinding(this.expression)) {
/* 221 */       scope.problemReporter().assignmentHasNoEffect(this, left.shortReadableName());
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 226 */     if (TypeBinding.notEquals(lhsType, rhsType)) {
/* 227 */       scope.compilationUnitScope().recordTypeConversion(lhsType, rhsType);
/*     */     }
/* 229 */     if (this.expression.isConstantValueOfTypeAssignableToType(rhsType, lhsType) || 
/* 230 */       rhsType.isCompatibleWith(lhsType, (Scope)scope)) {
/* 231 */       this.expression.computeConversion((Scope)scope, lhsType, rhsType);
/* 232 */       checkAssignment(scope, lhsType, rhsType);
/* 233 */       if (this.expression instanceof CastExpression && (
/* 234 */         this.expression.bits & 0x4000) == 0) {
/* 235 */         CastExpression.checkNeedForAssignedCast(scope, lhsType, (CastExpression)this.expression);
/*     */       }
/* 237 */       return this.resolvedType;
/* 238 */     }  if (isBoxingCompatible(rhsType, lhsType, this.expression, (Scope)scope)) {
/* 239 */       this.expression.computeConversion((Scope)scope, lhsType, rhsType);
/* 240 */       if (this.expression instanceof CastExpression && (
/* 241 */         this.expression.bits & 0x4000) == 0) {
/* 242 */         CastExpression.checkNeedForAssignedCast(scope, lhsType, (CastExpression)this.expression);
/*     */       }
/* 244 */       return this.resolvedType;
/*     */     } 
/* 246 */     scope.problemReporter().typeMismatchError(rhsType, lhsType, this.expression, this.lhs);
/* 247 */     return lhsType;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TypeBinding resolveTypeExpecting(BlockScope scope, TypeBinding expectedType) {
/* 256 */     TypeBinding type = super.resolveTypeExpecting(scope, expectedType);
/* 257 */     if (type == null) return null; 
/* 258 */     TypeBinding lhsType = this.resolvedType;
/* 259 */     TypeBinding rhsType = this.expression.resolvedType;
/*     */     
/* 261 */     if (TypeBinding.equalsEquals(expectedType, (TypeBinding)TypeBinding.BOOLEAN) && 
/* 262 */       TypeBinding.equalsEquals(lhsType, (TypeBinding)TypeBinding.BOOLEAN) && (
/* 263 */       this.lhs.bits & 0x2000) != 0) {
/* 264 */       scope.problemReporter().possibleAccidentalBooleanAssignment(this);
/*     */     }
/* 266 */     checkAssignment(scope, lhsType, rhsType);
/* 267 */     return type;
/*     */   }
/*     */ 
/*     */   
/*     */   public void traverse(ASTVisitor visitor, BlockScope scope) {
/* 272 */     if (visitor.visit(this, scope)) {
/* 273 */       this.lhs.traverse(visitor, scope);
/* 274 */       this.expression.traverse(visitor, scope);
/*     */     } 
/* 276 */     visitor.endVisit(this, scope);
/*     */   }
/*     */   
/*     */   public LocalVariableBinding localVariableBinding() {
/* 280 */     return this.lhs.localVariableBinding();
/*     */   }
/*     */   
/*     */   public boolean statementExpression() {
/* 284 */     return ((this.bits & 0x1FE00000) == 0);
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\ast\Assignment.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */