/*     */ package org.eclipse.jdt.internal.compiler.ast;
/*     */ 
/*     */ import org.eclipse.jdt.internal.compiler.lookup.ParameterizedTypeBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.RawTypeBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.ReferenceBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.Scope;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.TypeBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.TypeBindingVisitor;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class VisibilityInspector
/*     */   extends TypeBindingVisitor
/*     */ {
/*     */   private Scope scope;
/*     */   private boolean shouldChatter;
/*     */   private boolean visible = true;
/*     */   private FunctionalExpression expression;
/*     */   
/*     */   public VisibilityInspector(FunctionalExpression expression, Scope scope, boolean shouldChatter) {
/* 251 */     this.scope = scope;
/* 252 */     this.shouldChatter = shouldChatter;
/* 253 */     this.expression = expression;
/*     */   }
/*     */   
/*     */   private void checkVisibility(ReferenceBinding referenceBinding) {
/* 257 */     if (!referenceBinding.canBeSeenBy(this.scope)) {
/* 258 */       this.visible = false;
/* 259 */       if (this.shouldChatter) {
/* 260 */         this.scope.problemReporter().descriptorHasInvisibleType(this.expression, referenceBinding);
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   public boolean visit(ReferenceBinding referenceBinding) {
/* 266 */     checkVisibility(referenceBinding);
/* 267 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean visit(ParameterizedTypeBinding parameterizedTypeBinding) {
/* 273 */     checkVisibility((ReferenceBinding)parameterizedTypeBinding);
/* 274 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean visit(RawTypeBinding rawTypeBinding) {
/* 279 */     checkVisibility((ReferenceBinding)rawTypeBinding);
/* 280 */     return true;
/*     */   }
/*     */   
/*     */   public boolean visible(TypeBinding type) {
/* 284 */     TypeBindingVisitor.visit(this, type);
/* 285 */     return this.visible;
/*     */   }
/*     */   
/*     */   public boolean visible(TypeBinding[] types) {
/* 289 */     TypeBindingVisitor.visit(this, types);
/* 290 */     return this.visible;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\ast\FunctionalExpression$VisibilityInspector.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */