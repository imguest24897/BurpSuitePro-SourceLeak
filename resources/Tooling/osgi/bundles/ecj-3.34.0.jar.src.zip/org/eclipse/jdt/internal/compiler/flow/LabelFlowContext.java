/*    */ package org.eclipse.jdt.internal.compiler.flow;
/*    */ 
/*    */ import org.eclipse.jdt.core.compiler.CharOperation;
/*    */ import org.eclipse.jdt.internal.compiler.ast.ASTNode;
/*    */ import org.eclipse.jdt.internal.compiler.codegen.BranchLabel;
/*    */ import org.eclipse.jdt.internal.compiler.lookup.BlockScope;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class LabelFlowContext
/*    */   extends SwitchFlowContext
/*    */ {
/*    */   public char[] labelName;
/*    */   
/*    */   public LabelFlowContext(FlowContext parent, ASTNode associatedNode, char[] labelName, BranchLabel breakLabel, BlockScope scope) {
/* 32 */     super(parent, associatedNode, breakLabel, false, true);
/* 33 */     this.labelName = labelName;
/* 34 */     checkLabelValidity(scope);
/*    */   }
/*    */ 
/*    */   
/*    */   void checkLabelValidity(BlockScope scope) {
/* 39 */     FlowContext current = getLocalParent();
/* 40 */     while (current != null) {
/*    */       char[] currentLabelName;
/* 42 */       if ((currentLabelName = current.labelName()) != null && 
/* 43 */         CharOperation.equals(currentLabelName, this.labelName)) {
/* 44 */         scope.problemReporter().alreadyDefinedLabel(this.labelName, this.associatedNode);
/*    */       }
/* 46 */       current = current.getLocalParent();
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   public String individualToString() {
/* 52 */     return "Label flow context [label:" + String.valueOf(this.labelName) + "]";
/*    */   }
/*    */ 
/*    */   
/*    */   public char[] labelName() {
/* 57 */     return this.labelName;
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\flow\LabelFlowContext.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */