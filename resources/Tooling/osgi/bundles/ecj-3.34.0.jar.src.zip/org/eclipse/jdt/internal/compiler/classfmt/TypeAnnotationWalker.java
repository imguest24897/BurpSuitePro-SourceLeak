/*     */ package org.eclipse.jdt.internal.compiler.classfmt;
/*     */ 
/*     */ import org.eclipse.jdt.internal.compiler.env.IBinaryAnnotation;
/*     */ import org.eclipse.jdt.internal.compiler.env.IBinaryTypeAnnotation;
/*     */ import org.eclipse.jdt.internal.compiler.env.ITypeAnnotationWalker;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TypeAnnotationWalker
/*     */   implements ITypeAnnotationWalker
/*     */ {
/*     */   protected final IBinaryTypeAnnotation[] typeAnnotations;
/*     */   protected final long matches;
/*     */   protected final int pathPtr;
/*     */   
/*     */   public TypeAnnotationWalker(IBinaryTypeAnnotation[] typeAnnotations) {
/*  30 */     this(typeAnnotations, -1L >>> 64 - typeAnnotations.length);
/*     */   }
/*     */   TypeAnnotationWalker(IBinaryTypeAnnotation[] typeAnnotations, long matchBits) {
/*  33 */     this(typeAnnotations, matchBits, 0);
/*     */   }
/*     */   protected TypeAnnotationWalker(IBinaryTypeAnnotation[] typeAnnotations, long matchBits, int pathPtr) {
/*  36 */     this.typeAnnotations = typeAnnotations;
/*  37 */     this.matches = matchBits;
/*  38 */     this.pathPtr = pathPtr;
/*     */   }
/*     */   
/*     */   protected ITypeAnnotationWalker restrict(long newMatches, int newPathPtr) {
/*  42 */     if (this.matches == newMatches && this.pathPtr == newPathPtr) return this; 
/*  43 */     if (newMatches == 0L || this.typeAnnotations == null || this.typeAnnotations.length == 0)
/*  44 */       return EMPTY_ANNOTATION_WALKER; 
/*  45 */     return new TypeAnnotationWalker(this.typeAnnotations, newMatches, newPathPtr);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ITypeAnnotationWalker toField() {
/*  52 */     return toTarget(19);
/*     */   }
/*     */ 
/*     */   
/*     */   public ITypeAnnotationWalker toMethodReturn() {
/*  57 */     return toTarget(20);
/*     */   }
/*     */ 
/*     */   
/*     */   public ITypeAnnotationWalker toReceiver() {
/*  62 */     return toTarget(21);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected ITypeAnnotationWalker toTarget(int targetType) {
/*  69 */     long newMatches = this.matches;
/*  70 */     if (newMatches == 0L)
/*  71 */       return EMPTY_ANNOTATION_WALKER; 
/*  72 */     int length = this.typeAnnotations.length;
/*  73 */     long mask = 1L;
/*  74 */     for (int i = 0; i < length; i++, mask <<= 1L) {
/*  75 */       if (this.typeAnnotations[i].getTargetType() != targetType)
/*  76 */         newMatches &= mask ^ 0xFFFFFFFFFFFFFFFFL; 
/*     */     } 
/*  78 */     return restrict(newMatches, 0);
/*     */   }
/*     */ 
/*     */   
/*     */   public ITypeAnnotationWalker toTypeParameter(boolean isClassTypeParameter, int rank) {
/*  83 */     long newMatches = this.matches;
/*  84 */     if (newMatches == 0L)
/*  85 */       return EMPTY_ANNOTATION_WALKER; 
/*  86 */     int targetType = isClassTypeParameter ? 0 : 1;
/*  87 */     int length = this.typeAnnotations.length;
/*  88 */     long mask = 1L;
/*  89 */     for (int i = 0; i < length; i++, mask <<= 1L) {
/*  90 */       IBinaryTypeAnnotation candidate = this.typeAnnotations[i];
/*  91 */       if (candidate.getTargetType() != targetType || candidate.getTypeParameterIndex() != rank) {
/*  92 */         newMatches &= mask ^ 0xFFFFFFFFFFFFFFFFL;
/*     */       }
/*     */     } 
/*  95 */     return restrict(newMatches, 0);
/*     */   }
/*     */ 
/*     */   
/*     */   public ITypeAnnotationWalker toTypeParameterBounds(boolean isClassTypeParameter, int parameterRank) {
/* 100 */     long newMatches = this.matches;
/* 101 */     if (newMatches == 0L)
/* 102 */       return EMPTY_ANNOTATION_WALKER; 
/* 103 */     int length = this.typeAnnotations.length;
/* 104 */     int targetType = isClassTypeParameter ? 
/* 105 */       17 : 18;
/* 106 */     long mask = 1L;
/* 107 */     for (int i = 0; i < length; i++, mask <<= 1L) {
/* 108 */       IBinaryTypeAnnotation candidate = this.typeAnnotations[i];
/* 109 */       if (candidate.getTargetType() != targetType || (short)candidate.getTypeParameterIndex() != parameterRank) {
/* 110 */         newMatches &= mask ^ 0xFFFFFFFFFFFFFFFFL;
/*     */       }
/*     */     } 
/* 113 */     return restrict(newMatches, 0);
/*     */   }
/*     */ 
/*     */   
/*     */   public ITypeAnnotationWalker toTypeBound(short boundIndex) {
/* 118 */     long newMatches = this.matches;
/* 119 */     if (newMatches == 0L)
/* 120 */       return EMPTY_ANNOTATION_WALKER; 
/* 121 */     int length = this.typeAnnotations.length;
/* 122 */     long mask = 1L;
/* 123 */     for (int i = 0; i < length; i++, mask <<= 1L) {
/* 124 */       IBinaryTypeAnnotation candidate = this.typeAnnotations[i];
/* 125 */       if ((short)candidate.getBoundIndex() != boundIndex) {
/* 126 */         newMatches &= mask ^ 0xFFFFFFFFFFFFFFFFL;
/*     */       }
/*     */     } 
/* 129 */     return restrict(newMatches, 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ITypeAnnotationWalker toSupertype(short index, char[] superTypeSignature) {
/* 139 */     long newMatches = this.matches;
/* 140 */     if (newMatches == 0L)
/* 141 */       return EMPTY_ANNOTATION_WALKER; 
/* 142 */     int length = this.typeAnnotations.length;
/* 143 */     long mask = 1L;
/* 144 */     for (int i = 0; i < length; i++, mask <<= 1L) {
/* 145 */       IBinaryTypeAnnotation candidate = this.typeAnnotations[i];
/* 146 */       if (candidate.getTargetType() != 16 || (short)candidate.getSupertypeIndex() != index) {
/* 147 */         newMatches &= mask ^ 0xFFFFFFFFFFFFFFFFL;
/*     */       }
/*     */     } 
/* 150 */     return restrict(newMatches, 0);
/*     */   }
/*     */ 
/*     */   
/*     */   public ITypeAnnotationWalker toMethodParameter(short index) {
/* 155 */     long newMatches = this.matches;
/* 156 */     if (newMatches == 0L)
/* 157 */       return EMPTY_ANNOTATION_WALKER; 
/* 158 */     int length = this.typeAnnotations.length;
/* 159 */     long mask = 1L;
/* 160 */     for (int i = 0; i < length; i++, mask <<= 1L) {
/* 161 */       IBinaryTypeAnnotation candidate = this.typeAnnotations[i];
/* 162 */       if (candidate.getTargetType() != 22 || (short)candidate.getMethodFormalParameterIndex() != index) {
/* 163 */         newMatches &= mask ^ 0xFFFFFFFFFFFFFFFFL;
/*     */       }
/*     */     } 
/* 166 */     return restrict(newMatches, 0);
/*     */   }
/*     */ 
/*     */   
/*     */   public ITypeAnnotationWalker toThrows(int index) {
/* 171 */     long newMatches = this.matches;
/* 172 */     if (newMatches == 0L)
/* 173 */       return EMPTY_ANNOTATION_WALKER; 
/* 174 */     int length = this.typeAnnotations.length;
/* 175 */     long mask = 1L;
/* 176 */     for (int i = 0; i < length; i++, mask <<= 1L) {
/* 177 */       IBinaryTypeAnnotation candidate = this.typeAnnotations[i];
/* 178 */       if (candidate.getTargetType() != 23 || candidate.getThrowsTypeIndex() != index) {
/* 179 */         newMatches &= mask ^ 0xFFFFFFFFFFFFFFFFL;
/*     */       }
/*     */     } 
/* 182 */     return restrict(newMatches, 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ITypeAnnotationWalker toTypeArgument(int rank) {
/* 190 */     long newMatches = this.matches;
/* 191 */     if (newMatches == 0L)
/* 192 */       return EMPTY_ANNOTATION_WALKER; 
/* 193 */     int length = this.typeAnnotations.length;
/* 194 */     long mask = 1L;
/* 195 */     for (int i = 0; i < length; i++, mask <<= 1L) {
/* 196 */       IBinaryTypeAnnotation candidate = this.typeAnnotations[i];
/* 197 */       int[] path = candidate.getTypePath();
/* 198 */       if (this.pathPtr >= path.length || 
/* 199 */         path[this.pathPtr] != 3 || 
/* 200 */         path[this.pathPtr + 1] != rank) {
/* 201 */         newMatches &= mask ^ 0xFFFFFFFFFFFFFFFFL;
/*     */       }
/*     */     } 
/* 204 */     return restrict(newMatches, this.pathPtr + 2);
/*     */   }
/*     */ 
/*     */   
/*     */   public ITypeAnnotationWalker toWildcardBound() {
/* 209 */     long newMatches = this.matches;
/* 210 */     if (newMatches == 0L)
/* 211 */       return EMPTY_ANNOTATION_WALKER; 
/* 212 */     int length = this.typeAnnotations.length;
/* 213 */     long mask = 1L;
/* 214 */     for (int i = 0; i < length; i++, mask <<= 1L) {
/* 215 */       IBinaryTypeAnnotation candidate = this.typeAnnotations[i];
/* 216 */       int[] path = candidate.getTypePath();
/* 217 */       if (this.pathPtr >= path.length || 
/* 218 */         path[this.pathPtr] != 2) {
/* 219 */         newMatches &= mask ^ 0xFFFFFFFFFFFFFFFFL;
/*     */       }
/*     */     } 
/* 222 */     return restrict(newMatches, this.pathPtr + 2);
/*     */   }
/*     */ 
/*     */   
/*     */   public ITypeAnnotationWalker toNextArrayDimension() {
/* 227 */     return toNextDetail(0);
/*     */   }
/*     */ 
/*     */   
/*     */   public ITypeAnnotationWalker toNextNestedType() {
/* 232 */     return toNextDetail(1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected ITypeAnnotationWalker toNextDetail(int detailKind) {
/* 239 */     long newMatches = this.matches;
/* 240 */     if (newMatches == 0L)
/* 241 */       return restrict(newMatches, this.pathPtr + 2); 
/* 242 */     int length = this.typeAnnotations.length;
/* 243 */     long mask = 1L;
/* 244 */     for (int i = 0; i < length; i++, mask <<= 1L) {
/* 245 */       IBinaryTypeAnnotation candidate = this.typeAnnotations[i];
/* 246 */       int[] path = candidate.getTypePath();
/* 247 */       if (this.pathPtr >= path.length || path[this.pathPtr] != detailKind) {
/* 248 */         newMatches &= mask ^ 0xFFFFFFFFFFFFFFFFL;
/*     */       }
/*     */     } 
/* 251 */     return restrict(newMatches, this.pathPtr + 2);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IBinaryAnnotation[] getAnnotationsAtCursor(int currentTypeId, boolean mayApplyArrayContentsDefaultNullness) {
/* 258 */     int length = this.typeAnnotations.length;
/* 259 */     IBinaryAnnotation[] filtered = new IBinaryAnnotation[length];
/* 260 */     long ptr = 1L;
/* 261 */     int count = 0;
/* 262 */     for (int i = 0; i < length; i++, ptr <<= 1L) {
/* 263 */       if ((this.matches & ptr) != 0L) {
/*     */         
/* 265 */         IBinaryTypeAnnotation candidate = this.typeAnnotations[i];
/* 266 */         if ((candidate.getTypePath()).length <= this.pathPtr)
/*     */         {
/* 268 */           filtered[count++] = candidate.getAnnotation(); } 
/*     */       } 
/* 270 */     }  if (count == 0)
/* 271 */       return NO_ANNOTATIONS; 
/* 272 */     if (count < length)
/* 273 */       System.arraycopy(filtered, 0, filtered = new IBinaryAnnotation[count], 0, count); 
/* 274 */     return filtered;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\classfmt\TypeAnnotationWalker.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */