/*     */ package org.eclipse.jdt.internal.compiler.ast;
/*     */ 
/*     */ import org.eclipse.jdt.core.compiler.CharOperation;
/*     */ import org.eclipse.jdt.internal.compiler.ASTVisitor;
/*     */ import org.eclipse.jdt.internal.compiler.impl.Constant;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.BlockScope;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.ClassScope;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.MethodBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.ProblemMethodBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.ReferenceBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.Scope;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.TypeBinding;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JavadocMessageSend
/*     */   extends MessageSend
/*     */ {
/*     */   public int tagSourceStart;
/*     */   public int tagSourceEnd;
/*     */   public int tagValue;
/*     */   
/*     */   public JavadocMessageSend(char[] name, long pos) {
/*  28 */     this.selector = name;
/*  29 */     this.nameSourcePosition = pos;
/*  30 */     this.sourceStart = (int)(this.nameSourcePosition >>> 32L);
/*  31 */     this.sourceEnd = (int)this.nameSourcePosition;
/*  32 */     this.bits |= 0x8000;
/*     */   }
/*     */   public JavadocMessageSend(char[] name, long pos, JavadocArgumentExpression[] arguments) {
/*  35 */     this(name, pos);
/*  36 */     this.arguments = (Expression[])arguments;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private TypeBinding internalResolveType(Scope scope) {
/*  45 */     this.constant = Constant.NotAConstant;
/*  46 */     if (this.receiver == null) {
/*  47 */       this.actualReceiverType = (TypeBinding)scope.enclosingReceiverType();
/*  48 */     } else if (scope.kind == 3) {
/*  49 */       this.actualReceiverType = this.receiver.resolveType((ClassScope)scope);
/*     */     } else {
/*  51 */       this.actualReceiverType = this.receiver.resolveType((BlockScope)scope);
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/*  56 */     boolean hasArgsTypeVar = false;
/*  57 */     if (this.arguments != null) {
/*  58 */       this.argumentsHaveErrors = false;
/*  59 */       int length = this.arguments.length;
/*  60 */       this.argumentTypes = new TypeBinding[length];
/*  61 */       for (int i = 0; i < length; i++) {
/*  62 */         Expression argument = this.arguments[i];
/*  63 */         if (scope.kind == 3) {
/*  64 */           this.argumentTypes[i] = argument.resolveType((ClassScope)scope);
/*     */         } else {
/*  66 */           this.argumentTypes[i] = argument.resolveType((BlockScope)scope);
/*     */         } 
/*  68 */         if (this.argumentTypes[i] == null) {
/*  69 */           this.argumentsHaveErrors = true;
/*  70 */         } else if (!hasArgsTypeVar) {
/*  71 */           hasArgsTypeVar = this.argumentTypes[i].isTypeVariable();
/*     */         } 
/*     */       } 
/*  74 */       if (this.argumentsHaveErrors) {
/*  75 */         return null;
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/*  80 */     if (this.actualReceiverType == null) {
/*  81 */       return null;
/*     */     }
/*  83 */     this.actualReceiverType = scope.environment().convertToRawType(this.receiver.resolvedType, true);
/*  84 */     ReferenceBinding enclosingType = scope.enclosingReceiverType();
/*  85 */     if (enclosingType != null && enclosingType.isCompatibleWith(this.actualReceiverType)) {
/*  86 */       this.bits |= 0x4000;
/*     */     }
/*     */ 
/*     */     
/*  90 */     if (this.actualReceiverType.isBaseType()) {
/*  91 */       scope.problemReporter().javadocErrorNoMethodFor(this, this.actualReceiverType, this.argumentTypes, scope.getDeclarationModifiers());
/*  92 */       return null;
/*     */     } 
/*  94 */     this.binding = scope.getMethod(this.actualReceiverType, this.selector, this.argumentTypes, this);
/*  95 */     if (!this.binding.isValidBinding()) {
/*     */       
/*  97 */       TypeBinding enclosingTypeBinding = this.actualReceiverType;
/*  98 */       MethodBinding methodBinding = this.binding;
/*  99 */       while (!methodBinding.isValidBinding() && (enclosingTypeBinding.isMemberType() || enclosingTypeBinding.isLocalType())) {
/* 100 */         ReferenceBinding referenceBinding = enclosingTypeBinding.enclosingType();
/* 101 */         methodBinding = scope.getMethod((TypeBinding)referenceBinding, this.selector, this.argumentTypes, this);
/*     */       } 
/* 103 */       if (methodBinding.isValidBinding()) {
/* 104 */         this.binding = methodBinding;
/*     */       } else {
/*     */         
/* 107 */         enclosingTypeBinding = this.actualReceiverType;
/* 108 */         MethodBinding contructorBinding = this.binding;
/* 109 */         if (!contructorBinding.isValidBinding() && CharOperation.equals(this.selector, enclosingTypeBinding.shortReadableName())) {
/* 110 */           contructorBinding = scope.getConstructor((ReferenceBinding)enclosingTypeBinding, this.argumentTypes, this);
/*     */         }
/* 112 */         while (!contructorBinding.isValidBinding() && (enclosingTypeBinding.isMemberType() || enclosingTypeBinding.isLocalType())) {
/* 113 */           ReferenceBinding referenceBinding = enclosingTypeBinding.enclosingType();
/* 114 */           if (CharOperation.equals(this.selector, referenceBinding.shortReadableName())) {
/* 115 */             contructorBinding = scope.getConstructor(referenceBinding, this.argumentTypes, this);
/*     */           }
/*     */         } 
/* 118 */         if (contructorBinding.isValidBinding()) {
/* 119 */           this.binding = contructorBinding;
/*     */         }
/*     */       } 
/*     */     } 
/* 123 */     if (!this.binding.isValidBinding()) {
/*     */       MethodBinding closestMatch;
/* 125 */       switch (this.binding.problemId()) {
/*     */         case 3:
/*     */         case 5:
/*     */         case 6:
/*     */         case 7:
/* 130 */           closestMatch = ((ProblemMethodBinding)this.binding).closestMatch;
/* 131 */           if (closestMatch != null)
/* 132 */             this.binding = closestMatch; 
/*     */           break;
/*     */       } 
/*     */     } 
/* 136 */     if (!this.binding.isValidBinding()) {
/* 137 */       if (this.receiver.resolvedType instanceof org.eclipse.jdt.internal.compiler.lookup.ProblemReferenceBinding)
/*     */       {
/* 139 */         return null;
/*     */       }
/* 141 */       if (this.binding.declaringClass == null) {
/* 142 */         if (this.actualReceiverType instanceof ReferenceBinding) {
/* 143 */           this.binding.declaringClass = (ReferenceBinding)this.actualReceiverType;
/*     */         } else {
/* 145 */           scope.problemReporter().javadocErrorNoMethodFor(this, this.actualReceiverType, this.argumentTypes, scope.getDeclarationModifiers());
/* 146 */           return null;
/*     */         } 
/*     */       }
/* 149 */       scope.problemReporter().javadocInvalidMethod(this, this.binding, scope.getDeclarationModifiers());
/*     */       
/* 151 */       if (this.binding instanceof ProblemMethodBinding) {
/* 152 */         MethodBinding closestMatch = ((ProblemMethodBinding)this.binding).closestMatch;
/* 153 */         if (closestMatch != null) this.binding = closestMatch; 
/*     */       } 
/* 155 */       return this.resolvedType = (this.binding == null) ? null : this.binding.returnType;
/* 156 */     }  if (hasArgsTypeVar) {
/* 157 */       ProblemMethodBinding problemMethodBinding = new ProblemMethodBinding(this.binding, this.selector, this.argumentTypes, 1);
/* 158 */       scope.problemReporter().javadocInvalidMethod(this, (MethodBinding)problemMethodBinding, scope.getDeclarationModifiers());
/* 159 */     } else if (this.binding.isVarargs()) {
/* 160 */       int length = this.argumentTypes.length;
/* 161 */       if (this.binding.parameters.length != length || !this.argumentTypes[length - 1].isArrayType()) {
/* 162 */         ProblemMethodBinding problemMethodBinding = new ProblemMethodBinding(this.binding, this.selector, this.argumentTypes, 1);
/* 163 */         scope.problemReporter().javadocInvalidMethod(this, (MethodBinding)problemMethodBinding, scope.getDeclarationModifiers());
/*     */       } 
/*     */     } else {
/* 166 */       int length = this.argumentTypes.length;
/* 167 */       for (int i = 0; i < length; i++) {
/* 168 */         if (TypeBinding.notEquals(this.binding.parameters[i].erasure(), this.argumentTypes[i].erasure())) {
/* 169 */           ProblemMethodBinding problemMethodBinding = new ProblemMethodBinding(this.binding, this.selector, this.argumentTypes, 1);
/* 170 */           scope.problemReporter().javadocInvalidMethod(this, (MethodBinding)problemMethodBinding, scope.getDeclarationModifiers());
/*     */           break;
/*     */         } 
/*     */       } 
/*     */     } 
/* 175 */     if (isMethodUseDeprecated(this.binding, scope, true, this)) {
/* 176 */       scope.problemReporter().javadocDeprecatedMethod(this.binding, this, scope.getDeclarationModifiers());
/*     */     }
/*     */     
/* 179 */     return this.resolvedType = this.binding.returnType;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isSuperAccess() {
/* 184 */     return ((this.bits & 0x4000) != 0);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public StringBuffer printExpression(int indent, StringBuffer output) {
/* 190 */     if (this.receiver != null) {
/* 191 */       this.receiver.printExpression(0, output);
/*     */     }
/* 193 */     output.append('#').append(this.selector).append('(');
/* 194 */     if (this.arguments != null) {
/* 195 */       for (int i = 0; i < this.arguments.length; i++) {
/* 196 */         if (i > 0) output.append(", "); 
/* 197 */         this.arguments[i].printExpression(0, output);
/*     */       } 
/*     */     }
/* 200 */     return output.append(')');
/*     */   }
/*     */ 
/*     */   
/*     */   public TypeBinding resolveType(BlockScope scope) {
/* 205 */     return internalResolveType((Scope)scope);
/*     */   }
/*     */ 
/*     */   
/*     */   public TypeBinding resolveType(ClassScope scope) {
/* 210 */     return internalResolveType((Scope)scope);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void traverse(ASTVisitor visitor, BlockScope blockScope) {
/* 219 */     if (visitor.visit(this, blockScope)) {
/* 220 */       if (this.receiver != null) {
/* 221 */         this.receiver.traverse(visitor, blockScope);
/*     */       }
/* 223 */       if (this.arguments != null) {
/* 224 */         int argumentsLength = this.arguments.length;
/* 225 */         for (int i = 0; i < argumentsLength; i++)
/* 226 */           this.arguments[i].traverse(visitor, blockScope); 
/*     */       } 
/*     */     } 
/* 229 */     visitor.endVisit(this, blockScope);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void traverse(ASTVisitor visitor, ClassScope scope) {
/* 237 */     if (visitor.visit(this, scope)) {
/* 238 */       if (this.receiver != null) {
/* 239 */         this.receiver.traverse(visitor, scope);
/*     */       }
/* 241 */       if (this.arguments != null) {
/* 242 */         int argumentsLength = this.arguments.length;
/* 243 */         for (int i = 0; i < argumentsLength; i++)
/* 244 */           this.arguments[i].traverse(visitor, scope); 
/*     */       } 
/*     */     } 
/* 247 */     visitor.endVisit(this, scope);
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\ast\JavadocMessageSend.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */