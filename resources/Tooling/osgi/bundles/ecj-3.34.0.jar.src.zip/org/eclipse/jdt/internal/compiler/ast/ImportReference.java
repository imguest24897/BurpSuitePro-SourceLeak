/*     */ package org.eclipse.jdt.internal.compiler.ast;
/*     */ 
/*     */ import java.util.HashSet;
/*     */ import java.util.Set;
/*     */ import org.eclipse.jdt.internal.compiler.ASTVisitor;
/*     */ import org.eclipse.jdt.internal.compiler.impl.CompilerOptions;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.CompilationUnitScope;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.ModuleBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.PackageBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.SplitPackageBinding;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ImportReference
/*     */   extends ASTNode
/*     */ {
/*     */   public char[][] tokens;
/*     */   public long[] sourcePositions;
/*     */   public int declarationEnd;
/*     */   public int declarationSourceStart;
/*     */   public int declarationSourceEnd;
/*     */   public int modifiers;
/*     */   public Annotation[] annotations;
/*     */   public int trailingStarPosition;
/*     */   
/*     */   public ImportReference(char[][] tokens, long[] sourcePositions, boolean onDemand, int modifiers) {
/*  42 */     this.tokens = tokens;
/*  43 */     this.sourcePositions = sourcePositions;
/*  44 */     if (onDemand) {
/*  45 */       this.bits |= 0x20000;
/*     */     }
/*  47 */     this.sourceEnd = (int)(sourcePositions[sourcePositions.length - 1] & 0xFFFFFFFFFFFFFFFFL);
/*  48 */     this.sourceStart = (int)(sourcePositions[0] >>> 32L);
/*  49 */     this.modifiers = modifiers;
/*     */   }
/*     */   
/*     */   public boolean isStatic() {
/*  53 */     return ((this.modifiers & 0x8) != 0);
/*     */   }
/*     */   
/*     */   public char[][] getImportName() {
/*  57 */     return this.tokens;
/*     */   }
/*     */   
/*     */   public char[] getSimpleName() {
/*  61 */     return this.tokens[this.tokens.length - 1];
/*     */   }
/*     */   
/*     */   public void checkPackageConflict(CompilationUnitScope scope) {
/*  65 */     ModuleBinding module = scope.module();
/*  66 */     PackageBinding visiblePackage = module.getVisiblePackage(this.tokens);
/*  67 */     if (visiblePackage instanceof SplitPackageBinding) {
/*  68 */       Set<ModuleBinding> declaringMods = new HashSet<>();
/*  69 */       for (PackageBinding incarnation : ((SplitPackageBinding)visiblePackage).incarnations) {
/*  70 */         if (incarnation.enclosingModule != module && module.canAccess(incarnation))
/*  71 */           declaringMods.add(incarnation.enclosingModule); 
/*     */       } 
/*  73 */       if (!declaringMods.isEmpty()) {
/*  74 */         CompilerOptions compilerOptions = scope.compilerOptions();
/*  75 */         boolean inJdtDebugCompileMode = compilerOptions.enableJdtDebugCompileMode;
/*  76 */         if (!inJdtDebugCompileMode) {
/*  77 */           scope.problemReporter().conflictingPackagesFromOtherModules(this, declaringMods);
/*     */         }
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public StringBuffer print(int indent, StringBuffer output) {
/*  86 */     return print(indent, output, true);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public StringBuffer print(int tab, StringBuffer output, boolean withOnDemand) {
/*  92 */     for (int i = 0; i < this.tokens.length; i++) {
/*  93 */       if (i > 0) output.append('.'); 
/*  94 */       output.append(this.tokens[i]);
/*     */     } 
/*  96 */     if (withOnDemand && (this.bits & 0x20000) != 0) {
/*  97 */       output.append(".*");
/*     */     }
/*  99 */     return output;
/*     */   }
/*     */ 
/*     */   
/*     */   public void traverse(ASTVisitor visitor, CompilationUnitScope scope) {
/* 104 */     visitor.visit(this, scope);
/* 105 */     visitor.endVisit(this, scope);
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\ast\ImportReference.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */