/*    */ package org.eclipse.jdt.internal.compiler.flow;
/*    */ 
/*    */ import org.eclipse.jdt.internal.compiler.ast.ASTNode;
/*    */ import org.eclipse.jdt.internal.compiler.ast.SubRoutineStatement;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class InsideSubRoutineFlowContext
/*    */   extends TryFlowContext
/*    */ {
/*    */   public UnconditionalFlowInfo initsOnReturn;
/*    */   
/*    */   public InsideSubRoutineFlowContext(FlowContext parent, ASTNode associatedNode) {
/* 30 */     super(parent, associatedNode);
/* 31 */     this.initsOnReturn = FlowInfo.DEAD_END;
/*    */   }
/*    */ 
/*    */   
/*    */   public String individualToString() {
/* 36 */     StringBuilder buffer = new StringBuilder("Inside SubRoutine flow context");
/* 37 */     buffer.append("[initsOnReturn -").append(this.initsOnReturn.toString()).append(']');
/* 38 */     return buffer.toString();
/*    */   }
/*    */ 
/*    */   
/*    */   public UnconditionalFlowInfo initsOnReturn() {
/* 43 */     return this.initsOnReturn;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean isNonReturningContext() {
/* 48 */     return ((SubRoutineStatement)this.associatedNode).isSubRoutineEscaping();
/*    */   }
/*    */ 
/*    */   
/*    */   public void recordReturnFrom(UnconditionalFlowInfo flowInfo) {
/* 53 */     if ((flowInfo.tagBits & 0x1) == 0) {
/* 54 */       if (this.initsOnReturn == FlowInfo.DEAD_END) {
/* 55 */         this.initsOnReturn = (UnconditionalFlowInfo)flowInfo.copy();
/*    */       } else {
/* 57 */         this.initsOnReturn = this.initsOnReturn.mergedWith(flowInfo);
/*    */       } 
/*    */     }
/*    */   }
/*    */ 
/*    */   
/*    */   public SubRoutineStatement subroutine() {
/* 64 */     return (SubRoutineStatement)this.associatedNode;
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\flow\InsideSubRoutineFlowContext.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */