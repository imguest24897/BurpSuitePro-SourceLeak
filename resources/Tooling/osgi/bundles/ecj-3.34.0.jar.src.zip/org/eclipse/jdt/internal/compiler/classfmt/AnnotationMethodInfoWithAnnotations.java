/*    */ package org.eclipse.jdt.internal.compiler.classfmt;
/*    */ 
/*    */ import org.eclipse.jdt.internal.compiler.env.IBinaryAnnotation;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AnnotationMethodInfoWithAnnotations
/*    */   extends AnnotationMethodInfo
/*    */ {
/*    */   private AnnotationInfo[] annotations;
/*    */   
/*    */   AnnotationMethodInfoWithAnnotations(MethodInfo methodInfo, Object defaultValue, AnnotationInfo[] annotations) {
/* 22 */     super(methodInfo, defaultValue);
/* 23 */     this.annotations = annotations;
/*    */   }
/*    */   
/*    */   public IBinaryAnnotation[] getAnnotations() {
/* 27 */     return (IBinaryAnnotation[])this.annotations;
/*    */   }
/*    */   
/*    */   protected void initialize() {
/* 31 */     for (int i = 0, l = (this.annotations == null) ? 0 : this.annotations.length; i < l; i++) {
/* 32 */       if (this.annotations[i] != null)
/* 33 */         this.annotations[i].initialize(); 
/* 34 */     }  super.initialize();
/*    */   }
/*    */   
/*    */   protected void reset() {
/* 38 */     for (int i = 0, l = (this.annotations == null) ? 0 : this.annotations.length; i < l; i++) {
/* 39 */       if (this.annotations[i] != null)
/* 40 */         this.annotations[i].reset(); 
/* 41 */     }  super.reset();
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\classfmt\AnnotationMethodInfoWithAnnotations.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */