/*    */ package org.eclipse.jdt.internal.compiler.codegen;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class Label
/*    */ {
/*    */   public CodeStream codeStream;
/* 19 */   public int position = -1;
/*    */   
/*    */   public static final int POS_NOT_SET = -1;
/*    */ 
/*    */   
/*    */   public Label() {}
/*    */ 
/*    */   
/*    */   public Label(CodeStream codeStream) {
/* 28 */     this.codeStream = codeStream;
/*    */   }
/*    */   
/*    */   public abstract void place();
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\codegen\Label.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */