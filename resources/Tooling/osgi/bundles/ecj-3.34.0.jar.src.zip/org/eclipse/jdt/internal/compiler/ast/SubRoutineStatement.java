/*    */ package org.eclipse.jdt.internal.compiler.ast;
/*    */ 
/*    */ import org.eclipse.jdt.internal.compiler.codegen.CodeStream;
/*    */ import org.eclipse.jdt.internal.compiler.codegen.ExceptionLabel;
/*    */ import org.eclipse.jdt.internal.compiler.lookup.BlockScope;
/*    */ import org.eclipse.jdt.internal.compiler.lookup.LocalVariableBinding;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class SubRoutineStatement
/*    */   extends Statement
/*    */ {
/*    */   ExceptionLabel anyExceptionLabel;
/*    */   
/*    */   public static void reenterAllExceptionHandlers(SubRoutineStatement[] subroutines, int max, CodeStream codeStream) {
/* 27 */     if (subroutines == null)
/* 28 */       return;  if (max < 0) max = subroutines.length; 
/* 29 */     for (int i = 0; i < max; i++) {
/* 30 */       SubRoutineStatement sub = subroutines[i];
/* 31 */       sub.enterAnyExceptionHandler(codeStream);
/* 32 */       sub.enterDeclaredExceptionHandlers(codeStream);
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/* 37 */   protected SwitchExpression switchExpression = null;
/*    */ 
/*    */   
/*    */   public ExceptionLabel enterAnyExceptionHandler(CodeStream codeStream) {
/* 41 */     if (this.anyExceptionLabel == null) {
/* 42 */       this.anyExceptionLabel = new ExceptionLabel(codeStream, null);
/*    */     }
/* 44 */     this.anyExceptionLabel.placeStart();
/* 45 */     return this.anyExceptionLabel;
/*    */   }
/*    */ 
/*    */   
/*    */   public void enterDeclaredExceptionHandlers(CodeStream codeStream) {}
/*    */ 
/*    */   
/*    */   public void exitAnyExceptionHandler() {
/* 53 */     if (this.anyExceptionLabel != null) {
/* 54 */       this.anyExceptionLabel.placeEnd();
/*    */     }
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void exitDeclaredExceptionHandlers(CodeStream codeStream) {}
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public abstract boolean generateSubRoutineInvocation(BlockScope paramBlockScope, CodeStream paramCodeStream, Object paramObject, int paramInt, LocalVariableBinding paramLocalVariableBinding);
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public abstract boolean isSubRoutineEscaping();
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void placeAllAnyExceptionHandler() {
/* 77 */     this.anyExceptionLabel.place();
/*    */   }
/*    */   
/*    */   public SwitchExpression getSwitchExpression() {
/* 81 */     return this.switchExpression;
/*    */   }
/*    */   
/*    */   public void setSwitchExpression(SwitchExpression switchExpression) {
/* 85 */     this.switchExpression = switchExpression;
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\ast\SubRoutineStatement.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */