/*     */ package org.eclipse.jdt.internal.compiler.codegen;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.LocalVariableBinding;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BranchLabel
/*     */   extends Label
/*     */ {
/*  23 */   private int[] forwardReferences = new int[10];
/*  24 */   private int forwardReferenceCount = 0;
/*     */ 
/*     */   
/*     */   BranchLabel delegate;
/*     */   
/*     */   public int tagBits;
/*     */   
/*     */   public static final int WIDE = 1;
/*     */   
/*     */   public static final int USED = 2;
/*     */ 
/*     */   
/*     */   public BranchLabel() {}
/*     */ 
/*     */   
/*     */   public BranchLabel(CodeStream codeStream) {
/*  40 */     super(codeStream);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void addForwardReference(int pos) {
/*  47 */     if (this.delegate != null) {
/*  48 */       this.delegate.addForwardReference(pos);
/*     */       return;
/*     */     } 
/*  51 */     int count = this.forwardReferenceCount;
/*  52 */     if (count >= 1) {
/*  53 */       int previousValue = this.forwardReferences[count - 1];
/*  54 */       if (previousValue < pos) {
/*     */         int length;
/*  56 */         if (count >= (length = this.forwardReferences.length))
/*  57 */           System.arraycopy(this.forwardReferences, 0, this.forwardReferences = new int[2 * length], 0, length); 
/*  58 */         this.forwardReferences[this.forwardReferenceCount++] = pos;
/*  59 */       } else if (previousValue > pos) {
/*  60 */         int[] refs = this.forwardReferences;
/*     */         
/*  62 */         for (int i = 0, max = this.forwardReferenceCount; i < max; i++) {
/*  63 */           if (refs[i] == pos)
/*     */             return; 
/*     */         }  int length;
/*  66 */         if (count >= (length = refs.length))
/*  67 */           System.arraycopy(refs, 0, this.forwardReferences = new int[2 * length], 0, length); 
/*  68 */         this.forwardReferences[this.forwardReferenceCount++] = pos;
/*  69 */         Arrays.sort(this.forwardReferences, 0, this.forwardReferenceCount);
/*     */       } 
/*     */     } else {
/*     */       int length;
/*  73 */       if (count >= (length = this.forwardReferences.length))
/*  74 */         System.arraycopy(this.forwardReferences, 0, this.forwardReferences = new int[2 * length], 0, length); 
/*  75 */       this.forwardReferences[this.forwardReferenceCount++] = pos;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void becomeDelegateFor(BranchLabel otherLabel) {
/*  84 */     otherLabel.delegate = this;
/*     */ 
/*     */     
/*  87 */     int otherCount = otherLabel.forwardReferenceCount;
/*  88 */     if (otherCount == 0)
/*     */       return; 
/*  90 */     int[] mergedForwardReferences = new int[this.forwardReferenceCount + otherCount];
/*  91 */     int indexInMerge = 0;
/*  92 */     int j = 0;
/*  93 */     int i = 0;
/*  94 */     int max = this.forwardReferenceCount;
/*  95 */     int max2 = otherLabel.forwardReferenceCount;
/*  96 */     for (; i < max; i++) {
/*  97 */       int value1 = this.forwardReferences[i]; while (true) {
/*  98 */         if (j >= max2)
/*     */         
/*     */         { 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 111 */           mergedForwardReferences[indexInMerge++] = value1; break; }  int value2 = otherLabel.forwardReferences[j]; if (value1 < value2) { mergedForwardReferences[indexInMerge++] = value1; break; }  if (value1 == value2) { mergedForwardReferences[indexInMerge++] = value1; j++; break; }  mergedForwardReferences[indexInMerge++] = value2; j++;
/*     */       } 
/* 113 */     }  for (; j < max2; j++) {
/* 114 */       mergedForwardReferences[indexInMerge++] = otherLabel.forwardReferences[j];
/*     */     }
/* 116 */     this.forwardReferences = mergedForwardReferences;
/* 117 */     this.forwardReferenceCount = indexInMerge;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void branch() {
/* 124 */     this.tagBits |= 0x2;
/* 125 */     if (this.delegate != null) {
/* 126 */       this.delegate.branch();
/*     */       return;
/*     */     } 
/* 129 */     if (this.position == -1) {
/* 130 */       addForwardReference(this.codeStream.position);
/*     */       
/* 132 */       this.codeStream.position += 2;
/* 133 */       this.codeStream.classFileOffset += 2;
/*     */     
/*     */     }
/*     */     else {
/*     */       
/* 138 */       this.codeStream.writePosition(this);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void branchWide() {
/* 146 */     this.tagBits |= 0x2;
/* 147 */     if (this.delegate != null) {
/* 148 */       this.delegate.branchWide();
/*     */       return;
/*     */     } 
/* 151 */     if (this.position == -1) {
/* 152 */       addForwardReference(this.codeStream.position);
/*     */       
/* 154 */       this.tagBits |= 0x1;
/* 155 */       this.codeStream.position += 4;
/* 156 */       this.codeStream.classFileOffset += 4;
/*     */     } else {
/* 158 */       this.codeStream.writeWidePosition(this);
/*     */     } 
/*     */   }
/*     */   
/*     */   public int forwardReferenceCount() {
/* 163 */     if (this.delegate != null) return this.delegate.forwardReferenceCount(); 
/* 164 */     return this.forwardReferenceCount;
/*     */   }
/*     */   public int[] forwardReferences() {
/* 167 */     if (this.delegate != null) return this.delegate.forwardReferences(); 
/* 168 */     return this.forwardReferences;
/*     */   }
/*     */   public void initialize(CodeStream stream) {
/* 171 */     this.codeStream = stream;
/* 172 */     this.position = -1;
/* 173 */     this.forwardReferenceCount = 0;
/* 174 */     this.delegate = null;
/*     */   }
/*     */   public boolean isCaseLabel() {
/* 177 */     return false;
/*     */   }
/*     */   public boolean isStandardLabel() {
/* 180 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void place() {
/* 193 */     if (this.position == -1) {
/* 194 */       this.position = this.codeStream.position;
/* 195 */       this.codeStream.addLabel(this);
/* 196 */       int oldPosition = this.position;
/* 197 */       boolean isOptimizedBranch = false;
/* 198 */       if (this.forwardReferenceCount != 0) {
/* 199 */         isOptimizedBranch = (this.forwardReferences[this.forwardReferenceCount - 1] + 2 == this.position && this.codeStream.bCodeStream[this.codeStream.classFileOffset - 3] == -89);
/* 200 */         if (isOptimizedBranch) {
/* 201 */           if (this.codeStream.lastAbruptCompletion == this.position) {
/* 202 */             this.codeStream.lastAbruptCompletion = -1;
/*     */           }
/* 204 */           this.codeStream.position = this.position -= 3;
/* 205 */           this.codeStream.classFileOffset -= 3;
/* 206 */           this.forwardReferenceCount--;
/* 207 */           if (this.codeStream.lastEntryPC == oldPosition) {
/* 208 */             this.codeStream.lastEntryPC = this.position;
/*     */           }
/*     */           
/* 211 */           if ((this.codeStream.generateAttributes & 0x1C) != 0) {
/* 212 */             LocalVariableBinding[] locals = this.codeStream.locals;
/* 213 */             for (int j = 0, max = locals.length; j < max; j++) {
/* 214 */               LocalVariableBinding local = locals[j];
/* 215 */               if (local != null && local.initializationCount > 0) {
/* 216 */                 if (local.initializationPCs[(local.initializationCount - 1 << 1) + 1] == oldPosition)
/*     */                 {
/*     */                   
/* 219 */                   local.initializationPCs[(local.initializationCount - 1 << 1) + 1] = this.position;
/*     */                 }
/* 221 */                 if (local.initializationPCs[local.initializationCount - 1 << 1] == oldPosition) {
/* 222 */                   local.initializationPCs[local.initializationCount - 1 << 1] = this.position;
/*     */                 }
/*     */               } 
/*     */             } 
/*     */           } 
/* 227 */           if ((this.codeStream.generateAttributes & 0x2) != 0)
/*     */           {
/* 229 */             this.codeStream.removeUnusedPcToSourceMapEntries();
/*     */           }
/*     */         } 
/*     */       } 
/* 233 */       for (int i = 0; i < this.forwardReferenceCount; i++) {
/* 234 */         this.codeStream.writePosition(this, this.forwardReferences[i]);
/*     */       }
/*     */ 
/*     */ 
/*     */       
/* 239 */       if (isOptimizedBranch) {
/* 240 */         this.codeStream.optimizeBranch(oldPosition, this);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 250 */     String basic = getClass().getName();
/* 251 */     basic = basic.substring(basic.lastIndexOf('.') + 1);
/* 252 */     StringBuilder buffer = new StringBuilder(basic);
/* 253 */     buffer.append('@').append(Integer.toHexString(hashCode()));
/* 254 */     buffer.append("(position=").append(this.position);
/* 255 */     if (this.delegate != null) buffer.append("delegate=").append(this.delegate); 
/* 256 */     buffer.append(", forwards = [");
/* 257 */     for (int i = 0; i < this.forwardReferenceCount - 1; i++)
/* 258 */       buffer.append(String.valueOf(this.forwardReferences[i]) + ", "); 
/* 259 */     if (this.forwardReferenceCount >= 1)
/* 260 */       buffer.append(this.forwardReferences[this.forwardReferenceCount - 1]); 
/* 261 */     buffer.append("] )");
/* 262 */     return buffer.toString();
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\codegen\BranchLabel.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */