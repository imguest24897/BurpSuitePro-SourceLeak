/*      */ package org.eclipse.jdt.core.compiler;
/*      */ 
/*      */ import java.util.Arrays;
/*      */ import java.util.List;
/*      */ import org.eclipse.jdt.internal.compiler.parser.ScannerHelper;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public final class CharOperation
/*      */ {
/*   35 */   public static final char[] NO_CHAR = new char[0];
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*   40 */   public static final char[][] NO_CHAR_CHAR = new char[0][];
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*   46 */   public static final String[] NO_STRINGS = new String[0];
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*   52 */   public static final char[] ALL_PREFIX = new char[] { '*' };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*   58 */   public static final char[] COMMA_SEPARATOR = new char[] { ',' };
/*      */   
/*   60 */   private static final int[] EMPTY_REGIONS = new int[0];
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final char[] append(char[] array, char suffix) {
/*   86 */     if (array == null)
/*   87 */       return new char[] { suffix }; 
/*   88 */     int length = array.length;
/*   89 */     System.arraycopy(array, 0, array = new char[length + 1], 0, length);
/*   90 */     array[length] = suffix;
/*   91 */     return array;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final char[] append(char[] target, char[] suffix) {
/*  120 */     if (suffix == null || suffix.length == 0)
/*  121 */       return target; 
/*  122 */     int targetLength = target.length;
/*  123 */     int subLength = suffix.length;
/*  124 */     int newTargetLength = targetLength + subLength;
/*  125 */     if (newTargetLength > targetLength) {
/*  126 */       System.arraycopy(target, 0, target = new char[newTargetLength], 0, targetLength);
/*      */     }
/*  128 */     System.arraycopy(suffix, 0, target, targetLength, subLength);
/*  129 */     return target;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final char[] append(char[] target, int index, char[] array, int start, int end) {
/*  176 */     int targetLength = target.length;
/*  177 */     int subLength = end - start;
/*  178 */     int newTargetLength = subLength + index;
/*  179 */     if (newTargetLength > targetLength) {
/*  180 */       System.arraycopy(target, 0, target = new char[newTargetLength * 2], 0, index);
/*      */     }
/*  182 */     System.arraycopy(array, start, target, index, subLength);
/*  183 */     return target;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final char[] prepend(char prefix, char[] array) {
/*  211 */     if (array == null)
/*  212 */       return new char[] { prefix }; 
/*  213 */     int length = array.length;
/*  214 */     System.arraycopy(array, 0, array = new char[length + 1], 1, length);
/*  215 */     array[0] = prefix;
/*  216 */     return array;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final char[][] arrayConcat(char[][] first, char[][] second) {
/*  258 */     if (first == null)
/*  259 */       return second; 
/*  260 */     if (second == null) {
/*  261 */       return first;
/*      */     }
/*  263 */     int length1 = first.length;
/*  264 */     int length2 = second.length;
/*  265 */     char[][] result = new char[length1 + length2][];
/*  266 */     System.arraycopy(first, 0, result, 0, length1);
/*  267 */     System.arraycopy(second, 0, result, length1, length2);
/*  268 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final boolean camelCaseMatch(char[] pattern, char[] name) {
/*  332 */     if (pattern == null)
/*  333 */       return true; 
/*  334 */     if (name == null) {
/*  335 */       return false;
/*      */     }
/*  337 */     return camelCaseMatch(pattern, 0, pattern.length, name, 0, name.length, false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final boolean camelCaseMatch(char[] pattern, char[] name, boolean samePartCount) {
/*  410 */     if (pattern == null)
/*  411 */       return true; 
/*  412 */     if (name == null) {
/*  413 */       return false;
/*      */     }
/*  415 */     return camelCaseMatch(pattern, 0, pattern.length, name, 0, name.length, samePartCount);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final boolean camelCaseMatch(char[] pattern, int patternStart, int patternEnd, char[] name, int nameStart, int nameEnd) {
/*  517 */     return camelCaseMatch(pattern, patternStart, patternEnd, name, nameStart, nameEnd, false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final boolean camelCaseMatch(char[] pattern, int patternStart, int patternEnd, char[] name, int nameStart, int nameEnd, boolean samePartCount) {
/*  636 */     if (name == null)
/*  637 */       return false; 
/*  638 */     if (pattern == null)
/*  639 */       return true; 
/*  640 */     if (patternEnd < 0) patternEnd = pattern.length; 
/*  641 */     if (nameEnd < 0) nameEnd = name.length;
/*      */     
/*  643 */     if (patternEnd <= patternStart) return (nameEnd <= nameStart); 
/*  644 */     if (nameEnd <= nameStart) return false;
/*      */     
/*  646 */     if (name[nameStart] != pattern[patternStart])
/*      */     {
/*  648 */       return false;
/*      */     }
/*      */ 
/*      */     
/*  652 */     int iPattern = patternStart;
/*  653 */     int iName = nameStart;
/*      */     
/*      */     label77: while (true) {
/*      */       char nameChar;
/*      */       
/*  658 */       iPattern++;
/*  659 */       iName++;
/*      */       
/*  661 */       if (iPattern == patternEnd) {
/*      */         
/*  663 */         if (!samePartCount || iName == nameEnd) return true;
/*      */ 
/*      */         
/*      */         while (true) {
/*  667 */           if (iName == nameEnd)
/*      */           {
/*  669 */             return true;
/*      */           }
/*  671 */           nameChar = name[iName];
/*      */           
/*  673 */           if (nameChar < '') {
/*  674 */             if ((ScannerHelper.OBVIOUS_IDENT_CHAR_NATURES[nameChar] & 0x20) != 0) {
/*  675 */               return false;
/*      */             }
/*      */           }
/*  678 */           else if (!Character.isJavaIdentifierPart(nameChar) || Character.isUpperCase(nameChar)) {
/*  679 */             return false;
/*      */           } 
/*  681 */           iName++;
/*      */         } 
/*      */         break;
/*      */       } 
/*  685 */       if (iName == nameEnd)
/*      */       {
/*  687 */         return false;
/*      */       }
/*      */       
/*      */       char patternChar;
/*  691 */       if ((patternChar = pattern[iPattern]) == name[iName]) {
/*      */         continue;
/*      */       }
/*      */ 
/*      */       
/*  696 */       if (patternChar < '') {
/*  697 */         if ((ScannerHelper.OBVIOUS_IDENT_CHAR_NATURES[patternChar] & 0x24) == 0) {
/*  698 */           return false;
/*      */         }
/*      */       }
/*  701 */       else if (Character.isJavaIdentifierPart(patternChar) && !Character.isUpperCase(patternChar) && !Character.isDigit(patternChar)) {
/*  702 */         return false;
/*      */       } 
/*      */ 
/*      */       
/*      */       while (true) {
/*  707 */         if (iName == nameEnd)
/*      */         {
/*  709 */           return false;
/*      */         }
/*      */         
/*  712 */         nameChar = name[iName];
/*  713 */         if (nameChar < '') {
/*  714 */           int charNature = ScannerHelper.OBVIOUS_IDENT_CHAR_NATURES[nameChar];
/*  715 */           if ((charNature & 0x90) != 0) {
/*      */             
/*  717 */             iName++; continue;
/*  718 */           }  if ((charNature & 0x4) != 0) {
/*      */             
/*  720 */             if (patternChar == nameChar)
/*  721 */               continue label77;  iName++; continue;
/*      */           } 
/*  723 */           if (patternChar != nameChar)
/*      */           {
/*  725 */             return false;
/*      */           }
/*      */ 
/*      */           
/*      */           continue label77;
/*      */         } 
/*      */         
/*  732 */         if (Character.isJavaIdentifierPart(nameChar) && !Character.isUpperCase(nameChar)) {
/*  733 */           iName++; continue;
/*  734 */         }  if (Character.isDigit(nameChar))
/*  735 */         { if (patternChar == nameChar)
/*  736 */             continue label77;  iName++; continue; }  break;
/*  737 */       }  if (patternChar != nameChar) {
/*  738 */         return false;
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final boolean subWordMatch(char[] pattern, char[] name) {
/*  758 */     if (name == null)
/*  759 */       return false; 
/*  760 */     if (pattern == null) {
/*  761 */       return true;
/*      */     }
/*  763 */     int[] matchingRegions = getSubWordMatchingRegions(new String(pattern), new String(name));
/*  764 */     return (matchingRegions != null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int[] getSubWordMatchingRegions(String pattern, String name) {
/*  802 */     if (name == null)
/*  803 */       return null; 
/*  804 */     if (pattern == null)
/*      */     {
/*      */       
/*  807 */       return EMPTY_REGIONS;
/*      */     }
/*      */     
/*  810 */     return (new SubwordMatcher(name)).getMatchingRegions(pattern);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final boolean substringMatch(String pattern, String name) {
/*  823 */     if (pattern == null || pattern.length() == 0) {
/*  824 */       return true;
/*      */     }
/*  826 */     if (name == null) {
/*  827 */       return false;
/*      */     }
/*  829 */     return checkSubstringMatch(pattern.toCharArray(), name.toCharArray());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final boolean substringMatch(char[] pattern, char[] name) {
/*  842 */     if (pattern == null || pattern.length == 0) {
/*  843 */       return true;
/*      */     }
/*  845 */     if (name == null) {
/*  846 */       return false;
/*      */     }
/*  848 */     return checkSubstringMatch(pattern, name);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final boolean checkSubstringMatch(char[] pattern, char[] name) {
/*  882 */     for (int nidx = 0; nidx < name.length - pattern.length + 1; nidx++) {
/*      */       
/*  884 */       for (int pidx = 0; pidx < pattern.length; pidx++) {
/*  885 */         if (Character.toLowerCase(name[nidx + pidx]) != 
/*  886 */           Character.toLowerCase(pattern[pidx])) {
/*      */           
/*  888 */           if (name[nidx + pidx] == '(' || name[nidx + pidx] == ':')
/*  889 */             return false; 
/*      */           break;
/*      */         } 
/*  892 */         if (pidx == pattern.length - 1) {
/*  893 */           return true;
/*      */         }
/*      */       } 
/*      */     } 
/*      */     
/*  898 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String[] charArrayToStringArray(char[][] charArrays) {
/*  909 */     if (charArrays == null)
/*  910 */       return null; 
/*  911 */     int length = charArrays.length;
/*  912 */     if (length == 0)
/*  913 */       return NO_STRINGS; 
/*  914 */     String[] strings = new String[length];
/*  915 */     for (int i = 0; i < length; i++)
/*  916 */       strings[i] = new String(charArrays[i]); 
/*  917 */     return strings;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String charToString(char[] charArray) {
/*  928 */     if (charArray == null) return null; 
/*  929 */     return new String(charArray);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static char[][] toCharArrays(List<String> stringList) {
/*  941 */     if (stringList == null)
/*  942 */       return null; 
/*  943 */     char[][] result = new char[stringList.size()][];
/*  944 */     for (int i = 0; i < result.length; i++)
/*  945 */       result[i] = ((String)stringList.get(i)).toCharArray(); 
/*  946 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final char[][] arrayConcat(char[][] first, char[] second) {
/*  981 */     if (second == null)
/*  982 */       return first; 
/*  983 */     if (first == null) {
/*  984 */       return new char[][] { second };
/*      */     }
/*  986 */     int length = first.length;
/*  987 */     char[][] result = new char[length + 1][];
/*  988 */     System.arraycopy(first, 0, result, 0, length);
/*  989 */     result[length] = second;
/*  990 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int compareTo(char[] array1, char[] array2) {
/* 1006 */     int length1 = array1.length;
/* 1007 */     int length2 = array2.length;
/* 1008 */     int min = Math.min(length1, length2);
/* 1009 */     for (int i = 0; i < min; i++) {
/* 1010 */       if (array1[i] != array2[i]) {
/* 1011 */         return array1[i] - array2[i];
/*      */       }
/*      */     } 
/* 1014 */     return length1 - length2;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int compareTo(char[] array1, char[] array2, int start, int end) {
/* 1034 */     int length1 = array1.length;
/* 1035 */     int length2 = array2.length;
/* 1036 */     int min = Math.min(length1, length2);
/* 1037 */     min = Math.min(min, end);
/* 1038 */     for (int i = start; i < min; i++) {
/* 1039 */       if (array1[i] != array2[i]) {
/* 1040 */         return array1[i] - array2[i];
/*      */       }
/*      */     } 
/* 1043 */     return length1 - length2;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int compareWith(char[] array, char[] prefix) {
/* 1100 */     int arrayLength = array.length;
/* 1101 */     int prefixLength = prefix.length;
/* 1102 */     int min = Math.min(arrayLength, prefixLength);
/* 1103 */     int i = 0;
/* 1104 */     while (min-- != 0) {
/* 1105 */       char c1 = array[i];
/* 1106 */       char c2 = prefix[i++];
/* 1107 */       if (c1 != c2)
/* 1108 */         return c1 - c2; 
/*      */     } 
/* 1110 */     if (prefixLength == i)
/* 1111 */       return 0; 
/* 1112 */     return -1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final char[] concat(char[] first, char[] second) {
/* 1148 */     if (first == null)
/* 1149 */       return second; 
/* 1150 */     if (second == null) {
/* 1151 */       return first;
/*      */     }
/* 1153 */     int length1 = first.length;
/* 1154 */     int length2 = second.length;
/* 1155 */     char[] result = new char[length1 + length2];
/* 1156 */     System.arraycopy(first, 0, result, 0, length1);
/* 1157 */     System.arraycopy(second, 0, result, length1, length2);
/* 1158 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final char[] concat(char[] first, char[] second, char[] third) {
/* 1217 */     if (first == null)
/* 1218 */       return concat(second, third); 
/* 1219 */     if (second == null)
/* 1220 */       return concat(first, third); 
/* 1221 */     if (third == null) {
/* 1222 */       return concat(first, second);
/*      */     }
/* 1224 */     int length1 = first.length;
/* 1225 */     int length2 = second.length;
/* 1226 */     int length3 = third.length;
/* 1227 */     char[] result = new char[length1 + length2 + length3];
/* 1228 */     System.arraycopy(first, 0, result, 0, length1);
/* 1229 */     System.arraycopy(second, 0, result, length1, length2);
/* 1230 */     System.arraycopy(third, 0, result, length1 + length2, length3);
/* 1231 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final char[] concat(char[] first, char[] second, char separator) {
/* 1276 */     if (first == null)
/* 1277 */       return second; 
/* 1278 */     if (second == null) {
/* 1279 */       return first;
/*      */     }
/* 1281 */     int length1 = first.length;
/* 1282 */     if (length1 == 0)
/* 1283 */       return second; 
/* 1284 */     int length2 = second.length;
/* 1285 */     if (length2 == 0) {
/* 1286 */       return first;
/*      */     }
/* 1288 */     char[] result = new char[length1 + length2 + 1];
/* 1289 */     System.arraycopy(first, 0, result, 0, length1);
/* 1290 */     result[length1] = separator;
/* 1291 */     System.arraycopy(second, 0, result, length1 + 1, length2);
/* 1292 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final char[] concatAll(char[] first, char[] second, char separator) {
/* 1348 */     if (first == null)
/* 1349 */       return second; 
/* 1350 */     if (second == null) {
/* 1351 */       return first;
/*      */     }
/* 1353 */     int length1 = first.length;
/* 1354 */     if (length1 == 0)
/* 1355 */       return second; 
/* 1356 */     int length2 = second.length;
/*      */     
/* 1358 */     char[] result = new char[length1 + length2 + 1];
/* 1359 */     System.arraycopy(first, 0, result, 0, length1);
/* 1360 */     result[length1] = separator;
/* 1361 */     if (length2 > 0)
/* 1362 */       System.arraycopy(second, 0, result, length1 + 1, length2); 
/* 1363 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final char[] concat(char[] first, char sep1, char[] second, char sep2, char[] third) {
/* 1432 */     if (first == null)
/* 1433 */       return concat(second, third, sep2); 
/* 1434 */     if (second == null)
/* 1435 */       return concat(first, third, sep1); 
/* 1436 */     if (third == null) {
/* 1437 */       return concat(first, second, sep1);
/*      */     }
/* 1439 */     int length1 = first.length;
/* 1440 */     int length2 = second.length;
/* 1441 */     int length3 = third.length;
/* 1442 */     char[] result = new char[length1 + length2 + length3 + 2];
/* 1443 */     System.arraycopy(first, 0, result, 0, length1);
/* 1444 */     result[length1] = sep1;
/* 1445 */     System.arraycopy(second, 0, result, length1 + 1, length2);
/* 1446 */     result[length1 + length2 + 1] = sep2;
/* 1447 */     System.arraycopy(third, 0, result, length1 + length2 + 2, length3);
/* 1448 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final char[] concatNonEmpty(char[] first, char[] second, char separator) {
/* 1501 */     if (first == null || first.length == 0)
/* 1502 */       return second; 
/* 1503 */     if (second == null || second.length == 0)
/* 1504 */       return first; 
/* 1505 */     return concat(first, second, separator);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final char[] concatNonEmpty(char[] first, char sep1, char[] second, char sep2, char[] third) {
/* 1583 */     if (first == null || first.length == 0)
/* 1584 */       return concatNonEmpty(second, third, sep2); 
/* 1585 */     if (second == null || second.length == 0)
/* 1586 */       return concatNonEmpty(first, third, sep1); 
/* 1587 */     if (third == null || third.length == 0) {
/* 1588 */       return concatNonEmpty(first, second, sep1);
/*      */     }
/* 1590 */     return concat(first, sep1, second, sep2, third);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final char[] concat(char prefix, char[] array, char suffix) {
/* 1622 */     if (array == null) {
/* 1623 */       return new char[] { prefix, suffix };
/*      */     }
/* 1625 */     int length = array.length;
/* 1626 */     char[] result = new char[length + 2];
/* 1627 */     result[0] = prefix;
/* 1628 */     System.arraycopy(array, 0, result, 1, length);
/* 1629 */     result[length + 1] = suffix;
/* 1630 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final char[] concatWith(char[] name, char[][] array, char separator) {
/* 1671 */     int nameLength = (name == null) ? 0 : name.length;
/* 1672 */     if (nameLength == 0) {
/* 1673 */       return concatWith(array, separator);
/*      */     }
/* 1675 */     int length = (array == null) ? 0 : array.length;
/* 1676 */     if (length == 0) {
/* 1677 */       return name;
/*      */     }
/* 1679 */     int size = nameLength;
/* 1680 */     int index = length;
/* 1681 */     while (--index >= 0) {
/* 1682 */       if ((array[index]).length > 0)
/* 1683 */         size += (array[index]).length + 1; 
/* 1684 */     }  char[] result = new char[size];
/* 1685 */     index = size;
/* 1686 */     for (int i = length - 1; i >= 0; i--) {
/* 1687 */       int subLength = (array[i]).length;
/* 1688 */       if (subLength > 0) {
/* 1689 */         index -= subLength;
/* 1690 */         System.arraycopy(array[i], 0, result, index, subLength);
/* 1691 */         result[--index] = separator;
/*      */       } 
/*      */     } 
/* 1694 */     System.arraycopy(name, 0, result, 0, nameLength);
/* 1695 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final char[] concatWith(char[][] array, char[] name, char separator) {
/* 1736 */     int nameLength = (name == null) ? 0 : name.length;
/* 1737 */     if (nameLength == 0) {
/* 1738 */       return concatWith(array, separator);
/*      */     }
/* 1740 */     int length = (array == null) ? 0 : array.length;
/* 1741 */     if (length == 0) {
/* 1742 */       return name;
/*      */     }
/* 1744 */     int size = nameLength;
/* 1745 */     int index = length;
/* 1746 */     while (--index >= 0) {
/* 1747 */       if ((array[index]).length > 0)
/* 1748 */         size += (array[index]).length + 1; 
/* 1749 */     }  char[] result = new char[size];
/* 1750 */     index = 0;
/* 1751 */     for (int i = 0; i < length; i++) {
/* 1752 */       int subLength = (array[i]).length;
/* 1753 */       if (subLength > 0) {
/* 1754 */         System.arraycopy(array[i], 0, result, index, subLength);
/* 1755 */         index += subLength;
/* 1756 */         result[index++] = separator;
/*      */       } 
/*      */     } 
/* 1759 */     System.arraycopy(name, 0, result, index, nameLength);
/* 1760 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final char[] concatWith(char[][] array, char separator) {
/* 1787 */     int length = (array == null) ? 0 : array.length;
/* 1788 */     if (length == 0) {
/* 1789 */       return NO_CHAR;
/*      */     }
/* 1791 */     int size = length - 1;
/* 1792 */     int index = length;
/* 1793 */     while (--index >= 0) {
/* 1794 */       if ((array[index]).length == 0) {
/* 1795 */         size--; continue;
/*      */       } 
/* 1797 */       size += (array[index]).length;
/*      */     } 
/* 1799 */     if (size <= 0)
/* 1800 */       return NO_CHAR; 
/* 1801 */     char[] result = new char[size];
/* 1802 */     index = length;
/* 1803 */     while (--index >= 0) {
/* 1804 */       length = (array[index]).length;
/* 1805 */       if (length > 0) {
/* 1806 */         System.arraycopy(
/* 1807 */             array[index], 
/* 1808 */             0, 
/* 1809 */             result, 
/* 1810 */             size -= length, 
/* 1811 */             length);
/* 1812 */         if (--size >= 0)
/* 1813 */           result[size] = separator; 
/*      */       } 
/*      */     } 
/* 1816 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final char[] concatWithAll(char[][] array, char separator) {
/* 1851 */     int length = (array == null) ? 0 : array.length;
/* 1852 */     if (length == 0) {
/* 1853 */       return NO_CHAR;
/*      */     }
/* 1855 */     int size = length - 1;
/* 1856 */     int index = length;
/* 1857 */     while (--index >= 0) {
/* 1858 */       size += (array[index]).length;
/*      */     }
/* 1860 */     char[] result = new char[size];
/* 1861 */     index = length;
/* 1862 */     while (--index >= 0) {
/* 1863 */       length = (array[index]).length;
/* 1864 */       if (length > 0) {
/* 1865 */         System.arraycopy(
/* 1866 */             array[index], 
/* 1867 */             0, 
/* 1868 */             result, 
/* 1869 */             size -= length, 
/* 1870 */             length);
/*      */       }
/* 1872 */       if (--size >= 0)
/* 1873 */         result[size] = separator; 
/*      */     } 
/* 1875 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final boolean contains(char character, char[][] array) {
/* 1905 */     for (int i = array.length; --i >= 0; ) {
/* 1906 */       char[] subarray = array[i];
/* 1907 */       for (int j = subarray.length; --j >= 0;) {
/* 1908 */         if (subarray[j] == character)
/* 1909 */           return true; 
/*      */       } 
/* 1911 */     }  return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final boolean contains(char character, char[] array) {
/* 1941 */     for (int i = array.length; --i >= 0;) {
/* 1942 */       if (array[i] == character)
/* 1943 */         return true; 
/* 1944 */     }  return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final boolean contains(char[] characters, char[] array) {
/* 1975 */     for (int i = array.length; --i >= 0;) {
/* 1976 */       for (int j = characters.length; --j >= 0;)
/* 1977 */       { if (array[i] == characters[j])
/* 1978 */           return true;  } 
/* 1979 */     }  return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean containsEqual(char[][] array, char[] sequence) {
/* 1990 */     for (int i = 0; i < array.length; i++) {
/* 1991 */       if (equals(array[i], sequence))
/* 1992 */         return true; 
/*      */     } 
/* 1994 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final char[][] deepCopy(char[][] toCopy) {
/* 2005 */     int toCopyLength = toCopy.length;
/* 2006 */     char[][] result = new char[toCopyLength][];
/* 2007 */     for (int i = 0; i < toCopyLength; i++) {
/* 2008 */       char[] toElement = toCopy[i];
/* 2009 */       int toElementLength = toElement.length;
/* 2010 */       char[] resultElement = new char[toElementLength];
/* 2011 */       System.arraycopy(toElement, 0, resultElement, 0, toElementLength);
/* 2012 */       result[i] = resultElement;
/*      */     } 
/* 2014 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final boolean endsWith(char[] array, char[] toBeFound) {
/* 2045 */     int i = toBeFound.length;
/* 2046 */     int j = array.length - i;
/*      */     
/* 2048 */     if (j < 0)
/* 2049 */       return false; 
/* 2050 */     while (--i >= 0) {
/* 2051 */       if (toBeFound[i] != array[i + j])
/* 2052 */         return false; 
/* 2053 */     }  return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final boolean equals(char[][] first, char[][] second) {
/* 2093 */     if (first == second)
/* 2094 */       return true; 
/* 2095 */     if (first == null || second == null)
/* 2096 */       return false; 
/* 2097 */     if (first.length != second.length) {
/* 2098 */       return false;
/*      */     }
/* 2100 */     for (int i = first.length; --i >= 0;) {
/* 2101 */       if (!equals(first[i], second[i]))
/* 2102 */         return false; 
/* 2103 */     }  return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final boolean equals(char[][] first, char[][] second, boolean isCaseSensitive) {
/* 2156 */     if (isCaseSensitive) {
/* 2157 */       return equals(first, second);
/*      */     }
/* 2159 */     if (first == second)
/* 2160 */       return true; 
/* 2161 */     if (first == null || second == null)
/* 2162 */       return false; 
/* 2163 */     if (first.length != second.length) {
/* 2164 */       return false;
/*      */     }
/* 2166 */     for (int i = first.length; --i >= 0;) {
/* 2167 */       if (!equals(first[i], second[i], false))
/* 2168 */         return false; 
/* 2169 */     }  return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final boolean equals(char[] first, char[] second) {
/* 2209 */     return Arrays.equals(first, second);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final boolean equals(char[] first, char[] second, int secondStart, int secondEnd) {
/* 2261 */     return equals(first, second, secondStart, secondEnd, true);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final boolean equals(char[] first, char[] second, int secondStart, int secondEnd, boolean isCaseSensitive) {
/* 2325 */     if (first == second)
/* 2326 */       return true; 
/* 2327 */     if (first == null || second == null)
/* 2328 */       return false; 
/* 2329 */     if (first.length != secondEnd - secondStart)
/* 2330 */       return false; 
/* 2331 */     if (isCaseSensitive)
/* 2332 */     { for (int i = first.length; --i >= 0;) {
/* 2333 */         if (first[i] != second[i + secondStart])
/* 2334 */           return false; 
/*      */       }  }
/* 2336 */     else { for (int i = first.length; --i >= 0;) {
/* 2337 */         if (ScannerHelper.toLowerCase(first[i]) != ScannerHelper.toLowerCase(second[i + secondStart]))
/* 2338 */           return false; 
/*      */       }  }
/* 2340 */      return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final boolean equals(char[] first, char[] second, boolean isCaseSensitive) {
/* 2393 */     if (isCaseSensitive) {
/* 2394 */       return equals(first, second);
/*      */     }
/* 2396 */     if (first == second)
/* 2397 */       return true; 
/* 2398 */     if (first == null || second == null)
/* 2399 */       return false; 
/* 2400 */     if (first.length != second.length) {
/* 2401 */       return false;
/*      */     }
/* 2403 */     for (int i = first.length; --i >= 0;) {
/* 2404 */       if (ScannerHelper.toLowerCase(first[i]) != 
/* 2405 */         ScannerHelper.toLowerCase(second[i]))
/* 2406 */         return false; 
/* 2407 */     }  return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final boolean fragmentEquals(char[] fragment, char[] name, int startIndex, boolean isCaseSensitive) {
/* 2466 */     int max = fragment.length;
/* 2467 */     if (name.length < max + startIndex)
/* 2468 */       return false; 
/* 2469 */     if (isCaseSensitive) {
/* 2470 */       for (int j = max; 
/* 2471 */         --j >= 0;) {
/*      */         
/* 2473 */         if (fragment[j] != name[j + startIndex])
/* 2474 */           return false; 
/* 2475 */       }  return true;
/*      */     } 
/* 2477 */     for (int i = max; 
/* 2478 */       --i >= 0;) {
/*      */       
/* 2480 */       if (ScannerHelper.toLowerCase(fragment[i]) != 
/* 2481 */         ScannerHelper.toLowerCase(name[i + startIndex]))
/* 2482 */         return false; 
/* 2483 */     }  return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int hashCode(char[] array) {
/* 2493 */     int hash = Arrays.hashCode(array);
/* 2494 */     return hash & Integer.MAX_VALUE;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isWhitespace(char c) {
/* 2519 */     return (c < '' && (ScannerHelper.OBVIOUS_IDENT_CHAR_NATURES[c] & 0x100) != 0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int indexOf(char toBeFound, char[] array) {
/* 2550 */     return indexOf(toBeFound, array, 0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int indexOf(char[] toBeFound, char[] array, boolean isCaseSensitive) {
/* 2583 */     return indexOf(toBeFound, array, isCaseSensitive, 0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int indexOf(char[] toBeFound, char[] array, boolean isCaseSensitive, int start) {
/* 2617 */     return indexOf(toBeFound, array, isCaseSensitive, start, array.length);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int indexOf(char[] toBeFound, char[] array, boolean isCaseSensitive, int start, int end) {
/* 2652 */     int arrayLength = end;
/* 2653 */     int toBeFoundLength = toBeFound.length;
/* 2654 */     if (toBeFoundLength > arrayLength || start < 0) return -1; 
/* 2655 */     if (toBeFoundLength == 0) return 0; 
/* 2656 */     if (toBeFoundLength == arrayLength) {
/* 2657 */       if (isCaseSensitive) {
/* 2658 */         for (int j = start; j < arrayLength; j++) {
/* 2659 */           if (array[j] != toBeFound[j]) return -1; 
/*      */         } 
/* 2661 */         return 0;
/*      */       } 
/* 2663 */       for (int i = start; i < arrayLength; i++) {
/* 2664 */         if (ScannerHelper.toLowerCase(array[i]) != ScannerHelper.toLowerCase(toBeFound[i])) return -1; 
/*      */       } 
/* 2666 */       return 0;
/*      */     } 
/*      */     
/* 2669 */     if (isCaseSensitive)
/* 2670 */     { for (int i = start, max = arrayLength - toBeFoundLength + 1; i < max; i++) {
/* 2671 */         if (array[i] == toBeFound[0]) {
/* 2672 */           int j = 1; while (true) { if (j >= toBeFoundLength)
/*      */             {
/*      */               
/* 2675 */               return i; }  if (array[i + j] != toBeFound[j])
/*      */               break;  j++; } 
/*      */         } 
/*      */       }  }
/* 2679 */     else { for (int i = start, max = arrayLength - toBeFoundLength + 1; i < max; i++) {
/* 2680 */         if (ScannerHelper.toLowerCase(array[i]) == ScannerHelper.toLowerCase(toBeFound[0])) {
/* 2681 */           int j = 1; while (true) { if (j >= toBeFoundLength)
/*      */             {
/*      */               
/* 2684 */               return i; }  if (ScannerHelper.toLowerCase(array[i + j]) != ScannerHelper.toLowerCase(toBeFound[j]))
/*      */               break;  j++; } 
/*      */         } 
/*      */       }  }
/* 2688 */      return -1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int indexOf(char toBeFound, char[] array, int start) {
/* 2731 */     for (int i = start; i < array.length; i++) {
/* 2732 */       if (toBeFound == array[i])
/* 2733 */         return i; 
/* 2734 */     }  return -1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int indexOf(char toBeFound, char[] array, int start, int end) {
/* 2779 */     for (int i = start; i < end; i++) {
/* 2780 */       if (toBeFound == array[i])
/* 2781 */         return i; 
/* 2782 */     }  return -1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int lastIndexOf(char toBeFound, char[] array) {
/* 2814 */     for (int i = array.length; --i >= 0;) {
/* 2815 */       if (toBeFound == array[i])
/* 2816 */         return i; 
/* 2817 */     }  return -1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int lastIndexOf(char toBeFound, char[] array, int startIndex) {
/* 2863 */     for (int i = array.length; --i >= startIndex;) {
/* 2864 */       if (toBeFound == array[i])
/* 2865 */         return i; 
/* 2866 */     }  return -1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int lastIndexOf(char toBeFound, char[] array, int startIndex, int endIndex) {
/* 2917 */     for (int i = endIndex; --i >= startIndex;) {
/* 2918 */       if (toBeFound == array[i])
/* 2919 */         return i; 
/* 2920 */     }  return -1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final char[] lastSegment(char[] array, char separator) {
/* 2938 */     int pos = lastIndexOf(separator, array);
/* 2939 */     if (pos < 0)
/* 2940 */       return array; 
/* 2941 */     return subarray(array, pos + 1, array.length);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final boolean match(char[] pattern, char[] name, boolean isCaseSensitive) {
/* 2988 */     if (name == null)
/* 2989 */       return false; 
/* 2990 */     if (pattern == null) {
/* 2991 */       return true;
/*      */     }
/* 2993 */     return match(
/* 2994 */         pattern, 
/* 2995 */         0, 
/* 2996 */         pattern.length, 
/* 2997 */         name, 
/* 2998 */         0, 
/* 2999 */         name.length, 
/* 3000 */         isCaseSensitive);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final boolean match(char[] pattern, int patternStart, int patternEnd, char[] name, int nameStart, int nameEnd, boolean isCaseSensitive) {
/*      */     int segmentStart;
/* 3056 */     if (name == null)
/* 3057 */       return false; 
/* 3058 */     if (pattern == null)
/* 3059 */       return true; 
/* 3060 */     int iPattern = patternStart;
/* 3061 */     int iName = nameStart;
/*      */     
/* 3063 */     if (patternEnd < 0)
/* 3064 */       patternEnd = pattern.length; 
/* 3065 */     if (nameEnd < 0) {
/* 3066 */       nameEnd = name.length;
/*      */     }
/*      */     
/* 3069 */     char patternChar = Character.MIN_VALUE;
/*      */     while (true) {
/* 3071 */       if (iPattern == patternEnd) {
/* 3072 */         if (iName == nameEnd) return true; 
/* 3073 */         return false;
/*      */       } 
/* 3075 */       if ((patternChar = pattern[iPattern]) == '*') {
/*      */         break;
/*      */       }
/* 3078 */       if (iName == nameEnd) {
/* 3079 */         return false;
/*      */       }
/* 3081 */       if (patternChar != (
/* 3082 */         isCaseSensitive ? 
/* 3083 */         name[iName] : 
/* 3084 */         ScannerHelper.toLowerCase(name[iName])))
/* 3085 */         if (patternChar != '?') {
/* 3086 */           return false;
/*      */         } 
/* 3088 */       iName++;
/* 3089 */       iPattern++;
/*      */     } 
/*      */ 
/*      */     
/* 3093 */     if (patternChar == '*') {
/* 3094 */       segmentStart = ++iPattern;
/*      */     } else {
/* 3096 */       segmentStart = 0;
/*      */     } 
/* 3098 */     int prefixStart = iName;
/* 3099 */     while (iName < nameEnd) {
/* 3100 */       if (iPattern == patternEnd) {
/* 3101 */         iPattern = segmentStart;
/* 3102 */         iName = ++prefixStart;
/*      */         
/*      */         continue;
/*      */       } 
/* 3106 */       if ((patternChar = pattern[iPattern]) == '*') {
/* 3107 */         segmentStart = ++iPattern;
/* 3108 */         if (segmentStart == patternEnd) {
/* 3109 */           return true;
/*      */         }
/* 3111 */         prefixStart = iName;
/*      */         
/*      */         continue;
/*      */       } 
/* 3115 */       if ((isCaseSensitive ? name[iName] : ScannerHelper.toLowerCase(name[iName])) != 
/* 3116 */         patternChar)
/* 3117 */         if (patternChar != '?') {
/* 3118 */           iPattern = segmentStart;
/* 3119 */           iName = ++prefixStart;
/*      */           continue;
/*      */         }  
/* 3122 */       iName++;
/* 3123 */       iPattern++;
/*      */     } 
/*      */     
/* 3126 */     return !(segmentStart != patternEnd && (
/* 3127 */       iName != nameEnd || iPattern != patternEnd) && (
/* 3128 */       iPattern != patternEnd - 1 || pattern[iPattern] != '*'));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final boolean pathMatch(char[] pattern, char[] filepath, boolean isCaseSensitive, char pathSeparator) {
/*      */     int fSegmentStart, pSegmentRestart;
/* 3155 */     if (filepath == null)
/* 3156 */       return false; 
/* 3157 */     if (pattern == null) {
/* 3158 */       return true;
/*      */     }
/*      */     
/* 3161 */     int pSegmentStart = (pattern[0] == pathSeparator) ? 1 : 0;
/* 3162 */     int pLength = pattern.length;
/* 3163 */     int pSegmentEnd = indexOf(pathSeparator, pattern, pSegmentStart + 1);
/* 3164 */     if (pSegmentEnd < 0) pSegmentEnd = pLength;
/*      */ 
/*      */     
/* 3167 */     boolean freeTrailingDoubleStar = (pattern[pLength - 1] == pathSeparator);
/*      */ 
/*      */     
/* 3170 */     int fLength = filepath.length;
/* 3171 */     if (filepath[0] != pathSeparator) {
/* 3172 */       fSegmentStart = 0;
/*      */     } else {
/* 3174 */       fSegmentStart = 1;
/*      */     } 
/* 3176 */     if (fSegmentStart != pSegmentStart) {
/* 3177 */       return false;
/*      */     }
/* 3179 */     int fSegmentEnd = indexOf(pathSeparator, filepath, fSegmentStart + 1);
/* 3180 */     if (fSegmentEnd < 0) fSegmentEnd = fLength;
/*      */ 
/*      */     
/* 3183 */     while (pSegmentStart < pLength && (
/* 3184 */       pSegmentEnd != pLength || !freeTrailingDoubleStar) && (
/* 3185 */       pSegmentEnd != pSegmentStart + 2 || 
/* 3186 */       pattern[pSegmentStart] != '*' || 
/* 3187 */       pattern[pSegmentStart + 1] != '*')) {
/*      */       
/* 3189 */       if (fSegmentStart >= fLength) {
/* 3190 */         return false;
/*      */       }
/* 3192 */       if (!match(
/* 3193 */           pattern, 
/* 3194 */           pSegmentStart, 
/* 3195 */           pSegmentEnd, 
/* 3196 */           filepath, 
/* 3197 */           fSegmentStart, 
/* 3198 */           fSegmentEnd, 
/* 3199 */           isCaseSensitive)) {
/* 3200 */         return false;
/*      */       }
/*      */ 
/*      */       
/* 3204 */       pSegmentEnd = 
/* 3205 */         indexOf(
/* 3206 */           pathSeparator, 
/* 3207 */           pattern, 
/* 3208 */           pSegmentStart = pSegmentEnd + 1);
/*      */       
/* 3210 */       if (pSegmentEnd < 0) {
/* 3211 */         pSegmentEnd = pLength;
/*      */       }
/* 3213 */       fSegmentEnd = 
/* 3214 */         indexOf(
/* 3215 */           pathSeparator, 
/* 3216 */           filepath, 
/* 3217 */           fSegmentStart = fSegmentEnd + 1);
/*      */       
/* 3219 */       if (fSegmentEnd < 0) fSegmentEnd = fLength;
/*      */     
/*      */     } 
/*      */ 
/*      */     
/* 3224 */     if ((pSegmentStart >= pLength && freeTrailingDoubleStar) || (
/* 3225 */       pSegmentEnd == pSegmentStart + 2 && 
/* 3226 */       pattern[pSegmentStart] == '*' && 
/* 3227 */       pattern[pSegmentStart + 1] == '*')) {
/* 3228 */       pSegmentEnd = 
/* 3229 */         indexOf(
/* 3230 */           pathSeparator, 
/* 3231 */           pattern, 
/* 3232 */           pSegmentStart = pSegmentEnd + 1);
/*      */       
/* 3234 */       if (pSegmentEnd < 0) pSegmentEnd = pLength; 
/* 3235 */       pSegmentRestart = pSegmentStart;
/*      */     } else {
/* 3237 */       if (pSegmentStart >= pLength) return (fSegmentStart >= fLength); 
/* 3238 */       pSegmentRestart = 0;
/*      */     } 
/* 3240 */     int fSegmentRestart = fSegmentStart;
/* 3241 */     while (fSegmentStart < fLength) {
/*      */       
/* 3243 */       if (pSegmentStart >= pLength) {
/* 3244 */         if (freeTrailingDoubleStar) return true;
/*      */         
/* 3246 */         pSegmentEnd = 
/* 3247 */           indexOf(pathSeparator, pattern, pSegmentStart = pSegmentRestart);
/* 3248 */         if (pSegmentEnd < 0) pSegmentEnd = pLength;
/*      */         
/* 3250 */         fSegmentRestart = 
/* 3251 */           indexOf(pathSeparator, filepath, fSegmentRestart + 1);
/*      */         
/* 3253 */         if (fSegmentRestart < 0) {
/* 3254 */           fSegmentRestart = fLength;
/*      */         } else {
/* 3256 */           fSegmentRestart++;
/*      */         } 
/* 3258 */         fSegmentEnd = 
/* 3259 */           indexOf(pathSeparator, filepath, fSegmentStart = fSegmentRestart);
/* 3260 */         if (fSegmentEnd < 0) fSegmentEnd = fLength;
/*      */ 
/*      */         
/*      */         continue;
/*      */       } 
/* 3265 */       if (pSegmentEnd == pSegmentStart + 2 && 
/* 3266 */         pattern[pSegmentStart] == '*' && 
/* 3267 */         pattern[pSegmentStart + 1] == '*') {
/* 3268 */         pSegmentEnd = 
/* 3269 */           indexOf(pathSeparator, pattern, pSegmentStart = pSegmentEnd + 1);
/*      */         
/* 3271 */         if (pSegmentEnd < 0) pSegmentEnd = pLength; 
/* 3272 */         pSegmentRestart = pSegmentStart;
/* 3273 */         fSegmentRestart = fSegmentStart;
/* 3274 */         if (pSegmentStart >= pLength) return true;
/*      */         
/*      */         continue;
/*      */       } 
/* 3278 */       if (!match(
/* 3279 */           pattern, 
/* 3280 */           pSegmentStart, 
/* 3281 */           pSegmentEnd, 
/* 3282 */           filepath, 
/* 3283 */           fSegmentStart, 
/* 3284 */           fSegmentEnd, 
/* 3285 */           isCaseSensitive)) {
/*      */         
/* 3287 */         pSegmentEnd = 
/* 3288 */           indexOf(pathSeparator, pattern, pSegmentStart = pSegmentRestart);
/* 3289 */         if (pSegmentEnd < 0) pSegmentEnd = pLength;
/*      */         
/* 3291 */         fSegmentRestart = 
/* 3292 */           indexOf(pathSeparator, filepath, fSegmentRestart + 1);
/*      */         
/* 3294 */         if (fSegmentRestart < 0) {
/* 3295 */           fSegmentRestart = fLength;
/*      */         } else {
/* 3297 */           fSegmentRestart++;
/*      */         } 
/* 3299 */         fSegmentEnd = 
/* 3300 */           indexOf(pathSeparator, filepath, fSegmentStart = fSegmentRestart);
/* 3301 */         if (fSegmentEnd < 0) fSegmentEnd = fLength;
/*      */         
/*      */         continue;
/*      */       } 
/* 3305 */       pSegmentEnd = 
/* 3306 */         indexOf(
/* 3307 */           pathSeparator, 
/* 3308 */           pattern, 
/* 3309 */           pSegmentStart = pSegmentEnd + 1);
/*      */       
/* 3311 */       if (pSegmentEnd < 0) {
/* 3312 */         pSegmentEnd = pLength;
/*      */       }
/* 3314 */       fSegmentEnd = 
/* 3315 */         indexOf(
/* 3316 */           pathSeparator, 
/* 3317 */           filepath, 
/* 3318 */           fSegmentStart = fSegmentEnd + 1);
/*      */       
/* 3320 */       if (fSegmentEnd < 0) {
/* 3321 */         fSegmentEnd = fLength;
/*      */       }
/*      */     } 
/* 3324 */     return !(pSegmentRestart < pSegmentEnd && (
/* 3325 */       fSegmentStart < fLength || pSegmentStart < pLength) && (
/* 3326 */       pSegmentStart != pLength - 2 || 
/* 3327 */       pattern[pSegmentStart] != '*' || 
/* 3328 */       pattern[pSegmentStart + 1] != '*') && (
/* 3329 */       pSegmentStart != pLength || !freeTrailingDoubleStar));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int occurencesOf(char toBeFound, char[] array) {
/* 3359 */     int count = 0;
/* 3360 */     for (int i = 0; i < array.length; i++) {
/* 3361 */       if (toBeFound == array[i])
/* 3362 */         count++; 
/* 3363 */     }  return count;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int occurencesOf(char toBeFound, char[] array, int start) {
/* 3401 */     int count = 0;
/* 3402 */     for (int i = start; i < array.length; i++) {
/* 3403 */       if (toBeFound == array[i])
/* 3404 */         count++; 
/* 3405 */     }  return count;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int parseInt(char[] array, int start, int length) throws NumberFormatException {
/* 3420 */     if (length == 1) {
/* 3421 */       int result = array[start] - 48;
/* 3422 */       if (result < 0 || result > 9) {
/* 3423 */         throw new NumberFormatException("invalid digit");
/*      */       }
/* 3425 */       return result;
/*      */     } 
/* 3427 */     return Integer.parseInt(new String(array, start, length));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final boolean prefixEquals(char[] prefix, char[] name) {
/* 3458 */     int max = prefix.length;
/* 3459 */     if (name.length < max)
/* 3460 */       return false; 
/* 3461 */     for (int i = max; 
/* 3462 */       --i >= 0;) {
/*      */       
/* 3464 */       if (prefix[i] != name[i])
/* 3465 */         return false; 
/* 3466 */     }  return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final boolean prefixEquals(char[] prefix, char[] name, boolean isCaseSensitive) {
/* 3502 */     return prefixEquals(prefix, name, isCaseSensitive, 0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final boolean prefixEquals(char[] prefix, char[] name, boolean isCaseSensitive, int startIndex) {
/* 3545 */     int max = prefix.length;
/* 3546 */     if (name.length - startIndex < max)
/* 3547 */       return false; 
/* 3548 */     if (isCaseSensitive) {
/* 3549 */       for (int j = max; --j >= 0;) {
/* 3550 */         if (prefix[j] != name[startIndex + j])
/* 3551 */           return false; 
/* 3552 */       }  return true;
/*      */     } 
/*      */     
/* 3555 */     for (int i = max; --i >= 0;) {
/* 3556 */       if (ScannerHelper.toLowerCase(prefix[i]) != 
/* 3557 */         ScannerHelper.toLowerCase(name[startIndex + i]))
/* 3558 */         return false; 
/* 3559 */     }  return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final char[] remove(char[] array, char toBeRemoved) {
/* 3590 */     if (array == null) return null; 
/* 3591 */     int length = array.length;
/* 3592 */     if (length == 0) return array; 
/* 3593 */     char[] result = null;
/* 3594 */     int count = 0;
/* 3595 */     for (int i = 0; i < length; i++) {
/* 3596 */       char c = array[i];
/* 3597 */       if (c == toBeRemoved) {
/* 3598 */         if (result == null) {
/* 3599 */           result = new char[length];
/* 3600 */           System.arraycopy(array, 0, result, 0, i);
/* 3601 */           count = i;
/*      */         } 
/* 3603 */       } else if (result != null) {
/* 3604 */         result[count++] = c;
/*      */       } 
/*      */     } 
/* 3607 */     if (result == null) return array; 
/* 3608 */     System.arraycopy(result, 0, result = new char[count], 0, count);
/* 3609 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final void replace(char[] array, char toBeReplaced, char replacementChar) {
/* 3644 */     if (toBeReplaced != replacementChar) {
/* 3645 */       for (int i = 0, max = array.length; i < max; i++) {
/* 3646 */         if (array[i] == toBeReplaced) {
/* 3647 */           array[i] = replacementChar;
/*      */         }
/*      */       } 
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final void replace(char[] array, char[] toBeReplaced, char replacementChar) {
/* 3675 */     replace(array, toBeReplaced, replacementChar, 0, array.length);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final void replace(char[] array, char[] toBeReplaced, char replacementChar, int start, int end) {
/* 3705 */     for (int i = end; --i >= start;) {
/* 3706 */       for (int j = toBeReplaced.length; --j >= 0;) {
/* 3707 */         if (array[i] == toBeReplaced[j]) {
/* 3708 */           array[i] = replacementChar;
/*      */         }
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final char[] replace(char[] array, char[] toBeReplaced, char[] replacementChars) {
/* 3745 */     int max = array.length;
/* 3746 */     int replacedLength = toBeReplaced.length;
/* 3747 */     int replacementLength = replacementChars.length;
/*      */     
/* 3749 */     int[] starts = new int[5];
/* 3750 */     int occurrenceCount = 0;
/*      */     
/* 3752 */     if (!equals(toBeReplaced, replacementChars))
/*      */     {
/* 3754 */       for (int j = 0; j < max; ) {
/* 3755 */         int index = indexOf(toBeReplaced, array, true, j);
/* 3756 */         if (index == -1) {
/* 3757 */           j++;
/*      */           continue;
/*      */         } 
/* 3760 */         if (occurrenceCount == starts.length) {
/* 3761 */           System.arraycopy(
/* 3762 */               starts, 
/* 3763 */               0, 
/* 3764 */               starts = new int[occurrenceCount * 2], 
/* 3765 */               0, 
/* 3766 */               occurrenceCount);
/*      */         }
/* 3768 */         starts[occurrenceCount++] = index;
/* 3769 */         j = index + replacedLength;
/*      */       } 
/*      */     }
/* 3772 */     if (occurrenceCount == 0)
/* 3773 */       return array; 
/* 3774 */     char[] result = 
/* 3775 */       new char[max + 
/* 3776 */         occurrenceCount * (replacementLength - replacedLength)];
/* 3777 */     int inStart = 0, outStart = 0;
/* 3778 */     for (int i = 0; i < occurrenceCount; i++) {
/* 3779 */       int offset = starts[i] - inStart;
/* 3780 */       System.arraycopy(array, inStart, result, outStart, offset);
/* 3781 */       inStart += offset;
/* 3782 */       outStart += offset;
/* 3783 */       System.arraycopy(
/* 3784 */           replacementChars, 
/* 3785 */           0, 
/* 3786 */           result, 
/* 3787 */           outStart, 
/* 3788 */           replacementLength);
/* 3789 */       inStart += replacedLength;
/* 3790 */       outStart += replacementLength;
/*      */     } 
/* 3792 */     System.arraycopy(array, inStart, result, outStart, max - inStart);
/* 3793 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final char[] replaceOnCopy(char[] array, char toBeReplaced, char replacementChar) {
/* 3831 */     char[] result = null;
/* 3832 */     for (int i = 0, length = array.length; i < length; i++) {
/* 3833 */       char c = array[i];
/* 3834 */       if (c == toBeReplaced) {
/* 3835 */         if (result == null) {
/* 3836 */           result = new char[length];
/* 3837 */           System.arraycopy(array, 0, result, 0, i);
/*      */         } 
/* 3839 */         result[i] = replacementChar;
/* 3840 */       } else if (result != null) {
/* 3841 */         result[i] = c;
/*      */       } 
/*      */     } 
/* 3844 */     if (result == null) return array; 
/* 3845 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final char[][] splitAndTrimOn(char divider, char[] array) {
/* 3887 */     int length = (array == null) ? 0 : array.length;
/* 3888 */     if (length == 0) {
/* 3889 */       return NO_CHAR_CHAR;
/*      */     }
/* 3891 */     int wordCount = 1;
/* 3892 */     for (int i = 0; i < length; i++) {
/* 3893 */       if (array[i] == divider)
/* 3894 */         wordCount++; 
/* 3895 */     }  char[][] split = new char[wordCount][];
/* 3896 */     int last = 0, currentWord = 0;
/* 3897 */     for (int j = 0; j < length; j++) {
/* 3898 */       if (array[j] == divider) {
/* 3899 */         int k = last, m = j - 1;
/* 3900 */         while (k < j && array[k] == ' ')
/* 3901 */           k++; 
/* 3902 */         while (m > k && array[m] == ' ')
/* 3903 */           m--; 
/* 3904 */         split[currentWord] = new char[m - k + 1];
/* 3905 */         System.arraycopy(
/* 3906 */             array, 
/* 3907 */             k, 
/* 3908 */             split[currentWord++], 
/* 3909 */             0, 
/* 3910 */             m - k + 1);
/* 3911 */         last = j + 1;
/*      */       } 
/*      */     } 
/* 3914 */     int start = last, end = length - 1;
/* 3915 */     while (start < length && array[start] == ' ')
/* 3916 */       start++; 
/* 3917 */     while (end > start && array[end] == ' ')
/* 3918 */       end--; 
/* 3919 */     split[currentWord] = new char[end - start + 1];
/* 3920 */     System.arraycopy(
/* 3921 */         array, 
/* 3922 */         start, 
/* 3923 */         split[currentWord++], 
/* 3924 */         0, 
/* 3925 */         end - start + 1);
/* 3926 */     return split;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final char[][] splitOn(char divider, char[] array) {
/* 3960 */     int length = (array == null) ? 0 : array.length;
/* 3961 */     if (length == 0) {
/* 3962 */       return NO_CHAR_CHAR;
/*      */     }
/* 3964 */     int wordCount = 1;
/* 3965 */     for (int i = 0; i < length; i++) {
/* 3966 */       if (array[i] == divider)
/* 3967 */         wordCount++; 
/* 3968 */     }  char[][] split = new char[wordCount][];
/* 3969 */     int last = 0, currentWord = 0;
/* 3970 */     for (int j = 0; j < length; j++) {
/* 3971 */       if (array[j] == divider) {
/* 3972 */         split[currentWord] = new char[j - last];
/* 3973 */         System.arraycopy(
/* 3974 */             array, 
/* 3975 */             last, 
/* 3976 */             split[currentWord++], 
/* 3977 */             0, 
/* 3978 */             j - last);
/* 3979 */         last = j + 1;
/*      */       } 
/*      */     } 
/* 3982 */     split[currentWord] = new char[length - last];
/* 3983 */     System.arraycopy(array, last, split[currentWord], 0, length - last);
/* 3984 */     return split;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final char[][] splitOn(char divider, char[] array, int start, int end) {
/* 4016 */     int length = (array == null) ? 0 : array.length;
/* 4017 */     if (length == 0 || start > end) {
/* 4018 */       return NO_CHAR_CHAR;
/*      */     }
/* 4020 */     int wordCount = 1;
/* 4021 */     for (int i = start; i < end; i++) {
/* 4022 */       if (array[i] == divider)
/* 4023 */         wordCount++; 
/* 4024 */     }  char[][] split = new char[wordCount][];
/* 4025 */     int last = start, currentWord = 0;
/* 4026 */     for (int j = start; j < end; j++) {
/* 4027 */       if (array[j] == divider) {
/* 4028 */         split[currentWord] = new char[j - last];
/* 4029 */         System.arraycopy(
/* 4030 */             array, 
/* 4031 */             last, 
/* 4032 */             split[currentWord++], 
/* 4033 */             0, 
/* 4034 */             j - last);
/* 4035 */         last = j + 1;
/*      */       } 
/*      */     } 
/* 4038 */     split[currentWord] = new char[end - last];
/* 4039 */     System.arraycopy(array, last, split[currentWord], 0, end - last);
/* 4040 */     return split;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final char[][] splitOnWithEnclosures(char divider, char openEncl, char closeEncl, char[] array, int start, int end) {
/* 4079 */     int length = (array == null) ? 0 : array.length;
/* 4080 */     if (length == 0 || start > end) {
/* 4081 */       return NO_CHAR_CHAR;
/*      */     }
/* 4083 */     int wordCount = 1;
/* 4084 */     int enclCount = 0;
/* 4085 */     for (int i = start; i < end; i++) {
/* 4086 */       if (array[i] == openEncl) {
/* 4087 */         enclCount++;
/* 4088 */       } else if (array[i] == divider) {
/* 4089 */         wordCount++;
/*      */       } 
/* 4091 */     }  if (enclCount == 0) {
/* 4092 */       return splitOn(divider, array, start, end);
/*      */     }
/* 4094 */     int nesting = 0;
/* 4095 */     if (openEncl == divider || closeEncl == divider) {
/* 4096 */       return NO_CHAR_CHAR;
/*      */     }
/* 4098 */     int[][] splitOffsets = new int[wordCount][2];
/* 4099 */     int last = start, currentWord = 0, prevOffset = start;
/* 4100 */     for (int j = start; j < end; j++) {
/* 4101 */       if (array[j] == openEncl) {
/* 4102 */         nesting++;
/*      */       
/*      */       }
/* 4105 */       else if (array[j] == closeEncl) {
/* 4106 */         if (nesting > 0) {
/* 4107 */           nesting--;
/*      */         }
/*      */       }
/* 4110 */       else if (array[j] == divider && nesting == 0) {
/* 4111 */         splitOffsets[currentWord][0] = prevOffset;
/* 4112 */         last = splitOffsets[currentWord++][1] = j;
/* 4113 */         prevOffset = last + 1;
/*      */       } 
/*      */     } 
/* 4116 */     if (last < end - 1) {
/* 4117 */       splitOffsets[currentWord][0] = prevOffset;
/* 4118 */       splitOffsets[currentWord++][1] = end;
/*      */     } 
/* 4120 */     char[][] split = new char[currentWord][];
/* 4121 */     for (int k = 0; k < currentWord; k++) {
/* 4122 */       int sStart = splitOffsets[k][0];
/* 4123 */       int sEnd = splitOffsets[k][1];
/* 4124 */       int size = sEnd - sStart;
/* 4125 */       split[k] = new char[size];
/* 4126 */       System.arraycopy(array, sStart, split[k], 0, size);
/*      */     } 
/* 4128 */     return split;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final char[][] subarray(char[][] array, int start, int end) {
/* 4164 */     if (end == -1)
/* 4165 */       end = array.length; 
/* 4166 */     if (start > end)
/* 4167 */       return null; 
/* 4168 */     if (start < 0)
/* 4169 */       return null; 
/* 4170 */     if (end > array.length) {
/* 4171 */       return null;
/*      */     }
/* 4173 */     char[][] result = new char[end - start][];
/* 4174 */     System.arraycopy(array, start, result, 0, end - start);
/* 4175 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final char[] subarray(char[] array, int start, int end) {
/* 4211 */     if (end == -1)
/* 4212 */       end = array.length; 
/* 4213 */     if (start > end)
/* 4214 */       return null; 
/* 4215 */     if (start < 0)
/* 4216 */       return null; 
/* 4217 */     if (end > array.length) {
/* 4218 */       return null;
/*      */     }
/* 4220 */     char[] result = new char[end - start];
/* 4221 */     System.arraycopy(array, start, result, 0, end - start);
/* 4222 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final char[] toLowerCase(char[] chars) {
/* 4249 */     if (chars == null)
/* 4250 */       return null; 
/* 4251 */     int length = chars.length;
/* 4252 */     char[] lowerChars = null;
/* 4253 */     for (int i = 0; i < length; i++) {
/* 4254 */       char c = chars[i];
/* 4255 */       char lc = ScannerHelper.toLowerCase(c);
/* 4256 */       if (c != lc || lowerChars != null) {
/* 4257 */         if (lowerChars == null) {
/* 4258 */           System.arraycopy(
/* 4259 */               chars, 
/* 4260 */               0, 
/* 4261 */               lowerChars = new char[length], 
/* 4262 */               0, 
/* 4263 */               i);
/*      */         }
/* 4265 */         lowerChars[i] = lc;
/*      */       } 
/*      */     } 
/* 4268 */     return (lowerChars == null) ? chars : lowerChars;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final char[] toUpperCase(char[] chars) {
/* 4297 */     if (chars == null)
/* 4298 */       return null; 
/* 4299 */     int length = chars.length;
/* 4300 */     char[] upperChars = null;
/* 4301 */     for (int i = 0; i < length; i++) {
/* 4302 */       char c = chars[i];
/* 4303 */       char lc = ScannerHelper.toUpperCase(c);
/* 4304 */       if (c != lc || upperChars != null) {
/* 4305 */         if (upperChars == null) {
/* 4306 */           System.arraycopy(
/* 4307 */               chars, 
/* 4308 */               0, 
/* 4309 */               upperChars = new char[length], 
/* 4310 */               0, 
/* 4311 */               i);
/*      */         }
/* 4313 */         upperChars[i] = lc;
/*      */       } 
/*      */     } 
/* 4316 */     return (upperChars == null) ? chars : upperChars;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final char[] trim(char[] chars) {
/* 4343 */     if (chars == null) {
/* 4344 */       return null;
/*      */     }
/* 4346 */     int start = 0, length = chars.length, end = length - 1;
/* 4347 */     while (start < length && chars[start] == ' ') {
/* 4348 */       start++;
/*      */     }
/* 4350 */     while (end > start && chars[end] == ' ') {
/* 4351 */       end--;
/*      */     }
/* 4353 */     if (start != 0 || end != length - 1) {
/* 4354 */       return subarray(chars, start, end + 1);
/*      */     }
/* 4356 */     return chars;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String toString(char[][] array) {
/* 4381 */     char[] result = concatWith(array, '.');
/* 4382 */     return new String(result);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String[] toStrings(char[][] array) {
/* 4393 */     if (array == null) return NO_STRINGS; 
/* 4394 */     int length = array.length;
/* 4395 */     if (length == 0) return NO_STRINGS; 
/* 4396 */     String[] result = new String[length];
/* 4397 */     for (int i = 0; i < length; i++)
/* 4398 */       result[i] = new String(array[i]); 
/* 4399 */     return result;
/*      */   }
/*      */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\core\compiler\CharOperation.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */