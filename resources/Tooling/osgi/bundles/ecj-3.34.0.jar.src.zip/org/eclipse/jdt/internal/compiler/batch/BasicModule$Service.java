/*    */ package org.eclipse.jdt.internal.compiler.batch;
/*    */ 
/*    */ import org.eclipse.jdt.internal.compiler.env.IModule;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class Service
/*    */   implements IModule.IService
/*    */ {
/*    */   char[] provides;
/*    */   char[][] with;
/*    */   
/*    */   public char[] name() {
/* 45 */     return this.provides;
/*    */   }
/*    */ 
/*    */   
/*    */   public char[][] with() {
/* 50 */     return this.with;
/*    */   }
/*    */   
/*    */   public String toString() {
/* 54 */     StringBuilder buffer = new StringBuilder();
/* 55 */     buffer.append("provides");
/* 56 */     buffer.append(this.provides);
/* 57 */     buffer.append(" with ");
/* 58 */     buffer.append(this.with);
/* 59 */     buffer.append(';');
/* 60 */     return buffer.toString();
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\batch\BasicModule$Service.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */