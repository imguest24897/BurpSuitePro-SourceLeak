/*     */ package org.eclipse.jdt.internal.compiler.codegen;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.eclipse.jdt.internal.compiler.ClassFile;
/*     */ import org.eclipse.jdt.internal.compiler.ast.ArrayAllocationExpression;
/*     */ import org.eclipse.jdt.internal.compiler.ast.TypeReference;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.ArrayBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.MethodBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.TypeBinding;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TypeAnnotationCodeStream
/*     */   extends StackMapFrameCodeStream
/*     */ {
/*     */   public List<AnnotationContext> allTypeAnnotationContexts;
/*     */   
/*     */   public TypeAnnotationCodeStream(ClassFile givenClassFile) {
/*  37 */     super(givenClassFile);
/*  38 */     this.generateAttributes |= 0x20;
/*  39 */     this.allTypeAnnotationContexts = new ArrayList<>();
/*     */   }
/*     */   
/*     */   private void addAnnotationContext(TypeReference typeReference, int info, int targetType, ArrayAllocationExpression allocationExpression) {
/*  43 */     allocationExpression.getAllAnnotationContexts(targetType, info, this.allTypeAnnotationContexts);
/*     */   }
/*     */   
/*     */   private void addAnnotationContext(TypeReference typeReference, int info, int targetType) {
/*  47 */     typeReference.getAllAnnotationContexts(targetType, info, this.allTypeAnnotationContexts);
/*     */   }
/*     */   
/*     */   private void addAnnotationContext(TypeReference typeReference, int info, int typeIndex, int targetType) {
/*  51 */     typeReference.getAllAnnotationContexts(targetType, info, typeIndex, this.allTypeAnnotationContexts);
/*     */   }
/*     */ 
/*     */   
/*     */   public void instance_of(TypeReference typeReference, TypeBinding typeBinding) {
/*  56 */     if (typeReference != null && (typeReference.bits & 0x100000) != 0) {
/*  57 */       addAnnotationContext(typeReference, this.position, 67);
/*     */     }
/*  59 */     super.instance_of(typeReference, typeBinding);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void multianewarray(TypeReference typeReference, TypeBinding typeBinding, int dimensions, ArrayAllocationExpression allocationExpression) {
/*  68 */     if (typeReference != null && (typeReference.bits & 0x100000) != 0) {
/*  69 */       addAnnotationContext(typeReference, this.position, 68, allocationExpression);
/*     */     }
/*  71 */     super.multianewarray(typeReference, typeBinding, dimensions, allocationExpression);
/*     */   }
/*     */ 
/*     */   
/*     */   public void new_(TypeReference typeReference, TypeBinding typeBinding) {
/*  76 */     if (typeReference != null && (typeReference.bits & 0x100000) != 0) {
/*  77 */       addAnnotationContext(typeReference, this.position, 68);
/*     */     }
/*  79 */     super.new_(typeReference, typeBinding);
/*     */   }
/*     */ 
/*     */   
/*     */   public void newArray(TypeReference typeReference, ArrayAllocationExpression allocationExpression, ArrayBinding arrayBinding) {
/*  84 */     if (typeReference != null && (typeReference.bits & 0x100000) != 0) {
/*  85 */       addAnnotationContext(typeReference, this.position, 68, allocationExpression);
/*     */     }
/*  87 */     super.newArray(typeReference, allocationExpression, arrayBinding);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void checkcast(TypeReference typeReference, TypeBinding typeBinding, int currentPosition) {
/*  96 */     if (typeReference != null) {
/*  97 */       TypeReference[] typeReferences = typeReference.getTypeReferences();
/*  98 */       for (int i = typeReferences.length - 1; i >= 0; i--) {
/*  99 */         typeReference = typeReferences[i];
/* 100 */         if (typeReference != null) {
/* 101 */           if ((typeReference.bits & 0x100000) != 0) {
/* 102 */             if (!typeReference.resolvedType.isBaseType()) {
/* 103 */               addAnnotationContext(typeReference, this.position, i, 71);
/*     */             } else {
/*     */               
/* 106 */               addAnnotationContext(typeReference, currentPosition, i, 71);
/*     */             } 
/*     */           }
/* 109 */           if (!typeReference.resolvedType.isBaseType()) {
/* 110 */             super.checkcast(typeReference, typeReference.resolvedType, currentPosition);
/*     */           }
/*     */         } 
/*     */       } 
/*     */     } else {
/* 115 */       super.checkcast(null, typeBinding, currentPosition);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void invoke(byte opcode, MethodBinding methodBinding, TypeBinding declaringClass, TypeReference[] typeArguments) {
/* 121 */     if (typeArguments != null) {
/* 122 */       int targetType = methodBinding.isConstructor() ? 
/* 123 */         72 : 
/* 124 */         73;
/* 125 */       for (int i = 0, max = typeArguments.length; i < max; i++) {
/* 126 */         TypeReference typeArgument = typeArguments[i];
/* 127 */         if ((typeArgument.bits & 0x100000) != 0) {
/* 128 */           addAnnotationContext(typeArgument, this.position, i, targetType);
/*     */         }
/*     */       } 
/*     */     } 
/* 132 */     super.invoke(opcode, methodBinding, declaringClass, typeArguments);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void invokeDynamic(int bootStrapIndex, int argsSize, int returnTypeSize, char[] selector, char[] signature, boolean isConstructorReference, TypeReference lhsTypeReference, TypeReference[] typeArguments, int typeId, TypeBinding type) {
/* 139 */     if (lhsTypeReference != null && (lhsTypeReference.bits & 0x100000) != 0) {
/* 140 */       if (isConstructorReference) {
/* 141 */         addAnnotationContext(lhsTypeReference, this.position, 0, 69);
/*     */       } else {
/* 143 */         addAnnotationContext(lhsTypeReference, this.position, 0, 70);
/*     */       } 
/*     */     }
/* 146 */     if (typeArguments != null) {
/* 147 */       int targetType = 
/* 148 */         isConstructorReference ? 
/* 149 */         74 : 
/* 150 */         75;
/* 151 */       for (int i = 0, max = typeArguments.length; i < max; i++) {
/* 152 */         TypeReference typeArgument = typeArguments[i];
/* 153 */         if ((typeArgument.bits & 0x100000) != 0) {
/* 154 */           addAnnotationContext(typeArgument, this.position, i, targetType);
/*     */         }
/*     */       } 
/*     */     } 
/* 158 */     super.invokeDynamic(bootStrapIndex, argsSize, returnTypeSize, selector, signature, isConstructorReference, lhsTypeReference, typeArguments, typeId, type);
/*     */   }
/*     */ 
/*     */   
/*     */   public void reset(ClassFile givenClassFile) {
/* 163 */     super.reset(givenClassFile);
/* 164 */     this.allTypeAnnotationContexts = new ArrayList<>();
/*     */   }
/*     */ 
/*     */   
/*     */   public void init(ClassFile targetClassFile) {
/* 169 */     super.init(targetClassFile);
/* 170 */     this.allTypeAnnotationContexts = new ArrayList<>();
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\codegen\TypeAnnotationCodeStream.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */