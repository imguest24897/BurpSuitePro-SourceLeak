/*     */ package org.eclipse.jdt.internal.compiler.lookup;
/*     */ 
/*     */ import org.eclipse.jdt.internal.compiler.ast.Annotation;
/*     */ import org.eclipse.jdt.internal.compiler.ast.ArrayInitializer;
/*     */ import org.eclipse.jdt.internal.compiler.ast.ClassLiteralAccess;
/*     */ import org.eclipse.jdt.internal.compiler.ast.Expression;
/*     */ import org.eclipse.jdt.internal.compiler.ast.FieldReference;
/*     */ import org.eclipse.jdt.internal.compiler.ast.NameReference;
/*     */ import org.eclipse.jdt.internal.compiler.impl.Constant;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ElementValuePair
/*     */ {
/*     */   char[] name;
/*     */   public Object value;
/*     */   public MethodBinding binding;
/*     */   
/*     */   public static class UnresolvedEnumConstant
/*     */   {
/*     */     ReferenceBinding enumType;
/*     */     LookupEnvironment environment;
/*     */     char[] enumConstantName;
/*     */     
/*     */     UnresolvedEnumConstant(ReferenceBinding enumType, LookupEnvironment environment, char[] enumConstantName) {
/*  37 */       this.enumType = enumType;
/*  38 */       this.environment = environment;
/*  39 */       this.enumConstantName = enumConstantName;
/*     */     }
/*     */     FieldBinding getResolved() {
/*  42 */       if (this.enumType.isUnresolvedType())
/*  43 */         this.enumType = (ReferenceBinding)BinaryTypeBinding.resolveType(this.enumType, this.environment, false); 
/*  44 */       return this.enumType.getField(this.enumConstantName, false);
/*     */     }
/*     */     public char[] getEnumConstantName() {
/*  47 */       return this.enumConstantName;
/*     */     }
/*     */   }
/*     */   
/*     */   public static Object getValue(Expression expression) {
/*  52 */     if (expression == null)
/*  53 */       return null; 
/*  54 */     Constant constant = expression.constant;
/*     */     
/*  56 */     if (constant != null && constant != Constant.NotAConstant) {
/*  57 */       return constant;
/*     */     }
/*  59 */     if (expression instanceof Annotation)
/*  60 */       return ((Annotation)expression).getCompilerAnnotation(); 
/*  61 */     if (expression instanceof ArrayInitializer) {
/*  62 */       Expression[] exprs = ((ArrayInitializer)expression).expressions;
/*  63 */       int length = (exprs == null) ? 0 : exprs.length;
/*  64 */       Object[] values = new Object[length];
/*  65 */       for (int i = 0; i < length; i++)
/*  66 */         values[i] = getValue(exprs[i]); 
/*  67 */       return values;
/*     */     } 
/*  69 */     if (expression instanceof ClassLiteralAccess)
/*  70 */       return ((ClassLiteralAccess)expression).targetType; 
/*  71 */     if (expression instanceof org.eclipse.jdt.internal.compiler.ast.Reference) {
/*  72 */       FieldBinding fieldBinding = null;
/*  73 */       if (expression instanceof FieldReference) {
/*  74 */         fieldBinding = ((FieldReference)expression).fieldBinding();
/*  75 */       } else if (expression instanceof NameReference) {
/*  76 */         Binding binding = ((NameReference)expression).binding;
/*  77 */         if (binding != null && binding.kind() == 1)
/*  78 */           fieldBinding = (FieldBinding)binding; 
/*     */       } 
/*  80 */       if (fieldBinding != null && (fieldBinding.modifiers & 0x4000) > 0) {
/*  81 */         return fieldBinding;
/*     */       }
/*     */     } 
/*  84 */     return null;
/*     */   }
/*     */   
/*     */   public ElementValuePair(char[] name, Expression expression, MethodBinding binding) {
/*  88 */     this(name, getValue(expression), binding);
/*     */   }
/*     */   
/*     */   public ElementValuePair(char[] name, Object value, MethodBinding binding) {
/*  92 */     this.name = name;
/*  93 */     this.value = value;
/*  94 */     this.binding = binding;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public char[] getName() {
/* 101 */     return this.name;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MethodBinding getMethodBinding() {
/* 108 */     return this.binding;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object getValue() {
/* 120 */     if (this.value instanceof UnresolvedEnumConstant) {
/* 121 */       this.value = ((UnresolvedEnumConstant)this.value).getResolved();
/* 122 */     } else if (this.value instanceof Object[]) {
/* 123 */       Object[] valueArray = (Object[])this.value;
/* 124 */       for (int i = 0; i < valueArray.length; i++) {
/* 125 */         Object object = valueArray[i];
/* 126 */         if (object instanceof UnresolvedEnumConstant)
/* 127 */           valueArray[i] = ((UnresolvedEnumConstant)object).getResolved(); 
/*     */       } 
/*     */     } 
/* 130 */     return this.value;
/*     */   }
/*     */ 
/*     */   
/*     */   void setMethodBinding(MethodBinding binding) {
/* 135 */     this.binding = binding;
/*     */   }
/*     */ 
/*     */   
/*     */   void setValue(Object value) {
/* 140 */     this.value = value;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 145 */     StringBuilder buffer = new StringBuilder(5);
/* 146 */     buffer.append(this.name).append(" = ");
/* 147 */     buffer.append(this.value);
/* 148 */     return buffer.toString();
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\lookup\ElementValuePair.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */