/*    */ package org.eclipse.jdt.internal.compiler.ast;
/*    */ 
/*    */ import org.eclipse.jdt.internal.compiler.lookup.ModuleBinding;
/*    */ import org.eclipse.jdt.internal.compiler.lookup.Scope;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RequiresStatement
/*    */   extends ModuleStatement
/*    */ {
/*    */   public ModuleReference module;
/*    */   public ModuleBinding resolvedBinding;
/* 25 */   public int modifiers = 0;
/*    */   public int modifiersSourceStart;
/*    */   
/*    */   public RequiresStatement(ModuleReference module) {
/* 29 */     this.module = module;
/*    */   }
/*    */   public boolean isTransitive() {
/* 32 */     return ((this.modifiers & 0x20) != 0);
/*    */   }
/*    */   public boolean isStatic() {
/* 35 */     return ((this.modifiers & 0x40) != 0);
/*    */   }
/*    */   
/*    */   public StringBuffer print(int indent, StringBuffer output) {
/* 39 */     output.append("requires ");
/* 40 */     if (isTransitive())
/* 41 */       output.append("transitive "); 
/* 42 */     if (isStatic())
/* 43 */       output.append("static "); 
/* 44 */     this.module.print(indent, output);
/* 45 */     output.append(";");
/* 46 */     return output;
/*    */   }
/*    */   public ModuleBinding resolve(Scope scope) {
/* 49 */     if (this.resolvedBinding != null)
/* 50 */       return this.resolvedBinding; 
/* 51 */     this.resolvedBinding = this.module.resolve(scope);
/* 52 */     if (scope != null) {
/* 53 */       if (this.resolvedBinding == null) {
/* 54 */         scope.problemReporter().invalidModule(this.module);
/* 55 */       } else if (this.resolvedBinding.hasUnstableAutoName()) {
/* 56 */         scope.problemReporter().autoModuleWithUnstableName(this.module);
/*    */       } 
/*    */     }
/* 59 */     return this.resolvedBinding;
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\ast\RequiresStatement.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */