/*     */ package org.eclipse.jdt.internal.compiler.ast;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.eclipse.jdt.internal.compiler.ASTVisitor;
/*     */ import org.eclipse.jdt.internal.compiler.codegen.BranchLabel;
/*     */ import org.eclipse.jdt.internal.compiler.codegen.CodeStream;
/*     */ import org.eclipse.jdt.internal.compiler.flow.FlowContext;
/*     */ import org.eclipse.jdt.internal.compiler.flow.FlowInfo;
/*     */ import org.eclipse.jdt.internal.compiler.flow.LoopingFlowContext;
/*     */ import org.eclipse.jdt.internal.compiler.flow.UnconditionalFlowInfo;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.ArrayBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.Binding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.BlockScope;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.CaptureBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.ImplicitNullAnnotationVerifier;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.LocalVariableBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.MethodBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.ParameterizedTypeBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.ReferenceBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.Scope;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.TypeBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.TypeConstants;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.TypeVariableBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.VariableBinding;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ForeachStatement
/*     */   extends Statement
/*     */ {
/*     */   public LocalDeclaration elementVariable;
/*  61 */   public int elementVariableImplicitWidening = -1;
/*     */   
/*     */   public Expression collection;
/*     */   
/*     */   public Statement originalAction;
/*     */   
/*     */   public Statement action;
/*     */   
/*     */   public RecordPattern pattern;
/*     */   
/*     */   private int kind;
/*     */   
/*     */   private static final int ARRAY = 0;
/*     */   
/*     */   private static final int RAW_ITERABLE = 1;
/*     */   
/*     */   private static final int GENERIC_ITERABLE = 2;
/*     */   
/*     */   private TypeBinding iteratorReceiverType;
/*     */   
/*     */   private TypeBinding collectionElementType;
/*     */   private BranchLabel breakLabel;
/*     */   private BranchLabel continueLabel;
/*     */   public BlockScope scope;
/*     */   public LocalVariableBinding indexVariable;
/*     */   public LocalVariableBinding collectionVariable;
/*     */   public LocalVariableBinding maxVariable;
/*  88 */   private static final char[] SecretIteratorVariableName = " iterator".toCharArray();
/*  89 */   private static final char[] SecretIndexVariableName = " index".toCharArray();
/*  90 */   private static final char[] SecretCollectionVariableName = " collection".toCharArray();
/*  91 */   private static final char[] SecretMaxVariableName = " max".toCharArray();
/*  92 */   public static final char[] SecretRecordPatternVariableName = " recordPatternVar".toCharArray();
/*     */   
/*  94 */   int postCollectionInitStateIndex = -1;
/*  95 */   int mergedInitStateIndex = -1;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ForeachStatement(LocalDeclaration elementVariable, int start) {
/* 101 */     this.elementVariable = elementVariable;
/* 102 */     this.sourceStart = start;
/* 103 */     this.kind = -1;
/*     */   }
/*     */   
/*     */   public ForeachStatement(RecordPattern recordPattern, int start) {
/* 107 */     this(new LocalDeclaration(SecretRecordPatternVariableName, 0, 0), start);
/* 108 */     this.pattern = recordPattern;
/* 109 */     this.elementVariable.type = this.pattern.type;
/*     */   }
/*     */   public void transformAction() {
/* 112 */     if (this.pattern != null && this.action != null) {
/* 113 */       SwitchStatement switchStatement = new SwitchStatement();
/* 114 */       switchStatement.switchBits |= 0x20;
/* 115 */       switchStatement.containsPatterns = true;
/* 116 */       switchStatement.containsNull = true;
/* 117 */       switchStatement.expression = new SingleNameReference(this.elementVariable.name, 0L);
/*     */       
/* 119 */       List<Statement> stmts = new ArrayList<>();
/*     */       
/* 121 */       stmts.add(new CaseStatement(this.pattern, 0, 0));
/* 122 */       stmts.add(this.action);
/* 123 */       stmts.add(new BreakStatement(null, 0, 0));
/*     */       
/* 125 */       stmts.add(new CaseStatement(0, 0, new Expression[] { new NullLiteral(0, 0), new FakeDefaultLiteral(0, 0) }));
/*     */ 
/*     */       
/* 128 */       AllocationExpression allocationExpression = new AllocationExpression();
/* 129 */       allocationExpression.type = new SingleTypeReference("NullPointerException".toCharArray(), 0L);
/* 130 */       stmts.add(new ThrowStatement(allocationExpression, 0, 0));
/*     */       
/* 132 */       switchStatement.statements = stmts.<Statement>toArray(new Statement[0]);
/* 133 */       switchStatement.sourceStart = this.action.sourceStart;
/* 134 */       switchStatement.sourceEnd = this.action.sourceEnd;
/* 135 */       this.originalAction = this.action;
/* 136 */       this.action = switchStatement;
/*     */     } 
/*     */   }
/*     */   
/*     */   public FlowInfo analyseCode(BlockScope currentScope, FlowContext flowContext, FlowInfo flowInfo) {
/*     */     FlowInfo exitBranch;
/* 142 */     this.breakLabel = new BranchLabel();
/* 143 */     this.continueLabel = new BranchLabel();
/* 144 */     int initialComplaintLevel = ((flowInfo.reachMode() & 0x3) != 0) ? 1 : 0;
/*     */ 
/*     */     
/* 147 */     flowInfo = this.elementVariable.analyseCode(this.scope, flowContext, flowInfo);
/* 148 */     FlowInfo condInfo = this.collection.analyseCode(this.scope, flowContext, flowInfo.copy());
/* 149 */     this.collection.checkNPE(currentScope, flowContext, condInfo.copy(), 1);
/* 150 */     LocalVariableBinding elementVarBinding = this.elementVariable.binding;
/*     */ 
/*     */     
/* 153 */     condInfo.markAsDefinitelyAssigned(elementVarBinding);
/*     */     
/* 155 */     this.postCollectionInitStateIndex = currentScope.methodScope().recordInitializationStates(condInfo);
/*     */ 
/*     */ 
/*     */     
/* 159 */     LoopingFlowContext loopingContext = 
/* 160 */       new LoopingFlowContext(flowContext, flowInfo, this, this.breakLabel, 
/* 161 */         this.continueLabel, (Scope)this.scope, true);
/* 162 */     UnconditionalFlowInfo actionInfo = 
/* 163 */       condInfo.nullInfoLessUnconditionalCopy();
/* 164 */     actionInfo.markAsDefinitelyUnknown(elementVarBinding);
/* 165 */     if ((currentScope.compilerOptions()).isAnnotationBasedNullAnalysisEnabled) {
/* 166 */       int elementNullStatus = NullAnnotationMatching.nullStatusFromExpressionType(this.collectionElementType);
/* 167 */       int nullStatus = NullAnnotationMatching.checkAssignment(currentScope, flowContext, (VariableBinding)elementVarBinding, null, 
/* 168 */           elementNullStatus, this.collection, this.collectionElementType);
/* 169 */       if ((this.kind == 2 || this.kind == 1) && !currentScope.compilerOptions().usesNullTypeAnnotations()) {
/*     */         
/* 171 */         ReferenceBinding iterator = currentScope.getJavaUtilIterator();
/* 172 */         if (iterator != null) {
/* 173 */           MethodBinding next = iterator.getExactMethod(TypeConstants.NEXT, Binding.NO_TYPES, currentScope.compilationUnitScope);
/* 174 */           ImplicitNullAnnotationVerifier.ensureNullnessIsKnown(next, (Scope)currentScope);
/* 175 */           if (next != null && (next.tagBits & 0x180000000000000L) != 0L) {
/* 176 */             nullStatus = FlowInfo.tagBitsToNullStatus(next.tagBits);
/*     */           }
/*     */         } 
/*     */       } 
/* 180 */       if ((elementVarBinding.type.tagBits & 0x2L) == 0L) {
/* 181 */         actionInfo.markNullStatus(elementVarBinding, nullStatus);
/*     */       }
/*     */     } 
/*     */     
/* 185 */     if (this.action != null && (!this.action.isEmptyBlock() || 
/* 186 */       (currentScope.compilerOptions()).complianceLevel > 3080192L)) {
/*     */       
/* 188 */       if (this.action.complainIfUnreachable((FlowInfo)actionInfo, this.scope, initialComplaintLevel, true) < 2) {
/* 189 */         actionInfo = this.action.analyseCode(this.scope, (FlowContext)loopingContext, (FlowInfo)actionInfo).unconditionalCopy();
/* 190 */         FakedTrackingVariable.markForeachElementVar(this.elementVariable);
/*     */         
/* 192 */         FlowInfo actionNullInfo = condInfo.copy().addNullInfoFrom((FlowInfo)actionInfo);
/* 193 */         this.scope.checkUnclosedCloseables(actionNullInfo, (FlowContext)loopingContext, null, null);
/*     */       } 
/*     */ 
/*     */       
/* 197 */       exitBranch = flowInfo.unconditionalCopy()
/* 198 */         .addInitializationsFrom(condInfo.initsWhenFalse());
/*     */       
/* 200 */       if ((actionInfo.tagBits & loopingContext.initsOnContinue.tagBits & 
/* 201 */         0x1) != 0) {
/* 202 */         this.continueLabel = null;
/*     */       } else {
/* 204 */         actionInfo = actionInfo.mergedWith(loopingContext.initsOnContinue);
/* 205 */         loopingContext.complainOnDeferredFinalChecks(this.scope, (FlowInfo)actionInfo);
/* 206 */         exitBranch.addPotentialInitializationsFrom((FlowInfo)actionInfo);
/*     */       } 
/*     */     } else {
/* 209 */       exitBranch = condInfo.initsWhenFalse();
/* 210 */       if (this.action instanceof Block && !this.action.isEmptyBlock()) {
/* 211 */         this.scope.checkUnclosedCloseables((FlowInfo)actionInfo, (FlowContext)loopingContext, null, null);
/*     */       }
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 217 */     boolean hasEmptyAction = !(this.action != null && 
/* 218 */       !this.action.isEmptyBlock() && (
/* 219 */       this.action.bits & 0x1) == 0);
/*     */     
/* 221 */     switch (this.kind) {
/*     */       case 0:
/* 223 */         if (!hasEmptyAction || 
/* 224 */           elementVarBinding.resolvedPosition != -1) {
/* 225 */           this.collectionVariable.useFlag = 1;
/* 226 */           if (this.continueLabel != null) {
/* 227 */             this.indexVariable.useFlag = 1;
/* 228 */             this.maxVariable.useFlag = 1;
/*     */           } 
/*     */         } 
/*     */         break;
/*     */       case 1:
/*     */       case 2:
/* 234 */         this.indexVariable.useFlag = 1;
/*     */         break;
/*     */     } 
/*     */     
/* 238 */     loopingContext.complainOnDeferredNullChecks(currentScope, (FlowInfo)actionInfo);
/* 239 */     if (loopingContext.hasEscapingExceptions()) {
/* 240 */       UnconditionalFlowInfo unconditionalFlowInfo; FlowInfo loopbackFlowInfo = flowInfo.copy();
/* 241 */       if (this.continueLabel != null)
/*     */       {
/* 243 */         unconditionalFlowInfo = loopbackFlowInfo.mergedWith(loopbackFlowInfo.unconditionalCopy().addNullInfoFrom((FlowInfo)actionInfo).unconditionalInits());
/*     */       }
/* 245 */       loopingContext.simulateThrowAfterLoopBack((FlowInfo)unconditionalFlowInfo);
/*     */     } 
/*     */     
/* 248 */     UnconditionalFlowInfo unconditionalFlowInfo1 = FlowInfo.mergedOptimizedBranches(
/* 249 */         ((loopingContext.initsOnBreak.tagBits & 
/* 250 */         0x3) != 0) ? 
/* 251 */         (FlowInfo)loopingContext.initsOnBreak : 
/* 252 */         flowInfo.addInitializationsFrom((FlowInfo)loopingContext.initsOnBreak), 
/* 253 */         false, 
/* 254 */         exitBranch, 
/* 255 */         false, 
/* 256 */         true);
/* 257 */     unconditionalFlowInfo1.resetAssignmentInfo(this.elementVariable.binding);
/* 258 */     this.mergedInitStateIndex = currentScope.methodScope().recordInitializationStates((FlowInfo)unconditionalFlowInfo1);
/* 259 */     return (FlowInfo)unconditionalFlowInfo1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void generateCode(BlockScope currentScope, CodeStream codeStream) {
/* 271 */     if ((this.bits & Integer.MIN_VALUE) == 0) {
/*     */       return;
/*     */     }
/* 274 */     int pc = codeStream.position;
/* 275 */     boolean hasEmptyAction = !(this.action != null && 
/* 276 */       !this.action.isEmptyBlock() && (
/* 277 */       this.action.bits & 0x1) == 0);
/*     */     
/* 279 */     if (hasEmptyAction && 
/* 280 */       this.elementVariable.binding.resolvedPosition == -1 && 
/* 281 */       this.kind == 0) {
/* 282 */       this.collection.generateCode(this.scope, codeStream, false);
/* 283 */       codeStream.exitUserScope(this.scope);
/* 284 */       if (this.mergedInitStateIndex != -1) {
/* 285 */         codeStream.removeNotDefinitelyAssignedVariables((Scope)currentScope, this.mergedInitStateIndex);
/* 286 */         codeStream.addDefinitelyAssignedVariables((Scope)currentScope, this.mergedInitStateIndex);
/*     */       } 
/* 288 */       codeStream.recordPositionsFrom(pc, this.sourceStart);
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/* 293 */     switch (this.kind) {
/*     */       case 0:
/* 295 */         this.collection.generateCode(this.scope, codeStream, true);
/* 296 */         codeStream.store(this.collectionVariable, true);
/* 297 */         codeStream.addVariable(this.collectionVariable);
/* 298 */         if (this.continueLabel != null) {
/*     */           
/* 300 */           codeStream.arraylength();
/* 301 */           codeStream.store(this.maxVariable, false);
/* 302 */           codeStream.addVariable(this.maxVariable);
/* 303 */           codeStream.iconst_0();
/* 304 */           codeStream.store(this.indexVariable, false);
/* 305 */           codeStream.addVariable(this.indexVariable);
/*     */         } 
/*     */         break;
/*     */ 
/*     */       
/*     */       case 1:
/*     */       case 2:
/* 312 */         this.collection.generateCode(this.scope, codeStream, true);
/*     */         
/* 314 */         codeStream.invokeIterableIterator(this.iteratorReceiverType);
/* 315 */         codeStream.store(this.indexVariable, false);
/* 316 */         codeStream.addVariable(this.indexVariable);
/*     */         break;
/*     */     } 
/*     */     
/* 320 */     BranchLabel actionLabel = new BranchLabel(codeStream);
/* 321 */     actionLabel.tagBits |= 0x2;
/* 322 */     BranchLabel conditionLabel = new BranchLabel(codeStream);
/* 323 */     conditionLabel.tagBits |= 0x2;
/* 324 */     this.breakLabel.initialize(codeStream);
/* 325 */     if (this.continueLabel == null) {
/*     */       
/* 327 */       conditionLabel.place();
/* 328 */       int conditionPC = codeStream.position;
/* 329 */       switch (this.kind) {
/*     */ 
/*     */         
/*     */         case 0:
/* 333 */           codeStream.arraylength();
/* 334 */           codeStream.ifeq(this.breakLabel);
/*     */           break;
/*     */         case 1:
/*     */         case 2:
/* 338 */           codeStream.load(this.indexVariable);
/* 339 */           codeStream.invokeJavaUtilIteratorHasNext();
/* 340 */           codeStream.ifeq(this.breakLabel);
/*     */           break;
/*     */       } 
/* 343 */       codeStream.recordPositionsFrom(conditionPC, this.elementVariable.sourceStart);
/*     */     } else {
/* 345 */       this.continueLabel.initialize(codeStream);
/* 346 */       this.continueLabel.tagBits |= 0x2;
/*     */       
/* 348 */       codeStream.goto_(conditionLabel);
/*     */     } 
/*     */ 
/*     */     
/* 352 */     actionLabel.place();
/*     */ 
/*     */     
/* 355 */     switch (this.kind) {
/*     */       case 0:
/* 357 */         if (this.elementVariable.binding.resolvedPosition != -1) {
/* 358 */           codeStream.load(this.collectionVariable);
/* 359 */           if (this.continueLabel == null) {
/* 360 */             codeStream.iconst_0();
/*     */           } else {
/* 362 */             codeStream.load(this.indexVariable);
/*     */           } 
/* 364 */           codeStream.arrayAt(this.collectionElementType.id);
/* 365 */           if (this.elementVariableImplicitWidening != -1) {
/* 366 */             codeStream.generateImplicitConversion(this.elementVariableImplicitWidening);
/*     */           }
/* 368 */           codeStream.store(this.elementVariable.binding, false);
/* 369 */           codeStream.addVisibleLocalVariable(this.elementVariable.binding);
/* 370 */           if (this.postCollectionInitStateIndex != -1) {
/* 371 */             codeStream.addDefinitelyAssignedVariables(
/* 372 */                 (Scope)currentScope, 
/* 373 */                 this.postCollectionInitStateIndex);
/*     */           }
/*     */         } 
/*     */         break;
/*     */       case 1:
/*     */       case 2:
/* 379 */         codeStream.load(this.indexVariable);
/* 380 */         codeStream.invokeJavaUtilIteratorNext();
/* 381 */         if (this.elementVariable.binding.type.id != 1) {
/* 382 */           if (this.elementVariableImplicitWidening != -1) {
/* 383 */             codeStream.checkcast(this.collectionElementType);
/* 384 */             codeStream.generateImplicitConversion(this.elementVariableImplicitWidening);
/*     */           } else {
/* 386 */             codeStream.checkcast(this.elementVariable.binding.type);
/*     */           } 
/*     */         }
/* 389 */         if (this.elementVariable.binding.resolvedPosition == -1) {
/* 390 */           switch (this.elementVariable.binding.type.id) {
/*     */             case 7:
/*     */             case 8:
/* 393 */               codeStream.pop2();
/*     */               break;
/*     */           } 
/* 396 */           codeStream.pop();
/*     */           
/*     */           break;
/*     */         } 
/* 400 */         codeStream.store(this.elementVariable.binding, false);
/* 401 */         codeStream.addVisibleLocalVariable(this.elementVariable.binding);
/* 402 */         if (this.postCollectionInitStateIndex != -1) {
/* 403 */           codeStream.addDefinitelyAssignedVariables(
/* 404 */               (Scope)currentScope, 
/* 405 */               this.postCollectionInitStateIndex);
/*     */         }
/*     */         break;
/*     */     } 
/*     */ 
/*     */     
/* 411 */     if (!hasEmptyAction) {
/* 412 */       this.action.generateCode(this.scope, codeStream);
/*     */     }
/* 414 */     codeStream.removeVariable(this.elementVariable.binding);
/* 415 */     if (this.postCollectionInitStateIndex != -1) {
/* 416 */       codeStream.removeNotDefinitelyAssignedVariables((Scope)currentScope, this.postCollectionInitStateIndex);
/*     */     }
/*     */     
/* 419 */     if (this.continueLabel != null) {
/* 420 */       this.continueLabel.place();
/* 421 */       int continuationPC = codeStream.position;
/*     */       
/* 423 */       switch (this.kind) {
/*     */         case 0:
/* 425 */           if (!hasEmptyAction || this.elementVariable.binding.resolvedPosition >= 0) {
/* 426 */             codeStream.iinc(this.indexVariable.resolvedPosition, 1);
/*     */           }
/*     */           
/* 429 */           conditionLabel.place();
/* 430 */           codeStream.load(this.indexVariable);
/* 431 */           codeStream.load(this.maxVariable);
/* 432 */           codeStream.if_icmplt(actionLabel);
/*     */           break;
/*     */         
/*     */         case 1:
/*     */         case 2:
/* 437 */           conditionLabel.place();
/* 438 */           codeStream.load(this.indexVariable);
/* 439 */           codeStream.invokeJavaUtilIteratorHasNext();
/* 440 */           codeStream.ifne(actionLabel);
/*     */           break;
/*     */       } 
/* 443 */       codeStream.recordPositionsFrom(continuationPC, this.elementVariable.sourceStart);
/*     */     } 
/* 445 */     switch (this.kind) {
/*     */       case 0:
/* 447 */         codeStream.removeVariable(this.indexVariable);
/* 448 */         codeStream.removeVariable(this.maxVariable);
/* 449 */         codeStream.removeVariable(this.collectionVariable);
/*     */         break;
/*     */       
/*     */       case 1:
/*     */       case 2:
/* 454 */         codeStream.removeVariable(this.indexVariable);
/*     */         break;
/*     */     } 
/* 457 */     codeStream.exitUserScope(this.scope);
/* 458 */     if (this.mergedInitStateIndex != -1) {
/* 459 */       codeStream.removeNotDefinitelyAssignedVariables((Scope)currentScope, this.mergedInitStateIndex);
/* 460 */       codeStream.addDefinitelyAssignedVariables((Scope)currentScope, this.mergedInitStateIndex);
/*     */     } 
/* 462 */     this.breakLabel.place();
/* 463 */     codeStream.recordPositionsFrom(pc, this.sourceStart);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public StringBuffer printStatement(int indent, StringBuffer output) {
/* 469 */     printIndent(indent, output).append("for (");
/* 470 */     if (this.pattern != null) {
/* 471 */       this.pattern.printExpression(0, output);
/*     */     } else {
/* 473 */       this.elementVariable.printAsExpression(0, output);
/*     */     } 
/* 475 */     output.append(" : ");
/* 476 */     if (this.collection != null) {
/* 477 */       this.collection.print(0, output).append(") ");
/*     */     } else {
/* 479 */       output.append(')');
/*     */     } 
/*     */     
/* 482 */     if (this.action == null) {
/* 483 */       output.append(';');
/*     */     } else {
/* 485 */       output.append('\n');
/* 486 */       this.action.printStatement(indent + 1, output);
/*     */     } 
/* 488 */     return output;
/*     */   }
/*     */   
/*     */   public static TypeBinding getCollectionElementType(BlockScope scope, TypeBinding collectionType) {
/* 492 */     if (collectionType == null) return null;
/*     */     
/* 494 */     boolean isTargetJsr14 = ((scope.compilerOptions()).targetJDK == 3145728L);
/* 495 */     if (collectionType.isCapture()) {
/* 496 */       TypeBinding upperBound = ((CaptureBinding)collectionType).firstBound;
/* 497 */       if (upperBound != null && upperBound.isArrayType())
/* 498 */         collectionType = upperBound; 
/*     */     } 
/* 500 */     if (collectionType.isArrayType())
/* 501 */       return ((ArrayBinding)collectionType).elementsType(); 
/* 502 */     if (collectionType instanceof ReferenceBinding) {
/* 503 */       TypeVariableBinding[] arrayOfTypeVariableBinding; TypeBinding[] arrayOfTypeBinding1; ReferenceBinding iterableType = ((ReferenceBinding)collectionType).findSuperTypeOriginatingFrom(38, false);
/* 504 */       if (iterableType == null && isTargetJsr14) {
/* 505 */         iterableType = ((ReferenceBinding)collectionType).findSuperTypeOriginatingFrom(59, false);
/*     */       }
/* 507 */       if (iterableType == null) return null;
/*     */       
/* 509 */       TypeBinding[] arguments = null;
/* 510 */       switch (iterableType.kind()) {
/*     */         case 1028:
/* 512 */           return (TypeBinding)scope.getJavaLangObject();
/*     */         
/*     */         case 2052:
/* 515 */           arrayOfTypeVariableBinding = iterableType.typeVariables();
/*     */           break;
/*     */         
/*     */         case 260:
/* 519 */           arrayOfTypeBinding1 = ((ParameterizedTypeBinding)iterableType).arguments;
/*     */           break;
/*     */         
/*     */         default:
/* 523 */           return null;
/*     */       } 
/*     */       
/* 526 */       if (arrayOfTypeBinding1.length != 1) return null; 
/* 527 */       return arrayOfTypeBinding1[0];
/*     */     } 
/* 529 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void resolve(BlockScope upperScope) {
/*     */     // Byte code:
/*     */     //   0: aload_0
/*     */     //   1: new org/eclipse/jdt/internal/compiler/lookup/BlockScope
/*     */     //   4: dup
/*     */     //   5: aload_1
/*     */     //   6: invokespecial <init> : (Lorg/eclipse/jdt/internal/compiler/lookup/BlockScope;)V
/*     */     //   9: putfield scope : Lorg/eclipse/jdt/internal/compiler/lookup/BlockScope;
/*     */     //   12: aload_0
/*     */     //   13: getfield scope : Lorg/eclipse/jdt/internal/compiler/lookup/BlockScope;
/*     */     //   16: aload_0
/*     */     //   17: putfield blockStatement : Lorg/eclipse/jdt/internal/compiler/ast/Statement;
/*     */     //   20: aload_0
/*     */     //   21: getfield elementVariable : Lorg/eclipse/jdt/internal/compiler/ast/LocalDeclaration;
/*     */     //   24: aload_0
/*     */     //   25: getfield scope : Lorg/eclipse/jdt/internal/compiler/lookup/BlockScope;
/*     */     //   28: invokevirtual resolve : (Lorg/eclipse/jdt/internal/compiler/lookup/BlockScope;)V
/*     */     //   31: aconst_null
/*     */     //   32: astore_2
/*     */     //   33: aload_0
/*     */     //   34: getfield pattern : Lorg/eclipse/jdt/internal/compiler/ast/RecordPattern;
/*     */     //   37: ifnull -> 82
/*     */     //   40: aload_1
/*     */     //   41: invokevirtual compilerOptions : ()Lorg/eclipse/jdt/internal/compiler/impl/CompilerOptions;
/*     */     //   44: getfield enablePreviewFeatures : Z
/*     */     //   47: ifne -> 51
/*     */     //   50: return
/*     */     //   51: aload_0
/*     */     //   52: getfield pattern : Lorg/eclipse/jdt/internal/compiler/ast/RecordPattern;
/*     */     //   55: aconst_null
/*     */     //   56: aload_0
/*     */     //   57: getfield scope : Lorg/eclipse/jdt/internal/compiler/lookup/BlockScope;
/*     */     //   60: invokevirtual collectPatternVariablesToScope : ([Lorg/eclipse/jdt/internal/compiler/lookup/LocalVariableBinding;Lorg/eclipse/jdt/internal/compiler/lookup/BlockScope;)V
/*     */     //   63: aload_0
/*     */     //   64: getfield pattern : Lorg/eclipse/jdt/internal/compiler/ast/RecordPattern;
/*     */     //   67: invokevirtual getPatternVariablesWhenTrue : ()[Lorg/eclipse/jdt/internal/compiler/lookup/LocalVariableBinding;
/*     */     //   70: astore_2
/*     */     //   71: aload_0
/*     */     //   72: getfield pattern : Lorg/eclipse/jdt/internal/compiler/ast/RecordPattern;
/*     */     //   75: aload_0
/*     */     //   76: getfield scope : Lorg/eclipse/jdt/internal/compiler/lookup/BlockScope;
/*     */     //   79: invokevirtual resolve : (Lorg/eclipse/jdt/internal/compiler/lookup/BlockScope;)V
/*     */     //   82: aload_0
/*     */     //   83: getfield elementVariable : Lorg/eclipse/jdt/internal/compiler/ast/LocalDeclaration;
/*     */     //   86: getfield type : Lorg/eclipse/jdt/internal/compiler/ast/TypeReference;
/*     */     //   89: getfield resolvedType : Lorg/eclipse/jdt/internal/compiler/lookup/TypeBinding;
/*     */     //   92: astore_3
/*     */     //   93: aload_0
/*     */     //   94: getfield collection : Lorg/eclipse/jdt/internal/compiler/ast/Expression;
/*     */     //   97: ifnonnull -> 104
/*     */     //   100: aconst_null
/*     */     //   101: goto -> 112
/*     */     //   104: aload_0
/*     */     //   105: getfield collection : Lorg/eclipse/jdt/internal/compiler/ast/Expression;
/*     */     //   108: aload_1
/*     */     //   109: invokevirtual resolveType : (Lorg/eclipse/jdt/internal/compiler/lookup/BlockScope;)Lorg/eclipse/jdt/internal/compiler/lookup/TypeBinding;
/*     */     //   112: astore #4
/*     */     //   114: aload_0
/*     */     //   115: getfield elementVariable : Lorg/eclipse/jdt/internal/compiler/ast/LocalDeclaration;
/*     */     //   118: aload_1
/*     */     //   119: invokevirtual isTypeNameVar : (Lorg/eclipse/jdt/internal/compiler/lookup/Scope;)Z
/*     */     //   122: ifeq -> 330
/*     */     //   125: aload_0
/*     */     //   126: getfield elementVariable : Lorg/eclipse/jdt/internal/compiler/ast/LocalDeclaration;
/*     */     //   129: getfield type : Lorg/eclipse/jdt/internal/compiler/ast/TypeReference;
/*     */     //   132: invokevirtual dimensions : ()I
/*     */     //   135: ifgt -> 151
/*     */     //   138: aload_0
/*     */     //   139: getfield elementVariable : Lorg/eclipse/jdt/internal/compiler/ast/LocalDeclaration;
/*     */     //   142: getfield type : Lorg/eclipse/jdt/internal/compiler/ast/TypeReference;
/*     */     //   145: invokevirtual extraDimensions : ()I
/*     */     //   148: ifle -> 162
/*     */     //   151: aload_1
/*     */     //   152: invokevirtual problemReporter : ()Lorg/eclipse/jdt/internal/compiler/problem/ProblemReporter;
/*     */     //   155: aload_0
/*     */     //   156: getfield elementVariable : Lorg/eclipse/jdt/internal/compiler/ast/LocalDeclaration;
/*     */     //   159: invokevirtual varLocalCannotBeArray : (Lorg/eclipse/jdt/internal/compiler/ast/AbstractVariableDeclaration;)V
/*     */     //   162: getstatic org/eclipse/jdt/internal/compiler/lookup/TypeBinding.NULL : Lorg/eclipse/jdt/internal/compiler/lookup/NullTypeBinding;
/*     */     //   165: aload #4
/*     */     //   167: invokestatic equalsEquals : (Lorg/eclipse/jdt/internal/compiler/lookup/TypeBinding;Lorg/eclipse/jdt/internal/compiler/lookup/TypeBinding;)Z
/*     */     //   170: ifeq -> 190
/*     */     //   173: aload_1
/*     */     //   174: invokevirtual problemReporter : ()Lorg/eclipse/jdt/internal/compiler/problem/ProblemReporter;
/*     */     //   177: aload_0
/*     */     //   178: getfield elementVariable : Lorg/eclipse/jdt/internal/compiler/ast/LocalDeclaration;
/*     */     //   181: invokevirtual varLocalInitializedToNull : (Lorg/eclipse/jdt/internal/compiler/ast/AbstractVariableDeclaration;)V
/*     */     //   184: aload #4
/*     */     //   186: astore_3
/*     */     //   187: goto -> 215
/*     */     //   190: getstatic org/eclipse/jdt/internal/compiler/lookup/TypeBinding.VOID : Lorg/eclipse/jdt/internal/compiler/lookup/VoidTypeBinding;
/*     */     //   193: aload #4
/*     */     //   195: invokestatic equalsEquals : (Lorg/eclipse/jdt/internal/compiler/lookup/TypeBinding;Lorg/eclipse/jdt/internal/compiler/lookup/TypeBinding;)Z
/*     */     //   198: ifeq -> 215
/*     */     //   201: aload_1
/*     */     //   202: invokevirtual problemReporter : ()Lorg/eclipse/jdt/internal/compiler/problem/ProblemReporter;
/*     */     //   205: aload_0
/*     */     //   206: getfield elementVariable : Lorg/eclipse/jdt/internal/compiler/ast/LocalDeclaration;
/*     */     //   209: invokevirtual varLocalInitializedToVoid : (Lorg/eclipse/jdt/internal/compiler/ast/AbstractVariableDeclaration;)V
/*     */     //   212: aload #4
/*     */     //   214: astore_3
/*     */     //   215: aload_0
/*     */     //   216: getfield scope : Lorg/eclipse/jdt/internal/compiler/lookup/BlockScope;
/*     */     //   219: aload #4
/*     */     //   221: invokestatic getCollectionElementType : (Lorg/eclipse/jdt/internal/compiler/lookup/BlockScope;Lorg/eclipse/jdt/internal/compiler/lookup/TypeBinding;)Lorg/eclipse/jdt/internal/compiler/lookup/TypeBinding;
/*     */     //   224: dup
/*     */     //   225: astore_3
/*     */     //   226: ifnonnull -> 235
/*     */     //   229: aload #4
/*     */     //   231: astore_3
/*     */     //   232: goto -> 244
/*     */     //   235: aload_0
/*     */     //   236: getfield elementVariable : Lorg/eclipse/jdt/internal/compiler/ast/LocalDeclaration;
/*     */     //   239: aload_3
/*     */     //   240: invokevirtual patchType : (Lorg/eclipse/jdt/internal/compiler/lookup/TypeBinding;)Lorg/eclipse/jdt/internal/compiler/lookup/TypeBinding;
/*     */     //   243: astore_3
/*     */     //   244: aload_3
/*     */     //   245: instanceof org/eclipse/jdt/internal/compiler/lookup/ReferenceBinding
/*     */     //   248: ifeq -> 296
/*     */     //   251: aload_3
/*     */     //   252: checkcast org/eclipse/jdt/internal/compiler/lookup/ReferenceBinding
/*     */     //   255: astore #5
/*     */     //   257: aload_3
/*     */     //   258: aload_1
/*     */     //   259: invokevirtual canBeSeenBy : (Lorg/eclipse/jdt/internal/compiler/lookup/Scope;)Z
/*     */     //   262: ifne -> 296
/*     */     //   265: aload_1
/*     */     //   266: invokevirtual problemReporter : ()Lorg/eclipse/jdt/internal/compiler/problem/ProblemReporter;
/*     */     //   269: aload_0
/*     */     //   270: getfield elementVariable : Lorg/eclipse/jdt/internal/compiler/ast/LocalDeclaration;
/*     */     //   273: new org/eclipse/jdt/internal/compiler/lookup/ProblemReferenceBinding
/*     */     //   276: dup
/*     */     //   277: bipush #46
/*     */     //   279: aload #5
/*     */     //   281: invokevirtual shortReadableName : ()[C
/*     */     //   284: invokestatic splitOn : (C[C)[[C
/*     */     //   287: aload #5
/*     */     //   289: iconst_2
/*     */     //   290: invokespecial <init> : ([[CLorg/eclipse/jdt/internal/compiler/lookup/ReferenceBinding;I)V
/*     */     //   293: invokevirtual invalidType : (Lorg/eclipse/jdt/internal/compiler/ast/ASTNode;Lorg/eclipse/jdt/internal/compiler/lookup/TypeBinding;)V
/*     */     //   296: aload_0
/*     */     //   297: getfield elementVariable : Lorg/eclipse/jdt/internal/compiler/ast/LocalDeclaration;
/*     */     //   300: getfield binding : Lorg/eclipse/jdt/internal/compiler/lookup/LocalVariableBinding;
/*     */     //   303: ifnull -> 330
/*     */     //   306: aload_0
/*     */     //   307: getfield elementVariable : Lorg/eclipse/jdt/internal/compiler/ast/LocalDeclaration;
/*     */     //   310: getfield binding : Lorg/eclipse/jdt/internal/compiler/lookup/LocalVariableBinding;
/*     */     //   313: invokevirtual isValidBinding : ()Z
/*     */     //   316: ifeq -> 330
/*     */     //   319: aload_0
/*     */     //   320: getfield elementVariable : Lorg/eclipse/jdt/internal/compiler/ast/LocalDeclaration;
/*     */     //   323: aload_0
/*     */     //   324: getfield scope : Lorg/eclipse/jdt/internal/compiler/lookup/BlockScope;
/*     */     //   327: invokevirtual validateNullAnnotations : (Lorg/eclipse/jdt/internal/compiler/lookup/BlockScope;)V
/*     */     //   330: aconst_null
/*     */     //   331: astore #5
/*     */     //   333: aload_3
/*     */     //   334: ifnull -> 1543
/*     */     //   337: aload #4
/*     */     //   339: ifnull -> 1543
/*     */     //   342: aload_0
/*     */     //   343: getfield scope : Lorg/eclipse/jdt/internal/compiler/lookup/BlockScope;
/*     */     //   346: invokevirtual compilerOptions : ()Lorg/eclipse/jdt/internal/compiler/impl/CompilerOptions;
/*     */     //   349: getfield targetJDK : J
/*     */     //   352: ldc2_w 3145728
/*     */     //   355: lcmp
/*     */     //   356: ifne -> 363
/*     */     //   359: iconst_1
/*     */     //   360: goto -> 364
/*     */     //   363: iconst_0
/*     */     //   364: istore #6
/*     */     //   366: aload #4
/*     */     //   368: invokevirtual isCapture : ()Z
/*     */     //   371: ifeq -> 401
/*     */     //   374: aload #4
/*     */     //   376: checkcast org/eclipse/jdt/internal/compiler/lookup/CaptureBinding
/*     */     //   379: getfield firstBound : Lorg/eclipse/jdt/internal/compiler/lookup/TypeBinding;
/*     */     //   382: astore #7
/*     */     //   384: aload #7
/*     */     //   386: ifnull -> 401
/*     */     //   389: aload #7
/*     */     //   391: invokevirtual isArrayType : ()Z
/*     */     //   394: ifeq -> 401
/*     */     //   397: aload #7
/*     */     //   399: astore #4
/*     */     //   401: aload #4
/*     */     //   403: invokevirtual isArrayType : ()Z
/*     */     //   406: ifeq -> 745
/*     */     //   409: aload_0
/*     */     //   410: iconst_0
/*     */     //   411: putfield kind : I
/*     */     //   414: aload_0
/*     */     //   415: aload #4
/*     */     //   417: checkcast org/eclipse/jdt/internal/compiler/lookup/ArrayBinding
/*     */     //   420: invokevirtual elementsType : ()Lorg/eclipse/jdt/internal/compiler/lookup/TypeBinding;
/*     */     //   423: putfield collectionElementType : Lorg/eclipse/jdt/internal/compiler/lookup/TypeBinding;
/*     */     //   426: aload_0
/*     */     //   427: getfield collectionElementType : Lorg/eclipse/jdt/internal/compiler/lookup/TypeBinding;
/*     */     //   430: aload_3
/*     */     //   431: invokevirtual isCompatibleWith : (Lorg/eclipse/jdt/internal/compiler/lookup/TypeBinding;)Z
/*     */     //   434: ifne -> 474
/*     */     //   437: aload_0
/*     */     //   438: getfield scope : Lorg/eclipse/jdt/internal/compiler/lookup/BlockScope;
/*     */     //   441: aload_0
/*     */     //   442: getfield collectionElementType : Lorg/eclipse/jdt/internal/compiler/lookup/TypeBinding;
/*     */     //   445: aload_3
/*     */     //   446: invokevirtual isBoxingCompatibleWith : (Lorg/eclipse/jdt/internal/compiler/lookup/TypeBinding;Lorg/eclipse/jdt/internal/compiler/lookup/TypeBinding;)Z
/*     */     //   449: ifne -> 474
/*     */     //   452: aload_0
/*     */     //   453: getfield scope : Lorg/eclipse/jdt/internal/compiler/lookup/BlockScope;
/*     */     //   456: invokevirtual problemReporter : ()Lorg/eclipse/jdt/internal/compiler/problem/ProblemReporter;
/*     */     //   459: aload_0
/*     */     //   460: getfield collection : Lorg/eclipse/jdt/internal/compiler/ast/Expression;
/*     */     //   463: aload_0
/*     */     //   464: getfield collectionElementType : Lorg/eclipse/jdt/internal/compiler/lookup/TypeBinding;
/*     */     //   467: aload_3
/*     */     //   468: invokevirtual notCompatibleTypesErrorInForeach : (Lorg/eclipse/jdt/internal/compiler/ast/Expression;Lorg/eclipse/jdt/internal/compiler/lookup/TypeBinding;Lorg/eclipse/jdt/internal/compiler/lookup/TypeBinding;)V
/*     */     //   471: goto -> 504
/*     */     //   474: aload_0
/*     */     //   475: getfield collectionElementType : Lorg/eclipse/jdt/internal/compiler/lookup/TypeBinding;
/*     */     //   478: aload_3
/*     */     //   479: invokevirtual needsUncheckedConversion : (Lorg/eclipse/jdt/internal/compiler/lookup/TypeBinding;)Z
/*     */     //   482: ifeq -> 504
/*     */     //   485: aload_0
/*     */     //   486: getfield scope : Lorg/eclipse/jdt/internal/compiler/lookup/BlockScope;
/*     */     //   489: invokevirtual problemReporter : ()Lorg/eclipse/jdt/internal/compiler/problem/ProblemReporter;
/*     */     //   492: aload_0
/*     */     //   493: getfield collection : Lorg/eclipse/jdt/internal/compiler/ast/Expression;
/*     */     //   496: aload_0
/*     */     //   497: getfield collectionElementType : Lorg/eclipse/jdt/internal/compiler/lookup/TypeBinding;
/*     */     //   500: aload_3
/*     */     //   501: invokevirtual unsafeElementTypeConversion : (Lorg/eclipse/jdt/internal/compiler/ast/Expression;Lorg/eclipse/jdt/internal/compiler/lookup/TypeBinding;Lorg/eclipse/jdt/internal/compiler/lookup/TypeBinding;)V
/*     */     //   504: aload_0
/*     */     //   505: getfield collectionElementType : Lorg/eclipse/jdt/internal/compiler/lookup/TypeBinding;
/*     */     //   508: getfield id : I
/*     */     //   511: istore #7
/*     */     //   513: aload_3
/*     */     //   514: invokevirtual isBaseType : ()Z
/*     */     //   517: ifeq -> 634
/*     */     //   520: aload_0
/*     */     //   521: getfield collection : Lorg/eclipse/jdt/internal/compiler/ast/Expression;
/*     */     //   524: aload_0
/*     */     //   525: getfield scope : Lorg/eclipse/jdt/internal/compiler/lookup/BlockScope;
/*     */     //   528: aload #4
/*     */     //   530: aload #4
/*     */     //   532: invokevirtual computeConversion : (Lorg/eclipse/jdt/internal/compiler/lookup/Scope;Lorg/eclipse/jdt/internal/compiler/lookup/TypeBinding;Lorg/eclipse/jdt/internal/compiler/lookup/TypeBinding;)V
/*     */     //   535: aload_0
/*     */     //   536: getfield collectionElementType : Lorg/eclipse/jdt/internal/compiler/lookup/TypeBinding;
/*     */     //   539: invokevirtual isBaseType : ()Z
/*     */     //   542: ifne -> 618
/*     */     //   545: aload_0
/*     */     //   546: getfield scope : Lorg/eclipse/jdt/internal/compiler/lookup/BlockScope;
/*     */     //   549: invokevirtual environment : ()Lorg/eclipse/jdt/internal/compiler/lookup/LookupEnvironment;
/*     */     //   552: aload_0
/*     */     //   553: getfield collectionElementType : Lorg/eclipse/jdt/internal/compiler/lookup/TypeBinding;
/*     */     //   556: invokevirtual computeBoxingType : (Lorg/eclipse/jdt/internal/compiler/lookup/TypeBinding;)Lorg/eclipse/jdt/internal/compiler/lookup/TypeBinding;
/*     */     //   559: getfield id : I
/*     */     //   562: istore #7
/*     */     //   564: aload_0
/*     */     //   565: sipush #1024
/*     */     //   568: putfield elementVariableImplicitWidening : I
/*     */     //   571: aload_3
/*     */     //   572: invokevirtual isBaseType : ()Z
/*     */     //   575: ifeq -> 1280
/*     */     //   578: aload_0
/*     */     //   579: dup
/*     */     //   580: getfield elementVariableImplicitWidening : I
/*     */     //   583: aload_3
/*     */     //   584: getfield id : I
/*     */     //   587: iconst_4
/*     */     //   588: ishl
/*     */     //   589: iload #7
/*     */     //   591: iadd
/*     */     //   592: ior
/*     */     //   593: putfield elementVariableImplicitWidening : I
/*     */     //   596: aload_0
/*     */     //   597: getfield scope : Lorg/eclipse/jdt/internal/compiler/lookup/BlockScope;
/*     */     //   600: invokevirtual problemReporter : ()Lorg/eclipse/jdt/internal/compiler/problem/ProblemReporter;
/*     */     //   603: aload_0
/*     */     //   604: getfield collection : Lorg/eclipse/jdt/internal/compiler/ast/Expression;
/*     */     //   607: aload_0
/*     */     //   608: getfield collectionElementType : Lorg/eclipse/jdt/internal/compiler/lookup/TypeBinding;
/*     */     //   611: aload_3
/*     */     //   612: invokevirtual autoboxing : (Lorg/eclipse/jdt/internal/compiler/ast/Expression;Lorg/eclipse/jdt/internal/compiler/lookup/TypeBinding;Lorg/eclipse/jdt/internal/compiler/lookup/TypeBinding;)V
/*     */     //   615: goto -> 1280
/*     */     //   618: aload_0
/*     */     //   619: aload_3
/*     */     //   620: getfield id : I
/*     */     //   623: iconst_4
/*     */     //   624: ishl
/*     */     //   625: iload #7
/*     */     //   627: iadd
/*     */     //   628: putfield elementVariableImplicitWidening : I
/*     */     //   631: goto -> 1280
/*     */     //   634: aload_0
/*     */     //   635: getfield collectionElementType : Lorg/eclipse/jdt/internal/compiler/lookup/TypeBinding;
/*     */     //   638: invokevirtual isBaseType : ()Z
/*     */     //   641: ifeq -> 719
/*     */     //   644: aload_0
/*     */     //   645: getfield collection : Lorg/eclipse/jdt/internal/compiler/ast/Expression;
/*     */     //   648: aload_0
/*     */     //   649: getfield scope : Lorg/eclipse/jdt/internal/compiler/lookup/BlockScope;
/*     */     //   652: aload #4
/*     */     //   654: aload #4
/*     */     //   656: invokevirtual computeConversion : (Lorg/eclipse/jdt/internal/compiler/lookup/Scope;Lorg/eclipse/jdt/internal/compiler/lookup/TypeBinding;Lorg/eclipse/jdt/internal/compiler/lookup/TypeBinding;)V
/*     */     //   659: aload_0
/*     */     //   660: getfield scope : Lorg/eclipse/jdt/internal/compiler/lookup/BlockScope;
/*     */     //   663: invokevirtual environment : ()Lorg/eclipse/jdt/internal/compiler/lookup/LookupEnvironment;
/*     */     //   666: aload_0
/*     */     //   667: getfield collectionElementType : Lorg/eclipse/jdt/internal/compiler/lookup/TypeBinding;
/*     */     //   670: invokevirtual computeBoxingType : (Lorg/eclipse/jdt/internal/compiler/lookup/TypeBinding;)Lorg/eclipse/jdt/internal/compiler/lookup/TypeBinding;
/*     */     //   673: getfield id : I
/*     */     //   676: istore #8
/*     */     //   678: aload_0
/*     */     //   679: sipush #512
/*     */     //   682: iload #7
/*     */     //   684: iconst_4
/*     */     //   685: ishl
/*     */     //   686: ior
/*     */     //   687: iload #7
/*     */     //   689: ior
/*     */     //   690: putfield elementVariableImplicitWidening : I
/*     */     //   693: iload #8
/*     */     //   695: istore #7
/*     */     //   697: aload_0
/*     */     //   698: getfield scope : Lorg/eclipse/jdt/internal/compiler/lookup/BlockScope;
/*     */     //   701: invokevirtual problemReporter : ()Lorg/eclipse/jdt/internal/compiler/problem/ProblemReporter;
/*     */     //   704: aload_0
/*     */     //   705: getfield collection : Lorg/eclipse/jdt/internal/compiler/ast/Expression;
/*     */     //   708: aload_0
/*     */     //   709: getfield collectionElementType : Lorg/eclipse/jdt/internal/compiler/lookup/TypeBinding;
/*     */     //   712: aload_3
/*     */     //   713: invokevirtual autoboxing : (Lorg/eclipse/jdt/internal/compiler/ast/Expression;Lorg/eclipse/jdt/internal/compiler/lookup/TypeBinding;Lorg/eclipse/jdt/internal/compiler/lookup/TypeBinding;)V
/*     */     //   716: goto -> 1280
/*     */     //   719: aload_1
/*     */     //   720: aload_3
/*     */     //   721: iconst_1
/*     */     //   722: invokevirtual createArrayType : (Lorg/eclipse/jdt/internal/compiler/lookup/TypeBinding;I)Lorg/eclipse/jdt/internal/compiler/lookup/ArrayBinding;
/*     */     //   725: astore #5
/*     */     //   727: aload_0
/*     */     //   728: getfield collection : Lorg/eclipse/jdt/internal/compiler/ast/Expression;
/*     */     //   731: aload_0
/*     */     //   732: getfield scope : Lorg/eclipse/jdt/internal/compiler/lookup/BlockScope;
/*     */     //   735: aload #5
/*     */     //   737: aload #4
/*     */     //   739: invokevirtual computeConversion : (Lorg/eclipse/jdt/internal/compiler/lookup/Scope;Lorg/eclipse/jdt/internal/compiler/lookup/TypeBinding;Lorg/eclipse/jdt/internal/compiler/lookup/TypeBinding;)V
/*     */     //   742: goto -> 1280
/*     */     //   745: aload #4
/*     */     //   747: instanceof org/eclipse/jdt/internal/compiler/lookup/ReferenceBinding
/*     */     //   750: ifeq -> 1280
/*     */     //   753: aload #4
/*     */     //   755: checkcast org/eclipse/jdt/internal/compiler/lookup/ReferenceBinding
/*     */     //   758: bipush #38
/*     */     //   760: iconst_0
/*     */     //   761: invokevirtual findSuperTypeOriginatingFrom : (IZ)Lorg/eclipse/jdt/internal/compiler/lookup/ReferenceBinding;
/*     */     //   764: astore #7
/*     */     //   766: aload #7
/*     */     //   768: ifnonnull -> 789
/*     */     //   771: iload #6
/*     */     //   773: ifeq -> 789
/*     */     //   776: aload #4
/*     */     //   778: checkcast org/eclipse/jdt/internal/compiler/lookup/ReferenceBinding
/*     */     //   781: bipush #59
/*     */     //   783: iconst_0
/*     */     //   784: invokevirtual findSuperTypeOriginatingFrom : (IZ)Lorg/eclipse/jdt/internal/compiler/lookup/ReferenceBinding;
/*     */     //   787: astore #7
/*     */     //   789: aload #7
/*     */     //   791: ifnonnull -> 797
/*     */     //   794: goto -> 1280
/*     */     //   797: aload_0
/*     */     //   798: aload #4
/*     */     //   800: invokevirtual erasure : ()Lorg/eclipse/jdt/internal/compiler/lookup/TypeBinding;
/*     */     //   803: putfield iteratorReceiverType : Lorg/eclipse/jdt/internal/compiler/lookup/TypeBinding;
/*     */     //   806: iload #6
/*     */     //   808: ifeq -> 869
/*     */     //   811: aload_0
/*     */     //   812: getfield iteratorReceiverType : Lorg/eclipse/jdt/internal/compiler/lookup/TypeBinding;
/*     */     //   815: checkcast org/eclipse/jdt/internal/compiler/lookup/ReferenceBinding
/*     */     //   818: bipush #59
/*     */     //   820: iconst_0
/*     */     //   821: invokevirtual findSuperTypeOriginatingFrom : (IZ)Lorg/eclipse/jdt/internal/compiler/lookup/ReferenceBinding;
/*     */     //   824: ifnonnull -> 851
/*     */     //   827: aload_0
/*     */     //   828: aload #7
/*     */     //   830: putfield iteratorReceiverType : Lorg/eclipse/jdt/internal/compiler/lookup/TypeBinding;
/*     */     //   833: aload_0
/*     */     //   834: getfield collection : Lorg/eclipse/jdt/internal/compiler/ast/Expression;
/*     */     //   837: aload_0
/*     */     //   838: getfield scope : Lorg/eclipse/jdt/internal/compiler/lookup/BlockScope;
/*     */     //   841: aload #7
/*     */     //   843: aload #4
/*     */     //   845: invokevirtual computeConversion : (Lorg/eclipse/jdt/internal/compiler/lookup/Scope;Lorg/eclipse/jdt/internal/compiler/lookup/TypeBinding;Lorg/eclipse/jdt/internal/compiler/lookup/TypeBinding;)V
/*     */     //   848: goto -> 924
/*     */     //   851: aload_0
/*     */     //   852: getfield collection : Lorg/eclipse/jdt/internal/compiler/ast/Expression;
/*     */     //   855: aload_0
/*     */     //   856: getfield scope : Lorg/eclipse/jdt/internal/compiler/lookup/BlockScope;
/*     */     //   859: aload #4
/*     */     //   861: aload #4
/*     */     //   863: invokevirtual computeConversion : (Lorg/eclipse/jdt/internal/compiler/lookup/Scope;Lorg/eclipse/jdt/internal/compiler/lookup/TypeBinding;Lorg/eclipse/jdt/internal/compiler/lookup/TypeBinding;)V
/*     */     //   866: goto -> 924
/*     */     //   869: aload_0
/*     */     //   870: getfield iteratorReceiverType : Lorg/eclipse/jdt/internal/compiler/lookup/TypeBinding;
/*     */     //   873: checkcast org/eclipse/jdt/internal/compiler/lookup/ReferenceBinding
/*     */     //   876: bipush #38
/*     */     //   878: iconst_0
/*     */     //   879: invokevirtual findSuperTypeOriginatingFrom : (IZ)Lorg/eclipse/jdt/internal/compiler/lookup/ReferenceBinding;
/*     */     //   882: ifnonnull -> 909
/*     */     //   885: aload_0
/*     */     //   886: aload #7
/*     */     //   888: putfield iteratorReceiverType : Lorg/eclipse/jdt/internal/compiler/lookup/TypeBinding;
/*     */     //   891: aload_0
/*     */     //   892: getfield collection : Lorg/eclipse/jdt/internal/compiler/ast/Expression;
/*     */     //   895: aload_0
/*     */     //   896: getfield scope : Lorg/eclipse/jdt/internal/compiler/lookup/BlockScope;
/*     */     //   899: aload #7
/*     */     //   901: aload #4
/*     */     //   903: invokevirtual computeConversion : (Lorg/eclipse/jdt/internal/compiler/lookup/Scope;Lorg/eclipse/jdt/internal/compiler/lookup/TypeBinding;Lorg/eclipse/jdt/internal/compiler/lookup/TypeBinding;)V
/*     */     //   906: goto -> 924
/*     */     //   909: aload_0
/*     */     //   910: getfield collection : Lorg/eclipse/jdt/internal/compiler/ast/Expression;
/*     */     //   913: aload_0
/*     */     //   914: getfield scope : Lorg/eclipse/jdt/internal/compiler/lookup/BlockScope;
/*     */     //   917: aload #4
/*     */     //   919: aload #4
/*     */     //   921: invokevirtual computeConversion : (Lorg/eclipse/jdt/internal/compiler/lookup/Scope;Lorg/eclipse/jdt/internal/compiler/lookup/TypeBinding;Lorg/eclipse/jdt/internal/compiler/lookup/TypeBinding;)V
/*     */     //   924: aconst_null
/*     */     //   925: astore #8
/*     */     //   927: aload #7
/*     */     //   929: invokevirtual kind : ()I
/*     */     //   932: lookupswitch default -> 1055, 260 -> 1042, 1028 -> 968, 2052 -> 1032
/*     */     //   968: aload_0
/*     */     //   969: iconst_1
/*     */     //   970: putfield kind : I
/*     */     //   973: aload_0
/*     */     //   974: aload_0
/*     */     //   975: getfield scope : Lorg/eclipse/jdt/internal/compiler/lookup/BlockScope;
/*     */     //   978: invokevirtual getJavaLangObject : ()Lorg/eclipse/jdt/internal/compiler/lookup/ReferenceBinding;
/*     */     //   981: putfield collectionElementType : Lorg/eclipse/jdt/internal/compiler/lookup/TypeBinding;
/*     */     //   984: aload_0
/*     */     //   985: getfield collectionElementType : Lorg/eclipse/jdt/internal/compiler/lookup/TypeBinding;
/*     */     //   988: aload_3
/*     */     //   989: invokevirtual isCompatibleWith : (Lorg/eclipse/jdt/internal/compiler/lookup/TypeBinding;)Z
/*     */     //   992: ifne -> 1280
/*     */     //   995: aload_0
/*     */     //   996: getfield scope : Lorg/eclipse/jdt/internal/compiler/lookup/BlockScope;
/*     */     //   999: aload_0
/*     */     //   1000: getfield collectionElementType : Lorg/eclipse/jdt/internal/compiler/lookup/TypeBinding;
/*     */     //   1003: aload_3
/*     */     //   1004: invokevirtual isBoxingCompatibleWith : (Lorg/eclipse/jdt/internal/compiler/lookup/TypeBinding;Lorg/eclipse/jdt/internal/compiler/lookup/TypeBinding;)Z
/*     */     //   1007: ifne -> 1280
/*     */     //   1010: aload_0
/*     */     //   1011: getfield scope : Lorg/eclipse/jdt/internal/compiler/lookup/BlockScope;
/*     */     //   1014: invokevirtual problemReporter : ()Lorg/eclipse/jdt/internal/compiler/problem/ProblemReporter;
/*     */     //   1017: aload_0
/*     */     //   1018: getfield collection : Lorg/eclipse/jdt/internal/compiler/ast/Expression;
/*     */     //   1021: aload_0
/*     */     //   1022: getfield collectionElementType : Lorg/eclipse/jdt/internal/compiler/lookup/TypeBinding;
/*     */     //   1025: aload_3
/*     */     //   1026: invokevirtual notCompatibleTypesErrorInForeach : (Lorg/eclipse/jdt/internal/compiler/ast/Expression;Lorg/eclipse/jdt/internal/compiler/lookup/TypeBinding;Lorg/eclipse/jdt/internal/compiler/lookup/TypeBinding;)V
/*     */     //   1029: goto -> 1280
/*     */     //   1032: aload #7
/*     */     //   1034: invokevirtual typeVariables : ()[Lorg/eclipse/jdt/internal/compiler/lookup/TypeVariableBinding;
/*     */     //   1037: astore #8
/*     */     //   1039: goto -> 1058
/*     */     //   1042: aload #7
/*     */     //   1044: checkcast org/eclipse/jdt/internal/compiler/lookup/ParameterizedTypeBinding
/*     */     //   1047: getfield arguments : [Lorg/eclipse/jdt/internal/compiler/lookup/TypeBinding;
/*     */     //   1050: astore #8
/*     */     //   1052: goto -> 1058
/*     */     //   1055: goto -> 1280
/*     */     //   1058: aload #8
/*     */     //   1060: arraylength
/*     */     //   1061: iconst_1
/*     */     //   1062: if_icmpeq -> 1068
/*     */     //   1065: goto -> 1280
/*     */     //   1068: aload_0
/*     */     //   1069: iconst_2
/*     */     //   1070: putfield kind : I
/*     */     //   1073: aload_0
/*     */     //   1074: aload #8
/*     */     //   1076: iconst_0
/*     */     //   1077: aaload
/*     */     //   1078: putfield collectionElementType : Lorg/eclipse/jdt/internal/compiler/lookup/TypeBinding;
/*     */     //   1081: aload_0
/*     */     //   1082: getfield collectionElementType : Lorg/eclipse/jdt/internal/compiler/lookup/TypeBinding;
/*     */     //   1085: aload_3
/*     */     //   1086: invokevirtual isCompatibleWith : (Lorg/eclipse/jdt/internal/compiler/lookup/TypeBinding;)Z
/*     */     //   1089: ifne -> 1129
/*     */     //   1092: aload_0
/*     */     //   1093: getfield scope : Lorg/eclipse/jdt/internal/compiler/lookup/BlockScope;
/*     */     //   1096: aload_0
/*     */     //   1097: getfield collectionElementType : Lorg/eclipse/jdt/internal/compiler/lookup/TypeBinding;
/*     */     //   1100: aload_3
/*     */     //   1101: invokevirtual isBoxingCompatibleWith : (Lorg/eclipse/jdt/internal/compiler/lookup/TypeBinding;Lorg/eclipse/jdt/internal/compiler/lookup/TypeBinding;)Z
/*     */     //   1104: ifne -> 1129
/*     */     //   1107: aload_0
/*     */     //   1108: getfield scope : Lorg/eclipse/jdt/internal/compiler/lookup/BlockScope;
/*     */     //   1111: invokevirtual problemReporter : ()Lorg/eclipse/jdt/internal/compiler/problem/ProblemReporter;
/*     */     //   1114: aload_0
/*     */     //   1115: getfield collection : Lorg/eclipse/jdt/internal/compiler/ast/Expression;
/*     */     //   1118: aload_0
/*     */     //   1119: getfield collectionElementType : Lorg/eclipse/jdt/internal/compiler/lookup/TypeBinding;
/*     */     //   1122: aload_3
/*     */     //   1123: invokevirtual notCompatibleTypesErrorInForeach : (Lorg/eclipse/jdt/internal/compiler/ast/Expression;Lorg/eclipse/jdt/internal/compiler/lookup/TypeBinding;Lorg/eclipse/jdt/internal/compiler/lookup/TypeBinding;)V
/*     */     //   1126: goto -> 1159
/*     */     //   1129: aload_0
/*     */     //   1130: getfield collectionElementType : Lorg/eclipse/jdt/internal/compiler/lookup/TypeBinding;
/*     */     //   1133: aload_3
/*     */     //   1134: invokevirtual needsUncheckedConversion : (Lorg/eclipse/jdt/internal/compiler/lookup/TypeBinding;)Z
/*     */     //   1137: ifeq -> 1159
/*     */     //   1140: aload_0
/*     */     //   1141: getfield scope : Lorg/eclipse/jdt/internal/compiler/lookup/BlockScope;
/*     */     //   1144: invokevirtual problemReporter : ()Lorg/eclipse/jdt/internal/compiler/problem/ProblemReporter;
/*     */     //   1147: aload_0
/*     */     //   1148: getfield collection : Lorg/eclipse/jdt/internal/compiler/ast/Expression;
/*     */     //   1151: aload_0
/*     */     //   1152: getfield collectionElementType : Lorg/eclipse/jdt/internal/compiler/lookup/TypeBinding;
/*     */     //   1155: aload_3
/*     */     //   1156: invokevirtual unsafeElementTypeConversion : (Lorg/eclipse/jdt/internal/compiler/ast/Expression;Lorg/eclipse/jdt/internal/compiler/lookup/TypeBinding;Lorg/eclipse/jdt/internal/compiler/lookup/TypeBinding;)V
/*     */     //   1159: aload_0
/*     */     //   1160: getfield collectionElementType : Lorg/eclipse/jdt/internal/compiler/lookup/TypeBinding;
/*     */     //   1163: getfield id : I
/*     */     //   1166: istore #9
/*     */     //   1168: aload_3
/*     */     //   1169: invokevirtual isBaseType : ()Z
/*     */     //   1172: ifeq -> 1255
/*     */     //   1175: aload_0
/*     */     //   1176: getfield collectionElementType : Lorg/eclipse/jdt/internal/compiler/lookup/TypeBinding;
/*     */     //   1179: invokevirtual isBaseType : ()Z
/*     */     //   1182: ifne -> 1239
/*     */     //   1185: aload_0
/*     */     //   1186: getfield scope : Lorg/eclipse/jdt/internal/compiler/lookup/BlockScope;
/*     */     //   1189: invokevirtual environment : ()Lorg/eclipse/jdt/internal/compiler/lookup/LookupEnvironment;
/*     */     //   1192: aload_0
/*     */     //   1193: getfield collectionElementType : Lorg/eclipse/jdt/internal/compiler/lookup/TypeBinding;
/*     */     //   1196: invokevirtual computeBoxingType : (Lorg/eclipse/jdt/internal/compiler/lookup/TypeBinding;)Lorg/eclipse/jdt/internal/compiler/lookup/TypeBinding;
/*     */     //   1199: getfield id : I
/*     */     //   1202: istore #9
/*     */     //   1204: aload_0
/*     */     //   1205: sipush #1024
/*     */     //   1208: putfield elementVariableImplicitWidening : I
/*     */     //   1211: aload_3
/*     */     //   1212: invokevirtual isBaseType : ()Z
/*     */     //   1215: ifeq -> 1280
/*     */     //   1218: aload_0
/*     */     //   1219: dup
/*     */     //   1220: getfield elementVariableImplicitWidening : I
/*     */     //   1223: aload_3
/*     */     //   1224: getfield id : I
/*     */     //   1227: iconst_4
/*     */     //   1228: ishl
/*     */     //   1229: iload #9
/*     */     //   1231: iadd
/*     */     //   1232: ior
/*     */     //   1233: putfield elementVariableImplicitWidening : I
/*     */     //   1236: goto -> 1280
/*     */     //   1239: aload_0
/*     */     //   1240: aload_3
/*     */     //   1241: getfield id : I
/*     */     //   1244: iconst_4
/*     */     //   1245: ishl
/*     */     //   1246: iload #9
/*     */     //   1248: iadd
/*     */     //   1249: putfield elementVariableImplicitWidening : I
/*     */     //   1252: goto -> 1280
/*     */     //   1255: aload_0
/*     */     //   1256: getfield collectionElementType : Lorg/eclipse/jdt/internal/compiler/lookup/TypeBinding;
/*     */     //   1259: invokevirtual isBaseType : ()Z
/*     */     //   1262: ifeq -> 1280
/*     */     //   1265: aload_0
/*     */     //   1266: sipush #512
/*     */     //   1269: iload #9
/*     */     //   1271: iconst_4
/*     */     //   1272: ishl
/*     */     //   1273: ior
/*     */     //   1274: iload #9
/*     */     //   1276: ior
/*     */     //   1277: putfield elementVariableImplicitWidening : I
/*     */     //   1280: aload_0
/*     */     //   1281: getfield kind : I
/*     */     //   1284: tableswitch default -> 1507, 0 -> 1312, 1 -> 1460, 2 -> 1460
/*     */     //   1312: aload_0
/*     */     //   1313: new org/eclipse/jdt/internal/compiler/lookup/LocalVariableBinding
/*     */     //   1316: dup
/*     */     //   1317: getstatic org/eclipse/jdt/internal/compiler/ast/ForeachStatement.SecretIndexVariableName : [C
/*     */     //   1320: getstatic org/eclipse/jdt/internal/compiler/lookup/TypeBinding.INT : Lorg/eclipse/jdt/internal/compiler/lookup/BaseTypeBinding;
/*     */     //   1323: iconst_0
/*     */     //   1324: iconst_0
/*     */     //   1325: invokespecial <init> : ([CLorg/eclipse/jdt/internal/compiler/lookup/TypeBinding;IZ)V
/*     */     //   1328: putfield indexVariable : Lorg/eclipse/jdt/internal/compiler/lookup/LocalVariableBinding;
/*     */     //   1331: aload_0
/*     */     //   1332: getfield scope : Lorg/eclipse/jdt/internal/compiler/lookup/BlockScope;
/*     */     //   1335: aload_0
/*     */     //   1336: getfield indexVariable : Lorg/eclipse/jdt/internal/compiler/lookup/LocalVariableBinding;
/*     */     //   1339: invokevirtual addLocalVariable : (Lorg/eclipse/jdt/internal/compiler/lookup/LocalVariableBinding;)V
/*     */     //   1342: aload_0
/*     */     //   1343: getfield indexVariable : Lorg/eclipse/jdt/internal/compiler/lookup/LocalVariableBinding;
/*     */     //   1346: getstatic org/eclipse/jdt/internal/compiler/impl/Constant.NotAConstant : Lorg/eclipse/jdt/internal/compiler/impl/Constant;
/*     */     //   1349: invokevirtual setConstant : (Lorg/eclipse/jdt/internal/compiler/impl/Constant;)V
/*     */     //   1352: aload_0
/*     */     //   1353: new org/eclipse/jdt/internal/compiler/lookup/LocalVariableBinding
/*     */     //   1356: dup
/*     */     //   1357: getstatic org/eclipse/jdt/internal/compiler/ast/ForeachStatement.SecretMaxVariableName : [C
/*     */     //   1360: getstatic org/eclipse/jdt/internal/compiler/lookup/TypeBinding.INT : Lorg/eclipse/jdt/internal/compiler/lookup/BaseTypeBinding;
/*     */     //   1363: iconst_0
/*     */     //   1364: iconst_0
/*     */     //   1365: invokespecial <init> : ([CLorg/eclipse/jdt/internal/compiler/lookup/TypeBinding;IZ)V
/*     */     //   1368: putfield maxVariable : Lorg/eclipse/jdt/internal/compiler/lookup/LocalVariableBinding;
/*     */     //   1371: aload_0
/*     */     //   1372: getfield scope : Lorg/eclipse/jdt/internal/compiler/lookup/BlockScope;
/*     */     //   1375: aload_0
/*     */     //   1376: getfield maxVariable : Lorg/eclipse/jdt/internal/compiler/lookup/LocalVariableBinding;
/*     */     //   1379: invokevirtual addLocalVariable : (Lorg/eclipse/jdt/internal/compiler/lookup/LocalVariableBinding;)V
/*     */     //   1382: aload_0
/*     */     //   1383: getfield maxVariable : Lorg/eclipse/jdt/internal/compiler/lookup/LocalVariableBinding;
/*     */     //   1386: getstatic org/eclipse/jdt/internal/compiler/impl/Constant.NotAConstant : Lorg/eclipse/jdt/internal/compiler/impl/Constant;
/*     */     //   1389: invokevirtual setConstant : (Lorg/eclipse/jdt/internal/compiler/impl/Constant;)V
/*     */     //   1392: aload #5
/*     */     //   1394: ifnonnull -> 1418
/*     */     //   1397: aload_0
/*     */     //   1398: new org/eclipse/jdt/internal/compiler/lookup/LocalVariableBinding
/*     */     //   1401: dup
/*     */     //   1402: getstatic org/eclipse/jdt/internal/compiler/ast/ForeachStatement.SecretCollectionVariableName : [C
/*     */     //   1405: aload #4
/*     */     //   1407: iconst_0
/*     */     //   1408: iconst_0
/*     */     //   1409: invokespecial <init> : ([CLorg/eclipse/jdt/internal/compiler/lookup/TypeBinding;IZ)V
/*     */     //   1412: putfield collectionVariable : Lorg/eclipse/jdt/internal/compiler/lookup/LocalVariableBinding;
/*     */     //   1415: goto -> 1436
/*     */     //   1418: aload_0
/*     */     //   1419: new org/eclipse/jdt/internal/compiler/lookup/LocalVariableBinding
/*     */     //   1422: dup
/*     */     //   1423: getstatic org/eclipse/jdt/internal/compiler/ast/ForeachStatement.SecretCollectionVariableName : [C
/*     */     //   1426: aload #5
/*     */     //   1428: iconst_0
/*     */     //   1429: iconst_0
/*     */     //   1430: invokespecial <init> : ([CLorg/eclipse/jdt/internal/compiler/lookup/TypeBinding;IZ)V
/*     */     //   1433: putfield collectionVariable : Lorg/eclipse/jdt/internal/compiler/lookup/LocalVariableBinding;
/*     */     //   1436: aload_0
/*     */     //   1437: getfield scope : Lorg/eclipse/jdt/internal/compiler/lookup/BlockScope;
/*     */     //   1440: aload_0
/*     */     //   1441: getfield collectionVariable : Lorg/eclipse/jdt/internal/compiler/lookup/LocalVariableBinding;
/*     */     //   1444: invokevirtual addLocalVariable : (Lorg/eclipse/jdt/internal/compiler/lookup/LocalVariableBinding;)V
/*     */     //   1447: aload_0
/*     */     //   1448: getfield collectionVariable : Lorg/eclipse/jdt/internal/compiler/lookup/LocalVariableBinding;
/*     */     //   1451: getstatic org/eclipse/jdt/internal/compiler/impl/Constant.NotAConstant : Lorg/eclipse/jdt/internal/compiler/impl/Constant;
/*     */     //   1454: invokevirtual setConstant : (Lorg/eclipse/jdt/internal/compiler/impl/Constant;)V
/*     */     //   1457: goto -> 1543
/*     */     //   1460: aload_0
/*     */     //   1461: new org/eclipse/jdt/internal/compiler/lookup/LocalVariableBinding
/*     */     //   1464: dup
/*     */     //   1465: getstatic org/eclipse/jdt/internal/compiler/ast/ForeachStatement.SecretIteratorVariableName : [C
/*     */     //   1468: aload_0
/*     */     //   1469: getfield scope : Lorg/eclipse/jdt/internal/compiler/lookup/BlockScope;
/*     */     //   1472: invokevirtual getJavaUtilIterator : ()Lorg/eclipse/jdt/internal/compiler/lookup/ReferenceBinding;
/*     */     //   1475: iconst_0
/*     */     //   1476: iconst_0
/*     */     //   1477: invokespecial <init> : ([CLorg/eclipse/jdt/internal/compiler/lookup/TypeBinding;IZ)V
/*     */     //   1480: putfield indexVariable : Lorg/eclipse/jdt/internal/compiler/lookup/LocalVariableBinding;
/*     */     //   1483: aload_0
/*     */     //   1484: getfield scope : Lorg/eclipse/jdt/internal/compiler/lookup/BlockScope;
/*     */     //   1487: aload_0
/*     */     //   1488: getfield indexVariable : Lorg/eclipse/jdt/internal/compiler/lookup/LocalVariableBinding;
/*     */     //   1491: invokevirtual addLocalVariable : (Lorg/eclipse/jdt/internal/compiler/lookup/LocalVariableBinding;)V
/*     */     //   1494: aload_0
/*     */     //   1495: getfield indexVariable : Lorg/eclipse/jdt/internal/compiler/lookup/LocalVariableBinding;
/*     */     //   1498: getstatic org/eclipse/jdt/internal/compiler/impl/Constant.NotAConstant : Lorg/eclipse/jdt/internal/compiler/impl/Constant;
/*     */     //   1501: invokevirtual setConstant : (Lorg/eclipse/jdt/internal/compiler/impl/Constant;)V
/*     */     //   1504: goto -> 1543
/*     */     //   1507: iload #6
/*     */     //   1509: ifeq -> 1529
/*     */     //   1512: aload_0
/*     */     //   1513: getfield scope : Lorg/eclipse/jdt/internal/compiler/lookup/BlockScope;
/*     */     //   1516: invokevirtual problemReporter : ()Lorg/eclipse/jdt/internal/compiler/problem/ProblemReporter;
/*     */     //   1519: aload_0
/*     */     //   1520: getfield collection : Lorg/eclipse/jdt/internal/compiler/ast/Expression;
/*     */     //   1523: invokevirtual invalidTypeForCollectionTarget14 : (Lorg/eclipse/jdt/internal/compiler/ast/Expression;)V
/*     */     //   1526: goto -> 1543
/*     */     //   1529: aload_0
/*     */     //   1530: getfield scope : Lorg/eclipse/jdt/internal/compiler/lookup/BlockScope;
/*     */     //   1533: invokevirtual problemReporter : ()Lorg/eclipse/jdt/internal/compiler/problem/ProblemReporter;
/*     */     //   1536: aload_0
/*     */     //   1537: getfield collection : Lorg/eclipse/jdt/internal/compiler/ast/Expression;
/*     */     //   1540: invokevirtual invalidTypeForCollection : (Lorg/eclipse/jdt/internal/compiler/ast/Expression;)V
/*     */     //   1543: aload_0
/*     */     //   1544: getfield action : Lorg/eclipse/jdt/internal/compiler/ast/Statement;
/*     */     //   1547: ifnull -> 1562
/*     */     //   1550: aload_0
/*     */     //   1551: getfield action : Lorg/eclipse/jdt/internal/compiler/ast/Statement;
/*     */     //   1554: aload_2
/*     */     //   1555: aload_0
/*     */     //   1556: getfield scope : Lorg/eclipse/jdt/internal/compiler/lookup/BlockScope;
/*     */     //   1559: invokevirtual resolveWithPatternVariablesInScope : ([Lorg/eclipse/jdt/internal/compiler/lookup/LocalVariableBinding;Lorg/eclipse/jdt/internal/compiler/lookup/BlockScope;)V
/*     */     //   1562: return
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #534	-> 0
/*     */     //   #535	-> 12
/*     */     //   #536	-> 20
/*     */     //   #537	-> 31
/*     */     //   #539	-> 33
/*     */     //   #540	-> 40
/*     */     //   #541	-> 50
/*     */     //   #543	-> 51
/*     */     //   #544	-> 63
/*     */     //   #545	-> 71
/*     */     //   #547	-> 82
/*     */     //   #548	-> 93
/*     */     //   #551	-> 114
/*     */     //   #552	-> 125
/*     */     //   #553	-> 151
/*     */     //   #555	-> 162
/*     */     //   #556	-> 173
/*     */     //   #557	-> 184
/*     */     //   #558	-> 187
/*     */     //   #559	-> 201
/*     */     //   #560	-> 212
/*     */     //   #562	-> 215
/*     */     //   #563	-> 229
/*     */     //   #564	-> 232
/*     */     //   #565	-> 235
/*     */     //   #567	-> 244
/*     */     //   #568	-> 251
/*     */     //   #569	-> 257
/*     */     //   #570	-> 265
/*     */     //   #571	-> 273
/*     */     //   #572	-> 277
/*     */     //   #573	-> 287
/*     */     //   #574	-> 289
/*     */     //   #571	-> 290
/*     */     //   #570	-> 293
/*     */     //   #578	-> 296
/*     */     //   #579	-> 319
/*     */     //   #583	-> 330
/*     */     //   #584	-> 333
/*     */     //   #585	-> 342
/*     */     //   #586	-> 366
/*     */     //   #587	-> 374
/*     */     //   #588	-> 384
/*     */     //   #589	-> 397
/*     */     //   #591	-> 401
/*     */     //   #592	-> 409
/*     */     //   #593	-> 414
/*     */     //   #594	-> 426
/*     */     //   #595	-> 437
/*     */     //   #596	-> 452
/*     */     //   #597	-> 471
/*     */     //   #598	-> 485
/*     */     //   #601	-> 504
/*     */     //   #602	-> 513
/*     */     //   #603	-> 520
/*     */     //   #604	-> 535
/*     */     //   #605	-> 545
/*     */     //   #606	-> 564
/*     */     //   #607	-> 571
/*     */     //   #608	-> 578
/*     */     //   #609	-> 596
/*     */     //   #611	-> 615
/*     */     //   #612	-> 618
/*     */     //   #614	-> 631
/*     */     //   #615	-> 644
/*     */     //   #616	-> 659
/*     */     //   #617	-> 678
/*     */     //   #618	-> 693
/*     */     //   #619	-> 697
/*     */     //   #620	-> 716
/*     */     //   #621	-> 719
/*     */     //   #622	-> 727
/*     */     //   #624	-> 742
/*     */     //   #625	-> 753
/*     */     //   #626	-> 766
/*     */     //   #627	-> 776
/*     */     //   #630	-> 789
/*     */     //   #632	-> 797
/*     */     //   #633	-> 806
/*     */     //   #634	-> 811
/*     */     //   #635	-> 827
/*     */     //   #636	-> 833
/*     */     //   #637	-> 848
/*     */     //   #638	-> 851
/*     */     //   #640	-> 866
/*     */     //   #641	-> 885
/*     */     //   #642	-> 891
/*     */     //   #643	-> 906
/*     */     //   #644	-> 909
/*     */     //   #647	-> 924
/*     */     //   #648	-> 927
/*     */     //   #650	-> 968
/*     */     //   #651	-> 973
/*     */     //   #652	-> 984
/*     */     //   #653	-> 995
/*     */     //   #654	-> 1010
/*     */     //   #657	-> 1029
/*     */     //   #660	-> 1032
/*     */     //   #661	-> 1039
/*     */     //   #664	-> 1042
/*     */     //   #665	-> 1052
/*     */     //   #668	-> 1055
/*     */     //   #671	-> 1058
/*     */     //   #672	-> 1068
/*     */     //   #674	-> 1073
/*     */     //   #675	-> 1081
/*     */     //   #676	-> 1092
/*     */     //   #677	-> 1107
/*     */     //   #678	-> 1126
/*     */     //   #679	-> 1140
/*     */     //   #681	-> 1159
/*     */     //   #683	-> 1168
/*     */     //   #684	-> 1175
/*     */     //   #685	-> 1185
/*     */     //   #686	-> 1204
/*     */     //   #687	-> 1211
/*     */     //   #688	-> 1218
/*     */     //   #690	-> 1236
/*     */     //   #691	-> 1239
/*     */     //   #693	-> 1252
/*     */     //   #694	-> 1255
/*     */     //   #695	-> 1265
/*     */     //   #700	-> 1280
/*     */     //   #703	-> 1312
/*     */     //   #704	-> 1331
/*     */     //   #705	-> 1342
/*     */     //   #707	-> 1352
/*     */     //   #708	-> 1371
/*     */     //   #709	-> 1382
/*     */     //   #711	-> 1392
/*     */     //   #712	-> 1397
/*     */     //   #713	-> 1415
/*     */     //   #714	-> 1418
/*     */     //   #716	-> 1436
/*     */     //   #717	-> 1447
/*     */     //   #718	-> 1457
/*     */     //   #722	-> 1460
/*     */     //   #723	-> 1483
/*     */     //   #724	-> 1494
/*     */     //   #725	-> 1504
/*     */     //   #727	-> 1507
/*     */     //   #728	-> 1512
/*     */     //   #729	-> 1526
/*     */     //   #730	-> 1529
/*     */     //   #734	-> 1543
/*     */     //   #735	-> 1550
/*     */     //   #737	-> 1562
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	descriptor
/*     */     //   0	1563	0	this	Lorg/eclipse/jdt/internal/compiler/ast/ForeachStatement;
/*     */     //   0	1563	1	upperScope	Lorg/eclipse/jdt/internal/compiler/lookup/BlockScope;
/*     */     //   33	1530	2	patternVariablesInTrueScope	[Lorg/eclipse/jdt/internal/compiler/lookup/LocalVariableBinding;
/*     */     //   93	1470	3	elementType	Lorg/eclipse/jdt/internal/compiler/lookup/TypeBinding;
/*     */     //   114	1449	4	collectionType	Lorg/eclipse/jdt/internal/compiler/lookup/TypeBinding;
/*     */     //   257	39	5	refBinding	Lorg/eclipse/jdt/internal/compiler/lookup/ReferenceBinding;
/*     */     //   333	1230	5	expectedCollectionType	Lorg/eclipse/jdt/internal/compiler/lookup/TypeBinding;
/*     */     //   366	1177	6	isTargetJsr14	Z
/*     */     //   384	17	7	upperBound	Lorg/eclipse/jdt/internal/compiler/lookup/TypeBinding;
/*     */     //   513	229	7	compileTimeTypeID	I
/*     */     //   678	38	8	boxedID	I
/*     */     //   766	514	7	iterableType	Lorg/eclipse/jdt/internal/compiler/lookup/ReferenceBinding;
/*     */     //   927	353	8	arguments	[Lorg/eclipse/jdt/internal/compiler/lookup/TypeBinding;
/*     */     //   1168	112	9	compileTimeTypeID	I
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void traverse(ASTVisitor visitor, BlockScope blockScope) {
/* 744 */     if (visitor.visit(this, blockScope)) {
/* 745 */       this.elementVariable.traverse(visitor, this.scope);
/* 746 */       if (this.collection != null) {
/* 747 */         this.collection.traverse(visitor, this.scope);
/*     */       }
/* 749 */       if (this.action != null) {
/* 750 */         this.action.traverse(visitor, this.scope);
/*     */       }
/*     */     } 
/* 753 */     visitor.endVisit(this, blockScope);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean doesNotCompleteNormally() {
/* 758 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean canCompleteNormally() {
/* 763 */     return true;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\ast\ForeachStatement.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */