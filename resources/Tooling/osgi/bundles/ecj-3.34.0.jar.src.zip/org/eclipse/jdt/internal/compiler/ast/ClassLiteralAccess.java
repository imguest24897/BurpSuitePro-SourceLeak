/*     */ package org.eclipse.jdt.internal.compiler.ast;
/*     */ 
/*     */ import org.eclipse.jdt.internal.compiler.ASTVisitor;
/*     */ import org.eclipse.jdt.internal.compiler.codegen.CodeStream;
/*     */ import org.eclipse.jdt.internal.compiler.flow.FlowContext;
/*     */ import org.eclipse.jdt.internal.compiler.flow.FlowInfo;
/*     */ import org.eclipse.jdt.internal.compiler.impl.Constant;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.AnnotationBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.ArrayBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.BlockScope;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.FieldBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.LookupEnvironment;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.ReferenceBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.Scope;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.SourceTypeBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.TypeBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.TypeVariableBinding;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ClassLiteralAccess
/*     */   extends Expression
/*     */ {
/*     */   public TypeReference type;
/*     */   public TypeBinding targetType;
/*     */   FieldBinding syntheticField;
/*     */   
/*     */   public ClassLiteralAccess(int sourceEnd, TypeReference type) {
/*  30 */     this.type = type;
/*  31 */     type.bits |= 0x40000000;
/*  32 */     this.sourceStart = type.sourceStart;
/*  33 */     this.sourceEnd = sourceEnd;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public FlowInfo analyseCode(BlockScope currentScope, FlowContext flowContext, FlowInfo flowInfo) {
/*  43 */     SourceTypeBinding sourceType = currentScope.outerMostClassScope().enclosingSourceType();
/*     */     
/*  45 */     if (!sourceType.isInterface() && 
/*  46 */       !this.targetType.isBaseType() && 
/*  47 */       (currentScope.compilerOptions()).targetJDK < 3211264L) {
/*  48 */       this.syntheticField = sourceType.addSyntheticFieldForClassLiteral(this.targetType, currentScope);
/*     */     }
/*  50 */     return flowInfo;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void generateCode(BlockScope currentScope, CodeStream codeStream, boolean valueRequired) {
/*  65 */     int pc = codeStream.position;
/*     */ 
/*     */     
/*  68 */     if (valueRequired) {
/*  69 */       codeStream.generateClassLiteralAccessForType((Scope)currentScope, this.type.resolvedType, this.syntheticField);
/*  70 */       codeStream.generateImplicitConversion(this.implicitConversion);
/*     */     } 
/*  72 */     codeStream.recordPositionsFrom(pc, this.sourceStart);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public StringBuffer printExpression(int indent, StringBuffer output) {
/*  78 */     return this.type.print(0, output).append(".class");
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public TypeBinding resolveType(BlockScope scope) {
/*  84 */     this.constant = Constant.NotAConstant;
/*  85 */     if ((this.targetType = this.type.resolveType(scope, true)) == null) {
/*  86 */       return null;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  96 */     LookupEnvironment environment = scope.environment();
/*  97 */     this.targetType = environment.convertToRawType(this.targetType, true);
/*     */     
/*  99 */     if (this.targetType.isArrayType()) {
/* 100 */       ArrayBinding arrayBinding = (ArrayBinding)this.targetType;
/* 101 */       TypeBinding leafComponentType = arrayBinding.leafComponentType;
/* 102 */       if (leafComponentType == TypeBinding.VOID) {
/* 103 */         scope.problemReporter().cannotAllocateVoidArray(this);
/* 104 */         return null;
/* 105 */       }  if (leafComponentType.isTypeVariable()) {
/* 106 */         scope.problemReporter().illegalClassLiteralForTypeVariable((TypeVariableBinding)leafComponentType, this);
/*     */       }
/* 108 */     } else if (this.targetType.isTypeVariable()) {
/* 109 */       scope.problemReporter().illegalClassLiteralForTypeVariable((TypeVariableBinding)this.targetType, this);
/*     */     } 
/* 111 */     ReferenceBinding classType = scope.getJavaLangClass();
/*     */     
/* 113 */     if ((scope.compilerOptions()).sourceLevel >= 3211264L) {
/*     */       
/* 115 */       TypeBinding boxedType = null;
/* 116 */       if (this.targetType.id == 6) {
/* 117 */         ReferenceBinding referenceBinding = environment.getResolvedJavaBaseType(JAVA_LANG_VOID, (Scope)scope);
/*     */       } else {
/* 119 */         boxedType = scope.boxing(this.targetType);
/*     */       } 
/* 121 */       if (environment.usesNullTypeAnnotations())
/* 122 */         boxedType = environment.createAnnotatedType(boxedType, new AnnotationBinding[] { environment.getNonNullAnnotation() }); 
/* 123 */       this.resolvedType = (TypeBinding)environment.createParameterizedType(classType, new TypeBinding[] { boxedType }, null);
/*     */     } else {
/* 125 */       this.resolvedType = (TypeBinding)classType;
/*     */     } 
/* 127 */     return this.resolvedType;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void traverse(ASTVisitor visitor, BlockScope blockScope) {
/* 135 */     if (visitor.visit(this, blockScope)) {
/* 136 */       this.type.traverse(visitor, blockScope);
/*     */     }
/* 138 */     visitor.endVisit(this, blockScope);
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\ast\ClassLiteralAccess.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */