/*     */ package org.eclipse.jdt.internal.compiler.ast;
/*     */ 
/*     */ import org.eclipse.jdt.internal.compiler.ASTVisitor;
/*     */ import org.eclipse.jdt.internal.compiler.codegen.BranchLabel;
/*     */ import org.eclipse.jdt.internal.compiler.codegen.CodeStream;
/*     */ import org.eclipse.jdt.internal.compiler.flow.FlowContext;
/*     */ import org.eclipse.jdt.internal.compiler.flow.FlowInfo;
/*     */ import org.eclipse.jdt.internal.compiler.flow.LoopingFlowContext;
/*     */ import org.eclipse.jdt.internal.compiler.flow.UnconditionalFlowInfo;
/*     */ import org.eclipse.jdt.internal.compiler.impl.Constant;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.BlockScope;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.LocalVariableBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.Scope;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.TypeBinding;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DoStatement
/*     */   extends Statement
/*     */ {
/*     */   public Expression condition;
/*     */   public Statement action;
/*     */   private BranchLabel breakLabel;
/*     */   private BranchLabel continueLabel;
/*  35 */   int mergedInitStateIndex = -1;
/*  36 */   int preConditionInitStateIndex = -1;
/*     */ 
/*     */   
/*     */   public DoStatement(Expression condition, Statement action, int sourceStart, int sourceEnd) {
/*  40 */     this.sourceStart = sourceStart;
/*  41 */     this.sourceEnd = sourceEnd;
/*  42 */     this.condition = condition;
/*  43 */     this.action = action;
/*     */     
/*  45 */     if (action instanceof EmptyStatement) action.bits |= 0x1;
/*     */   
/*     */   }
/*     */   
/*     */   public FlowInfo analyseCode(BlockScope currentScope, FlowContext flowContext, FlowInfo flowInfo) {
/*  50 */     this.breakLabel = new BranchLabel();
/*  51 */     this.continueLabel = new BranchLabel();
/*  52 */     LoopingFlowContext loopingContext = 
/*  53 */       new LoopingFlowContext(
/*  54 */         flowContext, 
/*  55 */         flowInfo, 
/*  56 */         this, 
/*  57 */         this.breakLabel, 
/*  58 */         this.continueLabel, 
/*  59 */         (Scope)currentScope, 
/*  60 */         false);
/*     */     
/*  62 */     Constant cst = this.condition.constant;
/*  63 */     boolean isConditionTrue = (cst != Constant.NotAConstant && cst.booleanValue());
/*  64 */     cst = this.condition.optimizedBooleanConstant();
/*  65 */     boolean isConditionOptimizedTrue = (cst != Constant.NotAConstant && cst.booleanValue());
/*  66 */     boolean isConditionOptimizedFalse = (cst != Constant.NotAConstant && !cst.booleanValue());
/*     */     
/*  68 */     int previousMode = flowInfo.reachMode();
/*     */     
/*  70 */     FlowInfo initsOnCondition = flowInfo;
/*  71 */     UnconditionalFlowInfo actionInfo = flowInfo.nullInfoLessUnconditionalCopy();
/*     */ 
/*     */ 
/*     */     
/*  75 */     if (this.action != null && !this.action.isEmptyBlock()) {
/*  76 */       actionInfo = this.action
/*  77 */         .analyseCode(currentScope, (FlowContext)loopingContext, (FlowInfo)actionInfo)
/*  78 */         .unconditionalInits();
/*     */ 
/*     */       
/*  81 */       if ((actionInfo.tagBits & 
/*  82 */         loopingContext.initsOnContinue.tagBits & 
/*  83 */         0x1) != 0) {
/*  84 */         this.continueLabel = null;
/*     */       }
/*  86 */       if ((this.condition.implicitConversion & 0x400) != 0) {
/*  87 */         initsOnCondition = flowInfo.unconditionalInits()
/*  88 */           .addInitializationsFrom(
/*  89 */             (FlowInfo)actionInfo.mergedWith(loopingContext.initsOnContinue));
/*     */       }
/*     */     } 
/*  92 */     this.condition.checkNPEbyUnboxing(currentScope, flowContext, initsOnCondition);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  98 */     actionInfo.setReachMode(previousMode);
/*     */     
/*     */     LoopingFlowContext condLoopContext;
/* 101 */     FlowInfo condInfo = 
/* 102 */       this.condition.analyseCode(
/* 103 */         currentScope, 
/* 104 */         (FlowContext)(condLoopContext = 
/* 105 */         new LoopingFlowContext(flowContext, flowInfo, this, null, 
/* 106 */           null, (Scope)currentScope, true)), (
/* 107 */         (this.action == null) ? 
/* 108 */         actionInfo : 
/* 109 */         actionInfo.mergedWith(loopingContext.initsOnContinue)).copy());
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 114 */     this.preConditionInitStateIndex = currentScope.methodScope().recordInitializationStates((FlowInfo)actionInfo.mergedWith(loopingContext.initsOnContinue));
/* 115 */     if (!isConditionOptimizedFalse && this.continueLabel != null) {
/* 116 */       loopingContext.complainOnDeferredFinalChecks(currentScope, condInfo);
/* 117 */       condLoopContext.complainOnDeferredFinalChecks(currentScope, condInfo);
/* 118 */       loopingContext.complainOnDeferredNullChecks(currentScope, 
/* 119 */           (FlowInfo)flowInfo.unconditionalCopy().addPotentialNullInfoFrom(
/* 120 */             condInfo.initsWhenTrue().unconditionalInits()));
/* 121 */       condLoopContext.complainOnDeferredNullChecks(currentScope, 
/* 122 */           (FlowInfo)actionInfo.addPotentialNullInfoFrom(
/* 123 */             condInfo.initsWhenTrue().unconditionalInits()));
/*     */     } else {
/* 125 */       loopingContext.complainOnDeferredNullChecks(currentScope, 
/* 126 */           (FlowInfo)flowInfo.unconditionalCopy().addPotentialNullInfoFrom(
/* 127 */             condInfo.initsWhenTrue().unconditionalInits()), false);
/* 128 */       condLoopContext.complainOnDeferredNullChecks(currentScope, 
/* 129 */           (FlowInfo)actionInfo.addPotentialNullInfoFrom(
/* 130 */             condInfo.initsWhenTrue().unconditionalInits()), false);
/*     */     } 
/* 132 */     if (loopingContext.hasEscapingExceptions()) {
/* 133 */       FlowInfo loopbackFlowInfo = flowInfo.copy();
/*     */       
/* 135 */       UnconditionalFlowInfo unconditionalFlowInfo = loopbackFlowInfo.mergedWith(loopbackFlowInfo.unconditionalCopy().addNullInfoFrom(condInfo.initsWhenTrue()).unconditionalInits());
/* 136 */       loopingContext.simulateThrowAfterLoopBack((FlowInfo)unconditionalFlowInfo);
/*     */     } 
/*     */     
/* 139 */     UnconditionalFlowInfo unconditionalFlowInfo1 = 
/* 140 */       FlowInfo.mergedOptimizedBranches(
/* 141 */         ((loopingContext.initsOnBreak.tagBits & 0x3) != 0) ? 
/* 142 */         (FlowInfo)loopingContext.initsOnBreak : 
/* 143 */         flowInfo.unconditionalCopy().addInitializationsFrom((FlowInfo)loopingContext.initsOnBreak), 
/*     */         
/* 145 */         isConditionOptimizedTrue, 
/* 146 */         ((condInfo.tagBits & 0x3) == 0) ? 
/* 147 */         flowInfo.copy().addInitializationsFrom(condInfo.initsWhenFalse()) : 
/* 148 */         condInfo, 
/*     */         
/* 150 */         false, 
/* 151 */         !isConditionTrue);
/* 152 */     this.mergedInitStateIndex = currentScope.methodScope().recordInitializationStates((FlowInfo)unconditionalFlowInfo1);
/* 153 */     return (FlowInfo)unconditionalFlowInfo1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void generateCode(BlockScope currentScope, CodeStream codeStream) {
/* 162 */     if ((this.bits & Integer.MIN_VALUE) == 0) {
/*     */       return;
/*     */     }
/* 165 */     int pc = codeStream.position;
/*     */ 
/*     */     
/* 168 */     BranchLabel actionLabel = new BranchLabel(codeStream);
/* 169 */     if (this.action != null) actionLabel.tagBits |= 0x2; 
/* 170 */     actionLabel.place();
/* 171 */     this.breakLabel.initialize(codeStream);
/* 172 */     boolean hasContinueLabel = (this.continueLabel != null);
/* 173 */     if (hasContinueLabel) {
/* 174 */       this.continueLabel.initialize(codeStream);
/*     */     }
/*     */ 
/*     */     
/* 178 */     if (this.action != null) {
/* 179 */       this.action.generateCode(currentScope, codeStream);
/*     */     }
/*     */     
/* 182 */     if (hasContinueLabel) {
/* 183 */       this.continueLabel.place();
/*     */       
/* 185 */       if (this.preConditionInitStateIndex != -1) {
/* 186 */         codeStream.removeNotDefinitelyAssignedVariables((Scope)currentScope, this.preConditionInitStateIndex);
/* 187 */         codeStream.addDefinitelyAssignedVariables((Scope)currentScope, this.preConditionInitStateIndex);
/*     */       } 
/*     */       
/* 190 */       Constant cst = this.condition.optimizedBooleanConstant();
/* 191 */       boolean isConditionOptimizedFalse = (cst != Constant.NotAConstant && !cst.booleanValue());
/* 192 */       if (isConditionOptimizedFalse) {
/* 193 */         this.condition.generateCode(currentScope, codeStream, false);
/*     */       } else {
/* 195 */         this.condition.generateOptimizedBoolean(
/* 196 */             currentScope, 
/* 197 */             codeStream, 
/* 198 */             actionLabel, 
/* 199 */             (BranchLabel)null, 
/* 200 */             true);
/*     */       } 
/*     */     } 
/*     */     
/* 204 */     if (this.mergedInitStateIndex != -1) {
/* 205 */       codeStream.removeNotDefinitelyAssignedVariables((Scope)currentScope, this.mergedInitStateIndex);
/* 206 */       codeStream.addDefinitelyAssignedVariables((Scope)currentScope, this.mergedInitStateIndex);
/*     */     } 
/* 208 */     if (this.breakLabel.forwardReferenceCount() > 0) {
/* 209 */       this.breakLabel.place();
/*     */     }
/*     */     
/* 212 */     codeStream.recordPositionsFrom(pc, this.sourceStart);
/*     */   }
/*     */ 
/*     */   
/*     */   public StringBuffer printStatement(int indent, StringBuffer output) {
/* 217 */     printIndent(indent, output).append("do");
/* 218 */     if (this.action == null) {
/* 219 */       output.append(" ;\n");
/*     */     } else {
/* 221 */       output.append('\n');
/* 222 */       this.action.printStatement(indent + 1, output).append('\n');
/*     */     } 
/* 224 */     output.append("while (");
/* 225 */     return this.condition.printExpression(0, output).append(");");
/*     */   }
/*     */ 
/*     */   
/*     */   public void resolve(BlockScope scope) {
/* 230 */     if (containsPatternVariable()) {
/* 231 */       this.condition.collectPatternVariablesToScope((LocalVariableBinding[])null, scope);
/* 232 */       LocalVariableBinding[] patternVariablesInFalseScope = this.condition.getPatternVariablesWhenFalse();
/* 233 */       TypeBinding type = this.condition.resolveTypeExpecting(scope, (TypeBinding)TypeBinding.BOOLEAN);
/* 234 */       this.condition.computeConversion((Scope)scope, type, type);
/* 235 */       if (this.action != null) {
/* 236 */         this.action.resolve(scope);
/* 237 */         this.action.promotePatternVariablesIfApplicable(patternVariablesInFalseScope, () -> !this.action.breaksOut((char[])null));
/*     */       } 
/*     */     } else {
/*     */       
/* 241 */       TypeBinding type = this.condition.resolveTypeExpecting(scope, (TypeBinding)TypeBinding.BOOLEAN);
/* 242 */       this.condition.computeConversion((Scope)scope, type, type);
/* 243 */       if (this.action != null) {
/* 244 */         this.action.resolve(scope);
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   public boolean containsPatternVariable() {
/* 250 */     return this.condition.containsPatternVariable();
/*     */   }
/*     */   
/*     */   public void traverse(ASTVisitor visitor, BlockScope scope) {
/* 254 */     if (visitor.visit(this, scope)) {
/* 255 */       if (this.action != null) {
/* 256 */         this.action.traverse(visitor, scope);
/*     */       }
/* 258 */       this.condition.traverse(visitor, scope);
/*     */     } 
/* 260 */     visitor.endVisit(this, scope);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean doesNotCompleteNormally() {
/* 265 */     Constant cst = this.condition.constant;
/* 266 */     boolean isConditionTrue = !(cst != null && (cst == Constant.NotAConstant || !cst.booleanValue()));
/* 267 */     cst = this.condition.optimizedBooleanConstant();
/* 268 */     boolean isConditionOptimizedTrue = (cst == null) ? true : ((cst != Constant.NotAConstant && cst.booleanValue()));
/*     */     
/* 270 */     if (isConditionTrue || isConditionOptimizedTrue)
/* 271 */       return !(this.action != null && this.action.breaksOut((char[])null)); 
/* 272 */     if (this.action == null || this.action.breaksOut((char[])null))
/* 273 */       return false; 
/* 274 */     return (this.action.doesNotCompleteNormally() && !this.action.completesByContinue());
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean completesByContinue() {
/* 279 */     return this.action.continuesAtOuterLabel();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean canCompleteNormally() {
/* 284 */     Constant cst = this.condition.constant;
/* 285 */     boolean isConditionTrue = !(cst != null && (cst == Constant.NotAConstant || !cst.booleanValue()));
/* 286 */     cst = this.condition.optimizedBooleanConstant();
/* 287 */     boolean isConditionOptimizedTrue = (cst == null) ? true : ((cst != Constant.NotAConstant && cst.booleanValue()));
/*     */     
/* 289 */     if (!isConditionTrue && !isConditionOptimizedTrue) {
/* 290 */       if (this.action == null || this.action.canCompleteNormally())
/* 291 */         return true; 
/* 292 */       if (this.action != null && this.action.continueCompletes())
/* 293 */         return true; 
/*     */     } 
/* 295 */     if (this.action != null && this.action.breaksOut((char[])null)) {
/* 296 */       return true;
/*     */     }
/* 298 */     return false;
/*     */   }
/*     */   
/*     */   public boolean continueCompletes() {
/* 302 */     return this.action.continuesAtOuterLabel();
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\ast\DoStatement.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */