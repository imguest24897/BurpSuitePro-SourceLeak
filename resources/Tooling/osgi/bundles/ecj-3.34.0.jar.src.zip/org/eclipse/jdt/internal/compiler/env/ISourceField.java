package org.eclipse.jdt.internal.compiler.env;

public interface ISourceField extends IGenericField {
  int getDeclarationSourceEnd();
  
  int getDeclarationSourceStart();
  
  char[] getInitializationSource();
  
  int getNameSourceEnd();
  
  int getNameSourceStart();
  
  char[] getTypeName();
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\env\ISourceField.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */