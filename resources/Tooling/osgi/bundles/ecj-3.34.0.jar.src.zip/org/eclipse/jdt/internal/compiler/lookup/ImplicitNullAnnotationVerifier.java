/*     */ package org.eclipse.jdt.internal.compiler.lookup;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import org.eclipse.jdt.core.compiler.CharOperation;
/*     */ import org.eclipse.jdt.internal.compiler.ast.ASTNode;
/*     */ import org.eclipse.jdt.internal.compiler.ast.AbstractMethodDeclaration;
/*     */ import org.eclipse.jdt.internal.compiler.ast.Argument;
/*     */ import org.eclipse.jdt.internal.compiler.ast.NullAnnotationMatching;
/*     */ import org.eclipse.jdt.internal.compiler.impl.CompilerOptions;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ImplicitNullAnnotationVerifier
/*     */ {
/*     */   ImplicitNullAnnotationVerifier buddyImplicitNullAnnotationsVerifier;
/*     */   private boolean inheritNullAnnotations;
/*     */   protected LookupEnvironment environment;
/*     */   
/*     */   public static void ensureNullnessIsKnown(MethodBinding methodBinding, Scope scope) {
/*  40 */     if ((methodBinding.tagBits & 0x1000L) == 0L) {
/*  41 */       LookupEnvironment environment2 = scope.environment();
/*     */       
/*  43 */       (new ImplicitNullAnnotationVerifier(environment2, environment2.globalOptions.inheritNullAnnotations))
/*  44 */         .checkImplicitNullAnnotations(methodBinding, null, false, scope);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static class InheritedNonNullnessInfo
/*     */   {
/*     */     Boolean inheritedNonNullness;
/*     */ 
/*     */ 
/*     */     
/*     */     MethodBinding annotationOrigin;
/*     */ 
/*     */ 
/*     */     
/*     */     boolean complained;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ImplicitNullAnnotationVerifier(LookupEnvironment environment, boolean inheritNullAnnotations) {
/*  67 */     this.buddyImplicitNullAnnotationsVerifier = this;
/*  68 */     this.inheritNullAnnotations = inheritNullAnnotations;
/*  69 */     this.environment = environment;
/*     */   }
/*     */ 
/*     */   
/*     */   ImplicitNullAnnotationVerifier(LookupEnvironment environment) {
/*  74 */     CompilerOptions options = environment.globalOptions;
/*  75 */     this.buddyImplicitNullAnnotationsVerifier = new ImplicitNullAnnotationVerifier(environment, options.inheritNullAnnotations);
/*  76 */     this.inheritNullAnnotations = options.inheritNullAnnotations;
/*  77 */     this.environment = environment;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void checkImplicitNullAnnotations(MethodBinding currentMethod, AbstractMethodDeclaration srcMethod, boolean complain, Scope scope) {
/*     */     try {
/*  87 */       ReferenceBinding currentType = currentMethod.declaringClass;
/*  88 */       if (currentType.id == 1) {
/*     */         return;
/*     */       }
/*  91 */       boolean usesTypeAnnotations = scope.environment().usesNullTypeAnnotations();
/*  92 */       boolean needToApplyReturnNonNullDefault = 
/*  93 */         currentMethod.hasNonNullDefaultForReturnType(srcMethod);
/*  94 */       ParameterNonNullDefaultProvider needToApplyParameterNonNullDefault = 
/*  95 */         currentMethod.hasNonNullDefaultForParameter(srcMethod);
/*  96 */       boolean needToApplyNonNullDefault = needToApplyReturnNonNullDefault | needToApplyParameterNonNullDefault.hasAnyNonNullDefault();
/*     */       
/*  98 */       boolean isInstanceMethod = (!currentMethod.isConstructor() && !currentMethod.isStatic());
/*  99 */       complain &= isInstanceMethod;
/* 100 */       if (!needToApplyNonNullDefault && 
/* 101 */         !complain && (
/* 102 */         !this.inheritNullAnnotations || !isInstanceMethod)) {
/*     */         return;
/*     */       }
/*     */       
/* 106 */       if (isInstanceMethod) {
/* 107 */         List<MethodBinding> superMethodList = new ArrayList();
/*     */ 
/*     */         
/* 110 */         if (currentType instanceof SourceTypeBinding && !currentType.isHierarchyConnected() && !currentType.isAnonymousType()) {
/* 111 */           ((SourceTypeBinding)currentType).scope.connectTypeHierarchy();
/*     */         }
/*     */         
/* 114 */         int paramLen = currentMethod.parameters.length;
/* 115 */         findAllOverriddenMethods(currentMethod.original(), currentMethod.selector, paramLen, 
/* 116 */             currentType, new HashSet(), superMethodList);
/*     */ 
/*     */         
/* 119 */         InheritedNonNullnessInfo[] inheritedNonNullnessInfos = new InheritedNonNullnessInfo[paramLen + 1];
/* 120 */         for (int i = 0; i < paramLen + 1; ) { inheritedNonNullnessInfos[i] = new InheritedNonNullnessInfo(); i++; }
/*     */         
/* 122 */         int length = superMethodList.size();
/* 123 */         for (int j = length; --j >= 0; ) {
/* 124 */           MethodBinding currentSuper = superMethodList.get(j);
/* 125 */           if ((currentSuper.tagBits & 0x1000L) == 0L)
/*     */           {
/* 127 */             checkImplicitNullAnnotations(currentSuper, null, false, scope);
/*     */           }
/* 129 */           checkNullSpecInheritance(currentMethod, srcMethod, needToApplyReturnNonNullDefault, needToApplyParameterNonNullDefault, complain, currentSuper, null, scope, inheritedNonNullnessInfos);
/* 130 */           needToApplyNonNullDefault = false;
/*     */         } 
/*     */ 
/*     */         
/* 134 */         InheritedNonNullnessInfo info = inheritedNonNullnessInfos[0];
/* 135 */         if (!info.complained) {
/* 136 */           long tagBits = 0L;
/* 137 */           if (info.inheritedNonNullness == Boolean.TRUE) {
/* 138 */             tagBits = 72057594037927936L;
/* 139 */           } else if (info.inheritedNonNullness == Boolean.FALSE) {
/* 140 */             tagBits = 36028797018963968L;
/*     */           } 
/* 142 */           if (tagBits != 0L) {
/* 143 */             if (!usesTypeAnnotations) {
/* 144 */               currentMethod.tagBits |= tagBits;
/*     */             }
/* 146 */             else if (!currentMethod.returnType.isBaseType()) {
/* 147 */               LookupEnvironment env = scope.environment();
/* 148 */               currentMethod.returnType = env.createAnnotatedType(currentMethod.returnType, env.nullAnnotationsFromTagBits(tagBits));
/*     */             } 
/*     */           }
/*     */         } 
/*     */         
/* 153 */         for (int k = 0; k < paramLen; k++) {
/* 154 */           info = inheritedNonNullnessInfos[k + 1];
/* 155 */           if (!info.complained && info.inheritedNonNullness != null) {
/* 156 */             Argument currentArg = (srcMethod == null) ? null : srcMethod.arguments[k];
/* 157 */             if (!usesTypeAnnotations) {
/* 158 */               recordArgNonNullness(currentMethod, paramLen, k, currentArg, info.inheritedNonNullness);
/*     */             } else {
/* 160 */               recordArgNonNullness18(currentMethod, k, currentArg, info.inheritedNonNullness, scope.environment());
/*     */             } 
/*     */           } 
/*     */         } 
/*     */       } 
/* 165 */       if (needToApplyNonNullDefault)
/* 166 */         if (!usesTypeAnnotations) {
/* 167 */           currentMethod.fillInDefaultNonNullness(srcMethod, needToApplyReturnNonNullDefault, needToApplyParameterNonNullDefault);
/*     */         } else {
/* 169 */           currentMethod.fillInDefaultNonNullness18(srcMethod, scope.environment());
/*     */         }  
/*     */     } finally {
/* 172 */       currentMethod.tagBits |= 0x1000L;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void findAllOverriddenMethods(MethodBinding original, char[] selector, int suggestedParameterLength, ReferenceBinding currentType, Set<TypeBinding> ifcsSeen, List result) {
/* 183 */     if (currentType.id == 1) {
/*     */       return;
/*     */     }
/*     */     
/* 187 */     ReferenceBinding superclass = currentType.superclass();
/* 188 */     if (superclass == null)
/*     */       return; 
/* 190 */     collectOverriddenMethods(original, selector, suggestedParameterLength, superclass, ifcsSeen, result);
/*     */ 
/*     */     
/* 193 */     ReferenceBinding[] superInterfaces = currentType.superInterfaces();
/* 194 */     int ifcLen = superInterfaces.length;
/* 195 */     for (int i = 0; i < ifcLen; i++) {
/* 196 */       ReferenceBinding currentIfc = superInterfaces[i];
/* 197 */       if (ifcsSeen.add(currentIfc.original())) {
/* 198 */         collectOverriddenMethods(original, selector, suggestedParameterLength, currentIfc, ifcsSeen, result);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void collectOverriddenMethods(MethodBinding original, char[] selector, int suggestedParameterLength, ReferenceBinding superType, Set ifcsSeen, List<MethodBinding> result) {
/* 207 */     MethodBinding[] ifcMethods = superType.unResolvedMethods();
/* 208 */     int length = ifcMethods.length;
/* 209 */     boolean added = false;
/* 210 */     for (int i = 0; i < length; i++) {
/* 211 */       MethodBinding currentMethod = ifcMethods[i];
/* 212 */       if (CharOperation.equals(selector, currentMethod.selector))
/*     */       {
/* 214 */         if (currentMethod.doesParameterLengthMatch(suggestedParameterLength))
/*     */         {
/* 216 */           if (!currentMethod.isStatic())
/*     */           {
/* 218 */             if (MethodVerifier.doesMethodOverride(original, currentMethod, this.environment)) {
/* 219 */               result.add(currentMethod);
/* 220 */               added = true;
/*     */             }  }  }  } 
/*     */     } 
/* 223 */     if (!added) {
/* 224 */       findAllOverriddenMethods(original, selector, suggestedParameterLength, superType, ifcsSeen, result);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void checkNullSpecInheritance(MethodBinding currentMethod, AbstractMethodDeclaration srcMethod, boolean hasReturnNonNullDefault, ParameterNonNullDefaultProvider hasParameterNonNullDefault, boolean shouldComplain, MethodBinding inheritedMethod, MethodBinding[] allInheritedMethods, Scope scope, InheritedNonNullnessInfo[] inheritedNonNullnessInfos) {
/*     */     // Byte code:
/*     */     //   0: aload_1
/*     */     //   1: getfield declaringClass : Lorg/eclipse/jdt/internal/compiler/lookup/ReferenceBinding;
/*     */     //   4: getfield id : I
/*     */     //   7: iconst_1
/*     */     //   8: if_icmpne -> 12
/*     */     //   11: return
/*     */     //   12: aload #6
/*     */     //   14: getfield tagBits : J
/*     */     //   17: ldc2_w 4096
/*     */     //   20: land
/*     */     //   21: lconst_0
/*     */     //   22: lcmp
/*     */     //   23: ifne -> 39
/*     */     //   26: aload_0
/*     */     //   27: getfield buddyImplicitNullAnnotationsVerifier : Lorg/eclipse/jdt/internal/compiler/lookup/ImplicitNullAnnotationVerifier;
/*     */     //   30: aload #6
/*     */     //   32: aconst_null
/*     */     //   33: iconst_0
/*     */     //   34: aload #8
/*     */     //   36: invokevirtual checkImplicitNullAnnotations : (Lorg/eclipse/jdt/internal/compiler/lookup/MethodBinding;Lorg/eclipse/jdt/internal/compiler/ast/AbstractMethodDeclaration;ZLorg/eclipse/jdt/internal/compiler/lookup/Scope;)V
/*     */     //   39: aload_0
/*     */     //   40: getfield environment : Lorg/eclipse/jdt/internal/compiler/lookup/LookupEnvironment;
/*     */     //   43: invokevirtual usesNullTypeAnnotations : ()Z
/*     */     //   46: istore #10
/*     */     //   48: aload_0
/*     */     //   49: aload #6
/*     */     //   51: iload #10
/*     */     //   53: invokevirtual getReturnTypeNullnessTagBits : (Lorg/eclipse/jdt/internal/compiler/lookup/MethodBinding;Z)J
/*     */     //   56: lstore #11
/*     */     //   58: aload_0
/*     */     //   59: aload_1
/*     */     //   60: iload #10
/*     */     //   62: invokevirtual getReturnTypeNullnessTagBits : (Lorg/eclipse/jdt/internal/compiler/lookup/MethodBinding;Z)J
/*     */     //   65: lstore #13
/*     */     //   67: aload_0
/*     */     //   68: getfield inheritNullAnnotations : Z
/*     */     //   71: istore #15
/*     */     //   73: aload_1
/*     */     //   74: getfield returnType : Lorg/eclipse/jdt/internal/compiler/lookup/TypeBinding;
/*     */     //   77: ifnull -> 430
/*     */     //   80: aload_1
/*     */     //   81: getfield returnType : Lorg/eclipse/jdt/internal/compiler/lookup/TypeBinding;
/*     */     //   84: invokevirtual isBaseType : ()Z
/*     */     //   87: ifeq -> 93
/*     */     //   90: goto -> 430
/*     */     //   93: lload #13
/*     */     //   95: lconst_0
/*     */     //   96: lcmp
/*     */     //   97: ifne -> 237
/*     */     //   100: iload #15
/*     */     //   102: ifeq -> 206
/*     */     //   105: lload #11
/*     */     //   107: lconst_0
/*     */     //   108: lcmp
/*     */     //   109: ifeq -> 206
/*     */     //   112: iload_3
/*     */     //   113: ifeq -> 148
/*     */     //   116: iload #5
/*     */     //   118: ifeq -> 148
/*     */     //   121: lload #11
/*     */     //   123: ldc2_w 36028797018963968
/*     */     //   126: lcmp
/*     */     //   127: ifne -> 148
/*     */     //   130: aload #8
/*     */     //   132: invokevirtual problemReporter : ()Lorg/eclipse/jdt/internal/compiler/problem/ProblemReporter;
/*     */     //   135: aload_1
/*     */     //   136: aload_2
/*     */     //   137: checkcast org/eclipse/jdt/internal/compiler/ast/MethodDeclaration
/*     */     //   140: getfield returnType : Lorg/eclipse/jdt/internal/compiler/ast/TypeReference;
/*     */     //   143: aload #6
/*     */     //   145: invokevirtual conflictingNullAnnotations : (Lorg/eclipse/jdt/internal/compiler/lookup/MethodBinding;Lorg/eclipse/jdt/internal/compiler/ast/ASTNode;Lorg/eclipse/jdt/internal/compiler/lookup/MethodBinding;)V
/*     */     //   148: aload #9
/*     */     //   150: ifnull -> 196
/*     */     //   153: aload_2
/*     */     //   154: ifnull -> 196
/*     */     //   157: aload_0
/*     */     //   158: aload #8
/*     */     //   160: aload_2
/*     */     //   161: checkcast org/eclipse/jdt/internal/compiler/ast/MethodDeclaration
/*     */     //   164: getfield returnType : Lorg/eclipse/jdt/internal/compiler/ast/TypeReference;
/*     */     //   167: aload #6
/*     */     //   169: lload #11
/*     */     //   171: ldc2_w 72057594037927936
/*     */     //   174: lcmp
/*     */     //   175: ifne -> 182
/*     */     //   178: iconst_1
/*     */     //   179: goto -> 183
/*     */     //   182: iconst_0
/*     */     //   183: invokestatic valueOf : (Z)Ljava/lang/Boolean;
/*     */     //   186: aload #9
/*     */     //   188: iconst_0
/*     */     //   189: aaload
/*     */     //   190: invokevirtual recordDeferredInheritedNullness : (Lorg/eclipse/jdt/internal/compiler/lookup/Scope;Lorg/eclipse/jdt/internal/compiler/ast/ASTNode;Lorg/eclipse/jdt/internal/compiler/lookup/MethodBinding;Ljava/lang/Boolean;Lorg/eclipse/jdt/internal/compiler/lookup/ImplicitNullAnnotationVerifier$InheritedNonNullnessInfo;)V
/*     */     //   193: goto -> 430
/*     */     //   196: aload_0
/*     */     //   197: aload_1
/*     */     //   198: lload #11
/*     */     //   200: invokevirtual applyReturnNullBits : (Lorg/eclipse/jdt/internal/compiler/lookup/MethodBinding;J)V
/*     */     //   203: goto -> 430
/*     */     //   206: iload_3
/*     */     //   207: ifeq -> 237
/*     */     //   210: iload #10
/*     */     //   212: ifeq -> 225
/*     */     //   215: aload_1
/*     */     //   216: getfield returnType : Lorg/eclipse/jdt/internal/compiler/lookup/TypeBinding;
/*     */     //   219: invokevirtual acceptsNonNullDefault : ()Z
/*     */     //   222: ifeq -> 237
/*     */     //   225: ldc2_w 72057594037927936
/*     */     //   228: lstore #13
/*     */     //   230: aload_0
/*     */     //   231: aload_1
/*     */     //   232: lload #13
/*     */     //   234: invokevirtual applyReturnNullBits : (Lorg/eclipse/jdt/internal/compiler/lookup/MethodBinding;J)V
/*     */     //   237: iload #5
/*     */     //   239: ifeq -> 430
/*     */     //   242: lload #11
/*     */     //   244: ldc2_w 72057594037927936
/*     */     //   247: land
/*     */     //   248: lconst_0
/*     */     //   249: lcmp
/*     */     //   250: ifeq -> 306
/*     */     //   253: lload #13
/*     */     //   255: ldc2_w 72057594037927936
/*     */     //   258: lcmp
/*     */     //   259: ifeq -> 306
/*     */     //   262: aload_2
/*     */     //   263: ifnull -> 287
/*     */     //   266: aload #8
/*     */     //   268: invokevirtual problemReporter : ()Lorg/eclipse/jdt/internal/compiler/problem/ProblemReporter;
/*     */     //   271: aload_2
/*     */     //   272: aload #6
/*     */     //   274: aload_0
/*     */     //   275: getfield environment : Lorg/eclipse/jdt/internal/compiler/lookup/LookupEnvironment;
/*     */     //   278: invokevirtual getNonNullAnnotationName : ()[[C
/*     */     //   281: invokevirtual illegalReturnRedefinition : (Lorg/eclipse/jdt/internal/compiler/ast/AbstractMethodDeclaration;Lorg/eclipse/jdt/internal/compiler/lookup/MethodBinding;[[C)V
/*     */     //   284: goto -> 430
/*     */     //   287: aload #8
/*     */     //   289: invokevirtual problemReporter : ()Lorg/eclipse/jdt/internal/compiler/problem/ProblemReporter;
/*     */     //   292: aload #8
/*     */     //   294: invokevirtual referenceContext : ()Lorg/eclipse/jdt/internal/compiler/impl/ReferenceContext;
/*     */     //   297: aload_1
/*     */     //   298: aload #6
/*     */     //   300: iload #10
/*     */     //   302: invokevirtual cannotImplementIncompatibleNullness : (Lorg/eclipse/jdt/internal/compiler/impl/ReferenceContext;Lorg/eclipse/jdt/internal/compiler/lookup/MethodBinding;Lorg/eclipse/jdt/internal/compiler/lookup/MethodBinding;Z)V
/*     */     //   305: return
/*     */     //   306: iload #10
/*     */     //   308: ifeq -> 430
/*     */     //   311: aconst_null
/*     */     //   312: astore #16
/*     */     //   314: aload #6
/*     */     //   316: invokevirtual original : ()Lorg/eclipse/jdt/internal/compiler/lookup/MethodBinding;
/*     */     //   319: getfield typeVariables : [Lorg/eclipse/jdt/internal/compiler/lookup/TypeVariableBinding;
/*     */     //   322: astore #17
/*     */     //   324: aload #17
/*     */     //   326: ifnull -> 360
/*     */     //   329: aload_1
/*     */     //   330: getfield returnType : Lorg/eclipse/jdt/internal/compiler/lookup/TypeBinding;
/*     */     //   333: getfield id : I
/*     */     //   336: bipush #6
/*     */     //   338: if_icmpeq -> 360
/*     */     //   341: aload_0
/*     */     //   342: getfield environment : Lorg/eclipse/jdt/internal/compiler/lookup/LookupEnvironment;
/*     */     //   345: aload_1
/*     */     //   346: aload #17
/*     */     //   348: invokevirtual createParameterizedGenericMethod : (Lorg/eclipse/jdt/internal/compiler/lookup/MethodBinding;[Lorg/eclipse/jdt/internal/compiler/lookup/TypeBinding;)Lorg/eclipse/jdt/internal/compiler/lookup/ParameterizedGenericMethodBinding;
/*     */     //   351: astore #18
/*     */     //   353: aload #18
/*     */     //   355: getfield returnType : Lorg/eclipse/jdt/internal/compiler/lookup/TypeBinding;
/*     */     //   358: astore #16
/*     */     //   360: aload #6
/*     */     //   362: getfield returnType : Lorg/eclipse/jdt/internal/compiler/lookup/TypeBinding;
/*     */     //   365: aload_1
/*     */     //   366: getfield returnType : Lorg/eclipse/jdt/internal/compiler/lookup/TypeBinding;
/*     */     //   369: aload #16
/*     */     //   371: aconst_null
/*     */     //   372: iconst_0
/*     */     //   373: aconst_null
/*     */     //   374: getstatic org/eclipse/jdt/internal/compiler/ast/NullAnnotationMatching$CheckMode.OVERRIDE_RETURN : Lorg/eclipse/jdt/internal/compiler/ast/NullAnnotationMatching$CheckMode;
/*     */     //   377: invokestatic analyse : (Lorg/eclipse/jdt/internal/compiler/lookup/TypeBinding;Lorg/eclipse/jdt/internal/compiler/lookup/TypeBinding;Lorg/eclipse/jdt/internal/compiler/lookup/TypeBinding;Lorg/eclipse/jdt/internal/compiler/lookup/Substitution;ILorg/eclipse/jdt/internal/compiler/ast/Expression;Lorg/eclipse/jdt/internal/compiler/ast/NullAnnotationMatching$CheckMode;)Lorg/eclipse/jdt/internal/compiler/ast/NullAnnotationMatching;
/*     */     //   380: invokevirtual isAnyMismatch : ()Z
/*     */     //   383: ifeq -> 430
/*     */     //   386: aload_2
/*     */     //   387: ifnull -> 411
/*     */     //   390: aload #8
/*     */     //   392: invokevirtual problemReporter : ()Lorg/eclipse/jdt/internal/compiler/problem/ProblemReporter;
/*     */     //   395: aload_2
/*     */     //   396: aload #6
/*     */     //   398: aload_0
/*     */     //   399: getfield environment : Lorg/eclipse/jdt/internal/compiler/lookup/LookupEnvironment;
/*     */     //   402: invokevirtual getNonNullAnnotationName : ()[[C
/*     */     //   405: invokevirtual illegalReturnRedefinition : (Lorg/eclipse/jdt/internal/compiler/ast/AbstractMethodDeclaration;Lorg/eclipse/jdt/internal/compiler/lookup/MethodBinding;[[C)V
/*     */     //   408: goto -> 429
/*     */     //   411: aload #8
/*     */     //   413: invokevirtual problemReporter : ()Lorg/eclipse/jdt/internal/compiler/problem/ProblemReporter;
/*     */     //   416: aload #8
/*     */     //   418: invokevirtual referenceContext : ()Lorg/eclipse/jdt/internal/compiler/impl/ReferenceContext;
/*     */     //   421: aload_1
/*     */     //   422: aload #6
/*     */     //   424: iload #10
/*     */     //   426: invokevirtual cannotImplementIncompatibleNullness : (Lorg/eclipse/jdt/internal/compiler/impl/ReferenceContext;Lorg/eclipse/jdt/internal/compiler/lookup/MethodBinding;Lorg/eclipse/jdt/internal/compiler/lookup/MethodBinding;Z)V
/*     */     //   429: return
/*     */     //   430: aconst_null
/*     */     //   431: astore #16
/*     */     //   433: iload #5
/*     */     //   435: ifeq -> 475
/*     */     //   438: aload_1
/*     */     //   439: invokevirtual original : ()Lorg/eclipse/jdt/internal/compiler/lookup/MethodBinding;
/*     */     //   442: getfield typeVariables : [Lorg/eclipse/jdt/internal/compiler/lookup/TypeVariableBinding;
/*     */     //   445: astore #17
/*     */     //   447: aload #17
/*     */     //   449: getstatic org/eclipse/jdt/internal/compiler/lookup/Binding.NO_TYPE_VARIABLES : [Lorg/eclipse/jdt/internal/compiler/lookup/TypeVariableBinding;
/*     */     //   452: if_acmpeq -> 475
/*     */     //   455: aload_0
/*     */     //   456: getfield environment : Lorg/eclipse/jdt/internal/compiler/lookup/LookupEnvironment;
/*     */     //   459: aload #6
/*     */     //   461: aload #17
/*     */     //   463: invokevirtual createParameterizedGenericMethod : (Lorg/eclipse/jdt/internal/compiler/lookup/MethodBinding;[Lorg/eclipse/jdt/internal/compiler/lookup/TypeBinding;)Lorg/eclipse/jdt/internal/compiler/lookup/ParameterizedGenericMethodBinding;
/*     */     //   466: astore #18
/*     */     //   468: aload #18
/*     */     //   470: getfield parameters : [Lorg/eclipse/jdt/internal/compiler/lookup/TypeBinding;
/*     */     //   473: astore #16
/*     */     //   475: aload_2
/*     */     //   476: ifnonnull -> 483
/*     */     //   479: aconst_null
/*     */     //   480: goto -> 487
/*     */     //   483: aload_2
/*     */     //   484: getfield arguments : [Lorg/eclipse/jdt/internal/compiler/ast/Argument;
/*     */     //   487: astore #17
/*     */     //   489: iconst_0
/*     */     //   490: istore #18
/*     */     //   492: aload #17
/*     */     //   494: ifnull -> 502
/*     */     //   497: aload #17
/*     */     //   499: arraylength
/*     */     //   500: istore #18
/*     */     //   502: iload #10
/*     */     //   504: ifeq -> 517
/*     */     //   507: aload_1
/*     */     //   508: getfield parameters : [Lorg/eclipse/jdt/internal/compiler/lookup/TypeBinding;
/*     */     //   511: arraylength
/*     */     //   512: istore #18
/*     */     //   514: goto -> 550
/*     */     //   517: aload #6
/*     */     //   519: getfield parameterNonNullness : [Ljava/lang/Boolean;
/*     */     //   522: ifnull -> 536
/*     */     //   525: aload #6
/*     */     //   527: getfield parameterNonNullness : [Ljava/lang/Boolean;
/*     */     //   530: arraylength
/*     */     //   531: istore #18
/*     */     //   533: goto -> 550
/*     */     //   536: aload_1
/*     */     //   537: getfield parameterNonNullness : [Ljava/lang/Boolean;
/*     */     //   540: ifnull -> 550
/*     */     //   543: aload_1
/*     */     //   544: getfield parameterNonNullness : [Ljava/lang/Boolean;
/*     */     //   547: arraylength
/*     */     //   548: istore #18
/*     */     //   550: iconst_0
/*     */     //   551: istore #19
/*     */     //   553: goto -> 1249
/*     */     //   556: aload_1
/*     */     //   557: getfield parameters : [Lorg/eclipse/jdt/internal/compiler/lookup/TypeBinding;
/*     */     //   560: iload #19
/*     */     //   562: aaload
/*     */     //   563: invokevirtual isBaseType : ()Z
/*     */     //   566: ifeq -> 572
/*     */     //   569: goto -> 1246
/*     */     //   572: aload #17
/*     */     //   574: ifnonnull -> 581
/*     */     //   577: aconst_null
/*     */     //   578: goto -> 586
/*     */     //   581: aload #17
/*     */     //   583: iload #19
/*     */     //   585: aaload
/*     */     //   586: astore #20
/*     */     //   588: aload_0
/*     */     //   589: aload #6
/*     */     //   591: iload #19
/*     */     //   593: iload #10
/*     */     //   595: invokevirtual getParameterNonNullness : (Lorg/eclipse/jdt/internal/compiler/lookup/MethodBinding;IZ)Ljava/lang/Boolean;
/*     */     //   598: astore #21
/*     */     //   600: aload_0
/*     */     //   601: aload_1
/*     */     //   602: iload #19
/*     */     //   604: iload #10
/*     */     //   606: invokevirtual getParameterNonNullness : (Lorg/eclipse/jdt/internal/compiler/lookup/MethodBinding;IZ)Ljava/lang/Boolean;
/*     */     //   609: astore #22
/*     */     //   611: aload #22
/*     */     //   613: ifnonnull -> 821
/*     */     //   616: aload #21
/*     */     //   618: ifnull -> 747
/*     */     //   621: iload #15
/*     */     //   623: ifeq -> 747
/*     */     //   626: aload #4
/*     */     //   628: iload #19
/*     */     //   630: invokeinterface hasNonNullDefaultForParam : (I)Z
/*     */     //   635: ifeq -> 669
/*     */     //   638: iload #5
/*     */     //   640: ifeq -> 669
/*     */     //   643: aload #21
/*     */     //   645: getstatic java/lang/Boolean.FALSE : Ljava/lang/Boolean;
/*     */     //   648: if_acmpne -> 669
/*     */     //   651: aload #20
/*     */     //   653: ifnull -> 669
/*     */     //   656: aload #8
/*     */     //   658: invokevirtual problemReporter : ()Lorg/eclipse/jdt/internal/compiler/problem/ProblemReporter;
/*     */     //   661: aload_1
/*     */     //   662: aload #20
/*     */     //   664: aload #6
/*     */     //   666: invokevirtual conflictingNullAnnotations : (Lorg/eclipse/jdt/internal/compiler/lookup/MethodBinding;Lorg/eclipse/jdt/internal/compiler/ast/ASTNode;Lorg/eclipse/jdt/internal/compiler/lookup/MethodBinding;)V
/*     */     //   669: aload #9
/*     */     //   671: ifnull -> 708
/*     */     //   674: aload_2
/*     */     //   675: ifnull -> 708
/*     */     //   678: aload_0
/*     */     //   679: aload #8
/*     */     //   681: aload_2
/*     */     //   682: getfield arguments : [Lorg/eclipse/jdt/internal/compiler/ast/Argument;
/*     */     //   685: iload #19
/*     */     //   687: aaload
/*     */     //   688: getfield type : Lorg/eclipse/jdt/internal/compiler/ast/TypeReference;
/*     */     //   691: aload #6
/*     */     //   693: aload #21
/*     */     //   695: aload #9
/*     */     //   697: iload #19
/*     */     //   699: iconst_1
/*     */     //   700: iadd
/*     */     //   701: aaload
/*     */     //   702: invokevirtual recordDeferredInheritedNullness : (Lorg/eclipse/jdt/internal/compiler/lookup/Scope;Lorg/eclipse/jdt/internal/compiler/ast/ASTNode;Lorg/eclipse/jdt/internal/compiler/lookup/MethodBinding;Ljava/lang/Boolean;Lorg/eclipse/jdt/internal/compiler/lookup/ImplicitNullAnnotationVerifier$InheritedNonNullnessInfo;)V
/*     */     //   705: goto -> 1246
/*     */     //   708: iload #10
/*     */     //   710: ifne -> 729
/*     */     //   713: aload_0
/*     */     //   714: aload_1
/*     */     //   715: iload #18
/*     */     //   717: iload #19
/*     */     //   719: aload #20
/*     */     //   721: aload #21
/*     */     //   723: invokevirtual recordArgNonNullness : (Lorg/eclipse/jdt/internal/compiler/lookup/MethodBinding;IILorg/eclipse/jdt/internal/compiler/ast/Argument;Ljava/lang/Boolean;)V
/*     */     //   726: goto -> 1246
/*     */     //   729: aload_0
/*     */     //   730: aload_1
/*     */     //   731: iload #19
/*     */     //   733: aload #20
/*     */     //   735: aload #21
/*     */     //   737: aload_0
/*     */     //   738: getfield environment : Lorg/eclipse/jdt/internal/compiler/lookup/LookupEnvironment;
/*     */     //   741: invokevirtual recordArgNonNullness18 : (Lorg/eclipse/jdt/internal/compiler/lookup/MethodBinding;ILorg/eclipse/jdt/internal/compiler/ast/Argument;Ljava/lang/Boolean;Lorg/eclipse/jdt/internal/compiler/lookup/LookupEnvironment;)V
/*     */     //   744: goto -> 1246
/*     */     //   747: aload #4
/*     */     //   749: iload #19
/*     */     //   751: invokeinterface hasNonNullDefaultForParam : (I)Z
/*     */     //   756: ifeq -> 821
/*     */     //   759: getstatic java/lang/Boolean.TRUE : Ljava/lang/Boolean;
/*     */     //   762: astore #22
/*     */     //   764: iload #10
/*     */     //   766: ifne -> 786
/*     */     //   769: aload_0
/*     */     //   770: aload_1
/*     */     //   771: iload #18
/*     */     //   773: iload #19
/*     */     //   775: aload #20
/*     */     //   777: getstatic java/lang/Boolean.TRUE : Ljava/lang/Boolean;
/*     */     //   780: invokevirtual recordArgNonNullness : (Lorg/eclipse/jdt/internal/compiler/lookup/MethodBinding;IILorg/eclipse/jdt/internal/compiler/ast/Argument;Ljava/lang/Boolean;)V
/*     */     //   783: goto -> 821
/*     */     //   786: aload_1
/*     */     //   787: getfield parameters : [Lorg/eclipse/jdt/internal/compiler/lookup/TypeBinding;
/*     */     //   790: iload #19
/*     */     //   792: aaload
/*     */     //   793: invokevirtual acceptsNonNullDefault : ()Z
/*     */     //   796: ifeq -> 818
/*     */     //   799: aload_0
/*     */     //   800: aload_1
/*     */     //   801: iload #19
/*     */     //   803: aload #20
/*     */     //   805: getstatic java/lang/Boolean.TRUE : Ljava/lang/Boolean;
/*     */     //   808: aload_0
/*     */     //   809: getfield environment : Lorg/eclipse/jdt/internal/compiler/lookup/LookupEnvironment;
/*     */     //   812: invokevirtual recordArgNonNullness18 : (Lorg/eclipse/jdt/internal/compiler/lookup/MethodBinding;ILorg/eclipse/jdt/internal/compiler/ast/Argument;Ljava/lang/Boolean;Lorg/eclipse/jdt/internal/compiler/lookup/LookupEnvironment;)V
/*     */     //   815: goto -> 821
/*     */     //   818: aconst_null
/*     */     //   819: astore #22
/*     */     //   821: iload #5
/*     */     //   823: ifeq -> 1246
/*     */     //   826: aload #21
/*     */     //   828: getstatic java/lang/Boolean.TRUE : Ljava/lang/Boolean;
/*     */     //   831: if_acmpne -> 846
/*     */     //   834: aload_0
/*     */     //   835: getfield environment : Lorg/eclipse/jdt/internal/compiler/lookup/LookupEnvironment;
/*     */     //   838: invokevirtual getNonNullAnnotationName : ()[[C
/*     */     //   841: astore #23
/*     */     //   843: goto -> 855
/*     */     //   846: aload_0
/*     */     //   847: getfield environment : Lorg/eclipse/jdt/internal/compiler/lookup/LookupEnvironment;
/*     */     //   850: invokevirtual getNullableAnnotationName : ()[[C
/*     */     //   853: astore #23
/*     */     //   855: aload #21
/*     */     //   857: getstatic java/lang/Boolean.TRUE : Ljava/lang/Boolean;
/*     */     //   860: if_acmpeq -> 930
/*     */     //   863: aload #22
/*     */     //   865: getstatic java/lang/Boolean.TRUE : Ljava/lang/Boolean;
/*     */     //   868: if_acmpne -> 930
/*     */     //   871: aload #20
/*     */     //   873: ifnull -> 910
/*     */     //   876: aload #8
/*     */     //   878: invokevirtual problemReporter : ()Lorg/eclipse/jdt/internal/compiler/problem/ProblemReporter;
/*     */     //   881: aload #20
/*     */     //   883: aload #6
/*     */     //   885: getfield declaringClass : Lorg/eclipse/jdt/internal/compiler/lookup/ReferenceBinding;
/*     */     //   888: aload #21
/*     */     //   890: ifnonnull -> 897
/*     */     //   893: aconst_null
/*     */     //   894: goto -> 904
/*     */     //   897: aload_0
/*     */     //   898: getfield environment : Lorg/eclipse/jdt/internal/compiler/lookup/LookupEnvironment;
/*     */     //   901: invokevirtual getNullableAnnotationName : ()[[C
/*     */     //   904: invokevirtual illegalRedefinitionToNonNullParameter : (Lorg/eclipse/jdt/internal/compiler/ast/Argument;Lorg/eclipse/jdt/internal/compiler/lookup/ReferenceBinding;[[C)V
/*     */     //   907: goto -> 1246
/*     */     //   910: aload #8
/*     */     //   912: invokevirtual problemReporter : ()Lorg/eclipse/jdt/internal/compiler/problem/ProblemReporter;
/*     */     //   915: aload #8
/*     */     //   917: invokevirtual referenceContext : ()Lorg/eclipse/jdt/internal/compiler/impl/ReferenceContext;
/*     */     //   920: aload_1
/*     */     //   921: aload #6
/*     */     //   923: iconst_0
/*     */     //   924: invokevirtual cannotImplementIncompatibleNullness : (Lorg/eclipse/jdt/internal/compiler/impl/ReferenceContext;Lorg/eclipse/jdt/internal/compiler/lookup/MethodBinding;Lorg/eclipse/jdt/internal/compiler/lookup/MethodBinding;Z)V
/*     */     //   927: goto -> 1246
/*     */     //   930: aload #22
/*     */     //   932: ifnonnull -> 1147
/*     */     //   935: aload #21
/*     */     //   937: getstatic java/lang/Boolean.FALSE : Ljava/lang/Boolean;
/*     */     //   940: if_acmpne -> 988
/*     */     //   943: aload #20
/*     */     //   945: ifnull -> 968
/*     */     //   948: aload #8
/*     */     //   950: invokevirtual problemReporter : ()Lorg/eclipse/jdt/internal/compiler/problem/ProblemReporter;
/*     */     //   953: aload #20
/*     */     //   955: aload #6
/*     */     //   957: getfield declaringClass : Lorg/eclipse/jdt/internal/compiler/lookup/ReferenceBinding;
/*     */     //   960: aload #23
/*     */     //   962: invokevirtual parameterLackingNullableAnnotation : (Lorg/eclipse/jdt/internal/compiler/ast/Argument;Lorg/eclipse/jdt/internal/compiler/lookup/ReferenceBinding;[[C)V
/*     */     //   965: goto -> 1246
/*     */     //   968: aload #8
/*     */     //   970: invokevirtual problemReporter : ()Lorg/eclipse/jdt/internal/compiler/problem/ProblemReporter;
/*     */     //   973: aload #8
/*     */     //   975: invokevirtual referenceContext : ()Lorg/eclipse/jdt/internal/compiler/impl/ReferenceContext;
/*     */     //   978: aload_1
/*     */     //   979: aload #6
/*     */     //   981: iconst_0
/*     */     //   982: invokevirtual cannotImplementIncompatibleNullness : (Lorg/eclipse/jdt/internal/compiler/impl/ReferenceContext;Lorg/eclipse/jdt/internal/compiler/lookup/MethodBinding;Lorg/eclipse/jdt/internal/compiler/lookup/MethodBinding;Z)V
/*     */     //   985: goto -> 1246
/*     */     //   988: aload #21
/*     */     //   990: getstatic java/lang/Boolean.TRUE : Ljava/lang/Boolean;
/*     */     //   993: if_acmpne -> 1147
/*     */     //   996: aload #7
/*     */     //   998: ifnull -> 1067
/*     */     //   1001: aload #7
/*     */     //   1003: dup
/*     */     //   1004: astore #27
/*     */     //   1006: arraylength
/*     */     //   1007: istore #26
/*     */     //   1009: iconst_0
/*     */     //   1010: istore #25
/*     */     //   1012: goto -> 1060
/*     */     //   1015: aload #27
/*     */     //   1017: iload #25
/*     */     //   1019: aaload
/*     */     //   1020: astore #24
/*     */     //   1022: aload #6
/*     */     //   1024: getfield declaringClass : Lorg/eclipse/jdt/internal/compiler/lookup/ReferenceBinding;
/*     */     //   1027: aload #24
/*     */     //   1029: getfield declaringClass : Lorg/eclipse/jdt/internal/compiler/lookup/ReferenceBinding;
/*     */     //   1032: invokestatic equalsEquals : (Lorg/eclipse/jdt/internal/compiler/lookup/TypeBinding;Lorg/eclipse/jdt/internal/compiler/lookup/TypeBinding;)Z
/*     */     //   1035: ifeq -> 1057
/*     */     //   1038: aload_0
/*     */     //   1039: aload #24
/*     */     //   1041: iload #19
/*     */     //   1043: iload #10
/*     */     //   1045: invokevirtual getParameterNonNullness : (Lorg/eclipse/jdt/internal/compiler/lookup/MethodBinding;IZ)Ljava/lang/Boolean;
/*     */     //   1048: getstatic java/lang/Boolean.TRUE : Ljava/lang/Boolean;
/*     */     //   1051: if_acmpeq -> 1057
/*     */     //   1054: goto -> 1246
/*     */     //   1057: iinc #25, 1
/*     */     //   1060: iload #25
/*     */     //   1062: iload #26
/*     */     //   1064: if_icmplt -> 1015
/*     */     //   1067: aload #20
/*     */     //   1069: ifnull -> 1092
/*     */     //   1072: aload #8
/*     */     //   1074: invokevirtual problemReporter : ()Lorg/eclipse/jdt/internal/compiler/problem/ProblemReporter;
/*     */     //   1077: aload #20
/*     */     //   1079: aload #6
/*     */     //   1081: getfield declaringClass : Lorg/eclipse/jdt/internal/compiler/lookup/ReferenceBinding;
/*     */     //   1084: aload #23
/*     */     //   1086: invokevirtual parameterLackingNonnullAnnotation : (Lorg/eclipse/jdt/internal/compiler/ast/Argument;Lorg/eclipse/jdt/internal/compiler/lookup/ReferenceBinding;[[C)V
/*     */     //   1089: goto -> 1246
/*     */     //   1092: aload #8
/*     */     //   1094: invokevirtual classScope : ()Lorg/eclipse/jdt/internal/compiler/lookup/ClassScope;
/*     */     //   1097: getfield referenceContext : Lorg/eclipse/jdt/internal/compiler/ast/TypeDeclaration;
/*     */     //   1100: astore #24
/*     */     //   1102: aload #24
/*     */     //   1104: getfield superclass : Lorg/eclipse/jdt/internal/compiler/ast/TypeReference;
/*     */     //   1107: ifnull -> 1118
/*     */     //   1110: aload #24
/*     */     //   1112: getfield superclass : Lorg/eclipse/jdt/internal/compiler/ast/TypeReference;
/*     */     //   1115: goto -> 1120
/*     */     //   1118: aload #24
/*     */     //   1120: astore #25
/*     */     //   1122: aload #8
/*     */     //   1124: invokevirtual problemReporter : ()Lorg/eclipse/jdt/internal/compiler/problem/ProblemReporter;
/*     */     //   1127: aload_1
/*     */     //   1128: iload #19
/*     */     //   1130: iconst_1
/*     */     //   1131: iadd
/*     */     //   1132: aload #6
/*     */     //   1134: getfield declaringClass : Lorg/eclipse/jdt/internal/compiler/lookup/ReferenceBinding;
/*     */     //   1137: aload #25
/*     */     //   1139: aload #23
/*     */     //   1141: invokevirtual inheritedParameterLackingNonnullAnnotation : (Lorg/eclipse/jdt/internal/compiler/lookup/MethodBinding;ILorg/eclipse/jdt/internal/compiler/lookup/ReferenceBinding;Lorg/eclipse/jdt/internal/compiler/ast/ASTNode;[[C)V
/*     */     //   1144: goto -> 1246
/*     */     //   1147: iload #10
/*     */     //   1149: ifeq -> 1246
/*     */     //   1152: aload #6
/*     */     //   1154: getfield parameters : [Lorg/eclipse/jdt/internal/compiler/lookup/TypeBinding;
/*     */     //   1157: iload #19
/*     */     //   1159: aaload
/*     */     //   1160: astore #24
/*     */     //   1162: aload #16
/*     */     //   1164: ifnull -> 1175
/*     */     //   1167: aload #16
/*     */     //   1169: iload #19
/*     */     //   1171: aaload
/*     */     //   1172: goto -> 1176
/*     */     //   1175: aconst_null
/*     */     //   1176: astore #25
/*     */     //   1178: aload_1
/*     */     //   1179: getfield parameters : [Lorg/eclipse/jdt/internal/compiler/lookup/TypeBinding;
/*     */     //   1182: iload #19
/*     */     //   1184: aaload
/*     */     //   1185: aload #24
/*     */     //   1187: aload #25
/*     */     //   1189: aconst_null
/*     */     //   1190: iconst_0
/*     */     //   1191: aconst_null
/*     */     //   1192: getstatic org/eclipse/jdt/internal/compiler/ast/NullAnnotationMatching$CheckMode.OVERRIDE : Lorg/eclipse/jdt/internal/compiler/ast/NullAnnotationMatching$CheckMode;
/*     */     //   1195: invokestatic analyse : (Lorg/eclipse/jdt/internal/compiler/lookup/TypeBinding;Lorg/eclipse/jdt/internal/compiler/lookup/TypeBinding;Lorg/eclipse/jdt/internal/compiler/lookup/TypeBinding;Lorg/eclipse/jdt/internal/compiler/lookup/Substitution;ILorg/eclipse/jdt/internal/compiler/ast/Expression;Lorg/eclipse/jdt/internal/compiler/ast/NullAnnotationMatching$CheckMode;)Lorg/eclipse/jdt/internal/compiler/ast/NullAnnotationMatching;
/*     */     //   1198: invokevirtual isAnyMismatch : ()Z
/*     */     //   1201: ifeq -> 1246
/*     */     //   1204: aload #20
/*     */     //   1206: ifnull -> 1229
/*     */     //   1209: aload #8
/*     */     //   1211: invokevirtual problemReporter : ()Lorg/eclipse/jdt/internal/compiler/problem/ProblemReporter;
/*     */     //   1214: aload #20
/*     */     //   1216: aload #6
/*     */     //   1218: getfield declaringClass : Lorg/eclipse/jdt/internal/compiler/lookup/ReferenceBinding;
/*     */     //   1221: aload #24
/*     */     //   1223: invokevirtual illegalParameterRedefinition : (Lorg/eclipse/jdt/internal/compiler/ast/Argument;Lorg/eclipse/jdt/internal/compiler/lookup/ReferenceBinding;Lorg/eclipse/jdt/internal/compiler/lookup/TypeBinding;)V
/*     */     //   1226: goto -> 1246
/*     */     //   1229: aload #8
/*     */     //   1231: invokevirtual problemReporter : ()Lorg/eclipse/jdt/internal/compiler/problem/ProblemReporter;
/*     */     //   1234: aload #8
/*     */     //   1236: invokevirtual referenceContext : ()Lorg/eclipse/jdt/internal/compiler/impl/ReferenceContext;
/*     */     //   1239: aload_1
/*     */     //   1240: aload #6
/*     */     //   1242: iconst_0
/*     */     //   1243: invokevirtual cannotImplementIncompatibleNullness : (Lorg/eclipse/jdt/internal/compiler/impl/ReferenceContext;Lorg/eclipse/jdt/internal/compiler/lookup/MethodBinding;Lorg/eclipse/jdt/internal/compiler/lookup/MethodBinding;Z)V
/*     */     //   1246: iinc #19, 1
/*     */     //   1249: iload #19
/*     */     //   1251: iload #18
/*     */     //   1253: if_icmplt -> 556
/*     */     //   1256: iload #5
/*     */     //   1258: ifeq -> 1366
/*     */     //   1261: iload #10
/*     */     //   1263: ifeq -> 1366
/*     */     //   1266: aload_2
/*     */     //   1267: ifnull -> 1366
/*     */     //   1270: aload_1
/*     */     //   1271: invokevirtual typeVariables : ()[Lorg/eclipse/jdt/internal/compiler/lookup/TypeVariableBinding;
/*     */     //   1274: astore #19
/*     */     //   1276: aload #6
/*     */     //   1278: invokevirtual typeVariables : ()[Lorg/eclipse/jdt/internal/compiler/lookup/TypeVariableBinding;
/*     */     //   1281: astore #20
/*     */     //   1283: aload #19
/*     */     //   1285: getstatic org/eclipse/jdt/internal/compiler/lookup/Binding.NO_TYPE_VARIABLES : [Lorg/eclipse/jdt/internal/compiler/lookup/TypeVariableBinding;
/*     */     //   1288: if_acmpeq -> 1366
/*     */     //   1291: aload #19
/*     */     //   1293: arraylength
/*     */     //   1294: aload #20
/*     */     //   1296: arraylength
/*     */     //   1297: if_icmpne -> 1366
/*     */     //   1300: iconst_0
/*     */     //   1301: istore #21
/*     */     //   1303: goto -> 1358
/*     */     //   1306: aload #20
/*     */     //   1308: iload #21
/*     */     //   1310: aaload
/*     */     //   1311: astore #22
/*     */     //   1313: aload #22
/*     */     //   1315: aload #19
/*     */     //   1317: iload #21
/*     */     //   1319: aaload
/*     */     //   1320: aconst_null
/*     */     //   1321: aconst_null
/*     */     //   1322: iconst_m1
/*     */     //   1323: aconst_null
/*     */     //   1324: getstatic org/eclipse/jdt/internal/compiler/ast/NullAnnotationMatching$CheckMode.BOUND_CHECK : Lorg/eclipse/jdt/internal/compiler/ast/NullAnnotationMatching$CheckMode;
/*     */     //   1327: invokestatic analyse : (Lorg/eclipse/jdt/internal/compiler/lookup/TypeBinding;Lorg/eclipse/jdt/internal/compiler/lookup/TypeBinding;Lorg/eclipse/jdt/internal/compiler/lookup/TypeBinding;Lorg/eclipse/jdt/internal/compiler/lookup/Substitution;ILorg/eclipse/jdt/internal/compiler/ast/Expression;Lorg/eclipse/jdt/internal/compiler/ast/NullAnnotationMatching$CheckMode;)Lorg/eclipse/jdt/internal/compiler/ast/NullAnnotationMatching;
/*     */     //   1330: invokevirtual isAnyMismatch : ()Z
/*     */     //   1333: ifeq -> 1355
/*     */     //   1336: aload #8
/*     */     //   1338: invokevirtual problemReporter : ()Lorg/eclipse/jdt/internal/compiler/problem/ProblemReporter;
/*     */     //   1341: aload #22
/*     */     //   1343: aload #6
/*     */     //   1345: aload_2
/*     */     //   1346: invokevirtual typeParameters : ()[Lorg/eclipse/jdt/internal/compiler/ast/TypeParameter;
/*     */     //   1349: iload #21
/*     */     //   1351: aaload
/*     */     //   1352: invokevirtual cannotRedefineTypeArgumentNullity : (Lorg/eclipse/jdt/internal/compiler/lookup/TypeBinding;Lorg/eclipse/jdt/internal/compiler/lookup/Binding;Lorg/eclipse/jdt/internal/compiler/ast/ASTNode;)V
/*     */     //   1355: iinc #21, 1
/*     */     //   1358: iload #21
/*     */     //   1360: aload #19
/*     */     //   1362: arraylength
/*     */     //   1363: if_icmplt -> 1306
/*     */     //   1366: return
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #246	-> 0
/*     */     //   #248	-> 11
/*     */     //   #260	-> 12
/*     */     //   #262	-> 26
/*     */     //   #264	-> 39
/*     */     //   #265	-> 48
/*     */     //   #266	-> 58
/*     */     //   #268	-> 67
/*     */     //   #272	-> 73
/*     */     //   #273	-> 90
/*     */     //   #274	-> 93
/*     */     //   #276	-> 100
/*     */     //   #277	-> 105
/*     */     //   #278	-> 112
/*     */     //   #280	-> 116
/*     */     //   #281	-> 130
/*     */     //   #284	-> 148
/*     */     //   #285	-> 157
/*     */     //   #286	-> 167
/*     */     //   #285	-> 190
/*     */     //   #287	-> 193
/*     */     //   #289	-> 196
/*     */     //   #291	-> 203
/*     */     //   #294	-> 206
/*     */     //   #295	-> 225
/*     */     //   #296	-> 230
/*     */     //   #299	-> 237
/*     */     //   #300	-> 242
/*     */     //   #301	-> 253
/*     */     //   #303	-> 262
/*     */     //   #304	-> 266
/*     */     //   #305	-> 274
/*     */     //   #304	-> 281
/*     */     //   #306	-> 284
/*     */     //   #308	-> 287
/*     */     //   #309	-> 305
/*     */     //   #312	-> 306
/*     */     //   #313	-> 311
/*     */     //   #314	-> 314
/*     */     //   #315	-> 324
/*     */     //   #316	-> 341
/*     */     //   #317	-> 353
/*     */     //   #319	-> 360
/*     */     //   #320	-> 386
/*     */     //   #321	-> 390
/*     */     //   #322	-> 398
/*     */     //   #321	-> 405
/*     */     //   #322	-> 408
/*     */     //   #324	-> 411
/*     */     //   #325	-> 429
/*     */     //   #332	-> 430
/*     */     //   #333	-> 433
/*     */     //   #334	-> 438
/*     */     //   #335	-> 447
/*     */     //   #336	-> 455
/*     */     //   #337	-> 468
/*     */     //   #341	-> 475
/*     */     //   #343	-> 489
/*     */     //   #344	-> 492
/*     */     //   #345	-> 497
/*     */     //   #346	-> 502
/*     */     //   #347	-> 507
/*     */     //   #348	-> 517
/*     */     //   #349	-> 525
/*     */     //   #350	-> 536
/*     */     //   #351	-> 543
/*     */     //   #354	-> 550
/*     */     //   #355	-> 556
/*     */     //   #357	-> 572
/*     */     //   #358	-> 577
/*     */     //   #357	-> 586
/*     */     //   #359	-> 588
/*     */     //   #360	-> 600
/*     */     //   #362	-> 611
/*     */     //   #364	-> 616
/*     */     //   #365	-> 621
/*     */     //   #366	-> 626
/*     */     //   #368	-> 638
/*     */     //   #369	-> 643
/*     */     //   #370	-> 651
/*     */     //   #372	-> 656
/*     */     //   #376	-> 669
/*     */     //   #377	-> 678
/*     */     //   #378	-> 691
/*     */     //   #377	-> 702
/*     */     //   #379	-> 705
/*     */     //   #381	-> 708
/*     */     //   #382	-> 713
/*     */     //   #384	-> 729
/*     */     //   #386	-> 744
/*     */     //   #389	-> 747
/*     */     //   #390	-> 759
/*     */     //   #391	-> 764
/*     */     //   #392	-> 769
/*     */     //   #393	-> 786
/*     */     //   #394	-> 799
/*     */     //   #396	-> 818
/*     */     //   #399	-> 821
/*     */     //   #401	-> 826
/*     */     //   #402	-> 834
/*     */     //   #403	-> 843
/*     */     //   #404	-> 846
/*     */     //   #406	-> 855
/*     */     //   #407	-> 863
/*     */     //   #410	-> 871
/*     */     //   #411	-> 876
/*     */     //   #412	-> 881
/*     */     //   #413	-> 883
/*     */     //   #414	-> 888
/*     */     //   #411	-> 904
/*     */     //   #415	-> 907
/*     */     //   #416	-> 910
/*     */     //   #418	-> 927
/*     */     //   #419	-> 930
/*     */     //   #422	-> 935
/*     */     //   #423	-> 943
/*     */     //   #424	-> 948
/*     */     //   #425	-> 953
/*     */     //   #426	-> 955
/*     */     //   #427	-> 960
/*     */     //   #424	-> 962
/*     */     //   #428	-> 965
/*     */     //   #429	-> 968
/*     */     //   #431	-> 985
/*     */     //   #432	-> 988
/*     */     //   #434	-> 996
/*     */     //   #436	-> 1001
/*     */     //   #437	-> 1022
/*     */     //   #438	-> 1054
/*     */     //   #436	-> 1057
/*     */     //   #440	-> 1067
/*     */     //   #441	-> 1072
/*     */     //   #442	-> 1089
/*     */     //   #443	-> 1092
/*     */     //   #444	-> 1102
/*     */     //   #445	-> 1122
/*     */     //   #447	-> 1144
/*     */     //   #450	-> 1147
/*     */     //   #451	-> 1152
/*     */     //   #452	-> 1162
/*     */     //   #453	-> 1178
/*     */     //   #454	-> 1204
/*     */     //   #455	-> 1209
/*     */     //   #457	-> 1229
/*     */     //   #354	-> 1246
/*     */     //   #463	-> 1256
/*     */     //   #464	-> 1270
/*     */     //   #465	-> 1276
/*     */     //   #466	-> 1283
/*     */     //   #467	-> 1300
/*     */     //   #468	-> 1306
/*     */     //   #469	-> 1313
/*     */     //   #470	-> 1336
/*     */     //   #467	-> 1355
/*     */     //   #474	-> 1366
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	descriptor
/*     */     //   0	1367	0	this	Lorg/eclipse/jdt/internal/compiler/lookup/ImplicitNullAnnotationVerifier;
/*     */     //   0	1367	1	currentMethod	Lorg/eclipse/jdt/internal/compiler/lookup/MethodBinding;
/*     */     //   0	1367	2	srcMethod	Lorg/eclipse/jdt/internal/compiler/ast/AbstractMethodDeclaration;
/*     */     //   0	1367	3	hasReturnNonNullDefault	Z
/*     */     //   0	1367	4	hasParameterNonNullDefault	Lorg/eclipse/jdt/internal/compiler/lookup/ParameterNonNullDefaultProvider;
/*     */     //   0	1367	5	shouldComplain	Z
/*     */     //   0	1367	6	inheritedMethod	Lorg/eclipse/jdt/internal/compiler/lookup/MethodBinding;
/*     */     //   0	1367	7	allInheritedMethods	[Lorg/eclipse/jdt/internal/compiler/lookup/MethodBinding;
/*     */     //   0	1367	8	scope	Lorg/eclipse/jdt/internal/compiler/lookup/Scope;
/*     */     //   0	1367	9	inheritedNonNullnessInfos	[Lorg/eclipse/jdt/internal/compiler/lookup/ImplicitNullAnnotationVerifier$InheritedNonNullnessInfo;
/*     */     //   48	1319	10	useTypeAnnotations	Z
/*     */     //   58	1309	11	inheritedNullnessBits	J
/*     */     //   67	1300	13	currentNullnessBits	J
/*     */     //   73	1294	15	shouldInherit	Z
/*     */     //   314	116	16	substituteReturnType	Lorg/eclipse/jdt/internal/compiler/lookup/TypeBinding;
/*     */     //   324	106	17	typeVariables	[Lorg/eclipse/jdt/internal/compiler/lookup/TypeVariableBinding;
/*     */     //   353	7	18	substitute	Lorg/eclipse/jdt/internal/compiler/lookup/ParameterizedGenericMethodBinding;
/*     */     //   433	934	16	substituteParameters	[Lorg/eclipse/jdt/internal/compiler/lookup/TypeBinding;
/*     */     //   447	28	17	typeVariables	[Lorg/eclipse/jdt/internal/compiler/lookup/TypeVariableBinding;
/*     */     //   468	7	18	substitute	Lorg/eclipse/jdt/internal/compiler/lookup/ParameterizedGenericMethodBinding;
/*     */     //   489	878	17	currentArguments	[Lorg/eclipse/jdt/internal/compiler/ast/Argument;
/*     */     //   492	875	18	length	I
/*     */     //   553	703	19	i	I
/*     */     //   588	658	20	currentArgument	Lorg/eclipse/jdt/internal/compiler/ast/Argument;
/*     */     //   600	646	21	inheritedNonNullNess	Ljava/lang/Boolean;
/*     */     //   611	635	22	currentNonNullNess	Ljava/lang/Boolean;
/*     */     //   843	3	23	annotationName	[[C
/*     */     //   855	391	23	annotationName	[[C
/*     */     //   1022	35	24	one	Lorg/eclipse/jdt/internal/compiler/lookup/MethodBinding;
/*     */     //   1102	42	24	type	Lorg/eclipse/jdt/internal/compiler/ast/TypeDeclaration;
/*     */     //   1122	22	25	location	Lorg/eclipse/jdt/internal/compiler/ast/ASTNode;
/*     */     //   1162	84	24	inheritedParameter	Lorg/eclipse/jdt/internal/compiler/lookup/TypeBinding;
/*     */     //   1178	68	25	substituteParameter	Lorg/eclipse/jdt/internal/compiler/lookup/TypeBinding;
/*     */     //   1276	90	19	currentTypeVariables	[Lorg/eclipse/jdt/internal/compiler/lookup/TypeVariableBinding;
/*     */     //   1283	83	20	inheritedTypeVariables	[Lorg/eclipse/jdt/internal/compiler/lookup/TypeVariableBinding;
/*     */     //   1303	63	21	i	I
/*     */     //   1313	42	22	inheritedVariable	Lorg/eclipse/jdt/internal/compiler/lookup/TypeVariableBinding;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void applyReturnNullBits(MethodBinding method, long nullnessBits) {
/* 477 */     if (this.environment.usesNullTypeAnnotations()) {
/* 478 */       if (!method.returnType.isBaseType()) {
/* 479 */         method.returnType = this.environment.createAnnotatedType(method.returnType, this.environment.nullAnnotationsFromTagBits(nullnessBits));
/*     */       }
/*     */     } else {
/* 482 */       method.tagBits |= nullnessBits;
/*     */     } 
/*     */   }
/*     */   
/*     */   private Boolean getParameterNonNullness(MethodBinding method, int i, boolean useTypeAnnotations) {
/* 487 */     if (useTypeAnnotations) {
/* 488 */       TypeBinding parameter = method.parameters[i];
/* 489 */       if (parameter != null) {
/* 490 */         long nullBits = NullAnnotationMatching.validNullTagBits(parameter.tagBits);
/* 491 */         if (nullBits != 0L)
/* 492 */           return Boolean.valueOf((nullBits == 72057594037927936L)); 
/*     */       } 
/* 494 */       return null;
/*     */     } 
/* 496 */     return (method.parameterNonNullness == null) ? 
/* 497 */       null : method.parameterNonNullness[i];
/*     */   }
/*     */   
/*     */   private long getReturnTypeNullnessTagBits(MethodBinding method, boolean useTypeAnnotations) {
/* 501 */     if (useTypeAnnotations) {
/* 502 */       if (method.returnType == null)
/* 503 */         return 0L; 
/* 504 */       return NullAnnotationMatching.validNullTagBits(method.returnType.tagBits);
/*     */     } 
/* 506 */     return method.tagBits & 0x180000000000000L;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void recordDeferredInheritedNullness(Scope scope, ASTNode location, MethodBinding inheritedMethod, Boolean inheritedNonNullness, InheritedNonNullnessInfo nullnessInfo) {
/* 514 */     if (nullnessInfo.inheritedNonNullness != null && nullnessInfo.inheritedNonNullness != inheritedNonNullness) {
/* 515 */       scope.problemReporter().conflictingInheritedNullAnnotations(location, 
/* 516 */           nullnessInfo.inheritedNonNullness.booleanValue(), nullnessInfo.annotationOrigin, 
/* 517 */           inheritedNonNullness.booleanValue(), inheritedMethod);
/* 518 */       nullnessInfo.complained = true;
/*     */     } else {
/*     */       
/* 521 */       nullnessInfo.inheritedNonNullness = inheritedNonNullness;
/* 522 */       nullnessInfo.annotationOrigin = inheritedMethod;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   void recordArgNonNullness(MethodBinding method, int paramCount, int paramIdx, Argument currentArgument, Boolean nonNullNess) {
/* 528 */     if (method.parameterNonNullness == null)
/* 529 */       method.parameterNonNullness = new Boolean[paramCount]; 
/* 530 */     method.parameterNonNullness[paramIdx] = nonNullNess;
/* 531 */     if (currentArgument != null)
/* 532 */       currentArgument.binding.tagBits = currentArgument.binding.tagBits | (nonNullNess.booleanValue() ? 
/* 533 */         72057594037927936L : 36028797018963968L); 
/*     */   }
/*     */   
/*     */   void recordArgNonNullness18(MethodBinding method, int paramIdx, Argument currentArgument, Boolean nonNullNess, LookupEnvironment env) {
/* 537 */     AnnotationBinding annotationBinding = nonNullNess.booleanValue() ? env.getNonNullAnnotation() : env.getNullableAnnotation();
/* 538 */     method.parameters[paramIdx] = env.createAnnotatedType(method.parameters[paramIdx], new AnnotationBinding[] { annotationBinding });
/* 539 */     if (currentArgument != null) {
/* 540 */       currentArgument.binding.type = method.parameters[paramIdx];
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   static boolean areParametersEqual(MethodBinding one, MethodBinding two) {
/* 547 */     TypeBinding[] oneArgs = one.parameters;
/* 548 */     TypeBinding[] twoArgs = two.parameters;
/* 549 */     if (oneArgs == twoArgs) return true;
/*     */     
/* 551 */     int length = oneArgs.length;
/* 552 */     if (length != twoArgs.length) return false;
/*     */ 
/*     */ 
/*     */     
/*     */     int i;
/*     */     
/* 558 */     for (i = 0; i < length; i++) {
/* 559 */       if (!areTypesEqual(oneArgs[i], twoArgs[i])) {
/* 560 */         if (oneArgs[i].leafComponentType().isRawType() && 
/* 561 */           oneArgs[i].dimensions() == twoArgs[i].dimensions() && oneArgs[i].leafComponentType().isEquivalentTo(twoArgs[i].leafComponentType())) {
/*     */           
/* 563 */           if (one.typeVariables != Binding.NO_TYPE_VARIABLES) {
/* 564 */             return false;
/*     */           }
/*     */           
/* 567 */           for (int j = 0; j < i; j++) {
/* 568 */             if (oneArgs[j].leafComponentType().isParameterizedTypeWithActualArguments()) {
/* 569 */               return false;
/*     */             }
/*     */           } 
/*     */           break;
/*     */         } 
/* 574 */         return false;
/*     */       } 
/*     */     } 
/*     */     
/* 578 */     for (; ++i < length; i++) {
/* 579 */       if (!areTypesEqual(oneArgs[i], twoArgs[i])) {
/* 580 */         if (!oneArgs[i].leafComponentType().isRawType() || 
/* 581 */           oneArgs[i].dimensions() != twoArgs[i].dimensions() || !oneArgs[i].leafComponentType().isEquivalentTo(twoArgs[i].leafComponentType()))
/*     */         {
/* 583 */           return false; } 
/* 584 */       } else if (oneArgs[i].leafComponentType().isParameterizedTypeWithActualArguments()) {
/* 585 */         return false;
/*     */       } 
/*     */     } 
/* 588 */     return true;
/*     */   }
/*     */   static boolean areTypesEqual(TypeBinding one, TypeBinding two) {
/* 591 */     if (TypeBinding.equalsEquals(one, two)) return true;
/*     */     
/* 593 */     switch (one.kind()) {
/*     */       case 4:
/* 595 */         switch (two.kind()) {
/*     */           case 260:
/*     */           case 1028:
/* 598 */             if (TypeBinding.equalsEquals(one, two.erasure()))
/* 599 */               return true;  break;
/*     */         } 
/*     */         break;
/*     */       case 260:
/*     */       case 1028:
/* 604 */         switch (two.kind()) {
/*     */           case 4:
/* 606 */             if (TypeBinding.equalsEquals(one.erasure(), two))
/* 607 */               return true; 
/*     */             break;
/*     */         } 
/*     */         break;
/*     */     } 
/* 612 */     if (one.isParameterizedType() && two.isParameterizedType()) {
/* 613 */       return (one.isEquivalentTo(two) && two.isEquivalentTo(one));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 620 */     return false;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\lookup\ImplicitNullAnnotationVerifier.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */