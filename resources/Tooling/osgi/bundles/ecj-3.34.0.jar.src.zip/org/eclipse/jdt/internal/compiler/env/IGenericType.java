package org.eclipse.jdt.internal.compiler.env;

public interface IGenericType extends IDependent {
  int getModifiers();
  
  boolean isBinaryType();
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\env\IGenericType.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */