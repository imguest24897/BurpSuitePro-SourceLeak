/*    */ package org.eclipse.jdt.internal.compiler.lookup;
/*    */ 
/*    */ import java.util.Arrays;
/*    */ import java.util.Objects;
/*    */ import org.eclipse.jdt.core.compiler.CharOperation;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AptBinaryLocalVariableBinding
/*    */   extends LocalVariableBinding
/*    */ {
/*    */   AnnotationBinding[] annotationBindings;
/*    */   public MethodBinding methodBinding;
/*    */   
/*    */   public AptBinaryLocalVariableBinding(char[] name, TypeBinding type, int modifiers, AnnotationBinding[] annotationBindings, MethodBinding methodBinding) {
/* 27 */     super(name, type, modifiers, true);
/* 28 */     this.annotationBindings = (annotationBindings == null) ? Binding.NO_ANNOTATIONS : annotationBindings;
/* 29 */     this.methodBinding = methodBinding;
/*    */   }
/*    */ 
/*    */   
/*    */   public AnnotationBinding[] getAnnotations() {
/* 34 */     return this.annotationBindings;
/*    */   }
/*    */ 
/*    */   
/*    */   public int hashCode() {
/* 39 */     int result = 17;
/* 40 */     int c = CharOperation.hashCode(this.name);
/* 41 */     result = 31 * result + c;
/* 42 */     c = this.type.hashCode();
/* 43 */     result = 31 * result + c;
/* 44 */     c = this.modifiers;
/* 45 */     result = 31 * result + c;
/* 46 */     c = Arrays.hashCode((Object[])this.annotationBindings);
/* 47 */     result = 31 * result + c;
/* 48 */     c = this.methodBinding.hashCode();
/* 49 */     result = 31 * result + c;
/* 50 */     return result;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean equals(Object obj) {
/* 55 */     if (this == obj)
/* 56 */       return true; 
/* 57 */     if (obj == null)
/* 58 */       return false; 
/* 59 */     if (getClass() != obj.getClass())
/* 60 */       return false; 
/* 61 */     AptBinaryLocalVariableBinding other = (AptBinaryLocalVariableBinding)obj;
/* 62 */     return (CharOperation.equals(this.name, other.name) && 
/* 63 */       Objects.equals(this.type, other.type) && 
/* 64 */       this.modifiers == other.modifiers && 
/* 65 */       Arrays.equals((Object[])this.annotationBindings, (Object[])other.annotationBindings) && 
/* 66 */       Objects.equals(this.methodBinding, other.methodBinding));
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\lookup\AptBinaryLocalVariableBinding.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */