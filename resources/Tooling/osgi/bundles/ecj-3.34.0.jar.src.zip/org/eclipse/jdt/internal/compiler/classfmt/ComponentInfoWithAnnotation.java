/*    */ package org.eclipse.jdt.internal.compiler.classfmt;
/*    */ 
/*    */ import org.eclipse.jdt.internal.compiler.env.IBinaryAnnotation;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ComponentInfoWithAnnotation
/*    */   extends RecordComponentInfo
/*    */ {
/*    */   private AnnotationInfo[] annotations;
/*    */   
/*    */   ComponentInfoWithAnnotation(RecordComponentInfo info, AnnotationInfo[] annos) {
/* 19 */     super(info.reference, info.constantPoolOffsets, info.structOffset, info.version);
/* 20 */     this.attributeBytes = info.attributeBytes;
/* 21 */     this.constantPoolOffsets = info.constantPoolOffsets;
/* 22 */     this.descriptor = info.descriptor;
/* 23 */     this.name = info.name;
/* 24 */     this.signature = info.signature;
/* 25 */     this.signatureUtf8Offset = info.signatureUtf8Offset;
/* 26 */     this.tagBits = info.tagBits;
/* 27 */     this.annotations = annos;
/*    */   }
/*    */   
/*    */   public IBinaryAnnotation[] getAnnotations() {
/* 31 */     return (IBinaryAnnotation[])this.annotations;
/*    */   }
/*    */   
/*    */   protected void initialize() {
/* 35 */     if (this.annotations != null)
/* 36 */       for (int i = 0, max = this.annotations.length; i < max; i++)
/* 37 */         this.annotations[i].initialize();  
/* 38 */     super.initialize();
/*    */   }
/*    */   
/*    */   protected void reset() {
/* 42 */     if (this.annotations != null)
/* 43 */       for (int i = 0, max = this.annotations.length; i < max; i++)
/* 44 */         this.annotations[i].reset();  
/* 45 */     super.reset();
/*    */   }
/*    */   
/*    */   public String toString() {
/* 49 */     StringBuffer buffer = new StringBuffer(getClass().getName());
/* 50 */     if (this.annotations != null) {
/* 51 */       buffer.append('\n');
/* 52 */       for (int i = 0; i < this.annotations.length; i++) {
/* 53 */         buffer.append(this.annotations[i]);
/* 54 */         buffer.append('\n');
/*    */       } 
/*    */     } 
/* 57 */     toStringContent(buffer);
/* 58 */     return buffer.toString();
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\classfmt\ComponentInfoWithAnnotation.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */