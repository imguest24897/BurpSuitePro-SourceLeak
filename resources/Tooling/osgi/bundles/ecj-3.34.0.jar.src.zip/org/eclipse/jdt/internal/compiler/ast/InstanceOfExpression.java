/*     */ package org.eclipse.jdt.internal.compiler.ast;
/*     */ 
/*     */ import org.eclipse.jdt.internal.compiler.ASTVisitor;
/*     */ import org.eclipse.jdt.internal.compiler.codegen.BranchLabel;
/*     */ import org.eclipse.jdt.internal.compiler.codegen.CodeStream;
/*     */ import org.eclipse.jdt.internal.compiler.flow.FlowContext;
/*     */ import org.eclipse.jdt.internal.compiler.flow.FlowInfo;
/*     */ import org.eclipse.jdt.internal.compiler.flow.UnconditionalFlowInfo;
/*     */ import org.eclipse.jdt.internal.compiler.impl.CompilerOptions;
/*     */ import org.eclipse.jdt.internal.compiler.impl.Constant;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.Binding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.BlockScope;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.FieldBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.LocalVariableBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.Scope;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.TypeBinding;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class InstanceOfExpression
/*     */   extends OperatorExpression
/*     */ {
/*     */   public Expression expression;
/*     */   public TypeReference type;
/*     */   public LocalDeclaration elementVariable;
/*     */   public Pattern pattern;
/*  42 */   static final char[] SECRET_INSTANCEOF_PATTERN_EXPRESSION_VALUE = " instanceOfPatternExpressionValue".toCharArray();
/*     */   
/*  44 */   public LocalVariableBinding secretInstanceOfPatternExpressionValue = null;
/*     */   
/*     */   public InstanceOfExpression(Expression expression, TypeReference type) {
/*  47 */     this.expression = expression;
/*  48 */     this.type = type;
/*  49 */     type.bits |= 0x40000000;
/*  50 */     this.bits |= 0x1F00;
/*  51 */     this.sourceStart = expression.sourceStart;
/*  52 */     this.sourceEnd = type.sourceEnd;
/*     */   }
/*     */   public InstanceOfExpression(Expression expression, Pattern pattern) {
/*  55 */     this.expression = expression;
/*  56 */     this.pattern = pattern;
/*  57 */     this.elementVariable = pattern.getPatternVariable();
/*  58 */     this.type = pattern.getType();
/*  59 */     this.type.bits |= 0x40000000;
/*  60 */     this.bits |= 0x1F00;
/*  61 */     this.sourceStart = expression.sourceStart;
/*  62 */     this.sourceEnd = this.pattern.sourceEnd;
/*     */   }
/*     */   public FlowInfo analyseCode(BlockScope currentScope, FlowContext flowContext, FlowInfo flowInfo) {
/*     */     FlowInfo flowInfo1;
/*     */     UnconditionalFlowInfo unconditionalFlowInfo;
/*  67 */     LocalVariableBinding local = this.expression.localVariableBinding();
/*  68 */     FlowInfo initsWhenTrue = null;
/*  69 */     if (local != null && (local.type.tagBits & 0x2L) == 0L) {
/*  70 */       unconditionalFlowInfo = this.expression.analyseCode(currentScope, flowContext, flowInfo)
/*  71 */         .unconditionalInits();
/*  72 */       initsWhenTrue = unconditionalFlowInfo.copy();
/*  73 */       initsWhenTrue.markAsComparedEqualToNonNull(local);
/*  74 */       flowContext.recordUsingNullReference((Scope)currentScope, local, 
/*  75 */           this.expression, 1025, (FlowInfo)unconditionalFlowInfo);
/*     */       
/*  77 */       flowInfo1 = FlowInfo.conditional(initsWhenTrue.copy(), unconditionalFlowInfo.copy());
/*  78 */     } else if (this.expression instanceof Reference && 
/*  79 */       (currentScope.compilerOptions()).enableSyntacticNullAnalysisForFields) {
/*  80 */       FieldBinding field = ((Reference)this.expression).lastFieldBinding();
/*  81 */       if (field != null && (field.type.tagBits & 0x2L) == 0L) {
/*  82 */         flowContext.recordNullCheckedFieldReference((Reference)this.expression, 1);
/*     */       }
/*     */     } 
/*     */     
/*  86 */     if (initsWhenTrue == null) {
/*  87 */       unconditionalFlowInfo = this.expression.analyseCode(currentScope, flowContext, flowInfo1)
/*  88 */         .unconditionalInits();
/*  89 */       if (this.elementVariable != null) {
/*  90 */         initsWhenTrue = unconditionalFlowInfo.copy();
/*     */       }
/*     */     } 
/*  93 */     if (this.elementVariable != null) {
/*  94 */       initsWhenTrue.markAsDefinitelyAssigned(this.elementVariable.binding);
/*  95 */       initsWhenTrue.markAsDefinitelyNonNull(this.elementVariable.binding);
/*     */     } 
/*  97 */     if (this.pattern != null) {
/*  98 */       FlowInfo patternFlow = this.pattern.analyseCode(currentScope, flowContext, (initsWhenTrue == null) ? (FlowInfo)unconditionalFlowInfo : initsWhenTrue);
/*  99 */       initsWhenTrue = (initsWhenTrue == null) ? patternFlow : initsWhenTrue.addInitializationsFrom(patternFlow);
/*     */     } 
/* 101 */     return (initsWhenTrue == null) ? (FlowInfo)unconditionalFlowInfo : 
/* 102 */       FlowInfo.conditional(initsWhenTrue, unconditionalFlowInfo.copy());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void generateCode(BlockScope currentScope, CodeStream codeStream, boolean valueRequired) {
/* 113 */     if (this.elementVariable != null && this.elementVariable.binding != null) {
/* 114 */       this.elementVariable.binding.modifiers &= 0xEFFFFFFF;
/*     */     }
/* 116 */     addPatternVariables(currentScope, codeStream);
/*     */     
/* 118 */     int pc = codeStream.position;
/*     */     
/* 120 */     if (this.elementVariable != null) {
/* 121 */       addAssignment(currentScope, codeStream, this.secretInstanceOfPatternExpressionValue);
/* 122 */       codeStream.load(this.secretInstanceOfPatternExpressionValue);
/*     */     } else {
/* 124 */       this.expression.generateCode(currentScope, codeStream, true);
/*     */     } 
/*     */     
/* 127 */     codeStream.instance_of(this.type, this.type.resolvedType);
/* 128 */     if (this.elementVariable != null) {
/* 129 */       BranchLabel actionLabel = new BranchLabel(codeStream);
/* 130 */       codeStream.dup();
/* 131 */       codeStream.ifeq(actionLabel);
/* 132 */       codeStream.load(this.secretInstanceOfPatternExpressionValue);
/* 133 */       codeStream.removeVariable(this.secretInstanceOfPatternExpressionValue);
/* 134 */       codeStream.checkcast(this.type, this.type.resolvedType, codeStream.position);
/* 135 */       this.elementVariable.binding.recordInitializationStartPC(codeStream.position);
/* 136 */       codeStream.store(this.elementVariable.binding, false);
/* 137 */       codeStream.removeVariable(this.elementVariable.binding);
/* 138 */       codeStream.recordPositionsFrom(codeStream.position, this.sourceEnd);
/* 139 */       actionLabel.place();
/*     */     } 
/* 141 */     if (valueRequired) {
/* 142 */       codeStream.generateImplicitConversion(this.implicitConversion);
/*     */     } else {
/* 144 */       codeStream.pop();
/*     */     } 
/* 146 */     codeStream.recordPositionsFrom(pc, this.sourceStart);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void generateOptimizedBoolean(BlockScope currentScope, CodeStream codeStream, BranchLabel trueLabel, BranchLabel falseLabel, boolean valueRequired) {
/* 153 */     if (this.elementVariable == null && this.pattern == null) {
/* 154 */       super.generateOptimizedBoolean(currentScope, codeStream, trueLabel, falseLabel, valueRequired);
/*     */       return;
/*     */     } 
/* 157 */     Constant cst = optimizedBooleanConstant();
/* 158 */     addPatternVariables(currentScope, codeStream);
/*     */     
/* 160 */     int pc = codeStream.position;
/*     */     
/* 162 */     addAssignment(currentScope, codeStream, this.secretInstanceOfPatternExpressionValue);
/* 163 */     codeStream.load(this.secretInstanceOfPatternExpressionValue);
/*     */     
/* 165 */     BranchLabel nextSibling = (falseLabel != null) ? falseLabel : new BranchLabel(codeStream);
/* 166 */     codeStream.instance_of(this.type, this.type.resolvedType);
/* 167 */     codeStream.ifeq(nextSibling);
/* 168 */     codeStream.load(this.secretInstanceOfPatternExpressionValue);
/* 169 */     if (this.pattern instanceof RecordPattern) {
/* 170 */       this.pattern.generateOptimizedBoolean(currentScope, codeStream, trueLabel, nextSibling);
/* 171 */       codeStream.load(this.secretInstanceOfPatternExpressionValue);
/* 172 */       codeStream.checkcast(this.type, this.type.resolvedType, codeStream.position);
/*     */     } else {
/* 174 */       codeStream.checkcast(this.type, this.type.resolvedType, codeStream.position);
/* 175 */       codeStream.dup();
/* 176 */       codeStream.store(this.elementVariable.binding, false);
/*     */     } 
/*     */     
/* 179 */     codeStream.load(this.secretInstanceOfPatternExpressionValue);
/* 180 */     codeStream.removeVariable(this.secretInstanceOfPatternExpressionValue);
/* 181 */     codeStream.checkcast(this.type, this.type.resolvedType, codeStream.position);
/*     */     
/* 183 */     if (valueRequired && cst == Constant.NotAConstant) {
/* 184 */       codeStream.generateImplicitConversion(this.implicitConversion);
/*     */     } else {
/* 186 */       codeStream.pop();
/*     */     } 
/* 188 */     codeStream.recordPositionsFrom(pc, this.sourceStart);
/*     */ 
/*     */     
/* 191 */     if (cst != Constant.NotAConstant && cst.typeID() == 5) {
/* 192 */       pc = codeStream.position;
/* 193 */       if (cst.booleanValue()) {
/*     */         
/* 195 */         if (valueRequired && 
/* 196 */           falseLabel == null)
/*     */         {
/* 198 */           if (trueLabel != null) {
/* 199 */             codeStream.goto_(trueLabel);
/*     */           
/*     */           }
/*     */         }
/*     */       }
/* 204 */       else if (valueRequired && 
/* 205 */         falseLabel != null) {
/*     */         
/* 207 */         if (trueLabel == null) {
/* 208 */           codeStream.goto_(falseLabel);
/*     */         }
/*     */       } 
/*     */ 
/*     */       
/* 213 */       codeStream.recordPositionsFrom(pc, this.sourceStart);
/*     */     } else {
/*     */       
/* 216 */       int position = codeStream.position;
/* 217 */       if (valueRequired) {
/* 218 */         if (falseLabel == null) {
/* 219 */           if (trueLabel != null)
/*     */           {
/* 221 */             codeStream.pop2();
/* 222 */             codeStream.goto_(trueLabel);
/*     */           }
/*     */         
/* 225 */         } else if (trueLabel == null) {
/*     */           
/* 227 */           codeStream.pop2();
/*     */         } 
/*     */       }
/*     */ 
/*     */ 
/*     */       
/* 233 */       codeStream.recordPositionsFrom(position, this.sourceEnd);
/*     */     } 
/* 235 */     if (nextSibling != falseLabel)
/* 236 */       nextSibling.place(); 
/*     */   }
/*     */   
/*     */   private void addAssignment(BlockScope currentScope, CodeStream codeStream, LocalVariableBinding local) {
/* 240 */     assert local != null;
/* 241 */     SingleNameReference lhs = new SingleNameReference(local.name, 0L);
/* 242 */     lhs.binding = (Binding)local;
/* 243 */     lhs.bits &= 0xFFFFFFF8;
/* 244 */     lhs.bits |= 0x2;
/* 245 */     lhs.bits |= 0x10;
/* 246 */     ((LocalVariableBinding)lhs.binding).markReferenced();
/* 247 */     Assignment assignment = new Assignment(lhs, this.expression, 0);
/* 248 */     assignment.generateCode(currentScope, codeStream);
/* 249 */     codeStream.addVariable(this.secretInstanceOfPatternExpressionValue);
/*     */   }
/*     */ 
/*     */   
/*     */   public StringBuffer printExpressionNoParenthesis(int indent, StringBuffer output) {
/* 254 */     this.expression.printExpression(indent, output).append(" instanceof ");
/* 255 */     return (this.pattern == null) ? this.type.print(0, output) : this.pattern.printExpression(0, output);
/*     */   }
/*     */ 
/*     */   
/*     */   public void addPatternVariables(BlockScope currentScope, CodeStream codeStream) {
/* 260 */     if (this.elementVariable != null)
/* 261 */       codeStream.addVisibleLocalVariable(this.elementVariable.binding); 
/*     */   }
/*     */   
/*     */   public boolean resolvePatternVariable(BlockScope scope) {
/* 265 */     if (this.pattern != null) {
/* 266 */       this.pattern.resolve(scope);
/* 267 */       if (this.elementVariable == null) return false; 
/* 268 */       if (this.elementVariable.binding == null) {
/* 269 */         this.elementVariable.modifiers |= 0x10000000;
/* 270 */         this.elementVariable.resolve(scope, true);
/*     */ 
/*     */         
/* 273 */         this.elementVariable.modifiers &= 0xFBFFFFFF;
/* 274 */         this.elementVariable.binding.modifiers |= 0x10000000;
/* 275 */         this.elementVariable.binding.useFlag = 1;
/*     */         
/* 277 */         this.type = this.elementVariable.type;
/*     */       } 
/*     */     } 
/* 280 */     return true;
/*     */   }
/*     */   
/*     */   public void collectPatternVariablesToScope(LocalVariableBinding[] variables, BlockScope scope) {
/* 284 */     this.expression.collectPatternVariablesToScope(variables, scope);
/* 285 */     if (this.pattern != null) {
/* 286 */       this.pattern.collectPatternVariablesToScope(variables, scope);
/* 287 */       addPatternVariablesWhenTrue(this.pattern.patternVarsWhenTrue);
/*     */     } 
/*     */   }
/*     */   
/*     */   public boolean containsPatternVariable() {
/* 292 */     return !(this.elementVariable == null && this.pattern == null);
/*     */   }
/*     */   
/*     */   public LocalDeclaration getPatternVariable() {
/* 296 */     return this.elementVariable;
/*     */   }
/*     */   private void addSecretInstanceOfPatternExpressionValue(BlockScope scope1) {
/* 299 */     LocalVariableBinding local = 
/* 300 */       new LocalVariableBinding(
/* 301 */         SECRET_INSTANCEOF_PATTERN_EXPRESSION_VALUE, 
/* 302 */         TypeBinding.wellKnownType((Scope)scope1, 1), 
/* 303 */         0, 
/* 304 */         false);
/* 305 */     local.setConstant(Constant.NotAConstant);
/* 306 */     local.useFlag = 1;
/* 307 */     scope1.addLocalVariable(local);
/* 308 */     this.secretInstanceOfPatternExpressionValue = local;
/*     */   }
/*     */ 
/*     */   
/*     */   public TypeBinding resolveType(BlockScope scope) {
/* 313 */     this.constant = Constant.NotAConstant;
/* 314 */     if (this.elementVariable != null || this.pattern != null)
/* 315 */       addSecretInstanceOfPatternExpressionValue(scope); 
/* 316 */     resolvePatternVariable(scope);
/* 317 */     TypeBinding checkedType = this.type.resolveType(scope, true);
/* 318 */     if (this.expression instanceof CastExpression) {
/* 319 */       ((CastExpression)this.expression).setInstanceofType(checkedType);
/*     */     }
/* 321 */     TypeBinding expressionType = this.expression.resolveType(scope);
/* 322 */     if (this.pattern != null) {
/* 323 */       this.pattern.resolveWithExpression(scope, this.expression);
/*     */     }
/* 325 */     if (expressionType != null && checkedType != null && this.type.hasNullTypeAnnotation(TypeReference.AnnotationPosition.ANY))
/*     */     {
/* 327 */       if (!expressionType.isCompatibleWith(checkedType) || NullAnnotationMatching.analyse(checkedType, expressionType, -1).isAnyMismatch())
/* 328 */         scope.problemReporter().nullAnnotationUnsupportedLocation(this.type); 
/*     */     }
/* 330 */     if (expressionType == null || checkedType == null) {
/* 331 */       return null;
/*     */     }
/* 333 */     if (this.secretInstanceOfPatternExpressionValue != null && expressionType != TypeBinding.NULL) {
/* 334 */       this.secretInstanceOfPatternExpressionValue.type = expressionType;
/*     */     }
/* 336 */     if (!checkedType.isReifiable()) {
/* 337 */       CompilerOptions options = scope.compilerOptions();
/*     */       
/* 339 */       if (options.complianceLevel < 3932160L) {
/* 340 */         scope.problemReporter().illegalInstanceOfGenericType(checkedType, this);
/*     */       }
/* 342 */       else if (expressionType != TypeBinding.NULL) {
/* 343 */         boolean isLegal = checkCastTypesCompatibility((Scope)scope, checkedType, expressionType, this.expression, true);
/* 344 */         if (!isLegal || (this.bits & 0x80) != 0) {
/* 345 */           scope.problemReporter().unsafeCastInInstanceof(this.expression, checkedType, expressionType);
/*     */         }
/*     */       }
/*     */     
/* 349 */     } else if (checkedType.isValidBinding()) {
/*     */       
/* 351 */       if ((expressionType != TypeBinding.NULL && expressionType.isBaseType()) || 
/* 352 */         checkedType.isBaseType() || 
/* 353 */         !checkCastTypesCompatibility((Scope)scope, checkedType, expressionType, (Expression)null, true)) {
/* 354 */         scope.problemReporter().notCompatibleTypesError(this, expressionType, checkedType);
/*     */       }
/*     */     } 
/* 357 */     return this.resolvedType = (TypeBinding)TypeBinding.BOOLEAN;
/*     */   }
/*     */   
/*     */   public boolean checkUnsafeCast(Scope scope, TypeBinding castType, TypeBinding expressionType, TypeBinding match, boolean isNarrowing) {
/* 361 */     if (!castType.isReifiable()) {
/* 362 */       return CastExpression.checkUnsafeCast(this, scope, castType, expressionType, match, isNarrowing);
/*     */     }
/* 364 */     return super.checkUnsafeCast(scope, castType, expressionType, match, isNarrowing);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void tagAsUnnecessaryCast(Scope scope, TypeBinding castType) {
/* 373 */     if (this.expression.resolvedType != TypeBinding.NULL) {
/* 374 */       scope.problemReporter().unnecessaryInstanceof(this, castType);
/*     */     }
/*     */   }
/*     */   
/*     */   public void traverse(ASTVisitor visitor, BlockScope scope) {
/* 379 */     if (visitor.visit(this, scope)) {
/* 380 */       this.expression.traverse(visitor, scope);
/* 381 */       if (this.pattern != null) {
/* 382 */         this.pattern.traverse(visitor, scope);
/*     */       } else {
/* 384 */         this.type.traverse(visitor, scope);
/*     */       } 
/*     */     } 
/* 387 */     visitor.endVisit(this, scope);
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\ast\InstanceOfExpression.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */