/*     */ package org.eclipse.jdt.internal.compiler.apt.model;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import javax.lang.model.element.Element;
/*     */ import javax.lang.model.element.ElementKind;
/*     */ import javax.lang.model.type.DeclaredType;
/*     */ import javax.lang.model.type.TypeKind;
/*     */ import javax.lang.model.type.TypeMirror;
/*     */ import javax.lang.model.type.TypeVisitor;
/*     */ import org.eclipse.jdt.internal.compiler.apt.dispatch.BaseProcessingEnvImpl;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.Binding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.ParameterizedTypeBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.ReferenceBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.TypeBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.TypeVariableBinding;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DeclaredTypeImpl
/*     */   extends TypeMirrorImpl
/*     */   implements DeclaredType
/*     */ {
/*     */   private final ElementKind _elementKindHint;
/*     */   
/*     */   DeclaredTypeImpl(BaseProcessingEnvImpl env, ReferenceBinding binding) {
/*  45 */     super(env, (Binding)binding);
/*  46 */     this._elementKindHint = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   DeclaredTypeImpl(BaseProcessingEnvImpl env, ReferenceBinding binding, ElementKind elementKindHint) {
/*  55 */     super(env, (Binding)binding);
/*  56 */     this._elementKindHint = elementKindHint;
/*     */   }
/*     */ 
/*     */   
/*     */   public Element asElement() {
/*  61 */     TypeBinding prototype = null;
/*  62 */     if (this._binding instanceof TypeBinding) {
/*  63 */       prototype = ((TypeBinding)this._binding).prototype();
/*     */     }
/*  65 */     if (prototype != null) {
/*  66 */       return this._env.getFactory().newElement((Binding)prototype, this._elementKindHint);
/*     */     }
/*     */     
/*  69 */     return this._env.getFactory().newElement(this._binding, this._elementKindHint);
/*     */   }
/*     */ 
/*     */   
/*     */   public TypeMirror getEnclosingType() {
/*  74 */     ReferenceBinding binding = (ReferenceBinding)this._binding;
/*  75 */     ReferenceBinding enclosingType = binding.enclosingType();
/*  76 */     if (enclosingType != null) {
/*  77 */       return this._env.getFactory().newTypeMirror((Binding)enclosingType);
/*     */     }
/*  79 */     return this._env.getFactory().getNoType(TypeKind.NONE);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<? extends TypeMirror> getTypeArguments() {
/*  89 */     ReferenceBinding binding = (ReferenceBinding)this._binding;
/*  90 */     if (binding.isParameterizedType()) {
/*  91 */       ParameterizedTypeBinding ptb = (ParameterizedTypeBinding)this._binding;
/*  92 */       TypeBinding[] arguments = ptb.arguments;
/*  93 */       int length = (arguments == null) ? 0 : arguments.length;
/*  94 */       if (length == 0) return Collections.emptyList(); 
/*  95 */       List<TypeMirror> args = new ArrayList<>(length); byte b; int i; TypeBinding[] arrayOfTypeBinding1;
/*  96 */       for (i = (arrayOfTypeBinding1 = arguments).length, b = 0; b < i; ) { TypeBinding arg = arrayOfTypeBinding1[b];
/*  97 */         args.add(this._env.getFactory().newTypeMirror((Binding)arg)); b++; }
/*     */       
/*  99 */       return Collections.unmodifiableList(args);
/*     */     } 
/* 101 */     if (binding.isGenericType()) {
/* 102 */       TypeVariableBinding[] typeVariables = binding.typeVariables();
/* 103 */       List<TypeMirror> args = new ArrayList<>(typeVariables.length); byte b; int i; TypeVariableBinding[] arrayOfTypeVariableBinding1;
/* 104 */       for (i = (arrayOfTypeVariableBinding1 = typeVariables).length, b = 0; b < i; ) { TypeVariableBinding typeVariableBinding = arrayOfTypeVariableBinding1[b];
/* 105 */         args.add(this._env.getFactory().newTypeMirror((Binding)typeVariableBinding)); b++; }
/*     */       
/* 107 */       return Collections.unmodifiableList(args);
/*     */     } 
/* 109 */     return Collections.emptyList();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <R, P> R accept(TypeVisitor<R, P> v, P p) {
/* 117 */     return v.visitDeclared(this, p);
/*     */   }
/*     */ 
/*     */   
/*     */   public TypeKind getKind() {
/* 122 */     return TypeKind.DECLARED;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 127 */     return new String(this._binding.readableName());
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\apt\model\DeclaredTypeImpl.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */