/*     */ package org.eclipse.jdt.internal.compiler.classfmt;
/*     */ 
/*     */ import org.eclipse.jdt.core.compiler.CharOperation;
/*     */ import org.eclipse.jdt.internal.compiler.codegen.AttributeNamesConstants;
/*     */ import org.eclipse.jdt.internal.compiler.env.IBinaryAnnotation;
/*     */ import org.eclipse.jdt.internal.compiler.env.IBinaryTypeAnnotation;
/*     */ import org.eclipse.jdt.internal.compiler.env.IRecordComponent;
/*     */ import org.eclipse.jdt.internal.compiler.impl.Constant;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RecordComponentInfo
/*     */   extends ClassFileStruct
/*     */   implements IRecordComponent, Comparable
/*     */ {
/*     */   protected int attributeBytes;
/*     */   protected char[] descriptor;
/*     */   protected char[] name;
/*     */   protected char[] signature;
/*     */   protected int signatureUtf8Offset;
/*     */   protected long tagBits;
/*     */   protected long version;
/*     */   
/*     */   public static RecordComponentInfo createComponent(byte[] classFileBytes, int[] offsets, int offset, long version) {
/*  40 */     RecordComponentInfo componentInfo = new RecordComponentInfo(classFileBytes, offsets, offset, version);
/*     */     
/*  42 */     int attributesCount = componentInfo.u2At(4);
/*  43 */     int readOffset = 6;
/*  44 */     AnnotationInfo[] annotations = null;
/*  45 */     TypeAnnotationInfo[] typeAnnotations = null;
/*  46 */     for (int i = 0; i < attributesCount; i++) {
/*     */       
/*  48 */       int utf8Offset = componentInfo.constantPoolOffsets[componentInfo.u2At(readOffset)] - componentInfo.structOffset;
/*  49 */       char[] attributeName = componentInfo.utf8At(utf8Offset + 3, componentInfo.u2At(utf8Offset + 1));
/*  50 */       if (attributeName.length > 0) {
/*  51 */         AnnotationInfo[] decodedAnnotations; TypeAnnotationInfo[] decodedTypeAnnotations; switch (attributeName[0]) {
/*     */           case 'S':
/*  53 */             if (CharOperation.equals(AttributeNamesConstants.SignatureName, attributeName))
/*  54 */               componentInfo.signatureUtf8Offset = componentInfo.constantPoolOffsets[componentInfo.u2At(readOffset + 6)] - componentInfo.structOffset; 
/*     */             break;
/*     */           case 'R':
/*  57 */             decodedAnnotations = null;
/*  58 */             decodedTypeAnnotations = null;
/*  59 */             if (CharOperation.equals(attributeName, AttributeNamesConstants.RuntimeVisibleAnnotationsName)) {
/*  60 */               decodedAnnotations = componentInfo.decodeAnnotations(readOffset, true);
/*  61 */             } else if (CharOperation.equals(attributeName, AttributeNamesConstants.RuntimeInvisibleAnnotationsName)) {
/*  62 */               decodedAnnotations = componentInfo.decodeAnnotations(readOffset, false);
/*  63 */             } else if (CharOperation.equals(attributeName, AttributeNamesConstants.RuntimeVisibleTypeAnnotationsName)) {
/*  64 */               decodedTypeAnnotations = componentInfo.decodeTypeAnnotations(readOffset, true);
/*  65 */             } else if (CharOperation.equals(attributeName, AttributeNamesConstants.RuntimeInvisibleTypeAnnotationsName)) {
/*  66 */               decodedTypeAnnotations = componentInfo.decodeTypeAnnotations(readOffset, false);
/*     */             } 
/*  68 */             if (decodedAnnotations != null) {
/*  69 */               if (annotations == null) {
/*  70 */                 annotations = decodedAnnotations; break;
/*     */               } 
/*  72 */               int length = annotations.length;
/*  73 */               AnnotationInfo[] combined = new AnnotationInfo[length + decodedAnnotations.length];
/*  74 */               System.arraycopy(annotations, 0, combined, 0, length);
/*  75 */               System.arraycopy(decodedAnnotations, 0, combined, length, decodedAnnotations.length);
/*  76 */               annotations = combined; break;
/*     */             } 
/*  78 */             if (decodedTypeAnnotations != null) {
/*  79 */               if (typeAnnotations == null) {
/*  80 */                 typeAnnotations = decodedTypeAnnotations; break;
/*     */               } 
/*  82 */               int length = typeAnnotations.length;
/*  83 */               TypeAnnotationInfo[] combined = new TypeAnnotationInfo[length + decodedTypeAnnotations.length];
/*  84 */               System.arraycopy(typeAnnotations, 0, combined, 0, length);
/*  85 */               System.arraycopy(decodedTypeAnnotations, 0, combined, length, decodedTypeAnnotations.length);
/*  86 */               typeAnnotations = combined;
/*     */             } 
/*     */             break;
/*     */         } 
/*     */       } 
/*  91 */       readOffset = (int)(readOffset + 6L + componentInfo.u4At(readOffset + 2));
/*     */     } 
/*  93 */     componentInfo.attributeBytes = readOffset;
/*     */     
/*  95 */     if (typeAnnotations != null)
/*  96 */       return new ComponentInfoWithTypeAnnotation(componentInfo, annotations, typeAnnotations); 
/*  97 */     if (annotations != null)
/*  98 */       return new ComponentInfoWithAnnotation(componentInfo, annotations); 
/*  99 */     return componentInfo;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected RecordComponentInfo(byte[] classFileBytes, int[] offsets, int offset, long version) {
/* 109 */     super(classFileBytes, offsets, offset);
/* 110 */     this.signatureUtf8Offset = -1;
/* 111 */     this.version = version;
/*     */   }
/*     */   private AnnotationInfo[] decodeAnnotations(int offset, boolean runtimeVisible) {
/* 114 */     int numberOfAnnotations = u2At(offset + 6);
/* 115 */     if (numberOfAnnotations > 0) {
/* 116 */       int readOffset = offset + 8;
/* 117 */       AnnotationInfo[] newInfos = null;
/* 118 */       int newInfoCount = 0;
/* 119 */       for (int i = 0; i < numberOfAnnotations; i++) {
/*     */         
/* 121 */         AnnotationInfo newInfo = new AnnotationInfo(this.reference, this.constantPoolOffsets, 
/* 122 */             readOffset + this.structOffset, runtimeVisible, false);
/* 123 */         readOffset += newInfo.readOffset;
/* 124 */         long standardTagBits = newInfo.standardAnnotationTagBits;
/* 125 */         if (standardTagBits != 0L) {
/* 126 */           this.tagBits |= standardTagBits;
/* 127 */           if (this.version < 3473408L || (standardTagBits & 0x400000000000L) == 0L)
/*     */             continue; 
/*     */         } 
/* 130 */         if (newInfos == null)
/* 131 */           newInfos = new AnnotationInfo[numberOfAnnotations - i]; 
/* 132 */         newInfos[newInfoCount++] = newInfo; continue;
/*     */       } 
/* 134 */       if (newInfos != null) {
/* 135 */         if (newInfoCount != newInfos.length)
/* 136 */           System.arraycopy(newInfos, 0, newInfos = new AnnotationInfo[newInfoCount], 0, newInfoCount); 
/* 137 */         return newInfos;
/*     */       } 
/*     */     } 
/* 140 */     return null;
/*     */   }
/*     */   
/*     */   TypeAnnotationInfo[] decodeTypeAnnotations(int offset, boolean runtimeVisible) {
/* 144 */     int numberOfAnnotations = u2At(offset + 6);
/* 145 */     if (numberOfAnnotations > 0) {
/* 146 */       int readOffset = offset + 8;
/* 147 */       TypeAnnotationInfo[] typeAnnos = new TypeAnnotationInfo[numberOfAnnotations];
/* 148 */       for (int i = 0; i < numberOfAnnotations; i++) {
/* 149 */         TypeAnnotationInfo newInfo = new TypeAnnotationInfo(this.reference, this.constantPoolOffsets, readOffset + this.structOffset, runtimeVisible, false);
/* 150 */         readOffset += newInfo.readOffset;
/* 151 */         typeAnnos[i] = newInfo;
/*     */       } 
/* 153 */       return typeAnnos;
/*     */     } 
/* 155 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public int compareTo(Object o) {
/* 160 */     return (new String(getName())).compareTo(new String(((RecordComponentInfo)o).getName()));
/*     */   }
/*     */   
/*     */   public boolean equals(Object o) {
/* 164 */     if (!(o instanceof RecordComponentInfo)) {
/* 165 */       return false;
/*     */     }
/* 167 */     return CharOperation.equals(getName(), ((RecordComponentInfo)o).getName());
/*     */   }
/*     */   
/*     */   public int hashCode() {
/* 171 */     return CharOperation.hashCode(getName());
/*     */   }
/*     */   
/*     */   public char[] getGenericSignature() {
/* 175 */     if (this.signatureUtf8Offset != -1) {
/* 176 */       if (this.signature == null)
/*     */       {
/* 178 */         this.signature = utf8At(this.signatureUtf8Offset + 3, u2At(this.signatureUtf8Offset + 1));
/*     */       }
/* 180 */       return this.signature;
/*     */     } 
/* 182 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public char[] getName() {
/* 190 */     if (this.name == null) {
/*     */       
/* 192 */       int utf8Offset = this.constantPoolOffsets[u2At(0)] - this.structOffset;
/* 193 */       this.name = utf8At(utf8Offset + 3, u2At(utf8Offset + 1));
/*     */     } 
/* 195 */     return this.name;
/*     */   }
/*     */   
/*     */   public long getTagBits() {
/* 199 */     return this.tagBits;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public char[] getTypeName() {
/* 214 */     if (this.descriptor == null) {
/*     */       
/* 216 */       int utf8Offset = this.constantPoolOffsets[u2At(2)] - this.structOffset;
/* 217 */       this.descriptor = utf8At(utf8Offset + 3, u2At(utf8Offset + 1));
/*     */     } 
/* 219 */     return this.descriptor;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IBinaryAnnotation[] getAnnotations() {
/* 226 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public IBinaryTypeAnnotation[] getTypeAnnotations() {
/* 231 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void initialize() {
/* 238 */     getName();
/* 239 */     getTypeName();
/* 240 */     getGenericSignature();
/* 241 */     reset();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int sizeInBytes() {
/* 249 */     return this.attributeBytes;
/*     */   }
/*     */   public void throwFormatException() throws ClassFormatException {
/* 252 */     throw new ClassFormatException(29);
/*     */   }
/*     */   
/*     */   public String toString() {
/* 256 */     StringBuffer buffer = new StringBuffer(getClass().getName());
/* 257 */     toStringContent(buffer);
/* 258 */     return buffer.toString();
/*     */   }
/*     */   protected void toStringContent(StringBuffer buffer) {
/* 261 */     buffer
/* 262 */       .append('{')
/* 263 */       .append(getTypeName())
/* 264 */       .append(' ')
/* 265 */       .append(getName())
/* 266 */       .append(' ')
/* 267 */       .append('}')
/* 268 */       .toString();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Constant getConstant() {
/* 274 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int getModifiers() {
/* 280 */     return 0;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\classfmt\RecordComponentInfo.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */