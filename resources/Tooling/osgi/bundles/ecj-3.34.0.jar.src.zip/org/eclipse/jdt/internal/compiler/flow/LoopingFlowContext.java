/*     */ package org.eclipse.jdt.internal.compiler.flow;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import org.eclipse.jdt.internal.compiler.ast.ASTNode;
/*     */ import org.eclipse.jdt.internal.compiler.ast.Expression;
/*     */ import org.eclipse.jdt.internal.compiler.ast.FakedTrackingVariable;
/*     */ import org.eclipse.jdt.internal.compiler.ast.NullAnnotationMatching;
/*     */ import org.eclipse.jdt.internal.compiler.ast.Reference;
/*     */ import org.eclipse.jdt.internal.compiler.codegen.BranchLabel;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.BlockScope;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.FieldBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.LocalVariableBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.ReferenceBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.Scope;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.TypeBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.VariableBinding;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LoopingFlowContext
/*     */   extends SwitchFlowContext
/*     */ {
/*     */   public BranchLabel continueLabel;
/*  61 */   public UnconditionalFlowInfo initsOnContinue = FlowInfo.DEAD_END;
/*     */   private UnconditionalFlowInfo upstreamNullFlowInfo;
/*  63 */   private LoopingFlowContext[] innerFlowContexts = null;
/*  64 */   private UnconditionalFlowInfo[] innerFlowInfos = null;
/*  65 */   private int innerFlowContextsCount = 0;
/*  66 */   private LabelFlowContext[] breakTargetContexts = null;
/*  67 */   private int breakTargetsCount = 0;
/*     */   
/*     */   Reference[] finalAssignments;
/*     */   VariableBinding[] finalVariables;
/*  71 */   int assignCount = 0;
/*     */   
/*     */   LocalVariableBinding[] nullLocals;
/*     */   
/*     */   ASTNode[] nullReferences;
/*     */   
/*     */   int[] nullCheckTypes;
/*     */   UnconditionalFlowInfo[] nullInfos;
/*     */   NullAnnotationMatching[] nullAnnotationStatuses;
/*     */   int nullCount;
/*     */   
/*     */   private static class EscapingExceptionCatchSite
/*     */   {
/*     */     final ReferenceBinding caughtException;
/*     */     final ExceptionHandlingFlowContext catchingContext;
/*     */     final FlowInfo exceptionInfo;
/*     */     
/*     */     public EscapingExceptionCatchSite(ExceptionHandlingFlowContext catchingContext, ReferenceBinding caughtException, FlowInfo exceptionInfo) {
/*  89 */       this.catchingContext = catchingContext;
/*  90 */       this.caughtException = caughtException;
/*  91 */       this.exceptionInfo = exceptionInfo;
/*     */     }
/*     */     void simulateThrowAfterLoopBack(FlowInfo flowInfo) {
/*  94 */       this.catchingContext.recordHandlingException(this.caughtException, 
/*  95 */           flowInfo.unconditionalCopy().addNullInfoFrom(this.exceptionInfo).unconditionalInits(), 
/*  96 */           null, 
/*  97 */           null, null, true);
/*     */     }
/*     */   }
/*     */   
/* 101 */   private ArrayList escapingExceptionCatchSites = null;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Scope associatedScope;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LoopingFlowContext(FlowContext parent, FlowInfo upstreamNullFlowInfo, ASTNode associatedNode, BranchLabel breakLabel, BranchLabel continueLabel, Scope associatedScope, boolean isPreTest) {
/* 113 */     super(parent, associatedNode, breakLabel, isPreTest, false);
/* 114 */     this.tagBits |= 0x2;
/*     */     
/* 116 */     this.continueLabel = continueLabel;
/* 117 */     this.associatedScope = associatedScope;
/* 118 */     this.upstreamNullFlowInfo = upstreamNullFlowInfo.unconditionalCopy();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void complainOnDeferredFinalChecks(BlockScope scope, FlowInfo flowInfo) {
/* 129 */     for (int i = 0; i < this.assignCount; i++) {
/* 130 */       VariableBinding variable = this.finalVariables[i];
/* 131 */       if (variable != null) {
/* 132 */         boolean complained = false;
/* 133 */         if (variable instanceof FieldBinding) {
/* 134 */           if (flowInfo.isPotentiallyAssigned((FieldBinding)variable)) {
/* 135 */             complained = true;
/* 136 */             scope.problemReporter().duplicateInitializationOfBlankFinalField(
/* 137 */                 (FieldBinding)variable, 
/* 138 */                 this.finalAssignments[i]);
/*     */           }
/*     */         
/* 141 */         } else if (flowInfo.isPotentiallyAssigned((LocalVariableBinding)variable)) {
/* 142 */           variable.tagBits &= 0xFFFFFFFFFFFFF7FFL;
/* 143 */           if (variable.isFinal()) {
/* 144 */             complained = true;
/* 145 */             scope.problemReporter().duplicateInitializationOfFinalLocal(
/* 146 */                 (LocalVariableBinding)variable, 
/* 147 */                 (ASTNode)this.finalAssignments[i]);
/*     */           } 
/*     */         } 
/*     */ 
/*     */ 
/*     */         
/* 153 */         if (complained) {
/* 154 */           FlowContext context = getLocalParent();
/* 155 */           while (context != null) {
/* 156 */             context.removeFinalAssignmentIfAny(this.finalAssignments[i]);
/* 157 */             context = context.getLocalParent();
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void complainOnDeferredNullChecks(BlockScope scope, FlowInfo callerFlowInfo) {
/* 169 */     complainOnDeferredNullChecks(scope, callerFlowInfo, true);
/*     */   }
/*     */   public void complainOnDeferredNullChecks(BlockScope scope, FlowInfo callerFlowInfo, boolean updateInitsOnBreak) {
/* 172 */     for (int i = 0; i < this.innerFlowContextsCount; i++) {
/* 173 */       this.upstreamNullFlowInfo
/* 174 */         .addPotentialNullInfoFrom(
/* 175 */           (this.innerFlowContexts[i]).upstreamNullFlowInfo)
/* 176 */         .addPotentialNullInfoFrom(this.innerFlowInfos[i]);
/*     */     }
/* 178 */     this.innerFlowContextsCount = 0;
/* 179 */     FlowInfo upstreamCopy = this.upstreamNullFlowInfo.copy();
/* 180 */     UnconditionalFlowInfo incomingInfo = this.upstreamNullFlowInfo
/* 181 */       .addPotentialNullInfoFrom(callerFlowInfo.unconditionalInitsWithoutSideEffect());
/* 182 */     if ((this.tagBits & 0x1) != 0) {
/*     */       
/* 184 */       for (int j = 0; j < this.nullCount; j++) {
/* 185 */         Expression expression; int nullStatus; FakedTrackingVariable trackingVar; LocalVariableBinding local = this.nullLocals[j];
/* 186 */         ASTNode location = this.nullReferences[j];
/* 187 */         FlowInfo flowInfo = (this.nullInfos[j] != null) ? 
/* 188 */           incomingInfo.copy().addNullInfoFrom(this.nullInfos[j]) : 
/* 189 */           incomingInfo;
/*     */         
/* 191 */         switch (this.nullCheckTypes[j] & 0xFFFF0FFF) {
/*     */           case 258:
/*     */           case 514:
/* 194 */             if (flowInfo.isDefinitelyNonNull(local)) {
/* 195 */               this.nullReferences[j] = null;
/* 196 */               if ((this.nullCheckTypes[j] & 0xFFFF0FFF) == 514) {
/* 197 */                 if ((this.nullCheckTypes[j] & 0x1000) == 0)
/* 198 */                   scope.problemReporter().localVariableRedundantCheckOnNonNull(local, location); 
/*     */                 break;
/*     */               } 
/* 201 */               scope.problemReporter().localVariableNonNullComparedToNull(local, location);
/*     */               break;
/*     */             } 
/*     */ 
/*     */           
/*     */           case 256:
/*     */           case 512:
/* 208 */             if (flowInfo.isDefinitelyNonNull(local)) {
/* 209 */               this.nullReferences[j] = null;
/* 210 */               if ((this.nullCheckTypes[j] & 0xFFFF0FFF) == 512) {
/* 211 */                 if ((this.nullCheckTypes[j] & 0x1000) == 0)
/* 212 */                   scope.problemReporter().localVariableRedundantCheckOnNonNull(local, location); 
/*     */                 break;
/*     */               } 
/* 215 */               scope.problemReporter().localVariableNonNullComparedToNull(local, location);
/*     */               
/*     */               break;
/*     */             } 
/* 219 */             if (flowInfo.isDefinitelyNull(local)) {
/* 220 */               this.nullReferences[j] = null;
/* 221 */               if ((this.nullCheckTypes[j] & 0xFFFF0FFF) == 256) {
/* 222 */                 if ((this.nullCheckTypes[j] & 0x1000) == 0)
/* 223 */                   scope.problemReporter().localVariableRedundantCheckOnNull(local, location); 
/*     */                 break;
/*     */               } 
/* 226 */               scope.problemReporter().localVariableNullComparedToNonNull(local, location);
/*     */               break;
/*     */             } 
/*     */ 
/*     */           
/*     */           case 257:
/*     */           case 513:
/*     */           case 769:
/*     */           case 1025:
/* 235 */             expression = (Expression)location;
/* 236 */             if (flowInfo.isDefinitelyNull(local)) {
/* 237 */               this.nullReferences[j] = null;
/* 238 */               switch (this.nullCheckTypes[j] & 0xFFFF0F00) {
/*     */                 case 256:
/* 240 */                   if ((this.nullCheckTypes[j] & 0xFF & 0xFFFF0FFF) == 1 && (expression.implicitConversion & 0x400) != 0) {
/* 241 */                     scope.problemReporter().localVariableNullReference(local, (ASTNode)expression);
/*     */                     break;
/*     */                   } 
/* 244 */                   if ((this.nullCheckTypes[j] & 0x1000) == 0) {
/* 245 */                     scope.problemReporter().localVariableRedundantCheckOnNull(local, (ASTNode)expression);
/*     */                   }
/*     */                   break;
/*     */                 case 512:
/* 249 */                   if ((this.nullCheckTypes[j] & 0xFF & 0xFFFF0FFF) == 1 && (expression.implicitConversion & 0x400) != 0) {
/* 250 */                     scope.problemReporter().localVariableNullReference(local, (ASTNode)expression);
/*     */                     break;
/*     */                   } 
/* 253 */                   scope.problemReporter().localVariableNullComparedToNonNull(local, (ASTNode)expression);
/*     */                   break;
/*     */                 case 768:
/* 256 */                   scope.problemReporter().localVariableRedundantNullAssignment(local, (ASTNode)expression);
/*     */                   break;
/*     */                 case 1024:
/* 259 */                   scope.problemReporter().localVariableNullInstanceof(local, (ASTNode)expression);
/*     */                   break;
/*     */               } 
/* 262 */             } else if (flowInfo.isPotentiallyNull(local)) {
/* 263 */               switch (this.nullCheckTypes[j] & 0xFFFF0F00) {
/*     */                 case 256:
/* 265 */                   this.nullReferences[j] = null;
/* 266 */                   if ((this.nullCheckTypes[j] & 0xFF & 0xFFFF0FFF) == 1 && (expression.implicitConversion & 0x400) != 0) {
/* 267 */                     scope.problemReporter().localVariablePotentialNullReference(local, (ASTNode)expression);
/*     */                   }
/*     */                   break;
/*     */                 
/*     */                 case 512:
/* 272 */                   this.nullReferences[j] = null;
/* 273 */                   if ((this.nullCheckTypes[j] & 0xFF & 0xFFFF0FFF) == 1 && (expression.implicitConversion & 0x400) != 0) {
/* 274 */                     scope.problemReporter().localVariablePotentialNullReference(local, (ASTNode)expression);
/*     */                   }
/*     */                   break;
/*     */               } 
/*     */             
/*     */             } 
/*     */           
/*     */           case 3:
/* 282 */             if (flowInfo.isDefinitelyNull(local)) {
/* 283 */               this.nullReferences[j] = null;
/* 284 */               scope.problemReporter().localVariableNullReference(local, location);
/*     */               break;
/*     */             } 
/*     */           
/*     */           case 128:
/* 289 */             nullStatus = flowInfo.nullStatus(local);
/* 290 */             if (nullStatus != 4) {
/* 291 */               this.parent.recordNullityMismatch(scope, (Expression)location, this.providedExpectedTypes[j][0], this.providedExpectedTypes[j][1], flowInfo, nullStatus, null);
/*     */             }
/*     */             break;
/*     */           case 2048:
/* 295 */             trackingVar = local.closeTracker;
/* 296 */             if (trackingVar != null) {
/* 297 */               if (trackingVar.hasDefinitelyNoResource(flowInfo)) {
/*     */                 break;
/*     */               }
/* 300 */               if (trackingVar.isClosedInFinallyOfEnclosing(scope)) {
/*     */                 break;
/*     */               }
/* 303 */               if (this.parent.recordExitAgainstResource(scope, flowInfo, trackingVar, location)) {
/* 304 */                 this.nullReferences[j] = null;
/*     */                 break;
/*     */               } 
/*     */             } 
/*     */           
/*     */           case 16:
/* 310 */             checkUnboxing((Scope)scope, (Expression)location, flowInfo);
/*     */             break;
/*     */ 
/*     */ 
/*     */ 
/*     */           
/*     */           default:
/* 317 */             if (this.nullCheckTypes[j] != 3 || !upstreamCopy.isDefinitelyNonNull(local)) {
/* 318 */               this.parent.recordUsingNullReference((Scope)scope, local, location, 
/* 319 */                   this.nullCheckTypes[j], flowInfo);
/*     */             }
/*     */             break;
/*     */         } 
/*     */       } 
/*     */     } else {
/* 325 */       for (int j = 0; j < this.nullCount; j++) {
/* 326 */         Expression expression; int nullStatus; ASTNode location = this.nullReferences[j];
/*     */         
/* 328 */         LocalVariableBinding local = this.nullLocals[j];
/* 329 */         FlowInfo flowInfo = (this.nullInfos[j] != null) ? 
/* 330 */           incomingInfo.copy().addNullInfoFrom(this.nullInfos[j]) : 
/* 331 */           incomingInfo;
/* 332 */         switch (this.nullCheckTypes[j] & 0xFFFF0FFF) {
/*     */           case 256:
/*     */           case 512:
/* 335 */             if (flowInfo.isDefinitelyNonNull(local)) {
/* 336 */               this.nullReferences[j] = null;
/* 337 */               if ((this.nullCheckTypes[j] & 0xFFFF0FFF) == 512) {
/* 338 */                 if ((this.nullCheckTypes[j] & 0x1000) == 0)
/* 339 */                   scope.problemReporter().localVariableRedundantCheckOnNonNull(local, location); 
/*     */                 break;
/*     */               } 
/* 342 */               scope.problemReporter().localVariableNonNullComparedToNull(local, location);
/*     */               break;
/*     */             } 
/*     */ 
/*     */           
/*     */           case 257:
/*     */           case 513:
/*     */           case 769:
/*     */           case 1025:
/* 351 */             expression = (Expression)location;
/* 352 */             if (flowInfo.isDefinitelyNull(local)) {
/* 353 */               this.nullReferences[j] = null;
/* 354 */               switch (this.nullCheckTypes[j] & 0xFFFF0F00) {
/*     */                 case 256:
/* 356 */                   if ((this.nullCheckTypes[j] & 0xFF & 0xFFFF0FFF) == 1 && (expression.implicitConversion & 0x400) != 0) {
/* 357 */                     scope.problemReporter().localVariableNullReference(local, (ASTNode)expression);
/*     */                     break;
/*     */                   } 
/* 360 */                   if ((this.nullCheckTypes[j] & 0x1000) == 0) {
/* 361 */                     scope.problemReporter().localVariableRedundantCheckOnNull(local, (ASTNode)expression);
/*     */                   }
/*     */                   break;
/*     */                 case 512:
/* 365 */                   if ((this.nullCheckTypes[j] & 0xFF & 0xFFFF0FFF) == 1 && (expression.implicitConversion & 0x400) != 0) {
/* 366 */                     scope.problemReporter().localVariableNullReference(local, (ASTNode)expression);
/*     */                     break;
/*     */                   } 
/* 369 */                   scope.problemReporter().localVariableNullComparedToNonNull(local, (ASTNode)expression);
/*     */                   break;
/*     */                 case 768:
/* 372 */                   scope.problemReporter().localVariableRedundantNullAssignment(local, (ASTNode)expression);
/*     */                   break;
/*     */                 case 1024:
/* 375 */                   scope.problemReporter().localVariableNullInstanceof(local, (ASTNode)expression); break;
/*     */               }  break;
/*     */             } 
/* 378 */             if (flowInfo.isPotentiallyNull(local)) {
/* 379 */               switch (this.nullCheckTypes[j] & 0xFFFF0F00) {
/*     */                 case 256:
/* 381 */                   this.nullReferences[j] = null;
/* 382 */                   if ((this.nullCheckTypes[j] & 0xFF & 0xFFFF0FFF) == 1 && (expression.implicitConversion & 0x400) != 0) {
/* 383 */                     scope.problemReporter().localVariablePotentialNullReference(local, (ASTNode)expression);
/*     */                   }
/*     */                   break;
/*     */                 
/*     */                 case 512:
/* 388 */                   this.nullReferences[j] = null;
/* 389 */                   if ((this.nullCheckTypes[j] & 0xFF & 0xFFFF0FFF) == 1 && (expression.implicitConversion & 0x400) != 0) {
/* 390 */                     scope.problemReporter().localVariablePotentialNullReference(local, (ASTNode)expression);
/*     */                   }
/*     */                   break;
/*     */               } 
/*     */             
/*     */             }
/*     */             break;
/*     */           case 3:
/* 398 */             if (flowInfo.isDefinitelyNull(local)) {
/* 399 */               this.nullReferences[j] = null;
/* 400 */               scope.problemReporter().localVariableNullReference(local, location);
/*     */               break;
/*     */             } 
/* 403 */             if (flowInfo.isPotentiallyNull(local)) {
/* 404 */               this.nullReferences[j] = null;
/* 405 */               scope.problemReporter().localVariablePotentialNullReference(local, location);
/*     */             } 
/*     */             break;
/*     */           
/*     */           case 128:
/* 410 */             nullStatus = flowInfo.nullStatus(local);
/* 411 */             if (nullStatus != 4) {
/* 412 */               char[][] annotationName = scope.environment().getNonNullAnnotationName();
/* 413 */               TypeBinding providedType = this.providedExpectedTypes[j][0];
/* 414 */               TypeBinding expectedType = this.providedExpectedTypes[j][1];
/* 415 */               Expression expression2 = (Expression)location;
/* 416 */               if (this.nullAnnotationStatuses[j] != null) {
/* 417 */                 this.nullAnnotationStatuses[j] = this.nullAnnotationStatuses[j].withNullStatus(nullStatus);
/* 418 */                 scope.problemReporter().nullityMismatchingTypeAnnotation(expression2, providedType, expectedType, this.nullAnnotationStatuses[j]); break;
/*     */               } 
/* 420 */               scope.problemReporter().nullityMismatch(expression2, providedType, expectedType, nullStatus, annotationName);
/*     */             } 
/*     */             break;
/*     */           
/*     */           case 2048:
/* 425 */             nullStatus = flowInfo.nullStatus(local);
/* 426 */             if (nullStatus != 4) {
/* 427 */               FakedTrackingVariable closeTracker = local.closeTracker;
/* 428 */               if (closeTracker == null || 
/* 429 */                 closeTracker.hasDefinitelyNoResource(flowInfo)) {
/*     */                 break;
/*     */               }
/* 432 */               if (closeTracker.isClosedInFinallyOfEnclosing(scope)) {
/*     */                 break;
/*     */               }
/* 435 */               nullStatus = closeTracker.findMostSpecificStatus(flowInfo, scope, null);
/* 436 */               closeTracker.recordErrorLocation(this.nullReferences[j], nullStatus);
/* 437 */               closeTracker.reportRecordedErrors((Scope)scope, nullStatus, (flowInfo.reachMode() != 0));
/* 438 */               this.nullReferences[j] = null;
/*     */             } 
/*     */             break;
/*     */ 
/*     */           
/*     */           case 16:
/* 444 */             checkUnboxing((Scope)scope, (Expression)location, flowInfo);
/*     */             break;
/*     */         } 
/*     */ 
/*     */ 
/*     */       
/*     */       } 
/*     */     } 
/* 452 */     if (updateInitsOnBreak) {
/* 453 */       this.initsOnBreak.addPotentialNullInfoFrom(incomingInfo);
/* 454 */       for (int j = 0; j < this.breakTargetsCount; j++) {
/* 455 */         (this.breakTargetContexts[j]).initsOnBreak.addPotentialNullInfoFrom(incomingInfo);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public BranchLabel continueLabel() {
/* 462 */     return this.continueLabel;
/*     */   }
/*     */ 
/*     */   
/*     */   public String individualToString() {
/* 467 */     StringBuilder buffer = new StringBuilder("Looping flow context");
/* 468 */     buffer.append("[initsOnBreak - ").append(this.initsOnBreak.toString()).append(']');
/* 469 */     buffer.append("[initsOnContinue - ").append(this.initsOnContinue.toString()).append(']');
/* 470 */     buffer.append("[finalAssignments count - ").append(this.assignCount).append(']');
/* 471 */     buffer.append("[nullReferences count - ").append(this.nullCount).append(']');
/* 472 */     return buffer.toString();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isContinuable() {
/* 477 */     return true;
/*     */   }
/*     */   
/*     */   public boolean isContinuedTo() {
/* 481 */     return (this.initsOnContinue != FlowInfo.DEAD_END);
/*     */   }
/*     */ 
/*     */   
/*     */   public void recordBreakTo(FlowContext targetContext) {
/* 486 */     if (targetContext instanceof LabelFlowContext) {
/*     */       int current;
/* 488 */       if ((current = this.breakTargetsCount++) == 0) {
/* 489 */         this.breakTargetContexts = new LabelFlowContext[2];
/* 490 */       } else if (current == this.breakTargetContexts.length) {
/* 491 */         System.arraycopy(this.breakTargetContexts, 0, this.breakTargetContexts = new LabelFlowContext[current + 2], 0, current);
/*     */       } 
/* 493 */       this.breakTargetContexts[current] = (LabelFlowContext)targetContext;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void recordContinueFrom(FlowContext innerFlowContext, FlowInfo flowInfo) {
/* 499 */     if ((flowInfo.tagBits & 0x1) == 0) {
/* 500 */       if ((this.initsOnContinue.tagBits & 0x1) == 0) {
/* 501 */         this.initsOnContinue = this.initsOnContinue
/* 502 */           .mergedWith(flowInfo.unconditionalInitsWithoutSideEffect());
/*     */       } else {
/*     */         
/* 505 */         this.initsOnContinue = flowInfo.unconditionalCopy();
/*     */       } 
/* 507 */       FlowContext inner = innerFlowContext;
/* 508 */       while (inner != this && !(inner instanceof LoopingFlowContext)) {
/* 509 */         inner = inner.parent;
/*     */       }
/*     */       
/* 512 */       if (inner == this) {
/* 513 */         this.upstreamNullFlowInfo
/* 514 */           .addPotentialNullInfoFrom(
/* 515 */             flowInfo.unconditionalInitsWithoutSideEffect());
/*     */       } else {
/*     */         
/* 518 */         int length = 0;
/* 519 */         if (this.innerFlowContexts == null) {
/* 520 */           this.innerFlowContexts = new LoopingFlowContext[5];
/* 521 */           this.innerFlowInfos = new UnconditionalFlowInfo[5];
/*     */         }
/* 523 */         else if (this.innerFlowContextsCount == (
/* 524 */           length = this.innerFlowContexts.length) - 1) {
/* 525 */           System.arraycopy(this.innerFlowContexts, 0, 
/* 526 */               this.innerFlowContexts = new LoopingFlowContext[length + 5], 
/* 527 */               0, length);
/* 528 */           System.arraycopy(this.innerFlowInfos, 0, 
/* 529 */               this.innerFlowInfos = new UnconditionalFlowInfo[length + 5], 
/* 530 */               0, length);
/*     */         } 
/* 532 */         this.innerFlowContexts[this.innerFlowContextsCount] = (LoopingFlowContext)inner;
/* 533 */         this.innerFlowInfos[this.innerFlowContextsCount++] = 
/* 534 */           flowInfo.unconditionalInitsWithoutSideEffect();
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean recordFinalAssignment(VariableBinding binding, Reference finalAssignment) {
/* 545 */     if (binding instanceof LocalVariableBinding) {
/* 546 */       BlockScope blockScope = ((LocalVariableBinding)binding).declaringScope; Scope scope;
/* 547 */       while ((scope = ((Scope)blockScope).parent) != null) {
/* 548 */         if (scope == this.associatedScope)
/* 549 */           return false; 
/*     */       } 
/*     */     } 
/* 552 */     if (this.assignCount == 0) {
/* 553 */       this.finalAssignments = new Reference[5];
/* 554 */       this.finalVariables = new VariableBinding[5];
/*     */     } else {
/* 556 */       if (this.assignCount == this.finalAssignments.length)
/* 557 */         System.arraycopy(
/* 558 */             this.finalAssignments, 
/* 559 */             0, 
/* 560 */             this.finalAssignments = new Reference[this.assignCount * 2], 
/* 561 */             0, 
/* 562 */             this.assignCount); 
/* 563 */       System.arraycopy(
/* 564 */           this.finalVariables, 
/* 565 */           0, 
/* 566 */           this.finalVariables = new VariableBinding[this.assignCount * 2], 
/* 567 */           0, 
/* 568 */           this.assignCount);
/*     */     } 
/* 570 */     this.finalAssignments[this.assignCount] = finalAssignment;
/* 571 */     this.finalVariables[this.assignCount++] = binding;
/* 572 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void recordNullReferenceWithAnnotationStatus(LocalVariableBinding local, ASTNode expression, int checkType, FlowInfo nullInfo, NullAnnotationMatching nullAnnotationStatus) {
/* 578 */     if (this.nullCount == 0) {
/* 579 */       this.nullLocals = new LocalVariableBinding[5];
/* 580 */       this.nullReferences = new ASTNode[5];
/* 581 */       this.nullCheckTypes = new int[5];
/* 582 */       this.nullInfos = new UnconditionalFlowInfo[5];
/* 583 */       this.nullAnnotationStatuses = new NullAnnotationMatching[5];
/*     */     }
/* 585 */     else if (this.nullCount == this.nullLocals.length) {
/* 586 */       System.arraycopy(this.nullLocals, 0, 
/* 587 */           this.nullLocals = new LocalVariableBinding[this.nullCount * 2], 0, this.nullCount);
/* 588 */       System.arraycopy(this.nullReferences, 0, 
/* 589 */           this.nullReferences = new ASTNode[this.nullCount * 2], 0, this.nullCount);
/* 590 */       System.arraycopy(this.nullCheckTypes, 0, 
/* 591 */           this.nullCheckTypes = new int[this.nullCount * 2], 0, this.nullCount);
/* 592 */       System.arraycopy(this.nullInfos, 0, 
/* 593 */           this.nullInfos = new UnconditionalFlowInfo[this.nullCount * 2], 0, this.nullCount);
/* 594 */       System.arraycopy(this.nullAnnotationStatuses, 0, 
/* 595 */           this.nullAnnotationStatuses = new NullAnnotationMatching[this.nullCount * 2], 0, this.nullCount);
/*     */     } 
/* 597 */     this.nullLocals[this.nullCount] = local;
/* 598 */     this.nullReferences[this.nullCount] = expression;
/* 599 */     this.nullCheckTypes[this.nullCount] = checkType;
/* 600 */     this.nullAnnotationStatuses[this.nullCount] = nullAnnotationStatus;
/* 601 */     this.nullInfos[this.nullCount++] = (nullInfo != null) ? nullInfo.unconditionalCopy() : null;
/*     */   }
/*     */   
/*     */   public void recordUnboxing(Scope scope, Expression expression, int nullStatus, FlowInfo flowInfo) {
/* 605 */     if (nullStatus == 2) {
/* 606 */       super.recordUnboxing(scope, expression, nullStatus, flowInfo);
/*     */     } else {
/* 608 */       recordNullReference(null, (ASTNode)expression, 16, flowInfo);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean recordExitAgainstResource(BlockScope scope, FlowInfo flowInfo, FakedTrackingVariable trackingVar, ASTNode reference) {
/* 614 */     LocalVariableBinding local = trackingVar.binding;
/* 615 */     if (flowInfo.isDefinitelyNonNull(local)) {
/* 616 */       return false;
/*     */     }
/* 618 */     if (flowInfo.isDefinitelyNull(local)) {
/* 619 */       scope.problemReporter().unclosedCloseable(trackingVar, reference);
/* 620 */       return true;
/*     */     } 
/* 622 */     if (flowInfo.isPotentiallyNull(local)) {
/* 623 */       scope.problemReporter().potentiallyUnclosedCloseable(trackingVar, reference);
/* 624 */       return true;
/*     */     } 
/* 626 */     recordNullReference(trackingVar.binding, reference, 2048, flowInfo);
/* 627 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public void recordUsingNullReference(Scope scope, LocalVariableBinding local, ASTNode location, int checkType, FlowInfo flowInfo) {
/*     */     Expression reference;
/* 633 */     if ((flowInfo.tagBits & 0x3) != 0 || 
/* 634 */       flowInfo.isDefinitelyUnknown(local)) {
/*     */       return;
/*     */     }
/*     */     
/* 638 */     checkType |= this.tagBits & 0x1000;
/* 639 */     int checkTypeWithoutHideNullWarning = checkType & 0xFFFF0FFF;
/* 640 */     switch (checkTypeWithoutHideNullWarning) {
/*     */       case 256:
/*     */       case 512:
/* 643 */         reference = (Expression)location;
/* 644 */         if (flowInfo.isDefinitelyNonNull(local))
/* 645 */         { if (checkTypeWithoutHideNullWarning == 512) {
/* 646 */             if ((this.tagBits & 0x1000) == 0) {
/* 647 */               scope.problemReporter().localVariableRedundantCheckOnNonNull(local, (ASTNode)reference);
/*     */             }
/* 649 */             flowInfo.initsWhenFalse().setReachMode(2);
/*     */           } else {
/* 651 */             scope.problemReporter().localVariableNonNullComparedToNull(local, (ASTNode)reference);
/* 652 */             flowInfo.initsWhenTrue().setReachMode(2);
/*     */           }  }
/* 654 */         else if (flowInfo.isDefinitelyNull(local))
/* 655 */         { if (checkTypeWithoutHideNullWarning == 256) {
/* 656 */             if ((this.tagBits & 0x1000) == 0) {
/* 657 */               scope.problemReporter().localVariableRedundantCheckOnNull(local, (ASTNode)reference);
/*     */             }
/* 659 */             flowInfo.initsWhenFalse().setReachMode(2);
/*     */           } else {
/* 661 */             scope.problemReporter().localVariableNullComparedToNonNull(local, (ASTNode)reference);
/* 662 */             flowInfo.initsWhenTrue().setReachMode(2);
/*     */           }  }
/* 664 */         else if (this.upstreamNullFlowInfo.isDefinitelyNonNull(local) && !flowInfo.isPotentiallyNull(local) && !flowInfo.isPotentiallyUnknown(local))
/*     */         
/* 666 */         { recordNullReference(local, (ASTNode)reference, checkType, flowInfo);
/* 667 */           flowInfo.markAsDefinitelyNonNull(local); }
/* 668 */         else { if (flowInfo.cannotBeDefinitelyNullOrNonNull(local)) {
/*     */             return;
/*     */           }
/*     */           
/* 672 */           if (flowInfo.isPotentiallyNonNull(local)) {
/*     */             
/* 674 */             recordNullReference(local, (ASTNode)reference, 0x2 | checkType & 0xFFFFFF00, flowInfo);
/* 675 */           } else if (flowInfo.isPotentiallyNull(local)) {
/*     */             
/* 677 */             recordNullReference(local, (ASTNode)reference, 0x1 | checkType & 0xFFFFFF00, flowInfo);
/*     */           } else {
/* 679 */             recordNullReference(local, (ASTNode)reference, checkType, flowInfo);
/*     */           }  }
/*     */         
/*     */         return;
/*     */       case 257:
/*     */       case 513:
/*     */       case 769:
/*     */       case 1025:
/* 687 */         reference = (Expression)location;
/* 688 */         if (flowInfo.isPotentiallyNonNull(local) || 
/* 689 */           flowInfo.isPotentiallyUnknown(local) || 
/* 690 */           flowInfo.isProtectedNonNull(local)) {
/*     */           return;
/*     */         }
/*     */ 
/*     */         
/* 695 */         if (flowInfo.isDefinitelyNull(local)) {
/* 696 */           switch (checkTypeWithoutHideNullWarning & 0xFFFF0F00) {
/*     */             case 256:
/* 698 */               if ((checkTypeWithoutHideNullWarning & 0xFF) == 1 && (reference.implicitConversion & 0x400) != 0) {
/* 699 */                 scope.problemReporter().localVariableNullReference(local, (ASTNode)reference);
/*     */                 return;
/*     */               } 
/* 702 */               if ((this.tagBits & 0x1000) == 0) {
/* 703 */                 scope.problemReporter().localVariableRedundantCheckOnNull(local, (ASTNode)reference);
/*     */               }
/* 705 */               flowInfo.initsWhenFalse().setReachMode(2);
/*     */               return;
/*     */             case 512:
/* 708 */               if ((checkTypeWithoutHideNullWarning & 0xFF) == 1 && (reference.implicitConversion & 0x400) != 0) {
/* 709 */                 scope.problemReporter().localVariableNullReference(local, (ASTNode)reference);
/*     */                 return;
/*     */               } 
/* 712 */               scope.problemReporter().localVariableNullComparedToNonNull(local, (ASTNode)reference);
/* 713 */               flowInfo.initsWhenTrue().setReachMode(2);
/*     */               return;
/*     */             case 768:
/* 716 */               scope.problemReporter().localVariableRedundantNullAssignment(local, (ASTNode)reference);
/*     */               return;
/*     */             case 1024:
/* 719 */               scope.problemReporter().localVariableNullInstanceof(local, (ASTNode)reference);
/*     */               return;
/*     */           } 
/* 722 */         } else if (flowInfo.isPotentiallyNull(local)) {
/* 723 */           switch (checkTypeWithoutHideNullWarning & 0xFFFF0F00) {
/*     */             case 256:
/* 725 */               if ((checkTypeWithoutHideNullWarning & 0xFF) == 1 && (reference.implicitConversion & 0x400) != 0) {
/* 726 */                 scope.problemReporter().localVariablePotentialNullReference(local, (ASTNode)reference);
/*     */                 return;
/*     */               } 
/*     */               break;
/*     */             case 512:
/* 731 */               if ((checkTypeWithoutHideNullWarning & 0xFF) == 1 && (reference.implicitConversion & 0x400) != 0) {
/* 732 */                 scope.problemReporter().localVariablePotentialNullReference(local, (ASTNode)reference);
/*     */                 return;
/*     */               } 
/*     */               break;
/*     */           } 
/*     */         } 
/* 738 */         recordNullReference(local, (ASTNode)reference, checkType, flowInfo);
/*     */         return;
/*     */       case 3:
/* 741 */         if (flowInfo.isDefinitelyNonNull(local)) {
/*     */           return;
/*     */         }
/* 744 */         if (flowInfo.isDefinitelyNull(local)) {
/* 745 */           scope.problemReporter().localVariableNullReference(local, location);
/*     */           return;
/*     */         } 
/* 748 */         if (flowInfo.isPotentiallyNull(local)) {
/* 749 */           scope.problemReporter().localVariablePotentialNullReference(local, location);
/*     */           return;
/*     */         } 
/* 752 */         recordNullReference(local, location, checkType, flowInfo);
/*     */         return;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void removeFinalAssignmentIfAny(Reference reference) {
/* 761 */     for (int i = 0; i < this.assignCount; i++) {
/* 762 */       if (this.finalAssignments[i] == reference) {
/* 763 */         this.finalAssignments[i] = null;
/* 764 */         this.finalVariables[i] = null;
/*     */         return;
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void simulateThrowAfterLoopBack(FlowInfo flowInfo) {
/* 774 */     if (this.escapingExceptionCatchSites != null) {
/* 775 */       for (int i = 0, exceptionCount = this.escapingExceptionCatchSites.size(); i < exceptionCount; i++) {
/* 776 */         ((EscapingExceptionCatchSite)this.escapingExceptionCatchSites.get(i)).simulateThrowAfterLoopBack(flowInfo);
/*     */       }
/* 778 */       this.escapingExceptionCatchSites = null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void recordCatchContextOfEscapingException(ExceptionHandlingFlowContext catchingContext, ReferenceBinding caughtException, FlowInfo exceptionInfo) {
/* 787 */     if (this.escapingExceptionCatchSites == null) {
/* 788 */       this.escapingExceptionCatchSites = new ArrayList(5);
/*     */     }
/* 790 */     this.escapingExceptionCatchSites.add(new EscapingExceptionCatchSite(catchingContext, caughtException, exceptionInfo));
/*     */   }
/*     */   
/*     */   public boolean hasEscapingExceptions() {
/* 794 */     return (this.escapingExceptionCatchSites != null);
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean internalRecordNullityMismatch(Expression expression, TypeBinding providedType, FlowInfo flowInfo, int nullStatus, NullAnnotationMatching nullAnnotationStatus, TypeBinding expectedType, int checkType) {
/* 799 */     recordProvidedExpectedTypes(providedType, expectedType, this.nullCount);
/* 800 */     recordNullReferenceWithAnnotationStatus(expression.localVariableBinding(), (ASTNode)expression, checkType, flowInfo, nullAnnotationStatus);
/* 801 */     return true;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\flow\LoopingFlowContext.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */