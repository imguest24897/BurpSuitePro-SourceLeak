/*     */ package org.eclipse.jdt.internal.compiler.env;
/*     */ 
/*     */ import org.eclipse.jdt.core.compiler.CharOperation;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AccessRuleSet
/*     */ {
/*     */   private AccessRule[] accessRules;
/*     */   public byte classpathEntryType;
/*     */   public String classpathEntryName;
/*     */   
/*     */   public AccessRuleSet(AccessRule[] accessRules, byte classpathEntryType, String classpathEntryName) {
/*  37 */     this.accessRules = accessRules;
/*  38 */     this.classpathEntryType = classpathEntryType;
/*  39 */     this.classpathEntryName = classpathEntryName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object object) {
/*  47 */     if (this == object)
/*  48 */       return true; 
/*  49 */     if (!(object instanceof AccessRuleSet))
/*  50 */       return false; 
/*  51 */     AccessRuleSet otherRuleSet = (AccessRuleSet)object;
/*  52 */     if (this.classpathEntryType != otherRuleSet.classpathEntryType || (
/*  53 */       this.classpathEntryName == null && otherRuleSet.classpathEntryName != null) || 
/*  54 */       !this.classpathEntryName.equals(otherRuleSet.classpathEntryName)) {
/*  55 */       return false;
/*     */     }
/*  57 */     int rulesLength = this.accessRules.length;
/*  58 */     if (rulesLength != otherRuleSet.accessRules.length) return false; 
/*  59 */     for (int i = 0; i < rulesLength; i++) {
/*  60 */       if (!this.accessRules[i].equals(otherRuleSet.accessRules[i]))
/*  61 */         return false; 
/*  62 */     }  return true;
/*     */   }
/*     */   
/*     */   public AccessRule[] getAccessRules() {
/*  66 */     return this.accessRules;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AccessRestriction getViolatedRestriction(char[] targetTypeFilePath) {
/*  77 */     for (int i = 0, length = this.accessRules.length; i < length; i++) {
/*  78 */       AccessRule accessRule = this.accessRules[i];
/*  79 */       if (CharOperation.pathMatch(accessRule.pattern, targetTypeFilePath, 
/*  80 */           true, '/')) {
/*  81 */         switch (accessRule.getProblemId()) {
/*     */           case 16777496:
/*     */           case 16777523:
/*  84 */             return new AccessRestriction(accessRule, this.classpathEntryType, this.classpathEntryName);
/*     */         } 
/*  86 */         return null;
/*     */       } 
/*     */     } 
/*     */     
/*  90 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/*  96 */     int result = 1;
/*  97 */     result = 31 * result + hashCode(this.accessRules);
/*  98 */     result = 31 * result + ((this.classpathEntryName == null) ? 0 : this.classpathEntryName.hashCode());
/*  99 */     result = 31 * result + this.classpathEntryType;
/* 100 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   private int hashCode(AccessRule[] rules) {
/* 105 */     if (rules == null)
/* 106 */       return 0; 
/* 107 */     int result = 1;
/* 108 */     for (int i = 0, length = rules.length; i < length; i++) {
/* 109 */       result = 31 * result + ((rules[i] == null) ? 0 : rules[i].hashCode());
/*     */     }
/* 111 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 116 */     return toString(true);
/*     */   }
/*     */   
/*     */   public String toString(boolean wrap) {
/* 120 */     StringBuilder buffer = new StringBuilder(200);
/* 121 */     buffer.append("AccessRuleSet {");
/* 122 */     if (wrap)
/* 123 */       buffer.append('\n'); 
/* 124 */     for (int i = 0, length = this.accessRules.length; i < length; i++) {
/* 125 */       if (wrap)
/* 126 */         buffer.append('\t'); 
/* 127 */       AccessRule accessRule = this.accessRules[i];
/* 128 */       buffer.append(accessRule);
/* 129 */       if (wrap) {
/* 130 */         buffer.append('\n');
/* 131 */       } else if (i < length - 1) {
/* 132 */         buffer.append(", ");
/*     */       } 
/* 134 */     }  buffer.append("} [classpath entry: ");
/* 135 */     buffer.append(this.classpathEntryName);
/* 136 */     buffer.append("]");
/* 137 */     return buffer.toString();
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\env\AccessRuleSet.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */