/*     */ package org.eclipse.jdt.internal.compiler.classfmt;
/*     */ 
/*     */ import org.eclipse.jdt.internal.compiler.env.IBinaryAnnotation;
/*     */ import org.eclipse.jdt.internal.compiler.env.IBinaryElementValuePair;
/*     */ import org.eclipse.jdt.internal.compiler.env.IBinaryMethod;
/*     */ import org.eclipse.jdt.internal.compiler.env.IBinaryTypeAnnotation;
/*     */ import org.eclipse.jdt.internal.compiler.util.Util;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BinaryTypeFormatter
/*     */ {
/*     */   public static String annotationToString(IBinaryAnnotation annotation) {
/*  25 */     StringBuilder buffer = new StringBuilder();
/*  26 */     buffer.append('@');
/*  27 */     buffer.append(annotation.getTypeName());
/*  28 */     IBinaryElementValuePair[] valuePairs = annotation.getElementValuePairs();
/*  29 */     if (valuePairs != null) {
/*  30 */       buffer.append('(');
/*  31 */       buffer.append("\n\t");
/*  32 */       for (int i = 0, len = valuePairs.length; i < len; i++) {
/*  33 */         if (i > 0)
/*  34 */           buffer.append(",\n\t"); 
/*  35 */         buffer.append(valuePairs[i]);
/*     */       } 
/*  37 */       buffer.append(')');
/*     */     } 
/*  39 */     return buffer.toString();
/*     */   }
/*     */   
/*     */   public static String annotationToString(IBinaryTypeAnnotation typeAnnotation) {
/*  43 */     StringBuilder buffer = new StringBuilder();
/*  44 */     buffer.append(typeAnnotation.getAnnotation());
/*  45 */     buffer.append(' ');
/*     */     
/*  47 */     buffer.append("target_type=").append(typeAnnotation.getTargetType());
/*  48 */     buffer.append(", info=").append(typeAnnotation.getSupertypeIndex());
/*  49 */     buffer.append(", info2=").append(typeAnnotation.getBoundIndex());
/*  50 */     int[] theTypePath = typeAnnotation.getTypePath();
/*  51 */     if (theTypePath != null && theTypePath.length != 0) {
/*  52 */       buffer.append(", location=[");
/*  53 */       for (int i = 0, max = theTypePath.length; i < max; i += 2) {
/*  54 */         if (i > 0) {
/*  55 */           buffer.append(", ");
/*     */         }
/*  57 */         switch (theTypePath[i]) {
/*     */           case 0:
/*  59 */             buffer.append("ARRAY");
/*     */             break;
/*     */           case 1:
/*  62 */             buffer.append("INNER_TYPE");
/*     */             break;
/*     */           case 2:
/*  65 */             buffer.append("WILDCARD");
/*     */             break;
/*     */           case 3:
/*  68 */             buffer.append("TYPE_ARGUMENT(").append(theTypePath[i + 1]).append(')');
/*     */             break;
/*     */         } 
/*     */       } 
/*  72 */       buffer.append(']');
/*     */     } 
/*  74 */     return buffer.toString();
/*     */   }
/*     */   
/*     */   public static String methodToString(IBinaryMethod method) {
/*  78 */     StringBuffer result = new StringBuffer();
/*  79 */     methodToStringContent(result, method);
/*  80 */     return result.toString();
/*     */   }
/*     */   
/*     */   public static void methodToStringContent(StringBuffer buffer, IBinaryMethod method) {
/*  84 */     int modifiers = method.getModifiers();
/*  85 */     char[] desc = method.getGenericSignature();
/*  86 */     if (desc == null)
/*  87 */       desc = method.getMethodDescriptor(); 
/*  88 */     buffer
/*  89 */       .append('{')
/*  90 */       .append(
/*  91 */         String.valueOf(((modifiers & 0x100000) != 0) ? "deprecated " : Util.EMPTY_STRING) + (
/*  92 */         ((modifiers & 0x1) == 1) ? "public " : Util.EMPTY_STRING) + (
/*  93 */         ((modifiers & 0x2) == 2) ? "private " : Util.EMPTY_STRING) + (
/*  94 */         ((modifiers & 0x4) == 4) ? "protected " : Util.EMPTY_STRING) + (
/*  95 */         ((modifiers & 0x8) == 8) ? "static " : Util.EMPTY_STRING) + (
/*  96 */         ((modifiers & 0x10) == 16) ? "final " : Util.EMPTY_STRING) + (
/*  97 */         ((modifiers & 0x40) == 64) ? "bridge " : Util.EMPTY_STRING) + (
/*  98 */         ((modifiers & 0x80) == 128) ? "varargs " : Util.EMPTY_STRING))
/*  99 */       .append(method.getSelector())
/* 100 */       .append(desc)
/* 101 */       .append('}');
/*     */     
/* 103 */     Object defaultValue = method.getDefaultValue();
/* 104 */     if (defaultValue != null) {
/* 105 */       buffer.append(" default ");
/* 106 */       if (defaultValue instanceof Object[]) {
/* 107 */         buffer.append('{');
/* 108 */         Object[] elements = (Object[])defaultValue;
/* 109 */         for (int k = 0, len = elements.length; k < len; k++) {
/* 110 */           if (k > 0)
/* 111 */             buffer.append(", "); 
/* 112 */           buffer.append(elements[k]);
/*     */         } 
/* 114 */         buffer.append('}');
/*     */       } else {
/* 116 */         buffer.append(defaultValue);
/*     */       } 
/* 118 */       buffer.append('\n');
/*     */     } 
/*     */     
/* 121 */     IBinaryAnnotation[] annotations = method.getAnnotations();
/* 122 */     for (int i = 0, l = (annotations == null) ? 0 : annotations.length; i < l; i++) {
/* 123 */       buffer.append(annotations[i]);
/* 124 */       buffer.append('\n');
/*     */     } 
/*     */     
/* 127 */     int annotatedParameterCount = method.getAnnotatedParametersCount();
/* 128 */     for (int j = 0; j < annotatedParameterCount; j++) {
/* 129 */       buffer.append("param" + (j - 1));
/* 130 */       buffer.append('\n');
/* 131 */       IBinaryAnnotation[] infos = method.getParameterAnnotations(j, new char[0]);
/* 132 */       for (int m = 0, k = (infos == null) ? 0 : infos.length; m < k; m++) {
/* 133 */         buffer.append(infos[m]);
/* 134 */         buffer.append('\n');
/*     */       } 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\classfmt\BinaryTypeFormatter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */