/*     */ package org.eclipse.jdt.internal.compiler.ast;
/*     */ 
/*     */ import org.eclipse.jdt.core.compiler.CharOperation;
/*     */ import org.eclipse.jdt.internal.compiler.ASTVisitor;
/*     */ import org.eclipse.jdt.internal.compiler.codegen.CodeStream;
/*     */ import org.eclipse.jdt.internal.compiler.flow.FlowContext;
/*     */ import org.eclipse.jdt.internal.compiler.flow.FlowInfo;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.Binding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.BlockScope;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.FieldBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.MethodBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.MethodScope;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.ReferenceBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.SourceTypeBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.TypeBinding;
/*     */ import org.eclipse.jdt.internal.compiler.parser.Parser;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Initializer
/*     */   extends FieldDeclaration
/*     */ {
/*     */   public Block block;
/*     */   public int lastVisibleFieldID;
/*     */   public int bodyStart;
/*     */   public int bodyEnd;
/*     */   private MethodBinding methodBinding;
/*     */   
/*     */   public Initializer(Block block, int modifiers) {
/*  36 */     this.block = block;
/*  37 */     this.modifiers = modifiers;
/*     */     
/*  39 */     if (block != null) {
/*  40 */       this.declarationSourceStart = this.sourceStart = block.sourceStart;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public FlowInfo analyseCode(MethodScope currentScope, FlowContext flowContext, FlowInfo flowInfo) {
/*  50 */     if (this.block != null) {
/*  51 */       return this.block.analyseCode((BlockScope)currentScope, flowContext, flowInfo);
/*     */     }
/*  53 */     return flowInfo;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void generateCode(BlockScope currentScope, CodeStream codeStream) {
/*  66 */     if ((this.bits & Integer.MIN_VALUE) == 0) {
/*     */       return;
/*     */     }
/*  69 */     int pc = codeStream.position;
/*  70 */     if (this.block != null) this.block.generateCode(currentScope, codeStream); 
/*  71 */     codeStream.recordPositionsFrom(pc, this.sourceStart);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getKind() {
/*  79 */     return 2;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isStatic() {
/*  85 */     return ((this.modifiers & 0x8) != 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void parseStatements(Parser parser, TypeDeclaration typeDeclaration, CompilationUnitDeclaration unit) {
/*  94 */     parser.parse(this, typeDeclaration, unit);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public StringBuffer printStatement(int indent, StringBuffer output) {
/* 100 */     if (this.modifiers != 0) {
/* 101 */       printIndent(indent, output);
/* 102 */       printModifiers(this.modifiers, output);
/* 103 */       if (this.annotations != null) {
/* 104 */         printAnnotations(this.annotations, output);
/* 105 */         output.append(' ');
/*     */       } 
/* 107 */       output.append("{\n");
/* 108 */       if (this.block != null) {
/* 109 */         this.block.printBody(indent, output);
/*     */       }
/* 111 */       printIndent(indent, output).append('}');
/* 112 */       return output;
/* 113 */     }  if (this.block != null) {
/* 114 */       this.block.printStatement(indent, output);
/*     */     } else {
/* 116 */       printIndent(indent, output).append("{}");
/*     */     } 
/* 118 */     return output;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void resolve(MethodScope scope) {
/* 124 */     FieldBinding previousField = scope.initializedField;
/* 125 */     int previousFieldID = scope.lastVisibleFieldID;
/*     */     try {
/* 127 */       scope.initializedField = null;
/* 128 */       scope.lastVisibleFieldID = this.lastVisibleFieldID;
/* 129 */       if (isStatic()) {
/* 130 */         SourceTypeBinding sourceTypeBinding = scope.enclosingSourceType();
/* 131 */         if ((scope.compilerOptions()).sourceLevel < 3932160L && 
/* 132 */           sourceTypeBinding.isNestedType() && !sourceTypeBinding.isStatic()) {
/* 133 */           scope.problemReporter().innerTypesCannotDeclareStaticInitializers(
/* 134 */               (ReferenceBinding)sourceTypeBinding, 
/* 135 */               this);
/*     */         }
/*     */       } 
/* 138 */       if (this.block != null) this.block.resolve((BlockScope)scope); 
/*     */     } finally {
/* 140 */       scope.initializedField = previousField;
/* 141 */       scope.lastVisibleFieldID = previousFieldID;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public MethodBinding getMethodBinding() {
/* 147 */     if (this.methodBinding == null) {
/* 148 */       BlockScope blockScope = this.block.scope;
/* 149 */       this.methodBinding = isStatic() ? 
/* 150 */         new MethodBinding(8, CharOperation.NO_CHAR, (TypeBinding)TypeBinding.VOID, Binding.NO_PARAMETERS, Binding.NO_EXCEPTIONS, (ReferenceBinding)blockScope.enclosingSourceType()) : 
/* 151 */         new MethodBinding(0, CharOperation.NO_CHAR, (TypeBinding)TypeBinding.VOID, Binding.NO_PARAMETERS, Binding.NO_EXCEPTIONS, (ReferenceBinding)blockScope.enclosingSourceType());
/*     */     } 
/* 153 */     return this.methodBinding;
/*     */   }
/*     */ 
/*     */   
/*     */   public void traverse(ASTVisitor visitor, MethodScope scope) {
/* 158 */     if (visitor.visit(this, scope) && 
/* 159 */       this.block != null) this.block.traverse(visitor, (BlockScope)scope);
/*     */     
/* 161 */     visitor.endVisit(this, scope);
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\ast\Initializer.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */