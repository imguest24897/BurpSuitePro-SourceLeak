/*     */ package org.eclipse.jdt.internal.compiler.env;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.util.jar.Manifest;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AutomaticModuleNaming
/*     */ {
/*     */   private static final String AUTOMATIC_MODULE_NAME = "Automatic-Module-Name";
/*     */   
/*     */   public static char[] determineAutomaticModuleName(String jarFileName) {
/*     */     
/*  33 */     try { Exception exception1 = null, exception2 = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       try {  }
/*     */       finally
/*  41 */       { exception2 = null; if (exception1 == null) { exception1 = exception2; } else if (exception1 != exception2) { exception1.addSuppressed(exception2); }  }  } catch (IOException iOException) {}
/*     */ 
/*     */ 
/*     */     
/*  45 */     return determineAutomaticModuleNameFromFileName(jarFileName, true, true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static char[] determineAutomaticModuleName(String fileName, boolean isFile, Manifest manifest) {
/*  58 */     if (manifest != null) {
/*  59 */       String automaticModuleName = manifest.getMainAttributes().getValue("Automatic-Module-Name");
/*  60 */       if (automaticModuleName != null) {
/*  61 */         return automaticModuleName.toCharArray();
/*     */       }
/*     */     } 
/*  64 */     return determineAutomaticModuleNameFromFileName(fileName, true, isFile);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static char[] determineAutomaticModuleNameFromManifest(Manifest manifest) {
/*  74 */     if (manifest != null) {
/*  75 */       String automaticModuleName = manifest.getMainAttributes().getValue("Automatic-Module-Name");
/*  76 */       if (automaticModuleName != null) {
/*  77 */         return automaticModuleName.toCharArray();
/*     */       }
/*     */     } 
/*  80 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static char[] determineAutomaticModuleNameFromFileName(String name, boolean skipDirectory, boolean removeExtension) {
/*  98 */     int start = 0;
/*  99 */     int end = name.length();
/* 100 */     if (skipDirectory) {
/* 101 */       int j = name.lastIndexOf(File.separatorChar);
/* 102 */       start = j + 1;
/*     */     } 
/*     */ 
/*     */     
/* 106 */     if (removeExtension && (
/* 107 */       name.endsWith(".jar") || name.endsWith(".JAR"))) {
/* 108 */       end -= 4;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 114 */     for (int index = start; index < end - 1; index++) {
/* 115 */       if (name.charAt(index) == '-' && name.charAt(index + 1) >= '0' && name.charAt(index + 1) <= '9') {
/* 116 */         for (int index2 = index + 2; index2 < end; ) {
/* 117 */           char c = name.charAt(index2);
/* 118 */           if (c == '.') {
/*     */             break;
/*     */           }
/* 121 */           if (c >= '0') { if (c > '9')
/*     */               // Byte code: goto -> 150  index2++; }
/*     */            // Byte code: goto -> 150
/*     */         } 
/* 125 */         end = index;
/*     */ 
/*     */         
/*     */         break;
/*     */       } 
/*     */     } 
/*     */     
/* 132 */     StringBuilder sb = new StringBuilder(end - start);
/* 133 */     boolean needDot = false;
/* 134 */     for (int i = start; i < end; i++) {
/* 135 */       char c = name.charAt(i);
/* 136 */       if ((c >= 'A' && c <= 'Z') || (c >= 'a' && c <= 'z') || (c >= '0' && c <= '9')) {
/* 137 */         if (needDot) {
/* 138 */           sb.append('.');
/* 139 */           needDot = false;
/*     */         } 
/* 141 */         sb.append(c);
/*     */       }
/* 143 */       else if (sb.length() > 0) {
/* 144 */         needDot = true;
/*     */       } 
/*     */     } 
/*     */     
/* 148 */     return sb.toString().toCharArray();
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\env\AutomaticModuleNaming.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */