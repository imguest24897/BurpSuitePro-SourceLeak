/*    */ package org.eclipse.jdt.internal.compiler.codegen;
/*    */ 
/*    */ import org.eclipse.jdt.internal.compiler.ast.Annotation;
/*    */ import org.eclipse.jdt.internal.compiler.ast.TypeReference;
/*    */ import org.eclipse.jdt.internal.compiler.ast.UnionTypeReference;
/*    */ import org.eclipse.jdt.internal.compiler.lookup.TypeBinding;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MultiCatchExceptionLabel
/*    */   extends ExceptionLabel
/*    */ {
/*    */   ExceptionLabel[] exceptionLabels;
/*    */   
/*    */   public MultiCatchExceptionLabel(CodeStream codeStream, TypeBinding exceptionType) {
/* 29 */     super(codeStream, exceptionType);
/*    */   }
/*    */   
/*    */   public void initialize(UnionTypeReference typeReference, Annotation[] annotations) {
/* 33 */     TypeReference[] typeReferences = typeReference.typeReferences;
/* 34 */     int length = typeReferences.length;
/* 35 */     this.exceptionLabels = new ExceptionLabel[length];
/* 36 */     for (int i = 0; i < length; i++) {
/* 37 */       this.exceptionLabels[i] = new ExceptionLabel(this.codeStream, (typeReferences[i]).resolvedType, typeReferences[i], (i == 0) ? annotations : null);
/*    */     }
/*    */   }
/*    */   
/*    */   public void place() {
/* 42 */     for (int i = 0, max = this.exceptionLabels.length; i < max; i++) {
/* 43 */       this.exceptionLabels[i].place();
/*    */     }
/*    */   }
/*    */   
/*    */   public void placeEnd() {
/* 48 */     for (int i = 0, max = this.exceptionLabels.length; i < max; i++) {
/* 49 */       this.exceptionLabels[i].placeEnd();
/*    */     }
/*    */   }
/*    */   
/*    */   public void placeStart() {
/* 54 */     for (int i = 0, max = this.exceptionLabels.length; i < max; i++) {
/* 55 */       this.exceptionLabels[i].placeStart();
/*    */     }
/*    */   }
/*    */   
/*    */   public int getCount() {
/* 60 */     int temp = 0;
/* 61 */     for (int i = 0, max = this.exceptionLabels.length; i < max; i++) {
/* 62 */       temp += this.exceptionLabels[i].getCount();
/*    */     }
/* 64 */     return temp;
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\codegen\MultiCatchExceptionLabel.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */