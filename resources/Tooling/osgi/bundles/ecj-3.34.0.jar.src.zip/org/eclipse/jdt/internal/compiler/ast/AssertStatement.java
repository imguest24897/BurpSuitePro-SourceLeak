/*     */ package org.eclipse.jdt.internal.compiler.ast;
/*     */ 
/*     */ import org.eclipse.jdt.internal.compiler.ASTVisitor;
/*     */ import org.eclipse.jdt.internal.compiler.codegen.BranchLabel;
/*     */ import org.eclipse.jdt.internal.compiler.codegen.CodeStream;
/*     */ import org.eclipse.jdt.internal.compiler.flow.FlowContext;
/*     */ import org.eclipse.jdt.internal.compiler.flow.FlowInfo;
/*     */ import org.eclipse.jdt.internal.compiler.flow.UnconditionalFlowInfo;
/*     */ import org.eclipse.jdt.internal.compiler.impl.CompilerOptions;
/*     */ import org.eclipse.jdt.internal.compiler.impl.Constant;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.BlockScope;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.FieldBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.ReferenceBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.Scope;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.SourceTypeBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.TypeBinding;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AssertStatement
/*     */   extends Statement
/*     */ {
/*     */   public Expression assertExpression;
/*     */   public Expression exceptionArgument;
/*  34 */   int preAssertInitStateIndex = -1;
/*     */   private FieldBinding assertionSyntheticFieldBinding;
/*     */   
/*     */   public AssertStatement(Expression exceptionArgument, Expression assertExpression, int startPosition) {
/*  38 */     this.assertExpression = assertExpression;
/*  39 */     this.exceptionArgument = exceptionArgument;
/*  40 */     this.sourceStart = startPosition;
/*  41 */     this.sourceEnd = exceptionArgument.sourceEnd;
/*     */   }
/*     */   
/*     */   public AssertStatement(Expression assertExpression, int startPosition) {
/*  45 */     this.assertExpression = assertExpression;
/*  46 */     this.sourceStart = startPosition;
/*  47 */     this.sourceEnd = assertExpression.sourceEnd;
/*     */   }
/*     */ 
/*     */   
/*     */   public FlowInfo analyseCode(BlockScope currentScope, FlowContext flowContext, FlowInfo flowInfo) {
/*  52 */     this.preAssertInitStateIndex = currentScope.methodScope().recordInitializationStates(flowInfo);
/*     */     
/*  54 */     Constant cst = this.assertExpression.optimizedBooleanConstant();
/*  55 */     this.assertExpression.checkNPEbyUnboxing(currentScope, flowContext, flowInfo);
/*  56 */     boolean isOptimizedTrueAssertion = (cst != Constant.NotAConstant && cst.booleanValue());
/*  57 */     boolean isOptimizedFalseAssertion = (cst != Constant.NotAConstant && !cst.booleanValue());
/*     */     
/*  59 */     flowContext.tagBits |= 0x1000;
/*  60 */     FlowInfo conditionFlowInfo = this.assertExpression.analyseCode(currentScope, flowContext, flowInfo.copy());
/*  61 */     flowContext.extendTimeToLiveForNullCheckedField(1);
/*  62 */     flowContext.tagBits &= 0xFFFFEFFF;
/*  63 */     UnconditionalFlowInfo assertWhenTrueInfo = conditionFlowInfo.initsWhenTrue().unconditionalInits();
/*  64 */     FlowInfo assertInfo = conditionFlowInfo.initsWhenFalse();
/*  65 */     if (isOptimizedTrueAssertion) {
/*  66 */       assertInfo.setReachMode(1);
/*     */     }
/*     */     
/*  69 */     if (this.exceptionArgument != null) {
/*     */       
/*  71 */       FlowInfo exceptionInfo = this.exceptionArgument.analyseCode(currentScope, flowContext, assertInfo.copy());
/*     */       
/*  73 */       if (isOptimizedTrueAssertion) {
/*  74 */         currentScope.problemReporter().fakeReachable(this.exceptionArgument);
/*     */       } else {
/*  76 */         flowContext.checkExceptionHandlers(
/*  77 */             (TypeBinding)currentScope.getJavaLangAssertionError(), 
/*  78 */             this, 
/*  79 */             exceptionInfo, 
/*  80 */             currentScope);
/*     */       } 
/*     */     } 
/*     */     
/*  84 */     if (!isOptimizedTrueAssertion)
/*     */     {
/*  86 */       manageSyntheticAccessIfNecessary(currentScope, flowInfo);
/*     */     }
/*     */     
/*  89 */     flowContext.recordAbruptExit();
/*  90 */     if (isOptimizedFalseAssertion) {
/*  91 */       return flowInfo;
/*     */     }
/*     */ 
/*     */     
/*  95 */     CompilerOptions compilerOptions = currentScope.compilerOptions();
/*  96 */     if (!compilerOptions.includeNullInfoFromAsserts)
/*     */     {
/*     */ 
/*     */       
/* 100 */       return flowInfo.nullInfoLessUnconditionalCopy().mergedWith(assertInfo.nullInfoLessUnconditionalCopy()).addNullInfoFrom(flowInfo);
/*     */     }
/* 102 */     return flowInfo.mergedWith(assertInfo.nullInfoLessUnconditionalCopy())
/* 103 */       .addInitializationsFrom((FlowInfo)assertWhenTrueInfo.discardInitializationInfo());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void generateCode(BlockScope currentScope, CodeStream codeStream) {
/* 111 */     if ((this.bits & Integer.MIN_VALUE) == 0) {
/*     */       return;
/*     */     }
/* 114 */     int pc = codeStream.position;
/*     */     
/* 116 */     if (this.assertionSyntheticFieldBinding != null) {
/* 117 */       BranchLabel assertionActivationLabel = new BranchLabel(codeStream);
/* 118 */       codeStream.fieldAccess((byte)-78, this.assertionSyntheticFieldBinding, null);
/* 119 */       codeStream.ifne(assertionActivationLabel);
/*     */       
/*     */       BranchLabel falseLabel;
/* 122 */       this.assertExpression.generateOptimizedBoolean(currentScope, codeStream, falseLabel = new BranchLabel(codeStream), null, true);
/* 123 */       codeStream.newJavaLangAssertionError();
/* 124 */       codeStream.dup();
/* 125 */       if (this.exceptionArgument != null) {
/* 126 */         this.exceptionArgument.generateCode(currentScope, codeStream, true);
/* 127 */         codeStream.invokeJavaLangAssertionErrorConstructor(this.exceptionArgument.implicitConversion & 0xF);
/*     */       } else {
/* 129 */         codeStream.invokeJavaLangAssertionErrorDefaultConstructor();
/*     */       } 
/* 131 */       codeStream.athrow();
/*     */ 
/*     */       
/* 134 */       if (this.preAssertInitStateIndex != -1) {
/* 135 */         codeStream.removeNotDefinitelyAssignedVariables((Scope)currentScope, this.preAssertInitStateIndex);
/*     */       }
/* 137 */       falseLabel.place();
/* 138 */       assertionActivationLabel.place();
/*     */     
/*     */     }
/* 141 */     else if (this.preAssertInitStateIndex != -1) {
/* 142 */       codeStream.removeNotDefinitelyAssignedVariables((Scope)currentScope, this.preAssertInitStateIndex);
/*     */     } 
/*     */     
/* 145 */     codeStream.recordPositionsFrom(pc, this.sourceStart);
/*     */   }
/*     */ 
/*     */   
/*     */   public void resolve(BlockScope scope) {
/* 150 */     this.assertExpression.resolveTypeExpecting(scope, (TypeBinding)TypeBinding.BOOLEAN);
/* 151 */     if (this.exceptionArgument != null) {
/* 152 */       TypeBinding exceptionArgumentType = this.exceptionArgument.resolveType(scope);
/* 153 */       if (exceptionArgumentType != null) {
/* 154 */         int id = exceptionArgumentType.id;
/* 155 */         switch (id) {
/*     */           case 6:
/* 157 */             scope.problemReporter().illegalVoidExpression(this.exceptionArgument);
/*     */           
/*     */           default:
/* 160 */             id = 1; break;
/*     */           case 2:
/*     */           case 3:
/*     */           case 4:
/*     */           case 5:
/*     */           case 7:
/*     */           case 8:
/*     */           case 9:
/*     */           case 10:
/*     */           case 11:
/*     */             break;
/* 171 */         }  this.exceptionArgument.implicitConversion = (id << 4) + id;
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void traverse(ASTVisitor visitor, BlockScope scope) {
/* 179 */     if (visitor.visit(this, scope)) {
/* 180 */       this.assertExpression.traverse(visitor, scope);
/* 181 */       if (this.exceptionArgument != null) {
/* 182 */         this.exceptionArgument.traverse(visitor, scope);
/*     */       }
/*     */     } 
/* 185 */     visitor.endVisit(this, scope);
/*     */   }
/*     */   
/*     */   public void manageSyntheticAccessIfNecessary(BlockScope currentScope, FlowInfo flowInfo) {
/* 189 */     if ((flowInfo.tagBits & 0x1) == 0) {
/*     */ 
/*     */       
/* 192 */       SourceTypeBinding outerMostClass = currentScope.enclosingSourceType();
/* 193 */       while (outerMostClass.isLocalType()) {
/* 194 */         ReferenceBinding enclosing = outerMostClass.enclosingType();
/* 195 */         if (enclosing == null || enclosing.isInterface())
/* 196 */           break;  outerMostClass = (SourceTypeBinding)enclosing;
/*     */       } 
/* 198 */       this.assertionSyntheticFieldBinding = outerMostClass.addSyntheticFieldForAssert(currentScope);
/*     */ 
/*     */       
/* 201 */       TypeDeclaration typeDeclaration = outerMostClass.scope.referenceType();
/* 202 */       AbstractMethodDeclaration[] methods = typeDeclaration.methods;
/* 203 */       for (int i = 0, max = methods.length; i < max; i++) {
/* 204 */         AbstractMethodDeclaration method = methods[i];
/* 205 */         if (method.isClinit()) {
/* 206 */           ((Clinit)method).setAssertionSupport(this.assertionSyntheticFieldBinding, ((currentScope.compilerOptions()).sourceLevel < 3211264L));
/*     */           break;
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public StringBuffer printStatement(int tab, StringBuffer output) {
/* 215 */     printIndent(tab, output);
/* 216 */     output.append("assert ");
/* 217 */     this.assertExpression.printExpression(0, output);
/* 218 */     if (this.exceptionArgument != null) {
/* 219 */       output.append(": ");
/* 220 */       this.exceptionArgument.printExpression(0, output);
/*     */     } 
/* 222 */     return output.append(';');
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\ast\AssertStatement.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */