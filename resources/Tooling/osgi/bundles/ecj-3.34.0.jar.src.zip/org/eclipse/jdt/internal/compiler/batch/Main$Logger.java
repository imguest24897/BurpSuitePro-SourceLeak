/*      */ package org.eclipse.jdt.internal.compiler.batch;
/*      */ 
/*      */ import java.io.File;
/*      */ import java.io.FileNotFoundException;
/*      */ import java.io.FileOutputStream;
/*      */ import java.io.IOException;
/*      */ import java.io.OutputStreamWriter;
/*      */ import java.io.PrintWriter;
/*      */ import java.io.UnsupportedEncodingException;
/*      */ import java.lang.reflect.Field;
/*      */ import java.text.DateFormat;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Arrays;
/*      */ import java.util.Comparator;
/*      */ import java.util.Date;
/*      */ import java.util.HashMap;
/*      */ import java.util.Locale;
/*      */ import java.util.Map;
/*      */ import java.util.Set;
/*      */ import java.util.StringTokenizer;
/*      */ import org.eclipse.jdt.core.compiler.CategorizedProblem;
/*      */ import org.eclipse.jdt.core.compiler.CharOperation;
/*      */ import org.eclipse.jdt.core.compiler.IProblem;
/*      */ import org.eclipse.jdt.internal.compiler.CompilationResult;
/*      */ import org.eclipse.jdt.internal.compiler.env.ICompilationUnit;
/*      */ import org.eclipse.jdt.internal.compiler.impl.CompilerOptions;
/*      */ import org.eclipse.jdt.internal.compiler.impl.CompilerStats;
/*      */ import org.eclipse.jdt.internal.compiler.problem.DefaultProblem;
/*      */ import org.eclipse.jdt.internal.compiler.problem.ProblemReporter;
/*      */ import org.eclipse.jdt.internal.compiler.util.GenericXMLWriter;
/*      */ import org.eclipse.jdt.internal.compiler.util.HashtableOfInt;
/*      */ import org.eclipse.jdt.internal.compiler.util.Messages;
/*      */ import org.eclipse.jdt.internal.compiler.util.Util;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class Logger
/*      */ {
/*      */   private PrintWriter err;
/*      */   private PrintWriter log;
/*      */   private Main main;
/*      */   private PrintWriter out;
/*      */   int tagBits;
/*      */   private static final String CLASS = "class";
/*      */   private static final String CLASS_FILE = "classfile";
/*      */   private static final String CLASSPATH = "classpath";
/*      */   private static final String CLASSPATH_FILE = "FILE";
/*      */   private static final String CLASSPATH_FOLDER = "FOLDER";
/*      */   private static final String CLASSPATH_ID = "id";
/*      */   private static final String CLASSPATH_JAR = "JAR";
/*      */   private static final String CLASSPATHS = "classpaths";
/*      */   private static final String COMMAND_LINE_ARGUMENT = "argument";
/*      */   private static final String COMMAND_LINE_ARGUMENTS = "command_line";
/*      */   private static final String COMPILER = "compiler";
/*      */   private static final String COMPILER_COPYRIGHT = "copyright";
/*      */   private static final String COMPILER_NAME = "name";
/*      */   private static final String COMPILER_VERSION = "version";
/*      */   public static final int EMACS = 2;
/*      */   private static final String ERROR = "ERROR";
/*      */   private static final String ERROR_TAG = "error";
/*      */   private static final String WARNING_TAG = "warning";
/*      */   private static final String EXCEPTION = "exception";
/*      */   private static final String EXTRA_PROBLEM_TAG = "extra_problem";
/*      */   private static final String EXTRA_PROBLEMS = "extra_problems";
/*  151 */   private static final HashtableOfInt FIELD_TABLE = new HashtableOfInt();
/*      */   
/*      */   private static final String KEY = "key";
/*      */   
/*      */   private static final String MESSAGE = "message";
/*      */   private static final String NUMBER_OF_CLASSFILES = "number_of_classfiles";
/*      */   private static final String NUMBER_OF_ERRORS = "errors";
/*      */   private static final String NUMBER_OF_LINES = "number_of_lines";
/*      */   private static final String NUMBER_OF_PROBLEMS = "problems";
/*      */   private static final String NUMBER_OF_TASKS = "tasks";
/*      */   private static final String NUMBER_OF_WARNINGS = "warnings";
/*      */   private static final String NUMBER_OF_INFOS = "infos";
/*      */   private static final String OPTION = "option";
/*      */   private static final String OPTIONS = "options";
/*      */   private static final String OUTPUT = "output";
/*      */   private static final String PACKAGE = "package";
/*      */   private static final String PATH = "path";
/*      */   private static final String PROBLEM_ARGUMENT = "argument";
/*      */   private static final String PROBLEM_ARGUMENT_VALUE = "value";
/*      */   private static final String PROBLEM_ARGUMENTS = "arguments";
/*      */   private static final String PROBLEM_CATEGORY_ID = "categoryID";
/*      */   private static final String ID = "id";
/*      */   private static final String PROBLEM_ID = "problemID";
/*      */   private static final String PROBLEM_LINE = "line";
/*      */   private static final String PROBLEM_OPTION_KEY = "optionKey";
/*      */   private static final String PROBLEM_MESSAGE = "message";
/*      */   private static final String PROBLEM_SEVERITY = "severity";
/*      */   private static final String PROBLEM_SOURCE_END = "charEnd";
/*      */   private static final String PROBLEM_SOURCE_START = "charStart";
/*      */   private static final String PROBLEM_SUMMARY = "problem_summary";
/*      */   private static final String PROBLEM_TAG = "problem";
/*      */   private static final String PROBLEMS = "problems";
/*      */   private static final String SOURCE = "source";
/*      */   private static final String SOURCE_CONTEXT = "source_context";
/*      */   private static final String SOURCE_END = "sourceEnd";
/*      */   private static final String SOURCE_START = "sourceStart";
/*      */   private static final String SOURCES = "sources";
/*      */   private static final String STATS = "stats";
/*      */   private static final String TASK = "task";
/*      */   private static final String TASKS = "tasks";
/*      */   private static final String TIME = "time";
/*      */   private static final String VALUE = "value";
/*      */   private static final String WARNING = "WARNING";
/*      */   private static final String INFO = "INFO";
/*      */   public static final int XML = 1;
/*      */   private static final String XML_DTD_DECLARATION = "<!DOCTYPE compiler PUBLIC \"-//Eclipse.org//DTD Eclipse JDT 3.2.006 Compiler//EN\" \"https://www.eclipse.org/jdt/core/compiler_32_006.dtd\">";
/*      */   
/*      */   static {
/*      */     try {
/*  200 */       Class<?> c = IProblem.class;
/*  201 */       Field[] fields = c.getFields();
/*  202 */       for (int i = 0, max = fields.length; i < max; i++) {
/*  203 */         Field field = fields[i];
/*  204 */         if (field.getType().equals(int.class)) {
/*  205 */           Integer value = (Integer)field.get(null);
/*  206 */           int key2 = value.intValue() & 0x1FFFFF;
/*  207 */           if (key2 == 0) {
/*  208 */             key2 = Integer.MAX_VALUE;
/*      */           }
/*  210 */           FIELD_TABLE.put(key2, field.getName());
/*      */         } 
/*      */       } 
/*  213 */     } catch (SecurityException|IllegalArgumentException|IllegalAccessException e) {
/*  214 */       e.printStackTrace();
/*      */     } 
/*      */   }
/*      */   public Logger(Main main, PrintWriter out, PrintWriter err) {
/*  218 */     this.out = out;
/*  219 */     this.err = err;
/*  220 */     this.main = main;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public String buildFileName(String outputPath, String relativeFileName) {
/*  226 */     char fileSeparatorChar = File.separatorChar;
/*  227 */     String fileSeparator = File.separator;
/*      */     
/*  229 */     outputPath = outputPath.replace('/', fileSeparatorChar);
/*      */     
/*  231 */     StringBuilder outDir = new StringBuilder(outputPath);
/*  232 */     if (!outputPath.endsWith(fileSeparator)) {
/*  233 */       outDir.append(fileSeparator);
/*      */     }
/*  235 */     StringTokenizer tokenizer = 
/*  236 */       new StringTokenizer(relativeFileName, fileSeparator);
/*  237 */     String token = tokenizer.nextToken();
/*  238 */     while (tokenizer.hasMoreTokens()) {
/*  239 */       outDir.append(token).append(fileSeparator);
/*  240 */       token = tokenizer.nextToken();
/*      */     } 
/*      */     
/*  243 */     return outDir.append(token).toString();
/*      */   }
/*      */   
/*      */   public void close() {
/*  247 */     if (this.log != null) {
/*  248 */       if ((this.tagBits & 0x1) != 0) {
/*  249 */         endTag("compiler");
/*  250 */         flush();
/*      */       } 
/*  252 */       this.log.close();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void compiling() {
/*  260 */     printlnOut(this.main.bind("progress.compiling"));
/*      */   }
/*      */   private void endLoggingExtraProblems() {
/*  263 */     endTag("extra_problems");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void endLoggingProblems() {
/*  270 */     endTag("problems");
/*      */   }
/*      */   public void endLoggingSource() {
/*  273 */     if ((this.tagBits & 0x1) != 0) {
/*  274 */       endTag("source");
/*      */     }
/*      */   }
/*      */   
/*      */   public void endLoggingSources() {
/*  279 */     if ((this.tagBits & 0x1) != 0) {
/*  280 */       endTag("sources");
/*      */     }
/*      */   }
/*      */   
/*      */   public void endLoggingTasks() {
/*  285 */     if ((this.tagBits & 0x1) != 0)
/*  286 */       endTag("tasks"); 
/*      */   }
/*      */   
/*      */   private void endTag(String name) {
/*  290 */     if (this.log != null) {
/*  291 */       ((GenericXMLWriter)this.log).endTag(name, true, true);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private String errorReportSource(CategorizedProblem problem, char[] unitSource, int bits) {
/*  302 */     int startPosition = problem.getSourceStart();
/*  303 */     int endPosition = problem.getSourceEnd();
/*  304 */     if (unitSource == null && 
/*  305 */       problem.getOriginatingFileName() != null) {
/*      */       try {
/*  307 */         unitSource = Util.getFileCharContent(new File(new String(problem.getOriginatingFileName())), null);
/*  308 */       } catch (IOException iOException) {}
/*      */     }
/*      */ 
/*      */     
/*      */     int length;
/*      */     
/*  314 */     if (startPosition > endPosition || (
/*  315 */       startPosition < 0 && endPosition < 0) || 
/*  316 */       unitSource == null || (
/*  317 */       length = unitSource.length) == 0) {
/*  318 */       return Messages.problem_noSourceInformation;
/*      */     }
/*  320 */     StringBuilder errorBuffer = new StringBuilder();
/*  321 */     if ((bits & 0x2) == 0) {
/*  322 */       errorBuffer.append(' ').append(Messages.bind(Messages.problem_atLine, String.valueOf(problem.getSourceLineNumber())));
/*  323 */       errorBuffer.append(Util.LINE_SEPARATOR);
/*      */     } 
/*  325 */     errorBuffer.append('\t');
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     char c;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     int begin;
/*      */ 
/*      */ 
/*      */     
/*  339 */     for (begin = (startPosition >= length) ? (length - 1) : startPosition; begin > 0 && (
/*  340 */       c = unitSource[begin - 1]) != '\n' && c != '\r'; begin--);
/*      */     int end;
/*  342 */     for (end = (endPosition >= length) ? (length - 1) : endPosition; end + 1 < length && (
/*  343 */       c = unitSource[end + 1]) != '\r' && c != '\n'; end++);
/*      */ 
/*      */ 
/*      */     
/*  347 */     for (; (c = unitSource[begin]) == ' ' || c == '\t'; begin++);
/*      */ 
/*      */ 
/*      */     
/*  351 */     errorBuffer.append(unitSource, begin, end - begin + 1);
/*  352 */     errorBuffer.append(Util.LINE_SEPARATOR).append("\t");
/*      */     
/*      */     int i;
/*  355 */     for (i = begin; i < startPosition; i++) {
/*  356 */       errorBuffer.append((unitSource[i] == '\t') ? 9 : 32);
/*      */     }
/*  358 */     for (i = startPosition; i <= ((endPosition >= length) ? (length - 1) : endPosition); i++) {
/*  359 */       errorBuffer.append('^');
/*      */     }
/*  361 */     return errorBuffer.toString();
/*      */   }
/*      */ 
/*      */   
/*      */   private void extractContext(CategorizedProblem problem, char[] unitSource) {
/*  366 */     int startPosition = problem.getSourceStart();
/*  367 */     int endPosition = problem.getSourceEnd();
/*  368 */     if (unitSource == null && 
/*  369 */       problem.getOriginatingFileName() != null) {
/*      */       try {
/*  371 */         unitSource = Util.getFileCharContent(new File(new String(problem.getOriginatingFileName())), null);
/*  372 */       } catch (IOException iOException) {}
/*      */     }
/*      */ 
/*      */     
/*      */     int length;
/*      */     
/*  378 */     if (startPosition > endPosition || (
/*  379 */       startPosition < 0 && endPosition < 0) || 
/*  380 */       unitSource == null || (
/*  381 */       length = unitSource.length) <= 0 || 
/*  382 */       endPosition > length) {
/*  383 */       HashMap<String, Object> hashMap = new HashMap<>();
/*  384 */       hashMap.put("value", Messages.problem_noSourceInformation);
/*  385 */       hashMap.put("sourceStart", "-1");
/*  386 */       hashMap.put("sourceEnd", "-1");
/*  387 */       printTag("source_context", hashMap, true, true);
/*      */ 
/*      */       
/*      */       return;
/*      */     } 
/*      */ 
/*      */     
/*      */     char c;
/*      */ 
/*      */     
/*      */     int begin;
/*      */     
/*  399 */     for (begin = (startPosition >= length) ? (length - 1) : startPosition; begin > 0 && (
/*  400 */       c = unitSource[begin - 1]) != '\n' && c != '\r'; begin--);
/*      */     int end;
/*  402 */     for (end = (endPosition >= length) ? (length - 1) : endPosition; end + 1 < length && (
/*  403 */       c = unitSource[end + 1]) != '\r' && c != '\n'; end++);
/*      */ 
/*      */ 
/*      */     
/*  407 */     for (; (c = unitSource[begin]) == ' ' || c == '\t'; begin++);
/*  408 */     for (; (c = unitSource[end]) == ' ' || c == '\t'; end--);
/*      */ 
/*      */     
/*  411 */     StringBuffer buffer = new StringBuffer();
/*  412 */     buffer.append(unitSource, begin, end - begin + 1);
/*  413 */     HashMap<String, Object> parameters = new HashMap<>();
/*  414 */     parameters.put("value", String.valueOf(buffer));
/*  415 */     parameters.put("sourceStart", Integer.toString(startPosition - begin));
/*  416 */     parameters.put("sourceEnd", Integer.toString(endPosition - begin));
/*  417 */     printTag("source_context", parameters, true, true);
/*      */   }
/*      */   public void flush() {
/*  420 */     this.out.flush();
/*  421 */     this.err.flush();
/*  422 */     if (this.log != null) {
/*  423 */       this.log.flush();
/*      */     }
/*      */   }
/*      */   
/*      */   private String getFieldName(int id) {
/*  428 */     int key2 = id & 0x1FFFFF;
/*  429 */     if (key2 == 0) {
/*  430 */       key2 = Integer.MAX_VALUE;
/*      */     }
/*  432 */     return (String)FIELD_TABLE.get(key2);
/*      */   }
/*      */ 
/*      */   
/*      */   private String getProblemOptionKey(int problemID) {
/*  437 */     int irritant = ProblemReporter.getIrritant(problemID);
/*  438 */     return CompilerOptions.optionKeyFromIrritant(irritant);
/*      */   }
/*      */   
/*      */   public void logAverage() {
/*  442 */     Arrays.sort((Object[])this.main.compilerStats);
/*  443 */     long lineCount = (this.main.compilerStats[0]).lineCount;
/*  444 */     int length = this.main.maxRepetition;
/*  445 */     long sum = 0L;
/*  446 */     long parseSum = 0L, resolveSum = 0L, analyzeSum = 0L, generateSum = 0L;
/*  447 */     for (int i = 1, max = length - 1; i < max; i++) {
/*  448 */       CompilerStats stats = this.main.compilerStats[i];
/*  449 */       sum += stats.elapsedTime();
/*  450 */       parseSum += stats.parseTime;
/*  451 */       resolveSum += stats.resolveTime;
/*  452 */       analyzeSum += stats.analyzeTime;
/*  453 */       generateSum += stats.generateTime;
/*      */     } 
/*  455 */     long time = sum / (length - 2);
/*  456 */     long parseTime = parseSum / (length - 2);
/*  457 */     long resolveTime = resolveSum / (length - 2);
/*  458 */     long analyzeTime = analyzeSum / (length - 2);
/*  459 */     long generateTime = generateSum / (length - 2);
/*  460 */     printlnOut(this.main.bind(
/*  461 */           "compile.averageTime", 
/*  462 */           new String[] {
/*  463 */             String.valueOf(lineCount), 
/*  464 */             String.valueOf(time), 
/*  465 */             String.valueOf((int)(lineCount * 10000.0D / time) / 10.0D)
/*      */           }));
/*  467 */     if ((this.main.timing & 0x2) != 0)
/*  468 */       printlnOut(
/*  469 */           this.main.bind("compile.detailedTime", 
/*  470 */             new String[] {
/*  471 */               String.valueOf(parseTime), 
/*  472 */               String.valueOf((int)(parseTime * 1000.0D / time) / 10.0D), 
/*  473 */               String.valueOf(resolveTime), 
/*  474 */               String.valueOf((int)(resolveTime * 1000.0D / time) / 10.0D), 
/*  475 */               String.valueOf(analyzeTime), 
/*  476 */               String.valueOf((int)(analyzeTime * 1000.0D / time) / 10.0D), 
/*  477 */               String.valueOf(generateTime), 
/*  478 */               String.valueOf((int)(generateTime * 1000.0D / time) / 10.0D)
/*      */             })); 
/*      */   }
/*      */   
/*      */   public void logClassFile(boolean generatePackagesStructure, String outputPath, String relativeFileName) {
/*  483 */     if ((this.tagBits & 0x1) != 0) {
/*  484 */       String fileName = null;
/*  485 */       if (generatePackagesStructure) {
/*  486 */         fileName = buildFileName(outputPath, relativeFileName);
/*      */       } else {
/*  488 */         char fileSeparatorChar = File.separatorChar;
/*  489 */         String fileSeparator = File.separator;
/*      */         
/*  491 */         outputPath = outputPath.replace('/', fileSeparatorChar);
/*      */         
/*  493 */         int indexOfPackageSeparator = relativeFileName.lastIndexOf(fileSeparatorChar);
/*  494 */         if (indexOfPackageSeparator == -1) {
/*  495 */           if (outputPath.endsWith(fileSeparator)) {
/*  496 */             fileName = String.valueOf(outputPath) + relativeFileName;
/*      */           } else {
/*  498 */             fileName = String.valueOf(outputPath) + fileSeparator + relativeFileName;
/*      */           } 
/*      */         } else {
/*  501 */           int length = relativeFileName.length();
/*  502 */           if (outputPath.endsWith(fileSeparator)) {
/*  503 */             fileName = String.valueOf(outputPath) + relativeFileName.substring(indexOfPackageSeparator + 1, length);
/*      */           } else {
/*  505 */             fileName = String.valueOf(outputPath) + fileSeparator + relativeFileName.substring(indexOfPackageSeparator + 1, length);
/*      */           } 
/*      */         } 
/*      */       } 
/*  509 */       File f = new File(fileName);
/*      */       try {
/*  511 */         HashMap<String, Object> parameters = new HashMap<>();
/*  512 */         parameters.put("path", f.getCanonicalPath());
/*  513 */         printTag("classfile", parameters, true, true);
/*  514 */       } catch (IOException e) {
/*  515 */         logNoClassFileCreated(outputPath, relativeFileName, e);
/*      */       } 
/*      */     } 
/*      */   }
/*      */   public void logClasspath(FileSystem.Classpath[] classpaths) {
/*  520 */     if (classpaths == null)
/*  521 */       return;  if ((this.tagBits & 0x1) != 0) {
/*  522 */       int length = classpaths.length;
/*  523 */       if (length != 0) {
/*      */         
/*  525 */         printTag("classpaths", new HashMap<>(), true, false);
/*  526 */         HashMap<String, Object> parameters = new HashMap<>();
/*  527 */         for (int i = 0; i < length; i++) {
/*  528 */           String classpath = classpaths[i].getPath();
/*  529 */           parameters.put("path", classpath);
/*  530 */           File f = new File(classpath);
/*  531 */           String id = null;
/*  532 */           if (f.isFile()) {
/*  533 */             int kind = Util.archiveFormat(classpath);
/*  534 */             switch (kind) {
/*      */               case 0:
/*  536 */                 id = "JAR";
/*      */                 break;
/*      */               default:
/*  539 */                 id = "FILE";
/*      */                 break;
/*      */             } 
/*  542 */           } else if (f.isDirectory()) {
/*  543 */             id = "FOLDER";
/*      */           } 
/*  545 */           if (id != null) {
/*  546 */             parameters.put("id", id);
/*  547 */             printTag("classpath", parameters, true, true);
/*      */           } 
/*      */         } 
/*  550 */         endTag("classpaths");
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public void logCommandLineArguments(String[] commandLineArguments) {
/*  557 */     if (commandLineArguments == null)
/*  558 */       return;  if ((this.tagBits & 0x1) != 0) {
/*  559 */       int length = commandLineArguments.length;
/*  560 */       if (length != 0) {
/*      */         
/*  562 */         printTag("command_line", new HashMap<>(), true, false);
/*  563 */         for (int i = 0; i < length; i++) {
/*  564 */           HashMap<String, Object> parameters = new HashMap<>();
/*  565 */           parameters.put("value", commandLineArguments[i]);
/*  566 */           printTag("argument", parameters, true, true);
/*      */         } 
/*  568 */         endTag("command_line");
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void logException(Exception e) {
/*      */     // Byte code:
/*      */     //   0: new java/io/StringWriter
/*      */     //   3: dup
/*      */     //   4: invokespecial <init> : ()V
/*      */     //   7: astore_2
/*      */     //   8: new java/io/PrintWriter
/*      */     //   11: dup
/*      */     //   12: aload_2
/*      */     //   13: invokespecial <init> : (Ljava/io/Writer;)V
/*      */     //   16: astore_3
/*      */     //   17: aload_1
/*      */     //   18: aload_3
/*      */     //   19: invokevirtual printStackTrace : (Ljava/io/PrintWriter;)V
/*      */     //   22: aload_3
/*      */     //   23: invokevirtual flush : ()V
/*      */     //   26: aload_3
/*      */     //   27: invokevirtual close : ()V
/*      */     //   30: aload_2
/*      */     //   31: invokevirtual toString : ()Ljava/lang/String;
/*      */     //   34: astore #4
/*      */     //   36: aload_0
/*      */     //   37: getfield tagBits : I
/*      */     //   40: iconst_1
/*      */     //   41: iand
/*      */     //   42: ifeq -> 194
/*      */     //   45: new java/io/LineNumberReader
/*      */     //   48: dup
/*      */     //   49: new java/io/StringReader
/*      */     //   52: dup
/*      */     //   53: aload #4
/*      */     //   55: invokespecial <init> : (Ljava/lang/String;)V
/*      */     //   58: invokespecial <init> : (Ljava/io/Reader;)V
/*      */     //   61: astore #5
/*      */     //   63: iconst_0
/*      */     //   64: istore #7
/*      */     //   66: new java/lang/StringBuilder
/*      */     //   69: dup
/*      */     //   70: invokespecial <init> : ()V
/*      */     //   73: astore #8
/*      */     //   75: aload_1
/*      */     //   76: invokevirtual getMessage : ()Ljava/lang/String;
/*      */     //   79: astore #9
/*      */     //   81: aload #9
/*      */     //   83: ifnull -> 120
/*      */     //   86: aload #8
/*      */     //   88: aload #9
/*      */     //   90: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
/*      */     //   93: getstatic org/eclipse/jdt/internal/compiler/util/Util.LINE_SEPARATOR : Ljava/lang/String;
/*      */     //   96: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
/*      */     //   99: pop
/*      */     //   100: goto -> 120
/*      */     //   103: aload #8
/*      */     //   105: aload #6
/*      */     //   107: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
/*      */     //   110: getstatic org/eclipse/jdt/internal/compiler/util/Util.LINE_SEPARATOR : Ljava/lang/String;
/*      */     //   113: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
/*      */     //   116: pop
/*      */     //   117: iinc #7, 1
/*      */     //   120: aload #5
/*      */     //   122: invokevirtual readLine : ()Ljava/lang/String;
/*      */     //   125: dup
/*      */     //   126: astore #6
/*      */     //   128: ifnull -> 137
/*      */     //   131: iload #7
/*      */     //   133: iconst_4
/*      */     //   134: if_icmplt -> 103
/*      */     //   137: aload #5
/*      */     //   139: invokevirtual close : ()V
/*      */     //   142: goto -> 146
/*      */     //   145: pop
/*      */     //   146: aload #8
/*      */     //   148: invokevirtual toString : ()Ljava/lang/String;
/*      */     //   151: astore #9
/*      */     //   153: new java/util/HashMap
/*      */     //   156: dup
/*      */     //   157: invokespecial <init> : ()V
/*      */     //   160: astore #10
/*      */     //   162: aload #10
/*      */     //   164: ldc 'message'
/*      */     //   166: aload #9
/*      */     //   168: invokevirtual put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
/*      */     //   171: pop
/*      */     //   172: aload #10
/*      */     //   174: ldc 'class'
/*      */     //   176: aload_1
/*      */     //   177: invokevirtual getClass : ()Ljava/lang/Class;
/*      */     //   180: invokevirtual put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
/*      */     //   183: pop
/*      */     //   184: aload_0
/*      */     //   185: ldc 'exception'
/*      */     //   187: aload #10
/*      */     //   189: iconst_1
/*      */     //   190: iconst_1
/*      */     //   191: invokevirtual printTag : (Ljava/lang/String;Ljava/util/HashMap;ZZ)V
/*      */     //   194: aload_1
/*      */     //   195: invokevirtual getMessage : ()Ljava/lang/String;
/*      */     //   198: astore #5
/*      */     //   200: aload #5
/*      */     //   202: ifnonnull -> 214
/*      */     //   205: aload_0
/*      */     //   206: aload #4
/*      */     //   208: invokevirtual printlnErr : (Ljava/lang/String;)V
/*      */     //   211: goto -> 220
/*      */     //   214: aload_0
/*      */     //   215: aload #5
/*      */     //   217: invokevirtual printlnErr : (Ljava/lang/String;)V
/*      */     //   220: return
/*      */     // Line number table:
/*      */     //   Java source line number -> byte code offset
/*      */     //   #577	-> 0
/*      */     //   #578	-> 8
/*      */     //   #579	-> 17
/*      */     //   #580	-> 22
/*      */     //   #581	-> 26
/*      */     //   #582	-> 30
/*      */     //   #583	-> 36
/*      */     //   #584	-> 45
/*      */     //   #586	-> 63
/*      */     //   #587	-> 66
/*      */     //   #588	-> 75
/*      */     //   #589	-> 81
/*      */     //   #590	-> 86
/*      */     //   #593	-> 100
/*      */     //   #594	-> 103
/*      */     //   #595	-> 117
/*      */     //   #593	-> 120
/*      */     //   #597	-> 137
/*      */     //   #598	-> 142
/*      */     //   #601	-> 146
/*      */     //   #602	-> 153
/*      */     //   #603	-> 162
/*      */     //   #604	-> 172
/*      */     //   #605	-> 184
/*      */     //   #607	-> 194
/*      */     //   #608	-> 200
/*      */     //   #609	-> 205
/*      */     //   #610	-> 211
/*      */     //   #611	-> 214
/*      */     //   #613	-> 220
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	descriptor
/*      */     //   0	221	0	this	Lorg/eclipse/jdt/internal/compiler/batch/Main$Logger;
/*      */     //   0	221	1	e	Ljava/lang/Exception;
/*      */     //   8	213	2	writer	Ljava/io/StringWriter;
/*      */     //   17	204	3	printWriter	Ljava/io/PrintWriter;
/*      */     //   36	185	4	stackTrace	Ljava/lang/String;
/*      */     //   63	131	5	reader	Ljava/io/LineNumberReader;
/*      */     //   103	17	6	line	Ljava/lang/String;
/*      */     //   128	17	6	line	Ljava/lang/String;
/*      */     //   66	128	7	i	I
/*      */     //   75	119	8	buffer	Ljava/lang/StringBuilder;
/*      */     //   81	113	9	message	Ljava/lang/String;
/*      */     //   162	32	10	parameters	Ljava/util/HashMap;
/*      */     //   200	21	5	message	Ljava/lang/String;
/*      */     // Local variable type table:
/*      */     //   start	length	slot	name	signature
/*      */     //   162	32	10	parameters	Ljava/util/HashMap<Ljava/lang/String;Ljava/lang/Object;>;
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   100	142	145	java/io/IOException
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void logExtraProblem(CategorizedProblem problem, int localErrorCount, int globalErrorCount) {
/*  616 */     char[] originatingFileName = problem.getOriginatingFileName();
/*  617 */     if (originatingFileName == null) {
/*      */       
/*  619 */       String severity = problem.isError() ? "requestor.extraerror" : (
/*  620 */         problem.isInfo() ? "requestor.extrainfo" : "requestor.extrawarning");
/*  621 */       printErr(this.main.bind(
/*  622 */             severity, 
/*  623 */             Integer.toString(globalErrorCount)));
/*  624 */       printErr(" ");
/*  625 */       printlnErr(problem.getMessage());
/*      */     } else {
/*  627 */       String fileName = new String(originatingFileName);
/*  628 */       if ((this.tagBits & 0x2) != 0) {
/*  629 */         String severity = problem.isError() ? "output.emacs.error" : (
/*  630 */           problem.isInfo() ? "output.emacs.info" : 
/*  631 */           "output.emacs.warning");
/*  632 */         String result = String.valueOf(fileName) + 
/*  633 */           ":" + 
/*  634 */           problem.getSourceLineNumber() + 
/*  635 */           ": " + 
/*  636 */           this.main.bind(severity) + 
/*  637 */           ": " + 
/*  638 */           problem.getMessage();
/*  639 */         printlnErr(result);
/*  640 */         String errorReportSource = errorReportSource(problem, null, this.tagBits);
/*  641 */         printlnErr(errorReportSource);
/*      */       } else {
/*  643 */         if (localErrorCount == 0) {
/*  644 */           printlnErr("----------");
/*      */         }
/*  646 */         String severity = problem.isError() ? "requestor.error" : (
/*  647 */           problem.isInfo() ? "requestor.info" : "requestor.warning");
/*  648 */         printErr(this.main.bind(
/*  649 */               severity, 
/*  650 */               Integer.toString(globalErrorCount), 
/*  651 */               fileName));
/*  652 */         String errorReportSource = errorReportSource(problem, null, 0);
/*  653 */         printlnErr(errorReportSource);
/*  654 */         printlnErr(problem.getMessage());
/*  655 */         printlnErr("----------");
/*      */       } 
/*      */     } 
/*      */   }
/*      */   
/*      */   public void loggingExtraProblems(Main currentMain) {
/*  661 */     ArrayList<CategorizedProblem> problems = currentMain.extraProblems;
/*  662 */     int count = problems.size();
/*  663 */     int localProblemCount = 0;
/*  664 */     if (count != 0) {
/*  665 */       int errors = 0;
/*  666 */       int warnings = 0;
/*  667 */       int infos = 0; int i;
/*  668 */       for (i = 0; i < count; i++) {
/*  669 */         CategorizedProblem problem = problems.get(i);
/*  670 */         if (!this.main.isIgnored((IProblem)problem)) {
/*  671 */           currentMain.globalProblemsCount++;
/*  672 */           logExtraProblem(problem, localProblemCount, currentMain.globalProblemsCount);
/*  673 */           localProblemCount++;
/*  674 */           if (problem.isError()) {
/*  675 */             errors++;
/*  676 */             currentMain.globalErrorsCount++;
/*  677 */           } else if (problem.isInfo()) {
/*  678 */             currentMain.globalInfoCount++;
/*  679 */             infos++;
/*      */           } else {
/*  681 */             currentMain.globalWarningsCount++;
/*  682 */             warnings++;
/*      */           } 
/*      */         } 
/*      */       } 
/*  686 */       if ((this.tagBits & 0x1) != 0 && 
/*  687 */         errors + warnings + infos != 0) {
/*  688 */         startLoggingExtraProblems(count);
/*  689 */         for (i = 0; i < count; i++) {
/*  690 */           CategorizedProblem problem = problems.get(i);
/*  691 */           if (!this.main.isIgnored((IProblem)problem) && 
/*  692 */             problem.getID() != 536871362) {
/*  693 */             logXmlExtraProblem(problem, localProblemCount, currentMain.globalProblemsCount);
/*      */           }
/*      */         } 
/*      */         
/*  697 */         endLoggingExtraProblems();
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public void logUnavaibleAPT(String className) {
/*  704 */     if ((this.tagBits & 0x1) != 0) {
/*  705 */       HashMap<String, Object> parameters = new HashMap<>();
/*  706 */       parameters.put("message", this.main.bind("configure.unavailableAPT", className));
/*  707 */       printTag("error", parameters, true, true);
/*      */     } 
/*  709 */     printlnErr(this.main.bind("configure.unavailableAPT", className));
/*      */   }
/*      */   
/*      */   public void logIncorrectVMVersionForAnnotationProcessing() {
/*  713 */     if ((this.tagBits & 0x1) != 0) {
/*  714 */       HashMap<String, Object> parameters = new HashMap<>();
/*  715 */       parameters.put("message", this.main.bind("configure.incorrectVMVersionforAPT"));
/*  716 */       printTag("error", parameters, true, true);
/*      */     } 
/*  718 */     printlnErr(this.main.bind("configure.incorrectVMVersionforAPT"));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void logNoClassFileCreated(String outputDir, String relativeFileName, IOException e) {
/*  725 */     if ((this.tagBits & 0x1) != 0) {
/*  726 */       HashMap<String, Object> parameters = new HashMap<>();
/*  727 */       parameters.put("message", this.main.bind("output.noClassFileCreated", 
/*  728 */             new String[] {
/*  729 */               outputDir, 
/*  730 */               relativeFileName, 
/*  731 */               e.getMessage()
/*      */             }));
/*  733 */       printTag("error", parameters, true, true);
/*      */     } 
/*  735 */     printlnErr(this.main.bind("output.noClassFileCreated", 
/*  736 */           new String[] {
/*  737 */             outputDir, 
/*  738 */             relativeFileName, 
/*  739 */             e.getMessage()
/*      */           }));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void logNumberOfClassFilesGenerated(int exportedClassFilesCounter) {
/*  747 */     if ((this.tagBits & 0x1) != 0) {
/*  748 */       HashMap<String, Object> parameters = new HashMap<>();
/*  749 */       parameters.put("value", Integer.valueOf(exportedClassFilesCounter));
/*  750 */       printTag("number_of_classfiles", parameters, true, true);
/*      */     } 
/*  752 */     if (exportedClassFilesCounter == 1) {
/*  753 */       printlnOut(this.main.bind("compile.oneClassFileGenerated"));
/*      */     } else {
/*  755 */       printlnOut(this.main.bind("compile.severalClassFilesGenerated", 
/*  756 */             String.valueOf(exportedClassFilesCounter)));
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void logOptions(Map<String, String> options) {
/*  764 */     if ((this.tagBits & 0x1) != 0) {
/*  765 */       printTag("options", new HashMap<>(), true, false);
/*  766 */       Set<Map.Entry<String, String>> entriesSet = options.entrySet();
/*  767 */       Map.Entry[] entries = entriesSet.<Map.Entry>toArray(new Map.Entry[entriesSet.size()]);
/*  768 */       Arrays.sort(entries, (Comparator)new Comparator<Map.Entry<String, String>>()
/*      */           {
/*      */             public int compare(Map.Entry<String, String> o1, Map.Entry<String, String> o2) {
/*  771 */               Map.Entry<String, String> entry1 = o1;
/*  772 */               Map.Entry<String, String> entry2 = o2;
/*  773 */               return ((String)entry1.getKey()).compareTo(entry2.getKey());
/*      */             }
/*      */           });
/*  776 */       HashMap<String, Object> parameters = new HashMap<>();
/*  777 */       for (int i = 0, max = entries.length; i < max; i++) {
/*  778 */         Map.Entry<String, String> entry = entries[i];
/*  779 */         String key = entry.getKey();
/*  780 */         parameters.put("key", key);
/*  781 */         parameters.put("value", entry.getValue());
/*  782 */         printTag("option", parameters, true, true);
/*      */       } 
/*  784 */       endTag("options");
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void logPendingError(String error) {
/*  792 */     if ((this.tagBits & 0x1) != 0) {
/*  793 */       HashMap<String, Object> parameters = new HashMap<>();
/*  794 */       parameters.put("message", error);
/*  795 */       printTag("error", parameters, true, true);
/*      */     } 
/*  797 */     printlnErr(error);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void logWarning(String message) {
/*  804 */     if ((this.tagBits & 0x1) != 0) {
/*  805 */       HashMap<String, Object> parameters = new HashMap<>();
/*  806 */       parameters.put("message", message);
/*  807 */       printTag("warning", parameters, true, true);
/*      */     } 
/*  809 */     printlnOut(message);
/*      */   }
/*      */ 
/*      */   
/*      */   private void logProblem(CategorizedProblem problem, int localErrorCount, int globalErrorCount, char[] unitSource) {
/*  814 */     if (problem instanceof DefaultProblem) {
/*  815 */       ((DefaultProblem)problem).reportError();
/*      */     }
/*  817 */     if ((this.tagBits & 0x2) != 0) {
/*  818 */       String severity = problem.isError() ? "output.emacs.error" : (
/*  819 */         problem.isInfo() ? "output.emacs.info" : 
/*  820 */         "output.emacs.warning");
/*  821 */       String result = String.valueOf(new String(problem.getOriginatingFileName())) + 
/*  822 */         ":" + 
/*  823 */         problem.getSourceLineNumber() + 
/*  824 */         ": " + 
/*  825 */         this.main.bind(severity) + 
/*  826 */         ": " + 
/*  827 */         problem.getMessage();
/*  828 */       printlnErr(result);
/*  829 */       String errorReportSource = errorReportSource(problem, unitSource, this.tagBits);
/*  830 */       if (errorReportSource.length() != 0) printlnErr(errorReportSource); 
/*      */     } else {
/*  832 */       if (localErrorCount == 0) {
/*  833 */         printlnErr("----------");
/*      */       }
/*  835 */       String severity = problem.isError() ? "requestor.error" : (problem.isInfo() ? "requestor.info" : "requestor.warning");
/*  836 */       printErr(this.main.bind(severity, 
/*  837 */             Integer.toString(globalErrorCount), 
/*  838 */             new String(problem.getOriginatingFileName())));
/*      */       try {
/*  840 */         String errorReportSource = errorReportSource(problem, unitSource, 0);
/*  841 */         printlnErr(errorReportSource);
/*  842 */         printlnErr(problem.getMessage());
/*  843 */       } catch (Exception exception) {
/*  844 */         printlnErr(this.main.bind(
/*  845 */               "requestor.notRetrieveErrorMessage", problem.toString()));
/*      */       } 
/*  847 */       printlnErr("----------");
/*      */     } 
/*      */   }
/*      */   
/*      */   public int logProblems(CategorizedProblem[] problems, char[] unitSource, Main currentMain) {
/*  852 */     int count = problems.length;
/*  853 */     int localErrorCount = 0;
/*  854 */     int localProblemCount = 0;
/*  855 */     if (count != 0) {
/*  856 */       int errors = 0;
/*  857 */       int warnings = 0;
/*  858 */       int infos = 0;
/*  859 */       int tasks = 0; int i;
/*  860 */       for (i = 0; i < count; i++) {
/*  861 */         CategorizedProblem problem = problems[i];
/*  862 */         if (problem != null) {
/*  863 */           currentMain.globalProblemsCount++;
/*  864 */           logProblem(problem, localProblemCount, currentMain.globalProblemsCount, unitSource);
/*  865 */           localProblemCount++;
/*  866 */           if (problem.isError()) {
/*  867 */             localErrorCount++;
/*  868 */             errors++;
/*  869 */             currentMain.globalErrorsCount++;
/*  870 */           } else if (problem.getID() == 536871362) {
/*  871 */             currentMain.globalTasksCount++;
/*  872 */             tasks++;
/*  873 */           } else if (problem.isInfo()) {
/*  874 */             currentMain.globalInfoCount++;
/*  875 */             infos++;
/*      */           } else {
/*  877 */             currentMain.globalWarningsCount++;
/*  878 */             warnings++;
/*      */           } 
/*      */         } 
/*      */       } 
/*  882 */       if ((this.tagBits & 0x1) != 0) {
/*  883 */         if (errors + warnings + infos != 0) {
/*  884 */           startLoggingProblems(errors, warnings, infos);
/*  885 */           for (i = 0; i < count; i++) {
/*  886 */             CategorizedProblem problem = problems[i];
/*  887 */             if (problem != null && 
/*  888 */               problem.getID() != 536871362) {
/*  889 */               logXmlProblem(problem, unitSource);
/*      */             }
/*      */           } 
/*      */           
/*  893 */           endLoggingProblems();
/*      */         } 
/*  895 */         if (tasks != 0) {
/*  896 */           startLoggingTasks(tasks);
/*  897 */           for (i = 0; i < count; i++) {
/*  898 */             CategorizedProblem problem = problems[i];
/*  899 */             if (problem != null && 
/*  900 */               problem.getID() == 536871362) {
/*  901 */               logXmlTask(problem, unitSource);
/*      */             }
/*      */           } 
/*      */           
/*  905 */           endLoggingTasks();
/*      */         } 
/*      */       } 
/*      */     } 
/*  909 */     return localErrorCount;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void logProblemsSummary(int globalProblemsCount, int globalErrorsCount, int globalWarningsCount, int globalInfoCount, int globalTasksCount) {
/*  919 */     if ((this.tagBits & 0x1) != 0) {
/*      */       
/*  921 */       HashMap<String, Object> parameters = new HashMap<>();
/*  922 */       parameters.put("problems", Integer.valueOf(globalProblemsCount));
/*  923 */       parameters.put("errors", Integer.valueOf(globalErrorsCount));
/*  924 */       parameters.put("warnings", Integer.valueOf(globalWarningsCount));
/*  925 */       parameters.put("infos", Integer.valueOf(globalInfoCount));
/*  926 */       parameters.put("tasks", Integer.valueOf(globalTasksCount));
/*  927 */       printTag("problem_summary", parameters, true, true);
/*      */     } 
/*  929 */     if (globalProblemsCount == 1) {
/*  930 */       String message = null;
/*  931 */       if (globalErrorsCount == 1) {
/*  932 */         message = this.main.bind("compile.oneError");
/*  933 */       } else if (globalInfoCount == 1) {
/*  934 */         message = this.main.bind("compile.oneInfo");
/*      */       } else {
/*  936 */         message = this.main.bind("compile.oneWarning");
/*      */       } 
/*  938 */       printErr(this.main.bind("compile.oneProblem", message));
/*      */     } else {
/*  940 */       String errorMessage = null;
/*  941 */       String warningMessage = null;
/*  942 */       String infoMessage = null;
/*  943 */       if (globalErrorsCount > 0) {
/*  944 */         if (globalErrorsCount == 1) {
/*  945 */           errorMessage = this.main.bind("compile.oneError");
/*      */         } else {
/*  947 */           errorMessage = this.main.bind("compile.severalErrors", String.valueOf(globalErrorsCount));
/*      */         } 
/*      */       }
/*  950 */       int warningsNumber = globalWarningsCount + globalTasksCount;
/*  951 */       if (warningsNumber > 0) {
/*  952 */         if (warningsNumber == 1) {
/*  953 */           warningMessage = this.main.bind("compile.oneWarning");
/*      */         } else {
/*  955 */           warningMessage = this.main.bind("compile.severalWarnings", String.valueOf(warningsNumber));
/*      */         } 
/*      */       }
/*  958 */       if (globalInfoCount == 1) {
/*  959 */         infoMessage = this.main.bind("compile.oneInfo");
/*  960 */       } else if (globalInfoCount > 1) {
/*  961 */         infoMessage = this.main.bind("compile.severalInfos", String.valueOf(globalInfoCount));
/*      */       } 
/*  963 */       if (globalProblemsCount == globalInfoCount || globalProblemsCount == globalErrorsCount || globalProblemsCount == globalWarningsCount) {
/*  964 */         String msg = (errorMessage != null) ? errorMessage : ((warningMessage != null) ? warningMessage : infoMessage);
/*  965 */         printErr(this.main.bind(
/*  966 */               "compile.severalProblemsErrorsOrWarnings", 
/*  967 */               String.valueOf(globalProblemsCount), 
/*  968 */               msg));
/*      */       }
/*  970 */       else if (globalInfoCount == 0) {
/*  971 */         printErr(this.main.bind(
/*  972 */               "compile.severalProblemsErrorsAndWarnings", 
/*  973 */               new String[] {
/*  974 */                 String.valueOf(globalProblemsCount), 
/*  975 */                 errorMessage, 
/*  976 */                 warningMessage
/*      */               }));
/*      */       } else {
/*  979 */         if (errorMessage == null) {
/*  980 */           errorMessage = this.main.bind("compile.severalErrors", String.valueOf(globalErrorsCount));
/*      */         }
/*  982 */         if (warningMessage == null) {
/*  983 */           warningMessage = this.main.bind("compile.severalWarnings", String.valueOf(warningsNumber));
/*      */         }
/*  985 */         printErr(this.main.bind(
/*  986 */               "compile.severalProblems", 
/*  987 */               new String[] {
/*  988 */                 String.valueOf(globalProblemsCount), 
/*  989 */                 errorMessage, 
/*  990 */                 warningMessage, 
/*  991 */                 infoMessage
/*      */               }));
/*      */       } 
/*      */     } 
/*      */     
/*  996 */     if (this.main.failOnWarning && globalWarningsCount > 0) {
/*  997 */       printErr("\n");
/*  998 */       printErr(this.main.bind("compile.failOnWarning"));
/*      */     } 
/* 1000 */     if ((this.tagBits & 0x1) == 0) {
/* 1001 */       printlnErr();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void logProgress() {
/* 1009 */     printOut('.');
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void logRepetition(int i, int repetitions) {
/* 1019 */     printlnOut(this.main.bind("compile.repetition", 
/* 1020 */           String.valueOf(i + 1), String.valueOf(repetitions)));
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void logTiming(CompilerStats compilerStats) {
/* 1026 */     long time = compilerStats.elapsedTime();
/* 1027 */     long lineCount = compilerStats.lineCount;
/* 1028 */     if ((this.tagBits & 0x1) != 0) {
/* 1029 */       HashMap<String, Object> parameters = new HashMap<>();
/* 1030 */       parameters.put("value", Long.valueOf(time));
/* 1031 */       printTag("time", parameters, true, true);
/* 1032 */       parameters.put("value", Long.valueOf(lineCount));
/* 1033 */       printTag("number_of_lines", parameters, true, true);
/*      */     } 
/* 1035 */     if (lineCount != 0L) {
/* 1036 */       printlnOut(
/* 1037 */           this.main.bind("compile.instantTime", 
/* 1038 */             new String[] {
/* 1039 */               String.valueOf(lineCount), 
/* 1040 */               String.valueOf(time), 
/* 1041 */               String.valueOf((int)(lineCount * 10000.0D / time) / 10.0D)
/*      */             }));
/*      */     } else {
/* 1044 */       printlnOut(
/* 1045 */           this.main.bind("compile.totalTime", 
/* 1046 */             new String[] {
/* 1047 */               String.valueOf(time)
/*      */             }));
/*      */     } 
/* 1050 */     if ((this.main.timing & 0x2) != 0) {
/* 1051 */       printlnOut(
/* 1052 */           this.main.bind("compile.detailedTime", 
/* 1053 */             new String[] {
/* 1054 */               String.valueOf(compilerStats.parseTime), 
/* 1055 */               String.valueOf((int)(compilerStats.parseTime * 1000.0D / time) / 10.0D), 
/* 1056 */               String.valueOf(compilerStats.resolveTime), 
/* 1057 */               String.valueOf((int)(compilerStats.resolveTime * 1000.0D / time) / 10.0D), 
/* 1058 */               String.valueOf(compilerStats.analyzeTime), 
/* 1059 */               String.valueOf((int)(compilerStats.analyzeTime * 1000.0D / time) / 10.0D), 
/* 1060 */               String.valueOf(compilerStats.generateTime), 
/* 1061 */               String.valueOf((int)(compilerStats.generateTime * 1000.0D / time) / 10.0D)
/*      */             }));
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void logUsage(String usage) {
/* 1071 */     printlnOut(usage);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void logVersion(boolean printToOut) {
/* 1078 */     if (this.log != null && (this.tagBits & 0x1) == 0) {
/* 1079 */       String version = this.main.bind("misc.version", 
/* 1080 */           new String[] {
/* 1081 */             this.main.bind("compiler.name"), 
/* 1082 */             this.main.bind("compiler.version"), 
/* 1083 */             this.main.bind("compiler.copyright")
/*      */           });
/*      */       
/* 1086 */       this.log.println("# " + version);
/* 1087 */       if (printToOut) {
/* 1088 */         this.out.println(version);
/* 1089 */         this.out.flush();
/*      */       } 
/* 1091 */     } else if (printToOut) {
/* 1092 */       String version = this.main.bind("misc.version", 
/* 1093 */           new String[] {
/* 1094 */             this.main.bind("compiler.name"), 
/* 1095 */             this.main.bind("compiler.version"), 
/* 1096 */             this.main.bind("compiler.copyright")
/*      */           });
/*      */       
/* 1099 */       this.out.println(version);
/* 1100 */       this.out.flush();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void logWrongJDK() {
/* 1108 */     if ((this.tagBits & 0x1) != 0) {
/* 1109 */       HashMap<String, Object> parameters = new HashMap<>();
/* 1110 */       parameters.put("message", this.main.bind("configure.requiresJDK1.2orAbove"));
/* 1111 */       printTag("ERROR", parameters, true, true);
/*      */     } 
/* 1113 */     printlnErr(this.main.bind("configure.requiresJDK1.2orAbove"));
/*      */   }
/*      */   
/*      */   private void logXmlExtraProblem(CategorizedProblem problem, int globalErrorCount, int localErrorCount) {
/* 1117 */     int sourceStart = problem.getSourceStart();
/* 1118 */     int sourceEnd = problem.getSourceEnd();
/* 1119 */     boolean isError = problem.isError();
/* 1120 */     HashMap<String, Object> parameters = new HashMap<>();
/* 1121 */     parameters.put("severity", isError ? "ERROR" : (problem.isInfo() ? "INFO" : "WARNING"));
/* 1122 */     parameters.put("line", Integer.valueOf(problem.getSourceLineNumber()));
/* 1123 */     parameters.put("charStart", Integer.valueOf(sourceStart));
/* 1124 */     parameters.put("charEnd", Integer.valueOf(sourceEnd));
/* 1125 */     printTag("extra_problem", parameters, true, false);
/* 1126 */     parameters.put("value", problem.getMessage());
/* 1127 */     printTag("message", parameters, true, true);
/* 1128 */     extractContext(problem, null);
/* 1129 */     endTag("extra_problem");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void logXmlProblem(CategorizedProblem problem, char[] unitSource) {
/* 1138 */     int sourceStart = problem.getSourceStart();
/* 1139 */     int sourceEnd = problem.getSourceEnd();
/* 1140 */     int id = problem.getID();
/* 1141 */     HashMap<String, Object> parameters = new HashMap<>();
/* 1142 */     parameters.put("id", getFieldName(id));
/* 1143 */     parameters.put("problemID", Integer.valueOf(id));
/* 1144 */     boolean isError = problem.isError();
/* 1145 */     int severity = isError ? 1 : 0;
/* 1146 */     parameters.put("severity", isError ? "ERROR" : (problem.isInfo() ? "INFO" : "WARNING"));
/* 1147 */     parameters.put("line", Integer.valueOf(problem.getSourceLineNumber()));
/* 1148 */     parameters.put("charStart", Integer.valueOf(sourceStart));
/* 1149 */     parameters.put("charEnd", Integer.valueOf(sourceEnd));
/* 1150 */     String problemOptionKey = getProblemOptionKey(id);
/* 1151 */     if (problemOptionKey != null) {
/* 1152 */       parameters.put("optionKey", problemOptionKey);
/*      */     }
/* 1154 */     int categoryID = ProblemReporter.getProblemCategory(severity, id);
/* 1155 */     parameters.put("categoryID", Integer.valueOf(categoryID));
/* 1156 */     printTag("problem", parameters, true, false);
/* 1157 */     parameters.put("value", problem.getMessage());
/* 1158 */     printTag("message", parameters, true, true);
/* 1159 */     extractContext(problem, unitSource);
/* 1160 */     String[] arguments = problem.getArguments();
/* 1161 */     int length = arguments.length;
/* 1162 */     if (length != 0) {
/* 1163 */       parameters = new HashMap<>();
/* 1164 */       printTag("arguments", parameters, true, false);
/* 1165 */       for (int i = 0; i < length; i++) {
/* 1166 */         parameters = new HashMap<>();
/* 1167 */         parameters.put("value", arguments[i]);
/* 1168 */         printTag("argument", parameters, true, true);
/*      */       } 
/* 1170 */       endTag("arguments");
/*      */     } 
/* 1172 */     endTag("problem");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void logXmlTask(CategorizedProblem problem, char[] unitSource) {
/* 1181 */     HashMap<String, Object> parameters = new HashMap<>();
/* 1182 */     parameters.put("line", Integer.valueOf(problem.getSourceLineNumber()));
/* 1183 */     parameters.put("charStart", Integer.valueOf(problem.getSourceStart()));
/* 1184 */     parameters.put("charEnd", Integer.valueOf(problem.getSourceEnd()));
/* 1185 */     String problemOptionKey = getProblemOptionKey(problem.getID());
/* 1186 */     if (problemOptionKey != null) {
/* 1187 */       parameters.put("optionKey", problemOptionKey);
/*      */     }
/* 1189 */     printTag("task", parameters, true, false);
/* 1190 */     parameters.put("value", problem.getMessage());
/* 1191 */     printTag("message", parameters, true, true);
/* 1192 */     extractContext(problem, unitSource);
/* 1193 */     endTag("task");
/*      */   }
/*      */   
/*      */   private void printErr(String s) {
/* 1197 */     this.err.print(s);
/* 1198 */     if ((this.tagBits & 0x1) == 0 && this.log != null) {
/* 1199 */       this.log.print(s);
/*      */     }
/*      */   }
/*      */   
/*      */   private void printlnErr() {
/* 1204 */     this.err.println();
/* 1205 */     if ((this.tagBits & 0x1) == 0 && this.log != null) {
/* 1206 */       this.log.println();
/*      */     }
/*      */   }
/*      */   
/*      */   private void printlnErr(String s) {
/* 1211 */     this.err.println(s);
/* 1212 */     if ((this.tagBits & 0x1) == 0 && this.log != null) {
/* 1213 */       this.log.println(s);
/*      */     }
/*      */   }
/*      */   
/*      */   private void printlnOut(String s) {
/* 1218 */     this.out.println(s);
/* 1219 */     if ((this.tagBits & 0x1) == 0 && this.log != null) {
/* 1220 */       this.log.println(s);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void printNewLine() {
/* 1228 */     this.out.println();
/*      */   }
/*      */   
/*      */   private void printOut(char c) {
/* 1232 */     this.out.print(c);
/*      */   }
/*      */   
/*      */   public void printStats() {
/* 1236 */     boolean isTimed = ((this.main.timing & 0x1) != 0);
/* 1237 */     if ((this.tagBits & 0x1) != 0) {
/* 1238 */       printTag("stats", new HashMap<>(), true, false);
/*      */     }
/* 1240 */     if (isTimed) {
/* 1241 */       CompilerStats compilerStats = this.main.batchCompiler.stats;
/* 1242 */       compilerStats.startTime = this.main.startTime;
/* 1243 */       compilerStats.endTime = System.currentTimeMillis();
/* 1244 */       logTiming(compilerStats);
/*      */     } 
/* 1246 */     if (this.main.globalProblemsCount > 0) {
/* 1247 */       logProblemsSummary(this.main.globalProblemsCount, this.main.globalErrorsCount, this.main.globalWarningsCount, 
/* 1248 */           this.main.globalInfoCount, this.main.globalTasksCount);
/*      */     }
/* 1250 */     if (this.main.exportedClassFilesCounter != 0 && (
/* 1251 */       this.main.showProgress || isTimed || this.main.verbose)) {
/* 1252 */       logNumberOfClassFilesGenerated(this.main.exportedClassFilesCounter);
/*      */     }
/* 1254 */     if ((this.tagBits & 0x1) != 0) {
/* 1255 */       endTag("stats");
/*      */     }
/*      */   }
/*      */   
/*      */   private void printTag(String name, HashMap<String, Object> params, boolean insertNewLine, boolean closeTag) {
/* 1260 */     if (this.log != null) {
/* 1261 */       ((GenericXMLWriter)this.log).printTag(name, params, true, insertNewLine, closeTag);
/*      */     }
/* 1263 */     if (params != null) params.clear(); 
/*      */   }
/*      */   
/*      */   public void setEmacs() {
/* 1267 */     this.tagBits |= 0x2;
/*      */   }
/*      */   public void setLog(String logFileName) {
/* 1270 */     Date date = new Date();
/* 1271 */     DateFormat dateFormat = DateFormat.getDateTimeInstance(3, 1, Locale.getDefault());
/*      */     try {
/* 1273 */       int index = logFileName.lastIndexOf('.');
/* 1274 */       if (index != -1) {
/* 1275 */         if (logFileName.substring(index).toLowerCase().equals(".xml")) {
/* 1276 */           this.log = (PrintWriter)new GenericXMLWriter(new OutputStreamWriter(new FileOutputStream(logFileName, false), "UTF-8"), Util.LINE_SEPARATOR, true);
/* 1277 */           this.tagBits |= 0x1;
/*      */           
/* 1279 */           this.log.println("<!-- " + dateFormat.format(date) + " -->");
/* 1280 */           this.log.println("<!DOCTYPE compiler PUBLIC \"-//Eclipse.org//DTD Eclipse JDT 3.2.006 Compiler//EN\" \"https://www.eclipse.org/jdt/core/compiler_32_006.dtd\">");
/* 1281 */           HashMap<String, Object> parameters = new HashMap<>();
/* 1282 */           parameters.put("name", this.main.bind("compiler.name"));
/* 1283 */           parameters.put("version", this.main.bind("compiler.version"));
/* 1284 */           parameters.put("copyright", this.main.bind("compiler.copyright"));
/* 1285 */           printTag("compiler", parameters, true, false);
/*      */         } else {
/* 1287 */           this.log = new PrintWriter(new FileOutputStream(logFileName, false));
/* 1288 */           this.log.println("# " + dateFormat.format(date));
/*      */         } 
/*      */       } else {
/* 1291 */         this.log = new PrintWriter(new FileOutputStream(logFileName, false));
/* 1292 */         this.log.println("# " + dateFormat.format(date));
/*      */       } 
/* 1294 */     } catch (FileNotFoundException e) {
/* 1295 */       throw new IllegalArgumentException(this.main.bind("configure.cannotOpenLog", logFileName), e);
/* 1296 */     } catch (UnsupportedEncodingException e) {
/* 1297 */       throw new IllegalArgumentException(this.main.bind("configure.cannotOpenLogInvalidEncoding", logFileName), e);
/*      */     } 
/*      */   }
/*      */   private void startLoggingExtraProblems(int count) {
/* 1301 */     HashMap<String, Object> parameters = new HashMap<>();
/* 1302 */     parameters.put("problems", Integer.valueOf(count));
/* 1303 */     printTag("extra_problems", parameters, true, false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void startLoggingProblems(int errors, int warnings, int infos) {
/* 1311 */     HashMap<String, Object> parameters = new HashMap<>();
/* 1312 */     parameters.put("problems", Integer.valueOf(errors + warnings));
/* 1313 */     parameters.put("errors", Integer.valueOf(errors));
/* 1314 */     parameters.put("warnings", Integer.valueOf(warnings));
/* 1315 */     parameters.put("infos", Integer.valueOf(infos));
/* 1316 */     printTag("problems", parameters, true, false);
/*      */   }
/*      */   
/*      */   public void startLoggingSource(CompilationResult compilationResult) {
/* 1320 */     if ((this.tagBits & 0x1) != 0) {
/* 1321 */       ICompilationUnit compilationUnit = compilationResult.compilationUnit;
/* 1322 */       HashMap<String, Object> parameters = new HashMap<>();
/* 1323 */       if (compilationUnit != null) {
/* 1324 */         char[] fileName = compilationUnit.getFileName();
/* 1325 */         File f = new File(new String(fileName));
/* 1326 */         if (fileName != null) {
/* 1327 */           parameters.put("path", f.getAbsolutePath());
/*      */         }
/* 1329 */         char[][] packageName = compilationResult.packageName;
/* 1330 */         if (packageName != null) {
/* 1331 */           parameters.put(
/* 1332 */               "package", 
/* 1333 */               new String(CharOperation.concatWith(packageName, File.separatorChar)));
/*      */         }
/* 1335 */         CompilationUnit unit = (CompilationUnit)compilationUnit;
/* 1336 */         String destinationPath = unit.destinationPath;
/* 1337 */         if (destinationPath == null) {
/* 1338 */           destinationPath = this.main.destinationPath;
/*      */         }
/* 1340 */         if (destinationPath != null && destinationPath != "none") {
/* 1341 */           if (File.separatorChar == '/') {
/* 1342 */             parameters.put("output", destinationPath);
/*      */           } else {
/* 1344 */             parameters.put("output", destinationPath.replace('/', File.separatorChar));
/*      */           } 
/*      */         }
/*      */       } 
/* 1348 */       printTag("source", parameters, true, false);
/*      */     } 
/*      */   }
/*      */   
/*      */   public void startLoggingSources() {
/* 1353 */     if ((this.tagBits & 0x1) != 0) {
/* 1354 */       printTag("sources", new HashMap<>(), true, false);
/*      */     }
/*      */   }
/*      */   
/*      */   public void startLoggingTasks(int tasks) {
/* 1359 */     if ((this.tagBits & 0x1) != 0) {
/* 1360 */       HashMap<String, Object> parameters = new HashMap<>();
/* 1361 */       parameters.put("tasks", Integer.valueOf(tasks));
/* 1362 */       printTag("tasks", parameters, true, false);
/*      */     } 
/*      */   }
/*      */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\batch\Main$Logger.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */