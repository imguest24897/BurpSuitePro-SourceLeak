/*     */ package org.eclipse.jdt.internal.compiler.batch;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.nio.file.InvalidPathException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.function.Consumer;
/*     */ import java.util.function.Function;
/*     */ import java.util.zip.ZipFile;
/*     */ import javax.lang.model.SourceVersion;
/*     */ import org.eclipse.jdt.core.compiler.CharOperation;
/*     */ import org.eclipse.jdt.internal.compiler.CompilationResult;
/*     */ import org.eclipse.jdt.internal.compiler.DefaultErrorHandlingPolicies;
/*     */ import org.eclipse.jdt.internal.compiler.IProblemFactory;
/*     */ import org.eclipse.jdt.internal.compiler.classfmt.ExternalAnnotationDecorator;
/*     */ import org.eclipse.jdt.internal.compiler.env.AccessRuleSet;
/*     */ import org.eclipse.jdt.internal.compiler.env.IBinaryType;
/*     */ import org.eclipse.jdt.internal.compiler.env.IModule;
/*     */ import org.eclipse.jdt.internal.compiler.env.IModuleAwareNameEnvironment;
/*     */ import org.eclipse.jdt.internal.compiler.env.IModulePathEntry;
/*     */ import org.eclipse.jdt.internal.compiler.env.IUpdatableModule;
/*     */ import org.eclipse.jdt.internal.compiler.env.NameEnvironmentAnswer;
/*     */ import org.eclipse.jdt.internal.compiler.impl.CompilerOptions;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.ModuleBinding;
/*     */ import org.eclipse.jdt.internal.compiler.parser.Parser;
/*     */ import org.eclipse.jdt.internal.compiler.problem.DefaultProblemFactory;
/*     */ import org.eclipse.jdt.internal.compiler.problem.ProblemReporter;
/*     */ import org.eclipse.jdt.internal.compiler.util.JRTUtil;
/*     */ import org.eclipse.jdt.internal.compiler.util.SuffixConstants;
/*     */ import org.eclipse.jdt.internal.compiler.util.Util;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FileSystem
/*     */   implements IModuleAwareNameEnvironment, SuffixConstants
/*     */ {
/*  62 */   public static ArrayList<Classpath> EMPTY_CLASSPATH = new ArrayList<>(); protected Classpath[] classpaths;
/*     */   protected IModule module;
/*     */   Set<String> knownFileNames;
/*     */   protected boolean annotationsFromClasspath;
/*     */   
/*     */   public static interface Classpath extends IModulePathEntry { char[][][] findTypeNames(String param1String1, String param1String2);
/*     */     
/*     */     NameEnvironmentAnswer findClass(char[] param1ArrayOfchar, String param1String1, String param1String2, String param1String3);
/*     */     
/*     */     NameEnvironmentAnswer findClass(char[] param1ArrayOfchar, String param1String1, String param1String2, String param1String3, boolean param1Boolean);
/*     */     
/*     */     boolean isPackage(String param1String1, String param1String2);
/*     */     
/*     */     default boolean hasModule() {
/*  76 */       return (getModule() != null);
/*     */     } default boolean hasCUDeclaringPackage(String qualifiedPackageName, Function<CompilationUnit, String> pkgNameExtractor) {
/*  78 */       return hasCompilationUnit(qualifiedPackageName, null);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     List<Classpath> fetchLinkedJars(FileSystem.ClasspathSectionProblemReporter param1ClasspathSectionProblemReporter);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     void reset();
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     char[] normalizedPath();
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     String getPath();
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     void initialize() throws IOException;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     boolean hasAnnotationFileFor(String param1String);
/*     */ 
/*     */ 
/*     */     
/*     */     void acceptModule(IModule param1IModule);
/*     */ 
/*     */ 
/*     */     
/*     */     String getDestinationPath();
/*     */ 
/*     */ 
/*     */     
/*     */     Collection<String> getModuleNames(Collection<String> param1Collection);
/*     */ 
/*     */ 
/*     */     
/*     */     Collection<String> getModuleNames(Collection<String> param1Collection, Function<String, IModule> param1Function);
/*     */ 
/*     */ 
/*     */     
/*     */     default boolean forbidsExportFrom(String modName) {
/* 130 */       return false;
/*     */     } }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class ClasspathNormalizer
/*     */   {
/*     */     public static ArrayList<FileSystem.Classpath> normalize(ArrayList<FileSystem.Classpath> classpaths) {
/* 151 */       ArrayList<FileSystem.Classpath> normalizedClasspath = new ArrayList<>();
/* 152 */       HashSet<FileSystem.Classpath> cache = new HashSet<>();
/* 153 */       for (Iterator<FileSystem.Classpath> iterator = classpaths.iterator(); iterator.hasNext(); ) {
/* 154 */         FileSystem.Classpath classpath = iterator.next();
/* 155 */         if (!cache.contains(classpath)) {
/* 156 */           normalizedClasspath.add(classpath);
/* 157 */           cache.add(classpath);
/*     */         } 
/*     */       } 
/* 160 */       return normalizedClasspath;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 170 */   private static HashMap<File, Classpath> JRT_CLASSPATH_CACHE = null;
/* 171 */   protected Map<String, Classpath> moduleLocations = new HashMap<>();
/*     */ 
/*     */   
/* 174 */   Map<String, IUpdatableModule.UpdatesByKind> moduleUpdates = new HashMap<>();
/*     */   
/*     */   static boolean isJRE12Plus = false;
/*     */   private boolean hasLimitModules = false;
/*     */   
/*     */   static {
/*     */     try {
/* 181 */       isJRE12Plus = (SourceVersion.valueOf("RELEASE_12") != null);
/* 182 */     } catch (IllegalArgumentException illegalArgumentException) {}
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public FileSystem(String[] classpathNames, String[] initialFileNames, String encoding) {
/* 192 */     this(classpathNames, initialFileNames, encoding, null, null);
/*     */   }
/*     */   public FileSystem(String[] classpathNames, String[] initialFileNames, String encoding, String release) {
/* 195 */     this(classpathNames, initialFileNames, encoding, null, release);
/*     */   }
/*     */   protected FileSystem(String[] classpathNames, String[] initialFileNames, String encoding, Collection<String> limitModules) {
/* 198 */     this(classpathNames, initialFileNames, encoding, limitModules, null);
/*     */   }
/*     */   protected FileSystem(String[] classpathNames, String[] initialFileNames, String encoding, Collection<String> limitModules, String release) {
/* 201 */     int classpathSize = classpathNames.length;
/* 202 */     this.classpaths = new Classpath[classpathSize];
/* 203 */     int counter = 0;
/* 204 */     this.hasLimitModules = (limitModules != null && !limitModules.isEmpty());
/* 205 */     for (int i = 0; i < classpathSize; i++) {
/* 206 */       Classpath classpath = getClasspath(classpathNames[i], encoding, null, null, release);
/*     */       try {
/* 208 */         classpath.initialize();
/* 209 */         for (String moduleName : classpath.getModuleNames(limitModules))
/* 210 */           this.moduleLocations.put(moduleName, classpath); 
/* 211 */         this.classpaths[counter++] = classpath;
/* 212 */       } catch (IOException e) {
/* 213 */         String error = "Failed to init " + classpath;
/* 214 */         if (JRTUtil.PROPAGATE_IO_ERRORS) {
/* 215 */           throw new IllegalStateException(error, e);
/*     */         }
/* 217 */         System.err.println(error);
/* 218 */         e.printStackTrace();
/*     */       } 
/*     */     } 
/*     */     
/* 222 */     if (counter != classpathSize) {
/* 223 */       System.arraycopy(this.classpaths, 0, this.classpaths = new Classpath[counter], 0, counter);
/*     */     }
/* 225 */     initializeKnownFileNames(initialFileNames);
/*     */   }
/*     */   protected FileSystem(Classpath[] paths, String[] initialFileNames, boolean annotationsFromClasspath, Set<String> limitedModules) {
/* 228 */     int length = paths.length;
/* 229 */     int counter = 0;
/* 230 */     this.classpaths = new Classpath[length];
/* 231 */     this.hasLimitModules = (limitedModules != null && !limitedModules.isEmpty());
/* 232 */     for (int i = 0; i < length; i++) {
/* 233 */       Classpath classpath = paths[i];
/*     */       try {
/* 235 */         classpath.initialize();
/* 236 */         for (String moduleName : classpath.getModuleNames(limitedModules))
/* 237 */           this.moduleLocations.put(moduleName, classpath); 
/* 238 */         this.classpaths[counter++] = classpath;
/* 239 */       } catch (InvalidPathException invalidPathException) {
/*     */ 
/*     */       
/* 242 */       } catch (IOException e) {
/* 243 */         String error = "Failed to init " + classpath;
/* 244 */         if (JRTUtil.PROPAGATE_IO_ERRORS) {
/* 245 */           throw new IllegalStateException(error, e);
/*     */         }
/* 247 */         System.err.println(error);
/* 248 */         e.printStackTrace();
/*     */       } 
/*     */     } 
/*     */     
/* 252 */     if (counter != length)
/*     */     {
/* 254 */       System.arraycopy(this.classpaths, 0, this.classpaths = new Classpath[counter], 0, counter);
/*     */     }
/* 256 */     initializeModuleLocations(limitedModules);
/* 257 */     initializeKnownFileNames(initialFileNames);
/* 258 */     this.annotationsFromClasspath = annotationsFromClasspath;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void initializeModuleLocations(Set<String> limitedModules) {
/* 264 */     if (limitedModules == null) {
/* 265 */       byte b; int i; Classpath[] arrayOfClasspath; for (i = (arrayOfClasspath = this.classpaths).length, b = 0; b < i; ) { Classpath c = arrayOfClasspath[b];
/* 266 */         for (String moduleName : c.getModuleNames((Collection<String>)null))
/* 267 */           this.moduleLocations.put(moduleName, c);  b++; }
/*     */     
/*     */     } else {
/* 270 */       Map<String, Classpath> moduleMap = new HashMap<>(); byte b; int i; Classpath[] arrayOfClasspath;
/* 271 */       for (i = (arrayOfClasspath = this.classpaths).length, b = 0; b < i; ) { Classpath c = arrayOfClasspath[b];
/* 272 */         for (String moduleName : c.getModuleNames((Collection<String>)null))
/* 273 */           moduleMap.put(moduleName, c); 
/*     */         b++; }
/*     */       
/* 276 */       for (i = (arrayOfClasspath = this.classpaths).length, b = 0; b < i; ) { Classpath c = arrayOfClasspath[b];
/* 277 */         for (String moduleName : c.getModuleNames(limitedModules, m -> getModuleFromEnvironment(m.toCharArray()))) {
/* 278 */           Classpath classpath = moduleMap.get(moduleName);
/* 279 */           this.moduleLocations.put(moduleName, classpath);
/*     */         } 
/*     */         b++; }
/*     */     
/*     */     } 
/*     */   } protected FileSystem(Classpath[] paths, String[] initialFileNames, boolean annotationsFromClasspath) {
/* 285 */     this(paths, initialFileNames, annotationsFromClasspath, (Set<String>)null);
/*     */   }
/*     */   public static Classpath getClasspath(String classpathName, String encoding, AccessRuleSet accessRuleSet) {
/* 288 */     return getClasspath(classpathName, encoding, false, accessRuleSet, null, null, null);
/*     */   }
/*     */   public static Classpath getClasspath(String classpathName, String encoding, AccessRuleSet accessRuleSet, Map<String, String> options, String release) {
/* 291 */     return getClasspath(classpathName, encoding, false, accessRuleSet, null, options, release);
/*     */   }
/*     */   public static Classpath getJrtClasspath(String jdkHome, String encoding, AccessRuleSet accessRuleSet, Map<String, String> options) {
/* 294 */     return new ClasspathJrt(new File(convertPathSeparators(jdkHome)), true, accessRuleSet, null);
/*     */   }
/*     */   public static Classpath getOlderSystemRelease(String jdkHome, String release, AccessRuleSet accessRuleSet) {
/* 297 */     return isJRE12Plus ? 
/* 298 */       new ClasspathJep247Jdk12(new File(convertPathSeparators(jdkHome)), release, accessRuleSet) : 
/* 299 */       new ClasspathJep247(new File(convertPathSeparators(jdkHome)), release, accessRuleSet);
/*     */   }
/*     */ 
/*     */   
/*     */   public static Classpath getClasspath(String classpathName, String encoding, boolean isSourceOnly, AccessRuleSet accessRuleSet, String destinationPath, Map<String, String> options, String release) {
/* 304 */     Classpath result = null;
/* 305 */     File file = new File(convertPathSeparators(classpathName));
/* 306 */     if (file.isDirectory()) {
/* 307 */       if (file.exists()) {
/* 308 */         result = new ClasspathDirectory(file, encoding, 
/* 309 */             isSourceOnly ? 1 : 
/* 310 */             3, 
/* 311 */             accessRuleSet, (
/* 312 */             destinationPath == null || destinationPath == "none") ? 
/* 313 */             destinationPath : 
/* 314 */             convertPathSeparators(destinationPath), options);
/*     */       }
/*     */     } else {
/* 317 */       int format = Util.archiveFormat(classpathName);
/* 318 */       if (format == 0) {
/* 319 */         if (isSourceOnly) {
/*     */           
/* 321 */           result = new ClasspathSourceJar(file, true, accessRuleSet, 
/* 322 */               encoding, (
/* 323 */               destinationPath == null || destinationPath == "none") ? 
/* 324 */               destinationPath : 
/* 325 */               convertPathSeparators(destinationPath));
/* 326 */         } else if (destinationPath == null) {
/*     */           
/* 328 */           if (classpathName.endsWith("jrt-fs.jar")) {
/* 329 */             if (JRT_CLASSPATH_CACHE == null) {
/* 330 */               JRT_CLASSPATH_CACHE = new HashMap<>();
/*     */             } else {
/* 332 */               result = JRT_CLASSPATH_CACHE.get(file);
/*     */             } 
/* 334 */             if (result == null) {
/* 335 */               result = new ClasspathJrt(file, true, accessRuleSet, null);
/*     */               try {
/* 337 */                 result.initialize();
/* 338 */               } catch (IOException iOException) {}
/*     */ 
/*     */               
/* 341 */               JRT_CLASSPATH_CACHE.put(file, result);
/*     */             } 
/*     */           } else {
/* 344 */             result = 
/* 345 */               (release == null) ? 
/* 346 */               new ClasspathJar(file, true, accessRuleSet, null) : 
/* 347 */               new ClasspathMultiReleaseJar(file, true, accessRuleSet, destinationPath, release);
/*     */           } 
/*     */         } 
/* 350 */       } else if (format == 1) {
/* 351 */         return new ClasspathJmod(file, true, accessRuleSet, null);
/*     */       } 
/*     */     } 
/*     */     
/* 355 */     return result;
/*     */   }
/*     */   private void initializeKnownFileNames(String[] initialFileNames) {
/* 358 */     if (initialFileNames == null) {
/* 359 */       this.knownFileNames = new HashSet<>(0);
/*     */       return;
/*     */     } 
/* 362 */     this.knownFileNames = new HashSet<>(initialFileNames.length * 2);
/* 363 */     for (int i = initialFileNames.length; --i >= 0; ) {
/* 364 */       File compilationUnitFile = new File(initialFileNames[i]);
/* 365 */       char[] fileName = null;
/*     */       try {
/* 367 */         fileName = compilationUnitFile.getCanonicalPath().toCharArray();
/* 368 */       } catch (IOException iOException) {
/*     */         continue;
/*     */       } 
/*     */       
/* 372 */       char[] matchingPathName = null;
/* 373 */       int lastIndexOf = CharOperation.lastIndexOf('.', fileName);
/* 374 */       if (lastIndexOf != -1) {
/* 375 */         fileName = CharOperation.subarray(fileName, 0, lastIndexOf);
/*     */       }
/* 377 */       CharOperation.replace(fileName, '\\', '/');
/* 378 */       boolean globalPathMatches = false; byte b; int j;
/*     */       Classpath[] arrayOfClasspath;
/* 380 */       for (j = (arrayOfClasspath = this.classpaths).length, b = 0; b < j; ) { Classpath classpath = arrayOfClasspath[b];
/* 381 */         char[] matchCandidate = classpath.normalizedPath();
/* 382 */         boolean currentPathMatch = false;
/* 383 */         if (classpath instanceof ClasspathDirectory && 
/* 384 */           CharOperation.prefixEquals(matchCandidate, fileName)) {
/* 385 */           currentPathMatch = true;
/* 386 */           if (matchingPathName == null) {
/* 387 */             matchingPathName = matchCandidate;
/*     */           }
/* 389 */           else if (currentPathMatch) {
/*     */             
/* 391 */             if (matchCandidate.length > matchingPathName.length)
/*     */             {
/* 393 */               matchingPathName = matchCandidate;
/*     */             
/*     */             }
/*     */           }
/* 397 */           else if (!globalPathMatches && matchCandidate.length < matchingPathName.length) {
/* 398 */             matchingPathName = matchCandidate;
/*     */           } 
/*     */ 
/*     */           
/* 402 */           if (currentPathMatch)
/* 403 */             globalPathMatches = true; 
/*     */         } 
/*     */         b++; }
/*     */       
/* 407 */       if (matchingPathName == null) {
/* 408 */         this.knownFileNames.add(new String(fileName));
/*     */       } else {
/* 410 */         this.knownFileNames.add(new String(CharOperation.subarray(fileName, matchingPathName.length, fileName.length)));
/*     */       } 
/* 412 */       matchingPathName = null;
/*     */     } 
/*     */   }
/*     */   
/*     */   public void scanForModules(Parser parser) {
/* 417 */     for (int i = 0, max = this.classpaths.length; i < max; i++) {
/* 418 */       File file = new File(this.classpaths[i].getPath());
/* 419 */       IModule iModule = ModuleFinder.scanForModule(this.classpaths[i], file, parser, false, null);
/* 420 */       if (iModule != null)
/* 421 */         this.moduleLocations.put(String.valueOf(iModule.name()), this.classpaths[i]); 
/*     */     } 
/*     */   }
/*     */   
/*     */   public void cleanup() {
/* 426 */     for (int i = 0, max = this.classpaths.length; i < max; i++)
/* 427 */       this.classpaths[i].reset(); 
/*     */   }
/*     */   private static String convertPathSeparators(String path) {
/* 430 */     return (File.separatorChar == '/') ? 
/* 431 */       path.replace('\\', '/') : 
/* 432 */       path.replace('/', '\\');
/*     */   }
/*     */   private NameEnvironmentAnswer findClass(String qualifiedTypeName, char[] typeName, boolean asBinaryOnly, char[] moduleName) {
/* 435 */     NameEnvironmentAnswer answer = internalFindClass(qualifiedTypeName, typeName, asBinaryOnly, moduleName);
/* 436 */     if (this.annotationsFromClasspath && answer != null && answer.getBinaryType() instanceof org.eclipse.jdt.internal.compiler.classfmt.ClassFileReader) {
/* 437 */       for (int i = 0, length = this.classpaths.length; i < length; i++) {
/* 438 */         Classpath classpathEntry = this.classpaths[i];
/* 439 */         if (classpathEntry.hasAnnotationFileFor(qualifiedTypeName)) {
/*     */           
/* 441 */           ZipFile zip = (classpathEntry instanceof ClasspathJar) ? ((ClasspathJar)classpathEntry).zipFile : null;
/* 442 */           boolean shouldClose = false;
/*     */         } 
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 462 */       answer.setBinaryType((IBinaryType)new ExternalAnnotationDecorator(answer.getBinaryType(), null));
/*     */     } 
/* 464 */     return answer;
/*     */   }
/*     */   private NameEnvironmentAnswer internalFindClass(String qualifiedTypeName, char[] typeName, boolean asBinaryOnly, char[] moduleName) {
/* 467 */     if (this.knownFileNames.contains(qualifiedTypeName)) return null;
/*     */     
/* 469 */     String qualifiedBinaryFileName = String.valueOf(qualifiedTypeName) + ".class";
/* 470 */     String qualifiedPackageName = 
/* 471 */       (qualifiedTypeName.length() == typeName.length) ? 
/* 472 */       Util.EMPTY_STRING : 
/* 473 */       qualifiedBinaryFileName.substring(0, qualifiedTypeName.length() - typeName.length - 1);
/*     */     
/* 475 */     IModuleAwareNameEnvironment.LookupStrategy strategy = IModuleAwareNameEnvironment.LookupStrategy.get(moduleName);
/* 476 */     if (strategy == IModuleAwareNameEnvironment.LookupStrategy.Named) {
/* 477 */       if (this.moduleLocations != null) {
/*     */         
/* 479 */         String moduleNameString = String.valueOf(moduleName);
/* 480 */         Classpath classpath = this.moduleLocations.get(moduleNameString);
/* 481 */         if (classpath != null) {
/* 482 */           return classpath.findClass(typeName, qualifiedPackageName, moduleNameString, qualifiedBinaryFileName);
/*     */         }
/*     */       } 
/* 485 */       return null;
/*     */     } 
/* 487 */     String qp2 = (File.separatorChar == '/') ? qualifiedPackageName : qualifiedPackageName.replace('/', File.separatorChar);
/* 488 */     NameEnvironmentAnswer suggestedAnswer = null;
/* 489 */     if (qualifiedPackageName == qp2)
/* 490 */     { for (int i = 0, length = this.classpaths.length; i < length; i++) {
/* 491 */         if (strategy.matches(this.classpaths[i], Classpath::hasModule)) {
/*     */           
/* 493 */           NameEnvironmentAnswer answer = this.classpaths[i].findClass(typeName, qualifiedPackageName, (String)null, qualifiedBinaryFileName, asBinaryOnly);
/* 494 */           if (answer != null && (
/* 495 */             answer.moduleName() == null || this.moduleLocations.containsKey(String.valueOf(answer.moduleName()))))
/*     */           {
/* 497 */             if (!answer.ignoreIfBetter()) {
/* 498 */               if (answer.isBetter(suggestedAnswer))
/* 499 */                 return answer; 
/* 500 */             } else if (answer.isBetter(suggestedAnswer)) {
/*     */               
/* 502 */               suggestedAnswer = answer;
/*     */             }  } 
/*     */         } 
/*     */       }  }
/* 506 */     else { String qb2 = qualifiedBinaryFileName.replace('/', File.separatorChar);
/* 507 */       for (int i = 0, length = this.classpaths.length; i < length; i++) {
/* 508 */         Classpath p = this.classpaths[i];
/* 509 */         if (strategy.matches(p, Classpath::hasModule)) {
/*     */           
/* 511 */           NameEnvironmentAnswer answer = !(p instanceof ClasspathDirectory) ? 
/* 512 */             p.findClass(typeName, qualifiedPackageName, (String)null, qualifiedBinaryFileName, asBinaryOnly) : 
/* 513 */             p.findClass(typeName, qp2, (String)null, qb2, asBinaryOnly);
/* 514 */           if (answer != null && (
/* 515 */             answer.moduleName() == null || this.moduleLocations.containsKey(String.valueOf(answer.moduleName()))))
/*     */           {
/* 517 */             if (!answer.ignoreIfBetter()) {
/* 518 */               if (answer.isBetter(suggestedAnswer))
/* 519 */                 return answer; 
/* 520 */             } else if (answer.isBetter(suggestedAnswer)) {
/*     */               
/* 522 */               suggestedAnswer = answer;
/*     */             }  } 
/*     */         } 
/*     */       }  }
/* 526 */      return suggestedAnswer;
/*     */   }
/*     */ 
/*     */   
/*     */   public NameEnvironmentAnswer findType(char[][] compoundName, char[] moduleName) {
/* 531 */     if (compoundName != null)
/* 532 */       return findClass(
/* 533 */           new String(CharOperation.concatWith(compoundName, '/')), 
/* 534 */           compoundName[compoundName.length - 1], 
/* 535 */           false, 
/* 536 */           moduleName); 
/* 537 */     return null;
/*     */   }
/*     */   public char[][][] findTypeNames(char[][] packageName) {
/* 540 */     char[][][] result = null;
/* 541 */     if (packageName != null) {
/* 542 */       String qualifiedPackageName = new String(CharOperation.concatWith(packageName, '/'));
/* 543 */       String qualifiedPackageName2 = (File.separatorChar == '/') ? qualifiedPackageName : qualifiedPackageName.replace('/', File.separatorChar);
/* 544 */       if (qualifiedPackageName == qualifiedPackageName2) {
/* 545 */         for (int i = 0, length = this.classpaths.length; i < length; i++) {
/* 546 */           char[][][] answers = this.classpaths[i].findTypeNames(qualifiedPackageName, (String)null);
/* 547 */           if (answers != null)
/*     */           {
/* 549 */             if (result == null) {
/* 550 */               result = answers;
/*     */             } else {
/* 552 */               int resultLength = result.length;
/* 553 */               int answersLength = answers.length;
/* 554 */               System.arraycopy(result, 0, result = new char[answersLength + resultLength][][], 0, resultLength);
/* 555 */               System.arraycopy(answers, 0, result, resultLength, answersLength);
/*     */             } 
/*     */           }
/*     */         } 
/*     */       } else {
/* 560 */         for (int i = 0, length = this.classpaths.length; i < length; i++) {
/* 561 */           Classpath p = this.classpaths[i];
/* 562 */           char[][][] answers = !(p instanceof ClasspathDirectory) ? p.findTypeNames(qualifiedPackageName, (String)null) : 
/* 563 */             p.findTypeNames(qualifiedPackageName2, (String)null);
/* 564 */           if (answers != null)
/*     */           {
/* 566 */             if (result == null) {
/* 567 */               result = answers;
/*     */             } else {
/* 569 */               int resultLength = result.length;
/* 570 */               int answersLength = answers.length;
/* 571 */               System.arraycopy(result, 0, result = new char[answersLength + resultLength][][], 0, 
/* 572 */                   resultLength);
/* 573 */               System.arraycopy(answers, 0, result, resultLength, answersLength);
/*     */             } 
/*     */           }
/*     */         } 
/*     */       } 
/*     */     } 
/* 579 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   public NameEnvironmentAnswer findType(char[] typeName, char[][] packageName, char[] moduleName) {
/* 584 */     if (typeName != null)
/* 585 */       return findClass(
/* 586 */           new String(CharOperation.concatWith(packageName, typeName, '/')), 
/* 587 */           typeName, 
/* 588 */           false, 
/* 589 */           moduleName); 
/* 590 */     return null;
/*     */   }
/*     */   
/*     */   public char[][] getModulesDeclaringPackage(char[][] packageName, char[] moduleName) {
/*     */     int i;
/* 595 */     String qualifiedPackageName = new String(CharOperation.concatWith(packageName, '/'));
/* 596 */     String moduleNameString = String.valueOf(moduleName);
/*     */     
/* 598 */     IModuleAwareNameEnvironment.LookupStrategy strategy = IModuleAwareNameEnvironment.LookupStrategy.get(moduleName);
/* 599 */     if (strategy == IModuleAwareNameEnvironment.LookupStrategy.Named) {
/* 600 */       if (this.moduleLocations != null) {
/*     */         
/* 602 */         Classpath classpath = this.moduleLocations.get(moduleNameString);
/* 603 */         if (classpath != null && 
/* 604 */           classpath.isPackage(qualifiedPackageName, moduleNameString)) {
/* 605 */           return new char[][] { moduleName };
/*     */         }
/*     */       } 
/* 608 */       return null;
/*     */     } 
/*     */     
/* 611 */     char[][] allNames = null;
/* 612 */     boolean hasUnobserable = false; byte b; int j; Classpath[] arrayOfClasspath;
/* 613 */     for (j = (arrayOfClasspath = this.classpaths).length, b = 0; b < j; ) { Classpath cp = arrayOfClasspath[b];
/* 614 */       if (strategy.matches(cp, Classpath::hasModule))
/* 615 */         if (strategy == IModuleAwareNameEnvironment.LookupStrategy.Unnamed) {
/*     */           
/* 617 */           if (cp.isPackage(qualifiedPackageName, moduleNameString))
/* 618 */             return new char[][] { ModuleBinding.UNNAMED }; 
/*     */         } else {
/* 620 */           char[][] declaringModules = cp.getModulesDeclaringPackage(qualifiedPackageName, null);
/* 621 */           if (declaringModules != null) {
/* 622 */             if (cp instanceof ClasspathJrt && this.hasLimitModules) {
/* 623 */               declaringModules = filterModules(declaringModules);
/* 624 */               i = hasUnobserable | ((declaringModules == null) ? 1 : 0);
/*     */             } 
/* 626 */             if (allNames == null) {
/* 627 */               allNames = declaringModules;
/*     */             } else {
/* 629 */               allNames = CharOperation.arrayConcat(allNames, declaringModules);
/*     */             } 
/*     */           } 
/*     */         }   b++; }
/*     */     
/* 634 */     if (allNames == null && i != 0)
/* 635 */       return new char[][] { ModuleBinding.UNOBSERVABLE }; 
/* 636 */     return allNames;
/*     */   }
/*     */   private char[][] filterModules(char[][] declaringModules) {
/* 639 */     char[][] filtered = (char[][])Arrays.<char[]>stream(declaringModules).filter(m -> this.moduleLocations.containsKey(new String(m))).toArray(paramInt -> new char[paramInt][]);
/* 640 */     if (filtered.length == 0)
/* 641 */       return null; 
/* 642 */     return filtered;
/*     */   }
/*     */   private Parser getParser() {
/* 645 */     Map<String, String> opts = new HashMap<>();
/* 646 */     opts.put("org.eclipse.jdt.core.compiler.source", "9");
/* 647 */     return new Parser(
/* 648 */         new ProblemReporter(DefaultErrorHandlingPolicies.exitOnFirstError(), new CompilerOptions(opts), (IProblemFactory)new DefaultProblemFactory(Locale.getDefault())), 
/* 649 */         false);
/*     */   }
/*     */   
/*     */   public boolean hasCompilationUnit(char[][] qualifiedPackageName, char[] moduleName, boolean checkCUs) {
/* 653 */     String qPackageName = String.valueOf(CharOperation.concatWith(qualifiedPackageName, '/'));
/* 654 */     String moduleNameString = String.valueOf(moduleName);
/* 655 */     IModuleAwareNameEnvironment.LookupStrategy strategy = IModuleAwareNameEnvironment.LookupStrategy.get(moduleName);
/* 656 */     Parser parser = checkCUs ? getParser() : null;
/* 657 */     Function<CompilationUnit, String> pkgNameExtractor = sourceUnit -> {
/*     */         String pkgName = null;
/*     */         CompilationResult compilationResult = new CompilationResult(sourceUnit, 0, 0, 1);
/*     */         char[][] name = paramParser.parsePackageDeclaration(sourceUnit.getContents(), compilationResult);
/*     */         if (name != null) {
/*     */           pkgName = CharOperation.toString(name);
/*     */         }
/*     */         return pkgName;
/*     */       };
/* 666 */     switch (strategy) {
/*     */       case Named:
/* 668 */         if (this.moduleLocations != null) {
/* 669 */           Classpath location = this.moduleLocations.get(moduleNameString);
/* 670 */           if (location != null)
/* 671 */             return checkCUs ? location.hasCUDeclaringPackage(qPackageName, pkgNameExtractor) : 
/* 672 */               location.hasCompilationUnit(qPackageName, moduleNameString); 
/*     */         } 
/* 674 */         return false;
/*     */     } 
/* 676 */     for (int i = 0; i < this.classpaths.length; i++) {
/* 677 */       Classpath location = this.classpaths[i];
/* 678 */       if (strategy.matches(location, Classpath::hasModule) && 
/* 679 */         location.hasCompilationUnit(qPackageName, moduleNameString))
/* 680 */         return true; 
/*     */     } 
/* 682 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public IModule getModule(char[] name) {
/* 688 */     if (this.module != null && CharOperation.equals(name, this.module.name())) {
/* 689 */       return this.module;
/*     */     }
/* 691 */     if (this.moduleLocations.containsKey(new String(name))) {
/* 692 */       byte b; int i; Classpath[] arrayOfClasspath; for (i = (arrayOfClasspath = this.classpaths).length, b = 0; b < i; ) { Classpath classpath = arrayOfClasspath[b];
/* 693 */         IModule mod = classpath.getModule(name);
/* 694 */         if (mod != null)
/* 695 */           return mod; 
/*     */         b++; }
/*     */     
/*     */     } 
/* 699 */     return null;
/*     */   }
/*     */   public IModule getModuleFromEnvironment(char[] name) {
/* 702 */     if (this.module != null && CharOperation.equals(name, this.module.name()))
/* 703 */       return this.module;  byte b; int i;
/*     */     Classpath[] arrayOfClasspath;
/* 705 */     for (i = (arrayOfClasspath = this.classpaths).length, b = 0; b < i; ) { Classpath classpath = arrayOfClasspath[b];
/* 706 */       IModule mod = classpath.getModule(name);
/* 707 */       if (mod != null)
/* 708 */         return mod; 
/*     */       b++; }
/*     */     
/* 711 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public char[][] getAllAutomaticModules() {
/* 716 */     Set<char[]> set = (Set)new HashSet<>();
/* 717 */     for (int i = 0, l = this.classpaths.length; i < l; i++) {
/* 718 */       if (this.classpaths[i].isAutomaticModule()) {
/* 719 */         set.add(this.classpaths[i].getModule().name());
/*     */       }
/*     */     } 
/* 722 */     return set.<char[]>toArray(new char[set.size()][]);
/*     */   }
/*     */   
/*     */   public char[][] listPackages(char[] moduleName) {
/*     */     Classpath classpath;
/* 727 */     switch (IModuleAwareNameEnvironment.LookupStrategy.get(moduleName)) {
/*     */       case Named:
/* 729 */         classpath = this.moduleLocations.get(new String(moduleName));
/* 730 */         if (classpath != null)
/* 731 */           return classpath.listPackages(); 
/* 732 */         return CharOperation.NO_CHAR_CHAR;
/*     */     } 
/* 734 */     throw new UnsupportedOperationException("can list packages only of a named module");
/*     */   }
/*     */ 
/*     */   
/*     */   void addModuleUpdate(String moduleName, Consumer<IUpdatableModule> update, IUpdatableModule.UpdateKind kind) {
/* 739 */     IUpdatableModule.UpdatesByKind updates = this.moduleUpdates.get(moduleName);
/* 740 */     if (updates == null) {
/* 741 */       this.moduleUpdates.put(moduleName, updates = new IUpdatableModule.UpdatesByKind());
/*     */     }
/* 743 */     updates.getList(kind, true).add(update);
/*     */   }
/*     */   
/*     */   public void applyModuleUpdates(IUpdatableModule compilerModule, IUpdatableModule.UpdateKind kind) {
/* 747 */     char[] name = compilerModule.name();
/* 748 */     if (name != ModuleBinding.UNNAMED) {
/* 749 */       IUpdatableModule.UpdatesByKind updates = this.moduleUpdates.get(String.valueOf(name));
/* 750 */       if (updates != null)
/* 751 */         for (Consumer<IUpdatableModule> update : (Iterable<Consumer<IUpdatableModule>>)updates.getList(kind, false))
/* 752 */           update.accept(compilerModule);  
/*     */     } 
/*     */   }
/*     */   
/*     */   public static interface ClasspathSectionProblemReporter {
/*     */     void invalidClasspathSection(String param1String);
/*     */     
/*     */     void multipleClasspathSections(String param1String);
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\batch\FileSystem.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */