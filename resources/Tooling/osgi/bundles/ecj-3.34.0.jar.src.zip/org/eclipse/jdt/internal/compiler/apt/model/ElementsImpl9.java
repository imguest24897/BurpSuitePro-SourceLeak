/*     */ package org.eclipse.jdt.internal.compiler.apt.model;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.nio.charset.Charset;
/*     */ import java.nio.file.Files;
/*     */ import java.nio.file.Path;
/*     */ import java.util.Collections;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.Set;
/*     */ import javax.lang.model.AnnotatedConstruct;
/*     */ import javax.lang.model.element.AnnotationMirror;
/*     */ import javax.lang.model.element.Element;
/*     */ import javax.lang.model.element.ElementKind;
/*     */ import javax.lang.model.element.ExecutableElement;
/*     */ import javax.lang.model.element.ModuleElement;
/*     */ import javax.lang.model.element.PackageElement;
/*     */ import javax.lang.model.element.TypeElement;
/*     */ import javax.lang.model.util.Elements;
/*     */ import javax.tools.JavaFileManager;
/*     */ import javax.tools.JavaFileObject;
/*     */ import org.eclipse.jdt.core.compiler.CharOperation;
/*     */ import org.eclipse.jdt.internal.compiler.CompilationResult;
/*     */ import org.eclipse.jdt.internal.compiler.apt.dispatch.BaseProcessingEnvImpl;
/*     */ import org.eclipse.jdt.internal.compiler.impl.ReferenceContext;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.BinaryModuleBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.BinaryTypeBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.Binding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.LookupEnvironment;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.MethodBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.ModuleBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.PackageBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.ReferenceBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.SourceModuleBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.SourceTypeBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.TypeBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.TypeConstants;
/*     */ import org.eclipse.jdt.internal.compiler.tool.EclipseFileManager;
/*     */ import org.eclipse.jdt.internal.compiler.tool.PathFileObject;
/*     */ import org.eclipse.jdt.internal.compiler.util.HashtableOfModule;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ElementsImpl9
/*     */   extends ElementsImpl
/*     */ {
/*     */   public ElementsImpl9(BaseProcessingEnvImpl env) {
/*  64 */     super(env);
/*     */   }
/*     */ 
/*     */   
/*     */   public TypeElement getTypeElement(CharSequence name) {
/*  69 */     char[][] compoundName = CharOperation.splitOn('.', name.toString().toCharArray());
/*  70 */     Set<? extends ModuleElement> allModuleElements = getAllModuleElements();
/*  71 */     for (ModuleElement moduleElement : allModuleElements) {
/*  72 */       TypeElement t = getTypeElement(compoundName, ((ModuleElementImpl)moduleElement).binding);
/*  73 */       if (t != null) {
/*  74 */         return t;
/*     */       }
/*     */     } 
/*  77 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public TypeElement getTypeElement(ModuleElement module, CharSequence name) {
/*  82 */     ModuleBinding mBinding = ((ModuleElementImpl)module).binding;
/*  83 */     char[][] compoundName = CharOperation.splitOn('.', name.toString().toCharArray());
/*  84 */     return getTypeElement(compoundName, mBinding);
/*     */   }
/*     */   
/*     */   private TypeElement getTypeElement(char[][] compoundName, ModuleBinding mBinding) {
/*  88 */     LookupEnvironment le = (mBinding == null) ? this._env.getLookupEnvironment() : mBinding.environment;
/*  89 */     ReferenceBinding binding = (mBinding == null) ? le.getType(compoundName) : le.getType(compoundName, mBinding);
/*     */ 
/*     */     
/*  92 */     if (binding == null) {
/*  93 */       ReferenceBinding topLevelBinding = null;
/*  94 */       int topLevelSegments = compoundName.length;
/*  95 */       while (--topLevelSegments > 0) {
/*  96 */         char[][] topLevelName = new char[topLevelSegments][];
/*  97 */         for (int j = 0; j < topLevelSegments; j++) {
/*  98 */           topLevelName[j] = compoundName[j];
/*     */         }
/* 100 */         topLevelBinding = le.getType(topLevelName);
/* 101 */         if (topLevelBinding != null) {
/*     */           break;
/*     */         }
/*     */       } 
/* 105 */       if (topLevelBinding == null) {
/* 106 */         return null;
/*     */       }
/* 108 */       binding = topLevelBinding;
/* 109 */       for (int i = topLevelSegments; binding != null && i < compoundName.length; i++) {
/* 110 */         binding = binding.getMemberType(compoundName[i]);
/*     */       }
/*     */     } 
/* 113 */     if (binding == null) {
/* 114 */       return null;
/*     */     }
/* 116 */     if ((binding.tagBits & 0x80L) != 0L) {
/* 117 */       return null;
/*     */     }
/* 119 */     return new TypeElementImpl(this._env, binding, null);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Elements.Origin getOrigin(Element e) {
/* 125 */     return Elements.Origin.EXPLICIT;
/*     */   }
/*     */ 
/*     */   
/*     */   public Elements.Origin getOrigin(AnnotatedConstruct c, AnnotationMirror a) {
/* 130 */     return Elements.Origin.EXPLICIT;
/*     */   }
/*     */ 
/*     */   
/*     */   public Elements.Origin getOrigin(ModuleElement m, ModuleElement.Directive directive) {
/* 135 */     return Elements.Origin.EXPLICIT;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isBridge(ExecutableElement e) {
/* 140 */     MethodBinding methodBinding = (MethodBinding)((ExecutableElementImpl)e)._binding;
/* 141 */     return methodBinding.isBridge();
/*     */   }
/*     */ 
/*     */   
/*     */   public ModuleElement getModuleOf(Element elem) {
/* 146 */     if (elem instanceof ModuleElement) {
/* 147 */       return (ModuleElement)elem;
/*     */     }
/* 149 */     Element parent = elem.getEnclosingElement();
/* 150 */     while (parent != null) {
/* 151 */       if (parent instanceof ModuleElement) {
/* 152 */         return (ModuleElement)parent;
/*     */       }
/* 154 */       parent = parent.getEnclosingElement();
/*     */     } 
/* 156 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public ModuleElement getModuleElement(CharSequence name) {
/* 161 */     LookupEnvironment lookup = this._env.getLookupEnvironment();
/* 162 */     ModuleBinding binding = lookup.getModule((name.length() == 0) ? ModuleBinding.UNNAMED : name.toString().toCharArray());
/*     */     
/* 164 */     if (binding == null) {
/* 165 */       return null;
/*     */     }
/* 167 */     return new ModuleElementImpl(this._env, binding);
/*     */   }
/*     */ 
/*     */   
/*     */   public Set<? extends ModuleElement> getAllModuleElements() {
/* 172 */     LookupEnvironment lookup = this._env.getLookupEnvironment();
/* 173 */     HashtableOfModule knownModules = lookup.knownModules;
/* 174 */     ModuleBinding[] modules = knownModules.valueTable;
/* 175 */     if (modules == null || modules.length == 0) {
/* 176 */       return Collections.emptySet();
/*     */     }
/* 178 */     Set<ModuleElement> mods = new HashSet<>(modules.length); byte b; int i; ModuleBinding[] arrayOfModuleBinding1;
/* 179 */     for (i = (arrayOfModuleBinding1 = modules).length, b = 0; b < i; ) { ModuleBinding moduleBinding = arrayOfModuleBinding1[b];
/* 180 */       if (moduleBinding != null) {
/*     */         
/* 182 */         ModuleElement element = (ModuleElement)this._env.getFactory().newElement((Binding)moduleBinding);
/* 183 */         mods.add(element);
/*     */       }  b++; }
/* 185 */      mods.add((ModuleElement)this._env.getFactory().newElement((Binding)lookup.UnNamedModule));
/* 186 */     return mods;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public PackageElement getPackageElement(ModuleElement module, CharSequence name) {
/* 192 */     ModuleBinding mBinding = ((ModuleElementImpl)module).binding;
/* 193 */     char[][] compoundName = CharOperation.splitOn('.', name.toString().toCharArray());
/* 194 */     PackageBinding p = null;
/* 195 */     if (mBinding != null) {
/* 196 */       p = mBinding.getVisiblePackage(compoundName);
/*     */     } else {
/* 198 */       p = this._env.getLookupEnvironment().createPackage(compoundName);
/*     */     } 
/* 200 */     if (p == null || !p.isValidBinding())
/* 201 */       return null; 
/* 202 */     return (PackageElement)this._env.getFactory().newElement((Binding)p);
/*     */   }
/*     */   
/*     */   public boolean isAutomaticModule(ModuleElement module) {
/* 206 */     ModuleBinding mBinding = ((ModuleElementImpl)module).binding;
/* 207 */     return mBinding.isAutomatic(); } public JavaFileObject getFileObjectOf(Element element) { TypeElementImpl elementImpl; ReferenceBinding refBinding; ModuleElementImpl moduleEl; ModuleBinding mBinding;
/*     */     PackageElementImpl packEl;
/*     */     PackageBinding pBinding;
/*     */     Binding typeOrPackage;
/* 211 */     switch (element.getKind()) {
/*     */       case ENUM:
/*     */       case CLASS:
/*     */       case null:
/*     */       case INTERFACE:
/*     */       case RECORD:
/* 217 */         elementImpl = (TypeElementImpl)element;
/* 218 */         refBinding = (ReferenceBinding)elementImpl._binding;
/* 219 */         if (!refBinding.isBinaryBinding()) {
/* 220 */           TypeElementImpl outer = (TypeElementImpl)getOutermostTypeElement(element);
/* 221 */           refBinding = (ReferenceBinding)outer._binding;
/*     */         } 
/* 223 */         return getFileObjectForType((TypeBinding)refBinding);
/*     */       case MODULE:
/* 225 */         moduleEl = (ModuleElementImpl)element;
/* 226 */         mBinding = (ModuleBinding)moduleEl._binding;
/* 227 */         if (mBinding instanceof SourceModuleBinding) {
/* 228 */           SourceModuleBinding sourceModule = (SourceModuleBinding)mBinding;
/* 229 */           return getSourceJavaFileObject(sourceModule.scope.referenceContext());
/* 230 */         }  if (mBinding instanceof BinaryModuleBinding) {
/* 231 */           BinaryModuleBinding binaryBinding = (BinaryModuleBinding)mBinding;
/* 232 */           if (binaryBinding.path != null) {
/* 233 */             return (JavaFileObject)new PathFileObject(Path.of(binaryBinding.path), JavaFileObject.Kind.CLASS, Charset.defaultCharset());
/*     */           }
/*     */         } 
/*     */         break;
/*     */       case PACKAGE:
/* 238 */         packEl = (PackageElementImpl)element;
/* 239 */         pBinding = (PackageBinding)packEl._binding;
/* 240 */         typeOrPackage = pBinding.getTypeOrPackage(TypeConstants.PACKAGE_INFO_NAME, pBinding.enclosingModule, true);
/* 241 */         if (typeOrPackage != null) {
/* 242 */           return getFileObjectForType((TypeBinding)typeOrPackage);
/*     */         }
/*     */         break;
/*     */       case ENUM_CONSTANT:
/*     */       case FIELD:
/*     */       case PARAMETER:
/*     */       case LOCAL_VARIABLE:
/*     */       case METHOD:
/*     */       case CONSTRUCTOR:
/*     */       case RECORD_COMPONENT:
/* 252 */         if (element.getEnclosingElement() != null) {
/* 253 */           return getFileObjectOf(element.getEnclosingElement());
/*     */         }
/*     */         break;
/*     */     } 
/*     */ 
/*     */     
/* 259 */     return null; }
/*     */   
/*     */   private JavaFileObject getFileObjectForType(TypeBinding binding) {
/* 262 */     if (binding instanceof SourceTypeBinding) {
/* 263 */       SourceTypeBinding sourceTypeBinding = (SourceTypeBinding)binding;
/* 264 */       ReferenceContext referenceContext = sourceTypeBinding.scope.referenceContext();
/* 265 */       return getSourceJavaFileObject(referenceContext);
/* 266 */     }  if (binding instanceof BinaryTypeBinding) {
/* 267 */       BinaryTypeBinding binaryBinding = (BinaryTypeBinding)binding;
/* 268 */       if (binaryBinding.path != null) {
/* 269 */         Path of = Path.of(binaryBinding.path);
/* 270 */         if (Files.exists(of, new java.nio.file.LinkOption[0])) {
/* 271 */           return (JavaFileObject)new PathFileObject(of, JavaFileObject.Kind.CLASS, Charset.defaultCharset());
/*     */         }
/*     */       } 
/*     */     } 
/* 275 */     return null;
/*     */   }
/*     */   private JavaFileObject getSourceJavaFileObject(ReferenceContext referenceContext) {
/* 278 */     JavaFileManager fileManager = this._env.getFileManager();
/* 279 */     if (fileManager instanceof EclipseFileManager) {
/* 280 */       EclipseFileManager eFileManager = (EclipseFileManager)fileManager;
/* 281 */       CompilationResult compilationResult = referenceContext.compilationResult();
/* 282 */       String fileName = new String(compilationResult.fileName);
/* 283 */       File f = new File(fileName);
/* 284 */       if (f.exists()) {
/* 285 */         Iterator<? extends JavaFileObject> objects = eFileManager.getJavaFileObjects(new File[] { f }).iterator();
/* 286 */         if (objects.hasNext()) {
/* 287 */           return objects.next();
/*     */         }
/*     */       } 
/*     */     } else {
/* 291 */       throw new UnsupportedOperationException();
/*     */     } 
/* 293 */     return null;
/*     */   }
/*     */   
/*     */   public boolean isCanonicalConstructor(ExecutableElement e) {
/* 297 */     MethodBinding methodBinding = (MethodBinding)((ExecutableElementImpl)e)._binding;
/* 298 */     return methodBinding.isCanonicalConstructor();
/*     */   }
/*     */   
/*     */   public boolean isCompactConstructor(ExecutableElement e) {
/* 302 */     MethodBinding methodBinding = (MethodBinding)((ExecutableElementImpl)e)._binding;
/* 303 */     return methodBinding.isCompactConstructor();
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\apt\model\ElementsImpl9.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */