/*    */ package org.eclipse.jdt.internal.compiler.batch;
/*    */ 
/*    */ import org.eclipse.jdt.internal.compiler.CompilationResult;
/*    */ import org.eclipse.jdt.internal.compiler.ICompilerRequestor;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class BatchCompilerRequestor
/*    */   implements ICompilerRequestor
/*    */ {
/*    */   private Main compiler;
/* 22 */   private int lineDelta = 0;
/*    */   
/*    */   public BatchCompilerRequestor(Main compiler) {
/* 25 */     this.compiler = compiler;
/*    */   }
/*    */ 
/*    */   
/*    */   public void acceptResult(CompilationResult compilationResult) {
/* 30 */     if (compilationResult.lineSeparatorPositions != null) {
/* 31 */       int unitLineCount = compilationResult.lineSeparatorPositions.length;
/* 32 */       this.lineDelta += unitLineCount;
/* 33 */       if (this.compiler.showProgress && this.lineDelta > 2000) {
/*    */         
/* 35 */         this.compiler.logger.logProgress();
/* 36 */         this.lineDelta = 0;
/*    */       } 
/*    */     } 
/* 39 */     this.compiler.logger.startLoggingSource(compilationResult);
/* 40 */     if (compilationResult.hasProblems() || compilationResult.hasTasks()) {
/* 41 */       this.compiler.logger.logProblems(compilationResult.getAllProblems(), compilationResult.compilationUnit.getContents(), this.compiler);
/* 42 */       reportProblems(compilationResult);
/*    */     } 
/* 44 */     this.compiler.outputClassFiles(compilationResult);
/* 45 */     this.compiler.logger.endLoggingSource();
/*    */   }
/*    */   
/*    */   protected void reportProblems(CompilationResult result) {}
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\batch\BatchCompilerRequestor.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */