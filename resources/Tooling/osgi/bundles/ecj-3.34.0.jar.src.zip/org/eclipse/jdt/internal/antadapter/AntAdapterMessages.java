/*    */ package org.eclipse.jdt.internal.antadapter;
/*    */ 
/*    */ import java.text.MessageFormat;
/*    */ import java.util.Locale;
/*    */ import java.util.MissingResourceException;
/*    */ import java.util.ResourceBundle;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AntAdapterMessages
/*    */ {
/*    */   private static final String BUNDLE_NAME = "org.eclipse.jdt.internal.antadapter.messages";
/*    */   private static ResourceBundle RESOURCE_BUNDLE;
/*    */   
/*    */   static {
/*    */     try {
/* 29 */       RESOURCE_BUNDLE = ResourceBundle.getBundle("org.eclipse.jdt.internal.antadapter.messages", Locale.getDefault());
/* 30 */     } catch (MissingResourceException e) {
/* 31 */       System.out.println("Missing resource : " + "org.eclipse.jdt.internal.antadapter.messages".replace('.', '/') + ".properties for locale " + Locale.getDefault());
/* 32 */       throw e;
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static String getString(String key) {
/*    */     try {
/* 42 */       return RESOURCE_BUNDLE.getString(key);
/* 43 */     } catch (MissingResourceException missingResourceException) {
/* 44 */       return String.valueOf('!') + key + '!';
/*    */     } 
/*    */   }
/*    */   
/*    */   public static String getString(String key, String argument) {
/*    */     try {
/* 50 */       String message = RESOURCE_BUNDLE.getString(key);
/* 51 */       MessageFormat messageFormat = new MessageFormat(message);
/* 52 */       return messageFormat.format(new String[] { argument });
/* 53 */     } catch (MissingResourceException missingResourceException) {
/* 54 */       return String.valueOf('!') + key + '!';
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\antadapter\AntAdapterMessages.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */