/*     */ package org.eclipse.jdt.internal.compiler.apt.util;
/*     */ 
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ManyToMany<T1, T2>
/*     */ {
/*  43 */   private final Map<T1, Set<T2>> _forward = new HashMap<>();
/*  44 */   private final Map<T2, Set<T1>> _reverse = new HashMap<>();
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean _dirty = false;
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized boolean clear() {
/*  53 */     boolean hadContent = !(this._forward.isEmpty() && this._reverse.isEmpty());
/*  54 */     this._reverse.clear();
/*  55 */     this._forward.clear();
/*  56 */     this._dirty |= hadContent;
/*  57 */     return hadContent;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized void clearDirtyBit() {
/*  67 */     this._dirty = false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized boolean containsKey(T1 key) {
/*  75 */     return this._forward.containsKey(key);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized boolean containsKeyValuePair(T1 key, T2 value) {
/*  84 */     Set<T2> values = this._forward.get(key);
/*  85 */     if (values == null) {
/*  86 */       return false;
/*     */     }
/*  88 */     return values.contains(value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized boolean containsValue(T2 value) {
/*  97 */     return this._reverse.containsKey(value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized Set<T1> getKeys(T2 value) {
/* 107 */     Set<T1> keys = this._reverse.get(value);
/* 108 */     if (keys == null) {
/* 109 */       return Collections.emptySet();
/*     */     }
/* 111 */     return new HashSet<>(keys);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized Set<T2> getValues(T1 key) {
/* 121 */     Set<T2> values = this._forward.get(key);
/* 122 */     if (values == null) {
/* 123 */       return Collections.emptySet();
/*     */     }
/* 125 */     return new HashSet<>(values);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized Set<T1> getKeySet() {
/* 135 */     Set<T1> keys = new HashSet<>(this._forward.keySet());
/* 136 */     return keys;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized Set<T2> getValueSet() {
/* 146 */     Set<T2> values = new HashSet<>(this._reverse.keySet());
/* 147 */     return values;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized boolean isDirty() {
/* 159 */     return this._dirty;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized boolean keyHasOtherValues(T1 key, T2 value) {
/* 173 */     Set<T2> values = this._forward.get(key);
/* 174 */     if (values == null)
/* 175 */       return false; 
/* 176 */     int size = values.size();
/* 177 */     if (size == 0)
/* 178 */       return false; 
/* 179 */     if (size > 1) {
/* 180 */       return true;
/*     */     }
/* 182 */     return !values.contains(value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized boolean put(T1 key, T2 value) {
/* 197 */     Set<T2> values = this._forward.get(key);
/* 198 */     if (values == null) {
/* 199 */       values = new HashSet<>();
/* 200 */       this._forward.put(key, values);
/*     */     } 
/* 202 */     boolean added = values.add(value);
/* 203 */     this._dirty |= added;
/*     */ 
/*     */     
/* 206 */     Set<T1> keys = this._reverse.get(value);
/* 207 */     if (keys == null) {
/* 208 */       keys = new HashSet<>();
/* 209 */       this._reverse.put(value, keys);
/*     */     } 
/* 211 */     keys.add(key);
/*     */     
/* 213 */     assert checkIntegrity();
/* 214 */     return added;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized boolean remove(T1 key, T2 value) {
/* 225 */     Set<T2> values = this._forward.get(key);
/* 226 */     if (values == null) {
/* 227 */       assert checkIntegrity();
/* 228 */       return false;
/*     */     } 
/* 230 */     boolean removed = values.remove(value);
/* 231 */     if (values.isEmpty()) {
/* 232 */       this._forward.remove(key);
/*     */     }
/* 234 */     if (removed) {
/* 235 */       this._dirty = true;
/*     */       
/* 237 */       Set<T1> keys = this._reverse.get(value);
/* 238 */       keys.remove(key);
/* 239 */       if (keys.isEmpty()) {
/* 240 */         this._reverse.remove(value);
/*     */       }
/*     */     } 
/* 243 */     assert checkIntegrity();
/* 244 */     return removed;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized boolean removeKey(T1 key) {
/* 255 */     Set<T2> values = this._forward.get(key);
/* 256 */     if (values == null) {
/*     */       
/* 258 */       assert checkIntegrity();
/* 259 */       return false;
/*     */     } 
/* 261 */     for (T2 value : values) {
/* 262 */       Set<T1> keys = this._reverse.get(value);
/* 263 */       if (keys != null) {
/* 264 */         keys.remove(key);
/* 265 */         if (keys.isEmpty()) {
/* 266 */           this._reverse.remove(value);
/*     */         }
/*     */       } 
/*     */     } 
/*     */     
/* 271 */     this._forward.remove(key);
/* 272 */     this._dirty = true;
/* 273 */     assert checkIntegrity();
/* 274 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized boolean removeValue(T2 value) {
/* 285 */     Set<T1> keys = this._reverse.get(value);
/* 286 */     if (keys == null) {
/*     */       
/* 288 */       assert checkIntegrity();
/* 289 */       return false;
/*     */     } 
/* 291 */     for (T1 key : keys) {
/* 292 */       Set<T2> values = this._forward.get(key);
/* 293 */       if (values != null) {
/* 294 */         values.remove(value);
/* 295 */         if (values.isEmpty()) {
/* 296 */           this._forward.remove(key);
/*     */         }
/*     */       } 
/*     */     } 
/*     */     
/* 301 */     this._reverse.remove(value);
/* 302 */     this._dirty = true;
/* 303 */     assert checkIntegrity();
/* 304 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized boolean valueHasOtherKeys(T2 value, T1 key) {
/* 318 */     Set<T1> keys = this._reverse.get(value);
/* 319 */     if (keys == null)
/* 320 */       return false; 
/* 321 */     int size = keys.size();
/* 322 */     if (size == 0)
/* 323 */       return false; 
/* 324 */     if (size > 1) {
/* 325 */       return true;
/*     */     }
/* 327 */     return !keys.contains(key);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean checkIntegrity() {
/* 340 */     for (Map.Entry<T1, Set<T2>> entry : this._forward.entrySet()) {
/* 341 */       Set<T2> values = entry.getValue();
/* 342 */       if (values.isEmpty()) {
/* 343 */         throw new IllegalStateException("Integrity compromised: forward map contains an empty set");
/*     */       }
/* 345 */       for (T2 value : values) {
/* 346 */         Set<T1> keys = this._reverse.get(value);
/* 347 */         if (keys == null || !keys.contains(entry.getKey())) {
/* 348 */           throw new IllegalStateException("Integrity compromised: forward map contains an entry missing from reverse map: " + value);
/*     */         }
/*     */       } 
/*     */     } 
/*     */     
/* 353 */     for (Map.Entry<T2, Set<T1>> entry : this._reverse.entrySet()) {
/* 354 */       Set<T1> keys = entry.getValue();
/* 355 */       if (keys.isEmpty()) {
/* 356 */         throw new IllegalStateException("Integrity compromised: reverse map contains an empty set");
/*     */       }
/* 358 */       for (T1 key : keys) {
/* 359 */         Set<T2> values = this._forward.get(key);
/* 360 */         if (values == null || !values.contains(entry.getKey())) {
/* 361 */           throw new IllegalStateException("Integrity compromised: reverse map contains an entry missing from forward map: " + key);
/*     */         }
/*     */       } 
/*     */     } 
/* 365 */     return true;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\ap\\util\ManyToMany.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */