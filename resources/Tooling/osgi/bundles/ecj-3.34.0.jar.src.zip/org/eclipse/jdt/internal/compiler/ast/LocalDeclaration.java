/*     */ package org.eclipse.jdt.internal.compiler.ast;
/*     */ 
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import org.eclipse.jdt.internal.compiler.ASTVisitor;
/*     */ import org.eclipse.jdt.internal.compiler.codegen.AnnotationContext;
/*     */ import org.eclipse.jdt.internal.compiler.codegen.CodeStream;
/*     */ import org.eclipse.jdt.internal.compiler.flow.FlowContext;
/*     */ import org.eclipse.jdt.internal.compiler.flow.FlowInfo;
/*     */ import org.eclipse.jdt.internal.compiler.flow.UnconditionalFlowInfo;
/*     */ import org.eclipse.jdt.internal.compiler.impl.Constant;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.ArrayBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.Binding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.BlockScope;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.LocalVariableBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.NullTypeBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.ReferenceBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.Scope;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.TypeBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.TypeBindingVisitor;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.TypeVariableBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.VariableBinding;
/*     */ import org.eclipse.jdt.internal.compiler.parser.RecoveryScanner;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LocalDeclaration
/*     */   extends AbstractVariableDeclaration
/*     */ {
/*     */   public LocalVariableBinding binding;
/*     */   
/*     */   public LocalDeclaration(char[] name, int sourceStart, int sourceEnd) {
/*  67 */     this.name = name;
/*  68 */     this.sourceStart = sourceStart;
/*  69 */     this.sourceEnd = sourceEnd;
/*  70 */     this.declarationEnd = sourceEnd;
/*     */   }
/*     */ 
/*     */   
/*     */   public FlowInfo analyseCode(BlockScope currentScope, FlowContext flowContext, FlowInfo flowInfo) {
/*     */     UnconditionalFlowInfo unconditionalFlowInfo2;
/*  76 */     if ((flowInfo.tagBits & 0x1) == 0) {
/*  77 */       this.bits |= 0x40000000;
/*     */     }
/*  79 */     if (this.initialization == null) {
/*  80 */       return flowInfo;
/*     */     }
/*  82 */     this.initialization.checkNPEbyUnboxing(currentScope, flowContext, flowInfo);
/*     */     
/*  84 */     FlowInfo preInitInfo = null;
/*  85 */     boolean shouldAnalyseResource = (this.binding != null && 
/*  86 */       flowInfo.reachMode() == 0 && 
/*  87 */       (currentScope.compilerOptions()).analyseResourceLeaks && 
/*  88 */       FakedTrackingVariable.isAnyCloseable(this.initialization.resolvedType));
/*  89 */     if (shouldAnalyseResource) {
/*  90 */       unconditionalFlowInfo2 = flowInfo.unconditionalCopy();
/*     */       
/*  92 */       FakedTrackingVariable.preConnectTrackerAcrossAssignment(this, this.binding, this.initialization, flowInfo);
/*     */     } 
/*     */     
/*  95 */     UnconditionalFlowInfo unconditionalFlowInfo1 = 
/*  96 */       this.initialization
/*  97 */       .analyseCode(currentScope, flowContext, flowInfo)
/*  98 */       .unconditionalInits();
/*     */     
/* 100 */     if (shouldAnalyseResource) {
/* 101 */       FakedTrackingVariable.handleResourceAssignment(currentScope, (FlowInfo)unconditionalFlowInfo2, (FlowInfo)unconditionalFlowInfo1, flowContext, this, this.initialization, this.binding);
/*     */     } else {
/* 103 */       FakedTrackingVariable.cleanUpAfterAssignment(currentScope, 2, this.initialization);
/*     */     } 
/* 105 */     int nullStatus = this.initialization.nullStatus((FlowInfo)unconditionalFlowInfo1, flowContext);
/* 106 */     if (!unconditionalFlowInfo1.isDefinitelyAssigned(this.binding)) {
/* 107 */       this.bits |= 0x8;
/*     */     } else {
/* 109 */       this.bits &= 0xFFFFFFF7;
/*     */     } 
/* 111 */     unconditionalFlowInfo1.markAsDefinitelyAssigned(this.binding);
/* 112 */     if ((currentScope.compilerOptions()).isAnnotationBasedNullAnalysisEnabled) {
/* 113 */       nullStatus = NullAnnotationMatching.checkAssignment(currentScope, flowContext, (VariableBinding)this.binding, (FlowInfo)unconditionalFlowInfo1, nullStatus, this.initialization, this.initialization.resolvedType);
/*     */     }
/* 115 */     if ((this.binding.type.tagBits & 0x2L) == 0L) {
/* 116 */       unconditionalFlowInfo1.markNullStatus(this.binding, nullStatus);
/*     */     }
/*     */ 
/*     */     
/* 120 */     return (FlowInfo)unconditionalFlowInfo1;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void checkModifiers() {
/* 126 */     if ((this.modifiers & 0xFFFF & 0xFFFFFFEF) != 0)
/*     */     {
/*     */ 
/*     */ 
/*     */       
/* 131 */       this.modifiers = this.modifiers & 0xFFBFFFFF | 0x800000;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void generateCode(BlockScope currentScope, CodeStream codeStream) {
/* 142 */     if (this.binding.resolvedPosition != -1) {
/* 143 */       codeStream.addVisibleLocalVariable(this.binding);
/*     */     }
/* 145 */     if ((this.bits & Integer.MIN_VALUE) == 0) {
/*     */       return;
/*     */     }
/* 148 */     int pc = codeStream.position;
/*     */ 
/*     */ 
/*     */     
/* 152 */     if (this.initialization != null)
/*     */     {
/*     */       
/* 155 */       if (this.binding.resolvedPosition < 0) {
/* 156 */         if (this.initialization.constant == Constant.NotAConstant)
/*     */         {
/*     */           
/* 159 */           this.initialization.generateCode(currentScope, codeStream, false);
/*     */         }
/*     */       } else {
/* 162 */         this.initialization.generateCode(currentScope, codeStream, true);
/*     */         
/* 164 */         if (this.binding.type.isArrayType() && 
/* 165 */           this.initialization instanceof CastExpression && 
/* 166 */           (((CastExpression)this.initialization).innermostCastedExpression()).resolvedType == TypeBinding.NULL) {
/* 167 */           codeStream.checkcast(this.binding.type);
/*     */         }
/* 169 */         codeStream.store(this.binding, false);
/* 170 */         if ((this.bits & 0x8) != 0)
/*     */         {
/*     */ 
/*     */           
/* 174 */           this.binding.recordInitializationStartPC(codeStream.position); } 
/*     */       } 
/*     */     }
/* 177 */     codeStream.recordPositionsFrom(pc, this.sourceStart);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getKind() {
/* 185 */     return 4;
/*     */   }
/*     */ 
/*     */   
/*     */   public void getAllAnnotationContexts(int targetType, LocalVariableBinding localVariable, List<AnnotationContext> allAnnotationContexts) {
/* 190 */     TypeReference.AnnotationCollector collector = new TypeReference.AnnotationCollector(this, targetType, localVariable, allAnnotationContexts);
/* 191 */     traverseWithoutInitializer(collector, (BlockScope)null);
/*     */   }
/*     */ 
/*     */   
/*     */   public void getAllAnnotationContexts(int targetType, int parameterIndex, List<AnnotationContext> allAnnotationContexts) {
/* 196 */     TypeReference.AnnotationCollector collector = new TypeReference.AnnotationCollector(this, targetType, parameterIndex, allAnnotationContexts);
/* 197 */     traverse(collector, (BlockScope)null);
/*     */   }
/*     */   
/*     */   public boolean isArgument() {
/* 201 */     return false;
/*     */   }
/*     */   public boolean isReceiver() {
/* 204 */     return false;
/*     */   }
/*     */   
/*     */   public TypeBinding patchType(TypeBinding newType) {
/* 208 */     TypeVariableBinding[] arrayOfTypeVariableBinding = findCapturedTypeVariables(newType);
/* 209 */     if (arrayOfTypeVariableBinding != null && arrayOfTypeVariableBinding.length > 0) {
/* 210 */       newType = newType.upwardsProjection((Scope)this.binding.declaringScope, (TypeBinding[])arrayOfTypeVariableBinding);
/*     */     }
/* 212 */     this.type.resolvedType = newType;
/* 213 */     if (this.binding != null) {
/* 214 */       this.binding.type = newType;
/* 215 */       this.binding.markInitialized();
/*     */     } 
/* 217 */     return this.type.resolvedType;
/*     */   }
/*     */   
/*     */   private TypeVariableBinding[] findCapturedTypeVariables(TypeBinding typeBinding) {
/* 221 */     final Set<TypeVariableBinding> mentioned = new HashSet<>();
/* 222 */     TypeBindingVisitor.visit(new TypeBindingVisitor()
/*     */         {
/*     */           public boolean visit(TypeVariableBinding typeVariable) {
/* 225 */             if (typeVariable.isCapture())
/* 226 */               mentioned.add(typeVariable); 
/* 227 */             return super.visit(typeVariable);
/*     */           }
/* 229 */         },  typeBinding);
/* 230 */     if (mentioned.isEmpty()) return null; 
/* 231 */     return mentioned.<TypeVariableBinding>toArray(new TypeVariableBinding[mentioned.size()]);
/*     */   }
/*     */ 
/*     */   
/*     */   private static Expression findPolyExpression(Expression e) {
/* 236 */     if (e instanceof FunctionalExpression) {
/* 237 */       return e;
/*     */     }
/* 239 */     if (e instanceof ConditionalExpression) {
/* 240 */       ConditionalExpression ce = (ConditionalExpression)e;
/* 241 */       Expression candidate = findPolyExpression(ce.valueIfTrue);
/* 242 */       if (candidate == null) {
/* 243 */         candidate = findPolyExpression(ce.valueIfFalse);
/*     */       }
/* 245 */       if (candidate != null) return candidate; 
/*     */     } 
/* 247 */     if (e instanceof SwitchExpression) {
/* 248 */       SwitchExpression se = (SwitchExpression)e;
/* 249 */       for (Expression re : se.resultExpressions) {
/* 250 */         Expression candidate = findPolyExpression(re);
/* 251 */         if (candidate != null) return candidate; 
/*     */       } 
/*     */     } 
/* 254 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public void resolve(BlockScope scope) {
/* 259 */     resolve(scope, false);
/*     */   }
/*     */   
/*     */   public void resolve(final BlockScope scope, boolean isPatternVariable) {
/* 263 */     handleNonNullByDefault(scope, this.annotations, this);
/*     */     
/* 265 */     TypeBinding variableType = null;
/* 266 */     boolean variableTypeInferenceError = false;
/* 267 */     boolean isTypeNameVar = isTypeNameVar((Scope)scope);
/* 268 */     if (isTypeNameVar && !isPatternVariable) {
/* 269 */       if ((this.bits & 0x10) == 0)
/*     */       {
/* 271 */         if (this.initialization != null) {
/* 272 */           variableType = checkInferredLocalVariableInitializer(scope);
/* 273 */           variableTypeInferenceError = (variableType != null);
/*     */         } else {
/*     */           
/* 276 */           scope.problemReporter().varLocalWithoutInitizalier(this);
/* 277 */           ReferenceBinding referenceBinding = scope.getJavaLangObject();
/* 278 */           variableTypeInferenceError = true;
/*     */         } 
/*     */       }
/*     */     } else {
/* 282 */       variableType = this.type.resolveType(scope, true);
/*     */     } 
/*     */     
/* 285 */     this.bits |= this.type.bits & 0x100000;
/* 286 */     checkModifiers();
/* 287 */     if (variableType != null) {
/* 288 */       if (variableType == TypeBinding.VOID) {
/* 289 */         scope.problemReporter().variableTypeCannotBeVoid(this);
/*     */         return;
/*     */       } 
/* 292 */       if (variableType.isArrayType() && ((ArrayBinding)variableType).leafComponentType == TypeBinding.VOID) {
/* 293 */         scope.problemReporter().variableTypeCannotBeVoidArray(this);
/*     */         
/*     */         return;
/*     */       } 
/*     */     } 
/* 298 */     Binding existingVariable = scope.getBinding(this.name, 3, this, false);
/* 299 */     if (existingVariable != null && existingVariable.isValidBinding()) {
/* 300 */       boolean localExists = existingVariable instanceof LocalVariableBinding;
/* 301 */       if (localExists && (this.bits & 0x200000) != 0 && scope.isLambdaSubscope() && this.hiddenVariableDepth == 0) {
/* 302 */         scope.problemReporter().lambdaRedeclaresLocal(this);
/* 303 */       } else if (localExists && this.hiddenVariableDepth == 0) {
/* 304 */         scope.problemReporter().redefineLocal(this);
/*     */       } else {
/* 306 */         scope.problemReporter().localVariableHiding(this, existingVariable, false);
/*     */       } 
/*     */     } 
/*     */     
/* 310 */     if ((this.modifiers & 0x10) != 0 && this.initialization == null) {
/* 311 */       this.modifiers |= 0x4000000;
/*     */     }
/* 313 */     if (isTypeNameVar) {
/*     */ 
/*     */       
/* 316 */       this.binding = new LocalVariableBinding(this, (variableType != null) ? variableType : (TypeBinding)scope.getJavaLangObject(), this.modifiers, false)
/*     */         {
/*     */           private boolean isInitialized = false;
/*     */           
/*     */           public void markReferenced() {
/* 321 */             if (!this.isInitialized) {
/* 322 */               scope.problemReporter().varLocalReferencesItself(LocalDeclaration.this);
/* 323 */               this.type = null;
/* 324 */               this.isInitialized = true;
/*     */             } 
/*     */           }
/*     */           
/*     */           public void markInitialized() {
/* 329 */             this.isInitialized = true;
/*     */           }
/*     */         };
/*     */     } else {
/*     */       
/* 334 */       this.binding = new LocalVariableBinding(this, variableType, this.modifiers, false);
/*     */     } 
/* 336 */     scope.addLocalVariable(this.binding);
/* 337 */     this.binding.setConstant(Constant.NotAConstant);
/*     */ 
/*     */ 
/*     */     
/* 341 */     if (variableType == null && 
/* 342 */       this.initialization != null) {
/* 343 */       if (this.initialization instanceof CastExpression) {
/* 344 */         ((CastExpression)this.initialization).setVarTypeDeclaration(true);
/*     */       }
/* 346 */       this.initialization.resolveType(scope);
/* 347 */       if (isTypeNameVar && this.initialization.resolvedType != null) {
/* 348 */         if (TypeBinding.equalsEquals((TypeBinding)TypeBinding.NULL, this.initialization.resolvedType)) {
/* 349 */           scope.problemReporter().varLocalInitializedToNull(this);
/* 350 */           variableTypeInferenceError = true;
/* 351 */         } else if (TypeBinding.equalsEquals((TypeBinding)TypeBinding.VOID, this.initialization.resolvedType)) {
/* 352 */           scope.problemReporter().varLocalInitializedToVoid(this);
/* 353 */           variableTypeInferenceError = true;
/*     */         } 
/* 355 */         variableType = patchType(this.initialization.resolvedType);
/*     */       } else {
/* 357 */         variableTypeInferenceError = true;
/*     */       } 
/*     */     } 
/*     */     
/* 361 */     this.binding.markInitialized();
/* 362 */     if (variableTypeInferenceError) {
/*     */       return;
/*     */     }
/* 365 */     boolean resolveAnnotationsEarly = false;
/* 366 */     if (scope.environment().usesNullTypeAnnotations() && 
/* 367 */       !isTypeNameVar && 
/* 368 */       variableType != null && variableType.isValidBinding()) {
/* 369 */       resolveAnnotationsEarly = !(!(this.initialization instanceof Invocation) && 
/* 370 */         !(this.initialization instanceof ConditionalExpression) && 
/* 371 */         !(this.initialization instanceof SwitchExpression) && 
/* 372 */         !(this.initialization instanceof ArrayInitializer));
/*     */     }
/* 374 */     if (resolveAnnotationsEarly) {
/*     */       
/* 376 */       resolveAnnotations(scope, this.annotations, (Binding)this.binding, true);
/*     */       
/* 378 */       variableType = this.type.resolvedType;
/*     */     } 
/* 380 */     if (this.initialization != null) {
/* 381 */       if (this.initialization instanceof ArrayInitializer) {
/* 382 */         TypeBinding initializationType = this.initialization.resolveTypeExpecting(scope, variableType);
/* 383 */         if (initializationType != null) {
/* 384 */           ((ArrayInitializer)this.initialization).binding = (ArrayBinding)initializationType;
/* 385 */           this.initialization.computeConversion((Scope)scope, variableType, initializationType);
/*     */         } 
/*     */       } else {
/* 388 */         this.initialization.setExpressionContext(isTypeNameVar ? ExpressionContext.VANILLA_CONTEXT : ExpressionContext.ASSIGNMENT_CONTEXT);
/* 389 */         this.initialization.setExpectedType(variableType);
/* 390 */         TypeBinding initializationType = (this.initialization.resolvedType != null) ? this.initialization.resolvedType : this.initialization.resolveType(scope);
/* 391 */         if (initializationType != null) {
/* 392 */           if (TypeBinding.notEquals(variableType, initializationType))
/* 393 */             scope.compilationUnitScope().recordTypeConversion(variableType, initializationType); 
/* 394 */           if (this.initialization.isConstantValueOfTypeAssignableToType(initializationType, variableType) || 
/* 395 */             initializationType.isCompatibleWith(variableType, (Scope)scope)) {
/* 396 */             this.initialization.computeConversion((Scope)scope, variableType, initializationType);
/* 397 */             if (initializationType.needsUncheckedConversion(variableType)) {
/* 398 */               scope.problemReporter().unsafeTypeConversion(this.initialization, initializationType, variableType);
/*     */             }
/* 400 */             if (this.initialization instanceof CastExpression && (
/* 401 */               this.initialization.bits & 0x4000) == 0) {
/* 402 */               CastExpression.checkNeedForAssignedCast(scope, variableType, (CastExpression)this.initialization);
/*     */             }
/* 404 */           } else if (isBoxingCompatible(initializationType, variableType, this.initialization, (Scope)scope)) {
/* 405 */             this.initialization.computeConversion((Scope)scope, variableType, initializationType);
/* 406 */             if (this.initialization instanceof CastExpression && (
/* 407 */               this.initialization.bits & 0x4000) == 0) {
/* 408 */               CastExpression.checkNeedForAssignedCast(scope, variableType, (CastExpression)this.initialization);
/*     */             }
/*     */           }
/* 411 */           else if ((variableType.tagBits & 0x80L) == 0L) {
/*     */             
/* 413 */             scope.problemReporter().typeMismatchError(initializationType, variableType, this.initialization, null);
/*     */           } 
/*     */         } 
/*     */       } 
/*     */ 
/*     */       
/* 419 */       if (this.binding == Expression.getDirectBinding(this.initialization)) {
/* 420 */         scope.problemReporter().assignmentHasNoEffect(this, this.name);
/*     */       }
/*     */ 
/*     */ 
/*     */       
/* 425 */       this.binding.setConstant(
/* 426 */           this.binding.isFinal() ? 
/* 427 */           this.initialization.constant.castTo((variableType.id << 4) + this.initialization.constant.typeID()) : 
/* 428 */           Constant.NotAConstant);
/*     */     } 
/*     */     
/* 431 */     if (!resolveAnnotationsEarly)
/* 432 */       resolveAnnotations(scope, this.annotations, (Binding)this.binding, true); 
/* 433 */     Annotation.isTypeUseCompatible(this.type, (Scope)scope, this.annotations);
/* 434 */     validateNullAnnotations(scope);
/*     */   }
/*     */   
/*     */   void validateNullAnnotations(BlockScope scope) {
/* 438 */     if (!scope.validateNullAnnotation(this.binding.tagBits, this.type, this.annotations)) {
/* 439 */       this.binding.tagBits &= 0xFE7FFFFFFFFFFFFFL;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private TypeBinding checkInferredLocalVariableInitializer(BlockScope scope) {
/* 447 */     TypeBinding errorType = null;
/* 448 */     if (this.initialization instanceof ArrayInitializer) {
/* 449 */       scope.problemReporter().varLocalCannotBeArrayInitalizers(this);
/* 450 */       ArrayBinding arrayBinding = scope.createArrayType((TypeBinding)scope.getJavaLangObject(), 1);
/*     */     } else {
/*     */       
/* 453 */       Expression polyExpression = findPolyExpression(this.initialization);
/* 454 */       if (polyExpression instanceof ReferenceExpression) {
/* 455 */         scope.problemReporter().varLocalCannotBeMethodReference(this);
/* 456 */         NullTypeBinding nullTypeBinding = TypeBinding.NULL;
/* 457 */       } else if (polyExpression != null) {
/* 458 */         scope.problemReporter().varLocalCannotBeLambda(this);
/* 459 */         NullTypeBinding nullTypeBinding = TypeBinding.NULL;
/*     */       } 
/*     */     } 
/* 462 */     if (this.type.dimensions() > 0 || this.type.extraDimensions() > 0) {
/* 463 */       scope.problemReporter().varLocalCannotBeArray(this);
/* 464 */       ArrayBinding arrayBinding = scope.createArrayType((TypeBinding)scope.getJavaLangObject(), 1);
/*     */     } 
/* 466 */     if ((this.bits & 0x400000) != 0) {
/* 467 */       scope.problemReporter().varLocalMultipleDeclarators(this);
/* 468 */       errorType = this.initialization.resolveType(scope);
/*     */     } 
/* 470 */     return errorType;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void traverse(ASTVisitor visitor, BlockScope scope) {
/* 476 */     if (visitor.visit(this, scope)) {
/* 477 */       if (this.annotations != null) {
/* 478 */         int annotationsLength = this.annotations.length;
/* 479 */         for (int i = 0; i < annotationsLength; i++)
/* 480 */           this.annotations[i].traverse(visitor, scope); 
/*     */       } 
/* 482 */       this.type.traverse(visitor, scope);
/* 483 */       if (this.initialization != null)
/* 484 */         this.initialization.traverse(visitor, scope); 
/*     */     } 
/* 486 */     visitor.endVisit(this, scope);
/*     */   }
/*     */   
/*     */   private void traverseWithoutInitializer(ASTVisitor visitor, BlockScope scope) {
/* 490 */     if (visitor.visit(this, scope)) {
/* 491 */       if (this.annotations != null) {
/* 492 */         int annotationsLength = this.annotations.length;
/* 493 */         for (int i = 0; i < annotationsLength; i++)
/* 494 */           this.annotations[i].traverse(visitor, scope); 
/*     */       } 
/* 496 */       this.type.traverse(visitor, scope);
/*     */     } 
/* 498 */     visitor.endVisit(this, scope);
/*     */   }
/*     */   
/*     */   public boolean isRecoveredFromLoneIdentifier() {
/* 502 */     return (this.name == RecoveryScanner.FAKE_IDENTIFIER && (
/* 503 */       this.type instanceof SingleTypeReference || (this.type instanceof QualifiedTypeReference && !(this.type instanceof ArrayQualifiedTypeReference))) && this.initialization == null && !this.type.isBaseTypeReference());
/*     */   }
/*     */   
/*     */   public boolean isTypeNameVar(Scope scope) {
/* 507 */     return (this.type != null && this.type.isTypeNameVar(scope));
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\ast\LocalDeclaration.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */