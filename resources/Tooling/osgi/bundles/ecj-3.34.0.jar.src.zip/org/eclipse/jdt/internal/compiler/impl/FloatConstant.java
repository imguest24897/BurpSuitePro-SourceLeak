/*    */ package org.eclipse.jdt.internal.compiler.impl;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FloatConstant
/*    */   extends Constant
/*    */ {
/*    */   float value;
/*    */   
/*    */   public static Constant fromValue(float value) {
/* 21 */     return new FloatConstant(value);
/*    */   }
/*    */   
/*    */   private FloatConstant(float value) {
/* 25 */     this.value = value;
/*    */   }
/*    */ 
/*    */   
/*    */   public byte byteValue() {
/* 30 */     return (byte)(int)this.value;
/*    */   }
/*    */ 
/*    */   
/*    */   public char charValue() {
/* 35 */     return (char)(int)this.value;
/*    */   }
/*    */ 
/*    */   
/*    */   public double doubleValue() {
/* 40 */     return this.value;
/*    */   }
/*    */ 
/*    */   
/*    */   public float floatValue() {
/* 45 */     return this.value;
/*    */   }
/*    */ 
/*    */   
/*    */   public int intValue() {
/* 50 */     return (int)this.value;
/*    */   }
/*    */ 
/*    */   
/*    */   public long longValue() {
/* 55 */     return (long)this.value;
/*    */   }
/*    */ 
/*    */   
/*    */   public short shortValue() {
/* 60 */     return (short)(int)this.value;
/*    */   }
/*    */ 
/*    */   
/*    */   public String stringValue() {
/* 65 */     return String.valueOf(this.value);
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 70 */     return "(float)" + this.value;
/*    */   }
/*    */ 
/*    */   
/*    */   public int typeID() {
/* 75 */     return 9;
/*    */   }
/*    */ 
/*    */   
/*    */   public int hashCode() {
/* 80 */     return Float.floatToIntBits(this.value);
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean equals(Object obj) {
/* 85 */     if (this == obj) {
/* 86 */       return true;
/*    */     }
/* 88 */     if (obj == null) {
/* 89 */       return false;
/*    */     }
/* 91 */     if (getClass() != obj.getClass()) {
/* 92 */       return false;
/*    */     }
/* 94 */     FloatConstant other = (FloatConstant)obj;
/* 95 */     return (Float.floatToIntBits(this.value) == Float.floatToIntBits(other.value));
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\impl\FloatConstant.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */