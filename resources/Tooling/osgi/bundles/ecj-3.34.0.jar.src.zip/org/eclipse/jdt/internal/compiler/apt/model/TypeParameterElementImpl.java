/*     */ package org.eclipse.jdt.internal.compiler.apt.model;
/*     */ 
/*     */ import java.lang.reflect.Array;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import javax.lang.model.element.AnnotationMirror;
/*     */ import javax.lang.model.element.Element;
/*     */ import javax.lang.model.element.ElementKind;
/*     */ import javax.lang.model.element.ElementVisitor;
/*     */ import javax.lang.model.element.PackageElement;
/*     */ import javax.lang.model.element.TypeParameterElement;
/*     */ import javax.lang.model.type.TypeMirror;
/*     */ import org.eclipse.jdt.internal.compiler.apt.dispatch.BaseProcessingEnvImpl;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.AnnotationBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.Binding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.LookupEnvironment;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.ReferenceBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.TypeBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.TypeVariableBinding;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TypeParameterElementImpl
/*     */   extends ElementImpl
/*     */   implements TypeParameterElement
/*     */ {
/*     */   private final Element _declaringElement;
/*  49 */   private List<? extends TypeMirror> _bounds = null;
/*     */   
/*     */   TypeParameterElementImpl(BaseProcessingEnvImpl env, TypeVariableBinding binding, Element declaringElement) {
/*  52 */     super(env, (Binding)binding);
/*  53 */     this._declaringElement = declaringElement;
/*     */   }
/*     */   
/*     */   TypeParameterElementImpl(BaseProcessingEnvImpl env, TypeVariableBinding binding) {
/*  57 */     super(env, (Binding)binding);
/*  58 */     this._declaringElement = this._env.getFactory().newElement(binding.declaringElement);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public List<? extends TypeMirror> getBounds() {
/*  64 */     if (this._bounds == null) {
/*  65 */       this._bounds = calculateBounds();
/*     */     }
/*  67 */     return this._bounds;
/*     */   }
/*     */ 
/*     */   
/*     */   private List<? extends TypeMirror> calculateBounds() {
/*  72 */     TypeVariableBinding typeVariableBinding = (TypeVariableBinding)this._binding;
/*  73 */     ReferenceBinding varSuperclass = typeVariableBinding.superclass();
/*  74 */     TypeBinding firstClassOrArrayBound = typeVariableBinding.firstBound;
/*  75 */     int boundsLength = 0;
/*  76 */     boolean isFirstBoundATypeVariable = false;
/*  77 */     if (firstClassOrArrayBound != null) {
/*  78 */       if (firstClassOrArrayBound.isTypeVariable()) {
/*  79 */         isFirstBoundATypeVariable = true;
/*     */       }
/*  81 */       if (TypeBinding.equalsEquals(firstClassOrArrayBound, (TypeBinding)varSuperclass)) {
/*  82 */         boundsLength++;
/*  83 */         if (firstClassOrArrayBound.isTypeVariable()) {
/*  84 */           isFirstBoundATypeVariable = true;
/*     */         }
/*  86 */       } else if (firstClassOrArrayBound.isArrayType()) {
/*  87 */         boundsLength++;
/*     */       } else {
/*  89 */         firstClassOrArrayBound = null;
/*     */       } 
/*     */     } 
/*  92 */     ReferenceBinding[] superinterfaces = typeVariableBinding.superInterfaces();
/*  93 */     int superinterfacesLength = 0;
/*  94 */     if (superinterfaces != null) {
/*  95 */       superinterfacesLength = superinterfaces.length;
/*  96 */       boundsLength += superinterfacesLength;
/*     */     } 
/*  98 */     List<TypeMirror> typeBounds = new ArrayList<>(boundsLength);
/*  99 */     if (boundsLength != 0) {
/* 100 */       if (firstClassOrArrayBound != null) {
/* 101 */         TypeMirror typeBinding = this._env.getFactory().newTypeMirror((Binding)firstClassOrArrayBound);
/* 102 */         if (typeBinding == null) {
/* 103 */           return Collections.emptyList();
/*     */         }
/* 105 */         typeBounds.add(typeBinding);
/*     */       } 
/*     */       
/* 108 */       if (superinterfaces != null && !isFirstBoundATypeVariable) {
/* 109 */         for (int i = 0; i < superinterfacesLength; i++) {
/* 110 */           TypeMirror typeBinding = this._env.getFactory().newTypeMirror((Binding)superinterfaces[i]);
/* 111 */           if (typeBinding == null) {
/* 112 */             return Collections.emptyList();
/*     */           }
/* 114 */           typeBounds.add(typeBinding);
/*     */         } 
/*     */       }
/*     */     } else {
/*     */       
/* 119 */       typeBounds.add(this._env.getFactory().newTypeMirror((Binding)this._env.getLookupEnvironment().getType(LookupEnvironment.JAVA_LANG_OBJECT)));
/*     */     } 
/* 121 */     return Collections.unmodifiableList(typeBounds);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Element getGenericElement() {
/* 127 */     return this._declaringElement;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public <R, P> R accept(ElementVisitor<R, P> v, P p) {
/* 133 */     return v.visitTypeParameter(this, p);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected AnnotationBinding[] getAnnotationBindings() {
/* 144 */     return ((TypeVariableBinding)this._binding).getTypeAnnotations();
/*     */   }
/*     */   
/*     */   private boolean shouldEmulateJavacBug() {
/* 148 */     if ((this._env.getLookupEnvironment()).globalOptions.emulateJavacBug8031744) {
/* 149 */       AnnotationBinding[] annotations = getAnnotationBindings();
/* 150 */       for (int i = 0, length = annotations.length; i < length; i++) {
/* 151 */         ReferenceBinding firstAnnotationType = annotations[i].getAnnotationType();
/* 152 */         for (int j = i + 1; j < length; j++) {
/* 153 */           ReferenceBinding secondAnnotationType = annotations[j].getAnnotationType();
/* 154 */           if (firstAnnotationType == secondAnnotationType)
/* 155 */             return true; 
/*     */         } 
/*     */       } 
/*     */     } 
/* 159 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public List<? extends AnnotationMirror> getAnnotationMirrors() {
/* 164 */     if (shouldEmulateJavacBug())
/* 165 */       return Collections.emptyList(); 
/* 166 */     return super.getAnnotationMirrors();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public <A extends java.lang.annotation.Annotation> A[] getAnnotationsByType(Class<A> annotationType) {
/* 172 */     if (shouldEmulateJavacBug())
/* 173 */       return (A[])Array.newInstance(annotationType, 0); 
/* 174 */     return super.getAnnotationsByType(annotationType);
/*     */   }
/*     */ 
/*     */   
/*     */   public <A extends java.lang.annotation.Annotation> A getAnnotation(Class<A> annotationType) {
/* 179 */     if (shouldEmulateJavacBug())
/* 180 */       return null; 
/* 181 */     return super.getAnnotation(annotationType);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<? extends Element> getEnclosedElements() {
/* 192 */     return Collections.emptyList();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Element getEnclosingElement() {
/* 203 */     return getGenericElement();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ElementKind getKind() {
/* 209 */     return ElementKind.TYPE_PARAMETER;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   PackageElement getPackage() {
/* 216 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 221 */     return new String(this._binding.readableName());
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\apt\model\TypeParameterElementImpl.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */