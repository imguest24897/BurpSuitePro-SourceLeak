/*     */ package org.eclipse.jdt.internal.compiler.ast;
/*     */ 
/*     */ import org.eclipse.jdt.core.compiler.CharOperation;
/*     */ import org.eclipse.jdt.internal.compiler.ASTVisitor;
/*     */ import org.eclipse.jdt.internal.compiler.codegen.CodeStream;
/*     */ import org.eclipse.jdt.internal.compiler.impl.FloatConstant;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.BlockScope;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.TypeBinding;
/*     */ import org.eclipse.jdt.internal.compiler.util.FloatUtil;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FloatLiteral
/*     */   extends NumberLiteral
/*     */ {
/*     */   float value;
/*     */   
/*     */   public FloatLiteral(char[] token, int s, int e) {
/*  29 */     super(token, s, e);
/*     */   }
/*     */ 
/*     */   
/*     */   public void computeConstant() {
/*     */     Float computedValue;
/*  35 */     boolean containsUnderscores = (CharOperation.indexOf('_', this.source) > 0);
/*  36 */     if (containsUnderscores)
/*     */     {
/*  38 */       this.source = CharOperation.remove(this.source, '_');
/*     */     }
/*     */     try {
/*  41 */       computedValue = Float.valueOf(String.valueOf(this.source));
/*  42 */     } catch (NumberFormatException numberFormatException) {
/*     */ 
/*     */       
/*     */       try {
/*  46 */         float v = FloatUtil.valueOfHexFloatLiteral(this.source);
/*  47 */         if (v == Float.POSITIVE_INFINITY) {
/*     */           return;
/*     */         }
/*     */         
/*  51 */         if (Float.isNaN(v)) {
/*     */           return;
/*     */         }
/*     */         
/*  55 */         this.value = v;
/*  56 */         this.constant = FloatConstant.fromValue(v);
/*  57 */       } catch (NumberFormatException numberFormatException1) {}
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/*  62 */     float floatValue = computedValue.floatValue();
/*  63 */     if (floatValue > Float.MAX_VALUE) {
/*     */       return;
/*     */     }
/*     */     
/*  67 */     if (floatValue < Float.MIN_VALUE) {
/*     */ 
/*     */ 
/*     */       
/*  71 */       boolean isHexaDecimal = false;
/*  72 */       for (int i = 0; i < this.source.length; i++) {
/*  73 */         switch (this.source[i]) {
/*     */           case '.':
/*     */           case '0':
/*     */             break;
/*     */           case 'X':
/*     */           case 'x':
/*  79 */             isHexaDecimal = true;
/*     */             break;
/*     */           case 'D':
/*     */           case 'E':
/*     */           case 'F':
/*     */           case 'd':
/*     */           case 'e':
/*     */           case 'f':
/*  87 */             if (isHexaDecimal) {
/*     */               return;
/*     */             }
/*     */             break;
/*     */           
/*     */           case 'P':
/*     */           case 'p':
/*     */             break;
/*     */           
/*     */           default:
/*     */             return;
/*     */         } 
/*     */       
/*     */       } 
/*     */     } 
/* 102 */     this.value = floatValue;
/* 103 */     this.constant = FloatConstant.fromValue(this.value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void generateCode(BlockScope currentScope, CodeStream codeStream, boolean valueRequired) {
/* 115 */     int pc = codeStream.position;
/* 116 */     if (valueRequired) {
/* 117 */       codeStream.generateConstant(this.constant, this.implicitConversion);
/*     */     }
/* 119 */     codeStream.recordPositionsFrom(pc, this.sourceStart);
/*     */   }
/*     */ 
/*     */   
/*     */   public TypeBinding literalType(BlockScope scope) {
/* 124 */     return (TypeBinding)TypeBinding.FLOAT;
/*     */   }
/*     */ 
/*     */   
/*     */   public void traverse(ASTVisitor visitor, BlockScope scope) {
/* 129 */     visitor.visit(this, scope);
/* 130 */     visitor.endVisit(this, scope);
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\ast\FloatLiteral.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */