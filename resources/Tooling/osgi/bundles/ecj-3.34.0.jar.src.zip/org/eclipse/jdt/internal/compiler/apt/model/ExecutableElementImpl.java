/*     */ package org.eclipse.jdt.internal.compiler.apt.model;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import javax.lang.model.element.AnnotationValue;
/*     */ import javax.lang.model.element.Element;
/*     */ import javax.lang.model.element.ElementKind;
/*     */ import javax.lang.model.element.ElementVisitor;
/*     */ import javax.lang.model.element.ExecutableElement;
/*     */ import javax.lang.model.element.Modifier;
/*     */ import javax.lang.model.element.Name;
/*     */ import javax.lang.model.element.PackageElement;
/*     */ import javax.lang.model.element.TypeElement;
/*     */ import javax.lang.model.element.TypeParameterElement;
/*     */ import javax.lang.model.element.VariableElement;
/*     */ import javax.lang.model.type.TypeMirror;
/*     */ import org.eclipse.jdt.core.compiler.CharOperation;
/*     */ import org.eclipse.jdt.internal.compiler.apt.dispatch.BaseProcessingEnvImpl;
/*     */ import org.eclipse.jdt.internal.compiler.ast.AbstractMethodDeclaration;
/*     */ import org.eclipse.jdt.internal.compiler.ast.Argument;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.AnnotationBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.AnnotationHolder;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.AptBinaryLocalVariableBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.Binding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.LookupEnvironment;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.MethodBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.MethodVerifier;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.ReferenceBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.TypeBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.TypeConstants;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.TypeVariableBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.VariableBinding;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ExecutableElementImpl
/*     */   extends ElementImpl
/*     */   implements ExecutableElement
/*     */ {
/*  53 */   private Name _name = null;
/*     */   
/*     */   ExecutableElementImpl(BaseProcessingEnvImpl env, MethodBinding binding) {
/*  56 */     super(env, (Binding)binding);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public <R, P> R accept(ElementVisitor<R, P> v, P p) {
/*  62 */     return v.visitExecutable(this, p);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected AnnotationBinding[] getAnnotationBindings() {
/*  68 */     return ((MethodBinding)this._binding).getAnnotations();
/*     */   }
/*     */ 
/*     */   
/*     */   public AnnotationValue getDefaultValue() {
/*  73 */     MethodBinding binding = (MethodBinding)this._binding;
/*  74 */     Object defaultValue = binding.getDefaultValue();
/*  75 */     if (defaultValue != null) return new AnnotationMemberValue(this._env, defaultValue, binding); 
/*  76 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public List<? extends Element> getEnclosedElements() {
/*  81 */     return Collections.emptyList();
/*     */   }
/*     */ 
/*     */   
/*     */   public Element getEnclosingElement() {
/*  86 */     MethodBinding binding = (MethodBinding)this._binding;
/*  87 */     if (binding.declaringClass == null) {
/*  88 */       return null;
/*     */     }
/*  90 */     return this._env.getFactory().newElement((Binding)binding.declaringClass);
/*     */   }
/*     */ 
/*     */   
/*     */   public String getFileName() {
/*  95 */     ReferenceBinding dc = ((MethodBinding)this._binding).declaringClass;
/*  96 */     char[] name = dc.getFileName();
/*  97 */     if (name == null)
/*  98 */       return null; 
/*  99 */     return new String(name);
/*     */   }
/*     */ 
/*     */   
/*     */   public ElementKind getKind() {
/* 104 */     MethodBinding binding = (MethodBinding)this._binding;
/* 105 */     if (binding.isConstructor()) {
/* 106 */       return ElementKind.CONSTRUCTOR;
/*     */     }
/* 108 */     if (CharOperation.equals(binding.selector, TypeConstants.CLINIT)) {
/* 109 */       return ElementKind.STATIC_INIT;
/*     */     }
/* 111 */     if (CharOperation.equals(binding.selector, TypeConstants.INIT)) {
/* 112 */       return ElementKind.INSTANCE_INIT;
/*     */     }
/*     */     
/* 115 */     return ElementKind.METHOD;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Set<Modifier> getModifiers() {
/* 121 */     MethodBinding binding = (MethodBinding)this._binding;
/* 122 */     return Factory.getModifiers(binding.modifiers, getKind());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   PackageElement getPackage() {
/* 128 */     MethodBinding binding = (MethodBinding)this._binding;
/* 129 */     if (binding.declaringClass == null) {
/* 130 */       return null;
/*     */     }
/* 132 */     return this._env.getFactory().newPackageElement(binding.declaringClass.fPackage);
/*     */   }
/*     */ 
/*     */   
/*     */   public List<? extends VariableElement> getParameters() {
/* 137 */     MethodBinding binding = (MethodBinding)this._binding;
/* 138 */     int length = (binding.parameters == null) ? 0 : binding.parameters.length;
/* 139 */     if (length != 0) {
/* 140 */       AbstractMethodDeclaration methodDeclaration = binding.sourceMethod();
/* 141 */       List<VariableElement> params = new ArrayList<>(length);
/* 142 */       if (methodDeclaration != null) {
/* 143 */         byte b; int i; Argument[] arrayOfArgument; for (i = (arrayOfArgument = methodDeclaration.arguments).length, b = 0; b < i; ) { Argument argument = arrayOfArgument[b];
/* 144 */           VariableElement param = new VariableElementImpl(this._env, (VariableBinding)argument.binding);
/* 145 */           params.add(param);
/*     */           b++; }
/*     */       
/*     */       } else {
/* 149 */         AnnotationBinding[][] parameterAnnotationBindings = null;
/* 150 */         AnnotationHolder annotationHolder = binding.declaringClass.retrieveAnnotationHolder((Binding)binding, false);
/* 151 */         if (annotationHolder != null) {
/* 152 */           parameterAnnotationBindings = annotationHolder.getParameterAnnotations();
/*     */         }
/*     */         
/* 155 */         int i = 0; byte b; int j; TypeBinding[] arrayOfTypeBinding;
/* 156 */         for (j = (arrayOfTypeBinding = binding.parameters).length, b = 0; b < j; ) { TypeBinding typeBinding = arrayOfTypeBinding[b];
/* 157 */           char[] name = (binding.parameterNames.length > i) ? binding.parameterNames[i] : null;
/* 158 */           if (name == null) {
/* 159 */             StringBuilder builder = new StringBuilder("arg");
/* 160 */             builder.append(i);
/* 161 */             name = String.valueOf(builder).toCharArray();
/*     */           } 
/* 163 */           VariableElement param = new VariableElementImpl(this._env, 
/* 164 */               (VariableBinding)new AptBinaryLocalVariableBinding(
/* 165 */                 name, 
/* 166 */                 typeBinding, 
/* 167 */                 0, 
/* 168 */                 (parameterAnnotationBindings != null) ? parameterAnnotationBindings[i] : null, 
/* 169 */                 binding));
/* 170 */           params.add(param);
/* 171 */           i++; b++; }
/*     */       
/*     */       } 
/* 174 */       return Collections.unmodifiableList(params);
/*     */     } 
/* 176 */     return Collections.emptyList();
/*     */   }
/*     */ 
/*     */   
/*     */   public TypeMirror getReturnType() {
/* 181 */     MethodBinding binding = (MethodBinding)this._binding;
/* 182 */     if (binding.returnType == null) {
/* 183 */       return null;
/*     */     }
/* 185 */     return this._env.getFactory().newTypeMirror((Binding)binding.returnType);
/*     */   }
/*     */ 
/*     */   
/*     */   public Name getSimpleName() {
/* 190 */     MethodBinding binding = (MethodBinding)this._binding;
/* 191 */     if (this._name == null) {
/* 192 */       this._name = new NameImpl(binding.selector);
/*     */     }
/* 194 */     return this._name;
/*     */   }
/*     */ 
/*     */   
/*     */   public List<? extends TypeMirror> getThrownTypes() {
/* 199 */     MethodBinding binding = (MethodBinding)this._binding;
/* 200 */     if (binding.thrownExceptions.length == 0) {
/* 201 */       return Collections.emptyList();
/*     */     }
/* 203 */     List<TypeMirror> list = new ArrayList<>(binding.thrownExceptions.length); byte b; int i; ReferenceBinding[] arrayOfReferenceBinding;
/* 204 */     for (i = (arrayOfReferenceBinding = binding.thrownExceptions).length, b = 0; b < i; ) { ReferenceBinding exception = arrayOfReferenceBinding[b];
/* 205 */       list.add(this._env.getFactory().newTypeMirror((Binding)exception)); b++; }
/*     */     
/* 207 */     return list;
/*     */   }
/*     */ 
/*     */   
/*     */   public List<? extends TypeParameterElement> getTypeParameters() {
/* 212 */     MethodBinding binding = (MethodBinding)this._binding;
/* 213 */     TypeVariableBinding[] variables = binding.typeVariables();
/* 214 */     if (variables.length == 0) {
/* 215 */       return Collections.emptyList();
/*     */     }
/* 217 */     List<TypeParameterElement> params = new ArrayList<>(variables.length); byte b; int i; TypeVariableBinding[] arrayOfTypeVariableBinding1;
/* 218 */     for (i = (arrayOfTypeVariableBinding1 = variables).length, b = 0; b < i; ) { TypeVariableBinding variable = arrayOfTypeVariableBinding1[b];
/* 219 */       params.add(this._env.getFactory().newTypeParameterElement(variable, this)); b++; }
/*     */     
/* 221 */     return Collections.unmodifiableList(params);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean hides(Element hidden) {
/* 227 */     if (!(hidden instanceof ExecutableElementImpl)) {
/* 228 */       return false;
/*     */     }
/* 230 */     MethodBinding hiderBinding = (MethodBinding)this._binding;
/* 231 */     MethodBinding hiddenBinding = (MethodBinding)((ExecutableElementImpl)hidden)._binding;
/* 232 */     if (hiderBinding == hiddenBinding) {
/* 233 */       return false;
/*     */     }
/* 235 */     if (hiddenBinding.isPrivate()) {
/* 236 */       return false;
/*     */     }
/*     */     
/* 239 */     if (!hiderBinding.isStatic() || !hiddenBinding.isStatic()) {
/* 240 */       return false;
/*     */     }
/*     */     
/* 243 */     if (!CharOperation.equals(hiddenBinding.selector, hiderBinding.selector)) {
/* 244 */       return false;
/*     */     }
/*     */     
/* 247 */     if (!this._env.getLookupEnvironment().methodVerifier().isMethodSubsignature(hiderBinding, hiddenBinding)) {
/* 248 */       return false;
/*     */     }
/* 250 */     return (hiderBinding.declaringClass.findSuperTypeOriginatingFrom((TypeBinding)hiddenBinding.declaringClass) != null);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isVarArgs() {
/* 255 */     return ((MethodBinding)this._binding).isVarargs();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean overrides(ExecutableElement overridden, TypeElement type) {
/* 278 */     MethodBinding overriddenBinding = (MethodBinding)((ExecutableElementImpl)overridden)._binding;
/* 279 */     ReferenceBinding overriderContext = (ReferenceBinding)((TypeElementImpl)type)._binding;
/* 280 */     if ((MethodBinding)this._binding == overriddenBinding || 
/* 281 */       overriddenBinding.isStatic() || 
/* 282 */       overriddenBinding.isPrivate() || (
/* 283 */       (MethodBinding)this._binding).isStatic()) {
/* 284 */       return false;
/*     */     }
/* 286 */     char[] selector = ((MethodBinding)this._binding).selector;
/* 287 */     if (!CharOperation.equals(selector, overriddenBinding.selector)) {
/* 288 */       return false;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 293 */     if (overriderContext.findSuperTypeOriginatingFrom((TypeBinding)((MethodBinding)this._binding).declaringClass) == null && 
/* 294 */       ((MethodBinding)this._binding).declaringClass.findSuperTypeOriginatingFrom((TypeBinding)overriderContext) == null) {
/* 295 */       return false;
/*     */     }
/* 297 */     MethodBinding overriderBinding = new MethodBinding((MethodBinding)this._binding, overriderContext);
/* 298 */     if (overriderBinding.isPrivate())
/*     */     {
/*     */ 
/*     */       
/* 302 */       return false;
/*     */     }
/*     */     
/* 305 */     TypeBinding match = overriderBinding.declaringClass.findSuperTypeOriginatingFrom((TypeBinding)overriddenBinding.declaringClass);
/* 306 */     if (!(match instanceof ReferenceBinding)) return false;
/*     */     
/* 308 */     MethodBinding[] superMethods = ((ReferenceBinding)match).getMethods(selector);
/* 309 */     LookupEnvironment lookupEnvironment = this._env.getLookupEnvironment();
/* 310 */     if (lookupEnvironment == null) return false; 
/* 311 */     MethodVerifier methodVerifier = lookupEnvironment.methodVerifier();
/* 312 */     for (int i = 0, length = superMethods.length; i < length; i++) {
/* 313 */       if (superMethods[i].original() == overriddenBinding) {
/* 314 */         return methodVerifier.doesMethodOverride(overriderBinding, superMethods[i]);
/*     */       }
/*     */     } 
/* 317 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public TypeMirror getReceiverType() {
/* 322 */     return this._env.getFactory().getReceiverType((MethodBinding)this._binding);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isDefault() {
/* 327 */     if (this._binding != null) {
/* 328 */       return ((MethodBinding)this._binding).isDefaultMethod();
/*     */     }
/* 330 */     return false;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\apt\model\ExecutableElementImpl.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */