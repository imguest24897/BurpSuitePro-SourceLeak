/*     */ package org.eclipse.jdt.internal.compiler.ast;
/*     */ 
/*     */ import org.eclipse.jdt.core.compiler.CharOperation;
/*     */ import org.eclipse.jdt.internal.compiler.ASTVisitor;
/*     */ import org.eclipse.jdt.internal.compiler.impl.Constant;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.Binding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.BlockScope;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.ClassScope;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.ParameterizedTypeBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.ReferenceBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.Scope;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.TypeBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.TypeVariableBinding;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ParameterizedSingleTypeReference
/*     */   extends ArrayTypeReference
/*     */ {
/*  40 */   public static final TypeBinding[] DIAMOND_TYPE_ARGUMENTS = new TypeBinding[0];
/*     */   
/*     */   public TypeReference[] typeArguments;
/*     */   
/*     */   public ParameterizedSingleTypeReference(char[] name, TypeReference[] typeArguments, int dim, long pos) {
/*  45 */     super(name, dim, pos);
/*  46 */     this.originalSourceEnd = this.sourceEnd;
/*  47 */     this.typeArguments = typeArguments;
/*  48 */     for (int i = 0, max = typeArguments.length; i < max; i++) {
/*  49 */       if (((typeArguments[i]).bits & 0x100000) != 0) {
/*  50 */         this.bits |= 0x100000;
/*     */         break;
/*     */       } 
/*     */     } 
/*     */   }
/*     */   public ParameterizedSingleTypeReference(char[] name, TypeReference[] typeArguments, int dim, Annotation[][] annotationsOnDimensions, long pos) {
/*  56 */     this(name, typeArguments, dim, pos);
/*  57 */     setAnnotationsOnDimensions(annotationsOnDimensions);
/*  58 */     if (annotationsOnDimensions != null) {
/*  59 */       this.bits |= 0x100000;
/*     */     }
/*     */   }
/*     */   
/*     */   public void checkBounds(Scope scope) {
/*  64 */     if (this.resolvedType == null)
/*     */       return; 
/*  66 */     if (this.resolvedType.leafComponentType() instanceof ParameterizedTypeBinding) {
/*  67 */       ParameterizedTypeBinding parameterizedType = (ParameterizedTypeBinding)this.resolvedType.leafComponentType();
/*  68 */       TypeBinding[] argTypes = parameterizedType.arguments;
/*  69 */       if (argTypes != null) {
/*  70 */         parameterizedType.boundCheck(scope, this.typeArguments);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public TypeReference augmentTypeWithAdditionalDimensions(int additionalDimensions, Annotation[][] additionalAnnotations, boolean isVarargs) {
/*  77 */     int totalDimensions = dimensions() + additionalDimensions;
/*  78 */     Annotation[][] allAnnotations = getMergedAnnotationsOnDimensions(additionalDimensions, additionalAnnotations);
/*  79 */     ParameterizedSingleTypeReference parameterizedSingleTypeReference = new ParameterizedSingleTypeReference(this.token, this.typeArguments, totalDimensions, allAnnotations, (this.sourceStart << 32L) + this.sourceEnd);
/*  80 */     parameterizedSingleTypeReference.annotations = this.annotations;
/*  81 */     parameterizedSingleTypeReference.bits |= this.bits & 0x100000;
/*  82 */     if (!isVarargs)
/*  83 */       parameterizedSingleTypeReference.extendedDimensions = additionalDimensions; 
/*  84 */     return parameterizedSingleTypeReference;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public char[][] getParameterizedTypeName() {
/*  92 */     StringBuilder buffer = new StringBuilder(5);
/*  93 */     buffer.append(this.token).append('<');
/*  94 */     for (int i = 0, length = this.typeArguments.length; i < length; i++) {
/*  95 */       if (i > 0) buffer.append(','); 
/*  96 */       buffer.append(CharOperation.concatWith(this.typeArguments[i].getParameterizedTypeName(), '.'));
/*     */     } 
/*  98 */     buffer.append('>');
/*  99 */     int nameLength = buffer.length();
/* 100 */     char[] name = new char[nameLength];
/* 101 */     buffer.getChars(0, nameLength, name, 0);
/* 102 */     int dim = this.dimensions;
/* 103 */     if (dim > 0) {
/* 104 */       char[] dimChars = new char[dim * 2];
/* 105 */       for (int j = 0; j < dim; j++) {
/* 106 */         int index = j * 2;
/* 107 */         dimChars[index] = '[';
/* 108 */         dimChars[index + 1] = ']';
/*     */       } 
/* 110 */       name = CharOperation.concat(name, dimChars);
/*     */     } 
/* 112 */     return new char[][] { name };
/*     */   }
/*     */ 
/*     */   
/*     */   public TypeReference[][] getTypeArguments() {
/* 117 */     return new TypeReference[][] { this.typeArguments };
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected TypeBinding getTypeBinding(Scope scope) {
/* 125 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isParameterizedTypeReference() {
/* 130 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean hasNullTypeAnnotation(TypeReference.AnnotationPosition position) {
/* 135 */     if (super.hasNullTypeAnnotation(position))
/* 136 */       return true; 
/* 137 */     if (position == TypeReference.AnnotationPosition.ANY) {
/* 138 */       if (this.resolvedType != null && !this.resolvedType.hasNullTypeAnnotations())
/* 139 */         return false; 
/* 140 */       if (this.typeArguments != null)
/* 141 */         for (int i = 0; i < this.typeArguments.length; i++) {
/* 142 */           if (this.typeArguments[i].hasNullTypeAnnotation(position)) {
/* 143 */             return true;
/*     */           }
/*     */         }  
/*     */     } 
/* 147 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private TypeBinding internalResolveType(Scope scope, ReferenceBinding enclosingType, boolean checkBounds, int location) {
/* 155 */     this.constant = Constant.NotAConstant;
/* 156 */     if ((this.bits & 0x40000) != 0 && 
/* 157 */       this.resolvedType != null) {
/* 158 */       TypeBinding typeBinding; if (this.resolvedType.isValidBinding()) {
/* 159 */         return this.resolvedType;
/*     */       }
/* 161 */       switch (this.resolvedType.problemId()) {
/*     */         case 1:
/*     */         case 2:
/*     */         case 5:
/* 165 */           typeBinding = this.resolvedType.closestMatch();
/* 166 */           return typeBinding;
/*     */       } 
/* 168 */       return null;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 173 */     this.bits |= 0x40000;
/* 174 */     TypeBinding type = internalResolveLeafType(scope, enclosingType, checkBounds);
/*     */ 
/*     */     
/* 177 */     if (type == null) {
/* 178 */       this.resolvedType = createArrayType(scope, this.resolvedType);
/* 179 */       resolveAnnotations(scope, 0);
/* 180 */       return null;
/*     */     } 
/* 182 */     type = createArrayType(scope, type);
/* 183 */     if (!this.resolvedType.isValidBinding() && this.resolvedType.dimensions() == type.dimensions()) {
/* 184 */       resolveAnnotations(scope, 0);
/* 185 */       return type;
/*     */     } 
/* 187 */     this.resolvedType = type;
/* 188 */     resolveAnnotations(scope, location);
/* 189 */     if (this.dimensions > 0)
/* 190 */       this.resolvedType = ArrayTypeReference.maybeMarkArrayContentsNonNull(scope, this.resolvedType, this.sourceStart, this.dimensions, leafType -> {
/*     */           
/*     */           }); 
/* 193 */     return this.resolvedType;
/*     */   }
/*     */ 
/*     */   
/*     */   private TypeBinding internalResolveLeafType(Scope scope, ReferenceBinding enclosingType, boolean checkBounds) {
/*     */     ReferenceBinding currentType;
/* 199 */     if (enclosingType == null) {
/* 200 */       this.resolvedType = scope.getType(this.token);
/* 201 */       if (this.resolvedType.isValidBinding()) {
/* 202 */         currentType = (ReferenceBinding)this.resolvedType;
/*     */       } else {
/* 204 */         TypeBinding type; boolean bool; int j, k; reportInvalidType(scope);
/* 205 */         switch (this.resolvedType.problemId()) {
/*     */           case 1:
/*     */           case 2:
/*     */           case 5:
/* 209 */             type = this.resolvedType.closestMatch();
/* 210 */             if (type instanceof ReferenceBinding) {
/* 211 */               currentType = (ReferenceBinding)type;
/*     */               break;
/*     */             } 
/*     */           
/*     */           default:
/* 216 */             bool = (scope.kind == 3);
/* 217 */             j = this.typeArguments.length;
/* 218 */             for (k = 0; k < j; k++) {
/* 219 */               TypeReference typeArgument = this.typeArguments[k];
/* 220 */               if (bool) {
/* 221 */                 typeArgument.resolveType((ClassScope)scope);
/*     */               } else {
/* 223 */                 typeArgument.resolveType((BlockScope)scope, checkBounds);
/*     */               } 
/*     */             } 
/* 226 */             return null;
/*     */         } 
/*     */       
/*     */       } 
/* 230 */       enclosingType = currentType.enclosingType();
/* 231 */       if (enclosingType != null && currentType.hasEnclosingInstanceContext()) {
/* 232 */         enclosingType = scope.environment().convertToParameterizedType(enclosingType);
/*     */       }
/*     */     } else {
/* 235 */       this.resolvedType = (TypeBinding)(currentType = scope.getMemberType(this.token, enclosingType));
/* 236 */       if (!this.resolvedType.isValidBinding()) {
/* 237 */         scope.problemReporter().invalidEnclosingType(this, (TypeBinding)currentType, enclosingType);
/* 238 */         return null;
/*     */       } 
/* 240 */       if (isTypeUseDeprecated((TypeBinding)currentType, scope))
/* 241 */         scope.problemReporter().deprecatedType((TypeBinding)currentType, this); 
/* 242 */       ReferenceBinding currentEnclosing = currentType.enclosingType();
/* 243 */       if (currentEnclosing != null && TypeBinding.notEquals(currentEnclosing.erasure(), enclosingType.erasure())) {
/* 244 */         enclosingType = currentEnclosing;
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 249 */     boolean isClassScope = (scope.kind == 3);
/* 250 */     TypeReference keep = null;
/* 251 */     if (isClassScope) {
/* 252 */       keep = ((ClassScope)scope).superTypeReference;
/* 253 */       ((ClassScope)scope).superTypeReference = null;
/*     */     } 
/* 255 */     boolean isDiamond = ((this.bits & 0x80000) != 0);
/* 256 */     int argLength = this.typeArguments.length;
/* 257 */     TypeBinding[] argTypes = new TypeBinding[argLength];
/* 258 */     boolean argHasError = false;
/* 259 */     ReferenceBinding currentOriginal = (ReferenceBinding)currentType.original();
/* 260 */     for (int i = 0; i < argLength; i++) {
/* 261 */       TypeReference typeArgument = this.typeArguments[i];
/* 262 */       TypeBinding argType = isClassScope ? 
/* 263 */         typeArgument.resolveTypeArgument((ClassScope)scope, currentOriginal, i) : 
/* 264 */         typeArgument.resolveTypeArgument((BlockScope)scope, currentOriginal, i);
/* 265 */       this.bits |= typeArgument.bits & 0x100000;
/* 266 */       if (argType == null) {
/* 267 */         argHasError = true;
/*     */       } else {
/* 269 */         argTypes[i] = argType;
/*     */       } 
/*     */     } 
/* 272 */     if (argHasError) {
/* 273 */       return null;
/*     */     }
/* 275 */     if (isClassScope) {
/* 276 */       ((ClassScope)scope).superTypeReference = keep;
/* 277 */       if (((ClassScope)scope).detectHierarchyCycle((TypeBinding)currentOriginal, this)) {
/* 278 */         return null;
/*     */       }
/*     */     } 
/* 281 */     TypeVariableBinding[] typeVariables = currentOriginal.typeVariables();
/* 282 */     if (typeVariables == Binding.NO_TYPE_VARIABLES) {
/* 283 */       boolean isCompliant15 = ((scope.compilerOptions()).originalSourceLevel >= 3211264L);
/* 284 */       if ((currentOriginal.tagBits & 0x80L) == 0L && 
/* 285 */         isCompliant15) {
/* 286 */         this.resolvedType = (TypeBinding)currentType;
/* 287 */         scope.problemReporter().nonGenericTypeCannotBeParameterized(0, this, (TypeBinding)currentType, argTypes);
/* 288 */         return null;
/*     */       } 
/*     */ 
/*     */       
/* 292 */       if (!isCompliant15) {
/* 293 */         if (!this.resolvedType.isValidBinding())
/* 294 */           return (TypeBinding)currentType; 
/* 295 */         return this.resolvedType = (TypeBinding)currentType;
/*     */       }
/*     */     
/* 298 */     } else if (argLength != typeVariables.length) {
/* 299 */       if (!isDiamond) {
/* 300 */         scope.problemReporter().incorrectArityForParameterizedType(this, (TypeBinding)currentType, argTypes);
/* 301 */         return null;
/*     */       } 
/* 303 */     } else if (!currentType.isStatic()) {
/* 304 */       ReferenceBinding actualEnclosing = currentType.enclosingType();
/* 305 */       if (actualEnclosing != null && actualEnclosing.isRawType()) {
/* 306 */         scope.problemReporter().rawMemberTypeCannotBeParameterized(
/* 307 */             this, (ReferenceBinding)scope.environment().createRawType(currentOriginal, actualEnclosing), argTypes);
/* 308 */         return null;
/*     */       } 
/*     */     } 
/*     */     
/* 312 */     ParameterizedTypeBinding parameterizedType = scope.environment().createParameterizedType(currentOriginal, argTypes, enclosingType);
/*     */     
/* 314 */     if (!isDiamond)
/* 315 */     { if (checkBounds) {
/* 316 */         parameterizedType.boundCheck(scope, this.typeArguments);
/*     */       } else {
/* 318 */         scope.deferBoundCheck(this);
/*     */       }  }
/* 320 */     else { parameterizedType.arguments = DIAMOND_TYPE_ARGUMENTS; }
/*     */     
/* 322 */     if (isTypeUseDeprecated((TypeBinding)parameterizedType, scope)) {
/* 323 */       reportDeprecatedType((TypeBinding)parameterizedType, scope);
/*     */     }
/* 325 */     checkIllegalNullAnnotations(scope, this.typeArguments);
/*     */     
/* 327 */     if (!this.resolvedType.isValidBinding()) {
/* 328 */       return (TypeBinding)parameterizedType;
/*     */     }
/* 330 */     return this.resolvedType = (TypeBinding)parameterizedType;
/*     */   }
/*     */   private TypeBinding createArrayType(Scope scope, TypeBinding type) {
/* 333 */     if (this.dimensions > 0) {
/* 334 */       if (this.dimensions > 255)
/* 335 */         scope.problemReporter().tooManyDimensions(this); 
/* 336 */       return (TypeBinding)scope.createArrayType(type, this.dimensions);
/*     */     } 
/* 338 */     return type;
/*     */   }
/*     */ 
/*     */   
/*     */   public StringBuffer printExpression(int indent, StringBuffer output) {
/* 343 */     if (this.annotations != null && this.annotations[0] != null) {
/* 344 */       printAnnotations(this.annotations[0], output);
/* 345 */       output.append(' ');
/*     */     } 
/* 347 */     output.append(this.token);
/* 348 */     output.append("<");
/* 349 */     int length = this.typeArguments.length;
/* 350 */     if (length > 0) {
/* 351 */       int max = length - 1;
/* 352 */       for (int i = 0; i < max; i++) {
/* 353 */         this.typeArguments[i].print(0, output);
/* 354 */         output.append(", ");
/*     */       } 
/* 356 */       this.typeArguments[max].print(0, output);
/*     */     } 
/* 358 */     output.append(">");
/* 359 */     Annotation[][] annotationsOnDimensions = getAnnotationsOnDimensions();
/* 360 */     if ((this.bits & 0x4000) != 0) {
/* 361 */       for (int i = 0; i < this.dimensions - 1; i++) {
/* 362 */         if (annotationsOnDimensions != null && annotationsOnDimensions[i] != null) {
/* 363 */           output.append(" ");
/* 364 */           printAnnotations(annotationsOnDimensions[i], output);
/* 365 */           output.append(" ");
/*     */         } 
/* 367 */         output.append("[]");
/*     */       } 
/* 369 */       if (annotationsOnDimensions != null && annotationsOnDimensions[this.dimensions - 1] != null) {
/* 370 */         output.append(" ");
/* 371 */         printAnnotations(annotationsOnDimensions[this.dimensions - 1], output);
/* 372 */         output.append(" ");
/*     */       } 
/* 374 */       output.append("...");
/*     */     } else {
/* 376 */       for (int i = 0; i < this.dimensions; i++) {
/* 377 */         if (annotationsOnDimensions != null && annotationsOnDimensions[i] != null) {
/* 378 */           output.append(" ");
/* 379 */           printAnnotations(annotationsOnDimensions[i], output);
/* 380 */           output.append(" ");
/*     */         } 
/* 382 */         output.append("[]");
/*     */       } 
/*     */     } 
/* 385 */     return output;
/*     */   }
/*     */ 
/*     */   
/*     */   public TypeBinding resolveType(BlockScope scope, boolean checkBounds, int location) {
/* 390 */     return internalResolveType((Scope)scope, (ReferenceBinding)null, checkBounds, location);
/*     */   }
/*     */ 
/*     */   
/*     */   public TypeBinding resolveType(ClassScope scope, int location) {
/* 395 */     return internalResolveType((Scope)scope, (ReferenceBinding)null, false, location);
/*     */   }
/*     */ 
/*     */   
/*     */   public TypeBinding resolveTypeEnclosing(BlockScope scope, ReferenceBinding enclosingType) {
/* 400 */     return internalResolveType((Scope)scope, enclosingType, true, 0);
/*     */   }
/*     */ 
/*     */   
/*     */   public void traverse(ASTVisitor visitor, BlockScope scope) {
/* 405 */     if (visitor.visit(this, scope)) {
/* 406 */       if (this.annotations != null) {
/* 407 */         Annotation[] typeAnnotations = this.annotations[0];
/* 408 */         for (int j = 0, length = (typeAnnotations == null) ? 0 : typeAnnotations.length; j < length; j++) {
/* 409 */           typeAnnotations[j].traverse(visitor, scope);
/*     */         }
/*     */       } 
/* 412 */       Annotation[][] annotationsOnDimensions = getAnnotationsOnDimensions(true);
/* 413 */       if (annotationsOnDimensions != null) {
/* 414 */         for (int j = 0, k = annotationsOnDimensions.length; j < k; j++) {
/* 415 */           Annotation[] annotations2 = annotationsOnDimensions[j];
/* 416 */           if (annotations2 != null) {
/* 417 */             for (int m = 0, max2 = annotations2.length; m < max2; m++) {
/* 418 */               Annotation annotation = annotations2[m];
/* 419 */               annotation.traverse(visitor, scope);
/*     */             } 
/*     */           }
/*     */         } 
/*     */       }
/* 424 */       for (int i = 0, max = this.typeArguments.length; i < max; i++) {
/* 425 */         this.typeArguments[i].traverse(visitor, scope);
/*     */       }
/*     */     } 
/* 428 */     visitor.endVisit(this, scope);
/*     */   }
/*     */ 
/*     */   
/*     */   public void traverse(ASTVisitor visitor, ClassScope scope) {
/* 433 */     if (visitor.visit(this, scope)) {
/* 434 */       if (this.annotations != null) {
/* 435 */         Annotation[] typeAnnotations = this.annotations[0];
/* 436 */         for (int j = 0, length = (typeAnnotations == null) ? 0 : typeAnnotations.length; j < length; j++) {
/* 437 */           typeAnnotations[j].traverse(visitor, scope);
/*     */         }
/*     */       } 
/* 440 */       Annotation[][] annotationsOnDimensions = getAnnotationsOnDimensions(true);
/* 441 */       if (annotationsOnDimensions != null) {
/* 442 */         for (int j = 0, k = annotationsOnDimensions.length; j < k; j++) {
/* 443 */           Annotation[] annotations2 = annotationsOnDimensions[j];
/* 444 */           for (int m = 0, max2 = annotations2.length; m < max2; m++) {
/* 445 */             Annotation annotation = annotations2[m];
/* 446 */             annotation.traverse(visitor, scope);
/*     */           } 
/*     */         } 
/*     */       }
/* 450 */       for (int i = 0, max = this.typeArguments.length; i < max; i++) {
/* 451 */         this.typeArguments[i].traverse(visitor, scope);
/*     */       }
/*     */     } 
/* 454 */     visitor.endVisit(this, scope);
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\ast\ParameterizedSingleTypeReference.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */