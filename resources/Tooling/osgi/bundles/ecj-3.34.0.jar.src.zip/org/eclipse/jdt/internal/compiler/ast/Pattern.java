/*     */ package org.eclipse.jdt.internal.compiler.ast;
/*     */ 
/*     */ import java.util.function.Supplier;
/*     */ import org.eclipse.jdt.internal.compiler.ASTVisitor;
/*     */ import org.eclipse.jdt.internal.compiler.codegen.BranchLabel;
/*     */ import org.eclipse.jdt.internal.compiler.codegen.CodeStream;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.BlockScope;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.LocalVariableBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.MethodBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.Scope;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.TypeBinding;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class Pattern
/*     */   extends Expression
/*     */ {
/*     */   boolean isTotalTypeNode = false;
/*  29 */   static final char[] SECRET_PATTERN_VARIABLE_NAME = "secretPatternVariable".toCharArray();
/*     */   
/*  31 */   public LocalVariableBinding secretPatternVariable = null;
/*     */   
/*  33 */   public Boolean containsTypeElidedPatternVar = null;
/*     */   
/*     */   private Pattern enclosingPattern;
/*     */   
/*     */   protected MethodBinding accessorMethod;
/*     */   BranchLabel elseTarget;
/*     */   BranchLabel thenTarget;
/*     */   
/*     */   public boolean containsPatternVariable() {
/*     */     class PatternVariablesVisitor
/*     */       extends ASTVisitor
/*     */     {
/*     */       public boolean hasPatternVar = false;
/*     */       public boolean typeElidedVar = false;
/*     */       
/*     */       public boolean visit(TypePattern typePattern, BlockScope blockScope) {
/*  49 */         this.hasPatternVar = (typePattern.local != null);
/*  50 */         this.typeElidedVar |= typePattern.getType().isTypeNameVar((Scope)blockScope);
/*  51 */         return !(this.hasPatternVar && this.typeElidedVar);
/*     */       }
/*     */     };
/*     */     
/*  55 */     PatternVariablesVisitor pvv = new PatternVariablesVisitor();
/*  56 */     traverse(pvv, (BlockScope)null);
/*  57 */     this.containsTypeElidedPatternVar = Boolean.valueOf(pvv.typeElidedVar);
/*  58 */     return pvv.hasPatternVar;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Pattern getEnclosingPattern() {
/*  65 */     return this.enclosingPattern;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setEnclosingPattern(Pattern enclosingPattern) {
/*  72 */     this.enclosingPattern = enclosingPattern;
/*     */   }
/*     */   
/*     */   public boolean isTotalForType(TypeBinding type) {
/*  76 */     return false;
/*     */   }
/*     */   public TypeBinding resolveAtType(BlockScope scope, TypeBinding type) {
/*  79 */     return null;
/*     */   }
/*     */   
/*     */   public TypeBinding resolveType(BlockScope scope) {
/*  83 */     return resolveType(scope, true);
/*     */   }
/*     */   public TypeBinding resolveType(BlockScope scope, boolean isPatternVariable) {
/*  86 */     return null;
/*     */   }
/*     */   public boolean isAlwaysTrue() {
/*  89 */     return true;
/*     */   }
/*     */   
/*     */   public void generateCode(BlockScope currentScope, CodeStream codeStream) {
/*  93 */     setTargets(codeStream);
/*  94 */     generateOptimizedBoolean(currentScope, codeStream, this.thenTarget, this.elseTarget);
/*     */   }
/*     */   void setTargets(CodeStream codeStream) {
/*  97 */     if (this.elseTarget == null)
/*  98 */       this.elseTarget = new BranchLabel(codeStream); 
/*  99 */     if (this.thenTarget == null)
/* 100 */       this.thenTarget = new BranchLabel(codeStream); 
/*     */   }
/*     */   public void suspendVariables(CodeStream codeStream, BlockScope scope) {}
/*     */   
/*     */   public void resumeVariables(CodeStream codeStream, BlockScope scope) {}
/*     */   
/*     */   public abstract void generateOptimizedBoolean(BlockScope paramBlockScope, CodeStream paramCodeStream, BranchLabel paramBranchLabel1, BranchLabel paramBranchLabel2);
/*     */   
/*     */   protected abstract void generatePatternVariable(BlockScope paramBlockScope, CodeStream paramCodeStream, BranchLabel paramBranchLabel1, BranchLabel paramBranchLabel2);
/*     */   
/*     */   protected abstract void wrapupGeneration(CodeStream paramCodeStream);
/*     */   
/*     */   public TypeReference getType() {
/* 113 */     return null;
/*     */   }
/*     */   
/*     */   public abstract void resolveWithExpression(BlockScope paramBlockScope, Expression paramExpression);
/*     */   
/*     */   public void setTargetSupplier(Supplier<BranchLabel> targetSupplier) {}
/*     */   
/*     */   protected abstract boolean isPatternTypeCompatible(TypeBinding paramTypeBinding, BlockScope paramBlockScope);
/*     */   
/*     */   public abstract boolean dominates(Pattern paramPattern);
/*     */   
/*     */   public Pattern primary() {
/* 125 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public StringBuffer print(int indent, StringBuffer output) {
/* 130 */     return printExpression(indent, output);
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\ast\Pattern.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */