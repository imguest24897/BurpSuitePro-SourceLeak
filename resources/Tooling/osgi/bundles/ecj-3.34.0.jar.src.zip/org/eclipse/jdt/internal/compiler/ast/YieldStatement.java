/*     */ package org.eclipse.jdt.internal.compiler.ast;
/*     */ 
/*     */ import org.eclipse.jdt.internal.compiler.ASTVisitor;
/*     */ import org.eclipse.jdt.internal.compiler.codegen.CodeStream;
/*     */ import org.eclipse.jdt.internal.compiler.flow.FlowContext;
/*     */ import org.eclipse.jdt.internal.compiler.flow.FlowInfo;
/*     */ import org.eclipse.jdt.internal.compiler.impl.Constant;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.Binding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.BlockScope;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.LocalVariableBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.Scope;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.TypeBinding;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class YieldStatement
/*     */   extends BranchStatement
/*     */ {
/*     */   public Expression expression;
/*     */   public SwitchExpression switchExpression;
/*     */   public TryStatement tryStatement;
/*     */   public boolean isImplicit;
/*  32 */   static final char[] SECRET_YIELD_RESULT_VALUE_NAME = " secretYieldValue".toCharArray();
/*  33 */   private LocalVariableBinding secretYieldResultValue = null;
/*     */   public BlockScope scope;
/*     */   
/*     */   public YieldStatement(Expression exp, int sourceStart, int sourceEnd) {
/*  37 */     super((char[])null, sourceStart, sourceEnd);
/*  38 */     this.expression = exp;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public FlowInfo analyseCode(BlockScope currentScope, FlowContext flowContext, FlowInfo flowInfo) {
/*  52 */     FlowContext targetContext = this.isImplicit ? flowContext.getTargetContextForDefaultBreak() : 
/*  53 */       flowContext.getTargetContextForDefaultYield();
/*     */     
/*  55 */     flowInfo = this.expression.analyseCode(currentScope, flowContext, flowInfo);
/*  56 */     this.expression.checkNPEbyUnboxing(currentScope, flowContext, flowInfo);
/*  57 */     if (flowInfo.reachMode() == 0 && (currentScope.compilerOptions()).isAnnotationBasedNullAnalysisEnabled) {
/*  58 */       checkAgainstNullAnnotation(currentScope, flowContext, flowInfo, this.expression);
/*     */     }
/*  60 */     targetContext.recordAbruptExit();
/*  61 */     targetContext.expireNullCheckedFieldInfo();
/*     */     
/*  63 */     this.initStateIndex = 
/*  64 */       currentScope.methodScope().recordInitializationStates(flowInfo);
/*     */     
/*  66 */     this.targetLabel = targetContext.breakLabel();
/*  67 */     FlowContext traversedContext = flowContext;
/*  68 */     int subCount = 0;
/*  69 */     this.subroutines = new SubRoutineStatement[5];
/*     */     
/*     */     do {
/*     */       SubRoutineStatement sub;
/*  73 */       if ((sub = traversedContext.subroutine()) != null) {
/*  74 */         if (subCount == this.subroutines.length) {
/*  75 */           System.arraycopy(this.subroutines, 0, this.subroutines = new SubRoutineStatement[subCount * 2], 0, subCount);
/*     */         }
/*  77 */         this.subroutines[subCount++] = sub;
/*  78 */         if (sub.isSubRoutineEscaping()) {
/*     */           break;
/*     */         }
/*     */       } 
/*  82 */       traversedContext.recordReturnFrom(flowInfo.unconditionalInits());
/*  83 */       traversedContext.recordBreakTo(targetContext);
/*     */       
/*  85 */       if (traversedContext instanceof org.eclipse.jdt.internal.compiler.flow.InsideSubRoutineFlowContext) {
/*  86 */         ASTNode node = traversedContext.associatedNode;
/*  87 */         if (node instanceof TryStatement) {
/*  88 */           flowInfo.addInitializationsFrom((FlowInfo)((TryStatement)node).subRoutineInits);
/*     */         }
/*  90 */       } else if (traversedContext == targetContext) {
/*     */         
/*  92 */         targetContext.recordBreakFrom(flowInfo);
/*     */         break;
/*     */       } 
/*  95 */     } while ((traversedContext = traversedContext.getLocalParent()) != null);
/*     */ 
/*     */     
/*  98 */     if (subCount != this.subroutines.length) {
/*  99 */       System.arraycopy(this.subroutines, 0, this.subroutines = new SubRoutineStatement[subCount], 0, subCount);
/*     */     }
/* 101 */     return (FlowInfo)FlowInfo.DEAD_END;
/*     */   }
/*     */   
/*     */   protected void setSubroutineSwitchExpression(SubRoutineStatement sub) {
/* 105 */     sub.setSwitchExpression(this.switchExpression);
/*     */   }
/*     */   protected void addSecretYieldResultValue(BlockScope scope1) {
/* 108 */     SwitchExpression se = this.switchExpression;
/* 109 */     if (se == null || !se.containsTry)
/*     */       return; 
/* 111 */     LocalVariableBinding local = new LocalVariableBinding(
/* 112 */         SECRET_YIELD_RESULT_VALUE_NAME, 
/* 113 */         se.resolvedType, 
/* 114 */         0, 
/* 115 */         false);
/* 116 */     local.setConstant(Constant.NotAConstant);
/* 117 */     local.useFlag = 1;
/* 118 */     local.declaration = new LocalDeclaration(SECRET_YIELD_RESULT_VALUE_NAME, 0, 0);
/* 119 */     assert se.yieldResolvedPosition >= 0;
/* 120 */     local.resolvedPosition = se.yieldResolvedPosition;
/* 121 */     assert local.resolvedPosition < this.scope.maxOffset;
/* 122 */     this.scope.addLocalVariable(local);
/* 123 */     this.secretYieldResultValue = local;
/*     */   }
/*     */ 
/*     */   
/*     */   protected void restartExceptionLabels(CodeStream codeStream) {
/* 128 */     SubRoutineStatement.reenterAllExceptionHandlers(this.subroutines, -1, codeStream);
/*     */   }
/*     */   protected void generateExpressionResultCodeExpanded(BlockScope currentScope, CodeStream codeStream) {
/* 131 */     SwitchExpression se = this.switchExpression;
/* 132 */     addSecretYieldResultValue(this.scope);
/* 133 */     assert this.secretYieldResultValue != null;
/* 134 */     codeStream.record(this.secretYieldResultValue);
/* 135 */     SingleNameReference lhs = new SingleNameReference(this.secretYieldResultValue.name, 0L);
/* 136 */     lhs.binding = (Binding)this.secretYieldResultValue;
/* 137 */     lhs.bits &= 0xFFFFFFF8;
/* 138 */     lhs.bits |= 0x2;
/* 139 */     lhs.bits |= 0x10;
/* 140 */     ((LocalVariableBinding)lhs.binding).markReferenced();
/* 141 */     Assignment assignment = new Assignment(lhs, this.expression, 0);
/* 142 */     assignment.generateCode(this.scope, codeStream);
/*     */     
/* 144 */     int pc = codeStream.position;
/*     */ 
/*     */     
/* 147 */     if (this.subroutines != null) {
/* 148 */       for (int i = 0, max = this.subroutines.length; i < max; i++) {
/* 149 */         SubRoutineStatement sub = this.subroutines[i];
/* 150 */         sub.exitAnyExceptionHandler();
/* 151 */         sub.exitDeclaredExceptionHandlers(codeStream);
/* 152 */         SwitchExpression se1 = sub.getSwitchExpression();
/* 153 */         setSubroutineSwitchExpression(sub);
/* 154 */         boolean didEscape = sub.generateSubRoutineInvocation(currentScope, codeStream, this.targetLabel, this.initStateIndex, null);
/* 155 */         sub.setSwitchExpression(se1);
/* 156 */         if (didEscape) {
/* 157 */           codeStream.removeVariable(this.secretYieldResultValue);
/* 158 */           codeStream.recordPositionsFrom(pc, this.sourceStart);
/* 159 */           SubRoutineStatement.reenterAllExceptionHandlers(this.subroutines, i, codeStream);
/* 160 */           if (this.initStateIndex != -1) {
/* 161 */             codeStream.removeNotDefinitelyAssignedVariables((Scope)currentScope, this.initStateIndex);
/* 162 */             codeStream.addDefinitelyAssignedVariables((Scope)currentScope, this.initStateIndex);
/*     */           } 
/* 164 */           restartExceptionLabels(codeStream);
/*     */           return;
/*     */         } 
/*     */       } 
/*     */     }
/* 169 */     se.loadStoredTypesAndKeep(codeStream);
/* 170 */     codeStream.load(this.secretYieldResultValue);
/* 171 */     codeStream.removeVariable(this.secretYieldResultValue);
/*     */     
/* 173 */     codeStream.goto_(this.targetLabel);
/* 174 */     codeStream.recordPositionsFrom(pc, this.sourceStart);
/* 175 */     SubRoutineStatement.reenterAllExceptionHandlers(this.subroutines, -1, codeStream);
/* 176 */     if (this.initStateIndex != -1) {
/* 177 */       codeStream.removeNotDefinitelyAssignedVariables((Scope)currentScope, this.initStateIndex);
/* 178 */       codeStream.addDefinitelyAssignedVariables((Scope)currentScope, this.initStateIndex);
/*     */     } 
/*     */   }
/*     */   
/*     */   public void generateCode(BlockScope currentScope, CodeStream codeStream) {
/* 183 */     if ((this.bits & Integer.MIN_VALUE) == 0) {
/*     */       return;
/*     */     }
/* 186 */     if (this.switchExpression != null && this.switchExpression.containsTry && this.switchExpression.resolvedType != null) {
/* 187 */       generateExpressionResultCodeExpanded(currentScope, codeStream);
/*     */       return;
/*     */     } 
/* 190 */     this.expression.generateCode(this.scope, codeStream, (this.switchExpression != null));
/* 191 */     int pc = codeStream.position;
/*     */ 
/*     */ 
/*     */     
/* 195 */     if (this.subroutines != null) {
/* 196 */       for (int i = 0, max = this.subroutines.length; i < max; i++) {
/* 197 */         SubRoutineStatement sub = this.subroutines[i];
/* 198 */         SwitchExpression se = sub.getSwitchExpression();
/* 199 */         setSubroutineSwitchExpression(sub);
/* 200 */         boolean didEscape = sub.generateSubRoutineInvocation(currentScope, codeStream, this.targetLabel, this.initStateIndex, null);
/* 201 */         sub.setSwitchExpression(se);
/* 202 */         if (didEscape) {
/* 203 */           codeStream.recordPositionsFrom(pc, this.sourceStart);
/* 204 */           SubRoutineStatement.reenterAllExceptionHandlers(this.subroutines, i, codeStream);
/* 205 */           if (this.initStateIndex != -1) {
/* 206 */             codeStream.removeNotDefinitelyAssignedVariables((Scope)currentScope, this.initStateIndex);
/* 207 */             codeStream.addDefinitelyAssignedVariables((Scope)currentScope, this.initStateIndex);
/*     */           } 
/* 209 */           restartExceptionLabels(codeStream);
/*     */           return;
/*     */         } 
/*     */       } 
/*     */     }
/* 214 */     codeStream.goto_(this.targetLabel);
/* 215 */     codeStream.recordPositionsFrom(pc, this.sourceStart);
/* 216 */     SubRoutineStatement.reenterAllExceptionHandlers(this.subroutines, -1, codeStream);
/* 217 */     if (this.initStateIndex != -1) {
/* 218 */       codeStream.removeNotDefinitelyAssignedVariables((Scope)currentScope, this.initStateIndex);
/* 219 */       codeStream.addDefinitelyAssignedVariables((Scope)currentScope, this.initStateIndex);
/*     */     } 
/*     */   }
/*     */   private boolean isInsideTry() {
/* 223 */     return (this.switchExpression != null && this.switchExpression.containsTry);
/*     */   }
/*     */   
/*     */   public void resolve(BlockScope skope) {
/* 227 */     this.scope = isInsideTry() ? new BlockScope(skope) : skope;
/* 228 */     super.resolve(this.scope);
/* 229 */     if (this.expression == null) {
/*     */       return;
/*     */     }
/*     */     
/* 233 */     if (this.switchExpression != null || this.isImplicit) {
/* 234 */       if (this.switchExpression == null && this.isImplicit && !this.expression.statementExpression() && 
/* 235 */         (this.scope.compilerOptions()).sourceLevel >= 3801088L) {
/*     */ 
/*     */ 
/*     */         
/* 239 */         this.scope.problemReporter().invalidExpressionAsStatement(this.expression);
/*     */ 
/*     */         
/*     */         return;
/*     */       } 
/* 244 */     } else if ((this.scope.compilerOptions()).sourceLevel >= 3801088L) {
/* 245 */       this.scope.problemReporter().switchExpressionsYieldOutsideSwitchExpression(this);
/*     */     } 
/*     */     
/* 248 */     TypeBinding type = this.expression.resolveType(this.scope);
/* 249 */     if (this.switchExpression != null && type != null) {
/* 250 */       this.switchExpression.originalTypeMap.put(this.expression, type);
/*     */     }
/*     */   }
/*     */   
/*     */   public TypeBinding resolveExpressionType(BlockScope scope1) {
/* 255 */     return (this.expression != null) ? this.expression.resolveType(scope1) : null;
/*     */   }
/*     */ 
/*     */   
/*     */   public StringBuffer printStatement(int tab, StringBuffer output) {
/* 260 */     if (!this.isImplicit)
/* 261 */       printIndent(tab, output).append("yield"); 
/* 262 */     if (this.expression != null) {
/* 263 */       output.append(' ');
/* 264 */       this.expression.printExpression(tab, output);
/*     */     } 
/* 266 */     return output.append(';');
/*     */   }
/*     */ 
/*     */   
/*     */   public void traverse(ASTVisitor visitor, BlockScope blockscope) {
/* 271 */     if (visitor.visit(this, blockscope) && 
/* 272 */       this.expression != null) {
/* 273 */       this.expression.traverse(visitor, blockscope);
/*     */     }
/* 275 */     visitor.endVisit(this, blockscope);
/*     */   }
/*     */   
/*     */   public boolean doesNotCompleteNormally() {
/* 279 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean canCompleteNormally() {
/* 284 */     return false;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\ast\YieldStatement.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */