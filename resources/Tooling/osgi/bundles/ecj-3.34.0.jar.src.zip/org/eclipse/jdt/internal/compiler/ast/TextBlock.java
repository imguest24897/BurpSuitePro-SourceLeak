/*    */ package org.eclipse.jdt.internal.compiler.ast;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TextBlock
/*    */   extends StringLiteral
/*    */ {
/*    */   public int endLineNumber;
/*    */   
/*    */   public TextBlock(char[] token, int start, int end, int lineNumber, int endLineNumber) {
/* 20 */     super(token, start, end, lineNumber);
/* 21 */     this.endLineNumber = endLineNumber - 1;
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\ast\TextBlock.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */