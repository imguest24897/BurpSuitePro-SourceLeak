/*     */ package org.eclipse.jdt.internal.compiler.ast;
/*     */ 
/*     */ import org.eclipse.jdt.internal.compiler.ASTVisitor;
/*     */ import org.eclipse.jdt.internal.compiler.codegen.CodeStream;
/*     */ import org.eclipse.jdt.internal.compiler.flow.FlowContext;
/*     */ import org.eclipse.jdt.internal.compiler.flow.FlowInfo;
/*     */ import org.eclipse.jdt.internal.compiler.flow.UnconditionalFlowInfo;
/*     */ import org.eclipse.jdt.internal.compiler.impl.CompilerOptions;
/*     */ import org.eclipse.jdt.internal.compiler.impl.Constant;
/*     */ import org.eclipse.jdt.internal.compiler.impl.IrritantSet;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.ArrayBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.BlockScope;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.InferenceContext18;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.InvocationSite;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.LocalVariableBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.LookupEnvironment;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.MethodBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.ParameterizedGenericMethodBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.ParameterizedTypeBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.PolymorphicMethodBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.ReferenceBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.Scope;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.TypeBinding;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CastExpression
/*     */   extends Expression
/*     */ {
/*     */   public Expression expression;
/*     */   public TypeReference type;
/*     */   public TypeBinding expectedType;
/*     */   public TypeBinding instanceofType;
/*     */   public boolean isVarTypeDeclaration;
/*     */   
/*     */   public CastExpression(Expression expression, TypeReference type) {
/*  72 */     this.expression = expression;
/*  73 */     this.type = type;
/*  74 */     type.bits |= 0x40000000;
/*     */   }
/*     */ 
/*     */   
/*     */   public FlowInfo analyseCode(BlockScope currentScope, FlowContext flowContext, FlowInfo flowInfo) {
/*  79 */     UnconditionalFlowInfo unconditionalFlowInfo = this.expression
/*  80 */       .analyseCode(currentScope, flowContext, flowInfo)
/*  81 */       .unconditionalInits();
/*  82 */     this.expression.checkNPEbyUnboxing(currentScope, flowContext, flowInfo);
/*     */     
/*  84 */     flowContext.recordAbruptExit();
/*  85 */     return (FlowInfo)unconditionalFlowInfo;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void checkNeedForAssignedCast(BlockScope scope, TypeBinding expectedType, CastExpression rhs) {
/*  92 */     CompilerOptions compilerOptions = scope.compilerOptions();
/*  93 */     if (compilerOptions.getSeverity(67108864) == 256)
/*     */       return; 
/*  95 */     TypeBinding castedExpressionType = rhs.expression.resolvedType;
/*     */ 
/*     */     
/*  98 */     if (castedExpressionType == null || rhs.resolvedType.isBaseType())
/*     */       return; 
/* 100 */     if (castedExpressionType.isCompatibleWith(expectedType, (Scope)scope)) {
/* 101 */       if (scope.environment().usesNullTypeAnnotations())
/*     */       {
/* 103 */         if (NullAnnotationMatching.analyse(expectedType, castedExpressionType, -1).isAnyMismatch())
/*     */           return; 
/*     */       }
/* 106 */       scope.problemReporter().unnecessaryCast(rhs);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void checkNeedForCastCast(BlockScope scope, CastExpression enclosingCast) {
/* 116 */     if (scope.compilerOptions().getSeverity(67108864) == 256)
/*     */       return; 
/* 118 */     CastExpression nestedCast = (CastExpression)enclosingCast.expression;
/* 119 */     if ((nestedCast.bits & 0x4000) == 0)
/* 120 */       return;  if (nestedCast.losesPrecision((Scope)scope))
/*     */       return; 
/* 122 */     CastExpression alternateCast = new CastExpression(null, enclosingCast.type);
/* 123 */     alternateCast.resolvedType = enclosingCast.resolvedType;
/* 124 */     if (!alternateCast.checkCastTypesCompatibility((Scope)scope, enclosingCast.resolvedType, nestedCast.expression.resolvedType, (Expression)null, true))
/* 125 */       return;  scope.problemReporter().unnecessaryCast(nestedCast);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean losesPrecision(Scope scope) {
/* 132 */     TypeBinding exprType = this.expression.resolvedType;
/* 133 */     if (exprType.isBoxedPrimitiveType())
/* 134 */       exprType = scope.environment().computeBoxingType(exprType); 
/* 135 */     switch (this.resolvedType.id) {
/*     */       case 9:
/*     */       case 31:
/* 138 */         return !(exprType.id != 10 && exprType.id != 7);
/*     */       case 8:
/*     */       case 32:
/* 141 */         return (exprType.id == 7);
/*     */     } 
/* 143 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void checkNeedForEnclosingInstanceCast(BlockScope scope, Expression enclosingInstance, TypeBinding enclosingInstanceType, TypeBinding memberType) {
/* 150 */     if (scope.compilerOptions().getSeverity(67108864) == 256)
/*     */       return; 
/* 152 */     TypeBinding castedExpressionType = ((CastExpression)enclosingInstance).expression.resolvedType;
/* 153 */     if (castedExpressionType == null)
/*     */       return; 
/* 155 */     if (TypeBinding.equalsEquals(castedExpressionType, enclosingInstanceType))
/* 156 */     { scope.problemReporter().unnecessaryCast((CastExpression)enclosingInstance); }
/* 157 */     else { if (castedExpressionType == TypeBinding.NULL) {
/*     */         return;
/*     */       }
/* 160 */       TypeBinding alternateEnclosingInstanceType = castedExpressionType;
/* 161 */       if (castedExpressionType.isBaseType() || castedExpressionType.isArrayType())
/* 162 */         return;  if (TypeBinding.equalsEquals(memberType, (TypeBinding)scope.getMemberType(memberType.sourceName(), (ReferenceBinding)alternateEnclosingInstanceType))) {
/* 163 */         scope.problemReporter().unnecessaryCast((CastExpression)enclosingInstance);
/*     */       } }
/*     */   
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void checkNeedForArgumentCast(BlockScope scope, int operator, int operatorSignature, Expression expression, int expressionTypeId) {
/* 172 */     if (scope.compilerOptions().getSeverity(67108864) == 256) {
/*     */       return;
/*     */     }
/* 175 */     if ((expression.bits & 0x4000) == 0 && expression.resolvedType.isBaseType()) {
/*     */       return;
/*     */     }
/*     */     
/* 179 */     TypeBinding alternateLeftType = ((CastExpression)expression).expression.resolvedType;
/* 180 */     if (alternateLeftType == null)
/* 181 */       return;  if (alternateLeftType.id == expressionTypeId) {
/* 182 */       scope.problemReporter().unnecessaryCast((CastExpression)expression);
/*     */       return;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void checkNeedForArgumentCasts(BlockScope scope, Expression receiver, TypeBinding receiverType, MethodBinding binding, Expression[] arguments, TypeBinding[] argumentTypes, InvocationSite invocationSite) {
/* 193 */     if (scope.compilerOptions().getSeverity(67108864) == 256)
/*     */       return; 
/* 195 */     int length = argumentTypes.length;
/*     */ 
/*     */     
/* 198 */     TypeBinding[] rawArgumentTypes = argumentTypes;
/* 199 */     for (int i = 0; i < length; i++) {
/* 200 */       Expression argument = arguments[i];
/* 201 */       if (argument instanceof CastExpression)
/*     */       {
/* 203 */         if ((argument.bits & 0x4000) != 0 || !argument.resolvedType.isBaseType()) {
/*     */ 
/*     */           
/* 206 */           TypeBinding castedExpressionType = ((CastExpression)argument).expression.resolvedType;
/* 207 */           if (castedExpressionType == null)
/*     */             return; 
/* 209 */           if (TypeBinding.equalsEquals(castedExpressionType, argumentTypes[i])) {
/* 210 */             scope.problemReporter().unnecessaryCast((CastExpression)argument);
/* 211 */           } else if (castedExpressionType != TypeBinding.NULL) {
/*     */             
/* 213 */             if ((argument.implicitConversion & 0x200) == 0) {
/*     */ 
/*     */               
/* 216 */               if (rawArgumentTypes == argumentTypes) {
/* 217 */                 System.arraycopy(rawArgumentTypes, 0, rawArgumentTypes = new TypeBinding[length], 0, length);
/*     */               }
/*     */               
/* 220 */               rawArgumentTypes[i] = castedExpressionType;
/*     */             } 
/*     */           } 
/*     */         }  } 
/*     */     } 
/* 225 */     if (rawArgumentTypes != argumentTypes) {
/* 226 */       checkAlternateBinding(scope, receiver, receiverType, binding, arguments, argumentTypes, rawArgumentTypes, invocationSite);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void checkNeedForArgumentCasts(BlockScope scope, int operator, int operatorSignature, Expression left, int leftTypeId, boolean leftIsCast, Expression right, int rightTypeId, boolean rightIsCast) {
/* 234 */     if (scope.compilerOptions().getSeverity(67108864) == 256)
/*     */       return; 
/* 236 */     boolean useAutoBoxing = (operator != 18 && operator != 29);
/*     */     
/* 238 */     int alternateLeftTypeId = leftTypeId;
/* 239 */     if (leftIsCast) {
/* 240 */       if ((left.bits & 0x4000) == 0 && left.resolvedType.isBaseType()) {
/*     */         
/* 242 */         leftIsCast = false;
/*     */       } else {
/* 244 */         TypeBinding alternateLeftType = ((CastExpression)left).expression.resolvedType;
/* 245 */         if (alternateLeftType == null)
/* 246 */           return;  if ((alternateLeftTypeId = alternateLeftType.id) == leftTypeId || (
/* 247 */           useAutoBoxing ? (
/* 248 */           (scope.environment().computeBoxingType(alternateLeftType)).id == leftTypeId) : 
/* 249 */           TypeBinding.equalsEquals(alternateLeftType, left.resolvedType))) {
/* 250 */           scope.problemReporter().unnecessaryCast((CastExpression)left);
/* 251 */           leftIsCast = false;
/* 252 */         } else if (alternateLeftTypeId == 12) {
/* 253 */           alternateLeftTypeId = leftTypeId;
/* 254 */           leftIsCast = false;
/*     */         } 
/*     */       } 
/*     */     }
/*     */     
/* 259 */     int alternateRightTypeId = rightTypeId;
/* 260 */     if (rightIsCast) {
/* 261 */       if ((right.bits & 0x4000) == 0 && right.resolvedType.isBaseType()) {
/*     */         
/* 263 */         rightIsCast = false;
/*     */       } else {
/* 265 */         TypeBinding alternateRightType = ((CastExpression)right).expression.resolvedType;
/* 266 */         if (alternateRightType == null)
/* 267 */           return;  if ((alternateRightTypeId = alternateRightType.id) == rightTypeId || (
/* 268 */           useAutoBoxing ? (
/* 269 */           (scope.environment().computeBoxingType(alternateRightType)).id == rightTypeId) : 
/* 270 */           TypeBinding.equalsEquals(alternateRightType, right.resolvedType))) {
/* 271 */           scope.problemReporter().unnecessaryCast((CastExpression)right);
/* 272 */           rightIsCast = false;
/* 273 */         } else if (alternateRightTypeId == 12) {
/* 274 */           alternateRightTypeId = rightTypeId;
/* 275 */           rightIsCast = false;
/*     */         } 
/*     */       } 
/*     */     }
/* 279 */     if (leftIsCast || rightIsCast) {
/* 280 */       if (alternateLeftTypeId > 15 || alternateRightTypeId > 15) {
/* 281 */         if (alternateLeftTypeId == 11) {
/* 282 */           alternateRightTypeId = 1;
/* 283 */         } else if (alternateRightTypeId == 11) {
/* 284 */           alternateLeftTypeId = 1;
/*     */         } else {
/*     */           return;
/*     */         } 
/*     */       }
/* 289 */       int alternateOperatorSignature = OperatorExpression.OperatorSignatures[operator][(alternateLeftTypeId << 4) + alternateRightTypeId];
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 294 */       if ((operatorSignature & 0xF0F0F) == (alternateOperatorSignature & 0xF0F0F)) {
/* 295 */         if (leftIsCast) scope.problemReporter().unnecessaryCast((CastExpression)left); 
/* 296 */         if (rightIsCast) scope.problemReporter().unnecessaryCast((CastExpression)right);
/*     */       
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   public boolean checkNPE(BlockScope scope, FlowContext flowContext, FlowInfo flowInfo, int ttlForFieldCheck) {
/* 303 */     if ((this.resolvedType.tagBits & 0x100000000000000L) != 0L) {
/* 304 */       return true;
/*     */     }
/* 306 */     checkNPEbyUnboxing(scope, flowContext, flowInfo);
/* 307 */     return this.expression.checkNPE(scope, flowContext, flowInfo, ttlForFieldCheck);
/*     */   }
/*     */   private static void checkAlternateBinding(BlockScope scope, Expression receiver, TypeBinding receiverType, MethodBinding binding, Expression[] arguments, TypeBinding[] originalArgumentTypes, TypeBinding[] alternateArgumentTypes, final InvocationSite invocationSite) {
/*     */     MethodBinding bindingIfNoCast;
/* 311 */     InvocationSite fakeInvocationSite = new InvocationSite() {
/*     */         public TypeBinding[] genericTypeArguments() {
/* 313 */           return null;
/*     */         } public boolean isSuperAccess() {
/* 315 */           return invocationSite.isSuperAccess();
/*     */         } public boolean isTypeAccess() {
/* 317 */           return invocationSite.isTypeAccess();
/*     */         }
/*     */         public void setActualReceiverType(ReferenceBinding actualReceiverType) {}
/*     */         public void setDepth(int depth) {}
/*     */         
/*     */         public void setFieldIndex(int depth) {}
/*     */         
/*     */         public int sourceStart() {
/* 325 */           return 0;
/*     */         } public int sourceEnd() {
/* 327 */           return 0;
/*     */         } public TypeBinding invocationTargetType() {
/* 329 */           return invocationSite.invocationTargetType();
/*     */         } public boolean receiverIsImplicitThis() {
/* 331 */           return invocationSite.receiverIsImplicitThis();
/*     */         } public InferenceContext18 freshInferenceContext(Scope someScope) {
/* 333 */           return invocationSite.freshInferenceContext(someScope);
/*     */         } public ExpressionContext getExpressionContext() {
/* 335 */           return invocationSite.getExpressionContext();
/*     */         } public boolean isQualifiedSuper() {
/* 337 */           return invocationSite.isQualifiedSuper();
/*     */         } public boolean checkingPotentialCompatibility() {
/* 339 */           return false;
/*     */         }
/*     */         
/*     */         public void acceptPotentiallyCompatibleMethods(MethodBinding[] methods) {}
/*     */       };
/* 344 */     if (binding.isConstructor()) {
/* 345 */       bindingIfNoCast = scope.getConstructor((ReferenceBinding)receiverType, alternateArgumentTypes, fakeInvocationSite);
/*     */     } else {
/* 347 */       bindingIfNoCast = receiver.isImplicitThis() ? 
/* 348 */         scope.getImplicitMethod(binding.selector, alternateArgumentTypes, fakeInvocationSite) : 
/* 349 */         scope.getMethod(receiverType, binding.selector, alternateArgumentTypes, fakeInvocationSite);
/*     */     } 
/* 351 */     if (bindingIfNoCast == binding) {
/* 352 */       int argumentLength = originalArgumentTypes.length;
/* 353 */       if (binding.isVarargs()) {
/* 354 */         int paramLength = binding.parameters.length;
/* 355 */         if (paramLength == argumentLength) {
/* 356 */           int varargsIndex = paramLength - 1;
/* 357 */           ArrayBinding varargsType = (ArrayBinding)binding.parameters[varargsIndex];
/* 358 */           TypeBinding lastArgType = alternateArgumentTypes[varargsIndex];
/*     */ 
/*     */           
/* 361 */           if (varargsType.dimensions != lastArgType.dimensions()) {
/*     */             return;
/*     */           }
/* 364 */           if (lastArgType.isCompatibleWith(varargsType.elementsType()) && 
/* 365 */             lastArgType.isCompatibleWith((TypeBinding)varargsType)) {
/*     */             return;
/*     */           }
/*     */         } 
/*     */       } 
/* 370 */       for (int i = 0; i < argumentLength; i++) {
/* 371 */         if (TypeBinding.notEquals(originalArgumentTypes[i], alternateArgumentTypes[i]))
/*     */         {
/* 373 */           if (!preventsUnlikelyTypeWarning(originalArgumentTypes[i], alternateArgumentTypes[i], receiverType, binding, scope))
/* 374 */             scope.problemReporter().unnecessaryCast((CastExpression)arguments[i]); 
/*     */         }
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private static boolean preventsUnlikelyTypeWarning(TypeBinding castedType, TypeBinding uncastedType, TypeBinding receiverType, MethodBinding binding, BlockScope scope) {
/* 381 */     if (!scope.compilerOptions().isAnyEnabled(IrritantSet.UNLIKELY_ARGUMENT_TYPE))
/* 382 */       return false; 
/* 383 */     if (binding.isStatic() || binding.parameters.length != 1) {
/* 384 */       return false;
/*     */     }
/* 386 */     UnlikelyArgumentCheck argumentChecks = UnlikelyArgumentCheck.determineCheckForNonStaticSingleArgumentMethod(
/* 387 */         uncastedType, (Scope)scope, binding.selector, receiverType, binding.parameters);
/* 388 */     if (argumentChecks != null && argumentChecks.isDangerous(scope)) {
/*     */       
/* 390 */       argumentChecks = UnlikelyArgumentCheck.determineCheckForNonStaticSingleArgumentMethod(
/* 391 */           castedType, (Scope)scope, binding.selector, receiverType, binding.parameters);
/* 392 */       if (argumentChecks == null || !argumentChecks.isDangerous(scope))
/* 393 */         return true; 
/*     */     } 
/* 395 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean checkUnsafeCast(Scope scope, TypeBinding castType, TypeBinding expressionType, TypeBinding match, boolean isNarrowing) {
/* 400 */     return checkUnsafeCast(this, scope, castType, expressionType, match, isNarrowing);
/*     */   }
/*     */ 
/*     */   
/*     */   public static boolean checkUnsafeCast(Expression expression, Scope scope, TypeBinding castType, TypeBinding expressionType, TypeBinding match, boolean isNarrowing) {
/* 405 */     TypeBinding leafType, resolvedType = (expression.resolvedType != null) ? expression.resolvedType : castType;
/* 406 */     if (TypeBinding.equalsEquals(match, castType)) {
/* 407 */       if (!isNarrowing && TypeBinding.equalsEquals(match, resolvedType.leafComponentType()) && (
/* 408 */         !expressionType.isParameterizedType() || !expressionType.isProvablyDistinct(castType))) {
/* 409 */         expression.tagAsUnnecessaryCast(scope, castType);
/*     */       }
/* 411 */       return true;
/*     */     } 
/* 413 */     if (match != null && (
/* 414 */       isNarrowing ? 
/* 415 */       match.isProvablyDistinct(expressionType) : 
/* 416 */       castType.isProvablyDistinct(match))) {
/* 417 */       return false;
/*     */     }
/*     */     
/* 420 */     switch (castType.kind()) {
/*     */       case 260:
/* 422 */         if (!castType.isReifiable()) {
/*     */ 
/*     */ 
/*     */           
/* 426 */           if (match == null) {
/* 427 */             expression.bits |= 0x80;
/* 428 */             return true;
/*     */           } 
/* 430 */           switch (match.kind()) {
/*     */             case 260:
/* 432 */               if (isNarrowing) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */                 
/* 438 */                 if (expressionType.isRawType() || !expressionType.isEquivalentTo(match)) {
/* 439 */                   expression.bits |= 0x80;
/* 440 */                   return true;
/*     */                 } 
/*     */ 
/*     */ 
/*     */                 
/* 445 */                 ParameterizedTypeBinding paramCastType = (ParameterizedTypeBinding)castType;
/* 446 */                 TypeBinding[] castArguments = paramCastType.arguments;
/* 447 */                 int length = (castArguments == null) ? 0 : castArguments.length;
/* 448 */                 if ((paramCastType.tagBits & 0x60000000L) != 0L)
/*     */                 {
/* 450 */                   for (int i = 0; i < length; i++) {
/* 451 */                     if (!castArguments[i].isUnboundWildcard()) {
/*     */                       TypeBinding[] alternateArguments;
/*     */ 
/*     */                       
/* 455 */                       System.arraycopy(paramCastType.arguments, 0, alternateArguments = new TypeBinding[length], 0, length);
/* 456 */                       alternateArguments[i] = TypeBinding.equalsEquals(paramCastType.arguments[i], (TypeBinding)scope.getJavaLangObject()) ? (TypeBinding)scope.getJavaLangBoolean() : (TypeBinding)scope.getJavaLangObject();
/* 457 */                       LookupEnvironment environment = scope.environment();
/* 458 */                       ParameterizedTypeBinding alternateCastType = environment.createParameterizedType((ReferenceBinding)castType.erasure(), alternateArguments, castType.enclosingType());
/* 459 */                       if (TypeBinding.equalsEquals(alternateCastType.findSuperTypeOriginatingFrom(expressionType), match)) {
/* 460 */                         expression.bits |= 0x80;
/*     */                         
/*     */                         break;
/*     */                       } 
/*     */                     } 
/*     */                   } 
/*     */                 }
/* 467 */                 return true;
/*     */               } 
/*     */               
/* 470 */               if (!match.isEquivalentTo(castType)) {
/* 471 */                 expression.bits |= 0x80;
/* 472 */                 return true;
/*     */               } 
/*     */               break;
/*     */             
/*     */             case 1028:
/* 477 */               expression.bits |= 0x80;
/* 478 */               return true;
/*     */           } 
/* 480 */           if (isNarrowing) {
/*     */             
/* 482 */             expression.bits |= 0x80;
/* 483 */             return true;
/*     */           } 
/*     */         } 
/*     */         break;
/*     */ 
/*     */       
/*     */       case 68:
/* 490 */         leafType = castType.leafComponentType();
/* 491 */         if (isNarrowing && (!leafType.isReifiable() || leafType.isTypeVariable())) {
/* 492 */           expression.bits |= 0x80;
/* 493 */           return true;
/*     */         } 
/*     */         break;
/*     */       case 4100:
/* 497 */         expression.bits |= 0x80;
/* 498 */         return true;
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 507 */     if (!isNarrowing && TypeBinding.equalsEquals(match, resolvedType.leafComponentType())) {
/* 508 */       expression.tagAsUnnecessaryCast(scope, castType);
/*     */     }
/* 510 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void generateCode(BlockScope currentScope, CodeStream codeStream, boolean valueRequired) {
/* 522 */     int pc = codeStream.position;
/* 523 */     boolean annotatedCast = ((this.type.bits & 0x100000) != 0);
/* 524 */     boolean needRuntimeCheckcast = ((this.bits & 0x40) != 0);
/* 525 */     if (this.constant != Constant.NotAConstant) {
/* 526 */       if (valueRequired || needRuntimeCheckcast || annotatedCast) {
/* 527 */         codeStream.generateConstant(this.constant, this.implicitConversion);
/* 528 */         if (needRuntimeCheckcast || annotatedCast) {
/* 529 */           codeStream.checkcast(this.type, this.resolvedType, pc);
/*     */         }
/* 531 */         if (!valueRequired)
/*     */         {
/* 533 */           codeStream.pop();
/*     */         }
/*     */       } 
/* 536 */       codeStream.recordPositionsFrom(pc, this.sourceStart);
/*     */       return;
/*     */     } 
/* 539 */     this.expression.generateCode(currentScope, codeStream, !(!annotatedCast && !valueRequired && !needRuntimeCheckcast));
/* 540 */     if (annotatedCast || (needRuntimeCheckcast && TypeBinding.notEquals(this.expression.postConversionType((Scope)currentScope), this.resolvedType.erasure()))) {
/* 541 */       codeStream.checkcast(this.type, this.resolvedType, pc);
/*     */     }
/* 543 */     if (valueRequired) {
/* 544 */       codeStream.generateImplicitConversion(this.implicitConversion);
/* 545 */     } else if (annotatedCast || needRuntimeCheckcast) {
/* 546 */       switch (this.resolvedType.id) {
/*     */         case 7:
/*     */         case 8:
/* 549 */           codeStream.pop2();
/*     */           break;
/*     */         default:
/* 552 */           codeStream.pop();
/*     */           break;
/*     */       } 
/*     */     } 
/* 556 */     codeStream.recordPositionsFrom(pc, this.sourceStart);
/*     */   }
/*     */   
/*     */   public Expression innermostCastedExpression() {
/* 560 */     Expression current = this.expression;
/* 561 */     while (current instanceof CastExpression) {
/* 562 */       current = ((CastExpression)current).expression;
/*     */     }
/* 564 */     return current;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LocalVariableBinding localVariableBinding() {
/* 572 */     return this.expression.localVariableBinding();
/*     */   }
/*     */ 
/*     */   
/*     */   public int nullStatus(FlowInfo flowInfo, FlowContext flowContext) {
/* 577 */     if ((this.implicitConversion & 0x200) != 0)
/* 578 */       return 4; 
/* 579 */     return this.expression.nullStatus(flowInfo, flowContext);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Constant optimizedBooleanConstant() {
/* 587 */     switch (this.resolvedType.id) {
/*     */       case 5:
/*     */       case 33:
/* 590 */         return this.expression.optimizedBooleanConstant();
/*     */     } 
/* 592 */     return Constant.NotAConstant;
/*     */   }
/*     */ 
/*     */   
/*     */   public StringBuffer printExpression(int indent, StringBuffer output) {
/* 597 */     int parenthesesCount = (this.bits & 0x1FE00000) >> 21;
/* 598 */     String suffix = "";
/* 599 */     for (int i = 0; i < parenthesesCount; i++) {
/* 600 */       output.append('(');
/* 601 */       suffix = String.valueOf(suffix) + ')';
/*     */     } 
/* 603 */     output.append('(');
/* 604 */     this.type.print(0, output).append(") ");
/* 605 */     return this.expression.printExpression(0, output).append(suffix);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TypeBinding resolveType(BlockScope scope) {
/* 612 */     this.constant = Constant.NotAConstant;
/* 613 */     this.implicitConversion = 0;
/*     */     
/* 615 */     boolean exprContainCast = false;
/*     */     
/* 617 */     TypeBinding castType = this.resolvedType = this.type.resolveType(scope);
/* 618 */     if ((scope.compilerOptions()).sourceLevel >= 3407872L) {
/* 619 */       this.expression.setExpressionContext(ExpressionContext.CASTING_CONTEXT);
/* 620 */       if (this.expression instanceof FunctionalExpression) {
/* 621 */         this.expression.setExpectedType(this.resolvedType);
/* 622 */         this.bits |= 0x20;
/*     */       } 
/*     */     } 
/* 625 */     if (this.expression instanceof CastExpression) {
/* 626 */       this.expression.bits |= 0x20;
/* 627 */       exprContainCast = true;
/*     */     } 
/* 629 */     TypeBinding expressionType = this.expression.resolveType(scope);
/* 630 */     if (this.expression instanceof MessageSend) {
/* 631 */       MessageSend messageSend = (MessageSend)this.expression;
/* 632 */       MethodBinding methodBinding = messageSend.binding;
/* 633 */       if (methodBinding != null && methodBinding.isPolymorphic()) {
/* 634 */         messageSend.binding = scope.environment().updatePolymorphicMethodReturnType((PolymorphicMethodBinding)methodBinding, castType);
/* 635 */         if (TypeBinding.notEquals(expressionType, castType)) {
/* 636 */           expressionType = castType;
/* 637 */           this.bits |= 0x20;
/*     */         } 
/*     */       } 
/*     */     } 
/* 641 */     if (castType != null) {
/* 642 */       if (expressionType != null) {
/*     */         
/* 644 */         boolean nullAnnotationMismatch = ((scope.compilerOptions()).isAnnotationBasedNullAnalysisEnabled && 
/* 645 */           NullAnnotationMatching.analyse(castType, expressionType, -1).isAnyMismatch());
/*     */         
/* 647 */         if (this.instanceofType != null && expressionType.isParameterizedType() && 
/* 648 */           expressionType.isProvablyDistinct(this.instanceofType)) {
/* 649 */           this.bits |= 0x20;
/*     */         }
/* 651 */         if (this.isVarTypeDeclaration && TypeBinding.notEquals(expressionType, castType)) {
/* 652 */           this.bits |= 0x20;
/*     */         }
/* 654 */         boolean isLegal = checkCastTypesCompatibility((Scope)scope, castType, expressionType, this.expression, true);
/* 655 */         if (isLegal) {
/* 656 */           this.expression.computeConversion((Scope)scope, castType, expressionType);
/* 657 */           if ((this.bits & 0x80) != 0) {
/* 658 */             if ((scope.compilerOptions()).reportUnavoidableGenericTypeProblems || 
/* 659 */               !expressionType.isRawType() || !this.expression.forcedToBeRaw(scope.referenceContext())) {
/* 660 */               scope.problemReporter().unsafeCast(this, (Scope)scope);
/*     */             }
/* 662 */           } else if (nullAnnotationMismatch) {
/*     */             
/* 664 */             scope.problemReporter().unsafeNullnessCast(this, (Scope)scope);
/*     */           } else {
/* 666 */             if (castType.isRawType() && scope.compilerOptions().getSeverity(536936448) != 256) {
/* 667 */               scope.problemReporter().rawTypeReference(this.type, castType);
/*     */             }
/* 669 */             if ((this.bits & 0x4020) == 16384 && 
/* 670 */               !isIndirectlyUsed()) {
/* 671 */               scope.problemReporter().unnecessaryCast(this);
/*     */             }
/*     */           } 
/*     */         } else {
/* 675 */           if ((castType.tagBits & 0x80L) == 0L) {
/* 676 */             scope.problemReporter().typeCastError(this, castType, expressionType);
/*     */           }
/* 678 */           this.bits |= 0x20;
/*     */         } 
/*     */       } 
/* 681 */       this.resolvedType = castType.capture((Scope)scope, this.type.sourceStart, this.type.sourceEnd);
/* 682 */       if (exprContainCast) {
/* 683 */         checkNeedForCastCast(scope, this);
/*     */       }
/*     */     } 
/* 686 */     return this.resolvedType;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setExpectedType(TypeBinding expectedType) {
/* 694 */     this.expectedType = expectedType;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean isIndirectlyUsed() {
/* 702 */     if (this.expression instanceof MessageSend) {
/* 703 */       MethodBinding method = ((MessageSend)this.expression).binding;
/* 704 */       if (method instanceof ParameterizedGenericMethodBinding && 
/* 705 */         ((ParameterizedGenericMethodBinding)method).inferredReturnType) {
/* 706 */         if (this.expectedType == null)
/* 707 */           return true; 
/* 708 */         if (TypeBinding.notEquals(this.resolvedType, this.expectedType))
/* 709 */           return true; 
/*     */       } 
/*     */     } 
/* 712 */     if (this.expectedType != null && this.resolvedType.isBaseType() && !this.resolvedType.isCompatibleWith(this.expectedType))
/*     */     {
/* 714 */       return true;
/*     */     }
/* 716 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void tagAsNeedCheckCast() {
/* 724 */     this.bits |= 0x40;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void tagAsUnnecessaryCast(Scope scope, TypeBinding castType) {
/* 732 */     this.bits |= 0x4000;
/*     */   }
/*     */   
/*     */   public void setInstanceofType(TypeBinding instanceofTypeBinding) {
/* 736 */     this.instanceofType = instanceofTypeBinding;
/*     */   }
/*     */   
/*     */   public void setVarTypeDeclaration(boolean value) {
/* 740 */     this.isVarTypeDeclaration = value;
/*     */   }
/*     */ 
/*     */   
/*     */   public void traverse(ASTVisitor visitor, BlockScope blockScope) {
/* 745 */     if (visitor.visit(this, blockScope)) {
/* 746 */       this.type.traverse(visitor, blockScope);
/* 747 */       this.expression.traverse(visitor, blockScope);
/*     */     } 
/* 749 */     visitor.endVisit(this, blockScope);
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\ast\CastExpression.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */