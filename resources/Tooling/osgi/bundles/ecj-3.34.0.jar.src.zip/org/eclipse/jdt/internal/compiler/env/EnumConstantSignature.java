/*    */ package org.eclipse.jdt.internal.compiler.env;
/*    */ 
/*    */ import java.util.Arrays;
/*    */ import org.eclipse.jdt.core.compiler.CharOperation;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class EnumConstantSignature
/*    */ {
/*    */   char[] typeName;
/*    */   char[] constName;
/*    */   
/*    */   public EnumConstantSignature(char[] typeName, char[] constName) {
/* 30 */     this.typeName = typeName;
/* 31 */     this.constName = constName;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public char[] getTypeName() {
/* 38 */     return this.typeName;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public char[] getEnumConstantName() {
/* 45 */     return this.constName;
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 50 */     StringBuilder buffer = new StringBuilder();
/* 51 */     buffer.append(this.typeName);
/* 52 */     buffer.append('.');
/* 53 */     buffer.append(this.constName);
/* 54 */     return buffer.toString();
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public int hashCode() {
/* 60 */     int result = 1;
/* 61 */     result = 31 * result + CharOperation.hashCode(this.constName);
/* 62 */     result = 31 * result + CharOperation.hashCode(this.typeName);
/* 63 */     return result;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean equals(Object obj) {
/* 68 */     if (this == obj) {
/* 69 */       return true;
/*    */     }
/* 71 */     if (obj == null) {
/* 72 */       return false;
/*    */     }
/* 74 */     if (getClass() != obj.getClass()) {
/* 75 */       return false;
/*    */     }
/* 77 */     EnumConstantSignature other = (EnumConstantSignature)obj;
/* 78 */     if (!Arrays.equals(this.constName, other.constName)) {
/* 79 */       return false;
/*    */     }
/* 81 */     return Arrays.equals(this.typeName, other.typeName);
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\env\EnumConstantSignature.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */