/*     */ package org.eclipse.jdt.internal.compiler.ast;
/*     */ 
/*     */ import org.eclipse.jdt.internal.compiler.ASTVisitor;
/*     */ import org.eclipse.jdt.internal.compiler.codegen.BranchLabel;
/*     */ import org.eclipse.jdt.internal.compiler.codegen.CodeStream;
/*     */ import org.eclipse.jdt.internal.compiler.flow.FlowContext;
/*     */ import org.eclipse.jdt.internal.compiler.flow.FlowInfo;
/*     */ import org.eclipse.jdt.internal.compiler.flow.InsideSubRoutineFlowContext;
/*     */ import org.eclipse.jdt.internal.compiler.impl.Constant;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.BlockScope;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.LocalVariableBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.Scope;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.TypeBinding;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SynchronizedStatement
/*     */   extends SubRoutineStatement
/*     */ {
/*     */   public Expression expression;
/*     */   public Block block;
/*     */   public BlockScope scope;
/*     */   public LocalVariableBinding synchroVariable;
/*  30 */   static final char[] SecretLocalDeclarationName = " syncValue".toCharArray();
/*     */ 
/*     */   
/*  33 */   int preSynchronizedInitStateIndex = -1;
/*  34 */   int mergedSynchronizedInitStateIndex = -1;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SynchronizedStatement(Expression expression, Block statement, int s, int e) {
/*  42 */     this.expression = expression;
/*  43 */     this.block = statement;
/*  44 */     this.sourceEnd = e;
/*  45 */     this.sourceStart = s;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public FlowInfo analyseCode(BlockScope currentScope, FlowContext flowContext, FlowInfo flowInfo) {
/*  54 */     this.preSynchronizedInitStateIndex = 
/*  55 */       currentScope.methodScope().recordInitializationStates(flowInfo);
/*     */ 
/*     */ 
/*     */     
/*  59 */     this.synchroVariable.useFlag = 1;
/*     */ 
/*     */     
/*  62 */     FlowInfo expressionFlowInfo = this.expression.analyseCode(this.scope, flowContext, flowInfo);
/*     */     
/*  64 */     this.expression.checkNPE(currentScope, flowContext, expressionFlowInfo, 1);
/*     */     
/*  66 */     flowInfo = 
/*  67 */       this.block.analyseCode(
/*  68 */         this.scope, 
/*  69 */         (FlowContext)new InsideSubRoutineFlowContext(flowContext, this), 
/*  70 */         expressionFlowInfo);
/*     */     
/*  72 */     this.mergedSynchronizedInitStateIndex = 
/*  73 */       currentScope.methodScope().recordInitializationStates(flowInfo);
/*     */ 
/*     */     
/*  76 */     if ((flowInfo.tagBits & 0x1) != 0) {
/*  77 */       this.bits |= 0x20000000;
/*     */     }
/*     */     
/*  80 */     return flowInfo;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isSubRoutineEscaping() {
/*  85 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void generateCode(BlockScope currentScope, CodeStream codeStream) {
/*  96 */     if ((this.bits & Integer.MIN_VALUE) == 0) {
/*     */       return;
/*     */     }
/*     */ 
/*     */     
/* 101 */     this.anyExceptionLabel = null;
/*     */     
/* 103 */     int pc = codeStream.position;
/*     */ 
/*     */     
/* 106 */     this.expression.generateCode(this.scope, codeStream, true);
/* 107 */     if (this.block.isEmptyBlock()) {
/* 108 */       switch (this.synchroVariable.type.id) {
/*     */         case 7:
/*     */         case 8:
/* 111 */           codeStream.dup2();
/*     */           break;
/*     */         default:
/* 114 */           codeStream.dup();
/*     */           break;
/*     */       } 
/*     */       
/* 118 */       codeStream.monitorenter();
/* 119 */       codeStream.monitorexit();
/* 120 */       if (this.scope != currentScope) {
/* 121 */         codeStream.exitUserScope(this.scope);
/*     */       }
/*     */     } else {
/*     */       
/* 125 */       codeStream.store(this.synchroVariable, true);
/* 126 */       codeStream.addVariable(this.synchroVariable);
/* 127 */       codeStream.monitorenter();
/*     */ 
/*     */       
/* 130 */       enterAnyExceptionHandler(codeStream);
/* 131 */       this.block.generateCode(this.scope, codeStream);
/* 132 */       if (this.scope != currentScope)
/*     */       {
/* 134 */         codeStream.exitUserScope(this.scope, this.synchroVariable);
/*     */       }
/*     */       
/* 137 */       BranchLabel endLabel = new BranchLabel(codeStream);
/* 138 */       if ((this.bits & 0x20000000) == 0) {
/* 139 */         codeStream.load(this.synchroVariable);
/* 140 */         codeStream.monitorexit();
/* 141 */         exitAnyExceptionHandler();
/* 142 */         codeStream.goto_(endLabel);
/* 143 */         enterAnyExceptionHandler(codeStream);
/*     */       } 
/*     */       
/* 146 */       codeStream.pushExceptionOnStack((TypeBinding)this.scope.getJavaLangThrowable());
/* 147 */       if (this.preSynchronizedInitStateIndex != -1) {
/* 148 */         codeStream.removeNotDefinitelyAssignedVariables((Scope)currentScope, this.preSynchronizedInitStateIndex);
/*     */       }
/* 150 */       placeAllAnyExceptionHandler();
/* 151 */       codeStream.load(this.synchroVariable);
/* 152 */       codeStream.monitorexit();
/* 153 */       exitAnyExceptionHandler();
/* 154 */       codeStream.athrow();
/*     */       
/* 156 */       if (this.mergedSynchronizedInitStateIndex != -1) {
/* 157 */         codeStream.removeNotDefinitelyAssignedVariables((Scope)currentScope, this.mergedSynchronizedInitStateIndex);
/* 158 */         codeStream.addDefinitelyAssignedVariables((Scope)currentScope, this.mergedSynchronizedInitStateIndex);
/*     */       } 
/* 160 */       if (this.scope != currentScope) {
/* 161 */         codeStream.removeVariable(this.synchroVariable);
/*     */       }
/* 163 */       if ((this.bits & 0x20000000) == 0) {
/* 164 */         endLabel.place();
/*     */       }
/*     */     } 
/* 167 */     codeStream.recordPositionsFrom(pc, this.sourceStart);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean generateSubRoutineInvocation(BlockScope currentScope, CodeStream codeStream, Object targetLocation, int stateIndex, LocalVariableBinding secretLocal) {
/* 175 */     codeStream.load(this.synchroVariable);
/* 176 */     codeStream.monitorexit();
/* 177 */     exitAnyExceptionHandler();
/* 178 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void resolve(BlockScope upperScope) {
/* 184 */     this.scope = new BlockScope(upperScope);
/* 185 */     TypeBinding type = this.expression.resolveType(this.scope);
/* 186 */     if (type != null) {
/* 187 */       switch (type.id) {
/*     */         case 2:
/*     */         case 3:
/*     */         case 4:
/*     */         case 5:
/*     */         case 7:
/*     */         case 8:
/*     */         case 9:
/*     */         case 10:
/* 196 */           this.scope.problemReporter().invalidTypeToSynchronize(this.expression, type);
/*     */           break;
/*     */         case 6:
/* 199 */           this.scope.problemReporter().illegalVoidExpression(this.expression);
/*     */           break;
/*     */         case 12:
/* 202 */           this.scope.problemReporter().invalidNullToSynchronize(this.expression);
/*     */           break;
/*     */         default:
/* 205 */           if (type.hasValueBasedTypeAnnotation()) {
/* 206 */             this.scope.problemReporter().discouragedValueBasedTypeToSynchronize(this.expression, type);
/*     */           }
/*     */           break;
/*     */       } 
/* 210 */       this.synchroVariable = new LocalVariableBinding(SecretLocalDeclarationName, type, 0, false);
/* 211 */       this.scope.addLocalVariable(this.synchroVariable);
/* 212 */       this.synchroVariable.setConstant(Constant.NotAConstant);
/* 213 */       this.expression.computeConversion((Scope)this.scope, type, type);
/*     */     } 
/* 215 */     this.block.resolveUsing(this.scope);
/*     */   }
/*     */ 
/*     */   
/*     */   public StringBuffer printStatement(int indent, StringBuffer output) {
/* 220 */     printIndent(indent, output);
/* 221 */     output.append("synchronized (");
/* 222 */     this.expression.printExpression(0, output).append(')');
/* 223 */     output.append('\n');
/* 224 */     return this.block.printStatement(indent + 1, output);
/*     */   }
/*     */ 
/*     */   
/*     */   public void traverse(ASTVisitor visitor, BlockScope blockScope) {
/* 229 */     if (visitor.visit(this, blockScope)) {
/* 230 */       this.expression.traverse(visitor, this.scope);
/* 231 */       this.block.traverse(visitor, this.scope);
/*     */     } 
/* 233 */     visitor.endVisit(this, blockScope);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean doesNotCompleteNormally() {
/* 238 */     return this.block.doesNotCompleteNormally();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean completesByContinue() {
/* 243 */     return this.block.completesByContinue();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean canCompleteNormally() {
/* 248 */     return this.block.canCompleteNormally();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean continueCompletes() {
/* 253 */     return this.block.continueCompletes();
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\ast\SynchronizedStatement.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */