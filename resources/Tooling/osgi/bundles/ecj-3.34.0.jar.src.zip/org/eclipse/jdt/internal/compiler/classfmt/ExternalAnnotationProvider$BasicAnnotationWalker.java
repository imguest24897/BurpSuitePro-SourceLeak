/*     */ package org.eclipse.jdt.internal.compiler.classfmt;
/*     */ 
/*     */ import org.eclipse.jdt.core.compiler.CharOperation;
/*     */ import org.eclipse.jdt.internal.compiler.env.IBinaryAnnotation;
/*     */ import org.eclipse.jdt.internal.compiler.env.ITypeAnnotationWalker;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.LookupEnvironment;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.SignatureWrapper;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ abstract class BasicAnnotationWalker
/*     */   implements ITypeAnnotationWalker
/*     */ {
/*     */   char[] source;
/*     */   SignatureWrapper wrapper;
/*     */   int pos;
/*     */   int prevTypeArgStart;
/*     */   int currentTypeBound;
/*     */   LookupEnvironment environment;
/*     */   
/*     */   BasicAnnotationWalker(char[] source, int pos, LookupEnvironment environment) {
/* 405 */     this.source = source;
/* 406 */     this.pos = pos;
/* 407 */     this.environment = environment;
/* 408 */     paramExternalAnnotationProvider.initAnnotations(environment);
/*     */   }
/*     */   
/*     */   SignatureWrapper wrapperWithStart(int start) {
/* 412 */     if (this.wrapper == null)
/* 413 */       this.wrapper = new SignatureWrapper(this.source); 
/* 414 */     this.wrapper.start = start;
/* 415 */     this.wrapper.bracket = -1;
/* 416 */     return this.wrapper;
/*     */   }
/*     */ 
/*     */   
/*     */   public ITypeAnnotationWalker toReceiver() {
/* 421 */     return ITypeAnnotationWalker.EMPTY_ANNOTATION_WALKER;
/*     */   }
/*     */ 
/*     */   
/*     */   public ITypeAnnotationWalker toTypeParameter(boolean isClassTypeParameter, int rank) {
/* 426 */     return ITypeAnnotationWalker.EMPTY_ANNOTATION_WALKER;
/*     */   }
/*     */ 
/*     */   
/*     */   public ITypeAnnotationWalker toTypeParameterBounds(boolean isClassTypeParameter, int parameterRank) {
/* 431 */     return ITypeAnnotationWalker.EMPTY_ANNOTATION_WALKER;
/*     */   }
/*     */ 
/*     */   
/*     */   public ITypeAnnotationWalker toTypeBound(short boundIndex) {
/* 436 */     return ITypeAnnotationWalker.EMPTY_ANNOTATION_WALKER;
/*     */   }
/*     */ 
/*     */   
/*     */   public ITypeAnnotationWalker toSupertype(short index, char[] superTypeSignature) {
/* 441 */     return ITypeAnnotationWalker.EMPTY_ANNOTATION_WALKER;
/*     */   }
/*     */ 
/*     */   
/*     */   public ITypeAnnotationWalker toTypeArgument(int rank) {
/* 446 */     if (rank == 0) {
/* 447 */       int start = CharOperation.indexOf('<', this.source, this.pos) + 1;
/* 448 */       this.prevTypeArgStart = start;
/* 449 */       return new ExternalAnnotationProvider.MethodAnnotationWalker(ExternalAnnotationProvider.this, this.source, start, this.environment);
/*     */     } 
/* 451 */     int next = this.prevTypeArgStart;
/* 452 */     switch (this.source[next])
/*     */     { case '*':
/* 454 */         next = skipNullAnnotation(next + 1);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 464 */         this.prevTypeArgStart = next;
/* 465 */         return new ExternalAnnotationProvider.MethodAnnotationWalker(ExternalAnnotationProvider.this, this.source, next, this.environment);case '+': case '-': next = skipNullAnnotation(next + 1); break; }  next = wrapperWithStart(next).computeEnd(); this.prevTypeArgStart = ++next; return new ExternalAnnotationProvider.MethodAnnotationWalker(ExternalAnnotationProvider.this, this.source, next, this.environment);
/*     */   }
/*     */   
/*     */   public ITypeAnnotationWalker toWildcardBound() {
/*     */     int newPos;
/* 470 */     switch (this.source[this.pos]) {
/*     */       case '+':
/*     */       case '-':
/* 473 */         newPos = skipNullAnnotation(this.pos + 1);
/* 474 */         return new ExternalAnnotationProvider.MethodAnnotationWalker(ExternalAnnotationProvider.this, this.source, newPos, this.environment);
/*     */     } 
/* 476 */     return ITypeAnnotationWalker.EMPTY_ANNOTATION_WALKER;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ITypeAnnotationWalker toNextArrayDimension() {
/* 482 */     if (this.source[this.pos] == '[') {
/* 483 */       int newPos = skipNullAnnotation(this.pos + 1);
/* 484 */       return new ExternalAnnotationProvider.MethodAnnotationWalker(ExternalAnnotationProvider.this, this.source, newPos, this.environment);
/*     */     } 
/* 486 */     return ITypeAnnotationWalker.EMPTY_ANNOTATION_WALKER;
/*     */   }
/*     */ 
/*     */   
/*     */   public ITypeAnnotationWalker toNextNestedType() {
/* 491 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public IBinaryAnnotation[] getAnnotationsAtCursor(int currentTypeId, boolean mayApplyArrayContentsDefaultNullness) {
/* 496 */     if (this.pos != -1 && this.pos < this.source.length - 2)
/* 497 */       switch (this.source[this.pos]) {
/*     */         case '*':
/*     */         case '+':
/*     */         case '-':
/*     */         case 'L':
/*     */         case 'T':
/*     */         case '[':
/* 504 */           switch (this.source[this.pos + 1]) {
/*     */             case '0':
/* 506 */               return new IBinaryAnnotation[] { this.this$0.NULLABLE_ANNOTATION };
/*     */             case '1':
/* 508 */               return new IBinaryAnnotation[] { this.this$0.NONNULL_ANNOTATION };
/*     */           } 
/*     */           break;
/*     */       }  
/* 512 */     return NO_ANNOTATIONS;
/*     */   }
/*     */   int skipNullAnnotation(int cur) {
/* 515 */     if (cur >= this.source.length)
/* 516 */       return cur; 
/* 517 */     switch (this.source[cur]) {
/*     */       case '0':
/*     */       case '1':
/* 520 */         return cur + 1;
/*     */     } 
/* 522 */     return cur;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\classfmt\ExternalAnnotationProvider$BasicAnnotationWalker.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */