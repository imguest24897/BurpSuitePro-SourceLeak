/*     */ package org.eclipse.jdt.internal.compiler.ast;
/*     */ 
/*     */ import org.eclipse.jdt.internal.compiler.ASTVisitor;
/*     */ import org.eclipse.jdt.internal.compiler.impl.Constant;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.Binding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.BlockScope;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.ClassScope;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.ElementValuePair;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.FieldBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.LocalVariableBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.MethodBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.Scope;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.TypeBinding;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MemberValuePair
/*     */   extends ASTNode
/*     */ {
/*     */   public char[] name;
/*     */   public Expression value;
/*     */   public MethodBinding binding;
/*  42 */   public ElementValuePair compilerElementPair = null;
/*     */   
/*     */   public MemberValuePair(char[] token, int sourceStart, int sourceEnd, Expression value) {
/*  45 */     this.name = token;
/*  46 */     this.sourceStart = sourceStart;
/*  47 */     this.sourceEnd = sourceEnd;
/*  48 */     this.value = value;
/*  49 */     if (value instanceof ArrayInitializer) {
/*  50 */       value.bits |= 0x1;
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public StringBuffer print(int indent, StringBuffer output) {
/*  56 */     output
/*  57 */       .append(this.name)
/*  58 */       .append(" = ");
/*  59 */     this.value.print(0, output);
/*  60 */     return output;
/*     */   }
/*     */   public void resolveTypeExpecting(final BlockScope scope, final TypeBinding requiredType) {
/*     */     final TypeBinding valueType;
/*  64 */     if (this.compilerElementPair != null) {
/*     */       return;
/*     */     }
/*     */     
/*  68 */     if (this.value == null) {
/*  69 */       this.compilerElementPair = new ElementValuePair(this.name, this.value, this.binding);
/*     */       return;
/*     */     } 
/*  72 */     if (requiredType == null) {
/*     */       
/*  74 */       if (this.value instanceof ArrayInitializer) {
/*  75 */         this.value.resolveTypeExpecting(scope, (TypeBinding)null);
/*     */       } else {
/*  77 */         this.value.resolveType(scope);
/*     */       } 
/*  79 */       this.compilerElementPair = new ElementValuePair(this.name, this.value, this.binding);
/*     */       
/*     */       return;
/*     */     } 
/*  83 */     this.value.setExpectedType(requiredType);
/*     */     
/*  85 */     if (this.value instanceof ArrayInitializer) {
/*  86 */       ArrayInitializer initializer = (ArrayInitializer)this.value;
/*  87 */       valueType = initializer.resolveTypeExpecting(scope, this.binding.returnType);
/*  88 */     } else if (this.value instanceof ArrayAllocationExpression) {
/*  89 */       scope.problemReporter().annotationValueMustBeArrayInitializer((TypeBinding)this.binding.declaringClass, this.name, this.value);
/*  90 */       this.value.resolveType(scope);
/*  91 */       valueType = null;
/*     */     } else {
/*  93 */       valueType = this.value.resolveType(scope);
/*     */       
/*  95 */       ASTVisitor visitor = new ASTVisitor()
/*     */         {
/*     */           public boolean visit(SingleNameReference reference, BlockScope scop) {
/*  98 */             if (reference.binding instanceof LocalVariableBinding) {
/*  99 */               ((LocalVariableBinding)reference.binding).useFlag = 1;
/*     */             }
/* 101 */             return true;
/*     */           }
/*     */         };
/* 104 */       this.value.traverse(visitor, scope);
/*     */     } 
/* 106 */     this.compilerElementPair = new ElementValuePair(this.name, this.value, this.binding);
/* 107 */     if (valueType == null) {
/*     */       return;
/*     */     }
/* 110 */     final TypeBinding leafType = requiredType.leafComponentType();
/*     */     
/* 112 */     final boolean[] shouldExit = new boolean[1];
/* 113 */     Runnable check = new Runnable()
/*     */       {
/*     */         public void run() {
/* 116 */           if (!MemberValuePair.this.value.isConstantValueOfTypeAssignableToType(valueType, requiredType) && 
/* 117 */             !valueType.isCompatibleWith(requiredType)) {
/* 118 */             if (!requiredType.isArrayType() || 
/* 119 */               requiredType.dimensions() != 1 || (
/* 120 */               !MemberValuePair.this.value.isConstantValueOfTypeAssignableToType(valueType, leafType) && 
/* 121 */               !valueType.isCompatibleWith(leafType))) {
/*     */               
/* 123 */               if (leafType.isAnnotationType() && !valueType.isAnnotationType()) {
/* 124 */                 scope.problemReporter().annotationValueMustBeAnnotation((TypeBinding)MemberValuePair.this.binding.declaringClass, 
/* 125 */                     MemberValuePair.this.name, MemberValuePair.this.value, leafType);
/*     */               } else {
/* 127 */                 scope.problemReporter().typeMismatchError(valueType, requiredType, MemberValuePair.this.value, null);
/*     */               } 
/* 129 */               shouldExit[0] = true;
/*     */             } 
/*     */           } else {
/* 132 */             scope.compilationUnitScope().recordTypeConversion(requiredType.leafComponentType(), valueType.leafComponentType());
/* 133 */             MemberValuePair.this.value.computeConversion((Scope)scope, requiredType, valueType);
/*     */           } 
/*     */         }
/*     */       };
/*     */     
/* 138 */     if (!scope.deferCheck(check)) {
/* 139 */       check.run();
/* 140 */       if (shouldExit[0]) {
/*     */         return;
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 146 */     switch ((leafType.erasure()).id) {
/*     */       case 2:
/*     */       case 3:
/*     */       case 4:
/*     */       case 5:
/*     */       case 7:
/*     */       case 8:
/*     */       case 9:
/*     */       case 10:
/*     */       case 11:
/* 156 */         if (this.value instanceof ArrayInitializer) {
/* 157 */           ArrayInitializer initializer = (ArrayInitializer)this.value;
/* 158 */           Expression[] expressions = initializer.expressions;
/* 159 */           if (expressions != null) {
/* 160 */             for (int i = 0, max = expressions.length; i < max; i++) {
/* 161 */               Expression expression = expressions[i];
/* 162 */               if (expression.resolvedType != null && 
/* 163 */                 expression.constant == Constant.NotAConstant) {
/* 164 */                 scope.problemReporter().annotationValueMustBeConstant((TypeBinding)this.binding.declaringClass, this.name, expressions[i], false);
/*     */               }
/*     */             } 
/*     */           }
/* 168 */         } else if (this.value.constant == Constant.NotAConstant) {
/* 169 */           if (valueType.isArrayType()) {
/* 170 */             scope.problemReporter().annotationValueMustBeArrayInitializer((TypeBinding)this.binding.declaringClass, this.name, this.value);
/*     */           } else {
/* 172 */             scope.problemReporter().annotationValueMustBeConstant((TypeBinding)this.binding.declaringClass, this.name, this.value, false);
/*     */           } 
/*     */         } 
/*     */         return;
/*     */       case 16:
/* 177 */         if (this.value instanceof ArrayInitializer) {
/* 178 */           ArrayInitializer initializer = (ArrayInitializer)this.value;
/* 179 */           Expression[] expressions = initializer.expressions;
/* 180 */           if (expressions != null) {
/* 181 */             for (int i = 0, max = expressions.length; i < max; i++) {
/* 182 */               Expression currentExpression = expressions[i];
/* 183 */               if (!(currentExpression instanceof ClassLiteralAccess)) {
/* 184 */                 scope.problemReporter().annotationValueMustBeClassLiteral((TypeBinding)this.binding.declaringClass, this.name, currentExpression);
/*     */               }
/*     */             } 
/*     */           }
/* 188 */         } else if (!(this.value instanceof ClassLiteralAccess)) {
/* 189 */           scope.problemReporter().annotationValueMustBeClassLiteral((TypeBinding)this.binding.declaringClass, this.name, this.value);
/*     */         } 
/*     */         return;
/*     */     } 
/* 193 */     if (leafType.isEnum()) {
/* 194 */       if (this.value instanceof NullLiteral) {
/* 195 */         scope.problemReporter().annotationValueMustBeConstant((TypeBinding)this.binding.declaringClass, this.name, this.value, true);
/* 196 */       } else if (this.value instanceof ArrayInitializer) {
/* 197 */         ArrayInitializer initializer = (ArrayInitializer)this.value;
/* 198 */         Expression[] expressions = initializer.expressions;
/* 199 */         if (expressions != null) {
/* 200 */           for (int i = 0, max = expressions.length; i < max; i++) {
/* 201 */             Expression currentExpression = expressions[i];
/* 202 */             if (currentExpression instanceof NullLiteral) {
/* 203 */               scope.problemReporter().annotationValueMustBeConstant((TypeBinding)this.binding.declaringClass, this.name, currentExpression, true);
/* 204 */             } else if (currentExpression instanceof NameReference) {
/* 205 */               NameReference nameReference = (NameReference)currentExpression;
/* 206 */               Binding nameReferenceBinding = nameReference.binding;
/* 207 */               if (nameReferenceBinding.kind() == 1) {
/* 208 */                 FieldBinding fieldBinding = (FieldBinding)nameReferenceBinding;
/* 209 */                 if (!fieldBinding.declaringClass.isEnum()) {
/* 210 */                   scope.problemReporter().annotationValueMustBeConstant((TypeBinding)this.binding.declaringClass, this.name, currentExpression, true);
/*     */                 }
/*     */               } 
/*     */             } 
/*     */           } 
/*     */         }
/* 216 */       } else if (this.value instanceof NameReference) {
/* 217 */         NameReference nameReference = (NameReference)this.value;
/* 218 */         Binding nameReferenceBinding = nameReference.binding;
/* 219 */         if (nameReferenceBinding.kind() == 1) {
/* 220 */           FieldBinding fieldBinding = (FieldBinding)nameReferenceBinding;
/* 221 */           if (!fieldBinding.declaringClass.isEnum()) {
/* 222 */             if (!fieldBinding.type.isArrayType()) {
/* 223 */               scope.problemReporter().annotationValueMustBeConstant((TypeBinding)this.binding.declaringClass, this.name, this.value, true);
/*     */             } else {
/* 225 */               scope.problemReporter().annotationValueMustBeArrayInitializer((TypeBinding)this.binding.declaringClass, this.name, this.value);
/*     */             } 
/*     */           }
/*     */         } 
/*     */       } else {
/* 230 */         scope.problemReporter().annotationValueMustBeConstant((TypeBinding)this.binding.declaringClass, this.name, this.value, true);
/*     */       }
/*     */     
/*     */     }
/* 234 */     else if (leafType.isAnnotationType()) {
/* 235 */       if (!valueType.leafComponentType().isAnnotationType()) {
/* 236 */         scope.problemReporter().annotationValueMustBeAnnotation((TypeBinding)this.binding.declaringClass, this.name, this.value, leafType);
/* 237 */       } else if (this.value instanceof ArrayInitializer) {
/* 238 */         ArrayInitializer initializer = (ArrayInitializer)this.value;
/* 239 */         Expression[] expressions = initializer.expressions;
/* 240 */         if (expressions != null) {
/* 241 */           for (int i = 0, max = expressions.length; i < max; i++) {
/* 242 */             Expression currentExpression = expressions[i];
/* 243 */             if (currentExpression instanceof NullLiteral || !(currentExpression instanceof Annotation)) {
/* 244 */               scope.problemReporter().annotationValueMustBeAnnotation((TypeBinding)this.binding.declaringClass, this.name, currentExpression, leafType);
/*     */             }
/*     */           } 
/*     */         }
/* 248 */       } else if (!(this.value instanceof Annotation)) {
/* 249 */         scope.problemReporter().annotationValueMustBeAnnotation((TypeBinding)this.binding.declaringClass, this.name, this.value, leafType);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void traverse(ASTVisitor visitor, BlockScope scope) {
/* 258 */     if (visitor.visit(this, scope) && 
/* 259 */       this.value != null) {
/* 260 */       this.value.traverse(visitor, scope);
/*     */     }
/*     */     
/* 263 */     visitor.endVisit(this, scope);
/*     */   }
/*     */   public void traverse(ASTVisitor visitor, ClassScope scope) {
/* 266 */     if (visitor.visit(this, scope) && 
/* 267 */       this.value != null) {
/* 268 */       this.value.traverse(visitor, scope);
/*     */     }
/*     */     
/* 271 */     visitor.endVisit(this, scope);
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\ast\MemberValuePair.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */