/*     */ package org.eclipse.jdt.internal.compiler.ast;
/*     */ 
/*     */ import org.eclipse.jdt.internal.compiler.ASTVisitor;
/*     */ import org.eclipse.jdt.internal.compiler.codegen.BranchLabel;
/*     */ import org.eclipse.jdt.internal.compiler.codegen.CodeStream;
/*     */ import org.eclipse.jdt.internal.compiler.flow.FlowContext;
/*     */ import org.eclipse.jdt.internal.compiler.flow.FlowInfo;
/*     */ import org.eclipse.jdt.internal.compiler.impl.BooleanConstant;
/*     */ import org.eclipse.jdt.internal.compiler.impl.Constant;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.BlockScope;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.LocalVariableBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.Scope;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.TypeBinding;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class UnaryExpression
/*     */   extends OperatorExpression
/*     */ {
/*     */   public Expression expression;
/*     */   public Constant optimizedBooleanConstant;
/*     */   
/*     */   public UnaryExpression(Expression expression, int operator) {
/*  32 */     this.expression = expression;
/*  33 */     this.bits |= operator << 8;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public FlowInfo analyseCode(BlockScope currentScope, FlowContext flowContext, FlowInfo flowInfo) {
/*  41 */     if ((this.bits & 0x3F00) >> 8 == 11) {
/*  42 */       flowContext.tagBits ^= 0x4;
/*  43 */       flowInfo = this.expression
/*  44 */         .analyseCode(currentScope, flowContext, flowInfo)
/*  45 */         .asNegatedCondition();
/*  46 */       flowContext.tagBits ^= 0x4;
/*     */     } else {
/*  48 */       flowInfo = this.expression
/*  49 */         .analyseCode(currentScope, flowContext, flowInfo);
/*     */     } 
/*  51 */     this.expression.checkNPE(currentScope, flowContext, flowInfo);
/*  52 */     return flowInfo;
/*     */   }
/*     */ 
/*     */   
/*     */   protected void updateFlowOnBooleanResult(FlowInfo flowInfo, boolean result) {
/*  57 */     if ((this.bits & 0x3F00) >> 8 == 11) {
/*  58 */       this.expression.updateFlowOnBooleanResult(flowInfo, !result);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public Constant optimizedBooleanConstant() {
/*  64 */     return (this.optimizedBooleanConstant == null) ? 
/*  65 */       this.constant : 
/*  66 */       this.optimizedBooleanConstant;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void generateCode(BlockScope currentScope, CodeStream codeStream, boolean valueRequired) {
/*     */     BranchLabel falseLabel;
/*  82 */     int pc = codeStream.position;
/*     */     
/*  84 */     if (this.constant != Constant.NotAConstant) {
/*     */       
/*  86 */       if (valueRequired) {
/*  87 */         codeStream.generateConstant(this.constant, this.implicitConversion);
/*     */       }
/*  89 */       codeStream.recordPositionsFrom(pc, this.sourceStart);
/*     */       return;
/*     */     } 
/*  92 */     switch ((this.bits & 0x3F00) >> 8) {
/*     */       case 11:
/*  94 */         switch ((this.expression.implicitConversion & 0xFF) >> 4) {
/*     */ 
/*     */           
/*     */           case 5:
/*  98 */             this.expression.generateOptimizedBoolean(
/*  99 */                 currentScope, 
/* 100 */                 codeStream, 
/* 101 */                 (BranchLabel)null, 
/* 102 */                 falseLabel = new BranchLabel(codeStream), 
/* 103 */                 valueRequired);
/* 104 */             if (valueRequired) {
/* 105 */               codeStream.iconst_0();
/* 106 */               if (falseLabel.forwardReferenceCount() > 0) {
/* 107 */                 BranchLabel endifLabel; codeStream.goto_(endifLabel = new BranchLabel(codeStream));
/* 108 */                 codeStream.decrStackSize(1);
/* 109 */                 falseLabel.place();
/* 110 */                 codeStream.iconst_1();
/* 111 */                 endifLabel.place();
/*     */               }  break;
/*     */             } 
/* 114 */             falseLabel.place();
/*     */             break;
/*     */         } 
/*     */         
/*     */         break;
/*     */       case 12:
/* 120 */         switch ((this.expression.implicitConversion & 0xFF) >> 4) {
/*     */           
/*     */           case 10:
/* 123 */             this.expression.generateCode(currentScope, codeStream, valueRequired);
/* 124 */             if (valueRequired) {
/* 125 */               codeStream.iconst_m1();
/* 126 */               codeStream.ixor();
/*     */             } 
/*     */             break;
/*     */           case 7:
/* 130 */             this.expression.generateCode(currentScope, codeStream, valueRequired);
/* 131 */             if (valueRequired) {
/* 132 */               codeStream.ldc2_w(-1L);
/* 133 */               codeStream.lxor();
/*     */             } 
/*     */             break;
/*     */         } 
/*     */         break;
/*     */       case 13:
/* 139 */         if (this.constant != Constant.NotAConstant) {
/* 140 */           if (valueRequired)
/* 141 */             switch ((this.expression.implicitConversion & 0xFF) >> 4) {
/*     */               case 10:
/* 143 */                 codeStream.generateInlinedValue(this.constant.intValue() * -1);
/*     */                 break;
/*     */               case 9:
/* 146 */                 codeStream.generateInlinedValue(this.constant.floatValue() * -1.0F);
/*     */                 break;
/*     */               case 7:
/* 149 */                 codeStream.generateInlinedValue(this.constant.longValue() * -1L);
/*     */                 break;
/*     */               case 8:
/* 152 */                 codeStream.generateInlinedValue(this.constant.doubleValue() * -1.0D); break;
/*     */             }  
/*     */           break;
/*     */         } 
/* 156 */         this.expression.generateCode(currentScope, codeStream, valueRequired);
/* 157 */         if (valueRequired) {
/* 158 */           switch ((this.expression.implicitConversion & 0xFF) >> 4) {
/*     */             case 10:
/* 160 */               codeStream.ineg();
/*     */               break;
/*     */             case 9:
/* 163 */               codeStream.fneg();
/*     */               break;
/*     */             case 7:
/* 166 */               codeStream.lneg();
/*     */               break;
/*     */             case 8:
/* 169 */               codeStream.dneg();
/*     */               break;
/*     */           } 
/*     */         }
/*     */         break;
/*     */       case 14:
/* 175 */         this.expression.generateCode(currentScope, codeStream, valueRequired); break;
/*     */     } 
/* 177 */     if (valueRequired) {
/* 178 */       codeStream.generateImplicitConversion(this.implicitConversion);
/*     */     }
/* 180 */     codeStream.recordPositionsFrom(pc, this.sourceStart);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void generateOptimizedBoolean(BlockScope currentScope, CodeStream codeStream, BranchLabel trueLabel, BranchLabel falseLabel, boolean valueRequired) {
/* 195 */     if (this.constant != Constant.NotAConstant && this.constant.typeID() == 5) {
/* 196 */       super.generateOptimizedBoolean(
/* 197 */           currentScope, 
/* 198 */           codeStream, 
/* 199 */           trueLabel, 
/* 200 */           falseLabel, 
/* 201 */           valueRequired);
/*     */       return;
/*     */     } 
/* 204 */     if ((this.bits & 0x3F00) >> 8 == 11) {
/* 205 */       this.expression.generateOptimizedBoolean(
/* 206 */           currentScope, 
/* 207 */           codeStream, 
/* 208 */           falseLabel, 
/* 209 */           trueLabel, 
/* 210 */           valueRequired);
/*     */     } else {
/* 212 */       super.generateOptimizedBoolean(
/* 213 */           currentScope, 
/* 214 */           codeStream, 
/* 215 */           trueLabel, 
/* 216 */           falseLabel, 
/* 217 */           valueRequired);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public StringBuffer printExpressionNoParenthesis(int indent, StringBuffer output) {
/* 224 */     output.append(operatorToString()).append(' ');
/* 225 */     return this.expression.printExpression(0, output);
/*     */   }
/*     */   
/*     */   public void collectPatternVariablesToScope(LocalVariableBinding[] variables, BlockScope scope) {
/* 229 */     this.expression.collectPatternVariablesToScope(variables, scope);
/* 230 */     if ((this.bits & 0x3F00) >> 8 == 11) {
/* 231 */       variables = this.expression.getPatternVariablesWhenTrue();
/* 232 */       if (variables != null) {
/* 233 */         addPatternVariablesWhenFalse(variables);
/*     */       }
/* 235 */       variables = this.expression.getPatternVariablesWhenFalse();
/* 236 */       if (variables != null)
/* 237 */         addPatternVariablesWhenTrue(variables); 
/*     */     } else {
/* 239 */       variables = this.expression.getPatternVariablesWhenTrue();
/* 240 */       addPatternVariablesWhenTrue(variables);
/* 241 */       variables = this.expression.getPatternVariablesWhenFalse();
/* 242 */       addPatternVariablesWhenFalse(variables);
/*     */     } 
/*     */   }
/*     */   public TypeBinding resolveType(BlockScope scope) {
/*     */     int tableId;
/*     */     boolean expressionIsCast;
/* 248 */     if (expressionIsCast = this.expression instanceof CastExpression) this.expression.bits |= 0x20; 
/* 249 */     TypeBinding expressionType = this.expression.resolveType(scope);
/* 250 */     if (expressionType == null) {
/* 251 */       this.constant = Constant.NotAConstant;
/* 252 */       return null;
/*     */     } 
/* 254 */     int expressionTypeID = expressionType.id;
/*     */     
/* 256 */     boolean use15specifics = ((scope.compilerOptions()).sourceLevel >= 3211264L);
/* 257 */     if (use15specifics && 
/* 258 */       !expressionType.isBaseType()) {
/* 259 */       expressionTypeID = (scope.environment().computeBoxingType(expressionType)).id;
/*     */     }
/*     */     
/* 262 */     if (expressionTypeID > 15) {
/* 263 */       this.constant = Constant.NotAConstant;
/* 264 */       scope.problemReporter().invalidOperator(this, expressionType);
/* 265 */       return null;
/*     */     } 
/*     */ 
/*     */     
/* 269 */     switch ((this.bits & 0x3F00) >> 8) {
/*     */       case 11:
/* 271 */         tableId = 0;
/*     */         break;
/*     */       case 12:
/* 274 */         tableId = 10;
/*     */         break;
/*     */       default:
/* 277 */         tableId = 13;
/*     */         break;
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 284 */     int operatorSignature = OperatorSignatures[tableId][(expressionTypeID << 4) + expressionTypeID];
/* 285 */     this.expression.computeConversion((Scope)scope, TypeBinding.wellKnownType((Scope)scope, operatorSignature >>> 16 & 0xF), expressionType);
/* 286 */     this.bits |= operatorSignature & 0xF;
/* 287 */     switch (operatorSignature & 0xF) {
/*     */       case 5:
/* 289 */         this.resolvedType = (TypeBinding)TypeBinding.BOOLEAN;
/*     */         break;
/*     */       case 3:
/* 292 */         this.resolvedType = (TypeBinding)TypeBinding.BYTE;
/*     */         break;
/*     */       case 2:
/* 295 */         this.resolvedType = (TypeBinding)TypeBinding.CHAR;
/*     */         break;
/*     */       case 8:
/* 298 */         this.resolvedType = (TypeBinding)TypeBinding.DOUBLE;
/*     */         break;
/*     */       case 9:
/* 301 */         this.resolvedType = (TypeBinding)TypeBinding.FLOAT;
/*     */         break;
/*     */       case 10:
/* 304 */         this.resolvedType = (TypeBinding)TypeBinding.INT;
/*     */         break;
/*     */       case 7:
/* 307 */         this.resolvedType = (TypeBinding)TypeBinding.LONG;
/*     */         break;
/*     */       default:
/* 310 */         this.constant = Constant.NotAConstant;
/* 311 */         if (expressionTypeID != 0)
/* 312 */           scope.problemReporter().invalidOperator(this, expressionType); 
/* 313 */         return null;
/*     */     } 
/*     */     
/* 316 */     if (this.expression.constant != Constant.NotAConstant) {
/* 317 */       this.constant = 
/* 318 */         Constant.computeConstantOperation(
/* 319 */           this.expression.constant, 
/* 320 */           expressionTypeID, (
/* 321 */           this.bits & 0x3F00) >> 8);
/*     */     } else {
/* 323 */       this.constant = Constant.NotAConstant;
/* 324 */       if ((this.bits & 0x3F00) >> 8 == 11) {
/* 325 */         Constant cst = this.expression.optimizedBooleanConstant();
/* 326 */         if (cst != Constant.NotAConstant)
/* 327 */           this.optimizedBooleanConstant = BooleanConstant.fromValue(!cst.booleanValue()); 
/*     */       } 
/*     */     } 
/* 330 */     if (expressionIsCast)
/*     */     {
/* 332 */       CastExpression.checkNeedForArgumentCast(scope, tableId, operatorSignature, this.expression, expressionTypeID);
/*     */     }
/* 334 */     return this.resolvedType;
/*     */   }
/*     */   
/*     */   public boolean containsPatternVariable() {
/* 338 */     return this.expression.containsPatternVariable();
/*     */   }
/*     */   
/*     */   public LocalDeclaration getPatternVariable() {
/* 342 */     return this.expression.getPatternVariable();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void traverse(ASTVisitor visitor, BlockScope blockScope) {
/* 350 */     if (visitor.visit(this, blockScope)) {
/* 351 */       this.expression.traverse(visitor, blockScope);
/*     */     }
/* 353 */     visitor.endVisit(this, blockScope);
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\ast\UnaryExpression.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */