/*     */ package org.eclipse.jdt.internal.compiler.ast;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.eclipse.jdt.internal.compiler.ASTVisitor;
/*     */ import org.eclipse.jdt.internal.compiler.codegen.BranchLabel;
/*     */ import org.eclipse.jdt.internal.compiler.codegen.CodeStream;
/*     */ import org.eclipse.jdt.internal.compiler.flow.FlowContext;
/*     */ import org.eclipse.jdt.internal.compiler.flow.FlowInfo;
/*     */ import org.eclipse.jdt.internal.compiler.impl.Constant;
/*     */ import org.eclipse.jdt.internal.compiler.impl.IntConstant;
/*     */ import org.eclipse.jdt.internal.compiler.impl.JavaFeature;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.BlockScope;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.FieldBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.LocalVariableBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.ReferenceBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.Scope;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.TypeBinding;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CaseStatement
/*     */   extends Statement
/*     */ {
/*     */   static final int CASE_CONSTANT = 1;
/*     */   static final int CASE_PATTERN = 2;
/*     */   public BranchLabel targetLabel;
/*     */   public Expression[] constantExpressions;
/*     */   public BranchLabel[] targetLabels;
/*     */   public boolean isExpr = false;
/*  46 */   int patternIndex = -1;
/*     */   
/*     */   public CaseStatement(Expression constantExpression, int sourceEnd, int sourceStart) {
/*  49 */     this(sourceEnd, sourceStart, (constantExpression != null) ? new Expression[1] : null);
/*     */   }
/*     */   
/*     */   public CaseStatement(int sourceEnd, int sourceStart, Expression[] constantExpressions) {
/*  53 */     this.constantExpressions = constantExpressions;
/*  54 */     this.sourceEnd = sourceEnd;
/*  55 */     this.sourceStart = sourceStart;
/*  56 */     initPatterns();
/*     */   }
/*     */   
/*     */   private void initPatterns() {
/*  60 */     int l = (this.constantExpressions == null) ? 0 : this.constantExpressions.length;
/*  61 */     for (int i = 0; i < l; i++) {
/*  62 */       Expression e = this.constantExpressions[i];
/*  63 */       if (e instanceof Pattern) {
/*  64 */         this.patternIndex = i;
/*     */         break;
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public FlowInfo analyseCode(BlockScope currentScope, FlowContext flowContext, FlowInfo flowInfo) {
/*  75 */     if (this.constantExpressions != null) {
/*  76 */       int nullPatternCount = 0;
/*  77 */       for (int i = 0; i < this.constantExpressions.length; i++) {
/*  78 */         Expression e = this.constantExpressions[i];
/*  79 */         nullPatternCount += (e instanceof NullLiteral) ? 1 : 0;
/*  80 */         if (i > 0 && e instanceof Pattern && (
/*  81 */           i != nullPatternCount || !(e instanceof TypePattern))) {
/*  82 */           currentScope.problemReporter().IllegalFallThroughToPattern(e);
/*     */         }
/*  84 */         flowInfo = analyseConstantExpression(currentScope, flowContext, flowInfo, e);
/*  85 */         if (nullPatternCount > 0 && e instanceof TypePattern) {
/*  86 */           LocalVariableBinding binding = ((TypePattern)e).local.binding;
/*  87 */           if (binding != null)
/*  88 */             flowInfo.markNullStatus(binding, 16); 
/*     */         } 
/*     */       } 
/*     */     } 
/*  92 */     return flowInfo;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private FlowInfo analyseConstantExpression(BlockScope currentScope, FlowContext flowContext, FlowInfo flowInfo, Expression e) {
/*  99 */     if (e.constant == Constant.NotAConstant && 
/* 100 */       !e.resolvedType.isEnum()) {
/* 101 */       boolean caseNullorDefaultAllowed = 
/* 102 */         (JavaFeature.PATTERN_MATCHING_IN_SWITCH.isSupported(currentScope.compilerOptions()) && (
/* 103 */         e instanceof NullLiteral || e instanceof FakeDefaultLiteral));
/* 104 */       if (!caseNullorDefaultAllowed)
/* 105 */         currentScope.problemReporter().caseExpressionMustBeConstant(e); 
/* 106 */       if (e instanceof NullLiteral && flowContext.associatedNode instanceof SwitchStatement) {
/* 107 */         Expression switchValue = ((SwitchStatement)flowContext.associatedNode).expression;
/* 108 */         if (switchValue != null && switchValue.nullStatus(flowInfo, flowContext) == 4) {
/* 109 */           currentScope.problemReporter().unnecessaryNullCaseInSwitchOverNonNull(this);
/*     */         }
/*     */       } 
/*     */     } 
/* 113 */     return e.analyseCode(currentScope, flowContext, flowInfo);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean containsPatternVariable() {
/* 118 */     if (this.patternIndex == -1 || 
/* 119 */       this.constantExpressions.length <= this.patternIndex || 
/* 120 */       !(this.constantExpressions[this.patternIndex] instanceof Pattern)) {
/* 121 */       return false;
/*     */     }
/* 123 */     for (int i = 0, l = this.constantExpressions.length; i < l; i++) {
/* 124 */       if (this.constantExpressions[i] instanceof Pattern) {
/* 125 */         Pattern pattern = (Pattern)this.constantExpressions[i];
/* 126 */         if (pattern.containsPatternVariable())
/* 127 */           return true; 
/*     */       } 
/*     */     } 
/* 130 */     return false;
/*     */   }
/*     */   
/*     */   public StringBuffer printStatement(int tab, StringBuffer output) {
/* 134 */     printIndent(tab, output);
/* 135 */     if (this.constantExpressions == null) {
/* 136 */       output.append("default ");
/* 137 */       output.append(this.isExpr ? "->" : ":");
/*     */     } else {
/* 139 */       output.append("case ");
/* 140 */       for (int i = 0, l = this.constantExpressions.length; i < l; i++) {
/* 141 */         this.constantExpressions[i].printExpression(0, output);
/* 142 */         if (i < l - 1) output.append(','); 
/*     */       } 
/* 144 */       output.append(this.isExpr ? " ->" : " :");
/*     */     } 
/* 146 */     return output;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void generateCode(BlockScope currentScope, CodeStream codeStream) {
/* 155 */     if ((this.bits & Integer.MIN_VALUE) == 0) {
/*     */       return;
/*     */     }
/* 158 */     int pc = codeStream.position;
/* 159 */     if (this.targetLabels != null) {
/* 160 */       for (int i = 0, l = this.targetLabels.length; i < l; i++) {
/* 161 */         this.targetLabels[i].place();
/*     */       }
/*     */     }
/* 164 */     if (this.targetLabel != null)
/* 165 */       this.targetLabel.place(); 
/* 166 */     casePatternExpressionGenerateCode(currentScope, codeStream);
/* 167 */     codeStream.recordPositionsFrom(pc, this.sourceStart);
/*     */   }
/*     */   
/*     */   private void casePatternExpressionGenerateCode(BlockScope currentScope, CodeStream codeStream) {
/* 171 */     if (this.patternIndex != -1) {
/* 172 */       Pattern pattern = (Pattern)this.constantExpressions[this.patternIndex];
/* 173 */       if (containsPatternVariable()) {
/* 174 */         LocalVariableBinding local = currentScope.findVariable(SwitchStatement.SecretPatternVariableName, null);
/* 175 */         codeStream.load(local);
/* 176 */         pattern.generateCode(currentScope, codeStream);
/*     */       } else {
/* 178 */         pattern.setTargets(codeStream);
/*     */       } 
/*     */       
/* 181 */       if (!(pattern instanceof GuardedPattern)) {
/* 182 */         codeStream.goto_(pattern.thenTarget);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void resolve(BlockScope scope) {}
/*     */ 
/*     */   
/*     */   public static class ResolvedCase
/*     */   {
/* 194 */     static final ResolvedCase[] UnresolvedCase = new ResolvedCase[0]; public Constant c;
/*     */     public Expression e;
/*     */     public TypeBinding t;
/*     */     public int index;
/*     */     private int intValue;
/*     */     private boolean isPattern;
/*     */     
/*     */     ResolvedCase(Constant c, Expression e, TypeBinding t, int index) {
/* 202 */       this.c = c;
/* 203 */       this.e = e;
/* 204 */       this.t = t;
/* 205 */       this.index = index;
/* 206 */       if (c.typeID() == 11) {
/* 207 */         c.stringValue().hashCode();
/*     */       } else {
/* 209 */         this.intValue = c.intValue();
/*     */       } 
/* 211 */       this.isPattern = e instanceof Pattern;
/*     */     }
/*     */     public int intValue() {
/* 214 */       return this.intValue;
/*     */     }
/*     */     public boolean isPattern() {
/* 217 */       return this.isPattern;
/*     */     }
/*     */     
/*     */     public String toString() {
/* 221 */       StringBuilder builder = new StringBuilder();
/* 222 */       builder.append("case ");
/* 223 */       builder.append(this.e);
/* 224 */       builder.append(" [CONSTANT=");
/* 225 */       builder.append(this.c);
/* 226 */       builder.append("]");
/* 227 */       return builder.toString();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ResolvedCase[] resolveCase(BlockScope scope, TypeBinding switchExpressionType, SwitchStatement switchStatement) {
/* 234 */     if (containsPatternVariable()) {
/* 235 */       return resolveWithPatternVariablesInScope(this.patternVarsWhenTrue, scope, switchExpressionType, switchStatement);
/*     */     }
/* 237 */     return resolveCasePrivate(scope, switchExpressionType, switchStatement);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ResolvedCase[] resolveWithPatternVariablesInScope(LocalVariableBinding[] patternVariablesInScope, BlockScope scope, TypeBinding switchExpressionType, SwitchStatement switchStatement) {
/* 243 */     if (patternVariablesInScope != null) {
/* 244 */       byte b; int i; LocalVariableBinding[] arrayOfLocalVariableBinding1; for (i = (arrayOfLocalVariableBinding1 = patternVariablesInScope).length, b = 0; b < i; ) { LocalVariableBinding binding = arrayOfLocalVariableBinding1[b];
/* 245 */         binding.modifiers &= 0xEFFFFFFF; b++; }
/*     */       
/* 247 */       ResolvedCase[] cases = resolveCasePrivate(scope, switchExpressionType, switchStatement); LocalVariableBinding[] arrayOfLocalVariableBinding2;
/* 248 */       for (int j = (arrayOfLocalVariableBinding2 = patternVariablesInScope).length; i < j; ) { LocalVariableBinding binding = arrayOfLocalVariableBinding2[i];
/* 249 */         binding.modifiers |= 0x10000000; i++; }
/*     */       
/* 251 */       return cases;
/*     */     } 
/* 253 */     return resolveCasePrivate(scope, switchExpressionType, switchStatement);
/*     */   }
/*     */   
/*     */   private Expression getFirstValidExpression(BlockScope scope, SwitchStatement switchStatement) {
/* 257 */     assert this.constantExpressions != null;
/* 258 */     Expression ret = null;
/* 259 */     int patternCaseLabelCount = 0;
/* 260 */     int defaultCaseLabelCount = 0;
/* 261 */     int nullCaseLabelCount = 0;
/*     */     
/* 263 */     boolean patternSwitchAllowed = JavaFeature.PATTERN_MATCHING_IN_SWITCH.isSupported(scope.compilerOptions());
/* 264 */     if (patternSwitchAllowed)
/* 265 */     { int exprCount = 0; byte b; int i; Expression[] arrayOfExpression;
/* 266 */       for (i = (arrayOfExpression = this.constantExpressions).length, b = 0; b < i; ) { Expression e = arrayOfExpression[b];
/* 267 */         exprCount++;
/* 268 */         if (e instanceof FakeDefaultLiteral) {
/* 269 */           scope.problemReporter().validateJavaFeatureSupport(JavaFeature.PATTERN_MATCHING_IN_SWITCH, 
/* 270 */               e.sourceStart, e.sourceEnd);
/* 271 */           flagDuplicateDefault(scope, switchStatement, 
/* 272 */               (this.constantExpressions.length > 1) ? e : this);
/* 273 */           if (exprCount != 2 || nullCaseLabelCount < 1) {
/* 274 */             scope.problemReporter().patternSwitchCaseDefaultOnlyAsSecond(e);
/*     */           }
/* 276 */           if (patternCaseLabelCount > 0) {
/* 277 */             scope.problemReporter().switchPatternBothPatternAndDefaultCaseLabelsNotAllowed(e);
/*     */           }
/* 279 */           defaultCaseLabelCount++;
/*     */         } else {
/*     */           
/* 282 */           if (e instanceof Pattern) {
/* 283 */             scope.problemReporter().validateJavaFeatureSupport(JavaFeature.PATTERN_MATCHING_IN_SWITCH, 
/* 284 */                 e.sourceStart, e.sourceEnd);
/* 285 */             if (patternCaseLabelCount++ > 0) {
/* 286 */               scope.problemReporter().switchPatternOnlyOnePatternCaseLabelAllowed(e);
/* 287 */               return e;
/* 288 */             }  if (defaultCaseLabelCount > 0) {
/* 289 */               scope.problemReporter().switchPatternBothPatternAndDefaultCaseLabelsNotAllowed(e);
/* 290 */               return e;
/*     */             } 
/* 292 */             if (nullCaseLabelCount > 0) {
/* 293 */               scope.problemReporter().cannotMixNullAndNonTypePattern(e);
/* 294 */               return e;
/*     */             } 
/* 296 */           } else if (e instanceof NullLiteral) {
/* 297 */             scope.problemReporter().validateJavaFeatureSupport(JavaFeature.PATTERN_MATCHING_IN_SWITCH, 
/* 298 */                 e.sourceStart, e.sourceEnd);
/* 299 */             if (switchStatement.nullCase == null) {
/* 300 */               switchStatement.nullCase = this;
/*     */             }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */             
/* 307 */             nullCaseLabelCount++;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */             
/* 313 */             if (exprCount > 1 && nullCaseLabelCount < 2) {
/* 314 */               scope.problemReporter().patternSwitchNullOnlyOrFirstWithDefault(e);
/* 315 */               return e;
/*     */             } 
/*     */           } 
/* 318 */           if (ret == null) ret = e; 
/*     */         }  b++; }
/*     */        }
/* 321 */     else { byte b; int i; Expression[] arrayOfExpression; for (i = (arrayOfExpression = this.constantExpressions).length, b = 0; b < i; ) { Expression e = arrayOfExpression[b];
/* 322 */         if (e instanceof Pattern || 
/* 323 */           e instanceof NullLiteral || 
/* 324 */           e instanceof FakeDefaultLiteral)
/* 325 */         { scope.problemReporter().validateJavaFeatureSupport(JavaFeature.PATTERN_MATCHING_IN_SWITCH, 
/* 326 */               e.sourceStart, e.sourceEnd);
/*     */            }
/*     */         
/* 329 */         else if (ret == null) { ret = e; }
/*     */          b++; }
/*     */        }
/* 332 */      return ret;
/*     */   }
/*     */   
/*     */   private ResolvedCase[] resolveCasePrivate(BlockScope scope, TypeBinding switchExpressionType, SwitchStatement switchStatement) {
/* 336 */     scope.enclosingCase = this;
/* 337 */     if (this.constantExpressions == null) {
/* 338 */       flagDuplicateDefault(scope, switchStatement, this);
/* 339 */       return ResolvedCase.UnresolvedCase;
/*     */     } 
/* 341 */     Expression constExpr = getFirstValidExpression(scope, switchStatement);
/* 342 */     if (constExpr == null) {
/* 343 */       return ResolvedCase.UnresolvedCase;
/*     */     }
/*     */ 
/*     */     
/* 347 */     switchStatement.cases[switchStatement.caseCount++] = this;
/* 348 */     if (switchExpressionType != null && switchExpressionType.isEnum() && constExpr instanceof SingleNameReference) {
/* 349 */       ((SingleNameReference)constExpr).setActualReceiverType((ReferenceBinding)switchExpressionType);
/*     */     }
/*     */     
/* 352 */     TypeBinding caseType = constExpr.resolveType(scope);
/* 353 */     if (caseType == null || switchExpressionType == null) return ResolvedCase.UnresolvedCase;
/*     */ 
/*     */     
/* 356 */     List<ResolvedCase> cases = new ArrayList<>(); byte b; int i; Expression[] arrayOfExpression;
/* 357 */     for (i = (arrayOfExpression = this.constantExpressions).length, b = 0; b < i; ) { Expression e = arrayOfExpression[b];
/* 358 */       if (e != constExpr) {
/* 359 */         if (switchExpressionType.isEnum() && e instanceof SingleNameReference) {
/* 360 */           ((SingleNameReference)e).setActualReceiverType((ReferenceBinding)switchExpressionType);
/* 361 */         } else if (e instanceof FakeDefaultLiteral) {
/*     */           continue;
/*     */         } 
/* 364 */         caseType = e.resolveType(scope);
/*     */       } 
/* 366 */       if (caseType == null) {
/* 367 */         return ResolvedCase.UnresolvedCase;
/*     */       }
/* 369 */       if (caseType.isValidBinding()) {
/* 370 */         Constant con = resolveConstantExpression(scope, caseType, switchExpressionType, switchStatement, e);
/* 371 */         if (con != Constant.NotAConstant) {
/* 372 */           int index = (this == switchStatement.nullCase && e instanceof NullLiteral) ? 
/* 373 */             -1 : switchStatement.constantIndex++;
/* 374 */           cases.add(new ResolvedCase(con, e, caseType, index));
/*     */         } 
/*     */       }  continue; b++; }
/*     */     
/* 378 */     resolveWithPatternVariablesInScope(getPatternVariablesWhenTrue(), scope);
/* 379 */     if (cases.size() > 0) {
/* 380 */       return cases.<ResolvedCase>toArray(new ResolvedCase[cases.size()]);
/*     */     }
/*     */     
/* 383 */     return ResolvedCase.UnresolvedCase;
/*     */   }
/*     */ 
/*     */   
/*     */   private void flagDuplicateDefault(BlockScope scope, SwitchStatement switchStatement, ASTNode node) {
/* 388 */     if (switchStatement.defaultCase != null) {
/* 389 */       scope.problemReporter().duplicateDefaultCase(node);
/*     */     }
/*     */     
/* 392 */     switchStatement.defaultCase = this;
/* 393 */     if ((switchStatement.switchBits & 0x4) != 0)
/* 394 */       scope.problemReporter().illegalTotalPatternWithDefault(this); 
/*     */   }
/*     */   
/*     */   public void collectPatternVariablesToScope(LocalVariableBinding[] variables, BlockScope scope) {
/* 398 */     if (!containsPatternVariable())
/*     */       return;  byte b; int i;
/*     */     Expression[] arrayOfExpression;
/* 401 */     for (i = (arrayOfExpression = this.constantExpressions).length, b = 0; b < i; ) { Expression e = arrayOfExpression[b];
/* 402 */       e.collectPatternVariablesToScope(variables, scope);
/* 403 */       LocalVariableBinding[] patternVariables = e.getPatternVariablesWhenTrue();
/* 404 */       addPatternVariablesWhenTrue(patternVariables);
/*     */       b++; }
/*     */   
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Constant resolveConstantExpression(BlockScope scope, TypeBinding caseType, TypeBinding switchType, SwitchStatement switchStatement, Expression expression) {
/* 413 */     boolean patternSwitchAllowed = JavaFeature.PATTERN_MATCHING_IN_SWITCH.isSupported(scope.compilerOptions());
/* 414 */     if (patternSwitchAllowed) {
/* 415 */       if (expression instanceof Pattern)
/* 416 */         return resolveConstantExpression(scope, caseType, switchType, 
/* 417 */             switchStatement, (Pattern)expression); 
/* 418 */       if (expression instanceof NullLiteral) {
/* 419 */         if (!(switchType instanceof ReferenceBinding)) {
/* 420 */           scope.problemReporter().typeMismatchError((TypeBinding)TypeBinding.NULL, switchType, expression, null);
/*     */         }
/* 422 */         switchStatement.switchBits |= 0x2;
/* 423 */         return IntConstant.fromValue(-1);
/* 424 */       }  if (!(expression instanceof FakeDefaultLiteral))
/*     */       {
/*     */         
/* 427 */         if (switchStatement.isNonTraditional && 
/* 428 */           switchType.isBaseType() && !expression.isConstantValueOfTypeAssignableToType(caseType, switchType)) {
/* 429 */           scope.problemReporter().typeMismatchError(caseType, switchType, expression, null);
/* 430 */           return Constant.NotAConstant;
/*     */         } 
/*     */       }
/*     */     } 
/*     */     
/* 435 */     boolean boxing = !(patternSwitchAllowed && 
/* 436 */       !switchStatement.isAllowedType(switchType));
/*     */     
/* 438 */     if (expression.isConstantValueOfTypeAssignableToType(caseType, switchType) || (
/* 439 */       caseType.isCompatibleWith(switchType) && 
/* 440 */       !(expression instanceof StringLiteral))) {
/* 441 */       if (caseType.isEnum()) {
/* 442 */         if ((expression.bits & 0x1FE00000) >> 21 != 0) {
/* 443 */           scope.problemReporter().enumConstantsCannotBeSurroundedByParenthesis(expression);
/*     */         }
/*     */         
/* 446 */         if (expression instanceof NameReference && (
/* 447 */           expression.bits & 0x7) == 1) {
/* 448 */           NameReference reference = (NameReference)expression;
/* 449 */           FieldBinding field = reference.fieldBinding();
/* 450 */           if ((field.modifiers & 0x4000) == 0) {
/* 451 */             scope.problemReporter().enumSwitchCannotTargetField(reference, field);
/* 452 */           } else if (reference instanceof QualifiedNameReference) {
/* 453 */             scope.problemReporter().cannotUseQualifiedEnumConstantInCaseLabel(reference, field);
/*     */           } 
/* 455 */           return IntConstant.fromValue((field.original()).id + 1);
/*     */         } 
/*     */       } else {
/* 458 */         return expression.constant;
/*     */       } 
/* 460 */     } else if (boxing && isBoxingCompatible(caseType, switchType, expression, (Scope)scope)) {
/*     */       
/* 462 */       return expression.constant;
/*     */     } 
/* 464 */     scope.problemReporter().typeMismatchError(expression.resolvedType, switchType, expression, switchStatement.expression);
/* 465 */     return Constant.NotAConstant;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Constant resolveConstantExpression(BlockScope scope, TypeBinding caseType, TypeBinding switchExpressionType, SwitchStatement switchStatement, Pattern e) {
/* 473 */     Constant constant = Constant.NotAConstant;
/* 474 */     TypeBinding type = e.resolveType(scope);
/* 475 */     if (type != null) {
/* 476 */       constant = IntConstant.fromValue(switchStatement.constantIndex);
/* 477 */       switchStatement.caseLabelElements.add(e);
/* 478 */       if (e.resolvedType != null) {
/*     */ 
/*     */         
/* 481 */         TypeBinding pb = e.resolveAtType(scope, switchStatement.expression.resolvedType);
/* 482 */         if (pb != null) switchStatement.caseLabelElementTypes.add(pb); 
/* 483 */         TypeBinding expressionType = switchStatement.expression.resolvedType;
/*     */ 
/*     */         
/* 486 */         if (!pb.isReifiable()) {
/* 487 */           if (expressionType != TypeBinding.NULL) {
/* 488 */             boolean isLegal = e.checkCastTypesCompatibility((Scope)scope, pb, expressionType, e, false);
/* 489 */             if (!isLegal || (e.bits & 0x80) != 0) {
/* 490 */               scope.problemReporter().unsafeCastInInstanceof(e, pb, expressionType);
/*     */             }
/*     */           } 
/* 493 */         } else if (pb.isValidBinding()) {
/*     */           
/* 495 */           if (pb.isPrimitiveType()) {
/* 496 */             scope.problemReporter().unexpectedTypeinSwitchPattern(pb, e);
/* 497 */             return Constant.NotAConstant;
/*     */           } 
/* 499 */           if (pb.isBaseType() || 
/* 500 */             !e.checkCastTypesCompatibility((Scope)scope, pb, expressionType, (Expression)null, false)) {
/* 501 */             scope.problemReporter().typeMismatchError(expressionType, pb, e, null);
/* 502 */             return Constant.NotAConstant;
/*     */           } 
/*     */         } 
/* 505 */         if (e.isTotalForType(expressionType)) {
/* 506 */           if ((switchStatement.switchBits & 0x4) != 0) {
/* 507 */             scope.problemReporter().duplicateTotalPattern(e);
/* 508 */             return IntConstant.fromValue(-1);
/*     */           } 
/* 510 */           switchStatement.switchBits |= 0xC;
/* 511 */           if (switchStatement.defaultCase != null)
/* 512 */             scope.problemReporter().illegalTotalPatternWithDefault(this); 
/* 513 */           switchStatement.totalPattern = e;
/* 514 */           e.isTotalTypeNode = true;
/* 515 */           if (switchStatement.nullCase == null) {
/* 516 */             constant = IntConstant.fromValue(-1);
/*     */           }
/*     */         } 
/*     */       } 
/*     */     } 
/* 521 */     return constant; } void patternCaseRemovePatternLocals(final CodeStream codeStream) {
/*     */     byte b;
/*     */     int i;
/*     */     Expression[] arrayOfExpression;
/* 525 */     for (i = (arrayOfExpression = this.constantExpressions).length, b = 0; b < i; ) { Expression e = arrayOfExpression[b];
/* 526 */       if (e instanceof Pattern)
/* 527 */         e.traverse(new ASTVisitor()
/*     */             {
/*     */               public boolean visit(TypePattern typePattern, BlockScope scope) {
/* 530 */                 LocalDeclaration local = typePattern.getPatternVariable();
/* 531 */                 if (local != null && local.binding != null)
/* 532 */                   codeStream.removeVariable(local.binding); 
/* 533 */                 return false;
/*     */               }
/* 535 */             },  (BlockScope)null); 
/*     */       b++; }
/*     */   
/*     */   }
/*     */   
/*     */   public void traverse(ASTVisitor visitor, BlockScope blockScope) {
/* 541 */     if (visitor.visit(this, blockScope) && 
/* 542 */       this.constantExpressions != null) {
/* 543 */       byte b; int i; Expression[] arrayOfExpression; for (i = (arrayOfExpression = this.constantExpressions).length, b = 0; b < i; ) { Expression e = arrayOfExpression[b];
/* 544 */         e.traverse(visitor, blockScope);
/*     */         
/*     */         b++; }
/*     */     
/*     */     } 
/* 549 */     visitor.endVisit(this, blockScope);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LocalDeclaration getLocalDeclaration() {
/* 557 */     Expression cexp = this.constantExpressions[this.patternIndex];
/* 558 */     LocalDeclaration patternVariableIntroduced = cexp.getPatternVariable();
/* 559 */     return patternVariableIntroduced;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\ast\CaseStatement.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */