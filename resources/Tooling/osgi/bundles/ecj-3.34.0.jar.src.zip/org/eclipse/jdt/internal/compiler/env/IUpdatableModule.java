/*     */ package org.eclipse.jdt.internal.compiler.env;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.function.Consumer;
/*     */ import org.eclipse.jdt.core.compiler.CharOperation;
/*     */ import org.eclipse.jdt.internal.compiler.util.SimpleSetOfCharArray;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public interface IUpdatableModule
/*     */ {
/*     */   char[] name();
/*     */   
/*     */   void addReads(char[] paramArrayOfchar);
/*     */   
/*     */   void addExports(char[] paramArrayOfchar, char[][] paramArrayOfchar1);
/*     */   
/*     */   void setMainClassName(char[] paramArrayOfchar);
/*     */   
/*     */   void setPackageNames(SimpleSetOfCharArray paramSimpleSetOfCharArray);
/*     */   
/*     */   public enum UpdateKind
/*     */   {
/*  34 */     MODULE, PACKAGE; }
/*     */   
/*     */   public static class AddExports implements Consumer<IUpdatableModule> {
/*     */     char[] name;
/*     */     char[][] targets;
/*     */     
/*     */     public AddExports(char[] pkgName, char[][] targets) {
/*  41 */       this.name = pkgName;
/*  42 */       this.targets = targets;
/*     */     }
/*     */     
/*     */     public void accept(IUpdatableModule t) {
/*  46 */       t.addExports(this.name, this.targets);
/*     */     }
/*     */     
/*     */     public char[] getName() {
/*  50 */       return this.name;
/*     */     }
/*     */     
/*     */     public char[][] getTargetModules() {
/*  54 */       return this.targets;
/*     */     }
/*     */     
/*     */     public IUpdatableModule.UpdateKind getKind() {
/*  58 */       return IUpdatableModule.UpdateKind.PACKAGE;
/*     */     }
/*     */     
/*     */     public boolean equals(Object other) {
/*  62 */       if (this == other) return true; 
/*  63 */       if (!(other instanceof AddExports)) return false; 
/*  64 */       AddExports pu = (AddExports)other;
/*     */       
/*  66 */       if (!CharOperation.equals(this.name, pu.name))
/*  67 */         return false; 
/*  68 */       if (!CharOperation.equals(this.targets, pu.targets))
/*  69 */         return false; 
/*  70 */       return true;
/*     */     }
/*     */     
/*     */     public int hashCode() {
/*  74 */       int hash = CharOperation.hashCode(this.name);
/*  75 */       if (this.targets != null) {
/*  76 */         for (int i = 0; i < this.targets.length; i++) {
/*  77 */           hash += 17 * CharOperation.hashCode(this.targets[i]);
/*     */         }
/*     */       }
/*  80 */       return hash;
/*     */     }
/*     */     
/*     */     public String toString() {
/*  84 */       return "add-exports " + CharOperation.charToString(this.name) + "=" + CharOperation.charToString(CharOperation.concatWith(this.targets, ','));
/*     */     }
/*     */   }
/*     */   
/*     */   public static class AddReads
/*     */     implements Consumer<IUpdatableModule>
/*     */   {
/*     */     char[] targetModule;
/*     */     
/*     */     public AddReads(char[] target) {
/*  94 */       this.targetModule = target;
/*     */     }
/*     */ 
/*     */     
/*     */     public void accept(IUpdatableModule t) {
/*  99 */       t.addReads(this.targetModule);
/*     */     }
/*     */     
/*     */     public char[] getTarget() {
/* 103 */       return this.targetModule;
/*     */     }
/*     */     
/*     */     public IUpdatableModule.UpdateKind getKind() {
/* 107 */       return IUpdatableModule.UpdateKind.MODULE;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean equals(Object other) {
/* 112 */       if (this == other) return true; 
/* 113 */       if (!(other instanceof AddReads)) return false; 
/* 114 */       AddReads mu = (AddReads)other;
/* 115 */       return CharOperation.equals(this.targetModule, mu.targetModule);
/*     */     }
/*     */     
/*     */     public int hashCode() {
/* 119 */       return CharOperation.hashCode(this.targetModule);
/*     */     }
/*     */     
/*     */     public String toString() {
/* 123 */       return "add-read " + CharOperation.charToString(this.targetModule);
/*     */     } }
/*     */   public static class UpdatesByKind { List<Consumer<IUpdatableModule>> moduleUpdates;
/*     */     
/*     */     public UpdatesByKind() {
/* 128 */       this.moduleUpdates = Collections.emptyList();
/* 129 */       this.packageUpdates = Collections.emptyList();
/*     */     } List<Consumer<IUpdatableModule>> packageUpdates; public List<Consumer<IUpdatableModule>> getList(IUpdatableModule.UpdateKind kind, boolean create) {
/* 131 */       switch (kind) {
/*     */         case null:
/* 133 */           if (this.moduleUpdates == Collections.EMPTY_LIST && create)
/* 134 */             this.moduleUpdates = new ArrayList<>(); 
/* 135 */           return this.moduleUpdates;
/*     */         case PACKAGE:
/* 137 */           if (this.packageUpdates == Collections.EMPTY_LIST && create)
/* 138 */             this.packageUpdates = new ArrayList<>(); 
/* 139 */           return this.packageUpdates;
/*     */       } 
/* 141 */       throw new IllegalArgumentException("Unknown enum value " + kind);
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/* 146 */       StringBuilder result = new StringBuilder();
/* 147 */       for (Consumer<IUpdatableModule> consumer : this.moduleUpdates) {
/* 148 */         if (result.length() > 0)
/* 149 */           result.append("\n"); 
/* 150 */         result.append(consumer);
/*     */       } 
/* 152 */       for (Consumer<IUpdatableModule> consumer : this.packageUpdates) {
/* 153 */         if (result.length() > 0)
/* 154 */           result.append("\n"); 
/* 155 */         result.append(consumer);
/*     */       } 
/* 157 */       return result.toString();
/*     */     } }
/*     */ 
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\env\IUpdatableModule.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */