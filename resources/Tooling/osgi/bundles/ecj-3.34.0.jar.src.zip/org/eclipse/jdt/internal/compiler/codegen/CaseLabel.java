/*    */ package org.eclipse.jdt.internal.compiler.codegen;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CaseLabel
/*    */   extends BranchLabel
/*    */ {
/* 18 */   public int instructionPosition = -1;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public CaseLabel(CodeStream codeStream) {
/* 25 */     super(codeStream);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   void branch() {
/* 34 */     if (this.position == -1) {
/* 35 */       addForwardReference(this.codeStream.position);
/*    */       
/* 37 */       this.codeStream.position += 4;
/* 38 */       this.codeStream.classFileOffset += 4;
/*    */     
/*    */     }
/*    */     else {
/*    */       
/* 43 */       this.codeStream.writeSignedWord(this.position - this.instructionPosition);
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   void branchWide() {
/* 52 */     branch();
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean isCaseLabel() {
/* 57 */     return true;
/*    */   }
/*    */   
/*    */   public boolean isStandardLabel() {
/* 61 */     return false;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void place() {
/* 68 */     if ((this.tagBits & 0x2) != 0) {
/* 69 */       this.position = this.codeStream.getPosition();
/*    */     } else {
/* 71 */       this.position = this.codeStream.position;
/*    */     } 
/* 73 */     if (this.instructionPosition != -1) {
/* 74 */       int offset = this.position - this.instructionPosition;
/* 75 */       int[] forwardRefs = forwardReferences();
/* 76 */       for (int i = 0, length = forwardReferenceCount(); i < length; i++) {
/* 77 */         this.codeStream.writeSignedWord(forwardRefs[i], offset);
/*    */       }
/*    */       
/* 80 */       this.codeStream.addLabel(this);
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   void placeInstruction() {
/* 88 */     if (this.instructionPosition == -1)
/* 89 */       this.instructionPosition = this.codeStream.position; 
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\codegen\CaseLabel.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */