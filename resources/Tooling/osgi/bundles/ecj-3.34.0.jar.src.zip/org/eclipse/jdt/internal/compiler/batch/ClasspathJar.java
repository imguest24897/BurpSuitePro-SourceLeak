/*     */ package org.eclipse.jdt.internal.compiler.batch;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Enumeration;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import java.util.zip.ZipEntry;
/*     */ import java.util.zip.ZipFile;
/*     */ import org.eclipse.jdt.core.compiler.CharOperation;
/*     */ import org.eclipse.jdt.internal.compiler.classfmt.ClassFileReader;
/*     */ import org.eclipse.jdt.internal.compiler.classfmt.ClassFormatException;
/*     */ import org.eclipse.jdt.internal.compiler.classfmt.ExternalAnnotationDecorator;
/*     */ import org.eclipse.jdt.internal.compiler.env.AccessRuleSet;
/*     */ import org.eclipse.jdt.internal.compiler.env.IBinaryType;
/*     */ import org.eclipse.jdt.internal.compiler.env.IModule;
/*     */ import org.eclipse.jdt.internal.compiler.env.NameEnvironmentAnswer;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.BinaryTypeBinding;
/*     */ import org.eclipse.jdt.internal.compiler.util.ManifestAnalyzer;
/*     */ import org.eclipse.jdt.internal.compiler.util.Util;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ClasspathJar
/*     */   extends ClasspathLocation
/*     */ {
/*     */   protected File file;
/*     */   protected ZipFile zipFile;
/*     */   protected ZipFile annotationZipFile;
/*     */   protected boolean closeZipFileAtEnd;
/*     */   protected Set<String> packageCache;
/*     */   protected List<String> annotationPaths;
/*     */   
/*     */   public ClasspathJar(File file, boolean closeZipFileAtEnd, AccessRuleSet accessRuleSet, String destinationPath) {
/*  59 */     super(accessRuleSet, destinationPath);
/*  60 */     this.file = file;
/*  61 */     this.closeZipFileAtEnd = closeZipFileAtEnd;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<FileSystem.Classpath> fetchLinkedJars(FileSystem.ClasspathSectionProblemReporter problemReporter) {
/*  68 */     InputStream inputStream = null;
/*     */     try {
/*  70 */       initialize();
/*  71 */       ArrayList<FileSystem.Classpath> result = new ArrayList<>();
/*  72 */       ZipEntry manifest = this.zipFile.getEntry("META-INF/MANIFEST.MF");
/*  73 */       if (manifest != null) {
/*  74 */         inputStream = this.zipFile.getInputStream(manifest);
/*  75 */         ManifestAnalyzer analyzer = new ManifestAnalyzer();
/*  76 */         boolean success = analyzer.analyzeManifestContents(inputStream);
/*  77 */         List calledFileNames = analyzer.getCalledFileNames();
/*  78 */         if (problemReporter != null) {
/*  79 */           if (!success || (analyzer.getClasspathSectionsCount() == 1 && calledFileNames == null)) {
/*  80 */             problemReporter.invalidClasspathSection(getPath());
/*  81 */           } else if (analyzer.getClasspathSectionsCount() > 1) {
/*  82 */             problemReporter.multipleClasspathSections(getPath());
/*     */           } 
/*     */         }
/*  85 */         if (calledFileNames != null) {
/*  86 */           Iterator<String> calledFilesIterator = calledFileNames.iterator();
/*  87 */           String directoryPath = getPath();
/*  88 */           int lastSeparator = directoryPath.lastIndexOf(File.separatorChar);
/*  89 */           directoryPath = directoryPath.substring(0, lastSeparator + 1);
/*  90 */           while (calledFilesIterator.hasNext()) {
/*  91 */             File linkedFile = new File(String.valueOf(directoryPath) + (String)calledFilesIterator.next());
/*  92 */             if (linkedFile.isFile()) {
/*  93 */               result.add(new ClasspathJar(linkedFile, this.closeZipFileAtEnd, this.accessRuleSet, this.destinationPath));
/*     */             }
/*     */           } 
/*     */         } 
/*     */       } 
/*  98 */       return result;
/*  99 */     } catch (IOException|IllegalArgumentException iOException) {
/*     */ 
/*     */       
/* 102 */       return null;
/*     */     } finally {
/* 104 */       if (inputStream != null) {
/*     */         try {
/* 106 */           inputStream.close();
/* 107 */         } catch (IOException iOException) {}
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public NameEnvironmentAnswer findClass(char[] typeName, String qualifiedPackageName, String moduleName, String qualifiedBinaryFileName) {
/* 115 */     return findClass(typeName, qualifiedPackageName, moduleName, qualifiedBinaryFileName, false);
/*     */   }
/*     */   
/*     */   public NameEnvironmentAnswer findClass(char[] typeName, String qualifiedPackageName, String moduleName, String qualifiedBinaryFileName, boolean asBinaryOnly) {
/* 119 */     if (!isPackage(qualifiedPackageName, moduleName)) {
/* 120 */       return null;
/*     */     }
/*     */     try {
/* 123 */       ClassFileReader classFileReader = ClassFileReader.read(this.zipFile, qualifiedBinaryFileName);
/* 124 */       if (classFileReader != null) {
/* 125 */         IBinaryType iBinaryType; char[] modName = (this.module == null) ? null : this.module.name();
/* 126 */         if (classFileReader instanceof ClassFileReader) {
/* 127 */           ClassFileReader classReader = classFileReader;
/* 128 */           if (classReader.moduleName == null) {
/* 129 */             classReader.moduleName = modName;
/*     */           } else {
/* 131 */             modName = classReader.moduleName;
/*     */           } 
/*     */         } 
/* 134 */         if (this.annotationPaths != null)
/* 135 */         { String qualifiedClassName = qualifiedBinaryFileName.substring(0, qualifiedBinaryFileName.length() - "CLASS".length() - 1);
/* 136 */           Iterator<String> iterator = this.annotationPaths.iterator(); while (true) { ExternalAnnotationDecorator externalAnnotationDecorator; if (!iterator.hasNext())
/*     */             
/*     */             { 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */               
/* 151 */               externalAnnotationDecorator = new ExternalAnnotationDecorator((IBinaryType)classFileReader, null); break; }  String annotationPath = iterator.next(); try { if (this.annotationZipFile == null)
/*     */                 this.annotationZipFile = ExternalAnnotationDecorator.getAnnotationZipFile(annotationPath, null);  iBinaryType = ExternalAnnotationDecorator.create((IBinaryType)externalAnnotationDecorator, annotationPath, qualifiedClassName, this.annotationZipFile); if (iBinaryType.getExternalAnnotationStatus() == BinaryTypeBinding.ExternalAnnotationStatus.TYPE_IS_ANNOTATED)
/* 153 */                 break;  } catch (IOException iOException) {} }  }  return new NameEnvironmentAnswer(iBinaryType, fetchAccessRestriction(qualifiedBinaryFileName), modName);
/*     */       } 
/* 155 */     } catch (ClassFormatException|IOException classFormatException) {}
/*     */ 
/*     */     
/* 158 */     return null;
/*     */   }
/*     */   
/*     */   public boolean hasAnnotationFileFor(String qualifiedTypeName) {
/* 162 */     if (this.zipFile == null)
/* 163 */       return false; 
/* 164 */     return (this.zipFile.getEntry(String.valueOf(qualifiedTypeName) + ".eea") != null);
/*     */   }
/*     */   
/*     */   public char[][][] findTypeNames(String qualifiedPackageName, String moduleName) {
/* 168 */     if (!isPackage(qualifiedPackageName, moduleName))
/* 169 */       return null; 
/* 170 */     char[] packageArray = qualifiedPackageName.toCharArray();
/* 171 */     ArrayList<char[][]> answers = new ArrayList();
/* 172 */     for (Enumeration<? extends ZipEntry> e = this.zipFile.entries(); e.hasMoreElements(); ) {
/* 173 */       String fileName = ((ZipEntry)e.nextElement()).getName();
/*     */ 
/*     */       
/* 176 */       int last = fileName.lastIndexOf('/');
/* 177 */       if (last > 0) {
/*     */         
/* 179 */         String packageName = fileName.substring(0, last);
/* 180 */         if (!qualifiedPackageName.equals(packageName))
/*     */           continue; 
/* 182 */         int indexOfDot = fileName.lastIndexOf('.');
/* 183 */         if (indexOfDot != -1) {
/* 184 */           String typeName = fileName.substring(last + 1, indexOfDot);
/* 185 */           answers.add(
/* 186 */               CharOperation.arrayConcat(
/* 187 */                 CharOperation.splitOn('/', packageArray), 
/* 188 */                 typeName.toCharArray()));
/*     */         } 
/*     */       } 
/*     */     } 
/* 192 */     int size = answers.size();
/* 193 */     if (size != 0) {
/* 194 */       char[][][] result = new char[size][][];
/* 195 */       answers.toArray(result);
/* 196 */       return result;
/*     */     } 
/* 198 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public void initialize() throws IOException {
/* 203 */     if (this.zipFile == null)
/* 204 */       this.zipFile = new ZipFile(this.file); 
/*     */   }
/*     */   
/*     */   void acceptModule(ClassFileReader reader) {
/* 208 */     if (reader != null)
/* 209 */       acceptModule((IModule)reader.getModuleDeclaration()); 
/*     */   }
/*     */   
/*     */   void acceptModule(byte[] content) {
/* 213 */     if (content == null)
/*     */       return; 
/* 215 */     ClassFileReader reader = null;
/*     */     try {
/* 217 */       reader = new ClassFileReader(content, "module-info.class".toCharArray());
/* 218 */     } catch (ClassFormatException e) {
/* 219 */       e.printStackTrace();
/*     */     } 
/* 221 */     if (reader != null && reader.getModuleDeclaration() != null)
/* 222 */       acceptModule(reader); 
/*     */   }
/*     */   
/*     */   protected void addToPackageCache(String fileName, boolean endsWithSep) {
/* 226 */     int last = endsWithSep ? fileName.length() : fileName.lastIndexOf('/');
/* 227 */     while (last > 0) {
/*     */       
/* 229 */       String packageName = fileName.substring(0, last);
/* 230 */       if (this.packageCache.contains(packageName))
/*     */         return; 
/* 232 */       this.packageCache.add(packageName);
/* 233 */       last = packageName.lastIndexOf('/');
/*     */     } 
/*     */   }
/*     */   
/*     */   public synchronized char[][] getModulesDeclaringPackage(String qualifiedPackageName, String moduleName) {
/* 238 */     if (this.packageCache != null) {
/* 239 */       return singletonModuleNameIf(this.packageCache.contains(qualifiedPackageName));
/*     */     }
/* 241 */     this.packageCache = new HashSet<>(41);
/* 242 */     this.packageCache.add(Util.EMPTY_STRING);
/*     */     
/* 244 */     for (Enumeration<? extends ZipEntry> e = this.zipFile.entries(); e.hasMoreElements(); ) {
/* 245 */       String fileName = ((ZipEntry)e.nextElement()).getName();
/* 246 */       addToPackageCache(fileName, false);
/*     */     } 
/* 248 */     return singletonModuleNameIf(this.packageCache.contains(qualifiedPackageName));
/*     */   }
/*     */   
/*     */   public boolean hasCompilationUnit(String qualifiedPackageName, String moduleName) {
/* 252 */     qualifiedPackageName = String.valueOf(qualifiedPackageName) + '/';
/* 253 */     for (Enumeration<? extends ZipEntry> e = this.zipFile.entries(); e.hasMoreElements(); ) {
/* 254 */       String fileName = ((ZipEntry)e.nextElement()).getName();
/* 255 */       if (fileName.startsWith(qualifiedPackageName) && fileName.length() > qualifiedPackageName.length()) {
/* 256 */         String tail = fileName.substring(qualifiedPackageName.length());
/* 257 */         if (tail.indexOf('/') != -1)
/*     */           continue; 
/* 259 */         if (tail.toLowerCase().endsWith(".class"))
/* 260 */           return true; 
/*     */       } 
/*     */     } 
/* 263 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public char[][] listPackages() {
/* 268 */     Set<String> packageNames = new HashSet<>();
/* 269 */     for (Enumeration<? extends ZipEntry> e = this.zipFile.entries(); e.hasMoreElements(); ) {
/* 270 */       String fileName = ((ZipEntry)e.nextElement()).getName();
/* 271 */       int lastSlash = fileName.lastIndexOf('/');
/* 272 */       if (lastSlash != -1 && fileName.toLowerCase().endsWith(".class"))
/* 273 */         packageNames.add(fileName.substring(0, lastSlash).replace('/', '.')); 
/*     */     } 
/* 275 */     return (char[][])packageNames.stream().map(String::toCharArray).toArray(paramInt -> new char[paramInt][]);
/*     */   }
/*     */ 
/*     */   
/*     */   public void reset() {
/* 280 */     super.reset();
/* 281 */     if (this.closeZipFileAtEnd) {
/* 282 */       if (this.zipFile != null) {
/*     */         try {
/* 284 */           this.zipFile.close();
/* 285 */         } catch (IOException iOException) {}
/*     */ 
/*     */         
/* 288 */         this.zipFile = null;
/*     */       } 
/* 290 */       if (this.annotationZipFile != null) {
/*     */         try {
/* 292 */           this.annotationZipFile.close();
/* 293 */         } catch (IOException iOException) {}
/*     */ 
/*     */         
/* 296 */         this.annotationZipFile = null;
/*     */       } 
/*     */     } 
/* 299 */     this.packageCache = null;
/* 300 */     this.annotationPaths = null;
/*     */   }
/*     */   
/*     */   public String toString() {
/* 304 */     return "Classpath for jar file " + this.file.getPath();
/*     */   }
/*     */   
/*     */   public char[] normalizedPath() {
/* 308 */     if (this.normalizedPath == null) {
/* 309 */       String path2 = getPath();
/* 310 */       char[] rawName = path2.toCharArray();
/* 311 */       if (File.separatorChar == '\\') {
/* 312 */         CharOperation.replace(rawName, '\\', '/');
/*     */       }
/* 314 */       this.normalizedPath = CharOperation.subarray(rawName, 0, CharOperation.lastIndexOf('.', rawName));
/*     */     } 
/* 316 */     return this.normalizedPath;
/*     */   }
/*     */   
/*     */   public String getPath() {
/* 320 */     if (this.path == null) {
/*     */       try {
/* 322 */         this.path = this.file.getCanonicalPath();
/* 323 */       } catch (IOException iOException) {
/*     */         
/* 325 */         this.path = this.file.getAbsolutePath();
/*     */       } 
/*     */     }
/* 328 */     return this.path;
/*     */   }
/*     */   
/*     */   public int getMode() {
/* 332 */     return 2;
/*     */   }
/*     */ 
/*     */   
/*     */   public IModule getModule() {
/* 337 */     return this.module;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\batch\ClasspathJar.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */