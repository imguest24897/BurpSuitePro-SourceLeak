package org.eclipse.jdt.internal.compiler.env;

public interface IBinaryMethod extends IGenericMethod {
  IBinaryAnnotation[] getAnnotations();
  
  Object getDefaultValue();
  
  char[][] getExceptionTypeNames();
  
  char[] getGenericSignature();
  
  char[] getMethodDescriptor();
  
  IBinaryAnnotation[] getParameterAnnotations(int paramInt, char[] paramArrayOfchar);
  
  int getAnnotatedParametersCount();
  
  char[] getSelector();
  
  long getTagBits();
  
  boolean isClinit();
  
  IBinaryTypeAnnotation[] getTypeAnnotations();
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\env\IBinaryMethod.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */