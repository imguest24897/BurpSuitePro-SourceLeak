/*    */ package org.eclipse.jdt.internal.compiler.batch;
/*    */ 
/*    */ import java.io.File;
/*    */ import java.io.IOException;
/*    */ import java.io.InputStream;
/*    */ import java.util.zip.ZipEntry;
/*    */ import org.eclipse.jdt.internal.compiler.env.AccessRuleSet;
/*    */ import org.eclipse.jdt.internal.compiler.env.NameEnvironmentAnswer;
/*    */ import org.eclipse.jdt.internal.compiler.util.Util;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ClasspathSourceJar
/*    */   extends ClasspathJar
/*    */ {
/*    */   private String encoding;
/*    */   
/*    */   public ClasspathSourceJar(File file, boolean closeZipFileAtEnd, AccessRuleSet accessRuleSet, String encoding, String destinationPath) {
/* 31 */     super(file, closeZipFileAtEnd, accessRuleSet, destinationPath);
/* 32 */     this.encoding = encoding;
/*    */   }
/*    */ 
/*    */   
/*    */   public NameEnvironmentAnswer findClass(char[] typeName, String qualifiedPackageName, String moduleName, String qualifiedBinaryFileName, boolean asBinaryOnly) {
/* 37 */     if (!isPackage(qualifiedPackageName, moduleName)) {
/* 38 */       return null;
/*    */     }
/* 40 */     ZipEntry sourceEntry = this.zipFile.getEntry(String.valueOf(qualifiedBinaryFileName.substring(0, qualifiedBinaryFileName.length() - 6)) + ".java");
/* 41 */     if (sourceEntry != null) {
/*    */       try {
/* 43 */         InputStream stream = null;
/* 44 */         char[] contents = null;
/*    */         try {
/* 46 */           stream = this.zipFile.getInputStream(sourceEntry);
/* 47 */           contents = Util.getInputStreamAsCharArray(stream, this.encoding);
/*    */         } finally {
/* 49 */           if (stream != null)
/* 50 */             stream.close(); 
/*    */         } 
/* 52 */         CompilationUnit compilationUnit = new CompilationUnit(
/* 53 */             contents, 
/* 54 */             String.valueOf(qualifiedBinaryFileName.substring(0, qualifiedBinaryFileName.length() - 6)) + ".java", 
/* 55 */             this.encoding, 
/* 56 */             this.destinationPath);
/* 57 */         compilationUnit.module = (this.module == null) ? null : this.module.name();
/* 58 */         return new NameEnvironmentAnswer(
/* 59 */             compilationUnit, 
/* 60 */             fetchAccessRestriction(qualifiedBinaryFileName));
/* 61 */       } catch (IOException iOException) {}
/*    */     }
/*    */ 
/*    */     
/* 65 */     return null;
/*    */   }
/*    */ 
/*    */   
/*    */   public int getMode() {
/* 70 */     return 1;
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\batch\ClasspathSourceJar.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */