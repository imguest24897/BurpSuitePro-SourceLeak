/*     */ package org.eclipse.jdt.internal.compiler.classfmt;
/*     */ 
/*     */ import java.net.URI;
/*     */ import java.util.Arrays;
/*     */ import org.eclipse.jdt.core.compiler.CharOperation;
/*     */ import org.eclipse.jdt.internal.compiler.env.IBinaryAnnotation;
/*     */ import org.eclipse.jdt.internal.compiler.env.IBinaryModule;
/*     */ import org.eclipse.jdt.internal.compiler.env.IModule;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ModuleInfo
/*     */   extends ClassFileStruct
/*     */   implements IBinaryModule
/*     */ {
/*     */   protected int flags;
/*     */   protected int requiresCount;
/*     */   protected int exportsCount;
/*     */   protected int usesCount;
/*     */   protected int providesCount;
/*     */   protected int opensCount;
/*     */   protected char[] name;
/*     */   protected char[] version;
/*     */   protected ModuleReferenceInfo[] requires;
/*     */   protected PackageExportInfo[] exports;
/*     */   protected PackageExportInfo[] opens;
/*     */   char[][] uses;
/*     */   IModule.IService[] provides;
/*     */   protected AnnotationInfo[] annotations;
/*     */   private long tagBits;
/*     */   public URI path;
/*     */   
/*     */   public boolean isOpen() {
/*  46 */     return ((this.flags & 0x20) != 0);
/*     */   }
/*     */   public int requiresCount() {
/*  49 */     return this.requiresCount;
/*     */   }
/*     */   public int exportsCount() {
/*  52 */     return this.exportsCount;
/*     */   }
/*     */   public int usesCount() {
/*  55 */     return this.usesCount;
/*     */   }
/*     */   public int providesCount() {
/*  58 */     return this.providesCount;
/*     */   }
/*     */   
/*     */   public char[] name() {
/*  62 */     return this.name;
/*     */   }
/*     */   public void setName(char[] name) {
/*  65 */     this.name = name;
/*     */   }
/*     */   
/*     */   public IModule.IModuleReference[] requires() {
/*  69 */     return (IModule.IModuleReference[])this.requires;
/*     */   }
/*     */   
/*     */   public IModule.IPackageExport[] exports() {
/*  73 */     return (IModule.IPackageExport[])this.exports;
/*     */   }
/*     */   
/*     */   public char[][] uses() {
/*  77 */     return this.uses;
/*     */   }
/*     */   
/*     */   public IModule.IService[] provides() {
/*  81 */     return this.provides;
/*     */   }
/*     */   
/*     */   public IModule.IPackageExport[] opens() {
/*  85 */     return (IModule.IPackageExport[])this.opens;
/*     */   }
/*     */   
/*     */   public IBinaryAnnotation[] getAnnotations() {
/*  89 */     return (IBinaryAnnotation[])this.annotations;
/*     */   }
/*     */   
/*     */   public long getTagBits() {
/*  93 */     return this.tagBits;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected ModuleInfo(byte[] classFileBytes, int[] offsets, int offset) {
/* 102 */     super(classFileBytes, offsets, offset);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ModuleInfo createModule(byte[] classFileBytes, int[] offsets, int offset) {
/* 113 */     ModuleInfo module = new ModuleInfo(classFileBytes, offsets, 0);
/*     */     
/* 115 */     module.readModuleAttribute(offset + 6);
/*     */     
/* 117 */     return module;
/*     */   }
/*     */ 
/*     */   
/*     */   private void readModuleAttribute(int moduleOffset) {
/* 122 */     int name_index = this.constantPoolOffsets[u2At(moduleOffset)];
/* 123 */     int utf8Offset = this.constantPoolOffsets[u2At(name_index + 1)];
/* 124 */     this.name = utf8At(utf8Offset + 3, u2At(utf8Offset + 1));
/* 125 */     CharOperation.replace(this.name, '/', '.');
/* 126 */     moduleOffset += 2;
/* 127 */     this.flags = u2At(moduleOffset);
/* 128 */     moduleOffset += 2;
/* 129 */     int version_index = u2At(moduleOffset);
/* 130 */     if (version_index > 0) {
/* 131 */       utf8Offset = this.constantPoolOffsets[version_index];
/* 132 */       this.version = utf8At(utf8Offset + 3, u2At(utf8Offset + 1));
/*     */     } 
/* 134 */     moduleOffset += 2;
/*     */     
/* 136 */     int count = u2At(moduleOffset);
/* 137 */     this.requiresCount = count;
/* 138 */     this.requires = new ModuleReferenceInfo[count];
/* 139 */     moduleOffset += 2; int i;
/* 140 */     for (i = 0; i < count; i++) {
/* 141 */       name_index = this.constantPoolOffsets[u2At(moduleOffset)];
/* 142 */       utf8Offset = this.constantPoolOffsets[u2At(name_index + 1)];
/* 143 */       char[] requiresNames = utf8At(utf8Offset + 3, u2At(utf8Offset + 1));
/* 144 */       getClass(); this.requires[i] = new ModuleReferenceInfo();
/* 145 */       CharOperation.replace(requiresNames, '/', '.');
/* 146 */       (this.requires[i]).refName = requiresNames;
/* 147 */       moduleOffset += 2;
/* 148 */       int modifiers = u2At(moduleOffset);
/* 149 */       (this.requires[i]).modifiers = modifiers;
/* 150 */       (this.requires[i]).isTransitive = ((0x20 & modifiers) != 0);
/* 151 */       moduleOffset += 2;
/* 152 */       version_index = u2At(moduleOffset);
/* 153 */       if (version_index > 0) {
/* 154 */         utf8Offset = this.constantPoolOffsets[version_index];
/* 155 */         (this.requires[i]).required_version = utf8At(utf8Offset + 3, u2At(utf8Offset + 1));
/*     */       } 
/* 157 */       moduleOffset += 2;
/*     */     } 
/* 159 */     count = u2At(moduleOffset);
/* 160 */     moduleOffset += 2;
/* 161 */     this.exportsCount = count;
/* 162 */     this.exports = new PackageExportInfo[count];
/* 163 */     for (i = 0; i < count; i++) {
/* 164 */       name_index = this.constantPoolOffsets[u2At(moduleOffset)];
/* 165 */       utf8Offset = this.constantPoolOffsets[u2At(name_index + 1)];
/* 166 */       char[] exported = utf8At(utf8Offset + 3, u2At(utf8Offset + 1));
/* 167 */       CharOperation.replace(exported, '/', '.');
/* 168 */       getClass(); PackageExportInfo pack = new PackageExportInfo();
/* 169 */       this.exports[i] = pack;
/* 170 */       pack.packageName = exported;
/* 171 */       moduleOffset += 2;
/* 172 */       pack.modifiers = u2At(moduleOffset);
/* 173 */       moduleOffset += 2;
/* 174 */       int exportedtoCount = u2At(moduleOffset);
/* 175 */       moduleOffset += 2;
/* 176 */       if (exportedtoCount > 0) {
/* 177 */         pack.exportedTo = new char[exportedtoCount][];
/* 178 */         pack.exportedToCount = exportedtoCount;
/* 179 */         for (int k = 0; k < exportedtoCount; k++) {
/* 180 */           name_index = this.constantPoolOffsets[u2At(moduleOffset)];
/* 181 */           utf8Offset = this.constantPoolOffsets[u2At(name_index + 1)];
/* 182 */           char[] exportedToName = utf8At(utf8Offset + 3, u2At(utf8Offset + 1));
/* 183 */           CharOperation.replace(exportedToName, '/', '.');
/* 184 */           pack.exportedTo[k] = exportedToName;
/* 185 */           moduleOffset += 2;
/*     */         } 
/*     */       } 
/*     */     } 
/* 189 */     count = u2At(moduleOffset);
/* 190 */     moduleOffset += 2;
/* 191 */     this.opensCount = count;
/* 192 */     this.opens = new PackageExportInfo[count];
/* 193 */     for (i = 0; i < count; i++) {
/* 194 */       name_index = this.constantPoolOffsets[u2At(moduleOffset)];
/* 195 */       utf8Offset = this.constantPoolOffsets[u2At(name_index + 1)];
/* 196 */       char[] exported = utf8At(utf8Offset + 3, u2At(utf8Offset + 1));
/* 197 */       CharOperation.replace(exported, '/', '.');
/* 198 */       getClass(); PackageExportInfo pack = new PackageExportInfo();
/* 199 */       this.opens[i] = pack;
/* 200 */       pack.packageName = exported;
/* 201 */       moduleOffset += 2;
/* 202 */       pack.modifiers = u2At(moduleOffset);
/* 203 */       moduleOffset += 2;
/* 204 */       int exportedtoCount = u2At(moduleOffset);
/* 205 */       moduleOffset += 2;
/* 206 */       if (exportedtoCount > 0) {
/* 207 */         pack.exportedTo = new char[exportedtoCount][];
/* 208 */         pack.exportedToCount = exportedtoCount;
/* 209 */         for (int k = 0; k < exportedtoCount; k++) {
/* 210 */           name_index = this.constantPoolOffsets[u2At(moduleOffset)];
/* 211 */           utf8Offset = this.constantPoolOffsets[u2At(name_index + 1)];
/* 212 */           char[] exportedToName = utf8At(utf8Offset + 3, u2At(utf8Offset + 1));
/* 213 */           CharOperation.replace(exportedToName, '/', '.');
/* 214 */           pack.exportedTo[k] = exportedToName;
/* 215 */           moduleOffset += 2;
/*     */         } 
/*     */       } 
/*     */     } 
/* 219 */     count = u2At(moduleOffset);
/* 220 */     moduleOffset += 2;
/* 221 */     this.usesCount = count;
/* 222 */     this.uses = new char[count][];
/* 223 */     for (i = 0; i < count; i++) {
/* 224 */       int classIndex = this.constantPoolOffsets[u2At(moduleOffset)];
/* 225 */       utf8Offset = this.constantPoolOffsets[u2At(classIndex + 1)];
/* 226 */       char[] inf = utf8At(utf8Offset + 3, u2At(utf8Offset + 1));
/* 227 */       CharOperation.replace(inf, '/', '.');
/* 228 */       this.uses[i] = inf;
/* 229 */       moduleOffset += 2;
/*     */     } 
/* 231 */     count = u2At(moduleOffset);
/* 232 */     moduleOffset += 2;
/* 233 */     this.providesCount = count;
/* 234 */     this.provides = (IModule.IService[])new ServiceInfo[count];
/* 235 */     for (i = 0; i < count; i++) {
/* 236 */       int classIndex = this.constantPoolOffsets[u2At(moduleOffset)];
/* 237 */       utf8Offset = this.constantPoolOffsets[u2At(classIndex + 1)];
/* 238 */       char[] inf = utf8At(utf8Offset + 3, u2At(utf8Offset + 1));
/* 239 */       CharOperation.replace(inf, '/', '.');
/* 240 */       getClass(); ServiceInfo service = new ServiceInfo();
/* 241 */       this.provides[i] = service;
/* 242 */       service.serviceName = inf;
/* 243 */       moduleOffset += 2;
/* 244 */       int implCount = u2At(moduleOffset);
/* 245 */       moduleOffset += 2;
/* 246 */       service.with = new char[implCount][];
/* 247 */       if (implCount > 0) {
/* 248 */         service.with = new char[implCount][];
/* 249 */         for (int k = 0; k < implCount; k++) {
/* 250 */           classIndex = this.constantPoolOffsets[u2At(moduleOffset)];
/* 251 */           utf8Offset = this.constantPoolOffsets[u2At(classIndex + 1)];
/* 252 */           char[] implName = utf8At(utf8Offset + 3, u2At(utf8Offset + 1));
/* 253 */           CharOperation.replace(implName, '/', '.');
/* 254 */           service.with[k] = implName;
/* 255 */           moduleOffset += 2;
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */   void setAnnotations(AnnotationInfo[] annotationInfos, long tagBits, boolean fullyInitialize) {
/* 261 */     this.annotations = annotationInfos;
/* 262 */     this.tagBits = tagBits;
/* 263 */     if (fullyInitialize)
/* 264 */       for (int i = 0, max = annotationInfos.length; i < max; i++)
/* 265 */         annotationInfos[i].initialize();  
/*     */   }
/*     */   
/*     */   class ModuleReferenceInfo
/*     */     implements IModule.IModuleReference
/*     */   {
/*     */     char[] refName;
/*     */     boolean isTransitive = false;
/*     */     int modifiers;
/*     */     char[] required_version;
/*     */     
/*     */     public char[] name() {
/* 277 */       return this.refName;
/*     */     }
/*     */     
/*     */     public boolean isTransitive() {
/* 281 */       return this.isTransitive;
/*     */     }
/*     */     
/*     */     public boolean equals(Object o) {
/* 285 */       if (this == o)
/* 286 */         return true; 
/* 287 */       if (!(o instanceof IModule.IModuleReference))
/* 288 */         return false; 
/* 289 */       IModule.IModuleReference mod = (IModule.IModuleReference)o;
/* 290 */       if (this.modifiers != mod.getModifiers())
/* 291 */         return false; 
/* 292 */       return CharOperation.equals(this.refName, mod.name(), false);
/*     */     }
/*     */     
/*     */     public int hashCode() {
/* 296 */       return CharOperation.hashCode(this.refName);
/*     */     }
/*     */     
/*     */     public int getModifiers() {
/* 300 */       return this.modifiers;
/*     */     }
/*     */   }
/*     */   
/*     */   class PackageExportInfo implements IModule.IPackageExport { char[] packageName;
/*     */     char[][] exportedTo;
/*     */     int exportedToCount;
/*     */     int modifiers;
/*     */     
/*     */     public char[] name() {
/* 310 */       return this.packageName;
/*     */     }
/*     */ 
/*     */     
/*     */     public char[][] targets() {
/* 315 */       return this.exportedTo;
/*     */     }
/*     */     
/*     */     public String toString() {
/* 319 */       StringBuffer buffer = new StringBuffer();
/* 320 */       toStringContent(buffer);
/* 321 */       return buffer.toString();
/*     */     }
/*     */     protected void toStringContent(StringBuffer buffer) {
/* 324 */       buffer.append(this.packageName);
/* 325 */       if (this.exportedToCount > 0) {
/* 326 */         buffer.append(" to ");
/* 327 */         for (int i = 0; i < this.exportedToCount; i++) {
/* 328 */           buffer.append(this.exportedTo[i]);
/* 329 */           buffer.append(',').append(' ');
/*     */         } 
/*     */       } 
/* 332 */       buffer.append(';').append('\n');
/*     */     } }
/*     */   
/*     */   class ServiceInfo implements IModule.IService {
/*     */     char[] serviceName;
/*     */     char[][] with;
/*     */     
/*     */     public char[] name() {
/* 340 */       return this.serviceName;
/*     */     }
/*     */ 
/*     */     
/*     */     public char[][] with() {
/* 345 */       return this.with;
/*     */     }
/*     */   }
/*     */   
/*     */   public boolean equals(Object o) {
/* 350 */     if (this == o)
/* 351 */       return true; 
/* 352 */     if (!(o instanceof IModule))
/* 353 */       return false; 
/* 354 */     IModule mod = (IModule)o;
/* 355 */     if (!CharOperation.equals(this.name, mod.name()))
/* 356 */       return false; 
/* 357 */     return Arrays.equals((Object[])this.requires, (Object[])mod.requires());
/*     */   }
/*     */   
/*     */   public int hashCode() {
/* 361 */     int result = 17;
/* 362 */     int c = CharOperation.hashCode(this.name);
/* 363 */     result = 31 * result + c;
/* 364 */     c = Arrays.hashCode((Object[])this.requires);
/* 365 */     result = 31 * result + c;
/* 366 */     return result;
/*     */   }
/*     */   
/*     */   public String toString() {
/* 370 */     StringBuffer buffer = new StringBuffer(getClass().getName());
/* 371 */     toStringContent(buffer);
/* 372 */     return buffer.toString();
/*     */   }
/*     */   protected void toStringContent(StringBuffer buffer) {
/* 375 */     buffer.append("\nmodule ");
/* 376 */     buffer.append(this.name).append(' ');
/* 377 */     buffer.append('{').append('\n');
/* 378 */     if (this.requiresCount > 0) {
/* 379 */       for (int i = 0; i < this.requiresCount; i++) {
/* 380 */         buffer.append("\trequires ");
/* 381 */         if ((this.requires[i]).isTransitive) {
/* 382 */           buffer.append(" public ");
/*     */         }
/* 384 */         buffer.append((this.requires[i]).refName);
/* 385 */         buffer.append(';').append('\n');
/*     */       } 
/*     */     }
/* 388 */     if (this.exportsCount > 0) {
/* 389 */       buffer.append('\n');
/* 390 */       for (int i = 0; i < this.exportsCount; i++) {
/* 391 */         buffer.append("\texports ");
/* 392 */         buffer.append(this.exports[i].toString());
/*     */       } 
/*     */     } 
/* 395 */     buffer.append('\n').append('}').toString();
/*     */   }
/*     */   
/*     */   public URI getURI() {
/* 399 */     return this.path;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\classfmt\ModuleInfo.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */