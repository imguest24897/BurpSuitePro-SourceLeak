/*     */ package org.eclipse.jdt.internal.compiler.ast;
/*     */ 
/*     */ import java.util.function.Consumer;
/*     */ import org.eclipse.jdt.core.compiler.CharOperation;
/*     */ import org.eclipse.jdt.internal.compiler.ASTVisitor;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.AnnotationBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.ArrayBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.BlockScope;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.ClassScope;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.LookupEnvironment;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.Scope;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.TypeBinding;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ArrayTypeReference
/*     */   extends SingleTypeReference
/*     */ {
/*     */   public int dimensions;
/*     */   private Annotation[][] annotationsOnDimensions;
/*     */   public int originalSourceEnd;
/*     */   public int extendedDimensions;
/*     */   public TypeBinding leafComponentTypeWithoutDefaultNullness;
/*     */   
/*     */   public ArrayTypeReference(char[] source, int dimensions, long pos) {
/*  49 */     super(source, pos);
/*  50 */     this.originalSourceEnd = this.sourceEnd;
/*  51 */     this.dimensions = dimensions;
/*  52 */     this.annotationsOnDimensions = null;
/*     */   }
/*     */   
/*     */   public ArrayTypeReference(char[] source, int dimensions, Annotation[][] annotationsOnDimensions, long pos) {
/*  56 */     this(source, dimensions, pos);
/*  57 */     if (annotationsOnDimensions != null) {
/*  58 */       this.bits |= 0x100000;
/*     */     }
/*  60 */     this.annotationsOnDimensions = annotationsOnDimensions;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int dimensions() {
/*  66 */     return this.dimensions;
/*     */   }
/*     */ 
/*     */   
/*     */   public int extraDimensions() {
/*  71 */     return this.extendedDimensions;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Annotation[][] getAnnotationsOnDimensions(boolean useSourceOrder) {
/*  79 */     if (useSourceOrder || this.annotationsOnDimensions == null || this.annotationsOnDimensions.length == 0 || this.extendedDimensions == 0 || this.extendedDimensions == this.dimensions)
/*  80 */       return this.annotationsOnDimensions; 
/*  81 */     Annotation[][] externalAnnotations = new Annotation[this.dimensions][];
/*  82 */     int baseDimensions = this.dimensions - this.extendedDimensions;
/*  83 */     System.arraycopy(this.annotationsOnDimensions, baseDimensions, externalAnnotations, 0, this.extendedDimensions);
/*  84 */     System.arraycopy(this.annotationsOnDimensions, 0, externalAnnotations, this.extendedDimensions, baseDimensions);
/*  85 */     return externalAnnotations;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setAnnotationsOnDimensions(Annotation[][] annotationsOnDimensions) {
/*  90 */     this.annotationsOnDimensions = annotationsOnDimensions;
/*     */   }
/*     */ 
/*     */   
/*     */   public Annotation[] getTopAnnotations() {
/*  95 */     if (this.annotationsOnDimensions != null)
/*  96 */       return this.annotationsOnDimensions[0]; 
/*  97 */     return new Annotation[0];
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public char[][] getParameterizedTypeName() {
/* 105 */     int dim = this.dimensions;
/* 106 */     char[] dimChars = new char[dim * 2];
/* 107 */     for (int i = 0; i < dim; i++) {
/* 108 */       int index = i * 2;
/* 109 */       dimChars[index] = '[';
/* 110 */       dimChars[index + 1] = ']';
/*     */     } 
/* 112 */     return new char[][] { CharOperation.concat(this.token, dimChars) };
/*     */   }
/*     */ 
/*     */   
/*     */   protected TypeBinding getTypeBinding(Scope scope) {
/* 117 */     if (this.resolvedType != null) {
/* 118 */       return this.resolvedType;
/*     */     }
/* 120 */     if (this.dimensions > 255) {
/* 121 */       scope.problemReporter().tooManyDimensions(this);
/*     */     }
/* 123 */     TypeBinding leafComponentType = scope.getType(this.token);
/* 124 */     return (TypeBinding)scope.createArrayType(leafComponentType, this.dimensions);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public StringBuffer printExpression(int indent, StringBuffer output) {
/* 131 */     super.printExpression(indent, output);
/* 132 */     if ((this.bits & 0x4000) != 0) {
/* 133 */       for (int i = 0; i < this.dimensions - 1; i++) {
/* 134 */         if (this.annotationsOnDimensions != null && this.annotationsOnDimensions[i] != null) {
/* 135 */           output.append(' ');
/* 136 */           printAnnotations(this.annotationsOnDimensions[i], output);
/* 137 */           output.append(' ');
/*     */         } 
/* 139 */         output.append("[]");
/*     */       } 
/* 141 */       if (this.annotationsOnDimensions != null && this.annotationsOnDimensions[this.dimensions - 1] != null) {
/* 142 */         output.append(' ');
/* 143 */         printAnnotations(this.annotationsOnDimensions[this.dimensions - 1], output);
/* 144 */         output.append(' ');
/*     */       } 
/* 146 */       output.append("...");
/*     */     } else {
/* 148 */       for (int i = 0; i < this.dimensions; i++) {
/* 149 */         if (this.annotationsOnDimensions != null && this.annotationsOnDimensions[i] != null) {
/* 150 */           output.append(" ");
/* 151 */           printAnnotations(this.annotationsOnDimensions[i], output);
/* 152 */           output.append(" ");
/*     */         } 
/* 154 */         output.append("[]");
/*     */       } 
/*     */     } 
/* 157 */     return output;
/*     */   }
/*     */ 
/*     */   
/*     */   public void traverse(ASTVisitor visitor, BlockScope scope) {
/* 162 */     if (visitor.visit(this, scope)) {
/* 163 */       if (this.annotations != null) {
/* 164 */         Annotation[] typeAnnotations = this.annotations[0];
/* 165 */         for (int i = 0, length = (typeAnnotations == null) ? 0 : typeAnnotations.length; i < length; i++) {
/* 166 */           typeAnnotations[i].traverse(visitor, scope);
/*     */         }
/*     */       } 
/* 169 */       if (this.annotationsOnDimensions != null) {
/* 170 */         for (int i = 0, max = this.annotationsOnDimensions.length; i < max; i++) {
/* 171 */           Annotation[] annotations2 = this.annotationsOnDimensions[i];
/* 172 */           if (annotations2 != null) {
/* 173 */             for (int j = 0, max2 = annotations2.length; j < max2; j++) {
/* 174 */               Annotation annotation = annotations2[j];
/* 175 */               annotation.traverse(visitor, scope);
/*     */             } 
/*     */           }
/*     */         } 
/*     */       }
/*     */     } 
/* 181 */     visitor.endVisit(this, scope);
/*     */   }
/*     */ 
/*     */   
/*     */   public void traverse(ASTVisitor visitor, ClassScope scope) {
/* 186 */     if (visitor.visit(this, scope)) {
/* 187 */       if (this.annotations != null) {
/* 188 */         Annotation[] typeAnnotations = this.annotations[0];
/* 189 */         for (int i = 0, length = (typeAnnotations == null) ? 0 : typeAnnotations.length; i < length; i++) {
/* 190 */           typeAnnotations[i].traverse(visitor, scope);
/*     */         }
/*     */       } 
/* 193 */       if (this.annotationsOnDimensions != null) {
/* 194 */         for (int i = 0, max = this.annotationsOnDimensions.length; i < max; i++) {
/* 195 */           Annotation[] annotations2 = this.annotationsOnDimensions[i];
/* 196 */           if (annotations2 != null) {
/* 197 */             for (int j = 0, max2 = annotations2.length; j < max2; j++) {
/* 198 */               Annotation annotation = annotations2[j];
/* 199 */               annotation.traverse(visitor, scope);
/*     */             } 
/*     */           }
/*     */         } 
/*     */       }
/*     */     } 
/* 205 */     visitor.endVisit(this, scope);
/*     */   }
/*     */ 
/*     */   
/*     */   protected TypeBinding internalResolveType(Scope scope, int location) {
/* 210 */     TypeBinding internalResolveType = super.internalResolveType(scope, location);
/* 211 */     internalResolveType = maybeMarkArrayContentsNonNull(scope, internalResolveType, this.sourceStart, this.dimensions, leafType -> {
/*     */         
/*     */         });
/* 214 */     return internalResolveType;
/*     */   }
/*     */   static TypeBinding maybeMarkArrayContentsNonNull(Scope scope, TypeBinding typeBinding, int sourceStart, int dimensions, Consumer<TypeBinding> leafConsumer) {
/*     */     ArrayBinding arrayBinding;
/* 218 */     LookupEnvironment environment = scope.environment();
/* 219 */     if (environment.usesNullTypeAnnotations() && 
/* 220 */       scope.hasDefaultNullnessFor(512, sourceStart)) {
/* 221 */       AnnotationBinding nonNullAnnotation = environment.getNonNullAnnotation();
/* 222 */       typeBinding = addNonNullToDimensions(scope, typeBinding, nonNullAnnotation, dimensions);
/*     */       
/* 224 */       TypeBinding leafComponentType = typeBinding.leafComponentType();
/* 225 */       if ((leafComponentType.tagBits & 0x180000000000000L) == 0L && leafComponentType.acceptsNonNullDefault()) {
/* 226 */         if (leafConsumer != null)
/* 227 */           leafConsumer.accept(leafComponentType); 
/* 228 */         TypeBinding nonNullLeafComponentType = scope.environment().createAnnotatedType(leafComponentType, 
/* 229 */             new AnnotationBinding[] { nonNullAnnotation });
/* 230 */         arrayBinding = scope.createArrayType(nonNullLeafComponentType, typeBinding.dimensions(), 
/* 231 */             typeBinding.getTypeAnnotations());
/*     */       } 
/*     */     } 
/* 234 */     return (TypeBinding)arrayBinding;
/*     */   }
/*     */ 
/*     */   
/*     */   static TypeBinding addNonNullToDimensions(Scope scope, TypeBinding typeBinding, AnnotationBinding nonNullAnnotation, int dimensions2) {
/* 239 */     AnnotationBinding[][] newAnnots = new AnnotationBinding[dimensions2][];
/* 240 */     AnnotationBinding[] oldAnnots = typeBinding.getTypeAnnotations();
/* 241 */     if (oldAnnots == null) {
/* 242 */       for (int i = 1; i < dimensions2; i++) {
/* 243 */         (new AnnotationBinding[1])[0] = nonNullAnnotation; newAnnots[i] = new AnnotationBinding[1];
/*     */       } 
/*     */     } else {
/* 246 */       int j = 0;
/* 247 */       for (int i = 0; i < dimensions2; i++) {
/* 248 */         if (j >= oldAnnots.length || oldAnnots[j] == null) {
/* 249 */           if (i != 0) {
/* 250 */             (new AnnotationBinding[1])[0] = nonNullAnnotation; newAnnots[i] = new AnnotationBinding[1];
/*     */           } 
/* 252 */           j++;
/*     */         } else {
/* 254 */           int k = j;
/* 255 */           boolean seen = false;
/* 256 */           while (oldAnnots[k] != null) {
/* 257 */             seen |= oldAnnots[k].getAnnotationType()
/* 258 */               .hasNullBit(96);
/* 259 */             k++;
/*     */           } 
/* 261 */           if (seen || i == 0) {
/* 262 */             if (k > j) {
/* 263 */               AnnotationBinding[] annotationsForDimension = new AnnotationBinding[k - j];
/* 264 */               System.arraycopy(oldAnnots, j, annotationsForDimension, 0, k - j);
/* 265 */               newAnnots[i] = annotationsForDimension;
/*     */             } 
/*     */           } else {
/* 268 */             AnnotationBinding[] annotationsForDimension = new AnnotationBinding[k - j + 1];
/* 269 */             annotationsForDimension[0] = nonNullAnnotation;
/* 270 */             System.arraycopy(oldAnnots, j, annotationsForDimension, 1, k - j);
/* 271 */             newAnnots[i] = annotationsForDimension;
/*     */           } 
/* 273 */           j = k + 1;
/*     */         } 
/*     */       } 
/*     */     } 
/* 277 */     return scope.environment().createAnnotatedType(typeBinding, newAnnots);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean hasNullTypeAnnotation(TypeReference.AnnotationPosition position) {
/* 282 */     switch (position) {
/*     */       
/*     */       case LEAF_TYPE:
/* 285 */         return super.hasNullTypeAnnotation(position);
/*     */       
/*     */       case MAIN_TYPE:
/* 288 */         if (this.annotationsOnDimensions != null && this.annotationsOnDimensions.length > 0) {
/* 289 */           Annotation[] innerAnnotations = this.annotationsOnDimensions[0];
/* 290 */           return containsNullAnnotation(innerAnnotations);
/*     */         } 
/*     */         
/* 293 */         return super.hasNullTypeAnnotation(position);
/*     */       case null:
/* 295 */         if (super.hasNullTypeAnnotation(position))
/* 296 */           return true; 
/* 297 */         if (this.resolvedType != null && !this.resolvedType.hasNullTypeAnnotations())
/* 298 */           return false; 
/* 299 */         if (this.annotationsOnDimensions != null)
/* 300 */           for (int i = 0; i < this.annotationsOnDimensions.length; i++) {
/* 301 */             Annotation[] innerAnnotations = this.annotationsOnDimensions[i];
/* 302 */             if (containsNullAnnotation(innerAnnotations))
/* 303 */               return true; 
/*     */           }  
/*     */         break;
/*     */     } 
/* 307 */     return false;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\ast\ArrayTypeReference.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */