/*     */ package org.eclipse.jdt.internal.compiler.ast;
/*     */ 
/*     */ import org.eclipse.jdt.internal.compiler.ASTVisitor;
/*     */ import org.eclipse.jdt.internal.compiler.codegen.CodeStream;
/*     */ import org.eclipse.jdt.internal.compiler.impl.CharConstant;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.BlockScope;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.TypeBinding;
/*     */ import org.eclipse.jdt.internal.compiler.parser.ScannerHelper;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CharLiteral
/*     */   extends NumberLiteral
/*     */ {
/*     */   char value;
/*     */   
/*     */   public CharLiteral(char[] token, int s, int e) {
/*  27 */     super(token, s, e);
/*  28 */     computeValue();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void computeConstant() {
/*  36 */     this.constant = CharConstant.fromValue(this.value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void computeValue() {
/*  43 */     if ((this.value = this.source[1]) != '\\')
/*     */       return; 
/*     */     char digit;
/*  46 */     switch (digit = this.source[2]) {
/*     */       case 's':
/*  48 */         this.value = ' ';
/*     */         return;
/*     */       case 'b':
/*  51 */         this.value = '\b';
/*     */         return;
/*     */       case 't':
/*  54 */         this.value = '\t';
/*     */         return;
/*     */       case 'n':
/*  57 */         this.value = '\n';
/*     */         return;
/*     */       case 'f':
/*  60 */         this.value = '\f';
/*     */         return;
/*     */       case 'r':
/*  63 */         this.value = '\r';
/*     */         return;
/*     */       case '"':
/*  66 */         this.value = '"';
/*     */         return;
/*     */       case '\'':
/*  69 */         this.value = '\'';
/*     */         return;
/*     */       case '\\':
/*  72 */         this.value = '\\';
/*     */         return;
/*     */     } 
/*  75 */     int number = ScannerHelper.getNumericValue(digit);
/*  76 */     if ((digit = this.source[3]) != '\'') {
/*  77 */       number = number * 8 + ScannerHelper.getNumericValue(digit);
/*     */     } else {
/*  79 */       this.constant = CharConstant.fromValue(this.value = (char)number);
/*     */       return;
/*     */     } 
/*  82 */     if ((digit = this.source[4]) != '\'')
/*  83 */       number = number * 8 + ScannerHelper.getNumericValue(digit); 
/*  84 */     this.value = (char)number;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void generateCode(BlockScope currentScope, CodeStream codeStream, boolean valueRequired) {
/*  98 */     int pc = codeStream.position;
/*  99 */     if (valueRequired) {
/* 100 */       codeStream.generateConstant(this.constant, this.implicitConversion);
/*     */     }
/* 102 */     codeStream.recordPositionsFrom(pc, this.sourceStart);
/*     */   }
/*     */ 
/*     */   
/*     */   public TypeBinding literalType(BlockScope scope) {
/* 107 */     return (TypeBinding)TypeBinding.CHAR;
/*     */   }
/*     */ 
/*     */   
/*     */   public void traverse(ASTVisitor visitor, BlockScope blockScope) {
/* 112 */     visitor.visit(this, blockScope);
/* 113 */     visitor.endVisit(this, blockScope);
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\ast\CharLiteral.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */