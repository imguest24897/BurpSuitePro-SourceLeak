/*    */ package org.eclipse.jdt.internal.compiler.env;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class null
/*    */   implements ITypeAnnotationWalker
/*    */ {
/*    */   public ITypeAnnotationWalker toField() {
/* 34 */     return this;
/*    */   } public ITypeAnnotationWalker toThrows(int rank) {
/* 36 */     return this;
/*    */   } public ITypeAnnotationWalker toTypeArgument(int rank) {
/* 38 */     return this;
/*    */   } public ITypeAnnotationWalker toMethodParameter(short index) {
/* 40 */     return this;
/*    */   } public ITypeAnnotationWalker toSupertype(short index, char[] superTypeSignature) {
/* 42 */     return this;
/*    */   } public ITypeAnnotationWalker toTypeParameterBounds(boolean isClassTypeParameter, int parameterRank) {
/* 44 */     return this;
/*    */   } public ITypeAnnotationWalker toTypeBound(short boundIndex) {
/* 46 */     return this;
/*    */   } public ITypeAnnotationWalker toTypeParameter(boolean isClassTypeParameter, int rank) {
/* 48 */     return this;
/*    */   } public ITypeAnnotationWalker toMethodReturn() {
/* 50 */     return this;
/*    */   } public ITypeAnnotationWalker toReceiver() {
/* 52 */     return this;
/*    */   } public ITypeAnnotationWalker toWildcardBound() {
/* 54 */     return this;
/*    */   } public ITypeAnnotationWalker toNextArrayDimension() {
/* 56 */     return this;
/*    */   } public ITypeAnnotationWalker toNextNestedType() {
/* 58 */     return this;
/*    */   } public IBinaryAnnotation[] getAnnotationsAtCursor(int currentTypeId, boolean mayApplyArrayContentsDefaultNullness) {
/* 60 */     return NO_ANNOTATIONS;
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\env\ITypeAnnotationWalker$1.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */