package org.eclipse.jdt.internal.compiler.codegen;

public interface Opcodes {
  public static final byte OPC_nop = 0;
  
  public static final byte OPC_aconst_null = 1;
  
  public static final byte OPC_iconst_m1 = 2;
  
  public static final byte OPC_iconst_0 = 3;
  
  public static final byte OPC_iconst_1 = 4;
  
  public static final byte OPC_iconst_2 = 5;
  
  public static final byte OPC_iconst_3 = 6;
  
  public static final byte OPC_iconst_4 = 7;
  
  public static final byte OPC_iconst_5 = 8;
  
  public static final byte OPC_lconst_0 = 9;
  
  public static final byte OPC_lconst_1 = 10;
  
  public static final byte OPC_fconst_0 = 11;
  
  public static final byte OPC_fconst_1 = 12;
  
  public static final byte OPC_fconst_2 = 13;
  
  public static final byte OPC_dconst_0 = 14;
  
  public static final byte OPC_dconst_1 = 15;
  
  public static final byte OPC_bipush = 16;
  
  public static final byte OPC_sipush = 17;
  
  public static final byte OPC_ldc = 18;
  
  public static final byte OPC_ldc_w = 19;
  
  public static final byte OPC_ldc2_w = 20;
  
  public static final byte OPC_iload = 21;
  
  public static final byte OPC_lload = 22;
  
  public static final byte OPC_fload = 23;
  
  public static final byte OPC_dload = 24;
  
  public static final byte OPC_aload = 25;
  
  public static final byte OPC_iload_0 = 26;
  
  public static final byte OPC_iload_1 = 27;
  
  public static final byte OPC_iload_2 = 28;
  
  public static final byte OPC_iload_3 = 29;
  
  public static final byte OPC_lload_0 = 30;
  
  public static final byte OPC_lload_1 = 31;
  
  public static final byte OPC_lload_2 = 32;
  
  public static final byte OPC_lload_3 = 33;
  
  public static final byte OPC_fload_0 = 34;
  
  public static final byte OPC_fload_1 = 35;
  
  public static final byte OPC_fload_2 = 36;
  
  public static final byte OPC_fload_3 = 37;
  
  public static final byte OPC_dload_0 = 38;
  
  public static final byte OPC_dload_1 = 39;
  
  public static final byte OPC_dload_2 = 40;
  
  public static final byte OPC_dload_3 = 41;
  
  public static final byte OPC_aload_0 = 42;
  
  public static final byte OPC_aload_1 = 43;
  
  public static final byte OPC_aload_2 = 44;
  
  public static final byte OPC_aload_3 = 45;
  
  public static final byte OPC_iaload = 46;
  
  public static final byte OPC_laload = 47;
  
  public static final byte OPC_faload = 48;
  
  public static final byte OPC_daload = 49;
  
  public static final byte OPC_aaload = 50;
  
  public static final byte OPC_baload = 51;
  
  public static final byte OPC_caload = 52;
  
  public static final byte OPC_saload = 53;
  
  public static final byte OPC_istore = 54;
  
  public static final byte OPC_lstore = 55;
  
  public static final byte OPC_fstore = 56;
  
  public static final byte OPC_dstore = 57;
  
  public static final byte OPC_astore = 58;
  
  public static final byte OPC_istore_0 = 59;
  
  public static final byte OPC_istore_1 = 60;
  
  public static final byte OPC_istore_2 = 61;
  
  public static final byte OPC_istore_3 = 62;
  
  public static final byte OPC_lstore_0 = 63;
  
  public static final byte OPC_lstore_1 = 64;
  
  public static final byte OPC_lstore_2 = 65;
  
  public static final byte OPC_lstore_3 = 66;
  
  public static final byte OPC_fstore_0 = 67;
  
  public static final byte OPC_fstore_1 = 68;
  
  public static final byte OPC_fstore_2 = 69;
  
  public static final byte OPC_fstore_3 = 70;
  
  public static final byte OPC_dstore_0 = 71;
  
  public static final byte OPC_dstore_1 = 72;
  
  public static final byte OPC_dstore_2 = 73;
  
  public static final byte OPC_dstore_3 = 74;
  
  public static final byte OPC_astore_0 = 75;
  
  public static final byte OPC_astore_1 = 76;
  
  public static final byte OPC_astore_2 = 77;
  
  public static final byte OPC_astore_3 = 78;
  
  public static final byte OPC_iastore = 79;
  
  public static final byte OPC_lastore = 80;
  
  public static final byte OPC_fastore = 81;
  
  public static final byte OPC_dastore = 82;
  
  public static final byte OPC_aastore = 83;
  
  public static final byte OPC_bastore = 84;
  
  public static final byte OPC_castore = 85;
  
  public static final byte OPC_sastore = 86;
  
  public static final byte OPC_pop = 87;
  
  public static final byte OPC_pop2 = 88;
  
  public static final byte OPC_dup = 89;
  
  public static final byte OPC_dup_x1 = 90;
  
  public static final byte OPC_dup_x2 = 91;
  
  public static final byte OPC_dup2 = 92;
  
  public static final byte OPC_dup2_x1 = 93;
  
  public static final byte OPC_dup2_x2 = 94;
  
  public static final byte OPC_swap = 95;
  
  public static final byte OPC_iadd = 96;
  
  public static final byte OPC_ladd = 97;
  
  public static final byte OPC_fadd = 98;
  
  public static final byte OPC_dadd = 99;
  
  public static final byte OPC_isub = 100;
  
  public static final byte OPC_lsub = 101;
  
  public static final byte OPC_fsub = 102;
  
  public static final byte OPC_dsub = 103;
  
  public static final byte OPC_imul = 104;
  
  public static final byte OPC_lmul = 105;
  
  public static final byte OPC_fmul = 106;
  
  public static final byte OPC_dmul = 107;
  
  public static final byte OPC_idiv = 108;
  
  public static final byte OPC_ldiv = 109;
  
  public static final byte OPC_fdiv = 110;
  
  public static final byte OPC_ddiv = 111;
  
  public static final byte OPC_irem = 112;
  
  public static final byte OPC_lrem = 113;
  
  public static final byte OPC_frem = 114;
  
  public static final byte OPC_drem = 115;
  
  public static final byte OPC_ineg = 116;
  
  public static final byte OPC_lneg = 117;
  
  public static final byte OPC_fneg = 118;
  
  public static final byte OPC_dneg = 119;
  
  public static final byte OPC_ishl = 120;
  
  public static final byte OPC_lshl = 121;
  
  public static final byte OPC_ishr = 122;
  
  public static final byte OPC_lshr = 123;
  
  public static final byte OPC_iushr = 124;
  
  public static final byte OPC_lushr = 125;
  
  public static final byte OPC_iand = 126;
  
  public static final byte OPC_land = 127;
  
  public static final byte OPC_ior = -128;
  
  public static final byte OPC_lor = -127;
  
  public static final byte OPC_ixor = -126;
  
  public static final byte OPC_lxor = -125;
  
  public static final byte OPC_iinc = -124;
  
  public static final byte OPC_i2l = -123;
  
  public static final byte OPC_i2f = -122;
  
  public static final byte OPC_i2d = -121;
  
  public static final byte OPC_l2i = -120;
  
  public static final byte OPC_l2f = -119;
  
  public static final byte OPC_l2d = -118;
  
  public static final byte OPC_f2i = -117;
  
  public static final byte OPC_f2l = -116;
  
  public static final byte OPC_f2d = -115;
  
  public static final byte OPC_d2i = -114;
  
  public static final byte OPC_d2l = -113;
  
  public static final byte OPC_d2f = -112;
  
  public static final byte OPC_i2b = -111;
  
  public static final byte OPC_i2c = -110;
  
  public static final byte OPC_i2s = -109;
  
  public static final byte OPC_lcmp = -108;
  
  public static final byte OPC_fcmpl = -107;
  
  public static final byte OPC_fcmpg = -106;
  
  public static final byte OPC_dcmpl = -105;
  
  public static final byte OPC_dcmpg = -104;
  
  public static final byte OPC_ifeq = -103;
  
  public static final byte OPC_ifne = -102;
  
  public static final byte OPC_iflt = -101;
  
  public static final byte OPC_ifge = -100;
  
  public static final byte OPC_ifgt = -99;
  
  public static final byte OPC_ifle = -98;
  
  public static final byte OPC_if_icmpeq = -97;
  
  public static final byte OPC_if_icmpne = -96;
  
  public static final byte OPC_if_icmplt = -95;
  
  public static final byte OPC_if_icmpge = -94;
  
  public static final byte OPC_if_icmpgt = -93;
  
  public static final byte OPC_if_icmple = -92;
  
  public static final byte OPC_if_acmpeq = -91;
  
  public static final byte OPC_if_acmpne = -90;
  
  public static final byte OPC_goto = -89;
  
  public static final byte OPC_jsr = -88;
  
  public static final byte OPC_ret = -87;
  
  public static final byte OPC_tableswitch = -86;
  
  public static final byte OPC_lookupswitch = -85;
  
  public static final byte OPC_ireturn = -84;
  
  public static final byte OPC_lreturn = -83;
  
  public static final byte OPC_freturn = -82;
  
  public static final byte OPC_dreturn = -81;
  
  public static final byte OPC_areturn = -80;
  
  public static final byte OPC_return = -79;
  
  public static final byte OPC_getstatic = -78;
  
  public static final byte OPC_putstatic = -77;
  
  public static final byte OPC_getfield = -76;
  
  public static final byte OPC_putfield = -75;
  
  public static final byte OPC_invokevirtual = -74;
  
  public static final byte OPC_invokespecial = -73;
  
  public static final byte OPC_invokestatic = -72;
  
  public static final byte OPC_invokeinterface = -71;
  
  public static final byte OPC_invokedynamic = -70;
  
  public static final byte OPC_new = -69;
  
  public static final byte OPC_newarray = -68;
  
  public static final byte OPC_anewarray = -67;
  
  public static final byte OPC_arraylength = -66;
  
  public static final byte OPC_athrow = -65;
  
  public static final byte OPC_checkcast = -64;
  
  public static final byte OPC_instanceof = -63;
  
  public static final byte OPC_monitorenter = -62;
  
  public static final byte OPC_monitorexit = -61;
  
  public static final byte OPC_wide = -60;
  
  public static final byte OPC_multianewarray = -59;
  
  public static final byte OPC_ifnull = -58;
  
  public static final byte OPC_ifnonnull = -57;
  
  public static final byte OPC_goto_w = -56;
  
  public static final byte OPC_jsr_w = -55;
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\codegen\Opcodes.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */