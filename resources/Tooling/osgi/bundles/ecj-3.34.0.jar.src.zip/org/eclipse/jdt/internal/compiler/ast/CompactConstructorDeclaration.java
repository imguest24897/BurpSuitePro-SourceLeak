/*    */ package org.eclipse.jdt.internal.compiler.ast;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import org.eclipse.jdt.internal.compiler.CompilationResult;
/*    */ import org.eclipse.jdt.internal.compiler.flow.FlowContext;
/*    */ import org.eclipse.jdt.internal.compiler.flow.FlowInfo;
/*    */ import org.eclipse.jdt.internal.compiler.flow.InitializationFlowContext;
/*    */ import org.eclipse.jdt.internal.compiler.lookup.BlockScope;
/*    */ import org.eclipse.jdt.internal.compiler.lookup.ClassScope;
/*    */ import org.eclipse.jdt.internal.compiler.lookup.FieldBinding;
/*    */ import org.eclipse.jdt.internal.compiler.parser.Parser;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CompactConstructorDeclaration
/*    */   extends ConstructorDeclaration
/*    */ {
/*    */   public TypeDeclaration recordDeclaration;
/*    */   
/*    */   public CompactConstructorDeclaration(CompilationResult compilationResult) {
/* 31 */     super(compilationResult);
/*    */   }
/*    */   
/*    */   public void parseStatements(Parser parser, CompilationUnitDeclaration unit) {
/* 35 */     this.constructorCall = SuperReference.implicitSuperConstructorCall();
/* 36 */     parser.parse(this, unit, false);
/* 37 */     this.containsSwitchWithTry = parser.switchWithTry;
/*    */   }
/*    */   
/*    */   public void analyseCode(ClassScope classScope, InitializationFlowContext initializerFlowContext, FlowInfo flowInfo, int initialReachMode) {
/*    */     try {
/* 42 */       this.scope.isCompactConstructorScope = true;
/* 43 */       super.analyseCode(classScope, initializerFlowContext, flowInfo, initialReachMode);
/*    */     } finally {
/* 45 */       this.scope.isCompactConstructorScope = false;
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   protected void doFieldReachAnalysis(FlowInfo flowInfo, FieldBinding[] fields) {}
/*    */ 
/*    */   
/*    */   protected void checkAndGenerateFieldAssignment(FlowContext flowContext, FlowInfo flowInfo, FieldBinding[] fields) {
/* 54 */     this.scope.isCompactConstructorScope = false;
/* 55 */     if (fields == null) {
/*    */       return;
/*    */     }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 63 */     List<Statement> fieldAssignments = new ArrayList<>(); byte b; int i; FieldBinding[] arrayOfFieldBinding;
/* 64 */     for (i = (arrayOfFieldBinding = fields).length, b = 0; b < i; ) { FieldBinding field = arrayOfFieldBinding[b];
/* 65 */       if (!field.isStatic()) {
/*    */         
/* 67 */         assert field.isFinal();
/*    */         
/* 69 */         FieldReference lhs = new FieldReference(field.name, 0L);
/* 70 */         lhs.receiver = new ThisReference(0, 0);
/*    */         
/* 72 */         Assignment assignment = new Assignment(lhs, new SingleNameReference(field.name, 0L), 0);
/* 73 */         assignment.resolveType((BlockScope)this.scope);
/* 74 */         assignment.analyseCode((BlockScope)this.scope, flowContext, flowInfo);
/* 75 */         assignment.bits |= 0x400;
/* 76 */         assert flowInfo.isDefinitelyAssigned(field);
/* 77 */         fieldAssignments.add(assignment);
/*    */       }  b++; }
/* 79 */      if (fieldAssignments.isEmpty() || (flowInfo.tagBits & 0x1) != 0) {
/*    */       return;
/*    */     }
/* 82 */     Statement[] fa = fieldAssignments.<Statement>toArray(new Statement[0]);
/* 83 */     if (this.statements == null) {
/* 84 */       this.statements = fa;
/*    */       return;
/*    */     } 
/* 87 */     int len = this.statements.length;
/* 88 */     int fLen = fa.length;
/* 89 */     Statement[] stmts = new Statement[len + fLen];
/* 90 */     System.arraycopy(this.statements, 0, stmts, 0, len);
/* 91 */     System.arraycopy(fa, 0, stmts, len, fLen);
/* 92 */     this.statements = stmts;
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\ast\CompactConstructorDeclaration.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */