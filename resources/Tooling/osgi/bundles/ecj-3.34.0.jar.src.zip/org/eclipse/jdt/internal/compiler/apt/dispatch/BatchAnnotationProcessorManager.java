/*     */ package org.eclipse.jdt.internal.compiler.apt.dispatch;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.net.URLClassLoader;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.ServiceConfigurationError;
/*     */ import java.util.ServiceLoader;
/*     */ import javax.annotation.processing.Processor;
/*     */ import javax.lang.model.SourceVersion;
/*     */ import javax.tools.JavaFileManager;
/*     */ import javax.tools.StandardJavaFileManager;
/*     */ import javax.tools.StandardLocation;
/*     */ import org.eclipse.jdt.internal.compiler.batch.Main;
/*     */ import org.eclipse.jdt.internal.compiler.problem.AbortCompilation;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BatchAnnotationProcessorManager
/*     */   extends BaseAnnotationProcessorManager
/*     */ {
/*  46 */   private List<Processor> _setProcessors = null;
/*  47 */   private Iterator<Processor> _setProcessorIter = null;
/*     */ 
/*     */   
/*     */   private List<String> _commandLineProcessors;
/*     */ 
/*     */   
/*  53 */   private Iterator<String> _commandLineProcessorIter = null;
/*     */   
/*  55 */   private ServiceLoader<Processor> _serviceLoader = null;
/*     */ 
/*     */ 
/*     */   
/*     */   private Iterator<Processor> _serviceLoaderIter;
/*     */ 
/*     */ 
/*     */   
/*     */   private ClassLoader _procLoader;
/*     */ 
/*     */ 
/*     */   
/*     */   private static final boolean VERBOSE_PROCESSOR_DISCOVERY = true;
/*     */ 
/*     */   
/*     */   private boolean _printProcessorDiscovery = false;
/*     */ 
/*     */ 
/*     */   
/*     */   public void configure(Object batchCompiler, String[] commandLineArguments) {
/*  75 */     if (this._processingEnv != null) {
/*  76 */       throw new IllegalStateException(
/*  77 */           "Calling configure() more than once on an AnnotationProcessorManager is not supported");
/*     */     }
/*  79 */     BatchProcessingEnvImpl processingEnv = new BatchProcessingEnvImpl(this, (Main)batchCompiler, commandLineArguments);
/*  80 */     this._processingEnv = processingEnv;
/*     */     
/*  82 */     JavaFileManager fileManager = processingEnv.getFileManager();
/*  83 */     if (fileManager instanceof StandardJavaFileManager) {
/*  84 */       Iterable<? extends File> location = null;
/*  85 */       if (SourceVersion.latest().compareTo(SourceVersion.RELEASE_8) > 0) {
/*  86 */         location = ((StandardJavaFileManager)fileManager).getLocation(StandardLocation.ANNOTATION_PROCESSOR_MODULE_PATH);
/*     */       }
/*  88 */       if (location != null) {
/*  89 */         this._procLoader = fileManager.getClassLoader(StandardLocation.ANNOTATION_PROCESSOR_MODULE_PATH);
/*     */       } else {
/*  91 */         this._procLoader = fileManager.getClassLoader(StandardLocation.ANNOTATION_PROCESSOR_PATH);
/*     */       } 
/*     */     } else {
/*     */       
/*  95 */       this._procLoader = fileManager.getClassLoader(StandardLocation.ANNOTATION_PROCESSOR_PATH);
/*     */     } 
/*  97 */     parseCommandLine(commandLineArguments);
/*  98 */     this._round = 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void parseCommandLine(String[] commandLineArguments) {
/* 107 */     List<String> commandLineProcessors = null;
/* 108 */     for (int i = 0; i < commandLineArguments.length; i++) {
/* 109 */       String option = commandLineArguments[i];
/* 110 */       if ("-XprintProcessorInfo".equals(option)) {
/* 111 */         this._printProcessorInfo = true;
/* 112 */         this._printProcessorDiscovery = true;
/*     */       }
/* 114 */       else if ("-XprintRounds".equals(option)) {
/* 115 */         this._printRounds = true;
/*     */       }
/* 117 */       else if ("-processor".equals(option)) {
/* 118 */         commandLineProcessors = new ArrayList<>();
/* 119 */         String procs = commandLineArguments[++i];
/* 120 */         commandLineProcessors.addAll(Arrays.asList(procs.split(",")));
/*     */         break;
/*     */       } 
/*     */     } 
/* 124 */     this._commandLineProcessors = commandLineProcessors;
/* 125 */     if (this._commandLineProcessors != null) {
/* 126 */       this._commandLineProcessorIter = this._commandLineProcessors.iterator();
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public ProcessorInfo discoverNextProcessor() {
/* 132 */     if (this._setProcessors != null) {
/*     */       
/* 134 */       if (this._setProcessorIter.hasNext()) {
/* 135 */         Processor p = this._setProcessorIter.next();
/* 136 */         p.init(this._processingEnv);
/* 137 */         ProcessorInfo pi = new ProcessorInfo(p);
/* 138 */         this._processors.add(pi);
/* 139 */         if (this._printProcessorDiscovery && this._out != null) {
/* 140 */           this._out.println("API specified processor: " + pi);
/*     */         }
/* 142 */         return pi;
/*     */       } 
/* 144 */       return null;
/*     */     } 
/*     */     
/* 147 */     if (this._commandLineProcessors != null) {
/*     */ 
/*     */       
/* 150 */       if (this._commandLineProcessorIter.hasNext()) {
/* 151 */         String proc = this._commandLineProcessorIter.next();
/*     */         try {
/* 153 */           Class<?> clazz = this._procLoader.loadClass(proc);
/* 154 */           Object o = clazz.getDeclaredConstructor(new Class[0]).newInstance(new Object[0]);
/* 155 */           Processor p = (Processor)o;
/* 156 */           p.init(this._processingEnv);
/* 157 */           ProcessorInfo pi = new ProcessorInfo(p);
/* 158 */           this._processors.add(pi);
/* 159 */           if (this._printProcessorDiscovery && this._out != null) {
/* 160 */             this._out.println("Command line specified processor: " + pi);
/*     */           }
/* 162 */           return pi;
/* 163 */         } catch (Exception e) {
/*     */           
/* 165 */           throw new AbortCompilation(null, e);
/*     */         } 
/*     */       } 
/* 168 */       return null;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 173 */     if (this._serviceLoader == null) {
/* 174 */       this._serviceLoader = ServiceLoader.load(Processor.class, this._procLoader);
/* 175 */       this._serviceLoaderIter = this._serviceLoader.iterator();
/*     */     } 
/*     */     try {
/* 178 */       if (this._serviceLoaderIter.hasNext()) {
/* 179 */         Processor p = this._serviceLoaderIter.next();
/* 180 */         p.init(this._processingEnv);
/* 181 */         ProcessorInfo pi = new ProcessorInfo(p);
/* 182 */         this._processors.add(pi);
/* 183 */         if (this._printProcessorDiscovery && this._out != null) {
/* 184 */           StringBuilder sb = new StringBuilder();
/* 185 */           sb.append("Discovered processor service ");
/* 186 */           sb.append(pi);
/* 187 */           sb.append("\n  supporting ");
/* 188 */           sb.append(pi.getSupportedAnnotationTypesAsString());
/* 189 */           sb.append("\n  in ");
/* 190 */           sb.append(getProcessorLocation(p));
/* 191 */           this._out.println(sb.toString());
/*     */         } 
/* 193 */         return pi;
/*     */       } 
/* 195 */     } catch (ServiceConfigurationError e) {
/*     */       
/* 197 */       throw new AbortCompilation(null, e);
/*     */     } 
/* 199 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String getProcessorLocation(Processor p) {
/* 210 */     boolean isMember = false;
/* 211 */     Class<?> outerClass = p.getClass();
/* 212 */     StringBuilder innerName = new StringBuilder();
/* 213 */     while (outerClass.isMemberClass()) {
/* 214 */       innerName.insert(0, outerClass.getSimpleName());
/* 215 */       innerName.insert(0, '$');
/* 216 */       isMember = true;
/* 217 */       outerClass = outerClass.getEnclosingClass();
/*     */     } 
/* 219 */     String path = outerClass.getName();
/* 220 */     path = path.replace('.', '/');
/* 221 */     if (isMember) {
/* 222 */       path = String.valueOf(path) + innerName;
/*     */     }
/* 224 */     path = String.valueOf(path) + ".class";
/*     */ 
/*     */     
/* 227 */     String location = this._procLoader.getResource(path).toString();
/* 228 */     if (location.endsWith(path)) {
/* 229 */       location = location.substring(0, location.length() - path.length());
/*     */     }
/* 231 */     return location;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void reportProcessorException(Processor p, Exception e) {
/* 237 */     throw new AbortCompilation(null, e);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setProcessors(Object[] processors) {
/* 242 */     if (!this._isFirstRound) {
/* 243 */       throw new IllegalStateException("setProcessors() cannot be called after processing has begun");
/*     */     }
/*     */ 
/*     */     
/* 247 */     this._setProcessors = new ArrayList<>(processors.length); byte b; int i; Object[] arrayOfObject;
/* 248 */     for (i = (arrayOfObject = processors).length, b = 0; b < i; ) { Object o = arrayOfObject[b];
/* 249 */       Processor p = (Processor)o;
/* 250 */       this._setProcessors.add(p); b++; }
/*     */     
/* 252 */     this._setProcessorIter = this._setProcessors.iterator();
/*     */ 
/*     */     
/* 255 */     this._commandLineProcessors = null;
/* 256 */     this._commandLineProcessorIter = null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void cleanUp() {
/* 262 */     if (this._procLoader instanceof URLClassLoader)
/*     */       try {
/* 264 */         ((URLClassLoader)this._procLoader).close();
/* 265 */       } catch (IOException e) {
/* 266 */         e.printStackTrace();
/*     */       }  
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\apt\dispatch\BatchAnnotationProcessorManager.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */