/*     */ package org.eclipse.jdt.internal.compiler.codegen;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.Set;
/*     */ import org.eclipse.jdt.core.compiler.CharOperation;
/*     */ import org.eclipse.jdt.internal.compiler.ClassFile;
/*     */ import org.eclipse.jdt.internal.compiler.ast.ASTNode;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.Binding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.FieldBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.LocalVariableBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.MethodBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.Scope;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.TypeBinding;
/*     */ import org.eclipse.jdt.internal.compiler.problem.AbortMethod;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class StackMapFrameCodeStream
/*     */   extends CodeStream
/*     */ {
/*     */   public int[] stateIndexes;
/*     */   public int stateIndexesCounter;
/*     */   private HashMap framePositions;
/*     */   public Set exceptionMarkers;
/*     */   public ArrayList stackDepthMarkers;
/*     */   public ArrayList stackMarkers;
/*     */   
/*     */   public static class ExceptionMarker
/*     */     implements Comparable
/*     */   {
/*     */     private TypeBinding binding;
/*     */     public int pc;
/*     */     
/*     */     public ExceptionMarker(int pc, TypeBinding typeBinding) {
/*  43 */       this.pc = pc;
/*  44 */       this.binding = typeBinding;
/*     */     }
/*     */ 
/*     */     
/*     */     public int compareTo(Object o) {
/*  49 */       if (o instanceof ExceptionMarker) {
/*  50 */         return this.pc - ((ExceptionMarker)o).pc;
/*     */       }
/*  52 */       return 0;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean equals(Object obj) {
/*  57 */       if (obj instanceof ExceptionMarker) {
/*  58 */         ExceptionMarker marker = (ExceptionMarker)obj;
/*  59 */         return (this.pc == marker.pc && this.binding.equals(marker.binding));
/*     */       } 
/*  61 */       return false;
/*     */     }
/*     */     
/*     */     public TypeBinding getBinding() {
/*  65 */       return this.binding;
/*     */     }
/*     */ 
/*     */     
/*     */     public int hashCode() {
/*  70 */       return this.pc + CharOperation.hashCode(this.binding.constantPoolName());
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/*  75 */       StringBuffer buffer = new StringBuffer();
/*  76 */       buffer.append('(').append(this.pc).append(',').append(this.binding.constantPoolName()).append(')');
/*  77 */       return String.valueOf(buffer);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static class FramePosition
/*     */   {
/*     */     int counter;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public StackMapFrameCodeStream(ClassFile givenClassFile) {
/*  93 */     super(givenClassFile);
/*  94 */     this.generateAttributes |= 0x10;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addDefinitelyAssignedVariables(Scope scope, int initStateIndex) {
/*     */     // Byte code:
/*     */     //   0: iconst_0
/*     */     //   1: istore_3
/*     */     //   2: goto -> 77
/*     */     //   5: aload_0
/*     */     //   6: getfield visibleLocals : [Lorg/eclipse/jdt/internal/compiler/lookup/LocalVariableBinding;
/*     */     //   9: iload_3
/*     */     //   10: aaload
/*     */     //   11: astore #4
/*     */     //   13: aload #4
/*     */     //   15: ifnull -> 74
/*     */     //   18: aload_0
/*     */     //   19: aload_1
/*     */     //   20: iload_2
/*     */     //   21: aload #4
/*     */     //   23: invokevirtual isDefinitelyAssigned : (Lorg/eclipse/jdt/internal/compiler/lookup/Scope;ILorg/eclipse/jdt/internal/compiler/lookup/LocalVariableBinding;)Z
/*     */     //   26: istore #5
/*     */     //   28: iload #5
/*     */     //   30: ifne -> 36
/*     */     //   33: goto -> 74
/*     */     //   36: aload #4
/*     */     //   38: getfield initializationCount : I
/*     */     //   41: ifeq -> 65
/*     */     //   44: aload #4
/*     */     //   46: getfield initializationPCs : [I
/*     */     //   49: aload #4
/*     */     //   51: getfield initializationCount : I
/*     */     //   54: iconst_1
/*     */     //   55: isub
/*     */     //   56: iconst_1
/*     */     //   57: ishl
/*     */     //   58: iconst_1
/*     */     //   59: iadd
/*     */     //   60: iaload
/*     */     //   61: iconst_m1
/*     */     //   62: if_icmpeq -> 74
/*     */     //   65: aload #4
/*     */     //   67: aload_0
/*     */     //   68: getfield position : I
/*     */     //   71: invokevirtual recordInitializationStartPC : (I)V
/*     */     //   74: iinc #3, 1
/*     */     //   77: iload_3
/*     */     //   78: aload_0
/*     */     //   79: getfield visibleLocalsCount : I
/*     */     //   82: if_icmplt -> 5
/*     */     //   85: return
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #100	-> 0
/*     */     //   #101	-> 5
/*     */     //   #102	-> 13
/*     */     //   #104	-> 18
/*     */     //   #105	-> 28
/*     */     //   #106	-> 33
/*     */     //   #108	-> 36
/*     */     //   #109	-> 44
/*     */     //   #110	-> 58
/*     */     //   #109	-> 60
/*     */     //   #110	-> 61
/*     */     //   #109	-> 62
/*     */     //   #119	-> 65
/*     */     //   #100	-> 74
/*     */     //   #124	-> 85
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	descriptor
/*     */     //   0	86	0	this	Lorg/eclipse/jdt/internal/compiler/codegen/StackMapFrameCodeStream;
/*     */     //   0	86	1	scope	Lorg/eclipse/jdt/internal/compiler/lookup/Scope;
/*     */     //   0	86	2	initStateIndex	I
/*     */     //   2	83	3	i	I
/*     */     //   13	61	4	localBinding	Lorg/eclipse/jdt/internal/compiler/lookup/LocalVariableBinding;
/*     */     //   28	46	5	isDefinitelyAssigned	Z
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addExceptionMarker(int pc, TypeBinding typeBinding) {
/* 127 */     if (this.exceptionMarkers == null) {
/* 128 */       this.exceptionMarkers = new HashSet();
/*     */     }
/*     */     
/* 131 */     this.exceptionMarkers.add(new ExceptionMarker(pc, typeBinding));
/*     */   }
/*     */   
/*     */   public void addFramePosition(int pc) {
/* 135 */     Integer newEntry = Integer.valueOf(pc);
/*     */     FramePosition value;
/* 137 */     if ((value = (FramePosition)this.framePositions.get(newEntry)) != null) {
/* 138 */       value.counter++;
/*     */     } else {
/* 140 */       this.framePositions.put(newEntry, new FramePosition());
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void optimizeBranch(int oldPosition, BranchLabel lbl) {
/* 146 */     super.optimizeBranch(oldPosition, lbl);
/* 147 */     removeFramePosition(oldPosition);
/*     */   }
/*     */   
/*     */   public void removeFramePosition(int pc) {
/* 151 */     Integer entry = Integer.valueOf(pc);
/*     */     FramePosition value;
/* 153 */     if ((value = (FramePosition)this.framePositions.get(entry)) != null) {
/* 154 */       value.counter--;
/* 155 */       if (value.counter <= 0) {
/* 156 */         this.framePositions.remove(entry);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void addVariable(LocalVariableBinding localBinding) {
/* 163 */     if (localBinding.initializationPCs == null) {
/* 164 */       record(localBinding);
/*     */     }
/* 166 */     localBinding.recordInitializationStartPC(this.position);
/*     */   }
/*     */ 
/*     */   
/*     */   public void recordExpressionType(TypeBinding typeBinding, int delta, boolean adjustStackDepth) {
/* 171 */     if (adjustStackDepth) {
/*     */ 
/*     */ 
/*     */       
/* 175 */       switch (typeBinding.id) {
/*     */         case 7:
/*     */         case 8:
/* 178 */           this.stackDepth += 2;
/*     */         
/*     */         case 6:
/*     */           return;
/*     */       } 
/* 183 */       this.stackDepth++;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void generateClassLiteralAccessForType(Scope scope, TypeBinding accessedType, FieldBinding syntheticFieldBinding) {
/* 195 */     if (accessedType.isBaseType() && accessedType != TypeBinding.NULL) {
/* 196 */       getTYPE(accessedType.id);
/*     */       
/*     */       return;
/*     */     } 
/* 200 */     if (this.targetLevel >= 3211264L) {
/*     */       
/* 202 */       ldc(accessedType);
/*     */     } else {
/*     */       
/* 205 */       BranchLabel endLabel = new BranchLabel(this);
/* 206 */       if (syntheticFieldBinding != null) {
/* 207 */         fieldAccess((byte)-78, syntheticFieldBinding, null);
/* 208 */         dup();
/* 209 */         ifnonnull(endLabel);
/* 210 */         pop();
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 225 */       ExceptionLabel classNotFoundExceptionHandler = new ExceptionLabel(this, 
/* 226 */           (TypeBinding)TypeBinding.NULL);
/* 227 */       classNotFoundExceptionHandler.placeStart();
/* 228 */       ldc((accessedType == TypeBinding.NULL) ? "java.lang.Object" : 
/* 229 */           String.valueOf(accessedType.constantPoolName()).replace('/', '.'));
/* 230 */       invokeClassForName();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 246 */       classNotFoundExceptionHandler.placeEnd();
/*     */       
/* 248 */       if (syntheticFieldBinding != null) {
/* 249 */         dup();
/* 250 */         fieldAccess((byte)-77, syntheticFieldBinding, null);
/*     */       } 
/* 252 */       goto_(endLabel);
/* 253 */       int savedStackDepth = this.stackDepth;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 261 */       pushExceptionOnStack((TypeBinding)scope.getJavaLangClassNotFoundException());
/* 262 */       classNotFoundExceptionHandler.place();
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 267 */       newNoClassDefFoundError();
/* 268 */       dup_x1();
/* 269 */       swap();
/*     */ 
/*     */       
/* 272 */       invokeThrowableGetMessage();
/*     */ 
/*     */       
/* 275 */       invokeNoClassDefFoundErrorStringConstructor();
/* 276 */       athrow();
/* 277 */       endLabel.place();
/* 278 */       this.stackDepth = savedStackDepth;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void generateOuterAccess(Object[] mappingSequence, ASTNode invocationSite, Binding target, Scope scope) {
/* 284 */     int currentPosition = this.position;
/* 285 */     super.generateOuterAccess(mappingSequence, invocationSite, target, scope);
/* 286 */     if (currentPosition == this.position)
/*     */     {
/* 288 */       throw new AbortMethod((scope.referenceCompilationUnit()).compilationResult, null);
/*     */     }
/*     */   }
/*     */   
/*     */   public ExceptionMarker[] getExceptionMarkers() {
/* 293 */     Set exceptionMarkerSet = this.exceptionMarkers;
/* 294 */     if (this.exceptionMarkers == null)
/* 295 */       return null; 
/* 296 */     int size = exceptionMarkerSet.size();
/* 297 */     ExceptionMarker[] markers = new ExceptionMarker[size];
/* 298 */     int n = 0;
/* 299 */     for (Iterator<ExceptionMarker> iterator = exceptionMarkerSet.iterator(); iterator.hasNext();) {
/* 300 */       markers[n++] = iterator.next();
/*     */     }
/* 302 */     Arrays.sort((Object[])markers);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 309 */     return markers;
/*     */   }
/*     */   
/*     */   public int[] getFramePositions() {
/* 313 */     Set set = this.framePositions.keySet();
/* 314 */     int size = set.size();
/* 315 */     int[] positions = new int[size];
/* 316 */     int n = 0;
/* 317 */     for (Iterator iterator = set.iterator(); iterator.hasNext();) {
/* 318 */       positions[n++] = ((Integer)iterator.next()).intValue();
/*     */     }
/* 320 */     Arrays.sort(positions);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 327 */     return positions;
/*     */   }
/*     */   
/*     */   public boolean hasFramePositions() {
/* 331 */     return (this.framePositions.size() != 0);
/*     */   }
/*     */ 
/*     */   
/*     */   public void init(ClassFile targetClassFile) {
/* 336 */     super.init(targetClassFile);
/* 337 */     this.stateIndexesCounter = 0;
/* 338 */     if (this.framePositions != null) {
/* 339 */       this.framePositions.clear();
/*     */     }
/* 341 */     if (this.exceptionMarkers != null) {
/* 342 */       this.exceptionMarkers.clear();
/*     */     }
/* 344 */     if (this.stackDepthMarkers != null) {
/* 345 */       this.stackDepthMarkers.clear();
/*     */     }
/* 347 */     if (this.stackMarkers != null) {
/* 348 */       this.stackMarkers.clear();
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void initializeMaxLocals(MethodBinding methodBinding) {
/* 354 */     super.initializeMaxLocals(methodBinding);
/* 355 */     if (this.framePositions == null) {
/* 356 */       this.framePositions = new HashMap<>();
/*     */     } else {
/* 358 */       this.framePositions.clear();
/*     */     } 
/*     */   }
/*     */   
/*     */   public void popStateIndex() {
/* 363 */     this.stateIndexesCounter--;
/*     */   }
/*     */   
/*     */   public void pushStateIndex(int naturalExitMergeInitStateIndex) {
/* 367 */     if (this.stateIndexes == null) {
/* 368 */       this.stateIndexes = new int[3];
/*     */     }
/* 370 */     int length = this.stateIndexes.length;
/* 371 */     if (length == this.stateIndexesCounter)
/*     */     {
/* 373 */       System.arraycopy(this.stateIndexes, 0, this.stateIndexes = new int[length * 2], 0, length);
/*     */     }
/* 375 */     this.stateIndexes[this.stateIndexesCounter++] = naturalExitMergeInitStateIndex;
/*     */   }
/*     */ 
/*     */   
/*     */   public void removeNotDefinitelyAssignedVariables(Scope scope, int initStateIndex) {
/* 380 */     int index = this.visibleLocalsCount;
/* 381 */     for (int i = 0; i < index; i++) {
/* 382 */       LocalVariableBinding localBinding = this.visibleLocals[i];
/* 383 */       if (localBinding != null && localBinding.initializationCount > 0) {
/* 384 */         boolean isDefinitelyAssigned = isDefinitelyAssigned(scope, initStateIndex, localBinding);
/* 385 */         if (!isDefinitelyAssigned) {
/* 386 */           if (this.stateIndexes != null) {
/* 387 */             for (int j = 0, max = this.stateIndexesCounter; j < max; j++) {
/* 388 */               if (isDefinitelyAssigned(scope, this.stateIndexes[j], localBinding)) {
/*     */                 // Byte code: goto -> 106
/*     */               }
/*     */             } 
/*     */           }
/* 393 */           localBinding.recordInitializationEndPC(this.position);
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void reset(ClassFile givenClassFile) {
/* 401 */     super.reset(givenClassFile);
/* 402 */     this.stateIndexesCounter = 0;
/* 403 */     if (this.framePositions != null) {
/* 404 */       this.framePositions.clear();
/*     */     }
/* 406 */     if (this.exceptionMarkers != null) {
/* 407 */       this.exceptionMarkers.clear();
/*     */     }
/* 409 */     if (this.stackDepthMarkers != null) {
/* 410 */       this.stackDepthMarkers.clear();
/*     */     }
/* 412 */     if (this.stackMarkers != null) {
/* 413 */       this.stackMarkers.clear();
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   protected void writePosition(BranchLabel label) {
/* 419 */     super.writePosition(label);
/* 420 */     addFramePosition(label.position);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void writePosition(BranchLabel label, int forwardReference) {
/* 425 */     super.writePosition(label, forwardReference);
/* 426 */     addFramePosition(label.position);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void writeSignedWord(int pos, int value) {
/* 431 */     super.writeSignedWord(pos, value);
/* 432 */     addFramePosition(this.position);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void writeWidePosition(BranchLabel label) {
/* 437 */     super.writeWidePosition(label);
/* 438 */     addFramePosition(label.position);
/*     */   }
/*     */ 
/*     */   
/*     */   public void areturn() {
/* 443 */     super.areturn();
/* 444 */     addFramePosition(this.position);
/*     */   }
/*     */ 
/*     */   
/*     */   public void ireturn() {
/* 449 */     super.ireturn();
/* 450 */     addFramePosition(this.position);
/*     */   }
/*     */ 
/*     */   
/*     */   public void lreturn() {
/* 455 */     super.lreturn();
/* 456 */     addFramePosition(this.position);
/*     */   }
/*     */ 
/*     */   
/*     */   public void freturn() {
/* 461 */     super.freturn();
/* 462 */     addFramePosition(this.position);
/*     */   }
/*     */ 
/*     */   
/*     */   public void dreturn() {
/* 467 */     super.dreturn();
/* 468 */     addFramePosition(this.position);
/*     */   }
/*     */ 
/*     */   
/*     */   public void return_() {
/* 473 */     super.return_();
/* 474 */     addFramePosition(this.position);
/*     */   }
/*     */ 
/*     */   
/*     */   public void athrow() {
/* 479 */     super.athrow();
/* 480 */     addFramePosition(this.position);
/*     */   }
/*     */ 
/*     */   
/*     */   public void pushExceptionOnStack(TypeBinding binding) {
/* 485 */     super.pushExceptionOnStack(binding);
/* 486 */     addExceptionMarker(this.position, binding);
/*     */   }
/*     */ 
/*     */   
/*     */   public void goto_(BranchLabel label) {
/* 491 */     super.goto_(label);
/* 492 */     addFramePosition(this.position);
/*     */   }
/*     */ 
/*     */   
/*     */   public void goto_w(BranchLabel label) {
/* 497 */     super.goto_w(label);
/* 498 */     addFramePosition(this.position);
/*     */   }
/*     */ 
/*     */   
/*     */   public void resetInWideMode() {
/* 503 */     resetSecretLocals();
/* 504 */     super.resetInWideMode();
/*     */   }
/*     */ 
/*     */   
/*     */   public void resetForCodeGenUnusedLocals() {
/* 509 */     resetSecretLocals();
/* 510 */     super.resetForCodeGenUnusedLocals();
/*     */   }
/*     */   
/*     */   public void resetSecretLocals() {
/* 514 */     for (int i = 0, max = this.locals.length; i < max; i++) {
/* 515 */       LocalVariableBinding localVariableBinding = this.locals[i];
/* 516 */       if (localVariableBinding != null && localVariableBinding.isSecret())
/*     */       {
/* 518 */         localVariableBinding.resetInitializations();
/*     */       }
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\codegen\StackMapFrameCodeStream.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */