/*     */ package org.eclipse.jdt.internal.compiler.codegen;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ObjectCache
/*     */ {
/*     */   public Object[] keyTable;
/*     */   public int[] valueTable;
/*     */   int elementSize;
/*     */   int threshold;
/*     */   
/*     */   public ObjectCache() {
/*  26 */     this(13);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ObjectCache(int initialCapacity) {
/*  35 */     this.elementSize = 0;
/*  36 */     this.threshold = (int)(initialCapacity * 0.66F);
/*  37 */     this.keyTable = new Object[initialCapacity];
/*  38 */     this.valueTable = new int[initialCapacity];
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void clear() {
/*  44 */     for (int i = this.keyTable.length; --i >= 0; ) {
/*  45 */       this.keyTable[i] = null;
/*  46 */       this.valueTable[i] = 0;
/*     */     } 
/*  48 */     this.elementSize = 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean containsKey(Object key) {
/*  56 */     int index = hashCode(key), length = this.keyTable.length;
/*  57 */     while (this.keyTable[index] != null) {
/*  58 */       if (this.keyTable[index] == key)
/*  59 */         return true; 
/*  60 */       if (++index == length) {
/*  61 */         index = 0;
/*     */       }
/*     */     } 
/*  64 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int get(Object key) {
/*  73 */     int index = hashCode(key), length = this.keyTable.length;
/*  74 */     while (this.keyTable[index] != null) {
/*  75 */       if (this.keyTable[index] == key)
/*  76 */         return this.valueTable[index]; 
/*  77 */       if (++index == length) {
/*  78 */         index = 0;
/*     */       }
/*     */     } 
/*  81 */     return -1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode(Object key) {
/*  90 */     return (key.hashCode() & Integer.MAX_VALUE) % this.keyTable.length;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int put(Object key, int value) {
/* 102 */     int index = hashCode(key), length = this.keyTable.length;
/* 103 */     while (this.keyTable[index] != null) {
/* 104 */       if (this.keyTable[index] == key) {
/* 105 */         this.valueTable[index] = value; return value;
/* 106 */       }  if (++index == length) {
/* 107 */         index = 0;
/*     */       }
/*     */     } 
/* 110 */     this.keyTable[index] = key;
/* 111 */     this.valueTable[index] = value;
/*     */ 
/*     */     
/* 114 */     if (++this.elementSize > this.threshold)
/* 115 */       rehash(); 
/* 116 */     return value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void rehash() {
/* 124 */     ObjectCache newHashtable = new ObjectCache(this.keyTable.length * 2);
/* 125 */     for (int i = this.keyTable.length; --i >= 0;) {
/* 126 */       if (this.keyTable[i] != null)
/* 127 */         newHashtable.put(this.keyTable[i], this.valueTable[i]); 
/*     */     } 
/* 129 */     this.keyTable = newHashtable.keyTable;
/* 130 */     this.valueTable = newHashtable.valueTable;
/* 131 */     this.threshold = newHashtable.threshold;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int size() {
/* 139 */     return this.elementSize;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 148 */     int max = size();
/* 149 */     StringBuilder buf = new StringBuilder();
/* 150 */     buf.append("{");
/* 151 */     for (int i = 0; i < max; i++) {
/* 152 */       if (this.keyTable[i] != null) {
/* 153 */         buf.append(this.keyTable[i]).append("->").append(this.valueTable[i]);
/*     */       }
/* 155 */       if (i < max) {
/* 156 */         buf.append(", ");
/*     */       }
/*     */     } 
/* 159 */     buf.append("}");
/* 160 */     return buf.toString();
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\codegen\ObjectCache.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */