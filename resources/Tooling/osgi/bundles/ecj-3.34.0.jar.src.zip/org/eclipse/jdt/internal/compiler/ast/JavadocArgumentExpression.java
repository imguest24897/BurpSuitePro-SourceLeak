/*     */ package org.eclipse.jdt.internal.compiler.ast;
/*     */ 
/*     */ import org.eclipse.jdt.internal.compiler.ASTVisitor;
/*     */ import org.eclipse.jdt.internal.compiler.impl.Constant;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.BlockScope;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.ClassScope;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.ReferenceBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.Scope;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.TypeBinding;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JavadocArgumentExpression
/*     */   extends Expression
/*     */ {
/*     */   public char[] token;
/*     */   public Argument argument;
/*     */   
/*     */   public JavadocArgumentExpression(char[] name, int startPos, int endPos, TypeReference typeRef) {
/*  26 */     this.token = name;
/*  27 */     this.sourceStart = startPos;
/*  28 */     this.sourceEnd = endPos;
/*  29 */     long pos = (startPos << 32L) + endPos;
/*  30 */     this.argument = new Argument(name, pos, typeRef, 0);
/*  31 */     this.bits |= 0x8000;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private TypeBinding internalResolveType(Scope scope) {
/*  38 */     this.constant = Constant.NotAConstant;
/*  39 */     if (this.resolvedType != null) {
/*  40 */       return this.resolvedType.isValidBinding() ? this.resolvedType : null;
/*     */     }
/*  42 */     if (this.argument != null) {
/*  43 */       TypeReference typeRef = this.argument.type;
/*  44 */       if (typeRef != null) {
/*  45 */         this.resolvedType = typeRef.getTypeBinding(scope);
/*  46 */         typeRef.resolvedType = this.resolvedType;
/*     */ 
/*     */         
/*  49 */         if (this.resolvedType == null) {
/*  50 */           return null;
/*     */         }
/*  52 */         if (typeRef instanceof SingleTypeReference && 
/*  53 */           this.resolvedType.leafComponentType().enclosingType() != null && 
/*  54 */           (scope.compilerOptions()).complianceLevel <= 3145728L) {
/*  55 */           scope.problemReporter().javadocInvalidMemberTypeQualification(this.sourceStart, this.sourceEnd, scope.getDeclarationModifiers());
/*     */         
/*     */         }
/*  58 */         else if (typeRef instanceof QualifiedTypeReference) {
/*  59 */           ReferenceBinding referenceBinding = this.resolvedType.leafComponentType().enclosingType();
/*  60 */           if (referenceBinding != null) {
/*     */ 
/*     */             
/*  63 */             int compoundLength = 2;
/*  64 */             for (; (referenceBinding = referenceBinding.enclosingType()) != null; compoundLength++);
/*  65 */             int typeNameLength = (typeRef.getTypeName()).length;
/*  66 */             if (typeNameLength != compoundLength && typeNameLength != compoundLength + (this.resolvedType.getPackage()).compoundName.length) {
/*  67 */               scope.problemReporter().javadocInvalidMemberTypeQualification(typeRef.sourceStart, typeRef.sourceEnd, scope.getDeclarationModifiers());
/*     */             }
/*     */           } 
/*     */         } 
/*  71 */         if (!this.resolvedType.isValidBinding()) {
/*  72 */           scope.problemReporter().javadocInvalidType(typeRef, this.resolvedType, scope.getDeclarationModifiers());
/*  73 */           return null;
/*     */         } 
/*  75 */         if (isTypeUseDeprecated(this.resolvedType, scope)) {
/*  76 */           scope.problemReporter().javadocDeprecatedType(this.resolvedType, typeRef, scope.getDeclarationModifiers());
/*     */         }
/*  78 */         return this.resolvedType = scope.environment().convertToRawType(this.resolvedType, true);
/*     */       } 
/*     */     } 
/*  81 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public StringBuffer printExpression(int indent, StringBuffer output) {
/*  86 */     if (this.argument == null) {
/*  87 */       if (this.token != null) {
/*  88 */         output.append(this.token);
/*     */       }
/*     */     } else {
/*     */       
/*  92 */       this.argument.print(indent, output);
/*     */     } 
/*  94 */     return output;
/*     */   }
/*     */ 
/*     */   
/*     */   public void resolve(BlockScope scope) {
/*  99 */     if (this.argument != null) {
/* 100 */       this.argument.resolve(scope);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public TypeBinding resolveType(BlockScope scope) {
/* 106 */     return internalResolveType((Scope)scope);
/*     */   }
/*     */ 
/*     */   
/*     */   public TypeBinding resolveType(ClassScope scope) {
/* 111 */     return internalResolveType((Scope)scope);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void traverse(ASTVisitor visitor, BlockScope blockScope) {
/* 120 */     if (visitor.visit(this, blockScope) && 
/* 121 */       this.argument != null) {
/* 122 */       this.argument.traverse(visitor, blockScope);
/*     */     }
/*     */     
/* 125 */     visitor.endVisit(this, blockScope);
/*     */   }
/*     */   
/*     */   public void traverse(ASTVisitor visitor, ClassScope blockScope) {
/* 129 */     if (visitor.visit(this, blockScope) && 
/* 130 */       this.argument != null) {
/* 131 */       this.argument.traverse(visitor, blockScope);
/*     */     }
/*     */     
/* 134 */     visitor.endVisit(this, blockScope);
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\ast\JavadocArgumentExpression.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */