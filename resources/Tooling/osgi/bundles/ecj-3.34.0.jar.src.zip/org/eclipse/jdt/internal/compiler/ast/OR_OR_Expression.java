/*     */ package org.eclipse.jdt.internal.compiler.ast;
/*     */ 
/*     */ import org.eclipse.jdt.internal.compiler.ASTVisitor;
/*     */ import org.eclipse.jdt.internal.compiler.codegen.BranchLabel;
/*     */ import org.eclipse.jdt.internal.compiler.codegen.CodeStream;
/*     */ import org.eclipse.jdt.internal.compiler.flow.FlowContext;
/*     */ import org.eclipse.jdt.internal.compiler.flow.FlowInfo;
/*     */ import org.eclipse.jdt.internal.compiler.flow.UnconditionalFlowInfo;
/*     */ import org.eclipse.jdt.internal.compiler.impl.Constant;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.Binding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.BlockScope;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.LocalVariableBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.Scope;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.TypeBinding;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class OR_OR_Expression
/*     */   extends BinaryExpression
/*     */ {
/*  31 */   int rightInitStateIndex = -1;
/*  32 */   int mergedInitStateIndex = -1;
/*     */   
/*     */   public OR_OR_Expression(Expression left, Expression right, int operator) {
/*  35 */     super(left, right, operator);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public FlowInfo analyseCode(BlockScope currentScope, FlowContext flowContext, FlowInfo flowInfo) {
/*  44 */     Constant cst = this.left.optimizedBooleanConstant();
/*  45 */     boolean isLeftOptimizedTrue = (cst != Constant.NotAConstant && cst.booleanValue());
/*  46 */     boolean isLeftOptimizedFalse = (cst != Constant.NotAConstant && !cst.booleanValue());
/*     */     
/*  48 */     if (isLeftOptimizedFalse) {
/*     */ 
/*     */ 
/*     */       
/*  52 */       UnconditionalFlowInfo unconditionalFlowInfo1 = this.left.analyseCode(currentScope, flowContext, flowInfo).unconditionalInits();
/*  53 */       flowContext.expireNullCheckedFieldInfo();
/*  54 */       FlowInfo flowInfo2 = this.right.analyseCode(currentScope, flowContext, (FlowInfo)unconditionalFlowInfo1);
/*  55 */       flowContext.expireNullCheckedFieldInfo();
/*  56 */       this.mergedInitStateIndex = 
/*  57 */         currentScope.methodScope().recordInitializationStates(flowInfo2);
/*  58 */       return flowInfo2;
/*     */     } 
/*     */     
/*  61 */     FlowInfo leftInfo = this.left.analyseCode(currentScope, flowContext, flowInfo);
/*  62 */     if ((flowContext.tagBits & 0x4) == 0) {
/*  63 */       flowContext.expireNullCheckedFieldInfo();
/*     */     }
/*     */ 
/*     */     
/*  67 */     UnconditionalFlowInfo unconditionalFlowInfo = leftInfo.initsWhenFalse().unconditionalCopy();
/*  68 */     this.rightInitStateIndex = 
/*  69 */       currentScope.methodScope().recordInitializationStates((FlowInfo)unconditionalFlowInfo);
/*     */     
/*  71 */     int previousMode = unconditionalFlowInfo.reachMode();
/*  72 */     if (isLeftOptimizedTrue && (
/*  73 */       unconditionalFlowInfo.reachMode() & 0x3) == 0) {
/*  74 */       currentScope.problemReporter().fakeReachable(this.right);
/*  75 */       unconditionalFlowInfo.setReachMode(1);
/*     */     } 
/*     */     
/*  78 */     this.left.updateFlowOnBooleanResult((FlowInfo)unconditionalFlowInfo, false);
/*  79 */     FlowInfo flowInfo1 = this.right.analyseCode(currentScope, flowContext, (FlowInfo)unconditionalFlowInfo);
/*  80 */     if ((flowContext.tagBits & 0x4) == 0)
/*  81 */       flowContext.expireNullCheckedFieldInfo(); 
/*  82 */     this.left.checkNPEbyUnboxing(currentScope, flowContext, flowInfo);
/*  83 */     this.right.checkNPEbyUnboxing(currentScope, flowContext, leftInfo.initsWhenFalse());
/*     */ 
/*     */     
/*  86 */     FlowInfo leftInfoWhenTrueForMerging = leftInfo.initsWhenTrue().unconditionalCopy().addPotentialInitializationsFrom((FlowInfo)flowInfo1.unconditionalInitsWithoutSideEffect());
/*  87 */     FlowInfo mergedInfo = FlowInfo.conditional(
/*     */         
/*  89 */         (FlowInfo)leftInfoWhenTrueForMerging.unconditionalInits().mergedWith(
/*  90 */           flowInfo1.safeInitsWhenTrue().setReachMode(previousMode).unconditionalInits()), 
/*  91 */         flowInfo1.initsWhenFalse());
/*  92 */     this.mergedInitStateIndex = 
/*  93 */       currentScope.methodScope().recordInitializationStates(mergedInfo);
/*  94 */     return mergedInfo;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void generateCode(BlockScope currentScope, CodeStream codeStream, boolean valueRequired) {
/*     */     // Byte code:
/*     */     //   0: aload_2
/*     */     //   1: getfield position : I
/*     */     //   4: istore #4
/*     */     //   6: aload_0
/*     */     //   7: getfield constant : Lorg/eclipse/jdt/internal/compiler/impl/Constant;
/*     */     //   10: getstatic org/eclipse/jdt/internal/compiler/impl/Constant.NotAConstant : Lorg/eclipse/jdt/internal/compiler/impl/Constant;
/*     */     //   13: if_acmpeq -> 43
/*     */     //   16: iload_3
/*     */     //   17: ifeq -> 32
/*     */     //   20: aload_2
/*     */     //   21: aload_0
/*     */     //   22: getfield constant : Lorg/eclipse/jdt/internal/compiler/impl/Constant;
/*     */     //   25: aload_0
/*     */     //   26: getfield implicitConversion : I
/*     */     //   29: invokevirtual generateConstant : (Lorg/eclipse/jdt/internal/compiler/impl/Constant;I)V
/*     */     //   32: aload_2
/*     */     //   33: iload #4
/*     */     //   35: aload_0
/*     */     //   36: getfield sourceStart : I
/*     */     //   39: invokevirtual recordPositionsFrom : (II)V
/*     */     //   42: return
/*     */     //   43: aload_0
/*     */     //   44: getfield right : Lorg/eclipse/jdt/internal/compiler/ast/Expression;
/*     */     //   47: getfield constant : Lorg/eclipse/jdt/internal/compiler/impl/Constant;
/*     */     //   50: astore #5
/*     */     //   52: aload #5
/*     */     //   54: getstatic org/eclipse/jdt/internal/compiler/impl/Constant.NotAConstant : Lorg/eclipse/jdt/internal/compiler/impl/Constant;
/*     */     //   57: if_acmpeq -> 135
/*     */     //   60: aload #5
/*     */     //   62: invokevirtual booleanValue : ()Z
/*     */     //   65: ifeq -> 89
/*     */     //   68: aload_0
/*     */     //   69: getfield left : Lorg/eclipse/jdt/internal/compiler/ast/Expression;
/*     */     //   72: aload_1
/*     */     //   73: aload_2
/*     */     //   74: iconst_0
/*     */     //   75: invokevirtual generateCode : (Lorg/eclipse/jdt/internal/compiler/lookup/BlockScope;Lorg/eclipse/jdt/internal/compiler/codegen/CodeStream;Z)V
/*     */     //   78: iload_3
/*     */     //   79: ifeq -> 99
/*     */     //   82: aload_2
/*     */     //   83: invokevirtual iconst_1 : ()V
/*     */     //   86: goto -> 99
/*     */     //   89: aload_0
/*     */     //   90: getfield left : Lorg/eclipse/jdt/internal/compiler/ast/Expression;
/*     */     //   93: aload_1
/*     */     //   94: aload_2
/*     */     //   95: iload_3
/*     */     //   96: invokevirtual generateCode : (Lorg/eclipse/jdt/internal/compiler/lookup/BlockScope;Lorg/eclipse/jdt/internal/compiler/codegen/CodeStream;Z)V
/*     */     //   99: aload_0
/*     */     //   100: getfield mergedInitStateIndex : I
/*     */     //   103: iconst_m1
/*     */     //   104: if_icmpeq -> 116
/*     */     //   107: aload_2
/*     */     //   108: aload_1
/*     */     //   109: aload_0
/*     */     //   110: getfield mergedInitStateIndex : I
/*     */     //   113: invokevirtual removeNotDefinitelyAssignedVariables : (Lorg/eclipse/jdt/internal/compiler/lookup/Scope;I)V
/*     */     //   116: aload_2
/*     */     //   117: aload_0
/*     */     //   118: getfield implicitConversion : I
/*     */     //   121: invokevirtual generateImplicitConversion : (I)V
/*     */     //   124: aload_2
/*     */     //   125: iload #4
/*     */     //   127: aload_0
/*     */     //   128: getfield sourceStart : I
/*     */     //   131: invokevirtual recordPositionsFrom : (II)V
/*     */     //   134: return
/*     */     //   135: new org/eclipse/jdt/internal/compiler/codegen/BranchLabel
/*     */     //   138: dup
/*     */     //   139: aload_2
/*     */     //   140: invokespecial <init> : (Lorg/eclipse/jdt/internal/compiler/codegen/CodeStream;)V
/*     */     //   143: astore #6
/*     */     //   145: aload_0
/*     */     //   146: getfield left : Lorg/eclipse/jdt/internal/compiler/ast/Expression;
/*     */     //   149: invokevirtual optimizedBooleanConstant : ()Lorg/eclipse/jdt/internal/compiler/impl/Constant;
/*     */     //   152: astore #5
/*     */     //   154: aload #5
/*     */     //   156: getstatic org/eclipse/jdt/internal/compiler/impl/Constant.NotAConstant : Lorg/eclipse/jdt/internal/compiler/impl/Constant;
/*     */     //   159: if_acmpeq -> 166
/*     */     //   162: iconst_1
/*     */     //   163: goto -> 167
/*     */     //   166: iconst_0
/*     */     //   167: istore #8
/*     */     //   169: iload #8
/*     */     //   171: ifeq -> 186
/*     */     //   174: aload #5
/*     */     //   176: invokevirtual booleanValue : ()Z
/*     */     //   179: ifeq -> 186
/*     */     //   182: iconst_1
/*     */     //   183: goto -> 187
/*     */     //   186: iconst_0
/*     */     //   187: istore #9
/*     */     //   189: aload_0
/*     */     //   190: getfield right : Lorg/eclipse/jdt/internal/compiler/ast/Expression;
/*     */     //   193: invokevirtual optimizedBooleanConstant : ()Lorg/eclipse/jdt/internal/compiler/impl/Constant;
/*     */     //   196: astore #5
/*     */     //   198: aload #5
/*     */     //   200: getstatic org/eclipse/jdt/internal/compiler/impl/Constant.NotAConstant : Lorg/eclipse/jdt/internal/compiler/impl/Constant;
/*     */     //   203: if_acmpeq -> 210
/*     */     //   206: iconst_1
/*     */     //   207: goto -> 211
/*     */     //   210: iconst_0
/*     */     //   211: istore #10
/*     */     //   213: iload #10
/*     */     //   215: ifeq -> 230
/*     */     //   218: aload #5
/*     */     //   220: invokevirtual booleanValue : ()Z
/*     */     //   223: ifeq -> 230
/*     */     //   226: iconst_1
/*     */     //   227: goto -> 231
/*     */     //   230: iconst_0
/*     */     //   231: istore #11
/*     */     //   233: iload #8
/*     */     //   235: ifeq -> 256
/*     */     //   238: aload_0
/*     */     //   239: getfield left : Lorg/eclipse/jdt/internal/compiler/ast/Expression;
/*     */     //   242: aload_1
/*     */     //   243: aload_2
/*     */     //   244: iconst_0
/*     */     //   245: invokevirtual generateCode : (Lorg/eclipse/jdt/internal/compiler/lookup/BlockScope;Lorg/eclipse/jdt/internal/compiler/codegen/CodeStream;Z)V
/*     */     //   248: iload #9
/*     */     //   250: ifeq -> 269
/*     */     //   253: goto -> 317
/*     */     //   256: aload_0
/*     */     //   257: getfield left : Lorg/eclipse/jdt/internal/compiler/ast/Expression;
/*     */     //   260: aload_1
/*     */     //   261: aload_2
/*     */     //   262: aload #6
/*     */     //   264: aconst_null
/*     */     //   265: iconst_1
/*     */     //   266: invokevirtual generateOptimizedBoolean : (Lorg/eclipse/jdt/internal/compiler/lookup/BlockScope;Lorg/eclipse/jdt/internal/compiler/codegen/CodeStream;Lorg/eclipse/jdt/internal/compiler/codegen/BranchLabel;Lorg/eclipse/jdt/internal/compiler/codegen/BranchLabel;Z)V
/*     */     //   269: aload_0
/*     */     //   270: getfield rightInitStateIndex : I
/*     */     //   273: iconst_m1
/*     */     //   274: if_icmpeq -> 286
/*     */     //   277: aload_2
/*     */     //   278: aload_1
/*     */     //   279: aload_0
/*     */     //   280: getfield rightInitStateIndex : I
/*     */     //   283: invokevirtual addDefinitelyAssignedVariables : (Lorg/eclipse/jdt/internal/compiler/lookup/Scope;I)V
/*     */     //   286: iload #10
/*     */     //   288: ifeq -> 304
/*     */     //   291: aload_0
/*     */     //   292: getfield right : Lorg/eclipse/jdt/internal/compiler/ast/Expression;
/*     */     //   295: aload_1
/*     */     //   296: aload_2
/*     */     //   297: iconst_0
/*     */     //   298: invokevirtual generateCode : (Lorg/eclipse/jdt/internal/compiler/lookup/BlockScope;Lorg/eclipse/jdt/internal/compiler/codegen/CodeStream;Z)V
/*     */     //   301: goto -> 317
/*     */     //   304: aload_0
/*     */     //   305: getfield right : Lorg/eclipse/jdt/internal/compiler/ast/Expression;
/*     */     //   308: aload_1
/*     */     //   309: aload_2
/*     */     //   310: aload #6
/*     */     //   312: aconst_null
/*     */     //   313: iload_3
/*     */     //   314: invokevirtual generateOptimizedBoolean : (Lorg/eclipse/jdt/internal/compiler/lookup/BlockScope;Lorg/eclipse/jdt/internal/compiler/codegen/CodeStream;Lorg/eclipse/jdt/internal/compiler/codegen/BranchLabel;Lorg/eclipse/jdt/internal/compiler/codegen/BranchLabel;Z)V
/*     */     //   317: aload_0
/*     */     //   318: getfield mergedInitStateIndex : I
/*     */     //   321: iconst_m1
/*     */     //   322: if_icmpeq -> 334
/*     */     //   325: aload_2
/*     */     //   326: aload_1
/*     */     //   327: aload_0
/*     */     //   328: getfield mergedInitStateIndex : I
/*     */     //   331: invokevirtual removeNotDefinitelyAssignedVariables : (Lorg/eclipse/jdt/internal/compiler/lookup/Scope;I)V
/*     */     //   334: iload_3
/*     */     //   335: ifeq -> 514
/*     */     //   338: iload #8
/*     */     //   340: ifeq -> 370
/*     */     //   343: iload #9
/*     */     //   345: ifeq -> 370
/*     */     //   348: aload_2
/*     */     //   349: invokevirtual iconst_1 : ()V
/*     */     //   352: aload_2
/*     */     //   353: aload_2
/*     */     //   354: getfield position : I
/*     */     //   357: aload_0
/*     */     //   358: getfield left : Lorg/eclipse/jdt/internal/compiler/ast/Expression;
/*     */     //   361: getfield sourceEnd : I
/*     */     //   364: invokevirtual recordPositionsFrom : (II)V
/*     */     //   367: goto -> 491
/*     */     //   370: iload #10
/*     */     //   372: ifeq -> 402
/*     */     //   375: iload #11
/*     */     //   377: ifeq -> 402
/*     */     //   380: aload_2
/*     */     //   381: invokevirtual iconst_1 : ()V
/*     */     //   384: aload_2
/*     */     //   385: aload_2
/*     */     //   386: getfield position : I
/*     */     //   389: aload_0
/*     */     //   390: getfield left : Lorg/eclipse/jdt/internal/compiler/ast/Expression;
/*     */     //   393: getfield sourceEnd : I
/*     */     //   396: invokevirtual recordPositionsFrom : (II)V
/*     */     //   399: goto -> 406
/*     */     //   402: aload_2
/*     */     //   403: invokevirtual iconst_0 : ()V
/*     */     //   406: aload #6
/*     */     //   408: invokevirtual forwardReferenceCount : ()I
/*     */     //   411: ifle -> 486
/*     */     //   414: aload_0
/*     */     //   415: getfield bits : I
/*     */     //   418: bipush #16
/*     */     //   420: iand
/*     */     //   421: ifeq -> 449
/*     */     //   424: aload_2
/*     */     //   425: aload_0
/*     */     //   426: getfield implicitConversion : I
/*     */     //   429: invokevirtual generateImplicitConversion : (I)V
/*     */     //   432: aload_2
/*     */     //   433: aload_0
/*     */     //   434: invokevirtual generateReturnBytecode : (Lorg/eclipse/jdt/internal/compiler/ast/Expression;)V
/*     */     //   437: aload #6
/*     */     //   439: invokevirtual place : ()V
/*     */     //   442: aload_2
/*     */     //   443: invokevirtual iconst_1 : ()V
/*     */     //   446: goto -> 491
/*     */     //   449: aload_2
/*     */     //   450: new org/eclipse/jdt/internal/compiler/codegen/BranchLabel
/*     */     //   453: dup
/*     */     //   454: aload_2
/*     */     //   455: invokespecial <init> : (Lorg/eclipse/jdt/internal/compiler/codegen/CodeStream;)V
/*     */     //   458: dup
/*     */     //   459: astore #7
/*     */     //   461: invokevirtual goto_ : (Lorg/eclipse/jdt/internal/compiler/codegen/BranchLabel;)V
/*     */     //   464: aload_2
/*     */     //   465: iconst_1
/*     */     //   466: invokevirtual decrStackSize : (I)V
/*     */     //   469: aload #6
/*     */     //   471: invokevirtual place : ()V
/*     */     //   474: aload_2
/*     */     //   475: invokevirtual iconst_1 : ()V
/*     */     //   478: aload #7
/*     */     //   480: invokevirtual place : ()V
/*     */     //   483: goto -> 491
/*     */     //   486: aload #6
/*     */     //   488: invokevirtual place : ()V
/*     */     //   491: aload_2
/*     */     //   492: aload_0
/*     */     //   493: getfield implicitConversion : I
/*     */     //   496: invokevirtual generateImplicitConversion : (I)V
/*     */     //   499: aload_2
/*     */     //   500: aload_2
/*     */     //   501: getfield position : I
/*     */     //   504: aload_0
/*     */     //   505: getfield sourceEnd : I
/*     */     //   508: invokevirtual recordPositionsFrom : (II)V
/*     */     //   511: goto -> 519
/*     */     //   514: aload #6
/*     */     //   516: invokevirtual place : ()V
/*     */     //   519: return
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #102	-> 0
/*     */     //   #103	-> 6
/*     */     //   #105	-> 16
/*     */     //   #106	-> 20
/*     */     //   #107	-> 32
/*     */     //   #108	-> 42
/*     */     //   #110	-> 43
/*     */     //   #111	-> 52
/*     */     //   #113	-> 60
/*     */     //   #114	-> 68
/*     */     //   #115	-> 78
/*     */     //   #116	-> 86
/*     */     //   #118	-> 89
/*     */     //   #120	-> 99
/*     */     //   #121	-> 107
/*     */     //   #123	-> 116
/*     */     //   #124	-> 124
/*     */     //   #125	-> 134
/*     */     //   #128	-> 135
/*     */     //   #129	-> 145
/*     */     //   #130	-> 154
/*     */     //   #131	-> 169
/*     */     //   #133	-> 189
/*     */     //   #134	-> 198
/*     */     //   #135	-> 213
/*     */     //   #138	-> 233
/*     */     //   #139	-> 238
/*     */     //   #140	-> 248
/*     */     //   #141	-> 253
/*     */     //   #144	-> 256
/*     */     //   #147	-> 269
/*     */     //   #148	-> 277
/*     */     //   #150	-> 286
/*     */     //   #151	-> 291
/*     */     //   #152	-> 301
/*     */     //   #153	-> 304
/*     */     //   #156	-> 317
/*     */     //   #157	-> 325
/*     */     //   #164	-> 334
/*     */     //   #165	-> 338
/*     */     //   #166	-> 348
/*     */     //   #167	-> 352
/*     */     //   #168	-> 367
/*     */     //   #169	-> 370
/*     */     //   #170	-> 380
/*     */     //   #171	-> 384
/*     */     //   #172	-> 399
/*     */     //   #173	-> 402
/*     */     //   #175	-> 406
/*     */     //   #176	-> 414
/*     */     //   #177	-> 424
/*     */     //   #178	-> 432
/*     */     //   #179	-> 437
/*     */     //   #180	-> 442
/*     */     //   #181	-> 446
/*     */     //   #182	-> 449
/*     */     //   #183	-> 464
/*     */     //   #184	-> 469
/*     */     //   #185	-> 474
/*     */     //   #186	-> 478
/*     */     //   #188	-> 483
/*     */     //   #189	-> 486
/*     */     //   #192	-> 491
/*     */     //   #193	-> 499
/*     */     //   #194	-> 511
/*     */     //   #195	-> 514
/*     */     //   #197	-> 519
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	descriptor
/*     */     //   0	520	0	this	Lorg/eclipse/jdt/internal/compiler/ast/OR_OR_Expression;
/*     */     //   0	520	1	currentScope	Lorg/eclipse/jdt/internal/compiler/lookup/BlockScope;
/*     */     //   0	520	2	codeStream	Lorg/eclipse/jdt/internal/compiler/codegen/CodeStream;
/*     */     //   0	520	3	valueRequired	Z
/*     */     //   6	514	4	pc	I
/*     */     //   52	468	5	cst	Lorg/eclipse/jdt/internal/compiler/impl/Constant;
/*     */     //   145	375	6	trueLabel	Lorg/eclipse/jdt/internal/compiler/codegen/BranchLabel;
/*     */     //   461	22	7	endLabel	Lorg/eclipse/jdt/internal/compiler/codegen/BranchLabel;
/*     */     //   169	351	8	leftIsConst	Z
/*     */     //   189	331	9	leftIsTrue	Z
/*     */     //   213	307	10	rightIsConst	Z
/*     */     //   233	287	11	rightIsTrue	Z
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void generateOptimizedBoolean(BlockScope currentScope, CodeStream codeStream, BranchLabel trueLabel, BranchLabel falseLabel, boolean valueRequired) {
/* 204 */     if (this.constant != Constant.NotAConstant) {
/* 205 */       super.generateOptimizedBoolean(currentScope, codeStream, trueLabel, falseLabel, valueRequired);
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/* 210 */     Constant cst = this.right.constant;
/* 211 */     if (cst != Constant.NotAConstant && !cst.booleanValue()) {
/* 212 */       int pc = codeStream.position;
/* 213 */       this.left.generateOptimizedBoolean(currentScope, codeStream, trueLabel, falseLabel, valueRequired);
/* 214 */       if (this.mergedInitStateIndex != -1) {
/* 215 */         codeStream.removeNotDefinitelyAssignedVariables((Scope)currentScope, this.mergedInitStateIndex);
/*     */       }
/* 217 */       codeStream.recordPositionsFrom(pc, this.sourceStart);
/*     */       
/*     */       return;
/*     */     } 
/* 221 */     cst = this.left.optimizedBooleanConstant();
/* 222 */     boolean leftIsConst = (cst != Constant.NotAConstant);
/* 223 */     boolean leftIsTrue = (leftIsConst && cst.booleanValue());
/*     */     
/* 225 */     cst = this.right.optimizedBooleanConstant();
/* 226 */     boolean rightIsConst = (cst != Constant.NotAConstant);
/* 227 */     boolean rightIsTrue = (rightIsConst && cst.booleanValue());
/*     */ 
/*     */ 
/*     */     
/* 231 */     if (falseLabel == null) {
/* 232 */       if (trueLabel != null) {
/*     */         
/* 234 */         this.left.generateOptimizedBoolean(currentScope, codeStream, trueLabel, (BranchLabel)null, !leftIsConst);
/*     */         
/* 236 */         if (leftIsTrue) {
/* 237 */           if (valueRequired) codeStream.goto_(trueLabel); 
/* 238 */           codeStream.recordPositionsFrom(codeStream.position, this.left.sourceEnd);
/*     */         } else {
/*     */           
/* 241 */           if (this.rightInitStateIndex != -1) {
/* 242 */             codeStream.addDefinitelyAssignedVariables((Scope)currentScope, this.rightInitStateIndex);
/*     */           }
/* 244 */           this.right.generateOptimizedBoolean(currentScope, codeStream, trueLabel, (BranchLabel)null, (valueRequired && !rightIsConst));
/* 245 */           if (valueRequired && rightIsTrue) {
/* 246 */             codeStream.goto_(trueLabel);
/* 247 */             codeStream.recordPositionsFrom(codeStream.position, this.sourceEnd);
/*     */           }
/*     */         
/*     */         } 
/*     */       } 
/* 252 */     } else if (trueLabel == null) {
/* 253 */       BranchLabel internalTrueLabel = new BranchLabel(codeStream);
/* 254 */       this.left.generateOptimizedBoolean(currentScope, codeStream, internalTrueLabel, (BranchLabel)null, !leftIsConst);
/*     */       
/* 256 */       if (leftIsTrue) {
/* 257 */         internalTrueLabel.place();
/*     */       } else {
/*     */         
/* 260 */         if (this.rightInitStateIndex != -1) {
/* 261 */           codeStream
/* 262 */             .addDefinitelyAssignedVariables((Scope)currentScope, this.rightInitStateIndex);
/*     */         }
/* 264 */         this.right.generateOptimizedBoolean(currentScope, codeStream, (BranchLabel)null, falseLabel, (valueRequired && !rightIsConst));
/* 265 */         int pc = codeStream.position;
/* 266 */         if (valueRequired && rightIsConst && !rightIsTrue) {
/* 267 */           codeStream.goto_(falseLabel);
/* 268 */           codeStream.recordPositionsFrom(pc, this.sourceEnd);
/*     */         } 
/* 270 */         internalTrueLabel.place();
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 276 */     if (this.mergedInitStateIndex != -1) {
/* 277 */       codeStream.removeNotDefinitelyAssignedVariables((Scope)currentScope, this.mergedInitStateIndex);
/*     */     }
/*     */   }
/*     */   
/*     */   public void collectPatternVariablesToScope(LocalVariableBinding[] variables, BlockScope scope) {
/* 282 */     LocalVariableBinding[] temp = variables;
/* 283 */     this.left.collectPatternVariablesToScope(variables, scope);
/*     */ 
/*     */     
/* 286 */     variables = this.left.getPatternVariablesWhenFalse();
/* 287 */     addPatternVariablesWhenFalse(variables);
/*     */     
/* 289 */     int length = ((variables == null) ? 0 : variables.length) + ((temp == null) ? 0 : temp.length);
/* 290 */     LocalVariableBinding[] newArray = new LocalVariableBinding[length];
/* 291 */     if (variables != null) {
/* 292 */       System.arraycopy(variables, 0, newArray, 0, variables.length);
/*     */     }
/* 294 */     if (temp != null) {
/* 295 */       System.arraycopy(temp, 0, newArray, (variables == null) ? 0 : variables.length, temp.length);
/*     */     }
/* 297 */     this.right.collectPatternVariablesToScope(newArray, scope);
/* 298 */     variables = this.right.getPatternVariablesWhenFalse();
/* 299 */     addPatternVariablesWhenFalse(variables);
/*     */ 
/*     */ 
/*     */     
/* 303 */     variables = this.left.getPatternVariablesWhenTrue();
/* 304 */     this.right.addPatternVariablesWhenFalse(variables);
/*     */     
/* 306 */     variables = this.left.getPatternVariablesWhenFalse();
/* 307 */     this.right.addPatternVariablesWhenTrue(variables);
/*     */   }
/*     */   
/*     */   public boolean isCompactableOperation() {
/* 311 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TypeBinding resolveType(BlockScope scope) {
/* 319 */     TypeBinding result = super.resolveType(scope);
/*     */     
/* 321 */     Binding leftDirect = Expression.getDirectBinding(this.left);
/* 322 */     if (leftDirect != null && leftDirect == Expression.getDirectBinding(this.right) && 
/* 323 */       !(this.right instanceof Assignment)) {
/* 324 */       scope.problemReporter().comparingIdenticalExpressions(this);
/*     */     }
/* 326 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   public void traverse(ASTVisitor visitor, BlockScope scope) {
/* 331 */     if (visitor.visit(this, scope)) {
/* 332 */       this.left.traverse(visitor, scope);
/* 333 */       this.right.traverse(visitor, scope);
/*     */     } 
/* 335 */     visitor.endVisit(this, scope);
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\ast\OR_OR_Expression.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */