/*     */ package org.eclipse.jdt.internal.compiler.env;
/*     */ 
/*     */ import java.util.jar.Manifest;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public interface IModule
/*     */ {
/*  22 */   public static final IModuleReference[] NO_MODULE_REFS = new IModuleReference[0];
/*  23 */   public static final IPackageExport[] NO_EXPORTS = new IPackageExport[0];
/*  24 */   public static final char[][] NO_USES = new char[0][];
/*  25 */   public static final IService[] NO_PROVIDES = new IService[0];
/*  26 */   public static final IModule[] NO_MODULES = new IModule[0];
/*  27 */   public static final IPackageExport[] NO_OPENS = new IPackageExport[0];
/*     */   
/*     */   public static final String MODULE_INFO = "module-info";
/*     */   public static final String MODULE_INFO_JAVA = "module-info.java";
/*     */   public static final String MODULE_INFO_CLASS = "module-info.class";
/*     */   
/*     */   char[] name();
/*     */   
/*     */   IModuleReference[] requires();
/*     */   
/*     */   IPackageExport[] exports();
/*     */   
/*     */   char[][] uses();
/*     */   
/*     */   IService[] provides();
/*     */   
/*     */   IPackageExport[] opens();
/*     */   
/*     */   public static interface IModuleReference
/*     */   {
/*     */     char[] name();
/*     */     
/*     */     int getModifiers();
/*     */     
/*     */     default boolean isTransitive() {
/*  52 */       return ((getModifiers() & 0x20) != 0);
/*     */     }
/*     */     
/*     */     default boolean isStatic() {
/*  56 */       return ((getModifiers() & 0x40) != 0);
/*     */     }
/*     */   }
/*     */   
/*     */   public static interface IPackageExport {
/*     */     char[] name();
/*     */     
/*     */     default boolean isQualified() {
/*  64 */       char[][] targets = targets();
/*  65 */       return (targets != null && targets.length > 0);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     char[][] targets();
/*     */   }
/*     */ 
/*     */   
/*     */   default boolean isAutomatic() {
/*  75 */     return false;
/*     */   }
/*     */   default boolean isAutoNameFromManifest() {
/*  78 */     return false;
/*     */   }
/*     */   
/*     */   boolean isOpen();
/*     */   
/*     */   static IModule createAutomatic(char[] moduleName, boolean fromManifest) {
/*     */     final class AutoModule implements IModule { char[] name;
/*     */       boolean nameFromManifest;
/*     */       
/*     */       public AutoModule(char[] name, boolean nameFromManifest) {
/*  88 */         this.name = name;
/*  89 */         this.nameFromManifest = nameFromManifest;
/*     */       }
/*     */       
/*     */       public char[] name() {
/*  93 */         return this.name;
/*     */       }
/*     */ 
/*     */       
/*     */       public IModule.IModuleReference[] requires() {
/*  98 */         return IModule.NO_MODULE_REFS;
/*     */       }
/*     */ 
/*     */       
/*     */       public IModule.IPackageExport[] exports() {
/* 103 */         return IModule.NO_EXPORTS;
/*     */       }
/*     */ 
/*     */       
/*     */       public char[][] uses() {
/* 108 */         return IModule.NO_USES;
/*     */       }
/*     */ 
/*     */       
/*     */       public IModule.IService[] provides() {
/* 113 */         return IModule.NO_PROVIDES;
/*     */       }
/*     */ 
/*     */       
/*     */       public IModule.IPackageExport[] opens() {
/* 118 */         return NO_OPENS;
/*     */       }
/*     */ 
/*     */       
/*     */       public boolean isAutomatic() {
/* 123 */         return true;
/*     */       }
/*     */       
/*     */       public boolean isAutoNameFromManifest() {
/* 127 */         return this.nameFromManifest;
/*     */       }
/*     */       
/*     */       public boolean isOpen() {
/* 131 */         return false;
/*     */       } }
/*     */     ;
/* 134 */     return new AutoModule(moduleName, fromManifest);
/*     */   }
/*     */   
/*     */   static IModule createAutomatic(String fileName, boolean isFile, Manifest manifest) {
/* 138 */     boolean fromManifest = true;
/* 139 */     char[] inferredName = AutomaticModuleNaming.determineAutomaticModuleNameFromManifest(manifest);
/* 140 */     if (inferredName == null) {
/* 141 */       fromManifest = false;
/* 142 */       inferredName = AutomaticModuleNaming.determineAutomaticModuleNameFromFileName(fileName, true, isFile);
/*     */     } 
/* 144 */     return createAutomatic(inferredName, fromManifest);
/*     */   }
/*     */   
/*     */   public static interface IService {
/*     */     char[] name();
/*     */     
/*     */     char[][] with();
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\env\IModule.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */