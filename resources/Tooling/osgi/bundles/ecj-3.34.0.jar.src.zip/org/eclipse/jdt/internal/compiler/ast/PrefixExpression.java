/*    */ package org.eclipse.jdt.internal.compiler.ast;
/*    */ 
/*    */ import org.eclipse.jdt.internal.compiler.ASTVisitor;
/*    */ import org.eclipse.jdt.internal.compiler.lookup.BlockScope;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PrefixExpression
/*    */   extends CompoundAssignment
/*    */ {
/*    */   public PrefixExpression(Expression lhs, Expression expression, int operator, int pos) {
/* 28 */     super(lhs, expression, operator, lhs.sourceEnd);
/* 29 */     this.sourceStart = pos;
/* 30 */     this.sourceEnd = lhs.sourceEnd;
/*    */   }
/*    */   
/*    */   public boolean checkCastCompatibility() {
/* 34 */     return false;
/*    */   }
/*    */   
/*    */   public String operatorToString() {
/* 38 */     switch (this.operator) {
/*    */       case 14:
/* 40 */         return "++";
/*    */       case 13:
/* 42 */         return "--";
/*    */     } 
/* 44 */     return "unknown operator";
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public StringBuffer printExpressionNoParenthesis(int indent, StringBuffer output) {
/* 50 */     output.append(operatorToString()).append(' ');
/* 51 */     return this.lhs.printExpression(0, output);
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean restrainUsageToNumericTypes() {
/* 56 */     return true;
/*    */   }
/*    */ 
/*    */   
/*    */   public void traverse(ASTVisitor visitor, BlockScope scope) {
/* 61 */     if (visitor.visit(this, scope)) {
/* 62 */       this.lhs.traverse(visitor, scope);
/*    */     }
/* 64 */     visitor.endVisit(this, scope);
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\ast\PrefixExpression.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */