/*     */ package org.eclipse.jdt.internal.compiler.ast;
/*     */ 
/*     */ import org.eclipse.jdt.core.compiler.CharOperation;
/*     */ import org.eclipse.jdt.internal.compiler.ASTVisitor;
/*     */ import org.eclipse.jdt.internal.compiler.impl.CompilerOptions;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.Binding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.BlockScope;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.ClassScope;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.LookupEnvironment;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.PackageBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.ParameterizedTypeBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.ProblemReferenceBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.RawTypeBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.ReferenceBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.Scope;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.SplitPackageBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.TypeBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.TypeVariableBinding;
/*     */ import org.eclipse.jdt.internal.compiler.problem.AbortCompilation;
/*     */ 
/*     */ 
/*     */ public class QualifiedTypeReference
/*     */   extends TypeReference
/*     */ {
/*     */   public char[][] tokens;
/*     */   public long[] sourcePositions;
/*     */   
/*     */   public QualifiedTypeReference(char[][] sources, long[] poss) {
/*  29 */     this.tokens = sources;
/*  30 */     this.sourcePositions = poss;
/*  31 */     this.sourceStart = (int)(this.sourcePositions[0] >>> 32L);
/*  32 */     this.sourceEnd = (int)(this.sourcePositions[this.sourcePositions.length - 1] & 0xFFFFFFFFL);
/*     */   }
/*     */ 
/*     */   
/*     */   public TypeReference augmentTypeWithAdditionalDimensions(int additionalDimensions, Annotation[][] additionalAnnotations, boolean isVarargs) {
/*  37 */     int totalDimensions = dimensions() + additionalDimensions;
/*  38 */     Annotation[][] allAnnotations = getMergedAnnotationsOnDimensions(additionalDimensions, additionalAnnotations);
/*  39 */     ArrayQualifiedTypeReference arrayQualifiedTypeReference = new ArrayQualifiedTypeReference(this.tokens, totalDimensions, allAnnotations, this.sourcePositions);
/*  40 */     arrayQualifiedTypeReference.annotations = this.annotations;
/*  41 */     arrayQualifiedTypeReference.bits |= this.bits & 0x100000;
/*  42 */     if (!isVarargs)
/*  43 */       arrayQualifiedTypeReference.extendedDimensions = additionalDimensions; 
/*  44 */     return arrayQualifiedTypeReference;
/*     */   }
/*     */   
/*     */   protected TypeBinding findNextTypeBinding(int tokenIndex, Scope scope, PackageBinding packageBinding) {
/*  48 */     LookupEnvironment env = scope.environment();
/*     */     try {
/*  50 */       env.missingClassFileLocation = this;
/*  51 */       if (this.resolvedType == null) {
/*  52 */         this.resolvedType = scope.getType(this.tokens[tokenIndex], packageBinding);
/*     */       } else {
/*  54 */         this.resolvedType = (TypeBinding)scope.getMemberType(this.tokens[tokenIndex], (ReferenceBinding)this.resolvedType);
/*  55 */         if (!this.resolvedType.isValidBinding()) {
/*  56 */           this.resolvedType = (TypeBinding)new ProblemReferenceBinding(
/*  57 */               CharOperation.subarray(this.tokens, 0, tokenIndex + 1), 
/*  58 */               (ReferenceBinding)this.resolvedType.closestMatch(), 
/*  59 */               this.resolvedType.problemId());
/*     */         }
/*     */       } 
/*  62 */       return this.resolvedType;
/*  63 */     } catch (AbortCompilation e) {
/*  64 */       e.updateContext(this, (scope.referenceCompilationUnit()).compilationResult);
/*  65 */       throw e;
/*     */     } finally {
/*  67 */       env.missingClassFileLocation = null;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public char[] getLastToken() {
/*  73 */     return this.tokens[this.tokens.length - 1];
/*     */   }
/*     */ 
/*     */   
/*     */   protected void rejectAnnotationsOnPackageQualifiers(Scope scope, PackageBinding packageBinding) {
/*  78 */     if (packageBinding == null || this.annotations == null)
/*     */       return; 
/*  80 */     int i = packageBinding.compoundName.length;
/*  81 */     for (int j = 0; j < i; j++) {
/*  82 */       Annotation[] qualifierAnnot = this.annotations[j];
/*  83 */       if (qualifierAnnot != null && qualifierAnnot.length > 0) {
/*  84 */         if (j == 0) {
/*  85 */           for (int k = 0; k < qualifierAnnot.length; k++) {
/*  86 */             scope.problemReporter().typeAnnotationAtQualifiedName(qualifierAnnot[k]);
/*     */           }
/*     */         } else {
/*  89 */           scope.problemReporter().misplacedTypeAnnotations(qualifierAnnot[0], 
/*  90 */               qualifierAnnot[qualifierAnnot.length - 1]);
/*  91 */           this.annotations[j] = null;
/*     */         } 
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   protected static void rejectAnnotationsOnStaticMemberQualififer(Scope scope, ReferenceBinding currentType, Annotation[] qualifierAnnot) {
/*  99 */     if (currentType.isMemberType() && currentType.isStatic() && qualifierAnnot != null && qualifierAnnot.length > 0) {
/* 100 */       scope.problemReporter().illegalTypeAnnotationsInStaticMemberAccess(qualifierAnnot[0], 
/* 101 */           qualifierAnnot[qualifierAnnot.length - 1]);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected TypeBinding getTypeBinding(Scope scope) {
/* 108 */     if (this.resolvedType != null) {
/* 109 */       return this.resolvedType;
/*     */     }
/* 111 */     Binding binding = scope.getPackage(this.tokens);
/* 112 */     if (this.resolvedType != null) {
/* 113 */       return this.resolvedType;
/*     */     }
/* 115 */     if (binding != null && !binding.isValidBinding()) {
/* 116 */       if (binding instanceof ProblemReferenceBinding && binding.problemId() == 1) {
/* 117 */         ProblemReferenceBinding problemBinding = (ProblemReferenceBinding)binding;
/* 118 */         Binding pkg = scope.getTypeOrPackage(this.tokens);
/* 119 */         return (TypeBinding)new ProblemReferenceBinding(problemBinding.compoundName, (pkg instanceof PackageBinding) ? null : (ReferenceBinding)scope.environment().createMissingType(null, this.tokens), 1);
/*     */       } 
/* 121 */       return (TypeBinding)binding;
/*     */     } 
/* 123 */     PackageBinding packageBinding = (binding == null) ? null : (PackageBinding)binding;
/* 124 */     int typeStart = (packageBinding == null) ? 0 : packageBinding.compoundName.length;
/*     */     
/* 126 */     if (packageBinding != null) {
/* 127 */       PackageBinding uniquePackage = packageBinding.getVisibleFor(scope.module(), false);
/* 128 */       if (uniquePackage instanceof SplitPackageBinding) {
/* 129 */         CompilerOptions compilerOptions = scope.compilerOptions();
/* 130 */         boolean inJdtDebugCompileMode = compilerOptions.enableJdtDebugCompileMode;
/* 131 */         if (!inJdtDebugCompileMode) {
/* 132 */           SplitPackageBinding splitPackage = (SplitPackageBinding)uniquePackage;
/* 133 */           scope.problemReporter().conflictingPackagesFromModules(splitPackage, scope.module(), this.sourceStart, (int)this.sourcePositions[typeStart - 1]);
/* 134 */           this.resolvedType = (TypeBinding)new ProblemReferenceBinding(this.tokens, null, 3);
/* 135 */           return null;
/*     */         } 
/*     */       } 
/*     */     } 
/* 139 */     rejectAnnotationsOnPackageQualifiers(scope, packageBinding);
/*     */     
/* 141 */     boolean isClassScope = (scope.kind == 3);
/* 142 */     ReferenceBinding qualifiedType = null;
/* 143 */     for (int i = typeStart, max = this.tokens.length, last = max - 1; i < max; i++) {
/* 144 */       findNextTypeBinding(i, scope, packageBinding);
/* 145 */       if (!this.resolvedType.isValidBinding())
/* 146 */         return this.resolvedType; 
/* 147 */       if (i == 0 && this.resolvedType.isTypeVariable() && ((TypeVariableBinding)this.resolvedType).firstBound == null) {
/* 148 */         scope.problemReporter().illegalAccessFromTypeVariable((TypeVariableBinding)this.resolvedType, this);
/* 149 */         return null;
/*     */       } 
/* 151 */       if (i <= last && isTypeUseDeprecated(this.resolvedType, scope)) {
/* 152 */         reportDeprecatedType(this.resolvedType, scope, i);
/*     */       }
/* 154 */       if (isClassScope && (
/* 155 */         (ClassScope)scope).detectHierarchyCycle(this.resolvedType, this))
/* 156 */         return null; 
/* 157 */       ReferenceBinding currentType = (ReferenceBinding)this.resolvedType;
/* 158 */       if (qualifiedType != null) {
/* 159 */         if (this.annotations != null) {
/* 160 */           rejectAnnotationsOnStaticMemberQualififer(scope, currentType, this.annotations[i - 1]);
/*     */         }
/* 162 */         ReferenceBinding enclosingType = currentType.enclosingType();
/* 163 */         if (enclosingType != null && TypeBinding.notEquals(enclosingType.erasure(), qualifiedType.erasure())) {
/* 164 */           qualifiedType = enclosingType;
/*     */         }
/* 166 */         if (currentType.isGenericType()) {
/* 167 */           RawTypeBinding rawTypeBinding = scope.environment().createRawType(currentType, qualifiedType);
/* 168 */         } else if (!currentType.hasEnclosingInstanceContext()) {
/* 169 */           qualifiedType = currentType;
/*     */         } else {
/* 171 */           RawTypeBinding rawTypeBinding; boolean rawQualified = qualifiedType.isRawType();
/* 172 */           if (rawQualified) {
/* 173 */             rawTypeBinding = scope.environment().createRawType((ReferenceBinding)currentType.erasure(), qualifiedType);
/* 174 */           } else if (rawTypeBinding.isParameterizedType() && TypeBinding.equalsEquals(rawTypeBinding.erasure(), currentType.enclosingType().erasure())) {
/* 175 */             ParameterizedTypeBinding parameterizedTypeBinding = scope.environment().createParameterizedType((ReferenceBinding)currentType.erasure(), null, (ReferenceBinding)rawTypeBinding);
/*     */           } else {
/* 177 */             ReferenceBinding referenceBinding = currentType;
/*     */           } 
/*     */         } 
/*     */       } else {
/* 181 */         qualifiedType = currentType.isGenericType() ? (ReferenceBinding)scope.environment().convertToRawType((TypeBinding)currentType, false) : currentType;
/*     */       } 
/* 183 */       recordResolution(scope.environment(), (TypeBinding)qualifiedType);
/*     */     } 
/* 185 */     this.resolvedType = (TypeBinding)qualifiedType;
/* 186 */     return this.resolvedType;
/*     */   }
/*     */   
/*     */   void recordResolution(LookupEnvironment env, TypeBinding typeFound) {
/* 190 */     if (typeFound != null && typeFound.isValidBinding()) {
/* 191 */       synchronized (env.root) {
/* 192 */         for (int i = 0; i < env.root.resolutionListeners.length; i++) {
/* 193 */           env.root.resolutionListeners[i].recordResolution(this, typeFound);
/*     */         }
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public char[][] getTypeName() {
/* 202 */     return this.tokens;
/*     */   }
/*     */ 
/*     */   
/*     */   public StringBuffer printExpression(int indent, StringBuffer output) {
/* 207 */     for (int i = 0; i < this.tokens.length; i++) {
/* 208 */       if (i > 0) output.append('.'); 
/* 209 */       if (this.annotations != null && this.annotations[i] != null) {
/* 210 */         printAnnotations(this.annotations[i], output);
/* 211 */         output.append(' ');
/*     */       } 
/* 213 */       output.append(this.tokens[i]);
/*     */     } 
/* 215 */     return output;
/*     */   }
/*     */ 
/*     */   
/*     */   public void traverse(ASTVisitor visitor, BlockScope scope) {
/* 220 */     if (visitor.visit(this, scope) && 
/* 221 */       this.annotations != null) {
/* 222 */       int annotationsLevels = this.annotations.length;
/* 223 */       for (int i = 0; i < annotationsLevels; i++) {
/* 224 */         int annotationsLength = (this.annotations[i] == null) ? 0 : (this.annotations[i]).length;
/* 225 */         for (int j = 0; j < annotationsLength; j++) {
/* 226 */           this.annotations[i][j].traverse(visitor, scope);
/*     */         }
/*     */       } 
/*     */     } 
/* 230 */     visitor.endVisit(this, scope);
/*     */   }
/*     */ 
/*     */   
/*     */   public void traverse(ASTVisitor visitor, ClassScope scope) {
/* 235 */     if (visitor.visit(this, scope) && 
/* 236 */       this.annotations != null) {
/* 237 */       int annotationsLevels = this.annotations.length;
/* 238 */       for (int i = 0; i < annotationsLevels; i++) {
/* 239 */         int annotationsLength = (this.annotations[i] == null) ? 0 : (this.annotations[i]).length;
/* 240 */         for (int j = 0; j < annotationsLength; j++) {
/* 241 */           this.annotations[i][j].traverse(visitor, scope);
/*     */         }
/*     */       } 
/*     */     } 
/* 245 */     visitor.endVisit(this, scope);
/*     */   }
/*     */   
/*     */   public int getAnnotatableLevels() {
/* 249 */     return this.tokens.length;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\ast\QualifiedTypeReference.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */