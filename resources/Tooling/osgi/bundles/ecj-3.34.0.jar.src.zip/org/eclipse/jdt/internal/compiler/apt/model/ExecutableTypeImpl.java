/*     */ package org.eclipse.jdt.internal.compiler.apt.model;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import javax.lang.model.type.ExecutableType;
/*     */ import javax.lang.model.type.TypeKind;
/*     */ import javax.lang.model.type.TypeMirror;
/*     */ import javax.lang.model.type.TypeVariable;
/*     */ import javax.lang.model.type.TypeVisitor;
/*     */ import org.eclipse.jdt.internal.compiler.apt.dispatch.BaseProcessingEnvImpl;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.AnnotationBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.Binding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.MethodBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.ReferenceBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.TypeBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.TypeVariableBinding;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ExecutableTypeImpl
/*     */   extends TypeMirrorImpl
/*     */   implements ExecutableType
/*     */ {
/*     */   ExecutableTypeImpl(BaseProcessingEnvImpl env, MethodBinding binding) {
/*  42 */     super(env, (Binding)binding);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<? extends TypeMirror> getParameterTypes() {
/*  49 */     MethodBinding binding = (MethodBinding)this._binding;
/*  50 */     TypeBinding[] parameters = binding.parameters;
/*  51 */     int length = parameters.length;
/*  52 */     boolean isEnumConstructor = (binding.isConstructor() && 
/*  53 */       binding.declaringClass.isEnum() && 
/*  54 */       binding.declaringClass.isBinaryBinding() && (
/*  55 */       binding.modifiers & 0x40000000) == 0);
/*  56 */     if (isEnumConstructor) {
/*  57 */       ArrayList<TypeMirror> list = new ArrayList<>();
/*  58 */       for (int i = 0; i < length; i++) {
/*  59 */         list.add(this._env.getFactory().newTypeMirror((Binding)parameters[i]));
/*     */       }
/*  61 */       return Collections.unmodifiableList(list);
/*     */     } 
/*  63 */     if (length != 0) {
/*  64 */       ArrayList<TypeMirror> list = new ArrayList<>(); byte b; int i; TypeBinding[] arrayOfTypeBinding;
/*  65 */       for (i = (arrayOfTypeBinding = parameters).length, b = 0; b < i; ) { TypeBinding typeBinding = arrayOfTypeBinding[b];
/*  66 */         list.add(this._env.getFactory().newTypeMirror((Binding)typeBinding)); b++; }
/*     */       
/*  68 */       return Collections.unmodifiableList(list);
/*     */     } 
/*  70 */     return Collections.emptyList();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TypeMirror getReturnType() {
/*  78 */     return this._env.getFactory().newTypeMirror((Binding)((MethodBinding)this._binding).returnType);
/*     */   }
/*     */ 
/*     */   
/*     */   protected AnnotationBinding[] getAnnotationBindings() {
/*  83 */     return ((MethodBinding)this._binding).returnType.getTypeAnnotations();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<? extends TypeMirror> getThrownTypes() {
/*  91 */     ArrayList<TypeMirror> list = new ArrayList<>();
/*  92 */     ReferenceBinding[] thrownExceptions = ((MethodBinding)this._binding).thrownExceptions;
/*  93 */     if (thrownExceptions.length != 0) {
/*  94 */       byte b; int i; ReferenceBinding[] arrayOfReferenceBinding; for (i = (arrayOfReferenceBinding = thrownExceptions).length, b = 0; b < i; ) { ReferenceBinding referenceBinding = arrayOfReferenceBinding[b];
/*  95 */         list.add(this._env.getFactory().newTypeMirror((Binding)referenceBinding)); b++; }
/*     */     
/*     */     } 
/*  98 */     return Collections.unmodifiableList(list);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<? extends TypeVariable> getTypeVariables() {
/* 106 */     ArrayList<TypeVariable> list = new ArrayList<>();
/* 107 */     TypeVariableBinding[] typeVariables = ((MethodBinding)this._binding).typeVariables();
/* 108 */     if (typeVariables.length != 0) {
/* 109 */       byte b; int i; TypeVariableBinding[] arrayOfTypeVariableBinding; for (i = (arrayOfTypeVariableBinding = typeVariables).length, b = 0; b < i; ) { TypeVariableBinding typeVariableBinding = arrayOfTypeVariableBinding[b];
/* 110 */         list.add((TypeVariable)this._env.getFactory().newTypeMirror((Binding)typeVariableBinding)); b++; }
/*     */     
/*     */     } 
/* 113 */     return Collections.unmodifiableList(list);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <R, P> R accept(TypeVisitor<R, P> v, P p) {
/* 121 */     return v.visitExecutable(this, p);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TypeKind getKind() {
/* 129 */     return TypeKind.EXECUTABLE;
/*     */   }
/*     */ 
/*     */   
/*     */   public TypeMirror getReceiverType() {
/* 134 */     return this._env.getFactory().getReceiverType((MethodBinding)this._binding);
/*     */   }
/*     */   
/*     */   public String toString() {
/* 138 */     return new String(((MethodBinding)this._binding).returnType.readableName());
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\apt\model\ExecutableTypeImpl.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */