/*    */ package org.eclipse.jdt.internal.compiler.env;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AccessRestriction
/*    */ {
/*    */   private AccessRule accessRule;
/*    */   public byte classpathEntryType;
/*    */   public static final byte COMMAND_LINE = 0;
/*    */   public static final byte PROJECT = 1;
/*    */   public static final byte LIBRARY = 2;
/*    */   public String classpathEntryName;
/*    */   
/*    */   public AccessRestriction(AccessRule accessRule, byte classpathEntryType, String classpathEntryName) {
/* 27 */     this.accessRule = accessRule;
/* 28 */     this.classpathEntryName = classpathEntryName;
/* 29 */     this.classpathEntryType = classpathEntryType;
/*    */   }
/*    */   
/*    */   public int getProblemId() {
/* 33 */     return this.accessRule.getProblemId();
/*    */   }
/*    */   
/*    */   public boolean ignoreIfBetter() {
/* 37 */     return this.accessRule.ignoreIfBetter();
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\env\AccessRestriction.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */