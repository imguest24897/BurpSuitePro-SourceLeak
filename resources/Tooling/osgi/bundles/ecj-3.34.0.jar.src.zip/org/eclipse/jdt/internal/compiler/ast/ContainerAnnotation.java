/*    */ package org.eclipse.jdt.internal.compiler.ast;
/*    */ 
/*    */ import org.eclipse.jdt.core.compiler.CharOperation;
/*    */ import org.eclipse.jdt.internal.compiler.impl.Constant;
/*    */ import org.eclipse.jdt.internal.compiler.lookup.BlockScope;
/*    */ import org.eclipse.jdt.internal.compiler.lookup.MethodBinding;
/*    */ import org.eclipse.jdt.internal.compiler.lookup.ReferenceBinding;
/*    */ import org.eclipse.jdt.internal.compiler.lookup.Scope;
/*    */ import org.eclipse.jdt.internal.compiler.lookup.TypeBinding;
/*    */ import org.eclipse.jdt.internal.compiler.lookup.TypeConstants;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ContainerAnnotation
/*    */   extends SingleMemberAnnotation
/*    */ {
/*    */   private Annotation[] containees;
/*    */   private ArrayInitializer memberValues;
/*    */   
/*    */   public ContainerAnnotation(Annotation repeatingAnnotation, ReferenceBinding containerAnnotationType, BlockScope scope) {
/* 31 */     char[][] containerTypeName = containerAnnotationType.compoundName;
/* 32 */     if (containerTypeName.length == 1) {
/* 33 */       this.type = new SingleTypeReference(containerTypeName[0], 0L);
/*    */     } else {
/* 35 */       this.type = new QualifiedTypeReference(containerTypeName, new long[containerTypeName.length]);
/*    */     } 
/*    */     
/* 38 */     this.sourceStart = repeatingAnnotation.sourceStart;
/* 39 */     this.sourceEnd = repeatingAnnotation.sourceEnd;
/*    */     
/* 41 */     this.resolvedType = (TypeBinding)containerAnnotationType;
/* 42 */     this.recipient = repeatingAnnotation.recipient;
/* 43 */     this.containees = new Annotation[0];
/* 44 */     this.memberValue = this.memberValues = new ArrayInitializer();
/* 45 */     addContainee(repeatingAnnotation);
/*    */   }
/*    */   
/*    */   public void addContainee(Annotation repeatingAnnotation) {
/* 49 */     int length = this.containees.length;
/* 50 */     System.arraycopy(this.containees, 0, this.containees = new Annotation[length + 1], 0, length);
/* 51 */     this.containees[length] = repeatingAnnotation;
/* 52 */     this.memberValues.expressions = (Expression[])this.containees;
/* 53 */     repeatingAnnotation.setPersistibleAnnotation((length == 0) ? this : null);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public TypeBinding resolveType(BlockScope scope) {
/* 60 */     if (this.compilerAnnotation != null) {
/* 61 */       return this.resolvedType;
/*    */     }
/* 63 */     this.constant = Constant.NotAConstant;
/*    */     
/* 65 */     ReferenceBinding containerAnnotationType = (ReferenceBinding)this.resolvedType;
/* 66 */     if (!containerAnnotationType.isValidBinding())
/* 67 */       containerAnnotationType = (ReferenceBinding)containerAnnotationType.closestMatch(); 
/* 68 */     Annotation repeatingAnnotation = this.containees[0];
/* 69 */     ReferenceBinding repeatingAnnotationType = (ReferenceBinding)repeatingAnnotation.resolvedType;
/* 70 */     if (!repeatingAnnotationType.isDeprecated() && isTypeUseDeprecated((TypeBinding)containerAnnotationType, (Scope)scope)) {
/* 71 */       scope.problemReporter().deprecatedType((TypeBinding)containerAnnotationType, repeatingAnnotation);
/*    */     }
/* 73 */     checkContainerAnnotationType(repeatingAnnotation, scope, containerAnnotationType, repeatingAnnotationType, true);
/* 74 */     this.resolvedType = (TypeBinding)(containerAnnotationType = repeatingAnnotationType.containerAnnotationType());
/* 75 */     if (!this.resolvedType.isValidBinding()) {
/* 76 */       return this.resolvedType;
/*    */     }
/*    */     
/* 79 */     MethodBinding[] methods = containerAnnotationType.methods();
/* 80 */     MemberValuePair pair = memberValuePairs()[0];
/*    */     
/* 82 */     for (int i = 0, length = methods.length; i < length; i++) {
/* 83 */       MethodBinding method = methods[i];
/* 84 */       if (CharOperation.equals(method.selector, TypeConstants.VALUE)) {
/* 85 */         pair.binding = method;
/* 86 */         pair.resolveTypeExpecting(scope, method.returnType);
/*    */       } 
/*    */     } 
/* 89 */     this.compilerAnnotation = scope.environment().createAnnotation((ReferenceBinding)this.resolvedType, computeElementValuePairs());
/* 90 */     return this.resolvedType;
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\ast\ContainerAnnotation.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */