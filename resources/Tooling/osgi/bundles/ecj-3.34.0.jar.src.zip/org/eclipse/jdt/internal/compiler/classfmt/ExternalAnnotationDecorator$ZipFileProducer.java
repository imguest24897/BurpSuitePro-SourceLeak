package org.eclipse.jdt.internal.compiler.classfmt;

import java.io.IOException;
import java.util.zip.ZipFile;

public interface ZipFileProducer {
  ZipFile produce() throws IOException;
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\classfmt\ExternalAnnotationDecorator$ZipFileProducer.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */