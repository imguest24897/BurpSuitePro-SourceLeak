/*    */ package org.eclipse.jdt.internal.compiler.ast;
/*    */ 
/*    */ import org.eclipse.jdt.internal.compiler.ASTVisitor;
/*    */ import org.eclipse.jdt.internal.compiler.lookup.BlockScope;
/*    */ import org.eclipse.jdt.internal.compiler.lookup.ClassScope;
/*    */ import org.eclipse.jdt.internal.compiler.lookup.Scope;
/*    */ import org.eclipse.jdt.internal.compiler.lookup.TypeBinding;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class JavadocArraySingleTypeReference
/*    */   extends ArrayTypeReference
/*    */ {
/*    */   public JavadocArraySingleTypeReference(char[] name, int dim, long pos) {
/* 26 */     super(name, dim, pos);
/* 27 */     this.bits |= 0x8000;
/*    */   }
/*    */ 
/*    */   
/*    */   protected void reportInvalidType(Scope scope) {
/* 32 */     scope.problemReporter().javadocInvalidType(this, this.resolvedType, scope.getDeclarationModifiers());
/*    */   }
/*    */   
/*    */   protected void reportDeprecatedType(TypeBinding type, Scope scope) {
/* 36 */     scope.problemReporter().javadocDeprecatedType(type, this, scope.getDeclarationModifiers());
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void traverse(ASTVisitor visitor, BlockScope scope) {
/* 45 */     visitor.visit(this, scope);
/* 46 */     visitor.endVisit(this, scope);
/*    */   }
/*    */ 
/*    */   
/*    */   public void traverse(ASTVisitor visitor, ClassScope scope) {
/* 51 */     visitor.visit(this, scope);
/* 52 */     visitor.endVisit(this, scope);
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\ast\JavadocArraySingleTypeReference.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */