/*     */ package org.eclipse.jdt.internal.compiler.batch;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import javax.tools.JavaFileManager;
/*     */ import javax.tools.JavaFileObject;
/*     */ import org.eclipse.jdt.core.compiler.CharOperation;
/*     */ import org.eclipse.jdt.internal.compiler.classfmt.ClassFormatException;
/*     */ import org.eclipse.jdt.internal.compiler.env.AccessRuleSet;
/*     */ import org.eclipse.jdt.internal.compiler.env.IModule;
/*     */ import org.eclipse.jdt.internal.compiler.env.NameEnvironmentAnswer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ClasspathJsr199
/*     */   extends ClasspathLocation
/*     */ {
/*  41 */   private static final Set<JavaFileObject.Kind> fileTypes = new HashSet<>(); private JavaFileManager fileManager;
/*     */   
/*     */   static {
/*  44 */     fileTypes.add(JavaFileObject.Kind.CLASS);
/*     */   }
/*     */ 
/*     */   
/*     */   private JavaFileManager.Location location;
/*     */   private FileSystem.Classpath jrt;
/*     */   
/*     */   public ClasspathJsr199(JavaFileManager file, JavaFileManager.Location location) {
/*  52 */     super((AccessRuleSet)null, (String)null);
/*  53 */     this.fileManager = file;
/*  54 */     this.location = location;
/*     */   }
/*     */   public ClasspathJsr199(FileSystem.Classpath jrt, JavaFileManager file, JavaFileManager.Location location) {
/*  57 */     super((AccessRuleSet)null, (String)null);
/*  58 */     this.fileManager = file;
/*  59 */     this.jrt = jrt;
/*  60 */     this.location = location;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ClasspathJsr199(ClasspathJep247 older, JavaFileManager file, JavaFileManager.Location location) {
/*  67 */     super((AccessRuleSet)null, (String)null);
/*  68 */     this.fileManager = file;
/*  69 */     this.jrt = older;
/*  70 */     this.location = location;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public List fetchLinkedJars(FileSystem.ClasspathSectionProblemReporter problemReporter) {
/*  76 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public NameEnvironmentAnswer findClass(char[] typeName, String qualifiedPackageName, String moduleName, String aQualifiedBinaryFileName, boolean asBinaryOnly) {
/*  82 */     if (this.jrt != null) {
/*  83 */       return this.jrt.findClass(typeName, qualifiedPackageName, moduleName, aQualifiedBinaryFileName, asBinaryOnly);
/*     */     }
/*  85 */     String qualifiedBinaryFileName = (File.separatorChar == '/') ? 
/*  86 */       aQualifiedBinaryFileName : 
/*  87 */       aQualifiedBinaryFileName.replace(File.separatorChar, '/');
/*     */     
/*     */     try {
/*  90 */       int lastDot = qualifiedBinaryFileName.lastIndexOf('.');
/*  91 */       String className = (lastDot < 0) ? qualifiedBinaryFileName : qualifiedBinaryFileName.substring(0, lastDot);
/*  92 */       JavaFileObject jfo = null;
/*     */       try {
/*  94 */         jfo = this.fileManager.getJavaFileForInput(this.location, className, JavaFileObject.Kind.CLASS);
/*  95 */       } catch (IOException iOException) {}
/*     */ 
/*     */ 
/*     */       
/*  99 */       if (jfo == null) {
/* 100 */         return null;
/*     */       }
/* 102 */       Exception exception1 = null, exception2 = null;
/*     */ 
/*     */       
/*     */       try {  }
/*     */       finally
/* 107 */       { exception2 = null; if (exception1 == null) { exception1 = exception2; } else if (exception1 != exception2) { exception1.addSuppressed(exception2); }  } 
/* 108 */     } catch (ClassFormatException classFormatException) {
/*     */     
/* 110 */     } catch (IOException iOException) {}
/*     */ 
/*     */     
/* 113 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public char[][][] findTypeNames(String aQualifiedPackageName, String moduleName) {
/* 118 */     if (this.jrt != null) {
/* 119 */       return this.jrt.findTypeNames(aQualifiedPackageName, moduleName);
/*     */     }
/* 121 */     String qualifiedPackageName = (File.separatorChar == '/') ? aQualifiedPackageName : aQualifiedPackageName.replace(
/* 122 */         File.separatorChar, '/');
/*     */     
/* 124 */     Iterable<JavaFileObject> files = null;
/*     */     try {
/* 126 */       files = this.fileManager.list(this.location, qualifiedPackageName, fileTypes, false);
/* 127 */     } catch (IOException iOException) {}
/*     */ 
/*     */     
/* 130 */     if (files == null) {
/* 131 */       return null;
/*     */     }
/* 133 */     ArrayList<char[][]> answers = new ArrayList();
/* 134 */     char[][] packageName = CharOperation.splitOn(File.separatorChar, qualifiedPackageName.toCharArray());
/*     */     
/* 136 */     for (JavaFileObject file : files) {
/* 137 */       String fileName = file.toUri().getPath();
/*     */       
/* 139 */       int last = fileName.lastIndexOf('/');
/* 140 */       if (last > 0) {
/* 141 */         int indexOfDot = fileName.lastIndexOf('.');
/* 142 */         if (indexOfDot != -1) {
/* 143 */           String typeName = fileName.substring(last + 1, indexOfDot);
/* 144 */           answers.add(CharOperation.arrayConcat(packageName, typeName.toCharArray()));
/*     */         } 
/*     */       } 
/*     */     } 
/* 148 */     int size = answers.size();
/* 149 */     if (size != 0) {
/* 150 */       char[][][] result = new char[size][][];
/* 151 */       answers.toArray(result);
/* 152 */       return result;
/*     */     } 
/* 154 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public void initialize() throws IOException {
/* 159 */     if (this.jrt != null) {
/* 160 */       this.jrt.initialize();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void acceptModule(IModule mod) {}
/*     */ 
/*     */ 
/*     */   
/*     */   public char[][] getModulesDeclaringPackage(String aQualifiedPackageName, String moduleName) {
/* 171 */     if (this.jrt != null) {
/* 172 */       return this.jrt.getModulesDeclaringPackage(aQualifiedPackageName, moduleName);
/*     */     }
/* 174 */     String qualifiedPackageName = (File.separatorChar == '/') ? aQualifiedPackageName : aQualifiedPackageName.replace(
/* 175 */         File.separatorChar, '/');
/*     */     
/* 177 */     boolean result = false;
/*     */     try {
/* 179 */       Iterable<JavaFileObject> files = this.fileManager.list(this.location, qualifiedPackageName, fileTypes, false);
/* 180 */       Iterator<JavaFileObject> f = files.iterator();
/*     */       
/* 182 */       if (f.hasNext()) {
/* 183 */         result = true;
/*     */       }
/*     */       else {
/*     */         
/* 187 */         files = this.fileManager.list(this.location, qualifiedPackageName, fileTypes, true);
/* 188 */         f = files.iterator();
/*     */         
/* 190 */         if (f.hasNext()) {
/* 191 */           result = true;
/*     */         }
/*     */       } 
/* 194 */     } catch (IOException iOException) {}
/*     */ 
/*     */     
/* 197 */     return singletonModuleNameIf(result);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean hasCompilationUnit(String qualifiedPackageName, String moduleName) {
/* 202 */     if (this.jrt != null)
/* 203 */       return this.jrt.hasCompilationUnit(qualifiedPackageName, moduleName); 
/* 204 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public void reset() {
/*     */     try {
/* 210 */       super.reset();
/* 211 */       this.fileManager.flush();
/* 212 */     } catch (IOException iOException) {}
/*     */ 
/*     */     
/* 215 */     if (this.jrt != null) {
/* 216 */       this.jrt.reset();
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 222 */     return "Classpath for Jsr 199 JavaFileManager: " + this.location;
/*     */   }
/*     */ 
/*     */   
/*     */   public char[] normalizedPath() {
/* 227 */     if (this.normalizedPath == null) {
/* 228 */       this.normalizedPath = getPath().toCharArray();
/*     */     }
/* 230 */     return this.normalizedPath;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getPath() {
/* 235 */     if (this.path == null) {
/* 236 */       this.path = this.location.getName();
/*     */     }
/* 238 */     return this.path;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getMode() {
/* 243 */     return 2;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean hasAnnotationFileFor(String qualifiedTypeName) {
/* 248 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public Collection<String> getModuleNames(Collection<String> limitModules) {
/* 253 */     if (this.jrt != null)
/* 254 */       return this.jrt.getModuleNames(limitModules); 
/* 255 */     return Collections.emptyList();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean hasModule() {
/* 260 */     if (this.jrt != null) {
/* 261 */       return this.jrt.hasModule();
/*     */     }
/* 263 */     return super.hasModule();
/*     */   }
/*     */ 
/*     */   
/*     */   public IModule getModule(char[] name) {
/* 268 */     if (this.jrt != null) {
/* 269 */       return this.jrt.getModule(name);
/*     */     }
/* 271 */     return super.getModule(name);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public NameEnvironmentAnswer findClass(char[] typeName, String qualifiedPackageName, String moduleName, String qualifiedBinaryFileName) {
/* 278 */     return findClass(typeName, qualifiedPackageName, moduleName, qualifiedBinaryFileName, false);
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\batch\ClasspathJsr199.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */