/*      */ package org.eclipse.jdt.internal.compiler.classfmt;
/*      */ 
/*      */ import java.io.ByteArrayOutputStream;
/*      */ import java.io.File;
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import java.io.PrintWriter;
/*      */ import java.io.StringWriter;
/*      */ import java.net.URI;
/*      */ import java.util.Arrays;
/*      */ import java.util.function.Predicate;
/*      */ import java.util.zip.ZipEntry;
/*      */ import java.util.zip.ZipFile;
/*      */ import org.eclipse.jdt.core.compiler.CharOperation;
/*      */ import org.eclipse.jdt.internal.compiler.codegen.AttributeNamesConstants;
/*      */ import org.eclipse.jdt.internal.compiler.env.IBinaryAnnotation;
/*      */ import org.eclipse.jdt.internal.compiler.env.IBinaryElementValuePair;
/*      */ import org.eclipse.jdt.internal.compiler.env.IBinaryField;
/*      */ import org.eclipse.jdt.internal.compiler.env.IBinaryMethod;
/*      */ import org.eclipse.jdt.internal.compiler.env.IBinaryModule;
/*      */ import org.eclipse.jdt.internal.compiler.env.IBinaryNestedType;
/*      */ import org.eclipse.jdt.internal.compiler.env.IBinaryType;
/*      */ import org.eclipse.jdt.internal.compiler.env.IBinaryTypeAnnotation;
/*      */ import org.eclipse.jdt.internal.compiler.env.IModule;
/*      */ import org.eclipse.jdt.internal.compiler.env.IRecordComponent;
/*      */ import org.eclipse.jdt.internal.compiler.env.ITypeAnnotationWalker;
/*      */ import org.eclipse.jdt.internal.compiler.impl.Constant;
/*      */ import org.eclipse.jdt.internal.compiler.lookup.BinaryTypeBinding;
/*      */ import org.eclipse.jdt.internal.compiler.lookup.LookupEnvironment;
/*      */ import org.eclipse.jdt.internal.compiler.lookup.TypeConstants;
/*      */ import org.eclipse.jdt.internal.compiler.util.JRTUtil;
/*      */ import org.eclipse.jdt.internal.compiler.util.Util;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class ClassFileReader
/*      */   extends ClassFileStruct
/*      */   implements IBinaryType
/*      */ {
/*      */   private int accessFlags;
/*      */   private char[] classFileName;
/*      */   private char[] className;
/*      */   private int classNameIndex;
/*      */   private int constantPoolCount;
/*      */   private AnnotationInfo[] annotations;
/*      */   private TypeAnnotationInfo[] typeAnnotations;
/*      */   private FieldInfo[] fields;
/*      */   private ModuleInfo moduleDeclaration;
/*      */   public char[] moduleName;
/*      */   private int fieldsCount;
/*      */   private InnerClassInfo innerInfo;
/*      */   private InnerClassInfo[] innerInfos;
/*      */   private char[][] interfaceNames;
/*      */   private int interfacesCount;
/*      */   private char[][] permittedSubtypesNames;
/*      */   private int permittedSubtypesCount;
/*      */   private MethodInfo[] methods;
/*      */   private int methodsCount;
/*      */   private char[] signature;
/*      */   private char[] sourceName;
/*      */   private char[] sourceFileName;
/*      */   private char[] superclassName;
/*      */   private long tagBits;
/*      */   private long version;
/*      */   private char[] enclosingTypeName;
/*      */   private char[][][] missingTypeNames;
/*      */   private int enclosingNameAndTypeIndex;
/*      */   private char[] enclosingMethod;
/*      */   private char[] nestHost;
/*      */   private int nestMembersCount;
/*      */   private char[][] nestMembers;
/*      */   private boolean isRecord;
/*      */   private int recordComponentsCount;
/*      */   private RecordComponentInfo[] recordComponents;
/*      */   URI path;
/*      */   
/*      */   private static String printTypeModifiers(int modifiers) {
/*   94 */     StringWriter out = new StringWriter();
/*   95 */     PrintWriter print = new PrintWriter(out);
/*      */     
/*   97 */     if ((modifiers & 0x1) != 0) print.print("public "); 
/*   98 */     if ((modifiers & 0x2) != 0) print.print("private "); 
/*   99 */     if ((modifiers & 0x10) != 0) print.print("final "); 
/*  100 */     if ((modifiers & 0x20) != 0) print.print("super "); 
/*  101 */     if ((modifiers & 0x200) != 0) print.print("interface "); 
/*  102 */     if ((modifiers & 0x400) != 0) print.print("abstract "); 
/*  103 */     if ((modifiers & 0x10000000) != 0) print.print("sealed "); 
/*  104 */     print.flush();
/*  105 */     return out.toString();
/*      */   }
/*      */   
/*      */   public static ClassFileReader read(File file) throws ClassFormatException, IOException {
/*  109 */     return read(file, false);
/*      */   }
/*      */   
/*      */   public static ClassFileReader read(File file, boolean fullyInitialize) throws ClassFormatException, IOException {
/*  113 */     byte[] classFileBytes = Util.getFileByteContent(file);
/*  114 */     URI uri = file.toURI();
/*  115 */     ClassFileReader classFileReader = new ClassFileReader(uri, classFileBytes, file.getAbsolutePath().toCharArray());
/*  116 */     if (fullyInitialize) {
/*  117 */       classFileReader.initialize();
/*      */     }
/*  119 */     return classFileReader;
/*      */   }
/*      */   
/*      */   public static ClassFileReader read(InputStream stream, String fileName) throws ClassFormatException, IOException {
/*  123 */     return read(stream, fileName, false);
/*      */   }
/*      */   
/*      */   public static ClassFileReader read(InputStream stream, String fileName, boolean fullyInitialize) throws ClassFormatException, IOException {
/*  127 */     byte[] classFileBytes = Util.getInputStreamAsByteArray(stream);
/*  128 */     ClassFileReader classFileReader = new ClassFileReader(classFileBytes, fileName.toCharArray());
/*  129 */     if (fullyInitialize) {
/*  130 */       classFileReader.initialize();
/*      */     }
/*  132 */     return classFileReader;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static ClassFileReader read(ZipFile zip, String filename) throws ClassFormatException, IOException {
/*  139 */     return read(zip, filename, false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static ClassFileReader readFromJrt(File jrt, IModule module, String filename) throws ClassFormatException, IOException {
/*  148 */     return JRTUtil.getClassfile(jrt, filename, (module == null) ? null : new String(module.name()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static ClassFileReader readFromModule(File jrt, String moduleName, String filename, Predicate<String> moduleNameFilter) throws ClassFormatException, IOException {
/*  157 */     return JRTUtil.getClassfile(jrt, filename, moduleName, moduleNameFilter);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static ClassFileReader read(ZipFile zip, String filename, boolean fullyInitialize) throws ClassFormatException, IOException {
/*  164 */     ZipEntry ze = zip.getEntry(filename);
/*  165 */     if (ze == null)
/*  166 */       return null; 
/*  167 */     ClassFileReader classFileReader = Util.getZipEntryClassFile(zip.getName(), filename);
/*  168 */     if (fullyInitialize) {
/*  169 */       classFileReader.initialize();
/*      */     }
/*  171 */     return classFileReader;
/*      */   }
/*      */   
/*      */   public static ClassFileReader read(String fileName) throws ClassFormatException, IOException {
/*  175 */     return read(fileName, false);
/*      */   }
/*      */   
/*      */   public static ClassFileReader read(String fileName, boolean fullyInitialize) throws ClassFormatException, IOException {
/*  179 */     return read(new File(fileName), fullyInitialize);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ClassFileReader(byte[] classFileBytes, char[] fileName) throws ClassFormatException {
/*  190 */     this(classFileBytes, fileName, false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ClassFileReader(URI path, byte[] classFileBytes, char[] fileName) throws ClassFormatException {
/*  200 */     this(classFileBytes, fileName, false);
/*  201 */     this.path = path;
/*  202 */     if (this.moduleDeclaration != null) {
/*  203 */       this.moduleDeclaration.path = this.path;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ClassFileReader(byte[] classFileBytes, char[] fileName, boolean fullyInitialize) throws ClassFormatException {
/*  223 */     super(classFileBytes, null, 0);
/*  224 */     this.classFileName = fileName;
/*  225 */     int readOffset = 10;
/*      */     try {
/*  227 */       this.version = (u2At(6) << 16L) + u2At(4);
/*  228 */       this.constantPoolCount = u2At(8);
/*      */       
/*  230 */       this.constantPoolOffsets = new int[this.constantPoolCount];
/*  231 */       for (int i = 1; i < this.constantPoolCount; i++) {
/*  232 */         int tag = u1At(readOffset);
/*  233 */         switch (tag) {
/*      */           case 1:
/*  235 */             this.constantPoolOffsets[i] = readOffset;
/*  236 */             readOffset += u2At(readOffset + 1);
/*  237 */             readOffset += 3;
/*      */             break;
/*      */           case 3:
/*  240 */             this.constantPoolOffsets[i] = readOffset;
/*  241 */             readOffset += 5;
/*      */             break;
/*      */           case 4:
/*  244 */             this.constantPoolOffsets[i] = readOffset;
/*  245 */             readOffset += 5;
/*      */             break;
/*      */           case 5:
/*  248 */             this.constantPoolOffsets[i] = readOffset;
/*  249 */             readOffset += 9;
/*  250 */             i++;
/*      */             break;
/*      */           case 6:
/*  253 */             this.constantPoolOffsets[i] = readOffset;
/*  254 */             readOffset += 9;
/*  255 */             i++;
/*      */             break;
/*      */           case 7:
/*  258 */             this.constantPoolOffsets[i] = readOffset;
/*  259 */             readOffset += 3;
/*      */             break;
/*      */           case 8:
/*  262 */             this.constantPoolOffsets[i] = readOffset;
/*  263 */             readOffset += 3;
/*      */             break;
/*      */           case 9:
/*  266 */             this.constantPoolOffsets[i] = readOffset;
/*  267 */             readOffset += 5;
/*      */             break;
/*      */           case 10:
/*  270 */             this.constantPoolOffsets[i] = readOffset;
/*  271 */             readOffset += 5;
/*      */             break;
/*      */           case 11:
/*  274 */             this.constantPoolOffsets[i] = readOffset;
/*  275 */             readOffset += 5;
/*      */             break;
/*      */           case 12:
/*  278 */             this.constantPoolOffsets[i] = readOffset;
/*  279 */             readOffset += 5;
/*      */             break;
/*      */           case 15:
/*  282 */             this.constantPoolOffsets[i] = readOffset;
/*  283 */             readOffset += 4;
/*      */             break;
/*      */           case 16:
/*  286 */             this.constantPoolOffsets[i] = readOffset;
/*  287 */             readOffset += 3;
/*      */             break;
/*      */           case 17:
/*  290 */             this.constantPoolOffsets[i] = readOffset;
/*  291 */             readOffset += 5;
/*      */             break;
/*      */           case 18:
/*  294 */             this.constantPoolOffsets[i] = readOffset;
/*  295 */             readOffset += 5;
/*      */             break;
/*      */           case 19:
/*  298 */             this.constantPoolOffsets[i] = readOffset;
/*  299 */             readOffset += 3;
/*      */             break;
/*      */           case 20:
/*  302 */             this.constantPoolOffsets[i] = readOffset;
/*  303 */             readOffset += 3;
/*      */             break;
/*      */         } 
/*      */       
/*      */       } 
/*  308 */       this.accessFlags = u2At(readOffset);
/*  309 */       readOffset += 2;
/*      */ 
/*      */       
/*  312 */       this.classNameIndex = u2At(readOffset);
/*  313 */       if (this.classNameIndex != 0) {
/*  314 */         this.className = getConstantClassNameAt(this.classNameIndex);
/*      */       }
/*  316 */       readOffset += 2;
/*      */ 
/*      */       
/*  319 */       int superclassNameIndex = u2At(readOffset);
/*  320 */       readOffset += 2;
/*      */ 
/*      */       
/*  323 */       if (superclassNameIndex != 0) {
/*  324 */         this.superclassName = getConstantClassNameAt(superclassNameIndex);
/*  325 */         if (CharOperation.equals(this.superclassName, TypeConstants.CharArray_JAVA_LANG_RECORD_SLASH)) {
/*  326 */           this.accessFlags |= 0x1000000;
/*      */         }
/*      */       } 
/*      */ 
/*      */       
/*  331 */       this.interfacesCount = u2At(readOffset);
/*  332 */       readOffset += 2;
/*  333 */       if (this.interfacesCount != 0) {
/*  334 */         this.interfaceNames = new char[this.interfacesCount][];
/*  335 */         for (int k = 0; k < this.interfacesCount; k++) {
/*  336 */           this.interfaceNames[k] = getConstantClassNameAt(u2At(readOffset));
/*  337 */           readOffset += 2;
/*      */         } 
/*      */       } 
/*      */       
/*  341 */       this.fieldsCount = u2At(readOffset);
/*  342 */       readOffset += 2;
/*  343 */       if (this.fieldsCount != 0) {
/*      */         
/*  345 */         this.fields = new FieldInfo[this.fieldsCount];
/*  346 */         for (int k = 0; k < this.fieldsCount; k++) {
/*  347 */           FieldInfo field = FieldInfo.createField(this.reference, this.constantPoolOffsets, readOffset, this.version);
/*  348 */           this.fields[k] = field;
/*  349 */           readOffset += field.sizeInBytes();
/*      */         } 
/*      */       } 
/*      */       
/*  353 */       this.methodsCount = u2At(readOffset);
/*  354 */       readOffset += 2;
/*  355 */       if (this.methodsCount != 0) {
/*  356 */         this.methods = new MethodInfo[this.methodsCount];
/*  357 */         boolean isAnnotationType = ((this.accessFlags & 0x2000) != 0);
/*  358 */         for (int k = 0; k < this.methodsCount; k++) {
/*  359 */           this.methods[k] = isAnnotationType ? 
/*  360 */             AnnotationMethodInfo.createAnnotationMethod(this.reference, this.constantPoolOffsets, readOffset, this.version) : 
/*  361 */             MethodInfo.createMethod(this.reference, this.constantPoolOffsets, readOffset, this.version);
/*  362 */           readOffset += this.methods[k].sizeInBytes();
/*      */         } 
/*      */       } 
/*      */ 
/*      */       
/*  367 */       int attributesCount = u2At(readOffset);
/*  368 */       readOffset += 2;
/*      */       
/*  370 */       for (int j = 0; j < attributesCount; j++) {
/*  371 */         int utf8Offset = this.constantPoolOffsets[u2At(readOffset)];
/*  372 */         char[] attributeName = utf8At(utf8Offset + 3, u2At(utf8Offset + 1));
/*  373 */         if (attributeName.length == 0) {
/*  374 */           readOffset = (int)(readOffset + 6L + u4At(readOffset + 2));
/*      */         } else {
/*      */           
/*  377 */           switch (attributeName[0]) {
/*      */             case 'E':
/*  379 */               if (CharOperation.equals(attributeName, AttributeNamesConstants.EnclosingMethodName)) {
/*  380 */                 utf8Offset = 
/*  381 */                   this.constantPoolOffsets[u2At(this.constantPoolOffsets[u2At(readOffset + 6)] + 1)];
/*  382 */                 this.enclosingTypeName = utf8At(utf8Offset + 3, u2At(utf8Offset + 1));
/*  383 */                 this.enclosingNameAndTypeIndex = u2At(readOffset + 8);
/*      */               } 
/*      */               break;
/*      */             case 'D':
/*  387 */               if (CharOperation.equals(attributeName, AttributeNamesConstants.DeprecatedName)) {
/*  388 */                 this.accessFlags |= 0x100000;
/*      */               }
/*      */               break;
/*      */             case 'I':
/*  392 */               if (CharOperation.equals(attributeName, AttributeNamesConstants.InnerClassName)) {
/*  393 */                 int innerOffset = readOffset + 6;
/*  394 */                 int number_of_classes = u2At(innerOffset);
/*  395 */                 if (number_of_classes != 0) {
/*  396 */                   innerOffset += 2;
/*  397 */                   this.innerInfos = new InnerClassInfo[number_of_classes];
/*  398 */                   for (int k = 0; k < number_of_classes; k++) {
/*  399 */                     this.innerInfos[k] = 
/*  400 */                       new InnerClassInfo(this.reference, this.constantPoolOffsets, innerOffset);
/*  401 */                     if (this.classNameIndex == (this.innerInfos[k]).innerClassNameIndex) {
/*  402 */                       this.innerInfo = this.innerInfos[k];
/*      */                     }
/*  404 */                     innerOffset += 8;
/*      */                   } 
/*  406 */                   if (this.innerInfo != null) {
/*  407 */                     char[] enclosingType = this.innerInfo.getEnclosingTypeName();
/*  408 */                     if (enclosingType != null)
/*  409 */                       this.enclosingTypeName = enclosingType; 
/*      */                   } 
/*      */                 }  break;
/*      */               } 
/*  413 */               if (CharOperation.equals(attributeName, AttributeNamesConstants.InconsistentHierarchy)) {
/*  414 */                 this.tagBits |= 0x20000L;
/*      */               }
/*      */               break;
/*      */             case 'S':
/*  418 */               if (attributeName.length > 2)
/*  419 */                 switch (attributeName[1]) {
/*      */                   case 'o':
/*  421 */                     if (CharOperation.equals(attributeName, AttributeNamesConstants.SourceName)) {
/*  422 */                       utf8Offset = this.constantPoolOffsets[u2At(readOffset + 6)];
/*  423 */                       this.sourceFileName = utf8At(utf8Offset + 3, u2At(utf8Offset + 1));
/*      */                     } 
/*      */                     break;
/*      */                   case 'y':
/*  427 */                     if (CharOperation.equals(attributeName, AttributeNamesConstants.SyntheticName)) {
/*  428 */                       this.accessFlags |= 0x1000;
/*      */                     }
/*      */                     break;
/*      */                   case 'i':
/*  432 */                     if (CharOperation.equals(attributeName, AttributeNamesConstants.SignatureName)) {
/*  433 */                       utf8Offset = this.constantPoolOffsets[u2At(readOffset + 6)];
/*  434 */                       this.signature = utf8At(utf8Offset + 3, u2At(utf8Offset + 1));
/*      */                     } 
/*      */                     break;
/*      */                 }  
/*      */               break;
/*      */             case 'R':
/*  440 */               if (CharOperation.equals(attributeName, AttributeNamesConstants.RuntimeVisibleAnnotationsName)) {
/*  441 */                 decodeAnnotations(readOffset, true); break;
/*  442 */               }  if (CharOperation.equals(attributeName, AttributeNamesConstants.RuntimeInvisibleAnnotationsName)) {
/*  443 */                 decodeAnnotations(readOffset, false); break;
/*  444 */               }  if (CharOperation.equals(attributeName, AttributeNamesConstants.RuntimeVisibleTypeAnnotationsName)) {
/*  445 */                 decodeTypeAnnotations(readOffset, true); break;
/*  446 */               }  if (CharOperation.equals(attributeName, AttributeNamesConstants.RuntimeInvisibleTypeAnnotationsName)) {
/*  447 */                 decodeTypeAnnotations(readOffset, false); break;
/*  448 */               }  if (CharOperation.equals(attributeName, AttributeNamesConstants.RecordClass)) {
/*  449 */                 decodeRecords(readOffset, attributeName);
/*      */               }
/*      */               break;
/*      */             
/*      */             case 'M':
/*  454 */               if (CharOperation.equals(attributeName, AttributeNamesConstants.MissingTypesName)) {
/*      */                 
/*  456 */                 int missingTypeOffset = readOffset + 6;
/*  457 */                 int numberOfMissingTypes = u2At(missingTypeOffset);
/*  458 */                 if (numberOfMissingTypes != 0) {
/*  459 */                   this.missingTypeNames = new char[numberOfMissingTypes][][];
/*  460 */                   missingTypeOffset += 2;
/*  461 */                   for (int k = 0; k < numberOfMissingTypes; k++) {
/*  462 */                     utf8Offset = this.constantPoolOffsets[u2At(this.constantPoolOffsets[u2At(missingTypeOffset)] + 1)];
/*  463 */                     char[] missingTypeConstantPoolName = utf8At(utf8Offset + 3, u2At(utf8Offset + 1));
/*  464 */                     this.missingTypeNames[k] = CharOperation.splitOn('/', missingTypeConstantPoolName);
/*  465 */                     missingTypeOffset += 2;
/*      */                   } 
/*      */                 }  break;
/*  468 */               }  if (CharOperation.equals(attributeName, AttributeNamesConstants.ModuleName)) {
/*  469 */                 this.moduleDeclaration = ModuleInfo.createModule(this.reference, this.constantPoolOffsets, readOffset);
/*  470 */                 this.moduleName = this.moduleDeclaration.name();
/*      */               } 
/*      */               break;
/*      */             case 'N':
/*  474 */               if (CharOperation.equals(attributeName, AttributeNamesConstants.NestHost)) {
/*  475 */                 utf8Offset = 
/*  476 */                   this.constantPoolOffsets[u2At(this.constantPoolOffsets[u2At(readOffset + 6)] + 1)];
/*  477 */                 this.nestHost = utf8At(utf8Offset + 3, u2At(utf8Offset + 1)); break;
/*  478 */               }  if (CharOperation.equals(attributeName, AttributeNamesConstants.NestMembers)) {
/*  479 */                 int offset = readOffset + 6;
/*  480 */                 this.nestMembersCount = u2At(offset);
/*  481 */                 if (this.nestMembersCount != 0) {
/*  482 */                   offset += 2;
/*  483 */                   this.nestMembers = new char[this.nestMembersCount][];
/*  484 */                   for (int k = 0; k < this.nestMembersCount; k++) {
/*  485 */                     utf8Offset = 
/*  486 */                       this.constantPoolOffsets[u2At(this.constantPoolOffsets[u2At(offset)] + 1)];
/*  487 */                     this.nestMembers[k] = utf8At(utf8Offset + 3, u2At(utf8Offset + 1));
/*  488 */                     offset += 2;
/*      */                   } 
/*      */                 } 
/*      */               } 
/*      */               break;
/*      */             case 'P':
/*  494 */               if (CharOperation.equals(attributeName, AttributeNamesConstants.PermittedSubclasses)) {
/*  495 */                 int offset = readOffset + 6;
/*  496 */                 this.permittedSubtypesCount = u2At(offset);
/*  497 */                 if (this.permittedSubtypesCount != 0) {
/*  498 */                   this.accessFlags |= 0x10000000;
/*  499 */                   offset += 2;
/*  500 */                   this.permittedSubtypesNames = new char[this.permittedSubtypesCount][];
/*  501 */                   for (int k = 0; k < this.permittedSubtypesCount; k++) {
/*  502 */                     utf8Offset = 
/*  503 */                       this.constantPoolOffsets[u2At(this.constantPoolOffsets[u2At(offset)] + 1)];
/*  504 */                     this.permittedSubtypesNames[k] = utf8At(utf8Offset + 3, u2At(utf8Offset + 1));
/*  505 */                     offset += 2;
/*      */                   } 
/*      */                 } 
/*      */               } 
/*      */               break;
/*      */           } 
/*  511 */           readOffset = (int)(readOffset + 6L + u4At(readOffset + 2));
/*      */         } 
/*  513 */       }  if (this.moduleDeclaration != null && this.annotations != null) {
/*  514 */         this.moduleDeclaration.setAnnotations(this.annotations, this.tagBits, fullyInitialize);
/*  515 */         this.annotations = null;
/*      */       } 
/*  517 */       if (fullyInitialize) {
/*  518 */         initialize();
/*      */       }
/*  520 */     } catch (ClassFormatException e) {
/*  521 */       throw e;
/*  522 */     } catch (Exception e) {
/*  523 */       throw new ClassFormatException(e, 
/*  524 */           this.classFileName, 
/*  525 */           21, 
/*  526 */           readOffset);
/*      */     } 
/*      */   }
/*      */   
/*      */   private void decodeRecords(int readOffset, char[] attributeName) {
/*  531 */     if (CharOperation.equals(attributeName, AttributeNamesConstants.RecordClass)) {
/*  532 */       this.isRecord = true;
/*  533 */       int offset = readOffset + 6;
/*  534 */       this.recordComponentsCount = u2At(offset);
/*  535 */       if (this.recordComponentsCount != 0) {
/*  536 */         offset += 2;
/*  537 */         this.recordComponents = new RecordComponentInfo[this.recordComponentsCount];
/*  538 */         for (int j = 0; j < this.recordComponentsCount; j++) {
/*  539 */           RecordComponentInfo component = RecordComponentInfo.createComponent(this.reference, this.constantPoolOffsets, offset, this.version);
/*  540 */           this.recordComponents[j] = component;
/*  541 */           offset += component.sizeInBytes();
/*      */         } 
/*      */       } 
/*      */     } 
/*      */   }
/*      */   
/*      */   public char[] getNestHost() {
/*  548 */     return this.nestHost;
/*      */   }
/*      */ 
/*      */   
/*      */   public BinaryTypeBinding.ExternalAnnotationStatus getExternalAnnotationStatus() {
/*  553 */     return BinaryTypeBinding.ExternalAnnotationStatus.NOT_EEA_CONFIGURED;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ITypeAnnotationWalker enrichWithExternalAnnotationsFor(ITypeAnnotationWalker walker, Object member, LookupEnvironment environment) {
/*  562 */     return walker;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int accessFlags() {
/*  571 */     return this.accessFlags;
/*      */   }
/*      */   
/*      */   private void decodeAnnotations(int offset, boolean runtimeVisible) {
/*  575 */     int numberOfAnnotations = u2At(offset + 6);
/*  576 */     if (numberOfAnnotations > 0) {
/*  577 */       int readOffset = offset + 8;
/*  578 */       AnnotationInfo[] newInfos = null;
/*  579 */       int newInfoCount = 0;
/*  580 */       for (int i = 0; i < numberOfAnnotations; i++) {
/*      */         
/*  582 */         AnnotationInfo newInfo = new AnnotationInfo(this.reference, this.constantPoolOffsets, readOffset, runtimeVisible, false);
/*  583 */         readOffset += newInfo.readOffset;
/*  584 */         long standardTagBits = newInfo.standardAnnotationTagBits;
/*  585 */         if (standardTagBits != 0L) {
/*  586 */           this.tagBits |= standardTagBits;
/*  587 */           if ((this.version < 3473408L || (standardTagBits & 0x400000000000L) == 0L) && (
/*  588 */             standardTagBits & 0x20600FF840000000L) == 0L)
/*      */             continue; 
/*      */         } 
/*  591 */         if (newInfos == null)
/*  592 */           newInfos = new AnnotationInfo[numberOfAnnotations - i]; 
/*  593 */         newInfos[newInfoCount++] = newInfo; continue;
/*      */       } 
/*  595 */       if (newInfos == null) {
/*      */         return;
/*      */       }
/*  598 */       if (this.annotations == null) {
/*  599 */         if (newInfoCount != newInfos.length)
/*  600 */           System.arraycopy(newInfos, 0, newInfos = new AnnotationInfo[newInfoCount], 0, newInfoCount); 
/*  601 */         this.annotations = newInfos;
/*      */       } else {
/*  603 */         int length = this.annotations.length;
/*  604 */         AnnotationInfo[] temp = new AnnotationInfo[length + newInfoCount];
/*  605 */         System.arraycopy(this.annotations, 0, temp, 0, length);
/*  606 */         System.arraycopy(newInfos, 0, temp, length, newInfoCount);
/*  607 */         this.annotations = temp;
/*      */       } 
/*      */     } 
/*      */   }
/*      */   
/*      */   private void decodeTypeAnnotations(int offset, boolean runtimeVisible) {
/*  613 */     int numberOfAnnotations = u2At(offset + 6);
/*  614 */     if (numberOfAnnotations > 0) {
/*  615 */       int readOffset = offset + 8;
/*  616 */       TypeAnnotationInfo[] newInfos = null;
/*  617 */       newInfos = new TypeAnnotationInfo[numberOfAnnotations];
/*  618 */       for (int i = 0; i < numberOfAnnotations; i++) {
/*      */         
/*  620 */         TypeAnnotationInfo newInfo = new TypeAnnotationInfo(this.reference, this.constantPoolOffsets, readOffset, runtimeVisible, false);
/*  621 */         readOffset += newInfo.readOffset;
/*  622 */         newInfos[i] = newInfo;
/*      */       } 
/*  624 */       if (this.typeAnnotations == null) {
/*  625 */         this.typeAnnotations = newInfos;
/*      */       } else {
/*  627 */         int length = this.typeAnnotations.length;
/*  628 */         TypeAnnotationInfo[] temp = new TypeAnnotationInfo[length + numberOfAnnotations];
/*  629 */         System.arraycopy(this.typeAnnotations, 0, temp, 0, length);
/*  630 */         System.arraycopy(newInfos, 0, temp, length, numberOfAnnotations);
/*  631 */         this.typeAnnotations = temp;
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public IBinaryAnnotation[] getAnnotations() {
/*  641 */     return (IBinaryAnnotation[])this.annotations;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public IBinaryTypeAnnotation[] getTypeAnnotations() {
/*  649 */     return (IBinaryTypeAnnotation[])this.typeAnnotations;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private char[] getConstantClassNameAt(int constantPoolIndex) {
/*  660 */     int utf8Offset = this.constantPoolOffsets[u2At(this.constantPoolOffsets[constantPoolIndex] + 1)];
/*  661 */     return utf8At(utf8Offset + 3, u2At(utf8Offset + 1));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int[] getConstantPoolOffsets() {
/*  670 */     return this.constantPoolOffsets;
/*      */   }
/*      */ 
/*      */   
/*      */   public char[] getEnclosingMethod() {
/*  675 */     if (this.enclosingNameAndTypeIndex <= 0) {
/*  676 */       return null;
/*      */     }
/*  678 */     if (this.enclosingMethod == null) {
/*      */       
/*  680 */       StringBuffer buffer = new StringBuffer();
/*      */       
/*  682 */       int nameAndTypeOffset = this.constantPoolOffsets[this.enclosingNameAndTypeIndex];
/*  683 */       int utf8Offset = this.constantPoolOffsets[u2At(nameAndTypeOffset + 1)];
/*  684 */       buffer.append(utf8At(utf8Offset + 3, u2At(utf8Offset + 1)));
/*      */       
/*  686 */       utf8Offset = this.constantPoolOffsets[u2At(nameAndTypeOffset + 3)];
/*  687 */       buffer.append(utf8At(utf8Offset + 3, u2At(utf8Offset + 1)));
/*      */       
/*  689 */       this.enclosingMethod = String.valueOf(buffer).toCharArray();
/*      */     } 
/*  691 */     return this.enclosingMethod;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public char[] getEnclosingTypeName() {
/*  700 */     return this.enclosingTypeName;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public IBinaryField[] getFields() {
/*  709 */     return (IBinaryField[])this.fields;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public char[] getModule() {
/*  716 */     return this.moduleName;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public IBinaryModule getModuleDeclaration() {
/*  725 */     return this.moduleDeclaration;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public char[] getFileName() {
/*  733 */     return this.classFileName;
/*      */   }
/*      */ 
/*      */   
/*      */   public char[] getGenericSignature() {
/*  738 */     return this.signature;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public char[] getInnerSourceName() {
/*  763 */     if (this.innerInfo != null)
/*  764 */       return this.innerInfo.getSourceName(); 
/*  765 */     return null;
/*      */   }
/*      */ 
/*      */   
/*      */   public char[][] getInterfaceNames() {
/*  770 */     return this.interfaceNames;
/*      */   }
/*      */ 
/*      */   
/*      */   public char[][] getPermittedSubtypeNames() {
/*  775 */     return this.permittedSubtypesNames;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public IBinaryNestedType[] getMemberTypes() {
/*  781 */     if (this.innerInfos == null) return null;
/*      */     
/*  783 */     int length = this.innerInfos.length - ((this.innerInfo != null) ? 1 : 0);
/*  784 */     if (length != 0) {
/*  785 */       IBinaryNestedType[] memberTypes = 
/*  786 */         new IBinaryNestedType[length];
/*  787 */       int memberTypeIndex = 0; byte b; int i; InnerClassInfo[] arrayOfInnerClassInfo;
/*  788 */       for (i = (arrayOfInnerClassInfo = this.innerInfos).length, b = 0; b < i; ) { InnerClassInfo currentInnerInfo = arrayOfInnerClassInfo[b];
/*  789 */         int outerClassNameIdx = currentInnerInfo.outerClassNameIndex;
/*  790 */         int innerNameIndex = currentInnerInfo.innerNameIndex;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  804 */         if (outerClassNameIdx != 0 && 
/*  805 */           innerNameIndex != 0 && 
/*  806 */           outerClassNameIdx == this.classNameIndex && (
/*  807 */           currentInnerInfo.getSourceName()).length != 0)
/*  808 */           memberTypes[memberTypeIndex++] = currentInnerInfo; 
/*      */         b++; }
/*      */       
/*  811 */       if (memberTypeIndex == 0) return null; 
/*  812 */       if (memberTypeIndex != memberTypes.length)
/*      */       {
/*      */         
/*  815 */         System.arraycopy(
/*  816 */             memberTypes, 
/*  817 */             0, 
/*  818 */             memberTypes = new IBinaryNestedType[memberTypeIndex], 
/*  819 */             0, 
/*  820 */             memberTypeIndex);
/*      */       }
/*  822 */       return memberTypes;
/*      */     } 
/*  824 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public IBinaryMethod[] getMethods() {
/*  833 */     return (IBinaryMethod[])this.methods;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public char[][][] getMissingTypeNames() {
/*  885 */     return this.missingTypeNames;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getModifiers() {
/*      */     int modifiers;
/*  897 */     if (this.innerInfo != null) {
/*  898 */       modifiers = this.innerInfo.getModifiers() | 
/*  899 */         this.accessFlags & 0x100000 | 
/*  900 */         this.accessFlags & 0x1000;
/*      */     } else {
/*  902 */       modifiers = this.accessFlags;
/*      */     } 
/*  904 */     if (this.permittedSubtypesCount > 0)
/*  905 */       modifiers |= 0x10000000; 
/*  906 */     return modifiers;
/*      */   }
/*      */ 
/*      */   
/*      */   public char[] getName() {
/*  911 */     return this.className;
/*      */   }
/*      */ 
/*      */   
/*      */   public char[] getSourceName() {
/*  916 */     if (this.sourceName != null) {
/*  917 */       return this.sourceName;
/*      */     }
/*  919 */     char[] name = getInnerSourceName();
/*  920 */     if (name == null) {
/*  921 */       int start; name = getName();
/*      */       
/*  923 */       if (isAnonymous()) {
/*  924 */         start = CharOperation.indexOf('$', name, CharOperation.lastIndexOf('/', name) + 1) + 1;
/*      */       } else {
/*  926 */         start = CharOperation.lastIndexOf('/', name) + 1;
/*      */       } 
/*  928 */       if (start > 0) {
/*  929 */         char[] newName = new char[name.length - start];
/*  930 */         System.arraycopy(name, start, newName, 0, newName.length);
/*  931 */         name = newName;
/*      */       } 
/*      */     } 
/*  934 */     return this.sourceName = name;
/*      */   }
/*      */ 
/*      */   
/*      */   public char[] getSuperclassName() {
/*  939 */     return this.superclassName;
/*      */   }
/*      */ 
/*      */   
/*      */   public long getTagBits() {
/*  944 */     return this.tagBits;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public long getVersion() {
/*  953 */     return this.version;
/*      */   }
/*      */   
/*      */   private boolean hasNonSyntheticFieldChanges(FieldInfo[] currentFieldInfos, FieldInfo[] otherFieldInfos) {
/*  957 */     int length1 = (currentFieldInfos == null) ? 0 : currentFieldInfos.length;
/*  958 */     int length2 = (otherFieldInfos == null) ? 0 : otherFieldInfos.length;
/*  959 */     int index1 = 0;
/*  960 */     int index2 = 0;
/*      */     
/*  962 */     label36: while (index1 < length1 && index2 < length2) {
/*  963 */       while (currentFieldInfos[index1].isSynthetic()) {
/*  964 */         if (++index1 >= length1)
/*      */           break label36; 
/*  966 */       }  while (otherFieldInfos[index2].isSynthetic()) {
/*  967 */         if (++index2 >= length2)
/*      */           break label36; 
/*  969 */       }  if (hasStructuralFieldChanges(currentFieldInfos[index1++], otherFieldInfos[index2++])) {
/*  970 */         return true;
/*      */       }
/*      */     } 
/*  973 */     while (index1 < length1) {
/*  974 */       if (!currentFieldInfos[index1++].isSynthetic()) return true; 
/*      */     } 
/*  976 */     while (index2 < length2) {
/*  977 */       if (!otherFieldInfos[index2++].isSynthetic()) return true; 
/*      */     } 
/*  979 */     return false;
/*      */   }
/*      */   
/*      */   private boolean hasNonSyntheticMethodChanges(MethodInfo[] currentMethodInfos, MethodInfo[] otherMethodInfos) {
/*  983 */     int length1 = (currentMethodInfos == null) ? 0 : currentMethodInfos.length;
/*  984 */     int length2 = (otherMethodInfos == null) ? 0 : otherMethodInfos.length;
/*  985 */     int index1 = 0;
/*  986 */     int index2 = 0;
/*      */ 
/*      */     
/*  989 */     while (index1 < length1 && index2 < length2) { do {
/*  990 */         MethodInfo m; if (!(m = currentMethodInfos[index1]).isSynthetic() && !m.isClinit())
/*      */         
/*      */         { while (true)
/*  993 */           { if (!(m = otherMethodInfos[index2]).isSynthetic() && !m.isClinit())
/*      */             
/*      */             { 
/*  996 */               if (hasStructuralMethodChanges(currentMethodInfos[index1++], otherMethodInfos[index2++]))
/*  997 */                 return true;  continue; }  if (++index2 >= length2)
/*      */               break;  }  break; } 
/*      */       } while (++index1 < length1); break; }
/* 1000 */      while (index1 < length1) {
/* 1001 */       MethodInfo m; if (!(m = currentMethodInfos[index1++]).isSynthetic() && !m.isClinit()) return true; 
/*      */     } 
/* 1003 */     while (index2 < length2) {
/* 1004 */       MethodInfo m; if (!(m = otherMethodInfos[index2++]).isSynthetic() && !m.isClinit()) return true; 
/*      */     } 
/* 1006 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean hasStructuralChanges(byte[] newBytes) {
/* 1025 */     return hasStructuralChanges(newBytes, true, true);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean hasStructuralChanges(byte[] newBytes, boolean orderRequired, boolean excludesSynthetic) {
/*      */     try {
/* 1046 */       ClassFileReader newClassFile = 
/* 1047 */         new ClassFileReader(newBytes, this.classFileName);
/*      */ 
/*      */       
/* 1050 */       if (getModifiers() != newClassFile.getModifiers()) {
/* 1051 */         return true;
/*      */       }
/*      */ 
/*      */       
/* 1055 */       long OnlyStructuralTagBits = 2333005311180406784L;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1061 */       if ((getTagBits() & OnlyStructuralTagBits) != (newClassFile.getTagBits() & OnlyStructuralTagBits)) {
/* 1062 */         return true;
/*      */       }
/* 1064 */       if (hasStructuralAnnotationChanges(getAnnotations(), newClassFile.getAnnotations()))
/* 1065 */         return true; 
/* 1066 */       if (this.version >= 3407872L && 
/* 1067 */         hasStructuralTypeAnnotationChanges(getTypeAnnotations(), newClassFile.getTypeAnnotations())) {
/* 1068 */         return true;
/*      */       }
/*      */       
/* 1071 */       if (!CharOperation.equals(getGenericSignature(), newClassFile.getGenericSignature())) {
/* 1072 */         return true;
/*      */       }
/* 1074 */       if (!CharOperation.equals(getSuperclassName(), newClassFile.getSuperclassName())) {
/* 1075 */         return true;
/*      */       }
/* 1077 */       char[][] newInterfacesNames = newClassFile.getInterfaceNames();
/* 1078 */       if (this.interfaceNames != newInterfacesNames) {
/* 1079 */         int newInterfacesLength = (newInterfacesNames == null) ? 0 : newInterfacesNames.length;
/* 1080 */         if (newInterfacesLength != this.interfacesCount)
/* 1081 */           return true; 
/* 1082 */         for (int i = 0, max = this.interfacesCount; i < max; i++) {
/* 1083 */           if (!CharOperation.equals(this.interfaceNames[i], newInterfacesNames[i])) {
/* 1084 */             return true;
/*      */           }
/*      */         } 
/*      */       } 
/* 1088 */       char[][] newPermittedSubtypeNames = newClassFile.getPermittedSubtypeNames();
/* 1089 */       if (this.permittedSubtypesNames != newPermittedSubtypeNames) {
/* 1090 */         int newPermittedSubtypesLength = (newPermittedSubtypeNames == null) ? 0 : newPermittedSubtypeNames.length;
/* 1091 */         if (newPermittedSubtypesLength != this.permittedSubtypesCount)
/* 1092 */           return true; 
/* 1093 */         for (int i = 0, max = this.permittedSubtypesCount; i < max; i++) {
/* 1094 */           if (!CharOperation.equals(this.permittedSubtypesNames[i], newPermittedSubtypeNames[i])) {
/* 1095 */             return true;
/*      */           }
/*      */         } 
/*      */       } 
/* 1099 */       IBinaryNestedType[] currentMemberTypes = getMemberTypes();
/* 1100 */       IBinaryNestedType[] otherMemberTypes = newClassFile.getMemberTypes();
/* 1101 */       if (currentMemberTypes != otherMemberTypes) {
/* 1102 */         int currentMemberTypeLength = (currentMemberTypes == null) ? 0 : currentMemberTypes.length;
/* 1103 */         int otherMemberTypeLength = (otherMemberTypes == null) ? 0 : otherMemberTypes.length;
/* 1104 */         if (currentMemberTypeLength != otherMemberTypeLength)
/* 1105 */           return true; 
/* 1106 */         for (int i = 0; i < currentMemberTypeLength; i++) {
/* 1107 */           if (!CharOperation.equals(currentMemberTypes[i].getName(), otherMemberTypes[i].getName()) || 
/* 1108 */             currentMemberTypes[i].getModifiers() != otherMemberTypes[i].getModifiers()) {
/* 1109 */             return true;
/*      */           }
/*      */         } 
/*      */       } 
/* 1113 */       FieldInfo[] otherFieldInfos = (FieldInfo[])newClassFile.getFields();
/* 1114 */       int otherFieldInfosLength = (otherFieldInfos == null) ? 0 : otherFieldInfos.length;
/* 1115 */       boolean compareFields = true;
/* 1116 */       if (this.fieldsCount == otherFieldInfosLength) {
/* 1117 */         int i = 0;
/* 1118 */         for (; i < this.fieldsCount && 
/* 1119 */           !hasStructuralFieldChanges(this.fields[i], otherFieldInfos[i]); i++);
/* 1120 */         if ((compareFields = (i != this.fieldsCount)) && !orderRequired && !excludesSynthetic)
/* 1121 */           return true; 
/*      */       } 
/* 1123 */       if (compareFields) {
/* 1124 */         if (this.fieldsCount != otherFieldInfosLength && !excludesSynthetic)
/* 1125 */           return true; 
/* 1126 */         if (orderRequired) {
/* 1127 */           if (this.fieldsCount != 0)
/* 1128 */             Arrays.sort((Object[])this.fields); 
/* 1129 */           if (otherFieldInfosLength != 0)
/* 1130 */             Arrays.sort((Object[])otherFieldInfos); 
/*      */         } 
/* 1132 */         if (excludesSynthetic) {
/* 1133 */           if (hasNonSyntheticFieldChanges(this.fields, otherFieldInfos))
/* 1134 */             return true; 
/*      */         } else {
/* 1136 */           for (int i = 0; i < this.fieldsCount; i++) {
/* 1137 */             if (hasStructuralFieldChanges(this.fields[i], otherFieldInfos[i])) {
/* 1138 */               return true;
/*      */             }
/*      */           } 
/*      */         } 
/*      */       } 
/* 1143 */       MethodInfo[] otherMethodInfos = (MethodInfo[])newClassFile.getMethods();
/* 1144 */       int otherMethodInfosLength = (otherMethodInfos == null) ? 0 : otherMethodInfos.length;
/* 1145 */       boolean compareMethods = true;
/* 1146 */       if (this.methodsCount == otherMethodInfosLength) {
/* 1147 */         int i = 0;
/* 1148 */         for (; i < this.methodsCount && 
/* 1149 */           !hasStructuralMethodChanges(this.methods[i], otherMethodInfos[i]); i++);
/* 1150 */         if ((compareMethods = (i != this.methodsCount)) && !orderRequired && !excludesSynthetic)
/* 1151 */           return true; 
/*      */       } 
/* 1153 */       if (compareMethods) {
/* 1154 */         if (this.methodsCount != otherMethodInfosLength && !excludesSynthetic)
/* 1155 */           return true; 
/* 1156 */         if (orderRequired) {
/* 1157 */           if (this.methodsCount != 0)
/* 1158 */             Arrays.sort((Object[])this.methods); 
/* 1159 */           if (otherMethodInfosLength != 0)
/* 1160 */             Arrays.sort((Object[])otherMethodInfos); 
/*      */         } 
/* 1162 */         if (excludesSynthetic) {
/* 1163 */           if (hasNonSyntheticMethodChanges(this.methods, otherMethodInfos))
/* 1164 */             return true; 
/*      */         } else {
/* 1166 */           for (int i = 0; i < this.methodsCount; i++) {
/* 1167 */             if (hasStructuralMethodChanges(this.methods[i], otherMethodInfos[i])) {
/* 1168 */               return true;
/*      */             }
/*      */           } 
/*      */         } 
/*      */       } 
/* 1173 */       char[][][] missingTypes = getMissingTypeNames();
/* 1174 */       char[][][] newMissingTypes = newClassFile.getMissingTypeNames();
/* 1175 */       if (missingTypes != null) {
/* 1176 */         if (newMissingTypes == null) {
/* 1177 */           return true;
/*      */         }
/* 1179 */         int length = missingTypes.length;
/* 1180 */         if (length != newMissingTypes.length) {
/* 1181 */           return true;
/*      */         }
/* 1183 */         for (int i = 0; i < length; i++) {
/* 1184 */           if (!CharOperation.equals(missingTypes[i], newMissingTypes[i])) {
/* 1185 */             return true;
/*      */           }
/*      */         } 
/* 1188 */       } else if (newMissingTypes != null) {
/* 1189 */         return true;
/*      */       } 
/* 1191 */       return false;
/* 1192 */     } catch (ClassFormatException classFormatException) {
/* 1193 */       return true;
/*      */     } 
/*      */   }
/*      */   
/*      */   private boolean hasStructuralAnnotationChanges(IBinaryAnnotation[] currentAnnotations, IBinaryAnnotation[] otherAnnotations) {
/* 1198 */     if (currentAnnotations == otherAnnotations) {
/* 1199 */       return false;
/*      */     }
/* 1201 */     int currentAnnotationsLength = (currentAnnotations == null) ? 0 : currentAnnotations.length;
/* 1202 */     int otherAnnotationsLength = (otherAnnotations == null) ? 0 : otherAnnotations.length;
/* 1203 */     if (currentAnnotationsLength != otherAnnotationsLength)
/* 1204 */       return true; 
/* 1205 */     for (int i = 0; i < currentAnnotationsLength; i++) {
/* 1206 */       Boolean match = matchAnnotations(currentAnnotations[i], otherAnnotations[i]);
/* 1207 */       if (match != null)
/* 1208 */         return match.booleanValue(); 
/*      */     } 
/* 1210 */     return false;
/*      */   }
/*      */   private Boolean matchAnnotations(IBinaryAnnotation currentAnnotation, IBinaryAnnotation otherAnnotation) {
/* 1213 */     if (!CharOperation.equals(currentAnnotation.getTypeName(), otherAnnotation.getTypeName()))
/* 1214 */       return Boolean.valueOf(true); 
/* 1215 */     IBinaryElementValuePair[] currentPairs = currentAnnotation.getElementValuePairs();
/* 1216 */     IBinaryElementValuePair[] otherPairs = otherAnnotation.getElementValuePairs();
/* 1217 */     int currentPairsLength = (currentPairs == null) ? 0 : currentPairs.length;
/* 1218 */     int otherPairsLength = (otherPairs == null) ? 0 : otherPairs.length;
/* 1219 */     if (currentPairsLength != otherPairsLength)
/* 1220 */       return Boolean.TRUE; 
/* 1221 */     for (int j = 0; j < currentPairsLength; j++) {
/* 1222 */       if (!CharOperation.equals(currentPairs[j].getName(), otherPairs[j].getName()))
/* 1223 */         return Boolean.TRUE; 
/* 1224 */       Object value = currentPairs[j].getValue();
/* 1225 */       Object value2 = otherPairs[j].getValue();
/* 1226 */       if (value instanceof Object[]) {
/* 1227 */         Object[] currentValues = (Object[])value;
/* 1228 */         if (value2 instanceof Object[]) {
/* 1229 */           Object[] currentValues2 = (Object[])value2;
/* 1230 */           int length = currentValues.length;
/* 1231 */           if (length != currentValues2.length) {
/* 1232 */             return Boolean.TRUE;
/*      */           }
/* 1234 */           for (int n = 0; n < length; n++) {
/* 1235 */             if (!currentValues[n].equals(currentValues2[n])) {
/* 1236 */               return Boolean.TRUE;
/*      */             }
/*      */           } 
/* 1239 */           return Boolean.FALSE;
/*      */         } 
/* 1241 */         return Boolean.TRUE;
/* 1242 */       }  if (!value.equals(value2)) {
/* 1243 */         return Boolean.TRUE;
/*      */       }
/*      */     } 
/* 1246 */     return null;
/*      */   }
/*      */   
/*      */   private boolean hasStructuralFieldChanges(FieldInfo currentFieldInfo, FieldInfo otherFieldInfo) {
/* 1250 */     if (!CharOperation.equals(currentFieldInfo.getGenericSignature(), otherFieldInfo.getGenericSignature()))
/* 1251 */       return true; 
/* 1252 */     if (currentFieldInfo.getModifiers() != otherFieldInfo.getModifiers())
/* 1253 */       return true; 
/* 1254 */     if ((currentFieldInfo.getTagBits() & 0x400000000000L) != (otherFieldInfo.getTagBits() & 0x400000000000L))
/* 1255 */       return true; 
/* 1256 */     if (hasStructuralAnnotationChanges(currentFieldInfo.getAnnotations(), otherFieldInfo.getAnnotations()))
/* 1257 */       return true; 
/* 1258 */     if (this.version >= 3407872L && 
/* 1259 */       hasStructuralTypeAnnotationChanges(currentFieldInfo.getTypeAnnotations(), otherFieldInfo.getTypeAnnotations()))
/* 1260 */       return true; 
/* 1261 */     if (!CharOperation.equals(currentFieldInfo.getName(), otherFieldInfo.getName()))
/* 1262 */       return true; 
/* 1263 */     if (!CharOperation.equals(currentFieldInfo.getTypeName(), otherFieldInfo.getTypeName()))
/* 1264 */       return true; 
/* 1265 */     if (currentFieldInfo.hasConstant() != otherFieldInfo.hasConstant())
/* 1266 */       return true; 
/* 1267 */     if (currentFieldInfo.hasConstant()) {
/* 1268 */       Constant currentConstant = currentFieldInfo.getConstant();
/* 1269 */       Constant otherConstant = otherFieldInfo.getConstant();
/* 1270 */       if (currentConstant.typeID() != otherConstant.typeID())
/* 1271 */         return true; 
/* 1272 */       if (!currentConstant.getClass().equals(otherConstant.getClass()))
/* 1273 */         return true; 
/* 1274 */       switch (currentConstant.typeID()) {
/*      */         case 10:
/* 1276 */           return (currentConstant.intValue() != otherConstant.intValue());
/*      */         case 3:
/* 1278 */           return (currentConstant.byteValue() != otherConstant.byteValue());
/*      */         case 4:
/* 1280 */           return (currentConstant.shortValue() != otherConstant.shortValue());
/*      */         case 2:
/* 1282 */           return (currentConstant.charValue() != otherConstant.charValue());
/*      */         case 7:
/* 1284 */           return (currentConstant.longValue() != otherConstant.longValue());
/*      */         case 9:
/* 1286 */           return (currentConstant.floatValue() != otherConstant.floatValue());
/*      */         case 8:
/* 1288 */           return (currentConstant.doubleValue() != otherConstant.doubleValue());
/*      */         case 5:
/* 1290 */           return currentConstant.booleanValue() ^ otherConstant.booleanValue();
/*      */         case 11:
/* 1292 */           return !currentConstant.stringValue().equals(otherConstant.stringValue());
/*      */       } 
/*      */     } 
/* 1295 */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   private boolean hasStructuralMethodChanges(MethodInfo currentMethodInfo, MethodInfo otherMethodInfo) {
/* 1300 */     if (!CharOperation.equals(currentMethodInfo.getGenericSignature(), otherMethodInfo.getGenericSignature()))
/* 1301 */       return true; 
/* 1302 */     if (currentMethodInfo.getModifiers() != otherMethodInfo.getModifiers())
/* 1303 */       return true; 
/* 1304 */     if ((currentMethodInfo.getTagBits() & 0x400000000000L) != (otherMethodInfo.getTagBits() & 0x400000000000L))
/* 1305 */       return true; 
/* 1306 */     if (hasStructuralAnnotationChanges(currentMethodInfo.getAnnotations(), otherMethodInfo.getAnnotations())) {
/* 1307 */       return true;
/*      */     }
/* 1309 */     int currentAnnotatedParamsCount = currentMethodInfo.getAnnotatedParametersCount();
/* 1310 */     int otherAnnotatedParamsCount = otherMethodInfo.getAnnotatedParametersCount();
/* 1311 */     if (currentAnnotatedParamsCount != otherAnnotatedParamsCount)
/* 1312 */       return true; 
/* 1313 */     for (int i = 0; i < currentAnnotatedParamsCount; i++) {
/* 1314 */       if (hasStructuralAnnotationChanges(currentMethodInfo.getParameterAnnotations(i, this.classFileName), otherMethodInfo.getParameterAnnotations(i, this.classFileName)))
/* 1315 */         return true; 
/*      */     } 
/* 1317 */     if (this.version >= 3407872L && 
/* 1318 */       hasStructuralTypeAnnotationChanges(currentMethodInfo.getTypeAnnotations(), otherMethodInfo.getTypeAnnotations())) {
/* 1319 */       return true;
/*      */     }
/* 1321 */     if (!CharOperation.equals(currentMethodInfo.getSelector(), otherMethodInfo.getSelector()))
/* 1322 */       return true; 
/* 1323 */     if (!CharOperation.equals(currentMethodInfo.getMethodDescriptor(), otherMethodInfo.getMethodDescriptor()))
/* 1324 */       return true; 
/* 1325 */     if (!CharOperation.equals(currentMethodInfo.getGenericSignature(), otherMethodInfo.getGenericSignature())) {
/* 1326 */       return true;
/*      */     }
/* 1328 */     char[][] currentThrownExceptions = currentMethodInfo.getExceptionTypeNames();
/* 1329 */     char[][] otherThrownExceptions = otherMethodInfo.getExceptionTypeNames();
/* 1330 */     if (currentThrownExceptions != otherThrownExceptions) {
/* 1331 */       int currentThrownExceptionsLength = (currentThrownExceptions == null) ? 0 : currentThrownExceptions.length;
/* 1332 */       int otherThrownExceptionsLength = (otherThrownExceptions == null) ? 0 : otherThrownExceptions.length;
/* 1333 */       if (currentThrownExceptionsLength != otherThrownExceptionsLength)
/* 1334 */         return true; 
/* 1335 */       for (int k = 0; k < currentThrownExceptionsLength; k++) {
/* 1336 */         if (!CharOperation.equals(currentThrownExceptions[k], otherThrownExceptions[k]))
/* 1337 */           return true; 
/*      */       } 
/* 1339 */     }  return false;
/*      */   }
/*      */   
/*      */   private boolean hasStructuralTypeAnnotationChanges(IBinaryTypeAnnotation[] currentTypeAnnotations, IBinaryTypeAnnotation[] otherTypeAnnotations) {
/* 1343 */     if (otherTypeAnnotations != null) {
/*      */       
/* 1345 */       int len = otherTypeAnnotations.length;
/* 1346 */       System.arraycopy(otherTypeAnnotations, 0, otherTypeAnnotations = new IBinaryTypeAnnotation[len], 0, len);
/*      */     } 
/* 1348 */     if (currentTypeAnnotations != null) {
/*      */       byte b; int i; IBinaryTypeAnnotation[] arrayOfIBinaryTypeAnnotation;
/* 1350 */       for (i = (arrayOfIBinaryTypeAnnotation = currentTypeAnnotations).length, b = 0; b < i; ) { IBinaryTypeAnnotation currentAnnotation = arrayOfIBinaryTypeAnnotation[b];
/* 1351 */         if (affectsSignature(currentAnnotation)) {
/* 1352 */           if (otherTypeAnnotations == null)
/* 1353 */             return true; 
/* 1354 */           int j = 0; while (true) { if (j >= otherTypeAnnotations.length)
/*      */             {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */               
/* 1361 */               return true; }  IBinaryTypeAnnotation otherAnnotation = otherTypeAnnotations[j]; if (otherAnnotation != null && matchAnnotations(currentAnnotation.getAnnotation(), otherAnnotation.getAnnotation()) == Boolean.TRUE) { otherTypeAnnotations[j] = null; break; }  j++; } 
/*      */         }  b++; }
/*      */     
/* 1364 */     }  if (otherTypeAnnotations != null) {
/* 1365 */       byte b; int i; IBinaryTypeAnnotation[] arrayOfIBinaryTypeAnnotation; for (i = (arrayOfIBinaryTypeAnnotation = otherTypeAnnotations).length, b = 0; b < i; ) { IBinaryTypeAnnotation otherAnnotation = arrayOfIBinaryTypeAnnotation[b];
/* 1366 */         if (affectsSignature(otherAnnotation))
/* 1367 */           return true;  b++; }
/*      */     
/*      */     } 
/* 1370 */     return false;
/*      */   }
/*      */   
/*      */   private boolean affectsSignature(IBinaryTypeAnnotation typeAnnotation) {
/* 1374 */     if (typeAnnotation == null) return false; 
/* 1375 */     int targetType = typeAnnotation.getTargetType();
/* 1376 */     if (targetType >= 64 && targetType <= 75)
/* 1377 */       return false; 
/* 1378 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private void initialize() throws ClassFormatException {
/*      */     try {
/*      */       int i;
/*      */       int max;
/* 1387 */       for (i = 0, max = this.fieldsCount; i < max; i++) {
/* 1388 */         this.fields[i].initialize();
/*      */       }
/* 1390 */       for (i = 0, max = this.methodsCount; i < max; i++) {
/* 1391 */         this.methods[i].initialize();
/*      */       }
/* 1393 */       if (this.innerInfos != null) {
/* 1394 */         for (i = 0, max = this.innerInfos.length; i < max; i++) {
/* 1395 */           this.innerInfos[i].initialize();
/*      */         }
/*      */       }
/* 1398 */       if (this.annotations != null) {
/* 1399 */         for (i = 0, max = this.annotations.length; i < max; i++) {
/* 1400 */           this.annotations[i].initialize();
/*      */         }
/*      */       }
/* 1403 */       getEnclosingMethod();
/* 1404 */       reset();
/* 1405 */     } catch (RuntimeException e) {
/* 1406 */       ClassFormatException exception = new ClassFormatException(e, this.classFileName);
/* 1407 */       throw exception;
/*      */     } 
/*      */   }
/*      */   
/*      */   public boolean isAnonymous() {
/* 1412 */     if (this.innerInfo == null) return false; 
/* 1413 */     char[] innerSourceName = this.innerInfo.getSourceName();
/* 1414 */     return !(innerSourceName != null && innerSourceName.length != 0);
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isBinaryType() {
/* 1419 */     return true;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isLocal() {
/* 1424 */     if (this.innerInfo == null) return false; 
/* 1425 */     if (this.innerInfo.getEnclosingTypeName() != null) return false; 
/* 1426 */     char[] innerSourceName = this.innerInfo.getSourceName();
/* 1427 */     return (innerSourceName != null && innerSourceName.length > 0);
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isMember() {
/* 1432 */     if (this.innerInfo == null) return false; 
/* 1433 */     if (this.innerInfo.getEnclosingTypeName() == null) return false; 
/* 1434 */     char[] innerSourceName = this.innerInfo.getSourceName();
/* 1435 */     return (innerSourceName != null && innerSourceName.length > 0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isNestedType() {
/* 1444 */     return (this.innerInfo != null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public char[] sourceFileName() {
/* 1454 */     return this.sourceFileName;
/*      */   }
/*      */ 
/*      */   
/*      */   public String toString() {
/* 1459 */     ByteArrayOutputStream out = new ByteArrayOutputStream();
/* 1460 */     PrintWriter print = new PrintWriter(out);
/* 1461 */     print.println(String.valueOf(getClass().getName()) + "{");
/* 1462 */     print.println(" this.className: " + new String(getName()));
/* 1463 */     print.println(" this.superclassName: " + ((getSuperclassName() == null) ? "null" : new String(getSuperclassName())));
/* 1464 */     if (this.moduleName != null)
/* 1465 */       print.println(" this.moduleName: " + new String(this.moduleName)); 
/* 1466 */     print.println(" access_flags: " + printTypeModifiers(accessFlags()) + "(" + accessFlags() + ")");
/* 1467 */     print.flush();
/* 1468 */     return out.toString();
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isRecord() {
/* 1473 */     return this.isRecord;
/*      */   }
/*      */ 
/*      */   
/*      */   public IRecordComponent[] getRecordComponents() {
/* 1478 */     return (IRecordComponent[])this.recordComponents;
/*      */   }
/*      */   
/*      */   public URI getURI() {
/* 1482 */     return this.path;
/*      */   }
/*      */   public boolean isStaticInner(char[] innerTypeName) {
/* 1485 */     if (this.innerInfos != null) {
/* 1486 */       byte b; int i; InnerClassInfo[] arrayOfInnerClassInfo; for (i = (arrayOfInnerClassInfo = this.innerInfos).length, b = 0; b < i; ) { InnerClassInfo innerClassInfo = arrayOfInnerClassInfo[b];
/* 1487 */         if (Arrays.equals(innerTypeName, innerClassInfo.getName()))
/* 1488 */           return ((innerClassInfo.getModifiers() & 0x8) != 0); 
/*      */         b++; }
/*      */     
/*      */     } 
/* 1492 */     return false;
/*      */   }
/*      */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\classfmt\ClassFileReader.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */