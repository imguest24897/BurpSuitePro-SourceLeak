/*    */ package org.eclipse.jdt.internal.compiler.ast;
/*    */ 
/*    */ import org.eclipse.jdt.internal.compiler.ASTVisitor;
/*    */ import org.eclipse.jdt.internal.compiler.lookup.Binding;
/*    */ import org.eclipse.jdt.internal.compiler.lookup.BlockScope;
/*    */ import org.eclipse.jdt.internal.compiler.lookup.ClassScope;
/*    */ import org.eclipse.jdt.internal.compiler.lookup.ElementValuePair;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NormalAnnotation
/*    */   extends Annotation
/*    */ {
/*    */   public MemberValuePair[] memberValuePairs;
/*    */   
/*    */   public NormalAnnotation(TypeReference type, int sourceStart) {
/* 27 */     this.type = type;
/* 28 */     this.sourceStart = sourceStart;
/* 29 */     this.sourceEnd = type.sourceEnd;
/*    */   }
/*    */ 
/*    */   
/*    */   public ElementValuePair[] computeElementValuePairs() {
/* 34 */     int numberOfPairs = (this.memberValuePairs == null) ? 0 : this.memberValuePairs.length;
/* 35 */     if (numberOfPairs == 0) {
/* 36 */       return Binding.NO_ELEMENT_VALUE_PAIRS;
/*    */     }
/* 38 */     ElementValuePair[] pairs = new ElementValuePair[numberOfPairs];
/* 39 */     for (int i = 0; i < numberOfPairs; i++)
/* 40 */       pairs[i] = (this.memberValuePairs[i]).compilerElementPair; 
/* 41 */     return pairs;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public MemberValuePair[] memberValuePairs() {
/* 49 */     return (this.memberValuePairs == null) ? NoValuePairs : this.memberValuePairs;
/*    */   }
/*    */   
/*    */   public StringBuffer printExpression(int indent, StringBuffer output) {
/* 53 */     super.printExpression(indent, output);
/* 54 */     output.append('(');
/* 55 */     if (this.memberValuePairs != null) {
/* 56 */       for (int i = 0, max = this.memberValuePairs.length; i < max; i++) {
/* 57 */         if (i > 0) {
/* 58 */           output.append(',');
/*    */         }
/* 60 */         this.memberValuePairs[i].print(indent, output);
/*    */       } 
/*    */     }
/* 63 */     output.append(')');
/* 64 */     return output;
/*    */   }
/*    */ 
/*    */   
/*    */   public void traverse(ASTVisitor visitor, BlockScope scope) {
/* 69 */     if (visitor.visit(this, scope)) {
/* 70 */       if (this.type != null) {
/* 71 */         this.type.traverse(visitor, scope);
/*    */       }
/* 73 */       if (this.memberValuePairs != null) {
/* 74 */         int memberValuePairsLength = this.memberValuePairs.length;
/* 75 */         for (int i = 0; i < memberValuePairsLength; i++)
/* 76 */           this.memberValuePairs[i].traverse(visitor, scope); 
/*    */       } 
/*    */     } 
/* 79 */     visitor.endVisit(this, scope);
/*    */   }
/*    */   
/*    */   public void traverse(ASTVisitor visitor, ClassScope scope) {
/* 83 */     if (visitor.visit(this, scope)) {
/* 84 */       if (this.type != null) {
/* 85 */         this.type.traverse(visitor, scope);
/*    */       }
/* 87 */       if (this.memberValuePairs != null) {
/* 88 */         int memberValuePairsLength = this.memberValuePairs.length;
/* 89 */         for (int i = 0; i < memberValuePairsLength; i++)
/* 90 */           this.memberValuePairs[i].traverse(visitor, scope); 
/*    */       } 
/*    */     } 
/* 93 */     visitor.endVisit(this, scope);
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\ast\NormalAnnotation.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */