/*    */ package org.eclipse.jdt.internal.compiler.ast;
/*    */ 
/*    */ import org.eclipse.jdt.internal.compiler.ASTVisitor;
/*    */ import org.eclipse.jdt.internal.compiler.lookup.BlockScope;
/*    */ import org.eclipse.jdt.internal.compiler.lookup.ClassScope;
/*    */ import org.eclipse.jdt.internal.compiler.lookup.ElementValuePair;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SingleMemberAnnotation
/*    */   extends Annotation
/*    */ {
/*    */   public Expression memberValue;
/*    */   private MemberValuePair[] singlePairs;
/*    */   
/*    */   public SingleMemberAnnotation(TypeReference type, int sourceStart) {
/* 30 */     this.type = type;
/* 31 */     this.sourceStart = sourceStart;
/* 32 */     this.sourceEnd = type.sourceEnd;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public SingleMemberAnnotation() {}
/*    */ 
/*    */   
/*    */   public ElementValuePair[] computeElementValuePairs() {
/* 41 */     return new ElementValuePair[] { (memberValuePairs()[0]).compilerElementPair };
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public MemberValuePair[] memberValuePairs() {
/* 49 */     if (this.singlePairs == null) {
/* 50 */       this.singlePairs = 
/* 51 */         new MemberValuePair[] {
/* 52 */           new MemberValuePair(VALUE, this.memberValue.sourceStart, this.memberValue.sourceEnd, this.memberValue)
/*    */         };
/*    */     }
/* 55 */     return this.singlePairs;
/*    */   }
/*    */ 
/*    */   
/*    */   public StringBuffer printExpression(int indent, StringBuffer output) {
/* 60 */     super.printExpression(indent, output);
/* 61 */     output.append('(');
/* 62 */     this.memberValue.printExpression(indent, output);
/* 63 */     return output.append(')');
/*    */   }
/*    */ 
/*    */   
/*    */   public void traverse(ASTVisitor visitor, BlockScope scope) {
/* 68 */     if (visitor.visit(this, scope)) {
/* 69 */       if (this.type != null) {
/* 70 */         this.type.traverse(visitor, scope);
/*    */       }
/* 72 */       if (this.memberValue != null) {
/* 73 */         this.memberValue.traverse(visitor, scope);
/*    */       }
/*    */     } 
/* 76 */     visitor.endVisit(this, scope);
/*    */   }
/*    */ 
/*    */   
/*    */   public void traverse(ASTVisitor visitor, ClassScope scope) {
/* 81 */     if (visitor.visit(this, scope)) {
/* 82 */       if (this.type != null) {
/* 83 */         this.type.traverse(visitor, scope);
/*    */       }
/* 85 */       if (this.memberValue != null) {
/* 86 */         this.memberValue.traverse(visitor, scope);
/*    */       }
/*    */     } 
/* 89 */     visitor.endVisit(this, scope);
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\ast\SingleMemberAnnotation.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */