/*     */ package org.eclipse.jdt.internal.compiler.ast;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import org.eclipse.jdt.internal.compiler.ASTVisitor;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.BlockScope;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.ClassScope;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.IntersectionTypeBinding18;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.ReferenceBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.Scope;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.TypeBinding;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class IntersectionCastTypeReference
/*     */   extends TypeReference
/*     */ {
/*     */   public TypeReference[] typeReferences;
/*     */   
/*     */   public IntersectionCastTypeReference(TypeReference[] typeReferences) {
/*  37 */     this.typeReferences = typeReferences;
/*  38 */     this.sourceStart = (typeReferences[0]).sourceStart;
/*  39 */     int length = typeReferences.length;
/*  40 */     this.sourceEnd = (typeReferences[length - 1]).sourceEnd;
/*  41 */     for (int i = 0, max = typeReferences.length; i < max; i++) {
/*  42 */       if (((typeReferences[i]).bits & 0x100000) != 0) {
/*  43 */         this.bits |= 0x100000;
/*     */         break;
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public TypeReference augmentTypeWithAdditionalDimensions(int additionalDimensions, Annotation[][] additionalAnnotations, boolean isVarargs) {
/*  51 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   
/*     */   public char[] getLastToken() {
/*  56 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected TypeBinding getTypeBinding(Scope scope) {
/*  64 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public TypeReference[] getTypeReferences() {
/*  69 */     return this.typeReferences;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public TypeBinding resolveType(BlockScope scope, boolean checkBounds, int location) {
/*  75 */     int length = this.typeReferences.length;
/*  76 */     ReferenceBinding[] intersectingTypes = new ReferenceBinding[length];
/*  77 */     boolean hasError = false;
/*     */     
/*  79 */     int typeCount = 0;
/*     */     
/*  81 */     for (int i = 0; i < length; i++) {
/*  82 */       TypeReference typeReference = this.typeReferences[i];
/*  83 */       TypeBinding type = typeReference.resolveType(scope, checkBounds, location);
/*  84 */       if (type == null || (type.tagBits & 0x80L) != 0L) {
/*  85 */         hasError = true;
/*     */         continue;
/*     */       } 
/*  88 */       if (i == 0) {
/*  89 */         if (type.isBaseType()) {
/*  90 */           scope.problemReporter().onlyReferenceTypesInIntersectionCast(typeReference);
/*  91 */           hasError = true;
/*     */           continue;
/*     */         } 
/*  94 */         if (type.isArrayType()) {
/*  95 */           scope.problemReporter().illegalArrayTypeInIntersectionCast(typeReference);
/*  96 */           hasError = true;
/*     */           continue;
/*     */         } 
/*  99 */       } else if (!type.isInterface()) {
/* 100 */         scope.problemReporter().boundMustBeAnInterface(typeReference, type);
/* 101 */         hasError = true;
/*     */         continue;
/*     */       } 
/* 104 */       int k = 0; while (true) { if (k >= typeCount)
/*     */         
/*     */         { 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 120 */           intersectingTypes[typeCount++] = (ReferenceBinding)type; break; }  ReferenceBinding priorType = intersectingTypes[k]; if (TypeBinding.equalsEquals((TypeBinding)priorType, type)) { scope.problemReporter().duplicateBoundInIntersectionCast(typeReference); hasError = true; } else if (priorType.isInterface()) { if (TypeBinding.equalsEquals(type.findSuperTypeOriginatingFrom((TypeBinding)priorType), (TypeBinding)priorType)) { intersectingTypes[k] = (ReferenceBinding)type; break; }  if (TypeBinding.equalsEquals(priorType.findSuperTypeOriginatingFrom(type), type))
/*     */             break;  }  k++; }
/*     */        continue;
/* 123 */     }  if (hasError) {
/* 124 */       return null;
/*     */     }
/* 126 */     if (typeCount != length) {
/* 127 */       if (typeCount == 1) {
/* 128 */         return this.resolvedType = (TypeBinding)intersectingTypes[0];
/*     */       }
/* 130 */       System.arraycopy(intersectingTypes, 0, intersectingTypes = new ReferenceBinding[typeCount], 0, typeCount);
/*     */     } 
/* 132 */     IntersectionTypeBinding18 intersectionType = (IntersectionTypeBinding18)scope.environment().createIntersectionType18(intersectingTypes);
/*     */     
/* 134 */     ReferenceBinding itsSuperclass = null;
/* 135 */     ReferenceBinding[] interfaces = intersectingTypes;
/* 136 */     ReferenceBinding firstType = intersectingTypes[0];
/* 137 */     if (firstType.isClass()) {
/* 138 */       itsSuperclass = firstType.superclass();
/* 139 */       System.arraycopy(intersectingTypes, 1, interfaces = new ReferenceBinding[typeCount - 1], 0, typeCount - 1);
/*     */     } 
/*     */     
/* 142 */     Map<Object, Object> invocations = new HashMap<>(2);
/* 143 */     for (int j = 0, interfaceCount = interfaces.length; j < interfaceCount; j++) {
/* 144 */       ReferenceBinding one = interfaces[j];
/* 145 */       if (one != null && (
/* 146 */         itsSuperclass == null || !scope.hasErasedCandidatesCollisions((TypeBinding)itsSuperclass, (TypeBinding)one, invocations, (ReferenceBinding)intersectionType, this)))
/*     */       {
/* 148 */         for (int k = 0; k < j; k++) {
/* 149 */           ReferenceBinding two = interfaces[k];
/* 150 */           if (two != null && 
/* 151 */             scope.hasErasedCandidatesCollisions((TypeBinding)one, (TypeBinding)two, invocations, (ReferenceBinding)intersectionType, this))
/*     */             break; 
/*     */         }  } 
/*     */     } 
/* 155 */     if ((intersectionType.tagBits & 0x20000L) != 0L) {
/* 156 */       return null;
/*     */     }
/* 158 */     return this.resolvedType = (TypeBinding)intersectionType;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public char[][] getTypeName() {
/* 164 */     return this.typeReferences[0].getTypeName();
/*     */   }
/*     */ 
/*     */   
/*     */   public void traverse(ASTVisitor visitor, BlockScope scope) {
/* 169 */     if (visitor.visit(this, scope)) {
/* 170 */       int length = (this.typeReferences == null) ? 0 : this.typeReferences.length;
/* 171 */       for (int i = 0; i < length; i++) {
/* 172 */         this.typeReferences[i].traverse(visitor, scope);
/*     */       }
/*     */     } 
/* 175 */     visitor.endVisit(this, scope);
/*     */   }
/*     */ 
/*     */   
/*     */   public void traverse(ASTVisitor visitor, ClassScope scope) {
/* 180 */     throw new UnsupportedOperationException("Unexpected traversal request: IntersectionTypeReference in class scope");
/*     */   }
/*     */ 
/*     */   
/*     */   public StringBuffer printExpression(int indent, StringBuffer output) {
/* 185 */     int length = (this.typeReferences == null) ? 0 : this.typeReferences.length;
/* 186 */     printIndent(indent, output);
/* 187 */     for (int i = 0; i < length; i++) {
/* 188 */       this.typeReferences[i].printExpression(0, output);
/* 189 */       if (i != length - 1) {
/* 190 */         output.append(" & ");
/*     */       }
/*     */     } 
/* 193 */     return output;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\ast\IntersectionCastTypeReference.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */