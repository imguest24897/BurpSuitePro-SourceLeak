/*    */ package org.eclipse.jdt.internal.compiler.impl;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class StringConstant
/*    */   extends Constant
/*    */ {
/*    */   private String value;
/*    */   
/*    */   public static Constant fromValue(String value) {
/* 21 */     return new StringConstant(value);
/*    */   }
/*    */   
/*    */   private StringConstant(String value) {
/* 25 */     this.value = value;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String stringValue() {
/* 33 */     return this.value;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String toString() {
/* 41 */     return "(String)\"" + this.value + "\"";
/*    */   }
/*    */ 
/*    */   
/*    */   public int typeID() {
/* 46 */     return 11;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public int hashCode() {
/* 52 */     int result = 1;
/* 53 */     result = 31 * result + ((this.value == null) ? 0 : this.value.hashCode());
/* 54 */     return result;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean equals(Object obj) {
/* 59 */     if (this == obj) {
/* 60 */       return true;
/*    */     }
/* 62 */     if (obj == null) {
/* 63 */       return false;
/*    */     }
/* 65 */     if (getClass() != obj.getClass()) {
/* 66 */       return false;
/*    */     }
/* 68 */     StringConstant other = (StringConstant)obj;
/* 69 */     if (this.value == null) {
/* 70 */       return (other.value == null);
/*    */     }
/* 72 */     return this.value.equals(other.value);
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\impl\StringConstant.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */