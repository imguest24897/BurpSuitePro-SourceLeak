/*      */ package org.eclipse.jdt.internal.compiler.ast;
/*      */ 
/*      */ import org.eclipse.jdt.core.compiler.CharOperation;
/*      */ import org.eclipse.jdt.internal.compiler.ASTVisitor;
/*      */ import org.eclipse.jdt.internal.compiler.codegen.BranchLabel;
/*      */ import org.eclipse.jdt.internal.compiler.codegen.CodeStream;
/*      */ import org.eclipse.jdt.internal.compiler.codegen.ConstantPool;
/*      */ import org.eclipse.jdt.internal.compiler.codegen.ExceptionLabel;
/*      */ import org.eclipse.jdt.internal.compiler.codegen.MultiCatchExceptionLabel;
/*      */ import org.eclipse.jdt.internal.compiler.codegen.StackMapFrameCodeStream;
/*      */ import org.eclipse.jdt.internal.compiler.flow.ExceptionHandlingFlowContext;
/*      */ import org.eclipse.jdt.internal.compiler.flow.FinallyFlowContext;
/*      */ import org.eclipse.jdt.internal.compiler.flow.FlowContext;
/*      */ import org.eclipse.jdt.internal.compiler.flow.FlowInfo;
/*      */ import org.eclipse.jdt.internal.compiler.flow.InsideSubRoutineFlowContext;
/*      */ import org.eclipse.jdt.internal.compiler.flow.UnconditionalFlowInfo;
/*      */ import org.eclipse.jdt.internal.compiler.impl.CompilerOptions;
/*      */ import org.eclipse.jdt.internal.compiler.impl.Constant;
/*      */ import org.eclipse.jdt.internal.compiler.lookup.Binding;
/*      */ import org.eclipse.jdt.internal.compiler.lookup.BlockScope;
/*      */ import org.eclipse.jdt.internal.compiler.lookup.InvocationSite;
/*      */ import org.eclipse.jdt.internal.compiler.lookup.LocalVariableBinding;
/*      */ import org.eclipse.jdt.internal.compiler.lookup.MethodBinding;
/*      */ import org.eclipse.jdt.internal.compiler.lookup.MethodScope;
/*      */ import org.eclipse.jdt.internal.compiler.lookup.ProblemReferenceBinding;
/*      */ import org.eclipse.jdt.internal.compiler.lookup.ReferenceBinding;
/*      */ import org.eclipse.jdt.internal.compiler.lookup.Scope;
/*      */ import org.eclipse.jdt.internal.compiler.lookup.TypeBinding;
/*      */ import org.eclipse.jdt.internal.compiler.lookup.VariableBinding;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class TryStatement
/*      */   extends SubRoutineStatement
/*      */ {
/*   47 */   static final char[] SECRET_RETURN_ADDRESS_NAME = " returnAddress".toCharArray();
/*   48 */   static final char[] SECRET_ANY_HANDLER_NAME = " anyExceptionHandler".toCharArray();
/*   49 */   static final char[] SECRET_PRIMARY_EXCEPTION_VARIABLE_NAME = " primaryException".toCharArray();
/*   50 */   static final char[] SECRET_CAUGHT_THROWABLE_VARIABLE_NAME = " caughtThrowable".toCharArray();
/*   51 */   static final char[] SECRET_RETURN_VALUE_NAME = " returnValue".toCharArray();
/*      */   
/*   53 */   public Statement[] resources = new Statement[0];
/*      */   
/*      */   public Block tryBlock;
/*      */   
/*      */   public Block[] catchBlocks;
/*      */   
/*      */   public Argument[] catchArguments;
/*      */   
/*      */   public Block finallyBlock;
/*      */   
/*      */   BlockScope scope;
/*      */   
/*      */   public UnconditionalFlowInfo subRoutineInits;
/*      */   
/*      */   ReferenceBinding[] caughtExceptionTypes;
/*      */   boolean[] catchExits;
/*      */   BranchLabel subRoutineStartLabel;
/*      */   public LocalVariableBinding anyExceptionVariable;
/*      */   public LocalVariableBinding returnAddressVariable;
/*      */   public LocalVariableBinding secretReturnValue;
/*      */   ExceptionLabel[] declaredExceptionLabels;
/*      */   private Object[] reusableJSRTargets;
/*      */   private BranchLabel[] reusableJSRSequenceStartLabels;
/*      */   private int[] reusableJSRStateIndexes;
/*   77 */   private int reusableJSRTargetsCount = 0;
/*      */   
/*      */   private static final int NO_FINALLY = 0;
/*      */   
/*      */   private static final int FINALLY_SUBROUTINE = 1;
/*      */   
/*      */   private static final int FINALLY_DOES_NOT_COMPLETE = 2;
/*      */   private static final int FINALLY_INLINE = 3;
/*   85 */   int mergedInitStateIndex = -1;
/*   86 */   int preTryInitStateIndex = -1;
/*   87 */   int postTryInitStateIndex = -1;
/*      */   int[] postResourcesInitStateIndexes;
/*   89 */   int naturalExitMergeInitStateIndex = -1;
/*      */   
/*      */   int[] catchExitInitStateIndexes;
/*      */   private LocalVariableBinding primaryExceptionVariable;
/*      */   private LocalVariableBinding caughtThrowableVariable;
/*      */   private ExceptionLabel[] resourceExceptionLabels;
/*      */   private int[] caughtExceptionsCatchBlocks;
/*   96 */   public SwitchExpression enclosingSwitchExpression = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public FlowInfo analyseCode(BlockScope currentScope, FlowContext flowContext, FlowInfo flowInfo) {
/*      */     UnconditionalFlowInfo unconditionalFlowInfo1;
/*  107 */     this.preTryInitStateIndex = 
/*  108 */       currentScope.methodScope().recordInitializationStates(flowInfo);
/*      */     
/*  110 */     if (this.anyExceptionVariable != null) {
/*  111 */       this.anyExceptionVariable.useFlag = 1;
/*      */     }
/*  113 */     if (this.primaryExceptionVariable != null) {
/*  114 */       this.primaryExceptionVariable.useFlag = 1;
/*      */     }
/*  116 */     if (this.caughtThrowableVariable != null) {
/*  117 */       this.caughtThrowableVariable.useFlag = 1;
/*      */     }
/*  119 */     if (this.returnAddressVariable != null) {
/*  120 */       this.returnAddressVariable.useFlag = 1;
/*      */     }
/*  122 */     int resourcesLength = this.resources.length;
/*  123 */     if (resourcesLength > 0) {
/*  124 */       this.postResourcesInitStateIndexes = new int[resourcesLength];
/*      */     }
/*      */ 
/*      */     
/*  128 */     if (this.subRoutineStartLabel == null) {
/*      */       UnconditionalFlowInfo unconditionalFlowInfo;
/*  130 */       if (flowContext instanceof FinallyFlowContext) {
/*      */ 
/*      */         
/*  133 */         FinallyFlowContext finallyFlowContext = (FinallyFlowContext)flowContext;
/*  134 */         finallyFlowContext.outerTryContext = finallyFlowContext.tryContext;
/*      */       } 
/*      */       
/*  137 */       ExceptionHandlingFlowContext exceptionHandlingFlowContext = 
/*  138 */         new ExceptionHandlingFlowContext(
/*  139 */           flowContext, 
/*  140 */           this, 
/*  141 */           this.caughtExceptionTypes, 
/*  142 */           this.caughtExceptionsCatchBlocks, 
/*  143 */           null, 
/*  144 */           this.scope, 
/*  145 */           flowInfo);
/*  146 */       exceptionHandlingFlowContext.conditionalLevel = 0;
/*      */ 
/*      */ 
/*      */       
/*  150 */       FlowInfo flowInfo1 = flowInfo.copy(); int j;
/*  151 */       for (j = 0; j < resourcesLength; j++) {
/*  152 */         Statement resource = this.resources[j];
/*  153 */         flowInfo1 = resource.analyseCode(currentScope, (FlowContext)exceptionHandlingFlowContext, flowInfo1);
/*  154 */         this.postResourcesInitStateIndexes[j] = currentScope.methodScope().recordInitializationStates(flowInfo1);
/*  155 */         TypeBinding resolvedType = null;
/*  156 */         LocalVariableBinding localVariableBinding = null;
/*  157 */         if (resource instanceof LocalDeclaration) {
/*  158 */           localVariableBinding = ((LocalDeclaration)resource).binding;
/*  159 */           resolvedType = localVariableBinding.type;
/*  160 */           if (localVariableBinding.closeTracker != null) {
/*      */             
/*  162 */             localVariableBinding.closeTracker.withdraw();
/*  163 */             localVariableBinding.closeTracker = null;
/*      */           } 
/*      */         } else {
/*  166 */           if (resource instanceof NameReference && ((NameReference)resource).binding instanceof LocalVariableBinding) {
/*  167 */             localVariableBinding = (LocalVariableBinding)((NameReference)resource).binding;
/*      */           }
/*  169 */           resolvedType = ((Expression)resource).resolvedType;
/*  170 */           recordCallingClose(currentScope, flowContext, flowInfo1, (Expression)resource);
/*      */         } 
/*  172 */         if (localVariableBinding != null) {
/*  173 */           localVariableBinding.useFlag = 1;
/*      */         }
/*  175 */         MethodBinding closeMethod = findCloseMethod(resource, resolvedType);
/*  176 */         if (closeMethod != null && closeMethod.isValidBinding() && closeMethod.returnType.id == 6) {
/*  177 */           ReferenceBinding[] thrownExceptions = closeMethod.thrownExceptions;
/*  178 */           for (int k = 0, length = thrownExceptions.length; k < length; k++) {
/*  179 */             exceptionHandlingFlowContext.checkExceptionHandlers((TypeBinding)thrownExceptions[k], this.resources[j], flowInfo1, currentScope, true);
/*      */           }
/*      */         } 
/*      */       } 
/*  183 */       if (!this.tryBlock.isEmptyBlock()) {
/*  184 */         flowInfo1 = this.tryBlock.analyseCode(currentScope, (FlowContext)exceptionHandlingFlowContext, flowInfo1);
/*  185 */         if ((flowInfo1.tagBits & 0x1) != 0)
/*  186 */           this.bits |= 0x20000000; 
/*      */       } 
/*  188 */       if (resourcesLength > 0) {
/*  189 */         this.postTryInitStateIndex = currentScope.methodScope().recordInitializationStates(flowInfo1);
/*      */ 
/*      */ 
/*      */         
/*  193 */         for (j = 0; j < resourcesLength; j++) {
/*  194 */           if (this.resources[j] instanceof LocalDeclaration) {
/*  195 */             flowInfo1.resetAssignmentInfo(((LocalDeclaration)this.resources[j]).binding);
/*      */           }
/*      */         } 
/*      */       } 
/*  199 */       exceptionHandlingFlowContext.complainIfUnusedExceptionHandlers(this.scope, this);
/*      */ 
/*      */       
/*  202 */       if (this.catchArguments != null) {
/*      */         int catchCount;
/*  204 */         this.catchExits = new boolean[catchCount = this.catchBlocks.length];
/*  205 */         this.catchExitInitStateIndexes = new int[catchCount];
/*  206 */         for (int k = 0; k < catchCount; k++) {
/*      */           
/*  208 */           FlowInfo catchInfo = prepareCatchInfo(flowInfo, exceptionHandlingFlowContext, flowInfo1, k);
/*  209 */           flowContext.conditionalLevel++;
/*  210 */           catchInfo = 
/*  211 */             this.catchBlocks[k].analyseCode(
/*  212 */               currentScope, 
/*  213 */               flowContext, 
/*  214 */               catchInfo);
/*  215 */           flowContext.conditionalLevel--;
/*  216 */           this.catchExitInitStateIndexes[k] = currentScope.methodScope().recordInitializationStates(catchInfo);
/*  217 */           this.catchExits[k] = 
/*  218 */             ((catchInfo.tagBits & 0x1) != 0);
/*  219 */           unconditionalFlowInfo = flowInfo1.mergedWith(catchInfo.unconditionalInits());
/*      */         } 
/*      */       } 
/*  222 */       this.mergedInitStateIndex = 
/*  223 */         currentScope.methodScope().recordInitializationStates((FlowInfo)unconditionalFlowInfo);
/*      */ 
/*      */       
/*  226 */       flowContext.mergeFinallyNullInfo(exceptionHandlingFlowContext.initsOnFinally);
/*      */       
/*  228 */       return (FlowInfo)unconditionalFlowInfo;
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  234 */     InsideSubRoutineFlowContext insideSubContext = new InsideSubRoutineFlowContext(flowContext, this);
/*  235 */     if (flowContext instanceof FinallyFlowContext)
/*      */     {
/*      */       
/*  238 */       insideSubContext.outerTryContext = ((FinallyFlowContext)flowContext).tryContext;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*  243 */     ExceptionHandlingFlowContext handlingContext = 
/*  244 */       new ExceptionHandlingFlowContext(
/*  245 */         (FlowContext)insideSubContext, 
/*  246 */         this, 
/*  247 */         this.caughtExceptionTypes, 
/*  248 */         this.caughtExceptionsCatchBlocks, 
/*  249 */         null, 
/*  250 */         this.scope, 
/*  251 */         flowInfo);
/*  252 */     insideSubContext.initsOnFinally = handlingContext.initsOnFinally;
/*      */     FinallyFlowContext finallyContext;
/*  254 */     UnconditionalFlowInfo subInfo = 
/*  255 */       this.finallyBlock
/*  256 */       .analyseCode(
/*  257 */         currentScope, 
/*  258 */         (FlowContext)(finallyContext = new FinallyFlowContext(flowContext, this.finallyBlock, handlingContext)), 
/*  259 */         (FlowInfo)flowInfo.nullInfoLessUnconditionalCopy())
/*  260 */       .unconditionalInits();
/*  261 */     handlingContext.conditionalLevel = 0;
/*  262 */     if (subInfo == FlowInfo.DEAD_END) {
/*  263 */       this.bits |= 0x4000;
/*  264 */       this.scope.problemReporter().finallyMustCompleteNormally(this.finallyBlock);
/*      */     } else {
/*      */       
/*  267 */       FlowInfo finallyInfo = subInfo.copy();
/*  268 */       this.tryBlock.scope.finallyInfo = finallyInfo;
/*  269 */       if (this.catchBlocks != null)
/*  270 */         for (int j = 0; j < this.catchBlocks.length; j++) {
/*  271 */           (this.catchBlocks[j]).scope.finallyInfo = finallyInfo;
/*      */         } 
/*      */     } 
/*  274 */     this.subRoutineInits = subInfo;
/*      */ 
/*      */ 
/*      */     
/*  278 */     FlowInfo tryInfo = flowInfo.copy(); int i;
/*  279 */     for (i = 0; i < resourcesLength; i++) {
/*  280 */       Statement resource = this.resources[i];
/*  281 */       tryInfo = resource.analyseCode(currentScope, (FlowContext)handlingContext, tryInfo);
/*  282 */       this.postResourcesInitStateIndexes[i] = currentScope.methodScope().recordInitializationStates(tryInfo);
/*  283 */       TypeBinding resolvedType = null;
/*  284 */       LocalVariableBinding localVariableBinding = null;
/*  285 */       if (resource instanceof LocalDeclaration) {
/*  286 */         localVariableBinding = ((LocalDeclaration)this.resources[i]).binding;
/*  287 */         resolvedType = localVariableBinding.type;
/*  288 */         if (localVariableBinding.closeTracker != null)
/*      */         {
/*  290 */           localVariableBinding.closeTracker.withdraw();
/*      */         }
/*      */       } else {
/*      */         
/*  294 */         if (resource instanceof NameReference && ((NameReference)resource).binding instanceof LocalVariableBinding) {
/*  295 */           localVariableBinding = (LocalVariableBinding)((NameReference)resource).binding;
/*      */         }
/*  297 */         recordCallingClose(currentScope, flowContext, tryInfo, (Expression)resource);
/*  298 */         resolvedType = ((Expression)resource).resolvedType;
/*      */       } 
/*  300 */       if (localVariableBinding != null) {
/*  301 */         localVariableBinding.useFlag = 1;
/*      */       }
/*  303 */       MethodBinding closeMethod = findCloseMethod(resource, resolvedType);
/*  304 */       if (closeMethod != null && closeMethod.isValidBinding() && closeMethod.returnType.id == 6) {
/*  305 */         ReferenceBinding[] thrownExceptions = closeMethod.thrownExceptions;
/*  306 */         for (int j = 0, length = thrownExceptions.length; j < length; j++) {
/*  307 */           handlingContext.checkExceptionHandlers((TypeBinding)thrownExceptions[j], this.resources[i], tryInfo, currentScope, true);
/*      */         }
/*      */       } 
/*      */     } 
/*  311 */     if (!this.tryBlock.isEmptyBlock()) {
/*  312 */       tryInfo = this.tryBlock.analyseCode(currentScope, (FlowContext)handlingContext, tryInfo);
/*  313 */       if ((tryInfo.tagBits & 0x1) != 0)
/*  314 */         this.bits |= 0x20000000; 
/*      */     } 
/*  316 */     if (resourcesLength > 0) {
/*  317 */       this.postTryInitStateIndex = currentScope.methodScope().recordInitializationStates(tryInfo);
/*      */ 
/*      */ 
/*      */       
/*  321 */       for (i = 0; i < resourcesLength; i++) {
/*  322 */         if (this.resources[i] instanceof LocalDeclaration) {
/*  323 */           tryInfo.resetAssignmentInfo(((LocalDeclaration)this.resources[i]).binding);
/*      */         }
/*      */       } 
/*      */     } 
/*  327 */     handlingContext.complainIfUnusedExceptionHandlers(this.scope, this);
/*      */ 
/*      */     
/*  330 */     if (this.catchArguments != null) {
/*      */       int catchCount;
/*  332 */       this.catchExits = new boolean[catchCount = this.catchBlocks.length];
/*  333 */       this.catchExitInitStateIndexes = new int[catchCount];
/*  334 */       for (int j = 0; j < catchCount; j++) {
/*      */         
/*  336 */         FlowInfo catchInfo = prepareCatchInfo(flowInfo, handlingContext, tryInfo, j);
/*  337 */         insideSubContext.conditionalLevel = 1;
/*  338 */         catchInfo = 
/*  339 */           this.catchBlocks[j].analyseCode(
/*  340 */             currentScope, 
/*  341 */             (FlowContext)insideSubContext, 
/*  342 */             catchInfo);
/*  343 */         this.catchExitInitStateIndexes[j] = currentScope.methodScope().recordInitializationStates(catchInfo);
/*  344 */         this.catchExits[j] = 
/*  345 */           ((catchInfo.tagBits & 0x1) != 0);
/*  346 */         unconditionalFlowInfo1 = tryInfo.mergedWith(catchInfo.unconditionalInits());
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/*  351 */     finallyContext.complainOnDeferredChecks((
/*  352 */         ((((FlowInfo)unconditionalFlowInfo1).tagBits & 0x3) == 0) ? 
/*  353 */         flowInfo.unconditionalCopy()
/*  354 */         .addPotentialInitializationsFrom((FlowInfo)unconditionalFlowInfo1)
/*      */ 
/*      */         
/*  357 */         .addPotentialInitializationsFrom((FlowInfo)insideSubContext.initsOnReturn) : 
/*  358 */         insideSubContext.initsOnReturn)
/*  359 */         .addNullInfoFrom(
/*  360 */           handlingContext.initsOnFinally), 
/*  361 */         currentScope);
/*      */ 
/*      */     
/*  364 */     flowContext.mergeFinallyNullInfo(handlingContext.initsOnFinally);
/*      */     
/*  366 */     this.naturalExitMergeInitStateIndex = 
/*  367 */       currentScope.methodScope().recordInitializationStates((FlowInfo)unconditionalFlowInfo1);
/*  368 */     if (subInfo == FlowInfo.DEAD_END) {
/*  369 */       this.mergedInitStateIndex = 
/*  370 */         currentScope.methodScope().recordInitializationStates((FlowInfo)subInfo);
/*  371 */       return (FlowInfo)subInfo;
/*      */     } 
/*  373 */     FlowInfo mergedInfo = unconditionalFlowInfo1.addInitializationsFrom((FlowInfo)subInfo);
/*  374 */     this.mergedInitStateIndex = 
/*  375 */       currentScope.methodScope().recordInitializationStates(mergedInfo);
/*  376 */     return mergedInfo;
/*      */   }
/*      */ 
/*      */   
/*      */   private void recordCallingClose(BlockScope currentScope, FlowContext flowContext, FlowInfo flowInfo, Expression closeTarget) {
/*  381 */     FakedTrackingVariable trackingVariable = FakedTrackingVariable.getCloseTrackingVariable(closeTarget, flowInfo, flowContext);
/*  382 */     if (trackingVariable != null) {
/*  383 */       if (trackingVariable.methodScope == currentScope.methodScope()) {
/*  384 */         trackingVariable.markClose(flowInfo, flowContext);
/*      */       } else {
/*  386 */         trackingVariable.markClosedInNestedMethod();
/*      */       } 
/*  388 */       trackingVariable.markClosedEffectivelyFinal();
/*      */     } 
/*      */   }
/*      */   private MethodBinding findCloseMethod(ASTNode resource, TypeBinding type) {
/*  392 */     MethodBinding closeMethod = null;
/*  393 */     if (type != null && type.isValidBinding() && type instanceof ReferenceBinding) {
/*  394 */       ReferenceBinding binding = (ReferenceBinding)type;
/*  395 */       closeMethod = binding.getExactMethod(ConstantPool.Close, new TypeBinding[0], this.scope.compilationUnitScope());
/*  396 */       if (closeMethod == null) {
/*      */ 
/*      */ 
/*      */         
/*  400 */         InvocationSite.EmptyWithAstNode emptyWithAstNode = new InvocationSite.EmptyWithAstNode(resource);
/*  401 */         closeMethod = this.scope.compilationUnitScope().findMethod(binding, ConstantPool.Close, new TypeBinding[0], (InvocationSite)emptyWithAstNode, false);
/*      */       } 
/*      */     } 
/*  404 */     return closeMethod;
/*      */   }
/*      */   private FlowInfo prepareCatchInfo(FlowInfo flowInfo, ExceptionHandlingFlowContext handlingContext, FlowInfo tryInfo, int i) {
/*      */     FlowInfo catchInfo;
/*  408 */     if (isUncheckedCatchBlock(i)) {
/*  409 */       catchInfo = 
/*  410 */         flowInfo.unconditionalCopy()
/*  411 */         .addPotentialInitializationsFrom(
/*  412 */           (FlowInfo)handlingContext.initsOnException(i))
/*  413 */         .addPotentialInitializationsFrom(tryInfo)
/*  414 */         .addPotentialInitializationsFrom(
/*  415 */           (FlowInfo)handlingContext.initsOnReturn)
/*  416 */         .addNullInfoFrom(handlingContext.initsOnFinally);
/*      */     } else {
/*  418 */       UnconditionalFlowInfo unconditionalFlowInfo = handlingContext.initsOnException(i);
/*  419 */       catchInfo = 
/*  420 */         flowInfo.nullInfoLessUnconditionalCopy()
/*  421 */         .addPotentialInitializationsFrom((FlowInfo)unconditionalFlowInfo)
/*  422 */         .addNullInfoFrom((FlowInfo)unconditionalFlowInfo)
/*  423 */         .addPotentialInitializationsFrom(
/*  424 */           (FlowInfo)tryInfo.nullInfoLessUnconditionalCopy())
/*  425 */         .addPotentialInitializationsFrom(
/*  426 */           (FlowInfo)handlingContext.initsOnReturn.nullInfoLessUnconditionalCopy());
/*      */     } 
/*      */ 
/*      */     
/*  430 */     LocalVariableBinding catchArg = (this.catchArguments[i]).binding;
/*  431 */     catchInfo.markAsDefinitelyAssigned(catchArg);
/*  432 */     catchInfo.markAsDefinitelyNonNull(catchArg);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  440 */     if (this.tryBlock.statements == null && this.resources == null) {
/*  441 */       catchInfo.setReachMode(1);
/*      */     }
/*  443 */     return catchInfo;
/*      */   }
/*      */   
/*      */   private boolean isUncheckedCatchBlock(int catchBlock) {
/*  447 */     if (this.caughtExceptionsCatchBlocks == null) {
/*  448 */       return this.caughtExceptionTypes[catchBlock].isUncheckedException(true);
/*      */     }
/*  450 */     for (int i = 0, length = this.caughtExceptionsCatchBlocks.length; i < length; i++) {
/*  451 */       if (this.caughtExceptionsCatchBlocks[i] == catchBlock && 
/*  452 */         this.caughtExceptionTypes[i].isUncheckedException(true)) {
/*  453 */         return true;
/*      */       }
/*      */     } 
/*      */     
/*  457 */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   public ExceptionLabel enterAnyExceptionHandler(CodeStream codeStream) {
/*  462 */     if (this.subRoutineStartLabel == null)
/*  463 */       return null; 
/*  464 */     return super.enterAnyExceptionHandler(codeStream);
/*      */   }
/*      */ 
/*      */   
/*      */   public void enterDeclaredExceptionHandlers(CodeStream codeStream) {
/*  469 */     for (int i = 0, length = (this.declaredExceptionLabels == null) ? 0 : this.declaredExceptionLabels.length; i < length; i++) {
/*  470 */       this.declaredExceptionLabels[i].placeStart();
/*      */     }
/*  472 */     int resourceCount = this.resources.length;
/*  473 */     if (resourceCount > 0 && this.resourceExceptionLabels != null)
/*      */     {
/*  475 */       for (int j = resourceCount; j >= 0; j--) {
/*  476 */         this.resourceExceptionLabels[j].placeStart();
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   public void exitAnyExceptionHandler() {
/*  483 */     if (this.subRoutineStartLabel == null)
/*      */       return; 
/*  485 */     super.exitAnyExceptionHandler();
/*      */   }
/*      */ 
/*      */   
/*      */   public void exitDeclaredExceptionHandlers(CodeStream codeStream) {
/*  490 */     for (int i = 0, length = (this.declaredExceptionLabels == null) ? 0 : this.declaredExceptionLabels.length; i < length; i++) {
/*  491 */       this.declaredExceptionLabels[i].placeEnd();
/*      */     }
/*      */   }
/*      */   
/*      */   private int finallyMode() {
/*  496 */     if (this.subRoutineStartLabel == null)
/*  497 */       return 0; 
/*  498 */     if (isSubRoutineEscaping())
/*  499 */       return 2; 
/*  500 */     if ((this.scope.compilerOptions()).inlineJsrBytecode) {
/*  501 */       return 3;
/*      */     }
/*  503 */     return 1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void generateCode(BlockScope currentScope, CodeStream codeStream) {
/*      */     ExceptionLabel[] exceptionLabels;
/*  513 */     if ((this.bits & Integer.MIN_VALUE) == 0) {
/*      */       return;
/*      */     }
/*  516 */     boolean isStackMapFrameCodeStream = codeStream instanceof StackMapFrameCodeStream;
/*      */ 
/*      */     
/*  519 */     this.anyExceptionLabel = null;
/*  520 */     this.reusableJSRTargets = null;
/*  521 */     this.reusableJSRSequenceStartLabels = null;
/*  522 */     this.reusableJSRTargetsCount = 0;
/*      */     
/*  524 */     int pc = codeStream.position;
/*  525 */     int finallyMode = finallyMode();
/*      */     
/*  527 */     boolean requiresNaturalExit = false;
/*      */     
/*  529 */     int maxCatches = (this.catchArguments == null) ? 0 : this.catchArguments.length;
/*      */     
/*  531 */     if (maxCatches > 0) {
/*  532 */       exceptionLabels = new ExceptionLabel[maxCatches];
/*  533 */       for (int i = 0; i < maxCatches; i++) {
/*  534 */         Argument argument = this.catchArguments[i];
/*  535 */         ExceptionLabel exceptionLabel = null;
/*  536 */         if ((argument.binding.tagBits & 0x1000L) != 0L) {
/*  537 */           MultiCatchExceptionLabel multiCatchExceptionLabel = new MultiCatchExceptionLabel(codeStream, argument.binding.type);
/*  538 */           multiCatchExceptionLabel.initialize((UnionTypeReference)argument.type, argument.annotations);
/*  539 */           MultiCatchExceptionLabel multiCatchExceptionLabel1 = multiCatchExceptionLabel;
/*      */         } else {
/*  541 */           exceptionLabel = new ExceptionLabel(codeStream, argument.binding.type, argument.type, argument.annotations);
/*      */         } 
/*  543 */         exceptionLabel.placeStart();
/*  544 */         exceptionLabels[i] = exceptionLabel;
/*      */       } 
/*      */     } else {
/*  547 */       exceptionLabels = null;
/*      */     } 
/*  549 */     if (this.subRoutineStartLabel != null) {
/*  550 */       this.subRoutineStartLabel.initialize(codeStream);
/*  551 */       enterAnyExceptionHandler(codeStream);
/*      */     } 
/*      */     
/*      */     try {
/*  555 */       this.declaredExceptionLabels = exceptionLabels;
/*  556 */       int resourceCount = this.resources.length;
/*  557 */       if (resourceCount > 0) {
/*      */         
/*  559 */         this.resourceExceptionLabels = new ExceptionLabel[resourceCount + 1];
/*  560 */         codeStream.aconst_null();
/*  561 */         codeStream.store(this.primaryExceptionVariable, false);
/*  562 */         codeStream.addVariable(this.primaryExceptionVariable);
/*  563 */         codeStream.aconst_null();
/*  564 */         codeStream.store(this.caughtThrowableVariable, false);
/*  565 */         codeStream.addVariable(this.caughtThrowableVariable);
/*  566 */         for (int i = 0; i <= resourceCount; i++) {
/*      */           
/*  568 */           this.resourceExceptionLabels[i] = new ExceptionLabel(codeStream, null);
/*  569 */           this.resourceExceptionLabels[i].placeStart();
/*  570 */           if (i < resourceCount) {
/*  571 */             Statement stmt = this.resources[i];
/*  572 */             if (stmt instanceof NameReference) {
/*  573 */               NameReference ref = (NameReference)stmt;
/*  574 */               ref.bits |= 0x80000;
/*  575 */               VariableBinding binding = (VariableBinding)ref.binding;
/*  576 */               ref.checkEffectiveFinality(binding, (Scope)this.scope);
/*  577 */             } else if (stmt instanceof FieldReference) {
/*  578 */               FieldReference fieldReference = (FieldReference)stmt;
/*  579 */               if (!fieldReference.binding.isFinal())
/*  580 */                 this.scope.problemReporter().cannotReferToNonFinalField((VariableBinding)fieldReference.binding, fieldReference); 
/*      */             } 
/*  582 */             stmt.generateCode(this.scope, codeStream);
/*      */           } 
/*      */         } 
/*      */       } 
/*  586 */       this.tryBlock.generateCode(this.scope, codeStream);
/*  587 */       if (resourceCount > 0) {
/*  588 */         for (int i = resourceCount; i >= 0; i--) {
/*  589 */           BranchLabel exitLabel = new BranchLabel(codeStream);
/*  590 */           this.resourceExceptionLabels[i].placeEnd();
/*      */           
/*  592 */           Statement stmt = (i > 0) ? this.resources[i - 1] : null;
/*  593 */           if ((this.bits & 0x20000000) == 0) {
/*      */             
/*  595 */             if (i > 0) {
/*  596 */               int invokeCloseStartPc = codeStream.position;
/*  597 */               if (this.postTryInitStateIndex != -1) {
/*      */ 
/*      */ 
/*      */                 
/*  601 */                 codeStream.removeNotDefinitelyAssignedVariables((Scope)currentScope, this.postTryInitStateIndex);
/*  602 */                 codeStream.addDefinitelyAssignedVariables((Scope)currentScope, this.postTryInitStateIndex);
/*      */               } 
/*  604 */               generateCodeSnippet(stmt, codeStream, exitLabel, false, new int[0]);
/*  605 */               codeStream.recordPositionsFrom(invokeCloseStartPc, this.tryBlock.sourceEnd);
/*      */             } 
/*  607 */             codeStream.goto_(exitLabel);
/*      */           } 
/*      */           
/*  610 */           if (i > 0) {
/*      */             
/*  612 */             codeStream.removeNotDefinitelyAssignedVariables((Scope)currentScope, this.postResourcesInitStateIndexes[i - 1]);
/*  613 */             codeStream.addDefinitelyAssignedVariables((Scope)currentScope, this.postResourcesInitStateIndexes[i - 1]);
/*      */           } else {
/*      */             
/*  616 */             codeStream.removeNotDefinitelyAssignedVariables((Scope)currentScope, this.preTryInitStateIndex);
/*  617 */             codeStream.addDefinitelyAssignedVariables((Scope)currentScope, this.preTryInitStateIndex);
/*      */           } 
/*      */           
/*  620 */           codeStream.pushExceptionOnStack((TypeBinding)this.scope.getJavaLangThrowable());
/*  621 */           this.resourceExceptionLabels[i].place();
/*  622 */           if (i == resourceCount) {
/*      */             
/*  624 */             codeStream.store(this.primaryExceptionVariable, false);
/*      */           } else {
/*      */             
/*  627 */             BranchLabel elseLabel = new BranchLabel(codeStream), postElseLabel = new BranchLabel(codeStream);
/*  628 */             codeStream.store(this.caughtThrowableVariable, false);
/*  629 */             codeStream.load(this.primaryExceptionVariable);
/*  630 */             codeStream.ifnonnull(elseLabel);
/*  631 */             codeStream.load(this.caughtThrowableVariable);
/*  632 */             codeStream.store(this.primaryExceptionVariable, false);
/*  633 */             codeStream.goto_(postElseLabel);
/*  634 */             elseLabel.place();
/*  635 */             codeStream.load(this.primaryExceptionVariable);
/*  636 */             codeStream.load(this.caughtThrowableVariable);
/*  637 */             codeStream.if_acmpeq(postElseLabel);
/*  638 */             codeStream.load(this.primaryExceptionVariable);
/*  639 */             codeStream.load(this.caughtThrowableVariable);
/*  640 */             codeStream.invokeThrowableAddSuppressed();
/*  641 */             postElseLabel.place();
/*      */           } 
/*  643 */           if (i > 0) {
/*      */             
/*  645 */             BranchLabel postCloseLabel = new BranchLabel(codeStream);
/*  646 */             generateCodeSnippet(stmt, codeStream, postCloseLabel, true, new int[] { i, codeStream.position });
/*  647 */             postCloseLabel.place();
/*      */           } 
/*  649 */           codeStream.load(this.primaryExceptionVariable);
/*  650 */           codeStream.athrow();
/*  651 */           exitLabel.place();
/*      */         } 
/*  653 */         codeStream.removeVariable(this.primaryExceptionVariable);
/*  654 */         codeStream.removeVariable(this.caughtThrowableVariable);
/*      */       } 
/*      */     } finally {
/*  657 */       this.declaredExceptionLabels = null;
/*  658 */       this.resourceExceptionLabels = null;
/*      */     } 
/*  660 */     boolean tryBlockHasSomeCode = (codeStream.position != pc);
/*      */ 
/*      */ 
/*      */     
/*  664 */     if (tryBlockHasSomeCode) {
/*      */       
/*  666 */       BranchLabel naturalExitLabel = new BranchLabel(codeStream);
/*  667 */       BranchLabel postCatchesFinallyLabel = null; int i;
/*  668 */       for (i = 0; i < maxCatches; i++) {
/*  669 */         exceptionLabels[i].placeEnd();
/*      */       }
/*  671 */       if ((this.bits & 0x20000000) == 0) {
/*  672 */         int position = codeStream.position;
/*  673 */         switch (finallyMode) {
/*      */           case 1:
/*      */           case 3:
/*  676 */             requiresNaturalExit = true;
/*  677 */             if (this.naturalExitMergeInitStateIndex != -1) {
/*  678 */               codeStream.removeNotDefinitelyAssignedVariables((Scope)currentScope, this.naturalExitMergeInitStateIndex);
/*  679 */               codeStream.addDefinitelyAssignedVariables((Scope)currentScope, this.naturalExitMergeInitStateIndex);
/*      */             } 
/*  681 */             codeStream.goto_(naturalExitLabel);
/*      */             break;
/*      */           case 0:
/*  684 */             if (this.naturalExitMergeInitStateIndex != -1) {
/*  685 */               codeStream.removeNotDefinitelyAssignedVariables((Scope)currentScope, this.naturalExitMergeInitStateIndex);
/*  686 */               codeStream.addDefinitelyAssignedVariables((Scope)currentScope, this.naturalExitMergeInitStateIndex);
/*      */             } 
/*  688 */             codeStream.goto_(naturalExitLabel);
/*      */             break;
/*      */           case 2:
/*  691 */             codeStream.goto_(this.subRoutineStartLabel);
/*      */             break;
/*      */         } 
/*  694 */         codeStream.recordPositionsFrom(position, this.tryBlock.sourceEnd);
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  701 */       exitAnyExceptionHandler();
/*  702 */       if (this.catchArguments != null) {
/*  703 */         postCatchesFinallyLabel = new BranchLabel(codeStream);
/*      */         
/*  705 */         for (i = 0; i < maxCatches; i++) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  711 */           if (exceptionLabels[i].getCount() != 0) {
/*  712 */             enterAnyExceptionHandler(codeStream);
/*      */             
/*  714 */             if (this.preTryInitStateIndex != -1) {
/*  715 */               codeStream.removeNotDefinitelyAssignedVariables((Scope)currentScope, this.preTryInitStateIndex);
/*  716 */               codeStream.addDefinitelyAssignedVariables((Scope)currentScope, this.preTryInitStateIndex);
/*      */             } 
/*  718 */             codeStream.pushExceptionOnStack((exceptionLabels[i]).exceptionType);
/*  719 */             exceptionLabels[i].place();
/*      */ 
/*      */             
/*  722 */             int varPC = codeStream.position; LocalVariableBinding catchVar;
/*  723 */             if ((catchVar = (this.catchArguments[i]).binding).resolvedPosition != -1) {
/*  724 */               codeStream.store(catchVar, false);
/*  725 */               catchVar.recordInitializationStartPC(codeStream.position);
/*  726 */               codeStream.addVisibleLocalVariable(catchVar);
/*      */             } else {
/*  728 */               codeStream.pop();
/*      */             } 
/*  730 */             codeStream.recordPositionsFrom(varPC, (this.catchArguments[i]).sourceStart);
/*      */ 
/*      */             
/*  733 */             this.catchBlocks[i].generateCode(this.scope, codeStream);
/*  734 */             exitAnyExceptionHandler();
/*  735 */             if (!this.catchExits[i]) {
/*  736 */               switch (finallyMode) {
/*      */                 
/*      */                 case 3:
/*  739 */                   if (isStackMapFrameCodeStream) {
/*  740 */                     ((StackMapFrameCodeStream)codeStream).pushStateIndex(this.naturalExitMergeInitStateIndex);
/*      */                   }
/*  742 */                   if (this.catchExitInitStateIndexes[i] != -1) {
/*  743 */                     codeStream.removeNotDefinitelyAssignedVariables((Scope)currentScope, this.catchExitInitStateIndexes[i]);
/*  744 */                     codeStream.addDefinitelyAssignedVariables((Scope)currentScope, this.catchExitInitStateIndexes[i]);
/*      */                   } 
/*      */                   
/*  747 */                   this.finallyBlock.generateCode(this.scope, codeStream);
/*  748 */                   codeStream.goto_(postCatchesFinallyLabel);
/*  749 */                   if (isStackMapFrameCodeStream) {
/*  750 */                     ((StackMapFrameCodeStream)codeStream).popStateIndex();
/*      */                   }
/*      */                   break;
/*      */                 case 1:
/*  754 */                   requiresNaturalExit = true;
/*      */                 
/*      */                 case 0:
/*  757 */                   if (this.naturalExitMergeInitStateIndex != -1) {
/*  758 */                     codeStream.removeNotDefinitelyAssignedVariables((Scope)currentScope, this.naturalExitMergeInitStateIndex);
/*  759 */                     codeStream.addDefinitelyAssignedVariables((Scope)currentScope, this.naturalExitMergeInitStateIndex);
/*      */                   } 
/*  761 */                   codeStream.goto_(naturalExitLabel);
/*      */                   break;
/*      */                 case 2:
/*  764 */                   codeStream.goto_(this.subRoutineStartLabel);
/*      */                   break;
/*      */               } 
/*      */             }
/*      */           } 
/*      */         } 
/*      */       } 
/*  771 */       ExceptionLabel naturalExitExceptionHandler = (requiresNaturalExit && finallyMode == 1) ? 
/*  772 */         new ExceptionLabel(codeStream, null) : 
/*  773 */         null;
/*      */ 
/*      */ 
/*      */       
/*  777 */       int finallySequenceStartPC = codeStream.position;
/*  778 */       if (this.subRoutineStartLabel != null && this.anyExceptionLabel.getCount() != 0) {
/*  779 */         int position; codeStream.pushExceptionOnStack((TypeBinding)this.scope.getJavaLangThrowable());
/*  780 */         if (this.preTryInitStateIndex != -1) {
/*      */           
/*  782 */           codeStream.removeNotDefinitelyAssignedVariables((Scope)currentScope, this.preTryInitStateIndex);
/*  783 */           codeStream.addDefinitelyAssignedVariables((Scope)currentScope, this.preTryInitStateIndex);
/*      */         } 
/*  785 */         placeAllAnyExceptionHandler();
/*  786 */         if (naturalExitExceptionHandler != null) naturalExitExceptionHandler.place();
/*      */         
/*  788 */         switch (finallyMode) {
/*      */           
/*      */           case 1:
/*  791 */             codeStream.store(this.anyExceptionVariable, false);
/*  792 */             codeStream.jsr(this.subRoutineStartLabel);
/*  793 */             codeStream.recordPositionsFrom(finallySequenceStartPC, this.finallyBlock.sourceStart);
/*  794 */             position = codeStream.position;
/*  795 */             codeStream.throwAnyException(this.anyExceptionVariable);
/*  796 */             codeStream.recordPositionsFrom(position, this.finallyBlock.sourceEnd);
/*      */             
/*  798 */             this.subRoutineStartLabel.place();
/*  799 */             codeStream.pushExceptionOnStack((TypeBinding)this.scope.getJavaLangThrowable());
/*  800 */             position = codeStream.position;
/*  801 */             codeStream.store(this.returnAddressVariable, false);
/*  802 */             codeStream.recordPositionsFrom(position, this.finallyBlock.sourceStart);
/*  803 */             this.finallyBlock.generateCode(this.scope, codeStream);
/*  804 */             position = codeStream.position;
/*  805 */             codeStream.ret(this.returnAddressVariable.resolvedPosition);
/*  806 */             codeStream.recordPositionsFrom(
/*  807 */                 position, 
/*  808 */                 this.finallyBlock.sourceEnd);
/*      */             break;
/*      */ 
/*      */           
/*      */           case 3:
/*  813 */             codeStream.store(this.anyExceptionVariable, false);
/*  814 */             codeStream.addVariable(this.anyExceptionVariable);
/*  815 */             codeStream.recordPositionsFrom(finallySequenceStartPC, this.finallyBlock.sourceStart);
/*      */             
/*  817 */             this.finallyBlock.generateCode(currentScope, codeStream);
/*  818 */             position = codeStream.position;
/*  819 */             codeStream.throwAnyException(this.anyExceptionVariable);
/*  820 */             codeStream.removeVariable(this.anyExceptionVariable);
/*  821 */             if (this.preTryInitStateIndex != -1) {
/*  822 */               codeStream.removeNotDefinitelyAssignedVariables((Scope)currentScope, this.preTryInitStateIndex);
/*      */             }
/*  824 */             this.subRoutineStartLabel.place();
/*  825 */             codeStream.recordPositionsFrom(position, this.finallyBlock.sourceEnd);
/*      */             break;
/*      */           
/*      */           case 2:
/*  829 */             codeStream.pop();
/*  830 */             this.subRoutineStartLabel.place();
/*  831 */             codeStream.recordPositionsFrom(finallySequenceStartPC, this.finallyBlock.sourceStart);
/*      */             
/*  833 */             this.finallyBlock.generateCode(this.scope, codeStream);
/*      */             break;
/*      */         } 
/*      */ 
/*      */         
/*  838 */         if (requiresNaturalExit) {
/*  839 */           switch (finallyMode) {
/*      */             case 1:
/*  841 */               naturalExitLabel.place();
/*  842 */               position = codeStream.position;
/*  843 */               naturalExitExceptionHandler.placeStart();
/*  844 */               codeStream.jsr(this.subRoutineStartLabel);
/*  845 */               naturalExitExceptionHandler.placeEnd();
/*  846 */               codeStream.recordPositionsFrom(
/*  847 */                   position, 
/*  848 */                   this.finallyBlock.sourceEnd);
/*      */               break;
/*      */             
/*      */             case 3:
/*  852 */               if (isStackMapFrameCodeStream) {
/*  853 */                 ((StackMapFrameCodeStream)codeStream).pushStateIndex(this.naturalExitMergeInitStateIndex);
/*      */               }
/*  855 */               if (this.naturalExitMergeInitStateIndex != -1) {
/*  856 */                 codeStream.removeNotDefinitelyAssignedVariables((Scope)currentScope, this.naturalExitMergeInitStateIndex);
/*  857 */                 codeStream.addDefinitelyAssignedVariables((Scope)currentScope, this.naturalExitMergeInitStateIndex);
/*      */               } 
/*  859 */               naturalExitLabel.place();
/*      */               
/*  861 */               this.finallyBlock.generateCode(this.scope, codeStream);
/*  862 */               if (postCatchesFinallyLabel != null) {
/*  863 */                 position = codeStream.position;
/*      */                 
/*  865 */                 codeStream.goto_(postCatchesFinallyLabel);
/*  866 */                 codeStream.recordPositionsFrom(
/*  867 */                     position, 
/*  868 */                     this.finallyBlock.sourceEnd);
/*      */               } 
/*  870 */               if (isStackMapFrameCodeStream) {
/*  871 */                 ((StackMapFrameCodeStream)codeStream).popStateIndex();
/*      */               }
/*      */               break;
/*      */             case 2:
/*      */               break;
/*      */             default:
/*  877 */               naturalExitLabel.place();
/*      */               break;
/*      */           } 
/*      */         }
/*  881 */         if (postCatchesFinallyLabel != null) {
/*  882 */           postCatchesFinallyLabel.place();
/*      */         }
/*      */       } else {
/*      */         
/*  886 */         naturalExitLabel.place();
/*      */       }
/*      */     
/*      */     }
/*  890 */     else if (this.subRoutineStartLabel != null) {
/*  891 */       this.finallyBlock.generateCode(this.scope, codeStream);
/*      */     } 
/*      */ 
/*      */     
/*  895 */     if (this.mergedInitStateIndex != -1) {
/*  896 */       codeStream.removeNotDefinitelyAssignedVariables((Scope)currentScope, this.mergedInitStateIndex);
/*  897 */       codeStream.addDefinitelyAssignedVariables((Scope)currentScope, this.mergedInitStateIndex);
/*      */     } 
/*  899 */     codeStream.recordPositionsFrom(pc, this.sourceStart);
/*      */   }
/*      */   
/*      */   private void generateCodeSnippet(Statement statement, CodeStream codeStream, BranchLabel postCloseLabel, boolean record, int... values) {
/*  903 */     int i = -1;
/*  904 */     int invokeCloseStartPc = -1;
/*  905 */     if (record) {
/*  906 */       i = values[0];
/*  907 */       invokeCloseStartPc = values[1];
/*      */     } 
/*  909 */     if (statement instanceof LocalDeclaration) {
/*  910 */       generateCodeSnippet((LocalDeclaration)statement, codeStream, postCloseLabel, record, i, invokeCloseStartPc);
/*  911 */     } else if (statement instanceof Reference) {
/*  912 */       generateCodeSnippet((Reference)statement, codeStream, postCloseLabel, record, i, invokeCloseStartPc);
/*      */     } 
/*      */   }
/*      */   
/*      */   private void generateCodeSnippet(Reference reference, CodeStream codeStream, BranchLabel postCloseLabel, boolean record, int i, int invokeCloseStartPc) {
/*  917 */     reference.generateCode(this.scope, codeStream, true);
/*  918 */     codeStream.ifnull(postCloseLabel);
/*  919 */     reference.generateCode(this.scope, codeStream, true);
/*  920 */     codeStream.invokeAutoCloseableClose(reference.resolvedType);
/*  921 */     if (!record)
/*  922 */       return;  codeStream.recordPositionsFrom(invokeCloseStartPc, this.tryBlock.sourceEnd);
/*  923 */     isDuplicateResourceReference(i);
/*      */   }
/*      */   private void generateCodeSnippet(LocalDeclaration localDeclaration, CodeStream codeStream, BranchLabel postCloseLabel, boolean record, int i, int invokeCloseStartPc) {
/*  926 */     LocalVariableBinding variableBinding = localDeclaration.binding;
/*  927 */     codeStream.load(variableBinding);
/*  928 */     codeStream.ifnull(postCloseLabel);
/*  929 */     codeStream.load(variableBinding);
/*  930 */     codeStream.invokeAutoCloseableClose(variableBinding.type);
/*  931 */     if (!record)
/*  932 */       return;  codeStream.recordPositionsFrom(invokeCloseStartPc, this.tryBlock.sourceEnd);
/*  933 */     if (!isDuplicateResourceReference(i))
/*  934 */       codeStream.removeVariable(variableBinding); 
/*      */   }
/*      */   
/*      */   private boolean isDuplicateResourceReference(int index) {
/*  938 */     int len = this.resources.length;
/*  939 */     if (index < len && this.resources[index] instanceof Reference) {
/*  940 */       Reference ref = (Reference)this.resources[index];
/*  941 */       Binding refBinding = (ref instanceof NameReference) ? ((NameReference)ref).binding : (
/*  942 */         (ref instanceof FieldReference) ? (Binding)((FieldReference)ref).binding : null);
/*  943 */       if (refBinding == null) return false;
/*      */ 
/*      */       
/*  946 */       for (int i = 0; i < index; i++) {
/*  947 */         Statement stmt = this.resources[i];
/*  948 */         Binding b = (stmt instanceof LocalDeclaration) ? (Binding)((LocalDeclaration)stmt).binding : (
/*  949 */           (stmt instanceof NameReference) ? ((NameReference)stmt).binding : (
/*  950 */           (stmt instanceof FieldReference) ? (Binding)((FieldReference)stmt).binding : null));
/*  951 */         if (b == refBinding) {
/*  952 */           this.scope.problemReporter().duplicateResourceReference(ref);
/*  953 */           return true;
/*      */         } 
/*      */       } 
/*      */     } 
/*  957 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean generateSubRoutineInvocation(BlockScope currentScope, CodeStream codeStream, Object targetLocation, int stateIndex, LocalVariableBinding secretLocal) {
/*  966 */     int resourceCount = this.resources.length;
/*  967 */     if (resourceCount > 0 && this.resourceExceptionLabels != null) {
/*  968 */       for (int i = resourceCount; i > 0; i--) {
/*      */         
/*  970 */         this.resourceExceptionLabels[i].placeEnd();
/*  971 */         BranchLabel exitLabel = new BranchLabel(codeStream);
/*  972 */         int invokeCloseStartPc = codeStream.position;
/*  973 */         generateCodeSnippet(this.resources[i - 1], codeStream, exitLabel, false, new int[0]);
/*  974 */         codeStream.recordPositionsFrom(invokeCloseStartPc, this.tryBlock.sourceEnd);
/*  975 */         exitLabel.place();
/*      */       } 
/*  977 */       this.resourceExceptionLabels[0].placeEnd();
/*      */     } 
/*      */     
/*  980 */     boolean isStackMapFrameCodeStream = codeStream instanceof StackMapFrameCodeStream;
/*  981 */     int finallyMode = finallyMode();
/*  982 */     switch (finallyMode) {
/*      */       case 2:
/*  984 */         if (this.switchExpression != null) {
/*  985 */           this.finallyBlock.generateCode(currentScope, codeStream);
/*  986 */           return true;
/*      */         } 
/*  988 */         codeStream.goto_(this.subRoutineStartLabel);
/*  989 */         return true;
/*      */       
/*      */       case 0:
/*  992 */         if (this.switchExpression == null) {
/*  993 */           exitDeclaredExceptionHandlers(codeStream);
/*      */         }
/*  995 */         return false;
/*      */     } 
/*      */     
/*  998 */     CompilerOptions options = this.scope.compilerOptions();
/*  999 */     if (options.shareCommonFinallyBlocks && targetLocation != null) {
/* 1000 */       boolean reuseTargetLocation = true;
/* 1001 */       if (this.reusableJSRTargetsCount > 0) {
/* 1002 */         for (int i = 0, count = this.reusableJSRTargetsCount; i < count; ) {
/* 1003 */           Object reusableJSRTarget = this.reusableJSRTargets[i];
/*      */           
/* 1005 */           if (targetLocation != reusableJSRTarget)
/*      */           {
/* 1007 */             if (!(targetLocation instanceof Constant) || 
/* 1008 */               !(reusableJSRTarget instanceof Constant) || 
/* 1009 */               !((Constant)targetLocation).hasSameValue((Constant)reusableJSRTarget)) {
/*      */               i++;
/*      */               
/*      */               continue;
/*      */             } 
/*      */           }
/*      */           
/* 1016 */           if (this.reusableJSRStateIndexes[i] != stateIndex && finallyMode == 3) {
/* 1017 */             reuseTargetLocation = false;
/*      */             break;
/*      */           } 
/* 1020 */           codeStream.goto_(this.reusableJSRSequenceStartLabels[i]);
/* 1021 */           return true;
/*      */         } 
/*      */       } else {
/*      */         
/* 1025 */         this.reusableJSRTargets = new Object[3];
/* 1026 */         this.reusableJSRSequenceStartLabels = new BranchLabel[3];
/* 1027 */         this.reusableJSRStateIndexes = new int[3];
/*      */       } 
/* 1029 */       if (reuseTargetLocation) {
/* 1030 */         if (this.reusableJSRTargetsCount == this.reusableJSRTargets.length) {
/* 1031 */           System.arraycopy(this.reusableJSRTargets, 0, this.reusableJSRTargets = new Object[2 * this.reusableJSRTargetsCount], 0, this.reusableJSRTargetsCount);
/* 1032 */           System.arraycopy(this.reusableJSRSequenceStartLabels, 0, this.reusableJSRSequenceStartLabels = new BranchLabel[2 * this.reusableJSRTargetsCount], 0, this.reusableJSRTargetsCount);
/* 1033 */           System.arraycopy(this.reusableJSRStateIndexes, 0, this.reusableJSRStateIndexes = new int[2 * this.reusableJSRTargetsCount], 0, this.reusableJSRTargetsCount);
/*      */         } 
/* 1035 */         this.reusableJSRTargets[this.reusableJSRTargetsCount] = targetLocation;
/* 1036 */         BranchLabel reusableJSRSequenceStartLabel = new BranchLabel(codeStream);
/* 1037 */         reusableJSRSequenceStartLabel.place();
/* 1038 */         this.reusableJSRStateIndexes[this.reusableJSRTargetsCount] = stateIndex;
/* 1039 */         this.reusableJSRSequenceStartLabels[this.reusableJSRTargetsCount++] = reusableJSRSequenceStartLabel;
/*      */       } 
/*      */     } 
/* 1042 */     if (finallyMode == 3) {
/* 1043 */       if (isStackMapFrameCodeStream) {
/* 1044 */         ((StackMapFrameCodeStream)codeStream).pushStateIndex(stateIndex);
/*      */       }
/*      */ 
/*      */       
/* 1048 */       exitAnyExceptionHandler();
/* 1049 */       exitDeclaredExceptionHandlers(codeStream);
/* 1050 */       this.finallyBlock.generateCode(currentScope, codeStream);
/* 1051 */       if (isStackMapFrameCodeStream) {
/* 1052 */         ((StackMapFrameCodeStream)codeStream).popStateIndex();
/*      */       }
/*      */     } else {
/*      */       
/* 1056 */       codeStream.jsr(this.subRoutineStartLabel);
/* 1057 */       exitAnyExceptionHandler();
/* 1058 */       exitDeclaredExceptionHandlers(codeStream);
/*      */     } 
/* 1060 */     return false;
/*      */   }
/*      */   
/*      */   public boolean isSubRoutineEscaping() {
/* 1064 */     return ((this.bits & 0x4000) != 0);
/*      */   }
/*      */ 
/*      */   
/*      */   public StringBuffer printStatement(int indent, StringBuffer output) {
/* 1069 */     int length = this.resources.length;
/* 1070 */     printIndent(indent, output).append("try" + ((length == 0) ? "\n" : " (")); int i;
/* 1071 */     for (i = 0; i < length; i++) {
/* 1072 */       Statement stmt = this.resources[i];
/* 1073 */       if (stmt instanceof LocalDeclaration)
/* 1074 */       { ((LocalDeclaration)stmt).printAsExpression(0, output); }
/* 1075 */       else if (stmt instanceof Reference)
/* 1076 */       { ((Reference)stmt).printExpression(0, output); }
/*      */       else { continue; }
/* 1078 */        if (i != length - 1) {
/* 1079 */         output.append(";\n");
/* 1080 */         printIndent(indent + 2, output);
/*      */       }  continue;
/*      */     } 
/* 1083 */     if (length > 0) {
/* 1084 */       output.append(")\n");
/*      */     }
/* 1086 */     this.tryBlock.printStatement(indent + 1, output);
/*      */ 
/*      */     
/* 1089 */     if (this.catchBlocks != null) {
/* 1090 */       for (i = 0; i < this.catchBlocks.length; i++) {
/* 1091 */         output.append('\n');
/* 1092 */         printIndent(indent, output).append("catch (");
/* 1093 */         this.catchArguments[i].print(0, output).append(")\n");
/* 1094 */         this.catchBlocks[i].printStatement(indent + 1, output);
/*      */       } 
/*      */     }
/* 1097 */     if (this.finallyBlock != null) {
/* 1098 */       output.append('\n');
/* 1099 */       printIndent(indent, output).append("finally\n");
/* 1100 */       this.finallyBlock.printStatement(indent + 1, output);
/*      */     } 
/* 1102 */     return output;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void resolve(BlockScope upperScope) {
/* 1108 */     this.scope = new BlockScope(upperScope);
/*      */     
/* 1110 */     BlockScope finallyScope = null;
/* 1111 */     BlockScope resourceManagementScope = null;
/* 1112 */     int resourceCount = this.resources.length;
/* 1113 */     if (resourceCount > 0) {
/* 1114 */       resourceManagementScope = new BlockScope(this.scope);
/* 1115 */       this.primaryExceptionVariable = 
/* 1116 */         new LocalVariableBinding(SECRET_PRIMARY_EXCEPTION_VARIABLE_NAME, (TypeBinding)this.scope.getJavaLangThrowable(), 0, false);
/* 1117 */       resourceManagementScope.addLocalVariable(this.primaryExceptionVariable);
/* 1118 */       this.primaryExceptionVariable.setConstant(Constant.NotAConstant);
/* 1119 */       this.caughtThrowableVariable = 
/* 1120 */         new LocalVariableBinding(SECRET_CAUGHT_THROWABLE_VARIABLE_NAME, (TypeBinding)this.scope.getJavaLangThrowable(), 0, false);
/* 1121 */       resourceManagementScope.addLocalVariable(this.caughtThrowableVariable);
/* 1122 */       this.caughtThrowableVariable.setConstant(Constant.NotAConstant);
/*      */     } 
/* 1124 */     for (int i = 0; i < resourceCount; i++) {
/* 1125 */       this.resources[i].resolve(resourceManagementScope);
/* 1126 */       if (this.resources[i] instanceof LocalDeclaration) {
/* 1127 */         LocalDeclaration node = (LocalDeclaration)this.resources[i];
/* 1128 */         LocalVariableBinding localVariableBinding = node.binding;
/* 1129 */         if (localVariableBinding != null && localVariableBinding.isValidBinding()) {
/* 1130 */           localVariableBinding.modifiers |= 0x10;
/* 1131 */           localVariableBinding.tagBits |= 0x2000L;
/* 1132 */           TypeBinding resourceType = localVariableBinding.type;
/* 1133 */           if (resourceType instanceof ReferenceBinding) {
/* 1134 */             if (resourceType.findSuperTypeOriginatingFrom(62, false) == null && resourceType.isValidBinding()) {
/* 1135 */               upperScope.problemReporter().resourceHasToImplementAutoCloseable(resourceType, node.type);
/* 1136 */               localVariableBinding.type = (TypeBinding)new ProblemReferenceBinding(CharOperation.splitOn('.', resourceType.shortReadableName()), null, 15);
/*      */             } 
/* 1138 */           } else if (resourceType != null) {
/* 1139 */             upperScope.problemReporter().resourceHasToImplementAutoCloseable(resourceType, node.type);
/* 1140 */             localVariableBinding.type = (TypeBinding)new ProblemReferenceBinding(CharOperation.splitOn('.', resourceType.shortReadableName()), null, 15);
/*      */           } 
/*      */         } 
/*      */       } else {
/* 1144 */         Expression node = (Expression)this.resources[i];
/* 1145 */         TypeBinding resourceType = node.resolvedType;
/* 1146 */         if (resourceType instanceof ReferenceBinding) {
/* 1147 */           if (resourceType.findSuperTypeOriginatingFrom(62, false) == null && resourceType.isValidBinding()) {
/* 1148 */             upperScope.problemReporter().resourceHasToImplementAutoCloseable(resourceType, node);
/* 1149 */             ((Expression)this.resources[i]).resolvedType = (TypeBinding)new ProblemReferenceBinding(CharOperation.splitOn('.', resourceType.shortReadableName()), null, 15);
/*      */           } 
/* 1151 */         } else if (resourceType != null) {
/* 1152 */           upperScope.problemReporter().resourceHasToImplementAutoCloseable(resourceType, node);
/* 1153 */           ((Expression)this.resources[i]).resolvedType = (TypeBinding)new ProblemReferenceBinding(CharOperation.splitOn('.', resourceType.shortReadableName()), null, 15);
/*      */         } 
/*      */       } 
/*      */     } 
/* 1157 */     BlockScope tryScope = new BlockScope((resourceManagementScope != null) ? resourceManagementScope : this.scope);
/*      */     
/* 1159 */     if (this.finallyBlock != null) {
/* 1160 */       if (this.finallyBlock.isEmptyBlock()) {
/* 1161 */         if ((this.finallyBlock.bits & 0x8) != 0) {
/* 1162 */           this.scope.problemReporter().undocumentedEmptyBlock(this.finallyBlock.sourceStart, this.finallyBlock.sourceEnd);
/*      */         }
/*      */       } else {
/* 1165 */         finallyScope = new BlockScope(this.scope, false);
/*      */ 
/*      */         
/* 1168 */         MethodScope methodScope = this.scope.methodScope();
/*      */ 
/*      */         
/* 1171 */         if (!(upperScope.compilerOptions()).inlineJsrBytecode) {
/* 1172 */           this.returnAddressVariable = 
/* 1173 */             new LocalVariableBinding(SECRET_RETURN_ADDRESS_NAME, (TypeBinding)upperScope.getJavaLangObject(), 0, false);
/* 1174 */           finallyScope.addLocalVariable(this.returnAddressVariable);
/* 1175 */           this.returnAddressVariable.setConstant(Constant.NotAConstant);
/*      */         } 
/* 1177 */         this.subRoutineStartLabel = new BranchLabel();
/*      */         
/* 1179 */         this.anyExceptionVariable = 
/* 1180 */           new LocalVariableBinding(SECRET_ANY_HANDLER_NAME, (TypeBinding)this.scope.getJavaLangThrowable(), 0, false);
/* 1181 */         finallyScope.addLocalVariable(this.anyExceptionVariable);
/* 1182 */         this.anyExceptionVariable.setConstant(Constant.NotAConstant);
/*      */         
/* 1184 */         if (!methodScope.isInsideInitializer()) {
/* 1185 */           MethodBinding methodBinding = (methodScope.referenceContext instanceof AbstractMethodDeclaration) ? 
/* 1186 */             ((AbstractMethodDeclaration)methodScope.referenceContext).binding : ((methodScope.referenceContext instanceof LambdaExpression) ? 
/* 1187 */             ((LambdaExpression)methodScope.referenceContext).binding : null);
/* 1188 */           if (methodBinding != null) {
/* 1189 */             TypeBinding methodReturnType = methodBinding.returnType;
/* 1190 */             if (methodReturnType.id != 6) {
/* 1191 */               this.secretReturnValue = 
/* 1192 */                 new LocalVariableBinding(
/* 1193 */                   SECRET_RETURN_VALUE_NAME, 
/* 1194 */                   methodReturnType, 
/* 1195 */                   0, 
/* 1196 */                   false);
/* 1197 */               finallyScope.addLocalVariable(this.secretReturnValue);
/* 1198 */               this.secretReturnValue.setConstant(Constant.NotAConstant);
/*      */             } 
/*      */           } 
/*      */         } 
/* 1202 */         this.finallyBlock.resolveUsing(finallyScope);
/*      */         
/* 1204 */         int shiftScopesLength = (this.catchArguments == null) ? 1 : (this.catchArguments.length + 1);
/* 1205 */         finallyScope.shiftScopes = new BlockScope[shiftScopesLength];
/* 1206 */         finallyScope.shiftScopes[0] = tryScope;
/*      */       } 
/*      */     }
/* 1209 */     this.tryBlock.resolveUsing(tryScope);
/*      */ 
/*      */     
/* 1212 */     if (this.catchBlocks != null) {
/* 1213 */       int j, length = this.catchArguments.length;
/* 1214 */       TypeBinding[] argumentTypes = new TypeBinding[length];
/* 1215 */       boolean containsUnionTypes = false;
/* 1216 */       boolean catchHasError = false;
/* 1217 */       for (int k = 0; k < length; k++) {
/* 1218 */         BlockScope catchScope = new BlockScope(this.scope);
/* 1219 */         if (finallyScope != null) {
/* 1220 */           finallyScope.shiftScopes[k + 1] = catchScope;
/*      */         }
/*      */         
/* 1223 */         Argument catchArgument = this.catchArguments[k];
/* 1224 */         j = containsUnionTypes | (((catchArgument.type.bits & 0x20000000) != 0) ? 1 : 0);
/* 1225 */         argumentTypes[k] = catchArgument.resolveForCatch(catchScope); if (catchArgument.resolveForCatch(catchScope) == null) {
/* 1226 */           catchHasError = true;
/*      */         }
/* 1228 */         this.catchBlocks[k].resolveUsing(catchScope);
/*      */       } 
/* 1230 */       if (catchHasError) {
/*      */         return;
/*      */       }
/*      */ 
/*      */       
/* 1235 */       verifyDuplicationAndOrder(length, argumentTypes, j);
/*      */     } else {
/* 1237 */       this.caughtExceptionTypes = new ReferenceBinding[0];
/*      */     } 
/*      */     
/* 1240 */     if (finallyScope != null)
/*      */     {
/*      */ 
/*      */       
/* 1244 */       this.scope.addSubscope((Scope)finallyScope);
/*      */     }
/*      */   }
/*      */   
/*      */   public void traverse(ASTVisitor visitor, BlockScope blockScope) {
/* 1249 */     if (visitor.visit(this, blockScope)) {
/* 1250 */       Statement[] statements = this.resources; int i, max;
/* 1251 */       for (i = 0, max = statements.length; i < max; i++) {
/* 1252 */         statements[i].traverse(visitor, this.scope);
/*      */       }
/* 1254 */       this.tryBlock.traverse(visitor, this.scope);
/* 1255 */       if (this.catchArguments != null) {
/* 1256 */         for (i = 0, max = this.catchBlocks.length; i < max; i++) {
/* 1257 */           this.catchArguments[i].traverse(visitor, this.scope);
/* 1258 */           this.catchBlocks[i].traverse(visitor, this.scope);
/*      */         } 
/*      */       }
/* 1261 */       if (this.finallyBlock != null)
/* 1262 */         this.finallyBlock.traverse(visitor, this.scope); 
/*      */     } 
/* 1264 */     visitor.endVisit(this, blockScope);
/*      */   }
/*      */ 
/*      */   
/*      */   protected void verifyDuplicationAndOrder(int length, TypeBinding[] argumentTypes, boolean containsUnionTypes) {
/* 1269 */     if (containsUnionTypes) {
/* 1270 */       int totalCount = 0;
/* 1271 */       ReferenceBinding[][] allExceptionTypes = new ReferenceBinding[length][]; int i;
/* 1272 */       for (i = 0; i < length; i++) {
/* 1273 */         if (!(argumentTypes[i] instanceof org.eclipse.jdt.internal.compiler.lookup.ArrayBinding)) {
/*      */           
/* 1275 */           ReferenceBinding currentExceptionType = (ReferenceBinding)argumentTypes[i];
/* 1276 */           TypeReference catchArgumentType = (this.catchArguments[i]).type;
/* 1277 */           if ((catchArgumentType.bits & 0x20000000) != 0) {
/* 1278 */             TypeReference[] typeReferences = ((UnionTypeReference)catchArgumentType).typeReferences;
/* 1279 */             int typeReferencesLength = typeReferences.length;
/* 1280 */             ReferenceBinding[] unionExceptionTypes = new ReferenceBinding[typeReferencesLength];
/* 1281 */             for (int j = 0; j < typeReferencesLength; j++) {
/* 1282 */               unionExceptionTypes[j] = (ReferenceBinding)(typeReferences[j]).resolvedType;
/*      */             }
/* 1284 */             totalCount += typeReferencesLength;
/* 1285 */             allExceptionTypes[i] = unionExceptionTypes;
/*      */           } else {
/* 1287 */             (new ReferenceBinding[1])[0] = currentExceptionType; allExceptionTypes[i] = new ReferenceBinding[1];
/* 1288 */             totalCount++;
/*      */           } 
/*      */         } 
/* 1291 */       }  this.caughtExceptionTypes = new ReferenceBinding[totalCount];
/* 1292 */       this.caughtExceptionsCatchBlocks = new int[totalCount]; int l;
/* 1293 */       for (i = 0, l = 0; i < length; i++) {
/* 1294 */         ReferenceBinding[] currentExceptions = allExceptionTypes[i];
/* 1295 */         if (currentExceptions != null) {
/* 1296 */           int j; int max; label70: for (j = 0, max = currentExceptions.length; j < max; j++) {
/* 1297 */             ReferenceBinding exception = currentExceptions[j];
/* 1298 */             this.caughtExceptionTypes[l] = exception;
/* 1299 */             this.caughtExceptionsCatchBlocks[l++] = i;
/*      */             
/* 1301 */             for (int k = 0; k < i; k++) {
/* 1302 */               ReferenceBinding[] exceptions = allExceptionTypes[k];
/* 1303 */               if (exceptions != null)
/* 1304 */                 for (int n = 0, max2 = exceptions.length; n < max2; n++) {
/* 1305 */                   ReferenceBinding currentException = exceptions[n];
/* 1306 */                   if (exception.isCompatibleWith((TypeBinding)currentException)) {
/* 1307 */                     TypeReference catchArgumentType = (this.catchArguments[i]).type;
/* 1308 */                     if ((catchArgumentType.bits & 0x20000000) != 0) {
/* 1309 */                       catchArgumentType = ((UnionTypeReference)catchArgumentType).typeReferences[j];
/*      */                     }
/* 1311 */                     this.scope.problemReporter().wrongSequenceOfExceptionTypesError(
/* 1312 */                         catchArgumentType, 
/* 1313 */                         (TypeBinding)exception, 
/* 1314 */                         (TypeBinding)currentException); break label70;
/*      */                   } 
/*      */                 }  
/*      */             } 
/*      */           } 
/*      */         } 
/*      */       } 
/*      */     } else {
/* 1322 */       this.caughtExceptionTypes = new ReferenceBinding[length];
/* 1323 */       for (int i = 0; i < length; i++) {
/* 1324 */         if (!(argumentTypes[i] instanceof org.eclipse.jdt.internal.compiler.lookup.ArrayBinding)) {
/*      */           
/* 1326 */           this.caughtExceptionTypes[i] = (ReferenceBinding)argumentTypes[i];
/* 1327 */           for (int j = 0; j < i; j++) {
/* 1328 */             if (this.caughtExceptionTypes[i].isCompatibleWith(argumentTypes[j]))
/* 1329 */               this.scope.problemReporter().wrongSequenceOfExceptionTypesError(
/* 1330 */                   (this.catchArguments[i]).type, 
/* 1331 */                   (TypeBinding)this.caughtExceptionTypes[i], 
/* 1332 */                   argumentTypes[j]); 
/*      */           } 
/*      */         } 
/*      */       } 
/*      */     } 
/*      */   }
/*      */   
/*      */   public boolean doesNotCompleteNormally() {
/* 1340 */     if (!this.tryBlock.doesNotCompleteNormally()) {
/* 1341 */       return (this.finallyBlock != null) ? this.finallyBlock.doesNotCompleteNormally() : false;
/*      */     }
/* 1343 */     if (this.catchBlocks != null) {
/* 1344 */       for (int i = 0; i < this.catchBlocks.length; i++) {
/* 1345 */         if (!this.catchBlocks[i].doesNotCompleteNormally()) {
/* 1346 */           return (this.finallyBlock != null) ? this.finallyBlock.doesNotCompleteNormally() : false;
/*      */         }
/*      */       } 
/*      */     }
/* 1350 */     return true;
/*      */   }
/*      */   
/*      */   public boolean completesByContinue() {
/* 1354 */     if (this.tryBlock.completesByContinue()) {
/* 1355 */       return (this.finallyBlock == null) ? true : (
/* 1356 */         !(this.finallyBlock.doesNotCompleteNormally() && !this.finallyBlock.completesByContinue()));
/*      */     }
/* 1358 */     if (this.catchBlocks != null) {
/* 1359 */       for (int i = 0; i < this.catchBlocks.length; i++) {
/* 1360 */         if (this.catchBlocks[i].completesByContinue()) {
/* 1361 */           return (this.finallyBlock == null) ? true : (
/* 1362 */             !(this.finallyBlock.doesNotCompleteNormally() && !this.finallyBlock.completesByContinue()));
/*      */         }
/*      */       } 
/*      */     }
/* 1366 */     return (this.finallyBlock != null && this.finallyBlock.completesByContinue());
/*      */   }
/*      */   
/*      */   public boolean canCompleteNormally() {
/* 1370 */     if (this.tryBlock.canCompleteNormally()) {
/* 1371 */       return (this.finallyBlock != null) ? this.finallyBlock.canCompleteNormally() : true;
/*      */     }
/* 1373 */     if (this.catchBlocks != null) {
/* 1374 */       for (int i = 0; i < this.catchBlocks.length; i++) {
/* 1375 */         if (this.catchBlocks[i].canCompleteNormally()) {
/* 1376 */           return (this.finallyBlock != null) ? this.finallyBlock.canCompleteNormally() : true;
/*      */         }
/*      */       } 
/*      */     }
/* 1380 */     return false;
/*      */   }
/*      */   
/*      */   public boolean continueCompletes() {
/* 1384 */     if (this.tryBlock.continueCompletes()) {
/* 1385 */       return (this.finallyBlock == null) ? true : (
/* 1386 */         !(!this.finallyBlock.canCompleteNormally() && !this.finallyBlock.continueCompletes()));
/*      */     }
/* 1388 */     if (this.catchBlocks != null) {
/* 1389 */       for (int i = 0; i < this.catchBlocks.length; i++) {
/* 1390 */         if (this.catchBlocks[i].continueCompletes()) {
/* 1391 */           return (this.finallyBlock == null) ? true : (
/* 1392 */             !(!this.finallyBlock.canCompleteNormally() && !this.finallyBlock.continueCompletes()));
/*      */         }
/*      */       } 
/*      */     }
/* 1396 */     return (this.finallyBlock != null && this.finallyBlock.continueCompletes());
/*      */   }
/*      */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\ast\TryStatement.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */