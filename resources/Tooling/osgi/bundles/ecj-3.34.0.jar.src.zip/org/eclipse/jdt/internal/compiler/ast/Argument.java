/*     */ package org.eclipse.jdt.internal.compiler.ast;
/*     */ 
/*     */ import org.eclipse.jdt.core.compiler.CharOperation;
/*     */ import org.eclipse.jdt.internal.compiler.ASTVisitor;
/*     */ import org.eclipse.jdt.internal.compiler.impl.Constant;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.Binding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.BlockScope;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.CatchParameterBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.ClassScope;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.FieldBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.LocalVariableBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.MethodBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.MethodScope;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.RecordComponentBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.ReferenceBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.Scope;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.SourceTypeBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.TypeBinding;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Argument
/*     */   extends LocalDeclaration
/*     */ {
/*  36 */   private static final char[] SET = "set".toCharArray();
/*     */ 
/*     */   
/*     */   public Argument(char[] name, long posNom, TypeReference tr, int modifiers) {
/*  40 */     super(name, (int)(posNom >>> 32L), (int)posNom);
/*  41 */     this.declarationSourceEnd = (int)posNom;
/*  42 */     this.modifiers = modifiers;
/*  43 */     this.type = tr;
/*  44 */     if (tr != null) {
/*  45 */       this.bits |= tr.bits & 0x100000;
/*     */     }
/*  47 */     this.bits |= 0x40000004;
/*     */   }
/*     */ 
/*     */   
/*     */   public Argument(char[] name, long posNom, TypeReference tr, int modifiers, boolean typeElided) {
/*  52 */     super(name, (int)(posNom >>> 32L), (int)posNom);
/*  53 */     this.declarationSourceEnd = (int)posNom;
/*  54 */     this.modifiers = modifiers;
/*  55 */     this.type = tr;
/*  56 */     if (tr != null) {
/*  57 */       this.bits |= tr.bits & 0x100000;
/*     */     }
/*  59 */     this.bits |= 0x40000006;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isRecoveredFromLoneIdentifier() {
/*  64 */     return false;
/*     */   }
/*     */   
/*     */   public TypeBinding createBinding(MethodScope scope, TypeBinding typeBinding) {
/*  68 */     if (this.binding == null) {
/*     */       
/*  70 */       this.binding = new LocalVariableBinding(this, typeBinding, this.modifiers, scope);
/*  71 */     } else if (!this.binding.type.isValidBinding()) {
/*  72 */       AbstractMethodDeclaration methodDecl = scope.referenceMethod();
/*  73 */       if (methodDecl != null) {
/*  74 */         MethodBinding methodBinding = methodDecl.binding;
/*  75 */         if (methodBinding != null) {
/*  76 */           methodBinding.tagBits |= 0x200L;
/*     */         }
/*     */       } 
/*     */     } 
/*  80 */     if ((this.binding.tagBits & 0x200000000L) == 0L) {
/*  81 */       Annotation[] annots = this.annotations;
/*  82 */       long sourceLevel = (scope.compilerOptions()).sourceLevel;
/*  83 */       if (sourceLevel >= 3801088L && annots == null) {
/*  84 */         annots = getCorrespondingRecordComponentAnnotationsIfApplicable(scope.referenceMethod());
/*  85 */         annots = ASTNode.copyRecordComponentAnnotations((Scope)scope, 
/*  86 */             (Binding)this.binding, annots);
/*     */       } 
/*  88 */       if (annots != null)
/*  89 */         resolveAnnotations((BlockScope)scope, annots, (Binding)this.binding, true); 
/*  90 */       if (sourceLevel >= 3407872L) {
/*  91 */         Annotation.isTypeUseCompatible(this.type, (Scope)scope, annots);
/*  92 */         scope.validateNullAnnotation(this.binding.tagBits, this.type, annots);
/*     */       } 
/*     */     } 
/*  95 */     this.binding.declaration = this;
/*  96 */     return this.binding.type;
/*     */   }
/*     */   
/*     */   private Annotation[] getCorrespondingRecordComponentAnnotationsIfApplicable(AbstractMethodDeclaration methodDecl) {
/* 100 */     if (methodDecl != null && methodDecl.isConstructor() && (
/* 101 */       methodDecl.bits & 0x200) != 0 && (
/* 102 */       methodDecl.bits & 0x400) != 0) {
/* 103 */       MethodBinding methodBinding = methodDecl.binding;
/* 104 */       ReferenceBinding referenceBinding = (methodBinding == null) ? null : methodBinding.declaringClass;
/* 105 */       if (referenceBinding instanceof SourceTypeBinding) {
/* 106 */         SourceTypeBinding sourceTypeBinding = (SourceTypeBinding)referenceBinding;
/* 107 */         assert sourceTypeBinding.isRecord();
/* 108 */         sourceTypeBinding.components();
/* 109 */         RecordComponentBinding recordComponentBinding = sourceTypeBinding.getRecordComponent(this.name);
/* 110 */         if (recordComponentBinding != null) {
/* 111 */           RecordComponent recordComponent = recordComponentBinding.sourceRecordComponent();
/* 112 */           return recordComponent.annotations;
/*     */         } 
/*     */       } 
/*     */     } 
/* 116 */     return null;
/*     */   }
/*     */   public TypeBinding bind(MethodScope scope, TypeBinding typeBinding, boolean used) {
/* 119 */     TypeBinding newTypeBinding = createBinding(scope, typeBinding);
/*     */ 
/*     */     
/* 122 */     Binding existingVariable = scope.getBinding(this.name, 3, this, false);
/* 123 */     if (existingVariable != null && existingVariable.isValidBinding()) {
/* 124 */       boolean localExists = existingVariable instanceof LocalVariableBinding;
/* 125 */       if (localExists && this.hiddenVariableDepth == 0) {
/* 126 */         if ((this.bits & 0x200000) != 0 && scope.isLambdaSubscope()) {
/* 127 */           scope.problemReporter().lambdaRedeclaresArgument(this);
/* 128 */         } else if (!(scope.referenceContext instanceof CompactConstructorDeclaration)) {
/*     */ 
/*     */           
/* 131 */           scope.problemReporter().redefineArgument(this);
/*     */         } 
/*     */       } else {
/* 134 */         boolean isSpecialArgument = false;
/* 135 */         if (existingVariable instanceof FieldBinding) {
/* 136 */           if (scope.isInsideConstructor()) {
/* 137 */             isSpecialArgument = true;
/* 138 */           } else if (!((FieldBinding)existingVariable).isRecordComponent()) {
/*     */             
/* 140 */             AbstractMethodDeclaration methodDecl = scope.referenceMethod();
/* 141 */             if (methodDecl != null && CharOperation.prefixEquals(SET, methodDecl.selector)) {
/* 142 */               isSpecialArgument = true;
/*     */             }
/*     */           } 
/*     */         }
/* 146 */         scope.problemReporter().localVariableHiding(this, existingVariable, isSpecialArgument);
/*     */       } 
/*     */     } 
/* 149 */     scope.addLocalVariable(this.binding);
/* 150 */     this.binding.useFlag = used ? 1 : 0;
/* 151 */     return newTypeBinding;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getKind() {
/* 159 */     return ((this.bits & 0x4) != 0) ? 5 : 4;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isArgument() {
/* 164 */     return true;
/*     */   }
/*     */   
/*     */   public boolean isVarArgs() {
/* 168 */     return (this.type != null && (this.type.bits & 0x4000) != 0);
/*     */   }
/*     */   
/*     */   public boolean hasElidedType() {
/* 172 */     return ((this.bits & 0x2) != 0);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean hasNullTypeAnnotation(TypeReference.AnnotationPosition position) {
/* 177 */     return !(!TypeReference.containsNullAnnotation(this.annotations) && (
/* 178 */       this.type == null || !this.type.hasNullTypeAnnotation(position)));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public StringBuffer print(int indent, StringBuffer output) {
/* 184 */     printIndent(indent, output);
/* 185 */     printModifiers(this.modifiers, output);
/* 186 */     if (this.annotations != null) {
/* 187 */       printAnnotations(this.annotations, output);
/* 188 */       output.append(' ');
/*     */     } 
/*     */     
/* 191 */     if (this.type == null) {
/* 192 */       output.append("<no type> ");
/*     */     } else {
/* 194 */       this.type.print(0, output).append(' ');
/*     */     } 
/* 196 */     return output.append(this.name);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public StringBuffer printStatement(int indent, StringBuffer output) {
/* 202 */     return print(indent, output).append(';');
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TypeBinding resolveForCatch(BlockScope scope) {
/*     */     boolean hasError;
/* 210 */     TypeBinding exceptionType = this.type.resolveType(scope, true);
/*     */     
/* 212 */     if (exceptionType == null) {
/* 213 */       hasError = true;
/*     */     } else {
/* 215 */       hasError = false;
/* 216 */       switch (exceptionType.kind()) {
/*     */         case 260:
/* 218 */           if (exceptionType.isBoundParameterizedType()) {
/* 219 */             hasError = true;
/* 220 */             scope.problemReporter().invalidParameterizedExceptionType(exceptionType, this);
/*     */           } 
/*     */           break;
/*     */         
/*     */         case 4100:
/* 225 */           scope.problemReporter().invalidTypeVariableAsException(exceptionType, this);
/* 226 */           hasError = true;
/*     */           break;
/*     */       } 
/*     */       
/* 230 */       if (exceptionType.findSuperTypeOriginatingFrom(21, true) == null && exceptionType.isValidBinding()) {
/* 231 */         scope.problemReporter().cannotThrowType(this.type, exceptionType);
/* 232 */         hasError = true;
/*     */       } 
/*     */     } 
/*     */     
/* 236 */     Binding existingVariable = scope.getBinding(this.name, 3, this, false);
/* 237 */     if (existingVariable != null && existingVariable.isValidBinding()) {
/* 238 */       if (existingVariable instanceof LocalVariableBinding && this.hiddenVariableDepth == 0) {
/* 239 */         scope.problemReporter().redefineArgument(this);
/*     */       } else {
/* 241 */         scope.problemReporter().localVariableHiding(this, existingVariable, false);
/*     */       } 
/*     */     }
/*     */     
/* 245 */     if ((this.type.bits & 0x20000000) != 0) {
/* 246 */       this.binding = (LocalVariableBinding)new CatchParameterBinding(this, exceptionType, this.modifiers | 0x10, false);
/* 247 */       this.binding.tagBits |= 0x1000L;
/*     */     } else {
/* 249 */       this.binding = (LocalVariableBinding)new CatchParameterBinding(this, exceptionType, this.modifiers, false);
/*     */     } 
/* 251 */     resolveAnnotations(scope, this.annotations, (Binding)this.binding, true);
/* 252 */     Annotation.isTypeUseCompatible(this.type, (Scope)scope, this.annotations);
/* 253 */     if ((scope.compilerOptions()).isAnnotationBasedNullAnalysisEnabled && (
/* 254 */       this.type.hasNullTypeAnnotation(TypeReference.AnnotationPosition.ANY) || TypeReference.containsNullAnnotation(this.annotations)))
/*     */     {
/* 256 */       scope.problemReporter().nullAnnotationUnsupportedLocation(this.type);
/*     */     }
/*     */     
/* 259 */     scope.addLocalVariable(this.binding);
/* 260 */     this.binding.setConstant(Constant.NotAConstant);
/* 261 */     if (hasError) return null; 
/* 262 */     return exceptionType;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void traverse(ASTVisitor visitor, BlockScope scope) {
/* 268 */     if (visitor.visit(this, scope)) {
/* 269 */       if (this.annotations != null) {
/* 270 */         int annotationsLength = this.annotations.length;
/* 271 */         for (int i = 0; i < annotationsLength; i++)
/* 272 */           this.annotations[i].traverse(visitor, scope); 
/*     */       } 
/* 274 */       if (this.type != null)
/* 275 */         this.type.traverse(visitor, scope); 
/*     */     } 
/* 277 */     visitor.endVisit(this, scope);
/*     */   }
/*     */   
/*     */   public void traverse(ASTVisitor visitor, ClassScope scope) {
/* 281 */     if (visitor.visit(this, scope)) {
/* 282 */       if (this.annotations != null) {
/* 283 */         int annotationsLength = this.annotations.length;
/* 284 */         for (int i = 0; i < annotationsLength; i++)
/* 285 */           this.annotations[i].traverse(visitor, scope); 
/*     */       } 
/* 287 */       if (this.type != null)
/* 288 */         this.type.traverse(visitor, scope); 
/*     */     } 
/* 290 */     visitor.endVisit(this, scope);
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\ast\Argument.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */