package org.eclipse.jdt.internal.compiler.impl;

import org.eclipse.jdt.core.compiler.CategorizedProblem;
import org.eclipse.jdt.internal.compiler.CompilationResult;
import org.eclipse.jdt.internal.compiler.ast.CompilationUnitDeclaration;

public interface ReferenceContext {
  void abort(int paramInt, CategorizedProblem paramCategorizedProblem);
  
  CompilationResult compilationResult();
  
  CompilationUnitDeclaration getCompilationUnitDeclaration();
  
  boolean hasErrors();
  
  void tagAsHavingErrors();
  
  void tagAsHavingIgnoredMandatoryErrors(int paramInt);
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\impl\ReferenceContext.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */