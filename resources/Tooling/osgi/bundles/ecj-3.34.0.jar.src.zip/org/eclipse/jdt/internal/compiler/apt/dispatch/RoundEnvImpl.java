/*     */ package org.eclipse.jdt.internal.compiler.apt.dispatch;
/*     */ 
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.util.Collections;
/*     */ import java.util.HashSet;
/*     */ import java.util.Set;
/*     */ import javax.annotation.processing.RoundEnvironment;
/*     */ import javax.lang.model.element.Element;
/*     */ import javax.lang.model.element.ElementKind;
/*     */ import javax.lang.model.element.TypeElement;
/*     */ import javax.lang.model.util.ElementFilter;
/*     */ import org.eclipse.jdt.internal.compiler.apt.model.Factory;
/*     */ import org.eclipse.jdt.internal.compiler.apt.model.TypeElementImpl;
/*     */ import org.eclipse.jdt.internal.compiler.apt.util.ManyToMany;
/*     */ import org.eclipse.jdt.internal.compiler.ast.CompilationUnitDeclaration;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.AnnotationBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.Binding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.FieldBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.MethodBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.ModuleBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.ParameterizedTypeBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.ReferenceBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.SourceTypeBinding;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RoundEnvImpl
/*     */   implements RoundEnvironment
/*     */ {
/*     */   private final BaseProcessingEnvImpl _processingEnv;
/*     */   private final boolean _isLastRound;
/*     */   private final CompilationUnitDeclaration[] _units;
/*     */   private final ManyToMany<TypeElement, Element> _annoToUnit;
/*     */   private final ReferenceBinding[] _binaryTypes;
/*     */   private final Factory _factory;
/*  51 */   private Set<Element> _rootElements = null;
/*     */   
/*     */   public RoundEnvImpl(CompilationUnitDeclaration[] units, ReferenceBinding[] binaryTypeBindings, boolean isLastRound, BaseProcessingEnvImpl env) {
/*  54 */     this._processingEnv = env;
/*  55 */     this._isLastRound = isLastRound;
/*  56 */     this._units = units;
/*  57 */     this._factory = this._processingEnv.getFactory();
/*     */ 
/*     */     
/*  60 */     AnnotationDiscoveryVisitor visitor = new AnnotationDiscoveryVisitor(this._processingEnv);
/*  61 */     if (this._units != null) {
/*  62 */       byte b; int i; CompilationUnitDeclaration[] arrayOfCompilationUnitDeclaration; for (i = (arrayOfCompilationUnitDeclaration = this._units).length, b = 0; b < i; ) { CompilationUnitDeclaration unit = arrayOfCompilationUnitDeclaration[b];
/*  63 */         unit.scope.environment.suppressImportErrors = true;
/*  64 */         unit.traverse(visitor, unit.scope);
/*  65 */         unit.scope.environment.suppressImportErrors = false; b++; }
/*     */     
/*     */     } 
/*  68 */     this._annoToUnit = visitor._annoToElement;
/*  69 */     if (binaryTypeBindings != null) collectAnnotations(binaryTypeBindings); 
/*  70 */     this._binaryTypes = binaryTypeBindings; } private void collectAnnotations(ReferenceBinding[] referenceBindings) {
/*     */     byte b;
/*     */     int i;
/*     */     ReferenceBinding[] arrayOfReferenceBinding;
/*  74 */     for (i = (arrayOfReferenceBinding = referenceBindings).length, b = 0; b < i; ) { ReferenceBinding referenceBinding = arrayOfReferenceBinding[b];
/*     */       
/*  76 */       if (referenceBinding instanceof ParameterizedTypeBinding) {
/*  77 */         referenceBinding = ((ParameterizedTypeBinding)referenceBinding).genericType();
/*     */       }
/*  79 */       AnnotationBinding[] annotationBindings = Factory.getPackedAnnotationBindings(referenceBinding.getAnnotations()); byte b1; int j; AnnotationBinding[] arrayOfAnnotationBinding1;
/*  80 */       for (j = (arrayOfAnnotationBinding1 = annotationBindings).length, b1 = 0; b1 < j; ) { AnnotationBinding annotationBinding = arrayOfAnnotationBinding1[b1];
/*  81 */         TypeElement anno = (TypeElement)this._factory.newElement((Binding)annotationBinding.getAnnotationType());
/*  82 */         Element element = this._factory.newElement((Binding)referenceBinding);
/*  83 */         this._annoToUnit.put(anno, element); b1++; }
/*     */       
/*  85 */       FieldBinding[] fieldBindings = referenceBinding.fields(); int k; FieldBinding[] arrayOfFieldBinding1;
/*  86 */       for (k = (arrayOfFieldBinding1 = fieldBindings).length, j = 0; j < k; ) { FieldBinding fieldBinding = arrayOfFieldBinding1[j];
/*  87 */         annotationBindings = Factory.getPackedAnnotationBindings(fieldBinding.getAnnotations()); byte b2; int n; AnnotationBinding[] arrayOfAnnotationBinding;
/*  88 */         for (n = (arrayOfAnnotationBinding = annotationBindings).length, b2 = 0; b2 < n; ) { AnnotationBinding annotationBinding = arrayOfAnnotationBinding[b2];
/*  89 */           TypeElement anno = (TypeElement)this._factory.newElement((Binding)annotationBinding.getAnnotationType());
/*  90 */           Element element = this._factory.newElement((Binding)fieldBinding);
/*  91 */           this._annoToUnit.put(anno, element); b2++; }
/*     */          j++; }
/*     */       
/*  94 */       MethodBinding[] methodBindings = referenceBinding.methods(); MethodBinding[] arrayOfMethodBinding1;
/*  95 */       for (int m = (arrayOfMethodBinding1 = methodBindings).length; k < m; ) { MethodBinding methodBinding = arrayOfMethodBinding1[k];
/*  96 */         annotationBindings = Factory.getPackedAnnotationBindings(methodBinding.getAnnotations()); byte b2; int n; AnnotationBinding[] arrayOfAnnotationBinding;
/*  97 */         for (n = (arrayOfAnnotationBinding = annotationBindings).length, b2 = 0; b2 < n; ) { AnnotationBinding annotationBinding = arrayOfAnnotationBinding[b2];
/*  98 */           TypeElement anno = (TypeElement)this._factory.newElement((Binding)annotationBinding.getAnnotationType());
/*  99 */           Element element = this._factory.newElement((Binding)methodBinding);
/* 100 */           this._annoToUnit.put(anno, element); b2++; }
/*     */          k++; }
/*     */       
/* 103 */       ReferenceBinding[] memberTypes = referenceBinding.memberTypes();
/* 104 */       collectAnnotations(memberTypes);
/*     */       b++; }
/*     */   
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Set<TypeElement> getRootAnnotations() {
/* 116 */     return Collections.unmodifiableSet(this._annoToUnit.getKeySet());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean errorRaised() {
/* 122 */     return this._processingEnv.errorRaised();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Set<? extends Element> getElementsAnnotatedWith(TypeElement a) {
/* 134 */     if (a.getKind() != ElementKind.ANNOTATION_TYPE) {
/* 135 */       throw new IllegalArgumentException("Argument must represent an annotation type");
/*     */     }
/* 137 */     Binding annoBinding = ((TypeElementImpl)a)._binding;
/* 138 */     if (0L != (annoBinding.getAnnotationTagBits() & 0x1000000000000L)) {
/* 139 */       Set<Element> annotatedElements = new HashSet<>(this._annoToUnit.getValues(a));
/*     */ 
/*     */       
/* 142 */       ReferenceBinding annoTypeBinding = (ReferenceBinding)annoBinding;
/* 143 */       for (TypeElement element : ElementFilter.typesIn(getRootElements())) {
/* 144 */         ReferenceBinding typeBinding = (ReferenceBinding)((TypeElementImpl)element)._binding;
/* 145 */         addAnnotatedElements(annoTypeBinding, typeBinding, annotatedElements);
/*     */       } 
/* 147 */       return Collections.unmodifiableSet(annotatedElements);
/*     */     } 
/* 149 */     return Collections.unmodifiableSet(this._annoToUnit.getValues(a));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void addAnnotatedElements(ReferenceBinding anno, ReferenceBinding type, Set<Element> result) {
/* 160 */     if (type.isClass() && 
/* 161 */       inheritsAnno(type, anno))
/* 162 */       result.add(this._factory.newElement((Binding)type));  byte b;
/*     */     int i;
/*     */     ReferenceBinding[] arrayOfReferenceBinding;
/* 165 */     for (i = (arrayOfReferenceBinding = type.memberTypes()).length, b = 0; b < i; ) { ReferenceBinding element = arrayOfReferenceBinding[b];
/* 166 */       addAnnotatedElements(anno, element, result);
/*     */       b++; }
/*     */   
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean inheritsAnno(ReferenceBinding element, ReferenceBinding anno) {
/* 177 */     ReferenceBinding searchedElement = element;
/*     */     while (true) {
/* 179 */       if (searchedElement instanceof ParameterizedTypeBinding) {
/* 180 */         searchedElement = ((ParameterizedTypeBinding)searchedElement).genericType();
/*     */       }
/* 182 */       AnnotationBinding[] annos = Factory.getPackedAnnotationBindings(searchedElement.getAnnotations()); byte b; int i; AnnotationBinding[] arrayOfAnnotationBinding1;
/* 183 */       for (i = (arrayOfAnnotationBinding1 = annos).length, b = 0; b < i; ) { AnnotationBinding annoBinding = arrayOfAnnotationBinding1[b];
/* 184 */         if (annoBinding.getAnnotationType() == anno)
/*     */         {
/* 186 */           return true; } 
/*     */         b++; }
/*     */       
/* 189 */       if ((searchedElement = searchedElement.superclass()) == null) {
/* 190 */         return false;
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   public Set<? extends Element> getElementsAnnotatedWith(Class<? extends Annotation> a) {
/* 196 */     String canonicalName = a.getCanonicalName();
/* 197 */     if (canonicalName == null)
/*     */     {
/* 199 */       throw new IllegalArgumentException("Argument must represent an annotation type");
/*     */     }
/* 201 */     TypeElement annoType = this._processingEnv.getElementUtils().getTypeElement(canonicalName);
/* 202 */     if (annoType == null) {
/* 203 */       return Collections.emptySet();
/*     */     }
/* 205 */     return getElementsAnnotatedWith(annoType);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Set<? extends Element> getRootElements() {
/* 211 */     if (this._units == null) {
/* 212 */       return Collections.emptySet();
/*     */     }
/* 214 */     if (this._rootElements == null) {
/* 215 */       Set<Element> elements = new HashSet<>(this._units.length); byte b; int i; CompilationUnitDeclaration[] arrayOfCompilationUnitDeclaration;
/* 216 */       for (i = (arrayOfCompilationUnitDeclaration = this._units).length, b = 0; b < i; ) { CompilationUnitDeclaration unit = arrayOfCompilationUnitDeclaration[b];
/* 217 */         if (unit.moduleDeclaration != null && unit.moduleDeclaration.binding != null) {
/* 218 */           Element m = this._factory.newElement((Binding)unit.moduleDeclaration.binding);
/* 219 */           elements.add(m);
/*     */         
/*     */         }
/* 222 */         else if (unit.scope != null && unit.scope.topLevelTypes != null) {
/*     */           byte b1; int j; SourceTypeBinding[] arrayOfSourceTypeBinding;
/* 224 */           for (j = (arrayOfSourceTypeBinding = unit.scope.topLevelTypes).length, b1 = 0; b1 < j; ) { SourceTypeBinding binding = arrayOfSourceTypeBinding[b1];
/* 225 */             Element element = this._factory.newElement((Binding)binding);
/* 226 */             if (element == null) {
/* 227 */               throw new IllegalArgumentException("Top-level type binding could not be converted to element: " + binding);
/*     */             }
/* 229 */             elements.add(element); b1++; }
/*     */         
/*     */         }  b++; }
/* 232 */        if (this._binaryTypes != null) {
/* 233 */         ReferenceBinding[] arrayOfReferenceBinding; for (i = (arrayOfReferenceBinding = this._binaryTypes).length, b = 0; b < i; ) { ReferenceBinding typeBinding = arrayOfReferenceBinding[b];
/* 234 */           Element element = this._factory.newElement((Binding)typeBinding);
/* 235 */           if (element == null) {
/* 236 */             throw new IllegalArgumentException("Top-level type binding could not be converted to element: " + typeBinding);
/*     */           }
/* 238 */           elements.add(element);
/* 239 */           ModuleBinding binding = typeBinding.module();
/* 240 */           if (binding != null) {
/* 241 */             Element m = this._factory.newElement((Binding)binding);
/* 242 */             elements.add(m);
/*     */           }  b++; }
/*     */       
/*     */       } 
/* 246 */       this._rootElements = elements;
/*     */     } 
/* 248 */     return this._rootElements;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean processingOver() {
/* 254 */     return this._isLastRound;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\apt\dispatch\RoundEnvImpl.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */