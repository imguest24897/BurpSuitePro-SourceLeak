/*     */ package org.eclipse.jdt.internal.compiler.ast;
/*     */ 
/*     */ import org.eclipse.jdt.internal.compiler.ASTVisitor;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.BlockScope;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.ClassScope;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.ModuleBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.PackageBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.Scope;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.TypeBinding;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JavadocModuleReference
/*     */   extends Expression
/*     */   implements IJavadocTypeReference
/*     */ {
/*     */   public int tagSourceStart;
/*     */   public int tagSourceEnd;
/*     */   public TypeReference typeReference;
/*     */   public ModuleReference moduleReference;
/*     */   public ModuleBinding moduleBinding;
/*     */   
/*     */   public JavadocModuleReference(char[][] sources, long[] pos, int tagStart, int tagEnd) {
/*  34 */     this.moduleReference = new ModuleReference(sources, pos);
/*  35 */     this.tagSourceStart = tagStart;
/*  36 */     this.tagSourceEnd = tagEnd;
/*  37 */     this.sourceStart = this.moduleReference.sourceStart;
/*  38 */     this.sourceEnd = this.moduleReference.sourceEnd;
/*  39 */     this.bits |= 0x8000;
/*     */   }
/*     */ 
/*     */   
/*     */   public JavadocModuleReference(ModuleReference moduleRef, int tagStart, int tagEnd) {
/*  44 */     this.moduleReference = moduleRef;
/*  45 */     this.tagSourceStart = tagStart;
/*  46 */     this.tagSourceEnd = tagEnd;
/*  47 */     this.sourceStart = this.moduleReference.sourceStart;
/*  48 */     this.sourceEnd = this.moduleReference.sourceEnd;
/*  49 */     this.bits |= 0x8000;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void traverse(ASTVisitor visitor, BlockScope scope) {
/*  58 */     visitor.visit(this, scope);
/*  59 */     visitor.endVisit(this, scope);
/*     */   }
/*     */ 
/*     */   
/*     */   public int getTagSourceStart() {
/*  64 */     return this.tagSourceStart;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getTagSourceEnd() {
/*  69 */     return this.tagSourceEnd;
/*     */   }
/*     */   
/*     */   public TypeReference getTypeReference() {
/*  73 */     return this.typeReference;
/*     */   }
/*     */   
/*     */   public void setTypeReference(TypeReference typeReference) {
/*  77 */     this.typeReference = typeReference;
/*  78 */     if (this.typeReference != null) {
/*  79 */       this.sourceEnd = this.typeReference.sourceEnd;
/*     */     }
/*     */   }
/*     */   
/*     */   public ModuleReference getModuleReference() {
/*  84 */     return this.moduleReference;
/*     */   }
/*     */   
/*     */   public void setModuleReference(ModuleReference moduleReference) {
/*  88 */     this.moduleReference = moduleReference;
/*  89 */     this.sourceStart = this.moduleReference.sourceStart;
/*  90 */     this.sourceStart = this.moduleReference.sourceEnd;
/*     */   }
/*     */ 
/*     */   
/*     */   public StringBuffer printExpression(int indent, StringBuffer output) {
/*  95 */     if (this.moduleReference != null) {
/*  96 */       output.append(this.moduleReference.moduleName);
/*     */     }
/*  98 */     output.append('/');
/*  99 */     if (this.typeReference != null) {
/* 100 */       this.typeReference.printExpression(indent, output);
/*     */     }
/* 102 */     return output;
/*     */   }
/*     */   
/*     */   public ModuleBinding resolve(Scope scope) {
/* 106 */     ModuleBinding modBinding = this.moduleReference.resolve(scope);
/* 107 */     if (modBinding != null && 
/* 108 */       !modBinding.isUnnamed() && 
/* 109 */       modBinding.isValidBinding()) {
/* 110 */       this.moduleBinding = modBinding;
/*     */     } else {
/* 112 */       reportInvalidModule(scope);
/*     */     } 
/* 114 */     return this.moduleBinding;
/*     */   }
/*     */   
/*     */   private ModuleBinding resolveModule(BlockScope scope) {
/* 118 */     return resolve((Scope)scope);
/*     */   }
/*     */   
/*     */   private ModuleBinding resolveModule(ClassScope scope) {
/* 122 */     return resolve((Scope)scope);
/*     */   }
/*     */ 
/*     */   
/*     */   public TypeBinding resolveType(BlockScope blockScope) {
/* 127 */     resolveModule(blockScope);
/* 128 */     TypeBinding tBinding = null;
/* 129 */     if (this.moduleBinding != null && 
/* 130 */       this.typeReference != null) {
/* 131 */       tBinding = this.typeReference.resolveType(blockScope);
/* 132 */       PackageBinding pBinding = null;
/* 133 */       if (tBinding != null) {
/* 134 */         if (tBinding.isValidBinding()) {
/* 135 */           pBinding = tBinding.getPackage();
/*     */         } else {
/* 137 */           return tBinding;
/*     */         }
/*     */       
/* 140 */       } else if (this.typeReference.resolvedType != null && !this.typeReference.resolvedType.isValidBinding()) {
/* 141 */         if (this.typeReference instanceof JavadocSingleTypeReference) {
/* 142 */           pBinding = ((JavadocSingleTypeReference)this.typeReference).packageBinding;
/* 143 */         } else if (this.typeReference instanceof JavadocQualifiedTypeReference) {
/* 144 */           pBinding = ((JavadocQualifiedTypeReference)this.typeReference).packageBinding;
/*     */         } 
/*     */       } 
/*     */       
/* 148 */       if (pBinding != null && !this.moduleBinding.equals(pBinding.enclosingModule)) {
/* 149 */         reportInvalidType((Scope)blockScope);
/* 150 */         tBinding = null;
/*     */       } 
/*     */     } 
/* 153 */     return tBinding;
/*     */   }
/*     */ 
/*     */   
/*     */   public TypeBinding resolveType(ClassScope classScope) {
/* 158 */     resolveModule(classScope);
/* 159 */     TypeBinding tBinding = null;
/* 160 */     if (this.moduleBinding != null && 
/* 161 */       this.typeReference != null) {
/* 162 */       tBinding = this.typeReference.resolveType(classScope, -1);
/* 163 */       PackageBinding pBinding = null;
/* 164 */       if (tBinding != null) {
/* 165 */         if (tBinding.isValidBinding()) {
/* 166 */           pBinding = tBinding.getPackage();
/*     */         } else {
/* 168 */           return tBinding;
/*     */         }
/*     */       
/* 171 */       } else if (this.resolvedType != null && !this.resolvedType.isValidBinding()) {
/* 172 */         if (this.typeReference instanceof JavadocSingleTypeReference) {
/* 173 */           pBinding = ((JavadocSingleTypeReference)this.typeReference).packageBinding;
/* 174 */         } else if (this.typeReference instanceof JavadocQualifiedTypeReference) {
/* 175 */           pBinding = ((JavadocQualifiedTypeReference)this.typeReference).packageBinding;
/*     */         } 
/*     */       } 
/*     */       
/* 179 */       if (pBinding != null && !this.moduleBinding.equals(pBinding.enclosingModule)) {
/* 180 */         reportInvalidType((Scope)classScope);
/* 181 */         tBinding = null;
/*     */       } 
/*     */     } 
/* 184 */     return tBinding;
/*     */   }
/*     */   
/*     */   protected void reportInvalidModule(Scope scope) {
/* 188 */     scope.problemReporter().javadocInvalidModule(this.moduleReference);
/*     */   }
/*     */   
/*     */   protected void reportInvalidType(Scope scope) {
/* 192 */     scope.problemReporter().javadocInvalidMemberTypeQualification(this.typeReference.sourceStart, this.typeReference.sourceEnd, scope.getDeclarationModifiers());
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\ast\JavadocModuleReference.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */