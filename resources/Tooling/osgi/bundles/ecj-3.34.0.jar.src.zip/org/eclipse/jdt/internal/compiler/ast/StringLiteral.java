/*     */ package org.eclipse.jdt.internal.compiler.ast;
/*     */ 
/*     */ import org.eclipse.jdt.internal.compiler.ASTVisitor;
/*     */ import org.eclipse.jdt.internal.compiler.codegen.CodeStream;
/*     */ import org.eclipse.jdt.internal.compiler.impl.StringConstant;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.BlockScope;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.TypeBinding;
/*     */ import org.eclipse.jdt.internal.compiler.util.Util;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class StringLiteral
/*     */   extends Literal
/*     */ {
/*     */   char[] source;
/*     */   int lineNumber;
/*     */   
/*     */   public StringLiteral(char[] token, int start, int end, int lineNumber) {
/*  30 */     this(start, end);
/*  31 */     this.source = token;
/*  32 */     this.lineNumber = lineNumber - 1;
/*     */   }
/*     */ 
/*     */   
/*     */   public StringLiteral(int s, int e) {
/*  37 */     super(s, e);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void computeConstant() {
/*  43 */     this.constant = StringConstant.fromValue(String.valueOf(this.source));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ExtendedStringLiteral extendWith(CharLiteral lit) {
/*  49 */     return new ExtendedStringLiteral(this, lit);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ExtendedStringLiteral extendWith(StringLiteral lit) {
/*  55 */     return new ExtendedStringLiteral(this, lit);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public StringLiteralConcatenation extendsWith(StringLiteral lit) {
/*  62 */     return new StringLiteralConcatenation(this, lit);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void generateCode(BlockScope currentScope, CodeStream codeStream, boolean valueRequired) {
/*  70 */     int pc = codeStream.position;
/*  71 */     if (valueRequired)
/*  72 */       codeStream.ldc(this.constant.stringValue()); 
/*  73 */     codeStream.recordPositionsFrom(pc, this.sourceStart);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public TypeBinding literalType(BlockScope scope) {
/*  79 */     return (TypeBinding)scope.getJavaLangString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public StringBuffer printExpression(int indent, StringBuffer output) {
/*  86 */     output.append('"');
/*  87 */     for (int i = 0; i < this.source.length; i++) {
/*  88 */       Util.appendEscapedChar(output, this.source[i], true);
/*     */     }
/*  90 */     output.append('"');
/*  91 */     return output;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public char[] source() {
/*  97 */     return this.source;
/*     */   }
/*     */ 
/*     */   
/*     */   public void traverse(ASTVisitor visitor, BlockScope scope) {
/* 102 */     visitor.visit(this, scope);
/* 103 */     visitor.endVisit(this, scope);
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\ast\StringLiteral.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */