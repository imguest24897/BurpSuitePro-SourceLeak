/*     */ package org.eclipse.jdt.internal.compiler.ast;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import org.eclipse.jdt.internal.compiler.ASTVisitor;
/*     */ import org.eclipse.jdt.internal.compiler.codegen.CodeStream;
/*     */ import org.eclipse.jdt.internal.compiler.flow.FlowContext;
/*     */ import org.eclipse.jdt.internal.compiler.flow.FlowInfo;
/*     */ import org.eclipse.jdt.internal.compiler.impl.CompilerOptions;
/*     */ import org.eclipse.jdt.internal.compiler.impl.Constant;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.AnnotationBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.Binding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.BlockScope;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.ImplicitNullAnnotationVerifier;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.IntersectionTypeBinding18;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.LocalTypeBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.LookupEnvironment;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.MethodBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.ParameterizedGenericMethodBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.ParameterizedTypeBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.PolyTypeBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.ProblemMethodBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.ProblemReferenceBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.ReferenceBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.Scope;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.SourceTypeBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.Substitution;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.TypeBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.TypeBindingVisitor;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.TypeConstants;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.TypeVariableBinding;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class QualifiedAllocationExpression
/*     */   extends AllocationExpression
/*     */ {
/*     */   public Expression enclosingInstance;
/*     */   public TypeDeclaration anonymousType;
/*     */   
/*     */   public QualifiedAllocationExpression() {}
/*     */   
/*     */   public QualifiedAllocationExpression(TypeDeclaration anonymousType) {
/*  94 */     this.anonymousType = anonymousType;
/*  95 */     anonymousType.allocation = this;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public FlowInfo analyseCode(BlockScope currentScope, FlowContext flowContext, FlowInfo flowInfo) {
/* 101 */     if (this.enclosingInstance != null) {
/* 102 */       flowInfo = this.enclosingInstance.analyseCode(currentScope, flowContext, flowInfo);
/*     */     }
/* 104 */     else if (this.binding != null && this.binding.declaringClass != null) {
/* 105 */       ReferenceBinding superclass = this.binding.declaringClass.superclass();
/* 106 */       if (superclass != null && superclass.isMemberType() && !superclass.isStatic())
/*     */       {
/* 108 */         currentScope.tagAsAccessingEnclosingInstanceStateOf(superclass.enclosingType(), false);
/*     */       }
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 117 */     checkCapturedLocalInitializationIfNecessary(
/* 118 */         (this.anonymousType == null) ? 
/* 119 */         (ReferenceBinding)this.binding.declaringClass.erasure() : 
/* 120 */         (ReferenceBinding)this.binding.declaringClass.superclass().erasure(), 
/* 121 */         currentScope, 
/* 122 */         flowInfo);
/*     */ 
/*     */     
/* 125 */     if (this.arguments != null) {
/* 126 */       boolean analyseResources = (currentScope.compilerOptions()).analyseResourceLeaks;
/* 127 */       boolean hasResourceWrapperType = (analyseResources && 
/* 128 */         this.resolvedType instanceof ReferenceBinding && (
/* 129 */         (ReferenceBinding)this.resolvedType).hasTypeBit(4));
/* 130 */       for (int i = 0, count = this.arguments.length; i < count; i++) {
/* 131 */         flowInfo = this.arguments[i].analyseCode(currentScope, flowContext, flowInfo);
/* 132 */         if (analyseResources && !hasResourceWrapperType)
/*     */         {
/* 134 */           flowInfo = FakedTrackingVariable.markPassedToOutside(currentScope, this.arguments[i], flowInfo, flowContext, false);
/*     */         }
/* 136 */         this.arguments[i].checkNPEbyUnboxing(currentScope, flowContext, flowInfo);
/*     */       } 
/* 138 */       analyseArguments(currentScope, flowContext, flowInfo, this.binding, this.arguments);
/*     */     } 
/*     */ 
/*     */     
/* 142 */     if (this.anonymousType != null) {
/* 143 */       flowInfo = this.anonymousType.analyseCode(currentScope, flowContext, flowInfo);
/*     */     }
/*     */     
/*     */     ReferenceBinding[] thrownExceptions;
/*     */     
/* 148 */     if ((thrownExceptions = this.binding.thrownExceptions).length != 0) {
/* 149 */       if ((this.bits & 0x10000) != 0 && this.genericTypeArguments == null)
/*     */       {
/* 151 */         thrownExceptions = currentScope.environment().convertToRawTypes(this.binding.thrownExceptions, true, true);
/*     */       }
/*     */       
/* 154 */       flowContext.checkExceptionHandlers(
/* 155 */           (TypeBinding[])thrownExceptions, 
/* 156 */           this, 
/* 157 */           (FlowInfo)flowInfo.unconditionalCopy(), 
/* 158 */           currentScope);
/*     */     } 
/*     */ 
/*     */     
/* 162 */     if ((currentScope.compilerOptions()).analyseResourceLeaks && FakedTrackingVariable.isAnyCloseable(this.resolvedType)) {
/* 163 */       FakedTrackingVariable.analyseCloseableAllocation(currentScope, flowInfo, this);
/*     */     }
/*     */     
/* 166 */     manageEnclosingInstanceAccessIfNecessary(currentScope, flowInfo);
/* 167 */     manageSyntheticAccessIfNecessary(currentScope, flowInfo);
/*     */ 
/*     */     
/* 170 */     flowContext.recordAbruptExit();
/*     */     
/* 172 */     return flowInfo;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Expression enclosingInstance() {
/* 178 */     return this.enclosingInstance;
/*     */   }
/*     */ 
/*     */   
/*     */   public void generateCode(BlockScope currentScope, CodeStream codeStream, boolean valueRequired) {
/* 183 */     cleanUpInferenceContexts();
/* 184 */     if (!valueRequired)
/* 185 */       currentScope.problemReporter().unusedObjectAllocation(this); 
/* 186 */     int pc = codeStream.position;
/* 187 */     MethodBinding codegenBinding = this.binding.original();
/* 188 */     ReferenceBinding allocatedType = codegenBinding.declaringClass;
/* 189 */     codeStream.new_(this.type, (TypeBinding)allocatedType);
/* 190 */     boolean isUnboxing = ((this.implicitConversion & 0x400) != 0);
/* 191 */     if (valueRequired || isUnboxing) {
/* 192 */       codeStream.dup();
/*     */     }
/*     */     
/* 195 */     if (this.type != null) {
/* 196 */       codeStream.recordPositionsFrom(pc, this.type.sourceStart);
/*     */     } else {
/*     */       
/* 199 */       codeStream.ldc(String.valueOf(this.enumConstant.name));
/* 200 */       codeStream.generateInlinedValue(this.enumConstant.binding.id);
/*     */     } 
/*     */     
/* 203 */     if (allocatedType.isNestedType()) {
/* 204 */       codeStream.generateSyntheticEnclosingInstanceValues(
/* 205 */           currentScope, 
/* 206 */           allocatedType, 
/* 207 */           enclosingInstance(), 
/* 208 */           this);
/*     */     }
/*     */     
/* 211 */     generateArguments(this.binding, this.arguments, currentScope, codeStream);
/*     */     
/* 213 */     if (allocatedType.isNestedType()) {
/* 214 */       codeStream.generateSyntheticOuterArgumentValues(
/* 215 */           currentScope, 
/* 216 */           allocatedType, 
/* 217 */           this);
/*     */     }
/*     */ 
/*     */     
/* 221 */     if (this.syntheticAccessor == null) {
/* 222 */       codeStream.invoke((byte)-73, codegenBinding, null, this.typeArguments);
/*     */     } else {
/*     */       
/* 225 */       int i = 0;
/* 226 */       int max = this.syntheticAccessor.parameters.length - codegenBinding.parameters.length;
/* 227 */       for (; i < max; 
/* 228 */         i++) {
/* 229 */         codeStream.aconst_null();
/*     */       }
/* 231 */       codeStream.invoke((byte)-73, this.syntheticAccessor, null, this.typeArguments);
/*     */     } 
/* 233 */     if (valueRequired) {
/* 234 */       codeStream.generateImplicitConversion(this.implicitConversion);
/* 235 */     } else if (isUnboxing) {
/*     */       
/* 237 */       codeStream.generateImplicitConversion(this.implicitConversion);
/* 238 */       switch ((postConversionType((Scope)currentScope)).id) {
/*     */         case 7:
/*     */         case 8:
/* 241 */           codeStream.pop2();
/*     */           break;
/*     */         default:
/* 244 */           codeStream.pop(); break;
/*     */       } 
/*     */     } 
/* 247 */     codeStream.recordPositionsFrom(pc, this.sourceStart);
/*     */     
/* 249 */     if (this.anonymousType != null) {
/* 250 */       this.anonymousType.generateCode(currentScope, codeStream);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isSuperAccess() {
/* 258 */     return (this.anonymousType != null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void manageEnclosingInstanceAccessIfNecessary(BlockScope currentScope, FlowInfo flowInfo) {
/* 270 */     if ((flowInfo.tagBits & 0x1) == 0) {
/* 271 */       ReferenceBinding allocatedTypeErasure = (ReferenceBinding)this.binding.declaringClass.erasure();
/*     */ 
/*     */       
/* 274 */       if (allocatedTypeErasure.isNestedType() && (
/* 275 */         currentScope.enclosingSourceType().isLocalType() || currentScope.isLambdaSubscope()))
/*     */       {
/* 277 */         if (allocatedTypeErasure.isLocalType()) {
/* 278 */           ((LocalTypeBinding)allocatedTypeErasure).addInnerEmulationDependent(currentScope, (this.enclosingInstance != null));
/*     */         } else {
/*     */           
/* 281 */           currentScope.propagateInnerEmulation(allocatedTypeErasure, (this.enclosingInstance != null));
/*     */         } 
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public StringBuffer printExpression(int indent, StringBuffer output) {
/* 289 */     if (this.enclosingInstance != null)
/* 290 */       this.enclosingInstance.printExpression(0, output).append('.'); 
/* 291 */     super.printExpression(0, output);
/* 292 */     if (this.anonymousType != null) {
/* 293 */       this.anonymousType.print(indent, output);
/*     */     }
/* 295 */     return output;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public TypeBinding resolveType(BlockScope scope) {
/* 301 */     if (this.anonymousType == null && this.enclosingInstance == null) {
/* 302 */       return super.resolveType(scope);
/*     */     }
/* 304 */     TypeBinding result = resolveTypeForQualifiedAllocationExpression(scope);
/* 305 */     if (result != null && !result.isPolyType() && this.binding != null) {
/* 306 */       CompilerOptions compilerOptions = scope.compilerOptions();
/* 307 */       if (compilerOptions.isAnnotationBasedNullAnalysisEnabled) {
/* 308 */         ImplicitNullAnnotationVerifier.ensureNullnessIsKnown(this.binding, (Scope)scope);
/* 309 */         if (scope.environment().usesNullTypeAnnotations()) {
/* 310 */           if (this.binding instanceof ParameterizedGenericMethodBinding && this.typeArguments != null) {
/* 311 */             TypeVariableBinding[] typeVariables = this.binding.original().typeVariables();
/* 312 */             for (int i = 0; i < this.typeArguments.length; i++)
/* 313 */               this.typeArguments[i].checkNullConstraints((Scope)scope, (Substitution)this.binding, (TypeBinding[])typeVariables, i); 
/*     */           } 
/* 315 */           if (this.resolvedType.isValidBinding()) {
/* 316 */             this.resolvedType = scope.environment().createAnnotatedType(this.resolvedType, new AnnotationBinding[] { scope.environment().getNonNullAnnotation() });
/*     */           }
/*     */         } 
/*     */       } 
/* 320 */       if (compilerOptions.sourceLevel >= 3407872L && 
/* 321 */         this.binding.getTypeAnnotations() != Binding.NO_ANNOTATIONS) {
/* 322 */         this.resolvedType = scope.environment().createAnnotatedType(this.resolvedType, this.binding.getTypeAnnotations());
/*     */       }
/*     */     } 
/* 325 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private TypeBinding resolveTypeForQualifiedAllocationExpression(BlockScope scope) {
/*     */     ReferenceBinding referenceBinding1;
/* 332 */     boolean isDiamond = (this.type != null && (this.type.bits & 0x80000) != 0);
/* 333 */     TypeBinding enclosingInstanceType = null;
/* 334 */     TypeBinding receiverType = null;
/* 335 */     long sourceLevel = (scope.compilerOptions()).sourceLevel;
/* 336 */     if (this.constant != Constant.NotAConstant) {
/* 337 */       this.constant = Constant.NotAConstant;
/* 338 */       ReferenceBinding enclosingInstanceReference = null;
/* 339 */       boolean hasError = false;
/* 340 */       boolean enclosingInstanceContainsCast = false;
/*     */       
/* 342 */       if (this.enclosingInstance != null) {
/* 343 */         if (this.enclosingInstance instanceof CastExpression) {
/* 344 */           this.enclosingInstance.bits |= 0x20;
/* 345 */           enclosingInstanceContainsCast = true;
/*     */         } 
/* 347 */         if ((enclosingInstanceType = this.enclosingInstance.resolveType(scope)) == null)
/* 348 */         { hasError = true; }
/* 349 */         else if (enclosingInstanceType.isBaseType() || enclosingInstanceType.isArrayType())
/* 350 */         { scope.problemReporter().illegalPrimitiveOrArrayTypeForEnclosingInstance(
/* 351 */               enclosingInstanceType, 
/* 352 */               this.enclosingInstance);
/* 353 */           hasError = true; }
/* 354 */         else if (this.type instanceof QualifiedTypeReference)
/* 355 */         { scope.problemReporter().illegalUsageOfQualifiedTypeReference((QualifiedTypeReference)this.type);
/* 356 */           hasError = true; }
/* 357 */         else { ProblemReferenceBinding problemReferenceBinding; if (!(enclosingInstanceReference = (ReferenceBinding)enclosingInstanceType).canBeSeenBy((Scope)scope)) {
/*     */             
/* 359 */             problemReferenceBinding = new ProblemReferenceBinding(
/* 360 */                 enclosingInstanceReference.compoundName, 
/* 361 */                 enclosingInstanceReference, 
/* 362 */                 2);
/* 363 */             scope.problemReporter().invalidType(this.enclosingInstance, (TypeBinding)problemReferenceBinding);
/* 364 */             hasError = true;
/*     */           } else {
/* 366 */             this.resolvedType = receiverType = ((SingleTypeReference)this.type).resolveTypeEnclosing(scope, (ReferenceBinding)problemReferenceBinding);
/* 367 */             checkIllegalNullAnnotation(scope, receiverType);
/* 368 */             if (receiverType != null && enclosingInstanceContainsCast) {
/* 369 */               CastExpression.checkNeedForEnclosingInstanceCast(scope, this.enclosingInstance, (TypeBinding)problemReferenceBinding, receiverType);
/*     */             }
/*     */           }  }
/*     */       
/* 373 */       } else if (this.type == null) {
/*     */         
/* 375 */         SourceTypeBinding sourceTypeBinding = scope.enclosingSourceType();
/*     */       } else {
/* 377 */         receiverType = this.type.resolveType(scope, true);
/* 378 */         checkIllegalNullAnnotation(scope, receiverType);
/*     */         
/* 380 */         if (receiverType != null && receiverType.isValidBinding() && 
/* 381 */           this.type instanceof ParameterizedQualifiedTypeReference) {
/* 382 */           ReferenceBinding currentType = (ReferenceBinding)receiverType;
/*     */ 
/*     */           
/* 385 */           while ((currentType.modifiers & 0x8) == 0 && 
/* 386 */             !currentType.isRawType()) {
/* 387 */             if ((currentType = currentType.enclosingType()) == null) {
/* 388 */               ParameterizedQualifiedTypeReference qRef = (ParameterizedQualifiedTypeReference)this.type;
/* 389 */               for (int i = qRef.typeArguments.length - 2; i >= 0; i--) {
/* 390 */                 if (qRef.typeArguments[i] != null) {
/* 391 */                   scope.problemReporter().illegalQualifiedParameterizedTypeAllocation(this.type, receiverType); break;
/*     */                 } 
/*     */               } 
/*     */               break;
/*     */             } 
/*     */           } 
/*     */         } 
/*     */       } 
/* 399 */       if (receiverType == null || !receiverType.isValidBinding()) {
/* 400 */         hasError = true;
/*     */       }
/*     */ 
/*     */       
/* 404 */       if (this.typeArguments != null) {
/* 405 */         int length = this.typeArguments.length;
/* 406 */         this.argumentsHaveErrors = (sourceLevel < 3211264L);
/* 407 */         this.genericTypeArguments = new TypeBinding[length]; int i;
/* 408 */         for (i = 0; i < length; i++) {
/* 409 */           TypeReference typeReference = this.typeArguments[i];
/* 410 */           this.genericTypeArguments[i] = typeReference.resolveType(scope, true); if (typeReference.resolveType(scope, true) == null) {
/* 411 */             this.argumentsHaveErrors = true;
/*     */           }
/* 413 */           if (this.argumentsHaveErrors && typeReference instanceof Wildcard) {
/* 414 */             scope.problemReporter().illegalUsageOfWildcard(typeReference);
/*     */           }
/*     */         } 
/* 417 */         if (isDiamond) {
/* 418 */           scope.problemReporter().diamondNotWithExplicitTypeArguments(this.typeArguments);
/* 419 */           return null;
/*     */         } 
/* 421 */         if (this.argumentsHaveErrors) {
/* 422 */           if (this.arguments != null) {
/* 423 */             int max; for (i = 0, max = this.arguments.length; i < max; i++) {
/* 424 */               this.arguments[i].resolveType(scope);
/*     */             }
/*     */           } 
/* 427 */           return null;
/*     */         } 
/*     */       } 
/*     */ 
/*     */       
/* 432 */       this.argumentTypes = Binding.NO_PARAMETERS;
/* 433 */       if (this.arguments != null) {
/* 434 */         int length = this.arguments.length;
/* 435 */         this.argumentTypes = new TypeBinding[length];
/* 436 */         for (int i = 0; i < length; i++) {
/* 437 */           Expression argument = this.arguments[i];
/* 438 */           if (argument instanceof CastExpression) {
/* 439 */             argument.bits |= 0x20;
/* 440 */             this.argsContainCast = true;
/*     */           } 
/* 442 */           argument.setExpressionContext(ExpressionContext.INVOCATION_CONTEXT);
/* 443 */           this.argumentTypes[i] = argument.resolveType(scope); if (argument.resolveType(scope) == null) {
/* 444 */             this.argumentsHaveErrors = hasError = true;
/*     */           }
/*     */         } 
/*     */       } 
/*     */ 
/*     */       
/* 450 */       if (hasError) {
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 455 */         if (isDiamond) {
/* 456 */           return null;
/*     */         }
/* 458 */         if (receiverType instanceof ReferenceBinding) {
/* 459 */           ReferenceBinding referenceReceiver = (ReferenceBinding)receiverType;
/* 460 */           if (receiverType.isValidBinding()) {
/*     */             
/* 462 */             int length = (this.arguments == null) ? 0 : this.arguments.length;
/* 463 */             TypeBinding[] pseudoArgs = new TypeBinding[length];
/* 464 */             for (int i = length; --i >= 0;) {
/* 465 */               pseudoArgs[i] = (this.argumentTypes[i] == null) ? (TypeBinding)TypeBinding.NULL : this.argumentTypes[i];
/*     */             }
/* 467 */             this.binding = scope.findMethod(referenceReceiver, TypeConstants.INIT, pseudoArgs, this, false);
/* 468 */             if (this.binding != null && !this.binding.isValidBinding()) {
/* 469 */               MethodBinding closestMatch = ((ProblemMethodBinding)this.binding).closestMatch;
/*     */               
/* 471 */               if (closestMatch != null) {
/* 472 */                 ParameterizedGenericMethodBinding parameterizedGenericMethodBinding; if ((closestMatch.original()).typeVariables != Binding.NO_TYPE_VARIABLES)
/*     */                 {
/* 474 */                   parameterizedGenericMethodBinding = scope.environment().createParameterizedGenericMethod(closestMatch.original(), null);
/*     */                 }
/* 476 */                 this.binding = (MethodBinding)parameterizedGenericMethodBinding;
/* 477 */                 MethodBinding closestMatchOriginal = parameterizedGenericMethodBinding.original();
/* 478 */                 if (closestMatchOriginal.isOrEnclosedByPrivateType() && !scope.isDefinedInMethod(closestMatchOriginal))
/*     */                 {
/* 480 */                   closestMatchOriginal.modifiers |= 0x8000000;
/*     */                 }
/*     */               } 
/*     */             } 
/*     */           } 
/* 485 */           if (this.anonymousType != null) {
/*     */             
/* 487 */             scope.addAnonymousType(this.anonymousType, referenceReceiver);
/* 488 */             this.anonymousType.resolve(scope);
/* 489 */             return this.resolvedType = (TypeBinding)this.anonymousType.binding;
/*     */           } 
/*     */         } 
/* 492 */         return this.resolvedType = receiverType;
/*     */       } 
/* 494 */       if (this.anonymousType == null) {
/*     */         
/* 496 */         if (!receiverType.canBeInstantiated()) {
/* 497 */           scope.problemReporter().cannotInstantiate(this.type, receiverType);
/* 498 */           return this.resolvedType = receiverType;
/*     */         } 
/*     */       } else {
/* 501 */         ProblemReferenceBinding problemReferenceBinding; if (isDiamond && 
/* 502 */           sourceLevel < 3473408L) {
/* 503 */           scope.problemReporter().diamondNotWithAnoymousClasses(this.type);
/* 504 */           return null;
/*     */         } 
/*     */         
/* 507 */         ReferenceBinding referenceBinding = (ReferenceBinding)receiverType;
/* 508 */         if (referenceBinding.isTypeVariable()) {
/* 509 */           problemReferenceBinding = new ProblemReferenceBinding(new char[][] { referenceBinding.sourceName() }, referenceBinding, 9);
/* 510 */           scope.problemReporter().invalidType(this, (TypeBinding)problemReferenceBinding);
/* 511 */           return null;
/* 512 */         }  if (this.type != null && problemReferenceBinding.isEnum()) {
/* 513 */           scope.problemReporter().cannotInstantiate(this.type, (TypeBinding)problemReferenceBinding);
/* 514 */           return this.resolvedType = (TypeBinding)problemReferenceBinding;
/*     */         } 
/* 516 */         this.resolvedType = receiverType;
/*     */       }
/*     */     
/* 519 */     } else if (this.enclosingInstance != null) {
/* 520 */       enclosingInstanceType = this.enclosingInstance.resolvedType;
/* 521 */       this.resolvedType = receiverType = this.type.resolvedType;
/*     */     } 
/*     */     
/* 524 */     MethodBinding constructorBinding = null;
/* 525 */     if (isDiamond) {
/* 526 */       this.binding = constructorBinding = inferConstructorOfElidedParameterizedType((Scope)scope);
/* 527 */       if (this.binding == null || !this.binding.isValidBinding()) {
/* 528 */         scope.problemReporter().cannotInferElidedTypes(this);
/* 529 */         return this.resolvedType = null;
/*     */       } 
/* 531 */       if (this.typeExpected == null && sourceLevel >= 3407872L && this.expressionContext.definesTargetType()) {
/* 532 */         return (TypeBinding)new PolyTypeBinding(this);
/*     */       }
/* 534 */       this.resolvedType = this.type.resolvedType = (TypeBinding)(referenceBinding1 = this.binding.declaringClass);
/* 535 */       if (this.anonymousType != null) {
/* 536 */         constructorBinding = getAnonymousConstructorBinding(referenceBinding1, scope);
/* 537 */         if (constructorBinding == null)
/* 538 */           return null; 
/* 539 */         this.resolvedType = (TypeBinding)this.anonymousType.binding;
/*     */         
/* 541 */         if (!validate((ParameterizedTypeBinding)referenceBinding1, (Scope)scope)) {
/* 542 */           return this.resolvedType;
/*     */         
/*     */         }
/*     */       }
/* 546 */       else if (this.binding.isVarargs()) {
/* 547 */         TypeBinding lastArg = this.binding.parameters[this.binding.parameters.length - 1].leafComponentType();
/* 548 */         if (!lastArg.erasure().canBeSeenBy((Scope)scope)) {
/* 549 */           scope.problemReporter().invalidType(this, (TypeBinding)new ProblemReferenceBinding(new char[][] { lastArg.readableName() }, (ReferenceBinding)lastArg, 2));
/* 550 */           return this.resolvedType = null;
/*     */         } 
/*     */       } 
/*     */       
/* 554 */       this.binding = resolvePolyExpressionArguments(this, this.binding, this.argumentTypes, scope);
/*     */     }
/* 556 */     else if (this.anonymousType != null) {
/* 557 */       constructorBinding = getAnonymousConstructorBinding(referenceBinding1, scope);
/* 558 */       if (constructorBinding == null)
/* 559 */         return null; 
/* 560 */       this.resolvedType = (TypeBinding)this.anonymousType.binding;
/*     */     } else {
/* 562 */       this.binding = constructorBinding = findConstructorBinding(scope, this, referenceBinding1, this.argumentTypes);
/*     */     } 
/*     */     
/* 565 */     ReferenceBinding receiver = referenceBinding1;
/* 566 */     ReferenceBinding superType = receiver.isInterface() ? scope.getJavaLangObject() : receiver;
/* 567 */     if (constructorBinding.isValidBinding()) {
/* 568 */       if (isMethodUseDeprecated(constructorBinding, (Scope)scope, true, this)) {
/* 569 */         scope.problemReporter().deprecatedMethod(constructorBinding, this);
/*     */       }
/* 571 */       if (checkInvocationArguments(scope, null, (TypeBinding)superType, constructorBinding, this.arguments, 
/* 572 */           this.argumentTypes, this.argsContainCast, this)) {
/* 573 */         this.bits |= 0x10000;
/*     */       }
/* 575 */       if (this.typeArguments != null && (constructorBinding.original()).typeVariables == Binding.NO_TYPE_VARIABLES) {
/* 576 */         scope.problemReporter().unnecessaryTypeArgumentsForMethodInvocation(constructorBinding, 
/* 577 */             this.genericTypeArguments, this.typeArguments);
/*     */       }
/*     */     } else {
/* 580 */       if (constructorBinding.declaringClass == null) {
/* 581 */         constructorBinding.declaringClass = superType;
/*     */       }
/* 583 */       if (this.type != null && !this.type.resolvedType.isValidBinding())
/*     */       {
/* 585 */         return null;
/*     */       }
/* 587 */       scope.problemReporter().invalidConstructor(this, constructorBinding);
/* 588 */       return this.resolvedType;
/*     */     } 
/* 590 */     if ((constructorBinding.tagBits & 0x80L) != 0L) {
/* 591 */       scope.problemReporter().missingTypeInConstructor(this, constructorBinding);
/*     */     }
/* 593 */     if (this.enclosingInstance != null) {
/* 594 */       ReferenceBinding targetEnclosing = constructorBinding.declaringClass.enclosingType();
/* 595 */       if (targetEnclosing == null) {
/* 596 */         scope.problemReporter().unnecessaryEnclosingInstanceSpecification(this.enclosingInstance, receiver);
/* 597 */         return this.resolvedType;
/* 598 */       }  if (!enclosingInstanceType.isCompatibleWith((TypeBinding)targetEnclosing) && !scope.isBoxingCompatibleWith(enclosingInstanceType, (TypeBinding)targetEnclosing)) {
/* 599 */         scope.problemReporter().typeMismatchError(enclosingInstanceType, (TypeBinding)targetEnclosing, this.enclosingInstance, null);
/* 600 */         return this.resolvedType;
/*     */       } 
/* 602 */       this.enclosingInstance.computeConversion((Scope)scope, (TypeBinding)targetEnclosing, enclosingInstanceType);
/*     */     } 
/* 604 */     if (!isDiamond && referenceBinding1.isParameterizedTypeWithActualArguments() && (
/* 605 */       this.anonymousType == null || sourceLevel >= 3473408L)) {
/* 606 */       checkTypeArgumentRedundancy((ParameterizedTypeBinding)referenceBinding1, scope);
/*     */     }
/* 608 */     if (this.anonymousType != null) {
/*     */ 
/*     */       
/* 611 */       LookupEnvironment environment = scope.environment();
/* 612 */       if (environment.globalOptions.isAnnotationBasedNullAnalysisEnabled) {
/* 613 */         ImplicitNullAnnotationVerifier.ensureNullnessIsKnown(constructorBinding, (Scope)scope);
/*     */       }
/* 615 */       this.binding = this.anonymousType.createDefaultConstructorWithBinding(constructorBinding, ((this.bits & 0x10000) != 0 && this.genericTypeArguments == null));
/* 616 */       return this.resolvedType;
/*     */     } 
/* 618 */     return this.resolvedType = (TypeBinding)referenceBinding1;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean validate(final ParameterizedTypeBinding allocationType, final Scope scope) {
/*     */     class ValidityInspector
/*     */       extends TypeBindingVisitor
/*     */     {
/*     */       private boolean noErrors = true;
/*     */ 
/*     */ 
/*     */       
/*     */       public boolean visit(IntersectionTypeBinding18 intersectionTypeBinding18) {
/* 632 */         Arrays.sort(intersectionTypeBinding18.intersectingTypes, (t1, t2) -> t1.id - t2.id);
/* 633 */         scope.problemReporter().anonymousDiamondWithNonDenotableTypeArguments(QualifiedAllocationExpression.this.type, (TypeBinding)allocationType);
/* 634 */         return this.noErrors = false;
/*     */       }
/*     */       
/*     */       public boolean visit(TypeVariableBinding typeVariable) {
/* 638 */         if (typeVariable.isCapture()) {
/* 639 */           scope.problemReporter().anonymousDiamondWithNonDenotableTypeArguments(QualifiedAllocationExpression.this.type, (TypeBinding)allocationType);
/* 640 */           return this.noErrors = false;
/*     */         } 
/* 642 */         return true;
/*     */       }
/*     */       
/*     */       public boolean visit(ReferenceBinding ref) {
/* 646 */         if (!ref.canBeSeenBy(scope)) {
/* 647 */           scope.problemReporter().invalidType(QualifiedAllocationExpression.this.anonymousType, (TypeBinding)new ProblemReferenceBinding(ref.compoundName, ref, 2));
/* 648 */           return this.noErrors = false;
/*     */         } 
/* 650 */         return true;
/*     */       }
/*     */       public boolean isValid() {
/* 653 */         TypeBindingVisitor.visit(this, (TypeBinding)allocationType);
/* 654 */         return this.noErrors;
/*     */       }
/*     */     };
/*     */     
/* 658 */     return (new ValidityInspector()).isValid();
/*     */   }
/*     */   private MethodBinding getAnonymousConstructorBinding(ReferenceBinding receiverType, BlockScope scope) {
/* 661 */     ReferenceBinding superType = receiverType;
/*     */     
/* 663 */     ReferenceBinding anonymousSuperclass = superType.isInterface() ? scope.getJavaLangObject() : superType;
/*     */     
/* 665 */     scope.addAnonymousType(this.anonymousType, superType);
/* 666 */     this.anonymousType.resolve(scope);
/*     */ 
/*     */     
/* 669 */     this.resolvedType = (TypeBinding)this.anonymousType.binding;
/* 670 */     if ((this.resolvedType.tagBits & 0x20000L) != 0L) {
/* 671 */       return null;
/*     */     }
/* 673 */     return findConstructorBinding(scope, this, anonymousSuperclass, this.argumentTypes);
/*     */   }
/*     */   
/*     */   public void traverse(ASTVisitor visitor, BlockScope scope) {
/* 677 */     if (visitor.visit(this, scope)) {
/* 678 */       if (this.enclosingInstance != null)
/* 679 */         this.enclosingInstance.traverse(visitor, scope); 
/* 680 */       if (this.typeArguments != null) {
/* 681 */         for (int i = 0, typeArgumentsLength = this.typeArguments.length; i < typeArgumentsLength; i++) {
/* 682 */           this.typeArguments[i].traverse(visitor, scope);
/*     */         }
/*     */       }
/* 685 */       if (this.type != null)
/* 686 */         this.type.traverse(visitor, scope); 
/* 687 */       if (this.arguments != null) {
/* 688 */         int argumentsLength = this.arguments.length;
/* 689 */         for (int i = 0; i < argumentsLength; i++)
/* 690 */           this.arguments[i].traverse(visitor, scope); 
/*     */       } 
/* 692 */       if (this.anonymousType != null)
/* 693 */         this.anonymousType.traverse(visitor, scope); 
/*     */     } 
/* 695 */     visitor.endVisit(this, scope);
/*     */   }
/*     */   
/*     */   protected void reportTypeArgumentRedundancyProblem(ParameterizedTypeBinding allocationType, BlockScope scope) {
/* 699 */     if (checkDiamondOperatorCanbeRemoved(scope))
/* 700 */       scope.problemReporter().redundantSpecificationOfTypeArguments(this.type, allocationType.arguments); 
/*     */   }
/*     */   
/*     */   private boolean checkDiamondOperatorCanbeRemoved(BlockScope scope) {
/* 704 */     if (this.anonymousType != null && 
/* 705 */       this.anonymousType.methods != null && 
/* 706 */       this.anonymousType.methods.length > 0) {
/*     */       
/* 708 */       if ((scope.compilerOptions()).complianceLevel < 3473408L) return false;  byte b; int i; AbstractMethodDeclaration[] arrayOfAbstractMethodDeclaration;
/* 709 */       for (i = (arrayOfAbstractMethodDeclaration = this.anonymousType.methods).length, b = 0; b < i; ) { AbstractMethodDeclaration method = arrayOfAbstractMethodDeclaration[b];
/* 710 */         if (method.binding != null && (method.binding.modifiers & 0x10000000) == 0)
/* 711 */           return false;  b++; }
/*     */     
/*     */     } 
/* 714 */     return true;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\ast\QualifiedAllocationExpression.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */