/*     */ package org.eclipse.jdt.internal.compiler.apt.model;
/*     */ 
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.lang.reflect.Array;
/*     */ import java.lang.reflect.Proxy;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.EnumSet;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import javax.lang.model.element.AnnotationMirror;
/*     */ import javax.lang.model.element.Element;
/*     */ import javax.lang.model.element.ElementKind;
/*     */ import javax.lang.model.element.Modifier;
/*     */ import javax.lang.model.element.PackageElement;
/*     */ import javax.lang.model.element.TypeParameterElement;
/*     */ import javax.lang.model.type.ErrorType;
/*     */ import javax.lang.model.type.NoType;
/*     */ import javax.lang.model.type.NullType;
/*     */ import javax.lang.model.type.TypeKind;
/*     */ import javax.lang.model.type.TypeMirror;
/*     */ import org.eclipse.jdt.core.compiler.CharOperation;
/*     */ import org.eclipse.jdt.internal.compiler.apt.dispatch.BaseProcessingEnvImpl;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.AnnotationBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.ArrayBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.BaseTypeBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.Binding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.ElementValuePair;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.MethodBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.ModuleBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.PackageBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.ParameterizedTypeBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.PlainPackageBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.ReferenceBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.TypeBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.TypeConstants;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.TypeVariableBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.VariableBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.WildcardBinding;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Factory
/*     */ {
/*  70 */   public static final Byte DUMMY_BYTE = Byte.valueOf((byte)0);
/*  71 */   public static final Character DUMMY_CHAR = Character.valueOf('0');
/*  72 */   public static final Double DUMMY_DOUBLE = Double.valueOf(0.0D);
/*  73 */   public static final Float DUMMY_FLOAT = Float.valueOf(0.0F);
/*  74 */   public static final Integer DUMMY_INTEGER = Integer.valueOf(0);
/*  75 */   public static final Long DUMMY_LONG = Long.valueOf(0L);
/*  76 */   public static final Short DUMMY_SHORT = Short.valueOf((short)0);
/*     */   
/*     */   private final BaseProcessingEnvImpl _env;
/*  79 */   public static List<? extends AnnotationMirror> EMPTY_ANNOTATION_MIRRORS = Collections.emptyList();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Factory(BaseProcessingEnvImpl env) {
/*  85 */     this._env = env;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<? extends AnnotationMirror> getAnnotationMirrors(AnnotationBinding[] annotations) {
/*  93 */     if (annotations == null || annotations.length == 0) {
/*  94 */       return Collections.emptyList();
/*     */     }
/*  96 */     List<AnnotationMirror> list = new ArrayList<>(annotations.length); byte b; int i; AnnotationBinding[] arrayOfAnnotationBinding;
/*  97 */     for (i = (arrayOfAnnotationBinding = annotations).length, b = 0; b < i; ) { AnnotationBinding annotation = arrayOfAnnotationBinding[b];
/*  98 */       if (annotation != null)
/*  99 */         list.add(newAnnotationMirror(annotation));  b++; }
/*     */     
/* 101 */     return Collections.unmodifiableList(list);
/*     */   }
/*     */ 
/*     */   
/*     */   public <A extends Annotation> A[] getAnnotationsByType(AnnotationBinding[] annoInstances, Class<A> annotationClass) {
/* 106 */     Annotation[] result = getAnnotations(annoInstances, annotationClass, false);
/* 107 */     return (result == null) ? (A[])Array.newInstance(annotationClass, 0) : (A[])result;
/*     */   }
/*     */ 
/*     */   
/*     */   public <A extends Annotation> A getAnnotation(AnnotationBinding[] annoInstances, Class<A> annotationClass) {
/* 112 */     Annotation[] result = getAnnotations(annoInstances, annotationClass, true);
/* 113 */     return (result == null) ? null : (A)result[0];
/*     */   }
/*     */ 
/*     */   
/*     */   private <A extends Annotation> A[] getAnnotations(AnnotationBinding[] annoInstances, Class<A> annotationClass, boolean justTheFirst) {
/* 118 */     if (annoInstances == null || annoInstances.length == 0 || annotationClass == null) {
/* 119 */       return null;
/*     */     }
/* 121 */     String annoTypeName = annotationClass.getName();
/* 122 */     if (annoTypeName == null) return null;
/*     */     
/* 124 */     List<A> list = new ArrayList<>(annoInstances.length); byte b; int i; AnnotationBinding[] arrayOfAnnotationBinding;
/* 125 */     for (i = (arrayOfAnnotationBinding = annoInstances).length, b = 0; b < i; ) { AnnotationBinding annoInstance = arrayOfAnnotationBinding[b];
/* 126 */       if (annoInstance != null) {
/*     */ 
/*     */         
/* 129 */         AnnotationMirrorImpl annoMirror = createAnnotationMirror(annoTypeName, annoInstance);
/* 130 */         if (annoMirror != null)
/* 131 */         { list.add((A)Proxy.newProxyInstance(annotationClass.getClassLoader(), new Class[] { annotationClass }, annoMirror));
/* 132 */           if (justTheFirst)
/*     */             break;  } 
/*     */       }  b++; }
/* 135 */      Annotation[] result = (Annotation[])Array.newInstance(annotationClass, list.size());
/* 136 */     return (list.size() > 0) ? (A[])list.<Annotation>toArray(result) : null;
/*     */   }
/*     */   
/*     */   private AnnotationMirrorImpl createAnnotationMirror(String annoTypeName, AnnotationBinding annoInstance) {
/* 140 */     ReferenceBinding binding = annoInstance.getAnnotationType();
/* 141 */     if (binding != null && binding.isAnnotationType()) {
/*     */       char[] qName;
/* 143 */       if (binding.isMemberType()) {
/* 144 */         annoTypeName = annoTypeName.replace('$', '.');
/* 145 */         qName = CharOperation.concatWith((binding.enclosingType()).compoundName, binding.sourceName, '.');
/* 146 */         CharOperation.replace(qName, '$', '.');
/*     */       } else {
/* 148 */         qName = CharOperation.concatWith(binding.compoundName, '.');
/*     */       } 
/* 150 */       if (annoTypeName.equals(new String(qName))) {
/* 151 */         return (AnnotationMirrorImpl)this._env.getFactory().newAnnotationMirror(annoInstance);
/*     */       }
/*     */     } 
/* 154 */     return null;
/*     */   }
/*     */   
/*     */   private static void appendModifier(Set<Modifier> result, int modifiers, int modifierConstant, Modifier modifier) {
/* 158 */     if ((modifiers & modifierConstant) != 0) {
/* 159 */       result.add(modifier);
/*     */     }
/*     */   }
/*     */   
/*     */   private static void decodeModifiers(Set<Modifier> result, int modifiers, int[] checkBits) {
/* 164 */     if (checkBits == null)
/* 165 */       return;  for (int i = 0, max = checkBits.length; i < max; i++) {
/* 166 */       switch (checkBits[i]) {
/*     */         case 1:
/* 168 */           appendModifier(result, modifiers, checkBits[i], Modifier.PUBLIC);
/*     */           break;
/*     */         case 4:
/* 171 */           appendModifier(result, modifiers, checkBits[i], Modifier.PROTECTED);
/*     */           break;
/*     */         case 2:
/* 174 */           appendModifier(result, modifiers, checkBits[i], Modifier.PRIVATE);
/*     */           break;
/*     */         case 1024:
/* 177 */           appendModifier(result, modifiers, checkBits[i], Modifier.ABSTRACT);
/*     */           break;
/*     */         case 65536:
/*     */           try {
/* 181 */             appendModifier(result, modifiers, checkBits[i], Modifier.valueOf("DEFAULT"));
/* 182 */           } catch (IllegalArgumentException illegalArgumentException) {}
/*     */           break;
/*     */ 
/*     */         
/*     */         case 8:
/* 187 */           appendModifier(result, modifiers, checkBits[i], Modifier.STATIC);
/*     */           break;
/*     */         case 16:
/* 190 */           appendModifier(result, modifiers, checkBits[i], Modifier.FINAL);
/*     */           break;
/*     */         case 32:
/* 193 */           appendModifier(result, modifiers, checkBits[i], Modifier.SYNCHRONIZED);
/*     */           break;
/*     */         case 256:
/* 196 */           appendModifier(result, modifiers, checkBits[i], Modifier.NATIVE);
/*     */           break;
/*     */         case 2048:
/* 199 */           appendModifier(result, modifiers, checkBits[i], Modifier.STRICTFP);
/*     */           break;
/*     */         case 128:
/* 202 */           appendModifier(result, modifiers, checkBits[i], Modifier.TRANSIENT);
/*     */           break;
/*     */         case 64:
/* 205 */           appendModifier(result, modifiers, checkBits[i], Modifier.VOLATILE);
/*     */           break;
/*     */         case 67108864:
/*     */           try {
/* 209 */             appendModifier(result, modifiers, checkBits[i], Modifier.valueOf("NON_SEALED"));
/* 210 */           } catch (IllegalArgumentException illegalArgumentException) {}
/*     */           break;
/*     */ 
/*     */         
/*     */         case 268435456:
/*     */           try {
/* 216 */             appendModifier(result, modifiers, checkBits[i], Modifier.valueOf("SEALED"));
/* 217 */           } catch (IllegalArgumentException illegalArgumentException) {}
/*     */           break;
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static Object getMatchingDummyValue(Class<?> expectedType) {
/* 226 */     if (expectedType.isPrimitive()) {
/* 227 */       if (expectedType == boolean.class)
/* 228 */         return Boolean.FALSE; 
/* 229 */       if (expectedType == byte.class)
/* 230 */         return DUMMY_BYTE; 
/* 231 */       if (expectedType == char.class)
/* 232 */         return DUMMY_CHAR; 
/* 233 */       if (expectedType == double.class)
/* 234 */         return DUMMY_DOUBLE; 
/* 235 */       if (expectedType == float.class)
/* 236 */         return DUMMY_FLOAT; 
/* 237 */       if (expectedType == int.class)
/* 238 */         return DUMMY_INTEGER; 
/* 239 */       if (expectedType == long.class)
/* 240 */         return DUMMY_LONG; 
/* 241 */       if (expectedType == short.class) {
/* 242 */         return DUMMY_SHORT;
/*     */       }
/* 244 */       return DUMMY_INTEGER;
/*     */     } 
/*     */     
/* 247 */     return null;
/*     */   }
/*     */   
/*     */   public TypeMirror getReceiverType(MethodBinding binding) {
/* 251 */     if (binding != null) {
/* 252 */       if (binding.receiver != null) {
/* 253 */         return this._env.getFactory().newTypeMirror((Binding)binding.receiver);
/*     */       }
/* 255 */       if (binding.declaringClass != null && 
/* 256 */         !binding.isStatic() && (!binding.isConstructor() || binding.declaringClass.isMemberType())) {
/* 257 */         return this._env.getFactory().newTypeMirror((Binding)binding.declaringClass);
/*     */       }
/*     */     } 
/*     */     
/* 261 */     return NoTypeImpl.NO_TYPE_NONE;
/*     */   }
/*     */   
/*     */   public static Set<Modifier> getModifiers(int modifiers, ElementKind kind) {
/* 265 */     return getModifiers(modifiers, kind, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Set<Modifier> getModifiers(int modifiers, ElementKind kind, boolean isFromBinary) {
/* 272 */     EnumSet<Modifier> result = EnumSet.noneOf(Modifier.class);
/* 273 */     switch (kind) {
/*     */       
/*     */       case METHOD:
/*     */       case CONSTRUCTOR:
/* 277 */         decodeModifiers(result, modifiers, new int[] {
/* 278 */               1, 
/* 279 */               4, 
/* 280 */               2, 
/* 281 */               1024, 
/* 282 */               8, 
/* 283 */               16, 
/* 284 */               32, 
/* 285 */               256, 
/* 286 */               2048, 
/* 287 */               65536
/*     */             });
/*     */         break;
/*     */       
/*     */       case ENUM_CONSTANT:
/*     */       case FIELD:
/* 293 */         decodeModifiers(result, modifiers, new int[] {
/* 294 */               1, 
/* 295 */               4, 
/* 296 */               2, 
/* 297 */               8, 
/* 298 */               16, 
/* 299 */               128, 
/* 300 */               64
/*     */             });
/*     */         break;
/*     */       case ENUM:
/* 304 */         if (isFromBinary) {
/* 305 */           decodeModifiers(result, modifiers, new int[] {
/* 306 */                 1, 
/* 307 */                 4, 
/* 308 */                 16, 
/* 309 */                 2, 
/* 310 */                 1024, 
/* 311 */                 8, 
/* 312 */                 2048, 
/* 313 */                 268435456
/*     */               });
/*     */           break;
/*     */         } 
/* 317 */         decodeModifiers(result, modifiers, new int[] {
/* 318 */               1, 
/* 319 */               4, 
/* 320 */               16, 
/* 321 */               2, 
/* 322 */               8, 
/* 323 */               2048, 
/* 324 */               268435456
/*     */             });
/*     */         break;
/*     */ 
/*     */       
/*     */       case CLASS:
/*     */       case null:
/*     */       case INTERFACE:
/*     */       case RECORD:
/* 333 */         decodeModifiers(result, modifiers, new int[] {
/* 334 */               1, 
/* 335 */               4, 
/* 336 */               1024, 
/* 337 */               16, 
/* 338 */               2, 
/* 339 */               8, 
/* 340 */               2048, 
/* 341 */               268435456, 
/* 342 */               67108864
/*     */             });
/*     */         break;
/*     */       case MODULE:
/* 346 */         decodeModifiers(result, modifiers, new int[] {
/* 347 */               32, 
/* 348 */               32
/*     */             });
/*     */         break;
/*     */     } 
/*     */     
/* 353 */     return Collections.unmodifiableSet(result);
/*     */   }
/*     */ 
/*     */   
/*     */   public AnnotationMirror newAnnotationMirror(AnnotationBinding binding) {
/* 358 */     return new AnnotationMirrorImpl(this._env, binding);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Element newElement(Binding binding, ElementKind kindHint) {
/*     */     ReferenceBinding referenceBinding;
/* 365 */     if (binding == null)
/* 366 */       return null; 
/* 367 */     switch (binding.kind()) {
/*     */       case 1:
/*     */       case 2:
/*     */       case 3:
/*     */       case 131072:
/* 372 */         return new VariableElementImpl(this._env, (VariableBinding)binding);
/*     */       case 4:
/*     */       case 2052:
/* 375 */         referenceBinding = (ReferenceBinding)binding;
/* 376 */         if ((referenceBinding.tagBits & 0x80L) != 0L) {
/* 377 */           return new ErrorTypeElement(this._env, referenceBinding);
/*     */         }
/* 379 */         if (CharOperation.equals(referenceBinding.sourceName, TypeConstants.PACKAGE_INFO_NAME)) {
/* 380 */           return newPackageElement(referenceBinding.fPackage);
/*     */         }
/* 382 */         return new TypeElementImpl(this._env, referenceBinding, kindHint);
/*     */       case 8:
/* 384 */         return new ExecutableElementImpl(this._env, (MethodBinding)binding);
/*     */       case 260:
/*     */       case 1028:
/* 387 */         return new TypeElementImpl(this._env, ((ParameterizedTypeBinding)binding).genericType(), kindHint);
/*     */       case 16:
/* 389 */         return newPackageElement((PackageBinding)binding);
/*     */       case 4100:
/* 391 */         return new TypeParameterElementImpl(this._env, (TypeVariableBinding)binding);
/*     */       
/*     */       case 64:
/* 394 */         return new ModuleElementImpl(this._env, (ModuleBinding)binding);
/*     */       case 32:
/*     */       case 68:
/*     */       case 132:
/*     */       case 516:
/*     */       case 8196:
/* 400 */         throw new UnsupportedOperationException("NYI: binding type " + binding.kind());
/*     */     } 
/* 402 */     return null;
/*     */   }
/*     */   
/*     */   public Element newElement(Binding binding) {
/* 406 */     return newElement(binding, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PackageElement newPackageElement(PackageBinding binding) {
/*     */     PlainPackageBinding plainPackageBinding;
/* 414 */     if (binding != null && binding.enclosingModule != null) {
/* 415 */       plainPackageBinding = binding.getIncarnation(binding.enclosingModule);
/*     */     }
/* 417 */     if (plainPackageBinding == null) {
/* 418 */       return null;
/*     */     }
/* 420 */     return new PackageElementImpl(this._env, (PackageBinding)plainPackageBinding);
/*     */   }
/*     */   
/*     */   public NullType getNullType() {
/* 424 */     return NoTypeImpl.NULL_TYPE;
/*     */   }
/*     */ 
/*     */   
/*     */   public NoType getNoType(TypeKind kind) {
/* 429 */     switch (kind) {
/*     */       case NONE:
/* 431 */         return NoTypeImpl.NO_TYPE_NONE;
/*     */       case VOID:
/* 433 */         return NoTypeImpl.NO_TYPE_VOID;
/*     */       case PACKAGE:
/* 435 */         return NoTypeImpl.NO_TYPE_PACKAGE;
/*     */       case MODULE:
/* 437 */         return new NoTypeImpl(kind);
/*     */     } 
/* 439 */     throw new IllegalArgumentException();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PrimitiveTypeImpl getPrimitiveType(TypeKind kind) {
/* 449 */     switch (kind) {
/*     */       case BOOLEAN:
/* 451 */         return PrimitiveTypeImpl.BOOLEAN;
/*     */       case BYTE:
/* 453 */         return PrimitiveTypeImpl.BYTE;
/*     */       case CHAR:
/* 455 */         return PrimitiveTypeImpl.CHAR;
/*     */       case DOUBLE:
/* 457 */         return PrimitiveTypeImpl.DOUBLE;
/*     */       case FLOAT:
/* 459 */         return PrimitiveTypeImpl.FLOAT;
/*     */       case INT:
/* 461 */         return PrimitiveTypeImpl.INT;
/*     */       case LONG:
/* 463 */         return PrimitiveTypeImpl.LONG;
/*     */       case SHORT:
/* 465 */         return PrimitiveTypeImpl.SHORT;
/*     */     } 
/* 467 */     throw new IllegalArgumentException();
/*     */   }
/*     */ 
/*     */   
/*     */   public PrimitiveTypeImpl getPrimitiveType(BaseTypeBinding binding) {
/* 472 */     AnnotationBinding[] annotations = binding.getTypeAnnotations();
/* 473 */     if (annotations == null || annotations.length == 0) {
/* 474 */       return getPrimitiveType(PrimitiveTypeImpl.getKind(binding));
/*     */     }
/* 476 */     return new PrimitiveTypeImpl(this._env, binding);
/*     */   }
/*     */ 
/*     */   
/*     */   public TypeMirror newTypeMirror(Binding binding) {
/*     */     ReferenceBinding referenceBinding;
/*     */     BaseTypeBinding btb;
/* 483 */     switch (binding.kind()) {
/*     */       
/*     */       case 1:
/*     */       case 2:
/*     */       case 3:
/*     */       case 131072:
/* 489 */         return newTypeMirror((Binding)((VariableBinding)binding).type);
/*     */       
/*     */       case 16:
/* 492 */         return getNoType(TypeKind.PACKAGE);
/*     */       
/*     */       case 32:
/* 495 */         throw new UnsupportedOperationException("NYI: import type " + binding.kind());
/*     */       
/*     */       case 8:
/* 498 */         return new ExecutableTypeImpl(this._env, (MethodBinding)binding);
/*     */       
/*     */       case 4:
/*     */       case 260:
/*     */       case 1028:
/*     */       case 2052:
/* 504 */         referenceBinding = (ReferenceBinding)binding;
/* 505 */         if ((referenceBinding.tagBits & 0x80L) != 0L) {
/* 506 */           return getErrorType(referenceBinding);
/*     */         }
/* 508 */         return new DeclaredTypeImpl(this._env, (ReferenceBinding)binding);
/*     */       
/*     */       case 68:
/* 511 */         return new ArrayTypeImpl(this._env, (ArrayBinding)binding);
/*     */       
/*     */       case 132:
/* 514 */         btb = (BaseTypeBinding)binding;
/* 515 */         switch (btb.id) {
/*     */           case 6:
/* 517 */             return getNoType(TypeKind.VOID);
/*     */           case 12:
/* 519 */             return getNullType();
/*     */         } 
/* 521 */         return getPrimitiveType(btb);
/*     */ 
/*     */       
/*     */       case 516:
/*     */       case 8196:
/* 526 */         return new WildcardTypeImpl(this._env, (WildcardBinding)binding);
/*     */       
/*     */       case 4100:
/* 529 */         return new TypeVariableImpl(this._env, (TypeVariableBinding)binding);
/*     */       case 64:
/* 531 */         return getNoType(TypeKind.MODULE);
/*     */     } 
/* 533 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TypeParameterElement newTypeParameterElement(TypeVariableBinding variable, Element declaringElement) {
/* 541 */     return new TypeParameterElementImpl(this._env, variable, declaringElement);
/*     */   }
/*     */   
/*     */   public ErrorType getErrorType(ReferenceBinding binding) {
/* 545 */     return new ErrorTypeImpl(this._env, binding);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Object performNecessaryPrimitiveTypeConversion(Class<?> expectedType, Object value, boolean avoidReflectException) {
/* 594 */     assert expectedType.isPrimitive() : "expectedType is not a primitive type: " + expectedType.getName();
/* 595 */     if (value == null) {
/* 596 */       return avoidReflectException ? getMatchingDummyValue(expectedType) : null;
/*     */     }
/* 598 */     String typeName = expectedType.getName();
/* 599 */     char expectedTypeChar = typeName.charAt(0);
/* 600 */     int nameLen = typeName.length();
/*     */ 
/*     */     
/* 603 */     if (value instanceof Byte) {
/*     */       
/* 605 */       byte b = ((Byte)value).byteValue();
/* 606 */       switch (expectedTypeChar) {
/*     */         
/*     */         case 'b':
/* 609 */           if (nameLen == 4) {
/* 610 */             return value;
/*     */           }
/* 612 */           return avoidReflectException ? Boolean.FALSE : value;
/*     */         case 'c':
/* 614 */           return Character.valueOf((char)b);
/*     */         case 'd':
/* 616 */           return Double.valueOf(b);
/*     */         case 'f':
/* 618 */           return Float.valueOf(b);
/*     */         case 'i':
/* 620 */           return Integer.valueOf(b);
/*     */         case 'l':
/* 622 */           return Long.valueOf(b);
/*     */         case 's':
/* 624 */           return Short.valueOf(b);
/*     */       } 
/* 626 */       throw new IllegalStateException("unknown type " + expectedTypeChar);
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 631 */     if (value instanceof Short) {
/*     */       
/* 633 */       short s = ((Short)value).shortValue();
/* 634 */       switch (expectedTypeChar) {
/*     */         
/*     */         case 'b':
/* 637 */           if (nameLen == 4) {
/* 638 */             return Byte.valueOf((byte)s);
/*     */           }
/* 640 */           return avoidReflectException ? Boolean.FALSE : value;
/*     */         case 'c':
/* 642 */           return Character.valueOf((char)s);
/*     */         case 'd':
/* 644 */           return Double.valueOf(s);
/*     */         case 'f':
/* 646 */           return Float.valueOf(s);
/*     */         case 'i':
/* 648 */           return Integer.valueOf(s);
/*     */         case 'l':
/* 650 */           return Long.valueOf(s);
/*     */         case 's':
/* 652 */           return value;
/*     */       } 
/* 654 */       throw new IllegalStateException("unknown type " + expectedTypeChar);
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 659 */     if (value instanceof Character) {
/*     */       
/* 661 */       char c = ((Character)value).charValue();
/* 662 */       switch (expectedTypeChar) {
/*     */         
/*     */         case 'b':
/* 665 */           if (nameLen == 4) {
/* 666 */             return Byte.valueOf((byte)c);
/*     */           }
/* 668 */           return avoidReflectException ? Boolean.FALSE : value;
/*     */         case 'c':
/* 670 */           return value;
/*     */         case 'd':
/* 672 */           return Double.valueOf(c);
/*     */         case 'f':
/* 674 */           return Float.valueOf(c);
/*     */         case 'i':
/* 676 */           return Integer.valueOf(c);
/*     */         case 'l':
/* 678 */           return Long.valueOf(c);
/*     */         case 's':
/* 680 */           return Short.valueOf((short)c);
/*     */       } 
/* 682 */       throw new IllegalStateException("unknown type " + expectedTypeChar);
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 688 */     if (value instanceof Integer) {
/*     */       
/* 690 */       int i = ((Integer)value).intValue();
/* 691 */       switch (expectedTypeChar) {
/*     */         
/*     */         case 'b':
/* 694 */           if (nameLen == 4) {
/* 695 */             return Byte.valueOf((byte)i);
/*     */           }
/* 697 */           return avoidReflectException ? Boolean.FALSE : value;
/*     */         case 'c':
/* 699 */           return Character.valueOf((char)i);
/*     */         case 'd':
/* 701 */           return Double.valueOf(i);
/*     */         case 'f':
/* 703 */           return Float.valueOf(i);
/*     */         case 'i':
/* 705 */           return value;
/*     */         case 'l':
/* 707 */           return Long.valueOf(i);
/*     */         case 's':
/* 709 */           return Short.valueOf((short)i);
/*     */       } 
/* 711 */       throw new IllegalStateException("unknown type " + expectedTypeChar);
/*     */     } 
/*     */ 
/*     */     
/* 715 */     if (value instanceof Long) {
/*     */       
/* 717 */       long l = ((Long)value).longValue();
/* 718 */       switch (expectedTypeChar) {
/*     */ 
/*     */         
/*     */         case 'b':
/*     */         case 'c':
/*     */         case 'i':
/*     */         case 's':
/* 725 */           return avoidReflectException ? getMatchingDummyValue(expectedType) : value;
/*     */         case 'd':
/* 727 */           return Double.valueOf(l);
/*     */         case 'f':
/* 729 */           return Float.valueOf((float)l);
/*     */         case 'l':
/* 731 */           return value;
/*     */       } 
/*     */       
/* 734 */       throw new IllegalStateException("unknown type " + expectedTypeChar);
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 739 */     if (value instanceof Float) {
/*     */       
/* 741 */       float f = ((Float)value).floatValue();
/* 742 */       switch (expectedTypeChar) {
/*     */ 
/*     */         
/*     */         case 'b':
/*     */         case 'c':
/*     */         case 'i':
/*     */         case 'l':
/*     */         case 's':
/* 750 */           return avoidReflectException ? getMatchingDummyValue(expectedType) : value;
/*     */         case 'd':
/* 752 */           return Double.valueOf(f);
/*     */         case 'f':
/* 754 */           return value;
/*     */       } 
/* 756 */       throw new IllegalStateException("unknown type " + expectedTypeChar);
/*     */     } 
/*     */     
/* 759 */     if (value instanceof Double) {
/* 760 */       if (expectedTypeChar == 'd') {
/* 761 */         return value;
/*     */       }
/* 763 */       return avoidReflectException ? getMatchingDummyValue(expectedType) : value;
/*     */     } 
/*     */     
/* 766 */     if (value instanceof Boolean) {
/* 767 */       if (expectedTypeChar == 'b' && nameLen == 7) {
/* 768 */         return value;
/*     */       }
/* 770 */       return avoidReflectException ? getMatchingDummyValue(expectedType) : value;
/*     */     } 
/*     */     
/* 773 */     return avoidReflectException ? getMatchingDummyValue(expectedType) : value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void setArrayMatchingDummyValue(Object array, int i, Class<?> expectedLeafType) {
/* 784 */     if (boolean.class.equals(expectedLeafType)) {
/* 785 */       Array.setBoolean(array, i, false);
/*     */     }
/* 787 */     else if (byte.class.equals(expectedLeafType)) {
/* 788 */       Array.setByte(array, i, DUMMY_BYTE.byteValue());
/*     */     }
/* 790 */     else if (char.class.equals(expectedLeafType)) {
/* 791 */       Array.setChar(array, i, DUMMY_CHAR.charValue());
/*     */     }
/* 793 */     else if (double.class.equals(expectedLeafType)) {
/* 794 */       Array.setDouble(array, i, DUMMY_DOUBLE.doubleValue());
/*     */     }
/* 796 */     else if (float.class.equals(expectedLeafType)) {
/* 797 */       Array.setFloat(array, i, DUMMY_FLOAT.floatValue());
/*     */     }
/* 799 */     else if (int.class.equals(expectedLeafType)) {
/* 800 */       Array.setInt(array, i, DUMMY_INTEGER.intValue());
/*     */     }
/* 802 */     else if (long.class.equals(expectedLeafType)) {
/* 803 */       Array.setLong(array, i, DUMMY_LONG.longValue());
/*     */     }
/* 805 */     else if (short.class.equals(expectedLeafType)) {
/* 806 */       Array.setShort(array, i, DUMMY_SHORT.shortValue());
/*     */     } else {
/*     */       
/* 809 */       Array.set(array, i, null);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static AnnotationBinding[] getPackedAnnotationBindings(AnnotationBinding[] annotations) {
/* 819 */     int length = (annotations == null) ? 0 : annotations.length;
/* 820 */     if (length == 0) {
/* 821 */       return annotations;
/*     */     }
/* 823 */     AnnotationBinding[] repackagedBindings = annotations;
/* 824 */     for (int i = 0; i < length; i++) {
/* 825 */       AnnotationBinding annotation = repackagedBindings[i];
/* 826 */       if (annotation != null) {
/* 827 */         ReferenceBinding annotationType = annotation.getAnnotationType();
/* 828 */         if (annotationType.isRepeatableAnnotationType()) {
/*     */           
/* 830 */           ReferenceBinding containerType = annotationType.containerAnnotationType();
/* 831 */           if (containerType != null) {
/*     */             
/* 833 */             MethodBinding[] values = containerType.getMethods(TypeConstants.VALUE);
/* 834 */             if (values != null && values.length == 1)
/*     */             
/* 836 */             { MethodBinding value = values[0];
/* 837 */               if (value.returnType != null && value.returnType.dimensions() == 1 && !TypeBinding.notEquals(value.returnType.leafComponentType(), (TypeBinding)annotationType))
/*     */               
/*     */               { 
/*     */                 
/* 841 */                 List<AnnotationBinding> containees = null;
/* 842 */                 for (int m = i + 1; m < length; m++) {
/* 843 */                   AnnotationBinding otherAnnotation = repackagedBindings[m];
/* 844 */                   if (otherAnnotation != null && 
/* 845 */                     otherAnnotation.getAnnotationType() == annotationType) {
/* 846 */                     if (repackagedBindings == annotations)
/* 847 */                       System.arraycopy(repackagedBindings, 0, repackagedBindings = new AnnotationBinding[length], 0, length); 
/* 848 */                     repackagedBindings[m] = null;
/* 849 */                     if (containees == null) {
/* 850 */                       containees = new ArrayList<>();
/* 851 */                       containees.add(annotation);
/*     */                     } 
/* 853 */                     containees.add(otherAnnotation);
/*     */                   } 
/*     */                 } 
/* 856 */                 if (containees != null)
/* 857 */                 { ElementValuePair[] elementValuePairs = { new ElementValuePair(TypeConstants.VALUE, containees.toArray(), value) };
/* 858 */                   repackagedBindings[i] = new AnnotationBinding(containerType, elementValuePairs); }  }  } 
/*     */           } 
/*     */         } 
/*     */       } 
/* 862 */     }  int finalTally = 0; int k;
/* 863 */     for (k = 0; k < length; k++) {
/* 864 */       if (repackagedBindings[k] != null) {
/* 865 */         finalTally++;
/*     */       }
/*     */     } 
/* 868 */     if (repackagedBindings == annotations && finalTally == length) {
/* 869 */       return annotations;
/*     */     }
/*     */     
/* 872 */     annotations = new AnnotationBinding[finalTally]; int j;
/* 873 */     for (k = 0, j = 0; k < length; k++) {
/* 874 */       if (repackagedBindings[k] != null)
/* 875 */         annotations[j++] = repackagedBindings[k]; 
/*     */     } 
/* 877 */     return annotations;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static AnnotationBinding[] getUnpackedAnnotationBindings(AnnotationBinding[] annotations) {
/* 884 */     int length = (annotations == null) ? 0 : annotations.length;
/* 885 */     if (length == 0) {
/* 886 */       return annotations;
/*     */     }
/* 888 */     List<AnnotationBinding> unpackedAnnotations = new ArrayList<>();
/* 889 */     for (int i = 0; i < length; i++) {
/* 890 */       AnnotationBinding annotation = annotations[i];
/* 891 */       if (annotation != null) {
/* 892 */         unpackedAnnotations.add(annotation);
/* 893 */         ReferenceBinding annotationType = annotation.getAnnotationType();
/*     */         
/* 895 */         MethodBinding[] values = annotationType.getMethods(TypeConstants.VALUE);
/* 896 */         if (values != null && values.length == 1) {
/*     */           
/* 898 */           MethodBinding value = values[0];
/*     */           
/* 900 */           if (value.returnType.dimensions() == 1) {
/*     */ 
/*     */             
/* 903 */             TypeBinding containeeType = value.returnType.leafComponentType();
/* 904 */             if (containeeType != null && containeeType.isAnnotationType() && containeeType.isRepeatableAnnotationType())
/*     */             {
/*     */               
/* 907 */               if (containeeType.containerAnnotationType() == annotationType) {
/*     */ 
/*     */ 
/*     */                 
/* 911 */                 ElementValuePair[] elementValuePairs = annotation.getElementValuePairs(); byte b; int j; ElementValuePair[] arrayOfElementValuePair1;
/* 912 */                 for (j = (arrayOfElementValuePair1 = elementValuePairs).length, b = 0; b < j; ) { ElementValuePair elementValuePair = arrayOfElementValuePair1[b];
/* 913 */                   if (CharOperation.equals(elementValuePair.getName(), TypeConstants.VALUE))
/* 914 */                   { Object[] containees = (Object[])elementValuePair.getValue(); byte b1; int k; Object[] arrayOfObject1;
/* 915 */                     for (k = (arrayOfObject1 = containees).length, b1 = 0; b1 < k; ) { Object object = arrayOfObject1[b1];
/* 916 */                       unpackedAnnotations.add((AnnotationBinding)object); b1++; }  break; }  b++; }
/*     */               
/*     */               }  } 
/*     */           } 
/*     */         } 
/*     */       } 
/* 922 */     }  return unpackedAnnotations.<AnnotationBinding>toArray(new AnnotationBinding[unpackedAnnotations.size()]);
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\apt\model\Factory.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */