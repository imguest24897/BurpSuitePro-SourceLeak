/*    */ package org.eclipse.jdt.internal.compiler.ast;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Receiver
/*    */   extends Argument
/*    */ {
/*    */   public NameReference qualifyingName;
/*    */   
/*    */   public Receiver(char[] name, long posNom, TypeReference typeReference, NameReference qualifyingName, int modifiers) {
/* 20 */     super(name, posNom, typeReference, modifiers);
/* 21 */     this.qualifyingName = qualifyingName;
/*    */   }
/*    */   
/*    */   public boolean isReceiver() {
/* 25 */     return true;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public StringBuffer print(int indent, StringBuffer output) {
/* 31 */     printIndent(indent, output);
/* 32 */     printModifiers(this.modifiers, output);
/*    */     
/* 34 */     if (this.type == null) {
/* 35 */       output.append("<no type> ");
/*    */     } else {
/* 37 */       this.type.print(0, output).append(' ');
/*    */     } 
/* 39 */     if (this.qualifyingName != null) {
/* 40 */       this.qualifyingName.print(indent, output);
/* 41 */       output.append('.');
/*    */     } 
/* 43 */     return output.append(this.name);
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\ast\Receiver.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */