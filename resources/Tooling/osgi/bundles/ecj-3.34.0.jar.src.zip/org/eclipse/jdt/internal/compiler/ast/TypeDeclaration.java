/*      */ package org.eclipse.jdt.internal.compiler.ast;
/*      */ 
/*      */ import java.util.ArrayList;
/*      */ import java.util.Arrays;
/*      */ import java.util.HashSet;
/*      */ import java.util.List;
/*      */ import java.util.Set;
/*      */ import java.util.stream.Collectors;
/*      */ import org.eclipse.jdt.core.compiler.CategorizedProblem;
/*      */ import org.eclipse.jdt.core.compiler.CharOperation;
/*      */ import org.eclipse.jdt.internal.compiler.ASTVisitor;
/*      */ import org.eclipse.jdt.internal.compiler.ClassFile;
/*      */ import org.eclipse.jdt.internal.compiler.CompilationResult;
/*      */ import org.eclipse.jdt.internal.compiler.codegen.CodeStream;
/*      */ import org.eclipse.jdt.internal.compiler.flow.FlowContext;
/*      */ import org.eclipse.jdt.internal.compiler.flow.FlowInfo;
/*      */ import org.eclipse.jdt.internal.compiler.flow.InitializationFlowContext;
/*      */ import org.eclipse.jdt.internal.compiler.flow.UnconditionalFlowInfo;
/*      */ import org.eclipse.jdt.internal.compiler.impl.ReferenceContext;
/*      */ import org.eclipse.jdt.internal.compiler.impl.StringConstant;
/*      */ import org.eclipse.jdt.internal.compiler.lookup.Binding;
/*      */ import org.eclipse.jdt.internal.compiler.lookup.BlockScope;
/*      */ import org.eclipse.jdt.internal.compiler.lookup.ClassScope;
/*      */ import org.eclipse.jdt.internal.compiler.lookup.CompilationUnitScope;
/*      */ import org.eclipse.jdt.internal.compiler.lookup.FieldBinding;
/*      */ import org.eclipse.jdt.internal.compiler.lookup.LocalTypeBinding;
/*      */ import org.eclipse.jdt.internal.compiler.lookup.LocalVariableBinding;
/*      */ import org.eclipse.jdt.internal.compiler.lookup.MemberTypeBinding;
/*      */ import org.eclipse.jdt.internal.compiler.lookup.MethodBinding;
/*      */ import org.eclipse.jdt.internal.compiler.lookup.MethodScope;
/*      */ import org.eclipse.jdt.internal.compiler.lookup.NestedTypeBinding;
/*      */ import org.eclipse.jdt.internal.compiler.lookup.RecordComponentBinding;
/*      */ import org.eclipse.jdt.internal.compiler.lookup.ReferenceBinding;
/*      */ import org.eclipse.jdt.internal.compiler.lookup.Scope;
/*      */ import org.eclipse.jdt.internal.compiler.lookup.SourceTypeBinding;
/*      */ import org.eclipse.jdt.internal.compiler.lookup.SyntheticArgumentBinding;
/*      */ import org.eclipse.jdt.internal.compiler.lookup.TypeBinding;
/*      */ import org.eclipse.jdt.internal.compiler.lookup.TypeConstants;
/*      */ import org.eclipse.jdt.internal.compiler.lookup.TypeVariableBinding;
/*      */ import org.eclipse.jdt.internal.compiler.parser.Parser;
/*      */ import org.eclipse.jdt.internal.compiler.problem.AbortCompilation;
/*      */ import org.eclipse.jdt.internal.compiler.problem.AbortCompilationUnit;
/*      */ import org.eclipse.jdt.internal.compiler.problem.AbortMethod;
/*      */ import org.eclipse.jdt.internal.compiler.problem.AbortType;
/*      */ import org.eclipse.jdt.internal.compiler.problem.ProblemReporter;
/*      */ import org.eclipse.jdt.internal.compiler.problem.ProblemSeverities;
/*      */ import org.eclipse.jdt.internal.compiler.util.SimpleSetOfCharArray;
/*      */ import org.eclipse.jdt.internal.compiler.util.Util;
/*      */ 
/*      */ public class TypeDeclaration
/*      */   extends Statement implements ProblemSeverities, ReferenceContext {
/*      */   public static final int CLASS_DECL = 1;
/*      */   public static final int INTERFACE_DECL = 2;
/*      */   public static final int ENUM_DECL = 3;
/*      */   public static final int ANNOTATION_TYPE_DECL = 4;
/*      */   public static final int RECORD_DECL = 5;
/*   57 */   public int modifiers = 0;
/*      */   public int modifiersSourceStart;
/*   59 */   public int functionalExpressionsCount = 0;
/*      */   public Annotation[] annotations;
/*      */   public char[] name;
/*      */   public TypeReference superclass;
/*      */   public TypeReference[] superInterfaces;
/*      */   public FieldDeclaration[] fields;
/*      */   public AbstractMethodDeclaration[] methods;
/*      */   public TypeDeclaration[] memberTypes;
/*      */   public SourceTypeBinding binding;
/*      */   public ClassScope scope;
/*      */   public MethodScope initializerScope;
/*      */   public MethodScope staticInitializerScope;
/*      */   public boolean ignoreFurtherInvestigation = false;
/*      */   public int maxFieldCount;
/*      */   public int declarationSourceStart;
/*      */   public int declarationSourceEnd;
/*   75 */   public int restrictedIdentifierStart = -1;
/*      */   
/*      */   public int bodyStart;
/*      */   
/*      */   public int bodyEnd;
/*      */   
/*      */   public CompilationResult compilationResult;
/*      */   
/*      */   public MethodDeclaration[] missingAbstractMethods;
/*      */   
/*      */   public Javadoc javadoc;
/*      */   
/*      */   public QualifiedAllocationExpression allocation;
/*      */   
/*      */   public TypeDeclaration enclosingType;
/*      */   
/*      */   public FieldBinding enumValuesSyntheticfield;
/*      */   
/*      */   public int enumConstantsCounter;
/*      */   
/*      */   public TypeParameter[] typeParameters;
/*      */   
/*      */   public RecordComponent[] recordComponents;
/*      */   
/*      */   public int nRecordComponents;
/*  100 */   public static Set<String> disallowedComponentNames = new HashSet<>(6); static {
/*  101 */     disallowedComponentNames.add("clone");
/*  102 */     disallowedComponentNames.add("finalize");
/*  103 */     disallowedComponentNames.add("getClass");
/*  104 */     disallowedComponentNames.add("hashCode");
/*  105 */     disallowedComponentNames.add("notify");
/*  106 */     disallowedComponentNames.add("notifyAll");
/*  107 */     disallowedComponentNames.add("toString");
/*  108 */     disallowedComponentNames.add("wait");
/*      */   }
/*      */   public TypeReference[] permittedTypes;
/*      */   public TypeDeclaration(CompilationResult compilationResult) {
/*  112 */     this.compilationResult = compilationResult;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void abort(int abortLevel, CategorizedProblem problem) {
/*  120 */     switch (abortLevel) {
/*      */       case 2:
/*  122 */         throw new AbortCompilation(this.compilationResult, problem);
/*      */       case 4:
/*  124 */         throw new AbortCompilationUnit(this.compilationResult, problem);
/*      */       case 16:
/*  126 */         throw new AbortMethod(this.compilationResult, problem);
/*      */     } 
/*  128 */     throw new AbortType(this.compilationResult, problem);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void addClinit() {
/*  144 */     if (needClassInitMethod()) {
/*      */       AbstractMethodDeclaration[] methodDeclarations;
/*      */       
/*  147 */       if ((methodDeclarations = this.methods) == null) {
/*  148 */         int length = 0;
/*  149 */         methodDeclarations = new AbstractMethodDeclaration[1];
/*      */       } else {
/*  151 */         int length = methodDeclarations.length;
/*  152 */         System.arraycopy(
/*  153 */             methodDeclarations, 
/*  154 */             0, 
/*  155 */             methodDeclarations = new AbstractMethodDeclaration[length + 1], 
/*  156 */             1, 
/*  157 */             length);
/*      */       } 
/*  159 */       Clinit clinit = new Clinit(this.compilationResult);
/*  160 */       methodDeclarations[0] = clinit;
/*      */       
/*  162 */       clinit.declarationSourceStart = clinit.sourceStart = this.sourceStart;
/*  163 */       clinit.declarationSourceEnd = clinit.sourceEnd = this.sourceEnd;
/*  164 */       clinit.bodyEnd = this.sourceEnd;
/*  165 */       this.methods = methodDeclarations;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MethodDeclaration addMissingAbstractMethodFor(MethodBinding methodBinding) {
/*  174 */     TypeBinding[] argumentTypes = methodBinding.parameters;
/*  175 */     int argumentsLength = argumentTypes.length;
/*      */     
/*  177 */     MethodDeclaration methodDeclaration = new MethodDeclaration(this.compilationResult);
/*  178 */     methodDeclaration.selector = methodBinding.selector;
/*  179 */     methodDeclaration.sourceStart = this.sourceStart;
/*  180 */     methodDeclaration.sourceEnd = this.sourceEnd;
/*  181 */     methodDeclaration.modifiers = methodBinding.getAccessFlags() & 0xFFFFFBFF;
/*      */     
/*  183 */     if (argumentsLength > 0) {
/*  184 */       String baseName = "arg";
/*  185 */       Argument[] arguments = methodDeclaration.arguments = new Argument[argumentsLength];
/*  186 */       for (int i = argumentsLength; --i >= 0;) {
/*  187 */         arguments[i] = new Argument((String.valueOf(baseName) + i).toCharArray(), 0L, null, 0);
/*      */       }
/*      */     } 
/*      */ 
/*      */     
/*  192 */     if (this.missingAbstractMethods == null) {
/*  193 */       this.missingAbstractMethods = new MethodDeclaration[] { methodDeclaration };
/*      */     } else {
/*      */       MethodDeclaration[] newMethods;
/*  196 */       System.arraycopy(
/*  197 */           this.missingAbstractMethods, 
/*  198 */           0, 
/*  199 */           newMethods = new MethodDeclaration[this.missingAbstractMethods.length + 1], 
/*  200 */           1, 
/*  201 */           this.missingAbstractMethods.length);
/*  202 */       newMethods[0] = methodDeclaration;
/*  203 */       this.missingAbstractMethods = newMethods;
/*      */     } 
/*      */ 
/*      */     
/*  207 */     methodDeclaration.binding = new MethodBinding(
/*  208 */         methodDeclaration.modifiers | 0x1000, 
/*  209 */         methodBinding.selector, 
/*  210 */         methodBinding.returnType, 
/*  211 */         (argumentsLength == 0) ? Binding.NO_PARAMETERS : argumentTypes, 
/*  212 */         methodBinding.thrownExceptions, 
/*  213 */         (ReferenceBinding)this.binding);
/*      */     
/*  215 */     methodDeclaration.scope = new MethodScope((Scope)this.scope, methodDeclaration, true);
/*  216 */     methodDeclaration.bindArguments();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  233 */     return methodDeclaration;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public FlowInfo analyseCode(BlockScope currentScope, FlowContext flowContext, FlowInfo flowInfo) {
/*  242 */     if (this.ignoreFurtherInvestigation)
/*  243 */       return flowInfo; 
/*      */     try {
/*  245 */       if ((flowInfo.tagBits & 0x1) == 0) {
/*  246 */         this.bits |= Integer.MIN_VALUE;
/*  247 */         LocalTypeBinding localType = (LocalTypeBinding)this.binding;
/*  248 */         localType.setConstantPoolName(currentScope.compilationUnitScope().computeConstantPoolName(localType));
/*      */       } 
/*  250 */       manageEnclosingInstanceAccessIfNecessary(currentScope, flowInfo);
/*  251 */       updateMaxFieldCount();
/*  252 */       internalAnalyseCode(flowContext, flowInfo);
/*  253 */     } catch (AbortType abortType) {
/*  254 */       this.ignoreFurtherInvestigation = true;
/*      */     } 
/*  256 */     return flowInfo;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void analyseCode(ClassScope enclosingClassScope) {
/*  264 */     if (this.ignoreFurtherInvestigation) {
/*      */       return;
/*      */     }
/*      */     try {
/*  268 */       updateMaxFieldCount();
/*  269 */       internalAnalyseCode((FlowContext)null, (FlowInfo)FlowInfo.initial(this.maxFieldCount));
/*  270 */     } catch (AbortType abortType) {
/*  271 */       this.ignoreFurtherInvestigation = true;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void analyseCode(ClassScope currentScope, FlowContext flowContext, FlowInfo flowInfo) {
/*  280 */     if (this.ignoreFurtherInvestigation)
/*      */       return; 
/*      */     try {
/*  283 */       if ((flowInfo.tagBits & 0x1) == 0) {
/*  284 */         this.bits |= Integer.MIN_VALUE;
/*  285 */         LocalTypeBinding localType = (LocalTypeBinding)this.binding;
/*  286 */         localType.setConstantPoolName(currentScope.compilationUnitScope().computeConstantPoolName(localType));
/*      */       } 
/*  288 */       manageEnclosingInstanceAccessIfNecessary(currentScope, flowInfo);
/*  289 */       updateMaxFieldCount();
/*  290 */       internalAnalyseCode(flowContext, flowInfo);
/*  291 */     } catch (AbortType abortType) {
/*  292 */       this.ignoreFurtherInvestigation = true;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void analyseCode(CompilationUnitScope unitScope) {
/*  301 */     if (this.ignoreFurtherInvestigation)
/*      */       return; 
/*      */     try {
/*  304 */       internalAnalyseCode((FlowContext)null, (FlowInfo)FlowInfo.initial(this.maxFieldCount));
/*  305 */     } catch (AbortType abortType) {
/*  306 */       this.ignoreFurtherInvestigation = true;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean checkConstructors(Parser parser) {
/*  317 */     boolean hasConstructor = false;
/*  318 */     if (this.methods != null) {
/*  319 */       for (int i = this.methods.length; --i >= 0;) {
/*      */         
/*  321 */         if ((am = this.methods[i]).isConstructor()) {
/*  322 */           if (!CharOperation.equals(am.selector, this.name)) {
/*      */ 
/*      */             
/*  325 */             ConstructorDeclaration c = (ConstructorDeclaration)am;
/*  326 */             if (c.constructorCall == null || c.constructorCall.isImplicitSuper()) {
/*  327 */               MethodDeclaration m = parser.convertToMethodDeclaration(c, this.compilationResult);
/*  328 */               this.methods[i] = m;
/*      */             }  continue;
/*      */           } 
/*  331 */           switch (kind(this.modifiers)) {
/*      */             
/*      */             case 2:
/*  334 */               parser.problemReporter().interfaceCannotHaveConstructors((ConstructorDeclaration)am);
/*      */               break;
/*      */             
/*      */             case 4:
/*  338 */               parser.problemReporter().annotationTypeDeclarationCannotHaveConstructor((ConstructorDeclaration)am);
/*      */               break;
/*      */           } 
/*      */           
/*  342 */           hasConstructor = true;
/*      */         } 
/*      */       } 
/*      */     }
/*      */     
/*  347 */     return hasConstructor;
/*      */   }
/*      */ 
/*      */   
/*      */   public CompilationResult compilationResult() {
/*  352 */     return this.compilationResult;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ConstructorDeclaration createDefaultConstructorForRecord(boolean needExplicitConstructorCall, boolean needToInsert) {
/*  362 */     ConstructorDeclaration constructor = new ConstructorDeclaration(this.compilationResult);
/*  363 */     constructor.bits |= 0x600;
/*  364 */     constructor.selector = this.name;
/*  365 */     constructor.modifiers = this.modifiers & 0x7;
/*      */ 
/*      */     
/*  368 */     constructor.arguments = getArgumentsFromComponents(this.recordComponents);
/*      */     
/*  370 */     for (int i = 0, max = constructor.arguments.length; i < max; i++) {
/*  371 */       if (((constructor.arguments[i]).bits & 0x100000) != 0) {
/*  372 */         constructor.bits |= 0x100000;
/*      */         break;
/*      */       } 
/*      */     } 
/*  376 */     constructor.declarationSourceStart = constructor.sourceStart = 
/*  377 */       constructor.bodyStart = this.sourceStart;
/*  378 */     constructor.declarationSourceEnd = 
/*  379 */       constructor.sourceEnd = constructor.bodyEnd = this.sourceStart - 1;
/*      */ 
/*      */     
/*  382 */     if (needExplicitConstructorCall) {
/*  383 */       constructor.constructorCall = SuperReference.implicitSuperConstructorCall();
/*  384 */       constructor.constructorCall.sourceStart = this.sourceStart;
/*  385 */       constructor.constructorCall.sourceEnd = this.sourceEnd;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  390 */     List<Statement> statements = new ArrayList<>();
/*  391 */     int l = (this.recordComponents != null) ? this.recordComponents.length : 0;
/*  392 */     if (l > 0 && this.fields != null) {
/*  393 */       List<String> fNames = (List<String>)Arrays.<FieldDeclaration>stream(this.fields)
/*  394 */         .filter(f -> f.isARecordComponent)
/*  395 */         .map(f -> new String(f.name))
/*  396 */         .collect(Collectors.toList());
/*  397 */       for (int j = 0; j < l; j++) {
/*  398 */         RecordComponent component = this.recordComponents[j];
/*  399 */         if (fNames.contains(new String(component.name))) {
/*      */           
/*  401 */           FieldReference lhs = new FieldReference(component.name, 0L);
/*  402 */           lhs.receiver = ThisReference.implicitThis();
/*  403 */           statements.add(new Assignment(lhs, new SingleNameReference(component.name, 0L), 0));
/*      */         } 
/*      */       } 
/*  406 */     }  constructor.statements = statements.<Statement>toArray(new Statement[0]);
/*      */ 
/*      */     
/*  409 */     if (needToInsert) {
/*  410 */       if (this.methods == null) {
/*  411 */         this.methods = new AbstractMethodDeclaration[] { constructor };
/*      */       } else {
/*      */         AbstractMethodDeclaration[] newMethods;
/*  414 */         System.arraycopy(
/*  415 */             this.methods, 
/*  416 */             0, 
/*  417 */             newMethods = new AbstractMethodDeclaration[this.methods.length + 1], 
/*  418 */             1, 
/*  419 */             this.methods.length);
/*  420 */         newMethods[0] = constructor;
/*  421 */         this.methods = newMethods;
/*      */       } 
/*      */     }
/*  424 */     return constructor;
/*      */   }
/*      */ 
/*      */   
/*      */   private Argument[] getArgumentsFromComponents(RecordComponent[] comps) {
/*  429 */     Argument[] args2 = (comps == null || comps.length == 0) ? ASTNode.NO_ARGUMENTS : 
/*  430 */       new Argument[comps.length];
/*  431 */     int count = 0; byte b; int i; RecordComponent[] arrayOfRecordComponent;
/*  432 */     for (i = (arrayOfRecordComponent = comps).length, b = 0; b < i; ) { RecordComponent comp = arrayOfRecordComponent[b];
/*  433 */       Argument argument = new Argument(comp.name, comp.sourceStart << 32L | comp.sourceEnd, 
/*  434 */           comp.type, 0);
/*  435 */       args2[count++] = argument; b++; }
/*      */     
/*  437 */     return args2;
/*      */   }
/*      */   
/*      */   public ConstructorDeclaration createDefaultConstructor(boolean needExplicitConstructorCall, boolean needToInsert) {
/*  441 */     if (isRecord()) {
/*  442 */       return createDefaultConstructorForRecord(needExplicitConstructorCall, needToInsert);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  449 */     ConstructorDeclaration constructor = new ConstructorDeclaration(this.compilationResult);
/*  450 */     constructor.bits |= 0x80;
/*  451 */     constructor.selector = this.name;
/*  452 */     constructor.modifiers = this.modifiers & 0x7;
/*      */ 
/*      */ 
/*      */     
/*  456 */     constructor.declarationSourceStart = constructor.sourceStart = this.sourceStart;
/*  457 */     constructor.declarationSourceEnd = 
/*  458 */       constructor.sourceEnd = constructor.bodyEnd = this.sourceEnd;
/*      */ 
/*      */     
/*  461 */     if (needExplicitConstructorCall) {
/*  462 */       constructor.constructorCall = SuperReference.implicitSuperConstructorCall();
/*  463 */       constructor.constructorCall.sourceStart = this.sourceStart;
/*  464 */       constructor.constructorCall.sourceEnd = this.sourceEnd;
/*      */     } 
/*      */ 
/*      */     
/*  468 */     if (needToInsert) {
/*  469 */       if (this.methods == null) {
/*  470 */         this.methods = new AbstractMethodDeclaration[] { constructor };
/*      */       } else {
/*      */         AbstractMethodDeclaration[] newMethods;
/*  473 */         System.arraycopy(
/*  474 */             this.methods, 
/*  475 */             0, 
/*  476 */             newMethods = new AbstractMethodDeclaration[this.methods.length + 1], 
/*  477 */             1, 
/*  478 */             this.methods.length);
/*  479 */         newMethods[0] = constructor;
/*  480 */         this.methods = newMethods;
/*      */       } 
/*      */     }
/*  483 */     return constructor;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MethodBinding createDefaultConstructorWithBinding(MethodBinding inheritedConstructorBinding, boolean eraseThrownExceptions) {
/*  490 */     String baseName = "$anonymous";
/*  491 */     TypeBinding[] argumentTypes = inheritedConstructorBinding.parameters;
/*  492 */     int argumentsLength = argumentTypes.length;
/*      */     
/*  494 */     ConstructorDeclaration constructor = new ConstructorDeclaration(this.compilationResult);
/*  495 */     constructor.selector = new char[] { 'x' };
/*  496 */     constructor.sourceStart = this.sourceStart;
/*  497 */     constructor.sourceEnd = this.sourceEnd;
/*  498 */     int newModifiers = this.modifiers & 0x7;
/*  499 */     if (inheritedConstructorBinding.isVarargs()) {
/*  500 */       newModifiers |= 0x80;
/*      */     }
/*  502 */     constructor.modifiers = newModifiers;
/*  503 */     constructor.bits |= 0x80;
/*      */     
/*  505 */     if (argumentsLength > 0) {
/*  506 */       Argument[] arguments = constructor.arguments = new Argument[argumentsLength];
/*  507 */       for (int i = argumentsLength; --i >= 0;) {
/*  508 */         arguments[i] = new Argument((String.valueOf(baseName) + i).toCharArray(), 0L, null, 0);
/*      */       }
/*      */     } 
/*      */     
/*  512 */     constructor.constructorCall = SuperReference.implicitSuperConstructorCall();
/*  513 */     constructor.constructorCall.sourceStart = this.sourceStart;
/*  514 */     constructor.constructorCall.sourceEnd = this.sourceEnd;
/*      */     
/*  516 */     if (argumentsLength > 0) {
/*      */       
/*  518 */       Expression[] args1 = constructor.constructorCall.arguments = new Expression[argumentsLength];
/*  519 */       for (int i = argumentsLength; --i >= 0;) {
/*  520 */         args1[i] = new SingleNameReference((String.valueOf(baseName) + i).toCharArray(), 0L);
/*      */       }
/*      */     } 
/*      */ 
/*      */     
/*  525 */     if (this.methods == null) {
/*  526 */       this.methods = new AbstractMethodDeclaration[] { constructor };
/*      */     } else {
/*      */       AbstractMethodDeclaration[] newMethods;
/*  529 */       System.arraycopy(this.methods, 0, newMethods = new AbstractMethodDeclaration[this.methods.length + 1], 1, this.methods.length);
/*  530 */       newMethods[0] = constructor;
/*  531 */       this.methods = newMethods;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  536 */     ReferenceBinding[] thrownExceptions = eraseThrownExceptions ? 
/*  537 */       this.scope.environment().convertToRawTypes(inheritedConstructorBinding.thrownExceptions, true, true) : 
/*  538 */       inheritedConstructorBinding.thrownExceptions;
/*      */     
/*  540 */     SourceTypeBinding sourceType = this.binding;
/*  541 */     constructor.binding = new MethodBinding(
/*  542 */         constructor.modifiers, 
/*  543 */         (argumentsLength == 0) ? Binding.NO_PARAMETERS : argumentTypes, 
/*  544 */         thrownExceptions, 
/*  545 */         (ReferenceBinding)sourceType);
/*  546 */     constructor.binding.tagBits |= inheritedConstructorBinding.tagBits & 0x80L;
/*  547 */     constructor.binding.modifiers |= 0x4000000;
/*  548 */     if (inheritedConstructorBinding.parameterNonNullness != null && 
/*  549 */       argumentsLength > 0) {
/*      */ 
/*      */       
/*  552 */       int len = inheritedConstructorBinding.parameterNonNullness.length;
/*  553 */       System.arraycopy(inheritedConstructorBinding.parameterNonNullness, 0, 
/*  554 */           constructor.binding.parameterNonNullness = new Boolean[len], 0, len);
/*      */     } 
/*      */ 
/*      */     
/*  558 */     constructor.scope = new MethodScope((Scope)this.scope, constructor, true);
/*  559 */     constructor.bindArguments();
/*  560 */     constructor.constructorCall.resolve((BlockScope)constructor.scope);
/*      */     
/*  562 */     MethodBinding[] methodBindings = sourceType.methods();
/*      */     int length;
/*  564 */     System.arraycopy(methodBindings, 0, methodBindings = new MethodBinding[(length = methodBindings.length) + 1], 1, length);
/*  565 */     methodBindings[0] = constructor.binding;
/*  566 */     if (++length > 1)
/*  567 */       ReferenceBinding.sortMethods(methodBindings, 0, length); 
/*  568 */     sourceType.setMethods(methodBindings);
/*      */ 
/*      */     
/*  571 */     return constructor.binding;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public FieldDeclaration declarationOf(FieldBinding fieldBinding) {
/*  578 */     if (fieldBinding != null && this.fields != null)
/*  579 */       for (int i = 0, max = this.fields.length; i < max; i++) {
/*      */         FieldDeclaration fieldDecl;
/*  581 */         if ((fieldDecl = this.fields[i]).binding == fieldBinding) {
/*  582 */           return fieldDecl;
/*      */         }
/*      */       }  
/*  585 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public TypeDeclaration declarationOf(MemberTypeBinding memberTypeBinding) {
/*  592 */     if (memberTypeBinding != null && this.memberTypes != null)
/*  593 */       for (int i = 0, max = this.memberTypes.length; i < max; i++) {
/*      */         TypeDeclaration memberTypeDecl;
/*  595 */         if (TypeBinding.equalsEquals((TypeBinding)(memberTypeDecl = this.memberTypes[i]).binding, (TypeBinding)memberTypeBinding)) {
/*  596 */           return memberTypeDecl;
/*      */         }
/*      */       }  
/*  599 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public AbstractMethodDeclaration declarationOf(MethodBinding methodBinding) {
/*  606 */     if (methodBinding != null && this.methods != null)
/*  607 */       for (int i = 0, max = this.methods.length; i < max; i++) {
/*      */         AbstractMethodDeclaration methodDecl;
/*      */         
/*  610 */         if ((methodDecl = this.methods[i]).binding == methodBinding) {
/*  611 */           return methodDecl;
/*      */         }
/*      */       }  
/*  614 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public RecordComponent declarationOf(RecordComponentBinding recordComponentBinding) {
/*  621 */     if (recordComponentBinding != null && this.recordComponents != null)
/*  622 */       for (int i = 0, max = this.recordComponents.length; i < max; i++) {
/*      */         RecordComponent recordComponent;
/*  624 */         if ((recordComponent = this.recordComponents[i]).binding == recordComponentBinding) {
/*  625 */           return recordComponent;
/*      */         }
/*      */       }  
/*  628 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public TypeDeclaration declarationOfType(char[][] typeName) {
/*  639 */     int typeNameLength = typeName.length;
/*  640 */     if (typeNameLength < 1 || !CharOperation.equals(typeName[0], this.name)) {
/*  641 */       return null;
/*      */     }
/*  643 */     if (typeNameLength == 1) {
/*  644 */       return this;
/*      */     }
/*  646 */     char[][] subTypeName = new char[typeNameLength - 1][];
/*  647 */     System.arraycopy(typeName, 1, subTypeName, 0, typeNameLength - 1);
/*  648 */     for (int i = 0; i < this.memberTypes.length; i++) {
/*  649 */       TypeDeclaration typeDecl = this.memberTypes[i].declarationOfType(subTypeName);
/*  650 */       if (typeDecl != null) {
/*  651 */         return typeDecl;
/*      */       }
/*      */     } 
/*  654 */     return null;
/*      */   }
/*      */ 
/*      */   
/*      */   public CompilationUnitDeclaration getCompilationUnitDeclaration() {
/*  659 */     if (this.scope != null) {
/*  660 */       return (this.scope.compilationUnitScope()).referenceContext;
/*      */     }
/*  662 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ConstructorDeclaration getConstructor(Parser parser) {
/*  671 */     ConstructorDeclaration cd = null;
/*  672 */     if (this.methods != null) {
/*  673 */       for (int i = this.methods.length; --i >= 0;) {
/*      */         
/*  675 */         if ((am = this.methods[i]).isConstructor()) {
/*  676 */           if (!CharOperation.equals(am.selector, this.name)) {
/*      */ 
/*      */             
/*  679 */             ConstructorDeclaration c = (ConstructorDeclaration)am;
/*  680 */             if (c.constructorCall == null || c.constructorCall.isImplicitSuper()) {
/*  681 */               MethodDeclaration m = parser.convertToMethodDeclaration(c, this.compilationResult);
/*  682 */               this.methods[i] = m;
/*      */             }  continue;
/*      */           } 
/*  685 */           if (am instanceof CompactConstructorDeclaration) {
/*  686 */             CompactConstructorDeclaration ccd = (CompactConstructorDeclaration)am;
/*  687 */             ccd.recordDeclaration = this;
/*  688 */             if (ccd.arguments == null)
/*  689 */               ccd.arguments = getArgumentsFromComponents(this.recordComponents); 
/*  690 */             return ccd;
/*      */           } 
/*      */           
/*  693 */           if ((this.recordComponents == null || this.recordComponents.length == 0) && 
/*  694 */             am.arguments == null)
/*  695 */             return (ConstructorDeclaration)am; 
/*  696 */           cd = (ConstructorDeclaration)am;
/*      */         } 
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  705 */     return cd;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void generateCode(ClassFile enclosingClassFile) {
/*  712 */     if ((this.bits & 0x2000) != 0)
/*      */       return; 
/*  714 */     this.bits |= 0x2000;
/*  715 */     if (this.ignoreFurtherInvestigation) {
/*  716 */       if (this.binding == null)
/*      */         return; 
/*  718 */       ClassFile.createProblemType(
/*  719 */           this, 
/*  720 */           (this.scope.referenceCompilationUnit()).compilationResult);
/*      */       
/*      */       return;
/*      */     } 
/*      */     try {
/*  725 */       ClassFile classFile = ClassFile.getNewInstance(this.binding);
/*  726 */       classFile.initialize(this.binding, enclosingClassFile, false);
/*  727 */       if (this.binding.isMemberType()) {
/*  728 */         classFile.recordInnerClasses((TypeBinding)this.binding);
/*  729 */       } else if (this.binding.isLocalType()) {
/*  730 */         enclosingClassFile.recordInnerClasses((TypeBinding)this.binding);
/*  731 */         classFile.recordInnerClasses((TypeBinding)this.binding);
/*      */       } 
/*  733 */       SourceTypeBinding nestHost = this.binding.getNestHost();
/*  734 */       if (nestHost != null && !TypeBinding.equalsEquals((TypeBinding)nestHost, (TypeBinding)this.binding)) {
/*  735 */         ClassFile ocf = enclosingClassFile.outerMostEnclosingClassFile();
/*  736 */         if (ocf != null)
/*  737 */           ocf.recordNestMember(this.binding); 
/*      */       } 
/*  739 */       TypeVariableBinding[] typeVariables = this.binding.typeVariables(); int i, max;
/*  740 */       for (i = 0, max = typeVariables.length; i < max; i++) {
/*  741 */         TypeVariableBinding typeVariableBinding = typeVariables[i];
/*  742 */         if ((typeVariableBinding.tagBits & 0x800L) != 0L) {
/*  743 */           Util.recordNestedType(classFile, (TypeBinding)typeVariableBinding);
/*      */         }
/*      */       } 
/*      */ 
/*      */       
/*  748 */       classFile.addFieldInfos();
/*      */       
/*  750 */       if (this.memberTypes != null) {
/*  751 */         for (i = 0, max = this.memberTypes.length; i < max; i++) {
/*  752 */           TypeDeclaration memberType = this.memberTypes[i];
/*  753 */           classFile.recordInnerClasses((TypeBinding)memberType.binding);
/*  754 */           memberType.generateCode(this.scope, classFile);
/*      */         } 
/*      */       }
/*      */       
/*  758 */       classFile.setForMethodInfos();
/*  759 */       if (this.methods != null) {
/*  760 */         for (i = 0, max = this.methods.length; i < max; i++) {
/*  761 */           this.methods[i].generateCode(this.scope, classFile);
/*      */         }
/*      */       }
/*      */       
/*  765 */       classFile.addSpecialMethods(this);
/*      */       
/*  767 */       if (this.ignoreFurtherInvestigation) {
/*  768 */         throw new AbortType((this.scope.referenceCompilationUnit()).compilationResult, null);
/*      */       }
/*      */ 
/*      */       
/*  772 */       classFile.addAttributes();
/*  773 */       (this.scope.referenceCompilationUnit()).compilationResult.record(
/*  774 */           this.binding.constantPoolName(), 
/*  775 */           classFile);
/*  776 */     } catch (AbortType abortType) {
/*  777 */       if (this.binding == null)
/*      */         return; 
/*  779 */       ClassFile.createProblemType(
/*  780 */           this, 
/*  781 */           (this.scope.referenceCompilationUnit()).compilationResult);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void generateCode(BlockScope blockScope, CodeStream codeStream) {
/*  790 */     if ((this.bits & Integer.MIN_VALUE) == 0) {
/*      */       return;
/*      */     }
/*  793 */     if ((this.bits & 0x2000) != 0)
/*  794 */       return;  int pc = codeStream.position;
/*  795 */     if (this.binding != null) {
/*  796 */       SyntheticArgumentBinding[] enclosingInstances = ((NestedTypeBinding)this.binding).syntheticEnclosingInstances();
/*  797 */       for (int i = 0, slotSize = 0, count = (enclosingInstances == null) ? 0 : enclosingInstances.length; i < count; i++) {
/*  798 */         SyntheticArgumentBinding enclosingInstance = enclosingInstances[i];
/*  799 */         enclosingInstance.resolvedPosition = ++slotSize;
/*  800 */         if (slotSize > 255) {
/*  801 */           blockScope.problemReporter().noMoreAvailableSpaceForArgument((LocalVariableBinding)enclosingInstance, blockScope.referenceType());
/*      */         }
/*      */       } 
/*      */     } 
/*  805 */     generateCode(codeStream.classFile);
/*  806 */     codeStream.recordPositionsFrom(pc, this.sourceStart);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void generateCode(ClassScope classScope, ClassFile enclosingClassFile) {
/*  813 */     if ((this.bits & 0x2000) != 0)
/*  814 */       return;  if (this.binding != null) {
/*  815 */       SyntheticArgumentBinding[] enclosingInstances = ((NestedTypeBinding)this.binding).syntheticEnclosingInstances();
/*  816 */       for (int i = 0, slotSize = 0, count = (enclosingInstances == null) ? 0 : enclosingInstances.length; i < count; i++) {
/*  817 */         SyntheticArgumentBinding enclosingInstance = enclosingInstances[i];
/*  818 */         enclosingInstance.resolvedPosition = ++slotSize;
/*  819 */         if (slotSize > 255) {
/*  820 */           classScope.problemReporter().noMoreAvailableSpaceForArgument((LocalVariableBinding)enclosingInstance, classScope.referenceType());
/*      */         }
/*      */       } 
/*      */     } 
/*  824 */     generateCode(enclosingClassFile);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void generateCode(CompilationUnitScope unitScope) {
/*  831 */     generateCode((ClassFile)null);
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean hasErrors() {
/*  836 */     return this.ignoreFurtherInvestigation;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private void internalAnalyseCode(FlowContext flowContext, FlowInfo flowInfo) {
/*      */     FlowInfo flowInfo1, flowInfo2;
/*  843 */     if (CharOperation.equals(this.name, TypeConstants.YIELD)) {
/*  844 */       this.scope.problemReporter().validateRestrictedKeywords(this.name, this);
/*      */     }
/*      */     
/*  847 */     if (!this.binding.isUsed() && this.binding.isOrEnclosedByPrivateType() && 
/*  848 */       !(this.scope.referenceCompilationUnit()).compilationResult.hasSyntaxError) {
/*  849 */       this.scope.problemReporter().unusedPrivateType(this);
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*  854 */     if (this.typeParameters != null && 
/*  855 */       !(this.scope.referenceCompilationUnit()).compilationResult.hasSyntaxError) {
/*  856 */       for (int i = 0, length = this.typeParameters.length; i < length; i++) {
/*  857 */         TypeParameter typeParameter = this.typeParameters[i];
/*  858 */         if ((typeParameter.binding.modifiers & 0x8000000) == 0) {
/*  859 */           this.scope.problemReporter().unusedTypeParameter(typeParameter);
/*      */         }
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*  866 */     FlowContext parentContext = (flowContext instanceof InitializationFlowContext) ? null : flowContext;
/*  867 */     InitializationFlowContext initializerContext = new InitializationFlowContext(parentContext, this, flowInfo, flowContext, (BlockScope)this.initializerScope);
/*      */     
/*  869 */     InitializationFlowContext staticInitializerContext = new InitializationFlowContext(null, this, flowInfo, flowContext, (BlockScope)this.staticInitializerScope);
/*  870 */     UnconditionalFlowInfo unconditionalFlowInfo1 = flowInfo.unconditionalFieldLessCopy();
/*  871 */     UnconditionalFlowInfo unconditionalFlowInfo2 = flowInfo.unconditionalFieldLessCopy();
/*  872 */     if (this.fields != null) {
/*  873 */       for (int i = 0, count = this.fields.length; i < count; i++) {
/*  874 */         FieldDeclaration field = this.fields[i];
/*  875 */         if (field.isStatic()) {
/*  876 */           if ((((FlowInfo)unconditionalFlowInfo2).tagBits & 0x1) != 0) {
/*  877 */             field.bits &= Integer.MAX_VALUE;
/*      */           }
/*      */ 
/*      */ 
/*      */           
/*  882 */           staticInitializerContext.handledExceptions = Binding.ANY_EXCEPTION;
/*      */           
/*  884 */           flowInfo2 = field.analyseCode(this.staticInitializerScope, (FlowContext)staticInitializerContext, (FlowInfo)unconditionalFlowInfo2);
/*      */ 
/*      */           
/*  887 */           if (flowInfo2 == FlowInfo.DEAD_END) {
/*  888 */             this.staticInitializerScope.problemReporter().initializerMustCompleteNormally(field);
/*  889 */             flowInfo2 = FlowInfo.initial(this.maxFieldCount).setReachMode(1);
/*      */           } 
/*      */         } else {
/*  892 */           if ((((FlowInfo)unconditionalFlowInfo1).tagBits & 0x1) != 0) {
/*  893 */             field.bits &= Integer.MAX_VALUE;
/*      */           }
/*      */ 
/*      */ 
/*      */           
/*  898 */           initializerContext.handledExceptions = Binding.ANY_EXCEPTION;
/*      */           
/*  900 */           flowInfo1 = field.analyseCode(this.initializerScope, (FlowContext)initializerContext, (FlowInfo)unconditionalFlowInfo1);
/*      */ 
/*      */           
/*  903 */           if (flowInfo1 == FlowInfo.DEAD_END) {
/*  904 */             this.initializerScope.problemReporter().initializerMustCompleteNormally(field);
/*  905 */             flowInfo1 = FlowInfo.initial(this.maxFieldCount).setReachMode(1);
/*      */           } 
/*      */         } 
/*      */       } 
/*      */     }
/*  910 */     if (this.memberTypes != null) {
/*  911 */       for (int i = 0, count = this.memberTypes.length; i < count; i++) {
/*  912 */         if (flowContext != null) {
/*  913 */           this.memberTypes[i].analyseCode(this.scope, flowContext, flowInfo1.copy().setReachMode(flowInfo.reachMode()));
/*      */         } else {
/*  915 */           this.memberTypes[i].analyseCode(this.scope);
/*      */         } 
/*      */       } 
/*      */     }
/*  919 */     if ((this.scope.compilerOptions()).complianceLevel >= 3473408L)
/*      */     {
/*      */ 
/*      */       
/*  923 */       if (this.methods == null || !this.methods[0].isClinit()) {
/*  924 */         Clinit clinit = new Clinit(this.compilationResult);
/*  925 */         clinit.declarationSourceStart = clinit.sourceStart = this.sourceStart;
/*  926 */         clinit.declarationSourceEnd = clinit.sourceEnd = this.sourceEnd;
/*  927 */         clinit.bodyEnd = this.sourceEnd;
/*  928 */         int length = (this.methods == null) ? 0 : this.methods.length;
/*  929 */         AbstractMethodDeclaration[] methodDeclarations = new AbstractMethodDeclaration[length + 1];
/*  930 */         methodDeclarations[0] = clinit;
/*  931 */         if (this.methods != null)
/*  932 */           System.arraycopy(this.methods, 0, methodDeclarations, 1, length); 
/*      */       } 
/*      */     }
/*  935 */     if (this.methods != null) {
/*  936 */       UnconditionalFlowInfo outerInfo = flowInfo.unconditionalFieldLessCopy();
/*  937 */       FlowInfo constructorInfo = flowInfo1.unconditionalInits().discardNonFieldInitializations().addInitializationsFrom((FlowInfo)outerInfo);
/*  938 */       SimpleSetOfCharArray jUnitMethodSourceValues = getJUnitMethodSourceValues();
/*  939 */       for (int i = 0, count = this.methods.length; i < count; i++) {
/*  940 */         AbstractMethodDeclaration method = this.methods[i];
/*  941 */         if (!method.ignoreFurtherInvestigation)
/*      */         {
/*  943 */           if (method.isInitializationMethod()) {
/*      */             
/*  945 */             if (method.isStatic()) {
/*  946 */               ((Clinit)method).analyseCode(
/*  947 */                   this.scope, 
/*  948 */                   staticInitializerContext, 
/*  949 */                   flowInfo2.unconditionalInits().discardNonFieldInitializations().addInitializationsFrom((FlowInfo)outerInfo));
/*      */             } else {
/*  951 */               ((ConstructorDeclaration)method).analyseCode(this.scope, initializerContext, constructorInfo.copy(), flowInfo.reachMode());
/*      */             } 
/*      */           } else {
/*      */             
/*  955 */             if (method.arguments == null && jUnitMethodSourceValues.includes(method.selector) && method.binding != null) {
/*  956 */               method.binding.modifiers |= 0x8000000;
/*      */             }
/*      */             
/*  959 */             ((MethodDeclaration)method).analyseCode(this.scope, parentContext, flowInfo.copy());
/*      */           } 
/*      */         }
/*      */       } 
/*      */     } 
/*  964 */     if (this.binding.isEnum() && !this.binding.isAnonymousType()) {
/*  965 */       this.enumValuesSyntheticfield = this.binding.addSyntheticFieldForEnumValues();
/*      */     }
/*      */   }
/*      */   
/*      */   private SimpleSetOfCharArray getJUnitMethodSourceValues() {
/*  970 */     SimpleSetOfCharArray junitMethodSourceValues = new SimpleSetOfCharArray(); byte b; int i; AbstractMethodDeclaration[] arrayOfAbstractMethodDeclaration;
/*  971 */     for (i = (arrayOfAbstractMethodDeclaration = this.methods).length, b = 0; b < i; ) { AbstractMethodDeclaration methodDeclaration = arrayOfAbstractMethodDeclaration[b];
/*  972 */       if (methodDeclaration.annotations != null) {
/*  973 */         byte b1; int j; Annotation[] arrayOfAnnotation; for (j = (arrayOfAnnotation = methodDeclaration.annotations).length, b1 = 0; b1 < j; ) { Annotation annotation = arrayOfAnnotation[b1];
/*  974 */           if (annotation.resolvedType != null && annotation.resolvedType.id == 93)
/*  975 */             addJUnitMethodSourceValues(junitMethodSourceValues, annotation, methodDeclaration.selector);  b1++; }
/*      */       
/*      */       } 
/*      */       b++; }
/*      */     
/*  980 */     return junitMethodSourceValues; } private void addJUnitMethodSourceValues(SimpleSetOfCharArray junitMethodSourceValues, Annotation annotation, char[] methodName) {
/*      */     byte b;
/*      */     int i;
/*      */     MemberValuePair[] arrayOfMemberValuePair;
/*  984 */     for (i = (arrayOfMemberValuePair = annotation.memberValuePairs()).length, b = 0; b < i; ) { MemberValuePair memberValuePair = arrayOfMemberValuePair[b];
/*  985 */       if (CharOperation.equals(memberValuePair.name, TypeConstants.VALUE)) {
/*  986 */         Expression value = memberValuePair.value;
/*  987 */         if (value instanceof ArrayInitializer) {
/*  988 */           ArrayInitializer arrayInitializer = (ArrayInitializer)value; byte b1; int j; Expression[] arrayOfExpression;
/*  989 */           for (j = (arrayOfExpression = arrayInitializer.expressions).length, b1 = 0; b1 < j; ) { Expression arrayValue = arrayOfExpression[b1];
/*  990 */             junitMethodSourceValues.add(getValueAsChars(arrayValue)); b1++; }
/*      */         
/*      */         } else {
/*  993 */           junitMethodSourceValues.add(getValueAsChars(value));
/*      */         } 
/*      */         return;
/*      */       } 
/*      */       b++; }
/*      */     
/*  999 */     junitMethodSourceValues.add(methodName);
/*      */   }
/*      */   
/*      */   private char[] getValueAsChars(Expression value) {
/* 1003 */     if (value instanceof StringLiteral)
/* 1004 */       return ((StringLiteral)value).source; 
/* 1005 */     if (value.constant instanceof StringConstant) {
/* 1006 */       return ((StringConstant)value.constant).stringValue().toCharArray();
/*      */     }
/* 1008 */     return CharOperation.NO_CHAR;
/*      */   }
/*      */   
/*      */   public static final int kind(int flags) {
/* 1012 */     switch (flags & 0x1006200) {
/*      */       case 512:
/* 1014 */         return 2;
/*      */       case 8704:
/* 1016 */         return 4;
/*      */       case 16384:
/* 1018 */         return 3;
/*      */       case 16777216:
/* 1020 */         return 5;
/*      */     } 
/* 1022 */     return 1;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isRecord() {
/* 1027 */     return ((this.modifiers & 0x1000000) != 0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void manageEnclosingInstanceAccessIfNecessary(BlockScope currentScope, FlowInfo flowInfo) {
/* 1039 */     if ((flowInfo.tagBits & 0x1) != 0)
/* 1040 */       return;  NestedTypeBinding nestedType = (NestedTypeBinding)this.binding;
/*      */     
/* 1042 */     MethodScope methodScope = currentScope.methodScope();
/* 1043 */     if (!methodScope.isStatic && !methodScope.isConstructorCall) {
/* 1044 */       nestedType.addSyntheticArgumentAndField(nestedType.enclosingType());
/*      */     }
/*      */     
/* 1047 */     if (nestedType.isAnonymousType()) {
/* 1048 */       ReferenceBinding superclassBinding = (ReferenceBinding)nestedType.superclass.erasure();
/* 1049 */       if (superclassBinding.enclosingType() != null && !superclassBinding.isStatic() && (
/* 1050 */         !superclassBinding.isLocalType() || (
/* 1051 */         (NestedTypeBinding)superclassBinding).getSyntheticField(superclassBinding.enclosingType(), true) != null || 
/* 1052 */         superclassBinding.isMemberType())) {
/* 1053 */         nestedType.addSyntheticArgument(superclassBinding.enclosingType());
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1065 */       if (!methodScope.isStatic && methodScope.isConstructorCall && (currentScope.compilerOptions()).complianceLevel >= 3211264L) {
/* 1066 */         ReferenceBinding enclosing = nestedType.enclosingType();
/* 1067 */         if (enclosing.isNestedType()) {
/* 1068 */           NestedTypeBinding nestedEnclosing = (NestedTypeBinding)enclosing;
/*      */           
/* 1070 */           SyntheticArgumentBinding syntheticEnclosingInstanceArgument = nestedEnclosing.getSyntheticArgument(nestedEnclosing.enclosingType(), true, false);
/* 1071 */           if (syntheticEnclosingInstanceArgument != null) {
/* 1072 */             nestedType.addSyntheticArgumentAndField((LocalVariableBinding)syntheticEnclosingInstanceArgument);
/*      */           }
/*      */         } 
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void manageEnclosingInstanceAccessIfNecessary(ClassScope currentScope, FlowInfo flowInfo) {
/* 1090 */     if ((flowInfo.tagBits & 0x1) == 0) {
/* 1091 */       NestedTypeBinding nestedType = (NestedTypeBinding)this.binding;
/* 1092 */       nestedType.addSyntheticArgumentAndField(this.binding.enclosingType());
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final boolean needClassInitMethod() {
/* 1102 */     if ((this.bits & 0x1) != 0) {
/* 1103 */       return true;
/*      */     }
/* 1105 */     switch (kind(this.modifiers)) {
/*      */       case 2:
/*      */       case 4:
/* 1108 */         return (this.fields != null);
/*      */       case 3:
/* 1110 */         return true;
/*      */     } 
/* 1112 */     if (this.fields != null)
/* 1113 */       for (int i = this.fields.length; --i >= 0; ) {
/* 1114 */         FieldDeclaration field = this.fields[i];
/*      */         
/* 1116 */         if ((field.modifiers & 0x8) != 0) {
/* 1117 */           return true;
/*      */         }
/*      */       }  
/* 1120 */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   public void parseMethods(Parser parser, CompilationUnitDeclaration unit) {
/* 1125 */     if (unit.ignoreMethodBodies) {
/*      */       return;
/*      */     }
/*      */     
/* 1129 */     if (this.memberTypes != null) {
/* 1130 */       int length = this.memberTypes.length;
/* 1131 */       for (int i = 0; i < length; i++) {
/* 1132 */         TypeDeclaration typeDeclaration = this.memberTypes[i];
/* 1133 */         typeDeclaration.parseMethods(parser, unit);
/* 1134 */         this.bits |= typeDeclaration.bits & 0x80000;
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/* 1139 */     if (this.methods != null) {
/* 1140 */       int length = this.methods.length;
/* 1141 */       for (int i = 0; i < length; i++) {
/* 1142 */         AbstractMethodDeclaration abstractMethodDeclaration = this.methods[i];
/* 1143 */         abstractMethodDeclaration.parseStatements(parser, unit);
/* 1144 */         this.bits |= abstractMethodDeclaration.bits & 0x80000;
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/* 1149 */     if (this.fields != null) {
/* 1150 */       int length = this.fields.length;
/* 1151 */       for (int i = 0; i < length; i++) {
/* 1152 */         FieldDeclaration fieldDeclaration = this.fields[i];
/* 1153 */         switch (fieldDeclaration.getKind()) {
/*      */           case 2:
/* 1155 */             ((Initializer)fieldDeclaration).parseStatements(parser, this, unit);
/* 1156 */             this.bits |= fieldDeclaration.bits & 0x80000;
/*      */             break;
/*      */         } 
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public StringBuffer print(int indent, StringBuffer output) {
/* 1165 */     if (this.javadoc != null) {
/* 1166 */       this.javadoc.print(indent, output);
/*      */     }
/* 1168 */     if ((this.bits & 0x200) == 0) {
/* 1169 */       printIndent(indent, output);
/* 1170 */       printHeader(0, output);
/*      */     } 
/* 1172 */     return printBody(indent, output);
/*      */   }
/*      */   
/*      */   public StringBuffer printBody(int indent, StringBuffer output) {
/* 1176 */     output.append(" {");
/* 1177 */     if (this.memberTypes != null) {
/* 1178 */       for (int i = 0; i < this.memberTypes.length; i++) {
/* 1179 */         if (this.memberTypes[i] != null) {
/* 1180 */           output.append('\n');
/* 1181 */           this.memberTypes[i].print(indent + 1, output);
/*      */         } 
/*      */       } 
/*      */     }
/* 1185 */     if (this.fields != null) {
/* 1186 */       for (int fieldI = 0; fieldI < this.fields.length; fieldI++) {
/* 1187 */         if (this.fields[fieldI] != null) {
/* 1188 */           output.append('\n');
/* 1189 */           this.fields[fieldI].print(indent + 1, output);
/*      */         } 
/*      */       } 
/*      */     }
/* 1193 */     if (this.methods != null) {
/* 1194 */       for (int i = 0; i < this.methods.length; i++) {
/* 1195 */         if (this.methods[i] != null) {
/* 1196 */           output.append('\n');
/* 1197 */           this.methods[i].print(indent + 1, output);
/*      */         } 
/*      */       } 
/*      */     }
/* 1201 */     output.append('\n');
/* 1202 */     return printIndent(indent, output).append('}');
/*      */   }
/*      */   
/*      */   public StringBuffer printHeader(int indent, StringBuffer output) {
/* 1206 */     printModifiers(this.modifiers, output);
/* 1207 */     if (this.annotations != null) {
/* 1208 */       printAnnotations(this.annotations, output);
/* 1209 */       output.append(' ');
/*      */     } 
/*      */     
/* 1212 */     switch (kind(this.modifiers)) {
/*      */       case 1:
/* 1214 */         output.append("class ");
/*      */         break;
/*      */       case 2:
/* 1217 */         output.append("interface ");
/*      */         break;
/*      */       case 3:
/* 1220 */         output.append("enum ");
/*      */         break;
/*      */       case 4:
/* 1223 */         output.append("@interface ");
/*      */         break;
/*      */       case 5:
/* 1226 */         output.append("record ");
/*      */         break;
/*      */     } 
/* 1229 */     output.append(this.name);
/* 1230 */     if (isRecord()) {
/* 1231 */       output.append('(');
/* 1232 */       if (this.nRecordComponents > 0 && this.fields != null) {
/* 1233 */         for (int i = 0; i < this.nRecordComponents; i++) {
/* 1234 */           if (i > 0) output.append(", "); 
/* 1235 */           output.append((this.fields[i]).type.getTypeName()[0]);
/* 1236 */           output.append(' ');
/* 1237 */           output.append((this.fields[i]).name);
/*      */         } 
/*      */       }
/* 1240 */       output.append(')');
/*      */     } 
/* 1242 */     if (this.typeParameters != null) {
/* 1243 */       output.append("<");
/* 1244 */       for (int i = 0; i < this.typeParameters.length; i++) {
/* 1245 */         if (i > 0) output.append(", "); 
/* 1246 */         this.typeParameters[i].print(0, output);
/*      */       } 
/* 1248 */       output.append(">");
/*      */     } 
/*      */     
/* 1251 */     if (!isRecord() && this.superclass != null) {
/* 1252 */       output.append(" extends ");
/* 1253 */       this.superclass.print(0, output);
/*      */     } 
/* 1255 */     if (this.superInterfaces != null && this.superInterfaces.length > 0) {
/* 1256 */       switch (kind(this.modifiers)) {
/*      */         case 1:
/*      */         case 3:
/*      */         case 5:
/* 1260 */           output.append(" implements ");
/*      */           break;
/*      */         case 2:
/*      */         case 4:
/* 1264 */           output.append(" extends ");
/*      */           break;
/*      */       } 
/* 1267 */       for (int i = 0; i < this.superInterfaces.length; i++) {
/* 1268 */         if (i > 0) output.append(", "); 
/* 1269 */         this.superInterfaces[i].print(0, output);
/*      */       } 
/*      */     } 
/* 1272 */     if (this.permittedTypes != null && this.permittedTypes.length > 0) {
/* 1273 */       output.append(" permits ");
/* 1274 */       for (int i = 0; i < this.permittedTypes.length; i++) {
/* 1275 */         if (i > 0) output.append(", "); 
/* 1276 */         this.permittedTypes[i].print(0, output);
/*      */       } 
/*      */     } 
/* 1279 */     return output;
/*      */   }
/*      */ 
/*      */   
/*      */   public StringBuffer printStatement(int tab, StringBuffer output) {
/* 1284 */     return print(tab, output);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int record(FunctionalExpression expression) {
/* 1292 */     return this.functionalExpressionsCount++;
/*      */   }
/*      */   
/*      */   public void resolve() {
/* 1296 */     SourceTypeBinding sourceType = this.binding;
/* 1297 */     if (sourceType == null) {
/* 1298 */       this.ignoreFurtherInvestigation = true;
/*      */       return;
/*      */     } 
/*      */     try {
/* 1302 */       if (CharOperation.equals(this.name, TypeConstants.VAR)) {
/* 1303 */         if ((this.scope.compilerOptions()).sourceLevel < 3538944L) {
/* 1304 */           this.scope.problemReporter().varIsReservedTypeNameInFuture(this);
/*      */         } else {
/* 1306 */           this.scope.problemReporter().varIsReservedTypeName(this);
/*      */         } 
/*      */       }
/* 1309 */       this.scope.problemReporter().validateRestrictedKeywords(this.name, this);
/*      */       
/* 1311 */       long annotationTagBits = sourceType.getAnnotationTagBits();
/* 1312 */       if ((annotationTagBits & 0x400000000000L) == 0L && (
/* 1313 */         sourceType.modifiers & 0x100000) != 0 && 
/* 1314 */         (this.scope.compilerOptions()).sourceLevel >= 3211264L) {
/* 1315 */         this.scope.problemReporter().missingDeprecatedAnnotationForType(this);
/*      */       }
/* 1317 */       if ((annotationTagBits & 0x800000000000000L) != 0L && 
/* 1318 */         !this.binding.isFunctionalInterface((Scope)this.scope)) {
/* 1319 */         this.scope.problemReporter().notAFunctionalInterface(this);
/*      */       }
/*      */ 
/*      */       
/* 1323 */       if ((this.bits & 0x8) != 0 && this.nRecordComponents == 0) {
/* 1324 */         this.scope.problemReporter().undocumentedEmptyBlock(this.bodyStart - 1, this.bodyEnd);
/*      */       }
/* 1326 */       boolean needSerialVersion = 
/* 1327 */         (this.scope.compilerOptions().getSeverity(536870920) != 256 && 
/* 1328 */         sourceType.isClass() && 
/* 1329 */         !sourceType.isRecord() && 
/* 1330 */         sourceType.findSuperTypeOriginatingFrom(56, false) == null && 
/* 1331 */         sourceType.findSuperTypeOriginatingFrom(37, false) != null);
/*      */       
/* 1333 */       if (needSerialVersion) {
/*      */ 
/*      */         
/* 1336 */         CompilationUnitScope compilationUnitScope = this.scope.compilationUnitScope();
/* 1337 */         MethodBinding methodBinding = sourceType.getExactMethod(TypeConstants.WRITEREPLACE, Binding.NO_TYPES, compilationUnitScope);
/*      */         ReferenceBinding[] throwsExceptions;
/* 1339 */         needSerialVersion = 
/* 1340 */           !(methodBinding != null && 
/* 1341 */           methodBinding.isValidBinding() && 
/* 1342 */           methodBinding.returnType.id == 1 && (
/* 1343 */           throwsExceptions = methodBinding.thrownExceptions).length == 1 && 
/* 1344 */           (throwsExceptions[0]).id == 57);
/* 1345 */         if (needSerialVersion) {
/*      */ 
/*      */ 
/*      */           
/* 1349 */           boolean hasWriteObjectMethod = false;
/* 1350 */           boolean hasReadObjectMethod = false;
/* 1351 */           TypeBinding argumentTypeBinding = this.scope.getType(TypeConstants.JAVA_IO_OBJECTOUTPUTSTREAM, 3);
/* 1352 */           if (argumentTypeBinding.isValidBinding()) {
/* 1353 */             methodBinding = sourceType.getExactMethod(TypeConstants.WRITEOBJECT, new TypeBinding[] { argumentTypeBinding }, compilationUnitScope);
/* 1354 */             hasWriteObjectMethod = (methodBinding != null && 
/* 1355 */               methodBinding.isValidBinding() && 
/* 1356 */               methodBinding.modifiers == 2 && 
/* 1357 */               methodBinding.returnType == TypeBinding.VOID && (
/* 1358 */               throwsExceptions = methodBinding.thrownExceptions).length == 1 && 
/* 1359 */               (throwsExceptions[0]).id == 58);
/*      */           } 
/* 1361 */           argumentTypeBinding = this.scope.getType(TypeConstants.JAVA_IO_OBJECTINPUTSTREAM, 3);
/* 1362 */           if (argumentTypeBinding.isValidBinding()) {
/* 1363 */             methodBinding = sourceType.getExactMethod(TypeConstants.READOBJECT, new TypeBinding[] { argumentTypeBinding }, compilationUnitScope);
/* 1364 */             hasReadObjectMethod = (methodBinding != null && 
/* 1365 */               methodBinding.isValidBinding() && 
/* 1366 */               methodBinding.modifiers == 2 && 
/* 1367 */               methodBinding.returnType == TypeBinding.VOID && (
/* 1368 */               throwsExceptions = methodBinding.thrownExceptions).length == 1 && 
/* 1369 */               (throwsExceptions[0]).id == 58);
/*      */           } 
/* 1371 */           needSerialVersion = !(hasWriteObjectMethod && hasReadObjectMethod);
/*      */         } 
/*      */       } 
/*      */       
/* 1375 */       if (sourceType.findSuperTypeOriginatingFrom(21, true) != null) {
/* 1376 */         SourceTypeBinding sourceTypeBinding = sourceType; ReferenceBinding referenceBinding;
/*      */         do {
/* 1378 */           if (sourceTypeBinding.isGenericType()) {
/* 1379 */             this.scope.problemReporter().genericTypeCannotExtendThrowable(this);
/*      */             break;
/*      */           } 
/* 1382 */           if (sourceTypeBinding.isStatic())
/* 1383 */             break;  if (!sourceTypeBinding.isLocalType())
/* 1384 */             continue;  NestedTypeBinding nestedType = (NestedTypeBinding)sourceTypeBinding.erasure();
/* 1385 */           if ((nestedType.scope.methodScope()).isStatic)
/*      */             break; 
/* 1387 */         } while ((referenceBinding = sourceTypeBinding.enclosingType()) != null);
/*      */       } 
/*      */       
/* 1390 */       int localMaxFieldCount = 0;
/* 1391 */       int lastVisibleFieldID = -1;
/* 1392 */       boolean hasEnumConstants = false;
/* 1393 */       FieldDeclaration[] enumConstantsWithoutBody = null;
/*      */       
/* 1395 */       if (this.memberTypes != null) {
/* 1396 */         for (int i = 0, count = this.memberTypes.length; i < count; i++) {
/* 1397 */           this.memberTypes[i].resolve(this.scope);
/*      */         }
/*      */       }
/* 1400 */       if (this.recordComponents != null) {
/* 1401 */         byte b; int i; RecordComponent[] arrayOfRecordComponent; for (i = (arrayOfRecordComponent = this.recordComponents).length, b = 0; b < i; ) { RecordComponent rc = arrayOfRecordComponent[b];
/* 1402 */           rc.resolve((BlockScope)this.initializerScope); b++; }
/*      */       
/*      */       } 
/* 1405 */       if (this.fields != null)
/* 1406 */         for (int i = 0, count = this.fields.length; i < count; i++) {
/* 1407 */           FieldBinding fieldBinding; FieldDeclaration field = this.fields[i];
/* 1408 */           switch (field.getKind()) {
/*      */             case 3:
/* 1410 */               hasEnumConstants = true;
/* 1411 */               if (!(field.initialization instanceof QualifiedAllocationExpression)) {
/* 1412 */                 if (enumConstantsWithoutBody == null)
/* 1413 */                   enumConstantsWithoutBody = new FieldDeclaration[count]; 
/* 1414 */                 enumConstantsWithoutBody[i] = field;
/*      */               } 
/*      */             
/*      */             case 1:
/* 1418 */               fieldBinding = field.binding;
/* 1419 */               if (fieldBinding == null) {
/*      */                 
/* 1421 */                 if (field.initialization != null) field.initialization.resolve(field.isStatic() ? (BlockScope)this.staticInitializerScope : (BlockScope)this.initializerScope); 
/* 1422 */                 this.ignoreFurtherInvestigation = true;
/*      */                 break;
/*      */               } 
/* 1425 */               if (needSerialVersion && (
/* 1426 */                 fieldBinding.modifiers & 0x18) == 24 && 
/* 1427 */                 CharOperation.equals(TypeConstants.SERIALVERSIONUID, fieldBinding.name) && 
/* 1428 */                 TypeBinding.equalsEquals((TypeBinding)TypeBinding.LONG, fieldBinding.type)) {
/* 1429 */                 needSerialVersion = false;
/*      */               }
/* 1431 */               localMaxFieldCount++;
/* 1432 */               lastVisibleFieldID = field.binding.id;
/*      */ 
/*      */             
/*      */             case 2:
/* 1436 */               ((Initializer)field).lastVisibleFieldID = lastVisibleFieldID + 1;
/*      */             
/*      */             default:
/* 1439 */               if (isRecord()) {
/* 1440 */                 field.javadoc = this.javadoc;
/*      */               }
/* 1442 */               field.resolve(field.isStatic() ? this.staticInitializerScope : this.initializerScope); break;
/*      */           } 
/*      */         }  
/* 1445 */       if (this.maxFieldCount < localMaxFieldCount) {
/* 1446 */         this.maxFieldCount = localMaxFieldCount;
/*      */       }
/* 1448 */       if (needSerialVersion) {
/*      */         
/* 1450 */         TypeBinding javaxRmiCorbaStub = this.scope.getType(TypeConstants.JAVAX_RMI_CORBA_STUB, 4);
/* 1451 */         if (javaxRmiCorbaStub.isValidBinding()) {
/* 1452 */           ReferenceBinding superclassBinding = this.binding.superclass;
/* 1453 */           while (superclassBinding != null) {
/* 1454 */             if (TypeBinding.equalsEquals((TypeBinding)superclassBinding, javaxRmiCorbaStub)) {
/* 1455 */               needSerialVersion = false;
/*      */               break;
/*      */             } 
/* 1458 */             superclassBinding = superclassBinding.superclass();
/*      */           } 
/*      */         } 
/* 1461 */         if (needSerialVersion) {
/* 1462 */           this.scope.problemReporter().missingSerialVersion(this);
/*      */         }
/*      */       } 
/*      */ 
/*      */       
/* 1467 */       switch (kind(this.modifiers)) {
/*      */         case 4:
/* 1469 */           if (this.superclass != null) {
/* 1470 */             this.scope.problemReporter().annotationTypeDeclarationCannotHaveSuperclass(this);
/*      */           }
/* 1472 */           if (this.superInterfaces != null) {
/* 1473 */             this.scope.problemReporter().annotationTypeDeclarationCannotHaveSuperinterfaces(this);
/*      */           }
/*      */           break;
/*      */         
/*      */         case 3:
/* 1478 */           if (this.binding.isAbstract()) {
/* 1479 */             if (!hasEnumConstants) {
/* 1480 */               for (int i = 0, count = this.methods.length; i < count; i++) {
/* 1481 */                 AbstractMethodDeclaration methodDeclaration = this.methods[i];
/* 1482 */                 if (methodDeclaration.isAbstract() && methodDeclaration.binding != null)
/* 1483 */                   this.scope.problemReporter().enumAbstractMethodMustBeImplemented(methodDeclaration); 
/*      */               }  break;
/* 1485 */             }  if (enumConstantsWithoutBody != null)
/* 1486 */               for (int i = 0, count = this.methods.length; i < count; i++) {
/* 1487 */                 AbstractMethodDeclaration methodDeclaration = this.methods[i];
/* 1488 */                 if (methodDeclaration.isAbstract() && methodDeclaration.binding != null) {
/* 1489 */                   for (int f = 0, l = enumConstantsWithoutBody.length; f < l; f++) {
/* 1490 */                     if (enumConstantsWithoutBody[f] != null) {
/* 1491 */                       this.scope.problemReporter().enumConstantMustImplementAbstractMethod(methodDeclaration, enumConstantsWithoutBody[f]);
/*      */                     }
/*      */                   } 
/*      */                 }
/*      */               }  
/*      */           } 
/*      */           break;
/*      */       } 
/* 1499 */       int missingAbstractMethodslength = (this.missingAbstractMethods == null) ? 0 : this.missingAbstractMethods.length;
/* 1500 */       int methodsLength = (this.methods == null) ? 0 : this.methods.length;
/* 1501 */       if (methodsLength + missingAbstractMethodslength > 65535) {
/* 1502 */         this.scope.problemReporter().tooManyMethods(this);
/*      */       }
/* 1504 */       if (this.methods != null) {
/* 1505 */         for (int i = 0, count = this.methods.length; i < count; i++) {
/* 1506 */           this.methods[i].resolve(this.scope);
/*      */         }
/*      */       }
/*      */       
/* 1510 */       if (this.javadoc != null) {
/* 1511 */         if (this.scope != null && this.name != TypeConstants.PACKAGE_INFO_NAME)
/*      */         {
/* 1513 */           this.javadoc.resolve(this.scope);
/*      */         }
/* 1515 */       } else if (!sourceType.isLocalType()) {
/*      */         
/* 1517 */         int visibility = sourceType.modifiers & 0x7;
/* 1518 */         ProblemReporter reporter = this.scope.problemReporter();
/* 1519 */         int severity = reporter.computeSeverity(-1610612250);
/* 1520 */         if (severity != 256) {
/* 1521 */           if (this.enclosingType != null) {
/* 1522 */             visibility = Util.computeOuterMostVisibility(this.enclosingType, visibility);
/*      */           }
/* 1524 */           int javadocModifiers = this.binding.modifiers & 0xFFFFFFF8 | visibility;
/* 1525 */           reporter.javadocMissing(this.sourceStart, this.sourceEnd, severity, javadocModifiers);
/*      */         } 
/*      */       } 
/* 1528 */       updateNestHost();
/* 1529 */       FieldDeclaration[] fieldsDecls = this.fields;
/* 1530 */       if (fieldsDecls != null) {
/* 1531 */         byte b; int i; FieldDeclaration[] arrayOfFieldDeclaration; for (i = (arrayOfFieldDeclaration = fieldsDecls).length, b = 0; b < i; ) { FieldDeclaration fieldDeclaration = arrayOfFieldDeclaration[b];
/* 1532 */           fieldDeclaration.resolveJavadoc(this.initializerScope); b++; }
/*      */       
/* 1534 */       }  AbstractMethodDeclaration[] methodDecls = this.methods;
/* 1535 */       if (methodDecls != null) {
/* 1536 */         byte b; int i; AbstractMethodDeclaration[] arrayOfAbstractMethodDeclaration; for (i = (arrayOfAbstractMethodDeclaration = methodDecls).length, b = 0; b < i; ) { AbstractMethodDeclaration methodDeclaration = arrayOfAbstractMethodDeclaration[b];
/* 1537 */           methodDeclaration.resolveJavadoc(); b++; } 
/*      */       } 
/* 1539 */     } catch (AbortType abortType) {
/* 1540 */       this.ignoreFurtherInvestigation = true;
/*      */       return;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void resolve(BlockScope blockScope) {
/* 1552 */     if ((this.bits & 0x200) == 0) {
/*      */       
/* 1554 */       TypeBinding typeBinding = blockScope.getType(this.name);
/* 1555 */       if (typeBinding instanceof ReferenceBinding && 
/* 1556 */         typeBinding != this.binding && 
/* 1557 */         typeBinding.isValidBinding()) {
/* 1558 */         ReferenceBinding existingType = (ReferenceBinding)typeBinding;
/* 1559 */         if (existingType instanceof TypeVariableBinding) {
/* 1560 */           blockScope.problemReporter().typeHiding(this, (TypeVariableBinding)existingType);
/*      */           
/* 1562 */           Scope outerScope = blockScope.parent;
/* 1563 */           while (outerScope != null) {
/* 1564 */             TypeBinding typeBinding1 = outerScope.getType(this.name);
/* 1565 */             if (typeBinding1 instanceof TypeVariableBinding && typeBinding1.isValidBinding()) {
/* 1566 */               TypeVariableBinding tvb = (TypeVariableBinding)existingType;
/* 1567 */               Binding declaringElement = tvb.declaringElement;
/* 1568 */               if (declaringElement instanceof ReferenceBinding && 
/* 1569 */                 CharOperation.equals(((ReferenceBinding)declaringElement).sourceName(), this.name)) {
/* 1570 */                 blockScope.problemReporter().typeCollidesWithEnclosingType(this); break;
/*      */               } 
/*      */             } else {
/* 1573 */               if (typeBinding1 instanceof ReferenceBinding && 
/* 1574 */                 typeBinding1.isValidBinding() && 
/* 1575 */                 outerScope.isDefinedInType((ReferenceBinding)typeBinding1)) {
/* 1576 */                 blockScope.problemReporter().typeCollidesWithEnclosingType(this); break;
/*      */               } 
/* 1578 */               if (typeBinding1 == null)
/*      */                 break; 
/*      */             } 
/* 1581 */             outerScope = outerScope.parent;
/*      */           } 
/* 1583 */         } else if (existingType instanceof LocalTypeBinding && 
/* 1584 */           ((LocalTypeBinding)existingType).scope.methodScope() == blockScope.methodScope()) {
/*      */           
/* 1586 */           blockScope.problemReporter().duplicateNestedType(this);
/* 1587 */         } else if (existingType instanceof LocalTypeBinding && blockScope.isLambdaSubscope() && 
/* 1588 */           blockScope.enclosingLambdaScope().enclosingMethodScope() == ((LocalTypeBinding)existingType).scope.methodScope()) {
/* 1589 */           blockScope.problemReporter().duplicateNestedType(this);
/* 1590 */         } else if (blockScope.isDefinedInType(existingType)) {
/*      */           
/* 1592 */           blockScope.problemReporter().typeCollidesWithEnclosingType(this);
/* 1593 */         } else if (blockScope.isDefinedInSameUnit(existingType)) {
/*      */           
/* 1595 */           blockScope.problemReporter().typeHiding(this, (TypeBinding)existingType);
/*      */         } 
/*      */       } 
/* 1598 */       blockScope.addLocalType(this);
/*      */     } 
/*      */     
/* 1601 */     if (this.binding != null) {
/*      */       
/* 1603 */       blockScope.referenceCompilationUnit().record((LocalTypeBinding)this.binding);
/*      */ 
/*      */       
/* 1606 */       resolve();
/* 1607 */       updateMaxFieldCount();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void resolve(ClassScope upperScope) {
/* 1618 */     if (this.binding != null && this.binding instanceof LocalTypeBinding)
/*      */     {
/* 1620 */       upperScope.referenceCompilationUnit().record((LocalTypeBinding)this.binding);
/*      */     }
/* 1622 */     resolve();
/* 1623 */     updateMaxFieldCount();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void resolve(CompilationUnitScope upperScope) {
/* 1631 */     resolve();
/* 1632 */     updateMaxFieldCount();
/*      */   }
/*      */ 
/*      */   
/*      */   public void tagAsHavingErrors() {
/* 1637 */     this.ignoreFurtherInvestigation = true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void tagAsHavingIgnoredMandatoryErrors(int problemId) {}
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void traverse(ASTVisitor visitor, CompilationUnitScope unitScope) {
/*      */     try {
/* 1651 */       if (visitor.visit(this, unitScope)) {
/* 1652 */         if (this.javadoc != null) {
/* 1653 */           this.javadoc.traverse(visitor, this.scope);
/*      */         }
/* 1655 */         if (this.annotations != null) {
/* 1656 */           int annotationsLength = this.annotations.length;
/* 1657 */           for (int i = 0; i < annotationsLength; i++)
/* 1658 */             this.annotations[i].traverse(visitor, (BlockScope)this.staticInitializerScope); 
/*      */         } 
/* 1660 */         if (this.superclass != null)
/* 1661 */           this.superclass.traverse(visitor, this.scope); 
/* 1662 */         if (this.superInterfaces != null) {
/* 1663 */           int length = this.superInterfaces.length;
/* 1664 */           for (int i = 0; i < length; i++)
/* 1665 */             this.superInterfaces[i].traverse(visitor, this.scope); 
/*      */         } 
/* 1667 */         if (this.permittedTypes != null) {
/* 1668 */           int length = this.permittedTypes.length;
/* 1669 */           for (int i = 0; i < length; i++)
/* 1670 */             this.permittedTypes[i].traverse(visitor, this.scope); 
/*      */         } 
/* 1672 */         if (this.typeParameters != null) {
/* 1673 */           int length = this.typeParameters.length;
/* 1674 */           for (int i = 0; i < length; i++) {
/* 1675 */             this.typeParameters[i].traverse(visitor, this.scope);
/*      */           }
/*      */         } 
/* 1678 */         if (this.recordComponents != null) {
/* 1679 */           int length = this.recordComponents.length;
/* 1680 */           for (int i = 0; i < length; i++)
/* 1681 */             this.recordComponents[i].traverse(visitor, (BlockScope)this.initializerScope); 
/*      */         } 
/* 1683 */         if (this.memberTypes != null) {
/* 1684 */           int length = this.memberTypes.length;
/* 1685 */           for (int i = 0; i < length; i++)
/* 1686 */             this.memberTypes[i].traverse(visitor, this.scope); 
/*      */         } 
/* 1688 */         if (this.fields != null) {
/* 1689 */           int length = this.fields.length;
/* 1690 */           for (int i = 0; i < length; i++) {
/*      */             FieldDeclaration field;
/* 1692 */             if ((field = this.fields[i]).isStatic()) {
/* 1693 */               field.traverse(visitor, this.staticInitializerScope);
/*      */             } else {
/* 1695 */               field.traverse(visitor, this.initializerScope);
/*      */             } 
/*      */           } 
/*      */         } 
/* 1699 */         if (this.methods != null) {
/* 1700 */           int length = this.methods.length;
/* 1701 */           for (int i = 0; i < length; i++)
/* 1702 */             this.methods[i].traverse(visitor, this.scope); 
/*      */         } 
/*      */       } 
/* 1705 */       visitor.endVisit(this, unitScope);
/* 1706 */     } catch (AbortType abortType) {}
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void traverse(ASTVisitor visitor, BlockScope blockScope) {
/*      */     try {
/* 1717 */       if (visitor.visit(this, blockScope)) {
/* 1718 */         if (this.javadoc != null) {
/* 1719 */           this.javadoc.traverse(visitor, this.scope);
/*      */         }
/* 1721 */         if (this.annotations != null) {
/* 1722 */           int annotationsLength = this.annotations.length;
/* 1723 */           for (int i = 0; i < annotationsLength; i++)
/* 1724 */             this.annotations[i].traverse(visitor, (BlockScope)this.staticInitializerScope); 
/*      */         } 
/* 1726 */         if (this.superclass != null)
/* 1727 */           this.superclass.traverse(visitor, this.scope); 
/* 1728 */         if (this.superInterfaces != null) {
/* 1729 */           int length = this.superInterfaces.length;
/* 1730 */           for (int i = 0; i < length; i++)
/* 1731 */             this.superInterfaces[i].traverse(visitor, this.scope); 
/*      */         } 
/* 1733 */         if (this.permittedTypes != null) {
/* 1734 */           int length = this.permittedTypes.length;
/* 1735 */           for (int i = 0; i < length; i++)
/* 1736 */             this.permittedTypes[i].traverse(visitor, this.scope); 
/*      */         } 
/* 1738 */         if (this.typeParameters != null) {
/* 1739 */           int length = this.typeParameters.length;
/* 1740 */           for (int i = 0; i < length; i++) {
/* 1741 */             this.typeParameters[i].traverse(visitor, this.scope);
/*      */           }
/*      */         } 
/* 1744 */         if (this.recordComponents != null) {
/* 1745 */           int length = this.recordComponents.length;
/* 1746 */           for (int i = 0; i < length; i++)
/* 1747 */             this.recordComponents[i].traverse(visitor, (BlockScope)this.initializerScope); 
/*      */         } 
/* 1749 */         if (this.memberTypes != null) {
/* 1750 */           int length = this.memberTypes.length;
/* 1751 */           for (int i = 0; i < length; i++)
/* 1752 */             this.memberTypes[i].traverse(visitor, this.scope); 
/*      */         } 
/* 1754 */         if (this.fields != null) {
/* 1755 */           int length = this.fields.length;
/* 1756 */           for (int i = 0; i < length; i++) {
/* 1757 */             FieldDeclaration field = this.fields[i];
/* 1758 */             if (!field.isStatic() || field.isFinal())
/*      */             {
/*      */               
/* 1761 */               field.traverse(visitor, this.initializerScope);
/*      */             }
/*      */           } 
/*      */         } 
/* 1765 */         if (this.methods != null) {
/* 1766 */           int length = this.methods.length;
/* 1767 */           for (int i = 0; i < length; i++)
/* 1768 */             this.methods[i].traverse(visitor, this.scope); 
/*      */         } 
/*      */       } 
/* 1771 */       visitor.endVisit(this, blockScope);
/* 1772 */     } catch (AbortType abortType) {}
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void traverse(ASTVisitor visitor, ClassScope classScope) {
/*      */     try {
/* 1783 */       if (visitor.visit(this, classScope)) {
/* 1784 */         if (this.javadoc != null) {
/* 1785 */           this.javadoc.traverse(visitor, this.scope);
/*      */         }
/* 1787 */         if (this.annotations != null) {
/* 1788 */           int annotationsLength = this.annotations.length;
/* 1789 */           for (int i = 0; i < annotationsLength; i++)
/* 1790 */             this.annotations[i].traverse(visitor, (BlockScope)this.staticInitializerScope); 
/*      */         } 
/* 1792 */         if (this.superclass != null)
/* 1793 */           this.superclass.traverse(visitor, this.scope); 
/* 1794 */         if (this.superInterfaces != null) {
/* 1795 */           int length = this.superInterfaces.length;
/* 1796 */           for (int i = 0; i < length; i++)
/* 1797 */             this.superInterfaces[i].traverse(visitor, this.scope); 
/*      */         } 
/* 1799 */         if (this.permittedTypes != null) {
/* 1800 */           int length = this.permittedTypes.length;
/* 1801 */           for (int i = 0; i < length; i++)
/* 1802 */             this.permittedTypes[i].traverse(visitor, this.scope); 
/*      */         } 
/* 1804 */         if (this.typeParameters != null) {
/* 1805 */           int length = this.typeParameters.length;
/* 1806 */           for (int i = 0; i < length; i++) {
/* 1807 */             this.typeParameters[i].traverse(visitor, this.scope);
/*      */           }
/*      */         } 
/* 1810 */         if (this.recordComponents != null) {
/* 1811 */           int length = this.recordComponents.length;
/* 1812 */           for (int i = 0; i < length; i++)
/* 1813 */             this.recordComponents[i].traverse(visitor, (BlockScope)this.initializerScope); 
/*      */         } 
/* 1815 */         if (this.memberTypes != null) {
/* 1816 */           int length = this.memberTypes.length;
/* 1817 */           for (int i = 0; i < length; i++)
/* 1818 */             this.memberTypes[i].traverse(visitor, this.scope); 
/*      */         } 
/* 1820 */         if (this.fields != null) {
/* 1821 */           int length = this.fields.length;
/* 1822 */           for (int i = 0; i < length; i++) {
/*      */             FieldDeclaration field;
/* 1824 */             if ((field = this.fields[i]).isStatic()) {
/* 1825 */               field.traverse(visitor, this.staticInitializerScope);
/*      */             } else {
/* 1827 */               field.traverse(visitor, this.initializerScope);
/*      */             } 
/*      */           } 
/*      */         } 
/* 1831 */         if (this.methods != null) {
/* 1832 */           int length = this.methods.length;
/* 1833 */           for (int i = 0; i < length; i++)
/* 1834 */             this.methods[i].traverse(visitor, this.scope); 
/*      */         } 
/*      */       } 
/* 1837 */       visitor.endVisit(this, classScope);
/* 1838 */     } catch (AbortType abortType) {}
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void updateMaxFieldCount() {
/* 1854 */     if (this.binding == null)
/*      */       return; 
/* 1856 */     TypeDeclaration outerMostType = this.scope.outerMostClassScope().referenceType();
/* 1857 */     if (this.maxFieldCount > outerMostType.maxFieldCount) {
/* 1858 */       outerMostType.maxFieldCount = this.maxFieldCount;
/*      */     } else {
/* 1860 */       this.maxFieldCount = outerMostType.maxFieldCount;
/*      */     } 
/*      */   }
/*      */   
/*      */   private SourceTypeBinding findNestHost() {
/* 1865 */     ClassScope classScope = this.scope.enclosingTopMostClassScope();
/* 1866 */     return (classScope != null) ? classScope.referenceContext.binding : null;
/*      */   }
/*      */   
/*      */   void updateNestHost() {
/* 1870 */     if (this.binding == null)
/*      */       return; 
/* 1872 */     SourceTypeBinding nestHost = findNestHost();
/* 1873 */     if (nestHost != null && !this.binding.equals(nestHost))
/* 1874 */       this.binding.setNestHost(nestHost); 
/*      */   }
/*      */   
/*      */   public boolean isPackageInfo() {
/* 1878 */     return CharOperation.equals(this.name, TypeConstants.PACKAGE_INFO_NAME);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isSecondary() {
/* 1884 */     return ((this.bits & 0x1000) != 0);
/*      */   }
/*      */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\ast\TypeDeclaration.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */