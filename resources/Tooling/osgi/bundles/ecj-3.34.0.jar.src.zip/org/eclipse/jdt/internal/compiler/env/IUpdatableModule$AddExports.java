/*    */ package org.eclipse.jdt.internal.compiler.env;
/*    */ 
/*    */ import java.util.function.Consumer;
/*    */ import org.eclipse.jdt.core.compiler.CharOperation;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AddExports
/*    */   implements Consumer<IUpdatableModule>
/*    */ {
/*    */   char[] name;
/*    */   char[][] targets;
/*    */   
/*    */   public AddExports(char[] pkgName, char[][] targets) {
/* 41 */     this.name = pkgName;
/* 42 */     this.targets = targets;
/*    */   }
/*    */   
/*    */   public void accept(IUpdatableModule t) {
/* 46 */     t.addExports(this.name, this.targets);
/*    */   }
/*    */   
/*    */   public char[] getName() {
/* 50 */     return this.name;
/*    */   }
/*    */   
/*    */   public char[][] getTargetModules() {
/* 54 */     return this.targets;
/*    */   }
/*    */   
/*    */   public IUpdatableModule.UpdateKind getKind() {
/* 58 */     return IUpdatableModule.UpdateKind.PACKAGE;
/*    */   }
/*    */   
/*    */   public boolean equals(Object other) {
/* 62 */     if (this == other) return true; 
/* 63 */     if (!(other instanceof AddExports)) return false; 
/* 64 */     AddExports pu = (AddExports)other;
/*    */     
/* 66 */     if (!CharOperation.equals(this.name, pu.name))
/* 67 */       return false; 
/* 68 */     if (!CharOperation.equals(this.targets, pu.targets))
/* 69 */       return false; 
/* 70 */     return true;
/*    */   }
/*    */   
/*    */   public int hashCode() {
/* 74 */     int hash = CharOperation.hashCode(this.name);
/* 75 */     if (this.targets != null) {
/* 76 */       for (int i = 0; i < this.targets.length; i++) {
/* 77 */         hash += 17 * CharOperation.hashCode(this.targets[i]);
/*    */       }
/*    */     }
/* 80 */     return hash;
/*    */   }
/*    */   
/*    */   public String toString() {
/* 84 */     return "add-exports " + CharOperation.charToString(this.name) + "=" + CharOperation.charToString(CharOperation.concatWith(this.targets, ','));
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\env\IUpdatableModule$AddExports.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */