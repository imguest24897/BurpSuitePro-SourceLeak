/*    */ package org.eclipse.jdt.internal.compiler.env;
/*    */ 
/*    */ import org.eclipse.jdt.core.compiler.CharOperation;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ModuleReferenceImpl
/*    */   implements IModule.IModuleReference
/*    */ {
/*    */   public char[] name;
/*    */   public int modifiers;
/*    */   
/*    */   public char[] name() {
/* 23 */     return this.name;
/*    */   }
/*    */   
/*    */   public boolean equals(Object o) {
/* 27 */     if (this == o)
/* 28 */       return true; 
/* 29 */     if (!(o instanceof IModule.IModuleReference))
/* 30 */       return false; 
/* 31 */     IModule.IModuleReference mod = (IModule.IModuleReference)o;
/* 32 */     if (this.modifiers != mod.getModifiers())
/* 33 */       return false; 
/* 34 */     return CharOperation.equals(this.name, mod.name());
/*    */   }
/*    */   
/*    */   public int hashCode() {
/* 38 */     return CharOperation.hashCode(this.name);
/*    */   }
/*    */   
/*    */   public int getModifiers() {
/* 42 */     return this.modifiers;
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\env\ModuleReferenceImpl.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */