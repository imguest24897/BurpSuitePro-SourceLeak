/*      */ package org.eclipse.jdt.internal.compiler.ast;
/*      */ 
/*      */ import org.eclipse.jdt.core.compiler.CharOperation;
/*      */ import org.eclipse.jdt.internal.compiler.ASTVisitor;
/*      */ import org.eclipse.jdt.internal.compiler.impl.CompilerOptions;
/*      */ import org.eclipse.jdt.internal.compiler.lookup.Binding;
/*      */ import org.eclipse.jdt.internal.compiler.lookup.BlockScope;
/*      */ import org.eclipse.jdt.internal.compiler.lookup.ClassScope;
/*      */ import org.eclipse.jdt.internal.compiler.lookup.CompilationUnitScope;
/*      */ import org.eclipse.jdt.internal.compiler.lookup.ImportBinding;
/*      */ import org.eclipse.jdt.internal.compiler.lookup.LocalVariableBinding;
/*      */ import org.eclipse.jdt.internal.compiler.lookup.MethodBinding;
/*      */ import org.eclipse.jdt.internal.compiler.lookup.MethodScope;
/*      */ import org.eclipse.jdt.internal.compiler.lookup.ModuleBinding;
/*      */ import org.eclipse.jdt.internal.compiler.lookup.ModuleScope;
/*      */ import org.eclipse.jdt.internal.compiler.lookup.ReferenceBinding;
/*      */ import org.eclipse.jdt.internal.compiler.lookup.Scope;
/*      */ import org.eclipse.jdt.internal.compiler.lookup.TypeBinding;
/*      */ import org.eclipse.jdt.internal.compiler.lookup.TypeVariableBinding;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class Javadoc
/*      */   extends ASTNode
/*      */ {
/*      */   public JavadocSingleNameReference[] paramReferences;
/*      */   public JavadocSingleTypeReference[] paramTypeParameters;
/*      */   public TypeReference[] exceptionReferences;
/*      */   public JavadocReturnStatement returnStatement;
/*      */   public Expression[] seeReferences;
/*      */   public IJavadocTypeReference[] usesReferences;
/*      */   public IJavadocTypeReference[] providesReferences;
/*   38 */   public long[] inheritedPositions = null;
/*      */ 
/*      */   
/*      */   public JavadocSingleNameReference[] invalidParameters;
/*      */ 
/*      */   
/*   44 */   public long valuePositions = -1L;
/*      */   
/*      */   public Javadoc(int sourceStart, int sourceEnd) {
/*   47 */     this.sourceStart = sourceStart;
/*   48 */     this.sourceEnd = sourceEnd;
/*   49 */     this.bits |= 0x10000;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   boolean canBeSeen(int visibility, int modifiers) {
/*   59 */     if (modifiers < 0) return true; 
/*   60 */     switch (modifiers & 0x7) {
/*      */       case 1:
/*   62 */         return true;
/*      */       case 4:
/*   64 */         return (visibility != 1);
/*      */       case 0:
/*   66 */         return !(visibility != 0 && visibility != 2);
/*      */       case 2:
/*   68 */         return (visibility == 2);
/*      */     } 
/*   70 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ASTNode getNodeStartingAt(int start) {
/*   77 */     int length = 0;
/*      */     
/*   79 */     if (this.paramReferences != null) {
/*   80 */       length = this.paramReferences.length;
/*   81 */       for (int i = 0; i < length; i++) {
/*   82 */         JavadocSingleNameReference param = this.paramReferences[i];
/*   83 */         if (param.sourceStart == start) {
/*   84 */           return param;
/*      */         }
/*      */       } 
/*      */     } 
/*      */     
/*   89 */     if (this.invalidParameters != null) {
/*   90 */       length = this.invalidParameters.length;
/*   91 */       for (int i = 0; i < length; i++) {
/*   92 */         JavadocSingleNameReference param = this.invalidParameters[i];
/*   93 */         if (param.sourceStart == start) {
/*   94 */           return param;
/*      */         }
/*      */       } 
/*      */     } 
/*      */     
/*   99 */     if (this.paramTypeParameters != null) {
/*  100 */       length = this.paramTypeParameters.length;
/*  101 */       for (int i = 0; i < length; i++) {
/*  102 */         JavadocSingleTypeReference param = this.paramTypeParameters[i];
/*  103 */         if (param.sourceStart == start) {
/*  104 */           return param;
/*      */         }
/*      */       } 
/*      */     } 
/*      */     
/*  109 */     if (this.exceptionReferences != null) {
/*  110 */       length = this.exceptionReferences.length;
/*  111 */       for (int i = 0; i < length; i++) {
/*  112 */         TypeReference typeRef = this.exceptionReferences[i];
/*  113 */         if (typeRef.sourceStart == start) {
/*  114 */           return typeRef;
/*      */         }
/*      */       } 
/*      */     } 
/*      */     
/*  119 */     if (this.seeReferences != null) {
/*  120 */       length = this.seeReferences.length;
/*  121 */       for (int i = 0; i < length; i++) {
/*  122 */         Expression expression = this.seeReferences[i];
/*  123 */         if (expression.sourceStart == start)
/*  124 */           return expression; 
/*  125 */         if (expression instanceof JavadocAllocationExpression) {
/*  126 */           JavadocAllocationExpression allocationExpr = (JavadocAllocationExpression)this.seeReferences[i];
/*      */           
/*  128 */           if (allocationExpr.binding != null && allocationExpr.binding.isValidBinding() && 
/*  129 */             allocationExpr.arguments != null) {
/*  130 */             for (int j = 0, l = allocationExpr.arguments.length; j < l; j++) {
/*  131 */               if ((allocationExpr.arguments[j]).sourceStart == start) {
/*  132 */                 return allocationExpr.arguments[j];
/*      */               }
/*      */             }
/*      */           
/*      */           }
/*  137 */         } else if (expression instanceof JavadocMessageSend) {
/*  138 */           JavadocMessageSend messageSend = (JavadocMessageSend)this.seeReferences[i];
/*      */           
/*  140 */           if (messageSend.binding != null && messageSend.binding.isValidBinding() && 
/*  141 */             messageSend.arguments != null) {
/*  142 */             for (int j = 0, l = messageSend.arguments.length; j < l; j++) {
/*  143 */               if ((messageSend.arguments[j]).sourceStart == start) {
/*  144 */                 return messageSend.arguments[j];
/*      */               }
/*      */             }
/*      */           
/*      */           }
/*  149 */         } else if (expression instanceof JavadocModuleReference) {
/*  150 */           JavadocModuleReference modRef = (JavadocModuleReference)expression;
/*  151 */           if (modRef.typeReference != null && 
/*  152 */             modRef.typeReference.sourceStart == start) {
/*  153 */             return modRef.typeReference;
/*      */           }
/*      */         }
/*  156 */         else if (expression instanceof JavadocFieldReference) {
/*  157 */           JavadocFieldReference fieldRef = (JavadocFieldReference)expression;
/*  158 */           if (fieldRef.receiver instanceof JavadocModuleReference) {
/*  159 */             JavadocModuleReference modRef = (JavadocModuleReference)fieldRef.receiver;
/*  160 */             if (modRef.sourceStart == start) {
/*  161 */               return modRef;
/*      */             }
/*  163 */             if (modRef.typeReference != null && 
/*  164 */               modRef.typeReference.sourceStart == start) {
/*  165 */               return modRef.typeReference;
/*      */             }
/*      */           } 
/*      */         } 
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/*  173 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public StringBuffer print(int indent, StringBuffer output) {
/*  181 */     printIndent(indent, output).append("/**\n");
/*  182 */     if (this.paramReferences != null) {
/*  183 */       for (int i = 0, length = this.paramReferences.length; i < length; i++) {
/*  184 */         printIndent(indent + 1, output).append(" * @param ");
/*  185 */         this.paramReferences[i].print(indent, output).append('\n');
/*      */       } 
/*      */     }
/*  188 */     if (this.paramTypeParameters != null) {
/*  189 */       for (int i = 0, length = this.paramTypeParameters.length; i < length; i++) {
/*  190 */         printIndent(indent + 1, output).append(" * @param <");
/*  191 */         this.paramTypeParameters[i].print(indent, output).append(">\n");
/*      */       } 
/*      */     }
/*  194 */     if (this.returnStatement != null) {
/*  195 */       printIndent(indent + 1, output).append(" * @");
/*  196 */       this.returnStatement.print(indent, output).append('\n');
/*      */     } 
/*  198 */     if (this.exceptionReferences != null) {
/*  199 */       for (int i = 0, length = this.exceptionReferences.length; i < length; i++) {
/*  200 */         printIndent(indent + 1, output).append(" * @throws ");
/*  201 */         this.exceptionReferences[i].print(indent, output).append('\n');
/*      */       } 
/*      */     }
/*  204 */     if (this.seeReferences != null) {
/*  205 */       for (int i = 0, length = this.seeReferences.length; i < length; i++) {
/*  206 */         printIndent(indent + 1, output).append(" * @see ");
/*  207 */         this.seeReferences[i].print(indent, output).append('\n');
/*      */       } 
/*      */     }
/*  210 */     printIndent(indent, output).append(" */\n");
/*  211 */     return output;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void resolve(ClassScope scope) {
/*  218 */     if ((this.bits & 0x10000) == 0) {
/*      */       return;
/*      */     }
/*      */     
/*  222 */     this.bits &= 0xFFFEFFFF;
/*      */ 
/*      */ 
/*      */     
/*  226 */     if (this.inheritedPositions != null) {
/*  227 */       int length = this.inheritedPositions.length;
/*  228 */       for (int m = 0; m < length; m++) {
/*  229 */         int start = (int)(this.inheritedPositions[m] >>> 32L);
/*  230 */         int end = (int)this.inheritedPositions[m];
/*  231 */         scope.problemReporter().javadocUnexpectedTag(start, end);
/*      */       } 
/*      */     } 
/*      */     
/*  235 */     int paramTagsSize = (this.paramReferences == null) ? 0 : this.paramReferences.length;
/*  236 */     for (int i = 0; i < paramTagsSize && 
/*  237 */       scope.referenceContext.nRecordComponents <= 0; i++) {
/*      */ 
/*      */       
/*  240 */       JavadocSingleNameReference param = this.paramReferences[i];
/*  241 */       scope.problemReporter().javadocUnexpectedTag(param.tagSourceStart, param.tagSourceEnd);
/*      */     } 
/*  243 */     resolveTypeParameterTags((Scope)scope, true);
/*      */ 
/*      */     
/*  246 */     if (this.returnStatement != null) {
/*  247 */       scope.problemReporter().javadocUnexpectedTag(this.returnStatement.sourceStart, this.returnStatement.sourceEnd);
/*      */     }
/*      */ 
/*      */     
/*  251 */     int throwsTagsLength = (this.exceptionReferences == null) ? 0 : this.exceptionReferences.length;
/*  252 */     for (int j = 0; j < throwsTagsLength; j++) {
/*  253 */       int start, end; TypeReference typeRef = this.exceptionReferences[j];
/*      */       
/*  255 */       if (typeRef instanceof JavadocSingleTypeReference) {
/*  256 */         JavadocSingleTypeReference singleRef = (JavadocSingleTypeReference)typeRef;
/*  257 */         start = singleRef.tagSourceStart;
/*  258 */         end = singleRef.tagSourceEnd;
/*  259 */       } else if (typeRef instanceof JavadocQualifiedTypeReference) {
/*  260 */         JavadocQualifiedTypeReference qualifiedRef = (JavadocQualifiedTypeReference)typeRef;
/*  261 */         start = qualifiedRef.tagSourceStart;
/*  262 */         end = qualifiedRef.tagSourceEnd;
/*      */       } else {
/*  264 */         start = typeRef.sourceStart;
/*  265 */         end = typeRef.sourceEnd;
/*      */       } 
/*  267 */       scope.problemReporter().javadocUnexpectedTag(start, end);
/*      */     } 
/*      */ 
/*      */     
/*  271 */     int seeTagsLength = (this.seeReferences == null) ? 0 : this.seeReferences.length;
/*  272 */     for (int k = 0; k < seeTagsLength; k++) {
/*  273 */       resolveReference(this.seeReferences[k], (Scope)scope);
/*      */     }
/*      */ 
/*      */     
/*  277 */     boolean source15 = ((scope.compilerOptions()).sourceLevel >= 3211264L);
/*  278 */     if (!source15 && this.valuePositions != -1L) {
/*  279 */       scope.problemReporter().javadocUnexpectedTag((int)(this.valuePositions >>> 32L), (int)this.valuePositions);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void resolve(CompilationUnitScope unitScope) {
/*  287 */     if ((this.bits & 0x10000) == 0) {
/*      */       return;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void resolve(ModuleScope moduleScope) {
/*  299 */     if ((this.bits & 0x10000) == 0) {
/*      */       return;
/*      */     }
/*      */     
/*  303 */     this.bits &= 0xFFFEFFFF;
/*      */ 
/*      */     
/*  306 */     int seeTagsLength = (this.seeReferences == null) ? 0 : this.seeReferences.length;
/*  307 */     for (int i = 0; i < seeTagsLength; i++)
/*      */     {
/*  309 */       resolveReference(this.seeReferences[i], (Scope)moduleScope);
/*      */     }
/*      */     
/*  312 */     resolveUsesTags((BlockScope)moduleScope, true);
/*  313 */     resolveProvidesTags((BlockScope)moduleScope, true);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void resolve(MethodScope methScope) {
/*  320 */     if ((this.bits & 0x10000) == 0) {
/*      */       return;
/*      */     }
/*      */     
/*  324 */     this.bits &= 0xFFFEFFFF;
/*      */ 
/*      */     
/*  327 */     AbstractMethodDeclaration methDecl = methScope.referenceMethod();
/*  328 */     boolean overriding = (methDecl == null || methDecl.binding == null) ? false : (
/*      */       
/*  330 */       (!methDecl.binding.isStatic() && (methDecl.binding.modifiers & 0x30000000) != 0));
/*      */ 
/*      */     
/*  333 */     int seeTagsLength = (this.seeReferences == null) ? 0 : this.seeReferences.length;
/*  334 */     boolean superRef = false;
/*  335 */     for (int i = 0; i < seeTagsLength; i++) {
/*      */ 
/*      */       
/*  338 */       resolveReference(this.seeReferences[i], (Scope)methScope);
/*      */ 
/*      */       
/*  341 */       if (methDecl != null && !superRef) {
/*  342 */         if (!methDecl.isConstructor()) {
/*  343 */           if (overriding && this.seeReferences[i] instanceof JavadocMessageSend) {
/*  344 */             JavadocMessageSend messageSend = (JavadocMessageSend)this.seeReferences[i];
/*      */             
/*  346 */             if (messageSend.binding != null && messageSend.binding.isValidBinding() && messageSend.actualReceiverType instanceof ReferenceBinding) {
/*  347 */               ReferenceBinding methodReceiverType = (ReferenceBinding)messageSend.actualReceiverType;
/*  348 */               TypeBinding superType = methDecl.binding.declaringClass.findSuperTypeOriginatingFrom((TypeBinding)methodReceiverType);
/*  349 */               if (superType != null && TypeBinding.notEquals(superType.original(), (TypeBinding)methDecl.binding.declaringClass) && CharOperation.equals(messageSend.selector, methDecl.selector) && 
/*  350 */                 methScope.environment().methodVerifier().doesMethodOverride(methDecl.binding, messageSend.binding.original())) {
/*  351 */                 superRef = true;
/*      */               }
/*      */             }
/*      */           
/*      */           } 
/*  356 */         } else if (this.seeReferences[i] instanceof JavadocAllocationExpression) {
/*  357 */           JavadocAllocationExpression allocationExpr = (JavadocAllocationExpression)this.seeReferences[i];
/*      */           
/*  359 */           if (allocationExpr.binding != null && allocationExpr.binding.isValidBinding()) {
/*  360 */             ReferenceBinding allocType = (ReferenceBinding)allocationExpr.resolvedType.original();
/*  361 */             ReferenceBinding superType = (ReferenceBinding)methDecl.binding.declaringClass.findSuperTypeOriginatingFrom((TypeBinding)allocType);
/*  362 */             if (superType != null && TypeBinding.notEquals(superType.original(), (TypeBinding)methDecl.binding.declaringClass)) {
/*  363 */               MethodBinding superConstructor = methScope.getConstructor(superType, methDecl.binding.parameters, allocationExpr);
/*  364 */               if (superConstructor.isValidBinding() && superConstructor.original() == allocationExpr.binding.original()) {
/*  365 */                 MethodBinding current = methDecl.binding;
/*      */                 
/*  367 */                 if ((methScope.compilerOptions()).sourceLevel >= 3407872L && 
/*  368 */                   current.typeVariables != Binding.NO_TYPE_VARIABLES)
/*      */                 {
/*  370 */                   current = current.asRawMethod(methScope.environment());
/*      */                 }
/*  372 */                 if (superConstructor.areParametersEqual(current)) {
/*  373 */                   superRef = true;
/*      */                 }
/*      */               } 
/*      */             } 
/*      */           } 
/*      */         } 
/*      */       }
/*      */     } 
/*      */ 
/*      */     
/*  383 */     if (!superRef && methDecl != null && methDecl.annotations != null) {
/*  384 */       int k = methDecl.annotations.length;
/*  385 */       for (int m = 0; m < k && !superRef; m++) {
/*  386 */         superRef = ((methDecl.binding.tagBits & 0x2000000000000L) != 0L);
/*      */       }
/*      */     } 
/*      */ 
/*      */     
/*  391 */     boolean reportMissing = !(methDecl != null && ((overriding && this.inheritedPositions != null) || superRef || (methDecl.binding.declaringClass != null && methDecl.binding.declaringClass.isLocalType())));
/*  392 */     if (!overriding && this.inheritedPositions != null) {
/*  393 */       int k = this.inheritedPositions.length;
/*  394 */       for (int m = 0; m < k; m++) {
/*  395 */         int start = (int)(this.inheritedPositions[m] >>> 32L);
/*  396 */         int end = (int)this.inheritedPositions[m];
/*  397 */         methScope.problemReporter().javadocUnexpectedTag(start, end);
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/*  402 */     CompilerOptions compilerOptions = methScope.compilerOptions();
/*  403 */     resolveParamTags(methScope, reportMissing, compilerOptions.reportUnusedParameterIncludeDocCommentReference);
/*  404 */     resolveTypeParameterTags((Scope)methScope, (reportMissing && compilerOptions.reportMissingJavadocTagsMethodTypeParameters));
/*      */ 
/*      */     
/*  407 */     if (this.returnStatement == null) {
/*  408 */       if (reportMissing && methDecl != null && 
/*  409 */         methDecl.isMethod()) {
/*  410 */         MethodDeclaration meth = (MethodDeclaration)methDecl;
/*  411 */         if (meth.binding.returnType != TypeBinding.VOID)
/*      */         {
/*  413 */           methScope.problemReporter().javadocMissingReturnTag(meth.returnType.sourceStart, meth.returnType.sourceEnd, methDecl.binding.modifiers);
/*      */         }
/*      */       } 
/*      */     } else {
/*      */       
/*  418 */       this.returnStatement.resolve((BlockScope)methScope);
/*      */     } 
/*      */ 
/*      */     
/*  422 */     resolveThrowsTags(methScope, reportMissing);
/*      */ 
/*      */     
/*  425 */     boolean source15 = (compilerOptions.sourceLevel >= 3211264L);
/*  426 */     if (!source15 && methDecl != null && this.valuePositions != -1L) {
/*  427 */       methScope.problemReporter().javadocUnexpectedTag((int)(this.valuePositions >>> 32L), (int)this.valuePositions);
/*      */     }
/*      */ 
/*      */     
/*  431 */     int length = (this.invalidParameters == null) ? 0 : this.invalidParameters.length;
/*  432 */     for (int j = 0; j < length; j++) {
/*  433 */       this.invalidParameters[j].resolve((BlockScope)methScope, false, false);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private void resolveReference(Expression reference, Scope scope) {
/*  440 */     int problemCount = (scope.referenceContext().compilationResult()).problemCount;
/*  441 */     switch (scope.kind) {
/*      */       case 2:
/*  443 */         reference.resolveType((BlockScope)scope);
/*      */         break;
/*      */       case 3:
/*  446 */         reference.resolveType((ClassScope)scope);
/*      */         break;
/*      */     } 
/*  449 */     boolean hasProblems = ((scope.referenceContext().compilationResult()).problemCount > problemCount);
/*      */ 
/*      */     
/*  452 */     boolean source15 = ((scope.compilerOptions()).sourceLevel >= 3211264L);
/*  453 */     int scopeModifiers = -1;
/*  454 */     if (reference instanceof JavadocFieldReference) {
/*  455 */       JavadocFieldReference fieldRef = (JavadocFieldReference)reference;
/*      */ 
/*      */ 
/*      */       
/*  459 */       if (fieldRef.methodBinding != null) {
/*      */         
/*  461 */         if (fieldRef.tagValue == 10) {
/*  462 */           if (scopeModifiers == -1) scopeModifiers = scope.getDeclarationModifiers(); 
/*  463 */           scope.problemReporter().javadocInvalidValueReference(fieldRef.sourceStart, fieldRef.sourceEnd, scopeModifiers);
/*      */         }
/*  465 */         else if (fieldRef.actualReceiverType != null) {
/*  466 */           if (scope.kind != 5 && scope.enclosingSourceType().isCompatibleWith(fieldRef.actualReceiverType)) {
/*  467 */             fieldRef.bits |= 0x4000;
/*      */           }
/*  469 */           ReferenceBinding resolvedType = (ReferenceBinding)fieldRef.actualReceiverType;
/*  470 */           if (CharOperation.equals(resolvedType.sourceName(), fieldRef.token)) {
/*  471 */             fieldRef.methodBinding = scope.getConstructor(resolvedType, Binding.NO_TYPES, fieldRef);
/*      */           } else {
/*  473 */             fieldRef.methodBinding = scope.findMethod(resolvedType, fieldRef.token, Binding.NO_TYPES, fieldRef, false);
/*      */           }
/*      */         
/*      */         }
/*      */       
/*      */       }
/*  479 */       else if (source15 && fieldRef.binding != null && fieldRef.binding.isValidBinding() && 
/*  480 */         fieldRef.tagValue == 10 && !fieldRef.binding.isStatic()) {
/*  481 */         if (scopeModifiers == -1) scopeModifiers = scope.getDeclarationModifiers(); 
/*  482 */         scope.problemReporter().javadocInvalidValueReference(fieldRef.sourceStart, fieldRef.sourceEnd, scopeModifiers);
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/*  487 */       if (!hasProblems && fieldRef.binding != null && fieldRef.binding.isValidBinding() && fieldRef.actualReceiverType instanceof ReferenceBinding) {
/*  488 */         ReferenceBinding resolvedType = (ReferenceBinding)fieldRef.actualReceiverType;
/*  489 */         verifyTypeReference(fieldRef, fieldRef.receiver, scope, source15, resolvedType, fieldRef.binding.modifiers);
/*      */       } 
/*      */ 
/*      */       
/*      */       return;
/*      */     } 
/*      */ 
/*      */     
/*  497 */     if (!hasProblems && (reference instanceof JavadocSingleTypeReference || reference instanceof JavadocQualifiedTypeReference) && reference.resolvedType instanceof ReferenceBinding) {
/*  498 */       ReferenceBinding resolvedType = (ReferenceBinding)reference.resolvedType;
/*  499 */       verifyTypeReference(reference, reference, scope, source15, resolvedType, resolvedType.modifiers);
/*      */     } 
/*      */     
/*  502 */     if (!hasProblems && reference instanceof JavadocModuleReference) {
/*  503 */       JavadocModuleReference ref = (JavadocModuleReference)reference;
/*  504 */       ref.resolve(scope);
/*  505 */       ModuleReference mRef = ref.getModuleReference();
/*  506 */       if (mRef != null) {
/*  507 */         ModuleBinding mType = mRef.resolve(scope);
/*  508 */         if (mType != null && verifyModuleReference(reference, reference, scope, source15, mType, mType.modifiers)) {
/*  509 */           TypeReference tRef = ref.getTypeReference();
/*  510 */           if ((tRef instanceof JavadocSingleTypeReference || tRef instanceof JavadocQualifiedTypeReference) && tRef.resolvedType instanceof ReferenceBinding) {
/*  511 */             ReferenceBinding resolvedType = (ReferenceBinding)tRef.resolvedType;
/*  512 */             verifyTypeReference(reference, reference, scope, source15, resolvedType, resolvedType.modifiers);
/*      */           } 
/*      */         } 
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/*  519 */     if (reference instanceof JavadocMessageSend) {
/*  520 */       JavadocMessageSend msgSend = (JavadocMessageSend)reference;
/*      */ 
/*      */       
/*  523 */       if (source15 && msgSend.tagValue == 10) {
/*  524 */         if (scopeModifiers == -1) scopeModifiers = scope.getDeclarationModifiers(); 
/*  525 */         scope.problemReporter().javadocInvalidValueReference(msgSend.sourceStart, msgSend.sourceEnd, scopeModifiers);
/*      */       } 
/*      */ 
/*      */       
/*  529 */       if (!hasProblems && msgSend.binding != null && msgSend.binding.isValidBinding() && msgSend.actualReceiverType instanceof ReferenceBinding) {
/*  530 */         ReferenceBinding resolvedType = (ReferenceBinding)msgSend.actualReceiverType;
/*  531 */         verifyTypeReference(msgSend, msgSend.receiver, scope, source15, resolvedType, msgSend.binding.modifiers);
/*      */       
/*      */       }
/*      */     
/*      */     }
/*  536 */     else if (reference instanceof JavadocAllocationExpression) {
/*  537 */       JavadocAllocationExpression alloc = (JavadocAllocationExpression)reference;
/*      */ 
/*      */       
/*  540 */       if (source15 && alloc.tagValue == 10) {
/*  541 */         if (scopeModifiers == -1) scopeModifiers = scope.getDeclarationModifiers(); 
/*  542 */         scope.problemReporter().javadocInvalidValueReference(alloc.sourceStart, alloc.sourceEnd, scopeModifiers);
/*      */       } 
/*      */ 
/*      */       
/*  546 */       if (!hasProblems && alloc.binding != null && alloc.binding.isValidBinding() && alloc.resolvedType instanceof ReferenceBinding) {
/*  547 */         ReferenceBinding resolvedType = (ReferenceBinding)alloc.resolvedType;
/*  548 */         verifyTypeReference(alloc, alloc.type, scope, source15, resolvedType, alloc.binding.modifiers);
/*      */       
/*      */       }
/*      */ 
/*      */     
/*      */     }
/*  554 */     else if (reference instanceof JavadocSingleTypeReference && reference.resolvedType != null && reference.resolvedType.isTypeVariable()) {
/*  555 */       scope.problemReporter().javadocInvalidReference(reference.sourceStart, reference.sourceEnd);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void resolveParamTags(MethodScope scope, boolean reportMissing, boolean considerParamRefAsUsage) {
/*  563 */     AbstractMethodDeclaration methodDecl = scope.referenceMethod();
/*  564 */     int paramTagsSize = (this.paramReferences == null) ? 0 : this.paramReferences.length;
/*      */ 
/*      */     
/*  567 */     if (methodDecl == null) {
/*  568 */       for (int i = 0; i < paramTagsSize; i++) {
/*  569 */         JavadocSingleNameReference param = this.paramReferences[i];
/*  570 */         scope.problemReporter().javadocUnexpectedTag(param.tagSourceStart, param.tagSourceEnd);
/*      */       } 
/*      */       
/*      */       return;
/*      */     } 
/*      */     
/*  576 */     int argumentsSize = (methodDecl.arguments == null) ? 0 : methodDecl.arguments.length;
/*  577 */     if (paramTagsSize == 0) {
/*  578 */       if (reportMissing) {
/*  579 */         for (int i = 0; i < argumentsSize; i++) {
/*  580 */           Argument arg = methodDecl.arguments[i];
/*  581 */           scope.problemReporter().javadocMissingParamTag(arg.name, arg.sourceStart, arg.sourceEnd, methodDecl.binding.modifiers);
/*      */         } 
/*      */       }
/*      */     } else {
/*  585 */       LocalVariableBinding[] bindings = new LocalVariableBinding[paramTagsSize];
/*  586 */       int maxBindings = 0;
/*      */       
/*      */       int i;
/*  589 */       for (i = 0; i < paramTagsSize; i++) {
/*  590 */         JavadocSingleNameReference param = this.paramReferences[i];
/*  591 */         param.resolve((BlockScope)scope, true, considerParamRefAsUsage);
/*  592 */         if (param.binding != null && param.binding.isValidBinding()) {
/*      */           
/*  594 */           boolean found = false;
/*  595 */           for (int j = 0; j < maxBindings && !found; j++) {
/*  596 */             if (bindings[j] == param.binding) {
/*  597 */               scope.problemReporter().javadocDuplicatedParamTag(param.token, param.sourceStart, param.sourceEnd, methodDecl.binding.modifiers);
/*  598 */               found = true;
/*      */             } 
/*      */           } 
/*  601 */           if (!found) {
/*  602 */             bindings[maxBindings++] = (LocalVariableBinding)param.binding;
/*      */           }
/*      */         } 
/*      */       } 
/*      */ 
/*      */       
/*  608 */       if (reportMissing) {
/*  609 */         for (i = 0; i < argumentsSize; i++) {
/*  610 */           Argument arg = methodDecl.arguments[i];
/*  611 */           boolean found = false;
/*  612 */           for (int j = 0; j < maxBindings; j++) {
/*  613 */             LocalVariableBinding binding = bindings[j];
/*  614 */             if (arg.binding == binding) {
/*  615 */               found = true;
/*      */               break;
/*      */             } 
/*      */           } 
/*  619 */           if (!found) {
/*  620 */             scope.problemReporter().javadocMissingParamTag(arg.name, arg.sourceStart, arg.sourceEnd, methodDecl.binding.modifiers);
/*      */           }
/*      */         } 
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void resolveUsesTags(BlockScope scope, boolean reportMissing) {
/*  631 */     ModuleDeclaration moduleDecl = (ModuleDeclaration)scope.referenceContext();
/*  632 */     int usesTagsSize = (this.usesReferences == null) ? 0 : this.usesReferences.length;
/*      */ 
/*      */     
/*  635 */     if (moduleDecl == null) {
/*  636 */       for (int i = 0; i < usesTagsSize; i++) {
/*  637 */         IJavadocTypeReference uses = this.usesReferences[i];
/*  638 */         scope.problemReporter().javadocUnexpectedTag(uses.getTagSourceStart(), uses.getTagSourceEnd());
/*      */       } 
/*      */       
/*      */       return;
/*      */     } 
/*      */     
/*  644 */     int usesSize = moduleDecl.usesCount;
/*  645 */     if (usesTagsSize == 0) {
/*  646 */       if (reportMissing) {
/*  647 */         for (int i = 0; i < usesSize; i++) {
/*  648 */           UsesStatement uses = moduleDecl.uses[i];
/*  649 */           scope.problemReporter().javadocMissingUsesTag(uses.serviceInterface, uses.sourceStart, uses.sourceEnd, moduleDecl.binding.modifiers);
/*      */         } 
/*      */       }
/*      */     } else {
/*  653 */       TypeBinding[] bindings = new TypeBinding[usesTagsSize];
/*  654 */       int maxBindings = 0;
/*      */       
/*      */       int i;
/*  657 */       for (i = 0; i < usesTagsSize; i++) {
/*  658 */         TypeReference usesRef = (TypeReference)this.usesReferences[i];
/*      */         try {
/*  660 */           usesRef.resolve(scope);
/*  661 */           if (usesRef.resolvedType != null && usesRef.resolvedType.isValidBinding()) {
/*      */             
/*  663 */             boolean found = false;
/*  664 */             for (int j = 0; j < maxBindings && !found; j++) {
/*  665 */               if (bindings[j].equals(usesRef.resolvedType)) {
/*  666 */                 scope.problemReporter().javadocDuplicatedUsesTag(usesRef.sourceStart, usesRef.sourceEnd);
/*  667 */                 found = true;
/*      */               } 
/*      */             } 
/*  670 */             if (!found) {
/*  671 */               bindings[maxBindings++] = usesRef.resolvedType;
/*      */             }
/*      */           } 
/*  674 */         } catch (Exception exception) {
/*  675 */           scope.problemReporter().javadocInvalidUsesClass(usesRef.sourceStart, usesRef.sourceEnd);
/*      */         } 
/*      */       } 
/*      */ 
/*      */       
/*  680 */       if (reportMissing) {
/*  681 */         for (i = 0; i < usesSize; i++) {
/*  682 */           UsesStatement uses = moduleDecl.uses[i];
/*  683 */           boolean found = false;
/*  684 */           for (int j = 0; j < maxBindings && !found; j++) {
/*  685 */             TypeBinding binding = bindings[j];
/*  686 */             if (uses.serviceInterface.getTypeBinding((Scope)scope).equals(binding)) {
/*  687 */               found = true;
/*      */             }
/*      */           } 
/*  690 */           if (!found) {
/*  691 */             scope.problemReporter().javadocMissingUsesTag(uses.serviceInterface, uses.sourceStart, uses.sourceEnd, moduleDecl.binding.modifiers);
/*      */           }
/*      */         } 
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void resolveProvidesTags(BlockScope scope, boolean reportMissing) {
/*  702 */     ModuleDeclaration moduleDecl = (ModuleDeclaration)scope.referenceContext();
/*  703 */     int providesTagsSize = (this.providesReferences == null) ? 0 : this.providesReferences.length;
/*      */ 
/*      */     
/*  706 */     if (moduleDecl == null) {
/*  707 */       for (int i = 0; i < providesTagsSize; i++) {
/*  708 */         IJavadocTypeReference provides = this.providesReferences[i];
/*  709 */         scope.problemReporter().javadocUnexpectedTag(provides.getTagSourceStart(), provides.getTagSourceEnd());
/*      */       } 
/*      */       
/*      */       return;
/*      */     } 
/*      */     
/*  715 */     int providesSize = moduleDecl.servicesCount;
/*  716 */     if (providesTagsSize == 0) {
/*  717 */       if (reportMissing) {
/*  718 */         for (int i = 0; i < providesSize; i++) {
/*  719 */           ProvidesStatement provides = moduleDecl.services[i];
/*  720 */           scope.problemReporter().javadocMissingProvidesTag(provides.serviceInterface, provides.sourceStart, provides.sourceEnd, moduleDecl.binding.modifiers);
/*      */         } 
/*      */       }
/*      */     } else {
/*  724 */       TypeBinding[] bindings = new TypeBinding[providesTagsSize];
/*  725 */       int maxBindings = 0;
/*      */       
/*      */       int i;
/*  728 */       for (i = 0; i < providesTagsSize; i++) {
/*  729 */         TypeReference providesRef = (TypeReference)this.providesReferences[i];
/*      */         try {
/*  731 */           providesRef.resolve(scope);
/*  732 */           if (providesRef.resolvedType != null && providesRef.resolvedType.isValidBinding()) {
/*      */             
/*  734 */             boolean found = false;
/*  735 */             for (int j = 0; j < maxBindings && !found; j++) {
/*  736 */               if (bindings[j].equals(providesRef.resolvedType)) {
/*  737 */                 scope.problemReporter().javadocDuplicatedProvidesTag(providesRef.sourceStart, providesRef.sourceEnd);
/*  738 */                 found = true;
/*      */               } 
/*      */             } 
/*  741 */             if (!found) {
/*  742 */               bindings[maxBindings++] = providesRef.resolvedType;
/*      */             }
/*      */           } 
/*  745 */         } catch (Exception exception) {
/*  746 */           scope.problemReporter().javadocInvalidProvidesClass(providesRef.sourceStart, providesRef.sourceEnd);
/*      */         } 
/*      */       } 
/*      */ 
/*      */       
/*  751 */       if (reportMissing) {
/*  752 */         for (i = 0; i < providesSize; i++) {
/*  753 */           ProvidesStatement provides = moduleDecl.services[i];
/*  754 */           boolean found = false;
/*  755 */           for (int j = 0; j < maxBindings && !found; j++) {
/*  756 */             TypeBinding binding = bindings[j];
/*  757 */             if (provides.serviceInterface.getTypeBinding((Scope)scope).equals(binding)) {
/*  758 */               found = true;
/*      */             }
/*      */           } 
/*  761 */           if (!found) {
/*  762 */             scope.problemReporter().javadocMissingProvidesTag(provides.serviceInterface, provides.sourceStart, provides.sourceEnd, moduleDecl.binding.modifiers);
/*      */           }
/*      */         } 
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   private void resolveTypeParameterTags(Scope scope, boolean reportMissing) {
/*      */     AbstractMethodDeclaration methodDeclaration;
/*      */     TypeDeclaration typeDeclaration;
/*  773 */     int paramTypeParamLength = (this.paramTypeParameters == null) ? 0 : this.paramTypeParameters.length;
/*  774 */     int paramReferencesLength = (this.paramReferences == null) ? 0 : this.paramReferences.length;
/*      */ 
/*      */     
/*  777 */     TypeParameter[] parameters = null;
/*  778 */     TypeVariableBinding[] typeVariables = null;
/*  779 */     RecordComponent[] recordParameters = null;
/*  780 */     int modifiers = -1;
/*  781 */     switch (scope.kind) {
/*      */       case 2:
/*  783 */         methodDeclaration = ((MethodScope)scope).referenceMethod();
/*      */         
/*  785 */         if (methodDeclaration == null) {
/*  786 */           for (int i = 0; i < paramTypeParamLength; i++) {
/*  787 */             JavadocSingleTypeReference param = this.paramTypeParameters[i];
/*  788 */             scope.problemReporter().javadocUnexpectedTag(param.tagSourceStart, param.tagSourceEnd);
/*      */           } 
/*      */           return;
/*      */         } 
/*  792 */         parameters = methodDeclaration.typeParameters();
/*  793 */         typeVariables = methodDeclaration.binding.typeVariables;
/*  794 */         modifiers = methodDeclaration.binding.modifiers;
/*      */         break;
/*      */       case 3:
/*  797 */         typeDeclaration = ((ClassScope)scope).referenceContext;
/*  798 */         parameters = typeDeclaration.typeParameters;
/*  799 */         typeVariables = typeDeclaration.binding.typeVariables;
/*  800 */         modifiers = typeDeclaration.binding.modifiers;
/*  801 */         recordParameters = typeDeclaration.recordComponents;
/*      */         break;
/*      */     } 
/*      */ 
/*      */     
/*  806 */     if ((recordParameters == null || recordParameters.length == 0) && (
/*  807 */       typeVariables == null || typeVariables.length == 0)) {
/*  808 */       for (int i = 0; i < paramTypeParamLength; i++) {
/*  809 */         JavadocSingleTypeReference param = this.paramTypeParameters[i];
/*  810 */         scope.problemReporter().javadocUnexpectedTag(param.tagSourceStart, param.tagSourceEnd);
/*      */       } 
/*      */       
/*      */       return;
/*      */     } 
/*      */     
/*  816 */     if (recordParameters != null) {
/*  817 */       reportMissing = (reportMissing && (scope.compilerOptions()).sourceLevel >= 3211264L);
/*  818 */       int recordParametersLength = recordParameters.length;
/*  819 */       String[] argNames = new String[paramReferencesLength];
/*  820 */       if (paramReferencesLength == 0) {
/*  821 */         if (reportMissing) {
/*  822 */           for (int i = 0, l = recordParametersLength; i < l; i++) {
/*  823 */             scope.problemReporter().javadocMissingParamTag((recordParameters[i]).name, (recordParameters[i]).sourceStart, (recordParameters[i]).sourceEnd, modifiers);
/*      */           }
/*      */         }
/*      */       } else {
/*      */         int i;
/*      */         
/*  829 */         for (i = 0; i < paramReferencesLength; i++) {
/*  830 */           JavadocSingleNameReference param = this.paramReferences[i];
/*  831 */           String paramName = new String(param.getName()[0]);
/*      */           
/*  833 */           boolean duplicate = false;
/*  834 */           for (int j = 0; j < i && !duplicate; j++) {
/*  835 */             if (paramName.equals(argNames[j])) {
/*  836 */               scope.problemReporter().javadocDuplicatedParamTag(param.token, param.sourceStart, param.sourceEnd, modifiers);
/*  837 */               duplicate = true;
/*      */             } 
/*      */           } 
/*  840 */           if (!duplicate) {
/*  841 */             argNames[i] = paramName;
/*      */           }
/*      */         } 
/*      */         
/*  845 */         if (reportMissing) {
/*  846 */           for (i = 0; i < recordParameters.length; i++) {
/*  847 */             RecordComponent component = recordParameters[i];
/*  848 */             boolean found = false;
/*  849 */             for (int j = 0; j < paramReferencesLength && !found; j++) {
/*  850 */               JavadocSingleNameReference param = this.paramReferences[j];
/*  851 */               String paramName = new String(param.getName()[0]);
/*  852 */               if (paramName.equals(new String(component.name))) {
/*  853 */                 found = true;
/*      */               }
/*      */             } 
/*  856 */             if (!found) {
/*  857 */               scope.problemReporter().javadocMissingParamTag(component.name, component.sourceStart, component.sourceEnd, modifiers);
/*      */             }
/*      */           } 
/*      */         }
/*      */         
/*  862 */         for (i = 0; i < paramReferencesLength; i++) {
/*  863 */           JavadocSingleNameReference param = this.paramReferences[i];
/*  864 */           String paramName = new String(param.getName()[0]);
/*  865 */           boolean found = false;
/*  866 */           for (int j = 0; j < recordParameters.length; j++) {
/*  867 */             RecordComponent component = recordParameters[j];
/*  868 */             if (paramName.equals(new String(component.name))) {
/*  869 */               found = true;
/*      */             }
/*      */           } 
/*  872 */           if (!found) {
/*  873 */             scope.problemReporter().javadocInvalidParamTagName(param.sourceStart, param.sourceEnd);
/*      */           }
/*      */         } 
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/*  880 */     if (parameters != null) {
/*      */       
/*  882 */       reportMissing = (reportMissing && (scope.compilerOptions()).sourceLevel >= 3211264L);
/*  883 */       int typeParametersLength = parameters.length;
/*  884 */       if (paramTypeParamLength == 0) {
/*  885 */         if (reportMissing) {
/*  886 */           for (int i = 0, l = typeParametersLength; i < l; i++) {
/*  887 */             scope.problemReporter().javadocMissingParamTag((parameters[i]).name, (parameters[i]).sourceStart, (parameters[i]).sourceEnd, modifiers);
/*      */           
/*      */           }
/*      */         }
/*      */       }
/*  892 */       else if (typeVariables.length == typeParametersLength) {
/*  893 */         TypeVariableBinding[] bindings = new TypeVariableBinding[paramTypeParamLength];
/*      */         
/*      */         int i;
/*  896 */         for (i = 0; i < paramTypeParamLength; i++) {
/*  897 */           JavadocSingleTypeReference param = this.paramTypeParameters[i];
/*  898 */           TypeBinding paramBindind = param.internalResolveType(scope, 0);
/*  899 */           if (paramBindind != null && paramBindind.isValidBinding()) {
/*  900 */             if (paramBindind.isTypeVariable()) {
/*      */               
/*  902 */               if ((scope.compilerOptions()).reportUnusedParameterIncludeDocCommentReference) {
/*  903 */                 TypeVariableBinding typeVariableBinding = (TypeVariableBinding)paramBindind;
/*  904 */                 typeVariableBinding.modifiers |= 0x8000000;
/*      */               } 
/*      */               
/*  907 */               boolean duplicate = false;
/*  908 */               for (int j = 0; j < i && !duplicate; j++) {
/*  909 */                 if (TypeBinding.equalsEquals((TypeBinding)bindings[j], param.resolvedType)) {
/*  910 */                   scope.problemReporter().javadocDuplicatedParamTag(param.token, param.sourceStart, param.sourceEnd, modifiers);
/*  911 */                   duplicate = true;
/*      */                 } 
/*      */               } 
/*  914 */               if (!duplicate) {
/*  915 */                 bindings[i] = (TypeVariableBinding)param.resolvedType;
/*      */               }
/*      */             } else {
/*  918 */               scope.problemReporter().javadocUndeclaredParamTagName(param.token, param.sourceStart, param.sourceEnd, modifiers);
/*      */             } 
/*      */           }
/*      */         } 
/*      */ 
/*      */         
/*  924 */         for (i = 0; i < typeParametersLength; i++) {
/*  925 */           TypeParameter parameter = parameters[i];
/*  926 */           boolean found = false;
/*  927 */           for (int j = 0; j < paramTypeParamLength && !found; j++) {
/*  928 */             if (TypeBinding.equalsEquals((TypeBinding)parameter.binding, (TypeBinding)bindings[j])) {
/*  929 */               found = true;
/*  930 */               bindings[j] = null;
/*      */             } 
/*      */           } 
/*  933 */           if (!found && reportMissing) {
/*  934 */             scope.problemReporter().javadocMissingParamTag(parameter.name, parameter.sourceStart, parameter.sourceEnd, modifiers);
/*      */           }
/*      */         } 
/*      */ 
/*      */         
/*  939 */         for (i = 0; i < paramTypeParamLength; i++) {
/*  940 */           if (bindings[i] != null) {
/*  941 */             JavadocSingleTypeReference param = this.paramTypeParameters[i];
/*  942 */             scope.problemReporter().javadocUndeclaredParamTagName(param.token, param.sourceStart, param.sourceEnd, modifiers);
/*      */           } 
/*      */         } 
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void resolveThrowsTags(MethodScope methScope, boolean reportMissing) {
/*  953 */     AbstractMethodDeclaration md = methScope.referenceMethod();
/*  954 */     int throwsTagsLength = (this.exceptionReferences == null) ? 0 : this.exceptionReferences.length;
/*      */ 
/*      */     
/*  957 */     if (md == null) {
/*  958 */       for (int i = 0; i < throwsTagsLength; i++) {
/*  959 */         TypeReference typeRef = this.exceptionReferences[i];
/*  960 */         int start = typeRef.sourceStart;
/*  961 */         int end = typeRef.sourceEnd;
/*  962 */         if (typeRef instanceof JavadocQualifiedTypeReference) {
/*  963 */           start = ((JavadocQualifiedTypeReference)typeRef).tagSourceStart;
/*  964 */           end = ((JavadocQualifiedTypeReference)typeRef).tagSourceEnd;
/*  965 */         } else if (typeRef instanceof JavadocSingleTypeReference) {
/*  966 */           start = ((JavadocSingleTypeReference)typeRef).tagSourceStart;
/*  967 */           end = ((JavadocSingleTypeReference)typeRef).tagSourceEnd;
/*      */         } 
/*  969 */         methScope.problemReporter().javadocUnexpectedTag(start, end);
/*      */       } 
/*      */       
/*      */       return;
/*      */     } 
/*      */     
/*  975 */     int boundExceptionLength = (md.binding == null) ? 0 : md.binding.thrownExceptions.length;
/*  976 */     int thrownExceptionLength = (md.thrownExceptions == null) ? 0 : md.thrownExceptions.length;
/*  977 */     if (throwsTagsLength == 0) {
/*  978 */       if (reportMissing) {
/*  979 */         for (int i = 0; i < boundExceptionLength; i++) {
/*  980 */           ReferenceBinding exceptionBinding = md.binding.thrownExceptions[i];
/*  981 */           if (exceptionBinding != null && exceptionBinding.isValidBinding()) {
/*  982 */             int j = i;
/*  983 */             for (; j < thrownExceptionLength && TypeBinding.notEquals((TypeBinding)exceptionBinding, (md.thrownExceptions[j]).resolvedType); j++);
/*  984 */             if (j < thrownExceptionLength) {
/*  985 */               methScope.problemReporter().javadocMissingThrowsTag(md.thrownExceptions[j], md.binding.modifiers);
/*      */             }
/*      */           } 
/*      */         } 
/*      */       }
/*      */     } else {
/*  991 */       int maxRef = 0;
/*  992 */       TypeReference[] typeReferences = new TypeReference[throwsTagsLength];
/*      */       
/*      */       int i;
/*  995 */       for (i = 0; i < throwsTagsLength; i++) {
/*  996 */         TypeReference typeRef = this.exceptionReferences[i];
/*  997 */         typeRef.resolve((BlockScope)methScope);
/*  998 */         TypeBinding typeBinding = typeRef.resolvedType;
/*      */         
/* 1000 */         if (typeBinding != null && typeBinding.isValidBinding() && typeBinding.isClass())
/*      */         {
/* 1002 */           typeReferences[maxRef++] = typeRef;
/*      */         }
/*      */       } 
/*      */ 
/*      */       
/* 1007 */       for (i = 0; i < boundExceptionLength; i++) {
/* 1008 */         ReferenceBinding exceptionBinding = md.binding.thrownExceptions[i];
/* 1009 */         if (exceptionBinding != null) exceptionBinding = (ReferenceBinding)exceptionBinding.erasure(); 
/* 1010 */         boolean found = false;
/* 1011 */         for (int j = 0; j < maxRef && !found; j++) {
/* 1012 */           if (typeReferences[j] != null) {
/* 1013 */             TypeBinding typeBinding = (typeReferences[j]).resolvedType;
/* 1014 */             if (TypeBinding.equalsEquals((TypeBinding)exceptionBinding, typeBinding)) {
/* 1015 */               found = true;
/* 1016 */               typeReferences[j] = null;
/*      */             } 
/*      */           } 
/*      */         } 
/* 1020 */         if (!found && reportMissing && 
/* 1021 */           exceptionBinding != null && exceptionBinding.isValidBinding()) {
/* 1022 */           int k = i;
/* 1023 */           for (; k < thrownExceptionLength && TypeBinding.notEquals((TypeBinding)exceptionBinding, (md.thrownExceptions[k]).resolvedType); k++);
/* 1024 */           if (k < thrownExceptionLength) {
/* 1025 */             methScope.problemReporter().javadocMissingThrowsTag(md.thrownExceptions[k], md.binding.modifiers);
/*      */           }
/*      */         } 
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/* 1032 */       for (i = 0; i < maxRef; i++) {
/* 1033 */         TypeReference typeRef = typeReferences[i];
/* 1034 */         if (typeRef != null) {
/* 1035 */           boolean compatible = false;
/*      */           
/* 1037 */           for (int j = 0; j < thrownExceptionLength && !compatible; j++) {
/* 1038 */             TypeBinding exceptionBinding = (md.thrownExceptions[j]).resolvedType;
/* 1039 */             if (exceptionBinding != null) {
/* 1040 */               compatible = typeRef.resolvedType.isCompatibleWith(exceptionBinding);
/*      */             }
/*      */           } 
/*      */ 
/*      */           
/* 1045 */           if (!compatible && !typeRef.resolvedType.isUncheckedException(false)) {
/* 1046 */             methScope.problemReporter().javadocInvalidThrowsClassName(typeRef, md.binding.modifiers);
/*      */           }
/*      */         } 
/*      */       } 
/*      */     } 
/*      */   }
/*      */   
/*      */   private void verifyTypeReference(Expression reference, Expression typeReference, Scope scope, boolean source15, ReferenceBinding resolvedType, int modifiers) {
/* 1054 */     if (resolvedType.isValidBinding()) {
/* 1055 */       int scopeModifiers = -1;
/*      */ 
/*      */       
/* 1058 */       if (!canBeSeen((scope.problemReporter()).options.reportInvalidJavadocTagsVisibility, modifiers)) {
/* 1059 */         scope.problemReporter().javadocHiddenReference(typeReference.sourceStart, reference.sourceEnd, scope, modifiers);
/*      */         
/*      */         return;
/*      */       } 
/*      */       
/* 1064 */       if (reference != typeReference && 
/* 1065 */         !canBeSeen((scope.problemReporter()).options.reportInvalidJavadocTagsVisibility, resolvedType.modifiers)) {
/* 1066 */         scope.problemReporter().javadocHiddenReference(typeReference.sourceStart, typeReference.sourceEnd, scope, resolvedType.modifiers);
/*      */ 
/*      */         
/*      */         return;
/*      */       } 
/*      */       
/* 1072 */       if (resolvedType.isMemberType()) {
/* 1073 */         ReferenceBinding topLevelType = resolvedType;
/*      */         
/* 1075 */         int packageLength = topLevelType.fPackage.compoundName.length;
/* 1076 */         int depth = resolvedType.depth();
/* 1077 */         int idx = depth + packageLength;
/* 1078 */         char[][] computedCompoundName = new char[idx + 1][];
/* 1079 */         computedCompoundName[idx] = topLevelType.sourceName;
/* 1080 */         while (topLevelType.enclosingType() != null) {
/* 1081 */           topLevelType = topLevelType.enclosingType();
/* 1082 */           computedCompoundName[--idx] = topLevelType.sourceName;
/*      */         } 
/*      */ 
/*      */         
/* 1086 */         for (int i = packageLength; --i >= 0;) {
/* 1087 */           computedCompoundName[--idx] = topLevelType.fPackage.compoundName[i];
/*      */         }
/*      */         
/* 1090 */         if (scope.kind != 5) {
/* 1091 */           ClassScope topLevelScope = scope.classScope();
/*      */           
/* 1093 */           if (topLevelScope.parent.kind != 4 || 
/* 1094 */             !CharOperation.equals(topLevelType.sourceName, topLevelScope.referenceContext.name)) {
/* 1095 */             topLevelScope = topLevelScope.outerMostClassScope();
/* 1096 */             if (typeReference instanceof JavadocSingleTypeReference)
/*      */             {
/* 1098 */               if ((!source15 && depth == 1) || TypeBinding.notEquals((TypeBinding)topLevelType, (TypeBinding)topLevelScope.referenceContext.binding)) {
/*      */                 
/* 1100 */                 boolean hasValidImport = false;
/* 1101 */                 if (source15) {
/* 1102 */                   CompilationUnitScope unitScope = topLevelScope.compilationUnitScope();
/* 1103 */                   ImportBinding[] imports = unitScope.imports;
/* 1104 */                   int length = (imports == null) ? 0 : imports.length; int j;
/* 1105 */                   label94: for (j = 0; j < length; j++) {
/* 1106 */                     char[][] compoundName = (imports[j]).compoundName;
/* 1107 */                     int compoundNameLength = compoundName.length;
/* 1108 */                     if (((imports[j]).onDemand && compoundNameLength == computedCompoundName.length - 1) || 
/* 1109 */                       compoundNameLength == computedCompoundName.length) {
/* 1110 */                       for (int k = compoundNameLength; --k >= 0 && 
/* 1111 */                         CharOperation.equals((imports[j]).compoundName[k], computedCompoundName[k]);) {
/* 1112 */                         if (k == 0) {
/* 1113 */                           hasValidImport = true;
/* 1114 */                           ImportReference importReference = (imports[j]).reference;
/* 1115 */                           if (importReference != null) {
/* 1116 */                             importReference.bits |= 0x2;
/*      */                             
/*      */                             break label94;
/*      */                           } 
/*      */                           
/*      */                           break label94;
/*      */                         } 
/*      */                       } 
/*      */                     }
/*      */                   } 
/* 1126 */                   if (!hasValidImport) {
/* 1127 */                     if (scopeModifiers == -1) scopeModifiers = scope.getDeclarationModifiers(); 
/* 1128 */                     scope.problemReporter().javadocInvalidMemberTypeQualification(typeReference.sourceStart, typeReference.sourceEnd, scopeModifiers);
/*      */                   } 
/*      */                 } else {
/* 1131 */                   if (scopeModifiers == -1) scopeModifiers = scope.getDeclarationModifiers(); 
/* 1132 */                   scope.problemReporter().javadocInvalidMemberTypeQualification(typeReference.sourceStart, typeReference.sourceEnd, scopeModifiers);
/*      */                   return;
/*      */                 } 
/*      */               } 
/*      */             }
/*      */           } 
/* 1138 */           if (typeReference instanceof JavadocQualifiedTypeReference && !scope.isDefinedInSameUnit(resolvedType)) {
/*      */ 
/*      */             
/* 1141 */             char[][] typeRefName = ((JavadocQualifiedTypeReference)typeReference).getTypeName();
/* 1142 */             int skipLength = 0;
/* 1143 */             if (topLevelScope.getCurrentPackage() == resolvedType.getPackage() && 
/* 1144 */               typeRefName.length < computedCompoundName.length)
/*      */             {
/*      */               
/* 1147 */               skipLength = resolvedType.fPackage.compoundName.length;
/*      */             }
/* 1149 */             boolean valid = true;
/* 1150 */             if (typeRefName.length == computedCompoundName.length - skipLength) {
/* 1151 */               for (int j = 0; j < typeRefName.length; j++) {
/* 1152 */                 if (!CharOperation.equals(typeRefName[j], computedCompoundName[j + skipLength])) {
/* 1153 */                   valid = false;
/*      */                   break;
/*      */                 } 
/*      */               } 
/*      */             } else {
/* 1158 */               valid = false;
/*      */             } 
/*      */             
/* 1161 */             if (!valid) {
/* 1162 */               if (scopeModifiers == -1) scopeModifiers = scope.getDeclarationModifiers(); 
/* 1163 */               scope.problemReporter().javadocInvalidMemberTypeQualification(typeReference.sourceStart, typeReference.sourceEnd, scopeModifiers);
/*      */ 
/*      */ 
/*      */               
/*      */               return;
/*      */             } 
/*      */           } 
/*      */         } 
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/* 1175 */       if (scope.referenceCompilationUnit().isPackageInfo() && typeReference instanceof JavadocSingleTypeReference && 
/* 1176 */         resolvedType.fPackage.compoundName.length > 0) {
/* 1177 */         scope.problemReporter().javadocInvalidReference(typeReference.sourceStart, typeReference.sourceEnd);
/*      */         return;
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   private boolean verifyModuleReference(Expression reference, Expression typeReference, Scope scope, boolean source15, ModuleBinding moduleType, int modifiers) {
/* 1185 */     boolean bindingFound = false;
/* 1186 */     if (moduleType != null && moduleType.isValidBinding()) {
/* 1187 */       int scopeModifiers = -1;
/*      */       
/* 1189 */       ModuleBinding mBinding = scope.module();
/*      */       
/* 1191 */       if (mBinding == null) {
/* 1192 */         scope.problemReporter().javadocInvalidModuleQualification(typeReference.sourceStart, typeReference.sourceEnd, scopeModifiers);
/* 1193 */         return bindingFound;
/*      */       } 
/*      */       
/* 1196 */       if (mBinding.equals(moduleType)) {
/* 1197 */         bindingFound = true;
/*      */       } else {
/* 1199 */         ModuleBinding[] bindings = mBinding.getAllRequiredModules(); byte b; int i; ModuleBinding[] arrayOfModuleBinding1;
/* 1200 */         for (i = (arrayOfModuleBinding1 = bindings).length, b = 0; b < i; ) { ModuleBinding binding = arrayOfModuleBinding1[b];
/* 1201 */           if (moduleType.equals(binding)) {
/* 1202 */             bindingFound = true;
/*      */             break;
/*      */           } 
/*      */           b++; }
/*      */       
/*      */       } 
/* 1208 */       if (!bindingFound && 
/* 1209 */         !canBeSeen((scope.problemReporter()).options.reportInvalidJavadocTagsVisibility, moduleType.modifiers)) {
/* 1210 */         scope.problemReporter().javadocHiddenReference(typeReference.sourceStart, typeReference.sourceEnd, scope, moduleType.modifiers);
/* 1211 */         return bindingFound;
/*      */       } 
/*      */     } 
/*      */     
/* 1215 */     return bindingFound;
/*      */   }
/*      */ 
/*      */   
/*      */   public void traverse(ASTVisitor visitor, BlockScope scope) {
/* 1220 */     if (visitor.visit(this, scope)) {
/* 1221 */       if (this.paramReferences != null) {
/* 1222 */         for (int i = 0, length = this.paramReferences.length; i < length; i++) {
/* 1223 */           this.paramReferences[i].traverse(visitor, scope);
/*      */         }
/*      */       }
/* 1226 */       if (this.paramTypeParameters != null) {
/* 1227 */         for (int i = 0, length = this.paramTypeParameters.length; i < length; i++) {
/* 1228 */           this.paramTypeParameters[i].traverse(visitor, scope);
/*      */         }
/*      */       }
/* 1231 */       if (this.returnStatement != null) {
/* 1232 */         this.returnStatement.traverse(visitor, scope);
/*      */       }
/* 1234 */       if (this.exceptionReferences != null) {
/* 1235 */         for (int i = 0, length = this.exceptionReferences.length; i < length; i++) {
/* 1236 */           this.exceptionReferences[i].traverse(visitor, scope);
/*      */         }
/*      */       }
/* 1239 */       if (this.seeReferences != null) {
/* 1240 */         for (int i = 0, length = this.seeReferences.length; i < length; i++) {
/* 1241 */           this.seeReferences[i].traverse(visitor, scope);
/*      */         }
/*      */       }
/*      */     } 
/* 1245 */     visitor.endVisit(this, scope);
/*      */   }
/*      */   public void traverse(ASTVisitor visitor, ClassScope scope) {
/* 1248 */     if (visitor.visit(this, scope)) {
/* 1249 */       if (this.paramReferences != null) {
/* 1250 */         for (int i = 0, length = this.paramReferences.length; i < length; i++) {
/* 1251 */           this.paramReferences[i].traverse(visitor, scope);
/*      */         }
/*      */       }
/* 1254 */       if (this.paramTypeParameters != null) {
/* 1255 */         for (int i = 0, length = this.paramTypeParameters.length; i < length; i++) {
/* 1256 */           this.paramTypeParameters[i].traverse(visitor, scope);
/*      */         }
/*      */       }
/* 1259 */       if (this.returnStatement != null) {
/* 1260 */         this.returnStatement.traverse(visitor, scope);
/*      */       }
/* 1262 */       if (this.exceptionReferences != null) {
/* 1263 */         for (int i = 0, length = this.exceptionReferences.length; i < length; i++) {
/* 1264 */           this.exceptionReferences[i].traverse(visitor, scope);
/*      */         }
/*      */       }
/* 1267 */       if (this.seeReferences != null) {
/* 1268 */         for (int i = 0, length = this.seeReferences.length; i < length; i++) {
/* 1269 */           this.seeReferences[i].traverse(visitor, scope);
/*      */         }
/*      */       }
/*      */     } 
/* 1273 */     visitor.endVisit(this, scope);
/*      */   }
/*      */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\ast\Javadoc.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */