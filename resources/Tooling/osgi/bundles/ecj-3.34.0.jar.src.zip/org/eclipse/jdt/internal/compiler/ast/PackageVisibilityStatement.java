/*    */ package org.eclipse.jdt.internal.compiler.ast;
/*    */ 
/*    */ import org.eclipse.jdt.core.compiler.CharOperation;
/*    */ import org.eclipse.jdt.internal.compiler.lookup.PlainPackageBinding;
/*    */ import org.eclipse.jdt.internal.compiler.lookup.Scope;
/*    */ import org.eclipse.jdt.internal.compiler.lookup.SourceModuleBinding;
/*    */ import org.eclipse.jdt.internal.compiler.util.HashtableOfObject;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class PackageVisibilityStatement
/*    */   extends ModuleStatement
/*    */ {
/*    */   public ImportReference pkgRef;
/*    */   public ModuleReference[] targets;
/*    */   public char[] pkgName;
/*    */   public PlainPackageBinding resolvedPackage;
/*    */   
/*    */   public PackageVisibilityStatement(ImportReference pkgRef, ModuleReference[] targets) {
/* 32 */     this.pkgRef = pkgRef;
/* 33 */     this.pkgName = CharOperation.concatWith(this.pkgRef.tokens, '.');
/* 34 */     this.targets = targets;
/*    */   }
/*    */   public boolean isQualified() {
/* 37 */     return (this.targets != null && this.targets.length > 0);
/*    */   }
/*    */   
/*    */   public ModuleReference[] getTargetedModules() {
/* 41 */     return this.targets;
/*    */   }
/*    */   
/*    */   public boolean resolve(Scope scope) {
/* 45 */     boolean errorsExist = (resolvePackageReference(scope) == null);
/* 46 */     if (isQualified()) {
/* 47 */       HashtableOfObject modules = new HashtableOfObject(this.targets.length);
/* 48 */       for (int i = 0; i < this.targets.length; i++) {
/* 49 */         ModuleReference ref = this.targets[i];
/*    */         
/* 51 */         if (modules.containsKey(ref.moduleName)) {
/* 52 */           scope.problemReporter().duplicateModuleReference(8389922, ref);
/* 53 */           errorsExist = true;
/*    */         } else {
/* 55 */           modules.put(ref.moduleName, ref);
/*    */         } 
/*    */       } 
/*    */     } 
/* 59 */     return !errorsExist;
/*    */   }
/*    */   public int computeSeverity(int problemId) {
/* 62 */     return 1;
/*    */   }
/*    */   protected PlainPackageBinding resolvePackageReference(Scope scope) {
/* 65 */     if (this.resolvedPackage != null)
/* 66 */       return this.resolvedPackage; 
/* 67 */     ModuleDeclaration exportingModule = (scope.compilationUnitScope()).referenceContext.moduleDeclaration;
/* 68 */     SourceModuleBinding sourceModuleBinding = exportingModule.binding;
/* 69 */     this.resolvedPackage = (sourceModuleBinding != null) ? sourceModuleBinding.getOrCreateDeclaredPackage(this.pkgRef.tokens) : null;
/* 70 */     return this.resolvedPackage;
/*    */   }
/*    */ 
/*    */   
/*    */   public StringBuffer print(int indent, StringBuffer output) {
/* 75 */     this.pkgRef.print(indent, output);
/* 76 */     if (isQualified()) {
/* 77 */       output.append(" to ");
/* 78 */       for (int i = 0; i < this.targets.length; i++) {
/* 79 */         if (i > 0) output.append(", "); 
/* 80 */         this.targets[i].print(0, output);
/*    */       } 
/*    */     } 
/* 83 */     return output;
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\ast\PackageVisibilityStatement.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */