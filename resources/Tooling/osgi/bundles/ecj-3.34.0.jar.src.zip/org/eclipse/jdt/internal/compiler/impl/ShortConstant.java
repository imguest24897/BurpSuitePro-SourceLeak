/*    */ package org.eclipse.jdt.internal.compiler.impl;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ShortConstant
/*    */   extends Constant
/*    */ {
/*    */   private short value;
/*    */   
/*    */   public static Constant fromValue(short value) {
/* 21 */     return new ShortConstant(value);
/*    */   }
/*    */   
/*    */   private ShortConstant(short value) {
/* 25 */     this.value = value;
/*    */   }
/*    */ 
/*    */   
/*    */   public byte byteValue() {
/* 30 */     return (byte)this.value;
/*    */   }
/*    */ 
/*    */   
/*    */   public char charValue() {
/* 35 */     return (char)this.value;
/*    */   }
/*    */ 
/*    */   
/*    */   public double doubleValue() {
/* 40 */     return this.value;
/*    */   }
/*    */ 
/*    */   
/*    */   public float floatValue() {
/* 45 */     return this.value;
/*    */   }
/*    */ 
/*    */   
/*    */   public int intValue() {
/* 50 */     return this.value;
/*    */   }
/*    */ 
/*    */   
/*    */   public long longValue() {
/* 55 */     return this.value;
/*    */   }
/*    */ 
/*    */   
/*    */   public short shortValue() {
/* 60 */     return this.value;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public String stringValue() {
/* 66 */     return String.valueOf(this.value);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public String toString() {
/* 72 */     return "(short)" + this.value;
/*    */   }
/*    */ 
/*    */   
/*    */   public int typeID() {
/* 77 */     return 4;
/*    */   }
/*    */ 
/*    */   
/*    */   public int hashCode() {
/* 82 */     return this.value;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean equals(Object obj) {
/* 87 */     if (this == obj) {
/* 88 */       return true;
/*    */     }
/* 90 */     if (obj == null) {
/* 91 */       return false;
/*    */     }
/* 93 */     if (getClass() != obj.getClass()) {
/* 94 */       return false;
/*    */     }
/* 96 */     ShortConstant other = (ShortConstant)obj;
/* 97 */     return (this.value == other.value);
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\impl\ShortConstant.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */