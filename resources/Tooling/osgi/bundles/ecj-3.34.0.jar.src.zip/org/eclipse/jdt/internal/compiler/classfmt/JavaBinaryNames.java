/*    */ package org.eclipse.jdt.internal.compiler.classfmt;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class JavaBinaryNames
/*    */ {
/*    */   public static boolean isClinit(char[] selector) {
/*  8 */     return (selector[0] == '<' && selector.length == 8);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static boolean isConstructor(char[] selector) {
/* 15 */     return (selector[0] == '<' && selector.length == 6);
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\classfmt\JavaBinaryNames.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */