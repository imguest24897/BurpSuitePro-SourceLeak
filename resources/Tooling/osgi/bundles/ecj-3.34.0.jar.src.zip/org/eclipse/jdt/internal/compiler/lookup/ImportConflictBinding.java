/*    */ package org.eclipse.jdt.internal.compiler.lookup;
/*    */ 
/*    */ import org.eclipse.jdt.core.compiler.CharOperation;
/*    */ import org.eclipse.jdt.internal.compiler.ast.ImportReference;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ImportConflictBinding
/*    */   extends ImportBinding
/*    */ {
/*    */   public ReferenceBinding conflictingTypeBinding;
/*    */   
/*    */   public ImportConflictBinding(char[][] compoundName, Binding methodBinding, ReferenceBinding conflictingTypeBinding, ImportReference reference) {
/* 23 */     super(compoundName, false, methodBinding, reference);
/* 24 */     this.conflictingTypeBinding = conflictingTypeBinding;
/*    */   }
/*    */   
/*    */   public char[] readableName() {
/* 28 */     return CharOperation.concatWith(this.compoundName, '.');
/*    */   }
/*    */   
/*    */   public String toString() {
/* 32 */     return "method import : " + new String(readableName());
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\lookup\ImportConflictBinding.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */