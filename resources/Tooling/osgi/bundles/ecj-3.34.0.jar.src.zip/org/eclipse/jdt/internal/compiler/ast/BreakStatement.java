/*     */ package org.eclipse.jdt.internal.compiler.ast;
/*     */ 
/*     */ import org.eclipse.jdt.internal.compiler.ASTVisitor;
/*     */ import org.eclipse.jdt.internal.compiler.flow.FlowContext;
/*     */ import org.eclipse.jdt.internal.compiler.flow.FlowInfo;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.BlockScope;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BreakStatement
/*     */   extends BranchStatement
/*     */ {
/*     */   public boolean isSynthetic;
/*     */   
/*     */   public BreakStatement(char[] label, int sourceStart, int e) {
/*  26 */     super(label, sourceStart, e);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public FlowInfo analyseCode(BlockScope currentScope, FlowContext flowContext, FlowInfo flowInfo) {
/*  35 */     FlowContext targetContext = (this.label == null) ? 
/*  36 */       flowContext.getTargetContextForDefaultBreak() : 
/*  37 */       flowContext.getTargetContextForBreakLabel(this.label);
/*     */ 
/*     */     
/*  40 */     if (targetContext instanceof org.eclipse.jdt.internal.compiler.flow.SwitchFlowContext && 
/*  41 */       targetContext.associatedNode instanceof SwitchExpression) {
/*  42 */       currentScope.problemReporter().switchExpressionBreakNotAllowed(this);
/*     */     }
/*  44 */     if (targetContext == null) {
/*  45 */       if (this.label == null) {
/*  46 */         currentScope.problemReporter().invalidBreak(this);
/*     */       } else {
/*  48 */         currentScope.problemReporter().undefinedLabel(this);
/*     */       } 
/*  50 */       return flowInfo;
/*     */     } 
/*     */     
/*  53 */     targetContext.recordAbruptExit();
/*  54 */     targetContext.expireNullCheckedFieldInfo();
/*     */     
/*  56 */     this.initStateIndex = 
/*  57 */       currentScope.methodScope().recordInitializationStates(flowInfo);
/*     */     
/*  59 */     this.targetLabel = targetContext.breakLabel();
/*  60 */     FlowContext traversedContext = flowContext;
/*  61 */     int subCount = 0;
/*  62 */     this.subroutines = new SubRoutineStatement[5];
/*     */     
/*     */     do {
/*     */       SubRoutineStatement sub;
/*  66 */       if ((sub = traversedContext.subroutine()) != null) {
/*  67 */         if (subCount == this.subroutines.length) {
/*  68 */           System.arraycopy(this.subroutines, 0, this.subroutines = new SubRoutineStatement[subCount * 2], 0, subCount);
/*     */         }
/*  70 */         this.subroutines[subCount++] = sub;
/*  71 */         if (sub.isSubRoutineEscaping()) {
/*     */           break;
/*     */         }
/*     */       } 
/*  75 */       traversedContext.recordReturnFrom(flowInfo.unconditionalInits());
/*  76 */       traversedContext.recordBreakTo(targetContext);
/*     */       
/*  78 */       if (traversedContext instanceof org.eclipse.jdt.internal.compiler.flow.InsideSubRoutineFlowContext) {
/*  79 */         ASTNode node = traversedContext.associatedNode;
/*  80 */         if (node instanceof TryStatement) {
/*  81 */           TryStatement tryStatement = (TryStatement)node;
/*  82 */           flowInfo.addInitializationsFrom((FlowInfo)tryStatement.subRoutineInits);
/*     */         } 
/*  84 */       } else if (traversedContext == targetContext) {
/*     */         
/*  86 */         targetContext.recordBreakFrom(flowInfo);
/*     */         break;
/*     */       } 
/*  89 */     } while ((traversedContext = traversedContext.getLocalParent()) != null);
/*     */ 
/*     */     
/*  92 */     if (subCount != this.subroutines.length) {
/*  93 */       System.arraycopy(this.subroutines, 0, this.subroutines = new SubRoutineStatement[subCount], 0, subCount);
/*     */     }
/*  95 */     return (FlowInfo)FlowInfo.DEAD_END;
/*     */   }
/*     */ 
/*     */   
/*     */   public StringBuffer printStatement(int tab, StringBuffer output) {
/* 100 */     printIndent(tab, output).append("break");
/* 101 */     if (this.label != null) output.append(' ').append(this.label); 
/* 102 */     return output.append(';');
/*     */   }
/*     */ 
/*     */   
/*     */   public void traverse(ASTVisitor visitor, BlockScope blockscope) {
/* 107 */     visitor.visit(this, blockscope);
/* 108 */     visitor.endVisit(this, blockscope);
/*     */   }
/*     */   
/*     */   public boolean doesNotCompleteNormally() {
/* 112 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean canCompleteNormally() {
/* 117 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean doNotReportUnreachable() {
/* 123 */     return this.isSynthetic;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\ast\BreakStatement.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */