/*    */ package org.eclipse.jdt.internal.compiler.ast;
/*    */ 
/*    */ import org.eclipse.jdt.internal.compiler.ASTVisitor;
/*    */ import org.eclipse.jdt.internal.compiler.impl.Constant;
/*    */ import org.eclipse.jdt.internal.compiler.lookup.BlockScope;
/*    */ import org.eclipse.jdt.internal.compiler.lookup.ReferenceBinding;
/*    */ import org.eclipse.jdt.internal.compiler.lookup.TypeBinding;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SuperReference
/*    */   extends ThisReference
/*    */ {
/*    */   public SuperReference(int sourceStart, int sourceEnd) {
/* 28 */     super(sourceStart, sourceEnd);
/*    */   }
/*    */ 
/*    */   
/*    */   public static ExplicitConstructorCall implicitSuperConstructorCall() {
/* 33 */     return new ExplicitConstructorCall(1);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean isImplicitThis() {
/* 39 */     return false;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean isSuper() {
/* 45 */     return true;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean isUnqualifiedSuper() {
/* 50 */     return true;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean isThis() {
/* 56 */     return false;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public StringBuffer printExpression(int indent, StringBuffer output) {
/* 62 */     return output.append("super");
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public TypeBinding resolveType(BlockScope scope) {
/* 69 */     this.constant = Constant.NotAConstant;
/* 70 */     ReferenceBinding enclosingReceiverType = scope.enclosingReceiverType();
/* 71 */     if (!checkAccess(scope, enclosingReceiverType))
/* 72 */       return null; 
/* 73 */     if (enclosingReceiverType.id == 1) {
/* 74 */       scope.problemReporter().cannotUseSuperInJavaLangObject(this);
/* 75 */       return null;
/*    */     } 
/* 77 */     return this.resolvedType = (TypeBinding)enclosingReceiverType.superclass();
/*    */   }
/*    */ 
/*    */   
/*    */   public void traverse(ASTVisitor visitor, BlockScope blockScope) {
/* 82 */     visitor.visit(this, blockScope);
/* 83 */     visitor.endVisit(this, blockScope);
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\ast\SuperReference.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */