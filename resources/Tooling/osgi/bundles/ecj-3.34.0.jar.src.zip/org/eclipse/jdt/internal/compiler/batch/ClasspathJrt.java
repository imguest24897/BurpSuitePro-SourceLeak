/*     */ package org.eclipse.jdt.internal.compiler.batch;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.nio.file.FileVisitResult;
/*     */ import java.nio.file.Path;
/*     */ import java.nio.file.attribute.BasicFileAttributes;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import java.util.function.Function;
/*     */ import java.util.zip.ZipFile;
/*     */ import org.eclipse.jdt.core.compiler.CharOperation;
/*     */ import org.eclipse.jdt.internal.compiler.classfmt.ClassFileReader;
/*     */ import org.eclipse.jdt.internal.compiler.classfmt.ClassFormatException;
/*     */ import org.eclipse.jdt.internal.compiler.classfmt.ExternalAnnotationDecorator;
/*     */ import org.eclipse.jdt.internal.compiler.env.AccessRuleSet;
/*     */ import org.eclipse.jdt.internal.compiler.env.IBinaryModule;
/*     */ import org.eclipse.jdt.internal.compiler.env.IBinaryType;
/*     */ import org.eclipse.jdt.internal.compiler.env.IModule;
/*     */ import org.eclipse.jdt.internal.compiler.env.IMultiModuleEntry;
/*     */ import org.eclipse.jdt.internal.compiler.env.NameEnvironmentAnswer;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.BinaryTypeBinding;
/*     */ import org.eclipse.jdt.internal.compiler.util.JRTUtil;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ClasspathJrt
/*     */   extends ClasspathLocation
/*     */   implements IMultiModuleEntry
/*     */ {
/*     */   public File file;
/*     */   protected ZipFile annotationZipFile;
/*     */   protected boolean closeZipFileAtEnd;
/*  51 */   protected static Map<String, Map<String, IModule>> ModulesCache = new ConcurrentHashMap<>();
/*     */   
/*     */   public final Set<String> moduleNamesCache;
/*     */   
/*     */   protected List<String> annotationPaths;
/*     */   
/*     */   public ClasspathJrt(File file, boolean closeZipFileAtEnd, AccessRuleSet accessRuleSet, String destinationPath) {
/*  58 */     super(accessRuleSet, destinationPath);
/*  59 */     this.file = file;
/*  60 */     this.closeZipFileAtEnd = closeZipFileAtEnd;
/*  61 */     this.moduleNamesCache = new HashSet<>();
/*     */   }
/*     */ 
/*     */   
/*     */   public List fetchLinkedJars(FileSystem.ClasspathSectionProblemReporter problemReporter) {
/*  66 */     return null;
/*     */   }
/*     */   
/*     */   public char[][] getModulesDeclaringPackage(String qualifiedPackageName, String moduleName) {
/*  70 */     List<String> modules = JRTUtil.getModulesDeclaringPackage(this.file, qualifiedPackageName, moduleName);
/*  71 */     return CharOperation.toCharArrays(modules);
/*     */   }
/*     */   
/*     */   public boolean hasCompilationUnit(String qualifiedPackageName, String moduleName) {
/*  75 */     return JRTUtil.hasCompilationUnit(this.file, qualifiedPackageName, moduleName);
/*     */   }
/*     */   
/*     */   public NameEnvironmentAnswer findClass(char[] typeName, String qualifiedPackageName, String moduleName, String qualifiedBinaryFileName) {
/*  79 */     return findClass(typeName, qualifiedPackageName, moduleName, qualifiedBinaryFileName, false);
/*     */   }
/*     */   
/*     */   public NameEnvironmentAnswer findClass(char[] typeName, String qualifiedPackageName, String moduleName, String qualifiedBinaryFileName, boolean asBinaryOnly) {
/*  83 */     if (!isPackage(qualifiedPackageName, moduleName)) {
/*  84 */       return null;
/*     */     }
/*     */     try {
/*  87 */       ClassFileReader classFileReader = ClassFileReader.readFromModule(this.file, moduleName, qualifiedBinaryFileName, this.moduleNamesCache::contains);
/*     */       
/*  89 */       if (classFileReader != null) {
/*  90 */         IBinaryType iBinaryType = maybeDecorateForExternalAnnotations(qualifiedBinaryFileName, (IBinaryType)classFileReader);
/*  91 */         char[] answerModuleName = iBinaryType.getModule();
/*  92 */         if (answerModuleName == null && moduleName != null)
/*  93 */           answerModuleName = moduleName.toCharArray(); 
/*  94 */         return new NameEnvironmentAnswer(iBinaryType, fetchAccessRestriction(qualifiedBinaryFileName), answerModuleName);
/*     */       } 
/*  96 */     } catch (ClassFormatException|IOException classFormatException) {}
/*     */ 
/*     */     
/*  99 */     return null;
/*     */   }
/*     */   
/*     */   protected IBinaryType maybeDecorateForExternalAnnotations(String qualifiedBinaryFileName, IBinaryType reader) {
/*     */     IBinaryType iBinaryType;
/* 104 */     if (this.annotationPaths != null)
/* 105 */     { int extensionPos = qualifiedBinaryFileName.lastIndexOf('.');
/* 106 */       String qualifiedClassName = qualifiedBinaryFileName.substring(0, extensionPos);
/* 107 */       Iterator<String> iterator = this.annotationPaths.iterator(); while (true) { ExternalAnnotationDecorator externalAnnotationDecorator; if (!iterator.hasNext())
/*     */         
/*     */         { 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 122 */           externalAnnotationDecorator = new ExternalAnnotationDecorator(reader, null); break; }  String annotationPath = iterator.next(); try { if (this.annotationZipFile == null)
/*     */             this.annotationZipFile = ExternalAnnotationDecorator.getAnnotationZipFile(annotationPath, null);  iBinaryType = ExternalAnnotationDecorator.create((IBinaryType)externalAnnotationDecorator, annotationPath, qualifiedClassName, this.annotationZipFile); if (iBinaryType.getExternalAnnotationStatus() == BinaryTypeBinding.ExternalAnnotationStatus.TYPE_IS_ANNOTATED)
/* 124 */             break;  } catch (IOException iOException) {} }  }  return iBinaryType;
/*     */   }
/*     */   
/*     */   public boolean hasAnnotationFileFor(String qualifiedTypeName) {
/* 128 */     return false;
/*     */   }
/*     */   
/*     */   public char[][][] findTypeNames(final String qualifiedPackageName, final String moduleName) {
/* 132 */     if (!isPackage(qualifiedPackageName, moduleName))
/* 133 */       return null; 
/* 134 */     final char[] packageArray = qualifiedPackageName.toCharArray();
/* 135 */     final ArrayList answers = new ArrayList();
/*     */     
/*     */     try {
/* 138 */       JRTUtil.walkModuleImage(this.file, new JRTUtil.JrtFileVisitor<Path>()
/*     */           {
/*     */             public FileVisitResult visitPackage(Path dir, Path modPath, BasicFileAttributes attrs) throws IOException
/*     */             {
/* 142 */               if (qualifiedPackageName.startsWith(dir.toString())) {
/* 143 */                 return FileVisitResult.CONTINUE;
/*     */               }
/* 145 */               return FileVisitResult.SKIP_SUBTREE;
/*     */             }
/*     */ 
/*     */             
/*     */             public FileVisitResult visitFile(Path dir, Path modPath, BasicFileAttributes attrs) throws IOException {
/* 150 */               Path parent = dir.getParent();
/* 151 */               if (parent == null)
/* 152 */                 return FileVisitResult.CONTINUE; 
/* 153 */               if (!parent.toString().equals(qualifiedPackageName)) {
/* 154 */                 return FileVisitResult.CONTINUE;
/*     */               }
/* 156 */               String fileName = dir.getName(dir.getNameCount() - 1).toString();
/*     */               
/* 158 */               ClasspathJrt.this.addTypeName(answers, fileName, -1, packageArray);
/* 159 */               return FileVisitResult.CONTINUE;
/*     */             }
/*     */ 
/*     */             
/*     */             public FileVisitResult visitModule(Path p, String name) throws IOException {
/* 164 */               if (moduleName == null)
/* 165 */                 return FileVisitResult.CONTINUE; 
/* 166 */               if (!moduleName.equals(name)) {
/* 167 */                 return FileVisitResult.SKIP_SUBTREE;
/*     */               }
/* 169 */               return FileVisitResult.CONTINUE;
/*     */             }
/* 172 */           }7);
/* 173 */     } catch (IOException e) {
/* 174 */       String error = "Failed to find module " + moduleName + " defining package " + qualifiedPackageName + 
/* 175 */         " in " + this;
/* 176 */       if (JRTUtil.PROPAGATE_IO_ERRORS) {
/* 177 */         throw new IllegalStateException(error, e);
/*     */       }
/* 179 */       System.err.println(error);
/* 180 */       e.printStackTrace();
/*     */     } 
/*     */ 
/*     */     
/* 184 */     int size = answers.size();
/* 185 */     if (size != 0) {
/* 186 */       char[][][] result = new char[size][][];
/* 187 */       answers.toArray((Object[])result);
/* 188 */       return result;
/*     */     } 
/* 190 */     return null;
/*     */   }
/*     */   
/*     */   protected void addTypeName(ArrayList<char[][]> answers, String fileName, int last, char[] packageName) {
/* 194 */     int indexOfDot = fileName.lastIndexOf('.');
/* 195 */     if (indexOfDot != -1) {
/* 196 */       String typeName = fileName.substring(last + 1, indexOfDot);
/* 197 */       answers.add(
/* 198 */           CharOperation.arrayConcat(
/* 199 */             CharOperation.splitOn('/', packageName), 
/* 200 */             typeName.toCharArray()));
/*     */     } 
/*     */   }
/*     */   
/*     */   public void initialize() throws IOException {
/* 205 */     loadModules();
/*     */   }
/*     */   
/*     */   public void loadModules() {
/* 209 */     Map<String, IModule> cache = ModulesCache.computeIfAbsent(this.file.getPath(), key -> {
/*     */           HashMap<String, IModule> newCache = new HashMap<>();
/*     */ 
/*     */           
/*     */           try {
/*     */             JRTUtil.walkModuleImage(this.file, new JRTUtil.JrtFileVisitor<Path>()
/*     */                 {
/*     */                   public FileVisitResult visitPackage(Path dir, Path mod, BasicFileAttributes attrs) throws IOException
/*     */                   {
/* 218 */                     return FileVisitResult.CONTINUE;
/*     */                   }
/*     */ 
/*     */ 
/*     */                   
/*     */                   public FileVisitResult visitFile(Path f, Path mod, BasicFileAttributes attrs) throws IOException {
/* 224 */                     return FileVisitResult.CONTINUE;
/*     */                   }
/*     */ 
/*     */                   
/*     */                   public FileVisitResult visitModule(Path p, String name) throws IOException {
/*     */                     try {
/* 230 */                       ClasspathJrt.this.acceptModule(JRTUtil.getClassfile(ClasspathJrt.this.file, "module-info.class", name), newCache);
/* 231 */                     } catch (ClassFormatException e) {
/* 232 */                       throw new IOException(e);
/*     */                     } 
/* 234 */                     return FileVisitResult.SKIP_SUBTREE;
/*     */                   }
/*     */                 }4);
/*     */           }
/* 238 */           catch (IOException e) {
/*     */             String error = "Failed to walk modules for " + key;
/*     */             
/*     */             if (JRTUtil.PROPAGATE_IO_ERRORS) {
/*     */               throw new IllegalStateException(error, e);
/*     */             }
/*     */             System.err.println(error);
/*     */             e.printStackTrace();
/*     */             return null;
/*     */           } 
/*     */           return newCache.isEmpty() ? null : Collections.<String, IModule>unmodifiableMap(newCache);
/*     */         });
/* 250 */     this.moduleNamesCache.addAll(cache.keySet());
/*     */   }
/*     */   
/*     */   void acceptModule(ClassFileReader reader, Map<String, IModule> cache) {
/* 254 */     if (reader != null) {
/* 255 */       IBinaryModule iBinaryModule = reader.getModuleDeclaration();
/* 256 */       if (iBinaryModule != null) {
/* 257 */         cache.put(String.valueOf(iBinaryModule.name()), iBinaryModule);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public Collection<String> getModuleNames(Collection<String> limitModule, Function<String, IModule> getModule) {
/* 264 */     Map<String, IModule> cache = ModulesCache.get(this.file.getPath());
/* 265 */     return selectModules(cache.keySet(), limitModule, getModule);
/*     */   }
/*     */   
/*     */   protected <T> List<String> allModules(Iterable<T> allSystemModules, Function<T, String> getModuleName, Function<T, IModule> getModule) {
/* 269 */     List<String> result = new ArrayList<>();
/* 270 */     boolean hasJavaDotSE = false;
/* 271 */     for (T mod : allSystemModules) {
/* 272 */       String moduleName = getModuleName.apply(mod);
/* 273 */       if ("java.se".equals(moduleName)) {
/* 274 */         result.add(moduleName);
/* 275 */         hasJavaDotSE = true;
/*     */         break;
/*     */       } 
/*     */     } 
/* 279 */     for (T mod : allSystemModules) {
/* 280 */       String moduleName = getModuleName.apply(mod);
/* 281 */       boolean isJavaDotStart = moduleName.startsWith("java.");
/* 282 */       boolean isPotentialRoot = !isJavaDotStart;
/* 283 */       if (!hasJavaDotSE) {
/* 284 */         isPotentialRoot |= isJavaDotStart;
/*     */       }
/* 286 */       if (isPotentialRoot) {
/* 287 */         IModule m = getModule.apply(mod);
/* 288 */         if (m != null) {
/* 289 */           byte b; int i; IModule.IPackageExport[] arrayOfIPackageExport; for (i = (arrayOfIPackageExport = m.exports()).length, b = 0; b < i; ) { IModule.IPackageExport packageExport = arrayOfIPackageExport[b];
/* 290 */             if (!packageExport.isQualified()) {
/* 291 */               result.add(moduleName); break;
/*     */             } 
/*     */             b++; }
/*     */         
/*     */         } 
/*     */       } 
/*     */     } 
/* 298 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void reset() {
/* 345 */     if (this.closeZipFileAtEnd && 
/* 346 */       this.annotationZipFile != null) {
/*     */       try {
/* 348 */         this.annotationZipFile.close();
/* 349 */       } catch (IOException iOException) {}
/*     */ 
/*     */       
/* 352 */       this.annotationZipFile = null;
/*     */     } 
/*     */     
/* 355 */     if (this.annotationPaths != null)
/*     */     {
/* 357 */       this.annotationPaths = null;
/*     */     }
/*     */   }
/*     */   
/*     */   public String toString() {
/* 362 */     return "Classpath for JRT System " + this.file.getPath();
/*     */   }
/*     */   
/*     */   public char[] normalizedPath() {
/* 366 */     if (this.normalizedPath == null) {
/* 367 */       String path2 = getPath();
/* 368 */       char[] rawName = path2.toCharArray();
/* 369 */       if (File.separatorChar == '\\') {
/* 370 */         CharOperation.replace(rawName, '\\', '/');
/*     */       }
/* 372 */       this.normalizedPath = CharOperation.subarray(rawName, 0, CharOperation.lastIndexOf('.', rawName));
/*     */     } 
/* 374 */     return this.normalizedPath;
/*     */   }
/*     */   
/*     */   public String getPath() {
/* 378 */     if (this.path == null) {
/*     */       try {
/* 380 */         this.path = this.file.getCanonicalPath();
/* 381 */       } catch (IOException iOException) {
/*     */         
/* 383 */         this.path = this.file.getAbsolutePath();
/*     */       } 
/*     */     }
/* 386 */     return this.path;
/*     */   }
/*     */   
/*     */   public int getMode() {
/* 390 */     return 2;
/*     */   }
/*     */   
/*     */   public boolean hasModule() {
/* 394 */     return true;
/*     */   }
/*     */   
/*     */   public IModule getModule(char[] moduleName) {
/* 398 */     Map<String, IModule> modules = ModulesCache.get(this.file.getPath());
/* 399 */     if (modules != null) {
/* 400 */       return modules.get(String.valueOf(moduleName));
/*     */     }
/* 402 */     return null;
/*     */   }
/*     */   
/*     */   public boolean servesModule(char[] moduleName) {
/* 406 */     return (getModule(moduleName) != null);
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\batch\ClasspathJrt.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */