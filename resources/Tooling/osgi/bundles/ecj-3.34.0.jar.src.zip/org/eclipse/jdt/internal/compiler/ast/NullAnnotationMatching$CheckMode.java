/*    */ package org.eclipse.jdt.internal.compiler.ast;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum CheckMode
/*    */ {
/* 61 */   COMPATIBLE
/*    */   {
/*    */     boolean requiredNullableMatchesAll() {
/* 64 */       return true;
/*    */     }
/*    */   },
/* 67 */   EXACT,
/*    */   
/* 69 */   BOUND_CHECK,
/*    */   
/* 71 */   BOUND_SUPER_CHECK,
/*    */   
/* 73 */   OVERRIDE_RETURN
/*    */   {
/*    */     CheckMode toDetail() {
/* 76 */       return OVERRIDE;
/*    */     }
/*    */   },
/* 79 */   OVERRIDE
/*    */   {
/*    */     boolean requiredNullableMatchesAll() {
/* 82 */       return true;
/*    */     }
/*    */     CheckMode toDetail() {
/* 85 */       return OVERRIDE;
/*    */     }
/*    */   };
/*    */   
/*    */   boolean requiredNullableMatchesAll() {
/* 90 */     return false;
/*    */   }
/*    */   CheckMode toDetail() {
/* 93 */     return EXACT;
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\ast\NullAnnotationMatching$CheckMode.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */