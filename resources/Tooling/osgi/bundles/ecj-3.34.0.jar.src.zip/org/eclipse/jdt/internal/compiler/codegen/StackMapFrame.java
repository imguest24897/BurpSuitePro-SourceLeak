/*     */ package org.eclipse.jdt.internal.compiler.codegen;
/*     */ 
/*     */ import java.text.MessageFormat;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.Scope;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class StackMapFrame
/*     */ {
/*     */   public static final int USED = 1;
/*     */   public static final int SAME_FRAME = 0;
/*     */   public static final int CHOP_FRAME = 1;
/*     */   public static final int APPEND_FRAME = 2;
/*     */   public static final int SAME_FRAME_EXTENDED = 3;
/*     */   public static final int FULL_FRAME = 4;
/*     */   public static final int SAME_LOCALS_1_STACK_ITEMS = 5;
/*     */   public static final int SAME_LOCALS_1_STACK_ITEMS_EXTENDED = 6;
/*     */   public int pc;
/*     */   public int numberOfStackItems;
/*     */   private int numberOfLocals;
/*     */   public int localIndex;
/*     */   public VerificationTypeInfo[] locals;
/*     */   public VerificationTypeInfo[] stackItems;
/*  39 */   private int numberOfDifferentLocals = -1;
/*     */   public int tagBits;
/*     */   
/*     */   public StackMapFrame(int initialLocalSize) {
/*  43 */     this.locals = new VerificationTypeInfo[initialLocalSize];
/*  44 */     this.numberOfLocals = -1;
/*  45 */     this.numberOfDifferentLocals = -1;
/*     */   }
/*     */   
/*     */   public int getFrameType(StackMapFrame prevFrame) {
/*  49 */     int offsetDelta = getOffsetDelta(prevFrame);
/*  50 */     switch (this.numberOfStackItems) {
/*     */       case 0:
/*  52 */         switch (numberOfDifferentLocals(prevFrame)) {
/*     */           case 0:
/*  54 */             return (offsetDelta <= 63) ? 0 : 3;
/*     */           case 1:
/*     */           case 2:
/*     */           case 3:
/*  58 */             return 2;
/*     */           case -3:
/*     */           case -2:
/*     */           case -1:
/*  62 */             return 1;
/*     */         } 
/*     */         break;
/*     */       case 1:
/*  66 */         switch (numberOfDifferentLocals(prevFrame)) {
/*     */           case 0:
/*  68 */             return (offsetDelta <= 63) ? 5 : 6;
/*     */         }  break;
/*     */     } 
/*  71 */     return 4;
/*     */   }
/*     */   
/*     */   public void addLocal(int resolvedPosition, VerificationTypeInfo info) {
/*  75 */     if (this.locals == null) {
/*  76 */       this.locals = new VerificationTypeInfo[resolvedPosition + 1];
/*  77 */       this.locals[resolvedPosition] = info;
/*     */     } else {
/*  79 */       int length = this.locals.length;
/*  80 */       if (resolvedPosition >= length) {
/*  81 */         System.arraycopy(this.locals, 0, this.locals = new VerificationTypeInfo[resolvedPosition + 1], 0, 
/*  82 */             length);
/*     */       }
/*  84 */       this.locals[resolvedPosition] = info;
/*     */     } 
/*     */   }
/*     */   
/*     */   public void addStackItem(VerificationTypeInfo info) {
/*  89 */     if (info == null) {
/*  90 */       throw new IllegalArgumentException("info cannot be null");
/*     */     }
/*  92 */     if (this.stackItems == null) {
/*  93 */       this.stackItems = new VerificationTypeInfo[1];
/*  94 */       this.stackItems[0] = info;
/*  95 */       this.numberOfStackItems = 1;
/*     */     } else {
/*  97 */       int length = this.stackItems.length;
/*  98 */       if (this.numberOfStackItems == length) {
/*  99 */         System.arraycopy(this.stackItems, 0, this.stackItems = new VerificationTypeInfo[length + 1], 0, length);
/*     */       }
/* 101 */       this.stackItems[this.numberOfStackItems++] = info;
/*     */     } 
/*     */   }
/*     */   
/*     */   public StackMapFrame duplicate() {
/* 106 */     Map<VerificationTypeInfo, VerificationTypeInfo> cache = new HashMap<>();
/* 107 */     int length = this.locals.length;
/* 108 */     StackMapFrame result = new StackMapFrame(length);
/* 109 */     result.numberOfLocals = -1;
/* 110 */     result.numberOfDifferentLocals = -1;
/* 111 */     result.pc = this.pc;
/* 112 */     result.numberOfStackItems = this.numberOfStackItems;
/*     */     
/* 114 */     if (length != 0) {
/* 115 */       result.locals = new VerificationTypeInfo[length];
/* 116 */       for (int i = 0; i < length; i++) {
/* 117 */         VerificationTypeInfo verificationTypeInfo = this.locals[i];
/* 118 */         result.locals[i] = getCachedValue(cache, verificationTypeInfo);
/*     */       } 
/*     */     } 
/* 121 */     length = this.numberOfStackItems;
/* 122 */     if (length != 0) {
/* 123 */       result.stackItems = new VerificationTypeInfo[length];
/* 124 */       for (int i = 0; i < length; i++) {
/* 125 */         VerificationTypeInfo verificationTypeInfo = this.stackItems[i];
/* 126 */         result.stackItems[i] = getCachedValue(cache, verificationTypeInfo);
/*     */       } 
/*     */     } 
/* 129 */     return result;
/*     */   }
/*     */   
/*     */   private static VerificationTypeInfo getCachedValue(Map<VerificationTypeInfo, VerificationTypeInfo> cache, VerificationTypeInfo value) {
/* 133 */     VerificationTypeInfo cachedValue = value;
/* 134 */     if (value != null) {
/* 135 */       if (value.tag == 8 || value.tag == 6) {
/*     */         
/* 137 */         cachedValue = cache.get(value);
/* 138 */         if (cachedValue == null) {
/* 139 */           cachedValue = value.duplicate();
/* 140 */           cache.put(value, cachedValue);
/*     */         } 
/*     */       } else {
/* 143 */         cachedValue = value.duplicate();
/*     */       } 
/*     */     }
/* 146 */     return cachedValue;
/*     */   }
/*     */   public int numberOfDifferentLocals(StackMapFrame prevFrame) {
/* 149 */     if (this.numberOfDifferentLocals != -1)
/* 150 */       return this.numberOfDifferentLocals; 
/* 151 */     if (prevFrame == null) {
/* 152 */       this.numberOfDifferentLocals = 0;
/* 153 */       return 0;
/*     */     } 
/* 155 */     VerificationTypeInfo[] prevLocals = prevFrame.locals;
/* 156 */     VerificationTypeInfo[] currentLocals = this.locals;
/* 157 */     int prevLocalsLength = (prevLocals == null) ? 0 : prevLocals.length;
/* 158 */     int currentLocalsLength = (currentLocals == null) ? 0 : currentLocals.length;
/* 159 */     int prevNumberOfLocals = prevFrame.getNumberOfLocals();
/* 160 */     int currentNumberOfLocals = getNumberOfLocals();
/*     */     
/* 162 */     int result = 0;
/* 163 */     if (prevNumberOfLocals == 0) {
/* 164 */       if (currentNumberOfLocals != 0) {
/*     */         
/* 166 */         result = currentNumberOfLocals;
/* 167 */         int counter = 0;
/* 168 */         for (int i = 0; i < currentLocalsLength && counter < currentNumberOfLocals; i++) {
/* 169 */           if (currentLocals[i] != null) {
/* 170 */             switch (currentLocals[i].id()) {
/*     */               case 7:
/*     */               case 8:
/* 173 */                 i++; break;
/*     */             } 
/* 175 */             counter++;
/*     */           } else {
/* 177 */             result = Integer.MAX_VALUE;
/* 178 */             this.numberOfDifferentLocals = result;
/* 179 */             return result;
/*     */           } 
/*     */         } 
/*     */       } 
/* 183 */     } else if (currentNumberOfLocals == 0) {
/*     */       
/* 185 */       int counter = 0;
/* 186 */       result = -prevNumberOfLocals;
/* 187 */       for (int i = 0; i < prevLocalsLength && counter < prevNumberOfLocals; i++) {
/* 188 */         if (prevLocals[i] != null) {
/* 189 */           switch (prevLocals[i].id()) {
/*     */             case 7:
/*     */             case 8:
/* 192 */               i++; break;
/*     */           } 
/* 194 */           counter++;
/*     */         } else {
/* 196 */           result = Integer.MAX_VALUE;
/* 197 */           this.numberOfDifferentLocals = result;
/* 198 */           return result;
/*     */         } 
/*     */       } 
/*     */     } else {
/*     */       
/* 203 */       int indexInPrevLocals = 0;
/* 204 */       int indexInCurrentLocals = 0;
/* 205 */       int currentLocalsCounter = 0;
/* 206 */       int prevLocalsCounter = 0;
/* 207 */       for (; indexInCurrentLocals < currentLocalsLength && 
/* 208 */         currentLocalsCounter < currentNumberOfLocals; indexInCurrentLocals++) {
/* 209 */         VerificationTypeInfo currentLocal = currentLocals[indexInCurrentLocals];
/* 210 */         if (currentLocal != null) {
/* 211 */           currentLocalsCounter++;
/* 212 */           switch (currentLocal.id()) {
/*     */             case 7:
/*     */             case 8:
/* 215 */               indexInCurrentLocals++; break;
/*     */           } 
/*     */         } 
/* 218 */         if (indexInPrevLocals < prevLocalsLength && prevLocalsCounter < prevNumberOfLocals) {
/* 219 */           VerificationTypeInfo prevLocal = prevLocals[indexInPrevLocals];
/* 220 */           if (prevLocal != null) {
/* 221 */             prevLocalsCounter++;
/* 222 */             switch (prevLocal.id()) {
/*     */               case 7:
/*     */               case 8:
/* 225 */                 indexInPrevLocals++;
/*     */                 break;
/*     */             } 
/*     */           
/*     */           } 
/* 230 */           if (equals(prevLocal, currentLocal) && indexInPrevLocals == indexInCurrentLocals) {
/* 231 */             if (result != 0) {
/* 232 */               result = Integer.MAX_VALUE;
/* 233 */               this.numberOfDifferentLocals = result;
/* 234 */               return result;
/*     */             } 
/*     */           } else {
/*     */             
/* 238 */             result = Integer.MAX_VALUE;
/* 239 */             this.numberOfDifferentLocals = result;
/* 240 */             return result;
/*     */           } 
/* 242 */           indexInPrevLocals++;
/*     */         }
/*     */         else {
/*     */           
/* 246 */           if (currentLocal != null) {
/* 247 */             result++;
/*     */           } else {
/* 249 */             result = Integer.MAX_VALUE;
/* 250 */             this.numberOfDifferentLocals = result;
/* 251 */             return result;
/*     */           } 
/* 253 */           indexInCurrentLocals++; break;
/*     */         } 
/*     */       } 
/* 256 */       if (currentLocalsCounter < currentNumberOfLocals) {
/* 257 */         for (; indexInCurrentLocals < currentLocalsLength && 
/* 258 */           currentLocalsCounter < currentNumberOfLocals; indexInCurrentLocals++) {
/* 259 */           VerificationTypeInfo currentLocal = currentLocals[indexInCurrentLocals];
/* 260 */           if (currentLocal == null) {
/* 261 */             result = Integer.MAX_VALUE;
/* 262 */             this.numberOfDifferentLocals = result;
/* 263 */             return result;
/*     */           } 
/* 265 */           result++;
/* 266 */           currentLocalsCounter++;
/* 267 */           switch (currentLocal.id()) {
/*     */             case 7:
/*     */             case 8:
/* 270 */               indexInCurrentLocals++; break;
/*     */           } 
/*     */         } 
/* 273 */       } else if (prevLocalsCounter < prevNumberOfLocals) {
/* 274 */         result = -result;
/*     */         
/* 276 */         for (; indexInPrevLocals < prevLocalsLength && 
/* 277 */           prevLocalsCounter < prevNumberOfLocals; indexInPrevLocals++) {
/* 278 */           VerificationTypeInfo prevLocal = prevLocals[indexInPrevLocals];
/* 279 */           if (prevLocal == null) {
/* 280 */             result = Integer.MAX_VALUE;
/* 281 */             this.numberOfDifferentLocals = result;
/* 282 */             return result;
/*     */           } 
/* 284 */           result--;
/* 285 */           prevLocalsCounter++;
/* 286 */           switch (prevLocal.id()) {
/*     */             case 7:
/*     */             case 8:
/* 289 */               indexInPrevLocals++; break;
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/* 294 */     this.numberOfDifferentLocals = result;
/* 295 */     return result;
/*     */   }
/*     */   
/*     */   public int getNumberOfLocals() {
/* 299 */     if (this.numberOfLocals != -1) {
/* 300 */       return this.numberOfLocals;
/*     */     }
/* 302 */     int result = 0;
/* 303 */     int length = (this.locals == null) ? 0 : this.locals.length;
/* 304 */     for (int i = 0; i < length; i++) {
/* 305 */       if (this.locals[i] != null) {
/* 306 */         switch (this.locals[i].id()) {
/*     */           case 7:
/*     */           case 8:
/* 309 */             i++; break;
/*     */         } 
/* 311 */         result++;
/*     */       } 
/*     */     } 
/* 314 */     this.numberOfLocals = result;
/* 315 */     return result;
/*     */   }
/*     */   
/*     */   public int getOffsetDelta(StackMapFrame prevFrame) {
/* 319 */     if (prevFrame == null)
/* 320 */       return this.pc; 
/* 321 */     return (prevFrame.pc == -1) ? this.pc : (this.pc - prevFrame.pc - 1);
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 326 */     StringBuffer buffer = new StringBuffer();
/* 327 */     printFrame(buffer, this);
/* 328 */     return String.valueOf(buffer);
/*     */   }
/*     */   
/*     */   private void printFrame(StringBuffer buffer, StackMapFrame frame) {
/* 332 */     String pattern = "[pc : {0} locals: {1} stack items: {2}\nlocals: {3}\nstack: {4}\n]";
/* 333 */     int localsLength = (frame.locals == null) ? 0 : frame.locals.length;
/* 334 */     buffer.append(MessageFormat.format(pattern, 
/* 335 */           new Object[] { Integer.toString(frame.pc), Integer.toString(frame.getNumberOfLocals()), 
/* 336 */             Integer.toString(frame.numberOfStackItems), print(frame.locals, localsLength), 
/* 337 */             print(frame.stackItems, frame.numberOfStackItems) }));
/*     */   }
/*     */   
/*     */   private String print(VerificationTypeInfo[] infos, int length) {
/* 341 */     StringBuffer buffer = new StringBuffer();
/* 342 */     buffer.append('[');
/* 343 */     if (infos != null)
/* 344 */       for (int i = 0; i < length; i++) {
/* 345 */         if (i != 0)
/* 346 */           buffer.append(','); 
/* 347 */         VerificationTypeInfo verificationTypeInfo = infos[i];
/* 348 */         if (verificationTypeInfo == null) {
/* 349 */           buffer.append("top");
/*     */         } else {
/*     */           
/* 352 */           buffer.append(verificationTypeInfo);
/*     */         } 
/*     */       }  
/* 355 */     buffer.append(']');
/* 356 */     return String.valueOf(buffer);
/*     */   }
/*     */   
/*     */   public void putLocal(int resolvedPosition, VerificationTypeInfo info) {
/* 360 */     if (this.locals == null) {
/* 361 */       this.locals = new VerificationTypeInfo[resolvedPosition + 1];
/* 362 */       this.locals[resolvedPosition] = info;
/*     */     } else {
/* 364 */       int length = this.locals.length;
/* 365 */       if (resolvedPosition >= length) {
/* 366 */         System.arraycopy(this.locals, 0, this.locals = new VerificationTypeInfo[resolvedPosition + 1], 0, 
/* 367 */             length);
/*     */       }
/* 369 */       this.locals[resolvedPosition] = info;
/*     */     } 
/*     */   }
/*     */   
/*     */   public void replaceWithElementType() {
/* 374 */     VerificationTypeInfo info = this.stackItems[this.numberOfStackItems - 1];
/* 375 */     VerificationTypeInfo info2 = info.duplicate();
/* 376 */     info2.replaceWithElementType();
/* 377 */     this.stackItems[this.numberOfStackItems - 1] = info2;
/*     */   }
/*     */   
/*     */   public int getIndexOfDifferentLocals(int differentLocalsCount) {
/* 381 */     for (int i = this.locals.length - 1; i >= 0; i--) {
/* 382 */       VerificationTypeInfo currentLocal = this.locals[i];
/* 383 */       if (currentLocal != null) {
/*     */ 
/*     */ 
/*     */         
/* 387 */         differentLocalsCount--;
/*     */         
/* 389 */         if (differentLocalsCount == 0)
/* 390 */           return i; 
/*     */       } 
/*     */     } 
/* 393 */     return 0;
/*     */   }
/*     */   
/*     */   private static boolean equals(VerificationTypeInfo info, VerificationTypeInfo info2) {
/* 397 */     if (info == null) {
/* 398 */       return (info2 == null);
/*     */     }
/* 400 */     if (info2 == null)
/* 401 */       return false; 
/* 402 */     return info.equals(info2);
/*     */   }
/*     */   
/*     */   public StackMapFrame merge(StackMapFrame frame, Scope scope) {
/* 406 */     if (frame.pc == -1)
/*     */     {
/* 408 */       return this;
/*     */     }
/* 410 */     if (this.numberOfStackItems == frame.numberOfStackItems) {
/* 411 */       for (int i = 0, max = this.numberOfStackItems; i < max; i++) {
/* 412 */         this.stackItems[i] = this.stackItems[i].merge(frame.stackItems[i], scope);
/*     */       }
/*     */     }
/* 415 */     return this;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\codegen\StackMapFrame.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */