/*     */ package org.eclipse.jdt.internal.compiler.env;
/*     */ 
/*     */ import java.util.function.Consumer;
/*     */ import org.eclipse.jdt.core.compiler.CharOperation;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AddReads
/*     */   implements Consumer<IUpdatableModule>
/*     */ {
/*     */   char[] targetModule;
/*     */   
/*     */   public AddReads(char[] target) {
/*  94 */     this.targetModule = target;
/*     */   }
/*     */ 
/*     */   
/*     */   public void accept(IUpdatableModule t) {
/*  99 */     t.addReads(this.targetModule);
/*     */   }
/*     */   
/*     */   public char[] getTarget() {
/* 103 */     return this.targetModule;
/*     */   }
/*     */   
/*     */   public IUpdatableModule.UpdateKind getKind() {
/* 107 */     return IUpdatableModule.UpdateKind.MODULE;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object other) {
/* 112 */     if (this == other) return true; 
/* 113 */     if (!(other instanceof AddReads)) return false; 
/* 114 */     AddReads mu = (AddReads)other;
/* 115 */     return CharOperation.equals(this.targetModule, mu.targetModule);
/*     */   }
/*     */   
/*     */   public int hashCode() {
/* 119 */     return CharOperation.hashCode(this.targetModule);
/*     */   }
/*     */   
/*     */   public String toString() {
/* 123 */     return "add-read " + CharOperation.charToString(this.targetModule);
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\env\IUpdatableModule$AddReads.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */