/*     */ package org.eclipse.jdt.core;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.io.PrintWriter;
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Comparator;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.apache.tools.ant.BuildException;
/*     */ import org.apache.tools.ant.taskdefs.Javac;
/*     */ import org.apache.tools.ant.taskdefs.compilers.DefaultCompilerAdapter;
/*     */ import org.apache.tools.ant.types.Commandline;
/*     */ import org.apache.tools.ant.types.Path;
/*     */ import org.apache.tools.ant.util.JavaEnvUtils;
/*     */ import org.eclipse.jdt.core.compiler.CharOperation;
/*     */ import org.eclipse.jdt.internal.antadapter.AntAdapterMessages;
/*     */ import org.eclipse.jdt.internal.compiler.impl.CompilerOptions;
/*     */ import org.eclipse.jdt.internal.compiler.util.SuffixConstants;
/*     */ import org.eclipse.jdt.internal.compiler.util.Util;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JDTCompilerAdapter
/*     */   extends DefaultCompilerAdapter
/*     */ {
/*  58 */   private static final char[] SEPARATOR_CHARS = new char[] { '/', '\\' };
/*  59 */   private static final char[] ADAPTER_PREFIX = "#ADAPTER#".toCharArray();
/*  60 */   private static final char[] ADAPTER_ENCODING = "ENCODING#".toCharArray();
/*  61 */   private static final char[] ADAPTER_ACCESS = "ACCESS#".toCharArray();
/*  62 */   private static String compilerClass = "org.eclipse.jdt.internal.compiler.batch.Main";
/*     */   String logFileName;
/*     */   Map customDefaultOptions;
/*  65 */   private Map fileEncodings = null;
/*  66 */   private Map dirEncodings = null;
/*  67 */   private List accessRules = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean execute() throws BuildException {
/*  76 */     this.attributes.log(AntAdapterMessages.getString("ant.jdtadapter.info.usingJDTCompiler"), 3);
/*  77 */     Commandline cmd = setupJavacCommand();
/*     */     
/*     */     try {
/*  80 */       Class<?> c = Class.forName(compilerClass);
/*  81 */       Constructor<?> batchCompilerConstructor = c.getConstructor(new Class[] { PrintWriter.class, PrintWriter.class, boolean.class, Map.class });
/*  82 */       Object batchCompilerInstance = batchCompilerConstructor.newInstance(new Object[] { new PrintWriter(System.out), new PrintWriter(System.err), Boolean.TRUE, this.customDefaultOptions });
/*  83 */       Method compile = c.getMethod("compile", new Class[] { String[].class });
/*  84 */       Object result = compile.invoke(batchCompilerInstance, new Object[] { cmd.getArguments() });
/*  85 */       boolean resultValue = ((Boolean)result).booleanValue();
/*  86 */       if (!resultValue && this.logFileName != null) {
/*  87 */         this.attributes.log(AntAdapterMessages.getString("ant.jdtadapter.error.compilationFailed", this.logFileName));
/*     */       }
/*  89 */       return resultValue;
/*  90 */     } catch (ClassNotFoundException cnfe) {
/*  91 */       throw new BuildException(AntAdapterMessages.getString("ant.jdtadapter.error.cannotFindJDTCompiler"), cnfe);
/*  92 */     } catch (Exception ex) {
/*  93 */       throw new BuildException(ex);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected Commandline setupJavacCommand() throws BuildException {
/* 100 */     Commandline cmd = new Commandline();
/* 101 */     this.customDefaultOptions = (new CompilerOptions()).getMap();
/*     */     
/* 103 */     Class<Javac> javacClass = Javac.class;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 109 */     String[] compilerArgs = processCompilerArguments(javacClass);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 114 */     cmd.createArgument().setValue("-noExit");
/*     */     
/* 116 */     if (this.bootclasspath != null) {
/* 117 */       cmd.createArgument().setValue("-bootclasspath");
/* 118 */       if (this.bootclasspath.size() != 0) {
/*     */ 
/*     */ 
/*     */         
/* 122 */         cmd.createArgument().setPath(this.bootclasspath);
/*     */       } else {
/* 124 */         cmd.createArgument().setValue(Util.EMPTY_STRING);
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 133 */     if (this.extdirs != null) {
/* 134 */       cmd.createArgument().setValue("-extdirs");
/* 135 */       cmd.createArgument().setPath(this.extdirs);
/*     */     } 
/*     */     
/* 138 */     Path classpath = new Path(this.project);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 143 */     classpath.append(getCompileClasspath());
/*     */ 
/*     */ 
/*     */     
/* 147 */     cmd.createArgument().setValue("-classpath");
/* 148 */     createClasspathArgument(cmd, classpath);
/*     */ 
/*     */ 
/*     */     
/* 152 */     Path sourcepath = null;
/*     */ 
/*     */ 
/*     */     
/* 156 */     Method getSourcepathMethod = null;
/*     */     try {
/* 158 */       getSourcepathMethod = javacClass.getMethod("getSourcepath", null);
/* 159 */     } catch (NoSuchMethodException noSuchMethodException) {}
/*     */ 
/*     */     
/* 162 */     Path compileSourcePath = null;
/* 163 */     if (getSourcepathMethod != null) {
/*     */       try {
/* 165 */         compileSourcePath = (Path)getSourcepathMethod.invoke(this.attributes, null);
/* 166 */       } catch (IllegalAccessException|java.lang.reflect.InvocationTargetException illegalAccessException) {}
/*     */     }
/*     */ 
/*     */     
/* 170 */     if (compileSourcePath != null) {
/* 171 */       sourcepath = compileSourcePath;
/*     */     } else {
/* 173 */       sourcepath = this.src;
/*     */     } 
/* 175 */     cmd.createArgument().setValue("-sourcepath");
/* 176 */     createClasspathArgument(cmd, sourcepath);
/*     */     
/* 178 */     String javaVersion = JavaEnvUtils.getJavaVersion();
/* 179 */     String memoryParameterPrefix = javaVersion.equals("1.1") ? "-J-" : "-J-X";
/* 180 */     if (this.memoryInitialSize != null) {
/* 181 */       if (!this.attributes.isForkedJavac()) {
/* 182 */         this.attributes.log(AntAdapterMessages.getString("ant.jdtadapter.info.ignoringMemoryInitialSize"), 1);
/*     */       } else {
/* 184 */         cmd.createArgument().setValue(String.valueOf(memoryParameterPrefix) + 
/* 185 */             "ms" + this.memoryInitialSize);
/*     */       } 
/*     */     }
/*     */     
/* 189 */     if (this.memoryMaximumSize != null) {
/* 190 */       if (!this.attributes.isForkedJavac()) {
/* 191 */         this.attributes.log(AntAdapterMessages.getString("ant.jdtadapter.info.ignoringMemoryMaximumSize"), 1);
/*     */       } else {
/* 193 */         cmd.createArgument().setValue(String.valueOf(memoryParameterPrefix) + 
/* 194 */             "mx" + this.memoryMaximumSize);
/*     */       } 
/*     */     }
/*     */     
/* 198 */     if (this.debug) {
/*     */ 
/*     */       
/* 201 */       Method getDebugLevelMethod = null;
/*     */       try {
/* 203 */         getDebugLevelMethod = javacClass.getMethod("getDebugLevel", null);
/* 204 */       } catch (NoSuchMethodException noSuchMethodException) {}
/*     */ 
/*     */ 
/*     */       
/* 208 */       String debugLevel = null;
/* 209 */       if (getDebugLevelMethod != null) {
/*     */         try {
/* 211 */           debugLevel = (String)getDebugLevelMethod.invoke(this.attributes, null);
/* 212 */         } catch (IllegalAccessException|java.lang.reflect.InvocationTargetException illegalAccessException) {}
/*     */       }
/*     */ 
/*     */       
/* 216 */       if (debugLevel != null) {
/* 217 */         this.customDefaultOptions.put("org.eclipse.jdt.core.compiler.debug.localVariable", "do not generate");
/* 218 */         this.customDefaultOptions.put("org.eclipse.jdt.core.compiler.debug.lineNumber", "do not generate");
/* 219 */         this.customDefaultOptions.put("org.eclipse.jdt.core.compiler.debug.sourceFile", "do not generate");
/* 220 */         if (debugLevel.length() != 0) {
/* 221 */           if (debugLevel.indexOf("vars") != -1) {
/* 222 */             this.customDefaultOptions.put("org.eclipse.jdt.core.compiler.debug.localVariable", "generate");
/*     */           }
/* 224 */           if (debugLevel.indexOf("lines") != -1) {
/* 225 */             this.customDefaultOptions.put("org.eclipse.jdt.core.compiler.debug.lineNumber", "generate");
/*     */           }
/* 227 */           if (debugLevel.indexOf("source") != -1) {
/* 228 */             this.customDefaultOptions.put("org.eclipse.jdt.core.compiler.debug.sourceFile", "generate");
/*     */           }
/*     */         } 
/*     */       } else {
/* 232 */         this.customDefaultOptions.put("org.eclipse.jdt.core.compiler.debug.localVariable", "generate");
/* 233 */         this.customDefaultOptions.put("org.eclipse.jdt.core.compiler.debug.lineNumber", "generate");
/* 234 */         this.customDefaultOptions.put("org.eclipse.jdt.core.compiler.debug.sourceFile", "generate");
/*     */       } 
/*     */     } else {
/* 237 */       this.customDefaultOptions.put("org.eclipse.jdt.core.compiler.debug.localVariable", "do not generate");
/* 238 */       this.customDefaultOptions.put("org.eclipse.jdt.core.compiler.debug.lineNumber", "do not generate");
/* 239 */       this.customDefaultOptions.put("org.eclipse.jdt.core.compiler.debug.sourceFile", "do not generate");
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 245 */     if (this.attributes.getNowarn()) {
/*     */       
/* 247 */       Object[] entries = this.customDefaultOptions.entrySet().toArray();
/* 248 */       for (int i = 0, max = entries.length; i < max; i++) {
/* 249 */         Map.Entry entry = (Map.Entry)entries[i];
/* 250 */         if (entry.getKey() instanceof String)
/*     */         {
/* 252 */           if (entry.getValue() instanceof String)
/*     */           {
/* 254 */             if (((String)entry.getValue()).equals("warning"))
/* 255 */               this.customDefaultOptions.put(entry.getKey(), "ignore");  } 
/*     */         }
/*     */       } 
/* 258 */       this.customDefaultOptions.put("org.eclipse.jdt.core.compiler.taskTags", Util.EMPTY_STRING);
/* 259 */       if (this.deprecation) {
/* 260 */         this.customDefaultOptions.put("org.eclipse.jdt.core.compiler.problem.deprecation", "warning");
/* 261 */         this.customDefaultOptions.put("org.eclipse.jdt.core.compiler.problem.deprecationInDeprecatedCode", "enabled");
/* 262 */         this.customDefaultOptions.put("org.eclipse.jdt.core.compiler.problem.deprecationWhenOverridingDeprecatedMethod", "enabled");
/*     */       } 
/* 264 */     } else if (this.deprecation) {
/* 265 */       this.customDefaultOptions.put("org.eclipse.jdt.core.compiler.problem.deprecation", "warning");
/* 266 */       this.customDefaultOptions.put("org.eclipse.jdt.core.compiler.problem.deprecationInDeprecatedCode", "enabled");
/* 267 */       this.customDefaultOptions.put("org.eclipse.jdt.core.compiler.problem.deprecationWhenOverridingDeprecatedMethod", "enabled");
/*     */     } else {
/* 269 */       this.customDefaultOptions.put("org.eclipse.jdt.core.compiler.problem.deprecation", "ignore");
/* 270 */       this.customDefaultOptions.put("org.eclipse.jdt.core.compiler.problem.deprecationInDeprecatedCode", "disabled");
/* 271 */       this.customDefaultOptions.put("org.eclipse.jdt.core.compiler.problem.deprecationWhenOverridingDeprecatedMethod", "disabled");
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 277 */     if (this.destDir != null) {
/* 278 */       cmd.createArgument().setValue("-d");
/* 279 */       cmd.createArgument().setFile(this.destDir.getAbsoluteFile());
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 285 */     if (this.verbose) {
/* 286 */       cmd.createArgument().setValue("-verbose");
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 292 */     if (!this.attributes.getFailonerror()) {
/* 293 */       cmd.createArgument().setValue("-proceedOnError");
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 299 */     if (this.target != null) {
/* 300 */       this.customDefaultOptions.put("org.eclipse.jdt.core.compiler.codegen.targetPlatform", this.target);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 306 */     String source = this.attributes.getSource();
/* 307 */     if (source != null) {
/* 308 */       this.customDefaultOptions.put("org.eclipse.jdt.core.compiler.source", source);
/* 309 */       this.customDefaultOptions.put("org.eclipse.jdt.core.compiler.compliance", source);
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 315 */     if (this.release != null) {
/* 316 */       this.customDefaultOptions.put("org.eclipse.jdt.core.compiler.release", this.release);
/*     */     }
/*     */ 
/*     */     
/* 320 */     if (compilerArgs != null) {
/*     */ 
/*     */ 
/*     */       
/* 324 */       int length = compilerArgs.length;
/* 325 */       if (length != 0) {
/* 326 */         for (int i = 0, max = length; i < max; i++) {
/* 327 */           String arg = compilerArgs[i];
/* 328 */           if (this.logFileName == null && "-log".equals(arg) && i + 1 < max) {
/* 329 */             this.logFileName = compilerArgs[i + 1];
/*     */           }
/* 331 */           cmd.createArgument().setValue(arg);
/*     */         } 
/*     */       }
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 339 */     if (this.encoding != null) {
/* 340 */       cmd.createArgument().setValue("-encoding");
/* 341 */       cmd.createArgument().setValue(this.encoding);
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 349 */     logAndAddFilesToCompile(cmd);
/* 350 */     return cmd;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String[] processCompilerArguments(Class javacClass) {
/* 361 */     Method getCurrentCompilerArgsMethod = null;
/*     */     try {
/* 363 */       getCurrentCompilerArgsMethod = javacClass.getMethod("getCurrentCompilerArgs", null);
/* 364 */     } catch (NoSuchMethodException noSuchMethodException) {}
/*     */ 
/*     */ 
/*     */     
/* 368 */     String[] compilerArgs = null;
/* 369 */     if (getCurrentCompilerArgsMethod != null) {
/*     */       try {
/* 371 */         compilerArgs = (String[])getCurrentCompilerArgsMethod.invoke(this.attributes, null);
/* 372 */       } catch (IllegalAccessException|java.lang.reflect.InvocationTargetException illegalAccessException) {}
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 377 */     if (compilerArgs != null) checkCompilerArgs(compilerArgs); 
/* 378 */     return compilerArgs;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void checkCompilerArgs(String[] args) {
/* 387 */     for (int i = 0; i < args.length; i++) {
/* 388 */       if (args[i].charAt(0) == '@') {
/*     */         try {
/* 390 */           char[] content = Util.getFileCharContent(new File(args[i].substring(1)), null);
/* 391 */           int offset = 0;
/* 392 */           int prefixLength = ADAPTER_PREFIX.length;
/* 393 */           while ((offset = CharOperation.indexOf(ADAPTER_PREFIX, content, true, offset)) > -1) {
/* 394 */             int start = offset + prefixLength;
/* 395 */             int end = CharOperation.indexOf('\n', content, start);
/* 396 */             if (end == -1)
/* 397 */               end = content.length; 
/* 398 */             while (CharOperation.isWhitespace(content[end])) {
/* 399 */               end--;
/*     */             }
/*     */ 
/*     */             
/* 403 */             if (CharOperation.equals(ADAPTER_ENCODING, content, start, start + ADAPTER_ENCODING.length)) {
/* 404 */               CharOperation.replace(content, SEPARATOR_CHARS, File.separatorChar, start, end + 1);
/*     */               
/* 406 */               start += ADAPTER_ENCODING.length;
/* 407 */               int encodeStart = CharOperation.lastIndexOf('[', content, start, end);
/* 408 */               if (start < encodeStart && encodeStart < end) {
/* 409 */                 boolean isFile = CharOperation.equals(SuffixConstants.SUFFIX_java, content, encodeStart - 5, encodeStart, false);
/*     */                 
/* 411 */                 String str = String.valueOf(content, start, encodeStart - start);
/* 412 */                 String enc = String.valueOf(content, encodeStart, end - encodeStart + 1);
/* 413 */                 if (isFile) {
/* 414 */                   if (this.fileEncodings == null) {
/* 415 */                     this.fileEncodings = new HashMap<>();
/*     */                   }
/* 417 */                   this.fileEncodings.put(str, enc);
/*     */                 } else {
/* 419 */                   if (this.dirEncodings == null)
/* 420 */                     this.dirEncodings = new HashMap<>(); 
/* 421 */                   this.dirEncodings.put(str, enc);
/*     */                 } 
/*     */               } 
/* 424 */             } else if (CharOperation.equals(ADAPTER_ACCESS, content, start, start + ADAPTER_ACCESS.length)) {
/*     */               
/* 426 */               start += ADAPTER_ACCESS.length;
/* 427 */               int accessStart = CharOperation.indexOf('[', content, start, end);
/* 428 */               CharOperation.replace(content, SEPARATOR_CHARS, File.separatorChar, start, accessStart);
/* 429 */               if (start < accessStart && accessStart < end) {
/* 430 */                 String path = String.valueOf(content, start, accessStart - start);
/* 431 */                 String access = String.valueOf(content, accessStart, end - accessStart + 1);
/* 432 */                 if (this.accessRules == null)
/* 433 */                   this.accessRules = new ArrayList(); 
/* 434 */                 this.accessRules.add(path);
/* 435 */                 this.accessRules.add(access);
/*     */               } 
/*     */             } 
/* 438 */             offset = end;
/*     */           } 
/* 440 */         } catch (IOException iOException) {}
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void createClasspathArgument(Commandline cmd, Path classpath) {
/* 454 */     Commandline.Argument arg = cmd.createArgument();
/* 455 */     String[] pathElements = classpath.list();
/*     */ 
/*     */     
/* 458 */     if (pathElements.length == 0) {
/* 459 */       arg.setValue(Util.EMPTY_STRING);
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/* 464 */     if (this.accessRules == null) {
/* 465 */       arg.setPath(classpath);
/*     */       
/*     */       return;
/*     */     } 
/* 469 */     int rulesLength = this.accessRules.size();
/* 470 */     String[] rules = (String[])this.accessRules.toArray((Object[])new String[rulesLength]);
/* 471 */     int nextRule = 0;
/* 472 */     StringBuilder result = new StringBuilder();
/*     */ 
/*     */ 
/*     */     
/* 476 */     for (int i = 0, max = pathElements.length; i < max; i++) {
/* 477 */       if (i > 0)
/* 478 */         result.append(File.pathSeparatorChar); 
/* 479 */       String pathElement = pathElements[i];
/* 480 */       result.append(pathElement);
/*     */       
/* 482 */       for (int j = nextRule; j < rulesLength; j += 2) {
/* 483 */         String rule = rules[j];
/* 484 */         if (pathElement.endsWith(rule)) {
/* 485 */           result.append(rules[j + 1]);
/* 486 */           nextRule = j + 2;
/*     */           
/*     */           break;
/*     */         } 
/* 490 */         if (rule.endsWith(File.separator)) {
/*     */ 
/*     */           
/* 493 */           int ruleLength = rule.length();
/* 494 */           if (pathElement.regionMatches(false, pathElement.length() - ruleLength + 1, rule, 0, ruleLength - 1)) {
/* 495 */             result.append(rules[j + 1]);
/* 496 */             nextRule = j + 2;
/*     */             break;
/*     */           } 
/* 499 */         } else if (pathElement.endsWith(File.separator)) {
/*     */           
/* 501 */           int ruleLength = rule.length();
/* 502 */           if (pathElement.regionMatches(false, pathElement.length() - ruleLength - 1, rule, 0, ruleLength)) {
/* 503 */             result.append(rules[j + 1]);
/* 504 */             nextRule = j + 2;
/*     */             
/*     */             break;
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/* 511 */     arg.setValue(result.toString());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void logAndAddFilesToCompile(Commandline cmd) {
/* 522 */     this.attributes.log("Compilation " + cmd.describeArguments(), 
/* 523 */         3);
/*     */     
/* 525 */     StringBuilder niceSourceList = new StringBuilder("File");
/* 526 */     if (this.compileList.length != 1) {
/* 527 */       niceSourceList.append("s");
/*     */     }
/* 529 */     niceSourceList.append(" to be compiled:");
/* 530 */     niceSourceList.append(System.lineSeparator());
/*     */     
/* 532 */     String[] encodedFiles = null, encodedDirs = null;
/* 533 */     int encodedFilesLength = 0, encodedDirsLength = 0;
/* 534 */     if (this.fileEncodings != null) {
/* 535 */       encodedFilesLength = this.fileEncodings.size();
/* 536 */       encodedFiles = new String[encodedFilesLength];
/* 537 */       this.fileEncodings.keySet().toArray((Object[])encodedFiles);
/*     */     } 
/* 539 */     if (this.dirEncodings != null) {
/* 540 */       encodedDirsLength = this.dirEncodings.size();
/* 541 */       encodedDirs = new String[encodedDirsLength];
/* 542 */       this.dirEncodings.keySet().toArray((Object[])encodedDirs);
/*     */ 
/*     */       
/* 545 */       Comparator<? super String> comparator = new Comparator()
/*     */         {
/*     */           public int compare(Object o1, Object o2) {
/* 548 */             return ((String)o2).length() - ((String)o1).length();
/*     */           }
/*     */         };
/* 551 */       Arrays.sort(encodedDirs, comparator);
/*     */     } 
/*     */     
/* 554 */     for (int i = 0; i < this.compileList.length; i++) {
/* 555 */       String arg = this.compileList[i].getAbsolutePath();
/* 556 */       boolean encoded = false;
/* 557 */       if (encodedFiles != null)
/*     */       {
/* 559 */         for (int j = 0; j < encodedFilesLength; j++) {
/* 560 */           if (arg.endsWith(encodedFiles[j])) {
/*     */             
/* 562 */             arg = String.valueOf(arg) + (String)this.fileEncodings.get(encodedFiles[j]);
/* 563 */             if (j < encodedFilesLength - 1) {
/* 564 */               System.arraycopy(encodedFiles, j + 1, encodedFiles, j, encodedFilesLength - j - 1);
/*     */             }
/* 566 */             encodedFiles[--encodedFilesLength] = null;
/* 567 */             encoded = true;
/*     */             break;
/*     */           } 
/*     */         } 
/*     */       }
/* 572 */       if (!encoded && encodedDirs != null)
/*     */       {
/* 574 */         for (int j = 0; j < encodedDirsLength; j++) {
/* 575 */           if (arg.lastIndexOf(encodedDirs[j]) != -1) {
/* 576 */             arg = String.valueOf(arg) + (String)this.dirEncodings.get(encodedDirs[j]);
/*     */             break;
/*     */           } 
/*     */         } 
/*     */       }
/* 581 */       cmd.createArgument().setValue(arg);
/* 582 */       niceSourceList.append("    " + arg + System.lineSeparator());
/*     */     } 
/*     */     
/* 585 */     this.attributes.log(niceSourceList.toString(), 3);
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\core\JDTCompilerAdapter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */