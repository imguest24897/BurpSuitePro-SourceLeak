/*     */ package org.eclipse.jdt.internal.compiler.lookup;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import org.eclipse.jdt.internal.compiler.ast.Argument;
/*     */ import org.eclipse.jdt.internal.compiler.ast.ConditionalExpression;
/*     */ import org.eclipse.jdt.internal.compiler.ast.Expression;
/*     */ import org.eclipse.jdt.internal.compiler.ast.ExpressionContext;
/*     */ import org.eclipse.jdt.internal.compiler.ast.Invocation;
/*     */ import org.eclipse.jdt.internal.compiler.ast.LambdaExpression;
/*     */ import org.eclipse.jdt.internal.compiler.ast.MessageSend;
/*     */ import org.eclipse.jdt.internal.compiler.ast.ReferenceExpression;
/*     */ import org.eclipse.jdt.internal.compiler.ast.SwitchExpression;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class ConstraintExpressionFormula
/*     */   extends ConstraintFormula
/*     */ {
/*     */   Expression left;
/*     */   boolean isSoft;
/*     */   
/*     */   ConstraintExpressionFormula(Expression expression, TypeBinding type, int relation) {
/*  50 */     this.left = expression;
/*  51 */     this.right = type;
/*  52 */     this.relation = relation;
/*     */   }
/*     */   
/*     */   ConstraintExpressionFormula(Expression expression, TypeBinding type, int relation, boolean isSoft) {
/*  56 */     this(expression, type, relation);
/*  57 */     this.isSoft = isSoft;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Object reduce(InferenceContext18 inferenceContext) throws InferenceFailureException {
/*  63 */     if (this.relation == 8)
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*  70 */       return this.left.isPotentiallyCompatibleWith(this.right, inferenceContext.scope) ? TRUE : FALSE;
/*     */     }
/*     */ 
/*     */     
/*  74 */     if (this.right.isProperType(true)) {
/*  75 */       if (this.left.isCompatibleWith(this.right, inferenceContext.scope) || this.left.isBoxingCompatibleWith(this.right, inferenceContext.scope)) {
/*  76 */         if (this.left.resolvedType != null && this.left.resolvedType.needsUncheckedConversion(this.right)) {
/*  77 */           inferenceContext.usesUncheckedConversion = true;
/*     */         }
/*  79 */         return TRUE;
/*     */       } 
/*  81 */       return FALSE;
/*     */     } 
/*  83 */     if (!canBePolyExpression(this.left)) {
/*  84 */       TypeBinding exprType = this.left.resolvedType;
/*  85 */       if (exprType == null || !exprType.isValidBinding()) {
/*  86 */         if (this.left instanceof MessageSend && ((MessageSend)this.left).actualReceiverType instanceof InferenceVariable)
/*  87 */           return null; 
/*  88 */         return FALSE;
/*     */       } 
/*  90 */       return ConstraintTypeFormula.create(exprType, this.right, 1, this.isSoft);
/*     */     } 
/*     */ 
/*     */     
/*  94 */     if (this.left instanceof Invocation) {
/*  95 */       Invocation invocation = (Invocation)this.left;
/*  96 */       MethodBinding previousMethod = invocation.binding();
/*  97 */       if (previousMethod == null)
/*  98 */         return null; 
/*  99 */       MethodBinding method = previousMethod;
/*     */ 
/*     */ 
/*     */       
/* 103 */       method = previousMethod.shallowOriginal();
/* 104 */       InferenceContext18.SuspendedInferenceRecord prevInvocation = inferenceContext.enterPolyInvocation((InvocationSite)invocation, invocation.arguments());
/*     */ 
/*     */       
/* 107 */       InferenceContext18 innerCtx = null;
/*     */       try {
/* 109 */         Expression[] arguments = invocation.arguments();
/* 110 */         TypeBinding[] argumentTypes = (arguments == null) ? Binding.NO_PARAMETERS : new TypeBinding[arguments.length];
/* 111 */         for (int i = 0; i < argumentTypes.length; i++)
/* 112 */           argumentTypes[i] = (arguments[i]).resolvedType; 
/* 113 */         if (previousMethod instanceof ParameterizedGenericMethodBinding) {
/*     */           
/* 115 */           innerCtx = invocation.getInferenceContext((ParameterizedGenericMethodBinding)previousMethod);
/* 116 */           if (innerCtx == null) {
/*     */ 
/*     */ 
/*     */             
/* 120 */             TypeBinding exprType = this.left.resolvedType;
/* 121 */             if (exprType == null || !exprType.isValidBinding())
/* 122 */               return FALSE; 
/* 123 */             return ConstraintTypeFormula.create(exprType, this.right, 1, this.isSoft);
/*     */           } 
/* 125 */           if (innerCtx.stepCompleted >= 1) {
/* 126 */             inferenceContext.integrateInnerInferenceB2(innerCtx);
/*     */           } else {
/* 128 */             return FALSE;
/*     */           } 
/*     */         } else {
/*     */           
/* 132 */           inferenceContext.inferenceKind = inferenceContext.getInferenceKind(previousMethod, argumentTypes);
/* 133 */           boolean isDiamond = (method.isConstructor() && this.left.isPolyExpression(method));
/* 134 */           inferInvocationApplicability(inferenceContext, method, argumentTypes, isDiamond, inferenceContext.inferenceKind);
/*     */         } 
/*     */         
/* 137 */         if (!inferenceContext.computeB3((InvocationSite)invocation, this.right, method))
/* 138 */           return FALSE; 
/* 139 */         return null;
/*     */       } finally {
/* 141 */         inferenceContext.resumeSuspendedInference(prevInvocation, innerCtx);
/*     */       } 
/* 143 */     }  if (this.left instanceof ConditionalExpression) {
/* 144 */       ConditionalExpression conditional = (ConditionalExpression)this.left;
/* 145 */       return new ConstraintFormula[] {
/* 146 */           new ConstraintExpressionFormula(conditional.valueIfTrue, this.right, this.relation, this.isSoft), 
/* 147 */           new ConstraintExpressionFormula(conditional.valueIfFalse, this.right, this.relation, this.isSoft) };
/*     */     } 
/* 149 */     if (this.left instanceof SwitchExpression) {
/* 150 */       SwitchExpression se = (SwitchExpression)this.left;
/* 151 */       ConstraintFormula[] cfs = new ConstraintFormula[se.resultExpressions.size()];
/* 152 */       int i = 0;
/* 153 */       for (Expression re : se.resultExpressions) {
/* 154 */         cfs[i++] = new ConstraintExpressionFormula(re, this.right, this.relation, this.isSoft);
/*     */       }
/* 156 */       return cfs;
/* 157 */     }  if (this.left instanceof LambdaExpression) {
/* 158 */       LambdaExpression lambda = (LambdaExpression)this.left;
/* 159 */       BlockScope scope = lambda.enclosingScope;
/* 160 */       if (this.right instanceof InferenceVariable)
/* 161 */         return TRUE; 
/* 162 */       if (!this.right.isFunctionalInterface(scope)) {
/* 163 */         return FALSE;
/*     */       }
/* 165 */       ReferenceBinding t = (ReferenceBinding)this.right;
/* 166 */       ParameterizedTypeBinding withWildCards = InferenceContext18.parameterizedWithWildcard(t);
/* 167 */       if (withWildCards != null) {
/* 168 */         t = findGroundTargetType(inferenceContext, scope, lambda, withWildCards);
/*     */       }
/* 170 */       if (t == null)
/* 171 */         return FALSE; 
/* 172 */       MethodBinding functionType = t.getSingleAbstractMethod(scope, true);
/* 173 */       if (functionType == null)
/* 174 */         return FALSE; 
/* 175 */       TypeBinding[] parameters = functionType.parameters;
/* 176 */       if (parameters.length != (lambda.arguments()).length)
/* 177 */         return FALSE; 
/* 178 */       if (lambda.argumentsTypeElided())
/* 179 */         for (int i = 0; i < parameters.length; i++) {
/* 180 */           if (!parameters[i].isProperType(true))
/* 181 */             return FALSE; 
/* 182 */         }   lambda = lambda.resolveExpressionExpecting(t, inferenceContext.scope, inferenceContext);
/* 183 */       if (lambda == null)
/* 184 */         return FALSE; 
/* 185 */       if (functionType.returnType == TypeBinding.VOID) {
/* 186 */         if (!lambda.isVoidCompatible()) {
/* 187 */           return FALSE;
/*     */         }
/* 189 */       } else if (!lambda.isValueCompatible()) {
/* 190 */         return FALSE;
/*     */       } 
/* 192 */       List<ConstraintFormula> result = new ArrayList<>();
/* 193 */       if (!lambda.argumentsTypeElided()) {
/* 194 */         Argument[] arguments = lambda.arguments();
/* 195 */         for (int i = 0; i < parameters.length; i++) {
/* 196 */           result.add(ConstraintTypeFormula.create(parameters[i], (arguments[i]).type.resolvedType, 4));
/*     */         }
/* 198 */         if (lambda.resolvedType != null)
/* 199 */           result.add(ConstraintTypeFormula.create(lambda.resolvedType, this.right, 2)); 
/*     */       } 
/* 201 */       if (functionType.returnType != TypeBinding.VOID) {
/* 202 */         TypeBinding r = functionType.returnType;
/* 203 */         Expression[] exprs = lambda.resultExpressions();
/* 204 */         for (int i = 0, length = (exprs == null) ? 0 : exprs.length; i < length; i++) {
/* 205 */           Expression expr = exprs[i];
/* 206 */           if (r.isProperType(true) && expr.resolvedType != null) {
/* 207 */             TypeBinding exprType = expr.resolvedType;
/*     */             
/* 209 */             if (!expr.isConstantValueOfTypeAssignableToType(exprType, r) && 
/* 210 */               !exprType.isCompatibleWith(r) && !expr.isBoxingCompatible(exprType, r, expr, scope))
/* 211 */               return FALSE; 
/*     */           } else {
/* 213 */             result.add(new ConstraintExpressionFormula(expr, r, 1, this.isSoft));
/*     */           } 
/*     */         } 
/*     */       } 
/* 217 */       if (result.size() == 0)
/* 218 */         return TRUE; 
/* 219 */       return result.toArray(new ConstraintFormula[result.size()]);
/* 220 */     }  if (this.left instanceof ReferenceExpression) {
/* 221 */       return reduceReferenceExpressionCompatibility((ReferenceExpression)this.left, inferenceContext);
/*     */     }
/*     */     
/* 224 */     return FALSE;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static ReferenceBinding findGroundTargetType(InferenceContext18 inferenceContext, BlockScope scope, LambdaExpression lambda, ParameterizedTypeBinding targetTypeWithWildCards) {
/* 230 */     if (lambda.argumentsTypeElided()) {
/* 231 */       return lambda.findGroundTargetTypeForElidedLambda(scope, targetTypeWithWildCards);
/*     */     }
/* 233 */     InferenceContext18.SuspendedInferenceRecord previous = inferenceContext.enterLambda(lambda);
/*     */     try {
/* 235 */       return inferenceContext.inferFunctionalInterfaceParameterization(lambda, scope, targetTypeWithWildCards);
/*     */     } finally {
/* 237 */       inferenceContext.resumeSuspendedInference(previous, null);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean canBePolyExpression(Expression expr) {
/* 245 */     ExpressionContext previousExpressionContext = expr.getExpressionContext();
/* 246 */     if (previousExpressionContext == ExpressionContext.VANILLA_CONTEXT)
/* 247 */       this.left.setExpressionContext(ExpressionContext.ASSIGNMENT_CONTEXT); 
/*     */     try {
/* 249 */       return expr.isPolyExpression();
/*     */     } finally {
/* 251 */       expr.setExpressionContext(previousExpressionContext);
/*     */     } 
/*     */   }
/*     */   
/*     */   private Object reduceReferenceExpressionCompatibility(ReferenceExpression reference, InferenceContext18 inferenceContext) {
/* 256 */     TypeBinding t = this.right;
/* 257 */     if (t.isProperType(true))
/* 258 */       throw new IllegalStateException("Should not reach here with T being a proper type"); 
/* 259 */     if (!t.isFunctionalInterface(inferenceContext.scope))
/* 260 */       return FALSE; 
/* 261 */     MethodBinding functionType = t.getSingleAbstractMethod(inferenceContext.scope, true);
/* 262 */     if (functionType == null) {
/* 263 */       return FALSE;
/*     */     }
/* 265 */     reference = reference.resolveExpressionExpecting(t, inferenceContext.scope, inferenceContext);
/* 266 */     MethodBinding potentiallyApplicable = (reference != null) ? reference.binding : null;
/* 267 */     if (potentiallyApplicable == null)
/* 268 */       return FALSE; 
/* 269 */     if (reference.isExactMethodReference()) {
/* 270 */       List<ConstraintFormula> newConstraints = new ArrayList<>();
/* 271 */       TypeBinding[] p = functionType.parameters;
/* 272 */       int j = p.length;
/* 273 */       TypeBinding[] pPrime = potentiallyApplicable.parameters;
/* 274 */       int k = pPrime.length;
/* 275 */       int offset = 0;
/* 276 */       if (j == k + 1) {
/* 277 */         newConstraints.add(ConstraintTypeFormula.create(p[0], reference.lhs.resolvedType, 1));
/* 278 */         offset = 1;
/*     */       } 
/* 280 */       for (int m = offset; m < j; m++)
/* 281 */         newConstraints.add(ConstraintTypeFormula.create(p[m], pPrime[m - offset], 1)); 
/* 282 */       TypeBinding typeBinding = functionType.returnType;
/* 283 */       if (typeBinding != TypeBinding.VOID) {
/* 284 */         TypeBinding rAppl = (potentiallyApplicable.isConstructor() && !reference.isArrayConstructorReference()) ? potentiallyApplicable.declaringClass : potentiallyApplicable.returnType;
/* 285 */         if (rAppl == TypeBinding.VOID)
/* 286 */           return FALSE; 
/* 287 */         TypeBinding typeBinding1 = rAppl.capture(inferenceContext.scope, reference.sourceStart, reference.sourceEnd);
/* 288 */         newConstraints.add(ConstraintTypeFormula.create(typeBinding1, typeBinding, 1));
/*     */       } 
/* 290 */       return newConstraints.toArray(new ConstraintFormula[newConstraints.size()]);
/*     */     } 
/* 292 */     int n = functionType.parameters.length;
/* 293 */     for (int i = 0; i < n; i++) {
/* 294 */       if (!functionType.parameters[i].isProperType(true)) {
/* 295 */         return FALSE;
/*     */       }
/*     */     } 
/*     */     
/* 299 */     MethodBinding compileTimeDecl = potentiallyApplicable;
/* 300 */     if (!compileTimeDecl.isValidBinding())
/* 301 */       return FALSE; 
/* 302 */     TypeBinding r = functionType.isConstructor() ? functionType.declaringClass : functionType.returnType;
/* 303 */     if (r.id == 6) {
/* 304 */       return TRUE;
/*     */     }
/* 306 */     MethodBinding original = compileTimeDecl.shallowOriginal();
/* 307 */     if (needsInference(reference, original)) {
/*     */       TypeBinding[] argumentTypes;
/* 309 */       if (t.isParameterizedType()) {
/* 310 */         MethodBinding capturedFunctionType = ((ParameterizedTypeBinding)t).getSingleAbstractMethod(inferenceContext.scope, true, reference.sourceStart, reference.sourceEnd);
/* 311 */         argumentTypes = capturedFunctionType.parameters;
/*     */       } else {
/* 313 */         argumentTypes = functionType.parameters;
/*     */       } 
/* 315 */       InferenceContext18.SuspendedInferenceRecord prevInvocation = inferenceContext.enterPolyInvocation((InvocationSite)reference, reference.createPseudoExpressions(argumentTypes));
/*     */ 
/*     */       
/* 318 */       InferenceContext18 innerContext = null;
/*     */       try {
/* 320 */         innerContext = reference.getInferenceContext((ParameterizedMethodBinding)compileTimeDecl);
/* 321 */         if (innerContext != null)
/* 322 */           innerContext.pushBoundsTo(inferenceContext); 
/* 323 */         int innerInferenceKind = determineInferenceKind(compileTimeDecl, argumentTypes, innerContext);
/* 324 */         inferInvocationApplicability(inferenceContext, original, argumentTypes, original.isConstructor(), innerInferenceKind);
/* 325 */         if (!inferenceContext.computeB3((InvocationSite)reference, r, original))
/* 326 */           return FALSE; 
/* 327 */         return null;
/* 328 */       } catch (InferenceFailureException inferenceFailureException) {
/* 329 */         return FALSE;
/*     */       } finally {
/* 331 */         inferenceContext.resumeSuspendedInference(prevInvocation, innerContext);
/*     */       } 
/*     */     } 
/* 334 */     TypeBinding rPrime = compileTimeDecl.isConstructor() ? compileTimeDecl.declaringClass : compileTimeDecl.returnType.capture(inferenceContext.scope, reference.sourceStart(), reference.sourceEnd());
/* 335 */     if (rPrime.id == 6)
/* 336 */       return FALSE; 
/* 337 */     return ConstraintTypeFormula.create(rPrime, r, 1, this.isSoft);
/*     */   }
/*     */   
/*     */   private boolean needsInference(ReferenceExpression reference, MethodBinding original) {
/*     */     TypeBinding compileTimeReturn;
/* 342 */     if (reference.typeArguments != null) {
/* 343 */       return false;
/*     */     }
/* 345 */     if (original.isConstructor()) {
/*     */ 
/*     */       
/* 348 */       if (original.declaringClass.typeVariables() != Binding.NO_TYPE_VARIABLES && 
/* 349 */         reference.receiverType.isRawType())
/* 350 */         return true; 
/* 351 */       compileTimeReturn = original.declaringClass;
/*     */     } else {
/* 353 */       compileTimeReturn = original.returnType;
/*     */     } 
/* 355 */     return (original.typeVariables() != Binding.NO_TYPE_VARIABLES && 
/* 356 */       compileTimeReturn.mentionsAny((TypeBinding[])original.typeVariables(), -1));
/*     */   }
/*     */   
/*     */   private int determineInferenceKind(MethodBinding original, TypeBinding[] argumentTypes, InferenceContext18 innerContext) {
/* 360 */     if (innerContext != null)
/* 361 */       return innerContext.inferenceKind; 
/* 362 */     if (original.isVarargs()) {
/* 363 */       int expectedLen = original.parameters.length;
/* 364 */       int providedLen = argumentTypes.length;
/* 365 */       if (expectedLen < providedLen)
/* 366 */         return 3; 
/* 367 */       if (expectedLen == providedLen) {
/* 368 */         TypeBinding providedLast = argumentTypes[expectedLen - 1];
/* 369 */         TypeBinding expectedLast = original.parameters[expectedLen - 1];
/* 370 */         if (!providedLast.isCompatibleWith(expectedLast) && 
/* 371 */           expectedLast.isArrayType()) {
/* 372 */           expectedLast = expectedLast.leafComponentType();
/* 373 */           if (providedLast.isCompatibleWith(expectedLast)) {
/* 374 */             return 3;
/*     */           }
/*     */         } 
/*     */       } 
/*     */     } 
/* 379 */     return 1;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   static void inferInvocationApplicability(InferenceContext18 inferenceContext, MethodBinding method, TypeBinding[] arguments, boolean isDiamond, int checkType) {
/* 385 */     TypeVariableBinding[] typeVariables = method.getAllTypeVariables(isDiamond);
/* 386 */     InferenceVariable[] inferenceVariables = inferenceContext.createInitialBoundSet(typeVariables);
/*     */ 
/*     */     
/* 389 */     int paramLength = method.parameters.length;
/* 390 */     TypeBinding varArgsType = null;
/* 391 */     if (method.isVarargs()) {
/* 392 */       int varArgPos = paramLength - 1;
/* 393 */       varArgsType = method.parameters[varArgPos];
/*     */     } 
/* 395 */     inferenceContext.createInitialConstraintsForParameters(method.parameters, (checkType == 3), varArgsType, method);
/* 396 */     inferenceContext.addThrowsContraints((TypeBinding[])typeVariables, inferenceVariables, method.thrownExceptions);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static boolean inferPolyInvocationType(InferenceContext18 inferenceContext, InvocationSite invocationSite, TypeBinding targetType, MethodBinding method) throws InferenceFailureException {
/* 403 */     TypeBinding[] typeArguments = invocationSite.genericTypeArguments();
/* 404 */     if (typeArguments == null) {
/*     */       
/* 406 */       TypeBinding returnType = method.isConstructor() ? method.declaringClass : method.returnType;
/* 407 */       if (returnType == TypeBinding.VOID) {
/* 408 */         throw new InferenceFailureException("expression has no value");
/*     */       }
/* 410 */       if (inferenceContext.usesUncheckedConversion) {
/* 411 */         TypeBinding erasure = getRealErasure(returnType, inferenceContext.environment);
/* 412 */         ConstraintTypeFormula constraintTypeFormula = ConstraintTypeFormula.create(erasure, targetType, 1);
/* 413 */         return inferenceContext.reduceAndIncorporate(constraintTypeFormula);
/*     */       } 
/* 415 */       TypeBinding rTheta = inferenceContext.substitute(returnType);
/* 416 */       ParameterizedTypeBinding parameterizedType = InferenceContext18.parameterizedWithWildcard(rTheta);
/* 417 */       if (parameterizedType != null && parameterizedType.arguments != null) {
/* 418 */         TypeBinding[] arguments = parameterizedType.arguments;
/* 419 */         InferenceVariable[] betas = inferenceContext.addTypeVariableSubstitutions(arguments);
/* 420 */         ParameterizedTypeBinding gbeta = inferenceContext.environment.createParameterizedType(
/* 421 */             parameterizedType.genericType(), (TypeBinding[])betas, parameterizedType.enclosingType(), parameterizedType.getTypeAnnotations());
/* 422 */         inferenceContext.currentBounds.captures.put(gbeta, parameterizedType);
/*     */         
/* 424 */         for (int i = 0, length = arguments.length; i < length; i++) {
/* 425 */           if (arguments[i].isWildcard()) {
/* 426 */             WildcardBinding wc = (WildcardBinding)arguments[i];
/* 427 */             switch (wc.boundKind) {
/*     */               case 1:
/* 429 */                 inferenceContext.currentBounds.addBound(new TypeBound(betas[i], wc.bound(), 2), inferenceContext.environment);
/*     */                 break;
/*     */               case 2:
/* 432 */                 inferenceContext.currentBounds.addBound(new TypeBound(betas[i], wc.bound(), 3), inferenceContext.environment);
/*     */                 break;
/*     */             } 
/*     */           
/*     */           } 
/*     */         } 
/* 438 */         ConstraintTypeFormula constraintTypeFormula = ConstraintTypeFormula.create(gbeta, targetType, 1);
/* 439 */         return inferenceContext.reduceAndIncorporate(constraintTypeFormula);
/*     */       } 
/* 441 */       if (rTheta.leafComponentType() instanceof InferenceVariable) {
/* 442 */         InferenceVariable alpha = (InferenceVariable)rTheta.leafComponentType();
/* 443 */         TypeBinding targetLeafType = targetType.leafComponentType();
/* 444 */         boolean toResolve = false;
/* 445 */         if (inferenceContext.currentBounds.condition18_5_2_bullet_3_3_1(alpha, targetLeafType)) {
/* 446 */           toResolve = true;
/* 447 */         } else if (inferenceContext.currentBounds.condition18_5_2_bullet_3_3_2(alpha, targetLeafType, inferenceContext)) {
/* 448 */           toResolve = true;
/* 449 */         } else if (targetLeafType.isPrimitiveType()) {
/* 450 */           TypeBinding wrapper = inferenceContext.currentBounds.findWrapperTypeBound(alpha);
/* 451 */           if (wrapper != null)
/* 452 */             toResolve = true; 
/*     */         } 
/* 454 */         if (toResolve) {
/* 455 */           BoundSet solution = inferenceContext.solve(new InferenceVariable[] { alpha }, false);
/* 456 */           if (solution == null)
/* 457 */             return false; 
/* 458 */           TypeBinding u = solution.getInstantiation(alpha, null).capture(inferenceContext.scope, invocationSite.sourceStart(), invocationSite.sourceEnd());
/* 459 */           if (rTheta.dimensions() != 0) {
/* 460 */             u = inferenceContext.environment.createArrayType(u, rTheta.dimensions());
/*     */           }
/* 462 */           ConstraintTypeFormula constraintTypeFormula = ConstraintTypeFormula.create(u, targetType, 1);
/* 463 */           return inferenceContext.reduceAndIncorporate(constraintTypeFormula);
/*     */         } 
/*     */       } 
/* 466 */       ConstraintTypeFormula newConstraint = ConstraintTypeFormula.create(rTheta, targetType, 1);
/* 467 */       if (!inferenceContext.reduceAndIncorporate(newConstraint))
/* 468 */         return false; 
/*     */     } 
/* 470 */     return true;
/*     */   }
/*     */   
/*     */   private static TypeBinding getRealErasure(TypeBinding type, LookupEnvironment environment) {
/* 474 */     TypeBinding erasure = type.erasure();
/*     */     
/* 476 */     TypeBinding erasedLeaf = erasure.leafComponentType();
/* 477 */     if (erasedLeaf.isGenericType())
/* 478 */       erasedLeaf = environment.convertToRawType(erasedLeaf, false); 
/* 479 */     if (erasure.isArrayType())
/* 480 */       return environment.createArrayType(erasedLeaf, erasure.dimensions()); 
/* 481 */     return erasedLeaf;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   Collection<InferenceVariable> inputVariables(InferenceContext18 context) {
/* 487 */     if (this.left instanceof LambdaExpression)
/* 488 */     { if (this.right instanceof InferenceVariable) {
/* 489 */         return Collections.singletonList((InferenceVariable)this.right);
/*     */       }
/* 491 */       if (this.right.isFunctionalInterface(context.scope)) {
/* 492 */         LambdaExpression lambda = (LambdaExpression)this.left;
/* 493 */         ReferenceBinding targetType = (ReferenceBinding)this.right;
/* 494 */         ParameterizedTypeBinding withWildCards = InferenceContext18.parameterizedWithWildcard(targetType);
/* 495 */         if (withWildCards != null) {
/* 496 */           targetType = findGroundTargetType(context, lambda.enclosingScope, lambda, withWildCards);
/*     */         }
/* 498 */         if (targetType == null) {
/* 499 */           return EMPTY_VARIABLE_LIST;
/*     */         }
/* 501 */         MethodBinding sam = targetType.getSingleAbstractMethod(context.scope, true);
/* 502 */         Set<InferenceVariable> variables = new LinkedHashSet<>();
/* 503 */         if (lambda.argumentsTypeElided()) {
/*     */           
/* 505 */           int len = sam.parameters.length;
/* 506 */           for (int i = 0; i < len; i++) {
/* 507 */             sam.parameters[i].collectInferenceVariables(variables);
/*     */           }
/*     */         } 
/* 510 */         if (sam.returnType != TypeBinding.VOID) {
/*     */           
/* 512 */           TypeBinding r = sam.returnType;
/* 513 */           LambdaExpression resolved = lambda.resolveExpressionExpecting(this.right, context.scope, context);
/* 514 */           Expression[] resultExpressions = (resolved != null) ? resolved.resultExpressions() : null;
/* 515 */           for (int i = 0, length = (resultExpressions == null) ? 0 : resultExpressions.length; i < length; i++) {
/* 516 */             variables.addAll((new ConstraintExpressionFormula(resultExpressions[i], r, 1)).inputVariables(context));
/*     */           }
/*     */         } 
/* 519 */         return variables;
/*     */       }  }
/* 521 */     else if (this.left instanceof ReferenceExpression)
/* 522 */     { if (this.right instanceof InferenceVariable) {
/* 523 */         return Collections.singletonList((InferenceVariable)this.right);
/*     */       }
/* 525 */       if (this.right.isFunctionalInterface(context.scope) && !this.left.isExactMethodReference()) {
/* 526 */         MethodBinding sam = this.right.getSingleAbstractMethod(context.scope, true);
/* 527 */         Set<InferenceVariable> variables = new LinkedHashSet<>();
/* 528 */         int len = sam.parameters.length;
/* 529 */         for (int i = 0; i < len; i++) {
/* 530 */           sam.parameters[i].collectInferenceVariables(variables);
/*     */         }
/* 532 */         return variables;
/*     */       }  }
/* 534 */     else { if (this.left instanceof ConditionalExpression && this.left.isPolyExpression()) {
/* 535 */         ConditionalExpression expr = (ConditionalExpression)this.left;
/* 536 */         Set<InferenceVariable> variables = new LinkedHashSet<>();
/* 537 */         variables.addAll((new ConstraintExpressionFormula(expr.valueIfTrue, this.right, 1)).inputVariables(context));
/* 538 */         variables.addAll((new ConstraintExpressionFormula(expr.valueIfFalse, this.right, 1)).inputVariables(context));
/* 539 */         return variables;
/* 540 */       }  if (this.left instanceof SwitchExpression && this.left.isPolyExpression()) {
/* 541 */         SwitchExpression expr = (SwitchExpression)this.left;
/* 542 */         Set<InferenceVariable> variables = new LinkedHashSet<>();
/* 543 */         for (Expression re : expr.resultExpressions) {
/* 544 */           variables.addAll((new ConstraintExpressionFormula(re, this.right, 1)).inputVariables(context));
/*     */         }
/* 546 */         return variables;
/*     */       }  }
/* 548 */      return EMPTY_VARIABLE_LIST;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 554 */     StringBuffer buf = (new StringBuffer()).append('⟨');
/* 555 */     this.left.printExpression(4, buf);
/* 556 */     buf.append(relationToString(this.relation));
/* 557 */     appendTypeName(buf, this.right);
/* 558 */     buf.append('⟩');
/* 559 */     return buf.toString();
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\lookup\ConstraintExpressionFormula.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */