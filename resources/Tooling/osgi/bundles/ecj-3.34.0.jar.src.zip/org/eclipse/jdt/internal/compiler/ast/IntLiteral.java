/*     */ package org.eclipse.jdt.internal.compiler.ast;
/*     */ 
/*     */ import org.eclipse.jdt.core.compiler.CharOperation;
/*     */ import org.eclipse.jdt.internal.compiler.ASTVisitor;
/*     */ import org.eclipse.jdt.internal.compiler.codegen.CodeStream;
/*     */ import org.eclipse.jdt.internal.compiler.impl.Constant;
/*     */ import org.eclipse.jdt.internal.compiler.impl.IntConstant;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.BlockScope;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.TypeBinding;
/*     */ import org.eclipse.jdt.internal.compiler.parser.ScannerHelper;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class IntLiteral
/*     */   extends NumberLiteral
/*     */ {
/*  26 */   private static final char[] HEXA_MIN_VALUE = "0x80000000".toCharArray();
/*  27 */   private static final char[] HEXA_MINUS_ONE_VALUE = "0xffffffff".toCharArray();
/*  28 */   private static final char[] OCTAL_MIN_VALUE = "020000000000".toCharArray();
/*  29 */   private static final char[] OCTAL_MINUS_ONE_VALUE = "037777777777".toCharArray();
/*  30 */   private static final char[] DECIMAL_MIN_VALUE = "2147483648".toCharArray();
/*  31 */   private static final char[] DECIMAL_MAX_VALUE = "2147483647".toCharArray();
/*     */ 
/*     */   
/*     */   private char[] reducedForm;
/*     */   
/*     */   public int value;
/*     */   
/*  38 */   public static final IntLiteral One = new IntLiteral(new char[] { '1' }, null, 0, 0, 1, IntConstant.fromValue(1));
/*     */ 
/*     */   
/*     */   public static IntLiteral buildIntLiteral(char[] token, int s, int e) {
/*  42 */     char[] intReducedToken = removePrefixZerosAndUnderscores(token, false);
/*  43 */     switch (intReducedToken.length) {
/*     */       
/*     */       case 10:
/*  46 */         if (CharOperation.equals(intReducedToken, HEXA_MIN_VALUE)) {
/*  47 */           return new IntLiteralMinValue(token, (intReducedToken != token) ? intReducedToken : null, s, e);
/*     */         }
/*     */         break;
/*     */       
/*     */       case 12:
/*  52 */         if (CharOperation.equals(intReducedToken, OCTAL_MIN_VALUE)) {
/*  53 */           return new IntLiteralMinValue(token, (intReducedToken != token) ? intReducedToken : null, s, e);
/*     */         }
/*     */         break;
/*     */     } 
/*  57 */     return new IntLiteral(token, (intReducedToken != token) ? intReducedToken : null, s, e);
/*     */   }
/*     */   IntLiteral(char[] token, char[] reducedForm, int start, int end) {
/*  60 */     super(token, start, end);
/*  61 */     this.reducedForm = reducedForm;
/*     */   }
/*     */   IntLiteral(char[] token, char[] reducedForm, int start, int end, int value, Constant constant) {
/*  64 */     super(token, start, end);
/*  65 */     this.reducedForm = reducedForm;
/*  66 */     this.value = value;
/*  67 */     this.constant = constant;
/*     */   }
/*     */   
/*     */   public void computeConstant() {
/*  71 */     char[] token = (this.reducedForm != null) ? this.reducedForm : this.source;
/*  72 */     int tokenLength = token.length;
/*  73 */     int radix = 10;
/*  74 */     int j = 0;
/*  75 */     if (token[0] == '0') {
/*  76 */       if (tokenLength == 1) {
/*  77 */         this.constant = IntConstant.fromValue(0);
/*     */         return;
/*     */       } 
/*  80 */       if (token[1] == 'x' || token[1] == 'X') {
/*  81 */         radix = 16;
/*  82 */         j = 2;
/*  83 */       } else if (token[1] == 'b' || token[1] == 'B') {
/*  84 */         radix = 2;
/*  85 */         j = 2;
/*     */       } else {
/*  87 */         radix = 8;
/*  88 */         j = 1;
/*     */       } 
/*     */     } 
/*  91 */     switch (radix) {
/*     */       case 2:
/*  93 */         if (tokenLength - 2 > 32) {
/*     */           return;
/*     */         }
/*     */         
/*  97 */         computeValue(token, tokenLength, radix, j);
/*     */         return;
/*     */       case 16:
/* 100 */         if (tokenLength <= 10) {
/* 101 */           if (CharOperation.equals(token, HEXA_MINUS_ONE_VALUE)) {
/* 102 */             this.constant = IntConstant.fromValue(-1);
/*     */             return;
/*     */           } 
/* 105 */           computeValue(token, tokenLength, radix, j);
/*     */           return;
/*     */         } 
/*     */         break;
/*     */       case 10:
/* 110 */         if (tokenLength > DECIMAL_MAX_VALUE.length || (
/* 111 */           tokenLength == DECIMAL_MAX_VALUE.length && 
/* 112 */           CharOperation.compareTo(token, DECIMAL_MAX_VALUE) > 0)) {
/*     */           return;
/*     */         }
/* 115 */         computeValue(token, tokenLength, radix, j);
/*     */         break;
/*     */       case 8:
/* 118 */         if (tokenLength <= 12) {
/* 119 */           if (tokenLength == 12 && token[j] > '4') {
/*     */             return;
/*     */           }
/* 122 */           if (CharOperation.equals(token, OCTAL_MINUS_ONE_VALUE)) {
/* 123 */             this.constant = IntConstant.fromValue(-1);
/*     */             return;
/*     */           } 
/* 126 */           computeValue(token, tokenLength, radix, j);
/*     */           return;
/*     */         } 
/*     */         break;
/*     */     } 
/*     */   }
/*     */   
/*     */   private void computeValue(char[] token, int tokenLength, int radix, int j) {
/* 134 */     int computedValue = 0;
/* 135 */     while (j < tokenLength) {
/* 136 */       int digitValue; if ((digitValue = ScannerHelper.digit(token[j++], radix)) < 0) {
/*     */         return;
/*     */       }
/* 139 */       computedValue = computedValue * radix + digitValue;
/*     */     } 
/* 141 */     this.constant = IntConstant.fromValue(computedValue);
/*     */   }
/*     */   public IntLiteral convertToMinValue() {
/* 144 */     if ((this.bits & 0x1FE00000) >> 21 != 0) {
/* 145 */       return this;
/*     */     }
/* 147 */     char[] token = (this.reducedForm != null) ? this.reducedForm : this.source;
/* 148 */     switch (token.length) {
/*     */       
/*     */       case 10:
/* 151 */         if (CharOperation.equals(token, DECIMAL_MIN_VALUE)) {
/* 152 */           return new IntLiteralMinValue(this.source, this.reducedForm, this.sourceStart, this.sourceEnd);
/*     */         }
/*     */         break;
/*     */     } 
/* 156 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void generateCode(BlockScope currentScope, CodeStream codeStream, boolean valueRequired) {
/* 167 */     int pc = codeStream.position;
/* 168 */     if (valueRequired) {
/* 169 */       codeStream.generateConstant(this.constant, this.implicitConversion);
/*     */     }
/* 171 */     codeStream.recordPositionsFrom(pc, this.sourceStart);
/*     */   }
/*     */ 
/*     */   
/*     */   public TypeBinding literalType(BlockScope scope) {
/* 176 */     return (TypeBinding)TypeBinding.INT;
/*     */   }
/*     */   
/*     */   public void traverse(ASTVisitor visitor, BlockScope scope) {
/* 180 */     visitor.visit(this, scope);
/* 181 */     visitor.endVisit(this, scope);
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\ast\IntLiteral.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */