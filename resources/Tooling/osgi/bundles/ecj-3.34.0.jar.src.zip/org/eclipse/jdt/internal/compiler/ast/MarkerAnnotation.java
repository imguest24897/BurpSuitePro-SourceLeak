/*    */ package org.eclipse.jdt.internal.compiler.ast;
/*    */ 
/*    */ import org.eclipse.jdt.internal.compiler.ASTVisitor;
/*    */ import org.eclipse.jdt.internal.compiler.lookup.BlockScope;
/*    */ import org.eclipse.jdt.internal.compiler.lookup.ClassScope;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MarkerAnnotation
/*    */   extends Annotation
/*    */ {
/*    */   public MarkerAnnotation(TypeReference type, int sourceStart) {
/* 28 */     this.type = type;
/* 29 */     this.sourceStart = sourceStart;
/* 30 */     this.sourceEnd = type.sourceEnd;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public MemberValuePair[] memberValuePairs() {
/* 38 */     return NoValuePairs;
/*    */   }
/*    */ 
/*    */   
/*    */   public void traverse(ASTVisitor visitor, BlockScope scope) {
/* 43 */     if (visitor.visit(this, scope) && 
/* 44 */       this.type != null) {
/* 45 */       this.type.traverse(visitor, scope);
/*    */     }
/*    */     
/* 48 */     visitor.endVisit(this, scope);
/*    */   }
/*    */   
/*    */   public void traverse(ASTVisitor visitor, ClassScope scope) {
/* 52 */     if (visitor.visit(this, scope) && 
/* 53 */       this.type != null) {
/* 54 */       this.type.traverse(visitor, scope);
/*    */     }
/*    */     
/* 57 */     visitor.endVisit(this, scope);
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\ast\MarkerAnnotation.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */