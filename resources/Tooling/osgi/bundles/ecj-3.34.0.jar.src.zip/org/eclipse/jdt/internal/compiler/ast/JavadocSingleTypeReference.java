/*     */ package org.eclipse.jdt.internal.compiler.ast;
/*     */ 
/*     */ import org.eclipse.jdt.internal.compiler.ASTVisitor;
/*     */ import org.eclipse.jdt.internal.compiler.impl.Constant;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.Binding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.BlockScope;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.ClassScope;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.LocalTypeBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.ModuleBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.PackageBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.ProblemReferenceBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.ReferenceBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.Scope;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.TypeBinding;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JavadocSingleTypeReference
/*     */   extends SingleTypeReference
/*     */   implements IJavadocTypeReference
/*     */ {
/*     */   public int tagSourceStart;
/*     */   public int tagSourceEnd;
/*     */   public PackageBinding packageBinding;
/*     */   public ModuleBinding moduleBinding;
/*     */   private boolean canBeModule;
/*     */   
/*     */   public JavadocSingleTypeReference(char[] source, long pos, int tagStart, int tagEnd) {
/*  41 */     this(source, pos, tagStart, tagEnd, false);
/*     */   }
/*     */   
/*     */   public JavadocSingleTypeReference(char[] source, long pos, int tagStart, int tagEnd, boolean canBeModule) {
/*  45 */     super(source, pos);
/*  46 */     this.tagSourceStart = tagStart;
/*  47 */     this.tagSourceEnd = tagEnd;
/*  48 */     this.bits |= 0x8000;
/*  49 */     this.canBeModule = canBeModule;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected TypeBinding internalResolveType(Scope scope, int location) {
/*  58 */     this.constant = Constant.NotAConstant;
/*  59 */     if (this.resolvedType != null) {
/*  60 */       TypeBinding type; if (this.resolvedType.isValidBinding()) {
/*  61 */         return this.resolvedType;
/*     */       }
/*  63 */       switch (this.resolvedType.problemId()) {
/*     */         case 1:
/*     */         case 2:
/*     */         case 5:
/*  67 */           type = this.resolvedType.closestMatch();
/*  68 */           return type;
/*     */       } 
/*  70 */       return null;
/*     */     } 
/*     */ 
/*     */     
/*  74 */     this.resolvedType = getTypeBinding(scope);
/*  75 */     if (this.resolvedType instanceof LocalTypeBinding) {
/*     */       
/*  77 */       LocalTypeBinding localType = (LocalTypeBinding)this.resolvedType;
/*  78 */       if (localType.scope != null && localType.scope.parent == scope) {
/*  79 */         this.resolvedType = (TypeBinding)new ProblemReferenceBinding(new char[][] { localType.sourceName
/*  80 */             }, (ReferenceBinding)this.resolvedType, 1);
/*     */       }
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/*  86 */     if (this.resolvedType == null) return null;
/*     */     
/*  88 */     if (!this.resolvedType.isValidBinding()) {
/*  89 */       char[][] tokens = { this.token };
/*  90 */       Binding binding = scope.getTypeOrPackage(tokens);
/*  91 */       if (binding instanceof PackageBinding) {
/*  92 */         this.packageBinding = (PackageBinding)binding;
/*     */       } else {
/*     */         ModuleBinding moduleBinding;
/*  95 */         Binding modBinding = null;
/*  96 */         if (this.canBeModule) {
/*  97 */           moduleBinding = scope.environment().getModule(this.token);
/*     */         }
/*  99 */         if (moduleBinding instanceof ModuleBinding && 
/* 100 */           !moduleBinding.isUnnamed() && 
/* 101 */           moduleBinding.isValidBinding()) {
/* 102 */           this.moduleBinding = moduleBinding;
/*     */         } else {
/* 104 */           if (this.resolvedType.problemId() == 7) {
/* 105 */             TypeBinding closestMatch = this.resolvedType.closestMatch();
/* 106 */             if (closestMatch != null && closestMatch.isTypeVariable()) {
/* 107 */               this.resolvedType = closestMatch;
/* 108 */               return this.resolvedType;
/*     */             } 
/*     */           } 
/* 111 */           reportInvalidType(scope);
/*     */         } 
/*     */       } 
/* 114 */       return null;
/*     */     } 
/* 116 */     if (isTypeUseDeprecated(this.resolvedType, scope)) {
/* 117 */       reportDeprecatedType(this.resolvedType, scope);
/*     */     }
/*     */     
/* 120 */     if (this.resolvedType.isGenericType() || this.resolvedType.isParameterizedType()) {
/* 121 */       this.resolvedType = scope.environment().convertToRawType(this.resolvedType, true);
/*     */     }
/* 123 */     return this.resolvedType;
/*     */   }
/*     */   
/*     */   protected void reportDeprecatedType(TypeBinding type, Scope scope) {
/* 127 */     scope.problemReporter().javadocDeprecatedType(type, this, scope.getDeclarationModifiers());
/*     */   }
/*     */ 
/*     */   
/*     */   protected void reportInvalidType(Scope scope) {
/* 132 */     scope.problemReporter().javadocInvalidType(this, this.resolvedType, scope.getDeclarationModifiers());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void traverse(ASTVisitor visitor, BlockScope scope) {
/* 141 */     visitor.visit(this, scope);
/* 142 */     visitor.endVisit(this, scope);
/*     */   }
/*     */ 
/*     */   
/*     */   public void traverse(ASTVisitor visitor, ClassScope scope) {
/* 147 */     visitor.visit(this, scope);
/* 148 */     visitor.endVisit(this, scope);
/*     */   }
/*     */ 
/*     */   
/*     */   public int getTagSourceStart() {
/* 153 */     return this.tagSourceStart;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getTagSourceEnd() {
/* 158 */     return this.tagSourceEnd;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\ast\JavadocSingleTypeReference.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */