/*     */ package org.eclipse.jdt.internal.compiler.impl;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class IrritantSet
/*     */ {
/*     */   public static final int GROUP_MASK = -536870912;
/*     */   public static final int GROUP_SHIFT = 29;
/*     */   public static final int GROUP_MAX = 3;
/*     */   public static final int GROUP0 = 0;
/*     */   public static final int GROUP1 = 536870912;
/*     */   public static final int GROUP2 = 1073741824;
/*  51 */   public static final IrritantSet ALL = new IrritantSet(536870911);
/*  52 */   public static final IrritantSet BOXING = new IrritantSet(536871168);
/*  53 */   public static final IrritantSet CAST = new IrritantSet(67108864);
/*  54 */   public static final IrritantSet DEPRECATION = new IrritantSet(4);
/*  55 */   public static final IrritantSet TERMINAL_DEPRECATION = new IrritantSet(1082130432);
/*  56 */   public static final IrritantSet DEP_ANN = new IrritantSet(536879104);
/*  57 */   public static final IrritantSet FALLTHROUGH = new IrritantSet(537395200);
/*  58 */   public static final IrritantSet FINALLY = new IrritantSet(16777216);
/*  59 */   public static final IrritantSet HIDING = new IrritantSet(8);
/*  60 */   public static final IrritantSet INCOMPLETE_SWITCH = new IrritantSet(536875008);
/*  61 */   public static final IrritantSet NLS = new IrritantSet(256);
/*  62 */   public static final IrritantSet NULL = new IrritantSet(536871040);
/*  63 */   public static final IrritantSet RAW = new IrritantSet(536936448);
/*  64 */   public static final IrritantSet RESTRICTION = new IrritantSet(536870944);
/*  65 */   public static final IrritantSet SERIAL = new IrritantSet(536870920);
/*  66 */   public static final IrritantSet STATIC_ACCESS = new IrritantSet(268435456);
/*  67 */   public static final IrritantSet STATIC_METHOD = new IrritantSet(1073741840);
/*  68 */   public static final IrritantSet SYNTHETIC_ACCESS = new IrritantSet(128);
/*  69 */   public static final IrritantSet SYNCHRONIZED = new IrritantSet(805306368);
/*  70 */   public static final IrritantSet SUPER = new IrritantSet(537919488);
/*  71 */   public static final IrritantSet UNUSED = new IrritantSet(16);
/*  72 */   public static final IrritantSet UNCHECKED = new IrritantSet(536870914);
/*  73 */   public static final IrritantSet UNQUALIFIED_FIELD_ACCESS = new IrritantSet(4194304);
/*  74 */   public static final IrritantSet RESOURCE = new IrritantSet(1073741952);
/*  75 */   public static final IrritantSet UNLIKELY_ARGUMENT_TYPE = new IrritantSet(1075838976);
/*  76 */   public static final IrritantSet API_LEAK = new IrritantSet(1090519040);
/*  77 */   public static final IrritantSet MODULE = new IrritantSet(1107296256);
/*     */   
/*  79 */   public static final IrritantSet JAVADOC = new IrritantSet(33554432);
/*  80 */   public static final IrritantSet PREVIEW = new IrritantSet(1140850688);
/*  81 */   public static final IrritantSet COMPILER_DEFAULT_ERRORS = new IrritantSet(0);
/*  82 */   public static final IrritantSet COMPILER_DEFAULT_WARNINGS = new IrritantSet(0);
/*  83 */   public static final IrritantSet COMPILER_DEFAULT_INFOS = new IrritantSet(0);
/*     */   static {
/*  85 */     COMPILER_DEFAULT_INFOS
/*     */       
/*  87 */       .set(
/*  88 */         1480589312);
/*     */ 
/*     */ 
/*     */     
/*  92 */     COMPILER_DEFAULT_WARNINGS
/*     */       
/*  94 */       .set(
/*  95 */         16838239)
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 109 */       .set(
/* 110 */         721671934)
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 128 */       .set(
/* 129 */         1203384454);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 143 */     COMPILER_DEFAULT_ERRORS.set(
/* 144 */         1073744896);
/*     */ 
/*     */     
/* 147 */     ALL.setAll();
/* 148 */     HIDING
/* 149 */       .set(131072)
/* 150 */       .set(65536)
/* 151 */       .set(536871936);
/* 152 */     NULL
/* 153 */       .set(538968064)
/* 154 */       .set(541065216)
/* 155 */       .set(1073742848)
/* 156 */       .set(1073743872)
/* 157 */       .set(1073745920)
/* 158 */       .set(1073750016)
/* 159 */       .set(1073872896)
/* 160 */       .set(1073758208)
/* 161 */       .set(1074266112)
/* 162 */       .set(1074790400)
/* 163 */       .set(1342177280);
/*     */     
/* 165 */     RESTRICTION.set(536887296);
/* 166 */     STATIC_ACCESS.set(2048);
/* 167 */     UNUSED
/* 168 */       .set(32)
/* 169 */       .set(1074003968)
/* 170 */       .set(32768)
/* 171 */       .set(8388608)
/* 172 */       .set(537001984)
/* 173 */       .set(1024)
/* 174 */       .set(553648128)
/* 175 */       .set(603979776)
/* 176 */       .set(1073741826)
/* 177 */       .set(1073741832)
/* 178 */       .set(1073807360)
/* 179 */       .set(1073741888);
/* 180 */     STATIC_METHOD
/* 181 */       .set(1073741856);
/* 182 */     RESOURCE
/* 183 */       .set(1073742080)
/* 184 */       .set(1073742336);
/* 185 */     INCOMPLETE_SWITCH.set(1073774592);
/* 186 */     String suppressRawWhenUnchecked = System.getProperty("suppressRawWhenUnchecked");
/* 187 */     if (suppressRawWhenUnchecked != null && "true".equalsIgnoreCase(suppressRawWhenUnchecked)) {
/* 188 */       UNCHECKED.set(536936448);
/*     */     }
/*     */     
/* 191 */     JAVADOC
/* 192 */       .set(1048576)
/* 193 */       .set(2097152);
/*     */     
/* 195 */     UNLIKELY_ARGUMENT_TYPE
/* 196 */       .set(1077936128);
/*     */   }
/*     */ 
/*     */   
/* 200 */   private int[] bits = new int[3];
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IrritantSet(int singleGroupIrritants) {
/* 206 */     initialize(singleGroupIrritants);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IrritantSet(IrritantSet other) {
/* 213 */     initialize(other);
/*     */   }
/*     */   
/*     */   public boolean areAllSet() {
/* 217 */     for (int i = 0; i < 3; i++) {
/* 218 */       if (this.bits[i] != 536870911)
/* 219 */         return false; 
/*     */     } 
/* 221 */     return true;
/*     */   }
/*     */   
/*     */   public IrritantSet clear(int singleGroupIrritants) {
/* 225 */     int group = (singleGroupIrritants & 0xE0000000) >> 29;
/* 226 */     this.bits[group] = this.bits[group] & (singleGroupIrritants ^ 0xFFFFFFFF);
/* 227 */     return this;
/*     */   }
/*     */   
/*     */   public IrritantSet clearAll() {
/* 231 */     for (int i = 0; i < 3; i++) {
/* 232 */       this.bits[i] = 0;
/*     */     }
/* 234 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void initialize(int singleGroupIrritants) {
/* 243 */     if (singleGroupIrritants == 0)
/*     */       return; 
/* 245 */     int group = (singleGroupIrritants & 0xE0000000) >> 29;
/* 246 */     this.bits[group] = singleGroupIrritants & 0x1FFFFFFF;
/*     */   }
/*     */   
/*     */   public void initialize(IrritantSet other) {
/* 250 */     if (other == null)
/*     */       return; 
/* 252 */     System.arraycopy(other.bits, 0, this.bits = new int[3], 0, 3);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isAnySet(IrritantSet other) {
/* 260 */     if (other == null)
/* 261 */       return false; 
/* 262 */     for (int i = 0; i < 3; i++) {
/* 263 */       if ((this.bits[i] & other.bits[i]) != 0)
/* 264 */         return true; 
/*     */     } 
/* 266 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean hasSameIrritants(IrritantSet irritantSet) {
/* 274 */     if (irritantSet == null)
/* 275 */       return false; 
/* 276 */     for (int i = 0; i < 3; i++) {
/* 277 */       if (this.bits[i] != irritantSet.bits[i])
/* 278 */         return false; 
/*     */     } 
/* 280 */     return true;
/*     */   }
/*     */   
/*     */   public boolean isSet(int singleGroupIrritants) {
/* 284 */     int group = (singleGroupIrritants & 0xE0000000) >> 29;
/* 285 */     return ((this.bits[group] & singleGroupIrritants) != 0);
/*     */   }
/*     */   public int[] getBits() {
/* 288 */     return this.bits;
/*     */   }
/*     */   public IrritantSet set(int singleGroupIrritants) {
/* 291 */     int group = (singleGroupIrritants & 0xE0000000) >> 29;
/* 292 */     this.bits[group] = this.bits[group] | singleGroupIrritants & 0x1FFFFFFF;
/* 293 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IrritantSet set(IrritantSet other) {
/* 302 */     if (other == null)
/* 303 */       return this; 
/* 304 */     boolean wasNoOp = true;
/* 305 */     for (int i = 0; i < 3; i++) {
/* 306 */       int otherIrritant = other.bits[i] & 0x1FFFFFFF;
/*     */ 
/*     */       
/* 309 */       if ((this.bits[i] & otherIrritant) != otherIrritant) {
/* 310 */         wasNoOp = false;
/* 311 */         this.bits[i] = this.bits[i] | otherIrritant;
/*     */       } 
/*     */     } 
/* 314 */     return wasNoOp ? null : this;
/*     */   }
/*     */   
/*     */   public IrritantSet setAll() {
/* 318 */     for (int i = 0; i < 3; i++) {
/* 319 */       this.bits[i] = this.bits[i] | 0x1FFFFFFF;
/*     */     }
/*     */     
/* 322 */     return this;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\impl\IrritantSet.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */