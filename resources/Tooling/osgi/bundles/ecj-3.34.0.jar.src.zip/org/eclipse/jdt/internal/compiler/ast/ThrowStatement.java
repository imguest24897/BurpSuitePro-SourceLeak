/*     */ package org.eclipse.jdt.internal.compiler.ast;
/*     */ 
/*     */ import org.eclipse.jdt.internal.compiler.ASTVisitor;
/*     */ import org.eclipse.jdt.internal.compiler.codegen.CodeStream;
/*     */ import org.eclipse.jdt.internal.compiler.flow.FlowContext;
/*     */ import org.eclipse.jdt.internal.compiler.flow.FlowInfo;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.BlockScope;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.Scope;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.TypeBinding;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ThrowStatement
/*     */   extends Statement
/*     */ {
/*     */   public Expression exception;
/*     */   public TypeBinding exceptionType;
/*     */   
/*     */   public ThrowStatement(Expression exception, int sourceStart, int sourceEnd) {
/*  36 */     this.exception = exception;
/*  37 */     this.sourceStart = sourceStart;
/*  38 */     this.sourceEnd = sourceEnd;
/*     */   }
/*     */ 
/*     */   
/*     */   public FlowInfo analyseCode(BlockScope currentScope, FlowContext flowContext, FlowInfo flowInfo) {
/*  43 */     this.exception.analyseCode(currentScope, flowContext, flowInfo);
/*  44 */     this.exception.checkNPE(currentScope, flowContext, flowInfo);
/*     */     
/*  46 */     flowContext.checkExceptionHandlers(this.exceptionType, this, flowInfo, currentScope);
/*  47 */     currentScope.checkUnclosedCloseables(flowInfo, flowContext, this, currentScope);
/*  48 */     flowContext.recordAbruptExit();
/*  49 */     return (FlowInfo)FlowInfo.DEAD_END;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void generateCode(BlockScope currentScope, CodeStream codeStream) {
/*  60 */     if ((this.bits & Integer.MIN_VALUE) == 0)
/*     */       return; 
/*  62 */     int pc = codeStream.position;
/*  63 */     this.exception.generateCode(currentScope, codeStream, true);
/*  64 */     codeStream.athrow();
/*  65 */     codeStream.recordPositionsFrom(pc, this.sourceStart);
/*     */   }
/*     */ 
/*     */   
/*     */   public StringBuffer printStatement(int indent, StringBuffer output) {
/*  70 */     printIndent(indent, output).append("throw ");
/*  71 */     this.exception.printExpression(0, output);
/*  72 */     return output.append(';');
/*     */   }
/*     */ 
/*     */   
/*     */   public void resolve(BlockScope scope) {
/*  77 */     this.exceptionType = this.exception.resolveType(scope);
/*  78 */     if (this.exceptionType != null && this.exceptionType.isValidBinding()) {
/*  79 */       if (this.exceptionType == TypeBinding.NULL) {
/*  80 */         if ((scope.compilerOptions()).complianceLevel <= 3080192L)
/*     */         {
/*  82 */           scope.problemReporter().cannotThrowNull(this.exception);
/*     */         }
/*  84 */       } else if (this.exceptionType.findSuperTypeOriginatingFrom(21, true) == null) {
/*  85 */         scope.problemReporter().cannotThrowType(this.exception, this.exceptionType);
/*     */       } 
/*  87 */       this.exception.computeConversion((Scope)scope, this.exceptionType, this.exceptionType);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void traverse(ASTVisitor visitor, BlockScope blockScope) {
/*  93 */     if (visitor.visit(this, blockScope))
/*  94 */       this.exception.traverse(visitor, blockScope); 
/*  95 */     visitor.endVisit(this, blockScope);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean doesNotCompleteNormally() {
/* 100 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean canCompleteNormally() {
/* 105 */     return false;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\ast\ThrowStatement.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */