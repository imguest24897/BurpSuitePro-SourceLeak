/*      */ package org.eclipse.jdt.internal.compiler.flow;
/*      */ 
/*      */ import java.util.ArrayList;
/*      */ import org.eclipse.jdt.core.compiler.CharOperation;
/*      */ import org.eclipse.jdt.internal.compiler.ast.ASTNode;
/*      */ import org.eclipse.jdt.internal.compiler.ast.AbstractMethodDeclaration;
/*      */ import org.eclipse.jdt.internal.compiler.ast.Expression;
/*      */ import org.eclipse.jdt.internal.compiler.ast.FakedTrackingVariable;
/*      */ import org.eclipse.jdt.internal.compiler.ast.LabeledStatement;
/*      */ import org.eclipse.jdt.internal.compiler.ast.NullAnnotationMatching;
/*      */ import org.eclipse.jdt.internal.compiler.ast.Reference;
/*      */ import org.eclipse.jdt.internal.compiler.ast.SubRoutineStatement;
/*      */ import org.eclipse.jdt.internal.compiler.ast.ThrowStatement;
/*      */ import org.eclipse.jdt.internal.compiler.ast.TryStatement;
/*      */ import org.eclipse.jdt.internal.compiler.ast.TypeDeclaration;
/*      */ import org.eclipse.jdt.internal.compiler.codegen.BranchLabel;
/*      */ import org.eclipse.jdt.internal.compiler.lookup.Binding;
/*      */ import org.eclipse.jdt.internal.compiler.lookup.BlockScope;
/*      */ import org.eclipse.jdt.internal.compiler.lookup.CatchParameterBinding;
/*      */ import org.eclipse.jdt.internal.compiler.lookup.LocalVariableBinding;
/*      */ import org.eclipse.jdt.internal.compiler.lookup.ReferenceBinding;
/*      */ import org.eclipse.jdt.internal.compiler.lookup.Scope;
/*      */ import org.eclipse.jdt.internal.compiler.lookup.TypeBinding;
/*      */ import org.eclipse.jdt.internal.compiler.lookup.TypeConstants;
/*      */ import org.eclipse.jdt.internal.compiler.lookup.VariableBinding;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class FlowContext
/*      */   implements TypeConstants
/*      */ {
/*   67 */   public static final FlowContext NotContinuableContext = new FlowContext(null, null, true);
/*      */ 
/*      */ 
/*      */   
/*      */   public ASTNode associatedNode;
/*      */ 
/*      */   
/*      */   public FlowContext parent;
/*      */ 
/*      */   
/*      */   public FlowInfo initsOnFinally;
/*      */ 
/*      */   
/*   80 */   public int conditionalLevel = -1;
/*      */ 
/*      */   
/*      */   public int tagBits;
/*      */   
/*   85 */   public TypeBinding[][] providedExpectedTypes = null;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*   90 */   private Reference[] nullCheckedFieldReferences = null;
/*   91 */   private int[] timesToLiveForNullCheckInfo = null;
/*      */   
/*      */   public static final int DEFER_NULL_DIAGNOSTIC = 1;
/*      */   
/*      */   public static final int PREEMPT_NULL_DIAGNOSTIC = 2;
/*      */   
/*      */   public static final int INSIDE_NEGATION = 4;
/*      */   
/*      */   public static final int HIDE_NULL_COMPARISON_WARNING = 4096;
/*      */   
/*      */   public static final int HIDE_NULL_COMPARISON_WARNING_MASK = 61440;
/*      */   
/*      */   public static final int CAN_ONLY_NULL_NON_NULL = 0;
/*      */   
/*      */   public static final int CAN_ONLY_NULL = 1;
/*      */   
/*      */   public static final int CAN_ONLY_NON_NULL = 2;
/*      */   
/*      */   public static final int MAY_NULL = 3;
/*      */   
/*      */   public static final int ASSIGN_TO_NONNULL = 128;
/*      */   
/*      */   public static final int IN_UNBOXING = 16;
/*      */   
/*      */   public static final int EXIT_RESOURCE = 2048;
/*      */   
/*      */   public static final int CHECK_MASK = 255;
/*      */   
/*      */   public static final int IN_COMPARISON_NULL = 256;
/*      */   
/*      */   public static final int IN_COMPARISON_NON_NULL = 512;
/*      */   
/*      */   public static final int IN_ASSIGNMENT = 768;
/*      */   public static final int IN_INSTANCEOF = 1024;
/*      */   public static final int CONTEXT_MASK = -61696;
/*      */   
/*      */   public FlowContext(FlowContext parent, ASTNode associatedNode, boolean inheritNullFieldChecks) {
/*  128 */     this.parent = parent;
/*  129 */     this.associatedNode = associatedNode;
/*  130 */     if (parent != null) {
/*  131 */       if ((parent.tagBits & 0x3) != 0) {
/*  132 */         this.tagBits |= 0x1;
/*      */       }
/*  134 */       this.initsOnFinally = parent.initsOnFinally;
/*  135 */       this.conditionalLevel = parent.conditionalLevel;
/*  136 */       if (inheritNullFieldChecks)
/*  137 */         copyNullCheckedFieldsFrom(parent); 
/*      */     } 
/*      */   }
/*      */   
/*      */   public void copyNullCheckedFieldsFrom(FlowContext other) {
/*  142 */     Reference[] fieldReferences = other.nullCheckedFieldReferences;
/*  143 */     if (fieldReferences != null && fieldReferences.length > 0 && fieldReferences[0] != null) {
/*  144 */       this.nullCheckedFieldReferences = other.nullCheckedFieldReferences;
/*  145 */       this.timesToLiveForNullCheckInfo = other.timesToLiveForNullCheckInfo;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void recordNullCheckedFieldReference(Reference reference, int timeToLive) {
/*  156 */     if (this.nullCheckedFieldReferences == null) {
/*      */       
/*  158 */       this.nullCheckedFieldReferences = new Reference[] { reference };
/*  159 */       this.timesToLiveForNullCheckInfo = new int[] { timeToLive, -1 };
/*      */     } else {
/*  161 */       int len = this.nullCheckedFieldReferences.length;
/*      */       
/*  163 */       for (int i = 0; i < len; i++) {
/*  164 */         if (this.nullCheckedFieldReferences[i] == null) {
/*  165 */           this.nullCheckedFieldReferences[i] = reference;
/*  166 */           this.timesToLiveForNullCheckInfo[i] = timeToLive;
/*      */           
/*      */           return;
/*      */         } 
/*      */       } 
/*  171 */       System.arraycopy(this.nullCheckedFieldReferences, 0, this.nullCheckedFieldReferences = new Reference[len + 2], 0, len);
/*  172 */       System.arraycopy(this.timesToLiveForNullCheckInfo, 0, this.timesToLiveForNullCheckInfo = new int[len + 2], 0, len);
/*  173 */       this.nullCheckedFieldReferences[len] = reference;
/*  174 */       this.timesToLiveForNullCheckInfo[len] = timeToLive;
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public void extendTimeToLiveForNullCheckedField(int t) {
/*  180 */     if (this.timesToLiveForNullCheckInfo != null) {
/*  181 */       for (int i = 0; i < this.timesToLiveForNullCheckInfo.length; i++) {
/*  182 */         if (this.timesToLiveForNullCheckInfo[i] > 0) {
/*  183 */           this.timesToLiveForNullCheckInfo[i] = this.timesToLiveForNullCheckInfo[i] + t;
/*      */         }
/*      */       } 
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void expireNullCheckedFieldInfo() {
/*  194 */     if (this.nullCheckedFieldReferences != null) {
/*  195 */       for (int i = 0; i < this.nullCheckedFieldReferences.length; i++) {
/*  196 */         this.timesToLiveForNullCheckInfo[i] = this.timesToLiveForNullCheckInfo[i] - 1; if (this.timesToLiveForNullCheckInfo[i] - 1 == 0) {
/*  197 */           this.nullCheckedFieldReferences[i] = null;
/*      */         }
/*      */       } 
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isNullcheckedFieldAccess(Reference reference) {
/*  208 */     if (this.nullCheckedFieldReferences == null)
/*  209 */       return false; 
/*  210 */     int len = this.nullCheckedFieldReferences.length;
/*  211 */     for (int i = 0; i < len; i++) {
/*  212 */       Reference checked = this.nullCheckedFieldReferences[i];
/*  213 */       if (checked != null)
/*      */       {
/*      */         
/*  216 */         if (checked.isEquivalent(reference))
/*  217 */           return true; 
/*      */       }
/*      */     } 
/*  220 */     return false;
/*      */   }
/*      */   
/*      */   public BranchLabel breakLabel() {
/*  224 */     return null;
/*      */   }
/*      */   
/*      */   public void checkExceptionHandlers(TypeBinding raisedException, ASTNode location, FlowInfo flowInfo, BlockScope scope) {
/*  228 */     checkExceptionHandlers(raisedException, location, flowInfo, scope, false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void checkExceptionHandlers(TypeBinding raisedException, ASTNode location, FlowInfo flowInfo, BlockScope scope, boolean isExceptionOnAutoClose) {
/*  241 */     FlowContext traversedContext = this;
/*  242 */     ArrayList<LoopingFlowContext> abruptlyExitedLoops = null;
/*  243 */     if ((scope.compilerOptions()).sourceLevel >= 3342336L && location instanceof ThrowStatement) {
/*  244 */       Expression throwExpression = ((ThrowStatement)location).exception;
/*  245 */       LocalVariableBinding throwArgBinding = throwExpression.localVariableBinding();
/*  246 */       if (throwExpression instanceof org.eclipse.jdt.internal.compiler.ast.SingleNameReference && 
/*  247 */         throwArgBinding instanceof CatchParameterBinding && throwArgBinding.isEffectivelyFinal()) {
/*  248 */         CatchParameterBinding parameter = (CatchParameterBinding)throwArgBinding;
/*  249 */         checkExceptionHandlers(parameter.getPreciseTypes(), location, flowInfo, scope);
/*      */         return;
/*      */       } 
/*      */     } 
/*  253 */     while (traversedContext != null) {
/*      */       SubRoutineStatement sub;
/*  255 */       if ((sub = traversedContext.subroutine()) != null && sub.isSubRoutineEscaping()) {
/*      */         return;
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  263 */       if (traversedContext instanceof ExceptionHandlingFlowContext) {
/*  264 */         ExceptionHandlingFlowContext exceptionContext = 
/*  265 */           (ExceptionHandlingFlowContext)traversedContext;
/*      */         ReferenceBinding[] caughtExceptions;
/*  267 */         if ((caughtExceptions = exceptionContext.handledExceptions) != Binding.NO_EXCEPTIONS) {
/*  268 */           boolean definitelyCaught = false;
/*  269 */           for (int caughtIndex = 0, caughtCount = caughtExceptions.length; 
/*  270 */             caughtIndex < caughtCount; 
/*  271 */             caughtIndex++) {
/*  272 */             ReferenceBinding caughtException = caughtExceptions[caughtIndex];
/*  273 */             FlowInfo exceptionFlow = flowInfo;
/*  274 */             int state = (caughtException == null) ? 
/*  275 */               -1 : 
/*  276 */               Scope.compareTypes(raisedException, (TypeBinding)caughtException);
/*  277 */             if (abruptlyExitedLoops != null && caughtException != null && state != 0) {
/*  278 */               for (int i = 0, abruptlyExitedLoopsCount = abruptlyExitedLoops.size(); i < abruptlyExitedLoopsCount; i++) {
/*  279 */                 LoopingFlowContext loop = abruptlyExitedLoops.get(i);
/*  280 */                 loop.recordCatchContextOfEscapingException(exceptionContext, caughtException, flowInfo);
/*      */               } 
/*  282 */               exceptionFlow = FlowInfo.DEAD_END;
/*      */             } 
/*  284 */             switch (state) {
/*      */               case -1:
/*  286 */                 exceptionContext.recordHandlingException(
/*  287 */                     caughtException, 
/*  288 */                     exceptionFlow.unconditionalInits(), 
/*  289 */                     raisedException, 
/*  290 */                     raisedException, 
/*  291 */                     location, 
/*  292 */                     definitelyCaught);
/*      */                 
/*  294 */                 definitelyCaught = true;
/*      */                 break;
/*      */               case 1:
/*  297 */                 exceptionContext.recordHandlingException(
/*  298 */                     caughtException, 
/*  299 */                     exceptionFlow.unconditionalInits(), 
/*  300 */                     raisedException, 
/*  301 */                     (TypeBinding)caughtException, 
/*  302 */                     location, 
/*  303 */                     false);
/*      */                 break;
/*      */             } 
/*      */           } 
/*  307 */           if (definitelyCaught) {
/*      */             return;
/*      */           }
/*      */         } 
/*  311 */         if (exceptionContext.isMethodContext) {
/*  312 */           if (raisedException.isUncheckedException(false))
/*      */             return; 
/*  314 */           boolean shouldMergeUnhandledExceptions = exceptionContext instanceof ExceptionInferenceFlowContext;
/*      */ 
/*      */ 
/*      */           
/*  318 */           if (exceptionContext.associatedNode instanceof AbstractMethodDeclaration) {
/*  319 */             AbstractMethodDeclaration method = (AbstractMethodDeclaration)exceptionContext.associatedNode;
/*  320 */             if (method.isConstructor() && method.binding.declaringClass.isAnonymousType())
/*  321 */               shouldMergeUnhandledExceptions = true; 
/*      */           } 
/*  323 */           if (shouldMergeUnhandledExceptions) {
/*  324 */             exceptionContext.mergeUnhandledException(raisedException);
/*      */             return;
/*      */           } 
/*      */           break;
/*      */         } 
/*  329 */       } else if (traversedContext instanceof LoopingFlowContext) {
/*  330 */         if (abruptlyExitedLoops == null) {
/*  331 */           abruptlyExitedLoops = new ArrayList<>(5);
/*      */         }
/*  333 */         abruptlyExitedLoops.add(traversedContext);
/*      */       } 
/*      */       
/*  336 */       traversedContext.recordReturnFrom(flowInfo.unconditionalInits());
/*      */       
/*  338 */       if (!isExceptionOnAutoClose && 
/*  339 */         traversedContext instanceof InsideSubRoutineFlowContext) {
/*  340 */         ASTNode node = traversedContext.associatedNode;
/*  341 */         if (node instanceof TryStatement) {
/*  342 */           TryStatement tryStatement = (TryStatement)node;
/*  343 */           flowInfo.addInitializationsFrom(tryStatement.subRoutineInits);
/*      */         } 
/*      */       } 
/*      */       
/*  347 */       traversedContext = traversedContext.getLocalParent();
/*      */     } 
/*      */     
/*  350 */     if (isExceptionOnAutoClose) {
/*  351 */       scope.problemReporter().unhandledExceptionFromAutoClose(raisedException, location);
/*      */     } else {
/*  353 */       scope.problemReporter().unhandledException(raisedException, location);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void checkExceptionHandlers(TypeBinding[] raisedExceptions, ASTNode location, FlowInfo flowInfo, BlockScope scope) {
/*      */     int raisedCount;
/*  364 */     if (raisedExceptions == null || (
/*  365 */       raisedCount = raisedExceptions.length) == 0)
/*      */       return; 
/*  367 */     int remainingCount = raisedCount;
/*      */ 
/*      */ 
/*      */     
/*  371 */     System.arraycopy(
/*  372 */         raisedExceptions, 
/*  373 */         0, 
/*  374 */         raisedExceptions = new TypeBinding[raisedCount], 
/*  375 */         0, 
/*  376 */         raisedCount);
/*  377 */     FlowContext traversedContext = this;
/*      */     
/*  379 */     ArrayList<LoopingFlowContext> abruptlyExitedLoops = null;
/*  380 */     while (traversedContext != null) {
/*      */       SubRoutineStatement sub;
/*  382 */       if ((sub = traversedContext.subroutine()) != null && sub.isSubRoutineEscaping()) {
/*      */         return;
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  389 */       if (traversedContext instanceof ExceptionHandlingFlowContext) {
/*  390 */         ExceptionHandlingFlowContext exceptionContext = 
/*  391 */           (ExceptionHandlingFlowContext)traversedContext;
/*      */         ReferenceBinding[] caughtExceptions;
/*  393 */         if ((caughtExceptions = exceptionContext.handledExceptions) != Binding.NO_EXCEPTIONS) {
/*  394 */           int caughtCount = caughtExceptions.length;
/*  395 */           boolean[] locallyCaught = new boolean[raisedCount];
/*      */           
/*  397 */           for (int caughtIndex = 0; caughtIndex < caughtCount; caughtIndex++) {
/*  398 */             ReferenceBinding caughtException = caughtExceptions[caughtIndex];
/*  399 */             for (int raisedIndex = 0; raisedIndex < raisedCount; raisedIndex++) {
/*      */               TypeBinding raisedException;
/*  401 */               if ((raisedException = raisedExceptions[raisedIndex]) != null) {
/*  402 */                 FlowInfo exceptionFlow = flowInfo;
/*  403 */                 int state = (caughtException == null) ? 
/*  404 */                   -1 : 
/*  405 */                   Scope.compareTypes(raisedException, (TypeBinding)caughtException);
/*  406 */                 if (abruptlyExitedLoops != null && caughtException != null && state != 0) {
/*  407 */                   for (int k = 0, abruptlyExitedLoopsCount = abruptlyExitedLoops.size(); k < abruptlyExitedLoopsCount; k++) {
/*  408 */                     LoopingFlowContext loop = abruptlyExitedLoops.get(k);
/*  409 */                     loop.recordCatchContextOfEscapingException(exceptionContext, caughtException, flowInfo);
/*      */                   } 
/*  411 */                   exceptionFlow = FlowInfo.DEAD_END;
/*      */                 } 
/*  413 */                 switch (state) {
/*      */                   case -1:
/*  415 */                     exceptionContext.recordHandlingException(
/*  416 */                         caughtException, 
/*  417 */                         exceptionFlow.unconditionalInits(), 
/*  418 */                         raisedException, 
/*  419 */                         raisedException, 
/*  420 */                         location, 
/*  421 */                         locallyCaught[raisedIndex]);
/*      */                     
/*  423 */                     if (!locallyCaught[raisedIndex]) {
/*  424 */                       locallyCaught[raisedIndex] = true;
/*      */                       
/*  426 */                       remainingCount--;
/*      */                     } 
/*      */                     break;
/*      */                   case 1:
/*  430 */                     exceptionContext.recordHandlingException(
/*  431 */                         caughtException, 
/*  432 */                         exceptionFlow.unconditionalInits(), 
/*  433 */                         raisedException, 
/*  434 */                         (TypeBinding)caughtException, 
/*  435 */                         location, 
/*  436 */                         false);
/*      */                     break;
/*      */                 } 
/*      */               
/*      */               } 
/*      */             } 
/*      */           } 
/*  443 */           for (int j = 0; j < raisedCount; j++) {
/*  444 */             if (locallyCaught[j]) {
/*  445 */               raisedExceptions[j] = null;
/*      */             }
/*      */           } 
/*      */         } 
/*      */         
/*  450 */         if (exceptionContext.isMethodContext) {
/*  451 */           for (int j = 0; j < raisedCount; j++) {
/*      */             TypeBinding raisedException;
/*  453 */             if ((raisedException = raisedExceptions[j]) != null && 
/*  454 */               raisedException.isUncheckedException(false)) {
/*  455 */               remainingCount--;
/*  456 */               raisedExceptions[j] = null;
/*      */             } 
/*      */           } 
/*      */           
/*  460 */           boolean shouldMergeUnhandledException = exceptionContext instanceof ExceptionInferenceFlowContext;
/*      */ 
/*      */           
/*  463 */           if (exceptionContext.associatedNode instanceof AbstractMethodDeclaration) {
/*  464 */             AbstractMethodDeclaration method = (AbstractMethodDeclaration)exceptionContext.associatedNode;
/*  465 */             if (method.isConstructor() && method.binding.declaringClass.isAnonymousType())
/*  466 */               shouldMergeUnhandledException = true; 
/*      */           } 
/*  468 */           if (shouldMergeUnhandledException) {
/*  469 */             for (int k = 0; k < raisedCount; k++) {
/*      */               TypeBinding raisedException;
/*  471 */               if ((raisedException = raisedExceptions[k]) != null) {
/*  472 */                 exceptionContext.mergeUnhandledException(raisedException);
/*      */               }
/*      */             } 
/*      */             return;
/*      */           } 
/*      */           break;
/*      */         } 
/*  479 */       } else if (traversedContext instanceof LoopingFlowContext) {
/*  480 */         if (abruptlyExitedLoops == null) {
/*  481 */           abruptlyExitedLoops = new ArrayList<>(5);
/*      */         }
/*  483 */         abruptlyExitedLoops.add(traversedContext);
/*      */       } 
/*  485 */       if (remainingCount == 0) {
/*      */         return;
/*      */       }
/*  488 */       traversedContext.recordReturnFrom(flowInfo.unconditionalInits());
/*      */       
/*  490 */       if (traversedContext instanceof InsideSubRoutineFlowContext) {
/*  491 */         ASTNode node = traversedContext.associatedNode;
/*  492 */         if (node instanceof TryStatement) {
/*  493 */           TryStatement tryStatement = (TryStatement)node;
/*  494 */           flowInfo.addInitializationsFrom(tryStatement.subRoutineInits);
/*      */         } 
/*      */       } 
/*  497 */       traversedContext = traversedContext.getLocalParent();
/*      */     } 
/*      */     
/*  500 */     for (int i = 0; i < raisedCount; i++) {
/*      */       TypeBinding exception;
/*  502 */       if ((exception = raisedExceptions[i]) != null) {
/*      */         
/*  504 */         int j = 0; while (true) { if (j >= i) {
/*      */ 
/*      */             
/*  507 */             scope.problemReporter().unhandledException(exception, location); break;
/*      */           }  if (TypeBinding.equalsEquals(raisedExceptions[j], exception))
/*      */             break; 
/*      */           j++; }
/*      */       
/*      */       } 
/*  513 */     }  } public BranchLabel continueLabel() { return null; }
/*      */ 
/*      */   
/*      */   public FlowInfo getInitsForFinalBlankInitializationCheck(TypeBinding declaringType, FlowInfo flowInfo) {
/*  517 */     FlowContext current = this;
/*  518 */     FlowInfo inits = flowInfo;
/*      */     do {
/*  520 */       if (current instanceof InitializationFlowContext) {
/*  521 */         InitializationFlowContext initializationContext = (InitializationFlowContext)current;
/*  522 */         if (TypeBinding.equalsEquals((TypeBinding)((TypeDeclaration)initializationContext.associatedNode).binding, declaringType)) {
/*  523 */           return inits;
/*      */         }
/*  525 */         inits = initializationContext.initsBeforeContext;
/*  526 */         current = initializationContext.initializationParent;
/*  527 */       } else if (current instanceof ExceptionHandlingFlowContext) {
/*  528 */         if (current instanceof FieldInitsFakingFlowContext) {
/*  529 */           return FlowInfo.DEAD_END;
/*      */         }
/*  531 */         ExceptionHandlingFlowContext exceptionContext = (ExceptionHandlingFlowContext)current;
/*  532 */         current = (exceptionContext.initializationParent == null) ? exceptionContext.parent : exceptionContext.initializationParent;
/*      */       } else {
/*  534 */         current = current.getLocalParent();
/*      */       } 
/*  536 */     } while (current != null);
/*      */     
/*  538 */     throw new IllegalStateException(declaringType.debugName());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public FlowContext getTargetContextForBreakLabel(char[] labelName) {
/*  545 */     FlowContext current = this, lastNonReturningSubRoutine = null;
/*  546 */     while (current != null) {
/*  547 */       if (current.isNonReturningContext()) {
/*  548 */         lastNonReturningSubRoutine = current;
/*      */       }
/*      */       char[] currentLabelName;
/*  551 */       if ((currentLabelName = current.labelName()) != null && 
/*  552 */         CharOperation.equals(currentLabelName, labelName)) {
/*  553 */         ((LabeledStatement)current.associatedNode).bits |= 0x40;
/*  554 */         if (lastNonReturningSubRoutine == null)
/*  555 */           return current; 
/*  556 */         return lastNonReturningSubRoutine;
/*      */       } 
/*  558 */       current = current.getLocalParent();
/*      */     } 
/*      */     
/*  561 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public FlowContext getTargetContextForContinueLabel(char[] labelName) {
/*  568 */     FlowContext current = this;
/*  569 */     FlowContext lastContinuable = null;
/*  570 */     FlowContext lastNonReturningSubRoutine = null;
/*      */     
/*  572 */     while (current != null) {
/*  573 */       if (current.isNonReturningContext()) {
/*  574 */         lastNonReturningSubRoutine = current;
/*      */       }
/*  576 */       else if (current.isContinuable()) {
/*  577 */         lastContinuable = current;
/*      */       } 
/*      */       
/*      */       char[] currentLabelName;
/*      */       
/*  582 */       if ((currentLabelName = current.labelName()) != null && CharOperation.equals(currentLabelName, labelName)) {
/*  583 */         ((LabeledStatement)current.associatedNode).bits |= 0x40;
/*      */ 
/*      */         
/*  586 */         if (lastContinuable != null && 
/*  587 */           current.associatedNode.concreteStatement() == lastContinuable.associatedNode) {
/*      */           
/*  589 */           if (lastNonReturningSubRoutine == null) return lastContinuable; 
/*  590 */           return lastNonReturningSubRoutine;
/*      */         } 
/*      */         
/*  593 */         return NotContinuableContext;
/*      */       } 
/*  595 */       current = current.getLocalParent();
/*      */     } 
/*      */     
/*  598 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public FlowContext getTargetContextForDefaultBreak() {
/*  605 */     FlowContext current = this, lastNonReturningSubRoutine = null;
/*  606 */     while (current != null) {
/*  607 */       if (current.isNonReturningContext()) {
/*  608 */         lastNonReturningSubRoutine = current;
/*      */       }
/*  610 */       if (current.isBreakable() && current.labelName() == null) {
/*  611 */         if (lastNonReturningSubRoutine == null) return current; 
/*  612 */         return lastNonReturningSubRoutine;
/*      */       } 
/*  614 */       current = current.getLocalParent();
/*      */     } 
/*      */     
/*  617 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public FlowContext getTargetContextForDefaultYield() {
/*  623 */     FlowContext current = this, lastNonReturningSubRoutine = null;
/*  624 */     while (current != null) {
/*  625 */       if (current.isNonReturningContext()) {
/*  626 */         lastNonReturningSubRoutine = current;
/*      */       }
/*  628 */       if (current.isBreakable() && current.labelName() == null && ((SwitchFlowContext)current).isExpression) {
/*  629 */         if (lastNonReturningSubRoutine == null) return current; 
/*  630 */         return lastNonReturningSubRoutine;
/*      */       } 
/*  632 */       current = current.getLocalParent();
/*      */     } 
/*      */     
/*  635 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public FlowContext getTargetContextForDefaultContinue() {
/*  642 */     FlowContext current = this, lastNonReturningSubRoutine = null;
/*  643 */     while (current != null) {
/*  644 */       if (current.isNonReturningContext()) {
/*  645 */         lastNonReturningSubRoutine = current;
/*      */       }
/*  647 */       if (current.isContinuable()) {
/*  648 */         if (lastNonReturningSubRoutine == null)
/*  649 */           return current; 
/*  650 */         return lastNonReturningSubRoutine;
/*      */       } 
/*  652 */       current = current.getLocalParent();
/*      */     } 
/*      */     
/*  655 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public FlowContext getInitializationContext() {
/*  662 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public FlowContext getLocalParent() {
/*  670 */     if (this.associatedNode instanceof AbstractMethodDeclaration || this.associatedNode instanceof TypeDeclaration || this.associatedNode instanceof org.eclipse.jdt.internal.compiler.ast.LambdaExpression)
/*  671 */       return null; 
/*  672 */     return this.parent;
/*      */   }
/*      */   
/*      */   public String individualToString() {
/*  676 */     return "Flow context";
/*      */   }
/*      */   
/*      */   public FlowInfo initsOnBreak() {
/*  680 */     return FlowInfo.DEAD_END;
/*      */   }
/*      */   
/*      */   public UnconditionalFlowInfo initsOnReturn() {
/*  684 */     return FlowInfo.DEAD_END;
/*      */   }
/*      */   
/*      */   public boolean isBreakable() {
/*  688 */     return false;
/*      */   }
/*      */   
/*      */   public boolean isContinuable() {
/*  692 */     return false;
/*      */   }
/*      */   
/*      */   public boolean isNonReturningContext() {
/*  696 */     return false;
/*      */   }
/*      */   
/*      */   public boolean isSubRoutine() {
/*  700 */     return false;
/*      */   }
/*      */   
/*      */   public char[] labelName() {
/*  704 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void markFinallyNullStatus(LocalVariableBinding local, int nullStatus) {
/*  713 */     if (this.initsOnFinally == null)
/*  714 */       return;  if (this.conditionalLevel == -1)
/*  715 */       return;  if (this.conditionalLevel == 0) {
/*      */       
/*  717 */       this.initsOnFinally.markNullStatus(local, nullStatus);
/*      */       
/*      */       return;
/*      */     } 
/*  721 */     UnconditionalFlowInfo newInfo = this.initsOnFinally.unconditionalCopy();
/*  722 */     newInfo.markNullStatus(local, nullStatus);
/*  723 */     this.initsOnFinally = this.initsOnFinally.mergedWith(newInfo);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void mergeFinallyNullInfo(FlowInfo flowInfo) {
/*  733 */     if (this.initsOnFinally == null)
/*  734 */       return;  if (this.conditionalLevel == -1)
/*  735 */       return;  if (this.conditionalLevel == 0) {
/*      */       
/*  737 */       this.initsOnFinally.addNullInfoFrom(flowInfo);
/*      */       
/*      */       return;
/*      */     } 
/*  741 */     this.initsOnFinally = this.initsOnFinally.mergedWith(flowInfo.unconditionalCopy());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void recordAbruptExit() {
/*  752 */     if (this.conditionalLevel > -1) {
/*  753 */       this.conditionalLevel++;
/*      */       
/*  755 */       if (!(this instanceof ExceptionHandlingFlowContext) && this.parent != null) {
/*  756 */         this.parent.recordAbruptExit();
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void recordBreakFrom(FlowInfo flowInfo) {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void recordBreakTo(FlowContext targetContext) {}
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void recordContinueFrom(FlowContext innerFlowContext, FlowInfo flowInfo) {}
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean recordExitAgainstResource(BlockScope scope, FlowInfo flowInfo, FakedTrackingVariable trackingVar, ASTNode reference) {
/*  782 */     return false;
/*      */   }
/*      */   
/*      */   protected void recordProvidedExpectedTypes(TypeBinding providedType, TypeBinding expectedType, int nullCount) {
/*  786 */     if (nullCount == 0) {
/*  787 */       this.providedExpectedTypes = new TypeBinding[5][];
/*  788 */     } else if (this.providedExpectedTypes == null) {
/*  789 */       int size = 5;
/*  790 */       for (; size <= nullCount; size *= 2);
/*  791 */       this.providedExpectedTypes = new TypeBinding[size][];
/*      */     }
/*  793 */     else if (nullCount >= this.providedExpectedTypes.length) {
/*  794 */       int oldLen = this.providedExpectedTypes.length;
/*  795 */       System.arraycopy(this.providedExpectedTypes, 0, 
/*  796 */           this.providedExpectedTypes = new TypeBinding[nullCount * 2][], 0, oldLen);
/*      */     } 
/*  798 */     (new TypeBinding[2])[0] = providedType; (new TypeBinding[2])[1] = expectedType; this.providedExpectedTypes[nullCount] = new TypeBinding[2];
/*      */   }
/*      */   
/*      */   protected boolean recordFinalAssignment(VariableBinding variable, Reference finalReference) {
/*  802 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final void recordNullReference(LocalVariableBinding local, ASTNode location, int checkType, FlowInfo nullInfo) {
/*  825 */     recordNullReferenceWithAnnotationStatus(local, location, checkType, nullInfo, null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void recordNullReferenceWithAnnotationStatus(LocalVariableBinding local, ASTNode location, int checkType, FlowInfo nullInfo, NullAnnotationMatching nullAnnotationStatus) {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void recordUnboxing(Scope scope, Expression expression, int nullStatus, FlowInfo flowInfo) {
/*  860 */     checkUnboxing(scope, expression, flowInfo);
/*      */   }
/*      */   
/*      */   protected void checkUnboxing(Scope scope, Expression expression, FlowInfo flowInfo) {
/*  864 */     int status = expression.nullStatus(flowInfo, this);
/*  865 */     if ((status & 0x2) != 0) {
/*  866 */       scope.problemReporter().nullUnboxing((ASTNode)expression, expression.resolvedType); return;
/*      */     } 
/*  868 */     if ((status & 0x10) != 0) {
/*  869 */       scope.problemReporter().potentialNullUnboxing((ASTNode)expression, expression.resolvedType); return;
/*      */     } 
/*  871 */     if ((status & 0x4) != 0) {
/*      */       return;
/*      */     }
/*      */     
/*  875 */     if (this.parent != null) {
/*  876 */       this.parent.recordUnboxing(scope, expression, 1, flowInfo);
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   public void recordReturnFrom(UnconditionalFlowInfo flowInfo) {}
/*      */ 
/*      */   
/*      */   public void recordSettingFinal(VariableBinding variable, Reference finalReference, FlowInfo flowInfo) {
/*  885 */     if ((flowInfo.tagBits & 0x1) == 0) {
/*      */       
/*  887 */       FlowContext context = this;
/*  888 */       while (context != null && 
/*  889 */         context.recordFinalAssignment(variable, finalReference))
/*      */       {
/*      */         
/*  892 */         context = context.getLocalParent();
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void recordUsingNullReference(Scope scope, LocalVariableBinding local, ASTNode location, int checkType, FlowInfo flowInfo) {
/*      */     Expression reference;
/*  924 */     if ((flowInfo.tagBits & 0x3) != 0 || 
/*  925 */       flowInfo.isDefinitelyUnknown(local)) {
/*      */       return;
/*      */     }
/*      */     
/*  929 */     checkType |= this.tagBits & 0x1000;
/*  930 */     int checkTypeWithoutHideNullWarning = checkType & 0xFFFF0FFF;
/*  931 */     switch (checkTypeWithoutHideNullWarning) {
/*      */       case 256:
/*      */       case 512:
/*  934 */         if (flowInfo.isDefinitelyNonNull(local)) {
/*  935 */           if (checkTypeWithoutHideNullWarning == 512) {
/*  936 */             if ((checkType & 0x1000) == 0) {
/*  937 */               scope.problemReporter().localVariableRedundantCheckOnNonNull(local, location);
/*      */             }
/*  939 */             flowInfo.initsWhenFalse().setReachMode(2);
/*      */           } else {
/*  941 */             scope.problemReporter().localVariableNonNullComparedToNull(local, location);
/*  942 */             flowInfo.initsWhenTrue().setReachMode(2);
/*      */           } 
/*      */           return;
/*      */         } 
/*  946 */         if (flowInfo.cannotBeDefinitelyNullOrNonNull(local)) {
/*      */           return;
/*      */         }
/*      */       
/*      */       case 257:
/*      */       case 513:
/*      */       case 769:
/*      */       case 1025:
/*  954 */         reference = (Expression)location;
/*  955 */         if (flowInfo.isDefinitelyNull(local)) {
/*  956 */           switch (checkTypeWithoutHideNullWarning & 0xFFFF0F00) {
/*      */             case 256:
/*  958 */               if ((checkTypeWithoutHideNullWarning & 0xFF) == 1 && (reference.implicitConversion & 0x400) != 0) {
/*  959 */                 scope.problemReporter().localVariableNullReference(local, (ASTNode)reference);
/*      */                 return;
/*      */               } 
/*  962 */               if ((checkType & 0x1000) == 0) {
/*  963 */                 scope.problemReporter().localVariableRedundantCheckOnNull(local, (ASTNode)reference);
/*      */               }
/*  965 */               flowInfo.initsWhenFalse().setReachMode(2);
/*      */               return;
/*      */             case 512:
/*  968 */               if ((checkTypeWithoutHideNullWarning & 0xFF) == 1 && (reference.implicitConversion & 0x400) != 0) {
/*  969 */                 scope.problemReporter().localVariableNullReference(local, (ASTNode)reference);
/*      */                 return;
/*      */               } 
/*  972 */               scope.problemReporter().localVariableNullComparedToNonNull(local, (ASTNode)reference);
/*  973 */               flowInfo.initsWhenTrue().setReachMode(2);
/*      */               return;
/*      */             case 768:
/*  976 */               scope.problemReporter().localVariableRedundantNullAssignment(local, (ASTNode)reference);
/*      */               return;
/*      */             case 1024:
/*  979 */               scope.problemReporter().localVariableNullInstanceof(local, (ASTNode)reference); return;
/*      */           }  break;
/*      */         } 
/*  982 */         if (flowInfo.isPotentiallyNull(local)) {
/*  983 */           switch (checkTypeWithoutHideNullWarning & 0xFFFF0F00) {
/*      */             case 256:
/*  985 */               if ((checkTypeWithoutHideNullWarning & 0xFF) == 1 && (reference.implicitConversion & 0x400) != 0) {
/*  986 */                 scope.problemReporter().localVariablePotentialNullReference(local, (ASTNode)reference);
/*      */                 return;
/*      */               } 
/*      */               break;
/*      */             case 512:
/*  991 */               if ((checkTypeWithoutHideNullWarning & 0xFF) == 1 && (reference.implicitConversion & 0x400) != 0) {
/*  992 */                 scope.problemReporter().localVariablePotentialNullReference(local, (ASTNode)reference); return;
/*      */               }  break;
/*      */           } 
/*      */           break;
/*      */         } 
/*  997 */         if (flowInfo.cannotBeDefinitelyNullOrNonNull(local)) {
/*      */           return;
/*      */         }
/*      */         break;
/*      */       case 3:
/* 1002 */         if (flowInfo.isDefinitelyNull(local)) {
/* 1003 */           scope.problemReporter().localVariableNullReference(local, location);
/*      */           return;
/*      */         } 
/* 1006 */         if (flowInfo.isPotentiallyNull(local)) {
/* 1007 */           if (local.type.isFreeTypeVariable()) {
/* 1008 */             scope.problemReporter().localVariableFreeTypeVariableReference(local, location);
/*      */             return;
/*      */           } 
/* 1011 */           scope.problemReporter().localVariablePotentialNullReference(local, location);
/*      */           return;
/*      */         } 
/*      */         break;
/*      */     } 
/*      */ 
/*      */     
/* 1018 */     if (this.parent != null) {
/* 1019 */       this.parent.recordUsingNullReference(scope, local, location, checkType, 
/* 1020 */           flowInfo);
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   void removeFinalAssignmentIfAny(Reference reference) {}
/*      */ 
/*      */   
/*      */   public SubRoutineStatement subroutine() {
/* 1029 */     return null;
/*      */   }
/*      */ 
/*      */   
/*      */   public String toString() {
/* 1034 */     StringBuilder buffer = new StringBuilder();
/* 1035 */     FlowContext current = this;
/* 1036 */     int parentsCount = 0;
/* 1037 */     while ((current = current.parent) != null) {
/* 1038 */       parentsCount++;
/*      */     }
/* 1040 */     FlowContext[] parents = new FlowContext[parentsCount + 1];
/* 1041 */     current = this;
/* 1042 */     int index = parentsCount;
/* 1043 */     while (index >= 0) {
/* 1044 */       parents[index--] = current;
/* 1045 */       current = current.parent;
/*      */     } 
/* 1047 */     for (int i = 0; i < parentsCount; i++) {
/* 1048 */       for (int k = 0; k < i; k++)
/* 1049 */         buffer.append('\t'); 
/* 1050 */       buffer.append(parents[i].individualToString()).append('\n');
/*      */     } 
/* 1052 */     buffer.append('*');
/* 1053 */     for (int j = 0; j < parentsCount + 1; j++)
/* 1054 */       buffer.append('\t'); 
/* 1055 */     buffer.append(individualToString()).append('\n');
/* 1056 */     return buffer.toString();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void recordNullityMismatch(BlockScope currentScope, Expression expression, TypeBinding providedType, TypeBinding expectedType, FlowInfo flowInfo, int nullStatus, NullAnnotationMatching annotationStatus) {
/* 1070 */     if (providedType == null) {
/*      */       return;
/*      */     }
/* 1073 */     if (expression.localVariableBinding() != null) {
/*      */       
/* 1075 */       FlowContext currentContext = this;
/* 1076 */       while (currentContext != null) {
/*      */         
/* 1078 */         int isInsideAssert = 0;
/* 1079 */         if ((this.tagBits & 0x1000) != 0) {
/* 1080 */           isInsideAssert = 4096;
/*      */         }
/* 1082 */         if (currentContext.internalRecordNullityMismatch(expression, providedType, flowInfo, nullStatus, annotationStatus, expectedType, 0x80 | isInsideAssert))
/*      */           return; 
/* 1084 */         currentContext = currentContext.parent;
/*      */       } 
/*      */     } 
/*      */     
/* 1088 */     if (annotationStatus != null) {
/* 1089 */       currentScope.problemReporter().nullityMismatchingTypeAnnotation(expression, providedType, expectedType, annotationStatus);
/*      */     } else {
/* 1091 */       currentScope.problemReporter().nullityMismatch(expression, providedType, expectedType, nullStatus, 
/* 1092 */           currentScope.environment().getNonNullAnnotationName());
/*      */     } 
/*      */   }
/*      */   protected boolean internalRecordNullityMismatch(Expression expression, TypeBinding providedType, FlowInfo flowInfo, int nullStatus, NullAnnotationMatching nullAnnotationStatus, TypeBinding expectedType, int checkType) {
/* 1096 */     return false;
/*      */   }
/*      */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\flow\FlowContext.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */