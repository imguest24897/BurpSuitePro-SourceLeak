/*     */ package org.eclipse.jdt.internal.compiler.ast;
/*     */ 
/*     */ import org.eclipse.jdt.core.compiler.CharOperation;
/*     */ import org.eclipse.jdt.internal.compiler.ASTVisitor;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.BlockScope;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.ClassScope;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.LookupEnvironment;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.Scope;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.TypeBinding;
/*     */ import org.eclipse.jdt.internal.compiler.problem.AbortCompilation;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ArrayQualifiedTypeReference
/*     */   extends QualifiedTypeReference
/*     */ {
/*     */   int dimensions;
/*     */   private Annotation[][] annotationsOnDimensions;
/*     */   public int extendedDimensions;
/*     */   
/*     */   public ArrayQualifiedTypeReference(char[][] sources, int dim, long[] poss) {
/*  30 */     super(sources, poss);
/*  31 */     this.dimensions = dim;
/*  32 */     this.annotationsOnDimensions = null;
/*     */   }
/*     */   
/*     */   public ArrayQualifiedTypeReference(char[][] sources, int dim, Annotation[][] annotationsOnDimensions, long[] poss) {
/*  36 */     this(sources, dim, poss);
/*  37 */     this.annotationsOnDimensions = annotationsOnDimensions;
/*  38 */     if (annotationsOnDimensions != null) {
/*  39 */       this.bits |= 0x100000;
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public int dimensions() {
/*  45 */     return this.dimensions;
/*     */   }
/*     */ 
/*     */   
/*     */   public int extraDimensions() {
/*  50 */     return this.extendedDimensions;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Annotation[][] getAnnotationsOnDimensions(boolean useSourceOrder) {
/*  58 */     if (useSourceOrder || this.annotationsOnDimensions == null || this.annotationsOnDimensions.length == 0 || this.extendedDimensions == 0 || this.extendedDimensions == this.dimensions)
/*  59 */       return this.annotationsOnDimensions; 
/*  60 */     Annotation[][] externalAnnotations = new Annotation[this.dimensions][];
/*  61 */     int baseDimensions = this.dimensions - this.extendedDimensions;
/*  62 */     System.arraycopy(this.annotationsOnDimensions, baseDimensions, externalAnnotations, 0, this.extendedDimensions);
/*  63 */     System.arraycopy(this.annotationsOnDimensions, 0, externalAnnotations, this.extendedDimensions, baseDimensions);
/*  64 */     return externalAnnotations;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setAnnotationsOnDimensions(Annotation[][] annotationsOnDimensions) {
/*  69 */     this.annotationsOnDimensions = annotationsOnDimensions;
/*     */   }
/*     */ 
/*     */   
/*     */   public Annotation[] getTopAnnotations() {
/*  74 */     if (this.annotationsOnDimensions != null)
/*  75 */       return this.annotationsOnDimensions[0]; 
/*  76 */     return new Annotation[0];
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public char[][] getParameterizedTypeName() {
/*  84 */     int dim = this.dimensions;
/*  85 */     char[] dimChars = new char[dim * 2];
/*  86 */     for (int i = 0; i < dim; i++) {
/*  87 */       int index = i * 2;
/*  88 */       dimChars[index] = '[';
/*  89 */       dimChars[index + 1] = ']';
/*     */     } 
/*  91 */     int length = this.tokens.length;
/*  92 */     char[][] qParamName = new char[length][];
/*  93 */     System.arraycopy(this.tokens, 0, qParamName, 0, length - 1);
/*  94 */     qParamName[length - 1] = CharOperation.concat(this.tokens[length - 1], dimChars);
/*  95 */     return qParamName;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected TypeBinding getTypeBinding(Scope scope) {
/* 101 */     if (this.resolvedType != null)
/* 102 */       return this.resolvedType; 
/* 103 */     if (this.dimensions > 255) {
/* 104 */       scope.problemReporter().tooManyDimensions(this);
/*     */     }
/* 106 */     LookupEnvironment env = scope.environment();
/*     */     try {
/* 108 */       env.missingClassFileLocation = this;
/* 109 */       TypeBinding leafComponentType = super.getTypeBinding(scope);
/* 110 */       if (leafComponentType != null) {
/* 111 */         return this.resolvedType = (TypeBinding)scope.createArrayType(leafComponentType, this.dimensions);
/*     */       }
/* 113 */       return null;
/* 114 */     } catch (AbortCompilation e) {
/* 115 */       e.updateContext(this, (scope.referenceCompilationUnit()).compilationResult);
/* 116 */       throw e;
/*     */     } finally {
/* 118 */       env.missingClassFileLocation = null;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   protected TypeBinding internalResolveType(Scope scope, int location) {
/* 124 */     TypeBinding internalResolveType = super.internalResolveType(scope, location);
/* 125 */     internalResolveType = ArrayTypeReference.maybeMarkArrayContentsNonNull(scope, internalResolveType, this.sourceStart, this.dimensions, null);
/*     */     
/* 127 */     return internalResolveType;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public StringBuffer printExpression(int indent, StringBuffer output) {
/* 133 */     super.printExpression(indent, output);
/* 134 */     if ((this.bits & 0x4000) != 0) {
/* 135 */       for (int i = 0; i < this.dimensions - 1; i++) {
/* 136 */         if (this.annotationsOnDimensions != null && this.annotationsOnDimensions[i] != null) {
/* 137 */           output.append(' ');
/* 138 */           printAnnotations(this.annotationsOnDimensions[i], output);
/* 139 */           output.append(' ');
/*     */         } 
/* 141 */         output.append("[]");
/*     */       } 
/* 143 */       if (this.annotationsOnDimensions != null && this.annotationsOnDimensions[this.dimensions - 1] != null) {
/* 144 */         output.append(' ');
/* 145 */         printAnnotations(this.annotationsOnDimensions[this.dimensions - 1], output);
/* 146 */         output.append(' ');
/*     */       } 
/* 148 */       output.append("...");
/*     */     } else {
/* 150 */       for (int i = 0; i < this.dimensions; i++) {
/* 151 */         if (this.annotationsOnDimensions != null && this.annotationsOnDimensions[i] != null) {
/* 152 */           output.append(" ");
/* 153 */           printAnnotations(this.annotationsOnDimensions[i], output);
/* 154 */           output.append(" ");
/*     */         } 
/* 156 */         output.append("[]");
/*     */       } 
/*     */     } 
/* 159 */     return output;
/*     */   }
/*     */ 
/*     */   
/*     */   public void traverse(ASTVisitor visitor, BlockScope scope) {
/* 164 */     if (visitor.visit(this, scope)) {
/* 165 */       if (this.annotations != null) {
/* 166 */         int annotationsLevels = this.annotations.length;
/* 167 */         for (int i = 0; i < annotationsLevels; i++) {
/* 168 */           int annotationsLength = (this.annotations[i] == null) ? 0 : (this.annotations[i]).length;
/* 169 */           for (int j = 0; j < annotationsLength; j++)
/* 170 */             this.annotations[i][j].traverse(visitor, scope); 
/*     */         } 
/*     */       } 
/* 173 */       if (this.annotationsOnDimensions != null) {
/* 174 */         for (int i = 0, max = this.annotationsOnDimensions.length; i < max; i++) {
/* 175 */           Annotation[] annotations2 = this.annotationsOnDimensions[i];
/* 176 */           for (int j = 0, max2 = (annotations2 == null) ? 0 : annotations2.length; j < max2; j++) {
/* 177 */             Annotation annotation = annotations2[j];
/* 178 */             annotation.traverse(visitor, scope);
/*     */           } 
/*     */         } 
/*     */       }
/*     */     } 
/* 183 */     visitor.endVisit(this, scope);
/*     */   }
/*     */ 
/*     */   
/*     */   public void traverse(ASTVisitor visitor, ClassScope scope) {
/* 188 */     if (visitor.visit(this, scope)) {
/* 189 */       if (this.annotations != null) {
/* 190 */         int annotationsLevels = this.annotations.length;
/* 191 */         for (int i = 0; i < annotationsLevels; i++) {
/* 192 */           int annotationsLength = (this.annotations[i] == null) ? 0 : (this.annotations[i]).length;
/* 193 */           for (int j = 0; j < annotationsLength; j++)
/* 194 */             this.annotations[i][j].traverse(visitor, scope); 
/*     */         } 
/*     */       } 
/* 197 */       if (this.annotationsOnDimensions != null) {
/* 198 */         for (int i = 0, max = this.annotationsOnDimensions.length; i < max; i++) {
/* 199 */           Annotation[] annotations2 = this.annotationsOnDimensions[i];
/* 200 */           for (int j = 0, max2 = (annotations2 == null) ? 0 : annotations2.length; j < max2; j++) {
/* 201 */             Annotation annotation = annotations2[j];
/* 202 */             annotation.traverse(visitor, scope);
/*     */           } 
/*     */         } 
/*     */       }
/*     */     } 
/* 207 */     visitor.endVisit(this, scope);
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\ast\ArrayQualifiedTypeReference.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */