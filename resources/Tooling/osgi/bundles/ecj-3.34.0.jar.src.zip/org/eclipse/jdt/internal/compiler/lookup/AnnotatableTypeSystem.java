/*     */ package org.eclipse.jdt.internal.compiler.lookup;
/*     */ 
/*     */ import org.eclipse.jdt.core.compiler.CharOperation;
/*     */ import org.eclipse.jdt.internal.compiler.util.Util;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AnnotatableTypeSystem
/*     */   extends TypeSystem
/*     */ {
/*     */   private boolean isAnnotationBasedNullAnalysisEnabled;
/*     */   
/*     */   public AnnotatableTypeSystem(LookupEnvironment environment) {
/*  37 */     super(environment);
/*  38 */     this.environment = environment;
/*  39 */     this.isAnnotationBasedNullAnalysisEnabled = environment.globalOptions.isAnnotationBasedNullAnalysisEnabled;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TypeBinding[] getAnnotatedTypes(TypeBinding type) {
/*  46 */     TypeBinding[] derivedTypes = getDerivedTypes(type);
/*  47 */     int length = derivedTypes.length;
/*  48 */     TypeBinding[] annotatedVersions = new TypeBinding[length];
/*  49 */     int versions = 0;
/*  50 */     for (int i = 0; i < length; i++) {
/*  51 */       TypeBinding derivedType = derivedTypes[i];
/*  52 */       if (derivedType == null)
/*     */         break; 
/*  54 */       if (derivedType.hasTypeAnnotations())
/*     */       {
/*  56 */         if (derivedType.id == type.id)
/*  57 */           annotatedVersions[versions++] = derivedType; 
/*     */       }
/*     */     } 
/*  60 */     if (versions != length)
/*  61 */       System.arraycopy(annotatedVersions, 0, annotatedVersions = new TypeBinding[versions], 0, versions); 
/*  62 */     return annotatedVersions;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ArrayBinding getArrayType(TypeBinding leafType, int dimensions, AnnotationBinding[] annotations) {
/*  73 */     if (leafType instanceof ArrayBinding) {
/*  74 */       dimensions += leafType.dimensions();
/*  75 */       AnnotationBinding[] leafAnnotations = leafType.getTypeAnnotations();
/*  76 */       leafType = leafType.leafComponentType();
/*  77 */       AnnotationBinding[] allAnnotations = new AnnotationBinding[leafAnnotations.length + annotations.length + 1];
/*  78 */       System.arraycopy(annotations, 0, allAnnotations, 0, annotations.length);
/*  79 */       System.arraycopy(leafAnnotations, 0, allAnnotations, annotations.length + 1, leafAnnotations.length);
/*  80 */       annotations = allAnnotations;
/*     */     } 
/*  82 */     ArrayBinding nakedType = null;
/*  83 */     TypeBinding[] derivedTypes = getDerivedTypes(leafType);
/*  84 */     for (int i = 0, length = derivedTypes.length; i < length; i++) {
/*  85 */       TypeBinding derivedType = derivedTypes[i];
/*  86 */       if (derivedType == null)
/*  87 */         break;  if (derivedType.isArrayType() && derivedType.dimensions() == dimensions && derivedType.leafComponentType() == leafType) {
/*     */         
/*  89 */         if (Util.effectivelyEqual((Object[])derivedType.getTypeAnnotations(), (Object[])annotations))
/*  90 */           return (ArrayBinding)derivedType; 
/*  91 */         if (!derivedType.hasTypeAnnotations())
/*  92 */           nakedType = (ArrayBinding)derivedType; 
/*     */       } 
/*  94 */     }  if (nakedType == null) {
/*  95 */       nakedType = super.getArrayType(leafType, dimensions);
/*     */     }
/*  97 */     if (!haveTypeAnnotations(leafType, annotations)) {
/*  98 */       return nakedType;
/*     */     }
/* 100 */     ArrayBinding arrayType = new ArrayBinding(leafType, dimensions, this.environment);
/* 101 */     arrayType.id = nakedType.id;
/* 102 */     arrayType.setTypeAnnotations(annotations, this.isAnnotationBasedNullAnalysisEnabled);
/* 103 */     return (ArrayBinding)cacheDerivedType(leafType, nakedType, arrayType);
/*     */   }
/*     */ 
/*     */   
/*     */   public ArrayBinding getArrayType(TypeBinding leaftType, int dimensions) {
/* 108 */     return getArrayType(leaftType, dimensions, Binding.NO_ANNOTATIONS);
/*     */   }
/*     */ 
/*     */   
/*     */   public ReferenceBinding getMemberType(ReferenceBinding memberType, ReferenceBinding enclosingType) {
/* 113 */     if (!haveTypeAnnotations(memberType, enclosingType))
/* 114 */       return super.getMemberType(memberType, enclosingType); 
/* 115 */     return (ReferenceBinding)getAnnotatedType(memberType, enclosingType, memberType.getTypeAnnotations());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ParameterizedTypeBinding getParameterizedType(ReferenceBinding genericType, TypeBinding[] typeArguments, ReferenceBinding enclosingType, AnnotationBinding[] annotations) {
/* 121 */     if (genericType.hasTypeAnnotations()) {
/* 122 */       throw new IllegalStateException();
/*     */     }
/* 124 */     ParameterizedTypeBinding parameterizedType = this.parameterizedTypes.get(genericType, typeArguments, enclosingType, annotations);
/* 125 */     if (parameterizedType != null) {
/* 126 */       return parameterizedType;
/*     */     }
/* 128 */     ParameterizedTypeBinding nakedType = super.getParameterizedType(genericType, typeArguments, enclosingType);
/*     */     
/* 130 */     if (!haveTypeAnnotations(genericType, enclosingType, typeArguments, annotations)) {
/* 131 */       return nakedType;
/*     */     }
/* 133 */     parameterizedType = new ParameterizedTypeBinding(genericType, typeArguments, enclosingType, this.environment);
/* 134 */     parameterizedType.id = nakedType.id;
/* 135 */     parameterizedType.setTypeAnnotations(annotations, this.isAnnotationBasedNullAnalysisEnabled);
/* 136 */     this.parameterizedTypes.put(genericType, typeArguments, enclosingType, parameterizedType);
/* 137 */     return (ParameterizedTypeBinding)cacheDerivedType(genericType, nakedType, parameterizedType);
/*     */   }
/*     */ 
/*     */   
/*     */   public ParameterizedTypeBinding getParameterizedType(ReferenceBinding genericType, TypeBinding[] typeArguments, ReferenceBinding enclosingType) {
/* 142 */     return getParameterizedType(genericType, typeArguments, enclosingType, Binding.NO_ANNOTATIONS);
/*     */   }
/*     */ 
/*     */   
/*     */   public RawTypeBinding getRawType(ReferenceBinding genericType, ReferenceBinding enclosingType, AnnotationBinding[] annotations) {
/* 147 */     if (genericType.hasTypeAnnotations())
/* 148 */       throw new IllegalStateException(); 
/* 149 */     if (!genericType.hasEnclosingInstanceContext() && enclosingType != null) {
/* 150 */       enclosingType = (ReferenceBinding)enclosingType.original();
/*     */     }
/*     */     
/* 153 */     RawTypeBinding nakedType = null;
/* 154 */     TypeBinding[] derivedTypes = getDerivedTypes(genericType);
/* 155 */     for (int i = 0, length = derivedTypes.length; i < length; i++) {
/* 156 */       TypeBinding derivedType = derivedTypes[i];
/* 157 */       if (derivedType == null)
/*     */         break; 
/* 159 */       if (derivedType.isRawType() && derivedType.actualType() == genericType && derivedType.enclosingType() == enclosingType) {
/*     */         
/* 161 */         if (Util.effectivelyEqual((Object[])derivedType.getTypeAnnotations(), (Object[])annotations))
/* 162 */           return (RawTypeBinding)derivedType; 
/* 163 */         if (!derivedType.hasTypeAnnotations())
/* 164 */           nakedType = (RawTypeBinding)derivedType; 
/*     */       } 
/* 166 */     }  if (nakedType == null) {
/* 167 */       nakedType = super.getRawType(genericType, enclosingType);
/*     */     }
/* 169 */     if (!haveTypeAnnotations(genericType, enclosingType, (TypeBinding[])null, annotations)) {
/* 170 */       return nakedType;
/*     */     }
/* 172 */     RawTypeBinding rawType = new RawTypeBinding(genericType, enclosingType, this.environment);
/* 173 */     rawType.id = nakedType.id;
/* 174 */     rawType.setTypeAnnotations(annotations, this.isAnnotationBasedNullAnalysisEnabled);
/* 175 */     return (RawTypeBinding)cacheDerivedType(genericType, nakedType, rawType);
/*     */   }
/*     */ 
/*     */   
/*     */   public RawTypeBinding getRawType(ReferenceBinding genericType, ReferenceBinding enclosingType) {
/* 180 */     return getRawType(genericType, enclosingType, Binding.NO_ANNOTATIONS);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public WildcardBinding getWildcard(ReferenceBinding genericType, int rank, TypeBinding bound, TypeBinding[] otherBounds, int boundKind, AnnotationBinding[] annotations) {
/* 186 */     if (genericType == null) {
/* 187 */       genericType = ReferenceBinding.LUB_GENERIC;
/*     */     }
/* 189 */     if (genericType.hasTypeAnnotations()) {
/* 190 */       throw new IllegalStateException();
/*     */     }
/* 192 */     WildcardBinding nakedType = null;
/* 193 */     boolean useDerivedTypesOfBound = !(!(bound instanceof TypeVariableBinding) && (!(bound instanceof ParameterizedTypeBinding) || bound instanceof RawTypeBinding));
/* 194 */     TypeBinding[] derivedTypes = getDerivedTypes(useDerivedTypesOfBound ? bound : genericType);
/* 195 */     for (int i = 0, length = derivedTypes.length; i < length; i++) {
/* 196 */       TypeBinding derivedType = derivedTypes[i];
/* 197 */       if (derivedType == null)
/*     */         break; 
/* 199 */       if (derivedType.isWildcard() && derivedType.actualType() == genericType && derivedType.rank() == rank)
/*     */       {
/* 201 */         if (derivedType.boundKind() == boundKind && derivedType.bound() == bound && Util.effectivelyEqual((Object[])derivedType.additionalBounds(), (Object[])otherBounds)) {
/*     */           
/* 203 */           if (Util.effectivelyEqual((Object[])derivedType.getTypeAnnotations(), (Object[])annotations))
/* 204 */             return (WildcardBinding)derivedType; 
/* 205 */           if (!derivedType.hasTypeAnnotations())
/* 206 */             nakedType = (WildcardBinding)derivedType; 
/*     */         }  } 
/*     */     } 
/* 209 */     if (nakedType == null) {
/* 210 */       nakedType = super.getWildcard(genericType, rank, bound, otherBounds, boundKind);
/*     */     }
/* 212 */     if (!haveTypeAnnotations(genericType, bound, otherBounds, annotations)) {
/* 213 */       return nakedType;
/*     */     }
/* 215 */     WildcardBinding wildcard = new WildcardBinding(genericType, rank, bound, otherBounds, boundKind, this.environment);
/* 216 */     wildcard.id = nakedType.id;
/* 217 */     wildcard.setTypeAnnotations(annotations, this.isAnnotationBasedNullAnalysisEnabled);
/* 218 */     return (WildcardBinding)cacheDerivedType(useDerivedTypesOfBound ? bound : genericType, nakedType, wildcard);
/*     */   }
/*     */ 
/*     */   
/*     */   public WildcardBinding getWildcard(ReferenceBinding genericType, int rank, TypeBinding bound, TypeBinding[] otherBounds, int boundKind) {
/* 223 */     return getWildcard(genericType, rank, bound, otherBounds, boundKind, Binding.NO_ANNOTATIONS);
/*     */   }
/*     */ 
/*     */   
/*     */   public TypeBinding getAnnotatedType(TypeBinding type, AnnotationBinding[][] annotations) {
/*     */     ArrayBinding arrayBinding;
/*     */     int levels;
/*     */     TypeBinding types[], enclosingType;
/*     */     int i, j;
/* 232 */     if (type == null || !type.isValidBinding() || annotations == null || annotations.length == 0) {
/* 233 */       return type;
/*     */     }
/* 235 */     TypeBinding annotatedType = null;
/* 236 */     switch (type.kind()) {
/*     */       case 68:
/* 238 */         arrayBinding = (ArrayBinding)type;
/* 239 */         annotatedType = getArrayType(arrayBinding.leafComponentType, arrayBinding.dimensions, flattenedAnnotations(annotations));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 292 */         return annotatedType;case 4: case 132: case 260: case 516: case 1028: case 2052: case 4100: case 8196: case 32772: if (type.isUnresolvedType() && CharOperation.indexOf('$', type.sourceName()) > 0) type = BinaryTypeBinding.resolveType(type, this.environment, true);  levels = type.depth() + 1; types = new TypeBinding[levels]; types[--levels] = type; enclosingType = type.enclosingType(); while (enclosingType != null) { types[--levels] = enclosingType; enclosingType = enclosingType.enclosingType(); }  levels = annotations.length; j = types.length - levels; for (i = 0; i < levels && (annotations[i] == null || (annotations[i]).length <= 0); ) { i++; j++; }  if (i == levels) return type;  if (j < 0) return type;  for (enclosingType = (j == 0) ? null : types[j - 1]; i < levels; i++, j++) { TypeBinding currentType = types[j]; AnnotationBinding[] currentAnnotations = (annotations[i] != null && (annotations[i]).length > 0) ? annotations[i] : currentType.getTypeAnnotations(); annotatedType = getAnnotatedType(currentType, enclosingType, currentAnnotations); enclosingType = annotatedType; }  return annotatedType;
/*     */     } 
/*     */     throw new IllegalStateException();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private TypeBinding getAnnotatedType(TypeBinding type, TypeBinding enclosingType, AnnotationBinding[] annotations) {
/* 301 */     if (type.kind() == 260) {
/* 302 */       return getParameterizedType(type.actualType(), type.typeArguments(), (ReferenceBinding)enclosingType, annotations);
/*     */     }
/* 304 */     TypeBinding nakedType = null;
/* 305 */     TypeBinding[] derivedTypes = getDerivedTypes(type);
/* 306 */     for (int i = 0, length = derivedTypes.length; i < length; i++) {
/* 307 */       TypeBinding derivedType = derivedTypes[i];
/* 308 */       if (derivedType == null)
/*     */         break; 
/* 310 */       if (derivedType.enclosingType() == enclosingType && Util.effectivelyEqual((Object[])derivedType.typeArguments(), (Object[])type.typeArguments()))
/*     */       {
/*     */         
/* 313 */         switch (type.kind()) {
/*     */           case 68:
/* 315 */             if (!derivedType.isArrayType() || derivedType.dimensions() != type.dimensions() || derivedType.leafComponentType() != type.leafComponentType()) {
/*     */               break;
/*     */             }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */             
/* 340 */             if (Util.effectivelyEqual((Object[])derivedType.getTypeAnnotations(), (Object[])annotations)) {
/* 341 */               return derivedType;
/*     */             }
/* 343 */             if (!derivedType.hasTypeAnnotations())
/* 344 */               nakedType = derivedType;  break;case 1028: if (!derivedType.isRawType() || derivedType.actualType() != type.actualType()) break;  if (Util.effectivelyEqual((Object[])derivedType.getTypeAnnotations(), (Object[])annotations)) return derivedType;  if (!derivedType.hasTypeAnnotations()) nakedType = derivedType;  break;case 516: case 8196: if (!derivedType.isWildcard() || derivedType.actualType() != type.actualType() || derivedType.rank() != type.rank() || derivedType.boundKind() != type.boundKind()) break;  if (derivedType.bound() != type.bound() || !Util.effectivelyEqual((Object[])derivedType.additionalBounds(), (Object[])type.additionalBounds())) break;  if (Util.effectivelyEqual((Object[])derivedType.getTypeAnnotations(), (Object[])annotations)) return derivedType;  if (!derivedType.hasTypeAnnotations()) nakedType = derivedType;  break;default: switch (derivedType.kind()) { case 68: case 516: case 1028: case 8196: case 32772: break; }  if (Util.effectivelyEqual((Object[])derivedType.getTypeAnnotations(), (Object[])annotations)) return derivedType;  if (!derivedType.hasTypeAnnotations()) nakedType = derivedType;  break;
/*     */         }  } 
/* 346 */     }  if (nakedType == null) {
/* 347 */       nakedType = getUnannotatedType(type);
/*     */     }
/* 349 */     if (!haveTypeAnnotations(type, enclosingType, (TypeBinding[])null, annotations)) {
/* 350 */       return nakedType;
/*     */     }
/* 352 */     TypeBinding annotatedType = type.clone(enclosingType);
/* 353 */     annotatedType.id = nakedType.id;
/* 354 */     annotatedType.setTypeAnnotations(annotations, this.isAnnotationBasedNullAnalysisEnabled);
/* 355 */     if (this.isAnnotationBasedNullAnalysisEnabled && (annotatedType.tagBits & 0x180000000000000L) == 0L)
/*     */     {
/* 357 */       annotatedType.tagBits |= type.tagBits & 0x180000000000000L;
/*     */     }
/*     */     
/* 360 */     switch (type.kind())
/*     */     { case 68:
/* 362 */         keyType = type.leafComponentType();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 372 */         return cacheDerivedType(keyType, nakedType, annotatedType);case 516: case 1028: keyType = type.actualType(); return cacheDerivedType(keyType, nakedType, annotatedType); }  TypeBinding keyType = nakedType; return cacheDerivedType(keyType, nakedType, annotatedType);
/*     */   }
/*     */   
/*     */   private boolean haveTypeAnnotations(TypeBinding baseType, TypeBinding someType, TypeBinding[] someTypes, AnnotationBinding[] annotations) {
/* 376 */     if (baseType != null && baseType.hasTypeAnnotations())
/* 377 */       return true; 
/* 378 */     if (someType != null && someType.hasTypeAnnotations())
/* 379 */       return true;  int i; int length;
/* 380 */     for (i = 0, length = (annotations == null) ? 0 : annotations.length; i < length; i++) {
/* 381 */       if (annotations[i] != null)
/* 382 */         return true; 
/* 383 */     }  for (i = 0, length = (someTypes == null) ? 0 : someTypes.length; i < length; i++) {
/* 384 */       if (someTypes[i].hasTypeAnnotations())
/* 385 */         return true; 
/* 386 */     }  return false;
/*     */   }
/*     */   
/*     */   private boolean haveTypeAnnotations(TypeBinding leafType, AnnotationBinding[] annotations) {
/* 390 */     return haveTypeAnnotations(leafType, (TypeBinding)null, (TypeBinding[])null, annotations);
/*     */   }
/*     */   
/*     */   private boolean haveTypeAnnotations(TypeBinding memberType, TypeBinding enclosingType) {
/* 394 */     return haveTypeAnnotations(memberType, enclosingType, (TypeBinding[])null, (AnnotationBinding[])null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static AnnotationBinding[] flattenedAnnotations(AnnotationBinding[][] annotations) {
/* 403 */     if (annotations == null || annotations.length == 0) {
/* 404 */       return Binding.NO_ANNOTATIONS;
/*     */     }
/* 406 */     int levels = annotations.length;
/* 407 */     int length = levels;
/* 408 */     for (int i = 0; i < levels; i++) {
/* 409 */       length += (annotations[i] == null) ? 0 : (annotations[i]).length;
/*     */     }
/* 411 */     if (length == 0) {
/* 412 */       return Binding.NO_ANNOTATIONS;
/*     */     }
/* 414 */     AnnotationBinding[] series = new AnnotationBinding[length];
/* 415 */     int index = 0;
/* 416 */     for (int j = 0; j < levels; j++) {
/* 417 */       int annotationsLength = (annotations[j] == null) ? 0 : (annotations[j]).length;
/* 418 */       if (annotationsLength > 0) {
/* 419 */         System.arraycopy(annotations[j], 0, series, index, annotationsLength);
/* 420 */         index += annotationsLength;
/*     */       } 
/* 422 */       series[index++] = null;
/*     */     } 
/* 424 */     if (index != length)
/* 425 */       throw new IllegalStateException(); 
/* 426 */     return series;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isAnnotatedTypeSystem() {
/* 431 */     return true;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\lookup\AnnotatableTypeSystem.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */