/*     */ package org.eclipse.jdt.internal.compiler.apt.model;
/*     */ 
/*     */ import java.lang.reflect.Array;
/*     */ import java.util.List;
/*     */ import javax.lang.model.element.AnnotationMirror;
/*     */ import javax.lang.model.type.NoType;
/*     */ import javax.lang.model.type.NullType;
/*     */ import javax.lang.model.type.TypeKind;
/*     */ import javax.lang.model.type.TypeVisitor;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.Binding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.TypeBinding;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class NoTypeImpl
/*     */   extends TypeMirrorImpl
/*     */   implements NoType, NullType
/*     */ {
/*     */   private final TypeKind _kind;
/*  39 */   public static final NoType NO_TYPE_NONE = new NoTypeImpl(TypeKind.NONE);
/*  40 */   public static final NoType NO_TYPE_VOID = new NoTypeImpl(TypeKind.VOID, (Binding)TypeBinding.VOID);
/*  41 */   public static final NoType NO_TYPE_PACKAGE = new NoTypeImpl(TypeKind.PACKAGE);
/*  42 */   public static final NullType NULL_TYPE = new NoTypeImpl(TypeKind.NULL, (Binding)TypeBinding.NULL);
/*  43 */   public static final Binding NO_TYPE_BINDING = new Binding()
/*     */     {
/*     */       public int kind() {
/*  46 */         throw new IllegalStateException();
/*     */       }
/*     */ 
/*     */       
/*     */       public char[] readableName() {
/*  51 */         throw new IllegalStateException();
/*     */       }
/*     */     };
/*     */   
/*     */   public NoTypeImpl(TypeKind kind) {
/*  56 */     super(null, NO_TYPE_BINDING);
/*  57 */     this._kind = kind;
/*     */   }
/*     */   public NoTypeImpl(TypeKind kind, Binding binding) {
/*  60 */     super(null, binding);
/*  61 */     this._kind = kind;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public <R, P> R accept(TypeVisitor<R, P> v, P p) {
/*  67 */     switch (getKind()) {
/*     */       
/*     */       case NULL:
/*  70 */         return v.visitNull(this, p);
/*     */     } 
/*  72 */     return v.visitNoType(this, p);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TypeKind getKind() {
/*  79 */     return this._kind;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/*  85 */     switch (this._kind)
/*     */     
/*     */     { default:
/*  88 */         return "none";
/*     */       case NULL:
/*  90 */         return "null";
/*     */       case VOID:
/*  92 */         return "void";
/*     */       case PACKAGE:
/*  94 */         return "package";
/*     */       case MODULE:
/*  96 */         break; }  return "module";
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public List<? extends AnnotationMirror> getAnnotationMirrors() {
/* 102 */     return Factory.EMPTY_ANNOTATION_MIRRORS;
/*     */   }
/*     */ 
/*     */   
/*     */   public <A extends java.lang.annotation.Annotation> A getAnnotation(Class<A> annotationType) {
/* 107 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public <A extends java.lang.annotation.Annotation> A[] getAnnotationsByType(Class<A> annotationType) {
/* 113 */     return (A[])Array.newInstance(annotationType, 0);
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\apt\model\NoTypeImpl.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */