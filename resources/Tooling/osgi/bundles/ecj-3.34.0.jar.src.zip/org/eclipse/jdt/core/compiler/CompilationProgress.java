package org.eclipse.jdt.core.compiler;

public abstract class CompilationProgress {
  public abstract void begin(int paramInt);
  
  public abstract void done();
  
  public abstract boolean isCanceled();
  
  public abstract void setTaskName(String paramString);
  
  public abstract void worked(int paramInt1, int paramInt2);
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\core\compiler\CompilationProgress.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */