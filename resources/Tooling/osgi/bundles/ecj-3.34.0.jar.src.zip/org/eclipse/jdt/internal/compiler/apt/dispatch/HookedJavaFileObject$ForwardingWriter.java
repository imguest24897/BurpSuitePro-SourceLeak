/*     */ package org.eclipse.jdt.internal.compiler.apt.dispatch;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.Writer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class ForwardingWriter
/*     */   extends Writer
/*     */ {
/*     */   private final Writer _w;
/*     */   
/*     */   ForwardingWriter(Writer w) {
/*  46 */     this._w = w;
/*     */   }
/*     */   
/*     */   public Writer append(char c) throws IOException {
/*  50 */     return this._w.append(c);
/*     */   }
/*     */ 
/*     */   
/*     */   public Writer append(CharSequence csq, int start, int end) throws IOException {
/*  55 */     return this._w.append(csq, start, end);
/*     */   }
/*     */   
/*     */   public Writer append(CharSequence csq) throws IOException {
/*  59 */     return this._w.append(csq);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void close() throws IOException {
/*  65 */     this._w.close();
/*  66 */     HookedJavaFileObject.this.closed();
/*     */   }
/*     */   
/*     */   public void flush() throws IOException {
/*  70 */     this._w.flush();
/*     */   }
/*     */   
/*     */   public void write(char[] cbuf) throws IOException {
/*  74 */     this._w.write(cbuf);
/*     */   }
/*     */   
/*     */   public void write(int c) throws IOException {
/*  78 */     this._w.write(c);
/*     */   }
/*     */ 
/*     */   
/*     */   public void write(String str, int off, int len) throws IOException {
/*  83 */     this._w.write(str, off, len);
/*     */   }
/*     */   
/*     */   public void write(String str) throws IOException {
/*  87 */     this._w.write(str);
/*     */   }
/*     */ 
/*     */   
/*     */   public void write(char[] cbuf, int off, int len) throws IOException {
/*  92 */     this._w.write(cbuf, off, len);
/*     */   }
/*     */   
/*     */   protected Object clone() throws CloneNotSupportedException {
/*  96 */     return new ForwardingWriter(this._w);
/*     */   }
/*     */   
/*     */   public int hashCode() {
/* 100 */     return this._w.hashCode();
/*     */   }
/*     */   
/*     */   public boolean equals(Object obj) {
/* 104 */     if (this == obj)
/* 105 */       return true; 
/* 106 */     if (obj == null)
/* 107 */       return false; 
/* 108 */     if (getClass() != obj.getClass())
/* 109 */       return false; 
/* 110 */     ForwardingWriter other = (ForwardingWriter)obj;
/* 111 */     if (this._w == null) {
/* 112 */       if (other._w != null)
/* 113 */         return false; 
/* 114 */     } else if (!this._w.equals(other._w)) {
/* 115 */       return false;
/* 116 */     }  return true;
/*     */   }
/*     */   
/*     */   public String toString() {
/* 120 */     return "ForwardingWriter wrapping " + this._w.toString();
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\apt\dispatch\HookedJavaFileObject$ForwardingWriter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */