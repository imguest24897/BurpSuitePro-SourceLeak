/*     */ package org.eclipse.jdt.internal.compiler.ast;
/*     */ 
/*     */ import org.eclipse.jdt.internal.compiler.ASTVisitor;
/*     */ import org.eclipse.jdt.internal.compiler.codegen.BranchLabel;
/*     */ import org.eclipse.jdt.internal.compiler.codegen.CodeStream;
/*     */ import org.eclipse.jdt.internal.compiler.flow.FlowContext;
/*     */ import org.eclipse.jdt.internal.compiler.flow.FlowInfo;
/*     */ import org.eclipse.jdt.internal.compiler.impl.CompilerOptions;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.BlockScope;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.LocalVariableBinding;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Block
/*     */   extends Statement
/*     */ {
/*     */   public Statement[] statements;
/*     */   public int explicitDeclarations;
/*     */   public BlockScope scope;
/*     */   
/*     */   public Block(int explicitDeclarations) {
/*  37 */     this.explicitDeclarations = explicitDeclarations;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public FlowInfo analyseCode(BlockScope currentScope, FlowContext flowContext, FlowInfo flowInfo) {
/*  43 */     if (this.statements == null) return flowInfo; 
/*  44 */     int complaintLevel = ((flowInfo.reachMode() & 0x3) != 0) ? 1 : 0;
/*  45 */     CompilerOptions compilerOptions = currentScope.compilerOptions();
/*  46 */     boolean enableSyntacticNullAnalysisForFields = compilerOptions.enableSyntacticNullAnalysisForFields;
/*  47 */     for (int i = 0, max = this.statements.length; i < max; i++) {
/*  48 */       Statement stat = this.statements[i];
/*  49 */       if ((complaintLevel = stat.complainIfUnreachable(flowInfo, this.scope, complaintLevel, true)) < 2) {
/*  50 */         flowInfo = stat.analyseCode(this.scope, flowContext, flowInfo);
/*     */       }
/*     */       
/*  53 */       flowContext.mergeFinallyNullInfo(flowInfo);
/*  54 */       if (enableSyntacticNullAnalysisForFields) {
/*  55 */         flowContext.expireNullCheckedFieldInfo();
/*     */       }
/*  57 */       if (compilerOptions.analyseResourceLeaks) {
/*  58 */         FakedTrackingVariable.cleanUpUnassigned(this.scope, stat, flowInfo);
/*     */       }
/*     */     } 
/*  61 */     if (this.scope != currentScope)
/*     */     {
/*  63 */       this.scope.checkUnclosedCloseables(flowInfo, flowContext, null, null);
/*     */     }
/*  65 */     if (this.explicitDeclarations > 0) {
/*     */       
/*  67 */       LocalVariableBinding[] locals = this.scope.locals;
/*  68 */       if (locals != null) {
/*  69 */         int numLocals = this.scope.localIndex;
/*  70 */         for (int j = 0; j < numLocals; j++) {
/*  71 */           flowInfo.resetAssignmentInfo(locals[j]);
/*     */         }
/*     */       } 
/*     */     } 
/*  75 */     return flowInfo;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void generateCode(BlockScope currentScope, CodeStream codeStream) {
/*  82 */     if ((this.bits & Integer.MIN_VALUE) == 0) {
/*     */       return;
/*     */     }
/*  85 */     int pc = codeStream.position;
/*  86 */     if (this.statements != null) {
/*  87 */       byte b; int i; Statement[] arrayOfStatement; for (i = (arrayOfStatement = this.statements).length, b = 0; b < i; ) { Statement stmt = arrayOfStatement[b];
/*  88 */         stmt.generateCode(this.scope, codeStream); b++; }
/*     */     
/*     */     } 
/*  91 */     if (this.scope != currentScope) {
/*  92 */       codeStream.exitUserScope(this.scope);
/*     */     }
/*  94 */     codeStream.recordPositionsFrom(pc, this.sourceStart);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isEmptyBlock() {
/*  99 */     return (this.statements == null);
/*     */   }
/*     */   
/*     */   public StringBuffer printBody(int indent, StringBuffer output) {
/* 103 */     if (this.statements == null) return output; 
/* 104 */     for (int i = 0; i < this.statements.length; i++) {
/* 105 */       this.statements[i].printStatement(indent + 1, output);
/* 106 */       output.append('\n');
/*     */     } 
/* 108 */     return output;
/*     */   }
/*     */ 
/*     */   
/*     */   public StringBuffer printStatement(int indent, StringBuffer output) {
/* 113 */     printIndent(indent, output);
/* 114 */     output.append("{\n");
/* 115 */     printBody(indent, output);
/* 116 */     return printIndent(indent, output).append('}');
/*     */   }
/*     */ 
/*     */   
/*     */   public void resolve(BlockScope upperScope) {
/* 121 */     if ((this.bits & 0x8) != 0) {
/* 122 */       upperScope.problemReporter().undocumentedEmptyBlock(this.sourceStart, this.sourceEnd);
/*     */     }
/* 124 */     if (this.statements != null) {
/* 125 */       this.scope = 
/* 126 */         (this.explicitDeclarations == 0) ? 
/* 127 */         upperScope : 
/* 128 */         new BlockScope(upperScope, this.explicitDeclarations);
/* 129 */       for (int i = 0, length = this.statements.length; i < length; i++) {
/* 130 */         Statement stmt = this.statements[i];
/* 131 */         stmt.resolve(this.scope);
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   public void resolveUsing(BlockScope givenScope) {
/* 137 */     if ((this.bits & 0x8) != 0) {
/* 138 */       givenScope.problemReporter().undocumentedEmptyBlock(this.sourceStart, this.sourceEnd);
/*     */     }
/*     */     
/* 141 */     this.scope = givenScope;
/* 142 */     if (this.statements != null) {
/* 143 */       for (int i = 0, length = this.statements.length; i < length; i++) {
/* 144 */         this.statements[i].resolve(this.scope);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void traverse(ASTVisitor visitor, BlockScope blockScope) {
/* 151 */     if (visitor.visit(this, blockScope) && 
/* 152 */       this.statements != null) {
/* 153 */       for (int i = 0, length = this.statements.length; i < length; i++) {
/* 154 */         this.statements[i].traverse(visitor, this.scope);
/*     */       }
/*     */     }
/* 157 */     visitor.endVisit(this, blockScope);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void branchChainTo(BranchLabel label) {
/* 165 */     if (this.statements != null) {
/* 166 */       this.statements[this.statements.length - 1].branchChainTo(label);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean doesNotCompleteNormally() {
/* 173 */     int length = (this.statements == null) ? 0 : this.statements.length;
/* 174 */     return (length > 0 && this.statements[length - 1].doesNotCompleteNormally());
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean completesByContinue() {
/* 179 */     int length = (this.statements == null) ? 0 : this.statements.length;
/* 180 */     return (length > 0 && this.statements[length - 1].completesByContinue());
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean canCompleteNormally() {
/* 185 */     int length = (this.statements == null) ? 0 : this.statements.length;
/* 186 */     return !(length != 0 && !this.statements[length - 1].canCompleteNormally());
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean continueCompletes() {
/* 191 */     int length = (this.statements == null) ? 0 : this.statements.length;
/* 192 */     return (length > 0 && this.statements[length - 1].continueCompletes());
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\ast\Block.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */