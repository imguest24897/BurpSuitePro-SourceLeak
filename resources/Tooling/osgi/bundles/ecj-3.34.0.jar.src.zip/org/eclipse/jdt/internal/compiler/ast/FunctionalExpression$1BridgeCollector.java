/*     */ package org.eclipse.jdt.internal.compiler.ast;
/*     */ 
/*     */ import org.eclipse.jdt.internal.compiler.lookup.LookupEnvironment;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.MethodBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.MethodVerifier;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.ReferenceBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.Scope;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.TypeBinding;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class BridgeCollector
/*     */ {
/*     */   MethodBinding[] bridges;
/*     */   MethodBinding method;
/*     */   char[] selector;
/*     */   LookupEnvironment environment;
/*     */   Scope scope;
/*     */   
/*     */   BridgeCollector(ReferenceBinding functionalType, MethodBinding method) {
/* 331 */     this.method = method;
/* 332 */     this.selector = method.selector;
/* 333 */     this.environment = paramFunctionalExpression.enclosingScope.environment();
/* 334 */     this.scope = (Scope)paramFunctionalExpression.enclosingScope;
/* 335 */     collectBridges(new ReferenceBinding[] { functionalType });
/*     */   }
/*     */   
/*     */   void collectBridges(ReferenceBinding[] interfaces) {
/* 339 */     int length = (interfaces == null) ? 0 : interfaces.length;
/* 340 */     for (int i = 0; i < length; i++) {
/* 341 */       ReferenceBinding superInterface = interfaces[i];
/* 342 */       if (superInterface != null) {
/*     */         
/* 344 */         MethodBinding[] methods = superInterface.getMethods(this.selector);
/* 345 */         for (int j = 0, count = (methods == null) ? 0 : methods.length; j < count; j++) {
/* 346 */           MethodBinding inheritedMethod = methods[j];
/* 347 */           if (inheritedMethod != null && this.method != inheritedMethod)
/*     */           {
/* 349 */             if (!inheritedMethod.isStatic() && !inheritedMethod.redeclaresPublicObjectMethod(this.scope)) {
/*     */               
/* 351 */               inheritedMethod = MethodVerifier.computeSubstituteMethod(inheritedMethod, this.method, this.environment);
/* 352 */               if (inheritedMethod != null && MethodVerifier.isSubstituteParameterSubsignature(this.method, inheritedMethod, this.environment) && 
/* 353 */                 MethodVerifier.areReturnTypesCompatible(this.method, inheritedMethod, this.environment))
/*     */               
/* 355 */               { MethodBinding originalInherited = inheritedMethod.original();
/* 356 */                 MethodBinding originalOverride = this.method.original();
/* 357 */                 if (!originalOverride.areParameterErasuresEqual(originalInherited) || TypeBinding.notEquals(originalOverride.returnType.erasure(), originalInherited.returnType.erasure()))
/* 358 */                   add(originalInherited);  } 
/*     */             }  } 
/* 360 */         }  collectBridges(superInterface.superInterfaces());
/*     */       } 
/*     */     } 
/*     */   } void add(MethodBinding inheritedMethod) {
/* 364 */     if (this.bridges == null) {
/* 365 */       this.bridges = new MethodBinding[] { inheritedMethod };
/*     */       return;
/*     */     } 
/* 368 */     int length = this.bridges.length;
/* 369 */     for (int i = 0; i < length; i++) {
/* 370 */       if (this.bridges[i].areParameterErasuresEqual(inheritedMethod) && TypeBinding.equalsEquals((this.bridges[i]).returnType.erasure(), inheritedMethod.returnType.erasure()))
/*     */         return; 
/*     */     } 
/* 373 */     System.arraycopy(this.bridges, 0, this.bridges = new MethodBinding[length + 1], 0, length);
/* 374 */     this.bridges[length] = inheritedMethod;
/*     */   }
/*     */   MethodBinding[] getBridges() {
/* 377 */     return this.bridges;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\ast\FunctionalExpression$1BridgeCollector.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */