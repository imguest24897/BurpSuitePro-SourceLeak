/*     */ package org.eclipse.jdt.internal.compiler.ast;
/*     */ 
/*     */ import java.util.List;
/*     */ import java.util.function.BiPredicate;
/*     */ import org.eclipse.jdt.core.compiler.CharOperation;
/*     */ import org.eclipse.jdt.internal.compiler.ASTVisitor;
/*     */ import org.eclipse.jdt.internal.compiler.CompilationResult;
/*     */ import org.eclipse.jdt.internal.compiler.codegen.AnnotationContext;
/*     */ import org.eclipse.jdt.internal.compiler.flow.ExceptionHandlingFlowContext;
/*     */ import org.eclipse.jdt.internal.compiler.flow.FlowContext;
/*     */ import org.eclipse.jdt.internal.compiler.flow.FlowInfo;
/*     */ import org.eclipse.jdt.internal.compiler.impl.CompilerOptions;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.BlockScope;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.ClassScope;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.ReferenceBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.TypeBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.TypeConstants;
/*     */ import org.eclipse.jdt.internal.compiler.parser.Parser;
/*     */ import org.eclipse.jdt.internal.compiler.problem.AbortMethod;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MethodDeclaration
/*     */   extends AbstractMethodDeclaration
/*     */ {
/*     */   public TypeReference returnType;
/*     */   public TypeParameter[] typeParameters;
/*     */   
/*     */   public MethodDeclaration(CompilationResult compilationResult) {
/*  68 */     super(compilationResult);
/*  69 */     this.bits |= 0x100;
/*     */   }
/*     */ 
/*     */   
/*     */   public void analyseCode(ClassScope classScope, FlowContext flowContext, FlowInfo flowInfo) {
/*  74 */     if (this.ignoreFurtherInvestigation)
/*     */       return; 
/*     */     try {
/*  77 */       if (this.binding == null) {
/*     */         return;
/*     */       }
/*  80 */       if (!this.binding.isUsed() && !this.binding.isAbstract() && (
/*  81 */         this.binding.isPrivate() || ((
/*  82 */         this.binding.modifiers & 0x30000000) == 0 && 
/*  83 */         this.binding.isOrEnclosedByPrivateType())) && 
/*  84 */         !(classScope.referenceCompilationUnit()).compilationResult.hasSyntaxError) {
/*  85 */         this.scope.problemReporter().unusedPrivateMethod(this);
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*  91 */       if (this.binding.declaringClass.isEnum() && (this.selector == TypeConstants.VALUES || this.selector == TypeConstants.VALUEOF)) {
/*     */         return;
/*     */       }
/*     */       
/*  95 */       if (this.binding.isAbstract() || this.binding.isNative()) {
/*     */         return;
/*     */       }
/*     */       
/*  99 */       if (this.typeParameters != null && 
/* 100 */         !(this.scope.referenceCompilationUnit()).compilationResult.hasSyntaxError) {
/* 101 */         for (int i = 0, length = this.typeParameters.length; i < length; i++) {
/* 102 */           TypeParameter typeParameter = this.typeParameters[i];
/* 103 */           if ((typeParameter.binding.modifiers & 0x8000000) == 0) {
/* 104 */             this.scope.problemReporter().unusedTypeParameter(typeParameter);
/*     */           }
/*     */         } 
/*     */       }
/* 108 */       ExceptionHandlingFlowContext methodContext = 
/* 109 */         new ExceptionHandlingFlowContext(
/* 110 */           flowContext, 
/* 111 */           this, 
/* 112 */           this.binding.thrownExceptions, 
/* 113 */           null, 
/* 114 */           (BlockScope)this.scope, 
/* 115 */           FlowInfo.DEAD_END);
/*     */ 
/*     */       
/* 118 */       analyseArguments(classScope.environment(), flowInfo, this.arguments, this.binding);
/*     */       
/* 120 */       BiPredicate<TypeBinding, ReferenceBinding> condition = (argType, declClass) -> {
/*     */           ReferenceBinding enclosingType = argType.enclosingType();
/* 122 */           return (enclosingType != null && TypeBinding.equalsEquals((TypeBinding)declClass, (TypeBinding)enclosingType.actualType()));
/*     */         };
/*     */ 
/*     */ 
/*     */       
/* 127 */       boolean referencesGenericType = false;
/* 128 */       ReferenceBinding declaringClass = this.binding.declaringClass;
/* 129 */       if (declaringClass.isGenericType()) {
/* 130 */         if (condition.test(this.binding.returnType, declaringClass)) {
/* 131 */           referencesGenericType = true;
/*     */         }
/* 133 */         if (!referencesGenericType && this.binding.parameters != null && this.arguments != null) {
/* 134 */           int length = Math.min(this.binding.parameters.length, this.arguments.length);
/* 135 */           for (int i = 0; i < length; i++) {
/* 136 */             if (condition.test(this.binding.parameters[i], this.binding.declaringClass)) {
/* 137 */               referencesGenericType = true;
/*     */               break;
/*     */             } 
/*     */           } 
/*     */         } 
/*     */       } 
/* 143 */       if ((this.binding.declaringClass instanceof org.eclipse.jdt.internal.compiler.lookup.MemberTypeBinding && !this.binding.declaringClass.isStatic()) || referencesGenericType)
/*     */       {
/* 145 */         this.bits &= 0xFFFFFEFF;
/*     */       }
/*     */       
/* 148 */       if (this.statements != null) {
/* 149 */         CompilerOptions compilerOptions = this.scope.compilerOptions();
/* 150 */         boolean enableSyntacticNullAnalysisForFields = compilerOptions.enableSyntacticNullAnalysisForFields;
/* 151 */         int complaintLevel = ((flowInfo.reachMode() & 0x3) == 0) ? 0 : 1;
/* 152 */         for (int i = 0, count = this.statements.length; i < count; i++) {
/* 153 */           Statement stat = this.statements[i];
/* 154 */           if ((complaintLevel = stat.complainIfUnreachable(flowInfo, (BlockScope)this.scope, complaintLevel, true)) < 2) {
/* 155 */             flowInfo = stat.analyseCode((BlockScope)this.scope, (FlowContext)methodContext, flowInfo);
/*     */           }
/* 157 */           if (enableSyntacticNullAnalysisForFields) {
/* 158 */             methodContext.expireNullCheckedFieldInfo();
/*     */           }
/* 160 */           if (compilerOptions.analyseResourceLeaks) {
/* 161 */             FakedTrackingVariable.cleanUpUnassigned((BlockScope)this.scope, stat, flowInfo);
/*     */           }
/*     */         } 
/*     */       } else {
/*     */         
/* 166 */         this.bits &= 0xFFFFFEFF;
/*     */       } 
/*     */       
/* 169 */       TypeBinding returnTypeBinding = this.binding.returnType;
/* 170 */       if (returnTypeBinding == TypeBinding.VOID || isAbstract()) {
/* 171 */         if ((flowInfo.tagBits & 0x1) == 0) {
/* 172 */           this.bits |= 0x40;
/*     */         }
/*     */       }
/* 175 */       else if (flowInfo != FlowInfo.DEAD_END) {
/* 176 */         this.scope.problemReporter().shouldReturn(returnTypeBinding, this);
/*     */       } 
/*     */ 
/*     */       
/* 180 */       methodContext.complainIfUnusedExceptionHandlers(this);
/*     */       
/* 182 */       this.scope.checkUnusedParameters(this.binding);
/*     */       
/* 184 */       if (!this.binding.isStatic() && (this.bits & 0x100) != 0 && !isDefaultMethod() && 
/* 185 */         !this.binding.isOverriding() && !this.binding.isImplementing()) {
/* 186 */         if (this.binding.isPrivate() || this.binding.isFinal() || this.binding.declaringClass.isFinal()) {
/* 187 */           this.scope.problemReporter().methodCanBeDeclaredStatic(this);
/*     */         } else {
/* 189 */           this.scope.problemReporter().methodCanBePotentiallyDeclaredStatic(this);
/*     */         } 
/*     */       }
/*     */ 
/*     */       
/* 194 */       this.scope.checkUnclosedCloseables(flowInfo, null, null, null);
/* 195 */     } catch (AbortMethod abortMethod) {
/* 196 */       this.ignoreFurtherInvestigation = true;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void getAllAnnotationContexts(int targetType, List<AnnotationContext> allAnnotationContexts) {
/* 202 */     TypeReference.AnnotationCollector collector = new TypeReference.AnnotationCollector(this.returnType, targetType, allAnnotationContexts);
/* 203 */     for (int i = 0, max = this.annotations.length; i < max; i++) {
/* 204 */       Annotation annotation = this.annotations[i];
/* 205 */       annotation.traverse(collector, (BlockScope)null);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean hasNullTypeAnnotation(TypeReference.AnnotationPosition position) {
/* 211 */     return !(!TypeReference.containsNullAnnotation(this.annotations) && (
/* 212 */       this.returnType == null || !this.returnType.hasNullTypeAnnotation(position)));
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isDefaultMethod() {
/* 217 */     return ((this.modifiers & 0x10000) != 0);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isMethod() {
/* 222 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public RecordComponent getRecordComponent() {
/* 227 */     if (this.arguments != null && this.arguments.length != 0)
/* 228 */       return null; 
/* 229 */     ClassScope skope = this.scope.classScope();
/* 230 */     TypeDeclaration typeDecl = skope.referenceContext;
/* 231 */     if (!typeDecl.isRecord())
/* 232 */       return null; 
/* 233 */     if (!skope.referenceContext.isRecord())
/* 234 */       return null; 
/* 235 */     RecordComponent[] recComps = typeDecl.recordComponents;
/* 236 */     if (recComps == null || recComps.length == 0)
/* 237 */       return null;  byte b; int i; RecordComponent[] arrayOfRecordComponent1;
/* 238 */     for (i = (arrayOfRecordComponent1 = recComps).length, b = 0; b < i; ) { RecordComponent recComp = arrayOfRecordComponent1[b];
/* 239 */       if (recComp != null && recComp.name != null)
/*     */       {
/* 241 */         if (CharOperation.equals(this.selector, recComp.name))
/* 242 */           return recComp;  } 
/*     */       b++; }
/*     */     
/* 245 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void parseStatements(Parser parser, CompilationUnitDeclaration unit) {
/* 251 */     parser.parse(this, unit);
/* 252 */     this.containsSwitchWithTry = parser.switchWithTry;
/*     */   }
/*     */ 
/*     */   
/*     */   public StringBuffer printReturnType(int indent, StringBuffer output) {
/* 257 */     if (this.returnType == null) return output; 
/* 258 */     return this.returnType.printExpression(0, output).append(' ');
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void resolveStatements() {
/* 264 */     if (this.returnType != null && this.binding != null) {
/* 265 */       this.bits |= this.returnType.bits & 0x100000;
/* 266 */       this.returnType.resolvedType = this.binding.returnType;
/*     */     } 
/*     */     
/* 269 */     RecordComponent recordComponent = getRecordComponent();
/* 270 */     if (recordComponent != null) {
/*     */       
/* 272 */       if (this.returnType != null && TypeBinding.notEquals(this.returnType.resolvedType, recordComponent.type.resolvedType))
/* 273 */         this.scope.problemReporter().recordIllegalAccessorReturnType(this.returnType, recordComponent.type.resolvedType); 
/* 274 */       if (this.typeParameters != null)
/* 275 */         this.scope.problemReporter().recordAccessorMethodShouldNotBeGeneric(this); 
/* 276 */       if (this.binding != null) {
/* 277 */         if ((this.binding.modifiers & 0x1) == 0)
/* 278 */           this.scope.problemReporter().recordAccessorMethodShouldBePublic(this); 
/* 279 */         if ((this.binding.modifiers & 0x8) != 0)
/* 280 */           this.scope.problemReporter().recordAccessorMethodShouldNotBeStatic(this); 
/*     */       } 
/* 282 */       if (this.thrownExceptions != null) {
/* 283 */         this.scope.problemReporter().recordAccessorMethodHasThrowsClause(this);
/*     */       }
/*     */     } 
/* 286 */     if (CharOperation.equals((this.scope.enclosingSourceType()).sourceName, this.selector)) {
/* 287 */       this.scope.problemReporter().methodWithConstructorName(this);
/*     */     }
/*     */     
/* 290 */     boolean returnsUndeclTypeVar = false;
/* 291 */     if (this.returnType != null && this.returnType.resolvedType instanceof org.eclipse.jdt.internal.compiler.lookup.TypeVariableBinding) {
/* 292 */       returnsUndeclTypeVar = true;
/*     */     }
/* 294 */     if (this.typeParameters != null) {
/* 295 */       for (int i = 0, length = this.typeParameters.length; i < length; i++) {
/* 296 */         TypeParameter typeParameter = this.typeParameters[i];
/* 297 */         this.bits |= typeParameter.bits & 0x100000;
/*     */         
/* 299 */         if (returnsUndeclTypeVar && TypeBinding.equalsEquals((TypeBinding)(this.typeParameters[i]).binding, this.returnType.resolvedType)) {
/* 300 */           returnsUndeclTypeVar = false;
/*     */         }
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/* 306 */     CompilerOptions compilerOptions = this.scope.compilerOptions();
/*     */ 
/*     */     
/* 309 */     if (this.binding != null && recordComponent == null) {
/* 310 */       long complianceLevel = compilerOptions.complianceLevel;
/* 311 */       if (complianceLevel >= 3211264L) {
/* 312 */         int bindingModifiers = this.binding.modifiers;
/* 313 */         boolean hasOverrideAnnotation = ((this.binding.tagBits & 0x2000000000000L) != 0L);
/* 314 */         boolean hasUnresolvedArguments = ((this.binding.tagBits & 0x200L) != 0L);
/* 315 */         if (hasOverrideAnnotation && !hasUnresolvedArguments) {
/*     */           
/* 317 */           if ((bindingModifiers & 0x10000008) != 268435456)
/*     */           {
/*     */ 
/*     */             
/* 321 */             if (complianceLevel < 3276800L || (
/* 322 */               bindingModifiers & 0x20000008) != 536870912)
/*     */             {
/*     */               
/* 325 */               this.scope.problemReporter().methodMustOverride(this, complianceLevel);
/*     */             }
/*     */           }
/*     */         }
/* 329 */         else if (!this.binding.declaringClass.isInterface()) {
/* 330 */           if ((bindingModifiers & 0x10000008) == 268435456) {
/* 331 */             this.scope.problemReporter().missingOverrideAnnotation(this);
/*     */           }
/* 333 */           else if (complianceLevel >= 3276800L && 
/* 334 */             compilerOptions.reportMissingOverrideAnnotationForInterfaceMethodImplementation && 
/* 335 */             this.binding.isImplementing()) {
/*     */             
/* 337 */             this.scope.problemReporter().missingOverrideAnnotationForInterfaceMethodImplementation(this);
/*     */ 
/*     */           
/*     */           }
/*     */ 
/*     */ 
/*     */         
/*     */         }
/* 345 */         else if (complianceLevel >= 3276800L && 
/* 346 */           compilerOptions.reportMissingOverrideAnnotationForInterfaceMethodImplementation && ((
/* 347 */           bindingModifiers & 0x10000008) == 268435456 || this.binding.isImplementing())) {
/*     */           
/* 349 */           this.scope.problemReporter().missingOverrideAnnotationForInterfaceMethodImplementation(this);
/*     */         } 
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 355 */     switch (TypeDeclaration.kind((this.scope.referenceType()).modifiers)) {
/*     */       case 3:
/* 357 */         if (this.selector == TypeConstants.VALUES || 
/* 358 */           this.selector == TypeConstants.VALUEOF) {
/*     */           break;
/*     */         }
/*     */       
/*     */       case 1:
/*     */       case 5:
/* 364 */         if ((this.modifiers & 0x1000000) != 0) {
/* 365 */           if ((this.modifiers & 0x100) == 0 && (
/* 366 */             this.modifiers & 0x400) == 0)
/* 367 */             this.scope.problemReporter().methodNeedBody(this); 
/*     */           break;
/*     */         } 
/* 370 */         if ((this.modifiers & 0x100) != 0 || (this.modifiers & 0x400) != 0) {
/* 371 */           this.scope.problemReporter().methodNeedingNoBody(this); break;
/* 372 */         }  if (this.binding == null || this.binding.isStatic() || this.binding.declaringClass instanceof org.eclipse.jdt.internal.compiler.lookup.LocalTypeBinding || returnsUndeclTypeVar)
/*     */         {
/* 374 */           this.bits &= 0xFFFFFEFF;
/*     */         }
/*     */         break;
/*     */       
/*     */       case 2:
/* 379 */         if (compilerOptions.sourceLevel >= 3407872L && (
/* 380 */           this.modifiers & 0x1000400) == 16777216) {
/* 381 */           boolean isPrivateMethod = (compilerOptions.sourceLevel >= 3473408L && (this.modifiers & 0x2) != 0);
/* 382 */           if (isPrivateMethod || (this.modifiers & 0x10008) != 0) {
/* 383 */             this.scope.problemReporter().methodNeedBody(this);
/*     */           }
/*     */         } 
/*     */         break;
/*     */     } 
/* 388 */     super.resolveStatements();
/*     */ 
/*     */     
/* 391 */     if (compilerOptions.getSeverity(537919488) != 256 && 
/* 392 */       this.binding != null) {
/* 393 */       int bindingModifiers = this.binding.modifiers;
/* 394 */       if ((bindingModifiers & 0x30000000) == 268435456 && (
/* 395 */         this.bits & 0x10) == 0) {
/* 396 */         this.scope.problemReporter().overridesMethodWithoutSuperInvocation(this.binding);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void traverse(ASTVisitor visitor, ClassScope classScope) {
/* 407 */     if (visitor.visit(this, classScope)) {
/* 408 */       if (this.javadoc != null) {
/* 409 */         this.javadoc.traverse(visitor, (BlockScope)this.scope);
/*     */       }
/* 411 */       if (this.annotations != null) {
/* 412 */         int annotationsLength = this.annotations.length;
/* 413 */         for (int i = 0; i < annotationsLength; i++)
/* 414 */           this.annotations[i].traverse(visitor, (BlockScope)this.scope); 
/*     */       } 
/* 416 */       if (this.typeParameters != null) {
/* 417 */         int typeParametersLength = this.typeParameters.length;
/* 418 */         for (int i = 0; i < typeParametersLength; i++) {
/* 419 */           this.typeParameters[i].traverse(visitor, (BlockScope)this.scope);
/*     */         }
/*     */       } 
/* 422 */       if (this.returnType != null)
/* 423 */         this.returnType.traverse(visitor, (BlockScope)this.scope); 
/* 424 */       if (this.arguments != null) {
/* 425 */         int argumentLength = this.arguments.length;
/* 426 */         for (int i = 0; i < argumentLength; i++)
/* 427 */           this.arguments[i].traverse(visitor, (BlockScope)this.scope); 
/*     */       } 
/* 429 */       if (this.thrownExceptions != null) {
/* 430 */         int thrownExceptionsLength = this.thrownExceptions.length;
/* 431 */         for (int i = 0; i < thrownExceptionsLength; i++)
/* 432 */           this.thrownExceptions[i].traverse(visitor, (BlockScope)this.scope); 
/*     */       } 
/* 434 */       if (this.statements != null) {
/* 435 */         int statementsLength = this.statements.length;
/* 436 */         for (int i = 0; i < statementsLength; i++)
/* 437 */           this.statements[i].traverse(visitor, (BlockScope)this.scope); 
/*     */       } 
/*     */     } 
/* 440 */     visitor.endVisit(this, classScope);
/*     */   }
/*     */   
/*     */   public TypeParameter[] typeParameters() {
/* 444 */     return this.typeParameters;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\ast\MethodDeclaration.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */