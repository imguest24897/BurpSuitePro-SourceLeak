/*     */ package org.eclipse.jdt.internal.compiler.batch;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Enumeration;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.zip.ZipEntry;
/*     */ import org.eclipse.jdt.core.compiler.CharOperation;
/*     */ import org.eclipse.jdt.internal.compiler.classfmt.ClassFileReader;
/*     */ import org.eclipse.jdt.internal.compiler.classfmt.ClassFormatException;
/*     */ import org.eclipse.jdt.internal.compiler.classfmt.ExternalAnnotationDecorator;
/*     */ import org.eclipse.jdt.internal.compiler.env.AccessRuleSet;
/*     */ import org.eclipse.jdt.internal.compiler.env.IBinaryType;
/*     */ import org.eclipse.jdt.internal.compiler.env.IModule;
/*     */ import org.eclipse.jdt.internal.compiler.env.NameEnvironmentAnswer;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.BinaryTypeBinding;
/*     */ import org.eclipse.jdt.internal.compiler.util.Util;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ClasspathJmod
/*     */   extends ClasspathJar
/*     */ {
/*  40 */   public static char[] CLASSES = "classes".toCharArray();
/*  41 */   public static char[] CLASSES_FOLDER = "classes/".toCharArray();
/*     */ 
/*     */   
/*     */   public ClasspathJmod(File file, boolean closeZipFileAtEnd, AccessRuleSet accessRuleSet, String destinationPath) {
/*  45 */     super(file, closeZipFileAtEnd, accessRuleSet, destinationPath);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public List<FileSystem.Classpath> fetchLinkedJars(FileSystem.ClasspathSectionProblemReporter problemReporter) {
/*  51 */     return null;
/*     */   }
/*     */   
/*     */   public NameEnvironmentAnswer findClass(char[] typeName, String qualifiedPackageName, String moduleName, String qualifiedBinaryFileName, boolean asBinaryOnly) {
/*  55 */     if (!isPackage(qualifiedPackageName, moduleName)) {
/*  56 */       return null;
/*     */     }
/*     */     try {
/*  59 */       qualifiedBinaryFileName = new String(CharOperation.append(CLASSES_FOLDER, qualifiedBinaryFileName.toCharArray()));
/*  60 */       ClassFileReader classFileReader = ClassFileReader.read(this.zipFile, qualifiedBinaryFileName);
/*  61 */       if (classFileReader != null) {
/*  62 */         IBinaryType iBinaryType; char[] modName = (this.module == null) ? null : this.module.name();
/*  63 */         if (classFileReader instanceof ClassFileReader) {
/*  64 */           ClassFileReader classReader = classFileReader;
/*  65 */           if (classReader.moduleName == null) {
/*  66 */             classReader.moduleName = modName;
/*     */           } else {
/*  68 */             modName = classReader.moduleName;
/*     */           } 
/*     */         } 
/*  71 */         if (this.annotationPaths != null)
/*  72 */         { String qualifiedClassName = qualifiedBinaryFileName.substring(0, qualifiedBinaryFileName.length() - "CLASS".length() - 1);
/*  73 */           Iterator<String> iterator = this.annotationPaths.iterator(); while (true) { ExternalAnnotationDecorator externalAnnotationDecorator; if (!iterator.hasNext())
/*     */             
/*     */             { 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */               
/*  88 */               externalAnnotationDecorator = new ExternalAnnotationDecorator((IBinaryType)classFileReader, null); break; }  String annotationPath = iterator.next(); try { if (this.annotationZipFile == null)
/*     */                 this.annotationZipFile = ExternalAnnotationDecorator.getAnnotationZipFile(annotationPath, null);  iBinaryType = ExternalAnnotationDecorator.create((IBinaryType)externalAnnotationDecorator, annotationPath, qualifiedClassName, this.annotationZipFile); if (iBinaryType.getExternalAnnotationStatus() == BinaryTypeBinding.ExternalAnnotationStatus.TYPE_IS_ANNOTATED)
/*  90 */                 break;  } catch (IOException iOException) {} }  }  return new NameEnvironmentAnswer(iBinaryType, fetchAccessRestriction(qualifiedBinaryFileName), modName);
/*     */       } 
/*  92 */     } catch (ClassFormatException|IOException classFormatException) {}
/*     */ 
/*     */     
/*  95 */     return null;
/*     */   }
/*     */   
/*     */   public boolean hasAnnotationFileFor(String qualifiedTypeName) {
/*  99 */     qualifiedTypeName = new String(CharOperation.append(CLASSES_FOLDER, qualifiedTypeName.toCharArray()));
/* 100 */     return (this.zipFile.getEntry(String.valueOf(qualifiedTypeName) + ".eea") != null);
/*     */   }
/*     */ 
/*     */   
/*     */   public char[][][] findTypeNames(String qualifiedPackageName, String moduleName) {
/* 105 */     if (!isPackage(qualifiedPackageName, moduleName))
/* 106 */       return null; 
/* 107 */     char[] packageArray = qualifiedPackageName.toCharArray();
/* 108 */     ArrayList<char[][]> answers = new ArrayList();
/* 109 */     for (Enumeration<? extends ZipEntry> e = this.zipFile.entries(); e.hasMoreElements(); ) {
/* 110 */       String fileName = ((ZipEntry)e.nextElement()).getName();
/*     */ 
/*     */       
/* 113 */       int first = CharOperation.indexOf(CLASSES_FOLDER, fileName.toCharArray(), false);
/* 114 */       int last = fileName.lastIndexOf('/');
/* 115 */       if (last > 0) {
/*     */         
/* 117 */         String packageName = fileName.substring(first + 1, last);
/* 118 */         if (!qualifiedPackageName.equals(packageName))
/*     */           continue; 
/* 120 */         int indexOfDot = fileName.lastIndexOf('.');
/* 121 */         if (indexOfDot != -1) {
/* 122 */           String typeName = fileName.substring(last + 1, indexOfDot);
/* 123 */           answers.add(
/* 124 */               CharOperation.arrayConcat(
/* 125 */                 CharOperation.splitOn('/', packageArray), 
/* 126 */                 typeName.toCharArray()));
/*     */         } 
/*     */       } 
/*     */     } 
/* 130 */     int size = answers.size();
/* 131 */     if (size != 0) {
/* 132 */       char[][][] result = new char[size][][];
/* 133 */       answers.toArray(result);
/* 134 */       return result;
/*     */     } 
/* 136 */     return null;
/*     */   }
/*     */   
/*     */   public synchronized char[][] getModulesDeclaringPackage(String qualifiedPackageName, String moduleName) {
/* 140 */     if (this.packageCache != null) {
/* 141 */       return singletonModuleNameIf(this.packageCache.contains(qualifiedPackageName));
/*     */     }
/* 143 */     this.packageCache = new HashSet<>(41);
/* 144 */     this.packageCache.add(Util.EMPTY_STRING);
/*     */     
/* 146 */     for (Enumeration<? extends ZipEntry> e = this.zipFile.entries(); e.hasMoreElements(); ) {
/* 147 */       char[] entryName = ((ZipEntry)e.nextElement()).getName().toCharArray();
/* 148 */       int index = CharOperation.indexOf('/', entryName);
/* 149 */       if (index != -1) {
/* 150 */         char[] folder = CharOperation.subarray(entryName, 0, index);
/* 151 */         if (CharOperation.equals(CLASSES, folder)) {
/* 152 */           char[] fileName = CharOperation.subarray(entryName, index + 1, entryName.length);
/* 153 */           addToPackageCache(new String(fileName), false);
/*     */         } 
/*     */       } 
/*     */     } 
/* 157 */     return singletonModuleNameIf(this.packageCache.contains(qualifiedPackageName));
/*     */   }
/*     */   
/*     */   public boolean hasCompilationUnit(String qualifiedPackageName, String moduleName) {
/* 161 */     qualifiedPackageName = String.valueOf(qualifiedPackageName) + '/';
/* 162 */     for (Enumeration<? extends ZipEntry> e = this.zipFile.entries(); e.hasMoreElements(); ) {
/* 163 */       char[] entryName = ((ZipEntry)e.nextElement()).getName().toCharArray();
/* 164 */       int index = CharOperation.indexOf('/', entryName);
/* 165 */       if (index != -1) {
/* 166 */         char[] folder = CharOperation.subarray(entryName, 0, index);
/* 167 */         if (CharOperation.equals(CLASSES, folder)) {
/* 168 */           String fileName = new String(CharOperation.subarray(entryName, index + 1, entryName.length));
/* 169 */           if (fileName.startsWith(qualifiedPackageName) && fileName.length() > qualifiedPackageName.length()) {
/* 170 */             String tail = fileName.substring(qualifiedPackageName.length());
/* 171 */             if (tail.indexOf('/') != -1)
/*     */               continue; 
/* 173 */             if (tail.toLowerCase().endsWith(".class"))
/* 174 */               return true; 
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/* 179 */     return false;
/*     */   }
/*     */   
/*     */   public String toString() {
/* 183 */     return "Classpath for JMod file " + this.file.getPath();
/*     */   }
/*     */   
/*     */   public IModule getModule() {
/* 187 */     return this.module;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\batch\ClasspathJmod.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */