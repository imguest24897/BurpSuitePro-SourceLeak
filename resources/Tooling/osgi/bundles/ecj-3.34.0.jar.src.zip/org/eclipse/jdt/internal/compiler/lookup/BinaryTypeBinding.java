/*      */ package org.eclipse.jdt.internal.compiler.lookup;
/*      */ 
/*      */ import java.net.URI;
/*      */ import java.util.ArrayList;
/*      */ import org.eclipse.jdt.core.compiler.CharOperation;
/*      */ import org.eclipse.jdt.internal.compiler.ast.Annotation;
/*      */ import org.eclipse.jdt.internal.compiler.classfmt.AnnotationInfo;
/*      */ import org.eclipse.jdt.internal.compiler.classfmt.ExternalAnnotationProvider;
/*      */ import org.eclipse.jdt.internal.compiler.classfmt.NonNullDefaultAwareTypeAnnotationWalker;
/*      */ import org.eclipse.jdt.internal.compiler.classfmt.TypeAnnotationWalker;
/*      */ import org.eclipse.jdt.internal.compiler.codegen.ConstantPool;
/*      */ import org.eclipse.jdt.internal.compiler.env.ClassSignature;
/*      */ import org.eclipse.jdt.internal.compiler.env.EnumConstantSignature;
/*      */ import org.eclipse.jdt.internal.compiler.env.IBinaryAnnotation;
/*      */ import org.eclipse.jdt.internal.compiler.env.IBinaryElementValuePair;
/*      */ import org.eclipse.jdt.internal.compiler.env.IBinaryField;
/*      */ import org.eclipse.jdt.internal.compiler.env.IBinaryMethod;
/*      */ import org.eclipse.jdt.internal.compiler.env.IBinaryNestedType;
/*      */ import org.eclipse.jdt.internal.compiler.env.IBinaryType;
/*      */ import org.eclipse.jdt.internal.compiler.env.IBinaryTypeAnnotation;
/*      */ import org.eclipse.jdt.internal.compiler.env.IRecordComponent;
/*      */ import org.eclipse.jdt.internal.compiler.env.ITypeAnnotationWalker;
/*      */ import org.eclipse.jdt.internal.compiler.impl.BooleanConstant;
/*      */ import org.eclipse.jdt.internal.compiler.impl.CompilerOptions;
/*      */ import org.eclipse.jdt.internal.compiler.problem.AbortCompilation;
/*      */ import org.eclipse.jdt.internal.compiler.util.SimpleLookupTable;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class BinaryTypeBinding
/*      */   extends ReferenceBinding
/*      */ {
/*   97 */   public static final char[] TYPE_QUALIFIER_DEFAULT = "TypeQualifierDefault".toCharArray();
/*      */   
/*   99 */   private static final IBinaryMethod[] NO_BINARY_METHODS = new IBinaryMethod[0];
/*      */   
/*      */   protected ReferenceBinding superclass;
/*      */   
/*      */   protected ReferenceBinding enclosingType;
/*      */   
/*      */   protected ReferenceBinding[] superInterfaces;
/*      */   
/*      */   protected ReferenceBinding[] permittedSubtypes;
/*      */   
/*      */   protected FieldBinding[] fields;
/*      */   protected RecordComponentBinding[] components;
/*      */   protected MethodBinding[] methods;
/*      */   protected ReferenceBinding[] memberTypes;
/*      */   protected TypeVariableBinding[] typeVariables;
/*      */   protected ModuleBinding module;
/*      */   private BinaryTypeBinding prototype;
/*      */   public URI path;
/*      */   protected LookupEnvironment environment;
/*  118 */   protected SimpleLookupTable storedAnnotations = null;
/*      */   
/*      */   private ReferenceBinding containerAnnotationType;
/*  121 */   int defaultNullness = 0;
/*      */   boolean memberTypesSorted = false;
/*      */   
/*  124 */   public enum ExternalAnnotationStatus { FROM_SOURCE,
/*  125 */     NOT_EEA_CONFIGURED,
/*  126 */     NO_EEA_FILE,
/*  127 */     TYPE_IS_ANNOTATED;
/*      */     public boolean isPotentiallyUnannotatedLib() {
/*  129 */       switch (this) {
/*      */         case null:
/*      */         case TYPE_IS_ANNOTATED:
/*  132 */           return false;
/*      */       } 
/*  134 */       return true;
/*      */     } }
/*      */ 
/*      */   
/*  138 */   public ExternalAnnotationStatus externalAnnotationStatus = ExternalAnnotationStatus.NOT_EEA_CONFIGURED;
/*      */   
/*      */   static Object convertMemberValue(Object binaryValue, LookupEnvironment env, char[][][] missingTypeNames, boolean resolveEnumConstants) {
/*  141 */     if (binaryValue == null) return null; 
/*  142 */     if (binaryValue instanceof org.eclipse.jdt.internal.compiler.impl.Constant)
/*  143 */       return binaryValue; 
/*  144 */     if (binaryValue instanceof ClassSignature)
/*  145 */       return env.getTypeFromSignature(((ClassSignature)binaryValue).getTypeName(), 0, -1, false, null, missingTypeNames, ITypeAnnotationWalker.EMPTY_ANNOTATION_WALKER); 
/*  146 */     if (binaryValue instanceof IBinaryAnnotation)
/*  147 */       return createAnnotation((IBinaryAnnotation)binaryValue, env, missingTypeNames); 
/*  148 */     if (binaryValue instanceof EnumConstantSignature) {
/*  149 */       EnumConstantSignature ref = (EnumConstantSignature)binaryValue;
/*  150 */       ReferenceBinding enumType = (ReferenceBinding)env.getTypeFromSignature(ref.getTypeName(), 0, -1, false, null, missingTypeNames, ITypeAnnotationWalker.EMPTY_ANNOTATION_WALKER);
/*  151 */       if ((enumType.isUnresolvedType() || !enumType.isFieldInitializationFinished()) && !resolveEnumConstants)
/*  152 */         return new ElementValuePair.UnresolvedEnumConstant(enumType, env, ref.getEnumConstantName()); 
/*  153 */       enumType = (ReferenceBinding)resolveType(enumType, env, false);
/*  154 */       return enumType.getField(ref.getEnumConstantName(), false);
/*      */     } 
/*  156 */     if (binaryValue instanceof Object[]) {
/*  157 */       Object[] objects = (Object[])binaryValue;
/*  158 */       int length = objects.length;
/*  159 */       if (length == 0) return objects; 
/*  160 */       Object[] values = new Object[length];
/*  161 */       for (int i = 0; i < length; i++)
/*  162 */         values[i] = convertMemberValue(objects[i], env, missingTypeNames, resolveEnumConstants); 
/*  163 */       return values;
/*      */     } 
/*      */ 
/*      */     
/*  167 */     throw new IllegalStateException();
/*      */   }
/*      */ 
/*      */   
/*      */   public TypeBinding clone(TypeBinding outerType) {
/*  172 */     BinaryTypeBinding copy = new BinaryTypeBinding(this);
/*  173 */     copy.enclosingType = (ReferenceBinding)outerType;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  181 */     if (copy.enclosingType != null) {
/*  182 */       copy.tagBits |= 0x8000000L;
/*      */     } else {
/*  184 */       copy.tagBits &= 0xFFFFFFFFF7FFFFFFL;
/*      */     } 
/*  186 */     copy.tagBits |= 0x10000000L;
/*  187 */     return copy;
/*      */   }
/*      */ 
/*      */   
/*      */   static AnnotationBinding createAnnotation(IBinaryAnnotation annotationInfo, LookupEnvironment env, char[][][] missingTypeNames) {
/*  192 */     if (annotationInfo instanceof AnnotationInfo) {
/*  193 */       RuntimeException ex = ((AnnotationInfo)annotationInfo).exceptionDuringDecode;
/*  194 */       if (ex != null) {
/*  195 */         (new IllegalStateException("Accessing annotation with decode error", ex)).printStackTrace();
/*      */       }
/*      */     } 
/*  198 */     IBinaryElementValuePair[] binaryPairs = annotationInfo.getElementValuePairs();
/*  199 */     int length = (binaryPairs == null) ? 0 : binaryPairs.length;
/*  200 */     ElementValuePair[] pairs = (length == 0) ? Binding.NO_ELEMENT_VALUE_PAIRS : new ElementValuePair[length];
/*  201 */     for (int i = 0; i < length; i++) {
/*  202 */       pairs[i] = new ElementValuePair(binaryPairs[i].getName(), convertMemberValue(binaryPairs[i].getValue(), env, missingTypeNames, false), null);
/*      */     }
/*  204 */     char[] typeName = annotationInfo.getTypeName();
/*  205 */     LookupEnvironment env2 = annotationInfo.isExternalAnnotation() ? env.root : env;
/*  206 */     ReferenceBinding annotationType = env2.getTypeFromConstantPoolName(typeName, 1, typeName.length - 1, false, 
/*  207 */         missingTypeNames);
/*  208 */     return env2.createUnresolvedAnnotation(annotationType, pairs);
/*      */   }
/*      */   
/*      */   public static AnnotationBinding[] createAnnotations(IBinaryAnnotation[] annotationInfos, LookupEnvironment env, char[][][] missingTypeNames) {
/*  212 */     int length = (annotationInfos == null) ? 0 : annotationInfos.length;
/*  213 */     AnnotationBinding[] result = (length == 0) ? Binding.NO_ANNOTATIONS : new AnnotationBinding[length];
/*  214 */     for (int i = 0; i < length; i++)
/*  215 */       result[i] = createAnnotation(annotationInfos[i], env, missingTypeNames); 
/*  216 */     return result;
/*      */   } public static TypeBinding resolveType(TypeBinding type, LookupEnvironment environment, boolean convertGenericToRawType) {
/*      */     ArrayBinding arrayBinding;
/*      */     TypeBinding leafComponentType;
/*  220 */     switch (type.kind())
/*      */     { case 260:
/*  222 */         ((ParameterizedTypeBinding)type).resolve();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  256 */         return type;case 516: case 8196: return ((WildcardBinding)type).resolve();case 68: arrayBinding = (ArrayBinding)type; leafComponentType = arrayBinding.leafComponentType; resolveType(leafComponentType, environment, convertGenericToRawType); if (leafComponentType.hasNullTypeAnnotations() && environment.usesNullTypeAnnotations()) { if (arrayBinding.nullTagBitsPerDimension == null) arrayBinding.nullTagBitsPerDimension = new long[arrayBinding.dimensions + 1];  arrayBinding.nullTagBitsPerDimension[arrayBinding.dimensions] = leafComponentType.tagBits & 0x180000000000000L; }  return type;case 4100: ((TypeVariableBinding)type).resolve(); return type;case 2052: if (convertGenericToRawType) return environment.convertUnresolvedBinaryToRawType(type);  return type; }  if (type instanceof UnresolvedReferenceBinding) return ((UnresolvedReferenceBinding)type).resolve(environment, convertGenericToRawType);  if (convertGenericToRawType) return environment.convertUnresolvedBinaryToRawType(type);  return type;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected BinaryTypeBinding() {
/*  264 */     this.prototype = this;
/*      */   }
/*      */   
/*      */   public BinaryTypeBinding(BinaryTypeBinding prototype) {
/*  268 */     super(prototype);
/*  269 */     this.superclass = prototype.superclass;
/*  270 */     this.enclosingType = prototype.enclosingType;
/*  271 */     this.superInterfaces = prototype.superInterfaces;
/*  272 */     this.permittedSubtypes = prototype.permittedSubtypes;
/*  273 */     this.fields = prototype.fields;
/*  274 */     this.components = prototype.components;
/*  275 */     this.methods = prototype.methods;
/*  276 */     this.memberTypes = prototype.memberTypes;
/*  277 */     this.typeVariables = prototype.typeVariables;
/*  278 */     this.prototype = prototype.prototype;
/*  279 */     this.environment = prototype.environment;
/*  280 */     this.storedAnnotations = prototype.storedAnnotations;
/*  281 */     this.path = prototype.path;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public BinaryTypeBinding(PackageBinding packageBinding, IBinaryType binaryType, LookupEnvironment environment) {
/*  291 */     this(packageBinding, binaryType, environment, false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public BinaryTypeBinding(PackageBinding packageBinding, IBinaryType binaryType, LookupEnvironment environment, boolean needFieldsAndMethods) {
/*  302 */     this.prototype = this;
/*  303 */     this.compoundName = CharOperation.splitOn('/', binaryType.getName());
/*  304 */     computeId();
/*      */     
/*  306 */     this.tagBits |= 0x40L;
/*  307 */     this.environment = environment;
/*  308 */     this.fPackage = packageBinding;
/*  309 */     this.fileName = binaryType.getFileName();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  315 */     char[] typeSignature = binaryType.getGenericSignature();
/*  316 */     this.typeVariables = (typeSignature != null && typeSignature.length > 0 && typeSignature[0] == '<') ? 
/*  317 */       null : 
/*  318 */       Binding.NO_TYPE_VARIABLES;
/*      */     
/*  320 */     this.sourceName = binaryType.getSourceName();
/*  321 */     this.modifiers = binaryType.getModifiers();
/*      */     
/*  323 */     if ((binaryType.getTagBits() & 0x20000L) != 0L) {
/*  324 */       this.tagBits |= 0x20000L;
/*      */     }
/*  326 */     if (binaryType.isAnonymous()) {
/*  327 */       this.tagBits |= 0x834L;
/*  328 */     } else if (binaryType.isLocal()) {
/*  329 */       this.tagBits |= 0x814L;
/*  330 */     } else if (binaryType.isMember()) {
/*  331 */       this.tagBits |= 0x80CL;
/*      */     } 
/*      */     
/*  334 */     char[] enclosingTypeName = binaryType.getEnclosingTypeName();
/*  335 */     if (enclosingTypeName != null) {
/*      */       
/*  337 */       this.enclosingType = environment.getTypeFromConstantPoolName(enclosingTypeName, 0, -1, true, null);
/*  338 */       this.tagBits |= 0x80CL;
/*  339 */       this.tagBits |= 0x8000000L;
/*  340 */       if (enclosingType().isStrictfp())
/*  341 */         this.modifiers |= 0x800; 
/*  342 */       if (enclosingType().isDeprecated())
/*  343 */         this.modifiers |= 0x200000; 
/*      */     } 
/*  345 */     if (needFieldsAndMethods)
/*  346 */       cachePartsFrom(binaryType, true); 
/*  347 */     this.path = binaryType.getURI();
/*      */   }
/*      */   
/*      */   public boolean canBeSeenBy(Scope sco) {
/*  351 */     ModuleBinding mod = sco.module();
/*  352 */     return (mod.canAccess(this.fPackage) && super.canBeSeenBy(sco));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public FieldBinding[] availableFields() {
/*  360 */     if (!isPrototype()) {
/*  361 */       return this.prototype.availableFields();
/*      */     }
/*      */     
/*  364 */     if ((this.tagBits & 0x2000L) != 0L) {
/*  365 */       return this.fields;
/*      */     }
/*      */     
/*  368 */     if ((this.tagBits & 0x1000L) == 0L) {
/*  369 */       int length = this.fields.length;
/*  370 */       if (length > 1)
/*  371 */         ReferenceBinding.sortFields(this.fields, 0, length); 
/*  372 */       this.tagBits |= 0x1000L;
/*      */     } 
/*  374 */     FieldBinding[] availableFields = new FieldBinding[this.fields.length];
/*  375 */     int count = 0;
/*  376 */     for (int i = 0; i < this.fields.length; i++) {
/*      */       try {
/*  378 */         availableFields[count] = resolveTypeFor(this.fields[i]);
/*  379 */         count++;
/*  380 */       } catch (AbortCompilation abortCompilation) {}
/*      */     } 
/*      */ 
/*      */     
/*  384 */     if (count < availableFields.length)
/*  385 */       System.arraycopy(availableFields, 0, availableFields = new FieldBinding[count], 0, count); 
/*  386 */     return availableFields;
/*      */   }
/*      */   
/*      */   private TypeVariableBinding[] addMethodTypeVariables(TypeVariableBinding[] methodTypeVars) {
/*  390 */     if (!isPrototype()) throw new IllegalStateException(); 
/*  391 */     if (this.typeVariables == null || this.typeVariables == Binding.NO_TYPE_VARIABLES) {
/*  392 */       return methodTypeVars;
/*      */     }
/*  394 */     if (methodTypeVars == null || methodTypeVars == Binding.NO_TYPE_VARIABLES) {
/*  395 */       return this.typeVariables;
/*      */     }
/*      */     
/*  398 */     int total = this.typeVariables.length + methodTypeVars.length;
/*  399 */     TypeVariableBinding[] combinedTypeVars = new TypeVariableBinding[total];
/*  400 */     System.arraycopy(this.typeVariables, 0, combinedTypeVars, 0, this.typeVariables.length);
/*  401 */     int size = this.typeVariables.length;
/*  402 */     for (int i = 0, len = methodTypeVars.length; i < len; i++) {
/*  403 */       int j = this.typeVariables.length - 1; while (true) { if (j < 0)
/*      */         
/*      */         { 
/*      */           
/*  407 */           combinedTypeVars[size++] = methodTypeVars[i]; break; }  if (CharOperation.equals((methodTypeVars[i]).sourceName, (this.typeVariables[j]).sourceName))
/*      */           break;  j--; } 
/*  409 */     }  if (size != total) {
/*  410 */       System.arraycopy(combinedTypeVars, 0, combinedTypeVars = new TypeVariableBinding[size], 0, size);
/*      */     }
/*  412 */     return combinedTypeVars;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MethodBinding[] availableMethods() {
/*  421 */     if (!isPrototype()) {
/*  422 */       return this.prototype.availableMethods();
/*      */     }
/*      */     
/*  425 */     if ((this.tagBits & 0x8000L) != 0L) {
/*  426 */       return this.methods;
/*      */     }
/*      */     
/*  429 */     if ((this.tagBits & 0x4000L) == 0L) {
/*  430 */       int length = this.methods.length;
/*  431 */       if (length > 1)
/*  432 */         ReferenceBinding.sortMethods(this.methods, 0, length); 
/*  433 */       this.tagBits |= 0x4000L;
/*      */     } 
/*  435 */     MethodBinding[] availableMethods = new MethodBinding[this.methods.length];
/*  436 */     int count = 0;
/*  437 */     for (int i = 0; i < this.methods.length; i++) {
/*      */       try {
/*  439 */         availableMethods[count] = resolveTypesFor(this.methods[i]);
/*  440 */         count++;
/*  441 */       } catch (AbortCompilation abortCompilation) {}
/*      */     } 
/*      */ 
/*      */     
/*  445 */     if (count < availableMethods.length)
/*  446 */       System.arraycopy(availableMethods, 0, availableMethods = new MethodBinding[count], 0, count); 
/*  447 */     return availableMethods;
/*      */   }
/*      */   
/*      */   void cachePartsFrom(IBinaryType binaryType, boolean needFieldsAndMethods) {
/*  451 */     if (!isPrototype()) throw new IllegalStateException(); 
/*  452 */     ReferenceBinding previousRequester = this.environment.requestingType;
/*  453 */     this.environment.requestingType = this;
/*      */ 
/*      */     
/*      */     try {
/*  457 */       this.typeVariables = Binding.NO_TYPE_VARIABLES;
/*  458 */       this.superInterfaces = Binding.NO_SUPERINTERFACES;
/*  459 */       this.permittedSubtypes = Binding.NO_PERMITTEDTYPES;
/*      */ 
/*      */       
/*  462 */       this.memberTypes = Binding.NO_MEMBER_TYPES;
/*  463 */       IBinaryNestedType[] memberTypeStructures = binaryType.getMemberTypes();
/*  464 */       if (memberTypeStructures != null) {
/*  465 */         int size = memberTypeStructures.length;
/*  466 */         if (size > 0) {
/*  467 */           this.memberTypes = new ReferenceBinding[size];
/*  468 */           for (int i = 0; i < size; i++)
/*      */           {
/*  470 */             this.memberTypes[i] = this.environment.getTypeFromConstantPoolName(memberTypeStructures[i].getName(), 0, -1, false, null);
/*      */           }
/*  472 */           this.tagBits |= 0x10000000L;
/*      */         } 
/*      */       } 
/*      */       
/*  476 */       CompilerOptions globalOptions = this.environment.globalOptions;
/*  477 */       long sourceLevel = globalOptions.originalSourceLevel;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  483 */       if (this.environment.globalOptions.isAnnotationBasedNullAnalysisEnabled)
/*      */       {
/*  485 */         scanTypeForNullDefaultAnnotation(binaryType, this.fPackage);
/*      */       }
/*  487 */       ITypeAnnotationWalker walker = getTypeAnnotationWalker(binaryType.getTypeAnnotations(), 0);
/*  488 */       ITypeAnnotationWalker toplevelWalker = binaryType.enrichWithExternalAnnotationsFor(walker, null, this.environment);
/*  489 */       this.externalAnnotationStatus = binaryType.getExternalAnnotationStatus();
/*  490 */       if (this.externalAnnotationStatus.isPotentiallyUnannotatedLib() && this.defaultNullness != 0) {
/*  491 */         this.externalAnnotationStatus = ExternalAnnotationStatus.TYPE_IS_ANNOTATED;
/*      */       }
/*  493 */       char[] typeSignature = binaryType.getGenericSignature();
/*  494 */       this.tagBits |= binaryType.getTagBits();
/*  495 */       if (this.environment.globalOptions.complianceLevel < 3407872L) {
/*  496 */         this.tagBits &= 0xFFDFFFFFFFFFFFFFL;
/*      */       }
/*  498 */       char[][][] missingTypeNames = binaryType.getMissingTypeNames();
/*  499 */       SignatureWrapper wrapper = null;
/*  500 */       if (typeSignature != null) {
/*      */         
/*  502 */         wrapper = new SignatureWrapper(typeSignature);
/*  503 */         if (wrapper.signature[wrapper.start] == '<') {
/*      */           
/*  505 */           wrapper.start++;
/*  506 */           this.typeVariables = createTypeVariables(wrapper, true, missingTypeNames, toplevelWalker, true);
/*  507 */           wrapper.start++;
/*  508 */           this.tagBits |= 0x1000000L;
/*  509 */           this.modifiers |= 0x40000000;
/*      */         } 
/*      */       } 
/*  512 */       TypeVariableBinding[] typeVars = Binding.NO_TYPE_VARIABLES;
/*  513 */       char[] methodDescriptor = binaryType.getEnclosingMethod();
/*  514 */       if (methodDescriptor != null) {
/*  515 */         MethodBinding enclosingMethod = findMethod(methodDescriptor, missingTypeNames);
/*  516 */         if (enclosingMethod != null) {
/*  517 */           typeVars = enclosingMethod.typeVariables;
/*  518 */           this.typeVariables = addMethodTypeVariables(typeVars);
/*      */         } 
/*      */       } 
/*  521 */       if (typeSignature == null) {
/*  522 */         char[] superclassName = binaryType.getSuperclassName();
/*  523 */         if (superclassName != null) {
/*      */           
/*  525 */           this.superclass = this.environment.getTypeFromConstantPoolName(superclassName, 0, -1, false, missingTypeNames, toplevelWalker.toSupertype((short)-1, superclassName));
/*  526 */           this.tagBits |= 0x2000000L;
/*  527 */           if (CharOperation.equals(superclassName, TypeConstants.CharArray_JAVA_LANG_RECORD_SLASH)) {
/*  528 */             this.modifiers |= 0x1000000;
/*      */           }
/*      */         } 
/*      */         
/*  532 */         this.superInterfaces = Binding.NO_SUPERINTERFACES;
/*  533 */         char[][] interfaceNames = binaryType.getInterfaceNames();
/*  534 */         if (interfaceNames != null) {
/*  535 */           int size = interfaceNames.length;
/*  536 */           if (size > 0) {
/*  537 */             this.superInterfaces = new ReferenceBinding[size];
/*  538 */             for (short i = 0; i < size; i = (short)(i + 1))
/*      */             {
/*  540 */               this.superInterfaces[i] = this.environment.getTypeFromConstantPoolName(interfaceNames[i], 0, -1, false, missingTypeNames, toplevelWalker.toSupertype(i, interfaceNames[i])); } 
/*  541 */             this.tagBits |= 0x4000000L;
/*      */           } 
/*      */         } 
/*      */       } else {
/*      */         
/*  546 */         this.superclass = (ReferenceBinding)this.environment.getTypeFromTypeSignature(wrapper, typeVars, this, missingTypeNames, 
/*  547 */             toplevelWalker.toSupertype((short)-1, wrapper.peekFullType()));
/*  548 */         this.tagBits |= 0x2000000L;
/*      */         
/*  550 */         this.superInterfaces = Binding.NO_SUPERINTERFACES;
/*  551 */         if (!wrapper.atEnd()) {
/*      */           
/*  553 */           ArrayList<TypeBinding> types = new ArrayList(2);
/*  554 */           short rank = 0;
/*      */           while (true) {
/*  556 */             rank = (short)(rank + 1); types.add(this.environment.getTypeFromTypeSignature(wrapper, typeVars, this, missingTypeNames, toplevelWalker.toSupertype(rank, wrapper.peekFullType())));
/*  557 */             if (wrapper.atEnd()) {
/*  558 */               this.superInterfaces = new ReferenceBinding[types.size()];
/*  559 */               types.toArray(this.superInterfaces);
/*  560 */               this.tagBits |= 0x4000000L; break;
/*      */             } 
/*      */           } 
/*  563 */         }  this.permittedSubtypes = Binding.NO_PERMITTEDTYPES;
/*  564 */         if (!wrapper.atEnd()) {
/*      */           
/*  566 */           ArrayList<TypeBinding> types = new ArrayList(2);
/*  567 */           short rank = 0;
/*      */           while (true) {
/*  569 */             rank = (short)(rank + 1); types.add(this.environment.getTypeFromTypeSignature(wrapper, typeVars, this, missingTypeNames, toplevelWalker.toSupertype(rank, wrapper.peekFullType())));
/*  570 */             if (wrapper.atEnd()) {
/*  571 */               this.permittedSubtypes = new ReferenceBinding[types.size()];
/*  572 */               types.toArray(this.permittedSubtypes);
/*  573 */               this.extendedTagBits |= 0x2; break;
/*      */             } 
/*      */           } 
/*      */         } 
/*      */       } 
/*  578 */       char[][] permittedSubtypeNames = binaryType.getPermittedSubtypeNames();
/*  579 */       if (this.permittedSubtypes == Binding.NO_PERMITTEDTYPES && permittedSubtypeNames != null) {
/*  580 */         this.modifiers |= 0x10000000;
/*  581 */         int size = permittedSubtypeNames.length;
/*  582 */         if (size > 0) {
/*  583 */           this.permittedSubtypes = new ReferenceBinding[size];
/*  584 */           for (short i = 0; i < size; i = (short)(i + 1))
/*      */           {
/*  586 */             this.permittedSubtypes[i] = this.environment.getTypeFromConstantPoolName(permittedSubtypeNames[i], 0, -1, false, missingTypeNames, toplevelWalker.toSupertype(i, null)); } 
/*      */         } 
/*      */       } 
/*  589 */       boolean canUseNullTypeAnnotations = (this.environment.globalOptions.isAnnotationBasedNullAnalysisEnabled && this.environment.globalOptions.sourceLevel >= 3407872L);
/*  590 */       if (canUseNullTypeAnnotations && this.externalAnnotationStatus.isPotentiallyUnannotatedLib()) {
/*  591 */         if (this.superclass != null && this.superclass.hasNullTypeAnnotations()) {
/*  592 */           this.externalAnnotationStatus = ExternalAnnotationStatus.TYPE_IS_ANNOTATED;
/*      */         } else {
/*  594 */           byte b; int i; ReferenceBinding[] arrayOfReferenceBinding; for (i = (arrayOfReferenceBinding = this.superInterfaces).length, b = 0; b < i; ) { TypeBinding ifc = arrayOfReferenceBinding[b];
/*  595 */             if (ifc.hasNullTypeAnnotations()) {
/*  596 */               this.externalAnnotationStatus = ExternalAnnotationStatus.TYPE_IS_ANNOTATED; break;
/*      */             } 
/*      */             b++; }
/*      */           
/*  600 */           for (i = (arrayOfReferenceBinding = this.permittedSubtypes).length, b = 0; b < i; ) { TypeBinding permsub = arrayOfReferenceBinding[b];
/*  601 */             if (permsub.hasNullTypeAnnotations()) {
/*  602 */               this.externalAnnotationStatus = ExternalAnnotationStatus.TYPE_IS_ANNOTATED;
/*      */               break;
/*      */             } 
/*      */             b++; }
/*      */         
/*      */         } 
/*      */       }
/*  609 */       if (needFieldsAndMethods) {
/*  610 */         IRecordComponent[] iComponents = null;
/*  611 */         if (binaryType.isRecord()) {
/*  612 */           iComponents = binaryType.getRecordComponents();
/*  613 */           if (iComponents != null) {
/*  614 */             createFields((IBinaryField[])iComponents, binaryType, sourceLevel, missingTypeNames, RECORD_INITIALIZATION);
/*      */           }
/*      */         } 
/*  617 */         IBinaryField[] iFields = binaryType.getFields();
/*  618 */         createFields(iFields, binaryType, sourceLevel, missingTypeNames, FIELD_INITIALIZATION);
/*  619 */         IBinaryMethod[] iMethods = createMethods(binaryType.getMethods(), binaryType, sourceLevel, missingTypeNames);
/*  620 */         boolean isViewedAsDeprecated = isViewedAsDeprecated();
/*  621 */         if (isViewedAsDeprecated) {
/*  622 */           int i; int max; for (i = 0, max = this.fields.length; i < max; i++) {
/*  623 */             FieldBinding field = this.fields[i];
/*  624 */             if (!field.isDeprecated()) {
/*  625 */               field.modifiers |= 0x200000;
/*      */             }
/*      */           } 
/*  628 */           for (i = 0, max = this.methods.length; i < max; i++) {
/*  629 */             MethodBinding method = this.methods[i];
/*  630 */             if (!method.isDeprecated()) {
/*  631 */               method.modifiers |= 0x200000;
/*      */             }
/*      */           } 
/*      */         } 
/*  635 */         if (this.environment.globalOptions.isAnnotationBasedNullAnalysisEnabled) {
/*  636 */           if (iComponents != null) {
/*  637 */             for (int i = 0; i < iComponents.length; i++) {
/*      */               
/*  639 */               ITypeAnnotationWalker fieldWalker = ITypeAnnotationWalker.EMPTY_ANNOTATION_WALKER;
/*  640 */               if (sourceLevel < 3407872L)
/*  641 */                 fieldWalker = binaryType.enrichWithExternalAnnotationsFor(walker, iFields[i], this.environment); 
/*  642 */               scanFieldForNullAnnotation((IBinaryField)iComponents[i], this.components[i], isEnum(), fieldWalker);
/*      */             } 
/*      */           }
/*  645 */           if (iFields != null) {
/*  646 */             for (int i = 0; i < iFields.length; i++) {
/*      */               
/*  648 */               ITypeAnnotationWalker fieldWalker = ITypeAnnotationWalker.EMPTY_ANNOTATION_WALKER;
/*  649 */               if (sourceLevel < 3407872L)
/*  650 */                 fieldWalker = binaryType.enrichWithExternalAnnotationsFor(walker, iFields[i], this.environment); 
/*  651 */               scanFieldForNullAnnotation(iFields[i], this.fields[i], isEnum(), fieldWalker);
/*      */             } 
/*      */           }
/*  654 */           if (iMethods != null) {
/*  655 */             for (int i = 0; i < iMethods.length; i++) {
/*      */ 
/*      */ 
/*      */               
/*  659 */               ITypeAnnotationWalker methodWalker = ITypeAnnotationWalker.EMPTY_ANNOTATION_WALKER;
/*  660 */               if (sourceLevel < 3407872L)
/*  661 */                 methodWalker = binaryType.enrichWithExternalAnnotationsFor(methodWalker, iMethods[i], this.environment); 
/*  662 */               scanMethodForNullAnnotation(iMethods[i], this.methods[i], methodWalker, canUseNullTypeAnnotations);
/*      */             } 
/*      */           }
/*      */         } 
/*      */       } 
/*  667 */       IBinaryAnnotation[] declAnnotations = binaryType.getAnnotations();
/*  668 */       if (declAnnotations != null) {
/*  669 */         if (hasValueBasedTypeAnnotation(declAnnotations))
/*  670 */           this.extendedTagBits |= 0x4;  byte b; int i;
/*      */         IBinaryAnnotation[] arrayOfIBinaryAnnotation;
/*  672 */         for (i = (arrayOfIBinaryAnnotation = declAnnotations).length, b = 0; b < i; ) { IBinaryAnnotation annotation = arrayOfIBinaryAnnotation[b];
/*  673 */           char[] typeName = annotation.getTypeName();
/*  674 */           if (isPreviewFeature(typeName)) {
/*  675 */             this.tagBits |= 0x180000000L; break;
/*      */           } 
/*      */           b++; }
/*      */       
/*      */       } 
/*  680 */       if (this.environment.globalOptions.storeAnnotations) {
/*  681 */         setAnnotations(createAnnotations(declAnnotations, this.environment, missingTypeNames), false);
/*  682 */       } else if (sourceLevel >= 3473408L && isDeprecated() && binaryType.getAnnotations() != null) {
/*      */         byte b; int i;
/*      */         IBinaryAnnotation[] arrayOfIBinaryAnnotation;
/*  685 */         for (i = (arrayOfIBinaryAnnotation = declAnnotations).length, b = 0; b < i; ) { IBinaryAnnotation annotation = arrayOfIBinaryAnnotation[b];
/*  686 */           if (annotation.isDeprecatedAnnotation()) {
/*  687 */             AnnotationBinding[] annotationBindings = createAnnotations(new IBinaryAnnotation[] { annotation }, this.environment, missingTypeNames);
/*  688 */             setAnnotations(annotationBindings, true); byte b1; int j; ElementValuePair[] arrayOfElementValuePair;
/*  689 */             for (j = (arrayOfElementValuePair = annotationBindings[0].getElementValuePairs()).length, b1 = 0; b1 < j; ) { ElementValuePair elementValuePair = arrayOfElementValuePair[b1];
/*  690 */               if (CharOperation.equals(elementValuePair.name, TypeConstants.FOR_REMOVAL) && 
/*  691 */                 elementValuePair.value instanceof BooleanConstant && ((BooleanConstant)elementValuePair.value).booleanValue()) {
/*  692 */                 this.tagBits |= 0x4000000000000000L;
/*  693 */                 markImplicitTerminalDeprecation(this);
/*      */               }  b1++; }
/*      */             
/*      */             break;
/*      */           } 
/*      */           b++; }
/*      */       
/*      */       } 
/*  701 */       if (isAnnotationType()) {
/*  702 */         scanTypeForContainerAnnotation(binaryType, missingTypeNames);
/*      */       }
/*      */     } finally {
/*  705 */       if (this.components == null)
/*  706 */         this.components = Binding.NO_COMPONENTS; 
/*  707 */       if (this.fields == null)
/*  708 */         this.fields = Binding.NO_FIELDS; 
/*  709 */       if (this.methods == null) {
/*  710 */         this.methods = Binding.NO_METHODS;
/*      */       }
/*  712 */       this.environment.requestingType = previousRequester;
/*      */     }  } void markImplicitTerminalDeprecation(ReferenceBinding type) { byte b;
/*      */     int i;
/*      */     ReferenceBinding[] arrayOfReferenceBinding;
/*  716 */     for (i = (arrayOfReferenceBinding = type.memberTypes()).length, b = 0; b < i; ) { ReferenceBinding member = arrayOfReferenceBinding[b];
/*  717 */       member.tagBits |= 0x4000000000000000L;
/*  718 */       markImplicitTerminalDeprecation(member); b++; }
/*      */     
/*  720 */     MethodBinding[] methodsOfType = type.unResolvedMethods();
/*  721 */     if (methodsOfType != null) {
/*  722 */       MethodBinding[] arrayOfMethodBinding; for (int j = (arrayOfMethodBinding = methodsOfType).length; i < j; ) { MethodBinding methodBinding = arrayOfMethodBinding[i];
/*  723 */         methodBinding.tagBits |= 0x4000000000000000L; i++; }
/*      */     
/*  725 */     }  FieldBinding[] fieldsOfType = type.unResolvedFields();
/*  726 */     if (fieldsOfType != null) {
/*  727 */       byte b1; int j; FieldBinding[] arrayOfFieldBinding; for (j = (arrayOfFieldBinding = fieldsOfType).length, b1 = 0; b1 < j; ) { FieldBinding fieldBinding = arrayOfFieldBinding[b1];
/*  728 */         fieldBinding.tagBits |= 0x4000000000000000L;
/*      */         b1++; }
/*      */     
/*      */     }  }
/*      */    private ITypeAnnotationWalker getTypeAnnotationWalker(IBinaryTypeAnnotation[] annotations, int nullness) {
/*  733 */     if (!isPrototype()) throw new IllegalStateException(); 
/*  734 */     if (annotations == null || annotations.length == 0 || !this.environment.usesAnnotatedTypeSystem()) {
/*  735 */       if (this.environment.globalOptions.isAnnotationBasedNullAnalysisEnabled) {
/*  736 */         if (nullness == 0)
/*  737 */           nullness = getNullDefault(); 
/*  738 */         if (nullness > 2)
/*  739 */           return (ITypeAnnotationWalker)new NonNullDefaultAwareTypeAnnotationWalker(nullness, this.environment); 
/*      */       } 
/*  741 */       return ITypeAnnotationWalker.EMPTY_ANNOTATION_WALKER;
/*      */     } 
/*  743 */     if (this.environment.globalOptions.isAnnotationBasedNullAnalysisEnabled) {
/*  744 */       if (nullness == 0)
/*  745 */         nullness = getNullDefault(); 
/*  746 */       if (nullness > 2)
/*  747 */         return (ITypeAnnotationWalker)new NonNullDefaultAwareTypeAnnotationWalker(annotations, nullness, this.environment); 
/*      */     } 
/*  749 */     return (ITypeAnnotationWalker)new TypeAnnotationWalker(annotations);
/*      */   }
/*      */   
/*      */   private boolean hasValueBasedTypeAnnotation(IBinaryAnnotation[] declAnnotations) {
/*  753 */     boolean hasValueBasedAnnotation = false;
/*  754 */     if (declAnnotations != null && declAnnotations.length > 0) {
/*  755 */       byte b; int i; IBinaryAnnotation[] arrayOfIBinaryAnnotation; for (i = (arrayOfIBinaryAnnotation = declAnnotations).length, b = 0; b < i; ) { IBinaryAnnotation annot = arrayOfIBinaryAnnotation[b];
/*  756 */         char[] typeName = annot.getTypeName();
/*  757 */         if (typeName != null && typeName.length >= 25 && typeName[0] == 'L') {
/*      */           
/*  759 */           char[][] name = CharOperation.splitOn('/', typeName, 1, typeName.length - 1);
/*      */           try {
/*  761 */             if (CharOperation.equals(name, TypeConstants.JDK_INTERNAL_VALUEBASED)) {
/*  762 */               hasValueBasedAnnotation = true;
/*      */               break;
/*      */             } 
/*  765 */           } catch (Exception exception) {}
/*      */         } 
/*      */         b++; }
/*      */     
/*      */     } 
/*  770 */     return hasValueBasedAnnotation;
/*      */   }
/*      */   
/*      */   private int getNullDefaultFrom(IBinaryAnnotation[] declAnnotations) {
/*  774 */     int result = 0;
/*  775 */     if (declAnnotations != null) {
/*  776 */       byte b; int i; IBinaryAnnotation[] arrayOfIBinaryAnnotation; for (i = (arrayOfIBinaryAnnotation = declAnnotations).length, b = 0; b < i; ) { IBinaryAnnotation annotation = arrayOfIBinaryAnnotation[b];
/*  777 */         char[][] typeName = signature2qualifiedTypeName(annotation.getTypeName());
/*  778 */         if (this.environment.getNullAnnotationBit(typeName) == 128)
/*  779 */           result |= getNonNullByDefaultValue(annotation, this.environment);  b++; }
/*      */     
/*      */     } 
/*  782 */     return result;
/*      */   }
/*      */   private static abstract class VariableBindingInitialization<X extends VariableBinding> {
/*      */     abstract void setEmptyResult(BinaryTypeBinding param1BinaryTypeBinding);
/*      */     abstract X createBinding(BinaryTypeBinding param1BinaryTypeBinding, IBinaryField param1IBinaryField, TypeBinding param1TypeBinding);
/*      */     
/*      */     abstract X[] createResultArray(int param1Int);
/*      */     
/*      */     abstract void set(BinaryTypeBinding param1BinaryTypeBinding, X[] param1ArrayOfX); }
/*      */   
/*  792 */   private static final VariableBindingInitialization<FieldBinding> FIELD_INITIALIZATION = new VariableBindingInitialization<FieldBinding>()
/*      */     {
/*      */       void setEmptyResult(BinaryTypeBinding self)
/*      */       {
/*  796 */         set(self, Binding.NO_FIELDS);
/*      */       }
/*      */ 
/*      */       
/*      */       FieldBinding createBinding(BinaryTypeBinding self, IBinaryField binaryField, TypeBinding type) {
/*  801 */         return new FieldBinding(
/*  802 */             binaryField.getName(), 
/*  803 */             type, 
/*  804 */             binaryField.getModifiers() | 0x2000000, 
/*  805 */             self, 
/*  806 */             binaryField.getConstant());
/*      */       }
/*      */ 
/*      */       
/*      */       FieldBinding[] createResultArray(int size) {
/*  811 */         return new FieldBinding[size];
/*      */       }
/*      */ 
/*      */       
/*      */       void set(BinaryTypeBinding self, FieldBinding[] result) {
/*  816 */         self.fields = result;
/*      */       }
/*      */     };
/*      */   
/*  820 */   private static final VariableBindingInitialization<RecordComponentBinding> RECORD_INITIALIZATION = new VariableBindingInitialization<RecordComponentBinding>()
/*      */     {
/*      */       void setEmptyResult(BinaryTypeBinding self)
/*      */       {
/*  824 */         set(self, Binding.NO_COMPONENTS);
/*      */       }
/*      */ 
/*      */       
/*      */       RecordComponentBinding createBinding(BinaryTypeBinding self, IBinaryField binaryField, TypeBinding type) {
/*  829 */         return new RecordComponentBinding(
/*  830 */             binaryField.getName(), 
/*  831 */             type, 
/*  832 */             binaryField.getModifiers() | 0x2000000, 
/*  833 */             self);
/*      */       }
/*      */ 
/*      */       
/*      */       RecordComponentBinding[] createResultArray(int size) {
/*  838 */         return new RecordComponentBinding[size];
/*      */       }
/*      */ 
/*      */       
/*      */       void set(BinaryTypeBinding self, RecordComponentBinding[] result) {
/*  843 */         self.components = result;
/*      */       }
/*      */     };
/*      */   
/*      */   private void createFields(IBinaryField[] iFields, IBinaryType binaryType, long sourceLevel, char[][][] missingTypeNames, VariableBindingInitialization<VariableBinding> initialization) {
/*  848 */     if (!isPrototype()) throw new IllegalStateException(); 
/*  849 */     boolean save = this.environment.mayTolerateMissingType;
/*  850 */     this.environment.mayTolerateMissingType = true;
/*  851 */     boolean inited = false;
/*      */     try {
/*  853 */       if (iFields != null) {
/*  854 */         int size = iFields.length;
/*  855 */         if (size > 0) {
/*  856 */           VariableBinding[] fields1 = initialization.createResultArray(size);
/*  857 */           boolean use15specifics = (sourceLevel >= 3211264L);
/*  858 */           boolean hasRestrictedAccess = hasRestrictedAccess();
/*  859 */           int firstAnnotatedFieldIndex = -1; int i;
/*  860 */           for (i = 0; i < size; i++) {
/*  861 */             IBinaryField binaryField = iFields[i];
/*  862 */             char[] fieldSignature = use15specifics ? binaryField.getGenericSignature() : null;
/*  863 */             IBinaryAnnotation[] declAnnotations = binaryField.getAnnotations();
/*  864 */             ITypeAnnotationWalker walker = getTypeAnnotationWalker(binaryField.getTypeAnnotations(), getNullDefaultFrom(declAnnotations));
/*  865 */             if (sourceLevel >= 3407872L) {
/*  866 */               walker = binaryType.enrichWithExternalAnnotationsFor(walker, iFields[i], this.environment);
/*      */             }
/*  868 */             walker = walker.toField();
/*  869 */             TypeBinding type = (fieldSignature == null) ? 
/*  870 */               this.environment.getTypeFromSignature(binaryField.getTypeName(), 0, -1, false, this, missingTypeNames, walker) : 
/*  871 */               this.environment.getTypeFromTypeSignature(new SignatureWrapper(fieldSignature), Binding.NO_TYPE_VARIABLES, this, missingTypeNames, walker);
/*  872 */             VariableBinding field = initialization.createBinding(this, binaryField, type);
/*  873 */             if (declAnnotations != null) {
/*  874 */               byte b; int j; IBinaryAnnotation[] arrayOfIBinaryAnnotation; for (j = (arrayOfIBinaryAnnotation = declAnnotations).length, b = 0; b < j; ) { IBinaryAnnotation annotation = arrayOfIBinaryAnnotation[b];
/*  875 */                 char[] typeName = annotation.getTypeName();
/*  876 */                 if (isPreviewFeature(typeName)) {
/*  877 */                   field.tagBits |= 0x180000000L; break;
/*      */                 } 
/*      */                 b++; }
/*      */             
/*      */             } 
/*  882 */             boolean forceStoreAnnotations = (!this.environment.globalOptions.storeAnnotations && 
/*  883 */               this.environment.globalOptions.sourceLevel >= 3473408L && 
/*  884 */               binaryField.getAnnotations() != null && (
/*  885 */               binaryField.getTagBits() & 0x400000000000L) != 0L);
/*  886 */             if (firstAnnotatedFieldIndex < 0 && (
/*  887 */               this.environment.globalOptions.storeAnnotations || forceStoreAnnotations) && 
/*  888 */               binaryField.getAnnotations() != null) {
/*  889 */               firstAnnotatedFieldIndex = i;
/*  890 */               if (forceStoreAnnotations)
/*  891 */                 storedAnnotations(true, true); 
/*      */             } 
/*  893 */             field.id = i;
/*  894 */             if (use15specifics)
/*  895 */               field.tagBits |= binaryField.getTagBits(); 
/*  896 */             if (hasRestrictedAccess)
/*  897 */               field.modifiers |= 0x40000; 
/*  898 */             if (fieldSignature != null)
/*  899 */               field.modifiers |= 0x40000000; 
/*  900 */             fields1[i] = field;
/*      */           } 
/*  902 */           initialization.set(this, fields1);
/*  903 */           inited = true;
/*      */           
/*  905 */           if (firstAnnotatedFieldIndex >= 0) {
/*  906 */             for (i = firstAnnotatedFieldIndex; i < size; i++) {
/*  907 */               IBinaryField binaryField = iFields[i];
/*  908 */               fields1[i].setAnnotations(createAnnotations(binaryField.getAnnotations(), this.environment, missingTypeNames), false);
/*      */             } 
/*      */           }
/*      */         } 
/*      */       } 
/*      */     } finally {
/*  914 */       this.environment.mayTolerateMissingType = save;
/*  915 */       if (!inited) {
/*  916 */         initialization.setEmptyResult(this);
/*      */       }
/*      */     } 
/*      */   }
/*      */   
/*      */   private boolean isPreviewFeature(char[] typeName) {
/*  922 */     int index = CharOperation.lastIndexOf('/', typeName);
/*  923 */     if (index != -1)
/*  924 */       typeName = CharOperation.subarray(typeName, index, typeName.length); 
/*  925 */     index = CharOperation.indexOf(ConstantPool.PREVIEW_FEATURE, typeName, true);
/*  926 */     return (index == 0);
/*      */   }
/*      */   
/*      */   private MethodBinding createMethod(IBinaryMethod method, IBinaryType binaryType, long sourceLevel, char[][][] missingTypeNames) {
/*  930 */     if (!isPrototype()) throw new IllegalStateException(); 
/*  931 */     int methodModifiers = method.getModifiers() | 0x2000000;
/*  932 */     if (sourceLevel < 3211264L)
/*  933 */       methodModifiers &= 0xFFFFFF7F; 
/*  934 */     if (isInterface() && (methodModifiers & 0x400) == 0)
/*      */     {
/*  936 */       if ((methodModifiers & 0x8) == 0 && (
/*  937 */         methodModifiers & 0x2) == 0)
/*      */       {
/*  939 */         methodModifiers |= 0x10000;
/*      */       }
/*      */     }
/*  942 */     ReferenceBinding[] exceptions = Binding.NO_EXCEPTIONS;
/*  943 */     TypeBinding[] parameters = Binding.NO_PARAMETERS;
/*  944 */     TypeVariableBinding[] typeVars = Binding.NO_TYPE_VARIABLES;
/*  945 */     AnnotationBinding[][] paramAnnotations = null;
/*  946 */     TypeBinding returnType = null;
/*      */     
/*  948 */     char[][] argumentNames = method.getArgumentNames();
/*      */     
/*  950 */     IBinaryAnnotation[] declAnnotations = method.getAnnotations();
/*  951 */     boolean use15specifics = (sourceLevel >= 3211264L);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  957 */     ITypeAnnotationWalker walker = getTypeAnnotationWalker(method.getTypeAnnotations(), getNullDefaultFrom(declAnnotations));
/*  958 */     char[] methodSignature = method.getGenericSignature();
/*  959 */     if (methodSignature == null) {
/*  960 */       char[] methodDescriptor = method.getMethodDescriptor();
/*  961 */       if (sourceLevel >= 3407872L) {
/*  962 */         walker = binaryType.enrichWithExternalAnnotationsFor(walker, method, this.environment);
/*      */       }
/*  964 */       int numOfParams = 0;
/*      */       
/*  966 */       int index = 0; char nextChar;
/*  967 */       while ((nextChar = methodDescriptor[++index]) != ')') {
/*  968 */         if (nextChar != '[') {
/*  969 */           numOfParams++;
/*  970 */           if (nextChar == 'L') {
/*  971 */             do {  } while ((nextChar = methodDescriptor[++index]) != ';');
/*      */           }
/*      */         } 
/*      */       } 
/*      */       
/*  976 */       int startIndex = 0;
/*  977 */       if (method.isConstructor()) {
/*  978 */         if (isMemberType() && !isStatic())
/*      */         {
/*  980 */           startIndex++;
/*      */         }
/*  982 */         if (isEnum())
/*      */         {
/*  984 */           startIndex += 2;
/*      */         }
/*      */       } 
/*  987 */       int size = numOfParams - startIndex;
/*  988 */       if (size > 0) {
/*  989 */         parameters = new TypeBinding[size];
/*  990 */         if (this.environment.globalOptions.storeAnnotations)
/*  991 */           paramAnnotations = new AnnotationBinding[size][]; 
/*  992 */         index = 1;
/*  993 */         short visibleIdx = 0;
/*  994 */         int end = 0;
/*  995 */         for (int j = 0; j < numOfParams; ) { do {  }
/*  996 */           while ((nextChar = methodDescriptor[++end]) == '[');
/*  997 */           if (nextChar == 'L') {
/*  998 */             do {  } while ((nextChar = methodDescriptor[++end]) != ';');
/*      */           }
/* 1000 */           if (j >= startIndex) {
/*      */             
/* 1002 */             visibleIdx = (short)(visibleIdx + 1); parameters[j - startIndex] = this.environment.getTypeFromSignature(methodDescriptor, index, end, false, this, missingTypeNames, walker.toMethodParameter(visibleIdx));
/*      */ 
/*      */             
/* 1005 */             if (paramAnnotations != null)
/* 1006 */               paramAnnotations[j - startIndex] = createAnnotations(method.getParameterAnnotations(j - startIndex, this.fileName), this.environment, missingTypeNames); 
/*      */           } 
/* 1008 */           index = end + 1;
/*      */           j++; }
/*      */       
/*      */       } 
/* 1012 */       char[][] exceptionTypes = method.getExceptionTypeNames();
/* 1013 */       if (exceptionTypes != null) {
/* 1014 */         size = exceptionTypes.length;
/* 1015 */         if (size > 0) {
/* 1016 */           exceptions = new ReferenceBinding[size];
/* 1017 */           for (int j = 0; j < size; j++) {
/* 1018 */             exceptions[j] = this.environment.getTypeFromConstantPoolName(exceptionTypes[j], 0, -1, false, missingTypeNames, walker.toThrows(j));
/*      */           }
/*      */         } 
/*      */       } 
/* 1022 */       if (!method.isConstructor()) {
/* 1023 */         returnType = this.environment.getTypeFromSignature(methodDescriptor, index + 1, -1, false, this, missingTypeNames, walker.toMethodReturn());
/*      */       }
/* 1025 */       int argumentNamesLength = (argumentNames == null) ? 0 : argumentNames.length;
/* 1026 */       if (startIndex > 0 && argumentNamesLength > 0)
/*      */       {
/* 1028 */         if (startIndex >= argumentNamesLength) {
/* 1029 */           argumentNames = Binding.NO_PARAMETER_NAMES;
/*      */         } else {
/* 1031 */           char[][] slicedArgumentNames = new char[argumentNamesLength - startIndex][];
/* 1032 */           System.arraycopy(argumentNames, startIndex, slicedArgumentNames, 0, argumentNamesLength - startIndex);
/* 1033 */           argumentNames = slicedArgumentNames;
/*      */         } 
/*      */       }
/*      */     } else {
/*      */       
/* 1038 */       if (sourceLevel >= 3407872L) {
/* 1039 */         walker = binaryType.enrichWithExternalAnnotationsFor(walker, method, this.environment);
/*      */       }
/* 1041 */       if (walker == ITypeAnnotationWalker.EMPTY_ANNOTATION_WALKER && this.environment.globalOptions.isAnnotationBasedNullAnalysisEnabled) {
/* 1042 */         walker = provideSyntheticEEA(method, argumentNames, walker);
/*      */       }
/* 1044 */       methodModifiers |= 0x40000000;
/*      */       
/* 1046 */       SignatureWrapper wrapper = new SignatureWrapper(methodSignature, use15specifics);
/* 1047 */       if (wrapper.signature[wrapper.start] == '<') {
/*      */ 
/*      */         
/* 1050 */         wrapper.start++;
/* 1051 */         typeVars = createTypeVariables(wrapper, false, missingTypeNames, walker, false);
/* 1052 */         wrapper.start++;
/*      */       } 
/*      */       
/* 1055 */       if (wrapper.signature[wrapper.start] == '(') {
/* 1056 */         wrapper.start++;
/* 1057 */         if (wrapper.signature[wrapper.start] == ')') {
/* 1058 */           wrapper.start++;
/*      */         } else {
/* 1060 */           ArrayList<TypeBinding> types = new ArrayList(2);
/* 1061 */           short rank = 0;
/* 1062 */           while (wrapper.signature[wrapper.start] != ')') {
/* 1063 */             IBinaryAnnotation[] binaryParameterAnnotations = method.getParameterAnnotations(rank, this.fileName);
/* 1064 */             ITypeAnnotationWalker updatedWalker = NonNullDefaultAwareTypeAnnotationWalker.updateWalkerForParamNonNullDefault(walker, getNullDefaultFrom(binaryParameterAnnotations), this.environment);
/* 1065 */             types.add(this.environment.getTypeFromTypeSignature(wrapper, typeVars, this, missingTypeNames, updatedWalker.toMethodParameter(rank)));
/* 1066 */             rank = (short)(rank + 1);
/*      */           } 
/* 1068 */           wrapper.start++;
/* 1069 */           int numParam = types.size();
/* 1070 */           parameters = new TypeBinding[numParam];
/* 1071 */           types.toArray(parameters);
/* 1072 */           if (this.environment.globalOptions.storeAnnotations) {
/* 1073 */             paramAnnotations = new AnnotationBinding[numParam][];
/* 1074 */             for (int j = 0; j < numParam; j++) {
/* 1075 */               paramAnnotations[j] = createAnnotations(method.getParameterAnnotations(j, this.fileName), this.environment, missingTypeNames);
/*      */             }
/*      */           } 
/*      */         } 
/*      */       } 
/*      */       
/* 1081 */       returnType = this.environment.getTypeFromTypeSignature(wrapper, typeVars, this, missingTypeNames, walker.toMethodReturn());
/*      */       
/* 1083 */       if (!wrapper.atEnd() && wrapper.signature[wrapper.start] == '^') {
/*      */         
/* 1085 */         ArrayList<TypeBinding> types = new ArrayList(2);
/* 1086 */         int excRank = 0;
/*      */         do {
/* 1088 */           wrapper.start++;
/* 1089 */           types.add(this.environment.getTypeFromTypeSignature(wrapper, typeVars, this, missingTypeNames, 
/* 1090 */                 walker.toThrows(excRank++)));
/* 1091 */         } while (!wrapper.atEnd() && wrapper.signature[wrapper.start] == '^');
/* 1092 */         exceptions = new ReferenceBinding[types.size()];
/* 1093 */         types.toArray(exceptions);
/*      */       } else {
/* 1095 */         char[][] exceptionTypes = method.getExceptionTypeNames();
/* 1096 */         if (exceptionTypes != null) {
/* 1097 */           int size = exceptionTypes.length;
/* 1098 */           if (size > 0) {
/* 1099 */             exceptions = new ReferenceBinding[size];
/* 1100 */             for (int j = 0; j < size; j++) {
/* 1101 */               exceptions[j] = this.environment.getTypeFromConstantPoolName(exceptionTypes[j], 0, -1, false, missingTypeNames, walker.toThrows(j));
/*      */             }
/*      */           } 
/*      */         } 
/*      */       } 
/*      */     } 
/* 1107 */     MethodBinding result = method.isConstructor() ? 
/* 1108 */       new MethodBinding(methodModifiers, parameters, exceptions, this) : 
/* 1109 */       new MethodBinding(methodModifiers, method.getSelector(), returnType, parameters, exceptions, this);
/*      */     
/* 1111 */     if (declAnnotations != null) {
/* 1112 */       byte b; int j; IBinaryAnnotation[] arrayOfIBinaryAnnotation; for (j = (arrayOfIBinaryAnnotation = declAnnotations).length, b = 0; b < j; ) { IBinaryAnnotation annotation = arrayOfIBinaryAnnotation[b];
/* 1113 */         char[] typeName = annotation.getTypeName();
/* 1114 */         if (isPreviewFeature(typeName)) {
/* 1115 */           result.tagBits |= 0x180000000L; break;
/*      */         } 
/*      */         b++; }
/*      */     
/*      */     } 
/* 1120 */     IBinaryAnnotation[] receiverAnnotations = walker.toReceiver().getAnnotationsAtCursor(this.id, false);
/* 1121 */     if (receiverAnnotations != null && receiverAnnotations.length > 0) {
/* 1122 */       result.receiver = this.environment.createAnnotatedType(this, createAnnotations(receiverAnnotations, this.environment, missingTypeNames));
/*      */     }
/*      */     
/* 1125 */     boolean forceStoreAnnotations = (!this.environment.globalOptions.storeAnnotations && 
/* 1126 */       this.environment.globalOptions.sourceLevel >= 3473408L && 
/* 1127 */       method instanceof org.eclipse.jdt.internal.compiler.classfmt.MethodInfoWithAnnotations && (
/* 1128 */       method.getTagBits() & 0x400000000000L) != 0L);
/* 1129 */     if (this.environment.globalOptions.storeAnnotations || forceStoreAnnotations) {
/* 1130 */       if (forceStoreAnnotations)
/* 1131 */         storedAnnotations(true, true); 
/* 1132 */       IBinaryAnnotation[] annotations = method.getAnnotations();
/* 1133 */       if (method.isConstructor()) {
/* 1134 */         IBinaryAnnotation[] tAnnotations = walker.toMethodReturn().getAnnotationsAtCursor(this.id, false);
/* 1135 */         result.setTypeAnnotations(createAnnotations(tAnnotations, this.environment, missingTypeNames));
/*      */       } 
/* 1137 */       result.setAnnotations(
/* 1138 */           createAnnotations(annotations, this.environment, missingTypeNames), 
/* 1139 */           paramAnnotations, 
/* 1140 */           isAnnotationType() ? convertMemberValue(method.getDefaultValue(), this.environment, missingTypeNames, true) : null, 
/* 1141 */           this.environment);
/*      */     } 
/*      */     
/* 1144 */     if (argumentNames != null) result.parameterNames = argumentNames;
/*      */     
/* 1146 */     if (use15specifics)
/* 1147 */       result.tagBits |= method.getTagBits(); 
/* 1148 */     result.typeVariables = typeVars;
/*      */     
/* 1150 */     for (int i = 0, length = typeVars.length; i < length; i++) {
/* 1151 */       this.environment.typeSystem.fixTypeVariableDeclaringElement(typeVars[i], result);
/*      */     }
/* 1153 */     return result;
/*      */   }
/*      */   
/*      */   protected ITypeAnnotationWalker provideSyntheticEEA(IBinaryMethod method, char[][] argumentNames, ITypeAnnotationWalker walker) {
/* 1157 */     switch (this.id) {
/*      */       case 74:
/* 1159 */         if (this.environment.globalOptions.complianceLevel >= 3407872L && 
/* 1160 */           CharOperation.equals(method.getSelector(), TypeConstants.REQUIRE_NON_NULL) && 
/* 1161 */           argumentNames != null && argumentNames.length > 0) {
/*      */           
/* 1163 */           String eeaSource = (argumentNames.length == 1) ? 
/* 1164 */             "<TT;>(T0T;)T1T;" : 
/* 1165 */             "<TT;>(T0T;L0java/lang/String;)T1T;";
/* 1166 */           walker = ExternalAnnotationProvider.synthesizeForMethod(eeaSource.toCharArray(), this.environment);
/*      */         } 
/*      */         break;
/*      */     } 
/* 1170 */     return walker;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private IBinaryMethod[] createMethods(IBinaryMethod[] iMethods, IBinaryType binaryType, long sourceLevel, char[][][] missingTypeNames) {
/* 1179 */     if (!isPrototype()) throw new IllegalStateException(); 
/* 1180 */     boolean save = this.environment.mayTolerateMissingType;
/* 1181 */     this.environment.mayTolerateMissingType = true;
/*      */     try {
/* 1183 */       int total = 0, initialTotal = 0, iClinit = -1;
/* 1184 */       int[] toSkip = null;
/* 1185 */       if (iMethods != null) {
/* 1186 */         total = initialTotal = iMethods.length;
/* 1187 */         boolean keepBridgeMethods = (sourceLevel < 3211264L);
/* 1188 */         for (int j = total; --j >= 0; ) {
/* 1189 */           IBinaryMethod method = iMethods[j];
/* 1190 */           if ((method.getModifiers() & 0x1000) != 0) {
/* 1191 */             if (keepBridgeMethods && (method.getModifiers() & 0x40) != 0) {
/*      */               continue;
/*      */             }
/* 1194 */             if (toSkip == null) toSkip = new int[iMethods.length]; 
/* 1195 */             toSkip[j] = -1;
/* 1196 */             total--; continue;
/* 1197 */           }  if (iClinit == -1) {
/* 1198 */             char[] methodName = method.getSelector();
/* 1199 */             if (methodName.length == 8 && methodName[0] == '<') {
/*      */               
/* 1201 */               iClinit = j;
/* 1202 */               total--;
/*      */             } 
/*      */           } 
/*      */         } 
/*      */       } 
/* 1207 */       if (total == 0) {
/* 1208 */         this.methods = Binding.NO_METHODS;
/* 1209 */         return NO_BINARY_METHODS;
/*      */       } 
/*      */       
/* 1212 */       boolean hasRestrictedAccess = hasRestrictedAccess();
/* 1213 */       MethodBinding[] methods1 = new MethodBinding[total];
/* 1214 */       if (total == initialTotal) {
/* 1215 */         for (int j = 0; j < initialTotal; j++) {
/* 1216 */           MethodBinding method = createMethod(iMethods[j], binaryType, sourceLevel, missingTypeNames);
/* 1217 */           if (hasRestrictedAccess)
/* 1218 */             method.modifiers |= 0x40000; 
/* 1219 */           methods1[j] = method;
/*      */         } 
/* 1221 */         this.methods = methods1;
/* 1222 */         return iMethods;
/*      */       } 
/* 1224 */       IBinaryMethod[] mappedBinaryMethods = new IBinaryMethod[total];
/* 1225 */       for (int i = 0, index = 0; i < initialTotal; i++) {
/* 1226 */         if (iClinit != i && (toSkip == null || toSkip[i] != -1)) {
/* 1227 */           MethodBinding method = createMethod(iMethods[i], binaryType, sourceLevel, missingTypeNames);
/* 1228 */           if (hasRestrictedAccess)
/* 1229 */             method.modifiers |= 0x40000; 
/* 1230 */           mappedBinaryMethods[index] = iMethods[i];
/* 1231 */           methods1[index++] = method;
/*      */         } 
/*      */       } 
/* 1234 */       this.methods = methods1;
/* 1235 */       return mappedBinaryMethods;
/*      */     } finally {
/*      */       
/* 1238 */       this.environment.mayTolerateMissingType = save;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private TypeVariableBinding[] createTypeVariables(SignatureWrapper wrapper, boolean assignVariables, char[][][] missingTypeNames, ITypeAnnotationWalker walker, boolean isClassTypeParameter) {
/* 1245 */     if (!isPrototype()) throw new IllegalStateException();
/*      */     
/* 1247 */     char[] typeSignature = wrapper.signature;
/* 1248 */     int depth = 0, length = typeSignature.length;
/* 1249 */     int rank = 0;
/* 1250 */     ArrayList<TypeVariableBinding> variables = new ArrayList(1);
/* 1251 */     depth = 0;
/* 1252 */     boolean pendingVariable = true;
/*      */     
/* 1254 */     for (int i = 1; i < length; i++) {
/* 1255 */       switch (typeSignature[i]) {
/*      */         case '<':
/* 1257 */           depth++;
/*      */           break;
/*      */         case '>':
/* 1260 */           if (--depth < 0)
/*      */             break; 
/*      */           break;
/*      */         case ';':
/* 1264 */           if (depth == 0 && i + 1 < length && typeSignature[i + 1] != ':')
/* 1265 */             pendingVariable = true; 
/*      */           break;
/*      */         default:
/* 1268 */           if (pendingVariable) {
/* 1269 */             pendingVariable = false;
/* 1270 */             int colon = CharOperation.indexOf(':', typeSignature, i);
/* 1271 */             char[] variableName = CharOperation.subarray(typeSignature, i, colon);
/* 1272 */             TypeVariableBinding typeVariable = new TypeVariableBinding(variableName, this, rank, this.environment);
/* 1273 */             AnnotationBinding[] annotations = createAnnotations(walker.toTypeParameter(isClassTypeParameter, rank++).getAnnotationsAtCursor(0, false), 
/* 1274 */                 this.environment, missingTypeNames);
/* 1275 */             if (annotations != null && annotations != Binding.NO_ANNOTATIONS)
/* 1276 */               typeVariable.setTypeAnnotations(annotations, this.environment.globalOptions.isAnnotationBasedNullAnalysisEnabled); 
/* 1277 */             variables.add(typeVariable);
/*      */           } 
/*      */           break;
/*      */       } 
/*      */     
/*      */     } 
/*      */     TypeVariableBinding[] result;
/* 1284 */     variables.toArray(result = new TypeVariableBinding[rank]);
/*      */ 
/*      */     
/* 1287 */     if (assignVariables)
/* 1288 */       this.typeVariables = result; 
/* 1289 */     for (int j = 0; j < rank; j++) {
/* 1290 */       initializeTypeVariable(result[j], result, wrapper, missingTypeNames, walker.toTypeParameterBounds(isClassTypeParameter, j));
/* 1291 */       if (this.externalAnnotationStatus.isPotentiallyUnannotatedLib() && result[j].hasNullTypeAnnotations())
/* 1292 */         this.externalAnnotationStatus = ExternalAnnotationStatus.TYPE_IS_ANNOTATED; 
/*      */     } 
/* 1294 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ReferenceBinding enclosingType() {
/* 1303 */     if ((this.tagBits & 0x8000000L) == 0L) {
/* 1304 */       return this.enclosingType;
/*      */     }
/*      */     
/* 1307 */     this.enclosingType = (ReferenceBinding)resolveType(this.enclosingType, this.environment, false);
/* 1308 */     this.tagBits &= 0xFFFFFFFFF7FFFFFFL;
/* 1309 */     return this.enclosingType;
/*      */   }
/*      */   
/*      */   public RecordComponentBinding[] components() {
/* 1313 */     if (!isPrototype()) {
/* 1314 */       return this.components = this.prototype.components;
/*      */     }
/* 1316 */     if ((this.extendedTagBits & 0x1) != 0) {
/* 1317 */       return this.components;
/*      */     }
/*      */     
/* 1320 */     for (int i = this.components.length; --i >= 0;) {
/* 1321 */       resolveTypeFor(this.components[i]);
/*      */     }
/* 1323 */     this.extendedTagBits |= 0x1;
/* 1324 */     return this.components;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public FieldBinding[] fields() {
/* 1330 */     if (!isPrototype()) {
/* 1331 */       return this.fields = this.prototype.fields();
/*      */     }
/*      */     
/* 1334 */     if ((this.tagBits & 0x2000L) != 0L) {
/* 1335 */       return this.fields;
/*      */     }
/*      */     
/* 1338 */     if ((this.tagBits & 0x1000L) == 0L) {
/* 1339 */       int length = this.fields.length;
/* 1340 */       if (length > 1)
/* 1341 */         ReferenceBinding.sortFields(this.fields, 0, length); 
/* 1342 */       this.tagBits |= 0x1000L;
/*      */     } 
/* 1344 */     for (int i = this.fields.length; --i >= 0;)
/* 1345 */       resolveTypeFor(this.fields[i]); 
/* 1346 */     this.tagBits |= 0x2000L;
/* 1347 */     return this.fields;
/*      */   }
/*      */   
/*      */   private MethodBinding findMethod(char[] methodDescriptor, char[][][] missingTypeNames) {
/* 1351 */     if (!isPrototype()) throw new IllegalStateException(); 
/* 1352 */     int index = -1; do {  }
/* 1353 */     while (methodDescriptor[++index] != '(');
/*      */ 
/*      */     
/* 1356 */     char[] selector = new char[index];
/* 1357 */     System.arraycopy(methodDescriptor, 0, selector, 0, index);
/* 1358 */     TypeBinding[] parameters = Binding.NO_PARAMETERS;
/* 1359 */     int numOfParams = 0;
/*      */     
/* 1361 */     int paramStart = index; char nextChar;
/* 1362 */     while ((nextChar = methodDescriptor[++index]) != ')') {
/* 1363 */       if (nextChar != '[') {
/* 1364 */         numOfParams++;
/* 1365 */         if (nextChar == 'L')
/* 1366 */           do {  } while ((nextChar = methodDescriptor[++index]) != ';'); 
/*      */       } 
/*      */     } 
/* 1369 */     if (numOfParams > 0) {
/* 1370 */       parameters = new TypeBinding[numOfParams];
/* 1371 */       index = paramStart + 1;
/* 1372 */       int end = paramStart;
/* 1373 */       for (int j = 0; j < numOfParams; ) { do {  }
/* 1374 */         while ((nextChar = methodDescriptor[++end]) == '[');
/* 1375 */         if (nextChar == 'L') {
/* 1376 */           do {  } while ((nextChar = methodDescriptor[++end]) != ';');
/*      */         }
/*      */         
/* 1379 */         TypeBinding param = this.environment.getTypeFromSignature(methodDescriptor, index, end, false, this, missingTypeNames, ITypeAnnotationWalker.EMPTY_ANNOTATION_WALKER);
/* 1380 */         if (param instanceof UnresolvedReferenceBinding) {
/* 1381 */           param = resolveType(param, this.environment, true);
/*      */         }
/* 1383 */         parameters[j] = param;
/* 1384 */         index = end + 1;
/*      */         j++; }
/*      */     
/*      */     } 
/* 1388 */     int parameterLength = parameters.length;
/* 1389 */     MethodBinding[] methods2 = this.enclosingType.getMethods(selector, parameterLength);
/*      */     
/* 1391 */     for (int i = 0, max = methods2.length; i < max; i++) {
/* 1392 */       MethodBinding currentMethod = methods2[i];
/* 1393 */       TypeBinding[] parameters2 = currentMethod.parameters;
/* 1394 */       int currentMethodParameterLength = parameters2.length;
/* 1395 */       if (parameterLength == currentMethodParameterLength) {
/* 1396 */         int j = 0; while (true) { if (j >= currentMethodParameterLength)
/*      */           {
/*      */ 
/*      */ 
/*      */             
/* 1401 */             return currentMethod; }  if (TypeBinding.notEquals(parameters[j], parameters2[j]) && TypeBinding.notEquals(parameters[j].erasure(), parameters2[j].erasure()))
/*      */             break;  j++; } 
/*      */       } 
/* 1404 */     }  return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public char[] genericTypeSignature() {
/* 1412 */     if (!isPrototype())
/* 1413 */       return this.prototype.computeGenericTypeSignature(this.typeVariables); 
/* 1414 */     return computeGenericTypeSignature(this.typeVariables);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MethodBinding getExactConstructor(TypeBinding[] argumentTypes) {
/* 1421 */     if (!isPrototype()) {
/* 1422 */       return this.prototype.getExactConstructor(argumentTypes);
/*      */     }
/*      */     
/* 1425 */     if ((this.tagBits & 0x4000L) == 0L) {
/* 1426 */       int length = this.methods.length;
/* 1427 */       if (length > 1)
/* 1428 */         ReferenceBinding.sortMethods(this.methods, 0, length); 
/* 1429 */       this.tagBits |= 0x4000L;
/*      */     } 
/* 1431 */     int argCount = argumentTypes.length;
/*      */     long range;
/* 1433 */     if ((range = ReferenceBinding.binarySearch(TypeConstants.INIT, this.methods)) >= 0L)
/* 1434 */       for (int imethod = (int)range, end = (int)(range >> 32L); imethod <= end; imethod++) {
/* 1435 */         MethodBinding method = this.methods[imethod];
/* 1436 */         if (method.parameters.length == argCount) {
/* 1437 */           resolveTypesFor(method);
/* 1438 */           TypeBinding[] toMatch = method.parameters;
/* 1439 */           int iarg = 0; while (true) { if (iarg >= argCount)
/*      */             {
/*      */               
/* 1442 */               return method; }  if (TypeBinding.notEquals(toMatch[iarg], argumentTypes[iarg]))
/*      */               break;  iarg++; }
/*      */         
/*      */         } 
/* 1446 */       }   return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MethodBinding getExactMethod(char[] selector, TypeBinding[] argumentTypes, CompilationUnitScope refScope) {
/* 1455 */     if (!isPrototype()) {
/* 1456 */       return this.prototype.getExactMethod(selector, argumentTypes, refScope);
/*      */     }
/*      */     
/* 1459 */     if ((this.tagBits & 0x4000L) == 0L) {
/* 1460 */       int length = this.methods.length;
/* 1461 */       if (length > 1)
/* 1462 */         ReferenceBinding.sortMethods(this.methods, 0, length); 
/* 1463 */       this.tagBits |= 0x4000L;
/*      */     } 
/*      */     
/* 1466 */     int argCount = argumentTypes.length;
/* 1467 */     boolean foundNothing = true;
/*      */     
/*      */     long range;
/* 1470 */     if ((range = ReferenceBinding.binarySearch(selector, this.methods)) >= 0L)
/* 1471 */       for (int imethod = (int)range, end = (int)(range >> 32L); imethod <= end; imethod++) {
/* 1472 */         MethodBinding method = this.methods[imethod];
/* 1473 */         foundNothing = false;
/* 1474 */         if (method.parameters.length == argCount) {
/* 1475 */           resolveTypesFor(method);
/* 1476 */           TypeBinding[] toMatch = method.parameters;
/* 1477 */           int iarg = 0; while (true) { if (iarg >= argCount)
/*      */             {
/*      */               
/* 1480 */               return method; }  if (TypeBinding.notEquals(toMatch[iarg], argumentTypes[iarg]))
/*      */               break;  iarg++; }
/*      */         
/*      */         } 
/* 1484 */       }   if (foundNothing) {
/* 1485 */       if (isInterface()) {
/* 1486 */         if ((superInterfaces()).length == 1) {
/* 1487 */           if (refScope != null)
/* 1488 */             refScope.recordTypeReference(this.superInterfaces[0]); 
/* 1489 */           return this.superInterfaces[0].getExactMethod(selector, argumentTypes, refScope);
/*      */         } 
/* 1491 */       } else if (superclass() != null) {
/* 1492 */         if (refScope != null)
/* 1493 */           refScope.recordTypeReference(this.superclass); 
/* 1494 */         return this.superclass.getExactMethod(selector, argumentTypes, refScope);
/*      */       } 
/*      */     }
/*      */     
/* 1498 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public FieldBinding getField(char[] fieldName, boolean needResolve) {
/* 1504 */     if (!isPrototype()) {
/* 1505 */       return this.prototype.getField(fieldName, needResolve);
/*      */     }
/*      */     
/* 1508 */     if ((this.tagBits & 0x1000L) == 0L) {
/* 1509 */       int length = this.fields.length;
/* 1510 */       if (length > 1)
/* 1511 */         ReferenceBinding.sortFields(this.fields, 0, length); 
/* 1512 */       this.tagBits |= 0x1000L;
/*      */     } 
/* 1514 */     FieldBinding field = ReferenceBinding.binarySearch(fieldName, this.fields);
/* 1515 */     return (needResolve && field != null) ? resolveTypeFor(field) : field;
/*      */   }
/*      */ 
/*      */   
/*      */   public RecordComponentBinding getRecordComponent(char[] name) {
/* 1520 */     if (this.components != null) {
/* 1521 */       byte b; int i; RecordComponentBinding[] arrayOfRecordComponentBinding; for (i = (arrayOfRecordComponentBinding = this.components).length, b = 0; b < i; ) { RecordComponentBinding rcb = arrayOfRecordComponentBinding[b];
/* 1522 */         if (CharOperation.equals(name, rcb.name))
/* 1523 */           return rcb;  b++; }
/*      */     
/*      */     } 
/* 1526 */     return null;
/*      */   }
/*      */ 
/*      */   
/*      */   public RecordComponentBinding getComponent(char[] componentName, boolean needResolve) {
/* 1531 */     if (!isPrototype()) {
/* 1532 */       return this.prototype.getComponent(componentName, needResolve);
/*      */     }
/* 1534 */     RecordComponentBinding component = getRecordComponent(componentName);
/* 1535 */     return (needResolve && component != null) ? resolveTypeFor(component) : component;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean isFieldInitializationFinished() {
/* 1543 */     return !(this.fields == null && this.components == null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ReferenceBinding getMemberType(char[] typeName) {
/* 1552 */     if (!isPrototype()) {
/* 1553 */       ReferenceBinding memberType = this.prototype.getMemberType(typeName);
/* 1554 */       return (memberType == null) ? null : this.environment.createMemberType(memberType, this);
/*      */     } 
/*      */     
/* 1557 */     ReferenceBinding[] members = maybeSortedMemberTypes();
/*      */     
/* 1559 */     if (!this.memberTypesSorted) {
/* 1560 */       for (int i = members.length; --i >= 0; ) {
/* 1561 */         ReferenceBinding memberType = members[i];
/* 1562 */         if (memberType instanceof UnresolvedReferenceBinding) {
/* 1563 */           char[] name = memberType.sourceName;
/* 1564 */           int prefixLength = (this.compoundName[this.compoundName.length - 1]).length + 1;
/* 1565 */           if (name.length == prefixLength + typeName.length && 
/* 1566 */             CharOperation.fragmentEquals(typeName, name, prefixLength, true))
/* 1567 */           { members[i] = (ReferenceBinding)resolveType(memberType, this.environment, false); return (ReferenceBinding)resolveType(memberType, this.environment, false); }  continue;
/* 1568 */         }  if (CharOperation.equals(typeName, memberType.sourceName)) {
/* 1569 */           return memberType;
/*      */         }
/*      */       } 
/* 1572 */       return null;
/*      */     } 
/* 1574 */     int memberTypeIndex = ReferenceBinding.binarySearch(typeName, members);
/* 1575 */     if (memberTypeIndex >= 0) {
/* 1576 */       return members[memberTypeIndex];
/*      */     }
/* 1578 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MethodBinding[] getMethods(char[] selector) {
/* 1585 */     if (!isPrototype()) {
/* 1586 */       return this.prototype.getMethods(selector);
/*      */     }
/* 1588 */     if ((this.tagBits & 0x8000L) != 0L) {
/*      */       long l;
/* 1590 */       if ((l = ReferenceBinding.binarySearch(selector, this.methods)) >= 0L) {
/* 1591 */         int start = (int)l, end = (int)(l >> 32L);
/* 1592 */         int length = end - start + 1;
/* 1593 */         if ((this.tagBits & 0x8000L) != 0L) {
/*      */           MethodBinding[] result;
/*      */           
/* 1596 */           System.arraycopy(this.methods, start, result = new MethodBinding[length], 0, length);
/* 1597 */           return result;
/*      */         } 
/*      */       } 
/* 1600 */       return Binding.NO_METHODS;
/*      */     } 
/*      */     
/* 1603 */     if ((this.tagBits & 0x4000L) == 0L) {
/* 1604 */       int length = this.methods.length;
/* 1605 */       if (length > 1)
/* 1606 */         ReferenceBinding.sortMethods(this.methods, 0, length); 
/* 1607 */       this.tagBits |= 0x4000L;
/*      */     } 
/*      */     long range;
/* 1610 */     if ((range = ReferenceBinding.binarySearch(selector, this.methods)) >= 0L) {
/* 1611 */       int start = (int)range, end = (int)(range >> 32L);
/* 1612 */       int length = end - start + 1;
/* 1613 */       MethodBinding[] result = new MethodBinding[length];
/*      */       
/* 1615 */       for (int i = start, index = 0; i <= end; i++, index++)
/* 1616 */         result[index] = resolveTypesFor(this.methods[i]); 
/* 1617 */       return result;
/*      */     } 
/* 1619 */     return Binding.NO_METHODS;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MethodBinding[] getMethods(char[] selector, int suggestedParameterLength) {
/* 1626 */     if (!isPrototype()) {
/* 1627 */       return this.prototype.getMethods(selector, suggestedParameterLength);
/*      */     }
/* 1629 */     if ((this.tagBits & 0x8000L) != 0L) {
/* 1630 */       return getMethods(selector);
/*      */     }
/* 1632 */     if ((this.tagBits & 0x4000L) == 0L) {
/* 1633 */       int length = this.methods.length;
/* 1634 */       if (length > 1)
/* 1635 */         ReferenceBinding.sortMethods(this.methods, 0, length); 
/* 1636 */       this.tagBits |= 0x4000L;
/*      */     } 
/*      */     long range;
/* 1639 */     if ((range = ReferenceBinding.binarySearch(selector, this.methods)) >= 0L) {
/* 1640 */       int start = (int)range, end = (int)(range >> 32L);
/* 1641 */       int length = end - start + 1;
/* 1642 */       int count = 0;
/* 1643 */       for (int i = start; i <= end; i++) {
/* 1644 */         if (this.methods[i].doesParameterLengthMatch(suggestedParameterLength))
/* 1645 */           count++; 
/*      */       } 
/* 1647 */       if (count == 0) {
/* 1648 */         MethodBinding[] arrayOfMethodBinding = new MethodBinding[length];
/*      */         
/* 1650 */         for (int k = start, m = 0; k <= end; k++)
/* 1651 */           arrayOfMethodBinding[m++] = resolveTypesFor(this.methods[k]); 
/* 1652 */         return arrayOfMethodBinding;
/*      */       } 
/* 1654 */       MethodBinding[] result = new MethodBinding[count];
/*      */       
/* 1656 */       for (int j = start, index = 0; j <= end; j++) {
/* 1657 */         if (this.methods[j].doesParameterLengthMatch(suggestedParameterLength))
/* 1658 */           result[index++] = resolveTypesFor(this.methods[j]); 
/*      */       } 
/* 1660 */       return result;
/*      */     } 
/*      */     
/* 1663 */     return Binding.NO_METHODS;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean hasMemberTypes() {
/* 1668 */     if (!isPrototype())
/* 1669 */       return this.prototype.hasMemberTypes(); 
/* 1670 */     return (this.memberTypes.length > 0);
/*      */   }
/*      */ 
/*      */   
/*      */   public TypeVariableBinding getTypeVariable(char[] variableName) {
/* 1675 */     if (!isPrototype()) {
/* 1676 */       return this.prototype.getTypeVariable(variableName);
/*      */     }
/* 1678 */     TypeVariableBinding variable = super.getTypeVariable(variableName);
/* 1679 */     variable.resolve();
/* 1680 */     return variable;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean hasTypeBit(int bit) {
/* 1685 */     if (!isPrototype()) {
/* 1686 */       return this.prototype.hasTypeBit(bit);
/*      */     }
/*      */     
/* 1689 */     boolean wasToleratingMissingTypeProcessingAnnotations = this.environment.mayTolerateMissingType;
/* 1690 */     this.environment.mayTolerateMissingType = true;
/*      */     try {
/* 1692 */       superclass();
/* 1693 */       superInterfaces();
/*      */     } finally {
/* 1695 */       this.environment.mayTolerateMissingType = wasToleratingMissingTypeProcessingAnnotations;
/*      */     } 
/* 1697 */     return ((this.typeBits & bit) != 0);
/*      */   } private void initializeTypeVariable(TypeVariableBinding variable, TypeVariableBinding[] existingVariables, SignatureWrapper wrapper, char[][][] missingTypeNames, ITypeAnnotationWalker walker) {
/*      */     ReferenceBinding type;
/* 1700 */     if (!isPrototype()) throw new IllegalStateException();
/*      */ 
/*      */ 
/*      */     
/* 1704 */     int colon = CharOperation.indexOf(':', wrapper.signature, wrapper.start);
/* 1705 */     wrapper.start = colon + 1;
/* 1706 */     ReferenceBinding firstBound = null;
/* 1707 */     short rank = 0;
/* 1708 */     if (wrapper.signature[wrapper.start] == ':') {
/* 1709 */       type = this.environment.getResolvedJavaBaseType(TypeConstants.JAVA_LANG_OBJECT, null);
/* 1710 */       rank = (short)(rank + 1);
/*      */     } else {
/* 1712 */       rank = (short)(rank + 1); TypeBinding typeFromTypeSignature = this.environment.getTypeFromTypeSignature(wrapper, existingVariables, this, missingTypeNames, walker.toTypeBound(rank));
/* 1713 */       if (typeFromTypeSignature instanceof ReferenceBinding) {
/* 1714 */         type = (ReferenceBinding)typeFromTypeSignature;
/*      */       } else {
/*      */         
/* 1717 */         type = this.environment.getResolvedJavaBaseType(TypeConstants.JAVA_LANG_OBJECT, null);
/*      */       } 
/* 1719 */       firstBound = type;
/*      */     } 
/*      */ 
/*      */     
/* 1723 */     variable.modifiers |= 0x2000000;
/* 1724 */     variable.setSuperClass(type);
/*      */     
/* 1726 */     ReferenceBinding[] bounds = null;
/* 1727 */     if (wrapper.signature[wrapper.start] == ':') {
/* 1728 */       ArrayList<TypeBinding> types = new ArrayList(2);
/*      */       while (true) {
/* 1730 */         wrapper.start++;
/* 1731 */         rank = (short)(rank + 1); types.add(this.environment.getTypeFromTypeSignature(wrapper, existingVariables, this, missingTypeNames, walker.toTypeBound(rank)));
/* 1732 */         if (wrapper.signature[wrapper.start] != ':') {
/* 1733 */           bounds = new ReferenceBinding[types.size()];
/* 1734 */           types.toArray(bounds); break;
/*      */         } 
/*      */       } 
/* 1737 */     }  variable.setSuperInterfaces((bounds == null) ? Binding.NO_SUPERINTERFACES : bounds);
/* 1738 */     if (firstBound == null) {
/* 1739 */       firstBound = (variable.superInterfaces.length == 0) ? null : variable.superInterfaces[0];
/*      */     }
/* 1741 */     variable.setFirstBound(firstBound);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isEquivalentTo(TypeBinding otherType) {
/* 1750 */     if (TypeBinding.equalsEquals(this, otherType)) return true; 
/* 1751 */     if (otherType == null) return false; 
/* 1752 */     switch (otherType.kind()) {
/*      */       case 516:
/*      */       case 8196:
/* 1755 */         return ((WildcardBinding)otherType).boundCheck(this);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 260:
/*      */       case 1028:
/* 1765 */         return TypeBinding.equalsEquals(otherType.erasure(), this);
/*      */     } 
/* 1767 */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isGenericType() {
/* 1772 */     if (!isPrototype()) {
/* 1773 */       return this.prototype.isGenericType();
/*      */     }
/* 1775 */     return (this.typeVariables != Binding.NO_TYPE_VARIABLES);
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isHierarchyConnected() {
/* 1780 */     if (!isPrototype()) {
/* 1781 */       return this.prototype.isHierarchyConnected();
/*      */     }
/* 1783 */     return ((this.tagBits & 0x6000000L) == 0L);
/*      */   }
/*      */   
/*      */   public boolean isRepeatableAnnotationType() {
/* 1787 */     if (!isPrototype()) throw new IllegalStateException(); 
/* 1788 */     return (this.containerAnnotationType != null);
/*      */   }
/*      */ 
/*      */   
/*      */   public int kind() {
/* 1793 */     if (!isPrototype()) {
/* 1794 */       return this.prototype.kind();
/*      */     }
/* 1796 */     if (this.typeVariables != Binding.NO_TYPE_VARIABLES)
/* 1797 */       return 2052; 
/* 1798 */     return 4;
/*      */   }
/*      */ 
/*      */   
/*      */   public ReferenceBinding[] memberTypes() {
/* 1803 */     if (!isPrototype()) {
/* 1804 */       if ((this.tagBits & 0x10000000L) == 0L) {
/* 1805 */         return this.memberTypes;
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1811 */       ReferenceBinding[] members = this.prototype.memberTypes();
/* 1812 */       if (members != null) {
/* 1813 */         this.memberTypes = new ReferenceBinding[members.length];
/* 1814 */         for (int j = 0; j < members.length; j++)
/* 1815 */           this.memberTypes[j] = this.environment.createMemberType(members[j], this); 
/*      */       } 
/* 1817 */       this.tagBits &= 0xFFFFFFFFEFFFFFFFL;
/* 1818 */       this.memberTypesSorted = true;
/* 1819 */       return this.memberTypes;
/*      */     } 
/*      */     
/* 1822 */     if ((this.tagBits & 0x10000000L) == 0L) {
/* 1823 */       return maybeSortedMemberTypes();
/*      */     }
/* 1825 */     for (int i = this.memberTypes.length; --i >= 0;)
/* 1826 */       this.memberTypes[i] = (ReferenceBinding)resolveType(this.memberTypes[i], this.environment, false); 
/* 1827 */     this.tagBits &= 0xFFFFFFFFEFFFFFFFL;
/* 1828 */     return maybeSortedMemberTypes();
/*      */   }
/*      */ 
/*      */   
/*      */   private ReferenceBinding[] maybeSortedMemberTypes() {
/* 1833 */     if ((this.tagBits & 0x10000000L) != 0L) {
/* 1834 */       return this.memberTypes;
/*      */     }
/* 1836 */     if (!this.memberTypesSorted) {
/*      */       
/* 1838 */       int length = this.memberTypes.length;
/* 1839 */       if (length > 1)
/* 1840 */         sortMemberTypes(this.memberTypes, 0, length); 
/* 1841 */       this.memberTypesSorted = true;
/*      */     } 
/* 1843 */     return this.memberTypes;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MethodBinding[] methods() {
/* 1850 */     if (!isPrototype()) {
/* 1851 */       return this.methods = this.prototype.methods();
/*      */     }
/*      */     
/* 1854 */     if ((this.tagBits & 0x8000L) != 0L) {
/* 1855 */       return this.methods;
/*      */     }
/*      */     
/* 1858 */     if ((this.tagBits & 0x4000L) == 0L) {
/* 1859 */       int length = this.methods.length;
/* 1860 */       if (length > 1)
/* 1861 */         ReferenceBinding.sortMethods(this.methods, 0, length); 
/* 1862 */       this.tagBits |= 0x4000L;
/*      */     } 
/* 1864 */     for (int i = this.methods.length; --i >= 0;)
/* 1865 */       resolveTypesFor(this.methods[i]); 
/* 1866 */     this.tagBits |= 0x8000L;
/* 1867 */     return this.methods;
/*      */   }
/*      */   
/*      */   public void setHierarchyCheckDone() {
/* 1871 */     this.tagBits |= 0x300L;
/*      */   }
/*      */ 
/*      */   
/*      */   public TypeBinding prototype() {
/* 1876 */     return this.prototype;
/*      */   }
/*      */   
/*      */   private boolean isPrototype() {
/* 1880 */     return (this == this.prototype);
/*      */   }
/*      */   
/*      */   public boolean isRecord() {
/* 1884 */     return ((this.modifiers & 0x1000000) != 0);
/*      */   }
/*      */ 
/*      */   
/*      */   public MethodBinding getRecordComponentAccessor(char[] name) {
/* 1889 */     if (isRecord()) {
/* 1890 */       byte b; int i; MethodBinding[] arrayOfMethodBinding; for (i = (arrayOfMethodBinding = getMethods(name)).length, b = 0; b < i; ) { MethodBinding m = arrayOfMethodBinding[b];
/* 1891 */         if (CharOperation.equals(m.selector, name))
/* 1892 */           return m; 
/*      */         b++; }
/*      */     
/*      */     } 
/* 1896 */     return null;
/*      */   }
/*      */ 
/*      */   
/*      */   public ReferenceBinding containerAnnotationType() {
/* 1901 */     if (!isPrototype()) throw new IllegalStateException(); 
/* 1902 */     if (this.containerAnnotationType instanceof UnresolvedReferenceBinding) {
/* 1903 */       this.containerAnnotationType = (ReferenceBinding)resolveType(this.containerAnnotationType, this.environment, false);
/*      */     }
/* 1905 */     return this.containerAnnotationType;
/*      */   }
/*      */   private RecordComponentBinding resolveTypeFor(RecordComponentBinding component) {
/* 1908 */     if (!isPrototype()) {
/* 1909 */       return this.prototype.resolveTypeFor(component);
/*      */     }
/* 1911 */     if ((component.modifiers & 0x2000000) == 0) {
/* 1912 */       return component;
/*      */     }
/* 1914 */     TypeBinding resolvedType = resolveType(component.type, this.environment, true);
/* 1915 */     component.type = resolvedType;
/* 1916 */     if ((resolvedType.tagBits & 0x80L) != 0L) {
/* 1917 */       component.tagBits |= 0x80L;
/*      */     }
/* 1919 */     component.modifiers &= 0xFDFFFFFF;
/* 1920 */     return component;
/*      */   }
/*      */   
/*      */   private FieldBinding resolveTypeFor(FieldBinding field) {
/* 1924 */     if (!isPrototype()) {
/* 1925 */       return this.prototype.resolveTypeFor(field);
/*      */     }
/* 1927 */     if ((field.modifiers & 0x2000000) == 0) {
/* 1928 */       return field;
/*      */     }
/* 1930 */     TypeBinding resolvedType = resolveType(field.type, this.environment, true);
/* 1931 */     field.type = resolvedType;
/* 1932 */     if ((resolvedType.tagBits & 0x80L) != 0L) {
/* 1933 */       field.tagBits |= 0x80L;
/*      */     }
/* 1935 */     field.modifiers &= 0xFDFFFFFF;
/* 1936 */     return field;
/*      */   }
/*      */   
/*      */   MethodBinding resolveTypesFor(MethodBinding method) {
/* 1940 */     if (!isPrototype()) {
/* 1941 */       return this.prototype.resolveTypesFor(method);
/*      */     }
/* 1943 */     if ((method.modifiers & 0x2000000) == 0) {
/* 1944 */       return method;
/*      */     }
/* 1946 */     if (!method.isConstructor()) {
/* 1947 */       TypeBinding resolvedType = resolveType(method.returnType, this.environment, true);
/* 1948 */       method.returnType = resolvedType;
/* 1949 */       if ((resolvedType.tagBits & 0x80L) != 0L)
/* 1950 */         method.tagBits |= 0x80L; 
/*      */     } 
/*      */     int i;
/* 1953 */     for (i = method.parameters.length; --i >= 0; ) {
/* 1954 */       TypeBinding resolvedType = resolveType(method.parameters[i], this.environment, true);
/* 1955 */       method.parameters[i] = resolvedType;
/* 1956 */       if ((resolvedType.tagBits & 0x80L) != 0L) {
/* 1957 */         method.tagBits |= 0x80L;
/*      */       }
/*      */     } 
/* 1960 */     for (i = method.thrownExceptions.length; --i >= 0; ) {
/* 1961 */       ReferenceBinding resolvedType = (ReferenceBinding)resolveType(method.thrownExceptions[i], this.environment, true);
/* 1962 */       method.thrownExceptions[i] = resolvedType;
/* 1963 */       if ((resolvedType.tagBits & 0x80L) != 0L) {
/* 1964 */         method.tagBits |= 0x80L;
/*      */       }
/*      */     } 
/* 1967 */     for (i = method.typeVariables.length; --i >= 0;) {
/* 1968 */       method.typeVariables[i].resolve();
/*      */     }
/* 1970 */     method.modifiers &= 0xFDFFFFFF;
/* 1971 */     return method;
/*      */   }
/*      */ 
/*      */   
/*      */   AnnotationBinding[] retrieveAnnotations(Binding binding) {
/* 1976 */     if (!isPrototype()) {
/* 1977 */       return this.prototype.retrieveAnnotations(binding);
/*      */     }
/* 1979 */     return AnnotationBinding.addStandardAnnotations(super.retrieveAnnotations(binding), binding.getAnnotationTagBits(), this.environment);
/*      */   }
/*      */ 
/*      */   
/*      */   public void setContainerAnnotationType(ReferenceBinding value) {
/* 1984 */     if (!isPrototype()) throw new IllegalStateException(); 
/* 1985 */     this.containerAnnotationType = value;
/*      */   }
/*      */ 
/*      */   
/*      */   public void tagAsHavingDefectiveContainerType() {
/* 1990 */     if (!isPrototype()) throw new IllegalStateException(); 
/* 1991 */     if (this.containerAnnotationType != null && this.containerAnnotationType.isValidBinding()) {
/* 1992 */       this.containerAnnotationType = new ProblemReferenceBinding(this.containerAnnotationType.compoundName, this.containerAnnotationType, 22);
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   SimpleLookupTable storedAnnotations(boolean forceInitialize, boolean forceStore) {
/* 1998 */     if (!isPrototype()) {
/* 1999 */       return this.prototype.storedAnnotations(forceInitialize, forceStore);
/*      */     }
/* 2001 */     if (forceInitialize && this.storedAnnotations == null) {
/* 2002 */       if (!this.environment.globalOptions.storeAnnotations && !forceStore)
/* 2003 */         return null; 
/* 2004 */       this.storedAnnotations = new SimpleLookupTable(3);
/*      */     } 
/* 2006 */     return this.storedAnnotations;
/*      */   }
/*      */ 
/*      */   
/*      */   private void scanFieldForNullAnnotation(IBinaryField field, VariableBinding fieldBinding, boolean isEnum, ITypeAnnotationWalker externalAnnotationWalker) {
/* 2011 */     if (!isPrototype()) throw new IllegalStateException();
/*      */     
/* 2013 */     if (isEnum && (field.getModifiers() & 0x4000) != 0) {
/* 2014 */       fieldBinding.tagBits |= 0x100000000000000L;
/*      */       
/*      */       return;
/*      */     } 
/* 2018 */     if (!CharOperation.equals(this.fPackage.compoundName, TypeConstants.JAVA_LANG_ANNOTATION) && 
/* 2019 */       this.environment.usesNullTypeAnnotations()) {
/* 2020 */       TypeBinding fieldType = fieldBinding.type;
/* 2021 */       if (fieldType != null && 
/* 2022 */         !fieldType.isBaseType() && (
/* 2023 */         fieldType.tagBits & 0x180000000000000L) == 0L && 
/* 2024 */         fieldType.acceptsNonNullDefault()) {
/* 2025 */         int nullDefaultFromField = getNullDefaultFrom(field.getAnnotations());
/* 2026 */         if ((nullDefaultFromField == 0) ? 
/* 2027 */           hasNonNullDefaultForType(fieldType, 32, -1) : ((
/* 2028 */           nullDefaultFromField & 0x20) != 0)) {
/* 2029 */           fieldBinding.type = this.environment.createAnnotatedType(fieldType, 
/* 2030 */               new AnnotationBinding[] { this.environment.getNonNullAnnotation() });
/*      */         }
/*      */       } 
/*      */ 
/*      */       
/*      */       return;
/*      */     } 
/*      */     
/* 2038 */     if (fieldBinding.type == null || fieldBinding.type.isBaseType()) {
/*      */       return;
/*      */     }
/* 2041 */     boolean explicitNullness = false;
/* 2042 */     IBinaryAnnotation[] annotations = (externalAnnotationWalker != ITypeAnnotationWalker.EMPTY_ANNOTATION_WALKER) ? 
/* 2043 */       externalAnnotationWalker.getAnnotationsAtCursor(fieldBinding.type.id, false) : 
/* 2044 */       field.getAnnotations();
/* 2045 */     if (annotations != null)
/* 2046 */       for (int i = 0; i < annotations.length; i++) {
/* 2047 */         char[] annotationTypeName = annotations[i].getTypeName();
/* 2048 */         if (annotationTypeName[0] == 'L') {
/*      */           
/* 2050 */           int typeBit = this.environment.getNullAnnotationBit(signature2qualifiedTypeName(annotationTypeName));
/* 2051 */           if (typeBit == 32) {
/* 2052 */             fieldBinding.tagBits |= 0x100000000000000L;
/* 2053 */             explicitNullness = true;
/*      */             break;
/*      */           } 
/* 2056 */           if (typeBit == 64) {
/* 2057 */             fieldBinding.tagBits |= 0x80000000000000L;
/* 2058 */             explicitNullness = true;
/*      */             break;
/*      */           } 
/*      */         } 
/*      */       }  
/* 2063 */     if (explicitNullness && this.externalAnnotationStatus.isPotentiallyUnannotatedLib())
/* 2064 */       this.externalAnnotationStatus = ExternalAnnotationStatus.TYPE_IS_ANNOTATED; 
/* 2065 */     if (!explicitNullness) {
/* 2066 */       int nullDefaultFromField = getNullDefaultFrom(field.getAnnotations());
/* 2067 */       if ((nullDefaultFromField == 0) ? hasNonNullDefaultForType(fieldBinding.type, 32, -1) : ((
/* 2068 */         nullDefaultFromField & 0x20) != 0)) {
/* 2069 */         fieldBinding.tagBits |= 0x100000000000000L;
/*      */       }
/*      */     } 
/*      */   }
/*      */   
/*      */   private void scanMethodForNullAnnotation(IBinaryMethod method, MethodBinding methodBinding, ITypeAnnotationWalker externalAnnotationWalker, boolean useNullTypeAnnotations) {
/* 2075 */     if (!isPrototype()) throw new IllegalStateException(); 
/* 2076 */     if (isEnum()) {
/* 2077 */       int purpose = 0;
/* 2078 */       if (CharOperation.equals(TypeConstants.VALUEOF, method.getSelector()) && 
/* 2079 */         methodBinding.parameters.length == 1 && 
/* 2080 */         (methodBinding.parameters[0]).id == 11) {
/*      */         
/* 2082 */         purpose = 10;
/* 2083 */       } else if (CharOperation.equals(TypeConstants.VALUES, method.getSelector()) && 
/* 2084 */         methodBinding.parameters == Binding.NO_PARAMETERS) {
/* 2085 */         purpose = 9;
/*      */       } 
/* 2087 */       if (purpose != 0) {
/* 2088 */         boolean needToDefer = (this.environment.globalOptions.useNullTypeAnnotations == null);
/* 2089 */         if (needToDefer) {
/* 2090 */           this.environment.deferredEnumMethods.add(methodBinding);
/*      */         } else {
/* 2092 */           SyntheticMethodBinding.markNonNull(methodBinding, purpose, this.environment);
/*      */         } 
/*      */         
/*      */         return;
/*      */       } 
/*      */     } 
/* 2098 */     ITypeAnnotationWalker returnWalker = externalAnnotationWalker.toMethodReturn();
/* 2099 */     IBinaryAnnotation[] annotations = (returnWalker != ITypeAnnotationWalker.EMPTY_ANNOTATION_WALKER) ? 
/* 2100 */       returnWalker.getAnnotationsAtCursor(methodBinding.returnType.id, false) : 
/* 2101 */       method.getAnnotations();
/* 2102 */     if (annotations != null) {
/* 2103 */       int methodDefaultNullness = 0;
/* 2104 */       for (int i = 0; i < annotations.length; i++) {
/* 2105 */         char[] annotationTypeName = annotations[i].getTypeName();
/* 2106 */         if (annotationTypeName[0] == 'L') {
/*      */           
/* 2108 */           int typeBit = this.environment.getNullAnnotationBit(signature2qualifiedTypeName(annotationTypeName));
/* 2109 */           if (typeBit == 128) {
/* 2110 */             methodDefaultNullness |= getNonNullByDefaultValue(annotations[i], this.environment);
/* 2111 */           } else if (typeBit == 32) {
/* 2112 */             methodBinding.tagBits |= 0x100000000000000L;
/* 2113 */             if (this.environment.usesNullTypeAnnotations() && 
/* 2114 */               methodBinding.returnType != null && !methodBinding.returnType.hasNullTypeAnnotations()) {
/* 2115 */               methodBinding.returnType = this.environment.createAnnotatedType(methodBinding.returnType, 
/* 2116 */                   new AnnotationBinding[] { this.environment.getNonNullAnnotation() });
/*      */             }
/*      */           }
/* 2119 */           else if (typeBit == 64) {
/* 2120 */             methodBinding.tagBits |= 0x80000000000000L;
/* 2121 */             if (this.environment.usesNullTypeAnnotations() && 
/* 2122 */               methodBinding.returnType != null && !methodBinding.returnType.hasNullTypeAnnotations()) {
/* 2123 */               methodBinding.returnType = this.environment.createAnnotatedType(methodBinding.returnType, 
/* 2124 */                   new AnnotationBinding[] { this.environment.getNullableAnnotation() });
/*      */             }
/*      */           } 
/*      */         } 
/*      */       } 
/* 2129 */       methodBinding.defaultNullness = methodDefaultNullness;
/*      */     } 
/*      */ 
/*      */     
/* 2133 */     TypeBinding[] parameters = methodBinding.parameters;
/* 2134 */     int numVisibleParams = parameters.length;
/* 2135 */     int numParamAnnotations = (externalAnnotationWalker instanceof ExternalAnnotationProvider.IMethodAnnotationWalker) ? (
/* 2136 */       (ExternalAnnotationProvider.IMethodAnnotationWalker)externalAnnotationWalker).getParameterCount() : 
/* 2137 */       method.getAnnotatedParametersCount();
/* 2138 */     if (numParamAnnotations > 0) {
/* 2139 */       for (int j = 0; j < numVisibleParams; j++) {
/* 2140 */         if (numParamAnnotations > 0) {
/* 2141 */           int startIndex = numParamAnnotations - numVisibleParams;
/* 2142 */           ITypeAnnotationWalker parameterWalker = externalAnnotationWalker.toMethodParameter((short)(j + startIndex));
/* 2143 */           IBinaryAnnotation[] paramAnnotations = (parameterWalker != ITypeAnnotationWalker.EMPTY_ANNOTATION_WALKER) ? 
/* 2144 */             parameterWalker.getAnnotationsAtCursor((parameters[j]).id, false) : 
/* 2145 */             method.getParameterAnnotations(j + startIndex, this.fileName);
/* 2146 */           if (paramAnnotations != null) {
/* 2147 */             for (int i = 0; i < paramAnnotations.length; i++) {
/* 2148 */               char[] annotationTypeName = paramAnnotations[i].getTypeName();
/* 2149 */               if (annotationTypeName[0] == 'L') {
/*      */                 
/* 2151 */                 int typeBit = this.environment.getNullAnnotationBit(signature2qualifiedTypeName(annotationTypeName));
/* 2152 */                 if (typeBit == 32) {
/* 2153 */                   if (methodBinding.parameterNonNullness == null)
/* 2154 */                     methodBinding.parameterNonNullness = new Boolean[numVisibleParams]; 
/* 2155 */                   methodBinding.parameterNonNullness[j] = Boolean.TRUE;
/* 2156 */                   if (this.environment.usesNullTypeAnnotations() && 
/* 2157 */                     methodBinding.parameters[j] != null && 
/* 2158 */                     !methodBinding.parameters[j].hasNullTypeAnnotations()) {
/* 2159 */                     methodBinding.parameters[j] = this.environment.createAnnotatedType(
/* 2160 */                         methodBinding.parameters[j], 
/* 2161 */                         new AnnotationBinding[] { this.environment.getNonNullAnnotation() });
/*      */                   }
/*      */                   break;
/*      */                 } 
/* 2165 */                 if (typeBit == 64) {
/* 2166 */                   if (methodBinding.parameterNonNullness == null)
/* 2167 */                     methodBinding.parameterNonNullness = new Boolean[numVisibleParams]; 
/* 2168 */                   methodBinding.parameterNonNullness[j] = Boolean.FALSE;
/* 2169 */                   if (this.environment.usesNullTypeAnnotations() && 
/* 2170 */                     methodBinding.parameters[j] != null && 
/* 2171 */                     !methodBinding.parameters[j].hasNullTypeAnnotations()) {
/* 2172 */                     methodBinding.parameters[j] = this.environment.createAnnotatedType(
/* 2173 */                         methodBinding.parameters[j], 
/* 2174 */                         new AnnotationBinding[] { this.environment.getNullableAnnotation() });
/*      */                   }
/*      */                   break;
/*      */                 } 
/*      */               } 
/*      */             } 
/*      */           }
/*      */         } 
/*      */       } 
/*      */     }
/* 2184 */     if (useNullTypeAnnotations && this.externalAnnotationStatus.isPotentiallyUnannotatedLib())
/* 2185 */       if (methodBinding.returnType.hasNullTypeAnnotations() || (
/* 2186 */         methodBinding.tagBits & 0x180000000000000L) != 0L || 
/* 2187 */         methodBinding.parameterNonNullness != null) {
/* 2188 */         this.externalAnnotationStatus = ExternalAnnotationStatus.TYPE_IS_ANNOTATED;
/*      */       } else {
/* 2190 */         byte b; int i; TypeBinding[] arrayOfTypeBinding; for (i = (arrayOfTypeBinding = parameters).length, b = 0; b < i; ) { TypeBinding parameter = arrayOfTypeBinding[b];
/* 2191 */           if (parameter.hasNullTypeAnnotations()) {
/* 2192 */             this.externalAnnotationStatus = ExternalAnnotationStatus.TYPE_IS_ANNOTATED;
/*      */             break;
/*      */           } 
/*      */           b++; }
/*      */       
/*      */       }  
/*      */   }
/*      */   
/*      */   private void scanTypeForNullDefaultAnnotation(IBinaryType binaryType, PackageBinding packageBinding) {
/* 2201 */     if (!isPrototype()) throw new IllegalStateException(); 
/* 2202 */     char[][] nonNullByDefaultAnnotationName = this.environment.getNonNullByDefaultAnnotationName();
/* 2203 */     if (nonNullByDefaultAnnotationName == null) {
/*      */       return;
/*      */     }
/* 2206 */     if (CharOperation.equals(CharOperation.splitOn('/', binaryType.getName()), nonNullByDefaultAnnotationName))
/*      */       return;  byte b; int i; String[] arrayOfString;
/* 2208 */     for (i = (arrayOfString = this.environment.globalOptions.nonNullByDefaultAnnotationSecondaryNames).length, b = 0; b < i; ) { String name = arrayOfString[b];
/* 2209 */       if (CharOperation.toString(this.compoundName).equals(name))
/*      */         return;  b++; }
/*      */     
/* 2212 */     IBinaryAnnotation[] annotations = binaryType.getAnnotations();
/* 2213 */     boolean isPackageInfo = CharOperation.equals(sourceName(), TypeConstants.PACKAGE_INFO_NAME);
/* 2214 */     if (annotations != null) {
/* 2215 */       int nullness = 0;
/* 2216 */       int length = annotations.length;
/* 2217 */       for (int j = 0; j < length; j++) {
/* 2218 */         char[] annotationTypeName = annotations[j].getTypeName();
/* 2219 */         if (annotationTypeName[0] == 'L') {
/*      */           
/* 2221 */           int typeBit = this.environment.getNullAnnotationBit(signature2qualifiedTypeName(annotationTypeName));
/* 2222 */           if (typeBit == 128)
/*      */           {
/* 2224 */             nullness |= getNonNullByDefaultValue(annotations[j], this.environment); } 
/*      */         } 
/*      */       } 
/* 2227 */       this.defaultNullness = nullness;
/* 2228 */       if (nullness != 0) {
/* 2229 */         if (isPackageInfo)
/* 2230 */           packageBinding.setDefaultNullness(nullness); 
/*      */         return;
/*      */       } 
/*      */     } 
/* 2234 */     if (isPackageInfo) {
/*      */       
/* 2236 */       packageBinding.setDefaultNullness(0);
/*      */       return;
/*      */     } 
/* 2239 */     ReferenceBinding enclosingTypeBinding = this.enclosingType;
/* 2240 */     if (enclosingTypeBinding != null && 
/* 2241 */       setNullDefault(enclosingTypeBinding.getNullDefault())) {
/*      */       return;
/*      */     }
/*      */ 
/*      */     
/* 2246 */     if (packageBinding.getDefaultNullness() == 0 && !isPackageInfo && (
/* 2247 */       this.typeBits & 0xE0) == 0) {
/*      */ 
/*      */       
/* 2250 */       ReferenceBinding packageInfo = packageBinding.getType(TypeConstants.PACKAGE_INFO_NAME, packageBinding.enclosingModule);
/* 2251 */       if (packageInfo == null) {
/* 2252 */         packageBinding.setDefaultNullness(0);
/*      */       }
/*      */     } 
/*      */     
/* 2256 */     setNullDefault(packageBinding.getDefaultNullness());
/*      */   }
/*      */   
/*      */   boolean setNullDefault(int newNullDefault) {
/* 2260 */     this.defaultNullness = newNullDefault;
/* 2261 */     if (newNullDefault != 0) {
/* 2262 */       return true;
/*      */     }
/* 2264 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static int getNonNullByDefaultValue(IBinaryAnnotation annotation, LookupEnvironment environment) {
/* 2271 */     char[] annotationTypeName = annotation.getTypeName();
/* 2272 */     char[][] typeName = signature2qualifiedTypeName(annotationTypeName);
/* 2273 */     IBinaryElementValuePair[] elementValuePairs = annotation.getElementValuePairs();
/* 2274 */     if (elementValuePairs == null || elementValuePairs.length == 0) {
/*      */       
/* 2276 */       ReferenceBinding annotationType = environment.getType(typeName, environment.UnNamedModule);
/* 2277 */       if (annotationType == null) return 0; 
/* 2278 */       if (annotationType.isUnresolvedType())
/* 2279 */         annotationType = ((UnresolvedReferenceBinding)annotationType).resolve(environment, false); 
/* 2280 */       int nullness = evaluateTypeQualifierDefault(annotationType);
/* 2281 */       if (nullness != 0)
/* 2282 */         return nullness; 
/* 2283 */       MethodBinding[] annotationMethods = annotationType.methods();
/* 2284 */       if (annotationMethods != null && annotationMethods.length == 1) {
/* 2285 */         Object value = annotationMethods[0].getDefaultValue();
/* 2286 */         return Annotation.nullLocationBitsFromAnnotationValue(value);
/*      */       } 
/* 2288 */       return 56;
/* 2289 */     }  if (elementValuePairs.length > 0) {
/*      */       
/* 2291 */       int nullness = 0;
/* 2292 */       for (int i = 0; i < elementValuePairs.length; i++)
/* 2293 */         nullness |= Annotation.nullLocationBitsFromAnnotationValue(elementValuePairs[i].getValue()); 
/* 2294 */       return nullness;
/*      */     } 
/*      */     
/* 2297 */     return 2;
/*      */   } public static int evaluateTypeQualifierDefault(ReferenceBinding annotationType) {
/*      */     byte b;
/*      */     int i;
/*      */     AnnotationBinding[] arrayOfAnnotationBinding;
/* 2302 */     for (i = (arrayOfAnnotationBinding = annotationType.getAnnotations()).length, b = 0; b < i; ) { AnnotationBinding annotationOnAnnotation = arrayOfAnnotationBinding[b];
/* 2303 */       if (CharOperation.equals((annotationOnAnnotation.getAnnotationType()).compoundName[annotationOnAnnotation.type.compoundName.length - 1], TYPE_QUALIFIER_DEFAULT)) {
/* 2304 */         ElementValuePair[] pairs2 = annotationOnAnnotation.getElementValuePairs();
/* 2305 */         if (pairs2 != null) {
/* 2306 */           byte b1; int j; ElementValuePair[] arrayOfElementValuePair; for (j = (arrayOfElementValuePair = pairs2).length, b1 = 0; b1 < j; ) { ElementValuePair elementValuePair = arrayOfElementValuePair[b1];
/* 2307 */             char[] name = elementValuePair.getName();
/* 2308 */             if (CharOperation.equals(name, TypeConstants.VALUE)) {
/* 2309 */               int nullness = 0;
/* 2310 */               Object value = elementValuePair.getValue();
/* 2311 */               if (value instanceof Object[])
/* 2312 */               { Object[] values = (Object[])value; byte b2; int k; Object[] arrayOfObject1;
/* 2313 */                 for (k = (arrayOfObject1 = values).length, b2 = 0; b2 < k; ) { Object value1 = arrayOfObject1[b2];
/* 2314 */                   nullness |= Annotation.nullLocationBitsFromElementTypeAnnotationValue(value1); b2++; }
/*      */                  }
/* 2316 */               else { nullness |= Annotation.nullLocationBitsFromElementTypeAnnotationValue(value); }
/*      */               
/* 2318 */               return nullness;
/*      */             }  b1++; }
/*      */         
/*      */         } 
/*      */       }  b++; }
/*      */     
/* 2324 */     return 0;
/*      */   }
/*      */   
/*      */   static char[][] signature2qualifiedTypeName(char[] typeSignature) {
/* 2328 */     return CharOperation.splitOn('/', typeSignature, 1, typeSignature.length - 1);
/*      */   }
/*      */ 
/*      */   
/*      */   int getNullDefault() {
/* 2333 */     return this.defaultNullness;
/*      */   }
/*      */   
/*      */   private void scanTypeForContainerAnnotation(IBinaryType binaryType, char[][][] missingTypeNames) {
/* 2337 */     if (!isPrototype()) throw new IllegalStateException(); 
/* 2338 */     IBinaryAnnotation[] annotations = binaryType.getAnnotations();
/* 2339 */     if (annotations != null) {
/* 2340 */       int length = annotations.length;
/* 2341 */       for (int i = 0; i < length; i++) {
/* 2342 */         char[] annotationTypeName = annotations[i].getTypeName();
/* 2343 */         if (CharOperation.equals(annotationTypeName, ConstantPool.JAVA_LANG_ANNOTATION_REPEATABLE)) {
/* 2344 */           IBinaryElementValuePair[] elementValuePairs = annotations[i].getElementValuePairs();
/* 2345 */           if (elementValuePairs != null && elementValuePairs.length == 1) {
/* 2346 */             Object value = elementValuePairs[0].getValue();
/* 2347 */             if (value instanceof ClassSignature) {
/* 2348 */               this.containerAnnotationType = (ReferenceBinding)this.environment.getTypeFromSignature(((ClassSignature)value).getTypeName(), 0, -1, false, null, missingTypeNames, ITypeAnnotationWalker.EMPTY_ANNOTATION_WALKER);
/*      */             }
/*      */           } 
/*      */           break;
/*      */         } 
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ReferenceBinding superclass() {
/* 2364 */     if (!isPrototype()) {
/* 2365 */       return this.superclass = this.prototype.superclass();
/*      */     }
/*      */     
/* 2368 */     if ((this.tagBits & 0x2000000L) == 0L) {
/* 2369 */       return this.superclass;
/*      */     }
/*      */     
/* 2372 */     this.superclass = (ReferenceBinding)resolveType(this.superclass, this.environment, true);
/* 2373 */     this.tagBits &= 0xFFFFFFFFFDFFFFFFL;
/* 2374 */     if (this.superclass.problemId() == 1) {
/* 2375 */       this.tagBits |= 0x20000L;
/*      */     } else {
/*      */       
/* 2378 */       boolean wasToleratingMissingTypeProcessingAnnotations = this.environment.mayTolerateMissingType;
/* 2379 */       this.environment.mayTolerateMissingType = true;
/*      */       try {
/* 2381 */         this.superclass.superclass();
/* 2382 */         this.superclass.superInterfaces();
/*      */       } finally {
/* 2384 */         this.environment.mayTolerateMissingType = wasToleratingMissingTypeProcessingAnnotations;
/*      */       } 
/*      */     } 
/* 2387 */     this.typeBits |= this.superclass.typeBits & 0x713;
/* 2388 */     if ((this.typeBits & 0x3) != 0)
/* 2389 */       this.typeBits |= applyCloseableClassWhitelists(this.environment.globalOptions); 
/* 2390 */     detectCircularHierarchy();
/* 2391 */     return this.superclass;
/*      */   }
/*      */   
/*      */   private void breakLoop() {
/* 2395 */     ReferenceBinding currentSuper = this.superclass;
/* 2396 */     ReferenceBinding prevSuper = null;
/* 2397 */     while (currentSuper != null) {
/* 2398 */       if ((currentSuper.tagBits & 0x200L) != 0L && prevSuper instanceof BinaryTypeBinding) {
/* 2399 */         ((BinaryTypeBinding)prevSuper).superclass = this.environment.getResolvedType(TypeConstants.JAVA_LANG_OBJECT, null);
/*      */         break;
/*      */       } 
/* 2402 */       currentSuper.tagBits |= 0x200L;
/* 2403 */       prevSuper = currentSuper;
/* 2404 */       currentSuper = currentSuper.superclass();
/*      */     } 
/*      */   }
/*      */   
/*      */   private void detectCircularHierarchy() {
/* 2409 */     ReferenceBinding currentSuper = this.superclass;
/* 2410 */     ReferenceBinding tempSuper = null;
/* 2411 */     int count = 0;
/* 2412 */     int skipCount = 20;
/* 2413 */     while (currentSuper != null && 
/* 2414 */       !currentSuper.hasHierarchyCheckStarted()) {
/*      */       
/* 2416 */       if (TypeBinding.equalsEquals(currentSuper, this) || TypeBinding.equalsEquals(currentSuper, tempSuper)) {
/* 2417 */         currentSuper.tagBits |= 0x20000L;
/* 2418 */         if (currentSuper.isBinaryBinding()) {
/* 2419 */           breakLoop();
/*      */         }
/*      */         return;
/*      */       } 
/* 2423 */       if (count == skipCount) {
/* 2424 */         tempSuper = currentSuper;
/* 2425 */         skipCount *= 2;
/* 2426 */         count = 0;
/*      */       } 
/*      */       
/* 2429 */       if (!currentSuper.isHierarchyConnected())
/*      */         return; 
/* 2431 */       currentSuper = currentSuper.superclass();
/* 2432 */       count++;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 2437 */     tempSuper = this;
/* 2438 */     while (TypeBinding.notEquals(currentSuper, tempSuper)) {
/* 2439 */       tempSuper.setHierarchyCheckDone();
/* 2440 */       tempSuper = tempSuper.superclass();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ReferenceBinding[] superInterfaces() {
/* 2448 */     if (!isPrototype()) {
/* 2449 */       return this.superInterfaces = this.prototype.superInterfaces();
/*      */     }
/* 2451 */     if ((this.tagBits & 0x4000000L) == 0L) {
/* 2452 */       return this.superInterfaces;
/*      */     }
/* 2454 */     for (int i = this.superInterfaces.length; --i >= 0; ) {
/* 2455 */       this.superInterfaces[i] = (ReferenceBinding)resolveType(this.superInterfaces[i], this.environment, true);
/* 2456 */       if (this.superInterfaces[i].problemId() == 1) {
/* 2457 */         this.tagBits |= 0x20000L;
/*      */       } else {
/*      */         
/* 2460 */         boolean wasToleratingMissingTypeProcessingAnnotations = this.environment.mayTolerateMissingType;
/* 2461 */         this.environment.mayTolerateMissingType = true;
/*      */         
/* 2463 */         try { this.superInterfaces[i].superclass();
/* 2464 */           if (this.superInterfaces[i].isParameterizedType())
/* 2465 */           { ReferenceBinding superType = this.superInterfaces[i].actualType();
/* 2466 */             if (TypeBinding.equalsEquals(superType, this))
/* 2467 */             { this.tagBits |= 0x20000L;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */               
/* 2473 */               this.environment.mayTolerateMissingType = wasToleratingMissingTypeProcessingAnnotations; continue; }  }  this.superInterfaces[i].superInterfaces(); } finally { this.environment.mayTolerateMissingType = wasToleratingMissingTypeProcessingAnnotations; }
/*      */       
/*      */       } 
/* 2476 */       this.typeBits |= (this.superInterfaces[i]).typeBits & 0x713;
/* 2477 */       if ((this.typeBits & 0x3) != 0)
/* 2478 */         this.typeBits |= applyCloseableInterfaceWhitelists(); 
/*      */     } 
/* 2480 */     this.tagBits &= 0xFFFFFFFFFBFFFFFFL;
/* 2481 */     return this.superInterfaces;
/*      */   }
/*      */ 
/*      */   
/*      */   public ReferenceBinding[] permittedTypes() {
/* 2486 */     if (!isPrototype()) {
/* 2487 */       return this.permittedSubtypes = this.prototype.permittedTypes();
/*      */     }
/* 2489 */     for (int i = this.permittedSubtypes.length; --i >= 0;) {
/* 2490 */       this.permittedSubtypes[i] = (ReferenceBinding)resolveType(this.permittedSubtypes[i], this.environment, false);
/*      */     }
/*      */     
/* 2493 */     return this.permittedSubtypes;
/*      */   }
/*      */ 
/*      */   
/*      */   public TypeVariableBinding[] typeVariables() {
/* 2498 */     if (!isPrototype()) {
/* 2499 */       return this.typeVariables = this.prototype.typeVariables();
/*      */     }
/* 2501 */     if ((this.tagBits & 0x1000000L) == 0L) {
/* 2502 */       return this.typeVariables;
/*      */     }
/* 2504 */     for (int i = this.typeVariables.length; --i >= 0;)
/* 2505 */       this.typeVariables[i].resolve(); 
/* 2506 */     this.tagBits &= 0xFFFFFFFFFEFFFFFFL;
/* 2507 */     return this.typeVariables;
/*      */   }
/*      */ 
/*      */   
/*      */   public String toString() {
/* 2512 */     if (hasTypeAnnotations()) {
/* 2513 */       return annotatedDebugName();
/*      */     }
/* 2515 */     StringBuilder buffer = new StringBuilder();
/*      */     
/* 2517 */     if (isDeprecated()) buffer.append("deprecated "); 
/* 2518 */     if (isPublic()) buffer.append("public "); 
/* 2519 */     if (isProtected()) buffer.append("protected "); 
/* 2520 */     if (isPrivate()) buffer.append("private "); 
/* 2521 */     if (isAbstract() && isClass()) buffer.append("abstract "); 
/* 2522 */     if (isStatic() && isNestedType()) buffer.append("static "); 
/* 2523 */     if (isFinal()) buffer.append("final ");
/*      */     
/* 2525 */     if (isRecord()) { buffer.append("record "); }
/* 2526 */     else if (isEnum()) { buffer.append("enum "); }
/* 2527 */     else if (isAnnotationType()) { buffer.append("@interface "); }
/* 2528 */     else if (isClass()) { buffer.append("class "); }
/* 2529 */     else { buffer.append("interface "); }
/* 2530 */      buffer.append((this.compoundName != null) ? CharOperation.toString(this.compoundName) : "UNNAMED TYPE");
/*      */     
/* 2532 */     if (this.typeVariables == null) {
/* 2533 */       buffer.append("<NULL TYPE VARIABLES>");
/* 2534 */     } else if (this.typeVariables != Binding.NO_TYPE_VARIABLES) {
/* 2535 */       buffer.append("<");
/* 2536 */       for (int i = 0, length = this.typeVariables.length; i < length; i++) {
/* 2537 */         if (i > 0) buffer.append(", "); 
/* 2538 */         if (this.typeVariables[i] == null) {
/* 2539 */           buffer.append("NULL TYPE VARIABLE");
/*      */         } else {
/*      */           
/* 2542 */           char[] varChars = this.typeVariables[i].toString().toCharArray();
/* 2543 */           buffer.append(varChars, 1, varChars.length - 2);
/*      */         } 
/* 2545 */       }  buffer.append(">");
/*      */     } 
/* 2547 */     buffer.append("\n\textends ");
/* 2548 */     buffer.append((this.superclass != null) ? this.superclass.debugName() : "NULL TYPE");
/*      */     
/* 2550 */     if (this.superInterfaces != null) {
/* 2551 */       if (this.superInterfaces != Binding.NO_SUPERINTERFACES) {
/* 2552 */         buffer.append("\n\timplements : ");
/* 2553 */         for (int i = 0, length = this.superInterfaces.length; i < length; i++) {
/* 2554 */           if (i > 0)
/* 2555 */             buffer.append(", "); 
/* 2556 */           buffer.append((this.superInterfaces[i] != null) ? this.superInterfaces[i].debugName() : "NULL TYPE");
/*      */         } 
/*      */       } 
/*      */     } else {
/* 2560 */       buffer.append("NULL SUPERINTERFACES");
/*      */     } 
/*      */     
/* 2563 */     if (this.permittedSubtypes != null) {
/* 2564 */       if (this.permittedSubtypes != Binding.NO_PERMITTEDTYPES) {
/* 2565 */         buffer.append("\n\tpermits : ");
/* 2566 */         for (int i = 0, length = this.permittedSubtypes.length; i < length; i++) {
/* 2567 */           if (i > 0)
/* 2568 */             buffer.append(", "); 
/* 2569 */           buffer.append((this.permittedSubtypes[i] != null) ? this.permittedSubtypes[i].debugName() : "NULL TYPE");
/*      */         } 
/*      */       } 
/*      */     } else {
/* 2573 */       buffer.append("NULL PERMITTEDSUBTYPES");
/*      */     } 
/*      */     
/* 2576 */     if (this.enclosingType != null) {
/* 2577 */       buffer.append("\n\tenclosing type : ");
/* 2578 */       buffer.append(this.enclosingType.debugName());
/*      */     } 
/*      */     
/* 2581 */     if (this.fields != null) {
/* 2582 */       if (this.fields != Binding.NO_FIELDS) {
/* 2583 */         buffer.append("\n/*   fields   */");
/* 2584 */         for (int i = 0, length = this.fields.length; i < length; i++)
/* 2585 */           buffer.append((this.fields[i] != null) ? ("\n" + this.fields[i].toString()) : "\nNULL FIELD"); 
/*      */       } 
/*      */     } else {
/* 2588 */       buffer.append("NULL FIELDS");
/*      */     } 
/*      */     
/* 2591 */     if (this.methods != null) {
/* 2592 */       if (this.methods != Binding.NO_METHODS) {
/* 2593 */         buffer.append("\n/*   methods   */");
/* 2594 */         for (int i = 0, length = this.methods.length; i < length; i++)
/* 2595 */           buffer.append((this.methods[i] != null) ? ("\n" + this.methods[i].toString()) : "\nNULL METHOD"); 
/*      */       } 
/*      */     } else {
/* 2598 */       buffer.append("NULL METHODS");
/*      */     } 
/*      */     
/* 2601 */     if (this.memberTypes != null) {
/* 2602 */       if (this.memberTypes != Binding.NO_MEMBER_TYPES) {
/* 2603 */         buffer.append("\n/*   members   */");
/* 2604 */         for (int i = 0, length = this.memberTypes.length; i < length; i++)
/* 2605 */           buffer.append((this.memberTypes[i] != null) ? ("\n" + this.memberTypes[i].toString()) : "\nNULL TYPE"); 
/*      */       } 
/*      */     } else {
/* 2608 */       buffer.append("NULL MEMBER TYPES");
/*      */     } 
/*      */     
/* 2611 */     buffer.append("\n\n\n");
/* 2612 */     return buffer.toString();
/*      */   }
/*      */ 
/*      */   
/*      */   public TypeBinding unannotated() {
/* 2617 */     return this.prototype;
/*      */   }
/*      */   
/*      */   public TypeBinding withoutToplevelNullAnnotation() {
/* 2621 */     if (!hasNullTypeAnnotations())
/* 2622 */       return this; 
/* 2623 */     AnnotationBinding[] newAnnotations = this.environment.filterNullTypeAnnotations(this.typeAnnotations);
/* 2624 */     if (newAnnotations.length > 0)
/* 2625 */       return this.environment.createAnnotatedType(this.prototype, newAnnotations); 
/* 2626 */     return this.prototype;
/*      */   }
/*      */ 
/*      */   
/*      */   MethodBinding[] unResolvedMethods() {
/* 2631 */     if (!isPrototype()) {
/* 2632 */       return this.prototype.unResolvedMethods();
/*      */     }
/* 2634 */     return this.methods;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public FieldBinding[] unResolvedFields() {
/* 2640 */     if (!isPrototype()) {
/* 2641 */       return this.prototype.unResolvedFields();
/*      */     }
/* 2643 */     return this.fields;
/*      */   }
/*      */ 
/*      */   
/*      */   public RecordComponentBinding[] unResolvedComponents() {
/* 2648 */     if (!isPrototype())
/* 2649 */       return this.prototype.unResolvedComponents(); 
/* 2650 */     return this.components;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public ModuleBinding module() {
/* 2656 */     if (!isPrototype())
/* 2657 */       return this.prototype.module; 
/* 2658 */     return this.module;
/*      */   }
/*      */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\lookup\BinaryTypeBinding.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */