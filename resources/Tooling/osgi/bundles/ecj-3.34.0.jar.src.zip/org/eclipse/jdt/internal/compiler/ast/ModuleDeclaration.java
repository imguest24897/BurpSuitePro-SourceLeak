/*     */ package org.eclipse.jdt.internal.compiler.ast;
/*     */ 
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import org.eclipse.jdt.core.compiler.CategorizedProblem;
/*     */ import org.eclipse.jdt.core.compiler.CharOperation;
/*     */ import org.eclipse.jdt.internal.compiler.ASTVisitor;
/*     */ import org.eclipse.jdt.internal.compiler.ClassFile;
/*     */ import org.eclipse.jdt.internal.compiler.CompilationResult;
/*     */ import org.eclipse.jdt.internal.compiler.impl.CompilerOptions;
/*     */ import org.eclipse.jdt.internal.compiler.impl.ReferenceContext;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.Binding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.BlockScope;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.CompilationUnitScope;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.LookupEnvironment;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.ModuleBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.ModuleScope;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.PackageBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.PlainPackageBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.Scope;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.SourceModuleBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.TypeBinding;
/*     */ import org.eclipse.jdt.internal.compiler.problem.AbortCompilation;
/*     */ import org.eclipse.jdt.internal.compiler.problem.AbortCompilationUnit;
/*     */ import org.eclipse.jdt.internal.compiler.problem.AbortMethod;
/*     */ import org.eclipse.jdt.internal.compiler.problem.AbortType;
/*     */ import org.eclipse.jdt.internal.compiler.util.HashtableOfObject;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ModuleDeclaration
/*     */   extends ASTNode
/*     */   implements ReferenceContext
/*     */ {
/*     */   public ExportsStatement[] exports;
/*     */   public RequiresStatement[] requires;
/*     */   public UsesStatement[] uses;
/*     */   public ProvidesStatement[] services;
/*     */   public OpensStatement[] opens;
/*     */   public Annotation[] annotations;
/*     */   public int exportsCount;
/*     */   public int requiresCount;
/*     */   public int usesCount;
/*     */   public int servicesCount;
/*     */   public int opensCount;
/*     */   public SourceModuleBinding binding;
/*     */   public int declarationSourceStart;
/*     */   public int declarationSourceEnd;
/*     */   public int bodyStart;
/*     */   public int bodyEnd;
/*     */   public int modifiersSourceStart;
/*     */   public ModuleScope scope;
/*     */   public char[][] tokens;
/*     */   public char[] moduleName;
/*     */   public long[] sourcePositions;
/*  72 */   public int modifiers = 0;
/*     */   boolean ignoreFurtherInvestigation;
/*     */   boolean hasResolvedModuleDirectives;
/*     */   boolean hasResolvedPackageDirectives;
/*     */   boolean hasResolvedTypeDirectives;
/*     */   CompilationResult compilationResult;
/*     */   
/*     */   public ModuleDeclaration(CompilationResult compilationResult, char[][] tokens, long[] positions) {
/*  80 */     this.compilationResult = compilationResult;
/*  81 */     this.exportsCount = 0;
/*  82 */     this.requiresCount = 0;
/*  83 */     this.tokens = tokens;
/*  84 */     this.moduleName = CharOperation.concatWith(tokens, '.');
/*  85 */     this.sourcePositions = positions;
/*  86 */     this.sourceEnd = (int)(positions[positions.length - 1] & 0xFFFFFFFFFFFFFFFFL);
/*  87 */     this.sourceStart = (int)(positions[0] >>> 32L);
/*     */   }
/*     */   
/*     */   public ModuleBinding setBinding(SourceModuleBinding sourceModuleBinding) {
/*  91 */     this.binding = sourceModuleBinding;
/*  92 */     return (ModuleBinding)sourceModuleBinding;
/*     */   }
/*     */   
/*     */   public void checkAndSetModifiers() {
/*  96 */     int realModifiers = this.modifiers & 0xFFFF;
/*  97 */     int expectedModifiers = 4128;
/*  98 */     if ((realModifiers & (expectedModifiers ^ 0xFFFFFFFF)) != 0) {
/*  99 */       this.scope.problemReporter().illegalModifierForModule(this);
/* 100 */       realModifiers &= expectedModifiers;
/*     */     } 
/* 102 */     int effectiveModifiers = 0x8000 | realModifiers;
/* 103 */     this.modifiers = this.binding.modifiers = effectiveModifiers;
/*     */   }
/*     */   
/*     */   public boolean isOpen() {
/* 107 */     return ((this.modifiers & 0x20) != 0);
/*     */   }
/*     */   
/*     */   public void createScope(Scope parentScope) {
/* 111 */     this.scope = new ModuleScope(parentScope, this);
/*     */   }
/*     */   
/*     */   public void generateCode() {
/* 115 */     if ((this.bits & 0x2000) != 0)
/*     */       return; 
/* 117 */     this.bits |= 0x2000;
/* 118 */     if (this.ignoreFurtherInvestigation) {
/*     */       return;
/*     */     }
/*     */     
/*     */     try {
/* 123 */       LookupEnvironment env = this.scope.environment();
/* 124 */       ClassFile classFile = env.classFilePool.acquireForModule((ModuleBinding)this.binding, env.globalOptions);
/* 125 */       classFile.initializeForModule((ModuleBinding)this.binding);
/*     */ 
/*     */       
/* 128 */       classFile.addModuleAttributes((ModuleBinding)this.binding, this.annotations, this.scope.referenceCompilationUnit());
/* 129 */       (this.scope.referenceCompilationUnit()).compilationResult.record(
/* 130 */           this.binding.moduleName, 
/* 131 */           classFile);
/* 132 */     } catch (AbortType abortType) {
/* 133 */       if (this.binding == null) {
/*     */         return;
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   public void resolveModuleDirectives(CompilationUnitScope cuScope) {
/* 140 */     if (this.binding == null) {
/* 141 */       this.ignoreFurtherInvestigation = true;
/*     */       return;
/*     */     } 
/* 144 */     if (this.hasResolvedModuleDirectives) {
/*     */       return;
/*     */     }
/* 147 */     this.hasResolvedModuleDirectives = true;
/*     */     
/* 149 */     Set<ModuleBinding> requiredModules = new HashSet<>();
/* 150 */     Set<ModuleBinding> requiredTransitiveModules = new HashSet<>();
/* 151 */     for (int i = 0; i < this.requiresCount; i++) {
/* 152 */       RequiresStatement ref = this.requires[i];
/* 153 */       if (ref != null && ref.resolve((Scope)cuScope) != null) {
/* 154 */         if (!requiredModules.add(ref.resolvedBinding)) {
/* 155 */           cuScope.problemReporter().duplicateModuleReference(8389909, ref.module);
/*     */         }
/* 157 */         if (ref.isTransitive())
/* 158 */           requiredTransitiveModules.add(ref.resolvedBinding); 
/* 159 */         Collection<ModuleBinding> deps = ref.resolvedBinding.dependencyGraphCollector().get();
/* 160 */         if (deps.contains(this.binding)) {
/* 161 */           cuScope.problemReporter().cyclicModuleDependency((ModuleBinding)this.binding, ref.module);
/* 162 */           requiredModules.remove(ref.module.binding);
/*     */         } 
/*     */       } 
/*     */     } 
/* 166 */     this.binding.setRequires(requiredModules.<ModuleBinding>toArray(new ModuleBinding[requiredModules.size()]), 
/* 167 */         requiredTransitiveModules.<ModuleBinding>toArray(new ModuleBinding[requiredTransitiveModules.size()]));
/*     */ 
/*     */     
/* 170 */     if (this.exports != null) {
/* 171 */       byte b; int j; ExportsStatement[] arrayOfExportsStatement; for (j = (arrayOfExportsStatement = this.exports).length, b = 0; b < j; ) { ExportsStatement exportsStatement = arrayOfExportsStatement[b];
/* 172 */         if (exportsStatement.isQualified()) {
/* 173 */           byte b1; int k; ModuleReference[] arrayOfModuleReference; for (k = (arrayOfModuleReference = exportsStatement.targets).length, b1 = 0; b1 < k; ) { ModuleReference moduleReference = arrayOfModuleReference[b1];
/* 174 */             moduleReference.resolve((Scope)cuScope); b1++; }
/*     */         
/*     */         }  b++; }
/*     */     
/* 178 */     }  if (this.opens != null) {
/* 179 */       byte b; int j; OpensStatement[] arrayOfOpensStatement; for (j = (arrayOfOpensStatement = this.opens).length, b = 0; b < j; ) { OpensStatement opensStatement = arrayOfOpensStatement[b];
/* 180 */         if (opensStatement.isQualified()) {
/* 181 */           byte b1; int k; ModuleReference[] arrayOfModuleReference; for (k = (arrayOfModuleReference = opensStatement.targets).length, b1 = 0; b1 < k; ) { ModuleReference moduleReference = arrayOfModuleReference[b1];
/* 182 */             moduleReference.resolve((Scope)cuScope);
/*     */             b1++; }
/*     */         
/*     */         } 
/*     */         b++; }
/*     */     
/*     */     } 
/*     */   } public void resolvePackageDirectives(CompilationUnitScope cuScope) {
/* 190 */     if (this.binding == null) {
/* 191 */       this.ignoreFurtherInvestigation = true;
/*     */       return;
/*     */     } 
/* 194 */     if (this.hasResolvedPackageDirectives) {
/*     */       return;
/*     */     }
/* 197 */     this.hasResolvedPackageDirectives = true;
/*     */     
/* 199 */     Set<PlainPackageBinding> exportedPkgs = new HashSet<>();
/* 200 */     for (int i = 0; i < this.exportsCount; i++) {
/* 201 */       ExportsStatement ref = this.exports[i];
/* 202 */       if (ref != null && ref.resolve((Scope)cuScope)) {
/* 203 */         if (!exportedPkgs.add(ref.resolvedPackage)) {
/* 204 */           cuScope.problemReporter().invalidPackageReference(8389910, ref);
/*     */         }
/* 206 */         char[][] targets = null;
/* 207 */         if (ref.targets != null) {
/* 208 */           targets = new char[ref.targets.length][];
/* 209 */           for (int k = 0; k < targets.length; k++)
/* 210 */             targets[k] = (ref.targets[k]).moduleName; 
/*     */         } 
/* 212 */         this.binding.addResolvedExport(ref.resolvedPackage, targets);
/*     */       } 
/*     */     } 
/*     */     
/* 216 */     HashtableOfObject openedPkgs = new HashtableOfObject();
/* 217 */     for (int j = 0; j < this.opensCount; j++) {
/* 218 */       OpensStatement ref = this.opens[j];
/* 219 */       if (isOpen()) {
/* 220 */         cuScope.problemReporter().invalidOpensStatement(ref, this);
/*     */       } else {
/* 222 */         if (openedPkgs.containsKey(ref.pkgName)) {
/* 223 */           cuScope.problemReporter().invalidPackageReference(8389921, ref);
/*     */         } else {
/* 225 */           openedPkgs.put(ref.pkgName, ref);
/* 226 */           ref.resolve((Scope)cuScope);
/*     */         } 
/* 228 */         char[][] targets = null;
/* 229 */         if (ref.targets != null) {
/* 230 */           targets = new char[ref.targets.length][];
/* 231 */           for (int k = 0; k < targets.length; k++)
/* 232 */             targets[k] = (ref.targets[k]).moduleName; 
/*     */         } 
/* 234 */         this.binding.addResolvedOpens(ref.resolvedPackage, targets);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void resolveTypeDirectives(CompilationUnitScope cuScope) {
/* 241 */     if (this.binding == null) {
/* 242 */       this.ignoreFurtherInvestigation = true;
/*     */       return;
/*     */     } 
/* 245 */     if (this.hasResolvedTypeDirectives) {
/*     */       return;
/*     */     }
/* 248 */     this.hasResolvedTypeDirectives = true;
/* 249 */     ASTNode.resolveAnnotations((BlockScope)this.scope, this.annotations, (Binding)this.binding);
/*     */     
/* 251 */     Set<TypeBinding> allTypes = new HashSet<>();
/* 252 */     for (int i = 0; i < this.usesCount; i++) {
/* 253 */       TypeBinding serviceBinding = (this.uses[i]).serviceInterface.resolveType((BlockScope)this.scope);
/* 254 */       if (serviceBinding != null && serviceBinding.isValidBinding()) {
/* 255 */         if (!serviceBinding.isClass() && !serviceBinding.isInterface() && !serviceBinding.isAnnotationType()) {
/* 256 */           cuScope.problemReporter().invalidServiceRef(8389924, (this.uses[i]).serviceInterface);
/*     */         }
/* 258 */         if (!allTypes.add((this.uses[i]).serviceInterface.resolvedType)) {
/* 259 */           cuScope.problemReporter().duplicateTypeReference(8389911, (this.uses[i]).serviceInterface);
/*     */         }
/*     */       } 
/*     */     } 
/* 263 */     this.binding.setUses(allTypes.<TypeBinding>toArray(new TypeBinding[allTypes.size()]));
/*     */     
/* 265 */     Set<TypeBinding> interfaces = new HashSet<>();
/* 266 */     for (int j = 0; j < this.servicesCount; j++) {
/* 267 */       this.services[j].resolve((BlockScope)this.scope);
/* 268 */       TypeBinding infBinding = (this.services[j]).serviceInterface.resolvedType;
/* 269 */       if (infBinding != null && infBinding.isValidBinding()) {
/* 270 */         if (!interfaces.add((this.services[j]).serviceInterface.resolvedType)) {
/* 271 */           cuScope.problemReporter().duplicateTypeReference(8389912, 
/* 272 */               (this.services[j]).serviceInterface);
/*     */         }
/* 274 */         this.binding.setImplementations(infBinding, this.services[j].getResolvedImplementations());
/*     */       } 
/*     */     } 
/* 277 */     this.binding.setServices(interfaces.<TypeBinding>toArray(new TypeBinding[interfaces.size()]));
/*     */   }
/*     */   
/*     */   public void analyseCode(CompilationUnitScope skope) {
/* 281 */     analyseModuleGraph(skope);
/* 282 */     analyseReferencedPackages(skope);
/*     */   }
/*     */   
/*     */   private void analyseReferencedPackages(CompilationUnitScope skope) {
/* 286 */     if (this.exports != null) {
/* 287 */       analyseSomeReferencedPackages((PackageVisibilityStatement[])this.exports, skope);
/*     */     }
/* 289 */     if (this.opens != null)
/* 290 */       analyseSomeReferencedPackages((PackageVisibilityStatement[])this.opens, skope); 
/*     */   } private void analyseSomeReferencedPackages(PackageVisibilityStatement[] stats, CompilationUnitScope skope) {
/*     */     byte b;
/*     */     int i;
/*     */     PackageVisibilityStatement[] arrayOfPackageVisibilityStatement;
/* 295 */     for (i = (arrayOfPackageVisibilityStatement = stats).length, b = 0; b < i; ) { PackageVisibilityStatement stat = arrayOfPackageVisibilityStatement[b];
/* 296 */       PlainPackageBinding pb = stat.resolvedPackage;
/* 297 */       if (pb != null)
/*     */       {
/* 299 */         if (!pb.hasCompilationUnit(true)) {
/*     */           byte b1; int j; ModuleBinding[] arrayOfModuleBinding;
/* 301 */           for (j = (arrayOfModuleBinding = this.binding.getAllRequiredModules()).length, b1 = 0; b1 < j; ) { ModuleBinding req = arrayOfModuleBinding[b1]; byte b2; int k; PlainPackageBinding[] arrayOfPlainPackageBinding;
/* 302 */             for (k = (arrayOfPlainPackageBinding = req.getExports()).length, b2 = 0; b2 < k; ) { PlainPackageBinding exported = arrayOfPlainPackageBinding[b2];
/* 303 */               if (CharOperation.equals(pb.compoundName, exported.compoundName)) {
/* 304 */                 skope.problemReporter().exportingForeignPackage(stat, req); return;
/*     */               }  b2++; }
/*     */             
/*     */             b1++; }
/*     */           
/* 309 */           skope.problemReporter().invalidPackageReference(8389919, stat);
/*     */         } 
/*     */       }
/*     */       b++; }
/*     */   
/* 314 */   } public void analyseModuleGraph(CompilationUnitScope skope) { if (this.requires != null) {
/*     */       
/* 316 */       Map<String, Set<ModuleBinding>> pack2mods = new HashMap<>(); byte b; int i; ModuleBinding[] arrayOfModuleBinding;
/* 317 */       for (i = (arrayOfModuleBinding = this.binding.getAllRequiredModules()).length, b = 0; b < i; ) { ModuleBinding requiredModule = arrayOfModuleBinding[b]; byte b1; int j; PlainPackageBinding[] arrayOfPlainPackageBinding;
/* 318 */         for (j = (arrayOfPlainPackageBinding = requiredModule.getExports()).length, b1 = 0; b1 < j; ) { PlainPackageBinding exportedPackage = arrayOfPlainPackageBinding[b1];
/* 319 */           if (this.binding.canAccess((PackageBinding)exportedPackage)) {
/* 320 */             String packName = String.valueOf(exportedPackage.readableName());
/* 321 */             Set<ModuleBinding> mods = pack2mods.get(packName);
/* 322 */             if (mods == null)
/* 323 */               pack2mods.put(packName, mods = new HashSet<>()); 
/* 324 */             mods.add(requiredModule);
/*     */           }  b1++; }
/*     */          b++; }
/*     */       
/*     */       RequiresStatement[] arrayOfRequiresStatement;
/* 329 */       for (i = (arrayOfRequiresStatement = this.requires).length, b = 0; b < i; ) { RequiresStatement requiresStat = arrayOfRequiresStatement[b];
/* 330 */         ModuleBinding requiredModule = requiresStat.resolvedBinding;
/* 331 */         if (requiredModule != null) {
/* 332 */           if (requiredModule.isDeprecated())
/* 333 */             skope.problemReporter().deprecatedModule(requiresStat.module, requiredModule); 
/* 334 */           analyseOneDependency(requiresStat, requiredModule, skope, pack2mods);
/* 335 */           if (requiresStat.isTransitive()) {
/* 336 */             byte b1; int j; ModuleBinding[] arrayOfModuleBinding1; for (j = (arrayOfModuleBinding1 = requiredModule.getAllRequiredModules()).length, b1 = 0; b1 < j; ) { ModuleBinding secondLevelModule = arrayOfModuleBinding1[b1];
/* 337 */               analyseOneDependency(requiresStat, secondLevelModule, skope, pack2mods);
/*     */               b1++; }
/*     */           
/*     */           } 
/*     */         } 
/*     */         b++; }
/*     */     
/*     */     }  } private void analyseOneDependency(RequiresStatement requiresStat, ModuleBinding requiredModule, CompilationUnitScope skope, Map<String, Set<ModuleBinding>> pack2mods) { byte b;
/*     */     int i;
/*     */     PlainPackageBinding[] arrayOfPlainPackageBinding;
/* 347 */     for (i = (arrayOfPlainPackageBinding = requiredModule.getExports()).length, b = 0; b < i; ) { PlainPackageBinding pack = arrayOfPlainPackageBinding[b];
/* 348 */       Set<ModuleBinding> mods = pack2mods.get(String.valueOf(pack.readableName()));
/* 349 */       if (mods != null && mods.size() > 1) {
/* 350 */         CompilerOptions compilerOptions = skope.compilerOptions();
/* 351 */         boolean inJdtDebugCompileMode = compilerOptions.enableJdtDebugCompileMode;
/* 352 */         if (!inJdtDebugCompileMode)
/* 353 */           skope.problemReporter().conflictingPackagesFromModules((PackageBinding)pack, mods, requiresStat.sourceStart, requiresStat.sourceEnd); 
/*     */       } 
/*     */       b++; }
/*     */      }
/*     */ 
/*     */   
/*     */   public void traverse(ASTVisitor visitor, CompilationUnitScope unitScope) {
/* 360 */     visitor.visit(this, unitScope);
/*     */   }
/*     */   
/*     */   public StringBuffer printHeader(int indent, StringBuffer output) {
/* 364 */     if (this.annotations != null) {
/* 365 */       for (int i = 0; i < this.annotations.length; i++) {
/* 366 */         this.annotations[i].print(indent, output);
/* 367 */         if (i != this.annotations.length - 1)
/* 368 */           output.append(" "); 
/*     */       } 
/* 370 */       output.append('\n');
/*     */     } 
/* 372 */     if (isOpen()) {
/* 373 */       output.append("open ");
/*     */     }
/* 375 */     output.append("module ");
/* 376 */     output.append(CharOperation.charToString(this.moduleName));
/* 377 */     return output;
/*     */   }
/*     */   public StringBuffer printBody(int indent, StringBuffer output) {
/* 380 */     output.append(" {");
/* 381 */     if (this.requires != null) {
/* 382 */       for (int i = 0; i < this.requiresCount; i++) {
/* 383 */         output.append('\n');
/* 384 */         printIndent(indent + 1, output);
/* 385 */         this.requires[i].print(0, output);
/*     */       } 
/*     */     }
/* 388 */     if (this.exports != null) {
/* 389 */       for (int i = 0; i < this.exportsCount; i++) {
/* 390 */         output.append('\n');
/* 391 */         this.exports[i].print(indent + 1, output);
/*     */       } 
/*     */     }
/* 394 */     if (this.opens != null) {
/* 395 */       for (int i = 0; i < this.opensCount; i++) {
/* 396 */         output.append('\n');
/* 397 */         this.opens[i].print(indent + 1, output);
/*     */       } 
/*     */     }
/* 400 */     if (this.uses != null) {
/* 401 */       for (int i = 0; i < this.usesCount; i++) {
/* 402 */         output.append('\n');
/* 403 */         this.uses[i].print(indent + 1, output);
/*     */       } 
/*     */     }
/* 406 */     if (this.servicesCount != 0) {
/* 407 */       for (int i = 0; i < this.servicesCount; i++) {
/* 408 */         output.append('\n');
/* 409 */         this.services[i].print(indent + 1, output);
/*     */       } 
/*     */     }
/* 412 */     output.append('\n');
/* 413 */     return printIndent(indent, output).append('}');
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public StringBuffer print(int indent, StringBuffer output) {
/* 419 */     printIndent(indent, output);
/* 420 */     printHeader(0, output);
/* 421 */     return printBody(indent, output);
/*     */   }
/*     */ 
/*     */   
/*     */   public void abort(int abortLevel, CategorizedProblem problem) {
/* 426 */     switch (abortLevel) {
/*     */       case 2:
/* 428 */         throw new AbortCompilation(this.compilationResult, problem);
/*     */       case 4:
/* 430 */         throw new AbortCompilationUnit(this.compilationResult, problem);
/*     */       case 16:
/* 432 */         throw new AbortMethod(this.compilationResult, problem);
/*     */     } 
/* 434 */     throw new AbortType(this.compilationResult, problem);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public CompilationResult compilationResult() {
/* 440 */     return this.compilationResult;
/*     */   }
/*     */ 
/*     */   
/*     */   public CompilationUnitDeclaration getCompilationUnitDeclaration() {
/* 445 */     return this.scope.referenceCompilationUnit();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean hasErrors() {
/* 450 */     return this.ignoreFurtherInvestigation;
/*     */   }
/*     */ 
/*     */   
/*     */   public void tagAsHavingErrors() {
/* 455 */     this.ignoreFurtherInvestigation = true;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void tagAsHavingIgnoredMandatoryErrors(int problemId) {}
/*     */ 
/*     */   
/*     */   public String getModuleVersion() {
/* 464 */     if (this.scope != null) {
/* 465 */       LookupEnvironment env = (this.scope.environment()).root;
/* 466 */       return env.moduleVersion;
/*     */     } 
/* 468 */     return null;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\ast\ModuleDeclaration.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */