/*     */ package org.eclipse.jdt.internal.compiler.ast;
/*     */ 
/*     */ import org.eclipse.jdt.internal.compiler.ASTVisitor;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.BlockScope;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.ClassScope;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.LocalTypeBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.MethodScope;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.ReferenceBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.Scope;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.TypeBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.TypeVariableBinding;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SingleTypeReference
/*     */   extends TypeReference
/*     */ {
/*     */   public char[] token;
/*     */   
/*     */   public SingleTypeReference(char[] source, int start, int end) {
/*  29 */     this.token = source;
/*  30 */     this.sourceStart = start;
/*  31 */     this.sourceEnd = end;
/*     */   }
/*     */   public SingleTypeReference(char[] source, long pos) {
/*  34 */     this.token = source;
/*  35 */     this.sourceStart = (int)(pos >>> 32L);
/*  36 */     this.sourceEnd = (int)(pos & 0xFFFFFFFFL);
/*     */   }
/*     */ 
/*     */   
/*     */   public TypeReference augmentTypeWithAdditionalDimensions(int additionalDimensions, Annotation[][] additionalAnnotations, boolean isVarargs) {
/*  41 */     int totalDimensions = dimensions() + additionalDimensions;
/*  42 */     Annotation[][] allAnnotations = getMergedAnnotationsOnDimensions(additionalDimensions, additionalAnnotations);
/*  43 */     ArrayTypeReference arrayTypeReference = new ArrayTypeReference(this.token, totalDimensions, allAnnotations, (this.sourceStart << 32L) + this.sourceEnd);
/*  44 */     arrayTypeReference.annotations = this.annotations;
/*  45 */     arrayTypeReference.bits |= this.bits & 0x100000;
/*  46 */     if (!isVarargs)
/*  47 */       arrayTypeReference.extendedDimensions = additionalDimensions; 
/*  48 */     return arrayTypeReference;
/*     */   }
/*     */ 
/*     */   
/*     */   public char[] getLastToken() {
/*  53 */     return this.token;
/*     */   }
/*     */   
/*     */   protected TypeBinding getTypeBinding(Scope scope) {
/*  57 */     if (this.resolvedType != null) {
/*  58 */       return this.resolvedType;
/*     */     }
/*  60 */     this.resolvedType = scope.getType(this.token);
/*     */     
/*  62 */     if (this.resolvedType instanceof TypeVariableBinding) {
/*  63 */       TypeVariableBinding typeVariable = (TypeVariableBinding)this.resolvedType;
/*  64 */       if (typeVariable.declaringElement instanceof org.eclipse.jdt.internal.compiler.lookup.SourceTypeBinding) {
/*  65 */         scope.tagAsAccessingEnclosingInstanceStateOf((ReferenceBinding)typeVariable.declaringElement, true);
/*     */       }
/*  67 */     } else if (this.resolvedType instanceof LocalTypeBinding) {
/*  68 */       LocalTypeBinding localType = (LocalTypeBinding)this.resolvedType;
/*  69 */       MethodScope methodScope = scope.methodScope();
/*  70 */       if (methodScope != null && !methodScope.isStatic) {
/*  71 */         methodScope.tagAsAccessingEnclosingInstanceStateOf((ReferenceBinding)localType, false);
/*     */       }
/*     */     } 
/*     */     
/*  75 */     if (scope.kind == 3 && this.resolvedType.isValidBinding() && (
/*  76 */       (ClassScope)scope).detectHierarchyCycle(this.resolvedType, this))
/*  77 */       return null; 
/*  78 */     return this.resolvedType;
/*     */   }
/*     */ 
/*     */   
/*     */   public char[][] getTypeName() {
/*  83 */     return new char[][] { this.token };
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isBaseTypeReference() {
/*  88 */     return !(this.token != BYTE && 
/*  89 */       this.token != SHORT && 
/*  90 */       this.token != INT && 
/*  91 */       this.token != LONG && 
/*  92 */       this.token != FLOAT && 
/*  93 */       this.token != DOUBLE && 
/*  94 */       this.token != CHAR && 
/*  95 */       this.token != BOOLEAN && 
/*  96 */       this.token != NULL && 
/*  97 */       this.token != VOID);
/*     */   }
/*     */ 
/*     */   
/*     */   public StringBuffer printExpression(int indent, StringBuffer output) {
/* 102 */     if (this.annotations != null && this.annotations[0] != null) {
/* 103 */       printAnnotations(this.annotations[0], output);
/* 104 */       output.append(' ');
/*     */     } 
/* 106 */     return output.append(this.token);
/*     */   }
/*     */   
/*     */   public TypeBinding resolveTypeEnclosing(BlockScope scope, ReferenceBinding enclosingType) {
/* 110 */     this.resolvedType = (TypeBinding)scope.getMemberType(this.token, enclosingType);
/* 111 */     boolean hasError = false;
/*     */     
/* 113 */     resolveAnnotations((Scope)scope, 0);
/* 114 */     TypeBinding memberType = this.resolvedType;
/* 115 */     if (!memberType.isValidBinding()) {
/* 116 */       hasError = true;
/* 117 */       scope.problemReporter().invalidEnclosingType(this, memberType, enclosingType);
/* 118 */       memberType = ((ReferenceBinding)memberType).closestMatch();
/* 119 */       if (memberType == null) {
/* 120 */         return null;
/*     */       }
/*     */     } 
/* 123 */     if (isTypeUseDeprecated(memberType, (Scope)scope))
/* 124 */       reportDeprecatedType(memberType, (Scope)scope); 
/* 125 */     memberType = scope.environment().convertToRawType(memberType, false);
/* 126 */     if (memberType.isRawType() && (
/* 127 */       this.bits & 0x40000000) == 0 && 
/* 128 */       scope.compilerOptions().getSeverity(536936448) != 256) {
/* 129 */       scope.problemReporter().rawTypeReference(this, memberType);
/*     */     }
/* 131 */     if (hasError)
/*     */     {
/* 133 */       return memberType;
/*     */     }
/* 135 */     return this.resolvedType = memberType;
/*     */   }
/*     */ 
/*     */   
/*     */   public void traverse(ASTVisitor visitor, BlockScope scope) {
/* 140 */     if (visitor.visit(this, scope) && 
/* 141 */       this.annotations != null) {
/* 142 */       Annotation[] typeAnnotations = this.annotations[0];
/* 143 */       for (int i = 0, length = (typeAnnotations == null) ? 0 : typeAnnotations.length; i < length; i++) {
/* 144 */         typeAnnotations[i].traverse(visitor, scope);
/*     */       }
/*     */     } 
/* 147 */     visitor.endVisit(this, scope);
/*     */   }
/*     */ 
/*     */   
/*     */   public void traverse(ASTVisitor visitor, ClassScope scope) {
/* 152 */     if (visitor.visit(this, scope) && 
/* 153 */       this.annotations != null) {
/* 154 */       Annotation[] typeAnnotations = this.annotations[0];
/* 155 */       for (int i = 0, length = (typeAnnotations == null) ? 0 : typeAnnotations.length; i < length; i++) {
/* 156 */         typeAnnotations[i].traverse(visitor, scope);
/*     */       }
/*     */     } 
/* 159 */     visitor.endVisit(this, scope);
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\ast\SingleTypeReference.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */