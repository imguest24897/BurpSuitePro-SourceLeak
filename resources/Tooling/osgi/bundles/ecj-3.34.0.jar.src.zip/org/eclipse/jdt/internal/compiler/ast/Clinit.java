/*     */ package org.eclipse.jdt.internal.compiler.ast;
/*     */ 
/*     */ import org.eclipse.jdt.internal.compiler.ASTVisitor;
/*     */ import org.eclipse.jdt.internal.compiler.ClassFile;
/*     */ import org.eclipse.jdt.internal.compiler.CompilationResult;
/*     */ import org.eclipse.jdt.internal.compiler.codegen.BranchLabel;
/*     */ import org.eclipse.jdt.internal.compiler.codegen.CodeStream;
/*     */ import org.eclipse.jdt.internal.compiler.codegen.ConstantPool;
/*     */ import org.eclipse.jdt.internal.compiler.flow.ExceptionHandlingFlowContext;
/*     */ import org.eclipse.jdt.internal.compiler.flow.FlowContext;
/*     */ import org.eclipse.jdt.internal.compiler.flow.FlowInfo;
/*     */ import org.eclipse.jdt.internal.compiler.flow.InitializationFlowContext;
/*     */ import org.eclipse.jdt.internal.compiler.flow.UnconditionalFlowInfo;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.Binding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.BlockScope;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.ClassScope;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.FieldBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.MethodBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.MethodScope;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.Scope;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.SourceTypeBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.SyntheticMethodBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.TypeBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.TypeConstants;
/*     */ import org.eclipse.jdt.internal.compiler.parser.Parser;
/*     */ import org.eclipse.jdt.internal.compiler.problem.AbortMethod;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Clinit
/*     */   extends AbstractMethodDeclaration
/*     */ {
/*  41 */   private static int ENUM_CONSTANTS_THRESHOLD = 2000;
/*     */   
/*  43 */   private FieldBinding assertionSyntheticFieldBinding = null;
/*  44 */   private FieldBinding classLiteralSyntheticField = null;
/*     */   
/*     */   public Clinit(CompilationResult compilationResult) {
/*  47 */     super(compilationResult);
/*  48 */     this.modifiers = 0;
/*  49 */     this.selector = TypeConstants.CLINIT;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void analyseCode(ClassScope classScope, InitializationFlowContext staticInitializerFlowContext, FlowInfo flowInfo) {
/*  57 */     if (this.ignoreFurtherInvestigation)
/*     */       return; 
/*     */     try {
/*  60 */       ExceptionHandlingFlowContext clinitContext = 
/*  61 */         new ExceptionHandlingFlowContext(
/*  62 */           staticInitializerFlowContext.parent, 
/*  63 */           this, 
/*  64 */           Binding.NO_EXCEPTIONS, 
/*  65 */           (FlowContext)staticInitializerFlowContext, 
/*  66 */           (BlockScope)this.scope, 
/*  67 */           FlowInfo.DEAD_END);
/*     */ 
/*     */       
/*  70 */       if ((flowInfo.tagBits & 0x1) == 0) {
/*  71 */         this.bits |= 0x40;
/*     */       }
/*     */ 
/*     */       
/*  75 */       UnconditionalFlowInfo unconditionalFlowInfo = flowInfo.mergedWith(staticInitializerFlowContext.initsOnReturn);
/*  76 */       FieldBinding[] fields = this.scope.enclosingSourceType().fields();
/*  77 */       for (int i = 0, count = fields.length; i < count; i++) {
/*  78 */         FieldBinding field = fields[i];
/*  79 */         if (field.isStatic() && 
/*  80 */           !unconditionalFlowInfo.isDefinitelyAssigned(field)) {
/*  81 */           if (field.isFinal()) {
/*  82 */             this.scope.problemReporter().uninitializedBlankFinalField(
/*  83 */                 field, 
/*  84 */                 this.scope.referenceType().declarationOf(field.original()));
/*     */           }
/*  86 */           else if (field.isNonNull()) {
/*  87 */             this.scope.problemReporter().uninitializedNonNullField(
/*  88 */                 field, 
/*  89 */                 this.scope.referenceType().declarationOf(field.original()));
/*     */           } 
/*     */         }
/*     */       } 
/*     */ 
/*     */       
/*  95 */       staticInitializerFlowContext.checkInitializerExceptions(
/*  96 */           (BlockScope)this.scope, 
/*  97 */           (FlowContext)clinitContext, 
/*  98 */           (FlowInfo)unconditionalFlowInfo);
/*  99 */     } catch (AbortMethod abortMethod) {
/* 100 */       this.ignoreFurtherInvestigation = true;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void generateCode(ClassScope classScope, ClassFile classFile) {
/* 113 */     int clinitOffset = 0;
/* 114 */     if (this.ignoreFurtherInvestigation) {
/*     */       return;
/*     */     }
/*     */     
/* 118 */     CompilationResult unitResult = null;
/* 119 */     int problemCount = 0;
/* 120 */     if (classScope != null) {
/* 121 */       TypeDeclaration referenceContext = classScope.referenceContext;
/* 122 */       if (referenceContext != null) {
/* 123 */         unitResult = referenceContext.compilationResult();
/* 124 */         problemCount = unitResult.problemCount;
/*     */       } 
/*     */     } 
/* 127 */     boolean restart = false;
/*     */     do {
/*     */       try {
/* 130 */         clinitOffset = classFile.contentsOffset;
/* 131 */         generateCode(classScope, classFile, clinitOffset);
/* 132 */         restart = false;
/* 133 */       } catch (AbortMethod e) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 141 */         if (e.compilationResult == CodeStream.RESTART_IN_WIDE_MODE) {
/*     */           
/* 143 */           classFile.contentsOffset = clinitOffset;
/* 144 */           classFile.methodCount--;
/* 145 */           classFile.codeStream.resetInWideMode();
/*     */           
/* 147 */           if (unitResult != null) {
/* 148 */             unitResult.problemCount = problemCount;
/*     */           }
/*     */           
/* 151 */           restart = true;
/* 152 */         } else if (e.compilationResult == CodeStream.RESTART_CODE_GEN_FOR_UNUSED_LOCALS_MODE) {
/* 153 */           classFile.contentsOffset = clinitOffset;
/* 154 */           classFile.methodCount--;
/* 155 */           classFile.codeStream.resetForCodeGenUnusedLocals();
/*     */           
/* 157 */           if (unitResult != null) {
/* 158 */             unitResult.problemCount = problemCount;
/*     */           }
/*     */           
/* 161 */           restart = true;
/*     */         } else {
/*     */           
/* 164 */           classFile.contentsOffset = clinitOffset;
/* 165 */           classFile.methodCount--;
/* 166 */           restart = false;
/*     */         } 
/*     */       } 
/* 169 */     } while (restart);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void generateCode(ClassScope classScope, ClassFile classFile, int clinitOffset) {
/* 183 */     ConstantPool constantPool = classFile.constantPool;
/* 184 */     int constantPoolOffset = constantPool.currentOffset;
/* 185 */     int constantPoolIndex = constantPool.currentIndex;
/* 186 */     classFile.generateMethodInfoHeaderForClinit();
/* 187 */     int codeAttributeOffset = classFile.contentsOffset;
/* 188 */     classFile.generateCodeAttributeHeader();
/* 189 */     CodeStream codeStream = classFile.codeStream;
/* 190 */     resolve(classScope);
/*     */     
/* 192 */     codeStream.reset(this, classFile);
/* 193 */     TypeDeclaration declaringType = classScope.referenceContext;
/*     */ 
/*     */     
/* 196 */     MethodScope staticInitializerScope = declaringType.staticInitializerScope;
/* 197 */     staticInitializerScope.computeLocalVariablePositions(0, codeStream);
/*     */ 
/*     */ 
/*     */     
/* 201 */     if (this.assertionSyntheticFieldBinding != null) {
/*     */       
/* 203 */       codeStream.generateClassLiteralAccessForType(
/* 204 */           (Scope)classScope, 
/* 205 */           (TypeBinding)classScope.outerMostClassScope().enclosingSourceType(), 
/* 206 */           this.classLiteralSyntheticField);
/* 207 */       codeStream.invokeJavaLangClassDesiredAssertionStatus();
/* 208 */       BranchLabel falseLabel = new BranchLabel(codeStream);
/* 209 */       codeStream.ifne(falseLabel);
/* 210 */       codeStream.iconst_1();
/* 211 */       BranchLabel jumpLabel = new BranchLabel(codeStream);
/* 212 */       codeStream.decrStackSize(1);
/* 213 */       codeStream.goto_(jumpLabel);
/* 214 */       falseLabel.place();
/* 215 */       codeStream.iconst_0();
/* 216 */       jumpLabel.place();
/* 217 */       codeStream.fieldAccess((byte)-77, this.assertionSyntheticFieldBinding, null);
/*     */     } 
/* 219 */     boolean isJava9 = ((classScope.compilerOptions()).complianceLevel >= 3473408L);
/*     */     
/* 221 */     FieldDeclaration[] fieldDeclarations = declaringType.fields;
/* 222 */     int sourcePosition = -1;
/* 223 */     int remainingFieldCount = 0;
/* 224 */     if (TypeDeclaration.kind(declaringType.modifiers) == 3) {
/* 225 */       int enumCount = declaringType.enumConstantsCounter;
/* 226 */       if (!isJava9 && enumCount > ENUM_CONSTANTS_THRESHOLD) {
/*     */         
/* 228 */         int begin = -1;
/* 229 */         int count = 0;
/* 230 */         if (fieldDeclarations != null) {
/* 231 */           int max = fieldDeclarations.length;
/* 232 */           for (int i = 0; i < max; i++) {
/* 233 */             FieldDeclaration fieldDecl = fieldDeclarations[i];
/* 234 */             if (fieldDecl.isStatic()) {
/* 235 */               if (fieldDecl.getKind() == 3) {
/* 236 */                 if (begin == -1) {
/* 237 */                   begin = i;
/*     */                 }
/* 239 */                 count++;
/* 240 */                 if (count > ENUM_CONSTANTS_THRESHOLD) {
/* 241 */                   SyntheticMethodBinding syntheticMethod = declaringType.binding.addSyntheticMethodForEnumInitialization(begin, i);
/* 242 */                   codeStream.invoke((byte)-72, (MethodBinding)syntheticMethod, null);
/* 243 */                   begin = i;
/* 244 */                   count = 1;
/*     */                 } 
/*     */               } else {
/* 247 */                 remainingFieldCount++;
/*     */               } 
/*     */             }
/*     */           } 
/* 251 */           if (count != 0) {
/*     */             
/* 253 */             SyntheticMethodBinding syntheticMethod = declaringType.binding.addSyntheticMethodForEnumInitialization(begin, max);
/* 254 */             codeStream.invoke((byte)-72, (MethodBinding)syntheticMethod, null);
/*     */           } 
/*     */         } 
/* 257 */       } else if (fieldDeclarations != null) {
/* 258 */         for (int i = 0, max = fieldDeclarations.length; i < max; i++) {
/* 259 */           FieldDeclaration fieldDecl = fieldDeclarations[i];
/* 260 */           if (fieldDecl.isStatic()) {
/* 261 */             if (fieldDecl.getKind() == 3) {
/* 262 */               fieldDecl.generateCode((BlockScope)staticInitializerScope, codeStream);
/*     */             } else {
/* 264 */               remainingFieldCount++;
/*     */             } 
/*     */           }
/*     */         } 
/*     */       } 
/*     */ 
/*     */       
/* 271 */       codeStream.generateInlinedValue(enumCount);
/* 272 */       codeStream.anewarray((TypeBinding)declaringType.binding);
/* 273 */       if (enumCount > 0 && 
/* 274 */         fieldDeclarations != null) {
/* 275 */         for (int i = 0, max = fieldDeclarations.length; i < max; i++) {
/* 276 */           FieldDeclaration fieldDecl = fieldDeclarations[i];
/*     */           
/* 278 */           if (fieldDecl.getKind() == 3) {
/* 279 */             codeStream.dup();
/* 280 */             codeStream.generateInlinedValue(fieldDecl.binding.id);
/* 281 */             codeStream.fieldAccess((byte)-78, fieldDecl.binding, null);
/* 282 */             codeStream.aastore();
/*     */           } 
/*     */         } 
/*     */       }
/*     */       
/* 287 */       codeStream.fieldAccess((byte)-77, declaringType.enumValuesSyntheticfield, null);
/* 288 */       if (remainingFieldCount != 0)
/*     */       {
/* 290 */         for (int i = 0, max = fieldDeclarations.length; i < max && remainingFieldCount >= 0; i++) {
/* 291 */           FieldDeclaration fieldDecl = fieldDeclarations[i];
/* 292 */           switch (fieldDecl.getKind()) {
/*     */ 
/*     */             
/*     */             case 2:
/* 296 */               if (!fieldDecl.isStatic()) {
/*     */                 break;
/*     */               }
/* 299 */               remainingFieldCount--;
/* 300 */               sourcePosition = ((Initializer)fieldDecl).block.sourceEnd;
/* 301 */               fieldDecl.generateCode((BlockScope)staticInitializerScope, codeStream);
/*     */               break;
/*     */             case 1:
/* 304 */               if (!fieldDecl.binding.isStatic()) {
/*     */                 break;
/*     */               }
/* 307 */               remainingFieldCount--;
/* 308 */               sourcePosition = fieldDecl.declarationEnd;
/* 309 */               fieldDecl.generateCode((BlockScope)staticInitializerScope, codeStream);
/*     */               break;
/*     */           } 
/*     */         } 
/*     */       }
/*     */     } else {
/* 315 */       if (fieldDeclarations != null) {
/* 316 */         for (int i = 0, max = fieldDeclarations.length; i < max; i++) {
/* 317 */           FieldDeclaration fieldDecl = fieldDeclarations[i];
/* 318 */           switch (fieldDecl.getKind()) {
/*     */             case 2:
/* 320 */               if (!fieldDecl.isStatic())
/*     */                 break; 
/* 322 */               sourcePosition = ((Initializer)fieldDecl).block.sourceEnd;
/* 323 */               fieldDecl.generateCode((BlockScope)staticInitializerScope, codeStream);
/*     */               break;
/*     */             case 1:
/* 326 */               if (!fieldDecl.binding.isStatic())
/*     */                 break; 
/* 328 */               sourcePosition = fieldDecl.declarationEnd;
/* 329 */               fieldDecl.generateCode((BlockScope)staticInitializerScope, codeStream);
/*     */               break;
/*     */           } 
/*     */         } 
/*     */       }
/* 334 */       if (isJava9) {
/* 335 */         declaringType.binding.generateSyntheticFinalFieldInitialization(codeStream);
/*     */       }
/*     */     } 
/*     */     
/* 339 */     if (codeStream.position == 0) {
/*     */ 
/*     */       
/* 342 */       classFile.contentsOffset = clinitOffset;
/*     */       
/* 344 */       classFile.methodCount--;
/*     */       
/* 346 */       constantPool.resetForClinit(constantPoolIndex, constantPoolOffset);
/*     */     } else {
/* 348 */       if ((this.bits & 0x40) != 0) {
/* 349 */         int before = codeStream.position;
/* 350 */         codeStream.return_();
/* 351 */         if (sourcePosition != -1)
/*     */         {
/* 353 */           codeStream.recordPositionsFrom(before, sourcePosition);
/*     */         }
/*     */       } 
/*     */       
/* 357 */       codeStream.recordPositionsFrom(0, declaringType.sourceStart);
/* 358 */       classFile.completeCodeAttributeForClinit(codeAttributeOffset, (Scope)classScope);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isClinit() {
/* 365 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isInitializationMethod() {
/* 371 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isStatic() {
/* 377 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void parseStatements(Parser parser, CompilationUnitDeclaration unit) {}
/*     */ 
/*     */ 
/*     */   
/*     */   public StringBuffer print(int tab, StringBuffer output) {
/* 388 */     printIndent(tab, output).append("<clinit>()");
/* 389 */     printBody(tab + 1, output);
/* 390 */     return output;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void resolve(ClassScope classScope) {
/* 396 */     this.scope = new MethodScope((Scope)classScope, classScope.referenceContext, true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void traverse(ASTVisitor visitor, ClassScope classScope) {
/* 404 */     visitor.visit(this, classScope);
/* 405 */     visitor.endVisit(this, classScope);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setAssertionSupport(FieldBinding assertionSyntheticFieldBinding, boolean needClassLiteralField) {
/* 410 */     this.assertionSyntheticFieldBinding = assertionSyntheticFieldBinding;
/*     */ 
/*     */     
/* 413 */     if (needClassLiteralField) {
/* 414 */       SourceTypeBinding sourceType = 
/* 415 */         this.scope.outerMostClassScope().enclosingSourceType();
/*     */       
/* 417 */       if (!sourceType.isInterface() && !sourceType.isBaseType())
/* 418 */         this.classLiteralSyntheticField = sourceType.addSyntheticFieldForClassLiteral((TypeBinding)sourceType, (BlockScope)this.scope); 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\ast\Clinit.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */