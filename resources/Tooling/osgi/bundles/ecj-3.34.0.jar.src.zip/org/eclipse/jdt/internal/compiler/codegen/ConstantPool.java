/*      */ package org.eclipse.jdt.internal.compiler.codegen;
/*      */ 
/*      */ import org.eclipse.jdt.core.compiler.CharOperation;
/*      */ import org.eclipse.jdt.internal.compiler.ClassFile;
/*      */ import org.eclipse.jdt.internal.compiler.classfmt.ClassFileConstants;
/*      */ import org.eclipse.jdt.internal.compiler.lookup.MethodBinding;
/*      */ import org.eclipse.jdt.internal.compiler.lookup.TypeBinding;
/*      */ import org.eclipse.jdt.internal.compiler.lookup.TypeConstants;
/*      */ import org.eclipse.jdt.internal.compiler.lookup.TypeIds;
/*      */ import org.eclipse.jdt.internal.compiler.util.HashtableOfInteger;
/*      */ import org.eclipse.jdt.internal.compiler.util.HashtableOfObject;
/*      */ import org.eclipse.jdt.internal.compiler.util.Util;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class ConstantPool
/*      */   implements ClassFileConstants, TypeIds
/*      */ {
/*      */   public static final int DOUBLE_INITIAL_SIZE = 5;
/*      */   public static final int FLOAT_INITIAL_SIZE = 3;
/*      */   public static final int INT_INITIAL_SIZE = 248;
/*      */   public static final int LONG_INITIAL_SIZE = 5;
/*      */   public static final int UTF8_INITIAL_SIZE = 778;
/*      */   public static final int STRING_INITIAL_SIZE = 761;
/*      */   public static final int METHODS_AND_FIELDS_INITIAL_SIZE = 450;
/*      */   public static final int CLASS_INITIAL_SIZE = 86;
/*      */   public static final int NAMEANDTYPE_INITIAL_SIZE = 272;
/*      */   public static final int CONSTANTPOOL_INITIAL_SIZE = 2000;
/*      */   public static final int CONSTANTPOOL_GROW_SIZE = 6000;
/*      */   public static final int DYNAMIC_INITIAL_SIZE = 10;
/*      */   protected DoubleCache doubleCache;
/*      */   protected FloatCache floatCache;
/*      */   protected IntegerCache intCache;
/*      */   protected LongCache longCache;
/*      */   public CharArrayCache UTF8Cache;
/*      */   protected CharArrayCache stringCache;
/*      */   protected HashtableOfObject methodsAndFieldsCache;
/*      */   protected CharArrayCache classCache;
/*      */   protected CharArrayCache moduleCache;
/*      */   protected CharArrayCache packageCache;
/*      */   protected HashtableOfObject nameAndTypeCacheForFieldsAndMethods;
/*      */   protected HashtableOfInteger dynamicCache;
/*      */   public byte[] poolContent;
/*   64 */   public int currentIndex = 1;
/*      */   
/*      */   public int currentOffset;
/*      */   public int[] offsets;
/*      */   public ClassFile classFile;
/*   69 */   public static final char[] Append = "append".toCharArray();
/*   70 */   public static final char[] ARRAY_NEWINSTANCE_NAME = "newInstance".toCharArray();
/*   71 */   public static final char[] ARRAY_NEWINSTANCE_SIGNATURE = "(Ljava/lang/Class;[I)Ljava/lang/Object;".toCharArray();
/*   72 */   public static final char[] ArrayCopy = "arraycopy".toCharArray();
/*   73 */   public static final char[] ArrayCopySignature = "(Ljava/lang/Object;ILjava/lang/Object;II)V".toCharArray();
/*   74 */   public static final char[] ArrayJavaLangClassConstantPoolName = "[Ljava/lang/Class;".toCharArray();
/*   75 */   public static final char[] ArrayJavaLangObjectConstantPoolName = "[Ljava/lang/Object;".toCharArray();
/*   76 */   public static final char[] booleanBooleanSignature = "(Z)Ljava/lang/Boolean;".toCharArray();
/*   77 */   public static final char[] BooleanConstrSignature = "(Z)V".toCharArray();
/*   78 */   public static final char[] BOOLEANVALUE_BOOLEAN_METHOD_NAME = "booleanValue".toCharArray();
/*   79 */   public static final char[] BOOLEANVALUE_BOOLEAN_METHOD_SIGNATURE = "()Z".toCharArray();
/*   80 */   public static final char[] byteByteSignature = "(B)Ljava/lang/Byte;".toCharArray();
/*   81 */   public static final char[] ByteConstrSignature = "(B)V".toCharArray();
/*   82 */   public static final char[] BYTEVALUE_BYTE_METHOD_NAME = "byteValue".toCharArray();
/*   83 */   public static final char[] BYTEVALUE_BYTE_METHOD_SIGNATURE = "()B".toCharArray();
/*   84 */   public static final char[] charCharacterSignature = "(C)Ljava/lang/Character;".toCharArray();
/*   85 */   public static final char[] CharConstrSignature = "(C)V".toCharArray();
/*   86 */   public static final char[] CHARVALUE_CHARACTER_METHOD_NAME = "charValue".toCharArray();
/*   87 */   public static final char[] CHARVALUE_CHARACTER_METHOD_SIGNATURE = "()C".toCharArray();
/*   88 */   public static final char[] Clinit = "<clinit>".toCharArray();
/*   89 */   public static final char[] DefaultConstructorSignature = "()V".toCharArray();
/*   90 */   public static final char[] ClinitSignature = DefaultConstructorSignature;
/*   91 */   public static final char[] Close = "close".toCharArray();
/*   92 */   public static final char[] CloseSignature = "()V".toCharArray();
/*   93 */   public static final char[] DesiredAssertionStatus = "desiredAssertionStatus".toCharArray();
/*   94 */   public static final char[] DesiredAssertionStatusSignature = "()Z".toCharArray();
/*   95 */   public static final char[] DoubleConstrSignature = "(D)V".toCharArray();
/*   96 */   public static final char[] doubleDoubleSignature = "(D)Ljava/lang/Double;".toCharArray();
/*   97 */   public static final char[] DOUBLEVALUE_DOUBLE_METHOD_NAME = "doubleValue".toCharArray();
/*   98 */   public static final char[] DOUBLEVALUE_DOUBLE_METHOD_SIGNATURE = "()D".toCharArray();
/*   99 */   public static final char[] EnumName = "$enum$name".toCharArray();
/*  100 */   public static final char[] EnumOrdinal = "$enum$ordinal".toCharArray();
/*  101 */   public static final char[] Exit = "exit".toCharArray();
/*  102 */   public static final char[] ExitIntSignature = "(I)V".toCharArray();
/*  103 */   public static final char[] FloatConstrSignature = "(F)V".toCharArray();
/*  104 */   public static final char[] floatFloatSignature = "(F)Ljava/lang/Float;".toCharArray();
/*  105 */   public static final char[] FLOATVALUE_FLOAT_METHOD_NAME = "floatValue".toCharArray();
/*  106 */   public static final char[] FLOATVALUE_FLOAT_METHOD_SIGNATURE = "()F".toCharArray();
/*  107 */   public static final char[] ForName = "forName".toCharArray();
/*  108 */   public static final char[] ForNameSignature = "(Ljava/lang/String;)Ljava/lang/Class;".toCharArray();
/*  109 */   public static final char[] GET_BOOLEAN_METHOD_NAME = "getBoolean".toCharArray();
/*  110 */   public static final char[] GET_BOOLEAN_METHOD_SIGNATURE = "(Ljava/lang/Object;)Z".toCharArray();
/*  111 */   public static final char[] GET_BYTE_METHOD_NAME = "getByte".toCharArray();
/*  112 */   public static final char[] GET_BYTE_METHOD_SIGNATURE = "(Ljava/lang/Object;)B".toCharArray();
/*  113 */   public static final char[] GET_CHAR_METHOD_NAME = "getChar".toCharArray();
/*  114 */   public static final char[] GET_CHAR_METHOD_SIGNATURE = "(Ljava/lang/Object;)C".toCharArray();
/*  115 */   public static final char[] GET_DOUBLE_METHOD_NAME = "getDouble".toCharArray();
/*  116 */   public static final char[] GET_DOUBLE_METHOD_SIGNATURE = "(Ljava/lang/Object;)D".toCharArray();
/*  117 */   public static final char[] GET_FLOAT_METHOD_NAME = "getFloat".toCharArray();
/*  118 */   public static final char[] GET_FLOAT_METHOD_SIGNATURE = "(Ljava/lang/Object;)F".toCharArray();
/*  119 */   public static final char[] GET_INT_METHOD_NAME = "getInt".toCharArray();
/*  120 */   public static final char[] GET_INT_METHOD_SIGNATURE = "(Ljava/lang/Object;)I".toCharArray();
/*  121 */   public static final char[] GET_LONG_METHOD_NAME = "getLong".toCharArray();
/*  122 */   public static final char[] GET_LONG_METHOD_SIGNATURE = "(Ljava/lang/Object;)J".toCharArray();
/*  123 */   public static final char[] GET_OBJECT_METHOD_NAME = "get".toCharArray();
/*  124 */   public static final char[] GET_OBJECT_METHOD_SIGNATURE = "(Ljava/lang/Object;)Ljava/lang/Object;".toCharArray();
/*  125 */   public static final char[] GET_SHORT_METHOD_NAME = "getShort".toCharArray();
/*  126 */   public static final char[] GET_SHORT_METHOD_SIGNATURE = "(Ljava/lang/Object;)S".toCharArray();
/*  127 */   public static final char[] GetClass = "getClass".toCharArray();
/*  128 */   public static final char[] GetClassSignature = "()Ljava/lang/Class;".toCharArray();
/*  129 */   public static final char[] GetComponentType = "getComponentType".toCharArray();
/*  130 */   public static final char[] GetComponentTypeSignature = GetClassSignature;
/*  131 */   public static final char[] GetConstructor = "getConstructor".toCharArray();
/*  132 */   public static final char[] GetConstructorSignature = "([Ljava/lang/Class;)Ljava/lang/reflect/Constructor;".toCharArray();
/*  133 */   public static final char[] GETDECLAREDCONSTRUCTOR_NAME = "getDeclaredConstructor".toCharArray();
/*  134 */   public static final char[] GETDECLAREDCONSTRUCTOR_SIGNATURE = "([Ljava/lang/Class;)Ljava/lang/reflect/Constructor;".toCharArray();
/*      */   
/*  136 */   public static final char[] GETDECLAREDFIELD_NAME = "getDeclaredField".toCharArray();
/*  137 */   public static final char[] GETDECLAREDFIELD_SIGNATURE = "(Ljava/lang/String;)Ljava/lang/reflect/Field;".toCharArray();
/*  138 */   public static final char[] GETDECLAREDMETHOD_NAME = "getDeclaredMethod".toCharArray();
/*  139 */   public static final char[] GETDECLAREDMETHOD_SIGNATURE = "(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;".toCharArray();
/*  140 */   public static final char[] GetMessage = "getMessage".toCharArray();
/*  141 */   public static final char[] GetMessageSignature = "()Ljava/lang/String;".toCharArray();
/*  142 */   public static final char[] HasNext = "hasNext".toCharArray();
/*  143 */   public static final char[] HasNextSignature = "()Z".toCharArray();
/*  144 */   public static final char[] Init = "<init>".toCharArray();
/*  145 */   public static final char[] IntConstrSignature = "(I)V".toCharArray();
/*  146 */   public static final char[] ITERATOR_NAME = "iterator".toCharArray();
/*  147 */   public static final char[] ITERATOR_SIGNATURE = "()Ljava/util/Iterator;".toCharArray();
/*  148 */   public static final char[] Intern = "intern".toCharArray();
/*  149 */   public static final char[] InternSignature = GetMessageSignature;
/*  150 */   public static final char[] IntIntegerSignature = "(I)Ljava/lang/Integer;".toCharArray();
/*  151 */   public static final char[] INTVALUE_INTEGER_METHOD_NAME = "intValue".toCharArray();
/*  152 */   public static final char[] INTVALUE_INTEGER_METHOD_SIGNATURE = "()I".toCharArray();
/*  153 */   public static final char[] INVOKE_METHOD_METHOD_NAME = "invoke".toCharArray();
/*  154 */   public static final char[] INVOKE_METHOD_METHOD_SIGNATURE = "(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;".toCharArray();
/*  155 */   public static final char[][] JAVA_LANG_REFLECT_ACCESSIBLEOBJECT = new char[][] { TypeConstants.JAVA, TypeConstants.LANG, TypeConstants.REFLECT, "AccessibleObject".toCharArray() };
/*  156 */   public static final char[][] JAVA_LANG_REFLECT_ARRAY = new char[][] { TypeConstants.JAVA, TypeConstants.LANG, TypeConstants.REFLECT, "Array".toCharArray() };
/*  157 */   public static final char[] IllegalArgumentExceptionConstructorSignature = "(Ljava/lang/String;)V".toCharArray();
/*      */   
/*  159 */   public static final char[] JavaIoPrintStreamSignature = "Ljava/io/PrintStream;".toCharArray();
/*  160 */   public static final char[] JavaLangAssertionErrorConstantPoolName = "java/lang/AssertionError".toCharArray();
/*  161 */   public static final char[] JavaLangBooleanConstantPoolName = "java/lang/Boolean".toCharArray();
/*  162 */   public static final char[] JavaLangByteConstantPoolName = "java/lang/Byte".toCharArray();
/*  163 */   public static final char[] JavaLangCharacterConstantPoolName = "java/lang/Character".toCharArray();
/*  164 */   public static final char[] JavaLangClassConstantPoolName = "java/lang/Class".toCharArray();
/*  165 */   public static final char[] JavaLangClassNotFoundExceptionConstantPoolName = "java/lang/ClassNotFoundException".toCharArray();
/*  166 */   public static final char[] JavaLangClassSignature = "Ljava/lang/Class;".toCharArray();
/*  167 */   public static final char[] JavaLangDoubleConstantPoolName = "java/lang/Double".toCharArray();
/*  168 */   public static final char[] JavaLangEnumConstantPoolName = "java/lang/Enum".toCharArray();
/*  169 */   public static final char[] JavaLangErrorConstantPoolName = "java/lang/Error".toCharArray();
/*  170 */   public static final char[] JavaLangIncompatibleClassChangeErrorConstantPoolName = "java/lang/IncompatibleClassChangeError".toCharArray();
/*  171 */   public static final char[] JavaLangMatchExceptionConstantPoolName = "java/lang/MatchException".toCharArray();
/*  172 */   public static final char[] JavaLangMatchExceptionNewInstanceSignature = "(Ljava/lang/String;Ljava/lang/Throwable;)V".toCharArray();
/*  173 */   public static final char[] JavaLangExceptionConstantPoolName = "java/lang/Exception".toCharArray();
/*  174 */   public static final char[] JavaLangFloatConstantPoolName = "java/lang/Float".toCharArray();
/*  175 */   public static final char[] JavaLangIntegerConstantPoolName = "java/lang/Integer".toCharArray();
/*  176 */   public static final char[] JavaLangLongConstantPoolName = "java/lang/Long".toCharArray();
/*  177 */   public static final char[] JavaLangNoClassDefFoundErrorConstantPoolName = "java/lang/NoClassDefFoundError".toCharArray();
/*  178 */   public static final char[] JavaLangNoSuchFieldErrorConstantPoolName = "java/lang/NoSuchFieldError".toCharArray();
/*  179 */   public static final char[] JavaLangObjectConstantPoolName = "java/lang/Object".toCharArray();
/*  180 */   public static final char[] JAVALANGREFLECTACCESSIBLEOBJECT_CONSTANTPOOLNAME = "java/lang/reflect/AccessibleObject".toCharArray();
/*  181 */   public static final char[] JAVALANGREFLECTARRAY_CONSTANTPOOLNAME = "java/lang/reflect/Array".toCharArray();
/*  182 */   public static final char[] JavaLangReflectConstructorConstantPoolName = "java/lang/reflect/Constructor".toCharArray();
/*  183 */   public static final char[] JavaLangReflectConstructorNewInstanceSignature = "([Ljava/lang/Object;)Ljava/lang/Object;".toCharArray();
/*  184 */   public static final char[] JAVALANGREFLECTFIELD_CONSTANTPOOLNAME = "java/lang/reflect/Field".toCharArray();
/*  185 */   public static final char[] JAVALANGREFLECTMETHOD_CONSTANTPOOLNAME = "java/lang/reflect/Method".toCharArray();
/*  186 */   public static final char[] JavaLangShortConstantPoolName = "java/lang/Short".toCharArray();
/*  187 */   public static final char[] JavaLangStringBufferConstantPoolName = "java/lang/StringBuffer".toCharArray();
/*  188 */   public static final char[] JavaLangStringBuilderConstantPoolName = "java/lang/StringBuilder".toCharArray();
/*  189 */   public static final char[] JavaLangStringConstantPoolName = "java/lang/String".toCharArray();
/*  190 */   public static final char[] JavaLangStringSignature = "Ljava/lang/String;".toCharArray();
/*  191 */   public static final char[] JavaLangObjectSignature = "Ljava/lang/Object;".toCharArray();
/*  192 */   public static final char[] JavaLangSystemConstantPoolName = "java/lang/System".toCharArray();
/*  193 */   public static final char[] JavaLangThrowableConstantPoolName = "java/lang/Throwable".toCharArray();
/*  194 */   public static final char[] JavaLangIllegalArgumentExceptionConstantPoolName = "java/lang/IllegalArgumentException".toCharArray();
/*  195 */   public static final char[] JavaLangVoidConstantPoolName = "java/lang/Void".toCharArray();
/*  196 */   public static final char[] JavaUtilIteratorConstantPoolName = "java/util/Iterator".toCharArray();
/*  197 */   public static final char[] JavaUtilObjectsConstantPoolName = "java/util/Objects".toCharArray();
/*  198 */   public static final char[] LongConstrSignature = "(J)V".toCharArray();
/*  199 */   public static final char[] longLongSignature = "(J)Ljava/lang/Long;".toCharArray();
/*  200 */   public static final char[] LONGVALUE_LONG_METHOD_NAME = "longValue".toCharArray();
/*  201 */   public static final char[] LONGVALUE_LONG_METHOD_SIGNATURE = "()J".toCharArray();
/*  202 */   public static final char[] Name = "name".toCharArray();
/*  203 */   public static final char[] NewInstance = "newInstance".toCharArray();
/*  204 */   public static final char[] NewInstanceSignature = "(Ljava/lang/Class;[I)Ljava/lang/Object;".toCharArray();
/*  205 */   public static final char[] Next = "next".toCharArray();
/*  206 */   public static final char[] NextSignature = "()Ljava/lang/Object;".toCharArray();
/*  207 */   public static final char[] ObjectConstrSignature = "(Ljava/lang/Object;)V".toCharArray();
/*  208 */   public static final char[] ObjectSignature = "Ljava/lang/Object;".toCharArray();
/*  209 */   public static final char[] Ordinal = "ordinal".toCharArray();
/*  210 */   public static final char[] OrdinalSignature = "()I".toCharArray();
/*  211 */   public static final char[] Out = "out".toCharArray();
/*  212 */   public static final char[] RequireNonNull = "requireNonNull".toCharArray();
/*  213 */   public static final char[] RequireNonNullSignature = "(Ljava/lang/Object;)Ljava/lang/Object;".toCharArray();
/*  214 */   public static final char[] SET_BOOLEAN_METHOD_NAME = "setBoolean".toCharArray();
/*  215 */   public static final char[] SET_BOOLEAN_METHOD_SIGNATURE = "(Ljava/lang/Object;Z)V".toCharArray();
/*  216 */   public static final char[] SET_BYTE_METHOD_NAME = "setByte".toCharArray();
/*  217 */   public static final char[] SET_BYTE_METHOD_SIGNATURE = "(Ljava/lang/Object;B)V".toCharArray();
/*  218 */   public static final char[] SET_CHAR_METHOD_NAME = "setChar".toCharArray();
/*  219 */   public static final char[] SET_CHAR_METHOD_SIGNATURE = "(Ljava/lang/Object;C)V".toCharArray();
/*  220 */   public static final char[] SET_DOUBLE_METHOD_NAME = "setDouble".toCharArray();
/*  221 */   public static final char[] SET_DOUBLE_METHOD_SIGNATURE = "(Ljava/lang/Object;D)V".toCharArray();
/*  222 */   public static final char[] SET_FLOAT_METHOD_NAME = "setFloat".toCharArray();
/*  223 */   public static final char[] SET_FLOAT_METHOD_SIGNATURE = "(Ljava/lang/Object;F)V".toCharArray();
/*  224 */   public static final char[] SET_INT_METHOD_NAME = "setInt".toCharArray();
/*  225 */   public static final char[] SET_INT_METHOD_SIGNATURE = "(Ljava/lang/Object;I)V".toCharArray();
/*  226 */   public static final char[] SET_LONG_METHOD_NAME = "setLong".toCharArray();
/*  227 */   public static final char[] SET_LONG_METHOD_SIGNATURE = "(Ljava/lang/Object;J)V".toCharArray();
/*  228 */   public static final char[] SET_OBJECT_METHOD_NAME = "set".toCharArray();
/*  229 */   public static final char[] SET_OBJECT_METHOD_SIGNATURE = "(Ljava/lang/Object;Ljava/lang/Object;)V".toCharArray();
/*  230 */   public static final char[] SET_SHORT_METHOD_NAME = "setShort".toCharArray();
/*  231 */   public static final char[] SET_SHORT_METHOD_SIGNATURE = "(Ljava/lang/Object;S)V".toCharArray();
/*  232 */   public static final char[] SETACCESSIBLE_NAME = "setAccessible".toCharArray();
/*  233 */   public static final char[] SETACCESSIBLE_SIGNATURE = "(Z)V".toCharArray();
/*  234 */   public static final char[] ShortConstrSignature = "(S)V".toCharArray();
/*  235 */   public static final char[] shortShortSignature = "(S)Ljava/lang/Short;".toCharArray();
/*  236 */   public static final char[] SHORTVALUE_SHORT_METHOD_NAME = "shortValue".toCharArray();
/*  237 */   public static final char[] SHORTVALUE_SHORT_METHOD_SIGNATURE = "()S".toCharArray();
/*  238 */   public static final char[] StringBufferAppendBooleanSignature = "(Z)Ljava/lang/StringBuffer;".toCharArray();
/*  239 */   public static final char[] StringBufferAppendCharSignature = "(C)Ljava/lang/StringBuffer;".toCharArray();
/*  240 */   public static final char[] StringBufferAppendDoubleSignature = "(D)Ljava/lang/StringBuffer;".toCharArray();
/*  241 */   public static final char[] StringBufferAppendFloatSignature = "(F)Ljava/lang/StringBuffer;".toCharArray();
/*  242 */   public static final char[] StringBufferAppendIntSignature = "(I)Ljava/lang/StringBuffer;".toCharArray();
/*  243 */   public static final char[] StringBufferAppendLongSignature = "(J)Ljava/lang/StringBuffer;".toCharArray();
/*  244 */   public static final char[] StringBufferAppendObjectSignature = "(Ljava/lang/Object;)Ljava/lang/StringBuffer;".toCharArray();
/*  245 */   public static final char[] StringBufferAppendStringSignature = "(Ljava/lang/String;)Ljava/lang/StringBuffer;".toCharArray();
/*  246 */   public static final char[] StringBuilderAppendBooleanSignature = "(Z)Ljava/lang/StringBuilder;".toCharArray();
/*  247 */   public static final char[] StringBuilderAppendCharSignature = "(C)Ljava/lang/StringBuilder;".toCharArray();
/*  248 */   public static final char[] StringBuilderAppendDoubleSignature = "(D)Ljava/lang/StringBuilder;".toCharArray();
/*  249 */   public static final char[] StringBuilderAppendFloatSignature = "(F)Ljava/lang/StringBuilder;".toCharArray();
/*  250 */   public static final char[] StringBuilderAppendIntSignature = "(I)Ljava/lang/StringBuilder;".toCharArray();
/*  251 */   public static final char[] StringBuilderAppendLongSignature = "(J)Ljava/lang/StringBuilder;".toCharArray();
/*  252 */   public static final char[] StringBuilderAppendObjectSignature = "(Ljava/lang/Object;)Ljava/lang/StringBuilder;".toCharArray();
/*  253 */   public static final char[] StringBuilderAppendStringSignature = "(Ljava/lang/String;)Ljava/lang/StringBuilder;".toCharArray();
/*  254 */   public static final char[] StringConstructorSignature = "(Ljava/lang/String;)V".toCharArray();
/*  255 */   public static final char[] This = "this".toCharArray();
/*  256 */   public static final char[] ToString = "toString".toCharArray();
/*  257 */   public static final char[] ToStringSignature = GetMessageSignature;
/*  258 */   public static final char[] TYPE = "TYPE".toCharArray();
/*  259 */   public static final char[] ValueOf = "valueOf".toCharArray();
/*  260 */   public static final char[] ValueOfBooleanSignature = "(Z)Ljava/lang/String;".toCharArray();
/*  261 */   public static final char[] ValueOfCharSignature = "(C)Ljava/lang/String;".toCharArray();
/*  262 */   public static final char[] ValueOfDoubleSignature = "(D)Ljava/lang/String;".toCharArray();
/*  263 */   public static final char[] ValueOfFloatSignature = "(F)Ljava/lang/String;".toCharArray();
/*  264 */   public static final char[] ValueOfIntSignature = "(I)Ljava/lang/String;".toCharArray();
/*  265 */   public static final char[] ValueOfLongSignature = "(J)Ljava/lang/String;".toCharArray();
/*  266 */   public static final char[] ValueOfObjectSignature = "(Ljava/lang/Object;)Ljava/lang/String;".toCharArray();
/*  267 */   public static final char[] ValueOfStringClassSignature = "(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;".toCharArray();
/*  268 */   public static final char[] JAVA_LANG_ANNOTATION_DOCUMENTED = "Ljava/lang/annotation/Documented;".toCharArray();
/*  269 */   public static final char[] JAVA_LANG_ANNOTATION_ELEMENTTYPE = "Ljava/lang/annotation/ElementType;".toCharArray();
/*  270 */   public static final char[] JAVA_LANG_ANNOTATION_RETENTION = "Ljava/lang/annotation/Retention;".toCharArray();
/*  271 */   public static final char[] JAVA_LANG_ANNOTATION_RETENTIONPOLICY = "Ljava/lang/annotation/RetentionPolicy;".toCharArray();
/*  272 */   public static final char[] JAVA_LANG_ANNOTATION_TARGET = "Ljava/lang/annotation/Target;".toCharArray();
/*  273 */   public static final char[] JAVA_LANG_DEPRECATED = "Ljava/lang/Deprecated;".toCharArray();
/*  274 */   public static final char[] JAVA_LANG_ANNOTATION_INHERITED = "Ljava/lang/annotation/Inherited;".toCharArray();
/*      */   
/*  276 */   public static final char[] JAVA_LANG_SAFEVARARGS = "Ljava/lang/SafeVarargs;".toCharArray();
/*      */   
/*  278 */   public static final char[] JAVA_LANG_INVOKE_METHODHANDLE_POLYMORPHICSIGNATURE = "Ljava/lang/invoke/MethodHandle$PolymorphicSignature;".toCharArray();
/*      */   
/*  280 */   public static final char[] METAFACTORY = "metafactory".toCharArray();
/*  281 */   public static final char[] JAVA_LANG_INVOKE_LAMBDAMETAFACTORY_METAFACTORY_SIGNATURE = "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;Ljava/lang/invoke/MethodType;Ljava/lang/invoke/MethodHandle;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite;".toCharArray();
/*  282 */   public static final char[] ALTMETAFACTORY = "altMetafactory".toCharArray();
/*      */   
/*  284 */   public static final char[] JAVA_LANG_INVOKE_LAMBDAMETAFACTORY_ALTMETAFACTORY_SIGNATURE = "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;[Ljava/lang/Object;)Ljava/lang/invoke/CallSite;".toCharArray();
/*  285 */   public static final char[] JavaLangInvokeSerializedLambda = "Ljava/lang/invoke/SerializedLambda;".toCharArray();
/*  286 */   public static final char[] JavaLangInvokeSerializedLambdaConstantPoolName = "java/lang/invoke/SerializedLambda".toCharArray();
/*  287 */   public static final char[] GetImplMethodName = "getImplMethodName".toCharArray();
/*  288 */   public static final char[] GetImplMethodNameSignature = "()Ljava/lang/String;".toCharArray();
/*  289 */   public static final char[] GetImplMethodKind = "getImplMethodKind".toCharArray();
/*  290 */   public static final char[] GetImplMethodKindSignature = "()I".toCharArray();
/*  291 */   public static final char[] GetFunctionalInterfaceClass = "getFunctionalInterfaceClass".toCharArray();
/*  292 */   public static final char[] GetFunctionalInterfaceClassSignature = "()Ljava/lang/String;".toCharArray();
/*  293 */   public static final char[] GetFunctionalInterfaceMethodName = "getFunctionalInterfaceMethodName".toCharArray();
/*  294 */   public static final char[] GetFunctionalInterfaceMethodNameSignature = "()Ljava/lang/String;".toCharArray();
/*  295 */   public static final char[] GetFunctionalInterfaceMethodSignature = "getFunctionalInterfaceMethodSignature".toCharArray();
/*  296 */   public static final char[] GetFunctionalInterfaceMethodSignatureSignature = "()Ljava/lang/String;".toCharArray();
/*  297 */   public static final char[] GetImplClass = "getImplClass".toCharArray();
/*  298 */   public static final char[] GetImplClassSignature = "()Ljava/lang/String;".toCharArray();
/*  299 */   public static final char[] GetImplMethodSignature = "getImplMethodSignature".toCharArray();
/*  300 */   public static final char[] GetImplMethodSignatureSignature = "()Ljava/lang/String;".toCharArray();
/*  301 */   public static final char[] GetCapturedArg = "getCapturedArg".toCharArray();
/*  302 */   public static final char[] GetCapturedArgSignature = "(I)Ljava/lang/Object;".toCharArray();
/*      */   
/*  304 */   public static final char[] JAVA_LANG_ANNOTATION_REPEATABLE = "Ljava/lang/annotation/Repeatable;".toCharArray();
/*      */   
/*  306 */   public static final char[] HashCode = "hashCode".toCharArray();
/*  307 */   public static final char[] HashCodeSignature = "()I".toCharArray();
/*  308 */   public static final char[] Equals = "equals".toCharArray();
/*  309 */   public static final char[] EqualsSignature = "(Ljava/lang/Object;)Z".toCharArray();
/*  310 */   public static final char[] AddSuppressed = "addSuppressed".toCharArray();
/*  311 */   public static final char[] AddSuppressedSignature = "(Ljava/lang/Throwable;)V".toCharArray();
/*  312 */   public static final char[] Clone = "clone".toCharArray();
/*  313 */   public static final char[] CloneSignature = "()Ljava/lang/Object;".toCharArray();
/*  314 */   public static final char[] BOOTSTRAP = "bootstrap".toCharArray();
/*  315 */   public static final char[] JAVA_LANG_RUNTIME_OBJECTMETHOD_BOOTSTRAP_SIGNATURE = "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/TypeDescriptor;Ljava/lang/Class;Ljava/lang/String;[Ljava/lang/invoke/MethodHandle;)Ljava/lang/Object;".toCharArray();
/*  316 */   public static final char[] PREVIEW_FEATURE = "/PreviewFeature".toCharArray();
/*  317 */   public static final char[] TYPESWITCH = "typeSwitch".toCharArray();
/*  318 */   public static final char[] ENUMSWITCH = "enumSwitch".toCharArray();
/*  319 */   public static final char[] JAVA_LANG_RUNTIME_SWITCHBOOTSTRAPS_SWITCH_SIGNATURE = "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;[Ljava/lang/Object;)Ljava/lang/invoke/CallSite;".toCharArray();
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ConstantPool(ClassFile classFile) {
/*  325 */     this.UTF8Cache = new CharArrayCache(778);
/*  326 */     this.stringCache = new CharArrayCache(761);
/*  327 */     this.methodsAndFieldsCache = new HashtableOfObject(450);
/*  328 */     this.classCache = new CharArrayCache(86);
/*  329 */     this.moduleCache = new CharArrayCache(5);
/*  330 */     this.packageCache = new CharArrayCache(5);
/*  331 */     this.nameAndTypeCacheForFieldsAndMethods = new HashtableOfObject(272);
/*  332 */     this.dynamicCache = new HashtableOfInteger(10);
/*  333 */     this.offsets = new int[5];
/*  334 */     initialize(classFile);
/*      */   }
/*      */   public void initialize(ClassFile givenClassFile) {
/*  337 */     this.poolContent = givenClassFile.header;
/*  338 */     this.currentOffset = givenClassFile.headerOffset;
/*      */     
/*  340 */     this.currentIndex = 1;
/*  341 */     this.classFile = givenClassFile;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public byte[] dumpBytes() {
/*  347 */     System.arraycopy(this.poolContent, 0, this.poolContent = new byte[this.currentOffset], 0, this.currentOffset);
/*  348 */     return this.poolContent;
/*      */   }
/*      */   public int literalIndex(byte[] utf8encoding, char[] stringCharArray) {
/*      */     int index;
/*  352 */     if ((index = this.UTF8Cache.putIfAbsent(stringCharArray, this.currentIndex)) < 0) {
/*      */       
/*  354 */       if ((index = -index) > 65535) {
/*  355 */         this.classFile.referenceBinding.scope.problemReporter().noMoreAvailableSpaceInConstantPool(this.classFile.referenceBinding.scope.referenceType());
/*      */       }
/*  357 */       this.currentIndex++;
/*      */       
/*  359 */       int length = this.offsets.length;
/*  360 */       if (length <= index)
/*      */       {
/*  362 */         System.arraycopy(this.offsets, 0, this.offsets = new int[index * 2], 0, length);
/*      */       }
/*  364 */       this.offsets[index] = this.currentOffset;
/*  365 */       writeU1(1);
/*  366 */       int utf8encodingLength = utf8encoding.length;
/*  367 */       if (this.currentOffset + 2 + utf8encodingLength >= this.poolContent.length)
/*      */       {
/*      */         
/*  370 */         resizePoolContents(2 + utf8encodingLength);
/*      */       }
/*  372 */       this.poolContent[this.currentOffset++] = (byte)(utf8encodingLength >> 8);
/*  373 */       this.poolContent[this.currentOffset++] = (byte)utf8encodingLength;
/*      */       
/*  375 */       System.arraycopy(utf8encoding, 0, this.poolContent, this.currentOffset, utf8encodingLength);
/*  376 */       this.currentOffset += utf8encodingLength;
/*      */     } 
/*  378 */     return index;
/*      */   }
/*      */   public int literalIndex(TypeBinding binding) {
/*  381 */     TypeBinding typeBinding = binding.leafComponentType();
/*  382 */     if ((typeBinding.tagBits & 0x800L) != 0L) {
/*  383 */       Util.recordNestedType(this.classFile, typeBinding);
/*      */     }
/*  385 */     return literalIndex(binding.signature());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int literalIndex(char[] utf8Constant) {
/*      */     int index;
/*  395 */     if ((index = this.UTF8Cache.putIfAbsent(utf8Constant, this.currentIndex)) < 0) {
/*  396 */       if ((index = -index) > 65535) {
/*  397 */         this.classFile.referenceBinding.scope.problemReporter().noMoreAvailableSpaceInConstantPool(this.classFile.referenceBinding.scope.referenceType());
/*      */       }
/*      */ 
/*      */       
/*  401 */       int length = this.offsets.length;
/*  402 */       if (length <= index)
/*      */       {
/*  404 */         System.arraycopy(this.offsets, 0, this.offsets = new int[index * 2], 0, length);
/*      */       }
/*  406 */       this.offsets[index] = this.currentOffset;
/*  407 */       writeU1(1);
/*      */       
/*  409 */       int savedCurrentOffset = this.currentOffset;
/*  410 */       if (this.currentOffset + 2 >= this.poolContent.length)
/*      */       {
/*      */         
/*  413 */         resizePoolContents(2);
/*      */       }
/*  415 */       this.currentOffset += 2;
/*  416 */       length = 0;
/*  417 */       for (int i = 0; i < utf8Constant.length; i++) {
/*  418 */         char current = utf8Constant[i];
/*  419 */         if (current >= '\001' && current <= '') {
/*      */           
/*  421 */           writeU1(current);
/*  422 */           length++;
/*      */         }
/*  424 */         else if (current > '߿') {
/*      */           
/*  426 */           length += 3;
/*  427 */           writeU1(0xE0 | current >> 12 & 0xF);
/*  428 */           writeU1(0x80 | current >> 6 & 0x3F);
/*  429 */           writeU1(0x80 | current & 0x3F);
/*      */         }
/*      */         else {
/*      */           
/*  433 */           length += 2;
/*  434 */           writeU1(0xC0 | current >> 6 & 0x1F);
/*  435 */           writeU1(0x80 | current & 0x3F);
/*      */         } 
/*      */       } 
/*      */       
/*  439 */       if (length >= 65535) {
/*  440 */         this.currentOffset = savedCurrentOffset - 1;
/*  441 */         this.classFile.referenceBinding.scope.problemReporter().noMoreAvailableSpaceForConstant(this.classFile.referenceBinding.scope.referenceType());
/*      */       } 
/*  443 */       if (index > 65535) {
/*  444 */         this.classFile.referenceBinding.scope.problemReporter().noMoreAvailableSpaceInConstantPool(this.classFile.referenceBinding.scope.referenceType());
/*      */       }
/*  446 */       this.currentIndex++;
/*      */ 
/*      */       
/*  449 */       this.poolContent[savedCurrentOffset] = (byte)(length >> 8);
/*  450 */       this.poolContent[savedCurrentOffset + 1] = (byte)length;
/*      */     } 
/*  452 */     return index;
/*      */   }
/*      */   public int literalIndex(char[] stringCharArray, byte[] utf8encoding) {
/*      */     int index;
/*  456 */     if ((index = this.stringCache.putIfAbsent(stringCharArray, this.currentIndex)) < 0) {
/*      */       
/*  458 */       this.currentIndex++;
/*  459 */       if ((index = -index) > 65535) {
/*  460 */         this.classFile.referenceBinding.scope.problemReporter().noMoreAvailableSpaceInConstantPool(this.classFile.referenceBinding.scope.referenceType());
/*      */       }
/*      */       
/*  463 */       int length = this.offsets.length;
/*  464 */       if (length <= index)
/*      */       {
/*  466 */         System.arraycopy(this.offsets, 0, this.offsets = new int[index * 2], 0, length);
/*      */       }
/*  468 */       this.offsets[index] = this.currentOffset;
/*  469 */       writeU1(8);
/*      */       
/*  471 */       int stringIndexOffset = this.currentOffset;
/*  472 */       if (this.currentOffset + 2 >= this.poolContent.length) {
/*  473 */         resizePoolContents(2);
/*      */       }
/*  475 */       this.currentOffset += 2;
/*      */       
/*  477 */       int stringIndex = literalIndex(utf8encoding, stringCharArray);
/*  478 */       this.poolContent[stringIndexOffset++] = (byte)(stringIndex >> 8);
/*  479 */       this.poolContent[stringIndexOffset] = (byte)stringIndex;
/*      */     } 
/*  481 */     return index;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int literalIndex(double key) {
/*  498 */     if (this.doubleCache == null)
/*  499 */       this.doubleCache = new DoubleCache(5); 
/*      */     int index;
/*  501 */     if ((index = this.doubleCache.putIfAbsent(key, this.currentIndex)) < 0) {
/*  502 */       if ((index = -index) > 65535) {
/*  503 */         this.classFile.referenceBinding.scope.problemReporter().noMoreAvailableSpaceInConstantPool(this.classFile.referenceBinding.scope.referenceType());
/*      */       }
/*  505 */       this.currentIndex += 2;
/*      */ 
/*      */       
/*  508 */       int length = this.offsets.length;
/*  509 */       if (length <= index)
/*      */       {
/*  511 */         System.arraycopy(this.offsets, 0, this.offsets = new int[index * 2], 0, length);
/*      */       }
/*  513 */       this.offsets[index] = this.currentOffset;
/*  514 */       writeU1(6);
/*      */       
/*  516 */       long temp = Double.doubleToLongBits(key);
/*  517 */       length = this.poolContent.length;
/*  518 */       if (this.currentOffset + 8 >= length) {
/*  519 */         resizePoolContents(8);
/*      */       }
/*  521 */       this.poolContent[this.currentOffset++] = (byte)(int)(temp >>> 56L);
/*  522 */       this.poolContent[this.currentOffset++] = (byte)(int)(temp >>> 48L);
/*  523 */       this.poolContent[this.currentOffset++] = (byte)(int)(temp >>> 40L);
/*  524 */       this.poolContent[this.currentOffset++] = (byte)(int)(temp >>> 32L);
/*  525 */       this.poolContent[this.currentOffset++] = (byte)(int)(temp >>> 24L);
/*  526 */       this.poolContent[this.currentOffset++] = (byte)(int)(temp >>> 16L);
/*  527 */       this.poolContent[this.currentOffset++] = (byte)(int)(temp >>> 8L);
/*  528 */       this.poolContent[this.currentOffset++] = (byte)(int)temp;
/*      */     } 
/*  530 */     return index;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int literalIndex(float key) {
/*  545 */     if (this.floatCache == null)
/*  546 */       this.floatCache = new FloatCache(3); 
/*      */     int index;
/*  548 */     if ((index = this.floatCache.putIfAbsent(key, this.currentIndex)) < 0) {
/*  549 */       if ((index = -index) > 65535) {
/*  550 */         this.classFile.referenceBinding.scope.problemReporter().noMoreAvailableSpaceInConstantPool(this.classFile.referenceBinding.scope.referenceType());
/*      */       }
/*  552 */       this.currentIndex++;
/*      */ 
/*      */       
/*  555 */       int length = this.offsets.length;
/*  556 */       if (length <= index)
/*      */       {
/*  558 */         System.arraycopy(this.offsets, 0, this.offsets = new int[index * 2], 0, length);
/*      */       }
/*  560 */       this.offsets[index] = this.currentOffset;
/*  561 */       writeU1(4);
/*      */       
/*  563 */       int temp = Float.floatToIntBits(key);
/*  564 */       if (this.currentOffset + 4 >= this.poolContent.length) {
/*  565 */         resizePoolContents(4);
/*      */       }
/*  567 */       this.poolContent[this.currentOffset++] = (byte)(temp >>> 24);
/*  568 */       this.poolContent[this.currentOffset++] = (byte)(temp >>> 16);
/*  569 */       this.poolContent[this.currentOffset++] = (byte)(temp >>> 8);
/*  570 */       this.poolContent[this.currentOffset++] = (byte)temp;
/*      */     } 
/*  572 */     return index;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int literalIndex(int key) {
/*  587 */     if (this.intCache == null)
/*  588 */       this.intCache = new IntegerCache(248); 
/*      */     int index;
/*  590 */     if ((index = this.intCache.putIfAbsent(key, this.currentIndex)) < 0) {
/*  591 */       this.currentIndex++;
/*  592 */       if ((index = -index) > 65535) {
/*  593 */         this.classFile.referenceBinding.scope.problemReporter().noMoreAvailableSpaceInConstantPool(this.classFile.referenceBinding.scope.referenceType());
/*      */       }
/*      */ 
/*      */       
/*  597 */       int length = this.offsets.length;
/*  598 */       if (length <= index)
/*      */       {
/*  600 */         System.arraycopy(this.offsets, 0, this.offsets = new int[index * 2], 0, length);
/*      */       }
/*  602 */       this.offsets[index] = this.currentOffset;
/*  603 */       writeU1(3);
/*      */       
/*  605 */       if (this.currentOffset + 4 >= this.poolContent.length) {
/*  606 */         resizePoolContents(4);
/*      */       }
/*  608 */       this.poolContent[this.currentOffset++] = (byte)(key >>> 24);
/*  609 */       this.poolContent[this.currentOffset++] = (byte)(key >>> 16);
/*  610 */       this.poolContent[this.currentOffset++] = (byte)(key >>> 8);
/*  611 */       this.poolContent[this.currentOffset++] = (byte)key;
/*      */     } 
/*  613 */     return index;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int literalIndex(long key) {
/*  630 */     if (this.longCache == null)
/*  631 */       this.longCache = new LongCache(5); 
/*      */     int index;
/*  633 */     if ((index = this.longCache.putIfAbsent(key, this.currentIndex)) < 0) {
/*  634 */       if ((index = -index) > 65535) {
/*  635 */         this.classFile.referenceBinding.scope.problemReporter().noMoreAvailableSpaceInConstantPool(this.classFile.referenceBinding.scope.referenceType());
/*      */       }
/*  637 */       this.currentIndex += 2;
/*      */ 
/*      */       
/*  640 */       int length = this.offsets.length;
/*  641 */       if (length <= index)
/*      */       {
/*  643 */         System.arraycopy(this.offsets, 0, this.offsets = new int[index * 2], 0, length);
/*      */       }
/*  645 */       this.offsets[index] = this.currentOffset;
/*  646 */       writeU1(5);
/*      */       
/*  648 */       if (this.currentOffset + 8 >= this.poolContent.length) {
/*  649 */         resizePoolContents(8);
/*      */       }
/*  651 */       this.poolContent[this.currentOffset++] = (byte)(int)(key >>> 56L);
/*  652 */       this.poolContent[this.currentOffset++] = (byte)(int)(key >>> 48L);
/*  653 */       this.poolContent[this.currentOffset++] = (byte)(int)(key >>> 40L);
/*  654 */       this.poolContent[this.currentOffset++] = (byte)(int)(key >>> 32L);
/*  655 */       this.poolContent[this.currentOffset++] = (byte)(int)(key >>> 24L);
/*  656 */       this.poolContent[this.currentOffset++] = (byte)(int)(key >>> 16L);
/*  657 */       this.poolContent[this.currentOffset++] = (byte)(int)(key >>> 8L);
/*  658 */       this.poolContent[this.currentOffset++] = (byte)(int)key;
/*      */     } 
/*  660 */     return index;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int literalIndex(String stringConstant) {
/*  670 */     char[] stringCharArray = stringConstant.toCharArray(); int index;
/*  671 */     if ((index = this.stringCache.putIfAbsent(stringCharArray, this.currentIndex)) < 0) {
/*      */       
/*  673 */       this.currentIndex++;
/*  674 */       if ((index = -index) > 65535) {
/*  675 */         this.classFile.referenceBinding.scope.problemReporter().noMoreAvailableSpaceInConstantPool(this.classFile.referenceBinding.scope.referenceType());
/*      */       }
/*      */       
/*  678 */       int length = this.offsets.length;
/*  679 */       if (length <= index)
/*      */       {
/*  681 */         System.arraycopy(this.offsets, 0, this.offsets = new int[index * 2], 0, length);
/*      */       }
/*  683 */       this.offsets[index] = this.currentOffset;
/*  684 */       writeU1(8);
/*      */       
/*  686 */       int stringIndexOffset = this.currentOffset;
/*  687 */       if (this.currentOffset + 2 >= this.poolContent.length) {
/*  688 */         resizePoolContents(2);
/*      */       }
/*  690 */       this.currentOffset += 2;
/*  691 */       int stringIndex = literalIndex(stringCharArray);
/*  692 */       this.poolContent[stringIndexOffset++] = (byte)(stringIndex >> 8);
/*  693 */       this.poolContent[stringIndexOffset] = (byte)stringIndex;
/*      */     } 
/*  695 */     return index;
/*      */   }
/*      */   public int literalIndexForModule(char[] moduleName) {
/*      */     int index;
/*  699 */     if ((index = this.moduleCache.putIfAbsent(moduleName, this.currentIndex)) < 0) {
/*      */       
/*  701 */       this.currentIndex++;
/*  702 */       if ((index = -index) > 65535) {
/*  703 */         this.classFile.referenceBinding.scope.problemReporter().noMoreAvailableSpaceInConstantPool(this.classFile.referenceBinding.scope.referenceType());
/*      */       }
/*      */       
/*  706 */       int length = this.offsets.length;
/*  707 */       if (length <= index)
/*      */       {
/*  709 */         System.arraycopy(this.offsets, 0, this.offsets = new int[index * 2], 0, length);
/*      */       }
/*  711 */       this.offsets[index] = this.currentOffset;
/*  712 */       writeU1(19);
/*      */       
/*  714 */       int stringIndexOffset = this.currentOffset;
/*  715 */       if (this.currentOffset + 2 >= this.poolContent.length) {
/*  716 */         resizePoolContents(2);
/*      */       }
/*  718 */       this.currentOffset += 2;
/*      */       
/*  720 */       int stringIndex = literalIndex(moduleName);
/*  721 */       this.poolContent[stringIndexOffset++] = (byte)(stringIndex >> 8);
/*  722 */       this.poolContent[stringIndexOffset] = (byte)stringIndex;
/*      */     } 
/*  724 */     return index;
/*      */   }
/*      */   public int literalIndexForPackage(char[] packageName) {
/*      */     int index;
/*  728 */     if ((index = this.packageCache.putIfAbsent(packageName, this.currentIndex)) < 0) {
/*      */       
/*  730 */       this.currentIndex++;
/*  731 */       if ((index = -index) > 65535) {
/*  732 */         this.classFile.referenceBinding.scope.problemReporter().noMoreAvailableSpaceInConstantPool(this.classFile.referenceBinding.scope.referenceType());
/*      */       }
/*      */       
/*  735 */       int length = this.offsets.length;
/*  736 */       if (length <= index)
/*      */       {
/*  738 */         System.arraycopy(this.offsets, 0, this.offsets = new int[index * 2], 0, length);
/*      */       }
/*  740 */       this.offsets[index] = this.currentOffset;
/*  741 */       writeU1(20);
/*      */       
/*  743 */       int stringIndexOffset = this.currentOffset;
/*  744 */       if (this.currentOffset + 2 >= this.poolContent.length) {
/*  745 */         resizePoolContents(2);
/*      */       }
/*  747 */       this.currentOffset += 2;
/*      */       
/*  749 */       int stringIndex = literalIndex(packageName);
/*  750 */       this.poolContent[stringIndexOffset++] = (byte)(stringIndex >> 8);
/*  751 */       this.poolContent[stringIndexOffset] = (byte)stringIndex;
/*      */     } 
/*  753 */     return index;
/*      */   }
/*      */   public int literalIndexForType(char[] constantPoolName) {
/*      */     int index;
/*  757 */     if ((index = this.classCache.putIfAbsent(constantPoolName, this.currentIndex)) < 0) {
/*      */       
/*  759 */       this.currentIndex++;
/*  760 */       if ((index = -index) > 65535) {
/*  761 */         this.classFile.referenceBinding.scope.problemReporter().noMoreAvailableSpaceInConstantPool(this.classFile.referenceBinding.scope.referenceType());
/*      */       }
/*  763 */       int length = this.offsets.length;
/*  764 */       if (length <= index)
/*      */       {
/*  766 */         System.arraycopy(this.offsets, 0, this.offsets = new int[index * 2], 0, length);
/*      */       }
/*  768 */       this.offsets[index] = this.currentOffset;
/*  769 */       writeU1(7);
/*      */ 
/*      */       
/*  772 */       int nameIndexOffset = this.currentOffset;
/*  773 */       if (this.currentOffset + 2 >= this.poolContent.length) {
/*  774 */         resizePoolContents(2);
/*      */       }
/*  776 */       this.currentOffset += 2;
/*  777 */       int nameIndex = literalIndex(constantPoolName);
/*  778 */       this.poolContent[nameIndexOffset++] = (byte)(nameIndex >> 8);
/*  779 */       this.poolContent[nameIndexOffset] = (byte)nameIndex;
/*      */     } 
/*  781 */     return index;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int literalIndexForType(TypeBinding binding) {
/*  789 */     TypeBinding typeBinding = binding.leafComponentType();
/*  790 */     if ((typeBinding.tagBits & 0x800L) != 0L) {
/*  791 */       Util.recordNestedType(this.classFile, typeBinding);
/*      */     }
/*  793 */     return literalIndexForType(binding.constantPoolName());
/*      */   }
/*      */   public int literalIndexForMethod(char[] declaringClass, char[] selector, char[] signature, boolean isInterface) {
/*      */     int index;
/*  797 */     if ((index = putInCacheIfAbsent(declaringClass, selector, signature, this.currentIndex)) < 0) {
/*      */       
/*  799 */       this.currentIndex++;
/*  800 */       if ((index = -index) > 65535) {
/*  801 */         this.classFile.referenceBinding.scope.problemReporter().noMoreAvailableSpaceInConstantPool(this.classFile.referenceBinding.scope.referenceType());
/*      */       }
/*      */ 
/*      */       
/*  805 */       int length = this.offsets.length;
/*  806 */       if (length <= index)
/*      */       {
/*  808 */         System.arraycopy(this.offsets, 0, this.offsets = new int[index * 2], 0, length);
/*      */       }
/*  810 */       this.offsets[index] = this.currentOffset;
/*  811 */       writeU1(isInterface ? 11 : 10);
/*      */       
/*  813 */       int classIndexOffset = this.currentOffset;
/*  814 */       if (this.currentOffset + 4 >= this.poolContent.length) {
/*  815 */         resizePoolContents(4);
/*      */       }
/*  817 */       this.currentOffset += 4;
/*      */       
/*  819 */       int classIndex = literalIndexForType(declaringClass);
/*  820 */       int nameAndTypeIndex = literalIndexForNameAndType(selector, signature);
/*      */       
/*  822 */       this.poolContent[classIndexOffset++] = (byte)(classIndex >> 8);
/*  823 */       this.poolContent[classIndexOffset++] = (byte)classIndex;
/*  824 */       this.poolContent[classIndexOffset++] = (byte)(nameAndTypeIndex >> 8);
/*  825 */       this.poolContent[classIndexOffset] = (byte)nameAndTypeIndex;
/*      */     } 
/*  827 */     return index;
/*      */   }
/*      */   public int literalIndexForMethod(TypeBinding declaringClass, char[] selector, char[] signature, boolean isInterface) {
/*  830 */     if ((declaringClass.tagBits & 0x800L) != 0L) {
/*  831 */       Util.recordNestedType(this.classFile, declaringClass);
/*      */     }
/*  833 */     return literalIndexForMethod(declaringClass.constantPoolName(), selector, signature, isInterface);
/*      */   }
/*      */   public int literalIndexForNameAndType(char[] name, char[] signature) {
/*      */     int index;
/*  837 */     if ((index = putInNameAndTypeCacheIfAbsent(name, signature, this.currentIndex)) < 0) {
/*      */       
/*  839 */       this.currentIndex++;
/*  840 */       if ((index = -index) > 65535) {
/*  841 */         this.classFile.referenceBinding.scope.problemReporter().noMoreAvailableSpaceInConstantPool(this.classFile.referenceBinding.scope.referenceType());
/*      */       }
/*  843 */       int length = this.offsets.length;
/*  844 */       if (length <= index)
/*      */       {
/*  846 */         System.arraycopy(this.offsets, 0, this.offsets = new int[index * 2], 0, length);
/*      */       }
/*  848 */       this.offsets[index] = this.currentOffset;
/*  849 */       writeU1(12);
/*  850 */       int nameIndexOffset = this.currentOffset;
/*  851 */       if (this.currentOffset + 4 >= this.poolContent.length) {
/*  852 */         resizePoolContents(4);
/*      */       }
/*  854 */       this.currentOffset += 4;
/*      */       
/*  856 */       int nameIndex = literalIndex(name);
/*  857 */       int typeIndex = literalIndex(signature);
/*  858 */       this.poolContent[nameIndexOffset++] = (byte)(nameIndex >> 8);
/*  859 */       this.poolContent[nameIndexOffset++] = (byte)nameIndex;
/*  860 */       this.poolContent[nameIndexOffset++] = (byte)(typeIndex >> 8);
/*  861 */       this.poolContent[nameIndexOffset] = (byte)typeIndex;
/*      */     } 
/*  863 */     return index;
/*      */   }
/*      */   public int literalIndexForMethodHandle(MethodBinding binding) {
/*  866 */     boolean isInterface = binding.declaringClass.isInterface();
/*  867 */     int referenceKind = 
/*  868 */       isInterface ? (binding.isStatic() ? 6 : (binding.isPrivate() ? 7 : 9)) : (
/*  869 */       binding.isConstructor() ? 8 : (
/*  870 */       binding.isStatic() ? 6 : (
/*  871 */       binding.isPrivate() ? 7 : 
/*  872 */       5)));
/*      */     
/*  874 */     return literalIndexForMethodHandle(referenceKind, (TypeBinding)binding.declaringClass, binding.selector, binding.signature(), isInterface);
/*      */   }
/*      */   
/*      */   public int literalIndexForMethodHandle(int referenceKind, TypeBinding declaringClass, char[] selector, char[] signature, boolean isInterface) {
/*  878 */     int indexForMethod = literalIndexForMethod(declaringClass, selector, signature, isInterface);
/*      */     
/*  880 */     int index = this.currentIndex++;
/*  881 */     int length = this.offsets.length;
/*  882 */     if (length <= index)
/*      */     {
/*  884 */       System.arraycopy(this.offsets, 0, this.offsets = new int[index * 2], 0, length);
/*      */     }
/*      */     
/*  887 */     this.offsets[index] = this.currentOffset;
/*  888 */     writeU1(15);
/*  889 */     writeU1(referenceKind);
/*  890 */     writeU2(indexForMethod);
/*      */     
/*  892 */     return index;
/*      */   }
/*      */   public int literalIndexForMethodHandleFieldRef(int referenceKind, char[] declaringClass, char[] name, char[] signature) {
/*  895 */     assert referenceKind == 1;
/*  896 */     int indexForField = literalIndexForField(declaringClass, name, signature);
/*      */     
/*  898 */     int index = this.currentIndex++;
/*  899 */     int length = this.offsets.length;
/*  900 */     if (length <= index)
/*      */     {
/*  902 */       System.arraycopy(this.offsets, 0, this.offsets = new int[index * 2], 0, length);
/*      */     }
/*      */     
/*  905 */     this.offsets[index] = this.currentOffset;
/*  906 */     writeU1(15);
/*  907 */     writeU1(referenceKind);
/*  908 */     writeU2(indexForField);
/*      */     
/*  910 */     return index;
/*      */   }
/*      */   public int literalIndexForMethodType(char[] descriptor) {
/*  913 */     int signatureIndex = literalIndex(descriptor);
/*      */     
/*  915 */     int index = this.currentIndex++;
/*      */     
/*  917 */     int length = this.offsets.length;
/*  918 */     if (length <= index)
/*      */     {
/*  920 */       System.arraycopy(this.offsets, 0, this.offsets = new int[index * 2], 0, length);
/*      */     }
/*  922 */     this.offsets[index] = this.currentOffset;
/*  923 */     writeU1(16);
/*  924 */     writeU2(signatureIndex);
/*      */     
/*  926 */     return index;
/*      */   }
/*      */   private int literalIndexForInvokeAndConstantDynamic(int bootStrapIndex, char[] selector, char[] descriptor, int tag) {
/*      */     int index;
/*  930 */     if ((index = putInDynamicCacheIfAbsent(bootStrapIndex, selector, descriptor, this.currentIndex)) < 0) {
/*  931 */       this.currentIndex++;
/*  932 */       if ((index = -index) > 65535) {
/*  933 */         this.classFile.referenceBinding.scope.problemReporter().noMoreAvailableSpaceInConstantPool(this.classFile.referenceBinding.scope.referenceType());
/*      */       }
/*  935 */       int length = this.offsets.length;
/*  936 */       if (length <= index)
/*      */       {
/*  938 */         System.arraycopy(this.offsets, 0, this.offsets = new int[index * 2], 0, length);
/*      */       }
/*  940 */       this.offsets[index] = this.currentOffset;
/*      */       
/*  942 */       writeU1(tag);
/*  943 */       int classIndexOffset = this.currentOffset;
/*  944 */       if (this.currentOffset + 4 >= this.poolContent.length) {
/*  945 */         resizePoolContents(4);
/*      */       }
/*  947 */       this.currentOffset += 4;
/*      */       
/*  949 */       int nameAndTypeIndex = literalIndexForNameAndType(selector, descriptor);
/*      */       
/*  951 */       this.poolContent[classIndexOffset++] = (byte)(bootStrapIndex >> 8);
/*  952 */       this.poolContent[classIndexOffset++] = (byte)bootStrapIndex;
/*  953 */       this.poolContent[classIndexOffset++] = (byte)(nameAndTypeIndex >> 8);
/*  954 */       this.poolContent[classIndexOffset] = (byte)nameAndTypeIndex;
/*      */     } 
/*  956 */     return index;
/*      */   }
/*      */   
/*      */   public int literalIndexForDynamic(int bootStrapIndex, char[] selector, char[] descriptor) {
/*  960 */     return literalIndexForInvokeAndConstantDynamic(bootStrapIndex, selector, descriptor, 17);
/*      */   }
/*      */   public int literalIndexForInvokeDynamic(int bootStrapIndex, char[] selector, char[] descriptor) {
/*  963 */     return literalIndexForInvokeAndConstantDynamic(bootStrapIndex, selector, descriptor, 18);
/*      */   }
/*      */   public int literalIndexForField(char[] declaringClass, char[] name, char[] signature) {
/*      */     int index;
/*  967 */     if ((index = putInCacheIfAbsent(declaringClass, name, signature, this.currentIndex)) < 0) {
/*  968 */       this.currentIndex++;
/*      */       
/*  970 */       if ((index = -index) > 65535) {
/*  971 */         this.classFile.referenceBinding.scope.problemReporter().noMoreAvailableSpaceInConstantPool(this.classFile.referenceBinding.scope.referenceType());
/*      */       }
/*      */ 
/*      */       
/*  975 */       int length = this.offsets.length;
/*  976 */       if (length <= index)
/*      */       {
/*  978 */         System.arraycopy(this.offsets, 0, this.offsets = new int[index * 2], 0, length);
/*      */       }
/*  980 */       this.offsets[index] = this.currentOffset;
/*  981 */       writeU1(9);
/*  982 */       int classIndexOffset = this.currentOffset;
/*  983 */       if (this.currentOffset + 4 >= this.poolContent.length) {
/*  984 */         resizePoolContents(4);
/*      */       }
/*  986 */       this.currentOffset += 4;
/*      */       
/*  988 */       int classIndex = literalIndexForType(declaringClass);
/*  989 */       int nameAndTypeIndex = literalIndexForNameAndType(name, signature);
/*      */       
/*  991 */       this.poolContent[classIndexOffset++] = (byte)(classIndex >> 8);
/*  992 */       this.poolContent[classIndexOffset++] = (byte)classIndex;
/*  993 */       this.poolContent[classIndexOffset++] = (byte)(nameAndTypeIndex >> 8);
/*  994 */       this.poolContent[classIndexOffset] = (byte)nameAndTypeIndex;
/*      */     } 
/*  996 */     return index;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int literalIndexForLdc(char[] stringCharArray) {
/* 1005 */     int savedCurrentIndex = this.currentIndex;
/* 1006 */     int savedCurrentOffset = this.currentOffset;
/*      */     int index;
/* 1008 */     if ((index = this.stringCache.putIfAbsent(stringCharArray, this.currentIndex)) < 0) {
/* 1009 */       if ((index = -index) > 65535) {
/* 1010 */         this.classFile.referenceBinding.scope.problemReporter().noMoreAvailableSpaceInConstantPool(this.classFile.referenceBinding.scope.referenceType());
/*      */       }
/*      */       
/* 1013 */       this.currentIndex++;
/*      */       
/* 1015 */       int length = this.offsets.length;
/* 1016 */       if (length <= index)
/*      */       {
/* 1018 */         System.arraycopy(this.offsets, 0, this.offsets = new int[index * 2], 0, length);
/*      */       }
/* 1020 */       this.offsets[index] = this.currentOffset;
/* 1021 */       writeU1(8);
/*      */ 
/*      */       
/* 1024 */       int stringIndexOffset = this.currentOffset;
/* 1025 */       if (this.currentOffset + 2 >= this.poolContent.length) {
/* 1026 */         resizePoolContents(2);
/*      */       }
/* 1028 */       this.currentOffset += 2;
/*      */       
/*      */       int stringIndex;
/* 1031 */       if ((stringIndex = this.UTF8Cache.putIfAbsent(stringCharArray, this.currentIndex)) < 0) {
/* 1032 */         if ((stringIndex = -stringIndex) > 65535) {
/* 1033 */           this.classFile.referenceBinding.scope.problemReporter().noMoreAvailableSpaceInConstantPool(this.classFile.referenceBinding.scope.referenceType());
/*      */         }
/*      */         
/* 1036 */         this.currentIndex++;
/*      */         
/* 1038 */         length = this.offsets.length;
/* 1039 */         if (length <= stringIndex)
/*      */         {
/* 1041 */           System.arraycopy(this.offsets, 0, this.offsets = new int[stringIndex * 2], 0, length);
/*      */         }
/* 1043 */         this.offsets[stringIndex] = this.currentOffset;
/* 1044 */         writeU1(1);
/*      */         
/* 1046 */         int lengthOffset = this.currentOffset;
/* 1047 */         if (this.currentOffset + 2 >= this.poolContent.length)
/*      */         {
/*      */           
/* 1050 */           resizePoolContents(2);
/*      */         }
/* 1052 */         this.currentOffset += 2;
/* 1053 */         length = 0;
/* 1054 */         for (int i = 0; i < stringCharArray.length; i++) {
/* 1055 */           char current = stringCharArray[i];
/* 1056 */           if (current >= '\001' && current <= '') {
/*      */             
/* 1058 */             length++;
/* 1059 */             if (this.currentOffset + 1 >= this.poolContent.length)
/*      */             {
/*      */               
/* 1062 */               resizePoolContents(1);
/*      */             }
/* 1064 */             this.poolContent[this.currentOffset++] = (byte)current;
/*      */           }
/* 1066 */           else if (current > '߿') {
/*      */             
/* 1068 */             length += 3;
/* 1069 */             if (this.currentOffset + 3 >= this.poolContent.length)
/*      */             {
/*      */               
/* 1072 */               resizePoolContents(3);
/*      */             }
/* 1074 */             this.poolContent[this.currentOffset++] = (byte)(0xE0 | current >> 12 & 0xF);
/* 1075 */             this.poolContent[this.currentOffset++] = (byte)(0x80 | current >> 6 & 0x3F);
/* 1076 */             this.poolContent[this.currentOffset++] = (byte)(0x80 | current & 0x3F);
/*      */           } else {
/* 1078 */             if (this.currentOffset + 2 >= this.poolContent.length)
/*      */             {
/*      */               
/* 1081 */               resizePoolContents(2);
/*      */             }
/*      */ 
/*      */             
/* 1085 */             length += 2;
/* 1086 */             this.poolContent[this.currentOffset++] = (byte)(0xC0 | current >> 6 & 0x1F);
/* 1087 */             this.poolContent[this.currentOffset++] = (byte)(0x80 | current & 0x3F);
/*      */           } 
/*      */         } 
/* 1090 */         if (length >= 65535) {
/* 1091 */           this.currentOffset = savedCurrentOffset;
/* 1092 */           this.currentIndex = savedCurrentIndex;
/* 1093 */           this.stringCache.remove(stringCharArray);
/* 1094 */           this.UTF8Cache.remove(stringCharArray);
/* 1095 */           return 0;
/*      */         } 
/* 1097 */         this.poolContent[lengthOffset++] = (byte)(length >> 8);
/* 1098 */         this.poolContent[lengthOffset] = (byte)length;
/*      */       } 
/* 1100 */       this.poolContent[stringIndexOffset++] = (byte)(stringIndex >> 8);
/* 1101 */       this.poolContent[stringIndexOffset] = (byte)stringIndex;
/*      */     } 
/* 1103 */     return index;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private int putInNameAndTypeCacheIfAbsent(char[] key1, char[] key2, int value) {
/*      */     int index;
/* 1113 */     Object key1Value = this.nameAndTypeCacheForFieldsAndMethods.get(key1);
/* 1114 */     if (key1Value == null) {
/* 1115 */       CachedIndexEntry cachedIndexEntry = new CachedIndexEntry(key2, value);
/* 1116 */       index = -value;
/* 1117 */       this.nameAndTypeCacheForFieldsAndMethods.put(key1, cachedIndexEntry);
/* 1118 */     } else if (key1Value instanceof CachedIndexEntry) {
/*      */       
/* 1120 */       CachedIndexEntry entry = (CachedIndexEntry)key1Value;
/* 1121 */       if (CharOperation.equals(key2, entry.signature)) {
/* 1122 */         index = entry.index;
/*      */       } else {
/* 1124 */         CharArrayCache charArrayCache = new CharArrayCache();
/* 1125 */         charArrayCache.putIfAbsent(entry.signature, entry.index);
/* 1126 */         index = charArrayCache.putIfAbsent(key2, value);
/* 1127 */         this.nameAndTypeCacheForFieldsAndMethods.put(key1, charArrayCache);
/*      */       } 
/*      */     } else {
/* 1130 */       CharArrayCache charArrayCache = (CharArrayCache)key1Value;
/* 1131 */       index = charArrayCache.putIfAbsent(key2, value);
/*      */     } 
/* 1133 */     return index;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private int putInDynamicCacheIfAbsent(int bootstrapIndex, char[] selector, char[] descriptor, int value) {
/*      */     int index;
/* 1144 */     HashtableOfObject key1Value = (HashtableOfObject)this.dynamicCache.get(bootstrapIndex);
/* 1145 */     if (key1Value == null) {
/* 1146 */       key1Value = new HashtableOfObject();
/* 1147 */       this.dynamicCache.put(bootstrapIndex, key1Value);
/* 1148 */       CachedIndexEntry cachedIndexEntry = new CachedIndexEntry(descriptor, value);
/* 1149 */       index = -value;
/* 1150 */       key1Value.put(selector, cachedIndexEntry);
/*      */     } else {
/* 1152 */       Object key2Value = key1Value.get(selector);
/* 1153 */       if (key2Value == null) {
/* 1154 */         CachedIndexEntry cachedIndexEntry = new CachedIndexEntry(descriptor, value);
/* 1155 */         index = -value;
/* 1156 */         key1Value.put(selector, cachedIndexEntry);
/* 1157 */       } else if (key2Value instanceof CachedIndexEntry) {
/*      */         
/* 1159 */         CachedIndexEntry entry = (CachedIndexEntry)key2Value;
/* 1160 */         if (CharOperation.equals(descriptor, entry.signature)) {
/* 1161 */           index = entry.index;
/*      */         } else {
/* 1163 */           CharArrayCache charArrayCache = new CharArrayCache();
/* 1164 */           charArrayCache.putIfAbsent(entry.signature, entry.index);
/* 1165 */           index = charArrayCache.putIfAbsent(descriptor, value);
/* 1166 */           key1Value.put(selector, charArrayCache);
/*      */         } 
/*      */       } else {
/* 1169 */         CharArrayCache charArrayCache = (CharArrayCache)key2Value;
/* 1170 */         index = charArrayCache.putIfAbsent(descriptor, value);
/*      */       } 
/*      */     } 
/* 1173 */     return index;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private int putInCacheIfAbsent(char[] key1, char[] key2, char[] key3, int value) {
/*      */     int index;
/* 1185 */     HashtableOfObject key1Value = (HashtableOfObject)this.methodsAndFieldsCache.get(key1);
/* 1186 */     if (key1Value == null) {
/* 1187 */       key1Value = new HashtableOfObject();
/* 1188 */       this.methodsAndFieldsCache.put(key1, key1Value);
/* 1189 */       CachedIndexEntry cachedIndexEntry = new CachedIndexEntry(key3, value);
/* 1190 */       index = -value;
/* 1191 */       key1Value.put(key2, cachedIndexEntry);
/*      */     } else {
/* 1193 */       Object key2Value = key1Value.get(key2);
/* 1194 */       if (key2Value == null) {
/* 1195 */         CachedIndexEntry cachedIndexEntry = new CachedIndexEntry(key3, value);
/* 1196 */         index = -value;
/* 1197 */         key1Value.put(key2, cachedIndexEntry);
/* 1198 */       } else if (key2Value instanceof CachedIndexEntry) {
/*      */         
/* 1200 */         CachedIndexEntry entry = (CachedIndexEntry)key2Value;
/* 1201 */         if (CharOperation.equals(key3, entry.signature)) {
/* 1202 */           index = entry.index;
/*      */         } else {
/* 1204 */           CharArrayCache charArrayCache = new CharArrayCache();
/* 1205 */           charArrayCache.putIfAbsent(entry.signature, entry.index);
/* 1206 */           index = charArrayCache.putIfAbsent(key3, value);
/* 1207 */           key1Value.put(key2, charArrayCache);
/*      */         } 
/*      */       } else {
/* 1210 */         CharArrayCache charArrayCache = (CharArrayCache)key2Value;
/* 1211 */         index = charArrayCache.putIfAbsent(key3, value);
/*      */       } 
/*      */     } 
/* 1214 */     return index;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void resetForClinit(int constantPoolIndex, int constantPoolOffset) {
/* 1223 */     this.currentIndex = constantPoolIndex;
/* 1224 */     this.currentOffset = constantPoolOffset;
/* 1225 */     if (this.UTF8Cache.get(AttributeNamesConstants.CodeName) >= constantPoolIndex) {
/* 1226 */       this.UTF8Cache.remove(AttributeNamesConstants.CodeName);
/*      */     }
/* 1228 */     if (this.UTF8Cache.get(ClinitSignature) >= constantPoolIndex) {
/* 1229 */       this.UTF8Cache.remove(ClinitSignature);
/*      */     }
/* 1231 */     if (this.UTF8Cache.get(Clinit) >= constantPoolIndex) {
/* 1232 */       this.UTF8Cache.remove(Clinit);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final void resizePoolContents(int minimalSize) {
/* 1240 */     int length = this.poolContent.length;
/* 1241 */     int toAdd = length;
/* 1242 */     if (toAdd < minimalSize)
/* 1243 */       toAdd = minimalSize; 
/* 1244 */     System.arraycopy(this.poolContent, 0, this.poolContent = new byte[length + toAdd], 0, length);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final void writeU1(int value) {
/* 1252 */     if (this.currentOffset + 1 >= this.poolContent.length) {
/* 1253 */       resizePoolContents(1);
/*      */     }
/* 1255 */     this.poolContent[this.currentOffset++] = (byte)value;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final void writeU2(int value) {
/* 1263 */     if (this.currentOffset + 2 >= this.poolContent.length) {
/* 1264 */       resizePoolContents(2);
/*      */     }
/* 1266 */     this.poolContent[this.currentOffset++] = (byte)(value >>> 8);
/* 1267 */     this.poolContent[this.currentOffset++] = (byte)value;
/*      */   }
/*      */   public void reset() {
/* 1270 */     if (this.doubleCache != null) this.doubleCache.clear(); 
/* 1271 */     if (this.floatCache != null) this.floatCache.clear(); 
/* 1272 */     if (this.intCache != null) this.intCache.clear(); 
/* 1273 */     if (this.longCache != null) this.longCache.clear(); 
/* 1274 */     this.UTF8Cache.clear();
/* 1275 */     this.stringCache.clear();
/* 1276 */     this.methodsAndFieldsCache.clear();
/* 1277 */     this.classCache.clear();
/* 1278 */     this.packageCache.clear();
/* 1279 */     this.moduleCache.clear();
/* 1280 */     this.nameAndTypeCacheForFieldsAndMethods.clear();
/* 1281 */     this.dynamicCache.clear();
/* 1282 */     this.currentIndex = 1;
/* 1283 */     this.currentOffset = 0;
/*      */   }
/*      */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\codegen\ConstantPool.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */