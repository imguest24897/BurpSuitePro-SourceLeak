/*    */ package org.eclipse.jdt.internal.compiler.ast;
/*    */ 
/*    */ import org.eclipse.jdt.internal.compiler.ASTVisitor;
/*    */ import org.eclipse.jdt.internal.compiler.lookup.Binding;
/*    */ import org.eclipse.jdt.internal.compiler.lookup.BlockScope;
/*    */ import org.eclipse.jdt.internal.compiler.lookup.ClassScope;
/*    */ import org.eclipse.jdt.internal.compiler.lookup.LocalVariableBinding;
/*    */ import org.eclipse.jdt.internal.compiler.lookup.MethodScope;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class JavadocSingleNameReference
/*    */   extends SingleNameReference
/*    */ {
/*    */   public int tagSourceStart;
/*    */   public int tagSourceEnd;
/*    */   
/*    */   public JavadocSingleNameReference(char[] source, long pos, int tagStart, int tagEnd) {
/* 24 */     super(source, pos);
/* 25 */     this.tagSourceStart = tagStart;
/* 26 */     this.tagSourceEnd = tagEnd;
/* 27 */     this.bits |= 0x8000;
/*    */   }
/*    */ 
/*    */   
/*    */   public void resolve(BlockScope scope) {
/* 32 */     resolve(scope, true, (scope.compilerOptions()).reportUnusedParameterIncludeDocCommentReference);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void resolve(BlockScope scope, boolean warn, boolean considerParamRefAsUsage) {
/* 40 */     LocalVariableBinding variableBinding = scope.findVariable(this.token, this);
/* 41 */     if (variableBinding != null && variableBinding.isValidBinding() && (variableBinding.tagBits & 0x400L) != 0L) {
/* 42 */       this.binding = (Binding)variableBinding;
/* 43 */       if (considerParamRefAsUsage) {
/* 44 */         variableBinding.useFlag = 1;
/*    */       }
/*    */       return;
/*    */     } 
/* 48 */     if (warn) {
/*    */       try {
/* 50 */         MethodScope methScope = (MethodScope)scope;
/* 51 */         scope.problemReporter().javadocUndeclaredParamTagName(this.token, this.sourceStart, this.sourceEnd, (methScope.referenceMethod()).modifiers);
/*    */       }
/* 53 */       catch (Exception exception) {
/* 54 */         scope.problemReporter().javadocUndeclaredParamTagName(this.token, this.sourceStart, this.sourceEnd, -1);
/*    */       } 
/*    */     }
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void traverse(ASTVisitor visitor, BlockScope scope) {
/* 65 */     visitor.visit(this, scope);
/* 66 */     visitor.endVisit(this, scope);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void traverse(ASTVisitor visitor, ClassScope scope) {
/* 74 */     visitor.visit(this, scope);
/* 75 */     visitor.endVisit(this, scope);
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\ast\JavadocSingleNameReference.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */