/*     */ package org.eclipse.jdt.internal.compiler.classfmt;
/*     */ 
/*     */ import java.io.PrintStream;
/*     */ import java.io.PrintWriter;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ClassFormatException
/*     */   extends Exception
/*     */ {
/*     */   public static final int ErrBadMagic = 1;
/*     */   public static final int ErrBadMinorVersion = 2;
/*     */   public static final int ErrBadMajorVersion = 3;
/*     */   public static final int ErrBadConstantClass = 4;
/*     */   public static final int ErrBadConstantString = 5;
/*     */   public static final int ErrBadConstantNameAndType = 6;
/*     */   public static final int ErrBadConstantFieldRef = 7;
/*     */   public static final int ErrBadConstantMethodRef = 8;
/*     */   public static final int ErrBadConstantInterfaceMethodRef = 9;
/*     */   public static final int ErrBadConstantPoolIndex = 10;
/*     */   public static final int ErrBadSuperclassName = 11;
/*     */   public static final int ErrInterfaceCannotBeFinal = 12;
/*     */   public static final int ErrInterfaceMustBeAbstract = 13;
/*     */   public static final int ErrBadModifiers = 14;
/*     */   public static final int ErrClassCannotBeAbstractFinal = 15;
/*     */   public static final int ErrBadClassname = 16;
/*     */   public static final int ErrBadFieldInfo = 17;
/*     */   public static final int ErrBadMethodInfo = 17;
/*     */   public static final int ErrEmptyConstantPool = 18;
/*     */   public static final int ErrMalformedUtf8 = 19;
/*     */   public static final int ErrUnknownConstantTag = 20;
/*     */   public static final int ErrTruncatedInput = 21;
/*     */   public static final int ErrMethodMustBeAbstract = 22;
/*     */   public static final int ErrMalformedAttribute = 23;
/*     */   public static final int ErrBadInterface = 24;
/*     */   public static final int ErrInterfaceMustSubclassObject = 25;
/*     */   public static final int ErrIncorrectInterfaceMethods = 26;
/*     */   public static final int ErrInvalidMethodName = 27;
/*     */   public static final int ErrInvalidMethodSignature = 28;
/*     */   public static final int ErrBadComponentInfo = 29;
/*     */   private static final long serialVersionUID = 6667458511042774540L;
/*     */   private int errorCode;
/*     */   private int bufferPosition;
/*     */   private Exception nestedException;
/*     */   private char[] fileName;
/*     */   
/*     */   public ClassFormatException(RuntimeException e, char[] fileName) {
/*  58 */     this.nestedException = e;
/*  59 */     this.fileName = fileName;
/*     */   }
/*     */   public ClassFormatException(int code) {
/*  62 */     this.errorCode = code;
/*     */   }
/*     */   public ClassFormatException(Exception e, char[] fileName, int code, int bufPos) {
/*  65 */     this.nestedException = e;
/*  66 */     this.fileName = fileName;
/*  67 */     this.errorCode = code;
/*  68 */     this.bufferPosition = bufPos;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int getErrorCode() {
/*  74 */     return this.errorCode;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int getBufferPosition() {
/*  80 */     return this.bufferPosition;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Throwable getException() {
/*  89 */     return this.nestedException;
/*     */   }
/*     */   
/*     */   public void printStackTrace() {
/*  93 */     printStackTrace(System.err);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void printStackTrace(PrintStream output) {
/* 104 */     synchronized (output) {
/* 105 */       super.printStackTrace(output);
/* 106 */       Throwable throwable = getException();
/* 107 */       if (throwable != null) {
/* 108 */         if (this.fileName != null) {
/* 109 */           output.print("Caused in ");
/* 110 */           output.print(this.fileName);
/* 111 */           output.print(" by: ");
/*     */         } else {
/* 113 */           output.print("Caused by: ");
/*     */         } 
/* 115 */         throwable.printStackTrace(output);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void printStackTrace(PrintWriter output) {
/* 128 */     synchronized (output) {
/* 129 */       super.printStackTrace(output);
/* 130 */       Throwable throwable = getException();
/* 131 */       if (throwable != null) {
/* 132 */         if (this.fileName != null) {
/* 133 */           output.print("Caused in ");
/* 134 */           output.print(this.fileName);
/* 135 */           output.print(" by: ");
/*     */         } else {
/* 137 */           output.print("Caused by: ");
/*     */         } 
/* 139 */         throwable.printStackTrace(output);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\classfmt\ClassFormatException.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */