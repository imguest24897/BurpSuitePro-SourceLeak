/*    */ package org.eclipse.jdt.internal.compiler.ast;
/*    */ 
/*    */ import org.eclipse.jdt.internal.compiler.ASTVisitor;
/*    */ import org.eclipse.jdt.internal.compiler.codegen.CodeStream;
/*    */ import org.eclipse.jdt.internal.compiler.flow.FlowContext;
/*    */ import org.eclipse.jdt.internal.compiler.flow.FlowInfo;
/*    */ import org.eclipse.jdt.internal.compiler.impl.Constant;
/*    */ import org.eclipse.jdt.internal.compiler.lookup.BlockScope;
/*    */ import org.eclipse.jdt.internal.compiler.lookup.TypeBinding;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NullLiteral
/*    */   extends MagicLiteral
/*    */ {
/* 27 */   static final char[] source = new char[] { 'n', 'u', 'l', 'l' };
/*    */ 
/*    */   
/*    */   public NullLiteral(int s, int e) {
/* 31 */     super(s, e);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void computeConstant() {
/* 37 */     this.constant = Constant.NotAConstant;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void generateCode(BlockScope currentScope, CodeStream codeStream, boolean valueRequired) {
/* 49 */     int pc = codeStream.position;
/* 50 */     if (valueRequired) {
/* 51 */       codeStream.aconst_null();
/* 52 */       codeStream.generateImplicitConversion(this.implicitConversion);
/*    */     } 
/* 54 */     codeStream.recordPositionsFrom(pc, this.sourceStart);
/*    */   }
/*    */   
/*    */   public TypeBinding literalType(BlockScope scope) {
/* 58 */     return (TypeBinding)TypeBinding.NULL;
/*    */   }
/*    */ 
/*    */   
/*    */   public int nullStatus(FlowInfo flowInfo, FlowContext flowContext) {
/* 63 */     return 2;
/*    */   }
/*    */ 
/*    */   
/*    */   public Object reusableJSRTarget() {
/* 68 */     return TypeBinding.NULL;
/*    */   }
/*    */ 
/*    */   
/*    */   public char[] source() {
/* 73 */     return source;
/*    */   }
/*    */ 
/*    */   
/*    */   public void traverse(ASTVisitor visitor, BlockScope scope) {
/* 78 */     visitor.visit(this, scope);
/* 79 */     visitor.endVisit(this, scope);
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\ast\NullLiteral.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */