/*     */ package org.eclipse.jdt.internal.compiler.impl;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class IntConstant
/*     */   extends Constant
/*     */ {
/*     */   int value;
/*  20 */   private static final IntConstant MIN_VALUE = new IntConstant(-2147483648);
/*  21 */   private static final IntConstant MINUS_FOUR = new IntConstant(-4);
/*  22 */   private static final IntConstant MINUS_THREE = new IntConstant(-3);
/*  23 */   private static final IntConstant MINUS_TWO = new IntConstant(-2);
/*  24 */   private static final IntConstant MINUS_ONE = new IntConstant(-1);
/*  25 */   private static final IntConstant ZERO = new IntConstant(0);
/*  26 */   private static final IntConstant ONE = new IntConstant(1);
/*  27 */   private static final IntConstant TWO = new IntConstant(2);
/*  28 */   private static final IntConstant THREE = new IntConstant(3);
/*  29 */   private static final IntConstant FOUR = new IntConstant(4);
/*  30 */   private static final IntConstant FIVE = new IntConstant(5);
/*  31 */   private static final IntConstant SIX = new IntConstant(6);
/*  32 */   private static final IntConstant SEVEN = new IntConstant(7);
/*  33 */   private static final IntConstant EIGHT = new IntConstant(8);
/*  34 */   private static final IntConstant NINE = new IntConstant(9);
/*  35 */   private static final IntConstant TEN = new IntConstant(10);
/*     */   
/*     */   public static Constant fromValue(int value) {
/*  38 */     switch (value) { case -2147483648:
/*  39 */         return MIN_VALUE;
/*  40 */       case -4: return MINUS_FOUR;
/*  41 */       case -3: return MINUS_THREE;
/*  42 */       case -2: return MINUS_TWO;
/*  43 */       case -1: return MINUS_ONE;
/*  44 */       case 0: return ZERO;
/*  45 */       case 1: return ONE;
/*  46 */       case 2: return TWO;
/*  47 */       case 3: return THREE;
/*  48 */       case 4: return FOUR;
/*  49 */       case 5: return FIVE;
/*  50 */       case 6: return SIX;
/*  51 */       case 7: return SEVEN;
/*  52 */       case 8: return EIGHT;
/*  53 */       case 9: return NINE;
/*  54 */       case 10: return TEN; }
/*     */     
/*  56 */     return new IntConstant(value);
/*     */   }
/*     */   
/*     */   private IntConstant(int value) {
/*  60 */     this.value = value;
/*     */   }
/*     */ 
/*     */   
/*     */   public byte byteValue() {
/*  65 */     return (byte)this.value;
/*     */   }
/*     */ 
/*     */   
/*     */   public char charValue() {
/*  70 */     return (char)this.value;
/*     */   }
/*     */ 
/*     */   
/*     */   public double doubleValue() {
/*  75 */     return this.value;
/*     */   }
/*     */ 
/*     */   
/*     */   public float floatValue() {
/*  80 */     return this.value;
/*     */   }
/*     */ 
/*     */   
/*     */   public int intValue() {
/*  85 */     return this.value;
/*     */   }
/*     */ 
/*     */   
/*     */   public long longValue() {
/*  90 */     return this.value;
/*     */   }
/*     */ 
/*     */   
/*     */   public short shortValue() {
/*  95 */     return (short)this.value;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String stringValue() {
/* 101 */     return String.valueOf(this.value);
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 106 */     return "(int)" + this.value;
/*     */   }
/*     */ 
/*     */   
/*     */   public int typeID() {
/* 111 */     return 10;
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 116 */     return this.value;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object obj) {
/* 121 */     if (this == obj) {
/* 122 */       return true;
/*     */     }
/* 124 */     if (obj == null) {
/* 125 */       return false;
/*     */     }
/* 127 */     if (getClass() != obj.getClass()) {
/* 128 */       return false;
/*     */     }
/* 130 */     IntConstant other = (IntConstant)obj;
/* 131 */     return (this.value == other.value);
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\impl\IntConstant.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */