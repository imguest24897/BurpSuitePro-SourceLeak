/*    */ package org.eclipse.jdt.internal.compiler.ast;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class UsesStatement
/*    */   extends ModuleStatement
/*    */ {
/*    */   public TypeReference serviceInterface;
/*    */   
/*    */   public UsesStatement(TypeReference serviceInterface) {
/* 21 */     this.serviceInterface = serviceInterface;
/*    */   }
/*    */   
/*    */   public StringBuffer print(int indent, StringBuffer output) {
/* 25 */     printIndent(indent, output);
/* 26 */     output.append("uses ");
/* 27 */     this.serviceInterface.print(0, output);
/* 28 */     output.append(";");
/* 29 */     return output;
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\ast\UsesStatement.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */