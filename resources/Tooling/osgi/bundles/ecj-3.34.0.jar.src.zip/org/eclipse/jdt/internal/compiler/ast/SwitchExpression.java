/*     */ package org.eclipse.jdt.internal.compiler.ast;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.EmptyStackException;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.Stack;
/*     */ import java.util.stream.Collectors;
/*     */ import org.eclipse.jdt.core.compiler.CharOperation;
/*     */ import org.eclipse.jdt.internal.compiler.ASTVisitor;
/*     */ import org.eclipse.jdt.internal.compiler.codegen.CodeStream;
/*     */ import org.eclipse.jdt.internal.compiler.flow.FlowContext;
/*     */ import org.eclipse.jdt.internal.compiler.flow.FlowInfo;
/*     */ import org.eclipse.jdt.internal.compiler.impl.CompilerOptions;
/*     */ import org.eclipse.jdt.internal.compiler.impl.Constant;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.BlockScope;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.FieldBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.LocalVariableBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.LookupEnvironment;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.MethodBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.PolyTypeBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.Scope;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.TypeBinding;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SwitchExpression
/*     */   extends SwitchStatement
/*     */   implements IPolyExpression
/*     */ {
/*     */   TypeBinding expectedType;
/*  52 */   private ExpressionContext expressionContext = ExpressionContext.VANILLA_CONTEXT;
/*     */   
/*     */   private boolean isPolyExpression = false;
/*     */   
/*     */   private TypeBinding[] originalValueResultExpressionTypes;
/*     */   private TypeBinding[] finalValueResultExpressionTypes;
/*     */   Map<Expression, TypeBinding> originalTypeMap;
/*  59 */   private int nullStatus = 1;
/*     */   public List<Expression> resultExpressions;
/*     */   public boolean resolveAll;
/*     */   List<Integer> resultExpressionNullStatus;
/*     */   LocalVariableBinding hiddenYield;
/*  64 */   int hiddenYieldResolvedPosition = -1;
/*     */   public boolean containsTry = false;
/*     */   private static Map<TypeBinding, TypeBinding[]> type_map;
/*  67 */   static final char[] SECRET_YIELD_VALUE_NAME = " yieldValue".toCharArray();
/*  68 */   int yieldResolvedPosition = -1;
/*     */   List<LocalVariableBinding> typesOnStack;
/*     */   
/*     */   static {
/*  72 */     type_map = (Map)new HashMap<>();
/*  73 */     type_map.put(TypeBinding.CHAR, new TypeBinding[] { (TypeBinding)TypeBinding.CHAR, (TypeBinding)TypeBinding.INT });
/*  74 */     type_map.put(TypeBinding.SHORT, new TypeBinding[] { (TypeBinding)TypeBinding.SHORT, (TypeBinding)TypeBinding.BYTE, (TypeBinding)TypeBinding.INT });
/*  75 */     type_map.put(TypeBinding.BYTE, new TypeBinding[] { (TypeBinding)TypeBinding.BYTE, (TypeBinding)TypeBinding.INT });
/*     */   }
/*     */ 
/*     */   
/*     */   public void setExpressionContext(ExpressionContext context) {
/*  80 */     this.expressionContext = context;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setExpectedType(TypeBinding expectedType) {
/*  85 */     this.expectedType = expectedType;
/*     */   }
/*     */ 
/*     */   
/*     */   public ExpressionContext getExpressionContext() {
/*  90 */     return this.expressionContext;
/*     */   }
/*     */   
/*     */   protected boolean ignoreMissingDefaultCase(CompilerOptions compilerOptions, boolean isEnumSwitch) {
/*  94 */     return isEnumSwitch;
/*     */   }
/*     */   
/*     */   protected void reportMissingEnumConstantCase(BlockScope upperScope, FieldBinding enumConstant) {
/*  98 */     upperScope.problemReporter().missingEnumConstantCase(this, enumConstant);
/*     */   }
/*     */   
/*     */   protected int getFallThroughState(Statement stmt, BlockScope blockScope) {
/* 102 */     if ((stmt instanceof Expression && ((Expression)stmt).isTrulyExpression()) || stmt instanceof ThrowStatement)
/* 103 */       return 3; 
/* 104 */     if ((this.switchBits & 0x1) != 0 && 
/* 105 */       stmt instanceof Block) {
/* 106 */       Block block = (Block)stmt;
/* 107 */       if (!block.canCompleteNormally()) {
/* 108 */         return 3;
/*     */       }
/*     */     } 
/* 111 */     return 1;
/*     */   }
/*     */   
/*     */   public boolean checkNPE(BlockScope skope, FlowContext flowContext, FlowInfo flowInfo, int ttlForFieldCheck) {
/* 115 */     if ((this.nullStatus & 0x2) != 0) {
/* 116 */       skope.problemReporter().expressionNullReference(this);
/* 117 */     } else if ((this.nullStatus & 0x10) != 0) {
/* 118 */       skope.problemReporter().expressionPotentialNullReference(this);
/* 119 */     }  return true;
/*     */   }
/*     */   private void computeNullStatus(FlowInfo flowInfo, FlowContext flowContext) {
/*     */     int j;
/* 123 */     boolean precomputed = (this.resultExpressionNullStatus.size() > 0);
/* 124 */     if (!precomputed)
/* 125 */       this.resultExpressionNullStatus.add(Integer.valueOf(((Expression)this.resultExpressions.get(0)).nullStatus(flowInfo, flowContext)));  int status = ((Expression)this.resultExpressions.get(0)).nullStatus(flowInfo, flowContext);
/* 126 */     int combinedStatus = status;
/* 127 */     boolean identicalStatus = true;
/* 128 */     for (int i = 1, l = this.resultExpressions.size(); i < l; i++) {
/* 129 */       if (!precomputed)
/* 130 */         this.resultExpressionNullStatus.add(Integer.valueOf(((Expression)this.resultExpressions.get(i)).nullStatus(flowInfo, flowContext))); 
/* 131 */       int tmp = ((Expression)this.resultExpressions.get(i)).nullStatus(flowInfo, flowContext);
/* 132 */       j = identicalStatus & ((status == tmp) ? 1 : 0);
/* 133 */       combinedStatus |= tmp;
/*     */     } 
/* 135 */     if (j != 0) {
/* 136 */       this.nullStatus = status;
/*     */       return;
/*     */     } 
/* 139 */     status = Expression.computeNullStatus(0, combinedStatus);
/* 140 */     if (status > 0) {
/* 141 */       this.nullStatus = status;
/*     */     }
/*     */   }
/*     */   
/*     */   protected void completeNormallyCheck(BlockScope blockScope) {
/* 146 */     int sz = (this.statements != null) ? this.statements.length : 0;
/* 147 */     if (sz == 0) {
/*     */       return;
/*     */     }
/*     */     
/* 151 */     if ((this.switchBits & 0x1) != 0) {
/* 152 */       byte b; int j; Statement[] arrayOfStatement; for (j = (arrayOfStatement = this.statements).length, b = 0; b < j; ) { Statement stmt = arrayOfStatement[b];
/* 153 */         if (stmt instanceof Block)
/*     */         {
/* 155 */           if (stmt.canCompleteNormally()) {
/* 156 */             blockScope.problemReporter().switchExpressionLastStatementCompletesNormally(stmt);
/*     */           }
/*     */         }
/*     */         
/*     */         b++; }
/*     */ 
/*     */       
/*     */       return;
/*     */     } 
/* 165 */     Statement lastNonCaseStmt = null;
/* 166 */     Statement firstTrailingCaseStmt = null;
/* 167 */     for (int i = sz - 1; i >= 0; i--) {
/* 168 */       Statement stmt = this.statements[sz - 1];
/* 169 */       if (stmt instanceof CaseStatement) {
/* 170 */         firstTrailingCaseStmt = stmt;
/*     */       } else {
/* 172 */         lastNonCaseStmt = stmt;
/*     */         break;
/*     */       } 
/*     */     } 
/* 176 */     if (lastNonCaseStmt != null) {
/* 177 */       if (lastNonCaseStmt.canCompleteNormally()) {
/* 178 */         blockScope.problemReporter().switchExpressionLastStatementCompletesNormally(lastNonCaseStmt);
/* 179 */       } else if (lastNonCaseStmt instanceof ContinueStatement || lastNonCaseStmt instanceof ReturnStatement) {
/* 180 */         blockScope.problemReporter().switchExpressionIllegalLastStatement(lastNonCaseStmt);
/*     */       } 
/*     */     }
/* 183 */     if (firstTrailingCaseStmt != null) {
/* 184 */       blockScope.problemReporter().switchExpressionTrailingSwitchLabels(firstTrailingCaseStmt);
/*     */     }
/*     */   }
/*     */   
/*     */   protected boolean needToCheckFlowInAbsenceOfDefaultBranch() {
/* 189 */     return ((this.switchBits & 0x1) == 0);
/*     */   }
/*     */   
/*     */   public Expression[] getPolyExpressions() {
/* 193 */     List<Expression> polys = new ArrayList<>();
/* 194 */     for (Expression e : this.resultExpressions) {
/* 195 */       Expression[] ea = e.getPolyExpressions();
/* 196 */       if (ea == null || ea.length == 0)
/* 197 */         continue;  polys.addAll(Arrays.asList(ea));
/*     */     } 
/* 199 */     return polys.<Expression>toArray(new Expression[0]);
/*     */   }
/*     */   
/*     */   public boolean isPertinentToApplicability(TypeBinding targetType, MethodBinding method) {
/* 203 */     for (Expression e : this.resultExpressions) {
/* 204 */       if (!e.isPertinentToApplicability(targetType, method))
/* 205 */         return false; 
/*     */     } 
/* 207 */     return true;
/*     */   }
/*     */   
/*     */   public boolean isPotentiallyCompatibleWith(TypeBinding targetType, Scope scope1) {
/* 211 */     for (Expression e : this.resultExpressions) {
/* 212 */       if (!e.isPotentiallyCompatibleWith(targetType, scope1))
/* 213 */         return false; 
/*     */     } 
/* 215 */     return true;
/*     */   }
/*     */   
/*     */   public boolean isFunctionalType() {
/* 219 */     for (Expression e : this.resultExpressions) {
/* 220 */       if (e.isFunctionalType())
/* 221 */         return true; 
/*     */     } 
/* 223 */     return false;
/*     */   }
/*     */   
/*     */   public int nullStatus(FlowInfo flowInfo, FlowContext flowContext) {
/* 227 */     if ((this.implicitConversion & 0x200) != 0)
/* 228 */       return 4; 
/* 229 */     return this.nullStatus;
/*     */   }
/*     */   
/*     */   protected void statementGenerateCode(BlockScope currentScope, CodeStream codeStream, Statement statement) {
/* 233 */     if (!(statement instanceof Expression) || !((Expression)statement).isTrulyExpression() || 
/* 234 */       statement instanceof Assignment || 
/* 235 */       statement instanceof MessageSend || (
/* 236 */       statement instanceof SwitchStatement && !(statement instanceof SwitchExpression))) {
/* 237 */       super.statementGenerateCode(currentScope, codeStream, statement);
/*     */       return;
/*     */     } 
/* 240 */     Expression expression1 = (Expression)statement;
/* 241 */     expression1.generateCode(currentScope, codeStream, true);
/*     */   }
/*     */   private TypeBinding createType(int typeId) {
/* 244 */     TypeBinding type = TypeBinding.wellKnownType((Scope)this.scope, typeId);
/* 245 */     return (type != null) ? type : (TypeBinding)this.scope.getJavaLangObject();
/*     */   }
/*     */   private LocalVariableBinding addTypeStackVariable(CodeStream codeStream, TypeBinding type, int typeId, int index, int resolvedPosition) {
/* 248 */     char[] name = CharOperation.concat(SECRET_YIELD_VALUE_NAME, String.valueOf(index).toCharArray());
/* 249 */     type = (type != null) ? type : createType(typeId);
/* 250 */     LocalVariableBinding lvb = 
/* 251 */       new LocalVariableBinding(
/* 252 */         name, 
/* 253 */         type, 
/* 254 */         0, 
/* 255 */         false);
/* 256 */     lvb.setConstant(Constant.NotAConstant);
/* 257 */     lvb.useFlag = 1;
/* 258 */     lvb.resolvedPosition = resolvedPosition;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 264 */     this.scope.addLocalVariable(lvb);
/* 265 */     lvb.declaration = new LocalDeclaration(name, 0, 0);
/* 266 */     return lvb;
/*     */   }
/*     */   private int getNextOffset(LocalVariableBinding local) {
/* 269 */     int delta = (TypeBinding.equalsEquals(local.type, (TypeBinding)TypeBinding.LONG) || TypeBinding.equalsEquals(local.type, (TypeBinding)TypeBinding.DOUBLE)) ? 
/* 270 */       2 : 1;
/* 271 */     return local.resolvedPosition + delta;
/*     */   }
/*     */   private void processTypesBindingsOnStack(CodeStream codeStream) {
/* 274 */     int count = 0;
/* 275 */     int nextResolvedPosition = this.scope.offset;
/* 276 */     if (!codeStream.switchSaveTypeBindings.empty()) {
/* 277 */       this.typesOnStack = new ArrayList<>();
/* 278 */       int index = 0;
/* 279 */       Stack<TypeBinding> typeStack = new Stack<>();
/* 280 */       int sz = codeStream.switchSaveTypeBindings.size();
/* 281 */       for (int i = codeStream.lastSwitchCumulativeSyntheticVars; i < sz; i++) {
/* 282 */         typeStack.add(codeStream.switchSaveTypeBindings.get(i));
/*     */       }
/* 284 */       while (!typeStack.empty()) {
/* 285 */         TypeBinding type = typeStack.pop();
/* 286 */         LocalVariableBinding lvb = addTypeStackVariable(codeStream, type, 0, index++, nextResolvedPosition);
/* 287 */         nextResolvedPosition = getNextOffset(lvb);
/* 288 */         this.typesOnStack.add(lvb);
/* 289 */         codeStream.store(lvb, false);
/* 290 */         codeStream.addVariable(lvb);
/* 291 */         count++;
/*     */       } 
/*     */     } 
/*     */     
/* 295 */     this.yieldResolvedPosition = nextResolvedPosition;
/* 296 */     nextResolvedPosition += (TypeBinding.equalsEquals(this.resolvedType, (TypeBinding)TypeBinding.LONG) || 
/* 297 */       TypeBinding.equalsEquals(this.resolvedType, (TypeBinding)TypeBinding.DOUBLE)) ? 
/* 298 */       2 : 1;
/*     */     
/* 300 */     codeStream.lastSwitchCumulativeSyntheticVars += count + 1;
/* 301 */     int delta = nextResolvedPosition - this.scope.offset;
/* 302 */     this.scope.adjustLocalVariablePositions(delta, false);
/*     */   }
/*     */   public void loadStoredTypesAndKeep(CodeStream codeStream) {
/* 305 */     List<LocalVariableBinding> tos = this.typesOnStack;
/* 306 */     int sz = (tos != null) ? tos.size() : 0;
/* 307 */     codeStream.clearTypeBindingStack();
/* 308 */     int index = sz - 1;
/* 309 */     while (index >= 0) {
/* 310 */       LocalVariableBinding lvb = tos.get(index--);
/* 311 */       codeStream.load(lvb);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private void removeStoredTypes(CodeStream codeStream) {
/* 317 */     List<LocalVariableBinding> tos = this.typesOnStack;
/* 318 */     int sz = (tos != null) ? tos.size() : 0;
/* 319 */     int index = sz - 1;
/* 320 */     while (index >= 0) {
/* 321 */       LocalVariableBinding lvb = tos.get(index--);
/* 322 */       codeStream.removeVariable(lvb);
/*     */     } 
/*     */   }
/*     */   
/*     */   public void generateCode(BlockScope currentScope, CodeStream codeStream, boolean valueRequired) {
/* 327 */     int tmp = 0;
/* 328 */     if (this.containsTry) {
/* 329 */       tmp = codeStream.lastSwitchCumulativeSyntheticVars;
/* 330 */       processTypesBindingsOnStack(codeStream);
/*     */     } 
/* 332 */     generateCode(currentScope, codeStream);
/* 333 */     if (this.containsTry) {
/* 334 */       removeStoredTypes(codeStream);
/* 335 */       codeStream.lastSwitchCumulativeSyntheticVars = tmp;
/*     */     } 
/* 337 */     if (!valueRequired) {
/*     */       
/* 339 */       switch ((postConversionType((Scope)currentScope)).id) {
/*     */         case 7:
/*     */         case 8:
/* 342 */           codeStream.pop2();
/*     */         
/*     */         case 6:
/*     */           return;
/*     */       } 
/* 347 */       codeStream.pop();
/*     */     } 
/*     */ 
/*     */     
/* 351 */     if (!isPolyExpression())
/* 352 */       codeStream.generateImplicitConversion(this.implicitConversion); 
/*     */   }
/*     */   
/*     */   protected boolean computeConversions(BlockScope blockScope, TypeBinding targetType) {
/* 356 */     boolean ok = true;
/* 357 */     for (int i = 0, l = this.resultExpressions.size(); i < l; i++) {
/* 358 */       ok &= computeConversionsResultExpressions(blockScope, targetType, this.originalValueResultExpressionTypes[i], this.resultExpressions.get(i));
/*     */     }
/* 360 */     return ok;
/*     */   }
/*     */   
/*     */   private boolean computeConversionsResultExpressions(BlockScope blockScope, TypeBinding targetType, TypeBinding resultExpressionType, Expression resultExpression) {
/* 364 */     if (resultExpressionType != null && resultExpressionType.isValidBinding()) {
/* 365 */       if (resultExpression.isConstantValueOfTypeAssignableToType(resultExpressionType, targetType) || 
/* 366 */         resultExpressionType.isCompatibleWith(targetType)) {
/*     */         
/* 368 */         resultExpression.computeConversion((Scope)blockScope, targetType, resultExpressionType);
/* 369 */         if (resultExpressionType.needsUncheckedConversion(targetType)) {
/* 370 */           blockScope.problemReporter().unsafeTypeConversion(resultExpression, resultExpressionType, targetType);
/*     */         }
/* 372 */         if (resultExpression instanceof CastExpression && (
/* 373 */           resultExpression.bits & 0x4020) == 0) {
/* 374 */           CastExpression.checkNeedForAssignedCast(blockScope, targetType, (CastExpression)resultExpression);
/*     */         }
/* 376 */       } else if (isBoxingCompatible(resultExpressionType, targetType, resultExpression, (Scope)blockScope)) {
/* 377 */         resultExpression.computeConversion((Scope)blockScope, targetType, resultExpressionType);
/* 378 */         if (resultExpression instanceof CastExpression && (
/* 379 */           resultExpression.bits & 0x4020) == 0) {
/* 380 */           CastExpression.checkNeedForAssignedCast(blockScope, targetType, (CastExpression)resultExpression);
/*     */         }
/*     */       } else {
/* 383 */         blockScope.problemReporter().typeMismatchError(resultExpressionType, targetType, resultExpression, null);
/* 384 */         return false;
/*     */       } 
/*     */     }
/* 387 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   static class OOBLFlagger
/*     */     extends ASTVisitor
/*     */   {
/* 394 */     Set<String> labelDecls = new HashSet<>();
/* 395 */     Set<BreakStatement> referencedBreakLabels = new HashSet<>();
/* 396 */     Set<ContinueStatement> referencedContinueLabels = new HashSet<>();
/*     */     public OOBLFlagger(SwitchExpression se) {}
/*     */     
/*     */     public boolean visit(SwitchExpression switchExpression, BlockScope blockScope) {
/* 400 */       return true;
/*     */     }
/*     */     private void checkForOutofBoundLabels(BlockScope blockScope) {
/*     */       try {
/* 404 */         for (BreakStatement bs : this.referencedBreakLabels) {
/* 405 */           if (bs.label == null || bs.label.length == 0)
/*     */             continue; 
/* 407 */           if (!this.labelDecls.contains(new String(bs.label)))
/* 408 */             blockScope.problemReporter().switchExpressionsBreakOutOfSwitchExpression(bs); 
/*     */         } 
/* 410 */         for (ContinueStatement cs : this.referencedContinueLabels) {
/* 411 */           if (cs.label == null || cs.label.length == 0)
/*     */             continue; 
/* 413 */           if (!this.labelDecls.contains(new String(cs.label)))
/* 414 */             blockScope.problemReporter().switchExpressionsContinueOutOfSwitchExpression(cs); 
/*     */         } 
/* 416 */       } catch (EmptyStackException emptyStackException) {}
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void endVisit(SwitchExpression switchExpression, BlockScope blockScope) {
/* 423 */       checkForOutofBoundLabels(blockScope);
/*     */     }
/*     */     
/*     */     public boolean visit(BreakStatement breakStatement, BlockScope blockScope) {
/* 427 */       if (breakStatement.label != null && breakStatement.label.length != 0)
/* 428 */         this.referencedBreakLabels.add(breakStatement); 
/* 429 */       return true;
/*     */     }
/*     */     
/*     */     public boolean visit(ContinueStatement continueStatement, BlockScope blockScope) {
/* 433 */       if (continueStatement.label != null && continueStatement.label.length != 0)
/* 434 */         this.referencedContinueLabels.add(continueStatement); 
/* 435 */       return true;
/*     */     }
/*     */     
/*     */     public boolean visit(LambdaExpression lambdaExpression, BlockScope blockScope) {
/* 439 */       return false;
/*     */     }
/*     */     
/*     */     public boolean visit(LabeledStatement stmt, BlockScope blockScope) {
/* 443 */       if (stmt.label != null && stmt.label.length != 0)
/* 444 */         this.labelDecls.add(new String(stmt.label)); 
/* 445 */       return true;
/*     */     }
/*     */     
/*     */     public boolean visit(ReturnStatement stmt, BlockScope blockScope) {
/* 449 */       blockScope.problemReporter().switchExpressionsReturnWithinSwitchExpression(stmt);
/* 450 */       return false;
/*     */     }
/*     */     
/*     */     public boolean visit(TypeDeclaration stmt, BlockScope blockScope) {
/* 454 */       return false;
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void collectPatternVariablesToScope(LocalVariableBinding[] variables, BlockScope skope) {}
/*     */ 
/*     */   
/*     */   public TypeBinding resolveType(BlockScope upperScope) {
/* 463 */     return resolveTypeInternal(upperScope);
/*     */   }
/*     */   public TypeBinding resolveTypeInternal(BlockScope upperScope) {
/*     */     try {
/*     */       int resultExpressionsCount, j;
/* 468 */       if (this.constant != Constant.NotAConstant) {
/* 469 */         this.constant = Constant.NotAConstant;
/*     */ 
/*     */ 
/*     */         
/* 473 */         if (this.expressionContext == ExpressionContext.ASSIGNMENT_CONTEXT || this.expressionContext == ExpressionContext.INVOCATION_CONTEXT) {
/* 474 */           for (Expression e : this.resultExpressions) {
/*     */ 
/*     */             
/* 477 */             e.setExpressionContext(this.expressionContext);
/* 478 */             e.setExpectedType(this.expectedType);
/*     */           } 
/*     */         }
/*     */         
/* 482 */         if (this.originalTypeMap == null)
/* 483 */           this.originalTypeMap = new HashMap<>(); 
/* 484 */         resolve(upperScope);
/*     */         
/* 486 */         if (this.statements == null || this.statements.length == 0) {
/*     */           
/* 488 */           upperScope.problemReporter().switchExpressionEmptySwitchBlock(this);
/* 489 */           return null;
/*     */         } 
/*     */         
/* 492 */         resultExpressionsCount = (this.resultExpressions != null) ? this.resultExpressions.size() : 0;
/* 493 */         if (resultExpressionsCount == 0) {
/*     */ 
/*     */           
/* 496 */           upperScope.problemReporter().switchExpressionNoResultExpressions(this);
/* 497 */           return null;
/*     */         } 
/* 499 */         traverse(new OOBLFlagger(this), upperScope);
/*     */         
/* 501 */         if (this.originalValueResultExpressionTypes == null) {
/* 502 */           this.originalValueResultExpressionTypes = new TypeBinding[resultExpressionsCount];
/* 503 */           this.finalValueResultExpressionTypes = new TypeBinding[resultExpressionsCount];
/* 504 */           for (int n = 0; n < resultExpressionsCount; 
/* 505 */             this.finalValueResultExpressionTypes[n] = 
/* 506 */             ((Expression)this.resultExpressions.get(n)).resolvedType, n++) this.originalValueResultExpressionTypes[n] = ((Expression)this.resultExpressions.get(n)).resolvedType;
/*     */         
/*     */         } 
/* 509 */         if (isPolyExpression()) {
/* 510 */           if (this.expectedType == null || !this.expectedType.isProperType(true)) {
/* 511 */             return (TypeBinding)new PolyTypeBinding(this);
/*     */           }
/* 513 */           return this.resolvedType = computeConversions(this.scope, this.expectedType) ? this.expectedType : null;
/*     */         }
/*     */       
/*     */       } else {
/*     */         
/* 518 */         resultExpressionsCount = (this.resultExpressions != null) ? this.resultExpressions.size() : 0;
/* 519 */         if (resultExpressionsCount == 0)
/* 520 */           return this.resolvedType = null; 
/* 521 */         for (int n = 0; n < resultExpressionsCount; n++) {
/* 522 */           Expression resultExpr = this.resultExpressions.get(n);
/* 523 */           TypeBinding origType = this.originalTypeMap.get(resultExpr);
/* 524 */           if (origType == null || origType.kind() == 65540) {
/* 525 */             this.originalValueResultExpressionTypes[n] = 
/* 526 */               resultExpr.resolveTypeExpecting(upperScope, this.expectedType); this.finalValueResultExpressionTypes[n] = resultExpr.resolveTypeExpecting(upperScope, this.expectedType);
/*     */           } 
/*     */ 
/*     */ 
/*     */           
/* 531 */           if (!this.resolveAll && (
/* 532 */             resultExpr.resolvedType == null || !resultExpr.resolvedType.isValidBinding()))
/* 533 */             return this.resolvedType = null; 
/*     */         } 
/* 535 */         this.resolvedType = computeConversions(this.scope, this.expectedType) ? this.expectedType : null;
/*     */       } 
/*     */ 
/*     */       
/* 539 */       if (resultExpressionsCount == 1) {
/* 540 */         return this.resolvedType = this.originalValueResultExpressionTypes[0];
/*     */       }
/* 542 */       boolean typeUniformAcrossAllArms = true;
/* 543 */       TypeBinding tmp = this.originalValueResultExpressionTypes[0]; int i, l;
/* 544 */       for (i = 1, l = this.originalValueResultExpressionTypes.length; i < l; i++) {
/* 545 */         TypeBinding originalType = this.originalValueResultExpressionTypes[i];
/* 546 */         if (originalType != null && TypeBinding.notEquals(tmp, originalType)) {
/* 547 */           typeUniformAcrossAllArms = false;
/*     */           
/*     */           break;
/*     */         } 
/*     */       } 
/*     */       
/* 553 */       if (typeUniformAcrossAllArms) {
/* 554 */         tmp = this.originalValueResultExpressionTypes[0];
/* 555 */         for (i = 1; i < resultExpressionsCount; i++) {
/* 556 */           if (this.originalValueResultExpressionTypes[i] != null)
/* 557 */             tmp = NullAnnotationMatching.moreDangerousType(tmp, this.originalValueResultExpressionTypes[i]); 
/*     */         } 
/* 559 */         return this.resolvedType = tmp;
/*     */       } 
/*     */       
/* 562 */       boolean typeBbolean = true; byte b; int k; TypeBinding[] arrayOfTypeBinding;
/* 563 */       for (k = (arrayOfTypeBinding = this.originalValueResultExpressionTypes).length, b = 0; b < k; ) { TypeBinding t = arrayOfTypeBinding[b];
/* 564 */         if (t != null)
/* 565 */           j = typeBbolean & ((t.id != 5 && t.id != 33) ? 0 : 1);  b++; }
/*     */       
/* 567 */       LookupEnvironment env = this.scope.environment();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 573 */       if (j != 0) {
/* 574 */         for (int n = 0; n < resultExpressionsCount; n++) {
/* 575 */           if (this.originalValueResultExpressionTypes[n] != null && 
/* 576 */             (this.originalValueResultExpressionTypes[n]).id != 5) {
/* 577 */             this.finalValueResultExpressionTypes[n] = env.computeBoxingType(this.originalValueResultExpressionTypes[n]);
/* 578 */             ((Expression)this.resultExpressions.get(n)).computeConversion((Scope)this.scope, this.finalValueResultExpressionTypes[n], this.originalValueResultExpressionTypes[n]);
/*     */           } 
/* 580 */         }  return this.resolvedType = (TypeBinding)TypeBinding.BOOLEAN;
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 587 */       boolean typeNumeric = true;
/* 588 */       TypeBinding resultNumeric = null;
/* 589 */       HashSet<TypeBinding> typeSet = new HashSet<>();
/*     */ 
/*     */ 
/*     */       
/*     */       int m;
/*     */ 
/*     */       
/* 596 */       for (m = 0; m < resultExpressionsCount; m++) {
/* 597 */         TypeBinding originalType = this.originalValueResultExpressionTypes[m];
/* 598 */         if (originalType != null) {
/* 599 */           tmp = originalType.isNumericType() ? originalType : env.computeBoxingType(originalType);
/* 600 */           if (!tmp.isNumericType()) {
/* 601 */             typeNumeric = false;
/*     */             break;
/*     */           } 
/* 604 */           typeSet.add(TypeBinding.wellKnownType((Scope)this.scope, tmp.id));
/*     */         } 
/* 606 */       }  if (typeNumeric) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 614 */         TypeBinding[] dfl = {
/* 615 */             (TypeBinding)TypeBinding.DOUBLE, 
/* 616 */             (TypeBinding)TypeBinding.FLOAT, 
/* 617 */             (TypeBinding)TypeBinding.LONG }; byte b1; int i1; TypeBinding[] arrayOfTypeBinding1;
/* 618 */         for (i1 = (arrayOfTypeBinding1 = dfl).length, b1 = 0; b1 < i1; ) { TypeBinding binding = arrayOfTypeBinding1[b1];
/* 619 */           if (typeSet.contains(binding)) {
/* 620 */             resultNumeric = binding;
/*     */ 
/*     */ 
/*     */ 
/*     */             
/*     */             break;
/*     */           } 
/*     */ 
/*     */ 
/*     */           
/*     */           b1++; }
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 635 */         resultNumeric = (resultNumeric != null) ? resultNumeric : check_nonconstant_int();
/*     */         
/* 637 */         resultNumeric = (resultNumeric != null) ? resultNumeric : 
/* 638 */           getResultNumeric(typeSet);
/* 639 */         typeSet = null;
/* 640 */         for (int n = 0; n < resultExpressionsCount; n++) {
/* 641 */           ((Expression)this.resultExpressions.get(n)).computeConversion((Scope)this.scope, 
/* 642 */               resultNumeric, this.originalValueResultExpressionTypes[n]);
/* 643 */           this.finalValueResultExpressionTypes[n] = resultNumeric;
/*     */         } 
/*     */         
/* 646 */         return this.resolvedType = resultNumeric;
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 653 */       for (m = 0; m < resultExpressionsCount; m++) {
/* 654 */         TypeBinding finalType = this.finalValueResultExpressionTypes[m];
/* 655 */         if (finalType != null && finalType.isBaseType())
/* 656 */           this.finalValueResultExpressionTypes[m] = env.computeBoxingType(finalType); 
/*     */       } 
/* 658 */       TypeBinding commonType = this.scope.lowerUpperBound(this.finalValueResultExpressionTypes);
/* 659 */       if (commonType != null) {
/* 660 */         for (int n = 0, i1 = this.resultExpressions.size(); n < i1; n++) {
/* 661 */           if (this.originalValueResultExpressionTypes[n] != null) {
/* 662 */             ((Expression)this.resultExpressions.get(n)).computeConversion((Scope)this.scope, commonType, this.originalValueResultExpressionTypes[n]);
/* 663 */             this.finalValueResultExpressionTypes[n] = commonType;
/*     */           } 
/* 665 */         }  return this.resolvedType = commonType.capture((Scope)this.scope, this.sourceStart, this.sourceEnd);
/*     */       } 
/* 667 */       this.scope.problemReporter().switchExpressionIncompatibleResultExpressions(this);
/* 668 */       return null;
/*     */     } finally {
/* 670 */       if (this.scope != null) this.scope.enclosingCase = null; 
/*     */     } 
/*     */   }
/*     */   private TypeBinding check_nonconstant_int() {
/* 674 */     for (int i = 0, l = this.resultExpressions.size(); i < l; i++) {
/* 675 */       Expression e = this.resultExpressions.get(i);
/* 676 */       TypeBinding type = this.originalValueResultExpressionTypes[i];
/* 677 */       if (type != null && type.id == 10 && e.constant == Constant.NotAConstant)
/* 678 */         return (TypeBinding)TypeBinding.INT; 
/*     */     } 
/* 680 */     return null;
/*     */   }
/*     */   private boolean areAllIntegerResultExpressionsConvertibleToTargetType(TypeBinding targetType) {
/* 683 */     for (int i = 0, l = this.resultExpressions.size(); i < l; i++) {
/* 684 */       Expression e = this.resultExpressions.get(i);
/* 685 */       TypeBinding t = this.originalValueResultExpressionTypes[i];
/* 686 */       if (TypeBinding.equalsEquals(t, (TypeBinding)TypeBinding.INT) && 
/* 687 */         !e.isConstantValueOfTypeAssignableToType(t, targetType))
/* 688 */         return false; 
/*     */     } 
/* 690 */     return true;
/*     */   }
/*     */   
/*     */   public FlowInfo analyseCode(BlockScope currentScope, FlowContext flowContext, FlowInfo flowInfo) {
/* 694 */     flowInfo = super.analyseCode(currentScope, flowContext, flowInfo);
/* 695 */     this.resultExpressionNullStatus = new ArrayList<>(0);
/* 696 */     CompilerOptions compilerOptions = currentScope.compilerOptions();
/* 697 */     if (compilerOptions.enableSyntacticNullAnalysisForFields) {
/* 698 */       for (Expression re : this.resultExpressions) {
/* 699 */         this.resultExpressionNullStatus.add(Integer.valueOf(re.nullStatus(flowInfo, flowContext)));
/*     */         
/* 701 */         flowContext.expireNullCheckedFieldInfo();
/*     */       } 
/*     */     }
/* 704 */     computeNullStatus(flowInfo, flowContext);
/* 705 */     return flowInfo;
/*     */   }
/*     */   
/*     */   protected void addSecretTryResultVariable() {
/* 709 */     if (this.containsTry) {
/* 710 */       this.hiddenYield = 
/* 711 */         new LocalVariableBinding(
/* 712 */           SECRET_YIELD_VALUE_NAME, 
/* 713 */           null, 
/* 714 */           0, 
/* 715 */           false);
/* 716 */       this.hiddenYield.setConstant(Constant.NotAConstant);
/* 717 */       this.hiddenYield.useFlag = 1;
/* 718 */       this.scope.addLocalVariable(this.hiddenYield);
/* 719 */       this.hiddenYield.declaration = new LocalDeclaration(SECRET_YIELD_VALUE_NAME, 0, 0);
/*     */     } 
/*     */   }
/*     */   private TypeBinding check_csb(Set<TypeBinding> typeSet, TypeBinding candidate) {
/* 723 */     if (!typeSet.contains(candidate)) {
/* 724 */       return null;
/*     */     }
/* 726 */     TypeBinding[] allowedTypes = type_map.get(candidate);
/* 727 */     Set<TypeBinding> allowedSet = (Set<TypeBinding>)Arrays.<TypeBinding>stream(allowedTypes).collect(Collectors.toSet());
/*     */     
/* 729 */     if (!allowedSet.containsAll(typeSet)) {
/* 730 */       return null;
/*     */     }
/* 732 */     return areAllIntegerResultExpressionsConvertibleToTargetType(candidate) ? 
/* 733 */       candidate : null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private TypeBinding getResultNumeric(Set<TypeBinding> typeSet) {
/* 757 */     TypeBinding[] csb = { (TypeBinding)TypeBinding.SHORT, (TypeBinding)TypeBinding.BYTE, (TypeBinding)TypeBinding.CHAR }; byte b; int i; TypeBinding[] arrayOfTypeBinding1;
/* 758 */     for (i = (arrayOfTypeBinding1 = csb).length, b = 0; b < i; ) { TypeBinding c = arrayOfTypeBinding1[b];
/* 759 */       TypeBinding result = check_csb(typeSet, c);
/* 760 */       if (result != null)
/* 761 */         return result; 
/*     */       b++; }
/*     */     
/* 764 */     return (TypeBinding)TypeBinding.INT;
/*     */   }
/*     */   
/*     */   public boolean isPolyExpression() {
/* 768 */     if (this.isPolyExpression) {
/* 769 */       return true;
/*     */     }
/*     */     
/* 772 */     return this.isPolyExpression = !(this.expressionContext != ExpressionContext.ASSIGNMENT_CONTEXT && 
/* 773 */       this.expressionContext != ExpressionContext.INVOCATION_CONTEXT);
/*     */   }
/*     */   
/*     */   public boolean isTrulyExpression() {
/* 777 */     return true;
/*     */   }
/*     */   
/*     */   public boolean isCompatibleWith(TypeBinding left, Scope skope) {
/* 781 */     if (!isPolyExpression()) {
/* 782 */       return super.isCompatibleWith(left, skope);
/*     */     }
/* 784 */     for (Expression e : this.resultExpressions) {
/* 785 */       if (!e.isCompatibleWith(left, skope))
/* 786 */         return false; 
/*     */     } 
/* 788 */     return true;
/*     */   }
/*     */   
/*     */   public boolean isBoxingCompatibleWith(TypeBinding targetType, Scope skope) {
/* 792 */     if (!isPolyExpression()) {
/* 793 */       return super.isBoxingCompatibleWith(targetType, skope);
/*     */     }
/* 795 */     for (Expression e : this.resultExpressions) {
/* 796 */       if (!e.isCompatibleWith(targetType, skope) && !e.isBoxingCompatibleWith(targetType, skope))
/* 797 */         return false; 
/*     */     } 
/* 799 */     return true;
/*     */   }
/*     */   
/*     */   public boolean sIsMoreSpecific(TypeBinding s, TypeBinding t, Scope skope) {
/* 803 */     if (super.sIsMoreSpecific(s, t, skope))
/* 804 */       return true; 
/* 805 */     if (!isPolyExpression())
/* 806 */       return false; 
/* 807 */     for (Expression e : this.resultExpressions) {
/* 808 */       if (!e.sIsMoreSpecific(s, t, skope))
/* 809 */         return false; 
/*     */     } 
/* 811 */     return true;
/*     */   }
/*     */   
/*     */   public TypeBinding expectedType() {
/* 815 */     return this.expectedType;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void traverse(ASTVisitor visitor, BlockScope blockScope) {
/* 822 */     if (visitor.visit(this, blockScope)) {
/* 823 */       this.expression.traverse(visitor, blockScope);
/* 824 */       if (this.statements != null) {
/* 825 */         int statementsLength = this.statements.length;
/* 826 */         for (int i = 0; i < statementsLength; i++)
/* 827 */           this.statements[i].traverse(visitor, this.scope); 
/*     */       } 
/*     */     } 
/* 830 */     visitor.endVisit(this, blockScope);
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\ast\SwitchExpression.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */