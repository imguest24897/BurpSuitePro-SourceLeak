/*     */ package org.eclipse.jdt.internal.compiler.batch;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.nio.file.FileVisitResult;
/*     */ import java.nio.file.Path;
/*     */ import java.nio.file.attribute.BasicFileAttributes;
/*     */ import java.util.ArrayList;
/*     */ import org.eclipse.jdt.internal.compiler.util.JRTUtil;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class null
/*     */   implements JRTUtil.JrtFileVisitor<Path>
/*     */ {
/*     */   public FileVisitResult visitPackage(Path dir, Path modPath, BasicFileAttributes attrs) throws IOException {
/* 142 */     if (qualifiedPackageName.startsWith(dir.toString())) {
/* 143 */       return FileVisitResult.CONTINUE;
/*     */     }
/* 145 */     return FileVisitResult.SKIP_SUBTREE;
/*     */   }
/*     */ 
/*     */   
/*     */   public FileVisitResult visitFile(Path dir, Path modPath, BasicFileAttributes attrs) throws IOException {
/* 150 */     Path parent = dir.getParent();
/* 151 */     if (parent == null)
/* 152 */       return FileVisitResult.CONTINUE; 
/* 153 */     if (!parent.toString().equals(qualifiedPackageName)) {
/* 154 */       return FileVisitResult.CONTINUE;
/*     */     }
/* 156 */     String fileName = dir.getName(dir.getNameCount() - 1).toString();
/*     */     
/* 158 */     ClasspathJrt.this.addTypeName(answers, fileName, -1, packageArray);
/* 159 */     return FileVisitResult.CONTINUE;
/*     */   }
/*     */ 
/*     */   
/*     */   public FileVisitResult visitModule(Path p, String name) throws IOException {
/* 164 */     if (moduleName == null)
/* 165 */       return FileVisitResult.CONTINUE; 
/* 166 */     if (!moduleName.equals(name)) {
/* 167 */       return FileVisitResult.SKIP_SUBTREE;
/*     */     }
/* 169 */     return FileVisitResult.CONTINUE;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\batch\ClasspathJrt$1.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */