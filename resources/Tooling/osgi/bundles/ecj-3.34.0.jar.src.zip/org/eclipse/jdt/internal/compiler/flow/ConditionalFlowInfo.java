/*     */ package org.eclipse.jdt.internal.compiler.flow;
/*     */ 
/*     */ import org.eclipse.jdt.internal.compiler.lookup.FieldBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.LocalVariableBinding;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ConditionalFlowInfo
/*     */   extends FlowInfo
/*     */ {
/*     */   public FlowInfo initsWhenTrue;
/*     */   public FlowInfo initsWhenFalse;
/*     */   
/*     */   ConditionalFlowInfo(FlowInfo initsWhenTrue, FlowInfo initsWhenFalse) {
/*  34 */     this.initsWhenTrue = initsWhenTrue;
/*  35 */     this.initsWhenFalse = initsWhenFalse;
/*  36 */     this.tagBits = initsWhenTrue.tagBits & initsWhenFalse.tagBits & 0x3;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public FlowInfo addInitializationsFrom(FlowInfo otherInits) {
/*  42 */     this.initsWhenTrue.addInitializationsFrom(otherInits);
/*  43 */     this.initsWhenFalse.addInitializationsFrom(otherInits);
/*  44 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public FlowInfo addNullInfoFrom(FlowInfo otherInits) {
/*  50 */     this.initsWhenTrue.addNullInfoFrom(otherInits);
/*  51 */     this.initsWhenFalse.addNullInfoFrom(otherInits);
/*  52 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public FlowInfo addPotentialInitializationsFrom(FlowInfo otherInits) {
/*  58 */     this.initsWhenTrue.addPotentialInitializationsFrom(otherInits);
/*  59 */     this.initsWhenFalse.addPotentialInitializationsFrom(otherInits);
/*  60 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public FlowInfo asNegatedCondition() {
/*  66 */     FlowInfo extra = this.initsWhenTrue;
/*  67 */     this.initsWhenTrue = this.initsWhenFalse;
/*  68 */     this.initsWhenFalse = extra;
/*  69 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public FlowInfo copy() {
/*  75 */     return new ConditionalFlowInfo(this.initsWhenTrue.copy(), this.initsWhenFalse.copy());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public FlowInfo initsWhenFalse() {
/*  81 */     return this.initsWhenFalse;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public FlowInfo initsWhenTrue() {
/*  87 */     return this.initsWhenTrue;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isDefinitelyAssigned(FieldBinding field) {
/*  93 */     return (this.initsWhenTrue.isDefinitelyAssigned(field) && 
/*  94 */       this.initsWhenFalse.isDefinitelyAssigned(field));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isDefinitelyAssigned(LocalVariableBinding local) {
/* 100 */     return (this.initsWhenTrue.isDefinitelyAssigned(local) && 
/* 101 */       this.initsWhenFalse.isDefinitelyAssigned(local));
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isDefinitelyNonNull(LocalVariableBinding local) {
/* 106 */     return (this.initsWhenTrue.isDefinitelyNonNull(local) && 
/* 107 */       this.initsWhenFalse.isDefinitelyNonNull(local));
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isDefinitelyNull(LocalVariableBinding local) {
/* 112 */     return (this.initsWhenTrue.isDefinitelyNull(local) && 
/* 113 */       this.initsWhenFalse.isDefinitelyNull(local));
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isDefinitelyUnknown(LocalVariableBinding local) {
/* 118 */     return (this.initsWhenTrue.isDefinitelyUnknown(local) && 
/* 119 */       this.initsWhenFalse.isDefinitelyUnknown(local));
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean hasNullInfoFor(LocalVariableBinding local) {
/* 124 */     return !(!this.initsWhenTrue.hasNullInfoFor(local) && 
/* 125 */       !this.initsWhenFalse.hasNullInfoFor(local));
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isPotentiallyAssigned(FieldBinding field) {
/* 130 */     return !(!this.initsWhenTrue.isPotentiallyAssigned(field) && 
/* 131 */       !this.initsWhenFalse.isPotentiallyAssigned(field));
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isPotentiallyAssigned(LocalVariableBinding local) {
/* 136 */     return !(!this.initsWhenTrue.isPotentiallyAssigned(local) && 
/* 137 */       !this.initsWhenFalse.isPotentiallyAssigned(local));
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isPotentiallyNonNull(LocalVariableBinding local) {
/* 142 */     return !(!this.initsWhenTrue.isPotentiallyNonNull(local) && 
/* 143 */       !this.initsWhenFalse.isPotentiallyNonNull(local));
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isPotentiallyNull(LocalVariableBinding local) {
/* 148 */     return !(!this.initsWhenTrue.isPotentiallyNull(local) && 
/* 149 */       !this.initsWhenFalse.isPotentiallyNull(local));
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isPotentiallyUnknown(LocalVariableBinding local) {
/* 154 */     return !(!this.initsWhenTrue.isPotentiallyUnknown(local) && 
/* 155 */       !this.initsWhenFalse.isPotentiallyUnknown(local));
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isProtectedNonNull(LocalVariableBinding local) {
/* 160 */     return (this.initsWhenTrue.isProtectedNonNull(local) && 
/* 161 */       this.initsWhenFalse.isProtectedNonNull(local));
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isProtectedNull(LocalVariableBinding local) {
/* 166 */     return (this.initsWhenTrue.isProtectedNull(local) && 
/* 167 */       this.initsWhenFalse.isProtectedNull(local));
/*     */   }
/*     */ 
/*     */   
/*     */   public void markAsComparedEqualToNonNull(LocalVariableBinding local) {
/* 172 */     this.initsWhenTrue.markAsComparedEqualToNonNull(local);
/* 173 */     this.initsWhenFalse.markAsComparedEqualToNonNull(local);
/*     */   }
/*     */ 
/*     */   
/*     */   public void markAsComparedEqualToNull(LocalVariableBinding local) {
/* 178 */     this.initsWhenTrue.markAsComparedEqualToNull(local);
/* 179 */     this.initsWhenFalse.markAsComparedEqualToNull(local);
/*     */   }
/*     */ 
/*     */   
/*     */   public void markAsDefinitelyAssigned(FieldBinding field) {
/* 184 */     this.initsWhenTrue.markAsDefinitelyAssigned(field);
/* 185 */     this.initsWhenFalse.markAsDefinitelyAssigned(field);
/*     */   }
/*     */ 
/*     */   
/*     */   public void markAsDefinitelyAssigned(LocalVariableBinding local) {
/* 190 */     this.initsWhenTrue.markAsDefinitelyAssigned(local);
/* 191 */     this.initsWhenFalse.markAsDefinitelyAssigned(local);
/*     */   }
/*     */ 
/*     */   
/*     */   public void markAsDefinitelyNonNull(LocalVariableBinding local) {
/* 196 */     this.initsWhenTrue.markAsDefinitelyNonNull(local);
/* 197 */     this.initsWhenFalse.markAsDefinitelyNonNull(local);
/*     */   }
/*     */ 
/*     */   
/*     */   public void markAsDefinitelyNull(LocalVariableBinding local) {
/* 202 */     this.initsWhenTrue.markAsDefinitelyNull(local);
/* 203 */     this.initsWhenFalse.markAsDefinitelyNull(local);
/*     */   }
/*     */ 
/*     */   
/*     */   public void resetNullInfo(LocalVariableBinding local) {
/* 208 */     this.initsWhenTrue.resetNullInfo(local);
/* 209 */     this.initsWhenFalse.resetNullInfo(local);
/*     */   }
/*     */ 
/*     */   
/*     */   public void markPotentiallyNullBit(LocalVariableBinding local) {
/* 214 */     this.initsWhenTrue.markPotentiallyNullBit(local);
/* 215 */     this.initsWhenFalse.markPotentiallyNullBit(local);
/*     */   }
/*     */ 
/*     */   
/*     */   public void markPotentiallyNonNullBit(LocalVariableBinding local) {
/* 220 */     this.initsWhenTrue.markPotentiallyNonNullBit(local);
/* 221 */     this.initsWhenFalse.markPotentiallyNonNullBit(local);
/*     */   }
/*     */ 
/*     */   
/*     */   public void markAsDefinitelyUnknown(LocalVariableBinding local) {
/* 226 */     this.initsWhenTrue.markAsDefinitelyUnknown(local);
/* 227 */     this.initsWhenFalse.markAsDefinitelyUnknown(local);
/*     */   }
/*     */ 
/*     */   
/*     */   public void markPotentiallyUnknownBit(LocalVariableBinding local) {
/* 232 */     this.initsWhenTrue.markPotentiallyUnknownBit(local);
/* 233 */     this.initsWhenFalse.markPotentiallyUnknownBit(local);
/*     */   }
/*     */ 
/*     */   
/*     */   public FlowInfo setReachMode(int reachMode) {
/* 238 */     if (reachMode == 0) {
/* 239 */       this.tagBits &= 0xFFFFFFFC;
/*     */     } else {
/*     */       
/* 242 */       this.tagBits |= reachMode;
/*     */     } 
/* 244 */     this.initsWhenTrue.setReachMode(reachMode);
/* 245 */     this.initsWhenFalse.setReachMode(reachMode);
/* 246 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public UnconditionalFlowInfo mergedWith(UnconditionalFlowInfo otherInits) {
/* 251 */     return unconditionalInits().mergedWith(otherInits);
/*     */   }
/*     */   
/*     */   public UnconditionalFlowInfo mergeDefiniteInitsWith(UnconditionalFlowInfo otherInits) {
/* 255 */     return unconditionalInits().mergeDefiniteInitsWith(otherInits);
/*     */   }
/*     */   
/*     */   public UnconditionalFlowInfo nullInfoLessUnconditionalCopy() {
/* 259 */     return unconditionalInitsWithoutSideEffect()
/* 260 */       .nullInfoLessUnconditionalCopy();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 266 */     return "FlowInfo<true: " + this.initsWhenTrue.toString() + ", false: " + this.initsWhenFalse.toString() + ">";
/*     */   }
/*     */ 
/*     */   
/*     */   public FlowInfo safeInitsWhenTrue() {
/* 271 */     return this.initsWhenTrue;
/*     */   }
/*     */ 
/*     */   
/*     */   public UnconditionalFlowInfo unconditionalCopy() {
/* 276 */     return this.initsWhenTrue.unconditionalCopy()
/* 277 */       .mergedWith(this.initsWhenFalse.unconditionalInits());
/*     */   }
/*     */ 
/*     */   
/*     */   public UnconditionalFlowInfo unconditionalFieldLessCopy() {
/* 282 */     return this.initsWhenTrue.unconditionalFieldLessCopy()
/* 283 */       .mergedWith(this.initsWhenFalse.unconditionalFieldLessCopy());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public UnconditionalFlowInfo unconditionalInits() {
/* 289 */     return this.initsWhenTrue.unconditionalInits()
/* 290 */       .mergedWith(this.initsWhenFalse.unconditionalInits());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public UnconditionalFlowInfo unconditionalInitsWithoutSideEffect() {
/* 297 */     return this.initsWhenTrue.unconditionalCopy()
/* 298 */       .mergedWith(this.initsWhenFalse.unconditionalInits());
/*     */   }
/*     */ 
/*     */   
/*     */   public void resetAssignmentInfo(LocalVariableBinding local) {
/* 303 */     this.initsWhenTrue.resetAssignmentInfo(local);
/* 304 */     this.initsWhenFalse.resetAssignmentInfo(local);
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\flow\ConditionalFlowInfo.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */