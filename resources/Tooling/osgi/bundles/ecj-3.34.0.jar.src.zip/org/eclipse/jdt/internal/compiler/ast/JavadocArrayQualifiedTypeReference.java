/*    */ package org.eclipse.jdt.internal.compiler.ast;
/*    */ 
/*    */ import org.eclipse.jdt.internal.compiler.ASTVisitor;
/*    */ import org.eclipse.jdt.internal.compiler.lookup.BlockScope;
/*    */ import org.eclipse.jdt.internal.compiler.lookup.ClassScope;
/*    */ import org.eclipse.jdt.internal.compiler.lookup.Scope;
/*    */ import org.eclipse.jdt.internal.compiler.lookup.TypeBinding;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class JavadocArrayQualifiedTypeReference
/*    */   extends ArrayQualifiedTypeReference
/*    */ {
/*    */   public int tagSourceStart;
/*    */   public int tagSourceEnd;
/*    */   
/*    */   public JavadocArrayQualifiedTypeReference(JavadocQualifiedTypeReference typeRef, int dim) {
/* 29 */     super(typeRef.tokens, dim, typeRef.sourcePositions);
/*    */   }
/*    */ 
/*    */   
/*    */   protected void reportInvalidType(Scope scope) {
/* 34 */     scope.problemReporter().javadocInvalidType(this, this.resolvedType, scope.getDeclarationModifiers());
/*    */   }
/*    */   
/*    */   protected void reportDeprecatedType(TypeBinding type, Scope scope) {
/* 38 */     scope.problemReporter().javadocDeprecatedType(type, this, scope.getDeclarationModifiers());
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void traverse(ASTVisitor visitor, BlockScope scope) {
/* 47 */     visitor.visit(this, scope);
/* 48 */     visitor.endVisit(this, scope);
/*    */   }
/*    */ 
/*    */   
/*    */   public void traverse(ASTVisitor visitor, ClassScope scope) {
/* 53 */     visitor.visit(this, scope);
/* 54 */     visitor.endVisit(this, scope);
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\ast\JavadocArrayQualifiedTypeReference.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */