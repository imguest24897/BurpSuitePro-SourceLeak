/*     */ package org.eclipse.jdt.internal.compiler.ast;
/*     */ 
/*     */ import java.util.HashSet;
/*     */ import java.util.Set;
/*     */ import org.eclipse.jdt.core.compiler.CharOperation;
/*     */ import org.eclipse.jdt.internal.compiler.ASTVisitor;
/*     */ import org.eclipse.jdt.internal.compiler.codegen.BranchLabel;
/*     */ import org.eclipse.jdt.internal.compiler.codegen.CodeStream;
/*     */ import org.eclipse.jdt.internal.compiler.flow.FlowContext;
/*     */ import org.eclipse.jdt.internal.compiler.flow.FlowInfo;
/*     */ import org.eclipse.jdt.internal.compiler.impl.Constant;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.BlockScope;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.LocalVariableBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.RecordComponentBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.ReferenceBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.Scope;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.TypeBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.TypeBindingVisitor;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.TypeVariableBinding;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TypePattern
/*     */   extends Pattern
/*     */ {
/*     */   public LocalDeclaration local;
/*     */   Expression expression;
/*  41 */   public int index = -1;
/*     */   
/*     */   public TypePattern(LocalDeclaration local) {
/*  44 */     this.local = local;
/*     */   }
/*     */   
/*     */   protected TypePattern() {}
/*     */   
/*     */   public TypeReference getType() {
/*  50 */     return this.local.type;
/*     */   }
/*     */   
/*     */   public void collectPatternVariablesToScope(LocalVariableBinding[] variables, BlockScope scope) {
/*  54 */     if (this.resolvedType == null) {
/*  55 */       resolveType(scope);
/*     */     }
/*  57 */     if (this.local != null && this.local.binding != null) {
/*  58 */       LocalVariableBinding binding = this.local.binding;
/*  59 */       if (variables != null) {
/*  60 */         byte b; int i; LocalVariableBinding[] arrayOfLocalVariableBinding; for (i = (arrayOfLocalVariableBinding = variables).length, b = 0; b < i; ) { LocalVariableBinding variable = arrayOfLocalVariableBinding[b];
/*  61 */           if (variable != binding && 
/*  62 */             CharOperation.equals(binding.name, variable.name))
/*  63 */             scope.problemReporter().redefineLocal(this.local); 
/*     */           b++; }
/*     */       
/*     */       } 
/*  67 */       if (this.patternVarsWhenTrue == null) {
/*  68 */         this.patternVarsWhenTrue = new LocalVariableBinding[1];
/*  69 */         this.patternVarsWhenTrue[0] = binding;
/*     */       } else {
/*  71 */         LocalVariableBinding[] vars = new LocalVariableBinding[1];
/*  72 */         vars[0] = binding;
/*  73 */         addPatternVariablesWhenTrue(vars);
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   public boolean checkUnsafeCast(Scope scope, TypeBinding castType, TypeBinding expressionType, TypeBinding match, boolean isNarrowing) {
/*  79 */     if (!castType.isReifiable()) {
/*  80 */       return CastExpression.checkUnsafeCast(this, scope, castType, expressionType, match, isNarrowing);
/*     */     }
/*  82 */     return super.checkUnsafeCast(scope, castType, expressionType, match, isNarrowing);
/*     */   }
/*     */ 
/*     */   
/*     */   public FlowInfo analyseCode(BlockScope currentScope, FlowContext flowContext, FlowInfo flowInfo) {
/*  87 */     if (this.local != null) {
/*  88 */       FlowInfo patternInfo = flowInfo.copy();
/*  89 */       patternInfo.markAsDefinitelyAssigned(this.local.binding);
/*  90 */       if (!this.isTotalTypeNode) {
/*     */         
/*  92 */         patternInfo.markAsDefinitelyNonNull(this.local.binding);
/*     */       
/*     */       }
/*  95 */       else if (flowContext.associatedNode instanceof SwitchStatement) {
/*  96 */         SwitchStatement swStmt = (SwitchStatement)flowContext.associatedNode;
/*  97 */         int nullStatus = swStmt.containsNull ? 
/*  98 */           4 : 
/*  99 */           swStmt.expression.nullStatus(patternInfo, flowContext);
/* 100 */         patternInfo.markNullStatus(this.local.binding, nullStatus);
/*     */       } 
/*     */       
/* 103 */       return patternInfo;
/*     */     } 
/* 105 */     return flowInfo;
/*     */   }
/*     */   
/*     */   public void generateOptimizedBoolean(BlockScope currentScope, CodeStream codeStream, BranchLabel trueLabel, BranchLabel falseLabel) {
/* 109 */     if (this.local != null) {
/* 110 */       LocalVariableBinding localBinding = this.local.binding;
/* 111 */       if (!this.isTotalTypeNode) {
/* 112 */         codeStream.checkcast(localBinding.type);
/*     */       }
/* 114 */       this.local.generateCode(currentScope, codeStream);
/* 115 */       codeStream.store(localBinding, false);
/* 116 */       localBinding.recordInitializationStartPC(codeStream.position);
/*     */     } 
/*     */   }
/*     */   public void initializePatternVariables(BlockScope currentScope, CodeStream codeStream) {
/* 120 */     codeStream.addVariable(this.secretPatternVariable);
/* 121 */     codeStream.store(this.secretPatternVariable, false);
/*     */   }
/*     */   
/*     */   protected void generatePatternVariable(BlockScope currentScope, CodeStream codeStream, BranchLabel trueLabel, BranchLabel falseLabel) {
/* 125 */     if (this.local != null) {
/* 126 */       codeStream.load(this.secretPatternVariable);
/* 127 */       LocalVariableBinding localBinding = this.local.binding;
/* 128 */       if (!this.isTotalTypeNode)
/* 129 */         codeStream.checkcast(localBinding.type); 
/* 130 */       this.local.generateCode(currentScope, codeStream);
/* 131 */       codeStream.store(localBinding, false);
/* 132 */       localBinding.recordInitializationStartPC(codeStream.position);
/*     */     } 
/*     */   }
/*     */   
/*     */   public void wrapupGeneration(CodeStream codeStream) {
/* 137 */     codeStream.removeVariable(this.secretPatternVariable);
/*     */   }
/*     */   
/*     */   public LocalDeclaration getPatternVariable() {
/* 141 */     return this.local;
/*     */   }
/*     */   
/*     */   public void resolveWithExpression(BlockScope scope, Expression exp) {
/* 145 */     this.expression = exp;
/*     */   }
/*     */   
/*     */   public void resolve(BlockScope scope) {
/* 149 */     resolveType(scope);
/*     */   }
/*     */   
/*     */   public boolean isTotalForType(TypeBinding type) {
/* 153 */     if (type == null || this.resolvedType == null)
/* 154 */       return false; 
/* 155 */     return type.isSubtypeOf(this.resolvedType, false);
/*     */   }
/*     */   
/*     */   protected boolean isPatternTypeCompatible(TypeBinding other, BlockScope scope) {
/* 159 */     TypeBinding patternType = this.resolvedType;
/* 160 */     if (patternType.isBaseType()) {
/* 161 */       if (!TypeBinding.equalsEquals(other, patternType)) {
/* 162 */         scope.problemReporter().incompatiblePatternType(this, other, patternType);
/* 163 */         return false;
/*     */       } 
/* 165 */     } else if (!checkCastTypesCompatibility((Scope)scope, other, patternType, this.expression, true)) {
/* 166 */       scope.problemReporter().incompatiblePatternType(this, other, patternType);
/* 167 */       return false;
/*     */     } 
/* 169 */     return true;
/*     */   }
/*     */   
/*     */   public boolean dominates(Pattern p) {
/* 173 */     if (p.resolvedType == null || this.resolvedType == null)
/* 174 */       return false; 
/* 175 */     return p.resolvedType.erasure().isSubtypeOf(this.resolvedType.erasure(), false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TypeBinding resolveAtType(BlockScope scope, TypeBinding u) {
/* 185 */     if (this.resolvedType == null) {
/* 186 */       this.resolvedType = this.local.binding.type;
/*     */     }
/* 188 */     return this.resolvedType;
/*     */   }
/*     */   
/*     */   public TypeBinding resolveType(BlockScope scope, boolean isPatternVariable) {
/* 192 */     if (this.resolvedType != null)
/* 193 */       return this.resolvedType; 
/* 194 */     if (this.local != null) {
/* 195 */       this.local.modifiers |= 0x10000000;
/*     */ 
/*     */       
/* 198 */       if (this.local.isTypeNameVar((Scope)scope)) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 204 */         Pattern enclosingPattern = getEnclosingPattern();
/* 205 */         if (enclosingPattern instanceof RecordPattern) {
/* 206 */           ReferenceBinding recType = (ReferenceBinding)enclosingPattern.resolvedType;
/* 207 */           if (recType != null) {
/* 208 */             RecordComponentBinding[] components = recType.components();
/* 209 */             if (components.length > this.index) {
/* 210 */               RecordComponentBinding rcb = components[this.index];
/* 211 */               TypeVariableBinding[] mentionedTypeVariables = findSyntheticTypeVariables(rcb.type);
/* 212 */               if (mentionedTypeVariables != null && mentionedTypeVariables.length > 0) {
/* 213 */                 this.local.type.resolvedType = (TypeBinding)recType.upwardsProjection((Scope)scope, (TypeBinding[])mentionedTypeVariables);
/*     */               } else {
/* 215 */                 this.local.type.resolvedType = rcb.type;
/*     */               } 
/*     */             } 
/*     */           } 
/*     */         } 
/*     */       } 
/* 221 */       this.local.resolve(scope, isPatternVariable);
/* 222 */       if (this.local.binding != null) {
/* 223 */         this.local.binding.modifiers |= 0x10000000;
/* 224 */         this.local.binding.useFlag = 1;
/* 225 */         this.resolvedType = this.local.binding.type;
/*     */       } 
/* 227 */       initSecretPatternVariable(scope);
/*     */     } 
/*     */     
/* 230 */     return this.resolvedType;
/*     */   }
/*     */   
/*     */   private TypeVariableBinding[] findSyntheticTypeVariables(TypeBinding typeBinding) {
/* 234 */     final Set<TypeVariableBinding> mentioned = new HashSet<>();
/* 235 */     TypeBindingVisitor.visit(new TypeBindingVisitor()
/*     */         {
/*     */           public boolean visit(TypeVariableBinding typeVariable) {
/* 238 */             if (typeVariable.isCapture())
/* 239 */               mentioned.add(typeVariable); 
/* 240 */             return super.visit(typeVariable);
/*     */           }
/* 242 */         },  typeBinding);
/* 243 */     if (mentioned.isEmpty()) return null; 
/* 244 */     return mentioned.<TypeVariableBinding>toArray(new TypeVariableBinding[mentioned.size()]);
/*     */   }
/*     */   protected void initSecretPatternVariable(BlockScope scope) {
/* 247 */     LocalVariableBinding l = 
/* 248 */       this.secretPatternVariable = 
/* 249 */       new LocalVariableBinding(
/* 250 */         SECRET_PATTERN_VARIABLE_NAME, 
/* 251 */         this.resolvedType, 
/* 252 */         0, 
/* 253 */         false);
/* 254 */     l.setConstant(Constant.NotAConstant);
/* 255 */     l.useFlag = 1;
/* 256 */     scope.addLocalVariable(l);
/*     */   }
/*     */ 
/*     */   
/*     */   public void traverse(ASTVisitor visitor, BlockScope scope) {
/* 261 */     if (visitor.visit(this, scope) && 
/* 262 */       this.local != null) {
/* 263 */       this.local.traverse(visitor, scope);
/*     */     }
/* 265 */     visitor.endVisit(this, scope);
/*     */   }
/*     */ 
/*     */   
/*     */   public StringBuffer printExpression(int indent, StringBuffer output) {
/* 270 */     return (this.local != null) ? this.local.printAsExpression(indent, output) : output;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\ast\TypePattern.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */