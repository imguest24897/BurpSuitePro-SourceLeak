/*     */ package org.eclipse.jdt.internal.compiler.apt.model;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import javax.lang.model.element.ModuleElement;
/*     */ import javax.lang.model.element.PackageElement;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.Binding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.ModuleBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.PackageBinding;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ abstract class PackageDirectiveImpl
/*     */ {
/*     */   final PackageBinding binding1;
/*     */   List<ModuleElement> targets;
/*     */   
/*     */   PackageDirectiveImpl(PackageBinding pBinding) {
/* 186 */     this.binding1 = pBinding;
/*     */   }
/*     */   
/*     */   public PackageElement getPackage() {
/* 190 */     return ModuleElementImpl.this._env.getFactory().newPackageElement(this.binding1);
/*     */   }
/*     */   
/*     */   public List<? extends ModuleElement> getTargetModules(String[] restrictions) {
/* 194 */     if (this.targets != null) {
/* 195 */       return this.targets;
/*     */     }
/* 197 */     if (restrictions.length == 0) {
/* 198 */       return this.targets = null;
/*     */     }
/* 200 */     List<ModuleElement> targets1 = new ArrayList<>(restrictions.length); byte b; int i; String[] arrayOfString;
/* 201 */     for (i = (arrayOfString = restrictions).length, b = 0; b < i; ) { String string = arrayOfString[b];
/* 202 */       ModuleBinding target = ModuleElementImpl.this.binding.environment.getModule(string.toCharArray());
/* 203 */       if (target != null) {
/* 204 */         ModuleElement element = (ModuleElement)ModuleElementImpl.this._env.getFactory().newElement((Binding)target);
/* 205 */         targets1.add(element);
/*     */       }  b++; }
/*     */     
/* 208 */     return this.targets = Collections.unmodifiableList(targets1);
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\apt\model\ModuleElementImpl$PackageDirectiveImpl.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */