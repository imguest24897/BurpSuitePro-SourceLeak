/*      */ package org.eclipse.jdt.internal.compiler.ast;
/*      */ 
/*      */ import java.util.ArrayList;
/*      */ import java.util.Arrays;
/*      */ import java.util.HashMap;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.function.Function;
/*      */ import org.eclipse.jdt.internal.compiler.ASTVisitor;
/*      */ import org.eclipse.jdt.internal.compiler.codegen.BranchLabel;
/*      */ import org.eclipse.jdt.internal.compiler.codegen.CaseLabel;
/*      */ import org.eclipse.jdt.internal.compiler.codegen.CodeStream;
/*      */ import org.eclipse.jdt.internal.compiler.flow.FlowContext;
/*      */ import org.eclipse.jdt.internal.compiler.flow.FlowInfo;
/*      */ import org.eclipse.jdt.internal.compiler.flow.SwitchFlowContext;
/*      */ import org.eclipse.jdt.internal.compiler.flow.UnconditionalFlowInfo;
/*      */ import org.eclipse.jdt.internal.compiler.impl.CompilerOptions;
/*      */ import org.eclipse.jdt.internal.compiler.impl.Constant;
/*      */ import org.eclipse.jdt.internal.compiler.impl.JavaFeature;
/*      */ import org.eclipse.jdt.internal.compiler.lookup.BlockScope;
/*      */ import org.eclipse.jdt.internal.compiler.lookup.FieldBinding;
/*      */ import org.eclipse.jdt.internal.compiler.lookup.LocalVariableBinding;
/*      */ import org.eclipse.jdt.internal.compiler.lookup.MethodBinding;
/*      */ import org.eclipse.jdt.internal.compiler.lookup.ReferenceBinding;
/*      */ import org.eclipse.jdt.internal.compiler.lookup.Scope;
/*      */ import org.eclipse.jdt.internal.compiler.lookup.SourceTypeBinding;
/*      */ import org.eclipse.jdt.internal.compiler.lookup.SyntheticMethodBinding;
/*      */ import org.eclipse.jdt.internal.compiler.lookup.TypeBinding;
/*      */ import org.eclipse.jdt.internal.compiler.lookup.TypeVariableBinding;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class SwitchStatement
/*      */   extends Expression
/*      */ {
/*      */   public Expression expression;
/*      */   public Statement[] statements;
/*      */   public BlockScope scope;
/*      */   public int explicitDeclarations;
/*      */   public BranchLabel breakLabel;
/*      */   public CaseStatement[] cases;
/*      */   public CaseStatement defaultCase;
/*      */   public CaseStatement nullCase;
/*      */   public int blockStart;
/*      */   public int caseCount;
/*      */   int[] constants;
/*      */   int[] constMapping;
/*      */   public CaseStatement.ResolvedCase[] otherConstants;
/*      */   public int nConstants;
/*      */   public int switchBits;
/*      */   public boolean containsPatterns;
/*      */   public boolean containsNull;
/*      */   BranchLabel switchPatternRestartTarget;
/*      */   public Pattern totalPattern;
/*      */   public static final int CASE = 0;
/*      */   public static final int FALLTHROUGH = 1;
/*      */   public static final int ESCAPING = 2;
/*      */   public static final int BREAKING = 3;
/*      */   public static final int LabeledRules = 1;
/*      */   public static final int NullCase = 2;
/*      */   public static final int TotalPattern = 4;
/*      */   public static final int Exhaustive = 8;
/*      */   public static final int Enhanced = 16;
/*      */   public static final int Synthetic = 32;
/*   95 */   private static final char[] SecretStringVariableName = " switchDispatchString".toCharArray();
/*      */ 
/*      */   
/*   98 */   static final char[] SecretPatternVariableName = " switchDispatchPattern".toCharArray();
/*   99 */   private static final char[] SecretPatternRestartIndexName = " switchPatternRestartIndex".toCharArray();
/*      */ 
/*      */   
/*      */   public SyntheticMethodBinding synthetic;
/*      */   
/*  104 */   int preSwitchInitStateIndex = -1;
/*  105 */   int mergedInitStateIndex = -1;
/*      */   
/*  107 */   Statement[] duplicateCases = null;
/*  108 */   int duplicateCaseCounter = 0;
/*  109 */   private LocalVariableBinding dispatchStringCopy = null;
/*  110 */   private LocalVariableBinding dispatchPatternCopy = null;
/*  111 */   private LocalVariableBinding restartIndexLocal = null;
/*      */   
/*      */   boolean isNonTraditional = false;
/*  114 */   List<Pattern> caseLabelElements = new ArrayList<>(0);
/*  115 */   public List<TypeBinding> caseLabelElementTypes = new ArrayList<>(0);
/*  116 */   int constantIndex = 0;
/*      */   
/*      */   protected int getFallThroughState(Statement stmt, BlockScope blockScope) {
/*  119 */     if ((this.switchBits & 0x1) != 0) {
/*  120 */       if ((stmt instanceof Expression && ((Expression)stmt).isTrulyExpression()) || stmt instanceof ThrowStatement)
/*  121 */         return 3; 
/*  122 */       if (!stmt.canCompleteNormally()) {
/*  123 */         return 3;
/*      */       }
/*  125 */       if (stmt instanceof Block) {
/*  126 */         Block block = (Block)stmt;
/*      */         
/*  128 */         BreakStatement breakStatement = new BreakStatement(null, block.sourceEnd - 1, block.sourceEnd);
/*  129 */         breakStatement.isSynthetic = true;
/*      */         
/*  131 */         int l = (block.statements == null) ? 0 : block.statements.length;
/*  132 */         if (l == 0) {
/*  133 */           block.statements = new Statement[] { breakStatement };
/*  134 */           block.scope = this.scope;
/*      */         } else {
/*  136 */           Statement[] newArray = new Statement[l + 1];
/*  137 */           System.arraycopy(block.statements, 0, newArray, 0, l);
/*  138 */           newArray[l] = breakStatement;
/*  139 */           block.statements = newArray;
/*      */         } 
/*  141 */         return 3;
/*      */       } 
/*      */     } 
/*  144 */     return 1;
/*      */   }
/*      */   
/*      */   protected void completeNormallyCheck(BlockScope blockScope) {}
/*      */   
/*      */   protected boolean needToCheckFlowInAbsenceOfDefaultBranch() {
/*  150 */     return !isExhaustive();
/*      */   }
/*      */   public FlowInfo analyseCode(BlockScope currentScope, FlowContext flowContext, FlowInfo flowInfo) {
/*      */     try {
/*      */       FlowInfo flowInfo1;
/*  155 */       flowInfo = this.expression.analyseCode(currentScope, flowContext, flowInfo);
/*  156 */       if (isNullHostile()) {
/*  157 */         this.expression.checkNPE(currentScope, flowContext, flowInfo, 1);
/*      */       }
/*  159 */       SwitchFlowContext switchContext = 
/*  160 */         new SwitchFlowContext(flowContext, this, this.breakLabel = new BranchLabel(), true, true);
/*  161 */       switchContext.isExpression = this instanceof SwitchExpression;
/*      */ 
/*      */ 
/*      */       
/*  165 */       UnconditionalFlowInfo unconditionalFlowInfo1 = FlowInfo.DEAD_END;
/*      */       
/*  167 */       this.preSwitchInitStateIndex = currentScope.methodScope().recordInitializationStates(flowInfo);
/*  168 */       int caseIndex = 0;
/*  169 */       if (this.statements != null) {
/*  170 */         int initialComplaintLevel = ((flowInfo.reachMode() & 0x3) != 0) ? 1 : 0;
/*  171 */         int complaintLevel = initialComplaintLevel;
/*  172 */         int fallThroughState = 0;
/*  173 */         int prevCaseStmtIndex = -100;
/*  174 */         for (int i = 0, max = this.statements.length; i < max; i++) {
/*  175 */           Statement statement = this.statements[i];
/*  176 */           if (caseIndex < this.caseCount && statement == this.cases[caseIndex]) {
/*  177 */             this.scope.enclosingCase = this.cases[caseIndex];
/*  178 */             caseIndex++;
/*  179 */             if (prevCaseStmtIndex == i - 1 && (
/*  180 */               (CaseStatement)this.statements[prevCaseStmtIndex]).containsPatternVariable()) {
/*  181 */               this.scope.problemReporter().illegalFallthroughFromAPattern(this.statements[prevCaseStmtIndex]);
/*      */             }
/*  183 */             prevCaseStmtIndex = i;
/*  184 */             if (fallThroughState == 1 && complaintLevel <= 0) {
/*  185 */               if (((CaseStatement)statement).containsPatternVariable()) {
/*  186 */                 this.scope.problemReporter().IllegalFallThroughToPattern(this.scope.enclosingCase);
/*  187 */               } else if ((statement.bits & 0x20000000) == 0) {
/*  188 */                 this.scope.problemReporter().possibleFallThroughCase(this.scope.enclosingCase);
/*      */               } 
/*      */             }
/*  191 */             unconditionalFlowInfo1 = unconditionalFlowInfo1.mergedWith(flowInfo.unconditionalInits());
/*  192 */             complaintLevel = initialComplaintLevel;
/*  193 */             fallThroughState = this.containsPatterns ? 1 : 0;
/*  194 */           } else if (statement == this.defaultCase) {
/*  195 */             this.scope.enclosingCase = this.defaultCase;
/*  196 */             if (fallThroughState == 1 && 
/*  197 */               complaintLevel <= 0 && (
/*  198 */               statement.bits & 0x20000000) == 0) {
/*  199 */               this.scope.problemReporter().possibleFallThroughCase(this.scope.enclosingCase);
/*      */             }
/*  201 */             unconditionalFlowInfo1 = unconditionalFlowInfo1.mergedWith(flowInfo.unconditionalInits());
/*  202 */             if ((this.switchBits & 0x1) != 0 && this.expression.resolvedType instanceof ReferenceBinding) {
/*  203 */               if (this.expression instanceof NameReference) {
/*      */                 
/*  205 */                 NameReference reference = (NameReference)this.expression;
/*  206 */                 if (reference.localVariableBinding() != null) {
/*  207 */                   unconditionalFlowInfo1.markAsDefinitelyNonNull(reference.localVariableBinding());
/*  208 */                 } else if (reference.lastFieldBinding() != null && 
/*  209 */                   (this.scope.compilerOptions()).enableSyntacticNullAnalysisForFields) {
/*  210 */                   switchContext.recordNullCheckedFieldReference(reference, 2);
/*      */                 } 
/*  212 */               } else if (this.expression instanceof FieldReference && 
/*  213 */                 (this.scope.compilerOptions()).enableSyntacticNullAnalysisForFields) {
/*  214 */                 switchContext.recordNullCheckedFieldReference((FieldReference)this.expression, 2);
/*      */               } 
/*      */             }
/*  217 */             complaintLevel = initialComplaintLevel;
/*  218 */             fallThroughState = this.containsPatterns ? 1 : 0;
/*      */           } else {
/*  220 */             if (!(this instanceof SwitchExpression) && 
/*  221 */               (currentScope.compilerOptions()).complianceLevel >= 3801088L && 
/*  222 */               statement instanceof YieldStatement && 
/*  223 */               ((YieldStatement)statement).isImplicit) {
/*  224 */               YieldStatement y = (YieldStatement)statement;
/*  225 */               Expression e = ((YieldStatement)statement).expression;
/*      */ 
/*      */ 
/*      */               
/*  229 */               if (!y.expression.statementExpression()) {
/*  230 */                 this.scope.problemReporter().invalidExpressionAsStatement(e);
/*      */               }
/*      */             } 
/*  233 */             fallThroughState = getFallThroughState(statement, currentScope);
/*      */           } 
/*  235 */           if ((complaintLevel = statement.complainIfUnreachable((FlowInfo)unconditionalFlowInfo1, this.scope, complaintLevel, true)) < 2) {
/*  236 */             flowInfo1 = statement.analyseCode(this.scope, (FlowContext)switchContext, (FlowInfo)unconditionalFlowInfo1);
/*  237 */             if (flowInfo1 == FlowInfo.DEAD_END) {
/*  238 */               fallThroughState = 2;
/*      */             }
/*  240 */             switchContext.expireNullCheckedFieldInfo();
/*      */           } 
/*      */         } 
/*  243 */         completeNormallyCheck(currentScope);
/*      */       } 
/*      */       
/*  246 */       TypeBinding resolvedTypeBinding = this.expression.resolvedType;
/*  247 */       if (resolvedTypeBinding.isEnum()) {
/*  248 */         SourceTypeBinding sourceTypeBinding = (currentScope.classScope()).referenceContext.binding;
/*  249 */         this.synthetic = sourceTypeBinding.addSyntheticMethodForSwitchEnum(resolvedTypeBinding, this);
/*      */       } 
/*      */       
/*  252 */       if (this.defaultCase == null && needToCheckFlowInAbsenceOfDefaultBranch()) {
/*      */         
/*  254 */         flowInfo.addPotentialInitializationsFrom((FlowInfo)flowInfo1.mergedWith(switchContext.initsOnBreak));
/*  255 */         this.mergedInitStateIndex = currentScope.methodScope().recordInitializationStates(flowInfo);
/*  256 */         return flowInfo;
/*      */       } 
/*      */ 
/*      */       
/*  260 */       UnconditionalFlowInfo unconditionalFlowInfo2 = flowInfo1.mergedWith(switchContext.initsOnBreak);
/*  261 */       this.mergedInitStateIndex = 
/*  262 */         currentScope.methodScope().recordInitializationStates((FlowInfo)unconditionalFlowInfo2);
/*  263 */       return (FlowInfo)unconditionalFlowInfo2;
/*      */     } finally {
/*  265 */       if (this.scope != null) this.scope.enclosingCase = null; 
/*      */     } 
/*      */   }
/*      */   private boolean isNullHostile() {
/*  269 */     if ((this.expression.implicitConversion & 0x400) != 0)
/*  270 */       return true; 
/*  271 */     if (this.expression.resolvedType != null && (
/*  272 */       this.expression.resolvedType.id == 11 || this.expression.resolvedType.isEnum()))
/*  273 */       return true; 
/*  274 */     if ((this.switchBits & 0x3) == 1 && this.totalPattern == null) {
/*  275 */       return true;
/*      */     }
/*  277 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void generateCodeForStringSwitch(BlockScope currentScope, CodeStream codeStream) {
/*      */     
/*  293 */     try { if ((this.bits & Integer.MIN_VALUE) == 0) {
/*      */         return;
/*      */       }
/*  296 */       int pc = codeStream.position;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  351 */       boolean hasCases = (this.caseCount != 0);
/*  352 */       int constSize = hasCases ? this.otherConstants.length : 0;
/*  353 */       BranchLabel[] sourceCaseLabels = gatherLabels(codeStream, new BranchLabel[this.nConstants], BranchLabel::new);
/*  354 */       StringSwitchCase[] stringCases = new StringSwitchCase[constSize];
/*  355 */       CaseLabel[] hashCodeCaseLabels = new CaseLabel[constSize];
/*  356 */       this.constants = new int[constSize];
/*  357 */       for (int i = 0; i < constSize; i++) {
/*  358 */         String literal = (this.otherConstants[i]).c.stringValue();
/*  359 */         stringCases[i] = new StringSwitchCase(literal.hashCode(), literal, sourceCaseLabels[this.constMapping[i]]);
/*  360 */         hashCodeCaseLabels[i] = new CaseLabel(codeStream);
/*  361 */         (hashCodeCaseLabels[i]).tagBits |= 0x2;
/*      */       } 
/*  363 */       Arrays.sort((Object[])stringCases);
/*      */       
/*  365 */       int uniqHashCount = 0;
/*  366 */       int lastHashCode = 0;
/*  367 */       for (int j = 0, length = constSize; j < length; j++) {
/*  368 */         int hashCode = (stringCases[j]).hashCode;
/*  369 */         if (j == 0 || hashCode != lastHashCode) {
/*  370 */           lastHashCode = this.constants[uniqHashCount++] = hashCode;
/*      */         }
/*      */       } 
/*      */       
/*  374 */       if (uniqHashCount != constSize) {
/*  375 */         System.arraycopy(this.constants, 0, this.constants = new int[uniqHashCount], 0, uniqHashCount);
/*  376 */         System.arraycopy(hashCodeCaseLabels, 0, hashCodeCaseLabels = new CaseLabel[uniqHashCount], 0, uniqHashCount);
/*      */       } 
/*  378 */       int[] sortedIndexes = new int[uniqHashCount];
/*  379 */       for (int k = 0; k < uniqHashCount; k++) {
/*  380 */         sortedIndexes[k] = k;
/*      */       }
/*      */       
/*  383 */       CaseLabel defaultCaseLabel = new CaseLabel(codeStream);
/*  384 */       defaultCaseLabel.tagBits |= 0x2;
/*      */ 
/*      */       
/*  387 */       this.breakLabel.initialize(codeStream);
/*      */       
/*  389 */       BranchLabel defaultBranchLabel = new BranchLabel(codeStream);
/*  390 */       if (hasCases) defaultBranchLabel.tagBits |= 0x2; 
/*  391 */       if (this.defaultCase != null) {
/*  392 */         this.defaultCase.targetLabel = defaultBranchLabel;
/*      */       }
/*      */       
/*  395 */       this.expression.generateCode(currentScope, codeStream, true);
/*  396 */       codeStream.store(this.dispatchStringCopy, true);
/*  397 */       codeStream.addVariable(this.dispatchStringCopy);
/*  398 */       codeStream.invokeStringHashCode();
/*  399 */       if (hasCases) {
/*  400 */         codeStream.lookupswitch(defaultCaseLabel, this.constants, sortedIndexes, hashCodeCaseLabels);
/*  401 */         for (int m = 0, n = 0, max = constSize; m < max; m++) {
/*  402 */           int hashCode = (stringCases[m]).hashCode;
/*  403 */           if (m == 0 || hashCode != lastHashCode) {
/*  404 */             lastHashCode = hashCode;
/*  405 */             if (m != 0) {
/*  406 */               codeStream.goto_(defaultBranchLabel);
/*      */             }
/*  408 */             hashCodeCaseLabels[n++].place();
/*      */           } 
/*  410 */           codeStream.load(this.dispatchStringCopy);
/*  411 */           codeStream.ldc((stringCases[m]).string);
/*  412 */           codeStream.invokeStringEquals();
/*  413 */           codeStream.ifne((stringCases[m]).label);
/*      */         } 
/*  415 */         codeStream.goto_(defaultBranchLabel);
/*      */       } else {
/*  417 */         codeStream.pop();
/*      */       } 
/*      */ 
/*      */       
/*  421 */       int caseIndex = 0;
/*  422 */       if (this.statements != null) {
/*  423 */         for (int m = 0, maxCases = this.statements.length; m < maxCases; m++) {
/*  424 */           Statement statement = this.statements[m];
/*  425 */           if (caseIndex < this.caseCount && statement == this.cases[caseIndex]) {
/*  426 */             this.scope.enclosingCase = this.cases[caseIndex];
/*  427 */             if (this.preSwitchInitStateIndex != -1) {
/*  428 */               codeStream.removeNotDefinitelyAssignedVariables((Scope)currentScope, this.preSwitchInitStateIndex);
/*      */             }
/*  430 */             if (statement == this.defaultCase) {
/*  431 */               defaultCaseLabel.place();
/*      */             }
/*  433 */             caseIndex++;
/*      */           }
/*  435 */           else if (statement == this.defaultCase) {
/*  436 */             defaultCaseLabel.place();
/*  437 */             this.scope.enclosingCase = this.defaultCase;
/*  438 */             if (this.preSwitchInitStateIndex != -1) {
/*  439 */               codeStream.removeNotDefinitelyAssignedVariables((Scope)currentScope, this.preSwitchInitStateIndex);
/*      */             }
/*      */           } 
/*      */           
/*  443 */           statementGenerateCode(currentScope, codeStream, statement);
/*      */         } 
/*      */       }
/*      */ 
/*      */       
/*  448 */       if (this.mergedInitStateIndex != -1) {
/*  449 */         codeStream.removeNotDefinitelyAssignedVariables((Scope)currentScope, this.mergedInitStateIndex);
/*  450 */         codeStream.addDefinitelyAssignedVariables((Scope)currentScope, this.mergedInitStateIndex);
/*      */       } 
/*  452 */       codeStream.removeVariable(this.dispatchStringCopy);
/*  453 */       if (this.scope != currentScope) {
/*  454 */         codeStream.exitUserScope(this.scope);
/*      */       }
/*      */       
/*  457 */       this.breakLabel.place();
/*  458 */       if (this.defaultCase == null) {
/*      */         
/*  460 */         codeStream.recordPositionsFrom(codeStream.position, this.sourceEnd, true);
/*  461 */         defaultCaseLabel.place();
/*  462 */         defaultBranchLabel.place();
/*      */       } 
/*  464 */       if (expectedType() != null) {
/*  465 */         TypeBinding expectedType = expectedType().erasure();
/*  466 */         boolean optimizedGoto = (codeStream.lastAbruptCompletion == -1);
/*      */ 
/*      */         
/*  469 */         codeStream.recordExpressionType(expectedType, optimizedGoto ? 0 : 1, optimizedGoto);
/*      */       }  }
/*      */     finally
/*      */     
/*  473 */     { if (this.scope != null) this.scope.enclosingCase = null;  }  class StringSwitchCase implements Comparable { int hashCode; String string; BranchLabel label; public StringSwitchCase(int hashCode, String string, BranchLabel label) { this.hashCode = hashCode; this.string = string; this.label = label; } public int compareTo(Object o) { StringSwitchCase that = (StringSwitchCase)o; if (this.hashCode == that.hashCode) return 0;  if (this.hashCode > that.hashCode) return 1;  return -1; } public String toString() { return "StringSwitchCase :\ncase " + this.hashCode + ":(" + this.string + ")\n"; } }; if (this.scope != null) this.scope.enclosingCase = null;
/*      */   
/*      */   }
/*      */ 
/*      */   
/*      */   private <T extends BranchLabel> T[] gatherLabels(CodeStream codeStream, BranchLabel[] caseLabels, Function<CodeStream, T> newLabel) {
/*  479 */     for (int i = 0, j = 0, max = this.caseCount; i < max; i++) {
/*  480 */       CaseStatement stmt = this.cases[i];
/*  481 */       int l = stmt.constantExpressions.length;
/*  482 */       BranchLabel[] targetLabels = new BranchLabel[l];
/*  483 */       int count = 0;
/*  484 */       for (int k = 0; k < l; k++) {
/*  485 */         Expression e = stmt.constantExpressions[k];
/*  486 */         if (!(e instanceof FakeDefaultLiteral)) {
/*  487 */           caseLabels[j] = (BranchLabel)newLabel.apply(codeStream); targetLabels[count++] = (BranchLabel)newLabel.apply(codeStream);
/*  488 */           if (e == this.totalPattern)
/*  489 */             this.defaultCase = stmt; 
/*  490 */           (caseLabels[j++]).tagBits |= 0x2;
/*      */         } 
/*  492 */       }  System.arraycopy(targetLabels, 0, stmt.targetLabels = new BranchLabel[count], 0, count);
/*      */     } 
/*  494 */     return (T[])caseLabels;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void generateCode(BlockScope currentScope, CodeStream codeStream) {
/*  504 */     if (this.expression.resolvedType.id == 11 && !this.isNonTraditional) {
/*  505 */       generateCodeForStringSwitch(currentScope, codeStream);
/*      */       return;
/*      */     } 
/*      */     
/*  509 */     try { if ((this.bits & Integer.MIN_VALUE) == 0) {
/*      */         return;
/*      */       }
/*  512 */       int pc = codeStream.position;
/*      */ 
/*      */       
/*  515 */       this.breakLabel.initialize(codeStream);
/*  516 */       int constantCount = (this.otherConstants == null) ? 0 : this.otherConstants.length;
/*  517 */       CaseLabel[] caseLabels = gatherLabels(codeStream, new CaseLabel[this.nConstants], CaseLabel::new);
/*      */       
/*  519 */       CaseLabel defaultLabel = new CaseLabel(codeStream);
/*  520 */       boolean hasCases = (this.caseCount != 0);
/*  521 */       if (hasCases) defaultLabel.tagBits |= 0x2; 
/*  522 */       if (this.defaultCase != null) {
/*  523 */         this.defaultCase.targetLabel = (BranchLabel)defaultLabel;
/*      */       }
/*      */       
/*  526 */       TypeBinding resolvedType1 = this.expression.resolvedType;
/*  527 */       boolean valueRequired = false;
/*  528 */       if (this.containsPatterns || isNullAndNeedsPatternVar()) {
/*  529 */         generateCodeSwitchPatternPrologue(currentScope, codeStream);
/*  530 */         valueRequired = true;
/*  531 */         transformConstants();
/*  532 */       } else if (resolvedType1.isEnum()) {
/*      */         
/*  534 */         codeStream.invoke((byte)-72, (MethodBinding)this.synthetic, null);
/*  535 */         this.expression.generateCode(currentScope, codeStream, true);
/*      */         
/*  537 */         codeStream.invokeEnumOrdinal(resolvedType1.constantPoolName());
/*  538 */         codeStream.iaload();
/*  539 */         if (!hasCases)
/*      */         {
/*  541 */           codeStream.pop();
/*      */         }
/*  543 */         valueRequired = hasCases;
/*      */       } else {
/*  545 */         valueRequired = !(this.expression.constant != Constant.NotAConstant && !hasCases);
/*      */         
/*  547 */         this.expression.generateCode(currentScope, codeStream, valueRequired);
/*      */       } 
/*      */       
/*  550 */       if (hasCases) {
/*  551 */         int[] sortedIndexes = new int[constantCount];
/*      */         
/*  553 */         for (int i = 0; i < constantCount; i++) {
/*  554 */           sortedIndexes[i] = i;
/*      */         }
/*      */         int[] localKeysCopy;
/*  557 */         System.arraycopy(this.constants, 0, localKeysCopy = new int[constantCount], 0, constantCount);
/*  558 */         CodeStream.sort(localKeysCopy, 0, constantCount - 1, sortedIndexes);
/*      */         
/*  560 */         int max = localKeysCopy[constantCount - 1];
/*  561 */         int min = localKeysCopy[0];
/*  562 */         if ((long)(constantCount * 2.5D) > max - min) {
/*      */ 
/*      */ 
/*      */           
/*  566 */           if (max > 2147418112 && (currentScope.compilerOptions()).complianceLevel < 3145728L) {
/*  567 */             codeStream.lookupswitch(defaultLabel, this.constants, sortedIndexes, caseLabels);
/*      */           } else {
/*      */             
/*  570 */             codeStream.tableswitch(
/*  571 */                 defaultLabel, 
/*  572 */                 min, 
/*  573 */                 max, 
/*  574 */                 this.constants, 
/*  575 */                 sortedIndexes, 
/*  576 */                 this.constMapping, 
/*  577 */                 caseLabels);
/*      */           } 
/*      */         } else {
/*  580 */           codeStream.lookupswitch(defaultLabel, this.constants, sortedIndexes, caseLabels);
/*      */         } 
/*  582 */         codeStream.recordPositionsFrom(codeStream.position, this.expression.sourceEnd);
/*  583 */       } else if (valueRequired) {
/*  584 */         codeStream.pop();
/*      */       } 
/*      */ 
/*      */       
/*  588 */       int caseIndex = 0;
/*  589 */       int typeSwitchIndex = 0;
/*  590 */       if (this.statements != null) {
/*  591 */         for (int i = 0, maxCases = this.statements.length; i < maxCases; i++) {
/*  592 */           Statement statement = this.statements[i];
/*  593 */           CaseStatement caseStatement = null;
/*  594 */           if (caseIndex < constantCount && statement == this.cases[caseIndex]) {
/*  595 */             this.scope.enclosingCase = this.cases[caseIndex];
/*  596 */             if (this.preSwitchInitStateIndex != -1) {
/*  597 */               codeStream.removeNotDefinitelyAssignedVariables((Scope)currentScope, this.preSwitchInitStateIndex);
/*      */             }
/*  599 */             caseStatement = (CaseStatement)statement;
/*  600 */             patternCaseExitPreviousCaseScope(codeStream, caseIndex);
/*  601 */             caseIndex++;
/*  602 */             typeSwitchIndex += caseStatement.constantExpressions.length;
/*      */           }
/*  604 */           else if (statement == this.defaultCase) {
/*  605 */             this.scope.enclosingCase = this.defaultCase;
/*  606 */             if (this.preSwitchInitStateIndex != -1) {
/*  607 */               codeStream.removeNotDefinitelyAssignedVariables((Scope)currentScope, this.preSwitchInitStateIndex);
/*      */             }
/*  609 */           } else if (statement instanceof CaseStatement) {
/*  610 */             caseStatement = (CaseStatement)statement;
/*  611 */             typeSwitchIndex += caseStatement.constantExpressions.length;
/*      */           } 
/*      */           
/*  614 */           statementGenerateCode(currentScope, codeStream, statement);
/*  615 */           generateCodePatternCaseEpilogue(codeStream, typeSwitchIndex, caseStatement);
/*      */         } 
/*      */       }
/*  618 */       boolean enumInSwitchExpression = (resolvedType1.isEnum() && this instanceof SwitchExpression);
/*  619 */       boolean isEnumSwitchWithoutDefaultCase = (this.defaultCase == null && enumInSwitchExpression);
/*  620 */       CompilerOptions compilerOptions = (this.scope != null) ? this.scope.compilerOptions() : null;
/*  621 */       boolean isPatternSwitchSealedWithoutDefaultCase = (this.defaultCase == null && 
/*  622 */         compilerOptions != null && 
/*  623 */         this.containsPatterns && 
/*  624 */         JavaFeature.SEALED_CLASSES.isSupported(compilerOptions) && 
/*  625 */         JavaFeature.PATTERN_MATCHING_IN_SWITCH.isSupported(compilerOptions) && 
/*  626 */         this.expression.resolvedType instanceof ReferenceBinding && (
/*  627 */         (ReferenceBinding)this.expression.resolvedType).isSealed());
/*      */       
/*  629 */       if (isEnumSwitchWithoutDefaultCase || isPatternSwitchSealedWithoutDefaultCase) {
/*      */         
/*  631 */         if (this.preSwitchInitStateIndex != -1) {
/*  632 */           codeStream.removeNotDefinitelyAssignedVariables((Scope)currentScope, this.preSwitchInitStateIndex);
/*      */         }
/*  634 */         defaultLabel.place();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  643 */         if (compilerOptions.complianceLevel >= 4128768L) {
/*  644 */           codeStream.newJavaLangMatchException();
/*  645 */           codeStream.dup();
/*  646 */           codeStream.aconst_null();
/*  647 */           codeStream.aconst_null();
/*  648 */           codeStream.invokeJavaLangMatchExceptionConstructor();
/*  649 */           codeStream.athrow();
/*      */         } else {
/*  651 */           codeStream.newJavaLangIncompatibleClassChangeError();
/*  652 */           codeStream.dup();
/*  653 */           codeStream.invokeJavaLangIncompatibleClassChangeErrorDefaultConstructor();
/*  654 */           codeStream.athrow();
/*      */         } 
/*      */       } 
/*      */       
/*  658 */       if (this.mergedInitStateIndex != -1) {
/*  659 */         codeStream.removeNotDefinitelyAssignedVariables((Scope)currentScope, this.mergedInitStateIndex);
/*  660 */         codeStream.addDefinitelyAssignedVariables((Scope)currentScope, this.mergedInitStateIndex);
/*      */       } 
/*  662 */       generateCodeSwitchPatternEpilogue(codeStream);
/*  663 */       if (this.scope != currentScope) {
/*  664 */         codeStream.exitUserScope(this.scope);
/*      */       }
/*      */       
/*  667 */       this.breakLabel.place();
/*  668 */       if (this.defaultCase == null && !enumInSwitchExpression && !isPatternSwitchSealedWithoutDefaultCase) {
/*      */         
/*  670 */         codeStream.recordPositionsFrom(codeStream.position, this.sourceEnd, true);
/*  671 */         defaultLabel.place();
/*      */       } 
/*  673 */       if (this instanceof SwitchExpression) {
/*  674 */         TypeBinding switchResolveType = this.resolvedType;
/*  675 */         if (expectedType() != null) {
/*  676 */           switchResolveType = expectedType().erasure();
/*      */         }
/*  678 */         boolean optimizedGoto = (codeStream.lastAbruptCompletion == -1);
/*      */ 
/*      */         
/*  681 */         codeStream.recordExpressionType(switchResolveType, optimizedGoto ? 0 : 1, !(!optimizedGoto && !isEnumSwitchWithoutDefaultCase));
/*      */       }  }
/*      */     finally
/*      */     
/*  685 */     { if (this.scope != null) this.scope.enclosingCase = null;  }  if (this.scope != null) this.scope.enclosingCase = null; 
/*      */   }
/*      */   
/*      */   private void transformConstants() {
/*  689 */     if (this.nullCase == null) {
/*  690 */       for (int j = 0, l = this.otherConstants.length; j < l; j++) {
/*  691 */         if ((this.otherConstants[j]).e == this.totalPattern) {
/*  692 */           (this.otherConstants[j]).index = -1;
/*      */           break;
/*      */         } 
/*      */       } 
/*      */     }
/*  697 */     for (int i = 0; i < this.constants.length; i++)
/*  698 */       this.constants[i] = (this.otherConstants[i]).index; 
/*      */   }
/*      */   
/*      */   private void generateCodeSwitchPatternEpilogue(CodeStream codeStream) {
/*  702 */     if ((this.containsPatterns && this.caseLabelElements.size() > 0) || isNullAndNeedsPatternVar()) {
/*  703 */       codeStream.removeVariable(this.dispatchPatternCopy);
/*  704 */       codeStream.removeVariable(this.restartIndexLocal);
/*      */     } 
/*      */   }
/*      */   private void patternCaseExitPreviousCaseScope(CodeStream codeStream, int caseIndex) {
/*  708 */     if (caseIndex > 0) {
/*  709 */       CaseStatement caseStatement = this.cases[caseIndex];
/*  710 */       if (caseStatement.containsPatternVariable())
/*  711 */         caseStatement.patternCaseRemovePatternLocals(codeStream); 
/*      */     } 
/*      */   }
/*      */   
/*      */   private void generateCodePatternCaseEpilogue(CodeStream codeStream, int caseIndex, CaseStatement caseStatement) {
/*  716 */     if (this.switchPatternRestartTarget != null && caseStatement != null && 
/*  717 */       caseStatement.patternIndex != -1) {
/*      */       
/*  719 */       Pattern pattern = (Pattern)caseStatement.constantExpressions[caseStatement.patternIndex];
/*      */ 
/*      */       
/*  722 */       pattern.elseTarget.place();
/*  723 */       pattern.suspendVariables(codeStream, this.scope);
/*  724 */       if (!pattern.isAlwaysTrue()) {
/*  725 */         codeStream.loadInt(caseIndex);
/*  726 */         codeStream.store(this.restartIndexLocal, false);
/*  727 */         codeStream.goto_(this.switchPatternRestartTarget);
/*      */       } 
/*  729 */       pattern.thenTarget.place();
/*  730 */       pattern.resumeVariables(codeStream, this.scope);
/*      */     } 
/*      */   }
/*      */   private void generateCodeSwitchPatternPrologue(BlockScope currentScope, CodeStream codeStream) {
/*  734 */     this.expression.generateCode(currentScope, codeStream, true);
/*  735 */     if ((this.switchBits & 0x2) == 0) {
/*  736 */       codeStream.dup();
/*  737 */       codeStream.invokeJavaUtilObjectsrequireNonNull();
/*  738 */       codeStream.pop();
/*      */     } 
/*      */     
/*  741 */     codeStream.store(this.dispatchPatternCopy, false);
/*  742 */     codeStream.addVariable(this.dispatchPatternCopy);
/*      */     
/*  744 */     codeStream.loadInt(0);
/*  745 */     codeStream.store(this.restartIndexLocal, false);
/*  746 */     codeStream.addVariable(this.restartIndexLocal);
/*      */     
/*  748 */     this.switchPatternRestartTarget = new BranchLabel(codeStream);
/*  749 */     this.switchPatternRestartTarget.place();
/*      */     
/*  751 */     codeStream.load(this.dispatchPatternCopy);
/*  752 */     codeStream.load(this.restartIndexLocal);
/*  753 */     int invokeDynamicNumber = codeStream.classFile.recordBootstrapMethod(this);
/*  754 */     if (this.expression.resolvedType.isEnum()) {
/*  755 */       generateEnumSwitchPatternPrologue(codeStream, invokeDynamicNumber);
/*      */     } else {
/*  757 */       generateTypeSwitchPatternPrologue(codeStream, invokeDynamicNumber);
/*      */     } 
/*      */   }
/*      */   private void generateTypeSwitchPatternPrologue(CodeStream codeStream, int invokeDynamicNumber) {
/*  761 */     codeStream.invokeDynamic(invokeDynamicNumber, 
/*  762 */         2, 
/*  763 */         1, 
/*  764 */         "typeSwitch".toCharArray(), 
/*  765 */         "(Ljava/lang/Object;I)I".toCharArray(), 
/*  766 */         10, 
/*  767 */         (TypeBinding)TypeBinding.INT);
/*      */   }
/*      */   private void generateEnumSwitchPatternPrologue(CodeStream codeStream, int invokeDynamicNumber) {
/*  770 */     String genericTypeSignature = new String(this.expression.resolvedType.genericTypeSignature());
/*  771 */     String callingParams = "(" + genericTypeSignature + "I)I";
/*  772 */     codeStream.invokeDynamic(invokeDynamicNumber, 
/*  773 */         2, 
/*  774 */         1, 
/*  775 */         "enumSwitch".toCharArray(), 
/*  776 */         callingParams.toCharArray(), 
/*  777 */         10, 
/*  778 */         (TypeBinding)TypeBinding.INT);
/*      */   }
/*      */   protected void statementGenerateCode(BlockScope currentScope, CodeStream codeStream, Statement statement) {
/*  781 */     statement.generateCode(this.scope, codeStream);
/*      */   }
/*      */ 
/*      */   
/*      */   public void generateCode(BlockScope currentScope, CodeStream codeStream, boolean valueRequired) {
/*  786 */     generateCode(currentScope, codeStream);
/*      */   }
/*      */ 
/*      */   
/*      */   public StringBuffer printStatement(int indent, StringBuffer output) {
/*  791 */     printIndent(indent, output).append("switch (");
/*  792 */     this.expression.printExpression(0, output).append(") {");
/*  793 */     if (this.statements != null) {
/*  794 */       for (int i = 0; i < this.statements.length; i++) {
/*  795 */         output.append('\n');
/*  796 */         if (this.statements[i] instanceof CaseStatement) {
/*  797 */           this.statements[i].printStatement(indent, output);
/*      */         } else {
/*  799 */           this.statements[i].printStatement(indent + 2, output);
/*      */         } 
/*      */       } 
/*      */     }
/*  803 */     output.append("\n");
/*  804 */     return printIndent(indent, output).append('}');
/*      */   }
/*      */   
/*      */   private int getNConstants() {
/*  808 */     int n = 0;
/*  809 */     for (int i = 0, l = this.statements.length; i < l; i++) {
/*  810 */       Statement statement = this.statements[i];
/*  811 */       if (statement instanceof CaseStatement) {
/*  812 */         Expression[] exprs = ((CaseStatement)statement).constantExpressions;
/*  813 */         int count = 0;
/*  814 */         if (exprs != null) {
/*  815 */           byte b; int j; Expression[] arrayOfExpression; for (j = (arrayOfExpression = exprs).length, b = 0; b < j; ) { Expression e = arrayOfExpression[b];
/*  816 */             if (!(e instanceof FakeDefaultLiteral))
/*  817 */               count++;  b++; }
/*      */         
/*      */         } 
/*  820 */         n += count;
/*      */       } 
/*      */     } 
/*  823 */     return n;
/*      */   }
/*      */   
/*      */   protected void addSecretTryResultVariable() {}
/*      */   
/*      */   boolean isAllowedType(TypeBinding type) {
/*  829 */     if (type == null)
/*  830 */       return false; 
/*  831 */     switch (type.id) {
/*      */       case 2:
/*      */       case 3:
/*      */       case 4:
/*      */       case 10:
/*      */       case 26:
/*      */       case 27:
/*      */       case 28:
/*      */       case 29:
/*  840 */         return true;
/*      */     } 
/*      */     
/*  843 */     return false;
/*      */   }
/*      */   
/*      */   public void collectPatternVariablesToScope(LocalVariableBinding[] variables, BlockScope skope) {
/*  847 */     if (this.statements != null && this.containsPatterns) {
/*  848 */       byte b; int i; Statement[] arrayOfStatement; for (i = (arrayOfStatement = this.statements).length, b = 0; b < i; ) { Statement stmt = arrayOfStatement[b];
/*  849 */         if (stmt instanceof CaseStatement) {
/*  850 */           CaseStatement caseStatement = (CaseStatement)stmt;
/*  851 */           if (caseStatement.constantExpressions != null) {
/*  852 */             byte b1; int j; Expression[] arrayOfExpression; for (j = (arrayOfExpression = caseStatement.constantExpressions).length, b1 = 0; b1 < j; ) { Expression exp = arrayOfExpression[b1];
/*  853 */               exp.collectPatternVariablesToScope(variables, skope);
/*      */               b1++; }
/*      */           
/*      */           } 
/*      */         } 
/*      */         b++; }
/*      */     
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void resolve(BlockScope upperScope) {
/*      */     // Byte code:
/*      */     //   0: iconst_0
/*      */     //   1: istore_2
/*      */     //   2: iconst_0
/*      */     //   3: istore_3
/*      */     //   4: aload_0
/*      */     //   5: getfield expression : Lorg/eclipse/jdt/internal/compiler/ast/Expression;
/*      */     //   8: aload_1
/*      */     //   9: invokevirtual resolveType : (Lorg/eclipse/jdt/internal/compiler/lookup/BlockScope;)Lorg/eclipse/jdt/internal/compiler/lookup/TypeBinding;
/*      */     //   12: astore #4
/*      */     //   14: aload_1
/*      */     //   15: invokevirtual compilerOptions : ()Lorg/eclipse/jdt/internal/compiler/impl/CompilerOptions;
/*      */     //   18: astore #5
/*      */     //   20: aload_0
/*      */     //   21: aload_1
/*      */     //   22: aload #4
/*      */     //   24: invokevirtual checkAndSetEnhanced : (Lorg/eclipse/jdt/internal/compiler/lookup/BlockScope;Lorg/eclipse/jdt/internal/compiler/lookup/TypeBinding;)Z
/*      */     //   27: istore #6
/*      */     //   29: aload #4
/*      */     //   31: ifnull -> 274
/*      */     //   34: aload_0
/*      */     //   35: getfield expression : Lorg/eclipse/jdt/internal/compiler/ast/Expression;
/*      */     //   38: aload_1
/*      */     //   39: aload #4
/*      */     //   41: aload #4
/*      */     //   43: invokevirtual computeConversion : (Lorg/eclipse/jdt/internal/compiler/lookup/Scope;Lorg/eclipse/jdt/internal/compiler/lookup/TypeBinding;Lorg/eclipse/jdt/internal/compiler/lookup/TypeBinding;)V
/*      */     //   46: aload #4
/*      */     //   48: invokevirtual isValidBinding : ()Z
/*      */     //   51: ifne -> 60
/*      */     //   54: aconst_null
/*      */     //   55: astore #4
/*      */     //   57: goto -> 274
/*      */     //   60: aload #4
/*      */     //   62: invokevirtual isBaseType : ()Z
/*      */     //   65: ifeq -> 100
/*      */     //   68: aload_0
/*      */     //   69: getfield expression : Lorg/eclipse/jdt/internal/compiler/ast/Expression;
/*      */     //   72: aload #4
/*      */     //   74: getstatic org/eclipse/jdt/internal/compiler/lookup/TypeBinding.INT : Lorg/eclipse/jdt/internal/compiler/lookup/BaseTypeBinding;
/*      */     //   77: invokevirtual isConstantValueOfTypeAssignableToType : (Lorg/eclipse/jdt/internal/compiler/lookup/TypeBinding;Lorg/eclipse/jdt/internal/compiler/lookup/TypeBinding;)Z
/*      */     //   80: ifeq -> 86
/*      */     //   83: goto -> 274
/*      */     //   86: aload #4
/*      */     //   88: getstatic org/eclipse/jdt/internal/compiler/lookup/TypeBinding.INT : Lorg/eclipse/jdt/internal/compiler/lookup/BaseTypeBinding;
/*      */     //   91: invokevirtual isCompatibleWith : (Lorg/eclipse/jdt/internal/compiler/lookup/TypeBinding;)Z
/*      */     //   94: ifeq -> 239
/*      */     //   97: goto -> 274
/*      */     //   100: aload #4
/*      */     //   102: invokevirtual isEnum : ()Z
/*      */     //   105: ifeq -> 138
/*      */     //   108: iconst_1
/*      */     //   109: istore_2
/*      */     //   110: aload #5
/*      */     //   112: getfield complianceLevel : J
/*      */     //   115: ldc2_w 3211264
/*      */     //   118: lcmp
/*      */     //   119: ifge -> 274
/*      */     //   122: aload_1
/*      */     //   123: invokevirtual problemReporter : ()Lorg/eclipse/jdt/internal/compiler/problem/ProblemReporter;
/*      */     //   126: aload_0
/*      */     //   127: getfield expression : Lorg/eclipse/jdt/internal/compiler/ast/Expression;
/*      */     //   130: aload #4
/*      */     //   132: invokevirtual incorrectSwitchType : (Lorg/eclipse/jdt/internal/compiler/ast/Expression;Lorg/eclipse/jdt/internal/compiler/lookup/TypeBinding;)V
/*      */     //   135: goto -> 274
/*      */     //   138: aload_0
/*      */     //   139: getfield containsPatterns : Z
/*      */     //   142: ifne -> 173
/*      */     //   145: aload_1
/*      */     //   146: aload #4
/*      */     //   148: getstatic org/eclipse/jdt/internal/compiler/lookup/TypeBinding.INT : Lorg/eclipse/jdt/internal/compiler/lookup/BaseTypeBinding;
/*      */     //   151: invokevirtual isBoxingCompatibleWith : (Lorg/eclipse/jdt/internal/compiler/lookup/TypeBinding;Lorg/eclipse/jdt/internal/compiler/lookup/TypeBinding;)Z
/*      */     //   154: ifeq -> 173
/*      */     //   157: aload_0
/*      */     //   158: getfield expression : Lorg/eclipse/jdt/internal/compiler/ast/Expression;
/*      */     //   161: aload_1
/*      */     //   162: getstatic org/eclipse/jdt/internal/compiler/lookup/TypeBinding.INT : Lorg/eclipse/jdt/internal/compiler/lookup/BaseTypeBinding;
/*      */     //   165: aload #4
/*      */     //   167: invokevirtual computeConversion : (Lorg/eclipse/jdt/internal/compiler/lookup/Scope;Lorg/eclipse/jdt/internal/compiler/lookup/TypeBinding;Lorg/eclipse/jdt/internal/compiler/lookup/TypeBinding;)V
/*      */     //   170: goto -> 274
/*      */     //   173: aload #5
/*      */     //   175: getfield complianceLevel : J
/*      */     //   178: ldc2_w 3342336
/*      */     //   181: lcmp
/*      */     //   182: iflt -> 239
/*      */     //   185: aload #4
/*      */     //   187: getfield id : I
/*      */     //   190: bipush #11
/*      */     //   192: if_icmpne -> 239
/*      */     //   195: aload_0
/*      */     //   196: getfield containsPatterns : Z
/*      */     //   199: ifne -> 209
/*      */     //   202: aload_0
/*      */     //   203: getfield containsNull : Z
/*      */     //   206: ifeq -> 234
/*      */     //   209: getstatic org/eclipse/jdt/internal/compiler/impl/JavaFeature.PATTERN_MATCHING_IN_SWITCH : Lorg/eclipse/jdt/internal/compiler/impl/JavaFeature;
/*      */     //   212: aload #5
/*      */     //   214: invokevirtual isSupported : (Lorg/eclipse/jdt/internal/compiler/impl/CompilerOptions;)Z
/*      */     //   217: ifeq -> 224
/*      */     //   220: iconst_0
/*      */     //   221: goto -> 225
/*      */     //   224: iconst_1
/*      */     //   225: istore_3
/*      */     //   226: aload_0
/*      */     //   227: iconst_1
/*      */     //   228: putfield isNonTraditional : Z
/*      */     //   231: goto -> 274
/*      */     //   234: iconst_1
/*      */     //   235: istore_3
/*      */     //   236: goto -> 274
/*      */     //   239: getstatic org/eclipse/jdt/internal/compiler/impl/JavaFeature.PATTERN_MATCHING_IN_SWITCH : Lorg/eclipse/jdt/internal/compiler/impl/JavaFeature;
/*      */     //   242: aload #5
/*      */     //   244: invokevirtual isSupported : (Lorg/eclipse/jdt/internal/compiler/impl/CompilerOptions;)Z
/*      */     //   247: ifne -> 269
/*      */     //   250: aload_1
/*      */     //   251: invokevirtual problemReporter : ()Lorg/eclipse/jdt/internal/compiler/problem/ProblemReporter;
/*      */     //   254: aload_0
/*      */     //   255: getfield expression : Lorg/eclipse/jdt/internal/compiler/ast/Expression;
/*      */     //   258: aload #4
/*      */     //   260: invokevirtual incorrectSwitchType : (Lorg/eclipse/jdt/internal/compiler/ast/Expression;Lorg/eclipse/jdt/internal/compiler/lookup/TypeBinding;)V
/*      */     //   263: aconst_null
/*      */     //   264: astore #4
/*      */     //   266: goto -> 274
/*      */     //   269: aload_0
/*      */     //   270: iconst_1
/*      */     //   271: putfield isNonTraditional : Z
/*      */     //   274: iload_3
/*      */     //   275: ifeq -> 324
/*      */     //   278: aload_0
/*      */     //   279: new org/eclipse/jdt/internal/compiler/lookup/LocalVariableBinding
/*      */     //   282: dup
/*      */     //   283: getstatic org/eclipse/jdt/internal/compiler/ast/SwitchStatement.SecretStringVariableName : [C
/*      */     //   286: aload_1
/*      */     //   287: invokevirtual getJavaLangString : ()Lorg/eclipse/jdt/internal/compiler/lookup/ReferenceBinding;
/*      */     //   290: iconst_0
/*      */     //   291: iconst_0
/*      */     //   292: invokespecial <init> : ([CLorg/eclipse/jdt/internal/compiler/lookup/TypeBinding;IZ)V
/*      */     //   295: putfield dispatchStringCopy : Lorg/eclipse/jdt/internal/compiler/lookup/LocalVariableBinding;
/*      */     //   298: aload_1
/*      */     //   299: aload_0
/*      */     //   300: getfield dispatchStringCopy : Lorg/eclipse/jdt/internal/compiler/lookup/LocalVariableBinding;
/*      */     //   303: invokevirtual addLocalVariable : (Lorg/eclipse/jdt/internal/compiler/lookup/LocalVariableBinding;)V
/*      */     //   306: aload_0
/*      */     //   307: getfield dispatchStringCopy : Lorg/eclipse/jdt/internal/compiler/lookup/LocalVariableBinding;
/*      */     //   310: getstatic org/eclipse/jdt/internal/compiler/impl/Constant.NotAConstant : Lorg/eclipse/jdt/internal/compiler/impl/Constant;
/*      */     //   313: invokevirtual setConstant : (Lorg/eclipse/jdt/internal/compiler/impl/Constant;)V
/*      */     //   316: aload_0
/*      */     //   317: getfield dispatchStringCopy : Lorg/eclipse/jdt/internal/compiler/lookup/LocalVariableBinding;
/*      */     //   320: iconst_1
/*      */     //   321: putfield useFlag : I
/*      */     //   324: aload_0
/*      */     //   325: aload_1
/*      */     //   326: invokevirtual addSecretPatternSwitchVariables : (Lorg/eclipse/jdt/internal/compiler/lookup/BlockScope;)V
/*      */     //   329: aload_0
/*      */     //   330: getfield statements : [Lorg/eclipse/jdt/internal/compiler/ast/Statement;
/*      */     //   333: ifnull -> 1263
/*      */     //   336: aload_0
/*      */     //   337: getfield scope : Lorg/eclipse/jdt/internal/compiler/lookup/BlockScope;
/*      */     //   340: ifnonnull -> 355
/*      */     //   343: aload_0
/*      */     //   344: new org/eclipse/jdt/internal/compiler/lookup/BlockScope
/*      */     //   347: dup
/*      */     //   348: aload_1
/*      */     //   349: invokespecial <init> : (Lorg/eclipse/jdt/internal/compiler/lookup/BlockScope;)V
/*      */     //   352: putfield scope : Lorg/eclipse/jdt/internal/compiler/lookup/BlockScope;
/*      */     //   355: aload_0
/*      */     //   356: aload_0
/*      */     //   357: getfield statements : [Lorg/eclipse/jdt/internal/compiler/ast/Statement;
/*      */     //   360: arraylength
/*      */     //   361: dup
/*      */     //   362: istore #7
/*      */     //   364: anewarray org/eclipse/jdt/internal/compiler/ast/CaseStatement
/*      */     //   367: putfield cases : [Lorg/eclipse/jdt/internal/compiler/ast/CaseStatement;
/*      */     //   370: aload_0
/*      */     //   371: aload_0
/*      */     //   372: invokevirtual getNConstants : ()I
/*      */     //   375: putfield nConstants : I
/*      */     //   378: aload_0
/*      */     //   379: aload_0
/*      */     //   380: getfield nConstants : I
/*      */     //   383: newarray int
/*      */     //   385: putfield constants : [I
/*      */     //   388: aload_0
/*      */     //   389: aload_0
/*      */     //   390: getfield nConstants : I
/*      */     //   393: anewarray org/eclipse/jdt/internal/compiler/ast/CaseStatement$ResolvedCase
/*      */     //   396: putfield otherConstants : [Lorg/eclipse/jdt/internal/compiler/ast/CaseStatement$ResolvedCase;
/*      */     //   399: aload_0
/*      */     //   400: aload_0
/*      */     //   401: getfield nConstants : I
/*      */     //   404: newarray int
/*      */     //   406: putfield constMapping : [I
/*      */     //   409: iconst_0
/*      */     //   410: istore #8
/*      */     //   412: iconst_0
/*      */     //   413: istore #9
/*      */     //   415: aload_0
/*      */     //   416: getfield nConstants : I
/*      */     //   419: anewarray org/eclipse/jdt/internal/compiler/ast/Pattern
/*      */     //   422: astore #10
/*      */     //   424: aload_0
/*      */     //   425: getfield nConstants : I
/*      */     //   428: newarray int
/*      */     //   430: astore #11
/*      */     //   432: aconst_null
/*      */     //   433: astore #12
/*      */     //   435: iconst_0
/*      */     //   436: istore #13
/*      */     //   438: iconst_0
/*      */     //   439: istore #14
/*      */     //   441: iconst_0
/*      */     //   442: istore #15
/*      */     //   444: goto -> 1185
/*      */     //   447: aload_0
/*      */     //   448: getfield statements : [Lorg/eclipse/jdt/internal/compiler/ast/Statement;
/*      */     //   451: iload #15
/*      */     //   453: aaload
/*      */     //   454: astore #17
/*      */     //   456: aload #17
/*      */     //   458: instanceof org/eclipse/jdt/internal/compiler/ast/CaseStatement
/*      */     //   461: ifeq -> 567
/*      */     //   464: aload #17
/*      */     //   466: invokevirtual containsPatternVariable : ()Z
/*      */     //   469: ifeq -> 561
/*      */     //   472: aload #17
/*      */     //   474: checkcast org/eclipse/jdt/internal/compiler/ast/CaseStatement
/*      */     //   477: astore #18
/*      */     //   479: aload_0
/*      */     //   480: getfield switchBits : I
/*      */     //   483: bipush #32
/*      */     //   485: iand
/*      */     //   486: ifne -> 502
/*      */     //   489: aload #18
/*      */     //   491: aload_0
/*      */     //   492: getfield patternVarsWhenTrue : [Lorg/eclipse/jdt/internal/compiler/lookup/LocalVariableBinding;
/*      */     //   495: aload_0
/*      */     //   496: getfield scope : Lorg/eclipse/jdt/internal/compiler/lookup/BlockScope;
/*      */     //   499: invokevirtual collectPatternVariablesToScope : ([Lorg/eclipse/jdt/internal/compiler/lookup/LocalVariableBinding;Lorg/eclipse/jdt/internal/compiler/lookup/BlockScope;)V
/*      */     //   502: aload #17
/*      */     //   504: invokevirtual getPatternVariablesWhenTrue : ()[Lorg/eclipse/jdt/internal/compiler/lookup/LocalVariableBinding;
/*      */     //   507: astore #12
/*      */     //   509: aload #18
/*      */     //   511: getfield patternIndex : I
/*      */     //   514: iflt -> 581
/*      */     //   517: aload #18
/*      */     //   519: getfield constantExpressions : [Lorg/eclipse/jdt/internal/compiler/ast/Expression;
/*      */     //   522: aload #18
/*      */     //   524: getfield patternIndex : I
/*      */     //   527: aaload
/*      */     //   528: astore #19
/*      */     //   530: aload #19
/*      */     //   532: instanceof org/eclipse/jdt/internal/compiler/ast/Pattern
/*      */     //   535: ifeq -> 581
/*      */     //   538: aload #19
/*      */     //   540: checkcast org/eclipse/jdt/internal/compiler/ast/Pattern
/*      */     //   543: astore #20
/*      */     //   545: aload #20
/*      */     //   547: aload_0
/*      */     //   548: getfield scope : Lorg/eclipse/jdt/internal/compiler/lookup/BlockScope;
/*      */     //   551: aload_0
/*      */     //   552: getfield expression : Lorg/eclipse/jdt/internal/compiler/ast/Expression;
/*      */     //   555: invokevirtual resolveWithExpression : (Lorg/eclipse/jdt/internal/compiler/lookup/BlockScope;Lorg/eclipse/jdt/internal/compiler/ast/Expression;)V
/*      */     //   558: goto -> 581
/*      */     //   561: aconst_null
/*      */     //   562: astore #12
/*      */     //   564: goto -> 581
/*      */     //   567: aload #17
/*      */     //   569: aload #12
/*      */     //   571: aload_0
/*      */     //   572: getfield scope : Lorg/eclipse/jdt/internal/compiler/lookup/BlockScope;
/*      */     //   575: invokevirtual resolveWithPatternVariablesInScope : ([Lorg/eclipse/jdt/internal/compiler/lookup/LocalVariableBinding;Lorg/eclipse/jdt/internal/compiler/lookup/BlockScope;)V
/*      */     //   578: goto -> 1182
/*      */     //   581: aload #17
/*      */     //   583: checkcast org/eclipse/jdt/internal/compiler/ast/CaseStatement
/*      */     //   586: astore #18
/*      */     //   588: iload #13
/*      */     //   590: ifeq -> 598
/*      */     //   593: iload #13
/*      */     //   595: goto -> 604
/*      */     //   598: aload_0
/*      */     //   599: aload #18
/*      */     //   601: invokevirtual isCaseStmtNullDefault : (Lorg/eclipse/jdt/internal/compiler/ast/CaseStatement;)Z
/*      */     //   604: istore #13
/*      */     //   606: iload #14
/*      */     //   608: aload #18
/*      */     //   610: getfield constantExpressions : [Lorg/eclipse/jdt/internal/compiler/ast/Expression;
/*      */     //   613: ifnonnull -> 620
/*      */     //   616: iconst_1
/*      */     //   617: goto -> 621
/*      */     //   620: iconst_0
/*      */     //   621: ior
/*      */     //   622: istore #14
/*      */     //   624: aload #18
/*      */     //   626: aload_0
/*      */     //   627: getfield scope : Lorg/eclipse/jdt/internal/compiler/lookup/BlockScope;
/*      */     //   630: aload #4
/*      */     //   632: aload_0
/*      */     //   633: invokevirtual resolveCase : (Lorg/eclipse/jdt/internal/compiler/lookup/BlockScope;Lorg/eclipse/jdt/internal/compiler/lookup/TypeBinding;Lorg/eclipse/jdt/internal/compiler/ast/SwitchStatement;)[Lorg/eclipse/jdt/internal/compiler/ast/CaseStatement$ResolvedCase;
/*      */     //   636: astore #16
/*      */     //   638: aload #16
/*      */     //   640: getstatic org/eclipse/jdt/internal/compiler/ast/CaseStatement$ResolvedCase.UnresolvedCase : [Lorg/eclipse/jdt/internal/compiler/ast/CaseStatement$ResolvedCase;
/*      */     //   643: if_acmpeq -> 1179
/*      */     //   646: aload #16
/*      */     //   648: dup
/*      */     //   649: astore #22
/*      */     //   651: arraylength
/*      */     //   652: istore #21
/*      */     //   654: iconst_0
/*      */     //   655: istore #20
/*      */     //   657: goto -> 1172
/*      */     //   660: aload #22
/*      */     //   662: iload #20
/*      */     //   664: aaload
/*      */     //   665: astore #19
/*      */     //   667: aload #19
/*      */     //   669: getfield c : Lorg/eclipse/jdt/internal/compiler/impl/Constant;
/*      */     //   672: astore #23
/*      */     //   674: aload #23
/*      */     //   676: getstatic org/eclipse/jdt/internal/compiler/impl/Constant.NotAConstant : Lorg/eclipse/jdt/internal/compiler/impl/Constant;
/*      */     //   679: if_acmpne -> 685
/*      */     //   682: goto -> 1169
/*      */     //   685: aload_0
/*      */     //   686: getfield otherConstants : [Lorg/eclipse/jdt/internal/compiler/ast/CaseStatement$ResolvedCase;
/*      */     //   689: iload #8
/*      */     //   691: aload #19
/*      */     //   693: aastore
/*      */     //   694: aload_0
/*      */     //   695: getfield containsPatterns : Z
/*      */     //   698: ifeq -> 719
/*      */     //   701: aload #19
/*      */     //   703: invokevirtual intValue : ()I
/*      */     //   706: iconst_m1
/*      */     //   707: if_icmpne -> 714
/*      */     //   710: iconst_m1
/*      */     //   711: goto -> 724
/*      */     //   714: iload #8
/*      */     //   716: goto -> 724
/*      */     //   719: aload #19
/*      */     //   721: invokevirtual intValue : ()I
/*      */     //   724: istore #24
/*      */     //   726: aload_0
/*      */     //   727: getfield constants : [I
/*      */     //   730: iload #8
/*      */     //   732: iload #24
/*      */     //   734: iastore
/*      */     //   735: iload #8
/*      */     //   737: ifne -> 777
/*      */     //   740: iload #14
/*      */     //   742: ifeq -> 777
/*      */     //   745: aload #19
/*      */     //   747: invokevirtual isPattern : ()Z
/*      */     //   750: ifne -> 762
/*      */     //   753: aload_0
/*      */     //   754: aload #18
/*      */     //   756: invokevirtual isCaseStmtNullOnly : (Lorg/eclipse/jdt/internal/compiler/ast/CaseStatement;)Z
/*      */     //   759: ifeq -> 777
/*      */     //   762: aload_0
/*      */     //   763: getfield scope : Lorg/eclipse/jdt/internal/compiler/lookup/BlockScope;
/*      */     //   766: invokevirtual problemReporter : ()Lorg/eclipse/jdt/internal/compiler/problem/ProblemReporter;
/*      */     //   769: aload #19
/*      */     //   771: getfield e : Lorg/eclipse/jdt/internal/compiler/ast/Expression;
/*      */     //   774: invokevirtual patternDominatedByAnother : (Lorg/eclipse/jdt/internal/compiler/ast/Expression;)V
/*      */     //   777: iconst_0
/*      */     //   778: istore #25
/*      */     //   780: goto -> 1119
/*      */     //   783: aload_0
/*      */     //   784: aload #23
/*      */     //   786: iload #24
/*      */     //   788: <illegal opcode> test : (Lorg/eclipse/jdt/internal/compiler/ast/SwitchStatement;Lorg/eclipse/jdt/internal/compiler/impl/Constant;I)Ljava/util/function/IntPredicate;
/*      */     //   793: astore #26
/*      */     //   795: aload #19
/*      */     //   797: getfield e : Lorg/eclipse/jdt/internal/compiler/ast/Expression;
/*      */     //   800: getfield resolvedType : Lorg/eclipse/jdt/internal/compiler/lookup/TypeBinding;
/*      */     //   803: astore #27
/*      */     //   805: aload #27
/*      */     //   807: invokevirtual isValidBinding : ()Z
/*      */     //   810: ifne -> 816
/*      */     //   813: goto -> 1116
/*      */     //   816: iload #13
/*      */     //   818: ifne -> 826
/*      */     //   821: iload #14
/*      */     //   823: ifeq -> 861
/*      */     //   826: aload #19
/*      */     //   828: invokevirtual isPattern : ()Z
/*      */     //   831: ifne -> 843
/*      */     //   834: aload_0
/*      */     //   835: aload #18
/*      */     //   837: invokevirtual isCaseStmtNullOnly : (Lorg/eclipse/jdt/internal/compiler/ast/CaseStatement;)Z
/*      */     //   840: ifeq -> 861
/*      */     //   843: aload_0
/*      */     //   844: getfield scope : Lorg/eclipse/jdt/internal/compiler/lookup/BlockScope;
/*      */     //   847: invokevirtual problemReporter : ()Lorg/eclipse/jdt/internal/compiler/problem/ProblemReporter;
/*      */     //   850: aload #19
/*      */     //   852: getfield e : Lorg/eclipse/jdt/internal/compiler/ast/Expression;
/*      */     //   855: invokevirtual patternDominatedByAnother : (Lorg/eclipse/jdt/internal/compiler/ast/Expression;)V
/*      */     //   858: goto -> 1126
/*      */     //   861: aload #10
/*      */     //   863: iload #25
/*      */     //   865: aaload
/*      */     //   866: astore #28
/*      */     //   868: aload #28
/*      */     //   870: ifnull -> 978
/*      */     //   873: aload #19
/*      */     //   875: invokevirtual isPattern : ()Z
/*      */     //   878: ifeq -> 915
/*      */     //   881: aload #28
/*      */     //   883: aload #19
/*      */     //   885: getfield e : Lorg/eclipse/jdt/internal/compiler/ast/Expression;
/*      */     //   888: checkcast org/eclipse/jdt/internal/compiler/ast/Pattern
/*      */     //   891: invokevirtual dominates : (Lorg/eclipse/jdt/internal/compiler/ast/Pattern;)Z
/*      */     //   894: ifeq -> 1116
/*      */     //   897: aload_0
/*      */     //   898: getfield scope : Lorg/eclipse/jdt/internal/compiler/lookup/BlockScope;
/*      */     //   901: invokevirtual problemReporter : ()Lorg/eclipse/jdt/internal/compiler/problem/ProblemReporter;
/*      */     //   904: aload #19
/*      */     //   906: getfield e : Lorg/eclipse/jdt/internal/compiler/ast/Expression;
/*      */     //   909: invokevirtual patternDominatedByAnother : (Lorg/eclipse/jdt/internal/compiler/ast/Expression;)V
/*      */     //   912: goto -> 1116
/*      */     //   915: aload #27
/*      */     //   917: getfield id : I
/*      */     //   920: bipush #12
/*      */     //   922: if_icmpeq -> 1116
/*      */     //   925: aload #27
/*      */     //   927: invokevirtual isBaseType : ()Z
/*      */     //   930: ifeq -> 947
/*      */     //   933: aload_0
/*      */     //   934: getfield scope : Lorg/eclipse/jdt/internal/compiler/lookup/BlockScope;
/*      */     //   937: invokevirtual environment : ()Lorg/eclipse/jdt/internal/compiler/lookup/LookupEnvironment;
/*      */     //   940: aload #27
/*      */     //   942: invokevirtual computeBoxingType : (Lorg/eclipse/jdt/internal/compiler/lookup/TypeBinding;)Lorg/eclipse/jdt/internal/compiler/lookup/TypeBinding;
/*      */     //   945: astore #27
/*      */     //   947: aload #28
/*      */     //   949: invokevirtual primary : ()Lorg/eclipse/jdt/internal/compiler/ast/Pattern;
/*      */     //   952: aload #27
/*      */     //   954: invokevirtual isTotalForType : (Lorg/eclipse/jdt/internal/compiler/lookup/TypeBinding;)Z
/*      */     //   957: ifeq -> 1116
/*      */     //   960: aload_0
/*      */     //   961: getfield scope : Lorg/eclipse/jdt/internal/compiler/lookup/BlockScope;
/*      */     //   964: invokevirtual problemReporter : ()Lorg/eclipse/jdt/internal/compiler/problem/ProblemReporter;
/*      */     //   967: aload #19
/*      */     //   969: getfield e : Lorg/eclipse/jdt/internal/compiler/ast/Expression;
/*      */     //   972: invokevirtual patternDominatedByAnother : (Lorg/eclipse/jdt/internal/compiler/ast/Expression;)V
/*      */     //   975: goto -> 1116
/*      */     //   978: aload #19
/*      */     //   980: invokevirtual isPattern : ()Z
/*      */     //   983: ifne -> 1116
/*      */     //   986: aload #26
/*      */     //   988: iload #25
/*      */     //   990: invokeinterface test : (I)Z
/*      */     //   995: ifeq -> 1116
/*      */     //   998: aload_0
/*      */     //   999: getfield isNonTraditional : Z
/*      */     //   1002: ifeq -> 1098
/*      */     //   1005: iconst_1
/*      */     //   1006: istore #29
/*      */     //   1008: aload #19
/*      */     //   1010: getfield e : Lorg/eclipse/jdt/internal/compiler/ast/Expression;
/*      */     //   1013: instanceof org/eclipse/jdt/internal/compiler/ast/NullLiteral
/*      */     //   1016: ifne -> 1035
/*      */     //   1019: aload_0
/*      */     //   1020: getfield otherConstants : [Lorg/eclipse/jdt/internal/compiler/ast/CaseStatement$ResolvedCase;
/*      */     //   1023: iload #25
/*      */     //   1025: aaload
/*      */     //   1026: getfield e : Lorg/eclipse/jdt/internal/compiler/ast/Expression;
/*      */     //   1029: instanceof org/eclipse/jdt/internal/compiler/ast/NullLiteral
/*      */     //   1032: ifeq -> 1069
/*      */     //   1035: aload #19
/*      */     //   1037: getfield e : Lorg/eclipse/jdt/internal/compiler/ast/Expression;
/*      */     //   1040: instanceof org/eclipse/jdt/internal/compiler/ast/NullLiteral
/*      */     //   1043: ifeq -> 1066
/*      */     //   1046: aload_0
/*      */     //   1047: getfield otherConstants : [Lorg/eclipse/jdt/internal/compiler/ast/CaseStatement$ResolvedCase;
/*      */     //   1050: iload #25
/*      */     //   1052: aaload
/*      */     //   1053: getfield e : Lorg/eclipse/jdt/internal/compiler/ast/Expression;
/*      */     //   1056: instanceof org/eclipse/jdt/internal/compiler/ast/NullLiteral
/*      */     //   1059: ifeq -> 1066
/*      */     //   1062: iconst_1
/*      */     //   1063: goto -> 1067
/*      */     //   1066: iconst_0
/*      */     //   1067: istore #29
/*      */     //   1069: iload #29
/*      */     //   1071: ifeq -> 1116
/*      */     //   1074: aload_0
/*      */     //   1075: aload #19
/*      */     //   1077: getfield e : Lorg/eclipse/jdt/internal/compiler/ast/Expression;
/*      */     //   1080: aload_0
/*      */     //   1081: getfield otherConstants : [Lorg/eclipse/jdt/internal/compiler/ast/CaseStatement$ResolvedCase;
/*      */     //   1084: iload #25
/*      */     //   1086: aaload
/*      */     //   1087: getfield e : Lorg/eclipse/jdt/internal/compiler/ast/Expression;
/*      */     //   1090: iload #7
/*      */     //   1092: invokevirtual reportDuplicateCase : (Lorg/eclipse/jdt/internal/compiler/ast/Statement;Lorg/eclipse/jdt/internal/compiler/ast/Statement;I)V
/*      */     //   1095: goto -> 1116
/*      */     //   1098: aload_0
/*      */     //   1099: aload #18
/*      */     //   1101: aload_0
/*      */     //   1102: getfield cases : [Lorg/eclipse/jdt/internal/compiler/ast/CaseStatement;
/*      */     //   1105: aload #11
/*      */     //   1107: iload #25
/*      */     //   1109: iaload
/*      */     //   1110: aaload
/*      */     //   1111: iload #7
/*      */     //   1113: invokevirtual reportDuplicateCase : (Lorg/eclipse/jdt/internal/compiler/ast/Statement;Lorg/eclipse/jdt/internal/compiler/ast/Statement;I)V
/*      */     //   1116: iinc #25, 1
/*      */     //   1119: iload #25
/*      */     //   1121: iload #8
/*      */     //   1123: if_icmplt -> 783
/*      */     //   1126: aload_0
/*      */     //   1127: getfield constMapping : [I
/*      */     //   1130: iload #8
/*      */     //   1132: iload #8
/*      */     //   1134: iastore
/*      */     //   1135: aload #11
/*      */     //   1137: iload #8
/*      */     //   1139: iload #9
/*      */     //   1141: iastore
/*      */     //   1142: aload #19
/*      */     //   1144: getfield e : Lorg/eclipse/jdt/internal/compiler/ast/Expression;
/*      */     //   1147: instanceof org/eclipse/jdt/internal/compiler/ast/Pattern
/*      */     //   1150: ifeq -> 1166
/*      */     //   1153: aload #10
/*      */     //   1155: iload #8
/*      */     //   1157: aload #19
/*      */     //   1159: getfield e : Lorg/eclipse/jdt/internal/compiler/ast/Expression;
/*      */     //   1162: checkcast org/eclipse/jdt/internal/compiler/ast/Pattern
/*      */     //   1165: aastore
/*      */     //   1166: iinc #8, 1
/*      */     //   1169: iinc #20, 1
/*      */     //   1172: iload #20
/*      */     //   1174: iload #21
/*      */     //   1176: if_icmplt -> 660
/*      */     //   1179: iinc #9, 1
/*      */     //   1182: iinc #15, 1
/*      */     //   1185: iload #15
/*      */     //   1187: iload #7
/*      */     //   1189: if_icmplt -> 447
/*      */     //   1192: iload #7
/*      */     //   1194: iload #8
/*      */     //   1196: if_icmpeq -> 1288
/*      */     //   1199: aload_0
/*      */     //   1200: getfield otherConstants : [Lorg/eclipse/jdt/internal/compiler/ast/CaseStatement$ResolvedCase;
/*      */     //   1203: iconst_0
/*      */     //   1204: aload_0
/*      */     //   1205: iload #8
/*      */     //   1207: anewarray org/eclipse/jdt/internal/compiler/ast/CaseStatement$ResolvedCase
/*      */     //   1210: dup_x1
/*      */     //   1211: putfield otherConstants : [Lorg/eclipse/jdt/internal/compiler/ast/CaseStatement$ResolvedCase;
/*      */     //   1214: iconst_0
/*      */     //   1215: iload #8
/*      */     //   1217: invokestatic arraycopy : (Ljava/lang/Object;ILjava/lang/Object;II)V
/*      */     //   1220: aload_0
/*      */     //   1221: getfield constants : [I
/*      */     //   1224: iconst_0
/*      */     //   1225: aload_0
/*      */     //   1226: iload #8
/*      */     //   1228: newarray int
/*      */     //   1230: dup_x1
/*      */     //   1231: putfield constants : [I
/*      */     //   1234: iconst_0
/*      */     //   1235: iload #8
/*      */     //   1237: invokestatic arraycopy : (Ljava/lang/Object;ILjava/lang/Object;II)V
/*      */     //   1240: aload_0
/*      */     //   1241: getfield constMapping : [I
/*      */     //   1244: iconst_0
/*      */     //   1245: aload_0
/*      */     //   1246: iload #8
/*      */     //   1248: newarray int
/*      */     //   1250: dup_x1
/*      */     //   1251: putfield constMapping : [I
/*      */     //   1254: iconst_0
/*      */     //   1255: iload #8
/*      */     //   1257: invokestatic arraycopy : (Ljava/lang/Object;ILjava/lang/Object;II)V
/*      */     //   1260: goto -> 1288
/*      */     //   1263: aload_0
/*      */     //   1264: getfield bits : I
/*      */     //   1267: bipush #8
/*      */     //   1269: iand
/*      */     //   1270: ifeq -> 1288
/*      */     //   1273: aload_1
/*      */     //   1274: invokevirtual problemReporter : ()Lorg/eclipse/jdt/internal/compiler/problem/ProblemReporter;
/*      */     //   1277: aload_0
/*      */     //   1278: getfield blockStart : I
/*      */     //   1281: aload_0
/*      */     //   1282: getfield sourceEnd : I
/*      */     //   1285: invokevirtual undocumentedEmptyBlock : (II)V
/*      */     //   1288: aload_0
/*      */     //   1289: invokevirtual reportMixingCaseTypes : ()V
/*      */     //   1292: aload_0
/*      */     //   1293: aload_1
/*      */     //   1294: aload #5
/*      */     //   1296: invokevirtual checkAndFlagDefaultSealed : (Lorg/eclipse/jdt/internal/compiler/lookup/BlockScope;Lorg/eclipse/jdt/internal/compiler/impl/CompilerOptions;)Z
/*      */     //   1299: istore #7
/*      */     //   1301: iload #7
/*      */     //   1303: ifne -> 1375
/*      */     //   1306: aload_0
/*      */     //   1307: getfield defaultCase : Lorg/eclipse/jdt/internal/compiler/ast/CaseStatement;
/*      */     //   1310: ifnonnull -> 1375
/*      */     //   1313: aload_0
/*      */     //   1314: aload #5
/*      */     //   1316: iload_2
/*      */     //   1317: invokevirtual ignoreMissingDefaultCase : (Lorg/eclipse/jdt/internal/compiler/impl/CompilerOptions;Z)Z
/*      */     //   1320: ifeq -> 1338
/*      */     //   1323: iload_2
/*      */     //   1324: ifeq -> 1338
/*      */     //   1327: aload_1
/*      */     //   1328: invokevirtual methodScope : ()Lorg/eclipse/jdt/internal/compiler/lookup/MethodScope;
/*      */     //   1331: iconst_1
/*      */     //   1332: putfield hasMissingSwitchDefault : Z
/*      */     //   1335: goto -> 1375
/*      */     //   1338: aload_0
/*      */     //   1339: invokevirtual isExhaustive : ()Z
/*      */     //   1342: ifne -> 1375
/*      */     //   1345: iload #6
/*      */     //   1347: ifeq -> 1364
/*      */     //   1350: aload_1
/*      */     //   1351: invokevirtual problemReporter : ()Lorg/eclipse/jdt/internal/compiler/problem/ProblemReporter;
/*      */     //   1354: aload_0
/*      */     //   1355: getfield expression : Lorg/eclipse/jdt/internal/compiler/ast/Expression;
/*      */     //   1358: invokevirtual enhancedSwitchMissingDefaultCase : (Lorg/eclipse/jdt/internal/compiler/ast/ASTNode;)V
/*      */     //   1361: goto -> 1375
/*      */     //   1364: aload_1
/*      */     //   1365: invokevirtual problemReporter : ()Lorg/eclipse/jdt/internal/compiler/problem/ProblemReporter;
/*      */     //   1368: aload_0
/*      */     //   1369: iload_2
/*      */     //   1370: aload #4
/*      */     //   1372: invokevirtual missingDefaultCase : (Lorg/eclipse/jdt/internal/compiler/ast/SwitchStatement;ZLorg/eclipse/jdt/internal/compiler/lookup/TypeBinding;)V
/*      */     //   1375: iload_2
/*      */     //   1376: ifeq -> 1635
/*      */     //   1379: aload #5
/*      */     //   1381: getfield complianceLevel : J
/*      */     //   1384: ldc2_w 3211264
/*      */     //   1387: lcmp
/*      */     //   1388: iflt -> 1635
/*      */     //   1391: aload_0
/*      */     //   1392: getfield defaultCase : Lorg/eclipse/jdt/internal/compiler/ast/CaseStatement;
/*      */     //   1395: ifnull -> 1406
/*      */     //   1398: aload #5
/*      */     //   1400: getfield reportMissingEnumCaseDespiteDefault : Z
/*      */     //   1403: ifeq -> 1635
/*      */     //   1406: aload_0
/*      */     //   1407: getfield otherConstants : [Lorg/eclipse/jdt/internal/compiler/ast/CaseStatement$ResolvedCase;
/*      */     //   1410: ifnonnull -> 1417
/*      */     //   1413: iconst_0
/*      */     //   1414: goto -> 1422
/*      */     //   1417: aload_0
/*      */     //   1418: getfield otherConstants : [Lorg/eclipse/jdt/internal/compiler/ast/CaseStatement$ResolvedCase;
/*      */     //   1421: arraylength
/*      */     //   1422: istore #8
/*      */     //   1424: aload_0
/*      */     //   1425: getfield switchBits : I
/*      */     //   1428: iconst_4
/*      */     //   1429: iand
/*      */     //   1430: ifne -> 1635
/*      */     //   1433: aload_0
/*      */     //   1434: getfield containsPatterns : Z
/*      */     //   1437: ifne -> 1462
/*      */     //   1440: iload #8
/*      */     //   1442: aload_0
/*      */     //   1443: getfield caseCount : I
/*      */     //   1446: if_icmplt -> 1635
/*      */     //   1449: iload #8
/*      */     //   1451: aload #4
/*      */     //   1453: checkcast org/eclipse/jdt/internal/compiler/lookup/ReferenceBinding
/*      */     //   1456: invokevirtual enumConstantCount : ()I
/*      */     //   1459: if_icmpeq -> 1635
/*      */     //   1462: aload #4
/*      */     //   1464: invokevirtual erasure : ()Lorg/eclipse/jdt/internal/compiler/lookup/TypeBinding;
/*      */     //   1467: checkcast org/eclipse/jdt/internal/compiler/lookup/ReferenceBinding
/*      */     //   1470: invokevirtual fields : ()[Lorg/eclipse/jdt/internal/compiler/lookup/FieldBinding;
/*      */     //   1473: astore #9
/*      */     //   1475: iconst_0
/*      */     //   1476: istore #10
/*      */     //   1478: aload #9
/*      */     //   1480: arraylength
/*      */     //   1481: istore #11
/*      */     //   1483: goto -> 1605
/*      */     //   1486: aload #9
/*      */     //   1488: iload #10
/*      */     //   1490: aaload
/*      */     //   1491: astore #12
/*      */     //   1493: aload #12
/*      */     //   1495: getfield modifiers : I
/*      */     //   1498: sipush #16384
/*      */     //   1501: iand
/*      */     //   1502: ifne -> 1508
/*      */     //   1505: goto -> 1602
/*      */     //   1508: iconst_0
/*      */     //   1509: istore #13
/*      */     //   1511: goto -> 1543
/*      */     //   1514: aload #12
/*      */     //   1516: getfield id : I
/*      */     //   1519: iconst_1
/*      */     //   1520: iadd
/*      */     //   1521: aload_0
/*      */     //   1522: getfield otherConstants : [Lorg/eclipse/jdt/internal/compiler/ast/CaseStatement$ResolvedCase;
/*      */     //   1525: iload #13
/*      */     //   1527: aaload
/*      */     //   1528: getfield c : Lorg/eclipse/jdt/internal/compiler/impl/Constant;
/*      */     //   1531: invokevirtual intValue : ()I
/*      */     //   1534: if_icmpne -> 1540
/*      */     //   1537: goto -> 1602
/*      */     //   1540: iinc #13, 1
/*      */     //   1543: iload #13
/*      */     //   1545: iload #8
/*      */     //   1547: if_icmplt -> 1514
/*      */     //   1550: aload_0
/*      */     //   1551: dup
/*      */     //   1552: getfield switchBits : I
/*      */     //   1555: sipush #-257
/*      */     //   1558: iand
/*      */     //   1559: putfield switchBits : I
/*      */     //   1562: aload_0
/*      */     //   1563: getfield defaultCase : Lorg/eclipse/jdt/internal/compiler/ast/CaseStatement;
/*      */     //   1566: ifnull -> 1587
/*      */     //   1569: aload_0
/*      */     //   1570: getfield defaultCase : Lorg/eclipse/jdt/internal/compiler/ast/CaseStatement;
/*      */     //   1573: getfield bits : I
/*      */     //   1576: ldc_w 1073741824
/*      */     //   1579: iand
/*      */     //   1580: ifeq -> 1587
/*      */     //   1583: iconst_1
/*      */     //   1584: goto -> 1588
/*      */     //   1587: iconst_0
/*      */     //   1588: istore #13
/*      */     //   1590: iload #13
/*      */     //   1592: ifne -> 1602
/*      */     //   1595: aload_0
/*      */     //   1596: aload_1
/*      */     //   1597: aload #12
/*      */     //   1599: invokevirtual reportMissingEnumConstantCase : (Lorg/eclipse/jdt/internal/compiler/lookup/BlockScope;Lorg/eclipse/jdt/internal/compiler/lookup/FieldBinding;)V
/*      */     //   1602: iinc #10, 1
/*      */     //   1605: iload #10
/*      */     //   1607: iload #11
/*      */     //   1609: if_icmplt -> 1486
/*      */     //   1612: goto -> 1635
/*      */     //   1615: astore #30
/*      */     //   1617: aload_0
/*      */     //   1618: getfield scope : Lorg/eclipse/jdt/internal/compiler/lookup/BlockScope;
/*      */     //   1621: ifnull -> 1632
/*      */     //   1624: aload_0
/*      */     //   1625: getfield scope : Lorg/eclipse/jdt/internal/compiler/lookup/BlockScope;
/*      */     //   1628: aconst_null
/*      */     //   1629: putfield enclosingCase : Lorg/eclipse/jdt/internal/compiler/ast/CaseStatement;
/*      */     //   1632: aload #30
/*      */     //   1634: athrow
/*      */     //   1635: aload_0
/*      */     //   1636: getfield scope : Lorg/eclipse/jdt/internal/compiler/lookup/BlockScope;
/*      */     //   1639: ifnull -> 1650
/*      */     //   1642: aload_0
/*      */     //   1643: getfield scope : Lorg/eclipse/jdt/internal/compiler/lookup/BlockScope;
/*      */     //   1646: aconst_null
/*      */     //   1647: putfield enclosingCase : Lorg/eclipse/jdt/internal/compiler/ast/CaseStatement;
/*      */     //   1650: return
/*      */     // Line number table:
/*      */     //   Java source line number -> byte code offset
/*      */     //   #863	-> 0
/*      */     //   #864	-> 2
/*      */     //   #865	-> 4
/*      */     //   #866	-> 14
/*      */     //   #867	-> 20
/*      */     //   #868	-> 29
/*      */     //   #869	-> 34
/*      */     //   #871	-> 46
/*      */     //   #872	-> 54
/*      */     //   #873	-> 57
/*      */     //   #874	-> 60
/*      */     //   #875	-> 68
/*      */     //   #876	-> 83
/*      */     //   #877	-> 86
/*      */     //   #878	-> 97
/*      */     //   #879	-> 100
/*      */     //   #880	-> 108
/*      */     //   #881	-> 110
/*      */     //   #882	-> 122
/*      */     //   #884	-> 135
/*      */     //   #885	-> 138
/*      */     //   #886	-> 157
/*      */     //   #887	-> 170
/*      */     //   #888	-> 173
/*      */     //   #889	-> 195
/*      */     //   #890	-> 209
/*      */     //   #891	-> 226
/*      */     //   #892	-> 231
/*      */     //   #894	-> 234
/*      */     //   #895	-> 236
/*      */     //   #897	-> 239
/*      */     //   #898	-> 250
/*      */     //   #899	-> 263
/*      */     //   #900	-> 266
/*      */     //   #901	-> 269
/*      */     //   #905	-> 274
/*      */     //   #909	-> 278
/*      */     //   #910	-> 298
/*      */     //   #911	-> 306
/*      */     //   #912	-> 316
/*      */     //   #914	-> 324
/*      */     //   #915	-> 329
/*      */     //   #916	-> 336
/*      */     //   #917	-> 343
/*      */     //   #920	-> 355
/*      */     //   #921	-> 370
/*      */     //   #922	-> 378
/*      */     //   #923	-> 388
/*      */     //   #924	-> 399
/*      */     //   #925	-> 409
/*      */     //   #926	-> 412
/*      */     //   #927	-> 415
/*      */     //   #928	-> 424
/*      */     //   #929	-> 432
/*      */     //   #930	-> 435
/*      */     //   #931	-> 438
/*      */     //   #932	-> 441
/*      */     //   #934	-> 447
/*      */     //   #938	-> 456
/*      */     //   #939	-> 464
/*      */     //   #940	-> 472
/*      */     //   #941	-> 479
/*      */     //   #943	-> 489
/*      */     //   #945	-> 502
/*      */     //   #946	-> 509
/*      */     //   #947	-> 517
/*      */     //   #948	-> 530
/*      */     //   #949	-> 538
/*      */     //   #950	-> 545
/*      */     //   #953	-> 558
/*      */     //   #954	-> 561
/*      */     //   #956	-> 564
/*      */     //   #957	-> 567
/*      */     //   #958	-> 578
/*      */     //   #960	-> 581
/*      */     //   #961	-> 588
/*      */     //   #962	-> 593
/*      */     //   #961	-> 604
/*      */     //   #963	-> 606
/*      */     //   #964	-> 624
/*      */     //   #965	-> 638
/*      */     //   #966	-> 646
/*      */     //   #967	-> 667
/*      */     //   #968	-> 674
/*      */     //   #969	-> 682
/*      */     //   #970	-> 685
/*      */     //   #971	-> 694
/*      */     //   #972	-> 726
/*      */     //   #973	-> 735
/*      */     //   #974	-> 745
/*      */     //   #975	-> 762
/*      */     //   #977	-> 777
/*      */     //   #978	-> 783
/*      */     //   #990	-> 795
/*      */     //   #991	-> 805
/*      */     //   #992	-> 813
/*      */     //   #993	-> 816
/*      */     //   #994	-> 843
/*      */     //   #995	-> 858
/*      */     //   #997	-> 861
/*      */     //   #998	-> 868
/*      */     //   #999	-> 873
/*      */     //   #1000	-> 881
/*      */     //   #1001	-> 897
/*      */     //   #1003	-> 912
/*      */     //   #1004	-> 915
/*      */     //   #1005	-> 925
/*      */     //   #1006	-> 933
/*      */     //   #1008	-> 947
/*      */     //   #1009	-> 960
/*      */     //   #1012	-> 975
/*      */     //   #1013	-> 978
/*      */     //   #1014	-> 998
/*      */     //   #1015	-> 1005
/*      */     //   #1016	-> 1008
/*      */     //   #1017	-> 1035
/*      */     //   #1019	-> 1069
/*      */     //   #1020	-> 1074
/*      */     //   #1021	-> 1095
/*      */     //   #1022	-> 1098
/*      */     //   #977	-> 1116
/*      */     //   #1027	-> 1126
/*      */     //   #1028	-> 1135
/*      */     //   #1030	-> 1142
/*      */     //   #1031	-> 1153
/*      */     //   #1033	-> 1166
/*      */     //   #966	-> 1169
/*      */     //   #1036	-> 1179
/*      */     //   #932	-> 1182
/*      */     //   #1038	-> 1192
/*      */     //   #1039	-> 1199
/*      */     //   #1040	-> 1220
/*      */     //   #1041	-> 1240
/*      */     //   #1043	-> 1260
/*      */     //   #1044	-> 1263
/*      */     //   #1045	-> 1273
/*      */     //   #1048	-> 1288
/*      */     //   #1051	-> 1292
/*      */     //   #1052	-> 1301
/*      */     //   #1053	-> 1313
/*      */     //   #1054	-> 1327
/*      */     //   #1055	-> 1335
/*      */     //   #1056	-> 1338
/*      */     //   #1057	-> 1345
/*      */     //   #1058	-> 1350
/*      */     //   #1060	-> 1364
/*      */     //   #1065	-> 1375
/*      */     //   #1066	-> 1391
/*      */     //   #1067	-> 1406
/*      */     //   #1071	-> 1424
/*      */     //   #1072	-> 1433
/*      */     //   #1073	-> 1440
/*      */     //   #1074	-> 1449
/*      */     //   #1075	-> 1462
/*      */     //   #1076	-> 1475
/*      */     //   #1077	-> 1486
/*      */     //   #1078	-> 1493
/*      */     //   #1080	-> 1508
/*      */     //   #1081	-> 1514
/*      */     //   #1082	-> 1537
/*      */     //   #1080	-> 1540
/*      */     //   #1084	-> 1550
/*      */     //   #1086	-> 1562
/*      */     //   #1087	-> 1590
/*      */     //   #1088	-> 1595
/*      */     //   #1076	-> 1602
/*      */     //   #1095	-> 1612
/*      */     //   #1096	-> 1617
/*      */     //   #1097	-> 1632
/*      */     //   #1096	-> 1635
/*      */     //   #1098	-> 1650
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	descriptor
/*      */     //   0	1651	0	this	Lorg/eclipse/jdt/internal/compiler/ast/SwitchStatement;
/*      */     //   0	1651	1	upperScope	Lorg/eclipse/jdt/internal/compiler/lookup/BlockScope;
/*      */     //   2	1610	2	isEnumSwitch	Z
/*      */     //   4	1608	3	isStringSwitch	Z
/*      */     //   14	1598	4	expressionType	Lorg/eclipse/jdt/internal/compiler/lookup/TypeBinding;
/*      */     //   20	1592	5	compilerOptions	Lorg/eclipse/jdt/internal/compiler/impl/CompilerOptions;
/*      */     //   29	1583	6	isEnhanced	Z
/*      */     //   364	896	7	length	I
/*      */     //   412	848	8	counter	I
/*      */     //   415	845	9	caseCounter	I
/*      */     //   424	836	10	patterns	[Lorg/eclipse/jdt/internal/compiler/ast/Pattern;
/*      */     //   432	828	11	caseIndex	[I
/*      */     //   435	825	12	patternVariables	[Lorg/eclipse/jdt/internal/compiler/lookup/LocalVariableBinding;
/*      */     //   438	822	13	caseNullDefaultFound	Z
/*      */     //   441	819	14	defaultFound	Z
/*      */     //   444	748	15	i	I
/*      */     //   638	544	16	constantsList	[Lorg/eclipse/jdt/internal/compiler/ast/CaseStatement$ResolvedCase;
/*      */     //   456	726	17	statement	Lorg/eclipse/jdt/internal/compiler/ast/Statement;
/*      */     //   479	79	18	caseStatement	Lorg/eclipse/jdt/internal/compiler/ast/CaseStatement;
/*      */     //   530	28	19	probablePattern	Lorg/eclipse/jdt/internal/compiler/ast/Expression;
/*      */     //   545	13	20	pattern	Lorg/eclipse/jdt/internal/compiler/ast/Pattern;
/*      */     //   588	594	18	caseStmt	Lorg/eclipse/jdt/internal/compiler/ast/CaseStatement;
/*      */     //   667	502	19	c	Lorg/eclipse/jdt/internal/compiler/ast/CaseStatement$ResolvedCase;
/*      */     //   674	495	23	con	Lorg/eclipse/jdt/internal/compiler/impl/Constant;
/*      */     //   726	443	24	c1	I
/*      */     //   780	346	25	j	I
/*      */     //   795	321	26	check	Ljava/util/function/IntPredicate;
/*      */     //   805	311	27	type	Lorg/eclipse/jdt/internal/compiler/lookup/TypeBinding;
/*      */     //   868	248	28	p1	Lorg/eclipse/jdt/internal/compiler/ast/Pattern;
/*      */     //   1008	87	29	reportDup	Z
/*      */     //   1301	311	7	flagged	Z
/*      */     //   1424	188	8	constantCount	I
/*      */     //   1475	137	9	enumFields	[Lorg/eclipse/jdt/internal/compiler/lookup/FieldBinding;
/*      */     //   1478	134	10	i	I
/*      */     //   1483	129	11	max	I
/*      */     //   1493	109	12	enumConstant	Lorg/eclipse/jdt/internal/compiler/lookup/FieldBinding;
/*      */     //   1511	39	13	j	I
/*      */     //   1590	12	13	suppress	Z
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   0	1615	1615	finally
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean isCaseStmtNullDefault(CaseStatement caseStmt) {
/* 1100 */     return (caseStmt != null && 
/* 1101 */       caseStmt.constantExpressions != null && 
/* 1102 */       caseStmt.constantExpressions.length == 2 && 
/* 1103 */       caseStmt.constantExpressions[0] instanceof NullLiteral && 
/* 1104 */       caseStmt.constantExpressions[1] instanceof FakeDefaultLiteral);
/*      */   }
/*      */   private boolean isCaseStmtNullOnly(CaseStatement caseStmt) {
/* 1107 */     return (caseStmt != null && 
/* 1108 */       caseStmt.constantExpressions != null && 
/* 1109 */       caseStmt.constantExpressions.length == 1 && 
/* 1110 */       caseStmt.constantExpressions[0] instanceof NullLiteral);
/*      */   }
/*      */   private boolean isExhaustive() {
/* 1113 */     return ((this.switchBits & 0x8) != 0);
/*      */   }
/*      */   public boolean isEnhanced() {
/* 1116 */     return ((this.switchBits & 0x10) != 0);
/*      */   }
/*      */   private boolean checkAndSetEnhanced(BlockScope upperScope, TypeBinding expressionType) {
/* 1119 */     if (JavaFeature.PATTERN_MATCHING_IN_SWITCH.isSupported(upperScope.compilerOptions()) && 
/* 1120 */       expressionType != null && !(this instanceof SwitchExpression)) {
/*      */       
/* 1122 */       boolean acceptableType = !expressionType.isEnum();
/* 1123 */       switch (expressionType.id) {
/*      */         case 2:
/*      */         case 3:
/*      */         case 4:
/*      */         case 10:
/*      */         case 11:
/*      */         case 26:
/*      */         case 27:
/*      */         case 28:
/*      */         case 29:
/* 1133 */           acceptableType = false; break;
/*      */       } 
/* 1135 */       if (acceptableType || this.containsPatterns || this.containsNull) {
/* 1136 */         this.switchBits |= 0x10;
/* 1137 */         return true;
/*      */       } 
/*      */     } 
/* 1140 */     return false;
/*      */   }
/*      */   private boolean checkAndFlagDefaultSealed(BlockScope skope, CompilerOptions compilerOptions) {
/* 1143 */     if (this.defaultCase != null) {
/* 1144 */       this.switchBits |= 0x8;
/* 1145 */       return false;
/*      */     } 
/* 1147 */     boolean checkSealed = (this.containsPatterns && 
/* 1148 */       JavaFeature.SEALED_CLASSES.isSupported(compilerOptions) && 
/* 1149 */       JavaFeature.PATTERN_MATCHING_IN_SWITCH.isSupported(compilerOptions) && 
/* 1150 */       this.expression.resolvedType instanceof ReferenceBinding);
/* 1151 */     if (!checkSealed) return false; 
/* 1152 */     ReferenceBinding ref = (ReferenceBinding)this.expression.resolvedType;
/* 1153 */     if (!ref.isClass() && !ref.isInterface() && !ref.isTypeVariable() && !ref.isIntersectionType())
/* 1154 */       return false; 
/* 1155 */     if (ref instanceof TypeVariableBinding) {
/* 1156 */       TypeVariableBinding tvb = (TypeVariableBinding)ref;
/* 1157 */       ref = (tvb.firstBound instanceof ReferenceBinding) ? (ReferenceBinding)tvb.firstBound : ref;
/*      */     } 
/* 1159 */     if (!ref.isSealed()) return false; 
/* 1160 */     List<ReferenceBinding> allallowedTypes = new ArrayList<>();
/* 1161 */     if (ref.isClass() && !ref.isAbstract()) {
/* 1162 */       allallowedTypes.add(ref);
/*      */     }
/* 1164 */     List<ReferenceBinding> permittedTypes = new ArrayList<>(Arrays.asList(ref.permittedTypes()));
/* 1165 */     allallowedTypes.addAll(permittedTypes);
/* 1166 */     if (!isExhaustiveWithCaseTypes(allallowedTypes, this.caseLabelElementTypes)) {
/* 1167 */       if (this instanceof SwitchExpression)
/* 1168 */         return false; 
/* 1169 */       skope.problemReporter().enhancedSwitchMissingDefaultCase(this.expression);
/* 1170 */       return true;
/*      */     } 
/* 1172 */     this.switchBits |= 0x8;
/* 1173 */     return false;
/*      */   }
/*      */   
/*      */   private boolean isExhaustiveWithCaseTypes(List<ReferenceBinding> allallowedTypes, List<TypeBinding> listedTypes) {
/* 1177 */     int pendingTypes = allallowedTypes.size();
/* 1178 */     for (TypeBinding pt : allallowedTypes) {
/* 1179 */       for (TypeBinding type : listedTypes) {
/* 1180 */         if (pt.isCompatibleWith(type)) {
/* 1181 */           pendingTypes--;
/*      */           break;
/*      */         } 
/*      */       } 
/*      */     } 
/* 1186 */     if (pendingTypes == 0) {
/* 1187 */       return true;
/*      */     }
/* 1189 */     List<TypeBinding> coveredTypes = new ArrayList<>(listedTypes);
/* 1190 */     List<ReferenceBinding> remainingTypes = new ArrayList<>(allallowedTypes);
/* 1191 */     remainingTypes.removeAll(coveredTypes);
/*      */     
/* 1193 */     Map<TypeBinding, List<TypeBinding>> impliedTypes = new HashMap<>();
/*      */     
/* 1195 */     for (ReferenceBinding type : remainingTypes) {
/* 1196 */       impliedTypes.put(type, new ArrayList<>());
/* 1197 */       List<ReferenceBinding> typesToAdd = new ArrayList<>();
/* 1198 */       for (ReferenceBinding impliedType : allallowedTypes) {
/* 1199 */         if (impliedType.equals(type))
/* 1200 */           continue;  if (type.isClass()) {
/* 1201 */           if (impliedType.isAbstract() && type.superclass().equals(impliedType)) {
/* 1202 */             typesToAdd.add(impliedType);
/*      */           }
/* 1204 */           if (Arrays.<ReferenceBinding>asList(type.superInterfaces()).contains(impliedType))
/* 1205 */             typesToAdd.add(impliedType);  continue;
/* 1206 */         }  if (type.isInterface() && 
/* 1207 */           Arrays.<ReferenceBinding>asList(impliedType.superInterfaces()).contains(type)) {
/* 1208 */           typesToAdd.add(impliedType);
/*      */         }
/*      */       } 
/* 1211 */       if (!typesToAdd.isEmpty()) {
/* 1212 */         ((List<ReferenceBinding>)impliedTypes.get(type)).addAll(typesToAdd);
/*      */       }
/*      */     } 
/* 1215 */     boolean delta = true;
/* 1216 */     while (delta) {
/* 1217 */       delta = false;
/* 1218 */       List<ReferenceBinding> typesToAdd = new ArrayList<>();
/* 1219 */       for (ReferenceBinding type : remainingTypes) {
/* 1220 */         boolean add = false;
/* 1221 */         if (type.isClass()) {
/* 1222 */           for (TypeBinding tb : impliedTypes.get(type)) {
/* 1223 */             if (coveredTypes.contains(tb)) {
/* 1224 */               add = true;
/*      */               break;
/*      */             } 
/*      */           } 
/* 1228 */         } else if (type.isInterface()) {
/* 1229 */           add = coveredTypes.containsAll(impliedTypes.get(type));
/*      */         } 
/* 1231 */         if (add) {
/* 1232 */           typesToAdd.add(type);
/*      */         }
/*      */       } 
/* 1235 */       if (!typesToAdd.isEmpty()) {
/* 1236 */         remainingTypes.removeAll(typesToAdd);
/* 1237 */         coveredTypes.addAll(typesToAdd);
/* 1238 */         typesToAdd.clear();
/* 1239 */         delta = true;
/*      */       } 
/*      */     } 
/* 1242 */     return remainingTypes.isEmpty();
/*      */   }
/*      */   private boolean isNullAndNeedsPatternVar() {
/* 1245 */     if (this.containsPatterns)
/* 1246 */       return false; 
/* 1247 */     if (!this.containsNull)
/* 1248 */       return false; 
/* 1249 */     TypeBinding eType = (this.expression != null) ? this.expression.resolvedType : null;
/* 1250 */     if (eType == null)
/* 1251 */       return false; 
/* 1252 */     return !(eType.isPrimitiveOrBoxedPrimitiveType() || eType.isEnum());
/*      */   }
/*      */   private void addSecretPatternSwitchVariables(BlockScope upperScope) {
/* 1255 */     if (this.containsPatterns || isNullAndNeedsPatternVar()) {
/* 1256 */       this.scope = new BlockScope(upperScope);
/* 1257 */       this.dispatchPatternCopy = new LocalVariableBinding(SecretPatternVariableName, this.expression.resolvedType, 0, false);
/* 1258 */       this.scope.addLocalVariable(this.dispatchPatternCopy);
/* 1259 */       this.dispatchPatternCopy.setConstant(Constant.NotAConstant);
/* 1260 */       this.dispatchPatternCopy.useFlag = 1;
/* 1261 */       this.restartIndexLocal = new LocalVariableBinding(SecretPatternRestartIndexName, (TypeBinding)TypeBinding.INT, 0, false);
/* 1262 */       this.scope.addLocalVariable(this.restartIndexLocal);
/* 1263 */       this.restartIndexLocal.setConstant(Constant.NotAConstant);
/* 1264 */       this.restartIndexLocal.useFlag = 1;
/*      */     } 
/*      */   }
/*      */   protected void reportMissingEnumConstantCase(BlockScope upperScope, FieldBinding enumConstant) {
/* 1268 */     upperScope.problemReporter().missingEnumConstantCase(this, enumConstant);
/*      */   }
/*      */   protected boolean ignoreMissingDefaultCase(CompilerOptions compilerOptions, boolean isEnumSwitch) {
/* 1271 */     return (compilerOptions.getSeverity(1073774592) == 256);
/*      */   }
/*      */   
/*      */   public boolean isTrulyExpression() {
/* 1275 */     return false;
/*      */   }
/*      */   private void reportMixingCaseTypes() {
/* 1278 */     if (this.caseCount == 0) {
/* 1279 */       if (this.defaultCase != null && this.defaultCase.isExpr)
/* 1280 */         this.switchBits |= 0x1; 
/*      */       return;
/*      */     } 
/* 1283 */     if (this.cases[0] == null)
/*      */       return; 
/* 1285 */     boolean isExpr = (this.cases[0]).isExpr;
/* 1286 */     if (isExpr) this.switchBits |= 0x1; 
/* 1287 */     for (int i = 1, l = this.caseCount; i < l; i++) {
/* 1288 */       if ((this.cases[i]).isExpr != isExpr) {
/* 1289 */         this.scope.problemReporter().switchExpressionMixedCase(this.cases[i]);
/*      */         return;
/*      */       } 
/*      */     } 
/* 1293 */     if (this.defaultCase != null && this.defaultCase.isExpr != isExpr) {
/* 1294 */       this.scope.problemReporter().switchExpressionMixedCase(this.defaultCase);
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   private void reportDuplicateCase(Statement duplicate, Statement original, int length) {
/* 1300 */     if (this.duplicateCases == null) {
/* 1301 */       this.scope.problemReporter().duplicateCase(original);
/* 1302 */       if (duplicate != original)
/* 1303 */         this.scope.problemReporter().duplicateCase(duplicate); 
/* 1304 */       this.duplicateCases = new Statement[length];
/* 1305 */       this.duplicateCases[this.duplicateCaseCounter++] = original;
/* 1306 */       if (duplicate != original)
/* 1307 */         this.duplicateCases[this.duplicateCaseCounter++] = duplicate; 
/*      */     } else {
/* 1309 */       boolean found = false;
/* 1310 */       for (int k = 2; k < this.duplicateCaseCounter; k++) {
/* 1311 */         if (this.duplicateCases[k] == duplicate) {
/* 1312 */           found = true;
/*      */           break;
/*      */         } 
/*      */       } 
/* 1316 */       if (!found) {
/* 1317 */         this.scope.problemReporter().duplicateCase(duplicate);
/* 1318 */         this.duplicateCases[this.duplicateCaseCounter++] = duplicate;
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void traverse(ASTVisitor visitor, BlockScope blockScope) {
/* 1328 */     if (visitor.visit(this, blockScope)) {
/* 1329 */       this.expression.traverse(visitor, blockScope);
/* 1330 */       if (this.statements != null) {
/* 1331 */         int statementsLength = this.statements.length;
/* 1332 */         for (int i = 0; i < statementsLength; i++)
/* 1333 */           this.statements[i].traverse(visitor, this.scope); 
/*      */       } 
/*      */     } 
/* 1336 */     visitor.endVisit(this, blockScope);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void branchChainTo(BranchLabel label) {
/* 1350 */     if (this.breakLabel.forwardReferenceCount() > 0) {
/* 1351 */       label.becomeDelegateFor(this.breakLabel);
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean doesNotCompleteNormally() {
/* 1357 */     if (this.statements == null || this.statements.length == 0)
/* 1358 */       return false; 
/* 1359 */     for (int i = 0, length = this.statements.length; i < length; i++) {
/* 1360 */       if (this.statements[i].breaksOut((char[])null))
/* 1361 */         return false; 
/*      */     } 
/* 1363 */     return this.statements[this.statements.length - 1].doesNotCompleteNormally();
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean completesByContinue() {
/* 1368 */     if (this.statements == null || this.statements.length == 0)
/* 1369 */       return false; 
/* 1370 */     for (int i = 0, length = this.statements.length; i < length; i++) {
/* 1371 */       if (this.statements[i].completesByContinue())
/* 1372 */         return true; 
/*      */     } 
/* 1374 */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean canCompleteNormally() {
/* 1379 */     if (this.statements == null || this.statements.length == 0)
/* 1380 */       return true; 
/* 1381 */     if ((this.switchBits & 0x1) == 0) {
/* 1382 */       if (this.statements[this.statements.length - 1].canCompleteNormally())
/* 1383 */         return true; 
/* 1384 */       if (this.totalPattern == null && this.defaultCase == null)
/* 1385 */         return true; 
/* 1386 */       for (int i = 0, length = this.statements.length; i < length; i++) {
/* 1387 */         if (this.statements[i].breaksOut((char[])null))
/* 1388 */           return true; 
/*      */       } 
/*      */     } else {
/*      */       byte b; int i; Statement[] arrayOfStatement;
/* 1392 */       for (i = (arrayOfStatement = this.statements).length, b = 0; b < i; ) { Statement stmt = arrayOfStatement[b];
/* 1393 */         if (!(stmt instanceof CaseStatement)) {
/*      */           
/* 1395 */           if (this.totalPattern == null && this.defaultCase == null)
/* 1396 */             return true; 
/* 1397 */           if (stmt instanceof Expression)
/* 1398 */             return true; 
/* 1399 */           if (stmt.canCompleteNormally())
/* 1400 */             return true; 
/* 1401 */           if (stmt instanceof YieldStatement && ((YieldStatement)stmt).isImplicit)
/* 1402 */             return true; 
/* 1403 */           if (stmt instanceof Block) {
/* 1404 */             Block block = (Block)stmt;
/* 1405 */             if (block.canCompleteNormally())
/* 1406 */               return true; 
/* 1407 */             if (block.breaksOut((char[])null))
/* 1408 */               return true; 
/*      */           } 
/*      */         }  b++; }
/*      */     
/* 1412 */     }  return false;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean continueCompletes() {
/* 1417 */     if (this.statements == null || this.statements.length == 0)
/* 1418 */       return false; 
/* 1419 */     for (int i = 0, length = this.statements.length; i < length; i++) {
/* 1420 */       if (this.statements[i].continueCompletes())
/* 1421 */         return true; 
/*      */     } 
/* 1423 */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   public StringBuffer printExpression(int indent, StringBuffer output) {
/* 1428 */     return printStatement(indent, output);
/*      */   }
/*      */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\ast\SwitchStatement.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */