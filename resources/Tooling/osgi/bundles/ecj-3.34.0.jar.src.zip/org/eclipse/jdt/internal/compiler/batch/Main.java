/*      */ package org.eclipse.jdt.internal.compiler.batch;
/*      */ 
/*      */ import java.io.BufferedInputStream;
/*      */ import java.io.File;
/*      */ import java.io.FileInputStream;
/*      */ import java.io.FileNotFoundException;
/*      */ import java.io.FileOutputStream;
/*      */ import java.io.FilenameFilter;
/*      */ import java.io.IOException;
/*      */ import java.io.LineNumberReader;
/*      */ import java.io.OutputStreamWriter;
/*      */ import java.io.PrintWriter;
/*      */ import java.io.StringReader;
/*      */ import java.io.UnsupportedEncodingException;
/*      */ import java.lang.reflect.Field;
/*      */ import java.lang.reflect.InvocationTargetException;
/*      */ import java.lang.reflect.Method;
/*      */ import java.nio.file.Path;
/*      */ import java.nio.file.Paths;
/*      */ import java.text.DateFormat;
/*      */ import java.text.MessageFormat;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Arrays;
/*      */ import java.util.Collections;
/*      */ import java.util.Comparator;
/*      */ import java.util.Date;
/*      */ import java.util.HashMap;
/*      */ import java.util.HashSet;
/*      */ import java.util.Iterator;
/*      */ import java.util.List;
/*      */ import java.util.Locale;
/*      */ import java.util.Map;
/*      */ import java.util.MissingResourceException;
/*      */ import java.util.Properties;
/*      */ import java.util.ResourceBundle;
/*      */ import java.util.Set;
/*      */ import java.util.StringTokenizer;
/*      */ import java.util.function.Function;
/*      */ import org.eclipse.jdt.core.compiler.CategorizedProblem;
/*      */ import org.eclipse.jdt.core.compiler.CharOperation;
/*      */ import org.eclipse.jdt.core.compiler.CompilationProgress;
/*      */ import org.eclipse.jdt.core.compiler.IProblem;
/*      */ import org.eclipse.jdt.internal.compiler.AbstractAnnotationProcessorManager;
/*      */ import org.eclipse.jdt.internal.compiler.ClassFile;
/*      */ import org.eclipse.jdt.internal.compiler.CompilationResult;
/*      */ import org.eclipse.jdt.internal.compiler.Compiler;
/*      */ import org.eclipse.jdt.internal.compiler.ICompilerRequestor;
/*      */ import org.eclipse.jdt.internal.compiler.IErrorHandlingPolicy;
/*      */ import org.eclipse.jdt.internal.compiler.IProblemFactory;
/*      */ import org.eclipse.jdt.internal.compiler.ast.CompilationUnitDeclaration;
/*      */ import org.eclipse.jdt.internal.compiler.classfmt.ClassFileConstants;
/*      */ import org.eclipse.jdt.internal.compiler.classfmt.ClassFileReader;
/*      */ import org.eclipse.jdt.internal.compiler.classfmt.ClassFormatException;
/*      */ import org.eclipse.jdt.internal.compiler.env.AccessRule;
/*      */ import org.eclipse.jdt.internal.compiler.env.AccessRuleSet;
/*      */ import org.eclipse.jdt.internal.compiler.env.IBinaryModule;
/*      */ import org.eclipse.jdt.internal.compiler.env.ICompilationUnit;
/*      */ import org.eclipse.jdt.internal.compiler.env.IModule;
/*      */ import org.eclipse.jdt.internal.compiler.env.INameEnvironment;
/*      */ import org.eclipse.jdt.internal.compiler.env.IUpdatableModule;
/*      */ import org.eclipse.jdt.internal.compiler.impl.CompilerOptions;
/*      */ import org.eclipse.jdt.internal.compiler.impl.CompilerStats;
/*      */ import org.eclipse.jdt.internal.compiler.lookup.LookupEnvironment;
/*      */ import org.eclipse.jdt.internal.compiler.lookup.ModuleBinding;
/*      */ import org.eclipse.jdt.internal.compiler.lookup.PackageBinding;
/*      */ import org.eclipse.jdt.internal.compiler.lookup.PlainPackageBinding;
/*      */ import org.eclipse.jdt.internal.compiler.lookup.ReferenceBinding;
/*      */ import org.eclipse.jdt.internal.compiler.lookup.TypeConstants;
/*      */ import org.eclipse.jdt.internal.compiler.parser.Parser;
/*      */ import org.eclipse.jdt.internal.compiler.problem.AbortCompilation;
/*      */ import org.eclipse.jdt.internal.compiler.problem.DefaultProblem;
/*      */ import org.eclipse.jdt.internal.compiler.problem.DefaultProblemFactory;
/*      */ import org.eclipse.jdt.internal.compiler.problem.ProblemReporter;
/*      */ import org.eclipse.jdt.internal.compiler.problem.ProblemSeverities;
/*      */ import org.eclipse.jdt.internal.compiler.util.GenericXMLWriter;
/*      */ import org.eclipse.jdt.internal.compiler.util.HashtableOfInt;
/*      */ import org.eclipse.jdt.internal.compiler.util.HashtableOfObject;
/*      */ import org.eclipse.jdt.internal.compiler.util.Messages;
/*      */ import org.eclipse.jdt.internal.compiler.util.SuffixConstants;
/*      */ import org.eclipse.jdt.internal.compiler.util.Util;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class Main
/*      */   implements ProblemSeverities, SuffixConstants
/*      */ {
/*      */   private static final String ANNOTATION_SOURCE_CLASSPATH = "CLASSPATH";
/*      */   boolean enableJavadocOn;
/*      */   boolean warnJavadocOn;
/*      */   boolean warnAllJavadocOn;
/*      */   public Compiler batchCompiler;
/*      */   public ResourceBundle bundle;
/*      */   protected FileSystem.Classpath[] checkedClasspaths;
/*      */   protected IModule module;
/*      */   private String moduleVersion;
/*      */   protected List<String> annotationPaths;
/*      */   protected boolean annotationsFromClasspath;
/*      */   
/*      */   public static class Logger
/*      */   {
/*      */     private PrintWriter err;
/*      */     private PrintWriter log;
/*      */     private Main main;
/*      */     private PrintWriter out;
/*      */     int tagBits;
/*      */     private static final String CLASS = "class";
/*      */     private static final String CLASS_FILE = "classfile";
/*      */     private static final String CLASSPATH = "classpath";
/*      */     private static final String CLASSPATH_FILE = "FILE";
/*      */     private static final String CLASSPATH_FOLDER = "FOLDER";
/*      */     private static final String CLASSPATH_ID = "id";
/*      */     private static final String CLASSPATH_JAR = "JAR";
/*      */     private static final String CLASSPATHS = "classpaths";
/*      */     private static final String COMMAND_LINE_ARGUMENT = "argument";
/*      */     private static final String COMMAND_LINE_ARGUMENTS = "command_line";
/*      */     private static final String COMPILER = "compiler";
/*      */     private static final String COMPILER_COPYRIGHT = "copyright";
/*      */     private static final String COMPILER_NAME = "name";
/*      */     private static final String COMPILER_VERSION = "version";
/*      */     public static final int EMACS = 2;
/*      */     private static final String ERROR = "ERROR";
/*      */     private static final String ERROR_TAG = "error";
/*      */     private static final String WARNING_TAG = "warning";
/*      */     private static final String EXCEPTION = "exception";
/*      */     private static final String EXTRA_PROBLEM_TAG = "extra_problem";
/*      */     private static final String EXTRA_PROBLEMS = "extra_problems";
/*  151 */     private static final HashtableOfInt FIELD_TABLE = new HashtableOfInt();
/*      */     
/*      */     private static final String KEY = "key";
/*      */     
/*      */     private static final String MESSAGE = "message";
/*      */     private static final String NUMBER_OF_CLASSFILES = "number_of_classfiles";
/*      */     private static final String NUMBER_OF_ERRORS = "errors";
/*      */     private static final String NUMBER_OF_LINES = "number_of_lines";
/*      */     private static final String NUMBER_OF_PROBLEMS = "problems";
/*      */     private static final String NUMBER_OF_TASKS = "tasks";
/*      */     private static final String NUMBER_OF_WARNINGS = "warnings";
/*      */     private static final String NUMBER_OF_INFOS = "infos";
/*      */     private static final String OPTION = "option";
/*      */     private static final String OPTIONS = "options";
/*      */     private static final String OUTPUT = "output";
/*      */     private static final String PACKAGE = "package";
/*      */     private static final String PATH = "path";
/*      */     private static final String PROBLEM_ARGUMENT = "argument";
/*      */     private static final String PROBLEM_ARGUMENT_VALUE = "value";
/*      */     private static final String PROBLEM_ARGUMENTS = "arguments";
/*      */     private static final String PROBLEM_CATEGORY_ID = "categoryID";
/*      */     private static final String ID = "id";
/*      */     private static final String PROBLEM_ID = "problemID";
/*      */     private static final String PROBLEM_LINE = "line";
/*      */     private static final String PROBLEM_OPTION_KEY = "optionKey";
/*      */     private static final String PROBLEM_MESSAGE = "message";
/*      */     private static final String PROBLEM_SEVERITY = "severity";
/*      */     private static final String PROBLEM_SOURCE_END = "charEnd";
/*      */     private static final String PROBLEM_SOURCE_START = "charStart";
/*      */     private static final String PROBLEM_SUMMARY = "problem_summary";
/*      */     private static final String PROBLEM_TAG = "problem";
/*      */     private static final String PROBLEMS = "problems";
/*      */     private static final String SOURCE = "source";
/*      */     private static final String SOURCE_CONTEXT = "source_context";
/*      */     private static final String SOURCE_END = "sourceEnd";
/*      */     private static final String SOURCE_START = "sourceStart";
/*      */     private static final String SOURCES = "sources";
/*      */     private static final String STATS = "stats";
/*      */     private static final String TASK = "task";
/*      */     private static final String TASKS = "tasks";
/*      */     private static final String TIME = "time";
/*      */     private static final String VALUE = "value";
/*      */     private static final String WARNING = "WARNING";
/*      */     private static final String INFO = "INFO";
/*      */     public static final int XML = 1;
/*      */     private static final String XML_DTD_DECLARATION = "<!DOCTYPE compiler PUBLIC \"-//Eclipse.org//DTD Eclipse JDT 3.2.006 Compiler//EN\" \"https://www.eclipse.org/jdt/core/compiler_32_006.dtd\">";
/*      */     
/*      */     static {
/*      */       try {
/*  200 */         Class<?> c = IProblem.class;
/*  201 */         Field[] fields = c.getFields();
/*  202 */         for (int i = 0, max = fields.length; i < max; i++) {
/*  203 */           Field field = fields[i];
/*  204 */           if (field.getType().equals(int.class)) {
/*  205 */             Integer value = (Integer)field.get(null);
/*  206 */             int key2 = value.intValue() & 0x1FFFFF;
/*  207 */             if (key2 == 0) {
/*  208 */               key2 = Integer.MAX_VALUE;
/*      */             }
/*  210 */             FIELD_TABLE.put(key2, field.getName());
/*      */           } 
/*      */         } 
/*  213 */       } catch (SecurityException|IllegalArgumentException|IllegalAccessException e) {
/*  214 */         e.printStackTrace();
/*      */       } 
/*      */     }
/*      */     public Logger(Main main, PrintWriter out, PrintWriter err) {
/*  218 */       this.out = out;
/*  219 */       this.err = err;
/*  220 */       this.main = main;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public String buildFileName(String outputPath, String relativeFileName) {
/*  226 */       char fileSeparatorChar = File.separatorChar;
/*  227 */       String fileSeparator = File.separator;
/*      */       
/*  229 */       outputPath = outputPath.replace('/', fileSeparatorChar);
/*      */       
/*  231 */       StringBuilder outDir = new StringBuilder(outputPath);
/*  232 */       if (!outputPath.endsWith(fileSeparator)) {
/*  233 */         outDir.append(fileSeparator);
/*      */       }
/*  235 */       StringTokenizer tokenizer = 
/*  236 */         new StringTokenizer(relativeFileName, fileSeparator);
/*  237 */       String token = tokenizer.nextToken();
/*  238 */       while (tokenizer.hasMoreTokens()) {
/*  239 */         outDir.append(token).append(fileSeparator);
/*  240 */         token = tokenizer.nextToken();
/*      */       } 
/*      */       
/*  243 */       return outDir.append(token).toString();
/*      */     }
/*      */     
/*      */     public void close() {
/*  247 */       if (this.log != null) {
/*  248 */         if ((this.tagBits & 0x1) != 0) {
/*  249 */           endTag("compiler");
/*  250 */           flush();
/*      */         } 
/*  252 */         this.log.close();
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void compiling() {
/*  260 */       printlnOut(this.main.bind("progress.compiling"));
/*      */     }
/*      */     private void endLoggingExtraProblems() {
/*  263 */       endTag("extra_problems");
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private void endLoggingProblems() {
/*  270 */       endTag("problems");
/*      */     }
/*      */     public void endLoggingSource() {
/*  273 */       if ((this.tagBits & 0x1) != 0) {
/*  274 */         endTag("source");
/*      */       }
/*      */     }
/*      */     
/*      */     public void endLoggingSources() {
/*  279 */       if ((this.tagBits & 0x1) != 0) {
/*  280 */         endTag("sources");
/*      */       }
/*      */     }
/*      */     
/*      */     public void endLoggingTasks() {
/*  285 */       if ((this.tagBits & 0x1) != 0)
/*  286 */         endTag("tasks"); 
/*      */     }
/*      */     
/*      */     private void endTag(String name) {
/*  290 */       if (this.log != null) {
/*  291 */         ((GenericXMLWriter)this.log).endTag(name, true, true);
/*      */       }
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private String errorReportSource(CategorizedProblem problem, char[] unitSource, int bits) {
/*  302 */       int startPosition = problem.getSourceStart();
/*  303 */       int endPosition = problem.getSourceEnd();
/*  304 */       if (unitSource == null && 
/*  305 */         problem.getOriginatingFileName() != null) {
/*      */         try {
/*  307 */           unitSource = Util.getFileCharContent(new File(new String(problem.getOriginatingFileName())), null);
/*  308 */         } catch (IOException iOException) {}
/*      */       }
/*      */ 
/*      */       
/*      */       int length;
/*      */       
/*  314 */       if (startPosition > endPosition || (
/*  315 */         startPosition < 0 && endPosition < 0) || 
/*  316 */         unitSource == null || (
/*  317 */         length = unitSource.length) == 0) {
/*  318 */         return Messages.problem_noSourceInformation;
/*      */       }
/*  320 */       StringBuilder errorBuffer = new StringBuilder();
/*  321 */       if ((bits & 0x2) == 0) {
/*  322 */         errorBuffer.append(' ').append(Messages.bind(Messages.problem_atLine, String.valueOf(problem.getSourceLineNumber())));
/*  323 */         errorBuffer.append(Util.LINE_SEPARATOR);
/*      */       } 
/*  325 */       errorBuffer.append('\t');
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       char c;
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       int begin;
/*      */ 
/*      */ 
/*      */       
/*  339 */       for (begin = (startPosition >= length) ? (length - 1) : startPosition; begin > 0 && (
/*  340 */         c = unitSource[begin - 1]) != '\n' && c != '\r'; begin--);
/*      */       int end;
/*  342 */       for (end = (endPosition >= length) ? (length - 1) : endPosition; end + 1 < length && (
/*  343 */         c = unitSource[end + 1]) != '\r' && c != '\n'; end++);
/*      */ 
/*      */ 
/*      */       
/*  347 */       for (; (c = unitSource[begin]) == ' ' || c == '\t'; begin++);
/*      */ 
/*      */ 
/*      */       
/*  351 */       errorBuffer.append(unitSource, begin, end - begin + 1);
/*  352 */       errorBuffer.append(Util.LINE_SEPARATOR).append("\t");
/*      */       
/*      */       int i;
/*  355 */       for (i = begin; i < startPosition; i++) {
/*  356 */         errorBuffer.append((unitSource[i] == '\t') ? 9 : 32);
/*      */       }
/*  358 */       for (i = startPosition; i <= ((endPosition >= length) ? (length - 1) : endPosition); i++) {
/*  359 */         errorBuffer.append('^');
/*      */       }
/*  361 */       return errorBuffer.toString();
/*      */     }
/*      */ 
/*      */     
/*      */     private void extractContext(CategorizedProblem problem, char[] unitSource) {
/*  366 */       int startPosition = problem.getSourceStart();
/*  367 */       int endPosition = problem.getSourceEnd();
/*  368 */       if (unitSource == null && 
/*  369 */         problem.getOriginatingFileName() != null) {
/*      */         try {
/*  371 */           unitSource = Util.getFileCharContent(new File(new String(problem.getOriginatingFileName())), null);
/*  372 */         } catch (IOException iOException) {}
/*      */       }
/*      */ 
/*      */       
/*      */       int length;
/*      */       
/*  378 */       if (startPosition > endPosition || (
/*  379 */         startPosition < 0 && endPosition < 0) || 
/*  380 */         unitSource == null || (
/*  381 */         length = unitSource.length) <= 0 || 
/*  382 */         endPosition > length) {
/*  383 */         HashMap<String, Object> hashMap = new HashMap<>();
/*  384 */         hashMap.put("value", Messages.problem_noSourceInformation);
/*  385 */         hashMap.put("sourceStart", "-1");
/*  386 */         hashMap.put("sourceEnd", "-1");
/*  387 */         printTag("source_context", hashMap, true, true);
/*      */ 
/*      */         
/*      */         return;
/*      */       } 
/*      */ 
/*      */       
/*      */       char c;
/*      */ 
/*      */       
/*      */       int begin;
/*      */       
/*  399 */       for (begin = (startPosition >= length) ? (length - 1) : startPosition; begin > 0 && (
/*  400 */         c = unitSource[begin - 1]) != '\n' && c != '\r'; begin--);
/*      */       int end;
/*  402 */       for (end = (endPosition >= length) ? (length - 1) : endPosition; end + 1 < length && (
/*  403 */         c = unitSource[end + 1]) != '\r' && c != '\n'; end++);
/*      */ 
/*      */ 
/*      */       
/*  407 */       for (; (c = unitSource[begin]) == ' ' || c == '\t'; begin++);
/*  408 */       for (; (c = unitSource[end]) == ' ' || c == '\t'; end--);
/*      */ 
/*      */       
/*  411 */       StringBuffer buffer = new StringBuffer();
/*  412 */       buffer.append(unitSource, begin, end - begin + 1);
/*  413 */       HashMap<String, Object> parameters = new HashMap<>();
/*  414 */       parameters.put("value", String.valueOf(buffer));
/*  415 */       parameters.put("sourceStart", Integer.toString(startPosition - begin));
/*  416 */       parameters.put("sourceEnd", Integer.toString(endPosition - begin));
/*  417 */       printTag("source_context", parameters, true, true);
/*      */     }
/*      */     public void flush() {
/*  420 */       this.out.flush();
/*  421 */       this.err.flush();
/*  422 */       if (this.log != null) {
/*  423 */         this.log.flush();
/*      */       }
/*      */     }
/*      */     
/*      */     private String getFieldName(int id) {
/*  428 */       int key2 = id & 0x1FFFFF;
/*  429 */       if (key2 == 0) {
/*  430 */         key2 = Integer.MAX_VALUE;
/*      */       }
/*  432 */       return (String)FIELD_TABLE.get(key2);
/*      */     }
/*      */ 
/*      */     
/*      */     private String getProblemOptionKey(int problemID) {
/*  437 */       int irritant = ProblemReporter.getIrritant(problemID);
/*  438 */       return CompilerOptions.optionKeyFromIrritant(irritant);
/*      */     }
/*      */     
/*      */     public void logAverage() {
/*  442 */       Arrays.sort((Object[])this.main.compilerStats);
/*  443 */       long lineCount = (this.main.compilerStats[0]).lineCount;
/*  444 */       int length = this.main.maxRepetition;
/*  445 */       long sum = 0L;
/*  446 */       long parseSum = 0L, resolveSum = 0L, analyzeSum = 0L, generateSum = 0L;
/*  447 */       for (int i = 1, max = length - 1; i < max; i++) {
/*  448 */         CompilerStats stats = this.main.compilerStats[i];
/*  449 */         sum += stats.elapsedTime();
/*  450 */         parseSum += stats.parseTime;
/*  451 */         resolveSum += stats.resolveTime;
/*  452 */         analyzeSum += stats.analyzeTime;
/*  453 */         generateSum += stats.generateTime;
/*      */       } 
/*  455 */       long time = sum / (length - 2);
/*  456 */       long parseTime = parseSum / (length - 2);
/*  457 */       long resolveTime = resolveSum / (length - 2);
/*  458 */       long analyzeTime = analyzeSum / (length - 2);
/*  459 */       long generateTime = generateSum / (length - 2);
/*  460 */       printlnOut(this.main.bind(
/*  461 */             "compile.averageTime", 
/*  462 */             new String[] {
/*  463 */               String.valueOf(lineCount), 
/*  464 */               String.valueOf(time), 
/*  465 */               String.valueOf((int)(lineCount * 10000.0D / time) / 10.0D)
/*      */             }));
/*  467 */       if ((this.main.timing & 0x2) != 0)
/*  468 */         printlnOut(
/*  469 */             this.main.bind("compile.detailedTime", 
/*  470 */               new String[] {
/*  471 */                 String.valueOf(parseTime), 
/*  472 */                 String.valueOf((int)(parseTime * 1000.0D / time) / 10.0D), 
/*  473 */                 String.valueOf(resolveTime), 
/*  474 */                 String.valueOf((int)(resolveTime * 1000.0D / time) / 10.0D), 
/*  475 */                 String.valueOf(analyzeTime), 
/*  476 */                 String.valueOf((int)(analyzeTime * 1000.0D / time) / 10.0D), 
/*  477 */                 String.valueOf(generateTime), 
/*  478 */                 String.valueOf((int)(generateTime * 1000.0D / time) / 10.0D)
/*      */               })); 
/*      */     }
/*      */     
/*      */     public void logClassFile(boolean generatePackagesStructure, String outputPath, String relativeFileName) {
/*  483 */       if ((this.tagBits & 0x1) != 0) {
/*  484 */         String fileName = null;
/*  485 */         if (generatePackagesStructure) {
/*  486 */           fileName = buildFileName(outputPath, relativeFileName);
/*      */         } else {
/*  488 */           char fileSeparatorChar = File.separatorChar;
/*  489 */           String fileSeparator = File.separator;
/*      */           
/*  491 */           outputPath = outputPath.replace('/', fileSeparatorChar);
/*      */           
/*  493 */           int indexOfPackageSeparator = relativeFileName.lastIndexOf(fileSeparatorChar);
/*  494 */           if (indexOfPackageSeparator == -1) {
/*  495 */             if (outputPath.endsWith(fileSeparator)) {
/*  496 */               fileName = String.valueOf(outputPath) + relativeFileName;
/*      */             } else {
/*  498 */               fileName = String.valueOf(outputPath) + fileSeparator + relativeFileName;
/*      */             } 
/*      */           } else {
/*  501 */             int length = relativeFileName.length();
/*  502 */             if (outputPath.endsWith(fileSeparator)) {
/*  503 */               fileName = String.valueOf(outputPath) + relativeFileName.substring(indexOfPackageSeparator + 1, length);
/*      */             } else {
/*  505 */               fileName = String.valueOf(outputPath) + fileSeparator + relativeFileName.substring(indexOfPackageSeparator + 1, length);
/*      */             } 
/*      */           } 
/*      */         } 
/*  509 */         File f = new File(fileName);
/*      */         try {
/*  511 */           HashMap<String, Object> parameters = new HashMap<>();
/*  512 */           parameters.put("path", f.getCanonicalPath());
/*  513 */           printTag("classfile", parameters, true, true);
/*  514 */         } catch (IOException e) {
/*  515 */           logNoClassFileCreated(outputPath, relativeFileName, e);
/*      */         } 
/*      */       } 
/*      */     }
/*      */     public void logClasspath(FileSystem.Classpath[] classpaths) {
/*  520 */       if (classpaths == null)
/*  521 */         return;  if ((this.tagBits & 0x1) != 0) {
/*  522 */         int length = classpaths.length;
/*  523 */         if (length != 0) {
/*      */           
/*  525 */           printTag("classpaths", new HashMap<>(), true, false);
/*  526 */           HashMap<String, Object> parameters = new HashMap<>();
/*  527 */           for (int i = 0; i < length; i++) {
/*  528 */             String classpath = classpaths[i].getPath();
/*  529 */             parameters.put("path", classpath);
/*  530 */             File f = new File(classpath);
/*  531 */             String id = null;
/*  532 */             if (f.isFile()) {
/*  533 */               int kind = Util.archiveFormat(classpath);
/*  534 */               switch (kind) {
/*      */                 case 0:
/*  536 */                   id = "JAR";
/*      */                   break;
/*      */                 default:
/*  539 */                   id = "FILE";
/*      */                   break;
/*      */               } 
/*  542 */             } else if (f.isDirectory()) {
/*  543 */               id = "FOLDER";
/*      */             } 
/*  545 */             if (id != null) {
/*  546 */               parameters.put("id", id);
/*  547 */               printTag("classpath", parameters, true, true);
/*      */             } 
/*      */           } 
/*  550 */           endTag("classpaths");
/*      */         } 
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     public void logCommandLineArguments(String[] commandLineArguments) {
/*  557 */       if (commandLineArguments == null)
/*  558 */         return;  if ((this.tagBits & 0x1) != 0) {
/*  559 */         int length = commandLineArguments.length;
/*  560 */         if (length != 0) {
/*      */           
/*  562 */           printTag("command_line", new HashMap<>(), true, false);
/*  563 */           for (int i = 0; i < length; i++) {
/*  564 */             HashMap<String, Object> parameters = new HashMap<>();
/*  565 */             parameters.put("value", commandLineArguments[i]);
/*  566 */             printTag("argument", parameters, true, true);
/*      */           } 
/*  568 */           endTag("command_line");
/*      */         } 
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void logException(Exception e) {
/*      */       // Byte code:
/*      */       //   0: new java/io/StringWriter
/*      */       //   3: dup
/*      */       //   4: invokespecial <init> : ()V
/*      */       //   7: astore_2
/*      */       //   8: new java/io/PrintWriter
/*      */       //   11: dup
/*      */       //   12: aload_2
/*      */       //   13: invokespecial <init> : (Ljava/io/Writer;)V
/*      */       //   16: astore_3
/*      */       //   17: aload_1
/*      */       //   18: aload_3
/*      */       //   19: invokevirtual printStackTrace : (Ljava/io/PrintWriter;)V
/*      */       //   22: aload_3
/*      */       //   23: invokevirtual flush : ()V
/*      */       //   26: aload_3
/*      */       //   27: invokevirtual close : ()V
/*      */       //   30: aload_2
/*      */       //   31: invokevirtual toString : ()Ljava/lang/String;
/*      */       //   34: astore #4
/*      */       //   36: aload_0
/*      */       //   37: getfield tagBits : I
/*      */       //   40: iconst_1
/*      */       //   41: iand
/*      */       //   42: ifeq -> 194
/*      */       //   45: new java/io/LineNumberReader
/*      */       //   48: dup
/*      */       //   49: new java/io/StringReader
/*      */       //   52: dup
/*      */       //   53: aload #4
/*      */       //   55: invokespecial <init> : (Ljava/lang/String;)V
/*      */       //   58: invokespecial <init> : (Ljava/io/Reader;)V
/*      */       //   61: astore #5
/*      */       //   63: iconst_0
/*      */       //   64: istore #7
/*      */       //   66: new java/lang/StringBuilder
/*      */       //   69: dup
/*      */       //   70: invokespecial <init> : ()V
/*      */       //   73: astore #8
/*      */       //   75: aload_1
/*      */       //   76: invokevirtual getMessage : ()Ljava/lang/String;
/*      */       //   79: astore #9
/*      */       //   81: aload #9
/*      */       //   83: ifnull -> 120
/*      */       //   86: aload #8
/*      */       //   88: aload #9
/*      */       //   90: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
/*      */       //   93: getstatic org/eclipse/jdt/internal/compiler/util/Util.LINE_SEPARATOR : Ljava/lang/String;
/*      */       //   96: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
/*      */       //   99: pop
/*      */       //   100: goto -> 120
/*      */       //   103: aload #8
/*      */       //   105: aload #6
/*      */       //   107: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
/*      */       //   110: getstatic org/eclipse/jdt/internal/compiler/util/Util.LINE_SEPARATOR : Ljava/lang/String;
/*      */       //   113: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
/*      */       //   116: pop
/*      */       //   117: iinc #7, 1
/*      */       //   120: aload #5
/*      */       //   122: invokevirtual readLine : ()Ljava/lang/String;
/*      */       //   125: dup
/*      */       //   126: astore #6
/*      */       //   128: ifnull -> 137
/*      */       //   131: iload #7
/*      */       //   133: iconst_4
/*      */       //   134: if_icmplt -> 103
/*      */       //   137: aload #5
/*      */       //   139: invokevirtual close : ()V
/*      */       //   142: goto -> 146
/*      */       //   145: pop
/*      */       //   146: aload #8
/*      */       //   148: invokevirtual toString : ()Ljava/lang/String;
/*      */       //   151: astore #9
/*      */       //   153: new java/util/HashMap
/*      */       //   156: dup
/*      */       //   157: invokespecial <init> : ()V
/*      */       //   160: astore #10
/*      */       //   162: aload #10
/*      */       //   164: ldc 'message'
/*      */       //   166: aload #9
/*      */       //   168: invokevirtual put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
/*      */       //   171: pop
/*      */       //   172: aload #10
/*      */       //   174: ldc 'class'
/*      */       //   176: aload_1
/*      */       //   177: invokevirtual getClass : ()Ljava/lang/Class;
/*      */       //   180: invokevirtual put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
/*      */       //   183: pop
/*      */       //   184: aload_0
/*      */       //   185: ldc 'exception'
/*      */       //   187: aload #10
/*      */       //   189: iconst_1
/*      */       //   190: iconst_1
/*      */       //   191: invokevirtual printTag : (Ljava/lang/String;Ljava/util/HashMap;ZZ)V
/*      */       //   194: aload_1
/*      */       //   195: invokevirtual getMessage : ()Ljava/lang/String;
/*      */       //   198: astore #5
/*      */       //   200: aload #5
/*      */       //   202: ifnonnull -> 214
/*      */       //   205: aload_0
/*      */       //   206: aload #4
/*      */       //   208: invokevirtual printlnErr : (Ljava/lang/String;)V
/*      */       //   211: goto -> 220
/*      */       //   214: aload_0
/*      */       //   215: aload #5
/*      */       //   217: invokevirtual printlnErr : (Ljava/lang/String;)V
/*      */       //   220: return
/*      */       // Line number table:
/*      */       //   Java source line number -> byte code offset
/*      */       //   #577	-> 0
/*      */       //   #578	-> 8
/*      */       //   #579	-> 17
/*      */       //   #580	-> 22
/*      */       //   #581	-> 26
/*      */       //   #582	-> 30
/*      */       //   #583	-> 36
/*      */       //   #584	-> 45
/*      */       //   #586	-> 63
/*      */       //   #587	-> 66
/*      */       //   #588	-> 75
/*      */       //   #589	-> 81
/*      */       //   #590	-> 86
/*      */       //   #593	-> 100
/*      */       //   #594	-> 103
/*      */       //   #595	-> 117
/*      */       //   #593	-> 120
/*      */       //   #597	-> 137
/*      */       //   #598	-> 142
/*      */       //   #601	-> 146
/*      */       //   #602	-> 153
/*      */       //   #603	-> 162
/*      */       //   #604	-> 172
/*      */       //   #605	-> 184
/*      */       //   #607	-> 194
/*      */       //   #608	-> 200
/*      */       //   #609	-> 205
/*      */       //   #610	-> 211
/*      */       //   #611	-> 214
/*      */       //   #613	-> 220
/*      */       // Local variable table:
/*      */       //   start	length	slot	name	descriptor
/*      */       //   0	221	0	this	Lorg/eclipse/jdt/internal/compiler/batch/Main$Logger;
/*      */       //   0	221	1	e	Ljava/lang/Exception;
/*      */       //   8	213	2	writer	Ljava/io/StringWriter;
/*      */       //   17	204	3	printWriter	Ljava/io/PrintWriter;
/*      */       //   36	185	4	stackTrace	Ljava/lang/String;
/*      */       //   63	131	5	reader	Ljava/io/LineNumberReader;
/*      */       //   103	17	6	line	Ljava/lang/String;
/*      */       //   128	17	6	line	Ljava/lang/String;
/*      */       //   66	128	7	i	I
/*      */       //   75	119	8	buffer	Ljava/lang/StringBuilder;
/*      */       //   81	113	9	message	Ljava/lang/String;
/*      */       //   162	32	10	parameters	Ljava/util/HashMap;
/*      */       //   200	21	5	message	Ljava/lang/String;
/*      */       // Local variable type table:
/*      */       //   start	length	slot	name	signature
/*      */       //   162	32	10	parameters	Ljava/util/HashMap<Ljava/lang/String;Ljava/lang/Object;>;
/*      */       // Exception table:
/*      */       //   from	to	target	type
/*      */       //   100	142	145	java/io/IOException
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private void logExtraProblem(CategorizedProblem problem, int localErrorCount, int globalErrorCount) {
/*  616 */       char[] originatingFileName = problem.getOriginatingFileName();
/*  617 */       if (originatingFileName == null) {
/*      */         
/*  619 */         String severity = problem.isError() ? "requestor.extraerror" : (
/*  620 */           problem.isInfo() ? "requestor.extrainfo" : "requestor.extrawarning");
/*  621 */         printErr(this.main.bind(
/*  622 */               severity, 
/*  623 */               Integer.toString(globalErrorCount)));
/*  624 */         printErr(" ");
/*  625 */         printlnErr(problem.getMessage());
/*      */       } else {
/*  627 */         String fileName = new String(originatingFileName);
/*  628 */         if ((this.tagBits & 0x2) != 0) {
/*  629 */           String severity = problem.isError() ? "output.emacs.error" : (
/*  630 */             problem.isInfo() ? "output.emacs.info" : 
/*  631 */             "output.emacs.warning");
/*  632 */           String result = String.valueOf(fileName) + 
/*  633 */             ":" + 
/*  634 */             problem.getSourceLineNumber() + 
/*  635 */             ": " + 
/*  636 */             this.main.bind(severity) + 
/*  637 */             ": " + 
/*  638 */             problem.getMessage();
/*  639 */           printlnErr(result);
/*  640 */           String errorReportSource = errorReportSource(problem, null, this.tagBits);
/*  641 */           printlnErr(errorReportSource);
/*      */         } else {
/*  643 */           if (localErrorCount == 0) {
/*  644 */             printlnErr("----------");
/*      */           }
/*  646 */           String severity = problem.isError() ? "requestor.error" : (
/*  647 */             problem.isInfo() ? "requestor.info" : "requestor.warning");
/*  648 */           printErr(this.main.bind(
/*  649 */                 severity, 
/*  650 */                 Integer.toString(globalErrorCount), 
/*  651 */                 fileName));
/*  652 */           String errorReportSource = errorReportSource(problem, null, 0);
/*  653 */           printlnErr(errorReportSource);
/*  654 */           printlnErr(problem.getMessage());
/*  655 */           printlnErr("----------");
/*      */         } 
/*      */       } 
/*      */     }
/*      */     
/*      */     public void loggingExtraProblems(Main currentMain) {
/*  661 */       ArrayList<CategorizedProblem> problems = currentMain.extraProblems;
/*  662 */       int count = problems.size();
/*  663 */       int localProblemCount = 0;
/*  664 */       if (count != 0) {
/*  665 */         int errors = 0;
/*  666 */         int warnings = 0;
/*  667 */         int infos = 0; int i;
/*  668 */         for (i = 0; i < count; i++) {
/*  669 */           CategorizedProblem problem = problems.get(i);
/*  670 */           if (!this.main.isIgnored((IProblem)problem)) {
/*  671 */             currentMain.globalProblemsCount++;
/*  672 */             logExtraProblem(problem, localProblemCount, currentMain.globalProblemsCount);
/*  673 */             localProblemCount++;
/*  674 */             if (problem.isError()) {
/*  675 */               errors++;
/*  676 */               currentMain.globalErrorsCount++;
/*  677 */             } else if (problem.isInfo()) {
/*  678 */               currentMain.globalInfoCount++;
/*  679 */               infos++;
/*      */             } else {
/*  681 */               currentMain.globalWarningsCount++;
/*  682 */               warnings++;
/*      */             } 
/*      */           } 
/*      */         } 
/*  686 */         if ((this.tagBits & 0x1) != 0 && 
/*  687 */           errors + warnings + infos != 0) {
/*  688 */           startLoggingExtraProblems(count);
/*  689 */           for (i = 0; i < count; i++) {
/*  690 */             CategorizedProblem problem = problems.get(i);
/*  691 */             if (!this.main.isIgnored((IProblem)problem) && 
/*  692 */               problem.getID() != 536871362) {
/*  693 */               logXmlExtraProblem(problem, localProblemCount, currentMain.globalProblemsCount);
/*      */             }
/*      */           } 
/*      */           
/*  697 */           endLoggingExtraProblems();
/*      */         } 
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     public void logUnavaibleAPT(String className) {
/*  704 */       if ((this.tagBits & 0x1) != 0) {
/*  705 */         HashMap<String, Object> parameters = new HashMap<>();
/*  706 */         parameters.put("message", this.main.bind("configure.unavailableAPT", className));
/*  707 */         printTag("error", parameters, true, true);
/*      */       } 
/*  709 */       printlnErr(this.main.bind("configure.unavailableAPT", className));
/*      */     }
/*      */     
/*      */     public void logIncorrectVMVersionForAnnotationProcessing() {
/*  713 */       if ((this.tagBits & 0x1) != 0) {
/*  714 */         HashMap<String, Object> parameters = new HashMap<>();
/*  715 */         parameters.put("message", this.main.bind("configure.incorrectVMVersionforAPT"));
/*  716 */         printTag("error", parameters, true, true);
/*      */       } 
/*  718 */       printlnErr(this.main.bind("configure.incorrectVMVersionforAPT"));
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void logNoClassFileCreated(String outputDir, String relativeFileName, IOException e) {
/*  725 */       if ((this.tagBits & 0x1) != 0) {
/*  726 */         HashMap<String, Object> parameters = new HashMap<>();
/*  727 */         parameters.put("message", this.main.bind("output.noClassFileCreated", 
/*  728 */               new String[] {
/*  729 */                 outputDir, 
/*  730 */                 relativeFileName, 
/*  731 */                 e.getMessage()
/*      */               }));
/*  733 */         printTag("error", parameters, true, true);
/*      */       } 
/*  735 */       printlnErr(this.main.bind("output.noClassFileCreated", 
/*  736 */             new String[] {
/*  737 */               outputDir, 
/*  738 */               relativeFileName, 
/*  739 */               e.getMessage()
/*      */             }));
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void logNumberOfClassFilesGenerated(int exportedClassFilesCounter) {
/*  747 */       if ((this.tagBits & 0x1) != 0) {
/*  748 */         HashMap<String, Object> parameters = new HashMap<>();
/*  749 */         parameters.put("value", Integer.valueOf(exportedClassFilesCounter));
/*  750 */         printTag("number_of_classfiles", parameters, true, true);
/*      */       } 
/*  752 */       if (exportedClassFilesCounter == 1) {
/*  753 */         printlnOut(this.main.bind("compile.oneClassFileGenerated"));
/*      */       } else {
/*  755 */         printlnOut(this.main.bind("compile.severalClassFilesGenerated", 
/*  756 */               String.valueOf(exportedClassFilesCounter)));
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void logOptions(Map<String, String> options) {
/*  764 */       if ((this.tagBits & 0x1) != 0) {
/*  765 */         printTag("options", new HashMap<>(), true, false);
/*  766 */         Set<Map.Entry<String, String>> entriesSet = options.entrySet();
/*  767 */         Map.Entry[] entries = entriesSet.<Map.Entry>toArray(new Map.Entry[entriesSet.size()]);
/*  768 */         Arrays.sort(entries, (Comparator)new Comparator<Map.Entry<String, String>>()
/*      */             {
/*      */               public int compare(Map.Entry<String, String> o1, Map.Entry<String, String> o2) {
/*  771 */                 Map.Entry<String, String> entry1 = o1;
/*  772 */                 Map.Entry<String, String> entry2 = o2;
/*  773 */                 return ((String)entry1.getKey()).compareTo(entry2.getKey());
/*      */               }
/*      */             });
/*  776 */         HashMap<String, Object> parameters = new HashMap<>();
/*  777 */         for (int i = 0, max = entries.length; i < max; i++) {
/*  778 */           Map.Entry<String, String> entry = entries[i];
/*  779 */           String key = entry.getKey();
/*  780 */           parameters.put("key", key);
/*  781 */           parameters.put("value", entry.getValue());
/*  782 */           printTag("option", parameters, true, true);
/*      */         } 
/*  784 */         endTag("options");
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void logPendingError(String error) {
/*  792 */       if ((this.tagBits & 0x1) != 0) {
/*  793 */         HashMap<String, Object> parameters = new HashMap<>();
/*  794 */         parameters.put("message", error);
/*  795 */         printTag("error", parameters, true, true);
/*      */       } 
/*  797 */       printlnErr(error);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void logWarning(String message) {
/*  804 */       if ((this.tagBits & 0x1) != 0) {
/*  805 */         HashMap<String, Object> parameters = new HashMap<>();
/*  806 */         parameters.put("message", message);
/*  807 */         printTag("warning", parameters, true, true);
/*      */       } 
/*  809 */       printlnOut(message);
/*      */     }
/*      */ 
/*      */     
/*      */     private void logProblem(CategorizedProblem problem, int localErrorCount, int globalErrorCount, char[] unitSource) {
/*  814 */       if (problem instanceof DefaultProblem) {
/*  815 */         ((DefaultProblem)problem).reportError();
/*      */       }
/*  817 */       if ((this.tagBits & 0x2) != 0) {
/*  818 */         String severity = problem.isError() ? "output.emacs.error" : (
/*  819 */           problem.isInfo() ? "output.emacs.info" : 
/*  820 */           "output.emacs.warning");
/*  821 */         String result = String.valueOf(new String(problem.getOriginatingFileName())) + 
/*  822 */           ":" + 
/*  823 */           problem.getSourceLineNumber() + 
/*  824 */           ": " + 
/*  825 */           this.main.bind(severity) + 
/*  826 */           ": " + 
/*  827 */           problem.getMessage();
/*  828 */         printlnErr(result);
/*  829 */         String errorReportSource = errorReportSource(problem, unitSource, this.tagBits);
/*  830 */         if (errorReportSource.length() != 0) printlnErr(errorReportSource); 
/*      */       } else {
/*  832 */         if (localErrorCount == 0) {
/*  833 */           printlnErr("----------");
/*      */         }
/*  835 */         String severity = problem.isError() ? "requestor.error" : (problem.isInfo() ? "requestor.info" : "requestor.warning");
/*  836 */         printErr(this.main.bind(severity, 
/*  837 */               Integer.toString(globalErrorCount), 
/*  838 */               new String(problem.getOriginatingFileName())));
/*      */         try {
/*  840 */           String errorReportSource = errorReportSource(problem, unitSource, 0);
/*  841 */           printlnErr(errorReportSource);
/*  842 */           printlnErr(problem.getMessage());
/*  843 */         } catch (Exception exception) {
/*  844 */           printlnErr(this.main.bind(
/*  845 */                 "requestor.notRetrieveErrorMessage", problem.toString()));
/*      */         } 
/*  847 */         printlnErr("----------");
/*      */       } 
/*      */     }
/*      */     
/*      */     public int logProblems(CategorizedProblem[] problems, char[] unitSource, Main currentMain) {
/*  852 */       int count = problems.length;
/*  853 */       int localErrorCount = 0;
/*  854 */       int localProblemCount = 0;
/*  855 */       if (count != 0) {
/*  856 */         int errors = 0;
/*  857 */         int warnings = 0;
/*  858 */         int infos = 0;
/*  859 */         int tasks = 0; int i;
/*  860 */         for (i = 0; i < count; i++) {
/*  861 */           CategorizedProblem problem = problems[i];
/*  862 */           if (problem != null) {
/*  863 */             currentMain.globalProblemsCount++;
/*  864 */             logProblem(problem, localProblemCount, currentMain.globalProblemsCount, unitSource);
/*  865 */             localProblemCount++;
/*  866 */             if (problem.isError()) {
/*  867 */               localErrorCount++;
/*  868 */               errors++;
/*  869 */               currentMain.globalErrorsCount++;
/*  870 */             } else if (problem.getID() == 536871362) {
/*  871 */               currentMain.globalTasksCount++;
/*  872 */               tasks++;
/*  873 */             } else if (problem.isInfo()) {
/*  874 */               currentMain.globalInfoCount++;
/*  875 */               infos++;
/*      */             } else {
/*  877 */               currentMain.globalWarningsCount++;
/*  878 */               warnings++;
/*      */             } 
/*      */           } 
/*      */         } 
/*  882 */         if ((this.tagBits & 0x1) != 0) {
/*  883 */           if (errors + warnings + infos != 0) {
/*  884 */             startLoggingProblems(errors, warnings, infos);
/*  885 */             for (i = 0; i < count; i++) {
/*  886 */               CategorizedProblem problem = problems[i];
/*  887 */               if (problem != null && 
/*  888 */                 problem.getID() != 536871362) {
/*  889 */                 logXmlProblem(problem, unitSource);
/*      */               }
/*      */             } 
/*      */             
/*  893 */             endLoggingProblems();
/*      */           } 
/*  895 */           if (tasks != 0) {
/*  896 */             startLoggingTasks(tasks);
/*  897 */             for (i = 0; i < count; i++) {
/*  898 */               CategorizedProblem problem = problems[i];
/*  899 */               if (problem != null && 
/*  900 */                 problem.getID() == 536871362) {
/*  901 */                 logXmlTask(problem, unitSource);
/*      */               }
/*      */             } 
/*      */             
/*  905 */             endLoggingTasks();
/*      */           } 
/*      */         } 
/*      */       } 
/*  909 */       return localErrorCount;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void logProblemsSummary(int globalProblemsCount, int globalErrorsCount, int globalWarningsCount, int globalInfoCount, int globalTasksCount) {
/*  919 */       if ((this.tagBits & 0x1) != 0) {
/*      */         
/*  921 */         HashMap<String, Object> parameters = new HashMap<>();
/*  922 */         parameters.put("problems", Integer.valueOf(globalProblemsCount));
/*  923 */         parameters.put("errors", Integer.valueOf(globalErrorsCount));
/*  924 */         parameters.put("warnings", Integer.valueOf(globalWarningsCount));
/*  925 */         parameters.put("infos", Integer.valueOf(globalInfoCount));
/*  926 */         parameters.put("tasks", Integer.valueOf(globalTasksCount));
/*  927 */         printTag("problem_summary", parameters, true, true);
/*      */       } 
/*  929 */       if (globalProblemsCount == 1) {
/*  930 */         String message = null;
/*  931 */         if (globalErrorsCount == 1) {
/*  932 */           message = this.main.bind("compile.oneError");
/*  933 */         } else if (globalInfoCount == 1) {
/*  934 */           message = this.main.bind("compile.oneInfo");
/*      */         } else {
/*  936 */           message = this.main.bind("compile.oneWarning");
/*      */         } 
/*  938 */         printErr(this.main.bind("compile.oneProblem", message));
/*      */       } else {
/*  940 */         String errorMessage = null;
/*  941 */         String warningMessage = null;
/*  942 */         String infoMessage = null;
/*  943 */         if (globalErrorsCount > 0) {
/*  944 */           if (globalErrorsCount == 1) {
/*  945 */             errorMessage = this.main.bind("compile.oneError");
/*      */           } else {
/*  947 */             errorMessage = this.main.bind("compile.severalErrors", String.valueOf(globalErrorsCount));
/*      */           } 
/*      */         }
/*  950 */         int warningsNumber = globalWarningsCount + globalTasksCount;
/*  951 */         if (warningsNumber > 0) {
/*  952 */           if (warningsNumber == 1) {
/*  953 */             warningMessage = this.main.bind("compile.oneWarning");
/*      */           } else {
/*  955 */             warningMessage = this.main.bind("compile.severalWarnings", String.valueOf(warningsNumber));
/*      */           } 
/*      */         }
/*  958 */         if (globalInfoCount == 1) {
/*  959 */           infoMessage = this.main.bind("compile.oneInfo");
/*  960 */         } else if (globalInfoCount > 1) {
/*  961 */           infoMessage = this.main.bind("compile.severalInfos", String.valueOf(globalInfoCount));
/*      */         } 
/*  963 */         if (globalProblemsCount == globalInfoCount || globalProblemsCount == globalErrorsCount || globalProblemsCount == globalWarningsCount) {
/*  964 */           String msg = (errorMessage != null) ? errorMessage : ((warningMessage != null) ? warningMessage : infoMessage);
/*  965 */           printErr(this.main.bind(
/*  966 */                 "compile.severalProblemsErrorsOrWarnings", 
/*  967 */                 String.valueOf(globalProblemsCount), 
/*  968 */                 msg));
/*      */         }
/*  970 */         else if (globalInfoCount == 0) {
/*  971 */           printErr(this.main.bind(
/*  972 */                 "compile.severalProblemsErrorsAndWarnings", 
/*  973 */                 new String[] {
/*  974 */                   String.valueOf(globalProblemsCount), 
/*  975 */                   errorMessage, 
/*  976 */                   warningMessage
/*      */                 }));
/*      */         } else {
/*  979 */           if (errorMessage == null) {
/*  980 */             errorMessage = this.main.bind("compile.severalErrors", String.valueOf(globalErrorsCount));
/*      */           }
/*  982 */           if (warningMessage == null) {
/*  983 */             warningMessage = this.main.bind("compile.severalWarnings", String.valueOf(warningsNumber));
/*      */           }
/*  985 */           printErr(this.main.bind(
/*  986 */                 "compile.severalProblems", 
/*  987 */                 new String[] {
/*  988 */                   String.valueOf(globalProblemsCount), 
/*  989 */                   errorMessage, 
/*  990 */                   warningMessage, 
/*  991 */                   infoMessage
/*      */                 }));
/*      */         } 
/*      */       } 
/*      */       
/*  996 */       if (this.main.failOnWarning && globalWarningsCount > 0) {
/*  997 */         printErr("\n");
/*  998 */         printErr(this.main.bind("compile.failOnWarning"));
/*      */       } 
/* 1000 */       if ((this.tagBits & 0x1) == 0) {
/* 1001 */         printlnErr();
/*      */       }
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void logProgress() {
/* 1009 */       printOut('.');
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void logRepetition(int i, int repetitions) {
/* 1019 */       printlnOut(this.main.bind("compile.repetition", 
/* 1020 */             String.valueOf(i + 1), String.valueOf(repetitions)));
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public void logTiming(CompilerStats compilerStats) {
/* 1026 */       long time = compilerStats.elapsedTime();
/* 1027 */       long lineCount = compilerStats.lineCount;
/* 1028 */       if ((this.tagBits & 0x1) != 0) {
/* 1029 */         HashMap<String, Object> parameters = new HashMap<>();
/* 1030 */         parameters.put("value", Long.valueOf(time));
/* 1031 */         printTag("time", parameters, true, true);
/* 1032 */         parameters.put("value", Long.valueOf(lineCount));
/* 1033 */         printTag("number_of_lines", parameters, true, true);
/*      */       } 
/* 1035 */       if (lineCount != 0L) {
/* 1036 */         printlnOut(
/* 1037 */             this.main.bind("compile.instantTime", 
/* 1038 */               new String[] {
/* 1039 */                 String.valueOf(lineCount), 
/* 1040 */                 String.valueOf(time), 
/* 1041 */                 String.valueOf((int)(lineCount * 10000.0D / time) / 10.0D)
/*      */               }));
/*      */       } else {
/* 1044 */         printlnOut(
/* 1045 */             this.main.bind("compile.totalTime", 
/* 1046 */               new String[] {
/* 1047 */                 String.valueOf(time)
/*      */               }));
/*      */       } 
/* 1050 */       if ((this.main.timing & 0x2) != 0) {
/* 1051 */         printlnOut(
/* 1052 */             this.main.bind("compile.detailedTime", 
/* 1053 */               new String[] {
/* 1054 */                 String.valueOf(compilerStats.parseTime), 
/* 1055 */                 String.valueOf((int)(compilerStats.parseTime * 1000.0D / time) / 10.0D), 
/* 1056 */                 String.valueOf(compilerStats.resolveTime), 
/* 1057 */                 String.valueOf((int)(compilerStats.resolveTime * 1000.0D / time) / 10.0D), 
/* 1058 */                 String.valueOf(compilerStats.analyzeTime), 
/* 1059 */                 String.valueOf((int)(compilerStats.analyzeTime * 1000.0D / time) / 10.0D), 
/* 1060 */                 String.valueOf(compilerStats.generateTime), 
/* 1061 */                 String.valueOf((int)(compilerStats.generateTime * 1000.0D / time) / 10.0D)
/*      */               }));
/*      */       }
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void logUsage(String usage) {
/* 1071 */       printlnOut(usage);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void logVersion(boolean printToOut) {
/* 1078 */       if (this.log != null && (this.tagBits & 0x1) == 0) {
/* 1079 */         String version = this.main.bind("misc.version", 
/* 1080 */             new String[] {
/* 1081 */               this.main.bind("compiler.name"), 
/* 1082 */               this.main.bind("compiler.version"), 
/* 1083 */               this.main.bind("compiler.copyright")
/*      */             });
/*      */         
/* 1086 */         this.log.println("# " + version);
/* 1087 */         if (printToOut) {
/* 1088 */           this.out.println(version);
/* 1089 */           this.out.flush();
/*      */         } 
/* 1091 */       } else if (printToOut) {
/* 1092 */         String version = this.main.bind("misc.version", 
/* 1093 */             new String[] {
/* 1094 */               this.main.bind("compiler.name"), 
/* 1095 */               this.main.bind("compiler.version"), 
/* 1096 */               this.main.bind("compiler.copyright")
/*      */             });
/*      */         
/* 1099 */         this.out.println(version);
/* 1100 */         this.out.flush();
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void logWrongJDK() {
/* 1108 */       if ((this.tagBits & 0x1) != 0) {
/* 1109 */         HashMap<String, Object> parameters = new HashMap<>();
/* 1110 */         parameters.put("message", this.main.bind("configure.requiresJDK1.2orAbove"));
/* 1111 */         printTag("ERROR", parameters, true, true);
/*      */       } 
/* 1113 */       printlnErr(this.main.bind("configure.requiresJDK1.2orAbove"));
/*      */     }
/*      */     
/*      */     private void logXmlExtraProblem(CategorizedProblem problem, int globalErrorCount, int localErrorCount) {
/* 1117 */       int sourceStart = problem.getSourceStart();
/* 1118 */       int sourceEnd = problem.getSourceEnd();
/* 1119 */       boolean isError = problem.isError();
/* 1120 */       HashMap<String, Object> parameters = new HashMap<>();
/* 1121 */       parameters.put("severity", isError ? "ERROR" : (problem.isInfo() ? "INFO" : "WARNING"));
/* 1122 */       parameters.put("line", Integer.valueOf(problem.getSourceLineNumber()));
/* 1123 */       parameters.put("charStart", Integer.valueOf(sourceStart));
/* 1124 */       parameters.put("charEnd", Integer.valueOf(sourceEnd));
/* 1125 */       printTag("extra_problem", parameters, true, false);
/* 1126 */       parameters.put("value", problem.getMessage());
/* 1127 */       printTag("message", parameters, true, true);
/* 1128 */       extractContext(problem, null);
/* 1129 */       endTag("extra_problem");
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private void logXmlProblem(CategorizedProblem problem, char[] unitSource) {
/* 1138 */       int sourceStart = problem.getSourceStart();
/* 1139 */       int sourceEnd = problem.getSourceEnd();
/* 1140 */       int id = problem.getID();
/* 1141 */       HashMap<String, Object> parameters = new HashMap<>();
/* 1142 */       parameters.put("id", getFieldName(id));
/* 1143 */       parameters.put("problemID", Integer.valueOf(id));
/* 1144 */       boolean isError = problem.isError();
/* 1145 */       int severity = isError ? 1 : 0;
/* 1146 */       parameters.put("severity", isError ? "ERROR" : (problem.isInfo() ? "INFO" : "WARNING"));
/* 1147 */       parameters.put("line", Integer.valueOf(problem.getSourceLineNumber()));
/* 1148 */       parameters.put("charStart", Integer.valueOf(sourceStart));
/* 1149 */       parameters.put("charEnd", Integer.valueOf(sourceEnd));
/* 1150 */       String problemOptionKey = getProblemOptionKey(id);
/* 1151 */       if (problemOptionKey != null) {
/* 1152 */         parameters.put("optionKey", problemOptionKey);
/*      */       }
/* 1154 */       int categoryID = ProblemReporter.getProblemCategory(severity, id);
/* 1155 */       parameters.put("categoryID", Integer.valueOf(categoryID));
/* 1156 */       printTag("problem", parameters, true, false);
/* 1157 */       parameters.put("value", problem.getMessage());
/* 1158 */       printTag("message", parameters, true, true);
/* 1159 */       extractContext(problem, unitSource);
/* 1160 */       String[] arguments = problem.getArguments();
/* 1161 */       int length = arguments.length;
/* 1162 */       if (length != 0) {
/* 1163 */         parameters = new HashMap<>();
/* 1164 */         printTag("arguments", parameters, true, false);
/* 1165 */         for (int i = 0; i < length; i++) {
/* 1166 */           parameters = new HashMap<>();
/* 1167 */           parameters.put("value", arguments[i]);
/* 1168 */           printTag("argument", parameters, true, true);
/*      */         } 
/* 1170 */         endTag("arguments");
/*      */       } 
/* 1172 */       endTag("problem");
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private void logXmlTask(CategorizedProblem problem, char[] unitSource) {
/* 1181 */       HashMap<String, Object> parameters = new HashMap<>();
/* 1182 */       parameters.put("line", Integer.valueOf(problem.getSourceLineNumber()));
/* 1183 */       parameters.put("charStart", Integer.valueOf(problem.getSourceStart()));
/* 1184 */       parameters.put("charEnd", Integer.valueOf(problem.getSourceEnd()));
/* 1185 */       String problemOptionKey = getProblemOptionKey(problem.getID());
/* 1186 */       if (problemOptionKey != null) {
/* 1187 */         parameters.put("optionKey", problemOptionKey);
/*      */       }
/* 1189 */       printTag("task", parameters, true, false);
/* 1190 */       parameters.put("value", problem.getMessage());
/* 1191 */       printTag("message", parameters, true, true);
/* 1192 */       extractContext(problem, unitSource);
/* 1193 */       endTag("task");
/*      */     }
/*      */     
/*      */     private void printErr(String s) {
/* 1197 */       this.err.print(s);
/* 1198 */       if ((this.tagBits & 0x1) == 0 && this.log != null) {
/* 1199 */         this.log.print(s);
/*      */       }
/*      */     }
/*      */     
/*      */     private void printlnErr() {
/* 1204 */       this.err.println();
/* 1205 */       if ((this.tagBits & 0x1) == 0 && this.log != null) {
/* 1206 */         this.log.println();
/*      */       }
/*      */     }
/*      */     
/*      */     private void printlnErr(String s) {
/* 1211 */       this.err.println(s);
/* 1212 */       if ((this.tagBits & 0x1) == 0 && this.log != null) {
/* 1213 */         this.log.println(s);
/*      */       }
/*      */     }
/*      */     
/*      */     private void printlnOut(String s) {
/* 1218 */       this.out.println(s);
/* 1219 */       if ((this.tagBits & 0x1) == 0 && this.log != null) {
/* 1220 */         this.log.println(s);
/*      */       }
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void printNewLine() {
/* 1228 */       this.out.println();
/*      */     }
/*      */     
/*      */     private void printOut(char c) {
/* 1232 */       this.out.print(c);
/*      */     }
/*      */     
/*      */     public void printStats() {
/* 1236 */       boolean isTimed = ((this.main.timing & 0x1) != 0);
/* 1237 */       if ((this.tagBits & 0x1) != 0) {
/* 1238 */         printTag("stats", new HashMap<>(), true, false);
/*      */       }
/* 1240 */       if (isTimed) {
/* 1241 */         CompilerStats compilerStats = this.main.batchCompiler.stats;
/* 1242 */         compilerStats.startTime = this.main.startTime;
/* 1243 */         compilerStats.endTime = System.currentTimeMillis();
/* 1244 */         logTiming(compilerStats);
/*      */       } 
/* 1246 */       if (this.main.globalProblemsCount > 0) {
/* 1247 */         logProblemsSummary(this.main.globalProblemsCount, this.main.globalErrorsCount, this.main.globalWarningsCount, 
/* 1248 */             this.main.globalInfoCount, this.main.globalTasksCount);
/*      */       }
/* 1250 */       if (this.main.exportedClassFilesCounter != 0 && (
/* 1251 */         this.main.showProgress || isTimed || this.main.verbose)) {
/* 1252 */         logNumberOfClassFilesGenerated(this.main.exportedClassFilesCounter);
/*      */       }
/* 1254 */       if ((this.tagBits & 0x1) != 0) {
/* 1255 */         endTag("stats");
/*      */       }
/*      */     }
/*      */     
/*      */     private void printTag(String name, HashMap<String, Object> params, boolean insertNewLine, boolean closeTag) {
/* 1260 */       if (this.log != null) {
/* 1261 */         ((GenericXMLWriter)this.log).printTag(name, params, true, insertNewLine, closeTag);
/*      */       }
/* 1263 */       if (params != null) params.clear(); 
/*      */     }
/*      */     
/*      */     public void setEmacs() {
/* 1267 */       this.tagBits |= 0x2;
/*      */     }
/*      */     public void setLog(String logFileName) {
/* 1270 */       Date date = new Date();
/* 1271 */       DateFormat dateFormat = DateFormat.getDateTimeInstance(3, 1, Locale.getDefault());
/*      */       try {
/* 1273 */         int index = logFileName.lastIndexOf('.');
/* 1274 */         if (index != -1) {
/* 1275 */           if (logFileName.substring(index).toLowerCase().equals(".xml")) {
/* 1276 */             this.log = (PrintWriter)new GenericXMLWriter(new OutputStreamWriter(new FileOutputStream(logFileName, false), "UTF-8"), Util.LINE_SEPARATOR, true);
/* 1277 */             this.tagBits |= 0x1;
/*      */             
/* 1279 */             this.log.println("<!-- " + dateFormat.format(date) + " -->");
/* 1280 */             this.log.println("<!DOCTYPE compiler PUBLIC \"-//Eclipse.org//DTD Eclipse JDT 3.2.006 Compiler//EN\" \"https://www.eclipse.org/jdt/core/compiler_32_006.dtd\">");
/* 1281 */             HashMap<String, Object> parameters = new HashMap<>();
/* 1282 */             parameters.put("name", this.main.bind("compiler.name"));
/* 1283 */             parameters.put("version", this.main.bind("compiler.version"));
/* 1284 */             parameters.put("copyright", this.main.bind("compiler.copyright"));
/* 1285 */             printTag("compiler", parameters, true, false);
/*      */           } else {
/* 1287 */             this.log = new PrintWriter(new FileOutputStream(logFileName, false));
/* 1288 */             this.log.println("# " + dateFormat.format(date));
/*      */           } 
/*      */         } else {
/* 1291 */           this.log = new PrintWriter(new FileOutputStream(logFileName, false));
/* 1292 */           this.log.println("# " + dateFormat.format(date));
/*      */         } 
/* 1294 */       } catch (FileNotFoundException e) {
/* 1295 */         throw new IllegalArgumentException(this.main.bind("configure.cannotOpenLog", logFileName), e);
/* 1296 */       } catch (UnsupportedEncodingException e) {
/* 1297 */         throw new IllegalArgumentException(this.main.bind("configure.cannotOpenLogInvalidEncoding", logFileName), e);
/*      */       } 
/*      */     }
/*      */     private void startLoggingExtraProblems(int count) {
/* 1301 */       HashMap<String, Object> parameters = new HashMap<>();
/* 1302 */       parameters.put("problems", Integer.valueOf(count));
/* 1303 */       printTag("extra_problems", parameters, true, false);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private void startLoggingProblems(int errors, int warnings, int infos) {
/* 1311 */       HashMap<String, Object> parameters = new HashMap<>();
/* 1312 */       parameters.put("problems", Integer.valueOf(errors + warnings));
/* 1313 */       parameters.put("errors", Integer.valueOf(errors));
/* 1314 */       parameters.put("warnings", Integer.valueOf(warnings));
/* 1315 */       parameters.put("infos", Integer.valueOf(infos));
/* 1316 */       printTag("problems", parameters, true, false);
/*      */     }
/*      */     
/*      */     public void startLoggingSource(CompilationResult compilationResult) {
/* 1320 */       if ((this.tagBits & 0x1) != 0) {
/* 1321 */         ICompilationUnit compilationUnit = compilationResult.compilationUnit;
/* 1322 */         HashMap<String, Object> parameters = new HashMap<>();
/* 1323 */         if (compilationUnit != null) {
/* 1324 */           char[] fileName = compilationUnit.getFileName();
/* 1325 */           File f = new File(new String(fileName));
/* 1326 */           if (fileName != null) {
/* 1327 */             parameters.put("path", f.getAbsolutePath());
/*      */           }
/* 1329 */           char[][] packageName = compilationResult.packageName;
/* 1330 */           if (packageName != null) {
/* 1331 */             parameters.put(
/* 1332 */                 "package", 
/* 1333 */                 new String(CharOperation.concatWith(packageName, File.separatorChar)));
/*      */           }
/* 1335 */           CompilationUnit unit = (CompilationUnit)compilationUnit;
/* 1336 */           String destinationPath = unit.destinationPath;
/* 1337 */           if (destinationPath == null) {
/* 1338 */             destinationPath = this.main.destinationPath;
/*      */           }
/* 1340 */           if (destinationPath != null && destinationPath != "none") {
/* 1341 */             if (File.separatorChar == '/') {
/* 1342 */               parameters.put("output", destinationPath);
/*      */             } else {
/* 1344 */               parameters.put("output", destinationPath.replace('/', File.separatorChar));
/*      */             } 
/*      */           }
/*      */         } 
/* 1348 */         printTag("source", parameters, true, false);
/*      */       } 
/*      */     }
/*      */     
/*      */     public void startLoggingSources() {
/* 1353 */       if ((this.tagBits & 0x1) != 0) {
/* 1354 */         printTag("sources", new HashMap<>(), true, false);
/*      */       }
/*      */     }
/*      */     
/*      */     public void startLoggingTasks(int tasks) {
/* 1359 */       if ((this.tagBits & 0x1) != 0) {
/* 1360 */         HashMap<String, Object> parameters = new HashMap<>();
/* 1361 */         parameters.put("tasks", Integer.valueOf(tasks));
/* 1362 */         printTag("tasks", parameters, true, false);
/*      */       } 
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public static class ResourceBundleFactory
/*      */   {
/* 1371 */     private static HashMap<Locale, ResourceBundle> Cache = new HashMap<>();
/*      */     public static synchronized ResourceBundle getBundle(Locale locale) {
/* 1373 */       ResourceBundle bundle = Cache.get(locale);
/* 1374 */       if (bundle == null) {
/* 1375 */         bundle = ResourceBundle.getBundle("org.eclipse.jdt.internal.compiler.batch.messages", locale);
/* 1376 */         Cache.put(locale, bundle);
/*      */       } 
/* 1378 */       return bundle;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1402 */   private List<String> addonExports = Collections.EMPTY_LIST;
/* 1403 */   private List<String> addonReads = Collections.EMPTY_LIST;
/* 1404 */   public Set<String> rootModules = Collections.EMPTY_SET;
/*      */   
/*      */   public Set<String> limitedModules;
/*      */   
/*      */   public Locale compilerLocale;
/*      */   
/*      */   public CompilerOptions compilerOptions;
/*      */   
/*      */   public CompilationProgress progress;
/*      */   
/*      */   public String destinationPath;
/*      */   
/*      */   public String[] destinationPaths;
/*      */   
/*      */   protected boolean enablePreview;
/*      */   
/*      */   protected String releaseVersion;
/*      */   
/*      */   private boolean didSpecifySource;
/*      */   
/*      */   private boolean didSpecifyTarget;
/*      */   
/*      */   public String[] encodings;
/*      */   
/*      */   public int exportedClassFilesCounter;
/*      */   
/*      */   public String[] filenames;
/*      */   
/*      */   public String[] modNames;
/*      */   
/*      */   public String[] classNames;
/*      */   public int globalErrorsCount;
/*      */   public int globalProblemsCount;
/*      */   public int globalTasksCount;
/*      */   public int globalWarningsCount;
/*      */   public int globalInfoCount;
/*      */   private File javaHomeCache;
/*      */   private boolean javaHomeChecked = false;
/*      */   private boolean primaryNullAnnotationsSeen = false;
/*      */   public long lineCount0;
/*      */   public String log;
/*      */   public Logger logger;
/*      */   public int maxProblems;
/*      */   public Map<String, String> options;
/*      */   protected long complianceLevel;
/*      */   public char[][] ignoreOptionalProblemsFromFolders;
/*      */   protected PrintWriter out;
/*      */   public boolean proceed = true;
/*      */   public boolean proceedOnError = false;
/*      */   public boolean failOnWarning = false;
/*      */   public boolean produceRefInfo = false;
/*      */   public int currentRepetition;
/*      */   public int maxRepetition;
/*      */   public boolean showProgress = false;
/*      */   public long startTime;
/*      */   public ArrayList<String> pendingErrors;
/*      */   public boolean systemExitWhenFinished = true;
/*      */   public static final int TIMING_DISABLED = 0;
/*      */   public static final int TIMING_ENABLED = 1;
/*      */   public static final int TIMING_DETAILED = 2;
/* 1464 */   public int timing = 0;
/*      */ 
/*      */   
/*      */   public CompilerStats[] compilerStats;
/*      */   
/*      */   public boolean verbose = false;
/*      */   
/*      */   private String[] expandedCommandLine;
/*      */   
/*      */   private PrintWriter err;
/*      */   
/*      */   protected ArrayList<CategorizedProblem> extraProblems;
/*      */   
/*      */   public static final String bundleName = "org.eclipse.jdt.internal.compiler.batch.messages";
/*      */   
/*      */   public static final int DEFAULT_SIZE_CLASSPATH = 4;
/*      */   
/*      */   public static final String NONE = "none";
/*      */ 
/*      */   
/*      */   public static boolean compile(String commandLine) {
/* 1485 */     return (new Main(new PrintWriter(System.out), new PrintWriter(System.err), false, null, null)).compile(tokenize(commandLine));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean compile(String commandLine, PrintWriter outWriter, PrintWriter errWriter) {
/* 1493 */     return (new Main(outWriter, errWriter, false, null, null)).compile(tokenize(commandLine));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean compile(String[] commandLineArguments, PrintWriter outWriter, PrintWriter errWriter, CompilationProgress progress) {
/* 1500 */     return (new Main(outWriter, errWriter, false, null, progress)).compile(commandLineArguments);
/*      */   }
/*      */   public static File[][] getLibrariesFiles(File[] files) {
/* 1503 */     FilenameFilter filter = new FilenameFilter()
/*      */       {
/*      */         public boolean accept(File dir, String name) {
/* 1506 */           return (Util.archiveFormat(name) > -1);
/*      */         }
/*      */       };
/* 1509 */     int filesLength = files.length;
/* 1510 */     File[][] result = new File[filesLength][];
/* 1511 */     for (int i = 0; i < filesLength; i++) {
/* 1512 */       File currentFile = files[i];
/* 1513 */       if (currentFile.exists() && currentFile.isDirectory()) {
/* 1514 */         result[i] = currentFile.listFiles(filter);
/*      */       }
/*      */     } 
/* 1517 */     return result;
/*      */   }
/*      */   
/*      */   public static void main(String[] argv) {
/* 1521 */     (new Main(new PrintWriter(System.out), new PrintWriter(System.err), true, null, null)).compile(argv);
/*      */   }
/*      */ 
/*      */   
/*      */   public static String[] tokenize(String commandLine) {
/* 1526 */     int count = 0;
/* 1527 */     String[] arguments = new String[10];
/* 1528 */     StringTokenizer tokenizer = new StringTokenizer(commandLine, " \"", true);
/* 1529 */     String token = Util.EMPTY_STRING;
/* 1530 */     boolean insideQuotes = false;
/* 1531 */     boolean startNewToken = true;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1538 */     while (tokenizer.hasMoreTokens()) {
/* 1539 */       token = tokenizer.nextToken();
/*      */       
/* 1541 */       if (token.equals(" ")) {
/* 1542 */         if (insideQuotes) {
/* 1543 */           arguments[count - 1] = String.valueOf(arguments[count - 1]) + token;
/* 1544 */           startNewToken = false; continue;
/*      */         } 
/* 1546 */         startNewToken = true; continue;
/*      */       } 
/* 1548 */       if (token.equals("\"")) {
/* 1549 */         if (!insideQuotes && startNewToken) {
/* 1550 */           if (count == arguments.length)
/* 1551 */             System.arraycopy(arguments, 0, arguments = new String[count * 2], 0, count); 
/* 1552 */           arguments[count++] = Util.EMPTY_STRING;
/*      */         } 
/* 1554 */         insideQuotes = !insideQuotes;
/* 1555 */         startNewToken = false; continue;
/*      */       } 
/* 1557 */       if (insideQuotes) {
/* 1558 */         arguments[count - 1] = String.valueOf(arguments[count - 1]) + token;
/*      */       }
/* 1560 */       else if (token.length() > 0 && !startNewToken) {
/* 1561 */         arguments[count - 1] = String.valueOf(arguments[count - 1]) + token;
/*      */       } else {
/* 1563 */         if (count == arguments.length)
/* 1564 */           System.arraycopy(arguments, 0, arguments = new String[count * 2], 0, count); 
/* 1565 */         String trimmedToken = token.trim();
/* 1566 */         if (trimmedToken.length() != 0) {
/* 1567 */           arguments[count++] = trimmedToken;
/*      */         }
/*      */       } 
/*      */       
/* 1571 */       startNewToken = false;
/*      */     } 
/*      */     
/* 1574 */     System.arraycopy(arguments, 0, arguments = new String[count], 0, count);
/* 1575 */     return arguments;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Main(PrintWriter outWriter, PrintWriter errWriter, boolean systemExitWhenFinished) {
/* 1583 */     this(outWriter, errWriter, systemExitWhenFinished, null, null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Main(PrintWriter outWriter, PrintWriter errWriter, boolean systemExitWhenFinished, Map<String, String> customDefaultOptions) {
/* 1591 */     this(outWriter, errWriter, systemExitWhenFinished, customDefaultOptions, null);
/*      */   }
/*      */   
/*      */   public Main(PrintWriter outWriter, PrintWriter errWriter, boolean systemExitWhenFinished, Map<String, String> customDefaultOptions, CompilationProgress compilationProgress) {
/* 1595 */     initialize(outWriter, errWriter, systemExitWhenFinished, customDefaultOptions, compilationProgress);
/* 1596 */     relocalize();
/*      */   }
/*      */   
/*      */   public void addExtraProblems(CategorizedProblem problem) {
/* 1600 */     if (this.extraProblems == null) {
/* 1601 */       this.extraProblems = new ArrayList<>();
/*      */     }
/* 1603 */     this.extraProblems.add(problem);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void addNewEntry(ArrayList<FileSystem.Classpath> paths, String currentClasspathName, ArrayList<String> currentRuleSpecs, String customEncoding, String destPath, boolean isSourceOnly, boolean rejectDestinationPathOnJars) {
/* 1610 */     int rulesSpecsSize = currentRuleSpecs.size();
/* 1611 */     AccessRuleSet accessRuleSet = null;
/* 1612 */     if (rulesSpecsSize != 0) {
/* 1613 */       AccessRule[] accessRules = new AccessRule[currentRuleSpecs.size()];
/* 1614 */       boolean rulesOK = true;
/* 1615 */       Iterator<String> i = currentRuleSpecs.iterator();
/* 1616 */       int j = 0;
/* 1617 */       while (i.hasNext()) {
/* 1618 */         String ruleSpec = i.next();
/* 1619 */         char key = ruleSpec.charAt(0);
/* 1620 */         String pattern = ruleSpec.substring(1);
/* 1621 */         if (pattern.length() > 0) {
/* 1622 */           switch (key) {
/*      */             case '+':
/* 1624 */               accessRules[j++] = new AccessRule(pattern
/* 1625 */                   .toCharArray(), 0);
/*      */               continue;
/*      */             case '~':
/* 1628 */               accessRules[j++] = new AccessRule(pattern
/* 1629 */                   .toCharArray(), 
/* 1630 */                   16777496);
/*      */               continue;
/*      */             case '-':
/* 1633 */               accessRules[j++] = new AccessRule(pattern
/* 1634 */                   .toCharArray(), 
/* 1635 */                   16777523);
/*      */               continue;
/*      */             case '?':
/* 1638 */               accessRules[j++] = new AccessRule(pattern
/* 1639 */                   .toCharArray(), 
/* 1640 */                   16777523, true);
/*      */               continue;
/*      */           } 
/* 1643 */           rulesOK = false;
/*      */           continue;
/*      */         } 
/* 1646 */         rulesOK = false;
/*      */       } 
/*      */       
/* 1649 */       if (rulesOK) {
/* 1650 */         accessRuleSet = new AccessRuleSet(accessRules, (byte)0, currentClasspathName);
/*      */       } else {
/* 1652 */         if (currentClasspathName.length() != 0)
/*      */         {
/* 1654 */           addPendingErrors(bind("configure.incorrectClasspath", currentClasspathName));
/*      */         }
/*      */         return;
/*      */       } 
/*      */     } 
/* 1659 */     if ("none".equals(destPath)) {
/* 1660 */       destPath = "none";
/*      */     }
/*      */     
/* 1663 */     if (rejectDestinationPathOnJars && destPath != null && 
/* 1664 */       Util.archiveFormat(currentClasspathName) > -1) {
/* 1665 */       throw new IllegalArgumentException(
/* 1666 */           bind("configure.unexpectedDestinationPathEntryFile", 
/* 1667 */             currentClasspathName));
/*      */     }
/* 1669 */     FileSystem.Classpath currentClasspath = FileSystem.getClasspath(
/* 1670 */         currentClasspathName, 
/* 1671 */         customEncoding, 
/* 1672 */         isSourceOnly, 
/* 1673 */         accessRuleSet, 
/* 1674 */         destPath, 
/* 1675 */         this.options, 
/* 1676 */         this.releaseVersion);
/* 1677 */     if (currentClasspath != null) {
/* 1678 */       paths.add(currentClasspath);
/* 1679 */     } else if (currentClasspathName.length() != 0) {
/*      */       
/* 1681 */       addPendingErrors(bind("configure.incorrectClasspath", currentClasspathName));
/*      */     } 
/*      */   }
/*      */   void addPendingErrors(String message) {
/* 1685 */     if (this.pendingErrors == null) {
/* 1686 */       this.pendingErrors = new ArrayList<>();
/*      */     }
/* 1688 */     this.pendingErrors.add(message);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public String bind(String id) {
/* 1694 */     return bind(id, (String[])null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String bind(String id, String binding) {
/* 1701 */     return bind(id, new String[] { binding });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String bind(String id, String binding1, String binding2) {
/* 1709 */     return bind(id, new String[] { binding1, binding2 });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String bind(String id, String[] arguments) {
/* 1717 */     if (id == null)
/* 1718 */       return "No message available"; 
/* 1719 */     String message = null;
/*      */     try {
/* 1721 */       message = this.bundle.getString(id);
/* 1722 */     } catch (MissingResourceException missingResourceException) {
/*      */ 
/*      */       
/* 1725 */       return "Missing message: " + id + " in: " + "org.eclipse.jdt.internal.compiler.batch.messages";
/*      */     } 
/* 1727 */     return MessageFormat.format(message, (Object[])arguments);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean checkVMVersion(long minimalSupportedVersion) {
/*      */     int majorVersion;
/* 1756 */     String classFileVersion = System.getProperty("java.class.version");
/* 1757 */     if (classFileVersion == null)
/*      */     {
/* 1759 */       return false;
/*      */     }
/* 1761 */     int index = classFileVersion.indexOf('.');
/* 1762 */     if (index == -1)
/*      */     {
/* 1764 */       return false;
/*      */     }
/*      */     
/*      */     try {
/* 1768 */       majorVersion = Integer.parseInt(classFileVersion.substring(0, index));
/* 1769 */     } catch (NumberFormatException numberFormatException) {
/*      */       
/* 1771 */       return false;
/*      */     } 
/* 1773 */     return (ClassFileConstants.getComplianceLevelForJavaVersion(majorVersion) >= minimalSupportedVersion);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean compile(String[] argv) {
/*      */     try {
/* 1781 */       configure(argv);
/* 1782 */       if (this.progress != null)
/* 1783 */         this.progress.begin((this.filenames == null) ? 0 : (this.filenames.length * this.maxRepetition)); 
/* 1784 */       if (this.proceed) {
/*      */ 
/*      */ 
/*      */         
/* 1788 */         if (this.showProgress) this.logger.compiling(); 
/* 1789 */         for (this.currentRepetition = 0; this.currentRepetition < this.maxRepetition; this.currentRepetition++) {
/* 1790 */           this.globalProblemsCount = 0;
/* 1791 */           this.globalErrorsCount = 0;
/* 1792 */           this.globalWarningsCount = 0;
/* 1793 */           this.globalInfoCount = 0;
/* 1794 */           this.globalTasksCount = 0;
/* 1795 */           this.exportedClassFilesCounter = 0;
/*      */           
/* 1797 */           if (this.maxRepetition > 1) {
/* 1798 */             this.logger.flush();
/* 1799 */             this.logger.logRepetition(this.currentRepetition, this.maxRepetition);
/*      */           } 
/*      */           
/* 1802 */           performCompilation();
/*      */         } 
/* 1804 */         if (this.compilerStats != null) {
/* 1805 */           this.logger.logAverage();
/*      */         }
/* 1807 */         if (this.showProgress) this.logger.printNewLine(); 
/*      */       } 
/* 1809 */       if (this.systemExitWhenFinished) {
/* 1810 */         this.logger.flush();
/* 1811 */         this.logger.close();
/* 1812 */         if (this.failOnWarning && this.globalWarningsCount > 0) {
/* 1813 */           System.exit(-1);
/*      */         }
/* 1815 */         System.exit((this.globalErrorsCount > 0) ? -1 : 0);
/*      */       } 
/* 1817 */     } catch (Exception e) {
/* 1818 */       this.logger.logException(e);
/* 1819 */       if (this.systemExitWhenFinished) {
/* 1820 */         this.logger.flush();
/* 1821 */         this.logger.close();
/* 1822 */         System.exit(-1);
/*      */       } 
/* 1824 */       return false;
/*      */     } finally {
/* 1826 */       this.logger.flush();
/* 1827 */       this.logger.close();
/* 1828 */       if (this.progress != null)
/* 1829 */         this.progress.done(); 
/*      */     } 
/* 1831 */     if (this.progress == null || !this.progress.isCanceled()) {
/* 1832 */       if (this.failOnWarning && this.globalWarningsCount > 0)
/* 1833 */         return false; 
/* 1834 */       if (this.globalErrorsCount == 0) {
/* 1835 */         return true;
/*      */       }
/*      */     } 
/* 1838 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void configure(String[] argv) {
/* 1846 */     if (argv == null || argv.length == 0) {
/* 1847 */       printUsage();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       return;
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1882 */     ArrayList<String> bootclasspaths = new ArrayList<>(4);
/* 1883 */     String sourcepathClasspathArg = null;
/* 1884 */     String modulepathArg = null;
/* 1885 */     String moduleSourcepathArg = null;
/* 1886 */     ArrayList<String> sourcepathClasspaths = new ArrayList<>(4);
/* 1887 */     ArrayList<String> classpaths = new ArrayList<>(4);
/* 1888 */     ArrayList<String> extdirsClasspaths = null;
/* 1889 */     ArrayList<String> endorsedDirClasspaths = null;
/* 1890 */     this.annotationPaths = null;
/* 1891 */     this.annotationsFromClasspath = false;
/*      */     
/* 1893 */     int index = -1;
/* 1894 */     int filesCount = 0;
/* 1895 */     int classCount = 0;
/* 1896 */     int argCount = argv.length;
/* 1897 */     int mode = 0;
/* 1898 */     this.maxRepetition = 0;
/* 1899 */     boolean printUsageRequired = false;
/* 1900 */     String usageSection = null;
/* 1901 */     boolean printVersionRequired = false;
/*      */     
/* 1903 */     boolean didSpecifyDeprecation = false;
/* 1904 */     boolean didSpecifyCompliance = false;
/* 1905 */     boolean didSpecifyDisabledAnnotationProcessing = false;
/*      */     
/* 1907 */     String customEncoding = null;
/* 1908 */     String customDestinationPath = null;
/* 1909 */     String currentSourceDirectory = null;
/* 1910 */     String currentArg = Util.EMPTY_STRING;
/*      */     
/* 1912 */     Set<String> specifiedEncodings = null;
/*      */ 
/*      */     
/* 1915 */     boolean needExpansion = false;
/* 1916 */     for (int i = 0; i < argCount; i++) {
/* 1917 */       if (argv[i].startsWith("@")) {
/* 1918 */         needExpansion = true;
/*      */         
/*      */         break;
/*      */       } 
/*      */     } 
/* 1923 */     String[] newCommandLineArgs = null;
/* 1924 */     if (needExpansion) {
/* 1925 */       newCommandLineArgs = new String[argCount];
/* 1926 */       index = 0;
/* 1927 */       for (int j = 0; j < argCount; j++) {
/* 1928 */         String[] newArgs = null;
/* 1929 */         String arg = argv[j].trim();
/* 1930 */         if (arg.startsWith("@")) {
/*      */           try {
/* 1932 */             LineNumberReader reader = new LineNumberReader(new StringReader(new String(Util.getFileCharContent(new File(arg.substring(1)), null))));
/* 1933 */             StringBuilder buffer = new StringBuilder();
/*      */             String line;
/* 1935 */             while ((line = reader.readLine()) != null) {
/* 1936 */               line = line.trim();
/* 1937 */               if (!line.startsWith("#")) {
/* 1938 */                 buffer.append(line).append(" ");
/*      */               }
/*      */             } 
/* 1941 */             newArgs = tokenize(buffer.toString());
/* 1942 */           } catch (IOException iOException) {
/* 1943 */             throw new IllegalArgumentException(
/* 1944 */                 bind("configure.invalidexpansionargumentname", arg));
/*      */           } 
/*      */         }
/* 1947 */         if (newArgs != null) {
/* 1948 */           int newCommandLineArgsLength = newCommandLineArgs.length;
/* 1949 */           int newArgsLength = newArgs.length;
/* 1950 */           System.arraycopy(newCommandLineArgs, 0, newCommandLineArgs = new String[newCommandLineArgsLength + newArgsLength - 1], 0, index);
/* 1951 */           System.arraycopy(newArgs, 0, newCommandLineArgs, index, newArgsLength);
/* 1952 */           index += newArgsLength;
/*      */         } else {
/* 1954 */           newCommandLineArgs[index++] = arg;
/*      */         } 
/*      */       } 
/* 1957 */       index = -1;
/*      */     } else {
/* 1959 */       newCommandLineArgs = argv;
/* 1960 */       for (int j = 0; j < argCount; j++) {
/* 1961 */         newCommandLineArgs[j] = newCommandLineArgs[j].trim();
/*      */       }
/*      */     } 
/* 1964 */     argCount = newCommandLineArgs.length;
/* 1965 */     this.expandedCommandLine = newCommandLineArgs;
/* 1966 */     while (++index < argCount) {
/*      */       long releaseToJDKLevel; String versionAsString, version, modulepaths[], moduleSourcepaths[]; StringTokenizer tokenizer; String[] sourcePaths; StringTokenizer tokens;
/* 1968 */       if (customEncoding != null) {
/* 1969 */         throw new IllegalArgumentException(
/* 1970 */             bind("configure.unexpectedCustomEncoding", currentArg, customEncoding));
/*      */       }
/*      */       
/* 1973 */       currentArg = newCommandLineArgs[index];
/*      */       
/* 1975 */       switch (mode) {
/*      */         case 0:
/* 1977 */           if (currentArg.startsWith("-nowarn")) {
/* 1978 */             int foldersStart, foldersEnd; String folders; switch (currentArg.length()) {
/*      */               case 7:
/* 1980 */                 disableAll(0);
/*      */                 break;
/*      */               case 8:
/* 1983 */                 throw new IllegalArgumentException(bind(
/* 1984 */                       "configure.invalidNowarnOption", currentArg));
/*      */               default:
/* 1986 */                 foldersStart = currentArg.indexOf('[') + 1;
/* 1987 */                 foldersEnd = currentArg.lastIndexOf(']');
/* 1988 */                 if (foldersStart <= 8 || foldersEnd == -1 || foldersStart > foldersEnd || 
/* 1989 */                   foldersEnd < currentArg.length() - 1) {
/* 1990 */                   throw new IllegalArgumentException(bind(
/* 1991 */                         "configure.invalidNowarnOption", currentArg));
/*      */                 }
/* 1993 */                 folders = currentArg.substring(foldersStart, foldersEnd);
/* 1994 */                 if (folders.length() > 0) {
/* 1995 */                   char[][] currentFolders = decodeIgnoreOptionalProblemsFromFolders(folders);
/* 1996 */                   if (this.ignoreOptionalProblemsFromFolders != null) {
/* 1997 */                     int length = this.ignoreOptionalProblemsFromFolders.length + currentFolders.length;
/* 1998 */                     char[][] tempFolders = new char[length][];
/* 1999 */                     System.arraycopy(this.ignoreOptionalProblemsFromFolders, 0, tempFolders, 0, this.ignoreOptionalProblemsFromFolders.length);
/* 2000 */                     System.arraycopy(currentFolders, 0, tempFolders, this.ignoreOptionalProblemsFromFolders.length, currentFolders.length);
/* 2001 */                     this.ignoreOptionalProblemsFromFolders = tempFolders; break;
/*      */                   } 
/* 2003 */                   this.ignoreOptionalProblemsFromFolders = currentFolders;
/*      */                   break;
/*      */                 } 
/* 2006 */                 throw new IllegalArgumentException(bind(
/* 2007 */                       "configure.invalidNowarnOption", currentArg));
/*      */             } 
/*      */             
/* 2010 */             mode = 0;
/*      */             continue;
/*      */           } 
/* 2013 */           if (currentArg.startsWith("[")) {
/* 2014 */             throw new IllegalArgumentException(
/* 2015 */                 bind("configure.unexpectedBracket", 
/* 2016 */                   currentArg));
/*      */           }
/*      */           
/* 2019 */           if (currentArg.endsWith("]")) {
/*      */             
/* 2021 */             int encodingStart = currentArg.indexOf('[') + 1;
/* 2022 */             if (encodingStart <= 1) {
/* 2023 */               throw new IllegalArgumentException(
/* 2024 */                   bind("configure.unexpectedBracket", currentArg));
/*      */             }
/* 2026 */             int encodingEnd = currentArg.length() - 1;
/* 2027 */             if (encodingStart >= 1) {
/* 2028 */               if (encodingStart < encodingEnd) {
/* 2029 */                 customEncoding = currentArg.substring(encodingStart, encodingEnd);
/*      */                 try {
/*      */                 
/* 2032 */                 } catch (UnsupportedEncodingException e) {
/* 2033 */                   throw new IllegalArgumentException(
/* 2034 */                       bind("configure.unsupportedEncoding", customEncoding), e);
/*      */                 } 
/*      */               } 
/* 2037 */               currentArg = currentArg.substring(0, encodingStart - 1);
/*      */             } 
/*      */           } 
/*      */           
/* 2041 */           if (currentArg.endsWith(".java")) {
/* 2042 */             if (this.filenames == null) {
/* 2043 */               this.filenames = new String[argCount - index];
/* 2044 */               this.encodings = new String[argCount - index];
/* 2045 */               this.destinationPaths = new String[argCount - index];
/* 2046 */             } else if (filesCount == this.filenames.length) {
/* 2047 */               int length = this.filenames.length;
/* 2048 */               System.arraycopy(
/* 2049 */                   this.filenames, 
/* 2050 */                   0, 
/* 2051 */                   this.filenames = new String[length + argCount - index], 
/* 2052 */                   0, 
/* 2053 */                   length);
/* 2054 */               System.arraycopy(
/* 2055 */                   this.encodings, 
/* 2056 */                   0, 
/* 2057 */                   this.encodings = new String[length + argCount - index], 
/* 2058 */                   0, 
/* 2059 */                   length);
/* 2060 */               System.arraycopy(
/* 2061 */                   this.destinationPaths, 
/* 2062 */                   0, 
/* 2063 */                   this.destinationPaths = new String[length + argCount - index], 
/* 2064 */                   0, 
/* 2065 */                   length);
/*      */             } 
/* 2067 */             this.filenames[filesCount] = currentArg;
/* 2068 */             this.encodings[filesCount++] = customEncoding;
/*      */             
/* 2070 */             customEncoding = null;
/* 2071 */             mode = 0;
/*      */             continue;
/*      */           } 
/* 2074 */           if (currentArg.equals("-log")) {
/* 2075 */             if (this.log != null)
/* 2076 */               throw new IllegalArgumentException(
/* 2077 */                   bind("configure.duplicateLog", currentArg)); 
/* 2078 */             mode = 5;
/*      */             continue;
/*      */           } 
/* 2081 */           if (currentArg.equals("-repeat")) {
/* 2082 */             if (this.maxRepetition > 0)
/* 2083 */               throw new IllegalArgumentException(
/* 2084 */                   bind("configure.duplicateRepeat", currentArg)); 
/* 2085 */             mode = 6;
/*      */             continue;
/*      */           } 
/* 2088 */           if (currentArg.equals("-maxProblems")) {
/* 2089 */             if (this.maxProblems > 0)
/* 2090 */               throw new IllegalArgumentException(
/* 2091 */                   bind("configure.duplicateMaxProblems", currentArg)); 
/* 2092 */             mode = 11;
/*      */             continue;
/*      */           } 
/* 2095 */           if (currentArg.equals("--release")) {
/* 2096 */             mode = 30;
/*      */             continue;
/*      */           } 
/* 2099 */           if (currentArg.equals("-source")) {
/* 2100 */             mode = 7;
/*      */             continue;
/*      */           } 
/* 2103 */           if (currentArg.equals("-encoding")) {
/* 2104 */             mode = 8;
/*      */             continue;
/*      */           } 
/* 2107 */           if (currentArg.startsWith("-")) {
/* 2108 */             String str = optionStringToVersion(currentArg.substring(1));
/* 2109 */             if (str != null) {
/* 2110 */               if (didSpecifyCompliance) {
/* 2111 */                 throw new IllegalArgumentException(
/* 2112 */                     bind("configure.duplicateCompliance", currentArg));
/*      */               }
/* 2114 */               didSpecifyCompliance = true;
/* 2115 */               this.options.put("org.eclipse.jdt.core.compiler.compliance", str);
/* 2116 */               mode = 0;
/*      */               continue;
/*      */             } 
/*      */           } 
/* 2120 */           if (currentArg.equals("-d")) {
/* 2121 */             if (this.destinationPath != null) {
/* 2122 */               StringBuilder errorMessage = new StringBuilder();
/* 2123 */               errorMessage.append(currentArg);
/* 2124 */               if (index + 1 < argCount) {
/* 2125 */                 errorMessage.append(' ');
/* 2126 */                 errorMessage.append(newCommandLineArgs[index + 1]);
/*      */               } 
/* 2128 */               throw new IllegalArgumentException(
/* 2129 */                   bind("configure.duplicateOutputPath", errorMessage.toString()));
/*      */             } 
/* 2131 */             mode = 3;
/*      */             continue;
/*      */           } 
/* 2134 */           if (currentArg.equals("-classpath") || 
/* 2135 */             currentArg.equals("-cp")) {
/* 2136 */             mode = 1;
/*      */             continue;
/*      */           } 
/* 2139 */           if (currentArg.equals("-bootclasspath")) {
/* 2140 */             if (bootclasspaths.size() > 0) {
/* 2141 */               StringBuilder errorMessage = new StringBuilder();
/* 2142 */               errorMessage.append(currentArg);
/* 2143 */               if (index + 1 < argCount) {
/* 2144 */                 errorMessage.append(' ');
/* 2145 */                 errorMessage.append(newCommandLineArgs[index + 1]);
/*      */               } 
/* 2147 */               throw new IllegalArgumentException(
/* 2148 */                   bind("configure.duplicateBootClasspath", errorMessage.toString()));
/*      */             } 
/* 2150 */             mode = 9;
/*      */             continue;
/*      */           } 
/* 2153 */           if (currentArg.equals("--enable-preview")) {
/* 2154 */             this.enablePreview = true;
/* 2155 */             mode = 0;
/*      */             continue;
/*      */           } 
/* 2158 */           if (currentArg.equals("--system")) {
/* 2159 */             mode = 27;
/*      */             continue;
/*      */           } 
/* 2162 */           if (currentArg.equals("--module-path") || currentArg.equals("-p")) {
/* 2163 */             mode = 23;
/*      */             continue;
/*      */           } 
/* 2166 */           if (currentArg.equals("--module-source-path")) {
/* 2167 */             if (sourcepathClasspathArg != null) {
/* 2168 */               throw new IllegalArgumentException(bind("configure.OneOfModuleOrSourcePath"));
/*      */             }
/* 2170 */             mode = 24;
/*      */             continue;
/*      */           } 
/* 2173 */           if (currentArg.equals("--add-exports")) {
/* 2174 */             mode = 25;
/*      */             continue;
/*      */           } 
/* 2177 */           if (currentArg.equals("--add-reads")) {
/* 2178 */             mode = 26;
/*      */             continue;
/*      */           } 
/* 2181 */           if (currentArg.equals("--add-modules")) {
/* 2182 */             mode = 29;
/*      */             continue;
/*      */           } 
/* 2185 */           if (currentArg.equals("--limit-modules")) {
/* 2186 */             mode = 31;
/*      */             continue;
/*      */           } 
/* 2189 */           if (currentArg.equals("--module-version")) {
/* 2190 */             mode = 32;
/*      */             continue;
/*      */           } 
/* 2193 */           if (currentArg.equals("-sourcepath")) {
/* 2194 */             if (sourcepathClasspathArg != null) {
/* 2195 */               StringBuilder errorMessage = new StringBuilder();
/* 2196 */               errorMessage.append(currentArg);
/* 2197 */               if (index + 1 < argCount) {
/* 2198 */                 errorMessage.append(' ');
/* 2199 */                 errorMessage.append(newCommandLineArgs[index + 1]);
/*      */               } 
/* 2201 */               throw new IllegalArgumentException(
/* 2202 */                   bind("configure.duplicateSourcepath", errorMessage.toString()));
/*      */             } 
/* 2204 */             if (moduleSourcepathArg != null) {
/* 2205 */               throw new IllegalArgumentException(bind("configure.OneOfModuleOrSourcePath"));
/*      */             }
/* 2207 */             mode = 13;
/*      */             continue;
/*      */           } 
/* 2210 */           if (currentArg.equals("-extdirs")) {
/* 2211 */             if (extdirsClasspaths != null) {
/* 2212 */               StringBuilder errorMessage = new StringBuilder();
/* 2213 */               errorMessage.append(currentArg);
/* 2214 */               if (index + 1 < argCount) {
/* 2215 */                 errorMessage.append(' ');
/* 2216 */                 errorMessage.append(newCommandLineArgs[index + 1]);
/*      */               } 
/* 2218 */               throw new IllegalArgumentException(
/* 2219 */                   bind("configure.duplicateExtDirs", errorMessage.toString()));
/*      */             } 
/* 2221 */             mode = 12;
/*      */             continue;
/*      */           } 
/* 2224 */           if (currentArg.equals("-endorseddirs")) {
/* 2225 */             if (endorsedDirClasspaths != null) {
/* 2226 */               StringBuilder errorMessage = new StringBuilder();
/* 2227 */               errorMessage.append(currentArg);
/* 2228 */               if (index + 1 < argCount) {
/* 2229 */                 errorMessage.append(' ');
/* 2230 */                 errorMessage.append(newCommandLineArgs[index + 1]);
/*      */               } 
/* 2232 */               throw new IllegalArgumentException(
/* 2233 */                   bind("configure.duplicateEndorsedDirs", errorMessage.toString()));
/*      */             } 
/* 2235 */             mode = 15;
/*      */             continue;
/*      */           } 
/* 2238 */           if (currentArg.equals("-progress")) {
/* 2239 */             mode = 0;
/* 2240 */             this.showProgress = true;
/*      */             continue;
/*      */           } 
/* 2243 */           if (currentArg.startsWith("-proceedOnError")) {
/* 2244 */             mode = 0;
/* 2245 */             int length = currentArg.length();
/* 2246 */             if (length > 15) {
/* 2247 */               if (currentArg.equals("-proceedOnError:Fatal")) {
/* 2248 */                 this.options.put("org.eclipse.jdt.core.compiler.problem.fatalOptionalError", "enabled");
/*      */               } else {
/* 2250 */                 throw new IllegalArgumentException(
/* 2251 */                     bind("configure.invalidWarningConfiguration", currentArg));
/*      */               } 
/*      */             } else {
/* 2254 */               this.options.put("org.eclipse.jdt.core.compiler.problem.fatalOptionalError", "disabled");
/*      */             } 
/* 2256 */             this.proceedOnError = true;
/*      */             continue;
/*      */           } 
/* 2259 */           if (currentArg.equals("-failOnWarning")) {
/* 2260 */             mode = 0;
/* 2261 */             this.failOnWarning = true;
/*      */             continue;
/*      */           } 
/* 2264 */           if (currentArg.equals("-time")) {
/* 2265 */             mode = 0;
/* 2266 */             this.timing = 1;
/*      */             continue;
/*      */           } 
/* 2269 */           if (currentArg.equals("-time:detail")) {
/* 2270 */             mode = 0;
/* 2271 */             this.timing = 3;
/*      */             continue;
/*      */           } 
/* 2274 */           if (currentArg.equals("-version") || 
/* 2275 */             currentArg.equals("-v")) {
/* 2276 */             this.logger.logVersion(true);
/* 2277 */             this.proceed = false;
/*      */             return;
/*      */           } 
/* 2280 */           if (currentArg.equals("-showversion")) {
/* 2281 */             printVersionRequired = true;
/* 2282 */             mode = 0;
/*      */             continue;
/*      */           } 
/* 2285 */           if ("-deprecation".equals(currentArg)) {
/* 2286 */             didSpecifyDeprecation = true;
/* 2287 */             this.options.put("org.eclipse.jdt.core.compiler.problem.deprecation", "warning");
/* 2288 */             mode = 0;
/*      */             continue;
/*      */           } 
/* 2291 */           if (currentArg.equals("-help") || currentArg.equals("-?")) {
/* 2292 */             printUsageRequired = true;
/* 2293 */             mode = 0;
/*      */             continue;
/*      */           } 
/* 2296 */           if (currentArg.equals("-help:warn") || 
/* 2297 */             currentArg.equals("-?:warn")) {
/* 2298 */             printUsageRequired = true;
/* 2299 */             usageSection = "misc.usage.warn";
/*      */             continue;
/*      */           } 
/* 2302 */           if (currentArg.equals("-noExit")) {
/* 2303 */             this.systemExitWhenFinished = false;
/* 2304 */             mode = 0;
/*      */             continue;
/*      */           } 
/* 2307 */           if (currentArg.equals("-verbose")) {
/* 2308 */             this.verbose = true;
/* 2309 */             mode = 0;
/*      */             continue;
/*      */           } 
/* 2312 */           if (currentArg.equals("-referenceInfo")) {
/* 2313 */             this.produceRefInfo = true;
/* 2314 */             mode = 0;
/*      */             continue;
/*      */           } 
/* 2317 */           if (currentArg.equals("-inlineJSR")) {
/* 2318 */             mode = 0;
/* 2319 */             this.options.put(
/* 2320 */                 "org.eclipse.jdt.core.compiler.codegen.inlineJsrBytecode", 
/* 2321 */                 "enabled");
/*      */             continue;
/*      */           } 
/* 2324 */           if (currentArg.equals("-parameters")) {
/* 2325 */             mode = 0;
/* 2326 */             this.options.put(
/* 2327 */                 "org.eclipse.jdt.core.compiler.codegen.methodParameters", 
/* 2328 */                 "generate");
/*      */             continue;
/*      */           } 
/* 2331 */           if (currentArg.equals("-genericsignature")) {
/* 2332 */             mode = 0;
/* 2333 */             this.options.put(
/* 2334 */                 "org.eclipse.jdt.core.compiler.codegen.lambda.genericSignature", 
/* 2335 */                 "generate");
/*      */             continue;
/*      */           } 
/* 2338 */           if (currentArg.startsWith("-g")) {
/* 2339 */             mode = 0;
/* 2340 */             String debugOption = currentArg;
/* 2341 */             int length = currentArg.length();
/* 2342 */             if (length == 2) {
/* 2343 */               this.options.put(
/* 2344 */                   "org.eclipse.jdt.core.compiler.debug.localVariable", 
/* 2345 */                   "generate");
/* 2346 */               this.options.put(
/* 2347 */                   "org.eclipse.jdt.core.compiler.debug.lineNumber", 
/* 2348 */                   "generate");
/* 2349 */               this.options.put(
/* 2350 */                   "org.eclipse.jdt.core.compiler.debug.sourceFile", 
/* 2351 */                   "generate");
/*      */               continue;
/*      */             } 
/* 2354 */             if (length > 3) {
/* 2355 */               this.options.put(
/* 2356 */                   "org.eclipse.jdt.core.compiler.debug.localVariable", 
/* 2357 */                   "do not generate");
/* 2358 */               this.options.put(
/* 2359 */                   "org.eclipse.jdt.core.compiler.debug.lineNumber", 
/* 2360 */                   "do not generate");
/* 2361 */               this.options.put(
/* 2362 */                   "org.eclipse.jdt.core.compiler.debug.sourceFile", 
/* 2363 */                   "do not generate");
/* 2364 */               if (length == 7 && debugOption.equals("-g:none"))
/*      */                 continue; 
/* 2366 */               StringTokenizer stringTokenizer = 
/* 2367 */                 new StringTokenizer(debugOption.substring(3, debugOption.length()), ",");
/* 2368 */               while (stringTokenizer.hasMoreTokens()) {
/* 2369 */                 String token = stringTokenizer.nextToken();
/* 2370 */                 if (token.equals("vars")) {
/* 2371 */                   this.options.put(
/* 2372 */                       "org.eclipse.jdt.core.compiler.debug.localVariable", 
/* 2373 */                       "generate"); continue;
/* 2374 */                 }  if (token.equals("lines")) {
/* 2375 */                   this.options.put(
/* 2376 */                       "org.eclipse.jdt.core.compiler.debug.lineNumber", 
/* 2377 */                       "generate"); continue;
/* 2378 */                 }  if (token.equals("source")) {
/* 2379 */                   this.options.put(
/* 2380 */                       "org.eclipse.jdt.core.compiler.debug.sourceFile", 
/* 2381 */                       "generate"); continue;
/*      */                 } 
/* 2383 */                 throw new IllegalArgumentException(
/* 2384 */                     bind("configure.invalidDebugOption", debugOption));
/*      */               } 
/*      */               
/*      */               continue;
/*      */             } 
/* 2389 */             throw new IllegalArgumentException(
/* 2390 */                 bind("configure.invalidDebugOption", debugOption));
/*      */           } 
/* 2392 */           if (currentArg.startsWith("-info")) {
/* 2393 */             int infoTokenStart; boolean isEnabling; mode = 0;
/* 2394 */             String infoOption = currentArg;
/* 2395 */             int length = currentArg.length();
/* 2396 */             if (length == 10 && infoOption.equals("-info:none")) {
/* 2397 */               disableAll(1024);
/*      */               continue;
/*      */             } 
/* 2400 */             if (length <= 6) {
/* 2401 */               throw new IllegalArgumentException(
/* 2402 */                   bind("configure.invalidInfoConfiguration", infoOption));
/*      */             }
/*      */ 
/*      */             
/* 2406 */             switch (infoOption.charAt(6)) {
/*      */               case '+':
/* 2408 */                 infoTokenStart = 7;
/* 2409 */                 isEnabling = true;
/*      */                 break;
/*      */               case '-':
/* 2412 */                 infoTokenStart = 7;
/* 2413 */                 isEnabling = false;
/*      */                 break;
/*      */               default:
/* 2416 */                 disableAll(1024);
/* 2417 */                 infoTokenStart = 6;
/* 2418 */                 isEnabling = true;
/*      */                 break;
/*      */             } 
/* 2421 */             StringTokenizer stringTokenizer = 
/* 2422 */               new StringTokenizer(infoOption.substring(infoTokenStart, infoOption.length()), ",");
/* 2423 */             int tokenCounter = 0;
/*      */             
/* 2425 */             while (stringTokenizer.hasMoreTokens()) {
/* 2426 */               String token = stringTokenizer.nextToken();
/* 2427 */               tokenCounter++;
/* 2428 */               switch (token.charAt(0)) {
/*      */                 case '+':
/* 2430 */                   isEnabling = true;
/* 2431 */                   token = token.substring(1);
/*      */                   break;
/*      */                 case '-':
/* 2434 */                   isEnabling = false;
/* 2435 */                   token = token.substring(1); break;
/*      */               } 
/* 2437 */               handleInfoToken(token, isEnabling);
/*      */             } 
/* 2439 */             if (tokenCounter == 0) {
/* 2440 */               throw new IllegalArgumentException(
/* 2441 */                   bind("configure.invalidInfoOption", currentArg));
/*      */             }
/*      */             continue;
/*      */           } 
/* 2445 */           if (currentArg.startsWith("-warn")) {
/* 2446 */             int warnTokenStart; boolean isEnabling; mode = 0;
/* 2447 */             String warningOption = currentArg;
/* 2448 */             int length = currentArg.length();
/* 2449 */             if (length == 10 && warningOption.equals("-warn:none")) {
/* 2450 */               disableAll(0);
/*      */               continue;
/*      */             } 
/* 2453 */             if (length <= 6) {
/* 2454 */               throw new IllegalArgumentException(
/* 2455 */                   bind("configure.invalidWarningConfiguration", warningOption));
/*      */             }
/*      */ 
/*      */             
/* 2459 */             switch (warningOption.charAt(6)) {
/*      */               case '+':
/* 2461 */                 warnTokenStart = 7;
/* 2462 */                 isEnabling = true;
/*      */                 break;
/*      */               case '-':
/* 2465 */                 warnTokenStart = 7;
/* 2466 */                 isEnabling = false;
/*      */                 break;
/*      */               default:
/* 2469 */                 disableAll(0);
/* 2470 */                 warnTokenStart = 6;
/* 2471 */                 isEnabling = true;
/*      */                 break;
/*      */             } 
/* 2474 */             StringTokenizer stringTokenizer = 
/* 2475 */               new StringTokenizer(warningOption.substring(warnTokenStart, warningOption.length()), ",");
/* 2476 */             int tokenCounter = 0;
/*      */             
/* 2478 */             if (didSpecifyDeprecation) {
/* 2479 */               this.options.put("org.eclipse.jdt.core.compiler.problem.deprecation", "warning");
/*      */             }
/*      */             
/* 2482 */             while (stringTokenizer.hasMoreTokens()) {
/* 2483 */               String token = stringTokenizer.nextToken();
/* 2484 */               tokenCounter++;
/* 2485 */               switch (token.charAt(0)) {
/*      */                 case '+':
/* 2487 */                   isEnabling = true;
/* 2488 */                   token = token.substring(1);
/*      */                   break;
/*      */                 case '-':
/* 2491 */                   isEnabling = false;
/* 2492 */                   token = token.substring(1); break;
/*      */               } 
/* 2494 */               handleWarningToken(token, isEnabling);
/*      */             } 
/* 2496 */             if (tokenCounter == 0) {
/* 2497 */               throw new IllegalArgumentException(
/* 2498 */                   bind("configure.invalidWarningOption", currentArg));
/*      */             }
/*      */             continue;
/*      */           } 
/* 2502 */           if (currentArg.startsWith("-err")) {
/* 2503 */             int errorTokenStart; boolean isEnabling; mode = 0;
/* 2504 */             String errorOption = currentArg;
/* 2505 */             int length = currentArg.length();
/* 2506 */             if (length <= 5) {
/* 2507 */               throw new IllegalArgumentException(
/* 2508 */                   bind("configure.invalidErrorConfiguration", errorOption));
/*      */             }
/*      */ 
/*      */             
/* 2512 */             switch (errorOption.charAt(5)) {
/*      */               case '+':
/* 2514 */                 errorTokenStart = 6;
/* 2515 */                 isEnabling = true;
/*      */                 break;
/*      */               case '-':
/* 2518 */                 errorTokenStart = 6;
/* 2519 */                 isEnabling = false;
/*      */                 break;
/*      */               default:
/* 2522 */                 disableAll(1);
/* 2523 */                 errorTokenStart = 5;
/* 2524 */                 isEnabling = true;
/*      */                 break;
/*      */             } 
/* 2527 */             StringTokenizer stringTokenizer = 
/* 2528 */               new StringTokenizer(errorOption.substring(errorTokenStart, errorOption.length()), ",");
/* 2529 */             int tokenCounter = 0;
/*      */             
/* 2531 */             while (stringTokenizer.hasMoreTokens()) {
/* 2532 */               String token = stringTokenizer.nextToken();
/* 2533 */               tokenCounter++;
/* 2534 */               switch (token.charAt(0)) {
/*      */                 case '+':
/* 2536 */                   isEnabling = true;
/* 2537 */                   token = token.substring(1);
/*      */                   break;
/*      */                 case '-':
/* 2540 */                   isEnabling = false;
/* 2541 */                   token = token.substring(1);
/*      */                   break;
/*      */               } 
/* 2544 */               handleErrorToken(token, isEnabling);
/*      */             } 
/* 2546 */             if (tokenCounter == 0) {
/* 2547 */               throw new IllegalArgumentException(
/* 2548 */                   bind("configure.invalidErrorOption", currentArg));
/*      */             }
/*      */             continue;
/*      */           } 
/* 2552 */           if (currentArg.equals("-target")) {
/* 2553 */             mode = 4;
/*      */             continue;
/*      */           } 
/* 2556 */           if (currentArg.equals("-preserveAllLocals")) {
/* 2557 */             this.options.put(
/* 2558 */                 "org.eclipse.jdt.core.compiler.codegen.unusedLocal", 
/* 2559 */                 "preserve");
/* 2560 */             mode = 0;
/*      */             continue;
/*      */           } 
/* 2563 */           if (currentArg.equals("-enableJavadoc")) {
/* 2564 */             mode = 0;
/* 2565 */             this.enableJavadocOn = true;
/*      */             continue;
/*      */           } 
/* 2568 */           if (currentArg.equals("-Xemacs")) {
/* 2569 */             mode = 0;
/* 2570 */             this.logger.setEmacs();
/*      */             
/*      */             continue;
/*      */           } 
/* 2574 */           if (currentArg.startsWith("-A")) {
/* 2575 */             mode = 0;
/*      */             continue;
/*      */           } 
/* 2578 */           if (currentArg.equals("-processorpath")) {
/* 2579 */             mode = 17;
/*      */             continue;
/*      */           } 
/* 2582 */           if (currentArg.equals("-processor")) {
/* 2583 */             mode = 18;
/*      */             continue;
/*      */           } 
/* 2586 */           if (currentArg.equals("--processor-module-path")) {
/* 2587 */             mode = 28;
/*      */             continue;
/*      */           } 
/* 2590 */           if (currentArg.equals("-proc:only")) {
/* 2591 */             this.options.put(
/* 2592 */                 "org.eclipse.jdt.core.compiler.generateClassFiles", 
/* 2593 */                 "disabled");
/* 2594 */             mode = 0;
/*      */             continue;
/*      */           } 
/* 2597 */           if (currentArg.equals("-proc:none")) {
/* 2598 */             didSpecifyDisabledAnnotationProcessing = true;
/* 2599 */             this.options.put(
/* 2600 */                 "org.eclipse.jdt.core.compiler.processAnnotations", 
/* 2601 */                 "disabled");
/* 2602 */             mode = 0;
/*      */             continue;
/*      */           } 
/* 2605 */           if (currentArg.equals("-s")) {
/* 2606 */             mode = 19;
/*      */             continue;
/*      */           } 
/* 2609 */           if (currentArg.equals("-XprintProcessorInfo") || 
/* 2610 */             currentArg.equals("-XprintRounds")) {
/* 2611 */             mode = 0;
/*      */             
/*      */             continue;
/*      */           } 
/* 2615 */           if (currentArg.startsWith("-X")) {
/* 2616 */             mode = 0;
/*      */             continue;
/*      */           } 
/* 2619 */           if (currentArg.startsWith("-J")) {
/* 2620 */             mode = 0;
/*      */             continue;
/*      */           } 
/* 2623 */           if (currentArg.equals("-O")) {
/* 2624 */             mode = 0;
/*      */             continue;
/*      */           } 
/* 2627 */           if (currentArg.equals("-classNames")) {
/* 2628 */             mode = 20;
/*      */             continue;
/*      */           } 
/* 2631 */           if (currentArg.equals("-properties")) {
/* 2632 */             mode = 21;
/*      */             continue;
/*      */           } 
/* 2635 */           if (currentArg.equals("-missingNullDefault")) {
/* 2636 */             this.options.put("org.eclipse.jdt.core.compiler.annotation.missingNonNullByDefaultAnnotation", "warning");
/*      */             continue;
/*      */           } 
/* 2639 */           if (currentArg.equals("-annotationpath")) {
/* 2640 */             mode = 22;
/*      */             continue;
/*      */           } 
/*      */           break;
/*      */         case 4:
/* 2645 */           if (this.didSpecifyTarget) {
/* 2646 */             throw new IllegalArgumentException(
/* 2647 */                 bind("configure.duplicateTarget", currentArg));
/*      */           }
/* 2649 */           if (this.releaseVersion != null) {
/* 2650 */             throw new IllegalArgumentException(
/* 2651 */                 bind("configure.unsupportedWithRelease", "-target"));
/*      */           }
/* 2653 */           this.didSpecifyTarget = true;
/* 2654 */           if (currentArg.equals("1.1")) {
/* 2655 */             this.options.put("org.eclipse.jdt.core.compiler.codegen.targetPlatform", "1.1");
/* 2656 */           } else if (currentArg.equals("1.2")) {
/* 2657 */             this.options.put("org.eclipse.jdt.core.compiler.codegen.targetPlatform", "1.2");
/* 2658 */           } else if (currentArg.equals("jsr14")) {
/* 2659 */             this.options.put("org.eclipse.jdt.core.compiler.codegen.targetPlatform", "jsr14");
/* 2660 */           } else if (currentArg.equals("cldc1.1")) {
/* 2661 */             this.options.put("org.eclipse.jdt.core.compiler.codegen.targetPlatform", "cldc1.1");
/* 2662 */             this.options.put("org.eclipse.jdt.core.compiler.codegen.inlineJsrBytecode", "enabled");
/*      */           } else {
/* 2664 */             String str = optionStringToVersion(currentArg);
/* 2665 */             if (str != null) {
/* 2666 */               this.options.put("org.eclipse.jdt.core.compiler.codegen.targetPlatform", str);
/*      */             } else {
/* 2668 */               throw new IllegalArgumentException(bind("configure.targetJDK", currentArg));
/*      */             } 
/*      */           } 
/* 2671 */           mode = 0;
/*      */           continue;
/*      */         case 5:
/* 2674 */           this.log = currentArg;
/* 2675 */           mode = 0;
/*      */           continue;
/*      */         case 6:
/*      */           try {
/* 2679 */             this.maxRepetition = Integer.parseInt(currentArg);
/* 2680 */             if (this.maxRepetition <= 0) {
/* 2681 */               throw new IllegalArgumentException(bind("configure.repetition", currentArg));
/*      */             }
/* 2683 */           } catch (NumberFormatException e) {
/* 2684 */             throw new IllegalArgumentException(bind("configure.repetition", currentArg), e);
/*      */           } 
/* 2686 */           mode = 0;
/*      */           continue;
/*      */         case 11:
/*      */           try {
/* 2690 */             this.maxProblems = Integer.parseInt(currentArg);
/* 2691 */             if (this.maxProblems <= 0) {
/* 2692 */               throw new IllegalArgumentException(bind("configure.maxProblems", currentArg));
/*      */             }
/* 2694 */             this.options.put("org.eclipse.jdt.core.compiler.maxProblemPerUnit", currentArg);
/* 2695 */           } catch (NumberFormatException e) {
/* 2696 */             throw new IllegalArgumentException(bind("configure.maxProblems", currentArg), e);
/*      */           } 
/* 2698 */           mode = 0;
/*      */           continue;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         case 30:
/* 2709 */           this.releaseVersion = currentArg;
/* 2710 */           releaseToJDKLevel = CompilerOptions.releaseToJDKLevel(currentArg);
/* 2711 */           if (releaseToJDKLevel == 0L) {
/* 2712 */             throw new IllegalArgumentException(
/* 2713 */                 bind("configure.unsupportedReleaseVersion", currentArg));
/*      */           }
/*      */           
/* 2716 */           this.complianceLevel = releaseToJDKLevel;
/* 2717 */           versionAsString = CompilerOptions.versionFromJdkLevel(releaseToJDKLevel);
/* 2718 */           this.options.put("org.eclipse.jdt.core.compiler.compliance", versionAsString);
/* 2719 */           this.options.put("org.eclipse.jdt.core.compiler.source", versionAsString);
/* 2720 */           this.options.put("org.eclipse.jdt.core.compiler.codegen.targetPlatform", versionAsString);
/* 2721 */           mode = 0;
/*      */           continue;
/*      */         case 7:
/* 2724 */           if (this.didSpecifySource) {
/* 2725 */             throw new IllegalArgumentException(
/* 2726 */                 bind("configure.duplicateSource", currentArg));
/*      */           }
/* 2728 */           if (this.releaseVersion != null) {
/* 2729 */             throw new IllegalArgumentException(
/* 2730 */                 bind("configure.unsupportedWithRelease", "-source"));
/*      */           }
/* 2732 */           this.didSpecifySource = true;
/* 2733 */           version = optionStringToVersion(currentArg);
/* 2734 */           if (version != null) {
/* 2735 */             this.options.put("org.eclipse.jdt.core.compiler.source", version);
/*      */           } else {
/* 2737 */             throw new IllegalArgumentException(bind("configure.source", currentArg));
/*      */           } 
/* 2739 */           mode = 0;
/*      */           continue;
/*      */         case 8:
/* 2742 */           if (specifiedEncodings != null) {
/*      */             
/* 2744 */             if (!specifiedEncodings.contains(currentArg)) {
/* 2745 */               if (specifiedEncodings.size() > 1) {
/* 2746 */                 this.logger.logWarning(
/* 2747 */                     bind("configure.differentencodings", 
/* 2748 */                       currentArg, 
/* 2749 */                       getAllEncodings(specifiedEncodings)));
/*      */               } else {
/* 2751 */                 this.logger.logWarning(
/* 2752 */                     bind("configure.differentencoding", 
/* 2753 */                       currentArg, 
/* 2754 */                       getAllEncodings(specifiedEncodings)));
/*      */               } 
/*      */             }
/*      */           } else {
/* 2758 */             specifiedEncodings = new HashSet<>();
/*      */           } 
/*      */           try {
/*      */           
/* 2762 */           } catch (UnsupportedEncodingException e) {
/* 2763 */             throw new IllegalArgumentException(
/* 2764 */                 bind("configure.unsupportedEncoding", currentArg), e);
/*      */           } 
/* 2766 */           specifiedEncodings.add(currentArg);
/* 2767 */           this.options.put("org.eclipse.jdt.core.encoding", currentArg);
/* 2768 */           mode = 0;
/*      */           continue;
/*      */         case 3:
/* 2771 */           setDestinationPath(currentArg.equals("none") ? "none" : currentArg);
/* 2772 */           mode = 0;
/*      */           continue;
/*      */         case 27:
/* 2775 */           mode = 0;
/* 2776 */           setJavaHome(currentArg);
/*      */           continue;
/*      */         case 23:
/* 2779 */           mode = 0;
/* 2780 */           modulepaths = new String[1];
/* 2781 */           index += processPaths(newCommandLineArgs, index, currentArg, modulepaths);
/* 2782 */           modulepathArg = modulepaths[0];
/*      */           continue;
/*      */         case 24:
/* 2785 */           mode = 0;
/* 2786 */           moduleSourcepaths = new String[1];
/* 2787 */           index += processPaths(newCommandLineArgs, index, currentArg, moduleSourcepaths);
/* 2788 */           moduleSourcepathArg = moduleSourcepaths[0];
/*      */           continue;
/*      */         case 25:
/* 2791 */           mode = 0;
/*      */           
/* 2793 */           if (this.addonExports == Collections.EMPTY_LIST) {
/* 2794 */             this.addonExports = new ArrayList<>();
/*      */           }
/* 2796 */           this.addonExports.add(currentArg);
/*      */           continue;
/*      */         case 26:
/* 2799 */           mode = 0;
/* 2800 */           if (this.addonReads == Collections.EMPTY_LIST) {
/* 2801 */             this.addonReads = new ArrayList<>();
/*      */           }
/* 2803 */           this.addonReads.add(currentArg);
/*      */           continue;
/*      */         case 29:
/* 2806 */           mode = 0;
/* 2807 */           if (this.rootModules == Collections.EMPTY_SET) {
/* 2808 */             this.rootModules = new HashSet<>();
/*      */           }
/* 2810 */           tokenizer = new StringTokenizer(currentArg, ",");
/* 2811 */           while (tokenizer.hasMoreTokens()) {
/* 2812 */             this.rootModules.add(tokenizer.nextToken().trim());
/*      */           }
/*      */           continue;
/*      */         case 31:
/* 2816 */           mode = 0;
/* 2817 */           tokenizer = new StringTokenizer(currentArg, ",");
/* 2818 */           while (tokenizer.hasMoreTokens()) {
/* 2819 */             if (this.limitedModules == null) {
/* 2820 */               this.limitedModules = new HashSet<>();
/*      */             }
/* 2822 */             this.limitedModules.add(tokenizer.nextToken().trim());
/*      */           } 
/*      */           continue;
/*      */         case 32:
/* 2826 */           mode = 0;
/* 2827 */           this.moduleVersion = validateModuleVersion(currentArg);
/*      */           continue;
/*      */         case 1:
/* 2830 */           mode = 0;
/* 2831 */           index += processPaths(newCommandLineArgs, index, currentArg, classpaths);
/*      */           continue;
/*      */         case 9:
/* 2834 */           mode = 0;
/* 2835 */           index += processPaths(newCommandLineArgs, index, currentArg, bootclasspaths);
/*      */           continue;
/*      */         case 13:
/* 2838 */           mode = 0;
/* 2839 */           sourcePaths = new String[1];
/* 2840 */           index += processPaths(newCommandLineArgs, index, currentArg, sourcePaths);
/* 2841 */           sourcepathClasspathArg = sourcePaths[0];
/*      */           continue;
/*      */         case 12:
/* 2844 */           if (currentArg.indexOf("[-d") != -1) {
/* 2845 */             throw new IllegalArgumentException(
/* 2846 */                 bind("configure.unexpectedDestinationPathEntry", 
/* 2847 */                   "-extdir"));
/*      */           }
/* 2849 */           tokenizer = new StringTokenizer(currentArg, File.pathSeparator, false);
/* 2850 */           extdirsClasspaths = new ArrayList<>(4);
/* 2851 */           while (tokenizer.hasMoreTokens())
/* 2852 */             extdirsClasspaths.add(tokenizer.nextToken()); 
/* 2853 */           mode = 0;
/*      */           continue;
/*      */         case 15:
/* 2856 */           if (currentArg.indexOf("[-d") != -1)
/* 2857 */             throw new IllegalArgumentException(
/* 2858 */                 bind("configure.unexpectedDestinationPathEntry", 
/* 2859 */                   "-endorseddirs")); 
/* 2860 */           tokenizer = new StringTokenizer(currentArg, File.pathSeparator, false);
/* 2861 */           endorsedDirClasspaths = new ArrayList<>(4);
/* 2862 */           while (tokenizer.hasMoreTokens())
/* 2863 */             endorsedDirClasspaths.add(tokenizer.nextToken()); 
/* 2864 */           mode = 0;
/*      */           continue;
/*      */         case 16:
/* 2867 */           if (currentArg.endsWith("]")) {
/* 2868 */             customDestinationPath = currentArg.substring(0, 
/* 2869 */                 currentArg.length() - 1); break;
/*      */           } 
/* 2871 */           throw new IllegalArgumentException(
/* 2872 */               bind("configure.incorrectDestinationPathEntry", 
/* 2873 */                 "[-d " + currentArg));
/*      */ 
/*      */ 
/*      */         
/*      */         case 17:
/* 2878 */           mode = 0;
/*      */           continue;
/*      */         
/*      */         case 18:
/* 2882 */           mode = 0;
/*      */           continue;
/*      */         case 28:
/* 2885 */           mode = 0;
/*      */           continue;
/*      */         
/*      */         case 19:
/* 2889 */           mode = 0;
/*      */           continue;
/*      */         case 20:
/* 2892 */           tokenizer = new StringTokenizer(currentArg, ",");
/* 2893 */           if (this.classNames == null) {
/* 2894 */             this.classNames = new String[4];
/*      */           }
/* 2896 */           while (tokenizer.hasMoreTokens()) {
/* 2897 */             if (this.classNames.length == classCount)
/*      */             {
/* 2899 */               System.arraycopy(
/* 2900 */                   this.classNames, 
/* 2901 */                   0, 
/* 2902 */                   this.classNames = new String[classCount * 2], 
/* 2903 */                   0, 
/* 2904 */                   classCount);
/*      */             }
/* 2906 */             this.classNames[classCount++] = tokenizer.nextToken();
/*      */           } 
/* 2908 */           mode = 0;
/*      */           continue;
/*      */         case 21:
/* 2911 */           initializeWarnings(currentArg);
/* 2912 */           mode = 0;
/*      */           continue;
/*      */         case 22:
/* 2915 */           mode = 0;
/* 2916 */           if (currentArg.isEmpty() || currentArg.charAt(0) == '-')
/* 2917 */             throw new IllegalArgumentException(bind("configure.missingAnnotationPath", currentArg)); 
/* 2918 */           if ("CLASSPATH".equals(currentArg)) {
/* 2919 */             this.annotationsFromClasspath = true; continue;
/*      */           } 
/* 2921 */           if (this.annotationPaths == null)
/* 2922 */             this.annotationPaths = new ArrayList<>(); 
/* 2923 */           tokens = new StringTokenizer(currentArg, File.pathSeparator);
/* 2924 */           while (tokens.hasMoreTokens()) {
/* 2925 */             this.annotationPaths.add(tokens.nextToken());
/*      */           }
/*      */           continue;
/*      */       } 
/*      */ 
/*      */       
/* 2931 */       if (customDestinationPath == null) {
/* 2932 */         if (File.separatorChar != '/') {
/* 2933 */           currentArg = currentArg.replace('/', File.separatorChar);
/*      */         }
/* 2935 */         if (currentArg.endsWith("[-d")) {
/* 2936 */           currentSourceDirectory = currentArg.substring(0, 
/* 2937 */               currentArg.length() - 3);
/* 2938 */           mode = 16;
/*      */           continue;
/*      */         } 
/* 2941 */         currentSourceDirectory = currentArg;
/*      */       } 
/* 2943 */       File dir = new File(currentSourceDirectory);
/* 2944 */       if (!dir.isDirectory()) {
/* 2945 */         throw new IllegalArgumentException(
/* 2946 */             bind("configure.unrecognizedOption", currentSourceDirectory));
/*      */       }
/* 2948 */       String[] result = FileFinder.find(dir, ".java");
/* 2949 */       if ("none".equals(customDestinationPath)) {
/* 2950 */         customDestinationPath = "none";
/*      */       }
/* 2952 */       if (this.filenames != null) {
/*      */         
/* 2954 */         int length = result.length;
/* 2955 */         System.arraycopy(
/* 2956 */             this.filenames, 
/* 2957 */             0, 
/* 2958 */             this.filenames = new String[length + filesCount], 
/* 2959 */             0, 
/* 2960 */             filesCount);
/* 2961 */         System.arraycopy(
/* 2962 */             this.encodings, 
/* 2963 */             0, 
/* 2964 */             this.encodings = new String[length + filesCount], 
/* 2965 */             0, 
/* 2966 */             filesCount);
/* 2967 */         System.arraycopy(
/* 2968 */             this.destinationPaths, 
/* 2969 */             0, 
/* 2970 */             this.destinationPaths = new String[length + filesCount], 
/* 2971 */             0, 
/* 2972 */             filesCount);
/* 2973 */         System.arraycopy(result, 0, this.filenames, filesCount, length);
/* 2974 */         for (int j = 0; j < length; j++) {
/* 2975 */           this.encodings[filesCount + j] = customEncoding;
/* 2976 */           this.destinationPaths[filesCount + j] = customDestinationPath;
/*      */         } 
/* 2978 */         filesCount += length;
/* 2979 */         customEncoding = null;
/* 2980 */         customDestinationPath = null;
/* 2981 */         currentSourceDirectory = null;
/*      */       } else {
/* 2983 */         this.filenames = result;
/* 2984 */         filesCount = this.filenames.length;
/* 2985 */         this.encodings = new String[filesCount];
/* 2986 */         this.destinationPaths = new String[filesCount];
/* 2987 */         for (int j = 0; j < filesCount; j++) {
/* 2988 */           this.encodings[j] = customEncoding;
/* 2989 */           this.destinationPaths[j] = customDestinationPath;
/*      */         } 
/* 2991 */         customEncoding = null;
/* 2992 */         customDestinationPath = null;
/* 2993 */         currentSourceDirectory = null;
/*      */       } 
/* 2995 */       mode = 0;
/*      */     } 
/*      */     
/* 2998 */     if (this.enablePreview) {
/* 2999 */       this.options.put(
/* 3000 */           "org.eclipse.jdt.core.compiler.problem.enablePreviewFeatures", 
/* 3001 */           "enabled");
/*      */     }
/*      */ 
/*      */ 
/*      */     
/* 3006 */     if (this.enableJavadocOn) {
/* 3007 */       this.options.put(
/* 3008 */           "org.eclipse.jdt.core.compiler.doc.comment.support", 
/* 3009 */           "enabled");
/* 3010 */     } else if (this.warnJavadocOn || this.warnAllJavadocOn) {
/* 3011 */       this.options.put(
/* 3012 */           "org.eclipse.jdt.core.compiler.doc.comment.support", 
/* 3013 */           "enabled");
/*      */ 
/*      */       
/* 3016 */       this.options.put(
/* 3017 */           "org.eclipse.jdt.core.compiler.problem.unusedParameterIncludeDocCommentReference", 
/* 3018 */           "disabled");
/* 3019 */       this.options.put(
/* 3020 */           "org.eclipse.jdt.core.compiler.problem.unusedDeclaredThrownExceptionIncludeDocCommentReference", 
/* 3021 */           "disabled");
/*      */     } 
/*      */     
/* 3024 */     if (this.warnJavadocOn) {
/* 3025 */       this.options.put(
/* 3026 */           "org.eclipse.jdt.core.compiler.problem.invalidJavadocTags", 
/* 3027 */           "enabled");
/* 3028 */       this.options.put(
/* 3029 */           "org.eclipse.jdt.core.compiler.problem.invalidJavadocTagsDeprecatedRef", 
/* 3030 */           "enabled");
/* 3031 */       this.options.put(
/* 3032 */           "org.eclipse.jdt.core.compiler.problem.invalidJavadocTagsNotVisibleRef", 
/* 3033 */           "enabled");
/* 3034 */       this.options.put(
/* 3035 */           "org.eclipse.jdt.core.compiler.problem.missingJavadocTagsVisibility", 
/* 3036 */           "private");
/*      */     } 
/* 3038 */     if (printUsageRequired || (filesCount == 0 && classCount == 0)) {
/* 3039 */       if (usageSection == null) {
/* 3040 */         printUsage();
/*      */       } else {
/* 3042 */         printUsage(usageSection);
/*      */       } 
/* 3044 */       this.proceed = false;
/*      */       
/*      */       return;
/*      */     } 
/* 3048 */     if (this.log != null) {
/* 3049 */       this.logger.setLog(this.log);
/*      */     } else {
/* 3051 */       this.showProgress = false;
/*      */     } 
/* 3053 */     this.logger.logVersion(printVersionRequired);
/*      */     
/* 3055 */     validateOptions(didSpecifyCompliance);
/*      */ 
/*      */ 
/*      */     
/* 3059 */     if (!didSpecifyDisabledAnnotationProcessing && 
/* 3060 */       CompilerOptions.versionToJdkLevel(this.options.get("org.eclipse.jdt.core.compiler.compliance")) >= 3276800L) {
/* 3061 */       this.options.put("org.eclipse.jdt.core.compiler.processAnnotations", "enabled");
/*      */     }
/*      */     
/* 3064 */     this.logger.logCommandLineArguments(newCommandLineArgs);
/* 3065 */     this.logger.logOptions(this.options);
/*      */     
/* 3067 */     if (this.maxRepetition == 0) {
/* 3068 */       this.maxRepetition = 1;
/*      */     }
/* 3070 */     if (this.maxRepetition >= 3 && (this.timing & 0x1) != 0) {
/* 3071 */       this.compilerStats = new CompilerStats[this.maxRepetition];
/*      */     }
/*      */     
/* 3074 */     if (filesCount != 0) {
/* 3075 */       System.arraycopy(
/* 3076 */           this.filenames, 
/* 3077 */           0, 
/* 3078 */           this.filenames = new String[filesCount], 
/* 3079 */           0, 
/* 3080 */           filesCount);
/*      */       
/* 3082 */       this.modNames = new String[filesCount];
/*      */     } 
/*      */     
/* 3085 */     if (classCount != 0) {
/* 3086 */       System.arraycopy(
/* 3087 */           this.classNames, 
/* 3088 */           0, 
/* 3089 */           this.classNames = new String[classCount], 
/* 3090 */           0, 
/* 3091 */           classCount);
/*      */     }
/*      */     
/* 3094 */     if (moduleSourcepathArg == null) {
/* 3095 */       handleSingleModuleCompilation();
/*      */     }
/*      */     
/* 3098 */     setPaths(bootclasspaths, 
/* 3099 */         sourcepathClasspathArg, 
/* 3100 */         sourcepathClasspaths, 
/* 3101 */         classpaths, 
/* 3102 */         modulepathArg, 
/* 3103 */         moduleSourcepathArg, 
/* 3104 */         extdirsClasspaths, 
/* 3105 */         endorsedDirClasspaths, 
/* 3106 */         customEncoding);
/*      */     
/* 3108 */     if (specifiedEncodings != null && specifiedEncodings.size() > 1) {
/* 3109 */       this.logger.logWarning(bind("configure.multipleencodings", 
/* 3110 */             this.options.get("org.eclipse.jdt.core.encoding"), 
/* 3111 */             getAllEncodings(specifiedEncodings)));
/*      */     }
/* 3113 */     if (this.pendingErrors != null) {
/* 3114 */       for (Iterator<String> iterator = this.pendingErrors.iterator(); iterator.hasNext(); ) {
/* 3115 */         String message = iterator.next();
/* 3116 */         this.logger.logPendingError(message);
/*      */       } 
/* 3118 */       this.pendingErrors = null;
/*      */     } 
/*      */   }
/*      */   private String optionStringToVersion(String currentArg) {
/*      */     String str;
/* 3123 */     switch ((str = currentArg).hashCode()) { case 53: if (!str.equals("5")) {
/*      */           break;
/*      */         }
/*      */ 
/*      */ 
/*      */         
/* 3129 */         return "1.5";
/*      */       case 54:
/*      */         if (!str.equals("6"))
/*      */           break; 
/* 3133 */         return "1.6";
/*      */       case 55:
/*      */         if (!str.equals("7"))
/*      */           break; 
/* 3137 */         return "1.7";
/*      */       case 56:
/*      */         if (!str.equals("8"))
/*      */           break; 
/* 3141 */         return "1.8";
/*      */       case 57:
/*      */         if (!str.equals("9"))
/*      */           break; 
/* 3145 */         return "9";
/*      */       case 1567:
/*      */         if (!str.equals("10"))
/* 3148 */           break;  return "10";
/*      */       case 1568:
/*      */         if (!str.equals("11"))
/* 3151 */           break;  return "11";
/*      */       case 1569:
/*      */         if (!str.equals("12"))
/* 3154 */           break;  return "12";
/*      */       case 1570:
/*      */         if (!str.equals("13"))
/* 3157 */           break;  return "13";
/*      */       case 1571:
/*      */         if (!str.equals("14"))
/* 3160 */           break;  return "14";
/*      */       case 1572:
/*      */         if (!str.equals("15"))
/* 3163 */           break;  return "15";
/*      */       case 1573:
/*      */         if (!str.equals("16"))
/* 3166 */           break;  return "16";
/*      */       case 1574:
/*      */         if (!str.equals("17"))
/* 3169 */           break;  return "17";
/*      */       case 1575:
/*      */         if (!str.equals("18"))
/* 3172 */           break;  return "18";
/*      */       case 1576:
/*      */         if (!str.equals("19"))
/* 3175 */           break;  return "19";
/*      */       case 1598:
/*      */         if (!str.equals("20"))
/* 3178 */           break;  return "20";case 48566: if (!str.equals("1.3")) break;  return "1.3";case 48567: if (!str.equals("1.4")) break;  return "1.4";case 48568: if (!str.equals("1.5")) break;  return "1.5";case 48569: if (!str.equals("1.6")) break;  return "1.6";case 48570: if (!str.equals("1.7")) break;  return "1.7";case 48571: if (!str.equals("1.8")) break;  return "1.8";case 48572: if (!str.equals("1.9")) break;  return "9";case 52407: if (!str.equals("5.0")) break;  return "1.5";case 53368: if (!str.equals("6.0")) break;  return "1.6";case 54329: if (!str.equals("7.0")) break;  return "1.7";case 55290: if (!str.equals("8.0")) break;  return "1.8";case 56251: if (!str.equals("9.0")) break;  return "9";case 1507361: if (!str.equals("10.0")) break;  return "10";case 1508322: if (!str.equals("11.0")) break;  return "11";case 1509283: if (!str.equals("12.0")) break;  return "12";case 1510244: if (!str.equals("13.0")) break;  return "13";case 1511205: if (!str.equals("14.0")) break;  return "14";case 1512166: if (!str.equals("15.0")) break;  return "15";case 1513127: if (!str.equals("16.0")) break;  return "16";case 1514088: if (!str.equals("17.0")) break;  return "17";case 1515049: if (!str.equals("18.0")) break;  return "18";case 1516010: if (!str.equals("19.0")) break;  return "19";case 1537152: if (!str.equals("20.0")) break;  return "20"; }
/*      */     
/* 3180 */     return null;
/*      */   }
/*      */   
/*      */   private String validateModuleVersion(String versionString) {
/*      */     try {
/* 3185 */       Class<?> versionClass = Class.forName("java.lang.module.ModuleDescriptor$Version");
/* 3186 */       Method method = versionClass.getMethod("parse", new Class[] { String.class });
/*      */       try {
/* 3188 */         method.invoke(null, new Object[] { versionString });
/* 3189 */       } catch (InvocationTargetException e) {
/* 3190 */         if (e.getCause() instanceof IllegalArgumentException)
/* 3191 */           throw (IllegalArgumentException)e.getCause(); 
/*      */       } 
/* 3193 */     } catch (ClassNotFoundException|NoSuchMethodException|SecurityException|IllegalAccessException classNotFoundException) {
/* 3194 */       this.logger.logWarning(bind("configure.no.ModuleDescriptorVersionparse"));
/*      */     } 
/* 3196 */     return versionString;
/*      */   }
/*      */   
/*      */   private Parser getNewParser() {
/* 3200 */     return new Parser(new ProblemReporter(getHandlingPolicy(), 
/* 3201 */           new CompilerOptions(this.options), getProblemFactory()), false);
/*      */   } private IModule extractModuleDesc(String fileName) {
/*      */     IBinaryModule iBinaryModule;
/* 3204 */     IModule mod = null;
/* 3205 */     if (fileName.toLowerCase().endsWith("module-info.java")) {
/*      */ 
/*      */       
/* 3208 */       Map<String, String> opts = new HashMap<>(this.options);
/* 3209 */       opts.put("org.eclipse.jdt.core.compiler.source", this.options.get("org.eclipse.jdt.core.compiler.compliance"));
/* 3210 */       Parser parser = new Parser(new ProblemReporter(getHandlingPolicy(), 
/* 3211 */             new CompilerOptions(opts), getProblemFactory()), false);
/*      */       
/* 3213 */       ICompilationUnit cu = new CompilationUnit(null, fileName, null);
/* 3214 */       CompilationResult compilationResult = new CompilationResult(cu, 0, 1, 10);
/* 3215 */       CompilationUnitDeclaration unit = parser.parse(cu, compilationResult);
/* 3216 */       if (unit.isModuleInfo() && unit.moduleDeclaration != null) {
/* 3217 */         BasicModule basicModule = new BasicModule(unit.moduleDeclaration, null);
/*      */       }
/* 3219 */     } else if (fileName.toLowerCase().endsWith("module-info.class")) {
/*      */       try {
/* 3221 */         ClassFileReader reader = ClassFileReader.read(fileName);
/* 3222 */         iBinaryModule = reader.getModuleDeclaration();
/* 3223 */       } catch (ClassFormatException|IOException e) {
/* 3224 */         e.printStackTrace();
/* 3225 */         throw new IllegalArgumentException(
/* 3226 */             bind("configure.invalidModuleDescriptor", fileName));
/*      */       } 
/*      */     } 
/* 3229 */     return (IModule)iBinaryModule;
/*      */   }
/*      */   
/*      */   private static char[][] decodeIgnoreOptionalProblemsFromFolders(String folders) {
/* 3233 */     StringTokenizer tokenizer = new StringTokenizer(folders, File.pathSeparator);
/* 3234 */     char[][] result = new char[2 * tokenizer.countTokens()][];
/* 3235 */     int count = 0;
/* 3236 */     while (tokenizer.hasMoreTokens()) {
/* 3237 */       String fileName = tokenizer.nextToken();
/*      */       
/* 3239 */       File file = new File(fileName);
/* 3240 */       if (file.exists()) {
/* 3241 */         String absolutePath = file.getAbsolutePath();
/* 3242 */         result[count++] = absolutePath.toCharArray();
/*      */         
/*      */         try {
/* 3245 */           String canonicalPath = file.getCanonicalPath();
/* 3246 */           if (!absolutePath.equals(canonicalPath)) {
/* 3247 */             result[count++] = canonicalPath.toCharArray();
/*      */           }
/* 3249 */         } catch (IOException iOException) {}
/*      */         
/*      */         continue;
/*      */       } 
/*      */       
/* 3254 */       result[count++] = fileName.toCharArray();
/*      */     } 
/*      */     
/* 3257 */     if (count < result.length) {
/* 3258 */       char[][] shortened = new char[count][];
/* 3259 */       System.arraycopy(result, 0, shortened, 0, count);
/* 3260 */       result = shortened;
/*      */     } 
/* 3262 */     return result;
/*      */   }
/*      */   
/*      */   private static String getAllEncodings(Set<String> encodings) {
/* 3266 */     int size = encodings.size();
/* 3267 */     String[] allEncodings = new String[size];
/* 3268 */     encodings.toArray(allEncodings);
/* 3269 */     Arrays.sort((Object[])allEncodings);
/* 3270 */     StringBuffer buffer = new StringBuffer();
/* 3271 */     for (int i = 0; i < size; i++) {
/* 3272 */       if (i > 0) {
/* 3273 */         buffer.append(", ");
/*      */       }
/* 3275 */       buffer.append(allEncodings[i]);
/*      */     } 
/* 3277 */     return String.valueOf(buffer);
/*      */   }
/*      */   
/*      */   private void initializeWarnings(String propertiesFile) {
/* 3281 */     File file = new File(propertiesFile);
/* 3282 */     if (!file.exists()) {
/* 3283 */       throw new IllegalArgumentException(bind("configure.missingwarningspropertiesfile", propertiesFile));
/*      */     }
/* 3285 */     BufferedInputStream stream = null;
/* 3286 */     Properties properties = null;
/*      */     try {
/* 3288 */       stream = new BufferedInputStream(new FileInputStream(propertiesFile));
/* 3289 */       properties = new Properties();
/* 3290 */       properties.load(stream);
/* 3291 */     } catch (IOException e) {
/* 3292 */       e.printStackTrace();
/* 3293 */       throw new IllegalArgumentException(bind("configure.ioexceptionwarningspropertiesfile", propertiesFile));
/*      */     } finally {
/* 3295 */       if (stream != null) {
/*      */         try {
/* 3297 */           stream.close();
/* 3298 */         } catch (IOException iOException) {}
/*      */       }
/*      */     } 
/*      */ 
/*      */     
/* 3303 */     for (Iterator<Map.Entry<Object, Object>> iterator = properties.entrySet().iterator(); iterator.hasNext(); ) {
/* 3304 */       Map.Entry entry = iterator.next();
/* 3305 */       String key = entry.getKey().toString();
/* 3306 */       if (key.startsWith("org.eclipse.jdt.core.compiler.")) {
/* 3307 */         this.options.put(key, entry.getValue().toString());
/*      */       }
/*      */     } 
/*      */     
/* 3311 */     if (!properties.containsKey("org.eclipse.jdt.core.compiler.debug.localVariable")) {
/* 3312 */       this.options.put("org.eclipse.jdt.core.compiler.debug.localVariable", "generate");
/*      */     }
/* 3314 */     if (!properties.containsKey("org.eclipse.jdt.core.compiler.codegen.unusedLocal")) {
/* 3315 */       this.options.put("org.eclipse.jdt.core.compiler.codegen.unusedLocal", "preserve");
/*      */     }
/* 3317 */     if (!properties.containsKey("org.eclipse.jdt.core.compiler.doc.comment.support")) {
/* 3318 */       this.options.put("org.eclipse.jdt.core.compiler.doc.comment.support", "enabled");
/*      */     }
/* 3320 */     if (!properties.containsKey("org.eclipse.jdt.core.compiler.problem.forbiddenReference"))
/* 3321 */       this.options.put("org.eclipse.jdt.core.compiler.problem.forbiddenReference", "error"); 
/*      */   }
/*      */   
/*      */   protected void enableAll(int severity) {
/* 3325 */     String newValue = null;
/* 3326 */     switch (severity) {
/*      */       case 1:
/* 3328 */         newValue = "error";
/*      */         break;
/*      */       case 0:
/* 3331 */         newValue = "warning";
/*      */         break;
/*      */     } 
/* 3334 */     Map.Entry[] entries = (Map.Entry[])this.options.entrySet().toArray((Object[])new Map.Entry[this.options.size()]);
/* 3335 */     for (int i = 0, max = entries.length; i < max; i++) {
/* 3336 */       Map.Entry<String, String> entry = entries[i];
/* 3337 */       if (((String)entry.getValue()).equals("ignore")) {
/* 3338 */         this.options.put(entry.getKey(), newValue);
/*      */       }
/*      */     } 
/* 3341 */     this.options.put("org.eclipse.jdt.core.compiler.taskTags", Util.EMPTY_STRING);
/* 3342 */     if (newValue != null)
/* 3343 */       this.options.remove(newValue); 
/*      */   }
/*      */   
/*      */   protected void disableAll(int severity) {
/* 3347 */     String checkedValue = null;
/* 3348 */     switch (severity) {
/*      */       case 1:
/* 3350 */         checkedValue = "error";
/*      */         break;
/*      */       case 0:
/* 3353 */         checkedValue = "warning";
/*      */         break;
/*      */       case 1024:
/* 3356 */         checkedValue = "info";
/*      */         break;
/*      */     } 
/* 3359 */     Set<Map.Entry<String, String>> entrySet = this.options.entrySet();
/* 3360 */     for (Map.Entry<String, String> entry : entrySet) {
/* 3361 */       if (((String)entry.getValue()).equals(checkedValue)) {
/* 3362 */         this.options.put(entry.getKey(), "ignore");
/*      */       }
/*      */     } 
/* 3365 */     if (checkedValue != null) {
/* 3366 */       this.options.put(checkedValue, "ignore");
/*      */     }
/* 3368 */     if (severity == 0)
/* 3369 */       disableAll(1024); 
/*      */   }
/*      */   
/*      */   public String extractDestinationPathFromSourceFile(CompilationResult result) {
/* 3373 */     ICompilationUnit compilationUnit = result.compilationUnit;
/* 3374 */     if (compilationUnit != null) {
/* 3375 */       char[] fileName = compilationUnit.getFileName();
/* 3376 */       int lastIndex = CharOperation.lastIndexOf(File.separatorChar, fileName);
/* 3377 */       if (lastIndex != -1) {
/* 3378 */         String outputPathName = new String(fileName, 0, lastIndex);
/* 3379 */         File output = new File(outputPathName);
/* 3380 */         if (output.exists() && output.isDirectory()) {
/* 3381 */           return outputPathName;
/*      */         }
/*      */       } 
/*      */     } 
/* 3385 */     return System.getProperty("user.dir");
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public ICompilerRequestor getBatchRequestor() {
/* 3391 */     return new BatchCompilerRequestor(this);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public CompilationUnit[] getCompilationUnits() {
/* 3397 */     int fileCount = this.filenames.length;
/* 3398 */     CompilationUnit[] units = new CompilationUnit[fileCount];
/* 3399 */     HashtableOfObject knownFileNames = new HashtableOfObject(fileCount);
/*      */     
/* 3401 */     String defaultEncoding = this.options.get("org.eclipse.jdt.core.encoding");
/* 3402 */     if (Util.EMPTY_STRING.equals(defaultEncoding)) {
/* 3403 */       defaultEncoding = null;
/*      */     }
/* 3405 */     for (int round = 0; round < 2; round++) {
/* 3406 */       for (int i = 0; i < fileCount; i++) {
/* 3407 */         char[] charName = this.filenames[i].toCharArray();
/* 3408 */         boolean isModuleInfo = CharOperation.endsWith(charName, TypeConstants.MODULE_INFO_FILE_NAME);
/* 3409 */         if (isModuleInfo == ((round == 0))) {
/* 3410 */           String fileName; if (knownFileNames.get(charName) != null)
/* 3411 */             throw new IllegalArgumentException(bind("unit.more", this.filenames[i])); 
/* 3412 */           knownFileNames.put(charName, charName);
/* 3413 */           File file = new File(this.filenames[i]);
/* 3414 */           if (!file.exists())
/* 3415 */             throw new IllegalArgumentException(bind("unit.missing", this.filenames[i])); 
/* 3416 */           String encoding = this.encodings[i];
/* 3417 */           if (encoding == null) {
/* 3418 */             encoding = defaultEncoding;
/*      */           }
/*      */           try {
/* 3421 */             fileName = file.getCanonicalPath();
/* 3422 */           } catch (IOException iOException) {
/*      */             
/* 3424 */             fileName = this.filenames[i];
/*      */           } 
/* 3426 */           Function<String, String> annotationPathProvider = null;
/* 3427 */           if (this.annotationsFromClasspath) {
/* 3428 */             annotationPathProvider = (qualifiedTypeName -> {
/*      */                 FileSystem.Classpath[] arrayOfClasspath; int i = (arrayOfClasspath = this.checkedClasspaths).length; for (byte b = 0; b < i; b++) {
/*      */                   FileSystem.Classpath classpathEntry = arrayOfClasspath[b]; if (classpathEntry.hasAnnotationFileFor(qualifiedTypeName.replace('.', '/')))
/*      */                     return classpathEntry.getPath(); 
/*      */                 } 
/*      */                 return null;
/*      */               });
/* 3435 */           } else if (this.annotationPaths != null) {
/* 3436 */             annotationPathProvider = (qualifiedTypeName -> {
/*      */                 String eeaFileName = String.valueOf('/') + qualifiedTypeName.replace('.', '/') + ".eea";
/*      */                 for (String annotationPath : this.annotationPaths) {
/*      */                   if ((new File(String.valueOf(annotationPath) + eeaFileName)).exists())
/*      */                     return annotationPath; 
/*      */                 } 
/*      */                 return null;
/*      */               });
/*      */           } 
/* 3445 */           units[i] = new CompilationUnit(null, fileName, encoding, this.destinationPaths[i], 
/* 3446 */               shouldIgnoreOptionalProblems(this.ignoreOptionalProblemsFromFolders, fileName.toCharArray()), 
/* 3447 */               this.modNames[i], annotationPathProvider);
/*      */         } 
/*      */       } 
/*      */     } 
/* 3451 */     return units;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public IErrorHandlingPolicy getHandlingPolicy() {
/* 3460 */     return new IErrorHandlingPolicy()
/*      */       {
/*      */         public boolean proceedOnErrors() {
/* 3463 */           return Main.this.proceedOnError;
/*      */         }
/*      */         
/*      */         public boolean stopOnFirstError() {
/* 3467 */           return false;
/*      */         }
/*      */         
/*      */         public boolean ignoreAllErrors() {
/* 3471 */           return false;
/*      */         }
/*      */       };
/*      */   }
/*      */   private void setJavaHome(String javaHome) {
/* 3476 */     File release = new File(javaHome, "release");
/* 3477 */     Properties prop = new Properties(); try {
/* 3478 */       Exception exception2, exception1 = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     }
/* 3485 */     catch (IOException iOException) {
/* 3486 */       throw new IllegalArgumentException(bind("configure.invalidSystem", javaHome));
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public File getJavaHome() {
/* 3493 */     if (!this.javaHomeChecked) {
/* 3494 */       this.javaHomeChecked = true;
/* 3495 */       this.javaHomeCache = Util.getJavaHome();
/*      */     } 
/* 3497 */     return this.javaHomeCache;
/*      */   }
/*      */   
/*      */   public FileSystem getLibraryAccess() {
/* 3501 */     FileSystem nameEnvironment = new FileSystem(this.checkedClasspaths, this.filenames, (
/* 3502 */         this.annotationsFromClasspath && "enabled".equals(this.options.get("org.eclipse.jdt.core.compiler.annotation.nullanalysis"))), 
/* 3503 */         this.limitedModules);
/* 3504 */     nameEnvironment.module = this.module;
/* 3505 */     processAddonModuleOptions(nameEnvironment);
/* 3506 */     return nameEnvironment;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public IProblemFactory getProblemFactory() {
/* 3513 */     return (IProblemFactory)new DefaultProblemFactory(this.compilerLocale);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected ArrayList<FileSystem.Classpath> handleBootclasspath(ArrayList<String> bootclasspaths, String customEncoding) {
/* 3521 */     ArrayList<FileSystem.Classpath> result = new ArrayList<>(4); int bootclasspathsSize;
/* 3522 */     if (bootclasspaths != null && (
/* 3523 */       bootclasspathsSize = bootclasspaths.size()) != 0) {
/* 3524 */       result = new ArrayList<>(bootclasspathsSize);
/* 3525 */       for (String path : bootclasspaths) {
/* 3526 */         processPathEntries(4, result, path, customEncoding, false, true);
/*      */       }
/*      */     } else {
/*      */       try {
/* 3530 */         Util.collectVMBootclasspath(result, this.javaHomeCache);
/* 3531 */       } catch (IllegalStateException illegalStateException) {
/* 3532 */         throw new IllegalArgumentException(bind("configure.invalidSystem", this.javaHomeCache.toString()));
/*      */       } 
/*      */     } 
/* 3535 */     return result;
/*      */   }
/*      */   private void processAddonModuleOptions(FileSystem env) {
/* 3538 */     Map<String, IModule.IPackageExport[]> exports = (Map)new HashMap<>();
/* 3539 */     for (String option : this.addonExports) {
/* 3540 */       ModuleFinder.AddExport addExport = ModuleFinder.extractAddonExport(option);
/* 3541 */       if (addExport != null) {
/* 3542 */         String modName = addExport.sourceModuleName; byte b; int i; FileSystem.Classpath[] arrayOfClasspath;
/* 3543 */         for (i = (arrayOfClasspath = this.checkedClasspaths).length, b = 0; b < i; ) { FileSystem.Classpath classpath = arrayOfClasspath[b];
/* 3544 */           if (classpath.forbidsExportFrom(modName))
/* 3545 */             throw new IllegalArgumentException(bind("configure.illegalExportFromSystemModule", modName)); 
/*      */           b++; }
/*      */         
/* 3548 */         IModule.IPackageExport export = addExport.export;
/* 3549 */         IModule.IPackageExport[] existing = exports.get(modName);
/* 3550 */         if (existing == null) {
/* 3551 */           existing = new IModule.IPackageExport[1];
/* 3552 */           existing[0] = export;
/* 3553 */           exports.put(modName, existing);
/*      */         } else {
/* 3555 */           byte b1; int j; IModule.IPackageExport[] arrayOfIPackageExport1; for (j = (arrayOfIPackageExport1 = existing).length, b1 = 0; b1 < j; ) { IModule.IPackageExport iPackageExport = arrayOfIPackageExport1[b1];
/* 3556 */             if (CharOperation.equals(iPackageExport.name(), export.name()))
/* 3557 */               throw new IllegalArgumentException(bind("configure.duplicateExport")); 
/*      */             b1++; }
/*      */           
/* 3560 */           IModule.IPackageExport[] updated = new IModule.IPackageExport[existing.length + 1];
/* 3561 */           System.arraycopy(existing, 0, updated, 0, existing.length);
/* 3562 */           updated[existing.length] = export;
/* 3563 */           exports.put(modName, updated);
/*      */         } 
/* 3565 */         env.addModuleUpdate(modName, m -> m.addExports(paramIPackageExport.name(), paramIPackageExport.targets()), IUpdatableModule.UpdateKind.PACKAGE); continue;
/*      */       } 
/* 3567 */       throw new IllegalArgumentException(bind("configure.invalidModuleOption", "--add-exports " + option));
/*      */     } 
/*      */     
/* 3570 */     for (String option : this.addonReads) {
/* 3571 */       String[] result = ModuleFinder.extractAddonRead(option);
/* 3572 */       if (result != null && result.length == 2) {
/* 3573 */         env.addModuleUpdate(result[0], m -> m.addReads(paramArrayOfString[1].toCharArray()), IUpdatableModule.UpdateKind.MODULE); continue;
/*      */       } 
/* 3575 */       throw new IllegalArgumentException(bind("configure.invalidModuleOption", "--add-reads " + option));
/*      */     } 
/*      */   }
/*      */   
/*      */   protected ArrayList<FileSystem.Classpath> handleModulepath(String arg) {
/* 3580 */     ArrayList<String> modulePaths = processModulePathEntries(arg);
/* 3581 */     ArrayList<FileSystem.Classpath> result = new ArrayList<>();
/* 3582 */     if (modulePaths != null && modulePaths.size() > 0) {
/* 3583 */       for (String path : modulePaths) {
/* 3584 */         File file = new File(path);
/* 3585 */         if (file.isDirectory()) {
/* 3586 */           result.addAll(
/* 3587 */               ModuleFinder.findModules(file, null, getNewParser(), this.options, true, this.releaseVersion)); continue;
/*      */         } 
/* 3589 */         FileSystem.Classpath modulePath = ModuleFinder.findModule(file, null, getNewParser(), this.options, true, this.releaseVersion);
/* 3590 */         if (modulePath != null) {
/* 3591 */           result.add(modulePath);
/*      */         }
/*      */       } 
/*      */     }
/*      */     
/* 3596 */     return result;
/*      */   }
/*      */   protected ArrayList<FileSystem.Classpath> handleModuleSourcepath(String arg) {
/* 3599 */     ArrayList<String> modulePaths = processModulePathEntries(arg);
/* 3600 */     ArrayList<FileSystem.Classpath> result = new ArrayList<>();
/* 3601 */     if (modulePaths != null && 
/* 3602 */       modulePaths.size() != 0) {
/* 3603 */       if (this.destinationPath == null) {
/* 3604 */         addPendingErrors(bind("configure.missingDestinationPath"));
/*      */       }
/* 3606 */       String[] paths = new String[modulePaths.size()];
/* 3607 */       modulePaths.toArray(paths);
/* 3608 */       for (int i = 0; i < paths.length; i++) {
/* 3609 */         File dir = new File(paths[i]);
/* 3610 */         if (dir.isDirectory()) {
/*      */ 
/*      */ 
/*      */           
/* 3614 */           List<FileSystem.Classpath> modules = ModuleFinder.findModules(dir, this.destinationPath, getNewParser(), this.options, false, this.releaseVersion);
/* 3615 */           for (FileSystem.Classpath classpath : modules) {
/* 3616 */             result.add(classpath);
/* 3617 */             Path modLocation = Paths.get(classpath.getPath(), new String[0]).toAbsolutePath();
/* 3618 */             String destPath = classpath.getDestinationPath();
/* 3619 */             IModule mod = classpath.getModule();
/* 3620 */             String moduleName = (mod == null) ? null : new String(mod.name());
/* 3621 */             for (int k = 0; k < this.filenames.length; k++) {
/*      */ 
/*      */               
/*      */               try {
/*      */                 
/* 3626 */                 Path filePath = (new File(this.filenames[k])).getCanonicalFile().toPath();
/* 3627 */                 if (filePath.startsWith(modLocation)) {
/* 3628 */                   this.modNames[k] = moduleName;
/* 3629 */                   this.destinationPaths[k] = destPath;
/*      */                 } 
/* 3631 */               } catch (IOException iOException) {
/*      */ 
/*      */                 
/* 3634 */                 this.modNames[k] = "";
/*      */               } 
/*      */             } 
/*      */           } 
/*      */         } 
/*      */       } 
/* 3640 */       for (int j = 0; j < this.filenames.length; j++) {
/* 3641 */         if (this.modNames[j] == null) {
/* 3642 */           throw new IllegalArgumentException(bind("configure.notOnModuleSourcePath", new String[] { this.filenames[j] }));
/*      */         }
/*      */       } 
/*      */     } 
/* 3646 */     return result;
/*      */   }
/*      */   private void handleSingleModuleCompilation() {
/* 3649 */     if (this.filenames == null) {
/*      */       return;
/*      */     }
/* 3652 */     IModule singleMod = null; byte b; int i; String[] arrayOfString;
/* 3653 */     for (i = (arrayOfString = this.filenames).length, b = 0; b < i; ) { String filename = arrayOfString[b];
/* 3654 */       IModule mod = extractModuleDesc(filename);
/* 3655 */       if (mod != null)
/* 3656 */         if (singleMod == null) {
/* 3657 */           singleMod = mod;
/*      */         } else {
/* 3659 */           addPendingErrors(bind("configure.duplicateModuleInfo", filename));
/*      */         }  
/*      */       b++; }
/*      */     
/* 3663 */     if (singleMod != null) {
/* 3664 */       String moduleName = new String(singleMod.name());
/* 3665 */       for (int j = 0; j < this.modNames.length; j++) {
/* 3666 */         this.modNames[j] = moduleName;
/*      */       }
/* 3668 */       this.module = singleMod;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected ArrayList<FileSystem.Classpath> handleClasspath(ArrayList<String> classpaths, String customEncoding) {
/* 3675 */     ArrayList<FileSystem.Classpath> initial = new ArrayList<>(4);
/* 3676 */     if (classpaths != null && classpaths.size() > 0) {
/* 3677 */       for (String path : classpaths) {
/* 3678 */         processPathEntries(4, initial, path, customEncoding, false, true);
/*      */       }
/*      */     } else {
/*      */       
/* 3682 */       String classProp = System.getProperty("java.class.path");
/* 3683 */       if (classProp == null || classProp.length() == 0) {
/* 3684 */         addPendingErrors(bind("configure.noClasspath"));
/* 3685 */         FileSystem.Classpath classpath = FileSystem.getClasspath(System.getProperty("user.dir"), customEncoding, null, this.options, this.releaseVersion);
/* 3686 */         if (classpath != null) {
/* 3687 */           initial.add(classpath);
/*      */         }
/*      */       } else {
/* 3690 */         StringTokenizer tokenizer = new StringTokenizer(classProp, File.pathSeparator);
/*      */         
/* 3692 */         while (tokenizer.hasMoreTokens()) {
/* 3693 */           String token = tokenizer.nextToken();
/* 3694 */           FileSystem.Classpath currentClasspath = 
/* 3695 */             FileSystem.getClasspath(token, customEncoding, null, this.options, this.releaseVersion);
/* 3696 */           if (currentClasspath != null) {
/* 3697 */             initial.add(currentClasspath); continue;
/* 3698 */           }  if (token.length() != 0) {
/* 3699 */             addPendingErrors(bind("configure.incorrectClasspath", token));
/*      */           }
/*      */         } 
/*      */       } 
/*      */     } 
/* 3704 */     ArrayList<FileSystem.Classpath> result = new ArrayList<>();
/* 3705 */     HashMap<String, FileSystem.Classpath> knownNames = new HashMap<>();
/* 3706 */     FileSystem.ClasspathSectionProblemReporter problemReporter = 
/* 3707 */       new FileSystem.ClasspathSectionProblemReporter()
/*      */       {
/*      */         public void invalidClasspathSection(String jarFilePath) {
/* 3710 */           Main.this.addPendingErrors(Main.this.bind("configure.invalidClasspathSection", jarFilePath));
/*      */         }
/*      */         
/*      */         public void multipleClasspathSections(String jarFilePath) {
/* 3714 */           Main.this.addPendingErrors(Main.this.bind("configure.multipleClasspathSections", jarFilePath));
/*      */         }
/*      */       };
/* 3717 */     while (!initial.isEmpty()) {
/* 3718 */       FileSystem.Classpath current = initial.remove(0);
/* 3719 */       String currentPath = current.getPath();
/* 3720 */       if (knownNames.get(currentPath) == null) {
/* 3721 */         knownNames.put(currentPath, current);
/* 3722 */         result.add(current);
/* 3723 */         List<FileSystem.Classpath> linkedJars = current.fetchLinkedJars(problemReporter);
/* 3724 */         if (linkedJars != null) {
/* 3725 */           initial.addAll(0, linkedJars);
/*      */         }
/*      */       } 
/*      */     } 
/* 3729 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected ArrayList<FileSystem.Classpath> handleEndorseddirs(ArrayList<String> endorsedDirClasspaths) {
/* 3735 */     File javaHome = getJavaHome();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 3742 */     if (endorsedDirClasspaths == null) {
/* 3743 */       endorsedDirClasspaths = new ArrayList<>(4);
/* 3744 */       String endorsedDirsStr = System.getProperty("java.endorsed.dirs");
/* 3745 */       if (endorsedDirsStr == null) {
/* 3746 */         if (javaHome != null) {
/* 3747 */           endorsedDirClasspaths.add(String.valueOf(javaHome.getAbsolutePath()) + "/lib/endorsed");
/*      */         }
/*      */       } else {
/* 3750 */         StringTokenizer tokenizer = new StringTokenizer(endorsedDirsStr, File.pathSeparator);
/* 3751 */         while (tokenizer.hasMoreTokens()) {
/* 3752 */           endorsedDirClasspaths.add(tokenizer.nextToken());
/*      */         }
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 3761 */     if (endorsedDirClasspaths.size() != 0) {
/* 3762 */       ArrayList<FileSystem.Classpath> result = new ArrayList<>();
/* 3763 */       File[] directoriesToCheck = new File[endorsedDirClasspaths.size()];
/* 3764 */       for (int i = 0; i < directoriesToCheck.length; i++)
/* 3765 */         directoriesToCheck[i] = new File(endorsedDirClasspaths.get(i)); 
/* 3766 */       File[][] endorsedDirsJars = getLibrariesFiles(directoriesToCheck);
/* 3767 */       if (endorsedDirsJars != null) {
/* 3768 */         for (int j = 0, max = endorsedDirsJars.length; j < max; j++) {
/* 3769 */           File[] current = endorsedDirsJars[j];
/* 3770 */           if (current != null) {
/* 3771 */             for (int k = 0, max2 = current.length; k < max2; k++) {
/* 3772 */               FileSystem.Classpath classpath = 
/* 3773 */                 FileSystem.getClasspath(
/* 3774 */                   current[k].getAbsolutePath(), 
/* 3775 */                   null, null, this.options, this.releaseVersion);
/* 3776 */               if (classpath != null) {
/* 3777 */                 result.add(classpath);
/*      */               }
/*      */             } 
/* 3780 */           } else if (directoriesToCheck[j].isFile()) {
/* 3781 */             addPendingErrors(
/* 3782 */                 bind(
/* 3783 */                   "configure.incorrectEndorsedDirsEntry", 
/* 3784 */                   directoriesToCheck[j].getAbsolutePath()));
/*      */           } 
/*      */         } 
/*      */       }
/* 3788 */       return result;
/*      */     } 
/* 3790 */     return FileSystem.EMPTY_CLASSPATH;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected ArrayList<FileSystem.Classpath> handleExtdirs(ArrayList<String> extdirsClasspaths) {
/* 3798 */     File javaHome = getJavaHome();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 3806 */     if (extdirsClasspaths == null) {
/* 3807 */       extdirsClasspaths = new ArrayList<>(4);
/* 3808 */       String extdirsStr = System.getProperty("java.ext.dirs");
/* 3809 */       if (extdirsStr == null) {
/* 3810 */         extdirsClasspaths.add(String.valueOf(javaHome.getAbsolutePath()) + "/lib/ext");
/*      */       } else {
/* 3812 */         StringTokenizer tokenizer = new StringTokenizer(extdirsStr, File.pathSeparator);
/* 3813 */         while (tokenizer.hasMoreTokens()) {
/* 3814 */           extdirsClasspaths.add(tokenizer.nextToken());
/*      */         }
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 3822 */     if (extdirsClasspaths.size() != 0) {
/* 3823 */       ArrayList<FileSystem.Classpath> result = new ArrayList<>();
/* 3824 */       File[] directoriesToCheck = new File[extdirsClasspaths.size()];
/* 3825 */       for (int i = 0; i < directoriesToCheck.length; i++)
/* 3826 */         directoriesToCheck[i] = new File(extdirsClasspaths.get(i)); 
/* 3827 */       File[][] extdirsJars = getLibrariesFiles(directoriesToCheck);
/* 3828 */       if (extdirsJars != null) {
/* 3829 */         for (int j = 0, max = extdirsJars.length; j < max; j++) {
/* 3830 */           File[] current = extdirsJars[j];
/* 3831 */           if (current != null) {
/* 3832 */             for (int k = 0, max2 = current.length; k < max2; k++) {
/* 3833 */               FileSystem.Classpath classpath = 
/* 3834 */                 FileSystem.getClasspath(
/* 3835 */                   current[k].getAbsolutePath(), 
/* 3836 */                   null, null, this.options, this.releaseVersion);
/* 3837 */               if (classpath != null) {
/* 3838 */                 result.add(classpath);
/*      */               }
/*      */             } 
/* 3841 */           } else if (directoriesToCheck[j].isFile()) {
/* 3842 */             addPendingErrors(bind(
/* 3843 */                   "configure.incorrectExtDirsEntry", 
/* 3844 */                   directoriesToCheck[j].getAbsolutePath()));
/*      */           } 
/*      */         } 
/*      */       }
/* 3848 */       return result;
/*      */     } 
/*      */     
/* 3851 */     return FileSystem.EMPTY_CLASSPATH;
/*      */   }
/*      */   
/*      */   protected boolean isIgnored(IProblem problem) {
/* 3855 */     if (problem == null) {
/* 3856 */       return true;
/*      */     }
/* 3858 */     if (problem.isError()) {
/* 3859 */       return false;
/*      */     }
/* 3861 */     String key = problem.isInfo() ? "info" : "warning";
/* 3862 */     if ("ignore".equals(this.options.get(key))) {
/* 3863 */       return true;
/*      */     }
/* 3865 */     if (this.ignoreOptionalProblemsFromFolders != null) {
/* 3866 */       char[] fileName = problem.getOriginatingFileName();
/* 3867 */       if (fileName != null) {
/* 3868 */         return shouldIgnoreOptionalProblems(this.ignoreOptionalProblemsFromFolders, fileName);
/*      */       }
/*      */     } 
/* 3871 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void handleInfoToken(String token, boolean isEnabling) {
/* 3879 */     handleErrorOrWarningToken(token, isEnabling, 1024);
/*      */   }
/*      */   protected void handleWarningToken(String token, boolean isEnabling) {
/* 3882 */     handleErrorOrWarningToken(token, isEnabling, 0);
/*      */   }
/*      */   protected void handleErrorToken(String token, boolean isEnabling) {
/* 3885 */     handleErrorOrWarningToken(token, isEnabling, 1);
/*      */   }
/*      */   private void setSeverity(String compilerOptions, int severity, boolean isEnabling) {
/* 3888 */     if (isEnabling) {
/* 3889 */       switch (severity) {
/*      */         case 1:
/* 3891 */           this.options.put(compilerOptions, "error");
/*      */           return;
/*      */         case 0:
/* 3894 */           this.options.put(compilerOptions, "warning");
/*      */           return;
/*      */         case 1024:
/* 3897 */           this.options.put(compilerOptions, "info");
/*      */           return;
/*      */       } 
/* 3900 */       this.options.put(compilerOptions, "ignore");
/*      */     } else {
/*      */       String currentValue;
/* 3903 */       switch (severity) {
/*      */         case 1:
/* 3905 */           currentValue = this.options.get(compilerOptions);
/* 3906 */           if ("error".equals(currentValue)) {
/* 3907 */             this.options.put(compilerOptions, "ignore");
/*      */           }
/*      */           return;
/*      */         case 0:
/* 3911 */           currentValue = this.options.get(compilerOptions);
/* 3912 */           if ("warning".equals(currentValue)) {
/* 3913 */             this.options.put(compilerOptions, "ignore");
/*      */           }
/*      */           return;
/*      */         case 1024:
/* 3917 */           currentValue = this.options.get(compilerOptions);
/* 3918 */           if ("info".equals(currentValue)) {
/* 3919 */             this.options.put(compilerOptions, "ignore");
/*      */           }
/*      */           return;
/*      */       } 
/* 3923 */       this.options.put(compilerOptions, "ignore");
/*      */     } 
/*      */   }
/*      */   
/*      */   private void handleErrorOrWarningToken(String token, boolean isEnabling, int severity) {
/* 3928 */     if (token.length() == 0)
/* 3929 */       return;  switch (token.charAt(0)) {
/*      */       case 'a':
/* 3931 */         if (token.equals("allDeprecation")) {
/* 3932 */           setSeverity("org.eclipse.jdt.core.compiler.problem.deprecation", severity, isEnabling);
/* 3933 */           setSeverity("org.eclipse.jdt.core.compiler.problem.terminalDeprecation", severity, isEnabling);
/* 3934 */           this.options.put(
/* 3935 */               "org.eclipse.jdt.core.compiler.problem.deprecationInDeprecatedCode", 
/* 3936 */               isEnabling ? "enabled" : "disabled");
/* 3937 */           this.options.put(
/* 3938 */               "org.eclipse.jdt.core.compiler.problem.deprecationWhenOverridingDeprecatedMethod", 
/* 3939 */               isEnabling ? "enabled" : "disabled"); return;
/*      */         } 
/* 3941 */         if (token.equals("allJavadoc")) {
/* 3942 */           this.warnAllJavadocOn = this.warnJavadocOn = isEnabling;
/* 3943 */           setSeverity("org.eclipse.jdt.core.compiler.problem.invalidJavadoc", severity, isEnabling);
/* 3944 */           setSeverity("org.eclipse.jdt.core.compiler.problem.missingJavadocTags", severity, isEnabling);
/* 3945 */           setSeverity("org.eclipse.jdt.core.compiler.problem.missingJavadocComments", severity, isEnabling); return;
/*      */         } 
/* 3947 */         if (token.equals("assertIdentifier")) {
/* 3948 */           setSeverity("org.eclipse.jdt.core.compiler.problem.assertIdentifier", severity, isEnabling); return;
/*      */         } 
/* 3950 */         if (token.equals("allDeadCode")) {
/* 3951 */           setSeverity("org.eclipse.jdt.core.compiler.problem.deadCode", severity, isEnabling);
/* 3952 */           this.options.put(
/* 3953 */               "org.eclipse.jdt.core.compiler.problem.deadCodeInTrivialIfStatement", 
/* 3954 */               isEnabling ? "enabled" : "disabled"); return;
/*      */         } 
/* 3956 */         if (token.equals("allOver-ann")) {
/* 3957 */           setSeverity("org.eclipse.jdt.core.compiler.problem.missingOverrideAnnotation", severity, isEnabling);
/* 3958 */           this.options.put(
/* 3959 */               "org.eclipse.jdt.core.compiler.problem.missingOverrideAnnotationForInterfaceMethodImplementation", 
/* 3960 */               isEnabling ? "enabled" : "disabled"); return;
/*      */         } 
/* 3962 */         if (token.equals("all-static-method")) {
/* 3963 */           setSeverity("org.eclipse.jdt.core.compiler.problem.reportMethodCanBeStatic", severity, isEnabling);
/* 3964 */           setSeverity("org.eclipse.jdt.core.compiler.problem.reportMethodCanBePotentiallyStatic", severity, isEnabling); return;
/*      */         } 
/* 3966 */         if (token.equals("all")) {
/* 3967 */           if (isEnabling) {
/* 3968 */             enableAll(severity);
/*      */           } else {
/* 3970 */             disableAll(severity);
/*      */           } 
/*      */           return;
/*      */         } 
/*      */         break;
/*      */       case 'b':
/* 3976 */         if (token.equals("boxing")) {
/* 3977 */           setSeverity("org.eclipse.jdt.core.compiler.problem.autoboxing", severity, isEnabling);
/*      */           return;
/*      */         } 
/*      */         break;
/*      */       case 'c':
/* 3982 */         if (token.equals("constructorName")) {
/* 3983 */           setSeverity("org.eclipse.jdt.core.compiler.problem.methodWithConstructorName", severity, isEnabling); return;
/*      */         } 
/* 3985 */         if (token.equals("conditionAssign")) {
/* 3986 */           setSeverity("org.eclipse.jdt.core.compiler.problem.possibleAccidentalBooleanAssignment", severity, isEnabling); return;
/*      */         } 
/* 3988 */         if (token.equals("compareIdentical")) {
/* 3989 */           setSeverity("org.eclipse.jdt.core.compiler.problem.comparingIdentical", severity, isEnabling); return;
/*      */         } 
/* 3991 */         if (token.equals("charConcat")) {
/* 3992 */           setSeverity("org.eclipse.jdt.core.compiler.problem.noImplicitStringConversion", severity, isEnabling);
/*      */           return;
/*      */         } 
/*      */         break;
/*      */       case 'd':
/* 3997 */         if (token.equals("deprecation")) {
/* 3998 */           setSeverity("org.eclipse.jdt.core.compiler.problem.deprecation", severity, isEnabling);
/* 3999 */           this.options.put(
/* 4000 */               "org.eclipse.jdt.core.compiler.problem.deprecationInDeprecatedCode", 
/* 4001 */               "disabled");
/* 4002 */           this.options.put(
/* 4003 */               "org.eclipse.jdt.core.compiler.problem.deprecationWhenOverridingDeprecatedMethod", 
/* 4004 */               "disabled"); return;
/*      */         } 
/* 4006 */         if (token.equals("dep-ann")) {
/* 4007 */           setSeverity("org.eclipse.jdt.core.compiler.problem.missingDeprecatedAnnotation", severity, isEnabling); return;
/*      */         } 
/* 4009 */         if (token.equals("discouraged")) {
/* 4010 */           setSeverity("org.eclipse.jdt.core.compiler.problem.discouragedReference", severity, isEnabling); return;
/*      */         } 
/* 4012 */         if (token.equals("deadCode")) {
/* 4013 */           setSeverity("org.eclipse.jdt.core.compiler.problem.deadCode", severity, isEnabling);
/* 4014 */           this.options.put(
/* 4015 */               "org.eclipse.jdt.core.compiler.problem.deadCodeInTrivialIfStatement", 
/* 4016 */               "disabled");
/*      */           return;
/*      */         } 
/*      */         break;
/*      */       case 'e':
/* 4021 */         if (token.equals("enumSwitch")) {
/* 4022 */           setSeverity("org.eclipse.jdt.core.compiler.problem.incompleteEnumSwitch", severity, isEnabling); return;
/*      */         } 
/* 4024 */         if (token.equals("enumSwitchPedantic")) {
/* 4025 */           if (isEnabling) {
/* 4026 */             switch (severity) {
/*      */               case 1:
/* 4028 */                 setSeverity("org.eclipse.jdt.core.compiler.problem.incompleteEnumSwitch", severity, isEnabling);
/*      */                 break;
/*      */               case 0:
/* 4031 */                 if ("ignore".equals(this.options.get("org.eclipse.jdt.core.compiler.problem.incompleteEnumSwitch"))) {
/* 4032 */                   setSeverity("org.eclipse.jdt.core.compiler.problem.incompleteEnumSwitch", severity, isEnabling);
/*      */                 }
/*      */                 break;
/*      */             } 
/*      */           
/*      */           }
/* 4038 */           this.options.put("org.eclipse.jdt.core.compiler.problem.missingEnumCaseDespiteDefault", 
/* 4039 */               isEnabling ? "enabled" : "disabled"); return;
/*      */         } 
/* 4041 */         if (token.equals("emptyBlock")) {
/* 4042 */           setSeverity("org.eclipse.jdt.core.compiler.problem.undocumentedEmptyBlock", severity, isEnabling); return;
/*      */         } 
/* 4044 */         if (token.equals("enumIdentifier")) {
/* 4045 */           setSeverity("org.eclipse.jdt.core.compiler.problem.enumIdentifier", severity, isEnabling); return;
/*      */         } 
/* 4047 */         if (token.equals("exports")) {
/* 4048 */           setSeverity("org.eclipse.jdt.core.compiler.problem.APILeak", severity, isEnabling);
/*      */           return;
/*      */         } 
/*      */         break;
/*      */       case 'f':
/* 4053 */         if (token.equals("fieldHiding")) {
/* 4054 */           setSeverity("org.eclipse.jdt.core.compiler.problem.fieldHiding", severity, isEnabling); return;
/*      */         } 
/* 4056 */         if (token.equals("finalBound")) {
/* 4057 */           setSeverity("org.eclipse.jdt.core.compiler.problem.finalParameterBound", severity, isEnabling); return;
/*      */         } 
/* 4059 */         if (token.equals("finally")) {
/* 4060 */           setSeverity("org.eclipse.jdt.core.compiler.problem.finallyBlockNotCompletingNormally", severity, isEnabling); return;
/*      */         } 
/* 4062 */         if (token.equals("forbidden")) {
/* 4063 */           setSeverity("org.eclipse.jdt.core.compiler.problem.forbiddenReference", severity, isEnabling); return;
/*      */         } 
/* 4065 */         if (token.equals("fallthrough")) {
/* 4066 */           setSeverity("org.eclipse.jdt.core.compiler.problem.fallthroughCase", severity, isEnabling);
/*      */           return;
/*      */         } 
/*      */         break;
/*      */       case 'h':
/* 4071 */         if (token.equals("hiding")) {
/* 4072 */           setSeverity("org.eclipse.jdt.core.compiler.problem.hiddenCatchBlock", severity, isEnabling);
/* 4073 */           setSeverity("org.eclipse.jdt.core.compiler.problem.localVariableHiding", severity, isEnabling);
/* 4074 */           setSeverity("org.eclipse.jdt.core.compiler.problem.fieldHiding", severity, isEnabling);
/* 4075 */           setSeverity("org.eclipse.jdt.core.compiler.problem.typeParameterHiding", severity, isEnabling); return;
/*      */         } 
/* 4077 */         if (token.equals("hashCode")) {
/* 4078 */           setSeverity("org.eclipse.jdt.core.compiler.problem.missingHashCodeMethod", severity, isEnabling);
/*      */           return;
/*      */         } 
/*      */         break;
/*      */       case 'i':
/* 4083 */         if (token.equals("indirectStatic")) {
/* 4084 */           setSeverity("org.eclipse.jdt.core.compiler.problem.indirectStaticAccess", severity, isEnabling); return;
/*      */         } 
/* 4086 */         if (token.equals("inheritNullAnnot")) {
/* 4087 */           this.options.put(
/* 4088 */               "org.eclipse.jdt.core.compiler.annotation.inheritNullAnnotations", 
/* 4089 */               isEnabling ? "enabled" : "disabled"); return;
/*      */         } 
/* 4091 */         if (token.equals("intfNonInherited") || token.equals("interfaceNonInherited")) {
/* 4092 */           setSeverity("org.eclipse.jdt.core.compiler.problem.incompatibleNonInheritedInterfaceMethod", severity, isEnabling); return;
/*      */         } 
/* 4094 */         if (token.equals("intfAnnotation")) {
/* 4095 */           setSeverity("org.eclipse.jdt.core.compiler.problem.annotationSuperInterface", severity, isEnabling); return;
/*      */         } 
/* 4097 */         if (token.equals("intfRedundant")) {
/* 4098 */           setSeverity("org.eclipse.jdt.core.compiler.problem.redundantSuperinterface", severity, isEnabling); return;
/*      */         } 
/* 4100 */         if (token.equals("includeAssertNull")) {
/* 4101 */           this.options.put(
/* 4102 */               "org.eclipse.jdt.core.compiler.problem.includeNullInfoFromAsserts", 
/* 4103 */               isEnabling ? "enabled" : "disabled"); return;
/*      */         } 
/* 4105 */         if (token.equals("invalidJavadoc")) {
/* 4106 */           setSeverity("org.eclipse.jdt.core.compiler.problem.invalidJavadoc", severity, isEnabling);
/* 4107 */           this.options.put(
/* 4108 */               "org.eclipse.jdt.core.compiler.problem.invalidJavadocTags", 
/* 4109 */               isEnabling ? "enabled" : "disabled");
/* 4110 */           this.options.put(
/* 4111 */               "org.eclipse.jdt.core.compiler.problem.invalidJavadocTagsDeprecatedRef", 
/* 4112 */               isEnabling ? "enabled" : "disabled");
/* 4113 */           this.options.put(
/* 4114 */               "org.eclipse.jdt.core.compiler.problem.invalidJavadocTagsNotVisibleRef", 
/* 4115 */               isEnabling ? "enabled" : "disabled");
/* 4116 */           if (isEnabling) {
/* 4117 */             this.options.put(
/* 4118 */                 "org.eclipse.jdt.core.compiler.doc.comment.support", 
/* 4119 */                 "enabled");
/* 4120 */             this.options.put(
/* 4121 */                 "org.eclipse.jdt.core.compiler.problem.invalidJavadocTagsVisibility", 
/* 4122 */                 "private");
/*      */           }  return;
/*      */         } 
/* 4125 */         if (token.equals("invalidJavadocTag")) {
/* 4126 */           this.options.put(
/* 4127 */               "org.eclipse.jdt.core.compiler.problem.invalidJavadocTags", 
/* 4128 */               isEnabling ? "enabled" : "disabled"); return;
/*      */         } 
/* 4130 */         if (token.equals("invalidJavadocTagDep")) {
/* 4131 */           this.options.put(
/* 4132 */               "org.eclipse.jdt.core.compiler.problem.invalidJavadocTagsDeprecatedRef", 
/* 4133 */               isEnabling ? "enabled" : "disabled"); return;
/*      */         } 
/* 4135 */         if (token.equals("invalidJavadocTagNotVisible")) {
/* 4136 */           this.options.put(
/* 4137 */               "org.eclipse.jdt.core.compiler.problem.invalidJavadocTagsNotVisibleRef", 
/* 4138 */               isEnabling ? "enabled" : "disabled"); return;
/*      */         } 
/* 4140 */         if (token.startsWith("invalidJavadocTagVisibility")) {
/* 4141 */           int start = token.indexOf('(');
/* 4142 */           int end = token.indexOf(')');
/* 4143 */           String visibility = null;
/* 4144 */           if (isEnabling && start >= 0 && end >= 0 && start < end) {
/* 4145 */             visibility = token.substring(start + 1, end).trim();
/*      */           }
/* 4147 */           if ((visibility != null && visibility.equals("public")) || 
/* 4148 */             visibility.equals("private") || 
/* 4149 */             visibility.equals("protected") || 
/* 4150 */             visibility.equals("default")) {
/* 4151 */             this.options.put(
/* 4152 */                 "org.eclipse.jdt.core.compiler.problem.invalidJavadocTagsVisibility", 
/* 4153 */                 visibility);
/*      */             return;
/*      */           } 
/* 4156 */           throw new IllegalArgumentException(bind("configure.invalidJavadocTagVisibility", token));
/*      */         } 
/*      */         break;
/*      */       
/*      */       case 'j':
/* 4161 */         if (token.equals("javadoc")) {
/* 4162 */           this.warnJavadocOn = isEnabling;
/* 4163 */           setSeverity("org.eclipse.jdt.core.compiler.problem.invalidJavadoc", severity, isEnabling);
/* 4164 */           setSeverity("org.eclipse.jdt.core.compiler.problem.missingJavadocTags", severity, isEnabling);
/*      */           return;
/*      */         } 
/*      */         break;
/*      */       case 'l':
/* 4169 */         if (token.equals("localHiding")) {
/* 4170 */           setSeverity("org.eclipse.jdt.core.compiler.problem.localVariableHiding", severity, isEnabling);
/*      */           return;
/*      */         } 
/*      */         break;
/*      */       case 'm':
/* 4175 */         if (token.equals("maskedCatchBlock") || token.equals("maskedCatchBlocks")) {
/* 4176 */           setSeverity("org.eclipse.jdt.core.compiler.problem.hiddenCatchBlock", severity, isEnabling); return;
/*      */         } 
/* 4178 */         if (token.equals("missingJavadocTags")) {
/* 4179 */           setSeverity("org.eclipse.jdt.core.compiler.problem.missingJavadocTags", severity, isEnabling);
/* 4180 */           this.options.put(
/* 4181 */               "org.eclipse.jdt.core.compiler.problem.missingJavadocTagsOverriding", 
/* 4182 */               isEnabling ? "enabled" : "disabled");
/* 4183 */           this.options.put(
/* 4184 */               "org.eclipse.jdt.core.compiler.problem.missingJavadocTagsMethodTypeParameters", 
/* 4185 */               isEnabling ? "enabled" : "disabled");
/* 4186 */           if (isEnabling) {
/* 4187 */             this.options.put(
/* 4188 */                 "org.eclipse.jdt.core.compiler.doc.comment.support", 
/* 4189 */                 "enabled");
/* 4190 */             this.options.put(
/* 4191 */                 "org.eclipse.jdt.core.compiler.problem.missingJavadocTagsVisibility", 
/* 4192 */                 "private");
/*      */           }  return;
/*      */         } 
/* 4195 */         if (token.equals("missingJavadocTagsOverriding")) {
/* 4196 */           this.options.put(
/* 4197 */               "org.eclipse.jdt.core.compiler.problem.missingJavadocTagsOverriding", 
/* 4198 */               isEnabling ? "enabled" : "disabled"); return;
/*      */         } 
/* 4200 */         if (token.equals("missingJavadocTagsMethod")) {
/* 4201 */           this.options.put(
/* 4202 */               "org.eclipse.jdt.core.compiler.problem.missingJavadocTagsMethodTypeParameters", 
/* 4203 */               isEnabling ? "enabled" : "disabled"); return;
/*      */         } 
/* 4205 */         if (token.startsWith("missingJavadocTagsVisibility")) {
/* 4206 */           int start = token.indexOf('(');
/* 4207 */           int end = token.indexOf(')');
/* 4208 */           String visibility = null;
/* 4209 */           if (isEnabling && start >= 0 && end >= 0 && start < end) {
/* 4210 */             visibility = token.substring(start + 1, end).trim();
/*      */           }
/* 4212 */           if ((visibility != null && visibility.equals("public")) || 
/* 4213 */             visibility.equals("private") || 
/* 4214 */             visibility.equals("protected") || 
/* 4215 */             visibility.equals("default")) {
/* 4216 */             this.options.put(
/* 4217 */                 "org.eclipse.jdt.core.compiler.problem.missingJavadocTagsVisibility", 
/* 4218 */                 visibility);
/*      */             return;
/*      */           } 
/* 4221 */           throw new IllegalArgumentException(bind("configure.missingJavadocTagsVisibility", token));
/*      */         } 
/* 4223 */         if (token.equals("missingJavadocComments")) {
/* 4224 */           setSeverity("org.eclipse.jdt.core.compiler.problem.missingJavadocComments", severity, isEnabling);
/* 4225 */           this.options.put(
/* 4226 */               "org.eclipse.jdt.core.compiler.problem.missingJavadocCommentsOverriding", 
/* 4227 */               isEnabling ? "enabled" : "disabled");
/* 4228 */           if (isEnabling) {
/* 4229 */             this.options.put(
/* 4230 */                 "org.eclipse.jdt.core.compiler.doc.comment.support", 
/* 4231 */                 "enabled");
/* 4232 */             this.options.put(
/* 4233 */                 "org.eclipse.jdt.core.compiler.problem.missingJavadocCommentsVisibility", 
/* 4234 */                 "private");
/*      */           }  return;
/*      */         } 
/* 4237 */         if (token.equals("missingJavadocCommentsOverriding")) {
/* 4238 */           setSeverity("org.eclipse.jdt.core.compiler.problem.missingJavadocComments", severity, isEnabling);
/* 4239 */           this.options.put(
/* 4240 */               "org.eclipse.jdt.core.compiler.problem.missingJavadocCommentsOverriding", 
/* 4241 */               isEnabling ? "enabled" : "disabled"); return;
/*      */         } 
/* 4243 */         if (token.startsWith("missingJavadocCommentsVisibility")) {
/* 4244 */           int start = token.indexOf('(');
/* 4245 */           int end = token.indexOf(')');
/* 4246 */           String visibility = null;
/* 4247 */           if (isEnabling && start >= 0 && end >= 0 && start < end) {
/* 4248 */             visibility = token.substring(start + 1, end).trim();
/*      */           }
/* 4250 */           if ((visibility != null && visibility.equals("public")) || 
/* 4251 */             visibility.equals("private") || 
/* 4252 */             visibility.equals("protected") || 
/* 4253 */             visibility.equals("default")) {
/* 4254 */             this.options.put(
/* 4255 */                 "org.eclipse.jdt.core.compiler.problem.missingJavadocCommentsVisibility", 
/* 4256 */                 visibility);
/*      */             return;
/*      */           } 
/* 4259 */           throw new IllegalArgumentException(bind("configure.missingJavadocCommentsVisibility", token));
/*      */         } 
/* 4261 */         if (token.equals("module")) {
/* 4262 */           setSeverity("org.eclipse.jdt.core.compiler.problem.unstableAutoModuleName", severity, isEnabling);
/*      */           return;
/*      */         } 
/*      */         break;
/*      */       case 'n':
/* 4267 */         if (token.equals("nls")) {
/* 4268 */           setSeverity("org.eclipse.jdt.core.compiler.problem.nonExternalizedStringLiteral", severity, isEnabling); return;
/*      */         } 
/* 4270 */         if (token.equals("noEffectAssign")) {
/* 4271 */           setSeverity("org.eclipse.jdt.core.compiler.problem.noEffectAssignment", severity, isEnabling); return;
/*      */         } 
/* 4273 */         if (token.equals("noImplicitStringConversion")) {
/* 4274 */           setSeverity("org.eclipse.jdt.core.compiler.problem.noImplicitStringConversion", severity, isEnabling); return;
/*      */         } 
/* 4276 */         if (token.equals("null")) {
/* 4277 */           setSeverity("org.eclipse.jdt.core.compiler.problem.nullReference", severity, isEnabling);
/* 4278 */           setSeverity("org.eclipse.jdt.core.compiler.problem.potentialNullReference", severity, isEnabling);
/* 4279 */           setSeverity("org.eclipse.jdt.core.compiler.problem.redundantNullCheck", severity, isEnabling); return;
/*      */         } 
/* 4281 */         if (token.equals("nullDereference")) {
/* 4282 */           setSeverity("org.eclipse.jdt.core.compiler.problem.nullReference", severity, isEnabling);
/* 4283 */           if (!isEnabling) {
/* 4284 */             setSeverity("org.eclipse.jdt.core.compiler.problem.potentialNullReference", 256, isEnabling);
/* 4285 */             setSeverity("org.eclipse.jdt.core.compiler.problem.redundantNullCheck", 256, isEnabling);
/*      */           }  return;
/*      */         } 
/* 4288 */         if (token.equals("nullAnnotConflict")) {
/* 4289 */           setSeverity("org.eclipse.jdt.core.compiler.problem.nullAnnotationInferenceConflict", severity, isEnabling); return;
/*      */         } 
/* 4291 */         if (token.equals("nullAnnotRedundant")) {
/* 4292 */           setSeverity("org.eclipse.jdt.core.compiler.problem.redundantNullAnnotation", severity, isEnabling); return;
/*      */         } 
/* 4294 */         if (token.startsWith("nullAnnot")) {
/* 4295 */           String annotationNames = Util.EMPTY_STRING;
/* 4296 */           int start = token.indexOf('(');
/* 4297 */           int end = token.indexOf(')');
/* 4298 */           String nonNullAnnotName = null, nullableAnnotName = null, nonNullByDefaultAnnotName = null;
/* 4299 */           if (isEnabling && start >= 0 && end >= 0 && start < end) {
/* 4300 */             boolean isPrimarySet = !this.primaryNullAnnotationsSeen;
/* 4301 */             annotationNames = token.substring(start + 1, end).trim();
/* 4302 */             int separator1 = annotationNames.indexOf('|');
/* 4303 */             if (separator1 == -1) throw new IllegalArgumentException(bind("configure.invalidNullAnnot", token)); 
/* 4304 */             nullableAnnotName = annotationNames.substring(0, separator1).trim();
/* 4305 */             if (isPrimarySet && nullableAnnotName.length() == 0) throw new IllegalArgumentException(bind("configure.invalidNullAnnot", token)); 
/* 4306 */             int separator2 = annotationNames.indexOf('|', separator1 + 1);
/* 4307 */             if (separator2 == -1) throw new IllegalArgumentException(bind("configure.invalidNullAnnot", token)); 
/* 4308 */             nonNullAnnotName = annotationNames.substring(separator1 + 1, separator2).trim();
/* 4309 */             if (isPrimarySet && nonNullAnnotName.length() == 0) throw new IllegalArgumentException(bind("configure.invalidNullAnnot", token)); 
/* 4310 */             nonNullByDefaultAnnotName = annotationNames.substring(separator2 + 1).trim();
/* 4311 */             if (isPrimarySet && nonNullByDefaultAnnotName.length() == 0) throw new IllegalArgumentException(bind("configure.invalidNullAnnot", token)); 
/* 4312 */             if (isPrimarySet) {
/* 4313 */               this.primaryNullAnnotationsSeen = true;
/* 4314 */               this.options.put("org.eclipse.jdt.core.compiler.annotation.nullable", nullableAnnotName);
/* 4315 */               this.options.put("org.eclipse.jdt.core.compiler.annotation.nonnull", nonNullAnnotName);
/* 4316 */               this.options.put("org.eclipse.jdt.core.compiler.annotation.nonnullbydefault", nonNullByDefaultAnnotName);
/*      */             } else {
/* 4318 */               if (nullableAnnotName.length() > 0) {
/* 4319 */                 String nullableList = this.options.get("org.eclipse.jdt.core.compiler.annotation.nullable.secondary");
/* 4320 */                 nullableList = nullableList.isEmpty() ? nullableAnnotName : (String.valueOf(nullableList) + ',' + nullableAnnotName);
/* 4321 */                 this.options.put("org.eclipse.jdt.core.compiler.annotation.nullable.secondary", nullableList);
/*      */               } 
/* 4323 */               if (nonNullAnnotName.length() > 0) {
/* 4324 */                 String nonnullList = this.options.get("org.eclipse.jdt.core.compiler.annotation.nonnull.secondary");
/* 4325 */                 nonnullList = nonnullList.isEmpty() ? nonNullAnnotName : (String.valueOf(nonnullList) + ',' + nonNullAnnotName);
/* 4326 */                 this.options.put("org.eclipse.jdt.core.compiler.annotation.nonnull.secondary", nonnullList);
/*      */               } 
/* 4328 */               if (nonNullByDefaultAnnotName.length() > 0) {
/* 4329 */                 String nnbdList = this.options.get("org.eclipse.jdt.core.compiler.annotation.nonnullbydefault.secondary");
/* 4330 */                 nnbdList = nnbdList.isEmpty() ? nonNullByDefaultAnnotName : (String.valueOf(nnbdList) + ',' + nonNullByDefaultAnnotName);
/* 4331 */                 this.options.put("org.eclipse.jdt.core.compiler.annotation.nonnullbydefault.secondary", nnbdList);
/*      */               } 
/*      */             } 
/*      */           } 
/* 4335 */           this.options.put(
/* 4336 */               "org.eclipse.jdt.core.compiler.annotation.nullanalysis", 
/* 4337 */               isEnabling ? "enabled" : "disabled");
/* 4338 */           setSeverity("org.eclipse.jdt.core.compiler.problem.nullSpecViolation", severity, isEnabling);
/* 4339 */           setSeverity("org.eclipse.jdt.core.compiler.problem.nullAnnotationInferenceConflict", severity, isEnabling);
/* 4340 */           setSeverity("org.eclipse.jdt.core.compiler.problem.nullUncheckedConversion", severity, isEnabling);
/* 4341 */           setSeverity("org.eclipse.jdt.core.compiler.problem.redundantNullAnnotation", severity, isEnabling); return;
/*      */         } 
/* 4343 */         if (token.equals("nullUncheckedConversion")) {
/* 4344 */           setSeverity("org.eclipse.jdt.core.compiler.problem.nullUncheckedConversion", severity, isEnabling); return;
/*      */         } 
/* 4346 */         if (token.equals("nonnullNotRepeated")) {
/* 4347 */           setSeverity("org.eclipse.jdt.core.compiler.problem.nonnullParameterAnnotationDropped", severity, isEnabling);
/*      */           return;
/*      */         } 
/*      */         break;
/*      */       
/*      */       case 'o':
/* 4353 */         if (token.equals("over-sync")) {
/* 4354 */           setSeverity("org.eclipse.jdt.core.compiler.problem.missingSynchronizedOnInheritedMethod", severity, isEnabling); return;
/*      */         } 
/* 4356 */         if (token.equals("over-ann")) {
/* 4357 */           setSeverity("org.eclipse.jdt.core.compiler.problem.missingOverrideAnnotation", severity, isEnabling);
/* 4358 */           this.options.put(
/* 4359 */               "org.eclipse.jdt.core.compiler.problem.missingOverrideAnnotationForInterfaceMethodImplementation", 
/* 4360 */               "disabled");
/*      */           return;
/*      */         } 
/*      */         break;
/*      */       case 'p':
/* 4365 */         if (token.equals("pkgDefaultMethod") || token.equals("packageDefaultMethod")) {
/* 4366 */           setSeverity("org.eclipse.jdt.core.compiler.problem.overridingPackageDefaultMethod", severity, isEnabling); return;
/*      */         } 
/* 4368 */         if (token.equals("paramAssign")) {
/* 4369 */           setSeverity("org.eclipse.jdt.core.compiler.problem.parameterAssignment", severity, isEnabling);
/*      */           return;
/*      */         } 
/*      */         break;
/*      */       case 'r':
/* 4374 */         if (token.equals("raw")) {
/* 4375 */           setSeverity("org.eclipse.jdt.core.compiler.problem.rawTypeReference", severity, isEnabling); return;
/*      */         } 
/* 4377 */         if (token.equals("redundantSuperinterface")) {
/* 4378 */           setSeverity("org.eclipse.jdt.core.compiler.problem.redundantSuperinterface", severity, isEnabling); return;
/*      */         } 
/* 4380 */         if (token.equals("resource")) {
/* 4381 */           setSeverity("org.eclipse.jdt.core.compiler.problem.unclosedCloseable", severity, isEnabling);
/* 4382 */           setSeverity("org.eclipse.jdt.core.compiler.problem.potentiallyUnclosedCloseable", severity, isEnabling);
/* 4383 */           setSeverity("org.eclipse.jdt.core.compiler.problem.explicitlyClosedAutoCloseable", severity, isEnabling); return;
/*      */         } 
/* 4385 */         if (token.equals("removal")) {
/* 4386 */           setSeverity("org.eclipse.jdt.core.compiler.problem.terminalDeprecation", severity, isEnabling);
/* 4387 */           this.options.put(
/* 4388 */               "org.eclipse.jdt.core.compiler.problem.deprecationInDeprecatedCode", 
/* 4389 */               "disabled");
/* 4390 */           this.options.put(
/* 4391 */               "org.eclipse.jdt.core.compiler.problem.deprecationWhenOverridingDeprecatedMethod", 
/* 4392 */               "disabled");
/*      */           return;
/*      */         } 
/*      */         break;
/*      */       case 's':
/* 4397 */         if (token.equals("specialParamHiding")) {
/* 4398 */           this.options.put(
/* 4399 */               "org.eclipse.jdt.core.compiler.problem.specialParameterHidingField", 
/* 4400 */               isEnabling ? "enabled" : "disabled"); return;
/*      */         } 
/* 4402 */         if (token.equals("syntheticAccess") || token.equals("synthetic-access")) {
/* 4403 */           setSeverity("org.eclipse.jdt.core.compiler.problem.syntheticAccessEmulation", severity, isEnabling); return;
/*      */         } 
/* 4405 */         if (token.equals("staticReceiver")) {
/* 4406 */           setSeverity("org.eclipse.jdt.core.compiler.problem.staticAccessReceiver", severity, isEnabling); return;
/*      */         } 
/* 4408 */         if (token.equals("syncOverride")) {
/* 4409 */           setSeverity("org.eclipse.jdt.core.compiler.problem.missingSynchronizedOnInheritedMethod", severity, isEnabling); return;
/*      */         } 
/* 4411 */         if (token.equals("semicolon")) {
/* 4412 */           setSeverity("org.eclipse.jdt.core.compiler.problem.emptyStatement", severity, isEnabling); return;
/*      */         } 
/* 4414 */         if (token.equals("serial")) {
/* 4415 */           setSeverity("org.eclipse.jdt.core.compiler.problem.missingSerialVersion", severity, isEnabling); return;
/*      */         } 
/* 4417 */         if (token.equals("suppress")) {
/* 4418 */           switch (severity) {
/*      */             case 0:
/* 4420 */               this.options.put(
/* 4421 */                   "org.eclipse.jdt.core.compiler.problem.suppressWarnings", 
/* 4422 */                   isEnabling ? "enabled" : "disabled");
/* 4423 */               this.options.put(
/* 4424 */                   "org.eclipse.jdt.core.compiler.problem.suppressOptionalErrors", 
/* 4425 */                   "disabled");
/*      */               break;
/*      */             case 1:
/* 4428 */               this.options.put(
/* 4429 */                   "org.eclipse.jdt.core.compiler.problem.suppressWarnings", 
/* 4430 */                   isEnabling ? "enabled" : "disabled");
/* 4431 */               this.options.put(
/* 4432 */                   "org.eclipse.jdt.core.compiler.problem.suppressOptionalErrors", 
/* 4433 */                   isEnabling ? "enabled" : "disabled"); break;
/*      */           }  return;
/*      */         } 
/* 4436 */         if (token.equals("static-access")) {
/* 4437 */           setSeverity("org.eclipse.jdt.core.compiler.problem.staticAccessReceiver", severity, isEnabling);
/* 4438 */           setSeverity("org.eclipse.jdt.core.compiler.problem.indirectStaticAccess", severity, isEnabling); return;
/*      */         } 
/* 4440 */         if (token.equals("super")) {
/* 4441 */           setSeverity("org.eclipse.jdt.core.compiler.problem.overridingMethodWithoutSuperInvocation", severity, isEnabling); return;
/*      */         } 
/* 4443 */         if (token.equals("static-method")) {
/* 4444 */           setSeverity("org.eclipse.jdt.core.compiler.problem.reportMethodCanBeStatic", severity, isEnabling); return;
/*      */         } 
/* 4446 */         if (token.equals("switchDefault")) {
/* 4447 */           setSeverity("org.eclipse.jdt.core.compiler.problem.missingDefaultCase", severity, isEnabling); return;
/*      */         } 
/* 4449 */         if (token.equals("syntacticAnalysis")) {
/* 4450 */           this.options.put(
/* 4451 */               "org.eclipse.jdt.core.compiler.problem.syntacticNullAnalysisForFields", 
/* 4452 */               isEnabling ? "enabled" : "disabled");
/*      */           return;
/*      */         } 
/*      */         break;
/*      */       case 't':
/* 4457 */         if (token.startsWith("tasks")) {
/* 4458 */           String taskTags = Util.EMPTY_STRING;
/* 4459 */           int start = token.indexOf('(');
/* 4460 */           int end = token.indexOf(')');
/* 4461 */           if (start >= 0 && end >= 0 && start < end) {
/* 4462 */             taskTags = token.substring(start + 1, end).trim();
/* 4463 */             taskTags = taskTags.replace('|', ',');
/*      */           } 
/* 4465 */           if (taskTags.length() == 0) {
/* 4466 */             throw new IllegalArgumentException(bind("configure.invalidTaskTag", token));
/*      */           }
/* 4468 */           this.options.put(
/* 4469 */               "org.eclipse.jdt.core.compiler.taskTags", 
/* 4470 */               isEnabling ? taskTags : Util.EMPTY_STRING);
/*      */           
/* 4472 */           setSeverity("org.eclipse.jdt.core.compiler.problem.tasks", severity, isEnabling); return;
/*      */         } 
/* 4474 */         if (token.equals("typeHiding")) {
/* 4475 */           setSeverity("org.eclipse.jdt.core.compiler.problem.typeParameterHiding", severity, isEnabling);
/*      */           return;
/*      */         } 
/*      */         break;
/*      */       case 'u':
/* 4480 */         if (token.equals("unusedLocal") || token.equals("unusedLocals")) {
/* 4481 */           setSeverity("org.eclipse.jdt.core.compiler.problem.unusedLocal", severity, isEnabling); return;
/*      */         } 
/* 4483 */         if (token.equals("unusedArgument") || token.equals("unusedArguments")) {
/* 4484 */           setSeverity("org.eclipse.jdt.core.compiler.problem.unusedParameter", severity, isEnabling); return;
/*      */         } 
/* 4486 */         if (token.equals("unusedExceptionParam")) {
/* 4487 */           setSeverity("org.eclipse.jdt.core.compiler.problem.unusedExceptionParameter", severity, isEnabling); return;
/*      */         } 
/* 4489 */         if (token.equals("unusedImport") || token.equals("unusedImports")) {
/* 4490 */           setSeverity("org.eclipse.jdt.core.compiler.problem.unusedImport", severity, isEnabling); return;
/*      */         } 
/* 4492 */         if (token.equals("unusedAllocation")) {
/* 4493 */           setSeverity("org.eclipse.jdt.core.compiler.problem.unusedObjectAllocation", severity, isEnabling); return;
/*      */         } 
/* 4495 */         if (token.equals("unusedPrivate")) {
/* 4496 */           setSeverity("org.eclipse.jdt.core.compiler.problem.unusedPrivateMember", severity, isEnabling); return;
/*      */         } 
/* 4498 */         if (token.equals("unusedLabel")) {
/* 4499 */           setSeverity("org.eclipse.jdt.core.compiler.problem.unusedLabel", severity, isEnabling); return;
/*      */         } 
/* 4501 */         if (token.equals("uselessTypeCheck")) {
/* 4502 */           setSeverity("org.eclipse.jdt.core.compiler.problem.unnecessaryTypeCheck", severity, isEnabling); return;
/*      */         } 
/* 4504 */         if (token.equals("unchecked") || token.equals("unsafe")) {
/* 4505 */           setSeverity("org.eclipse.jdt.core.compiler.problem.uncheckedTypeOperation", severity, isEnabling); return;
/*      */         } 
/* 4507 */         if (token.equals("unlikelyCollectionMethodArgumentType")) {
/* 4508 */           setSeverity("org.eclipse.jdt.core.compiler.problem.unlikelyCollectionMethodArgumentType", severity, isEnabling); return;
/*      */         } 
/* 4510 */         if (token.equals("unlikelyEqualsArgumentType")) {
/* 4511 */           setSeverity("org.eclipse.jdt.core.compiler.problem.unlikelyEqualsArgumentType", severity, isEnabling); return;
/*      */         } 
/* 4513 */         if (token.equals("unnecessaryElse")) {
/* 4514 */           setSeverity("org.eclipse.jdt.core.compiler.problem.unnecessaryElse", severity, isEnabling); return;
/*      */         } 
/* 4516 */         if (token.equals("unusedThrown")) {
/* 4517 */           setSeverity("org.eclipse.jdt.core.compiler.problem.unusedDeclaredThrownException", severity, isEnabling); return;
/*      */         } 
/* 4519 */         if (token.equals("unusedThrownWhenOverriding")) {
/* 4520 */           this.options.put(
/* 4521 */               "org.eclipse.jdt.core.compiler.problem.unusedDeclaredThrownExceptionWhenOverriding", 
/* 4522 */               isEnabling ? "enabled" : "disabled"); return;
/*      */         } 
/* 4524 */         if (token.equals("unusedThrownIncludeDocComment")) {
/* 4525 */           this.options.put(
/* 4526 */               "org.eclipse.jdt.core.compiler.problem.unusedDeclaredThrownExceptionIncludeDocCommentReference", 
/* 4527 */               isEnabling ? "enabled" : "disabled"); return;
/*      */         } 
/* 4529 */         if (token.equals("unusedThrownExemptExceptionThrowable")) {
/* 4530 */           this.options.put(
/* 4531 */               "org.eclipse.jdt.core.compiler.problem.unusedDeclaredThrownExceptionExemptExceptionAndThrowable", 
/* 4532 */               isEnabling ? "enabled" : "disabled"); return;
/*      */         } 
/* 4534 */         if (token.equals("unqualifiedField") || token.equals("unqualified-field-access")) {
/* 4535 */           setSeverity("org.eclipse.jdt.core.compiler.problem.unqualifiedFieldAccess", severity, isEnabling); return;
/*      */         } 
/* 4537 */         if (token.equals("unused")) {
/* 4538 */           setSeverity("org.eclipse.jdt.core.compiler.problem.deadCode", severity, isEnabling);
/* 4539 */           setSeverity("org.eclipse.jdt.core.compiler.problem.redundantSuperinterface", severity, isEnabling);
/* 4540 */           setSeverity("org.eclipse.jdt.core.compiler.problem.redundantSpecificationOfTypeArguments", severity, isEnabling);
/* 4541 */           setSeverity("org.eclipse.jdt.core.compiler.problem.unusedDeclaredThrownException", severity, isEnabling);
/* 4542 */           setSeverity("org.eclipse.jdt.core.compiler.problem.unusedExceptionParameter", severity, isEnabling);
/* 4543 */           setSeverity("org.eclipse.jdt.core.compiler.problem.unusedImport", severity, isEnabling);
/* 4544 */           setSeverity("org.eclipse.jdt.core.compiler.problem.unusedLabel", severity, isEnabling);
/* 4545 */           setSeverity("org.eclipse.jdt.core.compiler.problem.unusedLocal", severity, isEnabling);
/* 4546 */           setSeverity("org.eclipse.jdt.core.compiler.problem.unusedObjectAllocation", severity, isEnabling);
/* 4547 */           setSeverity("org.eclipse.jdt.core.compiler.problem.unusedParameter", severity, isEnabling);
/* 4548 */           setSeverity("org.eclipse.jdt.core.compiler.problem.unusedPrivateMember", severity, isEnabling);
/* 4549 */           setSeverity("org.eclipse.jdt.core.compiler.problem.unusedTypeArgumentsForMethodInvocation", severity, isEnabling);
/* 4550 */           setSeverity("org.eclipse.jdt.core.compiler.problem.unusedTypeParameter", severity, isEnabling); return;
/*      */         } 
/* 4552 */         if (token.equals("unusedParam")) {
/* 4553 */           setSeverity("org.eclipse.jdt.core.compiler.problem.unusedParameter", severity, isEnabling); return;
/*      */         } 
/* 4555 */         if (token.equals("unusedTypeParameter")) {
/* 4556 */           setSeverity("org.eclipse.jdt.core.compiler.problem.unusedTypeParameter", severity, isEnabling); return;
/*      */         } 
/* 4558 */         if (token.equals("unusedParamIncludeDoc")) {
/* 4559 */           this.options.put(
/* 4560 */               "org.eclipse.jdt.core.compiler.problem.unusedParameterIncludeDocCommentReference", 
/* 4561 */               isEnabling ? "enabled" : "disabled"); return;
/*      */         } 
/* 4563 */         if (token.equals("unusedParamOverriding")) {
/* 4564 */           this.options.put(
/* 4565 */               "org.eclipse.jdt.core.compiler.problem.unusedParameterWhenOverridingConcrete", 
/* 4566 */               isEnabling ? "enabled" : "disabled"); return;
/*      */         } 
/* 4568 */         if (token.equals("unusedParamImplementing")) {
/* 4569 */           this.options.put(
/* 4570 */               "org.eclipse.jdt.core.compiler.problem.unusedParameterWhenImplementingAbstract", 
/* 4571 */               isEnabling ? "enabled" : "disabled"); return;
/*      */         } 
/* 4573 */         if (token.equals("unusedTypeArgs")) {
/* 4574 */           setSeverity("org.eclipse.jdt.core.compiler.problem.unusedTypeArgumentsForMethodInvocation", severity, isEnabling);
/* 4575 */           setSeverity("org.eclipse.jdt.core.compiler.problem.redundantSpecificationOfTypeArguments", severity, isEnabling); return;
/*      */         } 
/* 4577 */         if (token.equals("unavoidableGenericProblems")) {
/* 4578 */           this.options.put(
/* 4579 */               "org.eclipse.jdt.core.compiler.problem.unavoidableGenericTypeProblems", 
/* 4580 */               isEnabling ? "enabled" : "disabled");
/*      */           return;
/*      */         } 
/*      */         break;
/*      */       case 'v':
/* 4585 */         if (token.equals("varargsCast")) {
/* 4586 */           setSeverity("org.eclipse.jdt.core.compiler.problem.varargsArgumentNeedCast", severity, isEnabling);
/*      */           return;
/*      */         } 
/*      */         break;
/*      */       case 'w':
/* 4591 */         if (token.equals("warningToken")) {
/* 4592 */           setSeverity("org.eclipse.jdt.core.compiler.problem.unhandledWarningToken", severity, isEnabling);
/* 4593 */           setSeverity("org.eclipse.jdt.core.compiler.problem.unusedWarningToken", severity, isEnabling);
/*      */           return;
/*      */         } 
/*      */         break;
/*      */     } 
/* 4598 */     String message = null;
/* 4599 */     switch (severity) {
/*      */       case 1024:
/* 4601 */         message = bind("configure.invalidInfo", token);
/*      */         break;
/*      */       case 0:
/* 4604 */         message = bind("configure.invalidWarning", token);
/*      */         break;
/*      */       case 1:
/* 4607 */         message = bind("configure.invalidError", token); break;
/*      */     } 
/* 4609 */     addPendingErrors(message);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void initialize(PrintWriter outWriter, PrintWriter errWriter, boolean systemExit) {
/* 4616 */     initialize(outWriter, errWriter, systemExit, null, null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void initialize(PrintWriter outWriter, PrintWriter errWriter, boolean systemExit, Map<String, String> customDefaultOptions) {
/* 4623 */     initialize(outWriter, errWriter, systemExit, customDefaultOptions, null);
/*      */   }
/*      */   protected void initialize(PrintWriter outWriter, PrintWriter errWriter, boolean systemExit, Map<String, String> customDefaultOptions, CompilationProgress compilationProgress) {
/* 4626 */     this.logger = new Logger(this, outWriter, errWriter);
/* 4627 */     this.proceed = true;
/* 4628 */     this.out = outWriter;
/* 4629 */     this.err = errWriter;
/* 4630 */     this.systemExitWhenFinished = systemExit;
/* 4631 */     this.options = (new CompilerOptions()).getMap();
/* 4632 */     this.ignoreOptionalProblemsFromFolders = null;
/*      */     
/* 4634 */     this.progress = compilationProgress;
/* 4635 */     if (customDefaultOptions != null) {
/* 4636 */       this.didSpecifySource = (customDefaultOptions.get("org.eclipse.jdt.core.compiler.source") != null);
/* 4637 */       this.didSpecifyTarget = (customDefaultOptions.get("org.eclipse.jdt.core.compiler.codegen.targetPlatform") != null);
/* 4638 */       for (Iterator<Map.Entry<String, String>> iter = customDefaultOptions.entrySet().iterator(); iter.hasNext(); ) {
/* 4639 */         Map.Entry<String, String> entry = iter.next();
/* 4640 */         this.options.put(entry.getKey(), entry.getValue());
/*      */       } 
/*      */     } else {
/* 4643 */       this.didSpecifySource = false;
/* 4644 */       this.didSpecifyTarget = false;
/*      */     } 
/* 4646 */     this.classNames = null;
/*      */   }
/*      */   protected void initializeAnnotationProcessorManager() {
/* 4649 */     String className = "org.eclipse.jdt.internal.compiler.apt.dispatch.BatchAnnotationProcessorManager";
/*      */     try {
/* 4651 */       Class<?> c = Class.forName(className);
/* 4652 */       AbstractAnnotationProcessorManager annotationManager = c.getDeclaredConstructor(new Class[0]).newInstance(new Object[0]);
/* 4653 */       annotationManager.configure(this, this.expandedCommandLine);
/* 4654 */       annotationManager.setErr(this.err);
/* 4655 */       annotationManager.setOut(this.out);
/* 4656 */       this.batchCompiler.annotationProcessorManager = annotationManager;
/* 4657 */     } catch (ClassNotFoundException|InstantiationException|NoSuchMethodException|InvocationTargetException classNotFoundException) {
/* 4658 */       this.logger.logUnavaibleAPT(className);
/* 4659 */       throw new AbortCompilation();
/* 4660 */     } catch (IllegalAccessException illegalAccessException) {
/*      */       
/* 4662 */       throw new AbortCompilation();
/* 4663 */     } catch (UnsupportedClassVersionError unsupportedClassVersionError) {
/*      */       
/* 4665 */       this.logger.logIncorrectVMVersionForAnnotationProcessing();
/*      */     } 
/*      */   }
/*      */   private static boolean isParentOf(char[] folderName, char[] fileName) {
/* 4669 */     if (folderName.length >= fileName.length) {
/* 4670 */       return false;
/*      */     }
/* 4672 */     if (fileName[folderName.length] != '\\' && fileName[folderName.length] != '/') {
/* 4673 */       return false;
/*      */     }
/* 4675 */     for (int i = folderName.length - 1; i >= 0; i--) {
/* 4676 */       if (folderName[i] != fileName[i]) {
/* 4677 */         return false;
/*      */       }
/*      */     } 
/* 4680 */     return true;
/*      */   }
/*      */ 
/*      */   
/*      */   public void outputClassFiles(CompilationResult unitResult) {
/* 4685 */     if (unitResult != null && (!unitResult.hasErrors() || this.proceedOnError)) {
/* 4686 */       ClassFile[] classFiles = unitResult.getClassFiles();
/* 4687 */       String currentDestinationPath = null;
/* 4688 */       boolean generateClasspathStructure = false;
/* 4689 */       CompilationUnit compilationUnit = 
/* 4690 */         (CompilationUnit)unitResult.compilationUnit;
/* 4691 */       if (compilationUnit.destinationPath == null) {
/* 4692 */         if (this.destinationPath == null) {
/* 4693 */           currentDestinationPath = 
/* 4694 */             extractDestinationPathFromSourceFile(unitResult);
/* 4695 */         } else if (this.destinationPath != "none") {
/* 4696 */           currentDestinationPath = this.destinationPath;
/* 4697 */           generateClasspathStructure = true;
/*      */         } 
/* 4699 */       } else if (compilationUnit.destinationPath != "none") {
/* 4700 */         currentDestinationPath = compilationUnit.destinationPath;
/* 4701 */         generateClasspathStructure = true;
/*      */       } 
/* 4703 */       if (currentDestinationPath != null) {
/* 4704 */         for (int i = 0, fileCount = classFiles.length; i < fileCount; i++) {
/*      */           
/* 4706 */           ClassFile classFile = classFiles[i];
/* 4707 */           char[] filename = classFile.fileName();
/* 4708 */           int length = filename.length;
/* 4709 */           char[] relativeName = new char[length + 6];
/* 4710 */           System.arraycopy(filename, 0, relativeName, 0, length);
/* 4711 */           System.arraycopy(SuffixConstants.SUFFIX_class, 0, relativeName, length, 6);
/* 4712 */           CharOperation.replace(relativeName, '/', File.separatorChar);
/* 4713 */           String relativeStringName = new String(relativeName);
/*      */           try {
/* 4715 */             if (this.compilerOptions.verbose)
/* 4716 */               this.out.println(
/* 4717 */                   Messages.bind(
/* 4718 */                     Messages.compilation_write, 
/* 4719 */                     (Object[])new String[] {
/* 4720 */                       String.valueOf(this.exportedClassFilesCounter + 1), 
/* 4721 */                       relativeStringName
/*      */                     })); 
/* 4723 */             Util.writeToDisk(
/* 4724 */                 generateClasspathStructure, 
/* 4725 */                 currentDestinationPath, 
/* 4726 */                 relativeStringName, 
/* 4727 */                 classFile);
/* 4728 */             this.logger.logClassFile(
/* 4729 */                 generateClasspathStructure, 
/* 4730 */                 currentDestinationPath, 
/* 4731 */                 relativeStringName);
/* 4732 */             this.exportedClassFilesCounter++;
/* 4733 */           } catch (IOException e) {
/* 4734 */             this.logger.logNoClassFileCreated(currentDestinationPath, relativeStringName, e);
/*      */           } 
/*      */         } 
/* 4737 */         this.batchCompiler.lookupEnvironment.releaseClassFiles(classFiles);
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void performCompilation() {
/* 4745 */     this.startTime = System.currentTimeMillis();
/*      */     
/* 4747 */     FileSystem environment = getLibraryAccess();
/*      */     try {
/* 4749 */       this.compilerOptions = new CompilerOptions(this.options);
/* 4750 */       this.compilerOptions.performMethodsFullRecovery = false;
/* 4751 */       this.compilerOptions.performStatementsRecovery = false;
/* 4752 */       this.batchCompiler = 
/* 4753 */         new Compiler(
/* 4754 */           (INameEnvironment)environment, 
/* 4755 */           getHandlingPolicy(), 
/* 4756 */           this.compilerOptions, 
/* 4757 */           getBatchRequestor(), 
/* 4758 */           getProblemFactory(), 
/* 4759 */           this.out, 
/* 4760 */           this.progress);
/* 4761 */       this.batchCompiler.remainingIterations = this.maxRepetition - this.currentRepetition;
/*      */       
/* 4763 */       String setting = System.getProperty("jdt.compiler.useSingleThread");
/* 4764 */       this.batchCompiler.useSingleThread = (setting != null && setting.equals("true"));
/*      */       
/* 4766 */       if (this.compilerOptions.complianceLevel >= 3276800L && 
/* 4767 */         this.compilerOptions.processAnnotations) {
/* 4768 */         if (checkVMVersion(3276800L)) {
/* 4769 */           initializeAnnotationProcessorManager();
/* 4770 */           if (this.classNames != null) {
/* 4771 */             this.batchCompiler.setBinaryTypes(processClassNames(this.batchCompiler.lookupEnvironment));
/*      */           }
/*      */         } else {
/*      */           
/* 4775 */           this.logger.logIncorrectVMVersionForAnnotationProcessing();
/*      */         } 
/* 4777 */         if (checkVMVersion(3473408L)) {
/* 4778 */           initRootModules(this.batchCompiler.lookupEnvironment, environment);
/*      */         }
/*      */       } 
/*      */ 
/*      */       
/* 4783 */       this.compilerOptions.verbose = this.verbose;
/* 4784 */       this.compilerOptions.produceReferenceInfo = this.produceRefInfo;
/*      */       try {
/* 4786 */         this.logger.startLoggingSources();
/* 4787 */         this.batchCompiler.compile((ICompilationUnit[])getCompilationUnits());
/*      */       } finally {
/* 4789 */         this.logger.endLoggingSources();
/*      */       } 
/*      */       
/* 4792 */       if (this.extraProblems != null) {
/* 4793 */         loggingExtraProblems();
/* 4794 */         this.extraProblems = null;
/*      */       } 
/* 4796 */       if (this.compilerStats != null) {
/* 4797 */         this.compilerStats[this.currentRepetition] = this.batchCompiler.stats;
/*      */       }
/* 4799 */       this.logger.printStats();
/*      */     }
/*      */     finally {
/*      */       
/* 4803 */       environment.cleanup();
/*      */     } 
/*      */   }
/*      */   protected void loggingExtraProblems() {
/* 4807 */     this.logger.loggingExtraProblems(this);
/*      */   }
/*      */   public void printUsage() {
/* 4810 */     printUsage("misc.usage");
/*      */   }
/*      */   private void printUsage(String sectionID) {
/* 4813 */     this.logger.logUsage(
/* 4814 */         bind(
/* 4815 */           sectionID, 
/* 4816 */           new String[] {
/* 4817 */             System.getProperty("path.separator"), 
/* 4818 */             bind("compiler.name"), 
/* 4819 */             bind("compiler.version"), 
/* 4820 */             bind("compiler.copyright")
/*      */           }));
/* 4822 */     this.logger.flush();
/*      */   }
/*      */   private void initRootModules(LookupEnvironment environment, FileSystem fileSystem) {
/* 4825 */     Map<String, String> map = new HashMap<>();
/* 4826 */     for (String m : this.rootModules) {
/* 4827 */       ModuleBinding mod = environment.getModule(m.toCharArray());
/* 4828 */       if (mod == null) {
/* 4829 */         throw new IllegalArgumentException(bind("configure.invalidModuleName", m));
/*      */       }
/* 4831 */       PlainPackageBinding[] arrayOfPlainPackageBinding1 = mod.getExports(); byte b; int i; PlainPackageBinding[] arrayOfPlainPackageBinding2;
/* 4832 */       for (i = (arrayOfPlainPackageBinding2 = arrayOfPlainPackageBinding1).length, b = 0; b < i; ) { PlainPackageBinding plainPackageBinding = arrayOfPlainPackageBinding2[b];
/* 4833 */         String qName = CharOperation.toString(((PackageBinding)plainPackageBinding).compoundName);
/* 4834 */         String existing = map.get(qName);
/* 4835 */         if (existing != null) {
/* 4836 */           throw new IllegalArgumentException(bind("configure.packageConflict", new String[] { qName, existing, m }));
/*      */         }
/*      */         
/* 4839 */         map.put(qName, m); b++; }
/*      */     
/*      */     } 
/* 4842 */     if (this.limitedModules != null) {
/* 4843 */       for (String m : this.limitedModules) {
/* 4844 */         ModuleBinding mod = environment.getModule(m.toCharArray());
/* 4845 */         if (mod == null) {
/* 4846 */           throw new IllegalArgumentException(bind("configure.invalidModuleName", m));
/*      */         }
/*      */       } 
/*      */     }
/* 4850 */     environment.moduleVersion = this.moduleVersion;
/*      */   }
/*      */   
/*      */   private ReferenceBinding[] processClassNames(LookupEnvironment environment) {
/* 4854 */     int length = this.classNames.length;
/* 4855 */     ReferenceBinding[] referenceBindings = new ReferenceBinding[length];
/* 4856 */     ModuleBinding[] modules = new ModuleBinding[length];
/* 4857 */     Set<ModuleBinding> modSet = new HashSet<>();
/* 4858 */     String[] typeNames = new String[length];
/* 4859 */     if (this.complianceLevel <= 3407872L) {
/* 4860 */       typeNames = this.classNames;
/*      */     } else {
/* 4862 */       for (int j = 0; j < length; j++) {
/* 4863 */         String currentName = this.classNames[j];
/* 4864 */         int idx = currentName.indexOf('/');
/* 4865 */         ModuleBinding mod = null;
/* 4866 */         if (idx > 0) {
/* 4867 */           String m = currentName.substring(0, idx);
/* 4868 */           mod = environment.getModule(m.toCharArray());
/* 4869 */           if (mod == null) {
/* 4870 */             throw new IllegalArgumentException(bind("configure.invalidModuleName", m));
/*      */           }
/* 4872 */           modules[j] = mod;
/* 4873 */           modSet.add(mod);
/* 4874 */           currentName = currentName.substring(idx + 1);
/*      */         } 
/* 4876 */         typeNames[j] = currentName;
/*      */       } 
/*      */     } 
/*      */     
/* 4880 */     for (int i = 0; i < length; i++) {
/* 4881 */       char[][] compoundName = null;
/* 4882 */       String cls = typeNames[i];
/* 4883 */       if (cls.indexOf('.') != -1) {
/*      */         
/* 4885 */         char[] typeName = cls.toCharArray();
/* 4886 */         compoundName = CharOperation.splitOn('.', typeName);
/*      */       } else {
/* 4888 */         compoundName = new char[][] { cls.toCharArray() };
/*      */       } 
/* 4890 */       ModuleBinding mod = modules[i];
/* 4891 */       ReferenceBinding type = (mod != null) ? environment.getType(compoundName, mod) : environment.getType(compoundName);
/* 4892 */       if (type != null && type.isValidBinding()) {
/* 4893 */         if (type.isBinaryBinding()) {
/* 4894 */           referenceBindings[i] = type;
/* 4895 */           type.superclass();
/*      */         } 
/*      */       } else {
/* 4898 */         throw new IllegalArgumentException(
/* 4899 */             bind("configure.invalidClassName", this.classNames[i]));
/*      */       } 
/*      */     } 
/* 4902 */     return referenceBindings;
/*      */   }
/*      */   private ArrayList<String> processModulePathEntries(String arg) {
/* 4905 */     ArrayList<String> paths = new ArrayList<>();
/* 4906 */     if (arg == null)
/* 4907 */       return paths; 
/* 4908 */     StringTokenizer tokenizer = new StringTokenizer(arg, File.pathSeparator, false);
/* 4909 */     while (tokenizer.hasMoreTokens()) {
/* 4910 */       paths.add(tokenizer.nextToken());
/*      */     }
/* 4912 */     return paths;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void processPathEntries(int defaultSize, ArrayList<FileSystem.Classpath> paths, String currentPath, String customEncoding, boolean isSourceOnly, boolean rejectDestinationPathOnJars) {
/* 4920 */     String currentClasspathName = null;
/* 4921 */     String currentDestinationPath = null;
/* 4922 */     ArrayList<String> currentRuleSpecs = new ArrayList<>(defaultSize);
/* 4923 */     StringTokenizer tokenizer = new StringTokenizer(currentPath, 
/* 4924 */         String.valueOf(File.pathSeparator) + "[]", true);
/* 4925 */     ArrayList<String> tokens = new ArrayList<>();
/* 4926 */     while (tokenizer.hasMoreTokens()) {
/* 4927 */       tokens.add(tokenizer.nextToken());
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 4955 */     int state = 0;
/* 4956 */     String token = null;
/* 4957 */     int cursor = 0, tokensNb = tokens.size(), bracket = -1;
/* 4958 */     while (cursor < tokensNb && state != 99) {
/* 4959 */       token = tokens.get(cursor++);
/* 4960 */       if (token.equals(File.pathSeparator)) {
/* 4961 */         switch (state) {
/*      */           case 0:
/*      */           case 3:
/*      */           case 10:
/*      */             break;
/*      */           case 1:
/*      */           case 2:
/*      */           case 8:
/* 4969 */             state = 3;
/* 4970 */             addNewEntry(paths, currentClasspathName, currentRuleSpecs, 
/* 4971 */                 customEncoding, currentDestinationPath, isSourceOnly, 
/* 4972 */                 rejectDestinationPathOnJars);
/* 4973 */             currentRuleSpecs.clear();
/*      */             break;
/*      */           case 6:
/* 4976 */             state = 4;
/*      */             break;
/*      */           case 7:
/* 4979 */             throw new IllegalArgumentException(
/* 4980 */                 bind("configure.incorrectDestinationPathEntry", 
/* 4981 */                   currentPath));
/*      */           case 11:
/* 4983 */             cursor = bracket + 1;
/* 4984 */             state = 5;
/*      */             break;
/*      */           default:
/* 4987 */             state = 99; break;
/*      */         } 
/* 4989 */       } else if (token.equals("[")) {
/* 4990 */         switch (state) {
/*      */           case 0:
/* 4992 */             currentClasspathName = "";
/*      */           
/*      */           case 1:
/* 4995 */             bracket = cursor - 1;
/*      */           
/*      */           case 11:
/* 4998 */             state = 10;
/*      */             break;
/*      */           case 2:
/* 5001 */             state = 9;
/*      */             break;
/*      */           case 8:
/* 5004 */             state = 5;
/*      */             break;
/*      */           
/*      */           default:
/* 5008 */             state = 99; break;
/*      */         } 
/* 5010 */       } else if (token.equals("]")) {
/* 5011 */         switch (state) {
/*      */           case 6:
/* 5013 */             state = 2;
/*      */             break;
/*      */           case 7:
/* 5016 */             state = 8;
/*      */             break;
/*      */           case 10:
/* 5019 */             state = 11;
/*      */             break;
/*      */           
/*      */           default:
/* 5023 */             state = 99; break;
/*      */         } 
/*      */       } else {
/*      */         int i;
/* 5027 */         switch (state) {
/*      */           case 0:
/*      */           case 3:
/* 5030 */             state = 1;
/* 5031 */             currentClasspathName = token;
/*      */             break;
/*      */           case 5:
/* 5034 */             if (token.startsWith("-d ")) {
/* 5035 */               if (currentDestinationPath != null) {
/* 5036 */                 throw new IllegalArgumentException(
/* 5037 */                     bind("configure.duplicateDestinationPathEntry", 
/* 5038 */                       currentPath));
/*      */               }
/* 5040 */               currentDestinationPath = token.substring(3).trim();
/* 5041 */               state = 7;
/*      */               break;
/*      */             } 
/*      */           
/*      */           case 4:
/* 5046 */             if (currentDestinationPath != null) {
/* 5047 */               throw new IllegalArgumentException(
/* 5048 */                   bind("configure.accessRuleAfterDestinationPath", 
/* 5049 */                     currentPath));
/*      */             }
/* 5051 */             state = 6;
/* 5052 */             currentRuleSpecs.add(token);
/*      */             break;
/*      */           case 9:
/* 5055 */             if (!token.startsWith("-d ")) {
/* 5056 */               state = 99; break;
/*      */             } 
/* 5058 */             currentDestinationPath = token.substring(3).trim();
/* 5059 */             state = 7;
/*      */             break;
/*      */           
/*      */           case 11:
/* 5063 */             for (i = bracket; i < cursor; i++) {
/* 5064 */               currentClasspathName = String.valueOf(currentClasspathName) + (String)tokens.get(i);
/*      */             }
/* 5066 */             state = 1;
/*      */             break;
/*      */           case 10:
/*      */             break;
/*      */           default:
/* 5071 */             state = 99; break;
/*      */         } 
/*      */       } 
/* 5074 */       if (state == 11 && cursor == tokensNb) {
/* 5075 */         cursor = bracket + 1;
/* 5076 */         state = 5;
/*      */       } 
/*      */     } 
/* 5079 */     switch (state) {
/*      */       case 3:
/*      */         return;
/*      */       case 1:
/*      */       case 2:
/*      */       case 8:
/* 5085 */         addNewEntry(paths, currentClasspathName, currentRuleSpecs, 
/* 5086 */             customEncoding, currentDestinationPath, isSourceOnly, 
/* 5087 */             rejectDestinationPathOnJars);
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 5093 */     if (currentPath.length() != 0) {
/* 5094 */       addPendingErrors(bind("configure.incorrectClasspath", currentPath));
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   private int processPaths(String[] args, int index, String currentArg, ArrayList<String> paths) {
/* 5100 */     int localIndex = index;
/* 5101 */     int count = 0;
/* 5102 */     for (int i = 0, max = currentArg.length(); i < max; i++) {
/* 5103 */       switch (currentArg.charAt(i)) {
/*      */         case '[':
/* 5105 */           count++;
/*      */           break;
/*      */         case ']':
/* 5108 */           count--;
/*      */           break;
/*      */       } 
/*      */     } 
/* 5112 */     if (count == 0)
/* 5113 */     { paths.add(currentArg); }
/* 5114 */     else { if (count > 1) {
/* 5115 */         throw new IllegalArgumentException(
/* 5116 */             bind("configure.unexpectedBracket", 
/* 5117 */               currentArg));
/*      */       }
/* 5119 */       StringBuilder currentPath = new StringBuilder(currentArg);
/*      */       while (true) {
/* 5121 */         if (localIndex >= args.length) {
/* 5122 */           throw new IllegalArgumentException(
/* 5123 */               bind("configure.unexpectedBracket", 
/* 5124 */                 currentArg));
/*      */         }
/* 5126 */         localIndex++;
/* 5127 */         String nextArg = args[localIndex];
/* 5128 */         for (int j = 0, k = nextArg.length(); j < k; j++) {
/* 5129 */           switch (nextArg.charAt(j)) {
/*      */             case '[':
/* 5131 */               if (count > 1) {
/* 5132 */                 throw new IllegalArgumentException(
/* 5133 */                     bind("configure.unexpectedBracket", 
/* 5134 */                       nextArg));
/*      */               }
/* 5136 */               count++;
/*      */               break;
/*      */             case ']':
/* 5139 */               count--;
/*      */               break;
/*      */           } 
/*      */         } 
/* 5143 */         if (count == 0) {
/* 5144 */           currentPath.append(' ');
/* 5145 */           currentPath.append(nextArg);
/* 5146 */           paths.add(currentPath.toString());
/* 5147 */           return localIndex - index;
/* 5148 */         }  if (count < 0) {
/* 5149 */           throw new IllegalArgumentException(
/* 5150 */               bind("configure.unexpectedBracket", 
/* 5151 */                 nextArg));
/*      */         }
/* 5153 */         currentPath.append(' ');
/* 5154 */         currentPath.append(nextArg);
/*      */       }  }
/*      */ 
/*      */ 
/*      */     
/* 5159 */     return localIndex - index;
/*      */   }
/*      */   private int processPaths(String[] args, int index, String currentArg, String[] paths) {
/* 5162 */     int localIndex = index;
/* 5163 */     int count = 0;
/* 5164 */     for (int i = 0, max = currentArg.length(); i < max; i++) {
/* 5165 */       switch (currentArg.charAt(i)) {
/*      */         case '[':
/* 5167 */           count++;
/*      */           break;
/*      */         case ']':
/* 5170 */           count--;
/*      */           break;
/*      */       } 
/*      */     } 
/* 5174 */     if (count == 0) {
/* 5175 */       paths[0] = currentArg;
/*      */     } else {
/* 5177 */       StringBuilder currentPath = new StringBuilder(currentArg);
/*      */       while (true) {
/* 5179 */         localIndex++;
/* 5180 */         if (localIndex >= args.length) {
/* 5181 */           throw new IllegalArgumentException(
/* 5182 */               bind("configure.unexpectedBracket", 
/* 5183 */                 currentArg));
/*      */         }
/* 5185 */         String nextArg = args[localIndex];
/* 5186 */         for (int j = 0, k = nextArg.length(); j < k; j++) {
/* 5187 */           switch (nextArg.charAt(j)) {
/*      */             case '[':
/* 5189 */               if (count > 1) {
/* 5190 */                 throw new IllegalArgumentException(
/* 5191 */                     bind("configure.unexpectedBracket", 
/* 5192 */                       currentArg));
/*      */               }
/* 5194 */               count++;
/*      */               break;
/*      */             case ']':
/* 5197 */               count--;
/*      */               break;
/*      */           } 
/*      */         } 
/* 5201 */         if (count == 0) {
/* 5202 */           currentPath.append(' ');
/* 5203 */           currentPath.append(nextArg);
/* 5204 */           paths[0] = currentPath.toString();
/* 5205 */           return localIndex - index;
/* 5206 */         }  if (count < 0) {
/* 5207 */           throw new IllegalArgumentException(
/* 5208 */               bind("configure.unexpectedBracket", 
/* 5209 */                 currentArg));
/*      */         }
/* 5211 */         currentPath.append(' ');
/* 5212 */         currentPath.append(nextArg);
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/* 5217 */     return localIndex - index;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void relocalize() {
/* 5223 */     relocalize(Locale.getDefault());
/*      */   }
/*      */   
/*      */   private void relocalize(Locale locale) {
/* 5227 */     this.compilerLocale = locale;
/*      */     try {
/* 5229 */       this.bundle = ResourceBundleFactory.getBundle(locale);
/* 5230 */     } catch (MissingResourceException e) {
/* 5231 */       System.out.println("Missing resource : " + "org.eclipse.jdt.internal.compiler.batch.messages".replace('.', '/') + ".properties for locale " + locale);
/* 5232 */       throw e;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void setDestinationPath(String dest) {
/* 5239 */     this.destinationPath = dest;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void setLocale(Locale locale) {
/* 5245 */     relocalize(locale);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void setPaths(ArrayList<String> bootclasspaths, String sourcepathClasspathArg, ArrayList<String> sourcepathClasspaths, ArrayList<String> classpaths, String modulePath, String moduleSourcepath, ArrayList<String> extdirsClasspaths, ArrayList<String> endorsedDirClasspaths, String customEncoding) {
/* 5260 */     if (this.complianceLevel == 0L) {
/* 5261 */       String version = this.options.get("org.eclipse.jdt.core.compiler.compliance");
/* 5262 */       this.complianceLevel = CompilerOptions.versionToJdkLevel(version);
/*      */     } 
/*      */     
/* 5265 */     ArrayList<FileSystem.Classpath> allPaths = null;
/* 5266 */     long jdkLevel = validateClasspathOptions(bootclasspaths, endorsedDirClasspaths, extdirsClasspaths);
/*      */     
/* 5268 */     if (this.releaseVersion != null && this.complianceLevel < jdkLevel) {
/*      */       
/* 5270 */       allPaths = new ArrayList<>();
/* 5271 */       allPaths.add(
/* 5272 */           FileSystem.getOlderSystemRelease(this.javaHomeCache.getAbsolutePath(), this.releaseVersion, null));
/*      */     } else {
/* 5274 */       allPaths = handleBootclasspath(bootclasspaths, customEncoding);
/*      */     } 
/*      */     
/* 5277 */     List<FileSystem.Classpath> cp = handleClasspath(classpaths, customEncoding);
/*      */     
/* 5279 */     List<FileSystem.Classpath> mp = handleModulepath(modulePath);
/*      */     
/* 5281 */     List<FileSystem.Classpath> msp = handleModuleSourcepath(moduleSourcepath);
/*      */     
/* 5283 */     ArrayList<FileSystem.Classpath> sourcepaths = new ArrayList<>();
/* 5284 */     if (sourcepathClasspathArg != null) {
/* 5285 */       processPathEntries(4, sourcepaths, 
/* 5286 */           sourcepathClasspathArg, customEncoding, true, false);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 5295 */     List<FileSystem.Classpath> extdirs = handleExtdirs(extdirsClasspaths);
/*      */     
/* 5297 */     List<FileSystem.Classpath> endorsed = handleEndorseddirs(endorsedDirClasspaths);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 5307 */     allPaths.addAll(0, endorsed);
/* 5308 */     allPaths.addAll(extdirs);
/* 5309 */     allPaths.addAll(sourcepaths);
/* 5310 */     allPaths.addAll(cp);
/* 5311 */     allPaths.addAll(mp);
/* 5312 */     allPaths.addAll(msp);
/* 5313 */     allPaths = FileSystem.ClasspathNormalizer.normalize(allPaths);
/* 5314 */     this.checkedClasspaths = new FileSystem.Classpath[allPaths.size()];
/* 5315 */     allPaths.toArray(this.checkedClasspaths);
/* 5316 */     this.logger.logClasspath(this.checkedClasspaths);
/*      */     
/* 5318 */     if (this.annotationPaths != null && "enabled".equals(this.options.get("org.eclipse.jdt.core.compiler.annotation.nullanalysis"))) {
/* 5319 */       byte b; int i; FileSystem.Classpath[] arrayOfClasspath; for (i = (arrayOfClasspath = this.checkedClasspaths).length, b = 0; b < i; ) { FileSystem.Classpath c = arrayOfClasspath[b];
/* 5320 */         if (c instanceof ClasspathJar) {
/* 5321 */           ((ClasspathJar)c).annotationPaths = this.annotationPaths;
/* 5322 */         } else if (c instanceof ClasspathJrt) {
/* 5323 */           ((ClasspathJrt)c).annotationPaths = this.annotationPaths;
/*      */         } 
/*      */         b++; }
/*      */     
/*      */     }  } public static final boolean shouldIgnoreOptionalProblems(char[][] folderNames, char[] fileName) {
/* 5328 */     if (folderNames == null || fileName == null) {
/* 5329 */       return false;
/*      */     }
/* 5331 */     for (int i = 0, max = folderNames.length; i < max; i++) {
/* 5332 */       char[] folderName = folderNames[i];
/* 5333 */       if (isParentOf(folderName, fileName)) {
/* 5334 */         return true;
/*      */       }
/*      */     } 
/* 5337 */     return false;
/*      */   }
/*      */   protected long validateClasspathOptions(ArrayList<String> bootclasspaths, ArrayList<String> endorsedDirClasspaths, ArrayList<String> extdirsClasspaths) {
/* 5340 */     if (this.complianceLevel > 3407872L) {
/* 5341 */       if (bootclasspaths != null && bootclasspaths.size() > 0)
/* 5342 */         throw new IllegalArgumentException(
/* 5343 */             bind("configure.unsupportedOption", "-bootclasspath")); 
/* 5344 */       if (extdirsClasspaths != null && extdirsClasspaths.size() > 0)
/* 5345 */         throw new IllegalArgumentException(
/* 5346 */             bind("configure.unsupportedOption", "-extdirs")); 
/* 5347 */       if (endorsedDirClasspaths != null && endorsedDirClasspaths.size() > 0)
/* 5348 */         throw new IllegalArgumentException(
/* 5349 */             bind("configure.unsupportedOption", "-endorseddirs")); 
/*      */     } 
/* 5351 */     long jdkLevel = Util.getJDKLevel(getJavaHome());
/* 5352 */     if (jdkLevel < 3473408L && this.releaseVersion != null) {
/* 5353 */       throw new IllegalArgumentException(
/* 5354 */           bind("configure.unsupportedReleaseOption"));
/*      */     }
/* 5356 */     return jdkLevel;
/*      */   }
/*      */   protected void validateOptions(boolean didSpecifyCompliance) {
/* 5359 */     if (didSpecifyCompliance) {
/* 5360 */       String version = this.options.get("org.eclipse.jdt.core.compiler.compliance");
/* 5361 */       if (this.releaseVersion != null) {
/* 5362 */         throw new IllegalArgumentException(
/* 5363 */             bind("configure.unsupportedWithRelease", version));
/*      */       }
/* 5365 */       if ("1.3".equals(version)) {
/* 5366 */         if (!this.didSpecifySource) this.options.put("org.eclipse.jdt.core.compiler.source", "1.3"); 
/* 5367 */         if (!this.didSpecifyTarget) this.options.put("org.eclipse.jdt.core.compiler.codegen.targetPlatform", "1.1"); 
/* 5368 */       } else if ("1.4".equals(version)) {
/* 5369 */         if (this.didSpecifySource) {
/* 5370 */           Object source = this.options.get("org.eclipse.jdt.core.compiler.source");
/* 5371 */           if ("1.3".equals(source))
/* 5372 */           { if (!this.didSpecifyTarget) this.options.put("org.eclipse.jdt.core.compiler.codegen.targetPlatform", "1.2");  }
/* 5373 */           else if ("1.4".equals(source) && 
/* 5374 */             !this.didSpecifyTarget) { this.options.put("org.eclipse.jdt.core.compiler.codegen.targetPlatform", "1.4"); }
/*      */         
/*      */         } else {
/* 5377 */           this.options.put("org.eclipse.jdt.core.compiler.source", "1.3");
/* 5378 */           if (!this.didSpecifyTarget) this.options.put("org.eclipse.jdt.core.compiler.codegen.targetPlatform", "1.2"); 
/*      */         } 
/* 5380 */       } else if ("1.5".equals(version)) {
/* 5381 */         if (this.didSpecifySource) {
/* 5382 */           Object source = this.options.get("org.eclipse.jdt.core.compiler.source");
/* 5383 */           if ("1.3".equals(source) || 
/* 5384 */             "1.4".equals(source))
/* 5385 */           { if (!this.didSpecifyTarget) this.options.put("org.eclipse.jdt.core.compiler.codegen.targetPlatform", "1.4");  }
/* 5386 */           else if ("1.5".equals(source) && 
/* 5387 */             !this.didSpecifyTarget) { this.options.put("org.eclipse.jdt.core.compiler.codegen.targetPlatform", "1.5"); }
/*      */         
/*      */         } else {
/* 5390 */           this.options.put("org.eclipse.jdt.core.compiler.source", "1.5");
/* 5391 */           if (!this.didSpecifyTarget) this.options.put("org.eclipse.jdt.core.compiler.codegen.targetPlatform", "1.5"); 
/*      */         } 
/* 5393 */       } else if ("1.6".equals(version)) {
/* 5394 */         if (this.didSpecifySource) {
/* 5395 */           Object source = this.options.get("org.eclipse.jdt.core.compiler.source");
/* 5396 */           if ("1.3".equals(source) || 
/* 5397 */             "1.4".equals(source))
/* 5398 */           { if (!this.didSpecifyTarget) this.options.put("org.eclipse.jdt.core.compiler.codegen.targetPlatform", "1.4");  }
/* 5399 */           else if (("1.5".equals(source) || 
/* 5400 */             "1.6".equals(source)) && 
/* 5401 */             !this.didSpecifyTarget) { this.options.put("org.eclipse.jdt.core.compiler.codegen.targetPlatform", "1.6"); }
/*      */         
/*      */         } else {
/* 5404 */           this.options.put("org.eclipse.jdt.core.compiler.source", "1.6");
/* 5405 */           if (!this.didSpecifyTarget) this.options.put("org.eclipse.jdt.core.compiler.codegen.targetPlatform", "1.6"); 
/*      */         } 
/* 5407 */       } else if ("1.7".equals(version)) {
/* 5408 */         if (this.didSpecifySource) {
/* 5409 */           Object source = this.options.get("org.eclipse.jdt.core.compiler.source");
/* 5410 */           if ("1.3".equals(source) || 
/* 5411 */             "1.4".equals(source))
/* 5412 */           { if (!this.didSpecifyTarget) this.options.put("org.eclipse.jdt.core.compiler.codegen.targetPlatform", "1.4");  }
/* 5413 */           else if ("1.5".equals(source) || 
/* 5414 */             "1.6".equals(source))
/* 5415 */           { if (!this.didSpecifyTarget) this.options.put("org.eclipse.jdt.core.compiler.codegen.targetPlatform", "1.6");  }
/* 5416 */           else if ("1.7".equals(source) && 
/* 5417 */             !this.didSpecifyTarget) { this.options.put("org.eclipse.jdt.core.compiler.codegen.targetPlatform", "1.7"); }
/*      */         
/*      */         } else {
/* 5420 */           this.options.put("org.eclipse.jdt.core.compiler.source", "1.7");
/* 5421 */           if (!this.didSpecifyTarget) this.options.put("org.eclipse.jdt.core.compiler.codegen.targetPlatform", "1.7"); 
/*      */         } 
/* 5423 */       } else if ("1.8".equals(version)) {
/* 5424 */         if (this.didSpecifySource) {
/* 5425 */           Object source = this.options.get("org.eclipse.jdt.core.compiler.source");
/* 5426 */           if ("1.3".equals(source) || 
/* 5427 */             "1.4".equals(source))
/* 5428 */           { if (!this.didSpecifyTarget) this.options.put("org.eclipse.jdt.core.compiler.codegen.targetPlatform", "1.4");  }
/* 5429 */           else if ("1.5".equals(source) || 
/* 5430 */             "1.6".equals(source))
/* 5431 */           { if (!this.didSpecifyTarget) this.options.put("org.eclipse.jdt.core.compiler.codegen.targetPlatform", "1.6");  }
/* 5432 */           else if ("1.7".equals(source))
/* 5433 */           { if (!this.didSpecifyTarget) this.options.put("org.eclipse.jdt.core.compiler.codegen.targetPlatform", "1.7");  }
/* 5434 */           else if ("1.8".equals(source) && 
/* 5435 */             !this.didSpecifyTarget) { this.options.put("org.eclipse.jdt.core.compiler.codegen.targetPlatform", "1.8"); }
/*      */         
/*      */         } else {
/* 5438 */           this.options.put("org.eclipse.jdt.core.compiler.source", "1.8");
/* 5439 */           if (!this.didSpecifyTarget) this.options.put("org.eclipse.jdt.core.compiler.codegen.targetPlatform", "1.8"); 
/*      */         } 
/* 5441 */       } else if ("9".equals(version)) {
/* 5442 */         if (this.didSpecifySource) {
/* 5443 */           Object source = this.options.get("org.eclipse.jdt.core.compiler.source");
/* 5444 */           if ("1.3".equals(source) || 
/* 5445 */             "1.4".equals(source))
/* 5446 */           { if (!this.didSpecifyTarget) this.options.put("org.eclipse.jdt.core.compiler.codegen.targetPlatform", "1.4");  }
/* 5447 */           else if ("1.5".equals(source) || 
/* 5448 */             "1.6".equals(source))
/* 5449 */           { if (!this.didSpecifyTarget) this.options.put("org.eclipse.jdt.core.compiler.codegen.targetPlatform", "1.6");  }
/* 5450 */           else if ("1.7".equals(source))
/* 5451 */           { if (!this.didSpecifyTarget) this.options.put("org.eclipse.jdt.core.compiler.codegen.targetPlatform", "1.7");  }
/* 5452 */           else if ("1.8".equals(source))
/* 5453 */           { if (!this.didSpecifyTarget) this.options.put("org.eclipse.jdt.core.compiler.codegen.targetPlatform", "1.8");  }
/* 5454 */           else if ("9".equals(source) && 
/* 5455 */             !this.didSpecifyTarget) { this.options.put("org.eclipse.jdt.core.compiler.codegen.targetPlatform", "9"); }
/*      */         
/*      */         } else {
/* 5458 */           this.options.put("org.eclipse.jdt.core.compiler.source", "9");
/* 5459 */           if (!this.didSpecifyTarget) this.options.put("org.eclipse.jdt.core.compiler.codegen.targetPlatform", "9"); 
/*      */         } 
/* 5461 */       } else if ("10".equals(version)) {
/* 5462 */         if (this.didSpecifySource) {
/* 5463 */           Object source = this.options.get("org.eclipse.jdt.core.compiler.source");
/* 5464 */           if ("1.3".equals(source) || 
/* 5465 */             "1.4".equals(source))
/* 5466 */           { if (!this.didSpecifyTarget) this.options.put("org.eclipse.jdt.core.compiler.codegen.targetPlatform", "1.4");  }
/* 5467 */           else if ("1.5".equals(source) || 
/* 5468 */             "1.6".equals(source))
/* 5469 */           { if (!this.didSpecifyTarget) this.options.put("org.eclipse.jdt.core.compiler.codegen.targetPlatform", "1.6");  }
/* 5470 */           else if ("1.7".equals(source))
/* 5471 */           { if (!this.didSpecifyTarget) this.options.put("org.eclipse.jdt.core.compiler.codegen.targetPlatform", "1.7");  }
/* 5472 */           else if ("1.8".equals(source))
/* 5473 */           { if (!this.didSpecifyTarget) this.options.put("org.eclipse.jdt.core.compiler.codegen.targetPlatform", "1.8");  }
/* 5474 */           else if ("9".equals(source))
/* 5475 */           { if (!this.didSpecifyTarget) this.options.put("org.eclipse.jdt.core.compiler.codegen.targetPlatform", "9");  }
/* 5476 */           else if ("10".equals(source) && 
/* 5477 */             !this.didSpecifyTarget) { this.options.put("org.eclipse.jdt.core.compiler.codegen.targetPlatform", "10"); }
/*      */         
/*      */         } else {
/* 5480 */           this.options.put("org.eclipse.jdt.core.compiler.source", "10");
/* 5481 */           if (!this.didSpecifyTarget) this.options.put("org.eclipse.jdt.core.compiler.codegen.targetPlatform", "10");
/*      */         
/*      */         } 
/* 5484 */       } else if (!this.didSpecifyTarget) {
/* 5485 */         if (this.didSpecifySource) {
/* 5486 */           String source = this.options.get("org.eclipse.jdt.core.compiler.source");
/* 5487 */           if ("1.3".equals(source) || 
/* 5488 */             "1.4".equals(source)) {
/* 5489 */             if (!this.didSpecifyTarget) this.options.put("org.eclipse.jdt.core.compiler.codegen.targetPlatform", "1.4"); 
/* 5490 */           } else if ("1.5".equals(source) || 
/* 5491 */             "1.6".equals(source)) {
/* 5492 */             this.options.put("org.eclipse.jdt.core.compiler.codegen.targetPlatform", "1.6");
/*      */ 
/*      */           
/*      */           }
/* 5496 */           else if (CompilerOptions.versionToJdkLevel(source) >= 3342336L) {
/* 5497 */             this.options.put("org.eclipse.jdt.core.compiler.codegen.targetPlatform", source);
/*      */           }
/*      */         
/* 5500 */         } else if (CompilerOptions.versionToJdkLevel(version) > 3538944L) {
/* 5501 */           this.options.put("org.eclipse.jdt.core.compiler.source", version);
/* 5502 */           this.options.put("org.eclipse.jdt.core.compiler.codegen.targetPlatform", version);
/*      */         }
/*      */       
/*      */       }
/*      */     
/*      */     }
/* 5508 */     else if (this.didSpecifySource) {
/* 5509 */       String version = this.options.get("org.eclipse.jdt.core.compiler.source");
/*      */       
/* 5511 */       if ("1.4".equals(version)) {
/* 5512 */         if (!didSpecifyCompliance) this.options.put("org.eclipse.jdt.core.compiler.compliance", "1.4"); 
/* 5513 */         if (!this.didSpecifyTarget) this.options.put("org.eclipse.jdt.core.compiler.codegen.targetPlatform", "1.4"); 
/* 5514 */       } else if ("1.5".equals(version)) {
/* 5515 */         if (!didSpecifyCompliance) this.options.put("org.eclipse.jdt.core.compiler.compliance", "1.5"); 
/* 5516 */         if (!this.didSpecifyTarget) this.options.put("org.eclipse.jdt.core.compiler.codegen.targetPlatform", "1.5"); 
/* 5517 */       } else if ("1.6".equals(version)) {
/* 5518 */         if (!didSpecifyCompliance) this.options.put("org.eclipse.jdt.core.compiler.compliance", "1.6"); 
/* 5519 */         if (!this.didSpecifyTarget) this.options.put("org.eclipse.jdt.core.compiler.codegen.targetPlatform", "1.6"); 
/* 5520 */       } else if ("1.7".equals(version)) {
/* 5521 */         if (!didSpecifyCompliance) this.options.put("org.eclipse.jdt.core.compiler.compliance", "1.7"); 
/* 5522 */         if (!this.didSpecifyTarget) this.options.put("org.eclipse.jdt.core.compiler.codegen.targetPlatform", "1.7"); 
/* 5523 */       } else if ("1.8".equals(version)) {
/* 5524 */         if (!didSpecifyCompliance) this.options.put("org.eclipse.jdt.core.compiler.compliance", "1.8"); 
/* 5525 */         if (!this.didSpecifyTarget) this.options.put("org.eclipse.jdt.core.compiler.codegen.targetPlatform", "1.8"); 
/* 5526 */       } else if ("9".equals(version)) {
/* 5527 */         if (!didSpecifyCompliance) this.options.put("org.eclipse.jdt.core.compiler.compliance", "9"); 
/* 5528 */         if (!this.didSpecifyTarget) this.options.put("org.eclipse.jdt.core.compiler.codegen.targetPlatform", "9"); 
/* 5529 */       } else if ("10".equals(version)) {
/* 5530 */         if (!didSpecifyCompliance) this.options.put("org.eclipse.jdt.core.compiler.compliance", "10"); 
/* 5531 */         if (!this.didSpecifyTarget) this.options.put("org.eclipse.jdt.core.compiler.codegen.targetPlatform", "10");
/*      */       
/* 5533 */       } else if (CompilerOptions.versionToJdkLevel(version) > 3538944L) {
/* 5534 */         if (!didSpecifyCompliance) this.options.put("org.eclipse.jdt.core.compiler.compliance", version); 
/* 5535 */         if (!this.didSpecifyTarget) this.options.put("org.eclipse.jdt.core.compiler.codegen.targetPlatform", version);
/*      */       
/*      */       } 
/*      */     } 
/*      */     
/* 5540 */     String sourceVersion = this.options.get("org.eclipse.jdt.core.compiler.source");
/* 5541 */     if (this.complianceLevel == 0L) {
/* 5542 */       String compliance = this.options.get("org.eclipse.jdt.core.compiler.compliance");
/* 5543 */       this.complianceLevel = CompilerOptions.versionToJdkLevel(compliance);
/*      */     } 
/* 5545 */     if (sourceVersion.equals("10") && 
/* 5546 */       this.complianceLevel < 3538944L)
/*      */     {
/* 5548 */       throw new IllegalArgumentException(bind("configure.incompatibleComplianceForSource", (String)this.options.get("org.eclipse.jdt.core.compiler.compliance"), "10")); } 
/* 5549 */     if (sourceVersion.equals("9") && 
/* 5550 */       this.complianceLevel < 3473408L)
/*      */     {
/* 5552 */       throw new IllegalArgumentException(bind("configure.incompatibleComplianceForSource", (String)this.options.get("org.eclipse.jdt.core.compiler.compliance"), "9")); } 
/* 5553 */     if (sourceVersion.equals("1.8") && 
/* 5554 */       this.complianceLevel < 3407872L)
/*      */     {
/* 5556 */       throw new IllegalArgumentException(bind("configure.incompatibleComplianceForSource", (String)this.options.get("org.eclipse.jdt.core.compiler.compliance"), "1.8")); } 
/* 5557 */     if (sourceVersion.equals("1.7") && 
/* 5558 */       this.complianceLevel < 3342336L)
/*      */     {
/* 5560 */       throw new IllegalArgumentException(bind("configure.incompatibleComplianceForSource", (String)this.options.get("org.eclipse.jdt.core.compiler.compliance"), "1.7")); } 
/* 5561 */     if (sourceVersion.equals("1.6") && 
/* 5562 */       this.complianceLevel < 3276800L)
/*      */     {
/* 5564 */       throw new IllegalArgumentException(bind("configure.incompatibleComplianceForSource", (String)this.options.get("org.eclipse.jdt.core.compiler.compliance"), "1.6")); } 
/* 5565 */     if (sourceVersion.equals("1.5") && 
/* 5566 */       this.complianceLevel < 3211264L)
/*      */     {
/* 5568 */       throw new IllegalArgumentException(bind("configure.incompatibleComplianceForSource", (String)this.options.get("org.eclipse.jdt.core.compiler.compliance"), "1.5")); } 
/* 5569 */     if (sourceVersion.equals("1.4") && 
/* 5570 */       this.complianceLevel < 3145728L)
/*      */     {
/* 5572 */       throw new IllegalArgumentException(bind("configure.incompatibleComplianceForSource", (String)this.options.get("org.eclipse.jdt.core.compiler.compliance"), "1.4"));
/*      */     }
/* 5574 */     long ver = CompilerOptions.versionToJdkLevel(sourceVersion);
/* 5575 */     if (this.complianceLevel < ver) {
/* 5576 */       throw new IllegalArgumentException(bind("configure.incompatibleComplianceForSource", (String)this.options.get("org.eclipse.jdt.core.compiler.compliance"), sourceVersion));
/*      */     }
/* 5578 */     if (this.enablePreview && this.complianceLevel != ClassFileConstants.getLatestJDKLevel()) {
/* 5579 */       throw new IllegalArgumentException(bind("configure.unsupportedPreview"));
/*      */     }
/*      */ 
/*      */     
/* 5583 */     if (this.didSpecifyTarget) {
/* 5584 */       String targetVersion = this.options.get("org.eclipse.jdt.core.compiler.codegen.targetPlatform");
/*      */       
/* 5586 */       if ("jsr14".equals(targetVersion)) {
/*      */         
/* 5588 */         if (CompilerOptions.versionToJdkLevel(sourceVersion) < 3211264L) {
/* 5589 */           throw new IllegalArgumentException(bind("configure.incompatibleTargetForGenericSource", targetVersion, sourceVersion));
/*      */         }
/* 5591 */       } else if ("cldc1.1".equals(targetVersion)) {
/* 5592 */         if (this.didSpecifySource && CompilerOptions.versionToJdkLevel(sourceVersion) >= 3145728L) {
/* 5593 */           throw new IllegalArgumentException(bind("configure.incompatibleSourceForCldcTarget", targetVersion, sourceVersion));
/*      */         }
/* 5595 */         if (this.complianceLevel >= 3211264L) {
/* 5596 */           throw new IllegalArgumentException(bind("configure.incompatibleComplianceForCldcTarget", targetVersion, sourceVersion));
/*      */         }
/*      */       } else {
/*      */         
/* 5600 */         if (CompilerOptions.versionToJdkLevel(sourceVersion) >= 3407872L && 
/* 5601 */           CompilerOptions.versionToJdkLevel(targetVersion) < 3407872L) {
/* 5602 */           throw new IllegalArgumentException(bind("configure.incompatibleTargetForSource", targetVersion, "1.8"));
/*      */         }
/*      */         
/* 5605 */         if (CompilerOptions.versionToJdkLevel(sourceVersion) >= 3342336L && 
/* 5606 */           CompilerOptions.versionToJdkLevel(targetVersion) < 3342336L) {
/* 5607 */           throw new IllegalArgumentException(bind("configure.incompatibleTargetForSource", targetVersion, "1.7"));
/*      */         }
/*      */         
/* 5610 */         if (CompilerOptions.versionToJdkLevel(sourceVersion) >= 3276800L && 
/* 5611 */           CompilerOptions.versionToJdkLevel(targetVersion) < 3276800L) {
/* 5612 */           throw new IllegalArgumentException(bind("configure.incompatibleTargetForSource", targetVersion, "1.6"));
/*      */         }
/*      */         
/* 5615 */         if (CompilerOptions.versionToJdkLevel(sourceVersion) >= 3211264L && 
/* 5616 */           CompilerOptions.versionToJdkLevel(targetVersion) < 3211264L) {
/* 5617 */           throw new IllegalArgumentException(bind("configure.incompatibleTargetForSource", targetVersion, "1.5"));
/*      */         }
/*      */         
/* 5620 */         if (CompilerOptions.versionToJdkLevel(sourceVersion) >= 3145728L && 
/* 5621 */           CompilerOptions.versionToJdkLevel(targetVersion) < 3145728L) {
/* 5622 */           throw new IllegalArgumentException(bind("configure.incompatibleTargetForSource", targetVersion, "1.4"));
/*      */         }
/*      */         
/* 5625 */         if (this.complianceLevel < CompilerOptions.versionToJdkLevel(targetVersion))
/* 5626 */           throw new IllegalArgumentException(bind("configure.incompatibleComplianceForTarget", (String)this.options.get("org.eclipse.jdt.core.compiler.compliance"), targetVersion)); 
/*      */       } 
/*      */     } 
/*      */   }
/*      */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\batch\Main.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */