/*     */ package org.eclipse.jdt.internal.compiler.lookup;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class Binding
/*     */ {
/*     */   public static final int FIELD = 1;
/*     */   public static final int LOCAL = 2;
/*     */   public static final int VARIABLE = 3;
/*     */   public static final int TYPE = 4;
/*     */   public static final int METHOD = 8;
/*     */   public static final int PACKAGE = 16;
/*     */   public static final int IMPORT = 32;
/*     */   public static final int MODULE = 64;
/*     */   public static final int ARRAY_TYPE = 68;
/*     */   public static final int BASE_TYPE = 132;
/*     */   public static final int PARAMETERIZED_TYPE = 260;
/*     */   public static final int WILDCARD_TYPE = 516;
/*     */   public static final int RAW_TYPE = 1028;
/*     */   public static final int GENERIC_TYPE = 2052;
/*     */   public static final int TYPE_PARAMETER = 4100;
/*     */   public static final int INTERSECTION_TYPE = 8196;
/*     */   public static final int TYPE_USE = 16388;
/*     */   public static final int INTERSECTION_TYPE18 = 32772;
/*     */   public static final int POLY_TYPE = 65540;
/*     */   public static final int RECORD_COMPONENT = 131072;
/*     */   public static final int PATTERN = 262144;
/*  55 */   public static final ModuleBinding[] NO_MODULES = new ModuleBinding[0];
/*  56 */   public static final PackageBinding[] NO_PACKAGES = new PackageBinding[0];
/*  57 */   public static final PlainPackageBinding[] NO_PLAIN_PACKAGES = new PlainPackageBinding[0];
/*  58 */   public static final TypeBinding[] NO_TYPES = new TypeBinding[0];
/*  59 */   public static final ReferenceBinding[] NO_REFERENCE_TYPES = new ReferenceBinding[0];
/*  60 */   public static final TypeBinding[] NO_PARAMETERS = new TypeBinding[0];
/*  61 */   public static final ReferenceBinding[] NO_EXCEPTIONS = new ReferenceBinding[0];
/*  62 */   public static final ReferenceBinding[] ANY_EXCEPTION = new ReferenceBinding[1];
/*  63 */   public static final FieldBinding[] NO_FIELDS = new FieldBinding[0];
/*  64 */   public static final MethodBinding[] NO_METHODS = new MethodBinding[0];
/*  65 */   public static final ReferenceBinding[] NO_PERMITTEDTYPES = new ReferenceBinding[0];
/*  66 */   public static final ReferenceBinding[] NO_SUPERINTERFACES = new ReferenceBinding[0];
/*  67 */   public static final ReferenceBinding[] NO_MEMBER_TYPES = new ReferenceBinding[0];
/*  68 */   public static final TypeVariableBinding[] NO_TYPE_VARIABLES = new TypeVariableBinding[0];
/*  69 */   public static final AnnotationBinding[] NO_ANNOTATIONS = new AnnotationBinding[0];
/*  70 */   public static final ElementValuePair[] NO_ELEMENT_VALUE_PAIRS = new ElementValuePair[0];
/*  71 */   public static final char[][] NO_PARAMETER_NAMES = new char[0][];
/*  72 */   public static final RecordComponentBinding[] NO_COMPONENTS = new RecordComponentBinding[0];
/*     */   
/*  74 */   public static final RecordComponentBinding[] UNINITIALIZED_COMPONENTS = new RecordComponentBinding[0];
/*  75 */   public static final FieldBinding[] UNINITIALIZED_FIELDS = new FieldBinding[0];
/*  76 */   public static final MethodBinding[] UNINITIALIZED_METHODS = new MethodBinding[0];
/*  77 */   public static final ReferenceBinding[] UNINITIALIZED_REFERENCE_TYPES = new ReferenceBinding[0];
/*     */   
/*  79 */   static final InferenceVariable[] NO_INFERENCE_VARIABLES = new InferenceVariable[0];
/*  80 */   static final TypeBound[] NO_TYPE_BOUNDS = new TypeBound[0];
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final int NO_NULL_DEFAULT = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final int NULL_UNSPECIFIED_BY_DEFAULT = 2;
/*     */ 
/*     */ 
/*     */   
/*     */   public static final int DefaultLocationParameter = 8;
/*     */ 
/*     */ 
/*     */   
/*     */   public static final int DefaultLocationReturnType = 16;
/*     */ 
/*     */ 
/*     */   
/*     */   public static final int DefaultLocationField = 32;
/*     */ 
/*     */ 
/*     */   
/*     */   public static final int DefaultLocationTypeArgument = 64;
/*     */ 
/*     */ 
/*     */   
/*     */   public static final int DefaultLocationTypeParameter = 128;
/*     */ 
/*     */ 
/*     */   
/*     */   public static final int DefaultLocationTypeBound = 256;
/*     */ 
/*     */ 
/*     */   
/*     */   public static final int DefaultLocationArrayContents = 512;
/*     */ 
/*     */ 
/*     */   
/*     */   public static final int DefaultLocationsForTrueValue = 56;
/*     */ 
/*     */ 
/*     */   
/*     */   public static final int NullnessDefaultMASK = 1018;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract int kind();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public char[] computeUniqueKey() {
/* 137 */     return computeUniqueKey(true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public char[] computeUniqueKey(boolean isLeaf) {
/* 145 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long getAnnotationTagBits() {
/* 156 */     return 0L;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void initializeDeprecatedAnnotationTagBits() {}
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isAnnotationType() {
/* 169 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final boolean isValidBinding() {
/* 176 */     return (problemId() == 0);
/*     */   }
/*     */   public static boolean isValid(Binding binding) {
/* 179 */     return (binding != null && binding.isValidBinding());
/*     */   }
/*     */   public boolean isVolatile() {
/* 182 */     return false;
/*     */   }
/*     */   public boolean isTaggedRepeatable() {
/* 185 */     return false;
/*     */   }
/*     */   public boolean isParameter() {
/* 188 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int problemId() {
/* 197 */     return 0;
/*     */   }
/*     */ 
/*     */   
/*     */   public abstract char[] readableName();
/*     */ 
/*     */   
/*     */   public char[] shortReadableName() {
/* 205 */     return readableName();
/*     */   }
/*     */   public AnnotationBinding[] getAnnotations() {
/* 208 */     return NO_ANNOTATIONS;
/*     */   }
/*     */   public void setAnnotations(AnnotationBinding[] annotations, Scope scope, boolean forceStore) {
/* 211 */     setAnnotations(annotations, forceStore);
/*     */   }
/*     */   
/*     */   public void setAnnotations(AnnotationBinding[] annotations, boolean forceStore) {}
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\lookup\Binding.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */