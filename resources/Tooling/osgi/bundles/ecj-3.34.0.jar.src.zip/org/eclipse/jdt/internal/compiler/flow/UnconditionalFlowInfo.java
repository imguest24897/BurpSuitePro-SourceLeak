/*      */ package org.eclipse.jdt.internal.compiler.flow;
/*      */ 
/*      */ import java.util.Arrays;
/*      */ import org.eclipse.jdt.internal.compiler.impl.Constant;
/*      */ import org.eclipse.jdt.internal.compiler.lookup.FieldBinding;
/*      */ import org.eclipse.jdt.internal.compiler.lookup.LocalVariableBinding;
/*      */ import org.eclipse.jdt.internal.compiler.lookup.ReferenceBinding;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class UnconditionalFlowInfo
/*      */   extends FlowInfo
/*      */ {
/*      */   public static final boolean COVERAGE_TEST_FLAG = false;
/*      */   public static int CoverageTestId;
/*      */   public long definiteInits;
/*      */   public long potentialInits;
/*      */   public long nullBit1;
/*      */   public long nullBit2;
/*      */   public long nullBit3;
/*      */   public long nullBit4;
/*      */   public long iNBit;
/*      */   public long iNNBit;
/*      */   public static final int extraLength = 8;
/*      */   public long[][] extra;
/*      */   public int maxFieldCount;
/*      */   public static final int BitCacheSize = 64;
/*      */   public static final int IN = 6;
/*      */   public static final int INN = 7;
/*      */   
/*      */   public static class AssertionFailedException
/*      */     extends RuntimeException
/*      */   {
/*      */     private static final long serialVersionUID = 1827352841030089703L;
/*      */     
/*      */     public AssertionFailedException(String message) {
/*   51 */       super(message);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static UnconditionalFlowInfo fakeInitializedFlowInfo(int localsCount, int maxFieldCount) {
/*  122 */     UnconditionalFlowInfo flowInfo = new UnconditionalFlowInfo();
/*  123 */     flowInfo.maxFieldCount = maxFieldCount;
/*  124 */     for (int i = 0; i < localsCount; i++)
/*  125 */       flowInfo.markAsDefinitelyAssigned(i + maxFieldCount); 
/*  126 */     return flowInfo;
/*      */   }
/*      */ 
/*      */   
/*      */   public FlowInfo addInitializationsFrom(FlowInfo inits) {
/*  131 */     return addInfoFrom(inits, true);
/*      */   }
/*      */   
/*      */   public FlowInfo addNullInfoFrom(FlowInfo inits) {
/*  135 */     return addInfoFrom(inits, false);
/*      */   }
/*      */   private FlowInfo addInfoFrom(FlowInfo inits, boolean handleInits) {
/*  138 */     if (this == DEAD_END)
/*  139 */       return this; 
/*  140 */     if (inits == DEAD_END)
/*  141 */       return this; 
/*  142 */     UnconditionalFlowInfo otherInits = inits.unconditionalInits();
/*      */     
/*  144 */     if (handleInits) {
/*      */       
/*  146 */       this.definiteInits |= otherInits.definiteInits;
/*      */       
/*  148 */       this.potentialInits |= otherInits.potentialInits;
/*      */     } 
/*      */ 
/*      */     
/*  152 */     boolean thisHadNulls = ((this.tagBits & 0x4) != 0);
/*  153 */     boolean otherHasNulls = ((otherInits.tagBits & 0x4) != 0);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  161 */     if (otherHasNulls) {
/*  162 */       if (!thisHadNulls) {
/*  163 */         this.nullBit1 = otherInits.nullBit1;
/*  164 */         this.nullBit2 = otherInits.nullBit2;
/*  165 */         this.nullBit3 = otherInits.nullBit3;
/*  166 */         this.nullBit4 = otherInits.nullBit4;
/*  167 */         this.iNBit = otherInits.iNBit;
/*  168 */         this.iNNBit = otherInits.iNNBit;
/*      */ 
/*      */       
/*      */       }
/*      */       else {
/*      */ 
/*      */ 
/*      */         
/*  176 */         long a1 = this.nullBit1;
/*  177 */         long a2 = this.nullBit2;
/*  178 */         long a3 = this.nullBit3;
/*  179 */         long a4 = this.nullBit4;
/*      */ 
/*      */         
/*  182 */         long protNN1111 = a1 & a2 & a3 & a4;
/*      */ 
/*      */ 
/*      */         
/*  186 */         long acceptNonNull = otherInits.iNNBit;
/*  187 */         long acceptNull = otherInits.iNBit | 
/*  188 */           protNN1111;
/*  189 */         long dontResetToStart = protNN1111 ^ 0xFFFFFFFFFFFFFFFFL | acceptNonNull;
/*      */         
/*  191 */         a1 &= dontResetToStart;
/*  192 */         a2 = dontResetToStart & acceptNull & a2;
/*  193 */         a3 = dontResetToStart & acceptNonNull & a3;
/*  194 */         a4 &= dontResetToStart;
/*  195 */         a1 &= a2 | a3 | a4;
/*      */         long na2, na3, na4, b1, b2, b3, b4, nb2, nb3, nb4;
/*  197 */         this.nullBit1 = (b1 = otherInits.nullBit1) | 
/*  198 */           a1 & (a3 & 
/*  199 */           a4 & (nb2 = (b2 = otherInits.nullBit2) ^ 0xFFFFFFFFFFFFFFFFL) & (
/*  200 */           nb4 = (b4 = otherInits.nullBit4) ^ 0xFFFFFFFFFFFFFFFFL) | ((
/*  201 */           na4 = a4 ^ 0xFFFFFFFFFFFFFFFFL) | (na3 = a3 ^ 0xFFFFFFFFFFFFFFFFL)) & ((
/*  202 */           na2 = a2 ^ 0xFFFFFFFFFFFFFFFFL) & nb2 | 
/*  203 */           a2 & (nb3 = (b3 = otherInits.nullBit3) ^ 0xFFFFFFFFFFFFFFFFL) & nb4)); long na1, nb1;
/*  204 */         this.nullBit2 = b2 & (nb4 | nb3) | 
/*  205 */           na3 & na4 & b2 | 
/*  206 */           a2 & (nb3 & nb4 | (
/*  207 */           nb1 = b1 ^ 0xFFFFFFFFFFFFFFFFL) & (na3 | (na1 = a1 ^ 0xFFFFFFFFFFFFFFFFL)) | 
/*  208 */           a1 & b2);
/*  209 */         this.nullBit3 = b3 & (nb1 & (b2 | a2 | na1) | 
/*  210 */           b1 & (b4 | nb2 | a1 & a3) | 
/*  211 */           na1 & na2 & na4) | 
/*  212 */           a3 & nb2 & nb4 | 
/*  213 */           nb1 & ((na2 & a4 | na1) & a3 | 
/*  214 */           a1 & na2 & na4 & b2);
/*  215 */         this.nullBit4 = nb1 & (a4 & (na3 & nb3 | (a3 | na2) & nb2) | 
/*  216 */           a1 & (a3 & nb2 & b4 | 
/*  217 */           a2 & b2 & (b4 | a3 & na4 & nb3))) | 
/*  218 */           b1 & (a3 & a4 & b4 | 
/*  219 */           na2 & na4 & nb3 & b4 | 
/*  220 */           a2 & ((b3 | a4) & b4 | 
/*  221 */           na3 & a4 & b2 & b3) | 
/*  222 */           na1 & (b4 | (a4 | a2) & b2 & b3)) | (
/*  223 */           na1 & (na3 & nb3 | na2 & nb2) | 
/*  224 */           a1 & (nb2 & nb3 | a2 & a3)) & b4;
/*      */ 
/*      */         
/*  227 */         this.iNBit &= otherInits.iNBit;
/*  228 */         this.iNNBit &= otherInits.iNNBit;
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  235 */       this.tagBits |= 0x4;
/*      */     } 
/*      */     
/*  238 */     if (this.extra != null || otherInits.extra != null) {
/*  239 */       int mergeLimit = 0, copyLimit = 0;
/*  240 */       if (this.extra != null) {
/*  241 */         if (otherInits.extra != null) {
/*      */           int length;
/*      */           int otherLength;
/*  244 */           if ((length = (this.extra[0]).length) < (
/*  245 */             otherLength = (otherInits.extra[0]).length))
/*      */           {
/*  247 */             growSpace(otherLength, 0, length);
/*  248 */             mergeLimit = length;
/*  249 */             copyLimit = otherLength;
/*      */ 
/*      */           
/*      */           }
/*      */           else
/*      */           {
/*      */ 
/*      */             
/*  257 */             mergeLimit = otherLength;
/*      */           
/*      */           }
/*      */ 
/*      */         
/*      */         }
/*      */       
/*      */       }
/*  265 */       else if (otherInits.extra != null) {
/*      */ 
/*      */ 
/*      */         
/*  269 */         this.extra = new long[8][]; int otherLength;
/*  270 */         this.extra[0] = new long[otherLength = (otherInits.extra[0]).length];
/*  271 */         this.extra[1] = new long[otherLength];
/*  272 */         if (handleInits) {
/*  273 */           System.arraycopy(otherInits.extra[0], 0, this.extra[0], 0, otherLength);
/*  274 */           System.arraycopy(otherInits.extra[1], 0, this.extra[1], 0, otherLength);
/*      */         } 
/*  276 */         if (otherHasNulls) {
/*  277 */           for (int j = 2; j < 8; j++) {
/*  278 */             System.arraycopy(otherInits.extra[j], 0, 
/*  279 */                 this.extra[j] = new long[otherLength], 0, otherLength);
/*      */           }
/*  281 */           if ((this.tagBits & 0x40) != 0) {
/*  282 */             Arrays.fill(this.extra[6], 0, otherLength, -1L);
/*  283 */             Arrays.fill(this.extra[7], 0, otherLength, -1L);
/*      */           
/*      */           }
/*      */ 
/*      */         
/*      */         }
/*      */         else {
/*      */ 
/*      */           
/*  292 */           for (int j = 2; j < 8; j++) {
/*  293 */             this.extra[j] = new long[otherLength];
/*      */           }
/*  295 */           System.arraycopy(otherInits.extra[6], 0, this.extra[6], 0, otherLength);
/*  296 */           System.arraycopy(otherInits.extra[7], 0, this.extra[7], 0, otherLength);
/*      */         } 
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  305 */       if (handleInits) {
/*      */         int j;
/*  307 */         for (j = 0; j < mergeLimit; j++) {
/*  308 */           this.extra[0][j] = this.extra[0][j] | otherInits.extra[0][j];
/*  309 */           this.extra[1][j] = this.extra[1][j] | otherInits.extra[1][j];
/*      */         } 
/*  311 */         for (; j < copyLimit; j++) {
/*  312 */           this.extra[0][j] = otherInits.extra[0][j];
/*  313 */           this.extra[1][j] = otherInits.extra[1][j];
/*      */         } 
/*      */       } 
/*      */ 
/*      */       
/*  318 */       if (!thisHadNulls) {
/*  319 */         if (copyLimit < mergeLimit) {
/*  320 */           copyLimit = mergeLimit;
/*      */         }
/*  322 */         mergeLimit = 0;
/*      */       } 
/*  324 */       if (!otherHasNulls) {
/*  325 */         copyLimit = 0;
/*  326 */         mergeLimit = 0;
/*      */       }  int i;
/*  328 */       for (i = 0; i < mergeLimit; i++) {
/*  329 */         long a1 = this.extra[2][i];
/*  330 */         long a2 = this.extra[3][i];
/*  331 */         long a3 = this.extra[4][i];
/*  332 */         long a4 = this.extra[5][i];
/*      */         
/*  334 */         long protNN1111 = a1 & a2 & a3 & a4;
/*      */ 
/*      */ 
/*      */         
/*  338 */         long acceptNonNull = otherInits.extra[7][i];
/*  339 */         long acceptNull = otherInits.extra[6][i] | 
/*  340 */           protNN1111;
/*  341 */         long dontResetToStart = protNN1111 ^ 0xFFFFFFFFFFFFFFFFL | acceptNonNull;
/*      */         
/*  343 */         a1 &= dontResetToStart;
/*  344 */         a2 = dontResetToStart & acceptNull & a2;
/*  345 */         a3 = dontResetToStart & acceptNonNull & a3;
/*  346 */         a4 &= dontResetToStart;
/*  347 */         a1 &= a2 | a3 | a4;
/*      */         long na2, na3, na4, b1, b2, b3, b4, nb2, nb3, nb4;
/*  349 */         this.extra[2][i] = (b1 = otherInits.extra[2][i]) | 
/*  350 */           a1 & (a3 & 
/*  351 */           a4 & (nb2 = (b2 = otherInits.extra[3][i]) ^ 0xFFFFFFFFFFFFFFFFL) & (
/*  352 */           nb4 = (b4 = otherInits.extra[5][i]) ^ 0xFFFFFFFFFFFFFFFFL) | ((
/*  353 */           na4 = a4 ^ 0xFFFFFFFFFFFFFFFFL) | (na3 = a3 ^ 0xFFFFFFFFFFFFFFFFL)) & ((
/*  354 */           na2 = a2 ^ 0xFFFFFFFFFFFFFFFFL) & nb2 | 
/*  355 */           a2 & (nb3 = (b3 = otherInits.extra[4][i]) ^ 0xFFFFFFFFFFFFFFFFL) & nb4)); long na1, nb1;
/*  356 */         this.extra[3][i] = b2 & (nb4 | nb3) | 
/*  357 */           na3 & na4 & b2 | 
/*  358 */           a2 & (nb3 & nb4 | (
/*  359 */           nb1 = b1 ^ 0xFFFFFFFFFFFFFFFFL) & (na3 | (na1 = a1 ^ 0xFFFFFFFFFFFFFFFFL)) | 
/*  360 */           a1 & b2);
/*  361 */         this.extra[4][i] = b3 & (nb1 & (b2 | a2 | na1) | 
/*  362 */           b1 & (b4 | nb2 | a1 & a3) | 
/*  363 */           na1 & na2 & na4) | 
/*  364 */           a3 & nb2 & nb4 | 
/*  365 */           nb1 & ((na2 & a4 | na1) & a3 | 
/*  366 */           a1 & na2 & na4 & b2);
/*  367 */         this.extra[5][i] = nb1 & (a4 & (na3 & nb3 | (a3 | na2) & nb2) | 
/*  368 */           a1 & (a3 & nb2 & b4 | 
/*  369 */           a2 & b2 & (b4 | a3 & na4 & nb3))) | 
/*  370 */           b1 & (a3 & a4 & b4 | 
/*  371 */           na2 & na4 & nb3 & b4 | 
/*  372 */           a2 & ((b3 | a4) & b4 | 
/*  373 */           na3 & a4 & b2 & b3) | 
/*  374 */           na1 & (b4 | (a4 | a2) & b2 & b3)) | (
/*  375 */           na1 & (na3 & nb3 | na2 & nb2) | 
/*  376 */           a1 & (nb2 & nb3 | a2 & a3)) & b4;
/*      */ 
/*      */         
/*  379 */         this.extra[6][i] = this.extra[6][i] & otherInits.extra[6][i];
/*  380 */         this.extra[7][i] = this.extra[7][i] & otherInits.extra[7][i];
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  388 */       for (; i < copyLimit; i++) {
/*  389 */         for (int j = 2; j < 8; j++) {
/*  390 */           this.extra[j][i] = otherInits.extra[j][i];
/*      */         }
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  399 */     return this;
/*      */   }
/*      */ 
/*      */   
/*      */   public FlowInfo addPotentialInitializationsFrom(FlowInfo inits) {
/*  404 */     if (this == DEAD_END) {
/*  405 */       return this;
/*      */     }
/*  407 */     if (inits == DEAD_END) {
/*  408 */       return this;
/*      */     }
/*  410 */     UnconditionalFlowInfo otherInits = inits.unconditionalInits();
/*      */     
/*  412 */     this.potentialInits |= otherInits.potentialInits;
/*      */     
/*  414 */     if (this.extra != null) {
/*  415 */       if (otherInits.extra != null) {
/*      */         
/*  417 */         int i = 0; int length, otherLength;
/*  418 */         if ((length = (this.extra[0]).length) < (otherLength = (otherInits.extra[0]).length))
/*      */         {
/*  420 */           growSpace(otherLength, 0, length);
/*  421 */           for (; i < length; i++) {
/*  422 */             this.extra[1][i] = this.extra[1][i] | otherInits.extra[1][i];
/*      */           }
/*  424 */           for (; i < otherLength; i++) {
/*  425 */             this.extra[1][i] = otherInits.extra[1][i];
/*      */           }
/*      */         }
/*      */         else
/*      */         {
/*  430 */           for (; i < otherLength; i++) {
/*  431 */             this.extra[1][i] = this.extra[1][i] | otherInits.extra[1][i];
/*      */           }
/*      */         }
/*      */       
/*      */       } 
/*  436 */     } else if (otherInits.extra != null) {
/*      */       
/*  438 */       int otherLength = (otherInits.extra[0]).length;
/*  439 */       createExtraSpace(otherLength);
/*  440 */       System.arraycopy(otherInits.extra[1], 0, this.extra[1], 0, 
/*  441 */           otherLength);
/*      */     } 
/*  443 */     addPotentialNullInfoFrom(otherInits);
/*  444 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public UnconditionalFlowInfo addPotentialNullInfoFrom(UnconditionalFlowInfo otherInits) {
/*  460 */     if ((this.tagBits & 0x3) != 0 || (
/*  461 */       otherInits.tagBits & 0x3) != 0 || (
/*  462 */       otherInits.tagBits & 0x4) == 0) {
/*  463 */       return this;
/*      */     }
/*      */     
/*  466 */     boolean thisHadNulls = ((this.tagBits & 0x4) != 0);
/*  467 */     boolean thisHasNulls = false;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  472 */     if (thisHadNulls) {
/*  473 */       long a1, a2, a3, a4, na2, na3, na4, b1, b2, b3, b4, nb2, nb3, nb4; this.nullBit1 = (a1 = this.nullBit1) & ((
/*  474 */         a3 = this.nullBit3) & (a4 = this.nullBit4) & ((
/*  475 */         nb2 = (b2 = otherInits.nullBit2) ^ 0xFFFFFFFFFFFFFFFFL) & (
/*  476 */         nb4 = (b4 = otherInits.nullBit4) ^ 0xFFFFFFFFFFFFFFFFL) | (
/*  477 */         b1 = otherInits.nullBit1) & (b3 = otherInits.nullBit3)) | (
/*  478 */         na2 = (a2 = this.nullBit2) ^ 0xFFFFFFFFFFFFFFFFL) & (
/*  479 */         b1 & b3 | ((na4 = a4 ^ 0xFFFFFFFFFFFFFFFFL) | (na3 = a3 ^ 0xFFFFFFFFFFFFFFFFL)) & nb2) | 
/*  480 */         a2 & (na4 | na3) & ((nb3 = b3 ^ 0xFFFFFFFFFFFFFFFFL) & nb4 | b1 & b2)); long na1, nb1;
/*  481 */       this.nullBit2 = b2 & (nb3 | (nb1 = b1 ^ 0xFFFFFFFFFFFFFFFFL)) | 
/*  482 */         a2 & (nb3 & nb4 | b2 | na3 | (na1 = a1 ^ 0xFFFFFFFFFFFFFFFFL));
/*  483 */       this.nullBit3 = b3 & (nb1 & b2 | 
/*  484 */         a2 & (nb2 | a3) | 
/*  485 */         na1 & nb2 | 
/*  486 */         a1 & na2 & na4 & b1) | 
/*  487 */         a3 & (nb2 & nb4 | na2 & a4 | na1) | 
/*  488 */         a1 & na2 & na4 & b2;
/*  489 */       this.nullBit4 = na3 & (nb1 & nb3 & b4 | 
/*  490 */         a4 & (nb3 | b1 & b2)) | 
/*  491 */         nb2 & (na3 & b1 & nb3 | na2 & (nb1 & b4 | b1 & nb3 | a4)) | 
/*  492 */         a3 & (a4 & (nb2 | b1 & b3) | 
/*  493 */         a1 & a2 & (nb1 & b4 | na4 & (b2 | b1) & nb3));
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  500 */       if ((this.nullBit2 | this.nullBit3 | this.nullBit4) != 0L) {
/*  501 */         thisHasNulls = true;
/*      */       }
/*      */     } else {
/*  504 */       this.nullBit1 = 0L; long b1, b2, b3, nb1, nb3;
/*  505 */       this.nullBit2 = (b2 = otherInits.nullBit2) & ((
/*  506 */         nb3 = (b3 = otherInits.nullBit3) ^ 0xFFFFFFFFFFFFFFFFL) | (
/*  507 */         nb1 = (b1 = otherInits.nullBit1) ^ 0xFFFFFFFFFFFFFFFFL)); long nb2;
/*  508 */       this.nullBit3 = b3 & (nb1 | (nb2 = b2 ^ 0xFFFFFFFFFFFFFFFFL)); long b4;
/*  509 */       this.nullBit4 = (b1 ^ 0xFFFFFFFFFFFFFFFFL) & (b3 ^ 0xFFFFFFFFFFFFFFFFL) & (b4 = otherInits.nullBit4) | (b2 ^ 0xFFFFFFFFFFFFFFFFL) & (b1 & (b3 ^ 0xFFFFFFFFFFFFFFFFL) | (b1 ^ 0xFFFFFFFFFFFFFFFFL) & b4);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  516 */       if ((this.nullBit2 | this.nullBit3 | this.nullBit4) != 0L) {
/*  517 */         thisHasNulls = true;
/*      */       }
/*      */     } 
/*      */     
/*  521 */     if (otherInits.extra != null) {
/*  522 */       int mergeLimit = 0, copyLimit = (otherInits.extra[0]).length;
/*  523 */       if (this.extra == null) {
/*  524 */         createExtraSpace(copyLimit);
/*      */ 
/*      */       
/*      */       }
/*      */       else {
/*      */ 
/*      */         
/*  531 */         mergeLimit = copyLimit;
/*  532 */         if (mergeLimit > (this.extra[0]).length) {
/*  533 */           mergeLimit = (this.extra[0]).length;
/*  534 */           growSpace(copyLimit, 0, mergeLimit);
/*  535 */           if (!thisHadNulls) {
/*  536 */             mergeLimit = 0;
/*      */           }
/*      */         } 
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       int i;
/*      */ 
/*      */ 
/*      */       
/*  548 */       for (i = 0; i < mergeLimit; i++) {
/*  549 */         long a1, a2, a3, a4, na2, na3, na4, l1, l2, l3, l4, l6, l7, nb4; this.extra[2][i] = (a1 = this.extra[2][i]) & ((
/*  550 */           a3 = this.extra[4][i]) & (a4 = this.extra[5][i]) & ((
/*  551 */           l6 = (l2 = otherInits.extra[3][i]) ^ 0xFFFFFFFFFFFFFFFFL) & (
/*  552 */           nb4 = (l4 = otherInits.extra[5][i]) ^ 0xFFFFFFFFFFFFFFFFL) | (
/*  553 */           l1 = otherInits.extra[2][i]) & (l3 = otherInits.extra[4][i])) | (
/*  554 */           na2 = (a2 = this.extra[3][i]) ^ 0xFFFFFFFFFFFFFFFFL) & (
/*  555 */           l1 & l3 | ((na4 = a4 ^ 0xFFFFFFFFFFFFFFFFL) | (na3 = a3 ^ 0xFFFFFFFFFFFFFFFFL)) & l6) | 
/*  556 */           a2 & (na4 | na3) & ((l7 = l3 ^ 0xFFFFFFFFFFFFFFFFL) & nb4 | l1 & l2)); long na1, l5;
/*  557 */         this.extra[3][i] = l2 & (l7 | (l5 = l1 ^ 0xFFFFFFFFFFFFFFFFL)) | 
/*  558 */           a2 & (l7 & nb4 | l2 | na3 | (na1 = a1 ^ 0xFFFFFFFFFFFFFFFFL));
/*  559 */         this.extra[4][i] = l3 & (l5 & l2 | 
/*  560 */           a2 & (l6 | a3) | 
/*  561 */           na1 & l6 | 
/*  562 */           a1 & na2 & na4 & l1) | 
/*  563 */           a3 & (l6 & nb4 | na2 & a4 | na1) | 
/*  564 */           a1 & na2 & na4 & l2;
/*  565 */         this.extra[5][i] = na3 & (l5 & l7 & l4 | 
/*  566 */           a4 & (l7 | l1 & l2)) | 
/*  567 */           l6 & (na3 & l1 & l7 | na2 & (l5 & l4 | l1 & l7 | a4)) | 
/*  568 */           a3 & (a4 & (l6 | l1 & l3) | 
/*  569 */           a1 & a2 & (l5 & l4 | na4 & (l2 | l1) & l7));
/*      */         
/*  571 */         if ((this.extra[3][i] | this.extra[4][i] | this.extra[5][i]) != 0L) {
/*  572 */           thisHasNulls = true;
/*      */         }
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  580 */       for (; i < copyLimit; i++) {
/*  581 */         this.extra[2][i] = 0L; long l1, l2, l3, l5, l7;
/*  582 */         this.extra[3][i] = (l2 = otherInits.extra[3][i]) & ((
/*  583 */           l7 = (l3 = otherInits.extra[4][i]) ^ 0xFFFFFFFFFFFFFFFFL) | (
/*  584 */           l5 = (l1 = otherInits.extra[2][i]) ^ 0xFFFFFFFFFFFFFFFFL)); long l6;
/*  585 */         this.extra[4][i] = l3 & (l5 | (l6 = l2 ^ 0xFFFFFFFFFFFFFFFFL)); long l4;
/*  586 */         this.extra[5][i] = (l1 ^ 0xFFFFFFFFFFFFFFFFL) & (l3 ^ 0xFFFFFFFFFFFFFFFFL) & (l4 = otherInits.extra[5][i]) | (l2 ^ 0xFFFFFFFFFFFFFFFFL) & (l1 & (l3 ^ 0xFFFFFFFFFFFFFFFFL) | (l1 ^ 0xFFFFFFFFFFFFFFFFL) & l4);
/*      */         
/*  588 */         if ((this.extra[3][i] | this.extra[4][i] | this.extra[5][i]) != 0L) {
/*  589 */           thisHasNulls = true;
/*      */         }
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  598 */     if (thisHasNulls) {
/*  599 */       this.tagBits |= 0x4;
/*      */     } else {
/*      */       
/*  602 */       this.tagBits &= 0x4;
/*      */     } 
/*  604 */     return this;
/*      */   }
/*      */ 
/*      */   
/*      */   public final boolean cannotBeDefinitelyNullOrNonNull(LocalVariableBinding local) {
/*  609 */     if ((this.tagBits & 0x4) == 0 || (
/*  610 */       local.type.tagBits & 0x2L) != 0L) {
/*  611 */       return false;
/*      */     }
/*      */     int position;
/*  614 */     if ((position = local.id + this.maxFieldCount) < 64)
/*      */     {
/*  616 */       return ((((
/*  617 */         this.nullBit1 ^ 0xFFFFFFFFFFFFFFFFL) & (
/*  618 */         this.nullBit2 & this.nullBit3 | this.nullBit4) | (
/*  619 */         this.nullBit2 ^ 0xFFFFFFFFFFFFFFFFL) & (this.nullBit3 ^ 0xFFFFFFFFFFFFFFFFL) & this.nullBit4) & 
/*  620 */         1L << position) != 0L);
/*      */     }
/*      */     
/*  623 */     if (this.extra == null) {
/*  624 */       return false;
/*      */     }
/*      */     int vectorIndex;
/*  627 */     if ((vectorIndex = position / 64 - 1) >= (
/*  628 */       this.extra[0]).length)
/*  629 */       return false;  long a2;
/*      */     long a3;
/*      */     long a4;
/*  632 */     return ((((
/*  633 */       this.extra[2][vectorIndex] ^ 0xFFFFFFFFFFFFFFFFL) & ((
/*  634 */       a2 = this.extra[3][vectorIndex]) & (a3 = this.extra[4][vectorIndex]) | (a4 = this.extra[5][vectorIndex])) | (
/*  635 */       a2 ^ 0xFFFFFFFFFFFFFFFFL) & (a3 ^ 0xFFFFFFFFFFFFFFFFL) & a4) & 
/*  636 */       1L << position % 64) != 0L);
/*      */   }
/*      */ 
/*      */   
/*      */   public final boolean cannotBeNull(LocalVariableBinding local) {
/*  641 */     if ((this.tagBits & 0x4) == 0 || (
/*  642 */       local.type.tagBits & 0x2L) != 0L) {
/*  643 */       return false;
/*      */     }
/*      */     int position;
/*  646 */     if ((position = local.id + this.maxFieldCount) < 64)
/*      */     {
/*  648 */       return ((this.nullBit1 & this.nullBit3 & (
/*  649 */         this.nullBit2 & this.nullBit4 | this.nullBit2 ^ 0xFFFFFFFFFFFFFFFFL) & 
/*  650 */         1L << position) != 0L);
/*      */     }
/*      */     
/*  653 */     if (this.extra == null) {
/*  654 */       return false;
/*      */     }
/*      */     int vectorIndex;
/*  657 */     if ((vectorIndex = position / 64 - 1) >= (
/*  658 */       this.extra[0]).length) {
/*  659 */       return false;
/*      */     }
/*  661 */     return ((this.extra[2][vectorIndex] & this.extra[4][vectorIndex] & (
/*  662 */       this.extra[3][vectorIndex] & this.extra[5][vectorIndex] | 
/*  663 */       this.extra[3][vectorIndex] ^ 0xFFFFFFFFFFFFFFFFL) & 
/*  664 */       1L << position % 64) != 0L);
/*      */   }
/*      */ 
/*      */   
/*      */   public final boolean canOnlyBeNull(LocalVariableBinding local) {
/*  669 */     if ((this.tagBits & 0x4) == 0 || (
/*  670 */       local.type.tagBits & 0x2L) != 0L) {
/*  671 */       return false;
/*      */     }
/*      */     int position;
/*  674 */     if ((position = local.id + this.maxFieldCount) < 64)
/*      */     {
/*  676 */       return ((this.nullBit1 & this.nullBit2 & (
/*  677 */         this.nullBit3 ^ 0xFFFFFFFFFFFFFFFFL | this.nullBit4 ^ 0xFFFFFFFFFFFFFFFFL) & 
/*  678 */         1L << position) != 0L);
/*      */     }
/*      */     
/*  681 */     if (this.extra == null) {
/*  682 */       return false;
/*      */     }
/*      */     int vectorIndex;
/*  685 */     if ((vectorIndex = position / 64 - 1) >= (
/*  686 */       this.extra[0]).length) {
/*  687 */       return false;
/*      */     }
/*  689 */     return ((this.extra[2][vectorIndex] & this.extra[3][vectorIndex] & (
/*  690 */       this.extra[4][vectorIndex] ^ 0xFFFFFFFFFFFFFFFFL | this.extra[5][vectorIndex] ^ 0xFFFFFFFFFFFFFFFFL) & 
/*  691 */       1L << position % 64) != 0L);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public FlowInfo copy() {
/*  697 */     if (this == DEAD_END) {
/*  698 */       return this;
/*      */     }
/*  700 */     UnconditionalFlowInfo copy = new UnconditionalFlowInfo();
/*      */     
/*  702 */     copy.definiteInits = this.definiteInits;
/*  703 */     copy.potentialInits = this.potentialInits;
/*  704 */     boolean hasNullInfo = ((this.tagBits & 0x4) != 0);
/*  705 */     if (hasNullInfo) {
/*  706 */       copy.nullBit1 = this.nullBit1;
/*  707 */       copy.nullBit2 = this.nullBit2;
/*  708 */       copy.nullBit3 = this.nullBit3;
/*  709 */       copy.nullBit4 = this.nullBit4;
/*      */     } 
/*  711 */     copy.iNBit = this.iNBit;
/*  712 */     copy.iNNBit = this.iNNBit;
/*  713 */     copy.tagBits = this.tagBits;
/*  714 */     copy.maxFieldCount = this.maxFieldCount;
/*  715 */     if (this.extra != null) {
/*      */       
/*  717 */       copy.extra = new long[8][]; int length;
/*  718 */       System.arraycopy(this.extra[0], 0, 
/*  719 */           copy.extra[0] = new long[length = (this.extra[0]).length], 0, 
/*  720 */           length);
/*  721 */       System.arraycopy(this.extra[1], 0, 
/*  722 */           copy.extra[1] = new long[length], 0, length);
/*  723 */       if (hasNullInfo) {
/*  724 */         for (int j = 2; j < 6; j++) {
/*  725 */           System.arraycopy(this.extra[j], 0, 
/*  726 */               copy.extra[j] = new long[length], 0, length);
/*      */         }
/*      */       } else {
/*      */         
/*  730 */         for (int j = 2; j < 6; j++) {
/*  731 */           copy.extra[j] = new long[length];
/*      */         }
/*      */       } 
/*  734 */       System.arraycopy(this.extra[6], 0, copy.extra[6] = new long[length], 0, length);
/*  735 */       System.arraycopy(this.extra[7], 0, copy.extra[7] = new long[length], 0, length);
/*      */     } 
/*  737 */     return copy;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public UnconditionalFlowInfo discardInitializationInfo() {
/*  746 */     if (this == DEAD_END) {
/*  747 */       return this;
/*      */     }
/*  749 */     this.definiteInits = 
/*  750 */       this.potentialInits = 0L;
/*  751 */     if (this.extra != null) {
/*  752 */       for (int i = 0, length = (this.extra[0]).length; i < length; i++) {
/*  753 */         this.extra[1][i] = 0L; this.extra[0][i] = 0L;
/*      */       } 
/*      */     }
/*  756 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public UnconditionalFlowInfo discardNonFieldInitializations() {
/*  764 */     int limit = this.maxFieldCount;
/*  765 */     if (limit < 64) {
/*  766 */       long mask = (1L << limit) - 1L;
/*  767 */       this.definiteInits &= mask;
/*  768 */       this.potentialInits &= mask;
/*  769 */       this.nullBit1 &= mask;
/*  770 */       this.nullBit2 &= mask;
/*  771 */       this.nullBit3 &= mask;
/*  772 */       this.nullBit4 &= mask;
/*  773 */       this.iNBit &= mask;
/*  774 */       this.iNNBit &= mask;
/*      */     } 
/*      */     
/*  777 */     if (this.extra == null) {
/*  778 */       return this;
/*      */     }
/*  780 */     int length = (this.extra[0]).length; int vectorIndex;
/*  781 */     if ((vectorIndex = limit / 64 - 1) >= length) {
/*  782 */       return this;
/*      */     }
/*  784 */     if (vectorIndex >= 0) {
/*      */       
/*  786 */       long mask = (1L << limit % 64) - 1L;
/*  787 */       for (int j = 0; j < 8; j++) {
/*  788 */         this.extra[j][vectorIndex] = this.extra[j][vectorIndex] & mask;
/*      */       }
/*      */     } 
/*  791 */     for (int i = vectorIndex + 1; i < length; i++) {
/*  792 */       for (int j = 0; j < 8; j++) {
/*  793 */         this.extra[j][i] = 0L;
/*      */       }
/*      */     } 
/*  796 */     return this;
/*      */   }
/*      */ 
/*      */   
/*      */   public FlowInfo initsWhenFalse() {
/*  801 */     return this;
/*      */   }
/*      */ 
/*      */   
/*      */   public FlowInfo initsWhenTrue() {
/*  806 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final boolean isDefinitelyAssigned(int position) {
/*  815 */     if (position < 64)
/*      */     {
/*  817 */       return ((this.definiteInits & 1L << position) != 0L);
/*      */     }
/*      */     
/*  820 */     if (this.extra == null)
/*  821 */       return false; 
/*      */     int vectorIndex;
/*  823 */     if ((vectorIndex = position / 64 - 1) >= (
/*  824 */       this.extra[0]).length) {
/*  825 */       return false;
/*      */     }
/*  827 */     return ((this.extra[0][vectorIndex] & 
/*  828 */       1L << position % 64) != 0L);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final boolean isDefinitelyAssigned(FieldBinding field) {
/*  835 */     if ((this.tagBits & 0x1) != 0) {
/*  836 */       return true;
/*      */     }
/*  838 */     return isDefinitelyAssigned(field.id);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public final boolean isDefinitelyAssigned(LocalVariableBinding local) {
/*  844 */     if ((this.tagBits & 0x1) != 0 && (local.declaration.bits & 0x40000000) != 0) {
/*  845 */       return true;
/*      */     }
/*  847 */     return isDefinitelyAssigned(local.id + this.maxFieldCount);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public final boolean isDefinitelyNonNull(LocalVariableBinding local) {
/*  853 */     if ((this.tagBits & 0x3) != 0 || (
/*  854 */       this.tagBits & 0x4) == 0) {
/*  855 */       return false;
/*      */     }
/*  857 */     if ((local.type.tagBits & 0x2L) != 0L || 
/*  858 */       local.constant() != Constant.NotAConstant) {
/*  859 */       return true;
/*      */     }
/*  861 */     int position = local.id + this.maxFieldCount;
/*  862 */     if (position < 64) {
/*  863 */       return ((this.nullBit1 & this.nullBit3 & (this.nullBit2 ^ 0xFFFFFFFFFFFFFFFFL | this.nullBit4) & 
/*  864 */         1L << position) != 0L);
/*      */     }
/*      */     
/*  867 */     if (this.extra == null) {
/*  868 */       return false;
/*      */     }
/*      */     int vectorIndex;
/*  871 */     if ((vectorIndex = position / 64 - 1) >= (
/*  872 */       this.extra[2]).length) {
/*  873 */       return false;
/*      */     }
/*  875 */     return ((this.extra[2][vectorIndex] & this.extra[4][vectorIndex] & (
/*  876 */       this.extra[3][vectorIndex] ^ 0xFFFFFFFFFFFFFFFFL | this.extra[5][vectorIndex]) & 
/*  877 */       1L << position % 64) != 0L);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public final boolean isDefinitelyNull(LocalVariableBinding local) {
/*  883 */     if ((this.tagBits & 0x3) != 0 || (
/*  884 */       this.tagBits & 0x4) == 0 || (
/*  885 */       local.type.tagBits & 0x2L) != 0L) {
/*  886 */       return false;
/*      */     }
/*  888 */     int position = local.id + this.maxFieldCount;
/*  889 */     if (position < 64) {
/*  890 */       return ((this.nullBit1 & this.nullBit2 & (
/*  891 */         this.nullBit3 ^ 0xFFFFFFFFFFFFFFFFL | this.nullBit4 ^ 0xFFFFFFFFFFFFFFFFL) & 
/*  892 */         1L << position) != 0L);
/*      */     }
/*      */     
/*  895 */     if (this.extra == null) {
/*  896 */       return false;
/*      */     }
/*      */     int vectorIndex;
/*  899 */     if ((vectorIndex = position / 64 - 1) >= (
/*  900 */       this.extra[2]).length) {
/*  901 */       return false;
/*      */     }
/*  903 */     return ((this.extra[2][vectorIndex] & this.extra[3][vectorIndex] & (
/*  904 */       this.extra[4][vectorIndex] ^ 0xFFFFFFFFFFFFFFFFL | this.extra[5][vectorIndex] ^ 0xFFFFFFFFFFFFFFFFL) & 
/*  905 */       1L << position % 64) != 0L);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public final boolean isDefinitelyUnknown(LocalVariableBinding local) {
/*  911 */     if ((this.tagBits & 0x3) != 0 || (
/*  912 */       this.tagBits & 0x4) == 0) {
/*  913 */       return false;
/*      */     }
/*  915 */     int position = local.id + this.maxFieldCount;
/*  916 */     if (position < 64) {
/*  917 */       return ((this.nullBit1 & this.nullBit4 & (
/*  918 */         this.nullBit2 ^ 0xFFFFFFFFFFFFFFFFL) & (this.nullBit3 ^ 0xFFFFFFFFFFFFFFFFL) & 1L << position) != 0L);
/*      */     }
/*      */     
/*  921 */     if (this.extra == null) {
/*  922 */       return false;
/*      */     }
/*      */     int vectorIndex;
/*  925 */     if ((vectorIndex = position / 64 - 1) >= (
/*  926 */       this.extra[2]).length) {
/*  927 */       return false;
/*      */     }
/*  929 */     return ((this.extra[2][vectorIndex] & this.extra[5][vectorIndex] & (
/*  930 */       this.extra[3][vectorIndex] ^ 0xFFFFFFFFFFFFFFFFL) & (this.extra[4][vectorIndex] ^ 0xFFFFFFFFFFFFFFFFL) & 
/*  931 */       1L << position % 64) != 0L);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public final boolean hasNullInfoFor(LocalVariableBinding local) {
/*  937 */     if ((this.tagBits & 0x3) != 0 || (
/*  938 */       this.tagBits & 0x4) == 0) {
/*  939 */       return false;
/*      */     }
/*  941 */     int position = local.id + this.maxFieldCount;
/*  942 */     if (position < 64) {
/*  943 */       return (((this.nullBit1 | this.nullBit2 | 
/*  944 */         this.nullBit3 | this.nullBit4) & 1L << position) != 0L);
/*      */     }
/*      */     
/*  947 */     if (this.extra == null) {
/*  948 */       return false;
/*      */     }
/*      */     int vectorIndex;
/*  951 */     if ((vectorIndex = position / 64 - 1) >= (
/*  952 */       this.extra[2]).length) {
/*  953 */       return false;
/*      */     }
/*  955 */     return (((this.extra[2][vectorIndex] | this.extra[3][vectorIndex] | 
/*  956 */       this.extra[4][vectorIndex] | this.extra[5][vectorIndex]) & 
/*  957 */       1L << position % 64) != 0L);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final boolean isPotentiallyAssigned(int position) {
/*  965 */     if (position < 64)
/*      */     {
/*  967 */       return ((this.potentialInits & 1L << position) != 0L);
/*      */     }
/*      */     
/*  970 */     if (this.extra == null) {
/*  971 */       return false;
/*      */     }
/*      */     int vectorIndex;
/*  974 */     if ((vectorIndex = position / 64 - 1) >= (
/*  975 */       this.extra[0]).length) {
/*  976 */       return false;
/*      */     }
/*  978 */     return ((this.extra[1][vectorIndex] & 
/*  979 */       1L << position % 64) != 0L);
/*      */   }
/*      */ 
/*      */   
/*      */   public final boolean isPotentiallyAssigned(FieldBinding field) {
/*  984 */     return isPotentiallyAssigned(field.id);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public final boolean isPotentiallyAssigned(LocalVariableBinding local) {
/*  990 */     if (local.constant() != Constant.NotAConstant) {
/*  991 */       return true;
/*      */     }
/*  993 */     return isPotentiallyAssigned(local.id + this.maxFieldCount);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public final boolean isPotentiallyNonNull(LocalVariableBinding local) {
/*  999 */     if ((this.tagBits & 0x4) == 0 || (
/* 1000 */       local.type.tagBits & 0x2L) != 0L) {
/* 1001 */       return false;
/*      */     }
/*      */     int position;
/* 1004 */     if ((position = local.id + this.maxFieldCount) < 64)
/*      */     {
/* 1006 */       return ((this.nullBit3 & (this.nullBit1 ^ 0xFFFFFFFFFFFFFFFFL | this.nullBit2 ^ 0xFFFFFFFFFFFFFFFFL) & 
/* 1007 */         1L << position) != 0L);
/*      */     }
/*      */     
/* 1010 */     if (this.extra == null) {
/* 1011 */       return false;
/*      */     }
/*      */     int vectorIndex;
/* 1014 */     if ((vectorIndex = position / 64 - 1) >= (
/* 1015 */       this.extra[2]).length) {
/* 1016 */       return false;
/*      */     }
/* 1018 */     return ((this.extra[4][vectorIndex] & (
/* 1019 */       this.extra[2][vectorIndex] ^ 0xFFFFFFFFFFFFFFFFL | this.extra[3][vectorIndex] ^ 0xFFFFFFFFFFFFFFFFL) & 
/* 1020 */       1L << position % 64) != 0L);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public final boolean isPotentiallyNull(LocalVariableBinding local) {
/* 1026 */     if ((this.tagBits & 0x4) == 0 || (
/* 1027 */       local.type.tagBits & 0x2L) != 0L) {
/* 1028 */       return false;
/*      */     }
/*      */     int position;
/* 1031 */     if ((position = local.id + this.maxFieldCount) < 64)
/*      */     {
/* 1033 */       return ((this.nullBit2 & (this.nullBit1 ^ 0xFFFFFFFFFFFFFFFFL | this.nullBit3 ^ 0xFFFFFFFFFFFFFFFFL) & 
/* 1034 */         1L << position) != 0L);
/*      */     }
/*      */     
/* 1037 */     if (this.extra == null) {
/* 1038 */       return false;
/*      */     }
/*      */     int vectorIndex;
/* 1041 */     if ((vectorIndex = position / 64 - 1) >= (
/* 1042 */       this.extra[2]).length) {
/* 1043 */       return false;
/*      */     }
/* 1045 */     return ((this.extra[3][vectorIndex] & (
/* 1046 */       this.extra[2][vectorIndex] ^ 0xFFFFFFFFFFFFFFFFL | this.extra[4][vectorIndex] ^ 0xFFFFFFFFFFFFFFFFL) & 
/* 1047 */       1L << position % 64) != 0L);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public final boolean isPotentiallyUnknown(LocalVariableBinding local) {
/* 1053 */     if ((this.tagBits & 0x3) != 0 || (
/* 1054 */       this.tagBits & 0x4) == 0) {
/* 1055 */       return false;
/*      */     }
/* 1057 */     int position = local.id + this.maxFieldCount;
/* 1058 */     if (position < 64) {
/* 1059 */       return ((this.nullBit4 & (
/* 1060 */         this.nullBit1 ^ 0xFFFFFFFFFFFFFFFFL | (this.nullBit2 ^ 0xFFFFFFFFFFFFFFFFL) & (this.nullBit3 ^ 0xFFFFFFFFFFFFFFFFL)) & 
/* 1061 */         1L << position) != 0L);
/*      */     }
/*      */     
/* 1064 */     if (this.extra == null) {
/* 1065 */       return false;
/*      */     }
/*      */     int vectorIndex;
/* 1068 */     if ((vectorIndex = position / 64 - 1) >= (
/* 1069 */       this.extra[2]).length) {
/* 1070 */       return false;
/*      */     }
/* 1072 */     return ((this.extra[5][vectorIndex] & (
/* 1073 */       this.extra[2][vectorIndex] ^ 0xFFFFFFFFFFFFFFFFL | (
/* 1074 */       this.extra[3][vectorIndex] ^ 0xFFFFFFFFFFFFFFFFL) & (this.extra[4][vectorIndex] ^ 0xFFFFFFFFFFFFFFFFL)) & 
/* 1075 */       1L << position % 64) != 0L);
/*      */   }
/*      */ 
/*      */   
/*      */   public final boolean isProtectedNonNull(LocalVariableBinding local) {
/* 1080 */     if ((this.tagBits & 0x4) == 0 || (
/* 1081 */       local.type.tagBits & 0x2L) != 0L) {
/* 1082 */       return false;
/*      */     }
/*      */     int position;
/* 1085 */     if ((position = local.id + this.maxFieldCount) < 64)
/*      */     {
/* 1087 */       return ((this.nullBit1 & this.nullBit3 & this.nullBit4 & 1L << position) != 0L);
/*      */     }
/*      */     
/* 1090 */     if (this.extra == null) {
/* 1091 */       return false;
/*      */     }
/*      */     int vectorIndex;
/* 1094 */     if ((vectorIndex = position / 64 - 1) >= (
/* 1095 */       this.extra[0]).length) {
/* 1096 */       return false;
/*      */     }
/* 1098 */     return ((this.extra[2][vectorIndex] & 
/* 1099 */       this.extra[4][vectorIndex] & 
/* 1100 */       this.extra[5][vectorIndex] & 
/* 1101 */       1L << position % 64) != 0L);
/*      */   }
/*      */ 
/*      */   
/*      */   public final boolean isProtectedNull(LocalVariableBinding local) {
/* 1106 */     if ((this.tagBits & 0x4) == 0 || (
/* 1107 */       local.type.tagBits & 0x2L) != 0L) {
/* 1108 */       return false;
/*      */     }
/*      */     int position;
/* 1111 */     if ((position = local.id + this.maxFieldCount) < 64)
/*      */     {
/* 1113 */       return ((this.nullBit1 & this.nullBit2 & (
/* 1114 */         this.nullBit3 ^ this.nullBit4) & 
/* 1115 */         1L << position) != 0L);
/*      */     }
/*      */     
/* 1118 */     if (this.extra == null) {
/* 1119 */       return false;
/*      */     }
/*      */     int vectorIndex;
/* 1122 */     if ((vectorIndex = position / 64 - 1) >= (
/* 1123 */       this.extra[0]).length) {
/* 1124 */       return false;
/*      */     }
/* 1126 */     return ((this.extra[2][vectorIndex] & this.extra[3][vectorIndex] & (
/* 1127 */       this.extra[4][vectorIndex] ^ this.extra[5][vectorIndex]) & 
/* 1128 */       1L << position % 64) != 0L);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected static boolean isTrue(boolean expression, String message) {
/* 1140 */     if (!expression)
/* 1141 */       throw new AssertionFailedException("assertion failed: " + message); 
/* 1142 */     return expression;
/*      */   }
/*      */ 
/*      */   
/*      */   public void markAsComparedEqualToNonNull(LocalVariableBinding local) {
/* 1147 */     if (this != DEAD_END) {
/* 1148 */       this.tagBits |= 0x4;
/*      */ 
/*      */       
/*      */       int position;
/*      */       
/* 1153 */       if ((position = local.id + this.maxFieldCount) < 64) {
/*      */         long mask; long a1; long a2; long a3; long a4; long na2;
/* 1155 */         if (((mask = 1L << position) & (
/* 1156 */           a1 = this.nullBit1) & (
/* 1157 */           na2 = (a2 = this.nullBit2) ^ 0xFFFFFFFFFFFFFFFFL) & ((
/* 1158 */           a3 = this.nullBit3) ^ 0xFFFFFFFFFFFFFFFFL) & (
/* 1159 */           a4 = this.nullBit4)) != 
/* 1160 */           0L) {
/* 1161 */           this.nullBit4 &= mask ^ 0xFFFFFFFFFFFFFFFFL;
/* 1162 */         } else if ((mask & a1 & na2 & a3) == 0L) {
/* 1163 */           this.nullBit4 |= mask;
/* 1164 */           if ((mask & a1) == 0L) {
/* 1165 */             if ((mask & a2 & (a3 ^ a4)) != 0L) {
/* 1166 */               this.nullBit2 &= mask ^ 0xFFFFFFFFFFFFFFFFL;
/*      */             }
/* 1168 */             else if ((mask & (a2 | a3 | a4)) == 0L) {
/* 1169 */               this.nullBit2 |= mask;
/*      */             } 
/*      */           }
/*      */         } 
/* 1173 */         this.nullBit1 |= mask;
/* 1174 */         this.nullBit3 |= mask;
/*      */         
/* 1176 */         this.iNBit &= mask ^ 0xFFFFFFFFFFFFFFFFL;
/*      */ 
/*      */ 
/*      */       
/*      */       }
/*      */       else {
/*      */ 
/*      */ 
/*      */         
/* 1185 */         int vectorIndex = position / 64 - 1;
/* 1186 */         if (this.extra == null) {
/* 1187 */           int length = vectorIndex + 1;
/* 1188 */           createExtraSpace(length);
/*      */         } else {
/*      */           int oldLength;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 1197 */           if (vectorIndex >= (oldLength = (this.extra[0]).length)) {
/* 1198 */             growSpace(vectorIndex + 1, 0, oldLength);
/*      */           }
/*      */         } 
/*      */ 
/*      */ 
/*      */         
/*      */         long mask, a1, a2, a3, a4, na2;
/*      */ 
/*      */         
/* 1207 */         if (((mask = 1L << position % 64) & (
/* 1208 */           a1 = this.extra[2][vectorIndex]) & (
/* 1209 */           na2 = (a2 = this.extra[3][vectorIndex]) ^ 0xFFFFFFFFFFFFFFFFL) & ((
/* 1210 */           a3 = this.extra[4][vectorIndex]) ^ 0xFFFFFFFFFFFFFFFFL) & (
/* 1211 */           a4 = this.extra[5][vectorIndex])) != 
/* 1212 */           0L) {
/* 1213 */           this.extra[5][vectorIndex] = this.extra[5][vectorIndex] & (mask ^ 0xFFFFFFFFFFFFFFFFL);
/* 1214 */         } else if ((mask & a1 & na2 & a3) == 0L) {
/* 1215 */           this.extra[5][vectorIndex] = this.extra[5][vectorIndex] | mask;
/* 1216 */           if ((mask & a1) == 0L) {
/* 1217 */             if ((mask & a2 & (a3 ^ a4)) != 0L) {
/* 1218 */               this.extra[3][vectorIndex] = this.extra[3][vectorIndex] & (mask ^ 0xFFFFFFFFFFFFFFFFL);
/*      */             }
/* 1220 */             else if ((mask & (a2 | a3 | a4)) == 0L) {
/* 1221 */               this.extra[3][vectorIndex] = this.extra[3][vectorIndex] | mask;
/*      */             } 
/*      */           }
/*      */         } 
/* 1225 */         this.extra[2][vectorIndex] = this.extra[2][vectorIndex] | mask;
/* 1226 */         this.extra[4][vectorIndex] = this.extra[4][vectorIndex] | mask;
/*      */         
/* 1228 */         this.extra[6][vectorIndex] = this.extra[6][vectorIndex] & (mask ^ 0xFFFFFFFFFFFFFFFFL);
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void markAsComparedEqualToNull(LocalVariableBinding local) {
/* 1241 */     if (this != DEAD_END) {
/* 1242 */       this.tagBits |= 0x4;
/*      */       
/*      */       int position;
/*      */       
/* 1246 */       if ((position = local.id + this.maxFieldCount) < 64) {
/*      */         long mask;
/* 1248 */         if (((mask = 1L << position) & this.nullBit1) != 0L) {
/* 1249 */           if ((mask & (
/* 1250 */             this.nullBit2 ^ 0xFFFFFFFFFFFFFFFFL | this.nullBit3 | 
/* 1251 */             this.nullBit4 ^ 0xFFFFFFFFFFFFFFFFL)) != 0L) {
/* 1252 */             this.nullBit4 &= mask ^ 0xFFFFFFFFFFFFFFFFL;
/*      */           }
/* 1254 */         } else if ((mask & this.nullBit4) != 0L) {
/* 1255 */           this.nullBit3 &= mask ^ 0xFFFFFFFFFFFFFFFFL;
/*      */         }
/* 1257 */         else if ((mask & this.nullBit2) != 0L) {
/* 1258 */           this.nullBit3 &= mask ^ 0xFFFFFFFFFFFFFFFFL;
/* 1259 */           this.nullBit4 |= mask;
/*      */         } else {
/* 1261 */           this.nullBit3 |= mask;
/*      */         } 
/*      */         
/* 1264 */         this.nullBit1 |= mask;
/* 1265 */         this.nullBit2 |= mask;
/*      */         
/* 1267 */         this.iNNBit &= mask ^ 0xFFFFFFFFFFFFFFFFL;
/*      */ 
/*      */ 
/*      */       
/*      */       }
/*      */       else {
/*      */ 
/*      */ 
/*      */         
/* 1276 */         int vectorIndex = position / 64 - 1;
/* 1277 */         long mask = 1L << position % 64;
/* 1278 */         if (this.extra == null) {
/* 1279 */           int length = vectorIndex + 1;
/* 1280 */           createExtraSpace(length);
/*      */         } else {
/*      */           int oldLength;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 1289 */           if (vectorIndex >= (oldLength = (this.extra[0]).length)) {
/* 1290 */             growSpace(vectorIndex + 1, 0, oldLength);
/*      */           }
/*      */         } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1298 */         if ((mask & this.extra[2][vectorIndex]) != 0L) {
/* 1299 */           if ((mask & (
/* 1300 */             this.extra[3][vectorIndex] ^ 0xFFFFFFFFFFFFFFFFL | this.extra[4][vectorIndex] | 
/* 1301 */             this.extra[5][vectorIndex] ^ 0xFFFFFFFFFFFFFFFFL)) != 0L) {
/* 1302 */             this.extra[5][vectorIndex] = this.extra[5][vectorIndex] & (mask ^ 0xFFFFFFFFFFFFFFFFL);
/*      */           }
/* 1304 */         } else if ((mask & this.extra[5][vectorIndex]) != 0L) {
/* 1305 */           this.extra[4][vectorIndex] = this.extra[4][vectorIndex] & (mask ^ 0xFFFFFFFFFFFFFFFFL);
/*      */         }
/* 1307 */         else if ((mask & this.extra[3][vectorIndex]) != 0L) {
/* 1308 */           this.extra[4][vectorIndex] = this.extra[4][vectorIndex] & (mask ^ 0xFFFFFFFFFFFFFFFFL);
/* 1309 */           this.extra[5][vectorIndex] = this.extra[5][vectorIndex] | mask;
/*      */         } else {
/* 1311 */           this.extra[4][vectorIndex] = this.extra[4][vectorIndex] | mask;
/*      */         } 
/*      */         
/* 1314 */         this.extra[2][vectorIndex] = this.extra[2][vectorIndex] | mask;
/* 1315 */         this.extra[3][vectorIndex] = this.extra[3][vectorIndex] | mask;
/*      */         
/* 1317 */         this.extra[7][vectorIndex] = this.extra[7][vectorIndex] & (mask ^ 0xFFFFFFFFFFFFFFFFL);
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final void markAsDefinitelyAssigned(int position) {
/* 1327 */     if (this != DEAD_END) {
/*      */       long mask;
/*      */ 
/*      */ 
/*      */       
/* 1332 */       this.definiteInits |= mask = 1L << position;
/* 1333 */       this.potentialInits |= mask;
/*      */ 
/*      */ 
/*      */       
/* 1337 */       int vectorIndex = position / 64 - 1;
/* 1338 */       if (this.extra == null) {
/* 1339 */         int length = vectorIndex + 1;
/* 1340 */         createExtraSpace(length);
/*      */       } else {
/*      */         int oldLength;
/*      */         
/* 1344 */         if (vectorIndex >= (oldLength = (this.extra[0]).length)) {
/* 1345 */           growSpace(vectorIndex + 1, 0, oldLength);
/*      */         }
/*      */       } 
/*      */       long l1;
/* 1349 */       this.extra[0][vectorIndex] = this.extra[0][vectorIndex] | (
/* 1350 */         l1 = 1L << position % 64);
/* 1351 */       this.extra[1][vectorIndex] = this.extra[1][vectorIndex] | l1;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void markAsDefinitelyAssigned(FieldBinding field) {
/* 1358 */     if (this != DEAD_END) {
/* 1359 */       markAsDefinitelyAssigned(field.id);
/*      */     }
/*      */   }
/*      */   
/*      */   public void markAsDefinitelyAssigned(LocalVariableBinding local) {
/* 1364 */     if (this != DEAD_END) {
/* 1365 */       markAsDefinitelyAssigned(local.id + this.maxFieldCount);
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   public void markAsDefinitelyNonNull(LocalVariableBinding local) {
/* 1371 */     if (this != DEAD_END) {
/* 1372 */       int position; this.tagBits |= 0x4;
/*      */ 
/*      */       
/*      */       long mask;
/*      */ 
/*      */       
/* 1378 */       this.nullBit1 |= mask = 1L << position;
/* 1379 */       this.nullBit3 |= mask;
/*      */       
/* 1381 */       this.nullBit2 &= mask ^= 0xFFFFFFFFFFFFFFFFL;
/* 1382 */       this.nullBit4 &= mask;
/*      */       
/* 1384 */       this.iNBit &= mask;
/* 1385 */       this.iNNBit &= mask;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1394 */       int vectorIndex = position / 64 - 1;
/* 1395 */       if (this.extra == null) {
/* 1396 */         int length = vectorIndex + 1;
/* 1397 */         createExtraSpace(length);
/*      */       } else {
/*      */         int oldLength;
/*      */         
/* 1401 */         if (vectorIndex >= (oldLength = (this.extra[0]).length)) {
/* 1402 */           growSpace(vectorIndex + 1, 0, oldLength);
/*      */         }
/*      */       } 
/* 1405 */       this.extra[2][vectorIndex] = this.extra[2][vectorIndex] | (
/* 1406 */         mask = 1L << position % 64);
/* 1407 */       this.extra[4][vectorIndex] = this.extra[4][vectorIndex] | mask;
/* 1408 */       this.extra[3][vectorIndex] = this.extra[3][vectorIndex] & (mask ^= 0xFFFFFFFFFFFFFFFFL);
/* 1409 */       this.extra[5][vectorIndex] = this.extra[5][vectorIndex] & mask;
/*      */       
/* 1411 */       this.extra[6][vectorIndex] = this.extra[6][vectorIndex] & mask;
/* 1412 */       this.extra[7][vectorIndex] = this.extra[7][vectorIndex] & mask;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void markAsDefinitelyNull(LocalVariableBinding local) {
/* 1425 */     if (this != DEAD_END) {
/* 1426 */       int position; this.tagBits |= 0x4;
/*      */ 
/*      */       
/*      */       long mask;
/*      */ 
/*      */       
/* 1432 */       this.nullBit1 |= mask = 1L << position;
/* 1433 */       this.nullBit2 |= mask;
/*      */       
/* 1435 */       this.nullBit3 &= mask ^= 0xFFFFFFFFFFFFFFFFL;
/* 1436 */       this.nullBit4 &= mask;
/*      */       
/* 1438 */       this.iNBit &= mask;
/* 1439 */       this.iNNBit &= mask;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1448 */       int vectorIndex = position / 64 - 1;
/* 1449 */       if (this.extra == null) {
/* 1450 */         int length = vectorIndex + 1;
/* 1451 */         createExtraSpace(length);
/*      */       } else {
/*      */         int oldLength;
/*      */         
/* 1455 */         if (vectorIndex >= (oldLength = (this.extra[0]).length)) {
/* 1456 */           growSpace(vectorIndex + 1, 0, oldLength);
/*      */         }
/*      */       } 
/* 1459 */       this.extra[2][vectorIndex] = this.extra[2][vectorIndex] | (
/* 1460 */         mask = 1L << position % 64);
/* 1461 */       this.extra[3][vectorIndex] = this.extra[3][vectorIndex] | mask;
/* 1462 */       this.extra[4][vectorIndex] = this.extra[4][vectorIndex] & (mask ^= 0xFFFFFFFFFFFFFFFFL);
/* 1463 */       this.extra[5][vectorIndex] = this.extra[5][vectorIndex] & mask;
/*      */       
/* 1465 */       this.extra[6][vectorIndex] = this.extra[6][vectorIndex] & mask;
/* 1466 */       this.extra[7][vectorIndex] = this.extra[7][vectorIndex] & mask;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void markAsDefinitelyUnknown(LocalVariableBinding local) {
/* 1485 */     if (this != DEAD_END) {
/* 1486 */       int position; this.tagBits |= 0x4;
/*      */ 
/*      */ 
/*      */       
/*      */       long mask;
/*      */ 
/*      */       
/* 1493 */       this.nullBit1 |= mask = 1L << position;
/* 1494 */       this.nullBit4 |= mask;
/*      */       
/* 1496 */       this.nullBit2 &= mask ^= 0xFFFFFFFFFFFFFFFFL;
/* 1497 */       this.nullBit3 &= mask;
/*      */       
/* 1499 */       this.iNBit &= mask;
/* 1500 */       this.iNNBit &= mask;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1509 */       int vectorIndex = position / 64 - 1;
/* 1510 */       if (this.extra == null) {
/* 1511 */         int length = vectorIndex + 1;
/* 1512 */         createExtraSpace(length);
/*      */       } else {
/*      */         int oldLength;
/*      */         
/* 1516 */         if (vectorIndex >= (oldLength = (this.extra[0]).length)) {
/* 1517 */           growSpace(vectorIndex + 1, 0, oldLength);
/*      */         }
/*      */       } 
/* 1520 */       this.extra[2][vectorIndex] = this.extra[2][vectorIndex] | (
/* 1521 */         mask = 1L << position % 64);
/* 1522 */       this.extra[5][vectorIndex] = this.extra[5][vectorIndex] | mask;
/* 1523 */       this.extra[3][vectorIndex] = this.extra[3][vectorIndex] & (mask ^= 0xFFFFFFFFFFFFFFFFL);
/* 1524 */       this.extra[4][vectorIndex] = this.extra[4][vectorIndex] & mask;
/*      */       
/* 1526 */       this.extra[6][vectorIndex] = this.extra[6][vectorIndex] & mask;
/* 1527 */       this.extra[7][vectorIndex] = this.extra[7][vectorIndex] & mask;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void resetNullInfo(LocalVariableBinding local) {
/* 1539 */     if (this != DEAD_END) {
/* 1540 */       int position; this.tagBits |= 0x4;
/*      */ 
/*      */       
/*      */       long mask;
/*      */       
/* 1545 */       this.nullBit1 &= mask = 1L << position ^ 0xFFFFFFFFFFFFFFFFL;
/* 1546 */       this.nullBit2 &= mask;
/* 1547 */       this.nullBit3 &= mask;
/* 1548 */       this.nullBit4 &= mask;
/* 1549 */       this.iNBit &= mask;
/* 1550 */       this.iNNBit &= mask;
/*      */ 
/*      */       
/* 1553 */       int vectorIndex = position / 64 - 1;
/* 1554 */       if (this.extra == null || vectorIndex >= (this.extra[2]).length) {
/*      */         return;
/*      */       }
/*      */ 
/*      */       
/* 1559 */       this.extra[2][vectorIndex] = this.extra[2][vectorIndex] & (
/* 1560 */         mask = 1L << position % 64 ^ 0xFFFFFFFFFFFFFFFFL);
/* 1561 */       this.extra[3][vectorIndex] = this.extra[3][vectorIndex] & mask;
/* 1562 */       this.extra[4][vectorIndex] = this.extra[4][vectorIndex] & mask;
/* 1563 */       this.extra[5][vectorIndex] = this.extra[5][vectorIndex] & mask;
/* 1564 */       this.extra[6][vectorIndex] = this.extra[6][vectorIndex] & mask;
/* 1565 */       this.extra[7][vectorIndex] = this.extra[7][vectorIndex] & mask;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void markPotentiallyUnknownBit(LocalVariableBinding local) {
/* 1577 */     if (this != DEAD_END) {
/* 1578 */       this.tagBits |= 0x4;
/*      */       
/*      */       int position;
/* 1581 */       if ((position = local.id + this.maxFieldCount) < 64) {
/*      */         
/* 1583 */         long mask = 1L << position;
/* 1584 */         isTrue(((this.nullBit1 & mask) == 0L), "Adding 'unknown' mark in unexpected state");
/* 1585 */         this.nullBit4 |= mask;
/*      */ 
/*      */       
/*      */       }
/*      */       else {
/*      */ 
/*      */ 
/*      */         
/* 1593 */         int vectorIndex = position / 64 - 1;
/* 1594 */         if (this.extra == null) {
/* 1595 */           int length = vectorIndex + 1;
/* 1596 */           createExtraSpace(length);
/*      */         } else {
/*      */           int oldLength;
/*      */           
/* 1600 */           if (vectorIndex >= (oldLength = (this.extra[0]).length)) {
/* 1601 */             growSpace(vectorIndex + 1, 0, oldLength);
/*      */           }
/*      */         } 
/* 1604 */         long mask = 1L << position % 64;
/* 1605 */         isTrue(((this.extra[2][vectorIndex] & mask) == 0L), "Adding 'unknown' mark in unexpected state");
/* 1606 */         this.extra[5][vectorIndex] = this.extra[5][vectorIndex] | mask;
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void markPotentiallyNullBit(LocalVariableBinding local) {
/* 1621 */     if (this != DEAD_END) {
/* 1622 */       this.tagBits |= 0x4;
/*      */       
/*      */       int position;
/* 1625 */       if ((position = local.id + this.maxFieldCount) < 64) {
/*      */         
/* 1627 */         long mask = 1L << position;
/* 1628 */         isTrue(((this.nullBit1 & mask) == 0L), "Adding 'potentially null' mark in unexpected state");
/* 1629 */         this.nullBit2 |= mask;
/*      */ 
/*      */       
/*      */       }
/*      */       else {
/*      */ 
/*      */ 
/*      */         
/* 1637 */         int vectorIndex = position / 64 - 1;
/* 1638 */         if (this.extra == null) {
/* 1639 */           int length = vectorIndex + 1;
/* 1640 */           createExtraSpace(length);
/*      */         } else {
/*      */           int oldLength;
/*      */           
/* 1644 */           if (vectorIndex >= (oldLength = (this.extra[0]).length)) {
/* 1645 */             growSpace(vectorIndex + 1, 0, oldLength);
/*      */           }
/*      */         } 
/* 1648 */         long mask = 1L << position % 64;
/* 1649 */         this.extra[3][vectorIndex] = this.extra[3][vectorIndex] | mask;
/* 1650 */         isTrue(((this.extra[2][vectorIndex] & mask) == 0L), "Adding 'potentially null' mark in unexpected state");
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void markPotentiallyNonNullBit(LocalVariableBinding local) {
/* 1662 */     if (this != DEAD_END) {
/* 1663 */       this.tagBits |= 0x4;
/*      */       
/*      */       int position;
/* 1666 */       if ((position = local.id + this.maxFieldCount) < 64) {
/*      */         
/* 1668 */         long mask = 1L << position;
/* 1669 */         isTrue(((this.nullBit1 & mask) == 0L), "Adding 'potentially non-null' mark in unexpected state");
/* 1670 */         this.nullBit3 |= mask;
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       }
/*      */       else {
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1681 */         int vectorIndex = position / 64 - 1;
/* 1682 */         if (this.extra == null) {
/* 1683 */           int length = vectorIndex + 1;
/* 1684 */           createExtraSpace(length);
/*      */         } else {
/*      */           int oldLength;
/*      */           
/* 1688 */           if (vectorIndex >= (oldLength = (this.extra[0]).length)) {
/* 1689 */             growSpace(vectorIndex + 1, 0, oldLength);
/*      */           }
/*      */         } 
/* 1692 */         long mask = 1L << position % 64;
/* 1693 */         isTrue(((this.extra[2][vectorIndex] & mask) == 0L), "Adding 'potentially non-null' mark in unexpected state");
/* 1694 */         this.extra[4][vectorIndex] = this.extra[4][vectorIndex] | mask;
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public UnconditionalFlowInfo mergedWith(UnconditionalFlowInfo otherInits) {
/* 1709 */     if ((otherInits.tagBits & 0x1) != 0 && this != DEAD_END)
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1715 */       return this;
/*      */     }
/* 1717 */     if ((this.tagBits & 0x1) != 0)
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1723 */       return (UnconditionalFlowInfo)otherInits.copy();
/*      */     }
/*      */ 
/*      */     
/* 1727 */     this.definiteInits &= otherInits.definiteInits;
/*      */     
/* 1729 */     this.potentialInits |= otherInits.potentialInits;
/*      */ 
/*      */ 
/*      */     
/* 1733 */     boolean thisHasNulls = ((this.tagBits & 0x4) != 0);
/* 1734 */     boolean otherHasNulls = ((otherInits.tagBits & 0x4) != 0);
/* 1735 */     boolean thisWasUnreachable = false;
/* 1736 */     boolean otherIsUnreachable = false;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1742 */     if ((otherInits.tagBits & 0x2) != 0) {
/* 1743 */       otherIsUnreachable = true;
/* 1744 */     } else if ((this.tagBits & 0x2) != 0) {
/* 1745 */       this.nullBit1 = otherInits.nullBit1;
/* 1746 */       this.nullBit2 = otherInits.nullBit2;
/* 1747 */       this.nullBit3 = otherInits.nullBit3;
/* 1748 */       this.nullBit4 = otherInits.nullBit4;
/* 1749 */       this.iNBit = otherInits.iNBit;
/* 1750 */       this.iNNBit = otherInits.iNNBit;
/* 1751 */       thisWasUnreachable = true;
/* 1752 */       thisHasNulls = otherHasNulls;
/* 1753 */       this.tagBits = otherInits.tagBits;
/* 1754 */     } else if (thisHasNulls) {
/* 1755 */       if (otherHasNulls) {
/* 1756 */         long a1, a2, a3, a4, na2, na3, nb2, b1, b2, b3, b4; this.nullBit1 = (a1 = this.nullBit1) & (b1 = otherInits.nullBit1) & ((
/* 1757 */           a2 = this.nullBit2) & ((b2 = otherInits.nullBit2) & ((
/* 1758 */           a3 = this.nullBit3) & (a4 = this.nullBit4) ^ (b3 = otherInits.nullBit3) & (b4 = otherInits.nullBit4) ^ 0xFFFFFFFFFFFFFFFFL) | 
/* 1759 */           a3 & a4 & (nb2 = b2 ^ 0xFFFFFFFFFFFFFFFFL)) | (
/* 1760 */           na2 = a2 ^ 0xFFFFFFFFFFFFFFFFL) & (b2 & b3 & b4 | 
/* 1761 */           nb2 & ((na3 = a3 ^ 0xFFFFFFFFFFFFFFFFL) ^ b3))); long na1, na4, nb1, nb3, nb4;
/* 1762 */         this.nullBit2 = b2 & ((nb3 = b3 ^ 0xFFFFFFFFFFFFFFFFL) | (nb1 = b1 ^ 0xFFFFFFFFFFFFFFFFL) | a3 & (a4 | (na1 = a1 ^ 0xFFFFFFFFFFFFFFFFL)) & (nb4 = b4 ^ 0xFFFFFFFFFFFFFFFFL)) | 
/* 1763 */           a2 & (b2 | (na4 = a4 ^ 0xFFFFFFFFFFFFFFFFL) & b3 & (b4 | nb1) | na3 | na1);
/* 1764 */         this.nullBit3 = a3 & (na1 | a1 & na2 | b3 & (na4 ^ b4)) | 
/* 1765 */           b3 & (nb1 | b1 & nb2);
/* 1766 */         this.nullBit4 = na3 & (nb1 & nb3 & b4 | 
/* 1767 */           b1 & (nb2 & nb3 | a4 & b2 & nb4) | 
/* 1768 */           na1 & a4 & (nb3 | b1 & b2)) | 
/* 1769 */           a3 & a4 & (b3 & b4 | b1 & nb2 | na1 & a2) | 
/* 1770 */           na2 & (nb1 & b4 | b1 & nb3 | na1 & a4) & nb2 | 
/* 1771 */           a1 & (na3 & (nb3 & b4 | 
/* 1772 */           b1 & b2 & b3 & nb4 | 
/* 1773 */           na2 & (nb3 | nb2)) | 
/* 1774 */           na2 & b3 & b4 | 
/* 1775 */           a2 & (nb1 & b4 | a3 & na4 & b1) & nb3) | 
/* 1776 */           nb1 & b2 & b3 & b4;
/*      */ 
/*      */       
/*      */       }
/*      */       else {
/*      */ 
/*      */ 
/*      */         
/* 1784 */         long a1 = this.nullBit1;
/* 1785 */         this.nullBit1 = 0L; long a2, a3, na1, na3;
/* 1786 */         this.nullBit2 = (a2 = this.nullBit2) & (na3 = (a3 = this.nullBit3) ^ 0xFFFFFFFFFFFFFFFFL | (na1 = a1 ^ 0xFFFFFFFFFFFFFFFFL)); long a4, na2;
/* 1787 */         this.nullBit3 = a3 & ((na2 = a2 ^ 0xFFFFFFFFFFFFFFFFL) & (a4 = this.nullBit4) | na1) | a1 & na2 & (a4 ^ 0xFFFFFFFFFFFFFFFFL);
/* 1788 */         this.nullBit4 = (na3 | na2) & na1 & a4 | a1 & na3 & na2;
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1795 */       this.iNBit |= otherInits.iNBit;
/* 1796 */       this.iNNBit |= otherInits.iNNBit;
/* 1797 */     } else if (otherHasNulls) {
/* 1798 */       this.nullBit1 = 0L; long nb1, nb3, b1, b2, b3;
/* 1799 */       this.nullBit2 = (b2 = otherInits.nullBit2) & (nb3 = (b3 = otherInits.nullBit3) ^ 0xFFFFFFFFFFFFFFFFL | (nb1 = (b1 = otherInits.nullBit1) ^ 0xFFFFFFFFFFFFFFFFL)); long nb2, b4;
/* 1800 */       this.nullBit3 = b3 & ((nb2 = b2 ^ 0xFFFFFFFFFFFFFFFFL) & (b4 = otherInits.nullBit4) | nb1) | b1 & nb2 & (b4 ^ 0xFFFFFFFFFFFFFFFFL);
/* 1801 */       this.nullBit4 = (nb3 | nb2) & nb1 & b4 | b1 & nb3 & nb2;
/* 1802 */       this.iNBit |= otherInits.iNBit;
/* 1803 */       this.iNNBit |= otherInits.iNNBit;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1809 */       thisHasNulls = !(
/*      */         
/* 1811 */         this.nullBit2 == 0L && 
/* 1812 */         this.nullBit3 == 0L && 
/* 1813 */         this.nullBit4 == 0L);
/*      */     } 
/*      */ 
/*      */     
/* 1817 */     if (this.extra != null || otherInits.extra != null) {
/*      */       
/* 1819 */       int mergeLimit = 0;
/* 1820 */       int copyLimit = 0;
/* 1821 */       int resetLimit = 0;
/*      */       
/* 1823 */       if (this.extra != null) {
/* 1824 */         if (otherInits.extra != null) {
/*      */           int length;
/*      */           int otherLength;
/* 1827 */           if ((length = (this.extra[0]).length) < (
/* 1828 */             otherLength = (otherInits.extra[0]).length))
/*      */           {
/* 1830 */             growSpace(otherLength, 0, length);
/* 1831 */             mergeLimit = length;
/* 1832 */             copyLimit = otherLength;
/*      */ 
/*      */ 
/*      */           
/*      */           }
/*      */           else
/*      */           {
/*      */ 
/*      */             
/* 1841 */             mergeLimit = otherLength;
/* 1842 */             resetLimit = length;
/*      */           
/*      */           }
/*      */ 
/*      */         
/*      */         }
/*      */         else {
/*      */ 
/*      */           
/* 1851 */           resetLimit = (this.extra[0]).length;
/*      */ 
/*      */         
/*      */         }
/*      */ 
/*      */ 
/*      */       
/*      */       }
/* 1859 */       else if (otherInits.extra != null) {
/*      */         
/* 1861 */         int otherLength = (otherInits.extra[0]).length;
/* 1862 */         this.extra = new long[8][];
/* 1863 */         for (int j = 0; j < 8; j++) {
/* 1864 */           this.extra[j] = new long[otherLength];
/*      */         }
/* 1866 */         System.arraycopy(otherInits.extra[1], 0, 
/* 1867 */             this.extra[1], 0, otherLength);
/* 1868 */         System.arraycopy(otherInits.extra[6], 0, this.extra[6], 0, otherLength);
/* 1869 */         System.arraycopy(otherInits.extra[7], 0, this.extra[7], 0, otherLength);
/* 1870 */         copyLimit = otherLength;
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/*      */       int i;
/*      */ 
/*      */ 
/*      */       
/* 1879 */       for (i = 0; i < mergeLimit; i++) {
/* 1880 */         this.extra[0][i] = this.extra[0][i] & otherInits.extra[0][i];
/* 1881 */         this.extra[1][i] = this.extra[1][i] | otherInits.extra[1][i];
/*      */       } 
/* 1883 */       for (; i < copyLimit; i++) {
/* 1884 */         this.extra[1][i] = otherInits.extra[1][i];
/*      */       }
/* 1886 */       for (; i < resetLimit; i++) {
/* 1887 */         this.extra[0][i] = 0L;
/*      */       }
/*      */       
/* 1890 */       if (!otherHasNulls || otherIsUnreachable) {
/* 1891 */         if (otherIsUnreachable) {
/*      */           
/* 1893 */           resetLimit = 0;
/*      */         } else {
/*      */           
/* 1896 */           resetLimit = Math.max(resetLimit, mergeLimit);
/*      */         } 
/* 1898 */         copyLimit = 0;
/* 1899 */         mergeLimit = 0;
/*      */       } 
/* 1901 */       i = 0;
/* 1902 */       if (thisWasUnreachable) {
/* 1903 */         if (otherInits.extra != null)
/*      */         {
/* 1905 */           for (; i < mergeLimit; i++) {
/* 1906 */             this.extra[2][i] = otherInits.extra[2][i];
/* 1907 */             this.extra[3][i] = otherInits.extra[3][i];
/* 1908 */             this.extra[4][i] = otherInits.extra[4][i];
/* 1909 */             this.extra[5][i] = otherInits.extra[5][i];
/*      */           } 
/*      */         }
/*      */         
/* 1913 */         for (; i < resetLimit; i++) {
/* 1914 */           this.extra[2][i] = 0L;
/* 1915 */           this.extra[3][i] = 0L;
/* 1916 */           this.extra[4][i] = 0L;
/* 1917 */           this.extra[5][i] = 0L;
/*      */         } 
/*      */       } else {
/*      */         
/* 1921 */         for (; i < mergeLimit; i++) {
/* 1922 */           long a1, a2, a3, a4, na2, na3, nb2, b1, b2, b3, b4; this.extra[2][i] = (a1 = this.extra[2][i]) & (b1 = otherInits.extra[2][i]) & ((
/* 1923 */             a2 = this.extra[3][i]) & ((b2 = otherInits.extra[3][i]) & ((
/* 1924 */             a3 = this.extra[4][i]) & (a4 = this.extra[5][i]) ^ (b3 = otherInits.extra[4][i]) & (b4 = otherInits.extra[5][i]) ^ 0xFFFFFFFFFFFFFFFFL) | 
/* 1925 */             a3 & a4 & (nb2 = b2 ^ 0xFFFFFFFFFFFFFFFFL)) | (
/* 1926 */             na2 = a2 ^ 0xFFFFFFFFFFFFFFFFL) & (b2 & b3 & b4 | 
/* 1927 */             nb2 & ((na3 = a3 ^ 0xFFFFFFFFFFFFFFFFL) ^ b3))); long na1, na4, nb1, nb3, nb4;
/* 1928 */           this.extra[3][i] = b2 & ((nb3 = b3 ^ 0xFFFFFFFFFFFFFFFFL) | (nb1 = b1 ^ 0xFFFFFFFFFFFFFFFFL) | a3 & (a4 | (na1 = a1 ^ 0xFFFFFFFFFFFFFFFFL)) & (nb4 = b4 ^ 0xFFFFFFFFFFFFFFFFL)) | 
/* 1929 */             a2 & (b2 | (na4 = a4 ^ 0xFFFFFFFFFFFFFFFFL) & b3 & (b4 | nb1) | na3 | na1);
/* 1930 */           this.extra[4][i] = a3 & (na1 | a1 & na2 | b3 & (na4 ^ b4)) | 
/* 1931 */             b3 & (nb1 | b1 & nb2);
/* 1932 */           this.extra[5][i] = na3 & (nb1 & nb3 & b4 | 
/* 1933 */             b1 & (nb2 & nb3 | a4 & b2 & nb4) | 
/* 1934 */             na1 & a4 & (nb3 | b1 & b2)) | 
/* 1935 */             a3 & a4 & (b3 & b4 | b1 & nb2 | na1 & a2) | 
/* 1936 */             na2 & (nb1 & b4 | b1 & nb3 | na1 & a4) & nb2 | 
/* 1937 */             a1 & (na3 & (nb3 & b4 | 
/* 1938 */             b1 & b2 & b3 & nb4 | 
/* 1939 */             na2 & (nb3 | nb2)) | 
/* 1940 */             na2 & b3 & b4 | 
/* 1941 */             a2 & (nb1 & b4 | a3 & na4 & b1) & nb3) | 
/* 1942 */             nb1 & b2 & b3 & b4;
/* 1943 */           this.extra[6][i] = this.extra[6][i] | otherInits.extra[6][i];
/* 1944 */           this.extra[7][i] = this.extra[7][i] | otherInits.extra[7][i];
/* 1945 */           thisHasNulls = !(!thisHasNulls && 
/* 1946 */             this.extra[3][i] == 0L && 
/* 1947 */             this.extra[4][i] == 0L && 
/* 1948 */             this.extra[5][i] == 0L);
/*      */         } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1955 */         for (; i < copyLimit; i++) {
/* 1956 */           this.extra[2][i] = 0L; long nb1, nb3, b1, b2, b3;
/* 1957 */           this.extra[3][i] = (b2 = otherInits.extra[3][i]) & (nb3 = (b3 = otherInits.extra[4][i]) ^ 0xFFFFFFFFFFFFFFFFL | (nb1 = (b1 = otherInits.extra[2][i]) ^ 0xFFFFFFFFFFFFFFFFL)); long nb2, b4;
/* 1958 */           this.extra[4][i] = b3 & ((nb2 = b2 ^ 0xFFFFFFFFFFFFFFFFL) & (b4 = otherInits.extra[5][i]) | nb1) | b1 & nb2 & (b4 ^ 0xFFFFFFFFFFFFFFFFL);
/* 1959 */           this.extra[5][i] = (nb3 | nb2) & nb1 & b4 | b1 & nb3 & nb2;
/* 1960 */           this.extra[6][i] = this.extra[6][i] | otherInits.extra[6][i];
/* 1961 */           this.extra[7][i] = this.extra[7][i] | otherInits.extra[7][i];
/* 1962 */           thisHasNulls = !(!thisHasNulls && 
/* 1963 */             this.extra[3][i] == 0L && 
/* 1964 */             this.extra[4][i] == 0L && 
/* 1965 */             this.extra[5][i] == 0L);
/*      */         } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1972 */         for (; i < resetLimit; i++) {
/* 1973 */           long a1 = this.extra[2][i];
/* 1974 */           this.extra[2][i] = 0L; long a2, a3, na1, na3;
/* 1975 */           this.extra[3][i] = (a2 = this.extra[3][i]) & (na3 = (a3 = this.extra[4][i]) ^ 0xFFFFFFFFFFFFFFFFL | (na1 = a1 ^ 0xFFFFFFFFFFFFFFFFL)); long a4, na2;
/* 1976 */           this.extra[4][i] = a3 & ((na2 = a2 ^ 0xFFFFFFFFFFFFFFFFL) & (a4 = this.extra[5][i]) | na1) | a1 & na2 & (a4 ^ 0xFFFFFFFFFFFFFFFFL);
/* 1977 */           this.extra[5][i] = (na3 | na2) & na1 & a4 | a1 & na3 & na2;
/* 1978 */           if (otherInits.extra != null && (otherInits.extra[0]).length > i) {
/* 1979 */             this.extra[6][i] = this.extra[6][i] | otherInits.extra[6][i];
/* 1980 */             this.extra[7][i] = this.extra[7][i] | otherInits.extra[7][i];
/*      */           } 
/* 1982 */           thisHasNulls = !(!thisHasNulls && 
/* 1983 */             this.extra[3][i] == 0L && 
/* 1984 */             this.extra[4][i] == 0L && 
/* 1985 */             this.extra[5][i] == 0L);
/*      */         } 
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1994 */     if (thisHasNulls) {
/* 1995 */       this.tagBits |= 0x4;
/*      */     } else {
/*      */       
/* 1998 */       this.tagBits &= 0xFFFFFFFB;
/*      */     } 
/* 2000 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static int numberOfEnclosingFields(ReferenceBinding type) {
/* 2007 */     int count = 0;
/* 2008 */     type = type.enclosingType();
/* 2009 */     while (type != null) {
/* 2010 */       count += type.fieldCount();
/* 2011 */       type = type.enclosingType();
/*      */     } 
/* 2013 */     return count;
/*      */   }
/*      */ 
/*      */   
/*      */   public UnconditionalFlowInfo nullInfoLessUnconditionalCopy() {
/* 2018 */     if (this == DEAD_END) {
/* 2019 */       return this;
/*      */     }
/* 2021 */     UnconditionalFlowInfo copy = new UnconditionalFlowInfo();
/* 2022 */     copy.definiteInits = this.definiteInits;
/* 2023 */     copy.potentialInits = this.potentialInits;
/*      */     
/* 2025 */     copy.iNBit = -1L;
/* 2026 */     copy.iNNBit = -1L;
/* 2027 */     this.tagBits &= 0xFFFFFFFB;
/* 2028 */     copy.tagBits |= 0x40;
/* 2029 */     copy.maxFieldCount = this.maxFieldCount;
/* 2030 */     if (this.extra != null) {
/*      */       
/* 2032 */       copy.extra = new long[8][]; int length;
/* 2033 */       System.arraycopy(this.extra[0], 0, 
/* 2034 */           copy.extra[0] = 
/* 2035 */           new long[length = (this.extra[0]).length], 0, length);
/* 2036 */       System.arraycopy(this.extra[1], 0, 
/* 2037 */           copy.extra[1] = new long[length], 0, length);
/* 2038 */       for (int j = 2; j < 8; j++) {
/* 2039 */         copy.extra[j] = new long[length];
/*      */       }
/*      */       
/* 2042 */       Arrays.fill(copy.extra[6], -1L);
/* 2043 */       Arrays.fill(copy.extra[7], -1L);
/*      */     } 
/* 2045 */     return copy;
/*      */   }
/*      */ 
/*      */   
/*      */   public FlowInfo safeInitsWhenTrue() {
/* 2050 */     return copy();
/*      */   }
/*      */ 
/*      */   
/*      */   public FlowInfo setReachMode(int reachMode) {
/* 2055 */     if (this == DEAD_END) {
/* 2056 */       return this;
/*      */     }
/* 2058 */     if (reachMode == 0) {
/* 2059 */       this.tagBits &= 0xFFFFFFFC;
/* 2060 */     } else if (reachMode == 2) {
/* 2061 */       this.tagBits |= 0x2;
/*      */     } else {
/* 2063 */       if ((this.tagBits & 0x3) == 0) {
/*      */ 
/*      */         
/* 2066 */         this.potentialInits = 0L;
/* 2067 */         if (this.extra != null) {
/* 2068 */           for (int i = 0, length = (this.extra[0]).length; 
/* 2069 */             i < length; i++) {
/* 2070 */             this.extra[1][i] = 0L;
/*      */           }
/*      */         }
/*      */       } 
/* 2074 */       this.tagBits |= reachMode;
/*      */     } 
/* 2076 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public String toString() {
/* 2082 */     if (this == DEAD_END) {
/* 2083 */       return "FlowInfo.DEAD_END";
/*      */     }
/* 2085 */     if ((this.tagBits & 0x4) != 0) {
/* 2086 */       if (this.extra == null) {
/* 2087 */         return "FlowInfo<def: " + Long.toHexString(this.definiteInits) + 
/* 2088 */           ", pot: " + Long.toHexString(this.potentialInits) + 
/* 2089 */           ", reachable:" + (((this.tagBits & 0x3) == 0) ? 1 : 0) + 
/* 2090 */           ", null: " + Long.toHexString(this.nullBit1) + 
/* 2091 */           '.' + Long.toHexString(this.nullBit2) + '.' + Long.toHexString(this.nullBit3) + '.' + Long.toHexString(this.nullBit4) + 
/* 2092 */           ", incoming: " + Long.toHexString(this.iNBit) + '.' + Long.toHexString(this.iNNBit) + 
/* 2093 */           ">";
/*      */       }
/*      */       
/* 2096 */       String str1 = "FlowInfo<def:[" + Long.toHexString(this.definiteInits);
/* 2097 */       String str2 = "], pot:[" + Long.toHexString(this.potentialInits);
/* 2098 */       String nullS = ", null:[" + Long.toHexString(this.nullBit1) + 
/* 2099 */         '.' + Long.toHexString(this.nullBit2) + '.' + Long.toHexString(this.nullBit3) + '.' + Long.toHexString(this.nullBit4) + 
/* 2100 */         ", incoming: " + Long.toHexString(this.iNBit) + '.' + Long.toHexString(this.iNNBit);
/*      */       
/* 2102 */       int j = 0;
/*      */       
/* 2104 */       int k = ((this.extra[0]).length > 3) ? 3 : (this.extra[0]).length;
/* 2105 */       for (; j < k; j++) {
/* 2106 */         str1 = String.valueOf(str1) + "," + Long.toHexString(this.extra[0][j]);
/* 2107 */         str2 = String.valueOf(str2) + "," + Long.toHexString(this.extra[1][j]);
/* 2108 */         nullS = String.valueOf(nullS) + "\n\t" + Long.toHexString(this.extra[2][j]) + 
/* 2109 */           '.' + Long.toHexString(this.extra[3][j]) + '.' + Long.toHexString(this.extra[4][j]) + '.' + Long.toHexString(this.extra[5][j]) + 
/* 2110 */           ", incoming: " + Long.toHexString(this.extra[6][j]) + '.' + Long.toHexString(this.extra[7][j]);
/*      */       } 
/* 2112 */       if (k < (this.extra[0]).length) {
/* 2113 */         str1 = String.valueOf(str1) + ",...";
/* 2114 */         str2 = String.valueOf(str2) + ",...";
/* 2115 */         nullS = String.valueOf(nullS) + ",...";
/*      */       } 
/* 2117 */       return String.valueOf(str1) + str2 + 
/* 2118 */         "], reachable:" + (((this.tagBits & 0x3) == 0) ? 1 : 0) + 
/* 2119 */         nullS + 
/* 2120 */         "]>";
/*      */     } 
/*      */ 
/*      */     
/* 2124 */     if (this.extra == null) {
/* 2125 */       return "FlowInfo<def: " + this.definiteInits + 
/* 2126 */         ", pot: " + this.potentialInits + 
/* 2127 */         ", reachable:" + (((this.tagBits & 0x3) == 0) ? 1 : 0) + 
/* 2128 */         ", no null info>";
/*      */     }
/*      */     
/* 2131 */     String def = "FlowInfo<def:[" + this.definiteInits;
/* 2132 */     String pot = "], pot:[" + this.potentialInits;
/*      */     
/* 2134 */     int i = 0;
/*      */     
/* 2136 */     int ceil = ((this.extra[0]).length > 3) ? 3 : (this.extra[0]).length;
/* 2137 */     for (; i < ceil; i++) {
/* 2138 */       def = String.valueOf(def) + "," + this.extra[0][i];
/* 2139 */       pot = String.valueOf(pot) + "," + this.extra[1][i];
/*      */     } 
/* 2141 */     if (ceil < (this.extra[0]).length) {
/* 2142 */       def = String.valueOf(def) + ",...";
/* 2143 */       pot = String.valueOf(pot) + ",...";
/*      */     } 
/* 2145 */     return String.valueOf(def) + pot + 
/* 2146 */       "], reachable:" + (((this.tagBits & 0x3) == 0) ? 1 : 0) + 
/* 2147 */       ", no null info>";
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public UnconditionalFlowInfo unconditionalCopy() {
/* 2154 */     return (UnconditionalFlowInfo)copy();
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public UnconditionalFlowInfo unconditionalFieldLessCopy() {
/* 2160 */     UnconditionalFlowInfo copy = new UnconditionalFlowInfo();
/* 2161 */     copy.tagBits = this.tagBits;
/* 2162 */     copy.maxFieldCount = this.maxFieldCount;
/* 2163 */     int limit = this.maxFieldCount;
/* 2164 */     if (limit < 64) {
/*      */       long mask;
/* 2166 */       this.definiteInits &= mask = (1L << limit) - 1L ^ 0xFFFFFFFFFFFFFFFFL;
/* 2167 */       this.potentialInits &= mask;
/* 2168 */       this.nullBit1 &= mask;
/* 2169 */       this.nullBit2 &= mask;
/* 2170 */       this.nullBit3 &= mask;
/* 2171 */       this.nullBit4 &= mask;
/* 2172 */       this.iNBit &= mask;
/* 2173 */       this.iNNBit &= mask;
/*      */     } 
/*      */     
/* 2176 */     if (this.extra == null) {
/* 2177 */       return copy;
/*      */     }
/*      */     int vectorIndex, length;
/* 2180 */     if ((vectorIndex = limit / 64 - 1) >= (
/* 2181 */       length = (this.extra[0]).length)) {
/* 2182 */       return copy;
/*      */     }
/*      */     
/* 2185 */     copy.extra = new long[8][]; int copyStart;
/* 2186 */     if ((copyStart = vectorIndex + 1) < length) {
/* 2187 */       int copyLength = length - copyStart;
/* 2188 */       for (int j = 0; j < 8; j++) {
/* 2189 */         System.arraycopy(this.extra[j], copyStart, 
/* 2190 */             copy.extra[j] = new long[length], copyStart, 
/* 2191 */             copyLength);
/*      */       }
/*      */     }
/* 2194 */     else if (vectorIndex >= 0) {
/* 2195 */       copy.createExtraSpace(length);
/*      */     } 
/* 2197 */     if (vectorIndex >= 0) {
/* 2198 */       long mask = (1L << limit % 64) - 1L ^ 0xFFFFFFFFFFFFFFFFL;
/* 2199 */       for (int j = 0; j < 8; j++) {
/* 2200 */         copy.extra[j][vectorIndex] = 
/* 2201 */           this.extra[j][vectorIndex] & mask;
/*      */       }
/*      */     } 
/* 2204 */     return copy;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public UnconditionalFlowInfo unconditionalInits() {
/* 2210 */     return this;
/*      */   }
/*      */ 
/*      */   
/*      */   public UnconditionalFlowInfo unconditionalInitsWithoutSideEffect() {
/* 2215 */     return this;
/*      */   }
/*      */   
/*      */   public UnconditionalFlowInfo mergeDefiniteInitsWith(UnconditionalFlowInfo otherInits) {
/* 2219 */     if ((otherInits.tagBits & 0x1) != 0 && this != DEAD_END) {
/* 2220 */       return this;
/*      */     }
/* 2222 */     if ((this.tagBits & 0x1) != 0) {
/* 2223 */       return (UnconditionalFlowInfo)otherInits.copy();
/*      */     }
/*      */ 
/*      */     
/* 2227 */     this.definiteInits &= otherInits.definiteInits;
/* 2228 */     if (this.extra != null) {
/* 2229 */       if (otherInits.extra != null) {
/*      */         
/* 2231 */         int i = 0; int length, otherLength;
/* 2232 */         if ((length = (this.extra[0]).length) < (otherLength = (otherInits.extra[0]).length)) {
/*      */           
/* 2234 */           growSpace(otherLength, 0, length);
/* 2235 */           for (; i < length; i++) {
/* 2236 */             this.extra[0][i] = this.extra[0][i] & otherInits.extra[0][i];
/*      */           }
/* 2238 */           for (; i < otherLength; i++) {
/* 2239 */             this.extra[0][i] = otherInits.extra[0][i];
/*      */           }
/*      */         }
/*      */         else {
/*      */           
/* 2244 */           for (; i < otherLength; i++) {
/* 2245 */             this.extra[0][i] = this.extra[0][i] & otherInits.extra[0][i];
/*      */           }
/* 2247 */           for (; i < length; i++) {
/* 2248 */             this.extra[0][i] = 0L;
/*      */           }
/*      */         } 
/*      */       } else {
/* 2252 */         for (int i = 0; i < (this.extra[0]).length; i++) {
/* 2253 */           this.extra[0][i] = 0L;
/*      */         }
/*      */       }
/*      */     
/* 2257 */     } else if (otherInits.extra != null) {
/*      */       
/* 2259 */       int otherLength = (otherInits.extra[0]).length;
/* 2260 */       createExtraSpace(otherLength);
/* 2261 */       System.arraycopy(otherInits.extra[0], 0, this.extra[0], 0, 
/* 2262 */           otherLength);
/*      */     } 
/* 2264 */     return this;
/*      */   }
/*      */   
/*      */   public void resetAssignmentInfo(LocalVariableBinding local) {
/* 2268 */     resetAssignmentInfo(local.id + this.maxFieldCount);
/*      */   }
/*      */   
/*      */   public void resetAssignmentInfo(int position) {
/* 2272 */     if (this != DEAD_END) {
/*      */       long mask;
/*      */ 
/*      */ 
/*      */       
/* 2277 */       this.definiteInits &= mask = 1L << position ^ 0xFFFFFFFFFFFFFFFFL;
/* 2278 */       this.potentialInits &= mask;
/*      */ 
/*      */       
/* 2281 */       int vectorIndex = position / 64 - 1;
/* 2282 */       if (this.extra == null || vectorIndex >= (this.extra[0]).length)
/*      */         return;  long l1;
/* 2284 */       this.extra[0][vectorIndex] = this.extra[0][vectorIndex] & (
/* 2285 */         l1 = 1L << position % 64 ^ 0xFFFFFFFFFFFFFFFFL);
/* 2286 */       this.extra[1][vectorIndex] = this.extra[1][vectorIndex] & l1;
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   private void createExtraSpace(int length) {
/* 2292 */     this.extra = new long[8][];
/* 2293 */     for (int j = 0; j < 8; j++) {
/* 2294 */       this.extra[j] = new long[length];
/*      */     }
/* 2296 */     if ((this.tagBits & 0x40) != 0) {
/* 2297 */       Arrays.fill(this.extra[6], -1L);
/* 2298 */       Arrays.fill(this.extra[7], -1L);
/*      */     } 
/*      */   }
/*      */   
/*      */   public void growSpace(int newLength, int copyStart, int copyLength) {
/* 2303 */     for (int j = 0; j < 8; j++) {
/* 2304 */       System.arraycopy(this.extra[j], copyStart, 
/* 2305 */           this.extra[j] = new long[newLength], copyStart, 
/* 2306 */           copyLength);
/*      */     }
/* 2308 */     if ((this.tagBits & 0x40) != 0) {
/* 2309 */       Arrays.fill(this.extra[6], copyStart + copyLength, newLength, -1L);
/* 2310 */       Arrays.fill(this.extra[7], copyStart + copyLength, newLength, -1L);
/*      */     } 
/*      */   }
/*      */   
/*      */   public void acceptAllIncomingNullness() {
/* 2315 */     this.iNBit = -1L;
/* 2316 */     this.iNNBit = -1L;
/* 2317 */     if (this.extra != null) {
/* 2318 */       Arrays.fill(this.extra[6], -1L);
/* 2319 */       Arrays.fill(this.extra[7], -1L);
/*      */     } 
/*      */   }
/*      */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\flow\UnconditionalFlowInfo.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */