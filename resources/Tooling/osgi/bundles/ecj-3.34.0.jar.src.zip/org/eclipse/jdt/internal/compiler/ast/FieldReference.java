/*     */ package org.eclipse.jdt.internal.compiler.ast;
/*     */ 
/*     */ import org.eclipse.jdt.core.compiler.CharOperation;
/*     */ import org.eclipse.jdt.internal.compiler.ASTVisitor;
/*     */ import org.eclipse.jdt.internal.compiler.codegen.CodeStream;
/*     */ import org.eclipse.jdt.internal.compiler.flow.FlowContext;
/*     */ import org.eclipse.jdt.internal.compiler.flow.FlowInfo;
/*     */ import org.eclipse.jdt.internal.compiler.flow.UnconditionalFlowInfo;
/*     */ import org.eclipse.jdt.internal.compiler.impl.Constant;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.BaseTypeBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.BlockScope;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.FieldBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.InferenceContext18;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.InvocationSite;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.MethodBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.MethodScope;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.ProblemFieldBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.ProblemReferenceBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.ReferenceBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.Scope;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.SourceTypeBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.TypeBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.VariableBinding;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FieldReference
/*     */   extends Reference
/*     */   implements InvocationSite
/*     */ {
/*     */   public static final int READ = 0;
/*     */   public static final int WRITE = 1;
/*     */   public Expression receiver;
/*     */   public char[] token;
/*     */   public FieldBinding binding;
/*     */   public MethodBinding[] syntheticAccessors;
/*     */   public long nameSourcePosition;
/*     */   public TypeBinding actualReceiverType;
/*     */   public TypeBinding genericCast;
/*     */   
/*     */   public FieldReference(char[] source, long pos) {
/*  69 */     this.token = source;
/*  70 */     this.nameSourcePosition = pos;
/*     */     
/*  72 */     this.sourceStart = (int)(pos >>> 32L);
/*  73 */     this.sourceEnd = (int)(pos & 0xFFFFFFFFL);
/*  74 */     this.bits |= 0x1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public FlowInfo analyseAssignment(BlockScope currentScope, FlowContext flowContext, FlowInfo flowInfo, Assignment assignment, boolean isCompound) {
/*  81 */     if (isCompound) {
/*  82 */       if (this.binding.isBlankFinal() && 
/*  83 */         this.receiver.isThis() && 
/*  84 */         currentScope.needBlankFinalFieldInitializationCheck(this.binding)) {
/*  85 */         FlowInfo fieldInits = flowContext.getInitsForFinalBlankInitializationCheck(this.binding.declaringClass.original(), flowInfo);
/*  86 */         if (!fieldInits.isDefinitelyAssigned(this.binding)) {
/*  87 */           currentScope.problemReporter().uninitializedBlankFinalField(this.binding, this);
/*     */         }
/*     */       } 
/*     */       
/*  91 */       manageSyntheticAccessIfNecessary(currentScope, flowInfo, true);
/*     */     } 
/*  93 */     UnconditionalFlowInfo unconditionalFlowInfo = 
/*  94 */       this.receiver
/*  95 */       .analyseCode(currentScope, flowContext, flowInfo, !this.binding.isStatic())
/*  96 */       .unconditionalInits();
/*     */     
/*  98 */     this.receiver.checkNPE(currentScope, flowContext, (FlowInfo)unconditionalFlowInfo);
/*     */     
/* 100 */     if (assignment.expression != null) {
/* 101 */       unconditionalFlowInfo = 
/* 102 */         assignment
/* 103 */         .expression
/* 104 */         .analyseCode(currentScope, flowContext, (FlowInfo)unconditionalFlowInfo)
/* 105 */         .unconditionalInits();
/*     */     }
/* 107 */     manageSyntheticAccessIfNecessary(currentScope, (FlowInfo)unconditionalFlowInfo, false);
/*     */ 
/*     */     
/* 110 */     if (this.binding.isFinal()) {
/*     */       
/* 112 */       if (this.binding.isBlankFinal() && 
/* 113 */         !isCompound && 
/* 114 */         this.receiver.isThis() && 
/* 115 */         !(this.receiver instanceof QualifiedThisReference) && (
/* 116 */         this.receiver.bits & 0x1FE00000) == 0 && 
/* 117 */         currentScope.allowBlankFinalFieldAssignment(this.binding) && 
/* 118 */         !(currentScope.methodScope()).isCompactConstructorScope) {
/* 119 */         if (unconditionalFlowInfo.isPotentiallyAssigned(this.binding)) {
/* 120 */           currentScope.problemReporter().duplicateInitializationOfBlankFinalField(
/* 121 */               this.binding, 
/* 122 */               this);
/*     */         } else {
/* 124 */           flowContext.recordSettingFinal((VariableBinding)this.binding, this, (FlowInfo)unconditionalFlowInfo);
/*     */         } 
/* 126 */         unconditionalFlowInfo.markAsDefinitelyAssigned(this.binding);
/*     */       }
/* 128 */       else if ((currentScope.methodScope()).isCompactConstructorScope) {
/* 129 */         currentScope.problemReporter().recordIllegalExplicitFinalFieldAssignInCompactConstructor(this.binding, this);
/*     */       } else {
/*     */         
/* 132 */         currentScope.problemReporter().cannotAssignToFinalField(this.binding, this);
/*     */       } 
/* 134 */     } else if (this.binding.isNonNull() || this.binding.type.isTypeVariable()) {
/*     */       
/* 136 */       if (!isCompound && 
/* 137 */         this.receiver.isThis() && 
/* 138 */         !(this.receiver instanceof QualifiedThisReference) && 
/* 139 */         TypeBinding.equalsEquals(this.receiver.resolvedType, (TypeBinding)this.binding.declaringClass) && (
/* 140 */         this.receiver.bits & 0x1FE00000) == 0) {
/* 141 */         unconditionalFlowInfo.markAsDefinitelyAssigned(this.binding);
/*     */       }
/*     */     } 
/* 144 */     return (FlowInfo)unconditionalFlowInfo;
/*     */   }
/*     */ 
/*     */   
/*     */   public FlowInfo analyseCode(BlockScope currentScope, FlowContext flowContext, FlowInfo flowInfo) {
/* 149 */     return analyseCode(currentScope, flowContext, flowInfo, true);
/*     */   }
/*     */ 
/*     */   
/*     */   public FlowInfo analyseCode(BlockScope currentScope, FlowContext flowContext, FlowInfo flowInfo, boolean valueRequired) {
/* 154 */     boolean nonStatic = !this.binding.isStatic();
/* 155 */     this.receiver.analyseCode(currentScope, flowContext, flowInfo, nonStatic);
/* 156 */     if (nonStatic) {
/* 157 */       this.receiver.checkNPE(currentScope, flowContext, flowInfo, 1);
/*     */     }
/*     */     
/* 160 */     if (valueRequired || (currentScope.compilerOptions()).complianceLevel >= 3145728L) {
/* 161 */       manageSyntheticAccessIfNecessary(currentScope, flowInfo, true);
/*     */     }
/* 163 */     if ((currentScope.compilerOptions()).complianceLevel >= 3342336L) {
/* 164 */       FieldBinding fieldBinding = this.binding;
/* 165 */       if (this.receiver.isThis() && fieldBinding.isBlankFinal() && currentScope.needBlankFinalFieldInitializationCheck(fieldBinding)) {
/* 166 */         FlowInfo fieldInits = flowContext.getInitsForFinalBlankInitializationCheck(fieldBinding.declaringClass.original(), flowInfo);
/* 167 */         if (!fieldInits.isDefinitelyAssigned(fieldBinding)) {
/* 168 */           currentScope.problemReporter().uninitializedBlankFinalField(fieldBinding, this);
/*     */         }
/*     */       } 
/*     */     } 
/* 172 */     return flowInfo;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean checkNPE(BlockScope scope, FlowContext flowContext, FlowInfo flowInfo, int ttlForFieldCheck) {
/* 177 */     if (flowContext.isNullcheckedFieldAccess(this)) {
/* 178 */       return true;
/*     */     }
/* 180 */     return checkNullableFieldDereference((Scope)scope, this.binding, this.nameSourcePosition, flowContext, ttlForFieldCheck);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void computeConversion(Scope scope, TypeBinding runtimeTimeType, TypeBinding compileTimeType) {
/* 188 */     if (runtimeTimeType == null || compileTimeType == null) {
/*     */       return;
/*     */     }
/* 191 */     if (this.binding != null && this.binding.isValidBinding()) {
/* 192 */       FieldBinding originalBinding = this.binding.original();
/* 193 */       TypeBinding originalType = originalBinding.type;
/*     */       
/* 195 */       if (originalType.leafComponentType().isTypeVariable()) {
/* 196 */         TypeBinding targetType = (!compileTimeType.isBaseType() && runtimeTimeType.isBaseType()) ? 
/* 197 */           compileTimeType : 
/* 198 */           runtimeTimeType;
/* 199 */         this.genericCast = originalBinding.type.genericCast(targetType);
/* 200 */         if (this.genericCast instanceof ReferenceBinding) {
/* 201 */           ReferenceBinding referenceCast = (ReferenceBinding)this.genericCast;
/* 202 */           if (!referenceCast.canBeSeenBy(scope)) {
/* 203 */             scope.problemReporter().invalidType(this, 
/* 204 */                 (TypeBinding)new ProblemReferenceBinding(
/* 205 */                   CharOperation.splitOn('.', referenceCast.shortReadableName()), 
/* 206 */                   referenceCast, 
/* 207 */                   2));
/*     */           }
/*     */         } 
/*     */       } 
/*     */     } 
/* 212 */     super.computeConversion(scope, runtimeTimeType, compileTimeType);
/*     */   }
/*     */ 
/*     */   
/*     */   public FieldBinding fieldBinding() {
/* 217 */     return this.binding;
/*     */   }
/*     */ 
/*     */   
/*     */   public void generateAssignment(BlockScope currentScope, CodeStream codeStream, Assignment assignment, boolean valueRequired) {
/* 222 */     int pc = codeStream.position;
/* 223 */     FieldBinding codegenBinding = this.binding.original();
/* 224 */     this.receiver.generateCode(currentScope, codeStream, !codegenBinding.isStatic());
/* 225 */     codeStream.recordPositionsFrom(pc, this.sourceStart);
/* 226 */     assignment.expression.generateCode(currentScope, codeStream, true);
/* 227 */     fieldStore((Scope)currentScope, codeStream, codegenBinding, (this.syntheticAccessors == null) ? null : this.syntheticAccessors[1], this.actualReceiverType, this.receiver.isImplicitThis(), valueRequired);
/* 228 */     if (valueRequired) {
/* 229 */       codeStream.generateImplicitConversion(assignment.implicitConversion);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void generateCode(BlockScope currentScope, CodeStream codeStream, boolean valueRequired) {
/* 243 */     int pc = codeStream.position;
/* 244 */     if (this.constant != Constant.NotAConstant) {
/* 245 */       if (valueRequired) {
/* 246 */         codeStream.generateConstant(this.constant, this.implicitConversion);
/*     */       }
/* 248 */       codeStream.recordPositionsFrom(pc, this.sourceStart);
/*     */       return;
/*     */     } 
/* 251 */     FieldBinding codegenBinding = this.binding.original();
/* 252 */     boolean isStatic = codegenBinding.isStatic();
/* 253 */     boolean isThisReceiver = this.receiver instanceof ThisReference;
/* 254 */     Constant fieldConstant = codegenBinding.constant();
/* 255 */     if (fieldConstant != Constant.NotAConstant) {
/* 256 */       if (!isThisReceiver) {
/* 257 */         this.receiver.generateCode(currentScope, codeStream, !isStatic);
/* 258 */         if (!isStatic) {
/* 259 */           codeStream.invokeObjectGetClass();
/* 260 */           codeStream.pop();
/*     */         } 
/*     */       } 
/* 263 */       if (valueRequired) {
/* 264 */         codeStream.generateConstant(fieldConstant, this.implicitConversion);
/*     */       }
/* 266 */       codeStream.recordPositionsFrom(pc, this.sourceStart);
/*     */       return;
/*     */     } 
/* 269 */     if (valueRequired || (
/* 270 */       !isThisReceiver && (currentScope.compilerOptions()).complianceLevel >= 3145728L) || (
/* 271 */       this.implicitConversion & 0x400) != 0 || 
/* 272 */       this.genericCast != null) {
/* 273 */       this.receiver.generateCode(currentScope, codeStream, !isStatic);
/* 274 */       if ((this.bits & 0x40000) != 0) {
/* 275 */         codeStream.checkcast(this.actualReceiverType);
/*     */       }
/* 277 */       pc = codeStream.position;
/* 278 */       if (codegenBinding.declaringClass == null) {
/* 279 */         codeStream.arraylength();
/* 280 */         if (valueRequired) {
/* 281 */           codeStream.generateImplicitConversion(this.implicitConversion);
/*     */         } else {
/*     */           
/* 284 */           codeStream.pop();
/*     */         } 
/*     */       } else {
/* 287 */         if (this.syntheticAccessors == null || this.syntheticAccessors[0] == null) {
/* 288 */           TypeBinding constantPoolDeclaringClass = CodeStream.getConstantPoolDeclaringClass((Scope)currentScope, codegenBinding, this.actualReceiverType, this.receiver.isImplicitThis());
/* 289 */           if (isStatic) {
/* 290 */             codeStream.fieldAccess((byte)-78, codegenBinding, constantPoolDeclaringClass);
/*     */           } else {
/* 292 */             codeStream.fieldAccess((byte)-76, codegenBinding, constantPoolDeclaringClass);
/*     */           } 
/*     */         } else {
/* 295 */           codeStream.invoke((byte)-72, this.syntheticAccessors[0], null);
/*     */         } 
/*     */         
/* 298 */         if (this.genericCast != null) codeStream.checkcast(this.genericCast); 
/* 299 */         if (valueRequired) {
/* 300 */           codeStream.generateImplicitConversion(this.implicitConversion);
/*     */         } else {
/* 302 */           boolean isUnboxing = ((this.implicitConversion & 0x400) != 0);
/*     */           
/* 304 */           if (isUnboxing) codeStream.generateImplicitConversion(this.implicitConversion); 
/* 305 */           switch (isUnboxing ? (postConversionType((Scope)currentScope)).id : codegenBinding.type.id) {
/*     */             case 7:
/*     */             case 8:
/* 308 */               codeStream.pop2();
/*     */               break;
/*     */             default:
/* 311 */               codeStream.pop();
/*     */               break;
/*     */           } 
/*     */         } 
/*     */       } 
/* 316 */     } else if (isThisReceiver) {
/* 317 */       if (isStatic)
/*     */       {
/* 319 */         if (TypeBinding.notEquals((TypeBinding)(this.binding.original()).declaringClass, this.actualReceiverType.erasure())) {
/* 320 */           MethodBinding accessor = (this.syntheticAccessors == null) ? null : this.syntheticAccessors[0];
/* 321 */           if (accessor == null) {
/* 322 */             TypeBinding constantPoolDeclaringClass = CodeStream.getConstantPoolDeclaringClass((Scope)currentScope, codegenBinding, this.actualReceiverType, this.receiver.isImplicitThis());
/* 323 */             codeStream.fieldAccess((byte)-78, codegenBinding, constantPoolDeclaringClass);
/*     */           } else {
/* 325 */             codeStream.invoke((byte)-72, accessor, null);
/*     */           } 
/* 327 */           switch (codegenBinding.type.id) {
/*     */             case 7:
/*     */             case 8:
/* 330 */               codeStream.pop2();
/*     */               break;
/*     */             default:
/* 333 */               codeStream.pop();
/*     */               break;
/*     */           } 
/*     */         }  } 
/*     */     } else {
/* 338 */       this.receiver.generateCode(currentScope, codeStream, !isStatic);
/* 339 */       if (!isStatic) {
/* 340 */         codeStream.invokeObjectGetClass();
/* 341 */         codeStream.pop();
/*     */       } 
/*     */     } 
/*     */     
/* 345 */     codeStream.recordPositionsFrom(pc, this.sourceEnd);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void generateCompoundAssignment(BlockScope currentScope, CodeStream codeStream, Expression expression, int operator, int assignmentImplicitConversion, boolean valueRequired) {
/* 352 */     reportOnlyUselesslyReadPrivateField(currentScope, this.binding, valueRequired);
/* 353 */     FieldBinding codegenBinding = this.binding.original(); boolean isStatic;
/* 354 */     this.receiver.generateCode(currentScope, codeStream, !(isStatic = codegenBinding.isStatic()));
/* 355 */     if (isStatic) {
/* 356 */       if (this.syntheticAccessors == null || this.syntheticAccessors[0] == null) {
/* 357 */         TypeBinding constantPoolDeclaringClass = CodeStream.getConstantPoolDeclaringClass((Scope)currentScope, codegenBinding, this.actualReceiverType, this.receiver.isImplicitThis());
/* 358 */         codeStream.fieldAccess((byte)-78, codegenBinding, constantPoolDeclaringClass);
/*     */       } else {
/* 360 */         codeStream.invoke((byte)-72, this.syntheticAccessors[0], null);
/*     */       } 
/*     */     } else {
/* 363 */       codeStream.dup();
/* 364 */       if (this.syntheticAccessors == null || this.syntheticAccessors[0] == null) {
/* 365 */         TypeBinding constantPoolDeclaringClass = CodeStream.getConstantPoolDeclaringClass((Scope)currentScope, codegenBinding, this.actualReceiverType, this.receiver.isImplicitThis());
/* 366 */         codeStream.fieldAccess((byte)-76, codegenBinding, constantPoolDeclaringClass);
/*     */       } else {
/* 368 */         codeStream.invoke((byte)-72, this.syntheticAccessors[0], null);
/*     */       } 
/*     */     } 
/*     */     int operationTypeID;
/* 372 */     switch (operationTypeID = (this.implicitConversion & 0xFF) >> 4) {
/*     */       case 0:
/*     */       case 1:
/*     */       case 11:
/* 376 */         codeStream.generateStringConcatenationAppend(currentScope, null, expression);
/*     */         break;
/*     */       default:
/* 379 */         if (this.genericCast != null) {
/* 380 */           codeStream.checkcast(this.genericCast);
/*     */         }
/* 382 */         codeStream.generateImplicitConversion(this.implicitConversion);
/*     */         
/* 384 */         if (expression == IntLiteral.One) {
/* 385 */           codeStream.generateConstant(expression.constant, this.implicitConversion);
/*     */         } else {
/* 387 */           expression.generateCode(currentScope, codeStream, true);
/*     */         } 
/*     */         
/* 390 */         codeStream.sendOperator(operator, operationTypeID);
/*     */         
/* 392 */         codeStream.generateImplicitConversion(assignmentImplicitConversion); break;
/*     */     } 
/* 394 */     fieldStore((Scope)currentScope, codeStream, codegenBinding, (this.syntheticAccessors == null) ? null : this.syntheticAccessors[1], this.actualReceiverType, this.receiver.isImplicitThis(), valueRequired);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void generatePostIncrement(BlockScope currentScope, CodeStream codeStream, CompoundAssignment postIncrement, boolean valueRequired) {
/*     */     TypeBinding operandType;
/* 402 */     reportOnlyUselesslyReadPrivateField(currentScope, this.binding, valueRequired);
/* 403 */     FieldBinding codegenBinding = this.binding.original(); boolean isStatic;
/* 404 */     this.receiver.generateCode(currentScope, codeStream, !(isStatic = codegenBinding.isStatic()));
/* 405 */     if (isStatic) {
/* 406 */       if (this.syntheticAccessors == null || this.syntheticAccessors[0] == null) {
/* 407 */         TypeBinding constantPoolDeclaringClass = CodeStream.getConstantPoolDeclaringClass((Scope)currentScope, codegenBinding, this.actualReceiverType, this.receiver.isImplicitThis());
/* 408 */         codeStream.fieldAccess((byte)-78, codegenBinding, constantPoolDeclaringClass);
/*     */       } else {
/* 410 */         codeStream.invoke((byte)-72, this.syntheticAccessors[0], null);
/*     */       } 
/*     */     } else {
/* 413 */       codeStream.dup();
/* 414 */       if (this.syntheticAccessors == null || this.syntheticAccessors[0] == null) {
/* 415 */         TypeBinding constantPoolDeclaringClass = CodeStream.getConstantPoolDeclaringClass((Scope)currentScope, codegenBinding, this.actualReceiverType, this.receiver.isImplicitThis());
/* 416 */         codeStream.fieldAccess((byte)-76, codegenBinding, constantPoolDeclaringClass);
/*     */       } else {
/* 418 */         codeStream.invoke((byte)-72, this.syntheticAccessors[0], null);
/*     */       } 
/*     */     } 
/*     */     
/* 422 */     if (this.genericCast != null) {
/* 423 */       codeStream.checkcast(this.genericCast);
/* 424 */       operandType = this.genericCast;
/*     */     } else {
/* 426 */       operandType = codegenBinding.type;
/*     */     } 
/* 428 */     if (valueRequired) {
/* 429 */       if (isStatic) {
/* 430 */         switch (operandType.id) {
/*     */           case 7:
/*     */           case 8:
/* 433 */             codeStream.dup2();
/*     */             break;
/*     */           default:
/* 436 */             codeStream.dup();
/*     */             break;
/*     */         } 
/*     */       } else {
/* 440 */         switch (operandType.id) {
/*     */           case 7:
/*     */           case 8:
/* 443 */             codeStream.dup2_x1();
/*     */             break;
/*     */           default:
/* 446 */             codeStream.dup_x1();
/*     */             break;
/*     */         } 
/*     */       } 
/*     */     }
/* 451 */     codeStream.generateImplicitConversion(this.implicitConversion);
/* 452 */     codeStream.generateConstant(
/* 453 */         postIncrement.expression.constant, 
/* 454 */         this.implicitConversion);
/* 455 */     codeStream.sendOperator(postIncrement.operator, this.implicitConversion & 0xF);
/* 456 */     codeStream.generateImplicitConversion(
/* 457 */         postIncrement.preAssignImplicitConversion);
/* 458 */     fieldStore((Scope)currentScope, codeStream, codegenBinding, (this.syntheticAccessors == null) ? null : this.syntheticAccessors[1], this.actualReceiverType, this.receiver.isImplicitThis(), false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TypeBinding[] genericTypeArguments() {
/* 466 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public InferenceContext18 freshInferenceContext(Scope scope) {
/* 471 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isEquivalent(Reference reference) {
/* 477 */     if (this.receiver.isThis() && !(this.receiver instanceof QualifiedThisReference)) {
/*     */       
/* 479 */       char[] otherToken = null;
/*     */       
/* 481 */       if (reference instanceof SingleNameReference) {
/* 482 */         otherToken = ((SingleNameReference)reference).token;
/* 483 */       } else if (reference instanceof FieldReference) {
/* 484 */         FieldReference fr = (FieldReference)reference;
/* 485 */         if (fr.receiver.isThis() && !(fr.receiver instanceof QualifiedThisReference)) {
/* 486 */           otherToken = fr.token;
/*     */         }
/*     */       } 
/* 489 */       return (otherToken != null && CharOperation.equals(this.token, otherToken));
/*     */     } 
/*     */     
/* 492 */     char[][] thisTokens = getThisFieldTokens(1);
/* 493 */     if (thisTokens == null) {
/* 494 */       return false;
/*     */     }
/*     */     
/* 497 */     char[][] otherTokens = null;
/* 498 */     if (reference instanceof FieldReference) {
/* 499 */       otherTokens = ((FieldReference)reference).getThisFieldTokens(1);
/* 500 */     } else if (reference instanceof QualifiedNameReference) {
/* 501 */       if (((QualifiedNameReference)reference).binding instanceof org.eclipse.jdt.internal.compiler.lookup.LocalVariableBinding)
/* 502 */         return false; 
/* 503 */       otherTokens = ((QualifiedNameReference)reference).tokens;
/*     */     } 
/* 505 */     return CharOperation.equals(thisTokens, otherTokens);
/*     */   }
/*     */ 
/*     */   
/*     */   private char[][] getThisFieldTokens(int nestingCount) {
/* 510 */     char[][] result = null;
/* 511 */     if (this.receiver.isThis() && !(this.receiver instanceof QualifiedThisReference)) {
/*     */       
/* 513 */       result = new char[nestingCount][];
/*     */       
/* 515 */       result[0] = this.token;
/* 516 */     } else if (this.receiver instanceof FieldReference) {
/* 517 */       result = ((FieldReference)this.receiver).getThisFieldTokens(nestingCount + 1);
/* 518 */       if (result != null)
/*     */       {
/* 520 */         result[result.length - nestingCount] = this.token;
/*     */       }
/*     */     } 
/* 523 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isSuperAccess() {
/* 528 */     return this.receiver.isSuper();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isQualifiedSuper() {
/* 533 */     return this.receiver.isQualifiedSuper();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isTypeAccess() {
/* 538 */     return (this.receiver != null && this.receiver.isTypeReference());
/*     */   }
/*     */ 
/*     */   
/*     */   public FieldBinding lastFieldBinding() {
/* 543 */     return this.binding;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void manageSyntheticAccessIfNecessary(BlockScope currentScope, FlowInfo flowInfo, boolean isReadAccess) {
/* 550 */     if ((flowInfo.tagBits & 0x1) != 0) {
/*     */       return;
/*     */     }
/* 553 */     FieldBinding codegenBinding = this.binding.original();
/* 554 */     if (this.binding.isPrivate()) {
/* 555 */       if (!currentScope.enclosingSourceType().isNestmateOf(codegenBinding.declaringClass) && 
/* 556 */         TypeBinding.notEquals((TypeBinding)currentScope.enclosingSourceType(), (TypeBinding)codegenBinding.declaringClass) && 
/* 557 */         this.binding.constant((Scope)currentScope) == Constant.NotAConstant) {
/* 558 */         if (this.syntheticAccessors == null)
/* 559 */           this.syntheticAccessors = new MethodBinding[2]; 
/* 560 */         this.syntheticAccessors[isReadAccess ? 0 : 1] = 
/* 561 */           (MethodBinding)((SourceTypeBinding)codegenBinding.declaringClass).addSyntheticMethod(codegenBinding, isReadAccess, false);
/* 562 */         currentScope.problemReporter().needToEmulateFieldAccess(codegenBinding, this, isReadAccess); return;
/*     */       } 
/*     */     } else {
/* 565 */       if (this.receiver instanceof QualifiedSuperReference) {
/*     */         
/* 567 */         SourceTypeBinding destinationType = (SourceTypeBinding)((QualifiedSuperReference)this.receiver).currentCompatibleType;
/* 568 */         if (this.syntheticAccessors == null)
/* 569 */           this.syntheticAccessors = new MethodBinding[2]; 
/* 570 */         this.syntheticAccessors[isReadAccess ? 0 : 1] = (MethodBinding)destinationType.addSyntheticMethod(codegenBinding, isReadAccess, isSuperAccess());
/* 571 */         currentScope.problemReporter().needToEmulateFieldAccess(codegenBinding, this, isReadAccess);
/*     */         return;
/*     */       } 
/* 574 */       if (this.binding.isProtected())
/*     */       {
/* 576 */         if ((this.bits & 0x1FE0) != 0) {
/* 577 */           SourceTypeBinding enclosingSourceType; if (this.binding.declaringClass.getPackage() != (
/* 578 */             enclosingSourceType = currentScope.enclosingSourceType()).getPackage()) {
/*     */             
/* 580 */             SourceTypeBinding currentCompatibleType = 
/* 581 */               (SourceTypeBinding)enclosingSourceType.enclosingTypeAt((
/* 582 */                 this.bits & 0x1FE0) >> 5);
/* 583 */             if (this.syntheticAccessors == null)
/* 584 */               this.syntheticAccessors = new MethodBinding[2]; 
/* 585 */             this.syntheticAccessors[isReadAccess ? 0 : 1] = (MethodBinding)currentCompatibleType.addSyntheticMethod(codegenBinding, isReadAccess, isSuperAccess());
/* 586 */             currentScope.problemReporter().needToEmulateFieldAccess(codegenBinding, this, isReadAccess);
/*     */             return;
/*     */           } 
/*     */         }  } 
/*     */     } 
/*     */   }
/*     */   
/*     */   public Constant optimizedBooleanConstant() {
/* 594 */     if (this.resolvedType == null)
/* 595 */       return Constant.NotAConstant; 
/* 596 */     switch (this.resolvedType.id) {
/*     */       case 5:
/*     */       case 33:
/* 599 */         return (this.constant != Constant.NotAConstant) ? this.constant : this.binding.constant();
/*     */     } 
/* 601 */     return Constant.NotAConstant;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TypeBinding postConversionType(Scope scope) {
/*     */     BaseTypeBinding baseTypeBinding;
/* 610 */     TypeBinding typeBinding1, convertedType = this.resolvedType;
/* 611 */     if (this.genericCast != null)
/* 612 */       convertedType = this.genericCast; 
/* 613 */     int runtimeType = (this.implicitConversion & 0xFF) >> 4;
/* 614 */     switch (runtimeType) {
/*     */       case 5:
/* 616 */         baseTypeBinding = TypeBinding.BOOLEAN;
/*     */         break;
/*     */       case 3:
/* 619 */         baseTypeBinding = TypeBinding.BYTE;
/*     */         break;
/*     */       case 4:
/* 622 */         baseTypeBinding = TypeBinding.SHORT;
/*     */         break;
/*     */       case 2:
/* 625 */         baseTypeBinding = TypeBinding.CHAR;
/*     */         break;
/*     */       case 10:
/* 628 */         baseTypeBinding = TypeBinding.INT;
/*     */         break;
/*     */       case 9:
/* 631 */         baseTypeBinding = TypeBinding.FLOAT;
/*     */         break;
/*     */       case 7:
/* 634 */         baseTypeBinding = TypeBinding.LONG;
/*     */         break;
/*     */       case 8:
/* 637 */         baseTypeBinding = TypeBinding.DOUBLE;
/*     */         break;
/*     */     } 
/*     */     
/* 641 */     if ((this.implicitConversion & 0x200) != 0) {
/* 642 */       typeBinding1 = scope.environment().computeBoxingType((TypeBinding)baseTypeBinding);
/*     */     }
/* 644 */     return typeBinding1;
/*     */   }
/*     */ 
/*     */   
/*     */   public StringBuffer printExpression(int indent, StringBuffer output) {
/* 649 */     return this.receiver.printExpression(0, output).append('.').append(this.token);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TypeBinding resolveType(BlockScope scope) {
/* 659 */     boolean receiverCast = false;
/* 660 */     if (this.receiver instanceof CastExpression) {
/* 661 */       this.receiver.bits |= 0x20;
/* 662 */       receiverCast = true;
/*     */     } 
/* 664 */     this.actualReceiverType = this.receiver.resolveType(scope);
/* 665 */     if (this.actualReceiverType == null) {
/* 666 */       this.constant = Constant.NotAConstant;
/* 667 */       return null;
/*     */     } 
/* 669 */     if (receiverCast)
/*     */     {
/* 671 */       if (TypeBinding.equalsEquals(((CastExpression)this.receiver).expression.resolvedType, this.actualReceiverType)) {
/* 672 */         scope.problemReporter().unnecessaryCast((CastExpression)this.receiver);
/*     */       }
/*     */     }
/*     */     
/* 676 */     FieldBinding fieldBinding = this.binding = scope.getField(this.actualReceiverType, this.token, this);
/* 677 */     if (!fieldBinding.isValidBinding()) {
/* 678 */       this.constant = Constant.NotAConstant;
/* 679 */       if (this.receiver.resolvedType instanceof ProblemReferenceBinding)
/*     */       {
/* 681 */         return null;
/*     */       }
/*     */ 
/*     */       
/* 685 */       ReferenceBinding declaringClass = fieldBinding.declaringClass;
/* 686 */       boolean avoidSecondary = (declaringClass != null && 
/* 687 */         declaringClass.isAnonymousType() && 
/* 688 */         declaringClass.superclass() instanceof org.eclipse.jdt.internal.compiler.lookup.MissingTypeBinding);
/* 689 */       if (!avoidSecondary) {
/* 690 */         scope.problemReporter().invalidField(this, this.actualReceiverType);
/*     */       }
/* 692 */       if (fieldBinding instanceof ProblemFieldBinding) {
/* 693 */         ProblemFieldBinding problemFieldBinding = (ProblemFieldBinding)fieldBinding;
/* 694 */         FieldBinding closestMatch = problemFieldBinding.closestMatch;
/* 695 */         switch (problemFieldBinding.problemId()) {
/*     */           case 2:
/*     */           case 5:
/*     */           case 6:
/*     */           case 7:
/* 700 */             if (closestMatch != null)
/* 701 */               fieldBinding = closestMatch; 
/*     */             break;
/*     */         } 
/*     */       } 
/* 705 */       if (!fieldBinding.isValidBinding()) {
/* 706 */         return null;
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 711 */     TypeBinding oldReceiverType = this.actualReceiverType;
/* 712 */     this.actualReceiverType = this.actualReceiverType.getErasureCompatibleType((TypeBinding)fieldBinding.declaringClass);
/* 713 */     this.receiver.computeConversion((Scope)scope, this.actualReceiverType, this.actualReceiverType);
/* 714 */     if (TypeBinding.notEquals(this.actualReceiverType, oldReceiverType) && TypeBinding.notEquals(this.receiver.postConversionType((Scope)scope), this.actualReceiverType)) {
/* 715 */       this.bits |= 0x40000;
/*     */     }
/* 717 */     if (isFieldUseDeprecated(fieldBinding, (Scope)scope, this.bits)) {
/* 718 */       scope.problemReporter().deprecatedField(fieldBinding, this);
/*     */     }
/* 720 */     boolean isImplicitThisRcv = this.receiver.isImplicitThis();
/* 721 */     this.constant = isImplicitThisRcv ? fieldBinding.constant((Scope)scope) : Constant.NotAConstant;
/* 722 */     if (fieldBinding.isStatic()) {
/*     */       
/* 724 */       if (!isImplicitThisRcv && (
/* 725 */         !(this.receiver instanceof NameReference) || (
/* 726 */         ((NameReference)this.receiver).bits & 0x4) == 0)) {
/* 727 */         scope.problemReporter().nonStaticAccessToStaticField(this, fieldBinding);
/*     */       }
/* 729 */       ReferenceBinding declaringClass = this.binding.declaringClass;
/* 730 */       if (!isImplicitThisRcv && 
/* 731 */         TypeBinding.notEquals((TypeBinding)declaringClass, this.actualReceiverType) && 
/* 732 */         declaringClass.canBeSeenBy((Scope)scope)) {
/* 733 */         scope.problemReporter().indirectAccessToStaticField(this, fieldBinding);
/*     */       }
/*     */       
/* 736 */       if (declaringClass.isEnum() && scope.kind != 5) {
/* 737 */         MethodScope methodScope = scope.methodScope();
/* 738 */         SourceTypeBinding sourceType = scope.enclosingSourceType();
/* 739 */         if (this.constant == Constant.NotAConstant && 
/* 740 */           !methodScope.isStatic && (
/* 741 */           TypeBinding.equalsEquals((TypeBinding)sourceType, (TypeBinding)declaringClass) || TypeBinding.equalsEquals((TypeBinding)sourceType.superclass, (TypeBinding)declaringClass)) && 
/* 742 */           methodScope.isInsideInitializerOrConstructor()) {
/* 743 */           scope.problemReporter().enumStaticFieldUsedDuringInitialization(this.binding, this);
/*     */         }
/*     */       } 
/*     */     } 
/* 747 */     TypeBinding fieldType = fieldBinding.type;
/* 748 */     if (fieldType != null) {
/* 749 */       if ((this.bits & 0x2000) == 0) {
/* 750 */         fieldType = fieldType.capture((Scope)scope, this.sourceStart, this.sourceEnd);
/*     */       }
/* 752 */       this.resolvedType = fieldType;
/* 753 */       if ((fieldType.tagBits & 0x80L) != 0L) {
/* 754 */         scope.problemReporter().invalidType(this, fieldType);
/* 755 */         return null;
/*     */       } 
/*     */     } 
/* 758 */     return fieldType;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setActualReceiverType(ReferenceBinding receiverType) {
/* 763 */     this.actualReceiverType = (TypeBinding)receiverType;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setDepth(int depth) {
/* 768 */     this.bits &= 0xFFFFE01F;
/* 769 */     if (depth > 0) {
/* 770 */       this.bits |= (depth & 0xFF) << 5;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setFieldIndex(int index) {}
/*     */ 
/*     */ 
/*     */   
/*     */   public void traverse(ASTVisitor visitor, BlockScope scope) {
/* 781 */     if (visitor.visit(this, scope)) {
/* 782 */       this.receiver.traverse(visitor, scope);
/*     */     }
/* 784 */     visitor.endVisit(this, scope);
/*     */   }
/*     */ 
/*     */   
/*     */   public VariableBinding nullAnnotatedVariableBinding(boolean supportTypeAnnotations) {
/* 789 */     if (this.binding != null && (
/* 790 */       supportTypeAnnotations || (
/* 791 */       this.binding.tagBits & 0x180000000000000L) != 0L)) {
/* 792 */       return (VariableBinding)this.binding;
/*     */     }
/*     */     
/* 795 */     return null;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\ast\FieldReference.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */