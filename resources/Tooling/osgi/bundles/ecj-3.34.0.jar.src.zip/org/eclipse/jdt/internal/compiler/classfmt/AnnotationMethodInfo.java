/*     */ package org.eclipse.jdt.internal.compiler.classfmt;
/*     */ 
/*     */ import org.eclipse.jdt.core.compiler.CharOperation;
/*     */ import org.eclipse.jdt.internal.compiler.codegen.AttributeNamesConstants;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AnnotationMethodInfo
/*     */   extends MethodInfo
/*     */ {
/*  20 */   protected Object defaultValue = null;
/*     */   
/*     */   public static MethodInfo createAnnotationMethod(byte[] classFileBytes, int[] offsets, int offset, long version) {
/*  23 */     MethodInfo methodInfo = new MethodInfo(classFileBytes, offsets, offset, version);
/*  24 */     int attributesCount = methodInfo.u2At(6);
/*  25 */     int readOffset = 8;
/*  26 */     AnnotationInfo[] annotations = null;
/*  27 */     Object defaultValue = null;
/*  28 */     TypeAnnotationInfo[] typeAnnotations = null;
/*  29 */     for (int i = 0; i < attributesCount; i++) {
/*     */       
/*  31 */       int utf8Offset = methodInfo.constantPoolOffsets[methodInfo.u2At(readOffset)] - methodInfo.structOffset;
/*  32 */       char[] attributeName = methodInfo.utf8At(utf8Offset + 3, methodInfo.u2At(utf8Offset + 1));
/*  33 */       if (attributeName.length > 0) {
/*  34 */         AnnotationInfo[] methodAnnotations; TypeAnnotationInfo[] methodTypeAnnotations; switch (attributeName[0]) {
/*     */           case 'A':
/*  36 */             if (CharOperation.equals(attributeName, AttributeNamesConstants.AnnotationDefaultName)) {
/*     */ 
/*     */               
/*  39 */               AnnotationInfo info = 
/*  40 */                 new AnnotationInfo(methodInfo.reference, methodInfo.constantPoolOffsets, readOffset + 6 + methodInfo.structOffset);
/*  41 */               defaultValue = info.decodeDefaultValue();
/*     */             } 
/*     */             break;
/*     */           case 'S':
/*  45 */             if (CharOperation.equals(AttributeNamesConstants.SignatureName, attributeName))
/*  46 */               methodInfo.signatureUtf8Offset = methodInfo.constantPoolOffsets[methodInfo.u2At(readOffset + 6)] - methodInfo.structOffset; 
/*     */             break;
/*     */           case 'R':
/*  49 */             methodAnnotations = null;
/*  50 */             methodTypeAnnotations = null;
/*  51 */             if (CharOperation.equals(attributeName, AttributeNamesConstants.RuntimeVisibleAnnotationsName)) {
/*  52 */               methodAnnotations = decodeMethodAnnotations(readOffset, true, methodInfo);
/*  53 */             } else if (CharOperation.equals(attributeName, AttributeNamesConstants.RuntimeInvisibleAnnotationsName)) {
/*  54 */               methodAnnotations = decodeMethodAnnotations(readOffset, false, methodInfo);
/*  55 */             } else if (CharOperation.equals(attributeName, AttributeNamesConstants.RuntimeVisibleTypeAnnotationsName)) {
/*  56 */               methodTypeAnnotations = decodeTypeAnnotations(readOffset, true, methodInfo);
/*  57 */             } else if (CharOperation.equals(attributeName, AttributeNamesConstants.RuntimeInvisibleTypeAnnotationsName)) {
/*  58 */               methodTypeAnnotations = decodeTypeAnnotations(readOffset, false, methodInfo);
/*     */             } 
/*  60 */             if (methodAnnotations != null) {
/*  61 */               if (annotations == null) {
/*  62 */                 annotations = methodAnnotations; break;
/*     */               } 
/*  64 */               int length = annotations.length;
/*  65 */               AnnotationInfo[] newAnnotations = new AnnotationInfo[length + methodAnnotations.length];
/*  66 */               System.arraycopy(annotations, 0, newAnnotations, 0, length);
/*  67 */               System.arraycopy(methodAnnotations, 0, newAnnotations, length, methodAnnotations.length);
/*  68 */               annotations = newAnnotations; break;
/*     */             } 
/*  70 */             if (methodTypeAnnotations != null) {
/*  71 */               if (typeAnnotations == null) {
/*  72 */                 typeAnnotations = methodTypeAnnotations; break;
/*     */               } 
/*  74 */               int length = typeAnnotations.length;
/*  75 */               TypeAnnotationInfo[] newAnnotations = new TypeAnnotationInfo[length + methodTypeAnnotations.length];
/*  76 */               System.arraycopy(typeAnnotations, 0, newAnnotations, 0, length);
/*  77 */               System.arraycopy(methodTypeAnnotations, 0, newAnnotations, length, methodTypeAnnotations.length);
/*  78 */               typeAnnotations = newAnnotations;
/*     */             } 
/*     */             break;
/*     */         } 
/*     */       
/*     */       } 
/*  84 */       readOffset = (int)(readOffset + 6L + methodInfo.u4At(readOffset + 2));
/*     */     } 
/*  86 */     methodInfo.attributeBytes = readOffset;
/*     */     
/*  88 */     if (defaultValue != null) {
/*  89 */       if (typeAnnotations != null)
/*  90 */         return new AnnotationMethodInfoWithTypeAnnotations(methodInfo, defaultValue, annotations, typeAnnotations); 
/*  91 */       if (annotations != null) {
/*  92 */         return new AnnotationMethodInfoWithAnnotations(methodInfo, defaultValue, annotations);
/*     */       }
/*  94 */       return new AnnotationMethodInfo(methodInfo, defaultValue);
/*     */     } 
/*  96 */     if (typeAnnotations != null)
/*  97 */       return new MethodInfoWithTypeAnnotations(methodInfo, annotations, null, typeAnnotations); 
/*  98 */     if (annotations != null)
/*  99 */       return new MethodInfoWithAnnotations(methodInfo, annotations); 
/* 100 */     return methodInfo;
/*     */   }
/*     */   
/*     */   AnnotationMethodInfo(MethodInfo methodInfo, Object defaultValue) {
/* 104 */     super(methodInfo.reference, methodInfo.constantPoolOffsets, methodInfo.structOffset, methodInfo.version);
/* 105 */     this.defaultValue = defaultValue;
/*     */     
/* 107 */     this.accessFlags = methodInfo.accessFlags;
/* 108 */     this.attributeBytes = methodInfo.attributeBytes;
/* 109 */     this.descriptor = methodInfo.descriptor;
/* 110 */     this.exceptionNames = methodInfo.exceptionNames;
/* 111 */     this.name = methodInfo.name;
/* 112 */     this.signature = methodInfo.signature;
/* 113 */     this.signatureUtf8Offset = methodInfo.signatureUtf8Offset;
/* 114 */     this.tagBits = methodInfo.tagBits;
/*     */   }
/*     */   
/*     */   public Object getDefaultValue() {
/* 118 */     return this.defaultValue;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\classfmt\AnnotationMethodInfo.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */