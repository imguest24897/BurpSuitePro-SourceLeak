/*     */ package org.eclipse.jdt.internal.compiler.apt.dispatch;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class ForwardingOutputStream
/*     */   extends OutputStream
/*     */ {
/*     */   private final OutputStream _os;
/*     */   
/*     */   ForwardingOutputStream(OutputStream os) {
/* 130 */     this._os = os;
/*     */   }
/*     */ 
/*     */   
/*     */   public void close() throws IOException {
/* 135 */     this._os.close();
/* 136 */     HookedJavaFileObject.this.closed();
/*     */   }
/*     */   
/*     */   public void flush() throws IOException {
/* 140 */     this._os.flush();
/*     */   }
/*     */   
/*     */   public void write(byte[] b, int off, int len) throws IOException {
/* 144 */     this._os.write(b, off, len);
/*     */   }
/*     */   
/*     */   public void write(byte[] b) throws IOException {
/* 148 */     this._os.write(b);
/*     */   }
/*     */   
/*     */   public void write(int b) throws IOException {
/* 152 */     this._os.write(b);
/*     */   }
/*     */   
/*     */   protected Object clone() throws CloneNotSupportedException {
/* 156 */     return new ForwardingOutputStream(this._os);
/*     */   }
/*     */   
/*     */   public int hashCode() {
/* 160 */     return this._os.hashCode();
/*     */   }
/*     */   
/*     */   public boolean equals(Object obj) {
/* 164 */     if (this == obj)
/* 165 */       return true; 
/* 166 */     if (obj == null)
/* 167 */       return false; 
/* 168 */     if (getClass() != obj.getClass())
/* 169 */       return false; 
/* 170 */     ForwardingOutputStream other = (ForwardingOutputStream)obj;
/* 171 */     if (this._os == null) {
/* 172 */       if (other._os != null)
/* 173 */         return false; 
/* 174 */     } else if (!this._os.equals(other._os)) {
/* 175 */       return false;
/* 176 */     }  return true;
/*     */   }
/*     */   
/*     */   public String toString() {
/* 180 */     return "ForwardingOutputStream wrapping " + this._os.toString();
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\apt\dispatch\HookedJavaFileObject$ForwardingOutputStream.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */