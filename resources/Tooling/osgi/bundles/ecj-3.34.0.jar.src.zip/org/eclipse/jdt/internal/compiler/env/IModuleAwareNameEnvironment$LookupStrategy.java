/*    */ package org.eclipse.jdt.internal.compiler.env;
/*    */ 
/*    */ import java.util.function.Predicate;
/*    */ import org.eclipse.jdt.internal.compiler.lookup.ModuleBinding;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum LookupStrategy
/*    */ {
/* 29 */   Named
/*    */   {
/*    */     public <T> boolean matchesWithName(T elem, Predicate<T> isNamed, Predicate<T> nameMatcher)
/*    */     {
/* 33 */       if (!LookupStrategy.$assertionsDisabled && nameMatcher == null) throw new AssertionError("name match needs a nameMatcher"); 
/* 34 */       return (isNamed.test(elem) && nameMatcher.test(elem));
/*    */     }
/*    */   },
/* 37 */   AnyNamed
/*    */   {
/*    */     public <T> boolean matchesWithName(T elem, Predicate<T> isNamed, Predicate<T> nameMatcher)
/*    */     {
/* 41 */       return isNamed.test(elem);
/*    */     }
/*    */   },
/* 44 */   Any
/*    */   {
/*    */     public <T> boolean matchesWithName(T elem, Predicate<T> isNamed, Predicate<T> nameMatcher)
/*    */     {
/* 48 */       return true;
/*    */     }
/*    */   },
/* 51 */   Unnamed
/*    */   {
/*    */     public <T> boolean matchesWithName(T elem, Predicate<T> isNamed, Predicate<T> nameMatcher)
/*    */     {
/* 55 */       return !isNamed.test(elem);
/*    */     }
/*    */   };
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public <T> boolean matches(T elem, Predicate<T> isNamed) {
/* 73 */     return matchesWithName(elem, isNamed, t -> true);
/*    */   }
/*    */ 
/*    */   
/*    */   public static LookupStrategy get(char[] moduleName) {
/* 78 */     if (moduleName == ModuleBinding.ANY)
/* 79 */       return Any; 
/* 80 */     if (moduleName == ModuleBinding.ANY_NAMED)
/* 81 */       return AnyNamed; 
/* 82 */     if (moduleName == ModuleBinding.UNNAMED)
/* 83 */       return Unnamed; 
/* 84 */     return Named;
/*    */   }
/*    */   
/*    */   public static String getStringName(char[] moduleName) {
/* 88 */     switch (get(moduleName)) { case Named:
/* 89 */         return String.valueOf(moduleName); }
/* 90 */      return null;
/*    */   }
/*    */   
/*    */   public abstract <T> boolean matchesWithName(T paramT, Predicate<T> paramPredicate1, Predicate<T> paramPredicate2);
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\env\IModuleAwareNameEnvironment$LookupStrategy.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */