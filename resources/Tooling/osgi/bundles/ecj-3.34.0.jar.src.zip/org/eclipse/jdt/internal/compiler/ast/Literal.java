/*    */ package org.eclipse.jdt.internal.compiler.ast;
/*    */ 
/*    */ import org.eclipse.jdt.internal.compiler.flow.FlowContext;
/*    */ import org.eclipse.jdt.internal.compiler.flow.FlowInfo;
/*    */ import org.eclipse.jdt.internal.compiler.impl.Constant;
/*    */ import org.eclipse.jdt.internal.compiler.lookup.BlockScope;
/*    */ import org.eclipse.jdt.internal.compiler.lookup.TypeBinding;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class Literal
/*    */   extends Expression
/*    */ {
/*    */   public Literal(int s, int e) {
/* 25 */     this.sourceStart = s;
/* 26 */     this.sourceEnd = e;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public FlowInfo analyseCode(BlockScope currentScope, FlowContext flowContext, FlowInfo flowInfo) {
/* 35 */     return flowInfo;
/*    */   }
/*    */ 
/*    */   
/*    */   public abstract void computeConstant();
/*    */ 
/*    */   
/*    */   public abstract TypeBinding literalType(BlockScope paramBlockScope);
/*    */   
/*    */   public StringBuffer printExpression(int indent, StringBuffer output) {
/* 45 */     return output.append(source());
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public TypeBinding resolveType(BlockScope scope) {
/* 51 */     this.resolvedType = literalType(scope);
/*    */ 
/*    */     
/* 54 */     computeConstant();
/* 55 */     if (this.constant == null) {
/* 56 */       scope.problemReporter().constantOutOfRange(this, this.resolvedType);
/* 57 */       this.constant = Constant.NotAConstant;
/*    */     } 
/* 59 */     return this.resolvedType;
/*    */   }
/*    */   
/*    */   public abstract char[] source();
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\ast\Literal.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */