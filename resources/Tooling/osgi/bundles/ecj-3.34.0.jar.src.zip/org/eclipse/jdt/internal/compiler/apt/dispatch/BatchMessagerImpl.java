/*    */ package org.eclipse.jdt.internal.compiler.apt.dispatch;
/*    */ 
/*    */ import javax.annotation.processing.Messager;
/*    */ import javax.lang.model.element.AnnotationMirror;
/*    */ import javax.lang.model.element.AnnotationValue;
/*    */ import javax.lang.model.element.Element;
/*    */ import javax.tools.Diagnostic;
/*    */ import org.eclipse.jdt.core.compiler.CategorizedProblem;
/*    */ import org.eclipse.jdt.internal.compiler.batch.Main;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class BatchMessagerImpl
/*    */   extends BaseMessagerImpl
/*    */   implements Messager
/*    */ {
/*    */   private final Main _compiler;
/*    */   private final BaseProcessingEnvImpl _processingEnv;
/*    */   
/*    */   public BatchMessagerImpl(BaseProcessingEnvImpl processingEnv, Main compiler) {
/* 36 */     this._compiler = compiler;
/* 37 */     this._processingEnv = processingEnv;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void printMessage(Diagnostic.Kind kind, CharSequence msg) {
/* 45 */     printMessage(kind, msg, null, null, null);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void printMessage(Diagnostic.Kind kind, CharSequence msg, Element e) {
/* 53 */     printMessage(kind, msg, e, null, null);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void printMessage(Diagnostic.Kind kind, CharSequence msg, Element e, AnnotationMirror a) {
/* 62 */     printMessage(kind, msg, e, a, null);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void printMessage(Diagnostic.Kind kind, CharSequence msg, Element e, AnnotationMirror a, AnnotationValue v) {
/* 72 */     if (kind == Diagnostic.Kind.ERROR) {
/* 73 */       this._processingEnv.setErrorRaised(true);
/*    */     }
/* 75 */     AptProblem aptProblem = createProblem(kind, msg, e, a, v);
/* 76 */     if (aptProblem != null)
/* 77 */       this._compiler.addExtraProblems((CategorizedProblem)aptProblem); 
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\apt\dispatch\BatchMessagerImpl.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */