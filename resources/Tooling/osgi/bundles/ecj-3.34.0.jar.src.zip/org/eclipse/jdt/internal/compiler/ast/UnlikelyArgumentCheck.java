/*     */ package org.eclipse.jdt.internal.compiler.ast;
/*     */ 
/*     */ import org.eclipse.jdt.internal.compiler.lookup.BlockScope;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.ParameterizedTypeBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.ReferenceBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.Scope;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.TypeBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.TypeConstants;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class UnlikelyArgumentCheck
/*     */ {
/*     */   public final TypeConstants.DangerousMethod dangerousMethod;
/*     */   public final TypeBinding typeToCheck;
/*     */   public final TypeBinding expectedType;
/*     */   public final TypeBinding typeToReport;
/*     */   
/*     */   private UnlikelyArgumentCheck(TypeConstants.DangerousMethod dangerousMethod, TypeBinding typeToCheck, TypeBinding expectedType, TypeBinding typeToReport) {
/*  34 */     this.dangerousMethod = dangerousMethod;
/*  35 */     this.typeToCheck = typeToCheck;
/*  36 */     this.expectedType = expectedType;
/*  37 */     this.typeToReport = typeToReport;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isDangerous(BlockScope currentScope) {
/*  46 */     TypeBinding typeToCheck2 = this.typeToCheck;
/*     */     
/*  48 */     if (typeToCheck2.isBaseType()) {
/*  49 */       typeToCheck2 = currentScope.boxing(typeToCheck2);
/*     */     }
/*  51 */     TypeBinding expectedType2 = this.expectedType;
/*  52 */     if (expectedType2.isBaseType()) {
/*  53 */       expectedType2 = currentScope.boxing(expectedType2);
/*     */     }
/*  55 */     if (this.dangerousMethod != TypeConstants.DangerousMethod.Equals && (currentScope.compilerOptions()).reportUnlikelyCollectionMethodArgumentTypeStrict) {
/*  56 */       return !typeToCheck2.isCompatibleWith(expectedType2, (Scope)currentScope);
/*     */     }
/*     */     
/*  59 */     if (typeToCheck2.isCapture() || !typeToCheck2.isTypeVariable() || expectedType2.isCapture() || 
/*  60 */       !expectedType2.isTypeVariable()) {
/*  61 */       typeToCheck2 = typeToCheck2.erasure();
/*  62 */       expectedType2 = expectedType2.erasure();
/*     */     } 
/*  64 */     return (!typeToCheck2.isCompatibleWith(expectedType2, (Scope)currentScope) && 
/*  65 */       !expectedType2.isCompatibleWith(typeToCheck2, (Scope)currentScope));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static UnlikelyArgumentCheck determineCheckForNonStaticSingleArgumentMethod(TypeBinding argumentType, Scope scope, char[] selector, TypeBinding actualReceiverType, TypeBinding[] parameters) {
/*  76 */     if (parameters.length != 1)
/*  77 */       return null; 
/*  78 */     int paramTypeId = (parameters[0].original()).id;
/*  79 */     if (paramTypeId != 1 && paramTypeId != 59) {
/*  80 */       return null;
/*     */     }
/*     */     
/*  83 */     TypeConstants.DangerousMethod suspect = TypeConstants.DangerousMethod.detectSelector(selector);
/*  84 */     if (suspect == null) {
/*  85 */       return null;
/*     */     }
/*  87 */     if (actualReceiverType.hasTypeBit(256) && 
/*  88 */       paramTypeId == 1) {
/*  89 */       ReferenceBinding mapType; switch (suspect) {
/*     */         
/*     */         case Remove:
/*     */         case Get:
/*     */         case ContainsKey:
/*  94 */           mapType = actualReceiverType
/*  95 */             .findSuperTypeOriginatingFrom(91, false);
/*  96 */           if (mapType != null && mapType.isParameterizedType()) {
/*  97 */             return new UnlikelyArgumentCheck(suspect, argumentType, (
/*  98 */                 (ParameterizedTypeBinding)mapType).typeArguments()[0], (TypeBinding)mapType);
/*     */           }
/*     */           break;
/*     */         case ContainsValue:
/* 102 */           mapType = actualReceiverType.findSuperTypeOriginatingFrom(91, false);
/* 103 */           if (mapType != null && mapType.isParameterizedType()) {
/* 104 */             return new UnlikelyArgumentCheck(suspect, argumentType, (
/* 105 */                 (ParameterizedTypeBinding)mapType).typeArguments()[1], (TypeBinding)mapType);
/*     */           }
/*     */           break;
/*     */       } 
/*     */     
/*     */     } 
/* 111 */     if (actualReceiverType.hasTypeBit(512)) {
/* 112 */       if (paramTypeId == 1) {
/* 113 */         ReferenceBinding collectionType; switch (suspect) {
/*     */           
/*     */           case null:
/*     */           case Remove:
/* 117 */             collectionType = actualReceiverType
/* 118 */               .findSuperTypeOriginatingFrom(59, false);
/* 119 */             if (collectionType != null && collectionType.isParameterizedType()) {
/* 120 */               return new UnlikelyArgumentCheck(suspect, argumentType, (
/* 121 */                   (ParameterizedTypeBinding)collectionType).typeArguments()[0], (TypeBinding)collectionType);
/*     */             }
/*     */             break;
/*     */         } 
/* 125 */       } else if (paramTypeId == 59) {
/* 126 */         ReferenceBinding collectionType; ReferenceBinding argumentCollectionType; switch (suspect) {
/*     */           
/*     */           case RemoveAll:
/*     */           case ContainsAll:
/*     */           case RetainAll:
/* 131 */             collectionType = actualReceiverType
/* 132 */               .findSuperTypeOriginatingFrom(59, false);
/* 133 */             argumentCollectionType = argumentType
/* 134 */               .findSuperTypeOriginatingFrom(59, false);
/* 135 */             if (collectionType != null && argumentCollectionType != null && 
/* 136 */               argumentCollectionType.isParameterizedTypeWithActualArguments() && 
/* 137 */               collectionType.isParameterizedTypeWithActualArguments()) {
/* 138 */               return new UnlikelyArgumentCheck(suspect, (
/* 139 */                   (ParameterizedTypeBinding)argumentCollectionType).typeArguments()[0], (
/* 140 */                   (ParameterizedTypeBinding)collectionType).typeArguments()[0], (TypeBinding)collectionType);
/*     */             }
/*     */             break;
/*     */         } 
/*     */       
/*     */       } 
/* 146 */       if (actualReceiverType.hasTypeBit(1024) && 
/* 147 */         paramTypeId == 1) {
/* 148 */         ReferenceBinding listType; switch (suspect) {
/*     */           
/*     */           case IndexOf:
/*     */           case LastIndexOf:
/* 152 */             listType = actualReceiverType
/* 153 */               .findSuperTypeOriginatingFrom(92, false);
/* 154 */             if (listType != null && listType.isParameterizedType()) {
/* 155 */               return new UnlikelyArgumentCheck(suspect, argumentType, (
/* 156 */                   (ParameterizedTypeBinding)listType).typeArguments()[0], (TypeBinding)listType);
/*     */             }
/*     */             break;
/*     */         } 
/*     */       
/*     */       } 
/*     */     } 
/* 163 */     if (paramTypeId == 1 && suspect == TypeConstants.DangerousMethod.Equals) {
/* 164 */       return new UnlikelyArgumentCheck(suspect, argumentType, actualReceiverType, actualReceiverType);
/*     */     }
/* 166 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static UnlikelyArgumentCheck determineCheckForStaticTwoArgumentMethod(TypeBinding secondParameter, Scope scope, char[] selector, TypeBinding firstParameter, TypeBinding[] parameters, TypeBinding actualReceiverType) {
/* 172 */     if (parameters.length != 2)
/* 173 */       return null; 
/* 174 */     int paramTypeId1 = (parameters[0].original()).id;
/* 175 */     int paramTypeId2 = (parameters[1].original()).id;
/*     */     
/* 177 */     if (paramTypeId1 != 1 || paramTypeId2 != 1) {
/* 178 */       return null;
/*     */     }
/*     */     
/* 181 */     TypeConstants.DangerousMethod suspect = TypeConstants.DangerousMethod.detectSelector(selector);
/* 182 */     if (suspect == null) {
/* 183 */       return null;
/*     */     }
/* 185 */     if (actualReceiverType.id == 74 && suspect == TypeConstants.DangerousMethod.Equals) {
/* 186 */       return new UnlikelyArgumentCheck(suspect, secondParameter, firstParameter, firstParameter);
/*     */     }
/* 188 */     return null;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\ast\UnlikelyArgumentCheck.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */