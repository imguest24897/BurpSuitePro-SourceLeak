package org.eclipse.jdt.internal.compiler.apt.dispatch;

import java.util.List;
import javax.annotation.processing.Processor;

public interface IProcessorProvider {
  ProcessorInfo discoverNextProcessor();
  
  List<ProcessorInfo> getDiscoveredProcessors();
  
  void reportProcessorException(Processor paramProcessor, Exception paramException);
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\apt\dispatch\IProcessorProvider.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */