/*    */ package org.eclipse.jdt.internal.compiler.flow;
/*    */ 
/*    */ import org.eclipse.jdt.internal.compiler.lookup.ReferenceBinding;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class EscapingExceptionCatchSite
/*    */ {
/*    */   final ReferenceBinding caughtException;
/*    */   final ExceptionHandlingFlowContext catchingContext;
/*    */   final FlowInfo exceptionInfo;
/*    */   
/*    */   public EscapingExceptionCatchSite(ExceptionHandlingFlowContext catchingContext, ReferenceBinding caughtException, FlowInfo exceptionInfo) {
/* 89 */     this.catchingContext = catchingContext;
/* 90 */     this.caughtException = caughtException;
/* 91 */     this.exceptionInfo = exceptionInfo;
/*    */   }
/*    */   void simulateThrowAfterLoopBack(FlowInfo flowInfo) {
/* 94 */     this.catchingContext.recordHandlingException(this.caughtException, 
/* 95 */         flowInfo.unconditionalCopy().addNullInfoFrom(this.exceptionInfo).unconditionalInits(), 
/* 96 */         null, 
/* 97 */         null, null, true);
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\flow\LoopingFlowContext$EscapingExceptionCatchSite.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */