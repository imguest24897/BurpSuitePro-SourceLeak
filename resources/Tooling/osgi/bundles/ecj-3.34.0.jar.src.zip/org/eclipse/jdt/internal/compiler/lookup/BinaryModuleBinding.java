/*     */ package org.eclipse.jdt.internal.compiler.lookup;
/*     */ 
/*     */ import java.net.URI;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.Map;
/*     */ import java.util.stream.Stream;
/*     */ import org.eclipse.jdt.core.compiler.CharOperation;
/*     */ import org.eclipse.jdt.internal.compiler.env.IBinaryAnnotation;
/*     */ import org.eclipse.jdt.internal.compiler.env.IBinaryModule;
/*     */ import org.eclipse.jdt.internal.compiler.env.IModule;
/*     */ import org.eclipse.jdt.internal.compiler.env.IModuleAwareNameEnvironment;
/*     */ import org.eclipse.jdt.internal.compiler.env.IUpdatableModule;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BinaryModuleBinding
/*     */   extends ModuleBinding
/*     */ {
/*     */   private IModule.IPackageExport[] unresolvedExports;
/*     */   private IModule.IPackageExport[] unresolvedOpens;
/*     */   private char[][] unresolvedUses;
/*     */   private IModule.IService[] unresolvedProvides;
/*     */   public URI path;
/*     */   
/*     */   private static class AutomaticModuleBinding
/*     */     extends ModuleBinding
/*     */   {
/*     */     boolean autoNameFromManifest;
/*     */     boolean hasScannedPackages;
/*     */     
/*     */     public AutomaticModuleBinding(IModule module, LookupEnvironment existingEnvironment) {
/*  39 */       super(module.name(), existingEnvironment);
/*  40 */       existingEnvironment.root.knownModules.put(this.moduleName, this);
/*  41 */       this.isAuto = true;
/*  42 */       this.autoNameFromManifest = module.isAutoNameFromManifest();
/*  43 */       this.requires = Binding.NO_MODULES;
/*  44 */       this.requiresTransitive = Binding.NO_MODULES;
/*  45 */       this.exportedPackages = Binding.NO_PLAIN_PACKAGES;
/*  46 */       this.hasScannedPackages = false;
/*     */     }
/*     */     
/*     */     public boolean hasUnstableAutoName() {
/*  50 */       return !this.autoNameFromManifest;
/*     */     }
/*     */     
/*     */     public ModuleBinding[] getRequiresTransitive() {
/*  54 */       if (this.requiresTransitive == NO_MODULES) {
/*  55 */         char[][] autoModules = ((IModuleAwareNameEnvironment)this.environment.nameEnvironment).getAllAutomaticModules();
/*  56 */         this.requiresTransitive = (ModuleBinding[])Stream.<char[]>of(autoModules)
/*  57 */           .filter(name -> !CharOperation.equals(name, this.moduleName))
/*  58 */           .map(name -> this.environment.getModule(name)).filter(m -> (m != null))
/*  59 */           .toArray(param1Int -> new ModuleBinding[param1Int]);
/*     */       } 
/*  61 */       return this.requiresTransitive;
/*     */     }
/*     */     
/*     */     PlainPackageBinding getDeclaredPackage(char[] flatName) {
/*  65 */       if (!this.hasScannedPackages) {
/*  66 */         byte b; int i; char[][] arrayOfChar; for (i = (arrayOfChar = ((IModuleAwareNameEnvironment)this.environment.nameEnvironment).listPackages(nameForCUCheck())).length, b = 0; b < i; ) { char[] packageName = arrayOfChar[b];
/*  67 */           getOrCreateDeclaredPackage(CharOperation.splitOn('.', packageName)); b++; }
/*     */         
/*  69 */         this.hasScannedPackages = true;
/*     */       } 
/*  71 */       return (PlainPackageBinding)this.declaredPackages.get(flatName);
/*     */     }
/*     */ 
/*     */     
/*     */     public char[] nameForLookup() {
/*  76 */       return ANY_NAMED;
/*     */     }
/*     */ 
/*     */     
/*     */     public char[] nameForCUCheck() {
/*  81 */       return this.moduleName;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ModuleBinding create(IModule module, LookupEnvironment existingEnvironment) {
/* 101 */     if (module.isAutomatic())
/* 102 */       return new AutomaticModuleBinding(module, existingEnvironment); 
/* 103 */     return new BinaryModuleBinding((IBinaryModule)module, existingEnvironment);
/*     */   }
/*     */   
/*     */   private BinaryModuleBinding(IBinaryModule module, LookupEnvironment existingEnvironment) {
/* 107 */     super(module.name(), existingEnvironment);
/* 108 */     existingEnvironment.root.knownModules.put(this.moduleName, this);
/* 109 */     cachePartsFrom(module);
/* 110 */     this.path = module.getURI();
/*     */   }
/*     */   
/*     */   void cachePartsFrom(IBinaryModule module) {
/* 114 */     if (module.isOpen())
/* 115 */       this.modifiers |= 0x20; 
/* 116 */     this.tagBits |= module.getTagBits();
/*     */     
/* 118 */     IModule.IModuleReference[] requiresReferences = module.requires();
/* 119 */     this.requires = new ModuleBinding[requiresReferences.length];
/* 120 */     this.requiresTransitive = new ModuleBinding[requiresReferences.length];
/* 121 */     int count = 0;
/* 122 */     int transitiveCount = 0;
/* 123 */     for (int i = 0; i < requiresReferences.length; i++) {
/* 124 */       ModuleBinding requiredModule = this.environment.getModule(requiresReferences[i].name());
/* 125 */       if (requiredModule != null) {
/* 126 */         this.requires[count++] = requiredModule;
/* 127 */         if (requiresReferences[i].isTransitive()) {
/* 128 */           this.requiresTransitive[transitiveCount++] = requiredModule;
/*     */         }
/*     */       } 
/*     */     } 
/* 132 */     if (count < this.requires.length)
/* 133 */       System.arraycopy(this.requires, 0, this.requires = new ModuleBinding[count], 0, count); 
/* 134 */     if (transitiveCount < this.requiresTransitive.length) {
/* 135 */       System.arraycopy(this.requiresTransitive, 0, this.requiresTransitive = new ModuleBinding[transitiveCount], 0, transitiveCount);
/*     */     }
/* 137 */     this.unresolvedExports = module.exports();
/* 138 */     this.unresolvedOpens = module.opens();
/* 139 */     this.unresolvedUses = module.uses();
/* 140 */     this.unresolvedProvides = module.provides();
/* 141 */     if (this.environment.globalOptions.isAnnotationBasedNullAnalysisEnabled) {
/* 142 */       scanForNullDefaultAnnotation(module);
/*     */     }
/* 144 */     if ((this.tagBits & 0x400000000000L) != 0L || this.environment.globalOptions.storeAnnotations) {
/* 145 */       setAnnotations(BinaryTypeBinding.createAnnotations(module.getAnnotations(), this.environment, null), true);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private void scanForNullDefaultAnnotation(IBinaryModule binaryModule) {
/* 151 */     char[][] nonNullByDefaultAnnotationName = this.environment.getNonNullByDefaultAnnotationName();
/* 152 */     if (nonNullByDefaultAnnotationName == null) {
/*     */       return;
/*     */     }
/* 155 */     IBinaryAnnotation[] annotations = binaryModule.getAnnotations();
/* 156 */     if (annotations != null) {
/* 157 */       int nullness = 0;
/* 158 */       int length = annotations.length;
/* 159 */       for (int i = 0; i < length; i++) {
/* 160 */         char[] annotationTypeName = annotations[i].getTypeName();
/* 161 */         if (annotationTypeName[0] == 'L') {
/*     */           
/* 163 */           int typeBit = this.environment.getNullAnnotationBit(BinaryTypeBinding.signature2qualifiedTypeName(annotationTypeName));
/* 164 */           if (typeBit == 128)
/*     */           {
/* 166 */             nullness |= BinaryTypeBinding.getNonNullByDefaultValue(annotations[i], this.environment); } 
/*     */         } 
/*     */       } 
/* 169 */       this.defaultNullness = nullness;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public PlainPackageBinding[] getExports() {
/* 175 */     if (this.exportedPackages == null && this.unresolvedExports != null)
/* 176 */       resolvePackages(); 
/* 177 */     return super.getExports();
/*     */   }
/*     */ 
/*     */   
/*     */   public PlainPackageBinding[] getOpens() {
/* 182 */     if (this.openedPackages == null && this.unresolvedOpens != null)
/* 183 */       resolvePackages(); 
/* 184 */     return super.getOpens();
/*     */   }
/*     */   
/*     */   private void resolvePackages() {
/* 188 */     this.exportedPackages = new PlainPackageBinding[this.unresolvedExports.length];
/* 189 */     int count = 0; int i;
/* 190 */     for (i = 0; i < this.unresolvedExports.length; i++) {
/* 191 */       IModule.IPackageExport export = this.unresolvedExports[i];
/*     */ 
/*     */       
/* 194 */       PlainPackageBinding declaredPackage = getOrCreateDeclaredPackage(CharOperation.splitOn('.', export.name()));
/* 195 */       this.exportedPackages[count++] = declaredPackage;
/* 196 */       declaredPackage.isExported = Boolean.TRUE;
/* 197 */       recordExportRestrictions(declaredPackage, export.targets());
/*     */     } 
/* 199 */     if (count < this.exportedPackages.length) {
/* 200 */       System.arraycopy(this.exportedPackages, 0, this.exportedPackages = new PlainPackageBinding[count], 0, count);
/*     */     }
/* 202 */     this.openedPackages = new PlainPackageBinding[this.unresolvedOpens.length];
/* 203 */     count = 0;
/* 204 */     for (i = 0; i < this.unresolvedOpens.length; i++) {
/* 205 */       IModule.IPackageExport opens = this.unresolvedOpens[i];
/* 206 */       PlainPackageBinding declaredPackage = getOrCreateDeclaredPackage(CharOperation.splitOn('.', opens.name()));
/* 207 */       this.openedPackages[count++] = declaredPackage;
/* 208 */       recordOpensRestrictions(declaredPackage, opens.targets());
/*     */     } 
/* 210 */     if (count < this.openedPackages.length) {
/* 211 */       System.arraycopy(this.openedPackages, 0, this.openedPackages = new PlainPackageBinding[count], 0, count);
/*     */     }
/*     */   }
/*     */   
/*     */   PlainPackageBinding getDeclaredPackage(char[] flatName) {
/* 216 */     getExports();
/* 217 */     completeIfNeeded(IUpdatableModule.UpdateKind.PACKAGE);
/* 218 */     return super.getDeclaredPackage(flatName);
/*     */   }
/*     */ 
/*     */   
/*     */   public TypeBinding[] getUses() {
/* 223 */     if (this.uses == null) {
/* 224 */       this.uses = new TypeBinding[this.unresolvedUses.length];
/* 225 */       for (int i = 0; i < this.unresolvedUses.length; i++)
/* 226 */         this.uses[i] = this.environment.getType(CharOperation.splitOn('.', this.unresolvedUses[i]), this); 
/*     */     } 
/* 228 */     return super.getUses();
/*     */   }
/*     */ 
/*     */   
/*     */   public TypeBinding[] getServices() {
/* 233 */     if (this.services == null)
/* 234 */       resolveServices(); 
/* 235 */     return super.getServices();
/*     */   }
/*     */ 
/*     */   
/*     */   public TypeBinding[] getImplementations(TypeBinding binding) {
/* 240 */     if (this.implementations == null)
/* 241 */       resolveServices(); 
/* 242 */     return super.getImplementations(binding);
/*     */   }
/*     */   private void resolveServices() {
/* 245 */     this.services = new TypeBinding[this.unresolvedProvides.length];
/* 246 */     this.implementations = (Map)new LinkedHashMap<>();
/* 247 */     for (int i = 0; i < this.unresolvedProvides.length; i++) {
/* 248 */       this.services[i] = this.environment.getType(CharOperation.splitOn('.', this.unresolvedProvides[i].name()), this);
/* 249 */       char[][] implNames = this.unresolvedProvides[i].with();
/* 250 */       TypeBinding[] impls = new TypeBinding[implNames.length];
/* 251 */       for (int j = 0; j < implNames.length; j++)
/* 252 */         impls[j] = this.environment.getType(CharOperation.splitOn('.', implNames[j]), this); 
/* 253 */       this.implementations.put(this.services[i], impls);
/*     */     } 
/*     */   }
/*     */   
/*     */   public AnnotationBinding[] getAnnotations() {
/* 258 */     return retrieveAnnotations(this);
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\lookup\BinaryModuleBinding.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */