/*     */ package org.eclipse.jdt.internal.compiler.ast;
/*     */ 
/*     */ import java.util.function.BooleanSupplier;
/*     */ import org.eclipse.jdt.core.compiler.CharOperation;
/*     */ import org.eclipse.jdt.internal.compiler.ASTVisitor;
/*     */ import org.eclipse.jdt.internal.compiler.codegen.BranchLabel;
/*     */ import org.eclipse.jdt.internal.compiler.codegen.CodeStream;
/*     */ import org.eclipse.jdt.internal.compiler.flow.FlowContext;
/*     */ import org.eclipse.jdt.internal.compiler.flow.FlowInfo;
/*     */ import org.eclipse.jdt.internal.compiler.impl.CompilerOptions;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.AnnotationBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.ArrayBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.BlockScope;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.ClassScope;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.LocalVariableBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.LookupEnvironment;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.MethodBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.ReferenceBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.Scope;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.TypeBinding;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class Statement
/*     */   extends ASTNode
/*     */ {
/*     */   public static final int NOT_COMPLAINED = 0;
/*     */   public static final int COMPLAINED_FAKE_REACHABLE = 1;
/*     */   public static final int COMPLAINED_UNREACHABLE = 2;
/*     */   LocalVariableBinding[] patternVarsWhenTrue;
/*     */   LocalVariableBinding[] patternVarsWhenFalse;
/*     */   
/*     */   protected static boolean isKnowDeadCodePattern(Expression expression) {
/*  65 */     if (expression instanceof UnaryExpression) {
/*  66 */       expression = ((UnaryExpression)expression).expression;
/*     */     }
/*     */     
/*  69 */     if (expression instanceof Reference) return true;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  86 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract FlowInfo analyseCode(BlockScope paramBlockScope, FlowContext paramFlowContext, FlowInfo paramFlowInfo);
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean doesNotCompleteNormally() {
/*  96 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean completesByContinue() {
/* 104 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean canCompleteNormally() {
/* 115 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean continueCompletes() {
/* 122 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void analyseArguments(BlockScope currentScope, FlowContext flowContext, FlowInfo flowInfo, MethodBinding methodBinding, Expression[] arguments) {
/* 135 */     if (arguments != null) {
/* 136 */       CompilerOptions compilerOptions = currentScope.compilerOptions();
/* 137 */       if (compilerOptions.sourceLevel >= 3342336L && methodBinding.isPolymorphic())
/*     */         return; 
/* 139 */       boolean considerTypeAnnotations = currentScope.environment().usesNullTypeAnnotations();
/* 140 */       boolean hasJDK15NullAnnotations = (methodBinding.parameterNonNullness != null);
/* 141 */       int numParamsToCheck = methodBinding.parameters.length;
/* 142 */       int varArgPos = -1;
/* 143 */       TypeBinding varArgsType = null;
/* 144 */       boolean passThrough = false;
/* 145 */       if (considerTypeAnnotations || hasJDK15NullAnnotations)
/*     */       {
/* 147 */         if (methodBinding.isVarargs()) {
/* 148 */           varArgPos = numParamsToCheck - 1;
/*     */           
/* 150 */           varArgsType = methodBinding.parameters[varArgPos];
/* 151 */           if (numParamsToCheck == arguments.length) {
/* 152 */             TypeBinding lastType = (arguments[varArgPos]).resolvedType;
/* 153 */             if (lastType == TypeBinding.NULL || (
/* 154 */               varArgsType.dimensions() == lastType.dimensions() && 
/* 155 */               lastType.isCompatibleWith(varArgsType)))
/* 156 */               passThrough = true; 
/*     */           } 
/* 158 */           if (!passThrough)
/* 159 */             numParamsToCheck--; 
/*     */         } 
/*     */       }
/* 162 */       if (considerTypeAnnotations) {
/* 163 */         for (int i = 0; i < numParamsToCheck; i++) {
/* 164 */           TypeBinding expectedType = methodBinding.parameters[i];
/* 165 */           Boolean specialCaseNonNullness = hasJDK15NullAnnotations ? methodBinding.parameterNonNullness[i] : null;
/* 166 */           analyseOneArgument18(currentScope, flowContext, flowInfo, expectedType, arguments[i], 
/* 167 */               specialCaseNonNullness, (methodBinding.original()).parameters[i]);
/*     */         } 
/* 169 */         if (!passThrough && varArgsType instanceof ArrayBinding) {
/* 170 */           TypeBinding expectedType = ((ArrayBinding)varArgsType).elementsType();
/* 171 */           Boolean specialCaseNonNullness = hasJDK15NullAnnotations ? methodBinding.parameterNonNullness[varArgPos] : null;
/* 172 */           for (int j = numParamsToCheck; j < arguments.length; j++) {
/* 173 */             analyseOneArgument18(currentScope, flowContext, flowInfo, expectedType, arguments[j], 
/* 174 */                 specialCaseNonNullness, (methodBinding.original()).parameters[varArgPos]);
/*     */           }
/*     */         } 
/* 177 */       } else if (hasJDK15NullAnnotations) {
/* 178 */         for (int i = 0; i < numParamsToCheck; i++) {
/* 179 */           if (methodBinding.parameterNonNullness[i] == Boolean.TRUE) {
/* 180 */             TypeBinding expectedType = methodBinding.parameters[i];
/* 181 */             Expression argument = arguments[i];
/* 182 */             int nullStatus = argument.nullStatus(flowInfo, flowContext);
/* 183 */             if (nullStatus != 4)
/* 184 */               flowContext.recordNullityMismatch(currentScope, argument, argument.resolvedType, expectedType, flowInfo, nullStatus, null); 
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   void analyseOneArgument18(BlockScope currentScope, FlowContext flowContext, FlowInfo flowInfo, TypeBinding expectedType, Expression argument, Boolean expectedNonNullness, TypeBinding originalExpected) {
/* 192 */     if (argument instanceof ConditionalExpression && argument.isPolyExpression()) {
/*     */       
/* 194 */       ConditionalExpression ce = (ConditionalExpression)argument;
/* 195 */       ce.internalAnalyseOneArgument18(currentScope, flowContext, expectedType, ce.valueIfTrue, flowInfo, ce.ifTrueNullStatus, expectedNonNullness, originalExpected);
/* 196 */       ce.internalAnalyseOneArgument18(currentScope, flowContext, expectedType, ce.valueIfFalse, flowInfo, ce.ifFalseNullStatus, expectedNonNullness, originalExpected); return;
/*     */     } 
/* 198 */     if (argument instanceof SwitchExpression && argument.isPolyExpression()) {
/* 199 */       SwitchExpression se = (SwitchExpression)argument;
/* 200 */       for (int i = 0; i < se.resultExpressions.size(); i++) {
/* 201 */         se.internalAnalyseOneArgument18(currentScope, flowContext, expectedType, 
/* 202 */             se.resultExpressions.get(i), flowInfo, (
/* 203 */             (Integer)se.resultExpressionNullStatus.get(i)).intValue(), expectedNonNullness, originalExpected);
/*     */       }
/*     */       
/*     */       return;
/*     */     } 
/* 208 */     int nullStatus = argument.nullStatus(flowInfo, flowContext);
/* 209 */     internalAnalyseOneArgument18(currentScope, flowContext, expectedType, argument, flowInfo, 
/* 210 */         nullStatus, expectedNonNullness, originalExpected);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   void internalAnalyseOneArgument18(BlockScope currentScope, FlowContext flowContext, TypeBinding expectedType, Expression argument, FlowInfo flowInfo, int nullStatus, Boolean expectedNonNullness, TypeBinding originalExpected) {
/* 216 */     int statusFromAnnotatedNull = (expectedNonNullness == Boolean.TRUE) ? nullStatus : 0;
/*     */     
/* 218 */     NullAnnotationMatching annotationStatus = NullAnnotationMatching.analyse(expectedType, argument.resolvedType, nullStatus);
/*     */     
/* 220 */     if (!annotationStatus.isAnyMismatch() && statusFromAnnotatedNull != 0) {
/* 221 */       expectedType = originalExpected;
/*     */     }
/* 223 */     if (statusFromAnnotatedNull == 2) {
/*     */       
/* 225 */       currentScope.problemReporter().nullityMismatchingTypeAnnotation(argument, argument.resolvedType, expectedType, annotationStatus);
/* 226 */     } else if (annotationStatus.isAnyMismatch() || (statusFromAnnotatedNull & 0x10) != 0) {
/* 227 */       if (!expectedType.hasNullTypeAnnotations() && expectedNonNullness == Boolean.TRUE) {
/*     */         
/* 229 */         LookupEnvironment env = currentScope.environment();
/* 230 */         expectedType = env.createAnnotatedType(expectedType, new AnnotationBinding[] { env.getNonNullAnnotation() });
/*     */       } 
/* 232 */       flowContext.recordNullityMismatch(currentScope, argument, argument.resolvedType, expectedType, flowInfo, nullStatus, annotationStatus);
/*     */     } 
/*     */   } void checkAgainstNullAnnotation(BlockScope scope, FlowContext flowContext, FlowInfo flowInfo, Expression expr) {
/*     */     long tagBits;
/* 236 */     int nullStatus = expr.nullStatus(flowInfo, flowContext);
/*     */     
/* 238 */     MethodBinding methodBinding = null;
/* 239 */     boolean useTypeAnnotations = scope.environment().usesNullTypeAnnotations();
/*     */     try {
/* 241 */       methodBinding = scope.methodScope().referenceMethodBinding();
/* 242 */       tagBits = useTypeAnnotations ? methodBinding.returnType.tagBits : methodBinding.tagBits;
/* 243 */     } catch (NullPointerException nullPointerException) {
/*     */       return;
/*     */     } 
/*     */ 
/*     */     
/* 248 */     if (useTypeAnnotations) {
/* 249 */       checkAgainstNullTypeAnnotation(scope, methodBinding.returnType, expr, flowContext, flowInfo);
/* 250 */     } else if (nullStatus != 4) {
/*     */       
/* 252 */       if ((tagBits & 0x100000000000000L) != 0L) {
/* 253 */         flowContext.recordNullityMismatch(scope, expr, expr.resolvedType, methodBinding.returnType, flowInfo, nullStatus, null);
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   protected void checkAgainstNullTypeAnnotation(BlockScope scope, TypeBinding requiredType, Expression expression, FlowContext flowContext, FlowInfo flowInfo) {
/* 259 */     if (expression instanceof ConditionalExpression && expression.isPolyExpression()) {
/*     */       
/* 261 */       ConditionalExpression ce = (ConditionalExpression)expression;
/* 262 */       internalCheckAgainstNullTypeAnnotation(scope, requiredType, ce.valueIfTrue, ce.ifTrueNullStatus, flowContext, flowInfo);
/* 263 */       internalCheckAgainstNullTypeAnnotation(scope, requiredType, ce.valueIfFalse, ce.ifFalseNullStatus, flowContext, flowInfo); return;
/*     */     } 
/* 265 */     if (expression instanceof SwitchExpression && expression.isPolyExpression()) {
/* 266 */       SwitchExpression se = (SwitchExpression)expression;
/* 267 */       for (int i = 0; i < se.resultExpressions.size(); i++) {
/* 268 */         internalCheckAgainstNullTypeAnnotation(scope, requiredType, 
/* 269 */             se.resultExpressions.get(i), (
/* 270 */             (Integer)se.resultExpressionNullStatus.get(i)).intValue(), flowContext, flowInfo);
/*     */       }
/*     */       return;
/*     */     } 
/* 274 */     int nullStatus = expression.nullStatus(flowInfo, flowContext);
/* 275 */     internalCheckAgainstNullTypeAnnotation(scope, requiredType, expression, nullStatus, flowContext, flowInfo);
/*     */   }
/*     */   
/*     */   private void internalCheckAgainstNullTypeAnnotation(BlockScope scope, TypeBinding requiredType, Expression expression, int nullStatus, FlowContext flowContext, FlowInfo flowInfo) {
/* 279 */     NullAnnotationMatching annotationStatus = NullAnnotationMatching.analyse(requiredType, expression.resolvedType, null, null, nullStatus, expression, NullAnnotationMatching.CheckMode.COMPATIBLE);
/* 280 */     if (annotationStatus.isDefiniteMismatch()) {
/* 281 */       scope.problemReporter().nullityMismatchingTypeAnnotation(expression, expression.resolvedType, requiredType, annotationStatus);
/*     */     } else {
/* 283 */       if (annotationStatus.wantToReport())
/* 284 */         annotationStatus.report((Scope)scope); 
/* 285 */       if (annotationStatus.isUnchecked()) {
/* 286 */         flowContext.recordNullityMismatch(scope, expression, expression.resolvedType, requiredType, flowInfo, nullStatus, annotationStatus);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void branchChainTo(BranchLabel label) {}
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean breaksOut(final char[] label) {
/* 301 */     return (new ASTVisitor() {
/*     */         boolean breaksOut;
/*     */         
/*     */         public boolean visit(TypeDeclaration type, BlockScope skope) {
/* 305 */           return (label != null);
/*     */         } public boolean visit(TypeDeclaration type, ClassScope skope) {
/* 307 */           return (label != null);
/*     */         } public boolean visit(LambdaExpression lambda, BlockScope skope) {
/* 309 */           return (label != null);
/*     */         } public boolean visit(WhileStatement whileStatement, BlockScope skope) {
/* 311 */           return (label != null);
/*     */         } public boolean visit(DoStatement doStatement, BlockScope skope) {
/* 313 */           return (label != null);
/*     */         } public boolean visit(ForeachStatement foreachStatement, BlockScope skope) {
/* 315 */           return (label != null);
/*     */         } public boolean visit(ForStatement forStatement, BlockScope skope) {
/* 317 */           return (label != null);
/*     */         } public boolean visit(SwitchStatement switchStatement, BlockScope skope) {
/* 319 */           return (label != null);
/*     */         }
/*     */         
/*     */         public boolean visit(BreakStatement breakStatement, BlockScope skope) {
/* 323 */           if (label == null || CharOperation.equals(label, breakStatement.label))
/* 324 */             this.breaksOut = true; 
/* 325 */           return false;
/*     */         }
/*     */         
/*     */         public boolean visit(YieldStatement yieldStatement, BlockScope skope) {
/* 329 */           return false;
/*     */         }
/*     */         public boolean breaksOut() {
/* 332 */           Statement.this.traverse(this, null);
/* 333 */           return this.breaksOut;
/*     */         }
/* 335 */       }).breaksOut();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean continuesAtOuterLabel() {
/* 343 */     return (new ASTVisitor() {
/*     */         boolean continuesToLabel;
/*     */         
/*     */         public boolean visit(ContinueStatement continueStatement, BlockScope skope) {
/* 347 */           if (continueStatement.label != null)
/* 348 */             this.continuesToLabel = true; 
/* 349 */           return false;
/*     */         }
/*     */         public boolean continuesAtOuterLabel() {
/* 352 */           Statement.this.traverse(this, null);
/* 353 */           return this.continuesToLabel;
/*     */         }
/* 355 */       }).continuesAtOuterLabel();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int complainIfUnreachable(FlowInfo flowInfo, BlockScope scope, int previousComplaintLevel, boolean endOfBlock) {
/* 361 */     if ((flowInfo.reachMode() & 0x3) != 0) {
/* 362 */       if ((flowInfo.reachMode() & 0x1) != 0)
/* 363 */         this.bits &= Integer.MAX_VALUE; 
/* 364 */       if (flowInfo == FlowInfo.DEAD_END) {
/* 365 */         if (previousComplaintLevel < 2) {
/* 366 */           if (!doNotReportUnreachable())
/* 367 */             scope.problemReporter().unreachableCode(this); 
/* 368 */           if (endOfBlock)
/* 369 */             scope.checkUnclosedCloseables(flowInfo, null, null, null); 
/*     */         } 
/* 371 */         return 2;
/*     */       } 
/* 373 */       if (previousComplaintLevel < 1) {
/* 374 */         scope.problemReporter().fakeReachable(this);
/* 375 */         if (endOfBlock)
/* 376 */           scope.checkUnclosedCloseables(flowInfo, null, null, null); 
/*     */       } 
/* 378 */       return 1;
/*     */     } 
/*     */     
/* 381 */     return previousComplaintLevel;
/*     */   }
/*     */   
/*     */   protected boolean doNotReportUnreachable() {
/* 385 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void generateArguments(MethodBinding binding, Expression[] arguments, BlockScope currentScope, CodeStream codeStream) {
/* 391 */     if (binding.isVarargs()) {
/*     */ 
/*     */       
/* 394 */       TypeBinding[] params = binding.parameters;
/* 395 */       int paramLength = params.length;
/* 396 */       int varArgIndex = paramLength - 1;
/* 397 */       for (int i = 0; i < varArgIndex; i++) {
/* 398 */         arguments[i].generateCode(currentScope, codeStream, true);
/*     */       }
/* 400 */       ArrayBinding varArgsType = (ArrayBinding)params[varArgIndex];
/* 401 */       ArrayBinding codeGenVarArgsType = (ArrayBinding)binding.parameters[varArgIndex].erasure();
/* 402 */       int elementsTypeID = (varArgsType.elementsType()).id;
/* 403 */       int argLength = (arguments == null) ? 0 : arguments.length;
/*     */       
/* 405 */       if (argLength > paramLength) {
/*     */ 
/*     */ 
/*     */         
/* 409 */         codeStream.generateInlinedValue(argLength - varArgIndex);
/* 410 */         codeStream.newArray(codeGenVarArgsType);
/* 411 */         for (int j = varArgIndex; j < argLength; j++) {
/* 412 */           codeStream.dup();
/* 413 */           codeStream.generateInlinedValue(j - varArgIndex);
/* 414 */           arguments[j].generateCode(currentScope, codeStream, true);
/* 415 */           codeStream.arrayAtPut(elementsTypeID, false);
/*     */         } 
/* 417 */       } else if (argLength == paramLength) {
/*     */         
/* 419 */         TypeBinding lastType = (arguments[varArgIndex]).resolvedType;
/* 420 */         if (lastType == TypeBinding.NULL || (
/* 421 */           varArgsType.dimensions() == lastType.dimensions() && 
/* 422 */           lastType.isCompatibleWith((TypeBinding)codeGenVarArgsType)))
/*     */         {
/* 424 */           arguments[varArgIndex].generateCode(currentScope, codeStream, true);
/*     */         }
/*     */         else
/*     */         {
/* 428 */           codeStream.generateInlinedValue(1);
/* 429 */           codeStream.newArray(codeGenVarArgsType);
/* 430 */           codeStream.dup();
/* 431 */           codeStream.generateInlinedValue(0);
/* 432 */           arguments[varArgIndex].generateCode(currentScope, codeStream, true);
/* 433 */           codeStream.arrayAtPut(elementsTypeID, false);
/*     */         }
/*     */       
/*     */       } else {
/*     */         
/* 438 */         codeStream.generateInlinedValue(0);
/* 439 */         codeStream.newArray(codeGenVarArgsType);
/*     */       } 
/* 441 */     } else if (arguments != null) {
/* 442 */       for (int i = 0, max = arguments.length; i < max; i++)
/* 443 */         arguments[i].generateCode(currentScope, codeStream, true); 
/*     */     } 
/*     */   }
/*     */   
/*     */   public abstract void generateCode(BlockScope paramBlockScope, CodeStream paramCodeStream);
/*     */   
/*     */   public boolean isBoxingCompatible(TypeBinding expressionType, TypeBinding targetType, Expression expression, Scope scope) {
/* 450 */     if (scope.isBoxingCompatibleWith(expressionType, targetType)) {
/* 451 */       return true;
/*     */     }
/* 453 */     return (expressionType.isBaseType() && 
/* 454 */       !targetType.isBaseType() && 
/* 455 */       !targetType.isTypeVariable() && 
/* 456 */       (scope.compilerOptions()).sourceLevel >= 3211264L && (
/* 457 */       targetType.id == 26 || targetType.id == 27 || targetType.id == 28) && 
/* 458 */       expression.isConstantValueOfTypeAssignableToType(expressionType, scope.environment().computeBoxingType(targetType)));
/*     */   }
/*     */   
/*     */   public boolean isEmptyBlock() {
/* 462 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isValidJavaStatement() {
/* 477 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public StringBuffer print(int indent, StringBuffer output) {
/* 482 */     return printStatement(indent, output);
/*     */   }
/*     */   public abstract StringBuffer printStatement(int paramInt, StringBuffer paramStringBuffer);
/*     */   
/*     */   public abstract void resolve(BlockScope paramBlockScope);
/*     */   
/*     */   public LocalVariableBinding[] getPatternVariablesWhenTrue() {
/* 489 */     return this.patternVarsWhenTrue;
/*     */   }
/*     */   public LocalVariableBinding[] getPatternVariablesWhenFalse() {
/* 492 */     return this.patternVarsWhenFalse;
/*     */   }
/*     */   public void addPatternVariablesWhenTrue(LocalVariableBinding[] vars) {
/* 495 */     if (vars == null || vars.length == 0)
/* 496 */       return;  if (this.patternVarsWhenTrue == vars)
/* 497 */       return;  this.patternVarsWhenTrue = addPatternVariables(this.patternVarsWhenTrue, vars);
/*     */   }
/*     */   public void addPatternVariablesWhenFalse(LocalVariableBinding[] vars) {
/* 500 */     if (vars == null || vars.length == 0)
/* 501 */       return;  if (this.patternVarsWhenFalse == vars)
/* 502 */       return;  this.patternVarsWhenFalse = addPatternVariables(this.patternVarsWhenFalse, vars);
/*     */   }
/*     */   private LocalVariableBinding[] addPatternVariables(LocalVariableBinding[] current, LocalVariableBinding[] add) {
/* 505 */     if (add == null || add.length == 0)
/* 506 */       return current; 
/* 507 */     if (current == null) {
/* 508 */       current = add;
/*     */     } else {
/* 510 */       byte b; int i; LocalVariableBinding[] arrayOfLocalVariableBinding; for (i = (arrayOfLocalVariableBinding = add).length, b = 0; b < i; ) { LocalVariableBinding local = arrayOfLocalVariableBinding[b];
/* 511 */         current = addPatternVariables(current, local); b++; }
/*     */     
/*     */     } 
/* 514 */     return current;
/*     */   }
/*     */   private LocalVariableBinding[] addPatternVariables(LocalVariableBinding[] current, LocalVariableBinding add) {
/* 517 */     int oldSize = current.length;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 522 */     if (oldSize > 0 && current[oldSize - 1] == add) {
/* 523 */       return current;
/*     */     }
/* 525 */     int newLength = current.length + 1;
/* 526 */     System.arraycopy(current, 0, current = new LocalVariableBinding[newLength], 0, oldSize);
/* 527 */     current[oldSize] = add;
/* 528 */     return current;
/*     */   }
/*     */   public void promotePatternVariablesIfApplicable(LocalVariableBinding[] patternVariablesInScope, BooleanSupplier condition) {
/* 531 */     if (patternVariablesInScope != null && condition.getAsBoolean()) {
/* 532 */       byte b; int i; LocalVariableBinding[] arrayOfLocalVariableBinding; for (i = (arrayOfLocalVariableBinding = patternVariablesInScope).length, b = 0; b < i; ) { LocalVariableBinding binding = arrayOfLocalVariableBinding[b];
/* 533 */         binding.modifiers &= 0xEFFFFFFF;
/*     */         b++; }
/*     */     
/*     */     } 
/*     */   } public void resolveWithPatternVariablesInScope(LocalVariableBinding[] patternVariablesInScope, BlockScope scope) {
/* 538 */     if (patternVariablesInScope != null) {
/* 539 */       byte b; int i; LocalVariableBinding[] arrayOfLocalVariableBinding; for (i = (arrayOfLocalVariableBinding = patternVariablesInScope).length, b = 0; b < i; ) { LocalVariableBinding binding = arrayOfLocalVariableBinding[b];
/* 540 */         binding.modifiers &= 0xEFFFFFFF; b++; }
/*     */       
/* 542 */       resolve(scope);
/* 543 */       for (i = (arrayOfLocalVariableBinding = patternVariablesInScope).length, b = 0; b < i; ) { LocalVariableBinding binding = arrayOfLocalVariableBinding[b];
/* 544 */         binding.modifiers |= 0x10000000; b++; }
/*     */     
/*     */     } else {
/* 547 */       resolve(scope);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TypeBinding resolveExpressionType(BlockScope scope) {
/* 555 */     return null;
/*     */   }
/*     */   public boolean containsPatternVariable() {
/* 558 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TypeBinding invocationTargetType() {
/* 566 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public TypeBinding expectedType() {
/* 571 */     return invocationTargetType();
/*     */   }
/*     */   public ExpressionContext getExpressionContext() {
/* 574 */     return ExpressionContext.VANILLA_CONTEXT;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected MethodBinding findConstructorBinding(BlockScope scope, Invocation site, ReferenceBinding receiverType, TypeBinding[] argumentTypes) {
/* 582 */     MethodBinding ctorBinding = scope.getConstructor(receiverType, argumentTypes, site);
/* 583 */     return resolvePolyExpressionArguments(site, ctorBinding, argumentTypes, scope);
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\ast\Statement.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */