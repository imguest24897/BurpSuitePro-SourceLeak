/*     */ package org.eclipse.jdt.internal.compiler.ast;
/*     */ 
/*     */ import org.eclipse.jdt.internal.compiler.ASTVisitor;
/*     */ import org.eclipse.jdt.internal.compiler.codegen.BranchLabel;
/*     */ import org.eclipse.jdt.internal.compiler.codegen.CodeStream;
/*     */ import org.eclipse.jdt.internal.compiler.flow.FlowContext;
/*     */ import org.eclipse.jdt.internal.compiler.flow.FlowInfo;
/*     */ import org.eclipse.jdt.internal.compiler.flow.LoopingFlowContext;
/*     */ import org.eclipse.jdt.internal.compiler.flow.UnconditionalFlowInfo;
/*     */ import org.eclipse.jdt.internal.compiler.impl.Constant;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.BlockScope;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.LocalVariableBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.Scope;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.TypeBinding;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ForStatement
/*     */   extends Statement
/*     */ {
/*     */   public Statement[] initializations;
/*     */   public Expression condition;
/*     */   public Statement[] increments;
/*     */   public Statement action;
/*     */   public BlockScope scope;
/*     */   private BranchLabel breakLabel;
/*     */   private BranchLabel continueLabel;
/*  49 */   int preCondInitStateIndex = -1;
/*  50 */   int preIncrementsInitStateIndex = -1;
/*  51 */   int condIfTrueInitStateIndex = -1;
/*  52 */   int mergedInitStateIndex = -1;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ForStatement(Statement[] initializations, Expression condition, Statement[] increments, Statement action, boolean neededScope, int s, int e) {
/*  63 */     this.sourceStart = s;
/*  64 */     this.sourceEnd = e;
/*  65 */     this.initializations = initializations;
/*  66 */     this.condition = condition;
/*  67 */     this.increments = increments;
/*  68 */     this.action = action;
/*     */     
/*  70 */     if (action instanceof EmptyStatement) action.bits |= 0x1; 
/*  71 */     if (neededScope)
/*  72 */       this.bits |= 0x20000000; 
/*     */   }
/*     */   public FlowInfo analyseCode(BlockScope currentScope, FlowContext flowContext, FlowInfo flowInfo) {
/*     */     FlowInfo flowInfo1;
/*     */     LoopingFlowContext loopingContext;
/*     */     UnconditionalFlowInfo actionInfo;
/*  78 */     this.breakLabel = new BranchLabel();
/*  79 */     this.continueLabel = new BranchLabel();
/*  80 */     int initialComplaintLevel = ((flowInfo.reachMode() & 0x3) != 0) ? 1 : 0;
/*     */ 
/*     */     
/*  83 */     if (this.initializations != null) {
/*  84 */       for (int i = 0, count = this.initializations.length; i < count; i++) {
/*  85 */         flowInfo = this.initializations[i].analyseCode(this.scope, flowContext, flowInfo);
/*     */       }
/*     */     }
/*  88 */     this.preCondInitStateIndex = 
/*  89 */       currentScope.methodScope().recordInitializationStates(flowInfo);
/*     */     
/*  91 */     Constant cst = (this.condition == null) ? null : this.condition.constant;
/*  92 */     boolean isConditionTrue = !(cst != null && (cst == Constant.NotAConstant || !cst.booleanValue()));
/*  93 */     boolean isConditionFalse = (cst != null && cst != Constant.NotAConstant && !cst.booleanValue());
/*     */     
/*  95 */     cst = (this.condition == null) ? null : this.condition.optimizedBooleanConstant();
/*  96 */     boolean isConditionOptimizedTrue = !(cst != null && (cst == Constant.NotAConstant || !cst.booleanValue()));
/*  97 */     boolean isConditionOptimizedFalse = (cst != null && cst != Constant.NotAConstant && !cst.booleanValue());
/*     */ 
/*     */     
/* 100 */     LoopingFlowContext condLoopContext = null;
/* 101 */     UnconditionalFlowInfo unconditionalFlowInfo1 = flowInfo.nullInfoLessUnconditionalCopy();
/* 102 */     if (this.condition != null && 
/* 103 */       !isConditionTrue) {
/* 104 */       flowInfo1 = 
/* 105 */         this.condition.analyseCode(
/* 106 */           this.scope, 
/* 107 */           (FlowContext)(condLoopContext = 
/* 108 */           new LoopingFlowContext(flowContext, flowInfo, this, null, 
/* 109 */             null, (Scope)this.scope, true)), 
/* 110 */           (FlowInfo)unconditionalFlowInfo1);
/* 111 */       this.condition.checkNPEbyUnboxing(currentScope, flowContext, flowInfo);
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 118 */     if (this.action == null || (
/* 119 */       this.action.isEmptyBlock() && (currentScope.compilerOptions()).complianceLevel <= 3080192L)) {
/* 120 */       if (condLoopContext != null)
/* 121 */         condLoopContext.complainOnDeferredFinalChecks(this.scope, flowInfo1); 
/* 122 */       if (isConditionTrue) {
/* 123 */         if (condLoopContext != null) {
/* 124 */           condLoopContext.complainOnDeferredNullChecks(currentScope, 
/* 125 */               flowInfo1);
/*     */         }
/* 127 */         return (FlowInfo)FlowInfo.DEAD_END;
/*     */       } 
/* 129 */       if (isConditionFalse) {
/* 130 */         this.continueLabel = null;
/*     */       }
/* 132 */       actionInfo = flowInfo1.initsWhenTrue().unconditionalCopy();
/* 133 */       loopingContext = 
/* 134 */         new LoopingFlowContext(flowContext, flowInfo, this, 
/* 135 */           this.breakLabel, this.continueLabel, (Scope)this.scope, false);
/*     */     
/*     */     }
/*     */     else {
/*     */ 
/*     */       
/* 141 */       loopingContext = 
/* 142 */         new LoopingFlowContext(flowContext, flowInfo, this, this.breakLabel, 
/* 143 */           this.continueLabel, (Scope)this.scope, true);
/* 144 */       FlowInfo initsWhenTrue = flowInfo1.initsWhenTrue();
/* 145 */       this.condIfTrueInitStateIndex = 
/* 146 */         currentScope.methodScope().recordInitializationStates(initsWhenTrue);
/*     */       
/* 148 */       if (isConditionFalse) {
/* 149 */         actionInfo = FlowInfo.DEAD_END;
/*     */       } else {
/* 151 */         actionInfo = initsWhenTrue.unconditionalCopy();
/* 152 */         if (isConditionOptimizedFalse) {
/* 153 */           actionInfo.setReachMode(1);
/*     */         }
/*     */       } 
/* 156 */       if (this.action.complainIfUnreachable((FlowInfo)actionInfo, this.scope, initialComplaintLevel, true) < 2) {
/* 157 */         if (this.condition != null)
/* 158 */           this.condition.updateFlowOnBooleanResult((FlowInfo)actionInfo, true); 
/* 159 */         actionInfo = this.action.analyseCode(this.scope, (FlowContext)loopingContext, (FlowInfo)actionInfo).unconditionalInits();
/*     */       } 
/*     */ 
/*     */       
/* 163 */       if ((actionInfo.tagBits & 
/* 164 */         loopingContext.initsOnContinue.tagBits & 
/* 165 */         0x1) != 0) {
/* 166 */         this.continueLabel = null;
/*     */       } else {
/*     */         
/* 169 */         if (condLoopContext != null) {
/* 170 */           condLoopContext.complainOnDeferredFinalChecks(this.scope, 
/* 171 */               flowInfo1);
/*     */         }
/* 173 */         actionInfo = actionInfo.mergedWith(loopingContext.initsOnContinue);
/* 174 */         loopingContext.complainOnDeferredFinalChecks(this.scope, 
/* 175 */             (FlowInfo)actionInfo);
/*     */       } 
/*     */     } 
/*     */     
/* 179 */     FlowInfo exitBranch = flowInfo.copy();
/*     */     
/* 181 */     LoopingFlowContext incrementContext = null;
/* 182 */     if (this.continueLabel != null) {
/* 183 */       if (this.increments != null) {
/* 184 */         FlowInfo flowInfo2; incrementContext = 
/* 185 */           new LoopingFlowContext(flowContext, flowInfo, this, null, 
/* 186 */             null, (Scope)this.scope, true);
/* 187 */         UnconditionalFlowInfo unconditionalFlowInfo = actionInfo;
/* 188 */         this.preIncrementsInitStateIndex = 
/* 189 */           currentScope.methodScope().recordInitializationStates((FlowInfo)unconditionalFlowInfo);
/* 190 */         for (int i = 0, count = this.increments.length; i < count; i++) {
/* 191 */           flowInfo2 = this.increments[i]
/* 192 */             .analyseCode(this.scope, (FlowContext)incrementContext, (FlowInfo)unconditionalFlowInfo);
/*     */         }
/* 194 */         incrementContext.complainOnDeferredFinalChecks(this.scope, 
/* 195 */             (FlowInfo)(actionInfo = flowInfo2.unconditionalInits()));
/*     */       } 
/* 197 */       exitBranch.addPotentialInitializationsFrom((FlowInfo)actionInfo)
/* 198 */         .addInitializationsFrom(flowInfo1.initsWhenFalse());
/*     */     } else {
/* 200 */       exitBranch.addInitializationsFrom(flowInfo1.initsWhenFalse());
/* 201 */       if (this.increments != null && 
/* 202 */         initialComplaintLevel == 0) {
/* 203 */         currentScope.problemReporter().fakeReachable(this.increments[0]);
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 208 */     if (condLoopContext != null) {
/* 209 */       condLoopContext.complainOnDeferredNullChecks(currentScope, 
/* 210 */           (FlowInfo)actionInfo);
/*     */     }
/* 212 */     loopingContext.complainOnDeferredNullChecks(currentScope, 
/* 213 */         (FlowInfo)actionInfo);
/* 214 */     if (incrementContext != null) {
/* 215 */       incrementContext.complainOnDeferredNullChecks(currentScope, 
/* 216 */           (FlowInfo)actionInfo);
/*     */     }
/* 218 */     if (loopingContext.hasEscapingExceptions()) {
/* 219 */       UnconditionalFlowInfo unconditionalFlowInfo; FlowInfo loopbackFlowInfo = flowInfo.copy();
/* 220 */       if (this.continueLabel != null)
/*     */       {
/* 222 */         unconditionalFlowInfo = loopbackFlowInfo.mergedWith(loopbackFlowInfo.unconditionalCopy().addNullInfoFrom((FlowInfo)actionInfo).unconditionalInits());
/*     */       }
/* 224 */       loopingContext.simulateThrowAfterLoopBack((FlowInfo)unconditionalFlowInfo);
/*     */     } 
/*     */     
/* 227 */     UnconditionalFlowInfo unconditionalFlowInfo2 = FlowInfo.mergedOptimizedBranches(
/* 228 */         ((loopingContext.initsOnBreak.tagBits & 
/* 229 */         0x3) != 0) ? 
/* 230 */         (FlowInfo)loopingContext.initsOnBreak : 
/* 231 */         flowInfo.addInitializationsFrom((FlowInfo)loopingContext.initsOnBreak), 
/* 232 */         isConditionOptimizedTrue, 
/* 233 */         exitBranch, 
/* 234 */         isConditionOptimizedFalse, 
/* 235 */         !isConditionTrue);
/*     */ 
/*     */     
/* 238 */     if (this.initializations != null) {
/* 239 */       for (int i = 0; i < this.initializations.length; i++) {
/* 240 */         Statement init = this.initializations[i];
/* 241 */         if (init instanceof LocalDeclaration) {
/* 242 */           LocalVariableBinding binding = ((LocalDeclaration)init).binding;
/* 243 */           unconditionalFlowInfo2.resetAssignmentInfo(binding);
/*     */         } 
/*     */       } 
/*     */     }
/* 247 */     this.mergedInitStateIndex = currentScope.methodScope().recordInitializationStates((FlowInfo)unconditionalFlowInfo2);
/* 248 */     this.scope.checkUnclosedCloseables((FlowInfo)unconditionalFlowInfo2, (FlowContext)loopingContext, null, null);
/* 249 */     if (this.condition != null)
/* 250 */       this.condition.updateFlowOnBooleanResult((FlowInfo)unconditionalFlowInfo2, false); 
/* 251 */     return (FlowInfo)unconditionalFlowInfo2;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void generateCode(BlockScope currentScope, CodeStream codeStream) {
/* 262 */     if ((this.bits & Integer.MIN_VALUE) == 0) {
/*     */       return;
/*     */     }
/* 265 */     int pc = codeStream.position;
/*     */ 
/*     */     
/* 268 */     if (this.initializations != null) {
/* 269 */       for (int i = 0, max = this.initializations.length; i < max; i++) {
/* 270 */         this.initializations[i].generateCode(this.scope, codeStream);
/*     */       }
/*     */     }
/* 273 */     if (containsPatternVariable()) {
/* 274 */       this.condition.addPatternVariables(currentScope, codeStream);
/*     */     }
/* 276 */     Constant cst = (this.condition == null) ? null : this.condition.optimizedBooleanConstant();
/* 277 */     boolean isConditionOptimizedFalse = (cst != null && cst != Constant.NotAConstant && !cst.booleanValue());
/* 278 */     if (isConditionOptimizedFalse) {
/* 279 */       this.condition.generateCode(this.scope, codeStream, false);
/*     */       
/* 281 */       if ((this.bits & 0x20000000) != 0) {
/* 282 */         codeStream.exitUserScope(this.scope);
/*     */       }
/* 284 */       if (this.mergedInitStateIndex != -1) {
/* 285 */         codeStream.removeNotDefinitelyAssignedVariables((Scope)currentScope, this.mergedInitStateIndex);
/* 286 */         codeStream.addDefinitelyAssignedVariables((Scope)currentScope, this.mergedInitStateIndex);
/*     */       } 
/* 288 */       codeStream.recordPositionsFrom(pc, this.sourceStart);
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/* 293 */     BranchLabel actionLabel = new BranchLabel(codeStream);
/* 294 */     actionLabel.tagBits |= 0x2;
/* 295 */     BranchLabel conditionLabel = new BranchLabel(codeStream);
/* 296 */     this.breakLabel.initialize(codeStream);
/* 297 */     if (this.continueLabel == null) {
/* 298 */       conditionLabel.place();
/* 299 */       if (this.condition != null && this.condition.constant == Constant.NotAConstant) {
/* 300 */         this.condition.generateOptimizedBoolean(this.scope, codeStream, (BranchLabel)null, this.breakLabel, true);
/*     */       }
/*     */     } else {
/* 303 */       this.continueLabel.initialize(codeStream);
/*     */       
/* 305 */       if (this.condition != null && 
/* 306 */         this.condition.constant == Constant.NotAConstant && ((
/* 307 */         this.action != null && !this.action.isEmptyBlock()) || this.increments != null)) {
/* 308 */         conditionLabel.tagBits |= 0x2;
/* 309 */         int jumpPC = codeStream.position;
/* 310 */         codeStream.goto_(conditionLabel);
/* 311 */         codeStream.recordPositionsFrom(jumpPC, this.condition.sourceStart);
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 316 */     if (this.action != null) {
/*     */       
/* 318 */       if (this.condIfTrueInitStateIndex != -1)
/*     */       {
/* 320 */         codeStream.addDefinitelyAssignedVariables(
/* 321 */             (Scope)currentScope, 
/* 322 */             this.condIfTrueInitStateIndex);
/*     */       }
/* 324 */       actionLabel.place();
/* 325 */       this.action.generateCode(this.scope, codeStream);
/*     */     } else {
/* 327 */       actionLabel.place();
/*     */     } 
/* 329 */     if (this.preIncrementsInitStateIndex != -1) {
/* 330 */       codeStream.removeNotDefinitelyAssignedVariables((Scope)currentScope, this.preIncrementsInitStateIndex);
/* 331 */       codeStream.addDefinitelyAssignedVariables((Scope)currentScope, this.preIncrementsInitStateIndex);
/*     */     } 
/*     */     
/* 334 */     if (this.continueLabel != null) {
/* 335 */       this.continueLabel.place();
/*     */       
/* 337 */       if (this.increments != null) {
/* 338 */         for (int i = 0, max = this.increments.length; i < max; i++) {
/* 339 */           this.increments[i].generateCode(this.scope, codeStream);
/*     */         }
/*     */       }
/*     */ 
/*     */       
/* 344 */       if (this.preCondInitStateIndex != -1) {
/* 345 */         codeStream.removeNotDefinitelyAssignedVariables((Scope)currentScope, this.preCondInitStateIndex);
/*     */       }
/*     */       
/* 348 */       conditionLabel.place();
/* 349 */       if (this.condition != null && this.condition.constant == Constant.NotAConstant) {
/* 350 */         this.condition.generateOptimizedBoolean(this.scope, codeStream, actionLabel, (BranchLabel)null, true);
/*     */       } else {
/* 352 */         codeStream.goto_(actionLabel);
/*     */       
/*     */       }
/*     */     
/*     */     }
/* 357 */     else if (this.preCondInitStateIndex != -1) {
/* 358 */       codeStream.removeNotDefinitelyAssignedVariables((Scope)currentScope, this.preCondInitStateIndex);
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 364 */     if ((this.bits & 0x20000000) != 0) {
/* 365 */       codeStream.exitUserScope(this.scope);
/*     */     }
/* 367 */     if (this.mergedInitStateIndex != -1) {
/* 368 */       codeStream.removeNotDefinitelyAssignedVariables((Scope)currentScope, this.mergedInitStateIndex);
/* 369 */       codeStream.addDefinitelyAssignedVariables((Scope)currentScope, this.mergedInitStateIndex);
/*     */     } 
/* 371 */     this.breakLabel.place();
/* 372 */     codeStream.recordPositionsFrom(pc, this.sourceStart);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public StringBuffer printStatement(int tab, StringBuffer output) {
/* 378 */     printIndent(tab, output).append("for (");
/*     */     
/* 380 */     if (this.initializations != null) {
/* 381 */       for (int i = 0; i < this.initializations.length; i++) {
/*     */         
/* 383 */         if (i > 0) output.append(", "); 
/* 384 */         this.initializations[i].print(0, output);
/*     */       } 
/*     */     }
/* 387 */     output.append("; ");
/*     */     
/* 389 */     if (this.condition != null) this.condition.printExpression(0, output); 
/* 390 */     output.append("; ");
/*     */     
/* 392 */     if (this.increments != null) {
/* 393 */       for (int i = 0; i < this.increments.length; i++) {
/* 394 */         if (i > 0) output.append(", "); 
/* 395 */         this.increments[i].print(0, output);
/*     */       } 
/*     */     }
/* 398 */     output.append(") ");
/*     */     
/* 400 */     if (this.action == null) {
/* 401 */       output.append(';');
/*     */     } else {
/* 403 */       output.append('\n');
/* 404 */       this.action.printStatement(tab + 1, output);
/*     */     } 
/* 406 */     return output;
/*     */   }
/*     */ 
/*     */   
/*     */   public void resolve(BlockScope upperScope) {
/* 411 */     LocalVariableBinding[] patternVariablesInTrueScope = null;
/* 412 */     LocalVariableBinding[] patternVariablesInFalseScope = null;
/*     */     
/* 414 */     if (containsPatternVariable()) {
/* 415 */       this.condition.collectPatternVariablesToScope((LocalVariableBinding[])null, upperScope);
/* 416 */       patternVariablesInTrueScope = this.condition.getPatternVariablesWhenTrue();
/* 417 */       patternVariablesInFalseScope = this.condition.getPatternVariablesWhenFalse();
/*     */     } 
/*     */     
/* 420 */     this.scope = ((this.bits & 0x20000000) != 0) ? new BlockScope(upperScope) : upperScope;
/* 421 */     if (this.initializations != null)
/* 422 */       for (int i = 0, length = this.initializations.length; i < length; i++)
/* 423 */         this.initializations[i].resolve(this.scope);  
/* 424 */     if (this.condition != null) {
/* 425 */       TypeBinding type = this.condition.resolveTypeExpecting(this.scope, (TypeBinding)TypeBinding.BOOLEAN);
/* 426 */       this.condition.computeConversion((Scope)this.scope, type, type);
/*     */     } 
/* 428 */     if (this.increments != null) {
/* 429 */       for (int i = 0, length = this.increments.length; i < length; i++) {
/* 430 */         this.increments[i].resolveWithPatternVariablesInScope(patternVariablesInTrueScope, this.scope);
/*     */       }
/*     */     }
/* 433 */     if (this.action != null) {
/* 434 */       this.action.resolveWithPatternVariablesInScope(patternVariablesInTrueScope, this.scope);
/* 435 */       this.action.promotePatternVariablesIfApplicable(patternVariablesInFalseScope, () -> !this.action.breaksOut((char[])null));
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean containsPatternVariable() {
/* 442 */     return (this.condition != null && this.condition.containsPatternVariable());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void traverse(ASTVisitor visitor, BlockScope blockScope) {
/* 450 */     if (visitor.visit(this, blockScope)) {
/* 451 */       if (this.initializations != null) {
/* 452 */         int initializationsLength = this.initializations.length;
/* 453 */         for (int i = 0; i < initializationsLength; i++) {
/* 454 */           this.initializations[i].traverse(visitor, this.scope);
/*     */         }
/*     */       } 
/* 457 */       if (this.condition != null) {
/* 458 */         this.condition.traverse(visitor, this.scope);
/*     */       }
/* 460 */       if (this.increments != null) {
/* 461 */         int incrementsLength = this.increments.length;
/* 462 */         for (int i = 0; i < incrementsLength; i++) {
/* 463 */           this.increments[i].traverse(visitor, this.scope);
/*     */         }
/*     */       } 
/* 466 */       if (this.action != null)
/* 467 */         this.action.traverse(visitor, this.scope); 
/*     */     } 
/* 469 */     visitor.endVisit(this, blockScope);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean doesNotCompleteNormally() {
/* 474 */     Constant cst = (this.condition == null) ? null : this.condition.constant;
/* 475 */     boolean isConditionTrue = !(cst != null && (cst == Constant.NotAConstant || !cst.booleanValue()));
/* 476 */     cst = (this.condition == null) ? null : this.condition.optimizedBooleanConstant();
/* 477 */     boolean isConditionOptimizedTrue = (cst == null) ? true : ((cst != Constant.NotAConstant && cst.booleanValue()));
/*     */     
/* 479 */     return ((isConditionTrue || isConditionOptimizedTrue) && (this.action == null || !this.action.breaksOut((char[])null)));
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean completesByContinue() {
/* 484 */     return this.action.continuesAtOuterLabel();
/*     */   }
/*     */   
/*     */   public boolean canCompleteNormally() {
/* 488 */     Constant cst = (this.condition == null) ? null : this.condition.constant;
/* 489 */     boolean isConditionTrue = !(cst != null && (cst == Constant.NotAConstant || !cst.booleanValue()));
/* 490 */     cst = (this.condition == null) ? null : this.condition.optimizedBooleanConstant();
/* 491 */     boolean isConditionOptimizedTrue = (cst == null) ? true : ((cst != Constant.NotAConstant && cst.booleanValue()));
/*     */     
/* 493 */     if (!isConditionTrue && !isConditionOptimizedTrue)
/* 494 */       return true; 
/* 495 */     if (this.action != null && this.action.breaksOut((char[])null))
/* 496 */       return true; 
/* 497 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean continueCompletes() {
/* 502 */     return this.action.continuesAtOuterLabel();
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\ast\ForStatement.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */