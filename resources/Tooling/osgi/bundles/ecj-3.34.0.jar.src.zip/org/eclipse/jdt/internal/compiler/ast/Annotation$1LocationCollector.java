/*     */ package org.eclipse.jdt.internal.compiler.ast;
/*     */ 
/*     */ import java.util.Stack;
/*     */ import org.eclipse.jdt.internal.compiler.ASTVisitor;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.BlockScope;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.ReferenceBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.TypeBinding;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class LocationCollector
/*     */   extends ASTVisitor
/*     */ {
/*     */   Stack typePathEntries;
/*     */   Annotation searchedAnnotation;
/*     */   boolean continueSearch = true;
/*     */   
/*     */   public LocationCollector(Annotation currentAnnotation) {
/*  74 */     this.typePathEntries = new Stack();
/*  75 */     this.searchedAnnotation = currentAnnotation;
/*     */   }
/*     */   
/*     */   private int[] computeNestingDepth(TypeReference typeReference) {
/*  79 */     TypeBinding type = (typeReference.resolvedType == null) ? null : typeReference.resolvedType.leafComponentType();
/*  80 */     int[] nestingDepths = new int[typeReference.getAnnotatableLevels()];
/*  81 */     if (type != null && type.isNestedType()) {
/*  82 */       int depth = 0;
/*  83 */       TypeBinding currentType = type;
/*  84 */       while (currentType != null) {
/*  85 */         depth += currentType.isStatic() ? 0 : 1;
/*  86 */         ReferenceBinding referenceBinding = currentType.enclosingType();
/*     */       } 
/*     */       
/*  89 */       int counter = nestingDepths.length - 1;
/*  90 */       while (type != null && counter >= 0) {
/*  91 */         nestingDepths[counter--] = depth;
/*  92 */         depth -= type.isStatic() ? 0 : 1;
/*  93 */         ReferenceBinding referenceBinding = type.enclosingType();
/*     */       } 
/*     */     } 
/*  96 */     return nestingDepths;
/*     */   }
/*     */ 
/*     */   
/*     */   private void inspectAnnotations(Annotation[] annotations) {
/* 101 */     for (int i = 0, length = (annotations == null) ? 0 : annotations.length; this.continueSearch && i < length; i++) {
/* 102 */       if (annotations[i] == this.searchedAnnotation) {
/* 103 */         this.continueSearch = false;
/*     */         break;
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private void inspectArrayDimensions(Annotation[][] annotationsOnDimensions, int dimensions) {
/* 110 */     for (int i = 0; this.continueSearch && i < dimensions; i++) {
/* 111 */       Annotation[] annotations = (annotationsOnDimensions == null) ? null : annotationsOnDimensions[i];
/* 112 */       inspectAnnotations(annotations);
/* 113 */       if (!this.continueSearch)
/* 114 */         return;  this.typePathEntries.push(Annotation.TYPE_PATH_ELEMENT_ARRAY);
/*     */     } 
/*     */   }
/*     */   
/*     */   private void inspectTypeArguments(TypeReference[] typeReferences) {
/* 119 */     for (int i = 0, length = (typeReferences == null) ? 0 : typeReferences.length; this.continueSearch && i < length; i++) {
/* 120 */       int size = this.typePathEntries.size();
/* 121 */       this.typePathEntries.add(new int[] { 3, i });
/* 122 */       typeReferences[i].traverse(this, (BlockScope)null);
/* 123 */       if (!this.continueSearch)
/* 124 */         return;  this.typePathEntries.setSize(size);
/*     */     } 
/*     */   }
/*     */   
/*     */   public boolean visit(TypeReference typeReference, BlockScope scope) {
/* 129 */     if (this.continueSearch) {
/* 130 */       inspectArrayDimensions(typeReference.getAnnotationsOnDimensions(), typeReference.dimensions());
/* 131 */       if (this.continueSearch) {
/* 132 */         int[] nestingDepths = computeNestingDepth(typeReference);
/* 133 */         Annotation[][] annotations = typeReference.annotations;
/* 134 */         TypeReference[][] typeArguments = typeReference.getTypeArguments();
/* 135 */         int levels = typeReference.getAnnotatableLevels();
/* 136 */         int size = this.typePathEntries.size();
/* 137 */         for (int i = levels - 1; this.continueSearch && i >= 0; i--) {
/* 138 */           this.typePathEntries.setSize(size);
/* 139 */           for (int j = 0, depth = nestingDepths[i]; j < depth; j++)
/* 140 */             this.typePathEntries.add(Annotation.TYPE_PATH_INNER_TYPE); 
/* 141 */           if (annotations != null)
/* 142 */             inspectAnnotations(annotations[i]); 
/* 143 */           if (this.continueSearch && typeArguments != null) {
/* 144 */             inspectTypeArguments(typeArguments[i]);
/*     */           }
/*     */         } 
/*     */       } 
/*     */     } 
/* 149 */     return false;
/*     */   }
/*     */   
/*     */   public boolean visit(SingleTypeReference typeReference, BlockScope scope) {
/* 153 */     return visit(typeReference, scope);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean visit(ArrayTypeReference typeReference, BlockScope scope) {
/* 158 */     return visit(typeReference, scope);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean visit(ParameterizedSingleTypeReference typeReference, BlockScope scope) {
/* 163 */     return visit(typeReference, scope);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean visit(QualifiedTypeReference typeReference, BlockScope scope) {
/* 168 */     return visit(typeReference, scope);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean visit(ArrayQualifiedTypeReference typeReference, BlockScope scope) {
/* 173 */     return visit(typeReference, scope);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean visit(ParameterizedQualifiedTypeReference typeReference, BlockScope scope) {
/* 178 */     return visit(typeReference, scope);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean visit(Wildcard typeReference, BlockScope scope) {
/* 183 */     visit(typeReference, scope);
/* 184 */     if (this.continueSearch) {
/* 185 */       TypeReference bound = typeReference.bound;
/* 186 */       if (bound != null) {
/* 187 */         int size = this.typePathEntries.size();
/* 188 */         this.typePathEntries.push(Annotation.TYPE_PATH_ANNOTATION_ON_WILDCARD_BOUND);
/* 189 */         bound.traverse(this, scope);
/* 190 */         if (this.continueSearch)
/* 191 */           this.typePathEntries.setSize(size); 
/*     */       } 
/*     */     } 
/* 194 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean visit(ArrayAllocationExpression allocationExpression, BlockScope scope) {
/* 199 */     if (this.continueSearch) {
/* 200 */       inspectArrayDimensions(allocationExpression.getAnnotationsOnDimensions(), allocationExpression.dimensions.length);
/* 201 */       if (this.continueSearch) {
/* 202 */         allocationExpression.type.traverse(this, scope);
/*     */       }
/* 204 */       if (this.continueSearch) throw new IllegalStateException(); 
/*     */     } 
/* 206 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 211 */     StringBuffer buffer = new StringBuffer();
/* 212 */     buffer
/* 213 */       .append("search location for ")
/* 214 */       .append(this.searchedAnnotation)
/* 215 */       .append("\ncurrent type_path entries : ");
/* 216 */     for (int i = 0, maxi = this.typePathEntries.size(); i < maxi; i++) {
/* 217 */       int[] typePathEntry = this.typePathEntries.get(i);
/* 218 */       buffer
/* 219 */         .append('(')
/* 220 */         .append(typePathEntry[0])
/* 221 */         .append(',')
/* 222 */         .append(typePathEntry[1])
/* 223 */         .append(')');
/*     */     } 
/* 225 */     return String.valueOf(buffer);
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\ast\Annotation$1LocationCollector.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */