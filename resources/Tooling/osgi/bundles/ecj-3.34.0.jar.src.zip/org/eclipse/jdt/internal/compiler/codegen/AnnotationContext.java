/*    */ package org.eclipse.jdt.internal.compiler.codegen;
/*    */ 
/*    */ import org.eclipse.jdt.internal.compiler.ast.Annotation;
/*    */ import org.eclipse.jdt.internal.compiler.ast.Expression;
/*    */ import org.eclipse.jdt.internal.compiler.ast.Wildcard;
/*    */ import org.eclipse.jdt.internal.compiler.lookup.LocalVariableBinding;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AnnotationContext
/*    */ {
/*    */   public static final int VISIBLE = 1;
/*    */   public static final int INVISIBLE = 2;
/*    */   public Annotation annotation;
/*    */   public Expression typeReference;
/*    */   public int targetType;
/*    */   public int info;
/*    */   public int info2;
/*    */   public int visibility;
/*    */   public LocalVariableBinding variableBinding;
/*    */   public Wildcard wildcard;
/*    */   
/*    */   public AnnotationContext(Annotation annotation, Expression typeReference, int targetType, int visibility) {
/* 40 */     this.annotation = annotation;
/* 41 */     this.typeReference = typeReference;
/* 42 */     this.targetType = targetType;
/* 43 */     this.visibility = visibility;
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 48 */     return "AnnotationContext [annotation=" + 
/* 49 */       this.annotation + 
/* 50 */       ", typeReference=" + 
/* 51 */       this.typeReference + 
/* 52 */       ", targetType=" + 
/* 53 */       this.targetType + 
/* 54 */       ", info =" + 
/* 55 */       this.info + 
/* 56 */       ", boundIndex=" + 
/* 57 */       this.info2 + 
/* 58 */       "]";
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\codegen\AnnotationContext.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */