/*     */ package org.eclipse.jdt.internal.compiler.apt.dispatch;
/*     */ 
/*     */ import java.lang.reflect.Field;
/*     */ import java.nio.charset.Charset;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import javax.tools.JavaFileManager;
/*     */ import org.eclipse.jdt.internal.compiler.apt.util.EclipseFileManager;
/*     */ import org.eclipse.jdt.internal.compiler.batch.Main;
/*     */ import org.eclipse.jdt.internal.compiler.problem.AbortCompilation;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BatchProcessingEnvImpl
/*     */   extends BaseProcessingEnvImpl
/*     */ {
/*     */   protected final BaseAnnotationProcessorManager _dispatchManager;
/*     */   protected final JavaFileManager _fileManager;
/*     */   protected final Main _compilerOwner;
/*     */   
/*     */   public BatchProcessingEnvImpl(BaseAnnotationProcessorManager dispatchManager, Main batchCompiler, String[] commandLineArguments) {
/*  50 */     this._compilerOwner = batchCompiler;
/*  51 */     this._compiler = batchCompiler.batchCompiler;
/*  52 */     this._dispatchManager = dispatchManager;
/*  53 */     Class<?> c = null;
/*     */     try {
/*  55 */       c = Class.forName("org.eclipse.jdt.internal.compiler.tool.EclipseCompilerImpl");
/*  56 */     } catch (ClassNotFoundException classNotFoundException) {}
/*     */ 
/*     */     
/*  59 */     Field field = null;
/*  60 */     JavaFileManager javaFileManager = null;
/*  61 */     if (c != null) {
/*     */       try {
/*  63 */         field = c.getField("fileManager");
/*  64 */       } catch (SecurityException securityException) {
/*     */       
/*  66 */       } catch (IllegalArgumentException illegalArgumentException) {
/*     */       
/*  68 */       } catch (NoSuchFieldException noSuchFieldException) {}
/*     */     }
/*     */ 
/*     */     
/*  72 */     if (field != null) {
/*     */       try {
/*  74 */         javaFileManager = (JavaFileManager)field.get(batchCompiler);
/*  75 */       } catch (IllegalArgumentException illegalArgumentException) {
/*     */       
/*  77 */       } catch (IllegalAccessException illegalAccessException) {}
/*     */     }
/*     */ 
/*     */     
/*  81 */     if (javaFileManager != null) {
/*  82 */       this._fileManager = javaFileManager;
/*     */     } else {
/*  84 */       String encoding = (String)batchCompiler.options.get("org.eclipse.jdt.core.encoding");
/*  85 */       Charset charset = (encoding != null) ? Charset.forName(encoding) : null;
/*  86 */       EclipseFileManager eclipseFileManager = new EclipseFileManager(batchCompiler.compilerLocale, charset);
/*  87 */       ArrayList<String> options = new ArrayList<>();
/*  88 */       options.addAll(Arrays.asList(commandLineArguments));
/*  89 */       for (Iterator<String> iterator = options.iterator(); iterator.hasNext();) {
/*  90 */         eclipseFileManager.handleOption(iterator.next(), iterator);
/*     */       }
/*  92 */       this._fileManager = (JavaFileManager)eclipseFileManager;
/*     */     } 
/*  94 */     this._processorOptions = Collections.unmodifiableMap(parseProcessorOptions(commandLineArguments));
/*  95 */     this._filer = new BatchFilerImpl(this._dispatchManager, this);
/*  96 */     this._messager = new BatchMessagerImpl(this, this._compilerOwner);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Map<String, String> parseProcessorOptions(String[] args) {
/* 112 */     Map<String, String> options = new LinkedHashMap<>(); byte b; int i; String[] arrayOfString;
/* 113 */     for (i = (arrayOfString = args).length, b = 0; b < i; ) { String arg = arrayOfString[b];
/* 114 */       if (arg.startsWith("-A")) {
/*     */ 
/*     */         
/* 117 */         int equals = arg.indexOf('=');
/* 118 */         if (equals == 2) {
/*     */           
/* 120 */           Exception e = new IllegalArgumentException("-A option must have a key before the equals sign");
/* 121 */           throw new AbortCompilation(null, e);
/*     */         } 
/* 123 */         if (equals == arg.length() - 1) {
/*     */           
/* 125 */           options.put(arg.substring(2, equals), null);
/* 126 */         } else if (equals == -1) {
/*     */           
/* 128 */           options.put(arg.substring(2), null);
/*     */         } else {
/*     */           
/* 131 */           options.put(arg.substring(2, equals), arg.substring(equals + 1));
/*     */         } 
/*     */       }  b++; }
/* 134 */      return options;
/*     */   }
/*     */   
/*     */   public JavaFileManager getFileManager() {
/* 138 */     return this._fileManager;
/*     */   }
/*     */ 
/*     */   
/*     */   public Locale getLocale() {
/* 143 */     return this._compilerOwner.compilerLocale;
/*     */   }
/*     */   
/*     */   public boolean shouldIgnoreOptionalProblems(char[] fileName) {
/* 147 */     return Main.shouldIgnoreOptionalProblems(this._compilerOwner.ignoreOptionalProblemsFromFolders, fileName);
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\apt\dispatch\BatchProcessingEnvImpl.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */