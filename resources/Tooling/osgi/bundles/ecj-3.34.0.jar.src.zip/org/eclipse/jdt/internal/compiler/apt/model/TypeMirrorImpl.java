/*     */ package org.eclipse.jdt.internal.compiler.apt.model;
/*     */ 
/*     */ import java.lang.reflect.Array;
/*     */ import java.util.List;
/*     */ import javax.lang.model.element.AnnotationMirror;
/*     */ import javax.lang.model.type.TypeKind;
/*     */ import javax.lang.model.type.TypeMirror;
/*     */ import javax.lang.model.type.TypeVisitor;
/*     */ import org.eclipse.jdt.internal.compiler.apt.dispatch.BaseProcessingEnvImpl;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.AnnotationBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.Binding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.TypeBinding;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TypeMirrorImpl
/*     */   implements TypeMirror
/*     */ {
/*     */   protected final BaseProcessingEnvImpl _env;
/*     */   protected final Binding _binding;
/*     */   
/*     */   TypeMirrorImpl(BaseProcessingEnvImpl env, Binding binding) {
/*  44 */     this._env = env;
/*  45 */     this._binding = binding;
/*     */   }
/*     */   
/*     */   Binding binding() {
/*  49 */     return this._binding;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <R, P> R accept(TypeVisitor<R, P> v, P p) {
/*  57 */     return v.visit(this, p);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TypeKind getKind() {
/*  65 */     switch (this._binding.kind()) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       case 1:
/*     */       case 2:
/*     */       case 3:
/*     */       case 32:
/*     */       case 131072:
/*  83 */         throw new IllegalArgumentException("Invalid binding kind: " + this._binding.kind());
/*     */     } 
/*  85 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/*  93 */     return new String(this._binding.readableName());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 102 */     int result = 1;
/* 103 */     result = 31 * result + ((this._binding == null) ? 0 : this._binding.hashCode());
/* 104 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object obj) {
/* 112 */     if (this == obj)
/* 113 */       return true; 
/* 114 */     if (!(obj instanceof TypeMirrorImpl))
/* 115 */       return false; 
/* 116 */     TypeMirrorImpl other = (TypeMirrorImpl)obj;
/* 117 */     return (this._binding == other._binding);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final AnnotationBinding[] getPackedAnnotationBindings() {
/* 126 */     return Factory.getPackedAnnotationBindings(getAnnotationBindings());
/*     */   }
/*     */   
/*     */   protected AnnotationBinding[] getAnnotationBindings() {
/* 130 */     return ((TypeBinding)this._binding).getTypeAnnotations();
/*     */   }
/*     */ 
/*     */   
/*     */   public List<? extends AnnotationMirror> getAnnotationMirrors() {
/* 135 */     return (this._env == null) ? Factory.EMPTY_ANNOTATION_MIRRORS : 
/* 136 */       this._env.getFactory().getAnnotationMirrors(getPackedAnnotationBindings());
/*     */   }
/*     */ 
/*     */   
/*     */   public <A extends java.lang.annotation.Annotation> A getAnnotation(Class<A> annotationType) {
/* 141 */     return (this._env == null) ? null : this._env.getFactory().<A>getAnnotation(getPackedAnnotationBindings(), annotationType);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public <A extends java.lang.annotation.Annotation> A[] getAnnotationsByType(Class<A> annotationType) {
/* 147 */     if (this._env == null)
/* 148 */       return (A[])Array.newInstance(annotationType, 0); 
/* 149 */     return this._env.getFactory().getAnnotationsByType(Factory.getUnpackedAnnotationBindings(getPackedAnnotationBindings()), annotationType);
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\apt\model\TypeMirrorImpl.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */