/*     */ package org.eclipse.jdt.internal.compiler.batch;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import org.eclipse.jdt.core.compiler.CharOperation;
/*     */ import org.eclipse.jdt.internal.compiler.ast.ExportsStatement;
/*     */ import org.eclipse.jdt.internal.compiler.ast.ModuleDeclaration;
/*     */ import org.eclipse.jdt.internal.compiler.ast.ModuleReference;
/*     */ import org.eclipse.jdt.internal.compiler.ast.OpensStatement;
/*     */ import org.eclipse.jdt.internal.compiler.ast.ProvidesStatement;
/*     */ import org.eclipse.jdt.internal.compiler.ast.RequiresStatement;
/*     */ import org.eclipse.jdt.internal.compiler.ast.TypeReference;
/*     */ import org.eclipse.jdt.internal.compiler.ast.UsesStatement;
/*     */ import org.eclipse.jdt.internal.compiler.env.ICompilationUnit;
/*     */ import org.eclipse.jdt.internal.compiler.env.IModule;
/*     */ import org.eclipse.jdt.internal.compiler.env.IModulePathEntry;
/*     */ import org.eclipse.jdt.internal.compiler.env.ISourceModule;
/*     */ import org.eclipse.jdt.internal.compiler.env.ModuleReferenceImpl;
/*     */ import org.eclipse.jdt.internal.compiler.env.PackageExportImpl;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BasicModule
/*     */   implements ISourceModule
/*     */ {
/*     */   static class Service
/*     */     implements IModule.IService
/*     */   {
/*     */     char[] provides;
/*     */     char[][] with;
/*     */     
/*     */     public char[] name() {
/*  45 */       return this.provides;
/*     */     }
/*     */ 
/*     */     
/*     */     public char[][] with() {
/*  50 */       return this.with;
/*     */     }
/*     */     
/*     */     public String toString() {
/*  54 */       StringBuilder buffer = new StringBuilder();
/*  55 */       buffer.append("provides");
/*  56 */       buffer.append(this.provides);
/*  57 */       buffer.append(" with ");
/*  58 */       buffer.append(this.with);
/*  59 */       buffer.append(';');
/*  60 */       return buffer.toString();
/*     */     } }
/*     */   
/*     */   private static PackageExportImpl createPackageExport(ExportsStatement[] refs, int i) {
/*  64 */     ExportsStatement ref = refs[i];
/*  65 */     PackageExportImpl exp = new PackageExportImpl();
/*  66 */     exp.pack = ref.pkgName;
/*  67 */     ModuleReference[] imp = ref.targets;
/*  68 */     if (imp != null) {
/*  69 */       exp.exportedTo = new char[imp.length][];
/*  70 */       for (int j = 0; j < imp.length; j++) {
/*  71 */         exp.exportedTo = (imp[j]).tokens;
/*     */       }
/*     */     } 
/*  74 */     return exp;
/*     */   }
/*     */   private static Service createService(TypeReference service, TypeReference[] with) {
/*  77 */     Service ser = new Service();
/*  78 */     ser.provides = CharOperation.concatWith(service.getTypeName(), '.');
/*  79 */     ser.with = new char[with.length][];
/*  80 */     for (int i = 0; i < with.length; i++) {
/*  81 */       ser.with[i] = CharOperation.concatWith(with[i].getTypeName(), '.');
/*     */     }
/*  83 */     return ser;
/*     */   }
/*     */   private static PackageExportImpl createPackageOpen(OpensStatement ref) {
/*  86 */     PackageExportImpl exp = new PackageExportImpl();
/*  87 */     exp.pack = ref.pkgName;
/*  88 */     ModuleReference[] imp = ref.targets;
/*  89 */     if (imp != null) {
/*  90 */       exp.exportedTo = new char[imp.length][];
/*  91 */       for (int j = 0; j < imp.length; j++) {
/*  92 */         exp.exportedTo = (imp[j]).tokens;
/*     */       }
/*     */     } 
/*  95 */     return exp;
/*     */   }
/*     */   
/*     */   private boolean isOpen = false;
/*     */   char[] name;
/*     */   IModule.IModuleReference[] requires;
/*     */   IModule.IPackageExport[] exports;
/*     */   char[][] uses;
/*     */   Service[] provides;
/*     */   IModule.IPackageExport[] opens;
/*     */   private ICompilationUnit compilationUnit;
/*     */   
/*     */   public BasicModule(ModuleDeclaration descriptor, IModulePathEntry root) {
/* 108 */     this.compilationUnit = (descriptor.compilationResult()).compilationUnit;
/* 109 */     this.name = descriptor.moduleName;
/* 110 */     if (descriptor.requiresCount > 0) {
/* 111 */       RequiresStatement[] refs = descriptor.requires;
/* 112 */       this.requires = (IModule.IModuleReference[])new ModuleReferenceImpl[refs.length];
/* 113 */       for (int i = 0; i < refs.length; i++) {
/* 114 */         ModuleReferenceImpl ref = new ModuleReferenceImpl();
/* 115 */         ref.name = CharOperation.concatWith((refs[i]).module.tokens, '.');
/* 116 */         ref.modifiers = (refs[i]).modifiers;
/* 117 */         this.requires[i] = (IModule.IModuleReference)ref;
/*     */       } 
/*     */     } else {
/* 120 */       this.requires = (IModule.IModuleReference[])new ModuleReferenceImpl[0];
/*     */     } 
/* 122 */     if (descriptor.exportsCount > 0) {
/* 123 */       ExportsStatement[] refs = descriptor.exports;
/* 124 */       this.exports = (IModule.IPackageExport[])new PackageExportImpl[refs.length];
/* 125 */       for (int i = 0; i < refs.length; i++) {
/* 126 */         PackageExportImpl exp = createPackageExport(refs, i);
/* 127 */         this.exports[i] = (IModule.IPackageExport)exp;
/*     */       } 
/*     */     } else {
/* 130 */       this.exports = (IModule.IPackageExport[])new PackageExportImpl[0];
/*     */     } 
/* 132 */     if (descriptor.usesCount > 0) {
/* 133 */       UsesStatement[] u = descriptor.uses;
/* 134 */       this.uses = new char[u.length][];
/* 135 */       for (int i = 0; i < u.length; i++) {
/* 136 */         this.uses[i] = CharOperation.concatWith((u[i]).serviceInterface.getTypeName(), '.');
/*     */       }
/*     */     } 
/* 139 */     if (descriptor.servicesCount > 0) {
/* 140 */       ProvidesStatement[] services = descriptor.services;
/* 141 */       this.provides = new Service[descriptor.servicesCount];
/* 142 */       for (int i = 0; i < descriptor.servicesCount; i++) {
/* 143 */         this.provides[i] = createService((services[i]).serviceInterface, (services[i]).implementations);
/*     */       }
/*     */     } 
/* 146 */     if (descriptor.opensCount > 0) {
/* 147 */       OpensStatement[] refs = descriptor.opens;
/* 148 */       this.opens = (IModule.IPackageExport[])new PackageExportImpl[refs.length];
/* 149 */       for (int i = 0; i < refs.length; i++) {
/* 150 */         PackageExportImpl exp = createPackageOpen(refs[i]);
/* 151 */         this.opens[i] = (IModule.IPackageExport)exp;
/*     */       } 
/*     */     } else {
/* 154 */       this.opens = (IModule.IPackageExport[])new PackageExportImpl[0];
/*     */     } 
/* 156 */     this.isOpen = descriptor.isOpen();
/*     */   }
/*     */   
/*     */   public ICompilationUnit getCompilationUnit() {
/* 160 */     return this.compilationUnit;
/*     */   }
/*     */   
/*     */   public char[] name() {
/* 164 */     return this.name;
/*     */   }
/*     */   
/*     */   public IModule.IModuleReference[] requires() {
/* 168 */     return this.requires;
/*     */   }
/*     */   
/*     */   public IModule.IPackageExport[] exports() {
/* 172 */     return this.exports;
/*     */   }
/*     */   
/*     */   public char[][] uses() {
/* 176 */     return this.uses;
/*     */   }
/*     */   
/*     */   public IModule.IService[] provides() {
/* 180 */     return (IModule.IService[])this.provides;
/*     */   }
/*     */   
/*     */   public IModule.IPackageExport[] opens() {
/* 184 */     return this.opens;
/*     */   }
/*     */   
/*     */   public boolean isOpen() {
/* 188 */     return this.isOpen;
/*     */   }
/*     */   
/*     */   public boolean equals(Object o) {
/* 192 */     if (this == o)
/* 193 */       return true; 
/* 194 */     if (!(o instanceof IModule))
/* 195 */       return false; 
/* 196 */     IModule mod = (IModule)o;
/* 197 */     if (!CharOperation.equals(this.name, mod.name()))
/* 198 */       return false; 
/* 199 */     return Arrays.equals((Object[])this.requires, (Object[])mod.requires());
/*     */   }
/*     */   
/*     */   public int hashCode() {
/* 203 */     int result = 17;
/* 204 */     int c = CharOperation.hashCode(this.name);
/* 205 */     result = 31 * result + c;
/* 206 */     c = Arrays.hashCode((Object[])this.requires);
/* 207 */     result = 31 * result + c;
/* 208 */     return result;
/*     */   }
/*     */   
/*     */   public String toString() {
/* 212 */     StringBuffer buffer = new StringBuffer(getClass().getName());
/* 213 */     toStringContent(buffer);
/* 214 */     return buffer.toString();
/*     */   }
/*     */   protected void toStringContent(StringBuffer buffer) {
/* 217 */     buffer.append("\nmodule ");
/* 218 */     buffer.append(this.name).append(' ');
/* 219 */     buffer.append('{').append('\n');
/* 220 */     if (this.requires != null) {
/* 221 */       for (int i = 0; i < this.requires.length; i++) {
/* 222 */         buffer.append("\trequires ");
/* 223 */         if (this.requires[i].isTransitive()) {
/* 224 */           buffer.append(" public ");
/*     */         }
/* 226 */         buffer.append(this.requires[i].name());
/* 227 */         buffer.append(';').append('\n');
/*     */       } 
/*     */     }
/* 230 */     if (this.exports != null) {
/* 231 */       buffer.append('\n');
/* 232 */       for (int i = 0; i < this.exports.length; i++) {
/* 233 */         buffer.append("\texports ");
/* 234 */         buffer.append(this.exports[i].toString());
/*     */       } 
/*     */     } 
/* 237 */     if (this.uses != null) {
/* 238 */       buffer.append('\n'); byte b; int i; char[][] arrayOfChar;
/* 239 */       for (i = (arrayOfChar = this.uses).length, b = 0; b < i; ) { char[] cs = arrayOfChar[b];
/* 240 */         buffer.append(cs);
/* 241 */         buffer.append(';').append('\n'); b++; }
/*     */     
/*     */     } 
/* 244 */     if (this.provides != null) {
/* 245 */       buffer.append('\n'); byte b; int i; Service[] arrayOfService;
/* 246 */       for (i = (arrayOfService = this.provides).length, b = 0; b < i; ) { Service ser = arrayOfService[b];
/* 247 */         buffer.append(ser.toString()); b++; }
/*     */     
/*     */     } 
/* 250 */     buffer.append('\n').append('}').toString();
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\batch\BasicModule.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */