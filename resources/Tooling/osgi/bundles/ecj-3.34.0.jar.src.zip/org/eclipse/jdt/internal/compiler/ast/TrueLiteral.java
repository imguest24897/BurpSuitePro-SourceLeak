/*    */ package org.eclipse.jdt.internal.compiler.ast;
/*    */ 
/*    */ import org.eclipse.jdt.internal.compiler.ASTVisitor;
/*    */ import org.eclipse.jdt.internal.compiler.codegen.BranchLabel;
/*    */ import org.eclipse.jdt.internal.compiler.codegen.CodeStream;
/*    */ import org.eclipse.jdt.internal.compiler.impl.BooleanConstant;
/*    */ import org.eclipse.jdt.internal.compiler.lookup.BlockScope;
/*    */ import org.eclipse.jdt.internal.compiler.lookup.TypeBinding;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TrueLiteral
/*    */   extends MagicLiteral
/*    */ {
/* 25 */   static final char[] source = new char[] { 't', 'r', 'u', 'e' };
/*    */   
/*    */   public TrueLiteral(int s, int e) {
/* 28 */     super(s, e);
/*    */   }
/*    */   
/*    */   public void computeConstant() {
/* 32 */     this.constant = BooleanConstant.fromValue(true);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void generateCode(BlockScope currentScope, CodeStream codeStream, boolean valueRequired) {
/* 43 */     int pc = codeStream.position;
/* 44 */     if (valueRequired) {
/* 45 */       codeStream.generateConstant(this.constant, this.implicitConversion);
/*    */     }
/* 47 */     codeStream.recordPositionsFrom(pc, this.sourceStart);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void generateOptimizedBoolean(BlockScope currentScope, CodeStream codeStream, BranchLabel trueLabel, BranchLabel falseLabel, boolean valueRequired) {
/* 54 */     int pc = codeStream.position;
/*    */     
/* 56 */     if (valueRequired && 
/* 57 */       falseLabel == null)
/*    */     {
/* 59 */       if (trueLabel != null) {
/* 60 */         codeStream.goto_(trueLabel);
/*    */       }
/*    */     }
/*    */     
/* 64 */     codeStream.recordPositionsFrom(pc, this.sourceStart);
/*    */   }
/*    */   
/*    */   public TypeBinding literalType(BlockScope scope) {
/* 68 */     return (TypeBinding)TypeBinding.BOOLEAN;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public char[] source() {
/* 75 */     return source;
/*    */   }
/*    */   
/*    */   public void traverse(ASTVisitor visitor, BlockScope scope) {
/* 79 */     visitor.visit(this, scope);
/* 80 */     visitor.endVisit(this, scope);
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\ast\TrueLiteral.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */