/*     */ package org.eclipse.jdt.internal.compiler.ast;
/*     */ 
/*     */ import org.eclipse.jdt.internal.compiler.ASTVisitor;
/*     */ import org.eclipse.jdt.internal.compiler.impl.CompilerOptions;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.BlockScope;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.ClassScope;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.ProblemReferenceBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.ReferenceBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.TypeBinding;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class QualifiedSuperReference
/*     */   extends QualifiedThisReference
/*     */ {
/*     */   public QualifiedSuperReference(TypeReference name, int pos, int sourceEnd) {
/*  33 */     super(name, pos, sourceEnd);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isSuper() {
/*  38 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isQualifiedSuper() {
/*  43 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isThis() {
/*  48 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public StringBuffer printExpression(int indent, StringBuffer output) {
/*  53 */     return this.qualification.print(0, output).append(".super");
/*     */   }
/*     */ 
/*     */   
/*     */   public TypeBinding resolveType(BlockScope scope) {
/*  58 */     if ((this.bits & 0x1FE00000) != 0) {
/*  59 */       scope.problemReporter().invalidParenthesizedExpression(this);
/*  60 */       return null;
/*     */     } 
/*  62 */     super.resolveType(scope);
/*  63 */     if (this.resolvedType != null && !this.resolvedType.isValidBinding()) {
/*  64 */       scope.problemReporter().illegalSuperAccess(this.qualification.resolvedType, this.resolvedType, this);
/*  65 */       return null;
/*     */     } 
/*  67 */     if (this.currentCompatibleType == null) {
/*  68 */       return null;
/*     */     }
/*  70 */     if (this.currentCompatibleType.id == 1) {
/*  71 */       scope.problemReporter().cannotUseSuperInJavaLangObject(this);
/*  72 */       return null;
/*     */     } 
/*  74 */     return this.resolvedType = this.currentCompatibleType.isInterface() ? 
/*  75 */       (TypeBinding)this.currentCompatibleType : 
/*  76 */       (TypeBinding)this.currentCompatibleType.superclass();
/*     */   }
/*     */ 
/*     */   
/*     */   int findCompatibleEnclosing(ReferenceBinding enclosingType, TypeBinding type, BlockScope scope) {
/*  81 */     if (type.isInterface()) {
/*     */       
/*  83 */       CompilerOptions compilerOptions = scope.compilerOptions();
/*  84 */       ReferenceBinding[] supers = enclosingType.superInterfaces();
/*  85 */       int length = supers.length;
/*  86 */       boolean isJava8 = (compilerOptions.complianceLevel >= 3407872L);
/*  87 */       boolean isLegal = true;
/*  88 */       char[][] compoundName = null;
/*  89 */       ReferenceBinding closestMatch = null;
/*  90 */       for (int i = 0; i < length; i++) {
/*  91 */         if (TypeBinding.equalsEquals(supers[i].erasure(), type)) {
/*  92 */           this.currentCompatibleType = closestMatch = supers[i];
/*  93 */         } else if (supers[i].erasure().isCompatibleWith(type)) {
/*  94 */           isLegal = false;
/*  95 */           compoundName = (supers[i]).compoundName;
/*  96 */           if (closestMatch == null) {
/*  97 */             closestMatch = supers[i];
/*     */           }
/*     */         } 
/*     */       } 
/* 101 */       if (!isLegal || !isJava8) {
/* 102 */         this.currentCompatibleType = null;
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 107 */         this.resolvedType = (TypeBinding)new ProblemReferenceBinding(compoundName, 
/* 108 */             closestMatch, isJava8 ? 21 : 29);
/*     */       } 
/* 110 */       return 0;
/*     */     } 
/* 112 */     return super.findCompatibleEnclosing(enclosingType, type, scope);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void traverse(ASTVisitor visitor, BlockScope blockScope) {
/* 120 */     if (visitor.visit(this, blockScope)) {
/* 121 */       this.qualification.traverse(visitor, blockScope);
/*     */     }
/* 123 */     visitor.endVisit(this, blockScope);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void traverse(ASTVisitor visitor, ClassScope blockScope) {
/* 130 */     if (visitor.visit(this, blockScope)) {
/* 131 */       this.qualification.traverse(visitor, blockScope);
/*     */     }
/* 133 */     visitor.endVisit(this, blockScope);
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\ast\QualifiedSuperReference.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */