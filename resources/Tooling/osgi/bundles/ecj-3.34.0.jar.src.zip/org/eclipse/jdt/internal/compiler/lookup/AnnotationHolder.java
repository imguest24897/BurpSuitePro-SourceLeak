/*    */ package org.eclipse.jdt.internal.compiler.lookup;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AnnotationHolder
/*    */ {
/*    */   AnnotationBinding[] annotations;
/*    */   
/*    */   static AnnotationHolder storeAnnotations(AnnotationBinding[] annotations, AnnotationBinding[][] parameterAnnotations, Object defaultValue, LookupEnvironment optionalEnv) {
/* 20 */     if (parameterAnnotations != null) {
/* 21 */       boolean isEmpty = true;
/* 22 */       for (int i = parameterAnnotations.length; isEmpty && --i >= 0;) {
/* 23 */         if (parameterAnnotations[i] != null && (parameterAnnotations[i]).length > 0)
/* 24 */           isEmpty = false; 
/* 25 */       }  if (isEmpty) {
/* 26 */         parameterAnnotations = null;
/*    */       }
/*    */     } 
/* 29 */     if (defaultValue != null)
/* 30 */       return new AnnotationMethodHolder(annotations, parameterAnnotations, defaultValue, optionalEnv); 
/* 31 */     if (parameterAnnotations != null)
/* 32 */       return new MethodHolder(annotations, parameterAnnotations); 
/* 33 */     return (new AnnotationHolder()).setAnnotations(annotations);
/*    */   }
/*    */   
/*    */   AnnotationBinding[] getAnnotations() {
/* 37 */     return this.annotations;
/*    */   }
/*    */   Object getDefaultValue() {
/* 40 */     return null;
/*    */   }
/*    */   public AnnotationBinding[][] getParameterAnnotations() {
/* 43 */     return null;
/*    */   }
/*    */   AnnotationBinding[] getParameterAnnotations(int paramIndex) {
/* 46 */     return Binding.NO_ANNOTATIONS;
/*    */   }
/*    */   AnnotationHolder setAnnotations(AnnotationBinding[] annotations) {
/* 49 */     this.annotations = annotations;
/* 50 */     if (annotations == null || annotations.length == 0)
/* 51 */       return null; 
/* 52 */     return this;
/*    */   }
/*    */   
/*    */   static class MethodHolder
/*    */     extends AnnotationHolder {
/*    */     AnnotationBinding[][] parameterAnnotations;
/*    */     
/*    */     MethodHolder(AnnotationBinding[] annotations, AnnotationBinding[][] parameterAnnotations) {
/* 60 */       setAnnotations(annotations);
/* 61 */       this.parameterAnnotations = parameterAnnotations;
/*    */     }
/*    */     
/*    */     public AnnotationBinding[][] getParameterAnnotations() {
/* 65 */       return this.parameterAnnotations;
/*    */     }
/*    */     
/*    */     AnnotationBinding[] getParameterAnnotations(int paramIndex) {
/* 69 */       AnnotationBinding[] result = (this.parameterAnnotations == null) ? null : this.parameterAnnotations[paramIndex];
/* 70 */       return (result == null) ? Binding.NO_ANNOTATIONS : result;
/*    */     }
/*    */     
/*    */     AnnotationHolder setAnnotations(AnnotationBinding[] annotations) {
/* 74 */       this.annotations = (annotations == null || annotations.length == 0) ? Binding.NO_ANNOTATIONS : annotations;
/* 75 */       return this;
/*    */     }
/*    */   }
/*    */   
/*    */   static class AnnotationMethodHolder extends MethodHolder {
/*    */     Object defaultValue;
/*    */     LookupEnvironment env;
/*    */     
/*    */     AnnotationMethodHolder(AnnotationBinding[] annotations, AnnotationBinding[][] parameterAnnotations, Object defaultValue, LookupEnvironment optionalEnv) {
/* 84 */       super(annotations, parameterAnnotations);
/* 85 */       this.defaultValue = defaultValue;
/* 86 */       this.env = optionalEnv;
/*    */     }
/*    */     
/*    */     Object getDefaultValue() {
/* 90 */       if (this.defaultValue instanceof UnresolvedReferenceBinding) {
/* 91 */         if (this.env == null)
/* 92 */           throw new IllegalStateException(); 
/* 93 */         this.defaultValue = ((UnresolvedReferenceBinding)this.defaultValue).resolve(this.env, false);
/*    */       } 
/* 95 */       return this.defaultValue;
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\lookup\AnnotationHolder.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */