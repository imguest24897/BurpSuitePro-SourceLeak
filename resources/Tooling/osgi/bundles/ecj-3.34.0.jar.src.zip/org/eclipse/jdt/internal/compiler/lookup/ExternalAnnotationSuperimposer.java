/*     */ package org.eclipse.jdt.internal.compiler.lookup;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.FileNotFoundException;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.util.zip.ZipEntry;
/*     */ import java.util.zip.ZipFile;
/*     */ import org.eclipse.jdt.internal.compiler.ast.Argument;
/*     */ import org.eclipse.jdt.internal.compiler.classfmt.ExternalAnnotationProvider;
/*     */ import org.eclipse.jdt.internal.compiler.env.IBinaryAnnotation;
/*     */ import org.eclipse.jdt.internal.compiler.env.ITypeAnnotationWalker;
/*     */ import org.eclipse.jdt.internal.compiler.util.Messages;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class ExternalAnnotationSuperimposer
/*     */   extends TypeBindingVisitor
/*     */ {
/*     */   private ITypeAnnotationWalker currentWalker;
/*     */   private TypeBinding typeReplacement;
/*     */   private LookupEnvironment environment;
/*     */   private boolean isReplacing;
/*     */   
/*     */   public static void apply(SourceTypeBinding typeBinding, String externalAnnotationPath) {
/*  37 */     ZipFile zipFile = null;
/*     */     try {
/*  39 */       File annotationBase = new File(externalAnnotationPath);
/*  40 */       if (annotationBase.exists()) {
/*  41 */         InputStream input; String binaryTypeName = String.valueOf(typeBinding.constantPoolName());
/*  42 */         String relativeFileName = String.valueOf(binaryTypeName.replace('.', '/')) + ".eea";
/*     */ 
/*     */         
/*  45 */         if (annotationBase.isDirectory()) {
/*  46 */           input = new FileInputStream(String.valueOf(externalAnnotationPath) + '/' + relativeFileName);
/*     */         } else {
/*  48 */           zipFile = new ZipFile(externalAnnotationPath);
/*  49 */           ZipEntry zipEntry = zipFile.getEntry(relativeFileName);
/*  50 */           if (zipEntry == null)
/*     */             return; 
/*  52 */           input = zipFile.getInputStream(zipEntry);
/*     */         } 
/*  54 */         annotateType(typeBinding, new ExternalAnnotationProvider(input, binaryTypeName), typeBinding.environment);
/*     */       } 
/*  56 */     } catch (FileNotFoundException fileNotFoundException) {
/*     */     
/*  58 */     } catch (IOException e) {
/*  59 */       typeBinding.scope.problemReporter().abortDueToInternalError(Messages.bind(Messages.abort_externaAnnotationFile, 
/*  60 */             (Object[])new String[] { String.valueOf(typeBinding.readableName()), externalAnnotationPath, e.getMessage() }));
/*     */     } finally {
/*  62 */       if (zipFile != null) {
/*     */         try {
/*  64 */           zipFile.close();
/*  65 */         } catch (IOException iOException) {}
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   static void annotateType(SourceTypeBinding binding, ExternalAnnotationProvider provider, LookupEnvironment environment) {
/*  72 */     ITypeAnnotationWalker typeWalker = provider.forTypeHeader(environment);
/*  73 */     if (typeWalker != null && typeWalker != ITypeAnnotationWalker.EMPTY_ANNOTATION_WALKER) {
/*  74 */       ExternalAnnotationSuperimposer visitor = new ExternalAnnotationSuperimposer(environment);
/*  75 */       TypeVariableBinding[] typeParameters = binding.typeVariables();
/*  76 */       for (int i = 0; i < typeParameters.length; i++) {
/*  77 */         if (visitor.go(typeWalker.toTypeParameter(true, i)))
/*  78 */           typeParameters[i] = visitor.<TypeVariableBinding>superimpose(typeParameters[i], TypeVariableBinding.class); 
/*     */       } 
/*     */     } 
/*  81 */     binding.externalAnnotationProvider = provider;
/*     */   }
/*     */   
/*     */   public static void annotateComponentBinding(RecordComponentBinding componentBinding, ExternalAnnotationProvider provider, LookupEnvironment environment) {
/*  85 */     char[] componentSignature = componentBinding.genericSignature();
/*  86 */     if (componentSignature == null && componentBinding.type != null) {
/*  87 */       componentSignature = componentBinding.type.signature();
/*     */     }
/*  89 */     ITypeAnnotationWalker walker = provider.forField(componentBinding.name, componentSignature, environment);
/*  90 */     ExternalAnnotationSuperimposer visitor = new ExternalAnnotationSuperimposer(environment);
/*  91 */     if (visitor.go(walker))
/*  92 */       componentBinding.type = visitor.superimpose(componentBinding.type, TypeBinding.class); 
/*     */   }
/*     */   
/*     */   public static void annotateFieldBinding(FieldBinding field, ExternalAnnotationProvider provider, LookupEnvironment environment) {
/*  96 */     char[] fieldSignature = field.genericSignature();
/*  97 */     if (fieldSignature == null && field.type != null)
/*  98 */       fieldSignature = field.type.signature(); 
/*  99 */     ITypeAnnotationWalker walker = provider.forField(field.name, fieldSignature, environment);
/* 100 */     ExternalAnnotationSuperimposer visitor = new ExternalAnnotationSuperimposer(environment);
/* 101 */     if (visitor.go(walker))
/* 102 */       field.type = visitor.superimpose(field.type, TypeBinding.class); 
/*     */   }
/*     */   
/*     */   public static void annotateMethodBinding(MethodBinding method, Argument[] arguments, ExternalAnnotationProvider provider, LookupEnvironment environment) {
/* 106 */     char[] methodSignature = method.genericSignature();
/* 107 */     if (methodSignature == null)
/* 108 */       methodSignature = method.signature(); 
/* 109 */     ITypeAnnotationWalker walker = provider.forMethod(method.selector, methodSignature, environment);
/* 110 */     if (walker != null && walker != ITypeAnnotationWalker.EMPTY_ANNOTATION_WALKER) {
/* 111 */       ExternalAnnotationSuperimposer visitor = new ExternalAnnotationSuperimposer(environment);
/* 112 */       TypeVariableBinding[] typeParams = method.typeVariables;
/* 113 */       for (short i = 0; i < typeParams.length; i = (short)(i + 1)) {
/* 114 */         if (visitor.go(walker.toTypeParameter(false, i)))
/* 115 */           typeParams[i] = visitor.<TypeVariableBinding>superimpose(typeParams[i], TypeVariableBinding.class); 
/*     */       } 
/* 117 */       if (!method.isConstructor() && 
/* 118 */         visitor.go(walker.toMethodReturn())) {
/* 119 */         method.returnType = visitor.superimpose(method.returnType, TypeBinding.class);
/*     */       }
/* 121 */       TypeBinding[] parameters = method.parameters;
/* 122 */       for (short s1 = 0; s1 < parameters.length; s1 = (short)(s1 + 1)) {
/* 123 */         if (visitor.go(walker.toMethodParameter(s1))) {
/* 124 */           parameters[s1] = visitor.superimpose(parameters[s1], TypeBinding.class);
/* 125 */           if (arguments != null && s1 < arguments.length) {
/* 126 */             (arguments[s1]).binding.type = parameters[s1];
/*     */           }
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   ExternalAnnotationSuperimposer(LookupEnvironment environment) {
/* 138 */     this.environment = environment;
/*     */   }
/*     */ 
/*     */   
/*     */   private ExternalAnnotationSuperimposer(TypeBinding typeReplacement, boolean isReplacing, ITypeAnnotationWalker walker) {
/* 143 */     this.typeReplacement = typeReplacement;
/* 144 */     this.isReplacing = isReplacing;
/* 145 */     this.currentWalker = walker;
/*     */   }
/*     */   private ExternalAnnotationSuperimposer snapshot() {
/* 148 */     ExternalAnnotationSuperimposer memento = new ExternalAnnotationSuperimposer(this.typeReplacement, this.isReplacing, this.currentWalker);
/*     */     
/* 150 */     this.typeReplacement = null;
/* 151 */     this.isReplacing = false;
/* 152 */     return memento;
/*     */   }
/*     */   private void restore(ExternalAnnotationSuperimposer memento) {
/* 155 */     this.isReplacing = memento.isReplacing;
/* 156 */     this.currentWalker = memento.currentWalker;
/*     */   }
/*     */ 
/*     */   
/*     */   boolean go(ITypeAnnotationWalker walker) {
/* 161 */     reset();
/* 162 */     this.typeReplacement = null;
/* 163 */     this.isReplacing = false;
/*     */     
/* 165 */     this.currentWalker = walker;
/* 166 */     return (walker != ITypeAnnotationWalker.EMPTY_ANNOTATION_WALKER);
/*     */   }
/*     */   
/*     */   <T extends TypeBinding> T superimpose(T type, Class<? extends T> cl) {
/* 170 */     TypeBindingVisitor.visit(this, (TypeBinding)type);
/* 171 */     if (cl.isInstance(this.typeReplacement))
/* 172 */       return cl.cast(this.typeReplacement); 
/* 173 */     return type;
/*     */   }
/*     */ 
/*     */   
/*     */   private TypeBinding goAndSuperimpose(ITypeAnnotationWalker walker, TypeBinding type) {
/* 178 */     if (walker == ITypeAnnotationWalker.EMPTY_ANNOTATION_WALKER)
/* 179 */       return type; 
/* 180 */     this.currentWalker = walker;
/*     */     
/* 182 */     TypeBindingVisitor.visit(this, type);
/*     */     
/* 184 */     if (this.typeReplacement == null)
/* 185 */       return type; 
/* 186 */     this.isReplacing = true;
/* 187 */     TypeBinding answer = this.typeReplacement;
/* 188 */     this.typeReplacement = null;
/* 189 */     return answer;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean visit(ArrayBinding arrayBinding) {
/* 194 */     ExternalAnnotationSuperimposer memento = snapshot();
/*     */     try {
/* 196 */       int dims = arrayBinding.dimensions;
/* 197 */       AnnotationBinding[][] annotsOnDims = new AnnotationBinding[dims][];
/* 198 */       ITypeAnnotationWalker walker = this.currentWalker;
/* 199 */       for (int i = 0; i < dims; i++) {
/* 200 */         IBinaryAnnotation[] binaryAnnotations = walker.getAnnotationsAtCursor(arrayBinding.id, false);
/* 201 */         if (binaryAnnotations != ITypeAnnotationWalker.NO_ANNOTATIONS) {
/* 202 */           annotsOnDims[i] = BinaryTypeBinding.createAnnotations(binaryAnnotations, this.environment, null);
/* 203 */           this.isReplacing = true;
/*     */         } else {
/* 205 */           annotsOnDims[i] = Binding.NO_ANNOTATIONS;
/*     */         } 
/* 207 */         walker = walker.toNextArrayDimension();
/*     */       } 
/* 209 */       TypeBinding leafComponentType = goAndSuperimpose(walker, arrayBinding.leafComponentType());
/* 210 */       if (this.isReplacing) {
/* 211 */         this.typeReplacement = this.environment.createArrayType(leafComponentType, dims, AnnotatableTypeSystem.flattenedAnnotations(annotsOnDims));
/*     */       }
/*     */     } finally {
/* 214 */       restore(memento);
/*     */     } 
/* 216 */     return false;
/*     */   }
/*     */   
/*     */   public boolean visit(BaseTypeBinding baseTypeBinding) {
/* 220 */     return false;
/*     */   }
/*     */   
/*     */   public boolean visit(IntersectionTypeBinding18 intersectionTypeBinding18) {
/* 224 */     return false;
/*     */   }
/*     */   
/*     */   public boolean visit(ParameterizedTypeBinding parameterizedTypeBinding) {
/* 228 */     ExternalAnnotationSuperimposer memento = snapshot();
/*     */     try {
/* 230 */       IBinaryAnnotation[] binaryAnnotations = this.currentWalker.getAnnotationsAtCursor(parameterizedTypeBinding.id, false);
/* 231 */       AnnotationBinding[] annotations = Binding.NO_ANNOTATIONS;
/* 232 */       if (binaryAnnotations != ITypeAnnotationWalker.NO_ANNOTATIONS) {
/* 233 */         annotations = BinaryTypeBinding.createAnnotations(binaryAnnotations, this.environment, null);
/* 234 */         this.isReplacing = true;
/*     */       } 
/*     */       
/* 237 */       TypeBinding[] typeArguments = parameterizedTypeBinding.typeArguments();
/* 238 */       TypeBinding[] newArguments = new TypeBinding[typeArguments.length];
/* 239 */       for (int i = 0; i < typeArguments.length; i++) {
/* 240 */         newArguments[i] = goAndSuperimpose(memento.currentWalker.toTypeArgument(i), typeArguments[i]);
/*     */       }
/* 242 */       if (this.isReplacing)
/* 243 */         this.typeReplacement = this.environment.createParameterizedType(parameterizedTypeBinding.genericType(), newArguments, parameterizedTypeBinding.enclosingType(), annotations); 
/* 244 */       return false;
/*     */     } finally {
/* 246 */       restore(memento);
/*     */     } 
/*     */   }
/*     */   
/*     */   public boolean visit(RawTypeBinding rawTypeBinding) {
/* 251 */     return visit(rawTypeBinding);
/*     */   }
/*     */   
/*     */   public boolean visit(ReferenceBinding referenceBinding) {
/* 255 */     IBinaryAnnotation[] binaryAnnotations = this.currentWalker.getAnnotationsAtCursor(referenceBinding.id, false);
/* 256 */     if (binaryAnnotations != ITypeAnnotationWalker.NO_ANNOTATIONS)
/* 257 */       this.typeReplacement = this.environment.createAnnotatedType(referenceBinding, BinaryTypeBinding.createAnnotations(binaryAnnotations, this.environment, null)); 
/* 258 */     return false;
/*     */   }
/*     */   
/*     */   public boolean visit(TypeVariableBinding typeVariable) {
/* 262 */     return visit(typeVariable);
/*     */   }
/*     */   
/*     */   public boolean visit(WildcardBinding wildcardBinding) {
/* 266 */     TypeBinding bound = wildcardBinding.bound;
/* 267 */     ExternalAnnotationSuperimposer memento = snapshot();
/*     */     try {
/* 269 */       if (bound != null) {
/* 270 */         bound = goAndSuperimpose(memento.currentWalker.toWildcardBound(), bound);
/*     */       }
/* 272 */       IBinaryAnnotation[] binaryAnnotations = memento.currentWalker.getAnnotationsAtCursor(-1, false);
/* 273 */       if (this.isReplacing || binaryAnnotations != ITypeAnnotationWalker.NO_ANNOTATIONS) {
/* 274 */         TypeBinding[] otherBounds = wildcardBinding.otherBounds;
/* 275 */         if (binaryAnnotations != ITypeAnnotationWalker.NO_ANNOTATIONS) {
/* 276 */           AnnotationBinding[] annotations = BinaryTypeBinding.createAnnotations(binaryAnnotations, this.environment, null);
/* 277 */           this.typeReplacement = this.environment.createWildcard(wildcardBinding.genericType, wildcardBinding.rank, bound, otherBounds, wildcardBinding.boundKind, annotations);
/*     */         } else {
/* 279 */           this.typeReplacement = this.environment.createWildcard(wildcardBinding.genericType, wildcardBinding.rank, bound, otherBounds, wildcardBinding.boundKind);
/*     */         } 
/*     */       } 
/*     */     } finally {
/* 283 */       restore(memento);
/*     */     } 
/* 285 */     return false;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\lookup\ExternalAnnotationSuperimposer.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */