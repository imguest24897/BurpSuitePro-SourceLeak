/*    */ package org.eclipse.jdt.internal.compiler.ast;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum ExpressionContext
/*    */ {
/* 20 */   ASSIGNMENT_CONTEXT
/*    */   {
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */     
/*    */     public String toString()
/*    */     {
/* 29 */       return "assignment context";
/*    */     }
/*    */     
/*    */     public boolean definesTargetType() {
/* 33 */       return true;
/*    */     }
/*    */   },
/*    */   
/* 37 */   INVOCATION_CONTEXT
/*    */   {
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */     
/*    */     public String toString()
/*    */     {
/* 47 */       return "invocation context";
/*    */     }
/*    */     
/*    */     public boolean definesTargetType() {
/* 51 */       return true;
/*    */     }
/*    */   },
/*    */   
/* 55 */   CASTING_CONTEXT
/*    */   {
/*    */ 
/*    */     
/*    */     public String toString()
/*    */     {
/* 61 */       return "casting context";
/*    */     }
/*    */     
/*    */     public boolean definesTargetType() {
/* 65 */       return false;
/*    */     }
/*    */   },
/*    */   
/* 69 */   VANILLA_CONTEXT
/*    */   {
/*    */ 
/*    */     
/*    */     public String toString()
/*    */     {
/* 75 */       return "vanilla context";
/*    */     }
/*    */     
/*    */     public boolean definesTargetType() {
/* 79 */       return false;
/*    */     }
/*    */   };
/*    */   
/*    */   public abstract boolean definesTargetType();
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\ast\ExpressionContext.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */