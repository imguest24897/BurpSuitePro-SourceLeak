/*     */ package org.eclipse.jdt.internal.compiler.batch;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.FilenameFilter;
/*     */ import java.io.IOException;
/*     */ import java.nio.file.FileSystems;
/*     */ import java.nio.file.FileVisitResult;
/*     */ import java.nio.file.Files;
/*     */ import java.nio.file.Path;
/*     */ import java.nio.file.SimpleFileVisitor;
/*     */ import java.nio.file.attribute.BasicFileAttributes;
/*     */ import java.util.HashSet;
/*     */ import java.util.Hashtable;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.function.Function;
/*     */ import java.util.stream.Stream;
/*     */ import org.eclipse.jdt.core.compiler.CharOperation;
/*     */ import org.eclipse.jdt.internal.compiler.CompilationResult;
/*     */ import org.eclipse.jdt.internal.compiler.DefaultErrorHandlingPolicies;
/*     */ import org.eclipse.jdt.internal.compiler.IProblemFactory;
/*     */ import org.eclipse.jdt.internal.compiler.ast.CompilationUnitDeclaration;
/*     */ import org.eclipse.jdt.internal.compiler.ast.TypeDeclaration;
/*     */ import org.eclipse.jdt.internal.compiler.classfmt.ClassFileReader;
/*     */ import org.eclipse.jdt.internal.compiler.env.AccessRuleSet;
/*     */ import org.eclipse.jdt.internal.compiler.env.IBinaryType;
/*     */ import org.eclipse.jdt.internal.compiler.env.IModule;
/*     */ import org.eclipse.jdt.internal.compiler.env.NameEnvironmentAnswer;
/*     */ import org.eclipse.jdt.internal.compiler.impl.CompilerOptions;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.TypeConstants;
/*     */ import org.eclipse.jdt.internal.compiler.parser.Parser;
/*     */ import org.eclipse.jdt.internal.compiler.parser.ScannerHelper;
/*     */ import org.eclipse.jdt.internal.compiler.problem.DefaultProblemFactory;
/*     */ import org.eclipse.jdt.internal.compiler.problem.ProblemReporter;
/*     */ import org.eclipse.jdt.internal.compiler.util.Util;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ClasspathDirectory
/*     */   extends ClasspathLocation
/*     */ {
/*     */   private Hashtable directoryCache;
/*  60 */   private String[] missingPackageHolder = new String[1];
/*     */   private int mode;
/*     */   private String encoding;
/*  63 */   private Hashtable<String, Hashtable<String, String>> packageSecondaryTypes = null;
/*     */   
/*     */   Map options;
/*     */   
/*     */   ClasspathDirectory(File directory, String encoding, int mode, AccessRuleSet accessRuleSet, String destinationPath, Map options) {
/*  68 */     super(accessRuleSet, destinationPath);
/*  69 */     this.mode = mode;
/*  70 */     this.options = options;
/*     */     try {
/*  72 */       this.path = directory.getCanonicalPath();
/*  73 */     } catch (IOException iOException) {
/*     */       
/*  75 */       this.path = directory.getAbsolutePath();
/*     */     } 
/*  77 */     if (!this.path.endsWith(File.separator))
/*  78 */       this.path = String.valueOf(this.path) + File.separator; 
/*  79 */     this.directoryCache = new Hashtable<>(11);
/*  80 */     this.encoding = encoding;
/*     */   }
/*     */   String[] directoryList(String qualifiedPackageName) {
/*  83 */     String[] dirList = (String[])this.directoryCache.get(qualifiedPackageName);
/*  84 */     if (dirList == this.missingPackageHolder) return null; 
/*  85 */     if (dirList != null) return dirList;
/*     */     
/*  87 */     File dir = new File(String.valueOf(this.path) + qualifiedPackageName);
/*  88 */     if (dir.isDirectory())
/*     */     
/*     */     { 
/*  91 */       int index = qualifiedPackageName.length();
/*  92 */       int last = qualifiedPackageName.lastIndexOf(File.separatorChar); do {  }
/*  93 */       while (--index > last && !ScannerHelper.isUpperCase(qualifiedPackageName.charAt(index)));
/*  94 */       if (index > last)
/*  95 */         if (last == -1)
/*  96 */         { if (!doesFileExist(qualifiedPackageName, Util.EMPTY_STRING))
/*     */           
/*     */           { 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */             
/* 110 */             this.directoryCache.put(qualifiedPackageName, this.missingPackageHolder);
/* 111 */             return null; }  } else { String packageName = qualifiedPackageName.substring(last + 1); String parentPackage = qualifiedPackageName.substring(0, last); if (!doesFileExist(packageName, parentPackage)) { this.directoryCache.put(qualifiedPackageName, this.missingPackageHolder); return null; }  }   if ((dirList = dir.list()) == null) dirList = CharOperation.NO_STRINGS;  this.directoryCache.put(qualifiedPackageName, dirList); return dirList; }  this.directoryCache.put(qualifiedPackageName, this.missingPackageHolder); return null;
/*     */   }
/*     */   boolean doesFileExist(String fileName, String qualifiedPackageName) {
/* 114 */     String[] dirList = directoryList(qualifiedPackageName);
/* 115 */     if (dirList == null) return false;
/*     */     
/* 117 */     for (int i = dirList.length; --i >= 0;) {
/* 118 */       if (fileName.equals(dirList[i]))
/* 119 */         return true; 
/* 120 */     }  return false;
/*     */   }
/*     */   
/*     */   public List fetchLinkedJars(FileSystem.ClasspathSectionProblemReporter problemReporter) {
/* 124 */     return null;
/*     */   }
/*     */   private NameEnvironmentAnswer findClassInternal(char[] typeName, String qualifiedPackageName, String qualifiedBinaryFileName, boolean asBinaryOnly) {
/* 127 */     if (!isPackage(qualifiedPackageName, null)) return null; 
/* 128 */     String fileName = new String(typeName);
/* 129 */     boolean binaryExists = ((this.mode & 0x2) != 0 && doesFileExist(String.valueOf(fileName) + ".class", qualifiedPackageName));
/* 130 */     boolean sourceExists = ((this.mode & 0x1) != 0 && doesFileExist(String.valueOf(fileName) + ".java", qualifiedPackageName));
/* 131 */     if (sourceExists && !asBinaryOnly) {
/* 132 */       String fullSourcePath = String.valueOf(this.path) + qualifiedBinaryFileName.substring(0, qualifiedBinaryFileName.length() - 6) + ".java";
/* 133 */       CompilationUnit unit = new CompilationUnit(null, fullSourcePath, this.encoding, this.destinationPath);
/* 134 */       unit.module = (this.module == null) ? null : this.module.name();
/* 135 */       if (!binaryExists)
/* 136 */         return new NameEnvironmentAnswer(unit, 
/* 137 */             fetchAccessRestriction(qualifiedBinaryFileName)); 
/* 138 */       String fullBinaryPath = String.valueOf(this.path) + qualifiedBinaryFileName;
/* 139 */       long binaryModified = (new File(fullBinaryPath)).lastModified();
/* 140 */       long sourceModified = (new File(fullSourcePath)).lastModified();
/* 141 */       if (sourceModified > binaryModified)
/* 142 */         return new NameEnvironmentAnswer(unit, 
/* 143 */             fetchAccessRestriction(qualifiedBinaryFileName)); 
/*     */     } 
/* 145 */     if (binaryExists) {
/*     */       try {
/* 147 */         ClassFileReader reader = ClassFileReader.read(String.valueOf(this.path) + qualifiedBinaryFileName);
/*     */         
/* 149 */         String typeSearched = (qualifiedPackageName.length() > 0) ? (
/* 150 */           String.valueOf(qualifiedPackageName.replace(File.separatorChar, '/')) + "/" + fileName) : 
/* 151 */           fileName;
/* 152 */         if (!CharOperation.equals(reader.getName(), typeSearched.toCharArray())) {
/* 153 */           reader = null;
/*     */         }
/* 155 */         if (reader != null) {
/* 156 */           char[] modName = (reader.moduleName != null) ? reader.moduleName : ((this.module != null) ? this.module.name() : null);
/* 157 */           return new NameEnvironmentAnswer(
/* 158 */               (IBinaryType)reader, 
/* 159 */               fetchAccessRestriction(qualifiedBinaryFileName), 
/* 160 */               modName);
/*     */         } 
/* 162 */       } catch (IOException|org.eclipse.jdt.internal.compiler.classfmt.ClassFormatException iOException) {}
/*     */     }
/*     */ 
/*     */     
/* 166 */     return null;
/*     */   }
/*     */   
/*     */   public NameEnvironmentAnswer findSecondaryInClass(char[] typeName, String qualifiedPackageName, String qualifiedBinaryFileName) {
/* 170 */     if (CharOperation.equals(TypeConstants.PACKAGE_INFO_NAME, typeName)) {
/* 171 */       return null;
/*     */     }
/*     */     
/* 174 */     String typeNameString = new String(typeName);
/* 175 */     String moduleName = (this.module != null) ? String.valueOf(this.module.name()) : null;
/* 176 */     boolean prereqs = (this.options != null && isPackage(qualifiedPackageName, moduleName) && (this.mode & 0x1) != 0 && doesFileExist(String.valueOf(typeNameString) + ".java", qualifiedPackageName));
/* 177 */     return prereqs ? null : findSourceSecondaryType(typeNameString, qualifiedPackageName, qualifiedBinaryFileName);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean hasAnnotationFileFor(String qualifiedTypeName) {
/* 182 */     int pos = qualifiedTypeName.lastIndexOf('/');
/* 183 */     if (pos != -1 && pos + 1 < qualifiedTypeName.length()) {
/* 184 */       String fileName = String.valueOf(qualifiedTypeName.substring(pos + 1)) + ".eea";
/* 185 */       return doesFileExist(fileName, qualifiedTypeName.substring(0, pos));
/*     */     } 
/* 187 */     return false;
/*     */   }
/*     */   
/*     */   public NameEnvironmentAnswer findClass(char[] typeName, String qualifiedPackageName, String moduleName, String qualifiedBinaryFileName) {
/* 191 */     return findClass(typeName, qualifiedPackageName, moduleName, qualifiedBinaryFileName, false);
/*     */   }
/*     */   
/*     */   public NameEnvironmentAnswer findClass(char[] typeName, String qualifiedPackageName, String moduleName, String qualifiedBinaryFileName, boolean asBinaryOnly) {
/* 195 */     if (File.separatorChar == '/') {
/* 196 */       return findClassInternal(typeName, qualifiedPackageName, qualifiedBinaryFileName, asBinaryOnly);
/*     */     }
/* 198 */     return findClassInternal(typeName, qualifiedPackageName.replace('/', File.separatorChar), 
/* 199 */         qualifiedBinaryFileName.replace('/', File.separatorChar), asBinaryOnly);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private Hashtable<String, String> getSecondaryTypes(String qualifiedPackageName) {
/* 205 */     Hashtable<String, String> packageEntry = new Hashtable<>();
/*     */     
/* 207 */     String[] dirList = (String[])this.directoryCache.get(qualifiedPackageName);
/* 208 */     if (dirList == this.missingPackageHolder || 
/* 209 */       dirList == null) {
/* 210 */       return packageEntry;
/*     */     }
/* 212 */     File dir = new File(String.valueOf(this.path) + qualifiedPackageName);
/* 213 */     File[] listFiles = dir.isDirectory() ? dir.listFiles() : null;
/* 214 */     if (listFiles == null) return packageEntry;
/*     */     
/* 216 */     for (int i = 0, l = listFiles.length; i < l; i++) {
/* 217 */       File f = listFiles[i];
/* 218 */       if (!f.isDirectory()) {
/* 219 */         String s = f.getAbsolutePath();
/* 220 */         if (s != null && (
/* 221 */           s.endsWith(".java") || s.endsWith(".JAVA"))) {
/* 222 */           CompilationUnit cu = new CompilationUnit(null, s, this.encoding, this.destinationPath);
/* 223 */           CompilationResult compilationResult = new CompilationResult(s.toCharArray(), 1, 1, 10);
/* 224 */           ProblemReporter problemReporter = 
/* 225 */             new ProblemReporter(
/* 226 */               DefaultErrorHandlingPolicies.proceedWithAllProblems(), 
/* 227 */               new CompilerOptions(this.options), 
/* 228 */               (IProblemFactory)new DefaultProblemFactory());
/* 229 */           Parser parser = new Parser(problemReporter, false);
/* 230 */           parser.reportSyntaxErrorIsRequired = false;
/*     */           
/* 232 */           CompilationUnitDeclaration unit = parser.parse(cu, compilationResult);
/* 233 */           TypeDeclaration[] types = (unit != null) ? unit.types : null;
/* 234 */           if (types != null)
/* 235 */             for (int j = 0, k = types.length; j < k; j++)
/* 236 */             { TypeDeclaration type = types[j];
/* 237 */               char[] name = type.isSecondary() ? type.name : null;
/* 238 */               if (name != null)
/* 239 */                 packageEntry.put(new String(name), s);  }  
/*     */         } 
/*     */       } 
/* 242 */     }  return packageEntry;
/*     */   }
/*     */   
/*     */   private NameEnvironmentAnswer findSourceSecondaryType(String typeName, String qualifiedPackageName, String qualifiedBinaryFileName) {
/* 246 */     if (this.packageSecondaryTypes == null) this.packageSecondaryTypes = new Hashtable<>(); 
/* 247 */     Hashtable<String, String> packageEntry = this.packageSecondaryTypes.get(qualifiedPackageName);
/* 248 */     if (packageEntry == null) {
/* 249 */       packageEntry = getSecondaryTypes(qualifiedPackageName);
/* 250 */       this.packageSecondaryTypes.put(qualifiedPackageName, packageEntry);
/*     */     } 
/* 252 */     String fileName = packageEntry.get(typeName);
/* 253 */     return (fileName != null) ? new NameEnvironmentAnswer(new CompilationUnit(null, 
/* 254 */           fileName, this.encoding, this.destinationPath), 
/* 255 */         fetchAccessRestriction(qualifiedBinaryFileName)) : null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public char[][][] findTypeNames(String qualifiedPackageName, String moduleName) {
/* 261 */     if (!isPackage(qualifiedPackageName, moduleName)) {
/* 262 */       return null;
/*     */     }
/* 264 */     File dir = new File(String.valueOf(this.path) + qualifiedPackageName);
/* 265 */     if (!dir.exists() || !dir.isDirectory()) {
/* 266 */       return null;
/*     */     }
/* 268 */     String[] listFiles = dir.list(new FilenameFilter()
/*     */         {
/*     */           public boolean accept(File directory1, String name) {
/* 271 */             String fileName = name.toLowerCase();
/* 272 */             return !(!fileName.endsWith(".class") && !fileName.endsWith(".java"));
/*     */           }
/*     */         });
/*     */     int length;
/* 276 */     if (listFiles == null || (length = listFiles.length) == 0) {
/* 277 */       return null;
/*     */     }
/* 279 */     Set<String> secondary = getSecondaryTypes(qualifiedPackageName).keySet();
/* 280 */     char[][][] result = new char[length + secondary.size()][][];
/* 281 */     char[][] packageName = CharOperation.splitOn(File.separatorChar, qualifiedPackageName.toCharArray());
/* 282 */     for (int i = 0; i < length; i++) {
/* 283 */       String fileName = listFiles[i];
/* 284 */       int indexOfLastDot = fileName.indexOf('.');
/* 285 */       String typeName = (indexOfLastDot > 0) ? fileName.substring(0, indexOfLastDot) : fileName;
/* 286 */       result[i] = CharOperation.arrayConcat(packageName, typeName.toCharArray());
/*     */     } 
/* 288 */     if (secondary.size() > 0) {
/* 289 */       int idx = length;
/* 290 */       for (String type : secondary) {
/* 291 */         result[idx++] = CharOperation.arrayConcat(packageName, type.toCharArray());
/*     */       }
/*     */     } 
/* 294 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   public void initialize() throws IOException {}
/*     */ 
/*     */   
/*     */   public char[][] getModulesDeclaringPackage(String qualifiedPackageName, String moduleName) {
/* 302 */     String qp2 = (File.separatorChar == '/') ? qualifiedPackageName : qualifiedPackageName.replace('/', File.separatorChar);
/* 303 */     return singletonModuleNameIf((directoryList(qp2) != null));
/*     */   }
/*     */   
/*     */   public boolean hasCompilationUnit(String qualifiedPackageName, String moduleName) {
/* 307 */     String qp2 = (File.separatorChar == '/') ? qualifiedPackageName : qualifiedPackageName.replace('/', File.separatorChar);
/* 308 */     String[] dirList = directoryList(qp2);
/* 309 */     if (dirList != null) {
/* 310 */       byte b; int i; String[] arrayOfString; for (i = (arrayOfString = dirList).length, b = 0; b < i; ) { String entry = arrayOfString[b];
/* 311 */         String entryLC = entry.toLowerCase();
/* 312 */         if (entryLC.endsWith(".java") || entryLC.endsWith(".class"))
/* 313 */           return true;  b++; }
/*     */     
/*     */     } 
/* 316 */     return false;
/*     */   }
/*     */   
/*     */   public boolean hasCUDeclaringPackage(String qualifiedPackageName, Function<CompilationUnit, String> pkgNameExtractor) {
/* 320 */     String qp2 = (File.separatorChar == '/') ? qualifiedPackageName : qualifiedPackageName.replace('/', File.separatorChar);
/* 321 */     String[] directoryList = directoryList(qp2);
/* 322 */     if (directoryList == null)
/* 323 */       return false; 
/* 324 */     return Stream.<String>of(directoryList).anyMatch(entry -> {
/*     */           String entryLC = entry.toLowerCase();
/*     */           boolean hasDeclaration = false;
/*     */           String fullPath = String.valueOf(this.path) + paramString1 + "/" + entry;
/*     */           String pkgName = null;
/*     */           if (entryLC.endsWith(".class")) {
/*     */             return true;
/*     */           }
/*     */           if (entryLC.endsWith(".java")) {
/*     */             CompilationUnit cu = new CompilationUnit(null, fullPath, this.encoding);
/*     */             pkgName = paramFunction.apply(cu);
/*     */           } 
/*     */           if (pkgName != null && pkgName.equals(paramString1.replace(File.separatorChar, '.')))
/*     */             hasDeclaration = true; 
/*     */           return hasDeclaration;
/*     */         });
/*     */   }
/*     */   
/*     */   public char[][] listPackages() {
/* 343 */     final Set<String> packageNames = new HashSet<>();
/*     */     try {
/* 345 */       final Path basePath = FileSystems.getDefault().getPath(this.path, new String[0]);
/* 346 */       Files.walkFileTree(basePath, new SimpleFileVisitor<Path>()
/*     */           {
/*     */             public FileVisitResult visitFile(Path file, BasicFileAttributes attrs) {
/* 349 */               if (file.toString().toLowerCase().endsWith(".class")) {
/* 350 */                 packageNames.add(file.getParent().relativize(basePath).toString().replace('/', '.'));
/*     */               }
/* 352 */               return FileVisitResult.CONTINUE;
/*     */             }
/*     */           });
/* 355 */     } catch (IOException iOException) {}
/*     */ 
/*     */     
/* 358 */     return (char[][])packageNames.stream().map(String::toCharArray).toArray(paramInt -> new char[paramInt][]);
/*     */   }
/*     */ 
/*     */   
/*     */   public void reset() {
/* 363 */     super.reset();
/* 364 */     this.directoryCache = new Hashtable<>(11);
/*     */   }
/*     */   
/*     */   public String toString() {
/* 368 */     return "ClasspathDirectory " + this.path;
/*     */   }
/*     */   
/*     */   public char[] normalizedPath() {
/* 372 */     if (this.normalizedPath == null) {
/* 373 */       this.normalizedPath = this.path.toCharArray();
/* 374 */       if (File.separatorChar == '\\') {
/* 375 */         CharOperation.replace(this.normalizedPath, '\\', '/');
/*     */       }
/*     */     } 
/* 378 */     return this.normalizedPath;
/*     */   }
/*     */   
/*     */   public String getPath() {
/* 382 */     return this.path;
/*     */   }
/*     */   
/*     */   public int getMode() {
/* 386 */     return this.mode;
/*     */   }
/*     */   
/*     */   public IModule getModule() {
/* 390 */     return this.module;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\batch\ClasspathDirectory.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */