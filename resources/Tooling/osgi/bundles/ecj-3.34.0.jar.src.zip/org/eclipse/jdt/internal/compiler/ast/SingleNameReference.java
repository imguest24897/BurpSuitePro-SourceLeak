/*      */ package org.eclipse.jdt.internal.compiler.ast;
/*      */ 
/*      */ import org.eclipse.jdt.core.compiler.CharOperation;
/*      */ import org.eclipse.jdt.internal.compiler.ASTVisitor;
/*      */ import org.eclipse.jdt.internal.compiler.codegen.CodeStream;
/*      */ import org.eclipse.jdt.internal.compiler.flow.FlowContext;
/*      */ import org.eclipse.jdt.internal.compiler.flow.FlowInfo;
/*      */ import org.eclipse.jdt.internal.compiler.flow.UnconditionalFlowInfo;
/*      */ import org.eclipse.jdt.internal.compiler.impl.CompilerOptions;
/*      */ import org.eclipse.jdt.internal.compiler.impl.Constant;
/*      */ import org.eclipse.jdt.internal.compiler.lookup.BaseTypeBinding;
/*      */ import org.eclipse.jdt.internal.compiler.lookup.Binding;
/*      */ import org.eclipse.jdt.internal.compiler.lookup.BlockScope;
/*      */ import org.eclipse.jdt.internal.compiler.lookup.ClassScope;
/*      */ import org.eclipse.jdt.internal.compiler.lookup.FieldBinding;
/*      */ import org.eclipse.jdt.internal.compiler.lookup.LocalVariableBinding;
/*      */ import org.eclipse.jdt.internal.compiler.lookup.MethodBinding;
/*      */ import org.eclipse.jdt.internal.compiler.lookup.MethodScope;
/*      */ import org.eclipse.jdt.internal.compiler.lookup.ProblemReferenceBinding;
/*      */ import org.eclipse.jdt.internal.compiler.lookup.ReferenceBinding;
/*      */ import org.eclipse.jdt.internal.compiler.lookup.Scope;
/*      */ import org.eclipse.jdt.internal.compiler.lookup.SourceTypeBinding;
/*      */ import org.eclipse.jdt.internal.compiler.lookup.TypeBinding;
/*      */ import org.eclipse.jdt.internal.compiler.lookup.VariableBinding;
/*      */ import org.eclipse.jdt.internal.compiler.problem.AbortMethod;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class SingleNameReference
/*      */   extends NameReference
/*      */   implements OperatorIds
/*      */ {
/*      */   public static final int READ = 0;
/*      */   public static final int WRITE = 1;
/*      */   public char[] token;
/*      */   public MethodBinding[] syntheticAccessors;
/*      */   public TypeBinding genericCast;
/*      */   public boolean isLabel;
/*      */   
/*      */   public SingleNameReference(char[] source, long pos) {
/*   70 */     this.token = source;
/*   71 */     this.sourceStart = (int)(pos >>> 32L);
/*   72 */     this.sourceEnd = (int)pos;
/*      */   } public FlowInfo analyseAssignment(BlockScope currentScope, FlowContext flowContext, FlowInfo flowInfo, Assignment assignment, boolean isCompound) {
/*      */     UnconditionalFlowInfo unconditionalFlowInfo;
/*      */     FieldBinding fieldBinding;
/*      */     LocalVariableBinding localBinding;
/*   77 */     boolean isFinal, isReachable = ((flowInfo.tagBits & 0x3) == 0);
/*      */     
/*   79 */     if (isCompound) {
/*   80 */       FieldBinding fieldBinding1; LocalVariableBinding localVariableBinding; switch (this.bits & 0x7) {
/*      */         case 1:
/*   82 */           fieldBinding1 = (FieldBinding)this.binding;
/*   83 */           if (fieldBinding1.isBlankFinal() && 
/*   84 */             currentScope.needBlankFinalFieldInitializationCheck(fieldBinding1)) {
/*   85 */             FlowInfo fieldInits = flowContext.getInitsForFinalBlankInitializationCheck(fieldBinding1.declaringClass.original(), flowInfo);
/*   86 */             if (!fieldInits.isDefinitelyAssigned(fieldBinding1)) {
/*   87 */               currentScope.problemReporter().uninitializedBlankFinalField(fieldBinding1, this);
/*      */             }
/*      */           } 
/*   90 */           manageSyntheticAccessIfNecessary(currentScope, flowInfo, true);
/*      */           break;
/*      */ 
/*      */         
/*      */         case 2:
/*   95 */           if (!flowInfo.isDefinitelyAssigned(localVariableBinding = (LocalVariableBinding)this.binding)) {
/*   96 */             currentScope.problemReporter().uninitializedLocalVariable(localVariableBinding, this, (Scope)currentScope);
/*      */           }
/*      */           
/*   99 */           if (localVariableBinding.useFlag != 1) {
/*      */ 
/*      */             
/*  102 */             if (isReachable && (this.implicitConversion & 0x400) != 0) {
/*  103 */               localVariableBinding.useFlag = 1;
/*      */               break;
/*      */             } 
/*  106 */             if (localVariableBinding.useFlag <= 0)
/*  107 */               localVariableBinding.useFlag--; 
/*      */           }  break;
/*      */       } 
/*  110 */     }  if (assignment
/*      */       
/*  112 */       .expression != null) {
/*  113 */       unconditionalFlowInfo = assignment.expression.analyseCode(currentScope, flowContext, flowInfo).unconditionalInits();
/*      */     }
/*  115 */     switch (this.bits & 0x7) {
/*      */       case 1:
/*  117 */         manageSyntheticAccessIfNecessary(currentScope, (FlowInfo)unconditionalFlowInfo, false);
/*      */ 
/*      */         
/*  120 */         fieldBinding = (FieldBinding)this.binding;
/*  121 */         if (fieldBinding.isFinal()) {
/*      */           
/*  123 */           if (!isCompound && fieldBinding.isBlankFinal() && currentScope.allowBlankFinalFieldAssignment(fieldBinding)) {
/*  124 */             if (unconditionalFlowInfo.isPotentiallyAssigned(fieldBinding)) {
/*  125 */               currentScope.problemReporter().duplicateInitializationOfBlankFinalField(fieldBinding, this);
/*      */             } else {
/*  127 */               flowContext.recordSettingFinal((VariableBinding)fieldBinding, this, (FlowInfo)unconditionalFlowInfo);
/*      */             } 
/*  129 */             unconditionalFlowInfo.markAsDefinitelyAssigned(fieldBinding); break;
/*      */           } 
/*  131 */           currentScope.problemReporter().cannotAssignToFinalField(fieldBinding, this); break;
/*      */         } 
/*  133 */         if (!isCompound && (fieldBinding.isNonNull() || fieldBinding.type.isTypeVariable()) && 
/*  134 */           TypeBinding.equalsEquals((TypeBinding)fieldBinding.declaringClass, (TypeBinding)currentScope.enclosingReceiverType()))
/*      */         {
/*  136 */           unconditionalFlowInfo.markAsDefinitelyAssigned(fieldBinding);
/*      */         }
/*      */         break;
/*      */       case 2:
/*  140 */         localBinding = (LocalVariableBinding)this.binding;
/*  141 */         isFinal = localBinding.isFinal();
/*  142 */         if (!unconditionalFlowInfo.isDefinitelyAssigned(localBinding)) {
/*  143 */           this.bits |= 0x8;
/*      */         } else {
/*  145 */           this.bits &= 0xFFFFFFF7;
/*      */         } 
/*  147 */         if (unconditionalFlowInfo.isPotentiallyAssigned(localBinding) || (this.bits & 0x80000) != 0) {
/*  148 */           localBinding.tagBits &= 0xFFFFFFFFFFFFF7FFL;
/*  149 */           if (!isFinal) {
/*  150 */             if ((this.bits & 0x80000) != 0) {
/*  151 */               currentScope.problemReporter().cannotReferToNonEffectivelyFinalOuterLocal((VariableBinding)localBinding, this);
/*  152 */             } else if ((this.bits & 0x40) != 0) {
/*  153 */               currentScope.problemReporter().cannotReferToNonFinalLocalInGuard((VariableBinding)localBinding, this);
/*      */             } 
/*      */           }
/*      */         } 
/*  157 */         if (!isFinal && (localBinding.tagBits & 0x800L) != 0L && (localBinding.tagBits & 0x400L) == 0L) {
/*  158 */           flowContext.recordSettingFinal((VariableBinding)localBinding, this, (FlowInfo)unconditionalFlowInfo);
/*  159 */         } else if (isFinal) {
/*  160 */           if ((this.bits & 0x1FE0) == 0) {
/*      */             
/*  162 */             if ((isReachable && isCompound) || !localBinding.isBlankFinal()) {
/*  163 */               currentScope.problemReporter().cannotAssignToFinalLocal(localBinding, this);
/*  164 */             } else if (unconditionalFlowInfo.isPotentiallyAssigned(localBinding)) {
/*  165 */               currentScope.problemReporter().duplicateInitializationOfFinalLocal(localBinding, this);
/*  166 */             } else if ((this.bits & 0x80000) != 0) {
/*  167 */               currentScope.problemReporter().cannotAssignToFinalOuterLocal(localBinding, this);
/*      */             } else {
/*  169 */               flowContext.recordSettingFinal((VariableBinding)localBinding, this, (FlowInfo)unconditionalFlowInfo);
/*      */             } 
/*      */           } else {
/*  172 */             currentScope.problemReporter().cannotAssignToFinalOuterLocal(localBinding, this);
/*      */           }
/*      */         
/*  175 */         } else if ((localBinding.tagBits & 0x400L) != 0L) {
/*  176 */           currentScope.problemReporter().parameterAssignment(localBinding, this);
/*      */         } 
/*  178 */         unconditionalFlowInfo.markAsDefinitelyAssigned(localBinding); break;
/*      */     } 
/*  180 */     manageEnclosingInstanceAccessIfNecessary(currentScope, (FlowInfo)unconditionalFlowInfo);
/*  181 */     return (FlowInfo)unconditionalFlowInfo;
/*      */   }
/*      */ 
/*      */   
/*      */   public FlowInfo analyseCode(BlockScope currentScope, FlowContext flowContext, FlowInfo flowInfo) {
/*  186 */     return analyseCode(currentScope, flowContext, flowInfo, true);
/*      */   }
/*      */   public FlowInfo analyseCode(BlockScope currentScope, FlowContext flowContext, FlowInfo flowInfo, boolean valueRequired) {
/*      */     FieldBinding fieldBinding;
/*      */     LocalVariableBinding localBinding;
/*  191 */     switch (this.bits & 0x7) {
/*      */       case 1:
/*  193 */         if (valueRequired || (currentScope.compilerOptions()).complianceLevel >= 3145728L) {
/*  194 */           manageSyntheticAccessIfNecessary(currentScope, flowInfo, true);
/*      */         }
/*      */         
/*  197 */         fieldBinding = (FieldBinding)this.binding;
/*  198 */         if (fieldBinding.isBlankFinal() && currentScope.needBlankFinalFieldInitializationCheck(fieldBinding)) {
/*  199 */           FlowInfo fieldInits = flowContext.getInitsForFinalBlankInitializationCheck(fieldBinding.declaringClass.original(), flowInfo);
/*  200 */           if (!fieldInits.isDefinitelyAssigned(fieldBinding)) {
/*  201 */             currentScope.problemReporter().uninitializedBlankFinalField(fieldBinding, this);
/*      */           }
/*      */         } 
/*      */         break;
/*      */       
/*      */       case 2:
/*  207 */         if (!flowInfo.isDefinitelyAssigned(localBinding = (LocalVariableBinding)this.binding)) {
/*  208 */           currentScope.problemReporter().uninitializedLocalVariable(localBinding, this, (Scope)currentScope);
/*      */         }
/*  210 */         if ((flowInfo.tagBits & 0x3) == 0) {
/*  211 */           localBinding.useFlag = 1; break;
/*  212 */         }  if (localBinding.useFlag == 0)
/*  213 */           localBinding.useFlag = 2; 
/*      */         break;
/*      */     } 
/*  216 */     if (valueRequired) {
/*  217 */       manageEnclosingInstanceAccessIfNecessary(currentScope, flowInfo);
/*      */     }
/*  219 */     return flowInfo;
/*      */   }
/*      */   
/*      */   public TypeBinding checkFieldAccess(BlockScope scope) {
/*  223 */     FieldBinding fieldBinding = (FieldBinding)this.binding;
/*  224 */     this.constant = fieldBinding.constant((Scope)scope);
/*      */     
/*  226 */     this.bits &= 0xFFFFFFF8;
/*  227 */     this.bits |= 0x1;
/*  228 */     MethodScope methodScope = scope.methodScope();
/*  229 */     if (fieldBinding.isStatic()) {
/*      */       
/*  231 */       ReferenceBinding declaringClass = fieldBinding.declaringClass;
/*  232 */       if (declaringClass.isEnum() && scope.kind != 5) {
/*  233 */         SourceTypeBinding sourceType = scope.enclosingSourceType();
/*  234 */         if (this.constant == Constant.NotAConstant && 
/*  235 */           !methodScope.isStatic && (
/*  236 */           TypeBinding.equalsEquals((TypeBinding)sourceType, (TypeBinding)declaringClass) || TypeBinding.equalsEquals((TypeBinding)sourceType.superclass, (TypeBinding)declaringClass)) && 
/*  237 */           methodScope.isInsideInitializerOrConstructor()) {
/*  238 */           scope.problemReporter().enumStaticFieldUsedDuringInitialization(fieldBinding, this);
/*      */         }
/*      */       } 
/*      */     } else {
/*  242 */       if (scope.compilerOptions().getSeverity(4194304) != 256) {
/*  243 */         scope.problemReporter().unqualifiedFieldAccess(this, fieldBinding);
/*      */       }
/*      */       
/*  246 */       if (methodScope.isStatic) {
/*  247 */         scope.problemReporter().staticFieldAccessToNonStaticVariable(this, fieldBinding);
/*  248 */         return fieldBinding.type;
/*      */       } 
/*  250 */       scope.tagAsAccessingEnclosingInstanceStateOf(fieldBinding.declaringClass, false);
/*      */     } 
/*      */ 
/*      */     
/*  254 */     if (isFieldUseDeprecated(fieldBinding, (Scope)scope, this.bits)) {
/*  255 */       scope.problemReporter().deprecatedField(fieldBinding, this);
/*      */     }
/*  257 */     if ((this.bits & 0x2000) == 0 && 
/*  258 */       TypeBinding.equalsEquals((TypeBinding)methodScope.enclosingSourceType(), (TypeBinding)(fieldBinding.original()).declaringClass) && 
/*  259 */       methodScope.lastVisibleFieldID >= 0 && 
/*  260 */       fieldBinding.id >= methodScope.lastVisibleFieldID && (
/*  261 */       !fieldBinding.isStatic() || methodScope.isStatic)) {
/*  262 */       scope.problemReporter().forwardReference(this, 0, fieldBinding);
/*  263 */       this.bits |= 0x20000000;
/*      */     } 
/*  265 */     return fieldBinding.type;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean checkNPE(BlockScope scope, FlowContext flowContext, FlowInfo flowInfo, int ttlForFieldCheck) {
/*  271 */     if (!super.checkNPE(scope, flowContext, flowInfo, ttlForFieldCheck)) {
/*  272 */       CompilerOptions compilerOptions = scope.compilerOptions();
/*  273 */       if (compilerOptions.isAnnotationBasedNullAnalysisEnabled && 
/*  274 */         this.binding instanceof FieldBinding) {
/*  275 */         return checkNullableFieldDereference((Scope)scope, (FieldBinding)this.binding, (this.sourceStart << 32L) + this.sourceEnd, flowContext, ttlForFieldCheck);
/*      */       }
/*      */     } 
/*      */     
/*  279 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void computeConversion(Scope scope, TypeBinding runtimeTimeType, TypeBinding compileTimeType) {
/*  287 */     if (runtimeTimeType == null || compileTimeType == null)
/*      */       return; 
/*  289 */     if (this.binding != null && this.binding.isValidBinding()) {
/*  290 */       TypeBinding originalType = null;
/*  291 */       if ((this.bits & 0x1) != 0) {
/*      */         
/*  293 */         FieldBinding field = (FieldBinding)this.binding;
/*  294 */         FieldBinding originalBinding = field.original();
/*  295 */         originalType = originalBinding.type;
/*  296 */       } else if ((this.bits & 0x2) != 0) {
/*  297 */         LocalVariableBinding local = (LocalVariableBinding)this.binding;
/*  298 */         originalType = local.type;
/*      */       } 
/*      */       
/*  301 */       if (originalType != null && originalType.leafComponentType().isTypeVariable()) {
/*  302 */         TypeBinding targetType = (!compileTimeType.isBaseType() && runtimeTimeType.isBaseType()) ? 
/*  303 */           compileTimeType : 
/*  304 */           runtimeTimeType;
/*  305 */         this.genericCast = originalType.genericCast(scope.boxing(targetType));
/*  306 */         if (this.genericCast instanceof ReferenceBinding) {
/*  307 */           ReferenceBinding referenceCast = (ReferenceBinding)this.genericCast;
/*  308 */           if (!referenceCast.canBeSeenBy(scope)) {
/*  309 */             scope.problemReporter().invalidType(this, 
/*  310 */                 (TypeBinding)new ProblemReferenceBinding(
/*  311 */                   CharOperation.splitOn('.', referenceCast.shortReadableName()), 
/*  312 */                   referenceCast, 
/*  313 */                   2));
/*      */           }
/*      */         } 
/*      */       } 
/*      */     } 
/*  318 */     super.computeConversion(scope, runtimeTimeType, compileTimeType);
/*      */   }
/*      */   public void generateAssignment(BlockScope currentScope, CodeStream codeStream, Assignment assignment, boolean valueRequired) {
/*      */     int pc;
/*      */     FieldBinding codegenBinding;
/*      */     LocalVariableBinding localBinding;
/*  324 */     if (assignment.expression.isCompactableOperation()) {
/*  325 */       BinaryExpression operation = (BinaryExpression)assignment.expression;
/*  326 */       int operator = (operation.bits & 0x3F00) >> 8;
/*      */       SingleNameReference variableReference;
/*  328 */       if (operation.left instanceof SingleNameReference && (variableReference = (SingleNameReference)operation.left).binding == this.binding) {
/*      */         
/*  330 */         variableReference.generateCompoundAssignment(currentScope, codeStream, (this.syntheticAccessors == null) ? null : this.syntheticAccessors[1], operation.right, operator, operation.implicitConversion, valueRequired);
/*  331 */         if (valueRequired) {
/*  332 */           codeStream.generateImplicitConversion(assignment.implicitConversion);
/*      */         }
/*      */         return;
/*      */       } 
/*  336 */       if (operation.right instanceof SingleNameReference && (
/*  337 */         operator == 14 || operator == 15) && 
/*  338 */         (variableReference = (SingleNameReference)operation.right).binding == this.binding && 
/*  339 */         operation.left.constant != Constant.NotAConstant && (
/*  340 */         operation.left.implicitConversion & 0xFF) >> 4 != 11 && (
/*  341 */         operation.right.implicitConversion & 0xFF) >> 4 != 11) {
/*      */         
/*  343 */         variableReference.generateCompoundAssignment(currentScope, codeStream, (this.syntheticAccessors == null) ? null : this.syntheticAccessors[1], operation.left, operator, operation.implicitConversion, valueRequired);
/*  344 */         if (valueRequired) {
/*  345 */           codeStream.generateImplicitConversion(assignment.implicitConversion);
/*      */         }
/*      */         return;
/*      */       } 
/*      */     } 
/*  350 */     switch (this.bits & 0x7) {
/*      */       case 1:
/*  352 */         pc = codeStream.position;
/*  353 */         codegenBinding = ((FieldBinding)this.binding).original();
/*  354 */         if (!codegenBinding.isStatic()) {
/*  355 */           if ((this.bits & 0x1FE0) != 0) {
/*  356 */             ReferenceBinding targetType = currentScope.enclosingSourceType().enclosingTypeAt((this.bits & 0x1FE0) >> 5);
/*  357 */             Object[] emulationPath = currentScope.getEmulationPath(targetType, true, false);
/*  358 */             codeStream.generateOuterAccess(emulationPath, this, (Binding)targetType, (Scope)currentScope);
/*      */           } else {
/*  360 */             generateReceiver(codeStream);
/*      */           } 
/*      */         }
/*  363 */         codeStream.recordPositionsFrom(pc, this.sourceStart);
/*  364 */         assignment.expression.generateCode(currentScope, codeStream, true);
/*  365 */         fieldStore((Scope)currentScope, codeStream, codegenBinding, (this.syntheticAccessors == null) ? null : this.syntheticAccessors[1], this.actualReceiverType, true, valueRequired);
/*  366 */         if (valueRequired) {
/*  367 */           codeStream.generateImplicitConversion(assignment.implicitConversion);
/*      */         }
/*      */         return;
/*      */       
/*      */       case 2:
/*  372 */         localBinding = (LocalVariableBinding)this.binding;
/*  373 */         if (localBinding.resolvedPosition != -1) {
/*  374 */           assignment.expression.generateCode(currentScope, codeStream, true);
/*      */         } else {
/*  376 */           if (assignment.expression.constant != Constant.NotAConstant) {
/*      */             
/*  378 */             if (valueRequired) {
/*  379 */               codeStream.generateConstant(assignment.expression.constant, assignment.implicitConversion);
/*      */             }
/*      */           } else {
/*  382 */             assignment.expression.generateCode(currentScope, codeStream, true);
/*      */ 
/*      */             
/*  385 */             if (valueRequired) {
/*  386 */               codeStream.generateImplicitConversion(assignment.implicitConversion);
/*      */             } else {
/*  388 */               switch (localBinding.type.id) {
/*      */                 case 7:
/*      */                 case 8:
/*  391 */                   codeStream.pop2();
/*      */                   return;
/*      */               } 
/*  394 */               codeStream.pop();
/*      */             } 
/*      */           } 
/*      */ 
/*      */           
/*      */           return;
/*      */         } 
/*      */         
/*  402 */         if (localBinding.type.isArrayType() && 
/*  403 */           assignment.expression instanceof CastExpression && 
/*  404 */           (((CastExpression)assignment.expression).innermostCastedExpression()).resolvedType == TypeBinding.NULL) {
/*  405 */           codeStream.checkcast(localBinding.type);
/*      */         }
/*      */ 
/*      */         
/*  409 */         codeStream.store(localBinding, valueRequired);
/*  410 */         if ((this.bits & 0x10) != 0) {
/*  411 */           localBinding.recordInitializationStartPC(codeStream.position);
/*      */         }
/*  413 */         if ((this.bits & 0x8) != 0) {
/*  414 */           localBinding.recordInitializationStartPC(codeStream.position);
/*      */         }
/*      */         
/*  417 */         if (valueRequired)
/*  418 */           codeStream.generateImplicitConversion(assignment.implicitConversion); 
/*      */         break;
/*      */     } 
/*      */   } public void generateCode(BlockScope currentScope, CodeStream codeStream, boolean valueRequired) {
/*      */     FieldBinding codegenField;
/*      */     Constant fieldConstant;
/*      */     LocalVariableBinding localBinding;
/*  425 */     int pc = codeStream.position;
/*  426 */     if (this.constant != Constant.NotAConstant) {
/*  427 */       if (valueRequired) {
/*  428 */         codeStream.generateConstant(this.constant, this.implicitConversion);
/*      */       }
/*  430 */       codeStream.recordPositionsFrom(pc, this.sourceStart);
/*      */       return;
/*      */     } 
/*  433 */     switch (this.bits & 0x7) {
/*      */       case 1:
/*  435 */         codegenField = ((FieldBinding)this.binding).original();
/*  436 */         fieldConstant = codegenField.constant();
/*  437 */         if (fieldConstant != Constant.NotAConstant) {
/*      */           
/*  439 */           if (valueRequired) {
/*  440 */             codeStream.generateConstant(fieldConstant, this.implicitConversion);
/*      */           }
/*  442 */           codeStream.recordPositionsFrom(pc, this.sourceStart);
/*      */           return;
/*      */         } 
/*  445 */         if (codegenField.isStatic()) {
/*  446 */           if (!valueRequired)
/*      */           {
/*  448 */             if (TypeBinding.equalsEquals((TypeBinding)(((FieldBinding)this.binding).original()).declaringClass, this.actualReceiverType.erasure()) && (
/*  449 */               this.implicitConversion & 0x400) == 0 && 
/*  450 */               this.genericCast == null) {
/*      */               
/*  452 */               codeStream.recordPositionsFrom(pc, this.sourceStart);
/*      */               return;
/*      */             } 
/*      */           }
/*  456 */           if (this.syntheticAccessors == null || this.syntheticAccessors[0] == null) {
/*  457 */             TypeBinding constantPoolDeclaringClass = CodeStream.getConstantPoolDeclaringClass((Scope)currentScope, codegenField, this.actualReceiverType, true);
/*  458 */             codeStream.fieldAccess((byte)-78, codegenField, constantPoolDeclaringClass); break;
/*      */           } 
/*  460 */           codeStream.invoke((byte)-72, this.syntheticAccessors[0], null);
/*      */           break;
/*      */         } 
/*  463 */         if (!valueRequired && (
/*  464 */           this.implicitConversion & 0x400) == 0 && 
/*  465 */           this.genericCast == null) {
/*      */           
/*  467 */           codeStream.recordPositionsFrom(pc, this.sourceStart);
/*      */           
/*      */           return;
/*      */         } 
/*  471 */         if ((this.bits & 0x1FE0) != 0) {
/*  472 */           ReferenceBinding targetType = currentScope.enclosingSourceType().enclosingTypeAt((this.bits & 0x1FE0) >> 5);
/*  473 */           Object[] emulationPath = currentScope.getEmulationPath(targetType, true, false);
/*  474 */           codeStream.generateOuterAccess(emulationPath, this, (Binding)targetType, (Scope)currentScope);
/*      */         } else {
/*  476 */           generateReceiver(codeStream);
/*      */         } 
/*      */         
/*  479 */         if (this.syntheticAccessors == null || this.syntheticAccessors[0] == null) {
/*  480 */           TypeBinding constantPoolDeclaringClass = CodeStream.getConstantPoolDeclaringClass((Scope)currentScope, codegenField, this.actualReceiverType, true);
/*  481 */           codeStream.fieldAccess((byte)-76, codegenField, constantPoolDeclaringClass); break;
/*      */         } 
/*  483 */         codeStream.invoke((byte)-72, this.syntheticAccessors[0], null);
/*      */         break;
/*      */ 
/*      */       
/*      */       case 2:
/*  488 */         localBinding = (LocalVariableBinding)this.binding;
/*  489 */         if (localBinding.resolvedPosition == -1) {
/*  490 */           if (valueRequired) {
/*      */             
/*  492 */             localBinding.useFlag = 1;
/*  493 */             throw new AbortMethod(CodeStream.RESTART_CODE_GEN_FOR_UNUSED_LOCALS_MODE, null);
/*      */           } 
/*  495 */           codeStream.recordPositionsFrom(pc, this.sourceStart);
/*      */           return;
/*      */         } 
/*  498 */         if (!valueRequired && (this.implicitConversion & 0x400) == 0) {
/*      */           
/*  500 */           codeStream.recordPositionsFrom(pc, this.sourceStart);
/*      */           
/*      */           return;
/*      */         } 
/*  504 */         if (checkEffectiveFinality((VariableBinding)localBinding, (Scope)currentScope)) {
/*      */           
/*  506 */           VariableBinding[] path = currentScope.getEmulationPath(localBinding);
/*  507 */           codeStream.generateOuterAccess((Object[])path, this, (Binding)localBinding, (Scope)currentScope);
/*      */           break;
/*      */         } 
/*  510 */         codeStream.load(localBinding);
/*      */         break;
/*      */       
/*      */       default:
/*  514 */         codeStream.recordPositionsFrom(pc, this.sourceStart);
/*      */         return;
/*      */     } 
/*      */ 
/*      */     
/*  519 */     if (this.genericCast != null) codeStream.checkcast(this.genericCast); 
/*  520 */     if (valueRequired) {
/*  521 */       codeStream.generateImplicitConversion(this.implicitConversion);
/*      */     } else {
/*  523 */       boolean isUnboxing = ((this.implicitConversion & 0x400) != 0);
/*      */       
/*  525 */       if (isUnboxing) codeStream.generateImplicitConversion(this.implicitConversion); 
/*  526 */       switch (isUnboxing ? (postConversionType((Scope)currentScope)).id : this.resolvedType.id) {
/*      */         case 7:
/*      */         case 8:
/*  529 */           codeStream.pop2();
/*      */           break;
/*      */         default:
/*  532 */           codeStream.pop(); break;
/*      */       } 
/*      */     } 
/*  535 */     codeStream.recordPositionsFrom(pc, this.sourceStart);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void generateCompoundAssignment(BlockScope currentScope, CodeStream codeStream, Expression expression, int operator, int assignmentImplicitConversion, boolean valueRequired) {
/*      */     LocalVariableBinding localBinding;
/*  547 */     switch (this.bits & 0x7) {
/*      */       case 2:
/*  549 */         localBinding = (LocalVariableBinding)this.binding;
/*      */         
/*  551 */         Reference.reportOnlyUselesslyReadLocal(currentScope, localBinding, valueRequired);
/*      */         break;
/*      */       
/*      */       case 1:
/*  555 */         reportOnlyUselesslyReadPrivateField(currentScope, (FieldBinding)this.binding, valueRequired); break;
/*      */     } 
/*  557 */     generateCompoundAssignment(
/*  558 */         currentScope, 
/*  559 */         codeStream, 
/*  560 */         (this.syntheticAccessors == null) ? null : this.syntheticAccessors[1], 
/*  561 */         expression, 
/*  562 */         operator, 
/*  563 */         assignmentImplicitConversion, 
/*  564 */         valueRequired);
/*      */   }
/*      */   
/*      */   public void generateCompoundAssignment(BlockScope currentScope, CodeStream codeStream, MethodBinding writeAccessor, Expression expression, int operator, int assignmentImplicitConversion, boolean valueRequired) { FieldBinding codegenField;
/*      */     LocalVariableBinding localBinding;
/*      */     FieldBinding fieldBinding1;
/*      */     Constant assignConstant;
/*      */     LocalVariableBinding localVariableBinding1;
/*  572 */     switch (this.bits & 0x7) {
/*      */       case 1:
/*  574 */         codegenField = ((FieldBinding)this.binding).original();
/*  575 */         if (codegenField.isStatic()) {
/*  576 */           if (this.syntheticAccessors == null || this.syntheticAccessors[0] == null) {
/*  577 */             TypeBinding constantPoolDeclaringClass = CodeStream.getConstantPoolDeclaringClass((Scope)currentScope, codegenField, this.actualReceiverType, true);
/*  578 */             codeStream.fieldAccess((byte)-78, codegenField, constantPoolDeclaringClass); break;
/*      */           } 
/*  580 */           codeStream.invoke((byte)-72, this.syntheticAccessors[0], null);
/*      */           break;
/*      */         } 
/*  583 */         if ((this.bits & 0x1FE0) != 0) {
/*  584 */           ReferenceBinding targetType = currentScope.enclosingSourceType().enclosingTypeAt((this.bits & 0x1FE0) >> 5);
/*  585 */           Object[] emulationPath = currentScope.getEmulationPath(targetType, true, false);
/*  586 */           codeStream.generateOuterAccess(emulationPath, this, (Binding)targetType, (Scope)currentScope);
/*      */         } else {
/*  588 */           codeStream.aload_0();
/*      */         } 
/*  590 */         codeStream.dup();
/*  591 */         if (this.syntheticAccessors == null || this.syntheticAccessors[0] == null) {
/*  592 */           TypeBinding constantPoolDeclaringClass = CodeStream.getConstantPoolDeclaringClass((Scope)currentScope, codegenField, this.actualReceiverType, true);
/*  593 */           codeStream.fieldAccess((byte)-76, codegenField, constantPoolDeclaringClass); break;
/*      */         } 
/*  595 */         codeStream.invoke((byte)-72, this.syntheticAccessors[0], null);
/*      */         break;
/*      */ 
/*      */       
/*      */       case 2:
/*  600 */         localBinding = (LocalVariableBinding)this.binding;
/*      */ 
/*      */         
/*  603 */         switch (localBinding.type.id) {
/*      */           case 11:
/*  605 */             codeStream.generateStringConcatenationAppend(currentScope, this, expression);
/*  606 */             if (valueRequired) {
/*  607 */               codeStream.dup();
/*      */             }
/*  609 */             codeStream.store(localBinding, false);
/*      */             return;
/*      */           case 10:
/*  612 */             assignConstant = expression.constant;
/*  613 */             if (localBinding.resolvedPosition == -1) {
/*  614 */               if (valueRequired) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */                 
/*  620 */                 localBinding.useFlag = 1;
/*  621 */                 throw new AbortMethod(CodeStream.RESTART_CODE_GEN_FOR_UNUSED_LOCALS_MODE, null);
/*  622 */               }  if (assignConstant == Constant.NotAConstant)
/*      */               {
/*  624 */                 expression.generateCode(currentScope, codeStream, false);
/*      */               }
/*      */               return;
/*      */             } 
/*  628 */             if (assignConstant != Constant.NotAConstant && 
/*  629 */               assignConstant.typeID() != 9 && 
/*  630 */               assignConstant.typeID() != 8) {
/*  631 */               int increment; switch (operator) {
/*      */                 case 14:
/*  633 */                   increment = assignConstant.intValue();
/*  634 */                   if (increment != (short)increment)
/*  635 */                     break;  codeStream.iinc(localBinding.resolvedPosition, increment);
/*  636 */                   if (valueRequired) {
/*  637 */                     codeStream.load(localBinding);
/*      */                   }
/*      */                   return;
/*      */                 case 13:
/*  641 */                   increment = -assignConstant.intValue();
/*  642 */                   if (increment != (short)increment)
/*  643 */                     break;  codeStream.iinc(localBinding.resolvedPosition, increment);
/*  644 */                   if (valueRequired)
/*  645 */                     codeStream.load(localBinding);  return;
/*      */               } 
/*      */             }  break;
/*  648 */         }  if (localBinding
/*      */ 
/*      */ 
/*      */           
/*  652 */           .resolvedPosition == -1) {
/*  653 */           assignConstant = expression.constant;
/*  654 */           if (valueRequired) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*  660 */             localBinding.useFlag = 1;
/*  661 */             throw new AbortMethod(CodeStream.RESTART_CODE_GEN_FOR_UNUSED_LOCALS_MODE, null);
/*  662 */           }  if (assignConstant == Constant.NotAConstant)
/*      */           {
/*  664 */             expression.generateCode(currentScope, codeStream, false);
/*      */           }
/*      */           return;
/*      */         } 
/*  668 */         codeStream.load(localBinding);
/*      */         break;
/*      */     } 
/*      */     
/*      */     int operationTypeID;
/*  673 */     switch (operationTypeID = (this.implicitConversion & 0xFF) >> 4) {
/*      */ 
/*      */ 
/*      */       
/*      */       case 0:
/*      */       case 1:
/*      */       case 11:
/*  680 */         codeStream.generateStringConcatenationAppend(currentScope, null, expression);
/*      */         break;
/*      */ 
/*      */       
/*      */       default:
/*  685 */         if (this.genericCast != null)
/*  686 */           codeStream.checkcast(this.genericCast); 
/*  687 */         codeStream.generateImplicitConversion(this.implicitConversion);
/*      */         
/*  689 */         if (expression == IntLiteral.One) {
/*  690 */           codeStream.generateConstant(expression.constant, this.implicitConversion);
/*      */         } else {
/*  692 */           expression.generateCode(currentScope, codeStream, true);
/*      */         } 
/*      */         
/*  695 */         codeStream.sendOperator(operator, operationTypeID);
/*      */         
/*  697 */         codeStream.generateImplicitConversion(assignmentImplicitConversion);
/*      */         break;
/*      */     } 
/*  700 */     switch (this.bits & 0x7) {
/*      */       case 1:
/*  702 */         fieldBinding1 = ((FieldBinding)this.binding).original();
/*  703 */         fieldStore((Scope)currentScope, codeStream, fieldBinding1, writeAccessor, this.actualReceiverType, true, valueRequired);
/*      */         return;
/*      */       
/*      */       case 2:
/*  707 */         localVariableBinding1 = (LocalVariableBinding)this.binding;
/*  708 */         if (valueRequired) {
/*  709 */           switch (localVariableBinding1.type.id) {
/*      */             case 7:
/*      */             case 8:
/*  712 */               codeStream.dup2();
/*      */               break;
/*      */             default:
/*  715 */               codeStream.dup();
/*      */               break;
/*      */           } 
/*      */         }
/*  719 */         codeStream.store(localVariableBinding1, false);
/*      */         break;
/*      */     }  } public void generatePostIncrement(BlockScope currentScope, CodeStream codeStream, CompoundAssignment postIncrement, boolean valueRequired) { FieldBinding fieldBinding;
/*      */     FieldBinding codegenField;
/*      */     TypeBinding operandType;
/*      */     LocalVariableBinding localBinding;
/*  725 */     switch (this.bits & 0x7) {
/*      */       case 1:
/*  727 */         fieldBinding = (FieldBinding)this.binding;
/*      */ 
/*      */         
/*  730 */         reportOnlyUselesslyReadPrivateField(currentScope, fieldBinding, valueRequired);
/*  731 */         codegenField = fieldBinding.original();
/*  732 */         if (codegenField.isStatic()) {
/*  733 */           if (this.syntheticAccessors == null || this.syntheticAccessors[0] == null) {
/*  734 */             TypeBinding constantPoolDeclaringClass = CodeStream.getConstantPoolDeclaringClass((Scope)currentScope, codegenField, this.actualReceiverType, true);
/*  735 */             codeStream.fieldAccess((byte)-78, codegenField, constantPoolDeclaringClass);
/*      */           } else {
/*  737 */             codeStream.invoke((byte)-72, this.syntheticAccessors[0], null);
/*      */           } 
/*      */         } else {
/*  740 */           if ((this.bits & 0x1FE0) != 0) {
/*  741 */             ReferenceBinding targetType = currentScope.enclosingSourceType().enclosingTypeAt((this.bits & 0x1FE0) >> 5);
/*  742 */             Object[] emulationPath = currentScope.getEmulationPath(targetType, true, false);
/*  743 */             codeStream.generateOuterAccess(emulationPath, this, (Binding)targetType, (Scope)currentScope);
/*      */           } else {
/*  745 */             codeStream.aload_0();
/*      */           } 
/*  747 */           codeStream.dup();
/*  748 */           if (this.syntheticAccessors == null || this.syntheticAccessors[0] == null) {
/*  749 */             TypeBinding constantPoolDeclaringClass = CodeStream.getConstantPoolDeclaringClass((Scope)currentScope, codegenField, this.actualReceiverType, true);
/*  750 */             codeStream.fieldAccess((byte)-76, codegenField, constantPoolDeclaringClass);
/*      */           } else {
/*  752 */             codeStream.invoke((byte)-72, this.syntheticAccessors[0], null);
/*      */           } 
/*      */         } 
/*      */         
/*  756 */         if (this.genericCast != null) {
/*  757 */           codeStream.checkcast(this.genericCast);
/*  758 */           operandType = this.genericCast;
/*      */         } else {
/*  760 */           operandType = codegenField.type;
/*      */         } 
/*  762 */         if (valueRequired) {
/*  763 */           if (codegenField.isStatic()) {
/*  764 */             switch (operandType.id) {
/*      */               case 7:
/*      */               case 8:
/*  767 */                 codeStream.dup2();
/*      */                 break;
/*      */               default:
/*  770 */                 codeStream.dup();
/*      */                 break;
/*      */             } 
/*      */           } else {
/*  774 */             switch (operandType.id) {
/*      */               case 7:
/*      */               case 8:
/*  777 */                 codeStream.dup2_x1();
/*      */                 break;
/*      */               default:
/*  780 */                 codeStream.dup_x1();
/*      */                 break;
/*      */             } 
/*      */           } 
/*      */         }
/*  785 */         codeStream.generateImplicitConversion(this.implicitConversion);
/*  786 */         codeStream.generateConstant(postIncrement.expression.constant, this.implicitConversion);
/*  787 */         codeStream.sendOperator(postIncrement.operator, this.implicitConversion & 0xF);
/*  788 */         codeStream.generateImplicitConversion(postIncrement.preAssignImplicitConversion);
/*  789 */         fieldStore((Scope)currentScope, codeStream, codegenField, (this.syntheticAccessors == null) ? null : this.syntheticAccessors[1], this.actualReceiverType, true, false);
/*      */         return;
/*      */       
/*      */       case 2:
/*  793 */         localBinding = (LocalVariableBinding)this.binding;
/*      */ 
/*      */         
/*  796 */         Reference.reportOnlyUselesslyReadLocal(currentScope, localBinding, valueRequired);
/*  797 */         if (localBinding.resolvedPosition == -1) {
/*  798 */           if (valueRequired) {
/*      */             
/*  800 */             localBinding.useFlag = 1;
/*  801 */             throw new AbortMethod(CodeStream.RESTART_CODE_GEN_FOR_UNUSED_LOCALS_MODE, null);
/*      */           } 
/*      */           
/*      */           return;
/*      */         } 
/*      */         
/*  807 */         if (TypeBinding.equalsEquals(localBinding.type, (TypeBinding)TypeBinding.INT)) {
/*  808 */           if (valueRequired) {
/*  809 */             codeStream.load(localBinding);
/*      */           }
/*  811 */           if (postIncrement.operator == 14) {
/*  812 */             codeStream.iinc(localBinding.resolvedPosition, 1); break;
/*      */           } 
/*  814 */           codeStream.iinc(localBinding.resolvedPosition, -1);
/*      */           break;
/*      */         } 
/*  817 */         codeStream.load(localBinding);
/*  818 */         if (valueRequired) {
/*  819 */           switch (localBinding.type.id) {
/*      */             case 7:
/*      */             case 8:
/*  822 */               codeStream.dup2();
/*      */               break;
/*      */             default:
/*  825 */               codeStream.dup();
/*      */               break;
/*      */           } 
/*      */         }
/*  829 */         codeStream.generateImplicitConversion(this.implicitConversion);
/*  830 */         codeStream.generateConstant(postIncrement.expression.constant, this.implicitConversion);
/*  831 */         codeStream.sendOperator(postIncrement.operator, this.implicitConversion & 0xF);
/*  832 */         codeStream.generateImplicitConversion(postIncrement.preAssignImplicitConversion);
/*  833 */         codeStream.store(localBinding, false);
/*      */         break;
/*      */     }  }
/*      */ 
/*      */   
/*      */   public void generateReceiver(CodeStream codeStream) {
/*  839 */     codeStream.aload_0();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public TypeBinding[] genericTypeArguments() {
/*  847 */     return null;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isEquivalent(Reference reference) {
/*  852 */     char[] otherToken = null;
/*  853 */     if (reference instanceof SingleNameReference) {
/*  854 */       otherToken = ((SingleNameReference)reference).token;
/*  855 */     } else if (reference instanceof FieldReference) {
/*      */       
/*  857 */       FieldReference fr = (FieldReference)reference;
/*  858 */       if (fr.receiver.isThis() && !(fr.receiver instanceof QualifiedThisReference))
/*  859 */         otherToken = fr.token; 
/*      */     } 
/*  861 */     return (otherToken != null && CharOperation.equals(this.token, otherToken));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public LocalVariableBinding localVariableBinding() {
/*  870 */     switch (this.bits & 0x7) {
/*      */ 
/*      */       
/*      */       case 2:
/*  874 */         return (LocalVariableBinding)this.binding;
/*      */     } 
/*  876 */     return null;
/*      */   }
/*      */ 
/*      */   
/*      */   public VariableBinding nullAnnotatedVariableBinding(boolean supportTypeAnnotations) {
/*  881 */     switch (this.bits & 0x7) {
/*      */       case 1:
/*      */       case 2:
/*  884 */         if (supportTypeAnnotations || (
/*  885 */           ((VariableBinding)this.binding).tagBits & 0x180000000000000L) != 0L)
/*  886 */           return (VariableBinding)this.binding;  break;
/*      */     } 
/*  888 */     return null;
/*      */   }
/*      */ 
/*      */   
/*      */   public int nullStatus(FlowInfo flowInfo, FlowContext flowContext) {
/*  893 */     if ((this.implicitConversion & 0x200) != 0)
/*  894 */       return 4; 
/*  895 */     LocalVariableBinding local = localVariableBinding();
/*  896 */     if (local != null) {
/*  897 */       return flowInfo.nullStatus(local);
/*      */     }
/*  899 */     return super.nullStatus(flowInfo, flowContext);
/*      */   }
/*      */ 
/*      */   
/*      */   public void manageEnclosingInstanceAccessIfNecessary(BlockScope currentScope, FlowInfo flowInfo) {
/*  904 */     if (((this.bits & 0x1FE0) == 0 && (this.bits & 0x80000) == 0) || this.constant != Constant.NotAConstant) {
/*      */       return;
/*      */     }
/*  907 */     if ((this.bits & 0x7) == 2) {
/*  908 */       LocalVariableBinding localVariableBinding = (LocalVariableBinding)this.binding;
/*  909 */       if (localVariableBinding != null) {
/*  910 */         if (localVariableBinding.isUninitializedIn((Scope)currentScope)) {
/*      */           return;
/*      */         }
/*      */         
/*  914 */         if ((localVariableBinding.tagBits & 0x800L) == 0L) {
/*      */           return;
/*      */         }
/*      */         
/*  918 */         switch (localVariableBinding.useFlag) {
/*      */           case 1:
/*      */           case 2:
/*  921 */             currentScope.emulateOuterAccess(localVariableBinding);
/*      */             break;
/*      */         } 
/*      */       } 
/*      */     } 
/*      */   }
/*      */   public void manageSyntheticAccessIfNecessary(BlockScope currentScope, FlowInfo flowInfo, boolean isReadAccess) {
/*  928 */     if ((flowInfo.tagBits & 0x1) != 0) {
/*      */       return;
/*      */     }
/*  931 */     if (this.constant != Constant.NotAConstant) {
/*      */       return;
/*      */     }
/*  934 */     if ((this.bits & 0x1) != 0) {
/*  935 */       FieldBinding fieldBinding = (FieldBinding)this.binding;
/*  936 */       FieldBinding codegenField = fieldBinding.original();
/*  937 */       if ((this.bits & 0x1FE0) != 0 && ((
/*  938 */         codegenField.isPrivate() && 
/*  939 */         !currentScope.enclosingSourceType().isNestmateOf(codegenField.declaringClass)) || (
/*  940 */         codegenField.isProtected() && 
/*  941 */         codegenField.declaringClass.getPackage() != currentScope.enclosingSourceType().getPackage()))) {
/*  942 */         if (this.syntheticAccessors == null)
/*  943 */           this.syntheticAccessors = new MethodBinding[2]; 
/*  944 */         this.syntheticAccessors[isReadAccess ? 0 : 1] = 
/*  945 */           (MethodBinding)((SourceTypeBinding)currentScope.enclosingSourceType()
/*  946 */           .enclosingTypeAt((this.bits & 0x1FE0) >> 5)).addSyntheticMethod(codegenField, isReadAccess, false);
/*  947 */         currentScope.problemReporter().needToEmulateFieldAccess(codegenField, this, isReadAccess);
/*      */         return;
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public TypeBinding postConversionType(Scope scope) {
/*      */     BaseTypeBinding baseTypeBinding;
/*  958 */     TypeBinding typeBinding1, convertedType = this.resolvedType;
/*  959 */     if (this.genericCast != null)
/*  960 */       convertedType = this.genericCast; 
/*  961 */     int runtimeType = (this.implicitConversion & 0xFF) >> 4;
/*  962 */     switch (runtimeType) {
/*      */       case 5:
/*  964 */         baseTypeBinding = TypeBinding.BOOLEAN;
/*      */         break;
/*      */       case 3:
/*  967 */         baseTypeBinding = TypeBinding.BYTE;
/*      */         break;
/*      */       case 4:
/*  970 */         baseTypeBinding = TypeBinding.SHORT;
/*      */         break;
/*      */       case 2:
/*  973 */         baseTypeBinding = TypeBinding.CHAR;
/*      */         break;
/*      */       case 10:
/*  976 */         baseTypeBinding = TypeBinding.INT;
/*      */         break;
/*      */       case 9:
/*  979 */         baseTypeBinding = TypeBinding.FLOAT;
/*      */         break;
/*      */       case 7:
/*  982 */         baseTypeBinding = TypeBinding.LONG;
/*      */         break;
/*      */       case 8:
/*  985 */         baseTypeBinding = TypeBinding.DOUBLE;
/*      */         break;
/*      */     } 
/*      */     
/*  989 */     if ((this.implicitConversion & 0x200) != 0) {
/*  990 */       typeBinding1 = scope.environment().computeBoxingType((TypeBinding)baseTypeBinding);
/*      */     }
/*  992 */     return typeBinding1;
/*      */   }
/*      */ 
/*      */   
/*      */   public StringBuffer printExpression(int indent, StringBuffer output) {
/*  997 */     return output.append(this.token);
/*      */   }
/*      */   
/*      */   public TypeBinding reportError(BlockScope scope) {
/* 1001 */     this.constant = Constant.NotAConstant;
/* 1002 */     if (this.binding instanceof org.eclipse.jdt.internal.compiler.lookup.ProblemFieldBinding) {
/* 1003 */       scope.problemReporter().invalidField(this, (FieldBinding)this.binding);
/* 1004 */     } else if (this.binding instanceof ProblemReferenceBinding || this.binding instanceof org.eclipse.jdt.internal.compiler.lookup.MissingTypeBinding) {
/* 1005 */       scope.problemReporter().invalidType(this, (TypeBinding)this.binding);
/*      */     } else {
/* 1007 */       scope.problemReporter().unresolvableReference(this, this.binding);
/*      */     } 
/* 1009 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public TypeBinding resolveType(BlockScope scope) {
/* 1016 */     if (this.actualReceiverType != null) {
/* 1017 */       this.binding = (Binding)scope.getField(this.actualReceiverType, this.token, this);
/*      */     } else {
/* 1019 */       this.actualReceiverType = (TypeBinding)scope.enclosingSourceType();
/* 1020 */       this.binding = scope.getBinding(this.token, this.bits & 0x7, this, true);
/*      */     } 
/* 1022 */     if (this.binding.isValidBinding()) {
/* 1023 */       TypeBinding type; switch (this.bits & 0x7) {
/*      */         case 3:
/*      */         case 7:
/* 1026 */           if (this.binding instanceof VariableBinding) {
/* 1027 */             TypeBinding variableType; VariableBinding variable = (VariableBinding)this.binding;
/*      */             
/* 1029 */             if (this.binding instanceof LocalVariableBinding) {
/* 1030 */               this.bits &= 0xFFFFFFF8;
/* 1031 */               this.bits |= 0x2;
/* 1032 */               ((LocalVariableBinding)this.binding).markReferenced();
/* 1033 */               if (!variable.isFinal() && (this.bits & 0x80000) != 0 && 
/* 1034 */                 (scope.compilerOptions()).sourceLevel < 3407872L) {
/* 1035 */                 scope.problemReporter().cannotReferToNonFinalOuterLocal((LocalVariableBinding)variable, this);
/*      */               }
/* 1037 */               checkLocalStaticClassVariables(scope, variable);
/* 1038 */               variableType = variable.type;
/* 1039 */               this.constant = ((this.bits & 0x2000) == 0) ? variable.constant((Scope)scope) : Constant.NotAConstant;
/*      */             } else {
/*      */               
/* 1042 */               variableType = checkFieldAccess(scope);
/*      */             } 
/*      */             
/* 1045 */             if (variableType != null) {
/* 1046 */               this.resolvedType = 
/*      */                 
/* 1048 */                 variableType = ((this.bits & 0x2000) == 0) ? variableType.capture((Scope)scope, this.sourceStart, this.sourceEnd) : variableType;
/* 1049 */               if ((variableType.tagBits & 0x80L) != 0L) {
/* 1050 */                 if ((this.bits & 0x2) == 0)
/*      */                 {
/* 1052 */                   scope.problemReporter().invalidType(this, variableType);
/*      */                 }
/* 1054 */                 return null;
/*      */               } 
/*      */             } 
/* 1057 */             return variableType;
/*      */           } 
/*      */ 
/*      */           
/* 1061 */           this.bits &= 0xFFFFFFF8;
/* 1062 */           this.bits |= 0x4;
/*      */         
/*      */         case 4:
/* 1065 */           this.constant = Constant.NotAConstant;
/*      */           
/* 1067 */           type = (TypeBinding)this.binding;
/* 1068 */           if (isTypeUseDeprecated(type, (Scope)scope))
/* 1069 */             scope.problemReporter().deprecatedType(type, this); 
/* 1070 */           type = scope.environment().convertToRawType(type, false);
/* 1071 */           return this.resolvedType = type;
/*      */       } 
/*      */     
/*      */     } 
/* 1075 */     return this.resolvedType = reportError(scope);
/*      */   }
/*      */   
/*      */   private void checkLocalStaticClassVariables(BlockScope scope, VariableBinding variable) {
/* 1079 */     if (this.actualReceiverType.isStatic() && this.actualReceiverType.isLocalType() && (
/* 1080 */       variable.modifiers & 0x8) == 0 && (
/* 1081 */       this.bits & 0x80000) != 0) {
/* 1082 */       BlockScope declaringScope = ((LocalVariableBinding)this.binding).declaringScope;
/* 1083 */       MethodScope declaringMethodScope = (declaringScope instanceof MethodScope) ? (MethodScope)declaringScope : 
/* 1084 */         declaringScope.enclosingMethodScope();
/* 1085 */       MethodScope currentMethodScope = (scope instanceof MethodScope) ? (MethodScope)scope : scope.enclosingMethodScope();
/* 1086 */       ClassScope declaringClassScope = (declaringMethodScope != null) ? declaringMethodScope.classScope() : null;
/* 1087 */       ClassScope currentClassScope = (currentMethodScope != null) ? currentMethodScope.classScope() : null;
/* 1088 */       if (declaringClassScope != currentClassScope) {
/* 1089 */         scope.problemReporter().recordStaticReferenceToOuterLocalVariable((LocalVariableBinding)variable, this);
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public void traverse(ASTVisitor visitor, BlockScope scope) {
/* 1096 */     visitor.visit(this, scope);
/* 1097 */     visitor.endVisit(this, scope);
/*      */   }
/*      */ 
/*      */   
/*      */   public void traverse(ASTVisitor visitor, ClassScope scope) {
/* 1102 */     visitor.visit(this, scope);
/* 1103 */     visitor.endVisit(this, scope);
/*      */   }
/*      */ 
/*      */   
/*      */   public String unboundReferenceErrorName() {
/* 1108 */     return new String(this.token);
/*      */   }
/*      */ 
/*      */   
/*      */   public char[][] getName() {
/* 1113 */     return new char[][] { this.token };
/*      */   }
/*      */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\ast\SingleNameReference.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */