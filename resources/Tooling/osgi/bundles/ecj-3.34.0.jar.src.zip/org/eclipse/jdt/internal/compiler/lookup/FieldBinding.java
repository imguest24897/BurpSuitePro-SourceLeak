/*     */ package org.eclipse.jdt.internal.compiler.lookup;
/*     */ 
/*     */ import org.eclipse.jdt.core.compiler.CharOperation;
/*     */ import org.eclipse.jdt.internal.compiler.IErrorHandlingPolicy;
/*     */ import org.eclipse.jdt.internal.compiler.ast.ASTNode;
/*     */ import org.eclipse.jdt.internal.compiler.ast.FieldDeclaration;
/*     */ import org.eclipse.jdt.internal.compiler.ast.TypeDeclaration;
/*     */ import org.eclipse.jdt.internal.compiler.impl.Constant;
/*     */ import org.eclipse.jdt.internal.compiler.problem.ProblemReporter;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FieldBinding
/*     */   extends VariableBinding
/*     */ {
/*     */   public ReferenceBinding declaringClass;
/*  37 */   public int compoundUseFlag = 0;
/*     */   
/*     */   protected FieldBinding() {
/*  40 */     super(null, null, 0, null);
/*     */   }
/*     */   
/*     */   public FieldBinding(char[] name, TypeBinding type, int modifiers, ReferenceBinding declaringClass, Constant constant) {
/*  44 */     super(name, type, modifiers, constant);
/*  45 */     this.declaringClass = declaringClass;
/*     */   }
/*     */   
/*     */   public FieldBinding(FieldBinding initialFieldBinding, ReferenceBinding declaringClass) {
/*  49 */     super(initialFieldBinding.name, initialFieldBinding.type, initialFieldBinding.modifiers, initialFieldBinding.constant());
/*  50 */     this.declaringClass = declaringClass;
/*  51 */     this.id = initialFieldBinding.id;
/*  52 */     setAnnotations(initialFieldBinding.getAnnotations(), false);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public FieldBinding(FieldDeclaration field, TypeBinding type, int modifiers, ReferenceBinding declaringClass) {
/*  58 */     this(field.name, type, modifiers, declaringClass, (Constant)null);
/*  59 */     field.binding = this;
/*     */   }
/*     */   
/*     */   public final boolean canBeSeenBy(PackageBinding invocationPackage) {
/*  63 */     if (isPublic()) return true; 
/*  64 */     if (isPrivate()) return false;
/*     */ 
/*     */     
/*  67 */     return (invocationPackage == this.declaringClass.getPackage());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final boolean canBeSeenBy(TypeBinding receiverType, InvocationSite invocationSite, Scope scope) {
/*  77 */     if (isPublic()) return true;
/*     */     
/*  79 */     SourceTypeBinding invocationType = scope.enclosingSourceType();
/*  80 */     if (TypeBinding.equalsEquals(invocationType, this.declaringClass) && TypeBinding.equalsEquals(invocationType, receiverType)) return true;
/*     */     
/*  82 */     if (invocationType == null) {
/*  83 */       return (!isPrivate() && scope.getCurrentPackage() == this.declaringClass.fPackage);
/*     */     }
/*  85 */     if (isProtected()) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*  91 */       if (TypeBinding.equalsEquals(invocationType, this.declaringClass)) return true; 
/*  92 */       if (invocationType.fPackage == this.declaringClass.fPackage) return true;
/*     */       
/*  94 */       ReferenceBinding referenceBinding1 = invocationType;
/*  95 */       int depth = 0;
/*  96 */       ReferenceBinding receiverErasure = (ReferenceBinding)receiverType.erasure();
/*  97 */       ReferenceBinding declaringErasure = (ReferenceBinding)this.declaringClass.erasure();
/*     */       while (true) {
/*  99 */         if (referenceBinding1.findSuperTypeOriginatingFrom(declaringErasure) != null) {
/* 100 */           if (invocationSite.isSuperAccess()) {
/* 101 */             return true;
/*     */           }
/* 103 */           if (receiverType instanceof ArrayBinding)
/* 104 */             return false; 
/* 105 */           if (isStatic()) {
/* 106 */             if (depth > 0) invocationSite.setDepth(depth); 
/* 107 */             return true;
/*     */           } 
/* 109 */           if (TypeBinding.equalsEquals(referenceBinding1, receiverErasure) || receiverErasure.findSuperTypeOriginatingFrom(referenceBinding1) != null) {
/* 110 */             if (depth > 0) invocationSite.setDepth(depth); 
/* 111 */             return true;
/*     */           } 
/*     */         } 
/* 114 */         depth++;
/* 115 */         referenceBinding1 = referenceBinding1.enclosingType();
/* 116 */         if (referenceBinding1 == null)
/* 117 */           return false; 
/*     */       } 
/*     */     } 
/* 120 */     if (isPrivate()) {
/*     */ 
/*     */ 
/*     */       
/* 124 */       if (TypeBinding.notEquals(receiverType, this.declaringClass))
/*     */       {
/* 126 */         if ((scope.compilerOptions()).complianceLevel > 3276800L || !receiverType.isTypeVariable() || !((TypeVariableBinding)receiverType).isErasureBoundTo(this.declaringClass.erasure()))
/*     */         {
/* 128 */           return false;
/*     */         }
/*     */       }
/*     */       
/* 132 */       if (TypeBinding.notEquals(invocationType, this.declaringClass)) {
/* 133 */         ReferenceBinding outerInvocationType = invocationType;
/* 134 */         ReferenceBinding temp = outerInvocationType.enclosingType();
/* 135 */         while (temp != null) {
/* 136 */           outerInvocationType = temp;
/* 137 */           temp = temp.enclosingType();
/*     */         } 
/*     */         
/* 140 */         ReferenceBinding outerDeclaringClass = (ReferenceBinding)this.declaringClass.erasure();
/* 141 */         temp = outerDeclaringClass.enclosingType();
/* 142 */         while (temp != null) {
/* 143 */           outerDeclaringClass = temp;
/* 144 */           temp = temp.enclosingType();
/*     */         } 
/* 146 */         if (TypeBinding.notEquals(outerInvocationType, outerDeclaringClass)) return false; 
/*     */       } 
/* 148 */       return true;
/*     */     } 
/*     */ 
/*     */     
/* 152 */     PackageBinding declaringPackage = this.declaringClass.fPackage;
/* 153 */     if (invocationType.fPackage != declaringPackage) return false;
/*     */ 
/*     */     
/* 156 */     if (receiverType instanceof ArrayBinding)
/* 157 */       return false; 
/* 158 */     TypeBinding originalDeclaringClass = this.declaringClass.original();
/* 159 */     ReferenceBinding currentType = (ReferenceBinding)receiverType;
/*     */     while (true) {
/* 161 */       if (currentType.isCapture())
/* 162 */       { if (TypeBinding.equalsEquals(originalDeclaringClass, currentType.erasure().original())) return true;
/*     */          }
/* 164 */       else if (TypeBinding.equalsEquals(originalDeclaringClass, currentType.original())) { return true; }
/*     */       
/* 166 */       PackageBinding currentPackage = currentType.fPackage;
/*     */       
/* 168 */       if (currentPackage != null && currentPackage != declaringPackage) return false; 
/* 169 */       if ((currentType = currentType.superclass()) == null) {
/* 170 */         return false;
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public char[] computeUniqueKey(boolean isLeaf) {
/* 180 */     char[] declaringKey = 
/* 181 */       (this.declaringClass == null) ? 
/* 182 */       CharOperation.NO_CHAR : 
/* 183 */       this.declaringClass.computeUniqueKey(false);
/* 184 */     int declaringLength = declaringKey.length;
/*     */ 
/*     */     
/* 187 */     int nameLength = this.name.length;
/*     */ 
/*     */     
/* 190 */     (new char[1])[0] = 'V'; char[] returnTypeKey = (this.type == null) ? new char[1] : this.type.computeUniqueKey(false);
/* 191 */     int returnTypeLength = returnTypeKey.length;
/*     */     
/* 193 */     char[] uniqueKey = new char[declaringLength + 1 + nameLength + 1 + returnTypeLength];
/* 194 */     int index = 0;
/* 195 */     System.arraycopy(declaringKey, 0, uniqueKey, index, declaringLength);
/* 196 */     index += declaringLength;
/* 197 */     uniqueKey[index++] = '.';
/* 198 */     System.arraycopy(this.name, 0, uniqueKey, index, nameLength);
/* 199 */     index += nameLength;
/* 200 */     uniqueKey[index++] = ')';
/* 201 */     System.arraycopy(returnTypeKey, 0, uniqueKey, index, returnTypeLength);
/* 202 */     return uniqueKey;
/*     */   }
/*     */   
/*     */   public Constant constant() {
/* 206 */     Constant fieldConstant = this.constant;
/* 207 */     if (fieldConstant == null) {
/* 208 */       if (isFinal()) {
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 213 */         FieldBinding originalField = original();
/* 214 */         if (originalField.declaringClass instanceof SourceTypeBinding) {
/* 215 */           SourceTypeBinding sourceType = (SourceTypeBinding)originalField.declaringClass;
/* 216 */           if (sourceType.scope != null) {
/* 217 */             TypeDeclaration typeDecl = sourceType.scope.referenceContext;
/* 218 */             FieldDeclaration fieldDecl = typeDecl.declarationOf(originalField);
/* 219 */             MethodScope initScope = originalField.isStatic() ? typeDecl.staticInitializerScope : typeDecl.initializerScope;
/* 220 */             boolean old = initScope.insideTypeAnnotation;
/*     */             try {
/* 222 */               initScope.insideTypeAnnotation = false;
/* 223 */               fieldDecl.resolve(initScope);
/*     */             } finally {
/* 225 */               initScope.insideTypeAnnotation = old;
/*     */             } 
/* 227 */             fieldConstant = (originalField.constant == null) ? Constant.NotAConstant : originalField.constant;
/*     */           } else {
/* 229 */             fieldConstant = Constant.NotAConstant;
/*     */           } 
/*     */         } else {
/* 232 */           fieldConstant = Constant.NotAConstant;
/*     */         } 
/*     */       } else {
/* 235 */         fieldConstant = Constant.NotAConstant;
/*     */       } 
/* 237 */       this.constant = fieldConstant;
/*     */     } 
/* 239 */     return fieldConstant;
/*     */   }
/*     */ 
/*     */   
/*     */   public Constant constant(Scope scope) {
/* 244 */     if (this.constant != null)
/* 245 */       return this.constant; 
/* 246 */     ProblemReporter problemReporter = scope.problemReporter();
/* 247 */     IErrorHandlingPolicy suspendedPolicy = problemReporter.suspendTempErrorHandlingPolicy();
/*     */     try {
/* 249 */       return constant();
/*     */     } finally {
/* 251 */       problemReporter.resumeTempErrorHandlingPolicy(suspendedPolicy);
/*     */     } 
/*     */   }
/*     */   
/*     */   public void fillInDefaultNonNullness(FieldDeclaration sourceField, Scope scope) {
/* 256 */     if (this.type == null || this.type.isBaseType())
/*     */       return; 
/* 258 */     LookupEnvironment environment = scope.environment();
/* 259 */     if (environment.usesNullTypeAnnotations()) {
/* 260 */       if (!this.type.acceptsNonNullDefault())
/*     */         return; 
/* 262 */       if ((this.type.tagBits & 0x180000000000000L) == 0L) {
/* 263 */         this.type = environment.createAnnotatedType(this.type, new AnnotationBinding[] { environment.getNonNullAnnotation() });
/* 264 */       } else if ((this.type.tagBits & 0x100000000000000L) != 0L) {
/* 265 */         scope.problemReporter().nullAnnotationIsRedundant(sourceField);
/*     */       }
/*     */     
/* 268 */     } else if ((this.tagBits & 0x180000000000000L) == 0L) {
/* 269 */       this.tagBits |= 0x100000000000000L;
/* 270 */     } else if ((this.tagBits & 0x100000000000000L) != 0L) {
/* 271 */       scope.problemReporter().nullAnnotationIsRedundant(sourceField);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public char[] genericSignature() {
/* 280 */     if ((this.modifiers & 0x40000000) == 0) return null; 
/* 281 */     return this.type.genericTypeSignature();
/*     */   }
/*     */   public final int getAccessFlags() {
/* 284 */     return this.modifiers & 0xFFFF;
/*     */   }
/*     */ 
/*     */   
/*     */   public AnnotationBinding[] getAnnotations() {
/* 289 */     FieldBinding originalField = original();
/* 290 */     ReferenceBinding declaringClassBinding = originalField.declaringClass;
/* 291 */     if (declaringClassBinding == null) {
/* 292 */       return Binding.NO_ANNOTATIONS;
/*     */     }
/* 294 */     return declaringClassBinding.retrieveAnnotations(originalField);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long getAnnotationTagBits() {
/* 304 */     FieldBinding originalField = original();
/* 305 */     if ((originalField.tagBits & 0x200000000L) == 0L && originalField.declaringClass instanceof SourceTypeBinding) {
/* 306 */       ClassScope scope = ((SourceTypeBinding)originalField.declaringClass).scope;
/* 307 */       if (scope == null) {
/* 308 */         this.tagBits |= 0x600000000L;
/* 309 */         return 0L;
/*     */       } 
/* 311 */       TypeDeclaration typeDecl = scope.referenceContext;
/* 312 */       FieldDeclaration fieldDecl = typeDecl.declarationOf(originalField);
/* 313 */       if (fieldDecl != null) {
/* 314 */         MethodScope initializationScope = isStatic() ? typeDecl.staticInitializerScope : typeDecl.initializerScope;
/* 315 */         FieldBinding previousField = initializationScope.initializedField;
/* 316 */         int previousFieldID = initializationScope.lastVisibleFieldID;
/*     */         try {
/* 318 */           initializationScope.initializedField = originalField;
/* 319 */           initializationScope.lastVisibleFieldID = originalField.id;
/* 320 */           ASTNode.resolveAnnotations(initializationScope, fieldDecl.annotations, originalField);
/*     */         } finally {
/* 322 */           initializationScope.initializedField = previousField;
/* 323 */           initializationScope.lastVisibleFieldID = previousFieldID;
/*     */         } 
/*     */       } 
/*     */     } 
/* 327 */     return originalField.tagBits;
/*     */   }
/*     */   
/*     */   public final boolean isDefault() {
/* 331 */     return (!isPublic() && !isProtected() && !isPrivate());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final boolean isDeprecated() {
/* 340 */     return ((this.modifiers & 0x100000) != 0);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public final boolean isPrivate() {
/* 346 */     return ((this.modifiers & 0x2) != 0);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public final boolean isOrEnclosedByPrivateType() {
/* 352 */     if ((this.modifiers & 0x2) != 0)
/* 353 */       return true; 
/* 354 */     return (this.declaringClass != null && this.declaringClass.isOrEnclosedByPrivateType());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public final boolean isProtected() {
/* 360 */     return ((this.modifiers & 0x4) != 0);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public final boolean isPublic() {
/* 366 */     return ((this.modifiers & 0x1) != 0);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public final boolean isStatic() {
/* 372 */     return ((this.modifiers & 0x8) != 0);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public final boolean isSynthetic() {
/* 378 */     return ((this.modifiers & 0x1000) != 0);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public final boolean isTransient() {
/* 384 */     return ((this.modifiers & 0x80) != 0);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public final boolean isUsed() {
/* 390 */     return !((this.modifiers & 0x8000000) == 0 && this.compoundUseFlag <= 0);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public final boolean isUsedOnlyInCompound() {
/* 396 */     return ((this.modifiers & 0x8000000) == 0 && this.compoundUseFlag > 0);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public final boolean isViewedAsDeprecated() {
/* 402 */     return ((this.modifiers & 0x300000) != 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final boolean isVolatile() {
/* 409 */     return ((this.modifiers & 0x40) != 0);
/*     */   }
/*     */ 
/*     */   
/*     */   public final int kind() {
/* 414 */     return 1;
/*     */   }
/*     */   public boolean isRecordComponent() {
/* 417 */     return (this.declaringClass != null && this.declaringClass.isRecord() && !isStatic() && (
/* 418 */       this.modifiers & 0x1000000) != 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public FieldBinding original() {
/* 426 */     return this;
/*     */   }
/*     */   
/*     */   public void setAnnotations(AnnotationBinding[] annotations, boolean forceStore) {
/* 430 */     this.declaringClass.storeAnnotations(this, annotations, forceStore);
/*     */   }
/*     */   public FieldDeclaration sourceField() {
/*     */     SourceTypeBinding sourceType;
/*     */     try {
/* 435 */       sourceType = (SourceTypeBinding)this.declaringClass;
/* 436 */     } catch (ClassCastException classCastException) {
/* 437 */       return null;
/*     */     } 
/*     */     
/* 440 */     FieldDeclaration[] fields = sourceType.scope.referenceContext.fields;
/* 441 */     if (fields != null)
/* 442 */       for (int i = fields.length; --i >= 0;) {
/* 443 */         if (this == (fields[i]).binding)
/* 444 */           return fields[i]; 
/*     */       }  
/* 446 */     return null;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\lookup\FieldBinding.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */