/*     */ package org.eclipse.jdt.internal.compiler.impl;
/*     */ 
/*     */ import org.eclipse.jdt.internal.compiler.lookup.TypeConstants;
/*     */ import org.eclipse.jdt.internal.compiler.util.Messages;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public enum JavaFeature
/*     */ {
/*  36 */   SWITCH_EXPRESSIONS(3801088L, 
/*  37 */     Messages.bind(Messages.switch_expression), 
/*  38 */     new char[][] { TypeConstants.YIELD
/*  39 */     }, false),
/*     */   
/*  41 */   TEXT_BLOCKS(3866624L, 
/*  42 */     Messages.bind(Messages.text_block), 
/*  43 */     new char[0][], 
/*  44 */     false),
/*     */   
/*  46 */   PATTERN_MATCHING_IN_INSTANCEOF(3932160L, 
/*  47 */     Messages.bind(Messages.pattern_matching_instanceof), 
/*  48 */     new char[0][], 
/*  49 */     false),
/*     */   
/*  51 */   RECORDS(3932160L, 
/*  52 */     Messages.bind(Messages.records), 
/*  53 */     new char[][] { TypeConstants.RECORD_RESTRICTED_IDENTIFIER
/*  54 */     }, false),
/*     */   
/*  56 */   SEALED_CLASSES(3997696L, 
/*  57 */     Messages.bind(Messages.sealed_types), 
/*  58 */     new char[][] { TypeConstants.SEALED, TypeConstants.PERMITS
/*  59 */     }, false),
/*  60 */   PATTERN_MATCHING_IN_SWITCH(4194304L, 
/*  61 */     Messages.bind(Messages.pattern_matching_switch), 
/*  62 */     new char[0][], 
/*  63 */     true),
/*  64 */   RECORD_PATTERNS(4194304L, 
/*  65 */     Messages.bind(Messages.record_patterns), 
/*  66 */     new char[0][], 
/*  67 */     true);
/*     */   
/*     */   final long compliance;
/*     */   
/*     */   final String name;
/*     */   final boolean isPreview;
/*     */   char[][] restrictedKeywords;
/*     */   
/*     */   public boolean isPreview() {
/*  76 */     return this.isPreview;
/*     */   }
/*     */   public String getName() {
/*  79 */     return this.name;
/*     */   }
/*     */   public long getCompliance() {
/*  82 */     return this.compliance;
/*     */   }
/*     */   public char[][] getRestrictedKeywords() {
/*  85 */     return this.restrictedKeywords;
/*     */   }
/*     */   public boolean isSupported(CompilerOptions options) {
/*  88 */     if (this.isPreview)
/*  89 */       return options.enablePreviewFeatures; 
/*  90 */     return (getCompliance() <= options.sourceLevel);
/*     */   }
/*     */   public boolean isSupported(long comp, boolean preview) {
/*  93 */     if (this.isPreview)
/*  94 */       return preview; 
/*  95 */     return (getCompliance() <= comp);
/*     */   }
/*     */   
/*     */   JavaFeature(long compliance, String name, char[][] restrictedKeywords, boolean isPreview) {
/*  99 */     this.compliance = compliance;
/* 100 */     this.name = name;
/* 101 */     this.isPreview = isPreview;
/* 102 */     this.restrictedKeywords = restrictedKeywords;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\impl\JavaFeature.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */