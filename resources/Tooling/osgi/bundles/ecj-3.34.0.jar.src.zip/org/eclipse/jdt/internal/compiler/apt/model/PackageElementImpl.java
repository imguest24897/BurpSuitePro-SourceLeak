/*     */ package org.eclipse.jdt.internal.compiler.apt.model;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import javax.lang.model.element.Element;
/*     */ import javax.lang.model.element.ElementKind;
/*     */ import javax.lang.model.element.ElementVisitor;
/*     */ import javax.lang.model.element.Name;
/*     */ import javax.lang.model.element.PackageElement;
/*     */ import org.eclipse.jdt.core.compiler.CharOperation;
/*     */ import org.eclipse.jdt.internal.compiler.apt.dispatch.BaseProcessingEnvImpl;
/*     */ import org.eclipse.jdt.internal.compiler.batch.FileSystem;
/*     */ import org.eclipse.jdt.internal.compiler.env.INameEnvironment;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.AnnotationBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.Binding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.LookupEnvironment;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.ModuleBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.PackageBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.ReferenceBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.TypeConstants;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PackageElementImpl
/*     */   extends ElementImpl
/*     */   implements PackageElement
/*     */ {
/*     */   PackageElementImpl(BaseProcessingEnvImpl env, PackageBinding binding) {
/*  48 */     super(env, (Binding)binding);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public <R, P> R accept(ElementVisitor<R, P> v, P p) {
/*  54 */     return v.visitPackage(this, p);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected AnnotationBinding[] getAnnotationBindings() {
/*  60 */     PackageBinding packageBinding = (PackageBinding)this._binding;
/*  61 */     char[][] compoundName = CharOperation.arrayConcat(packageBinding.compoundName, TypeConstants.PACKAGE_INFO_NAME);
/*  62 */     ReferenceBinding type = packageBinding.environment.getType(compoundName);
/*  63 */     AnnotationBinding[] annotations = null;
/*  64 */     if (type != null && type.isValidBinding()) {
/*  65 */       annotations = type.getAnnotations();
/*     */     }
/*  67 */     return annotations;
/*     */   }
/*     */ 
/*     */   
/*     */   public List<? extends Element> getEnclosedElements() {
/*  72 */     PackageBinding binding = (PackageBinding)this._binding;
/*  73 */     LookupEnvironment environment = binding.environment;
/*  74 */     char[][][] typeNames = null;
/*  75 */     INameEnvironment nameEnvironment = binding.environment.nameEnvironment;
/*  76 */     if (nameEnvironment instanceof FileSystem) {
/*  77 */       typeNames = ((FileSystem)nameEnvironment).findTypeNames(binding.compoundName);
/*     */     }
/*  79 */     HashSet<Element> set = new HashSet<>();
/*  80 */     Set<ReferenceBinding> types = new HashSet<>();
/*  81 */     if (typeNames != null) {
/*  82 */       byte b; int i; char[][][] arrayOfChar; for (i = (arrayOfChar = typeNames).length, b = 0; b < i; ) { char[][] typeName = arrayOfChar[b];
/*  83 */         if (typeName != null) {
/*  84 */           ReferenceBinding type = environment.getType(typeName);
/*  85 */           if (type != null && !type.isMemberType() && 
/*  86 */             type.isValidBinding()) {
/*  87 */             Element newElement = this._env.getFactory().newElement((Binding)type);
/*  88 */             if (newElement.getKind() != ElementKind.PACKAGE) {
/*  89 */               set.add(newElement);
/*  90 */               types.add(type);
/*     */             } 
/*     */           } 
/*     */         }  b++; }
/*     */     
/*  95 */     }  if (binding.knownTypes != null) {
/*  96 */       ReferenceBinding[] knownTypes = binding.knownTypes.valueTable; byte b; int i; ReferenceBinding[] arrayOfReferenceBinding1;
/*  97 */       for (i = (arrayOfReferenceBinding1 = knownTypes).length, b = 0; b < i; ) { ReferenceBinding referenceBinding = arrayOfReferenceBinding1[b];
/*  98 */         if (referenceBinding != null && referenceBinding.isValidBinding() && referenceBinding.enclosingType() == null && 
/*  99 */           !types.contains(referenceBinding)) {
/* 100 */           Element newElement = this._env.getFactory().newElement((Binding)referenceBinding);
/* 101 */           if (newElement.getKind() != ElementKind.PACKAGE)
/* 102 */             set.add(newElement); 
/*     */         } 
/*     */         b++; }
/*     */     
/*     */     } 
/* 107 */     ArrayList<Element> list = new ArrayList<>(set.size());
/* 108 */     list.addAll(set);
/* 109 */     return Collections.unmodifiableList(list);
/*     */   }
/*     */ 
/*     */   
/*     */   public Element getEnclosingElement() {
/* 114 */     if ((this._env.getCompiler()).options.sourceLevel < 3473408L) {
/* 115 */       return null;
/*     */     }
/* 117 */     PackageBinding pBinding = (PackageBinding)this._binding;
/* 118 */     ModuleBinding module = pBinding.enclosingModule;
/* 119 */     if (module == null)
/* 120 */       return null; 
/* 121 */     return new ModuleElementImpl(this._env, module);
/*     */   }
/*     */ 
/*     */   
/*     */   public ElementKind getKind() {
/* 126 */     return ElementKind.PACKAGE;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   PackageElement getPackage() {
/* 132 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public Name getSimpleName() {
/* 137 */     char[][] compoundName = ((PackageBinding)this._binding).compoundName;
/* 138 */     int length = compoundName.length;
/* 139 */     if (length == 0) {
/* 140 */       return new NameImpl(CharOperation.NO_CHAR);
/*     */     }
/* 142 */     return new NameImpl(compoundName[length - 1]);
/*     */   }
/*     */ 
/*     */   
/*     */   public Name getQualifiedName() {
/* 147 */     return new NameImpl(CharOperation.concatWith(((PackageBinding)this._binding).compoundName, '.'));
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isUnnamed() {
/* 152 */     PackageBinding binding = (PackageBinding)this._binding;
/* 153 */     return (binding.compoundName == CharOperation.NO_CHAR_CHAR);
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\apt\model\PackageElementImpl.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */