/*      */ package org.eclipse.jdt.internal.compiler.ast;
/*      */ 
/*      */ import java.util.ArrayList;
/*      */ import java.util.Arrays;
/*      */ import java.util.HashMap;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import org.eclipse.jdt.core.compiler.CharOperation;
/*      */ import org.eclipse.jdt.internal.compiler.ASTVisitor;
/*      */ import org.eclipse.jdt.internal.compiler.env.AccessRestriction;
/*      */ import org.eclipse.jdt.internal.compiler.lookup.AnnotationBinding;
/*      */ import org.eclipse.jdt.internal.compiler.lookup.ArrayBinding;
/*      */ import org.eclipse.jdt.internal.compiler.lookup.Binding;
/*      */ import org.eclipse.jdt.internal.compiler.lookup.BlockScope;
/*      */ import org.eclipse.jdt.internal.compiler.lookup.FieldBinding;
/*      */ import org.eclipse.jdt.internal.compiler.lookup.InferenceContext18;
/*      */ import org.eclipse.jdt.internal.compiler.lookup.InvocationSite;
/*      */ import org.eclipse.jdt.internal.compiler.lookup.LocalVariableBinding;
/*      */ import org.eclipse.jdt.internal.compiler.lookup.LookupEnvironment;
/*      */ import org.eclipse.jdt.internal.compiler.lookup.MethodBinding;
/*      */ import org.eclipse.jdt.internal.compiler.lookup.ModuleBinding;
/*      */ import org.eclipse.jdt.internal.compiler.lookup.PackageBinding;
/*      */ import org.eclipse.jdt.internal.compiler.lookup.ParameterizedGenericMethodBinding;
/*      */ import org.eclipse.jdt.internal.compiler.lookup.ParameterizedMethodBinding;
/*      */ import org.eclipse.jdt.internal.compiler.lookup.ParameterizedTypeBinding;
/*      */ import org.eclipse.jdt.internal.compiler.lookup.ProblemMethodBinding;
/*      */ import org.eclipse.jdt.internal.compiler.lookup.RecordComponentBinding;
/*      */ import org.eclipse.jdt.internal.compiler.lookup.ReferenceBinding;
/*      */ import org.eclipse.jdt.internal.compiler.lookup.Scope;
/*      */ import org.eclipse.jdt.internal.compiler.lookup.SourceTypeBinding;
/*      */ import org.eclipse.jdt.internal.compiler.lookup.TypeBinding;
/*      */ import org.eclipse.jdt.internal.compiler.lookup.TypeConstants;
/*      */ import org.eclipse.jdt.internal.compiler.lookup.TypeIds;
/*      */ import org.eclipse.jdt.internal.compiler.lookup.TypeVariableBinding;
/*      */ import org.eclipse.jdt.internal.compiler.lookup.VariableBinding;
/*      */ import org.eclipse.jdt.internal.compiler.lookup.WildcardBinding;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public abstract class ASTNode
/*      */   implements TypeConstants, TypeIds
/*      */ {
/*      */   public int sourceStart;
/*      */   public int sourceEnd;
/*      */   public static final int Bit1 = 1;
/*      */   public static final int Bit2 = 2;
/*      */   public static final int Bit3 = 4;
/*      */   public static final int Bit4 = 8;
/*      */   public static final int Bit5 = 16;
/*      */   public static final int Bit6 = 32;
/*      */   public static final int Bit7 = 64;
/*      */   public static final int Bit8 = 128;
/*      */   public static final int Bit9 = 256;
/*      */   public static final int Bit10 = 512;
/*      */   public static final int Bit11 = 1024;
/*      */   public static final int Bit12 = 2048;
/*      */   public static final int Bit13 = 4096;
/*      */   public static final int Bit14 = 8192;
/*      */   public static final int Bit15 = 16384;
/*      */   public static final int Bit16 = 32768;
/*      */   public static final int Bit17 = 65536;
/*      */   public static final int Bit18 = 131072;
/*      */   public static final int Bit19 = 262144;
/*      */   public static final int Bit20 = 524288;
/*      */   public static final int Bit21 = 1048576;
/*      */   public static final int Bit22 = 2097152;
/*      */   public static final int Bit23 = 4194304;
/*      */   public static final int Bit24 = 8388608;
/*      */   public static final int Bit25 = 16777216;
/*      */   public static final int Bit26 = 33554432;
/*      */   public static final int Bit27 = 67108864;
/*      */   public static final int Bit28 = 134217728;
/*      */   public static final int Bit29 = 268435456;
/*      */   public static final int Bit30 = 536870912;
/*      */   public static final int Bit31 = 1073741824;
/*      */   public static final int Bit32 = -2147483648;
/*      */   public static final long Bit32L = 2147483648L;
/*      */   public static final long Bit33L = 4294967296L;
/*      */   public static final long Bit34L = 8589934592L;
/*      */   public static final long Bit35L = 17179869184L;
/*      */   public static final long Bit36L = 34359738368L;
/*      */   public static final long Bit37L = 68719476736L;
/*      */   public static final long Bit38L = 137438953472L;
/*      */   public static final long Bit39L = 274877906944L;
/*      */   public static final long Bit40L = 549755813888L;
/*      */   public static final long Bit41L = 1099511627776L;
/*      */   public static final long Bit42L = 2199023255552L;
/*      */   public static final long Bit43L = 4398046511104L;
/*      */   public static final long Bit44L = 8796093022208L;
/*      */   public static final long Bit45L = 17592186044416L;
/*      */   public static final long Bit46L = 35184372088832L;
/*      */   public static final long Bit47L = 70368744177664L;
/*      */   public static final long Bit48L = 140737488355328L;
/*      */   public static final long Bit49L = 281474976710656L;
/*      */   public static final long Bit50L = 562949953421312L;
/*      */   public static final long Bit51L = 1125899906842624L;
/*      */   public static final long Bit52L = 2251799813685248L;
/*      */   public static final long Bit53L = 4503599627370496L;
/*      */   public static final long Bit54L = 9007199254740992L;
/*      */   public static final long Bit55L = 18014398509481984L;
/*      */   public static final long Bit56L = 36028797018963968L;
/*      */   public static final long Bit57L = 72057594037927936L;
/*      */   public static final long Bit58L = 144115188075855872L;
/*      */   public static final long Bit59L = 288230376151711744L;
/*      */   public static final long Bit60L = 576460752303423488L;
/*      */   public static final long Bit61L = 1152921504606846976L;
/*      */   public static final long Bit62L = 2305843009213693952L;
/*      */   public static final long Bit63L = 4611686018427387904L;
/*      */   public static final long Bit64L = -9223372036854775808L;
/*  165 */   public int bits = Integer.MIN_VALUE;
/*      */ 
/*      */   
/*      */   public static final int ReturnTypeIDMASK = 15;
/*      */ 
/*      */   
/*      */   public static final int OperatorSHIFT = 8;
/*      */ 
/*      */   
/*      */   public static final int OperatorMASK = 16128;
/*      */ 
/*      */   
/*      */   public static final int IsReturnedValue = 16;
/*      */ 
/*      */   
/*      */   public static final int UnnecessaryCast = 16384;
/*      */   
/*      */   public static final int DisableUnnecessaryCastCheck = 32;
/*      */   
/*      */   public static final int GenerateCheckcast = 64;
/*      */   
/*      */   public static final int UnsafeCast = 128;
/*      */   
/*      */   public static final int RestrictiveFlagMASK = 7;
/*      */   
/*      */   public static final int IsTypeElided = 2;
/*      */   
/*      */   public static final int IsArgument = 4;
/*      */   
/*      */   public static final int IsLocalDeclarationReachable = 1073741824;
/*      */   
/*      */   public static final int IsForeachElementVariable = 16;
/*      */   
/*      */   public static final int ShadowsOuterLocal = 2097152;
/*      */   
/*      */   public static final int IsAdditionalDeclarator = 4194304;
/*      */   
/*      */   public static final int FirstAssignmentToLocal = 8;
/*      */   
/*      */   public static final int NeedReceiverGenericCast = 262144;
/*      */   
/*      */   public static final int IsImplicitThis = 4;
/*      */   
/*      */   public static final int DepthSHIFT = 5;
/*      */   
/*      */   public static final int DepthMASK = 8160;
/*      */   
/*      */   public static final int IsCapturedOuterLocal = 524288;
/*      */   
/*      */   public static final int IsUsedInPatternGuard = 64;
/*      */   
/*      */   public static final int IsSecretYieldValueUsage = 16;
/*      */   
/*      */   public static final int IsReachable = -2147483648;
/*      */   
/*      */   public static final int LabelUsed = 64;
/*      */   
/*      */   public static final int DocumentedFallthrough = 536870912;
/*      */   
/*      */   public static final int DocumentedCasesOmitted = 1073741824;
/*      */   
/*      */   public static final int IsSubRoutineEscaping = 16384;
/*      */   
/*      */   public static final int IsTryBlockExiting = 536870912;
/*      */   
/*      */   public static final int ContainsAssertion = 1;
/*      */   
/*      */   public static final int IsLocalType = 256;
/*      */   
/*      */   public static final int IsAnonymousType = 512;
/*      */   
/*      */   public static final int IsMemberType = 1024;
/*      */   
/*      */   public static final int HasAbstractMethods = 2048;
/*      */   
/*      */   public static final int IsSecondaryType = 4096;
/*      */   
/*      */   public static final int HasBeenGenerated = 8192;
/*      */   
/*      */   public static final int HasLocalType = 2;
/*      */   
/*      */   public static final int HasBeenResolved = 16;
/*      */   
/*      */   public static final int ParenthesizedSHIFT = 21;
/*      */   
/*      */   public static final int ParenthesizedMASK = 534773760;
/*      */   
/*      */   public static final int IgnoreNoEffectAssignCheck = 536870912;
/*      */   
/*      */   public static final int IsStrictlyAssigned = 8192;
/*      */   
/*      */   public static final int IsCompoundAssigned = 65536;
/*      */   
/*      */   public static final int DiscardEnclosingInstance = 8192;
/*      */   
/*      */   public static final int Unchecked = 65536;
/*      */   
/*      */   public static final int ResolveJavadoc = 65536;
/*      */   
/*      */   public static final int IsUsefulEmptyStatement = 1;
/*      */   
/*      */   public static final int UndocumentedEmptyBlock = 8;
/*      */   
/*      */   public static final int OverridingMethodWithSupercall = 16;
/*      */   
/*      */   public static final int CanBeStatic = 256;
/*      */   
/*      */   public static final int ErrorInSignature = 32;
/*      */   
/*      */   public static final int NeedFreeReturn = 64;
/*      */   
/*      */   public static final int IsDefaultConstructor = 128;
/*      */   
/*      */   public static final int IsCanonicalConstructor = 512;
/*      */   
/*      */   public static final int IsImplicit = 1024;
/*      */   
/*      */   public static final int HasAllMethodBodies = 16;
/*      */   
/*      */   public static final int IsImplicitUnit = 1;
/*      */   
/*      */   public static final int InsideJavadoc = 32768;
/*      */   
/*      */   public static final int SuperAccess = 16384;
/*      */   
/*      */   public static final int Empty = 262144;
/*      */   
/*      */   public static final int IsElseIfStatement = 536870912;
/*      */   
/*      */   public static final int ThenExit = 1073741824;
/*      */   
/*      */   public static final int IsElseStatementUnreachable = 128;
/*      */   
/*      */   public static final int IsThenStatementUnreachable = 256;
/*      */   
/*      */   public static final int IsSuperType = 16;
/*      */   
/*      */   public static final int IsVarArgs = 16384;
/*      */   
/*      */   public static final int IgnoreRawTypeCheck = 1073741824;
/*      */   
/*      */   public static final int IsAnnotationDefaultValue = 1;
/*      */   
/*      */   public static final int IsNonNull = 131072;
/*      */   
/*      */   public static final int NeededScope = 536870912;
/*      */   
/*      */   public static final int OnDemand = 131072;
/*      */   
/*      */   public static final int Used = 2;
/*      */   
/*      */   public static final int inModule = 262144;
/*      */   
/*      */   public static final int DidResolve = 262144;
/*      */   
/*      */   public static final int IsAnySubRoutineEscaping = 536870912;
/*      */   
/*      */   public static final int IsSynchronized = 1073741824;
/*      */   
/*      */   public static final int BlockExit = 536870912;
/*      */   
/*      */   public static final int IsRecovered = 32;
/*      */   
/*      */   public static final int HasSyntaxErrors = 524288;
/*      */   
/*      */   public static final int INVOCATION_ARGUMENT_OK = 0;
/*      */   
/*      */   public static final int INVOCATION_ARGUMENT_UNCHECKED = 1;
/*      */   
/*      */   public static final int INVOCATION_ARGUMENT_WILDCARD = 2;
/*      */   
/*      */   public static final int HasTypeAnnotations = 1048576;
/*      */   
/*      */   public static final int IsUnionType = 536870912;
/*      */   
/*      */   public static final int IsDiamond = 524288;
/*      */   
/*      */   public static final int InsideExpressionStatement = 1048576;
/*      */   
/*      */   public static final int IsSynthetic = 64;
/*      */   
/*      */   public static final int HasFunctionalInterfaceTypes = 2097152;
/*      */   
/*  348 */   public static final Argument[] NO_ARGUMENTS = new Argument[0];
/*  349 */   public static final RecordComponent[] NO_RECORD_COMPONENTS = new RecordComponent[0];
/*  350 */   public static final TypePattern[] NO_TYPE_PATTERNS = new TypePattern[0];
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static int checkInvocationArgument(BlockScope scope, Expression argument, TypeBinding parameterType, TypeBinding argumentType, TypeBinding originalParameterType) {
/*  357 */     argument.computeConversion((Scope)scope, parameterType, argumentType);
/*  358 */     if (argument instanceof AllocationExpression) {
/*  359 */       AllocationExpression allocExp = (AllocationExpression)argument;
/*      */       
/*  361 */       if (allocExp.typeExpected == null) {
/*  362 */         boolean isDiamond = (allocExp.type != null && (allocExp.type.bits & 0x80000) != 0);
/*  363 */         allocExp.typeExpected = parameterType;
/*  364 */         if (!isDiamond && allocExp.resolvedType.isParameterizedTypeWithActualArguments()) {
/*  365 */           ParameterizedTypeBinding pbinding = (ParameterizedTypeBinding)allocExp.resolvedType;
/*  366 */           scope.problemReporter().redundantSpecificationOfTypeArguments(allocExp.type, pbinding.arguments);
/*      */         } 
/*      */       } 
/*      */     } 
/*  370 */     if (argumentType != TypeBinding.NULL && parameterType.kind() == 516) {
/*  371 */       WildcardBinding wildcard = (WildcardBinding)parameterType;
/*  372 */       if (wildcard.boundKind != 2) {
/*  373 */         return 2;
/*      */       }
/*      */     } 
/*  376 */     TypeBinding checkedParameterType = parameterType;
/*  377 */     if (TypeBinding.notEquals(argumentType, checkedParameterType) && argumentType.needsUncheckedConversion(checkedParameterType)) {
/*  378 */       scope.problemReporter().unsafeTypeConversion(argument, argumentType, checkedParameterType);
/*  379 */       return 1;
/*      */     } 
/*  381 */     return 0;
/*      */   }
/*      */   public static boolean checkInvocationArguments(BlockScope scope, Expression receiver, TypeBinding receiverType, MethodBinding method, Expression[] arguments, TypeBinding[] argumentTypes, boolean argsContainCast, InvocationSite invocationSite) {
/*  384 */     long sourceLevel = (scope.compilerOptions()).sourceLevel;
/*  385 */     boolean is1_7 = (sourceLevel >= 3342336L);
/*  386 */     TypeBinding[] params = method.parameters;
/*  387 */     int paramLength = params.length;
/*  388 */     boolean isRawMemberInvocation = (!method.isStatic() && 
/*  389 */       !receiverType.isUnboundWildcard() && 
/*  390 */       method.declaringClass.isRawType() && 
/*  391 */       method.hasSubstitutedParameters());
/*      */     
/*  393 */     boolean uncheckedBoundCheck = ((method.tagBits & 0x100L) != 0L);
/*  394 */     MethodBinding rawOriginalGenericMethod = null;
/*  395 */     if (!isRawMemberInvocation && 
/*  396 */       method instanceof ParameterizedGenericMethodBinding) {
/*  397 */       ParameterizedGenericMethodBinding paramMethod = (ParameterizedGenericMethodBinding)method;
/*  398 */       if (paramMethod.isRaw && method.hasSubstitutedParameters()) {
/*  399 */         rawOriginalGenericMethod = method.original();
/*      */       }
/*      */     } 
/*      */     
/*  403 */     int invocationStatus = 0;
/*  404 */     if (arguments == null) {
/*  405 */       if (method.isVarargs()) {
/*  406 */         TypeBinding parameterType = ((ArrayBinding)params[paramLength - 1]).elementsType();
/*  407 */         if (!parameterType.isReifiable() && (
/*  408 */           !is1_7 || (method.tagBits & 0x8000000000000L) == 0L)) {
/*  409 */           scope.problemReporter().unsafeGenericArrayForVarargs(parameterType, (ASTNode)invocationSite);
/*      */         }
/*      */       } 
/*      */     } else {
/*  413 */       if (method.isVarargs())
/*      */       
/*  415 */       { int lastIndex = paramLength - 1;
/*  416 */         for (int i = 0; i < lastIndex; i++) {
/*  417 */           TypeBinding originalRawParam = (rawOriginalGenericMethod == null) ? null : rawOriginalGenericMethod.parameters[i];
/*  418 */           invocationStatus |= checkInvocationArgument(scope, arguments[i], params[i], argumentTypes[i], originalRawParam);
/*      */         } 
/*  420 */         int argLength = arguments.length;
/*  421 */         if (lastIndex <= argLength) {
/*  422 */           TypeBinding parameterType = params[lastIndex];
/*  423 */           TypeBinding originalRawParam = null;
/*      */           
/*  425 */           if (paramLength != argLength || parameterType.dimensions() != argumentTypes[lastIndex].dimensions()) {
/*  426 */             parameterType = ((ArrayBinding)parameterType).elementsType();
/*  427 */             if (!parameterType.isReifiable() && (
/*  428 */               !is1_7 || (method.tagBits & 0x8000000000000L) == 0L)) {
/*  429 */               scope.problemReporter().unsafeGenericArrayForVarargs(parameterType, (ASTNode)invocationSite);
/*      */             }
/*  431 */             originalRawParam = (rawOriginalGenericMethod == null) ? null : ((ArrayBinding)rawOriginalGenericMethod.parameters[lastIndex]).elementsType();
/*      */           } 
/*  433 */           for (int j = lastIndex; j < argLength; j++) {
/*  434 */             invocationStatus |= checkInvocationArgument(scope, arguments[j], parameterType, argumentTypes[j], originalRawParam);
/*      */           }
/*      */         } 
/*  437 */         if (paramLength == argLength) {
/*  438 */           int varargsIndex = paramLength - 1;
/*  439 */           ArrayBinding varargsType = (ArrayBinding)params[varargsIndex];
/*  440 */           TypeBinding lastArgType = argumentTypes[varargsIndex];
/*      */           
/*  442 */           if (lastArgType == TypeBinding.NULL)
/*  443 */           { if (!varargsType.leafComponentType().isBaseType() || varargsType.dimensions() != 1)
/*  444 */               scope.problemReporter().varargsArgumentNeedCast(method, lastArgType, invocationSite);  }
/*  445 */           else { int dimensions; if (varargsType.dimensions <= (dimensions = lastArgType.dimensions())) {
/*  446 */               if (lastArgType.leafComponentType().isBaseType()) {
/*  447 */                 dimensions--;
/*      */               }
/*  449 */               if (varargsType.dimensions < dimensions) {
/*  450 */                 scope.problemReporter().varargsArgumentNeedCast(method, lastArgType, invocationSite);
/*  451 */               } else if (varargsType.dimensions == dimensions && 
/*  452 */                 TypeBinding.notEquals(lastArgType, (TypeBinding)varargsType) && 
/*  453 */                 TypeBinding.notEquals(lastArgType.leafComponentType().erasure(), varargsType.leafComponentType.erasure()) && 
/*  454 */                 lastArgType.isCompatibleWith(varargsType.elementsType()) && 
/*  455 */                 lastArgType.isCompatibleWith((TypeBinding)varargsType)) {
/*  456 */                 scope.problemReporter().varargsArgumentNeedCast(method, lastArgType, invocationSite);
/*      */               } 
/*      */             }  }
/*      */         
/*      */         }  }
/*  461 */       else { for (int i = 0; i < paramLength; i++) {
/*  462 */           TypeBinding originalRawParam = (rawOriginalGenericMethod == null) ? null : rawOriginalGenericMethod.parameters[i];
/*  463 */           invocationStatus |= checkInvocationArgument(scope, arguments[i], params[i], argumentTypes[i], originalRawParam);
/*      */         }  }
/*      */       
/*  466 */       if (argsContainCast) {
/*  467 */         CastExpression.checkNeedForArgumentCasts(scope, receiver, receiverType, method, arguments, argumentTypes, invocationSite);
/*      */       }
/*      */     } 
/*  470 */     if ((invocationStatus & 0x2) != 0) {
/*  471 */       scope.problemReporter().wildcardInvocation((ASTNode)invocationSite, receiverType, method, argumentTypes);
/*  472 */     } else if (!method.isStatic() && !receiverType.isUnboundWildcard() && method.declaringClass.isRawType() && method.hasSubstitutedParameters()) {
/*  473 */       if ((scope.compilerOptions()).reportUnavoidableGenericTypeProblems || receiver == null || !receiver.forcedToBeRaw(scope.referenceContext())) {
/*  474 */         scope.problemReporter().unsafeRawInvocation((ASTNode)invocationSite, method);
/*      */       }
/*  476 */     } else if (rawOriginalGenericMethod != null || 
/*  477 */       uncheckedBoundCheck || (
/*  478 */       invocationStatus & 0x1) != 0) {
/*  479 */       if (method instanceof ParameterizedGenericMethodBinding) {
/*  480 */         scope.problemReporter().unsafeRawGenericMethodInvocation((ASTNode)invocationSite, method, argumentTypes);
/*  481 */         return true;
/*      */       } 
/*  483 */       if (sourceLevel >= 3407872L)
/*  484 */         return true; 
/*      */     } 
/*  486 */     return false;
/*      */   }
/*      */   public ASTNode concreteStatement() {
/*  489 */     return this;
/*      */   }
/*      */   private void reportPreviewAPI(Scope scope, long modifiers) {
/*  492 */     if ((scope.compilerOptions()).enablePreviewFeatures)
/*      */       return; 
/*  494 */     if ((modifiers & 0x180000000L) == 6442450944L)
/*  495 */       scope.problemReporter().previewAPIUsed(this.sourceStart, this.sourceEnd, 
/*  496 */           ((modifiers & 0x400L) != 0L)); 
/*      */   }
/*      */   
/*      */   public final boolean isFieldUseDeprecated(FieldBinding field, Scope scope, int filteredBits) {
/*  500 */     if ((this.bits & 0x8000) == 0 && (
/*  501 */       filteredBits & 0x2000) == 0 && 
/*  502 */       field.isOrEnclosedByPrivateType() && 
/*  503 */       !scope.isDefinedInField(field))
/*      */     {
/*  505 */       if ((filteredBits & 0x10000) != 0) {
/*      */         
/*  507 */         (field.original()).compoundUseFlag++;
/*      */       } else {
/*  509 */         (field.original()).modifiers |= 0x8000000;
/*      */       }  } 
/*  511 */     reportPreviewAPI(scope, field.tagBits);
/*      */     
/*  513 */     if ((field.modifiers & 0x40000) != 0) {
/*  514 */       ModuleBinding module = field.declaringClass.module();
/*  515 */       LookupEnvironment env = (module == null) ? scope.environment() : module.environment;
/*  516 */       AccessRestriction restriction = 
/*  517 */         env.getAccessRestriction(field.declaringClass.erasure());
/*  518 */       if (restriction != null) {
/*  519 */         scope.problemReporter().forbiddenReference(field, this, 
/*  520 */             restriction.classpathEntryType, restriction.classpathEntryName, 
/*  521 */             restriction.getProblemId());
/*      */       }
/*      */     } 
/*      */     
/*  525 */     if (!field.isViewedAsDeprecated()) return false;
/*      */ 
/*      */     
/*  528 */     if (scope.isDefinedInSameUnit(field.declaringClass)) return false;
/*      */ 
/*      */     
/*  531 */     if (!(scope.compilerOptions()).reportDeprecationInsideDeprecatedCode && scope.isInsideDeprecatedCode()) return false; 
/*  532 */     return true;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isImplicitThis() {
/*  537 */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean receiverIsImplicitThis() {
/*  542 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final boolean isMethodUseDeprecated(MethodBinding method, Scope scope, boolean isExplicitUse, InvocationSite invocation) {
/*  551 */     reportPreviewAPI(scope, method.tagBits);
/*      */ 
/*      */     
/*  554 */     if ((this.bits & 0x8000) == 0 && method.isOrEnclosedByPrivateType() && !scope.isDefinedInMethod(method))
/*      */     {
/*  556 */       (method.original()).modifiers |= 0x8000000;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*  561 */     if (isExplicitUse && (method.modifiers & 0x40000) != 0) {
/*      */ 
/*      */       
/*  564 */       ModuleBinding module = method.declaringClass.module();
/*  565 */       LookupEnvironment env = (module == null) ? scope.environment() : module.environment;
/*  566 */       AccessRestriction restriction = 
/*  567 */         env.getAccessRestriction(method.declaringClass.erasure());
/*  568 */       if (restriction != null) {
/*  569 */         scope.problemReporter().forbiddenReference(method, invocation, 
/*  570 */             restriction.classpathEntryType, restriction.classpathEntryName, 
/*  571 */             restriction.getProblemId());
/*      */       }
/*      */     } 
/*      */     
/*  575 */     if (!method.isViewedAsDeprecated()) return false;
/*      */ 
/*      */     
/*  578 */     if (scope.isDefinedInSameUnit(method.declaringClass)) return false;
/*      */ 
/*      */     
/*  581 */     if (!isExplicitUse && (
/*  582 */       method.modifiers & 0x100000) == 0) {
/*  583 */       return false;
/*      */     }
/*      */ 
/*      */     
/*  587 */     if (!(scope.compilerOptions()).reportDeprecationInsideDeprecatedCode && scope.isInsideDeprecatedCode()) return false; 
/*  588 */     return true;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isSuper() {
/*  593 */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isQualifiedSuper() {
/*  598 */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isThis() {
/*  603 */     return false;
/*      */   }
/*      */   
/*      */   public boolean isUnqualifiedSuper() {
/*  607 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final boolean isTypeUseDeprecated(TypeBinding type, Scope scope) {
/*  615 */     if (type.isArrayType()) {
/*  616 */       type = ((ArrayBinding)type).leafComponentType;
/*      */     }
/*  618 */     if (type.isBaseType()) {
/*  619 */       return false;
/*      */     }
/*  621 */     ReferenceBinding refType = (ReferenceBinding)type;
/*      */ 
/*      */     
/*  624 */     if ((this.bits & 0x8000) == 0 && refType instanceof TypeVariableBinding) {
/*  625 */       refType.modifiers |= 0x8000000;
/*      */     }
/*      */     
/*  628 */     if ((this.bits & 0x8000) == 0 && refType.isOrEnclosedByPrivateType() && !scope.isDefinedInType(refType))
/*      */     {
/*  630 */       ((ReferenceBinding)refType.erasure()).modifiers |= 0x8000000;
/*      */     }
/*  632 */     reportPreviewAPI(scope, type.extendedTagBits);
/*  633 */     if (refType.hasRestrictedAccess()) {
/*  634 */       ModuleBinding module = refType.module();
/*  635 */       LookupEnvironment env = (module == null) ? scope.environment() : module.environment;
/*  636 */       AccessRestriction restriction = env.getAccessRestriction(type.erasure());
/*  637 */       if (restriction != null) {
/*  638 */         scope.problemReporter().forbiddenReference(type, this, restriction.classpathEntryType, 
/*  639 */             restriction.classpathEntryName, restriction.getProblemId());
/*      */       }
/*      */     } 
/*      */ 
/*      */     
/*  644 */     refType.initializeDeprecatedAnnotationTagBits();
/*      */     
/*  646 */     if (!refType.isViewedAsDeprecated()) return false;
/*      */ 
/*      */     
/*  649 */     if (scope.isDefinedInSameUnit(refType)) return false;
/*      */ 
/*      */     
/*  652 */     if (!(scope.compilerOptions()).reportDeprecationInsideDeprecatedCode && scope.isInsideDeprecatedCode()) return false; 
/*  653 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isType() {
/*  663 */     return false;
/*      */   }
/*      */   
/*      */   public abstract StringBuffer print(int paramInt, StringBuffer paramStringBuffer);
/*      */   
/*      */   public static StringBuffer printAnnotations(Annotation[] annotations, StringBuffer output) {
/*  669 */     int length = annotations.length;
/*  670 */     for (int i = 0; i < length; i++) {
/*  671 */       if (i > 0) {
/*  672 */         output.append(" ");
/*      */       }
/*  674 */       Annotation annotation2 = annotations[i];
/*  675 */       if (annotation2 != null) {
/*  676 */         annotation2.print(0, output);
/*      */       } else {
/*  678 */         output.append('?');
/*      */       } 
/*      */     } 
/*  681 */     return output;
/*      */   }
/*      */ 
/*      */   
/*      */   public static StringBuffer printIndent(int indent, StringBuffer output) {
/*  686 */     for (int i = indent; i > 0; ) { output.append("  "); i--; }
/*  687 */      return output;
/*      */   }
/*      */ 
/*      */   
/*      */   public static StringBuffer printModifiers(int modifiers, StringBuffer output) {
/*  692 */     if ((modifiers & 0x1) != 0)
/*  693 */       output.append("public "); 
/*  694 */     if ((modifiers & 0x2) != 0)
/*  695 */       output.append("private "); 
/*  696 */     if ((modifiers & 0x4) != 0)
/*  697 */       output.append("protected "); 
/*  698 */     if ((modifiers & 0x8) != 0)
/*  699 */       output.append("static "); 
/*  700 */     if ((modifiers & 0x10) != 0)
/*  701 */       output.append("final "); 
/*  702 */     if ((modifiers & 0x20) != 0)
/*  703 */       output.append("synchronized "); 
/*  704 */     if ((modifiers & 0x40) != 0)
/*  705 */       output.append("volatile "); 
/*  706 */     if ((modifiers & 0x80) != 0)
/*  707 */       output.append("transient "); 
/*  708 */     if ((modifiers & 0x100) != 0)
/*  709 */       output.append("native "); 
/*  710 */     if ((modifiers & 0x400) != 0)
/*  711 */       output.append("abstract "); 
/*  712 */     if ((modifiers & 0x10000) != 0)
/*  713 */       output.append("default "); 
/*  714 */     if ((modifiers & 0x4000000) != 0)
/*  715 */       output.append("non-sealed "); 
/*  716 */     if ((modifiers & 0x10000000) != 0)
/*  717 */       output.append("sealed "); 
/*  718 */     return output;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static MethodBinding resolvePolyExpressionArguments(Invocation invocation, MethodBinding method, TypeBinding[] argumentTypes, BlockScope scope) {
/*  733 */     MethodBinding candidateMethod = method.isValidBinding() ? method : ((method instanceof ProblemMethodBinding) ? ((ProblemMethodBinding)method).closestMatch : null);
/*  734 */     if (candidateMethod == null)
/*  735 */       return method; 
/*  736 */     ProblemMethodBinding problemMethod = null;
/*  737 */     boolean variableArity = candidateMethod.isVarargs();
/*  738 */     TypeBinding[] parameters = candidateMethod.parameters;
/*  739 */     Expression[] arguments = invocation.arguments();
/*  740 */     if (variableArity && arguments != null && parameters.length == arguments.length && 
/*  741 */       arguments[arguments.length - 1].isCompatibleWith(parameters[parameters.length - 1], (Scope)scope)) {
/*  742 */       variableArity = false;
/*      */     }
/*      */     
/*  745 */     for (int i = 0, length = (arguments == null) ? 0 : arguments.length; i < length; i++) {
/*  746 */       Expression argument = arguments[i];
/*  747 */       TypeBinding parameterType = InferenceContext18.getParameter(parameters, i, variableArity);
/*  748 */       if (parameterType == null)
/*      */         continue; 
/*  750 */       if (argumentTypes[i] != null && argumentTypes[i].isPolyType()) {
/*  751 */         TypeBinding updatedArgumentType; argument.setExpectedType(parameterType);
/*      */         
/*  753 */         if (argument instanceof LambdaExpression) {
/*  754 */           LambdaExpression lambda = (LambdaExpression)argument;
/*      */           
/*  756 */           boolean skipKosherCheck = (method.problemId() == 3);
/*  757 */           updatedArgumentType = lambda.resolveType(scope, skipKosherCheck);
/*      */           
/*  759 */           if (lambda.hasErrors() || lambda.hasDescripterProblem) {
/*      */             continue;
/*      */           }
/*      */           
/*  763 */           lambda.updateLocalTypesInMethod(candidateMethod);
/*  764 */           parameterType = InferenceContext18.getParameter(parameters, i, variableArity);
/*  765 */           if (!lambda.isCompatibleWith(parameterType, (Scope)scope)) {
/*  766 */             if (method.isValidBinding() && problemMethod == null) {
/*  767 */               TypeBinding[] originalArguments = Arrays.<TypeBinding>copyOf(argumentTypes, argumentTypes.length);
/*  768 */               if (lambda.reportShapeError(parameterType, (Scope)scope)) {
/*  769 */                 problemMethod = new ProblemMethodBinding(candidateMethod, method.selector, originalArguments, 31);
/*      */               } else {
/*  771 */                 problemMethod = new ProblemMethodBinding(candidateMethod, method.selector, originalArguments, 1);
/*      */               } 
/*      */             } 
/*      */             continue;
/*      */           } 
/*      */         } else {
/*  777 */           updatedArgumentType = argument.resolveType(scope);
/*      */         } 
/*  779 */         if (updatedArgumentType != null && updatedArgumentType.kind() != 65540) {
/*  780 */           argumentTypes[i] = updatedArgumentType;
/*  781 */           if (candidateMethod.isPolymorphic())
/*  782 */             candidateMethod.parameters[i] = updatedArgumentType; 
/*      */         } 
/*      */       }  continue;
/*      */     } 
/*  786 */     if (method.returnType instanceof ReferenceBinding) {
/*  787 */       scope.referenceCompilationUnit().updateLocalTypesInMethod(method);
/*      */     }
/*  789 */     if (method instanceof ParameterizedGenericMethodBinding) {
/*  790 */       InferenceContext18 ic18 = invocation.getInferenceContext((ParameterizedMethodBinding)method);
/*  791 */       if (ic18 != null)
/*  792 */         ic18.flushBoundOutbox(); 
/*      */     } 
/*  794 */     if (problemMethod != null)
/*  795 */       return (MethodBinding)problemMethod; 
/*  796 */     return method;
/*      */   }
/*      */   
/*      */   public static void resolveAnnotations(BlockScope scope, Annotation[] sourceAnnotations, Binding recipient) {
/*  800 */     resolveAnnotations(scope, sourceAnnotations, recipient, false);
/*  801 */     if (recipient instanceof SourceTypeBinding) {
/*  802 */       ((SourceTypeBinding)recipient).evaluateNullAnnotations();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static AnnotationBinding[] resolveAnnotations(BlockScope scope, Annotation[] sourceAnnotations, Binding recipient, boolean copySE8AnnotationsToType) {
/*  811 */     AnnotationBinding[] annotations = null;
/*  812 */     int length = (sourceAnnotations == null) ? 0 : sourceAnnotations.length;
/*  813 */     if (recipient != null) {
/*  814 */       PackageBinding packageBinding; ReferenceBinding type; MethodBinding method; FieldBinding field; RecordComponentBinding rcb; LocalVariableBinding local; ModuleBinding module; switch (recipient.kind()) {
/*      */         case 16:
/*  816 */           packageBinding = (PackageBinding)recipient;
/*  817 */           if ((packageBinding.tagBits & 0x200000000L) != 0L) return annotations; 
/*  818 */           packageBinding.tagBits |= 0x600000000L;
/*      */           break;
/*      */         case 4:
/*      */         case 2052:
/*  822 */           type = (ReferenceBinding)recipient;
/*  823 */           if ((type.tagBits & 0x200000000L) != 0L) return annotations; 
/*  824 */           type.tagBits |= 0x600000000L;
/*  825 */           if (length > 0) {
/*  826 */             annotations = new AnnotationBinding[length];
/*  827 */             type.setAnnotations(annotations, false);
/*      */           } 
/*      */           break;
/*      */         case 8:
/*  831 */           method = (MethodBinding)recipient;
/*  832 */           if ((method.tagBits & 0x200000000L) != 0L) return annotations; 
/*  833 */           method.tagBits |= 0x600000000L;
/*  834 */           if (length > 0) {
/*  835 */             annotations = new AnnotationBinding[length];
/*  836 */             method.setAnnotations(annotations, false);
/*      */           } 
/*      */           break;
/*      */         case 1:
/*  840 */           field = (FieldBinding)recipient;
/*  841 */           if ((field.tagBits & 0x200000000L) != 0L) return annotations; 
/*  842 */           field.tagBits |= 0x600000000L;
/*  843 */           if (length > 0) {
/*  844 */             annotations = new AnnotationBinding[length];
/*  845 */             field.setAnnotations(annotations, false);
/*      */           } 
/*      */           break;
/*      */         case 131072:
/*  849 */           rcb = (RecordComponentBinding)recipient;
/*  850 */           if ((rcb.tagBits & 0x200000000L) != 0L) return annotations; 
/*  851 */           rcb.tagBits |= 0x600000000L;
/*  852 */           if (length > 0) {
/*  853 */             annotations = new AnnotationBinding[length];
/*  854 */             rcb.setAnnotations(annotations, false);
/*      */           } 
/*      */           break;
/*      */         case 2:
/*  858 */           local = (LocalVariableBinding)recipient;
/*  859 */           if ((local.tagBits & 0x200000000L) != 0L) return annotations; 
/*  860 */           local.tagBits |= 0x600000000L;
/*  861 */           if (length > 0) {
/*  862 */             annotations = new AnnotationBinding[length];
/*  863 */             local.setAnnotations(annotations, (Scope)scope, false);
/*      */           } 
/*      */           break;
/*      */         case 4100:
/*  867 */           ((TypeVariableBinding)recipient).tagBits |= 0x200000000L;
/*      */ 
/*      */ 
/*      */         
/*      */         case 16388:
/*  872 */           annotations = new AnnotationBinding[length];
/*      */           break;
/*      */         case 64:
/*  875 */           module = (ModuleBinding)recipient;
/*  876 */           if ((module.tagBits & 0x200000000L) != 0L) return annotations; 
/*  877 */           module.tagBits |= 0x600000000L;
/*  878 */           if (length > 0) {
/*  879 */             annotations = new AnnotationBinding[length];
/*  880 */             module.setAnnotations(annotations, (Scope)scope, false);
/*      */           } 
/*      */           break;
/*      */         default:
/*  884 */           return annotations;
/*      */       } 
/*      */     } 
/*  887 */     if (sourceAnnotations == null)
/*  888 */       return annotations;  int i;
/*  889 */     for (i = 0; i < length; i++) {
/*  890 */       Annotation annotation = sourceAnnotations[i];
/*  891 */       Binding annotationRecipient = annotation.recipient;
/*  892 */       if (annotationRecipient != null && recipient != null) {
/*      */         FieldBinding field; RecordComponentBinding recordComponentBinding; LocalVariableBinding local; long otherLocalTagBits;
/*  894 */         switch (recipient.kind()) {
/*      */           case 16388:
/*  896 */             if (annotations != null)
/*      */             {
/*  898 */               for (int j = 0; j < length; j++) {
/*  899 */                 annotations[j] = sourceAnnotations[j].getCompilerAnnotation();
/*      */               }
/*      */             }
/*      */             break;
/*      */           case 1:
/*  904 */             field = (FieldBinding)recipient;
/*  905 */             field.tagBits = ((FieldBinding)annotationRecipient).tagBits;
/*  906 */             if (annotations != null)
/*      */             {
/*  908 */               for (int j = 0; j < length; j++) {
/*  909 */                 Annotation annot = sourceAnnotations[j];
/*  910 */                 annotations[j] = annot.getCompilerAnnotation();
/*      */               } 
/*      */             }
/*      */             break;
/*      */           case 131072:
/*  915 */             recordComponentBinding = (RecordComponentBinding)recipient;
/*  916 */             recordComponentBinding.tagBits = ((RecordComponentBinding)annotationRecipient).tagBits;
/*  917 */             if (annotations != null)
/*      */             {
/*  919 */               for (int j = 0; j < length; j++) {
/*  920 */                 Annotation annot = sourceAnnotations[j];
/*  921 */                 annotations[j] = annot.getCompilerAnnotation();
/*      */               } 
/*      */             }
/*      */             break;
/*      */           case 2:
/*  926 */             local = (LocalVariableBinding)recipient;
/*      */             
/*  928 */             otherLocalTagBits = ((VariableBinding)annotationRecipient).tagBits;
/*      */             
/*  930 */             local.tagBits = otherLocalTagBits | local.tagBits & 0x400L;
/*  931 */             if ((otherLocalTagBits & 0x4000000000000L) == 0L) {
/*      */ 
/*      */               
/*  934 */               if (annotations != null) {
/*  935 */                 for (int j = 0; j < length; j++) {
/*  936 */                   Annotation annot = sourceAnnotations[j];
/*  937 */                   annotations[j] = annot.getCompilerAnnotation();
/*      */                 } 
/*      */               }
/*  940 */             } else if (annotations != null) {
/*      */               
/*  942 */               LocalDeclaration localDeclaration = local.declaration;
/*  943 */               int declarationSourceEnd = localDeclaration.declarationSourceEnd;
/*  944 */               int declarationSourceStart = localDeclaration.declarationSourceStart;
/*  945 */               for (int j = 0; j < length; j++) {
/*  946 */                 Annotation annot = sourceAnnotations[j];
/*      */ 
/*      */ 
/*      */ 
/*      */                 
/*  951 */                 AnnotationBinding annotationBinding = annot.getCompilerAnnotation();
/*  952 */                 annotations[j] = annotationBinding;
/*  953 */                 if (annotationBinding != null) {
/*  954 */                   ReferenceBinding annotationType = annotationBinding.getAnnotationType();
/*  955 */                   if (annotationType != null && annotationType.id == 49) {
/*  956 */                     annot.recordSuppressWarnings((Scope)scope, declarationSourceStart, declarationSourceEnd, (scope.compilerOptions()).suppressWarnings);
/*      */                   }
/*      */                 } 
/*      */               } 
/*      */             } 
/*      */ 
/*      */             
/*  963 */             if (annotationRecipient instanceof RecordComponentBinding && copySE8AnnotationsToType)
/*  964 */               copySE8AnnotationsToType(scope, recipient, sourceAnnotations, false); 
/*      */             break;
/*      */         } 
/*  967 */         return annotations;
/*      */       } 
/*  969 */       annotation.recipient = recipient;
/*  970 */       annotation.resolveType(scope);
/*      */       
/*  972 */       if (annotations != null) {
/*  973 */         annotations[i] = annotation.getCompilerAnnotation();
/*      */       }
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  981 */     if (recipient != null && recipient.isTaggedRepeatable()) {
/*  982 */       for (i = 0; i < length; i++) {
/*  983 */         Annotation annotation = sourceAnnotations[i];
/*  984 */         ReferenceBinding annotationType = (annotations[i] != null) ? annotations[i].getAnnotationType() : null;
/*  985 */         if (annotationType != null && annotationType.id == 90) {
/*  986 */           annotation.checkRepeatableMetaAnnotation(scope);
/*      */         }
/*      */       } 
/*      */     }
/*      */     
/*  991 */     if (annotations != null && length > 1) {
/*  992 */       AnnotationBinding[] distinctAnnotations = annotations;
/*  993 */       Map<Object, Object> implicitContainerAnnotations = null; int j;
/*  994 */       for (j = 0; j < length; j++) {
/*  995 */         AnnotationBinding annotation = distinctAnnotations[j];
/*  996 */         if (annotation != null) {
/*  997 */           ReferenceBinding annotationType = annotation.getAnnotationType();
/*  998 */           boolean foundDuplicate = false;
/*  999 */           ContainerAnnotation container = null;
/* 1000 */           for (int k = j + 1; k < length; k++) {
/* 1001 */             AnnotationBinding otherAnnotation = distinctAnnotations[k];
/* 1002 */             if (otherAnnotation != null && 
/* 1003 */               TypeBinding.equalsEquals((TypeBinding)otherAnnotation.getAnnotationType(), (TypeBinding)annotationType)) {
/* 1004 */               if (distinctAnnotations == annotations) {
/* 1005 */                 System.arraycopy(distinctAnnotations, 0, distinctAnnotations = new AnnotationBinding[length], 0, length);
/*      */               }
/* 1007 */               distinctAnnotations[k] = null;
/* 1008 */               if (annotationType.isRepeatableAnnotationType()) {
/* 1009 */                 Annotation persistibleAnnotation = sourceAnnotations[j].getPersistibleAnnotation();
/* 1010 */                 if (persistibleAnnotation instanceof ContainerAnnotation)
/* 1011 */                   container = (ContainerAnnotation)persistibleAnnotation; 
/* 1012 */                 if (container == null) {
/* 1013 */                   ReferenceBinding containerAnnotationType = annotationType.containerAnnotationType();
/* 1014 */                   container = new ContainerAnnotation(sourceAnnotations[j], containerAnnotationType, scope);
/* 1015 */                   if (implicitContainerAnnotations == null) implicitContainerAnnotations = new HashMap<>(3); 
/* 1016 */                   implicitContainerAnnotations.put(containerAnnotationType, sourceAnnotations[j]);
/* 1017 */                   Annotation.checkForInstancesOfRepeatableWithRepeatingContainerAnnotation(scope, annotationType, sourceAnnotations);
/*      */                 } 
/* 1019 */                 container.addContainee(sourceAnnotations[k]);
/*      */               } else {
/* 1021 */                 foundDuplicate = true;
/* 1022 */                 scope.problemReporter().duplicateAnnotation(sourceAnnotations[k], (scope.compilerOptions()).sourceLevel);
/*      */               } 
/*      */             } 
/*      */           } 
/* 1026 */           if (container != null) {
/* 1027 */             container.resolveType(scope);
/*      */           }
/* 1029 */           if (foundDuplicate) {
/* 1030 */             scope.problemReporter().duplicateAnnotation(sourceAnnotations[j], (scope.compilerOptions()).sourceLevel);
/*      */           }
/*      */         } 
/*      */       } 
/* 1034 */       if (implicitContainerAnnotations != null)
/* 1035 */         for (j = 0; j < length; j++) {
/* 1036 */           if (distinctAnnotations[j] != null) {
/* 1037 */             Annotation annotation = sourceAnnotations[j];
/* 1038 */             ReferenceBinding annotationType = distinctAnnotations[j].getAnnotationType();
/* 1039 */             if (implicitContainerAnnotations.containsKey(annotationType)) {
/* 1040 */               scope.problemReporter().repeatedAnnotationWithContainer((Annotation)implicitContainerAnnotations.get(annotationType), annotation);
/*      */             }
/*      */           } 
/*      */         }  
/*      */     } 
/* 1045 */     if (copySE8AnnotationsToType)
/* 1046 */       copySE8AnnotationsToType(scope, recipient, sourceAnnotations, false); 
/* 1047 */     return annotations;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static TypeBinding resolveAnnotations(BlockScope scope, Annotation[][] sourceAnnotations, TypeBinding type) {
/* 1057 */     int levels = (sourceAnnotations == null) ? 0 : sourceAnnotations.length;
/* 1058 */     if (type == null || levels == 0)
/* 1059 */       return type; 
/* 1060 */     AnnotationBinding[][] annotationBindings = new AnnotationBinding[levels][];
/*      */     
/* 1062 */     for (int i = 0; i < levels; i++) {
/* 1063 */       Annotation[] annotations = sourceAnnotations[i];
/* 1064 */       if (annotations != null && annotations.length > 0) {
/* 1065 */         annotationBindings[i] = resolveAnnotations(scope, annotations, (Binding)TypeBinding.TYPE_USE_BINDING, false);
/*      */       }
/*      */     } 
/* 1068 */     return scope.environment().createAnnotatedType(type, annotationBindings);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void handleNonNullByDefault(BlockScope scope, Annotation[] sourceAnnotations, LocalDeclaration localDeclaration) {
/* 1077 */     if (sourceAnnotations == null || sourceAnnotations.length == 0) {
/*      */       return;
/*      */     }
/* 1080 */     int length = sourceAnnotations.length;
/*      */     
/* 1082 */     int defaultNullness = 0;
/* 1083 */     Annotation lastNNBDAnnotation = null;
/* 1084 */     for (int i = 0; i < length; i++) {
/* 1085 */       Annotation annotation = sourceAnnotations[i];
/* 1086 */       long value = annotation.handleNonNullByDefault(scope);
/* 1087 */       if (value != 0L) {
/* 1088 */         defaultNullness = (int)(defaultNullness | value);
/* 1089 */         lastNNBDAnnotation = annotation;
/*      */       } 
/*      */     } 
/* 1092 */     if (defaultNullness != 0) {
/*      */       
/* 1094 */       LocalVariableBinding binding = new LocalVariableBinding(localDeclaration, null, 0, false);
/* 1095 */       Binding target = scope.checkRedundantDefaultNullness(defaultNullness, localDeclaration.sourceStart);
/* 1096 */       boolean recorded = scope.recordNonNullByDefault((Binding)binding, defaultNullness, lastNNBDAnnotation, 
/* 1097 */           lastNNBDAnnotation.sourceStart, localDeclaration.declarationSourceEnd);
/* 1098 */       if (recorded && 
/* 1099 */         target != null) {
/* 1100 */         scope.problemReporter().nullDefaultAnnotationIsRedundant(localDeclaration, 
/* 1101 */             new Annotation[] { lastNNBDAnnotation }, target);
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void copySE8AnnotationsToType(BlockScope scope, Binding recipient, Annotation[] annotations, boolean annotatingEnumerator) {
/*      */     MethodBinding method;
/* 1112 */     if (annotations == null || annotations.length == 0 || recipient == null) {
/*      */       return;
/*      */     }
/* 1115 */     long recipientTargetMask = 0L;
/* 1116 */     switch (recipient.kind()) {
/*      */       case 2:
/* 1118 */         recipientTargetMask = recipient.isParameter() ? 549755813888L : 2199023255552L;
/*      */         break;
/*      */       case 1:
/* 1121 */         recipientTargetMask = 137438953472L;
/*      */         break;
/*      */       case 8:
/* 1124 */         method = (MethodBinding)recipient;
/* 1125 */         recipientTargetMask = method.isConstructor() ? 1099511627776L : 274877906944L;
/*      */         break;
/*      */       case 131072:
/* 1128 */         recipientTargetMask = 1073741824L;
/*      */         break;
/*      */       
/*      */       default:
/*      */         return;
/*      */     } 
/* 1134 */     AnnotationBinding[] se8Annotations = null;
/* 1135 */     int se8count = 0;
/* 1136 */     long se8nullBits = 0L;
/* 1137 */     Annotation se8NullAnnotation = null;
/* 1138 */     int firstSE8 = -1;
/* 1139 */     for (int i = 0, length = annotations.length; i < length; i++) {
/* 1140 */       AnnotationBinding annotation = annotations[i].getCompilerAnnotation();
/* 1141 */       if (annotation != null) {
/* 1142 */         ReferenceBinding annotationType = annotation.getAnnotationType();
/* 1143 */         long metaTagBits = annotationType.getAnnotationTagBits();
/* 1144 */         if ((metaTagBits & 0x20000000000000L) != 0L)
/* 1145 */           if (annotatingEnumerator) {
/* 1146 */             if ((metaTagBits & recipientTargetMask) == 0L) {
/* 1147 */               scope.problemReporter().misplacedTypeAnnotations(annotations[i], annotations[i]);
/*      */             }
/*      */           } else {
/*      */             
/* 1151 */             if (firstSE8 == -1) firstSE8 = i; 
/* 1152 */             if (se8Annotations == null) {
/* 1153 */               se8Annotations = new AnnotationBinding[] { annotation };
/* 1154 */               se8count = 1;
/*      */             } else {
/* 1156 */               System.arraycopy(se8Annotations, 0, se8Annotations = new AnnotationBinding[se8count + 1], 0, se8count);
/* 1157 */               se8Annotations[se8count++] = annotation;
/*      */             } 
/* 1159 */             if (annotationType.hasNullBit(32)) {
/* 1160 */               se8nullBits |= 0x100000000000000L;
/* 1161 */               se8NullAnnotation = annotations[i];
/* 1162 */             } else if (annotationType.hasNullBit(64)) {
/* 1163 */               se8nullBits |= 0x80000000000000L;
/* 1164 */               se8NullAnnotation = annotations[i];
/*      */             } 
/*      */           }  
/*      */       } 
/* 1168 */     }  if (se8Annotations != null) {
/* 1169 */       LocalVariableBinding local; TypeReference typeRef; FieldBinding field; SourceTypeBinding sourceType; FieldDeclaration fieldDeclaration; RecordComponentBinding recordComponentBinding; RecordComponent recordComponent; MethodBinding methodBinding; switch (recipient.kind()) {
/*      */         case 2:
/* 1171 */           local = (LocalVariableBinding)recipient;
/* 1172 */           typeRef = local.declaration.type;
/* 1173 */           if (Annotation.isTypeUseCompatible(typeRef, (Scope)scope)) {
/* 1174 */             local.declaration.bits |= 0x100000;
/* 1175 */             typeRef.bits |= 0x100000;
/* 1176 */             int location = local.isParameter() ? 8 : 0;
/* 1177 */             local.type = mergeAnnotationsIntoType(scope, se8Annotations, se8nullBits, se8NullAnnotation, typeRef, location, local.type);
/* 1178 */             if (scope.environment().usesNullTypeAnnotations()) {
/* 1179 */               local.tagBits &= se8nullBits ^ 0xFFFFFFFFFFFFFFFFL;
/*      */             }
/*      */           } 
/*      */           break;
/*      */         case 1:
/* 1184 */           field = (FieldBinding)recipient;
/* 1185 */           sourceType = (SourceTypeBinding)field.declaringClass;
/* 1186 */           fieldDeclaration = sourceType.scope.referenceContext.declarationOf(field);
/* 1187 */           if (Annotation.isTypeUseCompatible(fieldDeclaration.type, (Scope)scope)) {
/* 1188 */             fieldDeclaration.bits |= 0x100000;
/* 1189 */             fieldDeclaration.type.bits |= 0x100000;
/* 1190 */             field.type = mergeAnnotationsIntoType(scope, se8Annotations, se8nullBits, se8NullAnnotation, 
/* 1191 */                 fieldDeclaration.type, 32, field.type);
/* 1192 */             if (scope.environment().usesNullTypeAnnotations()) {
/* 1193 */               field.tagBits &= se8nullBits ^ 0xFFFFFFFFFFFFFFFFL;
/*      */             }
/*      */           } 
/*      */           break;
/*      */         case 131072:
/* 1198 */           recordComponentBinding = (RecordComponentBinding)recipient;
/* 1199 */           recordComponent = recordComponentBinding.sourceRecordComponent();
/* 1200 */           if (Annotation.isTypeUseCompatible(recordComponent.type, (Scope)scope)) {
/* 1201 */             recordComponent.bits |= 0x100000;
/* 1202 */             recordComponent.type.bits |= 0x100000;
/* 1203 */             recordComponentBinding.type = mergeAnnotationsIntoType(scope, se8Annotations, se8nullBits, se8NullAnnotation, recordComponent.type, 
/* 1204 */                 32, recordComponentBinding.type);
/* 1205 */             if (scope.environment().usesNullTypeAnnotations()) {
/* 1206 */               recordComponentBinding.tagBits &= se8nullBits ^ 0xFFFFFFFFFFFFFFFFL;
/*      */             }
/*      */           } 
/*      */           break;
/*      */         case 8:
/* 1211 */           methodBinding = (MethodBinding)recipient;
/* 1212 */           if (!methodBinding.isConstructor()) {
/* 1213 */             sourceType = (SourceTypeBinding)methodBinding.declaringClass;
/* 1214 */             MethodDeclaration methodDecl = (MethodDeclaration)sourceType.scope.referenceContext.declarationOf(methodBinding);
/* 1215 */             if (Annotation.isTypeUseCompatible(methodDecl.returnType, (Scope)scope)) {
/* 1216 */               methodDecl.bits |= 0x100000;
/* 1217 */               methodDecl.returnType.bits |= 0x100000;
/* 1218 */               methodBinding.returnType = mergeAnnotationsIntoType(scope, se8Annotations, se8nullBits, se8NullAnnotation, 
/* 1219 */                   methodDecl.returnType, 16, methodBinding.returnType);
/* 1220 */               if (scope.environment().usesNullTypeAnnotations())
/* 1221 */                 methodBinding.tagBits &= se8nullBits ^ 0xFFFFFFFFFFFFFFFFL; 
/*      */             } 
/*      */             break;
/*      */           } 
/* 1225 */           methodBinding.setTypeAnnotations(se8Annotations);
/*      */           break;
/*      */       } 
/*      */       
/* 1229 */       AnnotationBinding[] recipientAnnotations = recipient.getAnnotations();
/* 1230 */       int j = (recipientAnnotations == null) ? 0 : recipientAnnotations.length;
/* 1231 */       int newLength = 0;
/* 1232 */       for (int k = 0; k < j; k++) {
/* 1233 */         AnnotationBinding recipientAnnotation = recipientAnnotations[k];
/* 1234 */         if (recipientAnnotation != null) {
/*      */           
/* 1236 */           long annotationTargetMask = recipientAnnotation.getAnnotationType().getAnnotationTagBits() & 0x20600FF840000000L;
/* 1237 */           if (annotationTargetMask == 0L || (annotationTargetMask & recipientTargetMask) != 0L)
/* 1238 */             recipientAnnotations[newLength++] = recipientAnnotation; 
/*      */         } 
/* 1240 */       }  if (newLength != j) {
/* 1241 */         System.arraycopy(recipientAnnotations, 0, recipientAnnotations = new AnnotationBinding[newLength], 0, newLength);
/* 1242 */         recipient.setAnnotations(recipientAnnotations, (Scope)scope, false);
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public static Annotation[] getRelevantAnnotations(Annotation[] annotations, long rcMask, List<AnnotationBinding> relevantAnnotations) {
/* 1250 */     if (annotations == null || annotations.length == 0) {
/* 1251 */       return null;
/*      */     }
/* 1253 */     List<Annotation> filteredAnnotations = new ArrayList<>(); byte b; int i; Annotation[] arrayOfAnnotation;
/* 1254 */     for (i = (arrayOfAnnotation = annotations).length, b = 0; b < i; ) { Annotation annot = arrayOfAnnotation[b];
/* 1255 */       AnnotationBinding annotationBinding = annot.getCompilerAnnotation();
/* 1256 */       if (annotationBinding != null) {
/* 1257 */         ReferenceBinding annotationType = annotationBinding.getAnnotationType();
/* 1258 */         long metaTagBits = annotationType.getAnnotationTagBits();
/* 1259 */         if ((metaTagBits & 0x20600FF840000000L) == 0L || (metaTagBits & rcMask) != 0L) {
/* 1260 */           filteredAnnotations.add(annot);
/* 1261 */           if (relevantAnnotations != null)
/* 1262 */             relevantAnnotations.add(annotationBinding); 
/*      */         } 
/*      */       }  b++; }
/* 1265 */      return filteredAnnotations.<Annotation>toArray(new Annotation[0]); } public static Annotation[] copyRecordComponentAnnotations(Scope scope, Binding recipient, Annotation[] annotations) { List<AnnotationBinding> relevantAnnotations; ArrayList<AnnotationBinding> arrayList2; MethodBinding methodBinding; ArrayList<AnnotationBinding> arrayList1;
/*      */     Annotation[] filteredAnnotations;
/*      */     AnnotationBinding[] recipientAnnotations;
/* 1268 */     if (annotations == null || annotations.length == 0 || recipient == null) {
/* 1269 */       return null;
/*      */     }
/* 1271 */     long recipientTargetMask = 0L;
/* 1272 */     switch (recipient.kind()) {
/*      */       case 2:
/* 1274 */         assert recipient.isParameter();
/* 1275 */         recipientTargetMask = recipient.isParameter() ? 549755813888L : 2199023255552L;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1293 */         relevantAnnotations = new ArrayList<>();
/* 1294 */         filteredAnnotations = getRelevantAnnotations(annotations, recipientTargetMask, relevantAnnotations);
/* 1295 */         recipientAnnotations = relevantAnnotations.<AnnotationBinding>toArray(new AnnotationBinding[relevantAnnotations.size()]);
/* 1296 */         recipient.setAnnotations(recipientAnnotations, scope, true);
/* 1297 */         return filteredAnnotations;case 1: recipientTargetMask = 137438953472L; arrayList2 = new ArrayList(); filteredAnnotations = getRelevantAnnotations(annotations, recipientTargetMask, arrayList2); recipientAnnotations = arrayList2.<AnnotationBinding>toArray(new AnnotationBinding[arrayList2.size()]); recipient.setAnnotations(recipientAnnotations, scope, true); return filteredAnnotations;case 8: methodBinding = (MethodBinding)recipient; recipientTargetMask = methodBinding.isConstructor() ? 1099511627776L : 274877906944L; arrayList1 = new ArrayList(); filteredAnnotations = getRelevantAnnotations(annotations, recipientTargetMask, arrayList1); recipientAnnotations = arrayList1.<AnnotationBinding>toArray(new AnnotationBinding[arrayList1.size()]); recipient.setAnnotations(recipientAnnotations, scope, true); return filteredAnnotations;case 131072: recipientTargetMask = 1073741824L; arrayList1 = new ArrayList<>(); filteredAnnotations = getRelevantAnnotations(annotations, recipientTargetMask, arrayList1); recipientAnnotations = arrayList1.<AnnotationBinding>toArray(new AnnotationBinding[arrayList1.size()]); recipient.setAnnotations(recipientAnnotations, scope, true); return filteredAnnotations;
/*      */     } 
/*      */     return null; }
/*      */ 
/*      */   
/*      */   private static TypeBinding mergeAnnotationsIntoType(BlockScope scope, AnnotationBinding[] se8Annotations, long se8nullBits, Annotation se8NullAnnotation, TypeReference typeRef, int location, TypeBinding existingType) {
/* 1303 */     if (existingType == null || !existingType.isValidBinding()) return existingType; 
/* 1304 */     TypeReference unionRef = typeRef.isUnionType() ? ((UnionTypeReference)typeRef).typeReferences[0] : null;
/*      */ 
/*      */     
/* 1307 */     TypeBinding oldLeafType = (unionRef == null) ? existingType.leafComponentType() : unionRef.resolvedType;
/* 1308 */     if (se8nullBits != 0L && 
/* 1309 */       typeRef instanceof ArrayTypeReference) {
/* 1310 */       ArrayTypeReference arrayTypeReference = (ArrayTypeReference)typeRef;
/* 1311 */       if (arrayTypeReference.leafComponentTypeWithoutDefaultNullness != null) {
/* 1312 */         oldLeafType = arrayTypeReference.leafComponentTypeWithoutDefaultNullness;
/*      */       }
/*      */     } 
/*      */     
/* 1316 */     if (se8nullBits != 0L && oldLeafType.isBaseType()) {
/* 1317 */       scope.problemReporter().illegalAnnotationForBaseType(typeRef, new Annotation[] { se8NullAnnotation }, se8nullBits);
/* 1318 */       return existingType;
/*      */     } 
/*      */     
/* 1321 */     if (typeRef.dimensions() > 0) {
/* 1322 */       location = 512;
/*      */     }
/*      */     
/* 1325 */     long prevNullBits = oldLeafType.tagBits & 0x180000000000000L;
/* 1326 */     if ((prevNullBits | se8nullBits) == 108086391056891904L && typeRef.hasNullTypeAnnotation(TypeReference.AnnotationPosition.MAIN_TYPE)) {
/*      */       
/* 1328 */       if (!(oldLeafType instanceof TypeVariableBinding)) {
/* 1329 */         if (prevNullBits != 108086391056891904L && se8nullBits != 108086391056891904L) {
/* 1330 */           scope.problemReporter().contradictoryNullAnnotations(se8NullAnnotation);
/*      */         }
/* 1332 */         se8nullBits = 108086391056891904L;
/*      */       } 
/* 1334 */       oldLeafType = oldLeafType.withoutToplevelNullAnnotation();
/* 1335 */     } else if (se8nullBits == 72057594037927936L && 
/* 1336 */       location != 16 && 
/* 1337 */       location != 32 && 
/* 1338 */       scope.hasDefaultNullnessForType(typeRef.resolvedType, location, typeRef.sourceStart)) {
/* 1339 */       scope.problemReporter().nullAnnotationIsRedundant(typeRef, new Annotation[] { se8NullAnnotation });
/*      */     } 
/* 1341 */     if (se8nullBits == 108086391056891904L)
/*      */     {
/* 1343 */       se8Annotations = scope.environment().filterNullTypeAnnotations(se8Annotations);
/*      */     }
/* 1345 */     if (se8Annotations.length > 0) {
/* 1346 */       AnnotationBinding[][] goodies = new AnnotationBinding[typeRef.getAnnotatableLevels()][];
/* 1347 */       goodies[0] = se8Annotations;
/* 1348 */       TypeBinding newLeafType = scope.environment().createAnnotatedType(oldLeafType, goodies);
/*      */       
/* 1350 */       if (unionRef == null) {
/* 1351 */         typeRef.resolvedType = existingType.isArrayType() ? (TypeBinding)scope.environment().createArrayType(newLeafType, existingType.dimensions(), existingType.getTypeAnnotations()) : newLeafType;
/*      */       } else {
/* 1353 */         unionRef.resolvedType = newLeafType;
/* 1354 */         unionRef.bits |= 0x100000;
/*      */       } 
/*      */     } 
/* 1357 */     return typeRef.resolvedType;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void resolveDeprecatedAnnotations(BlockScope scope, Annotation[] annotations, Binding recipient) {
/* 1364 */     if (recipient != null) {
/* 1365 */       PackageBinding packageBinding; ReferenceBinding type; MethodBinding method; FieldBinding field; LocalVariableBinding local; RecordComponentBinding recordComponentBinding; int kind = recipient.kind();
/* 1366 */       if (annotations != null) {
/*      */         int length;
/* 1368 */         if ((length = annotations.length) >= 0) {
/* 1369 */           PackageBinding packageBinding1; ReferenceBinding referenceBinding; MethodBinding methodBinding; FieldBinding fieldBinding; LocalVariableBinding localVariableBinding; RecordComponentBinding recordComponentBinding1; switch (kind) {
/*      */             case 16:
/* 1371 */               packageBinding1 = (PackageBinding)recipient;
/* 1372 */               if ((packageBinding1.tagBits & 0x400000000L) != 0L)
/*      */                 return;  break;
/*      */             case 4:
/*      */             case 2052:
/* 1376 */               referenceBinding = (ReferenceBinding)recipient;
/* 1377 */               if ((referenceBinding.tagBits & 0x400000000L) != 0L)
/*      */                 return;  break;
/*      */             case 8:
/* 1380 */               methodBinding = (MethodBinding)recipient;
/* 1381 */               if ((methodBinding.tagBits & 0x400000000L) != 0L)
/*      */                 return;  break;
/*      */             case 1:
/* 1384 */               fieldBinding = (FieldBinding)recipient;
/* 1385 */               if ((fieldBinding.tagBits & 0x400000000L) != 0L)
/*      */                 return;  break;
/*      */             case 2:
/* 1388 */               localVariableBinding = (LocalVariableBinding)recipient;
/* 1389 */               if ((localVariableBinding.tagBits & 0x400000000L) != 0L)
/*      */                 return;  break;
/*      */             case 131072:
/* 1392 */               recordComponentBinding1 = (RecordComponentBinding)recipient;
/* 1393 */               if ((recordComponentBinding1.tagBits & 0x400000000L) != 0L)
/*      */                 return;  break;
/*      */             default:
/*      */               return;
/*      */           } 
/* 1398 */           for (int i = 0; i < length; i++) {
/* 1399 */             TypeReference annotationTypeRef = (annotations[i]).type;
/*      */             
/* 1401 */             if (CharOperation.equals(TypeConstants.JAVA_LANG_DEPRECATED[2], annotationTypeRef.getLastToken())) {
/* 1402 */               TypeBinding annotationType = (annotations[i]).type.resolveType(scope);
/* 1403 */               if (annotationType != null && annotationType.isValidBinding() && annotationType.id == 44) {
/* 1404 */                 PackageBinding packageBinding2; ReferenceBinding referenceBinding1; MethodBinding methodBinding1; FieldBinding fieldBinding1; LocalVariableBinding localVariableBinding1; RecordComponentBinding recordComponentBinding2; long deprecationTagBits = 70385924046848L;
/* 1405 */                 if ((scope.compilerOptions()).complianceLevel >= 3473408L) {
/* 1406 */                   byte b; int j; MemberValuePair[] arrayOfMemberValuePair; for (j = (arrayOfMemberValuePair = annotations[i].memberValuePairs()).length, b = 0; b < j; ) { MemberValuePair memberValuePair = arrayOfMemberValuePair[b];
/* 1407 */                     if (CharOperation.equals(memberValuePair.name, TypeConstants.FOR_REMOVAL)) {
/* 1408 */                       if (memberValuePair.value instanceof TrueLiteral)
/* 1409 */                         deprecationTagBits |= 0x4000000000000000L;  break;
/*      */                     } 
/*      */                     b++; }
/*      */                 
/*      */                 } 
/* 1414 */                 switch (kind) {
/*      */                   case 16:
/* 1416 */                     packageBinding2 = (PackageBinding)recipient;
/* 1417 */                     packageBinding2.tagBits |= deprecationTagBits;
/*      */                     return;
/*      */                   case 4:
/*      */                   case 2052:
/*      */                   case 4100:
/* 1422 */                     referenceBinding1 = (ReferenceBinding)recipient;
/* 1423 */                     referenceBinding1.tagBits |= deprecationTagBits;
/*      */                     return;
/*      */                   case 8:
/* 1426 */                     methodBinding1 = (MethodBinding)recipient;
/* 1427 */                     methodBinding1.tagBits |= deprecationTagBits;
/*      */                     return;
/*      */                   case 1:
/* 1430 */                     fieldBinding1 = (FieldBinding)recipient;
/* 1431 */                     fieldBinding1.tagBits |= deprecationTagBits;
/*      */                     return;
/*      */                   case 2:
/* 1434 */                     localVariableBinding1 = (LocalVariableBinding)recipient;
/* 1435 */                     localVariableBinding1.tagBits |= deprecationTagBits;
/*      */                     return;
/*      */                   case 131072:
/* 1438 */                     recordComponentBinding2 = (RecordComponentBinding)recipient;
/* 1439 */                     recordComponentBinding2.tagBits |= deprecationTagBits;
/*      */                     return;
/*      */                 } 
/*      */                 return;
/*      */               } 
/*      */             } 
/*      */           } 
/*      */         } 
/*      */       } 
/* 1448 */       switch (kind) {
/*      */         case 16:
/* 1450 */           packageBinding = (PackageBinding)recipient;
/* 1451 */           packageBinding.tagBits |= 0x400000000L;
/*      */           return;
/*      */         case 4:
/*      */         case 2052:
/*      */         case 4100:
/* 1456 */           type = (ReferenceBinding)recipient;
/* 1457 */           type.tagBits |= 0x400000000L;
/*      */           return;
/*      */         case 8:
/* 1460 */           method = (MethodBinding)recipient;
/* 1461 */           method.tagBits |= 0x400000000L;
/*      */           return;
/*      */         case 1:
/* 1464 */           field = (FieldBinding)recipient;
/* 1465 */           field.tagBits |= 0x400000000L;
/*      */           return;
/*      */         case 2:
/* 1468 */           local = (LocalVariableBinding)recipient;
/* 1469 */           local.tagBits |= 0x400000000L;
/*      */           return;
/*      */         case 131072:
/* 1472 */           recordComponentBinding = (RecordComponentBinding)recipient;
/* 1473 */           recordComponentBinding.tagBits |= 0x400000000L;
/*      */           return;
/*      */       } 
/*      */       return;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean checkingPotentialCompatibility() {
/* 1483 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void acceptPotentiallyCompatibleMethods(MethodBinding[] methods) {}
/*      */ 
/*      */   
/*      */   public int sourceStart() {
/* 1492 */     return this.sourceStart;
/*      */   }
/*      */   public int sourceEnd() {
/* 1495 */     return this.sourceEnd;
/*      */   }
/*      */ 
/*      */   
/*      */   public String toString() {
/* 1500 */     return print(0, new StringBuffer(30)).toString();
/*      */   }
/*      */   
/*      */   public void traverse(ASTVisitor visitor, BlockScope scope) {}
/*      */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\ast\ASTNode.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */