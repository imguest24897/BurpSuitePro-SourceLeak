/*    */ package org.eclipse.jdt.internal.compiler.batch;
/*    */ 
/*    */ import java.io.File;
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FileFinder
/*    */ {
/*    */   public static String[] find(File f, String pattern) {
/* 31 */     List<String> files = new ArrayList<>();
/* 32 */     find0(f, pattern, files);
/* 33 */     String[] result = new String[files.size()];
/* 34 */     files.toArray(result);
/* 35 */     return result;
/*    */   }
/*    */   private static void find0(File f, String pattern, List<String> collector) {
/* 38 */     if (f.isDirectory()) {
/* 39 */       String[] files = f.list();
/* 40 */       if (files == null)
/* 41 */         return;  for (int i = 0, max = files.length; i < max; i++) {
/* 42 */         File current = new File(f, files[i]);
/* 43 */         if (current.isDirectory()) {
/* 44 */           find0(current, pattern, collector);
/*    */         } else {
/* 46 */           String name = current.getName().toLowerCase();
/* 47 */           if (name.endsWith(pattern))
/*    */           {
/*    */             
/* 50 */             if (name.endsWith("module-info.java")) {
/* 51 */               collector.add(0, current.getAbsolutePath());
/*    */             } else {
/* 53 */               collector.add(current.getAbsolutePath());
/*    */             } 
/*    */           }
/*    */         } 
/*    */       } 
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\batch\FileFinder.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */