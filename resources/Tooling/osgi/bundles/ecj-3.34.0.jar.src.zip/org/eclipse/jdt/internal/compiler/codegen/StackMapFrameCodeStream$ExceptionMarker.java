/*    */ package org.eclipse.jdt.internal.compiler.codegen;
/*    */ 
/*    */ import org.eclipse.jdt.core.compiler.CharOperation;
/*    */ import org.eclipse.jdt.internal.compiler.lookup.TypeBinding;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ExceptionMarker
/*    */   implements Comparable
/*    */ {
/*    */   private TypeBinding binding;
/*    */   public int pc;
/*    */   
/*    */   public ExceptionMarker(int pc, TypeBinding typeBinding) {
/* 43 */     this.pc = pc;
/* 44 */     this.binding = typeBinding;
/*    */   }
/*    */ 
/*    */   
/*    */   public int compareTo(Object o) {
/* 49 */     if (o instanceof ExceptionMarker) {
/* 50 */       return this.pc - ((ExceptionMarker)o).pc;
/*    */     }
/* 52 */     return 0;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean equals(Object obj) {
/* 57 */     if (obj instanceof ExceptionMarker) {
/* 58 */       ExceptionMarker marker = (ExceptionMarker)obj;
/* 59 */       return (this.pc == marker.pc && this.binding.equals(marker.binding));
/*    */     } 
/* 61 */     return false;
/*    */   }
/*    */   
/*    */   public TypeBinding getBinding() {
/* 65 */     return this.binding;
/*    */   }
/*    */ 
/*    */   
/*    */   public int hashCode() {
/* 70 */     return this.pc + CharOperation.hashCode(this.binding.constantPoolName());
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 75 */     StringBuffer buffer = new StringBuffer();
/* 76 */     buffer.append('(').append(this.pc).append(',').append(this.binding.constantPoolName()).append(')');
/* 77 */     return String.valueOf(buffer);
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\codegen\StackMapFrameCodeStream$ExceptionMarker.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */