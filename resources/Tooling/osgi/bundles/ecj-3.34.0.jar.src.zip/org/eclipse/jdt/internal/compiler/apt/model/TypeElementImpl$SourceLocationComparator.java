/*     */ package org.eclipse.jdt.internal.compiler.apt.model;
/*     */ 
/*     */ import java.util.Comparator;
/*     */ import java.util.IdentityHashMap;
/*     */ import javax.lang.model.element.Element;
/*     */ import javax.lang.model.element.ElementKind;
/*     */ import org.eclipse.jdt.internal.compiler.ast.FieldDeclaration;
/*     */ import org.eclipse.jdt.internal.compiler.ast.TypeDeclaration;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.Binding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.FieldBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.MethodBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.SourceTypeBinding;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class SourceLocationComparator
/*     */   implements Comparator<Element>
/*     */ {
/*  62 */   private final IdentityHashMap<ElementImpl, Integer> sourceStartCache = new IdentityHashMap<>();
/*     */ 
/*     */   
/*     */   public int compare(Element o1, Element o2) {
/*  66 */     ElementImpl e1 = (ElementImpl)o1;
/*  67 */     ElementImpl e2 = (ElementImpl)o2;
/*     */     
/*  69 */     return getSourceStart(e1) - getSourceStart(e2);
/*     */   }
/*     */   
/*     */   private int getSourceStart(ElementImpl e) {
/*  73 */     Integer value = this.sourceStartCache.get(e);
/*     */     
/*  75 */     if (value == null) {
/*  76 */       value = Integer.valueOf(determineSourceStart(e));
/*  77 */       this.sourceStartCache.put(e, value);
/*     */     } 
/*     */     
/*  80 */     return value.intValue(); } private int determineSourceStart(ElementImpl e) { TypeElementImpl typeElementImpl; Binding typeBinding;
/*     */     ExecutableElementImpl executableElementImpl;
/*     */     Binding binding;
/*     */     VariableElementImpl variableElementImpl;
/*  84 */     switch (e.getKind()) {
/*     */       case ENUM:
/*     */       case CLASS:
/*     */       case null:
/*     */       case INTERFACE:
/*     */       case RECORD:
/*  90 */         typeElementImpl = (TypeElementImpl)e;
/*  91 */         typeBinding = typeElementImpl._binding;
/*  92 */         if (typeBinding instanceof SourceTypeBinding) {
/*  93 */           SourceTypeBinding sourceTypeBinding = (SourceTypeBinding)typeBinding;
/*  94 */           TypeDeclaration typeDeclaration = (TypeDeclaration)sourceTypeBinding.scope.referenceContext();
/*  95 */           return typeDeclaration.sourceStart;
/*     */         } 
/*     */         break;
/*     */       case METHOD:
/*     */       case CONSTRUCTOR:
/* 100 */         executableElementImpl = (ExecutableElementImpl)e;
/* 101 */         binding = executableElementImpl._binding;
/* 102 */         if (binding instanceof MethodBinding) {
/* 103 */           MethodBinding methodBinding = (MethodBinding)binding;
/* 104 */           return methodBinding.sourceStart();
/*     */         } 
/*     */         break;
/*     */       case ENUM_CONSTANT:
/*     */       case FIELD:
/*     */       case RECORD_COMPONENT:
/* 110 */         variableElementImpl = (VariableElementImpl)e;
/* 111 */         binding = variableElementImpl._binding;
/* 112 */         if (binding instanceof FieldBinding) {
/* 113 */           FieldBinding fieldBinding = (FieldBinding)binding;
/* 114 */           FieldDeclaration fieldDeclaration = fieldBinding.sourceField();
/* 115 */           if (fieldDeclaration != null) {
/* 116 */             return fieldDeclaration.sourceStart;
/*     */           }
/*     */         } 
/*     */         break;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 124 */     return -1; }
/*     */ 
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\apt\model\TypeElementImpl$SourceLocationComparator.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */