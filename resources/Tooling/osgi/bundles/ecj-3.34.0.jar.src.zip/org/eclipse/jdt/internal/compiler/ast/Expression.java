/*      */ package org.eclipse.jdt.internal.compiler.ast;
/*      */ 
/*      */ import java.util.ArrayList;
/*      */ import org.eclipse.jdt.core.compiler.CharOperation;
/*      */ import org.eclipse.jdt.internal.compiler.ASTVisitor;
/*      */ import org.eclipse.jdt.internal.compiler.codegen.BranchLabel;
/*      */ import org.eclipse.jdt.internal.compiler.codegen.CodeStream;
/*      */ import org.eclipse.jdt.internal.compiler.flow.FlowContext;
/*      */ import org.eclipse.jdt.internal.compiler.flow.FlowInfo;
/*      */ import org.eclipse.jdt.internal.compiler.impl.Constant;
/*      */ import org.eclipse.jdt.internal.compiler.impl.ReferenceContext;
/*      */ import org.eclipse.jdt.internal.compiler.lookup.ArrayBinding;
/*      */ import org.eclipse.jdt.internal.compiler.lookup.BaseTypeBinding;
/*      */ import org.eclipse.jdt.internal.compiler.lookup.Binding;
/*      */ import org.eclipse.jdt.internal.compiler.lookup.BlockScope;
/*      */ import org.eclipse.jdt.internal.compiler.lookup.ClassScope;
/*      */ import org.eclipse.jdt.internal.compiler.lookup.FieldBinding;
/*      */ import org.eclipse.jdt.internal.compiler.lookup.InferenceContext18;
/*      */ import org.eclipse.jdt.internal.compiler.lookup.LocalVariableBinding;
/*      */ import org.eclipse.jdt.internal.compiler.lookup.MethodBinding;
/*      */ import org.eclipse.jdt.internal.compiler.lookup.ReferenceBinding;
/*      */ import org.eclipse.jdt.internal.compiler.lookup.Scope;
/*      */ import org.eclipse.jdt.internal.compiler.lookup.TypeBinding;
/*      */ import org.eclipse.jdt.internal.compiler.lookup.TypeVariableBinding;
/*      */ import org.eclipse.jdt.internal.compiler.lookup.VariableBinding;
/*      */ import org.eclipse.jdt.internal.compiler.lookup.WildcardBinding;
/*      */ import org.eclipse.jdt.internal.compiler.problem.ShouldNotImplement;
/*      */ import org.eclipse.jdt.internal.compiler.util.Messages;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public abstract class Expression
/*      */   extends Statement
/*      */ {
/*      */   public Constant constant;
/*   72 */   public int statementEnd = -1;
/*      */ 
/*      */ 
/*      */   
/*      */   public int implicitConversion;
/*      */ 
/*      */   
/*      */   public TypeBinding resolvedType;
/*      */ 
/*      */   
/*   82 */   public static Expression[] NO_EXPRESSIONS = new Expression[0];
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final boolean isConstantValueRepresentable(Constant constant, int constantTypeID, int targetTypeID) {
/*   88 */     if (targetTypeID == constantTypeID)
/*   89 */       return true; 
/*   90 */     switch (targetTypeID) {
/*      */       case 2:
/*   92 */         switch (constantTypeID) {
/*      */           case 2:
/*   94 */             return true;
/*      */           case 8:
/*   96 */             return (constant.doubleValue() == constant.charValue());
/*      */           case 9:
/*   98 */             return (constant.floatValue() == constant.charValue());
/*      */           case 10:
/*  100 */             return (constant.intValue() == constant.charValue());
/*      */           case 4:
/*  102 */             return (constant.shortValue() == constant.charValue());
/*      */           case 3:
/*  104 */             return (constant.byteValue() == constant.charValue());
/*      */           case 7:
/*  106 */             return (constant.longValue() == constant.charValue());
/*      */         } 
/*  108 */         return false;
/*      */ 
/*      */       
/*      */       case 9:
/*  112 */         switch (constantTypeID) {
/*      */           case 2:
/*  114 */             return (constant.charValue() == constant.floatValue());
/*      */           case 8:
/*  116 */             return (constant.doubleValue() == constant.floatValue());
/*      */           case 9:
/*  118 */             return true;
/*      */           case 10:
/*  120 */             return (constant.intValue() == constant.floatValue());
/*      */           case 4:
/*  122 */             return (constant.shortValue() == constant.floatValue());
/*      */           case 3:
/*  124 */             return (constant.byteValue() == constant.floatValue());
/*      */           case 7:
/*  126 */             return ((float)constant.longValue() == constant.floatValue());
/*      */         } 
/*  128 */         return false;
/*      */ 
/*      */       
/*      */       case 8:
/*  132 */         switch (constantTypeID) {
/*      */           case 2:
/*  134 */             return (constant.charValue() == constant.doubleValue());
/*      */           case 8:
/*  136 */             return true;
/*      */           case 9:
/*  138 */             return (constant.floatValue() == constant.doubleValue());
/*      */           case 10:
/*  140 */             return (constant.intValue() == constant.doubleValue());
/*      */           case 4:
/*  142 */             return (constant.shortValue() == constant.doubleValue());
/*      */           case 3:
/*  144 */             return (constant.byteValue() == constant.doubleValue());
/*      */           case 7:
/*  146 */             return (constant.longValue() == constant.doubleValue());
/*      */         } 
/*  148 */         return false;
/*      */ 
/*      */       
/*      */       case 3:
/*  152 */         switch (constantTypeID) {
/*      */           case 2:
/*  154 */             return (constant.charValue() == constant.byteValue());
/*      */           case 8:
/*  156 */             return (constant.doubleValue() == constant.byteValue());
/*      */           case 9:
/*  158 */             return (constant.floatValue() == constant.byteValue());
/*      */           case 10:
/*  160 */             return (constant.intValue() == constant.byteValue());
/*      */           case 4:
/*  162 */             return (constant.shortValue() == constant.byteValue());
/*      */           case 3:
/*  164 */             return true;
/*      */           case 7:
/*  166 */             return (constant.longValue() == constant.byteValue());
/*      */         } 
/*  168 */         return false;
/*      */ 
/*      */       
/*      */       case 4:
/*  172 */         switch (constantTypeID) {
/*      */           case 2:
/*  174 */             return (constant.charValue() == constant.shortValue());
/*      */           case 8:
/*  176 */             return (constant.doubleValue() == constant.shortValue());
/*      */           case 9:
/*  178 */             return (constant.floatValue() == constant.shortValue());
/*      */           case 10:
/*  180 */             return (constant.intValue() == constant.shortValue());
/*      */           case 4:
/*  182 */             return true;
/*      */           case 3:
/*  184 */             return (constant.byteValue() == constant.shortValue());
/*      */           case 7:
/*  186 */             return (constant.longValue() == constant.shortValue());
/*      */         } 
/*  188 */         return false;
/*      */ 
/*      */       
/*      */       case 10:
/*  192 */         switch (constantTypeID) {
/*      */           case 2:
/*  194 */             return (constant.charValue() == constant.intValue());
/*      */           case 8:
/*  196 */             return (constant.doubleValue() == constant.intValue());
/*      */           case 9:
/*  198 */             return (constant.floatValue() == constant.intValue());
/*      */           case 10:
/*  200 */             return true;
/*      */           case 4:
/*  202 */             return (constant.shortValue() == constant.intValue());
/*      */           case 3:
/*  204 */             return (constant.byteValue() == constant.intValue());
/*      */           case 7:
/*  206 */             return (constant.longValue() == constant.intValue());
/*      */         } 
/*  208 */         return false;
/*      */ 
/*      */       
/*      */       case 7:
/*  212 */         switch (constantTypeID) {
/*      */           case 2:
/*  214 */             return (constant.charValue() == constant.longValue());
/*      */           case 8:
/*  216 */             return (constant.doubleValue() == constant.longValue());
/*      */           case 9:
/*  218 */             return (constant.floatValue() == (float)constant.longValue());
/*      */           case 10:
/*  220 */             return (constant.intValue() == constant.longValue());
/*      */           case 4:
/*  222 */             return (constant.shortValue() == constant.longValue());
/*      */           case 3:
/*  224 */             return (constant.byteValue() == constant.longValue());
/*      */           case 7:
/*  226 */             return true;
/*      */         } 
/*  228 */         return false;
/*      */     } 
/*      */ 
/*      */     
/*  232 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public FlowInfo analyseCode(BlockScope currentScope, FlowContext flowContext, FlowInfo flowInfo) {
/*  242 */     return flowInfo;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public FlowInfo analyseCode(BlockScope currentScope, FlowContext flowContext, FlowInfo flowInfo, boolean valueRequired) {
/*  256 */     return analyseCode(currentScope, flowContext, flowInfo);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void updateFlowOnBooleanResult(FlowInfo flowInfo, boolean result) {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final boolean checkCastTypesCompatibility(Scope scope, TypeBinding castType, TypeBinding expressionType, Expression expression, boolean useAutoBoxing) {
/*      */     TypeBinding castElementType, exprElementType, bound;
/*      */     ReferenceBinding referenceBinding;
/*      */     TypeBinding typeBinding1;
/*      */     ReferenceBinding[] intersectingTypes;
/*      */     int i;
/*      */     byte b;
/*      */     int length, j;
/*      */     TypeBinding[] arrayOfTypeBinding;
/*  280 */     if (castType == null || expressionType == null) return true;
/*      */ 
/*      */ 
/*      */     
/*  284 */     boolean use15specifics = ((scope.compilerOptions()).sourceLevel >= 3211264L);
/*  285 */     boolean use17specifics = ((scope.compilerOptions()).sourceLevel >= 3342336L);
/*  286 */     useAutoBoxing &= use15specifics;
/*  287 */     if (castType.isBaseType()) {
/*  288 */       if (expressionType.isBaseType()) {
/*  289 */         if (TypeBinding.equalsEquals(expressionType, castType)) {
/*  290 */           if (expression != null) {
/*  291 */             this.constant = expression.constant;
/*      */           }
/*  293 */           tagAsUnnecessaryCast(scope, castType);
/*  294 */           return true;
/*      */         } 
/*  296 */         boolean necessary = false;
/*  297 */         if (expressionType.isCompatibleWith(castType) || (
/*  298 */           necessary = BaseTypeBinding.isNarrowing(castType.id, expressionType.id))) {
/*  299 */           if (expression != null) {
/*  300 */             expression.implicitConversion = (castType.id << 4) + expressionType.id;
/*  301 */             if (expression.constant != Constant.NotAConstant) {
/*  302 */               this.constant = expression.constant.castTo(expression.implicitConversion);
/*      */             }
/*      */           } 
/*  305 */           if (!necessary) tagAsUnnecessaryCast(scope, castType); 
/*  306 */           return true;
/*      */         } 
/*      */       } else {
/*  309 */         if (useAutoBoxing && use17specifics && castType.isPrimitiveType() && expressionType instanceof ReferenceBinding && 
/*  310 */           !expressionType.isBoxedPrimitiveType() && checkCastTypesCompatibility(scope, scope.boxing(castType), expressionType, expression, useAutoBoxing))
/*      */         {
/*      */           
/*  313 */           return true; } 
/*  314 */         if (useAutoBoxing && 
/*  315 */           scope.environment().computeBoxingType(expressionType).isCompatibleWith(castType)) {
/*  316 */           tagAsUnnecessaryCast(scope, castType);
/*  317 */           return true;
/*      */         } 
/*  319 */       }  return false;
/*  320 */     }  if (useAutoBoxing && 
/*  321 */       expressionType.isBaseType() && 
/*  322 */       scope.environment().computeBoxingType(expressionType).isCompatibleWith(castType)) {
/*  323 */       tagAsUnnecessaryCast(scope, castType);
/*  324 */       return true;
/*      */     } 
/*      */     
/*  327 */     if (castType.isIntersectionType18()) {
/*  328 */       ReferenceBinding[] arrayOfReferenceBinding = castType.getIntersectingTypes();
/*  329 */       for (int k = 0, m = arrayOfReferenceBinding.length; k < m; k++) {
/*  330 */         if (!checkCastTypesCompatibility(scope, (TypeBinding)arrayOfReferenceBinding[k], expressionType, expression, useAutoBoxing))
/*  331 */           return false; 
/*      */       } 
/*  333 */       return true;
/*      */     } 
/*      */     
/*  336 */     switch (expressionType.kind()) {
/*      */       
/*      */       case 132:
/*  339 */         if (expressionType == TypeBinding.NULL) {
/*  340 */           tagAsUnnecessaryCast(scope, castType);
/*  341 */           return true;
/*      */         } 
/*  343 */         return false;
/*      */       
/*      */       case 68:
/*  346 */         if (TypeBinding.equalsEquals(castType, expressionType)) {
/*  347 */           tagAsUnnecessaryCast(scope, castType);
/*  348 */           return true;
/*      */         } 
/*  350 */         switch (castType.kind()) {
/*      */           
/*      */           case 68:
/*  353 */             castElementType = ((ArrayBinding)castType).elementsType();
/*  354 */             exprElementType = ((ArrayBinding)expressionType).elementsType();
/*  355 */             if (exprElementType.isBaseType() || castElementType.isBaseType()) {
/*  356 */               if (TypeBinding.equalsEquals(castElementType, exprElementType)) {
/*  357 */                 tagAsNeedCheckCast();
/*  358 */                 return true;
/*      */               } 
/*  360 */               return false;
/*      */             } 
/*      */             
/*  363 */             return checkCastTypesCompatibility(scope, castElementType, exprElementType, expression, useAutoBoxing);
/*      */ 
/*      */           
/*      */           case 4100:
/*  367 */             typeBinding1 = expressionType.findSuperTypeOriginatingFrom(castType);
/*  368 */             if (typeBinding1 == null) {
/*  369 */               checkUnsafeCast(scope, castType, expressionType, (TypeBinding)null, true);
/*      */             }
/*  371 */             for (j = (arrayOfTypeBinding = ((TypeVariableBinding)castType).allUpperBounds()).length, b = 0; b < j; ) { TypeBinding typeBinding = arrayOfTypeBinding[b];
/*  372 */               if (!checkCastTypesCompatibility(scope, typeBinding, expressionType, expression, useAutoBoxing))
/*  373 */                 return false;  b++; }
/*      */             
/*  375 */             return true;
/*      */         } 
/*      */ 
/*      */         
/*  379 */         switch (castType.id) {
/*      */           case 36:
/*      */           case 37:
/*  382 */             tagAsNeedCheckCast();
/*  383 */             return true;
/*      */           case 1:
/*  385 */             tagAsUnnecessaryCast(scope, castType);
/*  386 */             return true;
/*      */         } 
/*  388 */         return false;
/*      */ 
/*      */ 
/*      */       
/*      */       case 4100:
/*  393 */         match = expressionType.findSuperTypeOriginatingFrom(castType);
/*  394 */         if (match == null)
/*      */         {
/*  396 */           if (castType instanceof TypeVariableBinding) {
/*      */             byte b1; int k; TypeBinding[] arrayOfTypeBinding1;
/*  398 */             for (k = (arrayOfTypeBinding1 = ((TypeVariableBinding)castType).allUpperBounds()).length, b1 = 0; b1 < k; ) { TypeBinding typeBinding = arrayOfTypeBinding1[b1];
/*  399 */               if (!checkCastTypesCompatibility(scope, typeBinding, expressionType, expression, useAutoBoxing))
/*  400 */                 return false;  b1++; }
/*      */           
/*      */           } else {
/*  403 */             byte b1; int k; TypeBinding[] arrayOfTypeBinding1; for (k = (arrayOfTypeBinding1 = ((TypeVariableBinding)expressionType).allUpperBounds()).length, b1 = 0; b1 < k; ) { TypeBinding typeBinding = arrayOfTypeBinding1[b1];
/*  404 */               if (!checkCastTypesCompatibility(scope, castType, typeBinding, expression, useAutoBoxing))
/*  405 */                 return false; 
/*      */               b1++; }
/*      */           
/*      */           } 
/*      */         }
/*  410 */         return checkUnsafeCast(scope, castType, expressionType, match, (match == null));
/*      */       
/*      */       case 516:
/*      */       case 8196:
/*  414 */         match = expressionType.findSuperTypeOriginatingFrom(castType);
/*  415 */         if (match != null) {
/*  416 */           return checkUnsafeCast(scope, castType, expressionType, match, false);
/*      */         }
/*  418 */         bound = ((WildcardBinding)expressionType).bound;
/*  419 */         if (bound == null) referenceBinding = scope.getJavaLangObject();
/*      */         
/*  421 */         return checkCastTypesCompatibility(scope, castType, (TypeBinding)referenceBinding, expression, useAutoBoxing);
/*      */       case 32772:
/*  423 */         intersectingTypes = expressionType.getIntersectingTypes();
/*  424 */         for (i = 0, length = intersectingTypes.length; i < length; i++) {
/*  425 */           if (checkCastTypesCompatibility(scope, castType, (TypeBinding)intersectingTypes[i], expression, useAutoBoxing))
/*  426 */             return true; 
/*      */         } 
/*  428 */         return false;
/*      */     } 
/*  430 */     if (expressionType.isInterface()) {
/*  431 */       switch (castType.kind()) {
/*      */         
/*      */         case 68:
/*  434 */           switch (expressionType.id) {
/*      */             case 36:
/*      */             case 37:
/*  437 */               tagAsNeedCheckCast();
/*  438 */               return true;
/*      */           } 
/*  440 */           return false;
/*      */ 
/*      */ 
/*      */         
/*      */         case 4100:
/*  445 */           match = expressionType.findSuperTypeOriginatingFrom(castType);
/*  446 */           if (match == null) {
/*  447 */             checkUnsafeCast(scope, castType, expressionType, (TypeBinding)null, true);
/*      */           }
/*      */           
/*  450 */           for (j = (arrayOfTypeBinding = ((TypeVariableBinding)castType).allUpperBounds()).length, length = 0; length < j; ) { TypeBinding upperBound = arrayOfTypeBinding[length];
/*  451 */             if (!checkCastTypesCompatibility(scope, upperBound, expressionType, expression, useAutoBoxing))
/*  452 */               return false;  length++; }
/*      */           
/*  454 */           return true;
/*      */       } 
/*      */       
/*  457 */       if (castType.isInterface()) {
/*      */         
/*  459 */         ReferenceBinding interfaceType = (ReferenceBinding)expressionType;
/*  460 */         match = interfaceType.findSuperTypeOriginatingFrom(castType);
/*  461 */         if (match != null) {
/*  462 */           return checkUnsafeCast(scope, castType, (TypeBinding)interfaceType, match, false);
/*      */         }
/*  464 */         tagAsNeedCheckCast();
/*  465 */         match = castType.findSuperTypeOriginatingFrom((TypeBinding)interfaceType);
/*  466 */         if (match != null) {
/*  467 */           return checkUnsafeCast(scope, castType, (TypeBinding)interfaceType, match, true);
/*      */         }
/*  469 */         if (use15specifics) {
/*  470 */           checkUnsafeCast(scope, castType, expressionType, (TypeBinding)null, true);
/*      */           
/*  472 */           if ((scope.compilerOptions()).complianceLevel < 3342336L) {
/*  473 */             if (interfaceType.hasIncompatibleSuperType((ReferenceBinding)castType)) {
/*  474 */               return false;
/*      */             }
/*  476 */           } else if (!castType.isRawType() && interfaceType.hasIncompatibleSuperType((ReferenceBinding)castType)) {
/*  477 */             return false;
/*      */           
/*      */           }
/*      */         
/*      */         }
/*      */         else {
/*      */           
/*  484 */           MethodBinding[] castTypeMethods = getAllOriginalInheritedMethods((ReferenceBinding)castType);
/*  485 */           MethodBinding[] expressionTypeMethods = getAllOriginalInheritedMethods((ReferenceBinding)expressionType);
/*  486 */           int exprMethodsLength = expressionTypeMethods.length;
/*  487 */           for (int k = 0, castMethodsLength = castTypeMethods.length; k < castMethodsLength; k++) {
/*  488 */             for (int m = 0; m < exprMethodsLength; m++) {
/*  489 */               if (TypeBinding.notEquals((castTypeMethods[k]).returnType, (expressionTypeMethods[m]).returnType) && 
/*  490 */                 CharOperation.equals((castTypeMethods[k]).selector, (expressionTypeMethods[m]).selector) && 
/*  491 */                 castTypeMethods[k].areParametersEqual(expressionTypeMethods[m])) {
/*  492 */                 return false;
/*      */               }
/*      */             } 
/*      */           } 
/*      */         } 
/*      */         
/*  498 */         return true;
/*      */       } 
/*      */       
/*  501 */       if (castType.id == 1) {
/*  502 */         tagAsUnnecessaryCast(scope, castType);
/*  503 */         return true;
/*      */       } 
/*      */       
/*  506 */       tagAsNeedCheckCast();
/*  507 */       match = castType.findSuperTypeOriginatingFrom(expressionType);
/*  508 */       if (match != null) {
/*  509 */         return checkUnsafeCast(scope, castType, expressionType, match, true);
/*      */       }
/*  511 */       if (((ReferenceBinding)castType).isFinal())
/*      */       {
/*  513 */         return false;
/*      */       }
/*  515 */       if (use15specifics) {
/*  516 */         checkUnsafeCast(scope, castType, expressionType, (TypeBinding)null, true);
/*      */         
/*  518 */         if ((scope.compilerOptions()).complianceLevel < 3342336L) {
/*  519 */           if (((ReferenceBinding)castType).hasIncompatibleSuperType((ReferenceBinding)expressionType)) {
/*  520 */             return false;
/*      */           }
/*  522 */         } else if (!castType.isRawType() && ((ReferenceBinding)castType).hasIncompatibleSuperType((ReferenceBinding)expressionType)) {
/*  523 */           return false;
/*      */         } 
/*      */       } 
/*  526 */       return true;
/*      */     } 
/*      */ 
/*      */     
/*  530 */     switch (castType.kind()) {
/*      */       
/*      */       case 68:
/*  533 */         if (expressionType.id == 1) {
/*  534 */           if (use15specifics) checkUnsafeCast(scope, castType, expressionType, expressionType, true); 
/*  535 */           tagAsNeedCheckCast();
/*  536 */           return true;
/*      */         } 
/*  538 */         return false;
/*      */ 
/*      */       
/*      */       case 4100:
/*  542 */         match = expressionType.findSuperTypeOriginatingFrom(castType);
/*  543 */         if (match == null) {
/*  544 */           checkUnsafeCast(scope, castType, expressionType, (TypeBinding)null, true);
/*      */         }
/*      */         
/*  547 */         for (j = (arrayOfTypeBinding = ((TypeVariableBinding)castType).allUpperBounds()).length, length = 0; length < j; ) { TypeBinding upperBound = arrayOfTypeBinding[length];
/*  548 */           if (!checkCastTypesCompatibility(scope, upperBound, expressionType, expression, useAutoBoxing))
/*  549 */             return false;  length++; }
/*      */         
/*  551 */         return true;
/*      */     } 
/*      */     
/*  554 */     if (castType.isInterface()) {
/*      */       
/*  556 */       ReferenceBinding refExprType = (ReferenceBinding)expressionType;
/*  557 */       match = refExprType.findSuperTypeOriginatingFrom(castType);
/*  558 */       if (match != null) {
/*  559 */         return checkUnsafeCast(scope, castType, expressionType, match, false);
/*      */       }
/*      */       
/*  562 */       if (refExprType.isFinal()) {
/*  563 */         return false;
/*      */       }
/*  565 */       tagAsNeedCheckCast();
/*  566 */       match = castType.findSuperTypeOriginatingFrom(expressionType);
/*  567 */       if (match != null) {
/*  568 */         return checkUnsafeCast(scope, castType, expressionType, match, true);
/*      */       }
/*  570 */       if (use15specifics) {
/*  571 */         checkUnsafeCast(scope, castType, expressionType, (TypeBinding)null, true);
/*      */         
/*  573 */         if ((scope.compilerOptions()).complianceLevel < 3342336L) {
/*  574 */           if (refExprType.hasIncompatibleSuperType((ReferenceBinding)castType)) {
/*  575 */             return false;
/*      */           }
/*  577 */         } else if (!castType.isRawType() && refExprType.hasIncompatibleSuperType((ReferenceBinding)castType)) {
/*  578 */           return false;
/*      */         } 
/*      */       } 
/*  581 */       return true;
/*      */     } 
/*      */     
/*  584 */     TypeBinding match = expressionType.findSuperTypeOriginatingFrom(castType);
/*  585 */     if (match != null) {
/*  586 */       if (expression != null && castType.id == 11) this.constant = expression.constant; 
/*  587 */       return checkUnsafeCast(scope, castType, expressionType, match, false);
/*      */     } 
/*  589 */     match = castType.findSuperTypeOriginatingFrom(expressionType);
/*  590 */     if (match != null) {
/*  591 */       tagAsNeedCheckCast();
/*  592 */       return checkUnsafeCast(scope, castType, expressionType, match, true);
/*      */     } 
/*  594 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean checkNPE(BlockScope scope, FlowContext flowContext, FlowInfo flowInfo, int ttlForFieldCheck) {
/*  618 */     boolean isNullable = false;
/*  619 */     if (this.resolvedType != null) {
/*      */       
/*  621 */       if ((this.resolvedType.tagBits & 0x100000000000000L) != 0L)
/*  622 */         return true; 
/*  623 */       if ((this.resolvedType.tagBits & 0x80000000000000L) != 0L) {
/*  624 */         isNullable = true;
/*      */       }
/*      */     } 
/*  627 */     LocalVariableBinding local = localVariableBinding();
/*  628 */     if (local != null && (
/*  629 */       local.type.tagBits & 0x2L) == 0L) {
/*      */       
/*  631 */       if ((this.bits & 0x20000) == 0) {
/*  632 */         flowContext.recordUsingNullReference((Scope)scope, local, this, 
/*  633 */             3, flowInfo);
/*      */         
/*  635 */         if (!flowInfo.isDefinitelyNonNull(local)) {
/*  636 */           flowContext.recordAbruptExit();
/*      */         }
/*      */       } 
/*  639 */       flowInfo.markAsComparedEqualToNonNull(local);
/*      */       
/*  641 */       flowContext.markFinallyNullStatus(local, 4);
/*  642 */       return true;
/*  643 */     }  if (isNullable) {
/*      */       
/*  645 */       scope.problemReporter().dereferencingNullableExpression(this);
/*  646 */       return true;
/*      */     } 
/*  648 */     return false;
/*      */   }
/*      */   public boolean checkNPE(BlockScope scope, FlowContext flowContext, FlowInfo flowInfo) {
/*  651 */     return checkNPE(scope, flowContext, flowInfo, 0);
/*      */   }
/*      */ 
/*      */   
/*      */   protected void checkNPEbyUnboxing(BlockScope scope, FlowContext flowContext, FlowInfo flowInfo) {
/*      */     int status;
/*  657 */     if ((this.implicitConversion & 0x400) != 0 && (
/*  658 */       this.bits & 0x20000) == 0 && (
/*  659 */       status = nullStatus(flowInfo, flowContext)) != 4)
/*      */     {
/*  661 */       flowContext.recordUnboxing((Scope)scope, this, status, flowInfo);
/*      */     }
/*      */   }
/*      */   
/*      */   public boolean checkUnsafeCast(Scope scope, TypeBinding castType, TypeBinding expressionType, TypeBinding match, boolean isNarrowing) {
/*  666 */     if (TypeBinding.equalsEquals(match, castType)) {
/*  667 */       if (!isNarrowing) tagAsUnnecessaryCast(scope, castType); 
/*  668 */       return true;
/*      */     } 
/*  670 */     if (match != null && (!castType.isReifiable() || !expressionType.isReifiable()) && (
/*  671 */       isNarrowing ? 
/*  672 */       match.isProvablyDistinct(expressionType) : 
/*  673 */       castType.isProvablyDistinct(match))) {
/*  674 */       return false;
/*      */     }
/*      */     
/*  677 */     if (!isNarrowing) tagAsUnnecessaryCast(scope, castType); 
/*  678 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void computeConversion(Scope scope, TypeBinding runtimeType, TypeBinding compileTimeType) {
/*  686 */     if (runtimeType == null || compileTimeType == null)
/*      */       return; 
/*  688 */     if (this.implicitConversion != 0) {
/*      */       return;
/*      */     }
/*      */ 
/*      */     
/*  693 */     if (runtimeType != TypeBinding.NULL && runtimeType.isBaseType())
/*  694 */     { if (!compileTimeType.isBaseType()) {
/*  695 */         TypeBinding unboxedType = scope.environment().computeBoxingType(compileTimeType);
/*  696 */         this.implicitConversion = 1024;
/*  697 */         scope.problemReporter().autoboxing(this, compileTimeType, runtimeType);
/*  698 */         compileTimeType = unboxedType;
/*      */       }  }
/*  700 */     else { if (compileTimeType != TypeBinding.NULL && compileTimeType.isBaseType()) {
/*  701 */         TypeBinding boxedType = scope.environment().computeBoxingType(runtimeType);
/*  702 */         if (TypeBinding.equalsEquals(boxedType, runtimeType))
/*  703 */           boxedType = compileTimeType; 
/*  704 */         if (boxedType.id > 33) {
/*  705 */           boxedType = compileTimeType;
/*      */         }
/*  707 */         this.implicitConversion = 0x200 | (boxedType.id << 4) + compileTimeType.id;
/*  708 */         scope.problemReporter().autoboxing(this, compileTimeType, scope.environment().computeBoxingType(boxedType)); return;
/*      */       } 
/*  710 */       if (this.constant != Constant.NotAConstant && this.constant.typeID() != 11) {
/*  711 */         this.implicitConversion = 512; return;
/*      */       }  }
/*      */     
/*      */     int compileTimeTypeID;
/*  715 */     if ((compileTimeTypeID = compileTimeType.id) >= 128) {
/*  716 */       compileTimeTypeID = ((compileTimeType.erasure()).id == 11) ? 11 : 1;
/*  717 */     } else if (runtimeType.isPrimitiveType() && compileTimeType instanceof ReferenceBinding && !compileTimeType.isBoxedPrimitiveType()) {
/*  718 */       compileTimeTypeID = 1;
/*      */     } 
/*      */     int runtimeTypeID;
/*  721 */     switch (runtimeTypeID = runtimeType.id) {
/*      */       case 2:
/*      */       case 3:
/*      */       case 4:
/*  725 */         if (compileTimeTypeID == 1) {
/*  726 */           this.implicitConversion |= (runtimeTypeID << 4) + compileTimeTypeID; break;
/*      */         } 
/*  728 */         this.implicitConversion |= 160 + compileTimeTypeID;
/*      */         break;
/*      */       
/*      */       case 5:
/*      */       case 7:
/*      */       case 8:
/*      */       case 9:
/*      */       case 10:
/*      */       case 11:
/*  737 */         this.implicitConversion |= (runtimeTypeID << 4) + compileTimeTypeID;
/*      */         break;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int computeNullStatus(int status, int combinedStatus) {
/*  747 */     if ((combinedStatus & 0x12) != 0)
/*  748 */       status |= 0x10; 
/*  749 */     if ((combinedStatus & 0x24) != 0)
/*  750 */       status |= 0x20; 
/*  751 */     if ((combinedStatus & 0x9) != 0)
/*  752 */       status |= 0x8; 
/*  753 */     return status;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void generateCode(BlockScope currentScope, CodeStream codeStream) {
/*  764 */     if ((this.bits & Integer.MIN_VALUE) == 0) {
/*      */       return;
/*      */     }
/*  767 */     generateCode(currentScope, codeStream, false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void generateCode(BlockScope currentScope, CodeStream codeStream, boolean valueRequired) {
/*  778 */     if (this.constant != Constant.NotAConstant) {
/*      */       
/*  780 */       int pc = codeStream.position;
/*  781 */       codeStream.generateConstant(this.constant, this.implicitConversion);
/*  782 */       codeStream.recordPositionsFrom(pc, this.sourceStart);
/*      */     } else {
/*      */       
/*  785 */       throw new ShouldNotImplement(Messages.ast_missingCode);
/*      */     } 
/*      */   }
/*      */   
/*      */   public void addPatternVariables(BlockScope scope, CodeStream codeStream) {}
/*      */   
/*      */   public LocalDeclaration getPatternVariable() {
/*  792 */     return null;
/*      */   }
/*      */   public void collectPatternVariablesToScope(LocalVariableBinding[] variables, BlockScope scope) {
/*  795 */     (new ASTVisitor()
/*      */       {
/*      */         LocalVariableBinding[] patternVariablesInScope;
/*      */         
/*      */         public boolean visit(Argument argument, BlockScope skope) {
/*  800 */           argument.addPatternVariablesWhenTrue(this.patternVariablesInScope);
/*  801 */           return true;
/*      */         }
/*      */ 
/*      */ 
/*      */         
/*      */         public boolean visit(QualifiedNameReference nameReference, BlockScope skope) {
/*  807 */           nameReference.addPatternVariablesWhenTrue(this.patternVariablesInScope);
/*  808 */           return true;
/*      */         }
/*      */ 
/*      */ 
/*      */         
/*      */         public boolean visit(SingleNameReference nameReference, BlockScope skope) {
/*  814 */           nameReference.addPatternVariablesWhenTrue(this.patternVariablesInScope);
/*  815 */           return true;
/*      */         }
/*      */         
/*      */         public void propagatePatternVariablesInScope(LocalVariableBinding[] vars, BlockScope skope) {
/*  819 */           this.patternVariablesInScope = vars;
/*  820 */           Expression.this.traverse(this, skope);
/*      */         }
/*  822 */       }).propagatePatternVariablesInScope(variables, scope);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void generateOptimizedBoolean(BlockScope currentScope, CodeStream codeStream, BranchLabel trueLabel, BranchLabel falseLabel, boolean valueRequired) {
/*  837 */     Constant cst = optimizedBooleanConstant();
/*  838 */     generateCode(currentScope, codeStream, (valueRequired && cst == Constant.NotAConstant));
/*  839 */     if (cst != Constant.NotAConstant && cst.typeID() == 5) {
/*  840 */       int pc = codeStream.position;
/*  841 */       if (cst.booleanValue()) {
/*      */         
/*  843 */         if (valueRequired && 
/*  844 */           falseLabel == null)
/*      */         {
/*  846 */           if (trueLabel != null) {
/*  847 */             codeStream.goto_(trueLabel);
/*      */           
/*      */           }
/*      */         }
/*      */       }
/*  852 */       else if (valueRequired && 
/*  853 */         falseLabel != null) {
/*      */         
/*  855 */         if (trueLabel == null) {
/*  856 */           codeStream.goto_(falseLabel);
/*      */         }
/*      */       } 
/*      */ 
/*      */       
/*  861 */       codeStream.recordPositionsFrom(pc, this.sourceStart);
/*      */       
/*      */       return;
/*      */     } 
/*  865 */     int position = codeStream.position;
/*  866 */     if (valueRequired) {
/*  867 */       if (falseLabel == null) {
/*  868 */         if (trueLabel != null)
/*      */         {
/*  870 */           codeStream.ifne(trueLabel);
/*      */         }
/*      */       }
/*  873 */       else if (trueLabel == null) {
/*      */         
/*  875 */         codeStream.ifeq(falseLabel);
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*  881 */     codeStream.recordPositionsFrom(position, this.sourceEnd);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void generateOptimizedStringConcatenation(BlockScope blockScope, CodeStream codeStream, int typeID) {
/*  890 */     if (typeID == 11 && this.constant != Constant.NotAConstant && this.constant.stringValue().length() == 0) {
/*      */       return;
/*      */     }
/*  893 */     generateCode(blockScope, codeStream, true);
/*  894 */     codeStream.invokeStringConcatenationAppendForType(typeID);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void generateOptimizedStringConcatenationCreation(BlockScope blockScope, CodeStream codeStream, int typeID) {
/*  902 */     codeStream.newStringContatenation();
/*  903 */     codeStream.dup();
/*  904 */     switch (typeID) {
/*      */ 
/*      */       
/*      */       case 0:
/*      */       case 1:
/*  909 */         codeStream.invokeStringConcatenationDefaultConstructor();
/*  910 */         generateCode(blockScope, codeStream, true);
/*  911 */         codeStream.invokeStringConcatenationAppendForType(1);
/*      */         return;
/*      */       case 11:
/*      */       case 12:
/*  915 */         if (this.constant != Constant.NotAConstant) {
/*  916 */           String stringValue = this.constant.stringValue();
/*  917 */           if (stringValue.length() == 0) {
/*  918 */             codeStream.invokeStringConcatenationDefaultConstructor();
/*      */             return;
/*      */           } 
/*  921 */           codeStream.ldc(stringValue);
/*      */           break;
/*      */         } 
/*  924 */         generateCode(blockScope, codeStream, true);
/*  925 */         codeStream.invokeStringValueOf(1);
/*      */         break;
/*      */       
/*      */       default:
/*  929 */         generateCode(blockScope, codeStream, true);
/*  930 */         codeStream.invokeStringValueOf(typeID); break;
/*      */     } 
/*  932 */     codeStream.invokeStringConcatenationStringConstructor();
/*      */   }
/*      */   
/*      */   private MethodBinding[] getAllOriginalInheritedMethods(ReferenceBinding binding) {
/*  936 */     ArrayList<MethodBinding> collector = new ArrayList<>();
/*  937 */     getAllInheritedMethods0(binding, collector);
/*  938 */     for (int i = 0, len = collector.size(); i < len; i++) {
/*  939 */       collector.set(i, ((MethodBinding)collector.get(i)).original());
/*      */     }
/*  941 */     return collector.<MethodBinding>toArray(new MethodBinding[collector.size()]);
/*      */   }
/*      */   
/*      */   private void getAllInheritedMethods0(ReferenceBinding binding, ArrayList<MethodBinding> collector) {
/*  945 */     if (!binding.isInterface())
/*  946 */       return;  MethodBinding[] methodBindings = binding.methods();
/*  947 */     for (int i = 0, max = methodBindings.length; i < max; i++) {
/*  948 */       collector.add(methodBindings[i]);
/*      */     }
/*  950 */     ReferenceBinding[] superInterfaces = binding.superInterfaces();
/*  951 */     for (int j = 0, k = superInterfaces.length; j < k; j++) {
/*  952 */       getAllInheritedMethods0(superInterfaces[j], collector);
/*      */     }
/*      */   }
/*      */   
/*      */   public static Binding getDirectBinding(Expression someExpression) {
/*  957 */     if ((someExpression.bits & 0x20000000) != 0) {
/*  958 */       return null;
/*      */     }
/*  960 */     if (someExpression instanceof SingleNameReference)
/*  961 */       return ((SingleNameReference)someExpression).binding; 
/*  962 */     if (someExpression instanceof FieldReference) {
/*  963 */       FieldReference fieldRef = (FieldReference)someExpression;
/*  964 */       if (fieldRef.receiver.isThis() && !(fieldRef.receiver instanceof QualifiedThisReference)) {
/*  965 */         return (Binding)fieldRef.binding;
/*      */       }
/*  967 */     } else if (someExpression instanceof Assignment) {
/*  968 */       Expression lhs = ((Assignment)someExpression).lhs;
/*  969 */       if ((lhs.bits & 0x2000) != 0)
/*      */       {
/*  971 */         return getDirectBinding(((Assignment)someExpression).lhs); } 
/*  972 */       if (someExpression instanceof PrefixExpression)
/*      */       {
/*  974 */         return getDirectBinding(((Assignment)someExpression).lhs);
/*      */       }
/*  976 */     } else if (someExpression instanceof QualifiedNameReference) {
/*  977 */       QualifiedNameReference qualifiedNameReference = (QualifiedNameReference)someExpression;
/*  978 */       if (qualifiedNameReference.indexOfFirstFieldBinding != 1 && 
/*  979 */         qualifiedNameReference.otherBindings == null)
/*      */       {
/*  981 */         return qualifiedNameReference.binding;
/*      */       }
/*  983 */     } else if (someExpression.isThis()) {
/*  984 */       return (Binding)someExpression.resolvedType;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  989 */     return null;
/*      */   }
/*      */   
/*      */   public boolean isCompactableOperation() {
/*  993 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isConstantValueOfTypeAssignableToType(TypeBinding constantType, TypeBinding targetType) {
/* 1002 */     if (this.constant == Constant.NotAConstant)
/* 1003 */       return false; 
/* 1004 */     if (TypeBinding.equalsEquals(constantType, targetType)) {
/* 1005 */       return true;
/*      */     }
/* 1007 */     if (BaseTypeBinding.isWidening(10, constantType.id) && 
/* 1008 */       BaseTypeBinding.isNarrowing(targetType.id, 10))
/*      */     {
/* 1010 */       return isConstantValueRepresentable(this.constant, constantType.id, targetType.id);
/*      */     }
/* 1012 */     return false;
/*      */   }
/*      */   
/*      */   public boolean isTypeReference() {
/* 1016 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public LocalVariableBinding localVariableBinding() {
/* 1024 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void markAsNonNull() {
/* 1033 */     this.bits |= 0x20000;
/*      */   }
/*      */ 
/*      */   
/*      */   public int nullStatus(FlowInfo flowInfo, FlowContext flowContext) {
/* 1038 */     return 4;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Constant optimizedBooleanConstant() {
/* 1049 */     return this.constant;
/*      */   }
/*      */   
/*      */   public boolean isPertinentToApplicability(TypeBinding targetType, MethodBinding method) {
/* 1053 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public TypeBinding postConversionType(Scope scope) {
/*      */     BaseTypeBinding baseTypeBinding;
/* 1062 */     TypeBinding typeBinding1, convertedType = this.resolvedType;
/* 1063 */     int runtimeType = (this.implicitConversion & 0xFF) >> 4;
/* 1064 */     switch (runtimeType) {
/*      */       case 5:
/* 1066 */         baseTypeBinding = TypeBinding.BOOLEAN;
/*      */         break;
/*      */       case 3:
/* 1069 */         baseTypeBinding = TypeBinding.BYTE;
/*      */         break;
/*      */       case 4:
/* 1072 */         baseTypeBinding = TypeBinding.SHORT;
/*      */         break;
/*      */       case 2:
/* 1075 */         baseTypeBinding = TypeBinding.CHAR;
/*      */         break;
/*      */       case 10:
/* 1078 */         baseTypeBinding = TypeBinding.INT;
/*      */         break;
/*      */       case 9:
/* 1081 */         baseTypeBinding = TypeBinding.FLOAT;
/*      */         break;
/*      */       case 7:
/* 1084 */         baseTypeBinding = TypeBinding.LONG;
/*      */         break;
/*      */       case 8:
/* 1087 */         baseTypeBinding = TypeBinding.DOUBLE;
/*      */         break;
/*      */     } 
/*      */     
/* 1091 */     if ((this.implicitConversion & 0x200) != 0) {
/* 1092 */       typeBinding1 = scope.environment().computeBoxingType((TypeBinding)baseTypeBinding);
/*      */     }
/* 1094 */     return typeBinding1;
/*      */   }
/*      */ 
/*      */   
/*      */   public StringBuffer print(int indent, StringBuffer output) {
/* 1099 */     printIndent(indent, output);
/* 1100 */     return printExpression(indent, output);
/*      */   }
/*      */ 
/*      */   
/*      */   public abstract StringBuffer printExpression(int paramInt, StringBuffer paramStringBuffer);
/*      */   
/*      */   public StringBuffer printStatement(int indent, StringBuffer output) {
/* 1107 */     return print(indent, output).append(";");
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void resolve(BlockScope scope) {
/* 1113 */     resolveType(scope);
/*      */   }
/*      */ 
/*      */   
/*      */   public TypeBinding resolveExpressionType(BlockScope scope) {
/* 1118 */     return resolveType(scope);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public TypeBinding resolveType(BlockScope scope) {
/* 1130 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public TypeBinding resolveType(ClassScope scope) {
/* 1142 */     return null;
/*      */   }
/*      */   
/*      */   public TypeBinding resolveTypeExpecting(BlockScope scope, TypeBinding expectedType) {
/* 1146 */     setExpectedType(expectedType);
/* 1147 */     TypeBinding expressionType = resolveType(scope);
/* 1148 */     if (expressionType == null) return null; 
/* 1149 */     if (TypeBinding.equalsEquals(expressionType, expectedType)) return expressionType;
/*      */     
/* 1151 */     if (!expressionType.isCompatibleWith(expectedType)) {
/* 1152 */       if (scope.isBoxingCompatibleWith(expressionType, expectedType)) {
/* 1153 */         computeConversion((Scope)scope, expectedType, expressionType);
/*      */       } else {
/* 1155 */         scope.problemReporter().typeMismatchError(expressionType, expectedType, this, null);
/* 1156 */         return null;
/*      */       } 
/*      */     }
/* 1159 */     return expressionType;
/*      */   }
/*      */   
/*      */   public Expression resolveExpressionExpecting(TypeBinding targetType, Scope scope, InferenceContext18 context) {
/* 1163 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean forcedToBeRaw(ReferenceContext referenceContext) {
/* 1172 */     if (this instanceof NameReference) {
/* 1173 */       Binding receiverBinding = ((NameReference)this).binding;
/* 1174 */       if (receiverBinding.isParameter() && (((LocalVariableBinding)receiverBinding).tagBits & 0x200L) != 0L)
/* 1175 */         return true; 
/* 1176 */       if (receiverBinding instanceof FieldBinding) {
/* 1177 */         FieldBinding field = (FieldBinding)receiverBinding;
/* 1178 */         if (field.type.isRawType()) {
/* 1179 */           if (referenceContext instanceof AbstractMethodDeclaration) {
/* 1180 */             AbstractMethodDeclaration methodDecl = (AbstractMethodDeclaration)referenceContext;
/* 1181 */             ReferenceBinding declaringClass = (methodDecl.binding != null) ? 
/* 1182 */               methodDecl.binding.declaringClass : 
/* 1183 */               methodDecl.scope.enclosingReceiverType();
/* 1184 */             if (TypeBinding.notEquals((TypeBinding)field.declaringClass, (TypeBinding)declaringClass)) {
/* 1185 */               return true;
/*      */             }
/* 1187 */           } else if (referenceContext instanceof TypeDeclaration) {
/* 1188 */             TypeDeclaration type = (TypeDeclaration)referenceContext;
/* 1189 */             if (TypeBinding.notEquals((TypeBinding)field.declaringClass, (TypeBinding)type.binding)) {
/* 1190 */               return true;
/*      */             }
/*      */           } 
/*      */         }
/*      */       } 
/* 1195 */     } else if (this instanceof MessageSend) {
/* 1196 */       if (!CharOperation.equals(((MessageSend)this).binding.declaringClass.getFileName(), 
/* 1197 */           referenceContext.compilationResult().getFileName())) {
/* 1198 */         return true;
/*      */       }
/* 1200 */     } else if (this instanceof FieldReference) {
/* 1201 */       FieldBinding field = ((FieldReference)this).binding;
/* 1202 */       if (!CharOperation.equals(field.declaringClass.getFileName(), 
/* 1203 */           referenceContext.compilationResult().getFileName())) {
/* 1204 */         return true;
/*      */       }
/* 1206 */       if (field.type.isRawType()) {
/* 1207 */         if (referenceContext instanceof AbstractMethodDeclaration) {
/* 1208 */           AbstractMethodDeclaration methodDecl = (AbstractMethodDeclaration)referenceContext;
/* 1209 */           ReferenceBinding declaringClass = (methodDecl.binding != null) ? 
/* 1210 */             methodDecl.binding.declaringClass : 
/* 1211 */             methodDecl.scope.enclosingReceiverType();
/* 1212 */           if (TypeBinding.notEquals((TypeBinding)field.declaringClass, (TypeBinding)declaringClass)) {
/* 1213 */             return true;
/*      */           }
/* 1215 */         } else if (referenceContext instanceof TypeDeclaration) {
/* 1216 */           TypeDeclaration type = (TypeDeclaration)referenceContext;
/* 1217 */           if (TypeBinding.notEquals((TypeBinding)field.declaringClass, (TypeBinding)type.binding)) {
/* 1218 */             return true;
/*      */           }
/*      */         } 
/*      */       }
/* 1222 */     } else if (this instanceof ConditionalExpression) {
/* 1223 */       ConditionalExpression ternary = (ConditionalExpression)this;
/* 1224 */       if (ternary.valueIfTrue.forcedToBeRaw(referenceContext) || ternary.valueIfFalse.forcedToBeRaw(referenceContext)) {
/* 1225 */         return true;
/*      */       }
/* 1227 */     } else if (this instanceof SwitchExpression) {
/* 1228 */       SwitchExpression se = (SwitchExpression)this;
/* 1229 */       for (Expression e : se.resultExpressions) {
/* 1230 */         if (e.forcedToBeRaw(referenceContext))
/* 1231 */           return true; 
/*      */       } 
/*      */     } 
/* 1234 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object reusableJSRTarget() {
/* 1243 */     if (this.constant != Constant.NotAConstant && (this.implicitConversion & 0x200) == 0) {
/* 1244 */       return this.constant;
/*      */     }
/* 1246 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setExpectedType(TypeBinding expectedType) {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setExpressionContext(ExpressionContext context) {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isCompatibleWith(TypeBinding left, Scope scope) {
/* 1266 */     return (this.resolvedType != null && this.resolvedType.isCompatibleWith(left, scope));
/*      */   }
/*      */   
/*      */   public boolean isBoxingCompatibleWith(TypeBinding left, Scope scope) {
/* 1270 */     return (this.resolvedType != null && isBoxingCompatible(this.resolvedType, left, this, scope));
/*      */   }
/*      */   
/*      */   public boolean sIsMoreSpecific(TypeBinding s, TypeBinding t, Scope scope) {
/* 1274 */     return s.isCompatibleWith(t, scope);
/*      */   }
/*      */   
/*      */   public boolean isExactMethodReference() {
/* 1278 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isPolyExpression() throws UnsupportedOperationException {
/* 1287 */     return false;
/*      */   }
/*      */   
/*      */   public boolean isPolyExpression(MethodBinding method) {
/* 1291 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void tagAsNeedCheckCast() {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void tagAsUnnecessaryCast(Scope scope, TypeBinding castType) {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Expression toTypeReference() {
/* 1317 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void traverse(ASTVisitor visitor, BlockScope scope) {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void traverse(ASTVisitor visitor, ClassScope scope) {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean statementExpression() {
/* 1340 */     return false;
/*      */   }
/*      */   
/*      */   public boolean isTrulyExpression() {
/* 1344 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public VariableBinding nullAnnotatedVariableBinding(boolean supportTypeAnnotations) {
/* 1355 */     return null;
/*      */   }
/*      */   
/*      */   public boolean isFunctionalType() {
/* 1359 */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   public Expression[] getPolyExpressions() {
/* 1364 */     (new Expression[1])[0] = this; return isPolyExpression() ? new Expression[1] : NO_EXPRESSIONS;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isPotentiallyCompatibleWith(TypeBinding targetType, Scope scope) {
/* 1370 */     return true;
/*      */   }
/*      */   
/*      */   protected Constant optimizedNullComparisonConstant() {
/* 1374 */     return Constant.NotAConstant;
/*      */   }
/*      */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\ast\Expression.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */