/*    */ package org.eclipse.jdt.internal.compiler.apt.model;
/*    */ 
/*    */ import org.eclipse.jdt.internal.compiler.apt.dispatch.BaseProcessingEnvImpl;
/*    */ import org.eclipse.jdt.internal.compiler.lookup.MethodBinding;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AnnotationMemberValue
/*    */   extends AnnotationValueImpl
/*    */ {
/*    */   private final MethodBinding _methodBinding;
/*    */   
/*    */   public AnnotationMemberValue(BaseProcessingEnvImpl env, Object value, MethodBinding methodBinding) {
/* 40 */     super(env, value, methodBinding.returnType);
/* 41 */     this._methodBinding = methodBinding;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public MethodBinding getMethodBinding() {
/* 48 */     return this._methodBinding;
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\apt\model\AnnotationMemberValue.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */