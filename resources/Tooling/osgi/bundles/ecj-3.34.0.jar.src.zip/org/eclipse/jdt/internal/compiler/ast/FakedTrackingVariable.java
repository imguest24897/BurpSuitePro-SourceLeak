/*      */ package org.eclipse.jdt.internal.compiler.ast;
/*      */ 
/*      */ import java.util.HashMap;
/*      */ import java.util.HashSet;
/*      */ import java.util.Iterator;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.Set;
/*      */ import org.eclipse.jdt.core.compiler.CharOperation;
/*      */ import org.eclipse.jdt.internal.compiler.ASTVisitor;
/*      */ import org.eclipse.jdt.internal.compiler.CompilationResult;
/*      */ import org.eclipse.jdt.internal.compiler.codegen.CodeStream;
/*      */ import org.eclipse.jdt.internal.compiler.flow.FinallyFlowContext;
/*      */ import org.eclipse.jdt.internal.compiler.flow.FlowContext;
/*      */ import org.eclipse.jdt.internal.compiler.flow.FlowInfo;
/*      */ import org.eclipse.jdt.internal.compiler.impl.Constant;
/*      */ import org.eclipse.jdt.internal.compiler.impl.ReferenceContext;
/*      */ import org.eclipse.jdt.internal.compiler.lookup.BlockScope;
/*      */ import org.eclipse.jdt.internal.compiler.lookup.LocalVariableBinding;
/*      */ import org.eclipse.jdt.internal.compiler.lookup.MethodBinding;
/*      */ import org.eclipse.jdt.internal.compiler.lookup.MethodScope;
/*      */ import org.eclipse.jdt.internal.compiler.lookup.ReferenceBinding;
/*      */ import org.eclipse.jdt.internal.compiler.lookup.Scope;
/*      */ import org.eclipse.jdt.internal.compiler.lookup.TypeBinding;
/*      */ import org.eclipse.jdt.internal.compiler.lookup.TypeConstants;
/*      */ import org.eclipse.jdt.internal.compiler.problem.ProblemReporter;
/*      */ import org.eclipse.jdt.internal.compiler.util.Util;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class FakedTrackingVariable
/*      */   extends LocalDeclaration
/*      */ {
/*   59 */   private static final char[] UNASSIGNED_CLOSEABLE_NAME = "<unassigned Closeable value>".toCharArray();
/*   60 */   private static final char[] UNASSIGNED_CLOSEABLE_NAME_TEMPLATE = "<unassigned Closeable value from line {0}>".toCharArray();
/*   61 */   private static final char[] TEMPLATE_ARGUMENT = "{0}".toCharArray();
/*      */ 
/*      */   
/*      */   private static final int CLOSE_SEEN = 1;
/*      */ 
/*      */   
/*      */   private static final int SHARED_WITH_OUTSIDE = 2;
/*      */ 
/*      */   
/*      */   private static final int OWNED_BY_OUTSIDE = 4;
/*      */ 
/*      */   
/*      */   private static final int CLOSED_IN_NESTED_METHOD = 8;
/*      */ 
/*      */   
/*      */   private static final int REPORTED_EXPLICIT_CLOSE = 16;
/*      */ 
/*      */   
/*      */   private static final int REPORTED_POTENTIAL_LEAK = 32;
/*      */ 
/*      */   
/*      */   private static final int REPORTED_DEFINITIVE_LEAK = 64;
/*      */ 
/*      */   
/*      */   private static final int FOREACH_ELEMENT_VAR = 128;
/*      */ 
/*      */   
/*      */   private static final int TWR_EFFECTIVELY_FINAL = 256;
/*      */   
/*      */   public MessageSend acquisition;
/*      */   
/*      */   public static boolean TEST_372319 = false;
/*      */   
/*   94 */   private int globalClosingState = 0;
/*      */   
/*      */   public LocalVariableBinding originalBinding;
/*      */   
/*      */   public FakedTrackingVariable innerTracker;
/*      */   
/*      */   public FakedTrackingVariable outerTracker;
/*      */   
/*      */   MethodScope methodScope;
/*      */   
/*      */   private HashMap recordedLocations;
/*      */   
/*      */   private ASTNode currentAssignment;
/*      */   
/*      */   private FlowContext tryContext;
/*      */ 
/*      */   
/*      */   public FakedTrackingVariable(LocalVariableBinding original, ASTNode location, FlowInfo flowInfo, FlowContext flowContext, int nullStatus) {
/*  112 */     super(original.name, location.sourceStart, location.sourceEnd);
/*  113 */     this.type = new SingleTypeReference(
/*  114 */         TypeConstants.OBJECT, (
/*  115 */         this.sourceStart << 32L) + this.sourceEnd);
/*  116 */     this.methodScope = original.declaringScope.methodScope();
/*  117 */     this.originalBinding = original;
/*      */     
/*  119 */     while (flowContext != null) {
/*  120 */       if (flowContext instanceof FinallyFlowContext) {
/*      */         
/*  122 */         this.tryContext = ((FinallyFlowContext)flowContext).tryContext;
/*      */         break;
/*      */       } 
/*  125 */       flowContext = flowContext.parent;
/*      */     } 
/*  127 */     resolve(original.declaringScope);
/*  128 */     if (nullStatus != 0) {
/*  129 */       flowInfo.markNullStatus(this.binding, nullStatus);
/*      */     }
/*      */   }
/*      */   
/*      */   private FakedTrackingVariable(BlockScope scope, ASTNode location, FlowInfo flowInfo, int nullStatus) {
/*  134 */     super(UNASSIGNED_CLOSEABLE_NAME, location.sourceStart, location.sourceEnd);
/*  135 */     this.type = new SingleTypeReference(
/*  136 */         TypeConstants.OBJECT, (
/*  137 */         this.sourceStart << 32L) + this.sourceEnd);
/*  138 */     this.methodScope = scope.methodScope();
/*  139 */     this.originalBinding = null;
/*  140 */     resolve(scope);
/*  141 */     if (nullStatus != 0)
/*  142 */       flowInfo.markNullStatus(this.binding, nullStatus); 
/*      */   }
/*      */   
/*      */   private void attachTo(LocalVariableBinding local) {
/*  146 */     local.closeTracker = this;
/*  147 */     this.originalBinding = local;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void generateCode(BlockScope currentScope, CodeStream codeStream) {}
/*      */ 
/*      */ 
/*      */   
/*      */   public void resolve(BlockScope scope) {
/*  157 */     this.binding = new LocalVariableBinding(
/*  158 */         this.name, 
/*  159 */         (TypeBinding)scope.getJavaLangObject(), 
/*  160 */         0, 
/*  161 */         false);
/*  162 */     this.binding.closeTracker = this;
/*  163 */     this.binding.declaringScope = scope;
/*  164 */     this.binding.setConstant(Constant.NotAConstant);
/*  165 */     this.binding.useFlag = 1;
/*      */     
/*  167 */     this.binding.id = scope.registerTrackingVariable(this);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static FakedTrackingVariable getCloseTrackingVariable(Expression expression, FlowInfo flowInfo, FlowContext flowContext) {
/*      */     while (true) {
/*  182 */       while (expression instanceof CastExpression)
/*  183 */         expression = ((CastExpression)expression).expression; 
/*  184 */       if (expression instanceof Assignment)
/*  185 */       { expression = ((Assignment)expression).expression; continue; }  break;
/*  186 */     }  if (expression instanceof ConditionalExpression) {
/*  187 */       FakedTrackingVariable falseTrackingVariable = getCloseTrackingVariable(((ConditionalExpression)expression).valueIfFalse, flowInfo, flowContext);
/*  188 */       if (falseTrackingVariable != null) {
/*  189 */         return falseTrackingVariable;
/*      */       }
/*  191 */       return getCloseTrackingVariable(((ConditionalExpression)expression).valueIfTrue, flowInfo, flowContext);
/*  192 */     }  if (expression instanceof SwitchExpression) {
/*  193 */       for (Expression re : ((SwitchExpression)expression).resultExpressions) {
/*  194 */         FakedTrackingVariable fakedTrackingVariable = getCloseTrackingVariable(re, flowInfo, flowContext);
/*  195 */         if (fakedTrackingVariable != null) {
/*  196 */           return fakedTrackingVariable;
/*      */         }
/*      */       } 
/*  199 */       return null;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  204 */     if (expression instanceof SingleNameReference)
/*  205 */     { SingleNameReference name = (SingleNameReference)expression;
/*  206 */       if (name.binding instanceof LocalVariableBinding) {
/*  207 */         LocalVariableBinding local = (LocalVariableBinding)name.binding;
/*  208 */         if (local.closeTracker != null)
/*  209 */           return local.closeTracker; 
/*  210 */         if (!isAnyCloseable(expression.resolvedType))
/*  211 */           return null; 
/*  212 */         if ((local.tagBits & 0x2000L) != 0L) {
/*  213 */           return null;
/*      */         }
/*      */         
/*  216 */         Statement location = local.declaration;
/*  217 */         local.closeTracker = new FakedTrackingVariable(local, location, flowInfo, flowContext, 1);
/*  218 */         if (local.isParameter()) {
/*  219 */           local.closeTracker.globalClosingState |= 0x4;
/*      */         }
/*      */         
/*  222 */         return local.closeTracker;
/*      */       }  }
/*  224 */     else { if (expression instanceof AllocationExpression)
/*      */       {
/*  226 */         return ((AllocationExpression)expression).closeTracker; } 
/*  227 */       if (expression instanceof MessageSend)
/*      */       {
/*  229 */         return ((MessageSend)expression).closeTracker; }  }
/*      */     
/*  231 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static FakedTrackingVariable preConnectTrackerAcrossAssignment(ASTNode location, LocalVariableBinding local, Expression rhs, FlowInfo flowInfo) {
/*  247 */     FakedTrackingVariable closeTracker = null;
/*  248 */     if (containsAllocation(rhs)) {
/*  249 */       closeTracker = local.closeTracker;
/*  250 */       if (closeTracker == null && 
/*  251 */         rhs.resolvedType != TypeBinding.NULL) {
/*  252 */         closeTracker = new FakedTrackingVariable(local, location, flowInfo, null, 1);
/*  253 */         if (local.isParameter()) {
/*  254 */           closeTracker.globalClosingState |= 0x4;
/*      */         }
/*      */       } 
/*      */       
/*  258 */       if (closeTracker != null) {
/*  259 */         closeTracker.currentAssignment = location;
/*  260 */         preConnectTrackerAcrossAssignment(location, local, flowInfo, closeTracker, rhs);
/*      */       } 
/*  262 */     } else if (rhs instanceof MessageSend) {
/*  263 */       closeTracker = local.closeTracker;
/*  264 */       if (closeTracker != null) {
/*  265 */         handleReassignment(flowInfo, closeTracker, location);
/*      */       }
/*  267 */       if (rhs.resolvedType != TypeBinding.NULL) {
/*  268 */         closeTracker = new FakedTrackingVariable(local, location, flowInfo, null, 1);
/*  269 */         closeTracker.currentAssignment = location;
/*  270 */         ((MessageSend)rhs).closeTracker = closeTracker;
/*      */       } 
/*      */     } 
/*  273 */     return closeTracker;
/*      */   }
/*      */   
/*      */   private static boolean containsAllocation(SwitchExpression location) {
/*  277 */     for (Expression re : location.resultExpressions) {
/*  278 */       if (containsAllocation(re))
/*  279 */         return true; 
/*      */     } 
/*  281 */     return false;
/*      */   }
/*      */   private static boolean containsAllocation(ASTNode location) {
/*  284 */     if (location instanceof AllocationExpression)
/*  285 */       return true; 
/*  286 */     if (location instanceof ConditionalExpression) {
/*  287 */       ConditionalExpression conditional = (ConditionalExpression)location;
/*  288 */       return !(!containsAllocation(conditional.valueIfTrue) && !containsAllocation(conditional.valueIfFalse));
/*  289 */     }  if (location instanceof SwitchExpression)
/*  290 */       return containsAllocation((SwitchExpression)location); 
/*  291 */     if (location instanceof CastExpression)
/*  292 */       return containsAllocation(((CastExpression)location).expression); 
/*  293 */     if (location instanceof MessageSend && 
/*  294 */       isFluentMethod(((MessageSend)location).binding)) {
/*  295 */       return containsAllocation(((MessageSend)location).receiver);
/*      */     }
/*  297 */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   private static void preConnectTrackerAcrossAssignment(ASTNode location, LocalVariableBinding local, FlowInfo flowInfo, FakedTrackingVariable closeTracker, Expression expression) {
/*  302 */     if (expression instanceof AllocationExpression) {
/*  303 */       preConnectTrackerAcrossAssignment(location, local, flowInfo, (AllocationExpression)expression, closeTracker);
/*  304 */     } else if (expression instanceof ConditionalExpression) {
/*  305 */       preConnectTrackerAcrossAssignment(location, local, flowInfo, (ConditionalExpression)expression, closeTracker);
/*  306 */     } else if (expression instanceof SwitchExpression) {
/*  307 */       preConnectTrackerAcrossAssignment(location, local, flowInfo, (SwitchExpression)expression, closeTracker);
/*  308 */     } else if (expression instanceof CastExpression) {
/*  309 */       preConnectTrackerAcrossAssignment(location, local, ((CastExpression)expression).expression, flowInfo);
/*  310 */     } else if (expression instanceof MessageSend && 
/*  311 */       isFluentMethod(((MessageSend)expression).binding)) {
/*  312 */       preConnectTrackerAcrossAssignment(location, local, ((MessageSend)expression).receiver, flowInfo);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   private static void preConnectTrackerAcrossAssignment(ASTNode location, LocalVariableBinding local, FlowInfo flowInfo, ConditionalExpression conditional, FakedTrackingVariable closeTracker) {
/*  318 */     preConnectTrackerAcrossAssignment(location, local, flowInfo, closeTracker, conditional.valueIfFalse);
/*  319 */     preConnectTrackerAcrossAssignment(location, local, flowInfo, closeTracker, conditional.valueIfTrue);
/*      */   }
/*      */ 
/*      */   
/*      */   private static void preConnectTrackerAcrossAssignment(ASTNode location, LocalVariableBinding local, FlowInfo flowInfo, SwitchExpression se, FakedTrackingVariable closeTracker) {
/*  324 */     for (Expression re : se.resultExpressions) {
/*  325 */       preConnectTrackerAcrossAssignment(location, local, flowInfo, closeTracker, re);
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   private static void preConnectTrackerAcrossAssignment(ASTNode location, LocalVariableBinding local, FlowInfo flowInfo, AllocationExpression allocationExpression, FakedTrackingVariable closeTracker) {
/*  331 */     allocationExpression.closeTracker = closeTracker;
/*  332 */     if (allocationExpression.arguments != null && allocationExpression.arguments.length > 0) {
/*      */       
/*  334 */       FakedTrackingVariable inner = preConnectTrackerAcrossAssignment(location, local, allocationExpression.arguments[0], flowInfo);
/*  335 */       if (inner != closeTracker && closeTracker.innerTracker == null) {
/*  336 */         closeTracker.innerTracker = inner;
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void analyseCloseableAllocation(BlockScope scope, FlowInfo flowInfo, AllocationExpression allocation) {
/*  346 */     if (((ReferenceBinding)allocation.resolvedType).hasTypeBit(8)) {
/*      */       
/*  348 */       if (allocation.closeTracker != null) {
/*  349 */         allocation.closeTracker.withdraw();
/*  350 */         allocation.closeTracker = null;
/*      */       } 
/*  352 */     } else if (((ReferenceBinding)allocation.resolvedType).hasTypeBit(4)) {
/*  353 */       boolean isWrapper = true;
/*  354 */       if (allocation.arguments != null && allocation.arguments.length > 0) {
/*      */         
/*  356 */         FakedTrackingVariable innerTracker = findCloseTracker(scope, flowInfo, allocation.arguments[0]);
/*  357 */         if (innerTracker != null) {
/*  358 */           FakedTrackingVariable currentInner = innerTracker;
/*      */           while (true) {
/*  360 */             if (currentInner == allocation.closeTracker) {
/*      */               return;
/*      */             }
/*  363 */             currentInner = currentInner.innerTracker;
/*  364 */             if (currentInner == null) {
/*  365 */               int newStatus = 2;
/*  366 */               if (allocation.closeTracker == null) {
/*  367 */                 allocation.closeTracker = new FakedTrackingVariable(scope, allocation, flowInfo, 1);
/*      */               }
/*  369 */               else if (scope.finallyInfo != null) {
/*      */                 
/*  371 */                 int finallyStatus = scope.finallyInfo.nullStatus(allocation.closeTracker.binding);
/*  372 */                 if (finallyStatus != 1) {
/*  373 */                   newStatus = finallyStatus;
/*      */                 }
/*      */               } 
/*  376 */               if (allocation.closeTracker.innerTracker != null && allocation.closeTracker.innerTracker != innerTracker) {
/*  377 */                 innerTracker = pickMoreUnsafe(allocation.closeTracker.innerTracker, innerTracker, scope, flowInfo);
/*      */               }
/*  379 */               allocation.closeTracker.innerTracker = innerTracker;
/*  380 */               innerTracker.outerTracker = allocation.closeTracker;
/*  381 */               flowInfo.markNullStatus(allocation.closeTracker.binding, newStatus);
/*  382 */               if (newStatus != 2) {
/*      */                 
/*  384 */                 FakedTrackingVariable currentTracker = innerTracker;
/*  385 */                 while (currentTracker != null) {
/*  386 */                   flowInfo.markNullStatus(currentTracker.binding, newStatus);
/*  387 */                   currentTracker.globalClosingState |= allocation.closeTracker.globalClosingState;
/*  388 */                   currentTracker = currentTracker.innerTracker;
/*      */                 } 
/*      */               }  return;
/*      */             } 
/*      */           } 
/*  393 */         }  if (!isAnyCloseable((allocation.arguments[0]).resolvedType)) {
/*  394 */           isWrapper = false;
/*      */         }
/*      */       } else {
/*      */         
/*  398 */         isWrapper = false;
/*      */       } 
/*      */       
/*  401 */       if (isWrapper) {
/*      */         
/*  403 */         if (allocation.closeTracker != null) {
/*  404 */           allocation.closeTracker.withdraw();
/*  405 */           allocation.closeTracker = null;
/*      */         } 
/*      */       } else {
/*      */         
/*  409 */         handleRegularResource(scope, flowInfo, allocation);
/*      */       } 
/*      */     } else {
/*  412 */       handleRegularResource(scope, flowInfo, allocation);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static FlowInfo analyseCloseableAcquisition(BlockScope scope, FlowInfo flowInfo, MessageSend acquisition) {
/*  421 */     if (isFluentMethod(acquisition.binding)) {
/*      */       
/*  423 */       acquisition.closeTracker = findCloseTracker(scope, flowInfo, acquisition.receiver);
/*  424 */       return flowInfo;
/*      */     } 
/*      */     
/*  427 */     if (((ReferenceBinding)acquisition.resolvedType).hasTypeBit(8)) {
/*      */       
/*  429 */       if (acquisition.closeTracker != null) {
/*  430 */         acquisition.closeTracker.withdraw();
/*  431 */         acquisition.closeTracker = null;
/*      */       } 
/*  433 */       return flowInfo;
/*      */     } 
/*  435 */     FakedTrackingVariable tracker = acquisition.closeTracker;
/*  436 */     if (tracker != null) {
/*      */       
/*  438 */       tracker.withdraw();
/*  439 */       acquisition.closeTracker = null;
/*  440 */       return flowInfo;
/*      */     } 
/*  442 */     tracker = new FakedTrackingVariable(scope, acquisition, flowInfo, 1);
/*  443 */     acquisition.closeTracker = tracker;
/*      */     
/*  445 */     tracker.acquisition = acquisition;
/*  446 */     FlowInfo outsideInfo = flowInfo.copy();
/*  447 */     outsideInfo.markAsDefinitelyNonNull(tracker.binding);
/*  448 */     flowInfo.markAsDefinitelyNull(tracker.binding);
/*  449 */     return FlowInfo.conditional(outsideInfo, flowInfo);
/*      */   }
/*      */ 
/*      */   
/*      */   private static boolean isFluentMethod(MethodBinding binding) {
/*  454 */     if (binding.isStatic())
/*  455 */       return false; 
/*  456 */     ReferenceBinding declaringClass = binding.declaringClass;
/*  457 */     if (declaringClass.equals(binding.returnType)) {
/*  458 */       byte b; int i; char[][][] arrayOfChar; for (i = (arrayOfChar = TypeConstants.FLUENT_RESOURCE_CLASSES).length, b = 0; b < i; ) { char[][] compoundName = arrayOfChar[b];
/*  459 */         if (CharOperation.equals(compoundName, declaringClass.compoundName))
/*  460 */           return true;  b++; }
/*      */     
/*      */     } 
/*  463 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private static FakedTrackingVariable pickMoreUnsafe(FakedTrackingVariable tracker1, FakedTrackingVariable tracker2, BlockScope scope, FlowInfo info) {
/*  469 */     int status1 = info.nullStatus(tracker1.binding);
/*  470 */     int status2 = info.nullStatus(tracker2.binding);
/*  471 */     if (status1 == 2 || status2 == 4) return pick(tracker1, tracker2, scope); 
/*  472 */     if (status1 == 4 || status2 == 2) return pick(tracker2, tracker1, scope); 
/*  473 */     if ((status1 & 0x10) != 0) return pick(tracker1, tracker2, scope); 
/*  474 */     if ((status2 & 0x10) != 0) return pick(tracker2, tracker1, scope); 
/*  475 */     return pick(tracker1, tracker2, scope);
/*      */   }
/*      */   
/*      */   private static FakedTrackingVariable pick(FakedTrackingVariable tracker1, FakedTrackingVariable tracker2, BlockScope scope) {
/*  479 */     tracker2.withdraw();
/*  480 */     return tracker1;
/*      */   }
/*      */   
/*      */   private static void handleRegularResource(BlockScope scope, FlowInfo flowInfo, AllocationExpression allocation) {
/*  484 */     FakedTrackingVariable presetTracker = allocation.closeTracker;
/*  485 */     if (presetTracker != null && presetTracker.originalBinding != null) {
/*      */ 
/*      */       
/*  488 */       handleReassignment(flowInfo, presetTracker, presetTracker.currentAssignment);
/*      */     } else {
/*  490 */       allocation.closeTracker = new FakedTrackingVariable(scope, allocation, flowInfo, 1);
/*      */     } 
/*  492 */     flowInfo.markAsDefinitelyNull(allocation.closeTracker.binding);
/*      */   }
/*      */   
/*      */   private static void handleReassignment(FlowInfo flowInfo, FakedTrackingVariable existingTracker, ASTNode location) {
/*  496 */     int closeStatus = flowInfo.nullStatus(existingTracker.binding);
/*  497 */     if (closeStatus != 4 && 
/*  498 */       closeStatus != 1 && 
/*  499 */       !flowInfo.isDefinitelyNull(existingTracker.originalBinding) && 
/*  500 */       !(location instanceof LocalDeclaration)) {
/*  501 */       existingTracker.recordErrorLocation(location, closeStatus);
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   private static FakedTrackingVariable findCloseTracker(BlockScope scope, FlowInfo flowInfo, Expression arg) {
/*  507 */     while (arg instanceof Assignment) {
/*  508 */       Assignment assign = (Assignment)arg;
/*  509 */       LocalVariableBinding innerLocal = assign.localVariableBinding();
/*  510 */       if (innerLocal != null)
/*      */       {
/*  512 */         return innerLocal.closeTracker;
/*      */       }
/*  514 */       arg = assign.expression;
/*      */     } 
/*      */     
/*  517 */     if (arg instanceof SingleNameReference) {
/*      */       
/*  519 */       LocalVariableBinding local = arg.localVariableBinding();
/*  520 */       if (local != null)
/*  521 */         return local.closeTracker; 
/*      */     } else {
/*  523 */       if (arg instanceof AllocationExpression)
/*      */       {
/*  525 */         return ((AllocationExpression)arg).closeTracker; } 
/*  526 */       if (arg instanceof MessageSend)
/*  527 */         return ((MessageSend)arg).closeTracker; 
/*      */     } 
/*  529 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void handleResourceAssignment(BlockScope scope, FlowInfo upstreamInfo, FlowInfo flowInfo, FlowContext flowContext, ASTNode location, Expression rhs, LocalVariableBinding local) {
/*      */     // Byte code:
/*      */     //   0: aconst_null
/*      */     //   1: astore #7
/*      */     //   3: aconst_null
/*      */     //   4: astore #8
/*      */     //   6: aload #6
/*      */     //   8: getfield closeTracker : Lorg/eclipse/jdt/internal/compiler/ast/FakedTrackingVariable;
/*      */     //   11: ifnull -> 45
/*      */     //   14: aload #6
/*      */     //   16: getfield closeTracker : Lorg/eclipse/jdt/internal/compiler/ast/FakedTrackingVariable;
/*      */     //   19: astore #7
/*      */     //   21: aload_1
/*      */     //   22: aload #6
/*      */     //   24: invokevirtual nullStatus : (Lorg/eclipse/jdt/internal/compiler/lookup/LocalVariableBinding;)I
/*      */     //   27: istore #9
/*      */     //   29: iload #9
/*      */     //   31: iconst_2
/*      */     //   32: if_icmpeq -> 45
/*      */     //   35: iload #9
/*      */     //   37: iconst_1
/*      */     //   38: if_icmpeq -> 45
/*      */     //   41: aload #7
/*      */     //   43: astore #8
/*      */     //   45: aload #5
/*      */     //   47: getfield resolvedType : Lorg/eclipse/jdt/internal/compiler/lookup/TypeBinding;
/*      */     //   50: getstatic org/eclipse/jdt/internal/compiler/lookup/TypeBinding.NULL : Lorg/eclipse/jdt/internal/compiler/lookup/NullTypeBinding;
/*      */     //   53: if_acmpeq -> 356
/*      */     //   56: aload #5
/*      */     //   58: aload_2
/*      */     //   59: aload_3
/*      */     //   60: invokestatic getCloseTrackingVariable : (Lorg/eclipse/jdt/internal/compiler/ast/Expression;Lorg/eclipse/jdt/internal/compiler/flow/FlowInfo;Lorg/eclipse/jdt/internal/compiler/flow/FlowContext;)Lorg/eclipse/jdt/internal/compiler/ast/FakedTrackingVariable;
/*      */     //   63: astore #9
/*      */     //   65: aload #9
/*      */     //   67: ifnull -> 211
/*      */     //   70: aload #6
/*      */     //   72: getfield closeTracker : Lorg/eclipse/jdt/internal/compiler/ast/FakedTrackingVariable;
/*      */     //   75: ifnonnull -> 119
/*      */     //   78: aload #9
/*      */     //   80: getfield originalBinding : Lorg/eclipse/jdt/internal/compiler/lookup/LocalVariableBinding;
/*      */     //   83: ifnull -> 93
/*      */     //   86: aload #6
/*      */     //   88: aload #9
/*      */     //   90: putfield closeTracker : Lorg/eclipse/jdt/internal/compiler/ast/FakedTrackingVariable;
/*      */     //   93: aload #9
/*      */     //   95: getfield currentAssignment : Lorg/eclipse/jdt/internal/compiler/ast/ASTNode;
/*      */     //   98: aload #4
/*      */     //   100: if_acmpne -> 356
/*      */     //   103: aload #9
/*      */     //   105: dup
/*      */     //   106: getfield globalClosingState : I
/*      */     //   109: sipush #-135
/*      */     //   112: iand
/*      */     //   113: putfield globalClosingState : I
/*      */     //   116: goto -> 356
/*      */     //   119: aload #5
/*      */     //   121: instanceof org/eclipse/jdt/internal/compiler/ast/AllocationExpression
/*      */     //   124: ifne -> 151
/*      */     //   127: aload #5
/*      */     //   129: instanceof org/eclipse/jdt/internal/compiler/ast/ConditionalExpression
/*      */     //   132: ifne -> 151
/*      */     //   135: aload #5
/*      */     //   137: instanceof org/eclipse/jdt/internal/compiler/ast/SwitchExpression
/*      */     //   140: ifne -> 151
/*      */     //   143: aload #5
/*      */     //   145: instanceof org/eclipse/jdt/internal/compiler/ast/MessageSend
/*      */     //   148: ifeq -> 201
/*      */     //   151: aload #9
/*      */     //   153: aload #8
/*      */     //   155: if_acmpne -> 159
/*      */     //   158: return
/*      */     //   159: aload #6
/*      */     //   161: getfield closeTracker : Lorg/eclipse/jdt/internal/compiler/ast/FakedTrackingVariable;
/*      */     //   164: aload #9
/*      */     //   166: if_acmpne -> 201
/*      */     //   169: aload #9
/*      */     //   171: getfield globalClosingState : I
/*      */     //   174: iconst_4
/*      */     //   175: iand
/*      */     //   176: ifeq -> 201
/*      */     //   179: aload #6
/*      */     //   181: new org/eclipse/jdt/internal/compiler/ast/FakedTrackingVariable
/*      */     //   184: dup
/*      */     //   185: aload #6
/*      */     //   187: aload #4
/*      */     //   189: aload_2
/*      */     //   190: aload_3
/*      */     //   191: iconst_2
/*      */     //   192: invokespecial <init> : (Lorg/eclipse/jdt/internal/compiler/lookup/LocalVariableBinding;Lorg/eclipse/jdt/internal/compiler/ast/ASTNode;Lorg/eclipse/jdt/internal/compiler/flow/FlowInfo;Lorg/eclipse/jdt/internal/compiler/flow/FlowContext;I)V
/*      */     //   195: putfield closeTracker : Lorg/eclipse/jdt/internal/compiler/ast/FakedTrackingVariable;
/*      */     //   198: goto -> 356
/*      */     //   201: aload #9
/*      */     //   203: aload #6
/*      */     //   205: invokevirtual attachTo : (Lorg/eclipse/jdt/internal/compiler/lookup/LocalVariableBinding;)V
/*      */     //   208: goto -> 356
/*      */     //   211: aload #7
/*      */     //   213: ifnull -> 309
/*      */     //   216: aload_3
/*      */     //   217: astore #10
/*      */     //   219: aload #7
/*      */     //   221: getfield tryContext : Lorg/eclipse/jdt/internal/compiler/flow/FlowContext;
/*      */     //   224: ifnull -> 255
/*      */     //   227: goto -> 250
/*      */     //   230: aload #7
/*      */     //   232: getfield tryContext : Lorg/eclipse/jdt/internal/compiler/flow/FlowContext;
/*      */     //   235: aload #10
/*      */     //   237: if_acmpne -> 243
/*      */     //   240: goto -> 356
/*      */     //   243: aload #10
/*      */     //   245: getfield parent : Lorg/eclipse/jdt/internal/compiler/flow/FlowContext;
/*      */     //   248: astore #10
/*      */     //   250: aload #10
/*      */     //   252: ifnonnull -> 230
/*      */     //   255: aload #7
/*      */     //   257: getfield globalClosingState : I
/*      */     //   260: sipush #134
/*      */     //   263: iand
/*      */     //   264: ifne -> 288
/*      */     //   267: aload_2
/*      */     //   268: aload #7
/*      */     //   270: getfield binding : Lorg/eclipse/jdt/internal/compiler/lookup/LocalVariableBinding;
/*      */     //   273: invokevirtual hasNullInfoFor : (Lorg/eclipse/jdt/internal/compiler/lookup/LocalVariableBinding;)Z
/*      */     //   276: ifeq -> 288
/*      */     //   279: aload_2
/*      */     //   280: aload #7
/*      */     //   282: getfield binding : Lorg/eclipse/jdt/internal/compiler/lookup/LocalVariableBinding;
/*      */     //   285: invokevirtual markAsDefinitelyNull : (Lorg/eclipse/jdt/internal/compiler/lookup/LocalVariableBinding;)V
/*      */     //   288: aload #6
/*      */     //   290: aload_2
/*      */     //   291: aload_3
/*      */     //   292: aload #6
/*      */     //   294: aload #4
/*      */     //   296: aload #5
/*      */     //   298: aload #7
/*      */     //   300: invokestatic analyseCloseableExpression : (Lorg/eclipse/jdt/internal/compiler/flow/FlowInfo;Lorg/eclipse/jdt/internal/compiler/flow/FlowContext;Lorg/eclipse/jdt/internal/compiler/lookup/LocalVariableBinding;Lorg/eclipse/jdt/internal/compiler/ast/ASTNode;Lorg/eclipse/jdt/internal/compiler/ast/Expression;Lorg/eclipse/jdt/internal/compiler/ast/FakedTrackingVariable;)Lorg/eclipse/jdt/internal/compiler/ast/FakedTrackingVariable;
/*      */     //   303: putfield closeTracker : Lorg/eclipse/jdt/internal/compiler/ast/FakedTrackingVariable;
/*      */     //   306: goto -> 356
/*      */     //   309: aload_2
/*      */     //   310: aload_3
/*      */     //   311: aload #6
/*      */     //   313: aload #4
/*      */     //   315: aload #5
/*      */     //   317: aconst_null
/*      */     //   318: invokestatic analyseCloseableExpression : (Lorg/eclipse/jdt/internal/compiler/flow/FlowInfo;Lorg/eclipse/jdt/internal/compiler/flow/FlowContext;Lorg/eclipse/jdt/internal/compiler/lookup/LocalVariableBinding;Lorg/eclipse/jdt/internal/compiler/ast/ASTNode;Lorg/eclipse/jdt/internal/compiler/ast/Expression;Lorg/eclipse/jdt/internal/compiler/ast/FakedTrackingVariable;)Lorg/eclipse/jdt/internal/compiler/ast/FakedTrackingVariable;
/*      */     //   321: astore #9
/*      */     //   323: aload #9
/*      */     //   325: ifnull -> 356
/*      */     //   328: aload #9
/*      */     //   330: aload #6
/*      */     //   332: invokevirtual attachTo : (Lorg/eclipse/jdt/internal/compiler/lookup/LocalVariableBinding;)V
/*      */     //   335: aload #9
/*      */     //   337: getfield globalClosingState : I
/*      */     //   340: sipush #134
/*      */     //   343: iand
/*      */     //   344: ifne -> 356
/*      */     //   347: aload_2
/*      */     //   348: aload #9
/*      */     //   350: getfield binding : Lorg/eclipse/jdt/internal/compiler/lookup/LocalVariableBinding;
/*      */     //   353: invokevirtual markAsDefinitelyNull : (Lorg/eclipse/jdt/internal/compiler/lookup/LocalVariableBinding;)V
/*      */     //   356: aload #8
/*      */     //   358: ifnull -> 428
/*      */     //   361: aload #8
/*      */     //   363: getfield innerTracker : Lorg/eclipse/jdt/internal/compiler/ast/FakedTrackingVariable;
/*      */     //   366: ifnull -> 402
/*      */     //   369: aload #8
/*      */     //   371: getfield innerTracker : Lorg/eclipse/jdt/internal/compiler/ast/FakedTrackingVariable;
/*      */     //   374: getfield binding : Lorg/eclipse/jdt/internal/compiler/lookup/LocalVariableBinding;
/*      */     //   377: getfield declaringScope : Lorg/eclipse/jdt/internal/compiler/lookup/BlockScope;
/*      */     //   380: aload_0
/*      */     //   381: if_acmpne -> 402
/*      */     //   384: aload #8
/*      */     //   386: getfield innerTracker : Lorg/eclipse/jdt/internal/compiler/ast/FakedTrackingVariable;
/*      */     //   389: aconst_null
/*      */     //   390: putfield outerTracker : Lorg/eclipse/jdt/internal/compiler/ast/FakedTrackingVariable;
/*      */     //   393: aload_0
/*      */     //   394: aload #8
/*      */     //   396: invokevirtual pruneWrapperTrackingVar : (Lorg/eclipse/jdt/internal/compiler/ast/FakedTrackingVariable;)V
/*      */     //   399: goto -> 428
/*      */     //   402: aload_1
/*      */     //   403: aload #8
/*      */     //   405: getfield binding : Lorg/eclipse/jdt/internal/compiler/lookup/LocalVariableBinding;
/*      */     //   408: invokevirtual nullStatus : (Lorg/eclipse/jdt/internal/compiler/lookup/LocalVariableBinding;)I
/*      */     //   411: istore #9
/*      */     //   413: iload #9
/*      */     //   415: iconst_4
/*      */     //   416: if_icmpeq -> 428
/*      */     //   419: aload #8
/*      */     //   421: aload #4
/*      */     //   423: iload #9
/*      */     //   425: invokevirtual recordErrorLocation : (Lorg/eclipse/jdt/internal/compiler/ast/ASTNode;I)V
/*      */     //   428: return
/*      */     // Line number table:
/*      */     //   Java source line number -> byte code offset
/*      */     //   #547	-> 0
/*      */     //   #548	-> 3
/*      */     //   #549	-> 6
/*      */     //   #551	-> 14
/*      */     //   #552	-> 21
/*      */     //   #553	-> 29
/*      */     //   #554	-> 41
/*      */     //   #558	-> 45
/*      */     //   #560	-> 56
/*      */     //   #561	-> 65
/*      */     //   #562	-> 70
/*      */     //   #564	-> 78
/*      */     //   #565	-> 86
/*      */     //   #566	-> 93
/*      */     //   #569	-> 103
/*      */     //   #571	-> 116
/*      */     //   #572	-> 119
/*      */     //   #573	-> 151
/*      */     //   #574	-> 158
/*      */     //   #575	-> 159
/*      */     //   #576	-> 169
/*      */     //   #579	-> 179
/*      */     //   #581	-> 198
/*      */     //   #584	-> 201
/*      */     //   #587	-> 208
/*      */     //   #588	-> 216
/*      */     //   #590	-> 219
/*      */     //   #591	-> 227
/*      */     //   #592	-> 230
/*      */     //   #596	-> 240
/*      */     //   #598	-> 243
/*      */     //   #591	-> 250
/*      */     //   #602	-> 255
/*      */     //   #603	-> 267
/*      */     //   #604	-> 279
/*      */     //   #605	-> 288
/*      */     //   #607	-> 306
/*      */     //   #608	-> 309
/*      */     //   #609	-> 323
/*      */     //   #610	-> 328
/*      */     //   #612	-> 335
/*      */     //   #613	-> 347
/*      */     //   #621	-> 356
/*      */     //   #622	-> 361
/*      */     //   #624	-> 384
/*      */     //   #625	-> 393
/*      */     //   #626	-> 399
/*      */     //   #627	-> 402
/*      */     //   #628	-> 413
/*      */     //   #629	-> 419
/*      */     //   #632	-> 428
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	descriptor
/*      */     //   0	429	0	scope	Lorg/eclipse/jdt/internal/compiler/lookup/BlockScope;
/*      */     //   0	429	1	upstreamInfo	Lorg/eclipse/jdt/internal/compiler/flow/FlowInfo;
/*      */     //   0	429	2	flowInfo	Lorg/eclipse/jdt/internal/compiler/flow/FlowInfo;
/*      */     //   0	429	3	flowContext	Lorg/eclipse/jdt/internal/compiler/flow/FlowContext;
/*      */     //   0	429	4	location	Lorg/eclipse/jdt/internal/compiler/ast/ASTNode;
/*      */     //   0	429	5	rhs	Lorg/eclipse/jdt/internal/compiler/ast/Expression;
/*      */     //   0	429	6	local	Lorg/eclipse/jdt/internal/compiler/lookup/LocalVariableBinding;
/*      */     //   3	426	7	previousTracker	Lorg/eclipse/jdt/internal/compiler/ast/FakedTrackingVariable;
/*      */     //   6	423	8	disconnectedTracker	Lorg/eclipse/jdt/internal/compiler/ast/FakedTrackingVariable;
/*      */     //   29	16	9	nullStatus	I
/*      */     //   65	291	9	rhsTrackVar	Lorg/eclipse/jdt/internal/compiler/ast/FakedTrackingVariable;
/*      */     //   219	87	10	currentFlowContext	Lorg/eclipse/jdt/internal/compiler/flow/FlowContext;
/*      */     //   413	15	9	upstreamStatus	I
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static FakedTrackingVariable analyseCloseableExpression(FlowInfo flowInfo, FlowContext flowContext, LocalVariableBinding local, ASTNode location, Expression expression, FakedTrackingVariable previousTracker) {
/*      */     while (true) {
/*  648 */       while (expression instanceof Assignment)
/*  649 */         expression = ((Assignment)expression).expression; 
/*  650 */       if (expression instanceof CastExpression) {
/*  651 */         expression = ((CastExpression)expression).expression;
/*      */         continue;
/*      */       } 
/*      */       break;
/*      */     } 
/*  656 */     boolean isResourceProducer = false;
/*  657 */     if (expression.resolvedType instanceof ReferenceBinding) {
/*  658 */       ReferenceBinding resourceType = (ReferenceBinding)expression.resolvedType;
/*  659 */       if (resourceType.hasTypeBit(8)) {
/*  660 */         if (isBlacklistedMethod(expression)) {
/*  661 */           isResourceProducer = true;
/*      */         } else {
/*  663 */           return null;
/*      */         } 
/*      */       }
/*      */     } 
/*      */     
/*  668 */     if (expression instanceof AllocationExpression) {
/*      */       
/*  670 */       FakedTrackingVariable tracker = ((AllocationExpression)expression).closeTracker;
/*  671 */       if (tracker != null && tracker.originalBinding == null)
/*      */       {
/*  673 */         return null;
/*      */       }
/*  675 */       return tracker;
/*  676 */     }  if (expression instanceof MessageSend || 
/*  677 */       expression instanceof ArrayReference) {
/*      */ 
/*      */       
/*  680 */       FakedTrackingVariable tracker = new FakedTrackingVariable(local, location, flowInfo, flowContext, 16);
/*  681 */       if (!isResourceProducer)
/*  682 */         tracker.globalClosingState |= 0x2; 
/*  683 */       return tracker;
/*      */     } 
/*  685 */     if ((expression.bits & 0x7) == 1 || (
/*  686 */       expression instanceof QualifiedNameReference && (
/*  687 */       (QualifiedNameReference)expression).isFieldAccess())) {
/*      */ 
/*      */       
/*  690 */       FakedTrackingVariable tracker = new FakedTrackingVariable(local, location, flowInfo, flowContext, 1);
/*  691 */       tracker.globalClosingState |= 0x4;
/*      */       
/*  693 */       return tracker;
/*      */     } 
/*      */     
/*  696 */     if (local.closeTracker != null)
/*      */     {
/*  698 */       return local.closeTracker; } 
/*  699 */     FakedTrackingVariable newTracker = new FakedTrackingVariable(local, location, flowInfo, flowContext, 1);
/*  700 */     LocalVariableBinding rhsLocal = expression.localVariableBinding();
/*  701 */     if (rhsLocal != null && rhsLocal.isParameter()) {
/*  702 */       newTracker.globalClosingState |= 0x4;
/*      */     }
/*  704 */     return newTracker;
/*      */   }
/*      */   
/*      */   private static boolean isBlacklistedMethod(Expression expression) {
/*  708 */     if (expression instanceof MessageSend) {
/*  709 */       MethodBinding method = ((MessageSend)expression).binding;
/*  710 */       if (method != null && method.isValidBinding())
/*      */       {
/*  712 */         return CharOperation.equals(method.declaringClass.compoundName, TypeConstants.JAVA_NIO_FILE_FILES); } 
/*      */     } 
/*  714 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void cleanUpAfterAssignment(BlockScope currentScope, int lhsBits, Expression expression) {
/*      */     while (true) {
/*  722 */       while (expression instanceof Assignment)
/*  723 */         expression = ((Assignment)expression).expression; 
/*  724 */       if (expression instanceof CastExpression) {
/*  725 */         expression = ((CastExpression)expression).expression; continue;
/*      */       } 
/*      */       break;
/*      */     } 
/*  729 */     if (expression instanceof AllocationExpression) {
/*  730 */       FakedTrackingVariable tracker = ((AllocationExpression)expression).closeTracker;
/*  731 */       if (tracker != null && tracker.originalBinding == null) {
/*  732 */         tracker.withdraw();
/*  733 */         ((AllocationExpression)expression).closeTracker = null;
/*      */       } 
/*  735 */     } else if (expression instanceof MessageSend) {
/*  736 */       FakedTrackingVariable tracker = ((MessageSend)expression).closeTracker;
/*  737 */       if (tracker != null && tracker.originalBinding == null) {
/*  738 */         tracker.withdraw();
/*  739 */         ((MessageSend)expression).closeTracker = null;
/*      */       } 
/*      */     } else {
/*      */       
/*  743 */       LocalVariableBinding local = expression.localVariableBinding();
/*  744 */       if (local != null && local.closeTracker != null && (lhsBits & 0x1) != 0) {
/*  745 */         local.closeTracker.withdraw();
/*      */       }
/*      */     } 
/*      */   }
/*      */   
/*      */   public static void cleanUpUnassigned(BlockScope scope, ASTNode location, final FlowInfo flowInfo) {
/*  751 */     if (!scope.hasResourceTrackers())
/*  752 */       return;  location.traverse(new ASTVisitor()
/*      */         {
/*      */           public boolean visit(MessageSend messageSend, BlockScope skope) {
/*  755 */             FakedTrackingVariable closeTracker = messageSend.closeTracker;
/*  756 */             if (closeTracker != null && 
/*  757 */               closeTracker.originalBinding == null) {
/*  758 */               int nullStatus = flowInfo.nullStatus(closeTracker.binding);
/*  759 */               if ((nullStatus & 0x12) != 0) {
/*  760 */                 closeTracker.reportError(skope.problemReporter(), messageSend, nullStatus);
/*      */               }
/*  762 */               closeTracker.withdraw();
/*      */             } 
/*      */             
/*  765 */             return true;
/*      */           }
/*  768 */         }scope);
/*      */   }
/*      */ 
/*      */   
/*      */   public static boolean isAnyCloseable(TypeBinding typeBinding) {
/*  773 */     return (typeBinding instanceof ReferenceBinding && (
/*  774 */       (ReferenceBinding)typeBinding).hasTypeBit(3));
/*      */   }
/*      */   
/*      */   public int findMostSpecificStatus(FlowInfo flowInfo, BlockScope currentScope, BlockScope locationScope) {
/*  778 */     int status = 1;
/*  779 */     FakedTrackingVariable currentTracker = this;
/*      */     
/*  781 */     while (currentTracker != null) {
/*  782 */       LocalVariableBinding currentVar = currentTracker.binding;
/*  783 */       int currentStatus = getNullStatusAggressively(currentVar, flowInfo);
/*  784 */       if (locationScope != null)
/*  785 */         currentStatus = mergeCloseStatus(locationScope, currentStatus, currentVar, currentScope); 
/*  786 */       if (currentStatus == 4) {
/*  787 */         status = currentStatus; break;
/*      */       } 
/*  789 */       if (status == 2 || status == 1) {
/*  790 */         status = currentStatus;
/*      */       }
/*  792 */       currentTracker = currentTracker.innerTracker;
/*      */     } 
/*  794 */     return status;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private int getNullStatusAggressively(LocalVariableBinding local, FlowInfo flowInfo) {
/*  804 */     if (flowInfo == FlowInfo.DEAD_END) {
/*  805 */       return 1;
/*      */     }
/*  807 */     int reachMode = flowInfo.reachMode();
/*  808 */     int status = 0;
/*      */     
/*      */     try {
/*  811 */       if (reachMode != 0)
/*  812 */         flowInfo.tagBits &= 0xFFFFFFFC; 
/*  813 */       status = flowInfo.nullStatus(local);
/*  814 */       if (TEST_372319) {
/*      */         try {
/*  816 */           Thread.sleep(5L);
/*  817 */         } catch (InterruptedException interruptedException) {}
/*      */       }
/*      */     } finally {
/*      */       
/*  821 */       flowInfo.tagBits |= reachMode;
/*      */     } 
/*      */     
/*  824 */     if ((status & 0x2) != 0) {
/*  825 */       if ((status & 0x24) != 0)
/*  826 */         return 16; 
/*  827 */       return 2;
/*  828 */     }  if ((status & 0x4) != 0) {
/*  829 */       if ((status & 0x10) != 0)
/*  830 */         return 16; 
/*  831 */       return 4;
/*  832 */     }  if ((status & 0x10) != 0)
/*  833 */       return 16; 
/*  834 */     if (status == 1)
/*      */     {
/*  836 */       if (this.originalBinding == null)
/*  837 */         return 2; 
/*      */     }
/*  839 */     return status;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int mergeCloseStatus(BlockScope currentScope, int status, LocalVariableBinding local, BlockScope outerScope) {
/*  846 */     if (status != 4) {
/*  847 */       if (currentScope.finallyInfo != null) {
/*  848 */         int finallyStatus = currentScope.finallyInfo.nullStatus(local);
/*  849 */         if (finallyStatus == 4)
/*  850 */           return finallyStatus; 
/*  851 */         if (finallyStatus != 2 && currentScope.finallyInfo.hasNullInfoFor(local))
/*  852 */           status = 16; 
/*      */       } 
/*  854 */       if (currentScope != outerScope && currentScope.parent instanceof BlockScope)
/*  855 */         return mergeCloseStatus((BlockScope)currentScope.parent, status, local, outerScope); 
/*      */     } 
/*  857 */     return status;
/*      */   }
/*      */ 
/*      */   
/*      */   public void markClose(FlowInfo flowInfo, FlowContext flowContext) {
/*  862 */     FakedTrackingVariable current = this;
/*      */     do {
/*  864 */       flowInfo.markAsDefinitelyNonNull(current.binding);
/*  865 */       current.globalClosingState |= 0x1;
/*  866 */       flowContext.markFinallyNullStatus(current.binding, 4);
/*  867 */       current = current.innerTracker;
/*  868 */     } while (current != null);
/*      */   }
/*      */ 
/*      */   
/*      */   public void markClosedInNestedMethod() {
/*  873 */     this.globalClosingState |= 0x8;
/*      */   }
/*      */ 
/*      */   
/*      */   public void markClosedEffectivelyFinal() {
/*  878 */     this.globalClosingState |= 0x100;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static FlowInfo markPassedToOutside(BlockScope scope, Expression expression, FlowInfo flowInfo, FlowContext flowContext, boolean owned) {
/*  888 */     FakedTrackingVariable trackVar = getCloseTrackingVariable(expression, flowInfo, flowContext);
/*  889 */     if (trackVar != null) {
/*      */       
/*  891 */       FlowInfo infoResourceIsClosed = owned ? flowInfo : flowInfo.copy();
/*  892 */       int flag = owned ? 4 : 2;
/*      */       while (true) {
/*  894 */         trackVar.globalClosingState |= flag;
/*  895 */         if (scope.methodScope() != trackVar.methodScope)
/*  896 */           trackVar.globalClosingState |= 0x8; 
/*  897 */         infoResourceIsClosed.markAsDefinitelyNonNull(trackVar.binding);
/*  898 */         if ((trackVar = trackVar.innerTracker) == null) {
/*  899 */           if (owned) {
/*  900 */             return infoResourceIsClosed;
/*      */           }
/*  902 */           return (FlowInfo)FlowInfo.conditional(flowInfo, infoResourceIsClosed).unconditionalCopy();
/*      */         } 
/*      */       } 
/*  905 */     }  return flowInfo;
/*      */   }
/*      */   
/*      */   public static void markForeachElementVar(LocalDeclaration local) {
/*  909 */     if (local.binding != null && local.binding.closeTracker != null) {
/*  910 */       local.binding.closeTracker.globalClosingState |= 0x80;
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   public static class IteratorForReporting
/*      */     implements Iterator<FakedTrackingVariable>
/*      */   {
/*      */     private final Set<FakedTrackingVariable> varSet;
/*      */     
/*      */     private final Scope scope;
/*      */     
/*      */     private final boolean atExit;
/*      */     
/*      */     private Stage stage;
/*      */     
/*      */     private Iterator<FakedTrackingVariable> iterator;
/*      */     private FakedTrackingVariable next;
/*      */     
/*      */     enum Stage
/*      */     {
/*  931 */       OuterLess,
/*      */       
/*  933 */       InnerOfProcessed,
/*      */       
/*  935 */       InnerOfNotEnclosing,
/*      */       
/*  937 */       AtExit;
/*      */     }
/*      */ 
/*      */     
/*      */     public IteratorForReporting(List<FakedTrackingVariable> variables, Scope scope, boolean atExit) {
/*  942 */       this.varSet = new HashSet<>(variables);
/*  943 */       this.scope = scope;
/*  944 */       this.atExit = atExit;
/*  945 */       setUpForStage(Stage.OuterLess);
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean hasNext() {
/*  950 */       switch (this.stage) {
/*      */         case OuterLess:
/*  952 */           while (this.iterator.hasNext()) {
/*  953 */             FakedTrackingVariable trackingVar = this.iterator.next();
/*  954 */             if (trackingVar.outerTracker == null)
/*  955 */               return found(trackingVar); 
/*      */           } 
/*  957 */           setUpForStage(Stage.InnerOfProcessed);
/*      */         
/*      */         case InnerOfProcessed:
/*  960 */           while (this.iterator.hasNext()) {
/*  961 */             FakedTrackingVariable trackingVar = this.iterator.next();
/*  962 */             FakedTrackingVariable outer = trackingVar.outerTracker;
/*  963 */             if (outer.binding.declaringScope == this.scope && !this.varSet.contains(outer))
/*  964 */               return found(trackingVar); 
/*      */           } 
/*  966 */           setUpForStage(Stage.InnerOfNotEnclosing);
/*      */         
/*      */         case InnerOfNotEnclosing:
/*  969 */           while (this.iterator.hasNext()) {
/*  970 */             FakedTrackingVariable trackingVar = this.iterator.next();
/*  971 */             FakedTrackingVariable outer = trackingVar.outerTracker;
/*  972 */             if (!this.varSet.contains(outer)) {
/*  973 */               BlockScope blockScope = outer.binding.declaringScope;
/*  974 */               Scope currentScope = this.scope; do {
/*  975 */                 if (!(currentScope = currentScope.parent instanceof BlockScope))
/*      */                 {
/*      */ 
/*      */                   
/*  979 */                   return found(trackingVar); } 
/*      */               } while (blockScope != currentScope); break;
/*      */             } 
/*  982 */           }  setUpForStage(Stage.AtExit);
/*      */         
/*      */         case null:
/*  985 */           if (this.atExit && this.iterator.hasNext())
/*  986 */             return found(this.iterator.next()); 
/*  987 */           return false;
/*  988 */       }  throw new IllegalStateException("Unexpected Stage " + this.stage);
/*      */     }
/*      */     
/*      */     private boolean found(FakedTrackingVariable trackingVar) {
/*  992 */       this.iterator.remove();
/*  993 */       this.next = trackingVar;
/*  994 */       return true;
/*      */     }
/*      */     private void setUpForStage(Stage nextStage) {
/*  997 */       this.iterator = this.varSet.iterator();
/*  998 */       this.stage = nextStage;
/*      */     }
/*      */     
/*      */     public FakedTrackingVariable next() {
/* 1002 */       return this.next;
/*      */     }
/*      */     
/*      */     public void remove() {
/* 1006 */       throw new UnsupportedOperationException();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean hasDefinitelyNoResource(FlowInfo flowInfo) {
/* 1015 */     if (this.originalBinding == null) return false; 
/* 1016 */     if (flowInfo.isDefinitelyNull(this.originalBinding)) {
/* 1017 */       return true;
/*      */     }
/* 1019 */     if (!flowInfo.isDefinitelyAssigned(this.originalBinding) && 
/* 1020 */       !flowInfo.isPotentiallyAssigned(this.originalBinding)) {
/* 1021 */       return true;
/*      */     }
/* 1023 */     return false;
/*      */   }
/*      */   
/*      */   public boolean isClosedInFinallyOfEnclosing(BlockScope scope) {
/* 1027 */     BlockScope currentScope = scope;
/*      */     while (true) {
/* 1029 */       if (currentScope.finallyInfo != null && 
/* 1030 */         currentScope.finallyInfo.isDefinitelyNonNull(this.binding)) {
/* 1031 */         return true;
/*      */       }
/* 1033 */       if (!(currentScope.parent instanceof BlockScope)) {
/* 1034 */         return false;
/*      */       }
/* 1036 */       currentScope = (BlockScope)currentScope.parent;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isResourceBeingReturned(FakedTrackingVariable returnedResource) {
/* 1044 */     FakedTrackingVariable current = this;
/*      */     while (true) {
/* 1046 */       if (current == returnedResource) {
/* 1047 */         this.globalClosingState |= 0x40;
/* 1048 */         return true;
/*      */       } 
/* 1050 */       current = current.innerTracker;
/* 1051 */       if (current == null)
/* 1052 */         return false; 
/*      */     } 
/*      */   }
/*      */   
/*      */   public void withdraw() {
/* 1057 */     this.binding.declaringScope.removeTrackingVar(this);
/*      */   }
/*      */   
/*      */   public void recordErrorLocation(ASTNode location, int nullStatus) {
/* 1061 */     if ((this.globalClosingState & 0x4) != 0) {
/*      */       return;
/*      */     }
/* 1064 */     if (this.recordedLocations == null)
/* 1065 */       this.recordedLocations = new HashMap<>(); 
/* 1066 */     this.recordedLocations.put(location, Integer.valueOf(nullStatus));
/*      */   }
/*      */   
/*      */   public boolean reportRecordedErrors(Scope scope, int mergedStatus, boolean atDeadEnd) {
/* 1070 */     FakedTrackingVariable current = this;
/* 1071 */     while (current.globalClosingState == 0) {
/* 1072 */       current = current.innerTracker;
/* 1073 */       if (current == null) {
/*      */         
/* 1075 */         if (atDeadEnd && neverClosedAtLocations())
/* 1076 */           mergedStatus = 2; 
/* 1077 */         if ((mergedStatus & 0x32) != 0) {
/* 1078 */           reportError(scope.problemReporter(), (ASTNode)null, mergedStatus);
/* 1079 */           return true;
/*      */         } 
/*      */         
/*      */         break;
/*      */       } 
/*      */     } 
/* 1085 */     boolean hasReported = false;
/* 1086 */     if (this.recordedLocations != null) {
/* 1087 */       Iterator<Map.Entry> locations = this.recordedLocations.entrySet().iterator();
/* 1088 */       int reportFlags = 0;
/* 1089 */       while (locations.hasNext()) {
/* 1090 */         Map.Entry entry = locations.next();
/* 1091 */         reportFlags |= reportError(scope.problemReporter(), (ASTNode)entry.getKey(), ((Integer)entry.getValue()).intValue());
/* 1092 */         hasReported = true;
/*      */       } 
/* 1094 */       if (reportFlags != 0) {
/*      */         
/* 1096 */         current = this;
/*      */         do {
/* 1098 */           current.globalClosingState |= reportFlags;
/* 1099 */         } while ((current = current.innerTracker) != null);
/*      */       } 
/*      */     } 
/* 1102 */     return hasReported;
/*      */   }
/*      */   
/*      */   private boolean neverClosedAtLocations() {
/* 1106 */     if (this.recordedLocations != null)
/* 1107 */       for (Object value : this.recordedLocations.values()) {
/* 1108 */         if (!value.equals(Integer.valueOf(2)))
/* 1109 */           return false; 
/*      */       }  
/* 1111 */     return true;
/*      */   }
/*      */   
/*      */   public int reportError(ProblemReporter problemReporter, ASTNode location, int nullStatus) {
/* 1115 */     if ((this.globalClosingState & 0x4) != 0) {
/* 1116 */       return 0;
/*      */     }
/*      */     
/* 1119 */     boolean isPotentialProblem = false;
/* 1120 */     if (nullStatus == 2) {
/* 1121 */       if ((this.globalClosingState & 0x8) != 0)
/* 1122 */         isPotentialProblem = true; 
/* 1123 */     } else if ((nullStatus & 0x30) != 0) {
/* 1124 */       isPotentialProblem = true;
/*      */     } 
/*      */     
/* 1127 */     if (isPotentialProblem) {
/* 1128 */       if ((this.globalClosingState & 0x60) != 0) {
/* 1129 */         return 0;
/*      */       }
/*      */ 
/*      */ 
/*      */       
/* 1134 */       problemReporter.potentiallyUnclosedCloseable(this, location);
/*      */     } else {
/* 1136 */       if ((this.globalClosingState & 0x40) != 0)
/* 1137 */         return 0; 
/* 1138 */       problemReporter.unclosedCloseable(this, location);
/*      */     } 
/*      */     
/* 1141 */     int reportFlag = isPotentialProblem ? 32 : 64;
/* 1142 */     if (location == null) {
/* 1143 */       FakedTrackingVariable current = this;
/*      */       do {
/* 1145 */         current.globalClosingState |= reportFlag;
/* 1146 */       } while ((current = current.innerTracker) != null);
/*      */     } 
/* 1148 */     return reportFlag;
/*      */   }
/*      */   
/*      */   public void reportExplicitClosing(ProblemReporter problemReporter) {
/* 1152 */     if ((this.globalClosingState & 0x194) == 0) {
/* 1153 */       this.globalClosingState |= 0x10;
/* 1154 */       problemReporter.explicitlyClosedAutoCloseable(this);
/*      */     } 
/*      */   }
/*      */   
/*      */   public String nameForReporting(ASTNode location, ReferenceContext referenceContext) {
/* 1159 */     if (this.name == UNASSIGNED_CLOSEABLE_NAME && 
/* 1160 */       location != null && referenceContext != null) {
/* 1161 */       CompilationResult compResult = referenceContext.compilationResult();
/* 1162 */       if (compResult != null) {
/* 1163 */         int[] lineEnds = compResult.getLineSeparatorPositions();
/* 1164 */         int resourceLine = Util.getLineNumber(this.sourceStart, lineEnds, 0, lineEnds.length - 1);
/* 1165 */         int reportLine = Util.getLineNumber(location.sourceStart, lineEnds, 0, lineEnds.length - 1);
/* 1166 */         if (resourceLine != reportLine) {
/* 1167 */           char[] replacement = Integer.toString(resourceLine).toCharArray();
/* 1168 */           return String.valueOf(CharOperation.replace(UNASSIGNED_CLOSEABLE_NAME_TEMPLATE, TEMPLATE_ARGUMENT, replacement));
/*      */         } 
/*      */       } 
/*      */     } 
/*      */     
/* 1173 */     return String.valueOf(this.name);
/*      */   }
/*      */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\ast\FakedTrackingVariable.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */