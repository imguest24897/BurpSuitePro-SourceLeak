/*     */ package org.eclipse.jdt.core.compiler;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import java.util.BitSet;
/*     */ import org.eclipse.jdt.internal.compiler.parser.ScannerHelper;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class SubwordMatcher
/*     */ {
/*  23 */   private static final int[] EMPTY_REGIONS = new int[0];
/*     */   
/*     */   private final char[] name;
/*     */   private final BitSet wordBoundaries;
/*     */   
/*     */   public SubwordMatcher(String name) {
/*  29 */     this.name = name.toCharArray();
/*  30 */     this.wordBoundaries = new BitSet(name.length());
/*     */     
/*  32 */     for (int i = 0; i < this.name.length; i++) {
/*  33 */       if (isWordBoundary(caseAt(i - 1), caseAt(i), caseAt(i + 1))) {
/*  34 */         this.wordBoundaries.set(i);
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   private Case caseAt(int index) {
/*  40 */     if (index < 0 || index >= this.name.length) {
/*  41 */       return Case.SEPARATOR;
/*     */     }
/*  43 */     char c = this.name[index];
/*  44 */     if (c == '_')
/*  45 */       return Case.SEPARATOR; 
/*  46 */     if (ScannerHelper.isUpperCase(c))
/*  47 */       return Case.UPPER; 
/*  48 */     return Case.LOWER;
/*     */   }
/*     */   
/*     */   private static boolean isWordBoundary(Case p, Case c, Case n) {
/*  52 */     if (p == c && c == n) {
/*  53 */       return false;
/*     */     }
/*  55 */     if (p == Case.SEPARATOR) {
/*  56 */       return true;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*  61 */     return (c == Case.UPPER && (p == Case.LOWER || n == Case.LOWER));
/*     */   }
/*     */   
/*     */   private enum Case {
/*  65 */     SEPARATOR, LOWER, UPPER;
/*     */   }
/*     */   
/*     */   public int[] getMatchingRegions(String pattern) {
/*  69 */     int segmentStart = 0;
/*  70 */     int[] segments = EMPTY_REGIONS;
/*     */ 
/*     */     
/*  73 */     int iName = -1;
/*  74 */     int iPatternWordStart = 0;
/*  75 */     for (int iPattern = 0; iPattern < pattern.length(); iPattern++) {
/*  76 */       iName++;
/*  77 */       if (iName == this.name.length)
/*     */       {
/*  79 */         return null;
/*     */       }
/*     */       
/*  82 */       char patternChar = pattern.charAt(iPattern);
/*  83 */       char nameChar = this.name[iName];
/*     */ 
/*     */       
/*  86 */       if (patternChar != nameChar)
/*     */       {
/*     */         
/*  89 */         if (isWordBoundary(iName) || !equalsIgnoreCase(patternChar, nameChar)) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/*  95 */           if (iName > segmentStart) {
/*  96 */             segments = Arrays.copyOf(segments, segments.length + 2);
/*  97 */             segments[segments.length - 2] = segmentStart;
/*  98 */             segments[segments.length - 1] = iName - segmentStart;
/*     */           } 
/*     */           
/* 101 */           int wordStart = indexOfWordStart(iName, patternChar);
/* 102 */           if (wordStart < 0) {
/*     */             
/* 104 */             int next = indexOfWordStart(iName, pattern.charAt(iPatternWordStart));
/* 105 */             if (next > 0) {
/* 106 */               wordStart = next;
/* 107 */               iPattern = iPatternWordStart;
/*     */               
/* 109 */               segments = Arrays.copyOfRange(segments, 0, segments.length - 2);
/*     */             } 
/*     */           } 
/*     */           
/* 113 */           if (wordStart < 0)
/*     */           {
/* 115 */             return null;
/*     */           }
/*     */           
/* 118 */           segmentStart = wordStart;
/* 119 */           iName = wordStart;
/* 120 */           iPatternWordStart = iPattern;
/*     */         } 
/*     */       }
/*     */     } 
/* 124 */     segments = Arrays.copyOf(segments, segments.length + 2);
/* 125 */     segments[segments.length - 2] = segmentStart;
/* 126 */     segments[segments.length - 1] = iName - segmentStart + 1;
/*     */     
/* 128 */     return segments;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int indexOfWordStart(int nameStart, char patternChar) {
/* 137 */     for (int iName = nameStart; iName < this.name.length; iName++) {
/* 138 */       char nameChar = this.name[iName];
/* 139 */       if (isWordBoundary(iName) && equalsIgnoreCase(nameChar, patternChar)) {
/* 140 */         return iName;
/*     */       }
/*     */ 
/*     */       
/* 144 */       if (!ScannerHelper.isJavaIdentifierPart(nameChar)) {
/* 145 */         return -1;
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 150 */     return -1;
/*     */   }
/*     */   
/*     */   private boolean equalsIgnoreCase(char a, char b) {
/* 154 */     return (ScannerHelper.toLowerCase(a) == ScannerHelper.toLowerCase(b));
/*     */   }
/*     */   
/*     */   private boolean isWordBoundary(int iName) {
/* 158 */     return this.wordBoundaries.get(iName);
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\core\compiler\SubwordMatcher.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */