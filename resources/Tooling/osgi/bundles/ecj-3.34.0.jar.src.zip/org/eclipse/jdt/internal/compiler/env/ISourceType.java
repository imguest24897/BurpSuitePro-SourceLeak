/*    */ package org.eclipse.jdt.internal.compiler.env;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface ISourceType
/*    */   extends IGenericType
/*    */ {
/*    */   int getDeclarationSourceEnd();
/*    */   
/*    */   int getDeclarationSourceStart();
/*    */   
/*    */   ISourceType getEnclosingType();
/*    */   
/*    */   ISourceField[] getFields();
/*    */   
/*    */   char[][] getInterfaceNames();
/*    */   
/*    */   default char[][] getPermittedSubtypeNames() {
/* 58 */     return null;
/*    */   }
/*    */   
/*    */   ISourceType[] getMemberTypes();
/*    */   
/*    */   ISourceMethod[] getMethods();
/*    */   
/*    */   char[] getName();
/*    */   
/*    */   int getNameSourceEnd();
/*    */   
/*    */   int getNameSourceStart();
/*    */   
/*    */   char[] getSuperclassName();
/*    */   
/*    */   char[][][] getTypeParameterBounds();
/*    */   
/*    */   char[][] getTypeParameterNames();
/*    */   
/*    */   boolean isAnonymous();
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\env\ISourceType.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */