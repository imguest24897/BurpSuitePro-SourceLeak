package org.eclipse.jdt.internal.compiler.ast;

import org.eclipse.jdt.internal.compiler.lookup.BlockScope;
import org.eclipse.jdt.internal.compiler.lookup.InferenceContext18;
import org.eclipse.jdt.internal.compiler.lookup.MethodBinding;
import org.eclipse.jdt.internal.compiler.lookup.Scope;
import org.eclipse.jdt.internal.compiler.lookup.TypeBinding;

public interface IPolyExpression {
  void setExpressionContext(ExpressionContext paramExpressionContext);
  
  ExpressionContext getExpressionContext();
  
  void setExpectedType(TypeBinding paramTypeBinding);
  
  TypeBinding invocationTargetType();
  
  boolean isPotentiallyCompatibleWith(TypeBinding paramTypeBinding, Scope paramScope);
  
  boolean isCompatibleWith(TypeBinding paramTypeBinding, Scope paramScope);
  
  boolean isBoxingCompatibleWith(TypeBinding paramTypeBinding, Scope paramScope);
  
  boolean sIsMoreSpecific(TypeBinding paramTypeBinding1, TypeBinding paramTypeBinding2, Scope paramScope);
  
  boolean isPertinentToApplicability(TypeBinding paramTypeBinding, MethodBinding paramMethodBinding);
  
  boolean isPolyExpression(MethodBinding paramMethodBinding);
  
  boolean isPolyExpression();
  
  boolean isFunctionalType();
  
  Expression[] getPolyExpressions();
  
  TypeBinding resolveType(BlockScope paramBlockScope);
  
  Expression resolveExpressionExpecting(TypeBinding paramTypeBinding, Scope paramScope, InferenceContext18 paramInferenceContext18);
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\ast\IPolyExpression.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */