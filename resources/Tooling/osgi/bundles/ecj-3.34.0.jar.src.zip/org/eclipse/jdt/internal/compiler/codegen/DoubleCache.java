/*     */ package org.eclipse.jdt.internal.compiler.codegen;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DoubleCache
/*     */ {
/*     */   private double[] keyTable;
/*     */   private int[] valueTable;
/*     */   private int elementSize;
/*     */   
/*     */   public DoubleCache() {
/*  26 */     this(13);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DoubleCache(int initialCapacity) {
/*  35 */     this.elementSize = 0;
/*  36 */     this.keyTable = new double[initialCapacity];
/*  37 */     this.valueTable = new int[initialCapacity];
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void clear() {
/*  43 */     for (int i = this.keyTable.length; --i >= 0; ) {
/*  44 */       this.keyTable[i] = 0.0D;
/*  45 */       this.valueTable[i] = 0;
/*     */     } 
/*  47 */     this.elementSize = 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean containsKey(double key) {
/*  55 */     if (key == 0.0D) {
/*  56 */       for (int i = 0, max = this.elementSize; i < max; i++) {
/*  57 */         if (this.keyTable[i] == 0.0D) {
/*  58 */           long value1 = Double.doubleToLongBits(key);
/*  59 */           long value2 = Double.doubleToLongBits(this.keyTable[i]);
/*  60 */           if (value1 == Long.MIN_VALUE && value2 == Long.MIN_VALUE)
/*  61 */             return true; 
/*  62 */           if (value1 == 0L && value2 == 0L)
/*  63 */             return true; 
/*     */         } 
/*     */       } 
/*     */     } else {
/*  67 */       for (int i = 0, max = this.elementSize; i < max; i++) {
/*  68 */         if (this.keyTable[i] == key) {
/*  69 */           return true;
/*     */         }
/*     */       } 
/*     */     } 
/*  73 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int put(double key, int value) {
/*  84 */     if (this.elementSize == this.keyTable.length) {
/*     */       
/*  86 */       System.arraycopy(this.keyTable, 0, this.keyTable = new double[this.elementSize * 2], 0, this.elementSize);
/*  87 */       System.arraycopy(this.valueTable, 0, this.valueTable = new int[this.elementSize * 2], 0, this.elementSize);
/*     */     } 
/*  89 */     this.keyTable[this.elementSize] = key;
/*  90 */     this.valueTable[this.elementSize] = value;
/*  91 */     this.elementSize++;
/*  92 */     return value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int putIfAbsent(double key, int value) {
/* 103 */     if (key == 0.0D) {
/* 104 */       for (int i = 0, max = this.elementSize; i < max; i++) {
/* 105 */         if (this.keyTable[i] == 0.0D) {
/* 106 */           long value1 = Double.doubleToLongBits(key);
/* 107 */           long value2 = Double.doubleToLongBits(this.keyTable[i]);
/* 108 */           if (value1 == Long.MIN_VALUE && value2 == Long.MIN_VALUE)
/* 109 */             return this.valueTable[i]; 
/* 110 */           if (value1 == 0L && value2 == 0L)
/* 111 */             return this.valueTable[i]; 
/*     */         } 
/*     */       } 
/*     */     } else {
/* 115 */       for (int i = 0, max = this.elementSize; i < max; i++) {
/* 116 */         if (this.keyTable[i] == key) {
/* 117 */           return this.valueTable[i];
/*     */         }
/*     */       } 
/*     */     } 
/* 121 */     if (this.elementSize == this.keyTable.length) {
/*     */       
/* 123 */       System.arraycopy(this.keyTable, 0, this.keyTable = new double[this.elementSize * 2], 0, this.elementSize);
/* 124 */       System.arraycopy(this.valueTable, 0, this.valueTable = new int[this.elementSize * 2], 0, this.elementSize);
/*     */     } 
/* 126 */     this.keyTable[this.elementSize] = key;
/* 127 */     this.valueTable[this.elementSize] = value;
/* 128 */     this.elementSize++;
/* 129 */     return -value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 138 */     int max = this.elementSize;
/* 139 */     StringBuilder buf = new StringBuilder();
/* 140 */     buf.append("{");
/* 141 */     for (int i = 0; i < max; i++) {
/* 142 */       if (this.keyTable[i] != 0.0D || (this.keyTable[i] == 0.0D && this.valueTable[i] != 0)) {
/* 143 */         buf.append(this.keyTable[i]).append("->").append(this.valueTable[i]);
/*     */       }
/* 145 */       if (i < max) {
/* 146 */         buf.append(", ");
/*     */       }
/*     */     } 
/* 149 */     buf.append("}");
/* 150 */     return buf.toString();
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\codegen\DoubleCache.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */