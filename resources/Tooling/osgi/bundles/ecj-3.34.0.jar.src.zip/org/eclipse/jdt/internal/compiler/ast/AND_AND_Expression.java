/*     */ package org.eclipse.jdt.internal.compiler.ast;
/*     */ 
/*     */ import org.eclipse.jdt.internal.compiler.ASTVisitor;
/*     */ import org.eclipse.jdt.internal.compiler.codegen.BranchLabel;
/*     */ import org.eclipse.jdt.internal.compiler.codegen.CodeStream;
/*     */ import org.eclipse.jdt.internal.compiler.flow.FlowContext;
/*     */ import org.eclipse.jdt.internal.compiler.flow.FlowInfo;
/*     */ import org.eclipse.jdt.internal.compiler.flow.UnconditionalFlowInfo;
/*     */ import org.eclipse.jdt.internal.compiler.impl.Constant;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.Binding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.BlockScope;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.LocalVariableBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.Scope;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.TypeBinding;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AND_AND_Expression
/*     */   extends BinaryExpression
/*     */ {
/*  30 */   int rightInitStateIndex = -1;
/*  31 */   int mergedInitStateIndex = -1;
/*     */   
/*     */   public AND_AND_Expression(Expression left, Expression right, int operator) {
/*  34 */     super(left, right, operator);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public FlowInfo analyseCode(BlockScope currentScope, FlowContext flowContext, FlowInfo flowInfo) {
/*  40 */     Constant cst = this.left.optimizedBooleanConstant();
/*  41 */     boolean isLeftOptimizedTrue = (cst != Constant.NotAConstant && cst.booleanValue());
/*  42 */     boolean isLeftOptimizedFalse = (cst != Constant.NotAConstant && !cst.booleanValue());
/*     */     
/*  44 */     if (isLeftOptimizedTrue) {
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*  49 */       UnconditionalFlowInfo unconditionalFlowInfo1 = this.left.analyseCode(currentScope, flowContext, flowInfo)
/*  50 */         .unconditionalInits();
/*  51 */       FlowInfo flowInfo2 = this.right.analyseCode(currentScope, flowContext, (FlowInfo)unconditionalFlowInfo1);
/*  52 */       this.mergedInitStateIndex = currentScope.methodScope()
/*  53 */         .recordInitializationStates(flowInfo2);
/*  54 */       return flowInfo2;
/*     */     } 
/*     */     
/*  57 */     FlowInfo leftInfo = this.left.analyseCode(currentScope, flowContext, flowInfo);
/*  58 */     if ((flowContext.tagBits & 0x4) != 0) {
/*  59 */       flowContext.expireNullCheckedFieldInfo();
/*     */     }
/*     */ 
/*     */     
/*  63 */     UnconditionalFlowInfo unconditionalFlowInfo = leftInfo.initsWhenTrue().unconditionalCopy();
/*  64 */     this.rightInitStateIndex = currentScope.methodScope().recordInitializationStates((FlowInfo)unconditionalFlowInfo);
/*     */     
/*  66 */     int previousMode = unconditionalFlowInfo.reachMode();
/*  67 */     if (isLeftOptimizedFalse && (
/*  68 */       unconditionalFlowInfo.reachMode() & 0x3) == 0) {
/*  69 */       currentScope.problemReporter().fakeReachable(this.right);
/*  70 */       unconditionalFlowInfo.setReachMode(1);
/*     */     } 
/*     */     
/*  73 */     this.left.updateFlowOnBooleanResult((FlowInfo)unconditionalFlowInfo, true);
/*  74 */     FlowInfo flowInfo1 = this.right.analyseCode(currentScope, flowContext, (FlowInfo)unconditionalFlowInfo);
/*  75 */     if ((flowContext.tagBits & 0x4) != 0)
/*  76 */       flowContext.expireNullCheckedFieldInfo(); 
/*  77 */     this.left.checkNPEbyUnboxing(currentScope, flowContext, flowInfo);
/*  78 */     this.right.checkNPEbyUnboxing(currentScope, flowContext, leftInfo.initsWhenTrue());
/*  79 */     FlowInfo mergedInfo = FlowInfo.conditional(
/*  80 */         flowInfo1.safeInitsWhenTrue(), 
/*  81 */         (FlowInfo)leftInfo.initsWhenFalse().unconditionalInits().mergedWith(
/*  82 */           flowInfo1.initsWhenFalse().setReachMode(previousMode).unconditionalInits()));
/*     */     
/*  84 */     this.mergedInitStateIndex = currentScope.methodScope().recordInitializationStates(mergedInfo);
/*  85 */     return mergedInfo;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void generateCode(BlockScope currentScope, CodeStream codeStream, boolean valueRequired) {
/*     */     // Byte code:
/*     */     //   0: aload_2
/*     */     //   1: getfield position : I
/*     */     //   4: istore #4
/*     */     //   6: aload_0
/*     */     //   7: getfield constant : Lorg/eclipse/jdt/internal/compiler/impl/Constant;
/*     */     //   10: getstatic org/eclipse/jdt/internal/compiler/impl/Constant.NotAConstant : Lorg/eclipse/jdt/internal/compiler/impl/Constant;
/*     */     //   13: if_acmpeq -> 43
/*     */     //   16: iload_3
/*     */     //   17: ifeq -> 32
/*     */     //   20: aload_2
/*     */     //   21: aload_0
/*     */     //   22: getfield constant : Lorg/eclipse/jdt/internal/compiler/impl/Constant;
/*     */     //   25: aload_0
/*     */     //   26: getfield implicitConversion : I
/*     */     //   29: invokevirtual generateConstant : (Lorg/eclipse/jdt/internal/compiler/impl/Constant;I)V
/*     */     //   32: aload_2
/*     */     //   33: iload #4
/*     */     //   35: aload_0
/*     */     //   36: getfield sourceStart : I
/*     */     //   39: invokevirtual recordPositionsFrom : (II)V
/*     */     //   42: return
/*     */     //   43: aload_0
/*     */     //   44: getfield right : Lorg/eclipse/jdt/internal/compiler/ast/Expression;
/*     */     //   47: getfield constant : Lorg/eclipse/jdt/internal/compiler/impl/Constant;
/*     */     //   50: astore #5
/*     */     //   52: aload #5
/*     */     //   54: getstatic org/eclipse/jdt/internal/compiler/impl/Constant.NotAConstant : Lorg/eclipse/jdt/internal/compiler/impl/Constant;
/*     */     //   57: if_acmpeq -> 135
/*     */     //   60: aload #5
/*     */     //   62: invokevirtual booleanValue : ()Z
/*     */     //   65: ifeq -> 81
/*     */     //   68: aload_0
/*     */     //   69: getfield left : Lorg/eclipse/jdt/internal/compiler/ast/Expression;
/*     */     //   72: aload_1
/*     */     //   73: aload_2
/*     */     //   74: iload_3
/*     */     //   75: invokevirtual generateCode : (Lorg/eclipse/jdt/internal/compiler/lookup/BlockScope;Lorg/eclipse/jdt/internal/compiler/codegen/CodeStream;Z)V
/*     */     //   78: goto -> 99
/*     */     //   81: aload_0
/*     */     //   82: getfield left : Lorg/eclipse/jdt/internal/compiler/ast/Expression;
/*     */     //   85: aload_1
/*     */     //   86: aload_2
/*     */     //   87: iconst_0
/*     */     //   88: invokevirtual generateCode : (Lorg/eclipse/jdt/internal/compiler/lookup/BlockScope;Lorg/eclipse/jdt/internal/compiler/codegen/CodeStream;Z)V
/*     */     //   91: iload_3
/*     */     //   92: ifeq -> 99
/*     */     //   95: aload_2
/*     */     //   96: invokevirtual iconst_0 : ()V
/*     */     //   99: aload_0
/*     */     //   100: getfield mergedInitStateIndex : I
/*     */     //   103: iconst_m1
/*     */     //   104: if_icmpeq -> 116
/*     */     //   107: aload_2
/*     */     //   108: aload_1
/*     */     //   109: aload_0
/*     */     //   110: getfield mergedInitStateIndex : I
/*     */     //   113: invokevirtual removeNotDefinitelyAssignedVariables : (Lorg/eclipse/jdt/internal/compiler/lookup/Scope;I)V
/*     */     //   116: aload_2
/*     */     //   117: aload_0
/*     */     //   118: getfield implicitConversion : I
/*     */     //   121: invokevirtual generateImplicitConversion : (I)V
/*     */     //   124: aload_2
/*     */     //   125: iload #4
/*     */     //   127: aload_0
/*     */     //   128: getfield sourceStart : I
/*     */     //   131: invokevirtual recordPositionsFrom : (II)V
/*     */     //   134: return
/*     */     //   135: new org/eclipse/jdt/internal/compiler/codegen/BranchLabel
/*     */     //   138: dup
/*     */     //   139: aload_2
/*     */     //   140: invokespecial <init> : (Lorg/eclipse/jdt/internal/compiler/codegen/CodeStream;)V
/*     */     //   143: astore #6
/*     */     //   145: aload_0
/*     */     //   146: getfield left : Lorg/eclipse/jdt/internal/compiler/ast/Expression;
/*     */     //   149: invokevirtual optimizedBooleanConstant : ()Lorg/eclipse/jdt/internal/compiler/impl/Constant;
/*     */     //   152: astore #5
/*     */     //   154: aload #5
/*     */     //   156: getstatic org/eclipse/jdt/internal/compiler/impl/Constant.NotAConstant : Lorg/eclipse/jdt/internal/compiler/impl/Constant;
/*     */     //   159: if_acmpeq -> 166
/*     */     //   162: iconst_1
/*     */     //   163: goto -> 167
/*     */     //   166: iconst_0
/*     */     //   167: istore #8
/*     */     //   169: iload #8
/*     */     //   171: ifeq -> 186
/*     */     //   174: aload #5
/*     */     //   176: invokevirtual booleanValue : ()Z
/*     */     //   179: ifeq -> 186
/*     */     //   182: iconst_1
/*     */     //   183: goto -> 187
/*     */     //   186: iconst_0
/*     */     //   187: istore #9
/*     */     //   189: aload_0
/*     */     //   190: getfield right : Lorg/eclipse/jdt/internal/compiler/ast/Expression;
/*     */     //   193: invokevirtual optimizedBooleanConstant : ()Lorg/eclipse/jdt/internal/compiler/impl/Constant;
/*     */     //   196: astore #5
/*     */     //   198: aload #5
/*     */     //   200: getstatic org/eclipse/jdt/internal/compiler/impl/Constant.NotAConstant : Lorg/eclipse/jdt/internal/compiler/impl/Constant;
/*     */     //   203: if_acmpeq -> 210
/*     */     //   206: iconst_1
/*     */     //   207: goto -> 211
/*     */     //   210: iconst_0
/*     */     //   211: istore #10
/*     */     //   213: iload #10
/*     */     //   215: ifeq -> 230
/*     */     //   218: aload #5
/*     */     //   220: invokevirtual booleanValue : ()Z
/*     */     //   223: ifeq -> 230
/*     */     //   226: iconst_1
/*     */     //   227: goto -> 231
/*     */     //   230: iconst_0
/*     */     //   231: istore #11
/*     */     //   233: iload #8
/*     */     //   235: ifeq -> 256
/*     */     //   238: aload_0
/*     */     //   239: getfield left : Lorg/eclipse/jdt/internal/compiler/ast/Expression;
/*     */     //   242: aload_1
/*     */     //   243: aload_2
/*     */     //   244: iconst_0
/*     */     //   245: invokevirtual generateCode : (Lorg/eclipse/jdt/internal/compiler/lookup/BlockScope;Lorg/eclipse/jdt/internal/compiler/codegen/CodeStream;Z)V
/*     */     //   248: iload #9
/*     */     //   250: ifne -> 269
/*     */     //   253: goto -> 317
/*     */     //   256: aload_0
/*     */     //   257: getfield left : Lorg/eclipse/jdt/internal/compiler/ast/Expression;
/*     */     //   260: aload_1
/*     */     //   261: aload_2
/*     */     //   262: aconst_null
/*     */     //   263: aload #6
/*     */     //   265: iconst_1
/*     */     //   266: invokevirtual generateOptimizedBoolean : (Lorg/eclipse/jdt/internal/compiler/lookup/BlockScope;Lorg/eclipse/jdt/internal/compiler/codegen/CodeStream;Lorg/eclipse/jdt/internal/compiler/codegen/BranchLabel;Lorg/eclipse/jdt/internal/compiler/codegen/BranchLabel;Z)V
/*     */     //   269: aload_0
/*     */     //   270: getfield rightInitStateIndex : I
/*     */     //   273: iconst_m1
/*     */     //   274: if_icmpeq -> 286
/*     */     //   277: aload_2
/*     */     //   278: aload_1
/*     */     //   279: aload_0
/*     */     //   280: getfield rightInitStateIndex : I
/*     */     //   283: invokevirtual addDefinitelyAssignedVariables : (Lorg/eclipse/jdt/internal/compiler/lookup/Scope;I)V
/*     */     //   286: iload #10
/*     */     //   288: ifeq -> 304
/*     */     //   291: aload_0
/*     */     //   292: getfield right : Lorg/eclipse/jdt/internal/compiler/ast/Expression;
/*     */     //   295: aload_1
/*     */     //   296: aload_2
/*     */     //   297: iconst_0
/*     */     //   298: invokevirtual generateCode : (Lorg/eclipse/jdt/internal/compiler/lookup/BlockScope;Lorg/eclipse/jdt/internal/compiler/codegen/CodeStream;Z)V
/*     */     //   301: goto -> 317
/*     */     //   304: aload_0
/*     */     //   305: getfield right : Lorg/eclipse/jdt/internal/compiler/ast/Expression;
/*     */     //   308: aload_1
/*     */     //   309: aload_2
/*     */     //   310: aconst_null
/*     */     //   311: aload #6
/*     */     //   313: iload_3
/*     */     //   314: invokevirtual generateOptimizedBoolean : (Lorg/eclipse/jdt/internal/compiler/lookup/BlockScope;Lorg/eclipse/jdt/internal/compiler/codegen/CodeStream;Lorg/eclipse/jdt/internal/compiler/codegen/BranchLabel;Lorg/eclipse/jdt/internal/compiler/codegen/BranchLabel;Z)V
/*     */     //   317: aload_0
/*     */     //   318: getfield mergedInitStateIndex : I
/*     */     //   321: iconst_m1
/*     */     //   322: if_icmpeq -> 334
/*     */     //   325: aload_2
/*     */     //   326: aload_1
/*     */     //   327: aload_0
/*     */     //   328: getfield mergedInitStateIndex : I
/*     */     //   331: invokevirtual removeNotDefinitelyAssignedVariables : (Lorg/eclipse/jdt/internal/compiler/lookup/Scope;I)V
/*     */     //   334: iload_3
/*     */     //   335: ifeq -> 484
/*     */     //   338: iload #8
/*     */     //   340: ifeq -> 355
/*     */     //   343: iload #9
/*     */     //   345: ifne -> 355
/*     */     //   348: aload_2
/*     */     //   349: invokevirtual iconst_0 : ()V
/*     */     //   352: goto -> 461
/*     */     //   355: iload #10
/*     */     //   357: ifeq -> 372
/*     */     //   360: iload #11
/*     */     //   362: ifne -> 372
/*     */     //   365: aload_2
/*     */     //   366: invokevirtual iconst_0 : ()V
/*     */     //   369: goto -> 376
/*     */     //   372: aload_2
/*     */     //   373: invokevirtual iconst_1 : ()V
/*     */     //   376: aload #6
/*     */     //   378: invokevirtual forwardReferenceCount : ()I
/*     */     //   381: ifle -> 456
/*     */     //   384: aload_0
/*     */     //   385: getfield bits : I
/*     */     //   388: bipush #16
/*     */     //   390: iand
/*     */     //   391: ifeq -> 419
/*     */     //   394: aload_2
/*     */     //   395: aload_0
/*     */     //   396: getfield implicitConversion : I
/*     */     //   399: invokevirtual generateImplicitConversion : (I)V
/*     */     //   402: aload_2
/*     */     //   403: aload_0
/*     */     //   404: invokevirtual generateReturnBytecode : (Lorg/eclipse/jdt/internal/compiler/ast/Expression;)V
/*     */     //   407: aload #6
/*     */     //   409: invokevirtual place : ()V
/*     */     //   412: aload_2
/*     */     //   413: invokevirtual iconst_0 : ()V
/*     */     //   416: goto -> 461
/*     */     //   419: aload_2
/*     */     //   420: new org/eclipse/jdt/internal/compiler/codegen/BranchLabel
/*     */     //   423: dup
/*     */     //   424: aload_2
/*     */     //   425: invokespecial <init> : (Lorg/eclipse/jdt/internal/compiler/codegen/CodeStream;)V
/*     */     //   428: dup
/*     */     //   429: astore #7
/*     */     //   431: invokevirtual goto_ : (Lorg/eclipse/jdt/internal/compiler/codegen/BranchLabel;)V
/*     */     //   434: aload_2
/*     */     //   435: iconst_1
/*     */     //   436: invokevirtual decrStackSize : (I)V
/*     */     //   439: aload #6
/*     */     //   441: invokevirtual place : ()V
/*     */     //   444: aload_2
/*     */     //   445: invokevirtual iconst_0 : ()V
/*     */     //   448: aload #7
/*     */     //   450: invokevirtual place : ()V
/*     */     //   453: goto -> 461
/*     */     //   456: aload #6
/*     */     //   458: invokevirtual place : ()V
/*     */     //   461: aload_2
/*     */     //   462: aload_0
/*     */     //   463: getfield implicitConversion : I
/*     */     //   466: invokevirtual generateImplicitConversion : (I)V
/*     */     //   469: aload_2
/*     */     //   470: aload_2
/*     */     //   471: getfield position : I
/*     */     //   474: aload_0
/*     */     //   475: getfield sourceEnd : I
/*     */     //   478: invokevirtual recordPositionsFrom : (II)V
/*     */     //   481: goto -> 489
/*     */     //   484: aload #6
/*     */     //   486: invokevirtual place : ()V
/*     */     //   489: return
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #94	-> 0
/*     */     //   #95	-> 6
/*     */     //   #97	-> 16
/*     */     //   #98	-> 20
/*     */     //   #99	-> 32
/*     */     //   #100	-> 42
/*     */     //   #102	-> 43
/*     */     //   #103	-> 52
/*     */     //   #105	-> 60
/*     */     //   #106	-> 68
/*     */     //   #107	-> 78
/*     */     //   #109	-> 81
/*     */     //   #110	-> 91
/*     */     //   #112	-> 99
/*     */     //   #113	-> 107
/*     */     //   #115	-> 116
/*     */     //   #116	-> 124
/*     */     //   #117	-> 134
/*     */     //   #120	-> 135
/*     */     //   #121	-> 145
/*     */     //   #122	-> 154
/*     */     //   #123	-> 169
/*     */     //   #125	-> 189
/*     */     //   #126	-> 198
/*     */     //   #127	-> 213
/*     */     //   #130	-> 233
/*     */     //   #131	-> 238
/*     */     //   #132	-> 248
/*     */     //   #133	-> 253
/*     */     //   #136	-> 256
/*     */     //   #139	-> 269
/*     */     //   #140	-> 277
/*     */     //   #142	-> 286
/*     */     //   #143	-> 291
/*     */     //   #144	-> 301
/*     */     //   #145	-> 304
/*     */     //   #148	-> 317
/*     */     //   #149	-> 325
/*     */     //   #156	-> 334
/*     */     //   #157	-> 338
/*     */     //   #158	-> 348
/*     */     //   #159	-> 352
/*     */     //   #160	-> 355
/*     */     //   #161	-> 365
/*     */     //   #162	-> 369
/*     */     //   #163	-> 372
/*     */     //   #165	-> 376
/*     */     //   #166	-> 384
/*     */     //   #167	-> 394
/*     */     //   #168	-> 402
/*     */     //   #169	-> 407
/*     */     //   #170	-> 412
/*     */     //   #171	-> 416
/*     */     //   #172	-> 419
/*     */     //   #173	-> 434
/*     */     //   #174	-> 439
/*     */     //   #175	-> 444
/*     */     //   #176	-> 448
/*     */     //   #178	-> 453
/*     */     //   #179	-> 456
/*     */     //   #182	-> 461
/*     */     //   #183	-> 469
/*     */     //   #184	-> 481
/*     */     //   #185	-> 484
/*     */     //   #187	-> 489
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	descriptor
/*     */     //   0	490	0	this	Lorg/eclipse/jdt/internal/compiler/ast/AND_AND_Expression;
/*     */     //   0	490	1	currentScope	Lorg/eclipse/jdt/internal/compiler/lookup/BlockScope;
/*     */     //   0	490	2	codeStream	Lorg/eclipse/jdt/internal/compiler/codegen/CodeStream;
/*     */     //   0	490	3	valueRequired	Z
/*     */     //   6	484	4	pc	I
/*     */     //   52	438	5	cst	Lorg/eclipse/jdt/internal/compiler/impl/Constant;
/*     */     //   145	345	6	falseLabel	Lorg/eclipse/jdt/internal/compiler/codegen/BranchLabel;
/*     */     //   431	22	7	endLabel	Lorg/eclipse/jdt/internal/compiler/codegen/BranchLabel;
/*     */     //   169	321	8	leftIsConst	Z
/*     */     //   189	301	9	leftIsTrue	Z
/*     */     //   213	277	10	rightIsConst	Z
/*     */     //   233	257	11	rightIsTrue	Z
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void generateOptimizedBoolean(BlockScope currentScope, CodeStream codeStream, BranchLabel trueLabel, BranchLabel falseLabel, boolean valueRequired) {
/* 195 */     if (this.constant != Constant.NotAConstant) {
/* 196 */       super.generateOptimizedBoolean(currentScope, codeStream, trueLabel, falseLabel, 
/* 197 */           valueRequired);
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/* 202 */     Constant cst = this.right.constant;
/* 203 */     if (cst != Constant.NotAConstant && cst.booleanValue()) {
/* 204 */       int pc = codeStream.position;
/* 205 */       this.left.generateOptimizedBoolean(currentScope, codeStream, trueLabel, falseLabel, valueRequired);
/* 206 */       if (this.mergedInitStateIndex != -1) {
/* 207 */         codeStream.removeNotDefinitelyAssignedVariables((Scope)currentScope, this.mergedInitStateIndex);
/*     */       }
/* 209 */       codeStream.recordPositionsFrom(pc, this.sourceStart);
/*     */       return;
/*     */     } 
/* 212 */     cst = this.left.optimizedBooleanConstant();
/* 213 */     boolean leftIsConst = (cst != Constant.NotAConstant);
/* 214 */     boolean leftIsTrue = (leftIsConst && cst.booleanValue());
/*     */     
/* 216 */     cst = this.right.optimizedBooleanConstant();
/* 217 */     boolean rightIsConst = (cst != Constant.NotAConstant);
/* 218 */     boolean rightIsTrue = (rightIsConst && cst.booleanValue());
/*     */ 
/*     */ 
/*     */     
/* 222 */     if (falseLabel == null) {
/* 223 */       if (trueLabel != null) {
/*     */         
/* 225 */         BranchLabel internalFalseLabel = new BranchLabel(codeStream);
/* 226 */         this.left.generateOptimizedBoolean(currentScope, codeStream, (BranchLabel)null, internalFalseLabel, !leftIsConst);
/*     */         
/* 228 */         if (leftIsConst && !leftIsTrue) {
/* 229 */           internalFalseLabel.place();
/*     */         } else {
/*     */           
/* 232 */           if (this.rightInitStateIndex != -1) {
/* 233 */             codeStream
/* 234 */               .addDefinitelyAssignedVariables((Scope)currentScope, this.rightInitStateIndex);
/*     */           }
/* 236 */           this.right.generateOptimizedBoolean(currentScope, codeStream, trueLabel, (BranchLabel)null, (
/* 237 */               valueRequired && !rightIsConst));
/* 238 */           if (valueRequired && rightIsConst && rightIsTrue) {
/* 239 */             codeStream.goto_(trueLabel);
/* 240 */             codeStream.recordPositionsFrom(codeStream.position, this.sourceEnd);
/*     */           } 
/* 242 */           internalFalseLabel.place();
/*     */         }
/*     */       
/*     */       } 
/* 246 */     } else if (trueLabel == null) {
/* 247 */       this.left.generateOptimizedBoolean(currentScope, codeStream, (BranchLabel)null, falseLabel, !leftIsConst);
/*     */       
/* 249 */       int pc = codeStream.position;
/* 250 */       if (leftIsConst && !leftIsTrue) {
/* 251 */         if (valueRequired) {
/* 252 */           codeStream.goto_(falseLabel);
/*     */         }
/* 254 */         codeStream.recordPositionsFrom(pc, this.sourceEnd);
/*     */       } else {
/*     */         
/* 257 */         if (this.rightInitStateIndex != -1) {
/* 258 */           codeStream
/* 259 */             .addDefinitelyAssignedVariables((Scope)currentScope, this.rightInitStateIndex);
/*     */         }
/* 261 */         this.right.generateOptimizedBoolean(currentScope, codeStream, (BranchLabel)null, falseLabel, (valueRequired && !rightIsConst));
/* 262 */         if (valueRequired && rightIsConst && !rightIsTrue) {
/* 263 */           codeStream.goto_(falseLabel);
/* 264 */           codeStream.recordPositionsFrom(pc, this.sourceEnd);
/*     */         } 
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 271 */     if (this.mergedInitStateIndex != -1) {
/* 272 */       codeStream.removeNotDefinitelyAssignedVariables((Scope)currentScope, this.mergedInitStateIndex);
/*     */     }
/*     */   }
/*     */   
/*     */   public void collectPatternVariablesToScope(LocalVariableBinding[] variables, BlockScope scope) {
/* 277 */     addPatternVariablesWhenTrue(variables);
/*     */     
/* 279 */     this.left.addPatternVariablesWhenTrue(this.patternVarsWhenTrue);
/*     */     
/* 281 */     this.left.collectPatternVariablesToScope(this.patternVarsWhenTrue, scope);
/*     */     
/* 283 */     variables = this.left.getPatternVariablesWhenTrue();
/* 284 */     addPatternVariablesWhenTrue(variables);
/* 285 */     this.right.addPatternVariablesWhenTrue(variables);
/*     */     
/* 287 */     variables = this.left.getPatternVariablesWhenFalse();
/* 288 */     this.right.addPatternVariablesWhenFalse(variables);
/*     */     
/* 290 */     this.right.collectPatternVariablesToScope(this.patternVarsWhenTrue, scope);
/* 291 */     variables = this.right.getPatternVariablesWhenTrue();
/* 292 */     addPatternVariablesWhenTrue(variables);
/*     */   }
/*     */   
/*     */   public boolean isCompactableOperation() {
/* 296 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TypeBinding resolveType(BlockScope scope) {
/* 304 */     TypeBinding result = super.resolveType(scope);
/*     */     
/* 306 */     Binding leftDirect = Expression.getDirectBinding(this.left);
/* 307 */     if (leftDirect != null && leftDirect == Expression.getDirectBinding(this.right) && 
/* 308 */       !(this.right instanceof Assignment)) {
/* 309 */       scope.problemReporter().comparingIdenticalExpressions(this);
/*     */     }
/* 311 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   public void traverse(ASTVisitor visitor, BlockScope scope) {
/* 316 */     if (visitor.visit(this, scope)) {
/* 317 */       this.left.traverse(visitor, scope);
/* 318 */       this.right.traverse(visitor, scope);
/*     */     } 
/* 320 */     visitor.endVisit(this, scope);
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\ast\AND_AND_Expression.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */