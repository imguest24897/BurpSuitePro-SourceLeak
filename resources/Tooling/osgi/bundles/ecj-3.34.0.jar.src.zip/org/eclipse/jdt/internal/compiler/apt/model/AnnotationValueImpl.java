/*     */ package org.eclipse.jdt.internal.compiler.apt.model;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import javax.lang.model.element.AnnotationMirror;
/*     */ import javax.lang.model.element.AnnotationValue;
/*     */ import javax.lang.model.element.AnnotationValueVisitor;
/*     */ import javax.lang.model.element.VariableElement;
/*     */ import javax.lang.model.type.TypeMirror;
/*     */ import org.eclipse.jdt.internal.compiler.apt.dispatch.BaseProcessingEnvImpl;
/*     */ import org.eclipse.jdt.internal.compiler.impl.Constant;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.AnnotationBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.ArrayBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.BaseTypeBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.Binding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.TypeBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.TypeIds;
/*     */ import org.eclipse.jdt.internal.compiler.problem.ShouldNotImplement;
/*     */ import org.eclipse.jdt.internal.compiler.util.Util;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AnnotationValueImpl
/*     */   implements AnnotationValue, TypeIds
/*     */ {
/*     */   private static final int T_AnnotationMirror = -1;
/*     */   private static final int T_EnumConstant = -2;
/*     */   private static final int T_ClassObject = -3;
/*     */   private static final int T_ArrayType = -4;
/*     */   private final BaseProcessingEnvImpl _env;
/*     */   private final Object _value;
/*     */   private final int _kind;
/*     */   
/*     */   public AnnotationValueImpl(BaseProcessingEnvImpl env, Object value, TypeBinding type) {
/*  91 */     this._env = env;
/*  92 */     int[] kind = new int[1];
/*  93 */     if (type == null) {
/*  94 */       this._value = convertToMirrorType(value, type, kind);
/*  95 */       this._kind = kind[0];
/*  96 */     } else if (type.isArrayType()) {
/*  97 */       List<AnnotationValue> convertedValues = null;
/*  98 */       TypeBinding valueType = ((ArrayBinding)type).elementsType();
/*  99 */       if (value instanceof Object[]) {
/* 100 */         Object[] values = (Object[])value;
/* 101 */         convertedValues = new ArrayList<>(values.length); byte b; int i; Object[] arrayOfObject1;
/* 102 */         for (i = (arrayOfObject1 = values).length, b = 0; b < i; ) { Object oneValue = arrayOfObject1[b];
/* 103 */           convertedValues.add(new AnnotationValueImpl(this._env, oneValue, valueType)); b++; }
/*     */       
/*     */       } else {
/* 106 */         convertedValues = new ArrayList<>(1);
/* 107 */         convertedValues.add(new AnnotationValueImpl(this._env, value, valueType));
/*     */       } 
/* 109 */       this._value = Collections.unmodifiableList(convertedValues);
/* 110 */       this._kind = -4;
/*     */     } else {
/* 112 */       this._value = convertToMirrorType(value, type, kind);
/* 113 */       this._kind = kind[0];
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Object convertToMirrorType(Object value, TypeBinding type, int[] kind) {
/* 130 */     if (type == null) {
/* 131 */       kind[0] = 11;
/* 132 */       return "<error>";
/* 133 */     }  if (type instanceof BaseTypeBinding || type.id == 11)
/* 134 */     { if (value == null) {
/* 135 */         if (type instanceof BaseTypeBinding || 
/* 136 */           type.id == 11) {
/*     */           
/* 138 */           kind[0] = 11;
/* 139 */           return "<error>";
/* 140 */         }  if (type.isAnnotationType()) {
/* 141 */           kind[0] = -1;
/* 142 */           return this._env.getFactory().newAnnotationMirror(null);
/*     */         } 
/* 144 */       } else if (value instanceof Constant) {
/* 145 */         if (type instanceof BaseTypeBinding) {
/* 146 */           kind[0] = ((BaseTypeBinding)type).id;
/*     */         }
/* 148 */         else if (type.id == 11) {
/* 149 */           kind[0] = ((Constant)value).typeID();
/*     */         } else {
/*     */           
/* 152 */           kind[0] = 11;
/* 153 */           return "<error>";
/*     */         } 
/* 155 */         switch (kind[0]) {
/*     */           case 5:
/* 157 */             return Boolean.valueOf(((Constant)value).booleanValue());
/*     */           case 3:
/* 159 */             return Byte.valueOf(((Constant)value).byteValue());
/*     */           case 2:
/* 161 */             return Character.valueOf(((Constant)value).charValue());
/*     */           case 8:
/* 163 */             return Double.valueOf(((Constant)value).doubleValue());
/*     */           case 9:
/* 165 */             return Float.valueOf(((Constant)value).floatValue());
/*     */           case 10:
/*     */             try {
/* 168 */               if (value instanceof org.eclipse.jdt.internal.compiler.impl.LongConstant || 
/* 169 */                 value instanceof org.eclipse.jdt.internal.compiler.impl.DoubleConstant || 
/* 170 */                 value instanceof org.eclipse.jdt.internal.compiler.impl.FloatConstant) {
/*     */                 
/* 172 */                 kind[0] = 11;
/* 173 */                 return "<error>";
/*     */               } 
/* 175 */               return Integer.valueOf(((Constant)value).intValue());
/* 176 */             } catch (ShouldNotImplement shouldNotImplement) {
/* 177 */               kind[0] = 11;
/* 178 */               return "<error>";
/*     */             } 
/*     */           case 11:
/* 181 */             return ((Constant)value).stringValue();
/*     */           case 7:
/* 183 */             return Long.valueOf(((Constant)value).longValue());
/*     */           case 4:
/* 185 */             return Short.valueOf(((Constant)value).shortValue());
/*     */         } 
/*     */       }  }
/* 188 */     else { if (type.isEnum()) {
/* 189 */         if (value instanceof org.eclipse.jdt.internal.compiler.lookup.FieldBinding) {
/* 190 */           kind[0] = -2;
/* 191 */           return this._env.getFactory().newElement((Binding)value);
/*     */         } 
/* 193 */         kind[0] = 11;
/* 194 */         return "<error>";
/*     */       } 
/* 196 */       if (type.isAnnotationType()) {
/* 197 */         if (value instanceof AnnotationBinding) {
/* 198 */           kind[0] = -1;
/* 199 */           return this._env.getFactory().newAnnotationMirror((AnnotationBinding)value);
/*     */         } 
/* 201 */       } else if (value instanceof TypeBinding) {
/* 202 */         kind[0] = -3;
/* 203 */         return this._env.getFactory().newTypeMirror((Binding)value);
/*     */       }  }
/*     */     
/* 206 */     kind[0] = 11;
/* 207 */     return "<error>";
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public <R, P> R accept(AnnotationValueVisitor<R, P> v, P p) {
/* 213 */     switch (this._kind) {
/*     */       case 5:
/* 215 */         return v.visitBoolean(((Boolean)this._value).booleanValue(), p);
/*     */       case 3:
/* 217 */         return v.visitByte(((Byte)this._value).byteValue(), p);
/*     */       case 2:
/* 219 */         return v.visitChar(((Character)this._value).charValue(), p);
/*     */       case 8:
/* 221 */         return v.visitDouble(((Double)this._value).doubleValue(), p);
/*     */       case 9:
/* 223 */         return v.visitFloat(((Float)this._value).floatValue(), p);
/*     */       case 10:
/* 225 */         return v.visitInt(((Integer)this._value).intValue(), p);
/*     */       case 11:
/* 227 */         return v.visitString((String)this._value, p);
/*     */       case 7:
/* 229 */         return v.visitLong(((Long)this._value).longValue(), p);
/*     */       case 4:
/* 231 */         return v.visitShort(((Short)this._value).shortValue(), p);
/*     */       case -2:
/* 233 */         return v.visitEnumConstant((VariableElement)this._value, p);
/*     */       case -3:
/* 235 */         return v.visitType((TypeMirror)this._value, p);
/*     */       case -1:
/* 237 */         return v.visitAnnotation((AnnotationMirror)this._value, p);
/*     */       case -4:
/* 239 */         return v.visitArray((List<? extends AnnotationValue>)this._value, p);
/*     */     } 
/* 241 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Object getValue() {
/* 247 */     return this._value;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object obj) {
/* 252 */     if (obj instanceof AnnotationValueImpl) {
/* 253 */       return this._value.equals(((AnnotationValueImpl)obj)._value);
/*     */     }
/* 255 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 260 */     return this._value.hashCode() + this._kind;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 265 */     if (this._value == null)
/* 266 */       return "null"; 
/* 267 */     if (this._value instanceof String) {
/* 268 */       String value = (String)this._value;
/* 269 */       StringBuffer sb = new StringBuffer();
/* 270 */       sb.append('"');
/* 271 */       for (int i = 0; i < value.length(); i++) {
/* 272 */         Util.appendEscapedChar(sb, value.charAt(i), true);
/*     */       }
/* 274 */       sb.append('"');
/* 275 */       return sb.toString();
/* 276 */     }  if (this._value instanceof Character) {
/* 277 */       StringBuffer sb = new StringBuffer();
/* 278 */       sb.append('\'');
/* 279 */       Util.appendEscapedChar(sb, ((Character)this._value).charValue(), false);
/* 280 */       sb.append('\'');
/* 281 */       return sb.toString();
/* 282 */     }  if (this._value instanceof VariableElement) {
/* 283 */       VariableElement enumDecl = (VariableElement)this._value;
/* 284 */       return String.valueOf(enumDecl.asType().toString()) + "." + enumDecl.getSimpleName();
/* 285 */     }  if (this._value instanceof Collection) {
/*     */ 
/*     */       
/* 288 */       Collection<AnnotationValue> values = (Collection<AnnotationValue>)this._value;
/* 289 */       StringBuilder sb = new StringBuilder();
/* 290 */       sb.append('{');
/* 291 */       boolean first = true;
/* 292 */       for (AnnotationValue annoValue : values) {
/* 293 */         if (!first) {
/* 294 */           sb.append(", ");
/*     */         }
/* 296 */         first = false;
/* 297 */         sb.append(annoValue.toString());
/*     */       } 
/* 299 */       sb.append('}');
/* 300 */       return sb.toString();
/* 301 */     }  if (this._value instanceof TypeMirror) {
/* 302 */       return String.valueOf(this._value.toString()) + ".class";
/*     */     }
/* 304 */     return this._value.toString();
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\apt\model\AnnotationValueImpl.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */