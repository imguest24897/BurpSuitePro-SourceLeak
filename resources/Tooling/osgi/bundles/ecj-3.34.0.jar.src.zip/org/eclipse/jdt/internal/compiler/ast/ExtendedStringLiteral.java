/*    */ package org.eclipse.jdt.internal.compiler.ast;
/*    */ 
/*    */ import org.eclipse.jdt.internal.compiler.ASTVisitor;
/*    */ import org.eclipse.jdt.internal.compiler.lookup.BlockScope;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ExtendedStringLiteral
/*    */   extends StringLiteral
/*    */ {
/*    */   public ExtendedStringLiteral(StringLiteral str, CharLiteral character) {
/* 26 */     super(str.source, str.sourceStart, str.sourceEnd, str.lineNumber);
/* 27 */     extendWith(character);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public ExtendedStringLiteral(StringLiteral str1, StringLiteral str2) {
/* 35 */     super(str1.source, str1.sourceStart, str1.sourceEnd, str1.lineNumber);
/* 36 */     extendWith(str2);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public ExtendedStringLiteral extendWith(CharLiteral lit) {
/* 46 */     int length = this.source.length;
/* 47 */     System.arraycopy(this.source, 0, this.source = new char[length + 1], 0, length);
/* 48 */     this.source[length] = lit.value;
/*    */     
/* 50 */     this.sourceEnd = lit.sourceEnd;
/* 51 */     return this;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public ExtendedStringLiteral extendWith(StringLiteral lit) {
/* 61 */     int length = this.source.length;
/* 62 */     System.arraycopy(
/* 63 */         this.source, 
/* 64 */         0, 
/* 65 */         this.source = new char[length + lit.source.length], 
/* 66 */         0, 
/* 67 */         length);
/* 68 */     System.arraycopy(lit.source, 0, this.source, length, lit.source.length);
/*    */     
/* 70 */     this.sourceEnd = lit.sourceEnd;
/* 71 */     return this;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public StringBuffer printExpression(int indent, StringBuffer output) {
/* 77 */     return output.append("ExtendedStringLiteral{").append(this.source).append('}');
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void traverse(ASTVisitor visitor, BlockScope scope) {
/* 83 */     visitor.visit(this, scope);
/* 84 */     visitor.endVisit(this, scope);
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\ast\ExtendedStringLiteral.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */