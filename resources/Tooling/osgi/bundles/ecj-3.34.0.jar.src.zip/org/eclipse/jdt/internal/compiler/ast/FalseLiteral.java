/*    */ package org.eclipse.jdt.internal.compiler.ast;
/*    */ 
/*    */ import org.eclipse.jdt.internal.compiler.ASTVisitor;
/*    */ import org.eclipse.jdt.internal.compiler.codegen.BranchLabel;
/*    */ import org.eclipse.jdt.internal.compiler.codegen.CodeStream;
/*    */ import org.eclipse.jdt.internal.compiler.impl.BooleanConstant;
/*    */ import org.eclipse.jdt.internal.compiler.lookup.BlockScope;
/*    */ import org.eclipse.jdt.internal.compiler.lookup.TypeBinding;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FalseLiteral
/*    */   extends MagicLiteral
/*    */ {
/* 25 */   static final char[] source = new char[] { 'f', 'a', 'l', 's', 'e' };
/*    */   
/*    */   public FalseLiteral(int s, int e) {
/* 28 */     super(s, e);
/*    */   }
/*    */   
/*    */   public void computeConstant() {
/* 32 */     this.constant = BooleanConstant.fromValue(false);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void generateCode(BlockScope currentScope, CodeStream codeStream, boolean valueRequired) {
/* 43 */     int pc = codeStream.position;
/* 44 */     if (valueRequired) {
/* 45 */       codeStream.generateConstant(this.constant, this.implicitConversion);
/*    */     }
/* 47 */     codeStream.recordPositionsFrom(pc, this.sourceStart);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void generateOptimizedBoolean(BlockScope currentScope, CodeStream codeStream, BranchLabel trueLabel, BranchLabel falseLabel, boolean valueRequired) {
/* 54 */     int pc = codeStream.position;
/* 55 */     if (valueRequired && 
/* 56 */       falseLabel != null)
/*    */     {
/* 58 */       if (trueLabel == null) {
/* 59 */         codeStream.goto_(falseLabel);
/*    */       }
/*    */     }
/*    */     
/* 63 */     codeStream.recordPositionsFrom(pc, this.sourceStart);
/*    */   }
/*    */   
/*    */   public TypeBinding literalType(BlockScope scope) {
/* 67 */     return (TypeBinding)TypeBinding.BOOLEAN;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public char[] source() {
/* 74 */     return source;
/*    */   }
/*    */   
/*    */   public void traverse(ASTVisitor visitor, BlockScope scope) {
/* 78 */     visitor.visit(this, scope);
/* 79 */     visitor.endVisit(this, scope);
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\ast\FalseLiteral.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */