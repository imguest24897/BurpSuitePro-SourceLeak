/*      */ package org.eclipse.jdt.internal.compiler.lookup;
/*      */ 
/*      */ import java.util.ArrayList;
/*      */ import java.util.HashMap;
/*      */ import java.util.HashSet;
/*      */ import java.util.LinkedHashSet;
/*      */ import java.util.Map;
/*      */ import java.util.Set;
/*      */ import java.util.function.Predicate;
/*      */ import org.eclipse.jdt.core.compiler.CharOperation;
/*      */ import org.eclipse.jdt.internal.compiler.ast.ASTNode;
/*      */ import org.eclipse.jdt.internal.compiler.ast.CompilationUnitDeclaration;
/*      */ import org.eclipse.jdt.internal.compiler.ast.ImportReference;
/*      */ import org.eclipse.jdt.internal.compiler.ast.Invocation;
/*      */ import org.eclipse.jdt.internal.compiler.ast.ModuleDeclaration;
/*      */ import org.eclipse.jdt.internal.compiler.ast.TypeDeclaration;
/*      */ import org.eclipse.jdt.internal.compiler.env.AccessRestriction;
/*      */ import org.eclipse.jdt.internal.compiler.env.IUpdatableModule;
/*      */ import org.eclipse.jdt.internal.compiler.impl.CompilerOptions;
/*      */ import org.eclipse.jdt.internal.compiler.impl.ReferenceContext;
/*      */ import org.eclipse.jdt.internal.compiler.problem.ProblemReporter;
/*      */ import org.eclipse.jdt.internal.compiler.util.HashtableOfObject;
/*      */ import org.eclipse.jdt.internal.compiler.util.HashtableOfType;
/*      */ import org.eclipse.jdt.internal.compiler.util.ObjectVector;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class CompilationUnitScope
/*      */   extends Scope
/*      */ {
/*      */   public LookupEnvironment environment;
/*      */   public CompilationUnitDeclaration referenceContext;
/*      */   public char[][] currentPackageName;
/*      */   public PlainPackageBinding fPackage;
/*      */   public ImportBinding[] imports;
/*      */   public int importPtr;
/*      */   public HashtableOfObject typeOrPackageCache;
/*      */   public SourceTypeBinding[] topLevelTypes;
/*      */   private SortedCompoundNameVector qualifiedReferences;
/*      */   private SortedSimpleNameVector simpleNameReferences;
/*      */   private SortedSimpleNameVector rootReferences;
/*      */   private LinkedHashSet<ReferenceBindingSetWrapper> referencedTypes;
/*      */   private Set<ReferenceBindingSetWrapper> referencedSuperTypesSet;
/*      */   private ObjectVector referencedSuperTypes;
/*      */   HashtableOfType constantPoolNameUsage;
/*   59 */   private int captureID = 1;
/*      */ 
/*      */   
/*      */   private ImportBinding[] tempImports;
/*      */ 
/*      */   
/*      */   private boolean skipCachingImports;
/*      */ 
/*      */   
/*      */   boolean connectingHierarchy;
/*      */   
/*      */   private ArrayList<Invocation> inferredInvocations;
/*      */   
/*   72 */   Map<InferenceVariable.InferenceVarKey, InferenceVariable> uniqueInferenceVariables = new HashMap<>();
/*      */   
/*      */   public CompilationUnitScope(CompilationUnitDeclaration unit, LookupEnvironment environment) {
/*   75 */     this(unit, environment.globalOptions);
/*   76 */     this.environment = environment;
/*      */   }
/*      */   
/*      */   public CompilationUnitScope(CompilationUnitDeclaration unit, CompilerOptions compilerOptions) {
/*   80 */     super(4, null);
/*   81 */     this.referenceContext = unit;
/*   82 */     unit.scope = this;
/*   83 */     this.currentPackageName = (unit.currentPackage == null) ? CharOperation.NO_CHAR_CHAR : unit.currentPackage.tokens;
/*      */     
/*   85 */     if (compilerOptions.produceReferenceInfo) {
/*   86 */       this.qualifiedReferences = new SortedCompoundNameVector();
/*   87 */       this.simpleNameReferences = new SortedSimpleNameVector();
/*   88 */       this.rootReferences = new SortedSimpleNameVector();
/*   89 */       this.referencedTypes = new LinkedHashSet<>();
/*   90 */       this.referencedSuperTypesSet = new HashSet<>();
/*   91 */       this.referencedSuperTypes = new ObjectVector();
/*      */     } else {
/*   93 */       this.qualifiedReferences = null;
/*   94 */       this.simpleNameReferences = null;
/*   95 */       this.rootReferences = null;
/*   96 */       this.referencedTypes = null;
/*   97 */       this.referencedSuperTypesSet = null;
/*   98 */       this.referencedSuperTypes = null;
/*      */     } 
/*      */   }
/*      */   
/*      */   void buildFieldsAndMethods() {
/*  103 */     for (int i = 0, length = this.topLevelTypes.length; i < length; i++)
/*  104 */       (this.topLevelTypes[i]).scope.buildFieldsAndMethods(); 
/*      */   }
/*      */   void buildTypeBindings(AccessRestriction accessRestriction) {
/*  107 */     this.topLevelTypes = new SourceTypeBinding[0];
/*  108 */     boolean firstIsSynthetic = false;
/*  109 */     if (this.referenceContext.compilationResult.compilationUnit != null) {
/*  110 */       char[][] expectedPackageName = this.referenceContext.compilationResult.compilationUnit.getPackageName();
/*  111 */       if (expectedPackageName != null && !this.referenceContext.isModuleInfo() && 
/*  112 */         !CharOperation.equals(this.currentPackageName, expectedPackageName)) {
/*      */ 
/*      */         
/*  115 */         if (this.referenceContext.currentPackage != null || 
/*  116 */           this.referenceContext.types != null || 
/*  117 */           this.referenceContext.imports != null) {
/*  118 */           problemReporter().packageIsNotExpectedPackage(this.referenceContext);
/*      */         }
/*  120 */         this.currentPackageName = (expectedPackageName.length == 0) ? CharOperation.NO_CHAR_CHAR : expectedPackageName;
/*      */       } 
/*      */     } 
/*  123 */     if (this.currentPackageName == CharOperation.NO_CHAR_CHAR) {
/*      */       
/*  125 */       this.fPackage = this.environment.defaultPackage;
/*  126 */       if (this.referenceContext.isModuleInfo()) {
/*  127 */         ModuleDeclaration moduleDecl = this.referenceContext.moduleDeclaration;
/*  128 */         if (moduleDecl != null) {
/*  129 */           moduleDecl.createScope(this);
/*  130 */           moduleDecl.checkAndSetModifiers();
/*      */         } 
/*  132 */       } else if (module() != this.environment.UnNamedModule) {
/*  133 */         problemReporter().unnamedPackageInNamedModule(module());
/*      */       } 
/*      */     } else {
/*  136 */       if ((this.fPackage = this.environment.createPlainPackage(this.currentPackageName)) == null) {
/*  137 */         if (this.referenceContext.currentPackage != null) {
/*  138 */           problemReporter().packageCollidesWithType(this.referenceContext);
/*      */         }
/*      */         
/*  141 */         this.fPackage = this.environment.defaultPackage; return;
/*      */       } 
/*  143 */       if (this.referenceContext.isPackageInfo()) {
/*      */         
/*  145 */         if (this.referenceContext.types == null || this.referenceContext.types.length == 0) {
/*  146 */           this.referenceContext.types = new TypeDeclaration[1];
/*  147 */           this.referenceContext.createPackageInfoType();
/*  148 */           firstIsSynthetic = true;
/*      */         } 
/*      */         
/*  151 */         if (this.referenceContext.currentPackage != null && this.referenceContext.currentPackage.annotations != null) {
/*  152 */           (this.referenceContext.types[0]).annotations = this.referenceContext.currentPackage.annotations;
/*      */         }
/*      */       } 
/*  155 */       recordQualifiedReference(this.currentPackageName);
/*      */     } 
/*      */ 
/*      */     
/*  159 */     TypeDeclaration[] types = this.referenceContext.types;
/*  160 */     int typeLength = (types == null) ? 0 : types.length;
/*  161 */     this.topLevelTypes = new SourceTypeBinding[typeLength];
/*  162 */     int count = 0;
/*  163 */     for (int i = 0; i < typeLength; i++) {
/*  164 */       TypeDeclaration typeDecl = types[i];
/*  165 */       if (this.environment.root.isProcessingAnnotations && this.environment.isMissingType(typeDecl.name))
/*  166 */         throw new SourceTypeCollisionException(); 
/*  167 */       recordSimpleReference(typeDecl.name);
/*  168 */       if (this.fPackage.hasType0Any(typeDecl.name)) {
/*      */         
/*  170 */         if (this.environment.root.isProcessingAnnotations) {
/*  171 */           throw new SourceTypeCollisionException();
/*      */         }
/*      */ 
/*      */         
/*  175 */         problemReporter().duplicateTypes(this.referenceContext, typeDecl);
/*      */       }
/*      */       else {
/*      */         
/*  179 */         if ((typeDecl.modifiers & 0x1) != 0) {
/*      */           char[] mainTypeName;
/*  181 */           if ((mainTypeName = this.referenceContext.getMainTypeName()) != null && 
/*  182 */             !CharOperation.equals(mainTypeName, typeDecl.name)) {
/*  183 */             problemReporter().publicClassMustMatchFileName(this.referenceContext, typeDecl);
/*      */           }
/*      */         } 
/*      */ 
/*      */         
/*  188 */         ClassScope child = new ClassScope(this, typeDecl);
/*  189 */         SourceTypeBinding type = child.buildType((SourceTypeBinding)null, this.fPackage, accessRestriction);
/*  190 */         if (firstIsSynthetic && i == 0)
/*  191 */           type.modifiers |= 0x1000; 
/*  192 */         if (type != null) {
/*  193 */           this.topLevelTypes[count++] = type;
/*      */         }
/*      */       } 
/*      */     } 
/*  197 */     if (count != this.topLevelTypes.length) {
/*  198 */       System.arraycopy(this.topLevelTypes, 0, this.topLevelTypes = new SourceTypeBinding[count], 0, count);
/*      */     }
/*  200 */     if (this.referenceContext.moduleDeclaration != null) {
/*  201 */       module().completeIfNeeded(IUpdatableModule.UpdateKind.MODULE);
/*  202 */       this.referenceContext.moduleDeclaration.resolvePackageDirectives(this);
/*  203 */       module().completeIfNeeded(IUpdatableModule.UpdateKind.PACKAGE);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   void checkAndSetImports() {
/*  209 */     TypeDeclaration[] types = this.referenceContext.types;
/*  210 */     if (types != null) {
/*  211 */       for (int j = 0; j < types.length; j++) {
/*  212 */         TypeDeclaration typeDecl = types[j];
/*  213 */         if (this.fPackage != this.environment.defaultPackage && this.fPackage.getPackage(typeDecl.name, module()) != null)
/*      */         {
/*      */           
/*  216 */           problemReporter().typeCollidesWithPackage(this.referenceContext, typeDecl);
/*      */         }
/*      */       } 
/*      */     }
/*      */     
/*  221 */     if (this.referenceContext.moduleDeclaration != null) {
/*  222 */       this.referenceContext.moduleDeclaration.resolveModuleDirectives(this);
/*      */     }
/*      */     
/*  225 */     if (this.referenceContext.imports == null) {
/*  226 */       this.imports = getDefaultImports();
/*      */       
/*      */       return;
/*      */     } 
/*      */     
/*  231 */     int numberOfStatements = this.referenceContext.imports.length;
/*  232 */     int numberOfImports = numberOfStatements + 1;
/*  233 */     for (int i = 0; i < numberOfStatements; i++) {
/*  234 */       ImportReference importReference = this.referenceContext.imports[i];
/*  235 */       if ((importReference.bits & 0x20000) != 0 && CharOperation.equals(TypeConstants.JAVA_LANG, importReference.tokens) && !importReference.isStatic()) {
/*  236 */         numberOfImports--;
/*      */         break;
/*      */       } 
/*      */     } 
/*  240 */     ImportBinding[] resolvedImports = new ImportBinding[numberOfImports];
/*  241 */     resolvedImports[0] = getDefaultImports()[0];
/*  242 */     int index = 1;
/*      */     
/*  244 */     Predicate<ImportReference> isStaticImport = i -> i.isStatic();
/*  245 */     Predicate<ImportReference> isNotStaticImport = Predicate.not(isStaticImport);
/*      */ 
/*      */     
/*  248 */     index = resolveImports(numberOfStatements, resolvedImports, index, isNotStaticImport);
/*      */ 
/*      */     
/*  251 */     ImportBinding[] temp = new ImportBinding[index];
/*  252 */     System.arraycopy(resolvedImports, 0, temp, 0, index);
/*  253 */     this.imports = temp;
/*      */ 
/*      */     
/*  256 */     index = resolveImports(numberOfStatements, resolvedImports, index, isStaticImport);
/*      */ 
/*      */     
/*  259 */     if (resolvedImports.length > index) {
/*  260 */       System.arraycopy(resolvedImports, 0, resolvedImports = new ImportBinding[index], 0, index);
/*      */     }
/*  262 */     this.imports = resolvedImports;
/*      */   }
/*      */   
/*      */   private int resolveImports(int numberOfStatements, ImportBinding[] resolvedImports, int index, Predicate<ImportReference> filter) {
/*  266 */     for (int i = 0; i < numberOfStatements; i++) {
/*  267 */       ImportReference importReference = this.referenceContext.imports[i];
/*  268 */       if (filter.test(importReference)) {
/*      */ 
/*      */ 
/*      */         
/*  272 */         char[][] compoundName = importReference.tokens;
/*      */ 
/*      */         
/*  275 */         for (int j = 0; j < index; j++) {
/*  276 */           ImportBinding resolved = resolvedImports[j];
/*  277 */           if (resolved.onDemand == (((importReference.bits & 0x20000) != 0)) && resolved.isStatic() == importReference.isStatic() && 
/*  278 */             CharOperation.equals(compoundName, (resolvedImports[j]).compoundName)) {
/*      */             // Byte code: goto -> 224
/*      */           }
/*      */         } 
/*      */ 
/*      */         
/*  284 */         if ((importReference.bits & 0x20000) != 0) {
/*  285 */           if (!CharOperation.equals(compoundName, this.currentPackageName)) {
/*      */ 
/*      */ 
/*      */             
/*  289 */             Binding importBinding = findImport(compoundName, compoundName.length);
/*  290 */             if (importBinding.isValidBinding() && (!importReference.isStatic() || !(importBinding instanceof PackageBinding)))
/*      */             {
/*      */               
/*  293 */               resolvedImports[index++] = new ImportBinding(compoundName, true, importBinding, importReference); } 
/*      */           } 
/*      */         } else {
/*  296 */           resolvedImports[index++] = new ImportBinding(compoundName, false, null, importReference);
/*      */         } 
/*      */       } 
/*  299 */     }  return index;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void checkParameterizedTypes() {
/*  306 */     if ((compilerOptions()).sourceLevel < 3211264L)
/*      */       return; 
/*  308 */     for (int i = 0, length = this.topLevelTypes.length; i < length; i++) {
/*  309 */       ClassScope scope = (this.topLevelTypes[i]).scope;
/*  310 */       scope.checkParameterizedTypeBounds();
/*  311 */       scope.checkParameterizedSuperTypeCollisions();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public char[] computeConstantPoolName(LocalTypeBinding localType) {
/*      */     char[] candidateName;
/*  320 */     if (localType.constantPoolName != null) {
/*  321 */       return localType.constantPoolName;
/*      */     }
/*      */ 
/*      */     
/*  325 */     if (this.constantPoolNameUsage == null) {
/*  326 */       this.constantPoolNameUsage = new HashtableOfType();
/*      */     }
/*  328 */     ReferenceBinding outerMostEnclosingType = localType.scope.outerMostClassScope().enclosingSourceType();
/*      */ 
/*      */     
/*  331 */     int index = 0;
/*      */     
/*  333 */     boolean isCompliant15 = ((compilerOptions()).complianceLevel >= 3211264L);
/*      */     while (true) {
/*  335 */       if (localType.isMemberType()) {
/*  336 */         if (index == 0) {
/*  337 */           candidateName = CharOperation.concat(
/*  338 */               localType.enclosingType().constantPoolName(), 
/*  339 */               localType.sourceName, 
/*  340 */               '$');
/*      */         }
/*      */         else {
/*      */           
/*  344 */           candidateName = CharOperation.concat(
/*  345 */               localType.enclosingType().constantPoolName(), 
/*  346 */               '$', 
/*  347 */               String.valueOf(index).toCharArray(), 
/*  348 */               '$', 
/*  349 */               localType.sourceName);
/*      */         } 
/*  351 */       } else if (localType.isAnonymousType()) {
/*  352 */         if (isCompliant15) {
/*      */           
/*  354 */           candidateName = CharOperation.concat(
/*  355 */               localType.enclosingType.constantPoolName(), 
/*  356 */               String.valueOf(index + 1).toCharArray(), 
/*  357 */               '$');
/*      */         } else {
/*  359 */           candidateName = CharOperation.concat(
/*  360 */               outerMostEnclosingType.constantPoolName(), 
/*  361 */               String.valueOf(index + 1).toCharArray(), 
/*  362 */               '$');
/*      */         }
/*      */       
/*      */       }
/*  366 */       else if (isCompliant15) {
/*  367 */         candidateName = CharOperation.concat(
/*  368 */             CharOperation.concat(
/*  369 */               localType.enclosingType().constantPoolName(), 
/*  370 */               String.valueOf(index + 1).toCharArray(), 
/*  371 */               '$'), 
/*  372 */             localType.sourceName);
/*      */       } else {
/*  374 */         candidateName = CharOperation.concat(
/*  375 */             outerMostEnclosingType.constantPoolName(), 
/*  376 */             '$', 
/*  377 */             String.valueOf(index + 1).toCharArray(), 
/*  378 */             '$', 
/*  379 */             localType.sourceName);
/*      */       } 
/*      */       
/*  382 */       if (this.constantPoolNameUsage.get(candidateName) != null) {
/*  383 */         index++; continue;
/*      */       }  break;
/*  385 */     }  this.constantPoolNameUsage.put(candidateName, localType);
/*      */ 
/*      */ 
/*      */     
/*  389 */     return candidateName;
/*      */   } void connectTypeHierarchy() {
/*      */     int i;
/*      */     int length;
/*  393 */     for (i = 0, length = this.topLevelTypes.length; i < length; i++) {
/*  394 */       (this.topLevelTypes[i]).scope.connectTypeHierarchy();
/*      */     }
/*      */     
/*  397 */     for (i = 0, length = this.topLevelTypes.length; i < length; i++)
/*  398 */       (this.topLevelTypes[i]).scope.connectImplicitPermittedTypes(); 
/*      */   }
/*      */   void faultInImports() {
/*  401 */     if (this.tempImports != null)
/*      */       return; 
/*  403 */     boolean unresolvedFound = false;
/*      */     
/*  405 */     boolean reportUnresolved = !this.environment.suppressImportErrors;
/*      */     
/*  407 */     if (this.typeOrPackageCache != null && !this.skipCachingImports)
/*      */       return; 
/*  409 */     if (this.referenceContext.imports == null) {
/*  410 */       this.typeOrPackageCache = new HashtableOfObject(1);
/*      */       
/*      */       return;
/*      */     } 
/*      */     
/*  415 */     int numberOfStatements = this.referenceContext.imports.length;
/*  416 */     HashtableOfType typesBySimpleNames = null;
/*  417 */     for (int i = 0; i < numberOfStatements; i++) {
/*  418 */       if (((this.referenceContext.imports[i]).bits & 0x20000) == 0) {
/*  419 */         typesBySimpleNames = new HashtableOfType(this.topLevelTypes.length + numberOfStatements);
/*  420 */         for (int n = 0, i1 = this.topLevelTypes.length; n < i1; n++) {
/*  421 */           typesBySimpleNames.put((this.topLevelTypes[n]).sourceName, this.topLevelTypes[n]);
/*      */         }
/*      */         
/*      */         break;
/*      */       } 
/*      */     } 
/*  427 */     int numberOfImports = numberOfStatements + 1;
/*  428 */     for (int j = 0; j < numberOfStatements; j++) {
/*  429 */       ImportReference importReference = this.referenceContext.imports[j];
/*  430 */       if ((importReference.bits & 0x20000) != 0 && CharOperation.equals(TypeConstants.JAVA_LANG, importReference.tokens) && !importReference.isStatic()) {
/*  431 */         numberOfImports--;
/*      */         break;
/*      */       } 
/*      */     } 
/*  435 */     this.tempImports = new ImportBinding[numberOfImports];
/*  436 */     this.tempImports[0] = getDefaultImports()[0];
/*  437 */     this.importPtr = 1;
/*      */     
/*  439 */     CompilerOptions compilerOptions = compilerOptions();
/*  440 */     boolean inJdtDebugCompileMode = compilerOptions.enableJdtDebugCompileMode;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  445 */     for (int k = 0; k < numberOfStatements; k++) {
/*  446 */       ImportReference importReference = this.referenceContext.imports[k];
/*  447 */       char[][] compoundName = importReference.getImportName();
/*      */ 
/*      */       
/*  450 */       for (int n = 0; n < this.importPtr; n++) {
/*  451 */         ImportBinding resolved = this.tempImports[n];
/*  452 */         if (resolved.onDemand == (((importReference.bits & 0x20000) != 0)) && resolved.isStatic() == importReference.isStatic() && 
/*  453 */           CharOperation.equals(compoundName, resolved.compoundName) && CharOperation.equals(importReference.getSimpleName(), resolved.getSimpleName())) {
/*  454 */           problemReporter().unusedImport(importReference);
/*      */           
/*      */           // Byte code: goto -> 940
/*      */         } 
/*      */       } 
/*  459 */       if ((importReference.bits & 0x20000) != 0) {
/*  460 */         Binding binding = findImport(compoundName, compoundName.length);
/*  461 */         if (!binding.isValidBinding()) {
/*  462 */           problemReporter().importProblem(importReference, binding);
/*      */           continue;
/*      */         } 
/*  465 */         if (binding instanceof PackageBinding) {
/*  466 */           PackageBinding uniquePackage = ((PackageBinding)binding).getVisibleFor(module(), false);
/*  467 */           if (uniquePackage instanceof SplitPackageBinding && !inJdtDebugCompileMode) {
/*  468 */             SplitPackageBinding splitPackage = (SplitPackageBinding)uniquePackage;
/*  469 */             problemReporter().conflictingPackagesFromModules(splitPackage, module(), importReference.sourceStart, importReference.sourceEnd);
/*      */             continue;
/*      */           } 
/*      */         } 
/*  473 */         if (importReference.isStatic() && binding instanceof PackageBinding) {
/*  474 */           problemReporter().cannotImportPackage(importReference);
/*      */         } else {
/*      */           
/*  477 */           recordImportBinding(new ImportBinding(compoundName, true, binding, importReference));
/*      */         }  continue;
/*  479 */       }  Binding importBinding = findSingleImport(compoundName, 13, importReference.isStatic());
/*  480 */       if (importBinding instanceof SplitPackageBinding && !inJdtDebugCompileMode) {
/*  481 */         SplitPackageBinding splitPackage = (SplitPackageBinding)importBinding;
/*  482 */         int sourceEnd = (int)(importReference.sourcePositions[splitPackage.compoundName.length - 1] & 0xFFFFL);
/*  483 */         problemReporter().conflictingPackagesFromModules((SplitPackageBinding)importBinding, module(), importReference.sourceStart, sourceEnd);
/*      */         continue;
/*      */       } 
/*  486 */       if (!importBinding.isValidBinding() && 
/*  487 */         importBinding.problemId() != 3) {
/*      */ 
/*      */         
/*  490 */         unresolvedFound = true;
/*  491 */         if (reportUnresolved) {
/*  492 */           problemReporter().importProblem(importReference, importBinding);
/*      */         }
/*      */         
/*      */         continue;
/*      */       } 
/*  497 */       if (importBinding instanceof PackageBinding) {
/*  498 */         problemReporter().cannotImportPackage(importReference); continue;
/*      */       } 
/*  500 */       if (this.environment.useModuleSystem && importBinding instanceof ReferenceBinding) {
/*  501 */         PackageBinding importedPackage = ((ReferenceBinding)importBinding).fPackage;
/*  502 */         if (importedPackage != null) {
/*  503 */           if (!importedPackage.isValidBinding()) {
/*  504 */             problemReporter().importProblem(importReference, importedPackage);
/*      */             
/*      */             continue;
/*      */           } 
/*  508 */           importedPackage = (PackageBinding)findImport(importedPackage.compoundName, false, true);
/*  509 */           if (importedPackage != null)
/*  510 */             importedPackage = importedPackage.getVisibleFor(module(), true); 
/*  511 */           if (importedPackage instanceof SplitPackageBinding && !inJdtDebugCompileMode) {
/*  512 */             SplitPackageBinding splitPackage = (SplitPackageBinding)importedPackage;
/*  513 */             int sourceEnd = (int)importReference.sourcePositions[splitPackage.compoundName.length - 1];
/*  514 */             problemReporter().conflictingPackagesFromModules(splitPackage, module(), importReference.sourceStart, sourceEnd);
/*      */             
/*      */             continue;
/*      */           } 
/*      */         } 
/*      */       } 
/*      */       
/*  521 */       if (checkAndRecordImportBinding(importBinding, typesBySimpleNames, importReference, compoundName) != -1)
/*      */       {
/*  523 */         if (importReference.isStatic())
/*      */         {
/*      */ 
/*      */ 
/*      */           
/*  528 */           if (importBinding.kind() == 1) {
/*  529 */             checkMoreStaticBindings(compoundName, typesBySimpleNames, 12, importReference);
/*  530 */           } else if (importBinding.kind() == 8) {
/*  531 */             checkMoreStaticBindings(compoundName, typesBySimpleNames, 4, importReference);
/*      */           } 
/*      */         }
/*      */       }
/*      */       
/*      */       continue;
/*      */     } 
/*  538 */     if (this.tempImports.length > this.importPtr)
/*  539 */       System.arraycopy(this.tempImports, 0, this.tempImports = new ImportBinding[this.importPtr], 0, this.importPtr); 
/*  540 */     this.imports = this.tempImports;
/*  541 */     this.tempImports = null;
/*  542 */     int length = this.imports.length;
/*  543 */     this.typeOrPackageCache = new HashtableOfObject(length);
/*  544 */     for (int m = 0; m < length; m++) {
/*  545 */       ImportBinding binding = this.imports[m];
/*  546 */       if ((!binding.onDemand && binding.resolvedImport instanceof ReferenceBinding) || binding instanceof ImportConflictBinding)
/*  547 */         this.typeOrPackageCache.put(binding.getSimpleName(), binding); 
/*      */     } 
/*  549 */     this.skipCachingImports = (this.environment.suppressImportErrors && unresolvedFound);
/*      */   }
/*      */   public void faultInTypes() {
/*  552 */     faultInImports();
/*  553 */     if (this.referenceContext.moduleDeclaration != null) {
/*  554 */       this.referenceContext.moduleDeclaration.resolveTypeDirectives(this);
/*  555 */     } else if (this.referenceContext.currentPackage != null) {
/*  556 */       this.referenceContext.currentPackage.checkPackageConflict(this);
/*      */     } 
/*      */     
/*  559 */     for (int i = 0, length = this.topLevelTypes.length; i < length; i++)
/*  560 */       this.topLevelTypes[i].faultInTypesForFieldsAndMethods(); 
/*      */   }
/*      */   
/*      */   public Binding findImport(char[][] compoundName, boolean findStaticImports, boolean onDemand) {
/*  564 */     if (onDemand) {
/*  565 */       return findImport(compoundName, compoundName.length);
/*      */     }
/*  567 */     return findSingleImport(compoundName, 13, findStaticImports);
/*      */   }
/*      */   private Binding findImport(char[][] compoundName, int length) {
/*      */     ReferenceBinding type;
/*  571 */     recordQualifiedReference(compoundName);
/*  572 */     ModuleBinding module = module();
/*  573 */     Binding binding = this.environment.getTopLevelPackage(compoundName[0]);
/*  574 */     int i = 1;
/*  575 */     if (binding != null) {
/*  576 */       PackageBinding packageBinding = (PackageBinding)binding;
/*  577 */       while (i < length) {
/*  578 */         binding = packageBinding.getTypeOrPackage(compoundName[i++], module, (i < length));
/*  579 */         if (binding instanceof ReferenceBinding && binding.problemId() == 30) {
/*  580 */           return this.environment.convertToRawType((TypeBinding)binding, false);
/*      */         }
/*  582 */         if (binding == null)
/*      */           // Byte code: goto -> 216 
/*  584 */         if (!binding.isValidBinding()) {
/*  585 */           if (binding.problemId() == 3 && packageBinding instanceof SplitPackageBinding)
/*  586 */             return packageBinding; 
/*  587 */           binding = null;
/*      */           // Byte code: goto -> 216
/*      */         } 
/*  590 */         if (!(binding instanceof PackageBinding)) {
/*  591 */           PackageBinding visibleFor = packageBinding.getVisibleFor(module, false);
/*  592 */           if (visibleFor instanceof SplitPackageBinding) {
/*  593 */             return visibleFor;
/*      */           }
/*      */           // Byte code: goto -> 216
/*      */         } 
/*  597 */         packageBinding = (PackageBinding)binding;
/*      */       } 
/*  599 */       if (packageBinding.isValidBinding() && !module.canAccess(packageBinding))
/*  600 */         return new ProblemPackageBinding(compoundName, 30, this.environment); 
/*  601 */       return packageBinding;
/*      */     } 
/*      */ 
/*      */     
/*  605 */     if (binding == null) {
/*  606 */       if (!module.isUnnamed()) {
/*  607 */         Binding inaccessible = this.environment.getInaccessibleBinding(compoundName, module);
/*  608 */         if (inaccessible != null)
/*  609 */           return inaccessible; 
/*      */       } 
/*  611 */       if ((compilerOptions()).complianceLevel >= 3145728L)
/*  612 */         return problemType(compoundName, i, null); 
/*  613 */       type = findType(compoundName[0], this.environment.defaultPackage, this.environment.defaultPackage);
/*  614 */       if (type == null || !type.isValidBinding())
/*  615 */         return new ProblemReferenceBinding(CharOperation.subarray(compoundName, 0, i), null, 1); 
/*  616 */       i = 1;
/*      */     } else {
/*  618 */       type = (ReferenceBinding)binding;
/*      */     } 
/*      */     
/*  621 */     while (i < length) {
/*  622 */       type = (ReferenceBinding)this.environment.convertToRawType(type, false);
/*  623 */       if (!type.canBeSeenBy(this.fPackage)) {
/*  624 */         return new ProblemReferenceBinding(CharOperation.subarray(compoundName, 0, i), type, 2);
/*      */       }
/*  626 */       char[] name = compoundName[i++];
/*      */       
/*  628 */       type = type.getMemberType(name);
/*  629 */       if (type == null)
/*  630 */         return new ProblemReferenceBinding(CharOperation.subarray(compoundName, 0, i), null, 1); 
/*      */     } 
/*  632 */     if (!type.canBeSeenBy(this.fPackage))
/*  633 */       return new ProblemReferenceBinding(compoundName, type, 2); 
/*  634 */     return type;
/*      */   }
/*      */   private Binding findSingleImport(char[][] compoundName, int mask, boolean findStaticImports) {
/*  637 */     if (compoundName.length == 1) {
/*      */ 
/*      */       
/*  640 */       if ((compilerOptions()).complianceLevel >= 3145728L && !this.referenceContext.isModuleInfo())
/*  641 */         return new ProblemReferenceBinding(compoundName, null, 1); 
/*  642 */       ReferenceBinding typeBinding = findType(compoundName[0], this.environment.defaultPackage, this.fPackage);
/*  643 */       if (typeBinding == null)
/*  644 */         return new ProblemReferenceBinding(compoundName, null, 1); 
/*  645 */       return typeBinding;
/*      */     } 
/*      */     
/*  648 */     if (findStaticImports)
/*  649 */       return findSingleStaticImport(compoundName, mask); 
/*  650 */     return findImport(compoundName, compoundName.length);
/*      */   }
/*      */   private Binding findSingleStaticImport(char[][] compoundName, int mask) {
/*  653 */     Binding binding = findImport(compoundName, compoundName.length - 1);
/*  654 */     if (!binding.isValidBinding()) return binding;
/*      */     
/*  656 */     char[] name = compoundName[compoundName.length - 1];
/*  657 */     if (binding instanceof PackageBinding) {
/*  658 */       Binding temp = ((PackageBinding)binding).getTypeOrPackage(name, module(), false);
/*  659 */       if (temp != null && temp instanceof ReferenceBinding)
/*  660 */         return new ProblemReferenceBinding(compoundName, (ReferenceBinding)temp, 14); 
/*  661 */       return binding;
/*      */     } 
/*      */ 
/*      */     
/*  665 */     ReferenceBinding type = (ReferenceBinding)binding;
/*  666 */     FieldBinding field = ((mask & 0x1) != 0) ? findField(type, name, null, true) : null;
/*  667 */     if (field != null) {
/*  668 */       if (field.problemId() == 3 && ((ProblemFieldBinding)field).closestMatch.isStatic())
/*  669 */         return field; 
/*  670 */       if (field.isValidBinding() && field.isStatic() && field.canBeSeenBy(type, (InvocationSite)null, this)) {
/*  671 */         return field;
/*      */       }
/*      */     } 
/*      */     
/*  675 */     MethodBinding method = ((mask & 0x8) != 0) ? findStaticMethod(type, name) : null;
/*  676 */     if (method != null) return method;
/*      */     
/*  678 */     type = findMemberType(name, type);
/*  679 */     if (type == null || !type.isStatic()) {
/*  680 */       if (field != null && !field.isValidBinding() && field.problemId() != 1)
/*  681 */         return field; 
/*  682 */       return new ProblemReferenceBinding(compoundName, type, 1);
/*      */     } 
/*  684 */     if (type.isValidBinding() && !type.canBeSeenBy(this.fPackage))
/*  685 */       return new ProblemReferenceBinding(compoundName, type, 2); 
/*  686 */     if (type.problemId() == 2)
/*  687 */       return new ProblemReferenceBinding(compoundName, ((ProblemReferenceBinding)type).closestMatch, 2); 
/*  688 */     return type;
/*      */   }
/*      */   
/*      */   private MethodBinding findStaticMethod(ReferenceBinding currentType, char[] selector) {
/*  692 */     if (!currentType.canBeSeenBy(this)) {
/*  693 */       return null;
/*      */     }
/*      */     while (true) {
/*  696 */       currentType.initializeForStaticImports();
/*  697 */       MethodBinding[] methods = currentType.getMethods(selector);
/*  698 */       if (methods != Binding.NO_METHODS)
/*  699 */         for (int i = methods.length; --i >= 0; ) {
/*  700 */           MethodBinding method = methods[i];
/*  701 */           if (method.isStatic() && method.canBeSeenBy(this.fPackage)) {
/*  702 */             return method;
/*      */           }
/*      */         }  
/*  705 */       if ((currentType = currentType.superclass()) == null)
/*  706 */         return null; 
/*      */     } 
/*      */   }
/*      */   ImportBinding[] getDefaultImports() {
/*  710 */     if (this.environment.root.defaultImports != null) return this.environment.root.defaultImports;
/*      */     
/*  712 */     Binding importBinding = this.environment.getTopLevelPackage(TypeConstants.JAVA);
/*  713 */     if (importBinding != null) {
/*  714 */       importBinding = ((PackageBinding)importBinding).getTypeOrPackage(TypeConstants.JAVA_LANG[1], module(), false);
/*      */     }
/*  716 */     if (importBinding == null || !importBinding.isValidBinding()) {
/*      */       
/*  718 */       problemReporter().isClassPathCorrect(
/*  719 */           TypeConstants.JAVA_LANG_OBJECT, 
/*  720 */           this.referenceContext, 
/*  721 */           this.environment.missingClassFileLocation, false, null);
/*  722 */       BinaryTypeBinding missingObject = this.environment.createMissingType(null, TypeConstants.JAVA_LANG_OBJECT);
/*  723 */       importBinding = missingObject.fPackage;
/*      */     } 
/*      */     
/*  726 */     this.environment.root.defaultImports = new ImportBinding[] { new ImportBinding(TypeConstants.JAVA_LANG, true, importBinding, null) }; return new ImportBinding[1];
/*      */   }
/*      */   
/*      */   public final Binding getImport(char[][] compoundName, boolean onDemand, boolean isStaticImport) {
/*  730 */     if (onDemand)
/*  731 */       return findImport(compoundName, compoundName.length); 
/*  732 */     return findSingleImport(compoundName, 13, isStaticImport);
/*      */   }
/*      */   
/*      */   public int nextCaptureID() {
/*  736 */     return this.captureID++;
/*      */   }
/*      */ 
/*      */   
/*      */   public ModuleBinding module() {
/*  741 */     if (!this.referenceContext.isModuleInfo() && 
/*  742 */       this.referenceContext.types == null && 
/*  743 */       this.referenceContext.currentPackage == null && 
/*  744 */       this.referenceContext.imports == null) {
/*  745 */       this.environment = this.environment.UnNamedModule.environment;
/*  746 */       return this.environment.UnNamedModule;
/*      */     } 
/*  748 */     return super.module();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ProblemReporter problemReporter() {
/*  759 */     ProblemReporter problemReporter = this.referenceContext.problemReporter;
/*  760 */     problemReporter.referenceContext = (ReferenceContext)this.referenceContext;
/*  761 */     return problemReporter;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void recordQualifiedReference(char[][] qualifiedName) {
/*  801 */     if (this.qualifiedReferences == null)
/*      */       return; 
/*  803 */     int length = qualifiedName.length;
/*  804 */     if (length > 1) {
/*  805 */       recordRootReference(qualifiedName[0]);
/*  806 */       while (this.qualifiedReferences.add(qualifiedName)) {
/*  807 */         if (length == 2) {
/*  808 */           recordSimpleReference(qualifiedName[0]);
/*  809 */           recordSimpleReference(qualifiedName[1]);
/*      */           return;
/*      */         } 
/*  812 */         length--;
/*  813 */         recordSimpleReference(qualifiedName[length]);
/*  814 */         System.arraycopy(qualifiedName, 0, qualifiedName = new char[length][], 0, length);
/*      */       } 
/*  816 */     } else if (length == 1) {
/*  817 */       recordRootReference(qualifiedName[0]);
/*  818 */       recordSimpleReference(qualifiedName[0]);
/*      */     } 
/*      */   }
/*      */   void recordReference(char[][] qualifiedEnclosingName, char[] simpleName) {
/*  822 */     recordQualifiedReference(qualifiedEnclosingName);
/*  823 */     if (qualifiedEnclosingName.length == 0)
/*  824 */       recordRootReference(simpleName); 
/*  825 */     recordSimpleReference(simpleName);
/*      */   }
/*      */   void recordReference(ReferenceBinding type, char[] simpleName) {
/*  828 */     ReferenceBinding actualType = typeToRecord(type);
/*  829 */     if (actualType != null)
/*  830 */       recordReference(actualType.compoundName, simpleName); 
/*      */   }
/*      */   void recordRootReference(char[] simpleName) {
/*  833 */     if (this.rootReferences == null)
/*      */       return; 
/*  835 */     this.rootReferences.add(simpleName);
/*      */   }
/*      */   void recordSimpleReference(char[] simpleName) {
/*  838 */     if (this.simpleNameReferences == null)
/*      */       return; 
/*  840 */     this.simpleNameReferences.add(simpleName);
/*      */   }
/*      */   void recordSuperTypeReference(TypeBinding type) {
/*  843 */     if (this.referencedSuperTypes == null)
/*      */       return; 
/*  845 */     ReferenceBinding actualType = typeToRecord(type);
/*  846 */     if (actualType != null && this.referencedSuperTypesSet.add(new ReferenceBindingSetWrapper(actualType)))
/*  847 */       this.referencedSuperTypes.add(actualType); 
/*      */   }
/*      */   public void recordTypeConversion(TypeBinding superType, TypeBinding subType) {
/*  850 */     recordSuperTypeReference(subType);
/*      */   }
/*      */   void recordTypeReference(TypeBinding type) {
/*  853 */     if (this.referencedTypes == null)
/*      */       return; 
/*  855 */     ReferenceBinding actualType = typeToRecord(type);
/*  856 */     if (actualType != null)
/*  857 */       this.referencedTypes.add(new ReferenceBindingSetWrapper(actualType)); 
/*      */   }
/*      */   void recordTypeReferences(TypeBinding[] types) {
/*  860 */     if (this.referencedTypes == null)
/*  861 */       return;  if (types == null || types.length == 0)
/*      */       return; 
/*  863 */     for (int i = 0, max = types.length; i < max; i++) {
/*      */ 
/*      */       
/*  866 */       ReferenceBinding actualType = typeToRecord(types[i]);
/*  867 */       if (actualType != null)
/*  868 */         this.referencedTypes.add(new ReferenceBindingSetWrapper(actualType)); 
/*      */     } 
/*      */   }
/*      */   Binding resolveSingleImport(ImportBinding importBinding, int mask) {
/*  872 */     if (importBinding.resolvedImport == null) {
/*  873 */       importBinding.resolvedImport = findSingleImport(importBinding.compoundName, mask, importBinding.isStatic());
/*  874 */       if (!importBinding.resolvedImport.isValidBinding() || importBinding.resolvedImport instanceof PackageBinding) {
/*  875 */         if (importBinding.resolvedImport.problemId() == 3)
/*  876 */           return importBinding.resolvedImport; 
/*  877 */         if (this.imports != null) {
/*  878 */           ImportBinding[] newImports = new ImportBinding[this.imports.length - 1];
/*  879 */           for (int i = 0, n = 0, max = this.imports.length; i < max; i++) {
/*  880 */             if (this.imports[i] != importBinding)
/*  881 */               newImports[n++] = this.imports[i]; 
/*  882 */           }  this.imports = newImports;
/*      */         } 
/*  884 */         return null;
/*      */       } 
/*      */     } 
/*  887 */     return importBinding.resolvedImport;
/*      */   }
/*      */ 
/*      */   
/*      */   public void storeDependencyInfo() {
/*  892 */     for (int i = 0; i < this.referencedSuperTypes.size; i++) {
/*  893 */       ReferenceBinding type = (ReferenceBinding)this.referencedSuperTypes.elementAt(i);
/*  894 */       this.referencedTypes.add(new ReferenceBindingSetWrapper(type));
/*      */       
/*  896 */       if (!type.isLocalType()) {
/*  897 */         ReferenceBinding enclosing = type.enclosingType();
/*  898 */         if (enclosing != null)
/*  899 */           recordSuperTypeReference(enclosing); 
/*      */       } 
/*  901 */       ReferenceBinding superclass = type.superclass();
/*  902 */       if (superclass != null)
/*  903 */         recordSuperTypeReference(superclass); 
/*  904 */       ReferenceBinding[] interfaces = type.superInterfaces();
/*  905 */       if (interfaces != null)
/*  906 */         for (int n = 0, length = interfaces.length; n < length; n++) {
/*  907 */           recordSuperTypeReference(interfaces[n]);
/*      */         } 
/*      */     } 
/*  910 */     for (ReferenceBindingSetWrapper wrapper : this.referencedTypes) {
/*  911 */       ReferenceBinding type = wrapper.referenceBinding;
/*  912 */       if (!type.isLocalType()) {
/*  913 */         recordQualifiedReference(type.isMemberType() ? 
/*  914 */             CharOperation.splitOn('.', type.readableName()) : 
/*  915 */             type.compoundName);
/*      */       }
/*      */     } 
/*  918 */     int size = this.qualifiedReferences.size;
/*  919 */     char[][][] qualifiedRefs = new char[size][][];
/*  920 */     for (int j = 0; j < size; j++)
/*  921 */       qualifiedRefs[j] = this.qualifiedReferences.elementAt(j); 
/*  922 */     this.referenceContext.compilationResult.qualifiedReferences = qualifiedRefs;
/*      */     
/*  924 */     size = this.simpleNameReferences.size;
/*  925 */     char[][] simpleRefs = new char[size][];
/*  926 */     for (int k = 0; k < size; k++)
/*  927 */       simpleRefs[k] = this.simpleNameReferences.elementAt(k); 
/*  928 */     this.referenceContext.compilationResult.simpleNameReferences = simpleRefs;
/*      */     
/*  930 */     size = this.rootReferences.size;
/*  931 */     char[][] rootRefs = new char[size][];
/*  932 */     for (int m = 0; m < size; m++)
/*  933 */       rootRefs[m] = this.rootReferences.elementAt(m); 
/*  934 */     this.referenceContext.compilationResult.rootReferences = rootRefs;
/*      */   }
/*      */   
/*      */   public String toString() {
/*  938 */     return "--- CompilationUnit Scope : " + new String(this.referenceContext.getFileName());
/*      */   }
/*      */   private ReferenceBinding typeToRecord(TypeBinding type) {
/*  941 */     if (type == null)
/*  942 */       return null; 
/*  943 */     while (type.isArrayType()) {
/*  944 */       type = ((ArrayBinding)type).leafComponentType();
/*      */     }
/*  946 */     switch (type.kind()) {
/*      */       case 132:
/*      */       case 516:
/*      */       case 4100:
/*      */       case 8196:
/*      */       case 32772:
/*      */       case 65540:
/*  953 */         return null;
/*      */       case 260:
/*      */       case 1028:
/*  956 */         type = type.erasure(); break;
/*      */     } 
/*  958 */     ReferenceBinding refType = (ReferenceBinding)type;
/*  959 */     if (refType.isLocalType()) return null; 
/*  960 */     return refType;
/*      */   }
/*      */   public void verifyMethods(MethodVerifier verifier) {
/*  963 */     for (int i = 0, length = this.topLevelTypes.length; i < length; i++)
/*  964 */       this.topLevelTypes[i].verifyMethods(verifier); 
/*      */   }
/*      */   private void recordImportBinding(ImportBinding bindingToAdd) {
/*  967 */     if (this.tempImports.length == this.importPtr) {
/*  968 */       System.arraycopy(this.tempImports, 0, this.tempImports = new ImportBinding[this.importPtr + 1], 0, this.importPtr);
/*      */     }
/*  970 */     this.tempImports[this.importPtr++] = bindingToAdd;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void checkMoreStaticBindings(char[][] compoundName, HashtableOfType typesBySimpleNames, int mask, ImportReference importReference) {
/*  986 */     Binding importBinding = findSingleStaticImport(compoundName, mask);
/*  987 */     if (!importBinding.isValidBinding()) {
/*      */ 
/*      */       
/*  990 */       if (importBinding.problemId() == 3)
/*      */       {
/*  992 */         checkAndRecordImportBinding(importBinding, typesBySimpleNames, importReference, compoundName);
/*      */       }
/*      */     } else {
/*  995 */       checkAndRecordImportBinding(importBinding, typesBySimpleNames, importReference, compoundName);
/*      */     } 
/*  997 */     if ((mask & 0x8) != 0 && importBinding.kind() == 8) {
/*      */ 
/*      */ 
/*      */       
/* 1001 */       mask &= 0xFFFFFFF7;
/*      */       
/* 1003 */       checkMoreStaticBindings(compoundName, typesBySimpleNames, mask, importReference);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private int checkAndRecordImportBinding(Binding importBinding, HashtableOfType typesBySimpleNames, ImportReference importReference, char[][] compoundName) {
/* 1020 */     ReferenceBinding conflictingType = null;
/* 1021 */     if (importBinding instanceof MethodBinding) {
/* 1022 */       conflictingType = (ReferenceBinding)getType(compoundName, compoundName.length);
/* 1023 */       if (!conflictingType.isValidBinding() || (importReference.isStatic() && !conflictingType.isStatic())) {
/* 1024 */         conflictingType = null;
/*      */       }
/*      */     } 
/* 1027 */     char[] name = importReference.getSimpleName();
/* 1028 */     if (importBinding instanceof ReferenceBinding || conflictingType != null) {
/* 1029 */       ReferenceBinding referenceBinding = (conflictingType == null) ? (ReferenceBinding)importBinding : conflictingType;
/* 1030 */       ReferenceBinding typeToCheck = (referenceBinding.problemId() == 3) ? 
/* 1031 */         ((ProblemReferenceBinding)referenceBinding).closestMatch : 
/* 1032 */         referenceBinding;
/* 1033 */       if (importReference.isTypeUseDeprecated(typeToCheck, this)) {
/* 1034 */         problemReporter().deprecatedType(typeToCheck, (ASTNode)importReference);
/*      */       }
/* 1036 */       ReferenceBinding existingType = typesBySimpleNames.get(name);
/* 1037 */       if (existingType != null) {
/*      */         
/* 1039 */         if (TypeBinding.equalsEquals(existingType, referenceBinding)) {
/*      */ 
/*      */           
/* 1042 */           for (int i = 0; i < this.importPtr; i++) {
/* 1043 */             ImportBinding resolved = this.tempImports[i];
/* 1044 */             if (resolved instanceof ImportConflictBinding) {
/* 1045 */               ImportConflictBinding importConflictBinding = (ImportConflictBinding)resolved;
/* 1046 */               if (TypeBinding.equalsEquals(importConflictBinding.conflictingTypeBinding, referenceBinding) && 
/* 1047 */                 !importReference.isStatic())
/*      */               {
/* 1049 */                 problemReporter().duplicateImport(importReference);
/* 1050 */                 recordImportBinding(new ImportBinding(compoundName, false, importBinding, importReference));
/*      */               }
/*      */             
/* 1053 */             } else if (resolved.resolvedImport == referenceBinding && 
/* 1054 */               importReference.isStatic() != resolved.isStatic()) {
/* 1055 */               recordImportBinding(new ImportBinding(compoundName, false, importBinding, importReference));
/*      */             } 
/*      */           } 
/*      */           
/* 1059 */           return -1;
/*      */         }  int j;
/*      */         int length;
/* 1062 */         for (j = 0, length = this.topLevelTypes.length; j < length; j++) {
/* 1063 */           if (CharOperation.equals((this.topLevelTypes[j]).sourceName, existingType.sourceName)) {
/* 1064 */             problemReporter().conflictingImport(importReference);
/* 1065 */             return -1;
/*      */           } 
/*      */         } 
/* 1068 */         if (importReference.isStatic() && importBinding instanceof ReferenceBinding && (compilerOptions()).sourceLevel >= 3407872L)
/*      */         {
/* 1070 */           for (j = 0; j < this.importPtr; j++) {
/* 1071 */             ImportBinding resolved = this.tempImports[j];
/* 1072 */             if (resolved.isStatic() && resolved.resolvedImport instanceof ReferenceBinding && importBinding != resolved.resolvedImport && 
/* 1073 */               CharOperation.equals(compoundName[compoundName.length - 1], resolved.compoundName[resolved.compoundName.length - 1])) {
/* 1074 */               ReferenceBinding type = (ReferenceBinding)resolved.resolvedImport;
/* 1075 */               resolved.resolvedImport = new ProblemReferenceBinding(new char[][] { name }, type, 3);
/* 1076 */               return -1;
/*      */             } 
/*      */           } 
/*      */         }
/*      */         
/* 1081 */         problemReporter().duplicateImport(importReference);
/* 1082 */         return -1;
/*      */       } 
/* 1084 */       typesBySimpleNames.put(name, referenceBinding);
/* 1085 */     } else if (importBinding instanceof FieldBinding) {
/* 1086 */       for (int j = 0; j < this.importPtr; j++) {
/* 1087 */         ImportBinding resolved = this.tempImports[j];
/*      */         
/* 1089 */         if (resolved.isStatic() && resolved.resolvedImport instanceof FieldBinding && importBinding != resolved.resolvedImport && 
/* 1090 */           CharOperation.equals(name, resolved.compoundName[resolved.compoundName.length - 1])) {
/* 1091 */           if ((compilerOptions()).sourceLevel >= 3407872L) {
/*      */             
/* 1093 */             FieldBinding field = (FieldBinding)resolved.resolvedImport;
/* 1094 */             resolved.resolvedImport = new ProblemFieldBinding(field, field.declaringClass, name, 3);
/* 1095 */             return -1;
/*      */           } 
/* 1097 */           problemReporter().duplicateImport(importReference);
/* 1098 */           return -1;
/*      */         } 
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/* 1104 */     if (conflictingType == null) {
/* 1105 */       recordImportBinding(new ImportBinding(compoundName, false, importBinding, importReference));
/*      */     } else {
/* 1107 */       recordImportBinding(new ImportConflictBinding(compoundName, importBinding, conflictingType, importReference));
/*      */     } 
/* 1109 */     return this.importPtr;
/*      */   }
/*      */   
/*      */   public boolean hasDefaultNullnessFor(int location, int sourceStart) {
/* 1113 */     int nonNullByDefaultValue = localNonNullByDefaultValue(sourceStart);
/* 1114 */     if (nonNullByDefaultValue != 0) {
/* 1115 */       return ((nonNullByDefaultValue & location) != 0);
/*      */     }
/* 1117 */     if (this.fPackage != null)
/* 1118 */       return ((this.fPackage.getDefaultNullness() & location) != 0); 
/* 1119 */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   public Binding checkRedundantDefaultNullness(int nullBits, int sourceStart) {
/* 1124 */     Binding target = localCheckRedundantDefaultNullness(nullBits, sourceStart);
/* 1125 */     if (target != null) {
/* 1126 */       return target;
/*      */     }
/* 1128 */     if (this.fPackage != null) {
/* 1129 */       return this.fPackage.findDefaultNullnessTarget(n -> (n.intValue() == paramInt));
/*      */     }
/*      */     
/* 1132 */     return null;
/*      */   }
/*      */   
/*      */   public void registerInferredInvocation(Invocation invocation) {
/* 1136 */     if (this.inferredInvocations == null)
/* 1137 */       this.inferredInvocations = new ArrayList<>(); 
/* 1138 */     this.inferredInvocations.add(invocation);
/*      */   }
/*      */   public void cleanUpInferenceContexts() {
/* 1141 */     if (this.inferredInvocations == null)
/*      */       return; 
/* 1143 */     for (Invocation invocation : this.inferredInvocations)
/* 1144 */       invocation.cleanUpInferenceContexts(); 
/* 1145 */     this.inferredInvocations = null;
/*      */   }
/*      */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\lookup\CompilationUnitScope.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */