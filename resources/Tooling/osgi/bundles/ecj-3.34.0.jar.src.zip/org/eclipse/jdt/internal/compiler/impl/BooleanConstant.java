/*    */ package org.eclipse.jdt.internal.compiler.impl;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class BooleanConstant
/*    */   extends Constant
/*    */ {
/*    */   private boolean value;
/* 20 */   private static final BooleanConstant TRUE = new BooleanConstant(true);
/* 21 */   private static final BooleanConstant FALSE = new BooleanConstant(false);
/*    */   
/*    */   public static Constant fromValue(boolean value) {
/* 24 */     return value ? TRUE : FALSE;
/*    */   }
/*    */   
/*    */   private BooleanConstant(boolean value) {
/* 28 */     this.value = value;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean booleanValue() {
/* 33 */     return this.value;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public String stringValue() {
/* 39 */     return String.valueOf(this.value);
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 44 */     return "(boolean)" + this.value;
/*    */   }
/*    */ 
/*    */   
/*    */   public int typeID() {
/* 49 */     return 5;
/*    */   }
/*    */ 
/*    */   
/*    */   public int hashCode() {
/* 54 */     return this.value ? 1231 : 1237;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean equals(Object obj) {
/* 59 */     if (this == obj) {
/* 60 */       return true;
/*    */     }
/* 62 */     if (obj == null) {
/* 63 */       return false;
/*    */     }
/* 65 */     if (getClass() != obj.getClass()) {
/* 66 */       return false;
/*    */     }
/*    */     
/* 69 */     return false;
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\impl\BooleanConstant.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */