/*    */ package org.eclipse.jdt.internal.compiler.ast;
/*    */ 
/*    */ import org.eclipse.jdt.internal.compiler.ASTVisitor;
/*    */ import org.eclipse.jdt.internal.compiler.codegen.CodeStream;
/*    */ import org.eclipse.jdt.internal.compiler.lookup.BlockScope;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PostfixExpression
/*    */   extends CompoundAssignment
/*    */ {
/*    */   public PostfixExpression(Expression lhs, Expression expression, int operator, int pos) {
/* 23 */     super(lhs, expression, operator, pos);
/* 24 */     this.sourceStart = lhs.sourceStart;
/* 25 */     this.sourceEnd = pos;
/*    */   }
/*    */   
/*    */   public boolean checkCastCompatibility() {
/* 29 */     return false;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void generateCode(BlockScope currentScope, CodeStream codeStream, boolean valueRequired) {
/* 44 */     int pc = codeStream.position;
/* 45 */     ((Reference)this.lhs).generatePostIncrement(currentScope, codeStream, this, valueRequired);
/* 46 */     if (valueRequired) {
/* 47 */       codeStream.generateImplicitConversion(this.implicitConversion);
/*    */     }
/* 49 */     codeStream.recordPositionsFrom(pc, this.sourceStart);
/*    */   }
/*    */ 
/*    */   
/*    */   public String operatorToString() {
/* 54 */     switch (this.operator) {
/*    */       case 14:
/* 56 */         return "++";
/*    */       case 13:
/* 58 */         return "--";
/*    */     } 
/* 60 */     return "unknown operator";
/*    */   }
/*    */ 
/*    */   
/*    */   public StringBuffer printExpressionNoParenthesis(int indent, StringBuffer output) {
/* 65 */     return this.lhs.printExpression(indent, output).append(' ').append(operatorToString());
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean restrainUsageToNumericTypes() {
/* 70 */     return true;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void traverse(ASTVisitor visitor, BlockScope scope) {
/* 76 */     if (visitor.visit(this, scope)) {
/* 77 */       this.lhs.traverse(visitor, scope);
/*    */     }
/* 79 */     visitor.endVisit(this, scope);
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\ast\PostfixExpression.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */