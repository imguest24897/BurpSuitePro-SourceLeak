/*    */ package org.eclipse.jdt.internal.compiler.ast;
/*    */ 
/*    */ import org.eclipse.jdt.internal.compiler.impl.Constant;
/*    */ import org.eclipse.jdt.internal.compiler.lookup.BlockScope;
/*    */ import org.eclipse.jdt.internal.compiler.lookup.TypeBinding;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FakeDefaultLiteral
/*    */   extends MagicLiteral
/*    */ {
/* 27 */   static final char[] source = new char[] { 'd', 'e', 'f', 'a', 'u', 'l', 't' };
/*    */ 
/*    */   
/*    */   public FakeDefaultLiteral(int s, int e) {
/* 31 */     super(s, e);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void computeConstant() {
/* 37 */     this.constant = Constant.NotAConstant;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public TypeBinding literalType(BlockScope scope) {
/* 43 */     return (TypeBinding)TypeBinding.VOID;
/*    */   }
/*    */ 
/*    */   
/*    */   public char[] source() {
/* 48 */     return source;
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\ast\FakeDefaultLiteral.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */