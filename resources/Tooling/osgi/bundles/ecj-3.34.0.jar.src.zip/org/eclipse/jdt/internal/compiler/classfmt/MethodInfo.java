/*     */ package org.eclipse.jdt.internal.compiler.classfmt;
/*     */ 
/*     */ import org.eclipse.jdt.core.compiler.CharOperation;
/*     */ import org.eclipse.jdt.internal.compiler.codegen.AttributeNamesConstants;
/*     */ import org.eclipse.jdt.internal.compiler.codegen.ConstantPool;
/*     */ import org.eclipse.jdt.internal.compiler.env.IBinaryAnnotation;
/*     */ import org.eclipse.jdt.internal.compiler.env.IBinaryMethod;
/*     */ import org.eclipse.jdt.internal.compiler.env.IBinaryTypeAnnotation;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MethodInfo
/*     */   extends ClassFileStruct
/*     */   implements IBinaryMethod, Comparable
/*     */ {
/*  30 */   private static final char[][] noException = CharOperation.NO_CHAR_CHAR;
/*  31 */   private static final char[][] noArgumentNames = CharOperation.NO_CHAR_CHAR;
/*  32 */   private static final char[] ARG = "arg".toCharArray();
/*     */   protected int accessFlags;
/*     */   protected int attributeBytes;
/*     */   protected char[] descriptor;
/*     */   protected volatile char[][] exceptionNames;
/*     */   protected char[] name;
/*     */   protected char[] signature;
/*     */   protected int signatureUtf8Offset;
/*     */   protected long tagBits;
/*     */   protected volatile char[][] argumentNames;
/*     */   protected long version;
/*     */   
/*     */   public static MethodInfo createMethod(byte[] classFileBytes, int[] offsets, int offset, long version) {
/*  45 */     MethodInfo methodInfo = new MethodInfo(classFileBytes, offsets, offset, version);
/*  46 */     int attributesCount = methodInfo.u2At(6);
/*  47 */     int readOffset = 8;
/*  48 */     AnnotationInfo[] annotations = null;
/*  49 */     AnnotationInfo[][] parameterAnnotations = null;
/*  50 */     TypeAnnotationInfo[] typeAnnotations = null;
/*  51 */     for (int i = 0; i < attributesCount; i++) {
/*     */       
/*  53 */       int utf8Offset = methodInfo.constantPoolOffsets[methodInfo.u2At(readOffset)] - methodInfo.structOffset;
/*  54 */       char[] attributeName = methodInfo.utf8At(utf8Offset + 3, methodInfo.u2At(utf8Offset + 1));
/*  55 */       if (attributeName.length > 0) {
/*  56 */         AnnotationInfo[] methodAnnotations; AnnotationInfo[][] paramAnnotations; TypeAnnotationInfo[] methodTypeAnnotations; switch (attributeName[0]) {
/*     */           case 'M':
/*  58 */             if (CharOperation.equals(attributeName, AttributeNamesConstants.MethodParametersName)) {
/*  59 */               methodInfo.decodeMethodParameters(readOffset, methodInfo);
/*     */             }
/*     */             break;
/*     */           case 'S':
/*  63 */             if (CharOperation.equals(AttributeNamesConstants.SignatureName, attributeName))
/*  64 */               methodInfo.signatureUtf8Offset = methodInfo.constantPoolOffsets[methodInfo.u2At(readOffset + 6)] - methodInfo.structOffset; 
/*     */             break;
/*     */           case 'R':
/*  67 */             methodAnnotations = null;
/*  68 */             paramAnnotations = null;
/*  69 */             methodTypeAnnotations = null;
/*  70 */             if (CharOperation.equals(attributeName, AttributeNamesConstants.RuntimeVisibleAnnotationsName)) {
/*  71 */               methodAnnotations = decodeMethodAnnotations(readOffset, true, methodInfo);
/*  72 */             } else if (CharOperation.equals(attributeName, AttributeNamesConstants.RuntimeInvisibleAnnotationsName)) {
/*  73 */               methodAnnotations = decodeMethodAnnotations(readOffset, false, methodInfo);
/*  74 */             } else if (CharOperation.equals(attributeName, AttributeNamesConstants.RuntimeVisibleParameterAnnotationsName)) {
/*  75 */               paramAnnotations = decodeParamAnnotations(readOffset, true, methodInfo);
/*  76 */             } else if (CharOperation.equals(attributeName, AttributeNamesConstants.RuntimeInvisibleParameterAnnotationsName)) {
/*  77 */               paramAnnotations = decodeParamAnnotations(readOffset, false, methodInfo);
/*  78 */             } else if (CharOperation.equals(attributeName, AttributeNamesConstants.RuntimeVisibleTypeAnnotationsName)) {
/*  79 */               methodTypeAnnotations = decodeTypeAnnotations(readOffset, true, methodInfo);
/*  80 */             } else if (CharOperation.equals(attributeName, AttributeNamesConstants.RuntimeInvisibleTypeAnnotationsName)) {
/*  81 */               methodTypeAnnotations = decodeTypeAnnotations(readOffset, false, methodInfo);
/*     */             } 
/*  83 */             if (methodAnnotations != null) {
/*  84 */               if (annotations == null) {
/*  85 */                 annotations = methodAnnotations; break;
/*     */               } 
/*  87 */               int length = annotations.length;
/*  88 */               AnnotationInfo[] newAnnotations = new AnnotationInfo[length + methodAnnotations.length];
/*  89 */               System.arraycopy(annotations, 0, newAnnotations, 0, length);
/*  90 */               System.arraycopy(methodAnnotations, 0, newAnnotations, length, methodAnnotations.length);
/*  91 */               annotations = newAnnotations; break;
/*     */             } 
/*  93 */             if (paramAnnotations != null) {
/*  94 */               int numberOfParameters = paramAnnotations.length;
/*  95 */               if (parameterAnnotations == null) {
/*  96 */                 parameterAnnotations = paramAnnotations; break;
/*     */               } 
/*  98 */               for (int p = 0; p < numberOfParameters; p++) {
/*  99 */                 int numberOfAnnotations = (paramAnnotations[p] == null) ? 0 : (paramAnnotations[p]).length;
/* 100 */                 if (numberOfAnnotations > 0)
/* 101 */                   if (parameterAnnotations[p] == null) {
/* 102 */                     parameterAnnotations[p] = paramAnnotations[p];
/*     */                   } else {
/* 104 */                     int length = (parameterAnnotations[p]).length;
/* 105 */                     AnnotationInfo[] newAnnotations = new AnnotationInfo[length + numberOfAnnotations];
/* 106 */                     System.arraycopy(parameterAnnotations[p], 0, newAnnotations, 0, length);
/* 107 */                     System.arraycopy(paramAnnotations[p], 0, newAnnotations, length, numberOfAnnotations);
/* 108 */                     parameterAnnotations[p] = newAnnotations;
/*     */                   }  
/*     */               } 
/*     */               break;
/*     */             } 
/* 113 */             if (methodTypeAnnotations != null) {
/* 114 */               if (typeAnnotations == null) {
/* 115 */                 typeAnnotations = methodTypeAnnotations; break;
/*     */               } 
/* 117 */               int length = typeAnnotations.length;
/* 118 */               TypeAnnotationInfo[] newAnnotations = new TypeAnnotationInfo[length + methodTypeAnnotations.length];
/* 119 */               System.arraycopy(typeAnnotations, 0, newAnnotations, 0, length);
/* 120 */               System.arraycopy(methodTypeAnnotations, 0, newAnnotations, length, methodTypeAnnotations.length);
/* 121 */               typeAnnotations = newAnnotations;
/*     */             } 
/*     */             break;
/*     */         } 
/*     */       
/*     */       } 
/* 127 */       readOffset = (int)(readOffset + 6L + methodInfo.u4At(readOffset + 2));
/*     */     } 
/* 129 */     methodInfo.attributeBytes = readOffset;
/*     */     
/* 131 */     if (typeAnnotations != null)
/* 132 */       return new MethodInfoWithTypeAnnotations(methodInfo, annotations, parameterAnnotations, typeAnnotations); 
/* 133 */     if (parameterAnnotations != null)
/* 134 */       return new MethodInfoWithParameterAnnotations(methodInfo, annotations, parameterAnnotations); 
/* 135 */     if (annotations != null)
/* 136 */       return new MethodInfoWithAnnotations(methodInfo, annotations); 
/* 137 */     return methodInfo;
/*     */   }
/*     */   static AnnotationInfo[] decodeAnnotations(int offset, boolean runtimeVisible, int numberOfAnnotations, MethodInfo methodInfo) {
/* 140 */     AnnotationInfo[] result = new AnnotationInfo[numberOfAnnotations];
/* 141 */     int readOffset = offset;
/* 142 */     for (int i = 0; i < numberOfAnnotations; i++) {
/* 143 */       result[i] = new AnnotationInfo(methodInfo.reference, methodInfo.constantPoolOffsets, 
/* 144 */           readOffset + methodInfo.structOffset, runtimeVisible, false);
/* 145 */       readOffset += (result[i]).readOffset;
/*     */     } 
/* 147 */     return result;
/*     */   }
/*     */   static AnnotationInfo[] decodeMethodAnnotations(int offset, boolean runtimeVisible, MethodInfo methodInfo) {
/* 150 */     int numberOfAnnotations = methodInfo.u2At(offset + 6);
/* 151 */     if (numberOfAnnotations > 0) {
/* 152 */       AnnotationInfo[] annos = decodeAnnotations(offset + 8, runtimeVisible, numberOfAnnotations, methodInfo);
/* 153 */       if (runtimeVisible) {
/* 154 */         int numRetainedAnnotations = 0;
/* 155 */         for (int i = 0; i < numberOfAnnotations; i++) {
/* 156 */           long standardAnnoTagBits = (annos[i]).standardAnnotationTagBits;
/* 157 */           methodInfo.tagBits |= standardAnnoTagBits;
/* 158 */           if (standardAnnoTagBits != 0L && (
/* 159 */             methodInfo.version < 3473408L || (standardAnnoTagBits & 0x400000000000L) == 0L)) {
/* 160 */             annos[i] = null;
/*     */           }
/*     */           else {
/*     */             
/* 164 */             numRetainedAnnotations++;
/*     */           } 
/*     */         } 
/* 167 */         if (numRetainedAnnotations != numberOfAnnotations) {
/* 168 */           if (numRetainedAnnotations == 0) {
/* 169 */             return null;
/*     */           }
/*     */           
/* 172 */           AnnotationInfo[] temp = new AnnotationInfo[numRetainedAnnotations];
/* 173 */           int tmpIndex = 0;
/* 174 */           for (int j = 0; j < numberOfAnnotations; j++) {
/* 175 */             if (annos[j] != null)
/* 176 */               temp[tmpIndex++] = annos[j]; 
/* 177 */           }  annos = temp;
/*     */         } 
/*     */       } 
/* 180 */       return annos;
/*     */     } 
/* 182 */     return null;
/*     */   }
/*     */   static TypeAnnotationInfo[] decodeTypeAnnotations(int offset, boolean runtimeVisible, MethodInfo methodInfo) {
/* 185 */     int numberOfAnnotations = methodInfo.u2At(offset + 6);
/* 186 */     if (numberOfAnnotations > 0) {
/* 187 */       int readOffset = offset + 8;
/* 188 */       TypeAnnotationInfo[] typeAnnos = new TypeAnnotationInfo[numberOfAnnotations];
/* 189 */       for (int i = 0; i < numberOfAnnotations; i++) {
/* 190 */         TypeAnnotationInfo newInfo = new TypeAnnotationInfo(methodInfo.reference, methodInfo.constantPoolOffsets, readOffset + methodInfo.structOffset, runtimeVisible, false);
/* 191 */         readOffset += newInfo.readOffset;
/* 192 */         typeAnnos[i] = newInfo;
/*     */       } 
/* 194 */       return typeAnnos;
/*     */     } 
/* 196 */     return null;
/*     */   }
/*     */   static AnnotationInfo[][] decodeParamAnnotations(int offset, boolean runtimeVisible, MethodInfo methodInfo) {
/* 199 */     AnnotationInfo[][] allParamAnnotations = null;
/* 200 */     int numberOfParameters = methodInfo.u1At(offset + 6);
/* 201 */     if (numberOfParameters > 0) {
/*     */       
/* 203 */       int readOffset = offset + 7;
/* 204 */       for (int i = 0; i < numberOfParameters; i++) {
/* 205 */         int numberOfAnnotations = methodInfo.u2At(readOffset);
/* 206 */         readOffset += 2;
/* 207 */         if (numberOfAnnotations > 0) {
/* 208 */           if (allParamAnnotations == null)
/* 209 */             allParamAnnotations = new AnnotationInfo[numberOfParameters][]; 
/* 210 */           AnnotationInfo[] annos = decodeAnnotations(readOffset, runtimeVisible, numberOfAnnotations, methodInfo);
/* 211 */           allParamAnnotations[i] = annos;
/* 212 */           for (int aIndex = 0; aIndex < annos.length; aIndex++)
/* 213 */             readOffset += (annos[aIndex]).readOffset; 
/*     */         } 
/*     */       } 
/*     */     } 
/* 217 */     return allParamAnnotations;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected MethodInfo(byte[] classFileBytes, int[] offsets, int offset, long version) {
/* 227 */     super(classFileBytes, offsets, offset);
/* 228 */     this.accessFlags = -1;
/* 229 */     this.signatureUtf8Offset = -1;
/* 230 */     this.version = version;
/*     */   }
/*     */   
/*     */   public int compareTo(Object o) {
/* 234 */     MethodInfo otherMethod = (MethodInfo)o;
/* 235 */     int result = (new String(getSelector())).compareTo(new String(otherMethod.getSelector()));
/* 236 */     if (result != 0) return result; 
/* 237 */     return (new String(getMethodDescriptor())).compareTo(new String(otherMethod.getMethodDescriptor()));
/*     */   }
/*     */   
/*     */   public boolean equals(Object o) {
/* 241 */     if (!(o instanceof MethodInfo)) {
/* 242 */       return false;
/*     */     }
/* 244 */     MethodInfo otherMethod = (MethodInfo)o;
/* 245 */     return (CharOperation.equals(getSelector(), otherMethod.getSelector()) && 
/* 246 */       CharOperation.equals(getMethodDescriptor(), otherMethod.getMethodDescriptor()));
/*     */   }
/*     */   
/*     */   public int hashCode() {
/* 250 */     return CharOperation.hashCode(getSelector()) + CharOperation.hashCode(getMethodDescriptor());
/*     */   }
/*     */ 
/*     */   
/*     */   public IBinaryAnnotation[] getAnnotations() {
/* 255 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public char[][] getArgumentNames() {
/* 262 */     if (this.argumentNames == null) {
/* 263 */       readCodeAttribute();
/*     */     }
/* 265 */     return this.argumentNames;
/*     */   }
/*     */   
/*     */   public Object getDefaultValue() {
/* 269 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public char[][] getExceptionTypeNames() {
/* 274 */     if (this.exceptionNames == null) {
/* 275 */       readExceptionAttributes();
/*     */     }
/* 277 */     return this.exceptionNames;
/*     */   }
/*     */   
/*     */   public char[] getGenericSignature() {
/* 281 */     if (this.signatureUtf8Offset != -1) {
/* 282 */       if (this.signature == null)
/*     */       {
/* 284 */         this.signature = utf8At(this.signatureUtf8Offset + 3, u2At(this.signatureUtf8Offset + 1));
/*     */       }
/* 286 */       return this.signature;
/*     */     } 
/* 288 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public char[] getMethodDescriptor() {
/* 293 */     if (this.descriptor == null) {
/*     */       
/* 295 */       int utf8Offset = this.constantPoolOffsets[u2At(4)] - this.structOffset;
/* 296 */       this.descriptor = utf8At(utf8Offset + 3, u2At(utf8Offset + 1));
/*     */     } 
/* 298 */     return this.descriptor;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getModifiers() {
/* 308 */     if (this.accessFlags == -1)
/*     */     {
/* 310 */       readModifierRelatedAttributes();
/*     */     }
/* 312 */     return this.accessFlags;
/*     */   }
/*     */   
/*     */   public IBinaryAnnotation[] getParameterAnnotations(int index, char[] classFileName) {
/* 316 */     return null;
/*     */   }
/*     */   
/*     */   public int getAnnotatedParametersCount() {
/* 320 */     return 0;
/*     */   }
/*     */   
/*     */   public IBinaryTypeAnnotation[] getTypeAnnotations() {
/* 324 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public char[] getSelector() {
/* 329 */     if (this.name == null) {
/*     */       
/* 331 */       int utf8Offset = this.constantPoolOffsets[u2At(2)] - this.structOffset;
/* 332 */       this.name = utf8At(utf8Offset + 3, u2At(utf8Offset + 1));
/*     */     } 
/* 334 */     return this.name;
/*     */   }
/*     */   
/*     */   public long getTagBits() {
/* 338 */     return this.tagBits;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void initialize() {
/* 345 */     getModifiers();
/* 346 */     getSelector();
/* 347 */     getMethodDescriptor();
/* 348 */     getExceptionTypeNames();
/* 349 */     getGenericSignature();
/* 350 */     getArgumentNames();
/* 351 */     reset();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isClinit() {
/* 359 */     return JavaBinaryNames.isClinit(getSelector());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isConstructor() {
/* 367 */     return JavaBinaryNames.isConstructor(getSelector());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isSynthetic() {
/* 374 */     return ((getModifiers() & 0x1000) != 0);
/*     */   }
/*     */   private synchronized void readExceptionAttributes() {
/* 377 */     int attributesCount = u2At(6);
/* 378 */     int readOffset = 8;
/* 379 */     char[][] names = null;
/* 380 */     for (int i = 0; i < attributesCount; i++) {
/* 381 */       int utf8Offset = this.constantPoolOffsets[u2At(readOffset)] - this.structOffset;
/* 382 */       char[] attributeName = utf8At(utf8Offset + 3, u2At(utf8Offset + 1));
/* 383 */       if (CharOperation.equals(attributeName, AttributeNamesConstants.ExceptionsName)) {
/*     */         
/* 385 */         int entriesNumber = u2At(readOffset + 6);
/*     */         
/* 387 */         readOffset += 8;
/* 388 */         if (entriesNumber == 0) {
/* 389 */           names = noException;
/*     */         } else {
/* 391 */           names = new char[entriesNumber][];
/* 392 */           for (int j = 0; j < entriesNumber; j++) {
/* 393 */             utf8Offset = 
/* 394 */               this.constantPoolOffsets[u2At(
/* 395 */                   this.constantPoolOffsets[u2At(readOffset)] - this.structOffset + 1)] - 
/* 396 */               this.structOffset;
/* 397 */             names[j] = utf8At(utf8Offset + 3, u2At(utf8Offset + 1));
/* 398 */             readOffset += 2;
/*     */           } 
/*     */         } 
/*     */       } else {
/* 402 */         readOffset = (int)(readOffset + 6L + u4At(readOffset + 2));
/*     */       } 
/*     */     } 
/* 405 */     if (names == null) {
/* 406 */       this.exceptionNames = noException;
/*     */     } else {
/* 408 */       this.exceptionNames = names;
/*     */     } 
/*     */   }
/*     */   private synchronized void readModifierRelatedAttributes() {
/* 412 */     int flags = u2At(0);
/* 413 */     int attributesCount = u2At(6);
/* 414 */     int readOffset = 8;
/* 415 */     for (int i = 0; i < attributesCount; i++) {
/* 416 */       int utf8Offset = this.constantPoolOffsets[u2At(readOffset)] - this.structOffset;
/* 417 */       char[] attributeName = utf8At(utf8Offset + 3, u2At(utf8Offset + 1));
/*     */       
/* 419 */       if (attributeName.length != 0)
/* 420 */         switch (attributeName[0]) {
/*     */           case 'D':
/* 422 */             if (CharOperation.equals(attributeName, AttributeNamesConstants.DeprecatedName))
/* 423 */               flags |= 0x100000; 
/*     */             break;
/*     */           case 'S':
/* 426 */             if (CharOperation.equals(attributeName, AttributeNamesConstants.SyntheticName))
/* 427 */               flags |= 0x1000; 
/*     */             break;
/*     */           case 'A':
/* 430 */             if (CharOperation.equals(attributeName, AttributeNamesConstants.AnnotationDefaultName))
/* 431 */               flags |= 0x20000; 
/*     */             break;
/*     */           case 'V':
/* 434 */             if (CharOperation.equals(attributeName, AttributeNamesConstants.VarargsName))
/* 435 */               flags |= 0x80; 
/*     */             break;
/*     */         }  
/* 438 */       readOffset = (int)(readOffset + 6L + u4At(readOffset + 2));
/*     */     } 
/* 440 */     this.accessFlags = flags;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int sizeInBytes() {
/* 448 */     return this.attributeBytes;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 453 */     StringBuffer buffer = new StringBuffer();
/* 454 */     toString(buffer);
/* 455 */     return buffer.toString();
/*     */   }
/*     */   void toString(StringBuffer buffer) {
/* 458 */     buffer.append(getClass().getName());
/* 459 */     toStringContent(buffer);
/*     */   }
/*     */   protected void toStringContent(StringBuffer buffer) {
/* 462 */     BinaryTypeFormatter.methodToStringContent(buffer, this);
/*     */   }
/*     */   private synchronized void readCodeAttribute() {
/* 465 */     int attributesCount = u2At(6);
/* 466 */     int readOffset = 8;
/* 467 */     if (attributesCount != 0) {
/* 468 */       for (int i = 0; i < attributesCount; i++) {
/* 469 */         int utf8Offset = this.constantPoolOffsets[u2At(readOffset)] - this.structOffset;
/* 470 */         char[] attributeName = utf8At(utf8Offset + 3, u2At(utf8Offset + 1));
/* 471 */         if (CharOperation.equals(attributeName, AttributeNamesConstants.CodeName)) {
/* 472 */           decodeCodeAttribute(readOffset);
/* 473 */           if (this.argumentNames == null) {
/* 474 */             this.argumentNames = noArgumentNames;
/*     */           }
/*     */           return;
/*     */         } 
/* 478 */         readOffset = (int)(readOffset + 6L + u4At(readOffset + 2));
/*     */       } 
/*     */     }
/*     */     
/* 482 */     this.argumentNames = noArgumentNames;
/*     */   }
/*     */   private void decodeCodeAttribute(int offset) {
/* 485 */     int readOffset = offset + 10;
/* 486 */     int codeLength = (int)u4At(readOffset);
/* 487 */     readOffset += 4 + codeLength;
/* 488 */     int exceptionTableLength = u2At(readOffset);
/* 489 */     readOffset += 2;
/* 490 */     if (exceptionTableLength != 0) {
/* 491 */       for (int j = 0; j < exceptionTableLength; j++) {
/* 492 */         readOffset += 8;
/*     */       }
/*     */     }
/* 495 */     int attributesCount = u2At(readOffset);
/* 496 */     readOffset += 2;
/* 497 */     for (int i = 0; i < attributesCount; i++) {
/* 498 */       int utf8Offset = this.constantPoolOffsets[u2At(readOffset)] - this.structOffset;
/* 499 */       char[] attributeName = utf8At(utf8Offset + 3, u2At(utf8Offset + 1));
/* 500 */       if (CharOperation.equals(attributeName, AttributeNamesConstants.LocalVariableTableName)) {
/* 501 */         decodeLocalVariableAttribute(readOffset, codeLength);
/*     */       }
/* 503 */       readOffset = (int)(readOffset + 6L + u4At(readOffset + 2));
/*     */     } 
/*     */   }
/*     */   private void decodeLocalVariableAttribute(int offset, int codeLength) {
/* 507 */     int readOffset = offset + 6;
/* 508 */     int length = u2At(readOffset);
/* 509 */     if (length != 0) {
/* 510 */       readOffset += 2;
/* 511 */       char[][] names = new char[length][];
/* 512 */       int argumentNamesIndex = 0;
/* 513 */       for (int i = 0; i < length; ) {
/* 514 */         int startPC = u2At(readOffset);
/* 515 */         if (startPC == 0) {
/* 516 */           int nameIndex = u2At(4 + readOffset);
/* 517 */           int utf8Offset = this.constantPoolOffsets[nameIndex] - this.structOffset;
/* 518 */           char[] localVariableName = utf8At(utf8Offset + 3, u2At(utf8Offset + 1));
/* 519 */           if (!CharOperation.equals(localVariableName, ConstantPool.This)) {
/* 520 */             names[argumentNamesIndex++] = localVariableName;
/*     */           }
/*     */ 
/*     */ 
/*     */           
/* 525 */           readOffset += 10; i++;
/*     */         }  break;
/* 527 */       }  if (argumentNamesIndex != names.length)
/*     */       {
/* 529 */         System.arraycopy(names, 0, names = new char[argumentNamesIndex][], 0, argumentNamesIndex);
/*     */       }
/* 531 */       this.argumentNames = names;
/*     */     } 
/*     */   }
/*     */   private void decodeMethodParameters(int offset, MethodInfo methodInfo) {
/* 535 */     int readOffset = offset + 6;
/* 536 */     int length = u1At(readOffset);
/* 537 */     if (length != 0) {
/* 538 */       readOffset++;
/* 539 */       char[][] names = new char[length][];
/* 540 */       for (int i = 0; i < length; i++) {
/* 541 */         int nameIndex = u2At(readOffset);
/* 542 */         if (nameIndex != 0) {
/* 543 */           int utf8Offset = this.constantPoolOffsets[nameIndex] - this.structOffset;
/* 544 */           char[] parameterName = utf8At(utf8Offset + 3, u2At(utf8Offset + 1));
/* 545 */           names[i] = parameterName;
/*     */         } else {
/* 547 */           names[i] = CharOperation.concat(ARG, String.valueOf(i).toCharArray());
/*     */         } 
/* 549 */         readOffset += 4;
/*     */       } 
/* 551 */       this.argumentNames = names;
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\classfmt\MethodInfo.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */