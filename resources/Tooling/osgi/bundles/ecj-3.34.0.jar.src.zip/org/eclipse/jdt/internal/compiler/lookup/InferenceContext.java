/*     */ package org.eclipse.jdt.internal.compiler.lookup;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class InferenceContext
/*     */ {
/*     */   private TypeBinding[][][] collectedSubstitutes;
/*     */   MethodBinding genericMethod;
/*     */   int depth;
/*     */   int status;
/*     */   TypeBinding expectedType;
/*     */   boolean hasExplicitExpectedType;
/*     */   public boolean isUnchecked;
/*     */   TypeBinding[] substitutes;
/*     */   static final int FAILED = 1;
/*     */   
/*     */   public InferenceContext(MethodBinding genericMethod) {
/*  32 */     this.genericMethod = genericMethod;
/*  33 */     TypeVariableBinding[] typeVariables = genericMethod.typeVariables;
/*  34 */     int varLength = typeVariables.length;
/*  35 */     this.collectedSubstitutes = new TypeBinding[varLength][3][];
/*  36 */     this.substitutes = new TypeBinding[varLength];
/*     */   }
/*     */   
/*     */   public TypeBinding[] getSubstitutes(TypeVariableBinding typeVariable, int constraint) {
/*  40 */     return this.collectedSubstitutes[typeVariable.rank][constraint];
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean hasUnresolvedTypeArgument() {
/*  47 */     for (int i = 0, varLength = this.substitutes.length; i < varLength; i++) {
/*  48 */       if (this.substitutes[i] == null) {
/*  49 */         return true;
/*     */       }
/*     */     } 
/*  52 */     return false;
/*     */   }
/*     */   public void recordSubstitute(TypeVariableBinding typeVariable, TypeBinding actualType, int constraint) {
/*     */     int length;
/*  56 */     TypeBinding[][] variableSubstitutes = this.collectedSubstitutes[typeVariable.rank];
/*     */     
/*  58 */     TypeBinding[] constraintSubstitutes = variableSubstitutes[constraint];
/*     */     
/*  60 */     if (constraintSubstitutes == null) {
/*  61 */       length = 0;
/*  62 */       constraintSubstitutes = new TypeBinding[1];
/*     */     } else {
/*  64 */       length = constraintSubstitutes.length;
/*  65 */       for (int i = 0; i < length; i++) {
/*  66 */         TypeBinding substitute = constraintSubstitutes[i];
/*  67 */         if (substitute == actualType)
/*  68 */           return;  if (substitute == null) {
/*  69 */           constraintSubstitutes[i] = actualType;
/*     */           
/*     */           // Byte code: goto -> 114
/*     */         } 
/*     */       } 
/*  74 */       System.arraycopy(constraintSubstitutes, 0, constraintSubstitutes = new TypeBinding[length + 1], 0, length);
/*     */     } 
/*  76 */     constraintSubstitutes[length] = actualType;
/*  77 */     variableSubstitutes[constraint] = constraintSubstitutes;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/*  82 */     StringBuilder buffer = new StringBuilder(20);
/*  83 */     buffer.append("InferenceContex for "); int i, length;
/*  84 */     for (i = 0, length = this.genericMethod.typeVariables.length; i < length; i++) {
/*  85 */       buffer.append(this.genericMethod.typeVariables[i]);
/*     */     }
/*  87 */     buffer.append(this.genericMethod);
/*  88 */     buffer.append("\n\t[status=");
/*  89 */     switch (this.status) {
/*     */       case 0:
/*  91 */         buffer.append("ok]");
/*     */         break;
/*     */       case 1:
/*  94 */         buffer.append("failed]");
/*     */         break;
/*     */     } 
/*  97 */     if (this.expectedType == null) {
/*  98 */       buffer.append(" [expectedType=null]");
/*     */     } else {
/* 100 */       buffer.append(" [expectedType=").append(this.expectedType.shortReadableName()).append(']');
/*     */     } 
/* 102 */     buffer.append(" [depth=").append(this.depth).append(']');
/* 103 */     buffer.append("\n\t[collected={");
/* 104 */     for (i = 0, length = (this.collectedSubstitutes == null) ? 0 : this.collectedSubstitutes.length; i < length; i++) {
/* 105 */       TypeBinding[][] collected = this.collectedSubstitutes[i];
/* 106 */       for (int m = 0; m <= 2; m++) {
/* 107 */         TypeBinding[] constraintCollected = collected[m];
/* 108 */         if (constraintCollected != null) {
/* 109 */           for (int n = 0, clength = constraintCollected.length; n < clength; n++) {
/* 110 */             buffer.append("\n\t\t").append((this.genericMethod.typeVariables[i]).sourceName);
/* 111 */             switch (m) {
/*     */               case 0:
/* 113 */                 buffer.append("=");
/*     */                 break;
/*     */               case 1:
/* 116 */                 buffer.append("<:");
/*     */                 break;
/*     */               case 2:
/* 119 */                 buffer.append(">:");
/*     */                 break;
/*     */             } 
/* 122 */             if (constraintCollected[n] != null) {
/* 123 */               buffer.append(constraintCollected[n].shortReadableName());
/*     */             }
/*     */           } 
/*     */         }
/*     */       } 
/*     */     } 
/* 129 */     buffer.append("}]");
/* 130 */     buffer.append("\n\t[inferred=");
/* 131 */     int count = 0;
/* 132 */     for (int j = 0, k = (this.substitutes == null) ? 0 : this.substitutes.length; j < k; j++) {
/* 133 */       if (this.substitutes[j] != null) {
/* 134 */         count++;
/* 135 */         buffer.append('{').append((this.genericMethod.typeVariables[j]).sourceName);
/* 136 */         buffer.append("=").append(this.substitutes[j].shortReadableName()).append('}');
/*     */       } 
/* 138 */     }  if (count == 0) buffer.append("{}"); 
/* 139 */     buffer.append(']');
/* 140 */     return buffer.toString();
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\lookup\InferenceContext.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */