package org.eclipse.jdt.internal.compiler.lookup;

public interface ExtendedTagBits {
  public static final int AreRecordComponentsComplete = 1;
  
  public static final int HasUnresolvedPermittedSubtypes = 2;
  
  public static final int AnnotationValueBased = 4;
  
  public static final int IsCanonicalConstructor = 8;
  
  public static final int isImplicit = 16;
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\lookup\ExtendedTagBits.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */