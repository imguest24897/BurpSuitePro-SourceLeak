/*     */ package org.eclipse.jdt.internal.compiler.ast;
/*     */ 
/*     */ import org.eclipse.jdt.internal.compiler.ASTVisitor;
/*     */ import org.eclipse.jdt.internal.compiler.codegen.CodeStream;
/*     */ import org.eclipse.jdt.internal.compiler.flow.FlowContext;
/*     */ import org.eclipse.jdt.internal.compiler.flow.FlowInfo;
/*     */ import org.eclipse.jdt.internal.compiler.flow.UnconditionalFlowInfo;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.Binding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.BlockScope;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.InferenceContext18;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.LocalTypeBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.MethodBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.MethodScope;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.ParameterizedGenericMethodBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.ParameterizedMethodBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.ProblemMethodBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.ReferenceBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.Scope;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.SourceTypeBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.TypeBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.TypeConstants;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.VariableBinding;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ExplicitConstructorCall
/*     */   extends Statement
/*     */   implements Invocation
/*     */ {
/*     */   public Expression[] arguments;
/*     */   public Expression qualification;
/*     */   public MethodBinding binding;
/*     */   MethodBinding syntheticAccessor;
/*     */   public int accessMode;
/*     */   public TypeReference[] typeArguments;
/*     */   public TypeBinding[] genericTypeArguments;
/*     */   public static final int ImplicitSuper = 1;
/*     */   public static final int Super = 2;
/*     */   public static final int This = 3;
/*     */   public VariableBinding[][] implicitArguments;
/*     */   public int typeArgumentsSourceStart;
/*     */   
/*     */   public ExplicitConstructorCall(int accessMode) {
/*  84 */     this.accessMode = accessMode;
/*     */   }
/*     */ 
/*     */   
/*     */   public FlowInfo analyseCode(BlockScope currentScope, FlowContext flowContext, FlowInfo flowInfo) {
/*     */     try {
/*     */       UnconditionalFlowInfo unconditionalFlowInfo;
/*     */       FlowInfo flowInfo1;
/*  92 */       ((MethodScope)currentScope).isConstructorCall = true;
/*     */ 
/*     */       
/*  95 */       if (this.qualification != null) {
/*  96 */         unconditionalFlowInfo = 
/*  97 */           this.qualification
/*  98 */           .analyseCode(currentScope, flowContext, flowInfo)
/*  99 */           .unconditionalInits();
/*     */       }
/*     */       
/* 102 */       if (this.arguments != null) {
/* 103 */         boolean analyseResources = (currentScope.compilerOptions()).analyseResourceLeaks;
/* 104 */         for (int i = 0, max = this.arguments.length; i < max; i++) {
/* 105 */           unconditionalFlowInfo = 
/* 106 */             this.arguments[i]
/* 107 */             .analyseCode(currentScope, flowContext, (FlowInfo)unconditionalFlowInfo)
/* 108 */             .unconditionalInits();
/* 109 */           if (analyseResources)
/*     */           {
/* 111 */             flowInfo1 = FakedTrackingVariable.markPassedToOutside(currentScope, this.arguments[i], (FlowInfo)unconditionalFlowInfo, flowContext, false);
/*     */           }
/* 113 */           this.arguments[i].checkNPEbyUnboxing(currentScope, flowContext, flowInfo1);
/*     */         } 
/* 115 */         analyseArguments(currentScope, flowContext, flowInfo1, this.binding, this.arguments);
/*     */       } 
/*     */       
/*     */       ReferenceBinding[] thrownExceptions;
/* 119 */       if ((thrownExceptions = this.binding.thrownExceptions) != Binding.NO_EXCEPTIONS) {
/* 120 */         if ((this.bits & 0x10000) != 0 && this.genericTypeArguments == null)
/*     */         {
/* 122 */           thrownExceptions = currentScope.environment().convertToRawTypes(this.binding.thrownExceptions, true, true);
/*     */         }
/*     */         
/* 125 */         flowContext.checkExceptionHandlers(
/* 126 */             (TypeBinding[])thrownExceptions, 
/* 127 */             (this.accessMode == 1) ? 
/* 128 */             (ASTNode)(currentScope.methodScope()).referenceContext : 
/* 129 */             this, 
/* 130 */             flowInfo1, 
/* 131 */             currentScope);
/*     */       } 
/* 133 */       manageEnclosingInstanceAccessIfNecessary(currentScope, flowInfo1);
/* 134 */       manageSyntheticAccessIfNecessary(currentScope, flowInfo1);
/* 135 */       return flowInfo1;
/*     */     } finally {
/* 137 */       ((MethodScope)currentScope).isConstructorCall = false;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void generateCode(BlockScope currentScope, CodeStream codeStream) {
/* 149 */     if ((this.bits & Integer.MIN_VALUE) == 0) {
/*     */       return;
/*     */     }
/*     */     try {
/* 153 */       ((MethodScope)currentScope).isConstructorCall = true;
/*     */       
/* 155 */       int pc = codeStream.position;
/* 156 */       codeStream.aload_0();
/*     */       
/* 158 */       MethodBinding codegenBinding = this.binding.original();
/* 159 */       ReferenceBinding targetType = codegenBinding.declaringClass;
/*     */ 
/*     */       
/* 162 */       if ((targetType.erasure()).id == 41 || targetType.isEnum()) {
/* 163 */         codeStream.aload_1();
/* 164 */         codeStream.iload_2();
/*     */       } 
/*     */ 
/*     */       
/* 168 */       if (targetType.isNestedType()) {
/* 169 */         codeStream.generateSyntheticEnclosingInstanceValues(
/* 170 */             currentScope, 
/* 171 */             targetType, 
/* 172 */             ((this.bits & 0x2000) != 0) ? null : this.qualification, 
/* 173 */             this);
/*     */       }
/*     */       
/* 176 */       generateArguments(this.binding, this.arguments, currentScope, codeStream);
/*     */ 
/*     */       
/* 179 */       if (targetType.isNestedType()) {
/* 180 */         codeStream.generateSyntheticOuterArgumentValues(
/* 181 */             currentScope, 
/* 182 */             targetType, 
/* 183 */             this);
/*     */       }
/* 185 */       if (this.syntheticAccessor != null) {
/*     */         
/* 187 */         int i = 0;
/* 188 */         int max = this.syntheticAccessor.parameters.length - codegenBinding.parameters.length;
/* 189 */         for (; i < max; 
/* 190 */           i++) {
/* 191 */           codeStream.aconst_null();
/*     */         }
/* 193 */         codeStream.invoke((byte)-73, this.syntheticAccessor, null, this.typeArguments);
/*     */       } else {
/* 195 */         codeStream.invoke((byte)-73, codegenBinding, null, this.typeArguments);
/*     */       } 
/* 197 */       codeStream.recordPositionsFrom(pc, this.sourceStart);
/*     */     } finally {
/* 199 */       ((MethodScope)currentScope).isConstructorCall = false;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TypeBinding[] genericTypeArguments() {
/* 208 */     return this.genericTypeArguments;
/*     */   }
/*     */   
/*     */   public boolean isImplicitSuper() {
/* 212 */     return (this.accessMode == 1);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isSuperAccess() {
/* 217 */     return (this.accessMode != 3);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isTypeAccess() {
/* 222 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void manageEnclosingInstanceAccessIfNecessary(BlockScope currentScope, FlowInfo flowInfo) {
/* 233 */     ReferenceBinding superTypeErasure = (ReferenceBinding)this.binding.declaringClass.erasure();
/*     */     
/* 235 */     if ((flowInfo.tagBits & 0x1) == 0)
/*     */     {
/* 237 */       if (superTypeErasure.isNestedType() && 
/* 238 */         currentScope.enclosingSourceType().isLocalType())
/*     */       {
/* 240 */         if (superTypeErasure.isLocalType()) {
/* 241 */           ((LocalTypeBinding)superTypeErasure).addInnerEmulationDependent(currentScope, (this.qualification != null));
/*     */         } else {
/*     */           
/* 244 */           currentScope.propagateInnerEmulation(superTypeErasure, (this.qualification != null));
/*     */         } 
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public void manageSyntheticAccessIfNecessary(BlockScope currentScope, FlowInfo flowInfo) {
/* 251 */     if ((flowInfo.tagBits & 0x1) == 0) {
/*     */       
/* 253 */       MethodBinding codegenBinding = this.binding.original();
/*     */ 
/*     */       
/* 256 */       if (this.binding.isPrivate() && 
/* 257 */         !currentScope.enclosingSourceType().isNestmateOf(this.binding.declaringClass) && 
/* 258 */         this.accessMode != 3) {
/* 259 */         ReferenceBinding declaringClass = codegenBinding.declaringClass;
/*     */         
/* 261 */         if ((declaringClass.tagBits & 0x10L) != 0L && (currentScope.compilerOptions()).complianceLevel >= 3145728L) {
/*     */           
/* 263 */           codegenBinding.tagBits |= 0x200L;
/*     */         } else {
/* 265 */           this.syntheticAccessor = (MethodBinding)((SourceTypeBinding)declaringClass).addSyntheticMethod(codegenBinding, isSuperAccess());
/* 266 */           currentScope.problemReporter().needToEmulateMethodAccess(codegenBinding, this);
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public StringBuffer printStatement(int indent, StringBuffer output) {
/* 274 */     printIndent(indent, output);
/* 275 */     if (this.qualification != null) this.qualification.printExpression(0, output).append('.'); 
/* 276 */     if (this.typeArguments != null) {
/* 277 */       output.append('<');
/* 278 */       int max = this.typeArguments.length - 1;
/* 279 */       for (int j = 0; j < max; j++) {
/* 280 */         this.typeArguments[j].print(0, output);
/* 281 */         output.append(", ");
/*     */       } 
/* 283 */       this.typeArguments[max].print(0, output);
/* 284 */       output.append('>');
/*     */     } 
/* 286 */     if (this.accessMode == 3) {
/* 287 */       output.append("this(");
/*     */     } else {
/* 289 */       output.append("super(");
/*     */     } 
/* 291 */     if (this.arguments != null) {
/* 292 */       for (int i = 0; i < this.arguments.length; i++) {
/* 293 */         if (i > 0) output.append(", "); 
/* 294 */         this.arguments[i].printExpression(0, output);
/*     */       } 
/*     */     }
/* 297 */     return output.append(");");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void resolve(BlockScope scope) {
/* 307 */     MethodScope methodScope = scope.methodScope();
/*     */     try {
/* 309 */       AbstractMethodDeclaration methodDeclaration = methodScope.referenceMethod();
/* 310 */       if (methodDeclaration != null && methodDeclaration.binding != null && 
/* 311 */         methodDeclaration.binding.isCanonicalConstructor() && 
/* 312 */         !checkAndFlagExplicitConstructorCallInCanonicalConstructor(methodDeclaration, scope)) {
/*     */         return;
/*     */       }
/* 315 */       if (methodDeclaration == null || 
/* 316 */         !methodDeclaration.isConstructor() || 
/* 317 */         ((ConstructorDeclaration)methodDeclaration).constructorCall != this) {
/* 318 */         if (!(methodDeclaration instanceof CompactConstructorDeclaration)) {
/* 319 */           scope.problemReporter().invalidExplicitConstructorCall(this);
/*     */         }
/* 321 */         if (this.qualification != null) {
/* 322 */           this.qualification.resolveType(scope);
/*     */         }
/* 324 */         if (this.typeArguments != null) {
/* 325 */           for (int i = 0, max = this.typeArguments.length; i < max; i++) {
/* 326 */             this.typeArguments[i].resolveType(scope, true);
/*     */           }
/*     */         }
/* 329 */         if (this.arguments != null) {
/* 330 */           for (int i = 0, max = this.arguments.length; i < max; i++) {
/* 331 */             this.arguments[i].resolveType(scope);
/*     */           }
/*     */         }
/*     */         return;
/*     */       } 
/* 336 */       methodScope.isConstructorCall = true;
/* 337 */       ReferenceBinding receiverType = scope.enclosingReceiverType();
/* 338 */       boolean rcvHasError = false;
/* 339 */       if (this.accessMode != 3) {
/* 340 */         receiverType = receiverType.superclass();
/* 341 */         TypeReference superclassRef = (scope.referenceType()).superclass;
/* 342 */         if (superclassRef != null && superclassRef.resolvedType != null && !superclassRef.resolvedType.isValidBinding()) {
/* 343 */           rcvHasError = true;
/*     */         }
/*     */       } 
/* 346 */       if (receiverType != null) {
/*     */         
/* 348 */         if (this.accessMode == 2 && (receiverType.erasure()).id == 41) {
/* 349 */           scope.problemReporter().cannotInvokeSuperConstructorInEnum(this, (methodScope.referenceMethod()).binding);
/*     */         }
/*     */         
/* 352 */         if (this.qualification != null) {
/* 353 */           if (this.accessMode != 2) {
/* 354 */             scope.problemReporter().unnecessaryEnclosingInstanceSpecification(
/* 355 */                 this.qualification, 
/* 356 */                 receiverType);
/*     */           }
/* 358 */           if (!rcvHasError) {
/* 359 */             ReferenceBinding enclosingType = receiverType.enclosingType();
/* 360 */             if (enclosingType == null) {
/* 361 */               scope.problemReporter().unnecessaryEnclosingInstanceSpecification(this.qualification, receiverType);
/* 362 */               this.bits |= 0x2000;
/*     */             } else {
/* 364 */               TypeBinding qTb = this.qualification.resolveTypeExpecting(scope, (TypeBinding)enclosingType);
/* 365 */               this.qualification.computeConversion((Scope)scope, qTb, qTb);
/*     */             } 
/*     */           } 
/*     */         } 
/*     */       } 
/*     */       
/* 371 */       long sourceLevel = (scope.compilerOptions()).sourceLevel;
/* 372 */       if (this.typeArguments != null) {
/* 373 */         boolean argHasError = (sourceLevel < 3211264L);
/* 374 */         int length = this.typeArguments.length;
/* 375 */         this.genericTypeArguments = new TypeBinding[length]; int i;
/* 376 */         for (i = 0; i < length; i++) {
/* 377 */           TypeReference typeReference = this.typeArguments[i];
/* 378 */           this.genericTypeArguments[i] = typeReference.resolveType(scope, true); if (typeReference.resolveType(scope, true) == null) {
/* 379 */             argHasError = true;
/*     */           }
/* 381 */           if (argHasError && typeReference instanceof Wildcard) {
/* 382 */             scope.problemReporter().illegalUsageOfWildcard(typeReference);
/*     */           }
/*     */         } 
/* 385 */         if (argHasError) {
/* 386 */           if (this.arguments != null) {
/* 387 */             int max; for (i = 0, max = this.arguments.length; i < max; i++) {
/* 388 */               this.arguments[i].resolveType(scope);
/*     */             }
/*     */           } 
/*     */           
/*     */           return;
/*     */         } 
/*     */       } 
/* 395 */       TypeBinding[] argumentTypes = Binding.NO_PARAMETERS;
/* 396 */       boolean argsContainCast = false;
/* 397 */       if (this.arguments != null) {
/* 398 */         boolean argHasError = false;
/* 399 */         int length = this.arguments.length;
/* 400 */         argumentTypes = new TypeBinding[length];
/* 401 */         for (int i = 0; i < length; i++) {
/* 402 */           Expression argument = this.arguments[i];
/* 403 */           if (argument instanceof CastExpression) {
/* 404 */             argument.bits |= 0x20;
/* 405 */             argsContainCast = true;
/*     */           } 
/* 407 */           argument.setExpressionContext(ExpressionContext.INVOCATION_CONTEXT);
/* 408 */           argumentTypes[i] = argument.resolveType(scope); if (argument.resolveType(scope) == null) {
/* 409 */             argHasError = true;
/*     */           }
/*     */         } 
/* 412 */         if (argHasError) {
/* 413 */           if (receiverType == null) {
/*     */             return;
/*     */           }
/*     */           
/* 417 */           TypeBinding[] pseudoArgs = new TypeBinding[length];
/* 418 */           for (int j = length; --j >= 0;) {
/* 419 */             pseudoArgs[j] = (argumentTypes[j] == null) ? (TypeBinding)TypeBinding.NULL : argumentTypes[j];
/*     */           }
/* 421 */           this.binding = scope.findMethod(receiverType, TypeConstants.INIT, pseudoArgs, this, false);
/* 422 */           if (this.binding != null && !this.binding.isValidBinding()) {
/* 423 */             MethodBinding closestMatch = ((ProblemMethodBinding)this.binding).closestMatch;
/*     */             
/* 425 */             if (closestMatch != null) {
/* 426 */               ParameterizedGenericMethodBinding parameterizedGenericMethodBinding; if ((closestMatch.original()).typeVariables != Binding.NO_TYPE_VARIABLES)
/*     */               {
/* 428 */                 parameterizedGenericMethodBinding = scope.environment().createParameterizedGenericMethod(closestMatch.original(), null);
/*     */               }
/* 430 */               this.binding = (MethodBinding)parameterizedGenericMethodBinding;
/* 431 */               MethodBinding closestMatchOriginal = parameterizedGenericMethodBinding.original();
/* 432 */               if (closestMatchOriginal.isOrEnclosedByPrivateType() && !scope.isDefinedInMethod(closestMatchOriginal))
/*     */               {
/* 434 */                 closestMatchOriginal.modifiers |= 0x8000000;
/*     */               }
/*     */             } 
/*     */           } 
/*     */           return;
/*     */         } 
/* 440 */       } else if ((receiverType.erasure()).id == 41) {
/*     */         
/* 442 */         argumentTypes = new TypeBinding[] { (TypeBinding)scope.getJavaLangString(), (TypeBinding)TypeBinding.INT };
/*     */       } 
/* 444 */       if (receiverType == null) {
/*     */         return;
/*     */       }
/* 447 */       this.binding = findConstructorBinding(scope, this, receiverType, argumentTypes);
/*     */       
/* 449 */       if (this.binding.isValidBinding()) {
/* 450 */         if ((this.binding.tagBits & 0x80L) != 0L && 
/* 451 */           !methodScope.enclosingSourceType().isAnonymousType()) {
/* 452 */           scope.problemReporter().missingTypeInConstructor(this, this.binding);
/*     */         }
/*     */         
/* 455 */         if (isMethodUseDeprecated(this.binding, (Scope)scope, (this.accessMode != 1), this)) {
/* 456 */           scope.problemReporter().deprecatedMethod(this.binding, this);
/*     */         }
/* 458 */         if (checkInvocationArguments(scope, null, (TypeBinding)receiverType, this.binding, this.arguments, argumentTypes, argsContainCast, this)) {
/* 459 */           this.bits |= 0x10000;
/*     */         }
/* 461 */         if (this.binding.isOrEnclosedByPrivateType()) {
/* 462 */           (this.binding.original()).modifiers |= 0x8000000;
/*     */         }
/* 464 */         if (this.typeArguments != null && 
/* 465 */           (this.binding.original()).typeVariables == Binding.NO_TYPE_VARIABLES) {
/* 466 */           scope.problemReporter().unnecessaryTypeArgumentsForMethodInvocation(this.binding, this.genericTypeArguments, this.typeArguments);
/*     */         }
/*     */       } else {
/* 469 */         if (this.binding.declaringClass == null) {
/* 470 */           this.binding.declaringClass = receiverType;
/*     */         }
/* 472 */         if (rcvHasError)
/*     */           return; 
/* 474 */         scope.problemReporter().invalidConstructor(this, this.binding);
/*     */       } 
/*     */     } finally {
/* 477 */       methodScope.isConstructorCall = false;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private boolean checkAndFlagExplicitConstructorCallInCanonicalConstructor(AbstractMethodDeclaration methodDecl, BlockScope scope) {
/* 483 */     if (methodDecl.binding == null || methodDecl.binding.declaringClass == null || 
/* 484 */       !methodDecl.binding.declaringClass.isRecord())
/* 485 */       return true; 
/* 486 */     boolean isInsideCCD = methodDecl instanceof CompactConstructorDeclaration;
/* 487 */     if (this.accessMode != 1) {
/* 488 */       if (isInsideCCD) {
/* 489 */         scope.problemReporter().recordCompactConstructorHasExplicitConstructorCall(this);
/*     */       } else {
/* 491 */         scope.problemReporter().recordCanonicalConstructorHasExplicitConstructorCall(this);
/* 492 */       }  return false;
/*     */     } 
/* 494 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setActualReceiverType(ReferenceBinding receiverType) {}
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDepth(int depth) {}
/*     */ 
/*     */ 
/*     */   
/*     */   public void setFieldIndex(int depth) {}
/*     */ 
/*     */ 
/*     */   
/*     */   public void traverse(ASTVisitor visitor, BlockScope scope) {
/* 513 */     if (visitor.visit(this, scope)) {
/* 514 */       if (this.qualification != null) {
/* 515 */         this.qualification.traverse(visitor, scope);
/*     */       }
/* 517 */       if (this.typeArguments != null) {
/* 518 */         for (int i = 0, typeArgumentsLength = this.typeArguments.length; i < typeArgumentsLength; i++) {
/* 519 */           this.typeArguments[i].traverse(visitor, scope);
/*     */         }
/*     */       }
/* 522 */       if (this.arguments != null)
/* 523 */         for (int i = 0, argumentLength = this.arguments.length; i < argumentLength; i++) {
/* 524 */           this.arguments[i].traverse(visitor, scope);
/*     */         } 
/*     */     } 
/* 527 */     visitor.endVisit(this, scope);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public MethodBinding binding() {
/* 533 */     return this.binding;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void registerInferenceContext(ParameterizedGenericMethodBinding method, InferenceContext18 infCtx18) {}
/*     */ 
/*     */ 
/*     */   
/*     */   public void registerResult(TypeBinding targetType, MethodBinding method) {}
/*     */ 
/*     */ 
/*     */   
/*     */   public InferenceContext18 getInferenceContext(ParameterizedMethodBinding method) {
/* 548 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void cleanUpInferenceContexts() {}
/*     */ 
/*     */ 
/*     */   
/*     */   public Expression[] arguments() {
/* 558 */     return this.arguments;
/*     */   }
/*     */ 
/*     */   
/*     */   public InferenceContext18 freshInferenceContext(Scope scope) {
/* 563 */     return new InferenceContext18(scope, this.arguments, this, null);
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\ast\ExplicitConstructorCall.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */