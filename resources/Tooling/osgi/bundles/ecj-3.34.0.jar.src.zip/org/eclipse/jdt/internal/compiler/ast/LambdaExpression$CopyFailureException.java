package org.eclipse.jdt.internal.compiler.ast;

class CopyFailureException extends RuntimeException {
  private static final long serialVersionUID = 1L;
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\ast\LambdaExpression$CopyFailureException.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */