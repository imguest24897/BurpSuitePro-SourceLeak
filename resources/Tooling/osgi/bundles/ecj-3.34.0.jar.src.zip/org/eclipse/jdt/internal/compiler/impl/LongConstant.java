/*     */ package org.eclipse.jdt.internal.compiler.impl;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LongConstant
/*     */   extends Constant
/*     */ {
/*  18 */   private static final LongConstant ZERO = new LongConstant(0L);
/*  19 */   private static final LongConstant MIN_VALUE = new LongConstant(Long.MIN_VALUE);
/*     */   
/*     */   private long value;
/*     */   
/*     */   public static Constant fromValue(long value) {
/*  24 */     if (value == 0L)
/*  25 */       return ZERO; 
/*  26 */     if (value == Long.MIN_VALUE) {
/*  27 */       return MIN_VALUE;
/*     */     }
/*  29 */     return new LongConstant(value);
/*     */   }
/*     */   
/*     */   private LongConstant(long value) {
/*  33 */     this.value = value;
/*     */   }
/*     */ 
/*     */   
/*     */   public byte byteValue() {
/*  38 */     return (byte)(int)this.value;
/*     */   }
/*     */ 
/*     */   
/*     */   public char charValue() {
/*  43 */     return (char)(int)this.value;
/*     */   }
/*     */ 
/*     */   
/*     */   public double doubleValue() {
/*  48 */     return this.value;
/*     */   }
/*     */ 
/*     */   
/*     */   public float floatValue() {
/*  53 */     return (float)this.value;
/*     */   }
/*     */ 
/*     */   
/*     */   public int intValue() {
/*  58 */     return (int)this.value;
/*     */   }
/*     */ 
/*     */   
/*     */   public long longValue() {
/*  63 */     return this.value;
/*     */   }
/*     */ 
/*     */   
/*     */   public short shortValue() {
/*  68 */     return (short)(int)this.value;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String stringValue() {
/*  74 */     return String.valueOf(this.value);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/*  80 */     return "(long)" + this.value;
/*     */   }
/*     */ 
/*     */   
/*     */   public int typeID() {
/*  85 */     return 7;
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/*  90 */     return (int)(this.value ^ this.value >>> 32L);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object obj) {
/*  95 */     if (this == obj) {
/*  96 */       return true;
/*     */     }
/*  98 */     if (obj == null) {
/*  99 */       return false;
/*     */     }
/* 101 */     if (getClass() != obj.getClass()) {
/* 102 */       return false;
/*     */     }
/* 104 */     LongConstant other = (LongConstant)obj;
/* 105 */     return (this.value == other.value);
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\impl\LongConstant.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */