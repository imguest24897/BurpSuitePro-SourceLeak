/*    */ package org.eclipse.jdt.internal.compiler.env;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PackageExportImpl
/*    */   implements IModule.IPackageExport
/*    */ {
/*    */   public char[] pack;
/*    */   public char[][] exportedTo;
/*    */   
/*    */   public char[] name() {
/* 21 */     return this.pack;
/*    */   }
/*    */ 
/*    */   
/*    */   public char[][] targets() {
/* 26 */     return this.exportedTo;
/*    */   }
/*    */   
/*    */   public String toString() {
/* 30 */     StringBuilder buffer = new StringBuilder();
/* 31 */     buffer.append(this.pack);
/* 32 */     buffer.append(" to ");
/* 33 */     if (this.exportedTo != null) {
/* 34 */       for (int i = 0; i < this.exportedTo.length; i++) {
/* 35 */         if (i > 0) {
/* 36 */           buffer.append(", ");
/*    */         }
/* 38 */         char[] cs = this.exportedTo[i];
/* 39 */         buffer.append(cs);
/*    */       } 
/*    */     }
/* 42 */     buffer.append(';');
/* 43 */     return buffer.toString();
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\env\PackageExportImpl.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */