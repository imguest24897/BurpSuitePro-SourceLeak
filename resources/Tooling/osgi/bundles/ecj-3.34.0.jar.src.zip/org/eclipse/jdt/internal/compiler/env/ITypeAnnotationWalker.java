/*    */ package org.eclipse.jdt.internal.compiler.env;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface ITypeAnnotationWalker
/*    */ {
/* 27 */   public static final IBinaryAnnotation[] NO_ANNOTATIONS = new IBinaryAnnotation[0];
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 32 */   public static final ITypeAnnotationWalker EMPTY_ANNOTATION_WALKER = new ITypeAnnotationWalker() {
/*    */       public ITypeAnnotationWalker toField() {
/* 34 */         return this;
/*    */       } public ITypeAnnotationWalker toThrows(int rank) {
/* 36 */         return this;
/*    */       } public ITypeAnnotationWalker toTypeArgument(int rank) {
/* 38 */         return this;
/*    */       } public ITypeAnnotationWalker toMethodParameter(short index) {
/* 40 */         return this;
/*    */       } public ITypeAnnotationWalker toSupertype(short index, char[] superTypeSignature) {
/* 42 */         return this;
/*    */       } public ITypeAnnotationWalker toTypeParameterBounds(boolean isClassTypeParameter, int parameterRank) {
/* 44 */         return this;
/*    */       } public ITypeAnnotationWalker toTypeBound(short boundIndex) {
/* 46 */         return this;
/*    */       } public ITypeAnnotationWalker toTypeParameter(boolean isClassTypeParameter, int rank) {
/* 48 */         return this;
/*    */       } public ITypeAnnotationWalker toMethodReturn() {
/* 50 */         return this;
/*    */       } public ITypeAnnotationWalker toReceiver() {
/* 52 */         return this;
/*    */       } public ITypeAnnotationWalker toWildcardBound() {
/* 54 */         return this;
/*    */       } public ITypeAnnotationWalker toNextArrayDimension() {
/* 56 */         return this;
/*    */       } public ITypeAnnotationWalker toNextNestedType() {
/* 58 */         return this;
/*    */       } public IBinaryAnnotation[] getAnnotationsAtCursor(int currentTypeId, boolean mayApplyArrayContentsDefaultNullness) {
/* 60 */         return NO_ANNOTATIONS;
/*    */       }
/*    */     };
/*    */   
/*    */   ITypeAnnotationWalker toField();
/*    */   
/*    */   ITypeAnnotationWalker toMethodReturn();
/*    */   
/*    */   ITypeAnnotationWalker toReceiver();
/*    */   
/*    */   ITypeAnnotationWalker toTypeParameter(boolean paramBoolean, int paramInt);
/*    */   
/*    */   ITypeAnnotationWalker toTypeParameterBounds(boolean paramBoolean, int paramInt);
/*    */   
/*    */   ITypeAnnotationWalker toTypeBound(short paramShort);
/*    */   
/*    */   ITypeAnnotationWalker toSupertype(short paramShort, char[] paramArrayOfchar);
/*    */   
/*    */   ITypeAnnotationWalker toMethodParameter(short paramShort);
/*    */   
/*    */   ITypeAnnotationWalker toThrows(int paramInt);
/*    */   
/*    */   ITypeAnnotationWalker toTypeArgument(int paramInt);
/*    */   
/*    */   ITypeAnnotationWalker toWildcardBound();
/*    */   
/*    */   ITypeAnnotationWalker toNextArrayDimension();
/*    */   
/*    */   ITypeAnnotationWalker toNextNestedType();
/*    */   
/*    */   IBinaryAnnotation[] getAnnotationsAtCursor(int paramInt, boolean paramBoolean);
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\env\ITypeAnnotationWalker.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */