/*     */ package org.eclipse.jdt.internal.compiler.ast;
/*     */ 
/*     */ import org.eclipse.jdt.core.compiler.CharOperation;
/*     */ import org.eclipse.jdt.internal.compiler.ASTVisitor;
/*     */ import org.eclipse.jdt.internal.compiler.codegen.BranchLabel;
/*     */ import org.eclipse.jdt.internal.compiler.codegen.CodeStream;
/*     */ import org.eclipse.jdt.internal.compiler.flow.FlowContext;
/*     */ import org.eclipse.jdt.internal.compiler.flow.FlowInfo;
/*     */ import org.eclipse.jdt.internal.compiler.flow.UnconditionalFlowInfo;
/*     */ import org.eclipse.jdt.internal.compiler.impl.CompilerOptions;
/*     */ import org.eclipse.jdt.internal.compiler.impl.Constant;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.BaseTypeBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.BlockScope;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.LocalVariableBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.LookupEnvironment;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.MethodBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.PolyTypeBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.Scope;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.TypeBinding;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ConditionalExpression
/*     */   extends OperatorExpression
/*     */   implements IPolyExpression
/*     */ {
/*     */   public Expression condition;
/*     */   public Expression valueIfTrue;
/*     */   public Expression valueIfFalse;
/*     */   public Constant optimizedBooleanConstant;
/*     */   public Constant optimizedIfTrueConstant;
/*     */   public Constant optimizedIfFalseConstant;
/*  52 */   int trueInitStateIndex = -1;
/*  53 */   int falseInitStateIndex = -1;
/*  54 */   int mergedInitStateIndex = -1;
/*     */ 
/*     */   
/*  57 */   private int nullStatus = 1;
/*     */   int ifFalseNullStatus;
/*     */   int ifTrueNullStatus;
/*     */   private TypeBinding expectedType;
/*  61 */   private ExpressionContext expressionContext = ExpressionContext.VANILLA_CONTEXT;
/*     */   private boolean isPolyExpression = false;
/*     */   private TypeBinding originalValueIfTrueType;
/*     */   private TypeBinding originalValueIfFalseType;
/*     */   private boolean use18specifics;
/*     */   
/*     */   public ConditionalExpression(Expression condition, Expression valueIfTrue, Expression valueIfFalse) {
/*  68 */     this.condition = condition;
/*  69 */     this.valueIfTrue = valueIfTrue;
/*  70 */     this.valueIfFalse = valueIfFalse;
/*  71 */     this.sourceStart = condition.sourceStart;
/*  72 */     this.sourceEnd = valueIfFalse.sourceEnd;
/*     */   }
/*     */ 
/*     */   
/*     */   public FlowInfo analyseCode(BlockScope currentScope, FlowContext flowContext, FlowInfo flowInfo) {
/*     */     FlowInfo mergedInfo;
/*  78 */     int initialComplaintLevel = ((flowInfo.reachMode() & 0x3) != 0) ? 1 : 0;
/*  79 */     Constant cst = this.condition.optimizedBooleanConstant();
/*  80 */     boolean isConditionOptimizedTrue = (cst != Constant.NotAConstant && cst.booleanValue());
/*  81 */     boolean isConditionOptimizedFalse = (cst != Constant.NotAConstant && !cst.booleanValue());
/*     */     
/*  83 */     int mode = flowInfo.reachMode();
/*  84 */     flowInfo = this.condition.analyseCode(currentScope, flowContext, flowInfo, (cst == Constant.NotAConstant));
/*     */     
/*  86 */     flowContext.conditionalLevel++;
/*     */ 
/*     */     
/*  89 */     FlowInfo trueFlowInfo = flowInfo.initsWhenTrue().copy();
/*  90 */     CompilerOptions compilerOptions = currentScope.compilerOptions();
/*  91 */     if (isConditionOptimizedFalse) {
/*  92 */       if ((mode & 0x3) == 0) {
/*  93 */         trueFlowInfo.setReachMode(1);
/*     */       }
/*  95 */       if (!isKnowDeadCodePattern(this.condition) || compilerOptions.reportDeadCodeInTrivialIfStatement) {
/*  96 */         this.valueIfTrue.complainIfUnreachable(trueFlowInfo, currentScope, initialComplaintLevel, false);
/*     */       }
/*     */     } 
/*  99 */     this.trueInitStateIndex = currentScope.methodScope().recordInitializationStates(trueFlowInfo);
/* 100 */     this.condition.updateFlowOnBooleanResult(trueFlowInfo, true);
/* 101 */     trueFlowInfo = this.valueIfTrue.analyseCode(currentScope, flowContext, trueFlowInfo);
/* 102 */     this.valueIfTrue.checkNPEbyUnboxing(currentScope, flowContext, trueFlowInfo);
/*     */ 
/*     */     
/* 105 */     this.ifTrueNullStatus = -1;
/* 106 */     if (compilerOptions.enableSyntacticNullAnalysisForFields) {
/* 107 */       this.ifTrueNullStatus = this.valueIfTrue.nullStatus(trueFlowInfo, flowContext);
/*     */       
/* 109 */       flowContext.expireNullCheckedFieldInfo();
/*     */     } 
/*     */ 
/*     */     
/* 113 */     FlowInfo falseFlowInfo = flowInfo.initsWhenFalse().copy();
/* 114 */     if (isConditionOptimizedTrue) {
/* 115 */       if ((mode & 0x3) == 0) {
/* 116 */         falseFlowInfo.setReachMode(1);
/*     */       }
/* 118 */       if (!isKnowDeadCodePattern(this.condition) || compilerOptions.reportDeadCodeInTrivialIfStatement) {
/* 119 */         this.valueIfFalse.complainIfUnreachable(falseFlowInfo, currentScope, initialComplaintLevel, true);
/*     */       }
/*     */     } 
/* 122 */     this.falseInitStateIndex = currentScope.methodScope().recordInitializationStates(falseFlowInfo);
/* 123 */     this.condition.updateFlowOnBooleanResult(falseFlowInfo, false);
/* 124 */     falseFlowInfo = this.valueIfFalse.analyseCode(currentScope, flowContext, falseFlowInfo);
/* 125 */     this.valueIfFalse.checkNPEbyUnboxing(currentScope, flowContext, falseFlowInfo);
/*     */     
/* 127 */     flowContext.conditionalLevel--;
/*     */ 
/*     */ 
/*     */     
/* 131 */     if (isConditionOptimizedTrue) {
/* 132 */       mergedInfo = trueFlowInfo.addPotentialInitializationsFrom(falseFlowInfo);
/* 133 */       if (this.ifTrueNullStatus != -1) {
/* 134 */         this.nullStatus = this.ifTrueNullStatus;
/*     */       } else {
/* 136 */         this.nullStatus = this.valueIfTrue.nullStatus(trueFlowInfo, flowContext);
/*     */       } 
/* 138 */     } else if (isConditionOptimizedFalse) {
/* 139 */       mergedInfo = falseFlowInfo.addPotentialInitializationsFrom(trueFlowInfo);
/* 140 */       this.nullStatus = this.valueIfFalse.nullStatus(falseFlowInfo, flowContext);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     }
/*     */     else {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 153 */       computeNullStatus(trueFlowInfo, falseFlowInfo, flowContext);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 161 */       cst = this.optimizedIfTrueConstant;
/* 162 */       boolean isValueIfTrueOptimizedTrue = (cst != null && cst != Constant.NotAConstant && cst.booleanValue());
/* 163 */       boolean isValueIfTrueOptimizedFalse = (cst != null && cst != Constant.NotAConstant && !cst.booleanValue());
/*     */       
/* 165 */       cst = this.optimizedIfFalseConstant;
/* 166 */       boolean isValueIfFalseOptimizedTrue = (cst != null && cst != Constant.NotAConstant && cst.booleanValue());
/* 167 */       boolean isValueIfFalseOptimizedFalse = (cst != null && cst != Constant.NotAConstant && !cst.booleanValue());
/*     */       
/* 169 */       UnconditionalFlowInfo trueFlowTowardsTrue = trueFlowInfo.initsWhenTrue().unconditionalCopy();
/* 170 */       UnconditionalFlowInfo falseFlowTowardsTrue = falseFlowInfo.initsWhenTrue().unconditionalCopy();
/* 171 */       UnconditionalFlowInfo trueFlowTowardsFalse = trueFlowInfo.initsWhenFalse().unconditionalInits();
/* 172 */       UnconditionalFlowInfo falseFlowTowardsFalse = falseFlowInfo.initsWhenFalse().unconditionalInits();
/* 173 */       if (isValueIfTrueOptimizedFalse) {
/* 174 */         trueFlowTowardsTrue.setReachMode(1);
/*     */       }
/* 176 */       if (isValueIfFalseOptimizedFalse) {
/* 177 */         falseFlowTowardsTrue.setReachMode(1);
/*     */       }
/* 179 */       if (isValueIfTrueOptimizedTrue) {
/* 180 */         trueFlowTowardsFalse.setReachMode(1);
/*     */       }
/* 182 */       if (isValueIfFalseOptimizedTrue) {
/* 183 */         falseFlowTowardsFalse.setReachMode(1);
/*     */       }
/* 185 */       mergedInfo = 
/* 186 */         FlowInfo.conditional(
/* 187 */           (FlowInfo)trueFlowTowardsTrue.mergedWith(falseFlowTowardsTrue), 
/* 188 */           (FlowInfo)trueFlowTowardsFalse.mergedWith(falseFlowTowardsFalse));
/*     */     } 
/* 190 */     this.mergedInitStateIndex = 
/* 191 */       currentScope.methodScope().recordInitializationStates(mergedInfo);
/* 192 */     mergedInfo.setReachMode(mode);
/*     */     
/* 194 */     return mergedInfo;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean checkNPE(BlockScope scope, FlowContext flowContext, FlowInfo flowInfo, int ttlForFieldCheck) {
/* 199 */     if ((this.nullStatus & 0x2) != 0) {
/* 200 */       scope.problemReporter().expressionNullReference(this);
/* 201 */     } else if ((this.nullStatus & 0x10) != 0) {
/* 202 */       scope.problemReporter().expressionPotentialNullReference(this);
/* 203 */     }  return true;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void computeNullStatus(FlowInfo trueBranchInfo, FlowInfo falseBranchInfo, FlowContext flowContext) {
/* 209 */     if (this.ifTrueNullStatus == -1) {
/* 210 */       this.ifTrueNullStatus = this.valueIfTrue.nullStatus(trueBranchInfo, flowContext);
/*     */     }
/* 212 */     this.ifFalseNullStatus = this.valueIfFalse.nullStatus(falseBranchInfo, flowContext);
/*     */     
/* 214 */     if (this.ifTrueNullStatus == this.ifFalseNullStatus) {
/* 215 */       this.nullStatus = this.ifTrueNullStatus;
/*     */       return;
/*     */     } 
/* 218 */     if (trueBranchInfo.reachMode() != 0) {
/* 219 */       this.nullStatus = this.ifFalseNullStatus;
/*     */       return;
/*     */     } 
/* 222 */     if (falseBranchInfo.reachMode() != 0) {
/* 223 */       this.nullStatus = this.ifTrueNullStatus;
/*     */ 
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/* 229 */     int combinedStatus = this.ifTrueNullStatus | this.ifFalseNullStatus;
/* 230 */     int status = Expression.computeNullStatus(0, combinedStatus);
/* 231 */     if (status > 0) {
/* 232 */       this.nullStatus = status;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void generateCode(BlockScope currentScope, CodeStream codeStream, boolean valueRequired) {
/* 248 */     int pc = codeStream.position;
/*     */     
/* 250 */     if (this.constant != Constant.NotAConstant) {
/* 251 */       if (valueRequired)
/* 252 */         codeStream.generateConstant(this.constant, this.implicitConversion); 
/* 253 */       codeStream.recordPositionsFrom(pc, this.sourceStart);
/*     */       return;
/*     */     } 
/* 256 */     Constant cst = this.condition.optimizedBooleanConstant();
/* 257 */     if (cst == Constant.NotAConstant) {
/* 258 */       cst = this.condition.optimizedNullComparisonConstant();
/*     */     }
/* 260 */     boolean needTruePart = !(cst != Constant.NotAConstant && !cst.booleanValue());
/* 261 */     boolean needFalsePart = !(cst != Constant.NotAConstant && cst.booleanValue());
/*     */     
/* 263 */     BranchLabel endifLabel = new BranchLabel(codeStream);
/*     */ 
/*     */     
/* 266 */     BranchLabel falseLabel = new BranchLabel(codeStream);
/* 267 */     falseLabel.tagBits |= 0x2;
/* 268 */     this.condition.generateOptimizedBoolean(
/* 269 */         currentScope, 
/* 270 */         codeStream, 
/* 271 */         (BranchLabel)null, 
/* 272 */         falseLabel, 
/* 273 */         (cst == Constant.NotAConstant));
/*     */     
/* 275 */     if (this.trueInitStateIndex != -1) {
/* 276 */       codeStream.removeNotDefinitelyAssignedVariables(
/* 277 */           (Scope)currentScope, 
/* 278 */           this.trueInitStateIndex);
/* 279 */       codeStream.addDefinitelyAssignedVariables((Scope)currentScope, this.trueInitStateIndex);
/*     */     } 
/*     */     
/* 282 */     if (needTruePart) {
/* 283 */       this.valueIfTrue.generateCode(currentScope, codeStream, valueRequired);
/* 284 */       if (needFalsePart) {
/*     */         
/* 286 */         int position = codeStream.position;
/* 287 */         codeStream.goto_(endifLabel);
/* 288 */         codeStream.recordPositionsFrom(position, this.valueIfTrue.sourceEnd);
/*     */         
/* 290 */         if (valueRequired) {
/* 291 */           switch (this.resolvedType.id) {
/*     */             case 7:
/*     */             case 8:
/* 294 */               codeStream.decrStackSize(2);
/*     */               break;
/*     */             default:
/* 297 */               codeStream.decrStackSize(1);
/*     */               break;
/*     */           } 
/*     */         }
/*     */       } 
/*     */     } 
/* 303 */     if (needFalsePart) {
/* 304 */       if (this.falseInitStateIndex != -1) {
/* 305 */         codeStream.removeNotDefinitelyAssignedVariables(
/* 306 */             (Scope)currentScope, 
/* 307 */             this.falseInitStateIndex);
/* 308 */         codeStream.addDefinitelyAssignedVariables((Scope)currentScope, this.falseInitStateIndex);
/*     */       } 
/* 310 */       if (falseLabel.forwardReferenceCount() > 0) {
/* 311 */         falseLabel.place();
/*     */       }
/* 313 */       this.valueIfFalse.generateCode(currentScope, codeStream, valueRequired);
/* 314 */       if (valueRequired) {
/* 315 */         codeStream.recordExpressionType(this.resolvedType);
/*     */       }
/* 317 */       if (needTruePart)
/*     */       {
/* 319 */         endifLabel.place();
/*     */       }
/*     */     } 
/*     */     
/* 323 */     if (this.mergedInitStateIndex != -1) {
/* 324 */       codeStream.removeNotDefinitelyAssignedVariables(
/* 325 */           (Scope)currentScope, 
/* 326 */           this.mergedInitStateIndex);
/*     */     }
/*     */     
/* 329 */     if (valueRequired)
/* 330 */       codeStream.generateImplicitConversion(this.implicitConversion); 
/* 331 */     codeStream.recordPositionsFrom(pc, this.sourceStart);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void generateOptimizedBoolean(BlockScope currentScope, CodeStream codeStream, BranchLabel trueLabel, BranchLabel falseLabel, boolean valueRequired) {
/*     */     // Byte code:
/*     */     //   0: aload_2
/*     */     //   1: getfield position : I
/*     */     //   4: istore #6
/*     */     //   6: aload_0
/*     */     //   7: getfield constant : Lorg/eclipse/jdt/internal/compiler/impl/Constant;
/*     */     //   10: getstatic org/eclipse/jdt/internal/compiler/impl/Constant.NotAConstant : Lorg/eclipse/jdt/internal/compiler/impl/Constant;
/*     */     //   13: if_acmpeq -> 27
/*     */     //   16: aload_0
/*     */     //   17: getfield constant : Lorg/eclipse/jdt/internal/compiler/impl/Constant;
/*     */     //   20: invokevirtual typeID : ()I
/*     */     //   23: iconst_5
/*     */     //   24: if_icmpeq -> 61
/*     */     //   27: aload_0
/*     */     //   28: getfield valueIfTrue : Lorg/eclipse/jdt/internal/compiler/ast/Expression;
/*     */     //   31: getfield implicitConversion : I
/*     */     //   34: sipush #255
/*     */     //   37: iand
/*     */     //   38: iconst_4
/*     */     //   39: ishr
/*     */     //   40: iconst_5
/*     */     //   41: if_icmpne -> 61
/*     */     //   44: aload_0
/*     */     //   45: getfield valueIfFalse : Lorg/eclipse/jdt/internal/compiler/ast/Expression;
/*     */     //   48: getfield implicitConversion : I
/*     */     //   51: sipush #255
/*     */     //   54: iand
/*     */     //   55: iconst_4
/*     */     //   56: ishr
/*     */     //   57: iconst_5
/*     */     //   58: if_icmpeq -> 73
/*     */     //   61: aload_0
/*     */     //   62: aload_1
/*     */     //   63: aload_2
/*     */     //   64: aload_3
/*     */     //   65: aload #4
/*     */     //   67: iload #5
/*     */     //   69: invokespecial generateOptimizedBoolean : (Lorg/eclipse/jdt/internal/compiler/lookup/BlockScope;Lorg/eclipse/jdt/internal/compiler/codegen/CodeStream;Lorg/eclipse/jdt/internal/compiler/codegen/BranchLabel;Lorg/eclipse/jdt/internal/compiler/codegen/BranchLabel;Z)V
/*     */     //   72: return
/*     */     //   73: aload_0
/*     */     //   74: getfield condition : Lorg/eclipse/jdt/internal/compiler/ast/Expression;
/*     */     //   77: getfield constant : Lorg/eclipse/jdt/internal/compiler/impl/Constant;
/*     */     //   80: astore #7
/*     */     //   82: aload_0
/*     */     //   83: getfield condition : Lorg/eclipse/jdt/internal/compiler/ast/Expression;
/*     */     //   86: invokevirtual optimizedBooleanConstant : ()Lorg/eclipse/jdt/internal/compiler/impl/Constant;
/*     */     //   89: astore #8
/*     */     //   91: aload #7
/*     */     //   93: getstatic org/eclipse/jdt/internal/compiler/impl/Constant.NotAConstant : Lorg/eclipse/jdt/internal/compiler/impl/Constant;
/*     */     //   96: if_acmpeq -> 107
/*     */     //   99: aload #7
/*     */     //   101: invokevirtual booleanValue : ()Z
/*     */     //   104: ifeq -> 123
/*     */     //   107: aload #8
/*     */     //   109: getstatic org/eclipse/jdt/internal/compiler/impl/Constant.NotAConstant : Lorg/eclipse/jdt/internal/compiler/impl/Constant;
/*     */     //   112: if_acmpeq -> 127
/*     */     //   115: aload #8
/*     */     //   117: invokevirtual booleanValue : ()Z
/*     */     //   120: ifne -> 127
/*     */     //   123: iconst_0
/*     */     //   124: goto -> 128
/*     */     //   127: iconst_1
/*     */     //   128: istore #9
/*     */     //   130: aload #7
/*     */     //   132: getstatic org/eclipse/jdt/internal/compiler/impl/Constant.NotAConstant : Lorg/eclipse/jdt/internal/compiler/impl/Constant;
/*     */     //   135: if_acmpeq -> 146
/*     */     //   138: aload #7
/*     */     //   140: invokevirtual booleanValue : ()Z
/*     */     //   143: ifne -> 162
/*     */     //   146: aload #8
/*     */     //   148: getstatic org/eclipse/jdt/internal/compiler/impl/Constant.NotAConstant : Lorg/eclipse/jdt/internal/compiler/impl/Constant;
/*     */     //   151: if_acmpeq -> 166
/*     */     //   154: aload #8
/*     */     //   156: invokevirtual booleanValue : ()Z
/*     */     //   159: ifeq -> 166
/*     */     //   162: iconst_0
/*     */     //   163: goto -> 167
/*     */     //   166: iconst_1
/*     */     //   167: istore #10
/*     */     //   169: new org/eclipse/jdt/internal/compiler/codegen/BranchLabel
/*     */     //   172: dup
/*     */     //   173: aload_2
/*     */     //   174: invokespecial <init> : (Lorg/eclipse/jdt/internal/compiler/codegen/CodeStream;)V
/*     */     //   177: astore #12
/*     */     //   179: aload #7
/*     */     //   181: getstatic org/eclipse/jdt/internal/compiler/impl/Constant.NotAConstant : Lorg/eclipse/jdt/internal/compiler/impl/Constant;
/*     */     //   184: if_acmpne -> 199
/*     */     //   187: aload #8
/*     */     //   189: getstatic org/eclipse/jdt/internal/compiler/impl/Constant.NotAConstant : Lorg/eclipse/jdt/internal/compiler/impl/Constant;
/*     */     //   192: if_acmpne -> 199
/*     */     //   195: iconst_1
/*     */     //   196: goto -> 200
/*     */     //   199: iconst_0
/*     */     //   200: istore #13
/*     */     //   202: aload_0
/*     */     //   203: getfield condition : Lorg/eclipse/jdt/internal/compiler/ast/Expression;
/*     */     //   206: aload_1
/*     */     //   207: aload_2
/*     */     //   208: aconst_null
/*     */     //   209: new org/eclipse/jdt/internal/compiler/codegen/BranchLabel
/*     */     //   212: dup
/*     */     //   213: aload_2
/*     */     //   214: invokespecial <init> : (Lorg/eclipse/jdt/internal/compiler/codegen/CodeStream;)V
/*     */     //   217: dup
/*     */     //   218: astore #11
/*     */     //   220: iload #13
/*     */     //   222: invokevirtual generateOptimizedBoolean : (Lorg/eclipse/jdt/internal/compiler/lookup/BlockScope;Lorg/eclipse/jdt/internal/compiler/codegen/CodeStream;Lorg/eclipse/jdt/internal/compiler/codegen/BranchLabel;Lorg/eclipse/jdt/internal/compiler/codegen/BranchLabel;Z)V
/*     */     //   225: aload_0
/*     */     //   226: getfield trueInitStateIndex : I
/*     */     //   229: iconst_m1
/*     */     //   230: if_icmpeq -> 251
/*     */     //   233: aload_2
/*     */     //   234: aload_1
/*     */     //   235: aload_0
/*     */     //   236: getfield trueInitStateIndex : I
/*     */     //   239: invokevirtual removeNotDefinitelyAssignedVariables : (Lorg/eclipse/jdt/internal/compiler/lookup/Scope;I)V
/*     */     //   242: aload_2
/*     */     //   243: aload_1
/*     */     //   244: aload_0
/*     */     //   245: getfield trueInitStateIndex : I
/*     */     //   248: invokevirtual addDefinitelyAssignedVariables : (Lorg/eclipse/jdt/internal/compiler/lookup/Scope;I)V
/*     */     //   251: iload #9
/*     */     //   253: ifeq -> 397
/*     */     //   256: aload_0
/*     */     //   257: getfield valueIfTrue : Lorg/eclipse/jdt/internal/compiler/ast/Expression;
/*     */     //   260: aload_1
/*     */     //   261: aload_2
/*     */     //   262: aload_3
/*     */     //   263: aload #4
/*     */     //   265: iload #5
/*     */     //   267: invokevirtual generateOptimizedBoolean : (Lorg/eclipse/jdt/internal/compiler/lookup/BlockScope;Lorg/eclipse/jdt/internal/compiler/codegen/CodeStream;Lorg/eclipse/jdt/internal/compiler/codegen/BranchLabel;Lorg/eclipse/jdt/internal/compiler/codegen/BranchLabel;Z)V
/*     */     //   270: iload #10
/*     */     //   272: ifeq -> 397
/*     */     //   275: aload #4
/*     */     //   277: ifnonnull -> 326
/*     */     //   280: aload_3
/*     */     //   281: ifnull -> 372
/*     */     //   284: aload_0
/*     */     //   285: getfield optimizedIfTrueConstant : Lorg/eclipse/jdt/internal/compiler/impl/Constant;
/*     */     //   288: astore #7
/*     */     //   290: aload #7
/*     */     //   292: ifnull -> 315
/*     */     //   295: aload #7
/*     */     //   297: getstatic org/eclipse/jdt/internal/compiler/impl/Constant.NotAConstant : Lorg/eclipse/jdt/internal/compiler/impl/Constant;
/*     */     //   300: if_acmpeq -> 315
/*     */     //   303: aload #7
/*     */     //   305: invokevirtual booleanValue : ()Z
/*     */     //   308: ifeq -> 315
/*     */     //   311: iconst_1
/*     */     //   312: goto -> 316
/*     */     //   315: iconst_0
/*     */     //   316: istore #14
/*     */     //   318: iload #14
/*     */     //   320: ifeq -> 372
/*     */     //   323: goto -> 397
/*     */     //   326: aload_3
/*     */     //   327: ifnonnull -> 372
/*     */     //   330: aload_0
/*     */     //   331: getfield optimizedIfTrueConstant : Lorg/eclipse/jdt/internal/compiler/impl/Constant;
/*     */     //   334: astore #7
/*     */     //   336: aload #7
/*     */     //   338: ifnull -> 361
/*     */     //   341: aload #7
/*     */     //   343: getstatic org/eclipse/jdt/internal/compiler/impl/Constant.NotAConstant : Lorg/eclipse/jdt/internal/compiler/impl/Constant;
/*     */     //   346: if_acmpeq -> 361
/*     */     //   349: aload #7
/*     */     //   351: invokevirtual booleanValue : ()Z
/*     */     //   354: ifne -> 361
/*     */     //   357: iconst_1
/*     */     //   358: goto -> 362
/*     */     //   361: iconst_0
/*     */     //   362: istore #14
/*     */     //   364: iload #14
/*     */     //   366: ifeq -> 372
/*     */     //   369: goto -> 397
/*     */     //   372: aload_2
/*     */     //   373: getfield position : I
/*     */     //   376: istore #14
/*     */     //   378: aload_2
/*     */     //   379: aload #12
/*     */     //   381: invokevirtual goto_ : (Lorg/eclipse/jdt/internal/compiler/codegen/BranchLabel;)V
/*     */     //   384: aload_2
/*     */     //   385: iload #14
/*     */     //   387: aload_0
/*     */     //   388: getfield valueIfTrue : Lorg/eclipse/jdt/internal/compiler/ast/Expression;
/*     */     //   391: getfield sourceEnd : I
/*     */     //   394: invokevirtual recordPositionsFrom : (II)V
/*     */     //   397: iload #10
/*     */     //   399: ifeq -> 452
/*     */     //   402: aload #11
/*     */     //   404: invokevirtual place : ()V
/*     */     //   407: aload_0
/*     */     //   408: getfield falseInitStateIndex : I
/*     */     //   411: iconst_m1
/*     */     //   412: if_icmpeq -> 433
/*     */     //   415: aload_2
/*     */     //   416: aload_1
/*     */     //   417: aload_0
/*     */     //   418: getfield falseInitStateIndex : I
/*     */     //   421: invokevirtual removeNotDefinitelyAssignedVariables : (Lorg/eclipse/jdt/internal/compiler/lookup/Scope;I)V
/*     */     //   424: aload_2
/*     */     //   425: aload_1
/*     */     //   426: aload_0
/*     */     //   427: getfield falseInitStateIndex : I
/*     */     //   430: invokevirtual addDefinitelyAssignedVariables : (Lorg/eclipse/jdt/internal/compiler/lookup/Scope;I)V
/*     */     //   433: aload_0
/*     */     //   434: getfield valueIfFalse : Lorg/eclipse/jdt/internal/compiler/ast/Expression;
/*     */     //   437: aload_1
/*     */     //   438: aload_2
/*     */     //   439: aload_3
/*     */     //   440: aload #4
/*     */     //   442: iload #5
/*     */     //   444: invokevirtual generateOptimizedBoolean : (Lorg/eclipse/jdt/internal/compiler/lookup/BlockScope;Lorg/eclipse/jdt/internal/compiler/codegen/CodeStream;Lorg/eclipse/jdt/internal/compiler/codegen/BranchLabel;Lorg/eclipse/jdt/internal/compiler/codegen/BranchLabel;Z)V
/*     */     //   447: aload #12
/*     */     //   449: invokevirtual place : ()V
/*     */     //   452: aload_0
/*     */     //   453: getfield mergedInitStateIndex : I
/*     */     //   456: iconst_m1
/*     */     //   457: if_icmpeq -> 469
/*     */     //   460: aload_2
/*     */     //   461: aload_1
/*     */     //   462: aload_0
/*     */     //   463: getfield mergedInitStateIndex : I
/*     */     //   466: invokevirtual removeNotDefinitelyAssignedVariables : (Lorg/eclipse/jdt/internal/compiler/lookup/Scope;I)V
/*     */     //   469: aload_2
/*     */     //   470: iload #6
/*     */     //   472: aload_0
/*     */     //   473: getfield sourceEnd : I
/*     */     //   476: invokevirtual recordPositionsFrom : (II)V
/*     */     //   479: return
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #345	-> 0
/*     */     //   #347	-> 6
/*     */     //   #348	-> 27
/*     */     //   #349	-> 44
/*     */     //   #350	-> 61
/*     */     //   #351	-> 72
/*     */     //   #353	-> 73
/*     */     //   #354	-> 82
/*     */     //   #356	-> 91
/*     */     //   #357	-> 107
/*     */     //   #356	-> 123
/*     */     //   #355	-> 128
/*     */     //   #359	-> 130
/*     */     //   #360	-> 146
/*     */     //   #359	-> 162
/*     */     //   #358	-> 167
/*     */     //   #362	-> 169
/*     */     //   #365	-> 179
/*     */     //   #366	-> 202
/*     */     //   #367	-> 206
/*     */     //   #368	-> 207
/*     */     //   #369	-> 208
/*     */     //   #370	-> 209
/*     */     //   #371	-> 220
/*     */     //   #366	-> 222
/*     */     //   #373	-> 225
/*     */     //   #374	-> 233
/*     */     //   #375	-> 234
/*     */     //   #376	-> 235
/*     */     //   #374	-> 239
/*     */     //   #377	-> 242
/*     */     //   #380	-> 251
/*     */     //   #381	-> 256
/*     */     //   #383	-> 270
/*     */     //   #386	-> 275
/*     */     //   #387	-> 280
/*     */     //   #389	-> 284
/*     */     //   #390	-> 290
/*     */     //   #391	-> 318
/*     */     //   #395	-> 326
/*     */     //   #396	-> 330
/*     */     //   #397	-> 336
/*     */     //   #398	-> 364
/*     */     //   #403	-> 372
/*     */     //   #404	-> 378
/*     */     //   #405	-> 384
/*     */     //   #411	-> 397
/*     */     //   #412	-> 402
/*     */     //   #413	-> 407
/*     */     //   #414	-> 415
/*     */     //   #415	-> 424
/*     */     //   #417	-> 433
/*     */     //   #420	-> 447
/*     */     //   #423	-> 452
/*     */     //   #424	-> 460
/*     */     //   #427	-> 469
/*     */     //   #428	-> 479
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	descriptor
/*     */     //   0	480	0	this	Lorg/eclipse/jdt/internal/compiler/ast/ConditionalExpression;
/*     */     //   0	480	1	currentScope	Lorg/eclipse/jdt/internal/compiler/lookup/BlockScope;
/*     */     //   0	480	2	codeStream	Lorg/eclipse/jdt/internal/compiler/codegen/CodeStream;
/*     */     //   0	480	3	trueLabel	Lorg/eclipse/jdt/internal/compiler/codegen/BranchLabel;
/*     */     //   0	480	4	falseLabel	Lorg/eclipse/jdt/internal/compiler/codegen/BranchLabel;
/*     */     //   0	480	5	valueRequired	Z
/*     */     //   6	474	6	pc	I
/*     */     //   82	398	7	cst	Lorg/eclipse/jdt/internal/compiler/impl/Constant;
/*     */     //   91	389	8	condCst	Lorg/eclipse/jdt/internal/compiler/impl/Constant;
/*     */     //   130	350	9	needTruePart	Z
/*     */     //   169	311	10	needFalsePart	Z
/*     */     //   220	260	11	internalFalseLabel	Lorg/eclipse/jdt/internal/compiler/codegen/BranchLabel;
/*     */     //   179	301	12	endifLabel	Lorg/eclipse/jdt/internal/compiler/codegen/BranchLabel;
/*     */     //   202	278	13	needConditionValue	Z
/*     */     //   318	8	14	isValueIfTrueOptimizedTrue	Z
/*     */     //   364	8	14	isValueIfTrueOptimizedFalse	Z
/*     */     //   378	19	14	position	I
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int nullStatus(FlowInfo flowInfo, FlowContext flowContext) {
/* 432 */     if ((this.implicitConversion & 0x200) != 0)
/* 433 */       return 4; 
/* 434 */     return this.nullStatus;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Constant optimizedBooleanConstant() {
/* 440 */     return (this.optimizedBooleanConstant == null) ? this.constant : this.optimizedBooleanConstant;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public StringBuffer printExpressionNoParenthesis(int indent, StringBuffer output) {
/* 446 */     this.condition.printExpression(indent, output).append(" ? ");
/* 447 */     this.valueIfTrue.printExpression(0, output).append(" : ");
/* 448 */     return this.valueIfFalse.printExpression(0, output);
/*     */   }
/*     */ 
/*     */   
/*     */   public void addPatternVariables(BlockScope scope, CodeStream codeStream) {
/* 453 */     this.condition.addPatternVariables(scope, codeStream);
/* 454 */     this.valueIfTrue.addPatternVariables(scope, codeStream);
/* 455 */     this.valueIfFalse.addPatternVariables(scope, codeStream);
/*     */   }
/*     */ 
/*     */   
/*     */   public void collectPatternVariablesToScope(LocalVariableBinding[] variables, BlockScope scope) {
/* 460 */     this.condition.collectPatternVariablesToScope(variables, scope);
/* 461 */     this.valueIfFalse.collectPatternVariablesToScope(variables, scope);
/* 462 */     this.valueIfTrue.collectPatternVariablesToScope(variables, scope);
/* 463 */     if (this.valueIfFalse.containsPatternVariable() && this.valueIfTrue.containsPatternVariable()) {
/* 464 */       LocalVariableBinding[] first = this.valueIfTrue.patternVarsWhenTrue;
/* 465 */       LocalVariableBinding[] second = this.valueIfFalse.patternVarsWhenTrue;
/* 466 */       if (first != null && second != null) {
/* 467 */         byte b; int i; LocalVariableBinding[] arrayOfLocalVariableBinding; for (i = (arrayOfLocalVariableBinding = first).length, b = 0; b < i; ) { LocalVariableBinding localVariableBinding = arrayOfLocalVariableBinding[b];
/* 468 */           char[] name = localVariableBinding.name; byte b1; int j; LocalVariableBinding[] arrayOfLocalVariableBinding1;
/* 469 */           for (j = (arrayOfLocalVariableBinding1 = second).length, b1 = 0; b1 < j; ) { LocalVariableBinding localVariableBinding2 = arrayOfLocalVariableBinding1[b1];
/* 470 */             if (CharOperation.equals(name, localVariableBinding2.name))
/* 471 */               scope.problemReporter().illegalRedeclarationOfPatternVar(localVariableBinding2, localVariableBinding2.declaration);  b1++; }
/*     */           
/*     */           b++; }
/*     */       
/*     */       } 
/* 476 */       first = this.valueIfTrue.patternVarsWhenFalse;
/* 477 */       second = this.valueIfFalse.patternVarsWhenFalse;
/* 478 */       if (first != null && second != null) {
/* 479 */         byte b; int i; LocalVariableBinding[] arrayOfLocalVariableBinding; for (i = (arrayOfLocalVariableBinding = first).length, b = 0; b < i; ) { LocalVariableBinding localVariableBinding = arrayOfLocalVariableBinding[b];
/* 480 */           char[] name = localVariableBinding.name; byte b1; int j; LocalVariableBinding[] arrayOfLocalVariableBinding1;
/* 481 */           for (j = (arrayOfLocalVariableBinding1 = second).length, b1 = 0; b1 < j; ) { LocalVariableBinding localVariableBinding2 = arrayOfLocalVariableBinding1[b1];
/* 482 */             if (CharOperation.equals(name, localVariableBinding2.name))
/* 483 */               scope.problemReporter().illegalRedeclarationOfPatternVar(localVariableBinding2, localVariableBinding2.declaration); 
/*     */             b1++; }
/*     */           
/*     */           b++; }
/*     */       
/*     */       } 
/*     */     } 
/* 490 */     if (!this.condition.containsPatternVariable()) {
/*     */       return;
/*     */     }
/* 493 */     if (this.condition.getPatternVariable() != null) {
/* 494 */       char[] name = (this.condition.getPatternVariable()).name;
/* 495 */       LocalDeclaration localVar = this.valueIfTrue.getPatternVariable();
/* 496 */       if (localVar != null && CharOperation.equals(name, localVar.name)) {
/* 497 */         scope.problemReporter().illegalRedeclarationOfPatternVar(localVar.binding, localVar);
/*     */         return;
/*     */       } 
/* 500 */       localVar = this.valueIfFalse.getPatternVariable();
/* 501 */       if (localVar != null && CharOperation.equals(name, localVar.name)) {
/* 502 */         scope.problemReporter().illegalRedeclarationOfPatternVar(localVar.binding, localVar);
/*     */         return;
/*     */       } 
/*     */     } 
/* 506 */     this.condition.collectPatternVariablesToScope(this.patternVarsWhenTrue, scope);
/*     */     
/* 508 */     variables = this.condition.getPatternVariablesWhenTrue();
/* 509 */     this.valueIfTrue.addPatternVariablesWhenTrue(variables);
/* 510 */     this.valueIfFalse.addPatternVariablesWhenFalse(variables);
/* 511 */     this.valueIfTrue.collectPatternVariablesToScope(variables, scope);
/*     */     
/* 513 */     variables = this.condition.getPatternVariablesWhenFalse();
/* 514 */     this.valueIfTrue.addPatternVariablesWhenFalse(variables);
/* 515 */     this.valueIfFalse.addPatternVariablesWhenTrue(variables);
/* 516 */     this.valueIfFalse.collectPatternVariablesToScope(variables, scope);
/*     */   }
/*     */ 
/*     */   
/*     */   public TypeBinding resolveType(BlockScope scope) {
/* 521 */     LookupEnvironment env = scope.environment();
/* 522 */     long sourceLevel = (scope.compilerOptions()).sourceLevel;
/* 523 */     boolean use15specifics = (sourceLevel >= 3211264L);
/* 524 */     this.use18specifics = (sourceLevel >= 3407872L);
/*     */     
/* 526 */     if (this.use18specifics && (
/* 527 */       this.expressionContext == ExpressionContext.ASSIGNMENT_CONTEXT || this.expressionContext == ExpressionContext.INVOCATION_CONTEXT)) {
/* 528 */       this.valueIfTrue.setExpressionContext(this.expressionContext);
/* 529 */       this.valueIfTrue.setExpectedType(this.expectedType);
/* 530 */       this.valueIfFalse.setExpressionContext(this.expressionContext);
/* 531 */       this.valueIfFalse.setExpectedType(this.expectedType);
/*     */     } 
/*     */ 
/*     */     
/* 535 */     collectPatternVariablesToScope((LocalVariableBinding[])null, scope);
/*     */     
/* 537 */     if (this.constant != Constant.NotAConstant) {
/* 538 */       this.constant = Constant.NotAConstant;
/* 539 */       TypeBinding conditionType = this.condition.resolveTypeExpecting(scope, (TypeBinding)TypeBinding.BOOLEAN);
/* 540 */       this.condition.computeConversion((Scope)scope, (TypeBinding)TypeBinding.BOOLEAN, conditionType);
/*     */       
/* 542 */       if (this.valueIfTrue instanceof CastExpression) this.valueIfTrue.bits |= 0x20; 
/* 543 */       this.originalValueIfTrueType = this.valueIfTrue.resolveType(scope);
/*     */       
/* 545 */       if (this.valueIfFalse instanceof CastExpression) this.valueIfFalse.bits |= 0x20; 
/* 546 */       this.originalValueIfFalseType = this.valueIfFalse.resolveType(scope);
/*     */       
/* 548 */       if (conditionType == null || this.originalValueIfTrueType == null || this.originalValueIfFalseType == null)
/* 549 */         return null; 
/*     */     } else {
/* 551 */       if (this.originalValueIfTrueType.kind() == 65540)
/* 552 */         this.originalValueIfTrueType = this.valueIfTrue.resolveType(scope); 
/* 553 */       if (this.originalValueIfFalseType.kind() == 65540) {
/* 554 */         this.originalValueIfFalseType = this.valueIfFalse.resolveType(scope);
/*     */       }
/* 556 */       if (this.originalValueIfTrueType == null || !this.originalValueIfTrueType.isValidBinding())
/* 557 */         return this.resolvedType = null; 
/* 558 */       if (this.originalValueIfFalseType == null || !this.originalValueIfFalseType.isValidBinding()) {
/* 559 */         return this.resolvedType = null;
/*     */       }
/*     */     } 
/*     */     Constant condConstant, trueConstant, falseConstant;
/* 563 */     if ((condConstant = this.condition.constant) != Constant.NotAConstant && (
/* 564 */       trueConstant = this.valueIfTrue.constant) != Constant.NotAConstant && (
/* 565 */       falseConstant = this.valueIfFalse.constant) != Constant.NotAConstant)
/*     */     {
/*     */       
/* 568 */       this.constant = condConstant.booleanValue() ? trueConstant : falseConstant;
/*     */     }
/* 570 */     if (isPolyExpression()) {
/* 571 */       if (this.expectedType == null || !this.expectedType.isProperType(true)) {
/*     */ 
/*     */         
/* 574 */         this.constant = Constant.NotAConstant;
/* 575 */         return (TypeBinding)new PolyTypeBinding(this);
/*     */       } 
/* 577 */       return this.resolvedType = computeConversions(scope, this.expectedType) ? this.expectedType : null;
/*     */     } 
/*     */     
/* 580 */     TypeBinding valueIfTrueType = this.originalValueIfTrueType;
/* 581 */     TypeBinding valueIfFalseType = this.originalValueIfFalseType;
/* 582 */     if (use15specifics && TypeBinding.notEquals(valueIfTrueType, valueIfFalseType)) {
/* 583 */       if (valueIfTrueType.isBaseType()) {
/* 584 */         if (valueIfFalseType.isBaseType()) {
/*     */           
/* 586 */           if (valueIfTrueType == TypeBinding.NULL) {
/* 587 */             valueIfFalseType = env.computeBoxingType(valueIfFalseType);
/* 588 */           } else if (valueIfFalseType == TypeBinding.NULL) {
/* 589 */             valueIfTrueType = env.computeBoxingType(valueIfTrueType);
/*     */           } 
/*     */         } else {
/*     */           
/* 593 */           TypeBinding unboxedIfFalseType = valueIfFalseType.isBaseType() ? valueIfFalseType : env.computeBoxingType(valueIfFalseType);
/* 594 */           if (valueIfTrueType.isNumericType() && unboxedIfFalseType.isNumericType()) {
/* 595 */             valueIfFalseType = unboxedIfFalseType;
/* 596 */           } else if (valueIfTrueType != TypeBinding.NULL) {
/* 597 */             valueIfFalseType = env.computeBoxingType(valueIfFalseType);
/*     */           } 
/*     */         } 
/* 600 */       } else if (valueIfFalseType.isBaseType()) {
/*     */         
/* 602 */         TypeBinding unboxedIfTrueType = valueIfTrueType.isBaseType() ? valueIfTrueType : env.computeBoxingType(valueIfTrueType);
/* 603 */         if (unboxedIfTrueType.isNumericType() && valueIfFalseType.isNumericType()) {
/* 604 */           valueIfTrueType = unboxedIfTrueType;
/* 605 */         } else if (valueIfFalseType != TypeBinding.NULL) {
/* 606 */           valueIfTrueType = env.computeBoxingType(valueIfTrueType);
/*     */         } 
/*     */       } else {
/*     */         
/* 610 */         TypeBinding unboxedIfTrueType = env.computeBoxingType(valueIfTrueType);
/* 611 */         TypeBinding unboxedIfFalseType = env.computeBoxingType(valueIfFalseType);
/* 612 */         if (unboxedIfTrueType.isNumericType() && unboxedIfFalseType.isNumericType()) {
/* 613 */           valueIfTrueType = unboxedIfTrueType;
/* 614 */           valueIfFalseType = unboxedIfFalseType;
/*     */         } 
/*     */       } 
/*     */     }
/* 618 */     if (TypeBinding.equalsEquals(valueIfTrueType, valueIfFalseType)) {
/* 619 */       this.valueIfTrue.computeConversion((Scope)scope, valueIfTrueType, this.originalValueIfTrueType);
/* 620 */       this.valueIfFalse.computeConversion((Scope)scope, valueIfFalseType, this.originalValueIfFalseType);
/* 621 */       if (TypeBinding.equalsEquals(valueIfTrueType, (TypeBinding)TypeBinding.BOOLEAN)) {
/* 622 */         this.optimizedIfTrueConstant = this.valueIfTrue.optimizedBooleanConstant();
/* 623 */         this.optimizedIfFalseConstant = this.valueIfFalse.optimizedBooleanConstant();
/* 624 */         if (this.optimizedIfTrueConstant != Constant.NotAConstant && 
/* 625 */           this.optimizedIfFalseConstant != Constant.NotAConstant && 
/* 626 */           this.optimizedIfTrueConstant.booleanValue() == this.optimizedIfFalseConstant.booleanValue()) {
/*     */           
/* 628 */           this.optimizedBooleanConstant = this.optimizedIfTrueConstant;
/* 629 */         } else if ((condConstant = this.condition.optimizedBooleanConstant()) != Constant.NotAConstant) {
/* 630 */           this.optimizedBooleanConstant = condConstant.booleanValue() ? 
/* 631 */             this.optimizedIfTrueConstant : 
/* 632 */             this.optimizedIfFalseConstant;
/*     */         } 
/*     */       } 
/* 635 */       return this.resolvedType = NullAnnotationMatching.moreDangerousType(valueIfTrueType, valueIfFalseType);
/*     */     } 
/*     */ 
/*     */     
/* 639 */     if (valueIfTrueType.isNumericType() && valueIfFalseType.isNumericType()) {
/*     */       
/* 641 */       if ((TypeBinding.equalsEquals(valueIfTrueType, (TypeBinding)TypeBinding.BYTE) && TypeBinding.equalsEquals(valueIfFalseType, (TypeBinding)TypeBinding.SHORT)) || (
/* 642 */         TypeBinding.equalsEquals(valueIfTrueType, (TypeBinding)TypeBinding.SHORT) && TypeBinding.equalsEquals(valueIfFalseType, (TypeBinding)TypeBinding.BYTE))) {
/* 643 */         this.valueIfTrue.computeConversion((Scope)scope, (TypeBinding)TypeBinding.SHORT, this.originalValueIfTrueType);
/* 644 */         this.valueIfFalse.computeConversion((Scope)scope, (TypeBinding)TypeBinding.SHORT, this.originalValueIfFalseType);
/* 645 */         return this.resolvedType = (TypeBinding)TypeBinding.SHORT;
/*     */       } 
/*     */       
/* 648 */       if ((TypeBinding.equalsEquals(valueIfTrueType, (TypeBinding)TypeBinding.BYTE) || TypeBinding.equalsEquals(valueIfTrueType, (TypeBinding)TypeBinding.SHORT) || TypeBinding.equalsEquals(valueIfTrueType, (TypeBinding)TypeBinding.CHAR)) && 
/* 649 */         TypeBinding.equalsEquals(valueIfFalseType, (TypeBinding)TypeBinding.INT) && 
/* 650 */         this.valueIfFalse.isConstantValueOfTypeAssignableToType(valueIfFalseType, valueIfTrueType)) {
/* 651 */         this.valueIfTrue.computeConversion((Scope)scope, valueIfTrueType, this.originalValueIfTrueType);
/* 652 */         this.valueIfFalse.computeConversion((Scope)scope, valueIfTrueType, this.originalValueIfFalseType);
/* 653 */         return this.resolvedType = valueIfTrueType;
/*     */       } 
/* 655 */       if ((TypeBinding.equalsEquals(valueIfFalseType, (TypeBinding)TypeBinding.BYTE) || 
/* 656 */         TypeBinding.equalsEquals(valueIfFalseType, (TypeBinding)TypeBinding.SHORT) || 
/* 657 */         TypeBinding.equalsEquals(valueIfFalseType, (TypeBinding)TypeBinding.CHAR)) && 
/* 658 */         TypeBinding.equalsEquals(valueIfTrueType, (TypeBinding)TypeBinding.INT) && 
/* 659 */         this.valueIfTrue.isConstantValueOfTypeAssignableToType(valueIfTrueType, valueIfFalseType)) {
/* 660 */         this.valueIfTrue.computeConversion((Scope)scope, valueIfFalseType, this.originalValueIfTrueType);
/* 661 */         this.valueIfFalse.computeConversion((Scope)scope, valueIfFalseType, this.originalValueIfFalseType);
/* 662 */         return this.resolvedType = valueIfFalseType;
/*     */       } 
/*     */ 
/*     */       
/* 666 */       if (BaseTypeBinding.isNarrowing(valueIfTrueType.id, 10) && 
/* 667 */         BaseTypeBinding.isNarrowing(valueIfFalseType.id, 10)) {
/* 668 */         this.valueIfTrue.computeConversion((Scope)scope, (TypeBinding)TypeBinding.INT, this.originalValueIfTrueType);
/* 669 */         this.valueIfFalse.computeConversion((Scope)scope, (TypeBinding)TypeBinding.INT, this.originalValueIfFalseType);
/* 670 */         return this.resolvedType = (TypeBinding)TypeBinding.INT;
/*     */       } 
/*     */       
/* 673 */       if (BaseTypeBinding.isNarrowing(valueIfTrueType.id, 7) && 
/* 674 */         BaseTypeBinding.isNarrowing(valueIfFalseType.id, 7)) {
/* 675 */         this.valueIfTrue.computeConversion((Scope)scope, (TypeBinding)TypeBinding.LONG, this.originalValueIfTrueType);
/* 676 */         this.valueIfFalse.computeConversion((Scope)scope, (TypeBinding)TypeBinding.LONG, this.originalValueIfFalseType);
/* 677 */         return this.resolvedType = (TypeBinding)TypeBinding.LONG;
/*     */       } 
/*     */       
/* 680 */       if (BaseTypeBinding.isNarrowing(valueIfTrueType.id, 9) && 
/* 681 */         BaseTypeBinding.isNarrowing(valueIfFalseType.id, 9)) {
/* 682 */         this.valueIfTrue.computeConversion((Scope)scope, (TypeBinding)TypeBinding.FLOAT, this.originalValueIfTrueType);
/* 683 */         this.valueIfFalse.computeConversion((Scope)scope, (TypeBinding)TypeBinding.FLOAT, this.originalValueIfFalseType);
/* 684 */         return this.resolvedType = (TypeBinding)TypeBinding.FLOAT;
/*     */       } 
/*     */       
/* 687 */       this.valueIfTrue.computeConversion((Scope)scope, (TypeBinding)TypeBinding.DOUBLE, this.originalValueIfTrueType);
/* 688 */       this.valueIfFalse.computeConversion((Scope)scope, (TypeBinding)TypeBinding.DOUBLE, this.originalValueIfFalseType);
/* 689 */       return this.resolvedType = (TypeBinding)TypeBinding.DOUBLE;
/*     */     } 
/*     */     
/* 692 */     if (valueIfTrueType.isBaseType() && valueIfTrueType != TypeBinding.NULL) {
/* 693 */       if (use15specifics) {
/* 694 */         valueIfTrueType = env.computeBoxingType(valueIfTrueType);
/*     */       } else {
/* 696 */         scope.problemReporter().conditionalArgumentsIncompatibleTypes(this, valueIfTrueType, valueIfFalseType);
/* 697 */         return null;
/*     */       } 
/*     */     }
/* 700 */     if (valueIfFalseType.isBaseType() && valueIfFalseType != TypeBinding.NULL) {
/* 701 */       if (use15specifics) {
/* 702 */         valueIfFalseType = env.computeBoxingType(valueIfFalseType);
/*     */       } else {
/* 704 */         scope.problemReporter().conditionalArgumentsIncompatibleTypes(this, valueIfTrueType, valueIfFalseType);
/* 705 */         return null;
/*     */       } 
/*     */     }
/* 708 */     if (use15specifics) {
/*     */       
/* 710 */       TypeBinding commonType = null;
/* 711 */       if (valueIfTrueType == TypeBinding.NULL) {
/* 712 */         commonType = valueIfFalseType.withoutToplevelNullAnnotation();
/* 713 */       } else if (valueIfFalseType == TypeBinding.NULL) {
/* 714 */         commonType = valueIfTrueType.withoutToplevelNullAnnotation();
/*     */       } else {
/* 716 */         commonType = scope.lowerUpperBound(new TypeBinding[] { valueIfTrueType, valueIfFalseType });
/*     */       } 
/* 718 */       if (commonType != null) {
/* 719 */         this.valueIfTrue.computeConversion((Scope)scope, commonType, this.originalValueIfTrueType);
/* 720 */         this.valueIfFalse.computeConversion((Scope)scope, commonType, this.originalValueIfFalseType);
/* 721 */         return this.resolvedType = commonType.capture((Scope)scope, this.sourceStart, this.sourceEnd);
/*     */       } 
/*     */     } else {
/*     */       
/* 725 */       if (valueIfFalseType.isCompatibleWith(valueIfTrueType)) {
/* 726 */         this.valueIfTrue.computeConversion((Scope)scope, valueIfTrueType, this.originalValueIfTrueType);
/* 727 */         this.valueIfFalse.computeConversion((Scope)scope, valueIfTrueType, this.originalValueIfFalseType);
/* 728 */         return this.resolvedType = valueIfTrueType;
/* 729 */       }  if (valueIfTrueType.isCompatibleWith(valueIfFalseType)) {
/* 730 */         this.valueIfTrue.computeConversion((Scope)scope, valueIfFalseType, this.originalValueIfTrueType);
/* 731 */         this.valueIfFalse.computeConversion((Scope)scope, valueIfFalseType, this.originalValueIfFalseType);
/* 732 */         return this.resolvedType = valueIfFalseType;
/*     */       } 
/*     */     } 
/* 735 */     scope.problemReporter().conditionalArgumentsIncompatibleTypes(
/* 736 */         this, 
/* 737 */         valueIfTrueType, 
/* 738 */         valueIfFalseType);
/* 739 */     return null;
/*     */   }
/*     */   
/*     */   protected boolean computeConversions(BlockScope scope, TypeBinding targetType) {
/* 743 */     boolean ok = true;
/* 744 */     if (this.originalValueIfTrueType != null && this.originalValueIfTrueType.isValidBinding()) {
/* 745 */       if (this.valueIfTrue.isConstantValueOfTypeAssignableToType(this.originalValueIfTrueType, targetType) || 
/* 746 */         this.originalValueIfTrueType.isCompatibleWith(targetType)) {
/*     */         
/* 748 */         this.valueIfTrue.computeConversion((Scope)scope, targetType, this.originalValueIfTrueType);
/* 749 */         if (this.originalValueIfTrueType.needsUncheckedConversion(targetType)) {
/* 750 */           scope.problemReporter().unsafeTypeConversion(this.valueIfTrue, this.originalValueIfTrueType, targetType);
/*     */         }
/* 752 */         if (this.valueIfTrue instanceof CastExpression && (
/* 753 */           this.valueIfTrue.bits & 0x4020) == 0) {
/* 754 */           CastExpression.checkNeedForAssignedCast(scope, targetType, (CastExpression)this.valueIfTrue);
/*     */         }
/* 756 */       } else if (isBoxingCompatible(this.originalValueIfTrueType, targetType, this.valueIfTrue, (Scope)scope)) {
/* 757 */         this.valueIfTrue.computeConversion((Scope)scope, targetType, this.originalValueIfTrueType);
/* 758 */         if (this.valueIfTrue instanceof CastExpression && (
/* 759 */           this.valueIfTrue.bits & 0x4020) == 0) {
/* 760 */           CastExpression.checkNeedForAssignedCast(scope, targetType, (CastExpression)this.valueIfTrue);
/*     */         }
/*     */       } else {
/* 763 */         scope.problemReporter().typeMismatchError(this.originalValueIfTrueType, targetType, this.valueIfTrue, null);
/* 764 */         ok = false;
/*     */       } 
/*     */     }
/* 767 */     if (this.originalValueIfFalseType != null && this.originalValueIfFalseType.isValidBinding()) {
/* 768 */       if (this.valueIfFalse.isConstantValueOfTypeAssignableToType(this.originalValueIfFalseType, targetType) || 
/* 769 */         this.originalValueIfFalseType.isCompatibleWith(targetType)) {
/*     */         
/* 771 */         this.valueIfFalse.computeConversion((Scope)scope, targetType, this.originalValueIfFalseType);
/* 772 */         if (this.originalValueIfFalseType.needsUncheckedConversion(targetType)) {
/* 773 */           scope.problemReporter().unsafeTypeConversion(this.valueIfFalse, this.originalValueIfFalseType, targetType);
/*     */         }
/* 775 */         if (this.valueIfFalse instanceof CastExpression && (
/* 776 */           this.valueIfFalse.bits & 0x4020) == 0) {
/* 777 */           CastExpression.checkNeedForAssignedCast(scope, targetType, (CastExpression)this.valueIfFalse);
/*     */         }
/* 779 */       } else if (isBoxingCompatible(this.originalValueIfFalseType, targetType, this.valueIfFalse, (Scope)scope)) {
/* 780 */         this.valueIfFalse.computeConversion((Scope)scope, targetType, this.originalValueIfFalseType);
/* 781 */         if (this.valueIfFalse instanceof CastExpression && (
/* 782 */           this.valueIfFalse.bits & 0x4020) == 0) {
/* 783 */           CastExpression.checkNeedForAssignedCast(scope, targetType, (CastExpression)this.valueIfFalse);
/*     */         }
/*     */       } else {
/* 786 */         scope.problemReporter().typeMismatchError(this.originalValueIfFalseType, targetType, this.valueIfFalse, null);
/* 787 */         ok = false;
/*     */       } 
/*     */     }
/* 790 */     return ok;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setExpectedType(TypeBinding expectedType) {
/* 795 */     this.expectedType = expectedType;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setExpressionContext(ExpressionContext context) {
/* 800 */     this.expressionContext = context;
/*     */   }
/*     */ 
/*     */   
/*     */   public ExpressionContext getExpressionContext() {
/* 805 */     return this.expressionContext;
/*     */   }
/*     */ 
/*     */   
/*     */   public Expression[] getPolyExpressions() {
/* 810 */     Expression[] truePolys = this.valueIfTrue.getPolyExpressions();
/* 811 */     Expression[] falsePolys = this.valueIfFalse.getPolyExpressions();
/* 812 */     if (truePolys.length == 0)
/* 813 */       return falsePolys; 
/* 814 */     if (falsePolys.length == 0)
/* 815 */       return truePolys; 
/* 816 */     Expression[] allPolys = new Expression[truePolys.length + falsePolys.length];
/* 817 */     System.arraycopy(truePolys, 0, allPolys, 0, truePolys.length);
/* 818 */     System.arraycopy(falsePolys, 0, allPolys, truePolys.length, falsePolys.length);
/* 819 */     return allPolys;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isPertinentToApplicability(TypeBinding targetType, MethodBinding method) {
/* 824 */     return (this.valueIfTrue.isPertinentToApplicability(targetType, method) && 
/* 825 */       this.valueIfFalse.isPertinentToApplicability(targetType, method));
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isPotentiallyCompatibleWith(TypeBinding targetType, Scope scope) {
/* 830 */     return (this.valueIfTrue.isPotentiallyCompatibleWith(targetType, scope) && 
/* 831 */       this.valueIfFalse.isPotentiallyCompatibleWith(targetType, scope));
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isFunctionalType() {
/* 836 */     return !(!this.valueIfTrue.isFunctionalType() && !this.valueIfFalse.isFunctionalType());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isPolyExpression() throws UnsupportedOperationException {
/* 842 */     if (!this.use18specifics) {
/* 843 */       return false;
/*     */     }
/* 845 */     if (this.isPolyExpression) {
/* 846 */       return true;
/*     */     }
/* 848 */     if (this.expressionContext != ExpressionContext.ASSIGNMENT_CONTEXT && this.expressionContext != ExpressionContext.INVOCATION_CONTEXT) {
/* 849 */       return false;
/*     */     }
/* 851 */     if (this.originalValueIfTrueType == null || this.originalValueIfFalseType == null) {
/* 852 */       return false;
/*     */     }
/* 854 */     if (this.valueIfTrue.isPolyExpression() || this.valueIfFalse.isPolyExpression()) {
/* 855 */       return true;
/*     */     }
/*     */     
/* 858 */     if ((this.originalValueIfTrueType.isBaseType() || (this.originalValueIfTrueType.id >= 26 && this.originalValueIfTrueType.id <= 33)) && (
/* 859 */       this.originalValueIfFalseType.isBaseType() || (this.originalValueIfFalseType.id >= 26 && this.originalValueIfFalseType.id <= 33))) {
/* 860 */       return false;
/*     */     }
/*     */ 
/*     */     
/* 864 */     return this.isPolyExpression = true;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isCompatibleWith(TypeBinding left, Scope scope) {
/* 869 */     return isPolyExpression() ? ((this.valueIfTrue.isCompatibleWith(left, scope) && this.valueIfFalse.isCompatibleWith(left, scope))) : 
/* 870 */       super.isCompatibleWith(left, scope);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isBoxingCompatibleWith(TypeBinding targetType, Scope scope) {
/* 876 */     return isPolyExpression() ? (((this.valueIfTrue.isCompatibleWith(targetType, scope) || 
/* 877 */       this.valueIfTrue.isBoxingCompatibleWith(targetType, scope)) && (
/* 878 */       this.valueIfFalse.isCompatibleWith(targetType, scope) || 
/* 879 */       this.valueIfFalse.isBoxingCompatibleWith(targetType, scope)))) : 
/* 880 */       super.isBoxingCompatibleWith(targetType, scope);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean sIsMoreSpecific(TypeBinding s, TypeBinding t, Scope scope) {
/* 885 */     if (super.sIsMoreSpecific(s, t, scope))
/* 886 */       return true; 
/* 887 */     return isPolyExpression() ? (
/* 888 */       (this.valueIfTrue.sIsMoreSpecific(s, t, scope) && this.valueIfFalse.sIsMoreSpecific(s, t, scope))) : false;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void traverse(ASTVisitor visitor, BlockScope scope) {
/* 894 */     if (visitor.visit(this, scope)) {
/* 895 */       this.condition.traverse(visitor, scope);
/* 896 */       this.valueIfTrue.traverse(visitor, scope);
/* 897 */       this.valueIfFalse.traverse(visitor, scope);
/*     */     } 
/* 899 */     visitor.endVisit(this, scope);
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\ast\ConditionalExpression.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */