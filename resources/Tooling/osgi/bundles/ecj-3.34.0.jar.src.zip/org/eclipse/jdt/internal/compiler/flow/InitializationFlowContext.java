/*     */ package org.eclipse.jdt.internal.compiler.flow;
/*     */ 
/*     */ import org.eclipse.jdt.internal.compiler.ast.ASTNode;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.Binding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.BlockScope;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.ReferenceBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.TypeBinding;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class InitializationFlowContext
/*     */   extends ExceptionHandlingFlowContext
/*     */ {
/*     */   public int exceptionCount;
/*  28 */   public TypeBinding[] thrownExceptions = new TypeBinding[5];
/*  29 */   public ASTNode[] exceptionThrowers = new ASTNode[5];
/*  30 */   public FlowInfo[] exceptionThrowerFlowInfos = new FlowInfo[5];
/*     */ 
/*     */ 
/*     */   
/*     */   public FlowInfo initsBeforeContext;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public InitializationFlowContext(FlowContext parent, ASTNode associatedNode, FlowInfo initsBeforeContext, FlowContext initializationParent, BlockScope scope) {
/*  40 */     super(parent, associatedNode, Binding.NO_EXCEPTIONS, initializationParent, scope, FlowInfo.DEAD_END);
/*  41 */     this.initsBeforeContext = initsBeforeContext;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void checkInitializerExceptions(BlockScope currentScope, FlowContext initializerContext, FlowInfo flowInfo) {
/*  48 */     for (int i = 0; i < this.exceptionCount; i++) {
/*  49 */       initializerContext.checkExceptionHandlers(
/*  50 */           this.thrownExceptions[i], 
/*  51 */           this.exceptionThrowers[i], 
/*  52 */           this.exceptionThrowerFlowInfos[i], 
/*  53 */           currentScope);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public FlowContext getInitializationContext() {
/*  59 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String individualToString() {
/*  65 */     StringBuilder buffer = new StringBuilder("Initialization flow context");
/*  66 */     for (int i = 0; i < this.exceptionCount; i++) {
/*  67 */       buffer.append('[').append(this.thrownExceptions[i].readableName());
/*  68 */       buffer.append('-').append(this.exceptionThrowerFlowInfos[i].toString()).append(']');
/*     */     } 
/*  70 */     return buffer.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void recordHandlingException(ReferenceBinding exceptionType, UnconditionalFlowInfo flowInfo, TypeBinding raisedException, TypeBinding caughtException, ASTNode invocationSite, boolean wasMasked) {
/*  83 */     int size = this.thrownExceptions.length;
/*  84 */     if (this.exceptionCount == size) {
/*  85 */       System.arraycopy(
/*  86 */           this.thrownExceptions, 
/*  87 */           0, 
/*  88 */           this.thrownExceptions = new TypeBinding[size * 2], 
/*  89 */           0, 
/*  90 */           size);
/*  91 */       System.arraycopy(
/*  92 */           this.exceptionThrowers, 
/*  93 */           0, 
/*  94 */           this.exceptionThrowers = new ASTNode[size * 2], 
/*  95 */           0, 
/*  96 */           size);
/*  97 */       System.arraycopy(
/*  98 */           this.exceptionThrowerFlowInfos, 
/*  99 */           0, 
/* 100 */           this.exceptionThrowerFlowInfos = new FlowInfo[size * 2], 
/* 101 */           0, 
/* 102 */           size);
/*     */     } 
/* 104 */     this.thrownExceptions[this.exceptionCount] = raisedException;
/* 105 */     this.exceptionThrowers[this.exceptionCount] = invocationSite;
/* 106 */     this.exceptionThrowerFlowInfos[this.exceptionCount++] = flowInfo.copy();
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\flow\InitializationFlowContext.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */