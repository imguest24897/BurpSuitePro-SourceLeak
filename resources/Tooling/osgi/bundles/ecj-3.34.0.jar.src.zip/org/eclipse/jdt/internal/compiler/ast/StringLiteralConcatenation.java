/*    */ package org.eclipse.jdt.internal.compiler.ast;
/*    */ 
/*    */ import org.eclipse.jdt.internal.compiler.ASTVisitor;
/*    */ import org.eclipse.jdt.internal.compiler.lookup.BlockScope;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class StringLiteralConcatenation
/*    */   extends StringLiteral
/*    */ {
/*    */   private static final int INITIAL_SIZE = 5;
/*    */   public Expression[] literals;
/*    */   public int counter;
/*    */   
/*    */   public StringLiteralConcatenation(StringLiteral str1, StringLiteral str2) {
/* 30 */     super(str1.sourceStart, str1.sourceEnd);
/* 31 */     this.source = str1.source;
/* 32 */     this.literals = (Expression[])new StringLiteral[5];
/* 33 */     this.counter = 0;
/* 34 */     this.literals[this.counter++] = str1;
/* 35 */     extendsWith(str2);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public StringLiteralConcatenation extendsWith(StringLiteral lit) {
/* 43 */     this.sourceEnd = lit.sourceEnd;
/* 44 */     int literalsLength = this.literals.length;
/* 45 */     if (this.counter == literalsLength)
/*    */     {
/* 47 */       System.arraycopy(this.literals, 0, this.literals = (Expression[])new StringLiteral[literalsLength + 5], 0, literalsLength);
/*    */     }
/*    */     
/* 50 */     int length = this.source.length;
/* 51 */     System.arraycopy(
/* 52 */         this.source, 
/* 53 */         0, 
/* 54 */         this.source = new char[length + lit.source.length], 
/* 55 */         0, 
/* 56 */         length);
/* 57 */     System.arraycopy(lit.source, 0, this.source, length, lit.source.length);
/* 58 */     this.literals[this.counter++] = lit;
/* 59 */     return this;
/*    */   }
/*    */ 
/*    */   
/*    */   public StringBuffer printExpression(int indent, StringBuffer output) {
/* 64 */     output.append("StringLiteralConcatenation{");
/* 65 */     for (int i = 0, max = this.counter; i < max; i++) {
/* 66 */       this.literals[i].printExpression(indent, output);
/* 67 */       output.append("+\n");
/*    */     } 
/* 69 */     return output.append('}');
/*    */   }
/*    */ 
/*    */   
/*    */   public char[] source() {
/* 74 */     return this.source;
/*    */   }
/*    */ 
/*    */   
/*    */   public void traverse(ASTVisitor visitor, BlockScope scope) {
/* 79 */     if (visitor.visit(this, scope)) {
/* 80 */       for (int i = 0, max = this.counter; i < max; i++) {
/* 81 */         this.literals[i].traverse(visitor, scope);
/*    */       }
/*    */     }
/* 84 */     visitor.endVisit(this, scope);
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\ast\StringLiteralConcatenation.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */