/*    */ package org.eclipse.jdt.internal.compiler.ast;
/*    */ 
/*    */ import org.eclipse.jdt.internal.compiler.impl.IntConstant;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class IntLiteralMinValue
/*    */   extends IntLiteral
/*    */ {
/* 20 */   static final char[] CharValue = new char[] { '-', '2', '1', '4', '7', '4', '8', '3', '6', '4', '8' };
/*    */   
/*    */   public IntLiteralMinValue(char[] token, char[] reducedToken, int start, int end) {
/* 23 */     super(token, reducedToken, start, end, -2147483648, IntConstant.fromValue(-2147483648));
/*    */   }
/*    */   
/*    */   public void computeConstant() {}
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\ast\IntLiteralMinValue.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */