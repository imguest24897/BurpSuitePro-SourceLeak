/*    */ package org.eclipse.jdt.internal.compiler.apt.model;
/*    */ 
/*    */ import javax.lang.model.type.TypeKind;
/*    */ import javax.lang.model.type.TypeMirror;
/*    */ import javax.lang.model.type.TypeVisitor;
/*    */ import javax.lang.model.type.WildcardType;
/*    */ import org.eclipse.jdt.internal.compiler.apt.dispatch.BaseProcessingEnvImpl;
/*    */ import org.eclipse.jdt.internal.compiler.lookup.Binding;
/*    */ import org.eclipse.jdt.internal.compiler.lookup.TypeBinding;
/*    */ import org.eclipse.jdt.internal.compiler.lookup.WildcardBinding;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class WildcardTypeImpl
/*    */   extends TypeMirrorImpl
/*    */   implements WildcardType
/*    */ {
/*    */   WildcardTypeImpl(BaseProcessingEnvImpl env, WildcardBinding binding) {
/* 33 */     super(env, (Binding)binding);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public TypeMirror getExtendsBound() {
/* 41 */     WildcardBinding wildcardBinding = (WildcardBinding)this._binding;
/* 42 */     if (wildcardBinding.boundKind != 1) return null; 
/* 43 */     TypeBinding bound = wildcardBinding.bound;
/* 44 */     if (bound == null) return null; 
/* 45 */     return this._env.getFactory().newTypeMirror((Binding)bound);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public TypeKind getKind() {
/* 53 */     return TypeKind.WILDCARD;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public TypeMirror getSuperBound() {
/* 60 */     WildcardBinding wildcardBinding = (WildcardBinding)this._binding;
/* 61 */     if (wildcardBinding.boundKind != 2) return null; 
/* 62 */     TypeBinding bound = wildcardBinding.bound;
/* 63 */     if (bound == null) return null; 
/* 64 */     return this._env.getFactory().newTypeMirror((Binding)bound);
/*    */   }
/*    */ 
/*    */   
/*    */   public <R, P> R accept(TypeVisitor<R, P> v, P p) {
/* 69 */     return v.visitWildcard(this, p);
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\apt\model\WildcardTypeImpl.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */