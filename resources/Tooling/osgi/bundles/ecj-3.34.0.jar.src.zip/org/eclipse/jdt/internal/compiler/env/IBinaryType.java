/*     */ package org.eclipse.jdt.internal.compiler.env;
/*     */ 
/*     */ import java.net.URI;
/*     */ import org.eclipse.jdt.core.compiler.CharOperation;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.BinaryTypeBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.LookupEnvironment;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public interface IBinaryType
/*     */   extends IGenericType
/*     */ {
/*  28 */   public static final char[][] NoInterface = CharOperation.NO_CHAR_CHAR;
/*  29 */   public static final IBinaryNestedType[] NoNestedType = new IBinaryNestedType[0];
/*  30 */   public static final IBinaryField[] NoField = new IBinaryField[0];
/*  31 */   public static final IBinaryMethod[] NoMethod = new IBinaryMethod[0];
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   IBinaryAnnotation[] getAnnotations();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   IBinaryTypeAnnotation[] getTypeAnnotations();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   char[] getEnclosingMethod();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   char[] getEnclosingTypeName();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   IBinaryField[] getFields();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   IRecordComponent[] getRecordComponents();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   char[] getModule();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   char[] getGenericSignature();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   char[][] getInterfaceNames();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default char[][] getPermittedSubtypeNames() {
/* 105 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   IBinaryNestedType[] getMemberTypes();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   IBinaryMethod[] getMethods();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   char[][][] getMissingTypeNames();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   char[] getName();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   char[] getSourceName();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   char[] getSuperclassName();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   long getTagBits();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean isAnonymous();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean isLocal();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean isRecord();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean isMember();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   char[] sourceFileName();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   ITypeAnnotationWalker enrichWithExternalAnnotationsFor(ITypeAnnotationWalker paramITypeAnnotationWalker, Object paramObject, LookupEnvironment paramLookupEnvironment);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   BinaryTypeBinding.ExternalAnnotationStatus getExternalAnnotationStatus();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default URI getURI() {
/* 205 */     return null;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\env\IBinaryType.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */