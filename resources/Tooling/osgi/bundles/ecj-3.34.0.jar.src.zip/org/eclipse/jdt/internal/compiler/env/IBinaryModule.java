package org.eclipse.jdt.internal.compiler.env;

import java.net.URI;

public interface IBinaryModule extends IModule {
  IBinaryAnnotation[] getAnnotations();
  
  long getTagBits();
  
  URI getURI();
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\env\IBinaryModule.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */