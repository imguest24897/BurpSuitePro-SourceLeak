/*      */ package org.eclipse.jdt.internal.compiler.ast;
/*      */ 
/*      */ import java.util.HashMap;
/*      */ import java.util.function.BiConsumer;
/*      */ import org.eclipse.jdt.core.compiler.CharOperation;
/*      */ import org.eclipse.jdt.internal.compiler.ASTVisitor;
/*      */ import org.eclipse.jdt.internal.compiler.codegen.CodeStream;
/*      */ import org.eclipse.jdt.internal.compiler.flow.FlowContext;
/*      */ import org.eclipse.jdt.internal.compiler.flow.FlowInfo;
/*      */ import org.eclipse.jdt.internal.compiler.flow.UnconditionalFlowInfo;
/*      */ import org.eclipse.jdt.internal.compiler.impl.CompilerOptions;
/*      */ import org.eclipse.jdt.internal.compiler.impl.Constant;
/*      */ import org.eclipse.jdt.internal.compiler.impl.IrritantSet;
/*      */ import org.eclipse.jdt.internal.compiler.impl.ReferenceContext;
/*      */ import org.eclipse.jdt.internal.compiler.lookup.ArrayBinding;
/*      */ import org.eclipse.jdt.internal.compiler.lookup.BaseTypeBinding;
/*      */ import org.eclipse.jdt.internal.compiler.lookup.Binding;
/*      */ import org.eclipse.jdt.internal.compiler.lookup.BlockScope;
/*      */ import org.eclipse.jdt.internal.compiler.lookup.FieldBinding;
/*      */ import org.eclipse.jdt.internal.compiler.lookup.ImplicitNullAnnotationVerifier;
/*      */ import org.eclipse.jdt.internal.compiler.lookup.InferenceContext18;
/*      */ import org.eclipse.jdt.internal.compiler.lookup.LocalVariableBinding;
/*      */ import org.eclipse.jdt.internal.compiler.lookup.MethodBinding;
/*      */ import org.eclipse.jdt.internal.compiler.lookup.ParameterizedGenericMethodBinding;
/*      */ import org.eclipse.jdt.internal.compiler.lookup.ParameterizedMethodBinding;
/*      */ import org.eclipse.jdt.internal.compiler.lookup.PolyTypeBinding;
/*      */ import org.eclipse.jdt.internal.compiler.lookup.PolymorphicMethodBinding;
/*      */ import org.eclipse.jdt.internal.compiler.lookup.ProblemMethodBinding;
/*      */ import org.eclipse.jdt.internal.compiler.lookup.ProblemReferenceBinding;
/*      */ import org.eclipse.jdt.internal.compiler.lookup.ReferenceBinding;
/*      */ import org.eclipse.jdt.internal.compiler.lookup.Scope;
/*      */ import org.eclipse.jdt.internal.compiler.lookup.SourceTypeBinding;
/*      */ import org.eclipse.jdt.internal.compiler.lookup.Substitution;
/*      */ import org.eclipse.jdt.internal.compiler.lookup.TypeBinding;
/*      */ import org.eclipse.jdt.internal.compiler.lookup.TypeConstants;
/*      */ import org.eclipse.jdt.internal.compiler.lookup.TypeVariableBinding;
/*      */ import org.eclipse.jdt.internal.compiler.util.SimpleLookupTable;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class MessageSend
/*      */   extends Expression
/*      */   implements IPolyExpression, Invocation
/*      */ {
/*      */   public Expression receiver;
/*      */   public char[] selector;
/*      */   public Expression[] arguments;
/*      */   public MethodBinding binding;
/*      */   public MethodBinding syntheticAccessor;
/*      */   public TypeBinding expectedType;
/*      */   public long nameSourcePosition;
/*      */   public TypeBinding actualReceiverType;
/*      */   public TypeBinding valueCast;
/*      */   public TypeReference[] typeArguments;
/*      */   public TypeBinding[] genericTypeArguments;
/*      */   public ExpressionContext expressionContext;
/*      */   private SimpleLookupTable inferenceContexts;
/*      */   private HashMap<TypeBinding, MethodBinding> solutionsPerTargetType;
/*      */   private InferenceContext18 outerInferenceContext;
/*      */   private boolean receiverIsType;
/*      */   protected boolean argsContainCast;
/*      */   public TypeBinding[] argumentTypes;
/*      */   public boolean argumentsHaveErrors;
/*      */   public FakedTrackingVariable closeTracker;
/*      */   BiConsumer<FlowInfo, Boolean> flowUpdateOnBooleanResult;
/*      */   
/*      */   public MessageSend() {
/*  131 */     this.expressionContext = ExpressionContext.VANILLA_CONTEXT;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  140 */     this.argumentTypes = Binding.NO_PARAMETERS;
/*  141 */     this.argumentsHaveErrors = false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public FlowInfo analyseCode(BlockScope currentScope, FlowContext flowContext, FlowInfo flowInfo) {
/*      */     FlowInfo flowInfo1;
/*  149 */     boolean nonStatic = !this.binding.isStatic();
/*  150 */     boolean wasInsideAssert = ((flowContext.tagBits & 0x1000) != 0);
/*  151 */     UnconditionalFlowInfo unconditionalFlowInfo = this.receiver.analyseCode(currentScope, flowContext, flowInfo, nonStatic).unconditionalInits();
/*      */     
/*  153 */     yieldQualifiedCheck(currentScope);
/*      */     
/*  155 */     CompilerOptions compilerOptions = currentScope.compilerOptions();
/*  156 */     boolean analyseResources = compilerOptions.analyseResourceLeaks;
/*  157 */     if (analyseResources)
/*  158 */       if (nonStatic) {
/*      */         
/*  160 */         if (CharOperation.equals(TypeConstants.CLOSE, this.selector)) {
/*  161 */           recordCallingClose(currentScope, flowContext, (FlowInfo)unconditionalFlowInfo, this.receiver);
/*      */         }
/*  163 */       } else if (this.arguments != null && this.arguments.length > 0 && FakedTrackingVariable.isAnyCloseable((this.arguments[0]).resolvedType)) {
/*      */         
/*  165 */         for (int i = 0; i < TypeConstants.closeMethods.length; i++) {
/*  166 */           TypeConstants.CloseMethodRecord record = TypeConstants.closeMethods[i];
/*  167 */           if (CharOperation.equals(record.selector, this.selector) && 
/*  168 */             CharOperation.equals(record.typeName, this.binding.declaringClass.compoundName)) {
/*      */             
/*  170 */             int len = Math.min(record.numCloseableArgs, this.arguments.length);
/*  171 */             for (int j = 0; j < len; j++) {
/*  172 */               recordCallingClose(currentScope, flowContext, (FlowInfo)unconditionalFlowInfo, this.arguments[j]);
/*      */             }
/*      */             break;
/*      */           } 
/*      */         } 
/*      */       }  
/*  178 */     if (compilerOptions.isAnyEnabled(IrritantSet.UNLIKELY_ARGUMENT_TYPE) && this.binding.isValidBinding() && 
/*  179 */       this.arguments != null) {
/*  180 */       if (this.arguments.length == 1 && !this.binding.isStatic()) {
/*  181 */         UnlikelyArgumentCheck argumentChecks = UnlikelyArgumentCheck.determineCheckForNonStaticSingleArgumentMethod(
/*  182 */             this.argumentTypes[0], (Scope)currentScope, this.selector, this.actualReceiverType, this.binding.parameters);
/*      */         
/*  184 */         if (argumentChecks != null && argumentChecks.isDangerous(currentScope)) {
/*  185 */           currentScope.problemReporter().unlikelyArgumentType(this.arguments[0], this.binding, 
/*  186 */               this.argumentTypes[0], argumentChecks.typeToReport, argumentChecks.dangerousMethod);
/*      */         }
/*  188 */       } else if (this.arguments.length == 2 && this.binding.isStatic()) {
/*  189 */         UnlikelyArgumentCheck argumentChecks = UnlikelyArgumentCheck.determineCheckForStaticTwoArgumentMethod(
/*  190 */             this.argumentTypes[1], (Scope)currentScope, this.selector, this.argumentTypes[0], 
/*  191 */             this.binding.parameters, this.actualReceiverType);
/*      */         
/*  193 */         if (argumentChecks != null && argumentChecks.isDangerous(currentScope)) {
/*  194 */           currentScope.problemReporter().unlikelyArgumentType(this.arguments[1], this.binding, 
/*  195 */               this.argumentTypes[1], argumentChecks.typeToReport, argumentChecks.dangerousMethod);
/*      */         }
/*      */       } 
/*      */     }
/*      */     
/*  200 */     if (nonStatic) {
/*  201 */       int timeToLive = ((this.bits & 0x100000) != 0) ? 3 : 2;
/*  202 */       this.receiver.checkNPE(currentScope, flowContext, (FlowInfo)unconditionalFlowInfo, timeToLive);
/*      */     } 
/*      */     
/*  205 */     if (this.arguments != null) {
/*  206 */       int length = this.arguments.length;
/*  207 */       for (int i = 0; i < length; i++) {
/*  208 */         FlowInfo flowInfo2; UnconditionalFlowInfo unconditionalFlowInfo1; Expression argument = this.arguments[i];
/*  209 */         argument.checkNPEbyUnboxing(currentScope, flowContext, (FlowInfo)unconditionalFlowInfo);
/*  210 */         switch (detectAssertionUtility(i)) {
/*      */           case TRUE_ASSERTION:
/*  212 */             flowInfo2 = analyseBooleanAssertion(currentScope, argument, flowContext, (FlowInfo)unconditionalFlowInfo, wasInsideAssert, true);
/*      */             break;
/*      */           case FALSE_ASSERTION:
/*  215 */             flowInfo2 = analyseBooleanAssertion(currentScope, argument, flowContext, flowInfo2, wasInsideAssert, false);
/*      */             break;
/*      */           case NONNULL_ASSERTION:
/*  218 */             flowInfo2 = analyseNullAssertion(currentScope, argument, flowContext, flowInfo2, false);
/*      */             break;
/*      */           case NULL_ASSERTION:
/*  221 */             flowInfo2 = analyseNullAssertion(currentScope, argument, flowContext, flowInfo2, true);
/*      */             break;
/*      */           case null:
/*  224 */             recordFlowUpdateOnResult(((SingleNameReference)argument).localVariableBinding(), true, false);
/*  225 */             unconditionalFlowInfo1 = argument.analyseCode(currentScope, flowContext, flowInfo2).unconditionalInits();
/*      */             break;
/*      */           case ARG_NONNULL_IF_TRUE_NEGATABLE:
/*  228 */             recordFlowUpdateOnResult(((SingleNameReference)argument).localVariableBinding(), true, true);
/*  229 */             unconditionalFlowInfo1 = argument.analyseCode(currentScope, flowContext, (FlowInfo)unconditionalFlowInfo1).unconditionalInits();
/*      */             break;
/*      */           case ARG_NULL_IF_TRUE:
/*  232 */             recordFlowUpdateOnResult(((SingleNameReference)argument).localVariableBinding(), false, true);
/*  233 */             unconditionalFlowInfo1 = argument.analyseCode(currentScope, flowContext, (FlowInfo)unconditionalFlowInfo1).unconditionalInits();
/*      */             break;
/*      */           default:
/*  236 */             unconditionalFlowInfo1 = argument.analyseCode(currentScope, flowContext, (FlowInfo)unconditionalFlowInfo1).unconditionalInits(); break;
/*      */         } 
/*  238 */         if (analyseResources)
/*      */         {
/*  240 */           flowInfo1 = FakedTrackingVariable.markPassedToOutside(currentScope, argument, (FlowInfo)unconditionalFlowInfo1, flowContext, false);
/*      */         }
/*      */       } 
/*  243 */       analyseArguments(currentScope, flowContext, flowInfo1, this.binding, this.arguments);
/*      */     } 
/*      */     ReferenceBinding[] thrownExceptions;
/*  246 */     if ((thrownExceptions = this.binding.thrownExceptions) != Binding.NO_EXCEPTIONS) {
/*  247 */       if ((this.bits & 0x10000) != 0 && this.genericTypeArguments == null)
/*      */       {
/*  249 */         thrownExceptions = currentScope.environment().convertToRawTypes(this.binding.thrownExceptions, true, true);
/*      */       }
/*      */       
/*  252 */       flowContext.checkExceptionHandlers((TypeBinding[])thrownExceptions, this, flowInfo1.copy(), currentScope);
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  258 */     if (analyseResources && FakedTrackingVariable.isAnyCloseable(this.resolvedType)) {
/*  259 */       flowInfo1 = FakedTrackingVariable.analyseCloseableAcquisition(currentScope, flowInfo1, this);
/*      */     }
/*  261 */     manageSyntheticAccessIfNecessary(currentScope, flowInfo1);
/*      */     
/*  263 */     flowContext.recordAbruptExit();
/*  264 */     flowContext.expireNullCheckedFieldInfo();
/*  265 */     return flowInfo1;
/*      */   }
/*      */   public void recordFlowUpdateOnResult(LocalVariableBinding local, boolean nonNullIfTrue, boolean negatable) {
/*  268 */     this.flowUpdateOnBooleanResult = ((f, result) -> {
/*      */         if (result.booleanValue() || paramBoolean1)
/*      */           if (result.booleanValue() == paramBoolean2) {
/*      */             f.markAsDefinitelyNonNull(paramLocalVariableBinding);
/*      */           } else {
/*      */             f.markAsDefinitelyNull(paramLocalVariableBinding);
/*      */           }  
/*      */       });
/*      */   }
/*      */   
/*      */   protected void updateFlowOnBooleanResult(FlowInfo flowInfo, boolean result) {
/*  279 */     if (this.flowUpdateOnBooleanResult != null)
/*  280 */       this.flowUpdateOnBooleanResult.accept(flowInfo, Boolean.valueOf(result)); 
/*      */   }
/*      */   
/*      */   private void yieldQualifiedCheck(BlockScope currentScope) {
/*  284 */     long sourceLevel = (currentScope.compilerOptions()).sourceLevel;
/*  285 */     if (sourceLevel < 3801088L || !receiverIsImplicitThis())
/*      */       return; 
/*  287 */     if (!CharOperation.equals(this.selector, TypeConstants.YIELD))
/*      */       return; 
/*  289 */     currentScope.problemReporter().switchExpressionsYieldUnqualifiedMethodError(this);
/*      */   }
/*      */   private void recordCallingClose(BlockScope currentScope, FlowContext flowContext, FlowInfo flowInfo, Expression closeTarget) {
/*  292 */     FakedTrackingVariable trackingVariable = FakedTrackingVariable.getCloseTrackingVariable(closeTarget, flowInfo, flowContext);
/*  293 */     if (trackingVariable != null)
/*  294 */       if (trackingVariable.methodScope == currentScope.methodScope()) {
/*  295 */         trackingVariable.markClose(flowInfo, flowContext);
/*      */       } else {
/*  297 */         trackingVariable.markClosedInNestedMethod();
/*      */       }  
/*      */   }
/*      */   
/*      */   private enum AssertUtil
/*      */   {
/*  303 */     NONE, TRUE_ASSERTION, FALSE_ASSERTION, NULL_ASSERTION, NONNULL_ASSERTION, ARG_NONNULL_IF_TRUE, ARG_NONNULL_IF_TRUE_NEGATABLE, ARG_NULL_IF_TRUE;
/*      */   }
/*      */ 
/*      */   
/*      */   private AssertUtil detectAssertionUtility(int argumentIdx) {
/*  308 */     TypeBinding[] parameters = (this.binding.original()).parameters;
/*  309 */     if (argumentIdx < parameters.length) {
/*  310 */       TypeBinding parameterType = parameters[argumentIdx];
/*  311 */       ReferenceBinding referenceBinding = this.binding.declaringClass;
/*  312 */       if (referenceBinding != null && parameterType != null) {
/*  313 */         switch ((referenceBinding.original()).id) {
/*      */           case 68:
/*  315 */             if (parameterType.id == 5)
/*  316 */               return AssertUtil.TRUE_ASSERTION; 
/*  317 */             if (parameterType.id == 1 && CharOperation.equals(TypeConstants.IS_NOTNULL, this.selector))
/*  318 */               return AssertUtil.NONNULL_ASSERTION; 
/*      */             break;
/*      */           case 69:
/*      */           case 70:
/*      */           case 75:
/*  323 */             if (parameterType.id == 5) {
/*  324 */               if (CharOperation.equals(TypeConstants.ASSERT_TRUE, this.selector))
/*  325 */                 return AssertUtil.TRUE_ASSERTION; 
/*  326 */               if (CharOperation.equals(TypeConstants.ASSERT_FALSE, this.selector))
/*  327 */                 return AssertUtil.FALSE_ASSERTION;  break;
/*  328 */             }  if (parameterType.id == 1) {
/*  329 */               if (CharOperation.equals(TypeConstants.ASSERT_NOTNULL, this.selector))
/*  330 */                 return AssertUtil.NONNULL_ASSERTION; 
/*  331 */               if (CharOperation.equals(TypeConstants.ASSERT_NULL, this.selector))
/*  332 */                 return AssertUtil.NULL_ASSERTION; 
/*      */             } 
/*      */             break;
/*      */           case 71:
/*  336 */             if (parameterType.id == 5) {
/*  337 */               if (CharOperation.equals(TypeConstants.IS_TRUE, this.selector))
/*  338 */                 return AssertUtil.TRUE_ASSERTION;  break;
/*  339 */             }  if (parameterType.id == 1 && 
/*  340 */               CharOperation.equals(TypeConstants.NOT_NULL, this.selector)) {
/*  341 */               return AssertUtil.NONNULL_ASSERTION;
/*      */             }
/*      */             break;
/*      */           case 72:
/*  345 */             if (parameterType.id == 5) {
/*  346 */               if (CharOperation.equals(TypeConstants.IS_TRUE, this.selector))
/*  347 */                 return AssertUtil.TRUE_ASSERTION;  break;
/*  348 */             }  if (parameterType.isTypeVariable() && 
/*  349 */               CharOperation.equals(TypeConstants.NOT_NULL, this.selector)) {
/*  350 */               return AssertUtil.NONNULL_ASSERTION;
/*      */             }
/*      */             break;
/*      */           case 73:
/*  354 */             if (parameterType.id == 5) {
/*  355 */               if (CharOperation.equals(TypeConstants.CHECK_ARGUMENT, this.selector) || 
/*  356 */                 CharOperation.equals(TypeConstants.CHECK_STATE, this.selector))
/*  357 */                 return AssertUtil.TRUE_ASSERTION;  break;
/*  358 */             }  if (parameterType.isTypeVariable() && 
/*  359 */               CharOperation.equals(TypeConstants.CHECK_NOT_NULL, this.selector)) {
/*  360 */               return AssertUtil.NONNULL_ASSERTION;
/*      */             }
/*      */             break;
/*      */           case 74:
/*  364 */             if (parameterType.isTypeVariable() && 
/*  365 */               CharOperation.equals(TypeConstants.REQUIRE_NON_NULL, this.selector)) {
/*  366 */               return AssertUtil.NONNULL_ASSERTION;
/*      */             }
/*  368 */             if (this.arguments[argumentIdx] instanceof SingleNameReference) {
/*  369 */               SingleNameReference nameRef = (SingleNameReference)this.arguments[argumentIdx];
/*  370 */               if (nameRef.binding instanceof LocalVariableBinding) {
/*  371 */                 if (CharOperation.equals(TypeConstants.NON_NULL, this.selector))
/*  372 */                   return AssertUtil.ARG_NONNULL_IF_TRUE_NEGATABLE; 
/*  373 */                 if (CharOperation.equals(TypeConstants.IS_NULL, this.selector))
/*  374 */                   return AssertUtil.ARG_NULL_IF_TRUE; 
/*      */               } 
/*      */             } 
/*      */             break;
/*      */           case 16:
/*  379 */             if (CharOperation.equals(TypeConstants.IS_INSTANCE, this.selector) && 
/*  380 */               this.arguments[argumentIdx] instanceof SingleNameReference) {
/*  381 */               SingleNameReference nameRef = (SingleNameReference)this.arguments[argumentIdx];
/*  382 */               if (nameRef.binding instanceof LocalVariableBinding) {
/*  383 */                 return AssertUtil.ARG_NONNULL_IF_TRUE;
/*      */               }
/*      */             } 
/*      */             break;
/*      */         } 
/*      */       }
/*      */     } 
/*  390 */     return AssertUtil.NONE;
/*      */   }
/*      */   private FlowInfo analyseBooleanAssertion(BlockScope currentScope, Expression argument, FlowContext flowContext, FlowInfo flowInfo, boolean wasInsideAssert, boolean passOnTrue) {
/*      */     UnconditionalFlowInfo assertWhenPassInfo;
/*      */     FlowInfo assertWhenFailInfo;
/*      */     boolean isOptimizedPassing, isOptimizedFailing;
/*  396 */     Constant cst = argument.optimizedBooleanConstant();
/*  397 */     boolean isOptimizedTrueAssertion = (cst != Constant.NotAConstant && cst.booleanValue());
/*  398 */     boolean isOptimizedFalseAssertion = (cst != Constant.NotAConstant && !cst.booleanValue());
/*  399 */     int tagBitsSave = flowContext.tagBits;
/*  400 */     flowContext.tagBits |= 0x1000;
/*  401 */     if (!passOnTrue)
/*  402 */       flowContext.tagBits |= 0x4; 
/*  403 */     FlowInfo conditionFlowInfo = argument.analyseCode(currentScope, flowContext, flowInfo.copy());
/*  404 */     flowContext.extendTimeToLiveForNullCheckedField(2);
/*  405 */     flowContext.tagBits = tagBitsSave;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  411 */     if (passOnTrue) {
/*  412 */       assertWhenPassInfo = conditionFlowInfo.initsWhenTrue().unconditionalInits();
/*  413 */       assertWhenFailInfo = conditionFlowInfo.initsWhenFalse();
/*  414 */       isOptimizedPassing = isOptimizedTrueAssertion;
/*  415 */       isOptimizedFailing = isOptimizedFalseAssertion;
/*      */     } else {
/*  417 */       assertWhenPassInfo = conditionFlowInfo.initsWhenFalse().unconditionalInits();
/*  418 */       assertWhenFailInfo = conditionFlowInfo.initsWhenTrue();
/*  419 */       isOptimizedPassing = isOptimizedFalseAssertion;
/*  420 */       isOptimizedFailing = isOptimizedTrueAssertion;
/*      */     } 
/*  422 */     if (isOptimizedPassing) {
/*  423 */       assertWhenFailInfo.setReachMode(1);
/*      */     }
/*  425 */     if (!isOptimizedFailing)
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  433 */       flowInfo = flowInfo.mergedWith(assertWhenFailInfo.nullInfoLessUnconditionalCopy())
/*  434 */         .addInitializationsFrom((FlowInfo)assertWhenPassInfo.discardInitializationInfo());
/*      */     }
/*  436 */     return flowInfo;
/*      */   }
/*      */ 
/*      */   
/*      */   private FlowInfo analyseNullAssertion(BlockScope currentScope, Expression argument, FlowContext flowContext, FlowInfo flowInfo, boolean expectingNull) {
/*  441 */     int nullStatus = argument.nullStatus(flowInfo, flowContext);
/*  442 */     boolean willFail = (nullStatus == (expectingNull ? 4 : 2));
/*  443 */     UnconditionalFlowInfo unconditionalFlowInfo = argument.analyseCode(currentScope, flowContext, flowInfo).unconditionalInits();
/*  444 */     LocalVariableBinding local = argument.localVariableBinding();
/*  445 */     if (local != null) {
/*  446 */       if (expectingNull) {
/*  447 */         unconditionalFlowInfo.markAsDefinitelyNull(local);
/*      */       } else {
/*  449 */         unconditionalFlowInfo.markAsDefinitelyNonNull(local);
/*      */       } 
/*  451 */     } else if (!expectingNull && 
/*  452 */       argument instanceof Reference && 
/*  453 */       (currentScope.compilerOptions()).enableSyntacticNullAnalysisForFields) {
/*      */       
/*  455 */       FieldBinding field = ((Reference)argument).lastFieldBinding();
/*  456 */       if (field != null && (field.type.tagBits & 0x2L) == 0L) {
/*  457 */         flowContext.recordNullCheckedFieldReference((Reference)argument, 3);
/*      */       }
/*      */     } 
/*      */     
/*  461 */     if (willFail)
/*  462 */       unconditionalFlowInfo.setReachMode(2); 
/*  463 */     return (FlowInfo)unconditionalFlowInfo;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean checkNPE(BlockScope scope, FlowContext flowContext, FlowInfo flowInfo, int ttlForFieldCheck) {
/*  469 */     int nullStatus = nullStatus(flowInfo, flowContext);
/*  470 */     if ((nullStatus & 0x10) != 0) {
/*  471 */       if (this.binding.returnType.isTypeVariable() && nullStatus == 48 && (scope.environment()).globalOptions.pessimisticNullAnalysisForFreeTypeVariablesEnabled) {
/*  472 */         scope.problemReporter().methodReturnTypeFreeTypeVariableReference(this.binding, this);
/*      */       } else {
/*  474 */         scope.problemReporter().messageSendPotentialNullReference(this.binding, this);
/*      */       } 
/*  476 */     } else if ((this.resolvedType.tagBits & 0x100000000000000L) != 0L) {
/*  477 */       NullAnnotationMatching nonNullStatus = NullAnnotationMatching.okNonNullStatus(this);
/*  478 */       if (nonNullStatus.wantToReport())
/*  479 */         nonNullStatus.report((Scope)scope); 
/*      */     } 
/*  481 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void computeConversion(Scope scope, TypeBinding runtimeTimeType, TypeBinding compileTimeType) {
/*  488 */     if (runtimeTimeType == null || compileTimeType == null) {
/*      */       return;
/*      */     }
/*  491 */     if (this.binding != null && this.binding.isValidBinding()) {
/*  492 */       MethodBinding originalBinding = this.binding.original();
/*  493 */       TypeBinding originalType = originalBinding.returnType;
/*      */       
/*  495 */       if (ArrayBinding.isArrayClone(this.actualReceiverType, this.binding) && 
/*  496 */         runtimeTimeType.id != 1 && 
/*  497 */         (scope.compilerOptions()).sourceLevel >= 3211264L) {
/*      */         
/*  499 */         this.valueCast = runtimeTimeType;
/*  500 */       } else if (originalType.leafComponentType().isTypeVariable()) {
/*  501 */         TypeBinding targetType = (!compileTimeType.isBaseType() && runtimeTimeType.isBaseType()) ? 
/*  502 */           compileTimeType : 
/*  503 */           runtimeTimeType;
/*  504 */         this.valueCast = originalType.genericCast(targetType);
/*      */       } 
/*  506 */       if (this.valueCast instanceof ReferenceBinding) {
/*  507 */         ReferenceBinding referenceCast = (ReferenceBinding)this.valueCast;
/*  508 */         if (!referenceCast.canBeSeenBy(scope)) {
/*  509 */           scope.problemReporter().invalidType(this, 
/*  510 */               (TypeBinding)new ProblemReferenceBinding(
/*  511 */                 CharOperation.splitOn('.', referenceCast.shortReadableName()), 
/*  512 */                 referenceCast, 
/*  513 */                 2));
/*      */         }
/*      */       } 
/*      */     } 
/*  517 */     super.computeConversion(scope, runtimeTimeType, compileTimeType);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void generateCode(BlockScope currentScope, CodeStream codeStream, boolean valueRequired) {
/*  529 */     cleanUpInferenceContexts();
/*  530 */     int pc = codeStream.position;
/*      */     
/*  532 */     MethodBinding codegenBinding = (this.binding instanceof PolymorphicMethodBinding) ? this.binding : this.binding.original();
/*  533 */     boolean isStatic = codegenBinding.isStatic();
/*  534 */     if (isStatic) {
/*  535 */       this.receiver.generateCode(currentScope, codeStream, false);
/*  536 */     } else if ((this.bits & 0x1FE0) != 0 && this.receiver.isImplicitThis()) {
/*      */       
/*  538 */       ReferenceBinding targetType = currentScope.enclosingSourceType().enclosingTypeAt((this.bits & 0x1FE0) >> 5);
/*  539 */       Object[] path = currentScope.getEmulationPath(targetType, true, false);
/*  540 */       codeStream.generateOuterAccess(path, this, (Binding)targetType, (Scope)currentScope);
/*      */     } else {
/*  542 */       this.receiver.generateCode(currentScope, codeStream, true);
/*  543 */       if ((this.bits & 0x40000) != 0) {
/*  544 */         codeStream.checkcast(this.actualReceiverType);
/*      */       }
/*      */     } 
/*  547 */     codeStream.recordPositionsFrom(pc, this.sourceStart);
/*      */     
/*  549 */     generateArguments(this.binding, this.arguments, currentScope, codeStream);
/*  550 */     pc = codeStream.position;
/*      */     
/*  552 */     if (this.syntheticAccessor == null) {
/*  553 */       TypeBinding constantPoolDeclaringClass = CodeStream.getConstantPoolDeclaringClass((Scope)currentScope, codegenBinding, this.actualReceiverType, this.receiver.isImplicitThis());
/*  554 */       if (isStatic) {
/*  555 */         codeStream.invoke((byte)-72, codegenBinding, constantPoolDeclaringClass, this.typeArguments);
/*  556 */       } else if (this.receiver.isSuper() || (
/*  557 */         !currentScope.enclosingSourceType().isNestmateOf(this.binding.declaringClass) && codegenBinding.isPrivate())) {
/*  558 */         codeStream.invoke((byte)-73, codegenBinding, constantPoolDeclaringClass, this.typeArguments);
/*  559 */       } else if (constantPoolDeclaringClass.isInterface()) {
/*  560 */         codeStream.invoke((byte)-71, codegenBinding, constantPoolDeclaringClass, this.typeArguments);
/*      */       } else {
/*  562 */         codeStream.invoke((byte)-74, codegenBinding, constantPoolDeclaringClass, this.typeArguments);
/*      */       } 
/*      */     } else {
/*  565 */       codeStream.invoke((byte)-72, this.syntheticAccessor, null, this.typeArguments);
/*      */     } 
/*      */     
/*  568 */     if (this.valueCast != null) codeStream.checkcast(this.valueCast); 
/*  569 */     if (valueRequired) {
/*      */       
/*  571 */       codeStream.generateImplicitConversion(this.implicitConversion);
/*      */     } else {
/*  573 */       boolean isUnboxing = ((this.implicitConversion & 0x400) != 0);
/*      */       
/*  575 */       if (isUnboxing) codeStream.generateImplicitConversion(this.implicitConversion); 
/*  576 */       switch (isUnboxing ? (postConversionType((Scope)currentScope)).id : codegenBinding.returnType.id) {
/*      */         case 7:
/*      */         case 8:
/*  579 */           codeStream.pop2();
/*      */           break;
/*      */         case 6:
/*      */           break;
/*      */         default:
/*  584 */           codeStream.pop(); break;
/*      */       } 
/*      */     } 
/*  587 */     codeStream.recordPositionsFrom(pc, (int)(this.nameSourcePosition >>> 32L));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public TypeBinding[] genericTypeArguments() {
/*  594 */     return this.genericTypeArguments;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isSuperAccess() {
/*  599 */     return this.receiver.isSuper();
/*      */   }
/*      */   
/*      */   public boolean isTypeAccess() {
/*  603 */     return (this.receiver != null && this.receiver.isTypeReference());
/*      */   }
/*      */   
/*      */   public void manageSyntheticAccessIfNecessary(BlockScope currentScope, FlowInfo flowInfo) {
/*  607 */     if ((flowInfo.tagBits & 0x1) != 0) {
/*      */       return;
/*      */     }
/*  610 */     MethodBinding codegenBinding = this.binding.original();
/*  611 */     if (this.binding.isPrivate()) {
/*  612 */       boolean useNesting = (currentScope.enclosingSourceType().isNestmateOf(codegenBinding.declaringClass) && 
/*  613 */         !(this.receiver instanceof QualifiedSuperReference));
/*      */       
/*  615 */       if (!useNesting && 
/*  616 */         TypeBinding.notEquals((TypeBinding)currentScope.enclosingSourceType(), (TypeBinding)codegenBinding.declaringClass)) {
/*  617 */         this.syntheticAccessor = (MethodBinding)((SourceTypeBinding)codegenBinding.declaringClass).addSyntheticMethod(codegenBinding, false);
/*  618 */         currentScope.problemReporter().needToEmulateMethodAccess(codegenBinding, this);
/*      */         return;
/*      */       } 
/*      */     } else {
/*  622 */       if (this.receiver instanceof QualifiedSuperReference) {
/*  623 */         if (this.actualReceiverType.isInterface()) {
/*      */           return;
/*      */         }
/*  626 */         SourceTypeBinding destinationType = (SourceTypeBinding)((QualifiedSuperReference)this.receiver).currentCompatibleType;
/*  627 */         this.syntheticAccessor = (MethodBinding)destinationType.addSyntheticMethod(codegenBinding, isSuperAccess());
/*  628 */         currentScope.problemReporter().needToEmulateMethodAccess(codegenBinding, this);
/*      */         return;
/*      */       } 
/*  631 */       if (this.binding.isProtected())
/*      */       {
/*      */         
/*  634 */         if ((this.bits & 0x1FE0) != 0) {
/*  635 */           SourceTypeBinding enclosingSourceType; if (codegenBinding.declaringClass.getPackage() != (
/*  636 */             enclosingSourceType = currentScope.enclosingSourceType()).getPackage()) {
/*      */             
/*  638 */             SourceTypeBinding currentCompatibleType = (SourceTypeBinding)enclosingSourceType.enclosingTypeAt((this.bits & 0x1FE0) >> 5);
/*  639 */             this.syntheticAccessor = (MethodBinding)currentCompatibleType.addSyntheticMethod(codegenBinding, isSuperAccess());
/*  640 */             currentScope.problemReporter().needToEmulateMethodAccess(codegenBinding, this);
/*      */             return;
/*      */           } 
/*      */         }  } 
/*      */     } 
/*      */   }
/*      */   public int nullStatus(FlowInfo flowInfo, FlowContext flowContext) {
/*  647 */     if ((this.implicitConversion & 0x200) != 0)
/*  648 */       return 4; 
/*  649 */     if (this.binding.isValidBinding()) {
/*      */       
/*  651 */       long tagBits = this.binding.tagBits;
/*  652 */       if ((tagBits & 0x180000000000000L) == 0L)
/*  653 */         tagBits = this.binding.returnType.tagBits & 0x180000000000000L; 
/*  654 */       if (tagBits == 0L && this.binding.returnType.isFreeTypeVariable()) {
/*  655 */         return 48;
/*      */       }
/*  657 */       return FlowInfo.tagBitsToNullStatus(tagBits);
/*      */     } 
/*  659 */     return 1;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public TypeBinding postConversionType(Scope scope) {
/*      */     BaseTypeBinding baseTypeBinding;
/*  666 */     TypeBinding typeBinding1, convertedType = this.resolvedType;
/*  667 */     if (this.valueCast != null)
/*  668 */       convertedType = this.valueCast; 
/*  669 */     int runtimeType = (this.implicitConversion & 0xFF) >> 4;
/*  670 */     switch (runtimeType) {
/*      */       case 5:
/*  672 */         baseTypeBinding = TypeBinding.BOOLEAN;
/*      */         break;
/*      */       case 3:
/*  675 */         baseTypeBinding = TypeBinding.BYTE;
/*      */         break;
/*      */       case 4:
/*  678 */         baseTypeBinding = TypeBinding.SHORT;
/*      */         break;
/*      */       case 2:
/*  681 */         baseTypeBinding = TypeBinding.CHAR;
/*      */         break;
/*      */       case 10:
/*  684 */         baseTypeBinding = TypeBinding.INT;
/*      */         break;
/*      */       case 9:
/*  687 */         baseTypeBinding = TypeBinding.FLOAT;
/*      */         break;
/*      */       case 7:
/*  690 */         baseTypeBinding = TypeBinding.LONG;
/*      */         break;
/*      */       case 8:
/*  693 */         baseTypeBinding = TypeBinding.DOUBLE;
/*      */         break;
/*      */     } 
/*      */     
/*  697 */     if ((this.implicitConversion & 0x200) != 0) {
/*  698 */       typeBinding1 = scope.environment().computeBoxingType((TypeBinding)baseTypeBinding);
/*      */     }
/*  700 */     return typeBinding1;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public StringBuffer printExpression(int indent, StringBuffer output) {
/*  706 */     if (!this.receiver.isImplicitThis()) this.receiver.printExpression(0, output).append('.'); 
/*  707 */     if (this.typeArguments != null) {
/*  708 */       output.append('<');
/*  709 */       int max = this.typeArguments.length - 1;
/*  710 */       for (int j = 0; j < max; j++) {
/*  711 */         this.typeArguments[j].print(0, output);
/*  712 */         output.append(", ");
/*      */       } 
/*  714 */       this.typeArguments[max].print(0, output);
/*  715 */       output.append('>');
/*      */     } 
/*  717 */     output.append(this.selector).append('(');
/*  718 */     if (this.arguments != null) {
/*  719 */       for (int i = 0; i < this.arguments.length; i++) {
/*  720 */         if (i > 0) output.append(", "); 
/*  721 */         this.arguments[i].printExpression(0, output);
/*      */       } 
/*      */     }
/*  724 */     return output.append(')');
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public TypeBinding resolveType(BlockScope scope) {
/*      */     TypeBinding returnType;
/*  731 */     if (this.constant != Constant.NotAConstant) {
/*  732 */       this.constant = Constant.NotAConstant;
/*  733 */       long sourceLevel = (scope.compilerOptions()).sourceLevel;
/*  734 */       boolean receiverCast = false;
/*  735 */       if (this.receiver instanceof CastExpression) {
/*  736 */         this.receiver.bits |= 0x20;
/*  737 */         receiverCast = true;
/*      */       } 
/*  739 */       this.actualReceiverType = this.receiver.resolveType(scope);
/*  740 */       if (this.actualReceiverType instanceof org.eclipse.jdt.internal.compiler.lookup.InferenceVariable) {
/*  741 */         return null;
/*      */       }
/*  743 */       this.receiverIsType = this.receiver.isType();
/*  744 */       if (receiverCast && this.actualReceiverType != null) {
/*      */         
/*  746 */         TypeBinding resolvedType2 = ((CastExpression)this.receiver).expression.resolvedType;
/*  747 */         if (TypeBinding.equalsEquals(resolvedType2, this.actualReceiverType) && (
/*  748 */           !scope.environment().usesNullTypeAnnotations() || !NullAnnotationMatching.analyse(this.actualReceiverType, resolvedType2, -1).isAnyMismatch())) {
/*  749 */           scope.problemReporter().unnecessaryCast((CastExpression)this.receiver);
/*      */         }
/*      */       } 
/*      */ 
/*      */       
/*  754 */       if (this.typeArguments != null) {
/*  755 */         int length = this.typeArguments.length;
/*  756 */         this.argumentsHaveErrors = (sourceLevel < 3211264L);
/*  757 */         this.genericTypeArguments = new TypeBinding[length]; int i;
/*  758 */         for (i = 0; i < length; i++) {
/*  759 */           TypeReference typeReference = this.typeArguments[i];
/*  760 */           this.genericTypeArguments[i] = typeReference.resolveType(scope, true, 64); if (typeReference.resolveType(scope, true, 64) == null) {
/*  761 */             this.argumentsHaveErrors = true;
/*      */           }
/*  763 */           if (this.argumentsHaveErrors && typeReference instanceof Wildcard) {
/*  764 */             scope.problemReporter().illegalUsageOfWildcard(typeReference);
/*      */           }
/*      */         } 
/*  767 */         if (this.argumentsHaveErrors) {
/*  768 */           if (this.arguments != null) {
/*  769 */             int max; for (i = 0, max = this.arguments.length; i < max; i++) {
/*  770 */               this.arguments[i].resolveType(scope);
/*      */             }
/*      */           } 
/*  773 */           return null;
/*      */         } 
/*      */       } 
/*      */       
/*  777 */       if (this.arguments != null) {
/*  778 */         this.argumentsHaveErrors = false;
/*  779 */         int length = this.arguments.length;
/*  780 */         this.argumentTypes = new TypeBinding[length];
/*  781 */         for (int i = 0; i < length; i++) {
/*  782 */           Expression argument = this.arguments[i];
/*  783 */           if ((this.arguments[i]).resolvedType != null)
/*  784 */             scope.problemReporter().genericInferenceError("Argument was unexpectedly found resolved", this); 
/*  785 */           if (argument instanceof CastExpression) {
/*  786 */             argument.bits |= 0x20;
/*  787 */             this.argsContainCast = true;
/*      */           } 
/*  789 */           argument.setExpressionContext(ExpressionContext.INVOCATION_CONTEXT);
/*  790 */           this.argumentTypes[i] = argument.resolveType(scope); if (argument.resolveType(scope) == null) {
/*  791 */             this.argumentsHaveErrors = true;
/*      */           }
/*      */         } 
/*  794 */         if (this.argumentsHaveErrors) {
/*  795 */           if (this.actualReceiverType instanceof ReferenceBinding) {
/*      */             
/*  797 */             TypeBinding[] pseudoArgs = new TypeBinding[length];
/*  798 */             for (int j = length; --j >= 0;) {
/*  799 */               pseudoArgs[j] = (this.argumentTypes[j] == null) ? (TypeBinding)TypeBinding.NULL : this.argumentTypes[j];
/*      */             }
/*  801 */             this.binding = this.receiver.isImplicitThis() ? 
/*  802 */               scope.getImplicitMethod(this.selector, pseudoArgs, this) : 
/*  803 */               scope.findMethod((ReferenceBinding)this.actualReceiverType, this.selector, pseudoArgs, this, false);
/*      */             
/*  805 */             if (this.binding != null && !this.binding.isValidBinding()) {
/*  806 */               MethodBinding closestMatch = ((ProblemMethodBinding)this.binding).closestMatch;
/*      */               
/*  808 */               if (closestMatch != null) {
/*  809 */                 ParameterizedGenericMethodBinding parameterizedGenericMethodBinding; if ((closestMatch.original()).typeVariables != Binding.NO_TYPE_VARIABLES)
/*      */                 {
/*  811 */                   parameterizedGenericMethodBinding = scope.environment().createParameterizedGenericMethod(closestMatch.original(), null);
/*      */                 }
/*  813 */                 this.binding = (MethodBinding)parameterizedGenericMethodBinding;
/*  814 */                 MethodBinding closestMatchOriginal = parameterizedGenericMethodBinding.original();
/*  815 */                 if (closestMatchOriginal.isOrEnclosedByPrivateType() && !scope.isDefinedInMethod(closestMatchOriginal))
/*      */                 {
/*  817 */                   closestMatchOriginal.modifiers |= 0x8000000;
/*      */                 }
/*      */               } 
/*      */             } 
/*      */           } 
/*  822 */           return null;
/*      */         } 
/*      */       } 
/*  825 */       if (this.actualReceiverType == null) {
/*  826 */         return null;
/*      */       }
/*      */       
/*  829 */       if (this.actualReceiverType.isBaseType()) {
/*  830 */         scope.problemReporter().errorNoMethodFor(this, this.actualReceiverType, this.argumentTypes);
/*  831 */         return null;
/*      */       } 
/*      */     } 
/*      */     
/*  835 */     TypeBinding methodType = findMethodBinding(scope);
/*  836 */     if (methodType != null && methodType.isPolyType()) {
/*  837 */       this.resolvedType = this.binding.returnType.capture((Scope)scope, this.sourceStart, this.sourceEnd);
/*  838 */       return methodType;
/*      */     } 
/*      */     
/*  841 */     if (!this.binding.isValidBinding()) {
/*  842 */       if (this.binding.declaringClass == null) {
/*  843 */         if (this.actualReceiverType instanceof ReferenceBinding) {
/*  844 */           this.binding.declaringClass = (ReferenceBinding)this.actualReceiverType;
/*      */         } else {
/*  846 */           scope.problemReporter().errorNoMethodFor(this, this.actualReceiverType, this.argumentTypes);
/*  847 */           return null;
/*      */         } 
/*      */       }
/*      */ 
/*      */       
/*  852 */       ReferenceBinding declaringClass = this.binding.declaringClass;
/*  853 */       boolean avoidSecondary = (declaringClass != null && 
/*  854 */         declaringClass.isAnonymousType() && 
/*  855 */         declaringClass.superclass() instanceof org.eclipse.jdt.internal.compiler.lookup.MissingTypeBinding);
/*  856 */       if (!avoidSecondary)
/*  857 */         scope.problemReporter().invalidMethod(this, this.binding, (Scope)scope); 
/*  858 */       MethodBinding closestMatch = ((ProblemMethodBinding)this.binding).closestMatch;
/*  859 */       switch (this.binding.problemId()) {
/*      */ 
/*      */ 
/*      */         
/*      */         case 23:
/*      */         case 27:
/*  865 */           if (this.expressionContext != ExpressionContext.INVOCATION_CONTEXT) {
/*      */             break;
/*      */           }
/*      */         
/*      */         case 2:
/*      */         case 6:
/*      */         case 7:
/*      */         case 8:
/*      */         case 10:
/*  874 */           if (closestMatch != null) this.resolvedType = closestMatch.returnType; 
/*      */           break;
/*      */         case 25:
/*  877 */           if (closestMatch != null && closestMatch.returnType != null) {
/*  878 */             this.resolvedType = closestMatch.returnType.withoutToplevelNullAnnotation();
/*      */           }
/*      */           break;
/*      */       } 
/*  882 */       if (closestMatch != null) {
/*  883 */         this.binding = closestMatch;
/*  884 */         MethodBinding closestMatchOriginal = closestMatch.original();
/*  885 */         if (closestMatchOriginal.isOrEnclosedByPrivateType() && !scope.isDefinedInMethod(closestMatchOriginal))
/*      */         {
/*  887 */           closestMatchOriginal.modifiers |= 0x8000000;
/*      */         }
/*      */       } 
/*  890 */       return (this.resolvedType != null && (this.resolvedType.tagBits & 0x80L) == 0L) ? 
/*  891 */         this.resolvedType : 
/*  892 */         null;
/*      */     } 
/*  894 */     CompilerOptions compilerOptions = scope.compilerOptions();
/*  895 */     if (compilerOptions.complianceLevel <= 3276800L && 
/*  896 */       this.binding.isPolymorphic()) {
/*  897 */       scope.problemReporter().polymorphicMethodNotBelow17(this);
/*  898 */       return null;
/*      */     } 
/*      */     
/*  901 */     if (compilerOptions.isAnnotationBasedNullAnalysisEnabled) {
/*  902 */       ImplicitNullAnnotationVerifier.ensureNullnessIsKnown(this.binding, (Scope)scope);
/*  903 */       if (compilerOptions.sourceLevel >= 3407872L && 
/*  904 */         this.binding instanceof ParameterizedGenericMethodBinding && this.typeArguments != null) {
/*  905 */         TypeVariableBinding[] typeVariables = this.binding.original().typeVariables();
/*  906 */         for (int i = 0; i < this.typeArguments.length; i++) {
/*  907 */           this.typeArguments[i].checkNullConstraints((Scope)scope, (Substitution)this.binding, (TypeBinding[])typeVariables, i);
/*      */         }
/*      */       } 
/*      */     } 
/*      */     
/*  912 */     if (this.binding.isPolymorphic()) {
/*      */       
/*  914 */       boolean resultDetermined = (compilerOptions.sourceLevel >= 3473408L && (
/*  915 */         this.binding.returnType == TypeBinding.VOID || 
/*  916 */         this.binding.returnType.id != 1));
/*      */       
/*  918 */       if (!resultDetermined && (this.bits & 0x100000) != 0)
/*      */       {
/*  920 */         this.binding = scope.environment().updatePolymorphicMethodReturnType((PolymorphicMethodBinding)this.binding, (TypeBinding)TypeBinding.VOID);
/*      */       }
/*      */     } 
/*  923 */     if ((this.binding.tagBits & 0x80L) != 0L) {
/*  924 */       scope.problemReporter().missingTypeInMethod(this, this.binding);
/*      */     }
/*  926 */     if (!this.binding.isStatic()) {
/*      */       
/*  928 */       if (this.receiverIsType) {
/*  929 */         scope.problemReporter().mustUseAStaticMethod(this, this.binding);
/*  930 */         if (this.actualReceiverType.isRawType() && (
/*  931 */           this.receiver.bits & 0x40000000) == 0 && 
/*  932 */           compilerOptions.getSeverity(536936448) != 256) {
/*  933 */           scope.problemReporter().rawTypeReference(this.receiver, this.actualReceiverType);
/*      */         }
/*      */       }
/*      */       else {
/*      */         
/*  938 */         TypeBinding oldReceiverType = this.actualReceiverType;
/*  939 */         this.actualReceiverType = this.actualReceiverType.getErasureCompatibleType((TypeBinding)this.binding.declaringClass);
/*  940 */         this.receiver.computeConversion((Scope)scope, this.actualReceiverType, this.actualReceiverType);
/*  941 */         if (TypeBinding.notEquals(this.actualReceiverType, oldReceiverType) && TypeBinding.notEquals(this.receiver.postConversionType((Scope)scope), this.actualReceiverType)) {
/*  942 */           this.bits |= 0x40000;
/*      */         }
/*      */       } 
/*      */     } else {
/*      */       
/*  947 */       if (this.binding.declaringClass.isInterface() && ((!isTypeAccess() && !this.receiver.isImplicitThis()) || !TypeBinding.equalsEquals((TypeBinding)this.binding.declaringClass, this.actualReceiverType))) {
/*  948 */         scope.problemReporter().nonStaticOrAlienTypeReceiver(this, this.binding);
/*  949 */       } else if (!this.receiver.isImplicitThis() && !this.receiver.isSuper() && !this.receiverIsType) {
/*  950 */         scope.problemReporter().nonStaticAccessToStaticMethod(this, this.binding);
/*      */       } 
/*  952 */       if (!this.receiver.isImplicitThis() && TypeBinding.notEquals((TypeBinding)this.binding.declaringClass, this.actualReceiverType)) {
/*  953 */         scope.problemReporter().indirectAccessToStaticMethod(this, this.binding);
/*      */       }
/*      */     } 
/*  956 */     if (checkInvocationArguments(scope, this.receiver, this.actualReceiverType, this.binding, this.arguments, this.argumentTypes, this.argsContainCast, this)) {
/*  957 */       this.bits |= 0x10000;
/*      */     }
/*      */ 
/*      */     
/*  961 */     if (this.binding.isAbstract() && 
/*  962 */       this.receiver.isSuper()) {
/*  963 */       scope.problemReporter().cannotDireclyInvokeAbstractMethod(this, this.binding);
/*      */     }
/*      */ 
/*      */     
/*  967 */     if (isMethodUseDeprecated(this.binding, (Scope)scope, true, this)) {
/*  968 */       scope.problemReporter().deprecatedMethod(this.binding, this);
/*      */     }
/*      */     
/*  971 */     if ((this.bits & 0x10000) != 0 && this.genericTypeArguments == null) {
/*      */       
/*  973 */       returnType = this.binding.returnType;
/*  974 */       if (returnType != null) {
/*  975 */         returnType = scope.environment().convertToRawType(returnType.erasure(), true);
/*      */       }
/*      */     } else {
/*  978 */       returnType = this.binding.returnType;
/*  979 */       if (returnType != null) {
/*  980 */         returnType = returnType.capture((Scope)scope, this.sourceStart, this.sourceEnd);
/*      */       }
/*      */     } 
/*  983 */     this.resolvedType = returnType;
/*  984 */     if (this.receiver.isSuper() && compilerOptions.getSeverity(537919488) != 256) {
/*  985 */       ReferenceContext referenceContext = (scope.methodScope()).referenceContext;
/*  986 */       if (referenceContext instanceof AbstractMethodDeclaration) {
/*  987 */         AbstractMethodDeclaration abstractMethodDeclaration = (AbstractMethodDeclaration)referenceContext;
/*  988 */         MethodBinding enclosingMethodBinding = abstractMethodDeclaration.binding;
/*  989 */         if (enclosingMethodBinding.isOverriding() && 
/*  990 */           CharOperation.equals(this.binding.selector, enclosingMethodBinding.selector) && 
/*  991 */           this.binding.areParametersEqual(enclosingMethodBinding)) {
/*  992 */           abstractMethodDeclaration.bits |= 0x10;
/*      */         }
/*      */       } 
/*      */     } 
/*  996 */     if (this.receiver.isSuper() && this.actualReceiverType.isInterface())
/*      */     {
/*  998 */       scope.checkAppropriateMethodAgainstSupers(this.selector, this.binding, this.argumentTypes, this);
/*      */     }
/* 1000 */     if (this.typeArguments != null && (this.binding.original()).typeVariables == Binding.NO_TYPE_VARIABLES) {
/* 1001 */       scope.problemReporter().unnecessaryTypeArgumentsForMethodInvocation(this.binding, this.genericTypeArguments, this.typeArguments);
/*      */     }
/* 1003 */     return ((this.resolvedType.tagBits & 0x80L) == 0L) ? 
/* 1004 */       this.resolvedType : 
/* 1005 */       null;
/*      */   }
/*      */   
/*      */   protected TypeBinding findMethodBinding(BlockScope scope) {
/* 1009 */     ReferenceContext referenceContext = (scope.methodScope()).referenceContext;
/* 1010 */     if (referenceContext instanceof LambdaExpression) {
/* 1011 */       this.outerInferenceContext = ((LambdaExpression)referenceContext).inferenceContext;
/*      */     }
/*      */     
/* 1014 */     if (this.expectedType != null && this.binding instanceof org.eclipse.jdt.internal.compiler.lookup.PolyParameterizedGenericMethodBinding) {
/* 1015 */       this.binding = this.solutionsPerTargetType.get(this.expectedType);
/*      */     }
/* 1017 */     if (this.binding == null) {
/* 1018 */       this.binding = this.receiver.isImplicitThis() ? 
/* 1019 */         scope.getImplicitMethod(this.selector, this.argumentTypes, this) : 
/* 1020 */         scope.getMethod(this.actualReceiverType, this.selector, this.argumentTypes, this);
/*      */       
/* 1022 */       if (this.binding instanceof org.eclipse.jdt.internal.compiler.lookup.PolyParameterizedGenericMethodBinding) {
/* 1023 */         this.solutionsPerTargetType = new HashMap<>();
/* 1024 */         return (TypeBinding)new PolyTypeBinding(this);
/*      */       } 
/*      */     } 
/* 1027 */     this.binding = resolvePolyExpressionArguments(this, this.binding, this.argumentTypes, scope);
/* 1028 */     return this.binding.returnType;
/*      */   }
/*      */ 
/*      */   
/*      */   public void setActualReceiverType(ReferenceBinding receiverType) {
/* 1033 */     if (receiverType == null)
/* 1034 */       return;  this.actualReceiverType = (TypeBinding)receiverType;
/*      */   }
/*      */   
/*      */   public void setDepth(int depth) {
/* 1038 */     this.bits &= 0xFFFFE01F;
/* 1039 */     if (depth > 0) {
/* 1040 */       this.bits |= (depth & 0xFF) << 5;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setExpectedType(TypeBinding expectedType) {
/* 1049 */     this.expectedType = expectedType;
/*      */   }
/*      */ 
/*      */   
/*      */   public void setExpressionContext(ExpressionContext context) {
/* 1054 */     this.expressionContext = context;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isPolyExpression() {
/* 1067 */     return isPolyExpression(this.binding);
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isBoxingCompatibleWith(TypeBinding targetType, Scope scope) {
/* 1072 */     if (this.argumentsHaveErrors || this.binding == null || !this.binding.isValidBinding() || targetType == null || scope == null)
/* 1073 */       return false; 
/* 1074 */     if (isPolyExpression() && !targetType.isPrimitiveOrBoxedPrimitiveType())
/* 1075 */       return false; 
/* 1076 */     TypeBinding originalExpectedType = this.expectedType;
/*      */     try {
/* 1078 */       MethodBinding method = (this.solutionsPerTargetType != null) ? this.solutionsPerTargetType.get(targetType) : null;
/* 1079 */       if (method == null) {
/* 1080 */         this.expectedType = targetType;
/*      */         
/* 1082 */         method = isPolyExpression() ? ParameterizedGenericMethodBinding.computeCompatibleMethod18(this.binding.shallowOriginal(), this.argumentTypes, scope, this) : this.binding;
/* 1083 */         registerResult(targetType, method);
/*      */       } 
/* 1085 */       if (method == null || !method.isValidBinding() || method.returnType == null || !method.returnType.isValidBinding())
/* 1086 */         return false; 
/* 1087 */       return isBoxingCompatible(method.returnType.capture(scope, this.sourceStart, this.sourceEnd), targetType, this, scope);
/*      */     } finally {
/* 1089 */       this.expectedType = originalExpectedType;
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isCompatibleWith(TypeBinding targetType, Scope scope) {
/* 1095 */     if (this.argumentsHaveErrors || this.binding == null || !this.binding.isValidBinding() || targetType == null || scope == null)
/* 1096 */       return false; 
/* 1097 */     TypeBinding originalExpectedType = this.expectedType;
/*      */     try {
/* 1099 */       MethodBinding method = (this.solutionsPerTargetType != null) ? this.solutionsPerTargetType.get(targetType) : null;
/* 1100 */       if (method == null) {
/* 1101 */         this.expectedType = targetType;
/*      */         
/* 1103 */         method = isPolyExpression() ? ParameterizedGenericMethodBinding.computeCompatibleMethod18(this.binding.shallowOriginal(), this.argumentTypes, scope, this) : this.binding;
/* 1104 */         registerResult(targetType, method);
/*      */       } 
/*      */       TypeBinding returnType;
/* 1107 */       if (method == null || !method.isValidBinding() || (returnType = method.returnType) == null || !returnType.isValidBinding())
/* 1108 */         return false; 
/* 1109 */       if ((this.bits & 0x10000) != 0 && this.genericTypeArguments == null)
/* 1110 */         returnType = scope.environment().convertToRawType(returnType.erasure(), true); 
/* 1111 */       return returnType.capture(scope, this.sourceStart, this.sourceEnd).isCompatibleWith(targetType, scope);
/*      */     } finally {
/* 1113 */       this.expectedType = originalExpectedType;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isPolyExpression(MethodBinding resolutionCandidate) {
/* 1120 */     if (this.expressionContext != ExpressionContext.ASSIGNMENT_CONTEXT && this.expressionContext != ExpressionContext.INVOCATION_CONTEXT) {
/* 1121 */       return false;
/*      */     }
/* 1123 */     if (this.typeArguments != null && this.typeArguments.length > 0) {
/* 1124 */       return false;
/*      */     }
/* 1126 */     if (this.constant != Constant.NotAConstant) {
/* 1127 */       throw new UnsupportedOperationException("Unresolved MessageSend can't be queried if it is a polyexpression");
/*      */     }
/* 1129 */     if (resolutionCandidate != null) {
/* 1130 */       if (resolutionCandidate instanceof ParameterizedGenericMethodBinding) {
/* 1131 */         ParameterizedGenericMethodBinding pgmb = (ParameterizedGenericMethodBinding)resolutionCandidate;
/* 1132 */         if (pgmb.inferredReturnType)
/* 1133 */           return true; 
/*      */       } 
/* 1135 */       if (resolutionCandidate.returnType != null) {
/*      */         
/* 1137 */         MethodBinding candidateOriginal = resolutionCandidate.original();
/* 1138 */         return candidateOriginal.returnType.mentionsAny((TypeBinding[])candidateOriginal.typeVariables(), -1);
/*      */       } 
/*      */     } 
/*      */     
/* 1142 */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean sIsMoreSpecific(TypeBinding s, TypeBinding t, Scope scope) {
/* 1147 */     if (super.sIsMoreSpecific(s, t, scope))
/* 1148 */       return true; 
/* 1149 */     return isPolyExpression() ? ((!s.isBaseType() && t.isBaseType())) : false;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void setFieldIndex(int depth) {}
/*      */ 
/*      */   
/*      */   public TypeBinding invocationTargetType() {
/* 1158 */     return this.expectedType;
/*      */   }
/*      */ 
/*      */   
/*      */   public void traverse(ASTVisitor visitor, BlockScope blockScope) {
/* 1163 */     if (visitor.visit(this, blockScope)) {
/* 1164 */       this.receiver.traverse(visitor, blockScope);
/* 1165 */       if (this.typeArguments != null) {
/* 1166 */         for (int i = 0, typeArgumentsLength = this.typeArguments.length; i < typeArgumentsLength; i++) {
/* 1167 */           this.typeArguments[i].traverse(visitor, blockScope);
/*      */         }
/*      */       }
/* 1170 */       if (this.arguments != null) {
/* 1171 */         int argumentsLength = this.arguments.length;
/* 1172 */         for (int i = 0; i < argumentsLength; i++)
/* 1173 */           this.arguments[i].traverse(visitor, blockScope); 
/*      */       } 
/*      */     } 
/* 1176 */     visitor.endVisit(this, blockScope);
/*      */   }
/*      */   
/*      */   public boolean statementExpression() {
/* 1180 */     return ((this.bits & 0x1FE00000) == 0);
/*      */   }
/*      */   
/*      */   public boolean receiverIsImplicitThis() {
/* 1184 */     return this.receiver.isImplicitThis();
/*      */   }
/*      */ 
/*      */   
/*      */   public MethodBinding binding() {
/* 1189 */     return this.binding;
/*      */   }
/*      */ 
/*      */   
/*      */   public void registerInferenceContext(ParameterizedGenericMethodBinding method, InferenceContext18 infCtx18) {
/* 1194 */     if (this.inferenceContexts == null)
/* 1195 */       this.inferenceContexts = new SimpleLookupTable(); 
/* 1196 */     this.inferenceContexts.put(method, infCtx18);
/*      */   }
/*      */ 
/*      */   
/*      */   public void registerResult(TypeBinding targetType, MethodBinding method) {
/* 1201 */     if (this.solutionsPerTargetType == null)
/* 1202 */       this.solutionsPerTargetType = new HashMap<>(); 
/* 1203 */     this.solutionsPerTargetType.put(targetType, method);
/*      */   }
/*      */ 
/*      */   
/*      */   public InferenceContext18 getInferenceContext(ParameterizedMethodBinding method) {
/* 1208 */     if (this.inferenceContexts == null)
/* 1209 */       return null; 
/* 1210 */     return (InferenceContext18)this.inferenceContexts.get(method);
/*      */   }
/*      */   
/*      */   public void cleanUpInferenceContexts() {
/* 1214 */     if (this.inferenceContexts == null)
/*      */       return;  byte b; int i; Object[] arrayOfObject;
/* 1216 */     for (i = (arrayOfObject = this.inferenceContexts.valueTable).length, b = 0; b < i; ) { Object value = arrayOfObject[b];
/* 1217 */       if (value != null)
/* 1218 */         ((InferenceContext18)value).cleanUp();  b++; }
/* 1219 */      this.inferenceContexts = null;
/* 1220 */     this.outerInferenceContext = null;
/* 1221 */     this.solutionsPerTargetType = null;
/*      */   }
/*      */   
/*      */   public Expression[] arguments() {
/* 1225 */     return this.arguments;
/*      */   }
/*      */   
/*      */   public ExpressionContext getExpressionContext() {
/* 1229 */     return this.expressionContext;
/*      */   }
/*      */ 
/*      */   
/*      */   public InferenceContext18 freshInferenceContext(Scope scope) {
/* 1234 */     return new InferenceContext18(scope, this.arguments, this, this.outerInferenceContext);
/*      */   }
/*      */   
/*      */   public boolean isQualifiedSuper() {
/* 1238 */     return this.receiver.isQualifiedSuper();
/*      */   }
/*      */   
/*      */   public int nameSourceStart() {
/* 1242 */     return (int)(this.nameSourcePosition >>> 32L);
/*      */   }
/*      */   
/*      */   public int nameSourceEnd() {
/* 1246 */     return (int)this.nameSourcePosition;
/*      */   }
/*      */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\ast\MessageSend.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */