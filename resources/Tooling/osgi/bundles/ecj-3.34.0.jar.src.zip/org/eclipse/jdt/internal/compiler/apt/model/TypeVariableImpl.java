/*    */ package org.eclipse.jdt.internal.compiler.apt.model;
/*    */ 
/*    */ import javax.lang.model.element.Element;
/*    */ import javax.lang.model.type.TypeKind;
/*    */ import javax.lang.model.type.TypeMirror;
/*    */ import javax.lang.model.type.TypeVariable;
/*    */ import javax.lang.model.type.TypeVisitor;
/*    */ import org.eclipse.jdt.internal.compiler.apt.dispatch.BaseProcessingEnvImpl;
/*    */ import org.eclipse.jdt.internal.compiler.lookup.Binding;
/*    */ import org.eclipse.jdt.internal.compiler.lookup.ReferenceBinding;
/*    */ import org.eclipse.jdt.internal.compiler.lookup.TypeBinding;
/*    */ import org.eclipse.jdt.internal.compiler.lookup.TypeVariableBinding;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TypeVariableImpl
/*    */   extends TypeMirrorImpl
/*    */   implements TypeVariable
/*    */ {
/*    */   TypeVariableImpl(BaseProcessingEnvImpl env, TypeVariableBinding binding) {
/* 34 */     super(env, (Binding)binding);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Element asElement() {
/* 41 */     return this._env.getFactory().newElement(this._binding);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public TypeMirror getLowerBound() {
/* 50 */     return this._env.getFactory().getNullType();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public TypeMirror getUpperBound() {
/* 58 */     TypeVariableBinding typeVariableBinding = (TypeVariableBinding)this._binding;
/* 59 */     TypeBinding firstBound = typeVariableBinding.firstBound;
/* 60 */     ReferenceBinding[] superInterfaces = typeVariableBinding.superInterfaces;
/* 61 */     if (firstBound == null || superInterfaces.length == 0)
/*    */     {
/* 63 */       return this._env.getFactory().newTypeMirror((Binding)typeVariableBinding.upperBound());
/*    */     }
/* 65 */     if (firstBound != null && superInterfaces.length == 1 && TypeBinding.equalsEquals((TypeBinding)superInterfaces[0], firstBound))
/*    */     {
/* 67 */       return this._env.getFactory().newTypeMirror((Binding)typeVariableBinding.upperBound());
/*    */     }
/* 69 */     return this._env.getFactory().newTypeMirror(this._binding);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public <R, P> R accept(TypeVisitor<R, P> v, P p) {
/* 77 */     return v.visitTypeVariable(this, p);
/*    */   }
/*    */ 
/*    */   
/*    */   public TypeKind getKind() {
/* 82 */     return TypeKind.TYPEVAR;
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\apt\model\TypeVariableImpl.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */