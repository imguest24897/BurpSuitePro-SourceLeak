/*    */ package org.eclipse.jdt.internal.compiler.classfmt;
/*    */ 
/*    */ import org.eclipse.jdt.internal.compiler.env.IBinaryTypeAnnotation;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class ComponentInfoWithTypeAnnotation
/*    */   extends ComponentInfoWithAnnotation
/*    */ {
/*    */   private TypeAnnotationInfo[] typeAnnotations;
/*    */   
/*    */   ComponentInfoWithTypeAnnotation(RecordComponentInfo info, AnnotationInfo[] annos, TypeAnnotationInfo[] typeAnnos) {
/* 21 */     super(info, annos);
/* 22 */     this.typeAnnotations = typeAnnos;
/*    */   }
/*    */   
/*    */   public IBinaryTypeAnnotation[] getTypeAnnotations() {
/* 26 */     return (IBinaryTypeAnnotation[])this.typeAnnotations;
/*    */   }
/*    */   
/*    */   protected void initialize() {
/* 30 */     for (int i = 0, max = this.typeAnnotations.length; i < max; i++)
/* 31 */       this.typeAnnotations[i].initialize(); 
/* 32 */     super.initialize();
/*    */   }
/*    */   
/*    */   protected void reset() {
/* 36 */     if (this.typeAnnotations != null)
/* 37 */       for (int i = 0, max = this.typeAnnotations.length; i < max; i++)
/* 38 */         this.typeAnnotations[i].reset();  
/* 39 */     super.reset();
/*    */   }
/*    */   
/*    */   public String toString() {
/* 43 */     StringBuffer buffer = new StringBuffer(getClass().getName());
/* 44 */     if (this.typeAnnotations != null) {
/* 45 */       buffer.append('\n');
/* 46 */       buffer.append("type annotations:");
/* 47 */       for (int i = 0; i < this.typeAnnotations.length; i++) {
/* 48 */         buffer.append(this.typeAnnotations[i]);
/* 49 */         buffer.append('\n');
/*    */       } 
/*    */     } 
/* 52 */     toStringContent(buffer);
/* 53 */     return buffer.toString();
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\classfmt\ComponentInfoWithTypeAnnotation.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */