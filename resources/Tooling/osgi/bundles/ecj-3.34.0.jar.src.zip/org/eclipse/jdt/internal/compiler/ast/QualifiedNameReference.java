/*      */ package org.eclipse.jdt.internal.compiler.ast;
/*      */ 
/*      */ import org.eclipse.jdt.core.compiler.CharOperation;
/*      */ import org.eclipse.jdt.internal.compiler.ASTVisitor;
/*      */ import org.eclipse.jdt.internal.compiler.codegen.CodeStream;
/*      */ import org.eclipse.jdt.internal.compiler.flow.FlowContext;
/*      */ import org.eclipse.jdt.internal.compiler.flow.FlowInfo;
/*      */ import org.eclipse.jdt.internal.compiler.flow.UnconditionalFlowInfo;
/*      */ import org.eclipse.jdt.internal.compiler.impl.Constant;
/*      */ import org.eclipse.jdt.internal.compiler.lookup.BaseTypeBinding;
/*      */ import org.eclipse.jdt.internal.compiler.lookup.Binding;
/*      */ import org.eclipse.jdt.internal.compiler.lookup.BlockScope;
/*      */ import org.eclipse.jdt.internal.compiler.lookup.ClassScope;
/*      */ import org.eclipse.jdt.internal.compiler.lookup.FieldBinding;
/*      */ import org.eclipse.jdt.internal.compiler.lookup.LocalVariableBinding;
/*      */ import org.eclipse.jdt.internal.compiler.lookup.MethodBinding;
/*      */ import org.eclipse.jdt.internal.compiler.lookup.MethodScope;
/*      */ import org.eclipse.jdt.internal.compiler.lookup.ProblemFieldBinding;
/*      */ import org.eclipse.jdt.internal.compiler.lookup.ProblemReferenceBinding;
/*      */ import org.eclipse.jdt.internal.compiler.lookup.ReferenceBinding;
/*      */ import org.eclipse.jdt.internal.compiler.lookup.Scope;
/*      */ import org.eclipse.jdt.internal.compiler.lookup.SourceTypeBinding;
/*      */ import org.eclipse.jdt.internal.compiler.lookup.SyntheticMethodBinding;
/*      */ import org.eclipse.jdt.internal.compiler.lookup.TypeBinding;
/*      */ import org.eclipse.jdt.internal.compiler.lookup.VariableBinding;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class QualifiedNameReference
/*      */   extends NameReference
/*      */ {
/*      */   public char[][] tokens;
/*      */   public long[] sourcePositions;
/*      */   public FieldBinding[] otherBindings;
/*      */   int[] otherDepths;
/*      */   public int indexOfFirstFieldBinding;
/*      */   public SyntheticMethodBinding syntheticWriteAccessor;
/*      */   public SyntheticMethodBinding[] syntheticReadAccessors;
/*      */   public TypeBinding genericCast;
/*      */   public TypeBinding[] otherGenericCasts;
/*      */   
/*      */   public QualifiedNameReference(char[][] tokens, long[] positions, int sourceStart, int sourceEnd) {
/*   76 */     this.tokens = tokens;
/*   77 */     this.sourcePositions = positions;
/*   78 */     this.sourceStart = sourceStart;
/*   79 */     this.sourceEnd = sourceEnd;
/*      */   }
/*      */   
/*      */   public FlowInfo analyseAssignment(BlockScope currentScope, FlowContext flowContext, FlowInfo flowInfo, Assignment assignment, boolean isCompound) {
/*      */     UnconditionalFlowInfo unconditionalFlowInfo;
/*      */     LocalVariableBinding localBinding;
/*   85 */     int otherBindingsCount = (this.otherBindings == null) ? 0 : this.otherBindings.length;
/*   86 */     boolean needValue = !(otherBindingsCount != 0 && this.otherBindings[0].isStatic());
/*   87 */     boolean complyTo14 = ((currentScope.compilerOptions()).complianceLevel >= 3145728L);
/*   88 */     FieldBinding lastFieldBinding = null;
/*   89 */     switch (this.bits & 0x7) {
/*      */       case 1:
/*   91 */         lastFieldBinding = (FieldBinding)this.binding;
/*   92 */         if (needValue || complyTo14) {
/*   93 */           manageSyntheticAccessIfNecessary(currentScope, lastFieldBinding, 0, flowInfo);
/*      */         }
/*      */         
/*   96 */         if (lastFieldBinding.isBlankFinal() && 
/*   97 */           this.otherBindings != null && 
/*   98 */           currentScope.needBlankFinalFieldInitializationCheck(lastFieldBinding)) {
/*   99 */           FlowInfo fieldInits = flowContext.getInitsForFinalBlankInitializationCheck(lastFieldBinding.declaringClass.original(), flowInfo);
/*  100 */           if (!fieldInits.isDefinitelyAssigned(lastFieldBinding)) {
/*  101 */             currentScope.problemReporter().uninitializedBlankFinalField(lastFieldBinding, this);
/*      */           }
/*      */         } 
/*  104 */         if (needValue) {
/*  105 */           checkInternalNPE(currentScope, flowContext, flowInfo, true);
/*      */         }
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 2:
/*  112 */         if (!flowInfo.isDefinitelyAssigned(localBinding = (LocalVariableBinding)this.binding)) {
/*  113 */           currentScope.problemReporter().uninitializedLocalVariable(localBinding, this, (Scope)currentScope);
/*      */         }
/*  115 */         if ((flowInfo.tagBits & 0x3) == 0) {
/*  116 */           localBinding.useFlag = 1;
/*  117 */         } else if (localBinding.useFlag == 0) {
/*  118 */           localBinding.useFlag = 2;
/*      */         } 
/*  120 */         if (needValue) {
/*  121 */           checkInternalNPE(currentScope, flowContext, flowInfo, true);
/*      */         }
/*      */         break;
/*      */     } 
/*  125 */     if (needValue) {
/*  126 */       manageEnclosingInstanceAccessIfNecessary(currentScope, flowInfo);
/*      */     }
/*      */ 
/*      */     
/*  130 */     if (this.otherBindings != null) {
/*  131 */       for (int i = 0; i < otherBindingsCount - 1; i++) {
/*  132 */         lastFieldBinding = this.otherBindings[i];
/*  133 */         needValue = !this.otherBindings[i + 1].isStatic();
/*  134 */         if (needValue || complyTo14) {
/*  135 */           manageSyntheticAccessIfNecessary(currentScope, lastFieldBinding, i + 1, flowInfo);
/*      */         }
/*      */       } 
/*  138 */       lastFieldBinding = this.otherBindings[otherBindingsCount - 1];
/*      */     } 
/*      */     
/*  141 */     if (isCompound) {
/*  142 */       if (otherBindingsCount == 0 && 
/*  143 */         lastFieldBinding.isBlankFinal() && 
/*  144 */         currentScope.needBlankFinalFieldInitializationCheck(lastFieldBinding)) {
/*  145 */         FlowInfo fieldInits = flowContext.getInitsForFinalBlankInitializationCheck((TypeBinding)lastFieldBinding.declaringClass, flowInfo);
/*  146 */         if (!fieldInits.isDefinitelyAssigned(lastFieldBinding)) {
/*  147 */           currentScope.problemReporter().uninitializedBlankFinalField(lastFieldBinding, this);
/*      */         }
/*      */       } 
/*  150 */       manageSyntheticAccessIfNecessary(currentScope, lastFieldBinding, otherBindingsCount, flowInfo);
/*      */     } 
/*      */     
/*  153 */     if (assignment.expression != null) {
/*  154 */       unconditionalFlowInfo = 
/*  155 */         assignment
/*  156 */         .expression
/*  157 */         .analyseCode(currentScope, flowContext, flowInfo)
/*  158 */         .unconditionalInits();
/*      */     }
/*      */ 
/*      */     
/*  162 */     if (lastFieldBinding.isFinal())
/*      */     {
/*  164 */       if (otherBindingsCount == 0 && 
/*  165 */         this.indexOfFirstFieldBinding == 1 && 
/*  166 */         lastFieldBinding.isBlankFinal() && 
/*  167 */         !isCompound && 
/*  168 */         currentScope.allowBlankFinalFieldAssignment(lastFieldBinding)) {
/*  169 */         if (unconditionalFlowInfo.isPotentiallyAssigned(lastFieldBinding)) {
/*  170 */           currentScope.problemReporter().duplicateInitializationOfBlankFinalField(lastFieldBinding, this);
/*      */         } else {
/*  172 */           flowContext.recordSettingFinal((VariableBinding)lastFieldBinding, this, (FlowInfo)unconditionalFlowInfo);
/*      */         } 
/*  174 */         unconditionalFlowInfo.markAsDefinitelyAssigned(lastFieldBinding);
/*      */       } else {
/*  176 */         currentScope.problemReporter().cannotAssignToFinalField(lastFieldBinding, this);
/*  177 */         if (otherBindingsCount == 0 && currentScope.allowBlankFinalFieldAssignment(lastFieldBinding)) {
/*  178 */           unconditionalFlowInfo.markAsDefinitelyAssigned(lastFieldBinding);
/*      */         }
/*      */       } 
/*      */     }
/*      */     
/*  183 */     manageSyntheticAccessIfNecessary(currentScope, lastFieldBinding, -1, (FlowInfo)unconditionalFlowInfo);
/*      */     
/*  185 */     return (FlowInfo)unconditionalFlowInfo;
/*      */   }
/*      */ 
/*      */   
/*      */   public FlowInfo analyseCode(BlockScope currentScope, FlowContext flowContext, FlowInfo flowInfo) {
/*  190 */     return analyseCode(currentScope, flowContext, flowInfo, true);
/*      */   }
/*      */   
/*      */   public FlowInfo analyseCode(BlockScope currentScope, FlowContext flowContext, FlowInfo flowInfo, boolean valueRequired) {
/*      */     FieldBinding fieldBinding;
/*      */     LocalVariableBinding localBinding;
/*  196 */     int otherBindingsCount = (this.otherBindings == null) ? 0 : this.otherBindings.length;
/*      */     
/*  198 */     boolean needValue = (otherBindingsCount == 0) ? valueRequired : (!this.otherBindings[0].isStatic());
/*  199 */     boolean complyTo14 = ((currentScope.compilerOptions()).complianceLevel >= 3145728L);
/*  200 */     switch (this.bits & 0x7) {
/*      */       case 1:
/*  202 */         if (needValue || complyTo14) {
/*  203 */           manageSyntheticAccessIfNecessary(currentScope, (FieldBinding)this.binding, 0, flowInfo);
/*      */         }
/*  205 */         fieldBinding = (FieldBinding)this.binding;
/*  206 */         if (this.indexOfFirstFieldBinding == 1)
/*      */         {
/*  208 */           if (fieldBinding.isBlankFinal() && 
/*  209 */             currentScope.needBlankFinalFieldInitializationCheck(fieldBinding)) {
/*  210 */             FlowInfo fieldInits = flowContext.getInitsForFinalBlankInitializationCheck(fieldBinding.declaringClass.original(), flowInfo);
/*  211 */             if (!fieldInits.isDefinitelyAssigned(fieldBinding)) {
/*  212 */               currentScope.problemReporter().uninitializedBlankFinalField(fieldBinding, this);
/*      */             }
/*      */           } 
/*      */         }
/*      */         break;
/*      */       
/*      */       case 2:
/*  219 */         if (!flowInfo.isDefinitelyAssigned(localBinding = (LocalVariableBinding)this.binding)) {
/*  220 */           currentScope.problemReporter().uninitializedLocalVariable(localBinding, this, (Scope)currentScope);
/*      */         }
/*  222 */         if ((flowInfo.tagBits & 0x3) == 0) {
/*  223 */           localBinding.useFlag = 1; break;
/*  224 */         }  if (localBinding.useFlag == 0)
/*  225 */           localBinding.useFlag = 2; 
/*      */         break;
/*      */     } 
/*  228 */     if (needValue) {
/*  229 */       checkInternalNPE(currentScope, flowContext, flowInfo, true);
/*      */     }
/*  231 */     if (needValue) {
/*  232 */       manageEnclosingInstanceAccessIfNecessary(currentScope, flowInfo);
/*      */     }
/*      */     
/*  235 */     if (this.otherBindings != null) {
/*  236 */       for (int i = 0; i < otherBindingsCount; i++) {
/*  237 */         needValue = (i < otherBindingsCount - 1) ? (!this.otherBindings[i + 1].isStatic()) : valueRequired;
/*  238 */         if (needValue || complyTo14) {
/*  239 */           manageSyntheticAccessIfNecessary(currentScope, this.otherBindings[i], i + 1, flowInfo);
/*      */         }
/*      */       } 
/*      */     }
/*  243 */     return flowInfo;
/*      */   }
/*      */ 
/*      */   
/*      */   private void checkInternalNPE(BlockScope scope, FlowContext flowContext, FlowInfo flowInfo, boolean checkString) {
/*  248 */     if ((this.bits & 0x7) == 2) {
/*  249 */       LocalVariableBinding local = (LocalVariableBinding)this.binding;
/*  250 */       if (local != null && (
/*  251 */         local.type.tagBits & 0x2L) == 0L && (
/*  252 */         checkString || local.type.id != 11)) {
/*  253 */         if ((this.bits & 0x20000) == 0) {
/*  254 */           flowContext.recordUsingNullReference((Scope)scope, local, this, 
/*  255 */               3, flowInfo);
/*      */         }
/*  257 */         flowInfo.markAsComparedEqualToNonNull(local);
/*      */         
/*  259 */         flowContext.markFinallyNullStatus(local, 4);
/*      */       } 
/*      */     } 
/*  262 */     if (this.otherBindings != null) {
/*  263 */       if ((this.bits & 0x7) == 1)
/*      */       {
/*  265 */         checkNullableFieldDereference((Scope)scope, (FieldBinding)this.binding, this.sourcePositions[this.indexOfFirstFieldBinding - 1], flowContext, 0);
/*      */       }
/*      */       
/*  268 */       int length = this.otherBindings.length - 1;
/*  269 */       for (int i = 0; i < length; i++) {
/*  270 */         checkNullableFieldDereference((Scope)scope, this.otherBindings[i], this.sourcePositions[this.indexOfFirstFieldBinding + i], flowContext, 0);
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean checkNPE(BlockScope scope, FlowContext flowContext, FlowInfo flowInfo, int ttlForFieldCheck) {
/*  277 */     if (super.checkNPE(scope, flowContext, flowInfo, ttlForFieldCheck)) {
/*  278 */       return true;
/*      */     }
/*  280 */     FieldBinding fieldBinding = null;
/*  281 */     long position = 0L;
/*  282 */     if (this.otherBindings == null) {
/*  283 */       if ((this.bits & 0x7) == 1) {
/*  284 */         fieldBinding = (FieldBinding)this.binding;
/*  285 */         position = this.sourcePositions[0];
/*      */       } 
/*      */     } else {
/*  288 */       fieldBinding = this.otherBindings[this.otherBindings.length - 1];
/*  289 */       position = this.sourcePositions[this.sourcePositions.length - 1];
/*      */     } 
/*  291 */     if (fieldBinding != null) {
/*  292 */       return checkNullableFieldDereference((Scope)scope, fieldBinding, position, flowContext, ttlForFieldCheck);
/*      */     }
/*  294 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void computeConversion(Scope scope, TypeBinding runtimeTimeType, TypeBinding compileTimeType) {
/*  302 */     if (runtimeTimeType == null || compileTimeType == null) {
/*      */       return;
/*      */     }
/*  305 */     FieldBinding field = null;
/*  306 */     int length = (this.otherBindings == null) ? 0 : this.otherBindings.length;
/*  307 */     if (length == 0) {
/*  308 */       if ((this.bits & 0x1) != 0 && this.binding != null && this.binding.isValidBinding()) {
/*  309 */         field = (FieldBinding)this.binding;
/*      */       }
/*      */     } else {
/*  312 */       field = this.otherBindings[length - 1];
/*      */     } 
/*  314 */     if (field != null) {
/*  315 */       FieldBinding originalBinding = field.original();
/*  316 */       TypeBinding originalType = originalBinding.type;
/*      */       
/*  318 */       if (originalType.leafComponentType().isTypeVariable()) {
/*  319 */         TypeBinding targetType = (!compileTimeType.isBaseType() && runtimeTimeType.isBaseType()) ? 
/*  320 */           compileTimeType : 
/*  321 */           runtimeTimeType;
/*  322 */         TypeBinding typeCast = originalType.genericCast(targetType);
/*  323 */         setGenericCast(length, typeCast);
/*  324 */         if (typeCast instanceof ReferenceBinding) {
/*  325 */           ReferenceBinding referenceCast = (ReferenceBinding)typeCast;
/*  326 */           if (!referenceCast.canBeSeenBy(scope)) {
/*  327 */             scope.problemReporter().invalidType(this, 
/*  328 */                 (TypeBinding)new ProblemReferenceBinding(
/*  329 */                   CharOperation.splitOn('.', referenceCast.shortReadableName()), 
/*  330 */                   referenceCast, 
/*  331 */                   2));
/*      */           }
/*      */         } 
/*      */       } 
/*      */     } 
/*  336 */     super.computeConversion(scope, runtimeTimeType, compileTimeType);
/*      */   }
/*      */ 
/*      */   
/*      */   public void generateAssignment(BlockScope currentScope, CodeStream codeStream, Assignment assignment, boolean valueRequired) {
/*  341 */     int pc = codeStream.position;
/*  342 */     FieldBinding lastFieldBinding = generateReadSequence(currentScope, codeStream);
/*  343 */     codeStream.recordPositionsFrom(pc, this.sourceStart);
/*  344 */     assignment.expression.generateCode(currentScope, codeStream, true);
/*  345 */     fieldStore((Scope)currentScope, codeStream, lastFieldBinding, (MethodBinding)this.syntheticWriteAccessor, getFinalReceiverType(), false, valueRequired);
/*      */     
/*  347 */     if (valueRequired) {
/*  348 */       codeStream.generateImplicitConversion(assignment.implicitConversion);
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   public void generateCode(BlockScope currentScope, CodeStream codeStream, boolean valueRequired) {
/*  354 */     int pc = codeStream.position;
/*  355 */     if (this.constant != Constant.NotAConstant) {
/*  356 */       if (valueRequired) {
/*  357 */         codeStream.generateConstant(this.constant, this.implicitConversion);
/*      */       }
/*      */     } else {
/*  360 */       FieldBinding lastFieldBinding = generateReadSequence(currentScope, codeStream);
/*  361 */       if (lastFieldBinding != null) {
/*  362 */         boolean isStatic = lastFieldBinding.isStatic();
/*  363 */         Constant fieldConstant = lastFieldBinding.constant();
/*  364 */         if (fieldConstant != Constant.NotAConstant) {
/*  365 */           if (!isStatic) {
/*  366 */             codeStream.invokeObjectGetClass();
/*  367 */             codeStream.pop();
/*      */           } 
/*  369 */           if (valueRequired) {
/*  370 */             codeStream.generateConstant(fieldConstant, this.implicitConversion);
/*      */           }
/*      */         } else {
/*  373 */           boolean isFirst = (lastFieldBinding == this.binding && (
/*  374 */             this.indexOfFirstFieldBinding == 1 || TypeBinding.equalsEquals((TypeBinding)lastFieldBinding.declaringClass, (TypeBinding)currentScope.enclosingReceiverType())) && 
/*  375 */             this.otherBindings == null);
/*  376 */           TypeBinding requiredGenericCast = getGenericCast((this.otherBindings == null) ? 0 : this.otherBindings.length);
/*  377 */           if (valueRequired || (
/*  378 */             !isFirst && (currentScope.compilerOptions()).complianceLevel >= 3145728L) || (
/*  379 */             this.implicitConversion & 0x400) != 0 || 
/*  380 */             requiredGenericCast != null) {
/*  381 */             int lastFieldPc = codeStream.position;
/*  382 */             if (lastFieldBinding.declaringClass == null) {
/*  383 */               codeStream.arraylength();
/*  384 */               if (valueRequired) {
/*  385 */                 codeStream.generateImplicitConversion(this.implicitConversion);
/*      */               } else {
/*      */                 
/*  388 */                 codeStream.pop();
/*      */               } 
/*      */             } else {
/*  391 */               SyntheticMethodBinding accessor = (this.syntheticReadAccessors == null) ? null : this.syntheticReadAccessors[this.syntheticReadAccessors.length - 1];
/*  392 */               if (accessor == null) {
/*  393 */                 TypeBinding constantPoolDeclaringClass = CodeStream.getConstantPoolDeclaringClass((Scope)currentScope, lastFieldBinding, getFinalReceiverType(), isFirst);
/*  394 */                 if (isStatic) {
/*  395 */                   codeStream.fieldAccess((byte)-78, lastFieldBinding, constantPoolDeclaringClass);
/*      */                 } else {
/*  397 */                   codeStream.fieldAccess((byte)-76, lastFieldBinding, constantPoolDeclaringClass);
/*      */                 } 
/*      */               } else {
/*  400 */                 codeStream.invoke((byte)-72, (MethodBinding)accessor, null);
/*      */               } 
/*  402 */               if (requiredGenericCast != null) codeStream.checkcast(requiredGenericCast); 
/*  403 */               if (valueRequired) {
/*  404 */                 codeStream.generateImplicitConversion(this.implicitConversion);
/*      */               } else {
/*  406 */                 boolean isUnboxing = ((this.implicitConversion & 0x400) != 0);
/*      */                 
/*  408 */                 if (isUnboxing) codeStream.generateImplicitConversion(this.implicitConversion); 
/*  409 */                 switch (isUnboxing ? (postConversionType((Scope)currentScope)).id : lastFieldBinding.type.id) {
/*      */                   case 7:
/*      */                   case 8:
/*  412 */                     codeStream.pop2();
/*      */                     break;
/*      */                   default:
/*  415 */                     codeStream.pop();
/*      */                     break;
/*      */                 } 
/*      */               
/*      */               } 
/*      */             } 
/*  421 */             int fieldPosition = (int)(this.sourcePositions[this.sourcePositions.length - 1] >>> 32L);
/*  422 */             codeStream.recordPositionsFrom(lastFieldPc, fieldPosition);
/*      */           }
/*  424 */           else if (!isStatic) {
/*  425 */             codeStream.invokeObjectGetClass();
/*  426 */             codeStream.pop();
/*      */           } 
/*      */         } 
/*      */       } 
/*      */     } 
/*      */     
/*  432 */     codeStream.recordPositionsFrom(pc, this.sourceStart);
/*      */   }
/*      */   
/*      */   public void generateCompoundAssignment(BlockScope currentScope, CodeStream codeStream, Expression expression, int operator, int assignmentImplicitConversion, boolean valueRequired) {
/*      */     TypeBinding requiredGenericCast;
/*  437 */     FieldBinding lastFieldBinding = generateReadSequence(currentScope, codeStream);
/*      */     
/*  439 */     reportOnlyUselesslyReadPrivateField(currentScope, lastFieldBinding, valueRequired);
/*  440 */     boolean isFirst = (lastFieldBinding == this.binding && (
/*  441 */       this.indexOfFirstFieldBinding == 1 || TypeBinding.equalsEquals((TypeBinding)lastFieldBinding.declaringClass, (TypeBinding)currentScope.enclosingReceiverType())) && 
/*  442 */       this.otherBindings == null);
/*  443 */     TypeBinding constantPoolDeclaringClass = CodeStream.getConstantPoolDeclaringClass((Scope)currentScope, lastFieldBinding, getFinalReceiverType(), isFirst);
/*  444 */     SyntheticMethodBinding accessor = (this.syntheticReadAccessors == null) ? null : this.syntheticReadAccessors[this.syntheticReadAccessors.length - 1];
/*  445 */     if (lastFieldBinding.isStatic()) {
/*  446 */       if (accessor == null) {
/*  447 */         codeStream.fieldAccess((byte)-78, lastFieldBinding, constantPoolDeclaringClass);
/*      */       } else {
/*  449 */         codeStream.invoke((byte)-72, (MethodBinding)accessor, null);
/*      */       } 
/*      */     } else {
/*  452 */       codeStream.dup();
/*  453 */       if (accessor == null) {
/*  454 */         codeStream.fieldAccess((byte)-76, lastFieldBinding, constantPoolDeclaringClass);
/*      */       } else {
/*  456 */         codeStream.invoke((byte)-72, (MethodBinding)accessor, null);
/*      */       } 
/*      */     } 
/*      */     
/*      */     int operationTypeID;
/*      */     
/*  462 */     switch (operationTypeID = (this.implicitConversion & 0xFF) >> 4) {
/*      */       case 0:
/*      */       case 1:
/*      */       case 11:
/*  466 */         codeStream.generateStringConcatenationAppend(currentScope, null, expression);
/*      */         break;
/*      */       default:
/*  469 */         requiredGenericCast = getGenericCast((this.otherBindings == null) ? 0 : this.otherBindings.length);
/*  470 */         if (requiredGenericCast != null) codeStream.checkcast(requiredGenericCast);
/*      */         
/*  472 */         codeStream.generateImplicitConversion(this.implicitConversion);
/*      */         
/*  474 */         if (expression == IntLiteral.One) {
/*  475 */           codeStream.generateConstant(expression.constant, this.implicitConversion);
/*      */         } else {
/*  477 */           expression.generateCode(currentScope, codeStream, true);
/*      */         } 
/*      */         
/*  480 */         codeStream.sendOperator(operator, operationTypeID);
/*      */         
/*  482 */         codeStream.generateImplicitConversion(assignmentImplicitConversion);
/*      */         break;
/*      */     } 
/*  485 */     fieldStore((Scope)currentScope, codeStream, lastFieldBinding, (MethodBinding)this.syntheticWriteAccessor, getFinalReceiverType(), false, valueRequired);
/*      */   }
/*      */ 
/*      */   
/*      */   public void generatePostIncrement(BlockScope currentScope, CodeStream codeStream, CompoundAssignment postIncrement, boolean valueRequired) {
/*      */     TypeBinding operandType;
/*  491 */     FieldBinding lastFieldBinding = generateReadSequence(currentScope, codeStream);
/*      */     
/*  493 */     reportOnlyUselesslyReadPrivateField(currentScope, lastFieldBinding, valueRequired);
/*  494 */     boolean isFirst = (lastFieldBinding == this.binding && (
/*  495 */       this.indexOfFirstFieldBinding == 1 || TypeBinding.equalsEquals((TypeBinding)lastFieldBinding.declaringClass, (TypeBinding)currentScope.enclosingReceiverType())) && 
/*  496 */       this.otherBindings == null);
/*  497 */     TypeBinding constantPoolDeclaringClass = CodeStream.getConstantPoolDeclaringClass((Scope)currentScope, lastFieldBinding, getFinalReceiverType(), isFirst);
/*  498 */     SyntheticMethodBinding accessor = (this.syntheticReadAccessors == null) ? 
/*  499 */       null : 
/*  500 */       this.syntheticReadAccessors[this.syntheticReadAccessors.length - 1];
/*  501 */     if (lastFieldBinding.isStatic()) {
/*  502 */       if (accessor == null) {
/*  503 */         codeStream.fieldAccess((byte)-78, lastFieldBinding, constantPoolDeclaringClass);
/*      */       } else {
/*  505 */         codeStream.invoke((byte)-72, (MethodBinding)accessor, constantPoolDeclaringClass);
/*      */       } 
/*      */     } else {
/*  508 */       codeStream.dup();
/*  509 */       if (accessor == null) {
/*  510 */         codeStream.fieldAccess((byte)-76, lastFieldBinding, null);
/*      */       } else {
/*  512 */         codeStream.invoke((byte)-72, (MethodBinding)accessor, null);
/*      */       } 
/*      */     } 
/*  515 */     TypeBinding requiredGenericCast = getGenericCast((this.otherBindings == null) ? 0 : this.otherBindings.length);
/*      */     
/*  517 */     if (requiredGenericCast != null) {
/*  518 */       codeStream.checkcast(requiredGenericCast);
/*  519 */       operandType = requiredGenericCast;
/*      */     } else {
/*  521 */       operandType = lastFieldBinding.type;
/*      */     } 
/*      */     
/*  524 */     if (valueRequired) {
/*  525 */       if (lastFieldBinding.isStatic()) {
/*  526 */         switch (operandType.id) {
/*      */           case 7:
/*      */           case 8:
/*  529 */             codeStream.dup2();
/*      */             break;
/*      */           default:
/*  532 */             codeStream.dup();
/*      */             break;
/*      */         } 
/*      */       } else {
/*  536 */         switch (operandType.id) {
/*      */           case 7:
/*      */           case 8:
/*  539 */             codeStream.dup2_x1();
/*      */             break;
/*      */           default:
/*  542 */             codeStream.dup_x1();
/*      */             break;
/*      */         } 
/*      */       } 
/*      */     }
/*  547 */     codeStream.generateImplicitConversion(this.implicitConversion);
/*  548 */     codeStream.generateConstant(
/*  549 */         postIncrement.expression.constant, 
/*  550 */         this.implicitConversion);
/*  551 */     codeStream.sendOperator(postIncrement.operator, this.implicitConversion & 0xF);
/*  552 */     codeStream.generateImplicitConversion(
/*  553 */         postIncrement.preAssignImplicitConversion);
/*  554 */     fieldStore((Scope)currentScope, codeStream, lastFieldBinding, (MethodBinding)this.syntheticWriteAccessor, getFinalReceiverType(), false, false);
/*      */   }
/*      */ 
/*      */   
/*      */   public FieldBinding generateReadSequence(BlockScope currentScope, CodeStream codeStream) {
/*      */     FieldBinding lastFieldBinding;
/*      */     TypeBinding lastGenericCast, lastReceiverType;
/*      */     LocalVariableBinding localBinding;
/*      */     Constant localConstant;
/*  563 */     int otherBindingsCount = (this.otherBindings == null) ? 0 : this.otherBindings.length;
/*  564 */     boolean needValue = !(otherBindingsCount != 0 && this.otherBindings[0].isStatic());
/*      */ 
/*      */ 
/*      */     
/*  568 */     boolean complyTo14 = ((currentScope.compilerOptions()).complianceLevel >= 3145728L);
/*      */     
/*  570 */     switch (this.bits & 0x7) {
/*      */       case 1:
/*  572 */         lastFieldBinding = ((FieldBinding)this.binding).original();
/*  573 */         lastGenericCast = this.genericCast;
/*  574 */         lastReceiverType = this.actualReceiverType;
/*      */         
/*  576 */         if (lastFieldBinding.constant() != Constant.NotAConstant) {
/*      */           break;
/*      */         }
/*  579 */         if ((needValue && !lastFieldBinding.isStatic()) || lastGenericCast != null) {
/*  580 */           int pc = codeStream.position;
/*  581 */           if ((this.bits & 0x1FE0) != 0) {
/*  582 */             ReferenceBinding targetType = currentScope.enclosingSourceType().enclosingTypeAt((this.bits & 0x1FE0) >> 5);
/*  583 */             Object[] emulationPath = currentScope.getEmulationPath(targetType, true, false);
/*  584 */             codeStream.generateOuterAccess(emulationPath, this, (Binding)targetType, (Scope)currentScope);
/*      */           } else {
/*  586 */             generateReceiver(codeStream);
/*      */           } 
/*  588 */           codeStream.recordPositionsFrom(pc, this.sourceStart);
/*      */         } 
/*      */         break;
/*      */       case 2:
/*  592 */         lastFieldBinding = null;
/*  593 */         lastGenericCast = null;
/*  594 */         localBinding = (LocalVariableBinding)this.binding;
/*  595 */         lastReceiverType = localBinding.type;
/*  596 */         if (!needValue)
/*      */           break; 
/*  598 */         localConstant = localBinding.constant();
/*  599 */         if (localConstant != Constant.NotAConstant) {
/*  600 */           codeStream.generateConstant(localConstant, 0);
/*      */           
/*      */           break;
/*      */         } 
/*  604 */         if (checkEffectiveFinality((VariableBinding)localBinding, (Scope)currentScope)) {
/*      */           
/*  606 */           VariableBinding[] path = currentScope.getEmulationPath(localBinding);
/*  607 */           codeStream.generateOuterAccess((Object[])path, this, (Binding)localBinding, (Scope)currentScope); break;
/*      */         } 
/*  609 */         codeStream.load(localBinding);
/*      */         break;
/*      */ 
/*      */       
/*      */       default:
/*  614 */         return null;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  619 */     int positionsLength = this.sourcePositions.length;
/*  620 */     FieldBinding initialFieldBinding = lastFieldBinding;
/*  621 */     if (this.otherBindings != null) {
/*  622 */       for (int i = 0; i < otherBindingsCount; i++) {
/*  623 */         int pc = codeStream.position;
/*  624 */         FieldBinding nextField = this.otherBindings[i].original();
/*  625 */         TypeBinding nextGenericCast = (this.otherGenericCasts == null) ? null : this.otherGenericCasts[i];
/*  626 */         if (lastFieldBinding != null) {
/*  627 */           needValue = !nextField.isStatic();
/*  628 */           Constant fieldConstant = lastFieldBinding.constant();
/*  629 */           if (fieldConstant != Constant.NotAConstant) {
/*  630 */             if (i > 0 && !lastFieldBinding.isStatic()) {
/*  631 */               codeStream.invokeObjectGetClass();
/*  632 */               codeStream.pop();
/*      */             } 
/*  634 */             if (needValue) {
/*  635 */               codeStream.generateConstant(fieldConstant, 0);
/*      */             }
/*      */           } else {
/*  638 */             if (needValue || (i > 0 && complyTo14) || lastGenericCast != null) {
/*  639 */               SyntheticMethodBinding syntheticMethodBinding = (this.syntheticReadAccessors == null) ? null : this.syntheticReadAccessors[i];
/*  640 */               if (syntheticMethodBinding == null) {
/*  641 */                 TypeBinding constantPoolDeclaringClass = CodeStream.getConstantPoolDeclaringClass((Scope)currentScope, lastFieldBinding, lastReceiverType, (i == 0 && this.indexOfFirstFieldBinding == 1));
/*  642 */                 if (lastFieldBinding.isStatic()) {
/*  643 */                   codeStream.fieldAccess((byte)-78, lastFieldBinding, constantPoolDeclaringClass);
/*      */                 } else {
/*  645 */                   codeStream.fieldAccess((byte)-76, lastFieldBinding, constantPoolDeclaringClass);
/*      */                 } 
/*      */               } else {
/*  648 */                 codeStream.invoke((byte)-72, (MethodBinding)syntheticMethodBinding, null);
/*      */               } 
/*  650 */               if (lastGenericCast != null) {
/*  651 */                 codeStream.checkcast(lastGenericCast);
/*  652 */                 lastReceiverType = lastGenericCast;
/*      */               } else {
/*  654 */                 lastReceiverType = lastFieldBinding.type;
/*      */               } 
/*  656 */               if (!needValue) codeStream.pop(); 
/*      */             } else {
/*  658 */               if (lastFieldBinding == initialFieldBinding) {
/*  659 */                 if (lastFieldBinding.isStatic())
/*      */                 {
/*  661 */                   if (TypeBinding.notEquals((TypeBinding)initialFieldBinding.declaringClass, this.actualReceiverType.erasure())) {
/*  662 */                     SyntheticMethodBinding syntheticMethodBinding = (this.syntheticReadAccessors == null) ? null : this.syntheticReadAccessors[i];
/*  663 */                     if (syntheticMethodBinding == null) {
/*  664 */                       TypeBinding constantPoolDeclaringClass = CodeStream.getConstantPoolDeclaringClass((Scope)currentScope, lastFieldBinding, lastReceiverType, (i == 0 && this.indexOfFirstFieldBinding == 1));
/*  665 */                       codeStream.fieldAccess((byte)-78, lastFieldBinding, constantPoolDeclaringClass);
/*      */                     } else {
/*  667 */                       codeStream.invoke((byte)-72, (MethodBinding)syntheticMethodBinding, null);
/*      */                     } 
/*  669 */                     codeStream.pop();
/*      */                   } 
/*      */                 }
/*  672 */               } else if (!lastFieldBinding.isStatic()) {
/*  673 */                 codeStream.invokeObjectGetClass();
/*  674 */                 codeStream.pop();
/*      */               } 
/*  676 */               lastReceiverType = lastFieldBinding.type;
/*      */             } 
/*  678 */             if (positionsLength - otherBindingsCount + i - 1 >= 0) {
/*  679 */               int fieldPosition = (int)(this.sourcePositions[positionsLength - otherBindingsCount + i - 1] >>> 32L);
/*  680 */               codeStream.recordPositionsFrom(pc, fieldPosition);
/*      */             } 
/*      */           } 
/*      */         } 
/*  684 */         lastFieldBinding = nextField;
/*  685 */         lastGenericCast = nextGenericCast;
/*      */       } 
/*      */     }
/*  688 */     return lastFieldBinding;
/*      */   }
/*      */   
/*      */   public void generateReceiver(CodeStream codeStream) {
/*  692 */     codeStream.aload_0();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public TypeBinding[] genericTypeArguments() {
/*  700 */     return null;
/*      */   }
/*      */   
/*      */   protected FieldBinding getCodegenBinding(int index) {
/*  704 */     if (index == 0) {
/*  705 */       return ((FieldBinding)this.binding).original();
/*      */     }
/*  707 */     return this.otherBindings[index - 1].original();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected TypeBinding getFinalReceiverType() {
/*  716 */     int otherBindingsCount = (this.otherBindings == null) ? 0 : this.otherBindings.length;
/*  717 */     switch (otherBindingsCount) {
/*      */       case 0:
/*  719 */         return this.actualReceiverType;
/*      */       case 1:
/*  721 */         return (this.genericCast != null) ? this.genericCast : ((VariableBinding)this.binding).type;
/*      */     } 
/*  723 */     TypeBinding previousGenericCast = (this.otherGenericCasts == null) ? null : this.otherGenericCasts[otherBindingsCount - 2];
/*  724 */     return (previousGenericCast != null) ? previousGenericCast : (this.otherBindings[otherBindingsCount - 2]).type;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected TypeBinding getGenericCast(int index) {
/*  730 */     if (index == 0) {
/*  731 */       return this.genericCast;
/*      */     }
/*  733 */     if (this.otherGenericCasts == null) return null; 
/*  734 */     return this.otherGenericCasts[index - 1];
/*      */   }
/*      */ 
/*      */   
/*      */   public TypeBinding getOtherFieldBindings(BlockScope scope) {
/*  739 */     int length = this.tokens.length;
/*  740 */     FieldBinding field = ((this.bits & 0x1) != 0) ? (FieldBinding)this.binding : null;
/*  741 */     TypeBinding type = ((VariableBinding)this.binding).type;
/*  742 */     int index = this.indexOfFirstFieldBinding;
/*  743 */     if (index == length) {
/*  744 */       this.constant = ((FieldBinding)this.binding).constant((Scope)scope);
/*      */       
/*  746 */       return (type != null && (this.bits & 0x2000) == 0) ? 
/*  747 */         type.capture((Scope)scope, this.sourceStart, this.sourceEnd) : 
/*  748 */         type;
/*      */     } 
/*      */     
/*  751 */     int otherBindingsLength = length - index;
/*  752 */     this.otherBindings = new FieldBinding[otherBindingsLength];
/*  753 */     this.otherDepths = new int[otherBindingsLength];
/*      */ 
/*      */     
/*  756 */     this.constant = ((VariableBinding)this.binding).constant((Scope)scope);
/*      */     
/*  758 */     int firstDepth = (this.bits & 0x1FE0) >> 5;
/*      */     
/*  760 */     while (index < length) {
/*  761 */       char[] token = this.tokens[index];
/*  762 */       if (type == null) {
/*  763 */         return null;
/*      */       }
/*  765 */       this.bits &= 0xFFFFE01F;
/*  766 */       FieldBinding previousField = field;
/*  767 */       field = scope.getField(type.capture((Scope)scope, (int)(this.sourcePositions[index] >>> 32L), (int)this.sourcePositions[index]), token, this);
/*  768 */       int place = index - this.indexOfFirstFieldBinding;
/*  769 */       this.otherBindings[place] = field;
/*  770 */       this.otherDepths[place] = (this.bits & 0x1FE0) >> 5;
/*  771 */       if (field.isValidBinding()) {
/*      */         
/*  773 */         if (previousField != null) {
/*  774 */           TypeBinding fieldReceiverType = type;
/*  775 */           TypeBinding oldReceiverType = fieldReceiverType;
/*  776 */           fieldReceiverType = fieldReceiverType.getErasureCompatibleType((TypeBinding)field.declaringClass);
/*  777 */           FieldBinding originalBinding = previousField.original();
/*  778 */           if (TypeBinding.notEquals(fieldReceiverType, oldReceiverType) || originalBinding.type.leafComponentType().isTypeVariable()) {
/*  779 */             setGenericCast(index - 1, originalBinding.type.genericCast(fieldReceiverType));
/*      */           }
/*      */         } 
/*      */         
/*  783 */         if (isFieldUseDeprecated(field, (Scope)scope, (index + 1 == length) ? this.bits : 0)) {
/*  784 */           scope.problemReporter().deprecatedField(field, this);
/*      */         }
/*      */         
/*  787 */         if (this.constant != Constant.NotAConstant) {
/*  788 */           this.constant = field.constant((Scope)scope);
/*      */         }
/*      */         
/*  791 */         if (field.isStatic()) {
/*  792 */           if ((field.modifiers & 0x4000) != 0 && scope.kind != 5) {
/*      */             
/*  794 */             ReferenceBinding declaringClass = (field.original()).declaringClass;
/*  795 */             MethodScope methodScope = scope.methodScope();
/*  796 */             SourceTypeBinding sourceType = methodScope.enclosingSourceType();
/*  797 */             if ((this.bits & 0x2000) == 0 && 
/*  798 */               TypeBinding.equalsEquals((TypeBinding)sourceType, (TypeBinding)declaringClass) && 
/*  799 */               methodScope.lastVisibleFieldID >= 0 && 
/*  800 */               field.id >= methodScope.lastVisibleFieldID && (
/*  801 */               !field.isStatic() || methodScope.isStatic)) {
/*  802 */               scope.problemReporter().forwardReference(this, index, field);
/*      */             }
/*      */             
/*  805 */             if ((TypeBinding.equalsEquals((TypeBinding)sourceType, (TypeBinding)declaringClass) || TypeBinding.equalsEquals((TypeBinding)sourceType.superclass, (TypeBinding)declaringClass)) && 
/*  806 */               field.constant((Scope)scope) == Constant.NotAConstant && 
/*  807 */               !methodScope.isStatic && 
/*  808 */               methodScope.isInsideInitializerOrConstructor()) {
/*  809 */               scope.problemReporter().enumStaticFieldUsedDuringInitialization(field, this);
/*      */             }
/*      */           } 
/*      */           
/*  813 */           scope.problemReporter().nonStaticAccessToStaticField(this, field, index);
/*      */           
/*  815 */           if (TypeBinding.notEquals((TypeBinding)field.declaringClass, type)) {
/*  816 */             scope.problemReporter().indirectAccessToStaticField(this, field);
/*      */           }
/*      */         } 
/*  819 */         type = field.type;
/*  820 */         index++; continue;
/*      */       } 
/*  822 */       this.constant = Constant.NotAConstant;
/*  823 */       scope.problemReporter().invalidField(this, field, index, type);
/*  824 */       setDepth(firstDepth);
/*  825 */       return null;
/*      */     } 
/*      */     
/*  828 */     setDepth(firstDepth);
/*  829 */     type = (this.otherBindings[otherBindingsLength - 1]).type;
/*      */     
/*  831 */     return (type != null && (this.bits & 0x2000) == 0) ? 
/*  832 */       type.capture((Scope)scope, this.sourceStart, this.sourceEnd) : 
/*  833 */       type;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isEquivalent(Reference reference) {
/*  838 */     if (reference instanceof FieldReference) {
/*  839 */       return reference.isEquivalent(this);
/*      */     }
/*  841 */     if (!(reference instanceof QualifiedNameReference)) return false;
/*      */     
/*  843 */     QualifiedNameReference qualifiedReference = (QualifiedNameReference)reference;
/*  844 */     if (this.tokens.length != qualifiedReference.tokens.length) return false; 
/*  845 */     if (this.binding != qualifiedReference.binding) return false; 
/*  846 */     if (this.otherBindings != null) {
/*  847 */       if (qualifiedReference.otherBindings == null) return false; 
/*  848 */       int len = this.otherBindings.length;
/*  849 */       if (len != qualifiedReference.otherBindings.length) return false; 
/*  850 */       for (int i = 0; i < len; i++) {
/*  851 */         if (this.otherBindings[i] != qualifiedReference.otherBindings[i]) return false; 
/*      */       } 
/*  853 */     } else if (qualifiedReference.otherBindings != null) {
/*  854 */       return false;
/*      */     } 
/*  856 */     return true;
/*      */   }
/*      */   
/*      */   public boolean isFieldAccess() {
/*  860 */     if (this.otherBindings != null) {
/*  861 */       return true;
/*      */     }
/*  863 */     return ((this.bits & 0x7) == 1);
/*      */   }
/*      */ 
/*      */   
/*      */   public FieldBinding lastFieldBinding() {
/*  868 */     if (this.otherBindings != null)
/*  869 */       return this.otherBindings[this.otherBindings.length - 1]; 
/*  870 */     if (this.binding != null && (this.bits & 0x7) == 1) {
/*  871 */       return (FieldBinding)this.binding;
/*      */     }
/*  873 */     return null;
/*      */   }
/*      */ 
/*      */   
/*      */   public void manageEnclosingInstanceAccessIfNecessary(BlockScope currentScope, FlowInfo flowInfo) {
/*  878 */     if (((this.bits & 0x1FE0) == 0 && (this.bits & 0x80000) == 0) || this.constant != Constant.NotAConstant) {
/*      */       return;
/*      */     }
/*  881 */     if ((this.bits & 0x7) == 2) {
/*  882 */       LocalVariableBinding localVariableBinding = (LocalVariableBinding)this.binding;
/*  883 */       if (localVariableBinding != null) {
/*  884 */         if (localVariableBinding.isUninitializedIn((Scope)currentScope)) {
/*      */           return;
/*      */         }
/*      */         
/*  888 */         switch (localVariableBinding.useFlag) {
/*      */           case 1:
/*      */           case 2:
/*  891 */             currentScope.emulateOuterAccess(localVariableBinding);
/*      */             break;
/*      */         } 
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void manageSyntheticAccessIfNecessary(BlockScope currentScope, FieldBinding fieldBinding, int index, FlowInfo flowInfo) {
/*  901 */     if ((flowInfo.tagBits & 0x1) != 0)
/*      */       return; 
/*  903 */     if (fieldBinding.constant((Scope)currentScope) != Constant.NotAConstant) {
/*      */       return;
/*      */     }
/*  906 */     if (fieldBinding.isPrivate()) {
/*  907 */       FieldBinding codegenField = getCodegenBinding((index < 0) ? ((this.otherBindings == null) ? 0 : this.otherBindings.length) : index);
/*  908 */       ReferenceBinding declaringClass = codegenField.declaringClass;
/*  909 */       if (!currentScope.enclosingSourceType().isNestmateOf(declaringClass) && 
/*  910 */         TypeBinding.notEquals((TypeBinding)declaringClass, (TypeBinding)currentScope.enclosingSourceType())) {
/*  911 */         setSyntheticAccessor(fieldBinding, index, ((SourceTypeBinding)declaringClass).addSyntheticMethod(codegenField, (index >= 0), false));
/*  912 */         currentScope.problemReporter().needToEmulateFieldAccess(codegenField, this, (index >= 0));
/*      */         return;
/*      */       } 
/*  915 */     } else if (fieldBinding.isProtected()) {
/*  916 */       int depth = (index == 0 || (index < 0 && this.otherDepths == null)) ? ((
/*  917 */         this.bits & 0x1FE0) >> 5) : 
/*  918 */         this.otherDepths[(index < 0) ? (this.otherDepths.length - 1) : (index - 1)];
/*      */ 
/*      */       
/*  921 */       if (depth > 0 && fieldBinding.declaringClass.getPackage() != currentScope.enclosingSourceType().getPackage()) {
/*  922 */         FieldBinding codegenField = getCodegenBinding((index < 0) ? ((this.otherBindings == null) ? 0 : this.otherBindings.length) : index);
/*  923 */         setSyntheticAccessor(fieldBinding, index, (
/*  924 */             (SourceTypeBinding)currentScope.enclosingSourceType().enclosingTypeAt(depth)).addSyntheticMethod(codegenField, (index >= 0), false));
/*  925 */         currentScope.problemReporter().needToEmulateFieldAccess(codegenField, this, (index >= 0));
/*      */         return;
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public Constant optimizedBooleanConstant() {
/*  933 */     if (this.binding.isValidBinding() && this.resolvedType != null)
/*  934 */       switch (this.resolvedType.id) {
/*      */         case 5:
/*      */         case 33:
/*  937 */           if (this.constant != Constant.NotAConstant) return this.constant; 
/*  938 */           switch (this.bits & 0x7) {
/*      */             case 1:
/*  940 */               if (this.otherBindings == null) {
/*  941 */                 return ((FieldBinding)this.binding).constant();
/*      */               }
/*      */             case 2:
/*  944 */               return this.otherBindings[this.otherBindings.length - 1].constant();
/*      */           } 
/*      */           break;
/*      */       }  
/*  948 */     return Constant.NotAConstant;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public TypeBinding postConversionType(Scope scope) {
/*      */     BaseTypeBinding baseTypeBinding;
/*  956 */     TypeBinding typeBinding1, convertedType = this.resolvedType;
/*  957 */     TypeBinding requiredGenericCast = getGenericCast((this.otherBindings == null) ? 0 : this.otherBindings.length);
/*  958 */     if (requiredGenericCast != null)
/*  959 */       convertedType = requiredGenericCast; 
/*  960 */     int runtimeType = (this.implicitConversion & 0xFF) >> 4;
/*  961 */     switch (runtimeType) {
/*      */       case 5:
/*  963 */         baseTypeBinding = TypeBinding.BOOLEAN;
/*      */         break;
/*      */       case 3:
/*  966 */         baseTypeBinding = TypeBinding.BYTE;
/*      */         break;
/*      */       case 4:
/*  969 */         baseTypeBinding = TypeBinding.SHORT;
/*      */         break;
/*      */       case 2:
/*  972 */         baseTypeBinding = TypeBinding.CHAR;
/*      */         break;
/*      */       case 10:
/*  975 */         baseTypeBinding = TypeBinding.INT;
/*      */         break;
/*      */       case 9:
/*  978 */         baseTypeBinding = TypeBinding.FLOAT;
/*      */         break;
/*      */       case 7:
/*  981 */         baseTypeBinding = TypeBinding.LONG;
/*      */         break;
/*      */       case 8:
/*  984 */         baseTypeBinding = TypeBinding.DOUBLE;
/*      */         break;
/*      */     } 
/*      */     
/*  988 */     if ((this.implicitConversion & 0x200) != 0) {
/*  989 */       typeBinding1 = scope.environment().computeBoxingType((TypeBinding)baseTypeBinding);
/*      */     }
/*  991 */     return typeBinding1;
/*      */   }
/*      */ 
/*      */   
/*      */   public StringBuffer printExpression(int indent, StringBuffer output) {
/*  996 */     for (int i = 0; i < this.tokens.length; i++) {
/*  997 */       if (i > 0) output.append('.'); 
/*  998 */       output.append(this.tokens[i]);
/*      */     } 
/* 1000 */     return output;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public TypeBinding reportError(BlockScope scope) {
/* 1007 */     Binding inaccessible = scope.environment().getInaccessibleBinding(this.tokens, scope.module());
/* 1008 */     if (inaccessible instanceof TypeBinding) {
/* 1009 */       this.indexOfFirstFieldBinding = -1;
/* 1010 */       this.binding = inaccessible;
/* 1011 */       scope.problemReporter().invalidType(this, (TypeBinding)this.binding);
/* 1012 */     } else if (this.binding instanceof ProblemFieldBinding) {
/* 1013 */       scope.problemReporter().invalidField(this, (FieldBinding)this.binding);
/* 1014 */     } else if (this.binding instanceof ProblemReferenceBinding || this.binding instanceof org.eclipse.jdt.internal.compiler.lookup.MissingTypeBinding) {
/* 1015 */       scope.problemReporter().invalidType(this, (TypeBinding)this.binding);
/*      */     } else {
/* 1017 */       scope.problemReporter().unresolvableReference(this, this.binding);
/*      */     } 
/* 1019 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public TypeBinding resolveType(BlockScope scope) {
/* 1027 */     this.actualReceiverType = (TypeBinding)scope.enclosingReceiverType();
/* 1028 */     this.constant = Constant.NotAConstant;
/* 1029 */     if ((this.binding = scope.getBinding(this.tokens, this.bits & 0x7, this, true)).isValidBinding()) {
/* 1030 */       TypeBinding type; switch (this.bits & 0x7) {
/*      */         case 3:
/*      */         case 7:
/* 1033 */           if (this.binding instanceof LocalVariableBinding) {
/* 1034 */             this.bits &= 0xFFFFFFF8;
/* 1035 */             this.bits |= 0x2;
/* 1036 */             LocalVariableBinding local = (LocalVariableBinding)this.binding;
/* 1037 */             if (!local.isFinal() && (this.bits & 0x80000) != 0 && 
/* 1038 */               (scope.compilerOptions()).sourceLevel < 3407872L) {
/* 1039 */               scope.problemReporter().cannotReferToNonFinalOuterLocal((LocalVariableBinding)this.binding, this);
/*      */             }
/* 1041 */             if (local.type != null && (local.type.tagBits & 0x80L) != 0L)
/*      */             {
/* 1043 */               return null;
/*      */             }
/* 1045 */             this.resolvedType = getOtherFieldBindings(scope);
/* 1046 */             if (this.resolvedType != null && (this.resolvedType.tagBits & 0x80L) != 0L) {
/* 1047 */               FieldBinding lastField = this.otherBindings[this.otherBindings.length - 1];
/* 1048 */               scope.problemReporter().invalidField(this, (FieldBinding)new ProblemFieldBinding(lastField.declaringClass, lastField.name, 1), this.tokens.length, this.resolvedType.leafComponentType());
/* 1049 */               return null;
/*      */             } 
/* 1051 */             return this.resolvedType;
/*      */           } 
/* 1053 */           if (this.binding instanceof FieldBinding) {
/* 1054 */             this.bits &= 0xFFFFFFF8;
/* 1055 */             this.bits |= 0x1;
/* 1056 */             FieldBinding fieldBinding = (FieldBinding)this.binding;
/* 1057 */             ReferenceBinding declaringClass = (fieldBinding.original()).declaringClass;
/* 1058 */             MethodScope methodScope = null;
/* 1059 */             SourceTypeBinding sourceType = null;
/* 1060 */             if (scope.kind != 5) {
/* 1061 */               methodScope = scope.methodScope();
/* 1062 */               sourceType = methodScope.enclosingSourceType();
/*      */             } 
/*      */             
/* 1065 */             if (scope.kind != 5 && (
/* 1066 */               this.indexOfFirstFieldBinding == 1 || (fieldBinding.modifiers & 0x4000) != 0 || (!fieldBinding.isFinal() && declaringClass.isEnum())) && 
/* 1067 */               TypeBinding.equalsEquals((TypeBinding)sourceType, (TypeBinding)declaringClass) && 
/* 1068 */               methodScope.lastVisibleFieldID >= 0 && 
/* 1069 */               fieldBinding.id >= methodScope.lastVisibleFieldID && (
/* 1070 */               !fieldBinding.isStatic() || methodScope.isStatic) && (
/* 1071 */               !methodScope.insideTypeAnnotation || fieldBinding.id != methodScope.lastVisibleFieldID))
/*      */             {
/*      */               
/* 1074 */               scope.problemReporter().forwardReference(this, this.indexOfFirstFieldBinding - 1, fieldBinding);
/*      */             }
/*      */ 
/*      */             
/* 1078 */             if (isFieldUseDeprecated(fieldBinding, (Scope)scope, (this.indexOfFirstFieldBinding == this.tokens.length) ? this.bits : 0)) {
/* 1079 */               scope.problemReporter().deprecatedField(fieldBinding, this);
/*      */             }
/* 1081 */             if (fieldBinding.isStatic()) {
/*      */ 
/*      */               
/* 1084 */               if (declaringClass.isEnum() && scope.kind != 5 && (
/* 1085 */                 TypeBinding.equalsEquals((TypeBinding)sourceType, (TypeBinding)declaringClass) || TypeBinding.equalsEquals((TypeBinding)sourceType.superclass, (TypeBinding)declaringClass)) && 
/* 1086 */                 fieldBinding.constant((Scope)scope) == Constant.NotAConstant && 
/* 1087 */                 !methodScope.isStatic && 
/* 1088 */                 methodScope.isInsideInitializerOrConstructor()) {
/* 1089 */                 scope.problemReporter().enumStaticFieldUsedDuringInitialization(fieldBinding, this);
/*      */               }
/*      */               
/* 1092 */               if (this.indexOfFirstFieldBinding > 1 && 
/* 1093 */                 TypeBinding.notEquals((TypeBinding)fieldBinding.declaringClass, this.actualReceiverType) && 
/* 1094 */                 fieldBinding.declaringClass.canBeSeenBy((Scope)scope)) {
/* 1095 */                 scope.problemReporter().indirectAccessToStaticField(this, fieldBinding);
/*      */               }
/*      */             } else {
/* 1098 */               boolean inStaticContext = (scope.methodScope()).isStatic;
/* 1099 */               if (this.indexOfFirstFieldBinding == 1) {
/* 1100 */                 if (scope.compilerOptions().getSeverity(4194304) != 256) {
/* 1101 */                   scope.problemReporter().unqualifiedFieldAccess(this, fieldBinding);
/*      */                 }
/* 1103 */                 if (!inStaticContext) {
/* 1104 */                   scope.tagAsAccessingEnclosingInstanceStateOf(fieldBinding.declaringClass, false);
/*      */                 }
/*      */               } 
/*      */               
/* 1108 */               if (this.indexOfFirstFieldBinding > 1 || 
/* 1109 */                 inStaticContext) {
/* 1110 */                 scope.problemReporter().staticFieldAccessToNonStaticVariable(this, fieldBinding);
/* 1111 */                 return null;
/*      */               } 
/*      */             } 
/*      */             
/* 1115 */             this.resolvedType = getOtherFieldBindings(scope);
/* 1116 */             if (this.resolvedType != null && (
/* 1117 */               this.resolvedType.tagBits & 0x80L) != 0L) {
/* 1118 */               FieldBinding lastField = (this.indexOfFirstFieldBinding == this.tokens.length) ? (FieldBinding)this.binding : this.otherBindings[this.otherBindings.length - 1];
/* 1119 */               scope.problemReporter().invalidField(this, (FieldBinding)new ProblemFieldBinding(lastField.declaringClass, lastField.name, 1), this.tokens.length, this.resolvedType.leafComponentType());
/* 1120 */               return null;
/*      */             } 
/* 1122 */             return this.resolvedType;
/*      */           } 
/*      */           
/* 1125 */           this.bits &= 0xFFFFFFF8;
/* 1126 */           this.bits |= 0x4;
/*      */         
/*      */         case 4:
/* 1129 */           type = (TypeBinding)this.binding;
/*      */ 
/*      */           
/* 1132 */           type = scope.environment().convertToRawType(type, false);
/* 1133 */           return this.resolvedType = type;
/*      */       } 
/*      */     
/*      */     } 
/* 1137 */     return this.resolvedType = reportError(scope);
/*      */   }
/*      */ 
/*      */   
/*      */   public void setFieldIndex(int index) {
/* 1142 */     this.indexOfFirstFieldBinding = index;
/*      */   }
/*      */ 
/*      */   
/*      */   protected void setGenericCast(int index, TypeBinding someGenericCast) {
/* 1147 */     if (someGenericCast == null)
/* 1148 */       return;  if (index == 0) {
/* 1149 */       this.genericCast = someGenericCast;
/*      */     } else {
/* 1151 */       if (this.otherGenericCasts == null) {
/* 1152 */         this.otherGenericCasts = new TypeBinding[this.otherBindings.length];
/*      */       }
/* 1154 */       this.otherGenericCasts[index - 1] = someGenericCast;
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   protected void setSyntheticAccessor(FieldBinding fieldBinding, int index, SyntheticMethodBinding syntheticAccessor) {
/* 1160 */     if (index < 0) {
/* 1161 */       this.syntheticWriteAccessor = syntheticAccessor;
/*      */     } else {
/* 1163 */       if (this.syntheticReadAccessors == null) {
/* 1164 */         this.syntheticReadAccessors = new SyntheticMethodBinding[(this.otherBindings == null) ? 1 : (this.otherBindings.length + 1)];
/*      */       }
/* 1166 */       this.syntheticReadAccessors[index] = syntheticAccessor;
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public void traverse(ASTVisitor visitor, BlockScope scope) {
/* 1172 */     visitor.visit(this, scope);
/* 1173 */     visitor.endVisit(this, scope);
/*      */   }
/*      */ 
/*      */   
/*      */   public void traverse(ASTVisitor visitor, ClassScope scope) {
/* 1178 */     visitor.visit(this, scope);
/* 1179 */     visitor.endVisit(this, scope);
/*      */   }
/*      */ 
/*      */   
/*      */   public String unboundReferenceErrorName() {
/* 1184 */     return new String(this.tokens[0]);
/*      */   }
/*      */ 
/*      */   
/*      */   public char[][] getName() {
/* 1189 */     return this.tokens;
/*      */   }
/*      */ 
/*      */   
/*      */   public VariableBinding nullAnnotatedVariableBinding(boolean supportTypeAnnotations) {
/* 1194 */     if (this.binding != null && isFieldAccess()) {
/*      */       FieldBinding fieldBinding;
/* 1196 */       if (this.otherBindings == null) {
/* 1197 */         fieldBinding = (FieldBinding)this.binding;
/*      */       } else {
/* 1199 */         fieldBinding = this.otherBindings[this.otherBindings.length - 1];
/*      */       } 
/* 1201 */       if (supportTypeAnnotations || fieldBinding.isNullable() || fieldBinding.isNonNull()) {
/* 1202 */         return (VariableBinding)fieldBinding;
/*      */       }
/*      */     } 
/* 1205 */     return null;
/*      */   }
/*      */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\ast\QualifiedNameReference.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */