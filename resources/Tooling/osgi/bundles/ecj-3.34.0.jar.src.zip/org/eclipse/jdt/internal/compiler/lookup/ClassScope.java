/*      */ package org.eclipse.jdt.internal.compiler.lookup;
/*      */ 
/*      */ import java.util.ArrayList;
/*      */ import java.util.HashMap;
/*      */ import java.util.Iterator;
/*      */ import java.util.LinkedHashSet;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.Set;
/*      */ import org.eclipse.jdt.core.compiler.CharOperation;
/*      */ import org.eclipse.jdt.internal.compiler.ast.ASTNode;
/*      */ import org.eclipse.jdt.internal.compiler.ast.AbstractMethodDeclaration;
/*      */ import org.eclipse.jdt.internal.compiler.ast.FieldDeclaration;
/*      */ import org.eclipse.jdt.internal.compiler.ast.RecordComponent;
/*      */ import org.eclipse.jdt.internal.compiler.ast.TypeDeclaration;
/*      */ import org.eclipse.jdt.internal.compiler.ast.TypeParameter;
/*      */ import org.eclipse.jdt.internal.compiler.ast.TypeReference;
/*      */ import org.eclipse.jdt.internal.compiler.env.AccessRestriction;
/*      */ import org.eclipse.jdt.internal.compiler.env.ICompilationUnit;
/*      */ import org.eclipse.jdt.internal.compiler.impl.JavaFeature;
/*      */ import org.eclipse.jdt.internal.compiler.impl.ReferenceContext;
/*      */ import org.eclipse.jdt.internal.compiler.problem.AbortCompilation;
/*      */ import org.eclipse.jdt.internal.compiler.problem.ProblemReporter;
/*      */ import org.eclipse.jdt.internal.compiler.util.HashtableOfObject;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class ClassScope
/*      */   extends Scope
/*      */ {
/*      */   public TypeDeclaration referenceContext;
/*      */   public TypeReference superTypeReference;
/*      */   ArrayList<Object> deferredBoundChecks;
/*      */   
/*      */   public ClassScope(Scope parent, TypeDeclaration context) {
/*   70 */     super(3, parent);
/*   71 */     this.referenceContext = context;
/*   72 */     this.deferredBoundChecks = null;
/*      */   }
/*      */   
/*      */   void buildAnonymousTypeBinding(SourceTypeBinding enclosingType, ReferenceBinding supertype) {
/*   76 */     LocalTypeBinding anonymousType = buildLocalType(enclosingType, enclosingType.fPackage);
/*   77 */     anonymousType.modifiers |= 0x8000000;
/*   78 */     int inheritedBits = supertype.typeBits;
/*      */     
/*   80 */     if ((inheritedBits & 0x4) != 0) {
/*   81 */       AbstractMethodDeclaration[] methods = this.referenceContext.methods;
/*   82 */       if (methods != null) {
/*   83 */         for (int i = 0; i < methods.length; i++) {
/*   84 */           if (CharOperation.equals(TypeConstants.CLOSE, (methods[i]).selector) && (methods[i]).arguments == null) {
/*   85 */             inheritedBits &= 0x713;
/*      */             break;
/*      */           } 
/*      */         } 
/*      */       }
/*      */     } 
/*   91 */     anonymousType.typeBits |= inheritedBits;
/*   92 */     anonymousType.setPermittedTypes(Binding.NO_PERMITTEDTYPES);
/*   93 */     if (supertype.isInterface()) {
/*   94 */       anonymousType.setSuperClass(getJavaLangObject());
/*   95 */       anonymousType.setSuperInterfaces(new ReferenceBinding[] { supertype });
/*   96 */       TypeReference typeReference = this.referenceContext.allocation.type;
/*   97 */       if (typeReference != null) {
/*   98 */         this.referenceContext.superInterfaces = new TypeReference[] { typeReference };
/*   99 */         if ((supertype.tagBits & 0x40000000L) != 0L) {
/*  100 */           problemReporter().superTypeCannotUseWildcard(anonymousType, typeReference, supertype);
/*  101 */           anonymousType.tagBits |= 0x20000L;
/*  102 */           anonymousType.setSuperInterfaces(Binding.NO_SUPERINTERFACES);
/*  103 */         }  if (supertype.isSealed()) {
/*  104 */           problemReporter().sealedAnonymousClassCannotExtendSealedType(typeReference, supertype);
/*  105 */           anonymousType.tagBits |= 0x20000L;
/*  106 */           anonymousType.setSuperInterfaces(Binding.NO_SUPERINTERFACES);
/*      */         } 
/*      */       } 
/*      */     } else {
/*  110 */       anonymousType.setSuperClass(supertype);
/*  111 */       anonymousType.setSuperInterfaces(Binding.NO_SUPERINTERFACES);
/*  112 */       checkForEnumSealedPreview(supertype, anonymousType);
/*  113 */       TypeReference typeReference = this.referenceContext.allocation.type;
/*  114 */       if (typeReference != null) {
/*  115 */         this.referenceContext.superclass = typeReference;
/*  116 */         if ((supertype.erasure()).id == 41) {
/*  117 */           problemReporter().cannotExtendEnum(anonymousType, typeReference, supertype);
/*  118 */           anonymousType.tagBits |= 0x20000L;
/*  119 */           anonymousType.setSuperClass(getJavaLangObject());
/*  120 */         } else if ((supertype.erasure()).id == 93) {
/*  121 */           if (!this.referenceContext.isRecord()) {
/*  122 */             problemReporter().recordCannotExtendRecord(anonymousType, typeReference, supertype);
/*  123 */             anonymousType.tagBits |= 0x20000L;
/*  124 */             anonymousType.setSuperClass(getJavaLangObject());
/*      */           } 
/*  126 */         } else if (supertype.isFinal()) {
/*  127 */           problemReporter().anonymousClassCannotExtendFinalClass(typeReference, supertype);
/*  128 */           anonymousType.tagBits |= 0x20000L;
/*  129 */           anonymousType.setSuperClass(getJavaLangObject());
/*  130 */         } else if ((supertype.tagBits & 0x40000000L) != 0L) {
/*  131 */           problemReporter().superTypeCannotUseWildcard(anonymousType, typeReference, supertype);
/*  132 */           anonymousType.tagBits |= 0x20000L;
/*  133 */           anonymousType.setSuperClass(getJavaLangObject());
/*  134 */         } else if (supertype.isSealed()) {
/*  135 */           problemReporter().sealedAnonymousClassCannotExtendSealedType(typeReference, supertype);
/*  136 */           anonymousType.tagBits |= 0x20000L;
/*  137 */           anonymousType.setSuperClass(getJavaLangObject());
/*      */         } 
/*      */       } 
/*      */     } 
/*  141 */     connectMemberTypes();
/*  142 */     buildFieldsAndMethods();
/*  143 */     anonymousType.faultInTypesForFieldsAndMethods();
/*  144 */     anonymousType.verifyMethods(environment().methodVerifier());
/*      */   }
/*      */   
/*      */   private void checkForEnumSealedPreview(ReferenceBinding supertype, LocalTypeBinding anonymousType) {
/*  148 */     if (!JavaFeature.SEALED_CLASSES.isSupported(compilerOptions()) || 
/*  149 */       !supertype.isEnum() || 
/*  150 */       !(supertype instanceof SourceTypeBinding)) {
/*      */       return;
/*      */     }
/*  153 */     SourceTypeBinding sourceSuperType = (SourceTypeBinding)supertype;
/*  154 */     ReferenceBinding[] permTypes = sourceSuperType.permittedTypes();
/*  155 */     int sz = (permTypes == null) ? 0 : permTypes.length;
/*  156 */     if (sz == 0) {
/*  157 */       permTypes = new ReferenceBinding[] { anonymousType };
/*      */     } else {
/*  159 */       System.arraycopy(permTypes, 0, 
/*  160 */           permTypes = new ReferenceBinding[sz + 1], 0, 
/*  161 */           sz);
/*  162 */       permTypes[sz] = anonymousType;
/*      */     } 
/*  164 */     anonymousType.modifiers |= 0x10;
/*  165 */     sourceSuperType.setPermittedTypes(permTypes);
/*      */   }
/*      */   
/*      */   void buildComponents() {
/*  169 */     SourceTypeBinding sourceType = this.referenceContext.binding;
/*  170 */     if (!sourceType.isRecord())
/*  171 */       return;  if (sourceType.areComponentsInitialized())
/*  172 */       return;  if (this.referenceContext.recordComponents == null) {
/*  173 */       sourceType.setComponents(Binding.NO_COMPONENTS);
/*      */       
/*      */       return;
/*      */     } 
/*  177 */     RecordComponent[] recComps = this.referenceContext.recordComponents;
/*  178 */     int size = recComps.length;
/*  179 */     int count = size;
/*      */ 
/*      */     
/*  182 */     RecordComponentBinding[] componentBindings = new RecordComponentBinding[count];
/*  183 */     HashtableOfObject knownComponentNames = new HashtableOfObject(count);
/*  184 */     count = 0;
/*  185 */     for (int i = 0; i < size; i++) {
/*  186 */       RecordComponent recComp = recComps[i];
/*  187 */       RecordComponentBinding compBinding = new RecordComponentBinding(sourceType, recComp, null, 
/*  188 */           recComp.modifiers | 0x2000000);
/*  189 */       compBinding.id = count;
/*  190 */       checkAndSetModifiersForComponents(compBinding, recComp);
/*      */       
/*  192 */       if (knownComponentNames.containsKey(recComp.name)) {
/*  193 */         RecordComponentBinding previousBinding = (RecordComponentBinding)knownComponentNames.get(recComp.name);
/*  194 */         if (previousBinding != null) {
/*  195 */           for (int f = 0; f < i; f++) {
/*  196 */             RecordComponent previousComponent = recComps[f];
/*  197 */             if (previousComponent.binding == previousBinding) {
/*      */               
/*  199 */               problemReporter().recordDuplicateComponent(previousComponent);
/*      */               break;
/*      */             } 
/*      */           } 
/*      */         }
/*  204 */         knownComponentNames.put(recComp.name, null);
/*  205 */         problemReporter().recordDuplicateComponent(recComp);
/*  206 */         recComp.binding = null;
/*      */       } else {
/*  208 */         knownComponentNames.put(recComp.name, compBinding);
/*      */         
/*  210 */         componentBindings[count++] = compBinding;
/*      */       } 
/*      */     } 
/*      */     
/*  214 */     if (count != componentBindings.length)
/*  215 */       System.arraycopy(componentBindings, 0, componentBindings = new RecordComponentBinding[count], 0, count); 
/*  216 */     sourceType.setComponents(componentBindings);
/*  217 */     if (size > 0)
/*  218 */       sourceType.isVarArgs = recComps[size - 1].isVarArgs(); 
/*      */   }
/*      */   
/*      */   private void checkAndSetModifiersForComponents(RecordComponentBinding compBinding, RecordComponent comp) {
/*  222 */     int modifiers = compBinding.modifiers;
/*  223 */     int realModifiers = modifiers & 0xFFFF;
/*  224 */     if (realModifiers != 0 && comp != null) {
/*  225 */       problemReporter().recordComponentsCannotHaveModifiers(comp);
/*      */     }
/*      */   }
/*      */   
/*      */   void buildFields() {
/*  230 */     SourceTypeBinding sourceType = this.referenceContext.binding;
/*  231 */     if (sourceType.areFieldsInitialized())
/*  232 */       return;  if (this.referenceContext.fields == null) {
/*  233 */       sourceType.setFields(Binding.NO_FIELDS);
/*      */       
/*      */       return;
/*      */     } 
/*  237 */     FieldDeclaration[] fields = this.referenceContext.fields;
/*  238 */     int size = fields.length;
/*  239 */     int count = 0;
/*  240 */     for (int i = 0; i < size; i++) {
/*  241 */       switch (fields[i].getKind()) {
/*      */         case 1:
/*      */         case 3:
/*  244 */           count++;
/*      */           break;
/*      */       } 
/*      */     
/*      */     } 
/*  249 */     FieldBinding[] fieldBindings = new FieldBinding[count];
/*  250 */     HashtableOfObject knownFieldNames = new HashtableOfObject(count);
/*  251 */     count = 0;
/*  252 */     for (int j = 0; j < size; j++) {
/*  253 */       FieldDeclaration field = fields[j];
/*  254 */       if (field.getKind() != 2) {
/*      */ 
/*      */ 
/*      */         
/*  258 */         FieldBinding fieldBinding = new FieldBinding(field, null, field.modifiers | 0x2000000, sourceType);
/*  259 */         fieldBinding.id = count;
/*      */         
/*  261 */         checkAndSetModifiersForField(fieldBinding, field);
/*      */         
/*  263 */         if (knownFieldNames.containsKey(field.name)) {
/*  264 */           FieldBinding previousBinding = (FieldBinding)knownFieldNames.get(field.name);
/*  265 */           if (previousBinding != null) {
/*  266 */             for (int f = 0; f < j; f++) {
/*  267 */               FieldDeclaration previousField = fields[f];
/*  268 */               if (previousField.binding == previousBinding) {
/*  269 */                 problemReporter().duplicateFieldInType(sourceType, previousField);
/*      */                 break;
/*      */               } 
/*      */             } 
/*      */           }
/*  274 */           knownFieldNames.put(field.name, null);
/*  275 */           problemReporter().duplicateFieldInType(sourceType, field);
/*  276 */           field.binding = null;
/*      */         } else {
/*  278 */           knownFieldNames.put(field.name, fieldBinding);
/*      */           
/*  280 */           fieldBindings[count++] = fieldBinding;
/*      */         } 
/*      */       } 
/*      */     } 
/*      */     
/*  285 */     if (count != fieldBindings.length)
/*  286 */       System.arraycopy(fieldBindings, 0, fieldBindings = new FieldBinding[count], 0, count); 
/*  287 */     sourceType.tagBits &= 0xFFFFFFFFFFFFCFFFL;
/*  288 */     sourceType.setFields(fieldBindings);
/*      */   }
/*      */   
/*      */   void buildFieldsAndMethods() {
/*  292 */     buildComponents();
/*  293 */     buildFields();
/*  294 */     buildMethods();
/*      */     
/*  296 */     SourceTypeBinding sourceType = this.referenceContext.binding;
/*  297 */     if (!sourceType.isPrivate() && sourceType.superclass instanceof SourceTypeBinding && sourceType.superclass.isPrivate()) {
/*  298 */       ((SourceTypeBinding)sourceType.superclass).tagIndirectlyAccessibleMembers();
/*      */     }
/*  300 */     if (sourceType.isMemberType() && !sourceType.isLocalType()) {
/*  301 */       ((MemberTypeBinding)sourceType).checkSyntheticArgsAndFields();
/*      */     }
/*  303 */     ReferenceBinding[] memberTypes = sourceType.memberTypes;
/*  304 */     for (int i = 0, length = memberTypes.length; i < length; i++) {
/*  305 */       ((SourceTypeBinding)memberTypes[i]).scope.buildFieldsAndMethods();
/*      */     }
/*      */   }
/*      */   
/*      */   private LocalTypeBinding buildLocalType(SourceTypeBinding enclosingType, PackageBinding packageBinding) {
/*  310 */     this.referenceContext.scope = this;
/*  311 */     this.referenceContext.staticInitializerScope = new MethodScope(this, (ReferenceContext)this.referenceContext, true);
/*  312 */     this.referenceContext.initializerScope = new MethodScope(this, (ReferenceContext)this.referenceContext, false);
/*      */ 
/*      */     
/*  315 */     LocalTypeBinding localType = new LocalTypeBinding(this, enclosingType, innermostSwitchCase());
/*  316 */     this.referenceContext.binding = localType;
/*  317 */     checkAndSetModifiers();
/*  318 */     buildTypeVariables();
/*      */ 
/*      */     
/*  321 */     ReferenceBinding[] memberTypeBindings = Binding.NO_MEMBER_TYPES;
/*  322 */     if (this.referenceContext.memberTypes != null) {
/*  323 */       int size = this.referenceContext.memberTypes.length;
/*  324 */       memberTypeBindings = new ReferenceBinding[size];
/*  325 */       int count = 0;
/*  326 */       for (int i = 0; i < size; i++) {
/*  327 */         ReferenceBinding type; TypeDeclaration memberContext = this.referenceContext.memberTypes[i];
/*  328 */         switch (TypeDeclaration.kind(memberContext.modifiers)) {
/*      */           case 2:
/*      */           
/*      */ 
/*      */           
/*      */           case 4:
/*  334 */             problemReporter().illegalLocalTypeDeclaration(memberContext);
/*      */             break;
/*      */           default:
/*  337 */             type = localType;
/*      */             
/*      */             while (true)
/*  340 */             { if (CharOperation.equals(type.sourceName, memberContext.name)) {
/*  341 */                 problemReporter().typeCollidesWithEnclosingType(memberContext);
/*      */                 break;
/*      */               } 
/*  344 */               type = type.enclosingType();
/*  345 */               if (type == null)
/*      */               
/*  347 */               { int j = 0; while (true) { ClassScope memberScope; if (j >= i)
/*      */                   
/*      */                   { 
/*      */ 
/*      */ 
/*      */                     
/*  353 */                     memberScope = new ClassScope(this, this.referenceContext.memberTypes[i]);
/*  354 */                     LocalTypeBinding memberBinding = memberScope.buildLocalType(localType, packageBinding);
/*  355 */                     memberBinding.setAsMemberType();
/*  356 */                     memberTypeBindings[count++] = memberBinding; break; }  if (CharOperation.equals((this.referenceContext.memberTypes[memberScope]).name, memberContext.name)) { problemReporter().duplicateNestedType(memberContext); break; }  memberScope++; }  break; }  }  break;
/*      */         }  continue;
/*  358 */       }  if (count != size)
/*  359 */         System.arraycopy(memberTypeBindings, 0, memberTypeBindings = new ReferenceBinding[count], 0, count); 
/*      */     } 
/*  361 */     localType.setMemberTypes(memberTypeBindings);
/*  362 */     return localType;
/*      */   }
/*      */ 
/*      */   
/*      */   void buildLocalTypeBinding(SourceTypeBinding enclosingType) {
/*  367 */     LocalTypeBinding localType = buildLocalType(enclosingType, enclosingType.fPackage);
/*  368 */     connectTypeHierarchy();
/*  369 */     connectImplicitPermittedTypes();
/*  370 */     if ((compilerOptions()).sourceLevel >= 3211264L) {
/*  371 */       checkParameterizedTypeBounds();
/*  372 */       checkParameterizedSuperTypeCollisions();
/*      */     } 
/*  374 */     buildFieldsAndMethods();
/*  375 */     localType.faultInTypesForFieldsAndMethods();
/*      */     
/*  377 */     this.referenceContext.binding.verifyMethods(environment().methodVerifier());
/*      */   }
/*      */   
/*      */   private void buildMemberTypes(AccessRestriction accessRestriction) {
/*  381 */     SourceTypeBinding sourceType = this.referenceContext.binding;
/*  382 */     ReferenceBinding[] memberTypeBindings = Binding.NO_MEMBER_TYPES;
/*  383 */     if (this.referenceContext.memberTypes != null) {
/*  384 */       int length = this.referenceContext.memberTypes.length;
/*  385 */       memberTypeBindings = new ReferenceBinding[length];
/*  386 */       int count = 0;
/*  387 */       for (int i = 0; i < length; i++) {
/*  388 */         ReferenceBinding type; TypeDeclaration memberContext = this.referenceContext.memberTypes[i];
/*  389 */         if ((environment()).root.isProcessingAnnotations && environment().isMissingType(memberContext.name)) {
/*  390 */           throw new SourceTypeCollisionException();
/*      */         }
/*  392 */         switch (TypeDeclaration.kind(memberContext.modifiers)) {
/*      */           case 2:
/*      */           case 4:
/*  395 */             if ((compilerOptions()).sourceLevel < 3932160L)
/*      */             {
/*      */               
/*  398 */               if (sourceType.isNestedType() && 
/*  399 */                 sourceType.isClass() && 
/*  400 */                 !sourceType.isStatic()) {
/*  401 */                 problemReporter().illegalLocalTypeDeclaration(memberContext);
/*      */                 break;
/*      */               } 
/*      */             }
/*      */           default:
/*  406 */             type = sourceType;
/*      */             
/*      */             while (true)
/*  409 */             { if (CharOperation.equals(type.sourceName, memberContext.name)) {
/*  410 */                 problemReporter().typeCollidesWithEnclosingType(memberContext);
/*      */                 break;
/*      */               } 
/*  413 */               type = type.enclosingType();
/*  414 */               if (type == null)
/*      */               
/*  416 */               { int j = 0; while (true) { ClassScope memberScope; if (j >= i)
/*      */                   
/*      */                   { 
/*      */ 
/*      */ 
/*      */ 
/*      */                     
/*  423 */                     memberScope = new ClassScope(this, memberContext);
/*  424 */                     memberTypeBindings[count++] = memberScope.buildType(sourceType, sourceType.fPackage, accessRestriction); break; }  if (CharOperation.equals((this.referenceContext.memberTypes[memberScope]).name, memberContext.name)) { problemReporter().duplicateNestedType(memberContext); break; }  memberScope++; }  break; }  }  break;
/*      */         } 
/*  426 */       }  if (count != length)
/*  427 */         System.arraycopy(memberTypeBindings, 0, memberTypeBindings = new ReferenceBinding[count], 0, count); 
/*      */     } 
/*  429 */     sourceType.setMemberTypes(memberTypeBindings);
/*      */   }
/*      */   
/*      */   void buildMethods() {
/*  433 */     SourceTypeBinding sourceType = this.referenceContext.binding;
/*  434 */     if (sourceType.areMethodsInitialized())
/*      */       return; 
/*  436 */     boolean isEnum = (TypeDeclaration.kind(this.referenceContext.modifiers) == 3);
/*  437 */     if (this.referenceContext.methods == null && !isEnum && !sourceType.isRecord()) {
/*  438 */       this.referenceContext.binding.setMethods(Binding.NO_METHODS);
/*      */       
/*      */       return;
/*      */     } 
/*      */     
/*  443 */     AbstractMethodDeclaration[] methods = this.referenceContext.methods;
/*  444 */     int size = (methods == null) ? 0 : methods.length;
/*      */     
/*  446 */     int clinitIndex = -1;
/*  447 */     for (int i = 0; i < size; i++) {
/*  448 */       if (methods[i].isClinit()) {
/*  449 */         clinitIndex = i;
/*      */         
/*      */         break;
/*      */       } 
/*      */     } 
/*  454 */     int count = isEnum ? 2 : 0;
/*  455 */     MethodBinding[] methodBindings = new MethodBinding[((clinitIndex == -1) ? size : (size - 1)) + count];
/*      */     
/*  457 */     if (isEnum) {
/*  458 */       methodBindings[0] = sourceType.addSyntheticEnumMethod(TypeConstants.VALUES);
/*  459 */       methodBindings[1] = sourceType.addSyntheticEnumMethod(TypeConstants.VALUEOF);
/*      */     } 
/*      */     
/*  462 */     boolean hasNativeMethods = false;
/*  463 */     if (sourceType.isAbstract()) {
/*  464 */       for (int j = 0; j < size; j++) {
/*  465 */         if (j != clinitIndex) {
/*  466 */           MethodScope scope = new MethodScope(this, (ReferenceContext)methods[j], false);
/*  467 */           MethodBinding methodBinding = scope.createMethod(methods[j]);
/*  468 */           if (methodBinding != null) {
/*  469 */             methodBindings[count++] = methodBinding;
/*  470 */             hasNativeMethods = !(!hasNativeMethods && !methodBinding.isNative());
/*      */           } 
/*      */         } 
/*      */       } 
/*      */     } else {
/*  475 */       boolean hasAbstractMethods = false;
/*  476 */       for (int j = 0; j < size; j++) {
/*  477 */         if (j != clinitIndex) {
/*  478 */           MethodScope scope = new MethodScope(this, (ReferenceContext)methods[j], false);
/*  479 */           MethodBinding methodBinding = scope.createMethod(methods[j]);
/*  480 */           if (methodBinding != null) {
/*  481 */             methodBindings[count++] = methodBinding;
/*  482 */             hasAbstractMethods = !(!hasAbstractMethods && !methodBinding.isAbstract());
/*  483 */             hasNativeMethods = !(!hasNativeMethods && !methodBinding.isNative());
/*  484 */             if (methods[j].isCanonicalConstructor()) {
/*  485 */               methodBinding.extendedTagBits |= 0x8;
/*      */             }
/*      */           } 
/*      */         } 
/*      */       } 
/*  490 */       if (hasAbstractMethods)
/*  491 */         problemReporter().abstractMethodInConcreteClass(sourceType); 
/*      */     } 
/*  493 */     if (sourceType.isRecord()) {
/*  494 */       assert this.referenceContext.isRecord();
/*  495 */       methodBindings = sourceType.checkAndAddSyntheticRecordMethods(methodBindings, count);
/*  496 */       count = methodBindings.length;
/*      */     } 
/*  498 */     if (count != methodBindings.length)
/*  499 */       System.arraycopy(methodBindings, 0, methodBindings = new MethodBinding[count], 0, count); 
/*  500 */     sourceType.tagBits &= 0xFFFFFFFFFFFF3FFFL;
/*  501 */     sourceType.setMethods(methodBindings);
/*      */ 
/*      */     
/*  504 */     if (hasNativeMethods) {
/*  505 */       for (int j = 0; j < methodBindings.length; j++) {
/*  506 */         (methodBindings[j]).modifiers |= 0x8000000;
/*      */       }
/*  508 */       FieldBinding[] fields = sourceType.unResolvedFields();
/*  509 */       for (int k = 0; k < fields.length; k++) {
/*  510 */         (fields[k]).modifiers |= 0x8000000;
/*      */       }
/*      */     } 
/*  513 */     if (isEnum && (compilerOptions()).isAnnotationBasedNullAnalysisEnabled) {
/*      */       
/*  515 */       LookupEnvironment environment = environment();
/*  516 */       ((SyntheticMethodBinding)methodBindings[0]).markNonNull(environment);
/*  517 */       ((SyntheticMethodBinding)methodBindings[1]).markNonNull(environment);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   SourceTypeBinding buildType(SourceTypeBinding enclosingType, PackageBinding packageBinding, AccessRestriction accessRestriction) {
/*  523 */     this.referenceContext.scope = this;
/*  524 */     this.referenceContext.staticInitializerScope = new MethodScope(this, (ReferenceContext)this.referenceContext, true);
/*  525 */     this.referenceContext.initializerScope = new MethodScope(this, (ReferenceContext)this.referenceContext, false);
/*      */     
/*  527 */     if (enclosingType == null) {
/*  528 */       char[][] className = CharOperation.arrayConcat(packageBinding.compoundName, this.referenceContext.name);
/*  529 */       this.referenceContext.binding = new SourceTypeBinding(className, packageBinding, this);
/*      */     } else {
/*  531 */       char[][] className = CharOperation.deepCopy(enclosingType.compoundName);
/*  532 */       className[className.length - 1] = 
/*  533 */         CharOperation.concat(className[className.length - 1], this.referenceContext.name, '$');
/*  534 */       if (packageBinding.hasType0Any(className[className.length - 1]))
/*      */       {
/*  536 */         this.parent.problemReporter().duplicateNestedType(this.referenceContext);
/*      */       }
/*  538 */       this.referenceContext.binding = new MemberTypeBinding(className, this, enclosingType);
/*      */     } 
/*      */     
/*  541 */     SourceTypeBinding sourceType = this.referenceContext.binding;
/*  542 */     sourceType.module = module();
/*  543 */     environment().setAccessRestriction(sourceType, accessRestriction);
/*  544 */     ICompilationUnit compilationUnit = this.referenceContext.compilationResult.getCompilationUnit();
/*  545 */     if (compilationUnit != null && (compilerOptions()).isAnnotationBasedNullAnalysisEnabled) {
/*  546 */       String externalAnnotationPath = compilationUnit.getExternalAnnotationPath(CharOperation.toString(sourceType.compoundName));
/*  547 */       if (externalAnnotationPath != null) {
/*  548 */         ExternalAnnotationSuperimposer.apply(sourceType, externalAnnotationPath);
/*      */       }
/*      */     } 
/*      */     
/*  552 */     TypeParameter[] typeParameters = this.referenceContext.typeParameters;
/*  553 */     sourceType.typeVariables = (typeParameters == null || typeParameters.length == 0) ? Binding.NO_TYPE_VARIABLES : null;
/*  554 */     sourceType.fPackage.addType(sourceType);
/*  555 */     checkAndSetModifiers();
/*  556 */     buildTypeVariables();
/*      */     
/*  558 */     buildMemberTypes(accessRestriction);
/*  559 */     return sourceType;
/*      */   }
/*      */ 
/*      */   
/*      */   private void buildTypeVariables() {
/*  564 */     SourceTypeBinding sourceType = this.referenceContext.binding;
/*  565 */     TypeParameter[] typeParameters = this.referenceContext.typeParameters;
/*      */     
/*  567 */     if (typeParameters == null || typeParameters.length == 0) {
/*  568 */       sourceType.setTypeVariables(Binding.NO_TYPE_VARIABLES);
/*      */       return;
/*      */     } 
/*  571 */     sourceType.setTypeVariables(Binding.NO_TYPE_VARIABLES);
/*      */     
/*  573 */     if (sourceType.id == 1) {
/*  574 */       problemReporter().objectCannotBeGeneric(this.referenceContext);
/*      */       return;
/*      */     } 
/*  577 */     sourceType.setTypeVariables(createTypeVariables(typeParameters, sourceType));
/*  578 */     sourceType.modifiers |= 0x40000000;
/*      */   }
/*      */ 
/*      */   
/*      */   void resolveTypeParameter(TypeParameter typeParameter) {
/*  583 */     typeParameter.resolve(this);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void checkAndSetModifiers() {
/*      */     // Byte code:
/*      */     //   0: aload_0
/*      */     //   1: getfield referenceContext : Lorg/eclipse/jdt/internal/compiler/ast/TypeDeclaration;
/*      */     //   4: getfield binding : Lorg/eclipse/jdt/internal/compiler/lookup/SourceTypeBinding;
/*      */     //   7: astore_1
/*      */     //   8: aload_1
/*      */     //   9: getfield modifiers : I
/*      */     //   12: istore_2
/*      */     //   13: aload_0
/*      */     //   14: invokevirtual compilerOptions : ()Lorg/eclipse/jdt/internal/compiler/impl/CompilerOptions;
/*      */     //   17: astore_3
/*      */     //   18: aload_0
/*      */     //   19: invokevirtual compilerOptions : ()Lorg/eclipse/jdt/internal/compiler/impl/CompilerOptions;
/*      */     //   22: getfield sourceLevel : J
/*      */     //   25: ldc2_w 3932160
/*      */     //   28: lcmp
/*      */     //   29: iflt -> 36
/*      */     //   32: iconst_1
/*      */     //   33: goto -> 37
/*      */     //   36: iconst_0
/*      */     //   37: istore #4
/*      */     //   39: getstatic org/eclipse/jdt/internal/compiler/impl/JavaFeature.SEALED_CLASSES : Lorg/eclipse/jdt/internal/compiler/impl/JavaFeature;
/*      */     //   42: aload_3
/*      */     //   43: invokevirtual isSupported : (Lorg/eclipse/jdt/internal/compiler/impl/CompilerOptions;)Z
/*      */     //   46: istore #5
/*      */     //   48: iload #5
/*      */     //   50: ifeq -> 65
/*      */     //   53: iload_2
/*      */     //   54: ldc_w 335544320
/*      */     //   57: iand
/*      */     //   58: ifeq -> 65
/*      */     //   61: iconst_1
/*      */     //   62: goto -> 66
/*      */     //   65: iconst_0
/*      */     //   66: istore #6
/*      */     //   68: aload_1
/*      */     //   69: invokevirtual isRecord : ()Z
/*      */     //   72: ifeq -> 80
/*      */     //   75: iload_2
/*      */     //   76: bipush #16
/*      */     //   78: ior
/*      */     //   79: istore_2
/*      */     //   80: iload_2
/*      */     //   81: ldc_w 4194304
/*      */     //   84: iand
/*      */     //   85: ifeq -> 96
/*      */     //   88: aload_0
/*      */     //   89: invokevirtual problemReporter : ()Lorg/eclipse/jdt/internal/compiler/problem/ProblemReporter;
/*      */     //   92: aload_1
/*      */     //   93: invokevirtual duplicateModifierForType : (Lorg/eclipse/jdt/internal/compiler/lookup/SourceTypeBinding;)V
/*      */     //   96: aload_1
/*      */     //   97: invokevirtual enclosingType : ()Lorg/eclipse/jdt/internal/compiler/lookup/ReferenceBinding;
/*      */     //   100: astore #7
/*      */     //   102: aload_1
/*      */     //   103: invokevirtual isMemberType : ()Z
/*      */     //   106: istore #8
/*      */     //   108: iload #8
/*      */     //   110: ifeq -> 225
/*      */     //   113: aload_1
/*      */     //   114: invokevirtual hasEnclosingInstanceContext : ()Z
/*      */     //   117: ifeq -> 132
/*      */     //   120: iload_2
/*      */     //   121: aload #7
/*      */     //   123: getfield modifiers : I
/*      */     //   126: ldc_w 1073741824
/*      */     //   129: iand
/*      */     //   130: ior
/*      */     //   131: istore_2
/*      */     //   132: iload_2
/*      */     //   133: aload #7
/*      */     //   135: getfield modifiers : I
/*      */     //   138: sipush #2048
/*      */     //   141: iand
/*      */     //   142: ior
/*      */     //   143: istore_2
/*      */     //   144: aload #7
/*      */     //   146: invokevirtual isInterface : ()Z
/*      */     //   149: ifeq -> 156
/*      */     //   152: iload_2
/*      */     //   153: iconst_1
/*      */     //   154: ior
/*      */     //   155: istore_2
/*      */     //   156: aload_1
/*      */     //   157: invokevirtual isEnum : ()Z
/*      */     //   160: ifeq -> 195
/*      */     //   163: iload #4
/*      */     //   165: ifne -> 187
/*      */     //   168: aload #7
/*      */     //   170: invokevirtual isStatic : ()Z
/*      */     //   173: ifne -> 187
/*      */     //   176: aload_0
/*      */     //   177: invokevirtual problemReporter : ()Lorg/eclipse/jdt/internal/compiler/problem/ProblemReporter;
/*      */     //   180: aload_1
/*      */     //   181: invokevirtual nonStaticContextForEnumMemberType : (Lorg/eclipse/jdt/internal/compiler/lookup/SourceTypeBinding;)V
/*      */     //   184: goto -> 689
/*      */     //   187: iload_2
/*      */     //   188: bipush #8
/*      */     //   190: ior
/*      */     //   191: istore_2
/*      */     //   192: goto -> 689
/*      */     //   195: aload_1
/*      */     //   196: invokevirtual isInterface : ()Z
/*      */     //   199: ifeq -> 210
/*      */     //   202: iload_2
/*      */     //   203: bipush #8
/*      */     //   205: ior
/*      */     //   206: istore_2
/*      */     //   207: goto -> 689
/*      */     //   210: aload_1
/*      */     //   211: invokevirtual isRecord : ()Z
/*      */     //   214: ifeq -> 689
/*      */     //   217: iload_2
/*      */     //   218: bipush #8
/*      */     //   220: ior
/*      */     //   221: istore_2
/*      */     //   222: goto -> 689
/*      */     //   225: aload_1
/*      */     //   226: invokevirtual isLocalType : ()Z
/*      */     //   229: ifeq -> 689
/*      */     //   232: aload_1
/*      */     //   233: invokevirtual isEnum : ()Z
/*      */     //   236: ifeq -> 295
/*      */     //   239: iload #4
/*      */     //   241: ifne -> 261
/*      */     //   244: aload_0
/*      */     //   245: invokevirtual problemReporter : ()Lorg/eclipse/jdt/internal/compiler/problem/ProblemReporter;
/*      */     //   248: aload_0
/*      */     //   249: getfield referenceContext : Lorg/eclipse/jdt/internal/compiler/ast/TypeDeclaration;
/*      */     //   252: invokevirtual illegalLocalTypeDeclaration : (Lorg/eclipse/jdt/internal/compiler/ast/TypeDeclaration;)V
/*      */     //   255: aload_1
/*      */     //   256: iconst_0
/*      */     //   257: putfield modifiers : I
/*      */     //   260: return
/*      */     //   261: iload_2
/*      */     //   262: ldc_w 65535
/*      */     //   265: iand
/*      */     //   266: sipush #-18433
/*      */     //   269: iand
/*      */     //   270: ifne -> 278
/*      */     //   273: iload #6
/*      */     //   275: ifeq -> 287
/*      */     //   278: aload_0
/*      */     //   279: invokevirtual problemReporter : ()Lorg/eclipse/jdt/internal/compiler/problem/ProblemReporter;
/*      */     //   282: aload_1
/*      */     //   283: invokevirtual illegalModifierForLocalEnumDeclaration : (Lorg/eclipse/jdt/internal/compiler/lookup/SourceTypeBinding;)V
/*      */     //   286: return
/*      */     //   287: iload_2
/*      */     //   288: bipush #8
/*      */     //   290: ior
/*      */     //   291: istore_2
/*      */     //   292: goto -> 333
/*      */     //   295: aload_1
/*      */     //   296: invokevirtual isRecord : ()Z
/*      */     //   299: ifeq -> 333
/*      */     //   302: iload_2
/*      */     //   303: bipush #8
/*      */     //   305: iand
/*      */     //   306: ifeq -> 328
/*      */     //   309: aload_0
/*      */     //   310: getfield parent : Lorg/eclipse/jdt/internal/compiler/lookup/Scope;
/*      */     //   313: instanceof org/eclipse/jdt/internal/compiler/lookup/ClassScope
/*      */     //   316: ifne -> 327
/*      */     //   319: aload_0
/*      */     //   320: invokevirtual problemReporter : ()Lorg/eclipse/jdt/internal/compiler/problem/ProblemReporter;
/*      */     //   323: aload_1
/*      */     //   324: invokevirtual recordIllegalStaticModifierForLocalClassOrInterface : (Lorg/eclipse/jdt/internal/compiler/lookup/SourceTypeBinding;)V
/*      */     //   327: return
/*      */     //   328: iload_2
/*      */     //   329: bipush #8
/*      */     //   331: ior
/*      */     //   332: istore_2
/*      */     //   333: aload_1
/*      */     //   334: invokevirtual isAnonymousType : ()Z
/*      */     //   337: ifeq -> 381
/*      */     //   340: aload_0
/*      */     //   341: invokevirtual compilerOptions : ()Lorg/eclipse/jdt/internal/compiler/impl/CompilerOptions;
/*      */     //   344: getfield complianceLevel : J
/*      */     //   347: ldc2_w 3473408
/*      */     //   350: lcmp
/*      */     //   351: ifge -> 359
/*      */     //   354: iload_2
/*      */     //   355: bipush #16
/*      */     //   357: ior
/*      */     //   358: istore_2
/*      */     //   359: aload_0
/*      */     //   360: getfield referenceContext : Lorg/eclipse/jdt/internal/compiler/ast/TypeDeclaration;
/*      */     //   363: getfield allocation : Lorg/eclipse/jdt/internal/compiler/ast/QualifiedAllocationExpression;
/*      */     //   366: getfield type : Lorg/eclipse/jdt/internal/compiler/ast/TypeReference;
/*      */     //   369: ifnonnull -> 423
/*      */     //   372: iload_2
/*      */     //   373: sipush #16384
/*      */     //   376: ior
/*      */     //   377: istore_2
/*      */     //   378: goto -> 423
/*      */     //   381: aload_0
/*      */     //   382: getfield parent : Lorg/eclipse/jdt/internal/compiler/lookup/Scope;
/*      */     //   385: invokevirtual referenceContext : ()Lorg/eclipse/jdt/internal/compiler/impl/ReferenceContext;
/*      */     //   388: instanceof org/eclipse/jdt/internal/compiler/ast/TypeDeclaration
/*      */     //   391: ifeq -> 423
/*      */     //   394: aload_0
/*      */     //   395: getfield parent : Lorg/eclipse/jdt/internal/compiler/lookup/Scope;
/*      */     //   398: invokevirtual referenceContext : ()Lorg/eclipse/jdt/internal/compiler/impl/ReferenceContext;
/*      */     //   401: checkcast org/eclipse/jdt/internal/compiler/ast/TypeDeclaration
/*      */     //   404: astore #9
/*      */     //   406: aload #9
/*      */     //   408: getfield modifiers : I
/*      */     //   411: invokestatic kind : (I)I
/*      */     //   414: iconst_2
/*      */     //   415: if_icmpne -> 423
/*      */     //   418: iload_2
/*      */     //   419: bipush #8
/*      */     //   421: ior
/*      */     //   422: istore_2
/*      */     //   423: aload_0
/*      */     //   424: astore #9
/*      */     //   426: aload #9
/*      */     //   428: getfield kind : I
/*      */     //   431: tableswitch default -> 677, 2 -> 452, 3 -> 624
/*      */     //   452: aload #9
/*      */     //   454: checkcast org/eclipse/jdt/internal/compiler/lookup/MethodScope
/*      */     //   457: astore #10
/*      */     //   459: aload #10
/*      */     //   461: invokevirtual isLambdaScope : ()Z
/*      */     //   464: ifeq -> 474
/*      */     //   467: aload #10
/*      */     //   469: invokevirtual namedMethodScope : ()Lorg/eclipse/jdt/internal/compiler/lookup/MethodScope;
/*      */     //   472: astore #10
/*      */     //   474: aload #10
/*      */     //   476: invokevirtual isInsideInitializer : ()Z
/*      */     //   479: ifeq -> 568
/*      */     //   482: aload #10
/*      */     //   484: getfield referenceContext : Lorg/eclipse/jdt/internal/compiler/impl/ReferenceContext;
/*      */     //   487: checkcast org/eclipse/jdt/internal/compiler/ast/TypeDeclaration
/*      */     //   490: getfield binding : Lorg/eclipse/jdt/internal/compiler/lookup/SourceTypeBinding;
/*      */     //   493: astore #11
/*      */     //   495: aload #10
/*      */     //   497: getfield initializedField : Lorg/eclipse/jdt/internal/compiler/lookup/FieldBinding;
/*      */     //   500: ifnull -> 530
/*      */     //   503: aload #10
/*      */     //   505: getfield initializedField : Lorg/eclipse/jdt/internal/compiler/lookup/FieldBinding;
/*      */     //   508: invokevirtual isViewedAsDeprecated : ()Z
/*      */     //   511: ifeq -> 677
/*      */     //   514: aload_1
/*      */     //   515: invokevirtual isDeprecated : ()Z
/*      */     //   518: ifne -> 677
/*      */     //   521: iload_2
/*      */     //   522: ldc_w 2097152
/*      */     //   525: ior
/*      */     //   526: istore_2
/*      */     //   527: goto -> 677
/*      */     //   530: aload #11
/*      */     //   532: invokevirtual isStrictfp : ()Z
/*      */     //   535: ifeq -> 544
/*      */     //   538: iload_2
/*      */     //   539: sipush #2048
/*      */     //   542: ior
/*      */     //   543: istore_2
/*      */     //   544: aload #11
/*      */     //   546: invokevirtual isViewedAsDeprecated : ()Z
/*      */     //   549: ifeq -> 677
/*      */     //   552: aload_1
/*      */     //   553: invokevirtual isDeprecated : ()Z
/*      */     //   556: ifne -> 677
/*      */     //   559: iload_2
/*      */     //   560: ldc_w 2097152
/*      */     //   563: ior
/*      */     //   564: istore_2
/*      */     //   565: goto -> 677
/*      */     //   568: aload #10
/*      */     //   570: getfield referenceContext : Lorg/eclipse/jdt/internal/compiler/impl/ReferenceContext;
/*      */     //   573: checkcast org/eclipse/jdt/internal/compiler/ast/AbstractMethodDeclaration
/*      */     //   576: getfield binding : Lorg/eclipse/jdt/internal/compiler/lookup/MethodBinding;
/*      */     //   579: astore #11
/*      */     //   581: aload #11
/*      */     //   583: ifnull -> 677
/*      */     //   586: aload #11
/*      */     //   588: invokevirtual isStrictfp : ()Z
/*      */     //   591: ifeq -> 600
/*      */     //   594: iload_2
/*      */     //   595: sipush #2048
/*      */     //   598: ior
/*      */     //   599: istore_2
/*      */     //   600: aload #11
/*      */     //   602: invokevirtual isViewedAsDeprecated : ()Z
/*      */     //   605: ifeq -> 677
/*      */     //   608: aload_1
/*      */     //   609: invokevirtual isDeprecated : ()Z
/*      */     //   612: ifne -> 677
/*      */     //   615: iload_2
/*      */     //   616: ldc_w 2097152
/*      */     //   619: ior
/*      */     //   620: istore_2
/*      */     //   621: goto -> 677
/*      */     //   624: aload #7
/*      */     //   626: invokevirtual isStrictfp : ()Z
/*      */     //   629: ifeq -> 638
/*      */     //   632: iload_2
/*      */     //   633: sipush #2048
/*      */     //   636: ior
/*      */     //   637: istore_2
/*      */     //   638: aload #7
/*      */     //   640: invokevirtual isViewedAsDeprecated : ()Z
/*      */     //   643: ifeq -> 677
/*      */     //   646: aload_1
/*      */     //   647: invokevirtual isDeprecated : ()Z
/*      */     //   650: ifne -> 677
/*      */     //   653: iload_2
/*      */     //   654: ldc_w 2097152
/*      */     //   657: ior
/*      */     //   658: istore_2
/*      */     //   659: aload_1
/*      */     //   660: dup
/*      */     //   661: getfield tagBits : J
/*      */     //   664: aload #7
/*      */     //   666: getfield tagBits : J
/*      */     //   669: ldc2_w 4611686018427387904
/*      */     //   672: land
/*      */     //   673: lor
/*      */     //   674: putfield tagBits : J
/*      */     //   677: aload #9
/*      */     //   679: getfield parent : Lorg/eclipse/jdt/internal/compiler/lookup/Scope;
/*      */     //   682: astore #9
/*      */     //   684: aload #9
/*      */     //   686: ifnonnull -> 426
/*      */     //   689: iload_2
/*      */     //   690: ldc_w 65535
/*      */     //   693: iand
/*      */     //   694: istore #9
/*      */     //   696: iload #9
/*      */     //   698: sipush #512
/*      */     //   701: iand
/*      */     //   702: ifeq -> 891
/*      */     //   705: iload #8
/*      */     //   707: ifeq -> 750
/*      */     //   710: iload #9
/*      */     //   712: sipush #-11792
/*      */     //   715: iand
/*      */     //   716: ifeq -> 852
/*      */     //   719: iload #9
/*      */     //   721: sipush #8192
/*      */     //   724: iand
/*      */     //   725: ifeq -> 739
/*      */     //   728: aload_0
/*      */     //   729: invokevirtual problemReporter : ()Lorg/eclipse/jdt/internal/compiler/problem/ProblemReporter;
/*      */     //   732: aload_1
/*      */     //   733: invokevirtual illegalModifierForAnnotationMemberType : (Lorg/eclipse/jdt/internal/compiler/lookup/SourceTypeBinding;)V
/*      */     //   736: goto -> 852
/*      */     //   739: aload_0
/*      */     //   740: invokevirtual problemReporter : ()Lorg/eclipse/jdt/internal/compiler/problem/ProblemReporter;
/*      */     //   743: aload_1
/*      */     //   744: invokevirtual illegalModifierForMemberInterface : (Lorg/eclipse/jdt/internal/compiler/lookup/SourceTypeBinding;)V
/*      */     //   747: goto -> 852
/*      */     //   750: aload_1
/*      */     //   751: invokevirtual isLocalType : ()Z
/*      */     //   754: ifeq -> 815
/*      */     //   757: sipush #11776
/*      */     //   760: iload #4
/*      */     //   762: ifeq -> 780
/*      */     //   765: aload_0
/*      */     //   766: getfield parent : Lorg/eclipse/jdt/internal/compiler/lookup/Scope;
/*      */     //   769: instanceof org/eclipse/jdt/internal/compiler/lookup/ClassScope
/*      */     //   772: ifeq -> 780
/*      */     //   775: bipush #8
/*      */     //   777: goto -> 781
/*      */     //   780: iconst_0
/*      */     //   781: ior
/*      */     //   782: iconst_m1
/*      */     //   783: ixor
/*      */     //   784: istore #10
/*      */     //   786: iload #9
/*      */     //   788: iload #10
/*      */     //   790: iand
/*      */     //   791: ifne -> 799
/*      */     //   794: iload #6
/*      */     //   796: ifeq -> 807
/*      */     //   799: aload_0
/*      */     //   800: invokevirtual problemReporter : ()Lorg/eclipse/jdt/internal/compiler/problem/ProblemReporter;
/*      */     //   803: aload_1
/*      */     //   804: invokevirtual localStaticsIllegalVisibilityModifierForInterfaceLocalType : (Lorg/eclipse/jdt/internal/compiler/lookup/SourceTypeBinding;)V
/*      */     //   807: iload_2
/*      */     //   808: bipush #8
/*      */     //   810: ior
/*      */     //   811: istore_2
/*      */     //   812: goto -> 852
/*      */     //   815: iload #9
/*      */     //   817: sipush #-11778
/*      */     //   820: iand
/*      */     //   821: ifeq -> 852
/*      */     //   824: iload #9
/*      */     //   826: sipush #8192
/*      */     //   829: iand
/*      */     //   830: ifeq -> 844
/*      */     //   833: aload_0
/*      */     //   834: invokevirtual problemReporter : ()Lorg/eclipse/jdt/internal/compiler/problem/ProblemReporter;
/*      */     //   837: aload_1
/*      */     //   838: invokevirtual illegalModifierForAnnotationType : (Lorg/eclipse/jdt/internal/compiler/lookup/SourceTypeBinding;)V
/*      */     //   841: goto -> 852
/*      */     //   844: aload_0
/*      */     //   845: invokevirtual problemReporter : ()Lorg/eclipse/jdt/internal/compiler/problem/ProblemReporter;
/*      */     //   848: aload_1
/*      */     //   849: invokevirtual illegalModifierForInterface : (Lorg/eclipse/jdt/internal/compiler/lookup/SourceTypeBinding;)V
/*      */     //   852: aload_1
/*      */     //   853: getfield sourceName : [C
/*      */     //   856: getstatic org/eclipse/jdt/internal/compiler/lookup/TypeConstants.PACKAGE_INFO_NAME : [C
/*      */     //   859: if_acmpne -> 882
/*      */     //   862: aload_0
/*      */     //   863: invokevirtual compilerOptions : ()Lorg/eclipse/jdt/internal/compiler/impl/CompilerOptions;
/*      */     //   866: getfield targetJDK : J
/*      */     //   869: ldc2_w 3211264
/*      */     //   872: lcmp
/*      */     //   873: ifle -> 882
/*      */     //   876: iload_2
/*      */     //   877: sipush #4096
/*      */     //   880: ior
/*      */     //   881: istore_2
/*      */     //   882: iload_2
/*      */     //   883: sipush #1024
/*      */     //   886: ior
/*      */     //   887: istore_2
/*      */     //   888: goto -> 1495
/*      */     //   891: iload #9
/*      */     //   893: sipush #16384
/*      */     //   896: iand
/*      */     //   897: ifeq -> 1268
/*      */     //   900: iload #8
/*      */     //   902: ifeq -> 944
/*      */     //   905: iload #9
/*      */     //   907: sipush #-18448
/*      */     //   910: iand
/*      */     //   911: ifne -> 919
/*      */     //   914: iload #6
/*      */     //   916: ifeq -> 973
/*      */     //   919: aload_0
/*      */     //   920: invokevirtual problemReporter : ()Lorg/eclipse/jdt/internal/compiler/problem/ProblemReporter;
/*      */     //   923: aload_1
/*      */     //   924: invokevirtual illegalModifierForMemberEnum : (Lorg/eclipse/jdt/internal/compiler/lookup/SourceTypeBinding;)V
/*      */     //   927: iload_2
/*      */     //   928: sipush #-1025
/*      */     //   931: iand
/*      */     //   932: istore_2
/*      */     //   933: iload #9
/*      */     //   935: sipush #-1025
/*      */     //   938: iand
/*      */     //   939: istore #9
/*      */     //   941: goto -> 973
/*      */     //   944: aload_1
/*      */     //   945: invokevirtual isLocalType : ()Z
/*      */     //   948: ifne -> 973
/*      */     //   951: iload #9
/*      */     //   953: sipush #-18434
/*      */     //   956: iand
/*      */     //   957: ifne -> 965
/*      */     //   960: iload #6
/*      */     //   962: ifeq -> 973
/*      */     //   965: aload_0
/*      */     //   966: invokevirtual problemReporter : ()Lorg/eclipse/jdt/internal/compiler/problem/ProblemReporter;
/*      */     //   969: aload_1
/*      */     //   970: invokevirtual illegalModifierForEnum : (Lorg/eclipse/jdt/internal/compiler/lookup/SourceTypeBinding;)V
/*      */     //   973: aload_1
/*      */     //   974: invokevirtual isAnonymousType : ()Z
/*      */     //   977: ifne -> 1495
/*      */     //   980: aload_0
/*      */     //   981: getfield referenceContext : Lorg/eclipse/jdt/internal/compiler/ast/TypeDeclaration;
/*      */     //   984: getfield bits : I
/*      */     //   987: sipush #2048
/*      */     //   990: iand
/*      */     //   991: ifeq -> 1003
/*      */     //   994: iload_2
/*      */     //   995: sipush #1024
/*      */     //   998: ior
/*      */     //   999: istore_2
/*      */     //   1000: goto -> 1173
/*      */     //   1003: aload_0
/*      */     //   1004: getfield referenceContext : Lorg/eclipse/jdt/internal/compiler/ast/TypeDeclaration;
/*      */     //   1007: astore #10
/*      */     //   1009: aload #10
/*      */     //   1011: getfield fields : [Lorg/eclipse/jdt/internal/compiler/ast/FieldDeclaration;
/*      */     //   1014: astore #11
/*      */     //   1016: aload #11
/*      */     //   1018: ifnonnull -> 1025
/*      */     //   1021: iconst_0
/*      */     //   1022: goto -> 1028
/*      */     //   1025: aload #11
/*      */     //   1027: arraylength
/*      */     //   1028: istore #12
/*      */     //   1030: iload #12
/*      */     //   1032: ifne -> 1038
/*      */     //   1035: goto -> 1173
/*      */     //   1038: aload #10
/*      */     //   1040: getfield methods : [Lorg/eclipse/jdt/internal/compiler/ast/AbstractMethodDeclaration;
/*      */     //   1043: astore #13
/*      */     //   1045: aload #13
/*      */     //   1047: ifnonnull -> 1054
/*      */     //   1050: iconst_0
/*      */     //   1051: goto -> 1057
/*      */     //   1054: aload #13
/*      */     //   1056: arraylength
/*      */     //   1057: istore #14
/*      */     //   1059: aload #10
/*      */     //   1061: getfield superInterfaces : [Lorg/eclipse/jdt/internal/compiler/ast/TypeReference;
/*      */     //   1064: ifnull -> 1071
/*      */     //   1067: iconst_1
/*      */     //   1068: goto -> 1072
/*      */     //   1071: iconst_0
/*      */     //   1072: istore #15
/*      */     //   1074: iconst_0
/*      */     //   1075: istore #16
/*      */     //   1077: goto -> 1093
/*      */     //   1080: aload #13
/*      */     //   1082: iload #16
/*      */     //   1084: aaload
/*      */     //   1085: invokevirtual isAbstract : ()Z
/*      */     //   1088: istore #15
/*      */     //   1090: iinc #16, 1
/*      */     //   1093: iload #16
/*      */     //   1095: iload #14
/*      */     //   1097: if_icmpge -> 1105
/*      */     //   1100: iload #15
/*      */     //   1102: ifeq -> 1080
/*      */     //   1105: iload #15
/*      */     //   1107: ifne -> 1113
/*      */     //   1110: goto -> 1173
/*      */     //   1113: iconst_0
/*      */     //   1114: istore #16
/*      */     //   1116: iconst_0
/*      */     //   1117: istore #17
/*      */     //   1119: goto -> 1155
/*      */     //   1122: aload #11
/*      */     //   1124: iload #17
/*      */     //   1126: aaload
/*      */     //   1127: astore #18
/*      */     //   1129: aload #18
/*      */     //   1131: invokevirtual getKind : ()I
/*      */     //   1134: iconst_3
/*      */     //   1135: if_icmpne -> 1152
/*      */     //   1138: aload #18
/*      */     //   1140: getfield initialization : Lorg/eclipse/jdt/internal/compiler/ast/Expression;
/*      */     //   1143: instanceof org/eclipse/jdt/internal/compiler/ast/QualifiedAllocationExpression
/*      */     //   1146: ifeq -> 1173
/*      */     //   1149: iconst_1
/*      */     //   1150: istore #16
/*      */     //   1152: iinc #17, 1
/*      */     //   1155: iload #17
/*      */     //   1157: iload #12
/*      */     //   1159: if_icmplt -> 1122
/*      */     //   1162: iload #16
/*      */     //   1164: ifeq -> 1173
/*      */     //   1167: iload_2
/*      */     //   1168: sipush #1024
/*      */     //   1171: ior
/*      */     //   1172: istore_2
/*      */     //   1173: aload_0
/*      */     //   1174: getfield referenceContext : Lorg/eclipse/jdt/internal/compiler/ast/TypeDeclaration;
/*      */     //   1177: astore #10
/*      */     //   1179: aload #10
/*      */     //   1181: getfield fields : [Lorg/eclipse/jdt/internal/compiler/ast/FieldDeclaration;
/*      */     //   1184: astore #11
/*      */     //   1186: aload #11
/*      */     //   1188: ifnull -> 1242
/*      */     //   1191: iconst_0
/*      */     //   1192: istore #12
/*      */     //   1194: aload #11
/*      */     //   1196: arraylength
/*      */     //   1197: istore #13
/*      */     //   1199: goto -> 1235
/*      */     //   1202: aload #11
/*      */     //   1204: iload #12
/*      */     //   1206: aaload
/*      */     //   1207: astore #14
/*      */     //   1209: aload #14
/*      */     //   1211: invokevirtual getKind : ()I
/*      */     //   1214: iconst_3
/*      */     //   1215: if_icmpne -> 1232
/*      */     //   1218: aload #14
/*      */     //   1220: getfield initialization : Lorg/eclipse/jdt/internal/compiler/ast/Expression;
/*      */     //   1223: instanceof org/eclipse/jdt/internal/compiler/ast/QualifiedAllocationExpression
/*      */     //   1226: ifeq -> 1232
/*      */     //   1229: goto -> 1247
/*      */     //   1232: iinc #12, 1
/*      */     //   1235: iload #12
/*      */     //   1237: iload #13
/*      */     //   1239: if_icmplt -> 1202
/*      */     //   1242: iload_2
/*      */     //   1243: bipush #16
/*      */     //   1245: ior
/*      */     //   1246: istore_2
/*      */     //   1247: iload #5
/*      */     //   1249: ifeq -> 1495
/*      */     //   1252: iload_2
/*      */     //   1253: bipush #16
/*      */     //   1255: iand
/*      */     //   1256: ifne -> 1495
/*      */     //   1259: iload_2
/*      */     //   1260: ldc_w 268435456
/*      */     //   1263: ior
/*      */     //   1264: istore_2
/*      */     //   1265: goto -> 1495
/*      */     //   1268: aload_1
/*      */     //   1269: invokevirtual isRecord : ()Z
/*      */     //   1272: ifeq -> 1373
/*      */     //   1275: ldc_w 335544320
/*      */     //   1278: istore #10
/*      */     //   1280: iload #8
/*      */     //   1282: ifeq -> 1312
/*      */     //   1285: iload #9
/*      */     //   1287: sipush #-2080
/*      */     //   1290: iand
/*      */     //   1291: ifne -> 1301
/*      */     //   1294: iload_2
/*      */     //   1295: iload #10
/*      */     //   1297: iand
/*      */     //   1298: ifeq -> 1495
/*      */     //   1301: aload_0
/*      */     //   1302: invokevirtual problemReporter : ()Lorg/eclipse/jdt/internal/compiler/problem/ProblemReporter;
/*      */     //   1305: aload_1
/*      */     //   1306: invokevirtual illegalModifierForInnerRecord : (Lorg/eclipse/jdt/internal/compiler/lookup/SourceTypeBinding;)V
/*      */     //   1309: goto -> 1495
/*      */     //   1312: aload_1
/*      */     //   1313: invokevirtual isLocalType : ()Z
/*      */     //   1316: ifeq -> 1346
/*      */     //   1319: iload #9
/*      */     //   1321: sipush #-2073
/*      */     //   1324: iand
/*      */     //   1325: ifne -> 1335
/*      */     //   1328: iload_2
/*      */     //   1329: iload #10
/*      */     //   1331: iand
/*      */     //   1332: ifeq -> 1495
/*      */     //   1335: aload_0
/*      */     //   1336: invokevirtual problemReporter : ()Lorg/eclipse/jdt/internal/compiler/problem/ProblemReporter;
/*      */     //   1339: aload_1
/*      */     //   1340: invokevirtual illegalModifierForLocalRecord : (Lorg/eclipse/jdt/internal/compiler/lookup/SourceTypeBinding;)V
/*      */     //   1343: goto -> 1495
/*      */     //   1346: iload #9
/*      */     //   1348: sipush #-2066
/*      */     //   1351: iand
/*      */     //   1352: ifne -> 1362
/*      */     //   1355: iload_2
/*      */     //   1356: iload #10
/*      */     //   1358: iand
/*      */     //   1359: ifeq -> 1495
/*      */     //   1362: aload_0
/*      */     //   1363: invokevirtual problemReporter : ()Lorg/eclipse/jdt/internal/compiler/problem/ProblemReporter;
/*      */     //   1366: aload_1
/*      */     //   1367: invokevirtual illegalModifierForRecord : (Lorg/eclipse/jdt/internal/compiler/lookup/SourceTypeBinding;)V
/*      */     //   1370: goto -> 1495
/*      */     //   1373: iload #8
/*      */     //   1375: ifeq -> 1398
/*      */     //   1378: iload #9
/*      */     //   1380: sipush #-3104
/*      */     //   1383: iand
/*      */     //   1384: ifeq -> 1475
/*      */     //   1387: aload_0
/*      */     //   1388: invokevirtual problemReporter : ()Lorg/eclipse/jdt/internal/compiler/problem/ProblemReporter;
/*      */     //   1391: aload_1
/*      */     //   1392: invokevirtual illegalModifierForMemberClass : (Lorg/eclipse/jdt/internal/compiler/lookup/SourceTypeBinding;)V
/*      */     //   1395: goto -> 1475
/*      */     //   1398: aload_1
/*      */     //   1399: invokevirtual isLocalType : ()Z
/*      */     //   1402: ifeq -> 1458
/*      */     //   1405: sipush #3088
/*      */     //   1408: iload #4
/*      */     //   1410: ifeq -> 1428
/*      */     //   1413: aload_0
/*      */     //   1414: getfield parent : Lorg/eclipse/jdt/internal/compiler/lookup/Scope;
/*      */     //   1417: instanceof org/eclipse/jdt/internal/compiler/lookup/ClassScope
/*      */     //   1420: ifeq -> 1428
/*      */     //   1423: bipush #8
/*      */     //   1425: goto -> 1429
/*      */     //   1428: iconst_0
/*      */     //   1429: ior
/*      */     //   1430: iconst_m1
/*      */     //   1431: ixor
/*      */     //   1432: istore #10
/*      */     //   1434: iload #9
/*      */     //   1436: iload #10
/*      */     //   1438: iand
/*      */     //   1439: ifne -> 1447
/*      */     //   1442: iload #6
/*      */     //   1444: ifeq -> 1475
/*      */     //   1447: aload_0
/*      */     //   1448: invokevirtual problemReporter : ()Lorg/eclipse/jdt/internal/compiler/problem/ProblemReporter;
/*      */     //   1451: aload_1
/*      */     //   1452: invokevirtual illegalModifierForLocalClass : (Lorg/eclipse/jdt/internal/compiler/lookup/SourceTypeBinding;)V
/*      */     //   1455: goto -> 1475
/*      */     //   1458: iload #9
/*      */     //   1460: sipush #-3090
/*      */     //   1463: iand
/*      */     //   1464: ifeq -> 1475
/*      */     //   1467: aload_0
/*      */     //   1468: invokevirtual problemReporter : ()Lorg/eclipse/jdt/internal/compiler/problem/ProblemReporter;
/*      */     //   1471: aload_1
/*      */     //   1472: invokevirtual illegalModifierForClass : (Lorg/eclipse/jdt/internal/compiler/lookup/SourceTypeBinding;)V
/*      */     //   1475: iload #9
/*      */     //   1477: sipush #1040
/*      */     //   1480: iand
/*      */     //   1481: sipush #1040
/*      */     //   1484: if_icmpne -> 1495
/*      */     //   1487: aload_0
/*      */     //   1488: invokevirtual problemReporter : ()Lorg/eclipse/jdt/internal/compiler/problem/ProblemReporter;
/*      */     //   1491: aload_1
/*      */     //   1492: invokevirtual illegalModifierCombinationFinalAbstractForClass : (Lorg/eclipse/jdt/internal/compiler/lookup/SourceTypeBinding;)V
/*      */     //   1495: iload #8
/*      */     //   1497: ifeq -> 1675
/*      */     //   1500: aload #7
/*      */     //   1502: invokevirtual isInterface : ()Z
/*      */     //   1505: ifeq -> 1551
/*      */     //   1508: iload #9
/*      */     //   1510: bipush #6
/*      */     //   1512: iand
/*      */     //   1513: ifeq -> 1630
/*      */     //   1516: aload_0
/*      */     //   1517: invokevirtual problemReporter : ()Lorg/eclipse/jdt/internal/compiler/problem/ProblemReporter;
/*      */     //   1520: aload_1
/*      */     //   1521: invokevirtual illegalVisibilityModifierForInterfaceMemberType : (Lorg/eclipse/jdt/internal/compiler/lookup/SourceTypeBinding;)V
/*      */     //   1524: iload #9
/*      */     //   1526: iconst_4
/*      */     //   1527: iand
/*      */     //   1528: ifeq -> 1536
/*      */     //   1531: iload_2
/*      */     //   1532: bipush #-5
/*      */     //   1534: iand
/*      */     //   1535: istore_2
/*      */     //   1536: iload #9
/*      */     //   1538: iconst_2
/*      */     //   1539: iand
/*      */     //   1540: ifeq -> 1630
/*      */     //   1543: iload_2
/*      */     //   1544: bipush #-3
/*      */     //   1546: iand
/*      */     //   1547: istore_2
/*      */     //   1548: goto -> 1630
/*      */     //   1551: iload #9
/*      */     //   1553: bipush #7
/*      */     //   1555: iand
/*      */     //   1556: istore #10
/*      */     //   1558: iload #10
/*      */     //   1560: iload #10
/*      */     //   1562: iconst_1
/*      */     //   1563: isub
/*      */     //   1564: iand
/*      */     //   1565: iconst_1
/*      */     //   1566: if_icmple -> 1630
/*      */     //   1569: aload_0
/*      */     //   1570: invokevirtual problemReporter : ()Lorg/eclipse/jdt/internal/compiler/problem/ProblemReporter;
/*      */     //   1573: aload_1
/*      */     //   1574: invokevirtual illegalVisibilityModifierCombinationForMemberType : (Lorg/eclipse/jdt/internal/compiler/lookup/SourceTypeBinding;)V
/*      */     //   1577: iload #10
/*      */     //   1579: iconst_1
/*      */     //   1580: iand
/*      */     //   1581: ifeq -> 1611
/*      */     //   1584: iload #10
/*      */     //   1586: iconst_4
/*      */     //   1587: iand
/*      */     //   1588: ifeq -> 1596
/*      */     //   1591: iload_2
/*      */     //   1592: bipush #-5
/*      */     //   1594: iand
/*      */     //   1595: istore_2
/*      */     //   1596: iload #10
/*      */     //   1598: iconst_2
/*      */     //   1599: iand
/*      */     //   1600: ifeq -> 1630
/*      */     //   1603: iload_2
/*      */     //   1604: bipush #-3
/*      */     //   1606: iand
/*      */     //   1607: istore_2
/*      */     //   1608: goto -> 1630
/*      */     //   1611: iload #10
/*      */     //   1613: iconst_4
/*      */     //   1614: iand
/*      */     //   1615: ifeq -> 1630
/*      */     //   1618: iload #10
/*      */     //   1620: iconst_2
/*      */     //   1621: iand
/*      */     //   1622: ifeq -> 1630
/*      */     //   1625: iload_2
/*      */     //   1626: bipush #-3
/*      */     //   1628: iand
/*      */     //   1629: istore_2
/*      */     //   1630: iload #9
/*      */     //   1632: bipush #8
/*      */     //   1634: iand
/*      */     //   1635: ifne -> 1654
/*      */     //   1638: aload #7
/*      */     //   1640: invokevirtual isInterface : ()Z
/*      */     //   1643: ifeq -> 1675
/*      */     //   1646: iload_2
/*      */     //   1647: bipush #8
/*      */     //   1649: ior
/*      */     //   1650: istore_2
/*      */     //   1651: goto -> 1675
/*      */     //   1654: aload #7
/*      */     //   1656: invokevirtual isStatic : ()Z
/*      */     //   1659: ifne -> 1675
/*      */     //   1662: iload #4
/*      */     //   1664: ifne -> 1675
/*      */     //   1667: aload_0
/*      */     //   1668: invokevirtual problemReporter : ()Lorg/eclipse/jdt/internal/compiler/problem/ProblemReporter;
/*      */     //   1671: aload_1
/*      */     //   1672: invokevirtual illegalStaticModifierForMemberType : (Lorg/eclipse/jdt/internal/compiler/lookup/SourceTypeBinding;)V
/*      */     //   1675: aload_1
/*      */     //   1676: iload_2
/*      */     //   1677: putfield modifiers : I
/*      */     //   1680: return
/*      */     // Line number table:
/*      */     //   Java source line number -> byte code offset
/*      */     //   #587	-> 0
/*      */     //   #588	-> 8
/*      */     //   #589	-> 13
/*      */     //   #590	-> 18
/*      */     //   #591	-> 39
/*      */     //   #592	-> 48
/*      */     //   #593	-> 53
/*      */     //   #592	-> 61
/*      */     //   #594	-> 68
/*      */     //   #596	-> 75
/*      */     //   #598	-> 80
/*      */     //   #599	-> 88
/*      */     //   #600	-> 96
/*      */     //   #601	-> 102
/*      */     //   #602	-> 108
/*      */     //   #603	-> 113
/*      */     //   #604	-> 120
/*      */     //   #605	-> 132
/*      */     //   #607	-> 144
/*      */     //   #608	-> 152
/*      */     //   #609	-> 156
/*      */     //   #610	-> 163
/*      */     //   #611	-> 176
/*      */     //   #613	-> 187
/*      */     //   #614	-> 192
/*      */     //   #615	-> 202
/*      */     //   #616	-> 207
/*      */     //   #618	-> 217
/*      */     //   #620	-> 222
/*      */     //   #621	-> 232
/*      */     //   #622	-> 239
/*      */     //   #623	-> 244
/*      */     //   #624	-> 255
/*      */     //   #625	-> 260
/*      */     //   #628	-> 261
/*      */     //   #629	-> 273
/*      */     //   #630	-> 278
/*      */     //   #631	-> 286
/*      */     //   #633	-> 287
/*      */     //   #634	-> 292
/*      */     //   #639	-> 302
/*      */     //   #640	-> 309
/*      */     //   #641	-> 319
/*      */     //   #642	-> 327
/*      */     //   #644	-> 328
/*      */     //   #646	-> 333
/*      */     //   #647	-> 340
/*      */     //   #648	-> 354
/*      */     //   #650	-> 359
/*      */     //   #651	-> 372
/*      */     //   #652	-> 378
/*      */     //   #653	-> 394
/*      */     //   #654	-> 406
/*      */     //   #656	-> 418
/*      */     //   #659	-> 423
/*      */     //   #661	-> 426
/*      */     //   #663	-> 452
/*      */     //   #664	-> 459
/*      */     //   #665	-> 467
/*      */     //   #666	-> 474
/*      */     //   #667	-> 482
/*      */     //   #670	-> 495
/*      */     //   #672	-> 503
/*      */     //   #673	-> 521
/*      */     //   #674	-> 527
/*      */     //   #675	-> 530
/*      */     //   #676	-> 538
/*      */     //   #677	-> 544
/*      */     //   #678	-> 559
/*      */     //   #680	-> 565
/*      */     //   #681	-> 568
/*      */     //   #682	-> 581
/*      */     //   #683	-> 586
/*      */     //   #684	-> 594
/*      */     //   #685	-> 600
/*      */     //   #686	-> 615
/*      */     //   #689	-> 621
/*      */     //   #692	-> 624
/*      */     //   #693	-> 632
/*      */     //   #694	-> 638
/*      */     //   #695	-> 653
/*      */     //   #696	-> 659
/*      */     //   #699	-> 677
/*      */     //   #700	-> 679
/*      */     //   #701	-> 684
/*      */     //   #705	-> 689
/*      */     //   #707	-> 696
/*      */     //   #709	-> 705
/*      */     //   #712	-> 710
/*      */     //   #713	-> 719
/*      */     //   #714	-> 728
/*      */     //   #716	-> 739
/*      */     //   #724	-> 747
/*      */     //   #725	-> 757
/*      */     //   #727	-> 760
/*      */     //   #725	-> 781
/*      */     //   #728	-> 786
/*      */     //   #729	-> 794
/*      */     //   #730	-> 799
/*      */     //   #734	-> 807
/*      */     //   #735	-> 812
/*      */     //   #737	-> 815
/*      */     //   #738	-> 824
/*      */     //   #739	-> 833
/*      */     //   #741	-> 844
/*      */     //   #747	-> 852
/*      */     //   #748	-> 876
/*      */     //   #750	-> 882
/*      */     //   #751	-> 888
/*      */     //   #753	-> 900
/*      */     //   #755	-> 905
/*      */     //   #756	-> 919
/*      */     //   #757	-> 927
/*      */     //   #758	-> 933
/*      */     //   #762	-> 941
/*      */     //   #768	-> 951
/*      */     //   #769	-> 965
/*      */     //   #771	-> 973
/*      */     //   #774	-> 980
/*      */     //   #775	-> 994
/*      */     //   #776	-> 1000
/*      */     //   #780	-> 1003
/*      */     //   #781	-> 1009
/*      */     //   #782	-> 1016
/*      */     //   #783	-> 1030
/*      */     //   #784	-> 1038
/*      */     //   #785	-> 1045
/*      */     //   #787	-> 1059
/*      */     //   #788	-> 1074
/*      */     //   #789	-> 1080
/*      */     //   #788	-> 1090
/*      */     //   #790	-> 1105
/*      */     //   #791	-> 1113
/*      */     //   #792	-> 1116
/*      */     //   #793	-> 1122
/*      */     //   #794	-> 1129
/*      */     //   #795	-> 1138
/*      */     //   #796	-> 1149
/*      */     //   #792	-> 1152
/*      */     //   #804	-> 1162
/*      */     //   #805	-> 1167
/*      */     //   #810	-> 1173
/*      */     //   #811	-> 1179
/*      */     //   #812	-> 1186
/*      */     //   #813	-> 1191
/*      */     //   #814	-> 1202
/*      */     //   #815	-> 1209
/*      */     //   #816	-> 1218
/*      */     //   #817	-> 1229
/*      */     //   #813	-> 1232
/*      */     //   #822	-> 1242
/*      */     //   #824	-> 1247
/*      */     //   #825	-> 1259
/*      */     //   #827	-> 1265
/*      */     //   #828	-> 1275
/*      */     //   #829	-> 1280
/*      */     //   #831	-> 1285
/*      */     //   #832	-> 1301
/*      */     //   #833	-> 1309
/*      */     //   #835	-> 1319
/*      */     //   #836	-> 1335
/*      */     //   #837	-> 1343
/*      */     //   #839	-> 1346
/*      */     //   #840	-> 1362
/*      */     //   #859	-> 1370
/*      */     //   #861	-> 1373
/*      */     //   #863	-> 1378
/*      */     //   #864	-> 1387
/*      */     //   #865	-> 1395
/*      */     //   #866	-> 1405
/*      */     //   #867	-> 1408
/*      */     //   #866	-> 1429
/*      */     //   #868	-> 1434
/*      */     //   #869	-> 1447
/*      */     //   #870	-> 1455
/*      */     //   #873	-> 1458
/*      */     //   #874	-> 1467
/*      */     //   #878	-> 1475
/*      */     //   #879	-> 1487
/*      */     //   #882	-> 1495
/*      */     //   #884	-> 1500
/*      */     //   #885	-> 1508
/*      */     //   #886	-> 1516
/*      */     //   #889	-> 1524
/*      */     //   #890	-> 1531
/*      */     //   #891	-> 1536
/*      */     //   #892	-> 1543
/*      */     //   #894	-> 1548
/*      */     //   #895	-> 1551
/*      */     //   #896	-> 1558
/*      */     //   #897	-> 1569
/*      */     //   #900	-> 1577
/*      */     //   #901	-> 1584
/*      */     //   #902	-> 1591
/*      */     //   #903	-> 1596
/*      */     //   #904	-> 1603
/*      */     //   #905	-> 1608
/*      */     //   #906	-> 1625
/*      */     //   #912	-> 1630
/*      */     //   #913	-> 1638
/*      */     //   #914	-> 1646
/*      */     //   #915	-> 1651
/*      */     //   #919	-> 1662
/*      */     //   #921	-> 1667
/*      */     //   #925	-> 1675
/*      */     //   #926	-> 1680
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	descriptor
/*      */     //   0	1681	0	this	Lorg/eclipse/jdt/internal/compiler/lookup/ClassScope;
/*      */     //   8	1673	1	sourceType	Lorg/eclipse/jdt/internal/compiler/lookup/SourceTypeBinding;
/*      */     //   13	1668	2	modifiers	I
/*      */     //   18	1663	3	options	Lorg/eclipse/jdt/internal/compiler/impl/CompilerOptions;
/*      */     //   39	1642	4	is16Plus	Z
/*      */     //   48	1633	5	isSealedSupported	Z
/*      */     //   68	1613	6	flagSealedNonModifiers	Z
/*      */     //   102	1579	7	enclosingType	Lorg/eclipse/jdt/internal/compiler/lookup/ReferenceBinding;
/*      */     //   108	1573	8	isMemberType	Z
/*      */     //   406	17	9	typeDecl	Lorg/eclipse/jdt/internal/compiler/ast/TypeDeclaration;
/*      */     //   426	263	9	scope	Lorg/eclipse/jdt/internal/compiler/lookup/Scope;
/*      */     //   459	165	10	methodScope	Lorg/eclipse/jdt/internal/compiler/lookup/MethodScope;
/*      */     //   495	70	11	type	Lorg/eclipse/jdt/internal/compiler/lookup/SourceTypeBinding;
/*      */     //   581	40	11	method	Lorg/eclipse/jdt/internal/compiler/lookup/MethodBinding;
/*      */     //   696	985	9	realModifiers	I
/*      */     //   786	26	10	UNEXPECTED_MODIFIERS	I
/*      */     //   1009	164	10	typeDeclaration	Lorg/eclipse/jdt/internal/compiler/ast/TypeDeclaration;
/*      */     //   1016	157	11	fields	[Lorg/eclipse/jdt/internal/compiler/ast/FieldDeclaration;
/*      */     //   1030	143	12	fieldsLength	I
/*      */     //   1045	128	13	methods	[Lorg/eclipse/jdt/internal/compiler/ast/AbstractMethodDeclaration;
/*      */     //   1059	114	14	methodsLength	I
/*      */     //   1074	99	15	definesAbstractMethod	Z
/*      */     //   1077	28	16	i	I
/*      */     //   1116	57	16	needAbstractBit	Z
/*      */     //   1119	43	17	i	I
/*      */     //   1129	23	18	fieldDecl	Lorg/eclipse/jdt/internal/compiler/ast/FieldDeclaration;
/*      */     //   1179	68	10	typeDeclaration	Lorg/eclipse/jdt/internal/compiler/ast/TypeDeclaration;
/*      */     //   1186	61	11	fields	[Lorg/eclipse/jdt/internal/compiler/ast/FieldDeclaration;
/*      */     //   1194	48	12	i	I
/*      */     //   1199	43	13	fieldsLength	I
/*      */     //   1209	23	14	fieldDecl	Lorg/eclipse/jdt/internal/compiler/ast/FieldDeclaration;
/*      */     //   1280	90	10	UNEXPECTED_MODIFIERS	I
/*      */     //   1434	21	10	UNEXPECTED_MODIFIERS	I
/*      */     //   1558	72	10	accessorBits	I
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void checkAndSetModifiersForField(FieldBinding fieldBinding, FieldDeclaration fieldDecl) {
/*  936 */     int modifiers = fieldBinding.modifiers;
/*  937 */     ReferenceBinding declaringClass = fieldBinding.declaringClass;
/*  938 */     if ((modifiers & 0x400000) != 0) {
/*  939 */       problemReporter().duplicateModifierForField(declaringClass, fieldDecl);
/*      */     }
/*  941 */     if (declaringClass.isInterface()) {
/*      */ 
/*      */       
/*  944 */       modifiers |= 0x19;
/*      */ 
/*      */       
/*  947 */       if ((modifiers & 0xFFFF) != 25)
/*  948 */         if ((declaringClass.modifiers & 0x2000) != 0) {
/*  949 */           problemReporter().illegalModifierForAnnotationField(fieldDecl);
/*      */         } else {
/*  951 */           problemReporter().illegalModifierForInterfaceField(fieldDecl);
/*      */         }  
/*  953 */       fieldBinding.modifiers = modifiers; return;
/*      */     } 
/*  955 */     if (fieldDecl.getKind() == 3) {
/*      */       
/*  957 */       if ((modifiers & 0xFFFF) != 0) {
/*  958 */         problemReporter().illegalModifierForEnumConstant(declaringClass, fieldDecl);
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  966 */       fieldBinding.modifiers |= 0x8004019;
/*      */       
/*      */       return;
/*      */     } 
/*      */     
/*  971 */     int realModifiers = modifiers & 0xFFFF;
/*      */     
/*  973 */     if ((realModifiers & 0xFFFFFF20) != 0) {
/*  974 */       problemReporter().illegalModifierForField(declaringClass, fieldDecl);
/*  975 */       modifiers &= 0xFFFF00DF;
/*      */     } 
/*      */     
/*  978 */     int accessorBits = realModifiers & 0x7;
/*  979 */     if ((accessorBits & accessorBits - 1) > 1) {
/*  980 */       problemReporter().illegalVisibilityModifierCombinationForField(declaringClass, fieldDecl);
/*      */ 
/*      */       
/*  983 */       if ((accessorBits & 0x1) != 0) {
/*  984 */         if ((accessorBits & 0x4) != 0)
/*  985 */           modifiers &= 0xFFFFFFFB; 
/*  986 */         if ((accessorBits & 0x2) != 0)
/*  987 */           modifiers &= 0xFFFFFFFD; 
/*  988 */       } else if ((accessorBits & 0x4) != 0 && (accessorBits & 0x2) != 0) {
/*  989 */         modifiers &= 0xFFFFFFFD;
/*      */       } 
/*      */     } 
/*      */     
/*  993 */     if ((realModifiers & 0x50) == 80) {
/*  994 */       problemReporter().illegalModifierCombinationFinalVolatileForField(declaringClass, fieldDecl);
/*      */     }
/*  996 */     if (fieldDecl.initialization == null && (modifiers & 0x10) != 0)
/*  997 */       modifiers |= 0x4000000; 
/*  998 */     fieldBinding.modifiers = modifiers;
/*      */   }
/*      */ 
/*      */   
/*      */   public void checkParameterizedSuperTypeCollisions() {
/* 1003 */     SourceTypeBinding sourceType = this.referenceContext.binding;
/* 1004 */     ReferenceBinding[] interfaces = sourceType.superInterfaces;
/* 1005 */     Map<Object, Object> invocations = new HashMap<>(2);
/* 1006 */     ReferenceBinding itsSuperclass = sourceType.isInterface() ? null : sourceType.superclass;
/* 1007 */     for (int i = 0, length = interfaces.length; i < length; i++) {
/* 1008 */       ReferenceBinding one = interfaces[i];
/* 1009 */       if (one != null && (
/* 1010 */         itsSuperclass == null || !hasErasedCandidatesCollisions(itsSuperclass, one, invocations, sourceType, (ASTNode)this.referenceContext)))
/*      */       {
/* 1012 */         for (int k = 0; k < i; k++) {
/* 1013 */           ReferenceBinding two = interfaces[k];
/* 1014 */           if (two != null && 
/* 1015 */             hasErasedCandidatesCollisions(one, two, invocations, sourceType, (ASTNode)this.referenceContext))
/*      */             break; 
/*      */         } 
/*      */       }
/*      */     } 
/* 1020 */     TypeParameter[] typeParameters = this.referenceContext.typeParameters;
/* 1021 */     for (int j = 0, paramLength = (typeParameters == null) ? 0 : typeParameters.length; j < paramLength; j++) {
/* 1022 */       TypeParameter typeParameter = typeParameters[j];
/* 1023 */       TypeVariableBinding typeVariable = typeParameter.binding;
/* 1024 */       if (typeVariable != null && typeVariable.isValidBinding()) {
/*      */         
/* 1026 */         TypeReference[] boundRefs = typeParameter.bounds;
/* 1027 */         if (boundRefs != null) {
/* 1028 */           boolean checkSuperclass = TypeBinding.equalsEquals(typeVariable.firstBound, typeVariable.superclass); int k, boundLength;
/* 1029 */           label67: for (k = 0, boundLength = boundRefs.length; k < boundLength; k++) {
/* 1030 */             TypeReference typeRef = boundRefs[k];
/* 1031 */             TypeBinding superType = typeRef.resolvedType;
/* 1032 */             if (superType != null && superType.isValidBinding()) {
/*      */ 
/*      */               
/* 1035 */               if (checkSuperclass && 
/* 1036 */                 hasErasedCandidatesCollisions(superType, typeVariable.superclass, invocations, typeVariable, (ASTNode)typeRef)) {
/*      */                 break;
/*      */               }
/* 1039 */               for (int index = typeVariable.superInterfaces.length; --index >= 0;)
/* 1040 */               { if (hasErasedCandidatesCollisions(superType, typeVariable.superInterfaces[index], invocations, typeVariable, (ASTNode)typeRef))
/*      */                   break label67;  } 
/*      */             } 
/*      */           } 
/*      */         } 
/*      */       } 
/* 1046 */     }  ReferenceBinding[] memberTypes = this.referenceContext.binding.memberTypes;
/* 1047 */     if (memberTypes != null && memberTypes != Binding.NO_MEMBER_TYPES) {
/* 1048 */       for (int k = 0, size = memberTypes.length; k < size; k++) {
/* 1049 */         ((SourceTypeBinding)memberTypes[k]).scope.checkParameterizedSuperTypeCollisions();
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   private void checkForInheritedMemberTypes(SourceTypeBinding sourceType) {
/* 1056 */     ReferenceBinding currentType = sourceType;
/* 1057 */     ReferenceBinding[] interfacesToVisit = null;
/* 1058 */     int nextPosition = 0;
/*      */     do {
/* 1060 */       if (currentType.hasMemberTypes()) {
/*      */         return;
/*      */       }
/* 1063 */       ReferenceBinding[] itsInterfaces = currentType.superInterfaces();
/*      */       
/* 1065 */       if (itsInterfaces == null || itsInterfaces == Binding.NO_SUPERINTERFACES)
/* 1066 */         continue;  if (interfacesToVisit == null) {
/* 1067 */         interfacesToVisit = itsInterfaces;
/* 1068 */         nextPosition = interfacesToVisit.length;
/*      */       } else {
/* 1070 */         int itsLength = itsInterfaces.length;
/* 1071 */         if (nextPosition + itsLength >= interfacesToVisit.length)
/* 1072 */           System.arraycopy(interfacesToVisit, 0, interfacesToVisit = new ReferenceBinding[nextPosition + itsLength + 5], 0, nextPosition); 
/* 1073 */         for (int a = 0; a < itsLength; a++) {
/* 1074 */           ReferenceBinding next = itsInterfaces[a];
/* 1075 */           int b = 0; while (true) { if (b >= nextPosition)
/*      */             
/* 1077 */             { interfacesToVisit[nextPosition++] = next; break; }  if (TypeBinding.equalsEquals(next, interfacesToVisit[b]))
/*      */               break;  b++; } 
/*      */         } 
/*      */       } 
/* 1081 */     } while ((currentType = currentType.superclass()) != null && (currentType.tagBits & 0x10000L) == 0L);
/*      */     
/* 1083 */     if (interfacesToVisit != null) {
/*      */       
/* 1085 */       boolean needToTag = false; int i;
/* 1086 */       for (i = 0; i < nextPosition; i++) {
/* 1087 */         ReferenceBinding anInterface = interfacesToVisit[i];
/* 1088 */         if ((anInterface.tagBits & 0x10000L) == 0L) {
/* 1089 */           if (anInterface.hasMemberTypes()) {
/*      */             return;
/*      */           }
/* 1092 */           needToTag = true;
/* 1093 */           ReferenceBinding[] itsInterfaces = anInterface.superInterfaces();
/* 1094 */           if (itsInterfaces != null && itsInterfaces != Binding.NO_SUPERINTERFACES) {
/* 1095 */             int itsLength = itsInterfaces.length;
/* 1096 */             if (nextPosition + itsLength >= interfacesToVisit.length)
/* 1097 */               System.arraycopy(interfacesToVisit, 0, interfacesToVisit = new ReferenceBinding[nextPosition + itsLength + 5], 0, nextPosition); 
/* 1098 */             for (int a = 0; a < itsLength; a++) {
/* 1099 */               ReferenceBinding next = itsInterfaces[a];
/* 1100 */               int b = 0; while (true) { if (b >= nextPosition)
/*      */                 
/* 1102 */                 { interfacesToVisit[nextPosition++] = next; break; }  if (TypeBinding.equalsEquals(next, interfacesToVisit[b]))
/*      */                   break;  b++; }
/*      */             
/*      */             } 
/*      */           } 
/*      */         } 
/* 1108 */       }  if (needToTag) {
/* 1109 */         for (i = 0; i < nextPosition; i++) {
/* 1110 */           (interfacesToVisit[i]).tagBits |= 0x10000L;
/*      */         }
/*      */       }
/*      */     } 
/*      */     
/* 1115 */     currentType = sourceType;
/*      */     do {
/* 1117 */       currentType.tagBits |= 0x10000L;
/* 1118 */     } while ((currentType = currentType.superclass()) != null && (currentType.tagBits & 0x10000L) == 0L);
/*      */   }
/*      */ 
/*      */   
/*      */   public void checkParameterizedTypeBounds() {
/* 1123 */     for (int i = 0, l = (this.deferredBoundChecks == null) ? 0 : this.deferredBoundChecks.size(); i < l; i++) {
/* 1124 */       Object toCheck = this.deferredBoundChecks.get(i);
/* 1125 */       if (toCheck instanceof TypeReference) {
/* 1126 */         ((TypeReference)toCheck).checkBounds(this);
/* 1127 */       } else if (toCheck instanceof Runnable) {
/* 1128 */         ((Runnable)toCheck).run();
/*      */       } 
/* 1130 */     }  this.deferredBoundChecks = null;
/*      */     
/* 1132 */     ReferenceBinding[] memberTypes = this.referenceContext.binding.memberTypes;
/* 1133 */     if (memberTypes != null && memberTypes != Binding.NO_MEMBER_TYPES)
/* 1134 */       for (int j = 0, size = memberTypes.length; j < size; j++)
/* 1135 */         ((SourceTypeBinding)memberTypes[j]).scope.checkParameterizedTypeBounds();  
/*      */   }
/*      */   
/*      */   private void connectMemberTypes() {
/* 1139 */     SourceTypeBinding sourceType = this.referenceContext.binding;
/* 1140 */     ReferenceBinding[] memberTypes = sourceType.memberTypes;
/* 1141 */     if (memberTypes != null && memberTypes != Binding.NO_MEMBER_TYPES) {
/* 1142 */       for (int i = 0, size = memberTypes.length; i < size; i++) {
/* 1143 */         ((SourceTypeBinding)memberTypes[i]).scope.connectTypeHierarchy();
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean connectSuperclass() {
/* 1158 */     SourceTypeBinding sourceType = this.referenceContext.binding;
/* 1159 */     if (sourceType.id == 1) {
/* 1160 */       sourceType.setSuperClass((ReferenceBinding)null);
/* 1161 */       sourceType.setSuperInterfaces(Binding.NO_SUPERINTERFACES);
/* 1162 */       sourceType.setPermittedTypes(Binding.NO_PERMITTEDTYPES);
/* 1163 */       if (!sourceType.isClass())
/* 1164 */         problemReporter().objectMustBeClass(sourceType); 
/* 1165 */       if (this.referenceContext.superclass != null || (this.referenceContext.superInterfaces != null && this.referenceContext.superInterfaces.length > 0))
/* 1166 */         problemReporter().objectCannotHaveSuperTypes(sourceType); 
/* 1167 */       return true;
/*      */     } 
/* 1169 */     if (this.referenceContext.superclass == null) {
/* 1170 */       if (sourceType.isEnum() && (compilerOptions()).sourceLevel >= 3211264L)
/* 1171 */         return connectEnumSuperclass(); 
/* 1172 */       sourceType.setSuperClass(getJavaLangObject());
/* 1173 */       return !detectHierarchyCycle(sourceType, sourceType.superclass, (TypeReference)null);
/*      */     } 
/* 1175 */     TypeReference superclassRef = this.referenceContext.superclass;
/* 1176 */     ReferenceBinding superclass = findSupertype(superclassRef);
/* 1177 */     if (superclass != null) {
/* 1178 */       if (!superclass.isClass() && (superclass.tagBits & 0x80L) == 0L)
/* 1179 */       { problemReporter().superclassMustBeAClass(sourceType, superclassRef, superclass); }
/* 1180 */       else if (superclass.isFinal())
/* 1181 */       { if (superclass.isRecord()) {
/* 1182 */           problemReporter().classExtendFinalRecord(sourceType, superclassRef, superclass);
/*      */         } else {
/* 1184 */           problemReporter().classExtendFinalClass(sourceType, superclassRef, superclass);
/*      */         }  }
/* 1186 */       else if ((superclass.tagBits & 0x40000000L) != 0L)
/* 1187 */       { problemReporter().superTypeCannotUseWildcard(sourceType, superclassRef, superclass); }
/* 1188 */       else if ((superclass.erasure()).id == 41)
/* 1189 */       { problemReporter().cannotExtendEnum(sourceType, superclassRef, superclass); }
/* 1190 */       else if ((superclass.erasure()).id == 93)
/* 1191 */       { if (!this.referenceContext.isRecord()) {
/* 1192 */           problemReporter().recordCannotExtendRecord(sourceType, superclassRef, superclass);
/*      */         } else {
/* 1194 */           return connectRecordSuperclass();
/*      */         }  }
/* 1196 */       else { if ((superclass.tagBits & 0x20000L) != 0L || 
/* 1197 */           !superclassRef.resolvedType.isValidBinding()) {
/* 1198 */           sourceType.setSuperClass(superclass);
/* 1199 */           sourceType.tagBits |= 0x20000L;
/* 1200 */           return superclassRef.resolvedType.isValidBinding();
/*      */         } 
/*      */         
/* 1203 */         sourceType.setSuperClass(superclass);
/* 1204 */         sourceType.typeBits |= superclass.typeBits & 0x713;
/*      */         
/* 1206 */         if ((sourceType.typeBits & 0x3) != 0)
/* 1207 */           sourceType.typeBits |= sourceType.applyCloseableClassWhitelists(compilerOptions()); 
/* 1208 */         return true; }
/*      */     
/*      */     }
/* 1211 */     sourceType.tagBits |= 0x20000L;
/* 1212 */     sourceType.setSuperClass(sourceType.isRecord() ? getJavaLangRecord() : getJavaLangObject());
/* 1213 */     if ((sourceType.superclass.tagBits & 0x100L) == 0L)
/* 1214 */       detectHierarchyCycle(sourceType, sourceType.superclass, (TypeReference)null); 
/* 1215 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean connectEnumSuperclass() {
/* 1222 */     SourceTypeBinding sourceType = this.referenceContext.binding;
/* 1223 */     ReferenceBinding rootEnumType = getJavaLangEnum();
/* 1224 */     if ((rootEnumType.tagBits & 0x80L) != 0L) {
/* 1225 */       sourceType.tagBits |= 0x20000L;
/* 1226 */       sourceType.setSuperClass(rootEnumType);
/* 1227 */       return false;
/*      */     } 
/* 1229 */     boolean foundCycle = detectHierarchyCycle(sourceType, rootEnumType, (TypeReference)null);
/*      */     
/* 1231 */     TypeVariableBinding[] refTypeVariables = rootEnumType.typeVariables();
/* 1232 */     if (refTypeVariables == Binding.NO_TYPE_VARIABLES) {
/* 1233 */       problemReporter().nonGenericTypeCannotBeParameterized(0, null, rootEnumType, new TypeBinding[] { sourceType });
/* 1234 */       return false;
/* 1235 */     }  if (1 != refTypeVariables.length) {
/* 1236 */       problemReporter().incorrectArityForParameterizedType(null, rootEnumType, new TypeBinding[] { sourceType });
/* 1237 */       return false;
/*      */     } 
/*      */     
/* 1240 */     ParameterizedTypeBinding superType = environment().createParameterizedType(
/* 1241 */         rootEnumType, 
/* 1242 */         new TypeBinding[] {
/* 1243 */           environment().convertToRawType(sourceType, false)
/*      */         
/* 1245 */         }null);
/* 1246 */     sourceType.tagBits |= superType.tagBits & 0x20000L;
/* 1247 */     sourceType.setSuperClass(superType);
/*      */     
/* 1249 */     if (!refTypeVariables[0].boundCheck(superType, sourceType, this, null).isOKbyJLS()) {
/* 1250 */       problemReporter().typeMismatchError(rootEnumType, refTypeVariables[0], sourceType, null);
/*      */     }
/* 1252 */     return !foundCycle;
/*      */   }
/*      */   
/*      */   private void connectImplicitPermittedTypes(SourceTypeBinding sourceType) {
/* 1256 */     List<SourceTypeBinding> types = new ArrayList<>(); byte b; int i; TypeDeclaration[] arrayOfTypeDeclaration;
/* 1257 */     for (i = (arrayOfTypeDeclaration = (referenceCompilationUnit()).types).length, b = 0; b < i; ) { TypeDeclaration typeDecl = arrayOfTypeDeclaration[b];
/* 1258 */       types.addAll(sourceType.collectAllTypeBindings(typeDecl, compilationUnitScope())); b++; }
/*      */     
/* 1260 */     Set<ReferenceBinding> permSubTypes = new LinkedHashSet<>();
/* 1261 */     for (ReferenceBinding type : types) {
/* 1262 */       if (!TypeBinding.equalsEquals(type, sourceType) && type.findSuperTypeOriginatingFrom(sourceType) != null) {
/* 1263 */         permSubTypes.add(type);
/*      */       }
/*      */     } 
/* 1266 */     if (sourceType.isSealed()) sourceType.isLocalType();
/*      */ 
/*      */     
/* 1269 */     if (permSubTypes.size() == 0) {
/* 1270 */       if (!sourceType.isLocalType())
/* 1271 */         problemReporter().sealedSealedTypeMissingPermits(sourceType, (ASTNode)this.referenceContext); 
/*      */       return;
/*      */     } 
/* 1274 */     sourceType.setPermittedTypes(permSubTypes.<ReferenceBinding>toArray(new ReferenceBinding[0]));
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   void connectImplicitPermittedTypes() {
/* 1280 */     TypeDeclaration typeDecl = this.referenceContext;
/* 1281 */     SourceTypeBinding sourceType = typeDecl.binding;
/* 1282 */     if (sourceType.id == 1 || sourceType.isEnum() || sourceType.isRecord())
/*      */       return; 
/* 1284 */     if (sourceType.isSealed() && (typeDecl.permittedTypes == null || 
/* 1285 */       typeDecl.permittedTypes.length == 0)) {
/* 1286 */       connectImplicitPermittedTypes(sourceType);
/*      */     }
/* 1288 */     ReferenceBinding[] memberTypes = sourceType.memberTypes;
/* 1289 */     if (memberTypes != null && memberTypes != Binding.NO_MEMBER_TYPES) {
/* 1290 */       for (int i = 0, size = memberTypes.length; i < size; i++) {
/* 1291 */         ((SourceTypeBinding)memberTypes[i]).scope.connectImplicitPermittedTypes();
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void connectPermittedTypes() {
/* 1314 */     SourceTypeBinding sourceType = this.referenceContext.binding;
/* 1315 */     sourceType.setPermittedTypes(Binding.NO_PERMITTEDTYPES);
/* 1316 */     if (this.referenceContext.permittedTypes == null) {
/*      */       return;
/*      */     }
/* 1319 */     if (sourceType.id == 1 || sourceType.isEnum()) {
/*      */       return;
/*      */     }
/* 1322 */     int length = this.referenceContext.permittedTypes.length;
/* 1323 */     ReferenceBinding[] permittedTypeBindings = new ReferenceBinding[length];
/* 1324 */     int count = 0;
/* 1325 */     for (int i = 0; i < length; i++) {
/* 1326 */       TypeReference permittedTypeRef = this.referenceContext.permittedTypes[i];
/* 1327 */       ReferenceBinding permittedType = findPermittedtype(permittedTypeRef);
/* 1328 */       if (permittedType != null) {
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1333 */         int j = 0; while (true) { if (j >= i)
/*      */           
/*      */           { 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/* 1340 */             permittedTypeBindings[count++] = permittedType; break; }  if (TypeBinding.equalsEquals(permittedTypeBindings[j], permittedType)) { problemReporter().sealedDuplicateTypeInPermits(sourceType, permittedTypeRef, permittedType); break; }  j++; }
/*      */       
/*      */       } 
/* 1343 */     }  if (count > 0) {
/* 1344 */       if (count != length)
/* 1345 */         System.arraycopy(permittedTypeBindings, 0, permittedTypeBindings = new ReferenceBinding[count], 0, count); 
/* 1346 */       sourceType.setPermittedTypes(permittedTypeBindings);
/*      */     } else {
/* 1348 */       sourceType.setPermittedTypes(Binding.NO_PERMITTEDTYPES);
/*      */     } 
/*      */   }
/*      */   
/*      */   private boolean connectRecordSuperclass() {
/* 1353 */     SourceTypeBinding sourceType = this.referenceContext.binding;
/* 1354 */     ReferenceBinding rootRecordType = getJavaLangRecord();
/* 1355 */     sourceType.setSuperClass(rootRecordType);
/* 1356 */     if ((rootRecordType.tagBits & 0x80L) != 0L) {
/* 1357 */       sourceType.tagBits |= 0x20000L;
/* 1358 */       return false;
/*      */     } 
/* 1360 */     return !detectHierarchyCycle(sourceType, rootRecordType, (TypeReference)null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean connectSuperInterfaces() {
/* 1373 */     SourceTypeBinding sourceType = this.referenceContext.binding;
/* 1374 */     sourceType.setSuperInterfaces(Binding.NO_SUPERINTERFACES);
/* 1375 */     if (this.referenceContext.superInterfaces == null) {
/* 1376 */       if (sourceType.isAnnotationType() && (compilerOptions()).sourceLevel >= 3211264L) {
/* 1377 */         ReferenceBinding annotationType = getJavaLangAnnotationAnnotation();
/* 1378 */         boolean foundCycle = detectHierarchyCycle(sourceType, annotationType, (TypeReference)null);
/* 1379 */         sourceType.setSuperInterfaces(new ReferenceBinding[] { annotationType });
/* 1380 */         return !foundCycle;
/*      */       } 
/* 1382 */       return true;
/*      */     } 
/* 1384 */     if (sourceType.id == 1) {
/* 1385 */       return true;
/*      */     }
/* 1387 */     boolean noProblems = true;
/* 1388 */     int length = this.referenceContext.superInterfaces.length;
/* 1389 */     ReferenceBinding[] interfaceBindings = new ReferenceBinding[length];
/* 1390 */     int count = 0;
/* 1391 */     for (int i = 0; i < length; i++) {
/* 1392 */       TypeReference superInterfaceRef = this.referenceContext.superInterfaces[i];
/* 1393 */       ReferenceBinding superInterface = findSupertype(superInterfaceRef);
/* 1394 */       if (superInterface == null) {
/* 1395 */         sourceType.tagBits |= 0x20000L;
/* 1396 */         noProblems = false;
/*      */       
/*      */       }
/*      */       else {
/*      */ 
/*      */         
/* 1402 */         for (int j = 0; j < i; j++) {
/* 1403 */           if (TypeBinding.equalsEquals(interfaceBindings[j], superInterface)) {
/* 1404 */             problemReporter().duplicateSuperinterface(sourceType, superInterfaceRef, superInterface);
/* 1405 */             sourceType.tagBits |= 0x20000L;
/* 1406 */             noProblems = false;
/*      */             // Byte code: goto -> 433
/*      */           } 
/*      */         } 
/* 1410 */         if (!superInterface.isInterface() && (superInterface.tagBits & 0x80L) == 0L) {
/* 1411 */           problemReporter().superinterfaceMustBeAnInterface(sourceType, superInterfaceRef, superInterface);
/* 1412 */           sourceType.tagBits |= 0x20000L;
/* 1413 */           noProblems = false;
/*      */         } else {
/* 1415 */           if (superInterface.isAnnotationType()) {
/* 1416 */             problemReporter().annotationTypeUsedAsSuperinterface(sourceType, superInterfaceRef, superInterface);
/*      */           }
/* 1418 */           if ((superInterface.tagBits & 0x40000000L) != 0L)
/* 1419 */           { problemReporter().superTypeCannotUseWildcard(sourceType, superInterfaceRef, superInterface);
/* 1420 */             sourceType.tagBits |= 0x20000L;
/* 1421 */             noProblems = false; }
/*      */           else
/*      */           
/* 1424 */           { if ((superInterface.tagBits & 0x20000L) != 0L || 
/* 1425 */               !superInterfaceRef.resolvedType.isValidBinding()) {
/* 1426 */               sourceType.tagBits |= 0x20000L;
/* 1427 */               noProblems &= superInterfaceRef.resolvedType.isValidBinding();
/*      */             } 
/*      */             
/* 1430 */             sourceType.typeBits |= superInterface.typeBits & 0x713;
/*      */             
/* 1432 */             if ((sourceType.typeBits & 0x3) != 0)
/* 1433 */               sourceType.typeBits |= sourceType.applyCloseableInterfaceWhitelists(); 
/* 1434 */             interfaceBindings[count++] = superInterface; } 
/*      */         } 
/*      */       } 
/* 1437 */     }  if (count > 0) {
/* 1438 */       if (count != length)
/* 1439 */         System.arraycopy(interfaceBindings, 0, interfaceBindings = new ReferenceBinding[count], 0, count); 
/* 1440 */       sourceType.setSuperInterfaces(interfaceBindings);
/*      */     } 
/* 1442 */     return noProblems;
/*      */   }
/*      */   
/*      */   void connectTypeHierarchy() {
/* 1446 */     SourceTypeBinding sourceType = this.referenceContext.binding;
/* 1447 */     CompilationUnitScope compilationUnitScopeLocal = compilationUnitScope();
/* 1448 */     boolean wasAlreadyConnecting = compilationUnitScopeLocal.connectingHierarchy;
/* 1449 */     compilationUnitScopeLocal.connectingHierarchy = true;
/*      */     try {
/* 1451 */       if ((sourceType.tagBits & 0x100L) == 0L) {
/* 1452 */         sourceType.tagBits |= 0x100L;
/* 1453 */         (environment()).typesBeingConnected.add(sourceType);
/* 1454 */         boolean noProblems = connectSuperclass();
/* 1455 */         noProblems &= connectSuperInterfaces();
/* 1456 */         (environment()).typesBeingConnected.remove(sourceType);
/* 1457 */         sourceType.tagBits |= 0x200L;
/* 1458 */         connectPermittedTypes();
/* 1459 */         noProblems &= connectTypeVariables(this.referenceContext.typeParameters, false);
/* 1460 */         sourceType.tagBits |= 0x40000L;
/* 1461 */         if (noProblems && sourceType.isHierarchyInconsistent())
/* 1462 */           problemReporter().hierarchyHasProblems(sourceType); 
/*      */       } 
/* 1464 */       connectMemberTypes();
/*      */     } finally {
/* 1466 */       compilationUnitScopeLocal.connectingHierarchy = wasAlreadyConnecting;
/*      */     } 
/* 1468 */     LookupEnvironment env = environment();
/*      */     try {
/* 1470 */       env.missingClassFileLocation = this.referenceContext;
/* 1471 */       checkForInheritedMemberTypes(sourceType);
/* 1472 */     } catch (AbortCompilation e) {
/* 1473 */       e.updateContext((ASTNode)this.referenceContext, (referenceCompilationUnit()).compilationResult);
/* 1474 */       throw e;
/*      */     } finally {
/* 1476 */       env.missingClassFileLocation = null;
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean deferCheck(Runnable check) {
/* 1482 */     if ((compilationUnitScope()).connectingHierarchy) {
/* 1483 */       if (this.deferredBoundChecks == null)
/* 1484 */         this.deferredBoundChecks = new ArrayList(); 
/* 1485 */       this.deferredBoundChecks.add(check);
/* 1486 */       return true;
/*      */     } 
/* 1488 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private void connectTypeHierarchyWithoutMembers() {
/* 1494 */     if (this.parent instanceof CompilationUnitScope) {
/* 1495 */       if (((CompilationUnitScope)this.parent).imports == null)
/* 1496 */         ((CompilationUnitScope)this.parent).checkAndSetImports(); 
/* 1497 */     } else if (this.parent instanceof ClassScope) {
/*      */       
/* 1499 */       ((ClassScope)this.parent).connectTypeHierarchyWithoutMembers();
/*      */     } 
/*      */ 
/*      */     
/* 1503 */     SourceTypeBinding sourceType = this.referenceContext.binding;
/* 1504 */     if ((sourceType.tagBits & 0x100L) != 0L) {
/*      */       return;
/*      */     }
/* 1507 */     CompilationUnitScope compilationUnitScopeLocal = compilationUnitScope();
/* 1508 */     boolean wasAlreadyConnecting = compilationUnitScopeLocal.connectingHierarchy;
/* 1509 */     compilationUnitScopeLocal.connectingHierarchy = true;
/*      */     try {
/* 1511 */       sourceType.tagBits |= 0x100L;
/* 1512 */       (environment()).typesBeingConnected.add(sourceType);
/* 1513 */       boolean noProblems = connectSuperclass();
/* 1514 */       noProblems &= connectSuperInterfaces();
/* 1515 */       (environment()).typesBeingConnected.remove(sourceType);
/* 1516 */       sourceType.tagBits |= 0x200L;
/* 1517 */       connectPermittedTypes();
/* 1518 */       noProblems &= connectTypeVariables(this.referenceContext.typeParameters, false);
/* 1519 */       sourceType.tagBits |= 0x40000L;
/* 1520 */       if (noProblems && sourceType.isHierarchyInconsistent())
/* 1521 */         problemReporter().hierarchyHasProblems(sourceType); 
/*      */     } finally {
/* 1523 */       compilationUnitScopeLocal.connectingHierarchy = wasAlreadyConnecting;
/*      */     } 
/*      */   }
/*      */   
/*      */   public boolean detectHierarchyCycle(TypeBinding superType, TypeReference reference) {
/* 1528 */     if (!(superType instanceof ReferenceBinding)) return false;
/*      */     
/* 1530 */     if (reference == this.superTypeReference) {
/* 1531 */       if (superType.isTypeVariable()) {
/* 1532 */         return false;
/*      */       }
/*      */       
/* 1535 */       if (superType.isParameterizedType())
/* 1536 */         superType = ((ParameterizedTypeBinding)superType).genericType(); 
/* 1537 */       compilationUnitScope().recordSuperTypeReference(superType);
/* 1538 */       return detectHierarchyCycle(this.referenceContext.binding, (ReferenceBinding)superType, reference);
/*      */     } 
/*      */ 
/*      */     
/* 1542 */     if ((superType.tagBits & 0x100L) == 0L && superType instanceof SourceTypeBinding)
/*      */     {
/* 1544 */       ((SourceTypeBinding)superType).scope.connectTypeHierarchyWithoutMembers();
/*      */     }
/* 1546 */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   private boolean detectHierarchyCycle(SourceTypeBinding sourceType, ReferenceBinding superType, TypeReference reference) {
/* 1551 */     if (superType.isRawType()) {
/* 1552 */       superType = ((RawTypeBinding)superType).genericType();
/*      */     }
/*      */     
/* 1555 */     if (TypeBinding.equalsEquals(sourceType, superType)) {
/* 1556 */       problemReporter().hierarchyCircularity(sourceType, superType, reference);
/* 1557 */       sourceType.tagBits |= 0x20000L;
/* 1558 */       return true;
/*      */     } 
/*      */     
/* 1561 */     if (superType.isMemberType()) {
/* 1562 */       ReferenceBinding current = superType.enclosingType();
/*      */       do {
/* 1564 */         if (current.isHierarchyBeingActivelyConnected()) {
/* 1565 */           problemReporter().hierarchyCircularity(sourceType, current, reference);
/* 1566 */           sourceType.tagBits |= 0x20000L;
/* 1567 */           current.tagBits |= 0x20000L;
/* 1568 */           return true;
/*      */         } 
/* 1570 */       } while ((current = current.enclosingType()) != null);
/*      */     } 
/*      */     
/* 1573 */     if (superType.isBinaryBinding()) {
/*      */ 
/*      */ 
/*      */       
/* 1577 */       if (superType.problemId() != 1 && (superType.tagBits & 0x20000L) != 0L) {
/* 1578 */         sourceType.tagBits |= 0x20000L;
/* 1579 */         problemReporter().hierarchyHasProblems(sourceType);
/* 1580 */         return true;
/*      */       } 
/* 1582 */       boolean hasCycle = false;
/* 1583 */       ReferenceBinding parentType = superType.superclass();
/* 1584 */       if (parentType != null) {
/* 1585 */         if (TypeBinding.equalsEquals(sourceType, parentType)) {
/* 1586 */           problemReporter().hierarchyCircularity(sourceType, superType, reference);
/* 1587 */           sourceType.tagBits |= 0x20000L;
/* 1588 */           superType.tagBits |= 0x20000L;
/* 1589 */           return true;
/*      */         } 
/* 1591 */         if (parentType.isParameterizedType())
/* 1592 */           parentType = ((ParameterizedTypeBinding)parentType).genericType(); 
/* 1593 */         hasCycle |= detectHierarchyCycle(sourceType, parentType, reference);
/* 1594 */         if ((parentType.tagBits & 0x20000L) != 0L) {
/* 1595 */           sourceType.tagBits |= 0x20000L;
/* 1596 */           parentType.tagBits |= 0x20000L;
/*      */         } 
/*      */       } 
/*      */       
/* 1600 */       ReferenceBinding[] itsInterfaces = superType.superInterfaces();
/* 1601 */       if (itsInterfaces != null && itsInterfaces != Binding.NO_SUPERINTERFACES) {
/* 1602 */         for (int i = 0, length = itsInterfaces.length; i < length; i++) {
/* 1603 */           ReferenceBinding anInterface = itsInterfaces[i];
/* 1604 */           if (TypeBinding.equalsEquals(sourceType, anInterface)) {
/* 1605 */             problemReporter().hierarchyCircularity(sourceType, superType, reference);
/* 1606 */             sourceType.tagBits |= 0x20000L;
/* 1607 */             superType.tagBits |= 0x20000L;
/* 1608 */             return true;
/*      */           } 
/* 1610 */           if (anInterface.isParameterizedType())
/* 1611 */             anInterface = ((ParameterizedTypeBinding)anInterface).genericType(); 
/* 1612 */           hasCycle |= detectHierarchyCycle(sourceType, anInterface, reference);
/* 1613 */           if ((anInterface.tagBits & 0x20000L) != 0L) {
/* 1614 */             sourceType.tagBits |= 0x20000L;
/* 1615 */             superType.tagBits |= 0x20000L;
/*      */           } 
/*      */         } 
/*      */       }
/* 1619 */       return hasCycle;
/*      */     } 
/*      */     
/* 1622 */     if (superType.isHierarchyBeingActivelyConnected()) {
/* 1623 */       TypeReference ref = ((SourceTypeBinding)superType).scope.superTypeReference;
/*      */ 
/*      */       
/* 1626 */       if (ref != null && ref.resolvedType != null) {
/* 1627 */         ReferenceBinding s = (ReferenceBinding)ref.resolvedType;
/*      */         do {
/* 1629 */           if (s.isHierarchyBeingActivelyConnected()) {
/* 1630 */             problemReporter().hierarchyCircularity(sourceType, superType, reference);
/* 1631 */             sourceType.tagBits |= 0x20000L;
/* 1632 */             superType.tagBits |= 0x20000L;
/* 1633 */             return true;
/*      */           } 
/* 1635 */         } while ((s = s.enclosingType()) != null);
/*      */       } 
/* 1637 */       if (ref != null && ref.resolvedType == null) {
/*      */ 
/*      */         
/* 1640 */         char[] referredName = ref.getLastToken();
/* 1641 */         for (Iterator<SourceTypeBinding> iter = (environment()).typesBeingConnected.iterator(); iter.hasNext(); ) {
/* 1642 */           SourceTypeBinding type = iter.next();
/* 1643 */           if (CharOperation.equals(referredName, type.sourceName())) {
/* 1644 */             problemReporter().hierarchyCircularity(sourceType, superType, reference);
/* 1645 */             sourceType.tagBits |= 0x20000L;
/* 1646 */             superType.tagBits |= 0x20000L;
/* 1647 */             return true;
/*      */           } 
/*      */         } 
/*      */       } 
/*      */     } 
/* 1652 */     if ((superType.tagBits & 0x100L) == 0L)
/*      */     {
/* 1654 */       if (superType.isValidBinding() && !superType.isUnresolvedType())
/* 1655 */         ((SourceTypeBinding)superType).scope.connectTypeHierarchyWithoutMembers(); 
/*      */     }
/* 1657 */     if ((superType.tagBits & 0x20000L) != 0L)
/* 1658 */       sourceType.tagBits |= 0x20000L; 
/* 1659 */     return false;
/*      */   }
/*      */   
/*      */   private ReferenceBinding findSupertype(TypeReference typeReference) {
/* 1663 */     CompilationUnitScope unitScope = compilationUnitScope();
/* 1664 */     LookupEnvironment env = unitScope.environment;
/*      */     try {
/* 1666 */       env.missingClassFileLocation = typeReference;
/* 1667 */       typeReference.aboutToResolve(this);
/* 1668 */       unitScope.recordQualifiedReference(typeReference.getTypeName());
/* 1669 */       this.superTypeReference = typeReference;
/* 1670 */       ReferenceBinding superType = (ReferenceBinding)typeReference.resolveSuperType(this);
/* 1671 */       return superType;
/* 1672 */     } catch (AbortCompilation e) {
/* 1673 */       SourceTypeBinding sourceType = this.referenceContext.binding;
/* 1674 */       if (sourceType.superInterfaces == null) sourceType.setSuperInterfaces(Binding.NO_SUPERINTERFACES); 
/* 1675 */       if (sourceType.permittedTypes == null) sourceType.setPermittedTypes(Binding.NO_PERMITTEDTYPES); 
/* 1676 */       e.updateContext((ASTNode)typeReference, (referenceCompilationUnit()).compilationResult);
/* 1677 */       throw e;
/*      */     } finally {
/* 1679 */       env.missingClassFileLocation = null;
/* 1680 */       this.superTypeReference = null;
/*      */     } 
/*      */   }
/*      */   
/*      */   private ReferenceBinding findPermittedtype(TypeReference typeReference) {
/* 1685 */     CompilationUnitScope unitScope = compilationUnitScope();
/* 1686 */     LookupEnvironment env = unitScope.environment;
/*      */     try {
/* 1688 */       env.missingClassFileLocation = typeReference;
/* 1689 */       typeReference.aboutToResolve(this);
/* 1690 */       unitScope.recordQualifiedReference(typeReference.getTypeName());
/* 1691 */       ReferenceBinding permittedType = (ReferenceBinding)typeReference.resolveType(this);
/* 1692 */       return permittedType;
/* 1693 */     } catch (AbortCompilation e) {
/* 1694 */       SourceTypeBinding sourceType = this.referenceContext.binding;
/* 1695 */       if (sourceType.permittedTypes == null) sourceType.setPermittedTypes(Binding.NO_PERMITTEDTYPES); 
/* 1696 */       e.updateContext((ASTNode)typeReference, (referenceCompilationUnit()).compilationResult);
/* 1697 */       throw e;
/*      */     } finally {
/* 1699 */       env.missingClassFileLocation = null;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ProblemReporter problemReporter() {
/*      */     MethodScope outerMethodScope;
/* 1711 */     if ((outerMethodScope = outerMostMethodScope()) == null) {
/* 1712 */       ProblemReporter problemReporter = (referenceCompilationUnit()).problemReporter;
/* 1713 */       problemReporter.referenceContext = (ReferenceContext)this.referenceContext;
/* 1714 */       return problemReporter;
/*      */     } 
/* 1716 */     return outerMethodScope.problemReporter();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public TypeDeclaration referenceType() {
/* 1723 */     return this.referenceContext;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean hasDefaultNullnessFor(int location, int sourceStart) {
/* 1728 */     int nonNullByDefaultValue = localNonNullByDefaultValue(sourceStart);
/* 1729 */     if (nonNullByDefaultValue != 0) {
/* 1730 */       return ((nonNullByDefaultValue & location) != 0);
/*      */     }
/* 1732 */     SourceTypeBinding binding = this.referenceContext.binding;
/* 1733 */     if (binding != null) {
/* 1734 */       int nullDefault = binding.getNullDefault();
/* 1735 */       if (nullDefault != 0) {
/* 1736 */         return ((nullDefault & location) != 0);
/*      */       }
/*      */     } 
/* 1739 */     return this.parent.hasDefaultNullnessFor(location, sourceStart);
/*      */   }
/*      */ 
/*      */   
/*      */   public Binding checkRedundantDefaultNullness(int nullBits, int sourceStart) {
/* 1744 */     Binding target = localCheckRedundantDefaultNullness(nullBits, sourceStart);
/* 1745 */     if (target != null) {
/* 1746 */       return target;
/*      */     }
/* 1748 */     SourceTypeBinding binding = this.referenceContext.binding;
/* 1749 */     if (binding != null) {
/* 1750 */       int nullDefault = binding.getNullDefault();
/* 1751 */       if (nullDefault != 0) {
/* 1752 */         return (nullDefault == nullBits) ? binding : null;
/*      */       }
/*      */     } 
/* 1755 */     return this.parent.checkRedundantDefaultNullness(nullBits, sourceStart);
/*      */   }
/*      */ 
/*      */   
/*      */   public String toString() {
/* 1760 */     if (this.referenceContext != null)
/* 1761 */       return "--- Class Scope ---\n\n" + 
/* 1762 */         this.referenceContext.binding.toString(); 
/* 1763 */     return "--- Class Scope ---\n\n Binding not initialized";
/*      */   }
/*      */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\lookup\ClassScope.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */