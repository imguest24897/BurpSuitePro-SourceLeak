/*     */ package org.eclipse.jdt.internal.compiler.codegen;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class IntegerCache
/*     */ {
/*     */   public int[] keyTable;
/*     */   public int[] valueTable;
/*     */   int elementSize;
/*     */   int threshold;
/*     */   
/*     */   public IntegerCache() {
/*  27 */     this(13);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IntegerCache(int initialCapacity) {
/*  36 */     this.elementSize = 0;
/*  37 */     this.threshold = (int)(initialCapacity * 0.66D);
/*  38 */     this.keyTable = new int[initialCapacity];
/*  39 */     this.valueTable = new int[initialCapacity];
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void clear() {
/*  45 */     for (int i = this.keyTable.length; --i >= 0; ) {
/*  46 */       this.keyTable[i] = 0;
/*  47 */       this.valueTable[i] = 0;
/*     */     } 
/*  49 */     this.elementSize = 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean containsKey(int key) {
/*  57 */     int index = hash(key), length = this.keyTable.length;
/*  58 */     while (this.keyTable[index] != 0 || (this.keyTable[index] == 0 && this.valueTable[index] != 0)) {
/*  59 */       if (this.keyTable[index] == key)
/*  60 */         return true; 
/*  61 */       if (++index == length) {
/*  62 */         index = 0;
/*     */       }
/*     */     } 
/*  65 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hash(int key) {
/*  73 */     return (key & Integer.MAX_VALUE) % this.keyTable.length;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int put(int key, int value) {
/*  84 */     int index = hash(key), length = this.keyTable.length;
/*  85 */     while (this.keyTable[index] != 0 || (this.keyTable[index] == 0 && this.valueTable[index] != 0)) {
/*  86 */       if (this.keyTable[index] == key) {
/*  87 */         this.valueTable[index] = value; return value;
/*  88 */       }  if (++index == length) {
/*  89 */         index = 0;
/*     */       }
/*     */     } 
/*  92 */     this.keyTable[index] = key;
/*  93 */     this.valueTable[index] = value;
/*     */ 
/*     */     
/*  96 */     if (++this.elementSize > this.threshold) {
/*  97 */       rehash();
/*     */     }
/*  99 */     return value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int putIfAbsent(int key, int value) {
/* 110 */     int index = hash(key), length = this.keyTable.length;
/* 111 */     while (this.keyTable[index] != 0 || (this.keyTable[index] == 0 && this.valueTable[index] != 0)) {
/* 112 */       if (this.keyTable[index] == key)
/* 113 */         return this.valueTable[index]; 
/* 114 */       if (++index == length) {
/* 115 */         index = 0;
/*     */       }
/*     */     } 
/* 118 */     this.keyTable[index] = key;
/* 119 */     this.valueTable[index] = value;
/*     */ 
/*     */     
/* 122 */     if (++this.elementSize > this.threshold) {
/* 123 */       rehash();
/*     */     }
/* 125 */     return -value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void rehash() {
/* 133 */     IntegerCache newHashtable = new IntegerCache(this.keyTable.length * 2);
/* 134 */     for (int i = this.keyTable.length; --i >= 0; ) {
/* 135 */       int key = this.keyTable[i];
/* 136 */       int value = this.valueTable[i];
/* 137 */       if (key != 0 || (key == 0 && value != 0)) {
/* 138 */         newHashtable.put(key, value);
/*     */       }
/*     */     } 
/* 141 */     this.keyTable = newHashtable.keyTable;
/* 142 */     this.valueTable = newHashtable.valueTable;
/* 143 */     this.threshold = newHashtable.threshold;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int size() {
/* 151 */     return this.elementSize;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 160 */     int max = size();
/* 161 */     StringBuilder buf = new StringBuilder();
/* 162 */     buf.append("{");
/* 163 */     for (int i = 0; i < max; i++) {
/* 164 */       if (this.keyTable[i] != 0 || (this.keyTable[i] == 0 && this.valueTable[i] != 0)) {
/* 165 */         buf.append(this.keyTable[i]).append("->").append(this.valueTable[i]);
/*     */       }
/* 167 */       if (i < max) {
/* 168 */         buf.append(", ");
/*     */       }
/*     */     } 
/* 171 */     buf.append("}");
/* 172 */     return buf.toString();
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\codegen\IntegerCache.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */