/*    */ package org.eclipse.jdt.internal.compiler.flow;
/*    */ 
/*    */ import org.eclipse.jdt.internal.compiler.ast.ASTNode;
/*    */ import org.eclipse.jdt.internal.compiler.lookup.LocalVariableBinding;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class TryFlowContext
/*    */   extends FlowContext
/*    */ {
/*    */   public FlowContext outerTryContext;
/*    */   
/*    */   public TryFlowContext(FlowContext parent, ASTNode associatedNode) {
/* 31 */     super(parent, associatedNode, true);
/*    */   }
/*    */ 
/*    */   
/*    */   public void markFinallyNullStatus(LocalVariableBinding local, int nullStatus) {
/* 36 */     if (this.outerTryContext != null) {
/* 37 */       this.outerTryContext.markFinallyNullStatus(local, nullStatus);
/*    */     }
/* 39 */     super.markFinallyNullStatus(local, nullStatus);
/*    */   }
/*    */ 
/*    */   
/*    */   public void mergeFinallyNullInfo(FlowInfo flowInfo) {
/* 44 */     if (this.outerTryContext != null) {
/* 45 */       this.outerTryContext.mergeFinallyNullInfo(flowInfo);
/*    */     }
/* 47 */     super.mergeFinallyNullInfo(flowInfo);
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\flow\TryFlowContext.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */