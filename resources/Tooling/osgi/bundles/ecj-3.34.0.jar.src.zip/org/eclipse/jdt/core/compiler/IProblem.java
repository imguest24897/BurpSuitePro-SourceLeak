package org.eclipse.jdt.core.compiler;

public interface IProblem {
  public static final int TypeRelated = 16777216;
  
  public static final int FieldRelated = 33554432;
  
  public static final int MethodRelated = 67108864;
  
  public static final int ConstructorRelated = 134217728;
  
  public static final int ImportRelated = 268435456;
  
  public static final int Internal = 536870912;
  
  public static final int Syntax = 1073741824;
  
  public static final int Javadoc = -2147483648;
  
  public static final int ModuleRelated = 8388608;
  
  public static final int Compliance = 4194304;
  
  public static final int PreviewRelated = 2097152;
  
  public static final int IgnoreCategoriesMask = 2097151;
  
  public static final int Unclassified = 0;
  
  public static final int ObjectHasNoSuperclass = 16777217;
  
  public static final int UndefinedType = 16777218;
  
  public static final int NotVisibleType = 16777219;
  
  public static final int AmbiguousType = 16777220;
  
  public static final int UsingDeprecatedType = 16777221;
  
  public static final int InternalTypeNameProvided = 16777222;
  
  public static final int UnusedPrivateType = 553648135;
  
  public static final int IncompatibleTypesInEqualityOperator = 16777231;
  
  public static final int IncompatibleTypesInConditionalOperator = 16777232;
  
  public static final int TypeMismatch = 16777233;
  
  public static final int IndirectAccessToStaticType = 553648146;
  
  public static final int ReturnTypeMismatch = 16777235;
  
  public static final int MissingEnclosingInstanceForConstructorCall = 16777236;
  
  public static final int MissingEnclosingInstance = 16777237;
  
  public static final int IncorrectEnclosingInstanceReference = 16777238;
  
  public static final int IllegalEnclosingInstanceSpecification = 16777239;
  
  public static final int CannotDefineStaticInitializerInLocalType = 536870936;
  
  public static final int OuterLocalMustBeFinal = 536870937;
  
  public static final int CannotDefineInterfaceInLocalType = 536870938;
  
  public static final int IllegalPrimitiveOrArrayTypeForEnclosingInstance = 16777243;
  
  public static final int EnclosingInstanceInConstructorCall = 536870940;
  
  public static final int AnonymousClassCannotExtendFinalClass = 16777245;
  
  public static final int CannotDefineAnnotationInLocalType = 536870942;
  
  public static final int CannotDefineEnumInLocalType = 536870943;
  
  public static final int NonStaticContextForEnumMemberType = 536870944;
  
  public static final int TypeHidingType = 16777249;
  
  public static final int NotAnnotationType = 16777250;
  
  public static final int UndefinedName = 570425394;
  
  public static final int UninitializedLocalVariable = 536870963;
  
  public static final int VariableTypeCannotBeVoid = 536870964;
  
  public static final int VariableTypeCannotBeVoidArray = 536870965;
  
  public static final int CannotAllocateVoidArray = 536870966;
  
  public static final int RedefinedLocal = 536870967;
  
  public static final int RedefinedArgument = 536870968;
  
  public static final int DuplicateFinalLocalInitialization = 536870969;
  
  public static final int NonBlankFinalLocalAssignment = 536870970;
  
  public static final int ParameterAssignment = 536870971;
  
  public static final int FinalOuterLocalAssignment = 536870972;
  
  public static final int LocalVariableIsNeverUsed = 536870973;
  
  public static final int ArgumentIsNeverUsed = 536870974;
  
  public static final int BytecodeExceeds64KLimit = 536870975;
  
  public static final int BytecodeExceeds64KLimitForClinit = 536870976;
  
  public static final int TooManyArgumentSlots = 536870977;
  
  public static final int TooManyLocalVariableSlots = 536870978;
  
  public static final int TooManySyntheticArgumentSlots = 536870979;
  
  public static final int TooManyArrayDimensions = 536870980;
  
  public static final int BytecodeExceeds64KLimitForConstructor = 536870981;
  
  public static final int UndefinedField = 33554502;
  
  public static final int NotVisibleField = 33554503;
  
  public static final int AmbiguousField = 33554504;
  
  public static final int UsingDeprecatedField = 33554505;
  
  public static final int NonStaticFieldFromStaticInvocation = 33554506;
  
  public static final int ReferenceToForwardField = 570425419;
  
  public static final int NonStaticAccessToStaticField = 570425420;
  
  public static final int UnusedPrivateField = 570425421;
  
  public static final int IndirectAccessToStaticField = 570425422;
  
  public static final int UnqualifiedFieldAccess = 570425423;
  
  public static final int FinalFieldAssignment = 33554512;
  
  public static final int UninitializedBlankFinalField = 33554513;
  
  public static final int DuplicateBlankFinalFieldInitialization = 33554514;
  
  public static final int UnresolvedVariable = 33554515;
  
  public static final int NonStaticOrAlienTypeReceiver = 67108948;
  
  public static final int ExceptionParameterIsNeverUsed = 536870997;
  
  public static final int BytecodeExceeds64KLimitForSwitchTable = 536870998;
  
  public static final int LocalVariableHidingLocalVariable = 536871002;
  
  public static final int LocalVariableHidingField = 570425435;
  
  public static final int FieldHidingLocalVariable = 570425436;
  
  public static final int FieldHidingField = 570425437;
  
  public static final int ArgumentHidingLocalVariable = 536871006;
  
  public static final int ArgumentHidingField = 536871007;
  
  public static final int MissingSerialVersion = 536871008;
  
  public static final int LambdaRedeclaresArgument = 536871009;
  
  public static final int LambdaRedeclaresLocal = 536871010;
  
  public static final int LambdaDescriptorMentionsUnmentionable = 99;
  
  public static final int UndefinedMethod = 67108964;
  
  public static final int NotVisibleMethod = 67108965;
  
  public static final int AmbiguousMethod = 67108966;
  
  public static final int UsingDeprecatedMethod = 67108967;
  
  public static final int DirectInvocationOfAbstractMethod = 67108968;
  
  public static final int VoidMethodReturnsValue = 67108969;
  
  public static final int MethodReturnsVoid = 67108970;
  
  public static final int MethodRequiresBody = 603979883;
  
  public static final int ShouldReturnValue = 603979884;
  
  public static final int MethodButWithConstructorName = 67108974;
  
  public static final int MissingReturnType = 16777327;
  
  public static final int BodyForNativeMethod = 603979888;
  
  public static final int BodyForAbstractMethod = 603979889;
  
  public static final int NoMessageSendOnBaseType = 67108978;
  
  public static final int ParameterMismatch = 67108979;
  
  public static final int NoMessageSendOnArrayType = 67108980;
  
  public static final int NonStaticAccessToStaticMethod = 603979893;
  
  public static final int UnusedPrivateMethod = 603979894;
  
  public static final int IndirectAccessToStaticMethod = 603979895;
  
  public static final int MissingTypeInMethod = 67108984;
  
  public static final int MethodCanBeStatic = 603979897;
  
  public static final int MethodCanBePotentiallyStatic = 603979898;
  
  public static final int MethodReferenceSwingsBothWays = 603979899;
  
  public static final int StaticMethodShouldBeAccessedStatically = 603979900;
  
  public static final int InvalidArrayConstructorReference = 603979901;
  
  public static final int ConstructedArrayIncompatible = 603979902;
  
  public static final int DanglingReference = 603979903;
  
  public static final int IncompatibleMethodReference = 603979904;
  
  public static final int MissingTypeInConstructor = 134217857;
  
  public static final int UndefinedConstructor = 134217858;
  
  public static final int NotVisibleConstructor = 134217859;
  
  public static final int AmbiguousConstructor = 134217860;
  
  public static final int UsingDeprecatedConstructor = 134217861;
  
  public static final int UnusedPrivateConstructor = 603979910;
  
  public static final int InstanceFieldDuringConstructorInvocation = 134217863;
  
  public static final int InstanceMethodDuringConstructorInvocation = 134217864;
  
  public static final int RecursiveConstructorInvocation = 134217865;
  
  public static final int ThisSuperDuringConstructorInvocation = 134217866;
  
  public static final int InvalidExplicitConstructorCall = 1207959691;
  
  public static final int UndefinedConstructorInDefaultConstructor = 134217868;
  
  public static final int NotVisibleConstructorInDefaultConstructor = 134217869;
  
  public static final int AmbiguousConstructorInDefaultConstructor = 134217870;
  
  public static final int UndefinedConstructorInImplicitConstructorCall = 134217871;
  
  public static final int NotVisibleConstructorInImplicitConstructorCall = 134217872;
  
  public static final int AmbiguousConstructorInImplicitConstructorCall = 134217873;
  
  public static final int UnhandledExceptionInDefaultConstructor = 16777362;
  
  public static final int UnhandledExceptionInImplicitConstructorCall = 16777363;
  
  public static final int UnusedObjectAllocation = 536871060;
  
  public static final int DeadCode = 536871061;
  
  public static final int ArrayReferenceRequired = 536871062;
  
  public static final int NoImplicitStringConversionForCharArrayExpression = 536871063;
  
  public static final int StringConstantIsExceedingUtf8Limit = 536871064;
  
  public static final int NonConstantExpression = 536871065;
  
  public static final int NumericValueOutOfRange = 536871066;
  
  public static final int IllegalCast = 16777372;
  
  public static final int InvalidClassInstantiation = 16777373;
  
  public static final int CannotDefineDimensionExpressionsWithInit = 536871070;
  
  public static final int MustDefineEitherDimensionExpressionsOrInitializer = 536871071;
  
  public static final int InvalidOperator = 536871072;
  
  public static final int CodeCannotBeReached = 536871073;
  
  public static final int CannotReturnInInitializer = 536871074;
  
  public static final int InitializerMustCompleteNormally = 536871075;
  
  public static final int InvalidVoidExpression = 536871076;
  
  public static final int MaskedCatch = 16777381;
  
  public static final int DuplicateDefaultCase = 536871078;
  
  public static final int UnreachableCatch = 83886247;
  
  public static final int UnhandledException = 16777384;
  
  public static final int IncorrectSwitchType = 16777385;
  
  public static final int DuplicateCase = 33554602;
  
  public static final int DuplicateLabel = 536871083;
  
  public static final int InvalidBreak = 536871084;
  
  public static final int InvalidContinue = 536871085;
  
  public static final int UndefinedLabel = 536871086;
  
  public static final int InvalidTypeToSynchronized = 536871087;
  
  public static final int InvalidNullToSynchronized = 536871088;
  
  public static final int CannotThrowNull = 536871089;
  
  public static final int AssignmentHasNoEffect = 536871090;
  
  public static final int PossibleAccidentalBooleanAssignment = 536871091;
  
  public static final int SuperfluousSemicolon = 536871092;
  
  public static final int UnnecessaryCast = 553648309;
  
  public static final int UnnecessaryArgumentCast = 553648310;
  
  public static final int UnnecessaryInstanceof = 553648311;
  
  public static final int FinallyMustCompleteNormally = 536871096;
  
  public static final int UnusedMethodDeclaredThrownException = 536871097;
  
  public static final int UnusedConstructorDeclaredThrownException = 536871098;
  
  public static final int InvalidCatchBlockSequence = 553648315;
  
  public static final int EmptyControlFlowStatement = 553648316;
  
  public static final int UnnecessaryElse = 536871101;
  
  public static final int NeedToEmulateFieldReadAccess = 33554622;
  
  public static final int NeedToEmulateFieldWriteAccess = 33554623;
  
  public static final int NeedToEmulateMethodAccess = 67109056;
  
  public static final int NeedToEmulateConstructorAccess = 67109057;
  
  public static final int FallthroughCase = 536871106;
  
  public static final int InheritedMethodHidesEnclosingName = 67109059;
  
  public static final int InheritedFieldHidesEnclosingName = 33554628;
  
  public static final int InheritedTypeHidesEnclosingName = 16777413;
  
  public static final int IllegalUsageOfQualifiedTypeReference = 1610612934;
  
  public static final int UnusedLabel = 536871111;
  
  public static final int ThisInStaticContext = 536871112;
  
  public static final int StaticMethodRequested = 603979977;
  
  public static final int IllegalDimension = 536871114;
  
  public static final int InvalidTypeExpression = 536871115;
  
  public static final int ParsingError = 1610612940;
  
  public static final int ParsingErrorNoSuggestion = 1610612941;
  
  public static final int InvalidUnaryExpression = 1610612942;
  
  public static final int InterfaceCannotHaveConstructors = 1610612943;
  
  public static final int ArrayConstantsOnlyInArrayInitializers = 1610612944;
  
  public static final int ParsingErrorOnKeyword = 1610612945;
  
  public static final int ParsingErrorOnKeywordNoSuggestion = 1610612946;
  
  public static final int ComparingIdentical = 536871123;
  
  public static final int UnsafeCast = 16777428;
  
  public static final int UnmatchedBracket = 1610612956;
  
  public static final int NoFieldOnBaseType = 33554653;
  
  public static final int InvalidExpressionAsStatement = 1610612958;
  
  public static final int ExpressionShouldBeAVariable = 1610612959;
  
  public static final int MissingSemiColon = 1610612960;
  
  public static final int InvalidParenthesizedExpression = 1610612961;
  
  public static final int NoSuperInInterfaceContext = 1610612962;
  
  public static final int ParsingErrorInsertTokenBefore = 1610612966;
  
  public static final int ParsingErrorInsertTokenAfter = 1610612967;
  
  public static final int ParsingErrorDeleteToken = 1610612968;
  
  public static final int ParsingErrorDeleteTokens = 1610612969;
  
  public static final int ParsingErrorMergeTokens = 1610612970;
  
  public static final int ParsingErrorInvalidToken = 1610612971;
  
  public static final int ParsingErrorMisplacedConstruct = 1610612972;
  
  public static final int ParsingErrorReplaceTokens = 1610612973;
  
  public static final int ParsingErrorNoSuggestionForTokens = 1610612974;
  
  public static final int ParsingErrorUnexpectedEOF = 1610612975;
  
  public static final int ParsingErrorInsertToComplete = 1610612976;
  
  public static final int ParsingErrorInsertToCompleteScope = 1610612977;
  
  public static final int ParsingErrorInsertToCompletePhrase = 1610612978;
  
  public static final int EndOfSource = 1610612986;
  
  public static final int InvalidHexa = 1610612987;
  
  public static final int InvalidOctal = 1610612988;
  
  public static final int InvalidCharacterConstant = 1610612989;
  
  public static final int InvalidEscape = 1610612990;
  
  public static final int InvalidInput = 1610612991;
  
  public static final int InvalidUnicodeEscape = 1610612992;
  
  public static final int InvalidFloat = 1610612993;
  
  public static final int NullSourceString = 1610612994;
  
  public static final int UnterminatedString = 1610612995;
  
  public static final int UnterminatedComment = 1610612996;
  
  public static final int NonExternalizedStringLiteral = 536871173;
  
  public static final int InvalidDigit = 1610612998;
  
  public static final int InvalidLowSurrogate = 1610612999;
  
  public static final int InvalidHighSurrogate = 1610613000;
  
  public static final int UnnecessaryNLSTag = 536871177;
  
  public static final int InvalidBinary = 1610613002;
  
  public static final int BinaryLiteralNotBelow17 = 1610613003;
  
  public static final int IllegalUnderscorePosition = 1610613004;
  
  public static final int UnderscoresInLiteralsNotBelow17 = 1610613005;
  
  public static final int IllegalHexaLiteral = 1610613006;
  
  public static final int MissingTypeInLambda = 67109135;
  
  public static final int UnterminatedTextBlock = 2097424;
  
  public static final int DiscouragedReference = 16777496;
  
  public static final int InterfaceCannotHaveInitializers = 16777516;
  
  public static final int DuplicateModifierForType = 16777517;
  
  public static final int IllegalModifierForClass = 16777518;
  
  public static final int IllegalModifierForInterface = 16777519;
  
  public static final int IllegalModifierForMemberClass = 16777520;
  
  public static final int IllegalModifierForMemberInterface = 16777521;
  
  public static final int IllegalModifierForLocalClass = 16777522;
  
  public static final int ForbiddenReference = 16777523;
  
  public static final int IllegalModifierCombinationFinalAbstractForClass = 16777524;
  
  public static final int IllegalVisibilityModifierForInterfaceMemberType = 16777525;
  
  public static final int IllegalVisibilityModifierCombinationForMemberType = 16777526;
  
  public static final int IllegalStaticModifierForMemberType = 16777527;
  
  public static final int SuperclassMustBeAClass = 16777528;
  
  public static final int ClassExtendFinalClass = 16777529;
  
  public static final int DuplicateSuperInterface = 16777530;
  
  public static final int SuperInterfaceMustBeAnInterface = 16777531;
  
  public static final int HierarchyCircularitySelfReference = 16777532;
  
  public static final int HierarchyCircularity = 16777533;
  
  public static final int HidingEnclosingType = 16777534;
  
  public static final int DuplicateNestedType = 16777535;
  
  public static final int CannotThrowType = 16777536;
  
  public static final int PackageCollidesWithType = 16777537;
  
  public static final int TypeCollidesWithPackage = 16777538;
  
  public static final int DuplicateTypes = 16777539;
  
  public static final int IsClassPathCorrect = 16777540;
  
  public static final int PublicClassMustMatchFileName = 16777541;
  
  public static final int MustSpecifyPackage = 536871238;
  
  public static final int HierarchyHasProblems = 16777543;
  
  public static final int PackageIsNotExpectedPackage = 536871240;
  
  public static final int ObjectCannotHaveSuperTypes = 536871241;
  
  public static final int ObjectMustBeClass = 536871242;
  
  public static final int RedundantSuperinterface = 16777547;
  
  public static final int ShouldImplementHashcode = 16777548;
  
  public static final int AbstractMethodsInConcreteClass = 16777549;
  
  public static final int SuperclassNotFound = 16777546;
  
  public static final int SuperclassNotVisible = 16777547;
  
  public static final int SuperclassAmbiguous = 16777548;
  
  public static final int SuperclassInternalNameProvided = 16777549;
  
  public static final int SuperclassInheritedNameHidesEnclosingName = 16777550;
  
  public static final int InterfaceNotFound = 16777551;
  
  public static final int InterfaceNotVisible = 16777552;
  
  public static final int InterfaceAmbiguous = 16777553;
  
  public static final int InterfaceInternalNameProvided = 16777554;
  
  public static final int InterfaceInheritedNameHidesEnclosingName = 16777555;
  
  public static final int DuplicateField = 33554772;
  
  public static final int DuplicateModifierForField = 33554773;
  
  public static final int IllegalModifierForField = 33554774;
  
  public static final int IllegalModifierForInterfaceField = 33554775;
  
  public static final int IllegalVisibilityModifierCombinationForField = 33554776;
  
  public static final int IllegalModifierCombinationFinalVolatileForField = 33554777;
  
  public static final int UnexpectedStaticModifierForField = 33554778;
  
  public static final int IsClassPathCorrectWithReferencingType = 16777563;
  
  public static final int FieldTypeNotFound = 33554782;
  
  public static final int FieldTypeNotVisible = 33554783;
  
  public static final int FieldTypeAmbiguous = 33554784;
  
  public static final int FieldTypeInternalNameProvided = 33554785;
  
  public static final int FieldTypeInheritedNameHidesEnclosingName = 33554786;
  
  public static final int DuplicateMethod = 67109219;
  
  public static final int IllegalModifierForArgument = 67109220;
  
  public static final int DuplicateModifierForMethod = 67109221;
  
  public static final int IllegalModifierForMethod = 67109222;
  
  public static final int IllegalModifierForInterfaceMethod = 67109223;
  
  public static final int IllegalVisibilityModifierCombinationForMethod = 67109224;
  
  public static final int UnexpectedStaticModifierForMethod = 67109225;
  
  public static final int IllegalAbstractModifierCombinationForMethod = 67109226;
  
  public static final int AbstractMethodInAbstractClass = 67109227;
  
  public static final int ArgumentTypeCannotBeVoid = 67109228;
  
  public static final int ArgumentTypeCannotBeVoidArray = 67109229;
  
  public static final int ReturnTypeCannotBeVoidArray = 67109230;
  
  public static final int NativeMethodsCannotBeStrictfp = 67109231;
  
  public static final int DuplicateModifierForArgument = 67109232;
  
  public static final int IllegalModifierForConstructor = 67109233;
  
  public static final int ArgumentTypeNotFound = 67109234;
  
  public static final int ArgumentTypeNotVisible = 67109235;
  
  public static final int ArgumentTypeAmbiguous = 67109236;
  
  public static final int ArgumentTypeInternalNameProvided = 67109237;
  
  public static final int ArgumentTypeInheritedNameHidesEnclosingName = 67109238;
  
  public static final int ExceptionTypeNotFound = 67109239;
  
  public static final int ExceptionTypeNotVisible = 67109240;
  
  public static final int ExceptionTypeAmbiguous = 67109241;
  
  public static final int ExceptionTypeInternalNameProvided = 67109242;
  
  public static final int ExceptionTypeInheritedNameHidesEnclosingName = 67109243;
  
  public static final int ReturnTypeNotFound = 67109244;
  
  public static final int ReturnTypeNotVisible = 67109245;
  
  public static final int ReturnTypeAmbiguous = 67109246;
  
  public static final int ReturnTypeInternalNameProvided = 67109247;
  
  public static final int ReturnTypeInheritedNameHidesEnclosingName = 67109248;
  
  public static final int ConflictingImport = 268435841;
  
  public static final int DuplicateImport = 268435842;
  
  public static final int CannotImportPackage = 268435843;
  
  public static final int UnusedImport = 268435844;
  
  public static final int ImportNotFound = 268435846;
  
  public static final int ImportNotVisible = 268435847;
  
  public static final int ImportAmbiguous = 268435848;
  
  public static final int ImportInternalNameProvided = 268435849;
  
  public static final int ImportInheritedNameHidesEnclosingName = 268435850;
  
  public static final int InvalidTypeForStaticImport = 268435847;
  
  public static final int DuplicateModifierForVariable = 67109259;
  
  public static final int IllegalModifierForVariable = 67109260;
  
  public static final int LocalVariableCannotBeNull = 536871309;
  
  public static final int LocalVariableCanOnlyBeNull = 536871310;
  
  public static final int LocalVariableMayBeNull = 536871311;
  
  public static final int AbstractMethodMustBeImplemented = 67109264;
  
  public static final int FinalMethodCannotBeOverridden = 67109265;
  
  public static final int IncompatibleExceptionInThrowsClause = 67109266;
  
  public static final int IncompatibleExceptionInInheritedMethodThrowsClause = 67109267;
  
  public static final int IncompatibleReturnType = 67109268;
  
  public static final int InheritedMethodReducesVisibility = 67109269;
  
  public static final int CannotOverrideAStaticMethodWithAnInstanceMethod = 67109270;
  
  public static final int CannotHideAnInstanceMethodWithAStaticMethod = 67109271;
  
  public static final int StaticInheritedMethodConflicts = 67109272;
  
  public static final int MethodReducesVisibility = 67109273;
  
  public static final int OverridingNonVisibleMethod = 67109274;
  
  public static final int AbstractMethodCannotBeOverridden = 67109275;
  
  public static final int OverridingDeprecatedMethod = 67109276;
  
  public static final int IncompatibleReturnTypeForNonInheritedInterfaceMethod = 67109277;
  
  public static final int IncompatibleExceptionInThrowsClauseForNonInheritedInterfaceMethod = 67109278;
  
  public static final int IllegalVararg = 67109279;
  
  public static final int OverridingMethodWithoutSuperInvocation = 67109280;
  
  public static final int MissingSynchronizedModifierInInheritedMethod = 67109281;
  
  public static final int AbstractMethodMustBeImplementedOverConcreteMethod = 67109282;
  
  public static final int InheritedIncompatibleReturnType = 67109283;
  
  public static final int CodeSnippetMissingClass = 536871332;
  
  public static final int CodeSnippetMissingMethod = 536871333;
  
  public static final int CannotUseSuperInCodeSnippet = 536871334;
  
  public static final int TooManyConstantsInConstantPool = 536871342;
  
  public static final int TooManyBytesForStringConstant = 536871343;
  
  public static final int TooManyFields = 536871344;
  
  public static final int TooManyMethods = 536871345;
  
  public static final int TooManyParametersForSyntheticMethod = 536871346;
  
  public static final int UseAssertAsAnIdentifier = 536871352;
  
  public static final int UseEnumAsAnIdentifier = 536871353;
  
  public static final int EnumConstantsCannotBeSurroundedByParenthesis = 1610613178;
  
  public static final int IllegalUseOfUnderscoreAsAnIdentifier = 1610613179;
  
  public static final int UninternedIdentityComparison = 1610613180;
  
  public static final int ErrorUseOfUnderscoreAsAnIdentifier = 1610613181;
  
  public static final int Task = 536871362;
  
  public static final int NullLocalVariableReference = 536871363;
  
  public static final int PotentialNullLocalVariableReference = 536871364;
  
  public static final int RedundantNullCheckOnNullLocalVariable = 536871365;
  
  public static final int NullLocalVariableComparisonYieldsFalse = 536871366;
  
  public static final int RedundantLocalVariableNullAssignment = 536871367;
  
  public static final int NullLocalVariableInstanceofYieldsFalse = 536871368;
  
  public static final int RedundantNullCheckOnNonNullLocalVariable = 536871369;
  
  public static final int NonNullLocalVariableComparisonYieldsFalse = 536871370;
  
  public static final int PotentialNullUnboxing = 536871371;
  
  public static final int NullUnboxing = 536871373;
  
  public static final int UndocumentedEmptyBlock = 536871372;
  
  public static final int JavadocInvalidSeeUrlReference = -1610612274;
  
  public static final int JavadocMissingTagDescription = -1610612273;
  
  public static final int JavadocDuplicateTag = -1610612272;
  
  public static final int JavadocHiddenReference = -1610612271;
  
  public static final int JavadocInvalidMemberTypeQualification = -1610612270;
  
  public static final int JavadocMissingIdentifier = -1610612269;
  
  public static final int JavadocNonStaticTypeFromStaticInvocation = -1610612268;
  
  public static final int JavadocInvalidParamTagTypeParameter = -1610612267;
  
  public static final int JavadocUnexpectedTag = -1610612266;
  
  public static final int JavadocMissingParamTag = -1610612265;
  
  public static final int JavadocMissingParamName = -1610612264;
  
  public static final int JavadocDuplicateParamName = -1610612263;
  
  public static final int JavadocInvalidParamName = -1610612262;
  
  public static final int JavadocMissingReturnTag = -1610612261;
  
  public static final int JavadocDuplicateReturnTag = -1610612260;
  
  public static final int JavadocMissingThrowsTag = -1610612259;
  
  public static final int JavadocMissingThrowsClassName = -1610612258;
  
  public static final int JavadocInvalidThrowsClass = -1610612257;
  
  public static final int JavadocDuplicateThrowsClassName = -1610612256;
  
  public static final int JavadocInvalidThrowsClassName = -1610612255;
  
  public static final int JavadocMissingSeeReference = -1610612254;
  
  public static final int JavadocInvalidSeeReference = -1610612253;
  
  public static final int JavadocInvalidSeeHref = -1610612252;
  
  public static final int JavadocInvalidSeeArgs = -1610612251;
  
  public static final int JavadocMissing = -1610612250;
  
  public static final int JavadocInvalidTag = -1610612249;
  
  public static final int JavadocUndefinedField = -1610612248;
  
  public static final int JavadocNotVisibleField = -1610612247;
  
  public static final int JavadocAmbiguousField = -1610612246;
  
  public static final int JavadocUsingDeprecatedField = -1610612245;
  
  public static final int JavadocUndefinedConstructor = -1610612244;
  
  public static final int JavadocNotVisibleConstructor = -1610612243;
  
  public static final int JavadocAmbiguousConstructor = -1610612242;
  
  public static final int JavadocUsingDeprecatedConstructor = -1610612241;
  
  public static final int JavadocUndefinedMethod = -1610612240;
  
  public static final int JavadocNotVisibleMethod = -1610612239;
  
  public static final int JavadocAmbiguousMethod = -1610612238;
  
  public static final int JavadocUsingDeprecatedMethod = -1610612237;
  
  public static final int JavadocNoMessageSendOnBaseType = -1610612236;
  
  public static final int JavadocParameterMismatch = -1610612235;
  
  public static final int JavadocNoMessageSendOnArrayType = -1610612234;
  
  public static final int JavadocUndefinedType = -1610612233;
  
  public static final int JavadocNotVisibleType = -1610612232;
  
  public static final int JavadocAmbiguousType = -1610612231;
  
  public static final int JavadocUsingDeprecatedType = -1610612230;
  
  public static final int JavadocInternalTypeNameProvided = -1610612229;
  
  public static final int JavadocInheritedMethodHidesEnclosingName = -1610612228;
  
  public static final int JavadocInheritedFieldHidesEnclosingName = -1610612227;
  
  public static final int JavadocInheritedNameHidesEnclosingTypeName = -1610612226;
  
  public static final int JavadocAmbiguousMethodReference = -1610612225;
  
  public static final int JavadocUnterminatedInlineTag = -1610612224;
  
  public static final int JavadocMalformedSeeReference = -1610612223;
  
  public static final int JavadocMessagePrefix = 536871426;
  
  public static final int JavadocMissingHashCharacter = -1610612221;
  
  public static final int JavadocEmptyReturnTag = -1610612220;
  
  public static final int JavadocInvalidValueReference = -1610612219;
  
  public static final int JavadocUnexpectedText = -1610612218;
  
  public static final int JavadocInvalidParamTagName = -1610612217;
  
  public static final int JavadocMissingUsesTag = -1610610936;
  
  public static final int JavadocDuplicateUsesTag = -1610610935;
  
  public static final int JavadocMissingUsesClassName = -1610610934;
  
  public static final int JavadocInvalidUsesClassName = -1610610933;
  
  public static final int JavadocInvalidUsesClass = -1610610932;
  
  public static final int JavadocMissingProvidesTag = -1610610931;
  
  public static final int JavadocDuplicateProvidesTag = -1610610930;
  
  public static final int JavadocMissingProvidesClassName = -1610610929;
  
  public static final int JavadocInvalidProvidesClassName = -1610610928;
  
  public static final int JavadocInvalidProvidesClass = -1610610927;
  
  public static final int JavadocInvalidModuleQualification = -1610610926;
  
  public static final int JavadocInvalidModule = -1610610925;
  
  public static final int JavadocInvalidSnippet = -1610610924;
  
  public static final int JavadocInvalidSnippetMissingColon = -1610610923;
  
  public static final int JavadocInvalidSnippetContentNewLine = -1610610922;
  
  public static final int JavadocInvalidSnippetRegionNotClosed = -1610610921;
  
  public static final int JavadocInvalidSnippetRegexSubstringTogether = -1610610920;
  
  public static final int JavadocInvalidSnippetDuplicateRegions = -1610610919;
  
  public static final int DuplicateTypeVariable = 536871432;
  
  public static final int IllegalTypeVariableSuperReference = 536871433;
  
  public static final int NonStaticTypeFromStaticInvocation = 536871434;
  
  public static final int ObjectCannotBeGeneric = 536871435;
  
  public static final int NonGenericType = 16777740;
  
  public static final int IncorrectArityForParameterizedType = 16777741;
  
  public static final int TypeArgumentMismatch = 16777742;
  
  public static final int DuplicateMethodErasure = 16777743;
  
  public static final int ReferenceToForwardTypeVariable = 16777744;
  
  public static final int BoundMustBeAnInterface = 16777745;
  
  public static final int UnsafeRawConstructorInvocation = 16777746;
  
  public static final int UnsafeRawMethodInvocation = 16777747;
  
  public static final int UnsafeTypeConversion = 16777748;
  
  public static final int InvalidTypeVariableExceptionType = 16777749;
  
  public static final int InvalidParameterizedExceptionType = 16777750;
  
  public static final int IllegalGenericArray = 16777751;
  
  public static final int UnsafeRawFieldAssignment = 16777752;
  
  public static final int FinalBoundForTypeVariable = 16777753;
  
  public static final int UndefinedTypeVariable = 536871450;
  
  public static final int SuperInterfacesCollide = 16777755;
  
  public static final int WildcardConstructorInvocation = 16777756;
  
  public static final int WildcardMethodInvocation = 16777757;
  
  public static final int WildcardFieldAssignment = 16777758;
  
  public static final int GenericMethodTypeArgumentMismatch = 16777759;
  
  public static final int GenericConstructorTypeArgumentMismatch = 16777760;
  
  public static final int UnsafeGenericCast = 16777761;
  
  public static final int IllegalInstanceofParameterizedType = 536871458;
  
  public static final int IllegalInstanceofTypeParameter = 536871459;
  
  public static final int NonGenericMethod = 16777764;
  
  public static final int IncorrectArityForParameterizedMethod = 16777765;
  
  public static final int ParameterizedMethodArgumentTypeMismatch = 16777766;
  
  public static final int NonGenericConstructor = 16777767;
  
  public static final int IncorrectArityForParameterizedConstructor = 16777768;
  
  public static final int ParameterizedConstructorArgumentTypeMismatch = 16777769;
  
  public static final int TypeArgumentsForRawGenericMethod = 16777770;
  
  public static final int TypeArgumentsForRawGenericConstructor = 16777771;
  
  public static final int SuperTypeUsingWildcard = 16777772;
  
  public static final int GenericTypeCannotExtendThrowable = 16777773;
  
  public static final int IllegalClassLiteralForTypeVariable = 16777774;
  
  public static final int UnsafeReturnTypeOverride = 67109423;
  
  public static final int MethodNameClash = 67109424;
  
  public static final int RawMemberTypeCannotBeParameterized = 16777777;
  
  public static final int MissingArgumentsForParameterizedMemberType = 16777778;
  
  public static final int StaticMemberOfParameterizedType = 16777779;
  
  public static final int BoundHasConflictingArguments = 16777780;
  
  public static final int DuplicateParameterizedMethods = 67109429;
  
  public static final int IllegalQualifiedParameterizedTypeAllocation = 16777782;
  
  public static final int DuplicateBounds = 16777783;
  
  public static final int BoundCannotBeArray = 16777784;
  
  public static final int UnsafeRawGenericConstructorInvocation = 16777785;
  
  public static final int UnsafeRawGenericMethodInvocation = 16777786;
  
  public static final int TypeParameterHidingType = 16777787;
  
  public static final int RawTypeReference = 16777788;
  
  public static final int NoAdditionalBoundAfterTypeVariable = 16777789;
  
  public static final int UnsafeGenericArrayForVarargs = 67109438;
  
  public static final int IllegalAccessFromTypeVariable = 16777791;
  
  public static final int TypeHidingTypeParameterFromType = 16777792;
  
  public static final int TypeHidingTypeParameterFromMethod = 16777793;
  
  public static final int InvalidUsageOfWildcard = 1610613314;
  
  public static final int UnusedTypeArgumentsForMethodInvocation = 67109443;
  
  public static final int IncompatibleTypesInForeach = 16777796;
  
  public static final int InvalidTypeForCollection = 536871493;
  
  public static final int InvalidTypeForCollectionTarget14 = 536871494;
  
  public static final int DuplicateInheritedMethods = 67109447;
  
  public static final int MethodNameClashHidden = 67109448;
  
  public static final int UnsafeElementTypeConversion = 16777801;
  
  public static final int InvalidTypeArguments = 83886666;
  
  public static final int InvalidUsageOfTypeParameters = 1610613326;
  
  public static final int InvalidUsageOfStaticImports = 1610613327;
  
  public static final int InvalidUsageOfForeachStatements = 1610613328;
  
  public static final int InvalidUsageOfTypeArguments = 1610613329;
  
  public static final int InvalidUsageOfEnumDeclarations = 1610613330;
  
  public static final int InvalidUsageOfVarargs = 1610613331;
  
  public static final int InvalidUsageOfAnnotations = 1610613332;
  
  public static final int InvalidUsageOfAnnotationDeclarations = 1610613333;
  
  public static final int InvalidUsageOfTypeParametersForAnnotationDeclaration = 1610613334;
  
  public static final int InvalidUsageOfTypeParametersForEnumDeclaration = 1610613335;
  
  public static final int IllegalModifierForAnnotationMethod = 67109464;
  
  public static final int IllegalExtendedDimensions = 67109465;
  
  public static final int InvalidFileNameForPackageAnnotations = 1610613338;
  
  public static final int IllegalModifierForAnnotationType = 16777819;
  
  public static final int IllegalModifierForAnnotationMemberType = 16777820;
  
  public static final int InvalidAnnotationMemberType = 16777821;
  
  public static final int AnnotationCircularitySelfReference = 16777822;
  
  public static final int AnnotationCircularity = 16777823;
  
  public static final int DuplicateAnnotation = 16777824;
  
  public static final int MissingValueForAnnotationMember = 16777825;
  
  public static final int DuplicateAnnotationMember = 536871522;
  
  public static final int UndefinedAnnotationMember = 67109475;
  
  public static final int AnnotationValueMustBeClassLiteral = 536871524;
  
  public static final int AnnotationValueMustBeConstant = 536871525;
  
  public static final int AnnotationFieldNeedConstantInitialization = 536871526;
  
  public static final int IllegalModifierForAnnotationField = 536871527;
  
  public static final int AnnotationCannotOverrideMethod = 67109480;
  
  public static final int AnnotationMembersCannotHaveParameters = 1610613353;
  
  public static final int AnnotationMembersCannotHaveTypeParameters = 1610613354;
  
  public static final int AnnotationTypeDeclarationCannotHaveSuperclass = 1610613355;
  
  public static final int AnnotationTypeDeclarationCannotHaveSuperinterfaces = 1610613356;
  
  public static final int DuplicateTargetInTargetAnnotation = 536871533;
  
  public static final int DisallowedTargetForAnnotation = 16777838;
  
  public static final int MethodMustOverride = 67109487;
  
  public static final int AnnotationTypeDeclarationCannotHaveConstructor = 1610613360;
  
  public static final int AnnotationValueMustBeAnnotation = 536871537;
  
  public static final int AnnotationTypeUsedAsSuperInterface = 16777842;
  
  public static final int MissingOverrideAnnotation = 67109491;
  
  public static final int FieldMissingDeprecatedAnnotation = 536871540;
  
  public static final int MethodMissingDeprecatedAnnotation = 536871541;
  
  public static final int TypeMissingDeprecatedAnnotation = 536871542;
  
  public static final int UnhandledWarningToken = 536871543;
  
  public static final int AnnotationValueMustBeArrayInitializer = 536871544;
  
  public static final int AnnotationValueMustBeAnEnumConstant = 536871545;
  
  public static final int MethodMustOverrideOrImplement = 67109498;
  
  public static final int UnusedWarningToken = 536871547;
  
  public static final int MissingOverrideAnnotationForInterfaceMethodImplementation = 67109500;
  
  public static final int InvalidUsageOfTypeAnnotations = 1610613373;
  
  public static final int DisallowedExplicitThisParameter = 1610613374;
  
  public static final int MisplacedTypeAnnotations = 1610613375;
  
  public static final int IllegalTypeAnnotationsInStaticMemberAccess = 1610613376;
  
  public static final int IllegalUsageOfTypeAnnotations = 1610613377;
  
  public static final int IllegalDeclarationOfThisParameter = 1610613378;
  
  public static final int ExplicitThisParameterNotBelow18 = 1610613379;
  
  public static final int DefaultMethodNotBelow18 = 1610613380;
  
  public static final int LambdaExpressionNotBelow18 = 1610613381;
  
  public static final int MethodReferenceNotBelow18 = 1610613382;
  
  public static final int ConstructorReferenceNotBelow18 = 1610613383;
  
  public static final int ExplicitThisParameterNotInLambda = 1610613384;
  
  @Deprecated
  public static final int ExplicitAnnotationTargetRequired = 16777865;
  
  public static final int IllegalTypeForExplicitThis = 1610613386;
  
  public static final int IllegalQualifierForExplicitThis = 1610613387;
  
  public static final int IllegalQualifierForExplicitThis2 = 1610613388;
  
  public static final int TargetTypeNotAFunctionalInterface = 553648781;
  
  public static final int IllegalVarargInLambda = 553648782;
  
  public static final int illFormedParameterizationOfFunctionalInterface = 553648783;
  
  public static final int lambdaSignatureMismatched = 553648784;
  
  public static final int lambdaParameterTypeMismatched = 553648785;
  
  public static final int IncompatibleLambdaParameterType = 553648786;
  
  public static final int NoGenericLambda = 553648787;
  
  public static final int UnusedTypeArgumentsForConstructorInvocation = 67109524;
  
  public static final int UnusedTypeParameter = 16777877;
  
  public static final int IllegalArrayOfUnionType = 16777878;
  
  public static final int OuterLocalMustBeEffectivelyFinal = 536871575;
  
  public static final int InterfaceNotFunctionalInterface = 553648792;
  
  public static final int ConstructionTypeMismatch = 553648793;
  
  public static final int ToleratedMisplacedTypeAnnotations = 1610613402;
  
  public static final int InterfaceSuperInvocationNotBelow18 = 1610613403;
  
  public static final int InterfaceStaticMethodInvocationNotBelow18 = 1610613404;
  
  public static final int FieldMustBeFinal = 536871581;
  
  public static final int NonNullExpressionComparisonYieldsFalse = 536871582;
  
  public static final int RedundantNullCheckOnNonNullExpression = 536871583;
  
  public static final int NullExpressionReference = 536871584;
  
  public static final int PotentialNullExpressionReference = 536871585;
  
  public static final int CorruptedSignature = 536871612;
  
  public static final int InvalidEncoding = 536871613;
  
  public static final int CannotReadSource = 536871614;
  
  public static final int BoxingConversion = 536871632;
  
  public static final int UnboxingConversion = 536871633;
  
  public static final int StrictfpNotRequired = 1610613477;
  
  public static final int IllegalModifierForEnum = 16777966;
  
  public static final int IllegalModifierForEnumConstant = 33555183;
  
  public static final int IllegalModifierForLocalEnum = 16777968;
  
  public static final int IllegalModifierForMemberEnum = 16777969;
  
  public static final int CannotDeclareEnumSpecialMethod = 67109618;
  
  public static final int IllegalQualifiedEnumConstantLabel = 33555187;
  
  public static final int CannotExtendEnum = 16777972;
  
  public static final int CannotInvokeSuperConstructorInEnum = 67109621;
  
  public static final int EnumAbstractMethodMustBeImplemented = 67109622;
  
  public static final int EnumSwitchCannotTargetField = 33555191;
  
  public static final int IllegalModifierForEnumConstructor = 67109624;
  
  public static final int MissingEnumConstantCase = 33555193;
  
  public static final int EnumStaticFieldInInInitializerContext = 33555194;
  
  public static final int EnumConstantMustImplementAbstractMethod = 67109627;
  
  public static final int EnumConstantCannotDefineAbstractMethod = 67109628;
  
  public static final int AbstractMethodInEnum = 67109629;
  
  public static final int MissingEnumDefaultCase = 536871678;
  
  public static final int MissingDefaultCase = 536871679;
  
  public static final int MissingEnumConstantCaseDespiteDefault = 33555200;
  
  public static final int UninitializedLocalVariableHintMissingDefault = 536871681;
  
  public static final int UninitializedBlankFinalFieldHintMissingDefault = 33555202;
  
  public static final int ShouldReturnValueHintMissingDefault = 67109635;
  
  public static final int IllegalExtendedDimensionsForVarArgs = 1610613536;
  
  public static final int MethodVarargsArgumentNeedCast = 67109665;
  
  public static final int ConstructorVarargsArgumentNeedCast = 134218530;
  
  public static final int VarargsConflict = 67109667;
  
  public static final int SafeVarargsOnFixedArityMethod = 67109668;
  
  public static final int SafeVarargsOnNonFinalInstanceMethod = 67109669;
  
  public static final int PotentialHeapPollutionFromVararg = 67109670;
  
  public static final int VarargsElementTypeNotVisible = 67109671;
  
  public static final int VarargsElementTypeNotVisibleForConstructor = 134218536;
  
  public static final int ApplicableMethodOverriddenByInapplicable = 67109673;
  
  public static final int JavadocGenericMethodTypeArgumentMismatch = -1610611886;
  
  public static final int JavadocNonGenericMethod = -1610611885;
  
  public static final int JavadocIncorrectArityForParameterizedMethod = -1610611884;
  
  public static final int JavadocParameterizedMethodArgumentTypeMismatch = -1610611883;
  
  public static final int JavadocTypeArgumentsForRawGenericMethod = -1610611882;
  
  public static final int JavadocGenericConstructorTypeArgumentMismatch = -1610611881;
  
  public static final int JavadocNonGenericConstructor = -1610611880;
  
  public static final int JavadocIncorrectArityForParameterizedConstructor = -1610611879;
  
  public static final int JavadocParameterizedConstructorArgumentTypeMismatch = -1610611878;
  
  public static final int JavadocTypeArgumentsForRawGenericConstructor = -1610611877;
  
  public static final int AssignmentToMultiCatchParameter = 536871782;
  
  public static final int ResourceHasToImplementAutoCloseable = 16778087;
  
  public static final int AssignmentToResource = 536871784;
  
  public static final int InvalidUnionTypeReferenceSequence = 553649001;
  
  public static final int AutoManagedResourceNotBelow17 = 1610613610;
  
  public static final int MultiCatchNotBelow17 = 1610613611;
  
  public static final int PolymorphicMethodNotBelow17 = 67109740;
  
  public static final int IncorrectSwitchType17 = 16778093;
  
  public static final int CannotInferElidedTypes = 16778094;
  
  public static final int CannotUseDiamondWithExplicitTypeArguments = 16778095;
  
  public static final int CannotUseDiamondWithAnonymousClasses = 16778096;
  
  public static final int SwitchOnStringsNotBelow17 = 16778097;
  
  public static final int UnhandledExceptionOnAutoClose = 16778098;
  
  public static final int DiamondNotBelow17 = 16778099;
  
  public static final int RedundantSpecificationOfTypeArguments = 16778100;
  
  public static final int PotentiallyUnclosedCloseable = 536871797;
  
  public static final int PotentiallyUnclosedCloseableAtExit = 536871798;
  
  public static final int UnclosedCloseable = 536871799;
  
  public static final int UnclosedCloseableAtExit = 536871800;
  
  public static final int ExplicitlyClosedAutoCloseable = 536871801;
  
  public static final int SwitchOnEnumNotBelow15 = 16778106;
  
  public static final int IntersectionCastNotBelow18 = 16778107;
  
  public static final int IllegalBasetypeInIntersectionCast = 16778108;
  
  public static final int IllegalArrayTypeInIntersectionCast = 16778109;
  
  public static final int DuplicateBoundInIntersectionCast = 16778110;
  
  public static final int MultipleFunctionalInterfaces = 16778111;
  
  public static final int StaticInterfaceMethodNotBelow18 = 1610613632;
  
  public static final int DuplicateAnnotationNotMarkedRepeatable = 16778113;
  
  public static final int DisallowedTargetForContainerAnnotationType = 16778114;
  
  public static final int RepeatedAnnotationWithContainerAnnotation = 16778115;
  
  public static final int AutoManagedVariableResourceNotBelow9 = 1610614087;
  
  public static final int ExternalProblemNotFixable = 900;
  
  public static final int ExternalProblemFixable = 901;
  
  public static final int ContainerAnnotationTypeHasWrongValueType = 16778118;
  
  public static final int ContainerAnnotationTypeMustHaveValue = 16778119;
  
  public static final int ContainerAnnotationTypeHasNonDefaultMembers = 16778120;
  
  public static final int ContainerAnnotationTypeHasShorterRetention = 16778121;
  
  public static final int RepeatableAnnotationTypeTargetMismatch = 16778122;
  
  public static final int RepeatableAnnotationTypeIsDocumented = 16778123;
  
  public static final int RepeatableAnnotationTypeIsInherited = 16778124;
  
  public static final int RepeatableAnnotationWithRepeatingContainerAnnotation = 16778125;
  
  public static final int RequiredNonNullButProvidedNull = 16778126;
  
  public static final int RequiredNonNullButProvidedPotentialNull = 16778127;
  
  public static final int RequiredNonNullButProvidedUnknown = 16778128;
  
  public static final int MissingNonNullByDefaultAnnotationOnPackage = 536871825;
  
  public static final int IllegalReturnNullityRedefinition = 67109778;
  
  public static final int IllegalRedefinitionToNonNullParameter = 67109779;
  
  public static final int IllegalDefinitionToNonNullParameter = 67109780;
  
  public static final int ParameterLackingNonNullAnnotation = 67109781;
  
  public static final int ParameterLackingNullableAnnotation = 67109782;
  
  public static final int PotentialNullMessageSendReference = 536871831;
  
  public static final int RedundantNullCheckOnNonNullMessageSend = 536871832;
  
  public static final int CannotImplementIncompatibleNullness = 536871833;
  
  public static final int RedundantNullAnnotation = 67109786;
  
  public static final int IllegalAnnotationForBaseType = 16778139;
  
  public static final int NullableFieldReference = 33555356;
  
  public static final int RedundantNullDefaultAnnotation = 536871837;
  
  public static final int RedundantNullDefaultAnnotationPackage = 536871838;
  
  public static final int RedundantNullDefaultAnnotationType = 536871839;
  
  public static final int RedundantNullDefaultAnnotationMethod = 536871840;
  
  public static final int ContradictoryNullAnnotations = 536871841;
  
  public static final int MissingNonNullByDefaultAnnotationOnType = 536871842;
  
  public static final int RedundantNullCheckOnSpecdNonNullLocalVariable = 536871843;
  
  public static final int SpecdNonNullLocalVariableComparisonYieldsFalse = 536871844;
  
  public static final int RequiredNonNullButProvidedSpecdNullable = 536871845;
  
  public static final int UninitializedNonNullField = 33555366;
  
  public static final int UninitializedNonNullFieldHintMissingDefault = 33555367;
  
  public static final int NonNullMessageSendComparisonYieldsFalse = 536871848;
  
  public static final int RedundantNullCheckOnNonNullSpecdField = 536871849;
  
  public static final int NonNullSpecdFieldComparisonYieldsFalse = 536871850;
  
  public static final int ConflictingNullAnnotations = 67109803;
  
  public static final int ConflictingInheritedNullAnnotations = 67109804;
  
  public static final int RedundantNullCheckOnField = 536871853;
  
  public static final int FieldComparisonYieldsFalse = 536871854;
  
  public static final int RedundantNullDefaultAnnotationModule = 536871855;
  
  public static final int RedundantNullCheckOnConstNonNullField = 536871856;
  
  public static final int ConstNonNullFieldComparisonYieldsFalse = 536871857;
  
  public static final int InheritedParameterLackingNonNullAnnotation = 67109810;
  
  public static final int ArrayReferencePotentialNullReference = 536871863;
  
  public static final int DereferencingNullableExpression = 536871864;
  
  public static final int NullityMismatchingTypeAnnotation = 536871865;
  
  public static final int NullityMismatchingTypeAnnotationSuperHint = 536871866;
  
  public static final int NullityUncheckedTypeAnnotationDetail = 536871867;
  
  public static final int NullityUncheckedTypeAnnotationDetailSuperHint = 536871868;
  
  public static final int ReferenceExpressionParameterNullityMismatch = 67109821;
  
  public static final int ReferenceExpressionParameterNullityUnchecked = 67109822;
  
  public static final int ReferenceExpressionReturnNullRedef = 67109823;
  
  public static final int ReferenceExpressionReturnNullRedefUnchecked = 67109824;
  
  public static final int RedundantNullCheckAgainstNonNullType = 536871873;
  
  public static final int NullAnnotationUnsupportedLocation = 536871874;
  
  public static final int NullAnnotationUnsupportedLocationAtType = 536871875;
  
  public static final int NullityMismatchTypeArgument = 536871876;
  
  public static final int ContradictoryNullAnnotationsOnBound = 536871877;
  
  public static final int ContradictoryNullAnnotationsInferred = 536871878;
  
  public static final int UnsafeNullnessCast = 536871879;
  
  public static final int NonNullDefaultDetailIsNotEvaluated = 968;
  
  public static final int NullNotCompatibleToFreeTypeVariable = 969;
  
  public static final int NullityMismatchAgainstFreeTypeVariable = 970;
  
  public static final int ImplicitObjectBoundNoNullDefault = 971;
  
  public static final int IllegalParameterNullityRedefinition = 67109836;
  
  public static final int ContradictoryNullAnnotationsInferredFunctionType = 67109837;
  
  public static final int IllegalReturnNullityRedefinitionFreeTypeVariable = 67109838;
  
  public static final int IllegalRedefinitionOfTypeVariable = 975;
  
  public static final int UncheckedAccessOfValueOfFreeTypeVariable = 976;
  
  public static final int UninitializedFreeTypeVariableField = 977;
  
  public static final int UninitializedFreeTypeVariableFieldHintMissingDefault = 978;
  
  public static final int RequiredNonNullButProvidedFreeTypeVariable = 16778195;
  
  public static final int NonNullTypeVariableFromLegacyMethod = 16778196;
  
  public static final int NonNullMethodTypeVariableFromLegacyMethod = 16778197;
  
  public static final int MissingNullAnnotationImplicitlyUsed = 536871894;
  
  public static final int AnnotatedTypeArgumentToUnannotated = 536871895;
  
  public static final int AnnotatedTypeArgumentToUnannotatedSuperHint = 536871896;
  
  public static final int NonNullArrayContentNotInitialized = 536871897;
  
  public static final int IllegalModifiersForElidedType = 536871913;
  
  public static final int IllegalModifiers = 536871914;
  
  public static final int IllegalTypeArgumentsInRawConstructorReference = 16778219;
  
  public static final int MissingValueFromLambda = 536871916;
  
  public static final int IllegalModifierForInterfaceMethod18 = 67109914;
  
  public static final int DefaultMethodOverridesObjectMethod = 67109915;
  
  public static final int InheritedDefaultMethodConflictsWithOtherInherited = 67109916;
  
  public static final int DuplicateInheritedDefaultMethods = 67109917;
  
  public static final int SuperAccessCannotBypassDirectSuper = 16778270;
  
  public static final int SuperCallCannotBypassOverride = 67109919;
  
  public static final int IllegalModifierCombinationForInterfaceMethod = 67109920;
  
  public static final int IllegalStrictfpForAbstractInterfaceMethod = 67109921;
  
  public static final int IllegalDefaultModifierSpecification = 67109922;
  
  public static final int CannotInferInvocationType = 16778275;
  
  public static final int TypeAnnotationAtQualifiedName = 1610613796;
  
  public static final int NullAnnotationAtQualifyingType = 1610613797;
  
  public static final int IllegalModifierForInterfaceMethod9 = 67109935;
  
  public static final int IllegalModifierCombinationForPrivateInterfaceMethod9 = 67109934;
  
  public static final int UndefinedModule = 8389908;
  
  public static final int DuplicateRequires = 8389909;
  
  public static final int DuplicateExports = 8389910;
  
  public static final int DuplicateUses = 8389911;
  
  public static final int DuplicateServices = 8389912;
  
  public static final int CyclicModuleDependency = 8389913;
  
  public static final int AbstractServiceImplementation = 16778522;
  
  public static final int ProviderMethodOrConstructorRequiredForServiceImpl = 16778523;
  
  public static final int ServiceImplDefaultConstructorNotPublic = 16778524;
  
  public static final int NestedServiceImpl = 16778525;
  
  public static final int ServiceImplNotDefinedByModule = 16778526;
  
  public static final int PackageDoesNotExistOrIsEmpty = 8389919;
  
  public static final int NonDenotableTypeArgumentForAnonymousDiamond = 16778528;
  
  public static final int DuplicateOpens = 8389921;
  
  public static final int DuplicateModuleRef = 8389922;
  
  public static final int InvalidOpensStatement = 8389923;
  
  public static final int InvalidServiceIntfType = 8389924;
  
  public static final int InvalidServiceImplType = 8389925;
  
  public static final int IllegalModifierForModule = 8389926;
  
  public static final int UndefinedModuleAddReads = 8389927;
  
  public static final int ExportingForeignPackage = 8389928;
  
  public static final int DuplicateResource = 536872163;
  
  public static final int UsingTerminallyDeprecatedType = 16778616;
  
  public static final int UsingTerminallyDeprecatedMethod = 67110265;
  
  public static final int UsingTerminallyDeprecatedConstructor = 67110266;
  
  public static final int UsingTerminallyDeprecatedField = 33555835;
  
  public static final int OverridingTerminallyDeprecatedMethod = 67110268;
  
  public static final int UsingDeprecatedSinceVersionType = 16778621;
  
  public static final int UsingDeprecatedSinceVersionMethod = 67110270;
  
  public static final int UsingDeprecatedSinceVersionConstructor = 67110271;
  
  public static final int UsingDeprecatedSinceVersionField = 33555840;
  
  public static final int OverridingDeprecatedSinceVersionMethod = 67110273;
  
  public static final int UsingTerminallyDeprecatedSinceVersionType = 16778626;
  
  public static final int UsingTerminallyDeprecatedSinceVersionMethod = 67110275;
  
  public static final int UsingTerminallyDeprecatedSinceVersionConstructor = 67110276;
  
  public static final int UsingTerminallyDeprecatedSinceVersionField = 33555845;
  
  public static final int OverridingTerminallyDeprecatedSinceVersionMethod = 67110278;
  
  public static final int UsingDeprecatedPackage = 8390033;
  
  public static final int UsingDeprecatedSinceVersionPackage = 8390034;
  
  public static final int UsingTerminallyDeprecatedPackage = 8390035;
  
  public static final int UsingTerminallyDeprecatedSinceVersionPackage = 8390036;
  
  public static final int UsingDeprecatedModule = 8390037;
  
  public static final int UsingDeprecatedSinceVersionModule = 8390038;
  
  public static final int UsingTerminallyDeprecatedModule = 8390039;
  
  public static final int UsingTerminallyDeprecatedSinceVersionModule = 8390040;
  
  public static final int NotAccessibleType = 16778666;
  
  public static final int NotAccessibleField = 33555883;
  
  public static final int NotAccessibleMethod = 67110316;
  
  public static final int NotAccessibleConstructor = 67110317;
  
  public static final int NotAccessiblePackage = 268436910;
  
  public static final int ConflictingPackageFromModules = 8390063;
  
  public static final int ConflictingPackageFromOtherModules = 8390064;
  
  public static final int NonPublicTypeInAPI = 8390065;
  
  public static final int NotExportedTypeInAPI = 8390066;
  
  public static final int MissingRequiresTransitiveForTypeInAPI = 8390067;
  
  public static final int UnnamedPackageInNamedModule = 8390068;
  
  public static final int UnstableAutoModuleName = 8390069;
  
  public static final int ConflictingPackageInModules = 8390070;
  
  public static final int JavadocNotAccessibleType = -2130704982;
  
  public static final int RedundantNullDefaultAnnotationLocal = 536871974;
  
  public static final int RedundantNullDefaultAnnotationField = 536871975;
  
  public static final int GenericInferenceError = 1100;
  
  public static final int LambdaShapeComputationError = 1101;
  
  public static final int ProblemNotAnalysed = 1102;
  
  public static final int PreviewFeatureDisabled = 4195407;
  
  public static final int PreviewFeatureUsed = 4195408;
  
  public static final int PreviewFeatureNotSupported = 4195409;
  
  public static final int PreviewFeaturesNotAllowed = 2098258;
  
  public static final int FeatureNotSupported = 4195411;
  
  public static final int PreviewAPIUsed = 4195412;
  
  public static final int UnlikelyCollectionMethodArgumentType = 1200;
  
  public static final int UnlikelyEqualsArgumentType = 1201;
  
  public static final int VarLocalMultipleDeclarators = 1073743324;
  
  public static final int VarLocalCannotBeArray = 1073743325;
  
  public static final int VarLocalReferencesItself = 1073743326;
  
  public static final int VarLocalWithoutInitizalier = 1073743327;
  
  public static final int VarLocalInitializedToNull = 16778720;
  
  public static final int VarLocalInitializedToVoid = 16778721;
  
  public static final int VarLocalCannotBeArrayInitalizers = 16778722;
  
  public static final int VarLocalCannotBeLambda = 16778723;
  
  public static final int VarLocalCannotBeMethodReference = 16778724;
  
  public static final int VarIsReserved = 1073743333;
  
  public static final int VarIsReservedInFuture = 1073743334;
  
  public static final int VarIsNotAllowedHere = 1073743335;
  
  public static final int VarCannotBeMixedWithNonVarParams = 1073743336;
  
  public static final int SwitchExpressionsIncompatibleResultExpressionTypes = 16778816;
  
  public static final int SwitchExpressionsEmptySwitchBlock = 536872513;
  
  public static final int SwitchExpressionsNoResultExpression = 16778818;
  
  public static final int SwitchExpressionSwitchLabeledBlockCompletesNormally = 536872515;
  
  public static final int SwitchExpressionLastStatementCompletesNormally = 536872516;
  
  public static final int SwitchExpressionTrailingSwitchLabels = 536872517;
  
  public static final int switchMixedCase = 1073743430;
  
  public static final int SwitchExpressionMissingDefaultCase = 536872519;
  
  public static final int SwitchExpressionBreakMissingValue = 536872522;
  
  public static final int SwitchExpressionMissingEnumConstantCase = 536872523;
  
  public static final int SwitchExpressionIllegalLastStatement = 536872524;
  
  public static final int SwitchExpressionsYieldIncompatibleResultExpressionTypes = 16778916;
  
  public static final int SwitchExpressionsYieldEmptySwitchBlock = 1073743525;
  
  public static final int SwitchExpressionsYieldNoResultExpression = 536872614;
  
  public static final int SwitchExpressionaYieldSwitchLabeledBlockCompletesNormally = 536872615;
  
  public static final int SwitchExpressionsYieldLastStatementCompletesNormally = 536872616;
  
  public static final int SwitchExpressionsYieldTrailingSwitchLabels = 536872617;
  
  public static final int SwitchPreviewMixedCase = 1073743530;
  
  public static final int SwitchExpressionsYieldMissingDefaultCase = 1073743531;
  
  public static final int SwitchExpressionsYieldMissingValue = 1073743532;
  
  public static final int SwitchExpressionsYieldMissingEnumConstantCase = 1073743533;
  
  public static final int SwitchExpressionsYieldIllegalLastStatement = 536872622;
  
  public static final int SwitchExpressionsYieldBreakNotAllowed = 1073743535;
  
  public static final int SwitchExpressionsYieldUnqualifiedMethodWarning = 1073743536;
  
  public static final int SwitchExpressionsYieldUnqualifiedMethodError = 1073743537;
  
  public static final int SwitchExpressionsYieldOutsideSwitchExpression = 1073743538;
  
  public static final int SwitchExpressionsYieldRestrictedGeneralWarning = 536872627;
  
  public static final int SwitchExpressionsYieldIllegalStatement = 536872628;
  
  public static final int SwitchExpressionsYieldTypeDeclarationWarning = 536872629;
  
  public static final int SwitchExpressionsYieldTypeDeclarationError = 536872630;
  
  public static final int MultiConstantCaseLabelsNotSupported = 1073743543;
  
  public static final int ArrowInCaseStatementsNotSupported = 1073743544;
  
  public static final int SwitchExpressionsNotSupported = 1073743545;
  
  public static final int SwitchExpressionsBreakOutOfSwitchExpression = 1073743546;
  
  public static final int SwitchExpressionsContinueOutOfSwitchExpression = 1073743547;
  
  public static final int SwitchExpressionsReturnWithinSwitchExpression = 1073743548;
  
  public static final int RecordIllegalModifierForInnerRecord = 16778946;
  
  public static final int RecordIllegalModifierForRecord = 16778947;
  
  public static final int RecordIllegalComponentNameInRecord = 16778948;
  
  public static final int RecordNonStaticFieldDeclarationInRecord = 16778949;
  
  public static final int RecordAccessorMethodHasThrowsClause = 16778950;
  
  public static final int RecordCanonicalConstructorHasThrowsClause = 16778951;
  
  public static final int RecordCanonicalConstructorVisibilityReduced = 16778952;
  
  public static final int RecordMultipleCanonicalConstructors = 16778953;
  
  public static final int RecordCompactConstructorHasReturnStatement = 16778954;
  
  public static final int RecordDuplicateComponent = 16778955;
  
  public static final int RecordIllegalNativeModifierInRecord = 16778956;
  
  public static final int RecordInstanceInitializerBlockInRecord = 16778957;
  
  public static final int RestrictedTypeName = 16778958;
  
  public static final int RecordIllegalAccessorReturnType = 16778959;
  
  public static final int RecordAccessorMethodShouldNotBeGeneric = 16778960;
  
  public static final int RecordAccessorMethodShouldBePublic = 16778961;
  
  public static final int RecordCanonicalConstructorShouldNotBeGeneric = 16778962;
  
  public static final int RecordCanonicalConstructorHasReturnStatement = 16778963;
  
  public static final int RecordCanonicalConstructorHasExplicitConstructorCall = 16778964;
  
  public static final int RecordCompactConstructorHasExplicitConstructorCall = 16778965;
  
  public static final int RecordNestedRecordInherentlyStatic = 16778966;
  
  public static final int RecordAccessorMethodShouldNotBeStatic = 16778967;
  
  public static final int RecordCannotExtendRecord = 16778968;
  
  public static final int RecordComponentCannotBeVoid = 16778969;
  
  public static final int RecordIllegalVararg = 16778970;
  
  public static final int RecordStaticReferenceToOuterLocalVariable = 16778971;
  
  public static final int RecordCannotDefineRecordInLocalType = 16778972;
  
  public static final int RecordComponentsCannotHaveModifiers = 16778973;
  
  public static final int RecordIllegalParameterNameInCanonicalConstructor = 16778974;
  
  public static final int RecordIllegalExplicitFinalFieldAssignInCompactConstructor = 16778975;
  
  public static final int RecordMissingExplicitConstructorCallInNonCanonicalConstructor = 16778976;
  
  public static final int RecordIllegalStaticModifierForLocalClassOrInterface = 16778977;
  
  public static final int RecordIllegalModifierForLocalRecord = 16778978;
  
  public static final int RecordIllegalExtendedDimensionsForRecordComponent = 1610614499;
  
  public static final int SafeVarargsOnSyntheticRecordAccessor = 16778980;
  
  public static final int LocalStaticsIllegalVisibilityModifierForInterfaceLocalType = 16778981;
  
  public static final int IllegalModifierForLocalEnumDeclaration = 16778982;
  
  public static final int ClassExtendFinalRecord = 16778983;
  
  public static final int RecordErasureIncompatibilityInCanonicalConstructor = 16778984;
  
  public static final int PatternVariableNotInScope = 2098932;
  
  public static final int PatternVariableRedefined = 536872693;
  
  public static final int PatternSubtypeOfExpression = 536872694;
  
  public static final int IllegalModifierForPatternVariable = 536872695;
  
  public static final int PatternVariableRedeclared = 536872696;
  
  public static final int DiscouragedValueBasedTypeSynchronization = 536872732;
  
  public static final int SealedMissingClassModifier = 16779066;
  
  public static final int SealedDisAllowedNonSealedModifierInClass = 16779067;
  
  public static final int SealedSuperClassDoesNotPermit = 16779068;
  
  public static final int SealedSuperInterfaceDoesNotPermit = 16779069;
  
  public static final int SealedMissingSealedModifier = 16779070;
  
  public static final int SealedMissingInterfaceModifier = 16779071;
  
  public static final int SealedDuplicateTypeInPermits = 16779072;
  
  public static final int SealedNotDirectSuperClass = 16779073;
  
  public static final int SealedPermittedTypeOutsideOfModule = 16779074;
  
  public static final int SealedPermittedTypeOutsideOfPackage = 16779075;
  
  public static final int SealedSealedTypeMissingPermits = 16779076;
  
  public static final int SealedInterfaceIsSealedAndNonSealed = 16779077;
  
  public static final int SealedDisAllowedNonSealedModifierInInterface = 16779078;
  
  public static final int SealedNotDirectSuperInterface = 16779079;
  
  public static final int SealedLocalDirectSuperTypeSealed = 16779080;
  
  public static final int SealedAnonymousClassCannotExtendSealedType = 16779081;
  
  public static final int SealedSuperTypeInDifferentPackage = 16779082;
  
  public static final int SealedSuperTypeDisallowed = 16779083;
  
  public static final int LocalReferencedInGuardMustBeEffectivelyFinal = 2099052;
  
  public static final int ConstantWithPatternIncompatible = 2099053;
  
  public static final int IllegalFallthroughToPattern = 2099054;
  
  public static final int OnlyOnePatternCaseLabelAllowed = 2099055;
  
  public static final int CannotMixPatternAndDefault = 2099056;
  
  public static final int CannotMixNullAndNonTypePattern = 2099057;
  
  public static final int PatternDominated = 2099058;
  
  public static final int IllegalTotalPatternWithDefault = 2099059;
  
  public static final int EnhancedSwitchMissingDefault = 2099060;
  
  public static final int DuplicateTotalPattern = 2099061;
  
  public static final int PatternSwitchNullOnlyOrFirstWithDefault = 2099072;
  
  public static final int PatternSwitchCaseDefaultOnlyAsSecond = 2099073;
  
  public static final int IllegalFallthroughFromAPattern = 2099074;
  
  public static final int UnnecessaryNullCaseInSwitchOverNonNull = 2099062;
  
  public static final int UnexpectedTypeinSwitchPattern = 2099063;
  
  public static final int UnexpectedTypeinRecordPattern = 2099064;
  
  public static final int RecordPatternMismatch = 2099065;
  
  public static final int PatternTypeMismatch = 2099066;
  
  public static final int RawTypeInRecordPattern = 2099067;
  
  public static final int CannotInferRecordPatternTypes = 2099092;
  
  String[] getArguments();
  
  int getID();
  
  String getMessage();
  
  char[] getOriginatingFileName();
  
  int getSourceEnd();
  
  int getSourceLineNumber();
  
  int getSourceStart();
  
  boolean isError();
  
  boolean isWarning();
  
  boolean isInfo();
  
  void setSourceEnd(int paramInt);
  
  void setSourceLineNumber(int paramInt);
  
  void setSourceStart(int paramInt);
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\core\compiler\IProblem.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */