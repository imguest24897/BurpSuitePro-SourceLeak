/*    */ package org.eclipse.jdt.internal.compiler.codegen;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CachedIndexEntry
/*    */ {
/*    */   public char[] signature;
/*    */   public int index;
/*    */   
/*    */   public CachedIndexEntry(char[] signature, int index) {
/* 21 */     this.signature = signature;
/* 22 */     this.index = index;
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\codegen\CachedIndexEntry.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */