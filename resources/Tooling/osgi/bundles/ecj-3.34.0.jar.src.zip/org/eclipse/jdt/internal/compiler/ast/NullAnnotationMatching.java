/*     */ package org.eclipse.jdt.internal.compiler.ast;
/*     */ 
/*     */ import org.eclipse.jdt.internal.compiler.flow.FlowContext;
/*     */ import org.eclipse.jdt.internal.compiler.flow.FlowInfo;
/*     */ import org.eclipse.jdt.internal.compiler.impl.CompilerOptions;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.AnnotationBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.ArrayBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.BinaryTypeBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.Binding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.BlockScope;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.CaptureBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.InvocationSite;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.LookupEnvironment;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.MethodBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.ParameterizedTypeBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.ProblemMethodBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.RawTypeBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.ReferenceBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.Scope;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.Substitution;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.TypeBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.TypeBindingVisitor;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.TypeVariableBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.VariableBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.WildcardBinding;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class NullAnnotationMatching
/*     */ {
/*  55 */   public static final NullAnnotationMatching NULL_ANNOTATIONS_OK = new NullAnnotationMatching(Severity.OK, 1, null);
/*  56 */   public static final NullAnnotationMatching NULL_ANNOTATIONS_OK_NONNULL = new NullAnnotationMatching(Severity.OK, 4, null);
/*  57 */   public static final NullAnnotationMatching NULL_ANNOTATIONS_UNCHECKED = new NullAnnotationMatching(Severity.UNCHECKED, 1, null); private final Severity severity; public final TypeBinding superTypeHint;
/*  58 */   public static final NullAnnotationMatching NULL_ANNOTATIONS_MISMATCH = new NullAnnotationMatching(Severity.MISMATCH, 1, null);
/*     */   public final int nullStatus;
/*     */   
/*  61 */   public enum CheckMode { COMPATIBLE
/*     */     {
/*     */       boolean requiredNullableMatchesAll() {
/*  64 */         return true;
/*     */       }
/*     */     },
/*  67 */     EXACT,
/*     */     
/*  69 */     BOUND_CHECK,
/*     */     
/*  71 */     BOUND_SUPER_CHECK,
/*     */     
/*  73 */     OVERRIDE_RETURN
/*     */     {
/*     */       CheckMode toDetail() {
/*  76 */         return OVERRIDE;
/*     */       }
/*     */     },
/*  79 */     OVERRIDE
/*     */     {
/*     */       boolean requiredNullableMatchesAll() {
/*  82 */         return true;
/*     */       }
/*     */       CheckMode toDetail() {
/*  85 */         return OVERRIDE;
/*     */       }
/*     */     };
/*     */     
/*     */     boolean requiredNullableMatchesAll() {
/*  90 */       return false;
/*     */     }
/*     */     CheckMode toDetail() {
/*  93 */       return EXACT;
/*     */     } }
/*     */ 
/*     */   
/*     */   private enum Severity {
/*  98 */     OK,
/*     */     
/* 100 */     LEGACY_WARNING,
/*     */     
/* 102 */     UNCHECKED,
/*     */     
/* 104 */     UNCHECKED_TO_UNANNOTATED,
/*     */     
/* 106 */     MISMATCH;
/*     */ 
/*     */     
/*     */     public Severity max(Severity severity) {
/* 110 */       if (compareTo(severity) < 0)
/* 111 */         return severity; 
/* 112 */       return this;
/*     */     }
/*     */     
/*     */     public boolean isAnyMismatch() {
/* 116 */       return (compareTo(LEGACY_WARNING) > 0);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   NullAnnotationMatching(Severity severity, int nullStatus, TypeBinding superTypeHint) {
/* 127 */     this.severity = severity;
/* 128 */     this.superTypeHint = superTypeHint;
/* 129 */     this.nullStatus = nullStatus;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public NullAnnotationMatching withNullStatus(int updatedNullStatus) {
/* 136 */     return (updatedNullStatus == this.nullStatus) ? this : 
/* 137 */       new NullAnnotationMatching(this.severity, updatedNullStatus, this.superTypeHint);
/*     */   }
/*     */   
/* 140 */   public boolean isAnyMismatch() { return this.severity.isAnyMismatch(); }
/* 141 */   public boolean isUnchecked() { return !(this.severity != Severity.UNCHECKED && this.severity != Severity.UNCHECKED_TO_UNANNOTATED); }
/* 142 */   public boolean isAnnotatedToUnannotated() { return (this.severity == Severity.UNCHECKED_TO_UNANNOTATED); }
/* 143 */   public boolean isDefiniteMismatch() { return (this.severity == Severity.MISMATCH); } public boolean wantToReport() {
/* 144 */     return (this.severity == Severity.LEGACY_WARNING);
/*     */   }
/*     */   public boolean isPotentiallyNullMismatch() {
/* 147 */     return (!isDefiniteMismatch() && this.nullStatus != -1 && (this.nullStatus & 0x10) != 0);
/*     */   }
/*     */   
/*     */   public String superTypeHintName(CompilerOptions options, boolean shortNames) {
/* 151 */     return String.valueOf(this.superTypeHint.nullAnnotatedReadableName(options, shortNames));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int checkAssignment(BlockScope currentScope, FlowContext flowContext, VariableBinding var, FlowInfo flowInfo, int nullStatus, Expression expression, TypeBinding providedType) {
/* 158 */     if (providedType == null) return 1; 
/* 159 */     long lhsTagBits = 0L;
/* 160 */     boolean hasReported = false;
/* 161 */     boolean usesNullTypeAnnotations = currentScope.environment().usesNullTypeAnnotations();
/* 162 */     if (!usesNullTypeAnnotations) {
/* 163 */       lhsTagBits = var.tagBits & 0x180000000000000L;
/*     */     } else {
/* 165 */       if (expression instanceof ConditionalExpression && expression.isPolyExpression()) {
/*     */         
/* 167 */         ConditionalExpression ce = (ConditionalExpression)expression;
/* 168 */         int status1 = checkAssignment(currentScope, flowContext, var, flowInfo, ce.ifTrueNullStatus, ce.valueIfTrue, ce.valueIfTrue.resolvedType);
/* 169 */         int status2 = checkAssignment(currentScope, flowContext, var, flowInfo, ce.ifFalseNullStatus, ce.valueIfFalse, ce.valueIfFalse.resolvedType);
/* 170 */         if (status1 == status2)
/* 171 */           return status1; 
/* 172 */         return nullStatus;
/* 173 */       }  if (expression instanceof SwitchExpression && expression.isPolyExpression()) {
/*     */         int j;
/* 175 */         SwitchExpression se = (SwitchExpression)expression;
/* 176 */         Expression[] resExprs = se.resultExpressions.<Expression>toArray(new Expression[0]);
/* 177 */         Expression re = resExprs[0];
/* 178 */         int status0 = checkAssignment(currentScope, flowContext, var, flowInfo, re.nullStatus(flowInfo, flowContext), re, re.resolvedType);
/* 179 */         boolean identicalStatus = true;
/* 180 */         for (int i = 1, l = resExprs.length; i < l; i++) {
/* 181 */           re = resExprs[i];
/* 182 */           int otherStatus = checkAssignment(currentScope, flowContext, var, flowInfo, re.nullStatus(flowInfo, flowContext), re, re.resolvedType);
/* 183 */           j = identicalStatus & ((status0 == otherStatus) ? 1 : 0);
/*     */         } 
/* 185 */         return (j != 0) ? status0 : nullStatus;
/*     */       } 
/* 187 */       lhsTagBits = var.type.tagBits & 0x180000000000000L;
/* 188 */       NullAnnotationMatching annotationStatus = analyse(var.type, providedType, null, null, nullStatus, expression, CheckMode.COMPATIBLE);
/* 189 */       if (annotationStatus.isAnyMismatch()) {
/* 190 */         flowContext.recordNullityMismatch(currentScope, expression, providedType, var.type, flowInfo, nullStatus, annotationStatus);
/* 191 */         hasReported = true;
/*     */       } else {
/* 193 */         if (annotationStatus.wantToReport())
/* 194 */           annotationStatus.report((Scope)currentScope); 
/* 195 */         if (annotationStatus.nullStatus != 1) {
/* 196 */           return annotationStatus.nullStatus;
/*     */         }
/*     */       } 
/*     */     } 
/* 200 */     if (lhsTagBits == 72057594037927936L && nullStatus != 4) {
/* 201 */       if (!hasReported)
/* 202 */         flowContext.recordNullityMismatch(currentScope, expression, providedType, var.type, flowInfo, nullStatus, null); 
/* 203 */       return 4;
/* 204 */     }  if (lhsTagBits == 36028797018963968L && nullStatus == 1) {
/* 205 */       if (usesNullTypeAnnotations && providedType.isTypeVariable() && (providedType.tagBits & 0x180000000000000L) == 0L)
/* 206 */         return 48; 
/* 207 */       return 24;
/*     */     } 
/* 209 */     return nullStatus;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static NullAnnotationMatching analyse(TypeBinding requiredType, TypeBinding providedType, int nullStatus) {
/* 220 */     return analyse(requiredType, providedType, null, null, nullStatus, null, CheckMode.COMPATIBLE);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static NullAnnotationMatching analyse(TypeBinding requiredType, TypeBinding providedType, TypeBinding providedSubstitute, Substitution substitution, int nullStatus, Expression providedExpression, CheckMode mode) {
/* 237 */     if (!requiredType.enterRecursiveFunction())
/* 238 */       return NULL_ANNOTATIONS_OK; 
/*     */     try {
/* 240 */       Severity severity = Severity.OK;
/* 241 */       TypeBinding superTypeHint = null;
/* 242 */       TypeBinding originalRequiredType = requiredType;
/* 243 */       NullAnnotationMatching okStatus = NULL_ANNOTATIONS_OK;
/* 244 */       if (areSameTypes(requiredType, providedType, providedSubstitute)) {
/* 245 */         if ((requiredType.tagBits & 0x100000000000000L) != 0L)
/* 246 */           return okNonNullStatus(providedExpression); 
/* 247 */         return okStatus;
/*     */       } 
/* 249 */       if (requiredType instanceof TypeVariableBinding && substitution != null && (mode == CheckMode.EXACT || mode == CheckMode.COMPATIBLE || mode == CheckMode.BOUND_SUPER_CHECK)) {
/* 250 */         requiredType.exitRecursiveFunction();
/* 251 */         requiredType = Scope.substitute(substitution, requiredType);
/* 252 */         if (!requiredType.enterRecursiveFunction())
/* 253 */           return NULL_ANNOTATIONS_OK; 
/* 254 */         if (areSameTypes(requiredType, providedType, providedSubstitute)) {
/* 255 */           if ((requiredType.tagBits & 0x100000000000000L) != 0L)
/* 256 */             return okNonNullStatus(providedExpression); 
/* 257 */           return okStatus;
/*     */         } 
/*     */       } 
/* 260 */       if (mode == CheckMode.BOUND_CHECK && requiredType instanceof TypeVariableBinding) {
/* 261 */         boolean passedBoundCheck = (substitution instanceof ParameterizedTypeBinding && (((ParameterizedTypeBinding)substitution).tagBits & 0x400000L) != 0L);
/* 262 */         if (!passedBoundCheck) {
/*     */           
/* 264 */           ReferenceBinding referenceBinding = requiredType.superclass();
/* 265 */           if (referenceBinding != null && (referenceBinding.hasNullTypeAnnotations() || substitution != null)) {
/* 266 */             NullAnnotationMatching status = analyse((TypeBinding)referenceBinding, providedType, null, substitution, nullStatus, providedExpression, CheckMode.BOUND_SUPER_CHECK);
/* 267 */             severity = severity.max(status.severity);
/* 268 */             if (severity == Severity.MISMATCH)
/* 269 */               return new NullAnnotationMatching(severity, nullStatus, superTypeHint); 
/*     */           } 
/* 271 */           ReferenceBinding[] arrayOfReferenceBinding = requiredType.superInterfaces();
/* 272 */           if (arrayOfReferenceBinding != null)
/* 273 */             for (int i = 0; i < arrayOfReferenceBinding.length; i++) {
/* 274 */               if (arrayOfReferenceBinding[i].hasNullTypeAnnotations() || substitution != null) {
/* 275 */                 NullAnnotationMatching status = analyse((TypeBinding)arrayOfReferenceBinding[i], providedType, null, substitution, nullStatus, providedExpression, CheckMode.BOUND_SUPER_CHECK);
/* 276 */                 severity = severity.max(status.severity);
/* 277 */                 if (severity == Severity.MISMATCH) {
/* 278 */                   return new NullAnnotationMatching(severity, nullStatus, superTypeHint);
/*     */                 }
/*     */               } 
/*     */             }  
/*     */         } 
/*     */       } 
/* 284 */       if (requiredType instanceof ArrayBinding) {
/* 285 */         long[] requiredDimsTagBits = ((ArrayBinding)requiredType).nullTagBitsPerDimension;
/* 286 */         if (requiredDimsTagBits != null) {
/* 287 */           int dims = requiredType.dimensions();
/* 288 */           if (requiredType.dimensions() == providedType.dimensions()) {
/* 289 */             long[] providedDimsTagBits = ((ArrayBinding)providedType).nullTagBitsPerDimension;
/* 290 */             if (providedDimsTagBits == null)
/* 291 */               providedDimsTagBits = new long[dims + 1]; 
/* 292 */             int currentNullStatus = nullStatus;
/* 293 */             for (int i = 0; i <= dims; i++) {
/* 294 */               long requiredBits = validNullTagBits(requiredDimsTagBits[i]);
/* 295 */               long providedBits = validNullTagBits(providedDimsTagBits[i]);
/* 296 */               if (i == 0 && requiredBits == 36028797018963968L && nullStatus != -1 && mode.requiredNullableMatchesAll()) {
/*     */                 
/* 298 */                 if (nullStatus == 2)
/*     */                   break; 
/*     */               } else {
/* 301 */                 if (i > 0)
/* 302 */                   currentNullStatus = -1; 
/* 303 */                 Severity dimSeverity = computeNullProblemSeverity(requiredBits, providedBits, currentNullStatus, (i == 0) ? mode : mode.toDetail(), null);
/* 304 */                 if (i > 0 && dimSeverity == Severity.UNCHECKED && 
/* 305 */                   providedExpression instanceof ArrayAllocationExpression && 
/* 306 */                   providedBits == 0L && requiredBits != 0L) {
/*     */                   
/* 308 */                   Expression[] dimensions = ((ArrayAllocationExpression)providedExpression).dimensions;
/* 309 */                   Expression previousDim = dimensions[i - 1];
/* 310 */                   if (previousDim instanceof IntLiteral && previousDim.constant.intValue() == 0) {
/* 311 */                     dimSeverity = Severity.OK;
/* 312 */                     nullStatus = -1;
/*     */                     break;
/*     */                   } 
/*     */                 } 
/* 316 */                 severity = severity.max(dimSeverity);
/* 317 */                 if (severity == Severity.MISMATCH) {
/* 318 */                   if (nullStatus == 2)
/* 319 */                     return new NullAnnotationMatching(severity, nullStatus, null); 
/* 320 */                   return NULL_ANNOTATIONS_MISMATCH;
/*     */                 } 
/*     */               } 
/* 323 */               if (severity == Severity.OK)
/* 324 */                 nullStatus = -1; 
/*     */             } 
/* 326 */           } else if (providedType.id == 12 && 
/* 327 */             dims > 0 && requiredDimsTagBits[0] == 72057594037927936L) {
/* 328 */             return NULL_ANNOTATIONS_MISMATCH;
/*     */           } 
/*     */         } 
/* 331 */       } else if (requiredType.hasNullTypeAnnotations() || providedType.hasNullTypeAnnotations() || requiredType.isTypeVariable()) {
/* 332 */         long requiredBits = requiredNullTagBits(requiredType, mode);
/* 333 */         if (requiredBits != 36028797018963968L || nullStatus == -1 || !mode.requiredNullableMatchesAll()) {
/*     */ 
/*     */           
/* 336 */           long providedBits = providedNullTagBits(providedType);
/* 337 */           Severity s = computeNullProblemSeverity(requiredBits, providedBits, nullStatus, mode, originalRequiredType);
/* 338 */           if (s.isAnyMismatch() && requiredType.isWildcard() && requiredBits != 0L && (
/* 339 */             (WildcardBinding)requiredType).determineNullBitsFromDeclaration(null, null) == 0L) {
/* 340 */             TypeVariableBinding typeVariable = ((WildcardBinding)requiredType).typeVariable();
/* 341 */             if ((typeVariable.tagBits & 0x180000000000000L) != 0L)
/*     */             {
/* 343 */               s = Severity.OK;
/*     */             }
/*     */           } 
/*     */           
/* 347 */           severity = severity.max(s);
/* 348 */           if (!severity.isAnyMismatch() && (providedBits & 0x180000000000000L) == 72057594037927936L)
/* 349 */             okStatus = okNonNullStatus(providedExpression); 
/*     */         } 
/* 351 */         if (severity != Severity.MISMATCH && nullStatus != 2) {
/* 352 */           TypeBinding providedSuper = providedType.findSuperTypeOriginatingFrom(requiredType);
/* 353 */           TypeBinding providedSubstituteSuper = (providedSubstitute != null) ? providedSubstitute.findSuperTypeOriginatingFrom(requiredType) : null;
/* 354 */           if (severity == Severity.UNCHECKED && requiredType.isTypeVariable() && providedType.isTypeVariable() && (providedSuper == requiredType || providedSubstituteSuper == requiredType)) {
/* 355 */             severity = Severity.OK;
/*     */           }
/* 357 */           if (providedSuper != providedType)
/* 358 */             superTypeHint = providedSuper; 
/* 359 */           if (requiredType.isParameterizedType() && providedSuper instanceof ParameterizedTypeBinding) {
/* 360 */             TypeBinding[] requiredArguments = ((ParameterizedTypeBinding)requiredType).arguments;
/* 361 */             TypeBinding[] providedArguments = ((ParameterizedTypeBinding)providedSuper).arguments;
/* 362 */             TypeBinding[] providedSubstitutes = (providedSubstituteSuper instanceof ParameterizedTypeBinding) ? ((ParameterizedTypeBinding)providedSubstituteSuper).arguments : null;
/* 363 */             if (requiredArguments != null && providedArguments != null && requiredArguments.length == providedArguments.length)
/* 364 */               for (int i = 0; i < requiredArguments.length; i++) {
/* 365 */                 TypeBinding providedArgSubstitute = (providedSubstitutes != null) ? providedSubstitutes[i] : null;
/* 366 */                 NullAnnotationMatching status = analyse(requiredArguments[i], providedArguments[i], providedArgSubstitute, substitution, -1, providedExpression, mode.toDetail());
/* 367 */                 severity = severity.max(status.severity);
/* 368 */                 if (severity == Severity.MISMATCH) {
/* 369 */                   return new NullAnnotationMatching(severity, nullStatus, superTypeHint);
/*     */                 }
/*     */               }  
/*     */           } 
/* 373 */           ReferenceBinding referenceBinding1 = requiredType.enclosingType();
/* 374 */           ReferenceBinding referenceBinding2 = providedType.enclosingType();
/* 375 */           if (referenceBinding1 != null && referenceBinding2 != null) {
/* 376 */             ReferenceBinding referenceBinding = (providedSubstitute != null) ? providedSubstitute.enclosingType() : null;
/* 377 */             NullAnnotationMatching status = analyse((TypeBinding)referenceBinding1, (TypeBinding)referenceBinding2, (TypeBinding)referenceBinding, substitution, -1, providedExpression, mode);
/* 378 */             severity = severity.max(status.severity);
/*     */           } 
/*     */         } 
/*     */       } 
/* 382 */       if (!severity.isAnyMismatch())
/* 383 */         return okStatus; 
/* 384 */       return new NullAnnotationMatching(severity, nullStatus, superTypeHint);
/*     */     } finally {
/* 386 */       requiredType.exitRecursiveFunction();
/*     */     } 
/*     */   }
/*     */   
/*     */   public void report(Scope scope) {}
/*     */   
/*     */   public static NullAnnotationMatching okNonNullStatus(final Expression providedExpression) {
/* 393 */     if (providedExpression instanceof MessageSend) {
/* 394 */       final MethodBinding method = ((MessageSend)providedExpression).binding;
/* 395 */       if (method != null && method.isValidBinding()) {
/* 396 */         MethodBinding originalMethod = method.original();
/* 397 */         ReferenceBinding referenceBinding = originalMethod.declaringClass;
/* 398 */         if (referenceBinding instanceof BinaryTypeBinding && 
/* 399 */           ((BinaryTypeBinding)referenceBinding).externalAnnotationStatus.isPotentiallyUnannotatedLib() && 
/* 400 */           originalMethod.returnType.isTypeVariable() && (
/* 401 */           originalMethod.returnType.tagBits & 0x180000000000000L) == 0L) {
/*     */           
/* 403 */           final int severity = (((BinaryTypeBinding)referenceBinding).externalAnnotationStatus == BinaryTypeBinding.ExternalAnnotationStatus.NO_EEA_FILE) ? 
/* 404 */             0 : 1024;
/* 405 */           return new NullAnnotationMatching(Severity.LEGACY_WARNING, 1, null)
/*     */             {
/*     */               public void report(Scope scope) {
/* 408 */                 scope.problemReporter().nonNullTypeVariableInUnannotatedBinary(scope.environment(), method, providedExpression, severity);
/*     */               }
/*     */             };
/*     */         } 
/*     */       } 
/*     */     } 
/* 414 */     return NULL_ANNOTATIONS_OK_NONNULL;
/*     */   }
/*     */ 
/*     */   
/*     */   protected static boolean areSameTypes(TypeBinding requiredType, TypeBinding providedType, TypeBinding providedSubstitute) {
/* 419 */     if (requiredType == providedType)
/* 420 */       return true; 
/* 421 */     if (requiredType.isParameterizedType() || requiredType.isArrayType())
/* 422 */       return false; 
/* 423 */     if (TypeBinding.notEquals(requiredType, providedType)) {
/* 424 */       if (requiredType instanceof CaptureBinding)
/*     */       
/* 426 */       { TypeBinding lowerBound = ((CaptureBinding)requiredType).lowerBound;
/* 427 */         if (lowerBound != null && areSameTypes(lowerBound, providedType, providedSubstitute))
/* 428 */           return ((requiredType.tagBits & 0x180000000000000L) == (providedType.tagBits & 0x180000000000000L));  }
/* 429 */       else { if (requiredType.kind() == 4100 && requiredType == providedSubstitute)
/* 430 */           return true; 
/* 431 */         if (providedType instanceof CaptureBinding) {
/*     */           
/* 433 */           TypeBinding upperBound = ((CaptureBinding)providedType).upperBound();
/* 434 */           if (upperBound != null && areSameTypes(requiredType, upperBound, providedSubstitute))
/* 435 */             return ((requiredType.tagBits & 0x180000000000000L) == (providedType.tagBits & 0x180000000000000L)); 
/*     */         }  }
/* 437 */        return false;
/*     */     } 
/* 439 */     return ((requiredType.tagBits & 0x180000000000000L) == (providedType.tagBits & 0x180000000000000L));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static long requiredNullTagBits(TypeBinding type, CheckMode mode) {
/* 446 */     long tagBits = type.tagBits & 0x180000000000000L;
/* 447 */     if (tagBits != 0L) {
/* 448 */       return validNullTagBits(tagBits);
/*     */     }
/* 450 */     if (type.isWildcard()) {
/* 451 */       WildcardBinding wildcardBinding = (WildcardBinding)type;
/* 452 */       TypeBinding bound = wildcardBinding.bound;
/* 453 */       tagBits = (bound != null) ? (bound.tagBits & 0x180000000000000L) : 0L;
/* 454 */       switch (wildcardBinding.boundKind) {
/*     */         case 2:
/* 456 */           if (tagBits == 36028797018963968L)
/* 457 */             return 36028797018963968L; 
/*     */           break;
/*     */         case 1:
/* 460 */           if (tagBits == 72057594037927936L)
/* 461 */             return tagBits; 
/*     */           break;
/*     */       } 
/* 464 */       return 108086391056891904L;
/*     */     } 
/*     */     
/* 467 */     if (type.isTypeVariable()) {
/*     */ 
/*     */       
/* 470 */       if (type.isCapture()) {
/* 471 */         TypeBinding lowerBound = ((CaptureBinding)type).lowerBound;
/* 472 */         if (lowerBound != null) {
/* 473 */           tagBits = lowerBound.tagBits & 0x180000000000000L;
/* 474 */           if (tagBits == 36028797018963968L)
/* 475 */             return 36028797018963968L; 
/*     */         } 
/*     */       } 
/* 478 */       switch (mode) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         case null:
/*     */         case BOUND_SUPER_CHECK:
/*     */         case OVERRIDE_RETURN:
/*     */         case OVERRIDE:
/* 489 */           return 0L;
/*     */       } 
/*     */       return 72057594037927936L;
/*     */     } 
/*     */   }
/*     */   
/*     */   static long providedNullTagBits(TypeBinding type) {
/* 496 */     long tagBits = type.tagBits & 0x180000000000000L;
/* 497 */     if (tagBits != 0L) {
/* 498 */       return validNullTagBits(tagBits);
/*     */     }
/* 500 */     if (type.isWildcard()) {
/* 501 */       return 108086391056891904L;
/*     */     }
/*     */     
/* 504 */     if (type.isTypeVariable()) {
/* 505 */       int i; TypeVariableBinding typeVariable = (TypeVariableBinding)type;
/* 506 */       boolean haveNullBits = false;
/* 507 */       if (typeVariable.isCapture()) {
/* 508 */         TypeBinding lowerBound = ((CaptureBinding)typeVariable).lowerBound;
/* 509 */         if (lowerBound != null) {
/* 510 */           tagBits = lowerBound.tagBits & 0x180000000000000L;
/* 511 */           if (tagBits == 36028797018963968L)
/* 512 */             return 36028797018963968L; 
/* 513 */           i = haveNullBits | ((tagBits != 0L) ? 1 : 0);
/*     */         } 
/*     */       } 
/* 516 */       if (typeVariable.firstBound != null) {
/* 517 */         long boundBits = typeVariable.firstBound.tagBits & 0x180000000000000L;
/* 518 */         if (boundBits == 72057594037927936L)
/* 519 */           return 72057594037927936L; 
/* 520 */         i |= (boundBits != 0L) ? 1 : 0;
/*     */       } 
/* 522 */       if (i != 0) {
/* 523 */         return 108086391056891904L;
/*     */       }
/*     */     } 
/* 526 */     return 0L;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int nullStatusFromExpressionType(TypeBinding type) {
/* 533 */     if (type.isFreeTypeVariable())
/* 534 */       return 48; 
/* 535 */     long bits = type.tagBits & 0x180000000000000L;
/* 536 */     if (bits == 0L)
/* 537 */       return 1; 
/* 538 */     if (bits == 72057594037927936L)
/* 539 */       return 4; 
/* 540 */     return 48;
/*     */   }
/*     */   
/*     */   public static long validNullTagBits(long bits) {
/* 544 */     bits &= 0x180000000000000L;
/* 545 */     return (bits == 108086391056891904L) ? 0L : bits;
/*     */   }
/*     */ 
/*     */   
/*     */   public static TypeBinding moreDangerousType(TypeBinding one, TypeBinding two) {
/* 550 */     if (one == null) return null; 
/* 551 */     long oneNullBits = validNullTagBits(one.tagBits);
/* 552 */     long twoNullBits = validNullTagBits(two.tagBits);
/* 553 */     if (oneNullBits != twoNullBits) {
/* 554 */       if (oneNullBits == 36028797018963968L)
/* 555 */         return one; 
/* 556 */       if (twoNullBits == 36028797018963968L) {
/* 557 */         return two;
/*     */       }
/* 559 */       if (oneNullBits == 0L)
/* 560 */         return one; 
/* 561 */       return two;
/* 562 */     }  if (one != two && 
/* 563 */       analyse(one, two, -1).isAnyMismatch()) {
/* 564 */       return two;
/*     */     }
/* 566 */     return one;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static Severity computeNullProblemSeverity(long requiredBits, long providedBits, int nullStatus, CheckMode mode, TypeBinding requiredType) {
/* 579 */     if (requiredBits == providedBits)
/* 580 */       return Severity.OK; 
/* 581 */     if (requiredBits == 0L)
/* 582 */     { switch (mode) {
/*     */         case EXACT:
/* 584 */           if (providedBits == 72057594037927936L && !(requiredType instanceof TypeVariableBinding))
/* 585 */             return Severity.UNCHECKED_TO_UNANNOTATED; 
/* 586 */           return Severity.OK;
/*     */         case COMPATIBLE:
/*     */         case null:
/*     */         case BOUND_SUPER_CHECK:
/* 590 */           return Severity.OK;
/*     */         case OVERRIDE_RETURN:
/* 592 */           if (providedBits == 72057594037927936L)
/* 593 */             return Severity.OK; 
/* 594 */           if (!(requiredType instanceof TypeVariableBinding))
/* 595 */             return Severity.OK; 
/* 596 */           return Severity.UNCHECKED;
/*     */         case OVERRIDE:
/* 598 */           return Severity.UNCHECKED;
/*     */       }  }
/* 600 */     else { if (requiredBits == 108086391056891904L) {
/* 601 */         if (mode == CheckMode.EXACT && providedBits == 72057594037927936L && 
/* 602 */           requiredType instanceof WildcardBinding) {
/* 603 */           WildcardBinding wildcard = (WildcardBinding)requiredType;
/*     */           
/* 605 */           if (wildcard.boundKind == 2 && providedBits == 72057594037927936L) {
/* 606 */             TypeBinding bound = wildcard.bound;
/* 607 */             if (bound != null && (bound.tagBits & 0x180000000000000L) != 0L)
/* 608 */               return Severity.OK; 
/* 609 */             return Severity.UNCHECKED_TO_UNANNOTATED;
/*     */           } 
/*     */         } 
/*     */         
/* 613 */         return Severity.OK;
/* 614 */       }  if (requiredBits == 72057594037927936L) {
/* 615 */         switch (mode) {
/*     */           case COMPATIBLE:
/* 617 */             if (nullStatus == 2) {
/* 618 */               return Severity.MISMATCH;
/*     */             }
/*     */           case BOUND_SUPER_CHECK:
/* 621 */             if (nullStatus == 4) {
/* 622 */               return Severity.OK;
/*     */             }
/*     */           case EXACT:
/*     */           case null:
/*     */           case OVERRIDE_RETURN:
/*     */           case OVERRIDE:
/* 628 */             if (providedBits == 0L)
/* 629 */               return Severity.UNCHECKED; 
/* 630 */             return Severity.MISMATCH;
/*     */         } 
/*     */       
/* 633 */       } else if (requiredBits == 36028797018963968L) {
/* 634 */         switch (mode) {
/*     */           case COMPATIBLE:
/*     */           case BOUND_SUPER_CHECK:
/*     */           case OVERRIDE_RETURN:
/* 638 */             return Severity.OK;
/*     */           case EXACT:
/*     */           case null:
/* 641 */             if (providedBits == 0L)
/* 642 */               return Severity.UNCHECKED; 
/* 643 */             return Severity.MISMATCH;
/*     */           case OVERRIDE:
/* 645 */             return Severity.MISMATCH;
/*     */         } 
/*     */       }  }
/* 648 */      return Severity.OK;
/*     */   }
/*     */   
/*     */   static class SearchContradictions extends TypeBindingVisitor {
/*     */     ReferenceBinding typeWithContradiction;
/*     */     
/*     */     public boolean visit(ReferenceBinding referenceBinding) {
/* 655 */       if ((referenceBinding.tagBits & 0x180000000000000L) == 108086391056891904L) {
/* 656 */         this.typeWithContradiction = referenceBinding;
/* 657 */         return false;
/*     */       } 
/* 659 */       return true;
/*     */     }
/*     */     
/*     */     public boolean visit(TypeVariableBinding typeVariable) {
/* 663 */       if (!visit((ReferenceBinding)typeVariable))
/* 664 */         return false; 
/* 665 */       long allNullBits = typeVariable.tagBits & 0x180000000000000L;
/* 666 */       if (typeVariable.firstBound != null)
/* 667 */         allNullBits = typeVariable.firstBound.tagBits & 0x180000000000000L;  byte b; int i; TypeBinding[] arrayOfTypeBinding;
/* 668 */       for (i = (arrayOfTypeBinding = typeVariable.otherUpperBounds()).length, b = 0; b < i; ) { TypeBinding otherBound = arrayOfTypeBinding[b];
/* 669 */         allNullBits |= otherBound.tagBits & 0x180000000000000L; b++; }
/* 670 */        if (allNullBits == 108086391056891904L) {
/* 671 */         this.typeWithContradiction = (ReferenceBinding)typeVariable;
/* 672 */         return false;
/*     */       } 
/* 674 */       return true;
/*     */     }
/*     */     
/*     */     public boolean visit(RawTypeBinding rawType) {
/* 678 */       return visit((ReferenceBinding)rawType);
/*     */     }
/*     */     
/*     */     public boolean visit(WildcardBinding wildcardBinding) {
/* 682 */       long allNullBits = wildcardBinding.tagBits & 0x180000000000000L;
/* 683 */       switch (wildcardBinding.boundKind) {
/*     */         case 1:
/* 685 */           allNullBits |= wildcardBinding.bound.tagBits & 0x100000000000000L;
/*     */           break;
/*     */         case 2:
/* 688 */           allNullBits |= wildcardBinding.bound.tagBits & 0x80000000000000L;
/*     */           break;
/*     */       } 
/* 691 */       if (allNullBits == 108086391056891904L) {
/* 692 */         this.typeWithContradiction = (ReferenceBinding)wildcardBinding;
/* 693 */         return false;
/*     */       } 
/* 695 */       return true;
/*     */     }
/*     */     
/*     */     public boolean visit(ParameterizedTypeBinding parameterizedTypeBinding) {
/* 699 */       if (!visit((ReferenceBinding)parameterizedTypeBinding))
/* 700 */         return false; 
/* 701 */       return super.visit(parameterizedTypeBinding);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static MethodBinding checkForContradictions(MethodBinding method, Object location, Scope scope) {
/* 711 */     int start = 0, end = 0;
/* 712 */     if (location instanceof InvocationSite) {
/* 713 */       start = ((InvocationSite)location).sourceStart();
/* 714 */       end = ((InvocationSite)location).sourceEnd();
/* 715 */     } else if (location instanceof ASTNode) {
/* 716 */       start = ((ASTNode)location).sourceStart;
/* 717 */       end = ((ASTNode)location).sourceEnd;
/*     */     } 
/* 719 */     SearchContradictions searchContradiction = new SearchContradictions();
/* 720 */     TypeBindingVisitor.visit(searchContradiction, method.returnType);
/* 721 */     if (searchContradiction.typeWithContradiction != null) {
/* 722 */       if (scope == null)
/* 723 */         return (MethodBinding)new ProblemMethodBinding(method, method.selector, method.parameters, 25); 
/* 724 */       scope.problemReporter().contradictoryNullAnnotationsInferred(method, start, end, location instanceof FunctionalExpression);
/*     */       
/* 726 */       return method;
/*     */     } 
/*     */     
/* 729 */     Expression[] arguments = null;
/* 730 */     if (location instanceof Invocation)
/* 731 */       arguments = ((Invocation)location).arguments(); 
/* 732 */     for (int i = 0; i < method.parameters.length; i++) {
/* 733 */       TypeBindingVisitor.visit(searchContradiction, method.parameters[i]);
/* 734 */       if (searchContradiction.typeWithContradiction != null) {
/* 735 */         if (scope == null)
/* 736 */           return (MethodBinding)new ProblemMethodBinding(method, method.selector, method.parameters, 25); 
/* 737 */         if (arguments != null && i < arguments.length) {
/* 738 */           scope.problemReporter().contradictoryNullAnnotationsInferred(method, arguments[i]);
/*     */         } else {
/* 740 */           scope.problemReporter().contradictoryNullAnnotationsInferred(method, start, end, location instanceof FunctionalExpression);
/* 741 */         }  return method;
/*     */       } 
/*     */     } 
/* 744 */     return method;
/*     */   }
/*     */   
/*     */   public static boolean hasContradictions(TypeBinding type) {
/* 748 */     SearchContradictions searchContradiction = new SearchContradictions();
/* 749 */     TypeBindingVisitor.visit(searchContradiction, type);
/* 750 */     return (searchContradiction.typeWithContradiction != null);
/*     */   }
/*     */   
/*     */   public static TypeBinding strongerType(TypeBinding type1, TypeBinding type2, LookupEnvironment environment) {
/* 754 */     if ((type1.tagBits & 0x100000000000000L) != 0L)
/* 755 */       return mergeTypeAnnotations(type1, type2, true, environment); 
/* 756 */     return mergeTypeAnnotations(type2, type1, true, environment);
/*     */   }
/*     */   
/*     */   public static TypeBinding[] weakerTypes(TypeBinding[] parameters1, TypeBinding[] parameters2, LookupEnvironment environment) {
/* 760 */     TypeBinding[] newParameters = new TypeBinding[parameters1.length];
/* 761 */     for (int i = 0; i < newParameters.length; i++) {
/* 762 */       long tagBits1 = (parameters1[i]).tagBits;
/* 763 */       long tagBits2 = (parameters2[i]).tagBits;
/* 764 */       if ((tagBits1 & 0x80000000000000L) != 0L) {
/* 765 */         newParameters[i] = mergeTypeAnnotations(parameters1[i], parameters2[i], true, environment);
/* 766 */       } else if ((tagBits2 & 0x80000000000000L) != 0L) {
/* 767 */         newParameters[i] = mergeTypeAnnotations(parameters2[i], parameters1[i], true, environment);
/* 768 */       } else if ((tagBits1 & 0x100000000000000L) == 0L) {
/* 769 */         newParameters[i] = mergeTypeAnnotations(parameters1[i], parameters2[i], true, environment);
/*     */       } else {
/* 771 */         newParameters[i] = mergeTypeAnnotations(parameters2[i], parameters1[i], true, environment);
/*     */       } 
/* 773 */     }  return newParameters;
/*     */   }
/*     */   private static TypeBinding mergeTypeAnnotations(TypeBinding type, TypeBinding otherType, boolean top, LookupEnvironment environment) {
/* 776 */     TypeBinding mainType = type;
/* 777 */     if (!top) {
/*     */       
/* 779 */       AnnotationBinding[] otherAnnotations = otherType.getTypeAnnotations();
/* 780 */       if (otherAnnotations != Binding.NO_ANNOTATIONS)
/* 781 */         mainType = environment.createAnnotatedType(type, otherAnnotations); 
/*     */     } 
/* 783 */     if (mainType.isParameterizedType() && otherType.isParameterizedType()) {
/* 784 */       ParameterizedTypeBinding ptb = (ParameterizedTypeBinding)type, otherPTB = (ParameterizedTypeBinding)otherType;
/* 785 */       TypeBinding[] typeArguments = ptb.arguments;
/* 786 */       TypeBinding[] otherTypeArguments = otherPTB.arguments;
/* 787 */       TypeBinding[] newTypeArguments = new TypeBinding[typeArguments.length];
/* 788 */       for (int i = 0; i < typeArguments.length; i++) {
/* 789 */         newTypeArguments[i] = mergeTypeAnnotations(typeArguments[i], otherTypeArguments[i], false, environment);
/*     */       }
/* 791 */       return (TypeBinding)environment.createParameterizedType(ptb.genericType(), newTypeArguments, ptb.enclosingType());
/*     */     } 
/* 793 */     return mainType;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 798 */     if (this == NULL_ANNOTATIONS_OK) return "OK"; 
/* 799 */     if (this == NULL_ANNOTATIONS_MISMATCH) return "MISMATCH"; 
/* 800 */     if (this == NULL_ANNOTATIONS_OK_NONNULL) return "OK NonNull"; 
/* 801 */     if (this == NULL_ANNOTATIONS_UNCHECKED) return "UNCHECKED"; 
/* 802 */     StringBuilder buf = new StringBuilder();
/* 803 */     buf.append("Analysis result: severity=" + this.severity);
/* 804 */     buf.append(" nullStatus=" + this.nullStatus);
/* 805 */     return buf.toString();
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\ast\NullAnnotationMatching.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */