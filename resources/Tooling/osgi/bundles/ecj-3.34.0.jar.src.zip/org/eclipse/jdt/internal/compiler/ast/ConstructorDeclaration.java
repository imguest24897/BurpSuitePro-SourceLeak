/*     */ package org.eclipse.jdt.internal.compiler.ast;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.eclipse.jdt.core.compiler.CategorizedProblem;
/*     */ import org.eclipse.jdt.core.compiler.CharOperation;
/*     */ import org.eclipse.jdt.internal.compiler.ASTVisitor;
/*     */ import org.eclipse.jdt.internal.compiler.ClassFile;
/*     */ import org.eclipse.jdt.internal.compiler.CompilationResult;
/*     */ import org.eclipse.jdt.internal.compiler.codegen.AnnotationContext;
/*     */ import org.eclipse.jdt.internal.compiler.codegen.CodeStream;
/*     */ import org.eclipse.jdt.internal.compiler.codegen.StackMapFrameCodeStream;
/*     */ import org.eclipse.jdt.internal.compiler.flow.FlowContext;
/*     */ import org.eclipse.jdt.internal.compiler.flow.FlowInfo;
/*     */ import org.eclipse.jdt.internal.compiler.flow.InitializationFlowContext;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.AnnotationBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.Binding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.BlockScope;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.ClassScope;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.FieldBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.LocalVariableBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.MethodScope;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.NestedTypeBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.RecordComponentBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.ReferenceBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.SourceTypeBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.SyntheticArgumentBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.TypeBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.TypeConstants;
/*     */ import org.eclipse.jdt.internal.compiler.parser.Parser;
/*     */ import org.eclipse.jdt.internal.compiler.problem.AbortMethod;
/*     */ import org.eclipse.jdt.internal.compiler.problem.ProblemReporter;
/*     */ import org.eclipse.jdt.internal.compiler.util.Util;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ConstructorDeclaration
/*     */   extends AbstractMethodDeclaration
/*     */ {
/*     */   public ExplicitConstructorCall constructorCall;
/*     */   public TypeParameter[] typeParameters;
/*     */   
/*     */   public ConstructorDeclaration(CompilationResult compilationResult) {
/*  56 */     super(compilationResult);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void analyseCode(ClassScope classScope, InitializationFlowContext initializerFlowContext, FlowInfo flowInfo, int initialReachMode) {
/*     */     // Byte code:
/*     */     //   0: aload_0
/*     */     //   1: getfield ignoreFurtherInvestigation : Z
/*     */     //   4: ifeq -> 8
/*     */     //   7: return
/*     */     //   8: aload_3
/*     */     //   9: invokevirtual reachMode : ()I
/*     */     //   12: istore #5
/*     */     //   14: aload_3
/*     */     //   15: iload #4
/*     */     //   17: invokevirtual setReachMode : (I)Lorg/eclipse/jdt/internal/compiler/flow/FlowInfo;
/*     */     //   20: pop
/*     */     //   21: aload_0
/*     */     //   22: getfield binding : Lorg/eclipse/jdt/internal/compiler/lookup/MethodBinding;
/*     */     //   25: dup
/*     */     //   26: astore #6
/*     */     //   28: ifnonnull -> 34
/*     */     //   31: goto -> 243
/*     */     //   34: aload_0
/*     */     //   35: getfield bits : I
/*     */     //   38: sipush #128
/*     */     //   41: iand
/*     */     //   42: ifeq -> 48
/*     */     //   45: goto -> 243
/*     */     //   48: aload #6
/*     */     //   50: invokevirtual isUsed : ()Z
/*     */     //   53: ifeq -> 59
/*     */     //   56: goto -> 243
/*     */     //   59: aload #6
/*     */     //   61: invokevirtual isPrivate : ()Z
/*     */     //   64: ifeq -> 89
/*     */     //   67: aload_0
/*     */     //   68: getfield binding : Lorg/eclipse/jdt/internal/compiler/lookup/MethodBinding;
/*     */     //   71: getfield declaringClass : Lorg/eclipse/jdt/internal/compiler/lookup/ReferenceBinding;
/*     */     //   74: getfield tagBits : J
/*     */     //   77: ldc2_w 1152921504606846976
/*     */     //   80: land
/*     */     //   81: lconst_0
/*     */     //   82: lcmp
/*     */     //   83: ifne -> 100
/*     */     //   86: goto -> 243
/*     */     //   89: aload #6
/*     */     //   91: invokevirtual isOrEnclosedByPrivateType : ()Z
/*     */     //   94: ifne -> 100
/*     */     //   97: goto -> 243
/*     */     //   100: aload_0
/*     */     //   101: getfield constructorCall : Lorg/eclipse/jdt/internal/compiler/ast/ExplicitConstructorCall;
/*     */     //   104: ifnonnull -> 110
/*     */     //   107: goto -> 243
/*     */     //   110: aload_0
/*     */     //   111: getfield constructorCall : Lorg/eclipse/jdt/internal/compiler/ast/ExplicitConstructorCall;
/*     */     //   114: getfield accessMode : I
/*     */     //   117: iconst_3
/*     */     //   118: if_icmpeq -> 221
/*     */     //   121: aload #6
/*     */     //   123: getfield declaringClass : Lorg/eclipse/jdt/internal/compiler/lookup/ReferenceBinding;
/*     */     //   126: invokevirtual superclass : ()Lorg/eclipse/jdt/internal/compiler/lookup/ReferenceBinding;
/*     */     //   129: astore #7
/*     */     //   131: aload #7
/*     */     //   133: ifnonnull -> 139
/*     */     //   136: goto -> 243
/*     */     //   139: aload #7
/*     */     //   141: getstatic org/eclipse/jdt/internal/compiler/lookup/Binding.NO_PARAMETERS : [Lorg/eclipse/jdt/internal/compiler/lookup/TypeBinding;
/*     */     //   144: invokevirtual getExactConstructor : ([Lorg/eclipse/jdt/internal/compiler/lookup/TypeBinding;)Lorg/eclipse/jdt/internal/compiler/lookup/MethodBinding;
/*     */     //   147: astore #8
/*     */     //   149: aload #8
/*     */     //   151: ifnonnull -> 157
/*     */     //   154: goto -> 243
/*     */     //   157: aload #8
/*     */     //   159: invokestatic implicitSuperConstructorCall : ()Lorg/eclipse/jdt/internal/compiler/ast/ExplicitConstructorCall;
/*     */     //   162: aload_0
/*     */     //   163: getfield scope : Lorg/eclipse/jdt/internal/compiler/lookup/MethodScope;
/*     */     //   166: invokevirtual canBeSeenBy : (Lorg/eclipse/jdt/internal/compiler/lookup/InvocationSite;Lorg/eclipse/jdt/internal/compiler/lookup/Scope;)Z
/*     */     //   169: ifne -> 175
/*     */     //   172: goto -> 243
/*     */     //   175: aload #6
/*     */     //   177: getfield declaringClass : Lorg/eclipse/jdt/internal/compiler/lookup/ReferenceBinding;
/*     */     //   180: astore #9
/*     */     //   182: aload #6
/*     */     //   184: invokevirtual isPublic : ()Z
/*     */     //   187: ifeq -> 221
/*     */     //   190: aload #6
/*     */     //   192: getfield parameters : [Lorg/eclipse/jdt/internal/compiler/lookup/TypeBinding;
/*     */     //   195: arraylength
/*     */     //   196: ifne -> 221
/*     */     //   199: aload #9
/*     */     //   201: invokevirtual isStatic : ()Z
/*     */     //   204: ifeq -> 221
/*     */     //   207: aload #9
/*     */     //   209: bipush #56
/*     */     //   211: iconst_0
/*     */     //   212: invokevirtual findSuperTypeOriginatingFrom : (IZ)Lorg/eclipse/jdt/internal/compiler/lookup/ReferenceBinding;
/*     */     //   215: ifnull -> 221
/*     */     //   218: goto -> 243
/*     */     //   221: aload_0
/*     */     //   222: getfield bits : I
/*     */     //   225: sipush #1024
/*     */     //   228: iand
/*     */     //   229: ifne -> 243
/*     */     //   232: aload_0
/*     */     //   233: getfield scope : Lorg/eclipse/jdt/internal/compiler/lookup/MethodScope;
/*     */     //   236: invokevirtual problemReporter : ()Lorg/eclipse/jdt/internal/compiler/problem/ProblemReporter;
/*     */     //   239: aload_0
/*     */     //   240: invokevirtual unusedPrivateConstructor : (Lorg/eclipse/jdt/internal/compiler/ast/ConstructorDeclaration;)V
/*     */     //   243: aload_0
/*     */     //   244: aconst_null
/*     */     //   245: invokevirtual isRecursive : (Ljava/util/ArrayList;)Z
/*     */     //   248: ifeq -> 265
/*     */     //   251: aload_0
/*     */     //   252: getfield scope : Lorg/eclipse/jdt/internal/compiler/lookup/MethodScope;
/*     */     //   255: invokevirtual problemReporter : ()Lorg/eclipse/jdt/internal/compiler/problem/ProblemReporter;
/*     */     //   258: aload_0
/*     */     //   259: getfield constructorCall : Lorg/eclipse/jdt/internal/compiler/ast/ExplicitConstructorCall;
/*     */     //   262: invokevirtual recursiveConstructorInvocation : (Lorg/eclipse/jdt/internal/compiler/ast/ExplicitConstructorCall;)V
/*     */     //   265: aload_0
/*     */     //   266: getfield typeParameters : [Lorg/eclipse/jdt/internal/compiler/ast/TypeParameter;
/*     */     //   269: ifnull -> 346
/*     */     //   272: aload_0
/*     */     //   273: getfield scope : Lorg/eclipse/jdt/internal/compiler/lookup/MethodScope;
/*     */     //   276: invokevirtual referenceCompilationUnit : ()Lorg/eclipse/jdt/internal/compiler/ast/CompilationUnitDeclaration;
/*     */     //   279: getfield compilationResult : Lorg/eclipse/jdt/internal/compiler/CompilationResult;
/*     */     //   282: getfield hasSyntaxError : Z
/*     */     //   285: ifne -> 346
/*     */     //   288: iconst_0
/*     */     //   289: istore #6
/*     */     //   291: aload_0
/*     */     //   292: getfield typeParameters : [Lorg/eclipse/jdt/internal/compiler/ast/TypeParameter;
/*     */     //   295: arraylength
/*     */     //   296: istore #7
/*     */     //   298: goto -> 339
/*     */     //   301: aload_0
/*     */     //   302: getfield typeParameters : [Lorg/eclipse/jdt/internal/compiler/ast/TypeParameter;
/*     */     //   305: iload #6
/*     */     //   307: aaload
/*     */     //   308: astore #8
/*     */     //   310: aload #8
/*     */     //   312: getfield binding : Lorg/eclipse/jdt/internal/compiler/lookup/TypeVariableBinding;
/*     */     //   315: getfield modifiers : I
/*     */     //   318: ldc 134217728
/*     */     //   320: iand
/*     */     //   321: ifne -> 336
/*     */     //   324: aload_0
/*     */     //   325: getfield scope : Lorg/eclipse/jdt/internal/compiler/lookup/MethodScope;
/*     */     //   328: invokevirtual problemReporter : ()Lorg/eclipse/jdt/internal/compiler/problem/ProblemReporter;
/*     */     //   331: aload #8
/*     */     //   333: invokevirtual unusedTypeParameter : (Lorg/eclipse/jdt/internal/compiler/ast/TypeParameter;)V
/*     */     //   336: iinc #6, 1
/*     */     //   339: iload #6
/*     */     //   341: iload #7
/*     */     //   343: if_icmplt -> 301
/*     */     //   346: new org/eclipse/jdt/internal/compiler/flow/ExceptionHandlingFlowContext
/*     */     //   349: dup
/*     */     //   350: aload_2
/*     */     //   351: getfield parent : Lorg/eclipse/jdt/internal/compiler/flow/FlowContext;
/*     */     //   354: aload_0
/*     */     //   355: aload_0
/*     */     //   356: getfield binding : Lorg/eclipse/jdt/internal/compiler/lookup/MethodBinding;
/*     */     //   359: getfield thrownExceptions : [Lorg/eclipse/jdt/internal/compiler/lookup/ReferenceBinding;
/*     */     //   362: aload_2
/*     */     //   363: aload_0
/*     */     //   364: getfield scope : Lorg/eclipse/jdt/internal/compiler/lookup/MethodScope;
/*     */     //   367: getstatic org/eclipse/jdt/internal/compiler/flow/FlowInfo.DEAD_END : Lorg/eclipse/jdt/internal/compiler/flow/UnconditionalFlowInfo;
/*     */     //   370: invokespecial <init> : (Lorg/eclipse/jdt/internal/compiler/flow/FlowContext;Lorg/eclipse/jdt/internal/compiler/ast/ASTNode;[Lorg/eclipse/jdt/internal/compiler/lookup/ReferenceBinding;Lorg/eclipse/jdt/internal/compiler/flow/FlowContext;Lorg/eclipse/jdt/internal/compiler/lookup/BlockScope;Lorg/eclipse/jdt/internal/compiler/flow/UnconditionalFlowInfo;)V
/*     */     //   373: astore #6
/*     */     //   375: aload_2
/*     */     //   376: aload_0
/*     */     //   377: getfield scope : Lorg/eclipse/jdt/internal/compiler/lookup/MethodScope;
/*     */     //   380: aload #6
/*     */     //   382: aload_3
/*     */     //   383: invokevirtual checkInitializerExceptions : (Lorg/eclipse/jdt/internal/compiler/lookup/BlockScope;Lorg/eclipse/jdt/internal/compiler/flow/FlowContext;Lorg/eclipse/jdt/internal/compiler/flow/FlowInfo;)V
/*     */     //   386: aload_0
/*     */     //   387: getfield binding : Lorg/eclipse/jdt/internal/compiler/lookup/MethodBinding;
/*     */     //   390: getfield declaringClass : Lorg/eclipse/jdt/internal/compiler/lookup/ReferenceBinding;
/*     */     //   393: invokevirtual isAnonymousType : ()Z
/*     */     //   396: ifeq -> 449
/*     */     //   399: aload #6
/*     */     //   401: getfield extendedExceptions : Ljava/util/List;
/*     */     //   404: astore #7
/*     */     //   406: aload #7
/*     */     //   408: ifnull -> 449
/*     */     //   411: aload #7
/*     */     //   413: invokeinterface size : ()I
/*     */     //   418: dup
/*     */     //   419: istore #8
/*     */     //   421: ifle -> 449
/*     */     //   424: aload #7
/*     */     //   426: iload #8
/*     */     //   428: anewarray org/eclipse/jdt/internal/compiler/lookup/ReferenceBinding
/*     */     //   431: dup
/*     */     //   432: astore #9
/*     */     //   434: invokeinterface toArray : ([Ljava/lang/Object;)[Ljava/lang/Object;
/*     */     //   439: pop
/*     */     //   440: aload_0
/*     */     //   441: getfield binding : Lorg/eclipse/jdt/internal/compiler/lookup/MethodBinding;
/*     */     //   444: aload #9
/*     */     //   446: putfield thrownExceptions : [Lorg/eclipse/jdt/internal/compiler/lookup/ReferenceBinding;
/*     */     //   449: aload_1
/*     */     //   450: invokevirtual environment : ()Lorg/eclipse/jdt/internal/compiler/lookup/LookupEnvironment;
/*     */     //   453: aload_3
/*     */     //   454: aload_0
/*     */     //   455: getfield arguments : [Lorg/eclipse/jdt/internal/compiler/ast/Argument;
/*     */     //   458: aload_0
/*     */     //   459: getfield binding : Lorg/eclipse/jdt/internal/compiler/lookup/MethodBinding;
/*     */     //   462: invokestatic analyseArguments : (Lorg/eclipse/jdt/internal/compiler/lookup/LookupEnvironment;Lorg/eclipse/jdt/internal/compiler/flow/FlowInfo;[Lorg/eclipse/jdt/internal/compiler/ast/Argument;Lorg/eclipse/jdt/internal/compiler/lookup/MethodBinding;)V
/*     */     //   465: aload_0
/*     */     //   466: getfield constructorCall : Lorg/eclipse/jdt/internal/compiler/ast/ExplicitConstructorCall;
/*     */     //   469: ifnull -> 551
/*     */     //   472: aload_0
/*     */     //   473: getfield constructorCall : Lorg/eclipse/jdt/internal/compiler/ast/ExplicitConstructorCall;
/*     */     //   476: getfield accessMode : I
/*     */     //   479: iconst_3
/*     */     //   480: if_icmpne -> 536
/*     */     //   483: aload_0
/*     */     //   484: getfield binding : Lorg/eclipse/jdt/internal/compiler/lookup/MethodBinding;
/*     */     //   487: getfield declaringClass : Lorg/eclipse/jdt/internal/compiler/lookup/ReferenceBinding;
/*     */     //   490: invokevirtual fields : ()[Lorg/eclipse/jdt/internal/compiler/lookup/FieldBinding;
/*     */     //   493: astore #7
/*     */     //   495: iconst_0
/*     */     //   496: istore #8
/*     */     //   498: aload #7
/*     */     //   500: arraylength
/*     */     //   501: istore #9
/*     */     //   503: goto -> 529
/*     */     //   506: aload #7
/*     */     //   508: iload #8
/*     */     //   510: aaload
/*     */     //   511: dup
/*     */     //   512: astore #10
/*     */     //   514: invokevirtual isStatic : ()Z
/*     */     //   517: ifne -> 526
/*     */     //   520: aload_3
/*     */     //   521: aload #10
/*     */     //   523: invokevirtual markAsDefinitelyAssigned : (Lorg/eclipse/jdt/internal/compiler/lookup/FieldBinding;)V
/*     */     //   526: iinc #8, 1
/*     */     //   529: iload #8
/*     */     //   531: iload #9
/*     */     //   533: if_icmplt -> 506
/*     */     //   536: aload_0
/*     */     //   537: getfield constructorCall : Lorg/eclipse/jdt/internal/compiler/ast/ExplicitConstructorCall;
/*     */     //   540: aload_0
/*     */     //   541: getfield scope : Lorg/eclipse/jdt/internal/compiler/lookup/MethodScope;
/*     */     //   544: aload #6
/*     */     //   546: aload_3
/*     */     //   547: invokevirtual analyseCode : (Lorg/eclipse/jdt/internal/compiler/lookup/BlockScope;Lorg/eclipse/jdt/internal/compiler/flow/FlowContext;Lorg/eclipse/jdt/internal/compiler/flow/FlowInfo;)Lorg/eclipse/jdt/internal/compiler/flow/FlowInfo;
/*     */     //   550: astore_3
/*     */     //   551: aload_3
/*     */     //   552: iload #5
/*     */     //   554: invokevirtual setReachMode : (I)Lorg/eclipse/jdt/internal/compiler/flow/FlowInfo;
/*     */     //   557: pop
/*     */     //   558: aload_0
/*     */     //   559: getfield statements : [Lorg/eclipse/jdt/internal/compiler/ast/Statement;
/*     */     //   562: ifnull -> 688
/*     */     //   565: aload_0
/*     */     //   566: getfield scope : Lorg/eclipse/jdt/internal/compiler/lookup/MethodScope;
/*     */     //   569: invokevirtual compilerOptions : ()Lorg/eclipse/jdt/internal/compiler/impl/CompilerOptions;
/*     */     //   572: astore #7
/*     */     //   574: aload #7
/*     */     //   576: getfield enableSyntacticNullAnalysisForFields : Z
/*     */     //   579: istore #8
/*     */     //   581: iload #5
/*     */     //   583: iconst_3
/*     */     //   584: iand
/*     */     //   585: ifne -> 592
/*     */     //   588: iconst_0
/*     */     //   589: goto -> 593
/*     */     //   592: iconst_1
/*     */     //   593: istore #9
/*     */     //   595: iconst_0
/*     */     //   596: istore #10
/*     */     //   598: aload_0
/*     */     //   599: getfield statements : [Lorg/eclipse/jdt/internal/compiler/ast/Statement;
/*     */     //   602: arraylength
/*     */     //   603: istore #11
/*     */     //   605: goto -> 681
/*     */     //   608: aload_0
/*     */     //   609: getfield statements : [Lorg/eclipse/jdt/internal/compiler/ast/Statement;
/*     */     //   612: iload #10
/*     */     //   614: aaload
/*     */     //   615: astore #12
/*     */     //   617: aload #12
/*     */     //   619: aload_3
/*     */     //   620: aload_0
/*     */     //   621: getfield scope : Lorg/eclipse/jdt/internal/compiler/lookup/MethodScope;
/*     */     //   624: iload #9
/*     */     //   626: iconst_1
/*     */     //   627: invokevirtual complainIfUnreachable : (Lorg/eclipse/jdt/internal/compiler/flow/FlowInfo;Lorg/eclipse/jdt/internal/compiler/lookup/BlockScope;IZ)I
/*     */     //   630: dup
/*     */     //   631: istore #9
/*     */     //   633: iconst_2
/*     */     //   634: if_icmpge -> 650
/*     */     //   637: aload #12
/*     */     //   639: aload_0
/*     */     //   640: getfield scope : Lorg/eclipse/jdt/internal/compiler/lookup/MethodScope;
/*     */     //   643: aload #6
/*     */     //   645: aload_3
/*     */     //   646: invokevirtual analyseCode : (Lorg/eclipse/jdt/internal/compiler/lookup/BlockScope;Lorg/eclipse/jdt/internal/compiler/flow/FlowContext;Lorg/eclipse/jdt/internal/compiler/flow/FlowInfo;)Lorg/eclipse/jdt/internal/compiler/flow/FlowInfo;
/*     */     //   649: astore_3
/*     */     //   650: iload #8
/*     */     //   652: ifeq -> 660
/*     */     //   655: aload #6
/*     */     //   657: invokevirtual expireNullCheckedFieldInfo : ()V
/*     */     //   660: aload #7
/*     */     //   662: getfield analyseResourceLeaks : Z
/*     */     //   665: ifeq -> 678
/*     */     //   668: aload_0
/*     */     //   669: getfield scope : Lorg/eclipse/jdt/internal/compiler/lookup/MethodScope;
/*     */     //   672: aload #12
/*     */     //   674: aload_3
/*     */     //   675: invokestatic cleanUpUnassigned : (Lorg/eclipse/jdt/internal/compiler/lookup/BlockScope;Lorg/eclipse/jdt/internal/compiler/ast/ASTNode;Lorg/eclipse/jdt/internal/compiler/flow/FlowInfo;)V
/*     */     //   678: iinc #10, 1
/*     */     //   681: iload #10
/*     */     //   683: iload #11
/*     */     //   685: if_icmplt -> 608
/*     */     //   688: aload_3
/*     */     //   689: getfield tagBits : I
/*     */     //   692: iconst_1
/*     */     //   693: iand
/*     */     //   694: ifne -> 708
/*     */     //   697: aload_0
/*     */     //   698: dup
/*     */     //   699: getfield bits : I
/*     */     //   702: bipush #64
/*     */     //   704: ior
/*     */     //   705: putfield bits : I
/*     */     //   708: aload_0
/*     */     //   709: getfield constructorCall : Lorg/eclipse/jdt/internal/compiler/ast/ExplicitConstructorCall;
/*     */     //   712: ifnull -> 763
/*     */     //   715: aload_0
/*     */     //   716: getfield constructorCall : Lorg/eclipse/jdt/internal/compiler/ast/ExplicitConstructorCall;
/*     */     //   719: getfield accessMode : I
/*     */     //   722: iconst_3
/*     */     //   723: if_icmpeq -> 763
/*     */     //   726: aload_3
/*     */     //   727: aload #6
/*     */     //   729: getfield initsOnReturn : Lorg/eclipse/jdt/internal/compiler/flow/UnconditionalFlowInfo;
/*     */     //   732: invokevirtual mergedWith : (Lorg/eclipse/jdt/internal/compiler/flow/UnconditionalFlowInfo;)Lorg/eclipse/jdt/internal/compiler/flow/UnconditionalFlowInfo;
/*     */     //   735: astore_3
/*     */     //   736: aload_0
/*     */     //   737: getfield binding : Lorg/eclipse/jdt/internal/compiler/lookup/MethodBinding;
/*     */     //   740: getfield declaringClass : Lorg/eclipse/jdt/internal/compiler/lookup/ReferenceBinding;
/*     */     //   743: invokevirtual fields : ()[Lorg/eclipse/jdt/internal/compiler/lookup/FieldBinding;
/*     */     //   746: astore #7
/*     */     //   748: aload_0
/*     */     //   749: aload_2
/*     */     //   750: aload_3
/*     */     //   751: aload #7
/*     */     //   753: invokevirtual checkAndGenerateFieldAssignment : (Lorg/eclipse/jdt/internal/compiler/flow/FlowContext;Lorg/eclipse/jdt/internal/compiler/flow/FlowInfo;[Lorg/eclipse/jdt/internal/compiler/lookup/FieldBinding;)V
/*     */     //   756: aload_0
/*     */     //   757: aload_3
/*     */     //   758: aload #7
/*     */     //   760: invokevirtual doFieldReachAnalysis : (Lorg/eclipse/jdt/internal/compiler/flow/FlowInfo;[Lorg/eclipse/jdt/internal/compiler/lookup/FieldBinding;)V
/*     */     //   763: aload #6
/*     */     //   765: aload_0
/*     */     //   766: invokevirtual complainIfUnusedExceptionHandlers : (Lorg/eclipse/jdt/internal/compiler/ast/AbstractMethodDeclaration;)V
/*     */     //   769: aload_0
/*     */     //   770: getfield scope : Lorg/eclipse/jdt/internal/compiler/lookup/MethodScope;
/*     */     //   773: aload_0
/*     */     //   774: getfield binding : Lorg/eclipse/jdt/internal/compiler/lookup/MethodBinding;
/*     */     //   777: invokevirtual checkUnusedParameters : (Lorg/eclipse/jdt/internal/compiler/lookup/MethodBinding;)V
/*     */     //   780: aload_0
/*     */     //   781: getfield scope : Lorg/eclipse/jdt/internal/compiler/lookup/MethodScope;
/*     */     //   784: aload_3
/*     */     //   785: aconst_null
/*     */     //   786: aconst_null
/*     */     //   787: aconst_null
/*     */     //   788: invokevirtual checkUnclosedCloseables : (Lorg/eclipse/jdt/internal/compiler/flow/FlowInfo;Lorg/eclipse/jdt/internal/compiler/flow/FlowContext;Lorg/eclipse/jdt/internal/compiler/ast/ASTNode;Lorg/eclipse/jdt/internal/compiler/lookup/BlockScope;)V
/*     */     //   791: goto -> 800
/*     */     //   794: pop
/*     */     //   795: aload_0
/*     */     //   796: iconst_1
/*     */     //   797: putfield ignoreFurtherInvestigation : Z
/*     */     //   800: return
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #63	-> 0
/*     */     //   #64	-> 7
/*     */     //   #66	-> 8
/*     */     //   #67	-> 14
/*     */     //   #71	-> 21
/*     */     //   #72	-> 34
/*     */     //   #73	-> 48
/*     */     //   #74	-> 59
/*     */     //   #75	-> 67
/*     */     //   #76	-> 86
/*     */     //   #77	-> 89
/*     */     //   #78	-> 97
/*     */     //   #82	-> 100
/*     */     //   #83	-> 107
/*     */     //   #89	-> 110
/*     */     //   #90	-> 121
/*     */     //   #91	-> 131
/*     */     //   #92	-> 136
/*     */     //   #94	-> 139
/*     */     //   #95	-> 149
/*     */     //   #96	-> 154
/*     */     //   #97	-> 157
/*     */     //   #98	-> 172
/*     */     //   #99	-> 175
/*     */     //   #100	-> 182
/*     */     //   #101	-> 199
/*     */     //   #102	-> 207
/*     */     //   #103	-> 218
/*     */     //   #107	-> 221
/*     */     //   #108	-> 232
/*     */     //   #112	-> 243
/*     */     //   #113	-> 251
/*     */     //   #116	-> 265
/*     */     //   #117	-> 272
/*     */     //   #118	-> 288
/*     */     //   #119	-> 301
/*     */     //   #120	-> 310
/*     */     //   #121	-> 324
/*     */     //   #118	-> 336
/*     */     //   #127	-> 346
/*     */     //   #128	-> 350
/*     */     //   #129	-> 354
/*     */     //   #130	-> 355
/*     */     //   #131	-> 362
/*     */     //   #132	-> 363
/*     */     //   #133	-> 367
/*     */     //   #127	-> 370
/*     */     //   #126	-> 373
/*     */     //   #134	-> 375
/*     */     //   #135	-> 376
/*     */     //   #136	-> 380
/*     */     //   #137	-> 382
/*     */     //   #134	-> 383
/*     */     //   #140	-> 386
/*     */     //   #141	-> 399
/*     */     //   #142	-> 406
/*     */     //   #144	-> 411
/*     */     //   #146	-> 424
/*     */     //   #147	-> 440
/*     */     //   #153	-> 449
/*     */     //   #156	-> 465
/*     */     //   #159	-> 472
/*     */     //   #160	-> 483
/*     */     //   #161	-> 495
/*     */     //   #163	-> 506
/*     */     //   #164	-> 520
/*     */     //   #161	-> 526
/*     */     //   #168	-> 536
/*     */     //   #172	-> 551
/*     */     //   #175	-> 558
/*     */     //   #176	-> 565
/*     */     //   #177	-> 574
/*     */     //   #178	-> 581
/*     */     //   #179	-> 595
/*     */     //   #180	-> 608
/*     */     //   #181	-> 617
/*     */     //   #182	-> 637
/*     */     //   #184	-> 650
/*     */     //   #185	-> 655
/*     */     //   #187	-> 660
/*     */     //   #188	-> 668
/*     */     //   #179	-> 678
/*     */     //   #193	-> 688
/*     */     //   #194	-> 697
/*     */     //   #203	-> 708
/*     */     //   #204	-> 715
/*     */     //   #205	-> 726
/*     */     //   #206	-> 736
/*     */     //   #207	-> 748
/*     */     //   #208	-> 756
/*     */     //   #211	-> 763
/*     */     //   #213	-> 769
/*     */     //   #214	-> 780
/*     */     //   #215	-> 791
/*     */     //   #216	-> 795
/*     */     //   #218	-> 800
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	descriptor
/*     */     //   0	801	0	this	Lorg/eclipse/jdt/internal/compiler/ast/ConstructorDeclaration;
/*     */     //   0	801	1	classScope	Lorg/eclipse/jdt/internal/compiler/lookup/ClassScope;
/*     */     //   0	801	2	initializerFlowContext	Lorg/eclipse/jdt/internal/compiler/flow/InitializationFlowContext;
/*     */     //   0	801	3	flowInfo	Lorg/eclipse/jdt/internal/compiler/flow/FlowInfo;
/*     */     //   0	801	4	initialReachMode	I
/*     */     //   14	787	5	nonStaticFieldInfoReachMode	I
/*     */     //   28	215	6	constructorBinding	Lorg/eclipse/jdt/internal/compiler/lookup/MethodBinding;
/*     */     //   131	90	7	superClass	Lorg/eclipse/jdt/internal/compiler/lookup/ReferenceBinding;
/*     */     //   149	72	8	methodBinding	Lorg/eclipse/jdt/internal/compiler/lookup/MethodBinding;
/*     */     //   182	39	9	declaringClass	Lorg/eclipse/jdt/internal/compiler/lookup/ReferenceBinding;
/*     */     //   291	55	6	i	I
/*     */     //   298	48	7	length	I
/*     */     //   310	26	8	typeParameter	Lorg/eclipse/jdt/internal/compiler/ast/TypeParameter;
/*     */     //   375	416	6	constructorContext	Lorg/eclipse/jdt/internal/compiler/flow/ExceptionHandlingFlowContext;
/*     */     //   406	43	7	computedExceptions	Ljava/util/List;
/*     */     //   421	28	8	size	I
/*     */     //   434	15	9	actuallyThrownExceptions	[Lorg/eclipse/jdt/internal/compiler/lookup/ReferenceBinding;
/*     */     //   495	41	7	fields	[Lorg/eclipse/jdt/internal/compiler/lookup/FieldBinding;
/*     */     //   498	38	8	i	I
/*     */     //   503	33	9	count	I
/*     */     //   514	12	10	field	Lorg/eclipse/jdt/internal/compiler/lookup/FieldBinding;
/*     */     //   574	114	7	compilerOptions	Lorg/eclipse/jdt/internal/compiler/impl/CompilerOptions;
/*     */     //   581	107	8	enableSyntacticNullAnalysisForFields	Z
/*     */     //   595	93	9	complaintLevel	I
/*     */     //   598	90	10	i	I
/*     */     //   605	83	11	count	I
/*     */     //   617	61	12	stat	Lorg/eclipse/jdt/internal/compiler/ast/Statement;
/*     */     //   748	15	7	fields	[Lorg/eclipse/jdt/internal/compiler/lookup/FieldBinding;
/*     */     // Exception table:
/*     */     //   from	to	target	type
/*     */     //   346	791	794	org/eclipse/jdt/internal/compiler/problem/AbortMethod
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void doFieldReachAnalysis(FlowInfo flowInfo, FieldBinding[] fields) {
/* 220 */     for (int i = 0, count = fields.length; i < count; i++) {
/* 221 */       FieldBinding field = fields[i];
/* 222 */       if (!field.isStatic() && !flowInfo.isDefinitelyAssigned(field)) {
/* 223 */         if (field.isFinal()) {
/* 224 */           this.scope.problemReporter().uninitializedBlankFinalField(
/* 225 */               field, 
/* 226 */               ((this.bits & 0x80) != 0) ? 
/* 227 */               this.scope.referenceType().declarationOf(field.original()) : 
/* 228 */               this);
/* 229 */         } else if (field.isNonNull() || field.type.isFreeTypeVariable()) {
/* 230 */           FieldDeclaration fieldDecl = this.scope.referenceType().declarationOf(field.original());
/* 231 */           if (!isValueProvidedUsingAnnotation(fieldDecl)) {
/* 232 */             this.scope.problemReporter().uninitializedNonNullField(
/* 233 */                 field, 
/* 234 */                 ((this.bits & 0x80) != 0) ? 
/* 235 */                 fieldDecl : 
/* 236 */                 this);
/*     */           }
/*     */         } 
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   protected void checkAndGenerateFieldAssignment(FlowContext flowContext, FlowInfo flowInfo, FieldBinding[] fields) {}
/*     */   
/*     */   boolean isValueProvidedUsingAnnotation(FieldDeclaration fieldDecl) {
/* 247 */     if (fieldDecl.annotations != null) {
/* 248 */       int length = fieldDecl.annotations.length;
/* 249 */       for (int i = 0; i < length; i++) {
/* 250 */         Annotation annotation = fieldDecl.annotations[i];
/* 251 */         if (annotation.resolvedType.id == 80)
/* 252 */           return true; 
/* 253 */         if (annotation.resolvedType.id == 81) {
/* 254 */           MemberValuePair[] memberValuePairs = annotation.memberValuePairs();
/* 255 */           if (memberValuePairs == Annotation.NoValuePairs)
/* 256 */             return true; 
/* 257 */           for (int j = 0; j < memberValuePairs.length; j++) {
/*     */             
/* 259 */             if (CharOperation.equals((memberValuePairs[j]).name, TypeConstants.OPTIONAL))
/* 260 */               return (memberValuePairs[j]).value instanceof FalseLiteral; 
/*     */           } 
/* 262 */         } else if (annotation.resolvedType.id == 82) {
/* 263 */           MemberValuePair[] memberValuePairs = annotation.memberValuePairs();
/* 264 */           if (memberValuePairs == Annotation.NoValuePairs)
/* 265 */             return true; 
/* 266 */           for (int j = 0; j < memberValuePairs.length; j++) {
/* 267 */             if (CharOperation.equals((memberValuePairs[j]).name, TypeConstants.REQUIRED))
/* 268 */               return (memberValuePairs[j]).value instanceof TrueLiteral; 
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/* 273 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void generateCode(ClassScope classScope, ClassFile classFile) {
/* 284 */     int problemResetPC = 0;
/* 285 */     if (this.ignoreFurtherInvestigation) {
/* 286 */       if (this.binding == null) {
/*     */         return;
/*     */       }
/* 289 */       CategorizedProblem[] problems = 
/* 290 */         (this.scope.referenceCompilationUnit()).compilationResult.getProblems(); int problemsLength;
/* 291 */       CategorizedProblem[] problemsCopy = new CategorizedProblem[problemsLength = problems.length];
/* 292 */       System.arraycopy(problems, 0, problemsCopy, 0, problemsLength);
/* 293 */       classFile.addProblemConstructor(this, this.binding, problemsCopy);
/*     */       return;
/*     */     } 
/* 296 */     boolean restart = false;
/* 297 */     boolean abort = false;
/* 298 */     CompilationResult unitResult = null;
/* 299 */     int problemCount = 0;
/* 300 */     if (classScope != null) {
/* 301 */       TypeDeclaration referenceContext = classScope.referenceContext;
/* 302 */       if (referenceContext != null) {
/* 303 */         unitResult = referenceContext.compilationResult();
/* 304 */         problemCount = unitResult.problemCount;
/*     */       } 
/*     */     } 
/*     */     while (true) {
/*     */       try {
/* 309 */         problemResetPC = classFile.contentsOffset;
/* 310 */         internalGenerateCode(classScope, classFile);
/* 311 */         restart = false;
/* 312 */       } catch (AbortMethod e) {
/* 313 */         if (e.compilationResult == CodeStream.RESTART_IN_WIDE_MODE) {
/*     */           
/* 315 */           classFile.contentsOffset = problemResetPC;
/* 316 */           classFile.methodCount--;
/* 317 */           classFile.codeStream.resetInWideMode();
/*     */           
/* 319 */           if (unitResult != null) {
/* 320 */             unitResult.problemCount = problemCount;
/*     */           }
/* 322 */           restart = true;
/* 323 */         } else if (e.compilationResult == CodeStream.RESTART_CODE_GEN_FOR_UNUSED_LOCALS_MODE) {
/* 324 */           classFile.contentsOffset = problemResetPC;
/* 325 */           classFile.methodCount--;
/* 326 */           classFile.codeStream.resetForCodeGenUnusedLocals();
/*     */           
/* 328 */           if (unitResult != null) {
/* 329 */             unitResult.problemCount = problemCount;
/*     */           }
/* 331 */           restart = true;
/*     */         } else {
/* 333 */           restart = false;
/* 334 */           abort = true;
/*     */         } 
/*     */       } 
/* 337 */       if (!restart) {
/* 338 */         if (abort) {
/*     */           
/* 340 */           CategorizedProblem[] problems = 
/* 341 */             (this.scope.referenceCompilationUnit()).compilationResult.getAllProblems(); int problemsLength;
/* 342 */           CategorizedProblem[] problemsCopy = new CategorizedProblem[problemsLength = problems.length];
/* 343 */           System.arraycopy(problems, 0, problemsCopy, 0, problemsLength);
/* 344 */           classFile.addProblemConstructor(this, this.binding, problemsCopy, problemResetPC);
/*     */         } 
/*     */         return;
/*     */       } 
/*     */     }  } public void generateSyntheticFieldInitializationsIfNecessary(MethodScope methodScope, CodeStream codeStream, ReferenceBinding declaringClass) {
/* 349 */     if (!declaringClass.isNestedType())
/*     */       return; 
/* 351 */     NestedTypeBinding nestedType = (NestedTypeBinding)declaringClass;
/*     */     
/* 353 */     SyntheticArgumentBinding[] syntheticArgs = nestedType.syntheticEnclosingInstances();
/* 354 */     if (syntheticArgs != null) {
/* 355 */       for (int i = 0, max = syntheticArgs.length; i < max; i++) {
/*     */         SyntheticArgumentBinding syntheticArg;
/* 357 */         if ((syntheticArg = syntheticArgs[i]).matchingField != null) {
/* 358 */           codeStream.aload_0();
/* 359 */           codeStream.load((LocalVariableBinding)syntheticArg);
/* 360 */           codeStream.fieldAccess((byte)-75, syntheticArg.matchingField, null);
/*     */         } 
/*     */       } 
/*     */     }
/* 364 */     syntheticArgs = nestedType.syntheticOuterLocalVariables();
/* 365 */     if (syntheticArgs != null) {
/* 366 */       for (int i = 0, max = syntheticArgs.length; i < max; i++) {
/*     */         SyntheticArgumentBinding syntheticArg;
/* 368 */         if ((syntheticArg = syntheticArgs[i]).matchingField != null) {
/* 369 */           codeStream.aload_0();
/* 370 */           codeStream.load((LocalVariableBinding)syntheticArg);
/* 371 */           codeStream.fieldAccess((byte)-75, syntheticArg.matchingField, null);
/*     */         } 
/*     */       } 
/*     */     }
/*     */   }
/*     */   
/*     */   private void internalGenerateCode(ClassScope classScope, ClassFile classFile) {
/* 378 */     classFile.generateMethodInfoHeader(this.binding);
/* 379 */     int methodAttributeOffset = classFile.contentsOffset;
/* 380 */     int attributeNumber = classFile.generateMethodInfoAttributes(this.binding);
/* 381 */     if (!this.binding.isNative() && !this.binding.isAbstract()) {
/*     */       
/* 383 */       TypeDeclaration declaringType = classScope.referenceContext;
/* 384 */       int codeAttributeOffset = classFile.contentsOffset;
/* 385 */       classFile.generateCodeAttributeHeader();
/* 386 */       CodeStream codeStream = classFile.codeStream;
/* 387 */       codeStream.reset(this, classFile);
/*     */ 
/*     */       
/* 390 */       ReferenceBinding declaringClass = this.binding.declaringClass;
/*     */       
/* 392 */       int enumOffset = declaringClass.isEnum() ? 2 : 0;
/* 393 */       int argSlotSize = 1 + enumOffset;
/*     */       
/* 395 */       if (declaringClass.isNestedType()) {
/* 396 */         this.scope.extraSyntheticArguments = declaringClass.syntheticOuterLocalVariables();
/* 397 */         this.scope.computeLocalVariablePositions(
/* 398 */             declaringClass.getEnclosingInstancesSlotSize() + 1 + enumOffset, 
/* 399 */             codeStream);
/* 400 */         argSlotSize += declaringClass.getEnclosingInstancesSlotSize();
/* 401 */         argSlotSize += declaringClass.getOuterLocalVariablesSlotSize();
/*     */       } else {
/* 403 */         this.scope.computeLocalVariablePositions(1 + enumOffset, codeStream);
/*     */       } 
/*     */       
/* 406 */       if (this.arguments != null) {
/* 407 */         for (int i = 0, max = this.arguments.length; i < max; i++) {
/*     */           LocalVariableBinding argBinding;
/*     */           
/* 410 */           codeStream.addVisibleLocalVariable(argBinding = (this.arguments[i]).binding);
/* 411 */           argBinding.recordInitializationStartPC(0);
/* 412 */           switch (argBinding.type.id) {
/*     */             case 7:
/*     */             case 8:
/* 415 */               argSlotSize += 2;
/*     */               break;
/*     */             default:
/* 418 */               argSlotSize++;
/*     */               break;
/*     */           } 
/*     */         
/*     */         } 
/*     */       }
/* 424 */       MethodScope initializerScope = declaringType.initializerScope;
/* 425 */       initializerScope.computeLocalVariablePositions(argSlotSize, codeStream);
/*     */       
/* 427 */       boolean needFieldInitializations = !(this.constructorCall != null && this.constructorCall.accessMode == 3);
/*     */ 
/*     */       
/* 430 */       boolean preInitSyntheticFields = ((this.scope.compilerOptions()).targetJDK >= 3145728L);
/*     */       
/* 432 */       if (needFieldInitializations && preInitSyntheticFields) {
/* 433 */         generateSyntheticFieldInitializationsIfNecessary(this.scope, codeStream, declaringClass);
/* 434 */         codeStream.recordPositionsFrom(0, (this.bodyStart > 0) ? this.bodyStart : this.sourceStart);
/*     */       } 
/*     */       
/* 437 */       if (this.constructorCall != null) {
/* 438 */         this.constructorCall.generateCode((BlockScope)this.scope, codeStream);
/*     */       }
/*     */       
/* 441 */       if (needFieldInitializations) {
/* 442 */         if (!preInitSyntheticFields) {
/* 443 */           generateSyntheticFieldInitializationsIfNecessary(this.scope, codeStream, declaringClass);
/*     */         }
/*     */         
/* 446 */         if (declaringType.fields != null) {
/* 447 */           for (int i = 0, max = declaringType.fields.length; i < max; i++) {
/*     */             FieldDeclaration fieldDecl;
/* 449 */             if (!(fieldDecl = declaringType.fields[i]).isStatic()) {
/* 450 */               fieldDecl.generateCode((BlockScope)initializerScope, codeStream);
/*     */             }
/*     */           } 
/*     */         }
/*     */       } 
/*     */       
/* 456 */       if (this.statements != null) {
/* 457 */         for (int i = 0, max = this.statements.length; i < max; i++) {
/* 458 */           this.statements[i].generateCode((BlockScope)this.scope, codeStream);
/*     */         }
/*     */       }
/*     */       
/* 462 */       if (this.ignoreFurtherInvestigation) {
/* 463 */         throw new AbortMethod((this.scope.referenceCompilationUnit()).compilationResult, null);
/*     */       }
/* 465 */       if ((this.bits & 0x40) != 0) {
/* 466 */         codeStream.return_();
/*     */       }
/*     */       
/* 469 */       codeStream.exitUserScope((BlockScope)this.scope);
/* 470 */       codeStream.recordPositionsFrom(0, (this.bodyEnd > 0) ? this.bodyEnd : this.sourceStart);
/*     */       try {
/* 472 */         classFile.completeCodeAttribute(codeAttributeOffset, this.scope);
/* 473 */       } catch (NegativeArraySizeException negativeArraySizeException) {
/* 474 */         throw new AbortMethod((this.scope.referenceCompilationUnit()).compilationResult, null);
/*     */       } 
/* 476 */       attributeNumber++;
/* 477 */       if (codeStream instanceof StackMapFrameCodeStream && 
/* 478 */         needFieldInitializations && 
/* 479 */         declaringType.fields != null) {
/* 480 */         ((StackMapFrameCodeStream)codeStream).resetSecretLocals();
/*     */       }
/*     */     } 
/* 483 */     classFile.completeMethodInfo(this.binding, methodAttributeOffset, attributeNumber);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected AnnotationBinding[][] getPropagatedRecordComponentAnnotations() {
/* 489 */     if ((this.bits & 0x600) == 0)
/* 490 */       return null; 
/* 491 */     if (this.binding == null)
/* 492 */       return null; 
/* 493 */     AnnotationBinding[][] paramAnnotations = null;
/* 494 */     ReferenceBinding declaringClass = this.binding.declaringClass;
/* 495 */     if (declaringClass instanceof SourceTypeBinding) {
/* 496 */       assert declaringClass.isRecord();
/* 497 */       RecordComponentBinding[] rcbs = ((SourceTypeBinding)declaringClass).components();
/* 498 */       for (int i = 0, length = rcbs.length; i < length; i++) {
/* 499 */         RecordComponentBinding rcb = rcbs[i];
/* 500 */         RecordComponent recordComponent = rcb.sourceRecordComponent();
/* 501 */         long rcMask = 9007749010554880L;
/* 502 */         List<AnnotationBinding> relevantAnnotationBindings = new ArrayList<>();
/* 503 */         Annotation[] relevantAnnotations = ASTNode.getRelevantAnnotations(recordComponent.annotations, rcMask, relevantAnnotationBindings);
/* 504 */         if (relevantAnnotations != null) {
/* 505 */           if (paramAnnotations == null) {
/* 506 */             paramAnnotations = new AnnotationBinding[length][];
/* 507 */             for (int j = 0; j < i; j++) {
/* 508 */               paramAnnotations[j] = Binding.NO_ANNOTATIONS;
/*     */             }
/*     */           } 
/* 511 */           this.binding.tagBits |= 0x400L;
/* 512 */           paramAnnotations[i] = relevantAnnotationBindings.<AnnotationBinding>toArray(new AnnotationBinding[0]);
/* 513 */         } else if (paramAnnotations != null) {
/* 514 */           paramAnnotations[i] = Binding.NO_ANNOTATIONS;
/*     */         } 
/*     */       } 
/*     */     } 
/* 518 */     return paramAnnotations;
/*     */   }
/*     */ 
/*     */   
/*     */   public void getAllAnnotationContexts(int targetType, List<AnnotationContext> allAnnotationContexts) {
/* 523 */     TypeReference fakeReturnType = new SingleTypeReference(this.selector, 0L);
/* 524 */     fakeReturnType.resolvedType = (TypeBinding)this.binding.declaringClass;
/* 525 */     TypeReference.AnnotationCollector collector = new TypeReference.AnnotationCollector(fakeReturnType, targetType, allAnnotationContexts);
/* 526 */     for (int i = 0, max = this.annotations.length; i < max; i++) {
/* 527 */       Annotation annotation = this.annotations[i];
/* 528 */       annotation.traverse(collector, (BlockScope)null);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isConstructor() {
/* 534 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isCanonicalConstructor() {
/* 539 */     return ((this.bits & 0x200) != 0);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isDefaultConstructor() {
/* 544 */     return ((this.bits & 0x80) != 0);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isInitializationMethod() {
/* 549 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isRecursive(ArrayList<ConstructorDeclaration> visited) {
/* 558 */     if (this.binding == null || 
/* 559 */       this.constructorCall == null || 
/* 560 */       this.constructorCall.binding == null || 
/* 561 */       this.constructorCall.isSuperAccess() || 
/* 562 */       !this.constructorCall.binding.isValidBinding()) {
/* 563 */       return false;
/*     */     }
/*     */     
/* 566 */     ConstructorDeclaration targetConstructor = 
/* 567 */       (ConstructorDeclaration)this.scope.referenceType().declarationOf(this.constructorCall.binding.original());
/* 568 */     if (targetConstructor == null) return false; 
/* 569 */     if (this == targetConstructor) return true;
/*     */     
/* 571 */     if (visited == null) {
/* 572 */       visited = new ArrayList(1);
/*     */     } else {
/* 574 */       int index = visited.indexOf(this);
/* 575 */       if (index >= 0) return (index == 0); 
/*     */     } 
/* 577 */     visited.add(this);
/*     */     
/* 579 */     return targetConstructor.isRecursive(visited);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void parseStatements(Parser parser, CompilationUnitDeclaration unit) {
/* 585 */     if ((this.bits & 0x80) != 0 && this.constructorCall == null) {
/* 586 */       this.constructorCall = SuperReference.implicitSuperConstructorCall();
/* 587 */       this.constructorCall.sourceStart = this.sourceStart;
/* 588 */       this.constructorCall.sourceEnd = this.sourceEnd;
/*     */       return;
/*     */     } 
/* 591 */     parser.parse(this, unit, false);
/* 592 */     this.containsSwitchWithTry = parser.switchWithTry;
/*     */   }
/*     */ 
/*     */   
/*     */   public StringBuffer printBody(int indent, StringBuffer output) {
/* 597 */     output.append(" {");
/* 598 */     if (this.constructorCall != null) {
/* 599 */       output.append('\n');
/* 600 */       this.constructorCall.printStatement(indent, output);
/*     */     } 
/* 602 */     if (this.statements != null) {
/* 603 */       for (int i = 0; i < this.statements.length; i++) {
/* 604 */         output.append('\n');
/* 605 */         this.statements[i].printStatement(indent, output);
/*     */       } 
/*     */     }
/* 608 */     output.append('\n');
/* 609 */     printIndent((indent == 0) ? 0 : (indent - 1), output).append('}');
/* 610 */     return output;
/*     */   }
/*     */ 
/*     */   
/*     */   public void resolveJavadoc() {
/* 615 */     if (this.binding == null || this.javadoc != null) {
/* 616 */       super.resolveJavadoc();
/* 617 */     } else if ((this.bits & 0x80) == 0) {
/* 618 */       if ((this.bits & 0x400) != 0)
/* 619 */         return;  if (this.binding.declaringClass != null && !this.binding.declaringClass.isLocalType()) {
/*     */         
/* 621 */         int javadocVisibility = this.binding.modifiers & 0x7;
/* 622 */         ClassScope classScope = this.scope.classScope();
/* 623 */         ProblemReporter reporter = this.scope.problemReporter();
/* 624 */         int severity = reporter.computeSeverity(-1610612250);
/* 625 */         if (severity != 256) {
/* 626 */           if (classScope != null) {
/* 627 */             javadocVisibility = Util.computeOuterMostVisibility(classScope.referenceType(), javadocVisibility);
/*     */           }
/* 629 */           int javadocModifiers = this.binding.modifiers & 0xFFFFFFF8 | javadocVisibility;
/* 630 */           reporter.javadocMissing(this.sourceStart, this.sourceEnd, severity, javadocModifiers);
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void resolveStatements() {
/* 642 */     SourceTypeBinding sourceType = this.scope.enclosingSourceType();
/* 643 */     if (!CharOperation.equals(sourceType.sourceName, this.selector)) {
/* 644 */       this.scope.problemReporter().missingReturnType(this);
/*     */     }
/*     */     
/* 647 */     if (this.binding != null && !this.binding.isPrivate()) {
/* 648 */       sourceType.tagBits |= 0x1000000000000000L;
/*     */     }
/*     */     
/* 651 */     if (this.constructorCall != null) {
/* 652 */       if (sourceType.id == 1 && 
/* 653 */         this.constructorCall.accessMode != 3) {
/*     */         
/* 655 */         if (this.constructorCall.accessMode == 2) {
/* 656 */           this.scope.problemReporter().cannotUseSuperInJavaLangObject(this.constructorCall);
/*     */         }
/* 658 */         this.constructorCall = null;
/* 659 */       } else if (sourceType.isRecord() && 
/* 660 */         !(this instanceof CompactConstructorDeclaration) && 
/* 661 */         this.binding != null && !this.binding.isCanonicalConstructor() && 
/* 662 */         this.constructorCall.accessMode != 3) {
/* 663 */         this.scope.problemReporter().recordMissingExplicitConstructorCallInNonCanonicalConstructor(this);
/* 664 */         this.constructorCall = null;
/*     */       } else {
/*     */         
/* 667 */         this.constructorCall.resolve((BlockScope)this.scope);
/*     */       } 
/*     */     }
/* 670 */     if ((this.modifiers & 0x1000000) != 0) {
/* 671 */       this.scope.problemReporter().methodNeedBody(this);
/*     */     }
/* 673 */     super.resolveStatements();
/*     */   }
/*     */ 
/*     */   
/*     */   public void traverse(ASTVisitor visitor, ClassScope classScope) {
/* 678 */     if (visitor.visit(this, classScope)) {
/* 679 */       if (this.javadoc != null) {
/* 680 */         this.javadoc.traverse(visitor, (BlockScope)this.scope);
/*     */       }
/* 682 */       if (this.annotations != null) {
/* 683 */         int annotationsLength = this.annotations.length;
/* 684 */         for (int i = 0; i < annotationsLength; i++)
/* 685 */           this.annotations[i].traverse(visitor, (BlockScope)this.scope); 
/*     */       } 
/* 687 */       if (this.typeParameters != null) {
/* 688 */         int typeParametersLength = this.typeParameters.length;
/* 689 */         for (int i = 0; i < typeParametersLength; i++) {
/* 690 */           this.typeParameters[i].traverse(visitor, (BlockScope)this.scope);
/*     */         }
/*     */       } 
/* 693 */       if (this.arguments != null) {
/* 694 */         int argumentLength = this.arguments.length;
/* 695 */         for (int i = 0; i < argumentLength; i++)
/* 696 */           this.arguments[i].traverse(visitor, (BlockScope)this.scope); 
/*     */       } 
/* 698 */       if (this.thrownExceptions != null) {
/* 699 */         int thrownExceptionsLength = this.thrownExceptions.length;
/* 700 */         for (int i = 0; i < thrownExceptionsLength; i++)
/* 701 */           this.thrownExceptions[i].traverse(visitor, (BlockScope)this.scope); 
/*     */       } 
/* 703 */       if (this.constructorCall != null)
/* 704 */         this.constructorCall.traverse(visitor, (BlockScope)this.scope); 
/* 705 */       if (this.statements != null) {
/* 706 */         int statementsLength = this.statements.length;
/* 707 */         for (int i = 0; i < statementsLength; i++)
/* 708 */           this.statements[i].traverse(visitor, (BlockScope)this.scope); 
/*     */       } 
/*     */     } 
/* 711 */     visitor.endVisit(this, classScope);
/*     */   }
/*     */   
/*     */   public TypeParameter[] typeParameters() {
/* 715 */     return this.typeParameters;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\ast\ConstructorDeclaration.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */