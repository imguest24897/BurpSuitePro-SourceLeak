/*     */ package org.eclipse.jdt.internal.compiler.ast;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import java.util.Comparator;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import org.eclipse.jdt.core.compiler.CategorizedProblem;
/*     */ import org.eclipse.jdt.core.compiler.CharOperation;
/*     */ import org.eclipse.jdt.internal.compiler.ASTVisitor;
/*     */ import org.eclipse.jdt.internal.compiler.ClassFile;
/*     */ import org.eclipse.jdt.internal.compiler.CompilationResult;
/*     */ import org.eclipse.jdt.internal.compiler.env.ICompilationUnit;
/*     */ import org.eclipse.jdt.internal.compiler.impl.CompilerOptions;
/*     */ import org.eclipse.jdt.internal.compiler.impl.Constant;
/*     */ import org.eclipse.jdt.internal.compiler.impl.IrritantSet;
/*     */ import org.eclipse.jdt.internal.compiler.impl.ReferenceContext;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.BlockScope;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.CompilationUnitScope;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.ImportBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.LocalTypeBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.LookupEnvironment;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.MethodBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.MethodScope;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.ModuleBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.Scope;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.SourceModuleBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.Substitution;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.TypeConstants;
/*     */ import org.eclipse.jdt.internal.compiler.parser.NLSTag;
/*     */ import org.eclipse.jdt.internal.compiler.problem.AbortCompilationUnit;
/*     */ import org.eclipse.jdt.internal.compiler.problem.AbortMethod;
/*     */ import org.eclipse.jdt.internal.compiler.problem.AbortType;
/*     */ import org.eclipse.jdt.internal.compiler.problem.ProblemReporter;
/*     */ import org.eclipse.jdt.internal.compiler.problem.ProblemSeverities;
/*     */ import org.eclipse.jdt.internal.compiler.util.HashSetOfInt;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CompilationUnitDeclaration
/*     */   extends ASTNode
/*     */   implements ProblemSeverities, ReferenceContext
/*     */ {
/*  63 */   private static final Comparator STRING_LITERAL_COMPARATOR = new Comparator()
/*     */     {
/*     */       public int compare(Object o1, Object o2) {
/*  66 */         StringLiteral literal1 = (StringLiteral)o1;
/*  67 */         StringLiteral literal2 = (StringLiteral)o2;
/*  68 */         return literal1.sourceStart - literal2.sourceStart;
/*     */       }
/*     */     };
/*     */ 
/*     */   
/*     */   private static final int STRING_LITERALS_INCREMENT = 10;
/*     */   
/*     */   public ImportReference currentPackage;
/*     */   public ImportReference[] imports;
/*     */   public TypeDeclaration[] types;
/*     */   public ModuleDeclaration moduleDeclaration;
/*     */   public int[][] comments;
/*     */   public boolean ignoreFurtherInvestigation = false;
/*     */   public boolean ignoreMethodBodies = false;
/*     */   public CompilationUnitScope scope;
/*     */   public ProblemReporter problemReporter;
/*     */   public CompilationResult compilationResult;
/*  85 */   public Map<Integer, LocalTypeBinding> localTypes = Collections.emptyMap();
/*     */   
/*     */   public boolean isPropagatingInnerClassEmulation;
/*     */   
/*     */   public Javadoc javadoc;
/*     */   
/*     */   public NLSTag[] nlsTags;
/*     */   
/*     */   private StringLiteral[] stringLiterals;
/*     */   
/*     */   private int stringLiteralsPtr;
/*     */   private HashSetOfInt stringLiteralsStart;
/*     */   public boolean[] validIdentityComparisonLines;
/*     */   IrritantSet[] suppressWarningIrritants;
/*     */   Annotation[] suppressWarningAnnotations;
/*     */   long[] suppressWarningScopePositions;
/*     */   int suppressWarningsCount;
/*     */   public int functionalExpressionsCount;
/*     */   public FunctionalExpression[] functionalExpressions;
/*     */   
/*     */   public CompilationUnitDeclaration(ProblemReporter problemReporter, CompilationResult compilationResult, int sourceLength) {
/* 106 */     this.problemReporter = problemReporter;
/* 107 */     this.compilationResult = compilationResult;
/*     */     
/* 109 */     this.sourceStart = 0;
/* 110 */     this.sourceEnd = sourceLength - 1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void abort(int abortLevel, CategorizedProblem problem) {
/* 118 */     switch (abortLevel) {
/*     */       case 8:
/* 120 */         throw new AbortType(this.compilationResult, problem);
/*     */       case 16:
/* 122 */         throw new AbortMethod(this.compilationResult, problem);
/*     */     } 
/* 124 */     throw new AbortCompilationUnit(this.compilationResult, problem);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void analyseCode() {
/* 132 */     if (this.ignoreFurtherInvestigation)
/*     */       return; 
/*     */     try {
/* 135 */       if (this.types != null) {
/* 136 */         for (int i = 0, count = this.types.length; i < count; i++) {
/* 137 */           this.types[i].analyseCode(this.scope);
/*     */         }
/*     */       }
/* 140 */       if (this.moduleDeclaration != null) {
/* 141 */         this.moduleDeclaration.analyseCode(this.scope);
/*     */       }
/*     */       
/* 144 */       propagateInnerEmulationForAllLocalTypes();
/* 145 */     } catch (AbortCompilationUnit abortCompilationUnit) {
/* 146 */       this.ignoreFurtherInvestigation = true;
/*     */       return;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void cleanUp() {
/* 156 */     if (this.types != null) {
/* 157 */       for (int j = 0, k = this.types.length; j < k; j++) {
/* 158 */         cleanUp(this.types[j]);
/*     */       }
/* 160 */       for (LocalTypeBinding localType : this.localTypes.values()) {
/*     */         
/* 162 */         localType.cleanUp();
/* 163 */         localType.enclosingCase = null;
/*     */       } 
/*     */     } 
/* 166 */     if (this.functionalExpressionsCount > 0) {
/* 167 */       for (int j = 0, k = this.functionalExpressionsCount; j < k; j++) {
/* 168 */         this.functionalExpressions[j].cleanUp();
/*     */       }
/*     */     }
/*     */     
/* 172 */     this.compilationResult.recoveryScannerData = null;
/*     */     
/* 174 */     ClassFile[] classFiles = this.compilationResult.getClassFiles();
/* 175 */     for (int i = 0, max = classFiles.length; i < max; i++) {
/*     */       
/* 177 */       ClassFile classFile = classFiles[i];
/*     */       
/* 179 */       classFile.referenceBinding = null;
/* 180 */       classFile.innerClassesBindings = null;
/* 181 */       classFile.bootstrapMethods = null;
/* 182 */       classFile.missingTypes = null;
/* 183 */       classFile.visitedTypes = null;
/*     */     } 
/*     */     
/* 186 */     this.suppressWarningAnnotations = null;
/*     */     
/* 188 */     if (this.scope != null)
/* 189 */       this.scope.cleanUpInferenceContexts(); 
/*     */   }
/*     */   
/*     */   private void cleanUp(TypeDeclaration type) {
/* 193 */     if (type.memberTypes != null) {
/* 194 */       for (int i = 0, max = type.memberTypes.length; i < max; i++) {
/* 195 */         cleanUp(type.memberTypes[i]);
/*     */       }
/*     */     }
/* 198 */     if (type.binding != null && type.binding.isAnnotationType())
/* 199 */       this.compilationResult.hasAnnotations = true; 
/* 200 */     if (type.binding != null)
/*     */     {
/* 202 */       type.binding.cleanUp();
/*     */     }
/*     */   }
/*     */   
/*     */   public void checkUnusedImports() {
/* 207 */     if (this.scope.imports != null) {
/* 208 */       for (int i = 0, max = this.scope.imports.length; i < max; i++) {
/* 209 */         ImportBinding importBinding = this.scope.imports[i];
/* 210 */         ImportReference importReference = importBinding.reference;
/* 211 */         if (importReference != null && (importReference.bits & 0x2) == 0) {
/* 212 */           this.scope.problemReporter().unusedImport(importReference);
/*     */         }
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public CompilationResult compilationResult() {
/* 220 */     return this.compilationResult;
/*     */   }
/*     */   
/*     */   public void createPackageInfoType() {
/* 224 */     TypeDeclaration declaration = new TypeDeclaration(this.compilationResult);
/* 225 */     declaration.name = TypeConstants.PACKAGE_INFO_NAME;
/* 226 */     declaration.modifiers = 512;
/* 227 */     declaration.javadoc = this.javadoc;
/* 228 */     this.types[0] = declaration;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TypeDeclaration declarationOfType(char[][] typeName) {
/* 238 */     for (int i = 0; i < this.types.length; i++) {
/* 239 */       TypeDeclaration typeDecl = this.types[i].declarationOfType(typeName);
/* 240 */       if (typeDecl != null) {
/* 241 */         return typeDecl;
/*     */       }
/*     */     } 
/* 244 */     return null;
/*     */   }
/*     */   
/*     */   public void finalizeProblems() {
/* 248 */     int problemCount = this.compilationResult.problemCount;
/* 249 */     CategorizedProblem[] problems = this.compilationResult.problems;
/* 250 */     if (this.suppressWarningsCount == 0) {
/*     */       return;
/*     */     }
/* 253 */     int removed = 0;
/* 254 */     IrritantSet[] foundIrritants = new IrritantSet[this.suppressWarningsCount];
/* 255 */     CompilerOptions options = this.scope.compilerOptions();
/* 256 */     boolean hasMandatoryErrors = false;
/* 257 */     for (int iProblem = 0, length = problemCount; iProblem < length; iProblem++) {
/* 258 */       CategorizedProblem problem = problems[iProblem];
/* 259 */       int problemID = problem.getID();
/* 260 */       int irritant = ProblemReporter.getIrritant(problemID);
/* 261 */       boolean isError = problem.isError();
/* 262 */       if (isError) {
/* 263 */         if (irritant == 0) {
/*     */           
/* 265 */           hasMandatoryErrors = true;
/*     */           continue;
/*     */         } 
/* 268 */         if (!options.suppressOptionalErrors) {
/*     */           continue;
/*     */         }
/*     */       } 
/* 272 */       int start = problem.getSourceStart();
/* 273 */       int end = problem.getSourceEnd();
/* 274 */       for (int iSuppress = 0, suppressCount = this.suppressWarningsCount; iSuppress < suppressCount; ) {
/* 275 */         long position = this.suppressWarningScopePositions[iSuppress];
/* 276 */         int startSuppress = (int)(position >>> 32L);
/* 277 */         int endSuppress = (int)position;
/* 278 */         if (start < startSuppress || 
/* 279 */           end > endSuppress || 
/* 280 */           !this.suppressWarningIrritants[iSuppress].isSet(irritant)) {
/*     */           iSuppress++;
/*     */           continue;
/*     */         } 
/* 284 */         removed++;
/* 285 */         problems[iProblem] = null;
/* 286 */         this.compilationResult.removeProblem(problem);
/* 287 */         if (foundIrritants[iSuppress] == null) {
/* 288 */           foundIrritants[iSuppress] = new IrritantSet(irritant); break;
/*     */         } 
/* 290 */         foundIrritants[iSuppress].set(irritant);
/*     */         
/*     */         break;
/*     */       } 
/*     */       continue;
/*     */     } 
/* 296 */     if (removed > 0) {
/* 297 */       for (int i = 0, index = 0; i < problemCount; i++) {
/*     */         CategorizedProblem problem;
/* 299 */         if ((problem = problems[i]) != null) {
/* 300 */           if (i > index) {
/* 301 */             problems[index++] = problem;
/*     */           } else {
/* 303 */             index++;
/*     */           } 
/*     */         }
/*     */       } 
/*     */     }
/*     */     
/* 309 */     if (!hasMandatoryErrors) {
/* 310 */       int severity = options.getSeverity(570425344);
/* 311 */       if (severity != 256) {
/* 312 */         boolean unusedWarningTokenIsWarning = ((severity & 0x1) == 0);
/* 313 */         for (int iSuppress = 0, suppressCount = this.suppressWarningsCount; iSuppress < suppressCount; iSuppress++) {
/* 314 */           Annotation annotation = this.suppressWarningAnnotations[iSuppress];
/* 315 */           if (annotation != null) {
/* 316 */             IrritantSet irritants = this.suppressWarningIrritants[iSuppress];
/* 317 */             if ((!unusedWarningTokenIsWarning || !irritants.areAllSet()) && 
/* 318 */               irritants != foundIrritants[iSuppress]) {
/* 319 */               MemberValuePair[] pairs = annotation.memberValuePairs(); int iPair, pairCount;
/* 320 */               label136: for (iPair = 0, pairCount = pairs.length; iPair < pairCount; iPair++) {
/* 321 */                 MemberValuePair pair = pairs[iPair];
/* 322 */                 if (CharOperation.equals(pair.name, TypeConstants.VALUE)) {
/* 323 */                   Expression value = pair.value;
/* 324 */                   if (value instanceof ArrayInitializer) {
/* 325 */                     ArrayInitializer initializer = (ArrayInitializer)value;
/* 326 */                     Expression[] inits = initializer.expressions;
/* 327 */                     if (inits != null) {
/* 328 */                       for (int iToken = 0, tokenCount = inits.length; iToken < tokenCount; iToken++) {
/* 329 */                         Constant constant = (inits[iToken]).constant;
/* 330 */                         if (constant != Constant.NotAConstant && constant.typeID() == 11) {
/* 331 */                           IrritantSet tokenIrritants = CompilerOptions.warningTokenToIrritants(constant.stringValue());
/* 332 */                           if (tokenIrritants != null && 
/* 333 */                             !tokenIrritants.areAllSet() && (
/* 334 */                             foundIrritants[iSuppress] == null || !foundIrritants[iSuppress].isAnySet(tokenIrritants))) {
/* 335 */                             if (unusedWarningTokenIsWarning) {
/* 336 */                               int start = value.sourceStart, end = value.sourceEnd;
/* 337 */                               for (int jSuppress = iSuppress - 1; jSuppress >= 0; jSuppress--) {
/* 338 */                                 long position = this.suppressWarningScopePositions[jSuppress];
/* 339 */                                 int startSuppress = (int)(position >>> 32L);
/* 340 */                                 int endSuppress = (int)position;
/* 341 */                                 if (start >= startSuppress && 
/* 342 */                                   end <= endSuppress && 
/* 343 */                                   this.suppressWarningIrritants[jSuppress].areAllSet())
/*     */                                   break label136; 
/*     */                               } 
/* 346 */                             }  int id = options.getIgnoredIrritant(tokenIrritants);
/* 347 */                             if (id > 0) {
/* 348 */                               String key = CompilerOptions.optionKeyFromIrritant(id);
/* 349 */                               this.scope.problemReporter().problemNotAnalysed(inits[iToken], key);
/*     */                             } else {
/* 351 */                               this.scope.problemReporter().unusedWarningToken(inits[iToken]);
/*     */                             } 
/*     */                           } 
/*     */                         } 
/*     */                       } 
/*     */                     }
/*     */                     break;
/*     */                   } 
/* 359 */                   Constant cst = value.constant;
/* 360 */                   if (cst != Constant.NotAConstant && cst.typeID() == 11) {
/* 361 */                     IrritantSet tokenIrritants = CompilerOptions.warningTokenToIrritants(cst.stringValue());
/* 362 */                     if (tokenIrritants != null && 
/* 363 */                       !tokenIrritants.areAllSet() && (
/* 364 */                       foundIrritants[iSuppress] == null || !foundIrritants[iSuppress].isAnySet(tokenIrritants))) {
/* 365 */                       if (unusedWarningTokenIsWarning) {
/* 366 */                         int start = value.sourceStart, end = value.sourceEnd;
/* 367 */                         for (int jSuppress = iSuppress - 1; jSuppress >= 0; jSuppress--) {
/* 368 */                           long position = this.suppressWarningScopePositions[jSuppress];
/* 369 */                           int startSuppress = (int)(position >>> 32L);
/* 370 */                           int endSuppress = (int)position;
/* 371 */                           if (start >= startSuppress && 
/* 372 */                             end <= endSuppress && 
/* 373 */                             this.suppressWarningIrritants[jSuppress].areAllSet())
/*     */                             break label136; 
/*     */                         } 
/* 376 */                       }  int id = options.getIgnoredIrritant(tokenIrritants);
/* 377 */                       if (id > 0) {
/* 378 */                         String key = CompilerOptions.optionKeyFromIrritant(id);
/* 379 */                         this.scope.problemReporter().problemNotAnalysed(value, key); break;
/*     */                       } 
/* 381 */                       this.scope.problemReporter().unusedWarningToken(value);
/*     */                     } 
/*     */                   } 
/*     */                   break;
/*     */                 } 
/*     */               } 
/*     */             } 
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void generateCode() {
/* 400 */     if (this.ignoreFurtherInvestigation) {
/* 401 */       if (this.types != null) {
/* 402 */         for (int i = 0, count = this.types.length; i < count; i++) {
/* 403 */           (this.types[i]).ignoreFurtherInvestigation = true;
/*     */           
/* 405 */           this.types[i].generateCode(this.scope);
/*     */         } 
/*     */       }
/*     */       return;
/*     */     } 
/*     */     try {
/* 411 */       if (this.types != null)
/* 412 */         for (int i = 0, count = this.types.length; i < count; i++) {
/* 413 */           this.types[i].generateCode(this.scope);
/*     */         } 
/* 415 */       if (this.moduleDeclaration != null) {
/* 416 */         this.moduleDeclaration.generateCode();
/*     */       }
/* 418 */     } catch (AbortCompilationUnit abortCompilationUnit) {}
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CompilationUnitDeclaration getCompilationUnitDeclaration() {
/* 425 */     return this;
/*     */   }
/*     */   
/*     */   public char[] getFileName() {
/* 429 */     return this.compilationResult.getFileName();
/*     */   }
/*     */   
/*     */   public char[] getMainTypeName() {
/* 433 */     if (this.compilationResult.compilationUnit == null) {
/* 434 */       char[] fileName = this.compilationResult.getFileName();
/*     */       
/* 436 */       int start = CharOperation.lastIndexOf('/', fileName) + 1;
/* 437 */       if (start == 0 || start < CharOperation.lastIndexOf('\\', fileName)) {
/* 438 */         start = CharOperation.lastIndexOf('\\', fileName) + 1;
/*     */       }
/* 440 */       int end = CharOperation.lastIndexOf('.', fileName);
/* 441 */       if (end == -1) {
/* 442 */         end = fileName.length;
/*     */       }
/* 444 */       return CharOperation.subarray(fileName, start, end);
/*     */     } 
/* 446 */     return this.compilationResult.compilationUnit.getMainTypeName();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isEmpty() {
/* 451 */     return (this.currentPackage == null && this.imports == null && this.types == null);
/*     */   }
/*     */   
/*     */   public boolean isPackageInfo() {
/* 455 */     return CharOperation.equals(getMainTypeName(), TypeConstants.PACKAGE_INFO_NAME);
/*     */   }
/*     */   
/*     */   public boolean isModuleInfo() {
/* 459 */     return CharOperation.equals(getMainTypeName(), TypeConstants.MODULE_INFO_NAME);
/*     */   }
/*     */   
/*     */   public boolean isSuppressed(CategorizedProblem problem) {
/* 463 */     if (this.suppressWarningsCount == 0) return false; 
/* 464 */     int irritant = ProblemReporter.getIrritant(problem.getID());
/* 465 */     if (irritant == 0) return false; 
/* 466 */     int start = problem.getSourceStart();
/* 467 */     int end = problem.getSourceEnd();
/* 468 */     for (int iSuppress = 0, suppressCount = this.suppressWarningsCount; iSuppress < suppressCount; iSuppress++) {
/* 469 */       long position = this.suppressWarningScopePositions[iSuppress];
/* 470 */       int startSuppress = (int)(position >>> 32L);
/* 471 */       int endSuppress = (int)position;
/* 472 */       if (start >= startSuppress && 
/* 473 */         end <= endSuppress && 
/* 474 */         this.suppressWarningIrritants[iSuppress].isSet(irritant))
/* 475 */         return true; 
/*     */     } 
/* 477 */     return false;
/*     */   }
/*     */   
/*     */   public boolean hasFunctionalTypes() {
/* 481 */     return this.compilationResult.hasFunctionalTypes;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean hasErrors() {
/* 486 */     return this.ignoreFurtherInvestigation;
/*     */   }
/*     */ 
/*     */   
/*     */   public StringBuffer print(int indent, StringBuffer output) {
/* 491 */     if (this.currentPackage != null) {
/* 492 */       printIndent(indent, output).append("package ");
/* 493 */       this.currentPackage.print(0, output, false).append(";\n");
/*     */     } 
/* 495 */     if (this.imports != null)
/* 496 */       for (int i = 0; i < this.imports.length; i++) {
/* 497 */         printIndent(indent, output).append("import ");
/* 498 */         ImportReference currentImport = this.imports[i];
/* 499 */         if (currentImport.isStatic()) {
/* 500 */           output.append("static ");
/*     */         }
/* 502 */         currentImport.print(0, output).append(";\n");
/*     */       }  
/* 504 */     if (this.moduleDeclaration != null) {
/* 505 */       this.moduleDeclaration.print(indent, output).append("\n");
/* 506 */     } else if (this.types != null) {
/* 507 */       for (int i = 0; i < this.types.length; i++) {
/* 508 */         this.types[i].print(indent, output).append("\n");
/*     */       }
/*     */     } 
/* 511 */     return output;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void propagateInnerEmulationForAllLocalTypes() {
/* 518 */     this.isPropagatingInnerClassEmulation = true;
/* 519 */     for (LocalTypeBinding localType : this.localTypes.values()) {
/*     */       
/* 521 */       if (((localType.scope.referenceType()).bits & Integer.MIN_VALUE) != 0) {
/* 522 */         localType.updateInnerEmulationDependents();
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   public void recordStringLiteral(StringLiteral literal, boolean fromRecovery) {
/* 528 */     if (this.stringLiteralsStart != null) {
/* 529 */       if (this.stringLiteralsStart.contains(literal.sourceStart))
/* 530 */         return;  this.stringLiteralsStart.add(literal.sourceStart);
/* 531 */     } else if (fromRecovery) {
/* 532 */       this.stringLiteralsStart = new HashSetOfInt(this.stringLiteralsPtr + 10);
/* 533 */       for (int i = 0; i < this.stringLiteralsPtr; i++) {
/* 534 */         this.stringLiteralsStart.add((this.stringLiterals[i]).sourceStart);
/*     */       }
/*     */       
/* 537 */       if (this.stringLiteralsStart.contains(literal.sourceStart))
/* 538 */         return;  this.stringLiteralsStart.add(literal.sourceStart);
/*     */     } 
/*     */     
/* 541 */     if (this.stringLiterals == null) {
/* 542 */       this.stringLiterals = new StringLiteral[10];
/* 543 */       this.stringLiteralsPtr = 0;
/*     */     } else {
/* 545 */       int stackLength = this.stringLiterals.length;
/* 546 */       if (this.stringLiteralsPtr == stackLength) {
/* 547 */         System.arraycopy(
/* 548 */             this.stringLiterals, 
/* 549 */             0, 
/* 550 */             this.stringLiterals = new StringLiteral[stackLength + 10], 
/* 551 */             0, 
/* 552 */             stackLength);
/*     */       }
/*     */     } 
/* 555 */     this.stringLiterals[this.stringLiteralsPtr++] = literal;
/*     */   }
/*     */   
/*     */   private boolean isLambdaExpressionCopyContext(ReferenceContext context) {
/* 559 */     if (context instanceof LambdaExpression && context != ((LambdaExpression)context).original())
/* 560 */       return true; 
/* 561 */     Scope cScope = (context instanceof AbstractMethodDeclaration) ? (Scope)((AbstractMethodDeclaration)context).scope : (
/* 562 */       (context instanceof TypeDeclaration) ? (Scope)((TypeDeclaration)context).scope : (
/* 563 */       (context instanceof LambdaExpression) ? (Scope)((LambdaExpression)context).scope : 
/* 564 */       null));
/* 565 */     return (cScope != null) ? isLambdaExpressionCopyContext(cScope.parent.referenceContext()) : false;
/*     */   }
/*     */   public void recordSuppressWarnings(IrritantSet irritants, Annotation annotation, int scopeStart, int scopeEnd, ReferenceContext context) {
/* 568 */     if (isLambdaExpressionCopyContext(context)) {
/*     */       return;
/*     */     }
/* 571 */     if (this.suppressWarningIrritants == null) {
/* 572 */       this.suppressWarningIrritants = new IrritantSet[3];
/* 573 */       this.suppressWarningAnnotations = new Annotation[3];
/* 574 */       this.suppressWarningScopePositions = new long[3];
/* 575 */     } else if (this.suppressWarningIrritants.length == this.suppressWarningsCount) {
/* 576 */       System.arraycopy(this.suppressWarningIrritants, 0, this.suppressWarningIrritants = new IrritantSet[2 * this.suppressWarningsCount], 0, this.suppressWarningsCount);
/* 577 */       System.arraycopy(this.suppressWarningAnnotations, 0, this.suppressWarningAnnotations = new Annotation[2 * this.suppressWarningsCount], 0, this.suppressWarningsCount);
/* 578 */       System.arraycopy(this.suppressWarningScopePositions, 0, this.suppressWarningScopePositions = new long[2 * this.suppressWarningsCount], 0, this.suppressWarningsCount);
/*     */     } 
/* 580 */     long scopePositions = (scopeStart << 32L) + scopeEnd;
/* 581 */     for (int i = 0, max = this.suppressWarningsCount; i < max; i++) {
/* 582 */       if (this.suppressWarningAnnotations[i] == annotation && 
/* 583 */         this.suppressWarningScopePositions[i] == scopePositions && 
/* 584 */         this.suppressWarningIrritants[i].hasSameIrritants(irritants)) {
/*     */         return;
/*     */       }
/*     */     } 
/*     */     
/* 589 */     this.suppressWarningIrritants[this.suppressWarningsCount] = irritants;
/* 590 */     this.suppressWarningAnnotations[this.suppressWarningsCount] = annotation;
/* 591 */     this.suppressWarningScopePositions[this.suppressWarningsCount++] = scopePositions;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void record(LocalTypeBinding localType) {
/* 599 */     if (this.localTypes == Collections.EMPTY_MAP)
/* 600 */       this.localTypes = new HashMap<>(); 
/* 601 */     this.localTypes.put(Integer.valueOf(localType.sourceStart), localType);
/*     */   }
/*     */   public void updateLocalTypesInMethod(MethodBinding methodBinding) {
/* 604 */     if (this.localTypes == Collections.EMPTY_MAP)
/*     */       return; 
/* 606 */     LambdaExpression.updateLocalTypesInMethod(methodBinding, new LambdaExpression.LocalTypeSubstitutor(this.localTypes, methodBinding), (Substitution)new Substitution.NullSubstitution(this.scope.environment()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int record(FunctionalExpression expression) {
/* 614 */     if (this.functionalExpressionsCount == 0) {
/* 615 */       this.functionalExpressions = new FunctionalExpression[5];
/* 616 */     } else if (this.functionalExpressionsCount == this.functionalExpressions.length) {
/* 617 */       System.arraycopy(this.functionalExpressions, 0, this.functionalExpressions = new FunctionalExpression[this.functionalExpressionsCount * 2], 0, this.functionalExpressionsCount);
/*     */     } 
/* 619 */     this.functionalExpressions[this.functionalExpressionsCount++] = expression;
/* 620 */     return (expression.enclosingScope.classScope()).referenceContext.record(expression);
/*     */   }
/*     */   
/*     */   public void resolve() {
/* 624 */     int startingTypeIndex = 0;
/* 625 */     boolean isPackageInfo = isPackageInfo();
/* 626 */     boolean isModuleInfo = isModuleInfo();
/* 627 */     if (this.types != null && isPackageInfo) {
/*     */       
/* 629 */       TypeDeclaration syntheticTypeDeclaration = this.types[0];
/*     */       
/* 631 */       if (syntheticTypeDeclaration.javadoc == null) {
/* 632 */         syntheticTypeDeclaration.javadoc = new Javadoc(syntheticTypeDeclaration.declarationSourceStart, syntheticTypeDeclaration.declarationSourceStart);
/*     */       }
/* 634 */       syntheticTypeDeclaration.resolve(this.scope);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 641 */       if (this.javadoc != null && syntheticTypeDeclaration.staticInitializerScope != null) {
/* 642 */         this.javadoc.resolve(syntheticTypeDeclaration.staticInitializerScope);
/*     */       }
/* 644 */       startingTypeIndex = 1;
/* 645 */     } else if (this.moduleDeclaration != null && isModuleInfo) {
/* 646 */       if (this.javadoc != null) {
/* 647 */         this.javadoc.resolve(this.moduleDeclaration.scope);
/* 648 */       } else if (this.moduleDeclaration.binding != null) {
/* 649 */         ProblemReporter reporter = this.scope.problemReporter();
/* 650 */         int severity = reporter.computeSeverity(-1610612250);
/* 651 */         if (severity != 256) {
/* 652 */           reporter.javadocModuleMissing(this.moduleDeclaration.declarationSourceStart, this.moduleDeclaration.bodyStart, 
/* 653 */               severity);
/*     */         }
/*     */       }
/*     */     
/*     */     }
/* 658 */     else if (this.javadoc != null) {
/* 659 */       this.javadoc.resolve(this.scope);
/*     */     } 
/*     */     
/* 662 */     if (this.currentPackage != null && this.currentPackage.annotations != null && !isPackageInfo) {
/* 663 */       this.scope.problemReporter().invalidFileNameForPackageAnnotations(this.currentPackage.annotations[0]);
/*     */     }
/*     */     try {
/* 666 */       if (this.types != null) {
/* 667 */         for (int i = startingTypeIndex, count = this.types.length; i < count; i++) {
/* 668 */           this.types[i].resolve(this.scope);
/*     */         }
/*     */       }
/* 671 */       if (!this.compilationResult.hasMandatoryErrors()) checkUnusedImports(); 
/* 672 */       reportNLSProblems();
/* 673 */     } catch (AbortCompilationUnit abortCompilationUnit) {
/* 674 */       this.ignoreFurtherInvestigation = true;
/*     */       return;
/*     */     } 
/*     */   }
/*     */   
/*     */   private void reportNLSProblems() {
/* 680 */     if (this.nlsTags != null || this.stringLiterals != null) {
/* 681 */       int stringLiteralsLength = this.stringLiteralsPtr;
/* 682 */       int nlsTagsLength = (this.nlsTags == null) ? 0 : this.nlsTags.length;
/* 683 */       if (stringLiteralsLength == 0) {
/* 684 */         if (nlsTagsLength != 0) {
/* 685 */           for (int i = 0; i < nlsTagsLength; i++) {
/* 686 */             NLSTag tag = this.nlsTags[i];
/* 687 */             if (tag != null) {
/* 688 */               this.scope.problemReporter().unnecessaryNLSTags(tag.start, tag.end);
/*     */             }
/*     */           } 
/*     */         }
/* 692 */       } else if (nlsTagsLength == 0) {
/*     */         
/* 694 */         if (this.stringLiterals.length != stringLiteralsLength) {
/* 695 */           System.arraycopy(this.stringLiterals, 0, this.stringLiterals = new StringLiteral[stringLiteralsLength], 0, stringLiteralsLength);
/*     */         }
/* 697 */         Arrays.sort(this.stringLiterals, STRING_LITERAL_COMPARATOR);
/* 698 */         for (int i = 0; i < stringLiteralsLength; i++) {
/* 699 */           this.scope.problemReporter().nonExternalizedStringLiteral(this.stringLiterals[i]);
/*     */         }
/*     */       } else {
/*     */         
/* 703 */         if (this.stringLiterals.length != stringLiteralsLength) {
/* 704 */           System.arraycopy(this.stringLiterals, 0, this.stringLiterals = new StringLiteral[stringLiteralsLength], 0, stringLiteralsLength);
/*     */         }
/* 706 */         Arrays.sort(this.stringLiterals, STRING_LITERAL_COMPARATOR);
/* 707 */         int indexInLine = 1;
/* 708 */         int lastLineNumber = -1;
/* 709 */         StringLiteral literal = null;
/* 710 */         int index = 0;
/* 711 */         int i = 0;
/* 712 */         while (i < stringLiteralsLength) {
/* 713 */           literal = this.stringLiterals[i];
/* 714 */           int literalLineNumber = (literal instanceof TextBlock) ? ((TextBlock)literal).endLineNumber : literal.lineNumber;
/* 715 */           if (lastLineNumber != literalLineNumber) {
/* 716 */             indexInLine = 1;
/* 717 */             lastLineNumber = literalLineNumber;
/*     */           } else {
/* 719 */             indexInLine++;
/*     */           } 
/* 721 */           if (index < nlsTagsLength)
/* 722 */             for (; index < nlsTagsLength; index++) {
/* 723 */               NLSTag tag = this.nlsTags[index];
/* 724 */               if (tag != null) {
/* 725 */                 int tagLineNumber = tag.lineNumber;
/* 726 */                 if (literalLineNumber < tagLineNumber) {
/* 727 */                   this.scope.problemReporter().nonExternalizedStringLiteral(literal); // Byte code: goto -> 492
/*     */                 } 
/* 729 */                 if (literalLineNumber == tagLineNumber)
/* 730 */                 { if (tag.index == indexInLine) {
/* 731 */                     this.nlsTags[index] = null;
/* 732 */                     index++;
/*     */                     // Byte code: goto -> 492
/*     */                   } 
/* 735 */                   int index2 = index + 1; while (true) { if (index2 >= nlsTagsLength)
/*     */                     
/*     */                     { 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */                       
/* 751 */                       this.scope.problemReporter().nonExternalizedStringLiteral(literal); break; }  NLSTag tag2 = this.nlsTags[index2]; if (tag2 != null) { int tagLineNumber2 = tag2.lineNumber; if (literalLineNumber == tagLineNumber2) { if (tag2.index == indexInLine) { this.nlsTags[index2] = null; break; }  } else { this.scope.problemReporter().nonExternalizedStringLiteral(literal); break; }
/*     */                        }
/*     */                      index2++; }
/*     */                    }
/* 755 */                 else { this.scope.problemReporter().unnecessaryNLSTags(tag.start, tag.end); index++; }
/*     */                 
/*     */                 i++;
/*     */                 continue;
/*     */               } 
/*     */             }  
/*     */           break;
/*     */         } 
/* 763 */         for (; i < stringLiteralsLength; i++) {
/* 764 */           this.scope.problemReporter().nonExternalizedStringLiteral(this.stringLiterals[i]);
/*     */         }
/* 766 */         if (index < nlsTagsLength) {
/* 767 */           for (; index < nlsTagsLength; index++) {
/* 768 */             NLSTag tag = this.nlsTags[index];
/* 769 */             if (tag != null) {
/* 770 */               this.scope.problemReporter().unnecessaryNLSTags(tag.start, tag.end);
/*     */             }
/*     */           } 
/*     */         }
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void tagAsHavingErrors() {
/* 780 */     this.ignoreFurtherInvestigation = true;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void tagAsHavingIgnoredMandatoryErrors(int problemId) {}
/*     */ 
/*     */   
/*     */   public void traverse(ASTVisitor visitor, CompilationUnitScope unitScope) {
/* 789 */     traverse(visitor, unitScope, true);
/*     */   }
/*     */   public void traverse(ASTVisitor visitor, CompilationUnitScope unitScope, boolean skipOnError) {
/* 792 */     if (skipOnError && this.ignoreFurtherInvestigation)
/*     */       return; 
/*     */     try {
/* 795 */       if (visitor.visit(this, this.scope)) {
/* 796 */         if (this.types != null && isPackageInfo()) {
/*     */           
/* 798 */           TypeDeclaration syntheticTypeDeclaration = this.types[0];
/*     */           
/* 800 */           MethodScope methodScope = syntheticTypeDeclaration.staticInitializerScope;
/*     */           
/* 802 */           if (this.javadoc != null && methodScope != null) {
/* 803 */             this.javadoc.traverse(visitor, (BlockScope)methodScope);
/*     */           }
/*     */           
/* 806 */           if (this.currentPackage != null && methodScope != null) {
/* 807 */             Annotation[] annotations = this.currentPackage.annotations;
/* 808 */             if (annotations != null) {
/* 809 */               int annotationsLength = annotations.length;
/* 810 */               for (int i = 0; i < annotationsLength; i++) {
/* 811 */                 annotations[i].traverse(visitor, (BlockScope)methodScope);
/*     */               }
/*     */             } 
/*     */           } 
/*     */         } 
/* 816 */         if (this.currentPackage != null) {
/* 817 */           this.currentPackage.traverse(visitor, this.scope);
/*     */         }
/* 819 */         if (this.imports != null) {
/* 820 */           int importLength = this.imports.length;
/* 821 */           for (int i = 0; i < importLength; i++) {
/* 822 */             this.imports[i].traverse(visitor, this.scope);
/*     */           }
/*     */         } 
/* 825 */         if (this.types != null) {
/* 826 */           int typesLength = this.types.length;
/* 827 */           for (int i = 0; i < typesLength; i++) {
/* 828 */             this.types[i].traverse(visitor, this.scope);
/*     */           }
/*     */         } 
/* 831 */         if (isModuleInfo() && this.moduleDeclaration != null) {
/* 832 */           this.moduleDeclaration.traverse(visitor, this.scope);
/*     */         }
/*     */       } 
/* 835 */       visitor.endVisit(this, this.scope);
/* 836 */     } catch (AbortCompilationUnit abortCompilationUnit) {}
/*     */   }
/*     */ 
/*     */   
/*     */   public ModuleBinding module(LookupEnvironment environment) {
/* 841 */     if (this.moduleDeclaration != null) {
/* 842 */       SourceModuleBinding sourceModuleBinding = this.moduleDeclaration.binding;
/* 843 */       if (sourceModuleBinding != null)
/* 844 */         return (ModuleBinding)sourceModuleBinding; 
/*     */     } 
/* 846 */     if (this.compilationResult != null) {
/* 847 */       ICompilationUnit compilationUnit = this.compilationResult.compilationUnit;
/* 848 */       if (compilationUnit != null)
/* 849 */         return compilationUnit.module(environment); 
/*     */     } 
/* 851 */     return environment.module;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\ast\CompilationUnitDeclaration.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */