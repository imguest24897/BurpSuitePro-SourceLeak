/*     */ package org.eclipse.jdt.internal.compiler.ast;
/*     */ 
/*     */ import java.util.List;
/*     */ import org.eclipse.jdt.internal.compiler.ASTVisitor;
/*     */ import org.eclipse.jdt.internal.compiler.codegen.AnnotationContext;
/*     */ import org.eclipse.jdt.internal.compiler.codegen.CodeStream;
/*     */ import org.eclipse.jdt.internal.compiler.flow.FlowContext;
/*     */ import org.eclipse.jdt.internal.compiler.flow.FlowInfo;
/*     */ import org.eclipse.jdt.internal.compiler.impl.Constant;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.ArrayBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.BlockScope;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.Scope;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.TypeBinding;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ArrayAllocationExpression
/*     */   extends Expression
/*     */ {
/*     */   public TypeReference type;
/*     */   public Expression[] dimensions;
/*     */   public Annotation[][] annotationsOnDimensions;
/*     */   public ArrayInitializer initializer;
/*     */   
/*     */   public FlowInfo analyseCode(BlockScope currentScope, FlowContext flowContext, FlowInfo flowInfo) {
/*  46 */     for (int i = 0, max = this.dimensions.length; i < max; i++) {
/*     */       Expression dim;
/*  48 */       if ((dim = this.dimensions[i]) != null) {
/*  49 */         flowInfo = dim.analyseCode(currentScope, flowContext, flowInfo);
/*  50 */         dim.checkNPEbyUnboxing(currentScope, flowContext, flowInfo);
/*     */       } 
/*     */     } 
/*     */     
/*  54 */     flowContext.recordAbruptExit();
/*  55 */     if (this.initializer != null) {
/*  56 */       return this.initializer.analyseCode(currentScope, flowContext, flowInfo);
/*     */     }
/*  58 */     return flowInfo;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void generateCode(BlockScope currentScope, CodeStream codeStream, boolean valueRequired) {
/*  67 */     int pc = codeStream.position;
/*     */     
/*  69 */     if (this.initializer != null) {
/*  70 */       this.initializer.generateCode(this.type, this, currentScope, codeStream, valueRequired);
/*     */       
/*     */       return;
/*     */     } 
/*  74 */     int explicitDimCount = 0;
/*  75 */     for (int i = 0, max = this.dimensions.length; i < max; i++) {
/*     */       Expression dimExpression;
/*  77 */       if ((dimExpression = this.dimensions[i]) == null)
/*  78 */         break;  dimExpression.generateCode(currentScope, codeStream, true);
/*  79 */       explicitDimCount++;
/*     */     } 
/*     */ 
/*     */     
/*  83 */     if (explicitDimCount == 1) {
/*     */       
/*  85 */       codeStream.newArray(this.type, this, (ArrayBinding)this.resolvedType);
/*     */     } else {
/*     */       
/*  88 */       codeStream.multianewarray(this.type, this.resolvedType, explicitDimCount, this);
/*     */     } 
/*  90 */     if (valueRequired) {
/*  91 */       codeStream.generateImplicitConversion(this.implicitConversion);
/*     */     } else {
/*  93 */       codeStream.pop();
/*     */     } 
/*  95 */     codeStream.recordPositionsFrom(pc, this.sourceStart);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public StringBuffer printExpression(int indent, StringBuffer output) {
/* 101 */     output.append("new ");
/* 102 */     this.type.print(0, output);
/* 103 */     for (int i = 0; i < this.dimensions.length; i++) {
/* 104 */       if (this.annotationsOnDimensions != null && this.annotationsOnDimensions[i] != null) {
/* 105 */         output.append(' ');
/* 106 */         printAnnotations(this.annotationsOnDimensions[i], output);
/* 107 */         output.append(' ');
/*     */       } 
/* 109 */       if (this.dimensions[i] == null) {
/* 110 */         output.append("[]");
/*     */       } else {
/* 112 */         output.append('[');
/* 113 */         this.dimensions[i].printExpression(0, output);
/* 114 */         output.append(']');
/*     */       } 
/*     */     } 
/* 117 */     if (this.initializer != null) this.initializer.printExpression(0, output); 
/* 118 */     return output;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TypeBinding resolveType(BlockScope scope) {
/* 128 */     TypeBinding referenceType = this.type.resolveType(scope, true);
/*     */ 
/*     */     
/* 131 */     this.constant = Constant.NotAConstant;
/* 132 */     if (referenceType == TypeBinding.VOID) {
/* 133 */       scope.problemReporter().cannotAllocateVoidArray(this);
/* 134 */       referenceType = null;
/*     */     } 
/*     */ 
/*     */     
/* 138 */     int explicitDimIndex = -1; int i;
/* 139 */     for (i = this.dimensions.length; --i >= 0; ) {
/* 140 */       if (this.dimensions[i] != null) {
/* 141 */         if (explicitDimIndex < 0) explicitDimIndex = i;  continue;
/* 142 */       }  if (explicitDimIndex > 0) {
/*     */         
/* 144 */         scope.problemReporter().incorrectLocationForNonEmptyDimension(this, explicitDimIndex);
/*     */ 
/*     */         
/*     */         break;
/*     */       } 
/*     */     } 
/*     */     
/* 151 */     if (this.initializer == null) {
/* 152 */       if (explicitDimIndex < 0) {
/* 153 */         scope.problemReporter().mustDefineDimensionsOrInitializer(this);
/*     */       }
/*     */       
/* 156 */       if (referenceType != null && !referenceType.isReifiable()) {
/* 157 */         scope.problemReporter().illegalGenericArray(referenceType, this);
/*     */       }
/* 159 */     } else if (explicitDimIndex >= 0) {
/* 160 */       scope.problemReporter().cannotDefineDimensionsAndInitializer(this);
/*     */     } 
/*     */ 
/*     */     
/* 164 */     for (i = 0; i <= explicitDimIndex; i++) {
/*     */       Expression dimExpression;
/* 166 */       if ((dimExpression = this.dimensions[i]) != null) {
/* 167 */         TypeBinding dimensionType = dimExpression.resolveTypeExpecting(scope, (TypeBinding)TypeBinding.INT);
/* 168 */         if (dimensionType != null) {
/* 169 */           this.dimensions[i].computeConversion((Scope)scope, (TypeBinding)TypeBinding.INT, dimensionType);
/*     */         }
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 175 */     if (referenceType != null) {
/* 176 */       if (this.dimensions.length > 255) {
/* 177 */         scope.problemReporter().tooManyDimensions(this);
/*     */       }
/* 179 */       if (this.type.annotations != null && (
/* 180 */         referenceType.tagBits & 0x180000000000000L) == 108086391056891904L) {
/*     */         
/* 182 */         scope.problemReporter().contradictoryNullAnnotations(this.type.annotations[this.type.annotations.length - 1]);
/* 183 */         referenceType = referenceType.withoutToplevelNullAnnotation();
/*     */       } 
/* 185 */       this.resolvedType = (TypeBinding)scope.createArrayType(referenceType, this.dimensions.length);
/*     */       
/* 187 */       int lastInitializedDim = -1;
/* 188 */       long[] nullTagBitsPerDimension = null;
/* 189 */       if (this.annotationsOnDimensions != null) {
/* 190 */         this.resolvedType = resolveAnnotations(scope, this.annotationsOnDimensions, this.resolvedType);
/* 191 */         nullTagBitsPerDimension = ((ArrayBinding)this.resolvedType).nullTagBitsPerDimension;
/* 192 */         if (nullTagBitsPerDimension != null) {
/* 193 */           for (int j = 0; j < this.annotationsOnDimensions.length; j++) {
/* 194 */             if ((nullTagBitsPerDimension[j] & 0x180000000000000L) == 108086391056891904L) {
/* 195 */               scope.problemReporter().contradictoryNullAnnotations(this.annotationsOnDimensions[j]);
/* 196 */               nullTagBitsPerDimension[j] = 0L;
/*     */             } 
/* 198 */             if (this.dimensions[j] != null) {
/* 199 */               lastInitializedDim = j;
/*     */             }
/*     */           } 
/*     */         }
/*     */       } 
/*     */       
/* 205 */       if (this.initializer != null) {
/* 206 */         this.resolvedType = ArrayTypeReference.maybeMarkArrayContentsNonNull((Scope)scope, this.resolvedType, this.sourceStart, this.dimensions.length, null);
/* 207 */         if (this.initializer.resolveTypeExpecting(scope, this.resolvedType) != null) {
/* 208 */           this.initializer.binding = (ArrayBinding)this.resolvedType;
/*     */         }
/*     */       }
/* 211 */       else if (lastInitializedDim != -1 && nullTagBitsPerDimension != null) {
/* 212 */         checkUninitializedNonNullArrayContents(scope, nullTagBitsPerDimension[lastInitializedDim + 1], lastInitializedDim);
/*     */       } 
/*     */       
/* 215 */       if ((referenceType.tagBits & 0x80L) != 0L) {
/* 216 */         return null;
/*     */       }
/*     */     } 
/* 219 */     return this.resolvedType;
/*     */   }
/*     */   
/*     */   protected void checkUninitializedNonNullArrayContents(BlockScope scope, long elementNullTagBits, int lastDim) {
/* 223 */     if ((elementNullTagBits & 0x100000000000000L) == 0L)
/*     */       return; 
/* 225 */     if (this.dimensions[lastDim] instanceof IntLiteral) {
/* 226 */       Constant intConstant = ((IntLiteral)this.dimensions[lastDim]).constant;
/* 227 */       if (intConstant.intValue() == 0)
/*     */         return; 
/*     */     } 
/* 230 */     TypeBinding elementType = this.resolvedType;
/* 231 */     for (int i = 0; i < lastDim + 1; i++) {
/* 232 */       elementType = ((ArrayBinding)elementType).elementsType();
/*     */     }
/* 234 */     scope.problemReporter().nonNullArrayContentNotInitialized(this.dimensions[lastDim], scope.environment(), elementType);
/*     */   }
/*     */ 
/*     */   
/*     */   public void traverse(ASTVisitor visitor, BlockScope scope) {
/* 239 */     if (visitor.visit(this, scope)) {
/* 240 */       int dimensionsLength = this.dimensions.length;
/* 241 */       this.type.traverse(visitor, scope);
/* 242 */       for (int i = 0; i < dimensionsLength; i++) {
/* 243 */         Annotation[] annotations = (this.annotationsOnDimensions == null) ? null : this.annotationsOnDimensions[i];
/* 244 */         int annotationsLength = (annotations == null) ? 0 : annotations.length;
/* 245 */         for (int j = 0; j < annotationsLength; j++) {
/* 246 */           annotations[j].traverse(visitor, scope);
/*     */         }
/* 248 */         if (this.dimensions[i] != null)
/* 249 */           this.dimensions[i].traverse(visitor, scope); 
/*     */       } 
/* 251 */       if (this.initializer != null)
/* 252 */         this.initializer.traverse(visitor, scope); 
/*     */     } 
/* 254 */     visitor.endVisit(this, scope);
/*     */   }
/*     */   
/*     */   public void getAllAnnotationContexts(int targetType, int info, List<AnnotationContext> allTypeAnnotationContexts) {
/* 258 */     TypeReference.AnnotationCollector collector = new TypeReference.AnnotationCollector(this, targetType, info, allTypeAnnotationContexts);
/* 259 */     this.type.traverse(collector, (BlockScope)null);
/* 260 */     if (this.annotationsOnDimensions != null) {
/* 261 */       int dimensionsLength = this.dimensions.length;
/* 262 */       for (int i = 0; i < dimensionsLength; i++) {
/* 263 */         Annotation[] annotations = this.annotationsOnDimensions[i];
/* 264 */         int annotationsLength = (annotations == null) ? 0 : annotations.length;
/* 265 */         for (int j = 0; j < annotationsLength; j++) {
/* 266 */           annotations[j].traverse(collector, (BlockScope)null);
/*     */         }
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   public Annotation[][] getAnnotationsOnDimensions() {
/* 273 */     return this.annotationsOnDimensions;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\ast\ArrayAllocationExpression.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */