/*     */ package org.eclipse.jdt.internal.compiler.apt.model;
/*     */ 
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import java.util.Set;
/*     */ import javax.lang.model.element.Element;
/*     */ import javax.lang.model.element.ElementKind;
/*     */ import javax.lang.model.element.ElementVisitor;
/*     */ import javax.lang.model.element.Modifier;
/*     */ import javax.lang.model.element.Name;
/*     */ import javax.lang.model.element.PackageElement;
/*     */ import javax.lang.model.element.VariableElement;
/*     */ import org.eclipse.jdt.core.compiler.CharOperation;
/*     */ import org.eclipse.jdt.internal.compiler.apt.dispatch.BaseProcessingEnvImpl;
/*     */ import org.eclipse.jdt.internal.compiler.impl.Constant;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.AnnotationBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.AptBinaryLocalVariableBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.AptSourceLocalVariableBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.Binding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.FieldBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.PackageBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.RecordComponentBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.TypeBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.VariableBinding;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class VariableElementImpl
/*     */   extends ElementImpl
/*     */   implements VariableElement
/*     */ {
/*     */   VariableElementImpl(BaseProcessingEnvImpl env, VariableBinding binding) {
/*  55 */     super(env, (Binding)binding);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public <R, P> R accept(ElementVisitor<R, P> v, P p) {
/*  61 */     return v.visitVariable(this, p);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected AnnotationBinding[] getAnnotationBindings() {
/*  67 */     return ((VariableBinding)this._binding).getAnnotations();
/*     */   }
/*     */ 
/*     */   
/*     */   public Object getConstantValue() {
/*  72 */     VariableBinding variableBinding = (VariableBinding)this._binding;
/*  73 */     Constant constant = variableBinding.constant();
/*  74 */     if (constant == null || constant == Constant.NotAConstant) return null; 
/*  75 */     TypeBinding type = variableBinding.type;
/*  76 */     switch (type.id) {
/*     */       case 5:
/*  78 */         return Boolean.valueOf(constant.booleanValue());
/*     */       case 3:
/*  80 */         return Byte.valueOf(constant.byteValue());
/*     */       case 2:
/*  82 */         return Character.valueOf(constant.charValue());
/*     */       case 8:
/*  84 */         return Double.valueOf(constant.doubleValue());
/*     */       case 9:
/*  86 */         return Float.valueOf(constant.floatValue());
/*     */       case 10:
/*  88 */         return Integer.valueOf(constant.intValue());
/*     */       case 11:
/*  90 */         return constant.stringValue();
/*     */       case 7:
/*  92 */         return Long.valueOf(constant.longValue());
/*     */       case 4:
/*  94 */         return Short.valueOf(constant.shortValue());
/*     */     } 
/*  96 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public List<? extends Element> getEnclosedElements() {
/* 101 */     return Collections.emptyList();
/*     */   }
/*     */ 
/*     */   
/*     */   public Element getEnclosingElement() {
/* 106 */     if (this._binding instanceof FieldBinding) {
/* 107 */       return this._env.getFactory().newElement((Binding)((FieldBinding)this._binding).declaringClass);
/*     */     }
/* 109 */     if (this._binding instanceof AptSourceLocalVariableBinding)
/* 110 */       return this._env.getFactory().newElement((Binding)((AptSourceLocalVariableBinding)this._binding).methodBinding); 
/* 111 */     if (this._binding instanceof AptBinaryLocalVariableBinding)
/* 112 */       return this._env.getFactory().newElement((Binding)((AptBinaryLocalVariableBinding)this._binding).methodBinding); 
/* 113 */     if (this._binding instanceof RecordComponentBinding) {
/* 114 */       return this._env.getFactory().newElement((Binding)((RecordComponentBinding)this._binding).declaringRecord);
/*     */     }
/* 116 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public ElementKind getKind() {
/* 121 */     if (this._binding instanceof FieldBinding) {
/* 122 */       if ((((FieldBinding)this._binding).modifiers & 0x4000) != 0) {
/* 123 */         return ElementKind.ENUM_CONSTANT;
/*     */       }
/*     */       
/* 126 */       return ElementKind.FIELD;
/*     */     } 
/*     */ 
/*     */     
/* 130 */     return ElementKind.PARAMETER;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Set<Modifier> getModifiers() {
/* 137 */     if (this._binding instanceof VariableBinding) {
/* 138 */       return Factory.getModifiers(((VariableBinding)this._binding).modifiers, getKind());
/*     */     }
/* 140 */     return Collections.emptySet();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   PackageElement getPackage() {
/* 146 */     if (this._binding instanceof FieldBinding) {
/* 147 */       PackageBinding pkgBinding = ((FieldBinding)this._binding).declaringClass.fPackage;
/* 148 */       return this._env.getFactory().newPackageElement(pkgBinding);
/*     */     } 
/*     */ 
/*     */     
/* 152 */     throw new UnsupportedOperationException("NYI: VariableElmentImpl.getPackage() for method parameter");
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Name getSimpleName() {
/* 158 */     return new NameImpl(((VariableBinding)this._binding).name);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean hides(Element hiddenElement) {
/* 164 */     if (this._binding instanceof FieldBinding) {
/* 165 */       if (!(((ElementImpl)hiddenElement)._binding instanceof FieldBinding)) {
/* 166 */         return false;
/*     */       }
/* 168 */       FieldBinding hidden = (FieldBinding)((ElementImpl)hiddenElement)._binding;
/* 169 */       if (hidden.isPrivate()) {
/* 170 */         return false;
/*     */       }
/* 172 */       FieldBinding hider = (FieldBinding)this._binding;
/* 173 */       if (hidden == hider) {
/* 174 */         return false;
/*     */       }
/* 176 */       if (!CharOperation.equals(hider.name, hidden.name)) {
/* 177 */         return false;
/*     */       }
/* 179 */       return (hider.declaringClass.findSuperTypeOriginatingFrom((TypeBinding)hidden.declaringClass) != null);
/*     */     } 
/*     */     
/* 182 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 187 */     return new String(((VariableBinding)this._binding).name);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object obj) {
/* 192 */     if (this == obj)
/* 193 */       return true; 
/* 194 */     if (obj == null)
/* 195 */       return false; 
/* 196 */     if (getClass() != obj.getClass())
/* 197 */       return false; 
/* 198 */     VariableElementImpl other = (VariableElementImpl)obj;
/* 199 */     return Objects.equals(this._binding, other._binding);
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\apt\model\VariableElementImpl.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */