/*    */ package org.eclipse.jdt.internal.compiler.ast;
/*    */ 
/*    */ import org.eclipse.jdt.internal.compiler.ASTVisitor;
/*    */ import org.eclipse.jdt.internal.compiler.lookup.BlockScope;
/*    */ import org.eclipse.jdt.internal.compiler.lookup.ClassScope;
/*    */ import org.eclipse.jdt.internal.compiler.lookup.MethodBinding;
/*    */ import org.eclipse.jdt.internal.compiler.lookup.MethodScope;
/*    */ import org.eclipse.jdt.internal.compiler.lookup.TypeBinding;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class JavadocReturnStatement
/*    */   extends ReturnStatement
/*    */ {
/*    */   public JavadocReturnStatement(int s, int e) {
/* 23 */     super((Expression)null, s, e);
/* 24 */     this.bits |= 0x48000;
/*    */   }
/*    */ 
/*    */   
/*    */   public void resolve(BlockScope scope) {
/* 29 */     MethodScope methodScope = scope.methodScope();
/* 30 */     MethodBinding methodBinding = null;
/* 31 */     TypeBinding methodType = 
/* 32 */       (methodScope.referenceContext instanceof AbstractMethodDeclaration) ? (
/* 33 */       ((methodBinding = ((AbstractMethodDeclaration)methodScope.referenceContext).binding) == null) ? 
/* 34 */       null : 
/* 35 */       methodBinding.returnType) : 
/* 36 */       (TypeBinding)TypeBinding.VOID;
/* 37 */     if (methodType == null || methodType == TypeBinding.VOID) {
/* 38 */       scope.problemReporter().javadocUnexpectedTag(this.sourceStart, this.sourceEnd);
/* 39 */     } else if ((this.bits & 0x40000) != 0) {
/* 40 */       scope.problemReporter().javadocEmptyReturnTag(this.sourceStart, this.sourceEnd, scope.getDeclarationModifiers());
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   public StringBuffer printStatement(int tab, StringBuffer output) {
/* 46 */     printIndent(tab, output).append("return");
/* 47 */     if ((this.bits & 0x40000) == 0)
/* 48 */       output.append(' ').append(" <not empty>"); 
/* 49 */     return output;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void traverse(ASTVisitor visitor, BlockScope scope) {
/* 58 */     visitor.visit(this, scope);
/* 59 */     visitor.endVisit(this, scope);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void traverse(ASTVisitor visitor, ClassScope scope) {
/* 66 */     visitor.visit(this, scope);
/* 67 */     visitor.endVisit(this, scope);
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\ast\JavadocReturnStatement.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */