/*    */ package org.eclipse.jdt.internal.compiler.classfmt;
/*    */ 
/*    */ import org.eclipse.jdt.internal.compiler.env.IBinaryTypeAnnotation;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class MethodInfoWithTypeAnnotations
/*    */   extends MethodInfoWithParameterAnnotations
/*    */ {
/*    */   private TypeAnnotationInfo[] typeAnnotations;
/*    */   
/*    */   MethodInfoWithTypeAnnotations(MethodInfo methodInfo, AnnotationInfo[] annotations, AnnotationInfo[][] parameterAnnotations, TypeAnnotationInfo[] typeAnnotations) {
/* 23 */     super(methodInfo, annotations, parameterAnnotations);
/* 24 */     this.typeAnnotations = typeAnnotations;
/*    */   }
/*    */   
/*    */   public IBinaryTypeAnnotation[] getTypeAnnotations() {
/* 28 */     return (IBinaryTypeAnnotation[])this.typeAnnotations;
/*    */   }
/*    */ 
/*    */   
/*    */   protected void initialize() {
/* 33 */     for (int i = 0, l = (this.typeAnnotations == null) ? 0 : this.typeAnnotations.length; i < l; i++) {
/* 34 */       this.typeAnnotations[i].initialize();
/*    */     }
/* 36 */     super.initialize();
/*    */   }
/*    */   
/*    */   protected void reset() {
/* 40 */     for (int i = 0, l = (this.typeAnnotations == null) ? 0 : this.typeAnnotations.length; i < l; i++) {
/* 41 */       this.typeAnnotations[i].reset();
/*    */     }
/* 43 */     super.reset();
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\classfmt\MethodInfoWithTypeAnnotations.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */