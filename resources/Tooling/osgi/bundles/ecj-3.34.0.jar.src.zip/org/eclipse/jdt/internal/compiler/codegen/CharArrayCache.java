/*     */ package org.eclipse.jdt.internal.compiler.codegen;
/*     */ 
/*     */ import org.eclipse.jdt.core.compiler.CharOperation;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CharArrayCache
/*     */ {
/*     */   public char[][] keyTable;
/*     */   public int[] valueTable;
/*     */   int elementSize;
/*     */   int threshold;
/*     */   
/*     */   public CharArrayCache() {
/*  29 */     this(9);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CharArrayCache(int initialCapacity) {
/*  38 */     this.elementSize = 0;
/*  39 */     this.threshold = initialCapacity * 2 / 3;
/*  40 */     this.keyTable = new char[initialCapacity][];
/*  41 */     this.valueTable = new int[initialCapacity];
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void clear() {
/*  47 */     for (int i = this.keyTable.length; --i >= 0; ) {
/*  48 */       this.keyTable[i] = null;
/*  49 */       this.valueTable[i] = 0;
/*     */     } 
/*  51 */     this.elementSize = 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean containsKey(char[] key) {
/*  59 */     int length = this.keyTable.length, index = CharOperation.hashCode(key) % length;
/*  60 */     while (this.keyTable[index] != null) {
/*  61 */       if (CharOperation.equals(this.keyTable[index], key))
/*  62 */         return true; 
/*  63 */       if (++index == length) {
/*  64 */         index = 0;
/*     */       }
/*     */     } 
/*  67 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int get(char[] key) {
/*  76 */     int length = this.keyTable.length, index = CharOperation.hashCode(key) % length;
/*  77 */     while (this.keyTable[index] != null) {
/*  78 */       if (CharOperation.equals(this.keyTable[index], key))
/*  79 */         return this.valueTable[index]; 
/*  80 */       if (++index == length) {
/*  81 */         index = 0;
/*     */       }
/*     */     } 
/*  84 */     return -1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int putIfAbsent(char[] key, int value) {
/*  96 */     int length = this.keyTable.length, index = CharOperation.hashCode(key) % length;
/*  97 */     while (this.keyTable[index] != null) {
/*  98 */       if (CharOperation.equals(this.keyTable[index], key))
/*  99 */         return this.valueTable[index]; 
/* 100 */       if (++index == length) {
/* 101 */         index = 0;
/*     */       }
/*     */     } 
/* 104 */     this.keyTable[index] = key;
/* 105 */     this.valueTable[index] = value;
/*     */ 
/*     */     
/* 108 */     if (++this.elementSize > this.threshold)
/* 109 */       rehash(); 
/* 110 */     return -value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int put(char[] key, int value) {
/* 123 */     int length = this.keyTable.length, index = CharOperation.hashCode(key) % length;
/* 124 */     while (this.keyTable[index] != null) {
/* 125 */       if (CharOperation.equals(this.keyTable[index], key)) {
/* 126 */         this.valueTable[index] = value; return value;
/* 127 */       }  if (++index == length) {
/* 128 */         index = 0;
/*     */       }
/*     */     } 
/* 131 */     this.keyTable[index] = key;
/* 132 */     this.valueTable[index] = value;
/*     */ 
/*     */     
/* 135 */     if (++this.elementSize > this.threshold)
/* 136 */       rehash(); 
/* 137 */     return value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void rehash() {
/* 145 */     CharArrayCache newHashtable = new CharArrayCache(this.keyTable.length * 2);
/* 146 */     for (int i = this.keyTable.length; --i >= 0;) {
/* 147 */       if (this.keyTable[i] != null)
/* 148 */         newHashtable.put(this.keyTable[i], this.valueTable[i]); 
/*     */     } 
/* 150 */     this.keyTable = newHashtable.keyTable;
/* 151 */     this.valueTable = newHashtable.valueTable;
/* 152 */     this.threshold = newHashtable.threshold;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void remove(char[] key) {
/* 159 */     int length = this.keyTable.length, index = CharOperation.hashCode(key) % length;
/* 160 */     while (this.keyTable[index] != null) {
/* 161 */       if (CharOperation.equals(this.keyTable[index], key)) {
/* 162 */         this.valueTable[index] = 0;
/* 163 */         this.keyTable[index] = null;
/*     */         return;
/*     */       } 
/* 166 */       if (++index == length) {
/* 167 */         index = 0;
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public char[] returnKeyFor(int value) {
/* 178 */     for (int i = this.keyTable.length; i-- > 0;) {
/* 179 */       if (this.valueTable[i] == value) {
/* 180 */         return this.keyTable[i];
/*     */       }
/*     */     } 
/* 183 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int size() {
/* 191 */     return this.elementSize;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 200 */     int max = size();
/* 201 */     StringBuilder buf = new StringBuilder();
/* 202 */     buf.append("{");
/* 203 */     for (int i = 0; i < max; i++) {
/* 204 */       if (this.keyTable[i] != null) {
/* 205 */         buf.append(this.keyTable[i]).append("->").append(this.valueTable[i]);
/*     */       }
/* 207 */       if (i < max) {
/* 208 */         buf.append(", ");
/*     */       }
/*     */     } 
/* 211 */     buf.append("}");
/* 212 */     return buf.toString();
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\codegen\CharArrayCache.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */