/*     */ package org.eclipse.jdt.internal.compiler.ast;
/*     */ 
/*     */ import java.util.List;
/*     */ import org.eclipse.jdt.internal.compiler.ASTVisitor;
/*     */ import org.eclipse.jdt.internal.compiler.codegen.AnnotationContext;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.BlockScope;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.ClassScope;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.LocalVariableBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.RecordComponentBinding;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class AnnotationCollector
/*     */   extends ASTVisitor
/*     */ {
/*     */   List<AnnotationContext> annotationContexts;
/*     */   Expression typeReference;
/*     */   int targetType;
/*  97 */   int info = 0;
/*  98 */   int info2 = 0;
/*     */   
/*     */   LocalVariableBinding localVariable;
/*     */   
/*     */   Annotation[][] annotationsOnDimensions;
/*     */   
/*     */   int dimensions;
/*     */   
/*     */   Wildcard currentWildcard;
/*     */   RecordComponentBinding recordComponentBinding;
/*     */   
/*     */   public AnnotationCollector(TypeParameter typeParameter, int targetType, int typeParameterIndex, List<AnnotationContext> annotationContexts) {
/* 110 */     this.annotationContexts = annotationContexts;
/* 111 */     this.typeReference = typeParameter.type;
/* 112 */     this.targetType = targetType;
/* 113 */     this.info = typeParameterIndex;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AnnotationCollector(LocalDeclaration localDeclaration, int targetType, LocalVariableBinding localVariable, List<AnnotationContext> annotationContexts) {
/* 121 */     this.annotationContexts = annotationContexts;
/* 122 */     this.typeReference = localDeclaration.type;
/* 123 */     this.targetType = targetType;
/* 124 */     this.localVariable = localVariable;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AnnotationCollector(LocalDeclaration localDeclaration, int targetType, int parameterIndex, List<AnnotationContext> annotationContexts) {
/* 132 */     this.annotationContexts = annotationContexts;
/* 133 */     this.typeReference = localDeclaration.type;
/* 134 */     this.targetType = targetType;
/* 135 */     this.info = parameterIndex;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AnnotationCollector(TypeReference typeReference, int targetType, List<AnnotationContext> annotationContexts) {
/* 142 */     this.annotationContexts = annotationContexts;
/* 143 */     this.typeReference = typeReference;
/* 144 */     this.targetType = targetType;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AnnotationCollector(Expression typeReference, int targetType, int info, List<AnnotationContext> annotationContexts) {
/* 151 */     this.annotationContexts = annotationContexts;
/* 152 */     this.typeReference = typeReference;
/* 153 */     this.info = info;
/* 154 */     this.targetType = targetType;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AnnotationCollector(TypeReference typeReference, int targetType, int info, int typeIndex, List<AnnotationContext> annotationContexts) {
/* 162 */     this.annotationContexts = annotationContexts;
/* 163 */     this.typeReference = typeReference;
/* 164 */     this.info = info;
/* 165 */     this.targetType = targetType;
/* 166 */     this.info2 = typeIndex;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AnnotationCollector(TypeReference typeReference, int targetType, int info, List<AnnotationContext> annotationContexts, Annotation[][] annotationsOnDimensions, int dimensions) {
/* 175 */     this.annotationContexts = annotationContexts;
/* 176 */     this.typeReference = typeReference;
/* 177 */     this.info = info;
/* 178 */     this.targetType = targetType;
/* 179 */     this.annotationsOnDimensions = annotationsOnDimensions;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 185 */     this.dimensions = dimensions;
/*     */   }
/*     */   
/*     */   public AnnotationCollector(RecordComponent recordComponent, int targetType, List<AnnotationContext> annotationContexts) {
/* 189 */     this.annotationContexts = annotationContexts;
/* 190 */     this.typeReference = recordComponent.type;
/* 191 */     this.targetType = targetType;
/* 192 */     this.recordComponentBinding = recordComponent.binding;
/*     */   }
/*     */   
/*     */   private boolean internalVisit(Annotation annotation) {
/* 196 */     AnnotationContext annotationContext = null;
/* 197 */     if (annotation.isRuntimeTypeInvisible()) {
/* 198 */       annotationContext = new AnnotationContext(annotation, this.typeReference, this.targetType, 2);
/* 199 */     } else if (annotation.isRuntimeTypeVisible()) {
/* 200 */       annotationContext = new AnnotationContext(annotation, this.typeReference, this.targetType, 1);
/*     */     } 
/* 202 */     if (annotationContext != null) {
/* 203 */       annotationContext.wildcard = this.currentWildcard;
/* 204 */       switch (this.targetType) {
/*     */         case 0:
/*     */         case 1:
/*     */         case 16:
/*     */         case 22:
/*     */         case 23:
/*     */         case 66:
/*     */         case 67:
/*     */         case 68:
/*     */         case 69:
/*     */         case 70:
/* 215 */           annotationContext.info = this.info;
/*     */           break;
/*     */         case 64:
/*     */         case 65:
/* 219 */           annotationContext.variableBinding = this.localVariable;
/*     */           break;
/*     */         case 17:
/*     */         case 18:
/*     */         case 71:
/*     */         case 72:
/*     */         case 73:
/*     */         case 74:
/*     */         case 75:
/* 228 */           annotationContext.info2 = this.info2;
/* 229 */           annotationContext.info = this.info;
/*     */           break;
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 238 */       this.annotationContexts.add(annotationContext);
/*     */     } 
/* 240 */     return true;
/*     */   }
/*     */   
/*     */   public boolean visit(MarkerAnnotation annotation, BlockScope scope) {
/* 244 */     return internalVisit(annotation);
/*     */   }
/*     */   
/*     */   public boolean visit(NormalAnnotation annotation, BlockScope scope) {
/* 248 */     return internalVisit(annotation);
/*     */   }
/*     */   
/*     */   public boolean visit(SingleMemberAnnotation annotation, BlockScope scope) {
/* 252 */     return internalVisit(annotation);
/*     */   }
/*     */   
/*     */   public boolean visit(Wildcard wildcard, BlockScope scope) {
/* 256 */     this.currentWildcard = wildcard;
/* 257 */     return true;
/*     */   }
/*     */   
/*     */   public boolean visit(Argument argument, BlockScope scope) {
/* 261 */     if ((argument.bits & 0x20000000) == 0) {
/* 262 */       return true;
/*     */     }
/* 264 */     for (int i = 0, max = this.localVariable.initializationCount; i < max; i++) {
/* 265 */       int startPC = this.localVariable.initializationPCs[i << 1];
/* 266 */       int endPC = this.localVariable.initializationPCs[(i << 1) + 1];
/* 267 */       if (startPC != endPC) {
/* 268 */         return true;
/*     */       }
/*     */     } 
/* 271 */     return false;
/*     */   }
/*     */   
/*     */   public boolean visit(Argument argument, ClassScope scope) {
/* 275 */     if ((argument.bits & 0x20000000) == 0) {
/* 276 */       return true;
/*     */     }
/* 278 */     for (int i = 0, max = this.localVariable.initializationCount; i < max; i++) {
/* 279 */       int startPC = this.localVariable.initializationPCs[i << 1];
/* 280 */       int endPC = this.localVariable.initializationPCs[(i << 1) + 1];
/* 281 */       if (startPC != endPC) {
/* 282 */         return true;
/*     */       }
/*     */     } 
/* 285 */     return false;
/*     */   }
/*     */   
/*     */   public boolean visit(LocalDeclaration localDeclaration, BlockScope scope) {
/* 289 */     for (int i = 0, max = this.localVariable.initializationCount; i < max; i++) {
/* 290 */       int startPC = this.localVariable.initializationPCs[i << 1];
/* 291 */       int endPC = this.localVariable.initializationPCs[(i << 1) + 1];
/* 292 */       if (startPC != endPC) {
/* 293 */         return true;
/*     */       }
/*     */     } 
/* 296 */     return false;
/*     */   }
/*     */   
/*     */   public void endVisit(Wildcard wildcard, BlockScope scope) {
/* 300 */     this.currentWildcard = null;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\ast\TypeReference$AnnotationCollector.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */