/*     */ package org.eclipse.jdt.internal.compiler.flow;
/*     */ 
/*     */ import org.eclipse.jdt.internal.compiler.ast.IfStatement;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.FieldBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.LocalVariableBinding;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class FlowInfo
/*     */ {
/*     */   public int tagBits;
/*     */   public static final int REACHABLE = 0;
/*     */   public static final int UNREACHABLE_OR_DEAD = 1;
/*     */   public static final int UNREACHABLE_BY_NULLANALYSIS = 2;
/*     */   public static final int UNREACHABLE = 3;
/*     */   public static final int NULL_FLAG_MASK = 4;
/*     */   public static final int UNKNOWN = 1;
/*     */   public static final int NULL = 2;
/*     */   public static final int NON_NULL = 4;
/*     */   public static final int POTENTIALLY_UNKNOWN = 8;
/*     */   public static final int POTENTIALLY_NULL = 16;
/*     */   public static final int POTENTIALLY_NON_NULL = 32;
/*     */   public static final int UNROOTED = 64;
/*     */   public static final int FREE_TYPEVARIABLE = 48;
/*  63 */   public static final UnconditionalFlowInfo DEAD_END = new UnconditionalFlowInfo(); static {
/*  64 */     DEAD_END.tagBits = 3;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract FlowInfo addInitializationsFrom(FlowInfo paramFlowInfo);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract FlowInfo addNullInfoFrom(FlowInfo paramFlowInfo);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract FlowInfo addPotentialInitializationsFrom(FlowInfo paramFlowInfo);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public FlowInfo asNegatedCondition() {
/*  98 */     return this;
/*     */   }
/*     */   
/*     */   public static FlowInfo conditional(FlowInfo initsWhenTrue, FlowInfo initsWhenFalse) {
/* 102 */     if (initsWhenTrue == initsWhenFalse) return initsWhenTrue;
/*     */     
/* 104 */     return new ConditionalFlowInfo(initsWhenTrue, initsWhenFalse);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean cannotBeDefinitelyNullOrNonNull(LocalVariableBinding local) {
/* 119 */     return !(!isPotentiallyUnknown(local) && (
/* 120 */       !isPotentiallyNonNull(local) || !isPotentiallyNull(local)));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean cannotBeNull(LocalVariableBinding local) {
/* 130 */     return !(!isDefinitelyNonNull(local) && !isProtectedNonNull(local));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean canOnlyBeNull(LocalVariableBinding local) {
/* 140 */     return !(!isDefinitelyNull(local) && !isProtectedNull(local));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract FlowInfo copy();
/*     */ 
/*     */ 
/*     */   
/*     */   public static UnconditionalFlowInfo initial(int maxFieldCount) {
/* 150 */     UnconditionalFlowInfo info = new UnconditionalFlowInfo();
/* 151 */     info.maxFieldCount = maxFieldCount;
/* 152 */     return info;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract FlowInfo initsWhenFalse();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract FlowInfo initsWhenTrue();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract boolean isDefinitelyAssigned(FieldBinding paramFieldBinding);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract boolean isDefinitelyAssigned(LocalVariableBinding paramLocalVariableBinding);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract boolean isDefinitelyNonNull(LocalVariableBinding paramLocalVariableBinding);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract boolean isDefinitelyNull(LocalVariableBinding paramLocalVariableBinding);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract boolean isDefinitelyUnknown(LocalVariableBinding paramLocalVariableBinding);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract boolean hasNullInfoFor(LocalVariableBinding paramLocalVariableBinding);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract boolean isPotentiallyAssigned(FieldBinding paramFieldBinding);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract boolean isPotentiallyAssigned(LocalVariableBinding paramLocalVariableBinding);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract boolean isPotentiallyNonNull(LocalVariableBinding paramLocalVariableBinding);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract boolean isPotentiallyNull(LocalVariableBinding paramLocalVariableBinding);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract boolean isPotentiallyUnknown(LocalVariableBinding paramLocalVariableBinding);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract boolean isProtectedNonNull(LocalVariableBinding paramLocalVariableBinding);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract boolean isProtectedNull(LocalVariableBinding paramLocalVariableBinding);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract void markAsComparedEqualToNonNull(LocalVariableBinding paramLocalVariableBinding);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract void markAsComparedEqualToNull(LocalVariableBinding paramLocalVariableBinding);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract void markAsDefinitelyAssigned(FieldBinding paramFieldBinding);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract void markAsDefinitelyNonNull(LocalVariableBinding paramLocalVariableBinding);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract void markAsDefinitelyNull(LocalVariableBinding paramLocalVariableBinding);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract void resetNullInfo(LocalVariableBinding paramLocalVariableBinding);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract void markPotentiallyUnknownBit(LocalVariableBinding paramLocalVariableBinding);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract void markPotentiallyNullBit(LocalVariableBinding paramLocalVariableBinding);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract void markPotentiallyNonNullBit(LocalVariableBinding paramLocalVariableBinding);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract void markAsDefinitelyAssigned(LocalVariableBinding paramLocalVariableBinding);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract void markAsDefinitelyUnknown(LocalVariableBinding paramLocalVariableBinding);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void markNullStatus(LocalVariableBinding local, int nullStatus) {
/* 331 */     switch (nullStatus) {
/*     */       
/*     */       case 1:
/* 334 */         markAsDefinitelyUnknown(local);
/*     */         return;
/*     */       case 2:
/* 337 */         markAsDefinitelyNull(local);
/*     */         return;
/*     */       case 4:
/* 340 */         markAsDefinitelyNonNull(local);
/*     */         return;
/*     */     } 
/*     */     
/* 344 */     resetNullInfo(local);
/* 345 */     if ((nullStatus & 0x8) != 0)
/* 346 */       markPotentiallyUnknownBit(local); 
/* 347 */     if ((nullStatus & 0x10) != 0)
/* 348 */       markPotentiallyNullBit(local); 
/* 349 */     if ((nullStatus & 0x20) != 0)
/* 350 */       markPotentiallyNonNullBit(local); 
/* 351 */     if ((nullStatus & 0x38) == 0) {
/* 352 */       markAsDefinitelyUnknown(local);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int nullStatus(LocalVariableBinding local) {
/* 362 */     if (isDefinitelyUnknown(local))
/* 363 */       return 1; 
/* 364 */     if (isDefinitelyNull(local))
/* 365 */       return 2; 
/* 366 */     if (isDefinitelyNonNull(local))
/* 367 */       return 4; 
/* 368 */     int status = 0;
/* 369 */     if (isPotentiallyUnknown(local))
/* 370 */       status |= 0x8; 
/* 371 */     if (isPotentiallyNull(local))
/* 372 */       status |= 0x10; 
/* 373 */     if (isPotentiallyNonNull(local))
/* 374 */       status |= 0x20; 
/* 375 */     if (status > 0)
/* 376 */       return status; 
/* 377 */     return 1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int mergeNullStatus(int nullStatus1, int nullStatus2) {
/* 385 */     boolean canBeNull = false;
/* 386 */     boolean canBeNonNull = false;
/* 387 */     switch (nullStatus1) {
/*     */       case 16:
/* 389 */         canBeNonNull = true;
/*     */       
/*     */       case 2:
/* 392 */         canBeNull = true;
/*     */         break;
/*     */       case 32:
/* 395 */         canBeNull = true;
/*     */       
/*     */       case 4:
/* 398 */         canBeNonNull = true;
/*     */         break;
/*     */     } 
/* 401 */     switch (nullStatus2) {
/*     */       case 16:
/* 403 */         canBeNonNull = true;
/*     */       
/*     */       case 2:
/* 406 */         canBeNull = true;
/*     */         break;
/*     */       case 32:
/* 409 */         canBeNull = true;
/*     */       
/*     */       case 4:
/* 412 */         canBeNonNull = true;
/*     */         break;
/*     */     } 
/* 415 */     if (canBeNull) {
/* 416 */       if (canBeNonNull) {
/* 417 */         return 16;
/*     */       }
/* 419 */       return 2;
/*     */     } 
/* 421 */     if (canBeNonNull) {
/* 422 */       return 4;
/*     */     }
/* 424 */     return 1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static UnconditionalFlowInfo mergedOptimizedBranches(FlowInfo initsWhenTrue, boolean isOptimizedTrue, FlowInfo initsWhenFalse, boolean isOptimizedFalse, boolean allowFakeDeadBranch) {
/*     */     UnconditionalFlowInfo mergedInfo;
/* 436 */     if (isOptimizedTrue) {
/* 437 */       if (initsWhenTrue == DEAD_END && allowFakeDeadBranch) {
/* 438 */         mergedInfo = initsWhenFalse.setReachMode(1)
/* 439 */           .unconditionalInits();
/*     */       } else {
/*     */         
/* 442 */         mergedInfo = 
/* 443 */           initsWhenTrue.addPotentialInitializationsFrom(initsWhenFalse
/* 444 */             .nullInfoLessUnconditionalCopy())
/* 445 */           .unconditionalInits();
/*     */       }
/*     */     
/* 448 */     } else if (isOptimizedFalse) {
/* 449 */       if (initsWhenFalse == DEAD_END && allowFakeDeadBranch) {
/* 450 */         mergedInfo = initsWhenTrue.setReachMode(1)
/* 451 */           .unconditionalInits();
/*     */       } else {
/*     */         
/* 454 */         mergedInfo = 
/* 455 */           initsWhenFalse.addPotentialInitializationsFrom(initsWhenTrue
/* 456 */             .nullInfoLessUnconditionalCopy())
/* 457 */           .unconditionalInits();
/*     */       } 
/*     */     } else {
/*     */       
/* 461 */       mergedInfo = initsWhenTrue
/* 462 */         .mergedWith(initsWhenFalse.unconditionalInits());
/*     */     } 
/* 464 */     return mergedInfo;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static UnconditionalFlowInfo mergedOptimizedBranchesIfElse(FlowInfo initsWhenTrue, boolean isOptimizedTrue, FlowInfo initsWhenFalse, boolean isOptimizedFalse, boolean allowFakeDeadBranch, FlowInfo flowInfo, IfStatement ifStatement, boolean reportDeadCodeInKnownPattern) {
/*     */     UnconditionalFlowInfo mergedInfo;
/* 476 */     if (isOptimizedTrue) {
/* 477 */       if (initsWhenTrue == DEAD_END && allowFakeDeadBranch) {
/* 478 */         if (!reportDeadCodeInKnownPattern) {
/*     */ 
/*     */ 
/*     */           
/* 482 */           if (ifStatement.elseStatement == null) {
/* 483 */             mergedInfo = flowInfo.unconditionalInits();
/*     */           } else {
/* 485 */             mergedInfo = initsWhenFalse.unconditionalInits();
/* 486 */             if (initsWhenFalse != DEAD_END)
/*     */             {
/* 488 */               mergedInfo.setReachMode(flowInfo.reachMode());
/*     */             }
/*     */           } 
/*     */         } else {
/* 492 */           mergedInfo = initsWhenFalse.setReachMode(1)
/* 493 */             .unconditionalInits();
/*     */         } 
/*     */       } else {
/*     */         
/* 497 */         mergedInfo = 
/* 498 */           initsWhenTrue.addPotentialInitializationsFrom(initsWhenFalse
/* 499 */             .nullInfoLessUnconditionalCopy())
/* 500 */           .unconditionalInits();
/*     */       }
/*     */     
/* 503 */     } else if (isOptimizedFalse) {
/* 504 */       if (initsWhenFalse == DEAD_END && allowFakeDeadBranch) {
/* 505 */         if (!reportDeadCodeInKnownPattern) {
/*     */ 
/*     */ 
/*     */           
/* 509 */           if (ifStatement.thenStatement == null) {
/* 510 */             mergedInfo = flowInfo.unconditionalInits();
/*     */           } else {
/* 512 */             mergedInfo = initsWhenTrue.unconditionalInits();
/* 513 */             if (initsWhenTrue != DEAD_END)
/*     */             {
/* 515 */               mergedInfo.setReachMode(flowInfo.reachMode());
/*     */             }
/*     */           } 
/*     */         } else {
/* 519 */           mergedInfo = initsWhenTrue.setReachMode(1)
/* 520 */             .unconditionalInits();
/*     */         } 
/*     */       } else {
/*     */         
/* 524 */         mergedInfo = 
/* 525 */           initsWhenFalse.addPotentialInitializationsFrom(initsWhenTrue
/* 526 */             .nullInfoLessUnconditionalCopy())
/* 527 */           .unconditionalInits();
/*     */       }
/*     */     
/* 530 */     } else if ((flowInfo.tagBits & 0x3) == 0 && (
/* 531 */       ifStatement.bits & 0x80) != 0 && 
/* 532 */       initsWhenTrue != DEAD_END && 
/* 533 */       initsWhenFalse != DEAD_END) {
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 538 */       mergedInfo = 
/* 539 */         initsWhenTrue.addPotentialInitializationsFrom(initsWhenFalse
/* 540 */           .nullInfoLessUnconditionalCopy())
/* 541 */         .unconditionalInits();
/*     */ 
/*     */       
/* 544 */       mergedInfo.mergeDefiniteInitsWith(initsWhenFalse.unconditionalCopy());
/*     */ 
/*     */       
/* 547 */       if ((mergedInfo.tagBits & 0x1) != 0 && (initsWhenFalse.tagBits & 0x3) == 2) {
/* 548 */         mergedInfo.tagBits &= 0xFFFFFFFE;
/* 549 */         mergedInfo.tagBits |= 0x2;
/*     */       }
/*     */     
/* 552 */     } else if ((flowInfo.tagBits & 0x3) == 0 && (
/* 553 */       ifStatement.bits & 0x100) != 0 && initsWhenTrue != DEAD_END && 
/* 554 */       initsWhenFalse != DEAD_END) {
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 559 */       mergedInfo = 
/* 560 */         initsWhenFalse.addPotentialInitializationsFrom(initsWhenTrue
/* 561 */           .nullInfoLessUnconditionalCopy())
/* 562 */         .unconditionalInits();
/*     */ 
/*     */       
/* 565 */       mergedInfo.mergeDefiniteInitsWith(initsWhenTrue.unconditionalCopy());
/*     */       
/* 567 */       if ((mergedInfo.tagBits & 0x1) != 0 && (initsWhenTrue.tagBits & 0x3) == 2) {
/* 568 */         mergedInfo.tagBits &= 0xFFFFFFFE;
/* 569 */         mergedInfo.tagBits |= 0x2;
/*     */       } 
/*     */     } else {
/*     */       
/* 573 */       mergedInfo = initsWhenTrue
/* 574 */         .mergedWith(initsWhenFalse.unconditionalInits());
/*     */     } 
/* 576 */     return mergedInfo;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int reachMode() {
/* 585 */     return this.tagBits & 0x3;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract FlowInfo safeInitsWhenTrue();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract FlowInfo setReachMode(int paramInt);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract UnconditionalFlowInfo mergedWith(UnconditionalFlowInfo paramUnconditionalFlowInfo);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract UnconditionalFlowInfo mergeDefiniteInitsWith(UnconditionalFlowInfo paramUnconditionalFlowInfo);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract UnconditionalFlowInfo nullInfoLessUnconditionalCopy();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 634 */     if (this == DEAD_END) {
/* 635 */       return "FlowInfo.DEAD_END";
/*     */     }
/* 637 */     return super.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract UnconditionalFlowInfo unconditionalCopy();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract UnconditionalFlowInfo unconditionalFieldLessCopy();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract UnconditionalFlowInfo unconditionalInits();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract UnconditionalFlowInfo unconditionalInitsWithoutSideEffect();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract void resetAssignmentInfo(LocalVariableBinding paramLocalVariableBinding);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int tagBitsToNullStatus(long tagBits) {
/* 686 */     if ((tagBits & 0x100000000000000L) != 0L)
/* 687 */       return 4; 
/* 688 */     if ((tagBits & 0x80000000000000L) != 0L)
/* 689 */       return 24; 
/* 690 */     return 1;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\flow\FlowInfo.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */