/*     */ package org.eclipse.jdt.internal.compiler.apt.model;
/*     */ 
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.lang.annotation.Inherited;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import javax.lang.model.element.AnnotationMirror;
/*     */ import javax.lang.model.element.Element;
/*     */ import javax.lang.model.element.ElementKind;
/*     */ import javax.lang.model.element.Modifier;
/*     */ import javax.lang.model.element.Name;
/*     */ import javax.lang.model.element.PackageElement;
/*     */ import javax.lang.model.type.TypeMirror;
/*     */ import org.eclipse.jdt.internal.compiler.apt.dispatch.BaseProcessingEnvImpl;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.AnnotationBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.Binding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.ReferenceBinding;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class ElementImpl
/*     */   implements Element, IElementInfo
/*     */ {
/*     */   public final BaseProcessingEnvImpl _env;
/*     */   public final Binding _binding;
/*     */   
/*     */   protected ElementImpl(BaseProcessingEnvImpl env, Binding binding) {
/*  46 */     this._env = env;
/*  47 */     this._binding = binding;
/*     */   }
/*     */ 
/*     */   
/*     */   public TypeMirror asType() {
/*  52 */     return this._env.getFactory().newTypeMirror(this._binding);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected abstract AnnotationBinding[] getAnnotationBindings();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final AnnotationBinding[] getPackedAnnotationBindings() {
/*  66 */     return Factory.getPackedAnnotationBindings(getAnnotationBindings());
/*     */   }
/*     */ 
/*     */   
/*     */   public <A extends Annotation> A getAnnotation(Class<A> annotationClass) {
/*  71 */     A annotation = this._env.getFactory().getAnnotation(getPackedAnnotationBindings(), annotationClass);
/*  72 */     if (annotation != null || getKind() != ElementKind.CLASS || annotationClass.getAnnotation(Inherited.class) == null) {
/*  73 */       return annotation;
/*     */     }
/*  75 */     ElementImpl superClass = (ElementImpl)this._env.getFactory().newElement((Binding)((ReferenceBinding)this._binding).superclass());
/*  76 */     return (superClass == null) ? null : superClass.<A>getAnnotation(annotationClass);
/*     */   }
/*     */ 
/*     */   
/*     */   public List<? extends AnnotationMirror> getAnnotationMirrors() {
/*  81 */     return this._env.getFactory().getAnnotationMirrors(getPackedAnnotationBindings());
/*     */   }
/*     */ 
/*     */   
/*     */   public <A extends Annotation> A[] getAnnotationsByType(Class<A> annotationType) {
/*  86 */     Annotation[] annotations = this._env.getFactory().getAnnotationsByType(Factory.getUnpackedAnnotationBindings(getPackedAnnotationBindings()), annotationType);
/*  87 */     if (annotations.length != 0 || getKind() != ElementKind.CLASS || annotationType.getAnnotation(Inherited.class) == null) {
/*  88 */       return (A[])annotations;
/*     */     }
/*  90 */     ElementImpl superClass = (ElementImpl)this._env.getFactory().newElement((Binding)((ReferenceBinding)this._binding).superclass());
/*  91 */     return (superClass == null) ? (A[])annotations : superClass.<A>getAnnotationsByType(annotationType);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Set<Modifier> getModifiers() {
/*  98 */     return Collections.emptySet();
/*     */   }
/*     */ 
/*     */   
/*     */   public Name getSimpleName() {
/* 103 */     return new NameImpl(this._binding.shortReadableName());
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 108 */     return this._binding.hashCode();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object obj) {
/* 115 */     if (this == obj)
/* 116 */       return true; 
/* 117 */     if (obj == null)
/* 118 */       return false; 
/* 119 */     if (getClass() != obj.getClass())
/* 120 */       return false; 
/* 121 */     ElementImpl other = (ElementImpl)obj;
/* 122 */     if (this._binding == null) {
/* 123 */       if (other._binding != null)
/* 124 */         return false; 
/* 125 */     } else if (this._binding != other._binding) {
/* 126 */       return false;
/* 127 */     }  return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 132 */     return this._binding.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getFileName() {
/* 138 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   PackageElement getPackage() {
/* 145 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean hides(Element hidden) {
/* 156 */     return false;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\apt\model\ElementImpl.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */