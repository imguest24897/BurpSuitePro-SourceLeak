/*    */ package org.eclipse.jdt.internal.compiler.ast;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class OpensStatement
/*    */   extends PackageVisibilityStatement
/*    */ {
/*    */   public OpensStatement(ImportReference pkgRef) {
/* 22 */     this(pkgRef, null);
/*    */   }
/*    */   public OpensStatement(ImportReference pkgRef, ModuleReference[] targets) {
/* 25 */     super(pkgRef, targets);
/*    */   }
/*    */   
/*    */   public int computeSeverity(int problemId) {
/* 29 */     switch (problemId) {
/*    */       case 8389919:
/* 31 */         return 0;
/*    */     } 
/* 33 */     return 1;
/*    */   }
/*    */ 
/*    */   
/*    */   public StringBuffer print(int indent, StringBuffer output) {
/* 38 */     printIndent(indent, output);
/* 39 */     output.append("opens ");
/* 40 */     super.print(0, output);
/* 41 */     output.append(";");
/* 42 */     return output;
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\ast\OpensStatement.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */