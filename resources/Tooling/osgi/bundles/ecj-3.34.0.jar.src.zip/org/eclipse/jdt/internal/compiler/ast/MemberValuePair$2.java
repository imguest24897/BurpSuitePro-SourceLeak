/*     */ package org.eclipse.jdt.internal.compiler.ast;
/*     */ 
/*     */ import org.eclipse.jdt.internal.compiler.lookup.BlockScope;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.Scope;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.TypeBinding;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class null
/*     */   implements Runnable
/*     */ {
/*     */   public void run() {
/* 116 */     if (!MemberValuePair.this.value.isConstantValueOfTypeAssignableToType(valueType, requiredType) && 
/* 117 */       !valueType.isCompatibleWith(requiredType)) {
/* 118 */       if (!requiredType.isArrayType() || 
/* 119 */         requiredType.dimensions() != 1 || (
/* 120 */         !MemberValuePair.this.value.isConstantValueOfTypeAssignableToType(valueType, leafType) && 
/* 121 */         !valueType.isCompatibleWith(leafType))) {
/*     */         
/* 123 */         if (leafType.isAnnotationType() && !valueType.isAnnotationType()) {
/* 124 */           scope.problemReporter().annotationValueMustBeAnnotation((TypeBinding)MemberValuePair.this.binding.declaringClass, 
/* 125 */               MemberValuePair.this.name, MemberValuePair.this.value, leafType);
/*     */         } else {
/* 127 */           scope.problemReporter().typeMismatchError(valueType, requiredType, MemberValuePair.this.value, null);
/*     */         } 
/* 129 */         shouldExit[0] = true;
/*     */       } 
/*     */     } else {
/* 132 */       scope.compilationUnitScope().recordTypeConversion(requiredType.leafComponentType(), valueType.leafComponentType());
/* 133 */       MemberValuePair.this.value.computeConversion((Scope)scope, requiredType, valueType);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\ast\MemberValuePair$2.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */