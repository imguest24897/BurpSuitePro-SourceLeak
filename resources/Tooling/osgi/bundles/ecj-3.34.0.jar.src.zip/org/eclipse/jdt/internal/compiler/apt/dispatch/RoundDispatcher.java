/*     */ package org.eclipse.jdt.internal.compiler.apt.dispatch;
/*     */ 
/*     */ import java.io.PrintWriter;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import javax.annotation.processing.RoundEnvironment;
/*     */ import javax.lang.model.element.Element;
/*     */ import javax.lang.model.element.TypeElement;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RoundDispatcher
/*     */ {
/*     */   private final Set<TypeElement> _unclaimedAnnotations;
/*     */   private final RoundEnvironment _roundEnv;
/*     */   private final IProcessorProvider _provider;
/*     */   private boolean _searchForStar = false;
/*     */   private final PrintWriter _traceProcessorInfo;
/*     */   private final PrintWriter _traceRounds;
/*     */   private final List<ProcessorInfo> _processors;
/*     */   
/*     */   public RoundDispatcher(IProcessorProvider provider, RoundEnvironment env, Set<TypeElement> rootAnnotations, PrintWriter traceProcessorInfo, PrintWriter traceRounds) {
/*  61 */     this._provider = provider;
/*  62 */     this._processors = provider.getDiscoveredProcessors();
/*  63 */     this._roundEnv = env;
/*  64 */     this._unclaimedAnnotations = new HashSet<>(rootAnnotations);
/*  65 */     this._traceProcessorInfo = traceProcessorInfo;
/*  66 */     this._traceRounds = traceRounds;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void round() {
/*  74 */     if (this._traceRounds != null) {
/*  75 */       StringBuilder sbElements = new StringBuilder();
/*  76 */       sbElements.append("\tinput files: {");
/*  77 */       Iterator<? extends Element> iElements = this._roundEnv.getRootElements().iterator();
/*  78 */       boolean hasNext = iElements.hasNext();
/*  79 */       while (hasNext) {
/*  80 */         sbElements.append(iElements.next());
/*  81 */         hasNext = iElements.hasNext();
/*  82 */         if (hasNext) {
/*  83 */           sbElements.append(',');
/*     */         }
/*     */       } 
/*  86 */       sbElements.append('}');
/*  87 */       this._traceRounds.println(sbElements.toString());
/*     */       
/*  89 */       StringBuilder sbAnnots = new StringBuilder();
/*  90 */       sbAnnots.append("\tannotations: [");
/*  91 */       Iterator<TypeElement> iAnnots = this._unclaimedAnnotations.iterator();
/*  92 */       hasNext = iAnnots.hasNext();
/*  93 */       while (hasNext) {
/*  94 */         sbAnnots.append(iAnnots.next());
/*  95 */         hasNext = iAnnots.hasNext();
/*  96 */         if (hasNext) {
/*  97 */           sbAnnots.append(',');
/*     */         }
/*     */       } 
/* 100 */       sbAnnots.append(']');
/* 101 */       this._traceRounds.println(sbAnnots.toString());
/*     */       
/* 103 */       this._traceRounds.println("\tlast round: " + this._roundEnv.processingOver());
/*     */     } 
/*     */ 
/*     */     
/* 107 */     this._searchForStar = this._unclaimedAnnotations.isEmpty();
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 112 */     for (ProcessorInfo pi : this._processors) {
/* 113 */       handleProcessor(pi);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 118 */     while (this._searchForStar || !this._unclaimedAnnotations.isEmpty()) {
/* 119 */       ProcessorInfo pi = this._provider.discoverNextProcessor();
/* 120 */       if (pi == null) {
/*     */         break;
/*     */       }
/*     */       
/* 124 */       handleProcessor(pi);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void handleProcessor(ProcessorInfo pi) {
/*     */     try {
/* 138 */       Set<TypeElement> annotationsToProcess = new HashSet<>();
/* 139 */       boolean shouldCall = pi.computeSupportedAnnotations(
/* 140 */           this._unclaimedAnnotations, annotationsToProcess);
/* 141 */       if (shouldCall) {
/* 142 */         boolean claimed = pi._processor.process(annotationsToProcess, this._roundEnv);
/* 143 */         if (this._traceProcessorInfo != null && !this._roundEnv.processingOver()) {
/* 144 */           StringBuilder sb = new StringBuilder();
/* 145 */           sb.append("Processor ");
/* 146 */           sb.append(pi._processor.getClass().getName());
/* 147 */           sb.append(" matches [");
/* 148 */           Iterator<TypeElement> i = annotationsToProcess.iterator();
/* 149 */           boolean hasNext = i.hasNext();
/* 150 */           while (hasNext) {
/* 151 */             sb.append(i.next());
/* 152 */             hasNext = i.hasNext();
/* 153 */             if (hasNext) {
/* 154 */               sb.append(' ');
/*     */             }
/*     */           } 
/* 157 */           sb.append("] and returns ");
/* 158 */           sb.append(claimed);
/* 159 */           this._traceProcessorInfo.println(sb.toString());
/*     */         } 
/* 161 */         if (claimed) {
/*     */           
/* 163 */           this._unclaimedAnnotations.removeAll(annotationsToProcess);
/* 164 */           if (pi.supportsStar()) {
/* 165 */             this._searchForStar = false;
/*     */           }
/*     */         } 
/*     */       } 
/* 169 */     } catch (Throwable e) {
/*     */ 
/*     */       
/* 172 */       this._provider.reportProcessorException(pi._processor, new Exception(e));
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\apt\dispatch\RoundDispatcher.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */