/*     */ package org.eclipse.jdt.internal.compiler.lookup;
/*     */ 
/*     */ import org.eclipse.jdt.core.compiler.CharOperation;
/*     */ import org.eclipse.jdt.internal.compiler.ast.ASTNode;
/*     */ import org.eclipse.jdt.internal.compiler.ast.TypeParameter;
/*     */ import org.eclipse.jdt.internal.compiler.impl.CompilerOptions;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CaptureBinding
/*     */   extends TypeVariableBinding
/*     */ {
/*     */   public TypeBinding lowerBound;
/*     */   public WildcardBinding wildcard;
/*     */   public int captureID;
/*     */   public ReferenceBinding sourceType;
/*     */   public int start;
/*     */   public int end;
/*     */   public ASTNode cud;
/*     */   TypeBinding pendingSubstitute;
/*     */   
/*     */   public CaptureBinding(WildcardBinding wildcard, ReferenceBinding sourceType, int start, int end, ASTNode cud, int captureID) {
/*  46 */     super(TypeConstants.WILDCARD_CAPTURE_NAME_PREFIX, wildcard.environment);
/*  47 */     this.wildcard = wildcard;
/*  48 */     this.modifiers = 1073741825;
/*  49 */     this.fPackage = wildcard.fPackage;
/*  50 */     this.sourceType = sourceType;
/*  51 */     this.start = start;
/*  52 */     this.end = end;
/*  53 */     this.captureID = captureID;
/*  54 */     this.tagBits |= 0x2000000000000000L;
/*  55 */     this.cud = cud;
/*  56 */     if (wildcard.hasTypeAnnotations()) {
/*     */       
/*  58 */       CaptureBinding unannotated = (CaptureBinding)clone((TypeBinding)null);
/*  59 */       unannotated.wildcard = (WildcardBinding)this.wildcard.unannotated();
/*  60 */       this.environment.getUnannotatedType(unannotated);
/*  61 */       this.id = unannotated.id;
/*     */       
/*  63 */       this.environment.typeSystem.cacheDerivedType(this, unannotated, this);
/*     */       
/*  65 */       super.setTypeAnnotations(wildcard.getTypeAnnotations(), wildcard.environment.globalOptions.isAnnotationBasedNullAnalysisEnabled);
/*  66 */       if (wildcard.hasNullTypeAnnotations())
/*  67 */         this.tagBits |= 0x100000L; 
/*     */     } else {
/*  69 */       computeId(this.environment);
/*  70 */       if (wildcard.hasNullTypeAnnotations()) {
/*  71 */         this.tagBits |= wildcard.tagBits & 0x180000000000000L | 0x100000L;
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   protected CaptureBinding(ReferenceBinding sourceType, char[] sourceName, int start, int end, int captureID, LookupEnvironment environment) {
/*  78 */     super(sourceName, (Binding)null, 0, environment);
/*  79 */     this.modifiers = 1073741825;
/*  80 */     this.sourceType = sourceType;
/*  81 */     this.start = start;
/*  82 */     this.end = end;
/*  83 */     this.captureID = captureID;
/*     */   }
/*     */   
/*     */   public CaptureBinding(CaptureBinding prototype) {
/*  87 */     super(prototype);
/*  88 */     this.wildcard = prototype.wildcard;
/*  89 */     this.sourceType = prototype.sourceType;
/*  90 */     this.start = prototype.start;
/*  91 */     this.end = prototype.end;
/*  92 */     this.captureID = prototype.captureID;
/*  93 */     this.lowerBound = prototype.lowerBound;
/*  94 */     this.tagBits |= prototype.tagBits & 0x2000000000000000L;
/*  95 */     this.cud = prototype.cud;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public TypeBinding clone(TypeBinding enclosingType) {
/* 101 */     return new CaptureBinding(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public char[] computeUniqueKey(boolean isLeaf) {
/* 111 */     StringBuilder buffer = new StringBuilder();
/* 112 */     if (isLeaf) {
/* 113 */       buffer.append(this.sourceType.computeUniqueKey(false));
/* 114 */       buffer.append('&');
/*     */     } 
/* 116 */     buffer.append(TypeConstants.WILDCARD_CAPTURE);
/* 117 */     buffer.append(this.wildcard.computeUniqueKey(false));
/* 118 */     buffer.append(this.end);
/* 119 */     buffer.append(';');
/* 120 */     int length = buffer.length();
/* 121 */     char[] uniqueKey = new char[length];
/* 122 */     buffer.getChars(0, length, uniqueKey, 0);
/* 123 */     return uniqueKey;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String debugName() {
/* 129 */     if (this.wildcard != null) {
/* 130 */       StringBuilder buffer = new StringBuilder(10);
/* 131 */       AnnotationBinding[] annotations = getTypeAnnotations();
/* 132 */       for (int i = 0, length = (annotations == null) ? 0 : annotations.length; i < length; i++) {
/* 133 */         buffer.append(annotations[i]);
/* 134 */         buffer.append(' ');
/*     */       } 
/* 136 */       buffer
/* 137 */         .append(TypeConstants.WILDCARD_CAPTURE_NAME_PREFIX)
/* 138 */         .append(this.captureID)
/* 139 */         .append(TypeConstants.WILDCARD_CAPTURE_NAME_SUFFIX)
/* 140 */         .append(this.wildcard.debugName());
/* 141 */       return buffer.toString();
/*     */     } 
/* 143 */     return super.debugName();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public char[] genericTypeSignature() {
/* 149 */     if (this.inRecursiveFunction)
/*     */     {
/*     */       
/* 152 */       return CharOperation.concat(new char[] { 'L' }, CharOperation.concatWith(TypeConstants.JAVA_LANG_OBJECT, '.'), new char[] { ';' });
/*     */     }
/* 154 */     this.inRecursiveFunction = true;
/*     */     try {
/* 156 */       return erasure().genericTypeSignature();
/*     */     } finally {
/* 158 */       this.inRecursiveFunction = false;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void initializeBounds(Scope scope, ParameterizedTypeBinding capturedParameterizedType) {
/*     */     TypeBinding capturedWildcardBound;
/* 167 */     boolean is18plus = ((scope.compilerOptions()).complianceLevel >= 3407872L);
/* 168 */     TypeVariableBinding wildcardVariable = this.wildcard.typeVariable();
/* 169 */     if (wildcardVariable == null) {
/*     */ 
/*     */       
/* 172 */       TypeBinding typeBinding2, typeBinding1 = this.wildcard.bound;
/* 173 */       switch (this.wildcard.boundKind) {
/*     */         
/*     */         case 1:
/* 176 */           typeBinding2 = is18plus ? 
/* 177 */             typeBinding1 : 
/* 178 */             typeBinding1.capture(scope, this.start, this.end);
/* 179 */           if (typeBinding1.isInterface()) {
/* 180 */             setSuperClass(scope.getJavaLangObject());
/* 181 */             setSuperInterfaces(new ReferenceBinding[] { (ReferenceBinding)typeBinding2 });
/*     */           }
/*     */           else {
/*     */             
/* 185 */             if (typeBinding2.isArrayType() || TypeBinding.equalsEquals(typeBinding2, this)) {
/* 186 */               setSuperClass(scope.getJavaLangObject());
/*     */             } else {
/* 188 */               setSuperClass((ReferenceBinding)typeBinding2);
/*     */             } 
/* 190 */             setSuperInterfaces(Binding.NO_SUPERINTERFACES);
/*     */           } 
/* 192 */           setFirstBound(typeBinding2);
/* 193 */           if ((typeBinding2.tagBits & 0x20000000L) == 0L)
/* 194 */             this.tagBits &= 0xFFFFFFFFDFFFFFFFL; 
/*     */           break;
/*     */         case 0:
/* 197 */           setSuperClass(scope.getJavaLangObject());
/* 198 */           setSuperInterfaces(Binding.NO_SUPERINTERFACES);
/* 199 */           this.tagBits &= 0xFFFFFFFFDFFFFFFFL;
/*     */           break;
/*     */         case 2:
/* 202 */           setSuperClass(scope.getJavaLangObject());
/* 203 */           setSuperInterfaces(Binding.NO_SUPERINTERFACES);
/* 204 */           this.lowerBound = this.wildcard.bound;
/* 205 */           if ((typeBinding1.tagBits & 0x20000000L) == 0L)
/* 206 */             this.tagBits &= 0xFFFFFFFFDFFFFFFFL; 
/*     */           break;
/*     */       } 
/*     */       return;
/*     */     } 
/* 211 */     ReferenceBinding originalVariableSuperclass = wildcardVariable.superclass;
/* 212 */     ReferenceBinding substitutedVariableSuperclass = (ReferenceBinding)Scope.substitute(capturedParameterizedType, originalVariableSuperclass);
/*     */     
/* 214 */     if (TypeBinding.equalsEquals(substitutedVariableSuperclass, this)) substitutedVariableSuperclass = originalVariableSuperclass;
/*     */     
/* 216 */     ReferenceBinding[] originalVariableInterfaces = wildcardVariable.superInterfaces();
/* 217 */     ReferenceBinding[] substitutedVariableInterfaces = Scope.substitute(capturedParameterizedType, originalVariableInterfaces);
/* 218 */     if (substitutedVariableInterfaces != originalVariableInterfaces)
/*     */     {
/* 220 */       for (int i = 0, length = substitutedVariableInterfaces.length; i < length; i++) {
/* 221 */         if (TypeBinding.equalsEquals(substitutedVariableInterfaces[i], this)) substitutedVariableInterfaces[i] = originalVariableInterfaces[i];
/*     */       
/*     */       } 
/*     */     }
/* 225 */     TypeBinding originalWildcardBound = this.wildcard.bound;
/*     */     
/* 227 */     switch (this.wildcard.boundKind) {
/*     */       
/*     */       case 1:
/* 230 */         capturedWildcardBound = is18plus ? 
/* 231 */           originalWildcardBound : 
/* 232 */           originalWildcardBound.capture(scope, this.start, this.end);
/* 233 */         if (originalWildcardBound.isInterface()) {
/* 234 */           setSuperClass(substitutedVariableSuperclass);
/*     */           
/* 236 */           if (substitutedVariableInterfaces == Binding.NO_SUPERINTERFACES) {
/* 237 */             setSuperInterfaces(new ReferenceBinding[] { (ReferenceBinding)capturedWildcardBound });
/*     */           } else {
/* 239 */             int length = substitutedVariableInterfaces.length;
/* 240 */             System.arraycopy(substitutedVariableInterfaces, 0, substitutedVariableInterfaces = new ReferenceBinding[length + 1], 1, length);
/* 241 */             substitutedVariableInterfaces[0] = (ReferenceBinding)capturedWildcardBound;
/* 242 */             setSuperInterfaces(Scope.greaterLowerBound(substitutedVariableInterfaces));
/*     */           }
/*     */         
/*     */         } else {
/*     */           
/* 247 */           if (capturedWildcardBound.isArrayType() || TypeBinding.equalsEquals(capturedWildcardBound, this)) {
/* 248 */             setSuperClass(substitutedVariableSuperclass);
/*     */           } else {
/* 250 */             setSuperClass((ReferenceBinding)capturedWildcardBound);
/* 251 */             if (this.superclass.isSuperclassOf(substitutedVariableSuperclass)) {
/* 252 */               setSuperClass(substitutedVariableSuperclass);
/*     */             }
/*     */           } 
/*     */ 
/*     */           
/* 257 */           setSuperInterfaces(substitutedVariableInterfaces);
/*     */         } 
/* 259 */         setFirstBound(capturedWildcardBound);
/* 260 */         if ((capturedWildcardBound.tagBits & 0x20000000L) == 0L)
/* 261 */           this.tagBits &= 0xFFFFFFFFDFFFFFFFL; 
/*     */         break;
/*     */       case 0:
/* 264 */         setSuperClass(substitutedVariableSuperclass);
/* 265 */         setSuperInterfaces(substitutedVariableInterfaces);
/* 266 */         this.tagBits &= 0xFFFFFFFFDFFFFFFFL;
/*     */         break;
/*     */       case 2:
/* 269 */         setSuperClass(substitutedVariableSuperclass);
/* 270 */         if (TypeBinding.equalsEquals(wildcardVariable.firstBound, substitutedVariableSuperclass) || TypeBinding.equalsEquals(originalWildcardBound, substitutedVariableSuperclass)) {
/* 271 */           setFirstBound(substitutedVariableSuperclass);
/*     */         }
/* 273 */         setSuperInterfaces(substitutedVariableInterfaces);
/* 274 */         this.lowerBound = originalWildcardBound;
/* 275 */         if ((originalWildcardBound.tagBits & 0x20000000L) == 0L)
/* 276 */           this.tagBits &= 0xFFFFFFFFDFFFFFFFL; 
/*     */         break;
/*     */     } 
/* 279 */     if (scope.environment().usesNullTypeAnnotations()) {
/* 280 */       evaluateNullAnnotations(scope, (TypeParameter)null);
/*     */     }
/*     */   }
/*     */   
/*     */   public ReferenceBinding upwardsProjection(Scope scope, TypeBinding[] mentionedTypeVariables) {
/* 285 */     if (enterRecursiveProjectionFunction()) {
/*     */       try {
/* 287 */         for (int i = 0; i < mentionedTypeVariables.length; i++) {
/* 288 */           if (TypeBinding.equalsEquals(this, mentionedTypeVariables[i])) {
/* 289 */             TypeBinding upperBoundForProjection = upperBoundForProjection();
/* 290 */             if (upperBoundForProjection == null)
/* 291 */               upperBoundForProjection = scope.getJavaLangObject(); 
/* 292 */             return ((ReferenceBinding)upperBoundForProjection).upwardsProjection(scope, mentionedTypeVariables);
/*     */           } 
/*     */         } 
/* 295 */         return this;
/*     */       } finally {
/* 297 */         exitRecursiveProjectionFunction();
/*     */       } 
/*     */     }
/* 300 */     return scope.getJavaLangObject();
/*     */   }
/*     */   
/*     */   public TypeBinding upperBoundForProjection() {
/* 304 */     TypeBinding upperBound = null;
/* 305 */     if (this.wildcard != null) {
/* 306 */       ReferenceBinding[] supers = superInterfaces();
/* 307 */       if (this.wildcard.boundKind == 1) {
/* 308 */         if (supers.length > 0) {
/* 309 */           ReferenceBinding[] allBounds = new ReferenceBinding[supers.length + 1];
/* 310 */           System.arraycopy(supers, 0, allBounds, 1, supers.length);
/* 311 */           allBounds[0] = superclass();
/* 312 */           ReferenceBinding[] glbs = Scope.greaterLowerBound(allBounds);
/* 313 */           if (glbs == null) {
/* 314 */             upperBound = new ProblemReferenceBinding(null, null, 10);
/* 315 */           } else if (glbs.length == 1) {
/* 316 */             upperBound = glbs[0];
/*     */           } else {
/* 318 */             upperBound = this.environment.createIntersectionType18(glbs);
/*     */           } 
/*     */         } else {
/* 321 */           upperBound = this.superclass;
/*     */         }
/*     */       
/*     */       }
/*     */       else {
/*     */         
/* 327 */         boolean superClassIsObject = TypeBinding.equalsEquals(superclass(), this.environment.getResolvedJavaBaseType(TypeConstants.JAVA_LANG_OBJECT, null));
/* 328 */         if (supers.length == 0) {
/* 329 */           upperBound = superclass();
/* 330 */         } else if (supers.length == 1) {
/* 331 */           upperBound = superClassIsObject ? supers[0] : this.environment.createIntersectionType18(new ReferenceBinding[] { superclass(), supers[0] });
/*     */         }
/* 333 */         else if (superClassIsObject) {
/* 334 */           upperBound = this.environment.createIntersectionType18(supers);
/*     */         } else {
/* 336 */           ReferenceBinding[] allBounds = new ReferenceBinding[supers.length + 1];
/* 337 */           System.arraycopy(supers, 0, allBounds, 1, supers.length);
/* 338 */           allBounds[0] = superclass();
/* 339 */           upperBound = this.environment.createIntersectionType18(allBounds);
/*     */         } 
/*     */       } 
/*     */     } else {
/*     */       
/* 344 */       upperBound = upperBound();
/*     */     } 
/* 346 */     return upperBound;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isCapture() {
/* 354 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isEquivalentTo(TypeBinding otherType) {
/* 362 */     if (equalsEquals(this, otherType)) return true; 
/* 363 */     if (otherType == null) return false;
/*     */     
/* 365 */     if (this.firstBound != null && this.firstBound.isArrayType() && 
/* 366 */       this.firstBound.isCompatibleWith(otherType)) {
/* 367 */       return true;
/*     */     }
/* 369 */     switch (otherType.kind()) {
/*     */       case 516:
/*     */       case 8196:
/* 372 */         return ((WildcardBinding)otherType).boundCheck(this);
/*     */     } 
/* 374 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isProperType(boolean admitCapture18) {
/* 379 */     if (this.lowerBound != null && !this.lowerBound.isProperType(admitCapture18))
/* 380 */       return false; 
/* 381 */     if (this.wildcard != null && !this.wildcard.isProperType(admitCapture18))
/* 382 */       return false; 
/* 383 */     return super.isProperType(admitCapture18);
/*     */   }
/*     */ 
/*     */   
/*     */   public char[] readableName() {
/* 388 */     if (this.wildcard != null) {
/* 389 */       StringBuilder buffer = new StringBuilder(10);
/* 390 */       buffer
/* 391 */         .append(TypeConstants.WILDCARD_CAPTURE_NAME_PREFIX)
/* 392 */         .append(this.captureID)
/* 393 */         .append(TypeConstants.WILDCARD_CAPTURE_NAME_SUFFIX)
/* 394 */         .append(this.wildcard.readableName());
/* 395 */       int length = buffer.length();
/* 396 */       char[] name = new char[length];
/* 397 */       buffer.getChars(0, length, name, 0);
/* 398 */       return name;
/*     */     } 
/* 400 */     return super.readableName();
/*     */   }
/*     */ 
/*     */   
/*     */   public char[] signableName() {
/* 405 */     if (this.wildcard != null) {
/* 406 */       StringBuilder buffer = new StringBuilder(10);
/* 407 */       buffer
/* 408 */         .append(TypeConstants.WILDCARD_CAPTURE_SIGNABLE_NAME_SUFFIX)
/* 409 */         .append(this.wildcard.readableName());
/* 410 */       int length = buffer.length();
/* 411 */       char[] name = new char[length];
/* 412 */       buffer.getChars(0, length, name, 0);
/* 413 */       return name;
/*     */     } 
/* 415 */     return super.readableName();
/*     */   }
/*     */ 
/*     */   
/*     */   public char[] shortReadableName() {
/* 420 */     if (this.wildcard != null) {
/* 421 */       StringBuilder buffer = new StringBuilder(10);
/* 422 */       buffer
/* 423 */         .append(TypeConstants.WILDCARD_CAPTURE_NAME_PREFIX)
/* 424 */         .append(this.captureID)
/* 425 */         .append(TypeConstants.WILDCARD_CAPTURE_NAME_SUFFIX)
/* 426 */         .append(this.wildcard.shortReadableName());
/* 427 */       int length = buffer.length();
/* 428 */       char[] name = new char[length];
/* 429 */       buffer.getChars(0, length, name, 0);
/* 430 */       return name;
/*     */     } 
/* 432 */     return super.shortReadableName();
/*     */   }
/*     */ 
/*     */   
/*     */   public char[] nullAnnotatedReadableName(CompilerOptions options, boolean shortNames) {
/* 437 */     StringBuffer nameBuffer = new StringBuffer(10);
/* 438 */     appendNullAnnotation(nameBuffer, options);
/* 439 */     nameBuffer.append(sourceName());
/* 440 */     if (!this.inRecursiveFunction) {
/* 441 */       this.inRecursiveFunction = true;
/*     */       try {
/* 443 */         if (this.wildcard != null) {
/* 444 */           nameBuffer.append("of ");
/* 445 */           nameBuffer.append(this.wildcard.withoutToplevelNullAnnotation().nullAnnotatedReadableName(options, shortNames));
/* 446 */         } else if (this.lowerBound != null) {
/* 447 */           nameBuffer.append(" super ");
/* 448 */           nameBuffer.append(this.lowerBound.nullAnnotatedReadableName(options, shortNames));
/* 449 */         } else if (this.firstBound != null) {
/* 450 */           nameBuffer.append(" extends ");
/* 451 */           nameBuffer.append(this.firstBound.nullAnnotatedReadableName(options, shortNames));
/* 452 */           TypeBinding[] otherUpperBounds = otherUpperBounds();
/* 453 */           if (otherUpperBounds != NO_TYPES)
/* 454 */             nameBuffer.append(" & ..."); 
/*     */         } 
/*     */       } finally {
/* 457 */         this.inRecursiveFunction = false;
/*     */       } 
/*     */     } 
/* 460 */     int nameLength = nameBuffer.length();
/* 461 */     char[] readableName = new char[nameLength];
/* 462 */     nameBuffer.getChars(0, nameLength, readableName, 0);
/* 463 */     return readableName;
/*     */   }
/*     */ 
/*     */   
/*     */   public TypeBinding withoutToplevelNullAnnotation() {
/* 468 */     if (!hasNullTypeAnnotations())
/* 469 */       return this; 
/* 470 */     if (this.wildcard != null && this.wildcard.hasNullTypeAnnotations()) {
/* 471 */       WildcardBinding newWildcard = (WildcardBinding)this.wildcard.withoutToplevelNullAnnotation();
/* 472 */       if (newWildcard != this.wildcard) {
/*     */         
/* 474 */         CaptureBinding newCapture = (CaptureBinding)this.environment.getUnannotatedType(this).clone((TypeBinding)null);
/* 475 */         if (newWildcard.hasTypeAnnotations())
/* 476 */           newCapture.tagBits |= 0x200000L; 
/* 477 */         newCapture.wildcard = newWildcard;
/*     */ 
/*     */         
/* 480 */         newCapture.superclass = this.superclass;
/* 481 */         newCapture.superInterfaces = this.superInterfaces;
/*     */         
/* 483 */         AnnotationBinding[] newAnnotations = this.environment.filterNullTypeAnnotations(this.typeAnnotations);
/* 484 */         return this.environment.createAnnotatedType(newCapture, newAnnotations);
/*     */       } 
/*     */     } 
/* 487 */     return super.withoutToplevelNullAnnotation();
/*     */   }
/*     */ 
/*     */   
/*     */   TypeBinding substituteInferenceVariable(InferenceVariable var, TypeBinding substituteType) {
/* 492 */     if (this.pendingSubstitute != null)
/* 493 */       return this.pendingSubstitute; 
/*     */     try {
/* 495 */       TypeBinding substitutedWildcard = this.wildcard.substituteInferenceVariable(var, substituteType);
/* 496 */       if (substitutedWildcard != this.wildcard) {
/* 497 */         CaptureBinding substitute = (CaptureBinding)clone(enclosingType());
/* 498 */         substitute.wildcard = (WildcardBinding)substitutedWildcard;
/* 499 */         this.pendingSubstitute = substitute;
/* 500 */         if (this.lowerBound != null)
/* 501 */           substitute.lowerBound = this.lowerBound.substituteInferenceVariable(var, substituteType); 
/* 502 */         if (this.firstBound != null)
/* 503 */           substitute.firstBound = this.firstBound.substituteInferenceVariable(var, substituteType); 
/* 504 */         if (this.superclass != null)
/* 505 */           substitute.superclass = (ReferenceBinding)this.superclass.substituteInferenceVariable(var, substituteType); 
/* 506 */         if (this.superInterfaces != null) {
/* 507 */           int length = this.superInterfaces.length;
/* 508 */           substitute.superInterfaces = new ReferenceBinding[length];
/* 509 */           for (int i = 0; i < length; i++)
/* 510 */             substitute.superInterfaces[i] = (ReferenceBinding)this.superInterfaces[i].substituteInferenceVariable(var, substituteType); 
/*     */         } 
/* 512 */         return substitute;
/*     */       } 
/* 514 */       return this;
/*     */     } finally {
/* 516 */       this.pendingSubstitute = null;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void setTypeAnnotations(AnnotationBinding[] annotations, boolean evalNullAnnotations) {
/* 522 */     super.setTypeAnnotations(annotations, evalNullAnnotations);
/* 523 */     if (annotations != Binding.NO_ANNOTATIONS && this.wildcard != null)
/*     */     {
/* 525 */       this.wildcard = (WildcardBinding)this.wildcard.environment.createAnnotatedType(this.wildcard, annotations);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public TypeBinding uncapture(Scope scope) {
/* 531 */     return this.wildcard.uncapture(scope);
/*     */   }
/*     */ 
/*     */   
/*     */   public ReferenceBinding downwardsProjection(Scope scope, TypeBinding[] mentionedTypeVariables) {
/* 536 */     ReferenceBinding result = null;
/* 537 */     if (enterRecursiveProjectionFunction()) {
/* 538 */       for (int i = 0; i < mentionedTypeVariables.length; i++) {
/* 539 */         if (TypeBinding.equalsEquals(this, mentionedTypeVariables[i])) {
/* 540 */           if (this.lowerBound != null) {
/* 541 */             result = (ReferenceBinding)this.lowerBound.downwardsProjection(scope, mentionedTypeVariables);
/*     */           }
/*     */           break;
/*     */         } 
/*     */       } 
/* 546 */       exitRecursiveProjectionFunction();
/*     */     } 
/* 548 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected TypeBinding[] getDerivedTypesForDeferredInitialization() {
/* 558 */     TypeBinding[] derived = this.environment.typeSystem.getDerivedTypes(this);
/* 559 */     if (derived.length > 0) {
/* 560 */       int count = 0;
/* 561 */       for (int i = 0; i < derived.length; i++) {
/* 562 */         if (derived[i] != null && (derived[i]).id == this.id)
/* 563 */           derived[count++] = derived[i]; 
/*     */       } 
/* 565 */       if (count < derived.length)
/* 566 */         System.arraycopy(derived, 0, derived = new TypeBinding[count], 0, count); 
/*     */     } 
/* 568 */     return derived;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 573 */     if (this.wildcard != null) {
/* 574 */       StringBuilder buffer = new StringBuilder(10);
/* 575 */       AnnotationBinding[] annotations = getTypeAnnotations();
/* 576 */       for (int i = 0, length = (annotations == null) ? 0 : annotations.length; i < length; i++) {
/* 577 */         buffer.append(annotations[i]);
/* 578 */         buffer.append(' ');
/*     */       } 
/* 580 */       buffer
/* 581 */         .append(TypeConstants.WILDCARD_CAPTURE_NAME_PREFIX)
/* 582 */         .append(this.captureID)
/* 583 */         .append(TypeConstants.WILDCARD_CAPTURE_NAME_SUFFIX)
/* 584 */         .append(this.wildcard);
/* 585 */       return buffer.toString();
/*     */     } 
/* 587 */     return super.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public char[] signature() {
/* 593 */     if (this.signature != null) {
/* 594 */       return this.signature;
/*     */     }
/* 596 */     if (this.firstBound instanceof ArrayBinding) {
/* 597 */       this.signature = constantPoolName();
/*     */     } else {
/* 599 */       this.signature = CharOperation.concat('L', constantPoolName(), ';');
/*     */     } 
/* 601 */     return this.signature;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\lookup\CaptureBinding.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */