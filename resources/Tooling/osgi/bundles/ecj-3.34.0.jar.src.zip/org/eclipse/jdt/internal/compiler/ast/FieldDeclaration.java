/*     */ package org.eclipse.jdt.internal.compiler.ast;
/*     */ 
/*     */ import java.util.List;
/*     */ import org.eclipse.jdt.internal.compiler.ASTVisitor;
/*     */ import org.eclipse.jdt.internal.compiler.codegen.AnnotationContext;
/*     */ import org.eclipse.jdt.internal.compiler.codegen.CodeStream;
/*     */ import org.eclipse.jdt.internal.compiler.flow.FlowContext;
/*     */ import org.eclipse.jdt.internal.compiler.flow.FlowInfo;
/*     */ import org.eclipse.jdt.internal.compiler.flow.UnconditionalFlowInfo;
/*     */ import org.eclipse.jdt.internal.compiler.impl.CompilerOptions;
/*     */ import org.eclipse.jdt.internal.compiler.impl.Constant;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.BlockScope;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.ClassScope;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.FieldBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.MethodScope;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.Scope;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.SourceTypeBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.VariableBinding;
/*     */ import org.eclipse.jdt.internal.compiler.problem.ProblemReporter;
/*     */ import org.eclipse.jdt.internal.compiler.util.Util;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FieldDeclaration
/*     */   extends AbstractVariableDeclaration
/*     */ {
/*     */   public FieldBinding binding;
/*     */   public Javadoc javadoc;
/*     */   public int endPart1Position;
/*     */   public int endPart2Position;
/*     */   public boolean isARecordComponent;
/*     */   
/*     */   public FieldDeclaration() {}
/*     */   
/*     */   public FieldDeclaration(char[] name, int sourceStart, int sourceEnd) {
/*  64 */     this.name = name;
/*     */ 
/*     */ 
/*     */     
/*  68 */     this.sourceStart = sourceStart;
/*  69 */     this.sourceEnd = sourceEnd;
/*     */   }
/*     */   public FlowInfo analyseCode(MethodScope initializationScope, FlowContext flowContext, FlowInfo flowInfo) {
/*     */     UnconditionalFlowInfo unconditionalFlowInfo;
/*  73 */     if (this.binding != null && !this.binding.isUsed() && this.binding.isOrEnclosedByPrivateType() && 
/*  74 */       !(initializationScope.referenceCompilationUnit()).compilationResult.hasSyntaxError && 
/*  75 */       !this.isARecordComponent) {
/*  76 */       initializationScope.problemReporter().unusedPrivateField(this);
/*     */     }
/*     */ 
/*     */     
/*  80 */     if (this.binding != null && 
/*  81 */       this.binding.isValidBinding() && 
/*  82 */       this.binding.isStatic() && 
/*  83 */       this.binding.constant((Scope)initializationScope) == Constant.NotAConstant && 
/*  84 */       this.binding.declaringClass.isNestedType() && 
/*  85 */       !this.binding.declaringClass.isStatic() && 
/*  86 */       (initializationScope.compilerOptions()).sourceLevel < 3932160L) {
/*  87 */       initializationScope.problemReporter().unexpectedStaticModifierForField(
/*  88 */           (SourceTypeBinding)this.binding.declaringClass, 
/*  89 */           this);
/*     */     }
/*     */ 
/*     */     
/*  93 */     if (this.initialization != null) {
/*  94 */       unconditionalFlowInfo = 
/*  95 */         this.initialization
/*  96 */         .analyseCode((BlockScope)initializationScope, flowContext, flowInfo)
/*  97 */         .unconditionalInits();
/*  98 */       unconditionalFlowInfo.markAsDefinitelyAssigned(this.binding);
/*     */     } 
/* 100 */     if (this.initialization != null && this.binding != null) {
/* 101 */       CompilerOptions options = initializationScope.compilerOptions();
/* 102 */       if (options.isAnnotationBasedNullAnalysisEnabled && (
/* 103 */         this.binding.isNonNull() || options.sourceLevel >= 3407872L)) {
/* 104 */         int nullStatus = this.initialization.nullStatus((FlowInfo)unconditionalFlowInfo, flowContext);
/* 105 */         NullAnnotationMatching.checkAssignment((BlockScope)initializationScope, flowContext, (VariableBinding)this.binding, (FlowInfo)unconditionalFlowInfo, nullStatus, this.initialization, this.initialization.resolvedType);
/*     */       } 
/*     */       
/* 108 */       this.initialization.checkNPEbyUnboxing((BlockScope)initializationScope, flowContext, (FlowInfo)unconditionalFlowInfo);
/*     */     } 
/* 110 */     return (FlowInfo)unconditionalFlowInfo;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void generateCode(BlockScope currentScope, CodeStream codeStream) {
/* 122 */     if ((this.bits & Integer.MIN_VALUE) == 0) {
/*     */       return;
/*     */     }
/*     */ 
/*     */     
/* 127 */     int pc = codeStream.position;
/*     */     boolean isStatic;
/* 129 */     if (this.initialization != null && (
/* 130 */       !(isStatic = this.binding.isStatic()) || this.binding.constant() == Constant.NotAConstant)) {
/*     */       
/* 132 */       if (!isStatic) {
/* 133 */         codeStream.aload_0();
/*     */       }
/* 135 */       this.initialization.generateCode(currentScope, codeStream, true);
/*     */       
/* 137 */       if (isStatic) {
/* 138 */         codeStream.fieldAccess((byte)-77, this.binding, null);
/*     */       } else {
/* 140 */         codeStream.fieldAccess((byte)-75, this.binding, null);
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 156 */     codeStream.recordPositionsFrom(pc, this.sourceStart);
/*     */   }
/*     */   public void getAllAnnotationContexts(int targetType, List<AnnotationContext> allAnnotationContexts) {
/* 159 */     TypeReference.AnnotationCollector collector = new TypeReference.AnnotationCollector(this.type, targetType, allAnnotationContexts);
/* 160 */     for (int i = 0, max = this.annotations.length; i < max; i++) {
/* 161 */       Annotation annotation = this.annotations[i];
/* 162 */       annotation.traverse(collector, (BlockScope)null);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getKind() {
/* 170 */     return (this.type == null) ? 3 : 1;
/*     */   }
/*     */   
/*     */   public boolean isStatic() {
/* 174 */     if (this.binding != null)
/* 175 */       return this.binding.isStatic(); 
/* 176 */     return ((this.modifiers & 0x8) != 0);
/*     */   }
/*     */   
/*     */   public boolean isFinal() {
/* 180 */     if (this.binding != null)
/* 181 */       return this.binding.isFinal(); 
/* 182 */     return ((this.modifiers & 0x10) != 0);
/*     */   }
/*     */   
/*     */   public StringBuffer print(int indent, StringBuffer output) {
/* 186 */     if (this.isARecordComponent)
/* 187 */       output.append("/* Implicit */"); 
/* 188 */     return super.print(indent, output);
/*     */   }
/*     */ 
/*     */   
/*     */   public StringBuffer printStatement(int indent, StringBuffer output) {
/* 193 */     if (this.javadoc != null) {
/* 194 */       this.javadoc.print(indent, output);
/*     */     }
/* 196 */     return super.printStatement(indent, output);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void resolve(MethodScope initializationScope) {
/*     */     // Byte code:
/*     */     //   0: aload_0
/*     */     //   1: getfield bits : I
/*     */     //   4: bipush #16
/*     */     //   6: iand
/*     */     //   7: ifeq -> 11
/*     */     //   10: return
/*     */     //   11: aload_0
/*     */     //   12: getfield binding : Lorg/eclipse/jdt/internal/compiler/lookup/FieldBinding;
/*     */     //   15: ifnull -> 28
/*     */     //   18: aload_0
/*     */     //   19: getfield binding : Lorg/eclipse/jdt/internal/compiler/lookup/FieldBinding;
/*     */     //   22: invokevirtual isValidBinding : ()Z
/*     */     //   25: ifne -> 29
/*     */     //   28: return
/*     */     //   29: aload_0
/*     */     //   30: dup
/*     */     //   31: getfield bits : I
/*     */     //   34: bipush #16
/*     */     //   36: ior
/*     */     //   37: putfield bits : I
/*     */     //   40: aload_1
/*     */     //   41: invokevirtual enclosingClassScope : ()Lorg/eclipse/jdt/internal/compiler/lookup/ClassScope;
/*     */     //   44: astore_2
/*     */     //   45: aload_2
/*     */     //   46: ifnull -> 263
/*     */     //   49: aload_2
/*     */     //   50: invokevirtual enclosingSourceType : ()Lorg/eclipse/jdt/internal/compiler/lookup/SourceTypeBinding;
/*     */     //   53: astore_3
/*     */     //   54: aload_3
/*     */     //   55: getfield superclass : Lorg/eclipse/jdt/internal/compiler/lookup/ReferenceBinding;
/*     */     //   58: ifnonnull -> 64
/*     */     //   61: goto -> 142
/*     */     //   64: aload_2
/*     */     //   65: aload_3
/*     */     //   66: getfield superclass : Lorg/eclipse/jdt/internal/compiler/lookup/ReferenceBinding;
/*     */     //   69: aload_0
/*     */     //   70: getfield name : [C
/*     */     //   73: aload_0
/*     */     //   74: iconst_0
/*     */     //   75: iconst_1
/*     */     //   76: invokevirtual findField : (Lorg/eclipse/jdt/internal/compiler/lookup/TypeBinding;[CLorg/eclipse/jdt/internal/compiler/lookup/InvocationSite;ZZ)Lorg/eclipse/jdt/internal/compiler/lookup/FieldBinding;
/*     */     //   79: astore #4
/*     */     //   81: aload #4
/*     */     //   83: ifnonnull -> 89
/*     */     //   86: goto -> 142
/*     */     //   89: aload #4
/*     */     //   91: invokevirtual isValidBinding : ()Z
/*     */     //   94: ifne -> 100
/*     */     //   97: goto -> 142
/*     */     //   100: aload #4
/*     */     //   102: invokevirtual original : ()Lorg/eclipse/jdt/internal/compiler/lookup/FieldBinding;
/*     */     //   105: aload_0
/*     */     //   106: getfield binding : Lorg/eclipse/jdt/internal/compiler/lookup/FieldBinding;
/*     */     //   109: if_acmpne -> 115
/*     */     //   112: goto -> 142
/*     */     //   115: aload #4
/*     */     //   117: aload_3
/*     */     //   118: aload_0
/*     */     //   119: aload_1
/*     */     //   120: invokevirtual canBeSeenBy : (Lorg/eclipse/jdt/internal/compiler/lookup/TypeBinding;Lorg/eclipse/jdt/internal/compiler/lookup/InvocationSite;Lorg/eclipse/jdt/internal/compiler/lookup/Scope;)Z
/*     */     //   123: ifne -> 129
/*     */     //   126: goto -> 142
/*     */     //   129: aload_1
/*     */     //   130: invokevirtual problemReporter : ()Lorg/eclipse/jdt/internal/compiler/problem/ProblemReporter;
/*     */     //   133: aload_0
/*     */     //   134: aload #4
/*     */     //   136: invokevirtual fieldHiding : (Lorg/eclipse/jdt/internal/compiler/ast/FieldDeclaration;Lorg/eclipse/jdt/internal/compiler/lookup/Binding;)V
/*     */     //   139: goto -> 263
/*     */     //   142: aload_2
/*     */     //   143: getfield parent : Lorg/eclipse/jdt/internal/compiler/lookup/Scope;
/*     */     //   146: astore #4
/*     */     //   148: aload #4
/*     */     //   150: getfield kind : I
/*     */     //   153: iconst_4
/*     */     //   154: if_icmpne -> 160
/*     */     //   157: goto -> 263
/*     */     //   160: aload #4
/*     */     //   162: aload_0
/*     */     //   163: getfield name : [C
/*     */     //   166: iconst_3
/*     */     //   167: aload_0
/*     */     //   168: iconst_0
/*     */     //   169: invokevirtual getBinding : ([CILorg/eclipse/jdt/internal/compiler/lookup/InvocationSite;Z)Lorg/eclipse/jdt/internal/compiler/lookup/Binding;
/*     */     //   172: astore #5
/*     */     //   174: aload #5
/*     */     //   176: ifnonnull -> 182
/*     */     //   179: goto -> 263
/*     */     //   182: aload #5
/*     */     //   184: invokevirtual isValidBinding : ()Z
/*     */     //   187: ifne -> 193
/*     */     //   190: goto -> 263
/*     */     //   193: aload #5
/*     */     //   195: aload_0
/*     */     //   196: getfield binding : Lorg/eclipse/jdt/internal/compiler/lookup/FieldBinding;
/*     */     //   199: if_acmpne -> 205
/*     */     //   202: goto -> 263
/*     */     //   205: aload #5
/*     */     //   207: instanceof org/eclipse/jdt/internal/compiler/lookup/FieldBinding
/*     */     //   210: ifeq -> 253
/*     */     //   213: aload #5
/*     */     //   215: checkcast org/eclipse/jdt/internal/compiler/lookup/FieldBinding
/*     */     //   218: astore #6
/*     */     //   220: aload #6
/*     */     //   222: invokevirtual original : ()Lorg/eclipse/jdt/internal/compiler/lookup/FieldBinding;
/*     */     //   225: aload_0
/*     */     //   226: getfield binding : Lorg/eclipse/jdt/internal/compiler/lookup/FieldBinding;
/*     */     //   229: if_acmpne -> 235
/*     */     //   232: goto -> 263
/*     */     //   235: aload #6
/*     */     //   237: invokevirtual isStatic : ()Z
/*     */     //   240: ifne -> 253
/*     */     //   243: aload_3
/*     */     //   244: invokevirtual isStatic : ()Z
/*     */     //   247: ifeq -> 253
/*     */     //   250: goto -> 263
/*     */     //   253: aload_1
/*     */     //   254: invokevirtual problemReporter : ()Lorg/eclipse/jdt/internal/compiler/problem/ProblemReporter;
/*     */     //   257: aload_0
/*     */     //   258: aload #5
/*     */     //   260: invokevirtual fieldHiding : (Lorg/eclipse/jdt/internal/compiler/ast/FieldDeclaration;Lorg/eclipse/jdt/internal/compiler/lookup/Binding;)V
/*     */     //   263: aload_0
/*     */     //   264: getfield type : Lorg/eclipse/jdt/internal/compiler/ast/TypeReference;
/*     */     //   267: ifnull -> 284
/*     */     //   270: aload_0
/*     */     //   271: getfield type : Lorg/eclipse/jdt/internal/compiler/ast/TypeReference;
/*     */     //   274: aload_0
/*     */     //   275: getfield binding : Lorg/eclipse/jdt/internal/compiler/lookup/FieldBinding;
/*     */     //   278: getfield type : Lorg/eclipse/jdt/internal/compiler/lookup/TypeBinding;
/*     */     //   281: putfield resolvedType : Lorg/eclipse/jdt/internal/compiler/lookup/TypeBinding;
/*     */     //   284: aload_1
/*     */     //   285: getfield initializedField : Lorg/eclipse/jdt/internal/compiler/lookup/FieldBinding;
/*     */     //   288: astore_3
/*     */     //   289: aload_1
/*     */     //   290: getfield lastVisibleFieldID : I
/*     */     //   293: istore #4
/*     */     //   295: aload_1
/*     */     //   296: aload_0
/*     */     //   297: getfield binding : Lorg/eclipse/jdt/internal/compiler/lookup/FieldBinding;
/*     */     //   300: putfield initializedField : Lorg/eclipse/jdt/internal/compiler/lookup/FieldBinding;
/*     */     //   303: aload_1
/*     */     //   304: aload_0
/*     */     //   305: getfield binding : Lorg/eclipse/jdt/internal/compiler/lookup/FieldBinding;
/*     */     //   308: getfield id : I
/*     */     //   311: putfield lastVisibleFieldID : I
/*     */     //   314: aload_1
/*     */     //   315: aload_0
/*     */     //   316: getfield annotations : [Lorg/eclipse/jdt/internal/compiler/ast/Annotation;
/*     */     //   319: aload_0
/*     */     //   320: getfield binding : Lorg/eclipse/jdt/internal/compiler/lookup/FieldBinding;
/*     */     //   323: invokestatic resolveAnnotations : (Lorg/eclipse/jdt/internal/compiler/lookup/BlockScope;[Lorg/eclipse/jdt/internal/compiler/ast/Annotation;Lorg/eclipse/jdt/internal/compiler/lookup/Binding;)V
/*     */     //   326: aload_0
/*     */     //   327: getfield annotations : [Lorg/eclipse/jdt/internal/compiler/ast/Annotation;
/*     */     //   330: ifnull -> 402
/*     */     //   333: iconst_0
/*     */     //   334: istore #5
/*     */     //   336: aload_0
/*     */     //   337: getfield annotations : [Lorg/eclipse/jdt/internal/compiler/ast/Annotation;
/*     */     //   340: arraylength
/*     */     //   341: istore #6
/*     */     //   343: goto -> 395
/*     */     //   346: aload_0
/*     */     //   347: getfield annotations : [Lorg/eclipse/jdt/internal/compiler/ast/Annotation;
/*     */     //   350: iload #5
/*     */     //   352: aaload
/*     */     //   353: getfield resolvedType : Lorg/eclipse/jdt/internal/compiler/lookup/TypeBinding;
/*     */     //   356: astore #7
/*     */     //   358: aload #7
/*     */     //   360: ifnull -> 392
/*     */     //   363: aload #7
/*     */     //   365: invokevirtual getAnnotationTagBits : ()J
/*     */     //   368: ldc2_w 9007199254740992
/*     */     //   371: land
/*     */     //   372: lconst_0
/*     */     //   373: lcmp
/*     */     //   374: ifeq -> 392
/*     */     //   377: aload_0
/*     */     //   378: dup
/*     */     //   379: getfield bits : I
/*     */     //   382: ldc_w 1048576
/*     */     //   385: ior
/*     */     //   386: putfield bits : I
/*     */     //   389: goto -> 402
/*     */     //   392: iinc #5, 1
/*     */     //   395: iload #5
/*     */     //   397: iload #6
/*     */     //   399: if_icmplt -> 346
/*     */     //   402: aload_0
/*     */     //   403: getfield binding : Lorg/eclipse/jdt/internal/compiler/lookup/FieldBinding;
/*     */     //   406: invokevirtual getAnnotationTagBits : ()J
/*     */     //   409: ldc2_w 70368744177664
/*     */     //   412: land
/*     */     //   413: lconst_0
/*     */     //   414: lcmp
/*     */     //   415: ifne -> 454
/*     */     //   418: aload_0
/*     */     //   419: getfield binding : Lorg/eclipse/jdt/internal/compiler/lookup/FieldBinding;
/*     */     //   422: getfield modifiers : I
/*     */     //   425: ldc_w 1048576
/*     */     //   428: iand
/*     */     //   429: ifeq -> 454
/*     */     //   432: aload_1
/*     */     //   433: invokevirtual compilerOptions : ()Lorg/eclipse/jdt/internal/compiler/impl/CompilerOptions;
/*     */     //   436: getfield sourceLevel : J
/*     */     //   439: ldc2_w 3211264
/*     */     //   442: lcmp
/*     */     //   443: iflt -> 454
/*     */     //   446: aload_1
/*     */     //   447: invokevirtual problemReporter : ()Lorg/eclipse/jdt/internal/compiler/problem/ProblemReporter;
/*     */     //   450: aload_0
/*     */     //   451: invokevirtual missingDeprecatedAnnotationForField : (Lorg/eclipse/jdt/internal/compiler/ast/FieldDeclaration;)V
/*     */     //   454: aload_0
/*     */     //   455: getfield initialization : Lorg/eclipse/jdt/internal/compiler/ast/Expression;
/*     */     //   458: ifnonnull -> 474
/*     */     //   461: aload_0
/*     */     //   462: getfield binding : Lorg/eclipse/jdt/internal/compiler/lookup/FieldBinding;
/*     */     //   465: getstatic org/eclipse/jdt/internal/compiler/impl/Constant.NotAConstant : Lorg/eclipse/jdt/internal/compiler/impl/Constant;
/*     */     //   468: invokevirtual setConstant : (Lorg/eclipse/jdt/internal/compiler/impl/Constant;)V
/*     */     //   471: goto -> 938
/*     */     //   474: aload_0
/*     */     //   475: getfield binding : Lorg/eclipse/jdt/internal/compiler/lookup/FieldBinding;
/*     */     //   478: getstatic org/eclipse/jdt/internal/compiler/impl/Constant.NotAConstant : Lorg/eclipse/jdt/internal/compiler/impl/Constant;
/*     */     //   481: invokevirtual setConstant : (Lorg/eclipse/jdt/internal/compiler/impl/Constant;)V
/*     */     //   484: aload_0
/*     */     //   485: getfield binding : Lorg/eclipse/jdt/internal/compiler/lookup/FieldBinding;
/*     */     //   488: getfield type : Lorg/eclipse/jdt/internal/compiler/lookup/TypeBinding;
/*     */     //   491: astore #5
/*     */     //   493: aload_0
/*     */     //   494: getfield initialization : Lorg/eclipse/jdt/internal/compiler/ast/Expression;
/*     */     //   497: getstatic org/eclipse/jdt/internal/compiler/ast/ExpressionContext.ASSIGNMENT_CONTEXT : Lorg/eclipse/jdt/internal/compiler/ast/ExpressionContext;
/*     */     //   500: invokevirtual setExpressionContext : (Lorg/eclipse/jdt/internal/compiler/ast/ExpressionContext;)V
/*     */     //   503: aload_0
/*     */     //   504: getfield initialization : Lorg/eclipse/jdt/internal/compiler/ast/Expression;
/*     */     //   507: aload #5
/*     */     //   509: invokevirtual setExpectedType : (Lorg/eclipse/jdt/internal/compiler/lookup/TypeBinding;)V
/*     */     //   512: aload_0
/*     */     //   513: getfield initialization : Lorg/eclipse/jdt/internal/compiler/ast/Expression;
/*     */     //   516: instanceof org/eclipse/jdt/internal/compiler/ast/ArrayInitializer
/*     */     //   519: ifeq -> 568
/*     */     //   522: aload_0
/*     */     //   523: getfield initialization : Lorg/eclipse/jdt/internal/compiler/ast/Expression;
/*     */     //   526: aload_1
/*     */     //   527: aload #5
/*     */     //   529: invokevirtual resolveTypeExpecting : (Lorg/eclipse/jdt/internal/compiler/lookup/BlockScope;Lorg/eclipse/jdt/internal/compiler/lookup/TypeBinding;)Lorg/eclipse/jdt/internal/compiler/lookup/TypeBinding;
/*     */     //   532: dup
/*     */     //   533: astore #6
/*     */     //   535: ifnull -> 872
/*     */     //   538: aload_0
/*     */     //   539: getfield initialization : Lorg/eclipse/jdt/internal/compiler/ast/Expression;
/*     */     //   542: checkcast org/eclipse/jdt/internal/compiler/ast/ArrayInitializer
/*     */     //   545: aload #6
/*     */     //   547: checkcast org/eclipse/jdt/internal/compiler/lookup/ArrayBinding
/*     */     //   550: putfield binding : Lorg/eclipse/jdt/internal/compiler/lookup/ArrayBinding;
/*     */     //   553: aload_0
/*     */     //   554: getfield initialization : Lorg/eclipse/jdt/internal/compiler/ast/Expression;
/*     */     //   557: aload_1
/*     */     //   558: aload #5
/*     */     //   560: aload #6
/*     */     //   562: invokevirtual computeConversion : (Lorg/eclipse/jdt/internal/compiler/lookup/Scope;Lorg/eclipse/jdt/internal/compiler/lookup/TypeBinding;Lorg/eclipse/jdt/internal/compiler/lookup/TypeBinding;)V
/*     */     //   565: goto -> 872
/*     */     //   568: aload_0
/*     */     //   569: getfield initialization : Lorg/eclipse/jdt/internal/compiler/ast/Expression;
/*     */     //   572: aload_1
/*     */     //   573: invokevirtual resolveType : (Lorg/eclipse/jdt/internal/compiler/lookup/BlockScope;)Lorg/eclipse/jdt/internal/compiler/lookup/TypeBinding;
/*     */     //   576: dup
/*     */     //   577: astore #6
/*     */     //   579: ifnull -> 862
/*     */     //   582: aload #5
/*     */     //   584: aload #6
/*     */     //   586: invokestatic notEquals : (Lorg/eclipse/jdt/internal/compiler/lookup/TypeBinding;Lorg/eclipse/jdt/internal/compiler/lookup/TypeBinding;)Z
/*     */     //   589: ifeq -> 603
/*     */     //   592: aload_1
/*     */     //   593: invokevirtual compilationUnitScope : ()Lorg/eclipse/jdt/internal/compiler/lookup/CompilationUnitScope;
/*     */     //   596: aload #5
/*     */     //   598: aload #6
/*     */     //   600: invokevirtual recordTypeConversion : (Lorg/eclipse/jdt/internal/compiler/lookup/TypeBinding;Lorg/eclipse/jdt/internal/compiler/lookup/TypeBinding;)V
/*     */     //   603: aload_0
/*     */     //   604: getfield initialization : Lorg/eclipse/jdt/internal/compiler/ast/Expression;
/*     */     //   607: aload #6
/*     */     //   609: aload #5
/*     */     //   611: invokevirtual isConstantValueOfTypeAssignableToType : (Lorg/eclipse/jdt/internal/compiler/lookup/TypeBinding;Lorg/eclipse/jdt/internal/compiler/lookup/TypeBinding;)Z
/*     */     //   614: ifne -> 628
/*     */     //   617: aload #6
/*     */     //   619: aload #5
/*     */     //   621: aload_2
/*     */     //   622: invokevirtual isCompatibleWith : (Lorg/eclipse/jdt/internal/compiler/lookup/TypeBinding;Lorg/eclipse/jdt/internal/compiler/lookup/Scope;)Z
/*     */     //   625: ifeq -> 705
/*     */     //   628: aload_0
/*     */     //   629: getfield initialization : Lorg/eclipse/jdt/internal/compiler/ast/Expression;
/*     */     //   632: aload_1
/*     */     //   633: aload #5
/*     */     //   635: aload #6
/*     */     //   637: invokevirtual computeConversion : (Lorg/eclipse/jdt/internal/compiler/lookup/Scope;Lorg/eclipse/jdt/internal/compiler/lookup/TypeBinding;Lorg/eclipse/jdt/internal/compiler/lookup/TypeBinding;)V
/*     */     //   640: aload #6
/*     */     //   642: aload #5
/*     */     //   644: invokevirtual needsUncheckedConversion : (Lorg/eclipse/jdt/internal/compiler/lookup/TypeBinding;)Z
/*     */     //   647: ifeq -> 665
/*     */     //   650: aload_1
/*     */     //   651: invokevirtual problemReporter : ()Lorg/eclipse/jdt/internal/compiler/problem/ProblemReporter;
/*     */     //   654: aload_0
/*     */     //   655: getfield initialization : Lorg/eclipse/jdt/internal/compiler/ast/Expression;
/*     */     //   658: aload #6
/*     */     //   660: aload #5
/*     */     //   662: invokevirtual unsafeTypeConversion : (Lorg/eclipse/jdt/internal/compiler/ast/Expression;Lorg/eclipse/jdt/internal/compiler/lookup/TypeBinding;Lorg/eclipse/jdt/internal/compiler/lookup/TypeBinding;)V
/*     */     //   665: aload_0
/*     */     //   666: getfield initialization : Lorg/eclipse/jdt/internal/compiler/ast/Expression;
/*     */     //   669: instanceof org/eclipse/jdt/internal/compiler/ast/CastExpression
/*     */     //   672: ifeq -> 809
/*     */     //   675: aload_0
/*     */     //   676: getfield initialization : Lorg/eclipse/jdt/internal/compiler/ast/Expression;
/*     */     //   679: getfield bits : I
/*     */     //   682: sipush #16384
/*     */     //   685: iand
/*     */     //   686: ifne -> 809
/*     */     //   689: aload_1
/*     */     //   690: aload #5
/*     */     //   692: aload_0
/*     */     //   693: getfield initialization : Lorg/eclipse/jdt/internal/compiler/ast/Expression;
/*     */     //   696: checkcast org/eclipse/jdt/internal/compiler/ast/CastExpression
/*     */     //   699: invokestatic checkNeedForAssignedCast : (Lorg/eclipse/jdt/internal/compiler/lookup/BlockScope;Lorg/eclipse/jdt/internal/compiler/lookup/TypeBinding;Lorg/eclipse/jdt/internal/compiler/ast/CastExpression;)V
/*     */     //   702: goto -> 809
/*     */     //   705: aload_0
/*     */     //   706: aload #6
/*     */     //   708: aload #5
/*     */     //   710: aload_0
/*     */     //   711: getfield initialization : Lorg/eclipse/jdt/internal/compiler/ast/Expression;
/*     */     //   714: aload_1
/*     */     //   715: invokevirtual isBoxingCompatible : (Lorg/eclipse/jdt/internal/compiler/lookup/TypeBinding;Lorg/eclipse/jdt/internal/compiler/lookup/TypeBinding;Lorg/eclipse/jdt/internal/compiler/ast/Expression;Lorg/eclipse/jdt/internal/compiler/lookup/Scope;)Z
/*     */     //   718: ifeq -> 773
/*     */     //   721: aload_0
/*     */     //   722: getfield initialization : Lorg/eclipse/jdt/internal/compiler/ast/Expression;
/*     */     //   725: aload_1
/*     */     //   726: aload #5
/*     */     //   728: aload #6
/*     */     //   730: invokevirtual computeConversion : (Lorg/eclipse/jdt/internal/compiler/lookup/Scope;Lorg/eclipse/jdt/internal/compiler/lookup/TypeBinding;Lorg/eclipse/jdt/internal/compiler/lookup/TypeBinding;)V
/*     */     //   733: aload_0
/*     */     //   734: getfield initialization : Lorg/eclipse/jdt/internal/compiler/ast/Expression;
/*     */     //   737: instanceof org/eclipse/jdt/internal/compiler/ast/CastExpression
/*     */     //   740: ifeq -> 809
/*     */     //   743: aload_0
/*     */     //   744: getfield initialization : Lorg/eclipse/jdt/internal/compiler/ast/Expression;
/*     */     //   747: getfield bits : I
/*     */     //   750: sipush #16384
/*     */     //   753: iand
/*     */     //   754: ifne -> 809
/*     */     //   757: aload_1
/*     */     //   758: aload #5
/*     */     //   760: aload_0
/*     */     //   761: getfield initialization : Lorg/eclipse/jdt/internal/compiler/ast/Expression;
/*     */     //   764: checkcast org/eclipse/jdt/internal/compiler/ast/CastExpression
/*     */     //   767: invokestatic checkNeedForAssignedCast : (Lorg/eclipse/jdt/internal/compiler/lookup/BlockScope;Lorg/eclipse/jdt/internal/compiler/lookup/TypeBinding;Lorg/eclipse/jdt/internal/compiler/ast/CastExpression;)V
/*     */     //   770: goto -> 809
/*     */     //   773: aload #5
/*     */     //   775: getfield tagBits : J
/*     */     //   778: aload #6
/*     */     //   780: getfield tagBits : J
/*     */     //   783: lor
/*     */     //   784: ldc2_w 128
/*     */     //   787: land
/*     */     //   788: lconst_0
/*     */     //   789: lcmp
/*     */     //   790: ifne -> 809
/*     */     //   793: aload_1
/*     */     //   794: invokevirtual problemReporter : ()Lorg/eclipse/jdt/internal/compiler/problem/ProblemReporter;
/*     */     //   797: aload #6
/*     */     //   799: aload #5
/*     */     //   801: aload_0
/*     */     //   802: getfield initialization : Lorg/eclipse/jdt/internal/compiler/ast/Expression;
/*     */     //   805: aconst_null
/*     */     //   806: invokevirtual typeMismatchError : (Lorg/eclipse/jdt/internal/compiler/lookup/TypeBinding;Lorg/eclipse/jdt/internal/compiler/lookup/TypeBinding;Lorg/eclipse/jdt/internal/compiler/ast/ASTNode;Lorg/eclipse/jdt/internal/compiler/ast/ASTNode;)V
/*     */     //   809: aload_0
/*     */     //   810: getfield binding : Lorg/eclipse/jdt/internal/compiler/lookup/FieldBinding;
/*     */     //   813: invokevirtual isFinal : ()Z
/*     */     //   816: ifeq -> 872
/*     */     //   819: aload_0
/*     */     //   820: getfield binding : Lorg/eclipse/jdt/internal/compiler/lookup/FieldBinding;
/*     */     //   823: aload_0
/*     */     //   824: getfield initialization : Lorg/eclipse/jdt/internal/compiler/ast/Expression;
/*     */     //   827: getfield constant : Lorg/eclipse/jdt/internal/compiler/impl/Constant;
/*     */     //   830: aload_0
/*     */     //   831: getfield binding : Lorg/eclipse/jdt/internal/compiler/lookup/FieldBinding;
/*     */     //   834: getfield type : Lorg/eclipse/jdt/internal/compiler/lookup/TypeBinding;
/*     */     //   837: getfield id : I
/*     */     //   840: iconst_4
/*     */     //   841: ishl
/*     */     //   842: aload_0
/*     */     //   843: getfield initialization : Lorg/eclipse/jdt/internal/compiler/ast/Expression;
/*     */     //   846: getfield constant : Lorg/eclipse/jdt/internal/compiler/impl/Constant;
/*     */     //   849: invokevirtual typeID : ()I
/*     */     //   852: iadd
/*     */     //   853: invokevirtual castTo : (I)Lorg/eclipse/jdt/internal/compiler/impl/Constant;
/*     */     //   856: invokevirtual setConstant : (Lorg/eclipse/jdt/internal/compiler/impl/Constant;)V
/*     */     //   859: goto -> 872
/*     */     //   862: aload_0
/*     */     //   863: getfield binding : Lorg/eclipse/jdt/internal/compiler/lookup/FieldBinding;
/*     */     //   866: getstatic org/eclipse/jdt/internal/compiler/impl/Constant.NotAConstant : Lorg/eclipse/jdt/internal/compiler/impl/Constant;
/*     */     //   869: invokevirtual setConstant : (Lorg/eclipse/jdt/internal/compiler/impl/Constant;)V
/*     */     //   872: aload_0
/*     */     //   873: getfield binding : Lorg/eclipse/jdt/internal/compiler/lookup/FieldBinding;
/*     */     //   876: aload_0
/*     */     //   877: getfield initialization : Lorg/eclipse/jdt/internal/compiler/ast/Expression;
/*     */     //   880: invokestatic getDirectBinding : (Lorg/eclipse/jdt/internal/compiler/ast/Expression;)Lorg/eclipse/jdt/internal/compiler/lookup/Binding;
/*     */     //   883: if_acmpne -> 938
/*     */     //   886: aload_1
/*     */     //   887: invokevirtual problemReporter : ()Lorg/eclipse/jdt/internal/compiler/problem/ProblemReporter;
/*     */     //   890: aload_0
/*     */     //   891: aload_0
/*     */     //   892: getfield name : [C
/*     */     //   895: invokevirtual assignmentHasNoEffect : (Lorg/eclipse/jdt/internal/compiler/ast/AbstractVariableDeclaration;[C)V
/*     */     //   898: goto -> 938
/*     */     //   901: astore #8
/*     */     //   903: aload_1
/*     */     //   904: aload_3
/*     */     //   905: putfield initializedField : Lorg/eclipse/jdt/internal/compiler/lookup/FieldBinding;
/*     */     //   908: aload_1
/*     */     //   909: iload #4
/*     */     //   911: putfield lastVisibleFieldID : I
/*     */     //   914: aload_0
/*     */     //   915: getfield binding : Lorg/eclipse/jdt/internal/compiler/lookup/FieldBinding;
/*     */     //   918: aload_1
/*     */     //   919: invokevirtual constant : (Lorg/eclipse/jdt/internal/compiler/lookup/Scope;)Lorg/eclipse/jdt/internal/compiler/impl/Constant;
/*     */     //   922: ifnonnull -> 935
/*     */     //   925: aload_0
/*     */     //   926: getfield binding : Lorg/eclipse/jdt/internal/compiler/lookup/FieldBinding;
/*     */     //   929: getstatic org/eclipse/jdt/internal/compiler/impl/Constant.NotAConstant : Lorg/eclipse/jdt/internal/compiler/impl/Constant;
/*     */     //   932: invokevirtual setConstant : (Lorg/eclipse/jdt/internal/compiler/impl/Constant;)V
/*     */     //   935: aload #8
/*     */     //   937: athrow
/*     */     //   938: aload_1
/*     */     //   939: aload_3
/*     */     //   940: putfield initializedField : Lorg/eclipse/jdt/internal/compiler/lookup/FieldBinding;
/*     */     //   943: aload_1
/*     */     //   944: iload #4
/*     */     //   946: putfield lastVisibleFieldID : I
/*     */     //   949: aload_0
/*     */     //   950: getfield binding : Lorg/eclipse/jdt/internal/compiler/lookup/FieldBinding;
/*     */     //   953: aload_1
/*     */     //   954: invokevirtual constant : (Lorg/eclipse/jdt/internal/compiler/lookup/Scope;)Lorg/eclipse/jdt/internal/compiler/impl/Constant;
/*     */     //   957: ifnonnull -> 970
/*     */     //   960: aload_0
/*     */     //   961: getfield binding : Lorg/eclipse/jdt/internal/compiler/lookup/FieldBinding;
/*     */     //   964: getstatic org/eclipse/jdt/internal/compiler/impl/Constant.NotAConstant : Lorg/eclipse/jdt/internal/compiler/impl/Constant;
/*     */     //   967: invokevirtual setConstant : (Lorg/eclipse/jdt/internal/compiler/impl/Constant;)V
/*     */     //   970: return
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #205	-> 0
/*     */     //   #206	-> 11
/*     */     //   #208	-> 29
/*     */     //   #212	-> 40
/*     */     //   #214	-> 45
/*     */     //   #216	-> 49
/*     */     //   #218	-> 54
/*     */     //   #222	-> 64
/*     */     //   #223	-> 81
/*     */     //   #224	-> 89
/*     */     //   #225	-> 100
/*     */     //   #226	-> 115
/*     */     //   #228	-> 129
/*     */     //   #229	-> 139
/*     */     //   #233	-> 142
/*     */     //   #234	-> 148
/*     */     //   #235	-> 160
/*     */     //   #236	-> 174
/*     */     //   #237	-> 182
/*     */     //   #238	-> 193
/*     */     //   #239	-> 205
/*     */     //   #240	-> 213
/*     */     //   #241	-> 220
/*     */     //   #242	-> 235
/*     */     //   #245	-> 253
/*     */     //   #249	-> 263
/*     */     //   #250	-> 270
/*     */     //   #253	-> 284
/*     */     //   #254	-> 289
/*     */     //   #256	-> 295
/*     */     //   #257	-> 303
/*     */     //   #259	-> 314
/*     */     //   #261	-> 326
/*     */     //   #262	-> 333
/*     */     //   #263	-> 346
/*     */     //   #264	-> 358
/*     */     //   #265	-> 377
/*     */     //   #266	-> 389
/*     */     //   #262	-> 392
/*     */     //   #272	-> 402
/*     */     //   #273	-> 418
/*     */     //   #274	-> 432
/*     */     //   #275	-> 446
/*     */     //   #278	-> 454
/*     */     //   #279	-> 461
/*     */     //   #280	-> 471
/*     */     //   #282	-> 474
/*     */     //   #284	-> 484
/*     */     //   #286	-> 493
/*     */     //   #287	-> 503
/*     */     //   #288	-> 512
/*     */     //   #290	-> 522
/*     */     //   #291	-> 538
/*     */     //   #292	-> 553
/*     */     //   #294	-> 565
/*     */     //   #296	-> 582
/*     */     //   #297	-> 592
/*     */     //   #298	-> 603
/*     */     //   #299	-> 617
/*     */     //   #300	-> 628
/*     */     //   #301	-> 640
/*     */     //   #302	-> 650
/*     */     //   #304	-> 665
/*     */     //   #305	-> 675
/*     */     //   #306	-> 689
/*     */     //   #308	-> 702
/*     */     //   #309	-> 721
/*     */     //   #310	-> 733
/*     */     //   #311	-> 743
/*     */     //   #312	-> 757
/*     */     //   #314	-> 770
/*     */     //   #315	-> 773
/*     */     //   #317	-> 793
/*     */     //   #320	-> 809
/*     */     //   #321	-> 819
/*     */     //   #323	-> 859
/*     */     //   #324	-> 862
/*     */     //   #327	-> 872
/*     */     //   #328	-> 886
/*     */     //   #331	-> 898
/*     */     //   #332	-> 903
/*     */     //   #333	-> 908
/*     */     //   #334	-> 914
/*     */     //   #335	-> 925
/*     */     //   #336	-> 935
/*     */     //   #332	-> 938
/*     */     //   #333	-> 943
/*     */     //   #334	-> 949
/*     */     //   #335	-> 960
/*     */     //   #337	-> 970
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	descriptor
/*     */     //   0	971	0	this	Lorg/eclipse/jdt/internal/compiler/ast/FieldDeclaration;
/*     */     //   0	971	1	initializationScope	Lorg/eclipse/jdt/internal/compiler/lookup/MethodScope;
/*     */     //   45	926	2	classScope	Lorg/eclipse/jdt/internal/compiler/lookup/ClassScope;
/*     */     //   54	209	3	declaringType	Lorg/eclipse/jdt/internal/compiler/lookup/SourceTypeBinding;
/*     */     //   81	61	4	existingVariable	Lorg/eclipse/jdt/internal/compiler/lookup/FieldBinding;
/*     */     //   148	115	4	outerScope	Lorg/eclipse/jdt/internal/compiler/lookup/Scope;
/*     */     //   174	89	5	existingVariable	Lorg/eclipse/jdt/internal/compiler/lookup/Binding;
/*     */     //   220	33	6	existingField	Lorg/eclipse/jdt/internal/compiler/lookup/FieldBinding;
/*     */     //   289	682	3	previousField	Lorg/eclipse/jdt/internal/compiler/lookup/FieldBinding;
/*     */     //   295	676	4	previousFieldID	I
/*     */     //   336	66	5	i	I
/*     */     //   343	59	6	max	I
/*     */     //   358	34	7	resolvedAnnotationType	Lorg/eclipse/jdt/internal/compiler/lookup/TypeBinding;
/*     */     //   493	405	5	fieldType	Lorg/eclipse/jdt/internal/compiler/lookup/TypeBinding;
/*     */     //   535	33	6	initializationType	Lorg/eclipse/jdt/internal/compiler/lookup/TypeBinding;
/*     */     //   579	319	6	initializationType	Lorg/eclipse/jdt/internal/compiler/lookup/TypeBinding;
/*     */     // Exception table:
/*     */     //   from	to	target	type
/*     */     //   295	901	901	finally
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void resolveJavadoc(MethodScope initializationScope) {
/* 339 */     if (this.javadoc != null) {
/* 340 */       FieldBinding previousField = initializationScope.initializedField;
/* 341 */       int previousFieldID = initializationScope.lastVisibleFieldID;
/*     */       try {
/* 343 */         initializationScope.initializedField = this.binding;
/* 344 */         if (this.binding != null)
/* 345 */           initializationScope.lastVisibleFieldID = this.binding.id; 
/* 346 */         this.javadoc.resolve(initializationScope);
/*     */       } finally {
/* 348 */         initializationScope.initializedField = previousField;
/* 349 */         initializationScope.lastVisibleFieldID = previousFieldID;
/*     */       } 
/* 351 */     } else if (this.binding != null && this.binding.declaringClass != null && !this.binding.declaringClass.isLocalType()) {
/*     */       
/* 353 */       int javadocVisibility = this.binding.modifiers & 0x7;
/* 354 */       ProblemReporter reporter = initializationScope.problemReporter();
/* 355 */       int severity = reporter.computeSeverity(-1610612250);
/* 356 */       if (severity != 256) {
/* 357 */         ClassScope classScope = initializationScope.enclosingClassScope();
/* 358 */         if (classScope != null) {
/* 359 */           javadocVisibility = Util.computeOuterMostVisibility(classScope.referenceType(), javadocVisibility);
/*     */         }
/* 361 */         int javadocModifiers = this.binding.modifiers & 0xFFFFFFF8 | javadocVisibility;
/* 362 */         reporter.javadocMissing(this.sourceStart, this.sourceEnd, severity, javadocModifiers);
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   public void traverse(ASTVisitor visitor, MethodScope scope) {
/* 368 */     if (visitor.visit(this, scope)) {
/* 369 */       if (this.javadoc != null) {
/* 370 */         this.javadoc.traverse(visitor, (BlockScope)scope);
/*     */       }
/* 372 */       if (this.annotations != null) {
/* 373 */         int annotationsLength = this.annotations.length;
/* 374 */         for (int i = 0; i < annotationsLength; i++)
/* 375 */           this.annotations[i].traverse(visitor, (BlockScope)scope); 
/*     */       } 
/* 377 */       if (this.type != null) {
/* 378 */         this.type.traverse(visitor, (BlockScope)scope);
/*     */       }
/* 380 */       if (this.initialization != null)
/* 381 */         this.initialization.traverse(visitor, (BlockScope)scope); 
/*     */     } 
/* 383 */     visitor.endVisit(this, scope);
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\ast\FieldDeclaration.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */