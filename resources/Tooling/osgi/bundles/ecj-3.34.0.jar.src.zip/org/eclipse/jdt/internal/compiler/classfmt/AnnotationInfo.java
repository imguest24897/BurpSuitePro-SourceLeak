/*     */ package org.eclipse.jdt.internal.compiler.classfmt;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import org.eclipse.jdt.core.compiler.CharOperation;
/*     */ import org.eclipse.jdt.internal.compiler.ast.Annotation;
/*     */ import org.eclipse.jdt.internal.compiler.codegen.ConstantPool;
/*     */ import org.eclipse.jdt.internal.compiler.env.ClassSignature;
/*     */ import org.eclipse.jdt.internal.compiler.env.EnumConstantSignature;
/*     */ import org.eclipse.jdt.internal.compiler.env.IBinaryAnnotation;
/*     */ import org.eclipse.jdt.internal.compiler.env.IBinaryElementValuePair;
/*     */ import org.eclipse.jdt.internal.compiler.impl.BooleanConstant;
/*     */ import org.eclipse.jdt.internal.compiler.impl.ByteConstant;
/*     */ import org.eclipse.jdt.internal.compiler.impl.CharConstant;
/*     */ import org.eclipse.jdt.internal.compiler.impl.DoubleConstant;
/*     */ import org.eclipse.jdt.internal.compiler.impl.FloatConstant;
/*     */ import org.eclipse.jdt.internal.compiler.impl.IntConstant;
/*     */ import org.eclipse.jdt.internal.compiler.impl.LongConstant;
/*     */ import org.eclipse.jdt.internal.compiler.impl.ShortConstant;
/*     */ import org.eclipse.jdt.internal.compiler.impl.StringConstant;
/*     */ import org.eclipse.jdt.internal.compiler.util.Util;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AnnotationInfo
/*     */   extends ClassFileStruct
/*     */   implements IBinaryAnnotation
/*     */ {
/*     */   private char[] typename;
/*     */   private volatile ElementValuePairInfo[] pairs;
/*  36 */   long standardAnnotationTagBits = 0L;
/*  37 */   int readOffset = 0;
/*     */   
/*  39 */   static Object[] EmptyValueArray = new Object[0];
/*     */   
/*     */   public RuntimeException exceptionDuringDecode;
/*     */   
/*     */   AnnotationInfo(byte[] classFileBytes, int[] contantPoolOffsets, int offset) {
/*  44 */     super(classFileBytes, contantPoolOffsets, offset);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   AnnotationInfo(byte[] classFileBytes, int[] contantPoolOffsets, int offset, boolean runtimeVisible, boolean populate) {
/*  52 */     this(classFileBytes, contantPoolOffsets, offset);
/*  53 */     if (populate) {
/*  54 */       decodeAnnotation();
/*     */     } else {
/*  56 */       this.readOffset = scanAnnotation(0, runtimeVisible, true);
/*     */     } 
/*     */   } private void decodeAnnotation() {
/*  59 */     this.readOffset = 0;
/*  60 */     int utf8Offset = this.constantPoolOffsets[u2At(0)] - this.structOffset;
/*  61 */     this.typename = utf8At(utf8Offset + 3, u2At(utf8Offset + 1));
/*  62 */     int numberOfPairs = u2At(2);
/*     */     
/*  64 */     this.readOffset += 4;
/*  65 */     ElementValuePairInfo[] decodedPairs = (numberOfPairs == 0) ? ElementValuePairInfo.NoMembers : new ElementValuePairInfo[numberOfPairs];
/*  66 */     int i = 0;
/*     */     try {
/*  68 */       while (i < numberOfPairs) {
/*     */         
/*  70 */         utf8Offset = this.constantPoolOffsets[u2At(this.readOffset)] - this.structOffset;
/*  71 */         char[] membername = utf8At(utf8Offset + 3, u2At(utf8Offset + 1));
/*  72 */         this.readOffset += 2;
/*  73 */         Object value = decodeDefaultValue();
/*  74 */         decodedPairs[i++] = new ElementValuePairInfo(membername, value);
/*     */       } 
/*  76 */       this.pairs = decodedPairs;
/*  77 */     } catch (RuntimeException any) {
/*  78 */       sanitizePairs(decodedPairs);
/*  79 */       StringBuilder newMessage = new StringBuilder(any.getMessage());
/*  80 */       newMessage.append(" while decoding pair #").append(i).append(" of annotation @").append(this.typename);
/*  81 */       newMessage.append(", bytes at structOffset ").append(this.structOffset).append(":");
/*  82 */       int offset = this.structOffset;
/*  83 */       while (offset <= this.structOffset + this.readOffset && offset < this.reference.length) {
/*  84 */         newMessage.append(' ').append(Integer.toHexString(this.reference[offset++] & 0xFF));
/*     */       }
/*  86 */       throw new IllegalStateException(newMessage.toString(), any);
/*     */     } 
/*     */   }
/*     */   
/*  90 */   private void sanitizePairs(ElementValuePairInfo[] oldPairs) { if (oldPairs != null) {
/*  91 */       ElementValuePairInfo[] newPairs = new ElementValuePairInfo[oldPairs.length];
/*  92 */       int count = 0;
/*  93 */       for (int i = 0; i < oldPairs.length; i++) {
/*  94 */         ElementValuePairInfo evpInfo = oldPairs[i];
/*  95 */         if (evpInfo != null)
/*  96 */           newPairs[count++] = evpInfo; 
/*     */       } 
/*  98 */       if (count < oldPairs.length) {
/*  99 */         this.pairs = Arrays.<ElementValuePairInfo>copyOf(newPairs, count);
/*     */       } else {
/* 101 */         this.pairs = newPairs;
/*     */       } 
/*     */     } else {
/* 104 */       this.pairs = ElementValuePairInfo.NoMembers;
/*     */     }  }
/*     */   Object decodeDefaultValue() { char[] typeName, constName, className;
/*     */     int numberOfValues;
/* 108 */     Object value = null;
/*     */     
/* 110 */     int tag = u1At(this.readOffset);
/* 111 */     this.readOffset++;
/* 112 */     int constValueOffset = -1;
/* 113 */     switch (tag) {
/*     */       case 90:
/* 115 */         constValueOffset = this.constantPoolOffsets[u2At(this.readOffset)] - this.structOffset;
/* 116 */         value = BooleanConstant.fromValue((i4At(constValueOffset + 1) == 1));
/* 117 */         this.readOffset += 2;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 194 */         return value;case 73: constValueOffset = this.constantPoolOffsets[u2At(this.readOffset)] - this.structOffset; value = IntConstant.fromValue(i4At(constValueOffset + 1)); this.readOffset += 2; return value;case 67: constValueOffset = this.constantPoolOffsets[u2At(this.readOffset)] - this.structOffset; value = CharConstant.fromValue((char)i4At(constValueOffset + 1)); this.readOffset += 2; return value;case 66: constValueOffset = this.constantPoolOffsets[u2At(this.readOffset)] - this.structOffset; value = ByteConstant.fromValue((byte)i4At(constValueOffset + 1)); this.readOffset += 2; return value;case 83: constValueOffset = this.constantPoolOffsets[u2At(this.readOffset)] - this.structOffset; value = ShortConstant.fromValue((short)i4At(constValueOffset + 1)); this.readOffset += 2; return value;case 68: constValueOffset = this.constantPoolOffsets[u2At(this.readOffset)] - this.structOffset; value = DoubleConstant.fromValue(doubleAt(constValueOffset + 1)); this.readOffset += 2; return value;case 70: constValueOffset = this.constantPoolOffsets[u2At(this.readOffset)] - this.structOffset; value = FloatConstant.fromValue(floatAt(constValueOffset + 1)); this.readOffset += 2; return value;case 74: constValueOffset = this.constantPoolOffsets[u2At(this.readOffset)] - this.structOffset; value = LongConstant.fromValue(i8At(constValueOffset + 1)); this.readOffset += 2; return value;case 115: constValueOffset = this.constantPoolOffsets[u2At(this.readOffset)] - this.structOffset; value = StringConstant.fromValue(String.valueOf(utf8At(constValueOffset + 3, u2At(constValueOffset + 1)))); this.readOffset += 2; return value;case 101: constValueOffset = this.constantPoolOffsets[u2At(this.readOffset)] - this.structOffset; typeName = utf8At(constValueOffset + 3, u2At(constValueOffset + 1)); this.readOffset += 2; constValueOffset = this.constantPoolOffsets[u2At(this.readOffset)] - this.structOffset; constName = utf8At(constValueOffset + 3, u2At(constValueOffset + 1)); this.readOffset += 2; value = new EnumConstantSignature(typeName, constName); return value;case 99: constValueOffset = this.constantPoolOffsets[u2At(this.readOffset)] - this.structOffset; className = utf8At(constValueOffset + 3, u2At(constValueOffset + 1)); value = new ClassSignature(className); this.readOffset += 2; return value;case 64: value = new AnnotationInfo(this.reference, this.constantPoolOffsets, this.readOffset + this.structOffset, false, true); this.readOffset += ((AnnotationInfo)value).readOffset; return value;case 91: numberOfValues = u2At(this.readOffset); this.readOffset += 2; if (numberOfValues == 0) { value = EmptyValueArray; } else { Object[] arrayElements = new Object[numberOfValues]; value = arrayElements; for (int i = 0; i < numberOfValues; i++) arrayElements[i] = decodeDefaultValue();  }  return value;
/*     */     } 
/*     */     String tagDisplay = (tag == 0) ? "0x00" : (String.valueOf((char)tag) + " (" + Integer.toHexString(tag & 0xFF) + ')');
/*     */     throw new IllegalStateException("Unrecognized tag " + tagDisplay); } public IBinaryElementValuePair[] getElementValuePairs() {
/* 198 */     if (this.pairs == null)
/* 199 */       lazyInitialize(); 
/* 200 */     return (IBinaryElementValuePair[])this.pairs;
/*     */   }
/*     */   
/*     */   public char[] getTypeName() {
/* 204 */     return this.typename;
/*     */   }
/*     */   
/*     */   public boolean isDeprecatedAnnotation() {
/* 208 */     return ((this.standardAnnotationTagBits & 0x4000400000000000L) != 0L);
/*     */   }
/*     */   void initialize() {
/* 211 */     if (this.pairs == null)
/* 212 */       decodeAnnotation(); 
/*     */   }
/*     */   
/* 215 */   synchronized void lazyInitialize() { if (this.pairs == null)
/* 216 */       decodeAnnotation();  }
/*     */   private int readRetentionPolicy(int offset) { int utf8Offset;
/*     */     char[] typeName;
/* 219 */     int numberOfValues, i, currentOffset = offset;
/* 220 */     int tag = u1At(currentOffset);
/* 221 */     currentOffset++;
/* 222 */     switch (tag) {
/*     */       case 101:
/* 224 */         utf8Offset = this.constantPoolOffsets[u2At(currentOffset)] - this.structOffset;
/* 225 */         typeName = utf8At(utf8Offset + 3, u2At(utf8Offset + 1));
/* 226 */         currentOffset += 2;
/* 227 */         if (typeName.length == 38 && CharOperation.equals(typeName, ConstantPool.JAVA_LANG_ANNOTATION_RETENTIONPOLICY)) {
/* 228 */           utf8Offset = this.constantPoolOffsets[u2At(currentOffset)] - this.structOffset;
/* 229 */           char[] constName = utf8At(utf8Offset + 3, u2At(utf8Offset + 1));
/* 230 */           this.standardAnnotationTagBits |= Annotation.getRetentionPolicy(constName);
/*     */         } 
/* 232 */         currentOffset += 2;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 260 */         return currentOffset;case 66: case 67: case 68: case 70: case 73: case 74: case 83: case 90: case 99: case 115: currentOffset += 2; return currentOffset;case 64: currentOffset = scanAnnotation(currentOffset, false, false); return currentOffset;case 91: numberOfValues = u2At(currentOffset); currentOffset += 2; for (i = 0; i < numberOfValues; i++) currentOffset = scanElementValue(currentOffset);  return currentOffset;
/*     */     }  throw new IllegalStateException(); } private int readTargetValue(int offset) { int utf8Offset;
/*     */     char[] typeName;
/* 263 */     int numberOfValues, currentOffset = offset;
/* 264 */     int tag = u1At(currentOffset);
/* 265 */     currentOffset++;
/* 266 */     switch (tag) {
/*     */       case 101:
/* 268 */         utf8Offset = this.constantPoolOffsets[u2At(currentOffset)] - this.structOffset;
/* 269 */         typeName = utf8At(utf8Offset + 3, u2At(utf8Offset + 1));
/* 270 */         currentOffset += 2;
/* 271 */         if (typeName.length == 34 && CharOperation.equals(typeName, ConstantPool.JAVA_LANG_ANNOTATION_ELEMENTTYPE)) {
/* 272 */           utf8Offset = this.constantPoolOffsets[u2At(currentOffset)] - this.structOffset;
/* 273 */           char[] constName = utf8At(utf8Offset + 3, u2At(utf8Offset + 1));
/* 274 */           this.standardAnnotationTagBits |= Annotation.getTargetElementType(constName);
/*     */         } 
/* 276 */         currentOffset += 2;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 308 */         return currentOffset;case 66: case 67: case 68: case 70: case 73: case 74: case 83: case 90: case 99: case 115: currentOffset += 2; return currentOffset;case 64: currentOffset = scanAnnotation(currentOffset, false, false); return currentOffset;case 91: numberOfValues = u2At(currentOffset); currentOffset += 2; if (numberOfValues == 0) { this.standardAnnotationTagBits |= 0x800000000L; } else { for (int i = 0; i < numberOfValues; i++) currentOffset = readTargetValue(currentOffset);  }  return currentOffset;
/*     */     } 
/*     */     throw new IllegalStateException(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int scanAnnotation(int offset, boolean expectRuntimeVisibleAnno, boolean toplevel) {
/* 327 */     int currentOffset = offset;
/* 328 */     int utf8Offset = this.constantPoolOffsets[u2At(offset)] - this.structOffset;
/* 329 */     char[] typeName = utf8At(utf8Offset + 3, u2At(utf8Offset + 1));
/* 330 */     if (toplevel)
/* 331 */       this.typename = typeName; 
/* 332 */     int numberOfPairs = u2At(offset + 2);
/*     */     
/* 334 */     currentOffset += 4;
/* 335 */     if (expectRuntimeVisibleAnno && toplevel) {
/* 336 */       switch (typeName.length) {
/*     */         case 22:
/* 338 */           if (CharOperation.equals(typeName, ConstantPool.JAVA_LANG_DEPRECATED)) {
/* 339 */             this.standardAnnotationTagBits |= 0x400000000000L;
/*     */           }
/*     */           break;
/*     */         case 23:
/* 343 */           if (CharOperation.equals(typeName, ConstantPool.JAVA_LANG_SAFEVARARGS)) {
/* 344 */             this.standardAnnotationTagBits |= 0x8000000000000L;
/* 345 */             return currentOffset;
/*     */           } 
/*     */           break;
/*     */         case 29:
/* 349 */           if (CharOperation.equals(typeName, ConstantPool.JAVA_LANG_ANNOTATION_TARGET)) {
/* 350 */             currentOffset += 2;
/* 351 */             return readTargetValue(currentOffset);
/*     */           } 
/*     */           break;
/*     */         case 32:
/* 355 */           if (CharOperation.equals(typeName, ConstantPool.JAVA_LANG_ANNOTATION_RETENTION)) {
/* 356 */             currentOffset += 2;
/* 357 */             return readRetentionPolicy(currentOffset);
/*     */           } 
/* 359 */           if (CharOperation.equals(typeName, ConstantPool.JAVA_LANG_ANNOTATION_INHERITED)) {
/* 360 */             this.standardAnnotationTagBits |= 0x1000000000000L;
/* 361 */             return currentOffset;
/*     */           } 
/*     */           break;
/*     */         case 33:
/* 365 */           if (CharOperation.equals(typeName, ConstantPool.JAVA_LANG_ANNOTATION_DOCUMENTED)) {
/* 366 */             this.standardAnnotationTagBits |= 0x800000000000L;
/* 367 */             return currentOffset;
/*     */           } 
/*     */           break;
/*     */         case 52:
/* 371 */           if (CharOperation.equals(typeName, ConstantPool.JAVA_LANG_INVOKE_METHODHANDLE_POLYMORPHICSIGNATURE)) {
/* 372 */             this.standardAnnotationTagBits |= 0x10000000000000L;
/* 373 */             return currentOffset;
/*     */           } 
/*     */           break;
/*     */       } 
/*     */     }
/* 378 */     for (int i = 0; i < numberOfPairs; i++) {
/*     */       
/* 380 */       currentOffset += 2;
/* 381 */       currentOffset = scanElementValue(currentOffset);
/*     */     } 
/* 383 */     return currentOffset;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int scanElementValue(int offset) {
/* 391 */     int numberOfValues, i, currentOffset = offset;
/* 392 */     int tag = u1At(currentOffset);
/* 393 */     currentOffset++;
/* 394 */     switch (tag) {
/*     */       case 90:
/* 396 */         if ((this.standardAnnotationTagBits & 0x400000000000L) != 0L) {
/*     */           
/* 398 */           int constantOffset = this.constantPoolOffsets[u2At(currentOffset)] - this.structOffset + 1;
/* 399 */           if (i4At(constantOffset) == 1) {
/* 400 */             this.standardAnnotationTagBits |= 0x4000000000000000L;
/*     */           }
/*     */         } 
/* 403 */         currentOffset += 2;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 433 */         return currentOffset;case 66: case 67: case 68: case 70: case 73: case 74: case 83: case 99: case 115: currentOffset += 2; return currentOffset;case 101: currentOffset += 4; return currentOffset;case 64: currentOffset = scanAnnotation(currentOffset, false, false); return currentOffset;case 91: numberOfValues = u2At(currentOffset); currentOffset += 2; for (i = 0; i < numberOfValues; i++) currentOffset = scanElementValue(currentOffset);  return currentOffset;
/*     */     } 
/*     */     throw new IllegalStateException();
/*     */   } public String toString() {
/* 437 */     return BinaryTypeFormatter.annotationToString(this);
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 442 */     int result = 1;
/* 443 */     result = 31 * result + Util.hashCode((Object[])this.pairs);
/* 444 */     result = 31 * result + CharOperation.hashCode(this.typename);
/* 445 */     return result;
/*     */   }
/*     */   
/*     */   public boolean equals(Object obj) {
/* 449 */     if (this == obj) {
/* 450 */       return true;
/*     */     }
/* 452 */     if (obj == null) {
/* 453 */       return false;
/*     */     }
/* 455 */     if (getClass() != obj.getClass()) {
/* 456 */       return false;
/*     */     }
/* 458 */     AnnotationInfo other = (AnnotationInfo)obj;
/* 459 */     if (!Arrays.equals((Object[])this.pairs, (Object[])other.pairs)) {
/* 460 */       return false;
/*     */     }
/* 462 */     if (!Arrays.equals(this.typename, other.typename)) {
/* 463 */       return false;
/*     */     }
/* 465 */     return true;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\classfmt\AnnotationInfo.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */