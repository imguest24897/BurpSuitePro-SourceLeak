/*     */ package org.eclipse.jdt.internal.compiler.batch;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import java.util.function.Function;
/*     */ import org.eclipse.jdt.core.compiler.CharOperation;
/*     */ import org.eclipse.jdt.internal.compiler.env.AccessRestriction;
/*     */ import org.eclipse.jdt.internal.compiler.env.AccessRuleSet;
/*     */ import org.eclipse.jdt.internal.compiler.env.IModule;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.ModuleBinding;
/*     */ import org.eclipse.jdt.internal.compiler.util.SuffixConstants;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class ClasspathLocation
/*     */   implements FileSystem.Classpath, SuffixConstants
/*     */ {
/*     */   public static final int SOURCE = 1;
/*     */   public static final int BINARY = 2;
/*     */   String path;
/*     */   char[] normalizedPath;
/*     */   public AccessRuleSet accessRuleSet;
/*     */   IModule module;
/*     */   public String destinationPath;
/*     */   
/*     */   protected ClasspathLocation(AccessRuleSet accessRuleSet, String destinationPath) {
/*  57 */     this.accessRuleSet = accessRuleSet;
/*  58 */     this.destinationPath = destinationPath;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected AccessRestriction fetchAccessRestriction(String qualifiedBinaryFileName) {
/*  74 */     if (this.accessRuleSet == null)
/*  75 */       return null; 
/*  76 */     char[] qualifiedTypeName = qualifiedBinaryFileName
/*  77 */       .substring(0, qualifiedBinaryFileName.length() - SUFFIX_CLASS.length)
/*  78 */       .toCharArray();
/*  79 */     if (File.separatorChar == '\\') {
/*  80 */       CharOperation.replace(qualifiedTypeName, File.separatorChar, '/');
/*     */     }
/*  82 */     return this.accessRuleSet.getViolatedRestriction(qualifiedTypeName);
/*     */   }
/*     */   
/*     */   public int getMode() {
/*  86 */     return 3;
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/*  91 */     int result = 1;
/*  92 */     result = 31 * result + getMode();
/*  93 */     result = 31 * result + ((this.path == null) ? 0 : this.path.hashCode());
/*  94 */     return result;
/*     */   }
/*     */   
/*     */   public boolean equals(Object obj) {
/*  98 */     if (this == obj)
/*  99 */       return true; 
/* 100 */     if (obj == null)
/* 101 */       return false; 
/* 102 */     if (getClass() != obj.getClass())
/* 103 */       return false; 
/* 104 */     ClasspathLocation other = (ClasspathLocation)obj;
/* 105 */     String localPath = getPath();
/* 106 */     String otherPath = other.getPath();
/* 107 */     if (localPath == null) {
/* 108 */       if (otherPath != null)
/* 109 */         return false; 
/* 110 */     } else if (!localPath.equals(otherPath)) {
/* 111 */       return false;
/* 112 */     }  if (getMode() != other.getMode())
/* 113 */       return false; 
/* 114 */     return true;
/*     */   }
/*     */   
/*     */   public String getPath() {
/* 118 */     return this.path;
/*     */   }
/*     */   
/*     */   public String getDestinationPath() {
/* 122 */     return this.destinationPath;
/*     */   }
/*     */ 
/*     */   
/*     */   public void acceptModule(IModule mod) {
/* 127 */     this.module = mod;
/*     */   }
/*     */   
/*     */   public boolean isAutomaticModule() {
/* 131 */     return (this.module == null) ? false : this.module.isAutomatic();
/*     */   }
/*     */   
/*     */   public Collection<String> getModuleNames(Collection<String> limitModules) {
/* 135 */     return getModuleNames(limitModules, m -> getModule(m.toCharArray()));
/*     */   }
/*     */   
/*     */   public Collection<String> getModuleNames(Collection<String> limitModules, Function<String, IModule> getModule) {
/* 139 */     if (this.module != null) {
/* 140 */       String name = String.valueOf(this.module.name());
/* 141 */       return selectModules(Collections.singleton(name), limitModules, getModule);
/*     */     } 
/* 143 */     return Collections.emptyList();
/*     */   }
/*     */   protected Collection<String> selectModules(Set<String> modules, Collection<String> limitModules, Function<String, IModule> getModule) {
/*     */     Collection<String> rootModules;
/* 147 */     if (limitModules != null) {
/* 148 */       Set<String> result = new HashSet<>(modules);
/* 149 */       result.retainAll(limitModules);
/* 150 */       rootModules = result;
/*     */     } else {
/* 152 */       rootModules = allModules(modules, s -> s, m -> getModule(m.toCharArray()));
/*     */     } 
/* 154 */     Set<String> allModules = new HashSet<>(rootModules);
/* 155 */     for (String mod : rootModules)
/* 156 */       addRequired(mod, allModules, getModule); 
/* 157 */     return allModules;
/*     */   }
/*     */   
/*     */   private void addRequired(String mod, Set<String> allModules, Function<String, IModule> getModule) {
/* 161 */     IModule iMod = getModule(mod.toCharArray());
/* 162 */     if (iMod != null) {
/* 163 */       byte b; int i; IModule.IModuleReference[] arrayOfIModuleReference; for (i = (arrayOfIModuleReference = iMod.requires()).length, b = 0; b < i; ) { IModule.IModuleReference requiredRef = arrayOfIModuleReference[b];
/* 164 */         IModule reqMod = getModule.apply(new String(requiredRef.name()));
/* 165 */         if (reqMod != null) {
/* 166 */           String reqModName = String.valueOf(reqMod.name());
/* 167 */           if (allModules.add(reqModName))
/* 168 */             addRequired(reqModName, allModules, getModule); 
/*     */         } 
/*     */         b++; }
/*     */     
/*     */     } 
/*     */   } protected <T> List<String> allModules(Iterable<T> allSystemModules, Function<T, String> getModuleName, Function<T, IModule> getModule) {
/* 174 */     List<String> result = new ArrayList<>();
/* 175 */     for (T mod : allSystemModules) {
/* 176 */       String moduleName = getModuleName.apply(mod);
/* 177 */       result.add(moduleName);
/*     */     } 
/* 179 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isPackage(String qualifiedPackageName, String moduleName) {
/* 184 */     return (getModulesDeclaringPackage(qualifiedPackageName, moduleName) != null);
/*     */   }
/*     */   
/*     */   protected char[][] singletonModuleNameIf(boolean condition) {
/* 188 */     if (!condition)
/* 189 */       return null; 
/* 190 */     if (this.module != null)
/* 191 */       return new char[][] { this.module.name() }; 
/* 192 */     return new char[][] { ModuleBinding.UNNAMED };
/*     */   }
/*     */ 
/*     */   
/*     */   public void reset() {
/* 197 */     this.module = null;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\batch\ClasspathLocation.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */