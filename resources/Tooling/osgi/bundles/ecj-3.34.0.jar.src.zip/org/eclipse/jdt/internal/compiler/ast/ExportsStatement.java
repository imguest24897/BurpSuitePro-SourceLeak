/*    */ package org.eclipse.jdt.internal.compiler.ast;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ExportsStatement
/*    */   extends PackageVisibilityStatement
/*    */ {
/*    */   public ExportsStatement(ImportReference pkgRef) {
/* 20 */     this(pkgRef, null);
/*    */   }
/*    */   public ExportsStatement(ImportReference pkgRef, ModuleReference[] targets) {
/* 23 */     super(pkgRef, targets);
/*    */   }
/*    */ 
/*    */   
/*    */   public StringBuffer print(int indent, StringBuffer output) {
/* 28 */     printIndent(indent, output);
/* 29 */     output.append("exports ");
/* 30 */     super.print(0, output);
/* 31 */     output.append(";");
/* 32 */     return output;
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\ast\ExportsStatement.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */