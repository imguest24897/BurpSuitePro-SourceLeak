/*    */ package org.eclipse.jdt.internal.compiler.lookup;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class MethodHolder
/*    */   extends AnnotationHolder
/*    */ {
/*    */   AnnotationBinding[][] parameterAnnotations;
/*    */   
/*    */   MethodHolder(AnnotationBinding[] annotations, AnnotationBinding[][] parameterAnnotations) {
/* 60 */     setAnnotations(annotations);
/* 61 */     this.parameterAnnotations = parameterAnnotations;
/*    */   }
/*    */   
/*    */   public AnnotationBinding[][] getParameterAnnotations() {
/* 65 */     return this.parameterAnnotations;
/*    */   }
/*    */   
/*    */   AnnotationBinding[] getParameterAnnotations(int paramIndex) {
/* 69 */     AnnotationBinding[] result = (this.parameterAnnotations == null) ? null : this.parameterAnnotations[paramIndex];
/* 70 */     return (result == null) ? Binding.NO_ANNOTATIONS : result;
/*    */   }
/*    */   
/*    */   AnnotationHolder setAnnotations(AnnotationBinding[] annotations) {
/* 74 */     this.annotations = (annotations == null || annotations.length == 0) ? Binding.NO_ANNOTATIONS : annotations;
/* 75 */     return this;
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\lookup\AnnotationHolder$MethodHolder.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */