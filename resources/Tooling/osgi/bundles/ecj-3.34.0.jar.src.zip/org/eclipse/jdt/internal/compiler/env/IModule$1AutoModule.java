/*     */ package org.eclipse.jdt.internal.compiler.env;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class AutoModule
/*     */   implements IModule
/*     */ {
/*     */   char[] name;
/*     */   boolean nameFromManifest;
/*     */   
/*     */   public AutoModule(char[] name, boolean nameFromManifest) {
/*  88 */     this.name = name;
/*  89 */     this.nameFromManifest = nameFromManifest;
/*     */   }
/*     */   
/*     */   public char[] name() {
/*  93 */     return this.name;
/*     */   }
/*     */ 
/*     */   
/*     */   public IModule.IModuleReference[] requires() {
/*  98 */     return IModule.NO_MODULE_REFS;
/*     */   }
/*     */ 
/*     */   
/*     */   public IModule.IPackageExport[] exports() {
/* 103 */     return IModule.NO_EXPORTS;
/*     */   }
/*     */ 
/*     */   
/*     */   public char[][] uses() {
/* 108 */     return IModule.NO_USES;
/*     */   }
/*     */ 
/*     */   
/*     */   public IModule.IService[] provides() {
/* 113 */     return IModule.NO_PROVIDES;
/*     */   }
/*     */ 
/*     */   
/*     */   public IModule.IPackageExport[] opens() {
/* 118 */     return NO_OPENS;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isAutomatic() {
/* 123 */     return true;
/*     */   }
/*     */   
/*     */   public boolean isAutoNameFromManifest() {
/* 127 */     return this.nameFromManifest;
/*     */   }
/*     */   
/*     */   public boolean isOpen() {
/* 131 */     return false;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\env\IModule$1AutoModule.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */