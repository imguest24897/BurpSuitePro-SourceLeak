/*    */ package org.eclipse.jdt.internal.compiler.apt.model;
/*    */ 
/*    */ import javax.lang.model.type.ArrayType;
/*    */ import javax.lang.model.type.TypeKind;
/*    */ import javax.lang.model.type.TypeMirror;
/*    */ import javax.lang.model.type.TypeVisitor;
/*    */ import org.eclipse.jdt.internal.compiler.apt.dispatch.BaseProcessingEnvImpl;
/*    */ import org.eclipse.jdt.internal.compiler.lookup.AnnotationBinding;
/*    */ import org.eclipse.jdt.internal.compiler.lookup.ArrayBinding;
/*    */ import org.eclipse.jdt.internal.compiler.lookup.Binding;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ArrayTypeImpl
/*    */   extends TypeMirrorImpl
/*    */   implements ArrayType
/*    */ {
/*    */   ArrayTypeImpl(BaseProcessingEnvImpl env, ArrayBinding binding) {
/* 35 */     super(env, (Binding)binding);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public TypeMirror getComponentType() {
/* 43 */     return this._env.getFactory().newTypeMirror((Binding)((ArrayBinding)this._binding).elementsType());
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public <R, P> R accept(TypeVisitor<R, P> v, P p) {
/* 51 */     return v.visitArray(this, p);
/*    */   }
/*    */ 
/*    */   
/*    */   protected AnnotationBinding[] getAnnotationBindings() {
/* 56 */     AnnotationBinding[] oldies = ((ArrayBinding)this._binding).getTypeAnnotations();
/* 57 */     AnnotationBinding[] newbies = Binding.NO_ANNOTATIONS;
/*    */     
/* 59 */     for (int i = 0, length = (oldies == null) ? 0 : oldies.length; i < length; i++) {
/* 60 */       if (oldies[i] == null) {
/* 61 */         System.arraycopy(oldies, 0, newbies = new AnnotationBinding[i], 0, i);
/* 62 */         return newbies;
/*    */       } 
/*    */     } 
/* 65 */     return newbies;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public TypeKind getKind() {
/* 73 */     return TypeKind.ARRAY;
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\apt\model\ArrayTypeImpl.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */