/*      */ package org.eclipse.jdt.internal.compiler.lookup;
/*      */ 
/*      */ import java.util.ArrayList;
/*      */ import java.util.List;
/*      */ import org.eclipse.jdt.core.compiler.CharOperation;
/*      */ import org.eclipse.jdt.internal.compiler.ast.ASTNode;
/*      */ import org.eclipse.jdt.internal.compiler.ast.AbstractMethodDeclaration;
/*      */ import org.eclipse.jdt.internal.compiler.ast.CaseStatement;
/*      */ import org.eclipse.jdt.internal.compiler.ast.FakedTrackingVariable;
/*      */ import org.eclipse.jdt.internal.compiler.ast.LambdaExpression;
/*      */ import org.eclipse.jdt.internal.compiler.ast.LocalDeclaration;
/*      */ import org.eclipse.jdt.internal.compiler.ast.ReturnStatement;
/*      */ import org.eclipse.jdt.internal.compiler.ast.Statement;
/*      */ import org.eclipse.jdt.internal.compiler.ast.TypeDeclaration;
/*      */ import org.eclipse.jdt.internal.compiler.codegen.CodeStream;
/*      */ import org.eclipse.jdt.internal.compiler.flow.FlowContext;
/*      */ import org.eclipse.jdt.internal.compiler.flow.FlowInfo;
/*      */ import org.eclipse.jdt.internal.compiler.impl.Constant;
/*      */ import org.eclipse.jdt.internal.compiler.problem.ProblemReporter;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class BlockScope
/*      */   extends Scope
/*      */ {
/*      */   public LocalVariableBinding[] locals;
/*      */   public int localIndex;
/*      */   public int startIndex;
/*      */   public int offset;
/*      */   public int maxOffset;
/*      */   public BlockScope[] shiftScopes;
/*   61 */   public Scope[] subscopes = new Scope[1];
/*   62 */   public int subscopeCount = 0;
/*      */   
/*      */   public CaseStatement enclosingCase;
/*      */   
/*   66 */   public static final VariableBinding[] EmulationPathToImplicitThis = new VariableBinding[0];
/*   67 */   public static final VariableBinding[] NoEnclosingInstanceInConstructorCall = new VariableBinding[0];
/*      */   
/*   69 */   public static final VariableBinding[] NoEnclosingInstanceInStaticContext = new VariableBinding[0];
/*      */   public boolean insideTypeAnnotation = false;
/*      */   public Statement blockStatement;
/*      */   private List trackingVariables;
/*      */   public FlowInfo finallyInfo;
/*      */   
/*      */   public BlockScope(BlockScope parent) {
/*   76 */     this(parent, true);
/*      */   }
/*      */   
/*      */   public BlockScope(BlockScope parent, boolean addToParentScope) {
/*   80 */     this(1, parent);
/*   81 */     this.locals = new LocalVariableBinding[5];
/*   82 */     if (addToParentScope) parent.addSubscope(this); 
/*   83 */     this.startIndex = parent.localIndex;
/*      */   }
/*      */   
/*      */   public BlockScope(BlockScope parent, int variableCount) {
/*   87 */     this(1, parent);
/*   88 */     this.locals = new LocalVariableBinding[variableCount];
/*   89 */     parent.addSubscope(this);
/*   90 */     this.startIndex = parent.localIndex;
/*      */   }
/*      */   
/*      */   protected BlockScope(int kind, Scope parent) {
/*   94 */     super(kind, parent);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public final void addAnonymousType(TypeDeclaration anonymousType, ReferenceBinding superBinding) {
/*  100 */     ClassScope anonymousClassScope = new ClassScope(this, anonymousType);
/*  101 */     anonymousClassScope.buildAnonymousTypeBinding(
/*  102 */         enclosingSourceType(), 
/*  103 */         superBinding);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  110 */     MethodScope methodScope = methodScope();
/*  111 */     while (methodScope != null && methodScope.referenceContext instanceof LambdaExpression) {
/*  112 */       LambdaExpression lambda = (LambdaExpression)methodScope.referenceContext;
/*  113 */       if (!lambda.scope.isStatic && !lambda.scope.isConstructorCall) {
/*  114 */         lambda.shouldCaptureInstance = true;
/*      */       }
/*  116 */       methodScope = methodScope.enclosingMethodScope();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public final void addLocalType(TypeDeclaration localType) {
/*  123 */     ClassScope localTypeScope = new ClassScope(this, localType);
/*  124 */     addSubscope(localTypeScope);
/*  125 */     localTypeScope.buildLocalTypeBinding(enclosingSourceType());
/*      */ 
/*      */     
/*  128 */     MethodScope methodScope = methodScope();
/*  129 */     while (methodScope != null && methodScope.referenceContext instanceof LambdaExpression) {
/*  130 */       LambdaExpression lambda = (LambdaExpression)methodScope.referenceContext;
/*  131 */       if (!lambda.scope.isStatic && !lambda.scope.isConstructorCall) {
/*  132 */         lambda.shouldCaptureInstance = true;
/*      */       }
/*  134 */       methodScope = methodScope.enclosingMethodScope();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public final void addLocalVariable(LocalVariableBinding binding) {
/*  141 */     checkAndSetModifiersForVariable(binding);
/*      */     
/*  143 */     if (this.localIndex == this.locals.length)
/*  144 */       System.arraycopy(
/*  145 */           this.locals, 
/*  146 */           0, 
/*  147 */           this.locals = new LocalVariableBinding[this.localIndex * 2], 
/*  148 */           0, 
/*  149 */           this.localIndex); 
/*  150 */     this.locals[this.localIndex++] = binding;
/*      */ 
/*      */     
/*  153 */     binding.declaringScope = this;
/*  154 */     binding.id = (outerMostMethodScope()).analysisIndex++;
/*      */   }
/*      */ 
/*      */   
/*      */   public void addSubscope(Scope childScope) {
/*  159 */     if (this.subscopeCount == this.subscopes.length)
/*  160 */       System.arraycopy(
/*  161 */           this.subscopes, 
/*  162 */           0, 
/*  163 */           this.subscopes = new Scope[this.subscopeCount * 2], 
/*  164 */           0, 
/*  165 */           this.subscopeCount); 
/*  166 */     this.subscopes[this.subscopeCount++] = childScope;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final boolean allowBlankFinalFieldAssignment(FieldBinding binding) {
/*  174 */     if (TypeBinding.notEquals(enclosingReceiverType(), binding.declaringClass)) {
/*  175 */       return false;
/*      */     }
/*  177 */     MethodScope methodScope = methodScope();
/*  178 */     if (methodScope.isStatic != binding.isStatic())
/*  179 */       return false; 
/*  180 */     if (methodScope.isLambdaScope())
/*  181 */       return false; 
/*  182 */     return !(!methodScope.isInsideInitializer() && 
/*  183 */       !((AbstractMethodDeclaration)methodScope.referenceContext).isInitializationMethod());
/*      */   }
/*      */   
/*      */   String basicToString(int tab) {
/*  187 */     String newLine = "\n";
/*  188 */     for (int i = tab; --i >= 0;) {
/*  189 */       newLine = String.valueOf(newLine) + "\t";
/*      */     }
/*  191 */     String s = String.valueOf(newLine) + "--- Block Scope ---";
/*  192 */     newLine = String.valueOf(newLine) + "\t";
/*  193 */     s = String.valueOf(s) + newLine + "locals:";
/*  194 */     for (int j = 0; j < this.localIndex; j++)
/*  195 */       s = String.valueOf(s) + newLine + "\t" + this.locals[j].toString(); 
/*  196 */     s = String.valueOf(s) + newLine + "startIndex = " + this.startIndex;
/*  197 */     return s;
/*      */   }
/*      */   
/*      */   private void checkAndSetModifiersForVariable(LocalVariableBinding varBinding) {
/*  201 */     int modifiers = varBinding.modifiers;
/*  202 */     if ((modifiers & 0x400000) != 0 && varBinding.declaration != null) {
/*  203 */       problemReporter().duplicateModifierForVariable(varBinding.declaration, this instanceof MethodScope);
/*      */     }
/*  205 */     int realModifiers = modifiers & 0xFFFF;
/*      */     
/*  207 */     int unexpectedModifiers = -17;
/*  208 */     if ((realModifiers & unexpectedModifiers) != 0 && varBinding.declaration != null) {
/*  209 */       problemReporter().illegalModifierForVariable(varBinding.declaration, this instanceof MethodScope);
/*      */     }
/*  211 */     varBinding.modifiers = modifiers;
/*      */   }
/*      */   
/*      */   public void adjustLocalVariablePositions(int delta, boolean offsetAlreadyUpdated) {
/*  215 */     this.offset += offsetAlreadyUpdated ? 0 : delta;
/*  216 */     if (this.offset > this.maxOffset)
/*  217 */       this.maxOffset = this.offset;  byte b; int i;
/*      */     Scope[] arrayOfScope;
/*  219 */     for (i = (arrayOfScope = this.subscopes).length, b = 0; b < i; ) { Scope subScope = arrayOfScope[b];
/*  220 */       if (subScope instanceof BlockScope) {
/*  221 */         ((BlockScope)subScope).adjustCurrentAndSubScopeLocalVariablePositions(delta);
/*      */       }
/*      */       b++; }
/*      */     
/*  225 */     Scope scope = this.parent;
/*  226 */     while (scope instanceof BlockScope) {
/*  227 */       BlockScope pBlock = (BlockScope)scope;
/*  228 */       int diff = this.maxOffset - pBlock.maxOffset;
/*  229 */       pBlock.maxOffset += (diff > 0) ? diff : 0;
/*  230 */       if (scope instanceof MethodScope)
/*      */         break; 
/*  232 */       scope = scope.parent;
/*      */     } 
/*      */   }
/*      */   public void adjustCurrentAndSubScopeLocalVariablePositions(int delta) {
/*  236 */     this.offset += delta;
/*  237 */     if (this.offset > this.maxOffset)
/*  238 */       this.maxOffset = this.offset;  byte b; int i;
/*      */     LocalVariableBinding[] arrayOfLocalVariableBinding;
/*  240 */     for (i = (arrayOfLocalVariableBinding = this.locals).length, b = 0; b < i; ) { LocalVariableBinding lvb = arrayOfLocalVariableBinding[b];
/*  241 */       if (lvb != null && lvb.resolvedPosition != -1)
/*  242 */         lvb.resolvedPosition += delta;  b++; }
/*      */      Scope[] arrayOfScope;
/*  244 */     for (i = (arrayOfScope = this.subscopes).length, b = 0; b < i; ) { Scope subScope = arrayOfScope[b];
/*  245 */       if (subScope instanceof BlockScope) {
/*  246 */         ((BlockScope)subScope).adjustCurrentAndSubScopeLocalVariablePositions(delta);
/*      */       }
/*      */       b++; }
/*      */   
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void computeLocalVariablePositions(int ilocal, int initOffset, CodeStream codeStream) {
/*  257 */     this.offset = initOffset;
/*  258 */     this.maxOffset = initOffset;
/*      */ 
/*      */     
/*  261 */     int maxLocals = this.localIndex;
/*  262 */     boolean hasMoreVariables = (ilocal < maxLocals);
/*      */ 
/*      */     
/*  265 */     int iscope = 0, maxScopes = this.subscopeCount;
/*  266 */     boolean hasMoreScopes = (maxScopes > 0);
/*      */ 
/*      */     
/*  269 */     while (hasMoreVariables || hasMoreScopes) {
/*  270 */       if (hasMoreScopes && (
/*  271 */         !hasMoreVariables || this.subscopes[iscope].startIndex() <= ilocal)) {
/*      */         
/*  273 */         if (this.subscopes[iscope] instanceof BlockScope) {
/*  274 */           BlockScope subscope = (BlockScope)this.subscopes[iscope];
/*  275 */           int subOffset = (subscope.shiftScopes == null) ? this.offset : subscope.maxShiftedOffset();
/*  276 */           subscope.computeLocalVariablePositions(0, subOffset, codeStream);
/*  277 */           if (subscope.maxOffset > this.maxOffset)
/*  278 */             this.maxOffset = subscope.maxOffset; 
/*      */         } 
/*  280 */         hasMoreScopes = (++iscope < maxScopes);
/*      */         
/*      */         continue;
/*      */       } 
/*  284 */       LocalVariableBinding local = this.locals[ilocal];
/*      */ 
/*      */       
/*  287 */       boolean generateCurrentLocalVar = (local.useFlag > 0 && local.constant() == Constant.NotAConstant);
/*      */ 
/*      */       
/*  290 */       if (local.useFlag == 0 && 
/*  291 */         local.declaration != null && (
/*  292 */         local.declaration.bits & 0x40000000) != 0)
/*      */       {
/*  294 */         if (local.isCatchParameter()) {
/*  295 */           problemReporter().unusedExceptionParameter(local.declaration);
/*      */         } else {
/*      */           
/*  298 */           problemReporter().unusedLocalVariable(local.declaration);
/*      */         } 
/*      */       }
/*      */ 
/*      */       
/*  303 */       if (!generateCurrentLocalVar && 
/*  304 */         local.declaration != null && (compilerOptions()).preserveAllLocalVariables) {
/*  305 */         generateCurrentLocalVar = true;
/*  306 */         if (local.useFlag == 0) {
/*  307 */           local.useFlag = 1;
/*      */         }
/*      */       } 
/*      */ 
/*      */       
/*  312 */       if (generateCurrentLocalVar) {
/*      */         
/*  314 */         if (local.declaration != null) {
/*  315 */           codeStream.record(local);
/*      */         }
/*      */         
/*  318 */         local.resolvedPosition = this.offset;
/*      */         
/*  320 */         if (TypeBinding.equalsEquals(local.type, TypeBinding.LONG) || TypeBinding.equalsEquals(local.type, TypeBinding.DOUBLE)) {
/*  321 */           this.offset += 2;
/*      */         } else {
/*  323 */           this.offset++;
/*      */         } 
/*  325 */         if (this.offset > 65535) {
/*  326 */           problemReporter().noMoreAvailableSpaceForLocal(
/*  327 */               local, 
/*  328 */               (local.declaration == null) ? (ASTNode)(methodScope()).referenceContext : (ASTNode)local.declaration);
/*      */         }
/*      */       } else {
/*  331 */         local.resolvedPosition = -1;
/*      */       } 
/*  333 */       hasMoreVariables = (++ilocal < maxLocals);
/*      */     } 
/*      */     
/*  336 */     if (this.offset > this.maxOffset) {
/*  337 */       this.maxOffset = this.offset;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void emulateOuterAccess(LocalVariableBinding outerLocalVariable) {
/*  348 */     BlockScope outerVariableScope = outerLocalVariable.declaringScope;
/*  349 */     if (outerVariableScope == null) {
/*      */       return;
/*      */     }
/*  352 */     int depth = 0;
/*  353 */     Scope scope = this;
/*  354 */     while (outerVariableScope != scope) {
/*  355 */       switch (scope.kind) {
/*      */         case 3:
/*  357 */           depth++;
/*      */           break;
/*      */         case 2:
/*  360 */           if (scope.isLambdaScope()) {
/*  361 */             LambdaExpression lambdaExpression = (LambdaExpression)scope.referenceContext();
/*  362 */             lambdaExpression.addSyntheticArgument(outerLocalVariable);
/*      */           } 
/*      */           break;
/*      */       } 
/*  366 */       scope = scope.parent;
/*      */     } 
/*  368 */     if (depth == 0) {
/*      */       return;
/*      */     }
/*  371 */     MethodScope currentMethodScope = methodScope();
/*  372 */     if (outerVariableScope.methodScope() != currentMethodScope) {
/*  373 */       NestedTypeBinding currentType = (NestedTypeBinding)enclosingSourceType();
/*      */ 
/*      */       
/*  376 */       if (!currentType.isLocalType()) {
/*      */         return;
/*      */       }
/*      */       
/*  380 */       if (!currentMethodScope.isInsideInitializerOrConstructor()) {
/*  381 */         currentType.addSyntheticArgumentAndField(outerLocalVariable);
/*      */       } else {
/*  383 */         currentType.addSyntheticArgument(outerLocalVariable);
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ReferenceBinding findLocalType(char[] name) {
/*  408 */     long compliance = (compilerOptions()).complianceLevel;
/*  409 */     for (int i = this.subscopeCount - 1; i >= 0; i--) {
/*  410 */       if (this.subscopes[i] instanceof ClassScope) {
/*  411 */         LocalTypeBinding sourceType = (LocalTypeBinding)((ClassScope)this.subscopes[i]).referenceContext.binding;
/*      */         
/*  413 */         if (compliance < 3145728L || sourceType.enclosingCase == null || 
/*  414 */           isInsideCase(sourceType.enclosingCase))
/*      */         {
/*      */ 
/*      */           
/*  418 */           if (CharOperation.equals(sourceType.sourceName(), name))
/*  419 */             return sourceType;  } 
/*      */       } 
/*      */     } 
/*  422 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public LocalDeclaration[] findLocalVariableDeclarations(int position) {
/*  432 */     int ilocal = 0, maxLocals = this.localIndex;
/*  433 */     boolean hasMoreVariables = (maxLocals > 0);
/*  434 */     LocalDeclaration[] localDeclarations = null;
/*  435 */     int declPtr = 0;
/*      */ 
/*      */     
/*  438 */     int iscope = 0, maxScopes = this.subscopeCount;
/*  439 */     boolean hasMoreScopes = (maxScopes > 0);
/*      */ 
/*      */     
/*  442 */     while (hasMoreVariables || hasMoreScopes) {
/*  443 */       if (hasMoreScopes && (
/*  444 */         !hasMoreVariables || this.subscopes[iscope].startIndex() <= ilocal)) {
/*      */         
/*  446 */         Scope subscope = this.subscopes[iscope];
/*  447 */         if (subscope.kind == 1) {
/*  448 */           localDeclarations = ((BlockScope)subscope).findLocalVariableDeclarations(position);
/*  449 */           if (localDeclarations != null) {
/*  450 */             return localDeclarations;
/*      */           }
/*      */         } 
/*  453 */         hasMoreScopes = (++iscope < maxScopes);
/*      */         continue;
/*      */       } 
/*  456 */       LocalVariableBinding local = this.locals[ilocal];
/*  457 */       if (local != null && (local.modifiers & 0x10000000) == 0) {
/*  458 */         LocalDeclaration localDecl = local.declaration;
/*  459 */         if (localDecl != null) {
/*  460 */           if (localDecl.declarationSourceStart <= position) {
/*  461 */             if (position <= localDecl.declarationSourceEnd) {
/*  462 */               if (localDeclarations == null) {
/*  463 */                 localDeclarations = new LocalDeclaration[maxLocals];
/*      */               }
/*  465 */               localDeclarations[declPtr++] = localDecl;
/*      */             } 
/*      */           } else {
/*  468 */             return localDeclarations;
/*      */           } 
/*      */         }
/*      */       } 
/*  472 */       hasMoreVariables = (++ilocal < maxLocals);
/*  473 */       if (!hasMoreVariables && localDeclarations != null) {
/*  474 */         return localDeclarations;
/*      */       }
/*      */     } 
/*      */     
/*  478 */     return null;
/*      */   }
/*      */   private boolean isPatternVariableInScope(InvocationSite invocationSite, LocalVariableBinding variable) {
/*  481 */     LocalVariableBinding[] patternVariablesInScope = invocationSite.getPatternVariablesWhenTrue();
/*  482 */     if (patternVariablesInScope == null)
/*  483 */       return false;  byte b; int i; LocalVariableBinding[] arrayOfLocalVariableBinding1;
/*  484 */     for (i = (arrayOfLocalVariableBinding1 = patternVariablesInScope).length, b = 0; b < i; ) { LocalVariableBinding v = arrayOfLocalVariableBinding1[b];
/*  485 */       if (v == variable)
/*  486 */         return true; 
/*      */       b++; }
/*      */     
/*  489 */     return false;
/*      */   }
/*      */   
/*      */   public LocalVariableBinding findVariable(char[] variableName, InvocationSite invocationSite) {
/*  493 */     int varLength = variableName.length; int i;
/*  494 */     for (i = this.localIndex - 1; i >= 0; i--) {
/*  495 */       LocalVariableBinding local = this.locals[i];
/*  496 */       if ((local.modifiers & 0x10000000) == 0) {
/*      */         char[] localName;
/*      */         
/*  499 */         if ((localName = local.name).length == varLength && CharOperation.equals(localName, variableName))
/*  500 */           return local; 
/*      */       } 
/*      */     } 
/*  503 */     for (i = this.localIndex - 1; i >= 0; i--) {
/*  504 */       LocalVariableBinding local = this.locals[i];
/*  505 */       if ((local.modifiers & 0x10000000) != 0) {
/*      */         char[] localName;
/*      */         
/*  508 */         if ((localName = local.name).length == varLength && CharOperation.equals(localName, variableName))
/*      */         {
/*  510 */           if (isPatternVariableInScope(invocationSite, local))
/*  511 */             return local;  } 
/*      */       } 
/*      */     } 
/*  514 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Binding getBinding(char[][] compoundName, int mask, InvocationSite invocationSite, boolean needResolve) {
/*  549 */     Binding binding = getBinding(compoundName[0], mask | 0x4 | 0x10, invocationSite, needResolve);
/*  550 */     invocationSite.setFieldIndex(1);
/*  551 */     if (binding instanceof VariableBinding) return binding; 
/*  552 */     CompilationUnitScope unitScope = compilationUnitScope();
/*      */ 
/*      */     
/*  555 */     unitScope.recordQualifiedReference(compoundName);
/*  556 */     if (!binding.isValidBinding()) return binding;
/*      */     
/*  558 */     int length = compoundName.length;
/*  559 */     int currentIndex = 1;
/*  560 */     if (binding instanceof PackageBinding) {
/*  561 */       PackageBinding packageBinding = (PackageBinding)binding;
/*  562 */       while (currentIndex < length) {
/*  563 */         unitScope.recordReference(packageBinding.compoundName, compoundName[currentIndex]);
/*  564 */         binding = packageBinding.getTypeOrPackage(compoundName[currentIndex++], module(), (currentIndex < length));
/*  565 */         invocationSite.setFieldIndex(currentIndex);
/*  566 */         if (binding == null) {
/*  567 */           if (currentIndex == length)
/*      */           {
/*  569 */             return new ProblemReferenceBinding(
/*  570 */                 CharOperation.subarray(compoundName, 0, currentIndex), 
/*  571 */                 null, 
/*  572 */                 1);
/*      */           }
/*  574 */           return new ProblemBinding(
/*  575 */               CharOperation.subarray(compoundName, 0, currentIndex), 
/*  576 */               1);
/*      */         } 
/*  578 */         if (binding instanceof ReferenceBinding) {
/*  579 */           if (!binding.isValidBinding())
/*  580 */             return new ProblemReferenceBinding(
/*  581 */                 CharOperation.subarray(compoundName, 0, currentIndex), 
/*  582 */                 (ReferenceBinding)((ReferenceBinding)binding).closestMatch(), 
/*  583 */                 binding.problemId()); 
/*  584 */           if (!((ReferenceBinding)binding).canBeSeenBy(this))
/*  585 */             return new ProblemReferenceBinding(
/*  586 */                 CharOperation.subarray(compoundName, 0, currentIndex), 
/*  587 */                 (ReferenceBinding)binding, 
/*  588 */                 2); 
/*  589 */           if (packageBinding instanceof SplitPackageBinding) {
/*  590 */             packageBinding = packageBinding.getVisibleFor(module(), false);
/*  591 */             if (packageBinding instanceof SplitPackageBinding) {
/*  592 */               problemReporter().conflictingPackagesFromModules((SplitPackageBinding)packageBinding, module(), 
/*  593 */                   invocationSite.sourceStart(), invocationSite.sourceEnd()); // Byte code: goto -> 351
/*      */             }  // Byte code: goto -> 351
/*      */           } 
/*      */           // Byte code: goto -> 351
/*      */         } 
/*  598 */         packageBinding = (PackageBinding)binding;
/*      */       } 
/*      */ 
/*      */       
/*  602 */       return new ProblemReferenceBinding(
/*  603 */           CharOperation.subarray(compoundName, 0, currentIndex), 
/*  604 */           null, 
/*  605 */           1);
/*      */     } 
/*      */ 
/*      */     
/*  609 */     ReferenceBinding referenceBinding = (ReferenceBinding)binding;
/*  610 */     binding = environment().convertToRawType(referenceBinding, false);
/*  611 */     if (invocationSite instanceof ASTNode) {
/*  612 */       ASTNode invocationNode = (ASTNode)invocationSite;
/*  613 */       if (invocationNode.isTypeUseDeprecated(referenceBinding, this)) {
/*  614 */         problemReporter().deprecatedType(referenceBinding, invocationNode);
/*      */       }
/*      */     } 
/*  617 */     Binding problemFieldBinding = null;
/*  618 */     while (currentIndex < length) {
/*  619 */       referenceBinding = (ReferenceBinding)binding;
/*  620 */       char[] nextName = compoundName[currentIndex++];
/*  621 */       invocationSite.setFieldIndex(currentIndex);
/*  622 */       invocationSite.setActualReceiverType(referenceBinding);
/*  623 */       if ((mask & 0x1) != 0 && (binding = findField(referenceBinding, nextName, invocationSite, true)) != null) {
/*  624 */         if (binding.isValidBinding()) {
/*      */           break;
/*      */         }
/*  627 */         problemFieldBinding = new ProblemFieldBinding(
/*  628 */             ((ProblemFieldBinding)binding).closestMatch, 
/*  629 */             ((ProblemFieldBinding)binding).declaringClass, 
/*  630 */             CharOperation.concatWith(CharOperation.subarray(compoundName, 0, currentIndex), '.'), 
/*  631 */             binding.problemId());
/*      */ 
/*      */         
/*  634 */         if (binding.problemId() != 2) {
/*  635 */           return problemFieldBinding;
/*      */         }
/*      */       } 
/*  638 */       if ((binding = findMemberType(nextName, referenceBinding)) == null) {
/*  639 */         if (problemFieldBinding != null) {
/*  640 */           return problemFieldBinding;
/*      */         }
/*  642 */         if ((mask & 0x1) != 0)
/*  643 */           return new ProblemFieldBinding(
/*  644 */               null, 
/*  645 */               referenceBinding, 
/*  646 */               nextName, 
/*  647 */               1); 
/*  648 */         if ((mask & 0x3) != 0) {
/*  649 */           return new ProblemBinding(
/*  650 */               CharOperation.subarray(compoundName, 0, currentIndex), 
/*  651 */               referenceBinding, 
/*  652 */               1);
/*      */         }
/*  654 */         return new ProblemReferenceBinding(
/*  655 */             CharOperation.subarray(compoundName, 0, currentIndex), 
/*  656 */             referenceBinding, 
/*  657 */             1);
/*      */       } 
/*      */       
/*  660 */       if (!binding.isValidBinding()) {
/*  661 */         if (problemFieldBinding != null) {
/*  662 */           return problemFieldBinding;
/*      */         }
/*  664 */         return new ProblemReferenceBinding(
/*  665 */             CharOperation.subarray(compoundName, 0, currentIndex), 
/*  666 */             (ReferenceBinding)((ReferenceBinding)binding).closestMatch(), 
/*  667 */             binding.problemId());
/*      */       } 
/*  669 */       if (invocationSite instanceof ASTNode) {
/*  670 */         referenceBinding = (ReferenceBinding)binding;
/*  671 */         ASTNode invocationNode = (ASTNode)invocationSite;
/*  672 */         if (invocationNode.isTypeUseDeprecated(referenceBinding, this)) {
/*  673 */           problemReporter().deprecatedType(referenceBinding, invocationNode);
/*      */         }
/*      */       } 
/*      */     } 
/*  677 */     if ((mask & 0x1) != 0 && binding instanceof FieldBinding) {
/*      */       
/*  679 */       FieldBinding field = (FieldBinding)binding;
/*  680 */       if (!field.isStatic()) {
/*  681 */         return new ProblemFieldBinding(
/*  682 */             field, 
/*  683 */             field.declaringClass, 
/*  684 */             CharOperation.concatWith(CharOperation.subarray(compoundName, 0, currentIndex), '.'), 
/*  685 */             7);
/*      */       }
/*      */       
/*  688 */       return binding;
/*      */     } 
/*  690 */     if ((mask & 0x4) != 0 && binding instanceof ReferenceBinding)
/*      */     {
/*  692 */       return binding;
/*      */     }
/*      */ 
/*      */     
/*  696 */     return new ProblemBinding(
/*  697 */         CharOperation.subarray(compoundName, 0, currentIndex), 
/*  698 */         1);
/*      */   }
/*      */ 
/*      */   
/*      */   public final Binding getBinding(char[][] compoundName, InvocationSite invocationSite) {
/*  703 */     int currentIndex = 0;
/*  704 */     int length = compoundName.length;
/*  705 */     Binding binding = 
/*  706 */       getBinding(
/*  707 */         compoundName[currentIndex++], 
/*  708 */         23, 
/*  709 */         invocationSite, 
/*  710 */         true);
/*  711 */     if (!binding.isValidBinding()) {
/*  712 */       return binding;
/*      */     }
/*  714 */     if (binding instanceof PackageBinding)
/*  715 */       while (true) { if (currentIndex >= length)
/*      */         {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  744 */           return binding; }  PackageBinding packageBinding = (PackageBinding)binding; binding = packageBinding.getTypeOrPackage(compoundName[currentIndex++], module(), (currentIndex < length)); if (binding == null) { if (currentIndex == length)
/*      */             return new ProblemReferenceBinding(CharOperation.subarray(compoundName, 0, currentIndex), null, 1);  return new ProblemBinding(CharOperation.subarray(compoundName, 0, currentIndex), 1); }  if (binding instanceof ReferenceBinding) { if (!binding.isValidBinding())
/*      */             return new ProblemReferenceBinding(CharOperation.subarray(compoundName, 0, currentIndex), (ReferenceBinding)((ReferenceBinding)binding).closestMatch(), binding.problemId());  if (!((ReferenceBinding)binding).canBeSeenBy(this))
/*  747 */             return new ProblemReferenceBinding(CharOperation.subarray(compoundName, 0, currentIndex), (ReferenceBinding)binding, 2);  break; }  }   if (binding instanceof ReferenceBinding)
/*  748 */       while (true) { if (currentIndex >= length)
/*      */         {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  781 */           return binding; }  ReferenceBinding typeBinding = (ReferenceBinding)binding; char[] nextName = compoundName[currentIndex++]; TypeBinding receiverType = typeBinding.capture(this, invocationSite.sourceStart(), invocationSite.sourceEnd()); if ((binding = findField(receiverType, nextName, invocationSite, true)) != null) { if (!binding.isValidBinding()) return new ProblemFieldBinding((FieldBinding)binding, ((FieldBinding)binding).declaringClass, CharOperation.concatWith(CharOperation.subarray(compoundName, 0, currentIndex), '.'), binding.problemId());  if (!((FieldBinding)binding).isStatic())
/*      */             return new ProblemFieldBinding((FieldBinding)binding, ((FieldBinding)binding).declaringClass, CharOperation.concatWith(CharOperation.subarray(compoundName, 0, currentIndex), '.'), 7);  break; }  if ((binding = findMemberType(nextName, typeBinding)) == null)
/*      */           return new ProblemBinding(CharOperation.subarray(compoundName, 0, currentIndex), typeBinding, 1);  if (!binding.isValidBinding())
/*  784 */           return new ProblemReferenceBinding(CharOperation.subarray(compoundName, 0, currentIndex), (ReferenceBinding)((ReferenceBinding)binding).closestMatch(), binding.problemId());  }   VariableBinding variableBinding = (VariableBinding)binding;
/*  785 */     while (currentIndex < length) {
/*  786 */       TypeBinding typeBinding = variableBinding.type;
/*  787 */       if (typeBinding == null) {
/*  788 */         return new ProblemFieldBinding(
/*  789 */             null, 
/*  790 */             null, 
/*  791 */             CharOperation.concatWith(CharOperation.subarray(compoundName, 0, currentIndex), '.'), 
/*  792 */             1);
/*      */       }
/*  794 */       TypeBinding receiverType = typeBinding.capture(this, invocationSite.sourceStart(), invocationSite.sourceEnd());
/*  795 */       variableBinding = findField(receiverType, compoundName[currentIndex++], invocationSite, true);
/*  796 */       if (variableBinding == null) {
/*  797 */         return new ProblemFieldBinding(
/*  798 */             null, 
/*  799 */             (receiverType instanceof ReferenceBinding) ? (ReferenceBinding)receiverType : null, 
/*  800 */             CharOperation.concatWith(CharOperation.subarray(compoundName, 0, currentIndex), '.'), 
/*  801 */             1);
/*      */       }
/*  803 */       if (!variableBinding.isValidBinding())
/*  804 */         return variableBinding; 
/*      */     } 
/*  806 */     return variableBinding;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public VariableBinding[] getEmulationPath(LocalVariableBinding outerLocalVariable) {
/*  827 */     MethodScope currentMethodScope = methodScope();
/*  828 */     SourceTypeBinding sourceType = currentMethodScope.enclosingSourceType();
/*      */ 
/*      */     
/*  831 */     BlockScope variableScope = outerLocalVariable.declaringScope;
/*  832 */     if (variableScope == null || currentMethodScope == variableScope.methodScope()) {
/*  833 */       return new VariableBinding[] { outerLocalVariable };
/*      */     }
/*      */ 
/*      */     
/*  837 */     LambdaExpression lambda = (LambdaExpression)currentMethodScope.referenceContext;
/*      */     SyntheticArgumentBinding syntheticArgument;
/*  839 */     if (currentMethodScope.isLambdaScope() && (syntheticArgument = lambda.getSyntheticArgument(outerLocalVariable)) != null) {
/*  840 */       return new VariableBinding[] { syntheticArgument };
/*      */     }
/*      */ 
/*      */     
/*  844 */     if (currentMethodScope.isInsideInitializerOrConstructor() && 
/*  845 */       sourceType.isNestedType()) {
/*      */       SyntheticArgumentBinding syntheticArg;
/*  847 */       if ((syntheticArg = ((NestedTypeBinding)sourceType).getSyntheticArgument(outerLocalVariable)) != null) {
/*  848 */         return new VariableBinding[] { syntheticArg };
/*      */       }
/*      */     } 
/*      */     
/*  852 */     if (!currentMethodScope.isStatic) {
/*      */       FieldBinding syntheticField;
/*  854 */       if ((syntheticField = sourceType.getSyntheticField(outerLocalVariable)) != null) {
/*  855 */         return new VariableBinding[] { syntheticField };
/*      */       }
/*      */     } 
/*  858 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object[] getEmulationPath(ReferenceBinding targetEnclosingType, boolean onlyExactMatch, boolean denyEnclosingArgInConstructorCall) {
/*  873 */     MethodScope currentMethodScope = methodScope();
/*  874 */     SourceTypeBinding sourceType = currentMethodScope.enclosingSourceType();
/*      */ 
/*      */     
/*  877 */     if (!currentMethodScope.isStatic && !currentMethodScope.isConstructorCall && (
/*  878 */       TypeBinding.equalsEquals(sourceType, targetEnclosingType) || (!onlyExactMatch && sourceType.findSuperTypeOriginatingFrom(targetEnclosingType) != null))) {
/*  879 */       return (Object[])EmulationPathToImplicitThis;
/*      */     }
/*      */     
/*  882 */     if (!sourceType.isNestedType() || sourceType.isStatic()) {
/*  883 */       if (currentMethodScope.isConstructorCall)
/*  884 */         return (Object[])NoEnclosingInstanceInConstructorCall; 
/*  885 */       if (currentMethodScope.isStatic) {
/*  886 */         return (Object[])NoEnclosingInstanceInStaticContext;
/*      */       }
/*  888 */       return null;
/*      */     } 
/*  890 */     if (sourceType.isNestedType() && currentMethodScope.isInsideInitializer() && 
/*  891 */       currentMethodScope.isStatic) {
/*  892 */       return (Object[])NoEnclosingInstanceInStaticContext;
/*      */     }
/*      */     
/*  895 */     boolean insideConstructor = currentMethodScope.isInsideInitializerOrConstructor();
/*      */     
/*  897 */     if (insideConstructor) {
/*      */       SyntheticArgumentBinding syntheticArg;
/*  899 */       if ((syntheticArg = ((NestedTypeBinding)sourceType).getSyntheticArgument(targetEnclosingType, onlyExactMatch, currentMethodScope.isConstructorCall)) != null) {
/*  900 */         boolean isAnonymousAndHasEnclosing = (sourceType.isAnonymousType() && 
/*  901 */           sourceType.scope.referenceContext.allocation.enclosingInstance != null);
/*      */         
/*  903 */         if (denyEnclosingArgInConstructorCall && 
/*  904 */           !isAnonymousAndHasEnclosing && (
/*  905 */           TypeBinding.equalsEquals(sourceType, targetEnclosingType) || (!onlyExactMatch && sourceType.findSuperTypeOriginatingFrom(targetEnclosingType) != null))) {
/*  906 */           return (Object[])NoEnclosingInstanceInConstructorCall;
/*      */         }
/*  908 */         return new Object[] { syntheticArg };
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/*  913 */     if (currentMethodScope.isStatic) {
/*  914 */       return (Object[])NoEnclosingInstanceInStaticContext;
/*      */     }
/*  916 */     if (sourceType.isAnonymousType()) {
/*  917 */       ReferenceBinding enclosingType = sourceType.enclosingType();
/*  918 */       if (enclosingType.isNestedType()) {
/*  919 */         NestedTypeBinding nestedEnclosingType = (NestedTypeBinding)enclosingType;
/*  920 */         SyntheticArgumentBinding enclosingArgument = nestedEnclosingType.getSyntheticArgument(nestedEnclosingType.enclosingType(), onlyExactMatch, currentMethodScope.isConstructorCall);
/*  921 */         if (enclosingArgument != null) {
/*  922 */           FieldBinding fieldBinding = sourceType.getSyntheticField(enclosingArgument);
/*  923 */           if (fieldBinding != null && (
/*  924 */             TypeBinding.equalsEquals(fieldBinding.type, targetEnclosingType) || (!onlyExactMatch && ((ReferenceBinding)fieldBinding.type).findSuperTypeOriginatingFrom(targetEnclosingType) != null))) {
/*  925 */             return new Object[] { fieldBinding };
/*      */           }
/*      */         } 
/*      */       } 
/*      */     } 
/*  930 */     FieldBinding syntheticField = sourceType.getSyntheticField(targetEnclosingType, onlyExactMatch);
/*  931 */     Object[] synEAoL = currentMethodScope.getSyntheticEnclosingArgumentOfLambda(targetEnclosingType);
/*  932 */     if (syntheticField != null) {
/*  933 */       if (currentMethodScope.isConstructorCall) {
/*  934 */         return (synEAoL != null) ? synEAoL : (Object[])NoEnclosingInstanceInConstructorCall;
/*      */       }
/*  936 */       return new Object[] { syntheticField };
/*      */     } 
/*      */ 
/*      */     
/*  940 */     Object[] path = new Object[2];
/*  941 */     ReferenceBinding currentType = sourceType.enclosingType();
/*  942 */     if (insideConstructor) {
/*  943 */       path[0] = ((NestedTypeBinding)sourceType).getSyntheticArgument(currentType, onlyExactMatch, currentMethodScope.isConstructorCall);
/*      */     } else {
/*  945 */       if (currentMethodScope.isConstructorCall) {
/*  946 */         return (synEAoL != null) ? synEAoL : (Object[])NoEnclosingInstanceInConstructorCall;
/*      */       }
/*  948 */       path[0] = sourceType.getSyntheticField(currentType, onlyExactMatch);
/*      */     } 
/*  950 */     if (path[0] != null) {
/*      */       
/*  952 */       int count = 1;
/*      */       ReferenceBinding currentEnclosingType;
/*  954 */       while ((currentEnclosingType = currentType.enclosingType()) != null) {
/*      */ 
/*      */         
/*  957 */         if (TypeBinding.equalsEquals(currentType, targetEnclosingType) || (
/*  958 */           !onlyExactMatch && currentType.findSuperTypeOriginatingFrom(targetEnclosingType) != null))
/*      */           break; 
/*  960 */         if (currentMethodScope != null) {
/*  961 */           currentMethodScope = currentMethodScope.enclosingMethodScope();
/*  962 */           if (currentMethodScope != null && currentMethodScope.isConstructorCall) {
/*  963 */             return (Object[])NoEnclosingInstanceInConstructorCall;
/*      */           }
/*  965 */           if (currentMethodScope != null && currentMethodScope.isStatic) {
/*  966 */             return (Object[])NoEnclosingInstanceInStaticContext;
/*      */           }
/*      */         } 
/*      */         
/*  970 */         syntheticField = ((NestedTypeBinding)currentType).getSyntheticField(currentEnclosingType, onlyExactMatch);
/*  971 */         if (syntheticField == null) {
/*      */           break;
/*      */         }
/*  974 */         if (count == path.length) {
/*  975 */           System.arraycopy(path, 0, path = new Object[count + 1], 0, count);
/*      */         }
/*      */         
/*  978 */         path[count++] = ((SourceTypeBinding)syntheticField.declaringClass).addSyntheticMethod(syntheticField, true, false);
/*  979 */         currentType = currentEnclosingType;
/*      */       } 
/*  981 */       if (TypeBinding.equalsEquals(currentType, targetEnclosingType) || (
/*  982 */         !onlyExactMatch && currentType.findSuperTypeOriginatingFrom(targetEnclosingType) != null)) {
/*  983 */         return path;
/*      */       }
/*      */     } 
/*  986 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public final boolean isDuplicateLocalVariable(char[] name) {
/*  992 */     BlockScope current = this;
/*      */     while (true) {
/*  994 */       for (int i = 0; i < this.localIndex; i++) {
/*  995 */         if (CharOperation.equals(name, (current.locals[i]).name))
/*  996 */           return true; 
/*      */       } 
/*  998 */       if (current.kind != 1) return false; 
/*  999 */       current = (BlockScope)current.parent;
/*      */     } 
/*      */   }
/*      */   
/*      */   public int maxShiftedOffset() {
/* 1004 */     int max = -1;
/* 1005 */     if (this.shiftScopes != null)
/* 1006 */       for (int i = 0, length = this.shiftScopes.length; i < length; i++) {
/* 1007 */         if (this.shiftScopes[i] != null) {
/* 1008 */           int subMaxOffset = (this.shiftScopes[i]).maxOffset;
/* 1009 */           if (subMaxOffset > max) max = subMaxOffset;
/*      */         
/*      */         } 
/*      */       }  
/* 1013 */     return max;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final boolean needBlankFinalFieldInitializationCheck(FieldBinding binding) {
/* 1021 */     boolean isStatic = binding.isStatic();
/* 1022 */     ReferenceBinding fieldDeclaringClass = binding.declaringClass;
/*      */     
/* 1024 */     MethodScope methodScope = namedMethodScope();
/* 1025 */     while (methodScope != null) {
/* 1026 */       if (methodScope.isStatic != isStatic)
/* 1027 */         return false; 
/* 1028 */       if (!methodScope.isInsideInitializer() && 
/* 1029 */         !((AbstractMethodDeclaration)methodScope.referenceContext).isInitializationMethod()) {
/* 1030 */         return false;
/*      */       }
/* 1032 */       ReferenceBinding enclosingType = methodScope.enclosingReceiverType();
/* 1033 */       if (TypeBinding.equalsEquals(enclosingType, fieldDeclaringClass)) {
/* 1034 */         return true;
/*      */       }
/* 1036 */       if (!enclosingType.erasure().isAnonymousType()) {
/* 1037 */         return false;
/*      */       }
/* 1039 */       methodScope = methodScope.enclosingMethodScope().namedMethodScope();
/*      */     } 
/* 1041 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ProblemReporter problemReporter() {
/* 1052 */     return methodScope().problemReporter();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void propagateInnerEmulation(ReferenceBinding targetType, boolean isEnclosingInstanceSupplied) {
/*      */     SyntheticArgumentBinding[] syntheticArguments;
/* 1063 */     if ((syntheticArguments = targetType.syntheticOuterLocalVariables()) != null) {
/* 1064 */       for (int i = 0, max = syntheticArguments.length; i < max; i++) {
/* 1065 */         SyntheticArgumentBinding syntheticArg = syntheticArguments[i];
/*      */         
/* 1067 */         if (!isEnclosingInstanceSupplied || 
/* 1068 */           !TypeBinding.equalsEquals(syntheticArg.type, targetType.enclosingType())) {
/* 1069 */           emulateOuterAccess(syntheticArg.actualOuterLocalVariable);
/*      */         }
/*      */       } 
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public TypeDeclaration referenceType() {
/* 1080 */     return methodScope().referenceType();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int scopeIndex() {
/* 1088 */     if (this instanceof MethodScope) return -1; 
/* 1089 */     BlockScope parentScope = (BlockScope)this.parent;
/* 1090 */     Scope[] parentSubscopes = parentScope.subscopes;
/* 1091 */     for (int i = 0, max = parentScope.subscopeCount; i < max; i++) {
/* 1092 */       if (parentSubscopes[i] == this) return i; 
/*      */     } 
/* 1094 */     return -1;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   int startIndex() {
/* 1100 */     return this.startIndex;
/*      */   }
/*      */ 
/*      */   
/*      */   public String toString() {
/* 1105 */     return toString(0);
/*      */   }
/*      */   
/*      */   public String toString(int tab) {
/* 1109 */     String s = basicToString(tab);
/* 1110 */     for (int i = 0; i < this.subscopeCount; i++) {
/* 1111 */       if (this.subscopes[i] instanceof BlockScope)
/* 1112 */         s = String.valueOf(s) + ((BlockScope)this.subscopes[i]).toString(tab + 1) + "\n"; 
/* 1113 */     }  return s;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int registerTrackingVariable(FakedTrackingVariable fakedTrackingVariable) {
/* 1124 */     if (this.trackingVariables == null)
/* 1125 */       this.trackingVariables = new ArrayList(3); 
/* 1126 */     this.trackingVariables.add(fakedTrackingVariable);
/* 1127 */     MethodScope outerMethodScope = outerMostMethodScope();
/* 1128 */     return outerMethodScope.analysisIndex++;
/*      */   }
/*      */   
/*      */   public void removeTrackingVar(FakedTrackingVariable trackingVariable) {
/* 1132 */     if (trackingVariable.innerTracker != null) {
/* 1133 */       trackingVariable.innerTracker.withdraw();
/* 1134 */       trackingVariable.innerTracker = null;
/*      */     } 
/* 1136 */     if (this.trackingVariables != null && 
/* 1137 */       this.trackingVariables.remove(trackingVariable))
/*      */       return; 
/* 1139 */     if (this.parent instanceof BlockScope)
/* 1140 */       ((BlockScope)this.parent).removeTrackingVar(trackingVariable); 
/*      */   }
/*      */   
/*      */   public void pruneWrapperTrackingVar(FakedTrackingVariable trackingVariable) {
/* 1144 */     this.trackingVariables.remove(trackingVariable);
/*      */   }
/*      */   
/*      */   public boolean hasResourceTrackers() {
/* 1148 */     return (this.trackingVariables != null && !this.trackingVariables.isEmpty());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void checkUnclosedCloseables(FlowInfo flowInfo, FlowContext flowContext, ASTNode location, BlockScope locationScope) {
/* 1156 */     if (!(compilerOptions()).analyseResourceLeaks)
/* 1157 */       return;  if (this.trackingVariables == null) {
/*      */       
/* 1159 */       if (location != null && this.parent instanceof BlockScope && !isLambdaScope())
/* 1160 */         ((BlockScope)this.parent).checkUnclosedCloseables(flowInfo, flowContext, location, locationScope); 
/*      */       return;
/*      */     } 
/* 1163 */     if (location != null && flowInfo.reachMode() != 0)
/*      */       return; 
/* 1165 */     FakedTrackingVariable returnVar = (location instanceof ReturnStatement) ? 
/* 1166 */       FakedTrackingVariable.getCloseTrackingVariable(((ReturnStatement)location).expression, flowInfo, flowContext) : null;
/*      */ 
/*      */     
/* 1169 */     FakedTrackingVariable.IteratorForReporting<FakedTrackingVariable> iteratorForReporting = new FakedTrackingVariable.IteratorForReporting(this.trackingVariables, this, (location != null));
/* 1170 */     while (iteratorForReporting.hasNext()) {
/* 1171 */       FakedTrackingVariable trackingVar = iteratorForReporting.next();
/*      */       
/* 1173 */       if (returnVar != null && trackingVar.isResourceBeingReturned(returnVar)) {
/*      */         continue;
/*      */       }
/*      */       
/* 1177 */       if (location != null && trackingVar.hasDefinitelyNoResource(flowInfo)) {
/*      */         continue;
/*      */       }
/*      */       
/* 1181 */       if (location != null && flowContext != null && flowContext.recordExitAgainstResource(this, flowInfo, trackingVar, location)) {
/*      */         continue;
/*      */       }
/*      */ 
/*      */       
/* 1186 */       int status = trackingVar.findMostSpecificStatus(flowInfo, this, locationScope);
/*      */       
/* 1188 */       if (status == 2) {
/*      */         
/* 1190 */         reportResourceLeak(trackingVar, location, status);
/*      */         continue;
/*      */       } 
/* 1193 */       if (location == null)
/*      */       {
/*      */         
/* 1196 */         if (trackingVar.reportRecordedErrors(this, status, (flowInfo.reachMode() != 0)))
/*      */           continue; 
/*      */       }
/* 1199 */       if (status == 16) {
/*      */         
/* 1201 */         reportResourceLeak(trackingVar, location, status); continue;
/* 1202 */       }  if (status == 4)
/*      */       {
/* 1204 */         if ((environment()).globalOptions.complianceLevel >= 3342336L)
/* 1205 */           trackingVar.reportExplicitClosing(problemReporter()); 
/*      */       }
/*      */     } 
/* 1208 */     if (location == null) {
/*      */       
/* 1210 */       for (int i = 0; i < this.localIndex; i++)
/* 1211 */         (this.locals[i]).closeTracker = null; 
/* 1212 */       this.trackingVariables = null;
/*      */     } 
/*      */   }
/*      */   
/*      */   private void reportResourceLeak(FakedTrackingVariable trackingVar, ASTNode location, int nullStatus) {
/* 1217 */     if (location != null) {
/* 1218 */       trackingVar.recordErrorLocation(location, nullStatus);
/*      */     } else {
/* 1220 */       trackingVar.reportError(problemReporter(), null, nullStatus);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void correlateTrackingVarsIfElse(FlowInfo thenFlowInfo, FlowInfo elseFlowInfo) {
/* 1243 */     if (this.trackingVariables != null) {
/* 1244 */       int trackVarCount = this.trackingVariables.size();
/* 1245 */       for (int i = 0; i < trackVarCount; i++) {
/* 1246 */         FakedTrackingVariable trackingVar = this.trackingVariables.get(i);
/* 1247 */         if (trackingVar.originalBinding == null) {
/*      */           
/* 1249 */           boolean hasNullInfoInThen = thenFlowInfo.hasNullInfoFor(trackingVar.binding);
/* 1250 */           boolean hasNullInfoInElse = elseFlowInfo.hasNullInfoFor(trackingVar.binding);
/* 1251 */           if (hasNullInfoInThen && !hasNullInfoInElse) {
/* 1252 */             int nullStatus = thenFlowInfo.nullStatus(trackingVar.binding);
/* 1253 */             elseFlowInfo.markNullStatus(trackingVar.binding, nullStatus);
/* 1254 */           } else if (!hasNullInfoInThen && hasNullInfoInElse) {
/* 1255 */             int nullStatus = elseFlowInfo.nullStatus(trackingVar.binding);
/* 1256 */             thenFlowInfo.markNullStatus(trackingVar.binding, nullStatus);
/*      */           }
/*      */         
/*      */         }
/* 1260 */         else if (thenFlowInfo.isDefinitelyNonNull(trackingVar.binding) && 
/* 1261 */           elseFlowInfo.isDefinitelyNull(trackingVar.originalBinding)) {
/*      */           
/* 1263 */           elseFlowInfo.markAsDefinitelyNonNull(trackingVar.binding);
/*      */         }
/* 1265 */         else if (elseFlowInfo.isDefinitelyNonNull(trackingVar.binding) && 
/* 1266 */           thenFlowInfo.isDefinitelyNull(trackingVar.originalBinding)) {
/*      */           
/* 1268 */           thenFlowInfo.markAsDefinitelyNonNull(trackingVar.binding);
/*      */         
/*      */         }
/* 1271 */         else if (thenFlowInfo != FlowInfo.DEAD_END && elseFlowInfo != FlowInfo.DEAD_END) {
/*      */ 
/*      */           
/* 1274 */           for (int j = i + 1; j < trackVarCount; j++) {
/* 1275 */             FakedTrackingVariable var2 = this.trackingVariables.get(j);
/* 1276 */             if (trackingVar.originalBinding == var2.originalBinding) {
/*      */               int newStatus;
/* 1278 */               boolean var1SeenInThen = thenFlowInfo.hasNullInfoFor(trackingVar.binding);
/* 1279 */               boolean var1SeenInElse = elseFlowInfo.hasNullInfoFor(trackingVar.binding);
/* 1280 */               boolean var2SeenInThen = thenFlowInfo.hasNullInfoFor(var2.binding);
/* 1281 */               boolean var2SeenInElse = elseFlowInfo.hasNullInfoFor(var2.binding);
/*      */               
/* 1283 */               if (!var1SeenInThen && var1SeenInElse && var2SeenInThen && !var2SeenInElse) {
/* 1284 */                 newStatus = FlowInfo.mergeNullStatus(thenFlowInfo.nullStatus(var2.binding), elseFlowInfo.nullStatus(trackingVar.binding));
/* 1285 */               } else if (var1SeenInThen && !var1SeenInElse && !var2SeenInThen && var2SeenInElse) {
/* 1286 */                 newStatus = FlowInfo.mergeNullStatus(thenFlowInfo.nullStatus(trackingVar.binding), elseFlowInfo.nullStatus(var2.binding));
/*      */               } else {
/*      */                 continue;
/*      */               } 
/* 1290 */               thenFlowInfo.markNullStatus(trackingVar.binding, newStatus);
/* 1291 */               elseFlowInfo.markNullStatus(trackingVar.binding, newStatus);
/* 1292 */               trackingVar.originalBinding.closeTracker = trackingVar;
/* 1293 */               thenFlowInfo.markNullStatus(var2.binding, 4);
/* 1294 */               elseFlowInfo.markNullStatus(var2.binding, 4);
/*      */             }  continue;
/*      */           } 
/*      */         } 
/*      */       } 
/*      */     } 
/* 1300 */     if (this.parent instanceof BlockScope) {
/* 1301 */       ((BlockScope)this.parent).correlateTrackingVarsIfElse(thenFlowInfo, elseFlowInfo);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void checkAppropriateMethodAgainstSupers(char[] selector, MethodBinding compileTimeMethod, TypeBinding[] parameters, InvocationSite site) {
/* 1308 */     ReferenceBinding enclosingType = enclosingReceiverType();
/* 1309 */     MethodBinding otherMethod = getMethod(enclosingType.superclass(), selector, parameters, site);
/* 1310 */     if (checkAppropriate(compileTimeMethod, otherMethod, site)) {
/* 1311 */       ReferenceBinding[] superInterfaces = enclosingType.superInterfaces();
/* 1312 */       if (superInterfaces != null)
/* 1313 */         for (int i = 0; i < superInterfaces.length; i++) {
/* 1314 */           otherMethod = getMethod(superInterfaces[i], selector, parameters, site);
/* 1315 */           if (!checkAppropriate(compileTimeMethod, otherMethod, site))
/*      */             break; 
/*      */         }  
/*      */     } 
/*      */   }
/*      */   
/*      */   private boolean checkAppropriate(MethodBinding compileTimeDeclaration, MethodBinding otherMethod, InvocationSite location) {
/* 1322 */     if (otherMethod == null || !otherMethod.isValidBinding() || otherMethod.original() == compileTimeDeclaration.original())
/* 1323 */       return true; 
/* 1324 */     if (MethodVerifier.doesMethodOverride(otherMethod, compileTimeDeclaration, environment())) {
/* 1325 */       problemReporter().illegalSuperCallBypassingOverride(location, compileTimeDeclaration, otherMethod.declaringClass);
/* 1326 */       return false;
/*      */     } 
/* 1328 */     return true;
/*      */   }
/*      */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\lookup\BlockScope.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */