/*    */ package org.eclipse.jdt.internal.compiler.classfmt;
/*    */ 
/*    */ import org.eclipse.jdt.internal.compiler.env.IBinaryTypeAnnotation;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class FieldInfoWithTypeAnnotation
/*    */   extends FieldInfoWithAnnotation
/*    */ {
/*    */   private TypeAnnotationInfo[] typeAnnotations;
/*    */   
/*    */   FieldInfoWithTypeAnnotation(FieldInfo info, AnnotationInfo[] annos, TypeAnnotationInfo[] typeAnnos) {
/* 23 */     super(info, annos);
/* 24 */     this.typeAnnotations = typeAnnos;
/*    */   }
/*    */   
/*    */   public IBinaryTypeAnnotation[] getTypeAnnotations() {
/* 28 */     return (IBinaryTypeAnnotation[])this.typeAnnotations;
/*    */   }
/*    */   
/*    */   protected void initialize() {
/* 32 */     for (int i = 0, max = this.typeAnnotations.length; i < max; i++)
/* 33 */       this.typeAnnotations[i].initialize(); 
/* 34 */     super.initialize();
/*    */   }
/*    */   
/*    */   protected void reset() {
/* 38 */     if (this.typeAnnotations != null)
/* 39 */       for (int i = 0, max = this.typeAnnotations.length; i < max; i++)
/* 40 */         this.typeAnnotations[i].reset();  
/* 41 */     super.reset();
/*    */   }
/*    */   
/*    */   public String toString() {
/* 45 */     StringBuffer buffer = new StringBuffer(getClass().getName());
/* 46 */     if (this.typeAnnotations != null) {
/* 47 */       buffer.append('\n');
/* 48 */       buffer.append("type annotations:");
/* 49 */       for (int i = 0; i < this.typeAnnotations.length; i++) {
/* 50 */         buffer.append(this.typeAnnotations[i]);
/* 51 */         buffer.append('\n');
/*    */       } 
/*    */     } 
/* 54 */     toStringContent(buffer);
/* 55 */     return buffer.toString();
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\classfmt\FieldInfoWithTypeAnnotation.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */