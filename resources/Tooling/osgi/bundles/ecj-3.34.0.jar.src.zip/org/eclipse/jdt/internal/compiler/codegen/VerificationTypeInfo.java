/*     */ package org.eclipse.jdt.internal.compiler.codegen;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.eclipse.jdt.core.compiler.CharOperation;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.ArrayBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.Scope;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.TypeBinding;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class VerificationTypeInfo
/*     */ {
/*     */   public static final int ITEM_TOP = 0;
/*     */   public static final int ITEM_INTEGER = 1;
/*     */   public static final int ITEM_FLOAT = 2;
/*     */   public static final int ITEM_DOUBLE = 3;
/*     */   public static final int ITEM_LONG = 4;
/*     */   public static final int ITEM_NULL = 5;
/*     */   public static final int ITEM_UNINITIALIZED_THIS = 6;
/*     */   public static final int ITEM_OBJECT = 7;
/*     */   public static final int ITEM_UNINITIALIZED = 8;
/*     */   public int tag;
/*     */   private int id;
/*     */   private TypeBinding binding;
/*     */   public int offset;
/*     */   private List<TypeBinding> bindings;
/*     */   
/*     */   public VerificationTypeInfo(int tag, TypeBinding binding) {
/*  88 */     this(binding);
/*  89 */     this.tag = tag;
/*     */   }
/*     */   
/*     */   public VerificationTypeInfo(TypeBinding binding) {
/*  93 */     if (binding == null)
/*  94 */       return;  this.id = binding.id;
/*  95 */     this.binding = binding;
/*  96 */     switch (binding.id) {
/*     */       case 2:
/*     */       case 3:
/*     */       case 4:
/*     */       case 5:
/*     */       case 10:
/* 102 */         this.tag = 1;
/*     */         return;
/*     */       case 9:
/* 105 */         this.tag = 2;
/*     */         return;
/*     */       case 7:
/* 108 */         this.tag = 4;
/*     */         return;
/*     */       case 8:
/* 111 */         this.tag = 3;
/*     */         return;
/*     */       case 12:
/* 114 */         this.tag = 5;
/*     */         return;
/*     */     } 
/* 117 */     this.tag = 7;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setBinding(TypeBinding binding) {
/* 122 */     int typeBindingId = binding.id;
/* 123 */     this.id = typeBindingId;
/* 124 */     switch (typeBindingId) {
/*     */       case 2:
/*     */       case 3:
/*     */       case 4:
/*     */       case 5:
/*     */       case 10:
/* 130 */         this.tag = 1;
/*     */         return;
/*     */       case 9:
/* 133 */         this.tag = 2;
/*     */         return;
/*     */       case 7:
/* 136 */         this.tag = 4;
/*     */         return;
/*     */       case 8:
/* 139 */         this.tag = 3;
/*     */         return;
/*     */       case 12:
/* 142 */         this.tag = 5;
/*     */         return;
/*     */     } 
/* 145 */     this.tag = 7;
/*     */   }
/*     */ 
/*     */   
/*     */   public int id() {
/* 150 */     return this.id;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 155 */     StringBuffer buffer = new StringBuffer();
/* 156 */     switch (this.tag) {
/*     */       case 6:
/* 158 */         buffer.append("uninitialized_this(").append(readableName()).append(")");
/*     */         break;
/*     */       case 8:
/* 161 */         buffer.append("uninitialized(").append(readableName()).append(")");
/*     */         break;
/*     */       case 7:
/* 164 */         buffer.append(readableName());
/*     */         break;
/*     */       case 3:
/* 167 */         buffer.append('D');
/*     */         break;
/*     */       case 2:
/* 170 */         buffer.append('F');
/*     */         break;
/*     */       case 1:
/* 173 */         buffer.append('I');
/*     */         break;
/*     */       case 4:
/* 176 */         buffer.append('J');
/*     */         break;
/*     */       case 5:
/* 179 */         buffer.append("null");
/*     */         break;
/*     */       case 0:
/* 182 */         buffer.append("top");
/*     */         break;
/*     */     } 
/* 185 */     return String.valueOf(buffer);
/*     */   }
/*     */   
/*     */   public VerificationTypeInfo duplicate() {
/* 189 */     VerificationTypeInfo verificationTypeInfo = new VerificationTypeInfo(this.tag, this.binding);
/* 190 */     verificationTypeInfo.offset = this.offset;
/* 191 */     return verificationTypeInfo;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object obj) {
/* 196 */     if (obj instanceof VerificationTypeInfo) {
/* 197 */       VerificationTypeInfo info1 = (VerificationTypeInfo)obj;
/* 198 */       return (info1.tag == this.tag && 
/* 199 */         info1.offset == this.offset && 
/* 200 */         CharOperation.equals(info1.constantPoolName(), constantPoolName()));
/*     */     } 
/* 202 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 207 */     return this.tag + this.offset + CharOperation.hashCode(constantPoolName());
/*     */   }
/*     */   
/*     */   public char[] constantPoolName() {
/* 211 */     return this.binding.constantPoolName();
/*     */   }
/*     */   
/*     */   public char[] readableName() {
/* 215 */     return constantPoolName();
/*     */   }
/*     */   
/*     */   public void replaceWithElementType() {
/* 219 */     ArrayBinding arrayBinding = (ArrayBinding)this.binding;
/* 220 */     this.binding = arrayBinding.elementsType();
/* 221 */     this.id = this.binding.id;
/*     */   }
/*     */   
/*     */   public VerificationTypeInfo merge(VerificationTypeInfo verificationTypeInfo, Scope scope) {
/* 225 */     if (this.binding.isBaseType() && verificationTypeInfo.binding.isBaseType()) {
/* 226 */       return this;
/*     */     }
/* 228 */     if (!this.binding.equals(verificationTypeInfo.binding))
/* 229 */     { if (this.bindings == null) {
/* 230 */         this.bindings = new ArrayList<>();
/* 231 */         this.bindings.add(this.binding);
/*     */       } 
/* 233 */       this.bindings.add(verificationTypeInfo.binding);
/* 234 */       this.binding = scope.lowerUpperBound(this.bindings.<TypeBinding>toArray(new TypeBinding[this.bindings.size()]));
/* 235 */       if (this.binding != null)
/* 236 */       { this.id = this.binding.id;
/* 237 */         switch (this.id)
/*     */         { case 12:
/* 239 */             this.tag = 5;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */             
/* 249 */             return this; }  this.tag = 7; } else { this.binding = (TypeBinding)scope.getJavaLangObject(); this.tag = 7; }  }  return this;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\codegen\VerificationTypeInfo.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */