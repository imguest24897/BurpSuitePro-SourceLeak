/*     */ package org.eclipse.jdt.internal.compiler.apt.dispatch;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import javax.annotation.processing.Filer;
/*     */ import javax.annotation.processing.Messager;
/*     */ import javax.annotation.processing.ProcessingEnvironment;
/*     */ import javax.lang.model.SourceVersion;
/*     */ import javax.lang.model.util.Elements;
/*     */ import javax.lang.model.util.Types;
/*     */ import javax.tools.JavaFileManager;
/*     */ import org.eclipse.jdt.internal.compiler.Compiler;
/*     */ import org.eclipse.jdt.internal.compiler.apt.model.ElementsImpl;
/*     */ import org.eclipse.jdt.internal.compiler.apt.model.Factory;
/*     */ import org.eclipse.jdt.internal.compiler.apt.model.TypesImpl;
/*     */ import org.eclipse.jdt.internal.compiler.env.ICompilationUnit;
/*     */ import org.eclipse.jdt.internal.compiler.impl.CompilerOptions;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.LookupEnvironment;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.ModuleBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.ReferenceBinding;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class BaseProcessingEnvImpl
/*     */   implements ProcessingEnvironment
/*     */ {
/*  49 */   public static final SourceVersion MINIMAL_REQUIRED_RUNTIME_VERSION = SourceVersion.RELEASE_17;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  69 */   private List<ICompilationUnit> _addedUnits = new ArrayList<>();
/*  70 */   private List<ReferenceBinding> _addedClassFiles = new ArrayList<>();
/*  71 */   private List<ICompilationUnit> _deletedUnits = new ArrayList<>();
/*  72 */   protected Elements _elementUtils = (Elements)ElementsImpl.create(this);
/*  73 */   protected Types _typeUtils = (Types)new TypesImpl(this);
/*  74 */   private Factory _factory = new Factory(this); private boolean _errorRaised = false;
/*     */   private static final long VERSION_FOR_MINIMAL_RUNTIME = 3997696L;
/*     */   protected Filer _filer;
/*     */   
/*     */   public void addNewUnit(ICompilationUnit unit) {
/*  79 */     this._addedUnits.add(unit);
/*     */   }
/*     */   protected Messager _messager; protected Map<String, String> _processorOptions; protected Compiler _compiler; public ModuleBinding _current_module;
/*     */   public void addNewClassFile(ReferenceBinding binding) {
/*  83 */     this._addedClassFiles.add(binding);
/*     */   }
/*     */   
/*     */   public Compiler getCompiler() {
/*  87 */     return this._compiler;
/*     */   }
/*     */   
/*     */   public ICompilationUnit[] getDeletedUnits() {
/*  91 */     ICompilationUnit[] result = new ICompilationUnit[this._deletedUnits.size()];
/*  92 */     this._deletedUnits.toArray(result);
/*  93 */     return result;
/*     */   }
/*     */   
/*     */   public ICompilationUnit[] getNewUnits() {
/*  97 */     ICompilationUnit[] result = new ICompilationUnit[this._addedUnits.size()];
/*  98 */     this._addedUnits.toArray(result);
/*  99 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   public Elements getElementUtils() {
/* 104 */     return this._elementUtils;
/*     */   }
/*     */ 
/*     */   
/*     */   public Filer getFiler() {
/* 109 */     return this._filer;
/*     */   }
/*     */ 
/*     */   
/*     */   public Messager getMessager() {
/* 114 */     return this._messager;
/*     */   }
/*     */ 
/*     */   
/*     */   public Map<String, String> getOptions() {
/* 119 */     return this._processorOptions;
/*     */   }
/*     */ 
/*     */   
/*     */   public Types getTypeUtils() {
/* 124 */     return this._typeUtils;
/*     */   }
/*     */   
/*     */   public LookupEnvironment getLookupEnvironment() {
/* 128 */     return this._compiler.lookupEnvironment;
/*     */   }
/*     */ 
/*     */   
/*     */   public SourceVersion getSourceVersion() {
/* 133 */     long sourceLevel = this._compiler.options.sourceLevel;
/* 134 */     if (sourceLevel <= 3211264L) {
/* 135 */       return SourceVersion.RELEASE_5;
/*     */     }
/* 137 */     if (sourceLevel == 3276800L)
/* 138 */       return SourceVersion.RELEASE_6; 
/* 139 */     if (sourceLevel == 3342336L)
/* 140 */       return SourceVersion.RELEASE_7; 
/* 141 */     if (sourceLevel == 3407872L)
/* 142 */       return SourceVersion.RELEASE_8; 
/* 143 */     if (sourceLevel == 3473408L)
/* 144 */       return SourceVersion.RELEASE_9; 
/* 145 */     if (sourceLevel == 3538944L)
/* 146 */       return SourceVersion.RELEASE_10; 
/* 147 */     if (sourceLevel == 3604480L)
/* 148 */       return SourceVersion.RELEASE_11; 
/* 149 */     if (sourceLevel == 3670016L)
/* 150 */       return SourceVersion.RELEASE_12; 
/* 151 */     if (sourceLevel == 3735552L)
/* 152 */       return SourceVersion.RELEASE_13; 
/* 153 */     if (sourceLevel == 3801088L)
/* 154 */       return SourceVersion.RELEASE_14; 
/* 155 */     if (sourceLevel == 3866624L)
/* 156 */       return SourceVersion.RELEASE_15; 
/* 157 */     if (sourceLevel == 3932160L)
/* 158 */       return SourceVersion.RELEASE_16; 
/* 159 */     if (sourceLevel == 3997696L) {
/* 160 */       return SourceVersion.RELEASE_17;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 165 */     if (sourceLevel > 3997696L) {
/*     */       try {
/* 167 */         return SourceVersion.valueOf("RELEASE_" + CompilerOptions.versionFromJdkLevel(sourceLevel));
/* 168 */       } catch (IllegalArgumentException illegalArgumentException) {
/*     */         
/* 170 */         return MINIMAL_REQUIRED_RUNTIME_VERSION;
/*     */       } 
/*     */     }
/*     */     
/* 174 */     throw new IllegalStateException("Invalid JDK source level: " + sourceLevel);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void reset() {
/* 183 */     this._addedUnits.clear();
/* 184 */     this._addedClassFiles.clear();
/* 185 */     this._deletedUnits.clear();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean errorRaised() {
/* 194 */     return this._errorRaised;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setErrorRaised(boolean b) {
/* 203 */     this._errorRaised = true;
/*     */   }
/*     */ 
/*     */   
/*     */   public Factory getFactory() {
/* 208 */     return this._factory;
/*     */   }
/*     */   
/*     */   public ReferenceBinding[] getNewClassFiles() {
/* 212 */     ReferenceBinding[] result = new ReferenceBinding[this._addedClassFiles.size()];
/* 213 */     this._addedClassFiles.toArray(result);
/* 214 */     return result;
/*     */   }
/*     */   
/*     */   public boolean isPreviewEnabled() {
/* 218 */     return this._compiler.options.enablePreviewFeatures;
/*     */   }
/*     */   
/*     */   public JavaFileManager getFileManager() {
/* 222 */     return null;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\apt\dispatch\BaseProcessingEnvImpl.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */