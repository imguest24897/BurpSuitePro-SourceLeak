/*     */ package org.eclipse.jdt.internal.compiler.apt.dispatch;
/*     */ 
/*     */ import javax.lang.model.element.Element;
/*     */ import javax.lang.model.element.TypeElement;
/*     */ import org.eclipse.jdt.internal.compiler.ASTVisitor;
/*     */ import org.eclipse.jdt.internal.compiler.apt.model.ElementImpl;
/*     */ import org.eclipse.jdt.internal.compiler.apt.model.Factory;
/*     */ import org.eclipse.jdt.internal.compiler.apt.util.ManyToMany;
/*     */ import org.eclipse.jdt.internal.compiler.ast.AbstractMethodDeclaration;
/*     */ import org.eclipse.jdt.internal.compiler.ast.Annotation;
/*     */ import org.eclipse.jdt.internal.compiler.ast.Argument;
/*     */ import org.eclipse.jdt.internal.compiler.ast.ConstructorDeclaration;
/*     */ import org.eclipse.jdt.internal.compiler.ast.FieldDeclaration;
/*     */ import org.eclipse.jdt.internal.compiler.ast.MethodDeclaration;
/*     */ import org.eclipse.jdt.internal.compiler.ast.ModuleDeclaration;
/*     */ import org.eclipse.jdt.internal.compiler.ast.RecordComponent;
/*     */ import org.eclipse.jdt.internal.compiler.ast.TypeDeclaration;
/*     */ import org.eclipse.jdt.internal.compiler.ast.TypeParameter;
/*     */ import org.eclipse.jdt.internal.compiler.impl.ReferenceContext;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.AnnotationBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.AptSourceLocalVariableBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.Binding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.BlockScope;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.ClassScope;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.CompilationUnitScope;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.FieldBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.LocalVariableBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.MethodBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.MethodScope;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.RecordComponentBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.ReferenceBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.SourceModuleBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.SourceTypeBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.TypeBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.TypeVariableBinding;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AnnotationDiscoveryVisitor
/*     */   extends ASTVisitor
/*     */ {
/*     */   final BaseProcessingEnvImpl _env;
/*     */   final Factory _factory;
/*     */   final ManyToMany<TypeElement, Element> _annoToElement;
/*     */   
/*     */   public AnnotationDiscoveryVisitor(BaseProcessingEnvImpl env) {
/*  63 */     this._env = env;
/*  64 */     this._factory = env.getFactory();
/*  65 */     this._annoToElement = new ManyToMany();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean visit(Argument argument, BlockScope scope) {
/*  70 */     Annotation[] annotations = argument.annotations;
/*  71 */     ReferenceContext referenceContext = scope.referenceContext();
/*  72 */     if (referenceContext instanceof AbstractMethodDeclaration) {
/*  73 */       MethodBinding binding = ((AbstractMethodDeclaration)referenceContext).binding;
/*  74 */       if (binding != null) {
/*  75 */         TypeDeclaration typeDeclaration = scope.referenceType();
/*  76 */         typeDeclaration.binding.resolveTypesFor(binding);
/*  77 */         if (argument.binding != null) {
/*  78 */           argument.binding = (LocalVariableBinding)new AptSourceLocalVariableBinding(argument.binding, binding);
/*     */         }
/*     */       } 
/*  81 */       if (annotations != null && argument.binding != null) {
/*  82 */         resolveAnnotations(
/*  83 */             scope, 
/*  84 */             annotations, 
/*  85 */             (Binding)argument.binding);
/*     */       }
/*     */     } 
/*  88 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean visit(ConstructorDeclaration constructorDeclaration, ClassScope scope) {
/*  93 */     Annotation[] annotations = constructorDeclaration.annotations;
/*  94 */     if (annotations != null) {
/*  95 */       MethodBinding constructorBinding = constructorDeclaration.binding;
/*  96 */       if (constructorBinding == null) {
/*  97 */         return false;
/*     */       }
/*  99 */       ((SourceTypeBinding)constructorBinding.declaringClass).resolveTypesFor(constructorBinding);
/* 100 */       resolveAnnotations(
/* 101 */           (BlockScope)constructorDeclaration.scope, 
/* 102 */           annotations, 
/* 103 */           (Binding)constructorBinding);
/*     */     } 
/*     */     
/* 106 */     TypeParameter[] typeParameters = constructorDeclaration.typeParameters;
/* 107 */     if (typeParameters != null) {
/* 108 */       int typeParametersLength = typeParameters.length;
/* 109 */       for (int i = 0; i < typeParametersLength; i++) {
/* 110 */         typeParameters[i].traverse(this, (BlockScope)constructorDeclaration.scope);
/*     */       }
/*     */     } 
/*     */     
/* 114 */     Argument[] arguments = constructorDeclaration.arguments;
/* 115 */     if (arguments != null) {
/* 116 */       int argumentLength = arguments.length;
/* 117 */       for (int i = 0; i < argumentLength; i++) {
/* 118 */         arguments[i].traverse(this, (BlockScope)constructorDeclaration.scope);
/*     */       }
/*     */     } 
/* 121 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean visit(FieldDeclaration fieldDeclaration, MethodScope scope) {
/* 126 */     Annotation[] annotations = fieldDeclaration.annotations;
/* 127 */     if (annotations != null) {
/* 128 */       FieldBinding fieldBinding = fieldDeclaration.binding;
/* 129 */       if (fieldBinding == null) {
/* 130 */         return false;
/*     */       }
/* 132 */       ((SourceTypeBinding)fieldBinding.declaringClass).resolveTypeFor(fieldBinding);
/* 133 */       if (fieldDeclaration.binding == null) {
/* 134 */         return false;
/*     */       }
/* 136 */       resolveAnnotations((BlockScope)scope, annotations, (Binding)fieldBinding);
/*     */     } 
/* 138 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean visit(RecordComponent recordComponent, BlockScope scope) {
/* 143 */     Annotation[] annotations = recordComponent.annotations;
/* 144 */     if (annotations != null) {
/* 145 */       RecordComponentBinding recordComponentBinding = recordComponent.binding;
/* 146 */       if (recordComponentBinding == null) {
/* 147 */         return false;
/*     */       }
/* 149 */       ((SourceTypeBinding)recordComponentBinding.declaringRecord).resolveTypeFor(recordComponentBinding);
/* 150 */       if (recordComponent.binding == null) {
/* 151 */         return false;
/*     */       }
/* 153 */       resolveAnnotations(scope, annotations, (Binding)recordComponentBinding);
/*     */     } 
/* 155 */     return false;
/*     */   }
/*     */   
/*     */   public boolean visit(TypeParameter typeParameter, ClassScope scope) {
/* 159 */     Annotation[] annotations = typeParameter.annotations;
/* 160 */     if (annotations != null) {
/* 161 */       TypeVariableBinding binding = typeParameter.binding;
/* 162 */       if (binding == null) {
/* 163 */         return false;
/*     */       }
/* 165 */       resolveAnnotations((BlockScope)scope.referenceContext.initializerScope, annotations, (Binding)binding);
/*     */     } 
/* 167 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean visit(TypeParameter typeParameter, BlockScope scope) {
/* 172 */     Annotation[] annotations = typeParameter.annotations;
/* 173 */     if (annotations != null) {
/* 174 */       TypeVariableBinding binding = typeParameter.binding;
/* 175 */       if (binding == null) {
/* 176 */         return false;
/*     */       }
/*     */       
/* 179 */       MethodBinding methodBinding = (MethodBinding)binding.declaringElement;
/* 180 */       ((SourceTypeBinding)methodBinding.declaringClass).resolveTypesFor(methodBinding);
/* 181 */       resolveAnnotations(scope, annotations, (Binding)binding);
/*     */     } 
/* 183 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean visit(MethodDeclaration methodDeclaration, ClassScope scope) {
/* 188 */     Annotation[] annotations = methodDeclaration.annotations;
/* 189 */     if (annotations != null) {
/* 190 */       MethodBinding methodBinding = methodDeclaration.binding;
/* 191 */       if (methodBinding == null) {
/* 192 */         return false;
/*     */       }
/* 194 */       ((SourceTypeBinding)methodBinding.declaringClass).resolveTypesFor(methodBinding);
/* 195 */       resolveAnnotations(
/* 196 */           (BlockScope)methodDeclaration.scope, 
/* 197 */           annotations, 
/* 198 */           (Binding)methodBinding);
/*     */     } 
/*     */     
/* 201 */     TypeParameter[] typeParameters = methodDeclaration.typeParameters;
/* 202 */     if (typeParameters != null) {
/* 203 */       int typeParametersLength = typeParameters.length;
/* 204 */       for (int i = 0; i < typeParametersLength; i++) {
/* 205 */         typeParameters[i].traverse(this, (BlockScope)methodDeclaration.scope);
/*     */       }
/*     */     } 
/*     */     
/* 209 */     Argument[] arguments = methodDeclaration.arguments;
/* 210 */     if (arguments != null) {
/* 211 */       int argumentLength = arguments.length;
/* 212 */       for (int i = 0; i < argumentLength; i++) {
/* 213 */         arguments[i].traverse(this, (BlockScope)methodDeclaration.scope);
/*     */       }
/*     */     } 
/* 216 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean visit(TypeDeclaration memberTypeDeclaration, ClassScope scope) {
/* 221 */     SourceTypeBinding binding = memberTypeDeclaration.binding;
/* 222 */     if (binding == null) {
/* 223 */       return false;
/*     */     }
/* 225 */     Annotation[] annotations = memberTypeDeclaration.annotations;
/* 226 */     if (annotations != null) {
/* 227 */       resolveAnnotations(
/* 228 */           (BlockScope)memberTypeDeclaration.staticInitializerScope, 
/* 229 */           annotations, 
/* 230 */           (Binding)binding);
/*     */     }
/* 232 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean visit(TypeDeclaration typeDeclaration, CompilationUnitScope scope) {
/* 237 */     SourceTypeBinding binding = typeDeclaration.binding;
/* 238 */     if (binding == null) {
/* 239 */       return false;
/*     */     }
/* 241 */     Annotation[] annotations = typeDeclaration.annotations;
/* 242 */     if (annotations != null) {
/* 243 */       resolveAnnotations(
/* 244 */           (BlockScope)typeDeclaration.staticInitializerScope, 
/* 245 */           annotations, 
/* 246 */           (Binding)binding);
/*     */     }
/* 248 */     return true;
/*     */   }
/*     */   
/*     */   public boolean visit(ModuleDeclaration module, CompilationUnitScope scope) {
/* 252 */     SourceModuleBinding sourceModuleBinding = module.binding;
/* 253 */     if (sourceModuleBinding == null) {
/* 254 */       return false;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 259 */     Annotation[] annotations = module.annotations;
/* 260 */     if (annotations != null) {
/* 261 */       resolveAnnotations((BlockScope)module.scope, 
/* 262 */           annotations, 
/* 263 */           (Binding)sourceModuleBinding);
/*     */     }
/* 265 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   private void resolveAnnotations(BlockScope scope, Annotation[] annotations, Binding currentBinding) {
/* 270 */     int length = (annotations == null) ? 0 : annotations.length;
/* 271 */     if (length == 0) {
/*     */       return;
/*     */     }
/* 274 */     boolean old = scope.insideTypeAnnotation;
/* 275 */     scope.insideTypeAnnotation = true;
/* 276 */     currentBinding.getAnnotationTagBits();
/* 277 */     scope.insideTypeAnnotation = old;
/* 278 */     ElementImpl element = (ElementImpl)this._factory.newElement(currentBinding);
/* 279 */     AnnotationBinding[] annotationBindings = element.getPackedAnnotationBindings(); byte b; int i; AnnotationBinding[] arrayOfAnnotationBinding1;
/* 280 */     for (i = (arrayOfAnnotationBinding1 = annotationBindings).length, b = 0; b < i; ) { AnnotationBinding binding = arrayOfAnnotationBinding1[b];
/* 281 */       ReferenceBinding annotationType = binding.getAnnotationType();
/* 282 */       if (binding != null && 
/* 283 */         Annotation.isAnnotationTargetAllowed(scope, (TypeBinding)annotationType, currentBinding)) {
/*     */         
/* 285 */         TypeElement anno = (TypeElement)this._factory.newElement((Binding)annotationType);
/* 286 */         this._annoToElement.put(anno, element);
/*     */       } 
/*     */       b++; }
/*     */   
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\apt\dispatch\AnnotationDiscoveryVisitor.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */