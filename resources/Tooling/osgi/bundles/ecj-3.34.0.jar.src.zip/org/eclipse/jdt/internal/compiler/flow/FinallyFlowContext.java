/*     */ package org.eclipse.jdt.internal.compiler.flow;
/*     */ 
/*     */ import org.eclipse.jdt.internal.compiler.ast.ASTNode;
/*     */ import org.eclipse.jdt.internal.compiler.ast.Expression;
/*     */ import org.eclipse.jdt.internal.compiler.ast.NullAnnotationMatching;
/*     */ import org.eclipse.jdt.internal.compiler.ast.Reference;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.BlockScope;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.FieldBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.LocalVariableBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.Scope;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.TypeBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.VariableBinding;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FinallyFlowContext
/*     */   extends TryFlowContext
/*     */ {
/*     */   Reference[] finalAssignments;
/*     */   VariableBinding[] finalVariables;
/*     */   int assignCount;
/*     */   LocalVariableBinding[] nullLocals;
/*     */   ASTNode[] nullReferences;
/*     */   int[] nullCheckTypes;
/*     */   NullAnnotationMatching[] nullAnnotationStatuses;
/*     */   int nullCount;
/*     */   public FlowContext tryContext;
/*     */   
/*     */   public FinallyFlowContext(FlowContext parent, ASTNode associatedNode, ExceptionHandlingFlowContext tryContext) {
/*  64 */     super(parent, associatedNode);
/*  65 */     this.tryContext = tryContext;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void complainOnDeferredChecks(FlowInfo flowInfo, BlockScope scope) {
/*     */     int i;
/*  76 */     for (i = 0; i < this.assignCount; i++) {
/*  77 */       VariableBinding variable = this.finalVariables[i];
/*  78 */       if (variable != null) {
/*     */         
/*  80 */         boolean complained = false;
/*  81 */         if (variable instanceof FieldBinding) {
/*     */           
/*  83 */           if (flowInfo.isPotentiallyAssigned((FieldBinding)variable)) {
/*  84 */             complained = true;
/*  85 */             scope.problemReporter().duplicateInitializationOfBlankFinalField((FieldBinding)variable, this.finalAssignments[i]);
/*     */           }
/*     */         
/*     */         }
/*  89 */         else if (flowInfo.isPotentiallyAssigned((LocalVariableBinding)variable)) {
/*  90 */           variable.tagBits &= 0xFFFFFFFFFFFFF7FFL;
/*  91 */           if (variable.isFinal()) {
/*  92 */             complained = true;
/*  93 */             scope.problemReporter().duplicateInitializationOfFinalLocal(
/*  94 */                 (LocalVariableBinding)variable, 
/*  95 */                 (ASTNode)this.finalAssignments[i]);
/*     */           } 
/*     */         } 
/*     */ 
/*     */ 
/*     */         
/* 101 */         if (complained) {
/* 102 */           FlowContext currentContext = getLocalParent();
/* 103 */           while (currentContext != null) {
/*     */             
/* 105 */             currentContext.removeFinalAssignmentIfAny(this.finalAssignments[i]);
/*     */             
/* 107 */             currentContext = currentContext.getLocalParent();
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 113 */     if ((this.tagBits & 0x1) != 0) {
/* 114 */       for (i = 0; i < this.nullCount; i++) {
/* 115 */         int nullStatus; ASTNode location = this.nullReferences[i];
/* 116 */         switch (this.nullCheckTypes[i] & 0xFFFF0FFF) {
/*     */           case 128:
/* 118 */             nullStatus = flowInfo.nullStatus(this.nullLocals[i]);
/* 119 */             if (nullStatus != 4) {
/* 120 */               this.parent.recordNullityMismatch(scope, (Expression)location, 
/* 121 */                   this.providedExpectedTypes[i][0], this.providedExpectedTypes[i][1], flowInfo, nullStatus, null);
/*     */             }
/*     */             break;
/*     */           case 16:
/* 125 */             checkUnboxing((Scope)scope, (Expression)location, flowInfo);
/*     */             break;
/*     */           default:
/* 128 */             this.parent.recordUsingNullReference((Scope)scope, this.nullLocals[i], 
/* 129 */                 this.nullReferences[i], this.nullCheckTypes[i], flowInfo);
/*     */             break;
/*     */         } 
/*     */       
/*     */       } 
/*     */     } else {
/* 135 */       for (i = 0; i < this.nullCount; i++) {
/* 136 */         Expression expression; int nullStatus; ASTNode location = this.nullReferences[i];
/*     */         
/* 138 */         LocalVariableBinding local = this.nullLocals[i];
/* 139 */         switch (this.nullCheckTypes[i] & 0xFFFF0FFF) {
/*     */           case 256:
/*     */           case 512:
/* 142 */             if (flowInfo.isDefinitelyNonNull(local)) {
/* 143 */               if ((this.nullCheckTypes[i] & 0xFFFF0FFF) == 512) {
/* 144 */                 if ((this.nullCheckTypes[i] & 0x1000) == 0)
/* 145 */                   scope.problemReporter().localVariableRedundantCheckOnNonNull(local, location); 
/*     */                 break;
/*     */               } 
/* 148 */               scope.problemReporter().localVariableNonNullComparedToNull(local, location);
/*     */               break;
/*     */             } 
/*     */ 
/*     */           
/*     */           case 257:
/*     */           case 513:
/*     */           case 769:
/*     */           case 1025:
/* 157 */             expression = (Expression)location;
/* 158 */             if (flowInfo.isDefinitelyNull(local)) {
/* 159 */               switch (this.nullCheckTypes[i] & 0xFFFF0F00) {
/*     */                 case 256:
/* 161 */                   if ((this.nullCheckTypes[i] & 0xFF & 0xFFFF0FFF) == 1 && (expression.implicitConversion & 0x400) != 0) {
/* 162 */                     scope.problemReporter().localVariableNullReference(local, (ASTNode)expression);
/*     */                     break;
/*     */                   } 
/* 165 */                   if ((this.nullCheckTypes[i] & 0x1000) == 0) {
/* 166 */                     scope.problemReporter().localVariableRedundantCheckOnNull(local, (ASTNode)expression);
/*     */                   }
/*     */                   break;
/*     */                 case 512:
/* 170 */                   if ((this.nullCheckTypes[i] & 0xFF & 0xFFFF0FFF) == 1 && (expression.implicitConversion & 0x400) != 0) {
/* 171 */                     scope.problemReporter().localVariableNullReference(local, (ASTNode)expression);
/*     */                     break;
/*     */                   } 
/* 174 */                   scope.problemReporter().localVariableNullComparedToNonNull(local, (ASTNode)expression);
/*     */                   break;
/*     */                 case 768:
/* 177 */                   scope.problemReporter().localVariableRedundantNullAssignment(local, (ASTNode)expression);
/*     */                   break;
/*     */                 case 1024:
/* 180 */                   scope.problemReporter().localVariableNullInstanceof(local, (ASTNode)expression); break;
/*     */               }  break;
/*     */             } 
/* 183 */             if (flowInfo.isPotentiallyNull(local)) {
/* 184 */               switch (this.nullCheckTypes[i] & 0xFFFF0F00) {
/*     */                 case 256:
/* 186 */                   this.nullReferences[i] = null;
/* 187 */                   if ((this.nullCheckTypes[i] & 0xFF & 0xFFFF0FFF) == 1 && (expression.implicitConversion & 0x400) != 0) {
/* 188 */                     scope.problemReporter().localVariablePotentialNullReference(local, (ASTNode)expression);
/*     */                   }
/*     */                   break;
/*     */                 
/*     */                 case 512:
/* 193 */                   this.nullReferences[i] = null;
/* 194 */                   if ((this.nullCheckTypes[i] & 0xFF & 0xFFFF0FFF) == 1 && (expression.implicitConversion & 0x400) != 0) {
/* 195 */                     scope.problemReporter().localVariablePotentialNullReference(local, (ASTNode)expression);
/*     */                   }
/*     */                   break;
/*     */               } 
/*     */             
/*     */             }
/*     */             break;
/*     */           case 3:
/* 203 */             if (flowInfo.isDefinitelyNull(local)) {
/* 204 */               scope.problemReporter().localVariableNullReference(local, location);
/*     */               break;
/*     */             } 
/* 207 */             if (flowInfo.isPotentiallyNull(local)) {
/* 208 */               scope.problemReporter().localVariablePotentialNullReference(local, location);
/*     */             }
/*     */             break;
/*     */           case 128:
/* 212 */             nullStatus = flowInfo.nullStatus(local);
/* 213 */             if (nullStatus != 4) {
/* 214 */               char[][] annotationName = scope.environment().getNonNullAnnotationName();
/* 215 */               TypeBinding providedType = this.providedExpectedTypes[i][0];
/* 216 */               TypeBinding expectedType = this.providedExpectedTypes[i][1];
/* 217 */               Expression expression2 = (Expression)location;
/* 218 */               if (this.nullAnnotationStatuses[i] != null) {
/* 219 */                 this.nullAnnotationStatuses[i] = this.nullAnnotationStatuses[i].withNullStatus(nullStatus);
/* 220 */                 scope.problemReporter().nullityMismatchingTypeAnnotation(expression2, providedType, expectedType, this.nullAnnotationStatuses[i]); break;
/*     */               } 
/* 222 */               scope.problemReporter().nullityMismatch(expression2, providedType, expectedType, nullStatus, annotationName);
/*     */             } 
/*     */             break;
/*     */           
/*     */           case 16:
/* 227 */             checkUnboxing((Scope)scope, (Expression)location, flowInfo);
/*     */             break;
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String individualToString() {
/* 239 */     StringBuilder buffer = new StringBuilder("Finally flow context");
/* 240 */     buffer.append("[finalAssignments count - ").append(this.assignCount).append(']');
/* 241 */     buffer.append("[nullReferences count - ").append(this.nullCount).append(']');
/* 242 */     return buffer.toString();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isSubRoutine() {
/* 247 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean recordFinalAssignment(VariableBinding binding, Reference finalAssignment) {
/* 254 */     if (this.assignCount == 0) {
/* 255 */       this.finalAssignments = new Reference[5];
/* 256 */       this.finalVariables = new VariableBinding[5];
/*     */     } else {
/* 258 */       if (this.assignCount == this.finalAssignments.length)
/* 259 */         System.arraycopy(
/* 260 */             this.finalAssignments, 
/* 261 */             0, 
/* 262 */             this.finalAssignments = new Reference[this.assignCount * 2], 
/* 263 */             0, 
/* 264 */             this.assignCount); 
/* 265 */       System.arraycopy(
/* 266 */           this.finalVariables, 
/* 267 */           0, 
/* 268 */           this.finalVariables = new VariableBinding[this.assignCount * 2], 
/* 269 */           0, 
/* 270 */           this.assignCount);
/*     */     } 
/* 272 */     this.finalAssignments[this.assignCount] = finalAssignment;
/* 273 */     this.finalVariables[this.assignCount++] = binding;
/* 274 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void recordUsingNullReference(Scope scope, LocalVariableBinding local, ASTNode location, int checkType, FlowInfo flowInfo) {
/* 280 */     if ((flowInfo.tagBits & 0x3) == 0 && !flowInfo.isDefinitelyUnknown(local)) {
/*     */       
/* 282 */       checkType |= this.tagBits & 0x1000;
/* 283 */       int checkTypeWithoutHideNullWarning = checkType & 0xFFFF0FFF;
/* 284 */       if ((this.tagBits & 0x1) != 0) {
/* 285 */         Expression reference; switch (checkTypeWithoutHideNullWarning) {
/*     */           case 256:
/*     */           case 257:
/*     */           case 512:
/*     */           case 513:
/*     */           case 769:
/*     */           case 1025:
/* 292 */             reference = (Expression)location;
/* 293 */             if (flowInfo.cannotBeNull(local)) {
/* 294 */               if (checkTypeWithoutHideNullWarning == 512) {
/* 295 */                 if ((checkType & 0x1000) == 0) {
/* 296 */                   scope.problemReporter().localVariableRedundantCheckOnNonNull(local, (ASTNode)reference);
/*     */                 }
/* 298 */                 flowInfo.initsWhenFalse().setReachMode(2);
/* 299 */               } else if (checkTypeWithoutHideNullWarning == 256) {
/* 300 */                 scope.problemReporter().localVariableNonNullComparedToNull(local, (ASTNode)reference);
/* 301 */                 flowInfo.initsWhenTrue().setReachMode(2);
/*     */               } 
/*     */               return;
/*     */             } 
/* 305 */             if (flowInfo.canOnlyBeNull(local)) {
/* 306 */               switch (checkTypeWithoutHideNullWarning & 0xFFFF0F00) {
/*     */                 case 256:
/* 308 */                   if ((checkTypeWithoutHideNullWarning & 0xFF) == 1 && (reference.implicitConversion & 0x400) != 0) {
/* 309 */                     scope.problemReporter().localVariableNullReference(local, (ASTNode)reference);
/*     */                     return;
/*     */                   } 
/* 312 */                   if ((checkType & 0x1000) == 0) {
/* 313 */                     scope.problemReporter().localVariableRedundantCheckOnNull(local, (ASTNode)reference);
/*     */                   }
/* 315 */                   flowInfo.initsWhenFalse().setReachMode(2);
/*     */                   return;
/*     */                 case 512:
/* 318 */                   if ((checkTypeWithoutHideNullWarning & 0xFF) == 1 && (reference.implicitConversion & 0x400) != 0) {
/* 319 */                     scope.problemReporter().localVariableNullReference(local, (ASTNode)reference);
/*     */                     return;
/*     */                   } 
/* 322 */                   scope.problemReporter().localVariableNullComparedToNonNull(local, (ASTNode)reference);
/* 323 */                   flowInfo.initsWhenTrue().setReachMode(2);
/*     */                   return;
/*     */                 case 768:
/* 326 */                   scope.problemReporter().localVariableRedundantNullAssignment(local, (ASTNode)reference);
/*     */                   return;
/*     */                 case 1024:
/* 329 */                   scope.problemReporter().localVariableNullInstanceof(local, (ASTNode)reference); return;
/*     */               }  break;
/*     */             } 
/* 332 */             if (flowInfo.isPotentiallyNull(local)) {
/* 333 */               switch (checkTypeWithoutHideNullWarning & 0xFFFF0F00) {
/*     */                 case 256:
/* 335 */                   if ((checkTypeWithoutHideNullWarning & 0xFF) == 1 && (reference.implicitConversion & 0x400) != 0) {
/* 336 */                     scope.problemReporter().localVariablePotentialNullReference(local, (ASTNode)reference);
/*     */                     return;
/*     */                   } 
/*     */                   break;
/*     */                 case 512:
/* 341 */                   if ((checkTypeWithoutHideNullWarning & 0xFF) == 1 && (reference.implicitConversion & 0x400) != 0) {
/* 342 */                     scope.problemReporter().localVariablePotentialNullReference(local, (ASTNode)reference);
/*     */                     return;
/*     */                   } 
/*     */                   break;
/*     */               } 
/*     */             }
/*     */             break;
/*     */           case 3:
/* 350 */             if (flowInfo.cannotBeNull(local)) {
/*     */               return;
/*     */             }
/* 353 */             if (flowInfo.canOnlyBeNull(local)) {
/* 354 */               scope.problemReporter().localVariableNullReference(local, location);
/*     */               return;
/*     */             } 
/*     */             break;
/*     */         } 
/*     */ 
/*     */       
/*     */       } else {
/*     */         Expression reference;
/* 363 */         switch (checkTypeWithoutHideNullWarning) {
/*     */           case 256:
/*     */           case 512:
/* 366 */             if (flowInfo.isDefinitelyNonNull(local)) {
/* 367 */               if (checkTypeWithoutHideNullWarning == 512) {
/* 368 */                 if ((checkType & 0x1000) == 0) {
/* 369 */                   scope.problemReporter().localVariableRedundantCheckOnNonNull(local, location);
/*     */                 }
/* 371 */                 flowInfo.initsWhenFalse().setReachMode(2);
/*     */               } else {
/* 373 */                 scope.problemReporter().localVariableNonNullComparedToNull(local, location);
/* 374 */                 flowInfo.initsWhenTrue().setReachMode(2);
/*     */               } 
/*     */               return;
/*     */             } 
/*     */           
/*     */           case 257:
/*     */           case 513:
/*     */           case 769:
/*     */           case 1025:
/* 383 */             reference = (Expression)location;
/* 384 */             if (flowInfo.isDefinitelyNull(local)) {
/* 385 */               switch (checkTypeWithoutHideNullWarning & 0xFFFF0F00) {
/*     */                 case 256:
/* 387 */                   if ((checkTypeWithoutHideNullWarning & 0xFF) == 1 && (reference.implicitConversion & 0x400) != 0) {
/* 388 */                     scope.problemReporter().localVariableNullReference(local, (ASTNode)reference);
/*     */                     return;
/*     */                   } 
/* 391 */                   if ((checkType & 0x1000) == 0) {
/* 392 */                     scope.problemReporter().localVariableRedundantCheckOnNull(local, (ASTNode)reference);
/*     */                   }
/* 394 */                   flowInfo.initsWhenFalse().setReachMode(2);
/*     */                   return;
/*     */                 case 512:
/* 397 */                   if ((checkTypeWithoutHideNullWarning & 0xFF) == 1 && (reference.implicitConversion & 0x400) != 0) {
/* 398 */                     scope.problemReporter().localVariableNullReference(local, (ASTNode)reference);
/*     */                     return;
/*     */                   } 
/* 401 */                   scope.problemReporter().localVariableNullComparedToNonNull(local, (ASTNode)reference);
/* 402 */                   flowInfo.initsWhenTrue().setReachMode(2);
/*     */                   return;
/*     */                 case 768:
/* 405 */                   scope.problemReporter().localVariableRedundantNullAssignment(local, (ASTNode)reference);
/*     */                   return;
/*     */                 case 1024:
/* 408 */                   scope.problemReporter().localVariableNullInstanceof(local, (ASTNode)reference); return;
/*     */               }  break;
/*     */             } 
/* 411 */             if (flowInfo.isPotentiallyNull(local)) {
/* 412 */               switch (checkTypeWithoutHideNullWarning & 0xFFFF0F00) {
/*     */                 case 256:
/* 414 */                   if ((checkTypeWithoutHideNullWarning & 0xFF) == 1 && (reference.implicitConversion & 0x400) != 0) {
/* 415 */                     scope.problemReporter().localVariablePotentialNullReference(local, (ASTNode)reference);
/*     */                     return;
/*     */                   } 
/*     */                   break;
/*     */                 case 512:
/* 420 */                   if ((checkTypeWithoutHideNullWarning & 0xFF) == 1 && (reference.implicitConversion & 0x400) != 0) {
/* 421 */                     scope.problemReporter().localVariablePotentialNullReference(local, (ASTNode)reference);
/*     */                     return;
/*     */                   } 
/*     */                   break;
/*     */               } 
/*     */             }
/*     */             break;
/*     */           case 3:
/* 429 */             if (flowInfo.isDefinitelyNull(local)) {
/* 430 */               scope.problemReporter().localVariableNullReference(local, location);
/*     */               return;
/*     */             } 
/* 433 */             if (flowInfo.isPotentiallyNull(local)) {
/* 434 */               scope.problemReporter().localVariablePotentialNullReference(local, location);
/*     */               return;
/*     */             } 
/* 437 */             if (flowInfo.isDefinitelyNonNull(local)) {
/*     */               return;
/*     */             }
/*     */             break;
/*     */         } 
/*     */ 
/*     */       
/*     */       } 
/* 445 */       recordNullReference(local, location, checkType, flowInfo);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   void removeFinalAssignmentIfAny(Reference reference) {
/* 452 */     for (int i = 0; i < this.assignCount; i++) {
/* 453 */       if (this.finalAssignments[i] == reference) {
/* 454 */         this.finalAssignments[i] = null;
/* 455 */         this.finalVariables[i] = null;
/*     */         return;
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void recordNullReferenceWithAnnotationStatus(LocalVariableBinding local, ASTNode expression, int checkType, FlowInfo nullInfo, NullAnnotationMatching nullAnnotationStatus) {
/* 464 */     if (this.nullCount == 0) {
/* 465 */       this.nullLocals = new LocalVariableBinding[5];
/* 466 */       this.nullReferences = new ASTNode[5];
/* 467 */       this.nullCheckTypes = new int[5];
/* 468 */       this.nullAnnotationStatuses = new NullAnnotationMatching[5];
/*     */     }
/* 470 */     else if (this.nullCount == this.nullLocals.length) {
/* 471 */       int newLength = this.nullCount * 2;
/* 472 */       System.arraycopy(this.nullLocals, 0, 
/* 473 */           this.nullLocals = new LocalVariableBinding[newLength], 0, 
/* 474 */           this.nullCount);
/* 475 */       System.arraycopy(this.nullReferences, 0, 
/* 476 */           this.nullReferences = new ASTNode[newLength], 0, 
/* 477 */           this.nullCount);
/* 478 */       System.arraycopy(this.nullCheckTypes, 0, 
/* 479 */           this.nullCheckTypes = new int[newLength], 0, 
/* 480 */           this.nullCount);
/* 481 */       System.arraycopy(this.nullAnnotationStatuses, 0, 
/* 482 */           this.nullAnnotationStatuses = new NullAnnotationMatching[this.nullCount * 2], 0, 
/* 483 */           this.nullCount);
/*     */     } 
/* 485 */     this.nullLocals[this.nullCount] = local;
/* 486 */     this.nullReferences[this.nullCount] = expression;
/* 487 */     this.nullAnnotationStatuses[this.nullCount] = nullAnnotationStatus;
/* 488 */     this.nullCheckTypes[this.nullCount++] = checkType;
/*     */   }
/*     */   
/*     */   public void recordUnboxing(Scope scope, Expression expression, int nullStatus, FlowInfo flowInfo) {
/* 492 */     if (nullStatus == 2) {
/* 493 */       super.recordUnboxing(scope, expression, nullStatus, flowInfo);
/*     */     } else {
/* 495 */       recordNullReference(null, (ASTNode)expression, 16, flowInfo);
/*     */     } 
/*     */   }
/*     */   
/*     */   protected boolean internalRecordNullityMismatch(Expression expression, TypeBinding providedType, FlowInfo flowInfo, int nullStatus, NullAnnotationMatching nullAnnotationStatus, TypeBinding expectedType, int checkType) {
/* 500 */     if (nullStatus == 1 || ((
/* 501 */       this.tagBits & 0x1) != 0 && nullStatus != 2)) {
/* 502 */       recordProvidedExpectedTypes(providedType, expectedType, this.nullCount);
/* 503 */       recordNullReferenceWithAnnotationStatus(expression.localVariableBinding(), (ASTNode)expression, checkType, flowInfo, nullAnnotationStatus);
/* 504 */       return true;
/*     */     } 
/* 506 */     return false;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\flow\FinallyFlowContext.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */