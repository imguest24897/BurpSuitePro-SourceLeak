/*     */ package org.eclipse.jdt.internal.compiler.env;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.function.Consumer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class UpdatesByKind
/*     */ {
/* 128 */   List<Consumer<IUpdatableModule>> moduleUpdates = Collections.emptyList();
/* 129 */   List<Consumer<IUpdatableModule>> packageUpdates = Collections.emptyList();
/*     */   public List<Consumer<IUpdatableModule>> getList(IUpdatableModule.UpdateKind kind, boolean create) {
/* 131 */     switch (kind) {
/*     */       case null:
/* 133 */         if (this.moduleUpdates == Collections.EMPTY_LIST && create)
/* 134 */           this.moduleUpdates = new ArrayList<>(); 
/* 135 */         return this.moduleUpdates;
/*     */       case PACKAGE:
/* 137 */         if (this.packageUpdates == Collections.EMPTY_LIST && create)
/* 138 */           this.packageUpdates = new ArrayList<>(); 
/* 139 */         return this.packageUpdates;
/*     */     } 
/* 141 */     throw new IllegalArgumentException("Unknown enum value " + kind);
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 146 */     StringBuilder result = new StringBuilder();
/* 147 */     for (Consumer<IUpdatableModule> consumer : this.moduleUpdates) {
/* 148 */       if (result.length() > 0)
/* 149 */         result.append("\n"); 
/* 150 */       result.append(consumer);
/*     */     } 
/* 152 */     for (Consumer<IUpdatableModule> consumer : this.packageUpdates) {
/* 153 */       if (result.length() > 0)
/* 154 */         result.append("\n"); 
/* 155 */       result.append(consumer);
/*     */     } 
/* 157 */     return result.toString();
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\env\IUpdatableModule$UpdatesByKind.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */