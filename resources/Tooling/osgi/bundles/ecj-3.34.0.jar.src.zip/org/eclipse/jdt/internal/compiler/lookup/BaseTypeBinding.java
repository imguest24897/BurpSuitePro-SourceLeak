/*     */ package org.eclipse.jdt.internal.compiler.lookup;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BaseTypeBinding
/*     */   extends TypeBinding
/*     */ {
/*  29 */   public static final int[] CONVERSIONS = initializeConversions();
/*     */   
/*     */   public static final int IDENTITY = 1;
/*     */   public static final int WIDENING = 2;
/*     */   public static final int NARROWING = 4;
/*     */   
/*     */   public static final int[] initializeConversions() {
/*  36 */     int[] table = new int[256];
/*     */     
/*  38 */     table[85] = 1;
/*     */     
/*  40 */     table[51] = 1;
/*  41 */     table[67] = 2;
/*  42 */     table[35] = 4;
/*  43 */     table[163] = 2;
/*  44 */     table[115] = 2;
/*  45 */     table[147] = 2;
/*  46 */     table[131] = 2;
/*     */     
/*  48 */     table[52] = 4;
/*  49 */     table[68] = 1;
/*  50 */     table[36] = 4;
/*  51 */     table[164] = 2;
/*  52 */     table[116] = 2;
/*  53 */     table[148] = 2;
/*  54 */     table[132] = 2;
/*     */     
/*  56 */     table[50] = 4;
/*  57 */     table[66] = 4;
/*  58 */     table[34] = 1;
/*  59 */     table[162] = 2;
/*  60 */     table[114] = 2;
/*  61 */     table[146] = 2;
/*  62 */     table[130] = 2;
/*     */     
/*  64 */     table[58] = 4;
/*  65 */     table[74] = 4;
/*  66 */     table[42] = 4;
/*  67 */     table[170] = 1;
/*  68 */     table[122] = 2;
/*  69 */     table[154] = 2;
/*  70 */     table[138] = 2;
/*     */     
/*  72 */     table[55] = 4;
/*  73 */     table[71] = 4;
/*  74 */     table[39] = 4;
/*  75 */     table[167] = 4;
/*  76 */     table[119] = 1;
/*  77 */     table[151] = 2;
/*  78 */     table[135] = 2;
/*     */     
/*  80 */     table[57] = 4;
/*  81 */     table[73] = 4;
/*  82 */     table[41] = 4;
/*  83 */     table[169] = 4;
/*  84 */     table[121] = 4;
/*  85 */     table[153] = 1;
/*  86 */     table[137] = 2;
/*     */     
/*  88 */     table[56] = 4;
/*  89 */     table[72] = 4;
/*  90 */     table[40] = 4;
/*  91 */     table[168] = 4;
/*  92 */     table[120] = 4;
/*  93 */     table[152] = 4;
/*  94 */     table[136] = 1;
/*     */     
/*  96 */     return table;
/*     */   }
/*     */ 
/*     */   
/*     */   public static final int MAX_CONVERSIONS = 256;
/*     */   
/*     */   public char[] simpleName;
/*     */   private char[] constantPoolName;
/*     */   
/*     */   public static final boolean isNarrowing(int left, int right) {
/* 106 */     int right2left = right + (left << 4);
/* 107 */     return (right2left >= 0 && 
/* 108 */       right2left < 256 && (
/* 109 */       CONVERSIONS[right2left] & 0x5) != 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final boolean isWidening(int left, int right) {
/* 120 */     int right2left = right + (left << 4);
/* 121 */     return (right2left >= 0 && 
/* 122 */       right2left < 256 && (
/* 123 */       CONVERSIONS[right2left] & 0x3) != 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   BaseTypeBinding(int id, char[] name, char[] constantPoolName) {
/* 131 */     this.tagBits |= 0x2L;
/* 132 */     this.id = id;
/* 133 */     this.simpleName = name;
/* 134 */     this.constantPoolName = constantPoolName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public char[] computeUniqueKey(boolean isLeaf) {
/* 142 */     return constantPoolName();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public char[] constantPoolName() {
/* 150 */     return this.constantPoolName;
/*     */   }
/*     */ 
/*     */   
/*     */   public TypeBinding clone(TypeBinding enclosingType) {
/* 155 */     return new BaseTypeBinding(this.id, this.simpleName, this.constantPoolName);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public PackageBinding getPackage() {
/* 161 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final boolean isCompatibleWith(TypeBinding right, Scope captureScope) {
/* 168 */     if (equalsEquals(this, right))
/* 169 */       return true; 
/* 170 */     int right2left = this.id + (right.id << 4);
/* 171 */     if (right2left >= 0 && 
/* 172 */       right2left < 256 && (
/* 173 */       CONVERSIONS[right2left] & 0x3) != 0)
/* 174 */       return true; 
/* 175 */     return (this == TypeBinding.NULL && !right.isBaseType());
/*     */   }
/*     */ 
/*     */   
/*     */   public void setTypeAnnotations(AnnotationBinding[] annotations, boolean evalNullAnnotations) {
/* 180 */     super.setTypeAnnotations(annotations, false);
/*     */   }
/*     */ 
/*     */   
/*     */   public TypeBinding unannotated() {
/* 185 */     if (!hasTypeAnnotations())
/* 186 */       return this; 
/* 187 */     switch (this.id) {
/*     */       case 5:
/* 189 */         return TypeBinding.BOOLEAN;
/*     */       case 3:
/* 191 */         return TypeBinding.BYTE;
/*     */       case 2:
/* 193 */         return TypeBinding.CHAR;
/*     */       case 8:
/* 195 */         return TypeBinding.DOUBLE;
/*     */       case 9:
/* 197 */         return TypeBinding.FLOAT;
/*     */       case 10:
/* 199 */         return TypeBinding.INT;
/*     */       case 7:
/* 201 */         return TypeBinding.LONG;
/*     */       case 4:
/* 203 */         return TypeBinding.SHORT;
/*     */     } 
/* 205 */     throw new IllegalStateException();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isUncheckedException(boolean includeSupertype) {
/* 214 */     return (this == TypeBinding.NULL);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int kind() {
/* 222 */     return 132;
/*     */   }
/*     */   
/*     */   public char[] qualifiedSourceName() {
/* 226 */     return this.simpleName;
/*     */   }
/*     */ 
/*     */   
/*     */   public char[] readableName() {
/* 231 */     return this.simpleName;
/*     */   }
/*     */ 
/*     */   
/*     */   public char[] shortReadableName() {
/* 236 */     return this.simpleName;
/*     */   }
/*     */ 
/*     */   
/*     */   public char[] sourceName() {
/* 241 */     return this.simpleName;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 246 */     return hasTypeAnnotations() ? annotatedDebugName() : new String(readableName());
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\lookup\BaseTypeBinding.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */