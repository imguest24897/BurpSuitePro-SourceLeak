package org.eclipse.jdt.internal.compiler.ast;

import org.eclipse.jdt.internal.compiler.lookup.InferenceContext18;
import org.eclipse.jdt.internal.compiler.lookup.InvocationSite;
import org.eclipse.jdt.internal.compiler.lookup.MethodBinding;
import org.eclipse.jdt.internal.compiler.lookup.ParameterizedGenericMethodBinding;
import org.eclipse.jdt.internal.compiler.lookup.ParameterizedMethodBinding;
import org.eclipse.jdt.internal.compiler.lookup.TypeBinding;

public interface Invocation extends InvocationSite {
  Expression[] arguments();
  
  MethodBinding binding();
  
  void registerInferenceContext(ParameterizedGenericMethodBinding paramParameterizedGenericMethodBinding, InferenceContext18 paramInferenceContext18);
  
  InferenceContext18 getInferenceContext(ParameterizedMethodBinding paramParameterizedMethodBinding);
  
  void cleanUpInferenceContexts();
  
  void registerResult(TypeBinding paramTypeBinding, MethodBinding paramMethodBinding);
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\ast\Invocation.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */