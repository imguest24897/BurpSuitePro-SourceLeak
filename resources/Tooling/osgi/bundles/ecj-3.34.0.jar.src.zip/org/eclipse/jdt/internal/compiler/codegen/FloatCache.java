/*     */ package org.eclipse.jdt.internal.compiler.codegen;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FloatCache
/*     */ {
/*     */   private float[] keyTable;
/*     */   private int[] valueTable;
/*     */   private int elementSize;
/*     */   
/*     */   public FloatCache() {
/*  26 */     this(13);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public FloatCache(int initialCapacity) {
/*  35 */     this.elementSize = 0;
/*  36 */     this.keyTable = new float[initialCapacity];
/*  37 */     this.valueTable = new int[initialCapacity];
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void clear() {
/*  43 */     for (int i = this.keyTable.length; --i >= 0; ) {
/*  44 */       this.keyTable[i] = 0.0F;
/*  45 */       this.valueTable[i] = 0;
/*     */     } 
/*  47 */     this.elementSize = 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean containsKey(float key) {
/*  55 */     if (key == 0.0F) {
/*  56 */       for (int i = 0, max = this.elementSize; i < max; i++) {
/*  57 */         if (this.keyTable[i] == 0.0F) {
/*  58 */           int value1 = Float.floatToIntBits(key);
/*  59 */           int value2 = Float.floatToIntBits(this.keyTable[i]);
/*  60 */           if (value1 == Integer.MIN_VALUE && value2 == Integer.MIN_VALUE)
/*  61 */             return true; 
/*  62 */           if (value1 == 0 && value2 == 0)
/*  63 */             return true; 
/*     */         } 
/*     */       } 
/*     */     } else {
/*  67 */       for (int i = 0, max = this.elementSize; i < max; i++) {
/*  68 */         if (this.keyTable[i] == key) {
/*  69 */           return true;
/*     */         }
/*     */       } 
/*     */     } 
/*  73 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int put(float key, int value) {
/*  84 */     if (this.elementSize == this.keyTable.length) {
/*     */       
/*  86 */       System.arraycopy(this.keyTable, 0, this.keyTable = new float[this.elementSize * 2], 0, this.elementSize);
/*  87 */       System.arraycopy(this.valueTable, 0, this.valueTable = new int[this.elementSize * 2], 0, this.elementSize);
/*     */     } 
/*  89 */     this.keyTable[this.elementSize] = key;
/*  90 */     this.valueTable[this.elementSize] = value;
/*  91 */     this.elementSize++;
/*  92 */     return value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int putIfAbsent(float key, int value) {
/* 103 */     if (key == 0.0F) {
/* 104 */       for (int i = 0, max = this.elementSize; i < max; i++) {
/* 105 */         if (this.keyTable[i] == 0.0F) {
/* 106 */           int value1 = Float.floatToIntBits(key);
/* 107 */           int value2 = Float.floatToIntBits(this.keyTable[i]);
/* 108 */           if (value1 == Integer.MIN_VALUE && value2 == Integer.MIN_VALUE)
/* 109 */             return this.valueTable[i]; 
/* 110 */           if (value1 == 0 && value2 == 0)
/* 111 */             return this.valueTable[i]; 
/*     */         } 
/*     */       } 
/*     */     } else {
/* 115 */       for (int i = 0, max = this.elementSize; i < max; i++) {
/* 116 */         if (this.keyTable[i] == key) {
/* 117 */           return this.valueTable[i];
/*     */         }
/*     */       } 
/*     */     } 
/* 121 */     if (this.elementSize == this.keyTable.length) {
/*     */       
/* 123 */       System.arraycopy(this.keyTable, 0, this.keyTable = new float[this.elementSize * 2], 0, this.elementSize);
/* 124 */       System.arraycopy(this.valueTable, 0, this.valueTable = new int[this.elementSize * 2], 0, this.elementSize);
/*     */     } 
/* 126 */     this.keyTable[this.elementSize] = key;
/* 127 */     this.valueTable[this.elementSize] = value;
/* 128 */     this.elementSize++;
/* 129 */     return -value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 138 */     int max = this.elementSize;
/* 139 */     StringBuilder buf = new StringBuilder();
/* 140 */     buf.append("{");
/* 141 */     for (int i = 0; i < max; i++) {
/* 142 */       if (this.keyTable[i] != 0.0F || (this.keyTable[i] == 0.0F && this.valueTable[i] != 0)) {
/* 143 */         buf.append(this.keyTable[i]).append("->").append(this.valueTable[i]);
/*     */       }
/* 145 */       if (i < max) {
/* 146 */         buf.append(", ");
/*     */       }
/*     */     } 
/* 149 */     buf.append("}");
/* 150 */     return buf.toString();
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\codegen\FloatCache.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */