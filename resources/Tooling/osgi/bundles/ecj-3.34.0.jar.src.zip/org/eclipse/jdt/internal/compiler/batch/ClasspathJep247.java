/*     */ package org.eclipse.jdt.internal.compiler.batch;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.nio.file.FileSystem;
/*     */ import java.nio.file.FileVisitResult;
/*     */ import java.nio.file.FileVisitor;
/*     */ import java.nio.file.Files;
/*     */ import java.nio.file.Path;
/*     */ import java.nio.file.attribute.BasicFileAttributes;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import org.eclipse.jdt.core.compiler.CharOperation;
/*     */ import org.eclipse.jdt.internal.compiler.classfmt.ClassFileReader;
/*     */ import org.eclipse.jdt.internal.compiler.classfmt.ClassFormatException;
/*     */ import org.eclipse.jdt.internal.compiler.env.AccessRuleSet;
/*     */ import org.eclipse.jdt.internal.compiler.env.IBinaryModule;
/*     */ import org.eclipse.jdt.internal.compiler.env.IBinaryType;
/*     */ import org.eclipse.jdt.internal.compiler.env.IModule;
/*     */ import org.eclipse.jdt.internal.compiler.env.NameEnvironmentAnswer;
/*     */ import org.eclipse.jdt.internal.compiler.impl.CompilerOptions;
/*     */ import org.eclipse.jdt.internal.compiler.util.CtSym;
/*     */ import org.eclipse.jdt.internal.compiler.util.JRTUtil;
/*     */ import org.eclipse.jdt.internal.compiler.util.Util;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ClasspathJep247
/*     */   extends ClasspathJrt
/*     */ {
/*     */   protected FileSystem fs;
/*  47 */   protected String compliance = null;
/*     */   protected long jdklevel;
/*  49 */   protected String releaseInHex = null;
/*  50 */   protected String[] subReleases = null;
/*  51 */   protected Path releasePath = null;
/*     */   protected Set<String> packageCache;
/*     */   protected File jdkHome;
/*  54 */   protected String modulePath = null;
/*     */   
/*     */   public ClasspathJep247(File jdkHome, String release, AccessRuleSet accessRuleSet) {
/*  57 */     super(jdkHome, false, accessRuleSet, (String)null);
/*  58 */     this.compliance = release;
/*  59 */     this.jdklevel = CompilerOptions.releaseToJDKLevel(this.compliance);
/*  60 */     this.jdkHome = jdkHome;
/*  61 */     this.file = new File(new File(jdkHome, "lib"), "jrt-fs.jar");
/*     */   }
/*     */   
/*     */   public List<FileSystem.Classpath> fetchLinkedJars(FileSystem.ClasspathSectionProblemReporter problemReporter) {
/*  65 */     return null;
/*     */   }
/*     */   
/*     */   public NameEnvironmentAnswer findClass(char[] typeName, String qualifiedPackageName, String moduleName, String qualifiedBinaryFileName) {
/*  69 */     return findClass(typeName, qualifiedPackageName, moduleName, qualifiedBinaryFileName, false);
/*     */   }
/*     */   
/*     */   public NameEnvironmentAnswer findClass(char[] typeName, String qualifiedPackageName, String moduleName, String qualifiedBinaryFileName, boolean asBinaryOnly) {
/*  73 */     if (!isPackage(qualifiedPackageName, moduleName)) {
/*  74 */       return null;
/*     */     }
/*     */     
/*     */     try {
/*  78 */       IBinaryType reader = null;
/*  79 */       byte[] content = null;
/*  80 */       qualifiedBinaryFileName = qualifiedBinaryFileName.replace(".class", ".sig");
/*  81 */       Path p = null;
/*  82 */       if (this.subReleases != null && this.subReleases.length > 0) {
/*  83 */         byte b; int i; String[] arrayOfString; for (i = (arrayOfString = this.subReleases).length, b = 0; b < i; ) { String rel = arrayOfString[b];
/*  84 */           p = this.fs.getPath(rel, new String[] { qualifiedBinaryFileName });
/*  85 */           if (Files.exists(p, new java.nio.file.LinkOption[0])) {
/*  86 */             content = JRTUtil.safeReadBytes(p);
/*  87 */             if (content != null)
/*     */               break; 
/*     */           }  b++; }
/*     */       
/*     */       } else {
/*  92 */         p = this.fs.getPath(this.releaseInHex, new String[] { qualifiedBinaryFileName });
/*  93 */         content = JRTUtil.safeReadBytes(p);
/*     */       } 
/*  95 */       if (content != null) {
/*  96 */         ClassFileReader classFileReader = new ClassFileReader(p.toUri(), content, qualifiedBinaryFileName.toCharArray());
/*  97 */         IBinaryType iBinaryType = maybeDecorateForExternalAnnotations(qualifiedBinaryFileName, (IBinaryType)classFileReader);
/*  98 */         char[] modName = (moduleName != null) ? moduleName.toCharArray() : null;
/*  99 */         return new NameEnvironmentAnswer(iBinaryType, fetchAccessRestriction(qualifiedBinaryFileName), modName);
/*     */       } 
/* 101 */     } catch (ClassFormatException|IOException classFormatException) {}
/*     */ 
/*     */     
/* 104 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public void initialize() throws IOException {
/* 109 */     if (this.compliance == null) {
/*     */       return;
/*     */     }
/* 112 */     this.releaseInHex = CtSym.getReleaseCode(this.compliance);
/* 113 */     Path filePath = this.jdkHome.toPath().resolve("lib").resolve("ct.sym");
/* 114 */     if (!Files.exists(filePath, new java.nio.file.LinkOption[0])) {
/*     */       return;
/*     */     }
/* 117 */     this.fs = JRTUtil.getJarFileSystem(filePath);
/* 118 */     this.releasePath = this.fs.getPath("/", new String[0]);
/* 119 */     if (!Files.exists(this.fs.getPath(this.releaseInHex, new String[0]), new java.nio.file.LinkOption[0])) {
/* 120 */       throw new IllegalArgumentException("release " + this.compliance + " is not found in the system");
/*     */     }
/* 122 */     super.initialize();
/*     */   }
/*     */ 
/*     */   
/*     */   public void loadModules() {
/* 127 */     if (this.jdklevel <= 3407872L) {
/* 128 */       super.loadModules();
/*     */       return;
/*     */     } 
/* 131 */     Path modPath = this.fs.getPath(String.valueOf(this.releaseInHex) + "-modules", new String[0]);
/* 132 */     if (!Files.exists(modPath, new java.nio.file.LinkOption[0])) {
/* 133 */       throw new IllegalArgumentException("release " + this.compliance + " is not found in the system");
/*     */     }
/* 135 */     this.modulePath = String.valueOf(this.file.getPath()) + "|" + modPath.toString();
/* 136 */     Map<String, IModule> cache = ModulesCache.computeIfAbsent(this.modulePath, key -> {
/*     */           Map<String, IModule> newCache = new HashMap<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/*     */           try {
/*     */             Exception exception2;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */             
/*     */             Exception exception1 = null;
/* 176 */           } catch (IOException e) {
/*     */             String error = "Failed to walk modules for " + key;
/*     */             
/*     */             if (JRTUtil.PROPAGATE_IO_ERRORS) {
/*     */               throw new IllegalStateException(error, e);
/*     */             }
/*     */             
/*     */             System.err.println(error);
/*     */             e.printStackTrace();
/*     */             return null;
/*     */           } 
/*     */           return newCache.isEmpty() ? null : Collections.<String, IModule>unmodifiableMap(newCache);
/*     */         });
/* 189 */     this.moduleNamesCache.addAll(cache.keySet());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   void acceptModule(ClassFileReader reader, Map<String, IModule> cache) {
/* 195 */     if (this.jdklevel <= 3407872L) {
/* 196 */       super.acceptModule(reader, cache);
/*     */       return;
/*     */     } 
/* 199 */     if (reader != null) {
/* 200 */       IBinaryModule iBinaryModule = reader.getModuleDeclaration();
/* 201 */       if (iBinaryModule != null)
/* 202 */         cache.put(String.valueOf(iBinaryModule.name()), iBinaryModule); 
/*     */     } 
/*     */   }
/*     */   
/*     */   protected void addToPackageCache(String packageName, boolean endsWithSep) {
/* 207 */     if (this.packageCache.contains(packageName))
/*     */       return; 
/* 209 */     this.packageCache.add(packageName);
/*     */   }
/*     */   
/*     */   public synchronized char[][] getModulesDeclaringPackage(String qualifiedPackageName, String moduleName) {
/* 213 */     if (this.packageCache == null) {
/* 214 */       this.packageCache = new HashSet<>(41);
/* 215 */       this.packageCache.add(Util.EMPTY_STRING);
/* 216 */       List<String> sub = new ArrayList<>(); try {
/* 217 */         Exception exception2, exception1 = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       }
/* 251 */       catch (IOException e) {
/* 252 */         String error = "Failed to find module " + moduleName + " defining package " + qualifiedPackageName + 
/* 253 */           " in release " + this.releasePath + " in " + this;
/* 254 */         if (JRTUtil.PROPAGATE_IO_ERRORS) {
/* 255 */           throw new IllegalStateException(error, e);
/*     */         }
/* 257 */         System.err.println(error);
/* 258 */         e.printStackTrace();
/*     */       } 
/*     */       
/* 261 */       this.subReleases = sub.<String>toArray(new String[sub.size()]);
/*     */     } 
/* 263 */     if (moduleName == null) {
/*     */       
/* 265 */       List<String> mods = JRTUtil.getModulesDeclaringPackage(this.file, qualifiedPackageName, moduleName);
/* 266 */       return CharOperation.toCharArrays(mods);
/*     */     } 
/* 268 */     return singletonModuleNameIf(this.packageCache.contains(qualifiedPackageName));
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 273 */     return "Classpath for JEP 247 for JDK " + this.file.getPath();
/*     */   }
/*     */   
/*     */   public char[] normalizedPath() {
/* 277 */     if (this.normalizedPath == null) {
/* 278 */       String path2 = getPath();
/* 279 */       char[] rawName = path2.toCharArray();
/* 280 */       if (File.separatorChar == '\\') {
/* 281 */         CharOperation.replace(rawName, '\\', '/');
/*     */       }
/* 283 */       this.normalizedPath = CharOperation.subarray(rawName, 0, CharOperation.lastIndexOf('.', rawName));
/*     */     } 
/* 285 */     return this.normalizedPath;
/*     */   }
/*     */   
/*     */   public String getPath() {
/* 289 */     if (this.path == null) {
/*     */       try {
/* 291 */         this.path = this.file.getCanonicalPath();
/* 292 */       } catch (IOException iOException) {
/*     */         
/* 294 */         this.path = this.file.getAbsolutePath();
/*     */       } 
/*     */     }
/* 297 */     return this.path;
/*     */   }
/*     */   
/*     */   public int getMode() {
/* 301 */     return 2;
/*     */   }
/*     */   
/*     */   public boolean forbidsExportFrom(String modName) {
/* 305 */     return servesModule(modName.toCharArray());
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\batch\ClasspathJep247.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */