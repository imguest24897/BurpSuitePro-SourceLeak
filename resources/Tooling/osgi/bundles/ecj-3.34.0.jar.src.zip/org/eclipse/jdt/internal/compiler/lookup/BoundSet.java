/*      */ package org.eclipse.jdt.internal.compiler.lookup;
/*      */ 
/*      */ import java.util.ArrayList;
/*      */ import java.util.Arrays;
/*      */ import java.util.Collection;
/*      */ import java.util.HashMap;
/*      */ import java.util.Iterator;
/*      */ import java.util.LinkedHashMap;
/*      */ import java.util.LinkedHashSet;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.Set;
/*      */ import java.util.function.Function;
/*      */ import java.util.stream.Collectors;
/*      */ import java.util.stream.Stream;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ class BoundSet
/*      */ {
/*      */   public static boolean enableOptimizationForBug543480 = true;
/*      */   
/*      */   static {
/*   49 */     String enableOptimizationForBug543480Property = System.getProperty("enableOptimizationForBug543480");
/*   50 */     if (enableOptimizationForBug543480Property != null) {
/*   51 */       enableOptimizationForBug543480 = enableOptimizationForBug543480Property.equalsIgnoreCase("true");
/*      */     }
/*      */   }
/*      */   
/*   55 */   static final BoundSet TRUE = new BoundSet();
/*   56 */   static final BoundSet FALSE = new BoundSet();
/*      */ 
/*      */   
/*      */   private static class ThreeSets
/*      */   {
/*      */     Set<TypeBound> superBounds;
/*      */     
/*      */     Set<TypeBound> sameBounds;
/*      */     
/*      */     Set<TypeBound> subBounds;
/*      */     
/*      */     TypeBinding instantiation;
/*      */     
/*      */     Map<InferenceVariable, TypeBound> inverseBounds;
/*      */     
/*      */     Set<InferenceVariable> dependencies;
/*      */ 
/*      */     
/*      */     public boolean addBound(TypeBound bound) {
/*   75 */       boolean result = addBound1(bound);
/*   76 */       if (result) {
/*   77 */         Set<InferenceVariable> set = (this.dependencies == null) ? new LinkedHashSet<>() : this.dependencies;
/*   78 */         bound.right.collectInferenceVariables(set);
/*   79 */         if (this.dependencies == null && set.size() > 0) {
/*   80 */           this.dependencies = set;
/*      */         }
/*      */       } 
/*   83 */       return result;
/*      */     }
/*      */     private boolean addBound1(TypeBound bound) {
/*   86 */       switch (bound.relation) {
/*      */         case 3:
/*   88 */           if (this.superBounds == null) this.superBounds = new LinkedHashSet<>(); 
/*   89 */           return this.superBounds.add(bound);
/*      */         case 4:
/*   91 */           if (this.sameBounds == null) this.sameBounds = new LinkedHashSet<>(); 
/*   92 */           return this.sameBounds.add(bound);
/*      */         case 2:
/*   94 */           if (this.subBounds == null) this.subBounds = new LinkedHashSet<>(); 
/*   95 */           return this.subBounds.add(bound);
/*      */       } 
/*   97 */       throw new IllegalArgumentException("Unexpected bound relation in : " + bound);
/*      */     }
/*      */ 
/*      */     
/*      */     public TypeBinding[] lowerBounds(boolean onlyProper, InferenceVariable variable) {
/*  102 */       TypeBinding[] boundTypes = new TypeBinding[this.superBounds.size()];
/*  103 */       Iterator<TypeBound> it = this.superBounds.iterator();
/*  104 */       long nullHints = variable.nullHints;
/*  105 */       int i = 0;
/*  106 */       while (it.hasNext()) {
/*  107 */         TypeBound current = it.next();
/*  108 */         TypeBinding boundType = current.right;
/*  109 */         if (!onlyProper || boundType.isProperType(true)) {
/*  110 */           boundTypes[i++] = boundType;
/*  111 */           nullHints |= current.nullHints;
/*      */         } 
/*      */       } 
/*  114 */       if (i == 0)
/*  115 */         return Binding.NO_TYPES; 
/*  116 */       if (i < boundTypes.length)
/*  117 */         System.arraycopy(boundTypes, 0, boundTypes = new TypeBinding[i], 0, i); 
/*  118 */       useNullHints(nullHints, boundTypes, variable.environment);
/*  119 */       InferenceContext18.sortTypes(boundTypes);
/*  120 */       return boundTypes;
/*      */     }
/*      */     
/*      */     public TypeBinding[] upperBounds(boolean onlyProper, InferenceVariable variable) {
/*  124 */       TypeBinding[] rights = new TypeBinding[this.subBounds.size()];
/*  125 */       TypeBinding simpleUpper = null;
/*  126 */       Iterator<TypeBound> it = this.subBounds.iterator();
/*  127 */       long nullHints = variable.nullHints;
/*  128 */       int i = 0;
/*  129 */       while (it.hasNext()) {
/*  130 */         TypeBinding right = ((TypeBound)it.next()).right;
/*  131 */         if (!onlyProper || right.isProperType(true)) {
/*  132 */           if (right instanceof ReferenceBinding) {
/*  133 */             rights[i++] = right;
/*  134 */             nullHints |= right.tagBits & 0x180000000000000L; continue;
/*      */           } 
/*  136 */           if (simpleUpper != null)
/*  137 */             return Binding.NO_TYPES; 
/*  138 */           simpleUpper = right;
/*      */         } 
/*      */       } 
/*      */       
/*  142 */       if (i == 0) {
/*  143 */         (new TypeBinding[1])[0] = simpleUpper; return (simpleUpper != null) ? new TypeBinding[1] : Binding.NO_TYPES;
/*  144 */       }  if (i == 1 && simpleUpper != null)
/*  145 */         return new TypeBinding[] { simpleUpper }; 
/*  146 */       if (i < rights.length)
/*  147 */         System.arraycopy(rights, 0, rights = new TypeBinding[i], 0, i); 
/*  148 */       useNullHints(nullHints, rights, variable.environment);
/*  149 */       InferenceContext18.sortTypes(rights);
/*  150 */       return rights;
/*      */     }
/*      */     
/*      */     public boolean hasDependency(InferenceVariable beta) {
/*  154 */       if (this.dependencies != null && this.dependencies.contains(beta))
/*  155 */         return true; 
/*  156 */       if (this.inverseBounds != null && 
/*  157 */         this.inverseBounds.containsKey(beta))
/*      */       {
/*  159 */         return true;
/*      */       }
/*      */       
/*  162 */       return false;
/*      */     }
/*      */     
/*      */     public int size() {
/*  166 */       int size = 0;
/*  167 */       if (this.superBounds != null)
/*  168 */         size += this.superBounds.size(); 
/*  169 */       if (this.sameBounds != null)
/*  170 */         size += this.sameBounds.size(); 
/*  171 */       if (this.subBounds != null)
/*  172 */         size += this.subBounds.size(); 
/*  173 */       return size;
/*      */     }
/*      */     public int flattenInto(TypeBound[] collected, int idx) {
/*  176 */       if (this.superBounds != null) {
/*  177 */         int len = this.superBounds.size();
/*  178 */         System.arraycopy(this.superBounds.toArray(), 0, collected, idx, len);
/*  179 */         idx += len;
/*      */       } 
/*  181 */       if (this.sameBounds != null) {
/*  182 */         int len = this.sameBounds.size();
/*  183 */         System.arraycopy(this.sameBounds.toArray(), 0, collected, idx, len);
/*  184 */         idx += len;
/*      */       } 
/*  186 */       if (this.subBounds != null) {
/*  187 */         int len = this.subBounds.size();
/*  188 */         System.arraycopy(this.subBounds.toArray(), 0, collected, idx, len);
/*  189 */         idx += len;
/*      */       } 
/*  191 */       return idx;
/*      */     }
/*      */     public ThreeSets copy() {
/*  194 */       ThreeSets copy = new ThreeSets();
/*  195 */       if (this.superBounds != null)
/*  196 */         copy.superBounds = new LinkedHashSet<>(this.superBounds); 
/*  197 */       if (this.sameBounds != null)
/*  198 */         copy.sameBounds = new LinkedHashSet<>(this.sameBounds); 
/*  199 */       if (this.subBounds != null)
/*  200 */         copy.subBounds = new LinkedHashSet<>(this.subBounds); 
/*  201 */       copy.instantiation = this.instantiation;
/*  202 */       if (this.dependencies != null) {
/*  203 */         copy.dependencies = new LinkedHashSet<>(this.dependencies);
/*      */       }
/*  205 */       return copy;
/*      */     }
/*      */     public TypeBinding findSingleWrapperType() {
/*  208 */       if (this.instantiation != null && 
/*  209 */         this.instantiation.isProperType(true)) {
/*  210 */         switch (this.instantiation.id) {
/*      */           case 26:
/*      */           case 27:
/*      */           case 28:
/*      */           case 29:
/*      */           case 30:
/*      */           case 31:
/*      */           case 32:
/*      */           case 33:
/*  219 */             return this.instantiation;
/*      */         } 
/*      */       
/*      */       }
/*  223 */       if (this.subBounds != null) {
/*  224 */         Iterator<TypeBound> it = this.subBounds.iterator();
/*  225 */         while (it.hasNext()) {
/*  226 */           TypeBinding boundType = ((TypeBound)it.next()).right;
/*  227 */           if (boundType.isProperType(true)) {
/*  228 */             switch (boundType.id) {
/*      */               case 26:
/*      */               case 27:
/*      */               case 28:
/*      */               case 29:
/*      */               case 30:
/*      */               case 31:
/*      */               case 32:
/*      */               case 33:
/*  237 */                 return boundType;
/*      */             } 
/*      */           }
/*      */         } 
/*      */       } 
/*  242 */       if (this.superBounds != null) {
/*  243 */         Iterator<TypeBound> it = this.superBounds.iterator();
/*  244 */         while (it.hasNext()) {
/*  245 */           TypeBinding boundType = ((TypeBound)it.next()).right;
/*  246 */           if (boundType.isProperType(true)) {
/*  247 */             switch (boundType.id) {
/*      */               case 26:
/*      */               case 27:
/*      */               case 28:
/*      */               case 29:
/*      */               case 30:
/*      */               case 31:
/*      */               case 32:
/*      */               case 33:
/*  256 */                 return boundType;
/*      */             } 
/*      */           }
/*      */         } 
/*      */       } 
/*  261 */       return null;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private void useNullHints(long nullHints, TypeBinding[] boundTypes, LookupEnvironment environment) {
/*  270 */       if (nullHints == 108086391056891904L) {
/*      */         
/*  272 */         for (int i = 0; i < boundTypes.length; i++)
/*  273 */           boundTypes[i] = boundTypes[i].withoutToplevelNullAnnotation(); 
/*      */       } else {
/*  275 */         AnnotationBinding[] annot = environment.nullAnnotationsFromTagBits(nullHints);
/*  276 */         if (annot != null)
/*      */         {
/*  278 */           for (int i = 0; i < boundTypes.length; i++) {
/*  279 */             boundTypes[i] = environment.createAnnotatedType(boundTypes[i], annot);
/*      */           }
/*      */         }
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     TypeBinding combineAndUseNullHints(TypeBinding type, long nullHints, LookupEnvironment environment) {
/*  287 */       if (this.sameBounds != null) {
/*  288 */         Iterator<TypeBound> it = this.sameBounds.iterator();
/*  289 */         while (it.hasNext())
/*  290 */           nullHints |= ((TypeBound)it.next()).nullHints; 
/*      */       } 
/*  292 */       if (this.superBounds != null) {
/*  293 */         Iterator<TypeBound> it = this.superBounds.iterator();
/*  294 */         while (it.hasNext())
/*  295 */           nullHints |= ((TypeBound)it.next()).nullHints; 
/*      */       } 
/*  297 */       if (this.subBounds != null) {
/*  298 */         Iterator<TypeBound> it = this.subBounds.iterator();
/*  299 */         while (it.hasNext())
/*  300 */           nullHints |= ((TypeBound)it.next()).nullHints; 
/*      */       } 
/*  302 */       if (nullHints == 108086391056891904L)
/*  303 */         return type.withoutToplevelNullAnnotation(); 
/*  304 */       AnnotationBinding[] annot = environment.nullAnnotationsFromTagBits(nullHints);
/*  305 */       if (annot != null)
/*      */       {
/*  307 */         return environment.createAnnotatedType(type, annot); } 
/*  308 */       return type;
/*      */     }
/*      */     public void setInstantiation(TypeBinding type, InferenceVariable variable, LookupEnvironment environment) {
/*  311 */       if (environment.globalOptions.isAnnotationBasedNullAnalysisEnabled) {
/*  312 */         long variableBits = variable.tagBits & 0x180000000000000L;
/*  313 */         long allBits = type.tagBits | variableBits;
/*  314 */         if (this.instantiation != null)
/*  315 */           allBits |= this.instantiation.tagBits; 
/*  316 */         allBits &= 0x180000000000000L;
/*  317 */         if (allBits == 108086391056891904L) {
/*  318 */           allBits = variableBits;
/*      */         }
/*  320 */         if (allBits != (type.tagBits & 0x180000000000000L)) {
/*  321 */           AnnotationBinding[] annot = environment.nullAnnotationsFromTagBits(allBits);
/*  322 */           if (annot != null) {
/*  323 */             type = environment.createAnnotatedType(type.withoutToplevelNullAnnotation(), annot);
/*  324 */           } else if (type.hasNullTypeAnnotations()) {
/*  325 */             type = type.withoutToplevelNullAnnotation();
/*      */           } 
/*      */         } 
/*  328 */       }  this.instantiation = type;
/*      */     }
/*      */   }
/*      */   
/*  332 */   HashMap<InferenceVariable, ThreeSets> boundsPerVariable = new LinkedHashMap<>();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  338 */   HashMap<ParameterizedTypeBinding, ParameterizedTypeBinding> captures = new LinkedHashMap<>();
/*      */   
/*  340 */   Set<InferenceVariable> inThrows = new LinkedHashSet<>();
/*      */   
/*  342 */   private TypeBound[] incorporatedBounds = Binding.NO_TYPE_BOUNDS;
/*  343 */   private TypeBound[] unincorporatedBounds = new TypeBound[8];
/*  344 */   private int unincorporatedBoundsCount = 0;
/*  345 */   private TypeBound[] mostRecentBounds = new TypeBound[4];
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void addBoundsFromTypeParameters(InferenceContext18 context, TypeVariableBinding[] typeParameters, InferenceVariable[] variables) {
/*  351 */     int length = typeParameters.length;
/*  352 */     for (int i = 0; i < length; i++) {
/*  353 */       TypeVariableBinding typeParameter = typeParameters[i];
/*  354 */       InferenceVariable variable = variables[i];
/*  355 */       TypeBound[] someBounds = typeParameter.getTypeBounds(variable, new InferenceSubstitution(context));
/*  356 */       boolean hasProperBound = false;
/*  357 */       if (someBounds.length > 0)
/*  358 */         hasProperBound = addBounds(someBounds, context.environment); 
/*  359 */       if (!hasProperBound) {
/*  360 */         addBound(new TypeBound(variable, context.object, 2), context.environment);
/*      */       }
/*      */     } 
/*      */   }
/*      */   
/*      */   public TypeBound[] flatten() {
/*  366 */     int size = 0;
/*  367 */     Iterator<ThreeSets> outerIt = this.boundsPerVariable.values().iterator();
/*  368 */     while (outerIt.hasNext())
/*  369 */       size += ((ThreeSets)outerIt.next()).size(); 
/*  370 */     if (size == 0) return Binding.NO_TYPE_BOUNDS; 
/*  371 */     TypeBound[] collected = new TypeBound[size];
/*  372 */     outerIt = this.boundsPerVariable.values().iterator();
/*  373 */     int idx = 0;
/*  374 */     while (outerIt.hasNext())
/*  375 */       idx = ((ThreeSets)outerIt.next()).flattenInto(collected, idx); 
/*  376 */     return collected;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public BoundSet copy() {
/*  384 */     BoundSet copy = new BoundSet();
/*  385 */     if (!this.boundsPerVariable.isEmpty()) {
/*  386 */       Iterator<Map.Entry<InferenceVariable, ThreeSets>> setsIterator = this.boundsPerVariable.entrySet().iterator();
/*  387 */       while (setsIterator.hasNext()) {
/*  388 */         Map.Entry<InferenceVariable, ThreeSets> entry = setsIterator.next();
/*  389 */         copy.boundsPerVariable.put(entry.getKey(), ((ThreeSets)entry.getValue()).copy());
/*      */       } 
/*      */     } 
/*  392 */     copy.inThrows.addAll(this.inThrows);
/*  393 */     copy.captures.putAll(this.captures);
/*  394 */     if (this.incorporatedBounds.length > 0)
/*  395 */       System.arraycopy(this.incorporatedBounds, 0, copy.incorporatedBounds = new TypeBound[this.incorporatedBounds.length], 0, this.incorporatedBounds.length); 
/*  396 */     if (this.unincorporatedBoundsCount > 0)
/*  397 */       System.arraycopy(this.unincorporatedBounds, 0, copy.unincorporatedBounds = new TypeBound[this.unincorporatedBounds.length], 0, this.unincorporatedBounds.length); 
/*  398 */     copy.unincorporatedBoundsCount = this.unincorporatedBoundsCount;
/*  399 */     return copy;
/*      */   }
/*      */ 
/*      */   
/*      */   public void addBound(TypeBound bound, LookupEnvironment environment) {
/*  404 */     if (bound.relation == 2 && bound.right.id == 1)
/*      */       return; 
/*  406 */     if (bound.left == bound.right)
/*      */       return; 
/*  408 */     for (int recent = 0; recent < 4; recent++) {
/*  409 */       if (bound.equals(this.mostRecentBounds[recent])) {
/*  410 */         if (environment.globalOptions.isAnnotationBasedNullAnalysisEnabled) {
/*  411 */           TypeBound existing = this.mostRecentBounds[recent];
/*  412 */           long boundNullBits = bound.right.tagBits & 0x180000000000000L;
/*  413 */           long existingNullBits = existing.right.tagBits & 0x180000000000000L;
/*  414 */           if (boundNullBits != existingNullBits) {
/*  415 */             if (existingNullBits == 0L) {
/*  416 */               existing.right = bound.right;
/*  417 */             } else if (boundNullBits != 0L) {
/*  418 */               existing.right = environment.createAnnotatedType(existing.right, environment.nullAnnotationsFromTagBits(boundNullBits));
/*      */             } 
/*      */           }
/*      */         } 
/*      */         return;
/*      */       } 
/*      */     } 
/*  425 */     this.mostRecentBounds[3] = this.mostRecentBounds[2];
/*  426 */     this.mostRecentBounds[2] = this.mostRecentBounds[1];
/*  427 */     this.mostRecentBounds[1] = this.mostRecentBounds[0];
/*  428 */     this.mostRecentBounds[0] = bound;
/*      */     
/*  430 */     InferenceVariable variable = bound.left.prototype();
/*  431 */     ThreeSets three = this.boundsPerVariable.get(variable);
/*  432 */     if (three == null)
/*  433 */       this.boundsPerVariable.put(variable, three = new ThreeSets()); 
/*  434 */     if (three.addBound(bound)) {
/*  435 */       int unincorporatedBoundsLength = this.unincorporatedBounds.length;
/*  436 */       if (this.unincorporatedBoundsCount >= unincorporatedBoundsLength)
/*  437 */         System.arraycopy(this.unincorporatedBounds, 0, this.unincorporatedBounds = new TypeBound[unincorporatedBoundsLength * 2], 0, unincorporatedBoundsLength); 
/*  438 */       this.unincorporatedBounds[this.unincorporatedBoundsCount++] = bound;
/*      */       
/*  440 */       TypeBinding typeBinding = bound.right;
/*  441 */       if (bound.relation == 4 && typeBinding.isProperType(true))
/*  442 */         three.setInstantiation(typeBinding, variable, environment); 
/*  443 */       if (bound.right instanceof InferenceVariable) {
/*      */ 
/*      */ 
/*      */         
/*  447 */         InferenceVariable rightIV = (InferenceVariable)bound.right.prototype();
/*  448 */         three = this.boundsPerVariable.get(rightIV);
/*  449 */         if (three == null)
/*  450 */           this.boundsPerVariable.put(rightIV, three = new ThreeSets()); 
/*  451 */         if (three.inverseBounds == null)
/*  452 */           three.inverseBounds = new HashMap<>(); 
/*  453 */         three.inverseBounds.put(rightIV, bound);
/*      */       } 
/*      */     } 
/*      */   }
/*      */   
/*      */   private boolean addBounds(TypeBound[] newBounds, LookupEnvironment environment) {
/*  459 */     boolean hasProperBound = false;
/*  460 */     for (int i = 0; i < newBounds.length; i++) {
/*  461 */       addBound(newBounds[i], environment);
/*  462 */       hasProperBound |= newBounds[i].isBound();
/*      */     } 
/*  464 */     return hasProperBound;
/*      */   }
/*      */   
/*      */   public void addBounds(BoundSet that, LookupEnvironment environment) {
/*  468 */     if (that == null || environment == null)
/*      */       return; 
/*  470 */     addBounds(that.flatten(), environment);
/*      */   }
/*      */   
/*      */   public boolean isInstantiated(InferenceVariable inferenceVariable) {
/*  474 */     ThreeSets three = this.boundsPerVariable.get(inferenceVariable.prototype());
/*  475 */     if (three != null)
/*  476 */       return (three.instantiation != null); 
/*  477 */     return false;
/*      */   }
/*      */   
/*      */   public TypeBinding getInstantiation(InferenceVariable inferenceVariable, LookupEnvironment environment) {
/*  481 */     ThreeSets three = this.boundsPerVariable.get(inferenceVariable.prototype());
/*  482 */     if (three != null) {
/*  483 */       TypeBinding instantiation = three.instantiation;
/*  484 */       if (environment != null && environment.globalOptions.isAnnotationBasedNullAnalysisEnabled && 
/*  485 */         instantiation != null && (instantiation.tagBits & 0x180000000000000L) == 0L)
/*  486 */         return three.combineAndUseNullHints(instantiation, inferenceVariable.nullHints, environment); 
/*  487 */       return instantiation;
/*      */     } 
/*  489 */     return null;
/*      */   }
/*      */   
/*      */   public int numUninstantiatedVariables(InferenceVariable[] variables) {
/*  493 */     int num = 0;
/*  494 */     for (int i = 0; i < variables.length; i++) {
/*  495 */       if (!isInstantiated(variables[i]))
/*  496 */         num++; 
/*      */     } 
/*  498 */     return num;
/*      */   }
/*      */ 
/*      */   
/*      */   boolean incorporate(InferenceContext18 context) throws InferenceFailureException {
/*  503 */     if (this.unincorporatedBoundsCount == 0 && this.captures.isEmpty()) {
/*  504 */       return true;
/*      */     }
/*      */     do {
/*      */       TypeBound[] freshBounds;
/*  508 */       System.arraycopy(this.unincorporatedBounds, 0, freshBounds = new TypeBound[this.unincorporatedBoundsCount], 0, this.unincorporatedBoundsCount);
/*  509 */       this.unincorporatedBoundsCount = 0;
/*      */ 
/*      */       
/*  512 */       if (!incorporate(context, this.incorporatedBounds, freshBounds)) {
/*  513 */         return false;
/*      */       }
/*  515 */       if (!incorporate(context, freshBounds, freshBounds)) {
/*  516 */         return false;
/*      */       }
/*      */       
/*  519 */       int incorporatedLength = this.incorporatedBounds.length;
/*  520 */       int unincorporatedLength = freshBounds.length;
/*  521 */       TypeBound[] aggregate = new TypeBound[incorporatedLength + unincorporatedLength];
/*  522 */       System.arraycopy(this.incorporatedBounds, 0, aggregate, 0, incorporatedLength);
/*  523 */       System.arraycopy(freshBounds, 0, aggregate, incorporatedLength, unincorporatedLength);
/*  524 */       this.incorporatedBounds = aggregate;
/*      */     }
/*  526 */     while (this.unincorporatedBoundsCount > 0);
/*      */     
/*  528 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   boolean incorporate(InferenceContext18 context, TypeBound[] first, TypeBound[] next) throws InferenceFailureException {
/*  539 */     boolean analyzeNull = context.environment.globalOptions.isAnnotationBasedNullAnalysisEnabled;
/*  540 */     ConstraintTypeFormula[] mostRecentFormulas = new ConstraintTypeFormula[4];
/*      */     
/*  542 */     for (int i = 0, iLength = first.length; i < iLength; i++) {
/*  543 */       TypeBound boundI = first[i];
/*  544 */       for (int j = 0, jLength = next.length; j < jLength; j++) {
/*  545 */         TypeBound boundJ = next[j];
/*  546 */         if (boundI != boundJ) {
/*      */           
/*  548 */           int iteration = 1;
/*      */           do {
/*  550 */             ConstraintTypeFormula newConstraint = null;
/*  551 */             boolean deriveTypeArgumentConstraints = false;
/*  552 */             if (iteration == 2) {
/*  553 */               TypeBound typeBound = boundI;
/*  554 */               boundI = boundJ;
/*  555 */               boundJ = typeBound;
/*      */             } 
/*  557 */             switch (boundI.relation) {
/*      */               case 4:
/*  559 */                 switch (boundJ.relation) {
/*      */                   case 4:
/*  561 */                     newConstraint = combineSameSame(boundI, boundJ, first, next);
/*      */                     break;
/*      */                   case 2:
/*      */                   case 3:
/*  565 */                     newConstraint = combineSameSubSuper(boundI, boundJ, first, next);
/*      */                     break;
/*      */                 } 
/*      */                 break;
/*      */               case 2:
/*  570 */                 switch (boundJ.relation) {
/*      */                   case 4:
/*  572 */                     newConstraint = combineSameSubSuper(boundJ, boundI, first, next);
/*      */                     break;
/*      */                   case 3:
/*  575 */                     newConstraint = combineSuperAndSub(boundJ, boundI);
/*      */                     break;
/*      */                   case 2:
/*  578 */                     newConstraint = combineEqualSupers(boundI, boundJ);
/*  579 */                     deriveTypeArgumentConstraints = TypeBinding.equalsEquals(boundI.left, boundJ.left);
/*      */                     break;
/*      */                 } 
/*      */                 break;
/*      */               case 3:
/*  584 */                 switch (boundJ.relation) {
/*      */                   case 4:
/*  586 */                     newConstraint = combineSameSubSuper(boundJ, boundI, first, next);
/*      */                     break;
/*      */                   case 2:
/*  589 */                     newConstraint = combineSuperAndSub(boundI, boundJ);
/*      */                     break;
/*      */                   case 3:
/*  592 */                     newConstraint = combineEqualSupers(boundI, boundJ); break;
/*      */                 } 
/*      */                 break;
/*      */             } 
/*  596 */             if (newConstraint != null) {
/*  597 */               if (newConstraint.left == newConstraint.right) {
/*  598 */                 newConstraint = null;
/*  599 */               } else if (newConstraint.equalsEquals(mostRecentFormulas[0]) || newConstraint.equalsEquals(mostRecentFormulas[1]) || 
/*  600 */                 newConstraint.equalsEquals(mostRecentFormulas[2]) || newConstraint.equalsEquals(mostRecentFormulas[3])) {
/*  601 */                 newConstraint = null;
/*      */               } 
/*      */             }
/*  604 */             if (newConstraint != null) {
/*      */               
/*  606 */               mostRecentFormulas[3] = mostRecentFormulas[2];
/*  607 */               mostRecentFormulas[2] = mostRecentFormulas[1];
/*  608 */               mostRecentFormulas[1] = mostRecentFormulas[0];
/*  609 */               mostRecentFormulas[0] = newConstraint;
/*      */               
/*  611 */               if (!reduceOneConstraint(context, newConstraint)) {
/*  612 */                 return false;
/*      */               }
/*  614 */               if (analyzeNull) {
/*      */ 
/*      */                 
/*  617 */                 long nullHints = (newConstraint.left.tagBits | newConstraint.right.tagBits) & 0x180000000000000L;
/*  618 */                 if (nullHints != 0L && (
/*  619 */                   TypeBinding.equalsEquals(boundI.left, boundJ.left) || (
/*  620 */                   boundI.relation == 4 && TypeBinding.equalsEquals(boundI.right, boundJ.left)) || (
/*  621 */                   boundJ.relation == 4 && TypeBinding.equalsEquals(boundI.left, boundJ.right)))) {
/*  622 */                   boundI.nullHints |= nullHints;
/*  623 */                   boundJ.nullHints |= nullHints;
/*      */                 } 
/*      */               } 
/*      */             } 
/*      */             
/*  628 */             ConstraintTypeFormula[] arrayOfConstraintTypeFormula = deriveTypeArgumentConstraints ? deriveTypeArgumentConstraints(boundI, boundJ) : null;
/*  629 */             if (arrayOfConstraintTypeFormula != null)
/*  630 */               for (int k = 0, length = arrayOfConstraintTypeFormula.length; k < length; k++) {
/*  631 */                 if (!reduceOneConstraint(context, arrayOfConstraintTypeFormula[k])) {
/*  632 */                   return false;
/*      */                 }
/*      */               }  
/*  635 */             if (iteration != 2)
/*  636 */               continue;  TypeBound boundX = boundI;
/*  637 */             boundI = boundJ;
/*  638 */             boundJ = boundX;
/*      */           }
/*  640 */           while (first != next && ++iteration <= 2);
/*      */         } 
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  647 */     Iterator<Map.Entry<ParameterizedTypeBinding, ParameterizedTypeBinding>> captIter = this.captures.entrySet().iterator();
/*  648 */     while (captIter.hasNext()) {
/*  649 */       Map.Entry<ParameterizedTypeBinding, ParameterizedTypeBinding> capt = captIter.next();
/*  650 */       ParameterizedTypeBinding gAlpha = capt.getKey();
/*  651 */       ParameterizedTypeBinding gA = capt.getValue();
/*  652 */       ReferenceBinding g = (ReferenceBinding)gA.original();
/*  653 */       final TypeVariableBinding[] parameters = g.typeVariables();
/*      */       
/*  655 */       InferenceVariable[] alphas = new InferenceVariable[gAlpha.arguments.length];
/*  656 */       System.arraycopy(gAlpha.arguments, 0, alphas, 0, alphas.length);
/*  657 */       InferenceSubstitution theta = new InferenceSubstitution(context.environment, alphas, context.currentInvocation)
/*      */         {
/*      */           protected TypeBinding getP(int i) {
/*  660 */             return parameters[i];
/*      */           }
/*      */         };
/*  663 */       for (int j = 0, length = parameters.length; j < length; j++) {
/*      */         
/*  665 */         TypeVariableBinding pi = parameters[j];
/*  666 */         InferenceVariable alpha = (InferenceVariable)gAlpha.arguments[j];
/*  667 */         addBounds(pi.getTypeBounds(alpha, theta), context.environment);
/*      */         
/*  669 */         TypeBinding ai = gA.arguments[j];
/*  670 */         if (ai instanceof WildcardBinding) {
/*  671 */           WildcardBinding wildcardBinding = (WildcardBinding)ai;
/*  672 */           TypeBinding t = wildcardBinding.bound;
/*  673 */           ThreeSets three = this.boundsPerVariable.get(alpha.prototype());
/*  674 */           if (three != null) {
/*      */             
/*  676 */             if (three.sameBounds != null) {
/*      */               
/*  678 */               Iterator<TypeBound> it = three.sameBounds.iterator();
/*  679 */               while (it.hasNext()) {
/*  680 */                 TypeBound bound = it.next();
/*  681 */                 if (!(bound.right instanceof InferenceVariable))
/*  682 */                   return false; 
/*      */               } 
/*      */             } 
/*  685 */             if (three.subBounds != null) {
/*  686 */               TypeBinding bi1 = pi.firstBound;
/*  687 */               if (bi1 == null) {
/*  688 */                 bi1 = context.object;
/*      */               }
/*      */ 
/*      */               
/*  692 */               Iterator<TypeBound> it = three.subBounds.iterator();
/*  693 */               while (it.hasNext()) {
/*  694 */                 TypeBound bound = it.next();
/*  695 */                 if (!(bound.right instanceof InferenceVariable)) {
/*  696 */                   TypeBinding bi, r = bound.right;
/*  697 */                   ReferenceBinding[] otherBounds = pi.superInterfaces;
/*      */                   
/*  699 */                   if (otherBounds == Binding.NO_SUPERINTERFACES) {
/*  700 */                     bi = bi1;
/*      */                   } else {
/*  702 */                     int n = otherBounds.length + 1;
/*  703 */                     ReferenceBinding[] allBounds = new ReferenceBinding[n];
/*  704 */                     allBounds[0] = (ReferenceBinding)bi1;
/*  705 */                     System.arraycopy(otherBounds, 0, allBounds, 1, n - 1);
/*  706 */                     bi = context.environment.createIntersectionType18(allBounds);
/*      */                   } 
/*  708 */                   addTypeBoundsFromWildcardBound(context, theta, wildcardBinding.boundKind, t, r, bi);
/*      */                 } 
/*      */               } 
/*      */             } 
/*  712 */             if (three.superBounds != null) {
/*      */ 
/*      */               
/*  715 */               Iterator<TypeBound> it = three.superBounds.iterator();
/*  716 */               while (it.hasNext()) {
/*  717 */                 TypeBound bound = it.next();
/*  718 */                 if (!(bound.right instanceof InferenceVariable)) {
/*  719 */                   if (wildcardBinding.boundKind == 2) {
/*  720 */                     reduceOneConstraint(context, ConstraintTypeFormula.create(bound.right, t, 2)); continue;
/*      */                   } 
/*  722 */                   return false;
/*      */                 } 
/*      */               } 
/*      */             } 
/*      */           } 
/*      */         } else {
/*  728 */           addBound(new TypeBound(alpha, ai, 4), context.environment);
/*      */         } 
/*      */       } 
/*      */     } 
/*  732 */     this.captures.clear();
/*  733 */     return true;
/*      */   }
/*      */ 
/*      */   
/*      */   void addTypeBoundsFromWildcardBound(InferenceContext18 context, InferenceSubstitution theta, int boundKind, TypeBinding t, TypeBinding r, TypeBinding bi) throws InferenceFailureException {
/*  738 */     ConstraintFormula formula = null;
/*  739 */     if (boundKind == 1) {
/*  740 */       if (bi.id == 1)
/*  741 */         formula = ConstraintTypeFormula.create(t, r, 2); 
/*  742 */       if (t.id == 1)
/*  743 */         formula = ConstraintTypeFormula.create(theta.substitute(theta, bi), r, 2); 
/*      */     } else {
/*  745 */       formula = ConstraintTypeFormula.create(theta.substitute(theta, bi), r, 2);
/*      */     } 
/*  747 */     if (formula != null) {
/*  748 */       reduceOneConstraint(context, formula);
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   private ConstraintTypeFormula combineSameSame(TypeBound boundS, TypeBound boundT, TypeBound[] firstBounds, TypeBound[] nextBounds) {
/*  754 */     if (TypeBinding.equalsEquals(boundS.left, boundT.left)) {
/*  755 */       return ConstraintTypeFormula.create(boundS.right, boundT.right, 4, !(!boundS.isSoft && !boundT.isSoft));
/*      */     }
/*      */ 
/*      */     
/*  759 */     ConstraintTypeFormula newConstraint = combineSameSameWithProperType(boundS, boundT, firstBounds, nextBounds);
/*  760 */     if (newConstraint != null)
/*  761 */       return newConstraint; 
/*  762 */     newConstraint = combineSameSameWithProperType(boundT, boundS, firstBounds, nextBounds);
/*  763 */     if (newConstraint != null)
/*  764 */       return newConstraint; 
/*  765 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private ConstraintTypeFormula combineSameSameWithProperType(TypeBound boundLeft, TypeBound boundRight, TypeBound[] firstBounds, TypeBound[] nextBounds) {
/*  772 */     TypeBinding u = boundLeft.right;
/*  773 */     if (enableOptimizationForBug543480 && isParameterizedDependency(boundRight))
/*      */     {
/*      */       
/*  776 */       return incorporateIntoParameterizedDependencyIfAllArgumentsAreProperTypes(boundRight, 
/*  777 */           firstBounds, nextBounds);
/*      */     }
/*  779 */     if (u.isProperType(true)) {
/*  780 */       InferenceVariable alpha = boundLeft.left;
/*  781 */       TypeBinding left = boundRight.left;
/*  782 */       TypeBinding right = boundRight.right.substituteInferenceVariable(alpha, u);
/*  783 */       return ConstraintTypeFormula.create(left, right, 4, !(!boundLeft.isSoft && !boundRight.isSoft));
/*      */     } 
/*  785 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private ConstraintTypeFormula combineSameSubSuper(TypeBound boundS, TypeBound boundT, TypeBound[] firstBounds, TypeBound[] nextBounds) {
/*  791 */     InferenceVariable alpha = boundS.left;
/*  792 */     TypeBinding s = boundS.right;
/*  793 */     if (TypeBinding.equalsEquals(alpha, boundT.left)) {
/*  794 */       TypeBinding t = boundT.right;
/*  795 */       return ConstraintTypeFormula.create(s, t, boundT.relation, !(!boundT.isSoft && !boundS.isSoft));
/*      */     } 
/*  797 */     if (TypeBinding.equalsEquals(alpha, boundT.right)) {
/*  798 */       TypeBinding t = boundT.left;
/*  799 */       return ConstraintTypeFormula.create(t, s, boundT.relation, !(!boundT.isSoft && !boundS.isSoft));
/*      */     } 
/*      */     
/*  802 */     if (boundS.right instanceof InferenceVariable) {
/*      */       
/*  804 */       alpha = (InferenceVariable)boundS.right;
/*  805 */       s = boundS.left;
/*  806 */       if (TypeBinding.equalsEquals(alpha, boundT.left)) {
/*  807 */         TypeBinding t = boundT.right;
/*  808 */         return ConstraintTypeFormula.create(s, t, boundT.relation, !(!boundT.isSoft && !boundS.isSoft));
/*      */       } 
/*  810 */       if (TypeBinding.equalsEquals(alpha, boundT.right)) {
/*  811 */         TypeBinding t = boundT.left;
/*  812 */         return ConstraintTypeFormula.create(t, s, boundT.relation, !(!boundT.isSoft && !boundS.isSoft));
/*      */       } 
/*      */     } 
/*  815 */     return combineSameSubSuperWithProperType(boundS, boundT, alpha, firstBounds, nextBounds);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private ConstraintTypeFormula combineSameSubSuperWithProperType(TypeBound boundLeft, TypeBound boundRight, InferenceVariable alpha, TypeBound[] firstBounds, TypeBound[] nextBounds) {
/*  823 */     TypeBinding u = boundLeft.right;
/*      */     
/*  825 */     if (enableOptimizationForBug543480 && isParameterizedDependency(boundRight))
/*      */     {
/*      */       
/*  828 */       return incorporateIntoParameterizedDependencyIfAllArgumentsAreProperTypes(boundRight, 
/*  829 */           firstBounds, nextBounds);
/*      */     }
/*  831 */     if (u.isProperType(true)) {
/*  832 */       boolean substitute = TypeBinding.equalsEquals(alpha, boundRight.left);
/*  833 */       TypeBinding left = substitute ? u : boundRight.left;
/*  834 */       TypeBinding right = boundRight.right.substituteInferenceVariable(alpha, u);
/*  835 */       substitute |= TypeBinding.notEquals(right, boundRight.right);
/*  836 */       if (substitute)
/*  837 */         return ConstraintTypeFormula.create(left, right, boundRight.relation, !(!boundRight.isSoft && !boundLeft.isSoft)); 
/*      */     } 
/*  839 */     return null;
/*      */   }
/*      */ 
/*      */   
/*      */   private ConstraintTypeFormula combineSuperAndSub(TypeBound boundS, TypeBound boundT) {
/*  844 */     InferenceVariable alpha = boundS.left;
/*  845 */     if (TypeBinding.equalsEquals(alpha, boundT.left))
/*      */     {
/*  847 */       return ConstraintTypeFormula.create(boundS.right, boundT.right, 2, !(!boundT.isSoft && !boundS.isSoft)); } 
/*  848 */     if (boundS.right instanceof InferenceVariable) {
/*      */       
/*  850 */       alpha = (InferenceVariable)boundS.right;
/*  851 */       if (TypeBinding.equalsEquals(alpha, boundT.right))
/*      */       {
/*  853 */         return ConstraintTypeFormula.create(boundS.left, boundT.left, 3, !(!boundT.isSoft && !boundS.isSoft)); } 
/*      */     } 
/*  855 */     return null;
/*      */   }
/*      */ 
/*      */   
/*      */   private ConstraintTypeFormula combineEqualSupers(TypeBound boundS, TypeBound boundT) {
/*  860 */     if (TypeBinding.equalsEquals(boundS.left, boundT.right))
/*      */     {
/*  862 */       return ConstraintTypeFormula.create(boundT.left, boundS.right, boundS.relation, !(!boundT.isSoft && !boundS.isSoft)); } 
/*  863 */     if (TypeBinding.equalsEquals(boundS.right, boundT.left))
/*      */     {
/*  865 */       return ConstraintTypeFormula.create(boundS.left, boundT.right, boundS.relation, !(!boundT.isSoft && !boundS.isSoft)); } 
/*  866 */     return null;
/*      */   }
/*      */   
/*      */   private boolean isParameterizedDependency(TypeBound typeBound) {
/*  870 */     return (typeBound.right.kind() == 260 && 
/*  871 */       !typeBound.right.isProperType(true) && 
/*  872 */       typeBound.right.isParameterizedTypeWithActualArguments());
/*      */   }
/*      */ 
/*      */   
/*      */   private ConstraintTypeFormula incorporateIntoParameterizedDependencyIfAllArgumentsAreProperTypes(TypeBound typeBound, TypeBound[] firstBounds, TypeBound[] nextBounds) {
/*  877 */     Collection<TypeBound> properTypesForAllInferenceVariables = getProperTypesForAllInferenceVariablesOrNull((ParameterizedTypeBinding)typeBound.right, firstBounds, nextBounds);
/*  878 */     if (properTypesForAllInferenceVariables != null) {
/*  879 */       return combineWithProperTypes(properTypesForAllInferenceVariables, typeBound);
/*      */     }
/*  881 */     return null;
/*      */   }
/*      */ 
/*      */   
/*      */   private Collection<TypeBound> getProperTypesForAllInferenceVariablesOrNull(ParameterizedTypeBinding parameterizedType, TypeBound[] firstBounds, TypeBound[] nextBounds) {
/*  886 */     Map<InferenceVariable, TypeBound> properTypesByInferenceVariable = properTypesByInferenceVariable(firstBounds, nextBounds);
/*  887 */     if (properTypesByInferenceVariable.size() == 0) {
/*  888 */       return null;
/*      */     }
/*  890 */     Set<InferenceVariable> inferenceVariables = getInferenceVariables(parameterizedType);
/*  891 */     if (properTypesByInferenceVariable.keySet().containsAll(inferenceVariables)) {
/*  892 */       return properTypesByInferenceVariable.values();
/*      */     }
/*  894 */     return null;
/*      */   }
/*      */   
/*      */   private Map<InferenceVariable, TypeBound> properTypesByInferenceVariable(TypeBound[] firstBounds, TypeBound[] nextBounds) {
/*  898 */     return (Map<InferenceVariable, TypeBound>)getBoundsStream(firstBounds, nextBounds)
/*  899 */       .filter(bound -> (bound.relation == 4))
/*  900 */       .filter(bound -> bound.right.isProperType(true))
/*  901 */       .collect(Collectors.toMap(bound -> bound.left, Function.identity(), (boundFromNextBounds, boundFromFirstBounds) -> boundFromNextBounds));
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private Stream<TypeBound> getBoundsStream(TypeBound[] firstBounds, TypeBound[] nextBounds) {
/*  907 */     if (firstBounds == nextBounds) {
/*  908 */       return Arrays.stream(firstBounds);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  914 */     return Stream.concat(Arrays.stream(nextBounds), Arrays.stream(firstBounds));
/*      */   }
/*      */   
/*      */   private Set<InferenceVariable> getInferenceVariables(ParameterizedTypeBinding parameterizedType) {
/*  918 */     Set<InferenceVariable> inferenceVariables = new LinkedHashSet<>(); byte b; int i; TypeBinding[] arrayOfTypeBinding;
/*  919 */     for (i = (arrayOfTypeBinding = parameterizedType.arguments).length, b = 0; b < i; ) { TypeBinding argument = arrayOfTypeBinding[b];
/*  920 */       argument.collectInferenceVariables(inferenceVariables); b++; }
/*      */     
/*  922 */     return inferenceVariables;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private ConstraintTypeFormula combineWithProperTypes(Collection<TypeBound> properTypesForAllInferenceVariables, TypeBound boundRight) {
/*  928 */     if (properTypesForAllInferenceVariables.size() == 0) {
/*  929 */       return null;
/*      */     }
/*  931 */     boolean isAnyLeftSoft = false;
/*  932 */     InferenceVariable left = boundRight.left;
/*  933 */     TypeBinding right = boundRight.right;
/*  934 */     for (TypeBound properTypeForInferenceVariable : properTypesForAllInferenceVariables) {
/*  935 */       TypeBound boundLeft = properTypeForInferenceVariable;
/*  936 */       InferenceVariable alpha = boundLeft.left;
/*  937 */       TypeBinding u = boundLeft.right;
/*  938 */       isAnyLeftSoft |= boundLeft.isSoft;
/*  939 */       right = right.substituteInferenceVariable(alpha, u);
/*      */     } 
/*  941 */     return ConstraintTypeFormula.create(left, right, boundRight.relation, !(!isAnyLeftSoft && !boundRight.isSoft));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private ConstraintTypeFormula[] deriveTypeArgumentConstraints(TypeBound boundS, TypeBound boundT) {
/*  951 */     TypeBinding[] supers = superTypesWithCommonGenericType(boundS.right, boundT.right);
/*  952 */     if (supers != null)
/*  953 */       return typeArgumentEqualityConstraints(supers[0], supers[1], !(!boundS.isSoft && !boundT.isSoft)); 
/*  954 */     return null;
/*      */   }
/*      */   
/*      */   private ConstraintTypeFormula[] typeArgumentEqualityConstraints(TypeBinding s, TypeBinding t, boolean isSoft) {
/*  958 */     if (s == null || s.kind() != 260 || t == null || t.kind() != 260)
/*  959 */       return null; 
/*  960 */     if (TypeBinding.equalsEquals(s, t))
/*  961 */       return null; 
/*  962 */     TypeBinding[] sis = s.typeArguments();
/*  963 */     TypeBinding[] tis = t.typeArguments();
/*  964 */     if (sis == null || tis == null || sis.length != tis.length)
/*  965 */       return null; 
/*  966 */     List<ConstraintTypeFormula> result = new ArrayList<>();
/*  967 */     for (int i = 0; i < sis.length; i++) {
/*  968 */       TypeBinding si = sis[i];
/*  969 */       TypeBinding ti = tis[i];
/*  970 */       if (!si.isWildcard() && !ti.isWildcard() && !TypeBinding.equalsEquals(si, ti))
/*      */       {
/*  972 */         result.add(ConstraintTypeFormula.create(si, ti, 4, isSoft)); } 
/*      */     } 
/*  974 */     if (result.size() > 0)
/*  975 */       return result.<ConstraintTypeFormula>toArray(new ConstraintTypeFormula[result.size()]); 
/*  976 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean reduceOneConstraint(InferenceContext18 context, ConstraintFormula currentConstraint) throws InferenceFailureException {
/*  985 */     Object result = currentConstraint.reduce(context);
/*  986 */     if (result == ReductionResult.FALSE)
/*  987 */       return false; 
/*  988 */     if (result == ReductionResult.TRUE)
/*  989 */       return true; 
/*  990 */     if (result == currentConstraint)
/*      */     {
/*  992 */       throw new IllegalStateException("Failed to reduce constraint formula");
/*      */     }
/*  994 */     if (result != null) {
/*  995 */       if (result instanceof ConstraintFormula)
/*  996 */       { if (!reduceOneConstraint(context, (ConstraintFormula)result))
/*  997 */           return false;  }
/*  998 */       else if (result instanceof ConstraintFormula[])
/*  999 */       { ConstraintFormula[] resultArray = (ConstraintFormula[])result;
/* 1000 */         for (int i = 0; i < resultArray.length; i++) {
/* 1001 */           if (!reduceOneConstraint(context, resultArray[i]))
/* 1002 */             return false; 
/*      */         }  }
/* 1004 */       else { addBound((TypeBound)result, context.environment); }
/*      */     
/*      */     }
/* 1007 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean dependsOnResolutionOf(InferenceVariable alpha, InferenceVariable beta) {
/* 1015 */     alpha = alpha.prototype();
/* 1016 */     beta = beta.prototype();
/* 1017 */     if (TypeBinding.equalsEquals(alpha, beta))
/* 1018 */       return true; 
/* 1019 */     Iterator<Map.Entry<ParameterizedTypeBinding, ParameterizedTypeBinding>> captureIter = this.captures.entrySet().iterator();
/* 1020 */     boolean betaIsInCaptureLhs = false;
/* 1021 */     while (captureIter.hasNext()) {
/* 1022 */       Map.Entry<ParameterizedTypeBinding, ParameterizedTypeBinding> entry = captureIter.next();
/* 1023 */       ParameterizedTypeBinding g = entry.getKey();
/* 1024 */       for (int i = 0; i < g.arguments.length; i++) {
/* 1025 */         if (TypeBinding.equalsEquals(g.arguments[i], alpha)) {
/*      */ 
/*      */           
/* 1028 */           ParameterizedTypeBinding captured = entry.getValue();
/* 1029 */           if (captured.mentionsAny(new TypeBinding[] { beta }, -1))
/* 1030 */             return true; 
/* 1031 */           if (g.mentionsAny(new TypeBinding[] { beta }, i))
/* 1032 */             return true; 
/* 1033 */         } else if (TypeBinding.equalsEquals(g.arguments[i], beta)) {
/* 1034 */           betaIsInCaptureLhs = true;
/*      */         } 
/*      */       } 
/*      */     } 
/* 1038 */     if (betaIsInCaptureLhs) {
/* 1039 */       ThreeSets sets = this.boundsPerVariable.get(beta);
/* 1040 */       if (sets != null && sets.hasDependency(alpha))
/* 1041 */         return true; 
/*      */     } else {
/* 1043 */       ThreeSets sets = this.boundsPerVariable.get(alpha);
/* 1044 */       if (sets != null && sets.hasDependency(beta))
/* 1045 */         return true; 
/*      */     } 
/* 1047 */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   List<Set<InferenceVariable>> computeConnectedComponents(InferenceVariable[] inferenceVariables) {
/* 1052 */     Map<InferenceVariable, Set<InferenceVariable>> allEdges = new HashMap<>();
/* 1053 */     for (int i = 0; i < inferenceVariables.length; i++) {
/* 1054 */       InferenceVariable iv1 = inferenceVariables[i];
/* 1055 */       Set<InferenceVariable> targetSet = new LinkedHashSet<>();
/* 1056 */       allEdges.put(iv1, targetSet);
/* 1057 */       for (int k = 0; k < i; k++) {
/* 1058 */         InferenceVariable iv2 = inferenceVariables[k];
/* 1059 */         if (dependsOnResolutionOf(iv1, iv2) || dependsOnResolutionOf(iv2, iv1)) {
/* 1060 */           targetSet.add(iv2);
/* 1061 */           ((Set<InferenceVariable>)allEdges.get(iv2)).add(iv1);
/*      */         } 
/*      */       } 
/*      */     } 
/*      */     
/* 1066 */     Set<InferenceVariable> visited = new LinkedHashSet<>();
/* 1067 */     List<Set<InferenceVariable>> allComponents = new ArrayList<>(); byte b; int j; InferenceVariable[] arrayOfInferenceVariable;
/* 1068 */     for (j = (arrayOfInferenceVariable = inferenceVariables).length, b = 0; b < j; ) { InferenceVariable inferenceVariable = arrayOfInferenceVariable[b];
/* 1069 */       Set<InferenceVariable> component = new LinkedHashSet<>();
/* 1070 */       addConnected(component, inferenceVariable, allEdges, visited);
/* 1071 */       if (!component.isEmpty())
/* 1072 */         allComponents.add(component);  b++; }
/*      */     
/* 1074 */     return allComponents;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private void addConnected(Set<InferenceVariable> component, InferenceVariable seed, Map<InferenceVariable, Set<InferenceVariable>> allEdges, Set<InferenceVariable> visited) {
/* 1080 */     if (visited.add(seed)) {
/*      */       
/* 1082 */       component.add(seed);
/* 1083 */       for (InferenceVariable next : allEdges.get(seed)) {
/* 1084 */         addConnected(component, next, allEdges, visited);
/*      */       }
/*      */     } 
/*      */   }
/*      */   
/*      */   public boolean hasCaptureBound(Set<InferenceVariable> variableSet) {
/* 1090 */     Iterator<ParameterizedTypeBinding> captureIter = this.captures.keySet().iterator();
/* 1091 */     while (captureIter.hasNext()) {
/* 1092 */       ParameterizedTypeBinding g = captureIter.next();
/* 1093 */       for (int i = 0; i < g.arguments.length; i++) {
/* 1094 */         if (variableSet.contains(g.arguments[i]))
/* 1095 */           return true; 
/*      */       } 
/* 1097 */     }  return false;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean hasOnlyTrivialExceptionBounds(InferenceVariable variable, TypeBinding[] upperBounds) {
/* 1102 */     if (upperBounds != null)
/* 1103 */       for (int i = 0; i < upperBounds.length; i++) {
/* 1104 */         switch ((upperBounds[i]).id) {
/*      */           case 1:
/*      */           case 21:
/*      */           case 25:
/*      */             break;
/*      */           default:
/* 1110 */             return false;
/*      */         } 
/*      */       }  
/* 1113 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public TypeBinding[] upperBounds(InferenceVariable variable, boolean onlyProper) {
/* 1121 */     ThreeSets three = this.boundsPerVariable.get(variable.prototype());
/* 1122 */     if (three == null || three.subBounds == null)
/* 1123 */       return Binding.NO_TYPES; 
/* 1124 */     return three.upperBounds(onlyProper, variable);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   TypeBinding[] lowerBounds(InferenceVariable variable, boolean onlyProper) {
/* 1134 */     ThreeSets three = this.boundsPerVariable.get(variable.prototype());
/* 1135 */     if (three == null || three.superBounds == null)
/* 1136 */       return Binding.NO_TYPES; 
/* 1137 */     return three.lowerBounds(onlyProper, variable);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String toString() {
/* 1146 */     StringBuilder buf = new StringBuilder("Type Bounds:\n");
/* 1147 */     TypeBound[] flattened = flatten();
/* 1148 */     for (int i = 0; i < flattened.length; i++) {
/* 1149 */       buf.append('\t').append(flattened[i].toString()).append('\n');
/*      */     }
/* 1151 */     buf.append("Capture Bounds:\n");
/* 1152 */     Iterator<Map.Entry<ParameterizedTypeBinding, ParameterizedTypeBinding>> captIter = this.captures.entrySet().iterator();
/* 1153 */     while (captIter.hasNext()) {
/* 1154 */       Map.Entry<ParameterizedTypeBinding, ParameterizedTypeBinding> capt = captIter.next();
/* 1155 */       String lhs = String.valueOf(((TypeBinding)capt.getKey()).shortReadableName());
/* 1156 */       String rhs = String.valueOf(((TypeBinding)capt.getValue()).shortReadableName());
/* 1157 */       buf.append('\t').append(lhs).append(" = capt(").append(rhs).append(")\n");
/*      */     } 
/* 1159 */     return buf.toString();
/*      */   }
/*      */   
/*      */   public TypeBinding findWrapperTypeBound(InferenceVariable variable) {
/* 1163 */     ThreeSets three = this.boundsPerVariable.get(variable.prototype());
/* 1164 */     if (three == null) return null; 
/* 1165 */     return three.findSingleWrapperType();
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean condition18_5_2_bullet_3_3_1(InferenceVariable alpha, TypeBinding targetType) {
/* 1171 */     if (targetType.isBaseType()) return false; 
/* 1172 */     if (InferenceContext18.parameterizedWithWildcard(targetType) != null) return false; 
/* 1173 */     ThreeSets ts = this.boundsPerVariable.get(alpha.prototype());
/* 1174 */     if (ts == null)
/* 1175 */       return false; 
/* 1176 */     if (ts.sameBounds != null) {
/* 1177 */       Iterator<TypeBound> bounds = ts.sameBounds.iterator();
/* 1178 */       while (bounds.hasNext()) {
/* 1179 */         TypeBound bound = bounds.next();
/* 1180 */         if (InferenceContext18.parameterizedWithWildcard(bound.right) != null)
/* 1181 */           return true; 
/*      */       } 
/*      */     } 
/* 1184 */     if (ts.superBounds != null) {
/* 1185 */       Iterator<TypeBound> bounds = ts.superBounds.iterator();
/* 1186 */       while (bounds.hasNext()) {
/* 1187 */         TypeBound bound = bounds.next();
/* 1188 */         if (InferenceContext18.parameterizedWithWildcard(bound.right) != null) {
/* 1189 */           return true;
/*      */         }
/*      */       } 
/*      */     } 
/*      */     
/* 1194 */     if (ts.superBounds != null) {
/* 1195 */       ArrayList<TypeBound> superBounds = new ArrayList<>(ts.superBounds);
/* 1196 */       int len = superBounds.size();
/* 1197 */       for (int i = 0; i < len; i++) {
/* 1198 */         TypeBinding s1 = ((TypeBound)superBounds.get(i)).right;
/* 1199 */         for (int j = i + 1; j < len; j++) {
/* 1200 */           TypeBinding s2 = ((TypeBound)superBounds.get(j)).right;
/* 1201 */           TypeBinding[] supers = superTypesWithCommonGenericType(s1, s2);
/* 1202 */           if (supers != null)
/*      */           {
/*      */ 
/*      */ 
/*      */ 
/*      */             
/* 1208 */             if (supers[0].isProperType(true) && supers[1].isProperType(true) && !TypeBinding.equalsEquals(supers[0], supers[1]))
/* 1209 */               return true; 
/*      */           }
/*      */         } 
/*      */       } 
/*      */     } 
/* 1214 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean condition18_5_2_bullet_3_3_2(InferenceVariable alpha, TypeBinding targetType, InferenceContext18 ctx18) {
/* 1221 */     if (!targetType.isParameterizedType()) return false; 
/* 1222 */     TypeBinding g = targetType.original();
/* 1223 */     ThreeSets ts = this.boundsPerVariable.get(alpha.prototype());
/* 1224 */     if (ts == null) {
/* 1225 */       return false;
/*      */     }
/* 1227 */     if (ts.sameBounds != null) {
/* 1228 */       Iterator<TypeBound> boundIterator = ts.sameBounds.iterator();
/* 1229 */       while (boundIterator.hasNext()) {
/* 1230 */         TypeBound b = boundIterator.next();
/* 1231 */         if (superOnlyRaw(g, b.right, ctx18.environment))
/* 1232 */           return true; 
/*      */       } 
/*      */     } 
/* 1235 */     if (ts.superBounds != null) {
/* 1236 */       Iterator<TypeBound> boundIterator = ts.superBounds.iterator();
/* 1237 */       while (boundIterator.hasNext()) {
/* 1238 */         TypeBound b = boundIterator.next();
/* 1239 */         if (superOnlyRaw(g, b.right, ctx18.environment))
/* 1240 */           return true; 
/*      */       } 
/*      */     } 
/* 1243 */     return false;
/*      */   }
/*      */   private boolean superOnlyRaw(TypeBinding g, TypeBinding s, LookupEnvironment env) {
/* 1246 */     if (s instanceof InferenceVariable)
/* 1247 */       return false; 
/* 1248 */     TypeBinding superType = s.findSuperTypeOriginatingFrom(g);
/* 1249 */     if (superType != null && !superType.isParameterizedType())
/* 1250 */       return s.isCompatibleWith(env.convertToRawType(g, false)); 
/* 1251 */     return false;
/*      */   }
/*      */   
/*      */   protected TypeBinding[] superTypesWithCommonGenericType(TypeBinding s, TypeBinding t) {
/* 1255 */     if (s == null || s.id == 1 || t == null || t.id == 1)
/* 1256 */       return null; 
/* 1257 */     if (TypeBinding.equalsEquals(s.original(), t.original())) {
/* 1258 */       return new TypeBinding[] { s, t };
/*      */     }
/* 1260 */     TypeBinding tSuper = t.findSuperTypeOriginatingFrom(s);
/* 1261 */     if (tSuper != null) {
/* 1262 */       return new TypeBinding[] { s, tSuper };
/*      */     }
/* 1264 */     TypeBinding[] result = superTypesWithCommonGenericType(s.superclass(), t);
/* 1265 */     if (result != null)
/* 1266 */       return result; 
/* 1267 */     ReferenceBinding[] superInterfaces = s.superInterfaces();
/* 1268 */     if (superInterfaces != null)
/* 1269 */       for (int i = 0; i < superInterfaces.length; i++) {
/* 1270 */         result = superTypesWithCommonGenericType(superInterfaces[i], t);
/* 1271 */         if (result != null) {
/* 1272 */           return result;
/*      */         }
/*      */       }  
/* 1275 */     return null;
/*      */   }
/*      */   
/*      */   public TypeBinding getEquivalentOuterVariable(InferenceVariable variable, InferenceVariable[] outerVariables) {
/* 1279 */     ThreeSets three = this.boundsPerVariable.get(variable);
/* 1280 */     if (three != null)
/* 1281 */       for (TypeBound bound : three.sameBounds) {
/* 1282 */         byte b1; int j; InferenceVariable[] arrayOfInferenceVariable1; for (j = (arrayOfInferenceVariable1 = outerVariables).length, b1 = 0; b1 < j; ) { InferenceVariable iv = arrayOfInferenceVariable1[b1];
/* 1283 */           if (TypeBinding.equalsEquals(bound.right, iv))
/* 1284 */             return iv;  b1++; }
/*      */       
/*      */       }   byte b; int i; InferenceVariable[] arrayOfInferenceVariable;
/* 1287 */     for (i = (arrayOfInferenceVariable = outerVariables).length, b = 0; b < i; ) { InferenceVariable iv = arrayOfInferenceVariable[b];
/* 1288 */       three = this.boundsPerVariable.get(iv);
/* 1289 */       if (three != null && three.sameBounds != null)
/* 1290 */         for (TypeBound bound : three.sameBounds) {
/* 1291 */           if (TypeBinding.equalsEquals(bound.right, variable))
/* 1292 */             return iv; 
/*      */         }   b++; }
/*      */     
/* 1295 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public TypeBinding[] condition18_5_5_item_4(ReferenceBinding rAlpha, InferenceVariable[] alpha, TypeBinding tPrime, InferenceContext18 ctx18) {
/* 1304 */     return tPrime.isParameterizedType() ? 
/* 1305 */       superTypesWithCommonGenericType(rAlpha, tPrime) : null;
/*      */   }
/*      */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\lookup\BoundSet.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */