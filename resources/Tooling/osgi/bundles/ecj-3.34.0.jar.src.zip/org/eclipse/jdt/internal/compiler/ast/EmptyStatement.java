/*    */ package org.eclipse.jdt.internal.compiler.ast;
/*    */ 
/*    */ import org.eclipse.jdt.internal.compiler.ASTVisitor;
/*    */ import org.eclipse.jdt.internal.compiler.codegen.CodeStream;
/*    */ import org.eclipse.jdt.internal.compiler.flow.FlowContext;
/*    */ import org.eclipse.jdt.internal.compiler.flow.FlowInfo;
/*    */ import org.eclipse.jdt.internal.compiler.lookup.BlockScope;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class EmptyStatement
/*    */   extends Statement
/*    */ {
/*    */   public EmptyStatement(int startPosition, int endPosition) {
/* 27 */     this.sourceStart = startPosition;
/* 28 */     this.sourceEnd = endPosition;
/*    */   }
/*    */ 
/*    */   
/*    */   public FlowInfo analyseCode(BlockScope currentScope, FlowContext flowContext, FlowInfo flowInfo) {
/* 33 */     return flowInfo;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public int complainIfUnreachable(FlowInfo flowInfo, BlockScope scope, int complaintLevel, boolean endOfBlock) {
/* 40 */     if ((scope.compilerOptions()).complianceLevel < 3145728L) {
/* 41 */       return complaintLevel;
/*    */     }
/* 43 */     return super.complainIfUnreachable(flowInfo, scope, complaintLevel, endOfBlock);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void generateCode(BlockScope currentScope, CodeStream codeStream) {}
/*    */ 
/*    */ 
/*    */   
/*    */   public StringBuffer printStatement(int tab, StringBuffer output) {
/* 53 */     return printIndent(tab, output).append(';');
/*    */   }
/*    */ 
/*    */   
/*    */   public void resolve(BlockScope scope) {
/* 58 */     if ((this.bits & 0x1) == 0) {
/* 59 */       scope.problemReporter().superfluousSemicolon(this.sourceStart, this.sourceEnd);
/*    */     } else {
/* 61 */       scope.problemReporter().emptyControlFlowStatement(this.sourceStart, this.sourceEnd);
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   public void traverse(ASTVisitor visitor, BlockScope scope) {
/* 67 */     visitor.visit(this, scope);
/* 68 */     visitor.endVisit(this, scope);
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\ast\EmptyStatement.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */