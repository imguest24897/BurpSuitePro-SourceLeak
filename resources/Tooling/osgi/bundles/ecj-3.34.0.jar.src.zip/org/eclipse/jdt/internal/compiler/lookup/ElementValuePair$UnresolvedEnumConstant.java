/*    */ package org.eclipse.jdt.internal.compiler.lookup;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class UnresolvedEnumConstant
/*    */ {
/*    */   ReferenceBinding enumType;
/*    */   LookupEnvironment environment;
/*    */   char[] enumConstantName;
/*    */   
/*    */   UnresolvedEnumConstant(ReferenceBinding enumType, LookupEnvironment environment, char[] enumConstantName) {
/* 37 */     this.enumType = enumType;
/* 38 */     this.environment = environment;
/* 39 */     this.enumConstantName = enumConstantName;
/*    */   }
/*    */   FieldBinding getResolved() {
/* 42 */     if (this.enumType.isUnresolvedType())
/* 43 */       this.enumType = (ReferenceBinding)BinaryTypeBinding.resolveType(this.enumType, this.environment, false); 
/* 44 */     return this.enumType.getField(this.enumConstantName, false);
/*    */   }
/*    */   public char[] getEnumConstantName() {
/* 47 */     return this.enumConstantName;
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\lookup\ElementValuePair$UnresolvedEnumConstant.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */