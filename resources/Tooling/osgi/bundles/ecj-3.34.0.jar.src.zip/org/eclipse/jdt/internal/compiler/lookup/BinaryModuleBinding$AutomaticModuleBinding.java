/*    */ package org.eclipse.jdt.internal.compiler.lookup;
/*    */ 
/*    */ import java.util.stream.Stream;
/*    */ import org.eclipse.jdt.core.compiler.CharOperation;
/*    */ import org.eclipse.jdt.internal.compiler.env.IModule;
/*    */ import org.eclipse.jdt.internal.compiler.env.IModuleAwareNameEnvironment;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class AutomaticModuleBinding
/*    */   extends ModuleBinding
/*    */ {
/*    */   boolean autoNameFromManifest;
/*    */   boolean hasScannedPackages;
/*    */   
/*    */   public AutomaticModuleBinding(IModule module, LookupEnvironment existingEnvironment) {
/* 39 */     super(module.name(), existingEnvironment);
/* 40 */     existingEnvironment.root.knownModules.put(this.moduleName, this);
/* 41 */     this.isAuto = true;
/* 42 */     this.autoNameFromManifest = module.isAutoNameFromManifest();
/* 43 */     this.requires = Binding.NO_MODULES;
/* 44 */     this.requiresTransitive = Binding.NO_MODULES;
/* 45 */     this.exportedPackages = Binding.NO_PLAIN_PACKAGES;
/* 46 */     this.hasScannedPackages = false;
/*    */   }
/*    */   
/*    */   public boolean hasUnstableAutoName() {
/* 50 */     return !this.autoNameFromManifest;
/*    */   }
/*    */   
/*    */   public ModuleBinding[] getRequiresTransitive() {
/* 54 */     if (this.requiresTransitive == NO_MODULES) {
/* 55 */       char[][] autoModules = ((IModuleAwareNameEnvironment)this.environment.nameEnvironment).getAllAutomaticModules();
/* 56 */       this.requiresTransitive = (ModuleBinding[])Stream.<char[]>of(autoModules)
/* 57 */         .filter(name -> !CharOperation.equals(name, this.moduleName))
/* 58 */         .map(name -> this.environment.getModule(name)).filter(m -> (m != null))
/* 59 */         .toArray(paramInt -> new ModuleBinding[paramInt]);
/*    */     } 
/* 61 */     return this.requiresTransitive;
/*    */   }
/*    */   
/*    */   PlainPackageBinding getDeclaredPackage(char[] flatName) {
/* 65 */     if (!this.hasScannedPackages) {
/* 66 */       byte b; int i; char[][] arrayOfChar; for (i = (arrayOfChar = ((IModuleAwareNameEnvironment)this.environment.nameEnvironment).listPackages(nameForCUCheck())).length, b = 0; b < i; ) { char[] packageName = arrayOfChar[b];
/* 67 */         getOrCreateDeclaredPackage(CharOperation.splitOn('.', packageName)); b++; }
/*    */       
/* 69 */       this.hasScannedPackages = true;
/*    */     } 
/* 71 */     return (PlainPackageBinding)this.declaredPackages.get(flatName);
/*    */   }
/*    */ 
/*    */   
/*    */   public char[] nameForLookup() {
/* 76 */     return ANY_NAMED;
/*    */   }
/*    */ 
/*    */   
/*    */   public char[] nameForCUCheck() {
/* 81 */     return this.moduleName;
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\lookup\BinaryModuleBinding$AutomaticModuleBinding.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */