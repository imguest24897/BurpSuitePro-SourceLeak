/*     */ package org.eclipse.jdt.internal.compiler.ast;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ import org.eclipse.jdt.internal.compiler.ASTVisitor;
/*     */ import org.eclipse.jdt.internal.compiler.codegen.CodeStream;
/*     */ import org.eclipse.jdt.internal.compiler.flow.FlowContext;
/*     */ import org.eclipse.jdt.internal.compiler.flow.FlowInfo;
/*     */ import org.eclipse.jdt.internal.compiler.flow.UnconditionalFlowInfo;
/*     */ import org.eclipse.jdt.internal.compiler.impl.CompilerOptions;
/*     */ import org.eclipse.jdt.internal.compiler.impl.Constant;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.AnnotationBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.Binding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.BlockScope;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.ImplicitNullAnnotationVerifier;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.InferenceContext18;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.InvocationSite;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.LocalTypeBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.LocalVariableBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.MethodBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.MethodScope;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.NestedTypeBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.ParameterizedGenericMethodBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.ParameterizedMethodBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.ParameterizedTypeBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.PolyTypeBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.ProblemMethodBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.ProblemReferenceBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.ReferenceBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.Scope;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.SourceTypeBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.Substitution;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.SyntheticArgumentBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.SyntheticFactoryMethodBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.TypeBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.TypeConstants;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.TypeVariableBinding;
/*     */ import org.eclipse.jdt.internal.compiler.util.SimpleLookupTable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AllocationExpression
/*     */   extends Expression
/*     */   implements IPolyExpression, Invocation
/*     */ {
/*     */   public TypeReference type;
/*     */   public Expression[] arguments;
/*     */   public MethodBinding binding;
/*     */   MethodBinding syntheticAccessor;
/*     */   public TypeReference[] typeArguments;
/*     */   public TypeBinding[] genericTypeArguments;
/*     */   public FieldDeclaration enumConstant;
/*     */   protected TypeBinding typeExpected;
/*     */   public boolean inferredReturnType;
/*     */   public FakedTrackingVariable closeTracker;
/*  85 */   public ExpressionContext expressionContext = ExpressionContext.VANILLA_CONTEXT;
/*     */   
/*     */   private SimpleLookupTable inferenceContexts;
/*     */   
/*     */   public HashMap<TypeBinding, MethodBinding> solutionsPerTargetType;
/*     */   private InferenceContext18 outerInferenceContext;
/*     */   public boolean argsContainCast;
/*  92 */   public TypeBinding[] argumentTypes = Binding.NO_PARAMETERS;
/*     */   
/*     */   public boolean argumentsHaveErrors = false;
/*     */   
/*     */   public FlowInfo analyseCode(BlockScope currentScope, FlowContext flowContext, FlowInfo flowInfo) {
/*     */     FlowInfo flowInfo1;
/*  98 */     checkCapturedLocalInitializationIfNecessary((ReferenceBinding)this.binding.declaringClass.erasure(), currentScope, flowInfo);
/*     */ 
/*     */     
/* 101 */     if (this.arguments != null) {
/* 102 */       boolean analyseResources = (currentScope.compilerOptions()).analyseResourceLeaks;
/* 103 */       boolean hasResourceWrapperType = (analyseResources && 
/* 104 */         this.resolvedType instanceof ReferenceBinding && (
/* 105 */         (ReferenceBinding)this.resolvedType).hasTypeBit(4));
/* 106 */       for (int i = 0, count = this.arguments.length; i < count; i++) {
/* 107 */         UnconditionalFlowInfo unconditionalFlowInfo = 
/* 108 */           this.arguments[i]
/* 109 */           .analyseCode(currentScope, flowContext, flowInfo)
/* 110 */           .unconditionalInits();
/*     */         
/* 112 */         if (analyseResources && !hasResourceWrapperType) {
/* 113 */           flowInfo1 = FakedTrackingVariable.markPassedToOutside(currentScope, this.arguments[i], (FlowInfo)unconditionalFlowInfo, flowContext, false);
/*     */         }
/* 115 */         this.arguments[i].checkNPEbyUnboxing(currentScope, flowContext, flowInfo1);
/*     */       } 
/* 117 */       analyseArguments(currentScope, flowContext, flowInfo1, this.binding, this.arguments);
/*     */     } 
/*     */     
/*     */     ReferenceBinding[] thrownExceptions;
/*     */     
/* 122 */     if ((thrownExceptions = this.binding.thrownExceptions).length != 0) {
/* 123 */       if ((this.bits & 0x10000) != 0 && this.genericTypeArguments == null)
/*     */       {
/* 125 */         thrownExceptions = currentScope.environment().convertToRawTypes(this.binding.thrownExceptions, true, true);
/*     */       }
/*     */       
/* 128 */       flowContext.checkExceptionHandlers(
/* 129 */           (TypeBinding[])thrownExceptions, 
/* 130 */           this, 
/* 131 */           (FlowInfo)flowInfo1.unconditionalCopy(), 
/* 132 */           currentScope);
/*     */     } 
/*     */ 
/*     */     
/* 136 */     if ((currentScope.compilerOptions()).analyseResourceLeaks && FakedTrackingVariable.isAnyCloseable(this.resolvedType)) {
/* 137 */       FakedTrackingVariable.analyseCloseableAllocation(currentScope, flowInfo1, this);
/*     */     }
/* 139 */     ReferenceBinding declaringClass = this.binding.declaringClass;
/* 140 */     MethodScope methodScope = currentScope.methodScope();
/* 141 */     if ((declaringClass.isMemberType() && !declaringClass.isStatic()) || (
/* 142 */       declaringClass.isLocalType() && !methodScope.isStatic && methodScope.isLambdaScope()))
/*     */     {
/*     */       
/* 145 */       currentScope.tagAsAccessingEnclosingInstanceStateOf(this.binding.declaringClass.enclosingType(), false);
/*     */     }
/*     */ 
/*     */     
/* 149 */     manageEnclosingInstanceAccessIfNecessary(currentScope, flowInfo1);
/* 150 */     manageSyntheticAccessIfNecessary(currentScope, flowInfo1);
/*     */ 
/*     */     
/* 153 */     flowContext.recordAbruptExit();
/*     */     
/* 155 */     return flowInfo1;
/*     */   }
/*     */   
/*     */   public void checkCapturedLocalInitializationIfNecessary(ReferenceBinding checkedType, BlockScope currentScope, FlowInfo flowInfo) {
/* 159 */     if ((checkedType.tagBits & 0x834L) == 2068L && 
/* 160 */       !currentScope.isDefinedInType(checkedType)) {
/* 161 */       NestedTypeBinding nestedType = (NestedTypeBinding)checkedType;
/* 162 */       SyntheticArgumentBinding[] syntheticArguments = nestedType.syntheticOuterLocalVariables();
/* 163 */       if (syntheticArguments != null)
/* 164 */         for (int i = 0, count = syntheticArguments.length; i < count; i++) {
/* 165 */           SyntheticArgumentBinding syntheticArgument = syntheticArguments[i];
/*     */           LocalVariableBinding targetLocal;
/* 167 */           if ((targetLocal = syntheticArgument.actualOuterLocalVariable) != null && 
/* 168 */             targetLocal.declaration != null && !flowInfo.isDefinitelyAssigned(targetLocal)) {
/* 169 */             currentScope.problemReporter().uninitializedLocalVariable(targetLocal, this, (Scope)currentScope);
/*     */           }
/*     */         }  
/*     */     } 
/*     */   }
/*     */   
/*     */   public Expression enclosingInstance() {
/* 176 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public void generateCode(BlockScope currentScope, CodeStream codeStream, boolean valueRequired) {
/* 181 */     cleanUpInferenceContexts();
/* 182 */     if (!valueRequired) {
/* 183 */       currentScope.problemReporter().unusedObjectAllocation(this);
/*     */     }
/* 185 */     int pc = codeStream.position;
/* 186 */     MethodBinding codegenBinding = this.binding.original();
/* 187 */     ReferenceBinding allocatedType = codegenBinding.declaringClass;
/*     */     
/* 189 */     codeStream.new_(this.type, (TypeBinding)allocatedType);
/* 190 */     boolean isUnboxing = ((this.implicitConversion & 0x400) != 0);
/* 191 */     if (valueRequired || isUnboxing) {
/* 192 */       codeStream.dup();
/*     */     }
/*     */     
/* 195 */     if (this.type != null) {
/* 196 */       codeStream.recordPositionsFrom(pc, this.type.sourceStart);
/*     */     } else {
/*     */       
/* 199 */       codeStream.ldc(String.valueOf(this.enumConstant.name));
/* 200 */       codeStream.generateInlinedValue(this.enumConstant.binding.id);
/*     */     } 
/*     */ 
/*     */     
/* 204 */     if (allocatedType.isNestedType()) {
/* 205 */       codeStream.generateSyntheticEnclosingInstanceValues(
/* 206 */           currentScope, 
/* 207 */           allocatedType, 
/* 208 */           enclosingInstance(), 
/* 209 */           this);
/*     */     }
/*     */     
/* 212 */     generateArguments(this.binding, this.arguments, currentScope, codeStream);
/*     */     
/* 214 */     if (allocatedType.isNestedType()) {
/* 215 */       codeStream.generateSyntheticOuterArgumentValues(
/* 216 */           currentScope, 
/* 217 */           allocatedType, 
/* 218 */           this);
/*     */     }
/*     */     
/* 221 */     if (this.syntheticAccessor == null) {
/* 222 */       codeStream.invoke((byte)-73, codegenBinding, null, this.typeArguments);
/*     */     } else {
/*     */       
/* 225 */       int i = 0;
/* 226 */       int max = this.syntheticAccessor.parameters.length - codegenBinding.parameters.length;
/* 227 */       for (; i < max; 
/* 228 */         i++) {
/* 229 */         codeStream.aconst_null();
/*     */       }
/* 231 */       codeStream.invoke((byte)-73, this.syntheticAccessor, null, this.typeArguments);
/*     */     } 
/* 233 */     if (valueRequired) {
/* 234 */       codeStream.generateImplicitConversion(this.implicitConversion);
/* 235 */     } else if (isUnboxing) {
/*     */       
/* 237 */       codeStream.generateImplicitConversion(this.implicitConversion);
/* 238 */       switch ((postConversionType((Scope)currentScope)).id) {
/*     */         case 7:
/*     */         case 8:
/* 241 */           codeStream.pop2();
/*     */           break;
/*     */         default:
/* 244 */           codeStream.pop(); break;
/*     */       } 
/*     */     } 
/* 247 */     codeStream.recordPositionsFrom(pc, this.sourceStart);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TypeBinding[] genericTypeArguments() {
/* 255 */     return this.genericTypeArguments;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isSuperAccess() {
/* 260 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isTypeAccess() {
/* 265 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void manageEnclosingInstanceAccessIfNecessary(BlockScope currentScope, FlowInfo flowInfo) {
/* 276 */     if ((flowInfo.tagBits & 0x1) != 0)
/* 277 */       return;  ReferenceBinding allocatedTypeErasure = (ReferenceBinding)this.binding.declaringClass.erasure();
/*     */ 
/*     */     
/* 280 */     if (allocatedTypeErasure.isNestedType() && (
/* 281 */       currentScope.enclosingSourceType().isLocalType() || currentScope.isLambdaSubscope()))
/*     */     {
/* 283 */       if (allocatedTypeErasure.isLocalType()) {
/* 284 */         ((LocalTypeBinding)allocatedTypeErasure).addInnerEmulationDependent(currentScope, false);
/*     */       }
/*     */       else {
/*     */         
/* 288 */         currentScope.propagateInnerEmulation(allocatedTypeErasure, false);
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void manageSyntheticAccessIfNecessary(BlockScope currentScope, FlowInfo flowInfo) {
/* 295 */     if ((flowInfo.tagBits & 0x1) != 0)
/*     */       return; 
/* 297 */     MethodBinding codegenBinding = this.binding.original();
/*     */     
/*     */     ReferenceBinding declaringClass;
/* 300 */     if (codegenBinding.isPrivate() && 
/* 301 */       !currentScope.enclosingSourceType().isNestmateOf(this.binding.declaringClass) && 
/* 302 */       TypeBinding.notEquals((TypeBinding)currentScope.enclosingSourceType(), (TypeBinding)(declaringClass = codegenBinding.declaringClass)))
/*     */     {
/*     */       
/* 305 */       if ((declaringClass.tagBits & 0x10L) != 0L && (currentScope.compilerOptions()).complianceLevel >= 3145728L) {
/*     */         
/* 307 */         codegenBinding.tagBits |= 0x200L;
/*     */       } else {
/* 309 */         this.syntheticAccessor = (MethodBinding)((SourceTypeBinding)declaringClass).addSyntheticMethod(codegenBinding, isSuperAccess());
/* 310 */         currentScope.problemReporter().needToEmulateMethodAccess(codegenBinding, this);
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public StringBuffer printExpression(int indent, StringBuffer output) {
/* 317 */     if (this.type != null) {
/* 318 */       output.append("new ");
/*     */     }
/* 320 */     if (this.typeArguments != null) {
/* 321 */       output.append('<');
/* 322 */       int max = this.typeArguments.length - 1;
/* 323 */       for (int j = 0; j < max; j++) {
/* 324 */         this.typeArguments[j].print(0, output);
/* 325 */         output.append(", ");
/*     */       } 
/* 327 */       this.typeArguments[max].print(0, output);
/* 328 */       output.append('>');
/*     */     } 
/* 330 */     if (this.type != null) {
/* 331 */       this.type.printExpression(0, output);
/*     */     }
/* 333 */     output.append('(');
/* 334 */     if (this.arguments != null) {
/* 335 */       for (int i = 0; i < this.arguments.length; i++) {
/* 336 */         if (i > 0) output.append(", "); 
/* 337 */         this.arguments[i].printExpression(0, output);
/*     */       } 
/*     */     }
/* 340 */     return output.append(')');
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public TypeBinding resolveType(BlockScope scope) {
/* 346 */     boolean isDiamond = (this.type != null && (this.type.bits & 0x80000) != 0);
/* 347 */     CompilerOptions compilerOptions = scope.compilerOptions();
/* 348 */     long sourceLevel = compilerOptions.sourceLevel;
/* 349 */     if (this.constant != Constant.NotAConstant) {
/* 350 */       this.constant = Constant.NotAConstant;
/* 351 */       if (this.type == null) {
/*     */         
/* 353 */         this.resolvedType = (TypeBinding)scope.enclosingReceiverType();
/*     */       } else {
/* 355 */         this.resolvedType = this.type.resolveType(scope, true);
/*     */       } 
/* 357 */       if (this.type != null) {
/* 358 */         checkIllegalNullAnnotation(scope, this.resolvedType);
/*     */         
/* 360 */         if (this.type instanceof ParameterizedQualifiedTypeReference) {
/* 361 */           ReferenceBinding currentType = (ReferenceBinding)this.resolvedType;
/* 362 */           if (currentType == null) return (TypeBinding)currentType;
/*     */ 
/*     */           
/* 365 */           while ((currentType.modifiers & 0x8) == 0 && 
/* 366 */             !currentType.isRawType()) {
/* 367 */             if ((currentType = currentType.enclosingType()) == null) {
/* 368 */               ParameterizedQualifiedTypeReference qRef = (ParameterizedQualifiedTypeReference)this.type;
/* 369 */               for (int i = qRef.typeArguments.length - 2; i >= 0; i--) {
/* 370 */                 if (qRef.typeArguments[i] != null) {
/* 371 */                   scope.problemReporter().illegalQualifiedParameterizedTypeAllocation(this.type, this.resolvedType);
/*     */                   
/*     */                   break;
/*     */                 } 
/*     */               } 
/*     */               break;
/*     */             } 
/*     */           } 
/*     */         } 
/*     */       } 
/* 381 */       if (this.typeArguments != null) {
/* 382 */         int length = this.typeArguments.length;
/* 383 */         this.argumentsHaveErrors = (sourceLevel < 3211264L);
/* 384 */         this.genericTypeArguments = new TypeBinding[length]; int i;
/* 385 */         for (i = 0; i < length; i++) {
/* 386 */           TypeReference typeReference = this.typeArguments[i];
/* 387 */           this.genericTypeArguments[i] = typeReference.resolveType(scope, true); if (typeReference.resolveType(scope, true) == null) {
/* 388 */             this.argumentsHaveErrors = true;
/*     */           }
/* 390 */           if (this.argumentsHaveErrors && typeReference instanceof Wildcard) {
/* 391 */             scope.problemReporter().illegalUsageOfWildcard(typeReference);
/*     */           }
/*     */         } 
/* 394 */         if (isDiamond) {
/* 395 */           scope.problemReporter().diamondNotWithExplicitTypeArguments(this.typeArguments);
/* 396 */           return null;
/*     */         } 
/* 398 */         if (this.argumentsHaveErrors) {
/* 399 */           if (this.arguments != null) {
/* 400 */             int max; for (i = 0, max = this.arguments.length; i < max; i++) {
/* 401 */               this.arguments[i].resolveType(scope);
/*     */             }
/*     */           } 
/* 404 */           return null;
/*     */         } 
/*     */       } 
/*     */ 
/*     */       
/* 409 */       if (this.arguments != null) {
/* 410 */         this.argumentsHaveErrors = false;
/* 411 */         int length = this.arguments.length;
/* 412 */         this.argumentTypes = new TypeBinding[length];
/* 413 */         for (int i = 0; i < length; i++) {
/* 414 */           Expression argument = this.arguments[i];
/* 415 */           if (argument instanceof CastExpression) {
/* 416 */             argument.bits |= 0x20;
/* 417 */             this.argsContainCast = true;
/*     */           } 
/* 419 */           argument.setExpressionContext(ExpressionContext.INVOCATION_CONTEXT);
/* 420 */           if ((this.arguments[i]).resolvedType != null)
/* 421 */             scope.problemReporter().genericInferenceError("Argument was unexpectedly found resolved", this); 
/* 422 */           this.argumentTypes[i] = argument.resolveType(scope); if (argument.resolveType(scope) == null) {
/* 423 */             this.argumentsHaveErrors = true;
/*     */           }
/*     */         } 
/* 426 */         if (this.argumentsHaveErrors) {
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 431 */           if (isDiamond) {
/* 432 */             return null;
/*     */           }
/* 434 */           if (this.resolvedType instanceof ReferenceBinding) {
/*     */             
/* 436 */             TypeBinding[] pseudoArgs = new TypeBinding[length];
/* 437 */             for (int j = length; --j >= 0;) {
/* 438 */               pseudoArgs[j] = (this.argumentTypes[j] == null) ? (TypeBinding)TypeBinding.NULL : this.argumentTypes[j];
/*     */             }
/* 440 */             this.binding = scope.findMethod((ReferenceBinding)this.resolvedType, TypeConstants.INIT, pseudoArgs, this, false);
/* 441 */             if (this.binding != null && !this.binding.isValidBinding()) {
/* 442 */               MethodBinding closestMatch = ((ProblemMethodBinding)this.binding).closestMatch;
/*     */               
/* 444 */               if (closestMatch != null) {
/* 445 */                 ParameterizedGenericMethodBinding parameterizedGenericMethodBinding; if ((closestMatch.original()).typeVariables != Binding.NO_TYPE_VARIABLES)
/*     */                 {
/* 447 */                   parameterizedGenericMethodBinding = scope.environment().createParameterizedGenericMethod(closestMatch.original(), null);
/*     */                 }
/* 449 */                 this.binding = (MethodBinding)parameterizedGenericMethodBinding;
/* 450 */                 MethodBinding closestMatchOriginal = parameterizedGenericMethodBinding.original();
/* 451 */                 if (closestMatchOriginal.isOrEnclosedByPrivateType() && !scope.isDefinedInMethod(closestMatchOriginal))
/*     */                 {
/* 453 */                   closestMatchOriginal.modifiers |= 0x8000000;
/*     */                 }
/*     */               } 
/*     */             } 
/*     */           } 
/* 458 */           return this.resolvedType;
/*     */         } 
/*     */       } 
/* 461 */       if (this.resolvedType == null || !this.resolvedType.isValidBinding()) {
/* 462 */         return null;
/*     */       }
/*     */ 
/*     */       
/* 466 */       if (this.type != null && !this.resolvedType.canBeInstantiated()) {
/* 467 */         scope.problemReporter().cannotInstantiate(this.type, this.resolvedType);
/* 468 */         return this.resolvedType;
/*     */       } 
/*     */     } 
/* 471 */     if (isDiamond) {
/* 472 */       this.binding = inferConstructorOfElidedParameterizedType((Scope)scope);
/* 473 */       if (this.binding == null || !this.binding.isValidBinding()) {
/* 474 */         scope.problemReporter().cannotInferElidedTypes(this);
/* 475 */         return this.resolvedType = null;
/*     */       } 
/* 477 */       if (this.typeExpected == null && compilerOptions.sourceLevel >= 3407872L && this.expressionContext.definesTargetType()) {
/* 478 */         return (TypeBinding)new PolyTypeBinding(this);
/*     */       }
/* 480 */       this.resolvedType = this.type.resolvedType = (TypeBinding)this.binding.declaringClass;
/*     */       
/* 482 */       if (this.binding.isVarargs()) {
/* 483 */         TypeBinding lastArg = this.binding.parameters[this.binding.parameters.length - 1].leafComponentType();
/* 484 */         if (!lastArg.erasure().canBeSeenBy((Scope)scope)) {
/* 485 */           scope.problemReporter().invalidType(this, (TypeBinding)new ProblemReferenceBinding(new char[][] { lastArg.readableName() }, (ReferenceBinding)lastArg, 2));
/* 486 */           return this.resolvedType = null;
/*     */         } 
/*     */       } 
/* 489 */       this.binding = resolvePolyExpressionArguments(this, this.binding, this.argumentTypes, scope);
/*     */     } else {
/* 491 */       this.binding = findConstructorBinding(scope, this, (ReferenceBinding)this.resolvedType, this.argumentTypes);
/*     */     } 
/* 493 */     if (!this.binding.isValidBinding()) {
/* 494 */       if (this.binding.declaringClass == null) {
/* 495 */         this.binding.declaringClass = (ReferenceBinding)this.resolvedType;
/*     */       }
/* 497 */       if (this.type != null && !this.type.resolvedType.isValidBinding()) {
/* 498 */         return null;
/*     */       }
/* 500 */       scope.problemReporter().invalidConstructor(this, this.binding);
/* 501 */       return this.resolvedType;
/*     */     } 
/* 503 */     if ((this.binding.tagBits & 0x80L) != 0L) {
/* 504 */       scope.problemReporter().missingTypeInConstructor(this, this.binding);
/*     */     }
/* 506 */     if (isMethodUseDeprecated(this.binding, (Scope)scope, true, this)) {
/* 507 */       scope.problemReporter().deprecatedMethod(this.binding, this);
/*     */     }
/* 509 */     if (checkInvocationArguments(scope, null, this.resolvedType, this.binding, this.arguments, this.argumentTypes, this.argsContainCast, this)) {
/* 510 */       this.bits |= 0x10000;
/*     */     }
/* 512 */     if (this.typeArguments != null && (this.binding.original()).typeVariables == Binding.NO_TYPE_VARIABLES) {
/* 513 */       scope.problemReporter().unnecessaryTypeArgumentsForMethodInvocation(this.binding, this.genericTypeArguments, this.typeArguments);
/*     */     }
/* 515 */     if (!isDiamond && this.resolvedType.isParameterizedTypeWithActualArguments()) {
/* 516 */       checkTypeArgumentRedundancy((ParameterizedTypeBinding)this.resolvedType, scope);
/*     */     }
/* 518 */     if (compilerOptions.isAnnotationBasedNullAnalysisEnabled) {
/* 519 */       ImplicitNullAnnotationVerifier.ensureNullnessIsKnown(this.binding, (Scope)scope);
/* 520 */       if (scope.environment().usesNullTypeAnnotations()) {
/* 521 */         if (this.binding instanceof ParameterizedGenericMethodBinding && this.typeArguments != null) {
/* 522 */           TypeVariableBinding[] typeVariables = this.binding.original().typeVariables();
/* 523 */           for (int i = 0; i < this.typeArguments.length; i++)
/* 524 */             this.typeArguments[i].checkNullConstraints((Scope)scope, (Substitution)this.binding, (TypeBinding[])typeVariables, i); 
/*     */         } 
/* 526 */         this.resolvedType = scope.environment().createAnnotatedType(this.resolvedType, new AnnotationBinding[] { scope.environment().getNonNullAnnotation() });
/*     */       } 
/*     */     } 
/* 529 */     if (compilerOptions.sourceLevel >= 3407872L && 
/* 530 */       this.binding.getTypeAnnotations() != Binding.NO_ANNOTATIONS) {
/* 531 */       this.resolvedType = scope.environment().createAnnotatedType(this.resolvedType, this.binding.getTypeAnnotations());
/*     */     }
/* 533 */     return this.resolvedType;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void checkIllegalNullAnnotation(BlockScope scope, TypeBinding allocationType) {
/* 540 */     if (allocationType != null) {
/*     */       
/* 542 */       long nullTagBits = allocationType.tagBits & 0x180000000000000L;
/* 543 */       if (nullTagBits != 0L) {
/* 544 */         Annotation annotation = this.type.findAnnotation(nullTagBits);
/* 545 */         if (annotation != null) {
/* 546 */           scope.problemReporter().nullAnnotationUnsupportedLocation(annotation);
/*     */         }
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isBoxingCompatibleWith(TypeBinding targetType, Scope scope) {
/* 554 */     if (isPolyExpression())
/* 555 */       return false; 
/* 556 */     if (this.argumentsHaveErrors || this.binding == null || 
/* 557 */       !this.binding.isValidBinding() || targetType == null || scope == null)
/* 558 */       return false; 
/* 559 */     return isBoxingCompatible(this.resolvedType, targetType, this, scope);
/*     */   }
/*     */   
/*     */   public boolean isCompatibleWith(TypeBinding targetType, Scope scope) {
/*     */     ReferenceBinding referenceBinding;
/* 564 */     if (this.argumentsHaveErrors || this.binding == null || !this.binding.isValidBinding() || targetType == null || scope == null)
/* 565 */       return false; 
/* 566 */     TypeBinding allocationType = this.resolvedType;
/* 567 */     if (isPolyExpression()) {
/* 568 */       TypeBinding originalExpectedType = this.typeExpected;
/*     */       try {
/* 570 */         MethodBinding method = (this.solutionsPerTargetType != null) ? this.solutionsPerTargetType.get(targetType) : null;
/* 571 */         if (method == null) {
/* 572 */           this.typeExpected = targetType;
/* 573 */           method = inferConstructorOfElidedParameterizedType(scope);
/* 574 */           if (method == null || !method.isValidBinding())
/* 575 */             return false; 
/*     */         } 
/* 577 */         referenceBinding = method.declaringClass;
/*     */       } finally {
/* 579 */         this.typeExpected = originalExpectedType;
/*     */       } 
/*     */     } 
/* 582 */     return (referenceBinding != null && referenceBinding.isCompatibleWith(targetType, scope));
/*     */   }
/*     */   
/*     */   public MethodBinding inferConstructorOfElidedParameterizedType(Scope scope) {
/* 586 */     if (this.typeExpected != null && this.binding != null) {
/* 587 */       MethodBinding cached = (this.solutionsPerTargetType != null) ? this.solutionsPerTargetType.get(this.typeExpected) : null;
/* 588 */       if (cached != null)
/* 589 */         return cached; 
/*     */     } 
/* 591 */     boolean[] inferredReturnTypeOut = new boolean[1];
/* 592 */     MethodBinding constructor = inferDiamondConstructor(scope, this, this.resolvedType, this.argumentTypes, inferredReturnTypeOut);
/* 593 */     if (constructor != null) {
/* 594 */       this.inferredReturnType = inferredReturnTypeOut[0];
/* 595 */       if (constructor instanceof ParameterizedGenericMethodBinding && (scope.compilerOptions()).sourceLevel >= 3407872L)
/*     */       {
/* 597 */         if (this.expressionContext == ExpressionContext.INVOCATION_CONTEXT && this.typeExpected == null)
/* 598 */           constructor = ParameterizedGenericMethodBinding.computeCompatibleMethod18(constructor.shallowOriginal(), this.argumentTypes, scope, this); 
/*     */       }
/* 600 */       if (this.typeExpected != null && this.typeExpected.isProperType(true))
/* 601 */         registerResult(this.typeExpected, constructor); 
/*     */     } 
/* 603 */     return constructor;
/*     */   }
/*     */   
/*     */   public static MethodBinding inferDiamondConstructor(Scope scope, InvocationSite site, TypeBinding type, TypeBinding[] argumentTypes, boolean[] inferredReturnTypeOut) {
/* 607 */     ReferenceBinding genericType = ((ParameterizedTypeBinding)type).genericType();
/* 608 */     ReferenceBinding enclosingType = type.enclosingType();
/* 609 */     ParameterizedTypeBinding allocationType = scope.environment().createParameterizedType(genericType, (TypeBinding[])genericType.typeVariables(), enclosingType);
/*     */ 
/*     */     
/* 612 */     MethodBinding factory = scope.getStaticFactory(allocationType, enclosingType, argumentTypes, site);
/* 613 */     if (factory instanceof ParameterizedGenericMethodBinding && factory.isValidBinding()) {
/* 614 */       ParameterizedGenericMethodBinding genericFactory = (ParameterizedGenericMethodBinding)factory;
/* 615 */       inferredReturnTypeOut[0] = genericFactory.inferredReturnType;
/* 616 */       SyntheticFactoryMethodBinding sfmb = (SyntheticFactoryMethodBinding)factory.original();
/* 617 */       TypeVariableBinding[] constructorTypeVariables = sfmb.getConstructor().typeVariables();
/* 618 */       TypeBinding[] constructorTypeArguments = (constructorTypeVariables != null) ? new TypeBinding[constructorTypeVariables.length] : Binding.NO_TYPES;
/* 619 */       if (constructorTypeArguments.length > 0)
/* 620 */         System.arraycopy(((ParameterizedGenericMethodBinding)factory).typeArguments, (sfmb.typeVariables()).length - constructorTypeArguments.length, 
/* 621 */             constructorTypeArguments, 0, constructorTypeArguments.length); 
/* 622 */       if (allocationType.isInterface()) {
/* 623 */         ParameterizedTypeBinding parameterizedType = (ParameterizedTypeBinding)factory.returnType;
/* 624 */         return (MethodBinding)new ParameterizedMethodBinding(parameterizedType, sfmb.getConstructor());
/*     */       } 
/* 626 */       return (MethodBinding)sfmb.applyTypeArgumentsOnConstructor(((ParameterizedTypeBinding)factory.returnType).arguments, constructorTypeArguments, genericFactory.inferredWithUncheckedConversion, site.invocationTargetType());
/*     */     } 
/* 628 */     return null;
/*     */   }
/*     */   public TypeBinding[] inferElidedTypes(Scope scope) {
/* 631 */     return inferElidedTypes((ParameterizedTypeBinding)this.resolvedType, scope);
/*     */   }
/*     */   
/*     */   public TypeBinding[] inferElidedTypes(ParameterizedTypeBinding parameterizedType, Scope scope) {
/* 635 */     ReferenceBinding genericType = parameterizedType.genericType();
/* 636 */     ReferenceBinding enclosingType = parameterizedType.enclosingType();
/* 637 */     ParameterizedTypeBinding allocationType = scope.environment().createParameterizedType(genericType, (TypeBinding[])genericType.typeVariables(), enclosingType);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 644 */     MethodBinding factory = scope.getStaticFactory(allocationType, enclosingType, this.argumentTypes, this);
/* 645 */     if (factory instanceof ParameterizedGenericMethodBinding && factory.isValidBinding()) {
/* 646 */       ParameterizedGenericMethodBinding genericFactory = (ParameterizedGenericMethodBinding)factory;
/* 647 */       this.inferredReturnType = genericFactory.inferredReturnType;
/* 648 */       return ((ParameterizedTypeBinding)factory.returnType).arguments;
/*     */     } 
/* 650 */     return null;
/*     */   }
/*     */   public void checkTypeArgumentRedundancy(ParameterizedTypeBinding allocationType, BlockScope scope) {
/*     */     TypeBinding[] inferredTypes;
/* 654 */     if (scope.problemReporter().computeSeverity(16778100) == 256 || (scope.compilerOptions()).sourceLevel < 3342336L)
/* 655 */       return;  if (allocationType.arguments == null)
/* 656 */       return;  if (this.genericTypeArguments != null)
/* 657 */       return;  if (this.type == null)
/* 658 */       return;  if (this.argumentTypes == Binding.NO_PARAMETERS && this.typeExpected instanceof ParameterizedTypeBinding) {
/* 659 */       ParameterizedTypeBinding expected = (ParameterizedTypeBinding)this.typeExpected;
/* 660 */       if (expected.arguments != null && allocationType.arguments.length == expected.arguments.length) {
/*     */         int j;
/*     */ 
/*     */         
/* 664 */         for (j = 0; j < allocationType.arguments.length && 
/* 665 */           !TypeBinding.notEquals(allocationType.arguments[j], expected.arguments[j]); j++);
/*     */ 
/*     */         
/* 668 */         if (j == allocationType.arguments.length) {
/* 669 */           scope.problemReporter().redundantSpecificationOfTypeArguments(this.type, allocationType.arguments);
/*     */           
/*     */           return;
/*     */         } 
/*     */       } 
/*     */     } 
/* 675 */     int previousBits = this.type.bits;
/*     */ 
/*     */     
/*     */     try {
/* 679 */       this.type.bits |= 0x80000;
/* 680 */       inferredTypes = inferElidedTypes(allocationType, (Scope)scope);
/*     */     } finally {
/*     */       
/* 683 */       this.type.bits = previousBits;
/*     */     } 
/* 685 */     if (inferredTypes == null) {
/*     */       return;
/*     */     }
/* 688 */     for (int i = 0; i < inferredTypes.length; i++) {
/* 689 */       if (TypeBinding.notEquals(inferredTypes[i], allocationType.arguments[i]))
/*     */         return; 
/*     */     } 
/* 692 */     reportTypeArgumentRedundancyProblem(allocationType, scope);
/*     */   }
/*     */   
/*     */   protected void reportTypeArgumentRedundancyProblem(ParameterizedTypeBinding allocationType, BlockScope scope) {
/* 696 */     scope.problemReporter().redundantSpecificationOfTypeArguments(this.type, allocationType.arguments);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setActualReceiverType(ReferenceBinding receiverType) {}
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDepth(int i) {}
/*     */ 
/*     */ 
/*     */   
/*     */   public void setFieldIndex(int i) {}
/*     */ 
/*     */ 
/*     */   
/*     */   public void traverse(ASTVisitor visitor, BlockScope scope) {
/* 716 */     if (visitor.visit(this, scope)) {
/* 717 */       if (this.typeArguments != null) {
/* 718 */         for (int i = 0, typeArgumentsLength = this.typeArguments.length; i < typeArgumentsLength; i++) {
/* 719 */           this.typeArguments[i].traverse(visitor, scope);
/*     */         }
/*     */       }
/* 722 */       if (this.type != null) {
/* 723 */         this.type.traverse(visitor, scope);
/*     */       }
/* 725 */       if (this.arguments != null)
/* 726 */         for (int i = 0, argumentsLength = this.arguments.length; i < argumentsLength; i++) {
/* 727 */           this.arguments[i].traverse(visitor, scope);
/*     */         } 
/*     */     } 
/* 730 */     visitor.endVisit(this, scope);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setExpectedType(TypeBinding expectedType) {
/* 737 */     this.typeExpected = expectedType;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setExpressionContext(ExpressionContext context) {
/* 742 */     this.expressionContext = context;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isPolyExpression() {
/* 747 */     return isPolyExpression(this.binding);
/*     */   }
/*     */   
/*     */   public boolean isPolyExpression(MethodBinding method) {
/* 751 */     return ((this.expressionContext == ExpressionContext.ASSIGNMENT_CONTEXT || this.expressionContext == ExpressionContext.INVOCATION_CONTEXT) && 
/* 752 */       this.type != null && (this.type.bits & 0x80000) != 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TypeBinding invocationTargetType() {
/* 760 */     return this.typeExpected;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean statementExpression() {
/* 765 */     return ((this.bits & 0x1FE00000) == 0);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public MethodBinding binding() {
/* 771 */     return this.binding;
/*     */   }
/*     */   
/*     */   public Expression[] arguments() {
/* 775 */     return this.arguments;
/*     */   }
/*     */ 
/*     */   
/*     */   public void registerInferenceContext(ParameterizedGenericMethodBinding method, InferenceContext18 infCtx18) {
/* 780 */     if (this.inferenceContexts == null)
/* 781 */       this.inferenceContexts = new SimpleLookupTable(); 
/* 782 */     this.inferenceContexts.put(method, infCtx18);
/*     */   }
/*     */ 
/*     */   
/*     */   public void registerResult(TypeBinding targetType, MethodBinding method) {
/* 787 */     if (method != null && method.isConstructor()) {
/* 788 */       if (this.solutionsPerTargetType == null)
/* 789 */         this.solutionsPerTargetType = new HashMap<>(); 
/* 790 */       this.solutionsPerTargetType.put(targetType, method);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public InferenceContext18 getInferenceContext(ParameterizedMethodBinding method) {
/* 796 */     if (this.inferenceContexts == null)
/* 797 */       return null; 
/* 798 */     return (InferenceContext18)this.inferenceContexts.get(method);
/*     */   }
/*     */ 
/*     */   
/*     */   public void cleanUpInferenceContexts() {
/* 803 */     if (this.inferenceContexts == null)
/*     */       return;  byte b; int i; Object[] arrayOfObject;
/* 805 */     for (i = (arrayOfObject = this.inferenceContexts.valueTable).length, b = 0; b < i; ) { Object value = arrayOfObject[b];
/* 806 */       if (value != null)
/* 807 */         ((InferenceContext18)value).cleanUp();  b++; }
/* 808 */      this.inferenceContexts = null;
/* 809 */     this.outerInferenceContext = null;
/* 810 */     this.solutionsPerTargetType = null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ExpressionContext getExpressionContext() {
/* 816 */     return this.expressionContext;
/*     */   }
/*     */   
/*     */   public InferenceContext18 freshInferenceContext(Scope scope) {
/* 820 */     return new InferenceContext18(scope, this.arguments, this, this.outerInferenceContext);
/*     */   }
/*     */   
/*     */   public int nameSourceStart() {
/* 824 */     if (this.enumConstant != null) {
/* 825 */       return this.enumConstant.sourceStart;
/*     */     }
/* 827 */     return this.type.sourceStart;
/*     */   }
/*     */   
/*     */   public int nameSourceEnd() {
/* 831 */     if (this.enumConstant != null) {
/* 832 */       return this.enumConstant.sourceEnd;
/*     */     }
/* 834 */     return this.type.sourceEnd;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\ast\AllocationExpression.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */