/*     */ package org.eclipse.jdt.internal.compiler.ast;
/*     */ 
/*     */ import org.eclipse.jdt.internal.compiler.CompilationResult;
/*     */ import org.eclipse.jdt.internal.compiler.DefaultErrorHandlingPolicies;
/*     */ import org.eclipse.jdt.internal.compiler.IErrorHandlingPolicy;
/*     */ import org.eclipse.jdt.internal.compiler.flow.FlowInfo;
/*     */ import org.eclipse.jdt.internal.compiler.impl.Constant;
/*     */ import org.eclipse.jdt.internal.compiler.impl.ReferenceContext;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.BlockScope;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.CompilationUnitScope;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.IntersectionTypeBinding18;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.LookupEnvironment;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.MethodBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.MethodScope;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.MethodVerifier;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.ParameterizedTypeBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.RawTypeBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.ReferenceBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.Scope;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.TypeBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.TypeBindingVisitor;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.TypeVariableBinding;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class FunctionalExpression
/*     */   extends Expression
/*     */ {
/*     */   protected TypeBinding expectedType;
/*     */   public MethodBinding descriptor;
/*     */   public MethodBinding binding;
/*     */   protected MethodBinding actualMethodBinding;
/*     */   boolean ignoreFurtherInvestigation;
/*  63 */   protected ExpressionContext expressionContext = ExpressionContext.VANILLA_CONTEXT;
/*     */   public CompilationResult compilationResult;
/*     */   public BlockScope enclosingScope;
/*  66 */   public int bootstrapMethodNumber = -1;
/*     */   public boolean shouldCaptureInstance = false;
/*  68 */   protected static IErrorHandlingPolicy silentErrorHandlingPolicy = DefaultErrorHandlingPolicies.ignoreAllProblems();
/*     */   private boolean hasReportedSamProblem = false;
/*     */   public boolean hasDescripterProblem;
/*     */   public boolean isSerializable;
/*     */   public int ordinal;
/*     */   public char[] text;
/*     */   
/*     */   public FunctionalExpression(CompilationResult compilationResult) {
/*  76 */     this.compilationResult = compilationResult;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public FunctionalExpression() {}
/*     */ 
/*     */   
/*     */   public boolean isBoxingCompatibleWith(TypeBinding targetType, Scope scope) {
/*  85 */     return false;
/*     */   }
/*     */   
/*     */   public void setCompilationResult(CompilationResult compilationResult) {
/*  89 */     this.compilationResult = compilationResult;
/*     */   }
/*     */ 
/*     */   
/*     */   public MethodBinding getMethodBinding() {
/*  94 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setExpectedType(TypeBinding expectedType) {
/*  99 */     this.expectedType = expectedType;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setExpressionContext(ExpressionContext context) {
/* 104 */     this.expressionContext = context;
/*     */   }
/*     */ 
/*     */   
/*     */   public ExpressionContext getExpressionContext() {
/* 109 */     return this.expressionContext;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isPolyExpression(MethodBinding candidate) {
/* 114 */     return true;
/*     */   }
/*     */   
/*     */   public boolean isPolyExpression() {
/* 118 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isFunctionalType() {
/* 123 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isPertinentToApplicability(TypeBinding targetType, MethodBinding method) {
/* 128 */     if (targetType instanceof TypeVariableBinding) {
/* 129 */       TypeVariableBinding typeVariable = (TypeVariableBinding)targetType;
/* 130 */       if (method != null) {
/* 131 */         if (typeVariable.declaringElement == method)
/* 132 */           return false; 
/* 133 */         if (method.isConstructor() && typeVariable.declaringElement == method.declaringClass) {
/* 134 */           return false;
/*     */         }
/* 136 */       } else if (typeVariable.declaringElement instanceof MethodBinding) {
/* 137 */         return false;
/*     */       } 
/*     */     } 
/* 140 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public TypeBinding invocationTargetType() {
/* 145 */     if (this.expectedType == null) return null;
/*     */ 
/*     */ 
/*     */     
/* 149 */     MethodBinding sam = this.expectedType.getSingleAbstractMethod((Scope)this.enclosingScope, true);
/* 150 */     if (sam != null && sam.problemId() != 17) {
/* 151 */       if (sam.isConstructor()) {
/* 152 */         return (TypeBinding)sam.declaringClass;
/*     */       }
/* 154 */       return sam.returnType;
/*     */     } 
/* 156 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public TypeBinding expectedType() {
/* 161 */     return this.expectedType;
/*     */   }
/*     */   public boolean argumentsTypeElided() {
/* 164 */     return true;
/*     */   }
/*     */   
/*     */   public int recordFunctionalType(Scope scope) {
/* 168 */     while (scope != null) {
/* 169 */       ReferenceContext context; CompilationUnitDeclaration unit; switch (scope.kind) {
/*     */         case 2:
/* 171 */           context = ((MethodScope)scope).referenceContext;
/* 172 */           if (context instanceof LambdaExpression) {
/* 173 */             LambdaExpression expression = (LambdaExpression)context;
/* 174 */             if (expression != expression.original)
/* 175 */               return 0; 
/*     */           } 
/*     */           break;
/*     */         case 4:
/* 179 */           unit = ((CompilationUnitScope)scope).referenceContext;
/* 180 */           return unit.record(this);
/*     */       } 
/* 182 */       scope = scope.parent;
/*     */     } 
/* 184 */     return 0;
/*     */   }
/*     */ 
/*     */   
/*     */   public TypeBinding resolveType(BlockScope blockScope) {
/* 189 */     return resolveType(blockScope, false);
/*     */   }
/*     */   
/*     */   public TypeBinding resolveType(BlockScope blockScope, boolean skipKosherCheck) {
/* 193 */     this.constant = Constant.NotAConstant;
/* 194 */     this.enclosingScope = blockScope;
/* 195 */     MethodBinding sam = (this.expectedType == null) ? null : this.expectedType.getSingleAbstractMethod((Scope)blockScope, argumentsTypeElided());
/* 196 */     if (sam == null) {
/* 197 */       blockScope.problemReporter().targetTypeIsNotAFunctionalInterface(this);
/* 198 */       return null;
/*     */     } 
/* 200 */     if (!sam.isValidBinding() && sam.problemId() != 25) {
/* 201 */       return reportSamProblem(blockScope, sam);
/*     */     }
/*     */     
/* 204 */     this.descriptor = sam;
/* 205 */     if (skipKosherCheck || kosherDescriptor((Scope)blockScope, sam, true)) {
/* 206 */       if (this.expectedType instanceof IntersectionTypeBinding18) {
/* 207 */         ReferenceBinding[] intersectingTypes = ((IntersectionTypeBinding18)this.expectedType).intersectingTypes;
/* 208 */         for (int t = 0, max = intersectingTypes.length; t < max; t++) {
/* 209 */           if (intersectingTypes[t].findSuperTypeOriginatingFrom(37, false) != null) {
/* 210 */             this.isSerializable = true;
/*     */             break;
/*     */           } 
/*     */         } 
/* 214 */       } else if (this.expectedType.findSuperTypeOriginatingFrom(37, false) != null) {
/* 215 */         this.isSerializable = true;
/*     */       } 
/* 217 */       LookupEnvironment environment = blockScope.environment();
/* 218 */       if (environment.globalOptions.isAnnotationBasedNullAnalysisEnabled) {
/* 219 */         NullAnnotationMatching.checkForContradictions(sam, this, (Scope)blockScope);
/*     */       }
/* 221 */       return this.resolvedType = this.expectedType;
/*     */     } 
/*     */     
/* 224 */     return this.resolvedType = null;
/*     */   }
/*     */   
/*     */   protected TypeBinding reportSamProblem(BlockScope blockScope, MethodBinding sam) {
/* 228 */     if (this.hasReportedSamProblem)
/* 229 */       return null; 
/* 230 */     switch (sam.problemId()) {
/*     */       case 17:
/* 232 */         blockScope.problemReporter().targetTypeIsNotAFunctionalInterface(this);
/* 233 */         this.hasReportedSamProblem = true;
/*     */         break;
/*     */       case 18:
/* 236 */         blockScope.problemReporter().illFormedParameterizationOfFunctionalInterface(this);
/* 237 */         this.hasReportedSamProblem = true;
/*     */         break;
/*     */     } 
/* 240 */     return null;
/*     */   }
/*     */   
/*     */   static class VisibilityInspector
/*     */     extends TypeBindingVisitor {
/*     */     private Scope scope;
/*     */     private boolean shouldChatter;
/*     */     private boolean visible = true;
/*     */     private FunctionalExpression expression;
/*     */     
/*     */     public VisibilityInspector(FunctionalExpression expression, Scope scope, boolean shouldChatter) {
/* 251 */       this.scope = scope;
/* 252 */       this.shouldChatter = shouldChatter;
/* 253 */       this.expression = expression;
/*     */     }
/*     */     
/*     */     private void checkVisibility(ReferenceBinding referenceBinding) {
/* 257 */       if (!referenceBinding.canBeSeenBy(this.scope)) {
/* 258 */         this.visible = false;
/* 259 */         if (this.shouldChatter) {
/* 260 */           this.scope.problemReporter().descriptorHasInvisibleType(this.expression, referenceBinding);
/*     */         }
/*     */       } 
/*     */     }
/*     */     
/*     */     public boolean visit(ReferenceBinding referenceBinding) {
/* 266 */       checkVisibility(referenceBinding);
/* 267 */       return true;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean visit(ParameterizedTypeBinding parameterizedTypeBinding) {
/* 273 */       checkVisibility((ReferenceBinding)parameterizedTypeBinding);
/* 274 */       return true;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean visit(RawTypeBinding rawTypeBinding) {
/* 279 */       checkVisibility((ReferenceBinding)rawTypeBinding);
/* 280 */       return true;
/*     */     }
/*     */     
/*     */     public boolean visible(TypeBinding type) {
/* 284 */       TypeBindingVisitor.visit(this, type);
/* 285 */       return this.visible;
/*     */     }
/*     */     
/*     */     public boolean visible(TypeBinding[] types) {
/* 289 */       TypeBindingVisitor.visit(this, types);
/* 290 */       return this.visible;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean kosherDescriptor(Scope scope, MethodBinding sam, boolean shouldChatter) {
/* 297 */     VisibilityInspector inspector = new VisibilityInspector(this, scope, shouldChatter);
/*     */     
/* 299 */     boolean status = true;
/* 300 */     if (!inspector.visible(sam.returnType))
/* 301 */       status = false; 
/* 302 */     if (!inspector.visible(sam.parameters))
/* 303 */       status = false; 
/* 304 */     if (!inspector.visible((TypeBinding[])sam.thrownExceptions))
/* 305 */       status = false; 
/* 306 */     if (!inspector.visible(this.expectedType))
/* 307 */       status = false; 
/* 308 */     this.hasDescripterProblem |= status ? 0 : 1;
/* 309 */     return status;
/*     */   }
/*     */   
/*     */   public int nullStatus(FlowInfo flowInfo) {
/* 313 */     return 4;
/*     */   }
/*     */   
/*     */   public int diagnosticsSourceEnd() {
/* 317 */     return this.sourceEnd;
/*     */   }
/*     */   
/*     */   public MethodBinding[] getRequiredBridges() {
/*     */     ReferenceBinding functionalType;
/*     */     class BridgeCollector
/*     */     {
/*     */       MethodBinding[] bridges;
/*     */       MethodBinding method;
/*     */       char[] selector;
/*     */       LookupEnvironment environment;
/*     */       Scope scope;
/*     */       
/*     */       BridgeCollector(ReferenceBinding functionalType, MethodBinding method) {
/* 331 */         this.method = method;
/* 332 */         this.selector = method.selector;
/* 333 */         this.environment = FunctionalExpression.this.enclosingScope.environment();
/* 334 */         this.scope = (Scope)FunctionalExpression.this.enclosingScope;
/* 335 */         collectBridges(new ReferenceBinding[] { functionalType });
/*     */       }
/*     */       
/*     */       void collectBridges(ReferenceBinding[] interfaces) {
/* 339 */         int length = (interfaces == null) ? 0 : interfaces.length;
/* 340 */         for (int i = 0; i < length; i++) {
/* 341 */           ReferenceBinding superInterface = interfaces[i];
/* 342 */           if (superInterface != null) {
/*     */             
/* 344 */             MethodBinding[] methods = superInterface.getMethods(this.selector);
/* 345 */             for (int j = 0, count = (methods == null) ? 0 : methods.length; j < count; j++) {
/* 346 */               MethodBinding inheritedMethod = methods[j];
/* 347 */               if (inheritedMethod != null && this.method != inheritedMethod)
/*     */               {
/* 349 */                 if (!inheritedMethod.isStatic() && !inheritedMethod.redeclaresPublicObjectMethod(this.scope)) {
/*     */                   
/* 351 */                   inheritedMethod = MethodVerifier.computeSubstituteMethod(inheritedMethod, this.method, this.environment);
/* 352 */                   if (inheritedMethod != null && MethodVerifier.isSubstituteParameterSubsignature(this.method, inheritedMethod, this.environment) && 
/* 353 */                     MethodVerifier.areReturnTypesCompatible(this.method, inheritedMethod, this.environment))
/*     */                   
/* 355 */                   { MethodBinding originalInherited = inheritedMethod.original();
/* 356 */                     MethodBinding originalOverride = this.method.original();
/* 357 */                     if (!originalOverride.areParameterErasuresEqual(originalInherited) || TypeBinding.notEquals(originalOverride.returnType.erasure(), originalInherited.returnType.erasure()))
/* 358 */                       add(originalInherited);  } 
/*     */                 }  } 
/* 360 */             }  collectBridges(superInterface.superInterfaces());
/*     */           } 
/*     */         } 
/*     */       } void add(MethodBinding inheritedMethod) {
/* 364 */         if (this.bridges == null) {
/* 365 */           this.bridges = new MethodBinding[] { inheritedMethod };
/*     */           return;
/*     */         } 
/* 368 */         int length = this.bridges.length;
/* 369 */         for (int i = 0; i < length; i++) {
/* 370 */           if (this.bridges[i].areParameterErasuresEqual(inheritedMethod) && TypeBinding.equalsEquals((this.bridges[i]).returnType.erasure(), inheritedMethod.returnType.erasure()))
/*     */             return; 
/*     */         } 
/* 373 */         System.arraycopy(this.bridges, 0, this.bridges = new MethodBinding[length + 1], 0, length);
/* 374 */         this.bridges[length] = inheritedMethod;
/*     */       }
/*     */       MethodBinding[] getBridges() {
/* 377 */         return this.bridges;
/*     */       }
/*     */     };
/*     */ 
/*     */     
/* 382 */     if (this.expectedType instanceof IntersectionTypeBinding18) {
/* 383 */       functionalType = (ReferenceBinding)((IntersectionTypeBinding18)this.expectedType).getSAMType((Scope)this.enclosingScope);
/*     */     } else {
/* 385 */       functionalType = (ReferenceBinding)this.expectedType;
/*     */     } 
/* 387 */     return (new BridgeCollector(functionalType, this.descriptor)).getBridges();
/*     */   }
/*     */   boolean requiresBridges() {
/* 390 */     return (getRequiredBridges() != null);
/*     */   }
/*     */   
/*     */   public void cleanUp() {}
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\ast\FunctionalExpression.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */