/*     */ package org.eclipse.jdt.internal.compiler.flow;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ import org.eclipse.jdt.internal.compiler.ast.ASTNode;
/*     */ import org.eclipse.jdt.internal.compiler.ast.AbstractMethodDeclaration;
/*     */ import org.eclipse.jdt.internal.compiler.ast.Argument;
/*     */ import org.eclipse.jdt.internal.compiler.ast.SubRoutineStatement;
/*     */ import org.eclipse.jdt.internal.compiler.ast.TryStatement;
/*     */ import org.eclipse.jdt.internal.compiler.ast.TypeReference;
/*     */ import org.eclipse.jdt.internal.compiler.ast.UnionTypeReference;
/*     */ import org.eclipse.jdt.internal.compiler.codegen.ObjectCache;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.BlockScope;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.CatchParameterBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.MethodScope;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.ReferenceBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.Scope;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.TypeBinding;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ExceptionHandlingFlowContext
/*     */   extends FlowContext
/*     */ {
/*     */   public static final int BitCacheSize = 32;
/*     */   public ReferenceBinding[] handledExceptions;
/*     */   int[] isReached;
/*     */   int[] isNeeded;
/*     */   UnconditionalFlowInfo[] initsOnExceptions;
/*  56 */   ObjectCache indexes = new ObjectCache();
/*     */   
/*     */   boolean isMethodContext;
/*     */   
/*     */   public UnconditionalFlowInfo initsOnReturn;
/*     */   
/*     */   public FlowContext initializationParent;
/*     */   
/*     */   public List extendedExceptions;
/*  65 */   private static final Argument[] NO_ARGUMENTS = new Argument[0];
/*     */ 
/*     */ 
/*     */   
/*     */   public Argument[] catchArguments;
/*     */ 
/*     */   
/*     */   private int[] exceptionToCatchBlockMap;
/*     */ 
/*     */ 
/*     */   
/*     */   public ExceptionHandlingFlowContext(FlowContext parent, ASTNode associatedNode, ReferenceBinding[] handledExceptions, FlowContext initializationParent, BlockScope scope, UnconditionalFlowInfo flowInfo) {
/*  77 */     this(parent, associatedNode, handledExceptions, (int[])null, NO_ARGUMENTS, initializationParent, scope, flowInfo);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ExceptionHandlingFlowContext(FlowContext parent, TryStatement tryStatement, ReferenceBinding[] handledExceptions, int[] exceptionToCatchBlockMap, FlowContext initializationParent, BlockScope scope, FlowInfo flowInfo) {
/*  88 */     this(parent, (ASTNode)tryStatement, handledExceptions, exceptionToCatchBlockMap, tryStatement.catchArguments, initializationParent, scope, flowInfo.unconditionalInits());
/*  89 */     UnconditionalFlowInfo unconditionalCopy = flowInfo.unconditionalCopy();
/*  90 */     unconditionalCopy.acceptAllIncomingNullness();
/*  91 */     unconditionalCopy.tagBits |= 0x40;
/*  92 */     this.initsOnFinally = unconditionalCopy;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   ExceptionHandlingFlowContext(FlowContext parent, ASTNode associatedNode, ReferenceBinding[] handledExceptions, int[] exceptionToCatchBlockMap, Argument[] catchArguments, FlowContext initializationParent, BlockScope scope, UnconditionalFlowInfo flowInfo) {
/* 104 */     super(parent, associatedNode, true);
/* 105 */     this.isMethodContext = (scope == scope.methodScope());
/* 106 */     this.handledExceptions = handledExceptions;
/* 107 */     this.catchArguments = catchArguments;
/* 108 */     this.exceptionToCatchBlockMap = exceptionToCatchBlockMap;
/* 109 */     int count = handledExceptions.length, cacheSize = count / 32 + 1;
/* 110 */     this.isReached = new int[cacheSize];
/* 111 */     this.isNeeded = new int[cacheSize];
/* 112 */     this.initsOnExceptions = new UnconditionalFlowInfo[count];
/* 113 */     boolean markExceptionsAndThrowableAsReached = 
/* 114 */       !(this.isMethodContext && !(scope.compilerOptions()).reportUnusedDeclaredThrownExceptionExemptExceptionAndThrowable);
/* 115 */     for (int i = 0; i < count; i++) {
/* 116 */       ReferenceBinding handledException = handledExceptions[i];
/* 117 */       int catchBlock = (this.exceptionToCatchBlockMap != null) ? this.exceptionToCatchBlockMap[i] : i;
/* 118 */       this.indexes.put(handledException, i);
/* 119 */       if (handledException.isUncheckedException(true)) {
/* 120 */         if (markExceptionsAndThrowableAsReached || (
/* 121 */           handledException.id != 21 && 
/* 122 */           handledException.id != 25)) {
/* 123 */           this.isReached[i / 32] = this.isReached[i / 32] | 1 << i % 32;
/*     */         }
/* 125 */         this.initsOnExceptions[catchBlock] = flowInfo.unconditionalCopy();
/*     */       } else {
/* 127 */         this.initsOnExceptions[catchBlock] = FlowInfo.DEAD_END;
/*     */       } 
/*     */     } 
/* 130 */     if (!this.isMethodContext) {
/* 131 */       System.arraycopy(this.isReached, 0, this.isNeeded, 0, cacheSize);
/*     */     }
/* 133 */     this.initsOnReturn = FlowInfo.DEAD_END;
/* 134 */     this.initializationParent = initializationParent;
/*     */   }
/*     */   
/*     */   public void complainIfUnusedExceptionHandlers(AbstractMethodDeclaration method) {
/* 138 */     MethodScope scope = method.scope;
/*     */     
/* 140 */     if ((method.binding.modifiers & 0x30000000) != 0 && 
/* 141 */       !(scope.compilerOptions()).reportUnusedDeclaredThrownExceptionWhenOverriding) {
/*     */       return;
/*     */     }
/*     */ 
/*     */     
/* 146 */     TypeBinding[] docCommentReferences = null;
/* 147 */     int docCommentReferencesLength = 0;
/* 148 */     if ((scope.compilerOptions())
/* 149 */       .reportUnusedDeclaredThrownExceptionIncludeDocCommentReference && 
/* 150 */       method.javadoc != null && 
/* 151 */       method.javadoc.exceptionReferences != null && (
/* 152 */       docCommentReferencesLength = method.javadoc.exceptionReferences.length) > 0) {
/* 153 */       docCommentReferences = new TypeBinding[docCommentReferencesLength];
/* 154 */       for (int j = 0; j < docCommentReferencesLength; j++) {
/* 155 */         docCommentReferences[j] = (method.javadoc.exceptionReferences[j]).resolvedType;
/*     */       }
/*     */     } 
/* 158 */     for (int i = 0, count = this.handledExceptions.length; i < count; i++) {
/* 159 */       int index = this.indexes.get(this.handledExceptions[i]);
/* 160 */       if ((this.isReached[index / 32] & 1 << index % 32) == 0) {
/* 161 */         for (int j = 0; j < docCommentReferencesLength; j++) {
/* 162 */           if (TypeBinding.equalsEquals(docCommentReferences[j], (TypeBinding)this.handledExceptions[i])) {
/*     */             // Byte code: goto -> 222
/*     */           }
/*     */         } 
/* 166 */         scope.problemReporter().unusedDeclaredThrownException(
/* 167 */             this.handledExceptions[index], 
/* 168 */             method, 
/* 169 */             (ASTNode)method.thrownExceptions[index]);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void complainIfUnusedExceptionHandlers(BlockScope scope, TryStatement tryStatement) {
/* 176 */     for (int index = 0, count = this.handledExceptions.length; index < count; index++) {
/* 177 */       int cacheIndex = index / 32;
/* 178 */       int bitMask = 1 << index % 32;
/* 179 */       if ((this.isReached[cacheIndex] & bitMask) == 0) {
/* 180 */         scope.problemReporter().unreachableCatchBlock(
/* 181 */             this.handledExceptions[index], 
/* 182 */             getExceptionType(index));
/*     */       }
/* 184 */       else if ((this.isNeeded[cacheIndex] & bitMask) == 0) {
/* 185 */         scope.problemReporter().hiddenCatchBlock(
/* 186 */             this.handledExceptions[index], 
/* 187 */             getExceptionType(index));
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private ASTNode getExceptionType(int index) {
/* 194 */     if (this.exceptionToCatchBlockMap == null) {
/* 195 */       return (ASTNode)(this.catchArguments[index]).type;
/*     */     }
/* 197 */     int catchBlock = this.exceptionToCatchBlockMap[index];
/* 198 */     TypeReference typeReference = (this.catchArguments[catchBlock]).type;
/* 199 */     if (typeReference instanceof UnionTypeReference) {
/* 200 */       TypeReference[] typeRefs = ((UnionTypeReference)typeReference).typeReferences;
/* 201 */       for (int i = 0, len = typeRefs.length; i < len; i++) {
/* 202 */         TypeReference typeRef = typeRefs[i];
/* 203 */         if (TypeBinding.equalsEquals(typeRef.resolvedType, (TypeBinding)this.handledExceptions[index])) return (ASTNode)typeRef; 
/*     */       } 
/*     */     } 
/* 206 */     return (ASTNode)typeReference;
/*     */   }
/*     */ 
/*     */   
/*     */   public FlowContext getInitializationContext() {
/* 211 */     return this.initializationParent;
/*     */   }
/*     */ 
/*     */   
/*     */   public String individualToString() {
/* 216 */     StringBuilder buffer = new StringBuilder("Exception flow context");
/* 217 */     int length = this.handledExceptions.length;
/* 218 */     for (int i = 0; i < length; i++) {
/* 219 */       int cacheIndex = i / 32;
/* 220 */       int bitMask = 1 << i % 32;
/* 221 */       buffer.append('[').append(this.handledExceptions[i].readableName());
/* 222 */       if ((this.isReached[cacheIndex] & bitMask) != 0) {
/* 223 */         if ((this.isNeeded[cacheIndex] & bitMask) == 0) {
/* 224 */           buffer.append("-masked");
/*     */         } else {
/* 226 */           buffer.append("-reached");
/*     */         } 
/*     */       } else {
/* 229 */         buffer.append("-not reached");
/*     */       } 
/* 231 */       int catchBlock = (this.exceptionToCatchBlockMap != null) ? this.exceptionToCatchBlockMap[i] : i;
/* 232 */       buffer.append('-').append(this.initsOnExceptions[catchBlock].toString()).append(']');
/*     */     } 
/* 234 */     buffer.append("[initsOnReturn -").append(this.initsOnReturn.toString()).append(']');
/* 235 */     return buffer.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public UnconditionalFlowInfo initsOnException(int index) {
/* 241 */     return this.initsOnExceptions[index];
/*     */   }
/*     */ 
/*     */   
/*     */   public UnconditionalFlowInfo initsOnReturn() {
/* 246 */     return this.initsOnReturn;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void mergeUnhandledException(TypeBinding newException) {
/* 254 */     if (this.extendedExceptions == null) {
/* 255 */       this.extendedExceptions = new ArrayList(Arrays.asList((Object[])this.handledExceptions));
/*     */     }
/* 257 */     boolean isRedundant = false;
/*     */     
/* 259 */     for (int i = this.extendedExceptions.size() - 1; i >= 0; i--) {
/* 260 */       switch (Scope.compareTypes(newException, (TypeBinding)this.extendedExceptions.get(i))) {
/*     */         case 1:
/* 262 */           this.extendedExceptions.remove(i);
/*     */           break;
/*     */         case -1:
/* 265 */           isRedundant = true;
/*     */           break;
/*     */       } 
/*     */ 
/*     */     
/*     */     } 
/* 271 */     if (!isRedundant) {
/* 272 */       this.extendedExceptions.add(newException);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void recordHandlingException(ReferenceBinding exceptionType, UnconditionalFlowInfo flowInfo, TypeBinding raisedException, TypeBinding caughtException, ASTNode invocationSite, boolean wasAlreadyDefinitelyCaught) {
/* 284 */     int index = this.indexes.get(exceptionType);
/* 285 */     int cacheIndex = index / 32;
/* 286 */     int bitMask = 1 << index % 32;
/* 287 */     if (!wasAlreadyDefinitelyCaught) {
/* 288 */       this.isNeeded[cacheIndex] = this.isNeeded[cacheIndex] | bitMask;
/*     */     }
/* 290 */     this.isReached[cacheIndex] = this.isReached[cacheIndex] | bitMask;
/* 291 */     int catchBlock = (this.exceptionToCatchBlockMap != null) ? this.exceptionToCatchBlockMap[index] : index;
/* 292 */     if (caughtException != null && this.catchArguments != null && this.catchArguments.length > 0 && !wasAlreadyDefinitelyCaught) {
/* 293 */       CatchParameterBinding catchParameter = (CatchParameterBinding)(this.catchArguments[catchBlock]).binding;
/* 294 */       catchParameter.setPreciseType(caughtException);
/*     */     } 
/* 296 */     this.initsOnExceptions[catchBlock] = 
/* 297 */       (((this.initsOnExceptions[catchBlock]).tagBits & 0x3) == 0) ? 
/* 298 */       this.initsOnExceptions[catchBlock].mergedWith(flowInfo) : 
/* 299 */       flowInfo.unconditionalCopy();
/*     */   }
/*     */ 
/*     */   
/*     */   public void recordReturnFrom(UnconditionalFlowInfo flowInfo) {
/* 304 */     if ((flowInfo.tagBits & 0x1) == 0) {
/* 305 */       if ((this.initsOnReturn.tagBits & 0x1) == 0) {
/* 306 */         this.initsOnReturn = this.initsOnReturn.mergedWith(flowInfo);
/*     */       } else {
/*     */         
/* 309 */         this.initsOnReturn = (UnconditionalFlowInfo)flowInfo.copy();
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SubRoutineStatement subroutine() {
/* 323 */     if (this.associatedNode instanceof SubRoutineStatement) {
/*     */       
/* 325 */       if (this.parent.subroutine() == this.associatedNode)
/* 326 */         return null; 
/* 327 */       return (SubRoutineStatement)this.associatedNode;
/*     */     } 
/* 329 */     return null;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\flow\ExceptionHandlingFlowContext.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */