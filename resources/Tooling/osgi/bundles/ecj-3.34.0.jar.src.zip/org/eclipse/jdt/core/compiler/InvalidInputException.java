/*    */ package org.eclipse.jdt.core.compiler;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class InvalidInputException
/*    */   extends Exception
/*    */ {
/*    */   private static final long serialVersionUID = 2909732853499731592L;
/*    */   
/*    */   public InvalidInputException() {}
/*    */   
/*    */   public InvalidInputException(String message) {
/* 39 */     super(message);
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\core\compiler\InvalidInputException.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */