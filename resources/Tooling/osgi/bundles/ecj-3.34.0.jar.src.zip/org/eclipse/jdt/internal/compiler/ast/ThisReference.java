/*     */ package org.eclipse.jdt.internal.compiler.ast;
/*     */ 
/*     */ import org.eclipse.jdt.internal.compiler.ASTVisitor;
/*     */ import org.eclipse.jdt.internal.compiler.codegen.CodeStream;
/*     */ import org.eclipse.jdt.internal.compiler.flow.FlowContext;
/*     */ import org.eclipse.jdt.internal.compiler.flow.FlowInfo;
/*     */ import org.eclipse.jdt.internal.compiler.impl.Constant;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.BlockScope;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.ClassScope;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.MethodBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.MethodScope;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.ReferenceBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.TypeBinding;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ThisReference
/*     */   extends Reference
/*     */ {
/*     */   public static ThisReference implicitThis() {
/*  32 */     ThisReference implicitThis = new ThisReference(0, 0);
/*  33 */     implicitThis.bits |= 0x4;
/*  34 */     return implicitThis;
/*     */   }
/*     */ 
/*     */   
/*     */   public ThisReference(int sourceStart, int sourceEnd) {
/*  39 */     this.sourceStart = sourceStart;
/*  40 */     this.sourceEnd = sourceEnd;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public FlowInfo analyseAssignment(BlockScope currentScope, FlowContext flowContext, FlowInfo flowInfo, Assignment assignment, boolean isCompound) {
/*  46 */     return flowInfo;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean checkAccess(BlockScope scope, ReferenceBinding receiverType) {
/*  51 */     MethodScope methodScope = scope.methodScope();
/*     */     
/*  53 */     if (methodScope.isConstructorCall) {
/*  54 */       methodScope.problemReporter().fieldsOrThisBeforeConstructorInvocation(this);
/*  55 */       return false;
/*     */     } 
/*     */ 
/*     */     
/*  59 */     if (methodScope.isStatic) {
/*  60 */       methodScope.problemReporter().errorThisSuperInStatic(this);
/*  61 */       return false;
/*  62 */     }  if (isUnqualifiedSuper()) {
/*  63 */       TypeDeclaration type = methodScope.referenceType();
/*  64 */       if (type != null && TypeDeclaration.kind(type.modifiers) == 2) {
/*  65 */         methodScope.problemReporter().errorNoSuperInInterface(this);
/*  66 */         return false;
/*     */       } 
/*     */     } 
/*  69 */     if (receiverType != null)
/*  70 */       scope.tagAsAccessingEnclosingInstanceStateOf(receiverType, false); 
/*  71 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean checkNPE(BlockScope scope, FlowContext flowContext, FlowInfo flowInfo, int ttlForFieldCheck) {
/*  76 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void generateAssignment(BlockScope currentScope, CodeStream codeStream, Assignment assignment, boolean valueRequired) {}
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void generateCode(BlockScope currentScope, CodeStream codeStream, boolean valueRequired) {
/*  88 */     int pc = codeStream.position;
/*  89 */     if (valueRequired)
/*  90 */       codeStream.aload_0(); 
/*  91 */     if ((this.bits & 0x4) == 0) codeStream.recordPositionsFrom(pc, this.sourceStart);
/*     */   
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void generateCompoundAssignment(BlockScope currentScope, CodeStream codeStream, Expression expression, int operator, int assignmentImplicitConversion, boolean valueRequired) {}
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void generatePostIncrement(BlockScope currentScope, CodeStream codeStream, CompoundAssignment postIncrement, boolean valueRequired) {}
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isImplicitThis() {
/* 109 */     return ((this.bits & 0x4) != 0);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isThis() {
/* 115 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public int nullStatus(FlowInfo flowInfo, FlowContext flowContext) {
/* 120 */     return 4;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public StringBuffer printExpression(int indent, StringBuffer output) {
/* 126 */     if (isImplicitThis()) return output; 
/* 127 */     return output.append("this");
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public TypeBinding resolveType(BlockScope scope) {
/* 133 */     this.constant = Constant.NotAConstant;
/*     */     
/* 135 */     ReferenceBinding enclosingReceiverType = scope.enclosingReceiverType();
/* 136 */     if (!isImplicitThis() && !checkAccess(scope, enclosingReceiverType)) {
/* 137 */       return null;
/*     */     }
/* 139 */     this.resolvedType = (TypeBinding)enclosingReceiverType;
/* 140 */     MethodScope methodScope = scope.namedMethodScope();
/* 141 */     if (methodScope != null) {
/* 142 */       MethodBinding method = methodScope.referenceMethodBinding();
/* 143 */       if (method != null && method.receiver != null && TypeBinding.equalsEquals(method.receiver, this.resolvedType))
/* 144 */         this.resolvedType = method.receiver; 
/*     */     } 
/* 146 */     return this.resolvedType;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void traverse(ASTVisitor visitor, BlockScope blockScope) {
/* 152 */     visitor.visit(this, blockScope);
/* 153 */     visitor.endVisit(this, blockScope);
/*     */   }
/*     */ 
/*     */   
/*     */   public void traverse(ASTVisitor visitor, ClassScope blockScope) {
/* 158 */     visitor.visit(this, blockScope);
/* 159 */     visitor.endVisit(this, blockScope);
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\ast\ThisReference.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */