/*     */ package org.eclipse.jdt.internal.compiler.ast;
/*     */ 
/*     */ import org.eclipse.jdt.core.compiler.CharOperation;
/*     */ import org.eclipse.jdt.internal.compiler.ASTVisitor;
/*     */ import org.eclipse.jdt.internal.compiler.impl.Constant;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.Binding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.BlockScope;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.ClassScope;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.PackageBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.ParameterizedTypeBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.RawTypeBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.ReferenceBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.Scope;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.TypeBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.TypeVariableBinding;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ParameterizedQualifiedTypeReference
/*     */   extends ArrayQualifiedTypeReference
/*     */ {
/*     */   public TypeReference[][] typeArguments;
/*     */   ReferenceBinding[] typesPerToken;
/*     */   
/*     */   public ParameterizedQualifiedTypeReference(char[][] tokens, TypeReference[][] typeArguments, int dim, long[] positions) {
/*  50 */     super(tokens, dim, positions);
/*  51 */     this.typeArguments = typeArguments; int i, max;
/*  52 */     label17: for (i = 0, max = typeArguments.length; i < max; i++) {
/*  53 */       TypeReference[] typeArgumentsOnTypeComponent = typeArguments[i];
/*  54 */       if (typeArgumentsOnTypeComponent != null)
/*  55 */         for (int j = 0, max2 = typeArgumentsOnTypeComponent.length; j < max2; j++) {
/*  56 */           if (((typeArgumentsOnTypeComponent[j]).bits & 0x100000) != 0) {
/*  57 */             this.bits |= 0x100000;
/*     */             break label17;
/*     */           } 
/*     */         }  
/*     */     } 
/*     */   }
/*     */   
/*     */   public ParameterizedQualifiedTypeReference(char[][] tokens, TypeReference[][] typeArguments, int dim, Annotation[][] annotationsOnDimensions, long[] positions) {
/*  65 */     this(tokens, typeArguments, dim, positions);
/*  66 */     setAnnotationsOnDimensions(annotationsOnDimensions);
/*  67 */     if (annotationsOnDimensions != null) {
/*  68 */       this.bits |= 0x100000;
/*     */     }
/*     */   }
/*     */   
/*     */   public void checkBounds(Scope scope) {
/*  73 */     if (this.resolvedType == null || !this.resolvedType.isValidBinding())
/*     */       return; 
/*  75 */     checkBounds(
/*  76 */         (ReferenceBinding)this.resolvedType.leafComponentType(), 
/*  77 */         scope, 
/*  78 */         this.typeArguments.length - 1);
/*     */   }
/*     */   
/*     */   public void checkBounds(ReferenceBinding type, Scope scope, int index) {
/*  82 */     if (index > 0) {
/*  83 */       ReferenceBinding enclosingType = this.typesPerToken[index - 1];
/*  84 */       if (enclosingType != null)
/*  85 */         checkBounds(enclosingType, scope, index - 1); 
/*     */     } 
/*  87 */     if (type.isParameterizedTypeWithActualArguments()) {
/*  88 */       ParameterizedTypeBinding parameterizedType = (ParameterizedTypeBinding)type;
/*  89 */       ReferenceBinding currentType = parameterizedType.genericType();
/*  90 */       TypeVariableBinding[] typeVariables = currentType.typeVariables();
/*  91 */       if (typeVariables != null) {
/*  92 */         parameterizedType.boundCheck(scope, this.typeArguments[index]);
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   public TypeReference augmentTypeWithAdditionalDimensions(int additionalDimensions, Annotation[][] additionalAnnotations, boolean isVarargs) {
/*  98 */     int totalDimensions = dimensions() + additionalDimensions;
/*  99 */     Annotation[][] allAnnotations = getMergedAnnotationsOnDimensions(additionalDimensions, additionalAnnotations);
/* 100 */     ParameterizedQualifiedTypeReference pqtr = new ParameterizedQualifiedTypeReference(this.tokens, this.typeArguments, totalDimensions, allAnnotations, this.sourcePositions);
/* 101 */     pqtr.annotations = this.annotations;
/* 102 */     pqtr.bits |= this.bits & 0x100000;
/* 103 */     if (!isVarargs)
/* 104 */       pqtr.extendedDimensions = additionalDimensions; 
/* 105 */     return pqtr;
/*     */   }
/*     */   
/*     */   public boolean isParameterizedTypeReference() {
/* 109 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean hasNullTypeAnnotation(TypeReference.AnnotationPosition position) {
/* 114 */     if (super.hasNullTypeAnnotation(position))
/* 115 */       return true; 
/* 116 */     if (position == TypeReference.AnnotationPosition.ANY) {
/* 117 */       if (this.resolvedType != null && !this.resolvedType.hasNullTypeAnnotations())
/* 118 */         return false; 
/* 119 */       if (this.typeArguments != null)
/* 120 */         for (int i = 0; i < this.typeArguments.length; i++) {
/* 121 */           TypeReference[] arguments = this.typeArguments[i];
/* 122 */           if (arguments != null) {
/* 123 */             for (int j = 0; j < arguments.length; j++) {
/* 124 */               if (arguments[j].hasNullTypeAnnotation(position)) {
/* 125 */                 return true;
/*     */               }
/*     */             } 
/*     */           }
/*     */         }  
/*     */     } 
/* 131 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public char[][] getParameterizedTypeName() {
/* 139 */     int length = this.tokens.length;
/* 140 */     char[][] qParamName = new char[length][];
/* 141 */     for (int i = 0; i < length; i++) {
/* 142 */       TypeReference[] arguments = this.typeArguments[i];
/* 143 */       if (arguments == null) {
/* 144 */         qParamName[i] = this.tokens[i];
/*     */       } else {
/* 146 */         StringBuilder buffer = new StringBuilder(5);
/* 147 */         buffer.append(this.tokens[i]);
/* 148 */         buffer.append('<');
/* 149 */         for (int j = 0, argLength = arguments.length; j < argLength; j++) {
/* 150 */           if (j > 0) buffer.append(','); 
/* 151 */           buffer.append(CharOperation.concatWith(arguments[j].getParameterizedTypeName(), '.'));
/*     */         } 
/* 153 */         buffer.append('>');
/* 154 */         int nameLength = buffer.length();
/* 155 */         qParamName[i] = new char[nameLength];
/* 156 */         buffer.getChars(0, nameLength, qParamName[i], 0);
/*     */       } 
/*     */     } 
/* 159 */     int dim = this.dimensions;
/* 160 */     if (dim > 0) {
/* 161 */       char[] dimChars = new char[dim * 2];
/* 162 */       for (int j = 0; j < dim; j++) {
/* 163 */         int index = j * 2;
/* 164 */         dimChars[index] = '[';
/* 165 */         dimChars[index + 1] = ']';
/*     */       } 
/* 167 */       qParamName[length - 1] = CharOperation.concat(qParamName[length - 1], dimChars);
/*     */     } 
/* 169 */     return qParamName;
/*     */   }
/*     */ 
/*     */   
/*     */   public TypeReference[][] getTypeArguments() {
/* 174 */     return this.typeArguments;
/*     */   }
/*     */ 
/*     */   
/*     */   protected TypeBinding getTypeBinding(Scope scope) {
/* 179 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private TypeBinding internalResolveType(Scope scope, boolean checkBounds, int location) {
/* 187 */     this.constant = Constant.NotAConstant;
/* 188 */     if ((this.bits & 0x40000) != 0 && 
/* 189 */       this.resolvedType != null) {
/* 190 */       TypeBinding typeBinding; if (this.resolvedType.isValidBinding()) {
/* 191 */         return this.resolvedType;
/*     */       }
/* 193 */       switch (this.resolvedType.problemId()) {
/*     */         case 1:
/*     */         case 2:
/*     */         case 5:
/* 197 */           typeBinding = this.resolvedType.closestMatch();
/* 198 */           return typeBinding;
/*     */       } 
/* 200 */       return null;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 205 */     this.bits |= 0x40000;
/* 206 */     TypeBinding type = internalResolveLeafType(scope, checkBounds);
/* 207 */     createArrayType(scope);
/* 208 */     resolveAnnotations(scope, location);
/* 209 */     if (this.dimensions > 0) {
/* 210 */       this.resolvedType = ArrayTypeReference.maybeMarkArrayContentsNonNull(scope, this.resolvedType, this.sourceStart, this.dimensions, null);
/*     */     }
/*     */     
/* 213 */     if (this.typeArguments != null)
/*     */     {
/* 215 */       checkIllegalNullAnnotations(scope, this.typeArguments[this.typeArguments.length - 1]); } 
/* 216 */     return (type == null) ? type : this.resolvedType;
/*     */   }
/*     */   private TypeBinding internalResolveLeafType(Scope scope, boolean checkBounds) {
/* 219 */     boolean isClassScope = (scope.kind == 3);
/* 220 */     Binding binding = scope.getPackage(this.tokens);
/* 221 */     if (binding != null && !binding.isValidBinding()) {
/* 222 */       this.resolvedType = (TypeBinding)binding;
/* 223 */       reportInvalidType(scope);
/*     */       
/* 225 */       for (int j = 0, k = this.tokens.length; j < k; j++) {
/* 226 */         TypeReference[] args = this.typeArguments[j];
/* 227 */         if (args != null) {
/* 228 */           int argLength = args.length;
/* 229 */           for (int m = 0; m < argLength; m++) {
/* 230 */             TypeReference typeArgument = args[m];
/* 231 */             if (isClassScope) {
/* 232 */               typeArgument.resolveType((ClassScope)scope);
/*     */             } else {
/* 234 */               typeArgument.resolveType((BlockScope)scope, checkBounds);
/*     */             } 
/*     */           } 
/*     */         } 
/*     */       } 
/* 239 */       return null;
/*     */     } 
/*     */     
/* 242 */     PackageBinding packageBinding = (binding == null) ? null : (PackageBinding)binding;
/* 243 */     rejectAnnotationsOnPackageQualifiers(scope, packageBinding);
/*     */     
/* 245 */     boolean typeIsConsistent = true;
/* 246 */     ReferenceBinding qualifyingType = null;
/* 247 */     int max = this.tokens.length;
/* 248 */     this.typesPerToken = new ReferenceBinding[max];
/* 249 */     for (int i = (packageBinding == null) ? 0 : packageBinding.compoundName.length; i < max; i++) {
/* 250 */       ParameterizedTypeBinding parameterizedTypeBinding; ReferenceBinding referenceBinding1; findNextTypeBinding(i, scope, packageBinding);
/* 251 */       if (!this.resolvedType.isValidBinding()) {
/* 252 */         reportInvalidType(scope);
/*     */         
/* 254 */         for (int j = i; j < max; j++) {
/* 255 */           TypeReference[] arrayOfTypeReference = this.typeArguments[j];
/* 256 */           if (arrayOfTypeReference != null) {
/* 257 */             int argLength = arrayOfTypeReference.length;
/* 258 */             for (int k = 0; k < argLength; k++) {
/* 259 */               TypeReference typeArgument = arrayOfTypeReference[k];
/* 260 */               if (isClassScope) {
/* 261 */                 typeArgument.resolveType((ClassScope)scope);
/*     */               } else {
/* 263 */                 typeArgument.resolveType((BlockScope)scope);
/*     */               } 
/*     */             } 
/*     */           } 
/*     */         } 
/* 268 */         return null;
/*     */       } 
/* 270 */       ReferenceBinding currentType = (ReferenceBinding)this.resolvedType;
/* 271 */       if (qualifyingType == null) {
/* 272 */         qualifyingType = currentType.enclosingType();
/* 273 */         if (qualifyingType != null && currentType.hasEnclosingInstanceContext()) {
/* 274 */           qualifyingType = scope.environment().convertToParameterizedType(qualifyingType);
/*     */         }
/*     */       } else {
/* 277 */         if (this.annotations != null)
/* 278 */           rejectAnnotationsOnStaticMemberQualififer(scope, currentType, this.annotations[i - 1]); 
/* 279 */         if (typeIsConsistent && currentType.isStatic() && (
/* 280 */           qualifyingType.isParameterizedTypeWithActualArguments() || qualifyingType.isGenericType())) {
/* 281 */           scope.problemReporter().staticMemberOfParameterizedType(this, currentType, qualifyingType, i);
/* 282 */           typeIsConsistent = false;
/* 283 */           qualifyingType = qualifyingType.actualType();
/*     */         } 
/* 285 */         ReferenceBinding enclosingType = currentType.enclosingType();
/* 286 */         if (enclosingType != null && TypeBinding.notEquals(enclosingType.erasure(), qualifyingType.erasure())) {
/* 287 */           qualifyingType = enclosingType;
/*     */         }
/*     */       } 
/*     */ 
/*     */       
/* 292 */       TypeReference[] args = this.typeArguments[i];
/* 293 */       if (args != null) {
/* 294 */         TypeReference keep = null;
/* 295 */         if (isClassScope) {
/* 296 */           keep = ((ClassScope)scope).superTypeReference;
/* 297 */           ((ClassScope)scope).superTypeReference = null;
/*     */         } 
/* 299 */         int argLength = args.length;
/* 300 */         boolean isDiamond = (argLength == 0 && i == max - 1 && (this.bits & 0x80000) != 0);
/* 301 */         TypeBinding[] argTypes = new TypeBinding[argLength];
/* 302 */         boolean argHasError = false;
/* 303 */         ReferenceBinding currentOriginal = (ReferenceBinding)currentType.original();
/* 304 */         for (int j = 0; j < argLength; j++) {
/* 305 */           TypeReference arg = args[j];
/* 306 */           TypeBinding argType = isClassScope ? 
/* 307 */             arg.resolveTypeArgument((ClassScope)scope, currentOriginal, j) : 
/* 308 */             arg.resolveTypeArgument((BlockScope)scope, currentOriginal, j);
/* 309 */           if (argType == null) {
/* 310 */             argHasError = true;
/*     */           } else {
/* 312 */             argTypes[j] = argType;
/*     */           } 
/*     */         } 
/* 315 */         if (argHasError) {
/* 316 */           return null;
/*     */         }
/* 318 */         if (isClassScope) {
/* 319 */           ((ClassScope)scope).superTypeReference = keep;
/* 320 */           if (((ClassScope)scope).detectHierarchyCycle((TypeBinding)currentOriginal, this)) {
/* 321 */             return null;
/*     */           }
/*     */         } 
/* 324 */         TypeVariableBinding[] typeVariables = currentOriginal.typeVariables();
/* 325 */         if (typeVariables == Binding.NO_TYPE_VARIABLES) {
/* 326 */           if ((scope.compilerOptions()).originalSourceLevel >= 3211264L) {
/* 327 */             scope.problemReporter().nonGenericTypeCannotBeParameterized(i, this, (TypeBinding)currentType, argTypes);
/* 328 */             return null;
/*     */           } 
/* 330 */           this.resolvedType = (qualifyingType != null && qualifyingType.isParameterizedType()) ? 
/* 331 */             (TypeBinding)scope.environment().createParameterizedType(currentOriginal, null, qualifyingType) : 
/* 332 */             (TypeBinding)currentType;
/* 333 */           return this.resolvedType;
/* 334 */         }  if (argLength != typeVariables.length && 
/* 335 */           !isDiamond) {
/* 336 */           scope.problemReporter().incorrectArityForParameterizedType(this, (TypeBinding)currentType, argTypes, i);
/* 337 */           return null;
/*     */         } 
/*     */ 
/*     */         
/* 341 */         if (typeIsConsistent) {
/* 342 */           if (!currentType.hasEnclosingInstanceContext()) {
/* 343 */             if (qualifyingType != null && qualifyingType.isRawType())
/* 344 */               this.typesPerToken[i - 1] = qualifyingType = qualifyingType.actualType(); 
/*     */           } else {
/* 346 */             ReferenceBinding actualEnclosing = currentType.enclosingType();
/* 347 */             if (actualEnclosing != null && actualEnclosing.isRawType()) {
/* 348 */               scope.problemReporter().rawMemberTypeCannotBeParameterized(
/* 349 */                   this, (ReferenceBinding)scope.environment().createRawType(currentOriginal, actualEnclosing), argTypes);
/* 350 */               typeIsConsistent = false;
/*     */             } 
/*     */           } 
/*     */         }
/* 354 */         ParameterizedTypeBinding parameterizedType = scope.environment().createParameterizedType(currentOriginal, argTypes, qualifyingType);
/*     */         
/* 356 */         if (!isDiamond)
/* 357 */         { if (checkBounds) {
/* 358 */             parameterizedType.boundCheck(scope, args);
/*     */           } else {
/* 360 */             scope.deferBoundCheck(this);
/*     */           }  }
/* 362 */         else { parameterizedType.arguments = ParameterizedSingleTypeReference.DIAMOND_TYPE_ARGUMENTS; }
/*     */         
/* 364 */         parameterizedTypeBinding = parameterizedType;
/*     */       } else {
/* 366 */         RawTypeBinding rawTypeBinding; ReferenceBinding currentOriginal = (ReferenceBinding)currentType.original();
/* 367 */         if (isClassScope && (
/* 368 */           (ClassScope)scope).detectHierarchyCycle((TypeBinding)currentOriginal, this))
/* 369 */           return null; 
/* 370 */         if (currentOriginal.isGenericType()) {
/* 371 */           if (typeIsConsistent && parameterizedTypeBinding != null && parameterizedTypeBinding.isParameterizedType() && currentOriginal.hasEnclosingInstanceContext()) {
/* 372 */             scope.problemReporter().parameterizedMemberTypeMissingArguments(this, (TypeBinding)scope.environment().createParameterizedType(currentOriginal, null, (ReferenceBinding)parameterizedTypeBinding), i);
/* 373 */             typeIsConsistent = false;
/*     */           } 
/* 375 */           rawTypeBinding = scope.environment().createRawType(currentOriginal, (ReferenceBinding)parameterizedTypeBinding);
/*     */         } else {
/* 377 */           referenceBinding1 = scope.environment().maybeCreateParameterizedType(currentOriginal, (ReferenceBinding)rawTypeBinding);
/*     */         } 
/*     */       } 
/* 380 */       if (isTypeUseDeprecated((TypeBinding)referenceBinding1, scope))
/* 381 */         reportDeprecatedType((TypeBinding)referenceBinding1, scope, i); 
/* 382 */       this.resolvedType = (TypeBinding)referenceBinding1;
/* 383 */       this.typesPerToken[i] = referenceBinding1;
/* 384 */       recordResolution(scope.environment(), this.resolvedType);
/*     */     } 
/* 386 */     return this.resolvedType;
/*     */   }
/*     */   private void createArrayType(Scope scope) {
/* 389 */     if (this.dimensions > 0) {
/* 390 */       if (this.dimensions > 255)
/* 391 */         scope.problemReporter().tooManyDimensions(this); 
/* 392 */       this.resolvedType = (TypeBinding)scope.createArrayType(this.resolvedType, this.dimensions);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public StringBuffer printExpression(int indent, StringBuffer output) {
/* 398 */     int length = this.tokens.length;
/* 399 */     for (int i = 0; i < length - 1; i++) {
/* 400 */       if (this.annotations != null && this.annotations[i] != null) {
/* 401 */         printAnnotations(this.annotations[i], output);
/* 402 */         output.append(' ');
/*     */       } 
/* 404 */       output.append(this.tokens[i]);
/* 405 */       TypeReference[] arrayOfTypeReference = this.typeArguments[i];
/* 406 */       if (arrayOfTypeReference != null) {
/* 407 */         output.append('<');
/* 408 */         int typeArgumentLength = arrayOfTypeReference.length;
/* 409 */         if (typeArgumentLength > 0) {
/* 410 */           int max = typeArgumentLength - 1;
/* 411 */           for (int j = 0; j < max; j++) {
/* 412 */             arrayOfTypeReference[j].print(0, output);
/* 413 */             output.append(", ");
/*     */           } 
/* 415 */           arrayOfTypeReference[max].print(0, output);
/*     */         } 
/* 417 */         output.append('>');
/*     */       } 
/* 419 */       output.append('.');
/*     */     } 
/* 421 */     if (this.annotations != null && this.annotations[length - 1] != null) {
/* 422 */       output.append(" ");
/* 423 */       printAnnotations(this.annotations[length - 1], output);
/* 424 */       output.append(' ');
/*     */     } 
/* 426 */     output.append(this.tokens[length - 1]);
/* 427 */     TypeReference[] typeArgument = this.typeArguments[length - 1];
/* 428 */     if (typeArgument != null) {
/* 429 */       output.append('<');
/* 430 */       int typeArgumentLength = typeArgument.length;
/* 431 */       if (typeArgumentLength > 0) {
/* 432 */         int max = typeArgumentLength - 1;
/* 433 */         for (int j = 0; j < max; j++) {
/* 434 */           typeArgument[j].print(0, output);
/* 435 */           output.append(", ");
/*     */         } 
/* 437 */         typeArgument[max].print(0, output);
/*     */       } 
/* 439 */       output.append('>');
/*     */     } 
/* 441 */     Annotation[][] annotationsOnDimensions = getAnnotationsOnDimensions();
/* 442 */     if ((this.bits & 0x4000) != 0) {
/* 443 */       for (int j = 0; j < this.dimensions - 1; j++) {
/* 444 */         if (annotationsOnDimensions != null && annotationsOnDimensions[j] != null) {
/* 445 */           output.append(" ");
/* 446 */           printAnnotations(annotationsOnDimensions[j], output);
/* 447 */           output.append(" ");
/*     */         } 
/* 449 */         output.append("[]");
/*     */       } 
/* 451 */       if (annotationsOnDimensions != null && annotationsOnDimensions[this.dimensions - 1] != null) {
/* 452 */         output.append(" ");
/* 453 */         printAnnotations(annotationsOnDimensions[this.dimensions - 1], output);
/* 454 */         output.append(" ");
/*     */       } 
/* 456 */       output.append("...");
/*     */     } else {
/* 458 */       for (int j = 0; j < this.dimensions; j++) {
/* 459 */         if (annotationsOnDimensions != null && annotationsOnDimensions[j] != null) {
/* 460 */           output.append(" ");
/* 461 */           printAnnotations(annotationsOnDimensions[j], output);
/* 462 */           output.append(" ");
/*     */         } 
/* 464 */         output.append("[]");
/*     */       } 
/*     */     } 
/* 467 */     return output;
/*     */   }
/*     */ 
/*     */   
/*     */   public TypeBinding resolveType(BlockScope scope, boolean checkBounds, int location) {
/* 472 */     return internalResolveType((Scope)scope, checkBounds, location);
/*     */   }
/*     */   
/*     */   public TypeBinding resolveType(ClassScope scope, int location) {
/* 476 */     return internalResolveType((Scope)scope, false, location);
/*     */   }
/*     */   
/*     */   public void traverse(ASTVisitor visitor, BlockScope scope) {
/* 480 */     if (visitor.visit(this, scope)) {
/* 481 */       if (this.annotations != null) {
/* 482 */         int annotationsLevels = this.annotations.length;
/* 483 */         for (int j = 0; j < annotationsLevels; j++) {
/* 484 */           int annotationsLength = (this.annotations[j] == null) ? 0 : (this.annotations[j]).length;
/* 485 */           for (int k = 0; k < annotationsLength; k++)
/* 486 */             this.annotations[j][k].traverse(visitor, scope); 
/*     */         } 
/*     */       } 
/* 489 */       Annotation[][] annotationsOnDimensions = getAnnotationsOnDimensions(true);
/* 490 */       if (annotationsOnDimensions != null) {
/* 491 */         for (int j = 0, k = annotationsOnDimensions.length; j < k; j++) {
/* 492 */           Annotation[] annotations2 = annotationsOnDimensions[j];
/* 493 */           for (int m = 0, max2 = (annotations2 == null) ? 0 : annotations2.length; m < max2; m++) {
/* 494 */             Annotation annotation = annotations2[m];
/* 495 */             annotation.traverse(visitor, scope);
/*     */           } 
/*     */         } 
/*     */       }
/* 499 */       for (int i = 0, max = this.typeArguments.length; i < max; i++) {
/* 500 */         if (this.typeArguments[i] != null) {
/* 501 */           for (int j = 0, max2 = (this.typeArguments[i]).length; j < max2; j++) {
/* 502 */             this.typeArguments[i][j].traverse(visitor, scope);
/*     */           }
/*     */         }
/*     */       } 
/*     */     } 
/* 507 */     visitor.endVisit(this, scope);
/*     */   }
/*     */ 
/*     */   
/*     */   public void traverse(ASTVisitor visitor, ClassScope scope) {
/* 512 */     if (visitor.visit(this, scope)) {
/* 513 */       if (this.annotations != null) {
/* 514 */         int annotationsLevels = this.annotations.length;
/* 515 */         for (int j = 0; j < annotationsLevels; j++) {
/* 516 */           int annotationsLength = (this.annotations[j] == null) ? 0 : (this.annotations[j]).length;
/* 517 */           for (int k = 0; k < annotationsLength; k++)
/* 518 */             this.annotations[j][k].traverse(visitor, scope); 
/*     */         } 
/*     */       } 
/* 521 */       Annotation[][] annotationsOnDimensions = getAnnotationsOnDimensions(true);
/* 522 */       if (annotationsOnDimensions != null) {
/* 523 */         for (int j = 0, k = annotationsOnDimensions.length; j < k; j++) {
/* 524 */           Annotation[] annotations2 = annotationsOnDimensions[j];
/* 525 */           for (int m = 0, max2 = (annotations2 == null) ? 0 : annotations2.length; m < max2; m++) {
/* 526 */             Annotation annotation = annotations2[m];
/* 527 */             annotation.traverse(visitor, scope);
/*     */           } 
/*     */         } 
/*     */       }
/* 531 */       for (int i = 0, max = this.typeArguments.length; i < max; i++) {
/* 532 */         if (this.typeArguments[i] != null) {
/* 533 */           for (int j = 0, max2 = (this.typeArguments[i]).length; j < max2; j++) {
/* 534 */             this.typeArguments[i][j].traverse(visitor, scope);
/*     */           }
/*     */         }
/*     */       } 
/*     */     } 
/* 539 */     visitor.endVisit(this, scope);
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\ast\ParameterizedQualifiedTypeReference.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */