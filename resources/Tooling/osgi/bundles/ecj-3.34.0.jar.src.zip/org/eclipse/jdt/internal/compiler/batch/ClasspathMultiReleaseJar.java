/*     */ package org.eclipse.jdt.internal.compiler.batch;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.nio.file.FileSystem;
/*     */ import java.nio.file.FileVisitResult;
/*     */ import java.nio.file.FileVisitor;
/*     */ import java.nio.file.Files;
/*     */ import java.nio.file.Path;
/*     */ import java.nio.file.attribute.BasicFileAttributes;
/*     */ import java.util.Enumeration;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.zip.ZipEntry;
/*     */ import org.eclipse.jdt.internal.compiler.classfmt.ClassFileReader;
/*     */ import org.eclipse.jdt.internal.compiler.classfmt.ExternalAnnotationDecorator;
/*     */ import org.eclipse.jdt.internal.compiler.env.AccessRuleSet;
/*     */ import org.eclipse.jdt.internal.compiler.env.IBinaryType;
/*     */ import org.eclipse.jdt.internal.compiler.env.NameEnvironmentAnswer;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.BinaryTypeBinding;
/*     */ import org.eclipse.jdt.internal.compiler.util.JRTUtil;
/*     */ import org.eclipse.jdt.internal.compiler.util.SuffixConstants;
/*     */ import org.eclipse.jdt.internal.compiler.util.Util;
/*     */ 
/*     */ public class ClasspathMultiReleaseJar
/*     */   extends ClasspathJar {
/*  27 */   private FileSystem fs = null;
/*  28 */   Path releasePath = null;
/*  29 */   String compliance = null;
/*     */ 
/*     */   
/*     */   public ClasspathMultiReleaseJar(File file, boolean closeZipFileAtEnd, AccessRuleSet accessRuleSet, String destinationPath, String compliance) {
/*  33 */     super(file, closeZipFileAtEnd, accessRuleSet, destinationPath);
/*  34 */     this.compliance = compliance;
/*     */   }
/*     */   
/*     */   public void initialize() throws IOException {
/*  38 */     super.initialize();
/*  39 */     if (this.file.exists()) {
/*  40 */       this.fs = JRTUtil.getJarFileSystem(this.file.toPath());
/*  41 */       this.releasePath = this.fs.getPath("/", new String[] { "META-INF", "versions", this.compliance });
/*  42 */       if (!Files.exists(this.releasePath, new java.nio.file.LinkOption[0])) {
/*  43 */         this.releasePath = null;
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public synchronized char[][] getModulesDeclaringPackage(String qualifiedPackageName, String moduleName) {
/*  50 */     if (this.releasePath == null) {
/*  51 */       return super.getModulesDeclaringPackage(qualifiedPackageName, moduleName);
/*     */     }
/*  53 */     if (this.packageCache != null) {
/*  54 */       return singletonModuleNameIf(this.packageCache.contains(qualifiedPackageName));
/*     */     }
/*  56 */     this.packageCache = new HashSet<>(41);
/*  57 */     this.packageCache.add(Util.EMPTY_STRING);
/*     */     Enumeration<? extends ZipEntry> e;
/*  59 */     for (e = this.zipFile.entries(); e.hasMoreElements(); ) {
/*  60 */       String fileName = ((ZipEntry)e.nextElement()).getName();
/*  61 */       addToPackageCache(fileName, false);
/*     */     } 
/*     */     try {
/*  64 */       if (this.releasePath != null && Files.exists(this.releasePath, new java.nio.file.LinkOption[0])) {
/*     */         Exception exception;
/*  66 */         e = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     }
/*  96 */     catch (Exception exception) {
/*  97 */       exception.printStackTrace();
/*     */     } 
/*     */     
/* 100 */     return singletonModuleNameIf(this.packageCache.contains(qualifiedPackageName));
/*     */   }
/*     */   
/*     */   public NameEnvironmentAnswer findClass(char[] binaryFileName, String qualifiedPackageName, String moduleName, String qualifiedBinaryFileName, boolean asBinaryOnly) {
/* 104 */     if (!isPackage(qualifiedPackageName, moduleName)) return null; 
/* 105 */     if (this.releasePath != null) {
/*     */       try {
/* 107 */         ClassFileReader classFileReader; Path p = this.releasePath.resolve(qualifiedBinaryFileName);
/* 108 */         byte[] content = Files.readAllBytes(p);
/* 109 */         IBinaryType reader = null;
/* 110 */         if (content != null) {
/* 111 */           classFileReader = new ClassFileReader(p.toUri(), content, qualifiedBinaryFileName.toCharArray());
/*     */         }
/* 113 */         if (classFileReader != null) {
/* 114 */           IBinaryType iBinaryType; char[] modName = (this.module == null) ? null : this.module.name();
/* 115 */           if (classFileReader instanceof ClassFileReader) {
/* 116 */             ClassFileReader classReader = classFileReader;
/* 117 */             if (classReader.moduleName == null) {
/* 118 */               classReader.moduleName = modName;
/*     */             } else {
/* 120 */               modName = classReader.moduleName;
/*     */             } 
/* 122 */           }  String fileNameWithoutExtension = qualifiedBinaryFileName.substring(0, qualifiedBinaryFileName.length() - SuffixConstants.SUFFIX_CLASS.length);
/*     */           
/* 124 */           if (this.annotationPaths != null)
/* 125 */           { String qualifiedClassName = qualifiedBinaryFileName.substring(0, qualifiedBinaryFileName.length() - "CLASS".length() - 1);
/* 126 */             Iterator<String> iterator = this.annotationPaths.iterator(); while (true) { ExternalAnnotationDecorator externalAnnotationDecorator; if (!iterator.hasNext())
/*     */               
/*     */               { 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */                 
/* 141 */                 externalAnnotationDecorator = new ExternalAnnotationDecorator((IBinaryType)classFileReader, null); break; }  String annotationPath = iterator.next(); try { if (this.annotationZipFile == null)
/*     */                   this.annotationZipFile = ExternalAnnotationDecorator.getAnnotationZipFile(annotationPath, null);  iBinaryType = ExternalAnnotationDecorator.create((IBinaryType)externalAnnotationDecorator, annotationPath, qualifiedClassName, this.annotationZipFile); if (iBinaryType.getExternalAnnotationStatus() == BinaryTypeBinding.ExternalAnnotationStatus.TYPE_IS_ANNOTATED)
/* 143 */                   break;  } catch (IOException iOException) {} }  }  if (this.accessRuleSet == null)
/* 144 */             return new NameEnvironmentAnswer(iBinaryType, null, modName); 
/* 145 */           return new NameEnvironmentAnswer(iBinaryType, 
/* 146 */               this.accessRuleSet.getViolatedRestriction(fileNameWithoutExtension.toCharArray()), 
/* 147 */               modName);
/*     */         } 
/* 149 */       } catch (IOException|org.eclipse.jdt.internal.compiler.classfmt.ClassFormatException iOException) {}
/*     */     }
/*     */ 
/*     */     
/* 153 */     return super.findClass(binaryFileName, qualifiedPackageName, moduleName, qualifiedBinaryFileName, asBinaryOnly);
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\batch\ClasspathMultiReleaseJar.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */