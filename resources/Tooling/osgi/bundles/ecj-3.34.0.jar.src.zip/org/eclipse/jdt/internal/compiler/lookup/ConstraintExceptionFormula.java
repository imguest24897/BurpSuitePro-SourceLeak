/*     */ package org.eclipse.jdt.internal.compiler.lookup;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import org.eclipse.jdt.internal.compiler.ast.FunctionalExpression;
/*     */ import org.eclipse.jdt.internal.compiler.ast.LambdaExpression;
/*     */ import org.eclipse.jdt.internal.compiler.ast.ReferenceExpression;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ConstraintExceptionFormula
/*     */   extends ConstraintFormula
/*     */ {
/*     */   FunctionalExpression left;
/*     */   
/*     */   public ConstraintExceptionFormula(FunctionalExpression left, TypeBinding type) {
/*  40 */     this.left = left;
/*  41 */     this.right = type;
/*  42 */     this.relation = 7;
/*     */   }
/*     */ 
/*     */   
/*     */   public Object reduce(InferenceContext18 inferenceContext) {
/*     */     ReferenceBinding[] arrayOfReferenceBinding2;
/*  48 */     Scope scope = inferenceContext.scope;
/*  49 */     if (!this.right.isFunctionalInterface(scope))
/*  50 */       return FALSE; 
/*  51 */     MethodBinding sam = this.right.getSingleAbstractMethod(scope, true);
/*  52 */     if (sam == null)
/*  53 */       return FALSE; 
/*  54 */     if (this.left instanceof LambdaExpression) {
/*  55 */       if (((LambdaExpression)this.left).argumentsTypeElided()) {
/*  56 */         int nParam = sam.parameters.length;
/*  57 */         for (int i1 = 0; i1 < nParam; i1++) {
/*  58 */           if (!sam.parameters[i1].isProperType(true))
/*  59 */             return FALSE; 
/*     */         } 
/*  61 */       }  if (sam.returnType != TypeBinding.VOID && !sam.returnType.isProperType(true)) {
/*  62 */         return FALSE;
/*     */       }
/*  64 */     } else if (!((ReferenceExpression)this.left).isExactMethodReference()) {
/*  65 */       int nParam = sam.parameters.length;
/*  66 */       for (int i1 = 0; i1 < nParam; i1++) {
/*  67 */         if (!sam.parameters[i1].isProperType(true))
/*  68 */           return FALSE; 
/*  69 */       }  if (sam.returnType != TypeBinding.VOID && !sam.returnType.isProperType(true)) {
/*  70 */         return FALSE;
/*     */       }
/*     */     } 
/*  73 */     ReferenceBinding[] arrayOfReferenceBinding1 = sam.thrownExceptions;
/*  74 */     InferenceVariable[] e = new InferenceVariable[arrayOfReferenceBinding1.length];
/*  75 */     int n = 0;
/*  76 */     for (int i = 0; i < arrayOfReferenceBinding1.length; i++) {
/*  77 */       if (!arrayOfReferenceBinding1[i].isProperType(true)) {
/*  78 */         e[n++] = (InferenceVariable)arrayOfReferenceBinding1[i];
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/*  83 */     if (n == 0) {
/*  84 */       return TRUE;
/*     */     }
/*  86 */     TypeBinding[] ePrime = null;
/*  87 */     if (this.left instanceof LambdaExpression) {
/*  88 */       LambdaExpression lambda = ((LambdaExpression)this.left).resolveExpressionExpecting(this.right, inferenceContext.scope, inferenceContext);
/*  89 */       if (lambda == null)
/*  90 */         return TRUE; 
/*  91 */       Set<TypeBinding> ePrimeSet = lambda.getThrownExceptions();
/*  92 */       ePrime = ePrimeSet.<TypeBinding>toArray(new TypeBinding[ePrimeSet.size()]);
/*     */     } else {
/*  94 */       ReferenceExpression referenceExpression = ((ReferenceExpression)this.left).resolveExpressionExpecting(this.right, scope, inferenceContext);
/*  95 */       MethodBinding method = (referenceExpression != null) ? referenceExpression.binding : null;
/*  96 */       if (method != null)
/*  97 */         arrayOfReferenceBinding2 = method.thrownExceptions; 
/*     */     } 
/*  99 */     if (arrayOfReferenceBinding2 == null)
/* 100 */       return TRUE; 
/* 101 */     int m = arrayOfReferenceBinding2.length;
/* 102 */     List<ConstraintFormula> result = new ArrayList<>();
/* 103 */     for (int k = 0; k < m; k++) {
/* 104 */       if (!arrayOfReferenceBinding2[k].isUncheckedException(false)) {
/*     */         int i1;
/* 106 */         for (i1 = 0; i1 < arrayOfReferenceBinding1.length; i1++) {
/* 107 */           if (arrayOfReferenceBinding1[i1].isProperType(true) && arrayOfReferenceBinding2[k].isCompatibleWith(arrayOfReferenceBinding1[i1]))
/*     */             break label76; 
/* 109 */         }  label76: for (i1 = 0; i1 < n; i1++)
/* 110 */           result.add(ConstraintTypeFormula.create(arrayOfReferenceBinding2[k], e[i1], 2)); 
/*     */       } 
/* 112 */     }  for (int j = 0; j < n; j++)
/* 113 */       inferenceContext.currentBounds.inThrows.add(e[j].prototype()); 
/* 114 */     return result.toArray(new ConstraintFormula[result.size()]);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   Collection<InferenceVariable> inputVariables(InferenceContext18 context) {
/* 120 */     if (this.left instanceof LambdaExpression) {
/* 121 */       if (this.right instanceof InferenceVariable) {
/* 122 */         return Collections.singletonList((InferenceVariable)this.right);
/*     */       }
/* 124 */       if (this.right.isFunctionalInterface(context.scope)) {
/* 125 */         LambdaExpression lambda = (LambdaExpression)this.left;
/* 126 */         MethodBinding sam = this.right.getSingleAbstractMethod(context.scope, true);
/* 127 */         Set<InferenceVariable> variables = new LinkedHashSet<>();
/* 128 */         if (lambda.argumentsTypeElided()) {
/*     */           
/* 130 */           int len = sam.parameters.length;
/* 131 */           for (int i = 0; i < len; i++) {
/* 132 */             sam.parameters[i].collectInferenceVariables(variables);
/*     */           }
/*     */         } 
/* 135 */         if (sam.returnType != TypeBinding.VOID)
/*     */         {
/* 137 */           sam.returnType.collectInferenceVariables(variables);
/*     */         }
/* 139 */         return variables;
/*     */       } 
/* 141 */     } else if (this.left instanceof ReferenceExpression) {
/* 142 */       if (this.right instanceof InferenceVariable) {
/* 143 */         return Collections.singletonList((InferenceVariable)this.right);
/*     */       }
/* 145 */       if (this.right.isFunctionalInterface(context.scope)) {
/* 146 */         MethodBinding sam = this.right.getSingleAbstractMethod(context.scope, true);
/* 147 */         Set<InferenceVariable> variables = new LinkedHashSet<>();
/* 148 */         int len = sam.parameters.length;
/* 149 */         for (int i = 0; i < len; i++) {
/* 150 */           sam.parameters[i].collectInferenceVariables(variables);
/*     */         }
/* 152 */         sam.returnType.collectInferenceVariables(variables);
/* 153 */         return variables;
/*     */       } 
/*     */     } 
/* 156 */     return EMPTY_VARIABLE_LIST;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 161 */     StringBuffer buf = (new StringBuffer()).append('⟨');
/* 162 */     this.left.printExpression(4, buf);
/* 163 */     buf.append(" ⊆throws ");
/* 164 */     appendTypeName(buf, this.right);
/* 165 */     buf.append('⟩');
/* 166 */     return buf.toString();
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\lookup\ConstraintExceptionFormula.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */