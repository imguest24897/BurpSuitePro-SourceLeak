/*    */ package org.eclipse.jdt.internal.compiler.apt.model;
/*    */ 
/*    */ import javax.lang.model.element.Name;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NameImpl
/*    */   implements Name
/*    */ {
/*    */   private final String _name;
/*    */   
/*    */   private NameImpl() {
/* 31 */     this._name = null;
/*    */   }
/*    */ 
/*    */   
/*    */   public NameImpl(CharSequence cs) {
/* 36 */     this._name = cs.toString();
/*    */   }
/*    */ 
/*    */   
/*    */   public NameImpl(char[] chars) {
/* 41 */     this._name = String.valueOf(chars);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean contentEquals(CharSequence cs) {
/* 49 */     return this._name.equals(cs.toString());
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public char charAt(int index) {
/* 57 */     return this._name.charAt(index);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public int length() {
/* 65 */     return this._name.length();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public CharSequence subSequence(int start, int end) {
/* 73 */     return this._name.subSequence(start, end);
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 78 */     return this._name;
/*    */   }
/*    */ 
/*    */   
/*    */   public int hashCode() {
/* 83 */     return this._name.hashCode();
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean equals(Object obj) {
/* 88 */     if (this == obj)
/* 89 */       return true; 
/* 90 */     if (obj == null)
/* 91 */       return false; 
/* 92 */     if (getClass() != obj.getClass())
/* 93 */       return false; 
/* 94 */     NameImpl other = (NameImpl)obj;
/* 95 */     return this._name.equals(other._name);
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\apt\model\NameImpl.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */