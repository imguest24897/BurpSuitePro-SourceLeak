/*    */ package org.eclipse.jdt.internal.compiler.env;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface IModuleReference
/*    */ {
/*    */   char[] name();
/*    */   
/*    */   default boolean isTransitive() {
/* 52 */     return ((getModifiers() & 0x20) != 0);
/*    */   }
/*    */   
/*    */   default boolean isStatic() {
/* 56 */     return ((getModifiers() & 0x40) != 0);
/*    */   }
/*    */   
/*    */   int getModifiers();
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\env\IModule$IModuleReference.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */