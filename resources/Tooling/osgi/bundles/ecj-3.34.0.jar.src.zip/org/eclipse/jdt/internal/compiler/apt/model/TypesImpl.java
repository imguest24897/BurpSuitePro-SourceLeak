/*     */ package org.eclipse.jdt.internal.compiler.apt.model;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import javax.lang.model.element.Element;
/*     */ import javax.lang.model.element.ElementKind;
/*     */ import javax.lang.model.element.TypeElement;
/*     */ import javax.lang.model.type.ArrayType;
/*     */ import javax.lang.model.type.DeclaredType;
/*     */ import javax.lang.model.type.ExecutableType;
/*     */ import javax.lang.model.type.NoType;
/*     */ import javax.lang.model.type.NullType;
/*     */ import javax.lang.model.type.PrimitiveType;
/*     */ import javax.lang.model.type.TypeKind;
/*     */ import javax.lang.model.type.TypeMirror;
/*     */ import javax.lang.model.type.WildcardType;
/*     */ import javax.lang.model.util.Types;
/*     */ import org.eclipse.jdt.core.compiler.CharOperation;
/*     */ import org.eclipse.jdt.internal.compiler.apt.dispatch.BaseProcessingEnvImpl;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.BaseTypeBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.Binding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.FieldBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.MethodBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.ParameterizedTypeBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.RawTypeBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.ReferenceBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.TypeBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.TypeVariableBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.VariableBinding;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TypesImpl
/*     */   implements Types
/*     */ {
/*     */   private final BaseProcessingEnvImpl _env;
/*     */   
/*     */   public TypesImpl(BaseProcessingEnvImpl env) {
/*  63 */     this._env = env;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Element asElement(TypeMirror t) {
/*  71 */     switch (t.getKind()) {
/*     */       case DECLARED:
/*     */       case TYPEVAR:
/*  74 */         return this._env.getFactory().newElement(((TypeMirrorImpl)t).binding());
/*     */     } 
/*     */ 
/*     */     
/*  78 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TypeMirror asMemberOf(DeclaredType containing, Element element) {
/*     */     TypeMirror typeMirror;
/*  86 */     ElementImpl elementImpl = (ElementImpl)element;
/*  87 */     DeclaredTypeImpl declaredTypeImpl = (DeclaredTypeImpl)containing;
/*  88 */     ReferenceBinding referenceBinding = (ReferenceBinding)declaredTypeImpl._binding;
/*     */ 
/*     */     
/*  91 */     switch (element.getKind()) {
/*     */       case METHOD:
/*     */       case CONSTRUCTOR:
/*  94 */         typeMirror = findMemberInHierarchy(referenceBinding, elementImpl._binding, new MemberInTypeFinder()
/*     */             {
/*     */               public TypeMirror find(ReferenceBinding typeBinding, Binding memberBinding) {
/*  97 */                 MethodBinding methodBinding = (MethodBinding)memberBinding; byte b; int i; MethodBinding[] arrayOfMethodBinding;
/*  98 */                 for (i = (arrayOfMethodBinding = typeBinding.methods()).length, b = 0; b < i; ) { MethodBinding method = arrayOfMethodBinding[b];
/*  99 */                   if (CharOperation.equals(method.selector, methodBinding.selector) && (
/* 100 */                     method.original() == methodBinding || 
/* 101 */                     method.areParameterErasuresEqual(methodBinding)))
/* 102 */                     return TypesImpl.this._env.getFactory().newTypeMirror((Binding)method); 
/*     */                   b++; }
/*     */                 
/* 105 */                 return null;
/*     */               }
/*     */             });
/*     */         
/* 109 */         if (typeMirror != null) {
/* 110 */           return typeMirror;
/*     */         }
/*     */         break;
/*     */       case TYPE_PARAMETER:
/* 114 */         typeMirror = findMemberInHierarchy(referenceBinding, elementImpl._binding, new MemberInTypeFinder()
/*     */             {
/*     */               public TypeMirror find(ReferenceBinding typeBinding, Binding memberBinding) {
/* 117 */                 if (typeBinding instanceof ParameterizedTypeBinding) {
/* 118 */                   TypeVariableBinding variableBinding = (TypeVariableBinding)memberBinding;
/* 119 */                   ReferenceBinding binding = ((ParameterizedTypeBinding)typeBinding).genericType();
/* 120 */                   if (variableBinding.declaringElement == binding) {
/* 121 */                     TypeVariableBinding[] typeVariables = binding.typeVariables();
/* 122 */                     TypeBinding[] typeArguments = ((ParameterizedTypeBinding)typeBinding).typeArguments();
/* 123 */                     if (typeVariables.length == typeArguments.length) {
/* 124 */                       for (int i = 0; i < typeVariables.length; i++) {
/* 125 */                         if (typeVariables[i] == memberBinding) {
/* 126 */                           return TypesImpl.this._env.getFactory().newTypeMirror((Binding)typeArguments[i]);
/*     */                         }
/*     */                       } 
/*     */                     }
/*     */                   } 
/*     */                 } 
/* 132 */                 return null;
/*     */               }
/*     */             });
/*     */         
/* 136 */         if (typeMirror != null) {
/* 137 */           return typeMirror;
/*     */         }
/*     */         break;
/*     */       case ENUM_CONSTANT:
/*     */       case FIELD:
/*     */       case RECORD_COMPONENT:
/* 143 */         typeMirror = findMemberInHierarchy(referenceBinding, elementImpl._binding, new MemberInTypeFinder()
/*     */             {
/*     */               public TypeMirror find(ReferenceBinding typeBinding, Binding memberBinding) {
/* 146 */                 VariableBinding variableBinding = (VariableBinding)memberBinding; byte b; int i; FieldBinding[] arrayOfFieldBinding;
/* 147 */                 for (i = (arrayOfFieldBinding = typeBinding.fields()).length, b = 0; b < i; ) { FieldBinding field = arrayOfFieldBinding[b];
/* 148 */                   if (CharOperation.equals(field.name, variableBinding.name))
/* 149 */                     return TypesImpl.this._env.getFactory().newTypeMirror((Binding)field); 
/*     */                   b++; }
/*     */                 
/* 152 */                 return null;
/*     */               }
/*     */             });
/*     */         
/* 156 */         if (typeMirror != null) {
/* 157 */           return typeMirror;
/*     */         }
/*     */         break;
/*     */       case ENUM:
/*     */       case CLASS:
/*     */       case null:
/*     */       case INTERFACE:
/*     */       case RECORD:
/* 165 */         typeMirror = findMemberInHierarchy(referenceBinding, elementImpl._binding, new MemberInTypeFinder()
/*     */             {
/*     */               public TypeMirror find(ReferenceBinding typeBinding, Binding memberBinding) {
/* 168 */                 ReferenceBinding elementBinding = (ReferenceBinding)memberBinding;
/*     */                 
/*     */                 byte b;
/*     */                 
/*     */                 int i;
/*     */                 
/*     */                 ReferenceBinding[] arrayOfReferenceBinding;
/* 175 */                 for (i = (arrayOfReferenceBinding = typeBinding.memberTypes()).length, b = 0; b < i; ) { ReferenceBinding memberReferenceBinding = arrayOfReferenceBinding[b];
/* 176 */                   if (CharOperation.equals(elementBinding.compoundName, memberReferenceBinding.compoundName))
/* 177 */                     return TypesImpl.this._env.getFactory().newTypeMirror((Binding)memberReferenceBinding); 
/*     */                   b++; }
/*     */                 
/* 180 */                 return null;
/*     */               }
/*     */             });
/*     */         
/* 184 */         if (typeMirror != null) {
/* 185 */           return typeMirror;
/*     */         }
/*     */         break;
/*     */       default:
/* 189 */         throw new IllegalArgumentException("element " + element + 
/* 190 */             " has unrecognized element kind " + element.getKind());
/*     */     } 
/* 192 */     throw new IllegalArgumentException("element " + element + 
/* 193 */         " is not a member of the containing type " + containing + 
/* 194 */         " nor any of its superclasses");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private TypeMirror findMemberInHierarchy(ReferenceBinding typeBinding, Binding memberBinding, MemberInTypeFinder finder) {
/* 203 */     TypeMirror result = null;
/*     */     
/* 205 */     if (typeBinding == null) {
/* 206 */       return null;
/*     */     }
/*     */     
/* 209 */     result = finder.find(typeBinding, memberBinding);
/* 210 */     if (result != null) {
/* 211 */       return result;
/*     */     }
/*     */     
/* 214 */     result = findMemberInHierarchy(typeBinding.superclass(), memberBinding, finder);
/* 215 */     if (result != null)
/* 216 */       return result;  byte b;
/*     */     int i;
/*     */     ReferenceBinding[] arrayOfReferenceBinding;
/* 219 */     for (i = (arrayOfReferenceBinding = typeBinding.superInterfaces()).length, b = 0; b < i; ) { ReferenceBinding superInterface = arrayOfReferenceBinding[b];
/* 220 */       result = findMemberInHierarchy(superInterface, memberBinding, finder);
/* 221 */       if (result != null) {
/* 222 */         return result;
/*     */       }
/*     */       b++; }
/*     */     
/* 226 */     return null;
/*     */   }
/*     */   private void validateRealType(TypeMirror t) {
/* 229 */     switch (t.getKind()) {
/*     */       case PACKAGE:
/*     */       case EXECUTABLE:
/*     */       case MODULE:
/* 233 */         throw new IllegalArgumentException(
/* 234 */             "Executable, package and module are illegal argument for Types.contains(..)");
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private void validateRealTypes(TypeMirror t1, TypeMirror t2) {
/* 240 */     validateRealType(t1);
/* 241 */     validateRealType(t2);
/*     */   }
/*     */ 
/*     */   
/*     */   public TypeElement boxedClass(PrimitiveType p) {
/* 246 */     PrimitiveTypeImpl primitiveTypeImpl = (PrimitiveTypeImpl)p;
/* 247 */     BaseTypeBinding baseTypeBinding = (BaseTypeBinding)primitiveTypeImpl._binding;
/* 248 */     TypeBinding boxed = this._env.getLookupEnvironment().computeBoxingType((TypeBinding)baseTypeBinding);
/* 249 */     return (TypeElement)this._env.getFactory().newElement((Binding)boxed);
/*     */   }
/*     */ 
/*     */   
/*     */   public TypeMirror capture(TypeMirror t) {
/* 254 */     validateRealType(t);
/* 255 */     TypeMirrorImpl typeMirrorImpl = (TypeMirrorImpl)t;
/* 256 */     if (typeMirrorImpl._binding instanceof ParameterizedTypeBinding) {
/* 257 */       throw new UnsupportedOperationException("NYI: TypesImpl.capture(...)");
/*     */     }
/* 259 */     return t;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean contains(TypeMirror t1, TypeMirror t2) {
/* 264 */     validateRealTypes(t1, t2);
/* 265 */     throw new UnsupportedOperationException("NYI: TypesImpl.contains(" + t1 + ", " + t2 + ")");
/*     */   }
/*     */ 
/*     */   
/*     */   public List<? extends TypeMirror> directSupertypes(TypeMirror t) {
/* 270 */     validateRealType(t);
/* 271 */     TypeMirrorImpl typeMirrorImpl = (TypeMirrorImpl)t;
/* 272 */     Binding binding = typeMirrorImpl._binding;
/* 273 */     if (binding instanceof ReferenceBinding) {
/* 274 */       ReferenceBinding referenceBinding = (ReferenceBinding)binding;
/* 275 */       ArrayList<TypeMirror> list = new ArrayList<>();
/* 276 */       ReferenceBinding superclass = referenceBinding.superclass();
/* 277 */       if (superclass != null)
/* 278 */         list.add(this._env.getFactory().newTypeMirror((Binding)superclass));  byte b; int i;
/*     */       ReferenceBinding[] arrayOfReferenceBinding;
/* 280 */       for (i = (arrayOfReferenceBinding = referenceBinding.superInterfaces()).length, b = 0; b < i; ) { ReferenceBinding interfaceBinding = arrayOfReferenceBinding[b];
/* 281 */         list.add(this._env.getFactory().newTypeMirror((Binding)interfaceBinding)); b++; }
/*     */       
/* 283 */       return Collections.unmodifiableList(list);
/*     */     } 
/* 285 */     return Collections.emptyList();
/*     */   }
/*     */ 
/*     */   
/*     */   public TypeMirror erasure(TypeMirror t) {
/* 290 */     validateRealType(t);
/* 291 */     TypeMirrorImpl typeMirrorImpl = (TypeMirrorImpl)t;
/* 292 */     Binding binding = typeMirrorImpl._binding;
/* 293 */     if (binding instanceof ReferenceBinding) {
/* 294 */       TypeBinding type = ((ReferenceBinding)binding).erasure();
/* 295 */       if (type.isGenericType()) {
/* 296 */         type = this._env.getLookupEnvironment().convertToRawType(type, false);
/*     */       }
/* 298 */       return this._env.getFactory().newTypeMirror((Binding)type);
/*     */     } 
/* 300 */     if (binding instanceof org.eclipse.jdt.internal.compiler.lookup.ArrayBinding) {
/* 301 */       TypeBinding typeBinding = (TypeBinding)binding;
/* 302 */       TypeBinding leafType = typeBinding.leafComponentType().erasure();
/* 303 */       if (leafType.isGenericType()) {
/* 304 */         leafType = this._env.getLookupEnvironment().convertToRawType(leafType, false);
/*     */       }
/* 306 */       return this._env.getFactory().newTypeMirror(
/* 307 */           (Binding)this._env.getLookupEnvironment().createArrayType(leafType, 
/* 308 */             typeBinding.dimensions()));
/*     */     } 
/* 310 */     return t;
/*     */   }
/*     */ 
/*     */   
/*     */   public ArrayType getArrayType(TypeMirror componentType) {
/* 315 */     TypeMirrorImpl typeMirrorImpl = (TypeMirrorImpl)componentType;
/* 316 */     TypeBinding typeBinding = (TypeBinding)typeMirrorImpl._binding;
/* 317 */     return (ArrayType)this._env.getFactory().newTypeMirror(
/* 318 */         (Binding)this._env.getLookupEnvironment().createArrayType(
/* 319 */           typeBinding.leafComponentType(), 
/* 320 */           typeBinding.dimensions() + 1));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DeclaredType getDeclaredType(TypeElement typeElem, TypeMirror... typeArgs) {
/*     */     RawTypeBinding rawTypeBinding;
/* 333 */     int typeArgsLength = typeArgs.length;
/* 334 */     TypeElementImpl typeElementImpl = (TypeElementImpl)typeElem;
/* 335 */     ReferenceBinding elementBinding = (ReferenceBinding)typeElementImpl._binding;
/* 336 */     TypeVariableBinding[] typeVariables = elementBinding.typeVariables();
/* 337 */     int typeVariablesLength = typeVariables.length;
/* 338 */     if (typeArgsLength == 0) {
/* 339 */       if (elementBinding.isGenericType())
/*     */       {
/* 341 */         return (DeclaredType)this._env.getFactory().newTypeMirror((Binding)this._env.getLookupEnvironment().createRawType(elementBinding, null));
/*     */       }
/* 343 */       return (DeclaredType)typeElem.asType();
/* 344 */     }  if (typeArgsLength != typeVariablesLength) {
/* 345 */       throw new IllegalArgumentException("Number of typeArguments doesn't match the number of formal parameters of typeElem");
/*     */     }
/* 347 */     TypeBinding[] typeArguments = new TypeBinding[typeArgsLength];
/* 348 */     for (int i = 0; i < typeArgsLength; i++) {
/* 349 */       TypeMirrorImpl typeMirrorImpl = (TypeMirrorImpl)typeArgs[i];
/* 350 */       Binding binding = typeMirrorImpl._binding;
/* 351 */       if (!(binding instanceof TypeBinding)) {
/* 352 */         throw new IllegalArgumentException("Invalid type argument: " + typeMirrorImpl);
/*     */       }
/* 354 */       typeArguments[i] = (TypeBinding)binding;
/*     */     } 
/*     */     
/* 357 */     ReferenceBinding enclosing = elementBinding.enclosingType();
/* 358 */     if (enclosing != null) {
/* 359 */       rawTypeBinding = this._env.getLookupEnvironment().createRawType(enclosing, null);
/*     */     }
/*     */     
/* 362 */     return (DeclaredType)this._env.getFactory().newTypeMirror(
/* 363 */         (Binding)this._env.getLookupEnvironment().createParameterizedType(elementBinding, typeArguments, (ReferenceBinding)rawTypeBinding));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DeclaredType getDeclaredType(DeclaredType containing, TypeElement typeElem, TypeMirror... typeArgs) {
/* 377 */     int typeArgsLength = typeArgs.length;
/* 378 */     TypeElementImpl typeElementImpl = (TypeElementImpl)typeElem;
/* 379 */     ReferenceBinding elementBinding = (ReferenceBinding)typeElementImpl._binding;
/* 380 */     TypeVariableBinding[] typeVariables = elementBinding.typeVariables();
/* 381 */     int typeVariablesLength = typeVariables.length;
/* 382 */     DeclaredTypeImpl declaredTypeImpl = (DeclaredTypeImpl)containing;
/* 383 */     ReferenceBinding enclosingType = (ReferenceBinding)declaredTypeImpl._binding;
/* 384 */     if (typeArgsLength == 0) {
/* 385 */       if (elementBinding.isGenericType())
/*     */       {
/*     */         
/* 388 */         return (DeclaredType)this._env.getFactory().newTypeMirror(
/* 389 */             (Binding)this._env.getLookupEnvironment().createRawType(elementBinding, enclosingType));
/*     */       }
/*     */       
/* 392 */       ParameterizedTypeBinding ptb = this._env.getLookupEnvironment().createParameterizedType(elementBinding, null, enclosingType);
/* 393 */       return (DeclaredType)this._env.getFactory().newTypeMirror((Binding)ptb);
/*     */     } 
/* 395 */     if (typeArgsLength != typeVariablesLength) {
/* 396 */       throw new IllegalArgumentException("Number of typeArguments doesn't match the number of formal parameters of typeElem");
/*     */     }
/* 398 */     TypeBinding[] typeArguments = new TypeBinding[typeArgsLength];
/* 399 */     for (int i = 0; i < typeArgsLength; i++) {
/* 400 */       TypeMirrorImpl typeMirrorImpl = (TypeMirrorImpl)typeArgs[i];
/* 401 */       Binding binding = typeMirrorImpl._binding;
/* 402 */       if (!(binding instanceof TypeBinding)) {
/* 403 */         throw new IllegalArgumentException("Invalid type for a type arguments : " + typeMirrorImpl);
/*     */       }
/* 405 */       typeArguments[i] = (TypeBinding)binding;
/*     */     } 
/* 407 */     return (DeclaredType)this._env.getFactory().newTypeMirror(
/* 408 */         (Binding)this._env.getLookupEnvironment().createParameterizedType(elementBinding, typeArguments, enclosingType));
/*     */   }
/*     */ 
/*     */   
/*     */   public NoType getNoType(TypeKind kind) {
/* 413 */     return this._env.getFactory().getNoType(kind);
/*     */   }
/*     */ 
/*     */   
/*     */   public NullType getNullType() {
/* 418 */     return this._env.getFactory().getNullType();
/*     */   }
/*     */ 
/*     */   
/*     */   public PrimitiveType getPrimitiveType(TypeKind kind) {
/* 423 */     return this._env.getFactory().getPrimitiveType(kind);
/*     */   }
/*     */ 
/*     */   
/*     */   public WildcardType getWildcardType(TypeMirror extendsBound, TypeMirror superBound) {
/* 428 */     if (extendsBound != null && superBound != null) {
/* 429 */       throw new IllegalArgumentException("Extends and super bounds cannot be set at the same time");
/*     */     }
/* 431 */     if (extendsBound != null) {
/* 432 */       TypeMirrorImpl extendsBoundMirrorType = (TypeMirrorImpl)extendsBound;
/* 433 */       TypeBinding typeBinding = (TypeBinding)extendsBoundMirrorType._binding;
/* 434 */       return (WildcardType)this._env.getFactory().newTypeMirror(
/* 435 */           (Binding)this._env.getLookupEnvironment().createWildcard(
/* 436 */             null, 
/* 437 */             0, 
/* 438 */             typeBinding, 
/* 439 */             null, 
/* 440 */             1));
/*     */     } 
/* 442 */     if (superBound != null) {
/* 443 */       TypeMirrorImpl superBoundMirrorType = (TypeMirrorImpl)superBound;
/* 444 */       TypeBinding typeBinding = (TypeBinding)superBoundMirrorType._binding;
/* 445 */       return new WildcardTypeImpl(this._env, this._env.getLookupEnvironment().createWildcard(
/* 446 */             null, 
/* 447 */             0, 
/* 448 */             typeBinding, 
/* 449 */             null, 
/* 450 */             2));
/*     */     } 
/* 452 */     return new WildcardTypeImpl(this._env, this._env.getLookupEnvironment().createWildcard(
/* 453 */           null, 
/* 454 */           0, 
/* 455 */           null, 
/* 456 */           null, 
/* 457 */           0));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isAssignable(TypeMirror t1, TypeMirror t2) {
/* 465 */     validateRealTypes(t1, t2);
/* 466 */     if (!(t1 instanceof TypeMirrorImpl) || !(t2 instanceof TypeMirrorImpl)) {
/* 467 */       return false;
/*     */     }
/* 469 */     Binding b1 = ((TypeMirrorImpl)t1).binding();
/* 470 */     Binding b2 = ((TypeMirrorImpl)t2).binding();
/* 471 */     if (!(b1 instanceof TypeBinding) || !(b2 instanceof TypeBinding))
/*     */     {
/* 473 */       throw new IllegalArgumentException();
/*     */     }
/* 475 */     if (((TypeBinding)b1).isCompatibleWith((TypeBinding)b2)) {
/* 476 */       return true;
/*     */     }
/*     */     
/* 479 */     TypeBinding convertedType = this._env.getLookupEnvironment().computeBoxingType((TypeBinding)b1);
/* 480 */     return (convertedType != null && convertedType.isCompatibleWith((TypeBinding)b2));
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isSameType(TypeMirror t1, TypeMirror t2) {
/* 485 */     if (t1 instanceof NoTypeImpl) {
/* 486 */       if (t2 instanceof NoTypeImpl) {
/* 487 */         return (((NoTypeImpl)t1).getKind() == ((NoTypeImpl)t2).getKind());
/*     */       }
/* 489 */       return false;
/* 490 */     }  if (t2 instanceof NoTypeImpl) {
/* 491 */       return false;
/*     */     }
/* 493 */     if (t1.getKind() == TypeKind.WILDCARD || t2.getKind() == TypeKind.WILDCARD)
/*     */     {
/* 495 */       return false;
/*     */     }
/* 497 */     if (t1 == t2) {
/* 498 */       return true;
/*     */     }
/* 500 */     if (!(t1 instanceof TypeMirrorImpl) || !(t2 instanceof TypeMirrorImpl)) {
/* 501 */       return false;
/*     */     }
/* 503 */     Binding b1 = ((TypeMirrorImpl)t1).binding();
/* 504 */     Binding b2 = ((TypeMirrorImpl)t2).binding();
/*     */     
/* 506 */     if (b1 == b2) {
/* 507 */       return true;
/*     */     }
/* 509 */     if (!(b1 instanceof TypeBinding) || !(b2 instanceof TypeBinding)) {
/* 510 */       return false;
/*     */     }
/* 512 */     TypeBinding type1 = (TypeBinding)b1;
/* 513 */     TypeBinding type2 = (TypeBinding)b2;
/* 514 */     if (TypeBinding.equalsEquals(type1, type2))
/* 515 */       return true; 
/* 516 */     return CharOperation.equals(type1.computeUniqueKey(), type2.computeUniqueKey());
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isSubsignature(ExecutableType m1, ExecutableType m2) {
/* 521 */     MethodBinding methodBinding1 = (MethodBinding)((ExecutableTypeImpl)m1)._binding;
/* 522 */     MethodBinding methodBinding2 = (MethodBinding)((ExecutableTypeImpl)m2)._binding;
/* 523 */     if (!CharOperation.equals(methodBinding1.selector, methodBinding2.selector))
/* 524 */       return false; 
/* 525 */     return (methodBinding1.areParameterErasuresEqual(methodBinding2) && methodBinding1.areTypeVariableErasuresEqual(methodBinding2));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isSubtype(TypeMirror t1, TypeMirror t2) {
/* 533 */     validateRealTypes(t1, t2);
/* 534 */     if (t1 instanceof NoTypeImpl) {
/* 535 */       if (t2 instanceof NoTypeImpl) {
/* 536 */         return (((NoTypeImpl)t1).getKind() == ((NoTypeImpl)t2).getKind());
/*     */       }
/* 538 */       return false;
/* 539 */     }  if (t2 instanceof NoTypeImpl) {
/* 540 */       return false;
/*     */     }
/* 542 */     if (!(t1 instanceof TypeMirrorImpl) || !(t2 instanceof TypeMirrorImpl)) {
/* 543 */       throw new IllegalArgumentException();
/*     */     }
/* 545 */     if (t1 == t2) {
/* 546 */       return true;
/*     */     }
/* 548 */     Binding b1 = ((TypeMirrorImpl)t1).binding();
/* 549 */     Binding b2 = ((TypeMirrorImpl)t2).binding();
/* 550 */     if (b1 == b2) {
/* 551 */       return true;
/*     */     }
/* 553 */     if (!(b1 instanceof TypeBinding) || !(b2 instanceof TypeBinding))
/*     */     {
/* 555 */       throw new IllegalArgumentException();
/*     */     }
/* 557 */     if (b1.kind() == 132 || b2.kind() == 132) {
/* 558 */       if (b1.kind() != b2.kind()) {
/* 559 */         return false;
/*     */       }
/*     */ 
/*     */       
/* 563 */       return ((TypeBinding)b1).isCompatibleWith((TypeBinding)b2);
/*     */     } 
/*     */     
/* 566 */     return ((TypeBinding)b1).isCompatibleWith((TypeBinding)b2);
/*     */   }
/*     */ 
/*     */   
/*     */   public PrimitiveType unboxedType(TypeMirror t) {
/* 571 */     if (!(((TypeMirrorImpl)t)._binding instanceof ReferenceBinding))
/*     */     {
/* 573 */       throw new IllegalArgumentException("Given type mirror cannot be unboxed");
/*     */     }
/* 575 */     ReferenceBinding boxed = (ReferenceBinding)((TypeMirrorImpl)t)._binding;
/* 576 */     TypeBinding unboxed = this._env.getLookupEnvironment().computeBoxingType((TypeBinding)boxed);
/* 577 */     if (unboxed.kind() != 132)
/*     */     {
/* 579 */       throw new IllegalArgumentException();
/*     */     }
/* 581 */     return (PrimitiveType)this._env.getFactory().newTypeMirror((Binding)unboxed);
/*     */   }
/*     */   
/*     */   private static interface MemberInTypeFinder {
/*     */     TypeMirror find(ReferenceBinding param1ReferenceBinding, Binding param1Binding);
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\apt\model\TypesImpl.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */