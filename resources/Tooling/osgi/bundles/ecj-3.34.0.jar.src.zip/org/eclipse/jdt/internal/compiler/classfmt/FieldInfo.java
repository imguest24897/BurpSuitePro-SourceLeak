/*     */ package org.eclipse.jdt.internal.compiler.classfmt;
/*     */ 
/*     */ import org.eclipse.jdt.core.compiler.CharOperation;
/*     */ import org.eclipse.jdt.internal.compiler.codegen.AttributeNamesConstants;
/*     */ import org.eclipse.jdt.internal.compiler.env.IBinaryAnnotation;
/*     */ import org.eclipse.jdt.internal.compiler.env.IBinaryField;
/*     */ import org.eclipse.jdt.internal.compiler.env.IBinaryTypeAnnotation;
/*     */ import org.eclipse.jdt.internal.compiler.impl.BooleanConstant;
/*     */ import org.eclipse.jdt.internal.compiler.impl.ByteConstant;
/*     */ import org.eclipse.jdt.internal.compiler.impl.CharConstant;
/*     */ import org.eclipse.jdt.internal.compiler.impl.Constant;
/*     */ import org.eclipse.jdt.internal.compiler.impl.DoubleConstant;
/*     */ import org.eclipse.jdt.internal.compiler.impl.FloatConstant;
/*     */ import org.eclipse.jdt.internal.compiler.impl.IntConstant;
/*     */ import org.eclipse.jdt.internal.compiler.impl.LongConstant;
/*     */ import org.eclipse.jdt.internal.compiler.impl.ShortConstant;
/*     */ import org.eclipse.jdt.internal.compiler.impl.StringConstant;
/*     */ import org.eclipse.jdt.internal.compiler.util.Util;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FieldInfo
/*     */   extends ClassFileStruct
/*     */   implements IBinaryField, Comparable
/*     */ {
/*     */   protected int accessFlags;
/*     */   protected int attributeBytes;
/*     */   protected Constant constant;
/*     */   protected char[] descriptor;
/*     */   protected char[] name;
/*     */   protected char[] signature;
/*     */   protected int signatureUtf8Offset;
/*     */   protected long tagBits;
/*     */   protected Object wrappedConstantValue;
/*     */   protected long version;
/*     */   
/*     */   public static FieldInfo createField(byte[] classFileBytes, int[] offsets, int offset, long version) {
/*  42 */     FieldInfo fieldInfo = new FieldInfo(classFileBytes, offsets, offset, version);
/*     */     
/*  44 */     int attributesCount = fieldInfo.u2At(6);
/*  45 */     int readOffset = 8;
/*  46 */     AnnotationInfo[] annotations = null;
/*  47 */     TypeAnnotationInfo[] typeAnnotations = null;
/*  48 */     for (int i = 0; i < attributesCount; i++) {
/*     */       
/*  50 */       int utf8Offset = fieldInfo.constantPoolOffsets[fieldInfo.u2At(readOffset)] - fieldInfo.structOffset;
/*  51 */       char[] attributeName = fieldInfo.utf8At(utf8Offset + 3, fieldInfo.u2At(utf8Offset + 1));
/*  52 */       if (attributeName.length > 0) {
/*  53 */         AnnotationInfo[] decodedAnnotations; TypeAnnotationInfo[] decodedTypeAnnotations; switch (attributeName[0]) {
/*     */           case 'S':
/*  55 */             if (CharOperation.equals(AttributeNamesConstants.SignatureName, attributeName))
/*  56 */               fieldInfo.signatureUtf8Offset = fieldInfo.constantPoolOffsets[fieldInfo.u2At(readOffset + 6)] - fieldInfo.structOffset; 
/*     */             break;
/*     */           case 'R':
/*  59 */             decodedAnnotations = null;
/*  60 */             decodedTypeAnnotations = null;
/*  61 */             if (CharOperation.equals(attributeName, AttributeNamesConstants.RuntimeVisibleAnnotationsName)) {
/*  62 */               decodedAnnotations = fieldInfo.decodeAnnotations(readOffset, true);
/*  63 */             } else if (CharOperation.equals(attributeName, AttributeNamesConstants.RuntimeInvisibleAnnotationsName)) {
/*  64 */               decodedAnnotations = fieldInfo.decodeAnnotations(readOffset, false);
/*  65 */             } else if (CharOperation.equals(attributeName, AttributeNamesConstants.RuntimeVisibleTypeAnnotationsName)) {
/*  66 */               decodedTypeAnnotations = fieldInfo.decodeTypeAnnotations(readOffset, true);
/*  67 */             } else if (CharOperation.equals(attributeName, AttributeNamesConstants.RuntimeInvisibleTypeAnnotationsName)) {
/*  68 */               decodedTypeAnnotations = fieldInfo.decodeTypeAnnotations(readOffset, false);
/*     */             } 
/*  70 */             if (decodedAnnotations != null) {
/*  71 */               if (annotations == null) {
/*  72 */                 annotations = decodedAnnotations; break;
/*     */               } 
/*  74 */               int length = annotations.length;
/*  75 */               AnnotationInfo[] combined = new AnnotationInfo[length + decodedAnnotations.length];
/*  76 */               System.arraycopy(annotations, 0, combined, 0, length);
/*  77 */               System.arraycopy(decodedAnnotations, 0, combined, length, decodedAnnotations.length);
/*  78 */               annotations = combined; break;
/*     */             } 
/*  80 */             if (decodedTypeAnnotations != null) {
/*  81 */               if (typeAnnotations == null) {
/*  82 */                 typeAnnotations = decodedTypeAnnotations; break;
/*     */               } 
/*  84 */               int length = typeAnnotations.length;
/*  85 */               TypeAnnotationInfo[] combined = new TypeAnnotationInfo[length + decodedTypeAnnotations.length];
/*  86 */               System.arraycopy(typeAnnotations, 0, combined, 0, length);
/*  87 */               System.arraycopy(decodedTypeAnnotations, 0, combined, length, decodedTypeAnnotations.length);
/*  88 */               typeAnnotations = combined;
/*     */             } 
/*     */             break;
/*     */         } 
/*     */       } 
/*  93 */       readOffset = (int)(readOffset + 6L + fieldInfo.u4At(readOffset + 2));
/*     */     } 
/*  95 */     fieldInfo.attributeBytes = readOffset;
/*     */     
/*  97 */     if (typeAnnotations != null)
/*  98 */       return new FieldInfoWithTypeAnnotation(fieldInfo, annotations, typeAnnotations); 
/*  99 */     if (annotations != null)
/* 100 */       return new FieldInfoWithAnnotation(fieldInfo, annotations); 
/* 101 */     return fieldInfo;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected FieldInfo(byte[] classFileBytes, int[] offsets, int offset, long version) {
/* 111 */     super(classFileBytes, offsets, offset);
/* 112 */     this.accessFlags = -1;
/* 113 */     this.signatureUtf8Offset = -1;
/* 114 */     this.version = version;
/*     */   }
/*     */   private AnnotationInfo[] decodeAnnotations(int offset, boolean runtimeVisible) {
/* 117 */     int numberOfAnnotations = u2At(offset + 6);
/* 118 */     if (numberOfAnnotations > 0) {
/* 119 */       int readOffset = offset + 8;
/* 120 */       AnnotationInfo[] newInfos = null;
/* 121 */       int newInfoCount = 0;
/* 122 */       for (int i = 0; i < numberOfAnnotations; i++) {
/*     */         
/* 124 */         AnnotationInfo newInfo = new AnnotationInfo(this.reference, this.constantPoolOffsets, 
/* 125 */             readOffset + this.structOffset, runtimeVisible, false);
/* 126 */         readOffset += newInfo.readOffset;
/* 127 */         long standardTagBits = newInfo.standardAnnotationTagBits;
/* 128 */         if (standardTagBits != 0L) {
/* 129 */           this.tagBits |= standardTagBits;
/* 130 */           if (this.version < 3473408L || (standardTagBits & 0x400000000000L) == 0L)
/*     */             continue; 
/*     */         } 
/* 133 */         if (newInfos == null)
/* 134 */           newInfos = new AnnotationInfo[numberOfAnnotations - i]; 
/* 135 */         newInfos[newInfoCount++] = newInfo; continue;
/*     */       } 
/* 137 */       if (newInfos != null) {
/* 138 */         if (newInfoCount != newInfos.length)
/* 139 */           System.arraycopy(newInfos, 0, newInfos = new AnnotationInfo[newInfoCount], 0, newInfoCount); 
/* 140 */         return newInfos;
/*     */       } 
/*     */     } 
/* 143 */     return null;
/*     */   }
/*     */   
/*     */   TypeAnnotationInfo[] decodeTypeAnnotations(int offset, boolean runtimeVisible) {
/* 147 */     int numberOfAnnotations = u2At(offset + 6);
/* 148 */     if (numberOfAnnotations > 0) {
/* 149 */       int readOffset = offset + 8;
/* 150 */       TypeAnnotationInfo[] typeAnnos = new TypeAnnotationInfo[numberOfAnnotations];
/* 151 */       for (int i = 0; i < numberOfAnnotations; i++) {
/* 152 */         TypeAnnotationInfo newInfo = new TypeAnnotationInfo(this.reference, this.constantPoolOffsets, readOffset + this.structOffset, runtimeVisible, false);
/* 153 */         readOffset += newInfo.readOffset;
/* 154 */         typeAnnos[i] = newInfo;
/*     */       } 
/* 156 */       return typeAnnos;
/*     */     } 
/* 158 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public int compareTo(Object o) {
/* 163 */     return (new String(getName())).compareTo(new String(((FieldInfo)o).getName()));
/*     */   }
/*     */   
/*     */   public boolean equals(Object o) {
/* 167 */     if (!(o instanceof FieldInfo)) {
/* 168 */       return false;
/*     */     }
/* 170 */     return CharOperation.equals(getName(), ((FieldInfo)o).getName());
/*     */   }
/*     */   
/*     */   public int hashCode() {
/* 174 */     return CharOperation.hashCode(getName());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Constant getConstant() {
/* 183 */     if (this.constant == null)
/*     */     {
/* 185 */       readConstantAttribute();
/*     */     }
/* 187 */     return this.constant;
/*     */   }
/*     */   
/*     */   public char[] getGenericSignature() {
/* 191 */     if (this.signatureUtf8Offset != -1) {
/* 192 */       if (this.signature == null)
/*     */       {
/* 194 */         this.signature = utf8At(this.signatureUtf8Offset + 3, u2At(this.signatureUtf8Offset + 1));
/*     */       }
/* 196 */       return this.signature;
/*     */     } 
/* 198 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getModifiers() {
/* 208 */     if (this.accessFlags == -1) {
/*     */       
/* 210 */       this.accessFlags = u2At(0);
/* 211 */       readModifierRelatedAttributes();
/*     */     } 
/* 213 */     return this.accessFlags;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public char[] getName() {
/* 221 */     if (this.name == null) {
/*     */       
/* 223 */       int utf8Offset = this.constantPoolOffsets[u2At(2)] - this.structOffset;
/* 224 */       this.name = utf8At(utf8Offset + 3, u2At(utf8Offset + 1));
/*     */     } 
/* 226 */     return this.name;
/*     */   }
/*     */   
/*     */   public long getTagBits() {
/* 230 */     return this.tagBits;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public char[] getTypeName() {
/* 245 */     if (this.descriptor == null) {
/*     */       
/* 247 */       int utf8Offset = this.constantPoolOffsets[u2At(4)] - this.structOffset;
/* 248 */       this.descriptor = utf8At(utf8Offset + 3, u2At(utf8Offset + 1));
/*     */     } 
/* 250 */     return this.descriptor;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IBinaryAnnotation[] getAnnotations() {
/* 257 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public IBinaryTypeAnnotation[] getTypeAnnotations() {
/* 262 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object getWrappedConstantValue() {
/* 270 */     if (this.wrappedConstantValue == null && 
/* 271 */       hasConstant()) {
/* 272 */       Constant fieldConstant = getConstant();
/* 273 */       switch (fieldConstant.typeID()) {
/*     */         case 10:
/* 275 */           this.wrappedConstantValue = Integer.valueOf(fieldConstant.intValue());
/*     */           break;
/*     */         case 3:
/* 278 */           this.wrappedConstantValue = Byte.valueOf(fieldConstant.byteValue());
/*     */           break;
/*     */         case 4:
/* 281 */           this.wrappedConstantValue = Short.valueOf(fieldConstant.shortValue());
/*     */           break;
/*     */         case 2:
/* 284 */           this.wrappedConstantValue = Character.valueOf(fieldConstant.charValue());
/*     */           break;
/*     */         case 9:
/* 287 */           this.wrappedConstantValue = Float.valueOf(fieldConstant.floatValue());
/*     */           break;
/*     */         case 8:
/* 290 */           this.wrappedConstantValue = Double.valueOf(fieldConstant.doubleValue());
/*     */           break;
/*     */         case 5:
/* 293 */           this.wrappedConstantValue = Util.toBoolean(fieldConstant.booleanValue());
/*     */           break;
/*     */         case 7:
/* 296 */           this.wrappedConstantValue = Long.valueOf(fieldConstant.longValue());
/*     */           break;
/*     */         case 11:
/* 299 */           this.wrappedConstantValue = fieldConstant.stringValue();
/*     */           break;
/*     */       } 
/*     */     } 
/* 303 */     return this.wrappedConstantValue;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean hasConstant() {
/* 310 */     return (getConstant() != Constant.NotAConstant);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void initialize() {
/* 317 */     getModifiers();
/* 318 */     getName();
/* 319 */     getConstant();
/* 320 */     getTypeName();
/* 321 */     getGenericSignature();
/* 322 */     reset();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isSynthetic() {
/* 329 */     return ((getModifiers() & 0x1000) != 0);
/*     */   }
/*     */   private void readConstantAttribute() {
/* 332 */     int attributesCount = u2At(6);
/* 333 */     int readOffset = 8;
/* 334 */     boolean isConstant = false;
/* 335 */     for (int i = 0; i < attributesCount; i++) {
/* 336 */       int utf8Offset = this.constantPoolOffsets[u2At(readOffset)] - this.structOffset;
/* 337 */       char[] attributeName = utf8At(utf8Offset + 3, u2At(utf8Offset + 1));
/*     */       
/* 339 */       if (CharOperation.equals(attributeName, AttributeNamesConstants.ConstantValueName)) {
/* 340 */         char[] sign; isConstant = true;
/*     */         
/* 342 */         int relativeOffset = this.constantPoolOffsets[u2At(readOffset + 6)] - this.structOffset;
/* 343 */         switch (u1At(relativeOffset)) {
/*     */           case 3:
/* 345 */             sign = getTypeName();
/* 346 */             if (sign.length == 1) {
/* 347 */               switch (sign[0]) {
/*     */                 case 'Z':
/* 349 */                   this.constant = BooleanConstant.fromValue((i4At(relativeOffset + 1) == 1));
/*     */                   break;
/*     */                 case 'I':
/* 352 */                   this.constant = IntConstant.fromValue(i4At(relativeOffset + 1));
/*     */                   break;
/*     */                 case 'C':
/* 355 */                   this.constant = CharConstant.fromValue((char)i4At(relativeOffset + 1));
/*     */                   break;
/*     */                 case 'B':
/* 358 */                   this.constant = ByteConstant.fromValue((byte)i4At(relativeOffset + 1));
/*     */                   break;
/*     */                 case 'S':
/* 361 */                   this.constant = ShortConstant.fromValue((short)i4At(relativeOffset + 1));
/*     */                   break;
/*     */               } 
/* 364 */               this.constant = Constant.NotAConstant;
/*     */               break;
/*     */             } 
/* 367 */             this.constant = Constant.NotAConstant;
/*     */             break;
/*     */           
/*     */           case 4:
/* 371 */             this.constant = FloatConstant.fromValue(floatAt(relativeOffset + 1));
/*     */             break;
/*     */           case 6:
/* 374 */             this.constant = DoubleConstant.fromValue(doubleAt(relativeOffset + 1));
/*     */             break;
/*     */           case 5:
/* 377 */             this.constant = LongConstant.fromValue(i8At(relativeOffset + 1));
/*     */             break;
/*     */           case 8:
/* 380 */             utf8Offset = this.constantPoolOffsets[u2At(relativeOffset + 1)] - this.structOffset;
/* 381 */             this.constant = 
/* 382 */               StringConstant.fromValue(
/* 383 */                 String.valueOf(utf8At(utf8Offset + 3, u2At(utf8Offset + 1))));
/*     */             break;
/*     */         } 
/*     */       } 
/* 387 */       readOffset = (int)(readOffset + 6L + u4At(readOffset + 2));
/*     */     } 
/* 389 */     if (!isConstant)
/* 390 */       this.constant = Constant.NotAConstant; 
/*     */   }
/*     */   
/*     */   private void readModifierRelatedAttributes() {
/* 394 */     int attributesCount = u2At(6);
/* 395 */     int readOffset = 8;
/* 396 */     for (int i = 0; i < attributesCount; i++) {
/* 397 */       int utf8Offset = this.constantPoolOffsets[u2At(readOffset)] - this.structOffset;
/* 398 */       char[] attributeName = utf8At(utf8Offset + 3, u2At(utf8Offset + 1));
/*     */       
/* 400 */       if (attributeName.length != 0)
/* 401 */         switch (attributeName[0]) {
/*     */           case 'D':
/* 403 */             if (CharOperation.equals(attributeName, AttributeNamesConstants.DeprecatedName))
/* 404 */               this.accessFlags |= 0x100000; 
/*     */             break;
/*     */           case 'S':
/* 407 */             if (CharOperation.equals(attributeName, AttributeNamesConstants.SyntheticName)) {
/* 408 */               this.accessFlags |= 0x1000;
/*     */             }
/*     */             break;
/*     */         }  
/* 412 */       readOffset = (int)(readOffset + 6L + u4At(readOffset + 2));
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int sizeInBytes() {
/* 421 */     return this.attributeBytes;
/*     */   }
/*     */   public void throwFormatException() throws ClassFormatException {
/* 424 */     throw new ClassFormatException(17);
/*     */   }
/*     */   
/*     */   public String toString() {
/* 428 */     StringBuffer buffer = new StringBuffer(getClass().getName());
/* 429 */     toStringContent(buffer);
/* 430 */     return buffer.toString();
/*     */   }
/*     */   protected void toStringContent(StringBuffer buffer) {
/* 433 */     int modifiers = getModifiers();
/* 434 */     buffer
/* 435 */       .append('{')
/* 436 */       .append(
/* 437 */         String.valueOf(((modifiers & 0x100000) != 0) ? "deprecated " : Util.EMPTY_STRING) + (
/* 438 */         ((modifiers & 0x1) == 1) ? "public " : Util.EMPTY_STRING) + (
/* 439 */         ((modifiers & 0x2) == 2) ? "private " : Util.EMPTY_STRING) + (
/* 440 */         ((modifiers & 0x4) == 4) ? "protected " : Util.EMPTY_STRING) + (
/* 441 */         ((modifiers & 0x8) == 8) ? "static " : Util.EMPTY_STRING) + (
/* 442 */         ((modifiers & 0x10) == 16) ? "final " : Util.EMPTY_STRING) + (
/* 443 */         ((modifiers & 0x40) == 64) ? "volatile " : Util.EMPTY_STRING) + (
/* 444 */         ((modifiers & 0x80) == 128) ? "transient " : Util.EMPTY_STRING))
/* 445 */       .append(getTypeName())
/* 446 */       .append(' ')
/* 447 */       .append(getName())
/* 448 */       .append(' ')
/* 449 */       .append(getConstant())
/* 450 */       .append('}')
/* 451 */       .toString();
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\classfmt\FieldInfo.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */