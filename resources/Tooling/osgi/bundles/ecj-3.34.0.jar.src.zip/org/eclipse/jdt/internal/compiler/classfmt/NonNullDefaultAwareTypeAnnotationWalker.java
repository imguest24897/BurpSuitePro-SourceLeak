/*     */ package org.eclipse.jdt.internal.compiler.classfmt;
/*     */ 
/*     */ import org.eclipse.jdt.core.compiler.CharOperation;
/*     */ import org.eclipse.jdt.internal.compiler.env.IBinaryAnnotation;
/*     */ import org.eclipse.jdt.internal.compiler.env.IBinaryElementValuePair;
/*     */ import org.eclipse.jdt.internal.compiler.env.IBinaryTypeAnnotation;
/*     */ import org.eclipse.jdt.internal.compiler.env.ITypeAnnotationWalker;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.LookupEnvironment;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class NonNullDefaultAwareTypeAnnotationWalker
/*     */   extends TypeAnnotationWalker
/*     */ {
/*     */   private final int defaultNullness;
/*     */   private final boolean atDefaultLocation;
/*     */   private final boolean atTypeBound;
/*     */   private final boolean currentArrayContentIsNonNull;
/*     */   private final boolean isEmpty;
/*     */   private final IBinaryAnnotation nonNullAnnotation;
/*     */   private final LookupEnvironment environment;
/*     */   private boolean nextIsDefaultLocation;
/*     */   private boolean nextIsTypeBound;
/*     */   private boolean nextArrayContentIsNonNull;
/*     */   
/*     */   public NonNullDefaultAwareTypeAnnotationWalker(IBinaryTypeAnnotation[] typeAnnotations, int defaultNullness, LookupEnvironment environment) {
/*  46 */     super(typeAnnotations);
/*  47 */     this.nonNullAnnotation = getNonNullAnnotation(environment);
/*  48 */     this.defaultNullness = defaultNullness;
/*  49 */     this.environment = environment;
/*  50 */     this.atDefaultLocation = false;
/*  51 */     this.atTypeBound = false;
/*  52 */     this.isEmpty = false;
/*  53 */     this.currentArrayContentIsNonNull = false;
/*     */   }
/*     */ 
/*     */   
/*     */   public NonNullDefaultAwareTypeAnnotationWalker(int defaultNullness, LookupEnvironment environment) {
/*  58 */     this(defaultNullness, getNonNullAnnotation(environment), false, false, environment, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   NonNullDefaultAwareTypeAnnotationWalker(IBinaryTypeAnnotation[] typeAnnotations, long newMatches, int newPathPtr, int defaultNullness, IBinaryAnnotation nonNullAnnotation, boolean atDefaultLocation, boolean atTypeBound, LookupEnvironment environment, boolean currentArrayContentIsNonNull) {
/*  65 */     super(typeAnnotations, newMatches, newPathPtr);
/*  66 */     this.defaultNullness = defaultNullness;
/*  67 */     this.nonNullAnnotation = nonNullAnnotation;
/*  68 */     this.atDefaultLocation = atDefaultLocation;
/*  69 */     this.atTypeBound = atTypeBound;
/*  70 */     this.environment = environment;
/*  71 */     this.currentArrayContentIsNonNull = this.nextArrayContentIsNonNull = currentArrayContentIsNonNull;
/*  72 */     this.isEmpty = false;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   NonNullDefaultAwareTypeAnnotationWalker(int defaultNullness, IBinaryAnnotation nonNullAnnotation, boolean atDefaultLocation, boolean atTypeBound, LookupEnvironment environment, boolean currentArrayContentIsNonNull) {
/*  78 */     super((IBinaryTypeAnnotation[])null, 0L, 0);
/*  79 */     this.nonNullAnnotation = nonNullAnnotation;
/*  80 */     this.defaultNullness = defaultNullness;
/*  81 */     this.atDefaultLocation = atDefaultLocation;
/*  82 */     this.atTypeBound = atTypeBound;
/*  83 */     this.isEmpty = true;
/*  84 */     this.environment = environment;
/*  85 */     this.currentArrayContentIsNonNull = this.nextArrayContentIsNonNull = currentArrayContentIsNonNull;
/*     */   }
/*     */   
/*     */   private static IBinaryAnnotation getNonNullAnnotation(LookupEnvironment environment) {
/*  89 */     final char[] nonNullAnnotationName = CharOperation.concat(
/*  90 */         'L', CharOperation.concatWith(environment.getNonNullAnnotationName(), '/'), ';');
/*     */     
/*  92 */     return new IBinaryAnnotation()
/*     */       {
/*     */         public char[] getTypeName() {
/*  95 */           return nonNullAnnotationName;
/*     */         }
/*     */         
/*     */         public IBinaryElementValuePair[] getElementValuePairs() {
/*  99 */           return null;
/*     */         }
/*     */       };
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected TypeAnnotationWalker restrict(long newMatches, int newPathPtr) {
/*     */     try {
/* 109 */       if (this.matches == newMatches && this.pathPtr == newPathPtr && 
/* 110 */         this.atDefaultLocation == this.nextIsDefaultLocation && this.atTypeBound == this.nextIsTypeBound && this.currentArrayContentIsNonNull == this.nextArrayContentIsNonNull) {
/* 111 */         return this;
/*     */       }
/* 113 */       if (newMatches == 0L || this.typeAnnotations == null || this.typeAnnotations.length == 0) {
/* 114 */         return new NonNullDefaultAwareTypeAnnotationWalker(this.defaultNullness, this.nonNullAnnotation, 
/* 115 */             this.nextIsDefaultLocation, this.nextIsTypeBound, this.environment, this.nextArrayContentIsNonNull);
/*     */       }
/* 117 */       return new NonNullDefaultAwareTypeAnnotationWalker(this.typeAnnotations, newMatches, newPathPtr, 
/* 118 */           this.defaultNullness, this.nonNullAnnotation, this.nextIsDefaultLocation, 
/* 119 */           this.nextIsTypeBound, this.environment, this.nextArrayContentIsNonNull);
/*     */     } finally {
/* 121 */       this.nextIsDefaultLocation = false;
/* 122 */       this.nextIsTypeBound = false;
/* 123 */       this.nextArrayContentIsNonNull = this.currentArrayContentIsNonNull;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public ITypeAnnotationWalker toSupertype(short index, char[] superTypeSignature) {
/* 129 */     if (this.isEmpty) return restrict(this.matches, this.pathPtr); 
/* 130 */     return super.toSupertype(index, superTypeSignature);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ITypeAnnotationWalker toMethodParameter(short index) {
/* 136 */     if (this.isEmpty) return restrict(this.matches, this.pathPtr); 
/* 137 */     return super.toMethodParameter(index);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ITypeAnnotationWalker toField() {
/* 143 */     if (this.isEmpty) return restrict(this.matches, this.pathPtr); 
/* 144 */     return super.toField();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ITypeAnnotationWalker toMethodReturn() {
/* 150 */     if (this.isEmpty) return restrict(this.matches, this.pathPtr); 
/* 151 */     return super.toMethodReturn();
/*     */   }
/*     */ 
/*     */   
/*     */   public ITypeAnnotationWalker toTypeBound(short boundIndex) {
/* 156 */     this.nextIsDefaultLocation = ((this.defaultNullness & 0x100) != 0);
/* 157 */     this.nextIsTypeBound = true;
/* 158 */     this.nextArrayContentIsNonNull = false;
/* 159 */     if (this.isEmpty) return restrict(this.matches, this.pathPtr); 
/* 160 */     return super.toTypeBound(boundIndex);
/*     */   }
/*     */ 
/*     */   
/*     */   public ITypeAnnotationWalker toWildcardBound() {
/* 165 */     this.nextIsDefaultLocation = ((this.defaultNullness & 0x100) != 0);
/* 166 */     this.nextIsTypeBound = true;
/* 167 */     this.nextArrayContentIsNonNull = false;
/* 168 */     if (this.isEmpty) return restrict(this.matches, this.pathPtr); 
/* 169 */     return super.toWildcardBound();
/*     */   }
/*     */ 
/*     */   
/*     */   public ITypeAnnotationWalker toTypeParameterBounds(boolean isClassTypeParameter, int parameterRank) {
/* 174 */     this.nextIsDefaultLocation = ((this.defaultNullness & 0x100) != 0);
/* 175 */     this.nextIsTypeBound = true;
/* 176 */     this.nextArrayContentIsNonNull = false;
/* 177 */     if (this.isEmpty) return restrict(this.matches, this.pathPtr); 
/* 178 */     return super.toTypeParameterBounds(isClassTypeParameter, parameterRank);
/*     */   }
/*     */ 
/*     */   
/*     */   public ITypeAnnotationWalker toTypeArgument(int rank) {
/* 183 */     this.nextIsDefaultLocation = ((this.defaultNullness & 0x40) != 0);
/* 184 */     this.nextIsTypeBound = false;
/* 185 */     this.nextArrayContentIsNonNull = false;
/* 186 */     if (this.isEmpty) return restrict(this.matches, this.pathPtr); 
/* 187 */     return super.toTypeArgument(rank);
/*     */   }
/*     */ 
/*     */   
/*     */   public ITypeAnnotationWalker toTypeParameter(boolean isClassTypeParameter, int rank) {
/* 192 */     this.nextIsDefaultLocation = ((this.defaultNullness & 0x80) != 0);
/* 193 */     this.nextIsTypeBound = false;
/* 194 */     this.nextArrayContentIsNonNull = false;
/* 195 */     if (this.isEmpty) return restrict(this.matches, this.pathPtr); 
/* 196 */     return super.toTypeParameter(isClassTypeParameter, rank);
/*     */   }
/*     */ 
/*     */   
/*     */   protected ITypeAnnotationWalker toNextDetail(int detailKind) {
/* 201 */     if (this.isEmpty) return restrict(this.matches, this.pathPtr); 
/* 202 */     return super.toNextDetail(detailKind);
/*     */   }
/*     */ 
/*     */   
/*     */   public IBinaryAnnotation[] getAnnotationsAtCursor(int currentTypeId, boolean mayApplyArrayContentsDefaultNullness) {
/* 207 */     IBinaryAnnotation[] normalAnnotations = this.isEmpty ? NO_ANNOTATIONS : super.getAnnotationsAtCursor(currentTypeId, mayApplyArrayContentsDefaultNullness);
/* 208 */     if ((this.atDefaultLocation || (mayApplyArrayContentsDefaultNullness && this.currentArrayContentIsNonNull)) && 
/* 209 */       currentTypeId != -1 && (
/* 210 */       !this.atTypeBound || currentTypeId != 1)) {
/*     */       
/* 212 */       if (normalAnnotations == null || normalAnnotations.length == 0)
/* 213 */         return new IBinaryAnnotation[] { this.nonNullAnnotation }; 
/* 214 */       if (this.environment.containsNullTypeAnnotation(normalAnnotations))
/*     */       {
/* 216 */         return normalAnnotations;
/*     */       }
/*     */       
/* 219 */       int len = normalAnnotations.length;
/* 220 */       IBinaryAnnotation[] newAnnots = new IBinaryAnnotation[len + 1];
/* 221 */       System.arraycopy(normalAnnotations, 0, newAnnots, 0, len);
/* 222 */       newAnnots[len] = this.nonNullAnnotation;
/* 223 */       return newAnnots;
/*     */     } 
/*     */     
/* 226 */     return normalAnnotations;
/*     */   }
/*     */ 
/*     */   
/*     */   public ITypeAnnotationWalker toNextArrayDimension() {
/* 231 */     boolean hasNNBDForArrayContents = ((this.defaultNullness & 0x200) != 0);
/* 232 */     if (hasNNBDForArrayContents) {
/* 233 */       this.nextArrayContentIsNonNull = true;
/*     */     }
/* 235 */     this.nextIsDefaultLocation = false;
/* 236 */     this.nextIsTypeBound = false;
/* 237 */     if (this.isEmpty)
/* 238 */       return restrict(this.matches, this.pathPtr); 
/* 239 */     return super.toNextArrayDimension();
/*     */   }
/*     */ 
/*     */   
/*     */   public static ITypeAnnotationWalker updateWalkerForParamNonNullDefault(ITypeAnnotationWalker walker, int defaultNullness, LookupEnvironment environment) {
/* 244 */     if (environment.globalOptions.isAnnotationBasedNullAnalysisEnabled && 
/* 245 */       defaultNullness != 0) {
/* 246 */       if (defaultNullness == 2) {
/* 247 */         if (walker instanceof NonNullDefaultAwareTypeAnnotationWalker) {
/* 248 */           NonNullDefaultAwareTypeAnnotationWalker nonNullDefaultAwareTypeAnnotationWalker = (NonNullDefaultAwareTypeAnnotationWalker)walker;
/* 249 */           return new TypeAnnotationWalker(nonNullDefaultAwareTypeAnnotationWalker.typeAnnotations, 
/* 250 */               nonNullDefaultAwareTypeAnnotationWalker.matches, 
/* 251 */               nonNullDefaultAwareTypeAnnotationWalker.pathPtr);
/*     */         } 
/* 253 */         return walker;
/*     */       } 
/*     */       
/* 256 */       if (walker instanceof TypeAnnotationWalker) {
/* 257 */         IBinaryAnnotation nonNullAnnotation2; TypeAnnotationWalker typeAnnotationWalker = (TypeAnnotationWalker)walker;
/*     */ 
/*     */         
/* 260 */         if (walker instanceof NonNullDefaultAwareTypeAnnotationWalker) {
/* 261 */           NonNullDefaultAwareTypeAnnotationWalker nonNullDefaultAwareTypeAnnotationWalker = (NonNullDefaultAwareTypeAnnotationWalker)walker;
/* 262 */           if (nonNullDefaultAwareTypeAnnotationWalker.isEmpty) {
/* 263 */             return new NonNullDefaultAwareTypeAnnotationWalker(defaultNullness, environment);
/*     */           }
/* 265 */           nonNullAnnotation2 = nonNullDefaultAwareTypeAnnotationWalker.nonNullAnnotation;
/*     */         } else {
/* 267 */           nonNullAnnotation2 = getNonNullAnnotation(environment);
/*     */         } 
/* 269 */         return new NonNullDefaultAwareTypeAnnotationWalker(typeAnnotationWalker.typeAnnotations, 
/* 270 */             typeAnnotationWalker.matches, typeAnnotationWalker.pathPtr, defaultNullness, 
/* 271 */             nonNullAnnotation2, false, false, environment, false);
/*     */       } 
/*     */       
/* 274 */       return new NonNullDefaultAwareTypeAnnotationWalker(defaultNullness, environment);
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 279 */     return walker;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\classfmt\NonNullDefaultAwareTypeAnnotationWalker.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */