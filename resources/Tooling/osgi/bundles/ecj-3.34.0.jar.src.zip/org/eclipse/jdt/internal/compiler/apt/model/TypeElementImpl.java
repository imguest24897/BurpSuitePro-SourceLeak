/*     */ package org.eclipse.jdt.internal.compiler.apt.model;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.Comparator;
/*     */ import java.util.IdentityHashMap;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import javax.lang.model.SourceVersion;
/*     */ import javax.lang.model.element.Element;
/*     */ import javax.lang.model.element.ElementKind;
/*     */ import javax.lang.model.element.ElementVisitor;
/*     */ import javax.lang.model.element.ExecutableElement;
/*     */ import javax.lang.model.element.Modifier;
/*     */ import javax.lang.model.element.Name;
/*     */ import javax.lang.model.element.NestingKind;
/*     */ import javax.lang.model.element.PackageElement;
/*     */ import javax.lang.model.element.RecordComponentElement;
/*     */ import javax.lang.model.element.TypeElement;
/*     */ import javax.lang.model.element.TypeParameterElement;
/*     */ import javax.lang.model.element.VariableElement;
/*     */ import javax.lang.model.type.TypeKind;
/*     */ import javax.lang.model.type.TypeMirror;
/*     */ import org.eclipse.jdt.core.compiler.CharOperation;
/*     */ import org.eclipse.jdt.internal.compiler.apt.dispatch.BaseProcessingEnvImpl;
/*     */ import org.eclipse.jdt.internal.compiler.ast.FieldDeclaration;
/*     */ import org.eclipse.jdt.internal.compiler.ast.TypeDeclaration;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.AnnotationBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.Binding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.FieldBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.MethodBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.RecordComponentBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.ReferenceBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.SourceTypeBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.TypeBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.TypeVariableBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.VariableBinding;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TypeElementImpl
/*     */   extends ElementImpl
/*     */   implements TypeElement
/*     */ {
/*     */   private final ElementKind _kindHint;
/*     */   
/*     */   private static final class SourceLocationComparator
/*     */     implements Comparator<Element>
/*     */   {
/*  62 */     private final IdentityHashMap<ElementImpl, Integer> sourceStartCache = new IdentityHashMap<>();
/*     */ 
/*     */     
/*     */     public int compare(Element o1, Element o2) {
/*  66 */       ElementImpl e1 = (ElementImpl)o1;
/*  67 */       ElementImpl e2 = (ElementImpl)o2;
/*     */       
/*  69 */       return getSourceStart(e1) - getSourceStart(e2);
/*     */     }
/*     */     
/*     */     private int getSourceStart(ElementImpl e) {
/*  73 */       Integer value = this.sourceStartCache.get(e);
/*     */       
/*  75 */       if (value == null) {
/*  76 */         value = Integer.valueOf(determineSourceStart(e));
/*  77 */         this.sourceStartCache.put(e, value);
/*     */       } 
/*     */       
/*  80 */       return value.intValue(); } private int determineSourceStart(ElementImpl e) { TypeElementImpl typeElementImpl; Binding typeBinding;
/*     */       ExecutableElementImpl executableElementImpl;
/*     */       Binding binding;
/*     */       VariableElementImpl variableElementImpl;
/*  84 */       switch (e.getKind()) {
/*     */         case ENUM:
/*     */         case CLASS:
/*     */         case null:
/*     */         case INTERFACE:
/*     */         case RECORD:
/*  90 */           typeElementImpl = (TypeElementImpl)e;
/*  91 */           typeBinding = typeElementImpl._binding;
/*  92 */           if (typeBinding instanceof SourceTypeBinding) {
/*  93 */             SourceTypeBinding sourceTypeBinding = (SourceTypeBinding)typeBinding;
/*  94 */             TypeDeclaration typeDeclaration = (TypeDeclaration)sourceTypeBinding.scope.referenceContext();
/*  95 */             return typeDeclaration.sourceStart;
/*     */           } 
/*     */           break;
/*     */         case METHOD:
/*     */         case CONSTRUCTOR:
/* 100 */           executableElementImpl = (ExecutableElementImpl)e;
/* 101 */           binding = executableElementImpl._binding;
/* 102 */           if (binding instanceof MethodBinding) {
/* 103 */             MethodBinding methodBinding = (MethodBinding)binding;
/* 104 */             return methodBinding.sourceStart();
/*     */           } 
/*     */           break;
/*     */         case ENUM_CONSTANT:
/*     */         case FIELD:
/*     */         case RECORD_COMPONENT:
/* 110 */           variableElementImpl = (VariableElementImpl)e;
/* 111 */           binding = variableElementImpl._binding;
/* 112 */           if (binding instanceof FieldBinding) {
/* 113 */             FieldBinding fieldBinding = (FieldBinding)binding;
/* 114 */             FieldDeclaration fieldDeclaration = fieldBinding.sourceField();
/* 115 */             if (fieldDeclaration != null) {
/* 116 */               return fieldDeclaration.sourceStart;
/*     */             }
/*     */           } 
/*     */           break;
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 124 */       return -1; }
/*     */   
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   TypeElementImpl(BaseProcessingEnvImpl env, ReferenceBinding binding, ElementKind kindHint) {
/* 136 */     super(env, (Binding)binding);
/* 137 */     this._kindHint = kindHint;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public <R, P> R accept(ElementVisitor<R, P> v, P p) {
/* 143 */     return v.visitType(this, p);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected AnnotationBinding[] getAnnotationBindings() {
/* 149 */     return ((ReferenceBinding)this._binding).getAnnotations();
/*     */   }
/*     */ 
/*     */   
/*     */   public List<? extends Element> getEnclosedElements() {
/* 154 */     ReferenceBinding binding = (ReferenceBinding)this._binding;
/* 155 */     List<Element> enclosed = new ArrayList<>(binding.fieldCount() + (binding.methods()).length + (binding.memberTypes()).length); byte b; int i; MethodBinding[] arrayOfMethodBinding;
/* 156 */     for (i = (arrayOfMethodBinding = binding.methods()).length, b = 0; b < i; ) { MethodBinding method = arrayOfMethodBinding[b];
/* 157 */       ExecutableElement executable = new ExecutableElementImpl(this._env, method);
/* 158 */       enclosed.add(executable); b++; }
/*     */      FieldBinding[] arrayOfFieldBinding;
/* 160 */     for (i = (arrayOfFieldBinding = binding.fields()).length, b = 0; b < i; ) { FieldBinding field = arrayOfFieldBinding[b];
/*     */       
/* 162 */       if (!field.isSynthetic()) {
/* 163 */         VariableElement variable = new VariableElementImpl(this._env, (VariableBinding)field);
/* 164 */         enclosed.add(variable);
/*     */       }  b++; }
/*     */     
/* 167 */     if (binding.isRecord()) {
/* 168 */       RecordComponentBinding[] components = binding.components(); RecordComponentBinding[] arrayOfRecordComponentBinding1;
/* 169 */       for (int j = (arrayOfRecordComponentBinding1 = components).length; i < j; ) { RecordComponentBinding comp = arrayOfRecordComponentBinding1[i];
/* 170 */         RecordComponentElement rec = new RecordComponentElementImpl(this._env, comp);
/* 171 */         enclosed.add(rec); i++; }
/*     */     
/*     */     }  ReferenceBinding[] arrayOfReferenceBinding;
/* 174 */     for (i = (arrayOfReferenceBinding = binding.memberTypes()).length, b = 0; b < i; ) { ReferenceBinding memberType = arrayOfReferenceBinding[b];
/* 175 */       TypeElement type = new TypeElementImpl(this._env, memberType, null);
/* 176 */       enclosed.add(type); b++; }
/*     */     
/* 178 */     Collections.sort(enclosed, new SourceLocationComparator());
/* 179 */     return Collections.unmodifiableList(enclosed);
/*     */   }
/*     */ 
/*     */   
/*     */   public List<? extends RecordComponentElement> getRecordComponents() {
/* 184 */     if (this._binding instanceof ReferenceBinding) {
/* 185 */       ReferenceBinding binding = (ReferenceBinding)this._binding;
/* 186 */       List<RecordComponentElement> enclosed = new ArrayList<>(); byte b; int i; RecordComponentBinding[] arrayOfRecordComponentBinding;
/* 187 */       for (i = (arrayOfRecordComponentBinding = binding.components()).length, b = 0; b < i; ) { RecordComponentBinding comp = arrayOfRecordComponentBinding[b];
/* 188 */         RecordComponentElement variable = new RecordComponentElementImpl(this._env, comp);
/* 189 */         enclosed.add(variable); b++; }
/*     */       
/* 191 */       Collections.sort(enclosed, new SourceLocationComparator());
/* 192 */       return Collections.unmodifiableList(enclosed);
/*     */     } 
/* 194 */     return Collections.emptyList();
/*     */   }
/*     */ 
/*     */   
/*     */   public List<? extends TypeMirror> getPermittedSubclasses() {
/* 199 */     ReferenceBinding binding = (ReferenceBinding)this._binding;
/* 200 */     if (binding.isSealed()) {
/* 201 */       List<TypeMirror> permitted = new ArrayList<>(); byte b; int i; ReferenceBinding[] arrayOfReferenceBinding;
/* 202 */       for (i = (arrayOfReferenceBinding = binding.permittedTypes()).length, b = 0; b < i; ) { ReferenceBinding type = arrayOfReferenceBinding[b];
/* 203 */         TypeMirror typeMirror = this._env.getFactory().newTypeMirror((Binding)type);
/* 204 */         permitted.add(typeMirror); b++; }
/*     */       
/* 206 */       return Collections.unmodifiableList(permitted);
/*     */     } 
/* 208 */     return Collections.emptyList();
/*     */   }
/*     */   
/*     */   public Element getEnclosingElement() {
/* 212 */     ReferenceBinding binding = (ReferenceBinding)this._binding;
/* 213 */     ReferenceBinding enclosingType = binding.enclosingType();
/* 214 */     if (enclosingType == null)
/*     */     {
/* 216 */       return this._env.getFactory().newPackageElement(binding.fPackage);
/*     */     }
/*     */     
/* 219 */     return this._env.getFactory().newElement((Binding)binding.enclosingType());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getFileName() {
/* 225 */     char[] name = ((ReferenceBinding)this._binding).getFileName();
/* 226 */     if (name == null)
/* 227 */       return null; 
/* 228 */     return new String(name);
/*     */   }
/*     */ 
/*     */   
/*     */   public List<? extends TypeMirror> getInterfaces() {
/* 233 */     ReferenceBinding binding = (ReferenceBinding)this._binding;
/* 234 */     if (binding.superInterfaces() == null || (binding.superInterfaces()).length == 0) {
/* 235 */       return Collections.emptyList();
/*     */     }
/* 237 */     List<TypeMirror> interfaces = new ArrayList<>((binding.superInterfaces()).length); byte b; int i; ReferenceBinding[] arrayOfReferenceBinding;
/* 238 */     for (i = (arrayOfReferenceBinding = binding.superInterfaces()).length, b = 0; b < i; ) { ReferenceBinding interfaceBinding = arrayOfReferenceBinding[b];
/* 239 */       TypeMirror interfaceType = this._env.getFactory().newTypeMirror((Binding)interfaceBinding);
/* 240 */       if (interfaceType.getKind() == TypeKind.ERROR) {
/* 241 */         if (this._env.getSourceVersion().compareTo(SourceVersion.RELEASE_6) > 0)
/*     */         {
/* 243 */           interfaces.add(interfaceType);
/*     */         }
/*     */       } else {
/* 246 */         interfaces.add(interfaceType);
/*     */       }  b++; }
/*     */     
/* 249 */     return Collections.unmodifiableList(interfaces);
/*     */   }
/*     */ 
/*     */   
/*     */   public ElementKind getKind() {
/* 254 */     if (this._kindHint != null) {
/* 255 */       return this._kindHint;
/*     */     }
/* 257 */     ReferenceBinding refBinding = (ReferenceBinding)this._binding;
/*     */     
/* 259 */     if (refBinding.isEnum()) {
/* 260 */       return ElementKind.ENUM;
/*     */     }
/* 262 */     if (refBinding.isRecord()) {
/* 263 */       return ElementKind.RECORD;
/*     */     }
/* 265 */     if (refBinding.isAnnotationType()) {
/* 266 */       return ElementKind.ANNOTATION_TYPE;
/*     */     }
/* 268 */     if (refBinding.isInterface()) {
/* 269 */       return ElementKind.INTERFACE;
/*     */     }
/* 271 */     if (refBinding.isClass()) {
/* 272 */       return ElementKind.CLASS;
/*     */     }
/*     */     
/* 275 */     throw new IllegalArgumentException("TypeElement " + new String(refBinding.shortReadableName()) + 
/* 276 */         " has unexpected attributes " + refBinding.modifiers);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Set<Modifier> getModifiers() {
/* 283 */     ReferenceBinding refBinding = (ReferenceBinding)this._binding;
/* 284 */     int modifiers = refBinding.modifiers;
/* 285 */     if (refBinding.isInterface() && refBinding.isNestedType()) {
/* 286 */       modifiers |= 0x8;
/*     */     }
/*     */     
/* 289 */     return Factory.getModifiers(modifiers, getKind(), refBinding.isBinaryBinding());
/*     */   }
/*     */ 
/*     */   
/*     */   public NestingKind getNestingKind() {
/* 294 */     ReferenceBinding refBinding = (ReferenceBinding)this._binding;
/* 295 */     if (refBinding.isAnonymousType())
/* 296 */       return NestingKind.ANONYMOUS; 
/* 297 */     if (refBinding.isLocalType())
/* 298 */       return NestingKind.LOCAL; 
/* 299 */     if (refBinding.isMemberType()) {
/* 300 */       return NestingKind.MEMBER;
/*     */     }
/* 302 */     return NestingKind.TOP_LEVEL;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   PackageElement getPackage() {
/* 308 */     ReferenceBinding binding = (ReferenceBinding)this._binding;
/* 309 */     return this._env.getFactory().newPackageElement(binding.fPackage);
/*     */   }
/*     */   
/*     */   public Name getQualifiedName() {
/*     */     char[] qName;
/* 314 */     ReferenceBinding binding = (ReferenceBinding)this._binding;
/*     */     
/* 316 */     if (binding.isMemberType()) {
/* 317 */       qName = CharOperation.concatWith((binding.enclosingType()).compoundName, binding.sourceName, '.');
/* 318 */       CharOperation.replace(qName, '$', '.');
/*     */     } else {
/* 320 */       qName = CharOperation.concatWith(binding.compoundName, '.');
/*     */     } 
/* 322 */     return new NameImpl(qName);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Name getSimpleName() {
/* 333 */     ReferenceBinding binding = (ReferenceBinding)this._binding;
/* 334 */     return new NameImpl(binding.sourceName());
/*     */   }
/*     */ 
/*     */   
/*     */   public TypeMirror getSuperclass() {
/* 339 */     ReferenceBinding binding = (ReferenceBinding)this._binding;
/* 340 */     ReferenceBinding superBinding = binding.superclass();
/* 341 */     if (superBinding == null || binding.isInterface()) {
/* 342 */       return this._env.getFactory().getNoType(TypeKind.NONE);
/*     */     }
/*     */     
/* 345 */     return this._env.getFactory().newTypeMirror((Binding)superBinding);
/*     */   }
/*     */ 
/*     */   
/*     */   public List<? extends TypeParameterElement> getTypeParameters() {
/* 350 */     ReferenceBinding binding = (ReferenceBinding)this._binding;
/* 351 */     TypeVariableBinding[] variables = binding.typeVariables();
/* 352 */     if (variables.length == 0) {
/* 353 */       return Collections.emptyList();
/*     */     }
/* 355 */     List<TypeParameterElement> params = new ArrayList<>(variables.length); byte b; int i; TypeVariableBinding[] arrayOfTypeVariableBinding1;
/* 356 */     for (i = (arrayOfTypeVariableBinding1 = variables).length, b = 0; b < i; ) { TypeVariableBinding variable = arrayOfTypeVariableBinding1[b];
/* 357 */       params.add(this._env.getFactory().newTypeParameterElement(variable, this)); b++; }
/*     */     
/* 359 */     return Collections.unmodifiableList(params);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean hides(Element hidden) {
/* 365 */     if (!(hidden instanceof TypeElementImpl)) {
/* 366 */       return false;
/*     */     }
/* 368 */     ReferenceBinding hiddenBinding = (ReferenceBinding)((TypeElementImpl)hidden)._binding;
/* 369 */     if (hiddenBinding.isPrivate()) {
/* 370 */       return false;
/*     */     }
/* 372 */     ReferenceBinding hiderBinding = (ReferenceBinding)this._binding;
/* 373 */     if (TypeBinding.equalsEquals((TypeBinding)hiddenBinding, (TypeBinding)hiderBinding)) {
/* 374 */       return false;
/*     */     }
/* 376 */     if (!hiddenBinding.isMemberType() || !hiderBinding.isMemberType()) {
/* 377 */       return false;
/*     */     }
/* 379 */     if (!CharOperation.equals(hiddenBinding.sourceName, hiderBinding.sourceName)) {
/* 380 */       return false;
/*     */     }
/* 382 */     return (hiderBinding.enclosingType().findSuperTypeOriginatingFrom((TypeBinding)hiddenBinding.enclosingType()) != null);
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 387 */     ReferenceBinding binding = (ReferenceBinding)this._binding;
/* 388 */     char[] concatWith = CharOperation.concatWith(binding.compoundName, '.');
/* 389 */     if (binding.isNestedType()) {
/* 390 */       CharOperation.replace(concatWith, '$', '.');
/* 391 */       return new String(concatWith);
/*     */     } 
/* 393 */     return new String(concatWith);
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\apt\model\TypeElementImpl.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */