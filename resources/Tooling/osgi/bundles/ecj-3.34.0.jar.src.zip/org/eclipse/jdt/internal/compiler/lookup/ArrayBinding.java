/*     */ package org.eclipse.jdt.internal.compiler.lookup;
/*     */ 
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import org.eclipse.jdt.core.compiler.CharOperation;
/*     */ import org.eclipse.jdt.internal.compiler.ClassFile;
/*     */ import org.eclipse.jdt.internal.compiler.impl.CompilerOptions;
/*     */ import org.eclipse.jdt.internal.compiler.impl.Constant;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ArrayBinding
/*     */   extends TypeBinding
/*     */ {
/*  46 */   public static final FieldBinding ArrayLength = new FieldBinding(TypeConstants.LENGTH, TypeBinding.INT, 17, null, Constant.NotAConstant);
/*     */   
/*     */   public TypeBinding leafComponentType;
/*     */   
/*     */   public int dimensions;
/*     */   
/*     */   LookupEnvironment environment;
/*     */   
/*     */   char[] constantPoolName;
/*     */   
/*     */   char[] genericTypeSignature;
/*     */   
/*     */   public long[] nullTagBitsPerDimension;
/*     */   private MethodBinding clone;
/*     */   
/*     */   public ArrayBinding(TypeBinding type, int dimensions, LookupEnvironment environment) {
/*  62 */     this.tagBits |= 0x1L;
/*  63 */     this.leafComponentType = type;
/*  64 */     this.dimensions = dimensions;
/*  65 */     this.environment = environment;
/*  66 */     if (type instanceof UnresolvedReferenceBinding) {
/*  67 */       ((UnresolvedReferenceBinding)type).addWrapper(this, environment);
/*     */     } else {
/*  69 */       this.tagBits |= type.tagBits & 0x2000000060000880L;
/*  70 */     }  long mask = type.tagBits & 0x180000000000000L;
/*  71 */     if (mask != 0L) {
/*  72 */       this.nullTagBitsPerDimension = new long[this.dimensions + 1];
/*  73 */       this.nullTagBitsPerDimension[this.dimensions] = mask;
/*  74 */       this.tagBits |= 0x100000L;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public TypeBinding closestMatch() {
/*  80 */     if (isValidBinding()) {
/*  81 */       return this;
/*     */     }
/*  83 */     TypeBinding leafClosestMatch = this.leafComponentType.closestMatch();
/*  84 */     if (leafClosestMatch == null) {
/*  85 */       return null;
/*     */     }
/*  87 */     return this.environment.createArrayType(this.leafComponentType.closestMatch(), this.dimensions);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<TypeBinding> collectMissingTypes(List<TypeBinding> missingTypes) {
/*  95 */     if ((this.tagBits & 0x80L) != 0L) {
/*  96 */       missingTypes = this.leafComponentType.collectMissingTypes(missingTypes);
/*     */     }
/*  98 */     return missingTypes;
/*     */   }
/*     */ 
/*     */   
/*     */   public void collectSubstitutes(Scope scope, TypeBinding actualType, InferenceContext inferenceContext, int constraint) {
/*     */     int actualDim;
/* 104 */     if ((this.tagBits & 0x20000000L) == 0L)
/* 105 */       return;  if (actualType == TypeBinding.NULL || actualType.kind() == 65540)
/*     */       return; 
/* 107 */     switch (actualType.kind()) {
/*     */       case 68:
/* 109 */         actualDim = actualType.dimensions();
/* 110 */         if (actualDim == this.dimensions) {
/* 111 */           this.leafComponentType.collectSubstitutes(scope, actualType.leafComponentType(), inferenceContext, constraint); break;
/* 112 */         }  if (actualDim > this.dimensions) {
/* 113 */           ArrayBinding actualReducedType = this.environment.createArrayType(actualType.leafComponentType(), actualDim - this.dimensions);
/* 114 */           this.leafComponentType.collectSubstitutes(scope, actualReducedType, inferenceContext, constraint);
/*     */         } 
/*     */         break;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean mentionsAny(TypeBinding[] parameters, int idx) {
/* 126 */     return this.leafComponentType.mentionsAny(parameters, idx);
/*     */   }
/*     */ 
/*     */   
/*     */   void collectInferenceVariables(Set<InferenceVariable> variables) {
/* 131 */     this.leafComponentType.collectInferenceVariables(variables);
/*     */   }
/*     */ 
/*     */   
/*     */   TypeBinding substituteInferenceVariable(InferenceVariable var, TypeBinding substituteType) {
/* 136 */     TypeBinding substitutedLeaf = this.leafComponentType.substituteInferenceVariable(var, substituteType);
/* 137 */     if (TypeBinding.notEquals(substitutedLeaf, this.leafComponentType))
/* 138 */       return this.environment.createArrayType(substitutedLeaf, this.dimensions, this.typeAnnotations); 
/* 139 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public char[] computeUniqueKey(boolean isLeaf) {
/* 148 */     char[] brackets = new char[this.dimensions];
/* 149 */     for (int i = this.dimensions - 1; i >= 0; ) { brackets[i] = '['; i--; }
/* 150 */      return CharOperation.concat(brackets, this.leafComponentType.computeUniqueKey(isLeaf));
/*     */   }
/*     */ 
/*     */   
/*     */   public char[] constantPoolName() {
/* 155 */     if (this.constantPoolName != null) {
/* 156 */       return this.constantPoolName;
/*     */     }
/* 158 */     char[] brackets = new char[this.dimensions];
/* 159 */     for (int i = this.dimensions - 1; i >= 0; ) { brackets[i] = '['; i--; }
/* 160 */      return this.constantPoolName = CharOperation.concat(brackets, this.leafComponentType.signature());
/*     */   }
/*     */   
/*     */   public String debugName() {
/* 164 */     if (hasTypeAnnotations())
/* 165 */       return annotatedDebugName(); 
/* 166 */     StringBuilder brackets = new StringBuilder(this.dimensions * 2);
/* 167 */     for (int i = this.dimensions; --i >= 0;)
/* 168 */       brackets.append("[]"); 
/* 169 */     return String.valueOf(this.leafComponentType.debugName()) + brackets.toString();
/*     */   }
/*     */ 
/*     */   
/*     */   public String annotatedDebugName() {
/* 174 */     StringBuilder brackets = new StringBuilder(this.dimensions * 2);
/* 175 */     brackets.append(this.leafComponentType.annotatedDebugName());
/* 176 */     brackets.append(' ');
/* 177 */     AnnotationBinding[] annotations = getTypeAnnotations();
/* 178 */     for (int i = 0, j = -1; i < this.dimensions; i++) {
/* 179 */       if (annotations != null) {
/* 180 */         if (i != 0)
/* 181 */           brackets.append(' '); 
/* 182 */         while (++j < annotations.length && annotations[j] != null) {
/* 183 */           brackets.append(annotations[j]);
/* 184 */           brackets.append(' ');
/*     */         } 
/*     */       } 
/* 187 */       brackets.append("[]");
/*     */     } 
/* 189 */     return brackets.toString();
/*     */   }
/*     */ 
/*     */   
/*     */   public int dimensions() {
/* 194 */     return this.dimensions;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TypeBinding elementsType() {
/* 204 */     if (this.dimensions == 1) {
/* 205 */       return this.leafComponentType;
/*     */     }
/* 207 */     AnnotationBinding[] oldies = getTypeAnnotations();
/* 208 */     AnnotationBinding[] newbies = Binding.NO_ANNOTATIONS;
/*     */     
/* 210 */     for (int i = 0, length = (oldies == null) ? 0 : oldies.length; i < length; i++) {
/* 211 */       if (oldies[i] == null) {
/* 212 */         System.arraycopy(oldies, i + 1, newbies = new AnnotationBinding[length - i - 1], 0, length - i - 1);
/*     */         break;
/*     */       } 
/*     */     } 
/* 216 */     return this.environment.createArrayType(this.leafComponentType, this.dimensions - 1, newbies);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TypeBinding erasure() {
/* 224 */     TypeBinding erasedType = this.leafComponentType.erasure();
/* 225 */     if (TypeBinding.notEquals(this.leafComponentType, erasedType))
/* 226 */       return this.environment.createArrayType(erasedType, this.dimensions); 
/* 227 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public ArrayBinding upwardsProjection(Scope scope, TypeBinding[] mentionedTypeVariables) {
/* 232 */     TypeBinding leafType = this.leafComponentType.upwardsProjection(scope, mentionedTypeVariables);
/* 233 */     return scope.environment().createArrayType(leafType, this.dimensions, this.typeAnnotations);
/*     */   }
/*     */ 
/*     */   
/*     */   public ArrayBinding downwardsProjection(Scope scope, TypeBinding[] mentionedTypeVariables) {
/* 238 */     TypeBinding leafType = this.leafComponentType.downwardsProjection(scope, mentionedTypeVariables);
/* 239 */     return scope.environment().createArrayType(leafType, this.dimensions, this.typeAnnotations);
/*     */   }
/*     */   
/*     */   public LookupEnvironment environment() {
/* 243 */     return this.environment;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public char[] genericTypeSignature() {
/* 249 */     if (this.genericTypeSignature == null) {
/* 250 */       char[] brackets = new char[this.dimensions];
/* 251 */       for (int i = this.dimensions - 1; i >= 0; ) { brackets[i] = '['; i--; }
/* 252 */        this.genericTypeSignature = CharOperation.concat(brackets, this.leafComponentType.genericTypeSignature());
/*     */     } 
/* 254 */     return this.genericTypeSignature;
/*     */   }
/*     */ 
/*     */   
/*     */   public PackageBinding getPackage() {
/* 259 */     return this.leafComponentType.getPackage();
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 264 */     return (this.leafComponentType == null) ? super.hashCode() : this.leafComponentType.hashCode(); }
/*     */   public boolean isCompatibleWith(TypeBinding otherType, Scope captureScope) { ArrayBinding otherArray;
/*     */     CaptureBinding otherCapture;
/*     */     byte b;
/*     */     TypeBinding otherLowerBound;
/*     */     int i;
/*     */     ReferenceBinding[] arrayOfReferenceBinding;
/* 271 */     if (equalsEquals(this, otherType)) {
/* 272 */       return true;
/*     */     }
/* 274 */     switch (otherType.kind()) {
/*     */       case 68:
/* 276 */         otherArray = (ArrayBinding)otherType;
/* 277 */         if (otherArray.leafComponentType.isBaseType())
/* 278 */           return false; 
/* 279 */         if (this.dimensions == otherArray.dimensions)
/* 280 */           return this.leafComponentType.isCompatibleWith(otherArray.leafComponentType); 
/* 281 */         if (this.dimensions < otherArray.dimensions)
/* 282 */           return false; 
/*     */         break;
/*     */       case 132:
/* 285 */         return false;
/*     */       case 516:
/*     */       case 8196:
/* 288 */         return ((WildcardBinding)otherType).boundCheck(this);
/*     */       
/*     */       case 32772:
/* 291 */         for (i = (arrayOfReferenceBinding = ((IntersectionTypeBinding18)otherType).intersectingTypes).length, b = 0; b < i; ) { ReferenceBinding intersecting = arrayOfReferenceBinding[b];
/* 292 */           if (!isCompatibleWith(intersecting, captureScope))
/* 293 */             return false;  b++; }
/*     */         
/* 295 */         return true;
/*     */ 
/*     */ 
/*     */       
/*     */       case 4100:
/* 300 */         otherCapture = (CaptureBinding)otherType;
/*     */         
/* 302 */         if (otherType.isCapture() && (otherLowerBound = otherCapture.lowerBound) != null) {
/* 303 */           if (!otherLowerBound.isArrayType()) return false; 
/* 304 */           return isCompatibleWith(otherLowerBound, captureScope);
/*     */         } 
/*     */         
/* 307 */         return false;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 312 */     switch ((otherType.leafComponentType()).id) {
/*     */       case 1:
/*     */       case 36:
/*     */       case 37:
/* 316 */         return true;
/*     */     } 
/* 318 */     return false; } public boolean isSubtypeOf(TypeBinding otherType, boolean simulatingBugJDK8026527) { ArrayBinding otherArray; CaptureBinding otherCapture;
/*     */     byte b;
/*     */     TypeBinding otherLowerBound;
/*     */     int i;
/*     */     ReferenceBinding[] arrayOfReferenceBinding;
/* 323 */     if (equalsEquals(this, otherType)) {
/* 324 */       return true;
/*     */     }
/* 326 */     switch (otherType.kind()) {
/*     */       case 68:
/* 328 */         otherArray = (ArrayBinding)otherType;
/* 329 */         if (otherArray.leafComponentType.isBaseType())
/* 330 */           return false; 
/* 331 */         if (this.dimensions == otherArray.dimensions)
/* 332 */           return this.leafComponentType.isSubtypeOf(otherArray.leafComponentType, simulatingBugJDK8026527); 
/* 333 */         if (this.dimensions < otherArray.dimensions)
/* 334 */           return false; 
/*     */         break;
/*     */       case 132:
/* 337 */         return false;
/*     */       case 32772:
/* 339 */         for (i = (arrayOfReferenceBinding = ((IntersectionTypeBinding18)otherType).intersectingTypes).length, b = 0; b < i; ) { ReferenceBinding intersecting = arrayOfReferenceBinding[b];
/* 340 */           if (!isSubtypeOf(intersecting, simulatingBugJDK8026527))
/* 341 */             return false;  b++; }
/*     */         
/* 343 */         return true;
/*     */ 
/*     */       
/*     */       case 4100:
/* 347 */         otherCapture = (CaptureBinding)otherType;
/*     */         
/* 349 */         if (otherType.isCapture() && (otherLowerBound = otherCapture.lowerBound) != null) {
/* 350 */           if (!otherLowerBound.isArrayType()) return false; 
/* 351 */           return isSubtypeOf(otherLowerBound, simulatingBugJDK8026527);
/*     */         } 
/*     */         break;
/*     */     } 
/* 355 */     switch ((otherType.leafComponentType()).id) {
/*     */       case 1:
/*     */       case 36:
/*     */       case 37:
/* 359 */         return true;
/*     */     } 
/* 361 */     return false; }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isProperType(boolean admitCapture18) {
/* 366 */     return this.leafComponentType.isProperType(admitCapture18);
/*     */   }
/*     */ 
/*     */   
/*     */   public int kind() {
/* 371 */     return 68;
/*     */   }
/*     */ 
/*     */   
/*     */   public TypeBinding leafComponentType() {
/* 376 */     return this.leafComponentType;
/*     */   }
/*     */ 
/*     */   
/*     */   public char[] nullAnnotatedReadableName(CompilerOptions options, boolean shortNames) {
/* 381 */     if (this.nullTagBitsPerDimension == null)
/* 382 */       return shortNames ? shortReadableName() : readableName(); 
/* 383 */     char[][] brackets = new char[this.dimensions][];
/* 384 */     for (int i = 0; i < this.dimensions; i++) {
/* 385 */       if ((this.nullTagBitsPerDimension[i] & 0x180000000000000L) != 0L) {
/*     */         char[][] fqAnnotationName;
/* 387 */         if ((this.nullTagBitsPerDimension[i] & 0x100000000000000L) != 0L) {
/* 388 */           fqAnnotationName = options.nonNullAnnotationName;
/*     */         } else {
/* 390 */           fqAnnotationName = options.nullableAnnotationName;
/* 391 */         }  char[] annotationName = shortNames ? 
/* 392 */           fqAnnotationName[fqAnnotationName.length - 1] : 
/* 393 */           CharOperation.concatWith(fqAnnotationName, '.');
/* 394 */         brackets[i] = new char[annotationName.length + 3];
/* 395 */         brackets[i][0] = '@';
/* 396 */         System.arraycopy(annotationName, 0, brackets[i], 1, annotationName.length);
/* 397 */         brackets[i][annotationName.length + 1] = '[';
/* 398 */         brackets[i][annotationName.length + 2] = ']';
/*     */       } else {
/* 400 */         (new char[2])[0] = '['; (new char[2])[1] = ']'; brackets[i] = new char[2];
/*     */       } 
/*     */     } 
/* 403 */     return CharOperation.concat(this.leafComponentType.nullAnnotatedReadableName(options, shortNames), 
/* 404 */         CharOperation.concatWith(brackets, ' '), 
/* 405 */         ' ');
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int problemId() {
/* 414 */     return this.leafComponentType.problemId();
/*     */   }
/*     */ 
/*     */   
/*     */   public char[] qualifiedSourceName() {
/* 419 */     char[] brackets = new char[this.dimensions * 2];
/* 420 */     for (int i = this.dimensions * 2 - 1; i >= 0; i -= 2) {
/* 421 */       brackets[i] = ']';
/* 422 */       brackets[i - 1] = '[';
/*     */     } 
/* 424 */     return CharOperation.concat(this.leafComponentType.qualifiedSourceName(), brackets);
/*     */   }
/*     */   
/*     */   public char[] readableName() {
/* 428 */     char[] brackets = new char[this.dimensions * 2];
/* 429 */     for (int i = this.dimensions * 2 - 1; i >= 0; i -= 2) {
/* 430 */       brackets[i] = ']';
/* 431 */       brackets[i - 1] = '[';
/*     */     } 
/* 433 */     return CharOperation.concat(this.leafComponentType.readableName(), brackets);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setTypeAnnotations(AnnotationBinding[] annotations, boolean evalNullAnnotations) {
/* 438 */     this.tagBits |= 0x200000L;
/* 439 */     if (annotations == null || annotations.length == 0)
/*     */       return; 
/* 441 */     this.typeAnnotations = annotations;
/*     */     
/* 443 */     if (evalNullAnnotations) {
/* 444 */       long nullTagBits = 0L;
/* 445 */       if (this.nullTagBitsPerDimension == null) {
/* 446 */         this.nullTagBitsPerDimension = new long[this.dimensions + 1];
/*     */       }
/* 448 */       int dimension = 0;
/* 449 */       for (int i = 0, length = annotations.length; i < length; i++) {
/* 450 */         AnnotationBinding annotation = annotations[i];
/* 451 */         if (annotation != null) {
/* 452 */           if (annotation.type.hasNullBit(64)) {
/* 453 */             nullTagBits |= 0x80000000000000L;
/* 454 */             this.tagBits |= 0x100000L;
/* 455 */           } else if (annotation.type.hasNullBit(32)) {
/* 456 */             nullTagBits |= 0x100000000000000L;
/* 457 */             this.tagBits |= 0x100000L;
/*     */           } 
/*     */         } else {
/*     */           
/* 461 */           if (nullTagBits != 0L) {
/* 462 */             this.nullTagBitsPerDimension[dimension] = nullTagBits;
/* 463 */             nullTagBits = 0L;
/*     */           } 
/* 465 */           dimension++;
/*     */         } 
/*     */       } 
/* 468 */       this.tagBits |= this.nullTagBitsPerDimension[0];
/*     */     } 
/*     */   }
/*     */   
/*     */   public char[] shortReadableName() {
/* 473 */     char[] brackets = new char[this.dimensions * 2];
/* 474 */     for (int i = this.dimensions * 2 - 1; i >= 0; i -= 2) {
/* 475 */       brackets[i] = ']';
/* 476 */       brackets[i - 1] = '[';
/*     */     } 
/* 478 */     return CharOperation.concat(this.leafComponentType.shortReadableName(), brackets);
/*     */   }
/*     */   
/*     */   public char[] sourceName() {
/* 482 */     char[] brackets = new char[this.dimensions * 2];
/* 483 */     for (int i = this.dimensions * 2 - 1; i >= 0; i -= 2) {
/* 484 */       brackets[i] = ']';
/* 485 */       brackets[i - 1] = '[';
/*     */     } 
/* 487 */     return CharOperation.concat(this.leafComponentType.sourceName(), brackets);
/*     */   }
/*     */   
/*     */   public void swapUnresolved(UnresolvedReferenceBinding unresolvedType, ReferenceBinding resolvedType, LookupEnvironment env) {
/* 491 */     if (this.leafComponentType == unresolvedType) {
/* 492 */       this.leafComponentType = env.convertUnresolvedBinaryToRawType(resolvedType);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 505 */       if (this.leafComponentType != resolvedType)
/* 506 */         this.id = (env.createArrayType(this.leafComponentType, this.dimensions, this.typeAnnotations)).id; 
/* 507 */       this.tagBits |= this.leafComponentType.tagBits & 0x2000000060000080L;
/*     */     } 
/*     */   }
/*     */   
/*     */   public String toString() {
/* 512 */     return (this.leafComponentType != null) ? debugName() : "NULL TYPE ARRAY";
/*     */   }
/*     */   
/*     */   public TypeBinding unannotated() {
/* 516 */     return hasTypeAnnotations() ? this.environment.getUnannotatedType(this) : this;
/*     */   }
/*     */   
/*     */   public TypeBinding withoutToplevelNullAnnotation() {
/* 520 */     if (!hasNullTypeAnnotations())
/* 521 */       return this; 
/* 522 */     AnnotationBinding[] newAnnotations = this.environment.filterNullTypeAnnotations(this.typeAnnotations);
/* 523 */     return this.environment.createArrayType(this.leafComponentType, this.dimensions, newAnnotations);
/*     */   }
/*     */   
/*     */   public TypeBinding uncapture(Scope scope) {
/* 527 */     if ((this.tagBits & 0x2000000000000000L) == 0L)
/* 528 */       return this; 
/* 529 */     TypeBinding leafType = this.leafComponentType.uncapture(scope);
/* 530 */     return scope.environment().createArrayType(leafType, this.dimensions, this.typeAnnotations);
/*     */   }
/*     */   
/*     */   public boolean acceptsNonNullDefault() {
/* 534 */     return true;
/*     */   }
/*     */   
/*     */   public long updateTagBits() {
/* 538 */     if (this.leafComponentType != null)
/* 539 */       this.tagBits |= this.leafComponentType.updateTagBits(); 
/* 540 */     return super.updateTagBits();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MethodBinding getCloneMethod(final MethodBinding originalMethod) {
/* 547 */     if (this.clone != null)
/* 548 */       return this.clone; 
/* 549 */     MethodBinding method = new MethodBinding()
/*     */       {
/*     */         public char[] signature(ClassFile classFile) {
/* 552 */           return originalMethod.signature();
/*     */         }
/*     */       };
/* 555 */     method.modifiers = originalMethod.modifiers;
/* 556 */     method.selector = originalMethod.selector;
/* 557 */     method.declaringClass = originalMethod.declaringClass;
/* 558 */     method.typeVariables = Binding.NO_TYPE_VARIABLES;
/* 559 */     method.parameters = originalMethod.parameters;
/* 560 */     method.thrownExceptions = Binding.NO_EXCEPTIONS;
/* 561 */     method.tagBits = originalMethod.tagBits;
/* 562 */     method.returnType = (this.environment.globalOptions.sourceLevel >= 3211264L) ? this : originalMethod.returnType;
/* 563 */     if (this.environment.globalOptions.isAnnotationBasedNullAnalysisEnabled)
/* 564 */       if (this.environment.usesNullTypeAnnotations()) {
/* 565 */         method.returnType = this.environment.createAnnotatedType(method.returnType, new AnnotationBinding[] { this.environment.getNonNullAnnotation() });
/*     */       } else {
/* 567 */         method.tagBits |= 0x100000000000000L;
/*     */       }  
/* 569 */     if ((method.returnType.tagBits & 0x80L) != 0L) {
/* 570 */       method.tagBits |= 0x80L;
/*     */     }
/* 572 */     return this.clone = method;
/*     */   }
/*     */   public static boolean isArrayClone(TypeBinding receiverType, MethodBinding binding) {
/* 575 */     if (receiverType instanceof ArrayBinding) {
/* 576 */       MethodBinding clone = ((ArrayBinding)receiverType).clone;
/* 577 */       return (clone != null && binding == clone);
/*     */     } 
/* 579 */     return false;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\lookup\ArrayBinding.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */