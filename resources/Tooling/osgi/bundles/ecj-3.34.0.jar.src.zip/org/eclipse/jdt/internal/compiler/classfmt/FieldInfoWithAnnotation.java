/*    */ package org.eclipse.jdt.internal.compiler.classfmt;
/*    */ 
/*    */ import org.eclipse.jdt.internal.compiler.env.IBinaryAnnotation;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FieldInfoWithAnnotation
/*    */   extends FieldInfo
/*    */ {
/*    */   private AnnotationInfo[] annotations;
/*    */   
/*    */   FieldInfoWithAnnotation(FieldInfo info, AnnotationInfo[] annos) {
/* 22 */     super(info.reference, info.constantPoolOffsets, info.structOffset, info.version);
/* 23 */     this.accessFlags = info.accessFlags;
/* 24 */     this.attributeBytes = info.attributeBytes;
/* 25 */     this.constant = info.constant;
/* 26 */     this.constantPoolOffsets = info.constantPoolOffsets;
/* 27 */     this.descriptor = info.descriptor;
/* 28 */     this.name = info.name;
/* 29 */     this.signature = info.signature;
/* 30 */     this.signatureUtf8Offset = info.signatureUtf8Offset;
/* 31 */     this.tagBits = info.tagBits;
/* 32 */     this.wrappedConstantValue = info.wrappedConstantValue;
/* 33 */     this.annotations = annos;
/*    */   }
/*    */   
/*    */   public IBinaryAnnotation[] getAnnotations() {
/* 37 */     return (IBinaryAnnotation[])this.annotations;
/*    */   }
/*    */   
/*    */   protected void initialize() {
/* 41 */     if (this.annotations != null)
/* 42 */       for (int i = 0, max = this.annotations.length; i < max; i++)
/* 43 */         this.annotations[i].initialize();  
/* 44 */     super.initialize();
/*    */   }
/*    */   
/*    */   protected void reset() {
/* 48 */     if (this.annotations != null)
/* 49 */       for (int i = 0, max = this.annotations.length; i < max; i++)
/* 50 */         this.annotations[i].reset();  
/* 51 */     super.reset();
/*    */   }
/*    */   
/*    */   public String toString() {
/* 55 */     StringBuffer buffer = new StringBuffer(getClass().getName());
/* 56 */     if (this.annotations != null) {
/* 57 */       buffer.append('\n');
/* 58 */       for (int i = 0; i < this.annotations.length; i++) {
/* 59 */         buffer.append(this.annotations[i]);
/* 60 */         buffer.append('\n');
/*    */       } 
/*    */     } 
/* 63 */     toStringContent(buffer);
/* 64 */     return buffer.toString();
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\classfmt\FieldInfoWithAnnotation.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */