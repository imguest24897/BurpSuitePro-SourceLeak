package org.eclipse.jdt.internal.compiler.batch;

public interface ClasspathSectionProblemReporter {
  void invalidClasspathSection(String paramString);
  
  void multipleClasspathSections(String paramString);
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\batch\FileSystem$ClasspathSectionProblemReporter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */