/*      */ package org.eclipse.jdt.internal.compiler.impl;
/*      */ 
/*      */ import org.eclipse.jdt.internal.compiler.ast.OperatorIds;
/*      */ import org.eclipse.jdt.internal.compiler.lookup.TypeIds;
/*      */ import org.eclipse.jdt.internal.compiler.problem.ShouldNotImplement;
/*      */ import org.eclipse.jdt.internal.compiler.util.Messages;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public abstract class Constant
/*      */   implements TypeIds, OperatorIds
/*      */ {
/*   23 */   public static final Constant NotAConstant = DoubleConstant.fromValue(Double.NaN);
/*   24 */   public static final Constant[] NotAConstantList = new Constant[] { DoubleConstant.fromValue(Double.NaN) };
/*      */   
/*      */   public boolean booleanValue() {
/*   27 */     throw new ShouldNotImplement(Messages.bind(Messages.constant_cannotCastedInto, new String[] { typeName(), "boolean" }));
/*      */   }
/*      */   
/*      */   public byte byteValue() {
/*   31 */     throw new ShouldNotImplement(Messages.bind(Messages.constant_cannotCastedInto, new String[] { typeName(), "byte" }));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Constant castTo(int conversionToTargetType) {
/*   39 */     if (this == NotAConstant) return NotAConstant; 
/*   40 */     switch (conversionToTargetType) { case 0:
/*   41 */         return this;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 51:
/*   57 */         return this;
/*   58 */       case 55: return ByteConstant.fromValue((byte)(int)longValue());
/*   59 */       case 52: return ByteConstant.fromValue((byte)shortValue());
/*      */ 
/*      */       
/*      */       case 56:
/*   63 */         return ByteConstant.fromValue((byte)(int)doubleValue());
/*   64 */       case 57: return ByteConstant.fromValue((byte)(int)floatValue());
/*      */       case 50:
/*   66 */         return ByteConstant.fromValue((byte)charValue());
/*   67 */       case 58: return ByteConstant.fromValue((byte)intValue());
/*      */       
/*      */       case 115:
/*   70 */         return LongConstant.fromValue(byteValue());
/*   71 */       case 119: return this;
/*   72 */       case 116: return LongConstant.fromValue(shortValue());
/*      */ 
/*      */       
/*      */       case 120:
/*   76 */         return LongConstant.fromValue((long)doubleValue());
/*   77 */       case 121: return LongConstant.fromValue((long)floatValue());
/*      */       case 114:
/*   79 */         return LongConstant.fromValue(charValue());
/*   80 */       case 122: return LongConstant.fromValue(intValue());
/*      */       
/*      */       case 67:
/*   83 */         return ShortConstant.fromValue(byteValue());
/*   84 */       case 71: return ShortConstant.fromValue((short)(int)longValue());
/*   85 */       case 68: return this;
/*      */ 
/*      */       
/*      */       case 72:
/*   89 */         return ShortConstant.fromValue((short)(int)doubleValue());
/*   90 */       case 73: return ShortConstant.fromValue((short)(int)floatValue());
/*      */       case 66:
/*   92 */         return ShortConstant.fromValue((short)charValue());
/*   93 */       case 74: return ShortConstant.fromValue((short)intValue());
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 187:
/*  113 */         return this;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 131:
/*  135 */         return DoubleConstant.fromValue(byteValue());
/*  136 */       case 135: return DoubleConstant.fromValue(longValue());
/*  137 */       case 132: return DoubleConstant.fromValue(shortValue());
/*      */ 
/*      */       
/*      */       case 136:
/*  141 */         return this;
/*  142 */       case 137: return DoubleConstant.fromValue(floatValue());
/*      */       case 130:
/*  144 */         return DoubleConstant.fromValue(charValue());
/*  145 */       case 138: return DoubleConstant.fromValue(intValue());
/*      */       
/*      */       case 147:
/*  148 */         return FloatConstant.fromValue(byteValue());
/*  149 */       case 151: return FloatConstant.fromValue((float)longValue());
/*  150 */       case 148: return FloatConstant.fromValue(shortValue());
/*      */ 
/*      */       
/*      */       case 152:
/*  154 */         return FloatConstant.fromValue((float)doubleValue());
/*  155 */       case 153: return this;
/*      */       case 146:
/*  157 */         return FloatConstant.fromValue(charValue());
/*  158 */       case 154: return FloatConstant.fromValue(intValue());
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 85:
/*  169 */         return this;
/*      */ 
/*      */ 
/*      */       
/*      */       case 35:
/*  174 */         return CharConstant.fromValue((char)byteValue());
/*  175 */       case 39: return CharConstant.fromValue((char)(int)longValue());
/*  176 */       case 36: return CharConstant.fromValue((char)shortValue());
/*      */ 
/*      */       
/*      */       case 40:
/*  180 */         return CharConstant.fromValue((char)(int)doubleValue());
/*  181 */       case 41: return CharConstant.fromValue((char)(int)floatValue());
/*      */       case 34:
/*  183 */         return this;
/*  184 */       case 42: return CharConstant.fromValue((char)intValue());
/*      */       
/*      */       case 163:
/*  187 */         return IntConstant.fromValue(byteValue());
/*  188 */       case 167: return IntConstant.fromValue((int)longValue());
/*  189 */       case 164: return IntConstant.fromValue(shortValue());
/*      */ 
/*      */       
/*      */       case 168:
/*  193 */         return IntConstant.fromValue((int)doubleValue());
/*  194 */       case 169: return IntConstant.fromValue((int)floatValue());
/*      */       case 162:
/*  196 */         return IntConstant.fromValue(charValue());
/*  197 */       case 170: return this; }
/*      */ 
/*      */     
/*  200 */     return NotAConstant;
/*      */   }
/*      */   
/*      */   public char charValue() {
/*  204 */     throw new ShouldNotImplement(Messages.bind(Messages.constant_cannotCastedInto, new String[] { typeName(), "char" }));
/*      */   } public static final Constant computeConstantOperation(Constant cst, int id, int operator) {
/*      */     float f;
/*      */     double d;
/*  208 */     switch (operator) {
/*      */       case 11:
/*  210 */         return BooleanConstant.fromValue(!cst.booleanValue());
/*      */       case 14:
/*  212 */         return computeConstantOperationPLUS(IntConstant.fromValue(0), 10, cst, id);
/*      */       case 13:
/*  214 */         switch (id) {
/*      */           case 9:
/*  216 */             if ((f = cst.floatValue()) == 0.0F) {
/*      */               
/*  218 */               if (Float.floatToIntBits(f) == 0) {
/*  219 */                 return FloatConstant.fromValue(-0.0F);
/*      */               }
/*  221 */               return FloatConstant.fromValue(0.0F);
/*      */             }  break;
/*      */           case 8:
/*  224 */             if ((d = cst.doubleValue()) == 0.0D) {
/*      */               
/*  226 */               if (Double.doubleToLongBits(d) == 0L) {
/*  227 */                 return DoubleConstant.fromValue(-0.0D);
/*      */               }
/*  229 */               return DoubleConstant.fromValue(0.0D);
/*      */             }  break;
/*      */         } 
/*  232 */         return computeConstantOperationMINUS(IntConstant.fromValue(0), 10, cst, id);
/*      */       case 12:
/*  234 */         switch (id) { case 2:
/*  235 */             return IntConstant.fromValue(cst.charValue() ^ 0xFFFFFFFF);
/*  236 */           case 3: return IntConstant.fromValue(cst.byteValue() ^ 0xFFFFFFFF);
/*  237 */           case 4: return IntConstant.fromValue(cst.shortValue() ^ 0xFFFFFFFF);
/*  238 */           case 10: return IntConstant.fromValue(cst.intValue() ^ 0xFFFFFFFF);
/*  239 */           case 7: return LongConstant.fromValue(cst.longValue() ^ 0xFFFFFFFFFFFFFFFFL); }
/*  240 */          return NotAConstant;
/*      */     } 
/*  242 */     return NotAConstant;
/*      */   }
/*      */ 
/*      */   
/*      */   public static final Constant computeConstantOperation(Constant left, int leftId, int operator, Constant right, int rightId) {
/*  247 */     switch (operator) { case 2:
/*  248 */         return computeConstantOperationAND(left, leftId, right, rightId);
/*  249 */       case 0: return computeConstantOperationAND_AND(left, leftId, right, rightId);
/*  250 */       case 9: return computeConstantOperationDIVIDE(left, leftId, right, rightId);
/*  251 */       case 6: return computeConstantOperationGREATER(left, leftId, right, rightId);
/*  252 */       case 7: return computeConstantOperationGREATER_EQUAL(left, leftId, right, rightId);
/*  253 */       case 10: return computeConstantOperationLEFT_SHIFT(left, leftId, right, rightId);
/*  254 */       case 4: return computeConstantOperationLESS(left, leftId, right, rightId);
/*  255 */       case 5: return computeConstantOperationLESS_EQUAL(left, leftId, right, rightId);
/*  256 */       case 13: return computeConstantOperationMINUS(left, leftId, right, rightId);
/*  257 */       case 15: return computeConstantOperationMULTIPLY(left, leftId, right, rightId);
/*  258 */       case 3: return computeConstantOperationOR(left, leftId, right, rightId);
/*  259 */       case 1: return computeConstantOperationOR_OR(left, leftId, right, rightId);
/*  260 */       case 14: return computeConstantOperationPLUS(left, leftId, right, rightId);
/*  261 */       case 16: return computeConstantOperationREMAINDER(left, leftId, right, rightId);
/*  262 */       case 17: return computeConstantOperationRIGHT_SHIFT(left, leftId, right, rightId);
/*  263 */       case 19: return computeConstantOperationUNSIGNED_RIGHT_SHIFT(left, leftId, right, rightId);
/*  264 */       case 8: return computeConstantOperationXOR(left, leftId, right, rightId); }
/*  265 */      return NotAConstant;
/*      */   }
/*      */ 
/*      */   
/*      */   public static final Constant computeConstantOperationAND(Constant left, int leftId, Constant right, int rightId) {
/*  270 */     switch (leftId) { case 5:
/*  271 */         return BooleanConstant.fromValue(left.booleanValue() & right.booleanValue());
/*      */       case 2:
/*  273 */         switch (rightId) { case 2:
/*  274 */             return IntConstant.fromValue(left.charValue() & right.charValue());
/*  275 */           case 3: return IntConstant.fromValue(left.charValue() & right.byteValue());
/*  276 */           case 4: return IntConstant.fromValue(left.charValue() & right.shortValue());
/*  277 */           case 10: return IntConstant.fromValue(left.charValue() & right.intValue());
/*  278 */           case 7: return LongConstant.fromValue(left.charValue() & right.longValue()); }
/*      */         
/*      */         break;
/*      */       case 3:
/*  282 */         switch (rightId) { case 2:
/*  283 */             return IntConstant.fromValue(left.byteValue() & right.charValue());
/*  284 */           case 3: return IntConstant.fromValue(left.byteValue() & right.byteValue());
/*  285 */           case 4: return IntConstant.fromValue(left.byteValue() & right.shortValue());
/*  286 */           case 10: return IntConstant.fromValue(left.byteValue() & right.intValue());
/*  287 */           case 7: return LongConstant.fromValue(left.byteValue() & right.longValue()); }
/*      */         
/*      */         break;
/*      */       case 4:
/*  291 */         switch (rightId) { case 2:
/*  292 */             return IntConstant.fromValue(left.shortValue() & right.charValue());
/*  293 */           case 3: return IntConstant.fromValue(left.shortValue() & right.byteValue());
/*  294 */           case 4: return IntConstant.fromValue(left.shortValue() & right.shortValue());
/*  295 */           case 10: return IntConstant.fromValue(left.shortValue() & right.intValue());
/*  296 */           case 7: return LongConstant.fromValue(left.shortValue() & right.longValue()); }
/*      */         
/*      */         break;
/*      */       case 10:
/*  300 */         switch (rightId) { case 2:
/*  301 */             return IntConstant.fromValue(left.intValue() & right.charValue());
/*  302 */           case 3: return IntConstant.fromValue(left.intValue() & right.byteValue());
/*  303 */           case 4: return IntConstant.fromValue(left.intValue() & right.shortValue());
/*  304 */           case 10: return IntConstant.fromValue(left.intValue() & right.intValue());
/*  305 */           case 7: return LongConstant.fromValue(left.intValue() & right.longValue()); }
/*      */         
/*      */         break;
/*      */       case 7:
/*  309 */         switch (rightId) { case 2:
/*  310 */             return LongConstant.fromValue(left.longValue() & right.charValue());
/*  311 */           case 3: return LongConstant.fromValue(left.longValue() & right.byteValue());
/*  312 */           case 4: return LongConstant.fromValue(left.longValue() & right.shortValue());
/*  313 */           case 10: return LongConstant.fromValue(left.longValue() & right.intValue());
/*  314 */           case 7: return LongConstant.fromValue(left.longValue() & right.longValue()); }
/*      */          break; }
/*      */     
/*  317 */     return NotAConstant;
/*      */   }
/*      */   
/*      */   public static final Constant computeConstantOperationAND_AND(Constant left, int leftId, Constant right, int rightId) {
/*  321 */     return BooleanConstant.fromValue((left.booleanValue() && right.booleanValue()));
/*      */   }
/*      */ 
/*      */   
/*      */   public static final Constant computeConstantOperationDIVIDE(Constant left, int leftId, Constant right, int rightId) {
/*  326 */     switch (leftId) {
/*      */       case 2:
/*  328 */         switch (rightId) { case 2:
/*  329 */             return IntConstant.fromValue(left.charValue() / right.charValue());
/*  330 */           case 9: return FloatConstant.fromValue(left.charValue() / right.floatValue());
/*  331 */           case 8: return DoubleConstant.fromValue(left.charValue() / right.doubleValue());
/*  332 */           case 3: return IntConstant.fromValue(left.charValue() / right.byteValue());
/*  333 */           case 4: return IntConstant.fromValue(left.charValue() / right.shortValue());
/*  334 */           case 10: return IntConstant.fromValue(left.charValue() / right.intValue());
/*  335 */           case 7: return LongConstant.fromValue(left.charValue() / right.longValue()); }
/*      */         
/*      */         break;
/*      */       case 9:
/*  339 */         switch (rightId) { case 2:
/*  340 */             return FloatConstant.fromValue(left.floatValue() / right.charValue());
/*  341 */           case 9: return FloatConstant.fromValue(left.floatValue() / right.floatValue());
/*  342 */           case 8: return DoubleConstant.fromValue(left.floatValue() / right.doubleValue());
/*  343 */           case 3: return FloatConstant.fromValue(left.floatValue() / right.byteValue());
/*  344 */           case 4: return FloatConstant.fromValue(left.floatValue() / right.shortValue());
/*  345 */           case 10: return FloatConstant.fromValue(left.floatValue() / right.intValue());
/*  346 */           case 7: return FloatConstant.fromValue(left.floatValue() / (float)right.longValue()); }
/*      */         
/*      */         break;
/*      */       case 8:
/*  350 */         switch (rightId) { case 2:
/*  351 */             return DoubleConstant.fromValue(left.doubleValue() / right.charValue());
/*  352 */           case 9: return DoubleConstant.fromValue(left.doubleValue() / right.floatValue());
/*  353 */           case 8: return DoubleConstant.fromValue(left.doubleValue() / right.doubleValue());
/*  354 */           case 3: return DoubleConstant.fromValue(left.doubleValue() / right.byteValue());
/*  355 */           case 4: return DoubleConstant.fromValue(left.doubleValue() / right.shortValue());
/*  356 */           case 10: return DoubleConstant.fromValue(left.doubleValue() / right.intValue());
/*  357 */           case 7: return DoubleConstant.fromValue(left.doubleValue() / right.longValue()); }
/*      */         
/*      */         break;
/*      */       case 3:
/*  361 */         switch (rightId) { case 2:
/*  362 */             return IntConstant.fromValue(left.byteValue() / right.charValue());
/*  363 */           case 9: return FloatConstant.fromValue(left.byteValue() / right.floatValue());
/*  364 */           case 8: return DoubleConstant.fromValue(left.byteValue() / right.doubleValue());
/*  365 */           case 3: return IntConstant.fromValue(left.byteValue() / right.byteValue());
/*  366 */           case 4: return IntConstant.fromValue(left.byteValue() / right.shortValue());
/*  367 */           case 10: return IntConstant.fromValue(left.byteValue() / right.intValue());
/*  368 */           case 7: return LongConstant.fromValue(left.byteValue() / right.longValue()); }
/*      */         
/*      */         break;
/*      */       case 4:
/*  372 */         switch (rightId) { case 2:
/*  373 */             return IntConstant.fromValue(left.shortValue() / right.charValue());
/*  374 */           case 9: return FloatConstant.fromValue(left.shortValue() / right.floatValue());
/*  375 */           case 8: return DoubleConstant.fromValue(left.shortValue() / right.doubleValue());
/*  376 */           case 3: return IntConstant.fromValue(left.shortValue() / right.byteValue());
/*  377 */           case 4: return IntConstant.fromValue(left.shortValue() / right.shortValue());
/*  378 */           case 10: return IntConstant.fromValue(left.shortValue() / right.intValue());
/*  379 */           case 7: return LongConstant.fromValue(left.shortValue() / right.longValue()); }
/*      */         
/*      */         break;
/*      */       case 10:
/*  383 */         switch (rightId) { case 2:
/*  384 */             return IntConstant.fromValue(left.intValue() / right.charValue());
/*  385 */           case 9: return FloatConstant.fromValue(left.intValue() / right.floatValue());
/*  386 */           case 8: return DoubleConstant.fromValue(left.intValue() / right.doubleValue());
/*  387 */           case 3: return IntConstant.fromValue(left.intValue() / right.byteValue());
/*  388 */           case 4: return IntConstant.fromValue(left.intValue() / right.shortValue());
/*  389 */           case 10: return IntConstant.fromValue(left.intValue() / right.intValue());
/*  390 */           case 7: return LongConstant.fromValue(left.intValue() / right.longValue()); }
/*      */         
/*      */         break;
/*      */       case 7:
/*  394 */         switch (rightId) { case 2:
/*  395 */             return LongConstant.fromValue(left.longValue() / right.charValue());
/*  396 */           case 9: return FloatConstant.fromValue((float)left.longValue() / right.floatValue());
/*  397 */           case 8: return DoubleConstant.fromValue(left.longValue() / right.doubleValue());
/*  398 */           case 3: return LongConstant.fromValue(left.longValue() / right.byteValue());
/*  399 */           case 4: return LongConstant.fromValue(left.longValue() / right.shortValue());
/*  400 */           case 10: return LongConstant.fromValue(left.longValue() / right.intValue());
/*  401 */           case 7: return LongConstant.fromValue(left.longValue() / right.longValue()); }
/*      */          break;
/*      */     } 
/*  404 */     return NotAConstant;
/*      */   }
/*      */   
/*      */   public static final Constant computeConstantOperationEQUAL_EQUAL(Constant left, int leftId, Constant right, int rightId) {
/*  408 */     switch (leftId) {
/*      */       case 5:
/*  410 */         if (rightId == 5) {
/*  411 */           return BooleanConstant.fromValue((left.booleanValue() == right.booleanValue()));
/*      */         }
/*      */         break;
/*      */       case 2:
/*  415 */         switch (rightId) { case 2:
/*  416 */             return BooleanConstant.fromValue((left.charValue() == right.charValue()));
/*  417 */           case 9: return BooleanConstant.fromValue((left.charValue() == right.floatValue()));
/*  418 */           case 8: return BooleanConstant.fromValue((left.charValue() == right.doubleValue()));
/*  419 */           case 3: return BooleanConstant.fromValue((left.charValue() == right.byteValue()));
/*  420 */           case 4: return BooleanConstant.fromValue((left.charValue() == right.shortValue()));
/*  421 */           case 10: return BooleanConstant.fromValue((left.charValue() == right.intValue()));
/*  422 */           case 7: return BooleanConstant.fromValue((left.charValue() == right.longValue())); }
/*      */          break;
/*      */       case 9:
/*  425 */         switch (rightId) { case 2:
/*  426 */             return BooleanConstant.fromValue((left.floatValue() == right.charValue()));
/*  427 */           case 9: return BooleanConstant.fromValue((left.floatValue() == right.floatValue()));
/*  428 */           case 8: return BooleanConstant.fromValue((left.floatValue() == right.doubleValue()));
/*  429 */           case 3: return BooleanConstant.fromValue((left.floatValue() == right.byteValue()));
/*  430 */           case 4: return BooleanConstant.fromValue((left.floatValue() == right.shortValue()));
/*  431 */           case 10: return BooleanConstant.fromValue((left.floatValue() == right.intValue()));
/*  432 */           case 7: return BooleanConstant.fromValue((left.floatValue() == (float)right.longValue())); }
/*      */         
/*      */         break;
/*      */       case 8:
/*  436 */         switch (rightId) { case 2:
/*  437 */             return BooleanConstant.fromValue((left.doubleValue() == right.charValue()));
/*  438 */           case 9: return BooleanConstant.fromValue((left.doubleValue() == right.floatValue()));
/*  439 */           case 8: return BooleanConstant.fromValue((left.doubleValue() == right.doubleValue()));
/*  440 */           case 3: return BooleanConstant.fromValue((left.doubleValue() == right.byteValue()));
/*  441 */           case 4: return BooleanConstant.fromValue((left.doubleValue() == right.shortValue()));
/*  442 */           case 10: return BooleanConstant.fromValue((left.doubleValue() == right.intValue()));
/*  443 */           case 7: return BooleanConstant.fromValue((left.doubleValue() == right.longValue())); }
/*      */         
/*      */         break;
/*      */       case 3:
/*  447 */         switch (rightId) { case 2:
/*  448 */             return BooleanConstant.fromValue((left.byteValue() == right.charValue()));
/*  449 */           case 9: return BooleanConstant.fromValue((left.byteValue() == right.floatValue()));
/*  450 */           case 8: return BooleanConstant.fromValue((left.byteValue() == right.doubleValue()));
/*  451 */           case 3: return BooleanConstant.fromValue((left.byteValue() == right.byteValue()));
/*  452 */           case 4: return BooleanConstant.fromValue((left.byteValue() == right.shortValue()));
/*  453 */           case 10: return BooleanConstant.fromValue((left.byteValue() == right.intValue()));
/*  454 */           case 7: return BooleanConstant.fromValue((left.byteValue() == right.longValue())); }
/*      */         
/*      */         break;
/*      */       case 4:
/*  458 */         switch (rightId) { case 2:
/*  459 */             return BooleanConstant.fromValue((left.shortValue() == right.charValue()));
/*  460 */           case 9: return BooleanConstant.fromValue((left.shortValue() == right.floatValue()));
/*  461 */           case 8: return BooleanConstant.fromValue((left.shortValue() == right.doubleValue()));
/*  462 */           case 3: return BooleanConstant.fromValue((left.shortValue() == right.byteValue()));
/*  463 */           case 4: return BooleanConstant.fromValue((left.shortValue() == right.shortValue()));
/*  464 */           case 10: return BooleanConstant.fromValue((left.shortValue() == right.intValue()));
/*  465 */           case 7: return BooleanConstant.fromValue((left.shortValue() == right.longValue())); }
/*      */         
/*      */         break;
/*      */       case 10:
/*  469 */         switch (rightId) { case 2:
/*  470 */             return BooleanConstant.fromValue((left.intValue() == right.charValue()));
/*  471 */           case 9: return BooleanConstant.fromValue((left.intValue() == right.floatValue()));
/*  472 */           case 8: return BooleanConstant.fromValue((left.intValue() == right.doubleValue()));
/*  473 */           case 3: return BooleanConstant.fromValue((left.intValue() == right.byteValue()));
/*  474 */           case 4: return BooleanConstant.fromValue((left.intValue() == right.shortValue()));
/*  475 */           case 10: return BooleanConstant.fromValue((left.intValue() == right.intValue()));
/*  476 */           case 7: return BooleanConstant.fromValue((left.intValue() == right.longValue())); }
/*      */         
/*      */         break;
/*      */       case 7:
/*  480 */         switch (rightId) { case 2:
/*  481 */             return BooleanConstant.fromValue((left.longValue() == right.charValue()));
/*  482 */           case 9: return BooleanConstant.fromValue(((float)left.longValue() == right.floatValue()));
/*  483 */           case 8: return BooleanConstant.fromValue((left.longValue() == right.doubleValue()));
/*  484 */           case 3: return BooleanConstant.fromValue((left.longValue() == right.byteValue()));
/*  485 */           case 4: return BooleanConstant.fromValue((left.longValue() == right.shortValue()));
/*  486 */           case 10: return BooleanConstant.fromValue((left.longValue() == right.intValue()));
/*  487 */           case 7: return BooleanConstant.fromValue((left.longValue() == right.longValue())); }
/*      */         
/*      */         break;
/*      */       case 11:
/*  491 */         if (rightId == 11)
/*      */         {
/*      */           
/*  494 */           return BooleanConstant.fromValue(((StringConstant)left).hasSameValue(right));
/*      */         }
/*      */         break;
/*      */       case 12:
/*  498 */         if (rightId == 11) {
/*  499 */           return BooleanConstant.fromValue(false);
/*      */         }
/*  501 */         if (rightId == 12) {
/*  502 */           return BooleanConstant.fromValue(true);
/*      */         }
/*      */         break;
/*      */     } 
/*  506 */     return BooleanConstant.fromValue(false);
/*      */   }
/*      */   
/*      */   public static final Constant computeConstantOperationGREATER(Constant left, int leftId, Constant right, int rightId) {
/*  510 */     switch (leftId) {
/*      */       case 2:
/*  512 */         switch (rightId) { case 2:
/*  513 */             return BooleanConstant.fromValue((left.charValue() > right.charValue()));
/*  514 */           case 9: return BooleanConstant.fromValue((left.charValue() > right.floatValue()));
/*  515 */           case 8: return BooleanConstant.fromValue((left.charValue() > right.doubleValue()));
/*  516 */           case 3: return BooleanConstant.fromValue((left.charValue() > right.byteValue()));
/*  517 */           case 4: return BooleanConstant.fromValue((left.charValue() > right.shortValue()));
/*  518 */           case 10: return BooleanConstant.fromValue((left.charValue() > right.intValue()));
/*  519 */           case 7: return BooleanConstant.fromValue((left.charValue() > right.longValue())); }
/*      */         
/*      */         break;
/*      */       case 9:
/*  523 */         switch (rightId) { case 2:
/*  524 */             return BooleanConstant.fromValue((left.floatValue() > right.charValue()));
/*  525 */           case 9: return BooleanConstant.fromValue((left.floatValue() > right.floatValue()));
/*  526 */           case 8: return BooleanConstant.fromValue((left.floatValue() > right.doubleValue()));
/*  527 */           case 3: return BooleanConstant.fromValue((left.floatValue() > right.byteValue()));
/*  528 */           case 4: return BooleanConstant.fromValue((left.floatValue() > right.shortValue()));
/*  529 */           case 10: return BooleanConstant.fromValue((left.floatValue() > right.intValue()));
/*  530 */           case 7: return BooleanConstant.fromValue((left.floatValue() > (float)right.longValue())); }
/*      */         
/*      */         break;
/*      */       case 8:
/*  534 */         switch (rightId) { case 2:
/*  535 */             return BooleanConstant.fromValue((left.doubleValue() > right.charValue()));
/*  536 */           case 9: return BooleanConstant.fromValue((left.doubleValue() > right.floatValue()));
/*  537 */           case 8: return BooleanConstant.fromValue((left.doubleValue() > right.doubleValue()));
/*  538 */           case 3: return BooleanConstant.fromValue((left.doubleValue() > right.byteValue()));
/*  539 */           case 4: return BooleanConstant.fromValue((left.doubleValue() > right.shortValue()));
/*  540 */           case 10: return BooleanConstant.fromValue((left.doubleValue() > right.intValue()));
/*  541 */           case 7: return BooleanConstant.fromValue((left.doubleValue() > right.longValue())); }
/*      */         
/*      */         break;
/*      */       case 3:
/*  545 */         switch (rightId) { case 2:
/*  546 */             return BooleanConstant.fromValue((left.byteValue() > right.charValue()));
/*  547 */           case 9: return BooleanConstant.fromValue((left.byteValue() > right.floatValue()));
/*  548 */           case 8: return BooleanConstant.fromValue((left.byteValue() > right.doubleValue()));
/*  549 */           case 3: return BooleanConstant.fromValue((left.byteValue() > right.byteValue()));
/*  550 */           case 4: return BooleanConstant.fromValue((left.byteValue() > right.shortValue()));
/*  551 */           case 10: return BooleanConstant.fromValue((left.byteValue() > right.intValue()));
/*  552 */           case 7: return BooleanConstant.fromValue((left.byteValue() > right.longValue())); }
/*      */         
/*      */         break;
/*      */       case 4:
/*  556 */         switch (rightId) { case 2:
/*  557 */             return BooleanConstant.fromValue((left.shortValue() > right.charValue()));
/*  558 */           case 9: return BooleanConstant.fromValue((left.shortValue() > right.floatValue()));
/*  559 */           case 8: return BooleanConstant.fromValue((left.shortValue() > right.doubleValue()));
/*  560 */           case 3: return BooleanConstant.fromValue((left.shortValue() > right.byteValue()));
/*  561 */           case 4: return BooleanConstant.fromValue((left.shortValue() > right.shortValue()));
/*  562 */           case 10: return BooleanConstant.fromValue((left.shortValue() > right.intValue()));
/*  563 */           case 7: return BooleanConstant.fromValue((left.shortValue() > right.longValue())); }
/*      */         
/*      */         break;
/*      */       case 10:
/*  567 */         switch (rightId) { case 2:
/*  568 */             return BooleanConstant.fromValue((left.intValue() > right.charValue()));
/*  569 */           case 9: return BooleanConstant.fromValue((left.intValue() > right.floatValue()));
/*  570 */           case 8: return BooleanConstant.fromValue((left.intValue() > right.doubleValue()));
/*  571 */           case 3: return BooleanConstant.fromValue((left.intValue() > right.byteValue()));
/*  572 */           case 4: return BooleanConstant.fromValue((left.intValue() > right.shortValue()));
/*  573 */           case 10: return BooleanConstant.fromValue((left.intValue() > right.intValue()));
/*  574 */           case 7: return BooleanConstant.fromValue((left.intValue() > right.longValue())); }
/*      */         
/*      */         break;
/*      */       case 7:
/*  578 */         switch (rightId) { case 2:
/*  579 */             return BooleanConstant.fromValue((left.longValue() > right.charValue()));
/*  580 */           case 9: return BooleanConstant.fromValue(((float)left.longValue() > right.floatValue()));
/*  581 */           case 8: return BooleanConstant.fromValue((left.longValue() > right.doubleValue()));
/*  582 */           case 3: return BooleanConstant.fromValue((left.longValue() > right.byteValue()));
/*  583 */           case 4: return BooleanConstant.fromValue((left.longValue() > right.shortValue()));
/*  584 */           case 10: return BooleanConstant.fromValue((left.longValue() > right.intValue()));
/*  585 */           case 7: return BooleanConstant.fromValue((left.longValue() > right.longValue())); }
/*      */         
/*      */         break;
/*      */     } 
/*  589 */     return NotAConstant;
/*      */   }
/*      */   
/*      */   public static final Constant computeConstantOperationGREATER_EQUAL(Constant left, int leftId, Constant right, int rightId) {
/*  593 */     switch (leftId) {
/*      */       case 2:
/*  595 */         switch (rightId) { case 2:
/*  596 */             return BooleanConstant.fromValue((left.charValue() >= right.charValue()));
/*  597 */           case 9: return BooleanConstant.fromValue((left.charValue() >= right.floatValue()));
/*  598 */           case 8: return BooleanConstant.fromValue((left.charValue() >= right.doubleValue()));
/*  599 */           case 3: return BooleanConstant.fromValue((left.charValue() >= right.byteValue()));
/*  600 */           case 4: return BooleanConstant.fromValue((left.charValue() >= right.shortValue()));
/*  601 */           case 10: return BooleanConstant.fromValue((left.charValue() >= right.intValue()));
/*  602 */           case 7: return BooleanConstant.fromValue((left.charValue() >= right.longValue())); }
/*      */         
/*      */         break;
/*      */       case 9:
/*  606 */         switch (rightId) { case 2:
/*  607 */             return BooleanConstant.fromValue((left.floatValue() >= right.charValue()));
/*  608 */           case 9: return BooleanConstant.fromValue((left.floatValue() >= right.floatValue()));
/*  609 */           case 8: return BooleanConstant.fromValue((left.floatValue() >= right.doubleValue()));
/*  610 */           case 3: return BooleanConstant.fromValue((left.floatValue() >= right.byteValue()));
/*  611 */           case 4: return BooleanConstant.fromValue((left.floatValue() >= right.shortValue()));
/*  612 */           case 10: return BooleanConstant.fromValue((left.floatValue() >= right.intValue()));
/*  613 */           case 7: return BooleanConstant.fromValue((left.floatValue() >= (float)right.longValue())); }
/*      */         
/*      */         break;
/*      */       case 8:
/*  617 */         switch (rightId) { case 2:
/*  618 */             return BooleanConstant.fromValue((left.doubleValue() >= right.charValue()));
/*  619 */           case 9: return BooleanConstant.fromValue((left.doubleValue() >= right.floatValue()));
/*  620 */           case 8: return BooleanConstant.fromValue((left.doubleValue() >= right.doubleValue()));
/*  621 */           case 3: return BooleanConstant.fromValue((left.doubleValue() >= right.byteValue()));
/*  622 */           case 4: return BooleanConstant.fromValue((left.doubleValue() >= right.shortValue()));
/*  623 */           case 10: return BooleanConstant.fromValue((left.doubleValue() >= right.intValue()));
/*  624 */           case 7: return BooleanConstant.fromValue((left.doubleValue() >= right.longValue())); }
/*      */         
/*      */         break;
/*      */       case 3:
/*  628 */         switch (rightId) { case 2:
/*  629 */             return BooleanConstant.fromValue((left.byteValue() >= right.charValue()));
/*  630 */           case 9: return BooleanConstant.fromValue((left.byteValue() >= right.floatValue()));
/*  631 */           case 8: return BooleanConstant.fromValue((left.byteValue() >= right.doubleValue()));
/*  632 */           case 3: return BooleanConstant.fromValue((left.byteValue() >= right.byteValue()));
/*  633 */           case 4: return BooleanConstant.fromValue((left.byteValue() >= right.shortValue()));
/*  634 */           case 10: return BooleanConstant.fromValue((left.byteValue() >= right.intValue()));
/*  635 */           case 7: return BooleanConstant.fromValue((left.byteValue() >= right.longValue())); }
/*      */         
/*      */         break;
/*      */       case 4:
/*  639 */         switch (rightId) { case 2:
/*  640 */             return BooleanConstant.fromValue((left.shortValue() >= right.charValue()));
/*  641 */           case 9: return BooleanConstant.fromValue((left.shortValue() >= right.floatValue()));
/*  642 */           case 8: return BooleanConstant.fromValue((left.shortValue() >= right.doubleValue()));
/*  643 */           case 3: return BooleanConstant.fromValue((left.shortValue() >= right.byteValue()));
/*  644 */           case 4: return BooleanConstant.fromValue((left.shortValue() >= right.shortValue()));
/*  645 */           case 10: return BooleanConstant.fromValue((left.shortValue() >= right.intValue()));
/*  646 */           case 7: return BooleanConstant.fromValue((left.shortValue() >= right.longValue())); }
/*      */         
/*      */         break;
/*      */       case 10:
/*  650 */         switch (rightId) { case 2:
/*  651 */             return BooleanConstant.fromValue((left.intValue() >= right.charValue()));
/*  652 */           case 9: return BooleanConstant.fromValue((left.intValue() >= right.floatValue()));
/*  653 */           case 8: return BooleanConstant.fromValue((left.intValue() >= right.doubleValue()));
/*  654 */           case 3: return BooleanConstant.fromValue((left.intValue() >= right.byteValue()));
/*  655 */           case 4: return BooleanConstant.fromValue((left.intValue() >= right.shortValue()));
/*  656 */           case 10: return BooleanConstant.fromValue((left.intValue() >= right.intValue()));
/*  657 */           case 7: return BooleanConstant.fromValue((left.intValue() >= right.longValue())); }
/*      */         
/*      */         break;
/*      */       case 7:
/*  661 */         switch (rightId) { case 2:
/*  662 */             return BooleanConstant.fromValue((left.longValue() >= right.charValue()));
/*  663 */           case 9: return BooleanConstant.fromValue(((float)left.longValue() >= right.floatValue()));
/*  664 */           case 8: return BooleanConstant.fromValue((left.longValue() >= right.doubleValue()));
/*  665 */           case 3: return BooleanConstant.fromValue((left.longValue() >= right.byteValue()));
/*  666 */           case 4: return BooleanConstant.fromValue((left.longValue() >= right.shortValue()));
/*  667 */           case 10: return BooleanConstant.fromValue((left.longValue() >= right.intValue()));
/*  668 */           case 7: return BooleanConstant.fromValue((left.longValue() >= right.longValue())); }
/*      */          break;
/*      */     } 
/*  671 */     return NotAConstant;
/*      */   }
/*      */   
/*      */   public static final Constant computeConstantOperationLEFT_SHIFT(Constant left, int leftId, Constant right, int rightId) {
/*  675 */     switch (leftId) {
/*      */       case 2:
/*  677 */         switch (rightId) { case 2:
/*  678 */             return IntConstant.fromValue(left.charValue() << right.charValue());
/*  679 */           case 3: return IntConstant.fromValue(left.charValue() << right.byteValue());
/*  680 */           case 4: return IntConstant.fromValue(left.charValue() << right.shortValue());
/*  681 */           case 10: return IntConstant.fromValue(left.charValue() << right.intValue());
/*  682 */           case 7: return IntConstant.fromValue(left.charValue() << (int)right.longValue()); }
/*      */         
/*      */         break;
/*      */       case 3:
/*  686 */         switch (rightId) { case 2:
/*  687 */             return IntConstant.fromValue(left.byteValue() << right.charValue());
/*  688 */           case 3: return IntConstant.fromValue(left.byteValue() << right.byteValue());
/*  689 */           case 4: return IntConstant.fromValue(left.byteValue() << right.shortValue());
/*  690 */           case 10: return IntConstant.fromValue(left.byteValue() << right.intValue());
/*  691 */           case 7: return IntConstant.fromValue(left.byteValue() << (int)right.longValue()); }
/*      */         
/*      */         break;
/*      */       case 4:
/*  695 */         switch (rightId) { case 2:
/*  696 */             return IntConstant.fromValue(left.shortValue() << right.charValue());
/*  697 */           case 3: return IntConstant.fromValue(left.shortValue() << right.byteValue());
/*  698 */           case 4: return IntConstant.fromValue(left.shortValue() << right.shortValue());
/*  699 */           case 10: return IntConstant.fromValue(left.shortValue() << right.intValue());
/*  700 */           case 7: return IntConstant.fromValue(left.shortValue() << (int)right.longValue()); }
/*      */         
/*      */         break;
/*      */       case 10:
/*  704 */         switch (rightId) { case 2:
/*  705 */             return IntConstant.fromValue(left.intValue() << right.charValue());
/*  706 */           case 3: return IntConstant.fromValue(left.intValue() << right.byteValue());
/*  707 */           case 4: return IntConstant.fromValue(left.intValue() << right.shortValue());
/*  708 */           case 10: return IntConstant.fromValue(left.intValue() << right.intValue());
/*  709 */           case 7: return IntConstant.fromValue(left.intValue() << (int)right.longValue()); }
/*      */         
/*      */         break;
/*      */       case 7:
/*  713 */         switch (rightId) { case 2:
/*  714 */             return LongConstant.fromValue(left.longValue() << right.charValue());
/*  715 */           case 3: return LongConstant.fromValue(left.longValue() << right.byteValue());
/*  716 */           case 4: return LongConstant.fromValue(left.longValue() << right.shortValue());
/*  717 */           case 10: return LongConstant.fromValue(left.longValue() << right.intValue());
/*  718 */           case 7: return LongConstant.fromValue(left.longValue() << (int)right.longValue()); }
/*      */          break;
/*      */     } 
/*  721 */     return NotAConstant;
/*      */   }
/*      */   
/*      */   public static final Constant computeConstantOperationLESS(Constant left, int leftId, Constant right, int rightId) {
/*  725 */     switch (leftId) {
/*      */       case 2:
/*  727 */         switch (rightId) { case 2:
/*  728 */             return BooleanConstant.fromValue((left.charValue() < right.charValue()));
/*  729 */           case 9: return BooleanConstant.fromValue((left.charValue() < right.floatValue()));
/*  730 */           case 8: return BooleanConstant.fromValue((left.charValue() < right.doubleValue()));
/*  731 */           case 3: return BooleanConstant.fromValue((left.charValue() < right.byteValue()));
/*  732 */           case 4: return BooleanConstant.fromValue((left.charValue() < right.shortValue()));
/*  733 */           case 10: return BooleanConstant.fromValue((left.charValue() < right.intValue()));
/*  734 */           case 7: return BooleanConstant.fromValue((left.charValue() < right.longValue())); }
/*      */         
/*      */         break;
/*      */       case 9:
/*  738 */         switch (rightId) { case 2:
/*  739 */             return BooleanConstant.fromValue((left.floatValue() < right.charValue()));
/*  740 */           case 9: return BooleanConstant.fromValue((left.floatValue() < right.floatValue()));
/*  741 */           case 8: return BooleanConstant.fromValue((left.floatValue() < right.doubleValue()));
/*  742 */           case 3: return BooleanConstant.fromValue((left.floatValue() < right.byteValue()));
/*  743 */           case 4: return BooleanConstant.fromValue((left.floatValue() < right.shortValue()));
/*  744 */           case 10: return BooleanConstant.fromValue((left.floatValue() < right.intValue()));
/*  745 */           case 7: return BooleanConstant.fromValue((left.floatValue() < (float)right.longValue())); }
/*      */         
/*      */         break;
/*      */       case 8:
/*  749 */         switch (rightId) { case 2:
/*  750 */             return BooleanConstant.fromValue((left.doubleValue() < right.charValue()));
/*  751 */           case 9: return BooleanConstant.fromValue((left.doubleValue() < right.floatValue()));
/*  752 */           case 8: return BooleanConstant.fromValue((left.doubleValue() < right.doubleValue()));
/*  753 */           case 3: return BooleanConstant.fromValue((left.doubleValue() < right.byteValue()));
/*  754 */           case 4: return BooleanConstant.fromValue((left.doubleValue() < right.shortValue()));
/*  755 */           case 10: return BooleanConstant.fromValue((left.doubleValue() < right.intValue()));
/*  756 */           case 7: return BooleanConstant.fromValue((left.doubleValue() < right.longValue())); }
/*      */         
/*      */         break;
/*      */       case 3:
/*  760 */         switch (rightId) { case 2:
/*  761 */             return BooleanConstant.fromValue((left.byteValue() < right.charValue()));
/*  762 */           case 9: return BooleanConstant.fromValue((left.byteValue() < right.floatValue()));
/*  763 */           case 8: return BooleanConstant.fromValue((left.byteValue() < right.doubleValue()));
/*  764 */           case 3: return BooleanConstant.fromValue((left.byteValue() < right.byteValue()));
/*  765 */           case 4: return BooleanConstant.fromValue((left.byteValue() < right.shortValue()));
/*  766 */           case 10: return BooleanConstant.fromValue((left.byteValue() < right.intValue()));
/*  767 */           case 7: return BooleanConstant.fromValue((left.byteValue() < right.longValue())); }
/*      */         
/*      */         break;
/*      */       case 4:
/*  771 */         switch (rightId) { case 2:
/*  772 */             return BooleanConstant.fromValue((left.shortValue() < right.charValue()));
/*  773 */           case 9: return BooleanConstant.fromValue((left.shortValue() < right.floatValue()));
/*  774 */           case 8: return BooleanConstant.fromValue((left.shortValue() < right.doubleValue()));
/*  775 */           case 3: return BooleanConstant.fromValue((left.shortValue() < right.byteValue()));
/*  776 */           case 4: return BooleanConstant.fromValue((left.shortValue() < right.shortValue()));
/*  777 */           case 10: return BooleanConstant.fromValue((left.shortValue() < right.intValue()));
/*  778 */           case 7: return BooleanConstant.fromValue((left.shortValue() < right.longValue())); }
/*      */         
/*      */         break;
/*      */       case 10:
/*  782 */         switch (rightId) { case 2:
/*  783 */             return BooleanConstant.fromValue((left.intValue() < right.charValue()));
/*  784 */           case 9: return BooleanConstant.fromValue((left.intValue() < right.floatValue()));
/*  785 */           case 8: return BooleanConstant.fromValue((left.intValue() < right.doubleValue()));
/*  786 */           case 3: return BooleanConstant.fromValue((left.intValue() < right.byteValue()));
/*  787 */           case 4: return BooleanConstant.fromValue((left.intValue() < right.shortValue()));
/*  788 */           case 10: return BooleanConstant.fromValue((left.intValue() < right.intValue()));
/*  789 */           case 7: return BooleanConstant.fromValue((left.intValue() < right.longValue())); }
/*      */         
/*      */         break;
/*      */       case 7:
/*  793 */         switch (rightId) { case 2:
/*  794 */             return BooleanConstant.fromValue((left.longValue() < right.charValue()));
/*  795 */           case 9: return BooleanConstant.fromValue(((float)left.longValue() < right.floatValue()));
/*  796 */           case 8: return BooleanConstant.fromValue((left.longValue() < right.doubleValue()));
/*  797 */           case 3: return BooleanConstant.fromValue((left.longValue() < right.byteValue()));
/*  798 */           case 4: return BooleanConstant.fromValue((left.longValue() < right.shortValue()));
/*  799 */           case 10: return BooleanConstant.fromValue((left.longValue() < right.intValue()));
/*  800 */           case 7: return BooleanConstant.fromValue((left.longValue() < right.longValue())); }
/*      */          break;
/*      */     } 
/*  803 */     return NotAConstant;
/*      */   }
/*      */   
/*      */   public static final Constant computeConstantOperationLESS_EQUAL(Constant left, int leftId, Constant right, int rightId) {
/*  807 */     switch (leftId) {
/*      */       case 2:
/*  809 */         switch (rightId) { case 2:
/*  810 */             return BooleanConstant.fromValue((left.charValue() <= right.charValue()));
/*  811 */           case 9: return BooleanConstant.fromValue((left.charValue() <= right.floatValue()));
/*  812 */           case 8: return BooleanConstant.fromValue((left.charValue() <= right.doubleValue()));
/*  813 */           case 3: return BooleanConstant.fromValue((left.charValue() <= right.byteValue()));
/*  814 */           case 4: return BooleanConstant.fromValue((left.charValue() <= right.shortValue()));
/*  815 */           case 10: return BooleanConstant.fromValue((left.charValue() <= right.intValue()));
/*  816 */           case 7: return BooleanConstant.fromValue((left.charValue() <= right.longValue())); }
/*      */         
/*      */         break;
/*      */       case 9:
/*  820 */         switch (rightId) { case 2:
/*  821 */             return BooleanConstant.fromValue((left.floatValue() <= right.charValue()));
/*  822 */           case 9: return BooleanConstant.fromValue((left.floatValue() <= right.floatValue()));
/*  823 */           case 8: return BooleanConstant.fromValue((left.floatValue() <= right.doubleValue()));
/*  824 */           case 3: return BooleanConstant.fromValue((left.floatValue() <= right.byteValue()));
/*  825 */           case 4: return BooleanConstant.fromValue((left.floatValue() <= right.shortValue()));
/*  826 */           case 10: return BooleanConstant.fromValue((left.floatValue() <= right.intValue()));
/*  827 */           case 7: return BooleanConstant.fromValue((left.floatValue() <= (float)right.longValue())); }
/*      */         
/*      */         break;
/*      */       case 8:
/*  831 */         switch (rightId) { case 2:
/*  832 */             return BooleanConstant.fromValue((left.doubleValue() <= right.charValue()));
/*  833 */           case 9: return BooleanConstant.fromValue((left.doubleValue() <= right.floatValue()));
/*  834 */           case 8: return BooleanConstant.fromValue((left.doubleValue() <= right.doubleValue()));
/*  835 */           case 3: return BooleanConstant.fromValue((left.doubleValue() <= right.byteValue()));
/*  836 */           case 4: return BooleanConstant.fromValue((left.doubleValue() <= right.shortValue()));
/*  837 */           case 10: return BooleanConstant.fromValue((left.doubleValue() <= right.intValue()));
/*  838 */           case 7: return BooleanConstant.fromValue((left.doubleValue() <= right.longValue())); }
/*      */         
/*      */         break;
/*      */       case 3:
/*  842 */         switch (rightId) { case 2:
/*  843 */             return BooleanConstant.fromValue((left.byteValue() <= right.charValue()));
/*  844 */           case 9: return BooleanConstant.fromValue((left.byteValue() <= right.floatValue()));
/*  845 */           case 8: return BooleanConstant.fromValue((left.byteValue() <= right.doubleValue()));
/*  846 */           case 3: return BooleanConstant.fromValue((left.byteValue() <= right.byteValue()));
/*  847 */           case 4: return BooleanConstant.fromValue((left.byteValue() <= right.shortValue()));
/*  848 */           case 10: return BooleanConstant.fromValue((left.byteValue() <= right.intValue()));
/*  849 */           case 7: return BooleanConstant.fromValue((left.byteValue() <= right.longValue())); }
/*      */         
/*      */         break;
/*      */       case 4:
/*  853 */         switch (rightId) { case 2:
/*  854 */             return BooleanConstant.fromValue((left.shortValue() <= right.charValue()));
/*  855 */           case 9: return BooleanConstant.fromValue((left.shortValue() <= right.floatValue()));
/*  856 */           case 8: return BooleanConstant.fromValue((left.shortValue() <= right.doubleValue()));
/*  857 */           case 3: return BooleanConstant.fromValue((left.shortValue() <= right.byteValue()));
/*  858 */           case 4: return BooleanConstant.fromValue((left.shortValue() <= right.shortValue()));
/*  859 */           case 10: return BooleanConstant.fromValue((left.shortValue() <= right.intValue()));
/*  860 */           case 7: return BooleanConstant.fromValue((left.shortValue() <= right.longValue())); }
/*      */         
/*      */         break;
/*      */       case 10:
/*  864 */         switch (rightId) { case 2:
/*  865 */             return BooleanConstant.fromValue((left.intValue() <= right.charValue()));
/*  866 */           case 9: return BooleanConstant.fromValue((left.intValue() <= right.floatValue()));
/*  867 */           case 8: return BooleanConstant.fromValue((left.intValue() <= right.doubleValue()));
/*  868 */           case 3: return BooleanConstant.fromValue((left.intValue() <= right.byteValue()));
/*  869 */           case 4: return BooleanConstant.fromValue((left.intValue() <= right.shortValue()));
/*  870 */           case 10: return BooleanConstant.fromValue((left.intValue() <= right.intValue()));
/*  871 */           case 7: return BooleanConstant.fromValue((left.intValue() <= right.longValue())); }
/*      */         
/*      */         break;
/*      */       case 7:
/*  875 */         switch (rightId) { case 2:
/*  876 */             return BooleanConstant.fromValue((left.longValue() <= right.charValue()));
/*  877 */           case 9: return BooleanConstant.fromValue(((float)left.longValue() <= right.floatValue()));
/*  878 */           case 8: return BooleanConstant.fromValue((left.longValue() <= right.doubleValue()));
/*  879 */           case 3: return BooleanConstant.fromValue((left.longValue() <= right.byteValue()));
/*  880 */           case 4: return BooleanConstant.fromValue((left.longValue() <= right.shortValue()));
/*  881 */           case 10: return BooleanConstant.fromValue((left.longValue() <= right.intValue()));
/*  882 */           case 7: return BooleanConstant.fromValue((left.longValue() <= right.longValue())); }
/*      */          break;
/*      */     } 
/*  885 */     return NotAConstant;
/*      */   }
/*      */   
/*      */   public static final Constant computeConstantOperationMINUS(Constant left, int leftId, Constant right, int rightId) {
/*  889 */     switch (leftId) {
/*      */       case 2:
/*  891 */         switch (rightId) { case 2:
/*  892 */             return IntConstant.fromValue(left.charValue() - right.charValue());
/*  893 */           case 9: return FloatConstant.fromValue(left.charValue() - right.floatValue());
/*  894 */           case 8: return DoubleConstant.fromValue(left.charValue() - right.doubleValue());
/*  895 */           case 3: return IntConstant.fromValue(left.charValue() - right.byteValue());
/*  896 */           case 4: return IntConstant.fromValue(left.charValue() - right.shortValue());
/*  897 */           case 10: return IntConstant.fromValue(left.charValue() - right.intValue());
/*  898 */           case 7: return LongConstant.fromValue(left.charValue() - right.longValue()); }
/*      */         
/*      */         break;
/*      */       case 9:
/*  902 */         switch (rightId) { case 2:
/*  903 */             return FloatConstant.fromValue(left.floatValue() - right.charValue());
/*  904 */           case 9: return FloatConstant.fromValue(left.floatValue() - right.floatValue());
/*  905 */           case 8: return DoubleConstant.fromValue(left.floatValue() - right.doubleValue());
/*  906 */           case 3: return FloatConstant.fromValue(left.floatValue() - right.byteValue());
/*  907 */           case 4: return FloatConstant.fromValue(left.floatValue() - right.shortValue());
/*  908 */           case 10: return FloatConstant.fromValue(left.floatValue() - right.intValue());
/*  909 */           case 7: return FloatConstant.fromValue(left.floatValue() - (float)right.longValue()); }
/*      */         
/*      */         break;
/*      */       case 8:
/*  913 */         switch (rightId) { case 2:
/*  914 */             return DoubleConstant.fromValue(left.doubleValue() - right.charValue());
/*  915 */           case 9: return DoubleConstant.fromValue(left.doubleValue() - right.floatValue());
/*  916 */           case 8: return DoubleConstant.fromValue(left.doubleValue() - right.doubleValue());
/*  917 */           case 3: return DoubleConstant.fromValue(left.doubleValue() - right.byteValue());
/*  918 */           case 4: return DoubleConstant.fromValue(left.doubleValue() - right.shortValue());
/*  919 */           case 10: return DoubleConstant.fromValue(left.doubleValue() - right.intValue());
/*  920 */           case 7: return DoubleConstant.fromValue(left.doubleValue() - right.longValue()); }
/*      */         
/*      */         break;
/*      */       case 3:
/*  924 */         switch (rightId) { case 2:
/*  925 */             return IntConstant.fromValue(left.byteValue() - right.charValue());
/*  926 */           case 9: return FloatConstant.fromValue(left.byteValue() - right.floatValue());
/*  927 */           case 8: return DoubleConstant.fromValue(left.byteValue() - right.doubleValue());
/*  928 */           case 3: return IntConstant.fromValue(left.byteValue() - right.byteValue());
/*  929 */           case 4: return IntConstant.fromValue(left.byteValue() - right.shortValue());
/*  930 */           case 10: return IntConstant.fromValue(left.byteValue() - right.intValue());
/*  931 */           case 7: return LongConstant.fromValue(left.byteValue() - right.longValue()); }
/*      */         
/*      */         break;
/*      */       case 4:
/*  935 */         switch (rightId) { case 2:
/*  936 */             return IntConstant.fromValue(left.shortValue() - right.charValue());
/*  937 */           case 9: return FloatConstant.fromValue(left.shortValue() - right.floatValue());
/*  938 */           case 8: return DoubleConstant.fromValue(left.shortValue() - right.doubleValue());
/*  939 */           case 3: return IntConstant.fromValue(left.shortValue() - right.byteValue());
/*  940 */           case 4: return IntConstant.fromValue(left.shortValue() - right.shortValue());
/*  941 */           case 10: return IntConstant.fromValue(left.shortValue() - right.intValue());
/*  942 */           case 7: return LongConstant.fromValue(left.shortValue() - right.longValue()); }
/*      */         
/*      */         break;
/*      */       case 10:
/*  946 */         switch (rightId) { case 2:
/*  947 */             return IntConstant.fromValue(left.intValue() - right.charValue());
/*  948 */           case 9: return FloatConstant.fromValue(left.intValue() - right.floatValue());
/*  949 */           case 8: return DoubleConstant.fromValue(left.intValue() - right.doubleValue());
/*  950 */           case 3: return IntConstant.fromValue(left.intValue() - right.byteValue());
/*  951 */           case 4: return IntConstant.fromValue(left.intValue() - right.shortValue());
/*  952 */           case 10: return IntConstant.fromValue(left.intValue() - right.intValue());
/*  953 */           case 7: return LongConstant.fromValue(left.intValue() - right.longValue()); }
/*      */         
/*      */         break;
/*      */       case 7:
/*  957 */         switch (rightId) { case 2:
/*  958 */             return LongConstant.fromValue(left.longValue() - right.charValue());
/*  959 */           case 9: return FloatConstant.fromValue((float)left.longValue() - right.floatValue());
/*  960 */           case 8: return DoubleConstant.fromValue(left.longValue() - right.doubleValue());
/*  961 */           case 3: return LongConstant.fromValue(left.longValue() - right.byteValue());
/*  962 */           case 4: return LongConstant.fromValue(left.longValue() - right.shortValue());
/*  963 */           case 10: return LongConstant.fromValue(left.longValue() - right.intValue());
/*  964 */           case 7: return LongConstant.fromValue(left.longValue() - right.longValue()); }
/*      */          break;
/*      */     } 
/*  967 */     return NotAConstant;
/*      */   }
/*      */   
/*      */   public static final Constant computeConstantOperationMULTIPLY(Constant left, int leftId, Constant right, int rightId) {
/*  971 */     switch (leftId) {
/*      */       case 2:
/*  973 */         switch (rightId) { case 2:
/*  974 */             return IntConstant.fromValue(left.charValue() * right.charValue());
/*  975 */           case 9: return FloatConstant.fromValue(left.charValue() * right.floatValue());
/*  976 */           case 8: return DoubleConstant.fromValue(left.charValue() * right.doubleValue());
/*  977 */           case 3: return IntConstant.fromValue(left.charValue() * right.byteValue());
/*  978 */           case 4: return IntConstant.fromValue(left.charValue() * right.shortValue());
/*  979 */           case 10: return IntConstant.fromValue(left.charValue() * right.intValue());
/*  980 */           case 7: return LongConstant.fromValue(left.charValue() * right.longValue()); }
/*      */         
/*      */         break;
/*      */       case 9:
/*  984 */         switch (rightId) { case 2:
/*  985 */             return FloatConstant.fromValue(left.floatValue() * right.charValue());
/*  986 */           case 9: return FloatConstant.fromValue(left.floatValue() * right.floatValue());
/*  987 */           case 8: return DoubleConstant.fromValue(left.floatValue() * right.doubleValue());
/*  988 */           case 3: return FloatConstant.fromValue(left.floatValue() * right.byteValue());
/*  989 */           case 4: return FloatConstant.fromValue(left.floatValue() * right.shortValue());
/*  990 */           case 10: return FloatConstant.fromValue(left.floatValue() * right.intValue());
/*  991 */           case 7: return FloatConstant.fromValue(left.floatValue() * (float)right.longValue()); }
/*      */         
/*      */         break;
/*      */       case 8:
/*  995 */         switch (rightId) { case 2:
/*  996 */             return DoubleConstant.fromValue(left.doubleValue() * right.charValue());
/*  997 */           case 9: return DoubleConstant.fromValue(left.doubleValue() * right.floatValue());
/*  998 */           case 8: return DoubleConstant.fromValue(left.doubleValue() * right.doubleValue());
/*  999 */           case 3: return DoubleConstant.fromValue(left.doubleValue() * right.byteValue());
/* 1000 */           case 4: return DoubleConstant.fromValue(left.doubleValue() * right.shortValue());
/* 1001 */           case 10: return DoubleConstant.fromValue(left.doubleValue() * right.intValue());
/* 1002 */           case 7: return DoubleConstant.fromValue(left.doubleValue() * right.longValue()); }
/*      */         
/*      */         break;
/*      */       case 3:
/* 1006 */         switch (rightId) { case 2:
/* 1007 */             return IntConstant.fromValue(left.byteValue() * right.charValue());
/* 1008 */           case 9: return FloatConstant.fromValue(left.byteValue() * right.floatValue());
/* 1009 */           case 8: return DoubleConstant.fromValue(left.byteValue() * right.doubleValue());
/* 1010 */           case 3: return IntConstant.fromValue(left.byteValue() * right.byteValue());
/* 1011 */           case 4: return IntConstant.fromValue(left.byteValue() * right.shortValue());
/* 1012 */           case 10: return IntConstant.fromValue(left.byteValue() * right.intValue());
/* 1013 */           case 7: return LongConstant.fromValue(left.byteValue() * right.longValue()); }
/*      */         
/*      */         break;
/*      */       case 4:
/* 1017 */         switch (rightId) { case 2:
/* 1018 */             return IntConstant.fromValue(left.shortValue() * right.charValue());
/* 1019 */           case 9: return FloatConstant.fromValue(left.shortValue() * right.floatValue());
/* 1020 */           case 8: return DoubleConstant.fromValue(left.shortValue() * right.doubleValue());
/* 1021 */           case 3: return IntConstant.fromValue(left.shortValue() * right.byteValue());
/* 1022 */           case 4: return IntConstant.fromValue(left.shortValue() * right.shortValue());
/* 1023 */           case 10: return IntConstant.fromValue(left.shortValue() * right.intValue());
/* 1024 */           case 7: return LongConstant.fromValue(left.shortValue() * right.longValue()); }
/*      */         
/*      */         break;
/*      */       case 10:
/* 1028 */         switch (rightId) { case 2:
/* 1029 */             return IntConstant.fromValue(left.intValue() * right.charValue());
/* 1030 */           case 9: return FloatConstant.fromValue(left.intValue() * right.floatValue());
/* 1031 */           case 8: return DoubleConstant.fromValue(left.intValue() * right.doubleValue());
/* 1032 */           case 3: return IntConstant.fromValue(left.intValue() * right.byteValue());
/* 1033 */           case 4: return IntConstant.fromValue(left.intValue() * right.shortValue());
/* 1034 */           case 10: return IntConstant.fromValue(left.intValue() * right.intValue());
/* 1035 */           case 7: return LongConstant.fromValue(left.intValue() * right.longValue()); }
/*      */         
/*      */         break;
/*      */       case 7:
/* 1039 */         switch (rightId) { case 2:
/* 1040 */             return LongConstant.fromValue(left.longValue() * right.charValue());
/* 1041 */           case 9: return FloatConstant.fromValue((float)left.longValue() * right.floatValue());
/* 1042 */           case 8: return DoubleConstant.fromValue(left.longValue() * right.doubleValue());
/* 1043 */           case 3: return LongConstant.fromValue(left.longValue() * right.byteValue());
/* 1044 */           case 4: return LongConstant.fromValue(left.longValue() * right.shortValue());
/* 1045 */           case 10: return LongConstant.fromValue(left.longValue() * right.intValue());
/* 1046 */           case 7: return LongConstant.fromValue(left.longValue() * right.longValue()); }
/*      */          break;
/*      */     } 
/* 1049 */     return NotAConstant;
/*      */   }
/*      */   
/*      */   public static final Constant computeConstantOperationOR(Constant left, int leftId, Constant right, int rightId) {
/* 1053 */     switch (leftId) { case 5:
/* 1054 */         return BooleanConstant.fromValue(left.booleanValue() | right.booleanValue());
/*      */       case 2:
/* 1056 */         switch (rightId) { case 2:
/* 1057 */             return IntConstant.fromValue(left.charValue() | right.charValue());
/* 1058 */           case 3: return IntConstant.fromValue(left.charValue() | right.byteValue());
/* 1059 */           case 4: return IntConstant.fromValue(left.charValue() | right.shortValue());
/* 1060 */           case 10: return IntConstant.fromValue(left.charValue() | right.intValue());
/* 1061 */           case 7: return LongConstant.fromValue(left.charValue() | right.longValue()); }
/*      */         
/*      */         break;
/*      */       case 3:
/* 1065 */         switch (rightId) { case 2:
/* 1066 */             return IntConstant.fromValue(left.byteValue() | right.charValue());
/* 1067 */           case 3: return IntConstant.fromValue(left.byteValue() | right.byteValue());
/* 1068 */           case 4: return IntConstant.fromValue(left.byteValue() | right.shortValue());
/* 1069 */           case 10: return IntConstant.fromValue(left.byteValue() | right.intValue());
/* 1070 */           case 7: return LongConstant.fromValue(left.byteValue() | right.longValue()); }
/*      */         
/*      */         break;
/*      */       case 4:
/* 1074 */         switch (rightId) { case 2:
/* 1075 */             return IntConstant.fromValue(left.shortValue() | right.charValue());
/* 1076 */           case 3: return IntConstant.fromValue(left.shortValue() | right.byteValue());
/* 1077 */           case 4: return IntConstant.fromValue(left.shortValue() | right.shortValue());
/* 1078 */           case 10: return IntConstant.fromValue(left.shortValue() | right.intValue());
/* 1079 */           case 7: return LongConstant.fromValue(left.shortValue() | right.longValue()); }
/*      */         
/*      */         break;
/*      */       case 10:
/* 1083 */         switch (rightId) { case 2:
/* 1084 */             return IntConstant.fromValue(left.intValue() | right.charValue());
/* 1085 */           case 3: return IntConstant.fromValue(left.intValue() | right.byteValue());
/* 1086 */           case 4: return IntConstant.fromValue(left.intValue() | right.shortValue());
/* 1087 */           case 10: return IntConstant.fromValue(left.intValue() | right.intValue());
/* 1088 */           case 7: return LongConstant.fromValue(left.intValue() | right.longValue()); }
/*      */         
/*      */         break;
/*      */       case 7:
/* 1092 */         switch (rightId) { case 2:
/* 1093 */             return LongConstant.fromValue(left.longValue() | right.charValue());
/* 1094 */           case 3: return LongConstant.fromValue(left.longValue() | right.byteValue());
/* 1095 */           case 4: return LongConstant.fromValue(left.longValue() | right.shortValue());
/* 1096 */           case 10: return LongConstant.fromValue(left.longValue() | right.intValue());
/* 1097 */           case 7: return LongConstant.fromValue(left.longValue() | right.longValue()); }
/*      */          break; }
/*      */     
/* 1100 */     return NotAConstant;
/*      */   }
/*      */   
/*      */   public static final Constant computeConstantOperationOR_OR(Constant left, int leftId, Constant right, int rightId) {
/* 1104 */     return BooleanConstant.fromValue(!(!left.booleanValue() && !right.booleanValue()));
/*      */   }
/*      */   
/*      */   public static final Constant computeConstantOperationPLUS(Constant left, int leftId, Constant right, int rightId) {
/* 1108 */     switch (leftId) {
/*      */       case 1:
/* 1110 */         if (rightId == 11) {
/* 1111 */           return StringConstant.fromValue(String.valueOf(left.stringValue()) + right.stringValue());
/*      */         }
/*      */         break;
/*      */       case 5:
/* 1115 */         if (rightId == 11) {
/* 1116 */           return StringConstant.fromValue(String.valueOf(left.stringValue()) + right.stringValue());
/*      */         }
/*      */         break;
/*      */       case 2:
/* 1120 */         switch (rightId) { case 2:
/* 1121 */             return IntConstant.fromValue(left.charValue() + right.charValue());
/* 1122 */           case 9: return FloatConstant.fromValue(left.charValue() + right.floatValue());
/* 1123 */           case 8: return DoubleConstant.fromValue(left.charValue() + right.doubleValue());
/* 1124 */           case 3: return IntConstant.fromValue(left.charValue() + right.byteValue());
/* 1125 */           case 4: return IntConstant.fromValue(left.charValue() + right.shortValue());
/* 1126 */           case 10: return IntConstant.fromValue(left.charValue() + right.intValue());
/* 1127 */           case 7: return LongConstant.fromValue(left.charValue() + right.longValue());
/* 1128 */           case 11: return StringConstant.fromValue(String.valueOf(left.stringValue()) + right.stringValue()); }
/*      */         
/*      */         break;
/*      */       case 9:
/* 1132 */         switch (rightId) { case 2:
/* 1133 */             return FloatConstant.fromValue(left.floatValue() + right.charValue());
/* 1134 */           case 9: return FloatConstant.fromValue(left.floatValue() + right.floatValue());
/* 1135 */           case 8: return DoubleConstant.fromValue(left.floatValue() + right.doubleValue());
/* 1136 */           case 3: return FloatConstant.fromValue(left.floatValue() + right.byteValue());
/* 1137 */           case 4: return FloatConstant.fromValue(left.floatValue() + right.shortValue());
/* 1138 */           case 10: return FloatConstant.fromValue(left.floatValue() + right.intValue());
/* 1139 */           case 7: return FloatConstant.fromValue(left.floatValue() + (float)right.longValue());
/* 1140 */           case 11: return StringConstant.fromValue(String.valueOf(left.stringValue()) + right.stringValue()); }
/*      */         
/*      */         break;
/*      */       case 8:
/* 1144 */         switch (rightId) { case 2:
/* 1145 */             return DoubleConstant.fromValue(left.doubleValue() + right.charValue());
/* 1146 */           case 9: return DoubleConstant.fromValue(left.doubleValue() + right.floatValue());
/* 1147 */           case 8: return DoubleConstant.fromValue(left.doubleValue() + right.doubleValue());
/* 1148 */           case 3: return DoubleConstant.fromValue(left.doubleValue() + right.byteValue());
/* 1149 */           case 4: return DoubleConstant.fromValue(left.doubleValue() + right.shortValue());
/* 1150 */           case 10: return DoubleConstant.fromValue(left.doubleValue() + right.intValue());
/* 1151 */           case 7: return DoubleConstant.fromValue(left.doubleValue() + right.longValue());
/* 1152 */           case 11: return StringConstant.fromValue(String.valueOf(left.stringValue()) + right.stringValue()); }
/*      */         
/*      */         break;
/*      */       case 3:
/* 1156 */         switch (rightId) { case 2:
/* 1157 */             return IntConstant.fromValue(left.byteValue() + right.charValue());
/* 1158 */           case 9: return FloatConstant.fromValue(left.byteValue() + right.floatValue());
/* 1159 */           case 8: return DoubleConstant.fromValue(left.byteValue() + right.doubleValue());
/* 1160 */           case 3: return IntConstant.fromValue(left.byteValue() + right.byteValue());
/* 1161 */           case 4: return IntConstant.fromValue(left.byteValue() + right.shortValue());
/* 1162 */           case 10: return IntConstant.fromValue(left.byteValue() + right.intValue());
/* 1163 */           case 7: return LongConstant.fromValue(left.byteValue() + right.longValue());
/* 1164 */           case 11: return StringConstant.fromValue(String.valueOf(left.stringValue()) + right.stringValue()); }
/*      */         
/*      */         break;
/*      */       case 4:
/* 1168 */         switch (rightId) { case 2:
/* 1169 */             return IntConstant.fromValue(left.shortValue() + right.charValue());
/* 1170 */           case 9: return FloatConstant.fromValue(left.shortValue() + right.floatValue());
/* 1171 */           case 8: return DoubleConstant.fromValue(left.shortValue() + right.doubleValue());
/* 1172 */           case 3: return IntConstant.fromValue(left.shortValue() + right.byteValue());
/* 1173 */           case 4: return IntConstant.fromValue(left.shortValue() + right.shortValue());
/* 1174 */           case 10: return IntConstant.fromValue(left.shortValue() + right.intValue());
/* 1175 */           case 7: return LongConstant.fromValue(left.shortValue() + right.longValue());
/* 1176 */           case 11: return StringConstant.fromValue(String.valueOf(left.stringValue()) + right.stringValue()); }
/*      */         
/*      */         break;
/*      */       case 10:
/* 1180 */         switch (rightId) { case 2:
/* 1181 */             return IntConstant.fromValue(left.intValue() + right.charValue());
/* 1182 */           case 9: return FloatConstant.fromValue(left.intValue() + right.floatValue());
/* 1183 */           case 8: return DoubleConstant.fromValue(left.intValue() + right.doubleValue());
/* 1184 */           case 3: return IntConstant.fromValue(left.intValue() + right.byteValue());
/* 1185 */           case 4: return IntConstant.fromValue(left.intValue() + right.shortValue());
/* 1186 */           case 10: return IntConstant.fromValue(left.intValue() + right.intValue());
/* 1187 */           case 7: return LongConstant.fromValue(left.intValue() + right.longValue());
/* 1188 */           case 11: return StringConstant.fromValue(String.valueOf(left.stringValue()) + right.stringValue()); }
/*      */         
/*      */         break;
/*      */       case 7:
/* 1192 */         switch (rightId) { case 2:
/* 1193 */             return LongConstant.fromValue(left.longValue() + right.charValue());
/* 1194 */           case 9: return FloatConstant.fromValue((float)left.longValue() + right.floatValue());
/* 1195 */           case 8: return DoubleConstant.fromValue(left.longValue() + right.doubleValue());
/* 1196 */           case 3: return LongConstant.fromValue(left.longValue() + right.byteValue());
/* 1197 */           case 4: return LongConstant.fromValue(left.longValue() + right.shortValue());
/* 1198 */           case 10: return LongConstant.fromValue(left.longValue() + right.intValue());
/* 1199 */           case 7: return LongConstant.fromValue(left.longValue() + right.longValue());
/* 1200 */           case 11: return StringConstant.fromValue(String.valueOf(left.stringValue()) + right.stringValue()); }
/*      */         
/*      */         break;
/*      */       case 11:
/* 1204 */         switch (rightId) { case 2:
/* 1205 */             return StringConstant.fromValue(String.valueOf(left.stringValue()) + String.valueOf(right.charValue()));
/* 1206 */           case 9: return StringConstant.fromValue(String.valueOf(left.stringValue()) + String.valueOf(right.floatValue()));
/* 1207 */           case 8: return StringConstant.fromValue(String.valueOf(left.stringValue()) + String.valueOf(right.doubleValue()));
/* 1208 */           case 3: return StringConstant.fromValue(String.valueOf(left.stringValue()) + String.valueOf(right.byteValue()));
/* 1209 */           case 4: return StringConstant.fromValue(String.valueOf(left.stringValue()) + String.valueOf(right.shortValue()));
/* 1210 */           case 10: return StringConstant.fromValue(String.valueOf(left.stringValue()) + String.valueOf(right.intValue()));
/* 1211 */           case 7: return StringConstant.fromValue(String.valueOf(left.stringValue()) + String.valueOf(right.longValue()));
/* 1212 */           case 11: return StringConstant.fromValue(String.valueOf(left.stringValue()) + right.stringValue());
/* 1213 */           case 5: return StringConstant.fromValue(String.valueOf(left.stringValue()) + right.booleanValue()); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         break;
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1229 */     return NotAConstant;
/*      */   }
/*      */   
/*      */   public static final Constant computeConstantOperationREMAINDER(Constant left, int leftId, Constant right, int rightId) {
/* 1233 */     switch (leftId) {
/*      */       case 2:
/* 1235 */         switch (rightId) { case 2:
/* 1236 */             return IntConstant.fromValue(left.charValue() % right.charValue());
/* 1237 */           case 9: return FloatConstant.fromValue(left.charValue() % right.floatValue());
/* 1238 */           case 8: return DoubleConstant.fromValue(left.charValue() % right.doubleValue());
/* 1239 */           case 3: return IntConstant.fromValue(left.charValue() % right.byteValue());
/* 1240 */           case 4: return IntConstant.fromValue(left.charValue() % right.shortValue());
/* 1241 */           case 10: return IntConstant.fromValue(left.charValue() % right.intValue());
/* 1242 */           case 7: return LongConstant.fromValue(left.charValue() % right.longValue()); }
/*      */         
/*      */         break;
/*      */       case 9:
/* 1246 */         switch (rightId) { case 2:
/* 1247 */             return FloatConstant.fromValue(left.floatValue() % right.charValue());
/* 1248 */           case 9: return FloatConstant.fromValue(left.floatValue() % right.floatValue());
/* 1249 */           case 8: return DoubleConstant.fromValue(left.floatValue() % right.doubleValue());
/* 1250 */           case 3: return FloatConstant.fromValue(left.floatValue() % right.byteValue());
/* 1251 */           case 4: return FloatConstant.fromValue(left.floatValue() % right.shortValue());
/* 1252 */           case 10: return FloatConstant.fromValue(left.floatValue() % right.intValue());
/* 1253 */           case 7: return FloatConstant.fromValue(left.floatValue() % (float)right.longValue()); }
/*      */         
/*      */         break;
/*      */       case 8:
/* 1257 */         switch (rightId) { case 2:
/* 1258 */             return DoubleConstant.fromValue(left.doubleValue() % right.charValue());
/* 1259 */           case 9: return DoubleConstant.fromValue(left.doubleValue() % right.floatValue());
/* 1260 */           case 8: return DoubleConstant.fromValue(left.doubleValue() % right.doubleValue());
/* 1261 */           case 3: return DoubleConstant.fromValue(left.doubleValue() % right.byteValue());
/* 1262 */           case 4: return DoubleConstant.fromValue(left.doubleValue() % right.shortValue());
/* 1263 */           case 10: return DoubleConstant.fromValue(left.doubleValue() % right.intValue());
/* 1264 */           case 7: return DoubleConstant.fromValue(left.doubleValue() % right.longValue()); }
/*      */         
/*      */         break;
/*      */       case 3:
/* 1268 */         switch (rightId) { case 2:
/* 1269 */             return IntConstant.fromValue(left.byteValue() % right.charValue());
/* 1270 */           case 9: return FloatConstant.fromValue(left.byteValue() % right.floatValue());
/* 1271 */           case 8: return DoubleConstant.fromValue(left.byteValue() % right.doubleValue());
/* 1272 */           case 3: return IntConstant.fromValue(left.byteValue() % right.byteValue());
/* 1273 */           case 4: return IntConstant.fromValue(left.byteValue() % right.shortValue());
/* 1274 */           case 10: return IntConstant.fromValue(left.byteValue() % right.intValue());
/* 1275 */           case 7: return LongConstant.fromValue(left.byteValue() % right.longValue()); }
/*      */         
/*      */         break;
/*      */       case 4:
/* 1279 */         switch (rightId) { case 2:
/* 1280 */             return IntConstant.fromValue(left.shortValue() % right.charValue());
/* 1281 */           case 9: return FloatConstant.fromValue(left.shortValue() % right.floatValue());
/* 1282 */           case 8: return DoubleConstant.fromValue(left.shortValue() % right.doubleValue());
/* 1283 */           case 3: return IntConstant.fromValue(left.shortValue() % right.byteValue());
/* 1284 */           case 4: return IntConstant.fromValue(left.shortValue() % right.shortValue());
/* 1285 */           case 10: return IntConstant.fromValue(left.shortValue() % right.intValue());
/* 1286 */           case 7: return LongConstant.fromValue(left.shortValue() % right.longValue()); }
/*      */         
/*      */         break;
/*      */       case 10:
/* 1290 */         switch (rightId) { case 2:
/* 1291 */             return IntConstant.fromValue(left.intValue() % right.charValue());
/* 1292 */           case 9: return FloatConstant.fromValue(left.intValue() % right.floatValue());
/* 1293 */           case 8: return DoubleConstant.fromValue(left.intValue() % right.doubleValue());
/* 1294 */           case 3: return IntConstant.fromValue(left.intValue() % right.byteValue());
/* 1295 */           case 4: return IntConstant.fromValue(left.intValue() % right.shortValue());
/* 1296 */           case 10: return IntConstant.fromValue(left.intValue() % right.intValue());
/* 1297 */           case 7: return LongConstant.fromValue(left.intValue() % right.longValue()); }
/*      */         
/*      */         break;
/*      */       case 7:
/* 1301 */         switch (rightId) { case 2:
/* 1302 */             return LongConstant.fromValue(left.longValue() % right.charValue());
/* 1303 */           case 9: return FloatConstant.fromValue((float)left.longValue() % right.floatValue());
/* 1304 */           case 8: return DoubleConstant.fromValue(left.longValue() % right.doubleValue());
/* 1305 */           case 3: return LongConstant.fromValue(left.longValue() % right.byteValue());
/* 1306 */           case 4: return LongConstant.fromValue(left.longValue() % right.shortValue());
/* 1307 */           case 10: return LongConstant.fromValue(left.longValue() % right.intValue());
/* 1308 */           case 7: return LongConstant.fromValue(left.longValue() % right.longValue()); }
/*      */          break;
/*      */     } 
/* 1311 */     return NotAConstant;
/*      */   }
/*      */   
/*      */   public static final Constant computeConstantOperationRIGHT_SHIFT(Constant left, int leftId, Constant right, int rightId) {
/* 1315 */     switch (leftId) {
/*      */       case 2:
/* 1317 */         switch (rightId) { case 2:
/* 1318 */             return IntConstant.fromValue(left.charValue() >> right.charValue());
/* 1319 */           case 3: return IntConstant.fromValue(left.charValue() >> right.byteValue());
/* 1320 */           case 4: return IntConstant.fromValue(left.charValue() >> right.shortValue());
/* 1321 */           case 10: return IntConstant.fromValue(left.charValue() >> right.intValue());
/* 1322 */           case 7: return IntConstant.fromValue(left.charValue() >> (int)right.longValue()); }
/*      */         
/*      */         break;
/*      */       case 3:
/* 1326 */         switch (rightId) { case 2:
/* 1327 */             return IntConstant.fromValue(left.byteValue() >> right.charValue());
/* 1328 */           case 3: return IntConstant.fromValue(left.byteValue() >> right.byteValue());
/* 1329 */           case 4: return IntConstant.fromValue(left.byteValue() >> right.shortValue());
/* 1330 */           case 10: return IntConstant.fromValue(left.byteValue() >> right.intValue());
/* 1331 */           case 7: return IntConstant.fromValue(left.byteValue() >> (int)right.longValue()); }
/*      */         
/*      */         break;
/*      */       case 4:
/* 1335 */         switch (rightId) { case 2:
/* 1336 */             return IntConstant.fromValue(left.shortValue() >> right.charValue());
/* 1337 */           case 3: return IntConstant.fromValue(left.shortValue() >> right.byteValue());
/* 1338 */           case 4: return IntConstant.fromValue(left.shortValue() >> right.shortValue());
/* 1339 */           case 10: return IntConstant.fromValue(left.shortValue() >> right.intValue());
/* 1340 */           case 7: return IntConstant.fromValue(left.shortValue() >> (int)right.longValue()); }
/*      */         
/*      */         break;
/*      */       case 10:
/* 1344 */         switch (rightId) { case 2:
/* 1345 */             return IntConstant.fromValue(left.intValue() >> right.charValue());
/* 1346 */           case 3: return IntConstant.fromValue(left.intValue() >> right.byteValue());
/* 1347 */           case 4: return IntConstant.fromValue(left.intValue() >> right.shortValue());
/* 1348 */           case 10: return IntConstant.fromValue(left.intValue() >> right.intValue());
/* 1349 */           case 7: return IntConstant.fromValue(left.intValue() >> (int)right.longValue()); }
/*      */         
/*      */         break;
/*      */       case 7:
/* 1353 */         switch (rightId) { case 2:
/* 1354 */             return LongConstant.fromValue(left.longValue() >> right.charValue());
/* 1355 */           case 3: return LongConstant.fromValue(left.longValue() >> right.byteValue());
/* 1356 */           case 4: return LongConstant.fromValue(left.longValue() >> right.shortValue());
/* 1357 */           case 10: return LongConstant.fromValue(left.longValue() >> right.intValue());
/* 1358 */           case 7: return LongConstant.fromValue(left.longValue() >> (int)right.longValue()); }
/*      */          break;
/*      */     } 
/* 1361 */     return NotAConstant;
/*      */   }
/*      */   
/*      */   public static final Constant computeConstantOperationUNSIGNED_RIGHT_SHIFT(Constant left, int leftId, Constant right, int rightId) {
/* 1365 */     switch (leftId) {
/*      */       case 2:
/* 1367 */         switch (rightId) { case 2:
/* 1368 */             return IntConstant.fromValue(left.charValue() >>> right.charValue());
/* 1369 */           case 3: return IntConstant.fromValue(left.charValue() >>> right.byteValue());
/* 1370 */           case 4: return IntConstant.fromValue(left.charValue() >>> right.shortValue());
/* 1371 */           case 10: return IntConstant.fromValue(left.charValue() >>> right.intValue());
/* 1372 */           case 7: return IntConstant.fromValue(left.charValue() >>> (int)right.longValue()); }
/*      */         
/*      */         break;
/*      */       case 3:
/* 1376 */         switch (rightId) { case 2:
/* 1377 */             return IntConstant.fromValue(left.byteValue() >>> right.charValue());
/* 1378 */           case 3: return IntConstant.fromValue(left.byteValue() >>> right.byteValue());
/* 1379 */           case 4: return IntConstant.fromValue(left.byteValue() >>> right.shortValue());
/* 1380 */           case 10: return IntConstant.fromValue(left.byteValue() >>> right.intValue());
/* 1381 */           case 7: return IntConstant.fromValue(left.byteValue() >>> (int)right.longValue()); }
/*      */         
/*      */         break;
/*      */       case 4:
/* 1385 */         switch (rightId) { case 2:
/* 1386 */             return IntConstant.fromValue(left.shortValue() >>> right.charValue());
/* 1387 */           case 3: return IntConstant.fromValue(left.shortValue() >>> right.byteValue());
/* 1388 */           case 4: return IntConstant.fromValue(left.shortValue() >>> right.shortValue());
/* 1389 */           case 10: return IntConstant.fromValue(left.shortValue() >>> right.intValue());
/* 1390 */           case 7: return IntConstant.fromValue(left.shortValue() >>> (int)right.longValue()); }
/*      */         
/*      */         break;
/*      */       case 10:
/* 1394 */         switch (rightId) { case 2:
/* 1395 */             return IntConstant.fromValue(left.intValue() >>> right.charValue());
/* 1396 */           case 3: return IntConstant.fromValue(left.intValue() >>> right.byteValue());
/* 1397 */           case 4: return IntConstant.fromValue(left.intValue() >>> right.shortValue());
/* 1398 */           case 10: return IntConstant.fromValue(left.intValue() >>> right.intValue());
/* 1399 */           case 7: return IntConstant.fromValue(left.intValue() >>> (int)right.longValue()); }
/*      */         
/*      */         break;
/*      */       case 7:
/* 1403 */         switch (rightId) { case 2:
/* 1404 */             return LongConstant.fromValue(left.longValue() >>> right.charValue());
/* 1405 */           case 3: return LongConstant.fromValue(left.longValue() >>> right.byteValue());
/* 1406 */           case 4: return LongConstant.fromValue(left.longValue() >>> right.shortValue());
/* 1407 */           case 10: return LongConstant.fromValue(left.longValue() >>> right.intValue());
/* 1408 */           case 7: return LongConstant.fromValue(left.longValue() >>> (int)right.longValue()); }
/*      */          break;
/*      */     } 
/* 1411 */     return NotAConstant;
/*      */   }
/*      */   
/*      */   public static final Constant computeConstantOperationXOR(Constant left, int leftId, Constant right, int rightId) {
/* 1415 */     switch (leftId) { case 5:
/* 1416 */         return BooleanConstant.fromValue(left.booleanValue() ^ right.booleanValue());
/*      */       case 2:
/* 1418 */         switch (rightId) { case 2:
/* 1419 */             return IntConstant.fromValue(left.charValue() ^ right.charValue());
/* 1420 */           case 3: return IntConstant.fromValue(left.charValue() ^ right.byteValue());
/* 1421 */           case 4: return IntConstant.fromValue(left.charValue() ^ right.shortValue());
/* 1422 */           case 10: return IntConstant.fromValue(left.charValue() ^ right.intValue());
/* 1423 */           case 7: return LongConstant.fromValue(left.charValue() ^ right.longValue()); }
/*      */         
/*      */         break;
/*      */       case 3:
/* 1427 */         switch (rightId) { case 2:
/* 1428 */             return IntConstant.fromValue(left.byteValue() ^ right.charValue());
/* 1429 */           case 3: return IntConstant.fromValue(left.byteValue() ^ right.byteValue());
/* 1430 */           case 4: return IntConstant.fromValue(left.byteValue() ^ right.shortValue());
/* 1431 */           case 10: return IntConstant.fromValue(left.byteValue() ^ right.intValue());
/* 1432 */           case 7: return LongConstant.fromValue(left.byteValue() ^ right.longValue()); }
/*      */         
/*      */         break;
/*      */       case 4:
/* 1436 */         switch (rightId) { case 2:
/* 1437 */             return IntConstant.fromValue(left.shortValue() ^ right.charValue());
/* 1438 */           case 3: return IntConstant.fromValue(left.shortValue() ^ right.byteValue());
/* 1439 */           case 4: return IntConstant.fromValue(left.shortValue() ^ right.shortValue());
/* 1440 */           case 10: return IntConstant.fromValue(left.shortValue() ^ right.intValue());
/* 1441 */           case 7: return LongConstant.fromValue(left.shortValue() ^ right.longValue()); }
/*      */         
/*      */         break;
/*      */       case 10:
/* 1445 */         switch (rightId) { case 2:
/* 1446 */             return IntConstant.fromValue(left.intValue() ^ right.charValue());
/* 1447 */           case 3: return IntConstant.fromValue(left.intValue() ^ right.byteValue());
/* 1448 */           case 4: return IntConstant.fromValue(left.intValue() ^ right.shortValue());
/* 1449 */           case 10: return IntConstant.fromValue(left.intValue() ^ right.intValue());
/* 1450 */           case 7: return LongConstant.fromValue(left.intValue() ^ right.longValue()); }
/*      */         
/*      */         break;
/*      */       case 7:
/* 1454 */         switch (rightId) { case 2:
/* 1455 */             return LongConstant.fromValue(left.longValue() ^ right.charValue());
/* 1456 */           case 3: return LongConstant.fromValue(left.longValue() ^ right.byteValue());
/* 1457 */           case 4: return LongConstant.fromValue(left.longValue() ^ right.shortValue());
/* 1458 */           case 10: return LongConstant.fromValue(left.longValue() ^ right.intValue());
/* 1459 */           case 7: return LongConstant.fromValue(left.longValue() ^ right.longValue()); }
/*      */          break; }
/*      */     
/* 1462 */     return NotAConstant;
/*      */   }
/*      */   
/*      */   public double doubleValue() {
/* 1466 */     throw new ShouldNotImplement(Messages.bind(Messages.constant_cannotCastedInto, new String[] { typeName(), "double" }));
/*      */   }
/*      */   
/*      */   public float floatValue() {
/* 1470 */     throw new ShouldNotImplement(Messages.bind(Messages.constant_cannotCastedInto, new String[] { typeName(), "float" }));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean hasSameValue(Constant otherConstant) {
/*      */     String value;
/* 1478 */     if (this == otherConstant)
/* 1479 */       return true; 
/*      */     int typeID;
/* 1481 */     if ((typeID = typeID()) != otherConstant.typeID())
/* 1482 */       return false; 
/* 1483 */     switch (typeID) {
/*      */       case 5:
/* 1485 */         return (booleanValue() == otherConstant.booleanValue());
/*      */       case 3:
/* 1487 */         return (byteValue() == otherConstant.byteValue());
/*      */       case 2:
/* 1489 */         return (charValue() == otherConstant.charValue());
/*      */       case 8:
/* 1491 */         return (doubleValue() == otherConstant.doubleValue());
/*      */       case 9:
/* 1493 */         return (floatValue() == otherConstant.floatValue());
/*      */       case 10:
/* 1495 */         return (intValue() == otherConstant.intValue());
/*      */       case 4:
/* 1497 */         return (shortValue() == otherConstant.shortValue());
/*      */       case 7:
/* 1499 */         return (longValue() == otherConstant.longValue());
/*      */       case 11:
/* 1501 */         value = stringValue();
/* 1502 */         return (value == null) ? (
/* 1503 */           (otherConstant.stringValue() == null)) : 
/* 1504 */           value.equals(otherConstant.stringValue());
/*      */     } 
/* 1506 */     return false;
/*      */   }
/*      */   
/*      */   public int intValue() {
/* 1510 */     throw new ShouldNotImplement(Messages.bind(Messages.constant_cannotCastedInto, new String[] { typeName(), "int" }));
/*      */   }
/*      */   
/*      */   public long longValue() {
/* 1514 */     throw new ShouldNotImplement(Messages.bind(Messages.constant_cannotCastedInto, new String[] { typeName(), "long" }));
/*      */   }
/*      */   
/*      */   public short shortValue() {
/* 1518 */     throw new ShouldNotImplement(Messages.bind(Messages.constant_cannotConvertedTo, new String[] { typeName(), "short" }));
/*      */   }
/*      */   
/*      */   public String stringValue() {
/* 1522 */     throw new ShouldNotImplement(Messages.bind(Messages.constant_cannotConvertedTo, new String[] { typeName(), "String" }));
/*      */   }
/*      */ 
/*      */   
/*      */   public String toString() {
/* 1527 */     if (this == NotAConstant) return "(Constant) NotAConstant"; 
/* 1528 */     return super.toString();
/*      */   }
/*      */   public abstract int typeID();
/*      */   
/*      */   public String typeName() {
/* 1533 */     switch (typeID()) { case 10:
/* 1534 */         return "int";
/* 1535 */       case 3: return "byte";
/* 1536 */       case 4: return "short";
/* 1537 */       case 2: return "char";
/* 1538 */       case 9: return "float";
/* 1539 */       case 8: return "double";
/* 1540 */       case 5: return "boolean";
/* 1541 */       case 7: return "long";
/* 1542 */       case 11: return "java.lang.String"; }
/* 1543 */      return "unknown";
/*      */   }
/*      */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\impl\Constant.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */