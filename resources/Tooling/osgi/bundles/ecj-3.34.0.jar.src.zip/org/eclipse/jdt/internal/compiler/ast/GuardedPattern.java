/*     */ package org.eclipse.jdt.internal.compiler.ast;
/*     */ 
/*     */ import org.eclipse.jdt.internal.compiler.ASTVisitor;
/*     */ import org.eclipse.jdt.internal.compiler.codegen.BranchLabel;
/*     */ import org.eclipse.jdt.internal.compiler.codegen.CodeStream;
/*     */ import org.eclipse.jdt.internal.compiler.flow.FlowContext;
/*     */ import org.eclipse.jdt.internal.compiler.flow.FlowInfo;
/*     */ import org.eclipse.jdt.internal.compiler.impl.Constant;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.BlockScope;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.LocalVariableBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.Scope;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.TypeBinding;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class GuardedPattern
/*     */   extends Pattern
/*     */ {
/*     */   public Pattern primaryPattern;
/*     */   public Expression condition;
/*  30 */   int thenInitStateIndex1 = -1;
/*  31 */   int thenInitStateIndex2 = -1;
/*  32 */   public int restrictedIdentifierStart = -1;
/*     */   
/*     */   public GuardedPattern(Pattern primaryPattern, Expression conditionalAndExpression) {
/*  35 */     this.primaryPattern = primaryPattern;
/*  36 */     this.condition = conditionalAndExpression;
/*  37 */     this.sourceStart = primaryPattern.sourceStart;
/*  38 */     this.sourceEnd = conditionalAndExpression.sourceEnd;
/*     */   }
/*     */   
/*     */   public void collectPatternVariablesToScope(LocalVariableBinding[] variables, BlockScope scope) {
/*  42 */     this.primaryPattern.collectPatternVariablesToScope(variables, scope);
/*  43 */     addPatternVariablesWhenTrue(this.primaryPattern.getPatternVariablesWhenTrue());
/*  44 */     this.condition.collectPatternVariablesToScope(getPatternVariablesWhenTrue(), scope);
/*  45 */     addPatternVariablesWhenTrue(this.condition.getPatternVariablesWhenTrue());
/*     */   }
/*     */ 
/*     */   
/*     */   public LocalDeclaration getPatternVariable() {
/*  50 */     return this.primaryPattern.getPatternVariable();
/*     */   }
/*     */ 
/*     */   
/*     */   public FlowInfo analyseCode(BlockScope currentScope, FlowContext flowContext, FlowInfo flowInfo) {
/*  55 */     flowInfo = this.primaryPattern.analyseCode(currentScope, flowContext, flowInfo);
/*  56 */     this.thenInitStateIndex1 = currentScope.methodScope().recordInitializationStates(flowInfo);
/*  57 */     FlowInfo mergedFlow = this.condition.analyseCode(currentScope, flowContext, flowInfo);
/*  58 */     mergedFlow = mergedFlow.safeInitsWhenTrue();
/*  59 */     this.thenInitStateIndex2 = currentScope.methodScope().recordInitializationStates(mergedFlow);
/*  60 */     return mergedFlow;
/*     */   }
/*     */ 
/*     */   
/*     */   public void generateOptimizedBoolean(BlockScope currentScope, CodeStream codeStream, BranchLabel trueLabel, BranchLabel falseLabel) {
/*  65 */     this.thenTarget = new BranchLabel(codeStream);
/*  66 */     this.elseTarget = new BranchLabel(codeStream);
/*  67 */     this.primaryPattern.generateOptimizedBoolean(currentScope, codeStream, this.thenTarget, this.elseTarget);
/*  68 */     Constant cst = this.condition.optimizedBooleanConstant();
/*     */     
/*  70 */     this.condition.generateOptimizedBoolean(
/*  71 */         currentScope, 
/*  72 */         codeStream, 
/*  73 */         this.thenTarget, 
/*  74 */         (BranchLabel)null, 
/*  75 */         (cst == Constant.NotAConstant));
/*  76 */     if (this.thenInitStateIndex2 != -1) {
/*  77 */       codeStream.removeNotDefinitelyAssignedVariables((Scope)currentScope, this.thenInitStateIndex2);
/*  78 */       codeStream.addDefinitelyAssignedVariables((Scope)currentScope, this.thenInitStateIndex2);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isAlwaysTrue() {
/*  84 */     Constant cst = this.condition.optimizedBooleanConstant();
/*  85 */     return (cst != Constant.NotAConstant && cst.booleanValue());
/*     */   }
/*     */   
/*     */   public boolean isTotalForType(TypeBinding type) {
/*  89 */     return (this.primaryPattern.isTotalForType(type) && isAlwaysTrue());
/*     */   }
/*     */   
/*     */   public Pattern primary() {
/*  93 */     return this.primaryPattern;
/*     */   }
/*     */ 
/*     */   
/*     */   public void resolve(BlockScope scope) {
/*  98 */     resolveType(scope);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean dominates(Pattern p) {
/* 103 */     if (isAlwaysTrue())
/* 104 */       return this.primaryPattern.dominates(p); 
/* 105 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public TypeBinding resolveType(BlockScope scope) {
/* 110 */     if (this.resolvedType != null || this.primaryPattern == null)
/* 111 */       return this.resolvedType; 
/* 112 */     this.resolvedType = this.primaryPattern.resolveType(scope);
/*     */ 
/*     */ 
/*     */     
/* 116 */     this.condition.resolveTypeExpecting(scope, (TypeBinding)TypeBinding.BOOLEAN);
/* 117 */     LocalDeclaration PatternVar = this.primaryPattern.getPatternVariable();
/* 118 */     final LocalVariableBinding lvb = (PatternVar == null) ? null : PatternVar.binding;
/* 119 */     this.condition.traverse(new ASTVisitor()
/*     */         {
/*     */           
/*     */           public boolean visit(SingleNameReference ref, BlockScope skope)
/*     */           {
/* 124 */             LocalVariableBinding local = ref.localVariableBinding();
/* 125 */             if (local != null && local != lvb) {
/* 126 */               ref.bits |= 0x40;
/*     */             }
/* 128 */             return false;
/*     */           }
/* 130 */         },  scope);
/* 131 */     return this.resolvedType = this.primaryPattern.resolvedType;
/*     */   }
/*     */ 
/*     */   
/*     */   public TypeBinding resolveAtType(BlockScope scope, TypeBinding u) {
/* 136 */     if (this.resolvedType == null || this.primaryPattern == null)
/* 137 */       return null; 
/* 138 */     if (this.primaryPattern.isTotalForType(u)) {
/* 139 */       return this.primaryPattern.resolveAtType(scope, u);
/*     */     }
/* 141 */     return this.resolvedType;
/*     */   }
/*     */ 
/*     */   
/*     */   public StringBuffer printExpression(int indent, StringBuffer output) {
/* 146 */     this.primaryPattern.print(indent, output).append(" when ");
/* 147 */     return this.condition.print(indent, output);
/*     */   }
/*     */ 
/*     */   
/*     */   public void traverse(ASTVisitor visitor, BlockScope scope) {
/* 152 */     if (visitor.visit(this, scope)) {
/* 153 */       if (this.primaryPattern != null)
/* 154 */         this.primaryPattern.traverse(visitor, scope); 
/* 155 */       if (this.condition != null)
/* 156 */         this.condition.traverse(visitor, scope); 
/*     */     } 
/* 158 */     visitor.endVisit(this, scope);
/*     */   }
/*     */   
/*     */   public void suspendVariables(CodeStream codeStream, BlockScope scope) {
/* 162 */     codeStream.removeNotDefinitelyAssignedVariables((Scope)scope, this.thenInitStateIndex1);
/* 163 */     this.primaryPattern.suspendVariables(codeStream, scope);
/*     */   }
/*     */   
/*     */   public void resumeVariables(CodeStream codeStream, BlockScope scope) {
/* 167 */     codeStream.addDefinitelyAssignedVariables((Scope)scope, this.thenInitStateIndex2);
/* 168 */     this.primaryPattern.resumeVariables(codeStream, scope);
/*     */   }
/*     */   
/*     */   public void resolveWithExpression(BlockScope scope, Expression expression) {
/* 172 */     this.primaryPattern.resolveWithExpression(scope, expression);
/*     */   }
/*     */   
/*     */   protected boolean isPatternTypeCompatible(TypeBinding other, BlockScope scope) {
/* 176 */     return this.primaryPattern.isPatternTypeCompatible(other, scope);
/*     */   }
/*     */   
/*     */   public void wrapupGeneration(CodeStream codeStream) {
/* 180 */     this.primaryPattern.wrapupGeneration(codeStream);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void generatePatternVariable(BlockScope currentScope, CodeStream codeStream, BranchLabel trueLabel, BranchLabel falseLabel) {
/* 185 */     this.primaryPattern.generatePatternVariable(currentScope, codeStream, trueLabel, falseLabel);
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\ast\GuardedPattern.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */