/*     */ package org.eclipse.jdt.internal.compiler.ast;
/*     */ 
/*     */ import java.util.EmptyStackException;
/*     */ import java.util.HashSet;
/*     */ import java.util.Set;
/*     */ import org.eclipse.jdt.internal.compiler.ASTVisitor;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.BlockScope;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class OOBLFlagger
/*     */   extends ASTVisitor
/*     */ {
/* 394 */   Set<String> labelDecls = new HashSet<>();
/* 395 */   Set<BreakStatement> referencedBreakLabels = new HashSet<>(); public OOBLFlagger(SwitchExpression se) {}
/* 396 */   Set<ContinueStatement> referencedContinueLabels = new HashSet<>();
/*     */ 
/*     */   
/*     */   public boolean visit(SwitchExpression switchExpression, BlockScope blockScope) {
/* 400 */     return true;
/*     */   }
/*     */   private void checkForOutofBoundLabels(BlockScope blockScope) {
/*     */     try {
/* 404 */       for (BreakStatement bs : this.referencedBreakLabels) {
/* 405 */         if (bs.label == null || bs.label.length == 0)
/*     */           continue; 
/* 407 */         if (!this.labelDecls.contains(new String(bs.label)))
/* 408 */           blockScope.problemReporter().switchExpressionsBreakOutOfSwitchExpression(bs); 
/*     */       } 
/* 410 */       for (ContinueStatement cs : this.referencedContinueLabels) {
/* 411 */         if (cs.label == null || cs.label.length == 0)
/*     */           continue; 
/* 413 */         if (!this.labelDecls.contains(new String(cs.label)))
/* 414 */           blockScope.problemReporter().switchExpressionsContinueOutOfSwitchExpression(cs); 
/*     */       } 
/* 416 */     } catch (EmptyStackException emptyStackException) {}
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void endVisit(SwitchExpression switchExpression, BlockScope blockScope) {
/* 423 */     checkForOutofBoundLabels(blockScope);
/*     */   }
/*     */   
/*     */   public boolean visit(BreakStatement breakStatement, BlockScope blockScope) {
/* 427 */     if (breakStatement.label != null && breakStatement.label.length != 0)
/* 428 */       this.referencedBreakLabels.add(breakStatement); 
/* 429 */     return true;
/*     */   }
/*     */   
/*     */   public boolean visit(ContinueStatement continueStatement, BlockScope blockScope) {
/* 433 */     if (continueStatement.label != null && continueStatement.label.length != 0)
/* 434 */       this.referencedContinueLabels.add(continueStatement); 
/* 435 */     return true;
/*     */   }
/*     */   
/*     */   public boolean visit(LambdaExpression lambdaExpression, BlockScope blockScope) {
/* 439 */     return false;
/*     */   }
/*     */   
/*     */   public boolean visit(LabeledStatement stmt, BlockScope blockScope) {
/* 443 */     if (stmt.label != null && stmt.label.length != 0)
/* 444 */       this.labelDecls.add(new String(stmt.label)); 
/* 445 */     return true;
/*     */   }
/*     */   
/*     */   public boolean visit(ReturnStatement stmt, BlockScope blockScope) {
/* 449 */     blockScope.problemReporter().switchExpressionsReturnWithinSwitchExpression(stmt);
/* 450 */     return false;
/*     */   }
/*     */   
/*     */   public boolean visit(TypeDeclaration stmt, BlockScope blockScope) {
/* 454 */     return false;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\ecj-3.34.0.jar!\org\eclipse\jdt\internal\compiler\ast\SwitchExpression$OOBLFlagger.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */