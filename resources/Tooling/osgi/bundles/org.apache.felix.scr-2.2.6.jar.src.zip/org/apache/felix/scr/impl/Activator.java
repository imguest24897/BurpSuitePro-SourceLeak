/*     */ package org.apache.felix.scr.impl;
/*     */ 
/*     */ import java.io.BufferedInputStream;
/*     */ import java.io.BufferedOutputStream;
/*     */ import java.io.DataInputStream;
/*     */ import java.io.DataOutputStream;
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import java.util.concurrent.ConcurrentMap;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ import java.util.concurrent.locks.Lock;
/*     */ import java.util.concurrent.locks.ReentrantLock;
/*     */ import org.apache.felix.scr.impl.config.ScrConfigurationImpl;
/*     */ import org.apache.felix.scr.impl.inject.internal.ClassUtils;
/*     */ import org.apache.felix.scr.impl.logger.InternalLogger;
/*     */ import org.apache.felix.scr.impl.logger.LogConfiguration;
/*     */ import org.apache.felix.scr.impl.logger.ScrLogger;
/*     */ import org.apache.felix.scr.impl.logger.ScrLoggerFactory;
/*     */ import org.apache.felix.scr.impl.manager.ComponentHolder;
/*     */ import org.apache.felix.scr.impl.manager.ScrConfiguration;
/*     */ import org.apache.felix.scr.impl.metadata.ComponentMetadata;
/*     */ import org.apache.felix.scr.impl.metadata.MetadataStoreHelper;
/*     */ import org.apache.felix.scr.impl.runtime.ServiceComponentRuntimeImpl;
/*     */ import org.osgi.framework.Bundle;
/*     */ import org.osgi.framework.BundleContext;
/*     */ import org.osgi.framework.BundleEvent;
/*     */ import org.osgi.framework.InvalidSyntaxException;
/*     */ import org.osgi.framework.ServiceReference;
/*     */ import org.osgi.framework.ServiceRegistration;
/*     */ import org.osgi.framework.wiring.BundleRevision;
/*     */ import org.osgi.framework.wiring.BundleWire;
/*     */ import org.osgi.framework.wiring.BundleWiring;
/*     */ import org.osgi.framework.wiring.FrameworkWiring;
/*     */ import org.osgi.service.component.runtime.ServiceComponentRuntime;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Activator
/*     */   extends AbstractExtender
/*     */ {
/* 109 */   private final ScrConfigurationImpl m_configuration = new ScrConfigurationImpl(this); private BundleContext m_context;
/*     */   private BundleContext m_globalContext;
/*     */   private ServiceReference<?> m_trueCondition;
/*     */   private Bundle m_bundle;
/*     */   private volatile ScrLogger logger;
/*     */   private Map<Long, BundleComponentActivator> m_componentBundles;
/*     */   private ComponentRegistry m_componentRegistry;
/*     */   private ComponentActorThread m_componentActor;
/*     */   private ServiceRegistration<ServiceComponentRuntime> m_runtime_reg;
/*     */   private ComponentCommands m_componentCommands;
/*     */   private ConcurrentMap<Long, List<ComponentMetadata>> m_componentMetadataStore;
/*     */   
/*     */   public void start(BundleContext context) throws Exception {
/* 122 */     this.m_context = context;
/* 123 */     this.m_bundle = context.getBundle();
/* 124 */     this.m_trueCondition = findTrueCondition(context);
/* 125 */     ClassUtils.setFrameworkWiring((FrameworkWiring)context.getBundle("System Bundle").adapt(FrameworkWiring.class));
/*     */     
/* 127 */     this.m_configuration.start(this.m_context);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ServiceReference<?> findTrueCondition(BundleContext context) {
/*     */     try {
/* 135 */       ServiceReference[] arrayOfServiceReference = context.getServiceReferences("org.osgi.service.condition.Condition", "(osgi.condition.id=true)");
/*     */       
/* 137 */       if (arrayOfServiceReference == null || arrayOfServiceReference.length == 0)
/*     */       {
/* 139 */         return null;
/*     */       }
/* 141 */       for (ServiceReference<?> ref : arrayOfServiceReference) {
/*     */         
/* 143 */         Bundle b = ref.getBundle();
/* 144 */         if (b != null && b.getBundleId() == 0L)
/*     */         {
/* 146 */           return ref;
/*     */         }
/*     */       } 
/* 149 */       return null;
/*     */     }
/* 151 */     catch (InvalidSyntaxException e) {
/*     */ 
/*     */       
/* 154 */       throw new RuntimeException(e);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void restart(boolean globalExtender, boolean initialStart) {
/* 160 */     this.m_componentMetadataStore = load(this.m_context, this.logger, this.m_configuration
/* 161 */         .cacheMetadata());
/* 162 */     BundleContext context = this.m_globalContext;
/* 163 */     if (globalExtender) {
/*     */       
/* 165 */       this.m_globalContext = this.m_context.getBundle("System Bundle").getBundleContext();
/*     */     }
/*     */     else {
/*     */       
/* 169 */       this.m_globalContext = this.m_context;
/*     */     } 
/* 171 */     if (!initialStart) {
/*     */       
/* 173 */       this.logger.log(InternalLogger.Level.INFO, "Stopping to restart with new globalExtender setting: {0}", null, new Object[] {
/*     */             
/* 175 */             Boolean.valueOf(globalExtender)
/*     */           });
/*     */ 
/*     */ 
/*     */       
/*     */       try {
/* 181 */         super.stop(context);
/*     */       }
/* 183 */       catch (Exception e) {
/*     */ 
/*     */         
/* 186 */         if (this.logger != null)
/*     */         {
/* 188 */           this.logger.log(InternalLogger.Level.ERROR, "Exception stopping during restart", e);
/*     */         }
/*     */       } 
/*     */     } 
/*     */     
/*     */     try {
/* 194 */       this.logger.log(InternalLogger.Level.INFO, "Starting with globalExtender setting: {0}", null, new Object[] {
/* 195 */             Boolean.valueOf(globalExtender)
/*     */           });
/* 197 */       super.start(this.m_globalContext);
/*     */     }
/* 199 */     catch (Exception e) {
/*     */       
/* 201 */       this.logger.log(InternalLogger.Level.ERROR, "Exception starting during restart", e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void doStart() throws Exception {
/* 211 */     this.m_componentBundles = new HashMap<>();
/* 212 */     this.m_componentRegistry = new ComponentRegistry((ScrConfiguration)this.m_configuration, this.logger);
/*     */     
/* 214 */     ServiceComponentRuntimeImpl runtime = new ServiceComponentRuntimeImpl(this.m_globalContext, this.m_componentRegistry);
/* 215 */     this.m_runtime_reg = this.m_context.registerService(ServiceComponentRuntime.class, runtime, this.m_componentRegistry
/*     */         
/* 217 */         .getServiceRegistrationProperties());
/* 218 */     this.m_componentRegistry.setRegistration(this.m_runtime_reg);
/*     */ 
/*     */     
/* 221 */     this.logger.log(InternalLogger.Level.INFO, " Version = {0}", null, new Object[] { this.m_bundle
/* 222 */           .getVersion().toString() });
/*     */ 
/*     */     
/* 225 */     this.m_componentActor = new ComponentActorThread(this.logger);
/* 226 */     Thread t = new Thread(this.m_componentActor, "SCR Component Actor");
/* 227 */     t.setDaemon(true);
/* 228 */     t.start();
/*     */     
/* 230 */     super.doStart();
/*     */     
/* 232 */     this.m_componentCommands = new ComponentCommands(this.m_context, (ServiceComponentRuntime)runtime, (ScrConfiguration)this.m_configuration);
/* 233 */     this.m_componentCommands.register();
/* 234 */     this.m_componentCommands.updateProvideScrInfoService(this.m_configuration.infoAsService());
/* 235 */     this.m_configuration.setScrCommand(this.m_componentCommands);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void stop(BundleContext context) throws Exception {
/* 241 */     super.stop(context);
/* 242 */     this.m_configuration.stop();
/* 243 */     store(this.m_componentMetadataStore, context, this.logger, this.m_configuration.cacheMetadata());
/* 244 */     this.logger.close();
/*     */   }
/*     */ 
/*     */   
/*     */   public ServiceReference<?> getTrueCondition() {
/* 249 */     return this.m_trueCondition;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void bundleChanged(BundleEvent event) {
/* 255 */     super.bundleChanged(event);
/* 256 */     if (event.getType() == 8 || event
/* 257 */       .getType() == 16)
/*     */     {
/* 259 */       this.m_componentMetadataStore.remove(Long.valueOf(event.getBundle().getBundleId()));
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static ConcurrentMap<Long, List<ComponentMetadata>> load(BundleContext context, ScrLogger logger, boolean loadFromCache) {
/*     */     try {
/* 269 */       ConcurrentMap<Long, List<ComponentMetadata>> result = new ConcurrentHashMap<>();
/* 270 */       if (!loadFromCache)
/*     */       {
/* 272 */         return result;
/*     */       }
/*     */       
/* 275 */       BundleContext systemContext = context.getBundle("System Bundle").getBundleContext();
/*     */       
/* 277 */       File store = context.getDataFile("componentMetadataStore");
/* 278 */       if (store.isFile()) {
/*     */         try {
/* 280 */           DataInputStream in = new DataInputStream(new BufferedInputStream(new FileInputStream(store)));
/*     */ 
/*     */           
/* 283 */           try { MetadataStoreHelper.MetaDataReader metaDataReader = new MetadataStoreHelper.MetaDataReader();
/* 284 */             if (!metaDataReader.isVersionSupported(in))
/*     */             
/*     */             { 
/* 287 */               ConcurrentMap<Long, List<ComponentMetadata>> concurrentMap = result;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */               
/* 317 */               in.close(); return concurrentMap; }  int numStrings = in.readInt(); for (int i = 0; i < numStrings; i++) metaDataReader.readIndexedString(in);  int numBundles = in.readInt(); for (int j = 0; j < numBundles; j++) { long bundleId = in.readLong(); int numComponents = in.readInt(); long lastModified = in.readLong(); List<ComponentMetadata> components = new ArrayList<>(numComponents); for (int k = 0; k < numComponents; k++) components.add(ComponentMetadata.load(in, metaDataReader));  Bundle b = systemContext.getBundle(bundleId); if (b != null) if (lastModified == b.getLastModified()) result.put(Long.valueOf(bundleId), components);   }  in.close(); } catch (Throwable throwable) { try { in.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }  throw throwable; } 
/* 318 */         } catch (IOException e) {
/*     */           
/* 320 */           logger.log(InternalLogger.Level.WARN, "Error loading component metadata cache.", e);
/*     */         } 
/*     */       }
/*     */       
/* 324 */       return result;
/*     */     }
/* 326 */     catch (RuntimeException re) {
/*     */ 
/*     */       
/* 329 */       logger.log(InternalLogger.Level.ERROR, "Error loading component metadata cache.", re);
/*     */       
/* 331 */       return new ConcurrentHashMap<>();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void store(Map<Long, List<ComponentMetadata>> componentsMap, BundleContext context, ScrLogger logger, boolean storeCache) {
/* 339 */     if (!storeCache) {
/*     */       return;
/*     */     }
/*     */ 
/*     */     
/* 344 */     BundleContext systemContext = context.getBundle("System Bundle").getBundleContext();
/* 345 */     File store = context.getDataFile("componentMetadataStore"); try {
/* 346 */       DataOutputStream out = new DataOutputStream(new BufferedOutputStream(new FileOutputStream(store)));
/*     */ 
/*     */       
/* 349 */       try { MetadataStoreHelper.MetaDataWriter metaDataWriter = new MetadataStoreHelper.MetaDataWriter();
/* 350 */         metaDataWriter.writeVersion(out);
/*     */         
/* 352 */         Set<String> allStrings = new HashSet<>();
/* 353 */         for (List<ComponentMetadata> components : componentsMap.values()) {
/*     */           
/* 355 */           for (ComponentMetadata component : components)
/*     */           {
/* 357 */             component.collectStrings(allStrings);
/*     */           }
/*     */         } 
/*     */         
/* 361 */         allStrings.remove(null);
/* 362 */         out.writeInt(allStrings.size());
/* 363 */         for (String s : allStrings)
/*     */         {
/* 365 */           metaDataWriter.writeIndexedString(s, out);
/*     */         }
/* 367 */         out.writeInt(componentsMap.size());
/* 368 */         for (Map.Entry<Long, List<ComponentMetadata>> entry : componentsMap.entrySet()) {
/*     */           
/* 370 */           out.writeLong(((Long)entry.getKey()).longValue());
/* 371 */           out.writeInt(((List)entry.getValue()).size());
/* 372 */           Bundle b = systemContext.getBundle(((Long)entry.getKey()).longValue());
/* 373 */           out.writeLong((b == null) ? -1L : b.getLastModified());
/* 374 */           for (ComponentMetadata component : entry.getValue())
/*     */           {
/* 376 */             component.store(out, metaDataWriter);
/*     */           }
/*     */         } 
/* 379 */         out.close(); } catch (Throwable throwable) { try { out.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }  throw throwable; } 
/* 380 */     } catch (IOException e) {
/*     */       
/* 382 */       logger.log(InternalLogger.Level.WARN, "Error storing component metadata cache.", e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void doStop() throws Exception {
/* 396 */     super.doStop();
/*     */     
/* 398 */     if (this.m_componentCommands != null)
/*     */     {
/* 400 */       this.m_componentCommands.unregister();
/*     */     }
/* 402 */     if (this.m_runtime_reg != null) {
/*     */       
/* 404 */       this.m_runtime_reg.unregister();
/* 405 */       this.m_runtime_reg = null;
/*     */     } 
/*     */     
/* 408 */     if (this.m_componentRegistry != null) {
/*     */       
/* 410 */       this.m_componentRegistry.shutdown();
/* 411 */       this.m_componentRegistry = null;
/*     */     } 
/*     */ 
/*     */     
/* 415 */     if (this.m_componentActor != null) {
/*     */       
/* 417 */       this.m_componentActor.terminate();
/* 418 */       this.m_componentActor = null;
/*     */     } 
/* 420 */     ClassUtils.setFrameworkWiring(null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected ScrExtension doCreateExtension(Bundle bundle) throws Exception {
/* 428 */     return new ScrExtension(bundle);
/*     */   }
/*     */ 
/*     */   
/*     */   protected class ScrExtension
/*     */   {
/*     */     private final Bundle bundle;
/* 435 */     private final Lock stateLock = new ReentrantLock();
/*     */ 
/*     */     
/*     */     public ScrExtension(Bundle bundle) {
/* 439 */       this.bundle = bundle;
/*     */     }
/*     */ 
/*     */     
/*     */     public void start() {
/* 444 */       boolean acquired = false;
/*     */ 
/*     */       
/*     */       try {
/*     */         try {
/* 449 */           acquired = this.stateLock.tryLock(Activator.this.m_configuration.stopTimeout(), TimeUnit.MILLISECONDS);
/*     */         
/*     */         }
/* 452 */         catch (InterruptedException e) {
/*     */           
/* 454 */           Thread.currentThread().interrupt();
/* 455 */           Activator.this.logger.log(InternalLogger.Level.WARN, "The wait for {0} being destroyed before destruction has been interrupted.", e, new Object[] { this.bundle });
/*     */         } 
/*     */ 
/*     */ 
/*     */         
/* 460 */         Activator.this.loadComponents(this.bundle);
/*     */       }
/*     */       finally {
/*     */         
/* 464 */         if (acquired)
/*     */         {
/* 466 */           this.stateLock.unlock();
/*     */         }
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void destroy() {
/* 473 */       boolean acquired = false;
/*     */ 
/*     */       
/*     */       try {
/*     */         try {
/* 478 */           acquired = this.stateLock.tryLock(Activator.this.m_configuration.stopTimeout(), TimeUnit.MILLISECONDS);
/*     */         
/*     */         }
/* 481 */         catch (InterruptedException e) {
/*     */           
/* 483 */           Thread.currentThread().interrupt();
/* 484 */           Activator.this.logger.log(InternalLogger.Level.WARN, "The wait for {0} being started before destruction has been interrupted.", e, new Object[] { this.bundle });
/*     */         } 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 490 */         Activator.this.disposeComponents(this.bundle);
/*     */       }
/*     */       finally {
/*     */         
/* 494 */         if (acquired)
/*     */         {
/* 496 */           this.stateLock.unlock();
/*     */         }
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void loadComponents(Bundle bundle) {
/*     */     boolean loaded;
/* 513 */     Long bundleId = Long.valueOf(bundle.getBundleId());
/* 514 */     List<ComponentMetadata> cached = this.m_componentMetadataStore.get(bundleId);
/* 515 */     if (cached != null && cached.isEmpty()) {
/*     */       return;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 521 */     if (cached == null && bundle
/* 522 */       .getHeaders("").get("Service-Component") == null) {
/*     */ 
/*     */       
/* 525 */       this.m_componentMetadataStore.put(bundleId, 
/* 526 */           Collections.emptyList());
/*     */ 
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/* 532 */     BundleContext context = bundle.getBundleContext();
/* 533 */     if (context == null) {
/*     */       
/* 535 */       this.logger.log(InternalLogger.Level.DEBUG, "Cannot get BundleContext of {0}.", null, new Object[] { bundle });
/*     */ 
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/* 541 */     BundleWiring wiring = (BundleWiring)bundle.adapt(BundleWiring.class);
/* 542 */     List<BundleWire> extenderWires = wiring.getRequiredWires("osgi.extender");
/* 543 */     for (BundleWire wire : extenderWires) {
/*     */       
/* 545 */       if ("osgi.component".equals(wire
/* 546 */           .getCapability().getAttributes().get("osgi.extender"))) {
/*     */         
/* 548 */         if (!((BundleRevision)this.m_bundle.adapt(BundleRevision.class)).equals(wire.getProvider())) {
/*     */           
/* 550 */           this.logger.log(InternalLogger.Level.DEBUG, "{0} wired to a different extender: {1}.", null, new Object[] { bundle, wire
/*     */                 
/* 552 */                 .getProvider().getBundle() });
/*     */ 
/*     */ 
/*     */           
/*     */           return;
/*     */         } 
/*     */ 
/*     */ 
/*     */         
/*     */         break;
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 566 */     synchronized (this.m_componentBundles) {
/*     */       
/* 568 */       if (this.m_componentBundles.containsKey(bundleId)) {
/*     */         
/* 570 */         loaded = true;
/*     */       }
/*     */       else {
/*     */         
/* 574 */         this.m_componentBundles.put(bundleId, null);
/* 575 */         loaded = false;
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 580 */     if (loaded) {
/*     */       
/* 582 */       this.logger.log(InternalLogger.Level.DEBUG, "Components for {0} already loaded. Nothing to do.", null, new Object[] { bundle });
/*     */ 
/*     */ 
/*     */       
/*     */       return;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/* 592 */       BundleComponentActivator ga = new BundleComponentActivator(this.logger, this.m_componentRegistry, this.m_componentActor, context, (ScrConfiguration)this.m_configuration, cached, getTrueCondition());
/* 593 */       ga.initialEnable();
/* 594 */       if (cached == null) {
/*     */         
/* 596 */         List<ComponentHolder<?>> components = ga.getSelectedComponents(null);
/* 597 */         List<ComponentMetadata> metadatas = new ArrayList<>(components.size());
/* 598 */         for (ComponentHolder<?> holder : ga.getSelectedComponents(null))
/*     */         {
/* 600 */           metadatas.add(holder.getComponentMetadata());
/*     */         }
/* 602 */         this.m_componentMetadataStore.put(bundleId, metadatas);
/*     */       } 
/*     */       
/* 605 */       synchronized (this.m_componentBundles)
/*     */       {
/* 607 */         this.m_componentBundles.put(bundleId, ga);
/*     */       }
/*     */     
/* 610 */     } catch (Exception e) {
/*     */ 
/*     */ 
/*     */       
/* 614 */       synchronized (this.m_componentBundles) {
/*     */         
/* 616 */         this.m_componentBundles.remove(bundleId);
/*     */       } 
/*     */       
/* 619 */       if (e instanceof IllegalStateException && bundle.getState() != 32) {
/*     */         
/* 621 */         this.logger.log(InternalLogger.Level.DEBUG, "{0} has been stopped while trying to activate its components. Trying again when the bundles gets started again.", e, new Object[] { bundle });
/*     */ 
/*     */       
/*     */       }
/*     */       else {
/*     */ 
/*     */         
/* 628 */         this.logger.log(InternalLogger.Level.ERROR, "Error while loading components of {0}", e, new Object[] { bundle });
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void disposeComponents(Bundle bundle) {
/*     */     BundleComponentActivator ga;
/* 641 */     synchronized (this.m_componentBundles) {
/*     */       
/* 643 */       ga = this.m_componentBundles.remove(Long.valueOf(bundle.getBundleId()));
/*     */     } 
/*     */     
/* 646 */     if (ga != null) {
/*     */       
/*     */       try {
/*     */ 
/*     */         
/* 651 */         int reason = isStopping() ? 5 : 6;
/* 652 */         ga.dispose(reason);
/*     */       }
/* 654 */       catch (Exception e) {
/*     */         
/* 656 */         this.logger.log(InternalLogger.Level.ERROR, "Error while disposing components of {0}", e, new Object[] { bundle });
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void debug(Bundle bundle, String msg) {
/* 665 */     if (this.logger.isLogEnabled(InternalLogger.Level.DEBUG))
/*     */     {
/* 667 */       if (bundle != null) {
/*     */         
/* 669 */         this.logger.log(InternalLogger.Level.DEBUG, "{0} : " + msg, null, new Object[] { bundle });
/*     */       }
/*     */       else {
/*     */         
/* 673 */         this.logger.log(InternalLogger.Level.DEBUG, msg, null);
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void warn(Bundle bundle, String msg, Throwable t) {
/* 681 */     if (this.logger.isLogEnabled(InternalLogger.Level.WARN))
/*     */     {
/* 683 */       if (bundle != null) {
/*     */         
/* 685 */         this.logger.log(InternalLogger.Level.WARN, "{0} : " + msg, t, new Object[] { bundle });
/*     */       }
/*     */       else {
/*     */         
/* 689 */         this.logger.log(InternalLogger.Level.WARN, msg, t);
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setLogger() {
/* 700 */     if (this.logger == null)
/*     */     {
/* 702 */       this.logger = ScrLoggerFactory.create(this.m_context, (LogConfiguration)this.m_configuration);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.apache.felix.scr-2.2.6.jar!\org\apache\felix\scr\impl\Activator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */