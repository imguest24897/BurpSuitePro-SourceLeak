/*     */ package org.apache.felix.scr.impl.inject.field;
/*     */ 
/*     */ import java.lang.reflect.Field;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Modifier;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Optional;
/*     */ import java.util.concurrent.CopyOnWriteArrayList;
/*     */ import java.util.concurrent.CopyOnWriteArraySet;
/*     */ import org.apache.felix.scr.impl.inject.BindParameters;
/*     */ import org.apache.felix.scr.impl.inject.InitReferenceMethod;
/*     */ import org.apache.felix.scr.impl.inject.MethodResult;
/*     */ import org.apache.felix.scr.impl.inject.RefPair;
/*     */ import org.apache.felix.scr.impl.inject.ReferenceMethod;
/*     */ import org.apache.felix.scr.impl.inject.ScrComponentContext;
/*     */ import org.apache.felix.scr.impl.inject.ValueUtils;
/*     */ import org.apache.felix.scr.impl.inject.internal.ClassUtils;
/*     */ import org.apache.felix.scr.impl.logger.ComponentLogger;
/*     */ import org.apache.felix.scr.impl.logger.InternalLogger;
/*     */ import org.apache.felix.scr.impl.metadata.ReferenceMetadata;
/*     */ import org.osgi.framework.BundleContext;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FieldHandler
/*     */ {
/*     */   private final ReferenceMetadata metadata;
/*     */   private final Class<?> componentClass;
/*     */   private volatile Field field;
/*     */   private volatile ValueUtils.ValueType valueType;
/*     */   private volatile State state;
/*     */   
/*     */   public FieldHandler(ReferenceMetadata metadata, Class<?> componentClass) {
/*  77 */     this.metadata = metadata;
/*  78 */     this.componentClass = componentClass;
/*  79 */     this.state = NotResolved.INSTANCE;
/*     */   }
/*     */   
/*     */   private enum METHOD_TYPE
/*     */   {
/*  84 */     BIND,
/*  85 */     UNBIND,
/*  86 */     UPDATED;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean initField(Object componentInstance, ComponentLogger logger) {
/*  93 */     if (this.valueType == ValueUtils.ValueType.ignore)
/*     */     {
/*  95 */       return true;
/*     */     }
/*     */     
/*     */     try {
/*  99 */       if (this.metadata.isMultiple())
/*     */       {
/* 101 */         if (this.metadata.isReplace())
/*     */         {
/* 103 */           setFieldValue(componentInstance, new CopyOnWriteArrayList());
/*     */         }
/*     */         else
/*     */         {
/* 107 */           Class<?> fieldType = this.field.getType();
/*     */ 
/*     */ 
/*     */           
/* 111 */           Object providedImpl = getFieldValue(componentInstance);
/* 112 */           if (providedImpl == null)
/*     */           {
/* 114 */             if (Modifier.isFinal(this.field.getModifiers())) {
/*     */               
/* 116 */               logger.log(InternalLogger.Level.ERROR, "Field {0} in class {1} must not be declared as final", null, new Object[] { this.metadata
/*     */ 
/*     */                     
/* 119 */                     .getField(), this.componentClass });
/* 120 */               this.valueType = ValueUtils.ValueType.ignore;
/* 121 */               return true;
/*     */             } 
/* 123 */             if (fieldType != ClassUtils.LIST_CLASS && fieldType != ClassUtils.COLLECTION_CLASS) {
/*     */               
/* 125 */               logger.log(InternalLogger.Level.ERROR, "Field {0} in class {1} has unsupported type {2}. It must be one of java.util.Collection or java.util.List.", null, new Object[] { this.metadata
/*     */ 
/*     */                     
/* 128 */                     .getField(), this.componentClass, fieldType.getName() });
/* 129 */               this.valueType = ValueUtils.ValueType.ignore;
/* 130 */               return true;
/*     */             } 
/* 132 */             if (fieldType == ClassUtils.LIST_CLASS)
/*     */             {
/* 134 */               setFieldValue(componentInstance, new CopyOnWriteArrayList());
/*     */             
/*     */             }
/*     */             else
/*     */             {
/* 139 */               setFieldValue(componentInstance, new CopyOnWriteArraySet());
/*     */             
/*     */             }
/*     */           
/*     */           }
/*     */         
/*     */         }
/*     */       
/*     */       }
/* 148 */       else if (this.metadata.isOptional())
/*     */       {
/* 150 */         if (this.valueType == ValueUtils.ValueType.ref_optional)
/*     */         {
/* 152 */           setFieldValue(componentInstance, Optional.empty());
/*     */         
/*     */         }
/*     */         else
/*     */         {
/* 157 */           setFieldValue(componentInstance, null);
/*     */         }
/*     */       
/*     */       }
/*     */     
/* 162 */     } catch (InvocationTargetException ite) {
/*     */       
/* 164 */       this.valueType = ValueUtils.ValueType.ignore;
/*     */       
/* 166 */       logger.log(InternalLogger.Level.ERROR, "Field {0} in class {1} can't be initialized.", ite, new Object[] { this.metadata
/* 167 */             .getField(), this.componentClass });
/* 168 */       return false;
/*     */     } 
/*     */     
/* 171 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   private Collection<Object> getReplaceCollection(BindParameters bp) {
/* 176 */     List<Object> objects = new ArrayList();
/* 177 */     for (Object val : bp.getComponentContext().getBoundValues(this.metadata.getName()).values())
/*     */     {
/* 179 */       objects.add(val);
/*     */     }
/* 181 */     return objects;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private MethodResult updateField(METHOD_TYPE mType, Object componentInstance, BindParameters bp) throws InvocationTargetException {
/* 189 */     ScrComponentContext key = bp.getComponentContext();
/* 190 */     RefPair<?, ?> refPair = bp.getRefPair();
/*     */     
/* 192 */     if (!this.metadata.isMultiple()) {
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 197 */       if (mType == METHOD_TYPE.UNBIND)
/*     */       {
/* 199 */         Map<RefPair<?, ?>, Object> boundValues = bp.getComponentContext().getBoundValues(this.metadata.getName());
/* 200 */         synchronized (boundValues)
/*     */         {
/* 202 */           if (this.metadata.isOptional() && !this.metadata.isStatic())
/*     */           {
/*     */             
/* 205 */             if (boundValues.size() == 1)
/*     */             {
/* 207 */               if (this.valueType == ValueUtils.ValueType.ref_optional) {
/*     */                 
/* 209 */                 setFieldValue(componentInstance, Optional.empty());
/*     */               
/*     */               }
/*     */               else {
/*     */                 
/* 214 */                 setFieldValue(componentInstance, null);
/*     */               } 
/*     */             }
/*     */           }
/* 218 */           boundValues.remove(refPair);
/*     */         
/*     */         }
/*     */ 
/*     */       
/*     */       }
/* 224 */       else if (mType == METHOD_TYPE.UPDATED)
/*     */       {
/* 226 */         if (this.valueType == ValueUtils.ValueType.ref_map || this.valueType == ValueUtils.ValueType.ref_tuple)
/*     */         {
/* 228 */           if (this.metadata.isStatic())
/*     */           {
/* 230 */             return MethodResult.REACTIVATE;
/*     */           }
/* 232 */           Object obj = ValueUtils.getValue(componentInstance.getClass().getName(), this.valueType, this.field
/* 233 */               .getType(), key, refPair, this.metadata);
/* 234 */           setFieldValue(componentInstance, obj);
/* 235 */           bp.getComponentContext().getBoundValues(this.metadata.getName()).put(refPair, obj);
/*     */         }
/*     */       
/*     */       }
/*     */       else
/*     */       {
/* 241 */         Object obj = ValueUtils.getValue(componentInstance.getClass().getName(), this.valueType, this.field
/* 242 */             .getType(), key, refPair, this.metadata);
/* 243 */         setFieldValue(componentInstance, obj);
/* 244 */         bp.getComponentContext().getBoundValues(this.metadata.getName()).put(refPair, obj);
/*     */ 
/*     */       
/*     */       }
/*     */ 
/*     */ 
/*     */     
/*     */     }
/* 252 */     else if (mType == METHOD_TYPE.BIND) {
/*     */       
/* 254 */       Object obj = ValueUtils.getValue(componentInstance.getClass().getName(), this.valueType, this.field
/* 255 */           .getType(), key, refPair, this.metadata);
/* 256 */       bp.getComponentContext().getBoundValues(this.metadata.getName()).put(refPair, obj);
/* 257 */       if (this.metadata.isReplace())
/*     */       {
/* 259 */         setFieldValue(componentInstance, getReplaceCollection(bp));
/*     */       
/*     */       }
/*     */       else
/*     */       {
/* 264 */         Collection<Object> col = (Collection<Object>)getFieldValue(componentInstance);
/* 265 */         col.add(obj);
/*     */       }
/*     */     
/*     */     }
/* 269 */     else if (mType == METHOD_TYPE.UNBIND) {
/*     */       
/* 271 */       if (!this.metadata.isStatic())
/*     */       {
/* 273 */         Object obj = bp.getComponentContext().getBoundValues(this.metadata.getName()).remove(refPair);
/* 274 */         if (this.metadata.isReplace())
/*     */         {
/* 276 */           setFieldValue(componentInstance, getReplaceCollection(bp));
/*     */         
/*     */         }
/*     */         else
/*     */         {
/* 281 */           Collection<Object> col = (Collection<Object>)getFieldValue(componentInstance);
/* 282 */           col.remove(obj);
/*     */         }
/*     */       
/*     */       }
/*     */     
/* 287 */     } else if (mType == METHOD_TYPE.UPDATED) {
/*     */       
/* 289 */       if (this.valueType == ValueUtils.ValueType.ref_map || this.valueType == ValueUtils.ValueType.ref_tuple)
/*     */       {
/* 291 */         if (!this.metadata.isStatic()) {
/*     */           
/* 293 */           Object obj = ValueUtils.getValue(componentInstance.getClass().getName(), this.valueType, this.field
/* 294 */               .getType(), key, refPair, this.metadata);
/* 295 */           Object oldObj = bp.getComponentContext().getBoundValues(this.metadata.getName()).put(refPair, obj);
/*     */           
/* 297 */           if (this.metadata.isReplace())
/*     */           {
/* 299 */             setFieldValue(componentInstance, getReplaceCollection(bp));
/*     */           
/*     */           }
/*     */           else
/*     */           {
/* 304 */             Collection<Object> col = (Collection<Object>)getFieldValue(componentInstance);
/* 305 */             col.add(obj);
/* 306 */             col.remove(oldObj);
/*     */           }
/*     */         
/*     */         }
/*     */         else {
/*     */           
/* 312 */           return MethodResult.REACTIVATE;
/*     */         } 
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 318 */     return MethodResult.VOID;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void setFieldValue(Object componentInstance, Object value) throws InvocationTargetException {
/*     */     try {
/* 326 */       this.field.set(componentInstance, value);
/*     */     }
/* 328 */     catch (IllegalArgumentException iae) {
/*     */       
/* 330 */       throw new InvocationTargetException(iae);
/*     */     }
/* 332 */     catch (IllegalAccessException iae) {
/*     */       
/* 334 */       throw new InvocationTargetException(iae);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Object getFieldValue(Object componentInstance) throws InvocationTargetException {
/*     */     try {
/* 343 */       return this.field.get(componentInstance);
/*     */     }
/* 345 */     catch (IllegalArgumentException iae) {
/*     */       
/* 347 */       throw new InvocationTargetException(iae);
/*     */     }
/* 349 */     catch (IllegalAccessException iae) {
/*     */       
/* 351 */       throw new InvocationTargetException(iae);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static class NotResolved
/*     */     implements State
/*     */   {
/* 378 */     private static final FieldHandler.State INSTANCE = new NotResolved();
/*     */ 
/*     */     
/*     */     private void resolve(FieldHandler handler, ComponentLogger logger) {
/* 382 */       logger.log(InternalLogger.Level.DEBUG, "getting field: {0}", null, new Object[] {
/* 383 */             FieldHandler.access$100(handler).getField()
/*     */           });
/*     */       
/* 386 */       FieldUtils.FieldSearchResult result = FieldUtils.searchField(handler.componentClass, handler.metadata.getField(), logger);
/* 387 */       handler.setSearchResult(result, logger);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public MethodResult invoke(FieldHandler handler, FieldHandler.METHOD_TYPE mType, Object componentInstance, BindParameters rawParameter) throws InvocationTargetException {
/* 397 */       resolve(handler, rawParameter.getComponentContext().getLogger());
/* 398 */       return handler.state.invoke(handler, mType, componentInstance, rawParameter);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean fieldExists(FieldHandler handler, ComponentLogger logger) {
/* 404 */       resolve(handler, logger);
/* 405 */       return handler.state.fieldExists(handler, logger);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static class NotFound
/*     */     implements State
/*     */   {
/* 414 */     private static final FieldHandler.State INSTANCE = new NotFound();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public MethodResult invoke(FieldHandler handler, FieldHandler.METHOD_TYPE mType, Object componentInstance, BindParameters rawParameter) {
/* 422 */       rawParameter.getComponentContext().getLogger().log(InternalLogger.Level.ERROR, "Field [{0}] not found", null, new Object[] {
/*     */             
/* 424 */             FieldHandler.access$100(handler).getField() });
/* 425 */       return null;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean fieldExists(FieldHandler handler, ComponentLogger logger) {
/* 431 */       return false;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static class Resolved
/*     */     implements State
/*     */   {
/* 440 */     private static final FieldHandler.State INSTANCE = new Resolved();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public MethodResult invoke(FieldHandler handler, FieldHandler.METHOD_TYPE mType, Object componentInstance, BindParameters rawParameter) throws InvocationTargetException {
/* 449 */       return handler.updateField(mType, componentInstance, rawParameter);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean fieldExists(FieldHandler handler, ComponentLogger logger) {
/* 455 */       return true;
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean fieldExists(ComponentLogger logger) {
/* 461 */     return this.state.fieldExists(this, logger);
/*     */   }
/*     */ 
/*     */   
/*     */   synchronized void setSearchResult(FieldUtils.FieldSearchResult result, ComponentLogger logger) {
/* 466 */     if (result == null) {
/*     */       
/* 468 */       this.field = null;
/* 469 */       this.valueType = null;
/* 470 */       this.state = NotFound.INSTANCE;
/*     */       
/* 472 */       logger.log(InternalLogger.Level.ERROR, "Field [{0}] not found; Component will fail", null, new Object[] { this.metadata
/* 473 */             .getField() });
/*     */     }
/*     */     else {
/*     */       
/* 477 */       this.field = result.field;
/* 478 */       if (!result.usable) {
/*     */         
/* 480 */         this.valueType = ValueUtils.ValueType.ignore;
/*     */       }
/*     */       else {
/*     */         
/* 484 */         this.valueType = ValueUtils.getReferenceValueType(this.componentClass, this.metadata, result.field
/* 485 */             .getType(), result.field, logger);
/*     */       } 
/* 487 */       this.state = Resolved.INSTANCE;
/* 488 */       logger.log(InternalLogger.Level.DEBUG, "Found field: {0}", null, new Object[] { result.field });
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static final class ReferenceMethodImpl
/*     */     implements ReferenceMethod
/*     */   {
/*     */     private final FieldHandler.METHOD_TYPE methodType;
/*     */     
/*     */     private final FieldHandler handler;
/*     */ 
/*     */     
/*     */     public ReferenceMethodImpl(FieldHandler.METHOD_TYPE mt, FieldHandler handler) {
/* 503 */       this.methodType = mt;
/* 504 */       this.handler = handler;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public <S, T> MethodResult invoke(Object componentInstance, BindParameters rawParameter, MethodResult methodCallFailureResult) {
/* 512 */       if (this.handler.valueType == ValueUtils.ValueType.ignore)
/*     */       {
/* 514 */         return MethodResult.VOID;
/*     */       }
/*     */ 
/*     */       
/*     */       try {
/* 519 */         return this.handler.state.invoke(this.handler, this.methodType, componentInstance, rawParameter);
/*     */ 
/*     */ 
/*     */       
/*     */       }
/* 524 */       catch (InvocationTargetException ite) {
/*     */         
/* 526 */         rawParameter.getComponentContext().getLogger().log(InternalLogger.Level.ERROR, "The {0} field has thrown an exception", null, new Object[] {
/*     */               
/* 528 */               FieldHandler.access$100(this.handler).getField()
/*     */             });
/*     */         
/* 531 */         return methodCallFailureResult;
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public <S, T> boolean getServiceObject(BindParameters rawParameter, BundleContext context) {
/* 539 */       if (this.methodType != FieldHandler.METHOD_TYPE.UNBIND)
/*     */       {
/*     */         
/* 542 */         if (rawParameter.getRefPair().getServiceObject(rawParameter.getComponentContext()) == null && this.handler
/* 543 */           .fieldExists(rawParameter.getComponentContext().getLogger()) && (this.handler
/* 544 */           .valueType == ValueUtils.ValueType.ref_serviceType || this.handler
/* 545 */           .valueType == ValueUtils.ValueType.ref_tuple || this.handler
/* 546 */           .valueType == ValueUtils.ValueType.ref_logger || this.handler
/* 547 */           .valueType == ValueUtils.ValueType.ref_formatterLogger || this.handler
/* 548 */           .valueType == ValueUtils.ValueType.ref_optional))
/*     */         {
/* 550 */           return rawParameter.getRefPair().getServiceObject(rawParameter.getComponentContext(), context);
/*     */         }
/*     */       }
/* 553 */       return true;
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public ReferenceMethod getBind() {
/* 559 */     return new ReferenceMethodImpl(METHOD_TYPE.BIND, this);
/*     */   }
/*     */ 
/*     */   
/*     */   public ReferenceMethod getUnbind() {
/* 564 */     return new ReferenceMethodImpl(METHOD_TYPE.UNBIND, this);
/*     */   }
/*     */ 
/*     */   
/*     */   public ReferenceMethod getUpdated() {
/* 569 */     return new ReferenceMethodImpl(METHOD_TYPE.UPDATED, this);
/*     */   }
/*     */ 
/*     */   
/*     */   public InitReferenceMethod getInit() {
/* 574 */     if (this.valueType == ValueUtils.ValueType.ignore)
/*     */     {
/* 576 */       return null;
/*     */     }
/* 578 */     return new InitReferenceMethod()
/*     */       {
/*     */ 
/*     */         
/*     */         public boolean init(Object componentInstance, ComponentLogger logger)
/*     */         {
/* 584 */           if (FieldHandler.this.fieldExists(logger))
/*     */           {
/* 586 */             return FieldHandler.this.initField(componentInstance, logger);
/*     */           }
/* 588 */           return false;
/*     */         }
/*     */       };
/*     */   }
/*     */   
/*     */   private static interface State {
/*     */     MethodResult invoke(FieldHandler param1FieldHandler, FieldHandler.METHOD_TYPE param1METHOD_TYPE, Object param1Object, BindParameters param1BindParameters) throws InvocationTargetException;
/*     */     
/*     */     boolean fieldExists(FieldHandler param1FieldHandler, ComponentLogger param1ComponentLogger);
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.apache.felix.scr-2.2.6.jar!\org\apache\felix\scr\impl\inject\field\FieldHandler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */