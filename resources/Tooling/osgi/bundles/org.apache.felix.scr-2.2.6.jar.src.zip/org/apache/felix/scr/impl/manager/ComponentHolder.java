package org.apache.felix.scr.impl.manager;

import java.util.Dictionary;
import java.util.List;
import org.apache.felix.scr.impl.metadata.ComponentMetadata;
import org.apache.felix.scr.impl.metadata.TargetedPID;
import org.osgi.util.promise.Promise;

public interface ComponentHolder<S> {
  ComponentActivator getActivator();
  
  ComponentMetadata getComponentMetadata();
  
  void configurationDeleted(TargetedPID paramTargetedPID1, TargetedPID paramTargetedPID2);
  
  boolean configurationUpdated(TargetedPID paramTargetedPID1, TargetedPID paramTargetedPID2, Dictionary<String, Object> paramDictionary, long paramLong);
  
  TargetedPID getConfigurationTargetedPID(TargetedPID paramTargetedPID1, TargetedPID paramTargetedPID2);
  
  List<? extends ComponentManager<?>> getComponents();
  
  Promise<Void> enableComponents(boolean paramBoolean);
  
  Promise<Void> disableComponents(boolean paramBoolean);
  
  boolean isEnabled();
  
  void disposeComponents(int paramInt);
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.apache.felix.scr-2.2.6.jar!\org\apache\felix\scr\impl\manager\ComponentHolder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */