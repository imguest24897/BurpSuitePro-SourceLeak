/*     */ package org.apache.felix.scr.impl.inject.methods;
/*     */ 
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.Comparator;
/*     */ import java.util.List;
/*     */ import org.apache.felix.scr.impl.inject.ActivatorParameter;
/*     */ import org.apache.felix.scr.impl.inject.BaseParameter;
/*     */ import org.apache.felix.scr.impl.inject.LifecycleMethod;
/*     */ import org.apache.felix.scr.impl.inject.MethodResult;
/*     */ import org.apache.felix.scr.impl.inject.ScrComponentContext;
/*     */ import org.apache.felix.scr.impl.inject.internal.Annotations;
/*     */ import org.apache.felix.scr.impl.inject.internal.ClassUtils;
/*     */ import org.apache.felix.scr.impl.logger.ComponentLogger;
/*     */ import org.apache.felix.scr.impl.logger.InternalLogger;
/*     */ import org.apache.felix.scr.impl.metadata.DSVersion;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ActivateMethod
/*     */   extends BaseMethod<ActivatorParameter, Object>
/*     */   implements LifecycleMethod
/*     */ {
/*     */   protected final boolean m_supportsInterfaces;
/*     */   
/*     */   public ActivateMethod(String methodName, boolean methodRequired, Class<?> componentClass, DSVersion dsVersion, boolean configurableServiceProperties, boolean supportsInterfaces) {
/*  52 */     super(methodName, methodRequired, componentClass, dsVersion, configurableServiceProperties);
/*  53 */     this.m_supportsInterfaces = supportsInterfaces;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected BaseMethod.MethodInfo<Object> doFindMethod(Class<?> targetClass, boolean acceptPrivate, boolean acceptPackage, ComponentLogger logger) throws SuitableMethodNotAccessibleException, InvocationTargetException {
/*  65 */     boolean suitableMethodNotAccessible = false;
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/*  70 */       Method method = getMethod(targetClass, getMethodName(), new Class[] { ClassUtils.COMPONENT_CONTEXT_CLASS }, acceptPrivate, acceptPackage, logger);
/*     */       
/*  72 */       if (method != null)
/*     */       {
/*  74 */         return new BaseMethod.MethodInfo(method);
/*     */       }
/*     */     }
/*  77 */     catch (SuitableMethodNotAccessibleException thrown) {
/*     */       
/*  79 */       logger.log(InternalLogger.Level.DEBUG, "SuitableMethodNotAccessible", thrown);
/*  80 */       suitableMethodNotAccessible = true;
/*     */     } 
/*  82 */     if (getDSVersion().isDS11()) {
/*     */       
/*  84 */       List<Method> methods = getSortedMethods(targetClass);
/*  85 */       for (Method m : methods) {
/*     */         
/*  87 */         Class<?>[] parameterTypes = m.getParameterTypes();
/*  88 */         if (parameterTypes.length == 1) {
/*     */           
/*  90 */           Class<?> type = parameterTypes[0];
/*     */           
/*  92 */           if (type == ClassUtils.BUNDLE_CONTEXT_CLASS) {
/*     */             
/*  94 */             if (accept(m, acceptPrivate, acceptPackage, returnValue()))
/*     */             {
/*  96 */               return new BaseMethod.MethodInfo(m);
/*     */             }
/*  98 */             suitableMethodNotAccessible = true;
/*     */           } 
/* 100 */           if (getDSVersion().isDS13() && isAnnotation(type)) {
/*     */             
/* 102 */             if (accept(m, acceptPrivate, acceptPackage, returnValue()))
/*     */             {
/* 104 */               return new BaseMethod.MethodInfo(m);
/*     */             }
/* 106 */             suitableMethodNotAccessible = true;
/*     */           } 
/* 108 */           if (type == ClassUtils.MAP_CLASS) {
/*     */             
/* 110 */             if (accept(m, acceptPrivate, acceptPackage, returnValue()))
/*     */             {
/* 112 */               return new BaseMethod.MethodInfo(m);
/*     */             }
/* 114 */             suitableMethodNotAccessible = true;
/*     */           } 
/* 116 */           if (type == int.class) {
/*     */             
/* 118 */             if (accept(m, acceptPrivate, acceptPackage, returnValue()))
/*     */             {
/* 120 */               return new BaseMethod.MethodInfo(m);
/*     */             }
/* 122 */             suitableMethodNotAccessible = true;
/*     */           } 
/* 124 */           if (type == Integer.class) {
/*     */             
/* 126 */             if (accept(m, acceptPrivate, acceptPackage, returnValue()))
/*     */             {
/* 128 */               return new BaseMethod.MethodInfo(m);
/*     */             }
/* 130 */             suitableMethodNotAccessible = true;
/*     */           } 
/*     */           continue;
/*     */         } 
/* 134 */         if (parameterTypes.length > 1) {
/*     */           
/* 136 */           boolean accept = true;
/* 137 */           for (Class<?> type : parameterTypes) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */             
/* 143 */             accept = (type == ClassUtils.COMPONENT_CONTEXT_CLASS || type == ClassUtils.BUNDLE_CONTEXT_CLASS || type == ClassUtils.MAP_CLASS || (isDeactivate() && (type == int.class || type == Integer.class)) || (getDSVersion().isDS13() && isAnnotation(type)));
/* 144 */             if (!accept) {
/*     */               break;
/*     */             }
/*     */           } 
/*     */ 
/*     */           
/* 150 */           if (accept) {
/*     */             
/* 152 */             if (accept(m, acceptPrivate, acceptPackage, returnValue()))
/*     */             {
/* 154 */               return new BaseMethod.MethodInfo(m);
/*     */             }
/* 156 */             suitableMethodNotAccessible = true;
/*     */           } 
/*     */           
/*     */           continue;
/*     */         } 
/*     */         
/* 162 */         if (accept(m, acceptPrivate, acceptPackage, returnValue()))
/*     */         {
/* 164 */           return new BaseMethod.MethodInfo(m);
/*     */         }
/* 166 */         suitableMethodNotAccessible = true;
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 172 */     if (suitableMethodNotAccessible)
/*     */     {
/* 174 */       throw new SuitableMethodNotAccessibleException();
/*     */     }
/*     */     
/* 177 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void setTypes(Object types) {}
/*     */ 
/*     */ 
/*     */   
/*     */   boolean isDeactivate() {
/* 188 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   List<Method> getSortedMethods(Class<?> targetClass) {
/* 199 */     List<Method> result = new ArrayList<>();
/* 200 */     Method[] methods = targetClass.getDeclaredMethods();
/* 201 */     for (Method m : methods) {
/*     */       
/* 203 */       if (m.getName().equals(getMethodName()))
/*     */       {
/* 205 */         result.add(m);
/*     */       }
/*     */     } 
/* 208 */     Collections.sort(result, new Comparator<Method>()
/*     */         {
/*     */           
/*     */           public int compare(Method m1, Method m2)
/*     */           {
/* 213 */             int l1 = (m1.getParameterTypes()).length;
/* 214 */             int l2 = (m2.getParameterTypes()).length;
/* 215 */             if (l1 == 0)
/*     */             {
/* 217 */               return l2;
/*     */             }
/* 219 */             if (l2 == 0)
/*     */             {
/* 221 */               return -l1;
/*     */             }
/* 223 */             if (l1 == 1 && l2 == 1) {
/*     */               
/* 225 */               Class<?> t1 = m1.getParameterTypes()[0];
/* 226 */               Class<?> t2 = m2.getParameterTypes()[0];
/*     */               
/* 228 */               if (t1 == ClassUtils.COMPONENT_CONTEXT_CLASS) return -1; 
/* 229 */               if (t2 == ClassUtils.COMPONENT_CONTEXT_CLASS) return 1; 
/* 230 */               if (t1 == ClassUtils.BUNDLE_CONTEXT_CLASS) return -1; 
/* 231 */               if (t2 == ClassUtils.BUNDLE_CONTEXT_CLASS) return 1; 
/* 232 */               if (ActivateMethod.this.isAnnotation(t1)) return ActivateMethod.this.isAnnotation(t2) ? 0 : -1; 
/* 233 */               if (ActivateMethod.this.isAnnotation(t2)) return 1; 
/* 234 */               if (t1 == ClassUtils.MAP_CLASS) return -1; 
/* 235 */               if (t2 == ClassUtils.MAP_CLASS) return 1; 
/* 236 */               if (t1 == int.class) return -1; 
/* 237 */               if (t2 == int.class) return 1; 
/* 238 */               if (t1 == Integer.class) return -1; 
/* 239 */               if (t2 == Integer.class) return 1; 
/* 240 */               return 0;
/*     */             } 
/* 242 */             return l1 - l2;
/*     */           }
/*     */         });
/*     */     
/* 246 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   private boolean isAnnotation(Class<?> t1) {
/* 251 */     return (t1.isAnnotation() || (this.m_supportsInterfaces && t1.isInterface() && t1 != ClassUtils.MAP_CLASS));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Object[] getParameters(Method method, ActivatorParameter rawParameter) {
/* 258 */     Class<?>[] parameterTypes = method.getParameterTypes();
/* 259 */     ActivatorParameter ap = rawParameter;
/* 260 */     Object[] param = new Object[parameterTypes.length];
/* 261 */     for (int i = 0; i < param.length; i++) {
/*     */       
/* 263 */       if (parameterTypes[i] == ClassUtils.COMPONENT_CONTEXT_CLASS) {
/*     */         
/* 265 */         param[i] = ap.getComponentContext();
/*     */       }
/* 267 */       else if (parameterTypes[i] == ClassUtils.BUNDLE_CONTEXT_CLASS) {
/*     */         
/* 269 */         param[i] = ap.getComponentContext().getBundleContext();
/*     */       }
/* 271 */       else if (parameterTypes[i] == ClassUtils.MAP_CLASS) {
/*     */ 
/*     */         
/* 274 */         param[i] = ap.getComponentContext().getProperties();
/*     */       }
/* 276 */       else if (parameterTypes[i] == ClassUtils.INTEGER_CLASS || parameterTypes[i] == int.class) {
/*     */         
/* 278 */         param[i] = Integer.valueOf(ap.getReason());
/*     */       }
/*     */       else {
/*     */         
/* 282 */         param[i] = Annotations.toObject(parameterTypes[i], ap
/* 283 */             .getComponentContext().getPropertiesMap(), ap
/* 284 */             .getComponentContext().getBundleContext().getBundle(), this.m_supportsInterfaces);
/*     */       } 
/*     */     } 
/*     */     
/* 288 */     return param;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String getMethodNamePrefix() {
/* 295 */     return "activate";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MethodResult invoke(Object componentInstance, ScrComponentContext componentContext, int reason, MethodResult methodCallFailureResult) {
/* 307 */     return invoke(componentInstance, new ActivatorParameter(componentContext, reason), methodCallFailureResult);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MethodResult invoke(Object componentInstance, ActivatorParameter rawParameter, MethodResult methodCallFailureResult) {
/* 315 */     if (methodExists(rawParameter.getComponentContext().getLogger()))
/*     */     {
/* 317 */       return super.invoke(componentInstance, rawParameter, methodCallFailureResult);
/*     */     }
/* 319 */     return null;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.apache.felix.scr-2.2.6.jar!\org\apache\felix\scr\impl\inject\methods\ActivateMethod.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */