/*    */ package org.apache.felix.scr.impl.manager;
/*    */ 
/*    */ import java.lang.management.ManagementFactory;
/*    */ import java.lang.management.ThreadInfo;
/*    */ import java.lang.management.ThreadMXBean;
/*    */ import java.util.concurrent.Callable;
/*    */ import org.codehaus.mojo.animal_sniffer.IgnoreJRERequirement;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ThreadDump
/*    */   implements Callable<String>
/*    */ {
/*    */   @IgnoreJRERequirement
/*    */   public String call() throws Exception {
/* 34 */     ThreadMXBean threadMXBean = ManagementFactory.getThreadMXBean();
/* 35 */     StringBuilder b = new StringBuilder("Thread dump\n");
/* 36 */     ThreadInfo[] infos = threadMXBean.dumpAllThreads(threadMXBean.isObjectMonitorUsageSupported(), threadMXBean.isSynchronizerUsageSupported());
/* 37 */     for (int i = 0; i < infos.length; i++) {
/*    */       
/* 39 */       ThreadInfo ti = infos[i];
/* 40 */       b.append("\n\nThreadId: ").append(ti.getThreadId()).append(" : name: ").append(ti.getThreadName()).append(" State: ").append(ti.getThreadState());
/* 41 */       b.append("\n  LockInfo: ").append(ti.getLockInfo()).append(" LockOwnerId: ").append(ti.getLockOwnerId()).append(" LockOwnerName: ").append(ti.getLockOwnerName());
/* 42 */       StackTraceElement[] stackTrace = ti.getStackTrace();
/* 43 */       for (int j = 0; j < stackTrace.length; j++)
/*    */       {
/* 45 */         b.append("\n  ").append(stackTrace[j]);
/*    */       }
/*    */     } 
/* 48 */     return b.toString();
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.apache.felix.scr-2.2.6.jar!\org\apache\felix\scr\impl\manager\ThreadDump.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */