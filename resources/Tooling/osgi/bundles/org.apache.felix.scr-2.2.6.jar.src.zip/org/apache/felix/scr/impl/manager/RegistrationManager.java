/*     */ package org.apache.felix.scr.impl.manager;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.concurrent.CountDownLatch;
/*     */ import java.util.concurrent.locks.Lock;
/*     */ import java.util.concurrent.locks.ReentrantLock;
/*     */ import org.apache.felix.scr.impl.logger.InternalLogger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ abstract class RegistrationManager<T>
/*     */ {
/*     */   enum RegState
/*     */   {
/*  32 */     unregistered, registered; }
/*     */   
/*     */   private static class RegStateWrapper {
/*  35 */     private final CountDownLatch latch = new CountDownLatch(1);
/*     */     
/*     */     private final RegistrationManager.RegState regState;
/*     */     
/*     */     RegStateWrapper(RegistrationManager.RegState regState) {
/*  40 */       this.regState = regState;
/*     */     }
/*     */ 
/*     */     
/*     */     public RegistrationManager.RegState getRegState() {
/*  45 */       return this.regState;
/*     */     }
/*     */ 
/*     */     
/*     */     public CountDownLatch getLatch() {
/*  50 */       return this.latch;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public int hashCode() {
/*  56 */       return this.regState.hashCode();
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean equals(Object other) {
/*  62 */       return (other instanceof RegStateWrapper && this.regState == ((RegStateWrapper)other).getRegState());
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public String toString() {
/*  68 */       return this.regState.toString();
/*     */     }
/*     */   }
/*     */   
/*  72 */   private final Lock registrationLock = new ReentrantLock();
/*     */   
/*  74 */   private final List<RegStateWrapper> opqueue = new ArrayList<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private volatile T m_serviceRegistration;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean changeRegistration(RegState desired, String[] services) {
/*     */     // Byte code:
/*     */     //   0: aconst_null
/*     */     //   1: astore_3
/*     */     //   2: aload_0
/*     */     //   3: getfield registrationLock : Ljava/util/concurrent/locks/Lock;
/*     */     //   6: invokeinterface lock : ()V
/*     */     //   11: aload_0
/*     */     //   12: getfield opqueue : Ljava/util/List;
/*     */     //   15: invokeinterface isEmpty : ()Z
/*     */     //   20: ifeq -> 208
/*     */     //   23: aload_1
/*     */     //   24: getstatic org/apache/felix/scr/impl/manager/RegistrationManager$RegState.unregistered : Lorg/apache/felix/scr/impl/manager/RegistrationManager$RegState;
/*     */     //   27: if_acmpne -> 34
/*     */     //   30: iconst_1
/*     */     //   31: goto -> 35
/*     */     //   34: iconst_0
/*     */     //   35: aload_0
/*     */     //   36: getfield m_serviceRegistration : Ljava/lang/Object;
/*     */     //   39: ifnonnull -> 46
/*     */     //   42: iconst_1
/*     */     //   43: goto -> 47
/*     */     //   46: iconst_0
/*     */     //   47: if_icmpne -> 423
/*     */     //   50: aload_0
/*     */     //   51: getstatic org/apache/felix/scr/impl/logger/InternalLogger$Level.DEBUG : Lorg/apache/felix/scr/impl/logger/InternalLogger$Level;
/*     */     //   54: ldc 'Already in desired state {0}'
/*     */     //   56: aconst_null
/*     */     //   57: iconst_1
/*     */     //   58: anewarray java/lang/Object
/*     */     //   61: dup
/*     */     //   62: iconst_0
/*     */     //   63: aload_1
/*     */     //   64: aastore
/*     */     //   65: invokevirtual log : (Lorg/apache/felix/scr/impl/logger/InternalLogger$Level;Ljava/lang/String;Ljava/lang/Throwable;[Ljava/lang/Object;)V
/*     */     //   68: iconst_0
/*     */     //   69: istore #4
/*     */     //   71: aload_0
/*     */     //   72: getfield registrationLock : Ljava/util/concurrent/locks/Lock;
/*     */     //   75: invokeinterface unlock : ()V
/*     */     //   80: aload_3
/*     */     //   81: ifnull -> 205
/*     */     //   84: aload_3
/*     */     //   85: invokevirtual getLatch : ()Ljava/util/concurrent/CountDownLatch;
/*     */     //   88: aload_0
/*     */     //   89: invokevirtual getTimeout : ()J
/*     */     //   92: getstatic java/util/concurrent/TimeUnit.MILLISECONDS : Ljava/util/concurrent/TimeUnit;
/*     */     //   95: invokevirtual await : (JLjava/util/concurrent/TimeUnit;)Z
/*     */     //   98: ifne -> 126
/*     */     //   101: aload_0
/*     */     //   102: getstatic org/apache/felix/scr/impl/logger/InternalLogger$Level.ERROR : Lorg/apache/felix/scr/impl/logger/InternalLogger$Level;
/*     */     //   105: ldc 'Timeout waiting for reg change to complete {0}'
/*     */     //   107: aconst_null
/*     */     //   108: iconst_1
/*     */     //   109: anewarray java/lang/Object
/*     */     //   112: dup
/*     */     //   113: iconst_0
/*     */     //   114: aload_3
/*     */     //   115: invokevirtual getRegState : ()Lorg/apache/felix/scr/impl/manager/RegistrationManager$RegState;
/*     */     //   118: aastore
/*     */     //   119: invokevirtual log : (Lorg/apache/felix/scr/impl/logger/InternalLogger$Level;Ljava/lang/String;Ljava/lang/Throwable;[Ljava/lang/Object;)V
/*     */     //   122: aload_0
/*     */     //   123: invokevirtual reportTimeout : ()V
/*     */     //   126: goto -> 205
/*     */     //   129: astore #5
/*     */     //   131: aload_3
/*     */     //   132: invokevirtual getLatch : ()Ljava/util/concurrent/CountDownLatch;
/*     */     //   135: aload_0
/*     */     //   136: invokevirtual getTimeout : ()J
/*     */     //   139: getstatic java/util/concurrent/TimeUnit.MILLISECONDS : Ljava/util/concurrent/TimeUnit;
/*     */     //   142: invokevirtual await : (JLjava/util/concurrent/TimeUnit;)Z
/*     */     //   145: ifne -> 173
/*     */     //   148: aload_0
/*     */     //   149: getstatic org/apache/felix/scr/impl/logger/InternalLogger$Level.ERROR : Lorg/apache/felix/scr/impl/logger/InternalLogger$Level;
/*     */     //   152: ldc 'Timeout waiting for reg change to complete {0}'
/*     */     //   154: aconst_null
/*     */     //   155: iconst_1
/*     */     //   156: anewarray java/lang/Object
/*     */     //   159: dup
/*     */     //   160: iconst_0
/*     */     //   161: aload_3
/*     */     //   162: invokevirtual getRegState : ()Lorg/apache/felix/scr/impl/manager/RegistrationManager$RegState;
/*     */     //   165: aastore
/*     */     //   166: invokevirtual log : (Lorg/apache/felix/scr/impl/logger/InternalLogger$Level;Ljava/lang/String;Ljava/lang/Throwable;[Ljava/lang/Object;)V
/*     */     //   169: aload_0
/*     */     //   170: invokevirtual reportTimeout : ()V
/*     */     //   173: goto -> 199
/*     */     //   176: astore #6
/*     */     //   178: aload_0
/*     */     //   179: getstatic org/apache/felix/scr/impl/logger/InternalLogger$Level.ERROR : Lorg/apache/felix/scr/impl/logger/InternalLogger$Level;
/*     */     //   182: ldc 'Interrupted twice waiting for reg change to complete {0}'
/*     */     //   184: aconst_null
/*     */     //   185: iconst_1
/*     */     //   186: anewarray java/lang/Object
/*     */     //   189: dup
/*     */     //   190: iconst_0
/*     */     //   191: aload_3
/*     */     //   192: invokevirtual getRegState : ()Lorg/apache/felix/scr/impl/manager/RegistrationManager$RegState;
/*     */     //   195: aastore
/*     */     //   196: invokevirtual log : (Lorg/apache/felix/scr/impl/logger/InternalLogger$Level;Ljava/lang/String;Ljava/lang/Throwable;[Ljava/lang/Object;)V
/*     */     //   199: invokestatic currentThread : ()Ljava/lang/Thread;
/*     */     //   202: invokevirtual interrupt : ()V
/*     */     //   205: iload #4
/*     */     //   207: ireturn
/*     */     //   208: aload_0
/*     */     //   209: getfield opqueue : Ljava/util/List;
/*     */     //   212: aload_0
/*     */     //   213: getfield opqueue : Ljava/util/List;
/*     */     //   216: invokeinterface size : ()I
/*     */     //   221: iconst_1
/*     */     //   222: isub
/*     */     //   223: invokeinterface get : (I)Ljava/lang/Object;
/*     */     //   228: checkcast org/apache/felix/scr/impl/manager/RegistrationManager$RegStateWrapper
/*     */     //   231: invokevirtual getRegState : ()Lorg/apache/felix/scr/impl/manager/RegistrationManager$RegState;
/*     */     //   234: aload_1
/*     */     //   235: if_acmpne -> 423
/*     */     //   238: aload_0
/*     */     //   239: getstatic org/apache/felix/scr/impl/logger/InternalLogger$Level.DEBUG : Lorg/apache/felix/scr/impl/logger/InternalLogger$Level;
/*     */     //   242: ldc 'Duplicate request on other thread: registration change queue {0}'
/*     */     //   244: aconst_null
/*     */     //   245: iconst_1
/*     */     //   246: anewarray java/lang/Object
/*     */     //   249: dup
/*     */     //   250: iconst_0
/*     */     //   251: aload_0
/*     */     //   252: getfield opqueue : Ljava/util/List;
/*     */     //   255: aastore
/*     */     //   256: invokevirtual log : (Lorg/apache/felix/scr/impl/logger/InternalLogger$Level;Ljava/lang/String;Ljava/lang/Throwable;[Ljava/lang/Object;)V
/*     */     //   259: aload_0
/*     */     //   260: getfield opqueue : Ljava/util/List;
/*     */     //   263: aload_0
/*     */     //   264: getfield opqueue : Ljava/util/List;
/*     */     //   267: invokeinterface size : ()I
/*     */     //   272: iconst_1
/*     */     //   273: isub
/*     */     //   274: invokeinterface get : (I)Ljava/lang/Object;
/*     */     //   279: checkcast org/apache/felix/scr/impl/manager/RegistrationManager$RegStateWrapper
/*     */     //   282: astore_3
/*     */     //   283: iconst_0
/*     */     //   284: istore #4
/*     */     //   286: aload_0
/*     */     //   287: getfield registrationLock : Ljava/util/concurrent/locks/Lock;
/*     */     //   290: invokeinterface unlock : ()V
/*     */     //   295: aload_3
/*     */     //   296: ifnull -> 420
/*     */     //   299: aload_3
/*     */     //   300: invokevirtual getLatch : ()Ljava/util/concurrent/CountDownLatch;
/*     */     //   303: aload_0
/*     */     //   304: invokevirtual getTimeout : ()J
/*     */     //   307: getstatic java/util/concurrent/TimeUnit.MILLISECONDS : Ljava/util/concurrent/TimeUnit;
/*     */     //   310: invokevirtual await : (JLjava/util/concurrent/TimeUnit;)Z
/*     */     //   313: ifne -> 341
/*     */     //   316: aload_0
/*     */     //   317: getstatic org/apache/felix/scr/impl/logger/InternalLogger$Level.ERROR : Lorg/apache/felix/scr/impl/logger/InternalLogger$Level;
/*     */     //   320: ldc 'Timeout waiting for reg change to complete {0}'
/*     */     //   322: aconst_null
/*     */     //   323: iconst_1
/*     */     //   324: anewarray java/lang/Object
/*     */     //   327: dup
/*     */     //   328: iconst_0
/*     */     //   329: aload_3
/*     */     //   330: invokevirtual getRegState : ()Lorg/apache/felix/scr/impl/manager/RegistrationManager$RegState;
/*     */     //   333: aastore
/*     */     //   334: invokevirtual log : (Lorg/apache/felix/scr/impl/logger/InternalLogger$Level;Ljava/lang/String;Ljava/lang/Throwable;[Ljava/lang/Object;)V
/*     */     //   337: aload_0
/*     */     //   338: invokevirtual reportTimeout : ()V
/*     */     //   341: goto -> 420
/*     */     //   344: astore #5
/*     */     //   346: aload_3
/*     */     //   347: invokevirtual getLatch : ()Ljava/util/concurrent/CountDownLatch;
/*     */     //   350: aload_0
/*     */     //   351: invokevirtual getTimeout : ()J
/*     */     //   354: getstatic java/util/concurrent/TimeUnit.MILLISECONDS : Ljava/util/concurrent/TimeUnit;
/*     */     //   357: invokevirtual await : (JLjava/util/concurrent/TimeUnit;)Z
/*     */     //   360: ifne -> 388
/*     */     //   363: aload_0
/*     */     //   364: getstatic org/apache/felix/scr/impl/logger/InternalLogger$Level.ERROR : Lorg/apache/felix/scr/impl/logger/InternalLogger$Level;
/*     */     //   367: ldc 'Timeout waiting for reg change to complete {0}'
/*     */     //   369: aconst_null
/*     */     //   370: iconst_1
/*     */     //   371: anewarray java/lang/Object
/*     */     //   374: dup
/*     */     //   375: iconst_0
/*     */     //   376: aload_3
/*     */     //   377: invokevirtual getRegState : ()Lorg/apache/felix/scr/impl/manager/RegistrationManager$RegState;
/*     */     //   380: aastore
/*     */     //   381: invokevirtual log : (Lorg/apache/felix/scr/impl/logger/InternalLogger$Level;Ljava/lang/String;Ljava/lang/Throwable;[Ljava/lang/Object;)V
/*     */     //   384: aload_0
/*     */     //   385: invokevirtual reportTimeout : ()V
/*     */     //   388: goto -> 414
/*     */     //   391: astore #6
/*     */     //   393: aload_0
/*     */     //   394: getstatic org/apache/felix/scr/impl/logger/InternalLogger$Level.ERROR : Lorg/apache/felix/scr/impl/logger/InternalLogger$Level;
/*     */     //   397: ldc 'Interrupted twice waiting for reg change to complete {0}'
/*     */     //   399: aconst_null
/*     */     //   400: iconst_1
/*     */     //   401: anewarray java/lang/Object
/*     */     //   404: dup
/*     */     //   405: iconst_0
/*     */     //   406: aload_3
/*     */     //   407: invokevirtual getRegState : ()Lorg/apache/felix/scr/impl/manager/RegistrationManager$RegState;
/*     */     //   410: aastore
/*     */     //   411: invokevirtual log : (Lorg/apache/felix/scr/impl/logger/InternalLogger$Level;Ljava/lang/String;Ljava/lang/Throwable;[Ljava/lang/Object;)V
/*     */     //   414: invokestatic currentThread : ()Ljava/lang/Thread;
/*     */     //   417: invokevirtual interrupt : ()V
/*     */     //   420: iload #4
/*     */     //   422: ireturn
/*     */     //   423: new org/apache/felix/scr/impl/manager/RegistrationManager$RegStateWrapper
/*     */     //   426: dup
/*     */     //   427: aload_1
/*     */     //   428: invokespecial <init> : (Lorg/apache/felix/scr/impl/manager/RegistrationManager$RegState;)V
/*     */     //   431: astore_3
/*     */     //   432: aload_0
/*     */     //   433: getfield opqueue : Ljava/util/List;
/*     */     //   436: aload_3
/*     */     //   437: invokeinterface add : (Ljava/lang/Object;)Z
/*     */     //   442: pop
/*     */     //   443: aload_0
/*     */     //   444: getfield opqueue : Ljava/util/List;
/*     */     //   447: invokeinterface size : ()I
/*     */     //   452: iconst_1
/*     */     //   453: if_icmple -> 617
/*     */     //   456: aload_0
/*     */     //   457: getstatic org/apache/felix/scr/impl/logger/InternalLogger$Level.DEBUG : Lorg/apache/felix/scr/impl/logger/InternalLogger$Level;
/*     */     //   460: ldc 'Allowing other thread to process request: registration change queue {0}'
/*     */     //   462: aconst_null
/*     */     //   463: iconst_1
/*     */     //   464: anewarray java/lang/Object
/*     */     //   467: dup
/*     */     //   468: iconst_0
/*     */     //   469: aload_0
/*     */     //   470: getfield opqueue : Ljava/util/List;
/*     */     //   473: aastore
/*     */     //   474: invokevirtual log : (Lorg/apache/felix/scr/impl/logger/InternalLogger$Level;Ljava/lang/String;Ljava/lang/Throwable;[Ljava/lang/Object;)V
/*     */     //   477: iconst_1
/*     */     //   478: istore #4
/*     */     //   480: aload_0
/*     */     //   481: getfield registrationLock : Ljava/util/concurrent/locks/Lock;
/*     */     //   484: invokeinterface unlock : ()V
/*     */     //   489: aload_3
/*     */     //   490: ifnull -> 614
/*     */     //   493: aload_3
/*     */     //   494: invokevirtual getLatch : ()Ljava/util/concurrent/CountDownLatch;
/*     */     //   497: aload_0
/*     */     //   498: invokevirtual getTimeout : ()J
/*     */     //   501: getstatic java/util/concurrent/TimeUnit.MILLISECONDS : Ljava/util/concurrent/TimeUnit;
/*     */     //   504: invokevirtual await : (JLjava/util/concurrent/TimeUnit;)Z
/*     */     //   507: ifne -> 535
/*     */     //   510: aload_0
/*     */     //   511: getstatic org/apache/felix/scr/impl/logger/InternalLogger$Level.ERROR : Lorg/apache/felix/scr/impl/logger/InternalLogger$Level;
/*     */     //   514: ldc 'Timeout waiting for reg change to complete {0}'
/*     */     //   516: aconst_null
/*     */     //   517: iconst_1
/*     */     //   518: anewarray java/lang/Object
/*     */     //   521: dup
/*     */     //   522: iconst_0
/*     */     //   523: aload_3
/*     */     //   524: invokevirtual getRegState : ()Lorg/apache/felix/scr/impl/manager/RegistrationManager$RegState;
/*     */     //   527: aastore
/*     */     //   528: invokevirtual log : (Lorg/apache/felix/scr/impl/logger/InternalLogger$Level;Ljava/lang/String;Ljava/lang/Throwable;[Ljava/lang/Object;)V
/*     */     //   531: aload_0
/*     */     //   532: invokevirtual reportTimeout : ()V
/*     */     //   535: goto -> 614
/*     */     //   538: astore #5
/*     */     //   540: aload_3
/*     */     //   541: invokevirtual getLatch : ()Ljava/util/concurrent/CountDownLatch;
/*     */     //   544: aload_0
/*     */     //   545: invokevirtual getTimeout : ()J
/*     */     //   548: getstatic java/util/concurrent/TimeUnit.MILLISECONDS : Ljava/util/concurrent/TimeUnit;
/*     */     //   551: invokevirtual await : (JLjava/util/concurrent/TimeUnit;)Z
/*     */     //   554: ifne -> 582
/*     */     //   557: aload_0
/*     */     //   558: getstatic org/apache/felix/scr/impl/logger/InternalLogger$Level.ERROR : Lorg/apache/felix/scr/impl/logger/InternalLogger$Level;
/*     */     //   561: ldc 'Timeout waiting for reg change to complete {0}'
/*     */     //   563: aconst_null
/*     */     //   564: iconst_1
/*     */     //   565: anewarray java/lang/Object
/*     */     //   568: dup
/*     */     //   569: iconst_0
/*     */     //   570: aload_3
/*     */     //   571: invokevirtual getRegState : ()Lorg/apache/felix/scr/impl/manager/RegistrationManager$RegState;
/*     */     //   574: aastore
/*     */     //   575: invokevirtual log : (Lorg/apache/felix/scr/impl/logger/InternalLogger$Level;Ljava/lang/String;Ljava/lang/Throwable;[Ljava/lang/Object;)V
/*     */     //   578: aload_0
/*     */     //   579: invokevirtual reportTimeout : ()V
/*     */     //   582: goto -> 608
/*     */     //   585: astore #6
/*     */     //   587: aload_0
/*     */     //   588: getstatic org/apache/felix/scr/impl/logger/InternalLogger$Level.ERROR : Lorg/apache/felix/scr/impl/logger/InternalLogger$Level;
/*     */     //   591: ldc 'Interrupted twice waiting for reg change to complete {0}'
/*     */     //   593: aconst_null
/*     */     //   594: iconst_1
/*     */     //   595: anewarray java/lang/Object
/*     */     //   598: dup
/*     */     //   599: iconst_0
/*     */     //   600: aload_3
/*     */     //   601: invokevirtual getRegState : ()Lorg/apache/felix/scr/impl/manager/RegistrationManager$RegState;
/*     */     //   604: aastore
/*     */     //   605: invokevirtual log : (Lorg/apache/felix/scr/impl/logger/InternalLogger$Level;Ljava/lang/String;Ljava/lang/Throwable;[Ljava/lang/Object;)V
/*     */     //   608: invokestatic currentThread : ()Ljava/lang/Thread;
/*     */     //   611: invokevirtual interrupt : ()V
/*     */     //   614: iload #4
/*     */     //   616: ireturn
/*     */     //   617: aload_0
/*     */     //   618: getstatic org/apache/felix/scr/impl/logger/InternalLogger$Level.DEBUG : Lorg/apache/felix/scr/impl/logger/InternalLogger$Level;
/*     */     //   621: ldc 'registration change queue {0}'
/*     */     //   623: aconst_null
/*     */     //   624: iconst_1
/*     */     //   625: anewarray java/lang/Object
/*     */     //   628: dup
/*     */     //   629: iconst_0
/*     */     //   630: aload_0
/*     */     //   631: getfield opqueue : Ljava/util/List;
/*     */     //   634: aastore
/*     */     //   635: invokevirtual log : (Lorg/apache/felix/scr/impl/logger/InternalLogger$Level;Ljava/lang/String;Ljava/lang/Throwable;[Ljava/lang/Object;)V
/*     */     //   638: aload_0
/*     */     //   639: getfield opqueue : Ljava/util/List;
/*     */     //   642: iconst_0
/*     */     //   643: invokeinterface get : (I)Ljava/lang/Object;
/*     */     //   648: checkcast org/apache/felix/scr/impl/manager/RegistrationManager$RegStateWrapper
/*     */     //   651: astore #4
/*     */     //   653: aload_0
/*     */     //   654: getfield m_serviceRegistration : Ljava/lang/Object;
/*     */     //   657: astore #5
/*     */     //   659: aload #4
/*     */     //   661: invokevirtual getRegState : ()Lorg/apache/felix/scr/impl/manager/RegistrationManager$RegState;
/*     */     //   664: getstatic org/apache/felix/scr/impl/manager/RegistrationManager$RegState.unregistered : Lorg/apache/felix/scr/impl/manager/RegistrationManager$RegState;
/*     */     //   667: if_acmpne -> 675
/*     */     //   670: aload_0
/*     */     //   671: aconst_null
/*     */     //   672: putfield m_serviceRegistration : Ljava/lang/Object;
/*     */     //   675: aload_0
/*     */     //   676: getfield registrationLock : Ljava/util/concurrent/locks/Lock;
/*     */     //   679: invokeinterface unlock : ()V
/*     */     //   684: aload #4
/*     */     //   686: invokevirtual getRegState : ()Lorg/apache/felix/scr/impl/manager/RegistrationManager$RegState;
/*     */     //   689: getstatic org/apache/felix/scr/impl/manager/RegistrationManager$RegState.registered : Lorg/apache/felix/scr/impl/manager/RegistrationManager$RegState;
/*     */     //   692: if_acmpne -> 705
/*     */     //   695: aload_0
/*     */     //   696: aload_2
/*     */     //   697: invokevirtual register : ([Ljava/lang/String;)Ljava/lang/Object;
/*     */     //   700: astore #5
/*     */     //   702: goto -> 741
/*     */     //   705: aload #5
/*     */     //   707: ifnull -> 719
/*     */     //   710: aload_0
/*     */     //   711: aload #5
/*     */     //   713: invokevirtual unregister : (Ljava/lang/Object;)V
/*     */     //   716: goto -> 741
/*     */     //   719: aload_0
/*     */     //   720: getstatic org/apache/felix/scr/impl/logger/InternalLogger$Level.ERROR : Lorg/apache/felix/scr/impl/logger/InternalLogger$Level;
/*     */     //   723: ldc 'Unexpected unregistration request with no registration present'
/*     */     //   725: new java/lang/Exception
/*     */     //   728: dup
/*     */     //   729: ldc 'Stack trace'
/*     */     //   731: invokespecial <init> : (Ljava/lang/String;)V
/*     */     //   734: iconst_0
/*     */     //   735: anewarray java/lang/Object
/*     */     //   738: invokevirtual log : (Lorg/apache/felix/scr/impl/logger/InternalLogger$Level;Ljava/lang/String;Ljava/lang/Throwable;[Ljava/lang/Object;)V
/*     */     //   741: aload_0
/*     */     //   742: getfield registrationLock : Ljava/util/concurrent/locks/Lock;
/*     */     //   745: invokeinterface lock : ()V
/*     */     //   750: aload_0
/*     */     //   751: getfield opqueue : Ljava/util/List;
/*     */     //   754: iconst_0
/*     */     //   755: invokeinterface remove : (I)Ljava/lang/Object;
/*     */     //   760: pop
/*     */     //   761: aload #4
/*     */     //   763: invokevirtual getRegState : ()Lorg/apache/felix/scr/impl/manager/RegistrationManager$RegState;
/*     */     //   766: getstatic org/apache/felix/scr/impl/manager/RegistrationManager$RegState.registered : Lorg/apache/felix/scr/impl/manager/RegistrationManager$RegState;
/*     */     //   769: if_acmpne -> 786
/*     */     //   772: aload_0
/*     */     //   773: aload #5
/*     */     //   775: putfield m_serviceRegistration : Ljava/lang/Object;
/*     */     //   778: aload_0
/*     */     //   779: aload_0
/*     */     //   780: getfield m_serviceRegistration : Ljava/lang/Object;
/*     */     //   783: invokevirtual postRegister : (Ljava/lang/Object;)V
/*     */     //   786: aload #4
/*     */     //   788: invokevirtual getLatch : ()Ljava/util/concurrent/CountDownLatch;
/*     */     //   791: invokevirtual countDown : ()V
/*     */     //   794: goto -> 855
/*     */     //   797: astore #7
/*     */     //   799: aload_0
/*     */     //   800: getfield registrationLock : Ljava/util/concurrent/locks/Lock;
/*     */     //   803: invokeinterface lock : ()V
/*     */     //   808: aload_0
/*     */     //   809: getfield opqueue : Ljava/util/List;
/*     */     //   812: iconst_0
/*     */     //   813: invokeinterface remove : (I)Ljava/lang/Object;
/*     */     //   818: pop
/*     */     //   819: aload #4
/*     */     //   821: invokevirtual getRegState : ()Lorg/apache/felix/scr/impl/manager/RegistrationManager$RegState;
/*     */     //   824: getstatic org/apache/felix/scr/impl/manager/RegistrationManager$RegState.registered : Lorg/apache/felix/scr/impl/manager/RegistrationManager$RegState;
/*     */     //   827: if_acmpne -> 844
/*     */     //   830: aload_0
/*     */     //   831: aload #5
/*     */     //   833: putfield m_serviceRegistration : Ljava/lang/Object;
/*     */     //   836: aload_0
/*     */     //   837: aload_0
/*     */     //   838: getfield m_serviceRegistration : Ljava/lang/Object;
/*     */     //   841: invokevirtual postRegister : (Ljava/lang/Object;)V
/*     */     //   844: aload #4
/*     */     //   846: invokevirtual getLatch : ()Ljava/util/concurrent/CountDownLatch;
/*     */     //   849: invokevirtual countDown : ()V
/*     */     //   852: aload #7
/*     */     //   854: athrow
/*     */     //   855: aload_0
/*     */     //   856: getfield opqueue : Ljava/util/List;
/*     */     //   859: invokeinterface isEmpty : ()Z
/*     */     //   864: ifeq -> 617
/*     */     //   867: iconst_1
/*     */     //   868: istore #4
/*     */     //   870: aload_0
/*     */     //   871: getfield registrationLock : Ljava/util/concurrent/locks/Lock;
/*     */     //   874: invokeinterface unlock : ()V
/*     */     //   879: aload_3
/*     */     //   880: ifnull -> 1004
/*     */     //   883: aload_3
/*     */     //   884: invokevirtual getLatch : ()Ljava/util/concurrent/CountDownLatch;
/*     */     //   887: aload_0
/*     */     //   888: invokevirtual getTimeout : ()J
/*     */     //   891: getstatic java/util/concurrent/TimeUnit.MILLISECONDS : Ljava/util/concurrent/TimeUnit;
/*     */     //   894: invokevirtual await : (JLjava/util/concurrent/TimeUnit;)Z
/*     */     //   897: ifne -> 925
/*     */     //   900: aload_0
/*     */     //   901: getstatic org/apache/felix/scr/impl/logger/InternalLogger$Level.ERROR : Lorg/apache/felix/scr/impl/logger/InternalLogger$Level;
/*     */     //   904: ldc 'Timeout waiting for reg change to complete {0}'
/*     */     //   906: aconst_null
/*     */     //   907: iconst_1
/*     */     //   908: anewarray java/lang/Object
/*     */     //   911: dup
/*     */     //   912: iconst_0
/*     */     //   913: aload_3
/*     */     //   914: invokevirtual getRegState : ()Lorg/apache/felix/scr/impl/manager/RegistrationManager$RegState;
/*     */     //   917: aastore
/*     */     //   918: invokevirtual log : (Lorg/apache/felix/scr/impl/logger/InternalLogger$Level;Ljava/lang/String;Ljava/lang/Throwable;[Ljava/lang/Object;)V
/*     */     //   921: aload_0
/*     */     //   922: invokevirtual reportTimeout : ()V
/*     */     //   925: goto -> 1004
/*     */     //   928: astore #5
/*     */     //   930: aload_3
/*     */     //   931: invokevirtual getLatch : ()Ljava/util/concurrent/CountDownLatch;
/*     */     //   934: aload_0
/*     */     //   935: invokevirtual getTimeout : ()J
/*     */     //   938: getstatic java/util/concurrent/TimeUnit.MILLISECONDS : Ljava/util/concurrent/TimeUnit;
/*     */     //   941: invokevirtual await : (JLjava/util/concurrent/TimeUnit;)Z
/*     */     //   944: ifne -> 972
/*     */     //   947: aload_0
/*     */     //   948: getstatic org/apache/felix/scr/impl/logger/InternalLogger$Level.ERROR : Lorg/apache/felix/scr/impl/logger/InternalLogger$Level;
/*     */     //   951: ldc 'Timeout waiting for reg change to complete {0}'
/*     */     //   953: aconst_null
/*     */     //   954: iconst_1
/*     */     //   955: anewarray java/lang/Object
/*     */     //   958: dup
/*     */     //   959: iconst_0
/*     */     //   960: aload_3
/*     */     //   961: invokevirtual getRegState : ()Lorg/apache/felix/scr/impl/manager/RegistrationManager$RegState;
/*     */     //   964: aastore
/*     */     //   965: invokevirtual log : (Lorg/apache/felix/scr/impl/logger/InternalLogger$Level;Ljava/lang/String;Ljava/lang/Throwable;[Ljava/lang/Object;)V
/*     */     //   968: aload_0
/*     */     //   969: invokevirtual reportTimeout : ()V
/*     */     //   972: goto -> 998
/*     */     //   975: astore #6
/*     */     //   977: aload_0
/*     */     //   978: getstatic org/apache/felix/scr/impl/logger/InternalLogger$Level.ERROR : Lorg/apache/felix/scr/impl/logger/InternalLogger$Level;
/*     */     //   981: ldc 'Interrupted twice waiting for reg change to complete {0}'
/*     */     //   983: aconst_null
/*     */     //   984: iconst_1
/*     */     //   985: anewarray java/lang/Object
/*     */     //   988: dup
/*     */     //   989: iconst_0
/*     */     //   990: aload_3
/*     */     //   991: invokevirtual getRegState : ()Lorg/apache/felix/scr/impl/manager/RegistrationManager$RegState;
/*     */     //   994: aastore
/*     */     //   995: invokevirtual log : (Lorg/apache/felix/scr/impl/logger/InternalLogger$Level;Ljava/lang/String;Ljava/lang/Throwable;[Ljava/lang/Object;)V
/*     */     //   998: invokestatic currentThread : ()Ljava/lang/Thread;
/*     */     //   1001: invokevirtual interrupt : ()V
/*     */     //   1004: iload #4
/*     */     //   1006: ireturn
/*     */     //   1007: astore #8
/*     */     //   1009: aload_0
/*     */     //   1010: getfield registrationLock : Ljava/util/concurrent/locks/Lock;
/*     */     //   1013: invokeinterface unlock : ()V
/*     */     //   1018: aload_3
/*     */     //   1019: ifnull -> 1143
/*     */     //   1022: aload_3
/*     */     //   1023: invokevirtual getLatch : ()Ljava/util/concurrent/CountDownLatch;
/*     */     //   1026: aload_0
/*     */     //   1027: invokevirtual getTimeout : ()J
/*     */     //   1030: getstatic java/util/concurrent/TimeUnit.MILLISECONDS : Ljava/util/concurrent/TimeUnit;
/*     */     //   1033: invokevirtual await : (JLjava/util/concurrent/TimeUnit;)Z
/*     */     //   1036: ifne -> 1064
/*     */     //   1039: aload_0
/*     */     //   1040: getstatic org/apache/felix/scr/impl/logger/InternalLogger$Level.ERROR : Lorg/apache/felix/scr/impl/logger/InternalLogger$Level;
/*     */     //   1043: ldc 'Timeout waiting for reg change to complete {0}'
/*     */     //   1045: aconst_null
/*     */     //   1046: iconst_1
/*     */     //   1047: anewarray java/lang/Object
/*     */     //   1050: dup
/*     */     //   1051: iconst_0
/*     */     //   1052: aload_3
/*     */     //   1053: invokevirtual getRegState : ()Lorg/apache/felix/scr/impl/manager/RegistrationManager$RegState;
/*     */     //   1056: aastore
/*     */     //   1057: invokevirtual log : (Lorg/apache/felix/scr/impl/logger/InternalLogger$Level;Ljava/lang/String;Ljava/lang/Throwable;[Ljava/lang/Object;)V
/*     */     //   1060: aload_0
/*     */     //   1061: invokevirtual reportTimeout : ()V
/*     */     //   1064: goto -> 1143
/*     */     //   1067: astore #9
/*     */     //   1069: aload_3
/*     */     //   1070: invokevirtual getLatch : ()Ljava/util/concurrent/CountDownLatch;
/*     */     //   1073: aload_0
/*     */     //   1074: invokevirtual getTimeout : ()J
/*     */     //   1077: getstatic java/util/concurrent/TimeUnit.MILLISECONDS : Ljava/util/concurrent/TimeUnit;
/*     */     //   1080: invokevirtual await : (JLjava/util/concurrent/TimeUnit;)Z
/*     */     //   1083: ifne -> 1111
/*     */     //   1086: aload_0
/*     */     //   1087: getstatic org/apache/felix/scr/impl/logger/InternalLogger$Level.ERROR : Lorg/apache/felix/scr/impl/logger/InternalLogger$Level;
/*     */     //   1090: ldc 'Timeout waiting for reg change to complete {0}'
/*     */     //   1092: aconst_null
/*     */     //   1093: iconst_1
/*     */     //   1094: anewarray java/lang/Object
/*     */     //   1097: dup
/*     */     //   1098: iconst_0
/*     */     //   1099: aload_3
/*     */     //   1100: invokevirtual getRegState : ()Lorg/apache/felix/scr/impl/manager/RegistrationManager$RegState;
/*     */     //   1103: aastore
/*     */     //   1104: invokevirtual log : (Lorg/apache/felix/scr/impl/logger/InternalLogger$Level;Ljava/lang/String;Ljava/lang/Throwable;[Ljava/lang/Object;)V
/*     */     //   1107: aload_0
/*     */     //   1108: invokevirtual reportTimeout : ()V
/*     */     //   1111: goto -> 1137
/*     */     //   1114: astore #10
/*     */     //   1116: aload_0
/*     */     //   1117: getstatic org/apache/felix/scr/impl/logger/InternalLogger$Level.ERROR : Lorg/apache/felix/scr/impl/logger/InternalLogger$Level;
/*     */     //   1120: ldc 'Interrupted twice waiting for reg change to complete {0}'
/*     */     //   1122: aconst_null
/*     */     //   1123: iconst_1
/*     */     //   1124: anewarray java/lang/Object
/*     */     //   1127: dup
/*     */     //   1128: iconst_0
/*     */     //   1129: aload_3
/*     */     //   1130: invokevirtual getRegState : ()Lorg/apache/felix/scr/impl/manager/RegistrationManager$RegState;
/*     */     //   1133: aastore
/*     */     //   1134: invokevirtual log : (Lorg/apache/felix/scr/impl/logger/InternalLogger$Level;Ljava/lang/String;Ljava/lang/Throwable;[Ljava/lang/Object;)V
/*     */     //   1137: invokestatic currentThread : ()Ljava/lang/Thread;
/*     */     //   1140: invokevirtual interrupt : ()V
/*     */     //   1143: aload #8
/*     */     //   1145: athrow
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #87	-> 0
/*     */     //   #88	-> 2
/*     */     //   #91	-> 11
/*     */     //   #93	-> 23
/*     */     //   #95	-> 50
/*     */     //   #96	-> 68
/*     */     //   #168	-> 71
/*     */     //   #169	-> 80
/*     */     //   #173	-> 84
/*     */     //   #175	-> 101
/*     */     //   #177	-> 115
/*     */     //   #175	-> 119
/*     */     //   #178	-> 122
/*     */     //   #200	-> 126
/*     */     //   #181	-> 129
/*     */     //   #185	-> 131
/*     */     //   #187	-> 148
/*     */     //   #189	-> 162
/*     */     //   #187	-> 166
/*     */     //   #190	-> 169
/*     */     //   #198	-> 173
/*     */     //   #193	-> 176
/*     */     //   #195	-> 178
/*     */     //   #197	-> 192
/*     */     //   #195	-> 196
/*     */     //   #199	-> 199
/*     */     //   #96	-> 205
/*     */     //   #99	-> 208
/*     */     //   #101	-> 238
/*     */     //   #104	-> 259
/*     */     //   #105	-> 283
/*     */     //   #168	-> 286
/*     */     //   #169	-> 295
/*     */     //   #173	-> 299
/*     */     //   #175	-> 316
/*     */     //   #177	-> 330
/*     */     //   #175	-> 334
/*     */     //   #178	-> 337
/*     */     //   #200	-> 341
/*     */     //   #181	-> 344
/*     */     //   #185	-> 346
/*     */     //   #187	-> 363
/*     */     //   #189	-> 377
/*     */     //   #187	-> 381
/*     */     //   #190	-> 384
/*     */     //   #198	-> 388
/*     */     //   #193	-> 391
/*     */     //   #195	-> 393
/*     */     //   #197	-> 407
/*     */     //   #195	-> 411
/*     */     //   #199	-> 414
/*     */     //   #105	-> 420
/*     */     //   #107	-> 423
/*     */     //   #108	-> 432
/*     */     //   #109	-> 443
/*     */     //   #111	-> 456
/*     */     //   #114	-> 477
/*     */     //   #168	-> 480
/*     */     //   #169	-> 489
/*     */     //   #173	-> 493
/*     */     //   #175	-> 510
/*     */     //   #177	-> 524
/*     */     //   #175	-> 528
/*     */     //   #178	-> 531
/*     */     //   #200	-> 535
/*     */     //   #181	-> 538
/*     */     //   #185	-> 540
/*     */     //   #187	-> 557
/*     */     //   #189	-> 571
/*     */     //   #187	-> 575
/*     */     //   #190	-> 578
/*     */     //   #198	-> 582
/*     */     //   #193	-> 585
/*     */     //   #195	-> 587
/*     */     //   #197	-> 601
/*     */     //   #195	-> 605
/*     */     //   #199	-> 608
/*     */     //   #114	-> 614
/*     */     //   #119	-> 617
/*     */     //   #121	-> 638
/*     */     //   #122	-> 653
/*     */     //   #123	-> 659
/*     */     //   #125	-> 670
/*     */     //   #128	-> 675
/*     */     //   #131	-> 684
/*     */     //   #133	-> 695
/*     */     //   #138	-> 705
/*     */     //   #140	-> 710
/*     */     //   #144	-> 719
/*     */     //   #153	-> 741
/*     */     //   #154	-> 750
/*     */     //   #155	-> 761
/*     */     //   #157	-> 772
/*     */     //   #158	-> 778
/*     */     //   #160	-> 786
/*     */     //   #161	-> 794
/*     */     //   #153	-> 797
/*     */     //   #154	-> 808
/*     */     //   #155	-> 819
/*     */     //   #157	-> 830
/*     */     //   #158	-> 836
/*     */     //   #160	-> 844
/*     */     //   #161	-> 852
/*     */     //   #163	-> 855
/*     */     //   #164	-> 867
/*     */     //   #168	-> 870
/*     */     //   #169	-> 879
/*     */     //   #173	-> 883
/*     */     //   #175	-> 900
/*     */     //   #177	-> 914
/*     */     //   #175	-> 918
/*     */     //   #178	-> 921
/*     */     //   #200	-> 925
/*     */     //   #181	-> 928
/*     */     //   #185	-> 930
/*     */     //   #187	-> 947
/*     */     //   #189	-> 961
/*     */     //   #187	-> 965
/*     */     //   #190	-> 968
/*     */     //   #198	-> 972
/*     */     //   #193	-> 975
/*     */     //   #195	-> 977
/*     */     //   #197	-> 991
/*     */     //   #195	-> 995
/*     */     //   #199	-> 998
/*     */     //   #164	-> 1004
/*     */     //   #168	-> 1007
/*     */     //   #169	-> 1018
/*     */     //   #173	-> 1022
/*     */     //   #175	-> 1039
/*     */     //   #177	-> 1053
/*     */     //   #175	-> 1057
/*     */     //   #178	-> 1060
/*     */     //   #200	-> 1064
/*     */     //   #181	-> 1067
/*     */     //   #185	-> 1069
/*     */     //   #187	-> 1086
/*     */     //   #189	-> 1100
/*     */     //   #187	-> 1104
/*     */     //   #190	-> 1107
/*     */     //   #198	-> 1111
/*     */     //   #193	-> 1114
/*     */     //   #195	-> 1116
/*     */     //   #197	-> 1130
/*     */     //   #195	-> 1134
/*     */     //   #199	-> 1137
/*     */     //   #202	-> 1143
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	descriptor
/*     */     //   178	21	6	e1	Ljava/lang/InterruptedException;
/*     */     //   131	74	5	e	Ljava/lang/InterruptedException;
/*     */     //   393	21	6	e1	Ljava/lang/InterruptedException;
/*     */     //   346	74	5	e	Ljava/lang/InterruptedException;
/*     */     //   587	21	6	e1	Ljava/lang/InterruptedException;
/*     */     //   540	74	5	e	Ljava/lang/InterruptedException;
/*     */     //   653	202	4	next	Lorg/apache/felix/scr/impl/manager/RegistrationManager$RegStateWrapper;
/*     */     //   659	196	5	serviceRegistration	Ljava/lang/Object;
/*     */     //   977	21	6	e1	Ljava/lang/InterruptedException;
/*     */     //   930	74	5	e	Ljava/lang/InterruptedException;
/*     */     //   1116	21	10	e1	Ljava/lang/InterruptedException;
/*     */     //   1069	74	9	e	Ljava/lang/InterruptedException;
/*     */     //   0	1146	0	this	Lorg/apache/felix/scr/impl/manager/RegistrationManager;
/*     */     //   0	1146	1	desired	Lorg/apache/felix/scr/impl/manager/RegistrationManager$RegState;
/*     */     //   0	1146	2	services	[Ljava/lang/String;
/*     */     //   2	1144	3	rsw	Lorg/apache/felix/scr/impl/manager/RegistrationManager$RegStateWrapper;
/*     */     // Local variable type table:
/*     */     //   start	length	slot	name	signature
/*     */     //   659	196	5	serviceRegistration	TT;
/*     */     //   0	1146	0	this	Lorg/apache/felix/scr/impl/manager/RegistrationManager<TT;>;
/*     */     // Exception table:
/*     */     //   from	to	target	type
/*     */     //   11	71	1007	finally
/*     */     //   84	126	129	java/lang/InterruptedException
/*     */     //   131	173	176	java/lang/InterruptedException
/*     */     //   208	286	1007	finally
/*     */     //   299	341	344	java/lang/InterruptedException
/*     */     //   346	388	391	java/lang/InterruptedException
/*     */     //   423	480	1007	finally
/*     */     //   493	535	538	java/lang/InterruptedException
/*     */     //   540	582	585	java/lang/InterruptedException
/*     */     //   617	870	1007	finally
/*     */     //   684	741	797	finally
/*     */     //   797	799	797	finally
/*     */     //   883	925	928	java/lang/InterruptedException
/*     */     //   930	972	975	java/lang/InterruptedException
/*     */     //   1007	1009	1007	finally
/*     */     //   1022	1064	1067	java/lang/InterruptedException
/*     */     //   1069	1111	1114	java/lang/InterruptedException
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   abstract T register(String[] paramArrayOfString);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   abstract void postRegister(T paramT);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   abstract void unregister(T paramT);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   abstract void log(InternalLogger.Level paramLevel, String paramString, Throwable paramThrowable, Object... paramVarArgs);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   abstract long getTimeout();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   abstract void reportTimeout();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   T getServiceRegistration() {
/* 220 */     return this.m_serviceRegistration;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.apache.felix.scr-2.2.6.jar!\org\apache\felix\scr\impl\manager\RegistrationManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */