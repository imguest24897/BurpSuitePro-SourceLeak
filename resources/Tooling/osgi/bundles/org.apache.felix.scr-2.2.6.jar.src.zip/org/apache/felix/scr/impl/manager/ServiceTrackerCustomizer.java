package org.apache.felix.scr.impl.manager;

import org.osgi.framework.ServiceReference;

public interface ServiceTrackerCustomizer<S, T, U extends org.osgi.framework.ServiceEvent> {
  T addingService(ServiceReference<S> paramServiceReference);
  
  void addedService(ServiceReference<S> paramServiceReference, T paramT, int paramInt1, int paramInt2, U paramU);
  
  void modifiedService(ServiceReference<S> paramServiceReference, T paramT, int paramInt, U paramU);
  
  void removedService(ServiceReference<S> paramServiceReference, T paramT, int paramInt, U paramU);
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.apache.felix.scr-2.2.6.jar!\org\apache\felix\scr\impl\manager\ServiceTrackerCustomizer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */