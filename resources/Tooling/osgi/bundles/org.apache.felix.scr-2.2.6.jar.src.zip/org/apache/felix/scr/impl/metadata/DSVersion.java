/*    */ package org.apache.felix.scr.impl.metadata;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum DSVersion
/*    */ {
/* 23 */   DSnone(-1),
/* 24 */   DS10(0),
/* 25 */   DS11(1),
/* 26 */   DS11Felix(2),
/* 27 */   DS12(3),
/* 28 */   DS12Felix(4),
/* 29 */   DS13(5),
/* 30 */   DS14(6),
/* 31 */   DS15(7);
/*    */   
/*    */   private final int version;
/*    */ 
/*    */   
/*    */   DSVersion(int version) {
/* 37 */     this.version = version;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean isDS10() {
/* 42 */     return (this.version >= DS10.version);
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean isDS11() {
/* 47 */     return (this.version >= DS11.version);
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean isDS12() {
/* 52 */     return (this.version >= DS12.version);
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean isDS13() {
/* 57 */     return (this.version >= DS13.version);
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean isDS14() {
/* 62 */     return (this.version >= DS14.version);
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean isDS15() {
/* 67 */     return (this.version >= DS15.version);
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.apache.felix.scr-2.2.6.jar!\org\apache\felix\scr\impl\metadata\DSVersion.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */