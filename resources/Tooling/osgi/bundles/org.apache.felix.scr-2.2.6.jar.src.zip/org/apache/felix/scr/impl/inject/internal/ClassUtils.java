/*     */ package org.apache.felix.scr.impl.inject.internal;
/*     */ 
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Optional;
/*     */ import org.apache.felix.scr.impl.logger.ComponentLogger;
/*     */ import org.apache.felix.scr.impl.logger.InternalLogger;
/*     */ import org.osgi.framework.Bundle;
/*     */ import org.osgi.framework.BundleContext;
/*     */ import org.osgi.framework.ServiceReference;
/*     */ import org.osgi.framework.wiring.BundleCapability;
/*     */ import org.osgi.framework.wiring.BundleWire;
/*     */ import org.osgi.framework.wiring.BundleWiring;
/*     */ import org.osgi.framework.wiring.FrameworkWiring;
/*     */ import org.osgi.resource.Requirement;
/*     */ import org.osgi.resource.Resource;
/*     */ import org.osgi.service.component.ComponentContext;
/*     */ import org.osgi.service.component.ComponentServiceObjects;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ClassUtils
/*     */ {
/*  53 */   private static final Class<?> OBJECT_CLASS = Object.class;
/*     */   
/*  55 */   public static final Class<?> SERVICE_REFERENCE_CLASS = ServiceReference.class;
/*     */   
/*  57 */   public static final Class<?> COMPONENTS_SERVICE_OBJECTS_CLASS = ComponentServiceObjects.class;
/*     */   
/*  59 */   public static final Class<?> MAP_CLASS = Map.class;
/*  60 */   public static final Class<?> MAP_ENTRY_CLASS = Map.Entry.class;
/*     */   
/*  62 */   public static final Class<?> COLLECTION_CLASS = Collection.class;
/*  63 */   public static final Class<?> LIST_CLASS = List.class;
/*     */   
/*  65 */   public static final Class<?> OPTIONAL_CLASS = Optional.class;
/*     */   
/*  67 */   public static final Class<?> COMPONENT_CONTEXT_CLASS = ComponentContext.class;
/*  68 */   public static final Class<?> BUNDLE_CONTEXT_CLASS = BundleContext.class;
/*  69 */   public static final Class<?> INTEGER_CLASS = Integer.class;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final String LOGGER_CLASS = "org.osgi.service.log.Logger";
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final String FORMATTER_LOGGER_CLASS = "org.osgi.service.log.FormatterLogger";
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final String LOGGER_FACTORY_CLASS = "org.osgi.service.log.LoggerFactory";
/*     */ 
/*     */ 
/*     */   
/*     */   public static FrameworkWiring m_fwkWiring;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Class<?> getClassFromComponentClassLoader(Class<?> componentClass, String className, ComponentLogger logger) {
/*  94 */     if (logger.isLogEnabled(InternalLogger.Level.DEBUG))
/*     */     {
/*  96 */       logger.log(InternalLogger.Level.DEBUG, "getClassFromComponentClassLoader: Looking for interface class {0} through loader of {1}", null, new Object[] { className, componentClass
/*     */ 
/*     */             
/*  99 */             .getName() });
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/* 106 */       ClassLoader loader = componentClass.getClassLoader();
/* 107 */       if (loader == null)
/*     */       {
/* 109 */         loader = ClassLoader.getSystemClassLoader();
/*     */       }
/*     */       
/* 112 */       Class<?> referenceClass = loader.loadClass(className);
/* 113 */       if (logger.isLogEnabled(InternalLogger.Level.DEBUG))
/*     */       {
/* 115 */         logger.log(InternalLogger.Level.DEBUG, "getClassFromComponentClassLoader: Found class {0}", null, new Object[] { referenceClass
/* 116 */               .getName() });
/*     */       }
/* 118 */       return referenceClass;
/*     */     }
/* 120 */     catch (ClassNotFoundException classNotFoundException) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 126 */       if (logger.isLogEnabled(InternalLogger.Level.DEBUG))
/*     */       {
/* 128 */         logger.log(InternalLogger.Level.DEBUG, "getClassFromComponentClassLoader: Not found through component class, using FrameworkWiring", null);
/*     */       }
/*     */ 
/*     */ 
/*     */       
/* 133 */       Bundle exportingHost = getExporter(className, logger);
/* 134 */       if (exportingHost != null) {
/*     */ 
/*     */         
/*     */         try {
/* 138 */           if (logger.isLogEnabled(InternalLogger.Level.DEBUG))
/*     */           {
/* 140 */             logger.log(InternalLogger.Level.DEBUG, "getClassFromComponentClassLoader: Checking Bundle {0}/{1}", null, new Object[] { exportingHost
/* 141 */                   .getSymbolicName(), Long.valueOf(exportingHost.getBundleId()) });
/*     */           }
/*     */           
/* 144 */           Class<?> referenceClass = exportingHost.loadClass(className);
/* 145 */           if (logger.isLogEnabled(InternalLogger.Level.DEBUG))
/*     */           {
/* 147 */             logger.log(InternalLogger.Level.DEBUG, "getClassFromComponentClassLoader: Found class {0}", null, new Object[] { referenceClass
/* 148 */                   .getName() });
/*     */           }
/* 150 */           return referenceClass;
/* 151 */         } catch (ClassNotFoundException classNotFoundException1) {}
/*     */ 
/*     */ 
/*     */       
/*     */       }
/* 156 */       else if (logger.isLogEnabled(InternalLogger.Level.DEBUG)) {
/*     */         
/* 158 */         logger.log(InternalLogger.Level.DEBUG, "getClassFromComponentClassLoader: No bundles exporting package {0} found", null, new Object[] { className });
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 164 */       if (logger.isLogEnabled(InternalLogger.Level.DEBUG))
/*     */       {
/* 166 */         logger.log(InternalLogger.Level.DEBUG, "getClassFromComponentClassLoader: No class found, falling back to class Object", null);
/*     */       }
/*     */       
/* 169 */       return OBJECT_CLASS;
/*     */     } 
/*     */   }
/*     */   private static Bundle getExporter(String className, ComponentLogger logger) {
/* 173 */     FrameworkWiring currentFwkWiring = m_fwkWiring;
/* 174 */     if (currentFwkWiring != null) {
/*     */       
/* 176 */       String referenceClassPackage = className.substring(0, className.lastIndexOf('.'));
/* 177 */       Collection<BundleCapability> providers = currentFwkWiring.findProviders(getRequirement(referenceClassPackage));
/* 178 */       for (BundleCapability provider : providers)
/*     */       {
/* 180 */         BundleWiring wiring = provider.getRevision().getWiring();
/* 181 */         if (wiring != null)
/*     */         {
/* 183 */           if ((provider.getRevision().getTypes() & 0x1) != 0) {
/*     */             
/* 185 */             List<BundleWire> hostWires = wiring.getRequiredWires("osgi.wiring.host");
/* 186 */             if (hostWires != null && !hostWires.isEmpty()) {
/* 187 */               return ((BundleWire)hostWires.get(0)).getProvider().getBundle();
/*     */             }
/*     */             
/*     */             continue;
/*     */           } 
/* 192 */           return wiring.getBundle();
/*     */         }
/*     */       
/*     */       }
/*     */     
/* 197 */     } else if (logger.isLogEnabled(InternalLogger.Level.DEBUG)) {
/*     */       
/* 199 */       logger.log(InternalLogger.Level.DEBUG, "getClassFromComponentClassLoader: FrameworkWiring not available, cannot find class", null);
/*     */     } 
/*     */     
/* 202 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   private static Requirement getRequirement(final String pkgName) {
/* 207 */     return new Requirement()
/*     */       {
/*     */         
/*     */         public Resource getResource()
/*     */         {
/* 212 */           return null;
/*     */         }
/*     */ 
/*     */ 
/*     */         
/*     */         public String getNamespace() {
/* 218 */           return "osgi.wiring.package";
/*     */         }
/*     */ 
/*     */ 
/*     */         
/*     */         public Map<String, String> getDirectives() {
/* 224 */           String filter = "(osgi.wiring.package=" + pkgName + ")";
/* 225 */           return Collections.singletonMap("filter", filter);
/*     */         }
/*     */ 
/*     */ 
/*     */         
/*     */         public Map<String, Object> getAttributes() {
/* 231 */           return Collections.emptyMap();
/*     */         }
/*     */       };
/*     */   }
/*     */ 
/*     */   
/*     */   public static void setFrameworkWiring(FrameworkWiring fwkWiring) {
/* 238 */     m_fwkWiring = fwkWiring;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getPackageName(Class<?> clazz) {
/* 247 */     String name = clazz.getName();
/* 248 */     int dot = name.lastIndexOf('.');
/* 249 */     return (dot > 0) ? name.substring(0, dot) : "";
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.apache.felix.scr-2.2.6.jar!\org\apache\felix\scr\impl\inject\internal\ClassUtils.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */