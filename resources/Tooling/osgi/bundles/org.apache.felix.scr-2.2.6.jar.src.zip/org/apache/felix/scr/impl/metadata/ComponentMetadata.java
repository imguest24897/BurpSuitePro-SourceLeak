/*      */ package org.apache.felix.scr.impl.metadata;
/*      */ 
/*      */ import java.io.DataInputStream;
/*      */ import java.io.DataOutputStream;
/*      */ import java.io.IOException;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Arrays;
/*      */ import java.util.Collections;
/*      */ import java.util.HashMap;
/*      */ import java.util.HashSet;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.Set;
/*      */ import java.util.TreeSet;
/*      */ import org.osgi.service.component.ComponentException;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class ComponentMetadata
/*      */ {
/*      */   public static final String CONFIGURATION_POLICY_REQUIRE = "require";
/*      */   public static final String CONFIGURATION_POLICY_IGNORE = "ignore";
/*      */   public static final String CONFIGURATION_POLICY_OPTIONAL = "optional";
/*      */   private static final Set<String> CONFIGURATION_POLICY_VALID;
/*      */   private static final String IMPLEMENTATION_CLASS_DUPLICATE = "icd";
/*   63 */   private static final ServiceMetadata SERVICE_DUPLICATE = new ServiceMetadata();
/*      */ 
/*      */ 
/*      */   
/*      */   private final DSVersion m_dsVersion;
/*      */ 
/*      */ 
/*      */   
/*      */   private String m_name;
/*      */ 
/*      */   
/*      */   private boolean m_enabled = true;
/*      */ 
/*      */   
/*      */   private String m_factory;
/*      */ 
/*      */   
/*      */   private Boolean m_immediate;
/*      */ 
/*      */   
/*      */   private String m_implementationClassName;
/*      */ 
/*      */   
/*      */   private String m_activate;
/*      */ 
/*      */   
/*      */   private boolean m_activateDeclared = false;
/*      */ 
/*      */   
/*      */   private String m_deactivate;
/*      */ 
/*      */   
/*      */   private boolean m_deactivateDeclared = false;
/*      */ 
/*      */   
/*      */   private String m_modified;
/*      */ 
/*      */   
/*      */   private String m_configurationPolicy;
/*      */ 
/*      */   
/*      */   private List<String> m_configurationPid;
/*      */ 
/*      */   
/*      */   private List<String> m_activationFields;
/*      */ 
/*      */   
/*  110 */   private final Map<String, Object> m_properties = new HashMap<>();
/*      */ 
/*      */   
/*  113 */   private final Map<String, Object> m_factoryProperties = new HashMap<>();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  119 */   private final List<PropertyMetadata> m_propertyMetaData = new ArrayList<>();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  125 */   private final List<PropertyMetadata> m_factoryPropertyMetaData = new ArrayList<>();
/*      */ 
/*      */   
/*      */   private ServiceMetadata m_service;
/*      */ 
/*      */   
/*  131 */   private final List<ReferenceMetadata> m_references = new ArrayList<>();
/*      */   
/*      */   private boolean m_configurableServiceProperties;
/*      */   
/*      */   private boolean m_persistentFactoryComponent;
/*      */   
/*      */   private boolean m_deleteCallsModify;
/*      */   
/*      */   private Boolean m_obsoleteFactoryComponentFactory;
/*      */   
/*      */   private boolean m_configureWithInterfaces;
/*      */   private boolean m_delayedKeepInstances;
/*      */   private String m_init;
/*      */   private boolean m_validated = false;
/*      */   
/*      */   static {
/*  147 */     CONFIGURATION_POLICY_VALID = new TreeSet<>();
/*  148 */     CONFIGURATION_POLICY_VALID.add("ignore");
/*  149 */     CONFIGURATION_POLICY_VALID.add("optional");
/*  150 */     CONFIGURATION_POLICY_VALID.add("require");
/*      */   }
/*      */   private static final byte TypeString = 1; private static final byte TypeLong = 2; private static final byte TypeDouble = 3; private static final byte TypeFloat = 4; private static final byte TypeInteger = 5; private static final byte TypeByte = 6; private static final byte TypeChar = 7; private static final byte TypeBoolean = 8;
/*      */   private static final byte TypeShort = 9;
/*      */   
/*      */   public ComponentMetadata(DSVersion dsVersion) {
/*  156 */     this.m_dsVersion = dsVersion;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setConfigurationPid(String[] configurationPid) {
/*  167 */     if (this.m_validated) {
/*      */       return;
/*      */     }
/*      */     
/*  171 */     this.m_configurationPid = new ArrayList<>(Arrays.asList(configurationPid));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setName(String name) {
/*  181 */     if (this.m_validated) {
/*      */       return;
/*      */     }
/*      */     
/*  185 */     this.m_name = name;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setEnabled(boolean enabled) {
/*  196 */     if (this.m_validated) {
/*      */       return;
/*      */     }
/*      */     
/*  200 */     this.m_enabled = enabled;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setFactoryIdentifier(String factoryIdentifier) {
/*  210 */     if (this.m_validated) {
/*      */       return;
/*      */     }
/*      */     
/*  214 */     this.m_factory = factoryIdentifier;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setImmediate(boolean immediate) {
/*  225 */     if (this.m_validated) {
/*      */       return;
/*      */     }
/*      */     
/*  229 */     this.m_immediate = immediate ? Boolean.TRUE : Boolean.FALSE;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setImplementationClassName(String implementationClassName) {
/*  240 */     if (this.m_validated) {
/*      */       return;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*  246 */     if (this.m_implementationClassName != null) {
/*      */       
/*  248 */       this.m_implementationClassName = "icd";
/*      */     }
/*      */     else {
/*      */       
/*  252 */       this.m_implementationClassName = implementationClassName;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setConfigurationPolicy(String configurationPolicy) {
/*  265 */     if (this.m_validated) {
/*      */       return;
/*      */     }
/*      */     
/*  269 */     this.m_configurationPolicy = configurationPolicy;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setActivate(String activate) {
/*  281 */     if (this.m_validated) {
/*      */       return;
/*      */     }
/*      */     
/*  285 */     this.m_activate = activate;
/*  286 */     this.m_activateDeclared = true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setDeactivate(String deactivate) {
/*  298 */     if (this.m_validated) {
/*      */       return;
/*      */     }
/*      */     
/*  302 */     this.m_deactivate = deactivate;
/*  303 */     this.m_deactivateDeclared = true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setModified(String modified) {
/*  315 */     if (this.m_validated) {
/*      */       return;
/*      */     }
/*      */     
/*  319 */     this.m_modified = modified;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void addProperty(PropertyMetadata newProperty) {
/*  330 */     if (this.m_validated) {
/*      */       return;
/*      */     }
/*      */     
/*  334 */     if (newProperty == null)
/*      */     {
/*  336 */       throw new IllegalArgumentException("Cannot add a null property");
/*      */     }
/*  338 */     this.m_propertyMetaData.add(newProperty);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void addFactoryProperty(PropertyMetadata newProperty) {
/*  348 */     if (this.m_validated) {
/*      */       return;
/*      */     }
/*      */     
/*  352 */     if (newProperty == null)
/*      */     {
/*  354 */       throw new IllegalArgumentException("Cannot add a null property");
/*      */     }
/*  356 */     this.m_factoryPropertyMetaData.add(newProperty);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setService(ServiceMetadata service) {
/*  366 */     if (this.m_validated) {
/*      */       return;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*  372 */     if (this.m_service != null) {
/*      */       
/*  374 */       this.m_service = SERVICE_DUPLICATE;
/*      */     }
/*      */     else {
/*      */       
/*  378 */       this.m_service = service;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void addDependency(ReferenceMetadata newReference) {
/*  390 */     if (this.m_validated) {
/*      */       return;
/*      */     }
/*      */     
/*  394 */     if (newReference == null)
/*      */     {
/*  396 */       throw new IllegalArgumentException("Cannot add a null ReferenceMetadata");
/*      */     }
/*  398 */     this.m_references.add(newReference);
/*      */   }
/*      */   
/*      */   public void setConfigurableServiceProperties(boolean configurableServiceProperties) {
/*  402 */     if (this.m_validated) {
/*      */       return;
/*      */     }
/*      */     
/*  406 */     this.m_configurableServiceProperties = configurableServiceProperties;
/*      */   }
/*      */   
/*      */   public void setPersistentFactoryComponent(boolean persistentFactoryComponent) {
/*  410 */     if (this.m_validated) {
/*      */       return;
/*      */     }
/*      */     
/*  414 */     this.m_persistentFactoryComponent = persistentFactoryComponent;
/*      */   }
/*      */   
/*      */   public void setDeleteCallsModify(boolean deleteCallsModify) {
/*  418 */     if (this.m_validated) {
/*      */       return;
/*      */     }
/*      */     
/*  422 */     this.m_deleteCallsModify = deleteCallsModify;
/*      */   }
/*      */   
/*      */   public void setObsoleteFactoryComponentFactory(boolean obsoleteFactoryComponentFactory) {
/*  426 */     if (this.m_validated) {
/*      */       return;
/*      */     }
/*      */     
/*  430 */     this.m_obsoleteFactoryComponentFactory = Boolean.valueOf(obsoleteFactoryComponentFactory);
/*      */   }
/*      */   
/*      */   public void setConfigureWithInterfaces(boolean configureWithInterfaces) {
/*  434 */     this.m_configureWithInterfaces = configureWithInterfaces;
/*      */   }
/*      */   
/*      */   public void setDelayedKeepInstances(boolean delayedKeepInstances) {
/*  438 */     if (this.m_validated) {
/*      */       return;
/*      */     }
/*      */     
/*  442 */     this.m_delayedKeepInstances = delayedKeepInstances;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setActivationFields(String[] fields) {
/*  449 */     if (!this.m_validated)
/*      */     {
/*  451 */       this.m_activationFields = new ArrayList<>(Arrays.asList(fields));
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   public void setInit(String value) {
/*  457 */     if (!this.m_validated)
/*      */     {
/*  459 */       this.m_init = value;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public DSVersion getDSVersion() {
/*  472 */     return this.m_dsVersion;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getName() {
/*  489 */     if (this.m_name != null)
/*      */     {
/*  491 */       return this.m_name;
/*      */     }
/*      */ 
/*      */     
/*  495 */     return getImplementationClassName();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public List<String> getConfigurationPid() {
/*  505 */     if (!this.m_validated)
/*      */     {
/*  507 */       throw new IllegalStateException("not yet validated");
/*      */     }
/*  509 */     return this.m_configurationPid;
/*      */   }
/*      */ 
/*      */   
/*      */   public int getPidIndex(TargetedPID pid) {
/*  514 */     if (!this.m_validated)
/*      */     {
/*  516 */       throw new IllegalStateException("not yet validated");
/*      */     }
/*  518 */     if (this.m_configurationPid == null)
/*      */     {
/*  520 */       throw new IllegalStateException("Apparently trying to configure a component " + this.m_name + " without a configurationPid using " + pid);
/*      */     }
/*  522 */     return this.m_configurationPid.indexOf(pid.getServicePid());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isConfigurationPidDeclared() {
/*  535 */     return (this.m_configurationPid != null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isEnabled() {
/*  545 */     return this.m_enabled;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getFactoryIdentifier() {
/*  556 */     return this.m_factory;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isImmediate() {
/*  575 */     if (this.m_immediate != null)
/*      */     {
/*  577 */       return this.m_immediate.booleanValue();
/*      */     }
/*      */ 
/*      */     
/*  581 */     return (this.m_service == null && this.m_factory == null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getImplementationClassName() {
/*  592 */     return this.m_implementationClassName;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getConfigurationPolicy() {
/*  604 */     return this.m_configurationPolicy;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getActivate() {
/*  616 */     return this.m_activate;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isActivateDeclared() {
/*  630 */     return this.m_activateDeclared;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getNumberOfConstructorParameters() {
/*  641 */     return (this.m_init == null) ? 0 : Integer.valueOf(this.m_init).intValue();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public List<String> getActivationFields() {
/*  652 */     return this.m_activationFields;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getDeactivate() {
/*  664 */     return this.m_deactivate;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isDeactivateDeclared() {
/*  678 */     return this.m_deactivateDeclared;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getModified() {
/*  690 */     return this.m_modified;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ServiceMetadata getServiceMetadata() {
/*  701 */     return this.m_service;
/*      */   }
/*      */ 
/*      */   
/*      */   public ServiceMetadata.Scope getServiceScope() {
/*  706 */     if (this.m_service == null)
/*      */     {
/*  708 */       return ServiceMetadata.Scope.singleton;
/*      */     }
/*  710 */     return this.m_service.getScope();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Map<String, Object> getProperties() {
/*  721 */     return this.m_properties;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Map<String, Object> getFactoryProperties() {
/*  732 */     return this.m_factoryProperties;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   List<PropertyMetadata> getPropertyMetaData() {
/*  744 */     return this.m_propertyMetaData;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   List<PropertyMetadata> getFactoryPropertyMetaData() {
/*  756 */     return this.m_factoryPropertyMetaData;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public List<ReferenceMetadata> getDependencies() {
/*  767 */     return this.m_references;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isFactory() {
/*  778 */     return (this.m_factory != null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isConfigurationRequired() {
/*  788 */     return "require".equals(this.m_configurationPolicy);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isConfigurationIgnored() {
/*  798 */     return "ignore".equals(this.m_configurationPolicy);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isConfigurationOptional() {
/*  808 */     return "optional".equals(this.m_configurationPolicy);
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isConfigurableServiceProperties() {
/*  813 */     return this.m_configurableServiceProperties;
/*      */   }
/*      */   
/*      */   public boolean isPersistentFactoryComponent() {
/*  817 */     return this.m_persistentFactoryComponent;
/*      */   }
/*      */   
/*      */   public boolean isDeleteCallsModify() {
/*  821 */     return this.m_deleteCallsModify;
/*      */   }
/*      */   
/*      */   public boolean isObsoleteFactoryComponentFactory() {
/*  825 */     return (this.m_obsoleteFactoryComponentFactory == null) ? false : this.m_obsoleteFactoryComponentFactory.booleanValue();
/*      */   }
/*      */   
/*      */   public boolean isConfigureWithInterfaces() {
/*  829 */     return this.m_configureWithInterfaces;
/*      */   }
/*      */   
/*      */   public boolean isDelayedKeepInstances() {
/*  833 */     return this.m_delayedKeepInstances;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void validate() {
/*  842 */     if (this.m_validated) {
/*      */       return;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*  848 */     if (this.m_name == null) {
/*      */ 
/*      */       
/*  851 */       if (!this.m_dsVersion.isDS11())
/*      */       {
/*  853 */         throw new ComponentException("The component name has not been set");
/*      */       }
/*  855 */       setName(getImplementationClassName());
/*      */     } 
/*      */ 
/*      */     
/*  859 */     if (this.m_implementationClassName == null)
/*      */     {
/*  861 */       throw validationFailure("Implementation class name missing");
/*      */     }
/*  863 */     if (this.m_implementationClassName == "icd")
/*      */     {
/*  865 */       throw validationFailure("Implementation element must occur exactly once");
/*      */     }
/*      */ 
/*      */     
/*  869 */     if (this.m_configurationPolicy == null) {
/*      */ 
/*      */       
/*  872 */       this.m_configurationPolicy = "optional";
/*      */     } else {
/*  874 */       if (!this.m_dsVersion.isDS11())
/*      */       {
/*  876 */         throw validationFailure("configuration-policy declaration requires DS 1.1 or later namespace ");
/*      */       }
/*  878 */       if (!CONFIGURATION_POLICY_VALID.contains(this.m_configurationPolicy))
/*      */       {
/*  880 */         throw validationFailure("configuration-policy must be one of " + CONFIGURATION_POLICY_VALID);
/*      */       }
/*      */     } 
/*      */     
/*  884 */     if (this.m_activate == null) {
/*      */ 
/*      */       
/*  887 */       this.m_activate = "activate";
/*      */     }
/*  889 */     else if (!this.m_dsVersion.isDS11()) {
/*      */       
/*  891 */       throw validationFailure("activate method declaration requires DS 1.1 or later namespace ");
/*      */     } 
/*      */ 
/*      */     
/*  895 */     if (this.m_deactivate == null) {
/*      */ 
/*      */       
/*  898 */       this.m_deactivate = "deactivate";
/*      */     }
/*  900 */     else if (!this.m_dsVersion.isDS11()) {
/*      */       
/*  902 */       throw validationFailure("deactivate method declaration requires DS 1.1 or later namespace ");
/*      */     } 
/*      */ 
/*      */     
/*  906 */     if (this.m_modified != null && !this.m_dsVersion.isDS11())
/*      */     {
/*  908 */       throw validationFailure("modified method declaration requires DS 1.1 or later namespace ");
/*      */     }
/*      */ 
/*      */     
/*  912 */     if (this.m_configurationPid == null) {
/*      */       
/*  914 */       this.m_configurationPid = Collections.singletonList(getName());
/*      */     }
/*      */     else {
/*      */       
/*  918 */       if (!this.m_dsVersion.isDS12())
/*      */       {
/*  920 */         throw validationFailure("configuration-pid attribute requires DS 1.2 or later namespace ");
/*      */       }
/*  922 */       if (this.m_configurationPid.isEmpty())
/*      */       {
/*  924 */         throw validationFailure("configuration-pid nust not be empty string ");
/*      */       }
/*  926 */       if (this.m_configurationPid.size() > 1 && !this.m_dsVersion.isDS13())
/*      */       {
/*  928 */         throw validationFailure("multiple configuration-pid requires DS 1.3 or later namespace ");
/*      */       }
/*  930 */       for (int i = 0; i < this.m_configurationPid.size(); i++) {
/*      */         
/*  932 */         if ("$".equals(this.m_configurationPid.get(i))) {
/*      */           
/*  934 */           if (!this.m_dsVersion.isDS13())
/*      */           {
/*  936 */             throw validationFailure("Use of '$' configuration-pid wildcard requires DS 1.3 or later namespace ");
/*      */           }
/*  938 */           this.m_configurationPid.set(i, getName());
/*      */         } 
/*      */       } 
/*  941 */       if ((new HashSet(this.m_configurationPid)).size() != this.m_configurationPid.size())
/*      */       {
/*  943 */         throw validationFailure("Duplicate pids not allowed: " + this.m_configurationPid);
/*      */       }
/*      */     } 
/*      */ 
/*      */     
/*  948 */     for (PropertyMetadata propMeta : this.m_propertyMetaData) {
/*      */       
/*  950 */       propMeta.validate(this);
/*  951 */       if (this.m_dsVersion.isDS15() && propMeta.isReferenceTarget()) {
/*      */ 
/*      */ 
/*      */         
/*  955 */         this.m_properties.putIfAbsent(propMeta.getName(), propMeta.getValue());
/*      */         
/*      */         continue;
/*      */       } 
/*  959 */       this.m_properties.put(propMeta.getName(), propMeta.getValue());
/*      */     } 
/*      */     
/*  962 */     this.m_propertyMetaData.clear();
/*      */ 
/*      */     
/*  965 */     if (!this.m_dsVersion.isDS14() && !this.m_factoryPropertyMetaData.isEmpty())
/*      */     {
/*  967 */       throw validationFailure("Use of factory properties requires DS 1.4 or later namespace ");
/*      */     }
/*  969 */     if (this.m_dsVersion.isDS14() && isFactory())
/*      */     {
/*  971 */       for (PropertyMetadata propMeta : this.m_factoryPropertyMetaData) {
/*      */         
/*  973 */         propMeta.validate(this);
/*  974 */         this.m_factoryProperties.put(propMeta.getName(), propMeta.getValue());
/*      */       } 
/*      */     }
/*      */     
/*  978 */     this.m_factoryPropertyMetaData.clear();
/*      */ 
/*      */     
/*  981 */     if (this.m_service == SERVICE_DUPLICATE)
/*      */     {
/*  983 */       throw validationFailure("Service element must occur at most once");
/*      */     }
/*  985 */     if (this.m_service != null)
/*      */     {
/*  987 */       this.m_service.validate(this);
/*      */     }
/*      */ 
/*      */     
/*  991 */     Set<String> refs = new HashSet<>();
/*  992 */     for (ReferenceMetadata refMeta : this.m_references) {
/*      */       
/*  994 */       refMeta.validate(this);
/*      */ 
/*      */       
/*  997 */       if (!refs.add(refMeta.getName()))
/*      */       {
/*  999 */         throw validationFailure("Detected duplicate reference name: ''" + refMeta.getName() + "''");
/*      */       }
/*      */     } 
/*      */ 
/*      */     
/* 1004 */     if (this.m_immediate != null)
/*      */     {
/* 1006 */       if (isImmediate()) {
/*      */ 
/*      */         
/* 1009 */         if (isFactory())
/*      */         {
/* 1011 */           throw validationFailure("Factory cannot be immediate");
/*      */ 
/*      */ 
/*      */         
/*      */         }
/*      */ 
/*      */       
/*      */       }
/* 1019 */       else if (this.m_service == null && !isFactory()) {
/*      */         
/* 1021 */         throw validationFailure("Delayed must provide a service or be a factory");
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1028 */     if (this.m_service != null)
/*      */     {
/* 1030 */       if (this.m_service.getScope() != ServiceMetadata.Scope.singleton && (isFactory() || isImmediate()))
/*      */       {
/* 1032 */         throw validationFailure("factory or immediate must be scope singleton not " + this.m_service.getScope());
/*      */       }
/*      */     }
/*      */ 
/*      */     
/* 1037 */     if (this.m_activationFields != null && !this.m_dsVersion.isDS14())
/*      */     {
/* 1039 */       throw validationFailure("Activation fields require version 1.4 or later");
/*      */     }
/*      */ 
/*      */     
/* 1043 */     if (this.m_init != null) {
/*      */       
/* 1045 */       if (!this.m_dsVersion.isDS14())
/*      */       {
/* 1047 */         throw validationFailure("Constructor injection requires version 1.4 or later");
/*      */       }
/* 1049 */       int constructorParameters = 0;
/*      */       
/*      */       try {
/* 1052 */         constructorParameters = Integer.valueOf(this.m_init).intValue();
/* 1053 */         if (constructorParameters < 0)
/*      */         {
/* 1055 */           throw validationFailure("Init parameter must have non negative value: " + this.m_init);
/*      */         }
/*      */       }
/* 1058 */       catch (NumberFormatException nfe) {
/*      */         
/* 1060 */         throw validationFailure("Init parameter is not a number: " + this.m_init);
/*      */       } 
/*      */     } 
/*      */     
/* 1064 */     if (this.m_dsVersion == DSVersion.DS12Felix)
/*      */     {
/* 1066 */       this.m_configurableServiceProperties = true;
/*      */     }
/* 1068 */     if (this.m_configurableServiceProperties && getServiceScope() != ServiceMetadata.Scope.singleton)
/*      */     {
/* 1070 */       throw validationFailure("configurable service properties only allowed with singleton scope");
/*      */     }
/* 1072 */     if (this.m_dsVersion.isDS13())
/*      */     {
/* 1074 */       this.m_deleteCallsModify = true;
/*      */     }
/* 1076 */     if (!this.m_dsVersion.isDS13() && this.m_configureWithInterfaces)
/*      */     {
/* 1078 */       throw validationFailure("Configuration with interfaces or annotations only possible with version 1.3 or later");
/*      */     }
/* 1080 */     if (this.m_dsVersion.isDS13() && this.m_obsoleteFactoryComponentFactory != null)
/*      */     {
/* 1082 */       throw validationFailure("Configuration of component factory instances through config admin factory pids supported only through the 1.2 namespace");
/*      */     }
/* 1084 */     if (this.m_persistentFactoryComponent && !isFactory())
/*      */     {
/* 1086 */       throw validationFailure("Only a factory component can be a persistent factory component");
/*      */     }
/*      */     
/* 1089 */     this.m_validated = true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   ComponentException validationFailure(String reason) {
/* 1101 */     return new ComponentException("Component " + getName() + " validation failed: " + reason);
/*      */   }
/*      */ 
/*      */   
/*      */   public void collectStrings(Set<String> strings) {
/* 1106 */     MetadataStoreHelper.addString(this.m_dsVersion.toString(), strings);
/* 1107 */     MetadataStoreHelper.addString(this.m_activate, strings);
/* 1108 */     if (this.m_activationFields != null)
/*      */     {
/* 1110 */       for (String s : this.m_activationFields)
/*      */       {
/* 1112 */         MetadataStoreHelper.addString(s, strings);
/*      */       }
/*      */     }
/* 1115 */     if (this.m_configurationPid != null)
/*      */     {
/* 1117 */       for (String s : this.m_configurationPid)
/*      */       {
/* 1119 */         MetadataStoreHelper.addString(s, strings);
/*      */       }
/*      */     }
/* 1122 */     MetadataStoreHelper.addString(this.m_configurationPolicy, strings);
/* 1123 */     MetadataStoreHelper.addString(this.m_deactivate, strings);
/* 1124 */     MetadataStoreHelper.addString(this.m_factory, strings);
/* 1125 */     MetadataStoreHelper.addString(this.m_implementationClassName, strings);
/* 1126 */     MetadataStoreHelper.addString(this.m_init, strings);
/* 1127 */     MetadataStoreHelper.addString(this.m_modified, strings);
/* 1128 */     MetadataStoreHelper.addString(this.m_name, strings);
/* 1129 */     for (Map.Entry<String, Object> entry : this.m_factoryProperties.entrySet())
/*      */     {
/* 1131 */       collectStrings(entry, strings);
/*      */     }
/* 1133 */     for (Map.Entry<String, Object> entry : this.m_properties.entrySet())
/*      */     {
/* 1135 */       collectStrings(entry, strings);
/*      */     }
/* 1137 */     for (ReferenceMetadata rMeta : this.m_references)
/*      */     {
/* 1139 */       rMeta.collectStrings(strings);
/*      */     }
/* 1141 */     if (this.m_service != null)
/*      */     {
/* 1143 */       this.m_service.collectStrings(strings);
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   private void collectStrings(Map.Entry<String, Object> entry, Set<String> strings) {
/* 1149 */     MetadataStoreHelper.addString(entry.getKey(), strings);
/* 1150 */     Object v = entry.getValue();
/* 1151 */     if (v instanceof String) {
/*      */       
/* 1153 */       MetadataStoreHelper.addString((String)v, strings);
/*      */     }
/* 1155 */     else if (v instanceof String[]) {
/*      */       
/* 1157 */       for (String s : (String[])v)
/*      */       {
/* 1159 */         MetadataStoreHelper.addString(s, strings);
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void store(DataOutputStream out, MetadataStoreHelper.MetaDataWriter metaDataWriter) throws IOException {
/* 1167 */     metaDataWriter.writeString(this.m_dsVersion.toString(), out);
/* 1168 */     metaDataWriter.writeString(this.m_activate, out);
/* 1169 */     out.writeBoolean((this.m_activationFields != null));
/* 1170 */     if (this.m_activationFields != null) {
/*      */       
/* 1172 */       out.writeInt(this.m_activationFields.size());
/* 1173 */       for (String s : this.m_activationFields)
/*      */       {
/* 1175 */         metaDataWriter.writeString(s, out);
/*      */       }
/*      */     } 
/* 1178 */     out.writeBoolean((this.m_configurationPid != null));
/* 1179 */     if (this.m_configurationPid != null) {
/*      */       
/* 1181 */       out.writeInt(this.m_configurationPid.size());
/* 1182 */       for (String s : this.m_configurationPid)
/*      */       {
/* 1184 */         metaDataWriter.writeString(s, out);
/*      */       }
/*      */     } 
/* 1187 */     metaDataWriter.writeString(this.m_configurationPolicy, out);
/* 1188 */     metaDataWriter.writeString(this.m_deactivate, out);
/* 1189 */     metaDataWriter.writeString(this.m_factory, out);
/* 1190 */     metaDataWriter.writeString(this.m_implementationClassName, out);
/* 1191 */     metaDataWriter.writeString(this.m_init, out);
/* 1192 */     metaDataWriter.writeString(this.m_modified, out);
/* 1193 */     metaDataWriter.writeString(this.m_name, out);
/* 1194 */     out.writeInt(this.m_factoryProperties.size());
/* 1195 */     for (Map.Entry<String, Object> prop : this.m_factoryProperties.entrySet()) {
/*      */       
/* 1197 */       metaDataWriter.writeString(prop.getKey(), out);
/* 1198 */       storePropertyValue(prop.getValue(), out, metaDataWriter);
/*      */     } 
/* 1200 */     out.writeInt(this.m_properties.size());
/* 1201 */     for (Map.Entry<String, Object> prop : this.m_properties.entrySet()) {
/*      */       
/* 1203 */       metaDataWriter.writeString(prop.getKey(), out);
/* 1204 */       storePropertyValue(prop.getValue(), out, metaDataWriter);
/*      */     } 
/* 1206 */     out.writeInt(this.m_references.size());
/* 1207 */     for (ReferenceMetadata rMeta : this.m_references)
/*      */     {
/* 1209 */       rMeta.store(out, metaDataWriter);
/*      */     }
/* 1211 */     out.writeBoolean((this.m_service != null));
/* 1212 */     if (this.m_service != null)
/*      */     {
/* 1214 */       this.m_service.store(out, metaDataWriter);
/*      */     }
/* 1216 */     out.writeBoolean(this.m_activateDeclared);
/* 1217 */     out.writeBoolean(this.m_configurableServiceProperties);
/* 1218 */     out.writeBoolean(this.m_configureWithInterfaces);
/* 1219 */     out.writeBoolean(this.m_deactivateDeclared);
/* 1220 */     out.writeBoolean(this.m_delayedKeepInstances);
/* 1221 */     out.writeBoolean(this.m_deleteCallsModify);
/* 1222 */     out.writeBoolean(this.m_enabled);
/* 1223 */     out.writeBoolean((this.m_immediate != null));
/* 1224 */     if (this.m_immediate != null)
/*      */     {
/* 1226 */       out.writeBoolean(this.m_immediate.booleanValue());
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static ComponentMetadata load(DataInputStream in, MetadataStoreHelper.MetaDataReader metaDataReader) throws IOException {
/* 1235 */     ComponentMetadata result = new ComponentMetadata(DSVersion.valueOf(metaDataReader.readString(in)));
/* 1236 */     result.m_activate = metaDataReader.readString(in);
/* 1237 */     if (in.readBoolean()) {
/*      */       
/* 1239 */       int size = in.readInt();
/* 1240 */       String[] activationFields = new String[size];
/* 1241 */       for (int m = 0; m < size; m++)
/*      */       {
/* 1243 */         activationFields[m] = metaDataReader.readString(in);
/*      */       }
/* 1245 */       result.setActivationFields(activationFields);
/*      */     } 
/* 1247 */     if (in.readBoolean()) {
/*      */       
/* 1249 */       int size = in.readInt();
/* 1250 */       String[] configPids = new String[size];
/* 1251 */       for (int m = 0; m < size; m++)
/*      */       {
/* 1253 */         configPids[m] = metaDataReader.readString(in);
/*      */       }
/* 1255 */       result.setConfigurationPid(configPids);
/*      */     } 
/* 1257 */     result.m_configurationPolicy = metaDataReader.readString(in);
/* 1258 */     result.m_deactivate = metaDataReader.readString(in);
/* 1259 */     result.m_factory = metaDataReader.readString(in);
/* 1260 */     result.m_implementationClassName = metaDataReader.readString(in);
/* 1261 */     result.m_init = metaDataReader.readString(in);
/* 1262 */     result.m_modified = metaDataReader.readString(in);
/* 1263 */     result.m_name = metaDataReader.readString(in);
/* 1264 */     int numFProps = in.readInt();
/* 1265 */     for (int i = 0; i < numFProps; i++)
/*      */     {
/* 1267 */       result.m_factoryProperties.put(metaDataReader.readString(in), 
/* 1268 */           loadPropertyValue(in, metaDataReader));
/*      */     }
/* 1270 */     int numProps = in.readInt();
/* 1271 */     for (int j = 0; j < numProps; j++)
/*      */     {
/* 1273 */       result.m_properties.put(metaDataReader.readString(in), 
/* 1274 */           loadPropertyValue(in, metaDataReader));
/*      */     }
/* 1276 */     int numRefs = in.readInt();
/* 1277 */     for (int k = 0; k < numRefs; k++)
/*      */     {
/* 1279 */       result.addDependency(ReferenceMetadata.load(in, metaDataReader));
/*      */     }
/* 1281 */     if (in.readBoolean())
/*      */     {
/* 1283 */       result.m_service = ServiceMetadata.load(in, metaDataReader);
/*      */     }
/* 1285 */     result.m_activateDeclared = in.readBoolean();
/* 1286 */     result.m_configurableServiceProperties = in.readBoolean();
/* 1287 */     result.m_configureWithInterfaces = in.readBoolean();
/* 1288 */     result.m_deactivateDeclared = in.readBoolean();
/* 1289 */     result.m_delayedKeepInstances = in.readBoolean();
/* 1290 */     result.m_deleteCallsModify = in.readBoolean();
/* 1291 */     result.m_enabled = in.readBoolean();
/* 1292 */     if (in.readBoolean())
/*      */     {
/* 1294 */       result.m_immediate = Boolean.valueOf(in.readBoolean());
/*      */     }
/*      */     
/* 1297 */     result.m_validated = true;
/* 1298 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static Object loadPropertyValue(DataInputStream in, MetadataStoreHelper.MetaDataReader metaDataReader) throws IOException {
/* 1314 */     boolean isArray = in.readBoolean();
/* 1315 */     byte valueType = in.readByte();
/* 1316 */     switch (valueType) {
/*      */       
/*      */       case 8:
/* 1319 */         if (isArray) {
/*      */           
/* 1321 */           boolean[] vArray = new boolean[in.readInt()];
/* 1322 */           for (int i = 0; i < vArray.length; i++)
/*      */           {
/* 1324 */             vArray[i] = in.readBoolean();
/*      */           }
/* 1326 */           return vArray;
/*      */         } 
/*      */ 
/*      */         
/* 1330 */         return Boolean.valueOf(in.readBoolean());
/*      */       
/*      */       case 6:
/* 1333 */         if (isArray) {
/*      */           
/* 1335 */           byte[] vArray = new byte[in.readInt()];
/* 1336 */           for (int i = 0; i < vArray.length; i++)
/*      */           {
/* 1338 */             vArray[i] = in.readByte();
/*      */           }
/* 1340 */           return vArray;
/*      */         } 
/*      */ 
/*      */         
/* 1344 */         return Byte.valueOf(in.readByte());
/*      */       
/*      */       case 7:
/* 1347 */         if (isArray) {
/*      */           
/* 1349 */           char[] vArray = new char[in.readInt()];
/* 1350 */           for (int i = 0; i < vArray.length; i++)
/*      */           {
/* 1352 */             vArray[i] = in.readChar();
/*      */           }
/* 1354 */           return vArray;
/*      */         } 
/*      */ 
/*      */         
/* 1358 */         return Character.valueOf(in.readChar());
/*      */       
/*      */       case 3:
/* 1361 */         if (isArray) {
/*      */           
/* 1363 */           double[] vArray = new double[in.readInt()];
/* 1364 */           for (int i = 0; i < vArray.length; i++)
/*      */           {
/* 1366 */             vArray[i] = in.readDouble();
/*      */           }
/* 1368 */           return vArray;
/*      */         } 
/*      */ 
/*      */         
/* 1372 */         return Double.valueOf(in.readDouble());
/*      */       
/*      */       case 4:
/* 1375 */         if (isArray) {
/*      */           
/* 1377 */           float[] vArray = new float[in.readInt()];
/* 1378 */           for (int i = 0; i < vArray.length; i++)
/*      */           {
/* 1380 */             vArray[i] = in.readFloat();
/*      */           }
/* 1382 */           return vArray;
/*      */         } 
/*      */ 
/*      */         
/* 1386 */         return Float.valueOf(in.readFloat());
/*      */       
/*      */       case 5:
/* 1389 */         if (isArray) {
/*      */           
/* 1391 */           int[] vArray = new int[in.readInt()];
/* 1392 */           for (int i = 0; i < vArray.length; i++)
/*      */           {
/* 1394 */             vArray[i] = in.readInt();
/*      */           }
/* 1396 */           return vArray;
/*      */         } 
/*      */ 
/*      */         
/* 1400 */         return Integer.valueOf(in.readInt());
/*      */       
/*      */       case 2:
/* 1403 */         if (isArray) {
/*      */           
/* 1405 */           long[] vArray = new long[in.readInt()];
/* 1406 */           for (int i = 0; i < vArray.length; i++)
/*      */           {
/* 1408 */             vArray[i] = in.readLong();
/*      */           }
/* 1410 */           return vArray;
/*      */         } 
/*      */ 
/*      */         
/* 1414 */         return Long.valueOf(in.readLong());
/*      */       
/*      */       case 9:
/* 1417 */         if (isArray) {
/*      */           
/* 1419 */           short[] vArray = new short[in.readInt()];
/* 1420 */           for (int i = 0; i < vArray.length; i++)
/*      */           {
/* 1422 */             vArray[i] = in.readShort();
/*      */           }
/* 1424 */           return vArray;
/*      */         } 
/*      */ 
/*      */         
/* 1428 */         return Short.valueOf(in.readShort());
/*      */       
/*      */       case 1:
/* 1431 */         if (isArray) {
/*      */           
/* 1433 */           String[] vArray = new String[in.readInt()];
/* 1434 */           for (int i = 0; i < vArray.length; i++)
/*      */           {
/* 1436 */             vArray[i] = metaDataReader.readString(in);
/*      */           }
/* 1438 */           return vArray;
/*      */         } 
/*      */ 
/*      */         
/* 1442 */         return metaDataReader.readString(in);
/*      */     } 
/*      */     
/* 1445 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   void storePropertyValue(Object value, DataOutputStream out, MetadataStoreHelper.MetaDataWriter metaDataWriter) throws IOException {
/* 1451 */     if (value == null) {
/*      */ 
/*      */       
/* 1454 */       out.writeBoolean(false);
/* 1455 */       out.writeByte(1);
/* 1456 */       metaDataWriter.writeString(null, out);
/*      */       return;
/*      */     } 
/* 1459 */     Class<?> arrayType = value.getClass().getComponentType();
/* 1460 */     boolean isArray = (arrayType != null);
/* 1461 */     out.writeBoolean(isArray);
/* 1462 */     byte valueType = getType((arrayType == null) ? value.getClass() : arrayType);
/* 1463 */     out.writeByte(valueType);
/* 1464 */     switch (valueType) {
/*      */       
/*      */       case 8:
/* 1467 */         if (isArray) {
/*      */           
/* 1469 */           boolean[] vArray = (boolean[])value;
/* 1470 */           out.writeInt(vArray.length);
/* 1471 */           for (boolean v : vArray)
/*      */           {
/* 1473 */             out.writeBoolean(v);
/*      */           }
/*      */           
/*      */           break;
/*      */         } 
/* 1478 */         out.writeBoolean(((Boolean)value).booleanValue());
/*      */         break;
/*      */       
/*      */       case 6:
/* 1482 */         if (isArray) {
/*      */           
/* 1484 */           byte[] vArray = (byte[])value;
/* 1485 */           out.writeInt(vArray.length);
/* 1486 */           for (byte v : vArray)
/*      */           {
/* 1488 */             out.writeByte(v);
/*      */           }
/*      */           
/*      */           break;
/*      */         } 
/* 1493 */         out.writeByte(((Byte)value).byteValue());
/*      */         break;
/*      */       
/*      */       case 7:
/* 1497 */         if (isArray) {
/*      */           
/* 1499 */           char[] vArray = (char[])value;
/* 1500 */           out.writeInt(vArray.length);
/* 1501 */           for (char v : vArray)
/*      */           {
/* 1503 */             out.writeChar(v);
/*      */           }
/*      */           
/*      */           break;
/*      */         } 
/* 1508 */         out.writeChar(((Character)value).charValue());
/*      */         break;
/*      */       
/*      */       case 3:
/* 1512 */         if (isArray) {
/*      */           
/* 1514 */           double[] vArray = (double[])value;
/* 1515 */           out.writeInt(vArray.length);
/* 1516 */           for (double v : vArray)
/*      */           {
/* 1518 */             out.writeDouble(v);
/*      */           }
/*      */           
/*      */           break;
/*      */         } 
/* 1523 */         out.writeDouble(((Double)value).doubleValue());
/*      */         break;
/*      */       
/*      */       case 4:
/* 1527 */         if (isArray) {
/*      */           
/* 1529 */           float[] vArray = (float[])value;
/* 1530 */           out.writeInt(vArray.length);
/* 1531 */           for (float v : vArray)
/*      */           {
/* 1533 */             out.writeFloat(v);
/*      */           }
/*      */           
/*      */           break;
/*      */         } 
/* 1538 */         out.writeFloat(((Float)value).floatValue());
/*      */         break;
/*      */       
/*      */       case 5:
/* 1542 */         if (isArray) {
/*      */           
/* 1544 */           int[] vArray = (int[])value;
/* 1545 */           out.writeInt(vArray.length);
/* 1546 */           for (int v : vArray)
/*      */           {
/* 1548 */             out.writeInt(v);
/*      */           }
/*      */           
/*      */           break;
/*      */         } 
/* 1553 */         out.writeInt(((Integer)value).intValue());
/*      */         break;
/*      */       
/*      */       case 2:
/* 1557 */         if (isArray) {
/*      */           
/* 1559 */           long[] vArray = (long[])value;
/* 1560 */           out.writeInt(vArray.length);
/* 1561 */           for (long v : vArray)
/*      */           {
/* 1563 */             out.writeLong(v);
/*      */           }
/*      */           
/*      */           break;
/*      */         } 
/* 1568 */         out.writeLong(((Long)value).longValue());
/*      */         break;
/*      */       
/*      */       case 9:
/* 1572 */         if (isArray) {
/*      */           
/* 1574 */           short[] vArray = (short[])value;
/* 1575 */           out.writeInt(vArray.length);
/* 1576 */           for (short v : vArray)
/*      */           {
/* 1578 */             out.writeShort(v);
/*      */           }
/*      */           
/*      */           break;
/*      */         } 
/* 1583 */         out.writeShort(((Short)value).shortValue());
/*      */         break;
/*      */       
/*      */       case 1:
/* 1587 */         if (isArray) {
/*      */           
/* 1589 */           String[] vArray = (String[])value;
/* 1590 */           out.writeInt(vArray.length);
/* 1591 */           for (String v : vArray)
/*      */           {
/* 1593 */             metaDataWriter.writeString(v, out);
/*      */           }
/*      */           
/*      */           break;
/*      */         } 
/*      */         
/* 1599 */         metaDataWriter.writeString((String)value, out);
/*      */         break;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private byte getType(Class<?> typeClass) {
/* 1607 */     if (Boolean.class.equals(typeClass) || boolean.class.equals(typeClass))
/*      */     {
/* 1609 */       return 8;
/*      */     }
/* 1611 */     if (Byte.class.equals(typeClass) || byte.class.equals(typeClass))
/*      */     {
/* 1613 */       return 6;
/*      */     }
/* 1615 */     if (Character.class.equals(typeClass) || char.class.equals(typeClass))
/*      */     {
/* 1617 */       return 7;
/*      */     }
/* 1619 */     if (Double.class.equals(typeClass) || double.class.equals(typeClass))
/*      */     {
/* 1621 */       return 3;
/*      */     }
/* 1623 */     if (Float.class.equals(typeClass) || float.class.equals(typeClass))
/*      */     {
/* 1625 */       return 4;
/*      */     }
/* 1627 */     if (Integer.class.equals(typeClass) || int.class.equals(typeClass))
/*      */     {
/* 1629 */       return 5;
/*      */     }
/* 1631 */     if (Long.class.equals(typeClass) || long.class.equals(typeClass))
/*      */     {
/* 1633 */       return 2;
/*      */     }
/* 1635 */     if (Short.class.equals(typeClass) || short.class.equals(typeClass))
/*      */     {
/* 1637 */       return 9;
/*      */     }
/* 1639 */     if (String.class.equals(typeClass))
/*      */     {
/* 1641 */       return 1;
/*      */     }
/* 1643 */     throw new IllegalArgumentException("Unsupported type: " + typeClass);
/*      */   }
/*      */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.apache.felix.scr-2.2.6.jar!\org\apache\felix\scr\impl\metadata\ComponentMetadata.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */