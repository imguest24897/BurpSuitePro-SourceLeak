/*     */ package org.apache.felix.scr.impl.inject.internal;
/*     */ 
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.Field;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Optional;
/*     */ import java.util.concurrent.atomic.AtomicInteger;
/*     */ import org.apache.felix.scr.impl.inject.ComponentConstructor;
/*     */ import org.apache.felix.scr.impl.inject.OpenStatus;
/*     */ import org.apache.felix.scr.impl.inject.RefPair;
/*     */ import org.apache.felix.scr.impl.inject.ScrComponentContext;
/*     */ import org.apache.felix.scr.impl.inject.ValueUtils;
/*     */ import org.apache.felix.scr.impl.inject.field.FieldUtils;
/*     */ import org.apache.felix.scr.impl.logger.ComponentLogger;
/*     */ import org.apache.felix.scr.impl.logger.InternalLogger;
/*     */ import org.apache.felix.scr.impl.metadata.ComponentMetadata;
/*     */ import org.apache.felix.scr.impl.metadata.ReferenceMetadata;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ComponentConstructorImpl<S>
/*     */   implements ComponentConstructor<S>
/*     */ {
/*     */   private final Field[] activationFields;
/*     */   private final ValueUtils.ValueType[] activationFieldTypes;
/*     */   private final Constructor<S> constructor;
/*     */   private final ValueUtils.ValueType[] constructorArgTypes;
/*     */   private final ReferenceMetadata[] constructorRefs;
/*     */   
/*     */   public ComponentConstructorImpl(ComponentMetadata componentMetadata, Class<S> componentClass, ComponentLogger logger) {
/*  62 */     Map<Integer, List<ReferenceMetadata>> paramMap = (componentMetadata.getNumberOfConstructorParameters() > 0) ? new HashMap<>() : null;
/*  63 */     for (ReferenceMetadata refMetadata : componentMetadata.getDependencies()) {
/*     */       
/*  65 */       if (refMetadata.getParameterIndex() != null) {
/*     */         
/*  67 */         int index = refMetadata.getParameterIndex().intValue();
/*  68 */         if (index > componentMetadata.getNumberOfConstructorParameters()) {
/*     */ 
/*     */ 
/*     */           
/*  72 */           logger.log(InternalLogger.Level.ERROR, "Ignoring reference {0} for constructor injection. Parameter index is too high.", null, new Object[] { refMetadata
/*     */                 
/*  74 */                 .getName() });
/*     */         }
/*  76 */         else if (!refMetadata.isStatic()) {
/*     */ 
/*     */           
/*  79 */           logger.log(InternalLogger.Level.ERROR, "Ignoring reference {0} for constructor injection. Reference is dynamic.", null, new Object[] { refMetadata
/*     */                 
/*  81 */                 .getName() });
/*     */         } 
/*  83 */         List<ReferenceMetadata> list = paramMap.get(Integer.valueOf(index));
/*  84 */         if (list == null) {
/*     */           
/*  86 */           list = new ArrayList<>();
/*  87 */           paramMap.put(Integer.valueOf(index), list);
/*     */         } 
/*  89 */         list.add(refMetadata);
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/*  94 */     Constructor<S> found = null;
/*  95 */     ValueUtils.ValueType[] foundTypes = null;
/*  96 */     ReferenceMetadata[] foundRefs = null;
/*     */     
/*  98 */     Constructor[] arrayOfConstructor = (Constructor[])componentClass.getConstructors();
/*  99 */     for (Constructor<?> c : arrayOfConstructor) {
/*     */ 
/*     */       
/* 102 */       if ((c.getParameterTypes()).length == componentMetadata.getNumberOfConstructorParameters()) {
/*     */         
/* 104 */         Constructor<S> check = (Constructor)c;
/* 105 */         logger.log(InternalLogger.Level.DEBUG, "Checking constructor {0}", null, new Object[] { check });
/*     */ 
/*     */ 
/*     */         
/* 109 */         if (componentMetadata.getNumberOfConstructorParameters() > 0) {
/*     */           
/* 111 */           boolean hasFailure = false;
/* 112 */           Class<?>[] argTypes = check.getParameterTypes();
/* 113 */           foundTypes = new ValueUtils.ValueType[argTypes.length];
/* 114 */           foundRefs = new ReferenceMetadata[argTypes.length];
/* 115 */           for (int i = 0; i < foundTypes.length; i++) {
/*     */             
/* 117 */             List<ReferenceMetadata> refs = paramMap.get(Integer.valueOf(i));
/* 118 */             if (refs == null) {
/*     */               
/* 120 */               foundTypes[i] = ValueUtils.getValueType(argTypes[i]);
/* 121 */               if (foundTypes[i] == ValueUtils.ValueType.ignore)
/*     */               {
/* 123 */                 logger.log(InternalLogger.Level.DEBUG, "Constructor argument type {0} not supported by constructor injection: {1}", null, new Object[] {
/*     */                       
/* 125 */                       Integer.valueOf(i), argTypes[i]
/*     */                     });
/*     */               }
/*     */             } else {
/*     */               
/* 130 */               for (ReferenceMetadata ref : refs) {
/*     */                 
/* 132 */                 ValueUtils.ValueType t = ValueUtils.getReferenceValueType(componentClass, ref, argTypes[i], null, logger);
/* 133 */                 if (t != null) {
/*     */                   
/* 135 */                   foundTypes[i] = t;
/* 136 */                   foundRefs[i] = ref;
/*     */                   break;
/*     */                 } 
/*     */               } 
/* 140 */               if (foundTypes[i] == null) {
/*     */                 
/* 142 */                 foundTypes[i] = ValueUtils.ValueType.ignore;
/*     */ 
/*     */               
/*     */               }
/* 146 */               else if (refs.size() > 1) {
/*     */                 
/* 148 */                 logger.log(InternalLogger.Level.ERROR, "Several references for constructor injection of parameter {0}. Only {1} will be used out of: {2}.", null, new Object[] {
/*     */                       
/* 150 */                       Integer.valueOf(i), foundRefs[i].getName(), getNames(refs)
/*     */                     });
/*     */               } 
/*     */             } 
/*     */             
/* 155 */             if (foundTypes[i] == ValueUtils.ValueType.ignore) {
/*     */               
/* 157 */               hasFailure = true;
/*     */               break;
/*     */             } 
/*     */           } 
/* 161 */           if (!hasFailure) {
/*     */             
/* 163 */             found = check;
/*     */ 
/*     */             
/*     */             break;
/*     */           } 
/*     */         } else {
/* 169 */           found = (Constructor)c;
/*     */           
/*     */           break;
/*     */         } 
/*     */       } 
/*     */     } 
/* 175 */     this.constructor = found;
/* 176 */     this.constructorArgTypes = foundTypes;
/* 177 */     this.constructorRefs = foundRefs;
/*     */ 
/*     */     
/* 180 */     if (componentMetadata.getActivationFields() != null) {
/*     */       
/* 182 */       this.activationFieldTypes = new ValueUtils.ValueType[componentMetadata.getActivationFields().size()];
/* 183 */       this.activationFields = new Field[this.activationFieldTypes.length];
/*     */       
/* 185 */       int index = 0;
/* 186 */       for (String fieldName : componentMetadata.getActivationFields())
/*     */       {
/* 188 */         FieldUtils.FieldSearchResult result = FieldUtils.searchField(componentClass, fieldName, logger);
/* 189 */         if (result == null || result.field == null) {
/*     */           
/* 191 */           this.activationFieldTypes[index] = null;
/* 192 */           this.activationFields[index] = null;
/*     */ 
/*     */         
/*     */         }
/* 196 */         else if (result.usable) {
/*     */           
/* 198 */           this.activationFieldTypes[index] = ValueUtils.getValueType(result.field.getType());
/* 199 */           this.activationFields[index] = result.field;
/*     */         }
/*     */         else {
/*     */           
/* 203 */           this.activationFieldTypes[index] = ValueUtils.ValueType.ignore;
/* 204 */           this.activationFields[index] = null;
/*     */         } 
/*     */ 
/*     */         
/* 208 */         index++;
/*     */       }
/*     */     
/*     */     } else {
/*     */       
/* 213 */       this.activationFieldTypes = ValueUtils.EMPTY_VALUE_TYPES;
/* 214 */       this.activationFields = null;
/*     */     } 
/*     */     
/* 217 */     if (this.constructor == null) {
/*     */       
/* 219 */       logger.log(InternalLogger.Level.ERROR, "Constructor with {0} arguments not found. Component will fail.", null, new Object[] {
/*     */             
/* 221 */             Integer.valueOf(componentMetadata.getNumberOfConstructorParameters())
/*     */           });
/*     */     } else {
/*     */       
/* 225 */       logger.log(InternalLogger.Level.DEBUG, "Found constructor with {0} arguments : {1}", null, new Object[] {
/*     */             
/* 227 */             Integer.valueOf(componentMetadata.getNumberOfConstructorParameters()), found
/*     */           });
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <T> S newInstance(ScrComponentContext componentContext, Map<ReferenceMetadata, OpenStatus<S, ?>> parameterMap) throws Exception {
/*     */     Object[] args;
/* 245 */     if (this.constructor == null)
/*     */     {
/* 247 */       throw new InstantiationException("Constructor not found.");
/*     */     }
/*     */ 
/*     */     
/* 251 */     if (this.constructorArgTypes == null) {
/*     */       
/* 253 */       args = null;
/*     */     }
/*     */     else {
/*     */       
/* 257 */       args = new Object[this.constructorArgTypes.length];
/* 258 */       for (int j = 0; j < args.length; j++) {
/*     */         
/* 260 */         ReferenceMetadata refMetadata = this.constructorRefs[j];
/* 261 */         OpenStatus<S, ?> status = (refMetadata == null) ? null : parameterMap.get(refMetadata);
/*     */         
/* 263 */         if (refMetadata == null) {
/*     */           
/* 265 */           args[j] = ValueUtils.getValue(this.constructor.getDeclaringClass().getName(), this.constructorArgTypes[j], this.constructor
/*     */               
/* 267 */               .getParameterTypes()[j], componentContext, null, refMetadata);
/*     */ 
/*     */         
/*     */         }
/*     */         else {
/*     */ 
/*     */           
/* 274 */           List<Object> refs = refMetadata.isMultiple() ? new ArrayList() : null;
/* 275 */           Object<?> ref = null;
/* 276 */           for (RefPair<S, ?> refPair : (Iterable<RefPair<S, ?>>)status.getRefs(new AtomicInteger())) {
/*     */             
/* 278 */             if (!refPair.isDeleted() && !refPair.isFailed()) {
/*     */               
/* 280 */               if (refPair.getServiceObject(componentContext) == null && (this.constructorArgTypes[j] == ValueUtils.ValueType.ref_serviceType || this.constructorArgTypes[j] == ValueUtils.ValueType.ref_tuple || this.constructorArgTypes[j] == ValueUtils.ValueType.ref_logger || this.constructorArgTypes[j] == ValueUtils.ValueType.ref_formatterLogger || this.constructorArgTypes[j] == ValueUtils.ValueType.ref_optional))
/*     */               {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */                 
/* 287 */                 refPair.getServiceObject(componentContext, componentContext.getBundleContext());
/*     */               }
/* 289 */               ref = (Object<?>)ValueUtils.getValue(this.constructor.getDeclaringClass().getName(), this.constructorArgTypes[j], this.constructor
/*     */                   
/* 291 */                   .getParameterTypes()[j], componentContext, refPair, refMetadata);
/*     */ 
/*     */ 
/*     */               
/* 295 */               if (refMetadata.isMultiple() && ref != null)
/*     */               {
/* 297 */                 refs.add(ref);
/*     */               }
/*     */             } 
/*     */           } 
/*     */           
/* 302 */           if (ref == null && this.constructorArgTypes[j] == ValueUtils.ValueType.ref_optional)
/*     */           {
/* 304 */             ref = Optional.empty();
/*     */           }
/*     */           
/* 307 */           if (!refMetadata.isMultiple()) {
/*     */             
/* 309 */             if (ref == null && !refMetadata.isOptional())
/*     */             {
/* 311 */               throw new InstantiationException("Unable to get service for reference " + refMetadata.getName());
/*     */             }
/* 313 */             args[j] = ref;
/*     */           }
/*     */           else {
/*     */             
/* 317 */             if (refs.isEmpty() && !refMetadata.isOptional())
/*     */             {
/* 319 */               throw new InstantiationException("Unable to get service for reference " + refMetadata.getName());
/*     */             }
/* 321 */             args[j] = refs;
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/* 326 */     S component = this.constructor.newInstance(args);
/*     */ 
/*     */     
/* 329 */     for (int i = 0; i < this.activationFieldTypes.length; i++) {
/*     */       
/* 331 */       if (this.activationFieldTypes[i] != null && this.activationFieldTypes[i] != ValueUtils.ValueType.ignore) {
/*     */         
/* 333 */         Object value = ValueUtils.getValue(this.constructor.getDeclaringClass().getName(), this.activationFieldTypes[i], this.activationFields[i]
/*     */             
/* 335 */             .getType(), componentContext, null, null);
/*     */ 
/*     */ 
/*     */         
/* 339 */         FieldUtils.setField(this.activationFields[i], component, value, componentContext.getLogger());
/*     */       } 
/*     */     } 
/*     */     
/* 343 */     return component;
/*     */   }
/*     */ 
/*     */   
/*     */   private String getNames(List<ReferenceMetadata> refs) {
/* 348 */     StringBuilder sb = new StringBuilder();
/* 349 */     for (ReferenceMetadata refMetadata : refs) {
/*     */       
/* 351 */       if (sb.length() == 0) {
/*     */         
/* 353 */         sb.append(refMetadata.getName());
/*     */         
/*     */         continue;
/*     */       } 
/* 357 */       sb.append(", ").append(refMetadata.getName());
/*     */     } 
/*     */     
/* 360 */     return sb.toString();
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.apache.felix.scr-2.2.6.jar!\org\apache\felix\scr\impl\inject\internal\ComponentConstructorImpl.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */