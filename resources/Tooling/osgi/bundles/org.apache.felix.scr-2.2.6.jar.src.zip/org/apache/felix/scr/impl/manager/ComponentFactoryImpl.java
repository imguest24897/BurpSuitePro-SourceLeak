/*     */ package org.apache.felix.scr.impl.manager;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Dictionary;
/*     */ import java.util.HashMap;
/*     */ import java.util.Hashtable;
/*     */ import java.util.IdentityHashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.apache.felix.scr.component.ExtFactoryComponentInstance;
/*     */ import org.apache.felix.scr.impl.inject.ComponentMethods;
/*     */ import org.apache.felix.scr.impl.inject.RefPair;
/*     */ import org.apache.felix.scr.impl.logger.InternalLogger;
/*     */ import org.apache.felix.scr.impl.metadata.ReferenceMetadata;
/*     */ import org.apache.felix.scr.impl.metadata.TargetedPID;
/*     */ import org.osgi.service.component.ComponentException;
/*     */ import org.osgi.service.component.ComponentFactory;
/*     */ import org.osgi.service.component.ComponentInstance;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ComponentFactoryImpl<S>
/*     */   extends AbstractComponentManager<S>
/*     */   implements ComponentFactory<S>, ComponentContainer<S>
/*     */ {
/*     */   private final Map<SingleComponentManager<S>, SingleComponentManager<S>> m_componentInstances;
/*     */   private volatile Map<String, Object> m_configuration;
/*     */   private volatile boolean m_hasConfiguration;
/*  90 */   protected volatile long m_changeCount = -1L;
/*     */   
/*     */   protected TargetedPID m_targetedPID;
/*     */ 
/*     */   
/*     */   public ComponentFactoryImpl(ComponentContainer<S> container, ComponentMethods<S> componentMethods) {
/*  96 */     super(container, componentMethods);
/*  97 */     this.m_componentInstances = new IdentityHashMap<>();
/*  98 */     this.m_configuration = new HashMap<>();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean verifyDependencyManagers() {
/* 105 */     if (!getComponentMetadata().isPersistentFactoryComponent())
/*     */     {
/* 107 */       return super.verifyDependencyManagers();
/*     */     }
/* 109 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isFactory() {
/* 115 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ComponentInstance<S> newInstance(Dictionary<String, ?> dictionary) {
/*     */     ComponentInstance<S> instance;
/* 124 */     SingleComponentManager<S> cm = createComponentManager();
/* 125 */     getLogger().log(InternalLogger.Level.DEBUG, "Creating new instance from component factory", null);
/*     */ 
/*     */     
/* 128 */     cm.setFactoryProperties(dictionary);
/*     */     
/* 130 */     cm.reconfigure(this.m_configuration, false, (TargetedPID)null);
/*     */     
/* 132 */     cm.enableInternal();
/*     */ 
/*     */     
/* 135 */     if (getComponentMetadata().isPersistentFactoryComponent()) {
/*     */       
/* 137 */       ModifyComponentInstance<S> modifyComponentInstance = new ModifyComponentInstance<>(cm);
/*     */     }
/*     */     else {
/*     */       
/* 141 */       instance = cm.getComponentInstance();
/* 142 */       if (instance == null || instance.getInstance() == null) {
/*     */ 
/*     */         
/* 145 */         cm.dispose(5);
/* 146 */         throw new ComponentException("Failed activating component");
/*     */       } 
/*     */     } 
/*     */     
/* 150 */     synchronized (this.m_componentInstances) {
/*     */       
/* 152 */       this.m_componentInstances.put(cm, cm);
/*     */     } 
/*     */     
/* 155 */     return instance;
/*     */   }
/*     */   
/*     */   private static class ModifyComponentInstance<S>
/*     */     implements ExtFactoryComponentInstance<S>
/*     */   {
/*     */     private final SingleComponentManager<S> cm;
/*     */     
/*     */     public ModifyComponentInstance(SingleComponentManager<S> cm) {
/* 164 */       this.cm = cm;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void dispose() {
/* 170 */       this.cm.dispose();
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public S getInstance() {
/* 176 */       ComponentInstance<S> componentInstance = this.cm.getComponentInstance();
/* 177 */       return (componentInstance == null) ? null : (S)componentInstance.getInstance();
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void modify(Dictionary<String, ?> properties) {
/* 183 */       this.cm.setFactoryProperties(properties);
/* 184 */       this.cm.reconfigure(false);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object object) {
/* 204 */     if (!(object instanceof ComponentFactoryImpl))
/*     */     {
/* 206 */       return false;
/*     */     }
/*     */     
/* 209 */     ComponentFactoryImpl<?> other = (ComponentFactoryImpl)object;
/* 210 */     return getComponentMetadata().getName().equals(other.getComponentMetadata().getName());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 221 */     return getComponentMetadata().getName().hashCode();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void deleteComponent(int reason) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String[] getProvidedServices() {
/* 240 */     return new String[] { ComponentFactory.class.getName() };
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean hasConfiguration() {
/* 246 */     return this.m_hasConfiguration;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<String, Object> getProperties() {
/* 257 */     Map<String, Object> props = new HashMap<>();
/*     */ 
/*     */     
/* 260 */     List<ReferenceMetadata> depMetaData = getComponentMetadata().getDependencies();
/* 261 */     for (ReferenceMetadata rm : depMetaData) {
/*     */       
/* 263 */       if (rm.getTarget() != null)
/*     */       {
/* 265 */         props.put(rm.getTargetPropertyName(), rm.getTarget());
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 270 */     for (String key : this.m_configuration.keySet()) {
/*     */       
/* 272 */       if (key.endsWith(".target"))
/*     */       {
/* 274 */         props.put(key, this.m_configuration.get(key));
/*     */       }
/*     */     } 
/*     */     
/* 278 */     return props;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setServiceProperties(Dictionary<String, ?> serviceProperties) {
/* 284 */     throw new IllegalStateException("ComponentFactory service properties are immutable");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void postRegister() {}
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void preDeregister() {}
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Dictionary<String, Object> getServiceProperties() {
/* 302 */     Dictionary<String, Object> props = new Hashtable<>(getComponentMetadata().getFactoryProperties());
/*     */ 
/*     */     
/* 305 */     props.put("component.name", getComponentMetadata().getName());
/* 306 */     props.put("component.factory", getComponentMetadata().getFactoryIdentifier());
/*     */     
/* 308 */     props.put("service.vendor", "The Apache Software Foundation");
/*     */     
/* 310 */     return props;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean collectDependencies(ComponentContextImpl<S> componentContext) {
/* 316 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   <T> boolean invokeUpdatedMethod(DependencyManager<S, T> dependencyManager, RefPair<S, T> ref, int trackingCount) {
/* 322 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   <T> void invokeBindMethod(DependencyManager<S, T> dependencyManager, RefPair<S, T> reference, int trackingCount) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   <T> void invokeUnbindMethod(DependencyManager<S, T> dependencyManager, RefPair<S, T> oldRef, int trackingCount) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void dispose(int reason) {
/* 347 */     List<AbstractComponentManager<S>> cms = new ArrayList<>();
/* 348 */     getComponentManagers(this.m_componentInstances, cms);
/* 349 */     for (AbstractComponentManager<S> acm : cms)
/*     */     {
/* 351 */       acm.dispose(reason);
/*     */     }
/*     */     
/* 354 */     synchronized (this.m_componentInstances) {
/*     */       
/* 356 */       this.m_componentInstances.clear();
/*     */     } 
/*     */ 
/*     */     
/* 360 */     super.dispose(reason);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void disposed(SingleComponentManager<S> component) {
/* 367 */     synchronized (this.m_componentInstances) {
/*     */       
/* 369 */       this.m_componentInstances.remove(component);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private SingleComponentManager<S> createComponentManager() {
/* 385 */     return new SingleComponentManager<>(this, getComponentMethods(), !getComponentMetadata().isPersistentFactoryComponent());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void getComponentManagers(Map<?, SingleComponentManager<S>> componentMap, List<AbstractComponentManager<S>> componentManagers) {
/* 391 */     if (componentMap != null)
/*     */     {
/* 393 */       synchronized (componentMap) {
/*     */         
/* 395 */         componentManagers.addAll(componentMap.values());
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public TargetedPID getConfigurationTargetedPID(TargetedPID pid, TargetedPID factoryPid) {
/* 402 */     return this.m_targetedPID;
/*     */   }
/*     */ 
/*     */   
/*     */   public void reconfigure(Map<String, Object> configuration, boolean configurationDeleted, TargetedPID factoryPid) {
/*     */     List<SingleComponentManager<S>> cms;
/* 408 */     if (factoryPid != null) {
/*     */       return;
/*     */     }
/*     */     
/* 412 */     this.m_configuration = configuration;
/*     */     
/* 414 */     synchronized (this.m_componentInstances) {
/*     */       
/* 416 */       cms = new ArrayList<>(this.m_componentInstances.keySet());
/*     */     } 
/* 418 */     for (SingleComponentManager<S> cm : cms)
/*     */     {
/* 420 */       cm.reconfigure(configuration, configurationDeleted, factoryPid);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void getComponentManagers(List<AbstractComponentManager<S>> cms) {
/* 428 */     synchronized (this.m_componentInstances) {
/*     */       
/* 430 */       cms.addAll(this.m_componentInstances.keySet());
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.apache.felix.scr-2.2.6.jar!\org\apache\felix\scr\impl\manager\ComponentFactoryImpl.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */