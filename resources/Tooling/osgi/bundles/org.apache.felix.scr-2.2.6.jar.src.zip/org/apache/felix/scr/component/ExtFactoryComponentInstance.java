package org.apache.felix.scr.component;

import java.util.Dictionary;
import org.osgi.service.component.ComponentInstance;

public interface ExtFactoryComponentInstance<S> extends ComponentInstance<S> {
  void modify(Dictionary<String, ?> paramDictionary);
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.apache.felix.scr-2.2.6.jar!\org\apache\felix\scr\component\ExtFactoryComponentInstance.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */