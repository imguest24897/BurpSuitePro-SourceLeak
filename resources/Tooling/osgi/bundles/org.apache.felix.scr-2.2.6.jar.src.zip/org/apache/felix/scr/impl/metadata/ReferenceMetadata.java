/*     */ package org.apache.felix.scr.impl.metadata;
/*     */ 
/*     */ import java.io.DataInputStream;
/*     */ import java.io.DataOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.util.Set;
/*     */ import java.util.TreeSet;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ReferenceMetadata
/*     */ {
/*     */   public enum ReferenceScope
/*     */   {
/*  38 */     bundle, prototype, prototype_required;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 145 */   private ReferenceScope m_scope = ReferenceScope.bundle;
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean m_isStatic = true;
/*     */ 
/*     */   
/*     */   private boolean m_isOptional = false;
/*     */ 
/*     */   
/*     */   private boolean m_isMultiple = false;
/*     */ 
/*     */   
/*     */   private boolean m_isReluctant = true;
/*     */ 
/*     */   
/*     */   private boolean m_isReplace = true;
/*     */ 
/*     */   
/*     */   private boolean m_validated = false;
/*     */ 
/*     */   
/* 167 */   private static final Set<String> CARDINALITY_VALID = new TreeSet<>(); static {
/* 168 */     CARDINALITY_VALID.add("0..1");
/* 169 */     CARDINALITY_VALID.add("0..n");
/* 170 */     CARDINALITY_VALID.add("1..1");
/* 171 */     CARDINALITY_VALID.add("1..n");
/*     */   }
/* 173 */   private static final Set<String> POLICY_VALID = new TreeSet<>(); static {
/* 174 */     POLICY_VALID.add("dynamic");
/* 175 */     POLICY_VALID.add("static");
/*     */   }
/* 177 */   private static final Set<String> POLICY_OPTION_VALID = new TreeSet<>(); static {
/* 178 */     POLICY_OPTION_VALID.add("reluctant");
/* 179 */     POLICY_OPTION_VALID.add("greedy");
/*     */   }
/* 181 */   private static final Set<String> FIELD_STRATEGY_VALID = new TreeSet<>(); static {
/* 182 */     FIELD_STRATEGY_VALID.add("replace");
/* 183 */     FIELD_STRATEGY_VALID.add("update");
/*     */   }
/* 185 */   public static final String CARDINALITY_0_1 = "0..1"; public static final String CARDINALITY_0_N = "0..n"; public static final String CARDINALITY_1_1 = "1..1"; public static final String CARDINALITY_1_N = "1..n"; public static final String POLICY_STATIC = "static"; public static final String POLICY_DYNAMIC = "dynamic"; public static final String POLICY_OPTION_RELUCTANT = "reluctant"; public static final String POLICY_OPTION_GREEDY = "greedy"; private static final Set<String> FIELD_VALUE_TYPE_VALID = new TreeSet<>(); private static final String FIELD_STRATEGY_UPDATE = "update"; private static final String FIELD_STRATEGY_REPLACE = "replace"; public static final String FIELD_VALUE_TYPE_SERVICE = "service"; public static final String FIELD_VALUE_TYPE_PROPERTIES = "properties"; public static final String FIELD_VALUE_TYPE_REFERENCE = "reference"; public static final String FIELD_VALUE_TYPE_SERVICEOBJECTS = "serviceobjects"; public static final String FIELD_VALUE_TYPE_TUPLE = "tuple"; public static final String CONDITION_SERVICE_CLASS = "org.osgi.service.condition.Condition"; static {
/* 186 */     FIELD_VALUE_TYPE_VALID.add("properties");
/* 187 */     FIELD_VALUE_TYPE_VALID.add("reference");
/* 188 */     FIELD_VALUE_TYPE_VALID.add("service");
/* 189 */     FIELD_VALUE_TYPE_VALID.add("serviceobjects");
/* 190 */     FIELD_VALUE_TYPE_VALID.add("tuple");
/*     */   }
/*     */   public static final String CONDITION_TRUE_FILTER = "(osgi.condition.id=true)"; public static final String REFERENCE_NAME_SATISFYING_CONDITION = "osgi.ds.satisfying.condition"; private String m_name; private String m_interface; private String m_cardinality; private String m_target; private String m_bind; private String m_updated; private String m_unbind; private String m_field;
/*     */   private String m_field_option;
/*     */   private String m_collection_type;
/*     */   private String m_policy;
/*     */   private String m_policy_option;
/*     */   private String m_scopeName;
/*     */   private String m_parameter;
/*     */   private Integer m_parameterIndex;
/*     */   
/*     */   public void setName(String name) {
/* 202 */     if (this.m_validated) {
/*     */       return;
/*     */     }
/*     */ 
/*     */     
/* 207 */     this.m_name = name;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setInterface(String interfaceName) {
/* 218 */     if (this.m_validated) {
/*     */       return;
/*     */     }
/*     */ 
/*     */     
/* 223 */     this.m_interface = interfaceName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setCardinality(String cardinality) {
/* 235 */     if (this.m_validated) {
/*     */       return;
/*     */     }
/*     */ 
/*     */     
/* 240 */     this.m_cardinality = cardinality;
/*     */ 
/*     */     
/* 243 */     this.m_isOptional = ("0..1".equals(cardinality) || "0..n".equals(cardinality));
/* 244 */     this.m_isMultiple = ("0..n".equals(cardinality) || "1..n".equals(cardinality));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setPolicy(String policy) {
/* 255 */     if (this.m_validated) {
/*     */       return;
/*     */     }
/*     */ 
/*     */     
/* 260 */     this.m_policy = policy;
/*     */ 
/*     */     
/* 263 */     this.m_isStatic = "static".equals(policy);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setPolicyOption(String policyOption) {
/* 274 */     if (this.m_validated) {
/*     */       return;
/*     */     }
/*     */ 
/*     */     
/* 279 */     this.m_policy_option = policyOption;
/*     */ 
/*     */     
/* 282 */     this.m_isReluctant = "reluctant".equals(policyOption);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setTarget(String target) {
/* 293 */     if (this.m_validated) {
/*     */       return;
/*     */     }
/*     */ 
/*     */     
/* 298 */     this.m_target = (target == null || target.length() == 0) ? null : target;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setBind(String bind) {
/* 309 */     if (this.m_validated) {
/*     */       return;
/*     */     }
/*     */ 
/*     */     
/* 314 */     this.m_bind = bind;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setUpdated(String updated) {
/* 325 */     if (this.m_validated) {
/*     */       return;
/*     */     }
/*     */ 
/*     */     
/* 330 */     this.m_updated = updated;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setUnbind(String unbind) {
/* 341 */     if (this.m_validated) {
/*     */       return;
/*     */     }
/*     */ 
/*     */     
/* 346 */     this.m_unbind = unbind;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setField(String field) {
/* 357 */     if (this.m_validated) {
/*     */       return;
/*     */     }
/*     */ 
/*     */     
/* 362 */     this.m_field = field;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setFieldOption(String strategy) {
/* 372 */     if (this.m_validated) {
/*     */       return;
/*     */     }
/*     */ 
/*     */     
/* 377 */     this.m_field_option = strategy;
/*     */     
/* 379 */     this.m_isReplace = "replace".equals(strategy);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setCollectionType(String valuetype) {
/* 389 */     if (this.m_validated) {
/*     */       return;
/*     */     }
/*     */ 
/*     */     
/* 394 */     this.m_collection_type = valuetype;
/*     */   }
/*     */   
/*     */   public void setScope(String scopeName) {
/* 398 */     if (this.m_validated) {
/*     */       return;
/*     */     }
/*     */     
/* 402 */     this.m_scopeName = scopeName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setParameter(String val) {
/* 411 */     if (this.m_validated) {
/*     */       return;
/*     */     }
/*     */     
/* 415 */     this.m_parameter = val;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getName() {
/* 427 */     return this.m_name;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getInterface() {
/* 438 */     return this.m_interface;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getCardinality() {
/* 449 */     return this.m_cardinality;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getPolicy() {
/* 460 */     return this.m_policy;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getPolicyOption() {
/* 471 */     return this.m_policy_option;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getTarget() {
/* 482 */     return this.m_target;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getBind() {
/* 494 */     return this.m_bind;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getUpdated() {
/* 506 */     return this.m_updated;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getUnbind() {
/* 518 */     return this.m_unbind;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getField() {
/* 530 */     return this.m_field;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getFieldOption() {
/* 542 */     return this.m_field_option;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getCollectionType() {
/* 553 */     return this.m_collection_type;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Integer getParameterIndex() {
/* 566 */     return this.m_parameterIndex;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isStatic() {
/* 578 */     return this.m_isStatic;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isOptional() {
/* 588 */     return this.m_isOptional;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isMultiple() {
/* 599 */     return this.m_isMultiple;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isReluctant() {
/* 610 */     return this.m_isReluctant;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isReplace() {
/* 620 */     return this.m_isReplace;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getTargetPropertyName() {
/* 632 */     return getName() + ".target";
/*     */   }
/*     */ 
/*     */   
/*     */   public String getMinCardinalityName() {
/* 637 */     return getName() + ".cardinality.minimum";
/*     */   }
/*     */ 
/*     */   
/*     */   public ReferenceScope getScope() {
/* 642 */     return this.m_scope;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void validate(ComponentMetadata componentMetadata) {
/* 651 */     DSVersion dsVersion = componentMetadata.getDSVersion();
/*     */     
/* 653 */     if (this.m_name == null) {
/*     */ 
/*     */       
/* 656 */       if (!dsVersion.isDS11())
/*     */       {
/* 658 */         throw componentMetadata.validationFailure("A name must be declared for the reference");
/*     */       }
/* 660 */       setName(getInterface());
/*     */     } 
/*     */     
/* 663 */     if (this.m_interface == null)
/*     */     {
/* 665 */       throw componentMetadata.validationFailure("An interface must be declared for the reference");
/*     */     }
/*     */ 
/*     */     
/* 669 */     if (this.m_cardinality == null) {
/*     */       
/* 671 */       setCardinality("1..1");
/*     */     }
/* 673 */     else if (!CARDINALITY_VALID.contains(this.m_cardinality)) {
/*     */       
/* 675 */       throw componentMetadata.validationFailure("Cardinality must be one of " + CARDINALITY_VALID);
/*     */     } 
/*     */     
/* 678 */     if (this.m_policy == null) {
/*     */       
/* 680 */       setPolicy("static");
/*     */     }
/* 682 */     else if (!POLICY_VALID.contains(this.m_policy)) {
/*     */       
/* 684 */       throw componentMetadata.validationFailure("Policy must be one of " + POLICY_VALID);
/*     */     } 
/*     */     
/* 687 */     if (this.m_policy_option == null) {
/*     */       
/* 689 */       setPolicyOption("reluctant");
/*     */     } else {
/* 691 */       if (!POLICY_OPTION_VALID.contains(this.m_policy_option))
/*     */       {
/* 693 */         throw componentMetadata.validationFailure("Policy option must be one of " + POLICY_OPTION_VALID);
/*     */       }
/* 695 */       if (!dsVersion.isDS12() && !"reluctant".equals(this.m_policy_option))
/*     */       {
/* 697 */         throw componentMetadata.validationFailure("Policy option must be reluctant for DS < 1.2");
/*     */       }
/*     */     } 
/* 700 */     if (this.m_scopeName != null) {
/* 701 */       if (!dsVersion.isDS13())
/*     */       {
/* 703 */         throw componentMetadata.validationFailure("reference scope can be set only for DS >= 1.3");
/*     */       }
/*     */       
/*     */       try {
/* 707 */         this.m_scope = ReferenceScope.valueOf(this.m_scopeName);
/*     */       }
/* 709 */       catch (IllegalArgumentException e) {
/*     */         
/* 711 */         throw componentMetadata.validationFailure("reference scope must be 'bundle' or 'prototype' not " + this.m_scopeName);
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 717 */     if (this.m_updated != null && !dsVersion.isDS12() && dsVersion != DSVersion.DS11Felix)
/*     */     {
/*     */       
/* 720 */       throw componentMetadata.validationFailure("updated method declaration requires DS 1.2 or later namespace ");
/*     */     }
/*     */ 
/*     */     
/* 724 */     if (this.m_field != null) {
/*     */ 
/*     */       
/* 727 */       if (!dsVersion.isDS13())
/*     */       {
/* 729 */         throw componentMetadata.validationFailure("Field reference requires DS >= 1.3");
/*     */       }
/*     */ 
/*     */       
/* 733 */       if (this.m_field_option == null) {
/*     */         
/* 735 */         setFieldOption("replace");
/*     */       }
/* 737 */       else if (!FIELD_STRATEGY_VALID.contains(this.m_field_option)) {
/*     */         
/* 739 */         throw componentMetadata.validationFailure("Field strategy must be one of " + FIELD_STRATEGY_VALID);
/*     */       } 
/* 741 */       if (!this.m_isMultiple)
/*     */       {
/*     */         
/* 744 */         if (this.m_field_option.equals("update"))
/*     */         {
/* 746 */           throw componentMetadata.validationFailure("Field strategy update not allowed for unary field references.");
/*     */         }
/*     */       }
/*     */ 
/*     */       
/* 751 */       if (this.m_collection_type != null && 
/* 752 */         !FIELD_VALUE_TYPE_VALID.contains(this.m_collection_type))
/*     */       {
/* 754 */         throw componentMetadata.validationFailure("Field value type must be one of " + FIELD_VALUE_TYPE_VALID);
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 759 */     if (this.m_parameter != null) {
/*     */ 
/*     */       
/* 762 */       if (!dsVersion.isDS14())
/*     */       {
/* 764 */         throw componentMetadata.validationFailure("Reference parameter requires DS >= 1.4");
/*     */       }
/*     */       
/*     */       try {
/* 768 */         this.m_parameterIndex = Integer.valueOf(this.m_parameter);
/*     */       }
/* 770 */       catch (NumberFormatException nfe) {
/*     */         
/* 772 */         throw componentMetadata.validationFailure("Reference parameter is not a number: " + this.m_parameter);
/*     */       } 
/* 774 */       if (this.m_parameterIndex.intValue() < 0)
/*     */       {
/* 776 */         throw componentMetadata.validationFailure("Reference parameter value must be zero or higher: " + this.m_parameter);
/*     */       }
/*     */       
/* 779 */       if (this.m_collection_type == null) {
/*     */         
/* 781 */         setCollectionType("service");
/*     */       }
/* 783 */       else if (!FIELD_VALUE_TYPE_VALID.contains(this.m_collection_type)) {
/*     */         
/* 785 */         throw componentMetadata.validationFailure("Collection value type must be one of " + FIELD_VALUE_TYPE_VALID);
/*     */       } 
/*     */     } 
/*     */     
/* 789 */     this.m_validated = true;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getDebugInfo() {
/* 794 */     return getName() + "interface=" + 
/* 795 */       getInterface() + ", filter=" + 
/* 796 */       getTarget() + ", policy=" + 
/* 797 */       getPolicy() + ", cardinality=" + 
/* 798 */       getCardinality() + ", bind=" + 
/* 799 */       getBind() + ", unbind=" + 
/* 800 */       getUnbind() + ", updated=" + 
/* 801 */       getUpdated() + ", field=" + 
/* 802 */       getField() + ", field-option=" + 
/* 803 */       getFieldOption() + ", collection-type=" + 
/* 804 */       getCollectionType() + ", parameter=" + 
/*     */       
/* 806 */       getParameterIndex();
/*     */   }
/*     */ 
/*     */   
/*     */   void collectStrings(Set<String> strings) {
/* 811 */     MetadataStoreHelper.addString(this.m_bind, strings);
/* 812 */     MetadataStoreHelper.addString(this.m_cardinality, strings);
/* 813 */     MetadataStoreHelper.addString(this.m_collection_type, strings);
/* 814 */     MetadataStoreHelper.addString(this.m_field, strings);
/* 815 */     MetadataStoreHelper.addString(this.m_field_option, strings);
/* 816 */     MetadataStoreHelper.addString(this.m_interface, strings);
/* 817 */     MetadataStoreHelper.addString(this.m_name, strings);
/* 818 */     MetadataStoreHelper.addString(this.m_parameter, strings);
/* 819 */     MetadataStoreHelper.addString(this.m_policy, strings);
/* 820 */     MetadataStoreHelper.addString(this.m_policy_option, strings);
/* 821 */     MetadataStoreHelper.addString(this.m_scopeName, strings);
/* 822 */     MetadataStoreHelper.addString(this.m_scope.toString(), strings);
/* 823 */     MetadataStoreHelper.addString(this.m_target, strings);
/* 824 */     MetadataStoreHelper.addString(this.m_unbind, strings);
/* 825 */     MetadataStoreHelper.addString(this.m_updated, strings);
/*     */   }
/*     */ 
/*     */   
/*     */   void store(DataOutputStream out, MetadataStoreHelper.MetaDataWriter metaDataWriter) throws IOException {
/* 830 */     metaDataWriter.writeString(this.m_bind, out);
/* 831 */     metaDataWriter.writeString(this.m_cardinality, out);
/* 832 */     metaDataWriter.writeString(this.m_collection_type, out);
/* 833 */     metaDataWriter.writeString(this.m_field, out);
/* 834 */     metaDataWriter.writeString(this.m_field_option, out);
/* 835 */     metaDataWriter.writeString(this.m_interface, out);
/* 836 */     out.writeBoolean(this.m_isMultiple);
/* 837 */     out.writeBoolean(this.m_isOptional);
/* 838 */     out.writeBoolean(this.m_isReluctant);
/* 839 */     out.writeBoolean(this.m_isReplace);
/* 840 */     out.writeBoolean(this.m_isStatic);
/* 841 */     metaDataWriter.writeString(this.m_name, out);
/* 842 */     metaDataWriter.writeString(this.m_parameter, out);
/* 843 */     out.writeBoolean((this.m_parameterIndex != null));
/* 844 */     if (this.m_parameterIndex != null)
/*     */     {
/* 846 */       out.writeInt(this.m_parameterIndex.intValue());
/*     */     }
/* 848 */     metaDataWriter.writeString(this.m_policy, out);
/* 849 */     metaDataWriter.writeString(this.m_policy_option, out);
/* 850 */     metaDataWriter.writeString(this.m_scopeName, out);
/* 851 */     metaDataWriter.writeString(this.m_scope.toString(), out);
/* 852 */     metaDataWriter.writeString(this.m_target, out);
/* 853 */     metaDataWriter.writeString(this.m_unbind, out);
/* 854 */     metaDataWriter.writeString(this.m_updated, out);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   static ReferenceMetadata load(DataInputStream in, MetadataStoreHelper.MetaDataReader metaDataReader) throws IOException {
/* 860 */     ReferenceMetadata result = new ReferenceMetadata();
/* 861 */     result.m_bind = metaDataReader.readString(in);
/* 862 */     result.m_cardinality = metaDataReader.readString(in);
/* 863 */     result.m_collection_type = metaDataReader.readString(in);
/* 864 */     result.m_field = metaDataReader.readString(in);
/* 865 */     result.m_field_option = metaDataReader.readString(in);
/* 866 */     result.m_interface = metaDataReader.readString(in);
/* 867 */     result.m_isMultiple = in.readBoolean();
/* 868 */     result.m_isOptional = in.readBoolean();
/* 869 */     result.m_isReluctant = in.readBoolean();
/* 870 */     result.m_isReplace = in.readBoolean();
/* 871 */     result.m_isStatic = in.readBoolean();
/* 872 */     result.m_name = metaDataReader.readString(in);
/* 873 */     result.m_parameter = metaDataReader.readString(in);
/* 874 */     if (in.readBoolean())
/*     */     {
/* 876 */       result.m_parameterIndex = Integer.valueOf(in.readInt());
/*     */     }
/* 878 */     result.m_policy = metaDataReader.readString(in);
/* 879 */     result.m_policy_option = metaDataReader.readString(in);
/* 880 */     result.m_scopeName = metaDataReader.readString(in);
/* 881 */     result.m_scope = ReferenceScope.valueOf(metaDataReader.readString(in));
/* 882 */     result.m_target = metaDataReader.readString(in);
/* 883 */     result.m_unbind = metaDataReader.readString(in);
/* 884 */     result.m_updated = metaDataReader.readString(in);
/*     */ 
/*     */     
/* 887 */     result.m_validated = true;
/* 888 */     return result;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.apache.felix.scr-2.2.6.jar!\org\apache\felix\scr\impl\metadata\ReferenceMetadata.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */