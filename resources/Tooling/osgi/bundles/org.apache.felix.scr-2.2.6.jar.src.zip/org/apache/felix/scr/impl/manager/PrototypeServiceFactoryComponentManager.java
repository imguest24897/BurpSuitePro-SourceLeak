/*    */ package org.apache.felix.scr.impl.manager;
/*    */ 
/*    */ import org.apache.felix.scr.impl.inject.ComponentMethods;
/*    */ import org.osgi.framework.PrototypeServiceFactory;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PrototypeServiceFactoryComponentManager<S>
/*    */   extends ServiceFactoryComponentManager<S>
/*    */   implements PrototypeServiceFactory<S>
/*    */ {
/*    */   public PrototypeServiceFactoryComponentManager(ComponentContainer<S> container, ComponentMethods<S> componentMethods) {
/* 29 */     super(container, componentMethods);
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.apache.felix.scr-2.2.6.jar!\org\apache\felix\scr\impl\manager\PrototypeServiceFactoryComponentManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */