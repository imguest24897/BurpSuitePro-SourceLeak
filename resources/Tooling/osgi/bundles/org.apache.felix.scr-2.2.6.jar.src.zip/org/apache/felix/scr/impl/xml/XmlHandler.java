/*     */ package org.apache.felix.scr.impl.xml;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.net.URL;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Properties;
/*     */ import org.apache.felix.scr.impl.logger.BundleLogger;
/*     */ import org.apache.felix.scr.impl.logger.InternalLogger;
/*     */ import org.apache.felix.scr.impl.metadata.ComponentMetadata;
/*     */ import org.apache.felix.scr.impl.metadata.DSVersion;
/*     */ import org.apache.felix.scr.impl.metadata.PropertyMetadata;
/*     */ import org.apache.felix.scr.impl.metadata.ReferenceMetadata;
/*     */ import org.apache.felix.scr.impl.metadata.ServiceMetadata;
/*     */ import org.osgi.framework.Bundle;
/*     */ import org.osgi.framework.ServiceReference;
/*     */ import org.xml.sax.Attributes;
/*     */ import org.xml.sax.SAXException;
/*     */ import org.xml.sax.helpers.DefaultHandler;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class XmlHandler
/*     */   extends DefaultHandler
/*     */ {
/*     */   private final Bundle m_bundle;
/*     */   private final BundleLogger m_logger;
/*     */   private final boolean m_globalObsoleteFactoryComponentFactory;
/*     */   private final boolean m_globalDelayedKeepInstances;
/*     */   private final ServiceReference<?> m_trueCondition;
/*     */   private ComponentMetadata m_currentComponent;
/*     */   private ServiceMetadata m_currentService;
/*  66 */   private List<ComponentMetadata> m_components = new ArrayList<>();
/*     */ 
/*     */   
/*     */   private PropertyMetadata m_pendingProperty;
/*     */ 
/*     */   
/*     */   private PropertyMetadata m_pendingFactoryProperty;
/*     */ 
/*     */   
/*     */   private StringBuilder propertyBuilder;
/*     */ 
/*     */   
/*     */   protected boolean firstElement = true;
/*     */ 
/*     */   
/*     */   protected String overrideNamespace;
/*     */ 
/*     */   
/*     */   protected boolean isComponent = false;
/*     */ 
/*     */ 
/*     */   
/*     */   public XmlHandler(Bundle bundle, BundleLogger logger, boolean globalObsoleteFactoryComponentFactory, boolean globalDelayedKeepInstances, ServiceReference<?> trueCondition) {
/*  89 */     this.m_bundle = bundle;
/*  90 */     this.m_logger = logger;
/*  91 */     this.m_globalObsoleteFactoryComponentFactory = globalObsoleteFactoryComponentFactory;
/*  92 */     this.m_globalDelayedKeepInstances = globalDelayedKeepInstances;
/*  93 */     this.m_trueCondition = trueCondition;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<ComponentMetadata> getComponentMetadataList() {
/* 104 */     return this.m_components;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void startElement(String uri, String localName, String qName, Attributes attributes) throws SAXException {
/* 114 */     if (this.firstElement) {
/*     */       
/* 116 */       this.firstElement = false;
/* 117 */       if (localName.equals("component") && "".equals(uri))
/*     */       {
/* 119 */         this.overrideNamespace = "http://www.osgi.org/xmlns/scr/v1.0.0";
/*     */       }
/*     */     } 
/*     */     
/* 123 */     if (this.overrideNamespace != null && "".equals(uri))
/*     */     {
/* 125 */       uri = this.overrideNamespace;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 131 */     if (this.isComponent && "".equals(uri))
/*     */     {
/* 133 */       uri = "http://www.osgi.org/xmlns/scr/v1.0.0";
/*     */     }
/*     */ 
/*     */     
/* 137 */     DSVersion namespaceCode = XmlConstants.NAMESPACE_CODE_MAP.get(uri);
/*     */     
/* 139 */     if (namespaceCode != null) {
/*     */ 
/*     */       
/*     */       try {
/*     */ 
/*     */         
/* 145 */         if (localName.equals("component"))
/*     */         {
/* 147 */           this.isComponent = true;
/*     */ 
/*     */           
/* 150 */           this.m_currentComponent = new ComponentMetadata(namespaceCode);
/*     */ 
/*     */           
/* 153 */           if (attributes.getValue("", "name") != null)
/*     */           {
/* 155 */             this.m_currentComponent.setName(attributes.getValue("", "name"));
/*     */           }
/*     */ 
/*     */           
/* 159 */           if (attributes.getValue("", "enabled") != null)
/*     */           {
/* 161 */             this.m_currentComponent.setEnabled(attributes.getValue("", "enabled").equals("true"));
/*     */           }
/*     */ 
/*     */           
/* 165 */           if (attributes.getValue("", "immediate") != null)
/*     */           {
/* 167 */             this.m_currentComponent.setImmediate(attributes.getValue("", "immediate").equals("true"));
/*     */           }
/*     */ 
/*     */           
/* 171 */           if (attributes.getValue("", "factory") != null)
/*     */           {
/* 173 */             this.m_currentComponent.setFactoryIdentifier(attributes.getValue("", "factory"));
/*     */           }
/*     */ 
/*     */           
/* 177 */           if (attributes.getValue("", "configuration-policy") != null)
/*     */           {
/* 179 */             this.m_currentComponent.setConfigurationPolicy(attributes.getValue("", "configuration-policy"));
/*     */           }
/*     */ 
/*     */           
/* 183 */           if (attributes.getValue("", "activate") != null)
/*     */           {
/* 185 */             this.m_currentComponent.setActivate(attributes.getValue("", "activate"));
/*     */           }
/*     */ 
/*     */           
/* 189 */           if (attributes.getValue("", "deactivate") != null)
/*     */           {
/* 191 */             this.m_currentComponent.setDeactivate(attributes.getValue("", "deactivate"));
/*     */           }
/*     */ 
/*     */           
/* 195 */           if (attributes.getValue("", "modified") != null)
/*     */           {
/* 197 */             this.m_currentComponent.setModified(attributes.getValue("", "modified"));
/*     */           }
/*     */ 
/*     */           
/* 201 */           String configurationPidString = attributes.getValue("", "configuration-pid");
/* 202 */           if (configurationPidString != null) {
/*     */             
/* 204 */             String[] configurationPid = configurationPidString.split(" ");
/* 205 */             this.m_currentComponent.setConfigurationPid(configurationPid);
/*     */           } 
/*     */           
/* 208 */           this.m_currentComponent.setConfigurableServiceProperties("true".equals(attributes.getValue("http://felix.apache.org/xmlns/scr/extensions/v1.0.0", "configurableServiceProperties")));
/* 209 */           this.m_currentComponent.setPersistentFactoryComponent("true".equals(attributes.getValue("http://felix.apache.org/xmlns/scr/extensions/v1.0.0", "persistentFactoryComponent")));
/* 210 */           this.m_currentComponent.setDeleteCallsModify("true".equals(attributes.getValue("http://felix.apache.org/xmlns/scr/extensions/v1.0.0", "deleteCallsModify")));
/* 211 */           if (attributes.getValue("http://felix.apache.org/xmlns/scr/extensions/v1.0.0", "obsoleteFactoryComponentFactory") != null) {
/*     */             
/* 213 */             this.m_currentComponent.setObsoleteFactoryComponentFactory("true".equals(attributes.getValue("http://felix.apache.org/xmlns/scr/extensions/v1.0.0", "obsoleteFactoryComponentFactory")));
/*     */           }
/* 215 */           else if (!namespaceCode.isDS13()) {
/*     */             
/* 217 */             this.m_currentComponent.setObsoleteFactoryComponentFactory(this.m_globalObsoleteFactoryComponentFactory);
/*     */           } 
/* 219 */           this.m_currentComponent.setConfigureWithInterfaces("true".equals(attributes.getValue("http://felix.apache.org/xmlns/scr/extensions/v1.0.0", "configureWithInterfaces")));
/* 220 */           this.m_currentComponent.setDelayedKeepInstances((this.m_globalDelayedKeepInstances || "true".equals(attributes.getValue("http://felix.apache.org/xmlns/scr/extensions/v1.0.0", "delayedKeepInstances"))));
/*     */ 
/*     */           
/* 223 */           String activationFields = attributes.getValue("", "activation-fields");
/* 224 */           if (activationFields != null) {
/*     */             
/* 226 */             String[] fields = activationFields.split(" ");
/* 227 */             this.m_currentComponent.setActivationFields(fields);
/*     */           } 
/*     */ 
/*     */           
/* 231 */           String init = attributes.getValue("", "init");
/* 232 */           if (init != null)
/*     */           {
/* 234 */             this.m_currentComponent.setInit(init);
/*     */           }
/*     */ 
/*     */           
/* 238 */           this.m_components.add(this.m_currentComponent);
/*     */ 
/*     */         
/*     */         }
/* 242 */         else if (!this.isComponent)
/*     */         {
/* 244 */           this.m_logger.log(InternalLogger.Level.DEBUG, "Not currently parsing a component; ignoring element {0} (bundle {1})", null, new Object[] { localName, this.m_bundle
/*     */                 
/* 246 */                 .getLocation() });
/*     */ 
/*     */         
/*     */         }
/* 250 */         else if (localName.equals("implementation"))
/*     */         {
/*     */           
/* 253 */           this.m_currentComponent.setImplementationClassName(attributes.getValue("", "class"));
/*     */         
/*     */         }
/* 256 */         else if (localName.equals("property"))
/*     */         {
/* 258 */           PropertyMetadata prop = new PropertyMetadata();
/*     */ 
/*     */           
/* 261 */           prop.setName(attributes.getValue("", "name"));
/*     */ 
/*     */           
/* 264 */           if (attributes.getValue("", "type") != null)
/*     */           {
/* 266 */             prop.setType(attributes.getValue("", "type"));
/*     */           }
/*     */ 
/*     */           
/* 270 */           if (attributes.getValue("", "value") != null)
/*     */           {
/* 272 */             prop.setValue(attributes.getValue("", "value"));
/* 273 */             this.m_currentComponent.addProperty(prop);
/*     */           
/*     */           }
/*     */           else
/*     */           {
/* 278 */             this.m_pendingProperty = prop;
/*     */           }
/*     */         
/*     */         }
/* 282 */         else if (localName.equals("properties"))
/*     */         {
/* 284 */           Properties props = readPropertiesEntry(attributes.getValue("", "entry"));
/*     */           
/* 286 */           for (Map.Entry<Object, Object> pEntry : props.entrySet())
/*     */           {
/* 288 */             PropertyMetadata prop = new PropertyMetadata();
/* 289 */             prop.setName(String.valueOf(pEntry.getKey()));
/* 290 */             prop.setValue(String.valueOf(pEntry.getValue()));
/* 291 */             this.m_currentComponent.addProperty(prop);
/*     */           
/*     */           }
/*     */         
/*     */         }
/* 296 */         else if (localName.equals("factory-property"))
/*     */         {
/* 298 */           PropertyMetadata prop = new PropertyMetadata();
/*     */ 
/*     */           
/* 301 */           prop.setName(attributes.getValue("", "name"));
/*     */ 
/*     */           
/* 304 */           if (attributes.getValue("", "type") != null)
/*     */           {
/* 306 */             prop.setType(attributes.getValue("", "type"));
/*     */           }
/*     */ 
/*     */           
/* 310 */           if (attributes.getValue("", "value") != null)
/*     */           {
/* 312 */             prop.setValue(attributes.getValue("", "value"));
/* 313 */             this.m_currentComponent.addFactoryProperty(prop);
/*     */           
/*     */           }
/*     */           else
/*     */           {
/* 318 */             this.m_pendingFactoryProperty = prop;
/*     */           }
/*     */         
/*     */         }
/* 322 */         else if (localName.equals("factory-properties"))
/*     */         {
/* 324 */           Properties props = readPropertiesEntry(attributes.getValue("", "entry"));
/*     */           
/* 326 */           for (Map.Entry<Object, Object> pEntry : props.entrySet())
/*     */           {
/* 328 */             PropertyMetadata prop = new PropertyMetadata();
/* 329 */             prop.setName(String.valueOf(pEntry.getKey()));
/* 330 */             prop.setValue(String.valueOf(pEntry.getValue()));
/* 331 */             this.m_currentComponent.addFactoryProperty(prop);
/*     */           }
/*     */         
/*     */         }
/* 335 */         else if (localName.equals("service"))
/*     */         {
/*     */           
/* 338 */           this.m_currentService = new ServiceMetadata();
/*     */ 
/*     */           
/* 341 */           if (attributes.getValue("", "servicefactory") != null)
/*     */           {
/* 343 */             this.m_currentService.setServiceFactory(attributes.getValue("", "servicefactory").equals("true"));
/*     */           }
/*     */           
/* 346 */           if (attributes.getValue("", "scope") != null)
/*     */           {
/* 348 */             this.m_currentService.setScope(attributes.getValue("", "scope"));
/*     */           }
/*     */           
/* 351 */           this.m_currentComponent.setService(this.m_currentService);
/*     */         }
/* 353 */         else if (localName.equals("provide"))
/*     */         {
/* 355 */           this.m_currentService.addProvide(attributes.getValue("", "interface"));
/*     */ 
/*     */         
/*     */         }
/* 359 */         else if (localName.equals("reference"))
/*     */         {
/* 361 */           ReferenceMetadata ref = new ReferenceMetadata();
/*     */ 
/*     */           
/* 364 */           if (attributes.getValue("", "name") != null)
/*     */           {
/* 366 */             ref.setName(attributes.getValue("", "name"));
/*     */           }
/*     */           
/* 369 */           ref.setInterface(attributes.getValue("", "interface"));
/*     */ 
/*     */           
/* 372 */           if (attributes.getValue("", "cardinality") != null)
/*     */           {
/* 374 */             ref.setCardinality(attributes.getValue("", "cardinality"));
/*     */           }
/*     */           
/* 377 */           if (attributes.getValue("", "policy") != null)
/*     */           {
/* 379 */             ref.setPolicy(attributes.getValue("", "policy"));
/*     */           }
/*     */           
/* 382 */           if (attributes.getValue("", "policy-option") != null)
/*     */           {
/* 384 */             ref.setPolicyOption(attributes.getValue("", "policy-option"));
/*     */           }
/*     */           
/* 387 */           if (attributes.getValue("", "scope") != null)
/*     */           {
/* 389 */             ref.setScope(attributes.getValue("", "scope"));
/*     */           }
/*     */           
/* 392 */           if (attributes.getValue("", "target") != null) {
/*     */             
/* 394 */             ref.setTarget(attributes.getValue("", "target"));
/* 395 */             PropertyMetadata prop = new PropertyMetadata(true);
/* 396 */             prop.setName(((ref.getName() == null) ? ref.getInterface() : ref.getName()) + ".target");
/* 397 */             prop.setValue(attributes.getValue("", "target"));
/* 398 */             this.m_currentComponent.addProperty(prop);
/*     */           } 
/*     */ 
/*     */ 
/*     */           
/* 403 */           ref.setBind(attributes.getValue("", "bind"));
/* 404 */           ref.setUpdated(attributes.getValue("", "updated"));
/* 405 */           ref.setUnbind(attributes.getValue("", "unbind"));
/*     */ 
/*     */           
/* 408 */           ref.setField(attributes.getValue("", "field"));
/* 409 */           ref.setFieldOption(attributes.getValue("", "field-option"));
/* 410 */           ref.setCollectionType(attributes.getValue("", "field-collection-type"));
/*     */ 
/*     */           
/* 413 */           if (attributes.getValue("", "parameter") != null)
/*     */           {
/* 415 */             ref.setParameter(attributes.getValue("", "parameter"));
/*     */           }
/*     */ 
/*     */           
/* 419 */           this.m_currentComponent.addDependency(ref);
/*     */ 
/*     */ 
/*     */         
/*     */         }
/* 424 */         else if (!localName.equals("components"))
/*     */         {
/* 426 */           this.m_logger.log(InternalLogger.Level.DEBUG, "Ignoring unsupported element {0} (bundle {1})", null, new Object[] { localName, this.m_bundle
/*     */                 
/* 428 */                 .getLocation() });
/*     */         }
/*     */       
/* 431 */       } catch (Exception ex) {
/*     */         
/* 433 */         throw new SAXException("Exception during parsing", ex);
/*     */       
/*     */       }
/*     */ 
/*     */     
/*     */     }
/* 439 */     else if (!localName.equals("components")) {
/*     */       
/* 441 */       this.m_logger.log(InternalLogger.Level.DEBUG, "Ignoring unsupported element '{'{0}'}'{1} (bundle {2})", null, new Object[] { uri, localName, this.m_bundle
/*     */             
/* 443 */             .getLocation() });
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void endElement(String uri, String localName, String qName) throws SAXException {
/* 451 */     if (this.overrideNamespace != null && "".equals(uri))
/*     */     {
/* 453 */       uri = this.overrideNamespace;
/*     */     }
/*     */     
/* 456 */     if (this.isComponent && "".equals(uri))
/*     */     {
/* 458 */       uri = "http://www.osgi.org/xmlns/scr/v1.0.0";
/*     */     }
/*     */     
/* 461 */     if ("http://www.osgi.org/xmlns/scr/v1.0.0".equals(uri))
/*     */     {
/* 463 */       if (localName.equals("component")) {
/*     */         
/* 465 */         this.isComponent = false;
/*     */       }
/* 467 */       else if (localName.equals("property") && this.m_pendingProperty != null) {
/*     */         
/* 469 */         if (this.propertyBuilder != null) {
/* 470 */           this.m_pendingProperty.setValues(this.propertyBuilder.toString());
/* 471 */           this.propertyBuilder = null;
/* 472 */           this.m_currentComponent.addProperty(this.m_pendingProperty);
/*     */         } 
/* 474 */         this.m_pendingProperty = null;
/*     */       }
/* 476 */       else if (localName.equals("factory-property") && this.m_pendingFactoryProperty != null) {
/*     */         
/* 478 */         if (this.propertyBuilder != null) {
/* 479 */           this.m_pendingFactoryProperty.setValues(this.propertyBuilder.toString());
/* 480 */           this.propertyBuilder = null;
/* 481 */           this.m_currentComponent.addFactoryProperty(this.m_pendingFactoryProperty);
/*     */         } 
/* 483 */         this.m_pendingFactoryProperty = null;
/*     */       } 
/*     */     }
/* 486 */     if (this.m_trueCondition != null && localName.equals("component")) {
/*     */       
/* 488 */       boolean missingSatisfyingConditionRef = true;
/* 489 */       for (ReferenceMetadata ref : this.m_currentComponent.getDependencies()) {
/*     */         
/* 491 */         if ("osgi.ds.satisfying.condition".equals(ref
/* 492 */             .getName())) {
/*     */           
/* 494 */           missingSatisfyingConditionRef = false;
/*     */           break;
/*     */         } 
/*     */       } 
/* 498 */       if (missingSatisfyingConditionRef) {
/*     */         
/* 500 */         ReferenceMetadata trueReference = new ReferenceMetadata();
/* 501 */         trueReference.setName("osgi.ds.satisfying.condition");
/*     */         
/* 503 */         trueReference.setTarget("(osgi.condition.id=true)");
/* 504 */         trueReference.setInterface("org.osgi.service.condition.Condition");
/* 505 */         trueReference.setPolicy("dynamic");
/* 506 */         this.m_currentComponent.addDependency(trueReference);
/*     */ 
/*     */ 
/*     */         
/* 510 */         PropertyMetadata prop = new PropertyMetadata(true);
/* 511 */         prop.setName("osgi.ds.satisfying.condition.target");
/*     */         
/* 513 */         prop.setValue("(osgi.condition.id=true)");
/* 514 */         this.m_currentComponent.addProperty(prop);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void characters(char[] ch, int start, int length) throws SAXException {
/* 524 */     if (this.m_pendingProperty != null || this.m_pendingFactoryProperty != null) {
/*     */       
/* 526 */       if (this.propertyBuilder == null) {
/* 527 */         this.propertyBuilder = new StringBuilder();
/*     */       }
/* 529 */       this.propertyBuilder.append(String.valueOf(ch, start, length));
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Properties readPropertiesEntry(String entryName) throws SAXException {
/* 548 */     if (entryName == null)
/*     */     {
/* 550 */       throw new SAXException("Missing entry attribute of properties element", null);
/*     */     }
/*     */     
/* 553 */     URL entryURL = this.m_bundle.getEntry(entryName);
/* 554 */     if (entryURL == null)
/*     */     {
/* 556 */       throw new SAXException("Missing bundle entry " + entryName, null);
/*     */     }
/*     */     
/* 559 */     Properties props = new Properties();
/* 560 */     InputStream entryStream = null;
/*     */     
/*     */     try {
/* 563 */       entryStream = entryURL.openStream();
/* 564 */       props.load(entryStream);
/*     */     }
/* 566 */     catch (IOException ioe) {
/*     */       
/* 568 */       throw new SAXException("Failed to read properties entry " + entryName, ioe);
/*     */     }
/*     */     finally {
/*     */       
/* 572 */       if (entryStream != null) {
/*     */         
/*     */         try {
/*     */           
/* 576 */           entryStream.close();
/*     */         }
/* 578 */         catch (IOException iOException) {}
/*     */       }
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 585 */     return props;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.apache.felix.scr-2.2.6.jar!\org\apache\felix\scr\impl\xml\XmlHandler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */