/*     */ package org.apache.felix.scr.impl.manager;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Dictionary;
/*     */ import java.util.IdentityHashMap;
/*     */ import org.apache.felix.scr.impl.inject.ComponentMethods;
/*     */ import org.apache.felix.scr.impl.inject.LifecycleMethod;
/*     */ import org.apache.felix.scr.impl.inject.MethodResult;
/*     */ import org.apache.felix.scr.impl.inject.RefPair;
/*     */ import org.apache.felix.scr.impl.logger.InternalLogger;
/*     */ import org.osgi.framework.Bundle;
/*     */ import org.osgi.framework.ServiceRegistration;
/*     */ import org.osgi.service.component.ComponentInstance;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ServiceFactoryComponentManager<S>
/*     */   extends SingleComponentManager<S>
/*     */ {
/*     */   public void setServiceProperties(Dictionary<String, ?> serviceProperties) {
/*  48 */     throw new IllegalStateException("Bundle or instance scoped service properties are immutable");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void postRegister() {}
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  60 */   private IdentityHashMap<S, ComponentContextImpl<S>> serviceContexts = new IdentityHashMap<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ServiceFactoryComponentManager(ComponentContainer<S> container, ComponentMethods<S> componentMethods) {
/*  68 */     super(container, componentMethods);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void deleteComponent(int reason) {
/*  78 */     if (!isStateLocked())
/*     */     {
/*  80 */       throw new IllegalStateException("need write lock (deleteComponent)");
/*     */     }
/*  82 */     for (ComponentContextImpl<S> componentContext : getComponentContexts()) {
/*     */       
/*  84 */       disposeImplementationObject(componentContext, reason);
/*  85 */       getLogger().log(InternalLogger.Level.DEBUG, "Unset implementation object for component in deleteComponent for reason {0}", null, new Object[] { REASONS[reason] });
/*     */     } 
/*     */ 
/*     */     
/*  89 */     synchronized (this.serviceContexts) {
/*     */       
/*  91 */       this.serviceContexts.clear();
/*     */     } 
/*  93 */     clearServiceProperties();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public S getService(Bundle bundle, ServiceRegistration<S> serviceRegistration) {
/* 103 */     getLogger().log(InternalLogger.Level.DEBUG, "ServiceFactory.getService()", null);
/*     */ 
/*     */ 
/*     */     
/* 107 */     ComponentContextImpl<S> componentContext = new ComponentContextImpl<>(this, bundle, serviceRegistration);
/* 108 */     if (collectDependencies(componentContext)) {
/*     */       
/* 110 */       getLogger().log(InternalLogger.Level.DEBUG, "getService (ServiceFactory) dependencies collected.", null);
/*     */ 
/*     */     
/*     */     }
/*     */     else {
/*     */ 
/*     */ 
/*     */       
/* 118 */       return null;
/*     */     } 
/* 120 */     AbstractComponentManager.State previousState = getState();
/*     */     
/* 122 */     S service = createImplementationObject(bundle, new SingleComponentManager.SetImplementationObject<S>()
/*     */         {
/*     */           
/*     */           public void presetComponentContext(ComponentContextImpl<S> componentContext)
/*     */           {
/* 127 */             synchronized (ServiceFactoryComponentManager.this.serviceContexts) {
/*     */               
/* 129 */               ServiceFactoryComponentManager.this.serviceContexts.put(componentContext.getImplementationObject(false), componentContext);
/*     */             } 
/*     */           }
/*     */ 
/*     */ 
/*     */           
/*     */           public void resetImplementationObject(S implementationObject) {
/* 136 */             synchronized (ServiceFactoryComponentManager.this.serviceContexts) {
/*     */               
/* 138 */               ServiceFactoryComponentManager.this.serviceContexts.remove(implementationObject);
/*     */             } 
/*     */           }
/*     */         }componentContext);
/*     */ 
/*     */ 
/*     */     
/* 145 */     if (service == null) {
/*     */ 
/*     */ 
/*     */       
/* 149 */       getLogger().log(InternalLogger.Level.DEBUG, "Failed creating the component instance; see log for reason", null);
/*     */     
/*     */     }
/*     */     else {
/*     */       
/* 154 */       setState(previousState, AbstractComponentManager.State.active);
/*     */     } 
/*     */     
/* 157 */     return service;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void ungetService(Bundle bundle, ServiceRegistration<S> registration, S service) {
/*     */     ComponentContextImpl<S> serviceContext;
/* 167 */     getLogger().log(InternalLogger.Level.DEBUG, "ServiceFactory.ungetService()", null);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 172 */     synchronized (this.serviceContexts) {
/*     */       
/* 174 */       serviceContext = this.serviceContexts.get(service);
/*     */     } 
/* 176 */     if (serviceContext != null) {
/* 177 */       disposeImplementationObject(serviceContext, 5);
/* 178 */       synchronized (this.serviceContexts) {
/*     */         
/* 180 */         if (this.serviceContexts.remove(service) != null) {
/*     */           AbstractComponentManager.State previousState;
/*     */           
/* 183 */           if (this.serviceContexts.isEmpty() && (
/* 184 */             previousState = getState()) == AbstractComponentManager.State.active)
/*     */           {
/* 186 */             setState(previousState, AbstractComponentManager.State.satisfied);
/*     */           }
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private Collection<ComponentContextImpl<S>> getComponentContexts() {
/* 195 */     synchronized (this.serviceContexts) {
/*     */       
/* 197 */       return new ArrayList<>(this.serviceContexts.values());
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   <T> void invokeBindMethod(DependencyManager<S, T> dependencyManager, RefPair<S, T> refPair, int trackingCount) {
/* 204 */     for (ComponentContextImpl<S> cc : getComponentContexts())
/*     */     {
/* 206 */       dependencyManager.invokeBindMethod(cc, refPair, trackingCount, cc.getEdgeInfo(dependencyManager));
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   <T> boolean invokeUpdatedMethod(DependencyManager<S, T> dependencyManager, RefPair<S, T> refPair, int trackingCount) {
/* 215 */     boolean reactivate = false;
/* 216 */     for (ComponentContextImpl<S> cc : getComponentContexts()) {
/*     */       
/* 218 */       if (dependencyManager.invokeUpdatedMethod(cc, refPair, trackingCount, cc.getEdgeInfo(dependencyManager)))
/*     */       {
/* 220 */         reactivate = true;
/*     */       }
/*     */     } 
/* 223 */     return reactivate;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   <T> void invokeUnbindMethod(DependencyManager<S, T> dependencyManager, RefPair<S, T> oldRefPair, int trackingCount) {
/* 229 */     for (ComponentContextImpl<S> cc : getComponentContexts())
/*     */     {
/* 231 */       dependencyManager.invokeUnbindMethod(cc, oldRefPair, trackingCount, cc.getEdgeInfo(dependencyManager));
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected MethodResult invokeModifiedMethod() {
/* 238 */     LifecycleMethod modifiedMethod = getComponentMethods().getModifiedMethod();
/* 239 */     MethodResult result = MethodResult.VOID;
/* 240 */     for (ComponentContextImpl<S> componentContext : getComponentContexts()) {
/*     */       
/* 242 */       S instance = componentContext.getImplementationObject(true);
/* 243 */       result = modifiedMethod.invoke(instance, componentContext, -1, MethodResult.VOID);
/*     */     } 
/*     */ 
/*     */     
/* 247 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ComponentInstance<S> getComponentInstance() {
/* 257 */     return super.getComponentInstance();
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.apache.felix.scr-2.2.6.jar!\org\apache\felix\scr\impl\manager\ServiceFactoryComponentManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */