/*     */ package org.apache.felix.scr.impl.inject.methods;
/*     */ 
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import org.apache.felix.scr.impl.inject.BaseParameter;
/*     */ import org.apache.felix.scr.impl.inject.BindParameters;
/*     */ import org.apache.felix.scr.impl.inject.MethodResult;
/*     */ import org.apache.felix.scr.impl.inject.RefPair;
/*     */ import org.apache.felix.scr.impl.inject.ReferenceMethod;
/*     */ import org.apache.felix.scr.impl.inject.ScrComponentContext;
/*     */ import org.apache.felix.scr.impl.inject.ValueUtils;
/*     */ import org.apache.felix.scr.impl.inject.internal.ClassUtils;
/*     */ import org.apache.felix.scr.impl.logger.ComponentLogger;
/*     */ import org.apache.felix.scr.impl.logger.InternalLogger;
/*     */ import org.apache.felix.scr.impl.metadata.DSVersion;
/*     */ import org.osgi.framework.BundleContext;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BindMethod
/*     */   extends BaseMethod<BindParameters, List<ValueUtils.ValueType>>
/*     */   implements ReferenceMethod
/*     */ {
/*     */   private final String m_referenceClassName;
/*  48 */   private volatile List<ValueUtils.ValueType> m_paramTypes = Collections.emptyList();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BindMethod(String methodName, Class<?> componentClass, String referenceClassName, DSVersion dsVersion, boolean configurableServiceProperties) {
/*  56 */     super(methodName, (methodName != null), componentClass, dsVersion, configurableServiceProperties);
/*  57 */     this.m_referenceClassName = referenceClassName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected BaseMethod.MethodInfo<List<ValueUtils.ValueType>> doFindMethod(Class<?> targetClass, boolean acceptPrivate, boolean acceptPackage, ComponentLogger logger) throws SuitableMethodNotAccessibleException, InvocationTargetException {
/*  97 */     boolean suitableMethodNotAccessible = false;
/*     */     
/*  99 */     if (logger.isLogEnabled(InternalLogger.Level.DEBUG))
/*     */     {
/* 101 */       logger.log(InternalLogger.Level.DEBUG, "doFindMethod: Looking for method " + targetClass
/* 102 */           .getName() + "." + getMethodName(), null);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/* 109 */       Method method = getServiceReferenceMethod(targetClass, acceptPrivate, acceptPackage, logger);
/* 110 */       if (method != null)
/*     */       {
/* 112 */         if (logger.isLogEnabled(InternalLogger.Level.DEBUG))
/*     */         {
/* 114 */           logger.log(InternalLogger.Level.DEBUG, "doFindMethod: Found Method " + method, null);
/*     */         }
/*     */         
/* 117 */         return new BaseMethod.MethodInfo<>(method, Collections.singletonList(ValueUtils.ValueType.ref_serviceReference));
/*     */       }
/*     */     
/* 120 */     } catch (SuitableMethodNotAccessibleException ex) {
/*     */       
/* 122 */       suitableMethodNotAccessible = true;
/*     */     } 
/*     */ 
/*     */     
/* 126 */     if (getDSVersion().isDS13()) {
/*     */       
/*     */       try {
/*     */         
/* 130 */         Method method = getComponentObjectsMethod(targetClass, acceptPrivate, acceptPackage, logger);
/* 131 */         if (method != null)
/*     */         {
/* 133 */           if (logger.isLogEnabled(InternalLogger.Level.DEBUG))
/*     */           {
/* 135 */             logger.log(InternalLogger.Level.DEBUG, "doFindMethod: Found Method " + method, null);
/*     */           }
/*     */           
/* 138 */           return new BaseMethod.MethodInfo<>(method, Collections.singletonList(ValueUtils.ValueType.ref_serviceObjects));
/*     */         }
/*     */       
/* 141 */       } catch (SuitableMethodNotAccessibleException ex) {
/*     */         
/* 143 */         suitableMethodNotAccessible = true;
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/* 148 */     Class<?> parameterClass = ClassUtils.getClassFromComponentClassLoader(targetClass, this.m_referenceClassName, logger);
/* 149 */     if (parameterClass != null) {
/*     */ 
/*     */       
/* 152 */       if (logger.isLogEnabled(InternalLogger.Level.DEBUG))
/*     */       {
/* 154 */         logger.log(InternalLogger.Level.DEBUG, "doFindMethod: No method taking ServiceReference found, checking method taking " + parameterClass
/*     */ 
/*     */             
/* 157 */             .getName(), null);
/*     */       }
/*     */ 
/*     */ 
/*     */       
/*     */       try {
/* 163 */         Method method = getServiceObjectMethod(targetClass, parameterClass, acceptPrivate, acceptPackage, logger);
/* 164 */         if (method != null)
/*     */         {
/* 166 */           if (logger.isLogEnabled(InternalLogger.Level.DEBUG))
/*     */           {
/* 168 */             logger.log(InternalLogger.Level.DEBUG, "doFindMethod: Found Method " + method, null);
/*     */           }
/*     */           
/* 171 */           return new BaseMethod.MethodInfo<>(method, 
/* 172 */               Collections.singletonList(ValueUtils.ValueType.ref_serviceType));
/*     */         }
/*     */       
/* 175 */       } catch (SuitableMethodNotAccessibleException ex) {
/*     */         
/* 177 */         suitableMethodNotAccessible = true;
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/*     */       try {
/* 183 */         Method method = getServiceObjectAssignableMethod(targetClass, parameterClass, acceptPrivate, acceptPackage, logger);
/* 184 */         if (method != null)
/*     */         {
/* 186 */           if (logger.isLogEnabled(InternalLogger.Level.DEBUG))
/*     */           {
/* 188 */             logger.log(InternalLogger.Level.DEBUG, "doFindMethod: Found Method " + method, null);
/*     */           }
/*     */           
/* 191 */           return new BaseMethod.MethodInfo<>(method, 
/* 192 */               Collections.singletonList(ValueUtils.ValueType.ref_serviceType));
/*     */         }
/*     */       
/* 195 */       } catch (SuitableMethodNotAccessibleException ex) {
/*     */         
/* 197 */         suitableMethodNotAccessible = true;
/*     */       } 
/*     */ 
/*     */       
/* 201 */       if (getDSVersion().isDS13()) {
/*     */         
/*     */         try {
/*     */           
/* 205 */           Method method = getMapMethod(targetClass, parameterClass, acceptPrivate, acceptPackage, logger);
/* 206 */           if (method != null)
/*     */           {
/* 208 */             if (logger.isLogEnabled(InternalLogger.Level.DEBUG))
/*     */             {
/* 210 */               logger.log(InternalLogger.Level.DEBUG, "doFindMethod: Found Method " + method, null);
/*     */             }
/*     */             
/* 213 */             return new BaseMethod.MethodInfo<>(method, 
/* 214 */                 Collections.singletonList(ValueUtils.ValueType.ref_map));
/*     */           }
/*     */         
/* 217 */         } catch (SuitableMethodNotAccessibleException ex) {
/*     */           
/* 219 */           suitableMethodNotAccessible = true;
/*     */         } 
/*     */       }
/*     */ 
/*     */       
/* 224 */       if (getDSVersion().isDS11() && !getDSVersion().isDS13()) {
/*     */ 
/*     */         
/*     */         try {
/*     */ 
/*     */           
/* 230 */           Method method = getServiceObjectWithMapMethod(targetClass, parameterClass, acceptPrivate, acceptPackage, logger);
/* 231 */           if (method != null)
/*     */           {
/* 233 */             if (logger.isLogEnabled(InternalLogger.Level.DEBUG))
/*     */             {
/* 235 */               logger.log(InternalLogger.Level.DEBUG, "doFindMethod: Found Method " + method, null);
/*     */             }
/*     */             
/* 238 */             List<ValueUtils.ValueType> paramTypes = new ArrayList<>(2);
/* 239 */             paramTypes.add(ValueUtils.ValueType.ref_serviceType);
/* 240 */             paramTypes.add(ValueUtils.ValueType.ref_map);
/* 241 */             return new BaseMethod.MethodInfo<>(method, paramTypes);
/*     */           }
/*     */         
/* 244 */         } catch (SuitableMethodNotAccessibleException ex) {
/*     */           
/* 246 */           suitableMethodNotAccessible = true;
/*     */         } 
/*     */ 
/*     */ 
/*     */         
/*     */         try {
/* 252 */           Method method = getServiceObjectAssignableWithMapMethod(targetClass, parameterClass, acceptPrivate, acceptPackage);
/*     */           
/* 254 */           if (method != null)
/*     */           {
/* 256 */             if (logger.isLogEnabled(InternalLogger.Level.DEBUG))
/*     */             {
/* 258 */               logger.log(InternalLogger.Level.DEBUG, "doFindMethod: Found Method " + method, null);
/*     */             }
/*     */             
/* 261 */             List<ValueUtils.ValueType> paramTypes = new ArrayList<>(2);
/* 262 */             paramTypes.add(ValueUtils.ValueType.ref_serviceType);
/* 263 */             paramTypes.add(ValueUtils.ValueType.ref_map);
/* 264 */             return new BaseMethod.MethodInfo<>(method, paramTypes);
/*     */           }
/*     */         
/*     */         }
/* 268 */         catch (SuitableMethodNotAccessibleException ex) {
/*     */           
/* 270 */           suitableMethodNotAccessible = true;
/*     */         } 
/*     */       } 
/*     */ 
/*     */       
/* 275 */       if (getDSVersion().isDS13())
/*     */       {
/* 277 */         for (Method m : targetClass.getDeclaredMethods()) {
/*     */           
/* 279 */           if (getMethodName().equals(m.getName())) {
/* 280 */             Class<?>[] parameterTypes = m.getParameterTypes();
/* 281 */             boolean matches = true;
/* 282 */             boolean specialMatch = true;
/* 283 */             List<ValueUtils.ValueType> paramTypes = new ArrayList<>(parameterTypes.length);
/* 284 */             for (Class<?> paramType : parameterTypes) {
/* 285 */               if (paramType == ClassUtils.SERVICE_REFERENCE_CLASS) {
/*     */                 
/* 287 */                 if (specialMatch && parameterClass == ClassUtils.SERVICE_REFERENCE_CLASS)
/*     */                 {
/* 289 */                   specialMatch = false;
/* 290 */                   paramTypes.add(ValueUtils.ValueType.ref_serviceType);
/*     */                 }
/*     */                 else
/*     */                 {
/* 294 */                   paramTypes.add(ValueUtils.ValueType.ref_serviceReference);
/*     */                 }
/*     */               
/* 297 */               } else if (paramType == ClassUtils.COMPONENTS_SERVICE_OBJECTS_CLASS) {
/*     */                 
/* 299 */                 if (specialMatch && parameterClass == ClassUtils.COMPONENTS_SERVICE_OBJECTS_CLASS)
/*     */                 {
/* 301 */                   specialMatch = false;
/* 302 */                   paramTypes.add(ValueUtils.ValueType.ref_serviceType);
/*     */                 }
/*     */                 else
/*     */                 {
/* 306 */                   paramTypes.add(ValueUtils.ValueType.ref_serviceObjects);
/*     */                 }
/*     */               
/* 309 */               } else if (paramType == ClassUtils.MAP_CLASS) {
/*     */                 
/* 311 */                 if (specialMatch && parameterClass == ClassUtils.MAP_CLASS)
/*     */                 {
/* 313 */                   specialMatch = false;
/* 314 */                   paramTypes.add(ValueUtils.ValueType.ref_serviceType);
/*     */                 }
/*     */                 else
/*     */                 {
/* 318 */                   paramTypes.add(ValueUtils.ValueType.ref_map);
/*     */                 }
/*     */               
/* 321 */               } else if (paramType.isAssignableFrom(parameterClass)) {
/*     */                 
/* 323 */                 paramTypes.add(ValueUtils.ValueType.ref_serviceType);
/*     */               
/*     */               }
/* 326 */               else if (getDSVersion().isDS14() && "org.osgi.service.log.LoggerFactory".equals(this.m_referenceClassName)) {
/*     */                 
/* 328 */                 if (paramType.getName().equals("org.osgi.service.log.Logger")) {
/*     */                   
/* 330 */                   paramTypes.add(ValueUtils.ValueType.ref_logger);
/*     */                 }
/* 332 */                 else if (paramType.getName().equals("org.osgi.service.log.FormatterLogger")) {
/*     */                   
/* 334 */                   paramTypes.add(ValueUtils.ValueType.ref_formatterLogger);
/*     */                 }
/*     */                 else {
/*     */                   
/* 338 */                   matches = false;
/*     */ 
/*     */                   
/*     */                   break;
/*     */                 } 
/*     */               } else {
/* 344 */                 matches = false;
/*     */                 break;
/*     */               } 
/*     */             } 
/* 348 */             if (matches)
/*     */             {
/* 350 */               if (accept(m, acceptPrivate, acceptPackage, returnValue())) {
/*     */                 
/* 352 */                 if (logger.isLogEnabled(InternalLogger.Level.DEBUG))
/*     */                 {
/* 354 */                   logger.log(InternalLogger.Level.DEBUG, "doFindMethod: Found Method " + m, null);
/*     */                 }
/*     */                 
/* 357 */                 return new BaseMethod.MethodInfo<>(m, paramTypes);
/*     */               } 
/* 359 */               suitableMethodNotAccessible = true;
/*     */             }
/*     */           
/*     */           } 
/*     */         } 
/*     */       }
/* 365 */     } else if (logger.isLogEnabled(InternalLogger.Level.WARN)) {
/*     */       
/* 367 */       logger.log(InternalLogger.Level.WARN, "doFindMethod: Cannot check for methods taking parameter class " + this.m_referenceClassName + ": " + targetClass
/*     */ 
/*     */           
/* 370 */           .getName() + " does not see it", null);
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 375 */     if (suitableMethodNotAccessible) {
/*     */       
/* 377 */       logger.log(InternalLogger.Level.ERROR, "doFindMethod: Suitable but non-accessible method found in class {0}", null, new Object[] { targetClass
/*     */             
/* 379 */             .getName() });
/* 380 */       throw new SuitableMethodNotAccessibleException();
/*     */     } 
/*     */ 
/*     */     
/* 384 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void setTypes(List<ValueUtils.ValueType> types) {
/* 390 */     this.m_paramTypes = types;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Method getServiceReferenceMethod(Class<?> targetClass, boolean acceptPrivate, boolean acceptPackage, ComponentLogger logger) throws SuitableMethodNotAccessibleException, InvocationTargetException {
/* 415 */     return getMethod(targetClass, getMethodName(), new Class[] { ClassUtils.SERVICE_REFERENCE_CLASS }, acceptPrivate, acceptPackage, logger);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Method getComponentObjectsMethod(Class<?> targetClass, boolean acceptPrivate, boolean acceptPackage, ComponentLogger logger) throws SuitableMethodNotAccessibleException, InvocationTargetException {
/* 422 */     return getMethod(targetClass, getMethodName(), new Class[] { ClassUtils.COMPONENTS_SERVICE_OBJECTS_CLASS }, acceptPrivate, acceptPackage, logger);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Method getServiceObjectMethod(Class<?> targetClass, Class<?> parameterClass, boolean acceptPrivate, boolean acceptPackage, ComponentLogger logger) throws SuitableMethodNotAccessibleException, InvocationTargetException {
/* 450 */     return getMethod(targetClass, getMethodName(), new Class[] { parameterClass }, acceptPrivate, acceptPackage, logger);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Method getServiceObjectAssignableMethod(Class<?> targetClass, Class<?> parameterClass, boolean acceptPrivate, boolean acceptPackage, ComponentLogger logger) throws SuitableMethodNotAccessibleException {
/* 477 */     Method[] candidateBindMethods = targetClass.getDeclaredMethods();
/* 478 */     boolean suitableNotAccessible = false;
/*     */     
/* 480 */     if (logger.isLogEnabled(InternalLogger.Level.DEBUG))
/*     */     {
/* 482 */       logger.log(InternalLogger.Level.DEBUG, "getServiceObjectAssignableMethod: Checking " + candidateBindMethods.length + " declared method in class " + targetClass
/*     */ 
/*     */           
/* 485 */           .getName(), null);
/*     */     }
/*     */ 
/*     */     
/* 489 */     for (int i = 0; i < candidateBindMethods.length; i++) {
/*     */       
/* 491 */       Method method = candidateBindMethods[i];
/* 492 */       if (logger.isLogEnabled(InternalLogger.Level.DEBUG))
/*     */       {
/* 494 */         logger.log(InternalLogger.Level.DEBUG, "getServiceObjectAssignableMethod: Checking " + method, null);
/*     */       }
/*     */ 
/*     */ 
/*     */       
/* 499 */       Class<?>[] parameters = method.getParameterTypes();
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 504 */       if (parameters.length == 1 && method.getName().equals(getMethodName())) {
/*     */ 
/*     */         
/* 507 */         if (logger.isLogEnabled(InternalLogger.Level.DEBUG))
/*     */         {
/* 509 */           logger.log(InternalLogger.Level.DEBUG, "getServiceObjectAssignableMethod: Considering " + method, null);
/*     */         }
/*     */ 
/*     */ 
/*     */         
/* 514 */         Class<?> theParameter = parameters[0];
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 519 */         if (theParameter.isAssignableFrom(parameterClass)) {
/*     */           
/* 521 */           if (accept(method, acceptPrivate, acceptPackage, false))
/*     */           {
/* 523 */             return method;
/*     */           }
/*     */ 
/*     */           
/* 527 */           suitableNotAccessible = true;
/*     */         }
/* 529 */         else if (logger.isLogEnabled(InternalLogger.Level.DEBUG)) {
/*     */           
/* 531 */           logger.log(InternalLogger.Level.DEBUG, "getServiceObjectAssignableMethod: Parameter failure: Required " + theParameter + "; actual " + parameterClass
/*     */ 
/*     */               
/* 534 */               .getName(), null);
/*     */         } 
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 542 */     if (suitableNotAccessible)
/*     */     {
/* 544 */       throw new SuitableMethodNotAccessibleException();
/*     */     }
/*     */ 
/*     */     
/* 548 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Method getServiceObjectWithMapMethod(Class<?> targetClass, Class<?> parameterClass, boolean acceptPrivate, boolean acceptPackage, ComponentLogger logger) throws SuitableMethodNotAccessibleException, InvocationTargetException {
/* 576 */     return getMethod(targetClass, getMethodName(), new Class[] { parameterClass, ClassUtils.MAP_CLASS }, acceptPrivate, acceptPackage, logger);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Method getServiceObjectAssignableWithMapMethod(Class<?> targetClass, Class<?> parameterClass, boolean acceptPrivate, boolean acceptPackage) throws SuitableMethodNotAccessibleException {
/* 602 */     Method[] candidateBindMethods = targetClass.getDeclaredMethods();
/* 603 */     boolean suitableNotAccessible = false;
/*     */ 
/*     */     
/* 606 */     for (int i = 0; i < candidateBindMethods.length; i++) {
/*     */       
/* 608 */       Method method = candidateBindMethods[i];
/* 609 */       Class<?>[] parameters = method.getParameterTypes();
/* 610 */       if (parameters.length == 2 && method.getName().equals(getMethodName()))
/*     */       {
/*     */ 
/*     */         
/* 614 */         if (parameters[0].isAssignableFrom(parameterClass) && parameters[1] == ClassUtils.MAP_CLASS) {
/*     */           
/* 616 */           if (accept(method, acceptPrivate, acceptPackage, false))
/*     */           {
/* 618 */             return method;
/*     */           }
/*     */ 
/*     */           
/* 622 */           suitableNotAccessible = true;
/*     */         } 
/*     */       }
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 629 */     if (suitableNotAccessible)
/*     */     {
/* 631 */       throw new SuitableMethodNotAccessibleException();
/*     */     }
/*     */ 
/*     */     
/* 635 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Method getMapMethod(Class<?> targetClass, Class<?> parameterClass, boolean acceptPrivate, boolean acceptPackage, ComponentLogger logger) throws SuitableMethodNotAccessibleException, InvocationTargetException {
/* 661 */     return getMethod(targetClass, getMethodName(), new Class[] { ClassUtils.MAP_CLASS }, acceptPrivate, acceptPackage, logger);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <S, T> boolean getServiceObject(BindParameters parameters, BundleContext context) {
/* 669 */     if (parameters.getRefPair().getServiceObject(parameters.getComponentContext()) == null && 
/* 670 */       methodExists(parameters.getComponentContext().getLogger()))
/*     */     {
/* 672 */       if (this.m_paramTypes.contains(ValueUtils.ValueType.ref_serviceType) || this.m_paramTypes
/* 673 */         .contains(ValueUtils.ValueType.ref_logger) || this.m_paramTypes
/* 674 */         .contains(ValueUtils.ValueType.ref_formatterLogger)) {
/* 675 */         return parameters.getRefPair().getServiceObject(parameters.getComponentContext(), context);
/*     */       }
/*     */     }
/* 678 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected Object[] getParameters(Method method, BindParameters bp) {
/* 684 */     ScrComponentContext key = bp.getComponentContext();
/* 685 */     Object[] result = new Object[this.m_paramTypes.size()];
/* 686 */     RefPair<?, ?> refPair = bp.getRefPair();
/* 687 */     int i = 0;
/* 688 */     for (ValueUtils.ValueType pt : this.m_paramTypes) {
/*     */       
/* 690 */       result[i] = ValueUtils.getValue(getComponentClass().getName(), pt, method
/* 691 */           .getParameterTypes()[i], key, refPair, null);
/* 692 */       i++;
/*     */     } 
/* 694 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String getMethodNamePrefix() {
/* 701 */     return "bind";
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.apache.felix.scr-2.2.6.jar!\org\apache\felix\scr\impl\inject\methods\BindMethod.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */