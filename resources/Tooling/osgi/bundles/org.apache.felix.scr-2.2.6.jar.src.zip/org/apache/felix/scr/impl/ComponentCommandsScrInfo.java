/*     */ package org.apache.felix.scr.impl;
/*     */ 
/*     */ import java.io.PrintWriter;
/*     */ import org.apache.felix.scr.info.ScrInfo;
/*     */ import org.osgi.framework.Bundle;
/*     */ import org.osgi.framework.BundleContext;
/*     */ import org.osgi.service.component.runtime.dto.ComponentDescriptionDTO;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ComponentCommandsScrInfo
/*     */   implements ScrInfo
/*     */ {
/*     */   private final ComponentCommands commands;
/*     */   private final BundleContext context;
/*     */   
/*     */   ComponentCommandsScrInfo(ComponentCommands commands, BundleContext context) {
/*  35 */     this.commands = commands;
/*  36 */     this.context = context;
/*     */   }
/*     */ 
/*     */   
/*     */   public void list(String bundleIdentifier, PrintWriter out) {
/*     */     CharSequence formatted;
/*     */     try {
/*  43 */       ComponentDescriptionDTO[] dtos = (bundleIdentifier == null) ? this.commands.list() : this.commands.list(getBundleID(bundleIdentifier));
/*  44 */       if (dtos != null) {
/*  45 */         formatted = this.commands.format(dtos, 1);
/*     */       } else {
/*  47 */         formatted = "No components found for bundle  " + bundleIdentifier;
/*     */       } 
/*  49 */     } catch (Exception e) {
/*  50 */       throw new RuntimeException("Error listing or formatting SCR runtime information", e);
/*     */     } 
/*  52 */     out.println(formatted);
/*     */   }
/*     */   
/*     */   private long getBundleID(String bundleIdentifier) {
/*     */     try {
/*  57 */       return Long.parseLong(bundleIdentifier);
/*  58 */     } catch (NumberFormatException e) {
/*     */       
/*  60 */       Bundle bundle = findBundle(bundleIdentifier);
/*  61 */       if (bundle == null) throw new IllegalArgumentException("Cannot find bundle with ID: " + bundleIdentifier); 
/*  62 */       return bundle.getBundleId();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void info(String componentId, PrintWriter out) {
/*  68 */     if (componentId != null) {
/*     */       Object infoObj;
/*     */       try {
/*  71 */         long configId = Long.parseLong(componentId);
/*  72 */         infoObj = this.commands.info(configId);
/*  73 */       } catch (NumberFormatException e) {
/*  74 */         infoObj = this.commands.info(componentId);
/*     */       } 
/*  76 */       CharSequence formatted = format(infoObj, out, 0);
/*  77 */       if (formatted == null) {
/*  78 */         out.println("No component found with ID " + componentId);
/*     */       } else {
/*  80 */         out.println(formatted);
/*     */       } 
/*     */       
/*     */       return;
/*     */     } 
/*  85 */     ComponentDescriptionDTO[] components = this.commands.list();
/*  86 */     if (components.length > 0) {
/*  87 */       for (ComponentDescriptionDTO componentDescriptionDTO : components) {
/*  88 */         out.println(format(componentDescriptionDTO, out, 0));
/*     */       }
/*     */     } else {
/*  91 */       out.println("No component found.");
/*     */     } 
/*     */   }
/*     */   
/*     */   private CharSequence format(Object info, PrintWriter out, int level) {
/*  96 */     if (info != null) {
/*     */       try {
/*  98 */         return this.commands.format(info, level);
/*  99 */       } catch (Exception e) {
/* 100 */         throw new RuntimeException("Error formatting SCR runtime information", e);
/*     */       } 
/*     */     }
/* 103 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public void config(PrintWriter out) {
/* 108 */     out.println(this.commands.config());
/*     */   }
/*     */   
/*     */   private Bundle findBundle(String bsn) {
/* 112 */     for (Bundle b : this.context.getBundles()) {
/* 113 */       if (b.getSymbolicName().equals(bsn)) return b; 
/*     */     } 
/* 115 */     return null;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.apache.felix.scr-2.2.6.jar!\org\apache\felix\scr\impl\ComponentCommandsScrInfo.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */