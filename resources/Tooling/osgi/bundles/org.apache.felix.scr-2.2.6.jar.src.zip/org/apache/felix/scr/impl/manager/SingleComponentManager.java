/*      */ package org.apache.felix.scr.impl.manager;
/*      */ 
/*      */ import java.util.ArrayList;
/*      */ import java.util.Dictionary;
/*      */ import java.util.HashMap;
/*      */ import java.util.Hashtable;
/*      */ import java.util.Iterator;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.concurrent.atomic.AtomicInteger;
/*      */ import org.apache.felix.scr.impl.inject.ComponentMethods;
/*      */ import org.apache.felix.scr.impl.inject.LifecycleMethod;
/*      */ import org.apache.felix.scr.impl.inject.MethodResult;
/*      */ import org.apache.felix.scr.impl.inject.OpenStatus;
/*      */ import org.apache.felix.scr.impl.inject.RefPair;
/*      */ import org.apache.felix.scr.impl.inject.ReferenceMethod;
/*      */ import org.apache.felix.scr.impl.logger.InternalLogger;
/*      */ import org.apache.felix.scr.impl.metadata.DSVersion;
/*      */ import org.apache.felix.scr.impl.metadata.ReferenceMetadata;
/*      */ import org.apache.felix.scr.impl.metadata.TargetedPID;
/*      */ import org.osgi.framework.Bundle;
/*      */ import org.osgi.framework.ServiceFactory;
/*      */ import org.osgi.framework.ServiceReference;
/*      */ import org.osgi.framework.ServiceRegistration;
/*      */ import org.osgi.service.component.ComponentInstance;
/*      */ import org.osgi.util.promise.Deferred;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class SingleComponentManager<S>
/*      */   extends AbstractComponentManager<S>
/*      */   implements ServiceFactory<S>
/*      */ {
/*   59 */   private final AtomicInteger m_useCount = new AtomicInteger();
/*      */ 
/*      */ 
/*      */   
/*      */   private volatile ComponentContextImpl<S> m_componentContext;
/*      */ 
/*      */ 
/*      */   
/*      */   private Map<String, Object> m_configurationProperties;
/*      */ 
/*      */ 
/*      */   
/*      */   private Map<String, Object> m_factoryProperties;
/*      */ 
/*      */ 
/*      */   
/*      */   private Map<String, Object> m_properties;
/*      */ 
/*      */   
/*      */   private Dictionary<String, Object> m_serviceProperties;
/*      */ 
/*      */ 
/*      */   
/*      */   public SingleComponentManager(ComponentContainer<S> container, ComponentMethods<S> componentMethods) {
/*   83 */     this(container, componentMethods, false);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public SingleComponentManager(ComponentContainer<S> container, ComponentMethods<S> componentMethods, boolean factoryInstance) {
/*   89 */     super(container, componentMethods, factoryInstance);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   void clear() {
/*   95 */     this.m_container.disposed(this);
/*      */     
/*   97 */     super.clear();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean createComponent(ComponentContextImpl<S> componentContext) {
/*  109 */     if (!isStateLocked())
/*      */     {
/*  111 */       throw new IllegalStateException("need write lock (createComponent)");
/*      */     }
/*  113 */     if (this.m_componentContext == null) {
/*      */       
/*  115 */       S tmpComponent = createImplementationObject((Bundle)null, new SetImplementationObject<S>()
/*      */           {
/*      */             
/*      */             public void presetComponentContext(ComponentContextImpl<S> componentContext)
/*      */             {
/*  120 */               SingleComponentManager.this.m_componentContext = componentContext;
/*      */             }
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*      */             public void resetImplementationObject(S implementationObject) {
/*  127 */               SingleComponentManager.this.m_componentContext = null;
/*      */             }
/*      */           },  componentContext);
/*      */ 
/*      */       
/*  132 */       if (tmpComponent == null)
/*      */       {
/*  134 */         return false;
/*      */       }
/*      */ 
/*      */       
/*  138 */       getLogger().log(InternalLogger.Level.DEBUG, "Set implementation object for component", null);
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       try {
/*  144 */         this.m_container.getActivator().missingServicePresent(getServiceReference());
/*      */       }
/*  146 */       catch (IllegalStateException ise) {
/*      */         
/*  148 */         return false;
/*      */       } 
/*      */     } 
/*  151 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void deleteComponent(int reason) {
/*  158 */     if (!isStateLocked())
/*      */     {
/*  160 */       throw new IllegalStateException("need write lock (deleteComponent)");
/*      */     }
/*  162 */     if (this.m_componentContext != null) {
/*      */       
/*  164 */       this.m_useCount.set(0);
/*  165 */       disposeImplementationObject(this.m_componentContext, reason);
/*  166 */       this.m_componentContext = null;
/*  167 */       getLogger().log(InternalLogger.Level.DEBUG, "Unset and deconfigured implementation object for component in deleteComponent for reason {0}", null, new Object[] { REASONS[reason] });
/*      */ 
/*      */       
/*  170 */       clearServiceProperties();
/*      */     } 
/*      */   } protected static interface SetImplementationObject<S> {
/*      */     void presetComponentContext(ComponentContextImpl<S> param1ComponentContextImpl);
/*      */     void resetImplementationObject(S param1S); }
/*      */   void clearServiceProperties() {
/*  176 */     this.m_properties = null;
/*  177 */     this.m_serviceProperties = null;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public ComponentInstance<S> getComponentInstance() {
/*  183 */     return (this.m_componentContext == null) ? null : this.m_componentContext.getComponentInstance();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private S getInstance() {
/*  196 */     return (this.m_componentContext == null) ? null : this.m_componentContext.getImplementationObject(true);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected S createImplementationObject(Bundle usingBundle, SetImplementationObject<S> setter, ComponentContextImpl<S> componentContext) {
/*  231 */     S implementationObject = null;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  236 */     Bundle bundle = getBundle();
/*  237 */     if (bundle == null) {
/*      */       
/*  239 */       getLogger().log(InternalLogger.Level.WARN, "Bundle shut down during instantiation of the implementation object", null);
/*      */ 
/*      */       
/*  242 */       return null;
/*      */     } 
/*      */ 
/*      */     
/*  246 */     List<OpenStatus<S, ?>> openStatusList = new ArrayList<>();
/*      */ 
/*      */     
/*  249 */     Map<ReferenceMetadata, OpenStatus<S, ?>> paramMap = (getComponentMetadata().getNumberOfConstructorParameters() > 0) ? new HashMap<>() : null;
/*  250 */     boolean failed = false;
/*  251 */     for (DependencyManager<S, ?> dm : getDependencyManagers()) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  256 */       OpenStatus<S, ?> open = dm.open(componentContext, componentContext.getEdgeInfo(dm));
/*  257 */       if (open == null) {
/*      */         
/*  259 */         getLogger().log(InternalLogger.Level.DEBUG, "Cannot create component instance due to failure to bind reference {0}", null, new Object[] { dm
/*      */               
/*  261 */               .getName() });
/*      */         
/*  263 */         failed = true;
/*      */         break;
/*      */       } 
/*  266 */       openStatusList.add(open);
/*  267 */       if (dm.getReferenceMetadata().getParameterIndex() != null) {
/*      */         
/*  269 */         if (!dm.bindDependency(componentContext, ReferenceMethod.NOPReferenceMethod, open)) {
/*      */           
/*  271 */           getLogger().log(InternalLogger.Level.DEBUG, "Cannot create component instance due to failure to bind reference {0}", null, new Object[] { dm
/*      */                 
/*  273 */                 .getName() });
/*  274 */           failed = true;
/*      */           
/*      */           break;
/*      */         } 
/*  278 */         paramMap.put(dm.getReferenceMetadata(), open);
/*      */       } 
/*      */     } 
/*      */     
/*  282 */     if (!failed) {
/*      */ 
/*      */       
/*      */       try {
/*  286 */         implementationObject = (S)getComponentMethods().getConstructor().newInstance(componentContext, paramMap);
/*      */ 
/*      */ 
/*      */       
/*      */       }
/*  291 */       catch (InstantiationException ie) {
/*      */ 
/*      */         
/*  294 */         getLogger().log(InternalLogger.Level.ERROR, "Error during instantiation of the implementation object: " + ie
/*      */             
/*  296 */             .getMessage(), null);
/*      */         
/*  298 */         setFailureReason(ie);
/*  299 */         return null;
/*      */       }
/*  301 */       catch (Throwable t) {
/*      */ 
/*      */         
/*  304 */         getLogger().log(InternalLogger.Level.ERROR, "Error during instantiation of the implementation object", t);
/*      */         
/*  306 */         setFailureReason(t);
/*  307 */         return null;
/*      */       } 
/*      */       
/*  310 */       componentContext.setImplementationObject(implementationObject);
/*      */ 
/*      */       
/*  313 */       setter.presetComponentContext(componentContext);
/*      */ 
/*      */       
/*  316 */       Iterator<OpenStatus<S, ?>> iter = openStatusList.iterator();
/*  317 */       for (DependencyManager<S, ?> dm : getDependencyManagers()) {
/*      */         
/*  319 */         OpenStatus<S, ?> open = iter.next();
/*  320 */         if (!dm.bind(componentContext, open)) {
/*      */           
/*  322 */           getLogger().log(InternalLogger.Level.DEBUG, "Cannot create component instance due to failure to bind reference {0}", null, new Object[] { dm
/*      */                 
/*  324 */                 .getName() });
/*  325 */           failed = true;
/*      */           break;
/*      */         } 
/*      */       } 
/*      */     } 
/*  330 */     if (failed) {
/*      */ 
/*      */       
/*  333 */       int skipCount = getReversedDependencyManagers().size() - openStatusList.size();
/*  334 */       for (DependencyManager<S, ?> md : getReversedDependencyManagers()) {
/*      */         
/*  336 */         if (skipCount > 0) {
/*      */           
/*  338 */           skipCount--;
/*      */         }
/*      */         else {
/*      */           
/*  342 */           md.close(componentContext, componentContext.getEdgeInfo(md));
/*      */         } 
/*  344 */         md.deactivate();
/*      */       } 
/*      */       
/*  347 */       setter.resetImplementationObject(implementationObject);
/*  348 */       return null;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  353 */     MethodResult failedResult = new MethodResult(true, new HashMap<>());
/*  354 */     MethodResult result = getComponentMethods().getActivateMethod().invoke(implementationObject, componentContext, 1, failedResult);
/*      */     
/*  356 */     if (result == failedResult) {
/*      */       
/*  358 */       setFailureReason((Throwable)failedResult.getResult().get("exception"));
/*      */ 
/*      */       
/*  361 */       for (DependencyManager<S, ?> md : getReversedDependencyManagers())
/*      */       {
/*  363 */         md.close(componentContext, componentContext.getEdgeInfo(md));
/*      */       }
/*      */       
/*  366 */       if (implementationObject != null)
/*      */       {
/*      */         
/*  369 */         setter.resetImplementationObject(implementationObject);
/*      */       }
/*      */       
/*  372 */       return null;
/*      */     } 
/*      */ 
/*      */     
/*  376 */     componentContext.setImplementationAccessible(true);
/*      */ 
/*      */ 
/*      */     
/*      */     try {
/*  381 */       this.m_container.getActivator().leaveCreate(getServiceReference());
/*      */     }
/*  383 */     catch (IllegalStateException ise) {
/*      */ 
/*      */       
/*  386 */       setFailureReason(ise);
/*      */       
/*  388 */       for (DependencyManager<S, ?> md : getReversedDependencyManagers())
/*      */       {
/*  390 */         md.close(componentContext, componentContext.getEdgeInfo(md));
/*      */       }
/*      */       
/*  393 */       if (implementationObject != null)
/*      */       {
/*      */         
/*  396 */         setter.resetImplementationObject(implementationObject);
/*      */       }
/*  398 */       return null;
/*      */     } 
/*      */ 
/*      */     
/*  402 */     setServiceProperties(result, null);
/*      */ 
/*      */     
/*  405 */     return implementationObject;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void disposeImplementationObject(ComponentContextImpl<S> componentContext, int reason) {
/*  412 */     componentContext.setImplementationAccessible(false);
/*  413 */     S implementationObject = componentContext.getImplementationObject(false);
/*      */     
/*  415 */     if (implementationObject != null) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  421 */       MethodResult result = getComponentMethods().getDeactivateMethod().invoke(implementationObject, componentContext, reason, null);
/*      */       
/*  423 */       if (result != null)
/*      */       {
/*  425 */         setServiceProperties(result, null);
/*      */       }
/*      */       
/*  428 */       for (DependencyManager<S, ?> md : getReversedDependencyManagers())
/*      */       {
/*  430 */         md.close(componentContext, componentContext.getEdgeInfo(md));
/*      */       }
/*      */     } 
/*  433 */     componentContext.cleanup();
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   <T> void invokeBindMethod(DependencyManager<S, T> dependencyManager, RefPair<S, T> refPair, int trackingCount) {
/*  439 */     ComponentContextImpl<S> componentContext = this.m_componentContext;
/*  440 */     if (componentContext != null) {
/*      */       
/*  442 */       EdgeInfo info = componentContext.getEdgeInfo(dependencyManager);
/*  443 */       dependencyManager.invokeBindMethod(componentContext, refPair, trackingCount, info);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   <T> boolean invokeUpdatedMethod(DependencyManager<S, T> dependencyManager, RefPair<S, T> refPair, int trackingCount) {
/*  450 */     ComponentContextImpl<S> componentContext = this.m_componentContext;
/*  451 */     if (componentContext != null) {
/*      */       
/*  453 */       EdgeInfo info = componentContext.getEdgeInfo(dependencyManager);
/*  454 */       return dependencyManager.invokeUpdatedMethod(componentContext, refPair, trackingCount, info);
/*      */     } 
/*  456 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   <T> void invokeUnbindMethod(DependencyManager<S, T> dependencyManager, RefPair<S, T> oldRefPair, int trackingCount) {
/*  462 */     ComponentContextImpl<S> componentContext = this.m_componentContext;
/*  463 */     if (componentContext != null) {
/*      */       
/*  465 */       EdgeInfo info = componentContext.getEdgeInfo(dependencyManager);
/*  466 */       dependencyManager.invokeUnbindMethod(componentContext, oldRefPair, trackingCount, info);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   protected void setFactoryProperties(Dictionary<String, ?> dictionary) {
/*  472 */     this.m_factoryProperties = copyToMap(dictionary, true);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void registerComponentId() {
/*  479 */     super.registerComponentId();
/*  480 */     this.m_properties = null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void unregisterComponentId() {
/*  487 */     super.unregisterComponentId();
/*  488 */     this.m_properties = null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Map<String, Object> getProperties() {
/*  504 */     if (this.m_properties == null) {
/*      */ 
/*      */       
/*  507 */       Map<String, Object> props = new HashMap<>();
/*  508 */       if (this.m_configurationProperties != null)
/*      */       {
/*  510 */         props.putAll(this.m_configurationProperties);
/*      */       }
/*  512 */       if (this.m_factoryProperties != null) {
/*      */         
/*  514 */         props.putAll(this.m_factoryProperties);
/*  515 */         if (getComponentMetadata().getDSVersion().isDS13() && this.m_factoryProperties.containsKey("service.pid")) {
/*      */           
/*  517 */           List<String> servicePids = new ArrayList<>();
/*  518 */           Object configPropServicePids = this.m_configurationProperties.get("service.pid");
/*  519 */           if (configPropServicePids instanceof List) {
/*      */ 
/*      */             
/*  522 */             List<String> l = (List<String>)configPropServicePids;
/*  523 */             servicePids.addAll(l);
/*      */           }
/*      */           else {
/*      */             
/*  527 */             servicePids.add(configPropServicePids.toString());
/*      */           } 
/*  529 */           if (this.m_factoryProperties.get("service.pid") instanceof String)
/*      */           {
/*  531 */             servicePids.add((String)this.m_factoryProperties.get("service.pid"));
/*      */           }
/*      */           
/*  534 */           if (servicePids.size() == 1) {
/*      */             
/*  536 */             props.put("service.pid", servicePids.get(0));
/*      */           }
/*      */           else {
/*      */             
/*  540 */             props.put("service.pid", servicePids);
/*      */           } 
/*      */         } 
/*      */       } 
/*      */ 
/*      */       
/*  546 */       props.put("component.name", getComponentMetadata().getName());
/*  547 */       props.put("component.id", Long.valueOf(getId()));
/*      */       
/*  549 */       this.m_properties = props;
/*      */     } 
/*      */     
/*  552 */     return this.m_properties;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void setServiceProperties(Dictionary<String, ?> serviceProperties) {
/*  558 */     if (serviceProperties == null || serviceProperties.isEmpty()) {
/*      */       
/*  560 */       this.m_serviceProperties = null;
/*      */     }
/*      */     else {
/*      */       
/*  564 */       this.m_serviceProperties = copyToDictionary(serviceProperties, false);
/*      */       
/*  566 */       this.m_serviceProperties.put("component.name", getComponentMetadata().getName());
/*  567 */       this.m_serviceProperties.put("component.id", Long.valueOf(getId()));
/*      */     } 
/*      */     
/*  570 */     updateServiceRegistration();
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   void postRegister() {
/*  576 */     if (this.m_serviceProperties != null)
/*      */     {
/*  578 */       updateServiceRegistration();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   void preDeregister() {
/*  585 */     if (this.m_componentContext != null)
/*      */     {
/*  587 */       this.m_componentContext.unsetServiceRegistration();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public Dictionary<String, Object> getServiceProperties() {
/*  594 */     if (this.m_serviceProperties != null)
/*      */     {
/*  596 */       return this.m_serviceProperties;
/*      */     }
/*  598 */     return super.getServiceProperties();
/*      */   }
/*      */ 
/*      */   
/*      */   final ServiceReference<S> getServiceReference() {
/*  603 */     ServiceRegistration<S> reg = getServiceRegistration();
/*  604 */     if (reg != null)
/*      */     {
/*  606 */       return reg.getReference();
/*      */     }
/*  608 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected ServiceRegistration<S> getServiceRegistration() {
/*  614 */     if (getComponentMetadata().getDSVersion() == DSVersion.DS12Felix)
/*      */     {
/*  616 */       return (this.m_componentContext != null) ? this.m_componentContext.getServiceRegistration() : null;
/*      */     }
/*  618 */     return super.getServiceRegistration();
/*      */   }
/*      */ 
/*      */   
/*      */   private void updateServiceRegistration() {
/*  623 */     ServiceRegistration<S> sr = getServiceRegistration();
/*  624 */     if (sr != null) {
/*      */       
/*      */       try
/*      */       {
/*      */         
/*  629 */         Dictionary<String, Object> regProps = getServiceProperties();
/*  630 */         if (!servicePropertiesMatches(sr, regProps))
/*      */         {
/*  632 */           sr.setProperties(regProps);
/*      */         }
/*      */         else
/*      */         {
/*  636 */           getLogger().log(InternalLogger.Level.DEBUG, "Not updating service registration, no change in properties", null);
/*      */         
/*      */         }
/*      */       
/*      */       }
/*  641 */       catch (IllegalStateException illegalStateException)
/*      */       {
/*      */       
/*      */       }
/*  645 */       catch (IllegalArgumentException iae)
/*      */       {
/*  647 */         getLogger().log(InternalLogger.Level.ERROR, "Unexpected configuration property problem when updating service registration", iae);
/*      */       
/*      */       }
/*  650 */       catch (Throwable t)
/*      */       {
/*  652 */         getLogger().log(InternalLogger.Level.ERROR, "Unexpected problem when updating service registration", t);
/*      */       }
/*      */     
/*      */     }
/*      */     else {
/*      */       
/*  658 */       getLogger().log(InternalLogger.Level.DEBUG, "No service registration to update", null);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void reconfigure(Map<String, Object> configuration, boolean configurationDeleted, TargetedPID factoryPid) {
/*  684 */     this.m_configurationProperties = configuration;
/*      */     
/*  686 */     reconfigure(configurationDeleted);
/*      */   }
/*      */ 
/*      */   
/*      */   void reconfigure(boolean configurationDeleted) {
/*  691 */     Deferred<Void> enableLatch = enableLatchWait();
/*      */ 
/*      */     
/*      */     try {
/*  695 */       this.m_properties = null;
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  700 */       if (!getState().isEnabled()) {
/*      */ 
/*      */         
/*  703 */         getLogger().log(InternalLogger.Level.DEBUG, "Component can not be activated since it is in state {0}", null, new Object[] {
/*      */               
/*  705 */               getState()
/*      */             });
/*      */ 
/*      */         
/*      */         return;
/*      */       } 
/*      */       
/*  712 */       obtainActivationWriteLock();
/*      */       
/*      */       try {
/*  715 */         if (!getState().isSatisfied() && !getComponentMetadata().isConfigurationIgnored()) {
/*      */           
/*  717 */           getLogger().log(InternalLogger.Level.DEBUG, "Attempting to activate unsatisfied component", null);
/*      */           
/*  719 */           updateTargets(getProperties());
/*  720 */           releaseActivationWriteeLock();
/*  721 */           activateInternal();
/*      */           
/*      */           return;
/*      */         } 
/*  725 */         if (!modify(configurationDeleted))
/*      */         {
/*      */           
/*  728 */           getLogger().log(InternalLogger.Level.DEBUG, "Deactivating and Activating to reconfigure from configuration", null);
/*      */ 
/*      */ 
/*      */           
/*  732 */           int reason = configurationDeleted ? 4 : 3;
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  737 */           releaseActivationWriteeLock();
/*      */           
/*  739 */           boolean dispose = this.m_factoryInstance;
/*  740 */           deactivateInternal(reason, dispose, dispose);
/*  741 */           if (!dispose)
/*      */           {
/*  743 */             obtainActivationWriteLock();
/*      */             
/*      */             try {
/*  746 */               updateTargets(getProperties());
/*      */             }
/*      */             finally {
/*      */               
/*  750 */               releaseActivationWriteeLock();
/*      */             } 
/*  752 */             activateInternal();
/*      */           }
/*      */         
/*      */         }
/*      */       
/*      */       } finally {
/*      */         
/*  759 */         releaseActivationWriteeLock();
/*      */       }
/*      */     
/*      */     } finally {
/*      */       
/*  764 */       enableLatch.resolve(null);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean modify(boolean configurationDeleted) {
/*  772 */     if (configurationDeleted && !getComponentMetadata().isDeleteCallsModify()) {
/*  773 */       return false;
/*      */     }
/*      */ 
/*      */     
/*  777 */     if (getComponentMetadata().getModified() == null) {
/*      */       
/*  779 */       getLogger().log(InternalLogger.Level.DEBUG, "No modified method, cannot update dynamically", null);
/*      */       
/*  781 */       return false;
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  790 */     Map<String, Object> props = getProperties();
/*  791 */     for (DependencyManager<S, ?> dm : getDependencyManagers()) {
/*      */       
/*  793 */       if (!dm.canUpdateDynamically(props)) {
/*      */         
/*  795 */         getLogger().log(InternalLogger.Level.DEBUG, "Cannot dynamically update the configuration due to dependency changes induced on dependency {0}", null, new Object[] { dm
/*      */               
/*  797 */               .getName() });
/*  798 */         return false;
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  806 */     obtainStateLock();
/*      */ 
/*      */     
/*      */     try {
/*  810 */       MethodResult result = invokeModifiedMethod();
/*  811 */       updateTargets(props);
/*  812 */       if (result == null) {
/*      */ 
/*      */         
/*  815 */         getLogger().log(InternalLogger.Level.ERROR, "Declared modify method ''{0}'' cannot be found, configuring by reactivation", null, new Object[] {
/*      */               
/*  817 */               getComponentMetadata().getModified() });
/*  818 */         return false;
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  824 */       if (!verifyDependencyManagers()) {
/*      */         
/*  826 */         getLogger().log(InternalLogger.Level.DEBUG, "Updating the service references caused at least one reference to become unsatisfied, deactivating component", null);
/*      */ 
/*      */         
/*  829 */         return false;
/*      */       } 
/*      */ 
/*      */       
/*  833 */       if (result.hasResult()) {
/*      */         
/*  835 */         setServiceProperties(result, null);
/*      */       }
/*      */       else {
/*      */         
/*  839 */         updateServiceRegistration();
/*      */       } 
/*      */ 
/*      */       
/*  843 */       return true;
/*      */     }
/*      */     finally {
/*      */       
/*  847 */       releaseStateLock();
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   protected MethodResult invokeModifiedMethod() {
/*  853 */     LifecycleMethod modifiedMethod = getComponentMethods().getModifiedMethod();
/*  854 */     if (getInstance() != null)
/*      */     {
/*  856 */       return modifiedMethod.invoke(getInstance(), this.m_componentContext, -1, MethodResult.VOID);
/*      */     }
/*      */     
/*  859 */     return MethodResult.VOID;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean servicePropertiesMatches(ServiceRegistration<S> reg, Dictionary<String, Object> props) {
/*  875 */     Dictionary<String, Object> regProps = new Hashtable<>();
/*  876 */     String[] keys = reg.getReference().getPropertyKeys();
/*  877 */     for (int i = 0; keys != null && i < keys.length; i++) {
/*      */       
/*  879 */       if (!keys[i].equals("objectClass") && 
/*  880 */         !keys[i].equals("service.id"))
/*      */       {
/*  882 */         regProps.put(keys[i], reg.getReference().getProperty(keys[i]));
/*      */       }
/*      */     } 
/*  885 */     return regProps.equals(props);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public S getService(Bundle bundle, ServiceRegistration<S> serviceRegistration) {
/*  891 */     ServiceReference<S> ref = null;
/*      */     
/*      */     try {
/*  894 */       ref = serviceRegistration.getReference();
/*      */     }
/*  896 */     catch (IllegalStateException ise) {
/*      */ 
/*      */       
/*  899 */       return null;
/*      */     } 
/*  901 */     if (this.m_container.getActivator().enterCreate(ref))
/*      */     {
/*      */       
/*  904 */       return null;
/*      */     }
/*      */     
/*      */     try {
/*  908 */       obtainStateLock();
/*      */       
/*      */       try {
/*  911 */         this.m_useCount.incrementAndGet();
/*      */       }
/*      */       finally {
/*      */         
/*  915 */         releaseStateLock();
/*      */       } 
/*  917 */       boolean decrement = true;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     }
/*      */     finally {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  943 */       this.m_container.getActivator().leaveCreate(ref);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   boolean getServiceInternal(ServiceRegistration<S> serviceRegistration) {
/*  951 */     boolean success = true;
/*  952 */     if (this.m_componentContext == null) {
/*      */       
/*  954 */       ComponentContextImpl<S> componentContext = new ComponentContextImpl<>(this, getBundle(), serviceRegistration);
/*  955 */       if (collectDependencies(componentContext)) {
/*      */         
/*  957 */         getLogger().log(InternalLogger.Level.DEBUG, "getService (single component manager) dependencies collected.", null);
/*      */       
/*      */       }
/*      */       else {
/*      */ 
/*      */         
/*  963 */         getLogger().log(InternalLogger.Level.INFO, "Could not obtain all required dependencies, getService returning null", null);
/*      */ 
/*      */         
/*  966 */         return false;
/*      */       } 
/*  968 */       obtainStateLock();
/*      */       
/*      */       try {
/*  971 */         if (this.m_componentContext == null) {
/*      */           
/*  973 */           AbstractComponentManager.State previousState = getState();
/*      */           
/*  975 */           S result = getService(componentContext);
/*  976 */           if (result == null)
/*      */           {
/*  978 */             success = false;
/*      */           }
/*      */           else
/*      */           {
/*  982 */             setState(previousState, AbstractComponentManager.State.active);
/*      */           }
/*      */         
/*      */         } 
/*      */       } finally {
/*      */         
/*  988 */         releaseStateLock();
/*      */       } 
/*      */     } 
/*  991 */     return success;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private S getService(ComponentContextImpl<S> componentContext) {
/*  997 */     if (!getState().isEnabled())
/*      */     {
/*  999 */       return null;
/*      */     }
/*      */     
/* 1002 */     if (createComponent(componentContext))
/*      */     {
/* 1004 */       return getInstance();
/*      */     }
/*      */ 
/*      */ 
/*      */     
/* 1009 */     getLogger().log(InternalLogger.Level.DEBUG, "Failed creating the component instance; see log for reason", null);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     try {
/* 1017 */       deleteComponent(0);
/*      */     }
/* 1019 */     catch (Throwable t) {
/*      */       
/* 1021 */       getLogger().log(InternalLogger.Level.DEBUG, "Cannot delete incomplete component instance. Ignoring.", t);
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 1026 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void ungetService(Bundle bundle, ServiceRegistration<S> serviceRegistration, S o) {
/* 1033 */     obtainStateLock();
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     try {
/* 1039 */       if (this.m_useCount.decrementAndGet() == 0 && !isImmediate() && 
/* 1040 */         !getComponentMetadata().isFactory() && !keepInstances())
/*      */       {
/* 1042 */         AbstractComponentManager.State previousState = getState();
/* 1043 */         deleteComponent(0);
/* 1044 */         setState(previousState, AbstractComponentManager.State.satisfied);
/*      */       }
/*      */     
/*      */     } finally {
/*      */       
/* 1049 */       releaseStateLock();
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   private boolean keepInstances() {
/* 1055 */     return getComponentMetadata().isDelayedKeepInstances();
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void getComponentManagers(List<AbstractComponentManager<S>> cms) {
/* 1061 */     cms.add(this);
/*      */   }
/*      */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.apache.felix.scr-2.2.6.jar!\org\apache\felix\scr\impl\manager\SingleComponentManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */