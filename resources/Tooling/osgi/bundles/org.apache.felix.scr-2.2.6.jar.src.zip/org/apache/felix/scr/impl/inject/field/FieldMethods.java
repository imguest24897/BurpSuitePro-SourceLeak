/*    */ package org.apache.felix.scr.impl.inject.field;
/*    */ 
/*    */ import org.apache.felix.scr.impl.inject.InitReferenceMethod;
/*    */ import org.apache.felix.scr.impl.inject.ReferenceMethod;
/*    */ import org.apache.felix.scr.impl.inject.ReferenceMethods;
/*    */ import org.apache.felix.scr.impl.metadata.DSVersion;
/*    */ import org.apache.felix.scr.impl.metadata.ReferenceMetadata;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FieldMethods
/*    */   implements ReferenceMethods
/*    */ {
/*    */   private final ReferenceMethod bind;
/*    */   private final ReferenceMethod updated;
/*    */   private final ReferenceMethod unbind;
/*    */   private final InitReferenceMethod init;
/*    */   
/*    */   public FieldMethods(ReferenceMetadata m_dependencyMetadata, Class<?> instanceClass, DSVersion dsVersion, boolean configurableServiceProperties) {
/* 43 */     FieldHandler handler = new FieldHandler(m_dependencyMetadata, instanceClass);
/*    */ 
/*    */ 
/*    */     
/* 47 */     this.bind = handler.getBind();
/* 48 */     this.unbind = handler.getUnbind();
/* 49 */     this.updated = handler.getUpdated();
/* 50 */     this.init = handler.getInit();
/*    */   }
/*    */ 
/*    */   
/*    */   public ReferenceMethod getBind() {
/* 55 */     return this.bind;
/*    */   }
/*    */ 
/*    */   
/*    */   public ReferenceMethod getUnbind() {
/* 60 */     return this.unbind;
/*    */   }
/*    */ 
/*    */   
/*    */   public ReferenceMethod getUpdated() {
/* 65 */     return this.updated;
/*    */   }
/*    */ 
/*    */   
/*    */   public InitReferenceMethod getInit() {
/* 70 */     return this.init;
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.apache.felix.scr-2.2.6.jar!\org\apache\felix\scr\impl\inject\field\FieldMethods.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */