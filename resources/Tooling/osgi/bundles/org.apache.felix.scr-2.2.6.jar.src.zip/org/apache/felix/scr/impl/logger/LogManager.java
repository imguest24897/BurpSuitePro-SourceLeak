/*     */ package org.apache.felix.scr.impl.logger;
/*     */ 
/*     */ import java.io.Closeable;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.concurrent.atomic.AtomicBoolean;
/*     */ import org.osgi.framework.Bundle;
/*     */ import org.osgi.framework.BundleContext;
/*     */ import org.osgi.framework.BundleEvent;
/*     */ import org.osgi.framework.BundleListener;
/*     */ import org.osgi.framework.ServiceReference;
/*     */ import org.osgi.service.log.Logger;
/*     */ import org.osgi.service.log.LoggerFactory;
/*     */ import org.osgi.util.tracker.ServiceTracker;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class LogManager
/*     */   extends ServiceTracker<Object, Object>
/*     */   implements BundleListener
/*     */ {
/*     */   private static final String LOGGER_FACTORY_CLASS_NAME = "org.osgi.service.log.LoggerFactory";
/*     */   final BundleContext scrContext;
/*     */   final BundleContext systemContext;
/*  55 */   final AtomicBoolean closed = new AtomicBoolean(false);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   class Lock
/*     */   {
/*  62 */     final Map<Bundle, LogManager.LogDomain> domains = new HashMap<>();
/*     */     int trackingCount;
/*     */     Object factory;
/*  65 */     int ranking = 0;
/*     */ 
/*     */     
/*     */     synchronized LogManager.LogDomain getLogDomain(Bundle bundle) {
/*  69 */       LogManager.LogDomain domain = this.domains.get(bundle);
/*  70 */       if (domain == null) {
/*     */         
/*  72 */         domain = new LogManager.LogDomain(bundle);
/*  73 */         this.domains.put(bundle, domain);
/*     */       } 
/*  75 */       return domain;
/*     */     }
/*     */ 
/*     */     
/*     */     synchronized void removedFactory(Object service) {
/*  80 */       if (this.factory == service) {
/*     */         
/*  82 */         this.factory = null;
/*  83 */         reset();
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     synchronized void setFactory(int ranking, Object service) {
/*  89 */       if (this.factory == null) {
/*     */         
/*  91 */         this.factory = service;
/*  92 */         this.ranking = ranking;
/*     */       }
/*  94 */       else if (this.ranking < ranking) {
/*     */         
/*  96 */         this.factory = service;
/*  97 */         this.ranking = ranking;
/*  98 */         reset();
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     synchronized void reset() {
/* 104 */       for (LogManager.LogDomain domain : this.domains.values())
/*     */       {
/* 106 */         domain.reset();
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*     */     synchronized Object getLogger(LogManager.LoggerFacade facade, Bundle bundle, String name) {
/* 112 */       if (this.factory == null)
/*     */       {
/* 114 */         return facade.logger = null;
/*     */       }
/*     */ 
/*     */ 
/*     */       
/*     */       try {
/* 120 */         return facade.logger = ((LoggerFactory)this.factory).getLogger(bundle, name, Logger.class);
/*     */       
/*     */       }
/* 123 */       catch (IllegalArgumentException e) {
/*     */ 
/*     */ 
/*     */         
/* 127 */         return ((LoggerFactory)this.factory).getLogger(LogManager.this.context.getBundle(), name, Logger.class);
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     synchronized LogManager.LogDomain remove(Bundle bundle) {
/* 135 */       return this.domains.remove(bundle);
/*     */     }
/*     */ 
/*     */     
/*     */     synchronized void close() {
/* 140 */       reset();
/* 141 */       this.domains.clear();
/*     */     }
/*     */   }
/*     */ 
/*     */   
/* 146 */   final Lock lock = new Lock();
/*     */   
/*     */   private final LogConfiguration config;
/*     */ 
/*     */   
/*     */   LogManager(BundleContext context, LogConfiguration config) {
/* 152 */     super(context, "org.osgi.service.log.LoggerFactory", null);
/* 153 */     this.scrContext = context;
/* 154 */     this.systemContext = context.getBundle("System Bundle").getBundleContext();
/* 155 */     this.config = config;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void init() {
/* 177 */     if (!this.config.isLogExtensionEnabled())
/*     */     {
/*     */ 
/*     */ 
/*     */       
/* 182 */       this.systemContext.addBundleListener(this);
/*     */     }
/* 184 */     open();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Object addingService(ServiceReference<Object> reference) {
/* 190 */     Object service = super.addingService(reference);
/* 191 */     Integer ranking = (Integer)reference.getProperty("service.ranking");
/* 192 */     if (ranking == null)
/* 193 */       ranking = Integer.valueOf(0); 
/* 194 */     this.lock.setFactory(ranking.intValue(), service);
/* 195 */     return service;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void removedService(ServiceReference<Object> reference, Object service) {
/* 201 */     super.removedService(reference, service);
/* 202 */     this.lock.removedFactory(service);
/*     */   }
/*     */ 
/*     */   
/*     */   <T> T getLogger(Bundle bundle, String name, Class<T> type) {
/* 207 */     return type.cast(this.lock.getLogDomain(bundle).getLogger(name));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void bundleChanged(BundleEvent event) {
/* 214 */     if (event.getType() == 4 && !this.closed.get()) {
/*     */       
/* 216 */       LogDomain domain = this.lock.remove(event.getBundle());
/* 217 */       if (domain != null)
/*     */       {
/* 219 */         domain.close();
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   class LogDomain
/*     */     implements Closeable
/*     */   {
/*     */     private final Bundle bundle;
/*     */     
/* 231 */     private final Set<LogManager.LoggerFacade> facades = new HashSet<>();
/*     */ 
/*     */     
/*     */     LogDomain(Bundle bundle) {
/* 235 */       this.bundle = bundle;
/*     */     }
/*     */ 
/*     */     
/*     */     private void reset() {
/* 240 */       synchronized (this.facades) {
/*     */         
/* 242 */         for (LogManager.LoggerFacade facade : this.facades)
/*     */         {
/* 244 */           facade.reset();
/*     */         }
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     LogManager.LoggerFacade getLogger(String name) {
/* 251 */       LogManager.LoggerFacade facade = LogManager.this.createLoggerFacade(this, name);
/* 252 */       synchronized (this.facades) {
/*     */         
/* 254 */         this.facades.add(facade);
/*     */       } 
/* 256 */       return facade;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void close() {
/* 262 */       reset();
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   class LoggerFacade
/*     */   {
/*     */     private final String name;
/*     */     
/*     */     private final LogManager.LogDomain domain;
/*     */     volatile Object logger;
/*     */     volatile String prefix;
/*     */     
/*     */     LoggerFacade(LogManager.LogDomain logDomain, String name) {
/* 276 */       this.domain = logDomain;
/* 277 */       this.name = name;
/*     */     }
/*     */ 
/*     */     
/*     */     void reset() {
/* 282 */       this.logger = null;
/*     */     }
/*     */ 
/*     */     
/*     */     Object getLogger() {
/* 287 */       Object l = this.logger;
/* 288 */       if (l == null)
/*     */       {
/* 290 */         l = LogManager.this.lock.getLogger(this, this.domain.bundle, this.name);
/*     */       }
/* 292 */       return l;
/*     */     }
/*     */ 
/*     */     
/*     */     Bundle getBundle() {
/* 297 */       return this.domain.bundle;
/*     */     }
/*     */ 
/*     */     
/*     */     String getName() {
/* 302 */       return this.name;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void close() {
/* 309 */     if (this.closed.compareAndSet(false, true)) {
/*     */       
/* 311 */       this.lock.close();
/* 312 */       super.close();
/* 313 */       this.systemContext.removeBundleListener(this);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   LoggerFacade createLoggerFacade(LogDomain logDomain, String name) {
/* 319 */     assert !this.closed.get();
/* 320 */     return new LoggerFacade(logDomain, name);
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.apache.felix.scr-2.2.6.jar!\org\apache\felix\scr\impl\logger\LogManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */