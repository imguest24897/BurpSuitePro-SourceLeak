/*     */ package org.apache.felix.scr.impl.manager;
/*     */ 
/*     */ import java.util.Comparator;
/*     */ import java.util.Dictionary;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.concurrent.ConcurrentSkipListMap;
/*     */ import java.util.concurrent.CountDownLatch;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ import org.apache.felix.scr.impl.helper.ComponentServiceObjectsHelper;
/*     */ import org.apache.felix.scr.impl.helper.ReadOnlyDictionary;
/*     */ import org.apache.felix.scr.impl.inject.RefPair;
/*     */ import org.apache.felix.scr.impl.inject.ScrComponentContext;
/*     */ import org.apache.felix.scr.impl.logger.ComponentLogger;
/*     */ import org.apache.felix.scr.impl.logger.InternalLogger;
/*     */ import org.apache.felix.scr.impl.metadata.ComponentMetadata;
/*     */ import org.osgi.framework.Bundle;
/*     */ import org.osgi.framework.BundleContext;
/*     */ import org.osgi.framework.ServiceReference;
/*     */ import org.osgi.framework.ServiceRegistration;
/*     */ import org.osgi.service.component.ComponentInstance;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ComponentContextImpl<S>
/*     */   implements ScrComponentContext
/*     */ {
/*     */   private final SingleComponentManager<S> m_componentManager;
/*     */   private final EdgeInfo[] edgeInfos;
/*  54 */   private final ComponentInstance<S> m_componentInstance = new ComponentInstanceImpl<>(this);
/*     */   
/*     */   private final Bundle m_usingBundle;
/*     */   
/*     */   private volatile ServiceRegistration<S> m_serviceRegistration;
/*     */   
/*     */   private volatile S m_implementationObject;
/*     */   
/*     */   private volatile boolean m_implementationAccessible;
/*     */   
/*  64 */   private final CountDownLatch accessibleLatch = new CountDownLatch(1);
/*     */ 
/*     */   
/*     */   private final ComponentServiceObjectsHelper serviceObjectsHelper;
/*     */ 
/*     */   
/*     */   private Map<String, Map<RefPair<?, ?>, Object>> boundValues;
/*     */ 
/*     */ 
/*     */   
/*     */   public ComponentContextImpl(SingleComponentManager<S> componentManager, Bundle usingBundle, ServiceRegistration<S> serviceRegistration) {
/*  75 */     this.m_componentManager = componentManager;
/*  76 */     this.m_usingBundle = usingBundle;
/*  77 */     this.m_serviceRegistration = serviceRegistration;
/*  78 */     this.edgeInfos = new EdgeInfo[componentManager.getComponentMetadata().getDependencies().size()];
/*  79 */     for (int i = 0; i < this.edgeInfos.length; i++)
/*     */     {
/*  81 */       this.edgeInfos[i] = new EdgeInfo();
/*     */     }
/*  83 */     this.serviceObjectsHelper = new ComponentServiceObjectsHelper(usingBundle.getBundleContext());
/*     */   }
/*     */ 
/*     */   
/*     */   public void unsetServiceRegistration() {
/*  88 */     this.m_serviceRegistration = null;
/*     */   }
/*     */ 
/*     */   
/*     */   public void cleanup() {
/*  93 */     this.serviceObjectsHelper.cleanup();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ComponentServiceObjectsHelper getComponentServiceObjectsHelper() {
/*  99 */     return this.serviceObjectsHelper;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setImplementationObject(S implementationObject) {
/* 104 */     this.m_implementationObject = implementationObject;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setImplementationAccessible(boolean implementationAccessible) {
/* 110 */     this.m_implementationAccessible = implementationAccessible;
/* 111 */     if (implementationAccessible)
/*     */     {
/* 113 */       this.accessibleLatch.countDown();
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   EdgeInfo getEdgeInfo(DependencyManager<S, ?> dm) {
/* 119 */     int index = dm.getIndex();
/* 120 */     return this.edgeInfos[index];
/*     */   }
/*     */ 
/*     */   
/*     */   ServiceRegistration<S> getServiceRegistration() {
/* 125 */     return this.m_serviceRegistration;
/*     */   }
/*     */ 
/*     */   
/*     */   protected SingleComponentManager<S> getComponentManager() {
/* 130 */     return this.m_componentManager;
/*     */   }
/*     */ 
/*     */   
/*     */   public ComponentMetadata getComponentMetadata() {
/* 135 */     return this.m_componentManager.getComponentMetadata();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final Dictionary<String, Object> getProperties() {
/* 142 */     return (Dictionary<String, Object>)new ReadOnlyDictionary(this.m_componentManager.getProperties());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<String, Object> getPropertiesMap() {
/* 149 */     return (Map<String, Object>)getProperties();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object locateService(String name) {
/* 156 */     this.m_componentManager.obtainActivationReadLock();
/*     */     
/*     */     try {
/* 159 */       DependencyManager<S, ?> dm = this.m_componentManager.getDependencyManager(name);
/* 160 */       return (dm != null) ? (T)dm.getService(this) : null;
/*     */     }
/*     */     finally {
/*     */       
/* 164 */       this.m_componentManager.releaseActivationReadLock();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object locateService(String name, ServiceReference<?> ref) {
/* 173 */     this.m_componentManager.obtainActivationReadLock();
/*     */     
/*     */     try {
/* 176 */       DependencyManager<S, ?> dm = this.m_componentManager.getDependencyManager(name);
/* 177 */       return (dm != null) ? (T)dm.getService(this, ref) : null;
/*     */     }
/*     */     finally {
/*     */       
/* 181 */       this.m_componentManager.releaseActivationReadLock();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object[] locateServices(String name) {
/* 189 */     this.m_componentManager.obtainActivationReadLock();
/*     */     
/*     */     try {
/* 192 */       DependencyManager<S, ?> dm = this.m_componentManager.getDependencyManager(name);
/* 193 */       return (dm != null) ? dm.getServices(this) : null;
/*     */     }
/*     */     finally {
/*     */       
/* 197 */       this.m_componentManager.releaseActivationReadLock();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BundleContext getBundleContext() {
/* 205 */     return this.m_componentManager.getBundleContext();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Bundle getUsingBundle() {
/* 212 */     return this.m_usingBundle;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ComponentLogger getLogger() {
/* 218 */     return this.m_componentManager.getLogger();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ComponentInstance<S> getComponentInstance() {
/* 225 */     return this.m_componentInstance;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void enableComponent(String name) {
/* 232 */     this.m_componentManager.getActivator().enableComponent(name);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void disableComponent(String name) {
/* 239 */     this.m_componentManager.getActivator().disableComponent(name);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ServiceReference<S> getServiceReference() {
/* 246 */     return (this.m_serviceRegistration == null) ? null : this.m_serviceRegistration.getReference();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setServiceProperties(Dictionary<String, ?> properties) {
/* 255 */     getComponentManager().setServiceProperties(properties);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   S getImplementationObject(boolean requireAccessible) {
/* 262 */     if (!requireAccessible || this.m_implementationAccessible)
/*     */     {
/* 264 */       return this.m_implementationObject;
/*     */     }
/*     */     
/*     */     try {
/* 268 */       if (this.accessibleLatch.await(this.m_componentManager.getLockTimeout(), TimeUnit.MILLISECONDS) && this.m_implementationAccessible)
/*     */       {
/* 270 */         return this.m_implementationObject;
/*     */       }
/*     */     }
/* 273 */     catch (InterruptedException e) {
/*     */ 
/*     */       
/*     */       try {
/* 277 */         if (this.accessibleLatch.await(this.m_componentManager.getLockTimeout(), TimeUnit.MILLISECONDS) && this.m_implementationAccessible)
/*     */         {
/* 279 */           return this.m_implementationObject;
/*     */         }
/*     */       }
/* 282 */       catch (InterruptedException e1) {
/*     */         
/* 284 */         this.m_componentManager.getLogger().log(InternalLogger.Level.INFO, "Interrupted twice waiting for implementation object to become accessible", e1);
/*     */       } 
/*     */ 
/*     */       
/* 288 */       Thread.currentThread().interrupt();
/* 289 */       return null;
/*     */     } 
/* 291 */     return null;
/*     */   }
/*     */   
/*     */   private static class ComponentInstanceImpl<S>
/*     */     implements ComponentInstance<S>
/*     */   {
/*     */     private final ComponentContextImpl<S> m_componentContext;
/*     */     
/*     */     private ComponentInstanceImpl(ComponentContextImpl<S> m_componentContext) {
/* 300 */       this.m_componentContext = m_componentContext;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public S getInstance() {
/* 307 */       return this.m_componentContext.getImplementationObject(true);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void dispose() {
/* 314 */       this.m_componentContext.getComponentManager().dispose();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized Map<RefPair<?, ?>, Object> getBoundValues(String key) {
/* 322 */     if (this.boundValues == null)
/*     */     {
/* 324 */       this.boundValues = new HashMap<>();
/*     */     }
/* 326 */     Map<RefPair<?, ?>, Object> map = this.boundValues.get(key);
/* 327 */     if (map == null) {
/*     */       
/* 329 */       map = createNewFieldHandlerMap();
/* 330 */       this.boundValues.put(key, map);
/*     */     } 
/* 332 */     return map;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Map<RefPair<?, ?>, Object> createNewFieldHandlerMap() {
/* 340 */     return new ConcurrentSkipListMap<>(Comparator.comparing(RefPair::getRef));
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.apache.felix.scr-2.2.6.jar!\org\apache\felix\scr\impl\manager\ComponentContextImpl.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */