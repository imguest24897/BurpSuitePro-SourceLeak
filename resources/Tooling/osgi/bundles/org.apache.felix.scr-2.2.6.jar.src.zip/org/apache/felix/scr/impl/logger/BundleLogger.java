package org.apache.felix.scr.impl.logger;

import org.osgi.framework.Bundle;

public interface BundleLogger extends InternalLogger {
  ComponentLogger component(Bundle paramBundle, String paramString1, String paramString2);
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.apache.felix.scr-2.2.6.jar!\org\apache\felix\scr\impl\logger\BundleLogger.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */