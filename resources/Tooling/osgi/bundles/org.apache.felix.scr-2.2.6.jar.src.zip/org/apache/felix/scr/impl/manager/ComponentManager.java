package org.apache.felix.scr.impl.manager;

import java.util.List;
import java.util.Map;
import org.osgi.framework.ServiceReference;

public interface ComponentManager<S> {
  public static final int STATE_UNSATISFIED_CONFIGURATION = 1;
  
  public static final int STATE_UNSATISFIED_REFERENCE = 2;
  
  public static final int STATE_SATISFIED = 4;
  
  public static final int STATE_ACTIVE = 8;
  
  public static final int STATE_DISPOSED = 32;
  
  Map<String, Object> getProperties();
  
  long getId();
  
  int getSpecState();
  
  String getFailureReason();
  
  List<? extends ReferenceManager<S, ?>> getReferenceManagers();
  
  ServiceReference<S> getRegisteredServiceReference();
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.apache.felix.scr-2.2.6.jar!\org\apache\felix\scr\impl\manager\ComponentManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */