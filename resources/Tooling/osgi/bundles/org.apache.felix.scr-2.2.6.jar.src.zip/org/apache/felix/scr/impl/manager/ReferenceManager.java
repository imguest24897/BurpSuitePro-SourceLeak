package org.apache.felix.scr.impl.manager;

import java.util.List;
import org.osgi.framework.ServiceReference;

public interface ReferenceManager<S, T> {
  List<ServiceReference<?>> getServiceReferences();
  
  String getName();
  
  String getTarget();
  
  boolean isSatisfied();
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.apache.felix.scr-2.2.6.jar!\org\apache\felix\scr\impl\manager\ReferenceManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */