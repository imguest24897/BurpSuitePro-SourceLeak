/*     */ package org.apache.felix.scr.impl.metadata;
/*     */ 
/*     */ import org.osgi.framework.Bundle;
/*     */ import org.osgi.framework.Version;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TargetedPID
/*     */ {
/*     */   private final String rawPid;
/*     */   private final String servicePid;
/*     */   private final String symbolicName;
/*     */   private final String version;
/*     */   private final String location;
/*     */   private final short bindingLevel;
/*     */   
/*     */   public static String getBundleVersion(Bundle bundle) {
/*  68 */     Version version = bundle.getVersion();
/*  69 */     return version.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public TargetedPID(String rawPid) {
/*  75 */     this.rawPid = rawPid;
/*     */     
/*  77 */     if (rawPid.indexOf('|') < 0) {
/*     */       
/*  79 */       this.servicePid = rawPid;
/*  80 */       this.symbolicName = null;
/*  81 */       this.version = null;
/*  82 */       this.location = null;
/*  83 */       this.bindingLevel = 0;
/*     */     }
/*     */     else {
/*     */       
/*  87 */       int start = 0;
/*  88 */       int end = rawPid.indexOf('|');
/*  89 */       this.servicePid = rawPid.substring(start, end);
/*     */       
/*  91 */       start = end + 1;
/*  92 */       end = rawPid.indexOf('|', start);
/*  93 */       if (end >= 0) {
/*     */         
/*  95 */         this.symbolicName = rawPid.substring(start, end);
/*  96 */         start = end + 1;
/*  97 */         end = rawPid.indexOf('|', start);
/*  98 */         if (end >= 0)
/*     */         {
/* 100 */           this.version = rawPid.substring(start, end);
/* 101 */           this.location = rawPid.substring(end + 1);
/* 102 */           this.bindingLevel = 3;
/*     */         }
/*     */         else
/*     */         {
/* 106 */           this.version = rawPid.substring(start);
/* 107 */           this.location = null;
/* 108 */           this.bindingLevel = 2;
/*     */         }
/*     */       
/*     */       } else {
/*     */         
/* 113 */         this.symbolicName = rawPid.substring(start);
/* 114 */         this.version = null;
/* 115 */         this.location = null;
/* 116 */         this.bindingLevel = 1;
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean matchesTarget(Bundle serviceBundle) {
/* 144 */     if (serviceBundle == null)
/*     */     {
/* 146 */       return false;
/*     */     }
/*     */ 
/*     */     
/* 150 */     if (this.symbolicName == null)
/*     */     {
/* 152 */       return true;
/*     */     }
/*     */ 
/*     */     
/* 156 */     if (!this.symbolicName.equals(serviceBundle.getSymbolicName()))
/*     */     {
/* 158 */       return false;
/*     */     }
/*     */ 
/*     */     
/* 162 */     if (this.version == null)
/*     */     {
/* 164 */       return true;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 169 */     if (!this.version.equals(getBundleVersion(serviceBundle)))
/*     */     {
/* 171 */       return false;
/*     */     }
/*     */ 
/*     */     
/* 175 */     return (this.location == null || this.location.equals(serviceBundle.getLocation()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getRawPid() {
/* 189 */     return this.rawPid;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getServicePid() {
/* 199 */     return this.servicePid;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean bindsStronger(TargetedPID other) {
/* 217 */     return (other == null || this.bindingLevel > other.bindingLevel);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 224 */     return this.rawPid.hashCode();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object obj) {
/* 231 */     if (obj == null)
/*     */     {
/* 233 */       return false;
/*     */     }
/* 235 */     if (obj == this)
/*     */     {
/* 237 */       return true;
/*     */     }
/*     */ 
/*     */     
/* 241 */     if (getClass() == obj.getClass())
/*     */     {
/* 243 */       return this.rawPid.equals(((TargetedPID)obj).rawPid);
/*     */     }
/*     */ 
/*     */     
/* 247 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 254 */     return this.rawPid;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.apache.felix.scr-2.2.6.jar!\org\apache\felix\scr\impl\metadata\TargetedPID.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */