/*     */ package org.apache.felix.scr.impl;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Set;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import java.util.concurrent.ConcurrentMap;
/*     */ import java.util.concurrent.ExecutorService;
/*     */ import java.util.concurrent.Executors;
/*     */ import java.util.concurrent.FutureTask;
/*     */ import org.osgi.framework.Bundle;
/*     */ import org.osgi.framework.BundleActivator;
/*     */ import org.osgi.framework.BundleContext;
/*     */ import org.osgi.framework.BundleEvent;
/*     */ import org.osgi.framework.BundleListener;
/*     */ import org.osgi.framework.SynchronousBundleListener;
/*     */ import org.osgi.framework.startlevel.BundleStartLevel;
/*     */ import org.osgi.util.tracker.BundleTracker;
/*     */ import org.osgi.util.tracker.BundleTrackerCustomizer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractExtender
/*     */   implements BundleActivator, BundleTrackerCustomizer<Bundle>, SynchronousBundleListener
/*     */ {
/*  51 */   private final ConcurrentMap<Bundle, Activator.ScrExtension> extensions = new ConcurrentHashMap<>();
/*  52 */   private final ConcurrentMap<Bundle, FutureTask<Void>> destroying = new ConcurrentHashMap<>();
/*     */   
/*     */   private volatile boolean stopping;
/*     */   private volatile boolean stopped;
/*     */   private BundleContext context;
/*     */   private BundleTracker<Bundle> tracker;
/*     */   
/*     */   public BundleContext getBundleContext() {
/*  60 */     return this.context;
/*     */   }
/*     */   
/*     */   public boolean isStopping() {
/*  64 */     return this.stopping;
/*     */   }
/*     */ 
/*     */   
/*     */   public void start(BundleContext context) throws Exception {
/*  69 */     this.context = context;
/*  70 */     this.context.addBundleListener((BundleListener)this);
/*  71 */     this.tracker = new BundleTracker(this.context, 40, this);
/*  72 */     doStart();
/*     */   }
/*     */ 
/*     */   
/*     */   public void stop(BundleContext context) throws Exception {
/*  77 */     this.stopping = true;
/*  78 */     while (!this.extensions.isEmpty()) {
/*  79 */       Collection<Bundle> toDestroy = chooseBundlesToDestroy(this.extensions.keySet());
/*  80 */       if (toDestroy == null || toDestroy.isEmpty()) {
/*  81 */         toDestroy = new ArrayList<>(this.extensions.keySet());
/*     */       }
/*  83 */       for (Bundle bundle : toDestroy) {
/*  84 */         destroyExtension(bundle);
/*     */       }
/*     */     } 
/*  87 */     doStop();
/*  88 */     this.stopped = true;
/*     */   }
/*     */   
/*     */   protected void doStart() throws Exception {
/*  92 */     startTracking();
/*     */   }
/*     */   
/*     */   protected void doStop() throws Exception {
/*  96 */     stopTracking();
/*     */   }
/*     */   
/*     */   protected void startTracking() {
/* 100 */     this.tracker.open();
/*     */   }
/*     */   
/*     */   protected void stopTracking() {
/* 104 */     this.tracker.close();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected ExecutorService createExecutor() {
/* 113 */     return Executors.newScheduledThreadPool(3);
/*     */   }
/*     */   
/*     */   protected Collection<Bundle> chooseBundlesToDestroy(Set<Bundle> bundles) {
/* 117 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void bundleChanged(BundleEvent event) {
/* 123 */     if (this.stopped) {
/*     */       return;
/*     */     }
/* 126 */     Bundle bundle = event.getBundle();
/* 127 */     if (bundle.getState() != 32 && bundle.getState() != 8)
/*     */     {
/*     */ 
/*     */       
/* 131 */       if (bundle != this.context.getBundle()) {
/* 132 */         destroyExtension(bundle);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public Bundle addingBundle(Bundle bundle, BundleEvent event) {
/* 139 */     modifiedBundle(bundle, event, bundle);
/* 140 */     return bundle;
/*     */   }
/*     */ 
/*     */   
/*     */   public void modifiedBundle(Bundle bundle, BundleEvent event, Bundle object) {
/* 145 */     if (bundle.getState() != 32 && bundle.getState() != 8) {
/*     */ 
/*     */ 
/*     */       
/* 149 */       if (bundle != this.context.getBundle()) {
/* 150 */         destroyExtension(bundle);
/*     */       }
/*     */       
/*     */       return;
/*     */     } 
/* 155 */     if (this.stopping) {
/*     */       return;
/*     */     }
/*     */ 
/*     */     
/* 160 */     if (bundle.getState() == 8) {
/* 161 */       String activationPolicyHeader = (String)bundle.getHeaders("").get("Bundle-ActivationPolicy");
/* 162 */       if (activationPolicyHeader == null || 
/* 163 */         !activationPolicyHeader.startsWith("lazy") || 
/* 164 */         !((BundleStartLevel)bundle.adapt(BundleStartLevel.class)).isActivationPolicyUsed()) {
/*     */         return;
/*     */       }
/*     */     } 
/*     */     
/* 169 */     createExtension(bundle);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void removedBundle(Bundle bundle, BundleEvent event, Bundle object) {
/* 175 */     destroyExtension(bundle);
/*     */   }
/*     */   
/*     */   private void createExtension(Bundle bundle) {
/*     */     try {
/* 180 */       BundleContext bundleContext = bundle.getBundleContext();
/* 181 */       if (bundleContext == null) {
/*     */         return;
/*     */       }
/*     */       
/* 185 */       Activator.ScrExtension extension = doCreateExtension(bundle);
/* 186 */       if (extension == null) {
/*     */         return;
/*     */       }
/*     */       
/* 190 */       synchronized (this.extensions) {
/* 191 */         if (this.extensions.putIfAbsent(bundle, extension) != null) {
/*     */           return;
/*     */         }
/*     */       } 
/* 195 */       debug(bundle, "Starting extension synchronously");
/* 196 */       extension.start();
/* 197 */     } catch (Throwable t) {
/* 198 */       warn(bundle, "Error while creating extension", t);
/*     */     } 
/*     */   }
/*     */   
/*     */   private void destroyExtension(final Bundle bundle) {
/*     */     FutureTask<Void> future;
/* 204 */     synchronized (this.extensions) {
/* 205 */       debug(bundle, "Starting destruction process");
/* 206 */       future = this.destroying.get(bundle);
/* 207 */       if (future == null) {
/* 208 */         final Activator.ScrExtension extension = this.extensions.remove(bundle);
/* 209 */         if (extension != null) {
/* 210 */           debug(bundle, "Scheduling extension destruction");
/* 211 */           future = new FutureTask<>(new Runnable()
/*     */               {
/*     */                 public void run() {
/* 214 */                   AbstractExtender.this.debug(bundle, "Destroying extension");
/*     */                   try {
/* 216 */                     extension.destroy();
/* 217 */                   } catch (Exception e) {
/* 218 */                     AbstractExtender.this.warn(bundle, "Error while destroying extension", e);
/*     */                   } finally {
/* 220 */                     AbstractExtender.this.debug(bundle, "Finished destroying extension");
/* 221 */                     synchronized (AbstractExtender.this.extensions) {
/* 222 */                       AbstractExtender.this.destroying.remove(bundle);
/*     */                     } 
/*     */                   } 
/*     */                 }
/*     */               }null);
/* 227 */           this.destroying.put(bundle, future);
/*     */         } else {
/* 229 */           debug(bundle, "Not an extended bundle or destruction of extension already finished");
/*     */         } 
/*     */       } else {
/* 232 */         debug(bundle, "Destruction already scheduled");
/*     */       } 
/*     */     } 
/* 235 */     if (future != null)
/*     */       try {
/* 237 */         debug(bundle, "Waiting for extension destruction");
/* 238 */         future.run();
/* 239 */         future.get();
/* 240 */       } catch (Throwable t) {
/* 241 */         warn(bundle, "Error while destroying extension", t);
/*     */       }  
/*     */   }
/*     */   
/*     */   protected abstract Activator.ScrExtension doCreateExtension(Bundle paramBundle) throws Exception;
/*     */   
/*     */   protected abstract void debug(Bundle paramBundle, String paramString);
/*     */   
/*     */   protected abstract void warn(Bundle paramBundle, String paramString, Throwable paramThrowable);
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.apache.felix.scr-2.2.6.jar!\org\apache\felix\scr\impl\AbstractExtender.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */