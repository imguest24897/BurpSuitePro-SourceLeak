/*    */ package org.apache.felix.scr.impl;
/*    */ 
/*    */ import org.osgi.framework.Bundle;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class ComponentRegistryKey
/*    */ {
/*    */   private final long bundleId;
/*    */   private final String componentName;
/*    */   
/*    */   ComponentRegistryKey(Bundle bundle, String componentName) {
/* 41 */     this.bundleId = bundle.getBundleId();
/* 42 */     this.componentName = componentName;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public int hashCode() {
/* 48 */     int code = (int)this.bundleId;
/* 49 */     code += 31 * this.componentName.hashCode();
/* 50 */     return code;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean equals(Object obj) {
/* 56 */     if (this == obj)
/*    */     {
/* 58 */       return true;
/*    */     }
/*    */     
/* 61 */     if (obj instanceof ComponentRegistryKey) {
/*    */       
/* 63 */       ComponentRegistryKey other = (ComponentRegistryKey)obj;
/* 64 */       return (this.bundleId == other.bundleId && this.componentName.equals(other.componentName));
/*    */     } 
/*    */     
/* 67 */     return false;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public long getBundleId() {
/* 73 */     return this.bundleId;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public String getComponentName() {
/* 79 */     return this.componentName;
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.apache.felix.scr-2.2.6.jar!\org\apache\felix\scr\impl\ComponentRegistryKey.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */