/*     */ package org.apache.felix.scr.impl.config;
/*     */ 
/*     */ import java.util.Dictionary;
/*     */ import java.util.Hashtable;
/*     */ import org.apache.felix.scr.impl.Activator;
/*     */ import org.apache.felix.scr.impl.ComponentCommands;
/*     */ import org.apache.felix.scr.impl.logger.InternalLogger;
/*     */ import org.apache.felix.scr.impl.manager.ScrConfiguration;
/*     */ import org.osgi.framework.BundleContext;
/*     */ import org.osgi.framework.ServiceRegistration;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ScrConfigurationImpl
/*     */   implements ScrConfiguration
/*     */ {
/*  60 */   private static final String VALUE_TRUE = Boolean.TRUE.toString();
/*     */   
/*     */   private static final String LOG_LEVEL_DEBUG = "debug";
/*     */   
/*     */   private static final String LOG_LEVEL_INFO = "info";
/*     */   
/*     */   private static final String LOG_LEVEL_WARN = "warn";
/*     */   
/*     */   private static final String LOG_LEVEL_ERROR = "error";
/*     */   
/*     */   private static final String PROP_SHOWTRACE = "ds.showtrace";
/*     */   
/*     */   private static final String PROP_SHOWERRORS = "ds.showerrors";
/*     */   
/*     */   private final Activator activator;
/*     */   
/*     */   private InternalLogger.Level logLevel;
/*     */   
/*     */   private boolean factoryEnabled;
/*     */   
/*     */   private boolean keepInstances;
/*     */   
/*     */   private boolean infoAsService;
/*     */   
/*     */   private boolean cacheMetadata;
/*     */   
/*     */   private boolean isLogEnabled;
/*     */   
/*     */   private boolean isLogExtensionEnabled;
/*     */   
/*  90 */   private long lockTimeout = 5000L;
/*     */   
/*  92 */   private long stopTimeout = 60000L;
/*     */   
/*  94 */   private long serviceChangecountTimeout = 5000L;
/*     */   
/*     */   private Boolean globalExtender;
/*     */   
/*     */   private volatile BundleContext bundleContext;
/*     */   
/*     */   private volatile ServiceRegistration<?> managedServiceRef;
/*     */   
/*     */   private volatile ServiceRegistration<?> metatypeProviderRef;
/*     */   
/*     */   private ComponentCommands scrCommand;
/*     */ 
/*     */   
/*     */   public ScrConfigurationImpl(Activator activator) {
/* 108 */     this.activator = activator;
/*     */   }
/*     */ 
/*     */   
/*     */   public void start(BundleContext bundleContext) {
/* 113 */     this.bundleContext = bundleContext;
/*     */ 
/*     */     
/* 116 */     Dictionary<String, Object> msProps = new Hashtable<>();
/* 117 */     msProps.put("service.pid", "org.apache.felix.scr.ScrService");
/* 118 */     msProps.put("service.description", "SCR Configurator");
/* 119 */     msProps.put("service.vendor", "The Apache Software Foundation");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 126 */     configure(null, true);
/*     */     
/* 128 */     this.managedServiceRef = bundleContext.registerService("org.osgi.service.cm.ManagedService", new ScrManagedServiceServiceFactory(this), msProps);
/*     */ 
/*     */     
/* 131 */     Dictionary<String, Object> mtProps = new Hashtable<>();
/* 132 */     mtProps.put("metatype.pid", "org.apache.felix.scr.ScrService");
/* 133 */     mtProps.put("service.description", "SCR Configurator MetaTypeProvider");
/* 134 */     mtProps.put("service.vendor", "The Apache Software Foundation");
/*     */     
/* 136 */     this.metatypeProviderRef = bundleContext.registerService("org.osgi.service.metatype.MetaTypeProvider", new ScrMetaTypeProviderServiceFactory(this), mtProps);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void stop() {
/* 142 */     if (this.managedServiceRef != null) {
/*     */       
/* 144 */       this.managedServiceRef.unregister();
/* 145 */       this.managedServiceRef = null;
/*     */     } 
/*     */     
/* 148 */     if (this.metatypeProviderRef != null) {
/*     */       
/* 150 */       this.metatypeProviderRef.unregister();
/* 151 */       this.metatypeProviderRef = null;
/*     */     } 
/*     */     
/* 154 */     this.bundleContext = null;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setScrCommand(ComponentCommands scrCommand) {
/* 159 */     this.scrCommand = scrCommand;
/* 160 */     scrCommand.updateProvideScrInfoService(infoAsService());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void configure(Dictionary<String, ?> config, boolean initialStart) {
/*     */     Boolean newGlobalExtender, oldGlobalExtender;
/* 168 */     synchronized (this) {
/*     */       
/* 170 */       if (config == null) {
/*     */         
/* 172 */         if (initialStart) {
/*     */           
/* 174 */           if (this.bundleContext == null)
/*     */           {
/* 176 */             this.logLevel = InternalLogger.Level.ERROR;
/* 177 */             this.factoryEnabled = false;
/* 178 */             this.keepInstances = false;
/* 179 */             this.infoAsService = false;
/* 180 */             this.lockTimeout = 5000L;
/* 181 */             this.stopTimeout = 60000L;
/* 182 */             this.serviceChangecountTimeout = 5000L;
/* 183 */             newGlobalExtender = Boolean.valueOf(false);
/* 184 */             this.cacheMetadata = false;
/* 185 */             this.isLogEnabled = true;
/* 186 */             this.isLogExtensionEnabled = false;
/*     */           }
/*     */           else
/*     */           {
/* 190 */             this.logLevel = getDefaultLogLevel();
/* 191 */             this.factoryEnabled = getDefaultFactoryEnabled();
/* 192 */             this.keepInstances = getDefaultKeepInstances();
/* 193 */             this.infoAsService = getDefaultInfoAsService();
/* 194 */             this.lockTimeout = getDefaultLockTimeout();
/* 195 */             this.stopTimeout = getDefaultStopTimeout();
/* 196 */             this.serviceChangecountTimeout = getServiceChangecountTimeout();
/* 197 */             newGlobalExtender = Boolean.valueOf(getDefaultGlobalExtender());
/* 198 */             this.cacheMetadata = getDefaultCacheMetadata();
/* 199 */             this.isLogEnabled = getDefaultLogEnabled();
/* 200 */             this.isLogExtensionEnabled = getDefaultLogExtension();
/*     */           }
/*     */         
/*     */         } else {
/*     */           
/* 205 */           newGlobalExtender = this.globalExtender;
/*     */         }
/*     */       
/*     */       } else {
/*     */         
/* 210 */         this.logLevel = getLogLevel(config.get("ds.loglevel"));
/* 211 */         this.factoryEnabled = VALUE_TRUE.equalsIgnoreCase(String.valueOf(config.get("ds.factory.enabled")));
/* 212 */         this.keepInstances = VALUE_TRUE.equalsIgnoreCase(String.valueOf(config.get("ds.delayed.keepInstances")));
/* 213 */         this.infoAsService = VALUE_TRUE.equalsIgnoreCase(String.valueOf(config.get("ds.info.service")));
/* 214 */         Long timeout = (Long)config.get("ds.lock.timeout.milliseconds");
/* 215 */         this.lockTimeout = (timeout == null) ? 5000L : timeout.longValue();
/* 216 */         timeout = (Long)config.get("ds.stop.timeout.milliseconds");
/* 217 */         this.stopTimeout = (timeout == null) ? 60000L : timeout.longValue();
/* 218 */         newGlobalExtender = Boolean.valueOf(VALUE_TRUE.equalsIgnoreCase(String.valueOf(config.get("ds.global.extender"))));
/* 219 */         this.cacheMetadata = VALUE_TRUE.equalsIgnoreCase(
/* 220 */             String.valueOf(config.get("ds.cache.metadata")));
/* 221 */         this.isLogEnabled = checkIfLogEnabled(config);
/* 222 */         this.isLogExtensionEnabled = VALUE_TRUE.equalsIgnoreCase(String.valueOf(config.get("ds.log.extension")));
/*     */       } 
/* 224 */       if (this.scrCommand != null)
/*     */       {
/* 226 */         this.scrCommand.updateProvideScrInfoService(infoAsService());
/*     */       }
/* 228 */       oldGlobalExtender = this.globalExtender;
/* 229 */       this.globalExtender = newGlobalExtender;
/*     */     } 
/* 231 */     this.activator.setLogger();
/* 232 */     if (newGlobalExtender != oldGlobalExtender)
/*     */     {
/* 234 */       this.activator.restart(newGlobalExtender.booleanValue(), initialStart);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public InternalLogger.Level getLogLevel() {
/* 246 */     return this.logLevel;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isFactoryEnabled() {
/* 253 */     return this.factoryEnabled;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean keepInstances() {
/* 260 */     return this.keepInstances;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean infoAsService() {
/* 266 */     return this.infoAsService;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public long lockTimeout() {
/* 272 */     return this.lockTimeout;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public long stopTimeout() {
/* 278 */     return this.stopTimeout;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean globalExtender() {
/* 284 */     return this.globalExtender.booleanValue();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean cacheMetadata() {
/* 290 */     return this.cacheMetadata;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public long serviceChangecountTimeout() {
/* 296 */     return this.serviceChangecountTimeout;
/*     */   }
/*     */ 
/*     */   
/*     */   private boolean getDefaultFactoryEnabled() {
/* 301 */     return VALUE_TRUE.equals(this.bundleContext.getProperty("ds.factory.enabled"));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean getDefaultKeepInstances() {
/* 307 */     return VALUE_TRUE.equals(this.bundleContext.getProperty("ds.delayed.keepInstances"));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private InternalLogger.Level getDefaultLogLevel() {
/* 313 */     return getLogLevel(this.bundleContext.getProperty("ds.loglevel"));
/*     */   }
/*     */ 
/*     */   
/*     */   private boolean getDefaultInfoAsService() {
/* 318 */     return VALUE_TRUE.equalsIgnoreCase(this.bundleContext.getProperty("ds.info.service"));
/*     */   }
/*     */ 
/*     */   
/*     */   private long getDefaultLockTimeout() {
/* 323 */     String val = this.bundleContext.getProperty("ds.lock.timeout.milliseconds");
/* 324 */     if (val == null)
/*     */     {
/* 326 */       return 5000L;
/*     */     }
/* 328 */     return Long.parseLong(val);
/*     */   }
/*     */ 
/*     */   
/*     */   private long getDefaultStopTimeout() {
/* 333 */     String val = this.bundleContext.getProperty("ds.stop.timeout.milliseconds");
/* 334 */     if (val == null)
/*     */     {
/* 336 */       return 60000L;
/*     */     }
/* 338 */     return Long.parseLong(val);
/*     */   }
/*     */ 
/*     */   
/*     */   private long getServiceChangecountTimeout() {
/* 343 */     String val = this.bundleContext.getProperty("ds.service.changecount.timeout");
/* 344 */     if (val == null)
/*     */     {
/* 346 */       return 5000L;
/*     */     }
/* 348 */     return Long.parseLong(val);
/*     */   }
/*     */ 
/*     */   
/*     */   private boolean getDefaultGlobalExtender() {
/* 353 */     return VALUE_TRUE.equalsIgnoreCase(this.bundleContext.getProperty("ds.global.extender"));
/*     */   }
/*     */ 
/*     */   
/*     */   private boolean getDefaultCacheMetadata() {
/* 358 */     return VALUE_TRUE.equalsIgnoreCase(this.bundleContext
/* 359 */         .getProperty("ds.cache.metadata"));
/*     */   }
/*     */ 
/*     */   
/*     */   private InternalLogger.Level getLogLevel(Object levelObject) {
/* 364 */     if (levelObject != null) {
/*     */       
/* 366 */       if (levelObject instanceof Number) {
/*     */         
/* 368 */         int ordinal = ((Number)levelObject).intValue();
/* 369 */         return InternalLogger.Level.values()[ordinal];
/*     */       } 
/*     */       
/* 372 */       String levelString = levelObject.toString();
/*     */       
/*     */       try {
/* 375 */         int ordinal = Integer.parseInt(levelString);
/* 376 */         return InternalLogger.Level.values()[ordinal];
/*     */       }
/* 378 */       catch (NumberFormatException numberFormatException) {
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 383 */         if ("debug".equalsIgnoreCase(levelString))
/*     */         {
/* 385 */           return InternalLogger.Level.DEBUG;
/*     */         }
/* 387 */         if ("info".equalsIgnoreCase(levelString))
/*     */         {
/* 389 */           return InternalLogger.Level.INFO;
/*     */         }
/* 391 */         if ("warn".equalsIgnoreCase(levelString))
/*     */         {
/* 393 */           return InternalLogger.Level.WARN;
/*     */         }
/* 395 */         if ("error".equalsIgnoreCase(levelString))
/*     */         {
/* 397 */           return InternalLogger.Level.ERROR;
/*     */         }
/*     */       } 
/*     */     } 
/*     */     
/* 402 */     if (VALUE_TRUE.equalsIgnoreCase(this.bundleContext.getProperty("ds.showtrace")))
/*     */     {
/* 404 */       return InternalLogger.Level.DEBUG;
/*     */     }
/*     */ 
/*     */     
/* 408 */     if ("false".equalsIgnoreCase(this.bundleContext.getProperty("ds.showerrors")))
/*     */     {
/* 410 */       return InternalLogger.Level.AUDIT;
/*     */     }
/*     */ 
/*     */     
/* 414 */     return InternalLogger.Level.ERROR;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isLogEnabled() {
/* 420 */     return this.isLogEnabled;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isLogExtensionEnabled() {
/* 426 */     return this.isLogExtensionEnabled;
/*     */   }
/*     */ 
/*     */   
/*     */   private boolean getDefaultLogExtension() {
/* 431 */     return VALUE_TRUE.equalsIgnoreCase(this.bundleContext.getProperty("ds.log.extension"));
/*     */   }
/*     */ 
/*     */   
/*     */   private boolean getDefaultLogEnabled() {
/* 436 */     String isLogEnabled = this.bundleContext.getProperty("ds.log.enabled");
/* 437 */     return (isLogEnabled == null) ? true : VALUE_TRUE.equalsIgnoreCase(isLogEnabled);
/*     */   }
/*     */ 
/*     */   
/*     */   private boolean checkIfLogEnabled(Dictionary<String, ?> properties) {
/* 442 */     Object isLogEnabled = properties.get("ds.log.enabled");
/* 443 */     if (isLogEnabled == null)
/*     */     {
/* 445 */       return true;
/*     */     }
/* 447 */     return (isLogEnabled == null) ? true : Boolean.parseBoolean(isLogEnabled.toString());
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.apache.felix.scr-2.2.6.jar!\org\apache\felix\scr\impl\config\ScrConfigurationImpl.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */