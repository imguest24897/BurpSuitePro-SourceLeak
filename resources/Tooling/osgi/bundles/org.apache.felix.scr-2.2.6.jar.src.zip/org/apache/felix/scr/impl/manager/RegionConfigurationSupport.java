/*     */ package org.apache.felix.scr.impl.manager;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.security.AccessController;
/*     */ import java.security.PrivilegedAction;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.Dictionary;
/*     */ import java.util.HashMap;
/*     */ import java.util.Hashtable;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.concurrent.atomic.AtomicInteger;
/*     */ import org.apache.felix.scr.impl.logger.InternalLogger;
/*     */ import org.apache.felix.scr.impl.logger.ScrLogger;
/*     */ import org.apache.felix.scr.impl.metadata.TargetedPID;
/*     */ import org.osgi.framework.Bundle;
/*     */ import org.osgi.framework.BundleContext;
/*     */ import org.osgi.framework.InvalidSyntaxException;
/*     */ import org.osgi.framework.ServiceReference;
/*     */ import org.osgi.framework.ServiceRegistration;
/*     */ import org.osgi.service.cm.Configuration;
/*     */ import org.osgi.service.cm.ConfigurationAdmin;
/*     */ import org.osgi.service.cm.ConfigurationEvent;
/*     */ import org.osgi.service.cm.ConfigurationException;
/*     */ import org.osgi.service.cm.ConfigurationListener;
/*     */ import org.osgi.service.cm.ConfigurationPermission;
/*     */ import org.osgi.service.cm.ManagedService;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class RegionConfigurationSupport
/*     */ {
/*     */   private final ScrLogger logger;
/*     */   private final ServiceReference<ConfigurationAdmin> caReference;
/*     */   private final BundleContext caBundleContext;
/*     */   private final Long bundleId;
/*  59 */   private final AtomicInteger referenceCount = new AtomicInteger(1);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private volatile ServiceRegistration<ConfigurationListener> m_registration;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RegionConfigurationSupport(ScrLogger logger, ServiceReference<ConfigurationAdmin> reference, Bundle bundle) {
/*  71 */     this.logger = logger;
/*  72 */     this.caReference = reference;
/*  73 */     this.bundleId = Long.valueOf(bundle.getBundleId());
/*  74 */     this.caBundleContext = bundle.getBundleContext();
/*     */   }
/*     */ 
/*     */   
/*     */   public void start() {
/*     */     ConfigurationListener serviceDelegator;
/*  80 */     Dictionary<String, Object> props = new Hashtable<>();
/*  81 */     props.put("service.description", "Declarative Services Configuration Support Listener");
/*  82 */     props.put("service.vendor", "The Apache Software Foundation");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  88 */     if (System.getSecurityManager() != null) {
/*  89 */       serviceDelegator = new ConfigurationListener()
/*     */         {
/*     */           
/*     */           public void configurationEvent(final ConfigurationEvent event)
/*     */           {
/*  94 */             AccessController.doPrivileged(new PrivilegedAction()
/*     */                 {
/*     */ 
/*     */                   
/*     */                   public Void run()
/*     */                   {
/* 100 */                     RegionConfigurationSupport.this.configurationEvent(event);
/* 101 */                     return null;
/*     */                   }
/*     */                 });
/*     */           }
/*     */         };
/*     */     }
/*     */     else {
/*     */       
/* 109 */       serviceDelegator = new ConfigurationListener()
/*     */         {
/*     */ 
/*     */           
/*     */           public void configurationEvent(ConfigurationEvent event)
/*     */           {
/* 115 */             RegionConfigurationSupport.this.configurationEvent(event);
/*     */           }
/*     */         };
/*     */     } 
/* 119 */     this.m_registration = this.caBundleContext.registerService(ConfigurationListener.class, serviceDelegator, props);
/*     */   }
/*     */ 
/*     */   
/*     */   public Long getBundleId() {
/* 124 */     return this.bundleId;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean reference() {
/* 129 */     if (this.referenceCount.get() == 0)
/*     */     {
/* 131 */       return false;
/*     */     }
/* 133 */     this.referenceCount.incrementAndGet();
/* 134 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean dereference() {
/* 139 */     if (this.referenceCount.decrementAndGet() == 0) {
/*     */ 
/*     */       
/*     */       try {
/* 143 */         this.m_registration.unregister();
/*     */       }
/* 145 */       catch (IllegalStateException illegalStateException) {}
/*     */ 
/*     */ 
/*     */       
/* 149 */       this.m_registration = null;
/* 150 */       return true;
/*     */     } 
/* 152 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean configureComponentHolder(ComponentHolder<?> holder) {
/* 163 */     if (!holder.getComponentMetadata().isConfigurationIgnored()) {
/*     */       
/* 165 */       BundleContext bundleContext = holder.getActivator().getBundleContext();
/* 166 */       if (bundleContext == null)
/*     */       {
/* 168 */         return false;
/*     */       }
/* 170 */       List<String> confPids = holder.getComponentMetadata().getConfigurationPid();
/*     */       
/* 172 */       ConfigurationAdmin ca = getConfigAdmin(bundleContext);
/* 173 */       if (ca == null)
/*     */       {
/* 175 */         return false;
/*     */       }
/*     */       
/*     */       try {
/* 179 */         for (String confPid : confPids) {
/*     */           
/* 181 */           Collection<Configuration> factory = findFactoryConfigurations(ca, confPid, bundleContext
/* 182 */               .getBundle());
/* 183 */           if (!factory.isEmpty()) {
/*     */             
/* 185 */             boolean created = false;
/* 186 */             for (Configuration config : factory) {
/*     */ 
/*     */               
/*     */               try {
/* 190 */                 this.logger.log(InternalLogger.Level.DEBUG, "Configuring holder {0} with change count {1}", null, new Object[] { holder, 
/*     */                       
/* 192 */                       Long.valueOf(config.getChangeCount()) });
/* 193 */                 if (checkBundleLocation(config, bundleContext
/* 194 */                     .getBundle()))
/*     */                 {
/* 196 */                   long changeCount = config.getChangeCount();
/* 197 */                   ServiceReference<ManagedService> ref = getManagedServiceReference(bundleContext);
/*     */                   
/* 199 */                   created |= holder.configurationUpdated(new TargetedPID(config
/* 200 */                         .getPid()), new TargetedPID(config
/* 201 */                         .getFactoryPid()), config
/* 202 */                       .getProcessedProperties(ref), changeCount);
/*     */                 }
/*     */               
/* 205 */               } catch (IllegalStateException e) {}
/*     */             } 
/*     */ 
/*     */ 
/*     */ 
/*     */             
/* 211 */             if (!created)
/*     */             {
/* 213 */               return false;
/*     */             }
/*     */             
/*     */             continue;
/*     */           } 
/*     */           
/* 219 */           Configuration singleton = findSingletonConfiguration(ca, confPid, bundleContext.getBundle());
/* 220 */           if (singleton != null) {
/*     */             
/*     */             try {
/*     */               
/* 224 */               this.logger.log(InternalLogger.Level.DEBUG, "Configuring holder {0} with change count {1}", null, new Object[] { holder, 
/*     */                     
/* 226 */                     Long.valueOf(singleton.getChangeCount()) });
/* 227 */               if (singleton != null && checkBundleLocation(singleton, bundleContext
/* 228 */                   .getBundle())) {
/*     */                 
/* 230 */                 long changeCount = singleton.getChangeCount();
/* 231 */                 ServiceReference<ManagedService> ref = getManagedServiceReference(bundleContext);
/*     */                 
/* 233 */                 holder.configurationUpdated(new TargetedPID(singleton
/* 234 */                       .getPid()), null, singleton
/* 235 */                     .getProcessedProperties(ref), changeCount);
/*     */                 
/*     */                 continue;
/*     */               } 
/*     */               
/* 240 */               return false;
/*     */             
/*     */             }
/* 243 */             catch (IllegalStateException e) {
/*     */               
/* 245 */               return false;
/*     */             } 
/*     */           }
/*     */ 
/*     */           
/* 250 */           return false;
/*     */         } 
/*     */ 
/*     */         
/* 254 */         return !confPids.isEmpty();
/*     */       } finally {
/*     */ 
/*     */         
/*     */         try {
/*     */           
/* 260 */           bundleContext.ungetService(this.caReference);
/*     */         }
/* 262 */         catch (IllegalStateException illegalStateException) {}
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 268 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void configurationEvent(ConfigurationEvent event) {
/* 289 */     TargetedPID pid = new TargetedPID(event.getPid());
/* 290 */     String rawFactoryPid = event.getFactoryPid();
/* 291 */     TargetedPID factoryPid = (rawFactoryPid == null) ? null : new TargetedPID(rawFactoryPid);
/*     */ 
/*     */ 
/*     */     
/* 295 */     Collection<ComponentHolder<?>> holders = getComponentHolders((factoryPid != null) ? factoryPid : pid);
/*     */     
/* 297 */     this.logger.log(InternalLogger.Level.DEBUG, "configurationEvent: Handling {0} of Configuration PID={1} for component holders {2}", null, new Object[] {
/*     */           
/* 299 */           getEventType(event), pid, holders
/*     */         });
/* 301 */     for (ComponentHolder<?> componentHolder : holders) {
/*     */       
/* 303 */       if (!componentHolder.getComponentMetadata().isConfigurationIgnored()) {
/*     */         ComponentActivator activator; BundleContext bundleContext; TargetedPID targetedPid, oldTargetedPID; boolean better;
/* 305 */         switch (event.getType()) {
/*     */           
/*     */           case 2:
/* 308 */             if (factoryPid != null || !configureComponentHolder(componentHolder))
/*     */             {
/* 310 */               componentHolder.configurationDeleted(pid, factoryPid);
/*     */             }
/*     */             continue;
/*     */ 
/*     */           
/*     */           case 1:
/* 316 */             activator = componentHolder.getActivator();
/* 317 */             if (activator == null) {
/*     */               continue;
/*     */             }
/*     */ 
/*     */             
/* 322 */             bundleContext = activator.getBundleContext();
/* 323 */             if (bundleContext == null) {
/*     */               continue;
/*     */             }
/*     */ 
/*     */             
/* 328 */             targetedPid = (factoryPid == null) ? pid : factoryPid;
/* 329 */             oldTargetedPID = componentHolder.getConfigurationTargetedPID(pid, factoryPid);
/* 330 */             if (factoryPid != null || targetedPid.equals(oldTargetedPID) || targetedPid
/* 331 */               .bindsStronger(oldTargetedPID)) {
/*     */               
/* 333 */               ConfigurationInfo configInfo = getConfigurationInfo(pid, targetedPid, componentHolder, bundleContext);
/*     */               
/* 335 */               if (configInfo != null)
/*     */               {
/* 337 */                 if (checkBundleLocation(configInfo.getBundleLocation(), bundleContext.getBundle()))
/*     */                 {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */                   
/* 347 */                   componentHolder.configurationUpdated(pid, factoryPid, configInfo.getProps(), configInfo
/* 348 */                       .getChangeCount());
/*     */                 }
/*     */               }
/*     */             } 
/*     */             continue;
/*     */ 
/*     */ 
/*     */ 
/*     */           
/*     */           case 3:
/* 358 */             activator = componentHolder.getActivator();
/* 359 */             if (activator == null) {
/*     */               continue;
/*     */             }
/*     */ 
/*     */             
/* 364 */             bundleContext = activator.getBundleContext();
/* 365 */             if (bundleContext == null) {
/*     */               continue;
/*     */             }
/*     */ 
/*     */             
/* 370 */             targetedPid = (factoryPid == null) ? pid : factoryPid;
/* 371 */             oldTargetedPID = componentHolder.getConfigurationTargetedPID(pid, factoryPid);
/* 372 */             if (targetedPid.equals(oldTargetedPID)) {
/*     */ 
/*     */ 
/*     */               
/* 376 */               ConfigurationInfo configInfo = getConfigurationInfo(pid, targetedPid, componentHolder, bundleContext);
/*     */               
/* 378 */               if (configInfo != null) {
/*     */                 
/* 380 */                 this.logger.log(InternalLogger.Level.DEBUG, "LocationChanged event, same targetedPID {0}, location now {1}, change count {2}", null, new Object[] { targetedPid, configInfo
/*     */                       
/* 382 */                       .getBundleLocation(), 
/* 383 */                       Long.valueOf(configInfo.getChangeCount()) });
/* 384 */                 if (configInfo.getProps() == null)
/*     */                 {
/* 386 */                   throw new IllegalStateException("Existing Configuration with pid " + pid + " has had its properties set to null and location changed.  We expected a delete event first.");
/*     */                 }
/*     */ 
/*     */                 
/* 390 */                 if (!checkBundleLocation(configInfo.getBundleLocation(), bundleContext.getBundle())) {
/*     */ 
/*     */                   
/* 393 */                   componentHolder.configurationDeleted(pid, factoryPid);
/*     */                   
/* 395 */                   configureComponentHolder(componentHolder);
/*     */                 } 
/*     */               } 
/*     */               
/*     */               continue;
/*     */             } 
/*     */             
/* 402 */             better = targetedPid.bindsStronger(oldTargetedPID);
/* 403 */             if (better) {
/*     */ 
/*     */ 
/*     */               
/* 407 */               ConfigurationInfo configInfo = getConfigurationInfo(pid, targetedPid, componentHolder, bundleContext);
/*     */               
/* 409 */               if (configInfo != null) {
/*     */                 
/* 411 */                 this.logger.log(InternalLogger.Level.DEBUG, "LocationChanged event, better targetedPID {0} compared to {1}, location now {2}, change count {3}", null, new Object[] { targetedPid, oldTargetedPID, configInfo
/*     */                       
/* 413 */                       .getBundleLocation(), 
/* 414 */                       Long.valueOf(configInfo.getChangeCount()) });
/* 415 */                 if (configInfo.getProps() == null) {
/*     */                   continue;
/*     */                 }
/*     */ 
/*     */ 
/*     */                 
/* 421 */                 if (checkBundleLocation(configInfo.getBundleLocation(), bundleContext.getBundle())) {
/*     */                   
/* 423 */                   if (oldTargetedPID != null)
/*     */                   {
/*     */                     
/* 426 */                     componentHolder.configurationDeleted(pid, factoryPid);
/*     */                   }
/* 428 */                   componentHolder.configurationUpdated(pid, factoryPid, configInfo.getProps(), configInfo
/* 429 */                       .getChangeCount());
/*     */                 } 
/*     */               } 
/*     */               
/*     */               continue;
/*     */             } 
/*     */             
/* 436 */             this.logger.log(InternalLogger.Level.DEBUG, "LocationChanged event, worse targetedPID {0} compared to {1}, do nothing", null, new Object[] { targetedPid, oldTargetedPID });
/*     */             continue;
/*     */         } 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 443 */         this.logger.log(InternalLogger.Level.WARN, "Unknown ConfigurationEvent type {0}", null, new Object[] {
/*     */               
/* 445 */               Integer.valueOf(event.getType())
/*     */             });
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   protected abstract Collection<ComponentHolder<?>> getComponentHolders(TargetedPID paramTargetedPID);
/*     */   
/*     */   private String getEventType(ConfigurationEvent event) {
/* 455 */     switch (event.getType()) {
/*     */       
/*     */       case 1:
/* 458 */         return "UPDATED";
/*     */       case 2:
/* 460 */         return "DELETED";
/*     */       case 3:
/* 462 */         return "LOCATION CHANGED";
/*     */     } 
/* 464 */     return "Unkown event type: " + event.getType();
/*     */   }
/*     */ 
/*     */   
/*     */   private static class ConfigurationInfo
/*     */   {
/*     */     private final Dictionary<String, Object> props;
/*     */     
/*     */     private final String bundleLocation;
/*     */     
/*     */     private final long changeCount;
/*     */     
/*     */     public ConfigurationInfo(Dictionary<String, Object> props, String bundleLocation, long changeCount) {
/* 477 */       this.props = props;
/* 478 */       this.bundleLocation = bundleLocation;
/* 479 */       this.changeCount = changeCount;
/*     */     }
/*     */ 
/*     */     
/*     */     public long getChangeCount() {
/* 484 */       return this.changeCount;
/*     */     }
/*     */ 
/*     */     
/*     */     public Dictionary<String, Object> getProps() {
/* 489 */       return this.props;
/*     */     }
/*     */ 
/*     */     
/*     */     public String getBundleLocation() {
/* 494 */       return this.bundleLocation;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ConfigurationInfo getConfigurationInfo(TargetedPID pid, TargetedPID targetedPid, ComponentHolder<?> componentHolder, BundleContext bundleContext) {
/*     */     try {
/* 515 */       ConfigurationAdmin ca = getConfigAdmin(bundleContext);
/* 516 */       if (ca == null)
/*     */       {
/* 518 */         return null;
/*     */       }
/*     */       
/*     */       try {
/* 522 */         Configuration[] configs = ca.listConfigurations(filter(pid.getRawPid()));
/* 523 */         if (configs != null && configs.length > 0)
/*     */         {
/* 525 */           for (Configuration config : configs)
/*     */           {
/*     */             
/*     */             try {
/* 529 */               ServiceReference<ManagedService> ref = getManagedServiceReference(bundleContext);
/*     */               
/* 531 */               return new ConfigurationInfo(config
/* 532 */                   .getProcessedProperties(ref), config
/* 533 */                   .getBundleLocation(), config.getChangeCount());
/*     */             }
/* 535 */             catch (IllegalStateException e) {}
/*     */           
/*     */           }
/*     */ 
/*     */         
/*     */         }
/*     */       }
/* 542 */       catch (IOException e) {
/*     */         
/* 544 */         this.logger.log(InternalLogger.Level.WARN, "Failed reading configuration for pid={0}", e, new Object[] { pid });
/*     */       
/*     */       }
/* 547 */       catch (InvalidSyntaxException e) {
/*     */         
/* 549 */         this.logger.log(InternalLogger.Level.WARN, "Failed reading configuration for pid={0}", (Throwable)e, new Object[] { pid });
/*     */       
/*     */       }
/*     */       finally {
/*     */         
/* 554 */         bundleContext.ungetService(this.caReference);
/*     */       }
/*     */     
/* 557 */     } catch (IllegalStateException ise) {
/*     */ 
/*     */       
/* 560 */       this.logger.log(InternalLogger.Level.DEBUG, "Bundle in unexpected state", ise);
/*     */     } 
/* 562 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   private ServiceReference<ManagedService> getManagedServiceReference(BundleContext bundleContext) {
/*     */     try {
/* 568 */       Collection<ServiceReference<ManagedService>> refs = bundleContext.getServiceReferences(ManagedService.class, "(&(service.bundleid=" + 
/* 569 */           String.valueOf(bundleContext.getBundle().getBundleId()) + ")(!(service.pid=*)))");
/* 570 */       if (!refs.isEmpty()) {
/* 571 */         return refs.iterator().next();
/*     */       }
/* 573 */     } catch (InvalidSyntaxException invalidSyntaxException) {}
/*     */ 
/*     */     
/* 576 */     return bundleContext.registerService(ManagedService.class, new ManagedService() { public void updated(Dictionary<String, ?> properties) throws ConfigurationException {} }, null)
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 583 */       .getReference();
/*     */   }
/*     */ 
/*     */   
/*     */   private String filter(String rawPid) {
/* 588 */     return "(service.pid=" + rawPid + ")";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Configuration findSingletonConfiguration(ConfigurationAdmin ca, String pid, Bundle bundle) {
/* 602 */     String filter = getTargetedPidFilter(pid, bundle, "service.pid");
/* 603 */     Configuration[] cfg = findConfigurations(ca, filter);
/* 604 */     if (cfg == null)
/*     */     {
/* 606 */       return null;
/*     */     }
/* 608 */     String longest = null;
/* 609 */     Configuration best = null;
/* 610 */     for (Configuration config : cfg) {
/*     */       
/* 612 */       if (checkBundleLocation(config, bundle)) {
/*     */         
/*     */         try {
/*     */           
/* 616 */           String testPid = config.getPid();
/* 617 */           if (longest == null || testPid.length() > longest.length())
/*     */           {
/* 619 */             longest = testPid;
/* 620 */             best = config;
/*     */           }
/*     */         
/* 623 */         } catch (IllegalStateException e) {}
/*     */       }
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 630 */     return best;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Collection<Configuration> findFactoryConfigurations(ConfigurationAdmin ca, String factoryPid, Bundle bundle) {
/* 645 */     String filter = getTargetedPidFilter(factoryPid, bundle, "service.factoryPid");
/* 646 */     Configuration[] configs = findConfigurations(ca, filter);
/* 647 */     if (configs == null)
/*     */     {
/* 649 */       return Collections.emptyList();
/*     */     }
/* 651 */     Map<String, Configuration> configsByPid = new HashMap<>();
/* 652 */     for (Configuration config : configs) {
/*     */       
/* 654 */       if (checkBundleLocation(config, bundle)) {
/*     */         
/*     */         try {
/*     */           
/* 658 */           Configuration oldConfig = configsByPid.get(config.getPid());
/* 659 */           if (oldConfig == null)
/*     */           {
/* 661 */             configsByPid.put(config.getPid(), config);
/*     */           }
/*     */           else
/*     */           {
/* 665 */             String newPid = config.getFactoryPid();
/* 666 */             String oldPid = oldConfig.getFactoryPid();
/* 667 */             if (newPid.length() > oldPid.length())
/*     */             {
/* 669 */               configsByPid.put(config.getPid(), config);
/*     */             }
/*     */           }
/*     */         
/* 673 */         } catch (IllegalStateException e) {}
/*     */       }
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 680 */     return configsByPid.values();
/*     */   }
/*     */ 
/*     */   
/*     */   private boolean checkBundleLocation(Configuration config, Bundle bundle) {
/* 685 */     if (config == null)
/*     */     {
/* 687 */       return false;
/*     */     }
/*     */     
/* 690 */     String configBundleLocation = null;
/*     */     
/*     */     try {
/* 693 */       configBundleLocation = config.getBundleLocation();
/*     */     }
/* 695 */     catch (IllegalStateException e) {
/*     */       
/* 697 */       return false;
/*     */     } 
/*     */     
/* 700 */     return checkBundleLocation(configBundleLocation, bundle);
/*     */   }
/*     */ 
/*     */   
/*     */   private boolean checkBundleLocation(String configBundleLocation, Bundle bundle) {
/*     */     boolean result;
/* 706 */     if (configBundleLocation == null) {
/*     */       
/* 708 */       result = true;
/*     */     }
/* 710 */     else if (configBundleLocation.startsWith("?")) {
/*     */ 
/*     */       
/* 713 */       if (System.getSecurityManager() != null)
/*     */       {
/* 715 */         result = bundle.hasPermission(new ConfigurationPermission(configBundleLocation, "target"));
/*     */       
/*     */       }
/*     */       else
/*     */       {
/* 720 */         result = true;
/*     */       }
/*     */     
/*     */     } else {
/*     */       
/* 725 */       result = configBundleLocation.equals(bundle.getLocation());
/*     */     } 
/* 727 */     this.logger.log(InternalLogger.Level.DEBUG, "checkBundleLocation: location {0}, returning {1}", null, new Object[] { configBundleLocation, 
/*     */           
/* 729 */           Boolean.valueOf(result) });
/* 730 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private Configuration[] findConfigurations(ConfigurationAdmin ca, String filter) {
/*     */     try {
/* 737 */       return ca.listConfigurations(filter);
/*     */     }
/* 739 */     catch (IOException ioe) {
/*     */       
/* 741 */       this.logger.log(InternalLogger.Level.WARN, "Problem listing configurations for filter={0}", ioe, new Object[] { filter });
/*     */ 
/*     */     
/*     */     }
/* 745 */     catch (InvalidSyntaxException ise) {
/*     */       
/* 747 */       this.logger.log(InternalLogger.Level.ERROR, "Invalid Configuration selection filter {0}", (Throwable)ise, new Object[] { filter });
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 752 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   private String getTargetedPidFilter(String pid, Bundle bundle, String key) {
/* 757 */     String bsn = bundle.getSymbolicName();
/* 758 */     String version = bundle.getVersion().toString();
/* 759 */     String location = escape(bundle.getLocation());
/*     */     
/* 761 */     StringBuilder sb = new StringBuilder();
/*     */     
/* 763 */     sb.append("(|(");
/*     */     
/* 765 */     sb.append(key);
/* 766 */     sb.append('=');
/* 767 */     sb.append(pid);
/*     */     
/* 769 */     sb.append(")(");
/*     */     
/* 771 */     sb.append(key);
/* 772 */     sb.append('=');
/* 773 */     sb.append(pid);
/* 774 */     sb.append('|');
/* 775 */     sb.append(bsn);
/*     */     
/* 777 */     sb.append(")(");
/*     */     
/* 779 */     sb.append(key);
/* 780 */     sb.append('=');
/* 781 */     sb.append(pid);
/* 782 */     sb.append('|');
/* 783 */     sb.append(bsn);
/* 784 */     sb.append('|');
/* 785 */     sb.append(version);
/*     */     
/* 787 */     sb.append(")(");
/*     */     
/* 789 */     sb.append(key);
/* 790 */     sb.append('=');
/* 791 */     sb.append(pid);
/* 792 */     sb.append('|');
/* 793 */     sb.append(bsn);
/* 794 */     sb.append('|');
/* 795 */     sb.append(version);
/* 796 */     sb.append('|');
/* 797 */     sb.append(location);
/*     */     
/* 799 */     sb.append("))");
/*     */     
/* 801 */     return sb.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static final String escape(String value) {
/* 811 */     StringBuilder sb = null;
/*     */     
/* 813 */     int index = 0;
/*     */     
/* 815 */     for (int i = 0; i < value.length(); i++) {
/* 816 */       char c = value.charAt(i);
/*     */       
/* 818 */       switch (c) {
/*     */         case '(':
/*     */         case ')':
/*     */         case '*':
/*     */         case '\\':
/* 823 */           if (sb == null) {
/* 824 */             sb = new StringBuilder();
/*     */           }
/*     */           
/* 827 */           sb.append(value, index, i);
/* 828 */           sb.append('\\');
/* 829 */           sb.append(c);
/*     */           
/* 831 */           index = i + 1;
/*     */           break;
/*     */       } 
/*     */ 
/*     */     
/*     */     } 
/* 837 */     if (sb == null) {
/* 838 */       return value;
/*     */     }
/*     */     
/* 841 */     if (index < value.length()) {
/* 842 */       sb.append(value, index, value.length());
/*     */     }
/*     */     
/* 845 */     return sb.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private ConfigurationAdmin getConfigAdmin(BundleContext bundleContext) {
/*     */     try {
/* 852 */       return (ConfigurationAdmin)bundleContext.getService(this.caReference);
/*     */     }
/* 854 */     catch (IllegalStateException e) {
/*     */       
/* 856 */       return null;
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.apache.felix.scr-2.2.6.jar!\org\apache\felix\scr\impl\manager\RegionConfigurationSupport.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */