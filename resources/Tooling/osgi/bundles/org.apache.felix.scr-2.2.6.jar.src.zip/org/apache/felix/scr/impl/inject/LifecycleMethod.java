package org.apache.felix.scr.impl.inject;

public interface LifecycleMethod {
  MethodResult invoke(Object paramObject, ScrComponentContext paramScrComponentContext, int paramInt, MethodResult paramMethodResult);
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.apache.felix.scr-2.2.6.jar!\org\apache\felix\scr\impl\inject\LifecycleMethod.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */