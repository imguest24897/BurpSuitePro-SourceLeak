/*     */ package org.apache.felix.scr.impl.helper;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.List;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import java.util.concurrent.ConcurrentMap;
/*     */ import org.osgi.framework.BundleContext;
/*     */ import org.osgi.framework.ServiceObjects;
/*     */ import org.osgi.framework.ServiceReference;
/*     */ import org.osgi.service.component.ComponentServiceObjects;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ComponentServiceObjectsHelper
/*     */ {
/*     */   private final BundleContext bundleContext;
/*  40 */   private final ConcurrentMap<ServiceReference<?>, ComponentServiceObjectsImpl<?>> services = new ConcurrentHashMap<>();
/*     */   
/*  42 */   private final List<ComponentServiceObjectsImpl<?>> closedServices = new ArrayList<>();
/*     */   
/*  44 */   private final ConcurrentMap<ServiceReference<?>, Object> prototypeInstances = new ConcurrentHashMap<>();
/*     */ 
/*     */   
/*     */   public ComponentServiceObjectsHelper(BundleContext bundleContext) {
/*  48 */     this.bundleContext = bundleContext;
/*     */   }
/*     */ 
/*     */   
/*     */   public void cleanup() {
/*  53 */     Collection<ComponentServiceObjectsImpl<?>> csos = this.services.values();
/*  54 */     this.services.clear();
/*  55 */     for (ComponentServiceObjectsImpl<?> cso : csos)
/*     */     {
/*  57 */       cso.deactivate();
/*     */     }
/*  59 */     synchronized (this.closedServices) {
/*     */       
/*  61 */       csos = new ArrayList<>(this.closedServices);
/*  62 */       this.closedServices.clear();
/*     */     } 
/*  64 */     for (ComponentServiceObjectsImpl<?> cso : csos)
/*     */     {
/*  66 */       cso.deactivate();
/*     */     }
/*  68 */     this.prototypeInstances.clear();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public <T> ComponentServiceObjects<T> getServiceObjects(ServiceReference<T> ref) {
/*  74 */     ComponentServiceObjectsImpl<T> cso = (ComponentServiceObjectsImpl<T>)this.services.get(ref);
/*     */     
/*  76 */     if (cso == null) {
/*     */       
/*  78 */       ServiceObjects<T> serviceObjects = this.bundleContext.getServiceObjects(ref);
/*     */       
/*  80 */       if (serviceObjects != null) {
/*     */         
/*  82 */         cso = new ComponentServiceObjectsImpl<>(serviceObjects);
/*     */         
/*  84 */         ComponentServiceObjectsImpl<T> oldCSO = (ComponentServiceObjectsImpl<T>)this.services.putIfAbsent(ref, cso);
/*     */         
/*  86 */         if (oldCSO != null)
/*     */         {
/*  88 */           cso = oldCSO;
/*     */         }
/*     */       } 
/*     */     } 
/*  92 */     return cso;
/*     */   }
/*     */   
/*     */   public void closeServiceObjects(ServiceReference<?> ref) {
/*  96 */     ComponentServiceObjectsImpl<?> cso = this.services.remove(ref);
/*  97 */     if (cso != null) {
/*     */       
/*  99 */       synchronized (this.closedServices) {
/*     */         
/* 101 */         this.closedServices.add(cso);
/*     */       } 
/* 103 */       cso.close();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public <T> T getPrototypeRefInstance(ServiceReference<T> ref) {
/* 110 */     T service = (T)this.prototypeInstances.get(ref);
/* 111 */     if (service == null) {
/*     */       
/* 113 */       service = (T)getServiceObjects(ref).getService();
/*     */       
/* 115 */       T oldService = (T)this.prototypeInstances.putIfAbsent(ref, service);
/* 116 */       if (oldService != null) {
/*     */ 
/*     */         
/* 119 */         getServiceObjects(ref).ungetService(service);
/* 120 */         service = oldService;
/*     */       } 
/*     */     } 
/* 123 */     return service;
/*     */   }
/*     */   
/*     */   private static final class ComponentServiceObjectsImpl<T>
/*     */     implements ComponentServiceObjects<T> {
/* 128 */     private final List<T> instances = new ArrayList<>();
/*     */     
/*     */     private volatile ServiceObjects<T> serviceObjects;
/*     */     
/*     */     private volatile boolean deactivated = false;
/*     */ 
/*     */     
/*     */     public ComponentServiceObjectsImpl(ServiceObjects<T> so) {
/* 136 */       this.serviceObjects = so;
/*     */     }
/*     */ 
/*     */     
/*     */     public void deactivate() {
/* 141 */       this.deactivated = true;
/* 142 */       close();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void close() {
/* 150 */       ServiceObjects<T> so = this.serviceObjects;
/* 151 */       this.serviceObjects = null;
/* 152 */       if (so != null) {
/*     */         
/* 154 */         List<T> localInstances = new ArrayList<>();
/* 155 */         synchronized (this.instances) {
/*     */           
/* 157 */           localInstances.addAll(this.instances);
/* 158 */           this.instances.clear();
/*     */         } 
/* 160 */         for (T obj : localInstances) {
/*     */ 
/*     */           
/*     */           try {
/* 164 */             so.ungetService(obj);
/*     */           }
/* 166 */           catch (IllegalStateException illegalStateException) {
/*     */ 
/*     */           
/*     */           }
/* 170 */           catch (IllegalArgumentException illegalArgumentException) {}
/*     */         } 
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public T getService() {
/* 180 */       if (this.deactivated)
/*     */       {
/* 182 */         throw new IllegalStateException();
/*     */       }
/* 184 */       ServiceObjects<T> so = this.serviceObjects;
/* 185 */       T service = null;
/* 186 */       if (so != null) {
/*     */         
/* 188 */         service = (T)so.getService();
/* 189 */         if (service != null)
/*     */         {
/* 191 */           synchronized (this.instances) {
/*     */             
/* 193 */             this.instances.add(service);
/*     */           } 
/*     */         }
/*     */       } 
/* 197 */       return service;
/*     */     }
/*     */ 
/*     */     
/*     */     public void ungetService(T service) {
/* 202 */       if (this.deactivated)
/*     */       {
/* 204 */         throw new IllegalStateException();
/*     */       }
/* 206 */       ServiceObjects<T> so = this.serviceObjects;
/* 207 */       if (so != null) {
/*     */         boolean remove;
/*     */         
/* 210 */         synchronized (this.instances) {
/*     */           
/* 212 */           remove = this.instances.remove(service);
/*     */         } 
/* 214 */         if (remove) {
/* 215 */           so.ungetService(service);
/*     */         }
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public ServiceReference<T> getServiceReference() {
/* 222 */       ServiceObjects<T> so = this.serviceObjects;
/* 223 */       if (so != null)
/*     */       {
/* 225 */         return so.getServiceReference();
/*     */       }
/* 227 */       return null;
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/* 232 */       return "ComponentServiceObjectsImpl [instances=" + this.instances + ", serviceObjects=" + this.serviceObjects + ", deactivated=" + this.deactivated + ", hashCode=" + 
/* 233 */         hashCode() + "]";
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.apache.felix.scr-2.2.6.jar!\org\apache\felix\scr\impl\helper\ComponentServiceObjectsHelper.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */