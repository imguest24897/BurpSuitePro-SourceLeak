/*    */ package org.apache.felix.scr.impl.inject.methods;
/*    */ 
/*    */ import org.apache.felix.scr.impl.metadata.DSVersion;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ModifiedMethod
/*    */   extends ActivateMethod
/*    */ {
/*    */   public ModifiedMethod(String methodName, Class<?> componentClass, DSVersion dsVersion, boolean configurableServiceProperties, boolean supportsInterfaces) {
/* 30 */     super(methodName, (methodName != null), componentClass, dsVersion, configurableServiceProperties, supportsInterfaces);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   protected boolean acceptEmpty() {
/* 36 */     return true;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   protected String getMethodNamePrefix() {
/* 42 */     return "modified";
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.apache.felix.scr-2.2.6.jar!\org\apache\felix\scr\impl\inject\methods\ModifiedMethod.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */