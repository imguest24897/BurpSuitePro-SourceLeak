/*     */ package org.apache.felix.scr.impl.inject.methods;
/*     */ 
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Modifier;
/*     */ import java.security.AccessController;
/*     */ import java.security.PrivilegedAction;
/*     */ import java.util.Arrays;
/*     */ import java.util.Map;
/*     */ import org.apache.felix.scr.impl.inject.BaseParameter;
/*     */ import org.apache.felix.scr.impl.inject.MethodResult;
/*     */ import org.apache.felix.scr.impl.inject.internal.ClassUtils;
/*     */ import org.apache.felix.scr.impl.logger.ComponentLogger;
/*     */ import org.apache.felix.scr.impl.logger.InternalLogger;
/*     */ import org.apache.felix.scr.impl.metadata.DSVersion;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class BaseMethod<P extends BaseParameter, T>
/*     */ {
/*     */   private final DSVersion dsVersion;
/*     */   private final boolean configurableServiceProperties;
/*     */   private final String m_methodName;
/*     */   private final Class<?> m_componentClass;
/*     */   private volatile Method m_method;
/*     */   private final boolean m_methodRequired;
/*     */   private volatile State m_state;
/*     */   
/*     */   protected BaseMethod(String methodName, boolean methodRequired, Class<?> componentClass, DSVersion dsVersion, boolean configurableServiceProperties) {
/*  62 */     this.m_methodName = methodName;
/*  63 */     this.m_methodRequired = methodRequired;
/*  64 */     this.m_componentClass = componentClass;
/*  65 */     this.dsVersion = dsVersion;
/*  66 */     this.configurableServiceProperties = configurableServiceProperties;
/*  67 */     if (this.m_methodName == null) {
/*     */       
/*  69 */       this.m_state = NotApplicable.INSTANCE;
/*     */     }
/*     */     else {
/*     */       
/*  73 */       this.m_state = NotResolved.INSTANCE;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   protected final DSVersion getDSVersion() {
/*  79 */     return this.dsVersion;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected final boolean isDS12Felix() {
/*  85 */     return this.configurableServiceProperties;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected final String getMethodName() {
/*  91 */     return this.m_methodName;
/*     */   }
/*     */ 
/*     */   
/*     */   final Method getMethod() {
/*  96 */     return this.m_method;
/*     */   }
/*     */ 
/*     */   
/*     */   protected final Class<?> getComponentClass() {
/* 101 */     return this.m_componentClass;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   synchronized void setMethod(MethodInfo<T> methodInfo, ComponentLogger logger) {
/* 108 */     this.m_method = (methodInfo == null) ? null : methodInfo.getMethod();
/*     */     
/* 110 */     if (this.m_method != null) {
/*     */       
/* 112 */       setTypes(methodInfo.getTypes());
/* 113 */       this.m_state = Resolved.INSTANCE;
/* 114 */       logger.log(InternalLogger.Level.DEBUG, "Found {0} method: {1}", null, new Object[] {
/* 115 */             getMethodNamePrefix(), this.m_method
/*     */           });
/* 117 */     } else if (this.m_methodRequired) {
/*     */       
/* 119 */       this.m_state = NotFound.INSTANCE;
/* 120 */       logger.log(InternalLogger.Level.ERROR, "{0} method [{1}] not found; Component will fail", null, new Object[] {
/*     */             
/* 122 */             getMethodNamePrefix(), getMethodName()
/*     */           });
/*     */     }
/*     */     else {
/*     */       
/* 127 */       logger.log(InternalLogger.Level.DEBUG, "{0} method [{1}] not found, ignoring", null, new Object[] {
/* 128 */             getMethodNamePrefix(), getMethodName() });
/* 129 */       this.m_state = NotApplicable.INSTANCE;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   State getState() {
/* 136 */     return this.m_state;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private MethodInfo<T> findMethod(ComponentLogger logger) throws InvocationTargetException {
/* 154 */     boolean acceptPrivate = getDSVersion().isDS11();
/* 155 */     boolean acceptPackage = getDSVersion().isDS11();
/*     */     
/* 157 */     Class<?> targetClass = getComponentClass();
/* 158 */     ClassLoader targetClasslLoader = targetClass.getClassLoader();
/* 159 */     String targetPackage = getPackageName(targetClass);
/* 160 */     Class<?> theClass = targetClass;
/*     */ 
/*     */ 
/*     */     
/*     */     while (true) {
/* 165 */       if (logger.isLogEnabled(InternalLogger.Level.DEBUG))
/*     */       {
/* 167 */         logger.log(InternalLogger.Level.DEBUG, "Locating method " + 
/* 168 */             getMethodName() + " in class " + theClass.getName(), null);
/*     */       }
/*     */ 
/*     */       
/*     */       try {
/* 173 */         MethodInfo<T> method = doFindMethod(theClass, acceptPrivate, acceptPackage, logger);
/*     */ 
/*     */         
/* 176 */         if (method != null)
/*     */         {
/* 178 */           return method;
/*     */         }
/*     */       }
/* 181 */       catch (SuitableMethodNotAccessibleException ex) {
/*     */ 
/*     */         
/* 184 */         logger.log(InternalLogger.Level.ERROR, "findMethod: Suitable but non-accessible method {0} found in class {1}, subclass of {2}", null, new Object[] {
/*     */               
/* 186 */               getMethodName(), theClass.getName(), targetClass.getName()
/*     */             });
/*     */         
/*     */         break;
/*     */       } 
/* 191 */       theClass = theClass.getSuperclass();
/* 192 */       if (theClass == null) {
/*     */         break;
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 201 */       int i = acceptPackage & ((targetClasslLoader == theClass.getClassLoader() && targetPackage.equals(getPackageName(theClass))) ? 1 : 0);
/*     */ 
/*     */       
/* 204 */       acceptPrivate = false;
/*     */     } 
/*     */ 
/*     */     
/* 208 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String[] getParametersForLogging(Object[] params) {
/* 219 */     if (params == null) {
/* 220 */       return null;
/*     */     }
/* 222 */     String[] result = new String[params.length];
/* 223 */     for (int i = 0; i < params.length; i++) {
/* 224 */       result[i] = (params[i] == null) ? null : params[i].getClass().getName();
/*     */     }
/* 226 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private MethodResult invokeMethod(Object componentInstance, P rawParameter) throws InvocationTargetException {
/* 232 */     ComponentLogger logger = rawParameter.getComponentContext().getLogger();
/*     */     
/*     */     try {
/* 235 */       if (componentInstance != null) {
/*     */         
/* 237 */         Object[] params = getParameters(this.m_method, rawParameter);
/* 238 */         if (logger.isLogEnabled(InternalLogger.Level.DEBUG))
/*     */         {
/* 240 */           logger.log(InternalLogger.Level.DEBUG, "invoking {0}: {1}: parameters {2}", null, new Object[] {
/* 241 */                 getMethodNamePrefix(), 
/* 242 */                 getMethodName(), Arrays.asList(getParametersForLogging(params))
/*     */               });
/*     */         }
/* 245 */         Map<String, Object> result = (Map<String, Object>)this.m_method.invoke(componentInstance, params);
/*     */         
/* 247 */         logger.log(InternalLogger.Level.DEBUG, "invoked {0}: {1}", null, new Object[] {
/* 248 */               getMethodNamePrefix(), getMethodName() });
/* 249 */         return new MethodResult((this.m_method.getReturnType() != void.class), result);
/*     */       } 
/*     */ 
/*     */       
/* 253 */       rawParameter.getComponentContext().getLogger().log(InternalLogger.Level.WARN, "Method {0}: {1} cannot be called on null object", null, new Object[] {
/*     */ 
/*     */             
/* 256 */             getMethodNamePrefix(), getMethodName()
/*     */           });
/*     */     }
/* 259 */     catch (IllegalStateException ise) {
/*     */       
/* 261 */       rawParameter.getComponentContext().getLogger().log(InternalLogger.Level.DEBUG, ise
/* 262 */           .getMessage(), null);
/* 263 */       return null;
/*     */     }
/* 265 */     catch (IllegalAccessException ex) {
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 270 */       rawParameter.getComponentContext().getLogger().log(InternalLogger.Level.DEBUG, "Method {0} cannot be called", ex, new Object[] {
/*     */             
/* 272 */             getMethodName()
/*     */           });
/* 274 */     } catch (InvocationTargetException ex) {
/*     */       
/* 276 */       throw ex;
/*     */     }
/* 278 */     catch (Throwable t) {
/*     */       
/* 280 */       throw new InvocationTargetException(t);
/*     */     } 
/*     */ 
/*     */     
/* 284 */     return MethodResult.VOID;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean returnValue() {
/* 290 */     return isDS12Felix();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String getMethodNamePrefix() {
/* 307 */     return "";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Method getMethod(Class<?> clazz, String name, Class<?>[] parameterTypes, boolean acceptPrivate, boolean acceptPackage, ComponentLogger logger) throws SuitableMethodNotAccessibleException, InvocationTargetException {
/*     */     try {
/* 347 */       Method method = clazz.getDeclaredMethod(name, parameterTypes);
/*     */ 
/*     */       
/* 350 */       if (accept(method, acceptPrivate, acceptPackage, returnValue()))
/*     */       {
/* 352 */         return method;
/*     */       }
/*     */ 
/*     */       
/* 356 */       throw new SuitableMethodNotAccessibleException();
/*     */     }
/* 358 */     catch (NoSuchMethodException nsme) {
/*     */ 
/*     */ 
/*     */       
/* 362 */       if (logger.isLogEnabled(InternalLogger.Level.DEBUG))
/*     */       {
/* 364 */         String argList = (parameterTypes != null) ? Arrays.<Class<?>>asList(parameterTypes).toString() : "";
/* 365 */         logger.log(InternalLogger.Level.DEBUG, "Declared Method {0}.{1}({2}) not found", null, new Object[] { clazz
/* 366 */               .getName(), name, argList });
/*     */       }
/*     */     
/* 369 */     } catch (NoClassDefFoundError cdfe) {
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 374 */       if (logger.isLogEnabled(InternalLogger.Level.WARN))
/*     */       {
/* 376 */         StringBuilder buf = new StringBuilder();
/* 377 */         buf.append("Failure loooking up method ").append(name).append('(');
/* 378 */         for (int i = 0; parameterTypes != null && i < parameterTypes.length; i++) {
/*     */           
/* 380 */           buf.append(parameterTypes[i].getName());
/* 381 */           if (i > 0)
/*     */           {
/* 383 */             buf.append(", ");
/*     */           }
/*     */         } 
/* 386 */         buf.append(") in class class ").append(clazz.getName()).append(". Assuming no such method.");
/* 387 */         logger.log(InternalLogger.Level.WARN, buf.toString(), cdfe);
/*     */       }
/*     */     
/* 390 */     } catch (SuitableMethodNotAccessibleException e) {
/*     */       
/* 392 */       throw e;
/*     */     }
/* 394 */     catch (Throwable throwable) {
/*     */ 
/*     */ 
/*     */       
/* 398 */       throw new InvocationTargetException(throwable, "Unexpected problem trying to get method " + name);
/*     */     } 
/*     */ 
/*     */     
/* 402 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static boolean accept(Method method, boolean acceptPrivate, boolean acceptPackage, boolean allowReturnValue) {
/* 432 */     if (void.class != method.getReturnType() && (ClassUtils.MAP_CLASS != method.getReturnType() || !allowReturnValue))
/*     */     {
/* 434 */       return false;
/*     */     }
/*     */ 
/*     */     
/* 438 */     int mod = method.getModifiers();
/*     */ 
/*     */     
/* 441 */     if (Modifier.isStatic(mod))
/*     */     {
/* 443 */       return false;
/*     */     }
/*     */ 
/*     */     
/* 447 */     if (Modifier.isPublic(mod) || Modifier.isProtected(mod)) {
/*     */       
/* 449 */       setAccessible(method);
/* 450 */       return true;
/*     */     } 
/*     */ 
/*     */     
/* 454 */     if (Modifier.isPrivate(mod)) {
/*     */       
/* 456 */       if (acceptPrivate) {
/*     */         
/* 458 */         setAccessible(method);
/* 459 */         return true;
/*     */       } 
/*     */       
/* 462 */       return false;
/*     */     } 
/*     */ 
/*     */     
/* 466 */     if (acceptPackage) {
/*     */       
/* 468 */       setAccessible(method);
/* 469 */       return true;
/*     */     } 
/*     */ 
/*     */     
/* 473 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static void setAccessible(final Method method) {
/* 479 */     AccessController.doPrivileged(new PrivilegedAction()
/*     */         {
/*     */           
/*     */           public Object run()
/*     */           {
/* 484 */             method.setAccessible(true);
/* 485 */             return null;
/*     */           }
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getPackageName(Class<?> clazz) {
/* 497 */     String name = clazz.getName();
/* 498 */     int dot = name.lastIndexOf('.');
/* 499 */     return (dot > 0) ? name.substring(0, dot) : "";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MethodResult invoke(Object componentInstance, P rawParameter, MethodResult methodCallFailureResult) {
/*     */     try {
/* 531 */       return this.m_state.invoke(this, componentInstance, rawParameter);
/*     */     }
/* 533 */     catch (InvocationTargetException ite) {
/*     */       
/* 535 */       rawParameter.getComponentContext().getLogger().log(InternalLogger.Level.ERROR, "The {0} method has thrown an exception", ite
/* 536 */           .getCause(), new Object[] {
/* 537 */             getMethodName() });
/* 538 */       if (methodCallFailureResult != null && methodCallFailureResult.getResult() != null)
/*     */       {
/* 540 */         methodCallFailureResult.getResult().put("exception", ite.getCause());
/*     */       }
/*     */ 
/*     */       
/* 544 */       return methodCallFailureResult;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean methodExists(ComponentLogger logger) {
/* 550 */     return this.m_state.methodExists(this, logger);
/*     */   }
/*     */   protected abstract void setTypes(T paramT);
/*     */   protected abstract MethodInfo<T> doFindMethod(Class<?> paramClass, boolean paramBoolean1, boolean paramBoolean2, ComponentLogger paramComponentLogger) throws SuitableMethodNotAccessibleException, InvocationTargetException;
/*     */   
/*     */   protected abstract Object[] getParameters(Method paramMethod, P paramP);
/*     */   
/*     */   protected static final class MethodInfo<T> { private final Method m_method;
/*     */     
/*     */     public MethodInfo(Method m) {
/* 560 */       this(m, null);
/*     */     }
/*     */     private final T m_types;
/*     */     
/*     */     public MethodInfo(Method m, T types) {
/* 565 */       this.m_method = m;
/* 566 */       this.m_types = types;
/*     */     }
/*     */ 
/*     */     
/*     */     public Method getMethod() {
/* 571 */       return this.m_method;
/*     */     }
/*     */ 
/*     */     
/*     */     public T getTypes() {
/* 576 */       return this.m_types;
/*     */     } }
/*     */ 
/*     */ 
/*     */   
/*     */   private static interface State
/*     */   {
/*     */     <P extends BaseParameter, T> MethodResult invoke(BaseMethod<P, T> param1BaseMethod, Object param1Object, P param1P) throws InvocationTargetException;
/*     */ 
/*     */     
/*     */     <P extends BaseParameter, T> boolean methodExists(BaseMethod<P, T> param1BaseMethod, ComponentLogger param1ComponentLogger);
/*     */   }
/*     */ 
/*     */   
/*     */   private static class NotApplicable
/*     */     implements State
/*     */   {
/* 593 */     private static final BaseMethod.State INSTANCE = new NotApplicable();
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public <P extends BaseParameter, T> MethodResult invoke(BaseMethod<P, T> baseMethod, Object componentInstance, P rawParameter) {
/* 599 */       return MethodResult.VOID;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public <P extends BaseParameter, T> boolean methodExists(BaseMethod<P, T> baseMethod, ComponentLogger logger) {
/* 606 */       return true;
/*     */     }
/*     */   }
/*     */   
/*     */   private static class NotResolved
/*     */     implements State {
/* 612 */     private static final BaseMethod.State INSTANCE = new NotResolved();
/*     */ 
/*     */ 
/*     */     
/*     */     private <P extends BaseParameter, T> void resolve(BaseMethod<P, T> baseMethod, ComponentLogger logger) {
/* 617 */       logger.log(InternalLogger.Level.DEBUG, "getting {0}: {1}", null, new Object[] { baseMethod
/* 618 */             .getMethodNamePrefix(), baseMethod.getMethodName() });
/*     */ 
/*     */       
/* 621 */       BaseMethod.MethodInfo<T> method = null;
/*     */       
/*     */       try {
/* 624 */         method = baseMethod.findMethod(logger);
/*     */       }
/* 626 */       catch (InvocationTargetException ex) {
/*     */         
/* 628 */         logger.log(InternalLogger.Level.WARN, "{0} cannot be found", ex.getTargetException(), new Object[] { baseMethod
/* 629 */               .getMethodName() });
/*     */       } 
/*     */       
/* 632 */       baseMethod.setMethod(method, logger);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public <P extends BaseParameter, T> MethodResult invoke(BaseMethod<P, T> baseMethod, Object componentInstance, P rawParameter) throws InvocationTargetException {
/* 640 */       resolve(baseMethod, rawParameter.getComponentContext().getLogger());
/* 641 */       return baseMethod.getState().invoke(baseMethod, componentInstance, rawParameter);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public <P extends BaseParameter, T> boolean methodExists(BaseMethod<P, T> baseMethod, ComponentLogger logger) {
/* 648 */       resolve(baseMethod, logger);
/* 649 */       return baseMethod.getState().methodExists(baseMethod, logger);
/*     */     }
/*     */   }
/*     */   
/*     */   private static class NotFound
/*     */     implements State {
/* 655 */     private static final BaseMethod.State INSTANCE = new NotFound();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public <P extends BaseParameter, T> MethodResult invoke(BaseMethod<P, T> baseMethod, Object componentInstance, P rawParameter) {
/* 664 */       rawParameter.getComponentContext().getLogger().log(InternalLogger.Level.ERROR, "{0} method [{1}] not found", null, new Object[] { baseMethod
/*     */             
/* 666 */             .getMethodNamePrefix(), baseMethod.getMethodName() });
/* 667 */       return null;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public <P extends BaseParameter, T> boolean methodExists(BaseMethod<P, T> baseMethod, ComponentLogger logger) {
/* 674 */       return false;
/*     */     }
/*     */   }
/*     */   
/*     */   private static class Resolved
/*     */     implements State {
/* 680 */     private static final BaseMethod.State INSTANCE = new Resolved();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public <P extends BaseParameter, T> MethodResult invoke(BaseMethod<P, T> baseMethod, Object componentInstance, P rawParameter) throws InvocationTargetException {
/* 687 */       return baseMethod.invokeMethod(componentInstance, rawParameter);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public <P extends BaseParameter, T> boolean methodExists(BaseMethod<P, T> baseMethod, ComponentLogger logger) {
/* 694 */       return true;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.apache.felix.scr-2.2.6.jar!\org\apache\felix\scr\impl\inject\methods\BaseMethod.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */