/*      */ package org.apache.felix.scr.impl.manager;
/*      */ 
/*      */ import java.io.PrintWriter;
/*      */ import java.io.StringWriter;
/*      */ import java.lang.reflect.InvocationTargetException;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Arrays;
/*      */ import java.util.Collections;
/*      */ import java.util.Dictionary;
/*      */ import java.util.Enumeration;
/*      */ import java.util.HashMap;
/*      */ import java.util.Hashtable;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.Set;
/*      */ import java.util.TreeSet;
/*      */ import java.util.concurrent.TimeUnit;
/*      */ import java.util.concurrent.atomic.AtomicInteger;
/*      */ import java.util.concurrent.atomic.AtomicLong;
/*      */ import java.util.concurrent.atomic.AtomicReference;
/*      */ import java.util.concurrent.locks.Condition;
/*      */ import java.util.concurrent.locks.Lock;
/*      */ import java.util.concurrent.locks.ReentrantLock;
/*      */ import java.util.concurrent.locks.ReentrantReadWriteLock;
/*      */ import org.apache.felix.scr.impl.inject.ComponentMethods;
/*      */ import org.apache.felix.scr.impl.inject.MethodResult;
/*      */ import org.apache.felix.scr.impl.inject.RefPair;
/*      */ import org.apache.felix.scr.impl.logger.ComponentLogger;
/*      */ import org.apache.felix.scr.impl.logger.InternalLogger;
/*      */ import org.apache.felix.scr.impl.metadata.ComponentMetadata;
/*      */ import org.apache.felix.scr.impl.metadata.ReferenceMetadata;
/*      */ import org.apache.felix.scr.impl.metadata.ServiceMetadata;
/*      */ import org.apache.felix.scr.impl.metadata.TargetedPID;
/*      */ import org.osgi.framework.Bundle;
/*      */ import org.osgi.framework.BundleContext;
/*      */ import org.osgi.framework.ServiceException;
/*      */ import org.osgi.framework.ServicePermission;
/*      */ import org.osgi.framework.ServiceReference;
/*      */ import org.osgi.framework.ServiceRegistration;
/*      */ import org.osgi.util.promise.Deferred;
/*      */ import org.osgi.util.promise.Promise;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public abstract class AbstractComponentManager<S>
/*      */   implements ComponentManager<S>
/*      */ {
/*   73 */   static final String[] REASONS = new String[] { "Unspecified", "Component disabled", "Reference became unsatisfied", "Configuration modified", "Configuration deleted", "Component disabled", "Bundle stopped" }; protected final ComponentContainer<S> m_container; protected final boolean m_factoryInstance;
/*      */   private volatile long m_componentId;
/*      */   private final ComponentMethods<S> m_componentMethods;
/*      */   private final List<DependencyManager<S, ?>> m_dependencyManagers;
/*      */   private volatile boolean m_dependencyManagersInitialized;
/*      */   
/*   79 */   protected enum State { disposed(-1, false, false, false),
/*      */ 
/*      */     
/*   82 */     disabled(-1, false, false, false),
/*   83 */     unsatisfiedReference(2, true, false, false),
/*   84 */     satisfied(4, true, true, false),
/*   85 */     active(8, true, true, true);
/*      */     
/*      */     private final int specState;
/*      */     
/*      */     private final boolean enabled;
/*      */     
/*      */     private final boolean satisfed;
/*      */     
/*      */     private final boolean actve;
/*      */ 
/*      */     
/*      */     State(int specState, boolean enabled, boolean satisfied, boolean active) {
/*   97 */       this.specState = specState;
/*   98 */       this.enabled = enabled;
/*   99 */       this.satisfed = satisfied;
/*  100 */       this.actve = active;
/*      */     }
/*      */ 
/*      */     
/*      */     public int getSpecState() {
/*  105 */       return this.specState;
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean isEnabled() {
/*  110 */       return this.enabled;
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean isSatisfied() {
/*  115 */       return this.satisfed;
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean isActive() {
/*  120 */       return this.actve;
/*      */     } }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  140 */   private final AtomicInteger m_trackingCount = new AtomicInteger();
/*      */ 
/*      */ 
/*      */   
/*      */   private final ReentrantLock m_stateLock;
/*      */ 
/*      */ 
/*      */   
/*  148 */   private final AtomicReference<Deferred<Void>> m_enabledLatchRef = new AtomicReference<>(new Deferred());
/*      */ 
/*      */   
/*  151 */   private final AtomicReference<State> state = new AtomicReference<>(State.disabled);
/*      */ 
/*      */   
/*      */   private volatile int m_floor;
/*      */   
/*      */   private volatile int m_ceiling;
/*      */   
/*  158 */   private final Lock m_missingLock = new ReentrantLock();
/*  159 */   private final Condition m_missingCondition = this.m_missingLock.newCondition();
/*  160 */   private final Set<Integer> m_missing = new TreeSet<>();
/*      */   
/*  162 */   protected final ReentrantReadWriteLock m_activationLock = new ReentrantReadWriteLock();
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private volatile String failureReason;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected AbstractComponentManager(ComponentContainer<S> container, ComponentMethods<S> componentMethods) {
/*  174 */     this(container, componentMethods, false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final long getLockTimeout() {
/*  228 */     if (this.m_container.getActivator().getConfiguration() != null)
/*      */     {
/*  230 */       return this.m_container.getActivator().getConfiguration().lockTimeout();
/*      */     }
/*  232 */     return 5000L;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private void obtainLock(Lock lock) {
/*      */     try {
/*  239 */       if (!lock.tryLock(getLockTimeout(), TimeUnit.MILLISECONDS))
/*      */       {
/*  241 */         dumpThreads();
/*  242 */         throw new IllegalStateException("Could not obtain lock");
/*      */       }
/*      */     
/*  245 */     } catch (InterruptedException e) {
/*      */ 
/*      */       
/*      */       try {
/*  249 */         if (!lock.tryLock(getLockTimeout(), TimeUnit.MILLISECONDS))
/*      */         {
/*  251 */           dumpThreads();
/*  252 */           throw new IllegalStateException("Could not obtain lock");
/*      */         }
/*      */       
/*  255 */       } catch (InterruptedException e1) {
/*      */         
/*  257 */         Thread.currentThread().interrupt();
/*  258 */         throw new IllegalStateException("Interrupted twice: Could not obtain lock");
/*      */       } 
/*  260 */       Thread.currentThread().interrupt();
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   final void obtainActivationReadLock() {
/*  266 */     obtainLock(this.m_activationLock.readLock());
/*      */   }
/*      */ 
/*      */   
/*      */   final void releaseActivationReadLock() {
/*  271 */     this.m_activationLock.readLock().unlock();
/*      */   }
/*      */ 
/*      */   
/*      */   final void obtainActivationWriteLock() {
/*  276 */     obtainLock(this.m_activationLock.writeLock());
/*      */   }
/*      */ 
/*      */   
/*      */   final void releaseActivationWriteeLock() {
/*  281 */     if (this.m_activationLock.getWriteHoldCount() > 0)
/*      */     {
/*  283 */       this.m_activationLock.writeLock().unlock();
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   final void obtainStateLock() {
/*  289 */     obtainLock(this.m_stateLock);
/*      */   }
/*      */ 
/*      */   
/*      */   final void releaseStateLock() {
/*  294 */     this.m_stateLock.unlock();
/*      */   }
/*      */ 
/*      */   
/*      */   final boolean isStateLocked() {
/*  299 */     return (this.m_stateLock.getHoldCount() > 0);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   final void dumpThreads() {
/*      */     try {
/*  306 */       String dump = (new ThreadDump()).call();
/*  307 */       this.m_container.getLogger().log(InternalLogger.Level.DEBUG, dump, null);
/*      */     }
/*  309 */     catch (Throwable t) {
/*      */       
/*  311 */       this.m_container.getLogger().log(InternalLogger.Level.DEBUG, "Could not dump threads", t);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   void tracked(int trackingCount) {
/*  318 */     this.m_missingLock.lock();
/*      */     
/*      */     try {
/*  321 */       if (trackingCount == this.m_floor + 1) {
/*      */         
/*  323 */         this.m_floor++;
/*  324 */         this.m_missing.remove(Integer.valueOf(trackingCount));
/*      */       }
/*  326 */       else if (trackingCount < this.m_ceiling) {
/*      */         
/*  328 */         this.m_missing.remove(Integer.valueOf(trackingCount));
/*      */       } 
/*  330 */       if (trackingCount > this.m_ceiling) {
/*      */         
/*  332 */         for (int i = this.m_ceiling + 1; i < trackingCount; i++)
/*      */         {
/*  334 */           this.m_missing.add(Integer.valueOf(i));
/*      */         }
/*  336 */         this.m_ceiling = trackingCount;
/*      */       } 
/*  338 */       this.m_missingCondition.signalAll();
/*      */     }
/*      */     finally {
/*      */       
/*  342 */       this.m_missingLock.unlock();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void waitForTracked(int trackingCount) {
/*  353 */     this.m_missingLock.lock();
/*      */ 
/*      */     
/*  356 */     try { while (this.m_ceiling < trackingCount || (!this.m_missing.isEmpty() && ((Integer)this.m_missing.iterator().next()).intValue() < trackingCount)) {
/*      */         
/*  358 */         this.m_container.getLogger().log(InternalLogger.Level.DEBUG, "waitForTracked trackingCount: {0} ceiling: {1} missing: {2}", null, new Object[] {
/*      */               
/*  360 */               Integer.valueOf(trackingCount), Integer.valueOf(this.m_ceiling), this.m_missing
/*      */             });
/*      */         try {
/*  363 */           if (!doMissingWait())
/*      */           {
/*      */             return;
/*      */           }
/*      */         }
/*  368 */         catch (InterruptedException e) {
/*      */ 
/*      */           
/*      */           try {
/*  372 */             if (!doMissingWait())
/*      */             {
/*      */               return;
/*      */             }
/*      */           }
/*  377 */           catch (InterruptedException e1) {
/*      */             
/*  379 */             this.m_container.getLogger().log(InternalLogger.Level.ERROR, "waitForTracked interrupted twice: {0} ceiling: {1} missing: {2},  Expect further errors", e1, new Object[] {
/*      */                   
/*  381 */                   Integer.valueOf(trackingCount), Integer.valueOf(this.m_ceiling), this.m_missing });
/*      */           } 
/*  383 */           Thread.currentThread().interrupt();
/*      */         } 
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/*  389 */       this.m_missingLock.unlock(); } finally { this.m_missingLock.unlock(); }
/*      */   
/*      */   }
/*      */ 
/*      */   
/*      */   private boolean doMissingWait() throws InterruptedException {
/*  395 */     if (!this.m_missingCondition.await(getLockTimeout(), TimeUnit.MILLISECONDS)) {
/*      */       
/*  397 */       this.m_container.getLogger().log(InternalLogger.Level.ERROR, "waitForTracked timed out: {0} ceiling: {1} missing: {2},  Expect further errors", null, new Object[] { this.m_trackingCount, 
/*      */ 
/*      */             
/*  400 */             Integer.valueOf(this.m_ceiling), this.m_missing });
/*  401 */       dumpThreads();
/*  402 */       this.m_missing.clear();
/*  403 */       return false;
/*      */     } 
/*  405 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void registerComponentId() {
/*  412 */     this.m_componentId = this.m_container.getActivator().registerComponentId(this);
/*  413 */     this.m_container.getLogger().setComponentId(this.m_componentId);
/*      */   }
/*      */ 
/*      */   
/*      */   void unregisterComponentId() {
/*  418 */     if (this.m_componentId >= 0L) {
/*      */       
/*  420 */       this.m_container.getActivator().unregisterComponentId(this);
/*  421 */       this.m_componentId = -1L;
/*  422 */       this.m_container.getLogger().setComponentId(this.m_componentId);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*  427 */   private static final AtomicLong taskCounter = new AtomicLong();
/*      */   final RegistrationManager<ServiceRegistration<S>> registrationManager;
/*      */   
/*      */   public final Promise<Void> enable(boolean async) {
/*  431 */     Deferred<Void> enableLatch = null;
/*      */     
/*      */     try {
/*  434 */       enableLatch = enableLatchWait();
/*  435 */       if (!async)
/*      */       {
/*  437 */         enableInternal();
/*      */       }
/*      */     }
/*      */     finally {
/*      */       
/*  442 */       if (!async)
/*      */       {
/*  444 */         enableLatch.resolve(null);
/*      */       }
/*      */     } 
/*      */     
/*  448 */     if (async) {
/*      */       
/*  450 */       final Deferred<Void> latch = enableLatch;
/*  451 */       this.m_container.getActivator().schedule(new Runnable()
/*      */           {
/*      */             
/*  454 */             long count = AbstractComponentManager.taskCounter.incrementAndGet();
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*      */             public void run() {
/*      */               try {
/*  461 */                 AbstractComponentManager.this.enableInternal();
/*      */               }
/*      */               finally {
/*      */                 
/*  465 */                 latch.resolve(null);
/*      */               } 
/*      */             }
/*      */ 
/*      */ 
/*      */             
/*      */             public String toString() {
/*  472 */               return "Async Activate: " + AbstractComponentManager.this.getComponentMetadata().getName() + " id: " + this.count;
/*      */             }
/*      */           });
/*      */     } 
/*  476 */     return enableLatch.getPromise();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   Deferred<Void> enableLatchWait() {
/*      */     while (true) {
/*  492 */       Deferred<Void> enabledLatch = this.m_enabledLatchRef.get();
/*  493 */       boolean waited = false;
/*  494 */       boolean interrupted = false;
/*  495 */       while (!waited) {
/*      */ 
/*      */         
/*      */         try {
/*  499 */           enabledLatch.getPromise().getValue();
/*  500 */           waited = true;
/*      */         }
/*  502 */         catch (InterruptedException e) {
/*      */           
/*  504 */           interrupted = true;
/*      */         }
/*  506 */         catch (InvocationTargetException invocationTargetException) {}
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/*  511 */       if (interrupted)
/*      */       {
/*  513 */         Thread.currentThread().interrupt();
/*      */       }
/*  515 */       Deferred<Void> newEnabledLatch = new Deferred();
/*      */       
/*  517 */       if (this.m_enabledLatchRef.compareAndSet(enabledLatch, newEnabledLatch))
/*  518 */         return newEnabledLatch; 
/*      */     } 
/*      */   }
/*      */   
/*      */   public final Promise<Void> disable(boolean async) {
/*  523 */     Deferred<Void> enableLatch = null;
/*      */     
/*      */     try {
/*  526 */       enableLatch = enableLatchWait();
/*  527 */       if (!async)
/*      */       {
/*  529 */         disableInternal();
/*      */       }
/*      */     }
/*      */     finally {
/*      */       
/*  534 */       if (!async)
/*      */       {
/*  536 */         enableLatch.resolve(null);
/*      */       }
/*      */     } 
/*      */     
/*  540 */     if (async) {
/*      */       
/*  542 */       final Deferred<Void> latch = enableLatch;
/*  543 */       this.m_container.getActivator().schedule(new Runnable()
/*      */           {
/*      */             
/*  546 */             long count = AbstractComponentManager.taskCounter.incrementAndGet();
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*      */             public void run() {
/*      */               try {
/*  553 */                 AbstractComponentManager.this.disableInternal();
/*      */               }
/*      */               finally {
/*      */                 
/*  557 */                 latch.resolve(null);
/*      */               } 
/*      */             }
/*      */ 
/*      */ 
/*      */             
/*      */             public String toString() {
/*  564 */               return "Async Deactivate: " + AbstractComponentManager.this.getComponentMetadata().getName() + " id: " + this.count;
/*      */             }
/*      */           });
/*      */     } 
/*      */     
/*  569 */     return enableLatch.getPromise();
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   void dispose() {
/*  575 */     dispose(5);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void dispose(int reason) {
/*  589 */     deactivateInternal(reason, true, true);
/*      */   }
/*      */ 
/*      */   
/*      */   <T> void registerMissingDependency(DependencyManager<S, T> dm, ServiceReference<T> ref, int trackingCount) {
/*  594 */     this.m_container.getActivator().registerMissingDependency(dm, ref, trackingCount);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public long getId() {
/*  602 */     return this.m_componentId;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Bundle getBundle() {
/*  612 */     BundleContext context = getBundleContext();
/*  613 */     if (context != null) {
/*      */       
/*      */       try {
/*      */         
/*  617 */         return context.getBundle();
/*      */       }
/*  619 */       catch (IllegalStateException illegalStateException) {}
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  625 */     return null;
/*      */   }
/*      */ 
/*      */   
/*      */   BundleContext getBundleContext() {
/*  630 */     return this.m_container.getActivator().getBundleContext();
/*      */   }
/*      */ 
/*      */   
/*      */   protected boolean isImmediate() {
/*  635 */     return getComponentMetadata().isImmediate();
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isFactory() {
/*  641 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final void enableInternal() {
/*      */     State previousState;
/*  649 */     if ((previousState = getState()) == State.disposed)
/*      */     {
/*  651 */       throw new IllegalStateException("enable: " + this);
/*      */     }
/*  653 */     if (!this.m_container.getActivator().isActive()) {
/*      */       
/*  655 */       this.m_container.getLogger().log(InternalLogger.Level.DEBUG, "Bundle's component activator is not active; not enabling component", null);
/*      */       
/*      */       return;
/*      */     } 
/*      */     
/*  660 */     if (previousState.isEnabled()) {
/*      */       
/*  662 */       this.m_container.getLogger().log(InternalLogger.Level.WARN, "enable called but component is already in state {0}", null, new Object[] { previousState });
/*      */ 
/*      */       
/*      */       return;
/*      */     } 
/*      */     
/*  668 */     registerComponentId();
/*  669 */     this.m_container.getLogger().log(InternalLogger.Level.DEBUG, "Updating target filters", null);
/*  670 */     updateTargets(getProperties());
/*      */     
/*  672 */     setState(previousState, State.unsatisfiedReference);
/*  673 */     this.m_container.getLogger().log(InternalLogger.Level.DEBUG, "Component enabled", null);
/*  674 */     activateInternal();
/*      */   }
/*      */ 
/*      */   
/*      */   final void activateInternal() {
/*  679 */     this.m_container.getLogger().log(InternalLogger.Level.DEBUG, "ActivateInternal", null);
/*  680 */     State s = getState();
/*  681 */     if (s == State.disposed) {
/*      */       
/*  683 */       this.m_container.getLogger().log(InternalLogger.Level.DEBUG, "ActivateInternal: disposed", null);
/*      */       
/*      */       return;
/*      */     } 
/*  687 */     if (s == State.active) {
/*      */       
/*  689 */       this.m_container.getLogger().log(InternalLogger.Level.DEBUG, "ActivateInternal: already activated", null);
/*      */       
/*      */       return;
/*      */     } 
/*  693 */     if (!s.isEnabled()) {
/*      */       
/*  695 */       this.m_container.getLogger().log(InternalLogger.Level.DEBUG, "Component is not enabled; not activating component", null);
/*      */       
/*      */       return;
/*      */     } 
/*  699 */     if (!this.m_container.getActivator().isActive()) {
/*      */       
/*  701 */       this.m_container.getLogger().log(InternalLogger.Level.DEBUG, "Bundle's component activator is not active; not activating component", null);
/*      */ 
/*      */       
/*      */       return;
/*      */     } 
/*      */     
/*  707 */     this.m_container.getLogger().log(InternalLogger.Level.DEBUG, "Activating component from state {0}", null, new Object[] {
/*  708 */           getState()
/*      */         });
/*      */ 
/*      */     
/*  712 */     if (!hasServiceRegistrationPermissions()) {
/*      */       
/*  714 */       this.m_container.getLogger().log(InternalLogger.Level.DEBUG, "Component is not permitted to register all services, cannot activate", null);
/*      */ 
/*      */       
/*      */       return;
/*      */     } 
/*      */     
/*  720 */     obtainActivationReadLock();
/*      */ 
/*      */     
/*      */     try {
/*  724 */       s = getState();
/*  725 */       if (s == State.disposed) {
/*      */         
/*  727 */         this.m_container.getLogger().log(InternalLogger.Level.DEBUG, "ActivateInternal: disposed", null);
/*      */         
/*      */         return;
/*      */       } 
/*  731 */       if (s == State.active) {
/*      */         
/*  733 */         this.m_container.getLogger().log(InternalLogger.Level.DEBUG, "ActivateInternal: already activated", null);
/*      */         
/*      */         return;
/*      */       } 
/*  737 */       if (!s.isEnabled()) {
/*      */         
/*  739 */         this.m_container.getLogger().log(InternalLogger.Level.DEBUG, "Component is not enabled; not activating component", null);
/*      */ 
/*      */         
/*      */         return;
/*      */       } 
/*      */       
/*  745 */       if (!verifyDependencyManagers()) {
/*      */         
/*  747 */         this.m_container.getLogger().log(InternalLogger.Level.DEBUG, "Not all dependencies satisfied, cannot activate", null);
/*      */         
/*      */         return;
/*      */       } 
/*      */       
/*  752 */       if (!registerService()) {
/*      */         return;
/*      */       }
/*      */ 
/*      */ 
/*      */       
/*  758 */       if (isImmediate() || getComponentMetadata().isFactory()) {
/*      */         
/*  760 */         ServiceRegistration<S> serviceRegistration = this.registrationManager.getServiceRegistration();
/*  761 */         ServiceReference<S> ref = null;
/*      */         
/*      */         try {
/*  764 */           ref = (serviceRegistration == null) ? null : serviceRegistration.getReference();
/*      */         }
/*  766 */         catch (IllegalStateException illegalStateException) {}
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  771 */         if (ref != null) {
/*      */           
/*  773 */           this.m_container.getActivator().enterCreate(ref);
/*      */           
/*      */           try {
/*  776 */             getServiceInternal(serviceRegistration);
/*      */           }
/*      */           finally {
/*      */             
/*  780 */             this.m_container.getActivator().leaveCreate(ref);
/*      */           }
/*      */         
/*      */         } else {
/*      */           
/*  785 */           getServiceInternal(null);
/*      */         }
/*      */       
/*      */       } 
/*      */     } finally {
/*      */       
/*  791 */       releaseActivationReadLock();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final void deactivateInternal(int reason, boolean disable, boolean dispose) {
/*  804 */     if (!getState().isEnabled()) {
/*      */       return;
/*      */     }
/*      */     
/*  808 */     State nextState = State.unsatisfiedReference;
/*  809 */     if (disable)
/*      */     {
/*  811 */       nextState = State.disabled;
/*      */     }
/*  813 */     if (dispose)
/*      */     {
/*  815 */       nextState = State.disposed;
/*      */     }
/*  817 */     this.m_container.getLogger().log(InternalLogger.Level.DEBUG, "Deactivating component", null);
/*      */ 
/*      */ 
/*      */     
/*  821 */     obtainActivationReadLock();
/*      */ 
/*      */     
/*      */     try {
/*  825 */       doDeactivate(reason, (disable || this.m_factoryInstance));
/*  826 */       setState(getState(), nextState);
/*      */     }
/*      */     finally {
/*      */       
/*  830 */       releaseActivationReadLock();
/*      */     } 
/*  832 */     if (isFactory() || this.m_factoryInstance || dispose) {
/*      */       
/*  834 */       this.m_container.getLogger().log(InternalLogger.Level.DEBUG, "Disposing component (reason: " + reason + ")", null);
/*      */       
/*  836 */       clear();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private void doDeactivate(int reason, boolean disable) {
/*      */     try {
/*  844 */       if (!unregisterService())
/*      */       {
/*  846 */         this.m_container.getLogger().log(InternalLogger.Level.DEBUG, "Component deactivation occuring on another thread", null);
/*      */       }
/*      */       
/*  849 */       obtainStateLock();
/*      */ 
/*      */       
/*      */       try {
/*  853 */         deleteComponent(reason);
/*  854 */         deactivateDependencyManagers();
/*  855 */         if (disable)
/*      */         {
/*  857 */           disableDependencyManagers();
/*      */         }
/*      */       }
/*      */       finally {
/*      */         
/*  862 */         releaseStateLock();
/*      */       }
/*      */     
/*  865 */     } catch (Throwable t) {
/*      */       
/*  867 */       this.m_container.getLogger().log(InternalLogger.Level.WARN, "Component deactivation threw an exception", t);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   final void disableInternal() {
/*  874 */     deactivateInternal(1, true, false);
/*  875 */     unregisterComponentId();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   boolean getServiceInternal(ServiceRegistration<S> serviceRegistration) {
/*  884 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private Object getService() {
/*  894 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   ComponentMethods<S> getComponentMethods() {
/*  900 */     return this.m_componentMethods;
/*      */   }
/*      */ 
/*      */   
/*      */   protected String[] getProvidedServices() {
/*  905 */     if (getComponentMetadata().getServiceMetadata() != null) {
/*      */       
/*  907 */       String[] provides = getComponentMetadata().getServiceMetadata().getProvides();
/*  908 */       return provides;
/*      */     } 
/*  910 */     return null;
/*      */   }
/*      */   
/*      */   protected AbstractComponentManager(ComponentContainer<S> container, ComponentMethods<S> componentMethods, boolean factoryInstance) {
/*  914 */     this.registrationManager = new RegistrationManager<ServiceRegistration<S>>()
/*      */       {
/*      */ 
/*      */         
/*      */         ServiceRegistration<S> register(String[] services)
/*      */         {
/*  920 */           BundleContext bundleContext = AbstractComponentManager.this.getBundleContext();
/*  921 */           if (bundleContext == null)
/*      */           {
/*  923 */             return null;
/*      */           }
/*  925 */           Dictionary<String, Object> serviceProperties = AbstractComponentManager.this.getServiceProperties();
/*      */ 
/*      */           
/*      */           try {
/*  929 */             ServiceRegistration<S> serviceRegistration = bundleContext.registerService(services, AbstractComponentManager.this
/*  930 */                 .getService(), serviceProperties);
/*  931 */             return serviceRegistration;
/*      */           }
/*  933 */           catch (ServiceException e) {
/*      */             
/*  935 */             log(InternalLogger.Level.ERROR, "Unexpected error registering component service with properties {0}", (Throwable)e, new Object[] { serviceProperties });
/*      */ 
/*      */             
/*  938 */             return null;
/*      */           } 
/*      */         }
/*      */ 
/*      */ 
/*      */         
/*      */         void postRegister(ServiceRegistration<S> t) {
/*  945 */           AbstractComponentManager.this.postRegister();
/*      */         }
/*      */ 
/*      */ 
/*      */         
/*      */         void unregister(ServiceRegistration<S> serviceRegistration) {
/*  951 */           AbstractComponentManager.this.preDeregister();
/*  952 */           serviceRegistration.unregister();
/*      */         }
/*      */ 
/*      */ 
/*      */         
/*      */         void log(InternalLogger.Level level, String message, Throwable ex, Object... arguments) {
/*  958 */           AbstractComponentManager.this.getLogger().log(level, message, ex, arguments);
/*      */         }
/*      */ 
/*      */ 
/*      */         
/*      */         long getTimeout() {
/*  964 */           return AbstractComponentManager.this.getLockTimeout();
/*      */         }
/*      */ 
/*      */ 
/*      */         
/*      */         void reportTimeout() {
/*  970 */           AbstractComponentManager.this.dumpThreads(); } }; ((Deferred)this.m_enabledLatchRef.get()).resolve(null); this.m_factoryInstance = factoryInstance; this.m_container = container; this.m_componentMethods = componentMethods;
/*      */     this.m_componentId = -1L;
/*      */     ComponentMetadata metadata = container.getComponentMetadata();
/*      */     this.m_dependencyManagers = loadDependencyManagers(metadata);
/*      */     this.m_stateLock = new ReentrantLock(true);
/*      */     if (this.m_container.getLogger().isLogEnabled(InternalLogger.Level.DEBUG)) {
/*      */       this.m_container.getLogger().log(InternalLogger.Level.DEBUG, "Component created: DS={0}, implementation={1}, immediate={2}, default-enabled={3}, factory={4}, configuration-policy={5}, activate={6}, deactivate={7}, modified={8} configuration-pid={9}", null, new Object[] { metadata.getDSVersion(), metadata.getImplementationClassName(), Boolean.valueOf(metadata.isImmediate()), Boolean.valueOf(metadata.isEnabled()), metadata.getFactoryIdentifier(), metadata.getConfigurationPolicy(), metadata.getActivate(), metadata.getDeactivate(), metadata.getModified(), metadata.getConfigurationPid() });
/*      */       if (metadata.getServiceMetadata() != null)
/*      */         this.m_container.getLogger().log(InternalLogger.Level.DEBUG, "Component Services: scope={0}, services={1}", null, new Object[] { metadata.getServiceScope(), Arrays.toString((Object[])metadata.getServiceMetadata().getProvides()) }); 
/*      */       if (metadata.getProperties() != null)
/*      */         this.m_container.getLogger().log(InternalLogger.Level.DEBUG, "Component Properties: {0}", null, new Object[] { metadata.getProperties() }); 
/*  981 */     }  } protected boolean registerService() { String[] services = getProvidedServices();
/*  982 */     if (services != null)
/*      */     {
/*  984 */       return this.registrationManager.changeRegistration(RegistrationManager.RegState.registered, services);
/*      */     }
/*  986 */     return true; }
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean unregisterService() {
/*  991 */     String[] services = getProvidedServices();
/*  992 */     if (services != null)
/*      */     {
/*  994 */       return this.registrationManager.changeRegistration(RegistrationManager.RegState.unregistered, services);
/*      */     }
/*  996 */     return true;
/*      */   }
/*      */ 
/*      */   
/*      */   protected ServiceRegistration<S> getServiceRegistration() {
/* 1001 */     return this.registrationManager.getServiceRegistration();
/*      */   }
/*      */ 
/*      */   
/*      */   AtomicInteger getTrackingCount() {
/* 1006 */     return this.m_trackingCount;
/*      */   }
/*      */ 
/*      */   
/*      */   private void initDependencyManagers(ComponentContextImpl<S> componentContext) {
/* 1011 */     if (this.m_dependencyManagersInitialized) {
/*      */       return;
/*      */     }
/*      */     
/* 1015 */     Bundle bundle = getBundle();
/* 1016 */     if (bundle == null) {
/*      */       
/* 1018 */       this.m_container.getLogger().log(InternalLogger.Level.ERROR, "bundle shut down while trying to load implementation object class", null);
/*      */ 
/*      */       
/* 1021 */       throw new IllegalStateException("bundle shut down while trying to load implementation object class");
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*      */     try {
/* 1027 */       Class<S> implementationObjectClass = bundle.loadClass(
/* 1028 */           getComponentMetadata().getImplementationClassName());
/* 1029 */       this.m_componentMethods.initComponentMethods(getComponentMetadata(), implementationObjectClass, componentContext
/* 1030 */           .getLogger());
/*      */     }
/* 1032 */     catch (ClassNotFoundException e) {
/*      */       
/* 1034 */       this.m_container.getLogger().log(InternalLogger.Level.ERROR, "Could not load implementation object class {0}", e, new Object[] {
/*      */             
/* 1036 */             getComponentMetadata().getImplementationClassName() });
/* 1037 */       throw new IllegalStateException("Could not load implementation object class " + 
/* 1038 */           getComponentMetadata().getImplementationClassName());
/*      */     } 
/*      */     
/* 1041 */     for (DependencyManager<S, ?> dependencyManager : this.m_dependencyManagers)
/*      */     {
/* 1043 */       dependencyManager.initBindingMethods(this.m_componentMethods.getBindMethods(dependencyManager.getName()));
/*      */     }
/* 1045 */     this.m_dependencyManagersInitialized = true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean collectDependencies(ComponentContextImpl<S> componentContext) {
/* 1057 */     initDependencyManagers(componentContext);
/* 1058 */     for (DependencyManager<S, ?> dependencyManager : this.m_dependencyManagers) {
/*      */       
/* 1060 */       if (!dependencyManager.prebind(componentContext)) {
/*      */ 
/*      */         
/* 1063 */         deactivateDependencyManagers();
/* 1064 */         this.m_container.getLogger().log(InternalLogger.Level.DEBUG, "Could not get required dependency for dependency manager: {0}", null, new Object[] { dependencyManager
/*      */               
/* 1066 */               .getName() });
/* 1067 */         return false;
/*      */       } 
/*      */     } 
/* 1070 */     this.m_container.getLogger().log(InternalLogger.Level.DEBUG, "This thread collected dependencies", null);
/*      */     
/* 1072 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void notifyWaiters() {
/* 1090 */     if (this.registrationManager.getServiceRegistration() != null) {
/*      */ 
/*      */       
/* 1093 */       this.m_container.getLogger().log(InternalLogger.Level.DEBUG, "Notifying possible clients that service might be available with activator {0}", null, new Object[] { this.m_container
/*      */ 
/*      */             
/* 1096 */             .getActivator() });
/*      */       
/*      */       try {
/* 1099 */         this.m_container.getActivator().missingServicePresent(((ServiceRegistration)this.registrationManager.getServiceRegistration()).getReference());
/*      */       }
/* 1101 */       catch (IllegalStateException illegalStateException) {}
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ComponentActivator getActivator() {
/* 1112 */     return this.m_container.getActivator();
/*      */   }
/*      */ 
/*      */   
/*      */   synchronized void clear() {
/* 1117 */     this.m_container.getActivator().unregisterComponentId(this);
/*      */   }
/*      */   
/*      */   public ComponentLogger getLogger() {
/* 1121 */     return this.m_container.getLogger();
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public String toString() {
/* 1127 */     return "Component: " + getComponentMetadata().getName() + " (" + getId() + ")";
/*      */   }
/*      */ 
/*      */   
/*      */   private boolean hasServiceRegistrationPermissions() {
/* 1132 */     boolean allowed = true;
/* 1133 */     if (System.getSecurityManager() != null) {
/*      */       
/* 1135 */       ServiceMetadata serviceMetadata = getComponentMetadata().getServiceMetadata();
/* 1136 */       if (serviceMetadata != null) {
/*      */         
/* 1138 */         String[] services = serviceMetadata.getProvides();
/* 1139 */         if (services != null && services.length > 0) {
/*      */           
/* 1141 */           Bundle bundle = getBundle();
/* 1142 */           for (String service : services) {
/*      */             
/* 1144 */             ServicePermission servicePermission = new ServicePermission(service, "register");
/* 1145 */             if (!bundle.hasPermission(servicePermission)) {
/*      */               
/* 1147 */               this.m_container.getLogger().log(InternalLogger.Level.DEBUG, "Permission to register service {0} is denied", null, new Object[] { service });
/*      */ 
/*      */               
/* 1150 */               allowed = false;
/*      */             } 
/*      */           } 
/*      */         } 
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/* 1158 */     return allowed;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private List<DependencyManager<S, ?>> loadDependencyManagers(ComponentMetadata metadata) {
/* 1165 */     if (!metadata.getDependencies().isEmpty()) {
/*      */       
/* 1167 */       List<DependencyManager<S, ?>> depMgrList = new ArrayList<>(metadata.getDependencies().size());
/* 1168 */       int index = 0;
/* 1169 */       for (ReferenceMetadata currentdependency : metadata.getDependencies()) {
/*      */ 
/*      */         
/* 1172 */         DependencyManager<S, ?> depmanager = new DependencyManager<>(this, currentdependency, index++);
/*      */         
/* 1174 */         depMgrList.add(depmanager);
/*      */       } 
/* 1176 */       return depMgrList;
/*      */     } 
/*      */     
/* 1179 */     return Collections.emptyList();
/*      */   }
/*      */ 
/*      */   
/*      */   final void updateTargets(Map<String, Object> properties) {
/* 1184 */     for (DependencyManager<S, ?> dm : getDependencyManagers())
/*      */     {
/* 1186 */       dm.setTargetFilter(properties);
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   protected boolean verifyDependencyManagers() {
/* 1192 */     State previousState = getState();
/*      */     
/* 1194 */     boolean satisfied = true;
/*      */     
/* 1196 */     for (DependencyManager<S, ?> dm : getDependencyManagers()) {
/*      */ 
/*      */       
/* 1199 */       if (!dm.hasGetPermission()) {
/*      */ 
/*      */         
/* 1202 */         if (dm.isOptional()) {
/*      */           
/* 1204 */           this.m_container.getLogger().log(InternalLogger.Level.DEBUG, "No permission to get optional dependency: {0}; assuming satisfied", null, new Object[] { dm
/*      */                 
/* 1206 */                 .getName() });
/*      */           
/*      */           continue;
/*      */         } 
/* 1210 */         this.m_container.getLogger().log(InternalLogger.Level.DEBUG, "No permission to get mandatory dependency: {0}; assuming unsatisfied", null, new Object[] { dm
/*      */               
/* 1212 */               .getName() });
/* 1213 */         satisfied = false;
/*      */         continue;
/*      */       } 
/* 1216 */       if (!dm.isSatisfied()) {
/*      */ 
/*      */         
/* 1219 */         this.m_container.getLogger().log(InternalLogger.Level.DEBUG, "Dependency not satisfied: {0}", null, new Object[] { dm
/* 1220 */               .getName() });
/* 1221 */         satisfied = false;
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 1227 */     if (satisfied != previousState.isSatisfied())
/*      */     {
/* 1229 */       setState(previousState, satisfied ? State.satisfied : State.unsatisfiedReference);
/*      */     }
/* 1231 */     return satisfied;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   List<DependencyManager<S, ?>> getDependencyManagers() {
/* 1240 */     return this.m_dependencyManagers;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public List<? extends ReferenceManager<S, ?>> getReferenceManagers() {
/* 1246 */     return (List)this.m_dependencyManagers;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   List<DependencyManager<S, ?>> getReversedDependencyManagers() {
/* 1255 */     List<DependencyManager<S, ?>> list = new ArrayList<>(this.m_dependencyManagers);
/* 1256 */     Collections.reverse(list);
/* 1257 */     return list;
/*      */   }
/*      */ 
/*      */   
/*      */   DependencyManager<S, ?> getDependencyManager(String name) {
/* 1262 */     for (ReferenceManager<S, ?> dm : getDependencyManagers()) {
/*      */       
/* 1264 */       if (name.equals(dm.getName()))
/*      */       {
/* 1266 */         return (DependencyManager<S, ?>)dm;
/*      */       }
/*      */     } 
/*      */ 
/*      */     
/* 1271 */     return null;
/*      */   }
/*      */ 
/*      */   
/*      */   private void deactivateDependencyManagers() {
/* 1276 */     this.m_container.getLogger().log(InternalLogger.Level.DEBUG, "Deactivating dependency managers", null);
/*      */     
/* 1278 */     for (DependencyManager<S, ?> dm : getDependencyManagers())
/*      */     {
/* 1280 */       dm.deactivate();
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   private void disableDependencyManagers() {
/* 1286 */     this.m_container.getLogger().log(InternalLogger.Level.DEBUG, "Disabling dependency managers", null);
/*      */     
/* 1288 */     AtomicInteger trackingCount = new AtomicInteger();
/* 1289 */     for (DependencyManager<S, ?> dm : getDependencyManagers())
/*      */     {
/* 1291 */       dm.unregisterServiceListener(trackingCount);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Dictionary<String, Object> getServiceProperties() {
/* 1311 */     return copyTo(null, getProperties(), false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected static Dictionary<String, Object> copyTo(Dictionary<String, Object> target, Map<String, ?> source, boolean allProps) {
/* 1336 */     if (target == null)
/*      */     {
/* 1338 */       target = new Hashtable<>();
/*      */     }
/*      */     
/* 1341 */     if (source != null && !source.isEmpty())
/*      */     {
/* 1343 */       for (Map.Entry<String, ?> entry : source.entrySet()) {
/*      */ 
/*      */         
/* 1346 */         String key = entry.getKey();
/* 1347 */         if (allProps || key.charAt(0) != '.')
/*      */         {
/* 1349 */           target.put(key, entry.getValue());
/*      */         }
/*      */       } 
/*      */     }
/*      */     
/* 1354 */     return target;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected static Map<String, Object> copyToMap(Dictionary<String, ?> source, boolean allProps) {
/* 1374 */     Map<String, Object> target = new HashMap<>();
/*      */     
/* 1376 */     if (source != null && !source.isEmpty())
/*      */     {
/* 1378 */       for (Enumeration<String> ce = source.keys(); ce.hasMoreElements(); ) {
/*      */ 
/*      */         
/* 1381 */         String key = ce.nextElement();
/* 1382 */         if (allProps || key.charAt(0) != '.')
/*      */         {
/* 1384 */           target.put(key, source.get(key));
/*      */         }
/*      */       } 
/*      */     }
/*      */     
/* 1389 */     return target;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected static Dictionary<String, Object> copyToDictionary(Dictionary<String, ?> source, boolean allProps) {
/* 1395 */     Hashtable<String, Object> target = new Hashtable<>();
/*      */     
/* 1397 */     if (source != null && !source.isEmpty())
/*      */     {
/* 1399 */       for (Enumeration<String> ce = source.keys(); ce.hasMoreElements(); ) {
/*      */ 
/*      */         
/* 1402 */         String key = ce.nextElement();
/* 1403 */         if (allProps || key.charAt(0) != '.')
/*      */         {
/* 1405 */           target.put(key, source.get(key));
/*      */         }
/*      */       } 
/*      */     }
/*      */     
/* 1410 */     return target;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ComponentMetadata getComponentMetadata() {
/* 1418 */     return this.m_container.getComponentMetadata();
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public int getSpecState() {
/* 1424 */     return getState().getSpecState();
/*      */   }
/*      */ 
/*      */   
/*      */   State getState() {
/* 1429 */     State s = this.state.get();
/* 1430 */     this.m_container.getLogger().log(InternalLogger.Level.DEBUG, "Querying state {0}", null, new Object[] { s });
/* 1431 */     return s;
/*      */   }
/*      */ 
/*      */   
/*      */   public String getFailureReason() {
/* 1436 */     return this.failureReason;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setFailureReason(Throwable e) {
/* 1445 */     StringWriter sw = new StringWriter();
/* 1446 */     PrintWriter pw = new PrintWriter(sw);
/* 1447 */     e.printStackTrace(pw);
/* 1448 */     pw.flush();
/* 1449 */     this.failureReason = sw.toString();
/*      */   }
/*      */ 
/*      */   
/*      */   void setState(State previousState, State newState) {
/* 1454 */     if (this.state.compareAndSet(previousState, newState)) {
/*      */       
/* 1456 */       this.m_container.getLogger().log(InternalLogger.Level.DEBUG, "Changed state from {0} to {1}", null, new Object[] { previousState, newState });
/*      */       
/* 1458 */       if (newState == State.active || newState == State.unsatisfiedReference)
/*      */       {
/* 1460 */         this.failureReason = null;
/*      */       }
/* 1462 */       this.m_container.getActivator().updateChangeCount();
/*      */     }
/*      */     else {
/*      */       
/* 1466 */       this.m_container.getLogger().log(InternalLogger.Level.DEBUG, "Did not change state from {0} to {1}: current state {2}", null, new Object[] { previousState, newState, this.state
/*      */             
/* 1468 */             .get() });
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void setServiceProperties(MethodResult methodResult, Integer trackingCount) {
/* 1475 */     if (methodResult.hasResult()) {
/*      */       
/* 1477 */       if (trackingCount != null)
/*      */       {
/* 1479 */         tracked(trackingCount.intValue());
/*      */       }
/*      */       
/* 1482 */       Dictionary<String, Object> serviceProps = (methodResult.getResult() == null) ? null : new Hashtable<>(methodResult.getResult());
/* 1483 */       setServiceProperties(serviceProps);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ServiceReference<S> getRegisteredServiceReference() {
/* 1498 */     ServiceRegistration<S> reg = this.registrationManager.getServiceRegistration();
/* 1499 */     if (reg != null) {
/*      */       
/*      */       try {
/*      */         
/* 1503 */         return reg.getReference();
/*      */       }
/* 1505 */       catch (IllegalStateException illegalStateException) {}
/*      */     }
/*      */ 
/*      */ 
/*      */     
/* 1510 */     return null;
/*      */   }
/*      */   
/*      */   protected abstract void deleteComponent(int paramInt);
/*      */   
/*      */   abstract <T> boolean invokeUpdatedMethod(DependencyManager<S, T> paramDependencyManager, RefPair<S, T> paramRefPair, int paramInt);
/*      */   
/*      */   abstract <T> void invokeBindMethod(DependencyManager<S, T> paramDependencyManager, RefPair<S, T> paramRefPair, int paramInt);
/*      */   
/*      */   abstract <T> void invokeUnbindMethod(DependencyManager<S, T> paramDependencyManager, RefPair<S, T> paramRefPair, int paramInt);
/*      */   
/*      */   public abstract Map<String, Object> getProperties();
/*      */   
/*      */   public abstract void setServiceProperties(Dictionary<String, ?> paramDictionary);
/*      */   
/*      */   abstract void postRegister();
/*      */   
/*      */   abstract void preDeregister();
/*      */   
/*      */   public abstract void reconfigure(Map<String, Object> paramMap, boolean paramBoolean, TargetedPID paramTargetedPID);
/*      */   
/*      */   public abstract void getComponentManagers(List<AbstractComponentManager<S>> paramList);
/*      */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.apache.felix.scr-2.2.6.jar!\org\apache\felix\scr\impl\manager\AbstractComponentManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */