/*     */ package org.apache.felix.scr.impl.inject.internal;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.apache.felix.scr.impl.inject.ComponentConstructor;
/*     */ import org.apache.felix.scr.impl.inject.ComponentMethods;
/*     */ import org.apache.felix.scr.impl.inject.LifecycleMethod;
/*     */ import org.apache.felix.scr.impl.inject.ReferenceMethods;
/*     */ import org.apache.felix.scr.impl.inject.field.FieldMethods;
/*     */ import org.apache.felix.scr.impl.inject.methods.ActivateMethod;
/*     */ import org.apache.felix.scr.impl.inject.methods.BindMethods;
/*     */ import org.apache.felix.scr.impl.inject.methods.DeactivateMethod;
/*     */ import org.apache.felix.scr.impl.inject.methods.ModifiedMethod;
/*     */ import org.apache.felix.scr.impl.logger.ComponentLogger;
/*     */ import org.apache.felix.scr.impl.metadata.ComponentMetadata;
/*     */ import org.apache.felix.scr.impl.metadata.DSVersion;
/*     */ import org.apache.felix.scr.impl.metadata.ReferenceMetadata;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ComponentMethodsImpl<T>
/*     */   implements ComponentMethods<T>
/*     */ {
/*     */   private LifecycleMethod m_activateMethod;
/*     */   private LifecycleMethod m_modifiedMethod;
/*     */   private LifecycleMethod m_deactivateMethod;
/*     */   private ComponentConstructor<T> m_constructor;
/*  53 */   private final Map<String, ReferenceMethods> bindMethodMap = new HashMap<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized void initComponentMethods(ComponentMetadata componentMetadata, Class<T> implementationObjectClass, ComponentLogger logger) {
/*  62 */     if (this.m_activateMethod != null) {
/*     */       return;
/*     */     }
/*     */ 
/*     */     
/*  67 */     DSVersion dsVersion = componentMetadata.getDSVersion();
/*  68 */     boolean configurableServiceProperties = componentMetadata.isConfigurableServiceProperties();
/*  69 */     boolean supportsInterfaces = componentMetadata.isConfigureWithInterfaces();
/*     */     
/*  71 */     this
/*     */       
/*  73 */       .m_activateMethod = (LifecycleMethod)new ActivateMethod(componentMetadata.getActivate(), componentMetadata.isActivateDeclared(), implementationObjectClass, dsVersion, configurableServiceProperties, supportsInterfaces);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  78 */     this
/*  79 */       .m_deactivateMethod = (LifecycleMethod)new DeactivateMethod(componentMetadata.getDeactivate(), componentMetadata.isDeactivateDeclared(), implementationObjectClass, dsVersion, configurableServiceProperties, supportsInterfaces);
/*     */     
/*  81 */     this.m_modifiedMethod = (LifecycleMethod)new ModifiedMethod(componentMetadata.getModified(), implementationObjectClass, dsVersion, configurableServiceProperties, supportsInterfaces);
/*     */     
/*  83 */     for (ReferenceMetadata referenceMetadata : componentMetadata.getDependencies()) {
/*     */       
/*  85 */       String refName = referenceMetadata.getName();
/*  86 */       List<ReferenceMethods> methods = new ArrayList<>();
/*  87 */       if (referenceMetadata.getField() != null)
/*     */       {
/*  89 */         methods.add(new FieldMethods(referenceMetadata, implementationObjectClass, dsVersion, configurableServiceProperties));
/*     */       }
/*  91 */       if (referenceMetadata.getBind() != null)
/*     */       {
/*  93 */         methods.add(new BindMethods(referenceMetadata, implementationObjectClass, dsVersion, configurableServiceProperties));
/*     */       }
/*     */       
/*  96 */       if (methods.isEmpty()) {
/*     */         
/*  98 */         this.bindMethodMap.put(refName, ReferenceMethods.NOPReferenceMethod); continue;
/*     */       } 
/* 100 */       if (methods.size() == 1) {
/*     */         
/* 102 */         this.bindMethodMap.put(refName, methods.get(0));
/*     */         
/*     */         continue;
/*     */       } 
/* 106 */       this.bindMethodMap.put(refName, new DuplexReferenceMethods(methods));
/*     */     } 
/*     */ 
/*     */     
/* 110 */     this.m_constructor = new ComponentConstructorImpl<>(componentMetadata, implementationObjectClass, logger);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public LifecycleMethod getActivateMethod() {
/* 116 */     return this.m_activateMethod;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public LifecycleMethod getDeactivateMethod() {
/* 122 */     return this.m_deactivateMethod;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public LifecycleMethod getModifiedMethod() {
/* 128 */     return this.m_modifiedMethod;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ReferenceMethods getBindMethods(String refName) {
/* 134 */     return this.bindMethodMap.get(refName);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ComponentConstructor<T> getConstructor() {
/* 140 */     return this.m_constructor;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.apache.felix.scr-2.2.6.jar!\org\apache\felix\scr\impl\inject\internal\ComponentMethodsImpl.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */