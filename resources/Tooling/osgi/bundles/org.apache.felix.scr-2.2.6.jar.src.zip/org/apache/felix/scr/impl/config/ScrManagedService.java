/*    */ package org.apache.felix.scr.impl.config;
/*    */ 
/*    */ import java.util.Dictionary;
/*    */ import org.osgi.service.cm.ConfigurationException;
/*    */ import org.osgi.service.cm.ManagedService;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ScrManagedService
/*    */   implements ManagedService
/*    */ {
/*    */   private final ScrConfigurationImpl scrConfiguration;
/*    */   
/*    */   public ScrManagedService(ScrConfigurationImpl scrConfiguration) {
/* 45 */     this.scrConfiguration = scrConfiguration;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void updated(Dictionary<String, ?> properties) throws ConfigurationException {
/* 51 */     this.scrConfiguration.configure(properties, false);
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.apache.felix.scr-2.2.6.jar!\org\apache\felix\scr\impl\config\ScrManagedService.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */