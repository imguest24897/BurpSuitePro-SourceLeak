/*    */ package org.apache.felix.scr.impl.manager;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.Collections;
/*    */ import java.util.List;
/*    */ import org.osgi.framework.ServiceEvent;
/*    */ import org.osgi.framework.ServiceReference;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ExtendedServiceEvent
/*    */   extends ServiceEvent
/*    */ {
/*    */   private List<AbstractComponentManager<?>> managers;
/*    */   
/*    */   public ExtendedServiceEvent(ServiceEvent source) {
/* 35 */     super(source.getType(), source.getServiceReference());
/*    */   }
/*    */ 
/*    */   
/*    */   public ExtendedServiceEvent(int type, ServiceReference<?> ref) {
/* 40 */     super(type, ref);
/*    */   }
/*    */ 
/*    */   
/*    */   public void addComponentManager(AbstractComponentManager<?> manager) {
/* 45 */     if (this.managers == null)
/* 46 */       this.managers = new ArrayList<>(); 
/* 47 */     this.managers.add(manager);
/*    */   }
/*    */ 
/*    */   
/*    */   public List<AbstractComponentManager<?>> getManagers() {
/* 52 */     return (this.managers == null) ? Collections.<AbstractComponentManager<?>>emptyList() : 
/* 53 */       this.managers;
/*    */   }
/*    */ 
/*    */   
/*    */   public void activateManagers() {
/* 58 */     for (AbstractComponentManager<?> manager : getManagers())
/*    */     {
/* 60 */       manager.activateInternal();
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.apache.felix.scr-2.2.6.jar!\org\apache\felix\scr\impl\manager\ExtendedServiceEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */