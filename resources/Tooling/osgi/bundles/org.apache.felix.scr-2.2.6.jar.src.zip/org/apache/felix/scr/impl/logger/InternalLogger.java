/*    */ package org.apache.felix.scr.impl.logger;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface InternalLogger
/*    */ {
/*    */   void log(Level paramLevel, String paramString, Throwable paramThrowable);
/*    */   
/*    */   void log(Level paramLevel, String paramString, Throwable paramThrowable, Object... paramVarArgs);
/*    */   
/*    */   boolean isLogEnabled(Level paramLevel);
/*    */   
/*    */   public enum Level
/*    */   {
/* 38 */     AUDIT
/*    */     {
/*    */       boolean err()
/*    */       {
/* 42 */         return true;
/*    */       }
/*    */     },
/* 45 */     ERROR
/*    */     {
/*    */       boolean err()
/*    */       {
/* 49 */         return true;
/*    */       }
/*    */     },
/* 52 */     WARN, INFO, DEBUG, TRACE;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */     
/*    */     boolean implies(Level other) {
/* 63 */       return (ordinal() >= other.ordinal());
/*    */     }
/*    */ 
/*    */     
/*    */     boolean err() {
/* 68 */       return false;
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.apache.felix.scr-2.2.6.jar!\org\apache\felix\scr\impl\logger\InternalLogger.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */