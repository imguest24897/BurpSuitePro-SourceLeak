package org.apache.felix.scr.impl.manager;

import org.apache.felix.scr.impl.logger.LogConfiguration;

public interface ScrConfiguration extends LogConfiguration {
  public static final String PID = "org.apache.felix.scr.ScrService";
  
  public static final String PROP_FACTORY_ENABLED = "ds.factory.enabled";
  
  public static final String PROP_DELAYED_KEEP_INSTANCES = "ds.delayed.keepInstances";
  
  public static final String PROP_INFO_SERVICE = "ds.info.service";
  
  public static final String PROP_LOCK_TIMEOUT = "ds.lock.timeout.milliseconds";
  
  public static final String PROP_STOP_TIMEOUT = "ds.stop.timeout.milliseconds";
  
  public static final long DEFAULT_LOCK_TIMEOUT_MILLISECONDS = 5000L;
  
  public static final long DEFAULT_SERVICE_CHANGECOUNT_TIMEOUT_MILLISECONDS = 5000L;
  
  public static final long DEFAULT_STOP_TIMEOUT_MILLISECONDS = 60000L;
  
  public static final String PROP_GLOBAL_EXTENDER = "ds.global.extender";
  
  public static final String PROP_SERVICE_CHANGECOUNT_TIMEOUT = "ds.service.changecount.timeout";
  
  public static final String PROP_CACHE_METADATA = "ds.cache.metadata";
  
  boolean isFactoryEnabled();
  
  boolean keepInstances();
  
  @Deprecated
  boolean infoAsService();
  
  long lockTimeout();
  
  long stopTimeout();
  
  boolean globalExtender();
  
  long serviceChangecountTimeout();
  
  boolean cacheMetadata();
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.apache.felix.scr-2.2.6.jar!\org\apache\felix\scr\impl\manager\ScrConfiguration.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */