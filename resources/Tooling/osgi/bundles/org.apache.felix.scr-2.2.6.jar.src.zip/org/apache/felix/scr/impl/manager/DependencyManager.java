/*      */ package org.apache.felix.scr.impl.manager;
/*      */ 
/*      */ import java.util.ArrayList;
/*      */ import java.util.Collection;
/*      */ import java.util.Collections;
/*      */ import java.util.Iterator;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.SortedMap;
/*      */ import java.util.TreeMap;
/*      */ import java.util.concurrent.CountDownLatch;
/*      */ import java.util.concurrent.atomic.AtomicInteger;
/*      */ import java.util.concurrent.atomic.AtomicReference;
/*      */ import org.apache.felix.scr.impl.helper.Coercions;
/*      */ import org.apache.felix.scr.impl.inject.BindParameters;
/*      */ import org.apache.felix.scr.impl.inject.MethodResult;
/*      */ import org.apache.felix.scr.impl.inject.OpenStatus;
/*      */ import org.apache.felix.scr.impl.inject.RefPair;
/*      */ import org.apache.felix.scr.impl.inject.ReferenceMethod;
/*      */ import org.apache.felix.scr.impl.inject.ReferenceMethods;
/*      */ import org.apache.felix.scr.impl.logger.InternalLogger;
/*      */ import org.apache.felix.scr.impl.metadata.ReferenceMetadata;
/*      */ import org.apache.felix.scr.impl.metadata.ServiceMetadata;
/*      */ import org.osgi.framework.BundleContext;
/*      */ import org.osgi.framework.InvalidSyntaxException;
/*      */ import org.osgi.framework.ServiceEvent;
/*      */ import org.osgi.framework.ServicePermission;
/*      */ import org.osgi.framework.ServiceReference;
/*      */ import org.osgi.service.component.ComponentException;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class DependencyManager<S, T>
/*      */   implements ReferenceManager<S, T>
/*      */ {
/*      */   public static final String ANY_SERVICE_CLASS = "org.osgi.service.component.AnyService";
/*      */   public static final String NEVER_SATIFIED_FILTER = "(&(invalid.target.cannot.resolve=*)(!(invalid.target.cannot.resolve=*)))";
/*      */   private final AbstractComponentManager<S> m_componentManager;
/*      */   private final ReferenceMetadata m_dependencyMetadata;
/*      */   private final int m_index;
/*      */   private final Customizer<S, T> m_customizer;
/*      */   private volatile ReferenceMethods m_bindMethods;
/*      */   private volatile ServiceTracker<T, RefPair<S, T>, ExtendedServiceEvent> m_tracker;
/*      */   private volatile String m_target;
/*      */   private volatile int m_minCardinality;
/*      */   private static final String OBJECTCLASS_CLAUSE = "(objectClass=";
/*      */   private static final String PROTOTYPE_SCOPE_CLAUSE = "(service.scope=prototype)";
/*      */   
/*      */   DependencyManager(AbstractComponentManager<S> componentManager, ReferenceMetadata dependency, int index) {
/*   93 */     this.m_componentManager = componentManager;
/*   94 */     this.m_dependencyMetadata = dependency;
/*   95 */     this.m_index = index;
/*   96 */     this.m_customizer = newCustomizer();
/*      */     
/*   98 */     this.m_minCardinality = defaultMinimumCardinality(dependency);
/*      */ 
/*      */     
/*  101 */     if (this.m_componentManager.getLogger().isLogEnabled(InternalLogger.Level.DEBUG))
/*      */     {
/*  103 */       this.m_componentManager.getLogger().log(InternalLogger.Level.DEBUG, "Dependency Manager created {0}", null, new Object[] { dependency
/*      */             
/*  105 */             .getDebugInfo() });
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   private static int defaultMinimumCardinality(ReferenceMetadata dependency) {
/*  111 */     return dependency.isOptional() ? 0 : 1;
/*      */   }
/*      */ 
/*      */   
/*      */   int getIndex() {
/*  116 */     return this.m_index;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void initBindingMethods(ReferenceMethods bindMethods) {
/*  124 */     this.m_bindMethods = bindMethods;
/*      */   }
/*      */ 
/*      */   
/*      */   private static interface Customizer<S, T>
/*      */     extends ServiceTrackerCustomizer<T, RefPair<S, T>, ExtendedServiceEvent>
/*      */   {
/*      */     boolean prebind(ComponentContextImpl<S> param1ComponentContextImpl);
/*      */ 
/*      */     
/*      */     void close();
/*      */ 
/*      */     
/*      */     Collection<RefPair<S, T>> getRefs(AtomicInteger param1AtomicInteger);
/*      */ 
/*      */     
/*      */     boolean isSatisfied();
/*      */     
/*      */     void setTracker(ServiceTracker<T, RefPair<S, T>, ExtendedServiceEvent> param1ServiceTracker);
/*      */     
/*      */     void setTrackerOpened();
/*      */     
/*      */     void setPreviousRefMap(Map<ServiceReference<T>, RefPair<S, T>> param1Map);
/*      */   }
/*      */   
/*      */   private abstract class AbstractCustomizer
/*      */     implements Customizer<S, T>
/*      */   {
/*  152 */     private final Map<ServiceReference<T>, RefPair<S, T>> EMPTY_REF_MAP = Collections.emptyMap();
/*      */     
/*      */     private volatile boolean trackerOpened;
/*      */     
/*  156 */     private volatile Map<ServiceReference<T>, RefPair<S, T>> previousRefMap = this.EMPTY_REF_MAP;
/*      */ 
/*      */ 
/*      */     
/*      */     public void setTracker(ServiceTracker<T, RefPair<S, T>, ExtendedServiceEvent> tracker) {
/*  161 */       DependencyManager.this.m_tracker = tracker;
/*  162 */       DependencyManager.this.m_componentManager.getLogger().log(InternalLogger.Level.DEBUG, "dm {0} tracker reset (closed)", null, new Object[] { this.this$0
/*  163 */             .getName() });
/*  164 */       this.trackerOpened = false;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public boolean isSatisfied() {
/*  170 */       return DependencyManager.this.cardinalitySatisfied();
/*      */     }
/*      */ 
/*      */     
/*      */     protected ServiceTracker<T, RefPair<S, T>, ExtendedServiceEvent> getTracker() {
/*  175 */       return DependencyManager.this.m_tracker;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     protected boolean isActive() {
/*  184 */       ServiceTracker<T, RefPair<S, T>, ExtendedServiceEvent> tracker = getTracker();
/*  185 */       return (tracker != null && tracker.isActive());
/*      */     }
/*      */ 
/*      */     
/*      */     protected boolean isTrackerOpened() {
/*  190 */       return this.trackerOpened;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public void setTrackerOpened() {
/*  196 */       this.trackerOpened = true;
/*  197 */       DependencyManager.this.m_componentManager.getLogger().log(InternalLogger.Level.DEBUG, "dm {0} tracker opened", null, new Object[] { this.this$0
/*  198 */             .getName() });
/*      */     }
/*      */ 
/*      */     
/*      */     protected void deactivateTracker() {
/*  203 */       ServiceTracker<T, RefPair<S, T>, ExtendedServiceEvent> tracker = getTracker();
/*  204 */       if (tracker != null)
/*      */       {
/*  206 */         tracker.deactivate();
/*      */       }
/*      */     }
/*      */ 
/*      */     
/*      */     protected Map<ServiceReference<T>, RefPair<S, T>> getPreviousRefMap() {
/*  212 */       return this.previousRefMap;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public void setPreviousRefMap(Map<ServiceReference<T>, RefPair<S, T>> previousRefMap) {
/*  218 */       if (previousRefMap != null) {
/*      */         
/*  220 */         this.previousRefMap = previousRefMap;
/*      */       }
/*      */       else {
/*      */         
/*  224 */         this.previousRefMap = this.EMPTY_REF_MAP;
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     protected void ungetService(RefPair<S, T> ref) {
/*  231 */       ref.ungetServiceObjects(DependencyManager.this.m_componentManager.getBundleContext());
/*      */     }
/*      */ 
/*      */     
/*      */     protected void tracked(int trackingCount) {
/*  236 */       DependencyManager.this.m_componentManager.tracked(trackingCount);
/*      */     }
/*      */     
/*      */     private AbstractCustomizer() {}
/*      */   }
/*      */   
/*      */   private class FactoryCustomizer
/*      */     extends AbstractCustomizer {
/*      */     private FactoryCustomizer() {}
/*      */     
/*      */     public RefPair<S, T> addingService(ServiceReference<T> serviceReference) {
/*  247 */       RefPair<S, T> refPair = DependencyManager.this.newRefPair(serviceReference);
/*  248 */       return refPair;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void addedService(ServiceReference<T> serviceReference, RefPair<S, T> refPair, int trackingCount, int serviceCount, ExtendedServiceEvent event) {
/*  255 */       if (DependencyManager.this.cardinalityJustSatisfied(serviceCount))
/*      */       {
/*  257 */         DependencyManager.this.m_componentManager.activateInternal();
/*      */       }
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void modifiedService(ServiceReference<T> serviceReference, RefPair<S, T> refPair, int trackingCount, ExtendedServiceEvent event) {}
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void removedService(ServiceReference<T> serviceReference, RefPair<S, T> refPair, int trackingCount, ExtendedServiceEvent event) {
/*  271 */       refPair.markDeleted();
/*  272 */       if (!DependencyManager.this.cardinalitySatisfied())
/*      */       {
/*  274 */         DependencyManager.this.deactivateComponentManager();
/*      */       }
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public boolean prebind(ComponentContextImpl<S> key) {
/*  281 */       ServiceTracker<T, RefPair<S, T>, ExtendedServiceEvent> tracker = getTracker();
/*  282 */       if (tracker == null)
/*      */       {
/*  284 */         return false;
/*      */       }
/*  286 */       AtomicInteger trackingCount = new AtomicInteger();
/*  287 */       int serviceCount = tracker.getTracked(Boolean.valueOf(true), trackingCount).size();
/*  288 */       return DependencyManager.this.cardinalitySatisfied(serviceCount);
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public void close() {
/*  294 */       deactivateTracker();
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public Collection<RefPair<S, T>> getRefs(AtomicInteger trackingCount) {
/*  300 */       return Collections.emptyList();
/*      */     }
/*      */   }
/*      */   
/*      */   private class MultipleDynamicCustomizer
/*      */     extends AbstractCustomizer
/*      */   {
/*      */     private RefPair<S, T> lastRefPair;
/*      */     private int lastRefPairTrackingCount;
/*      */     
/*      */     private MultipleDynamicCustomizer() {}
/*      */     
/*      */     public RefPair<S, T> addingService(ServiceReference<T> serviceReference) {
/*  313 */       RefPair<S, T> refPair = getPreviousRefMap().get(serviceReference);
/*  314 */       if (refPair == null)
/*      */       {
/*  316 */         refPair = DependencyManager.this.newRefPair(serviceReference);
/*      */       }
/*  318 */       return refPair;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void addedService(ServiceReference<T> serviceReference, RefPair<S, T> refPair, int trackingCount, int serviceCount, ExtendedServiceEvent event) {
/*  325 */       DependencyManager.this.m_componentManager.getLogger().log(InternalLogger.Level.DEBUG, "dm {0} tracking {1} MultipleDynamic added {2} (enter)", null, new Object[] { this.this$0
/*      */             
/*  327 */             .getName(), Integer.valueOf(trackingCount), serviceReference });
/*  328 */       boolean tracked = false;
/*  329 */       if (getPreviousRefMap().remove(serviceReference) == null)
/*      */       {
/*  331 */         if (isActive()) {
/*      */           
/*  333 */           DependencyManager.this.m_componentManager.getLogger().log(InternalLogger.Level.DEBUG, "dm {0} tracking {1} MultipleDynamic already active, binding {2}", null, new Object[] { this.this$0
/*      */                 
/*  335 */                 .getName(), Integer.valueOf(trackingCount), serviceReference });
/*  336 */           DependencyManager.this.m_componentManager.invokeBindMethod(DependencyManager.this, refPair, trackingCount);
/*  337 */           if (refPair.isFailed())
/*      */           {
/*  339 */             DependencyManager.this.m_componentManager.registerMissingDependency(DependencyManager.this, serviceReference, trackingCount);
/*      */           
/*      */           }
/*      */         }
/*  343 */         else if (isTrackerOpened() && DependencyManager.this.cardinalityJustSatisfied(serviceCount)) {
/*      */           
/*  345 */           DependencyManager.this.m_componentManager.getLogger().log(InternalLogger.Level.DEBUG, "dm {0} tracking {1} MultipleDynamic, activating", null, new Object[] { this.this$0
/*      */                 
/*  347 */                 .getName(), Integer.valueOf(trackingCount) });
/*  348 */           tracked(trackingCount);
/*  349 */           tracked = true;
/*  350 */           DependencyManager.this.m_componentManager.activateInternal();
/*      */         }
/*      */         else {
/*      */           
/*  354 */           DependencyManager.this.m_componentManager.getLogger().log(InternalLogger.Level.DEBUG, "dm {0} tracking {1} MultipleDynamic, inactive, doing nothing: tracker opened: {2}, optional: {3}", null, new Object[] { this.this$0
/*      */                 
/*  356 */                 .getName(), Integer.valueOf(trackingCount), Boolean.valueOf(isTrackerOpened()), Boolean.valueOf(this.this$0.isOptional()) });
/*      */         } 
/*      */       }
/*  359 */       DependencyManager.this.m_componentManager.getLogger().log(InternalLogger.Level.DEBUG, "dm {0} tracking {1} MultipleDynamic added {2} (exit)", null, new Object[] { this.this$0
/*      */             
/*  361 */             .getName(), Integer.valueOf(trackingCount), serviceReference });
/*  362 */       if (!tracked)
/*      */       {
/*  364 */         tracked(trackingCount);
/*      */       }
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void modifiedService(ServiceReference<T> serviceReference, RefPair<S, T> refPair, int trackingCount, ExtendedServiceEvent event) {
/*  372 */       DependencyManager.this.m_componentManager.getLogger().log(InternalLogger.Level.DEBUG, "dm {0} tracking {1} MultipleDynamic modified {2} (enter)", null, new Object[] { this.this$0
/*      */             
/*  374 */             .getName(), Integer.valueOf(trackingCount), serviceReference });
/*  375 */       if (isActive())
/*      */       {
/*  377 */         DependencyManager.this.m_componentManager.invokeUpdatedMethod(DependencyManager.this, refPair, trackingCount);
/*      */       }
/*  379 */       DependencyManager.this.m_componentManager.getLogger().log(InternalLogger.Level.DEBUG, "dm {0} tracking {1} MultipleDynamic modified {2} (exit)", null, new Object[] { this.this$0
/*      */             
/*  381 */             .getName(), Integer.valueOf(trackingCount), serviceReference });
/*  382 */       tracked(trackingCount);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void removedService(ServiceReference<T> serviceReference, RefPair<S, T> refPair, int trackingCount, ExtendedServiceEvent event) {
/*  389 */       DependencyManager.this.m_componentManager.getLogger().log(InternalLogger.Level.DEBUG, "dm {0} tracking {1} MultipleDynamic removed {2} (enter)", null, new Object[] { this.this$0
/*      */             
/*  391 */             .getName(), Integer.valueOf(trackingCount), serviceReference });
/*  392 */       refPair.markDeleted();
/*  393 */       boolean unbind = DependencyManager.this.cardinalitySatisfied();
/*  394 */       if (unbind) {
/*      */         
/*  396 */         if (isActive())
/*      */         {
/*  398 */           DependencyManager.this.m_componentManager.invokeUnbindMethod(DependencyManager.this, refPair, trackingCount);
/*      */         }
/*  400 */         DependencyManager.this.m_componentManager.getLogger().log(InternalLogger.Level.DEBUG, "dm {0} tracking {1} MultipleDynamic removed (unbind) {2}", null, new Object[] { this.this$0
/*      */               
/*  402 */               .getName(), Integer.valueOf(trackingCount), serviceReference });
/*  403 */         tracked(trackingCount);
/*      */       }
/*      */       else {
/*      */         
/*  407 */         this.lastRefPair = refPair;
/*  408 */         this.lastRefPairTrackingCount = trackingCount;
/*  409 */         tracked(trackingCount);
/*  410 */         DependencyManager.this.deactivateComponentManager();
/*  411 */         this.lastRefPair = null;
/*  412 */         DependencyManager.this.m_componentManager.getLogger().log(InternalLogger.Level.DEBUG, "dm {0} tracking {1} MultipleDynamic removed (deactivate) {2}", null, new Object[] { this.this$0
/*      */               
/*  414 */               .getName(), Integer.valueOf(trackingCount), serviceReference });
/*      */       } 
/*  416 */       ungetService(refPair);
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public boolean prebind(ComponentContextImpl<S> key) {
/*  422 */       ServiceTracker<T, RefPair<S, T>, ExtendedServiceEvent> tracker = getTracker();
/*  423 */       if (tracker == null)
/*      */       {
/*  425 */         return false;
/*      */       }
/*  427 */       int serviceCount = 0;
/*  428 */       AtomicInteger trackingCount = new AtomicInteger();
/*  429 */       SortedMap<ServiceReference<T>, RefPair<S, T>> tracked = tracker.getTracked(
/*  430 */           Boolean.valueOf(true), trackingCount);
/*  431 */       List<RefPair<S, T>> failed = new ArrayList<>();
/*  432 */       for (RefPair<S, T> refPair : tracked.values()) {
/*      */         
/*  434 */         if (DependencyManager.this.getServiceObject(key, DependencyManager.this.m_bindMethods.getBind(), refPair)) {
/*      */           
/*  436 */           serviceCount++;
/*      */           
/*      */           continue;
/*      */         } 
/*  440 */         failed.add(refPair);
/*      */       } 
/*      */       
/*  443 */       if (DependencyManager.this.cardinalitySatisfied(serviceCount)) {
/*      */         
/*  445 */         for (RefPair<S, T> refPair : failed)
/*      */         {
/*  447 */           DependencyManager.this.m_componentManager.registerMissingDependency(DependencyManager.this, refPair.getRef(), trackingCount
/*  448 */               .get());
/*      */         }
/*  450 */         return true;
/*      */       } 
/*  452 */       return false;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public void close() {
/*  458 */       AtomicInteger trackingCount = new AtomicInteger();
/*  459 */       for (RefPair<S, T> ref : getRefs(trackingCount))
/*      */       {
/*  461 */         ungetService(ref);
/*      */       }
/*  463 */       deactivateTracker();
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public Collection<RefPair<S, T>> getRefs(AtomicInteger trackingCount) {
/*  469 */       if (this.lastRefPair == null) {
/*      */         
/*  471 */         ServiceTracker<T, RefPair<S, T>, ExtendedServiceEvent> tracker = getTracker();
/*  472 */         if (tracker == null) {
/*      */           
/*  474 */           trackingCount.set(this.lastRefPairTrackingCount);
/*  475 */           return Collections.emptyList();
/*      */         } 
/*  477 */         return tracker.getTracked(null, trackingCount).values();
/*      */       } 
/*      */ 
/*      */       
/*  481 */       trackingCount.set(this.lastRefPairTrackingCount);
/*  482 */       return Collections.singletonList(this.lastRefPair);
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   private class MultipleStaticGreedyCustomizer
/*      */     extends AbstractCustomizer
/*      */   {
/*      */     private MultipleStaticGreedyCustomizer() {}
/*      */     
/*      */     public RefPair<S, T> addingService(ServiceReference<T> serviceReference) {
/*  493 */       RefPair<S, T> refPair = DependencyManager.this.newRefPair(serviceReference);
/*  494 */       return refPair;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void addedService(ServiceReference<T> serviceReference, RefPair<S, T> refPair, int trackingCount, int serviceCount, ExtendedServiceEvent event) {
/*  501 */       DependencyManager.this.m_componentManager.getLogger().log(InternalLogger.Level.DEBUG, "dm {0} tracking {1} MultipleStaticGreedy added {2} (enter)", null, new Object[] { this.this$0
/*      */             
/*  503 */             .getName(), Integer.valueOf(trackingCount), serviceReference });
/*  504 */       tracked(trackingCount);
/*  505 */       if (isActive()) {
/*      */         
/*  507 */         DependencyManager.this.m_componentManager.getLogger().log(InternalLogger.Level.DEBUG, "Dependency Manager: Static dependency on {0}/{1} is broken", null, new Object[] { this.this$0
/*      */               
/*  509 */               .getName(), DependencyManager.access$600(this.this$0).getInterface() });
/*  510 */         DependencyManager.this.deactivateComponentManager();
/*      */         
/*  512 */         if (event != null)
/*      */         {
/*  514 */           event.addComponentManager(DependencyManager.this.m_componentManager);
/*      */         
/*      */         }
/*      */       }
/*  518 */       else if (isTrackerOpened() && DependencyManager.this.cardinalityJustSatisfied(serviceCount)) {
/*      */         
/*  520 */         DependencyManager.this.m_componentManager.activateInternal();
/*      */       } 
/*  522 */       DependencyManager.this.m_componentManager.getLogger().log(InternalLogger.Level.DEBUG, "dm {0} tracking {1} MultipleStaticGreedy added {2} (exit)", null, new Object[] { this.this$0
/*      */             
/*  524 */             .getName(), Integer.valueOf(trackingCount), serviceReference });
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void modifiedService(ServiceReference<T> serviceReference, RefPair<S, T> refPair, int trackingCount, ExtendedServiceEvent event) {
/*  531 */       DependencyManager.this.m_componentManager.getLogger().log(InternalLogger.Level.DEBUG, "dm {0} tracking {1} MultipleStaticGreedy modified {2} (enter)", null, new Object[] { this.this$0
/*      */             
/*  533 */             .getName(), Integer.valueOf(trackingCount), serviceReference });
/*  534 */       boolean reactivate = false;
/*  535 */       if (isActive())
/*      */       {
/*  537 */         reactivate = DependencyManager.this.m_componentManager.invokeUpdatedMethod(DependencyManager.this, refPair, trackingCount);
/*      */       }
/*  539 */       tracked(trackingCount);
/*  540 */       if (reactivate) {
/*      */         
/*  542 */         DependencyManager.this.deactivateComponentManager();
/*  543 */         if (event != null)
/*      */         {
/*  545 */           event.addComponentManager(DependencyManager.this.m_componentManager);
/*      */         }
/*      */       } 
/*  548 */       DependencyManager.this.m_componentManager.getLogger().log(InternalLogger.Level.DEBUG, "dm {0} tracking {1} MultipleStaticGreedy modified {2} (exit)", null, new Object[] { this.this$0
/*      */             
/*  550 */             .getName(), Integer.valueOf(trackingCount), serviceReference });
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void removedService(ServiceReference<T> serviceReference, RefPair<S, T> refPair, int trackingCount, ExtendedServiceEvent event) {
/*  557 */       DependencyManager.this.m_componentManager.getLogger().log(InternalLogger.Level.DEBUG, "dm {0} tracking {1} MultipleStaticGreedy removed {2} (enter)", null, new Object[] { this.this$0
/*      */             
/*  559 */             .getName(), Integer.valueOf(trackingCount), serviceReference });
/*  560 */       refPair.markDeleted();
/*  561 */       tracked(trackingCount);
/*  562 */       if (isActive()) {
/*      */ 
/*      */         
/*  565 */         DependencyManager.this.m_componentManager.getLogger().log(InternalLogger.Level.DEBUG, "Dependency Manager: Static dependency on {0}/{1} is broken", null, new Object[] { this.this$0
/*      */               
/*  567 */               .getName(), DependencyManager.access$600(this.this$0).getInterface() });
/*  568 */         DependencyManager.this.deactivateComponentManager();
/*      */         
/*  570 */         if (event != null)
/*      */         {
/*  572 */           event.addComponentManager(DependencyManager.this.m_componentManager);
/*      */         }
/*      */       }
/*  575 */       else if (!DependencyManager.this.cardinalitySatisfied()) {
/*      */         
/*  577 */         DependencyManager.this.m_componentManager.getLogger().log(InternalLogger.Level.DEBUG, "Dependency Manager: Static dependency on {0}/{1} is broken", null, new Object[] { this.this$0
/*      */               
/*  579 */               .getName(), DependencyManager.access$600(this.this$0).getInterface() });
/*  580 */         DependencyManager.this.deactivateComponentManager();
/*      */       } 
/*      */       
/*  583 */       ungetService(refPair);
/*  584 */       DependencyManager.this.m_componentManager.getLogger().log(InternalLogger.Level.DEBUG, "dm {0} tracking {1} MultipleStaticGreedy removed {2} (exit)", null, new Object[] { this.this$0
/*      */             
/*  586 */             .getName(), Integer.valueOf(trackingCount), serviceReference });
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public boolean prebind(ComponentContextImpl<S> key) {
/*  592 */       ServiceTracker<T, RefPair<S, T>, ExtendedServiceEvent> tracker = getTracker();
/*  593 */       if (tracker == null)
/*      */       {
/*  595 */         return false;
/*      */       }
/*  597 */       int serviceCount = 0;
/*  598 */       AtomicInteger trackingCount = new AtomicInteger();
/*  599 */       SortedMap<ServiceReference<T>, RefPair<S, T>> tracked = tracker.getTracked(
/*  600 */           Boolean.valueOf(DependencyManager.this.cardinalitySatisfied(tracker.getServiceCount())), trackingCount);
/*  601 */       for (RefPair<S, T> refPair : tracked.values()) {
/*      */         
/*  603 */         if (DependencyManager.this.getServiceObject(key, DependencyManager.this.m_bindMethods.getBind(), refPair))
/*      */         {
/*  605 */           serviceCount++;
/*      */         }
/*      */       } 
/*  608 */       return DependencyManager.this.cardinalitySatisfied(serviceCount);
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public void close() {
/*  614 */       AtomicInteger trackingCount = new AtomicInteger();
/*  615 */       for (RefPair<S, T> ref : getRefs(trackingCount))
/*      */       {
/*  617 */         ungetService(ref);
/*      */       }
/*  619 */       deactivateTracker();
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public Collection<RefPair<S, T>> getRefs(AtomicInteger trackingCount) {
/*  625 */       ServiceTracker<T, RefPair<S, T>, ExtendedServiceEvent> tracker = getTracker();
/*  626 */       if (tracker == null)
/*      */       {
/*  628 */         return Collections.emptyList();
/*      */       }
/*  630 */       return tracker.getTracked(null, trackingCount).values();
/*      */     } }
/*      */   
/*      */   private class MultipleStaticReluctantCustomizer extends AbstractCustomizer {
/*      */     private final AtomicReference<Collection<RefPair<S, T>>> refs;
/*      */     
/*      */     private MultipleStaticReluctantCustomizer() {
/*  637 */       this.refs = new AtomicReference<>();
/*      */     }
/*      */     
/*      */     private int trackingCount;
/*      */     
/*      */     public RefPair<S, T> addingService(ServiceReference<T> serviceReference) {
/*  643 */       RefPair<S, T> refPair = DependencyManager.this.newRefPair(serviceReference);
/*  644 */       return refPair;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void addedService(ServiceReference<T> serviceReference, RefPair<S, T> refPair, int trackingCount, int serviceCount, ExtendedServiceEvent event) {
/*  651 */       DependencyManager.this.m_componentManager.getLogger().log(InternalLogger.Level.DEBUG, "dm {0} tracking {1} MultipleStaticReluctant added {2} (enter)", null, new Object[] { this.this$0
/*      */             
/*  653 */             .getName(), Integer.valueOf(trackingCount), serviceReference });
/*  654 */       tracked(trackingCount);
/*  655 */       if (isTrackerOpened() && DependencyManager.this.cardinalityJustSatisfied(serviceCount) && !isActive())
/*      */       {
/*  657 */         DependencyManager.this.m_componentManager.activateInternal();
/*      */       }
/*  659 */       DependencyManager.this.m_componentManager.getLogger().log(InternalLogger.Level.DEBUG, "dm {0} tracking {1} MultipleStaticReluctant added {2} (exit)", null, new Object[] { this.this$0
/*      */             
/*  661 */             .getName(), Integer.valueOf(trackingCount), serviceReference });
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void modifiedService(ServiceReference<T> serviceReference, RefPair<S, T> refPair, int trackingCount, ExtendedServiceEvent event) {
/*  668 */       DependencyManager.this.m_componentManager.getLogger().log(InternalLogger.Level.DEBUG, "dm {0} tracking {1} MultipleStaticReluctant modified {2} (enter)", null, new Object[] { this.this$0
/*      */             
/*  670 */             .getName(), Integer.valueOf(trackingCount), serviceReference });
/*  671 */       boolean reactivate = false;
/*  672 */       Collection<RefPair<S, T>> refs = this.refs.get();
/*  673 */       if (isActive() && refs != null && refs.contains(refPair))
/*      */       {
/*  675 */         reactivate = DependencyManager.this.m_componentManager.invokeUpdatedMethod(DependencyManager.this, refPair, trackingCount);
/*      */       }
/*  677 */       tracked(trackingCount);
/*  678 */       if (reactivate) {
/*      */         
/*  680 */         DependencyManager.this.deactivateComponentManager();
/*  681 */         if (event != null)
/*      */         {
/*  683 */           event.addComponentManager(DependencyManager.this.m_componentManager);
/*      */         }
/*      */       } 
/*  686 */       DependencyManager.this.m_componentManager.getLogger().log(InternalLogger.Level.DEBUG, "dm {0} tracking {1} MultipleStaticReluctant modified {2} (exit)", null, new Object[] { this.this$0
/*      */             
/*  688 */             .getName(), Integer.valueOf(trackingCount), serviceReference });
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void removedService(ServiceReference<T> serviceReference, RefPair<S, T> refPair, int trackingCount, ExtendedServiceEvent event) {
/*  695 */       DependencyManager.this.m_componentManager.getLogger().log(InternalLogger.Level.DEBUG, "dm {0} tracking {1} MultipleStaticReluctant removed {2} (enter)", null, new Object[] { this.this$0
/*      */             
/*  697 */             .getName(), Integer.valueOf(trackingCount), serviceReference });
/*  698 */       refPair.markDeleted();
/*  699 */       tracked(trackingCount);
/*  700 */       Collection<RefPair<S, T>> refs = this.refs.get();
/*  701 */       if (isActive() && refs != null) {
/*      */         
/*  703 */         if (refs.contains(refPair))
/*      */         {
/*      */           
/*  706 */           DependencyManager.this.m_componentManager.getLogger().log(InternalLogger.Level.DEBUG, "Dependency Manager: Static dependency on {0}/{1} is broken", null, new Object[] { this.this$0
/*      */                 
/*  708 */                 .getName(), DependencyManager.access$600(this.this$0).getInterface() });
/*  709 */           DependencyManager.this.deactivateComponentManager();
/*      */ 
/*      */           
/*  712 */           if (event != null)
/*      */           {
/*  714 */             event.addComponentManager(DependencyManager.this.m_componentManager);
/*      */           }
/*      */         }
/*      */       
/*      */       }
/*  719 */       else if (!DependencyManager.this.cardinalitySatisfied()) {
/*      */         
/*  721 */         DependencyManager.this.m_componentManager.getLogger().log(InternalLogger.Level.DEBUG, "Dependency Manager: Static dependency on {0}/{1} is broken", null, new Object[] { this.this$0
/*      */               
/*  723 */               .getName(), DependencyManager.access$600(this.this$0).getInterface() });
/*  724 */         DependencyManager.this.deactivateComponentManager();
/*      */       } 
/*  726 */       ungetService(refPair);
/*  727 */       DependencyManager.this.m_componentManager.getLogger().log(InternalLogger.Level.DEBUG, "dm {0} tracking {1} MultipleStaticReluctant removed {2} (exit)", null, new Object[] { this.this$0
/*      */             
/*  729 */             .getName(), Integer.valueOf(trackingCount), serviceReference });
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean prebind(ComponentContextImpl<S> key) {
/*      */       Map<ServiceReference<T>, RefPair<S, T>> tracked;
/*  735 */       int serviceCount = 0;
/*  736 */       Collection<RefPair<S, T>> refs = this.refs.get();
/*  737 */       if (refs != null) {
/*      */ 
/*      */         
/*  740 */         for (RefPair<S, T> refPair : refs) {
/*      */           
/*  742 */           if (DependencyManager.this.getServiceObject(key, DependencyManager.this.m_bindMethods.getBind(), refPair))
/*      */           {
/*  744 */             serviceCount++;
/*      */           }
/*      */         } 
/*  747 */         return DependencyManager.this.cardinalitySatisfied(serviceCount);
/*      */       } 
/*  749 */       refs = new ArrayList<>();
/*  750 */       AtomicInteger trackingCount = new AtomicInteger();
/*  751 */       ServiceTracker<T, RefPair<S, T>, ExtendedServiceEvent> tracker = getTracker();
/*      */       
/*  753 */       if (tracker == null) {
/*      */         
/*  755 */         tracked = Collections.emptyMap();
/*      */       }
/*      */       else {
/*      */         
/*  759 */         tracked = tracker.getTracked(Boolean.valueOf(true), trackingCount);
/*      */       } 
/*  761 */       for (RefPair<S, T> refPair : tracked.values()) {
/*      */         
/*  763 */         if (DependencyManager.this.getServiceObject(key, DependencyManager.this.m_bindMethods.getBind(), refPair))
/*      */         {
/*  765 */           serviceCount++;
/*      */         }
/*  767 */         refs.add(refPair);
/*      */       } 
/*  769 */       if (this.refs.compareAndSet(null, refs)) {
/*      */         
/*  771 */         this.trackingCount = trackingCount.get();
/*      */       
/*      */       }
/*      */       else {
/*      */         
/*  776 */         Collection<RefPair<S, T>> actualRefs = this.refs.get();
/*  777 */         refs.removeAll(actualRefs);
/*  778 */         for (RefPair<S, T> ref : refs)
/*      */         {
/*  780 */           ungetService(ref);
/*      */         }
/*      */       } 
/*  783 */       return DependencyManager.this.cardinalitySatisfied(serviceCount);
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public void close() {
/*  789 */       Collection<RefPair<S, T>> refs = this.refs.getAndSet(null);
/*  790 */       if (refs != null)
/*      */       {
/*  792 */         for (RefPair<S, T> ref : refs)
/*      */         {
/*  794 */           ungetService(ref);
/*      */         }
/*      */       }
/*  797 */       deactivateTracker();
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public Collection<RefPair<S, T>> getRefs(AtomicInteger trackingCount) {
/*  803 */       trackingCount.set(this.trackingCount);
/*  804 */       Collection<RefPair<S, T>> refs = this.refs.get();
/*  805 */       return (refs == null) ? Collections.<RefPair<S, T>>emptyList() : refs;
/*      */     }
/*      */   }
/*      */   
/*      */   private class SingleDynamicCustomizer
/*      */     extends AbstractCustomizer {
/*      */     private RefPair<S, T> currentRefPair;
/*      */     private RefPair<S, T> bindingRefPair;
/*      */     
/*      */     private SingleDynamicCustomizer() {
/*  815 */       this.queuedRefPairs = new ArrayList<>();
/*      */     }
/*      */ 
/*      */     
/*      */     private Collection<RefPair<S, T>> queuedRefPairs;
/*      */     
/*      */     public RefPair<S, T> addingService(ServiceReference<T> serviceReference) {
/*  822 */       RefPair<S, T> refPair = getPreviousRefMap().get(serviceReference);
/*  823 */       if (refPair == null)
/*      */       {
/*  825 */         refPair = DependencyManager.this.newRefPair(serviceReference);
/*      */       }
/*  827 */       return refPair;
/*      */     }
/*      */     
/*      */     private Thread bindingThread;
/*      */     private int trackingCount;
/*      */     
/*      */     public void addedService(ServiceReference<T> serviceReference, RefPair<S, T> refPair, int trackingCount, int serviceCount, ExtendedServiceEvent event) {
/*  834 */       DependencyManager.this.m_componentManager.getLogger().log(InternalLogger.Level.DEBUG, "dm {0} tracking {1} SingleDynamic added {2} (enter)", null, new Object[] { this.this$0
/*      */             
/*  836 */             .getName(), Integer.valueOf(trackingCount), serviceReference });
/*  837 */       boolean tracked = false;
/*  838 */       if (getPreviousRefMap().remove(serviceReference) == null)
/*      */       {
/*  840 */         if (isActive()) {
/*      */ 
/*      */           
/*  843 */           ServiceTracker<T, RefPair<S, T>, ExtendedServiceEvent> tracker = getTracker();
/*  844 */           Object monitor = (tracker == null) ? null : tracker.tracked();
/*  845 */           if (monitor != null)
/*      */           {
/*  847 */             tryInvokeBind(tracker, monitor, refPair, trackingCount);
/*      */           }
/*      */         }
/*  850 */         else if (isTrackerOpened() && DependencyManager.this.cardinalityJustSatisfied(serviceCount)) {
/*      */           
/*  852 */           tracked(trackingCount);
/*  853 */           tracked = true;
/*  854 */           DependencyManager.this.m_componentManager.activateInternal();
/*      */         } 
/*      */       }
/*  857 */       this.trackingCount = trackingCount;
/*  858 */       DependencyManager.this.m_componentManager.getLogger().log(InternalLogger.Level.DEBUG, "dm {0} tracking {1} SingleDynamic added {2} (exit)", null, new Object[] { this.this$0
/*      */             
/*  860 */             .getName(), Integer.valueOf(trackingCount), serviceReference });
/*  861 */       if (!tracked)
/*      */       {
/*  863 */         tracked(trackingCount);
/*      */       }
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private void tryInvokeBind(ServiceTracker<T, RefPair<S, T>, ExtendedServiceEvent> tracker, Object monitor, RefPair<S, T> next, int trackingCount) {
/*  871 */       boolean checkQueue = false;
/*      */ 
/*      */       
/*      */       while (true) {
/*      */         try {
/*  876 */           if ((next = tryInvokeBind0(tracker, monitor, next, trackingCount)) != null)
/*      */           {
/*      */             continue;
/*      */           
/*      */           }
/*      */         }
/*      */         finally {
/*      */           
/*  884 */           synchronized (monitor) {
/*      */             
/*  886 */             if (this.bindingThread != null && this.bindingThread
/*  887 */               .equals(Thread.currentThread()))
/*      */             {
/*      */ 
/*      */               
/*  891 */               if (this.queuedRefPairs.isEmpty()) {
/*      */ 
/*      */                 
/*  894 */                 this.bindingRefPair = null;
/*  895 */                 this.bindingThread = null;
/*      */               }
/*      */               else {
/*      */                 
/*  899 */                 next = getBestFromQueue();
/*      */ 
/*      */ 
/*      */                 
/*  903 */                 checkQueue = true;
/*      */               } 
/*      */             }
/*      */           } 
/*      */         } 
/*      */         
/*  909 */         if (!checkQueue)
/*      */           break; 
/*      */       } 
/*      */     }
/*      */     private RefPair<S, T> getBestFromQueue() {
/*  914 */       RefPair<S, T> currentBest = null;
/*  915 */       for (RefPair<S, T> betterCandidate : this.queuedRefPairs) {
/*      */         
/*  917 */         if (currentBest == null || betterCandidate
/*  918 */           .getRef().compareTo(currentBest.getRef()) > 0)
/*      */         {
/*  920 */           currentBest = betterCandidate;
/*      */         }
/*      */       } 
/*  923 */       this.queuedRefPairs.clear();
/*  924 */       return currentBest;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     private RefPair<S, T> tryInvokeBind0(ServiceTracker<T, RefPair<S, T>, ExtendedServiceEvent> tracker, Object monitor, RefPair<S, T> refPair, int trackingCount) {
/*      */       RefPair<S, T> current;
/*  931 */       boolean invokeBind = false;
/*      */       
/*  933 */       synchronized (monitor) {
/*      */         
/*  935 */         current = this.currentRefPair;
/*      */         
/*  937 */         invokeBind = (current == null || current.isDeleted() || (!DependencyManager.this.isReluctant() && refPair.getRef().compareTo(current.getRef()) > 0));
/*  938 */         if (invokeBind) {
/*      */           
/*  940 */           if (this.bindingThread != null && !this.bindingThread.equals(Thread.currentThread())) {
/*      */ 
/*      */             
/*  943 */             if (refPair.getRef().compareTo(this.bindingRefPair.getRef()) > 0)
/*      */             {
/*      */               
/*  946 */               this.queuedRefPairs.add(refPair);
/*      */             }
/*  948 */             return null;
/*      */           } 
/*      */           
/*  951 */           this.bindingRefPair = refPair;
/*  952 */           this.bindingThread = Thread.currentThread();
/*      */         } 
/*      */       } 
/*      */       
/*  956 */       if (invokeBind) {
/*      */         
/*  958 */         boolean invokedUnbind = false;
/*  959 */         DependencyManager.this.m_componentManager.invokeBindMethod(DependencyManager.this, this.bindingRefPair, trackingCount);
/*      */         
/*  961 */         if (!this.bindingRefPair.isFailed()) {
/*      */           
/*  963 */           if (current != null)
/*      */           {
/*  965 */             DependencyManager.this.m_componentManager.invokeUnbindMethod(DependencyManager.this, current, trackingCount);
/*      */             
/*  967 */             invokedUnbind = true;
/*  968 */             ungetService(current);
/*      */           }
/*      */         
/*  971 */         } else if (DependencyManager.this.cardinalitySatisfied(0)) {
/*      */           
/*  973 */           DependencyManager.this.m_componentManager.registerMissingDependency(DependencyManager.this, this.bindingRefPair
/*  974 */               .getRef(), trackingCount);
/*      */         } 
/*  976 */         RefPair<S, T> next = null;
/*  977 */         synchronized (monitor) {
/*      */           
/*  979 */           if (!this.queuedRefPairs.isEmpty()) {
/*      */ 
/*      */ 
/*      */             
/*  983 */             next = getBestFromQueue();
/*  984 */             this.bindingRefPair = next;
/*  985 */             if (invokedUnbind)
/*      */             {
/*      */               
/*  988 */               this.currentRefPair = null;
/*      */             
/*      */             }
/*      */           
/*      */           }
/*  993 */           else if (this.bindingRefPair.isDeleted()) {
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*  998 */             Iterator<RefPair<S, T>> iNext = getTracker().getTracked(null, new AtomicInteger()).values().iterator();
/*  999 */             next = iNext.hasNext() ? iNext.next() : null;
/* 1000 */             this.bindingRefPair = next;
/* 1001 */             if (invokedUnbind)
/*      */             {
/*      */               
/* 1004 */               this.currentRefPair = null;
/*      */             
/*      */             }
/*      */           }
/*      */           else {
/*      */             
/* 1010 */             this.currentRefPair = this.bindingRefPair;
/* 1011 */             this.bindingRefPair = null;
/* 1012 */             this.bindingThread = null;
/* 1013 */             return null;
/*      */           } 
/*      */         } 
/*      */ 
/*      */         
/* 1018 */         DependencyManager.this.m_componentManager.invokeUnbindMethod(DependencyManager.this, refPair, trackingCount);
/*      */         
/* 1020 */         ungetService(refPair);
/* 1021 */         return next;
/*      */       } 
/* 1023 */       return null;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void modifiedService(ServiceReference<T> serviceReference, RefPair<S, T> refPair, int trackingCount, ExtendedServiceEvent event) {
/* 1030 */       DependencyManager.this.m_componentManager.getLogger().log(InternalLogger.Level.DEBUG, "dm {0} tracking {1} SingleDynamic modified {2} (enter)", null, new Object[] { this.this$0
/*      */             
/* 1032 */             .getName(), Integer.valueOf(trackingCount), serviceReference });
/* 1033 */       boolean invokeUpdated = false;
/* 1034 */       ServiceTracker<T, RefPair<S, T>, ExtendedServiceEvent> tracker = getTracker();
/* 1035 */       Object monitor = (tracker == null) ? null : tracker.tracked();
/* 1036 */       if (monitor != null)
/*      */       {
/* 1038 */         synchronized (monitor) {
/*      */           
/* 1040 */           invokeUpdated = (isActive() && refPair == this.currentRefPair);
/*      */         } 
/*      */       }
/* 1043 */       if (invokeUpdated)
/*      */       {
/* 1045 */         DependencyManager.this.m_componentManager.invokeUpdatedMethod(DependencyManager.this, refPair, trackingCount);
/*      */       }
/* 1047 */       this.trackingCount = trackingCount;
/* 1048 */       DependencyManager.this.m_componentManager.getLogger().log(InternalLogger.Level.DEBUG, "dm {0} tracking {1} SingleDynamic modified {2} (exit)", null, new Object[] { this.this$0
/*      */             
/* 1050 */             .getName(), Integer.valueOf(trackingCount), serviceReference });
/* 1051 */       tracked(trackingCount);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void removedService(ServiceReference<T> serviceReference, RefPair<S, T> refPair, int trackingCount, ExtendedServiceEvent event) {
/* 1058 */       DependencyManager.this.m_componentManager.getLogger().log(InternalLogger.Level.DEBUG, "dm {0} tracking {1} SingleDynamic removed {2} (enter)", null, new Object[] { this.this$0
/*      */             
/* 1060 */             .getName(), Integer.valueOf(trackingCount), serviceReference });
/* 1061 */       boolean deactivate = false;
/* 1062 */       boolean untracked = true;
/* 1063 */       RefPair<S, T> oldRefPair = null;
/* 1064 */       RefPair<S, T> nextRefPair = null;
/* 1065 */       ServiceTracker<T, RefPair<S, T>, ExtendedServiceEvent> tracker = getTracker();
/* 1066 */       Object monitor = (tracker == null) ? null : tracker.tracked();
/* 1067 */       if (monitor != null)
/*      */       {
/* 1069 */         synchronized (monitor) {
/*      */           
/* 1071 */           refPair.markDeleted();
/* 1072 */           if (refPair == this.currentRefPair && isActive()) {
/*      */             
/* 1074 */             if (!getTracker().isEmpty()) {
/*      */               
/* 1076 */               SortedMap<ServiceReference<T>, RefPair<S, T>> tracked = getTracker().getTracked(null, new AtomicInteger());
/*      */ 
/*      */               
/* 1079 */               nextRefPair = tracked.values().iterator().next();
/*      */             } 
/*      */ 
/*      */             
/* 1083 */             if (DependencyManager.this.isEffectivelyOptional() || nextRefPair != null)
/*      */             {
/* 1085 */               oldRefPair = this.currentRefPair;
/*      */             }
/*      */             else
/*      */             {
/* 1089 */               deactivate = true;
/*      */             }
/*      */           
/* 1092 */           } else if (!DependencyManager.this.cardinalitySatisfied() && this.currentRefPair == null) {
/*      */             
/* 1094 */             deactivate = true;
/*      */           } 
/*      */         } 
/*      */       }
/* 1098 */       if (nextRefPair != null)
/*      */       {
/* 1100 */         tryInvokeBind(tracker, monitor, nextRefPair, trackingCount);
/*      */       }
/*      */       
/* 1103 */       if (oldRefPair != null) {
/*      */         
/* 1105 */         this.trackingCount = trackingCount;
/* 1106 */         synchronized (monitor) {
/*      */           
/* 1108 */           if (oldRefPair != this.currentRefPair) {
/*      */             
/* 1110 */             oldRefPair = null;
/*      */             
/* 1112 */             if (this.currentRefPair == null)
/*      */             {
/*      */               
/* 1115 */               deactivate = !DependencyManager.this.isEffectivelyOptional();
/*      */             }
/*      */           }
/*      */           else {
/*      */             
/* 1120 */             this.currentRefPair = null;
/*      */           } 
/*      */         } 
/* 1123 */         if (oldRefPair != null) {
/*      */           
/* 1125 */           DependencyManager.this.m_componentManager.invokeUnbindMethod(DependencyManager.this, oldRefPair, trackingCount);
/*      */           
/* 1127 */           ungetService(oldRefPair);
/*      */         } 
/* 1129 */         tracked(trackingCount);
/* 1130 */         untracked = false;
/*      */       } 
/*      */       
/* 1133 */       if (deactivate) {
/*      */         
/* 1135 */         this.trackingCount = trackingCount;
/* 1136 */         tracked(trackingCount);
/* 1137 */         untracked = false;
/* 1138 */         DependencyManager.this.deactivateComponentManager();
/*      */       } 
/*      */       
/* 1141 */       if (untracked) {
/*      */         
/* 1143 */         this.trackingCount = trackingCount;
/* 1144 */         tracked(trackingCount);
/*      */       } 
/* 1146 */       DependencyManager.this.m_componentManager.getLogger().log(InternalLogger.Level.DEBUG, "dm {0} tracking {1} SingleDynamic removed {2} (exit)", null, new Object[] { this.this$0
/*      */             
/* 1148 */             .getName(), Integer.valueOf(trackingCount), serviceReference });
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public boolean prebind(ComponentContextImpl<S> key) {
/* 1154 */       RefPair<S, T> refPair = null;
/* 1155 */       boolean success = DependencyManager.this.cardinalitySatisfied(0);
/* 1156 */       AtomicInteger trackingCount = new AtomicInteger();
/* 1157 */       ServiceTracker<T, RefPair<S, T>, ExtendedServiceEvent> tracker = getTracker();
/* 1158 */       Object monitor = (tracker == null) ? null : tracker.tracked();
/* 1159 */       if (monitor != null)
/*      */       {
/* 1161 */         synchronized (monitor) {
/*      */           
/* 1163 */           if (success || !tracker.isEmpty()) {
/*      */             
/* 1165 */             SortedMap<ServiceReference<T>, RefPair<S, T>> tracked = tracker.getTracked(
/* 1166 */                 Boolean.valueOf(true), trackingCount);
/* 1167 */             if (!tracked.isEmpty()) {
/*      */               
/* 1169 */               refPair = tracked.values().iterator().next();
/* 1170 */               this.currentRefPair = refPair;
/*      */             } 
/*      */           } 
/*      */         } 
/*      */       }
/* 1175 */       if (refPair != null) {
/*      */         
/* 1177 */         success |= DependencyManager.this.getServiceObject(key, DependencyManager.this.m_bindMethods.getBind(), refPair);
/* 1178 */         if (refPair.isFailed() && DependencyManager.this.cardinalitySatisfied(0))
/*      */         {
/* 1180 */           DependencyManager.this.m_componentManager.registerMissingDependency(DependencyManager.this, refPair.getRef(), trackingCount
/* 1181 */               .get());
/*      */         }
/*      */       } 
/* 1184 */       return success;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public void close() {
/* 1190 */       closeRefPair();
/* 1191 */       deactivateTracker();
/*      */     }
/*      */ 
/*      */     
/*      */     private void closeRefPair() {
/* 1196 */       if (this.currentRefPair != null)
/*      */       {
/* 1198 */         ungetService(this.currentRefPair);
/*      */       }
/* 1200 */       this.currentRefPair = null;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public Collection<RefPair<S, T>> getRefs(AtomicInteger trackingCount) {
/* 1206 */       ServiceTracker<T, RefPair<S, T>, ExtendedServiceEvent> tracker = getTracker();
/* 1207 */       Object monitor = (tracker == null) ? null : tracker.tracked();
/* 1208 */       if (monitor != null)
/*      */       {
/* 1210 */         synchronized (monitor) {
/*      */           
/* 1212 */           trackingCount.set(this.trackingCount);
/* 1213 */           return (this.currentRefPair == null) ? 
/* 1214 */             Collections.<RefPair<S, T>>emptyList() : 
/* 1215 */             Collections.<RefPair<S, T>>singleton(this.currentRefPair);
/*      */         } 
/*      */       }
/*      */ 
/*      */       
/* 1220 */       return Collections.emptyList();
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   private class SingleStaticCustomizer
/*      */     extends AbstractCustomizer
/*      */   {
/*      */     private RefPair<S, T> refPair;
/*      */     private int trackingCount;
/*      */     
/*      */     private SingleStaticCustomizer() {}
/*      */     
/*      */     public RefPair<S, T> addingService(ServiceReference<T> serviceReference) {
/* 1234 */       RefPair<S, T> refPair = DependencyManager.this.newRefPair(serviceReference);
/* 1235 */       return refPair;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void addedService(ServiceReference<T> serviceReference, RefPair<S, T> refPair, int trackingCount, int serviceCount, ExtendedServiceEvent event) {
/* 1242 */       DependencyManager.this.m_componentManager.getLogger().log(InternalLogger.Level.DEBUG, "dm {0} tracking {1} SingleStatic added {2} (enter)", null, new Object[] { this.this$0
/*      */             
/* 1244 */             .getName(), Integer.valueOf(trackingCount), serviceReference });
/* 1245 */       this.trackingCount = trackingCount;
/* 1246 */       tracked(trackingCount);
/* 1247 */       ServiceTracker<T, RefPair<S, T>, ExtendedServiceEvent> tracker = getTracker();
/* 1248 */       Object monitor = (tracker == null) ? null : tracker.tracked();
/* 1249 */       if (monitor != null && isActive()) {
/*      */         boolean reactivate;
/*      */         
/* 1252 */         synchronized (monitor) {
/*      */ 
/*      */           
/* 1255 */           reactivate = (!DependencyManager.this.isReluctant() && (this.refPair == null || refPair.getRef().compareTo(this.refPair.getRef()) > 0));
/*      */         } 
/* 1257 */         if (reactivate)
/*      */         {
/* 1259 */           DependencyManager.this.deactivateComponentManager();
/* 1260 */           if (event != null)
/*      */           {
/* 1262 */             event.addComponentManager(DependencyManager.this.m_componentManager);
/*      */           }
/*      */         }
/*      */         else
/*      */         {
/* 1267 */           DependencyManager.this.m_componentManager.getLogger().log(InternalLogger.Level.DEBUG, "dm {0} tracking {1} SingleStatic active but new {2} is worse match than old {3}", null, new Object[] { this.this$0
/*      */                 
/* 1269 */                 .getName(), Integer.valueOf(trackingCount), refPair, this.refPair });
/*      */         }
/*      */       
/* 1272 */       } else if (isTrackerOpened() && DependencyManager.this.cardinalityJustSatisfied(serviceCount)) {
/*      */         
/* 1274 */         DependencyManager.this.m_componentManager.activateInternal();
/*      */       }
/*      */       else {
/*      */         
/* 1278 */         DependencyManager.this.m_componentManager.getLogger().log(InternalLogger.Level.DEBUG, "dm {0} tracking {1} SingleStatic active: {2} trackerOpened: {3} optional: {4}", null, new Object[] { this.this$0
/*      */               
/* 1280 */               .getName(), Integer.valueOf(trackingCount), Boolean.valueOf(isActive()), Boolean.valueOf(isTrackerOpened()), Boolean.valueOf(this.this$0.isOptional()) });
/*      */       } 
/* 1282 */       DependencyManager.this.m_componentManager.getLogger().log(InternalLogger.Level.DEBUG, "dm {0} tracking {1} SingleStatic added {2} (exit)", null, new Object[] { this.this$0
/*      */             
/* 1284 */             .getName(), Integer.valueOf(trackingCount), serviceReference });
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void modifiedService(ServiceReference<T> serviceReference, RefPair<S, T> refPair, int trackingCount, ExtendedServiceEvent event) {
/* 1291 */       DependencyManager.this.m_componentManager.getLogger().log(InternalLogger.Level.DEBUG, "dm {0} tracking {1} SingleStatic modified {2} (enter)", null, new Object[] { this.this$0
/*      */             
/* 1293 */             .getName(), Integer.valueOf(trackingCount), serviceReference });
/* 1294 */       boolean invokeUpdated = false;
/* 1295 */       Object monitor = getTracker().tracked();
/* 1296 */       if (monitor != null)
/*      */       {
/* 1298 */         synchronized (monitor) {
/*      */           
/* 1300 */           invokeUpdated = (isActive() && refPair == this.refPair);
/*      */         } 
/*      */       }
/* 1303 */       boolean reactivate = false;
/* 1304 */       if (invokeUpdated)
/*      */       {
/* 1306 */         reactivate = DependencyManager.this.m_componentManager.invokeUpdatedMethod(DependencyManager.this, refPair, trackingCount);
/*      */       }
/* 1308 */       this.trackingCount = trackingCount;
/* 1309 */       tracked(trackingCount);
/* 1310 */       if (reactivate) {
/*      */         
/* 1312 */         DependencyManager.this.deactivateComponentManager();
/* 1313 */         synchronized (monitor) {
/*      */           
/* 1315 */           if (refPair == this.refPair)
/*      */           {
/* 1317 */             this.refPair = null;
/*      */           }
/*      */         } 
/* 1320 */         if (event != null)
/*      */         {
/* 1322 */           event.addComponentManager(DependencyManager.this.m_componentManager);
/*      */         }
/*      */       } 
/* 1325 */       DependencyManager.this.m_componentManager.getLogger().log(InternalLogger.Level.DEBUG, "dm {0} tracking {1} SingleStatic modified {2} (exit)", null, new Object[] { this.this$0
/*      */             
/* 1327 */             .getName(), Integer.valueOf(trackingCount), serviceReference });
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void removedService(ServiceReference<T> serviceReference, RefPair<S, T> refPair, int trackingCount, ExtendedServiceEvent event) {
/* 1334 */       DependencyManager.this.m_componentManager.getLogger().log(InternalLogger.Level.DEBUG, "dm {0} tracking {1} SingleStatic removed {2} (enter)", null, new Object[] { this.this$0
/*      */             
/* 1336 */             .getName(), Integer.valueOf(trackingCount), serviceReference });
/* 1337 */       refPair.markDeleted();
/* 1338 */       this.trackingCount = trackingCount;
/* 1339 */       tracked(trackingCount);
/*      */       
/* 1341 */       ServiceTracker<T, RefPair<S, T>, ExtendedServiceEvent> tracker = getTracker();
/* 1342 */       Object monitor = (tracker == null) ? null : tracker.tracked();
/* 1343 */       if (monitor != null) {
/*      */         boolean reactivate;
/* 1345 */         synchronized (monitor) {
/*      */ 
/*      */           
/* 1348 */           reactivate = ((isActive() && refPair == this.refPair) || !DependencyManager.this.cardinalitySatisfied(tracker.getServiceCount()));
/* 1349 */           if (!reactivate && refPair == this.refPair)
/*      */           {
/* 1351 */             this.refPair = null;
/*      */           }
/*      */         } 
/* 1354 */         if (reactivate) {
/*      */           
/* 1356 */           DependencyManager.this.deactivateComponentManager();
/* 1357 */           synchronized (monitor) {
/*      */             
/* 1359 */             if (refPair == this.refPair)
/*      */             {
/* 1361 */               this.refPair = null;
/*      */             }
/*      */           } 
/* 1364 */           if (event != null)
/*      */           {
/* 1366 */             event.addComponentManager(DependencyManager.this.m_componentManager);
/*      */           }
/*      */         } 
/*      */       } 
/* 1370 */       DependencyManager.this.m_componentManager.getLogger().log(InternalLogger.Level.DEBUG, "dm {0} tracking {1} SingleStatic removed {2} (exit)", null, new Object[] { this.this$0
/*      */             
/* 1372 */             .getName(), Integer.valueOf(trackingCount), serviceReference });
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public boolean prebind(ComponentContextImpl<S> key) {
/* 1378 */       RefPair<S, T> refPair = null;
/* 1379 */       boolean success = DependencyManager.this.cardinalitySatisfied(0);
/* 1380 */       AtomicInteger trackingCount = new AtomicInteger();
/* 1381 */       ServiceTracker<T, RefPair<S, T>, ExtendedServiceEvent> tracker = getTracker();
/* 1382 */       Object monitor = (tracker == null) ? null : tracker.tracked();
/* 1383 */       if (monitor != null)
/*      */       {
/* 1385 */         synchronized (monitor) {
/*      */           
/* 1387 */           if (success || !tracker.isEmpty()) {
/*      */             
/* 1389 */             SortedMap<ServiceReference<T>, RefPair<S, T>> tracked = tracker.getTracked(
/* 1390 */                 Boolean.valueOf(true), trackingCount);
/* 1391 */             if (!tracked.isEmpty()) {
/*      */               
/* 1393 */               refPair = tracked.values().iterator().next();
/* 1394 */               this.refPair = refPair;
/*      */             } 
/*      */           } 
/*      */         } 
/*      */       }
/* 1399 */       if (refPair != null) {
/*      */         
/* 1401 */         success |= DependencyManager.this.getServiceObject(key, DependencyManager.this.m_bindMethods.getBind(), refPair);
/* 1402 */         if (refPair.isFailed())
/*      */         {
/* 1404 */           DependencyManager.this.m_componentManager.registerMissingDependency(DependencyManager.this, refPair
/* 1405 */               .getRef(), trackingCount.get());
/*      */         }
/*      */       } 
/* 1408 */       return success;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public void close() {
/* 1414 */       ServiceTracker<T, RefPair<S, T>, ExtendedServiceEvent> tracker = getTracker();
/* 1415 */       Object monitor = (tracker == null) ? null : tracker.tracked();
/* 1416 */       if (monitor != null) {
/*      */         RefPair<S, T> ref;
/*      */         
/* 1419 */         synchronized (monitor) {
/*      */           
/* 1421 */           ref = this.refPair;
/* 1422 */           this.refPair = null;
/*      */         } 
/* 1424 */         if (ref != null)
/*      */         {
/* 1426 */           ungetService(ref);
/*      */         }
/* 1428 */         tracker.deactivate();
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public Collection<RefPair<S, T>> getRefs(AtomicInteger trackingCount) {
/* 1435 */       ServiceTracker<T, RefPair<S, T>, ExtendedServiceEvent> tracker = getTracker();
/* 1436 */       Object monitor = (tracker == null) ? null : tracker.tracked();
/* 1437 */       if (monitor != null)
/*      */       {
/* 1439 */         synchronized (monitor) {
/*      */           
/* 1441 */           trackingCount.set(this.trackingCount);
/* 1442 */           return (this.refPair == null) ? Collections.<RefPair<S, T>>emptyList() : Collections.<RefPair<S, T>>singleton(this.refPair);
/*      */         } 
/*      */       }
/*      */ 
/*      */       
/* 1447 */       return Collections.emptyList();
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   private class NoPermissionsCustomizer
/*      */     implements Customizer<S, T>
/*      */   {
/*      */     private NoPermissionsCustomizer() {}
/*      */     
/*      */     public boolean prebind(ComponentContextImpl<S> key) {
/* 1458 */       return false;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void close() {}
/*      */ 
/*      */ 
/*      */     
/*      */     public Collection<RefPair<S, T>> getRefs(AtomicInteger trackingCount) {
/* 1469 */       return Collections.emptyList();
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public boolean isSatisfied() {
/* 1475 */       return DependencyManager.this.isOptional();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void setTracker(ServiceTracker<T, RefPair<S, T>, ExtendedServiceEvent> tRefPairServiceTracker) {}
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void setTrackerOpened() {}
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void setPreviousRefMap(Map<ServiceReference<T>, RefPair<S, T>> previousRefMap) {}
/*      */ 
/*      */ 
/*      */     
/*      */     public RefPair<S, T> addingService(ServiceReference<T> tServiceReference) {
/* 1496 */       return null;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void addedService(ServiceReference<T> tServiceReference, RefPair<S, T> service, int trackingCount, int serviceCount, ExtendedServiceEvent event) {}
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void modifiedService(ServiceReference<T> tServiceReference, RefPair<S, T> service, int trackingCount, ExtendedServiceEvent event) {}
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void removedService(ServiceReference<T> tServiceReference, RefPair<S, T> service, int trackingCount, ExtendedServiceEvent event) {}
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private String getServiceName() {
/* 1520 */     return this.m_dependencyMetadata.getInterface();
/*      */   }
/*      */ 
/*      */   
/*      */   boolean isOptional() {
/* 1525 */     return this.m_dependencyMetadata.isOptional();
/*      */   }
/*      */ 
/*      */   
/*      */   private boolean isEffectivelyOptional() {
/* 1530 */     return (this.m_minCardinality == 0);
/*      */   }
/*      */ 
/*      */   
/*      */   boolean cardinalitySatisfied() {
/* 1535 */     ServiceTracker<T, RefPair<S, T>, ExtendedServiceEvent> tracker = this.m_tracker;
/* 1536 */     return cardinalitySatisfied((tracker == null) ? 0 : tracker.getServiceCount());
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean cardinalitySatisfied(int serviceCount) {
/* 1541 */     return (this.m_minCardinality <= serviceCount);
/*      */   }
/*      */ 
/*      */   
/*      */   private boolean cardinalityJustSatisfied(int serviceCount) {
/* 1546 */     return (this.m_minCardinality == serviceCount);
/*      */   }
/*      */ 
/*      */   
/*      */   private boolean isMultiple() {
/* 1551 */     return this.m_dependencyMetadata.isMultiple();
/*      */   }
/*      */ 
/*      */   
/*      */   private boolean isStatic() {
/* 1556 */     return this.m_dependencyMetadata.isStatic();
/*      */   }
/*      */ 
/*      */   
/*      */   private boolean isReluctant() {
/* 1561 */     return this.m_dependencyMetadata.isReluctant();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void deactivate() {
/* 1568 */     this.m_customizer.close();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   int size() {
/* 1583 */     AtomicInteger trackingCount = new AtomicInteger();
/* 1584 */     ServiceTracker<T, RefPair<S, T>, ExtendedServiceEvent> tracker = this.m_tracker;
/* 1585 */     if (tracker == null)
/*      */     {
/* 1587 */       return 0;
/*      */     }
/* 1589 */     return this.m_tracker.getTracked(null, trackingCount).size();
/*      */   }
/*      */ 
/*      */   
/*      */   private ServiceReference<?>[] getFrameworkServiceReferences(String targetFilter) {
/* 1594 */     if (hasGetPermission()) {
/*      */ 
/*      */       
/* 1597 */       BundleContext bc = this.m_componentManager.getActivator().getBundleContext();
/* 1598 */       if (bc == null)
/*      */       {
/* 1600 */         return null;
/*      */       }
/*      */ 
/*      */       
/*      */       try {
/* 1605 */         return (ServiceReference<?>[])bc.getServiceReferences(this.m_dependencyMetadata.getInterface(), targetFilter);
/*      */       
/*      */       }
/* 1608 */       catch (IllegalStateException illegalStateException) {
/*      */ 
/*      */       
/*      */       }
/* 1612 */       catch (InvalidSyntaxException ise) {
/*      */         
/* 1614 */         this.m_componentManager.getLogger().log(InternalLogger.Level.ERROR, "Unexpected problem with filter ''{0}''", (Throwable)ise, new Object[] { targetFilter });
/*      */ 
/*      */         
/* 1617 */         return null;
/*      */       } 
/*      */     } 
/*      */     
/* 1621 */     this.m_componentManager.getLogger().log(InternalLogger.Level.DEBUG, "No permission to access the services", null);
/*      */     
/* 1623 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private RefPair<S, T> getBestRefPair() {
/* 1640 */     Collection<RefPair<S, T>> refs = this.m_customizer.getRefs(new AtomicInteger());
/* 1641 */     if (refs.isEmpty())
/*      */     {
/* 1643 */       return null;
/*      */     }
/* 1645 */     return refs.iterator().next();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   T getService(ComponentContextImpl<S> key) {
/* 1657 */     RefPair<S, T> sr = getBestRefPair();
/* 1658 */     return getService(key, sr);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   Object[] getServices(ComponentContextImpl<S> key) {
/* 1671 */     Collection<RefPair<S, T>> refs = this.m_customizer.getRefs(new AtomicInteger());
/* 1672 */     List<T> services = new ArrayList<>(refs.size());
/* 1673 */     for (RefPair<S, T> ref : refs) {
/*      */       
/* 1675 */       T service = getService(key, ref);
/* 1676 */       if (service != null)
/*      */       {
/* 1678 */         services.add(service);
/*      */       }
/*      */     } 
/* 1681 */     return services.isEmpty() ? null : services.<Object>toArray(new Object[services.size()]);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public List<ServiceReference<?>> getServiceReferences() {
/* 1692 */     Collection<RefPair<S, T>> bound = this.m_customizer.getRefs(new AtomicInteger());
/* 1693 */     List<ServiceReference<?>> result = new ArrayList<>(bound.size());
/* 1694 */     for (RefPair<S, T> ref : bound)
/*      */     {
/* 1696 */       result.add(ref.getRef());
/*      */     }
/* 1698 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private RefPair<S, T> getRefPair(ServiceReference<T> serviceReference) {
/* 1714 */     ServiceTracker<T, RefPair<S, T>, ExtendedServiceEvent> tracker = this.m_tracker;
/* 1715 */     if (tracker != null) {
/*      */       
/* 1717 */       AtomicInteger trackingCount = new AtomicInteger();
/* 1718 */       return (RefPair<S, T>)tracker.getTracked(null, trackingCount).get(serviceReference);
/*      */     } 
/* 1720 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   T getService(ComponentContextImpl<S> key, ServiceReference<T> serviceReference) {
/* 1737 */     RefPair<S, T> refPair = getRefPair(serviceReference);
/* 1738 */     return getService(key, refPair);
/*      */   }
/*      */ 
/*      */   
/*      */   private T getService(ComponentContextImpl<S> key, RefPair<S, T> refPair) {
/* 1743 */     if (refPair == null)
/*      */     {
/*      */       
/* 1746 */       return null;
/*      */     }
/*      */     T serviceObject;
/* 1749 */     if ((serviceObject = (T)refPair.getServiceObject(key)) != null)
/*      */     {
/* 1751 */       return serviceObject;
/*      */     }
/*      */     
/* 1754 */     BundleContext bundleContext = this.m_componentManager.getBundleContext();
/* 1755 */     if (bundleContext == null) {
/*      */       
/* 1757 */       this.m_componentManager.getLogger().log(InternalLogger.Level.ERROR, "Bundle shut down while getting service {0} ({1}/{2,number,#})", null, new Object[] {
/* 1758 */             getName(), this.m_dependencyMetadata
/* 1759 */             .getInterface(), refPair.getRef().getProperty("service.id") });
/* 1760 */       return null;
/*      */     } 
/*      */     
/*      */     try {
/* 1764 */       refPair.getServiceObject(key, bundleContext);
/* 1765 */       serviceObject = (T)refPair.getServiceObject(key);
/*      */     }
/* 1767 */     catch (Exception e) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1772 */       this.m_componentManager.getLogger().log(InternalLogger.Level.ERROR, "Failed getting service {0} ({1}/{2,number,#})", e, new Object[] {
/*      */             
/* 1774 */             getName(), this.m_dependencyMetadata.getInterface(), refPair
/* 1775 */             .getRef().getProperty("service.id") });
/* 1776 */       return null;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 1781 */     return serviceObject;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getName() {
/* 1792 */     return this.m_dependencyMetadata.getName();
/*      */   }
/*      */ 
/*      */   
/*      */   public ReferenceMetadata getReferenceMetadata() {
/* 1797 */     return this.m_dependencyMetadata;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isSatisfied() {
/* 1809 */     return this.m_customizer.isSatisfied();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean hasGetPermission() {
/* 1818 */     if (System.getSecurityManager() != null) {
/*      */       
/* 1820 */       ServicePermission servicePermission = new ServicePermission(getServiceName(), "get");
/* 1821 */       return this.m_componentManager.getBundle().hasPermission(servicePermission);
/*      */     } 
/*      */ 
/*      */     
/* 1825 */     return true;
/*      */   }
/*      */ 
/*      */   
/*      */   boolean prebind(ComponentContextImpl<S> key) {
/* 1830 */     return this.m_customizer.prebind(key);
/*      */   }
/*      */   
/*      */   public static final class OpenStatusImpl<S, T> implements OpenStatus<S, T> {
/*      */     private final DependencyManager<S, T> dm;
/*      */     
/*      */     OpenStatusImpl(DependencyManager<S, T> dm) {
/* 1837 */       this.dm = dm;
/*      */     }
/*      */     
/*      */     public Collection<RefPair<S, T>> getRefs(AtomicInteger trackingCount) {
/* 1841 */       return this.dm.m_customizer.getRefs(trackingCount);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   OpenStatus<S, T> open(ComponentContextImpl<S> componentContext, EdgeInfo edgeInfo) {
/*      */     Collection<RefPair<S, T>> refs;
/*      */     CountDownLatch openLatch;
/* 1855 */     int serviceCount = 0;
/* 1856 */     OpenStatus<S, T> status = new OpenStatusImpl<>(this);
/*      */     
/* 1858 */     AtomicInteger trackingCount = new AtomicInteger();
/*      */     
/* 1860 */     synchronized (this.m_tracker.tracked()) {
/*      */       
/* 1862 */       refs = this.m_customizer.getRefs(trackingCount);
/* 1863 */       edgeInfo.setOpen(trackingCount.get());
/* 1864 */       openLatch = edgeInfo.getOpenLatch();
/*      */     } 
/* 1866 */     this.m_componentManager.getLogger().log(InternalLogger.Level.DEBUG, "For dependency {0}, optional: {1}; to bind: {2}", null, new Object[] {
/*      */           
/* 1868 */           getName(), Boolean.valueOf(isOptional()), refs });
/* 1869 */     for (RefPair<S, T> refPair : refs) {
/*      */       
/* 1871 */       if (!refPair.isDeleted() && !refPair.isFailed())
/*      */       {
/* 1873 */         serviceCount++;
/*      */       }
/*      */     } 
/* 1876 */     openLatch.countDown();
/* 1877 */     return cardinalitySatisfied(serviceCount) ? status : null;
/*      */   }
/*      */ 
/*      */   
/*      */   boolean bind(ComponentContextImpl<S> componentContext, OpenStatus<S, T> status) {
/* 1882 */     if (!invokeInitMethod(componentContext)) {
/*      */       
/* 1884 */       this.m_componentManager.getLogger().log(InternalLogger.Level.DEBUG, "For dependency {0}, failed to initialize object", null, new Object[] {
/*      */             
/* 1886 */             getName() });
/* 1887 */       return false;
/*      */     } 
/* 1889 */     ReferenceMethod bindMethod = this.m_bindMethods.getBind();
/* 1890 */     return bindDependency(componentContext, bindMethod, status);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   boolean bindDependency(ComponentContextImpl<S> componentContext, ReferenceMethod bindMethod, OpenStatus<S, T> status) {
/* 1897 */     int serviceCount = 0;
/* 1898 */     AtomicInteger trackingCount = new AtomicInteger();
/* 1899 */     for (RefPair<S, T> refPair : (Iterable<RefPair<S, T>>)status.getRefs(trackingCount)) {
/*      */       
/* 1901 */       if (!refPair.isDeleted() && !refPair.isFailed()) {
/*      */         
/* 1903 */         if (!doInvokeBindMethod(componentContext, bindMethod, refPair, trackingCount.get()))
/*      */         {
/* 1905 */           this.m_componentManager.getLogger().log(InternalLogger.Level.DEBUG, "For dependency {0}, failed to invoke bind method on object {1}", null, new Object[] {
/*      */                 
/* 1907 */                 getName(), refPair
/*      */               });
/*      */         }
/* 1910 */         serviceCount++;
/*      */       } 
/*      */     } 
/* 1913 */     return cardinalitySatisfied(serviceCount);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void close(ComponentContextImpl<S> componentContext, EdgeInfo edgeInfo) {
/*      */     Collection<RefPair<S, T>> refPairs;
/*      */     CountDownLatch latch;
/* 1928 */     boolean doUnbind = (componentContext != null && (this.m_dependencyMetadata.getField() != null || this.m_dependencyMetadata.getUnbind() != null));
/*      */     
/* 1930 */     AtomicInteger trackingCount = new AtomicInteger();
/*      */ 
/*      */     
/* 1933 */     synchronized (this.m_tracker.tracked()) {
/*      */       
/* 1935 */       refPairs = this.m_customizer.getRefs(trackingCount);
/* 1936 */       edgeInfo.setClose(trackingCount.get());
/* 1937 */       latch = edgeInfo.getCloseLatch();
/*      */     } 
/*      */     
/* 1940 */     this.m_componentManager.getLogger().log(InternalLogger.Level.DEBUG, "DependencyManager: {0} close component unbinding from {1} at tracking count {2} refpairs: {3}", null, new Object[] {
/*      */           
/* 1942 */           getName(), componentContext, Integer.valueOf(trackingCount.get()), refPairs });
/* 1943 */     this.m_componentManager.waitForTracked(trackingCount.get());
/* 1944 */     for (RefPair<S, T> boundRef : refPairs) {
/*      */       
/* 1946 */       if (doUnbind && !boundRef.isFailed())
/*      */       {
/* 1948 */         invokeUnbindMethod(componentContext, boundRef, trackingCount.get(), edgeInfo);
/*      */       }
/*      */       
/* 1951 */       boundRef.ungetServiceObject(componentContext);
/*      */     } 
/*      */     
/* 1954 */     latch.countDown();
/*      */   }
/*      */ 
/*      */   
/*      */   public void invokeBindMethodLate(ServiceReference<T> ref, int trackingCount) {
/* 1959 */     ServiceTracker<T, RefPair<S, T>, ExtendedServiceEvent> tracker = this.m_tracker;
/* 1960 */     if (tracker == null || !tracker.isActive()) {
/*      */       
/* 1962 */       this.m_componentManager.notifyWaiters();
/*      */       return;
/*      */     } 
/* 1965 */     if (!isSatisfied()) {
/*      */       return;
/*      */     }
/*      */     
/* 1969 */     if (!isMultiple()) {
/*      */       
/* 1971 */       Collection<RefPair<S, T>> refs = this.m_customizer.getRefs(new AtomicInteger());
/* 1972 */       if (refs.isEmpty()) {
/*      */         return;
/*      */       }
/*      */       
/* 1976 */       RefPair<S, T> test = refs.iterator().next();
/* 1977 */       if (ref != test.getRef()) {
/*      */         return;
/*      */       }
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 1984 */     RefPair<S, T> refPair = tracker.getService(ref);
/* 1985 */     if (refPair == null) {
/*      */       return;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1998 */     this.m_componentManager.invokeBindMethod(this, refPair, trackingCount);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   boolean invokeInitMethod(ComponentContextImpl<S> componentContext) {
/* 2008 */     if (this.m_bindMethods.getInit() != null) {
/*      */       
/* 2010 */       Object componentInstance = componentContext.getImplementationObject(false);
/* 2011 */       if (componentInstance != null)
/*      */       {
/* 2013 */         return this.m_bindMethods.getInit().init(componentInstance, componentContext.getLogger());
/*      */       }
/*      */     } 
/* 2016 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   boolean invokeBindMethod(ComponentContextImpl<S> componentContext, RefPair<S, T> refPair, int trackingCount, EdgeInfo info) {
/* 2044 */     if (componentContext.getImplementationObject(false) != null) {
/*      */       
/* 2046 */       Object monitor = this.m_tracker.tracked();
/* 2047 */       if (monitor == null)
/*      */       {
/*      */         
/* 2050 */         return true;
/*      */       }
/* 2052 */       synchronized (monitor) {
/*      */         
/* 2054 */         if (info.outOfRange(trackingCount))
/*      */         {
/*      */           
/* 2057 */           return true;
/*      */         }
/*      */       } 
/*      */       
/* 2061 */       return doInvokeBindMethod(componentContext, this.m_bindMethods.getBind(), refPair, trackingCount);
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 2066 */     this.m_componentManager.getLogger().log(InternalLogger.Level.DEBUG, "DependencyManager : component not yet created, assuming bind method call succeeded", null);
/*      */ 
/*      */     
/* 2069 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean doInvokeBindMethod(ComponentContextImpl<S> componentContext, ReferenceMethod bindMethod, RefPair<S, T> refPair, int trackingCount) {
/* 2078 */     if (!getServiceObject(componentContext, bindMethod, refPair)) {
/*      */       
/* 2080 */       this.m_componentManager.getLogger().log(InternalLogger.Level.WARN, "DependencyManager : invokeBindMethod : Service not available from service registry for ServiceReference {0} for reference {1}", null, new Object[] { refPair
/*      */             
/* 2082 */             .getRef(), getName() });
/* 2083 */       return false;
/*      */     } 
/*      */     
/* 2086 */     MethodResult result = bindMethod.invoke(componentContext.getImplementationObject(false), new BindParameters(componentContext, refPair), MethodResult.VOID);
/*      */     
/* 2088 */     if (result == null)
/*      */     {
/* 2090 */       return false;
/*      */     }
/* 2092 */     this.m_componentManager.setServiceProperties(result, Integer.valueOf(trackingCount));
/* 2093 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   boolean invokeUpdatedMethod(ComponentContextImpl<S> componentContext, RefPair<S, T> refPair, int trackingCount, EdgeInfo info) {
/* 2107 */     ServiceTracker<T, RefPair<S, T>, ExtendedServiceEvent> tracker = this.m_tracker;
/* 2108 */     Object monitor = (tracker == null) ? null : tracker.tracked();
/* 2109 */     if (monitor == null)
/*      */     {
/* 2111 */       return false;
/*      */     }
/* 2113 */     if (this.m_dependencyMetadata.getUpdated() == null && this.m_dependencyMetadata.getField() == null)
/*      */     {
/* 2115 */       return false;
/*      */     }
/*      */ 
/*      */     
/* 2119 */     if (componentContext != null) {
/*      */       
/* 2121 */       synchronized (monitor) {
/*      */         
/* 2123 */         if (info.outOfRange(trackingCount))
/*      */         {
/*      */           
/* 2126 */           return false;
/*      */         }
/*      */       } 
/* 2129 */       info.waitForOpen(this.m_componentManager, getName(), "invokeUpdatedMethod");
/* 2130 */       if (!getServiceObject(componentContext, this.m_bindMethods.getUpdated(), refPair)) {
/*      */         
/* 2132 */         this.m_componentManager.getLogger().log(InternalLogger.Level.WARN, "DependencyManager : invokeUpdatedMethod : Service not available from service registry for ServiceReference {0} for reference {1}", null, new Object[] { refPair
/*      */               
/* 2134 */               .getRef(), getName() });
/* 2135 */         return false;
/*      */       } 
/*      */       
/* 2138 */       MethodResult methodResult = this.m_bindMethods.getUpdated().invoke(componentContext
/* 2139 */           .getImplementationObject(false), new BindParameters(componentContext, refPair), MethodResult.VOID);
/* 2140 */       if (methodResult != null)
/*      */       {
/* 2142 */         this.m_componentManager.setServiceProperties(methodResult, Integer.valueOf(trackingCount));
/*      */       }
/* 2144 */       return (methodResult == MethodResult.REACTIVATE);
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2151 */     this.m_componentManager.getLogger().log(InternalLogger.Level.DEBUG, "DependencyManager : Component not set, no need to call updated method", null);
/*      */ 
/*      */     
/* 2154 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void invokeUnbindMethod(ComponentContextImpl<S> componentContext, RefPair<S, T> refPair, int trackingCount, EdgeInfo info) {
/* 2172 */     ServiceTracker<T, RefPair<S, T>, ExtendedServiceEvent> tracker = this.m_tracker;
/* 2173 */     Object monitor = (tracker == null) ? null : tracker.tracked();
/* 2174 */     if (monitor == null) {
/*      */       return;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/* 2180 */     if (componentContext != null) {
/*      */       boolean outOfRange;
/* 2182 */       synchronized (monitor) {
/*      */         
/* 2184 */         if (info.beforeRange(trackingCount)) {
/*      */           return;
/*      */         }
/*      */       } 
/*      */ 
/*      */       
/* 2190 */       info.waitForOpen(this.m_componentManager, getName(), "invokeUnbindMethod");
/*      */       
/* 2192 */       synchronized (monitor) {
/*      */         
/* 2194 */         outOfRange = info.afterRange(trackingCount);
/*      */       } 
/* 2196 */       if (outOfRange) {
/*      */ 
/*      */         
/* 2199 */         info.waitForClose(this.m_componentManager, getName(), "invokeUnbindMethod");
/*      */         
/*      */         return;
/*      */       } 
/*      */       
/* 2204 */       if (!getServiceObject(componentContext, this.m_bindMethods.getUnbind(), refPair)) {
/*      */         
/* 2206 */         this.m_componentManager.getLogger().log(InternalLogger.Level.WARN, "DependencyManager : invokeUnbindMethod : Service not available from service registry for ServiceReference {0} for reference {1}", null, new Object[] { refPair
/*      */               
/* 2208 */               .getRef(), getName() });
/*      */         
/*      */         return;
/*      */       } 
/* 2212 */       MethodResult methodResult = this.m_bindMethods.getUnbind().invoke(componentContext
/* 2213 */           .getImplementationObject(false), new BindParameters(componentContext, refPair), MethodResult.VOID);
/* 2214 */       if (methodResult != null)
/*      */       {
/* 2216 */         this.m_componentManager.setServiceProperties(methodResult, Integer.valueOf(trackingCount));
/*      */       }
/* 2218 */       componentContext.getComponentServiceObjectsHelper().closeServiceObjects(refPair.getRef());
/*      */ 
/*      */     
/*      */     }
/*      */     else {
/*      */ 
/*      */       
/* 2225 */       this.m_componentManager.getLogger().log(InternalLogger.Level.DEBUG, "DependencyManager : Component not set, no need to call unbind method", null);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   boolean canUpdateDynamically(Map<String, Object> properties) {
/* 2255 */     String newTarget = (String)properties.get(this.m_dependencyMetadata.getTargetPropertyName());
/* 2256 */     String currentTarget = getTarget();
/* 2257 */     int newMinimumCardinality = getMinimumCardinality(properties);
/* 2258 */     if (this.m_minCardinality == newMinimumCardinality && ((currentTarget == null && newTarget == null) || (currentTarget != null && currentTarget
/* 2259 */       .equals(newTarget))))
/*      */     {
/*      */ 
/*      */       
/* 2263 */       return true;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2269 */     if (this.m_dependencyMetadata.isStatic())
/*      */     {
/*      */ 
/*      */ 
/*      */       
/* 2274 */       return false;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/* 2279 */     if (newMinimumCardinality == 0)
/*      */     {
/*      */ 
/*      */       
/* 2283 */       return true;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/* 2288 */     ServiceReference[] arrayOfServiceReference = (ServiceReference[])getFrameworkServiceReferences(newTarget);
/* 2289 */     if (arrayOfServiceReference != null)
/*      */     {
/*      */       
/* 2292 */       return (newMinimumCardinality <= arrayOfServiceReference.length);
/*      */     }
/*      */ 
/*      */ 
/*      */     
/* 2297 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void setTargetFilter(Map<String, Object> properties) {
/* 2312 */     Integer minimumCardinality = Integer.valueOf(getMinimumCardinality(properties));
/* 2313 */     setTargetFilter((String)properties.get(this.m_dependencyMetadata.getTargetPropertyName()), minimumCardinality.intValue());
/*      */   }
/*      */ 
/*      */   
/*      */   private int getMinimumCardinality(Map<String, Object> properties) {
/* 2318 */     Integer minimumCardinality = null;
/*      */     
/*      */     try {
/* 2321 */       minimumCardinality = Integer.valueOf(Coercions.coerceToInteger(properties
/* 2322 */             .get(this.m_dependencyMetadata.getMinCardinalityName())));
/*      */     }
/* 2324 */     catch (ComponentException e) {
/*      */       
/* 2326 */       this.m_componentManager.getLogger().log(InternalLogger.Level.WARN, "Invalid minimum cardinality property for dependency {0}: {1}", null, new Object[] {
/*      */             
/* 2328 */             getName(), e.getMessage() });
/*      */     } 
/* 2330 */     if (minimumCardinality != null && (minimumCardinality.intValue() < defaultMinimumCardinality(this.m_dependencyMetadata) || (
/* 2331 */       !this.m_dependencyMetadata.isMultiple() && minimumCardinality.intValue() > 1)))
/*      */     {
/*      */       
/* 2334 */       minimumCardinality = null;
/*      */     }
/* 2336 */     if (minimumCardinality == null)
/*      */     {
/* 2338 */       minimumCardinality = Integer.valueOf(defaultMinimumCardinality(this.m_dependencyMetadata));
/*      */     }
/* 2340 */     return minimumCardinality.intValue();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void setTargetFilter(String target, int minimumCardinality) {
/*      */     // Byte code:
/*      */     //   0: aload_1
/*      */     //   1: ifnonnull -> 12
/*      */     //   4: aload_0
/*      */     //   5: getfield m_dependencyMetadata : Lorg/apache/felix/scr/impl/metadata/ReferenceMetadata;
/*      */     //   8: invokevirtual getTarget : ()Ljava/lang/String;
/*      */     //   11: astore_1
/*      */     //   12: aload_0
/*      */     //   13: getfield m_target : Ljava/lang/String;
/*      */     //   16: ifnonnull -> 23
/*      */     //   19: aload_1
/*      */     //   20: ifnull -> 41
/*      */     //   23: aload_0
/*      */     //   24: getfield m_target : Ljava/lang/String;
/*      */     //   27: ifnull -> 101
/*      */     //   30: aload_0
/*      */     //   31: getfield m_target : Ljava/lang/String;
/*      */     //   34: aload_1
/*      */     //   35: invokevirtual equals : (Ljava/lang/Object;)Z
/*      */     //   38: ifeq -> 101
/*      */     //   41: aload_0
/*      */     //   42: getfield m_componentManager : Lorg/apache/felix/scr/impl/manager/AbstractComponentManager;
/*      */     //   45: invokevirtual getLogger : ()Lorg/apache/felix/scr/impl/logger/ComponentLogger;
/*      */     //   48: getstatic org/apache/felix/scr/impl/logger/InternalLogger$Level.DEBUG : Lorg/apache/felix/scr/impl/logger/InternalLogger$Level;
/*      */     //   51: ldc 'No change in target property for dependency {0}: currently registered: {1}'
/*      */     //   53: aconst_null
/*      */     //   54: iconst_2
/*      */     //   55: anewarray java/lang/Object
/*      */     //   58: dup
/*      */     //   59: iconst_0
/*      */     //   60: aload_0
/*      */     //   61: invokevirtual getName : ()Ljava/lang/String;
/*      */     //   64: aastore
/*      */     //   65: dup
/*      */     //   66: iconst_1
/*      */     //   67: aload_0
/*      */     //   68: getfield m_tracker : Lorg/apache/felix/scr/impl/manager/ServiceTracker;
/*      */     //   71: ifnull -> 78
/*      */     //   74: iconst_1
/*      */     //   75: goto -> 79
/*      */     //   78: iconst_0
/*      */     //   79: invokestatic valueOf : (Z)Ljava/lang/Boolean;
/*      */     //   82: aastore
/*      */     //   83: invokeinterface log : (Lorg/apache/felix/scr/impl/logger/InternalLogger$Level;Ljava/lang/String;Ljava/lang/Throwable;[Ljava/lang/Object;)V
/*      */     //   88: aload_0
/*      */     //   89: getfield m_tracker : Lorg/apache/felix/scr/impl/manager/ServiceTracker;
/*      */     //   92: ifnull -> 101
/*      */     //   95: aload_0
/*      */     //   96: iload_2
/*      */     //   97: putfield m_minCardinality : I
/*      */     //   100: return
/*      */     //   101: aload_1
/*      */     //   102: ifnull -> 150
/*      */     //   105: aload_1
/*      */     //   106: invokestatic createFilter : (Ljava/lang/String;)Lorg/osgi/framework/Filter;
/*      */     //   109: pop
/*      */     //   110: goto -> 150
/*      */     //   113: astore_3
/*      */     //   114: aload_0
/*      */     //   115: getfield m_componentManager : Lorg/apache/felix/scr/impl/manager/AbstractComponentManager;
/*      */     //   118: invokevirtual getLogger : ()Lorg/apache/felix/scr/impl/logger/ComponentLogger;
/*      */     //   121: getstatic org/apache/felix/scr/impl/logger/InternalLogger$Level.ERROR : Lorg/apache/felix/scr/impl/logger/InternalLogger$Level;
/*      */     //   124: ldc 'Invalid syntax in target property for dependency {0} to {1}'
/*      */     //   126: aconst_null
/*      */     //   127: iconst_2
/*      */     //   128: anewarray java/lang/Object
/*      */     //   131: dup
/*      */     //   132: iconst_0
/*      */     //   133: aload_0
/*      */     //   134: invokevirtual getName : ()Ljava/lang/String;
/*      */     //   137: aastore
/*      */     //   138: dup
/*      */     //   139: iconst_1
/*      */     //   140: aload_1
/*      */     //   141: aastore
/*      */     //   142: invokeinterface log : (Lorg/apache/felix/scr/impl/logger/InternalLogger$Level;Ljava/lang/String;Ljava/lang/Throwable;[Ljava/lang/Object;)V
/*      */     //   147: ldc '(&(invalid.target.cannot.resolve=*)(!(invalid.target.cannot.resolve=*)))'
/*      */     //   149: astore_1
/*      */     //   150: aload_0
/*      */     //   151: aload_1
/*      */     //   152: putfield m_target : Ljava/lang/String;
/*      */     //   155: aload_0
/*      */     //   156: invokespecial getClassFilter : ()Ljava/lang/String;
/*      */     //   159: astore_3
/*      */     //   160: aload_0
/*      */     //   161: aload_3
/*      */     //   162: aload_1
/*      */     //   163: invokespecial getInitialReferenceFilter : (Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
/*      */     //   166: astore #4
/*      */     //   168: aload_0
/*      */     //   169: getfield m_tracker : Lorg/apache/felix/scr/impl/manager/ServiceTracker;
/*      */     //   172: astore #5
/*      */     //   174: new java/util/concurrent/atomic/AtomicInteger
/*      */     //   177: dup
/*      */     //   178: invokespecial <init> : ()V
/*      */     //   181: astore #6
/*      */     //   183: aload_0
/*      */     //   184: aload #6
/*      */     //   186: invokevirtual unregisterServiceListener : (Ljava/util/concurrent/atomic/AtomicInteger;)Ljava/util/SortedMap;
/*      */     //   189: astore #7
/*      */     //   191: aload #6
/*      */     //   193: invokevirtual get : ()I
/*      */     //   196: iconst_m1
/*      */     //   197: if_icmpeq -> 212
/*      */     //   200: aload_0
/*      */     //   201: getfield m_componentManager : Lorg/apache/felix/scr/impl/manager/AbstractComponentManager;
/*      */     //   204: aload #6
/*      */     //   206: invokevirtual get : ()I
/*      */     //   209: invokevirtual waitForTracked : (I)V
/*      */     //   212: aload_0
/*      */     //   213: getfield m_componentManager : Lorg/apache/felix/scr/impl/manager/AbstractComponentManager;
/*      */     //   216: invokevirtual getLogger : ()Lorg/apache/felix/scr/impl/logger/ComponentLogger;
/*      */     //   219: getstatic org/apache/felix/scr/impl/logger/InternalLogger$Level.DEBUG : Lorg/apache/felix/scr/impl/logger/InternalLogger$Level;
/*      */     //   222: ldc 'Setting target property for dependency {0} to {1}'
/*      */     //   224: aconst_null
/*      */     //   225: iconst_2
/*      */     //   226: anewarray java/lang/Object
/*      */     //   229: dup
/*      */     //   230: iconst_0
/*      */     //   231: aload_0
/*      */     //   232: invokevirtual getName : ()Ljava/lang/String;
/*      */     //   235: aastore
/*      */     //   236: dup
/*      */     //   237: iconst_1
/*      */     //   238: aload_1
/*      */     //   239: aastore
/*      */     //   240: invokeinterface log : (Lorg/apache/felix/scr/impl/logger/InternalLogger$Level;Ljava/lang/String;Ljava/lang/Throwable;[Ljava/lang/Object;)V
/*      */     //   245: aload_0
/*      */     //   246: getfield m_componentManager : Lorg/apache/felix/scr/impl/manager/AbstractComponentManager;
/*      */     //   249: invokevirtual getBundleContext : ()Lorg/osgi/framework/BundleContext;
/*      */     //   252: astore #8
/*      */     //   254: aload_0
/*      */     //   255: getfield m_customizer : Lorg/apache/felix/scr/impl/manager/DependencyManager$Customizer;
/*      */     //   258: aload #7
/*      */     //   260: invokeinterface setPreviousRefMap : (Ljava/util/Map;)V
/*      */     //   265: aload #5
/*      */     //   267: ifnull -> 282
/*      */     //   270: aload #5
/*      */     //   272: invokevirtual isActive : ()Z
/*      */     //   275: ifeq -> 282
/*      */     //   278: iconst_1
/*      */     //   279: goto -> 283
/*      */     //   282: iconst_0
/*      */     //   283: istore #9
/*      */     //   285: aload_0
/*      */     //   286: getfield m_componentManager : Lorg/apache/felix/scr/impl/manager/AbstractComponentManager;
/*      */     //   289: invokevirtual getLogger : ()Lorg/apache/felix/scr/impl/logger/ComponentLogger;
/*      */     //   292: getstatic org/apache/felix/scr/impl/logger/InternalLogger$Level.DEBUG : Lorg/apache/felix/scr/impl/logger/InternalLogger$Level;
/*      */     //   295: ldc 'New service tracker for {0}, initial active: {1}, previous references: {2}, classFilter: {3}, initialReferenceFilter {4}'
/*      */     //   297: aconst_null
/*      */     //   298: iconst_5
/*      */     //   299: anewarray java/lang/Object
/*      */     //   302: dup
/*      */     //   303: iconst_0
/*      */     //   304: aload_0
/*      */     //   305: invokevirtual getName : ()Ljava/lang/String;
/*      */     //   308: aastore
/*      */     //   309: dup
/*      */     //   310: iconst_1
/*      */     //   311: iload #9
/*      */     //   313: invokestatic valueOf : (Z)Ljava/lang/Boolean;
/*      */     //   316: aastore
/*      */     //   317: dup
/*      */     //   318: iconst_2
/*      */     //   319: aload #7
/*      */     //   321: aastore
/*      */     //   322: dup
/*      */     //   323: iconst_3
/*      */     //   324: aload_3
/*      */     //   325: aastore
/*      */     //   326: dup
/*      */     //   327: iconst_4
/*      */     //   328: aload #4
/*      */     //   330: aastore
/*      */     //   331: invokeinterface log : (Lorg/apache/felix/scr/impl/logger/InternalLogger$Level;Ljava/lang/String;Ljava/lang/Throwable;[Ljava/lang/Object;)V
/*      */     //   336: aload_0
/*      */     //   337: invokespecial getTrueConditionRef : ()Lorg/osgi/framework/ServiceReference;
/*      */     //   340: astore #10
/*      */     //   342: new org/apache/felix/scr/impl/manager/ServiceTracker
/*      */     //   345: dup
/*      */     //   346: aload #8
/*      */     //   348: aload_0
/*      */     //   349: getfield m_customizer : Lorg/apache/felix/scr/impl/manager/DependencyManager$Customizer;
/*      */     //   352: iload #9
/*      */     //   354: aload_0
/*      */     //   355: getfield m_componentManager : Lorg/apache/felix/scr/impl/manager/AbstractComponentManager;
/*      */     //   358: invokevirtual getActivator : ()Lorg/apache/felix/scr/impl/manager/ComponentActivator;
/*      */     //   361: aload #4
/*      */     //   363: aload #10
/*      */     //   365: invokespecial <init> : (Lorg/osgi/framework/BundleContext;Lorg/apache/felix/scr/impl/manager/ServiceTrackerCustomizer;ZLorg/apache/felix/scr/impl/manager/ExtendedServiceListenerContext;Ljava/lang/String;Lorg/osgi/framework/ServiceReference;)V
/*      */     //   368: astore #11
/*      */     //   370: aload_0
/*      */     //   371: getfield m_customizer : Lorg/apache/felix/scr/impl/manager/DependencyManager$Customizer;
/*      */     //   374: aload #11
/*      */     //   376: invokeinterface setTracker : (Lorg/apache/felix/scr/impl/manager/ServiceTracker;)V
/*      */     //   381: aload_0
/*      */     //   382: iload_2
/*      */     //   383: putfield m_minCardinality : I
/*      */     //   386: aload #11
/*      */     //   388: aload_0
/*      */     //   389: getfield m_componentManager : Lorg/apache/felix/scr/impl/manager/AbstractComponentManager;
/*      */     //   392: invokevirtual getTrackingCount : ()Ljava/util/concurrent/atomic/AtomicInteger;
/*      */     //   395: invokevirtual open : (Ljava/util/concurrent/atomic/AtomicInteger;)V
/*      */     //   398: aload_0
/*      */     //   399: getfield m_customizer : Lorg/apache/felix/scr/impl/manager/DependencyManager$Customizer;
/*      */     //   402: invokeinterface setTrackerOpened : ()V
/*      */     //   407: aload #5
/*      */     //   409: ifnull -> 419
/*      */     //   412: aload #5
/*      */     //   414: aload #7
/*      */     //   416: invokevirtual completeClose : (Ljava/util/Map;)V
/*      */     //   419: aload_0
/*      */     //   420: getfield m_componentManager : Lorg/apache/felix/scr/impl/manager/AbstractComponentManager;
/*      */     //   423: invokevirtual getLogger : ()Lorg/apache/felix/scr/impl/logger/ComponentLogger;
/*      */     //   426: getstatic org/apache/felix/scr/impl/logger/InternalLogger$Level.DEBUG : Lorg/apache/felix/scr/impl/logger/InternalLogger$Level;
/*      */     //   429: ldc 'registering service listener for dependency {0}'
/*      */     //   431: aconst_null
/*      */     //   432: iconst_1
/*      */     //   433: anewarray java/lang/Object
/*      */     //   436: dup
/*      */     //   437: iconst_0
/*      */     //   438: aload_0
/*      */     //   439: invokevirtual getName : ()Ljava/lang/String;
/*      */     //   442: aastore
/*      */     //   443: invokeinterface log : (Lorg/apache/felix/scr/impl/logger/InternalLogger$Level;Ljava/lang/String;Ljava/lang/Throwable;[Ljava/lang/Object;)V
/*      */     //   448: return
/*      */     // Line number table:
/*      */     //   Java source line number -> byte code offset
/*      */     //   #2360	-> 0
/*      */     //   #2362	-> 4
/*      */     //   #2365	-> 12
/*      */     //   #2367	-> 41
/*      */     //   #2369	-> 61
/*      */     //   #2367	-> 83
/*      */     //   #2370	-> 88
/*      */     //   #2372	-> 95
/*      */     //   #2373	-> 100
/*      */     //   #2376	-> 101
/*      */     //   #2380	-> 105
/*      */     //   #2390	-> 110
/*      */     //   #2382	-> 113
/*      */     //   #2384	-> 114
/*      */     //   #2386	-> 134
/*      */     //   #2384	-> 142
/*      */     //   #2389	-> 147
/*      */     //   #2392	-> 150
/*      */     //   #2400	-> 155
/*      */     //   #2403	-> 160
/*      */     //   #2406	-> 168
/*      */     //   #2407	-> 174
/*      */     //   #2408	-> 183
/*      */     //   #2409	-> 191
/*      */     //   #2412	-> 200
/*      */     //   #2414	-> 212
/*      */     //   #2416	-> 232
/*      */     //   #2414	-> 240
/*      */     //   #2417	-> 245
/*      */     //   #2419	-> 254
/*      */     //   #2420	-> 265
/*      */     //   #2421	-> 285
/*      */     //   #2423	-> 305
/*      */     //   #2421	-> 331
/*      */     //   #2425	-> 336
/*      */     //   #2426	-> 342
/*      */     //   #2427	-> 358
/*      */     //   #2429	-> 370
/*      */     //   #2431	-> 381
/*      */     //   #2433	-> 386
/*      */     //   #2434	-> 398
/*      */     //   #2435	-> 407
/*      */     //   #2437	-> 412
/*      */     //   #2439	-> 419
/*      */     //   #2441	-> 439
/*      */     //   #2439	-> 443
/*      */     //   #2442	-> 448
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	descriptor
/*      */     //   114	36	3	e	Lorg/osgi/framework/InvalidSyntaxException;
/*      */     //   0	449	0	this	Lorg/apache/felix/scr/impl/manager/DependencyManager;
/*      */     //   0	449	1	target	Ljava/lang/String;
/*      */     //   0	449	2	minimumCardinality	I
/*      */     //   160	289	3	classFilterString	Ljava/lang/String;
/*      */     //   168	281	4	initialReferenceFilterString	Ljava/lang/String;
/*      */     //   174	275	5	oldTracker	Lorg/apache/felix/scr/impl/manager/ServiceTracker;
/*      */     //   183	266	6	trackingCount	Ljava/util/concurrent/atomic/AtomicInteger;
/*      */     //   191	258	7	refMap	Ljava/util/SortedMap;
/*      */     //   254	195	8	bundleContext	Lorg/osgi/framework/BundleContext;
/*      */     //   285	164	9	initialActive	Z
/*      */     //   342	107	10	trueReference	Lorg/osgi/framework/ServiceReference;
/*      */     //   370	79	11	tracker	Lorg/apache/felix/scr/impl/manager/ServiceTracker;
/*      */     // Local variable type table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	449	0	this	Lorg/apache/felix/scr/impl/manager/DependencyManager<TS;TT;>;
/*      */     //   174	275	5	oldTracker	Lorg/apache/felix/scr/impl/manager/ServiceTracker<TT;Lorg/apache/felix/scr/impl/inject/RefPair<TS;TT;>;Lorg/apache/felix/scr/impl/manager/ExtendedServiceEvent;>;
/*      */     //   191	258	7	refMap	Ljava/util/SortedMap<Lorg/osgi/framework/ServiceReference<TT;>;Lorg/apache/felix/scr/impl/inject/RefPair<TS;TT;>;>;
/*      */     //   342	107	10	trueReference	Lorg/osgi/framework/ServiceReference<TT;>;
/*      */     //   370	79	11	tracker	Lorg/apache/felix/scr/impl/manager/ServiceTracker<TT;Lorg/apache/felix/scr/impl/inject/RefPair<TS;TT;>;Lorg/apache/felix/scr/impl/manager/ExtendedServiceEvent;>;
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   105	110	113	org/osgi/framework/InvalidSyntaxException
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private String getClassFilter() {
/* 2446 */     String objectClass = this.m_dependencyMetadata.getInterface();
/* 2447 */     if ("org.osgi.service.component.AnyService".equals(objectClass))
/*      */     {
/* 2449 */       objectClass = "*";
/*      */     }
/* 2451 */     StringBuilder classFilterSB = new StringBuilder();
/* 2452 */     classFilterSB.append("(objectClass=");
/* 2453 */     classFilterSB.append(objectClass);
/* 2454 */     classFilterSB.append(')');
/* 2455 */     return classFilterSB.toString();
/*      */   }
/*      */ 
/*      */   
/*      */   private String getInitialReferenceFilter(String classFilterString, String target) {
/* 2460 */     if (target == null)
/*      */     {
/* 2462 */       if ("org.osgi.service.component.AnyService".equals(this.m_dependencyMetadata
/* 2463 */           .getInterface())) {
/*      */         
/* 2465 */         this.m_componentManager.getLogger().log(InternalLogger.Level.ERROR, "The dependency reference {0} is an AnyService reference with no target specified.", null, new Object[] {
/*      */               
/* 2467 */               getName() });
/* 2468 */         target = "(&(invalid.target.cannot.resolve=*)(!(invalid.target.cannot.resolve=*)))";
/*      */       } 
/*      */     }
/*      */     
/* 2472 */     boolean multipleExpr = (target != null || this.m_dependencyMetadata.getScope() == ReferenceMetadata.ReferenceScope.prototype_required);
/* 2473 */     StringBuilder initialReferenceFilterSB = new StringBuilder();
/* 2474 */     if (multipleExpr)
/*      */     {
/* 2476 */       initialReferenceFilterSB.append("(&");
/*      */     }
/* 2478 */     initialReferenceFilterSB.append(classFilterString);
/*      */ 
/*      */ 
/*      */     
/* 2482 */     if (this.m_dependencyMetadata.getScope() == ReferenceMetadata.ReferenceScope.prototype_required)
/*      */     {
/* 2484 */       initialReferenceFilterSB.append("(service.scope=prototype)");
/*      */     }
/*      */ 
/*      */     
/* 2488 */     if (target != null)
/*      */     {
/* 2490 */       initialReferenceFilterSB.append(target);
/*      */     }
/* 2492 */     if (multipleExpr)
/*      */     {
/* 2494 */       initialReferenceFilterSB.append(')');
/*      */     }
/* 2496 */     return initialReferenceFilterSB.toString();
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private ServiceReference<T> getTrueConditionRef() {
/* 2502 */     if (this.m_dependencyMetadata.getScope() == ReferenceMetadata.ReferenceScope.prototype_required)
/*      */     {
/* 2504 */       return null;
/*      */     }
/* 2506 */     if (!"osgi.ds.satisfying.condition".equals(this.m_dependencyMetadata
/* 2507 */         .getName()))
/*      */     {
/* 2509 */       return null;
/*      */     }
/* 2511 */     if (!"(osgi.condition.id=true)".equals(this.m_target))
/*      */     {
/* 2513 */       return null;
/*      */     }
/* 2515 */     if (!"org.osgi.service.condition.Condition".equals(this.m_dependencyMetadata
/* 2516 */         .getInterface()))
/*      */     {
/* 2518 */       return null;
/*      */     }
/* 2520 */     return (ServiceReference)this.m_componentManager.getActivator().getTrueCondition();
/*      */   }
/*      */ 
/*      */   
/*      */   private Customizer<S, T> newCustomizer() {
/*      */     Customizer<S, T> customizer;
/* 2526 */     if (!hasGetPermission()) {
/*      */       
/* 2528 */       customizer = new NoPermissionsCustomizer();
/* 2529 */       this.m_componentManager.getLogger().log(InternalLogger.Level.INFO, "No permission to get services for {0}", null, new Object[] {
/*      */             
/* 2531 */             getName()
/*      */           });
/* 2533 */     } else if (this.m_componentManager.isFactory()) {
/*      */       
/* 2535 */       customizer = new FactoryCustomizer();
/*      */     }
/* 2537 */     else if (isMultiple()) {
/*      */       
/* 2539 */       if (isStatic()) {
/*      */         
/* 2541 */         if (isReluctant())
/*      */         {
/* 2543 */           customizer = new MultipleStaticReluctantCustomizer();
/*      */         }
/*      */         else
/*      */         {
/* 2547 */           customizer = new MultipleStaticGreedyCustomizer();
/*      */         }
/*      */       
/*      */       } else {
/*      */         
/* 2552 */         customizer = new MultipleDynamicCustomizer();
/*      */       
/*      */       }
/*      */     
/*      */     }
/* 2557 */     else if (isStatic()) {
/*      */       
/* 2559 */       customizer = new SingleStaticCustomizer();
/*      */     }
/*      */     else {
/*      */       
/* 2563 */       customizer = new SingleDynamicCustomizer();
/*      */     } 
/*      */     
/* 2566 */     return customizer;
/*      */   }
/*      */ 
/*      */   
/*      */   SortedMap<ServiceReference<T>, RefPair<S, T>> unregisterServiceListener(AtomicInteger trackingCount) {
/*      */     SortedMap<ServiceReference<T>, RefPair<S, T>> refMap;
/* 2572 */     ServiceTracker<T, RefPair<S, T>, ExtendedServiceEvent> tracker = this.m_tracker;
/* 2573 */     if (tracker != null) {
/*      */       
/* 2575 */       refMap = tracker.close(trackingCount);
/* 2576 */       this.m_tracker = null;
/* 2577 */       this.m_componentManager.getLogger().log(InternalLogger.Level.DEBUG, "unregistering service listener for dependency {0}", null, new Object[] {
/*      */             
/* 2579 */             getName()
/*      */           });
/*      */     } else {
/*      */       
/* 2583 */       refMap = new TreeMap<>(Collections.reverseOrder());
/* 2584 */       this.m_componentManager.getLogger().log(InternalLogger.Level.DEBUG, " No existing service listener to unregister for dependency {0}", null, new Object[] {
/* 2585 */             getName() });
/* 2586 */       trackingCount.set(-1);
/*      */     } 
/*      */     
/* 2589 */     return refMap;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getTarget() {
/* 2598 */     return this.m_target;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public String toString() {
/* 2604 */     return "DependencyManager: Component [" + this.m_componentManager + "] reference [" + getName() + "]";
/*      */   }
/*      */ 
/*      */   
/*      */   boolean getServiceObject(ComponentContextImpl<S> key, ReferenceMethod bindMethod, RefPair<S, T> refPair) {
/* 2609 */     BundleContext bundleContext = this.m_componentManager.getBundleContext();
/* 2610 */     if (bundleContext != null)
/*      */     {
/* 2612 */       return bindMethod.getServiceObject(new BindParameters(key, refPair), bundleContext);
/*      */     }
/*      */ 
/*      */     
/* 2616 */     refPair.markFailed();
/* 2617 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   RefPair<S, T> newRefPair(ServiceReference<T> serviceReference) {
/* 2623 */     if (this.m_dependencyMetadata.getScope() == ReferenceMetadata.ReferenceScope.bundle)
/*      */     {
/* 2625 */       return new SingleRefPair<>(serviceReference);
/*      */     }
/* 2627 */     if (this.m_componentManager.getComponentMetadata().getServiceScope() == ServiceMetadata.Scope.singleton)
/*      */     {
/* 2629 */       return new SinglePrototypeRefPair<>(serviceReference);
/*      */     }
/* 2631 */     return new MultiplePrototypeRefPair<>(serviceReference);
/*      */   }
/*      */ 
/*      */   
/*      */   private void deactivateComponentManager() {
/* 2636 */     this.m_componentManager.deactivateInternal(2, false, false);
/*      */   }
/*      */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.apache.felix.scr-2.2.6.jar!\org\apache\felix\scr\impl\manager\DependencyManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */