/*    */ package org.apache.felix.scr.impl.inject;
/*    */ 
/*    */ import java.util.Map;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MethodResult
/*    */ {
/* 39 */   public static final MethodResult VOID = new MethodResult(false, null);
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 44 */   public static final MethodResult REACTIVATE = new MethodResult(false, null);
/*    */ 
/*    */   
/*    */   private final Map<String, Object> result;
/*    */ 
/*    */   
/*    */   private final boolean hasResult;
/*    */ 
/*    */ 
/*    */   
/*    */   public MethodResult(boolean hasResult, Map<String, Object> result) {
/* 55 */     this.hasResult = hasResult;
/* 56 */     this.result = result;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean hasResult() {
/* 61 */     return this.hasResult;
/*    */   }
/*    */ 
/*    */   
/*    */   public Map<String, Object> getResult() {
/* 66 */     return this.result;
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.apache.felix.scr-2.2.6.jar!\org\apache\felix\scr\impl\inject\MethodResult.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */