/*     */ package org.apache.felix.scr.impl;
/*     */ 
/*     */ import java.lang.reflect.InvocationHandler;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Proxy;
/*     */ import java.text.MessageFormat;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.Comparator;
/*     */ import java.util.Dictionary;
/*     */ import java.util.HashMap;
/*     */ import java.util.Hashtable;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.SortedMap;
/*     */ import java.util.TreeMap;
/*     */ import org.apache.felix.scr.impl.manager.ScrConfiguration;
/*     */ import org.apache.felix.scr.info.ScrInfo;
/*     */ import org.apache.felix.service.command.Descriptor;
/*     */ import org.osgi.framework.Bundle;
/*     */ import org.osgi.framework.BundleContext;
/*     */ import org.osgi.framework.InvalidSyntaxException;
/*     */ import org.osgi.framework.ServiceReference;
/*     */ import org.osgi.framework.ServiceRegistration;
/*     */ import org.osgi.framework.dto.ServiceReferenceDTO;
/*     */ import org.osgi.framework.wiring.BundleRevision;
/*     */ import org.osgi.framework.wiring.BundleWiring;
/*     */ import org.osgi.service.component.ComponentFactory;
/*     */ import org.osgi.service.component.runtime.ServiceComponentRuntime;
/*     */ import org.osgi.service.component.runtime.dto.ComponentConfigurationDTO;
/*     */ import org.osgi.service.component.runtime.dto.ComponentDescriptionDTO;
/*     */ import org.osgi.service.component.runtime.dto.ReferenceDTO;
/*     */ import org.osgi.service.component.runtime.dto.SatisfiedReferenceDTO;
/*     */ import org.osgi.service.component.runtime.dto.UnsatisfiedReferenceDTO;
/*     */ import org.osgi.util.tracker.ServiceTracker;
/*     */ import org.osgi.util.tracker.ServiceTrackerCustomizer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ComponentCommands
/*     */   implements ServiceTrackerCustomizer<Object, ServiceRegistration<?>>
/*     */ {
/*     */   private static final String INDENT_1 = "  ";
/*     */   private static final String INDENT_2 = "    ";
/*     */   private final BundleContext context;
/*     */   private final ServiceComponentRuntime scr;
/*     */   private final ScrConfiguration scrConfig;
/*     */   private final ServiceTracker<Object, ServiceRegistration<?>> gogoRuntimeTracker;
/*     */   
/*  75 */   private final Comparator<ComponentConfigurationDTO> configDtoComparator = new Comparator<ComponentConfigurationDTO>()
/*     */     {
/*     */       public int compare(ComponentConfigurationDTO o1, ComponentConfigurationDTO o2) {
/*  78 */         long diff = o1.id - o2.id;
/*  79 */         return (diff == 0L) ? 0 : (int)(diff / Math.abs(diff));
/*     */       }
/*     */     };
/*  82 */   private final Comparator<ServiceReferenceDTO> serviceRefDtoComparator = new Comparator<ServiceReferenceDTO>()
/*     */     {
/*     */       public int compare(ServiceReferenceDTO o1, ServiceReferenceDTO o2) {
/*  85 */         long diff = o1.id - o2.id;
/*  86 */         return (diff == 0L) ? 0 : (int)(diff / Math.abs(diff));
/*     */       }
/*     */     };
/*     */   
/*  90 */   private ServiceRegistration<ComponentCommands> commandsReg = null;
/*  91 */   private ServiceRegistration<ScrInfo> scrInfoReg = null;
/*     */   
/*     */   synchronized void register() {
/*  94 */     if (this.commandsReg != null) {
/*  95 */       throw new IllegalStateException("Component Commands already registered");
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 100 */     Dictionary<String, Object> svcProps = new Hashtable<>();
/* 101 */     svcProps.put("osgi.command.scope", "scr");
/* 102 */     svcProps.put("osgi.command.function", new String[] { "config", "disable", "enable", "info", "list" });
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 109 */     svcProps.put("service.description", "SCR Gogo Shell Support");
/* 110 */     svcProps.put("service.vendor", "The Apache Software Foundation");
/* 111 */     this.commandsReg = this.context.registerService(ComponentCommands.class, this, svcProps);
/*     */     
/* 113 */     this.gogoRuntimeTracker.open(true);
/*     */   }
/*     */   
/*     */   synchronized void unregister() {
/* 117 */     this.gogoRuntimeTracker.close();
/* 118 */     safeUnregister(this.commandsReg);
/* 119 */     safeUnregister(this.scrInfoReg);
/*     */   }
/*     */   
/*     */   public synchronized void updateProvideScrInfoService(boolean register) {
/* 123 */     if (register) {
/* 124 */       if (this.scrInfoReg == null) {
/* 125 */         Dictionary<String, Object> svcProps = new Hashtable<>();
/* 126 */         svcProps.put("service.description", "SCR Info Service");
/* 127 */         svcProps.put("service.vendor", "The Apache Software Foundation");
/* 128 */         this.scrInfoReg = this.context.registerService(ScrInfo.class, new ComponentCommandsScrInfo(this, this.context), svcProps);
/*     */       } 
/*     */     } else {
/* 131 */       safeUnregister(this.scrInfoReg);
/* 132 */       this.scrInfoReg = null;
/*     */     } 
/*     */   }
/*     */   
/*     */   protected ComponentCommands(BundleContext context, ServiceComponentRuntime scr, ScrConfiguration scrConfig) {
/* 137 */     this.context = context;
/* 138 */     this.scr = scr;
/* 139 */     this.scrConfig = scrConfig;
/* 140 */     this.gogoRuntimeTracker = new ServiceTracker(context, "org.apache.felix.service.command.CommandProcessor", this);
/*     */   }
/*     */   
/*     */   @Descriptor("List all components")
/*     */   public ComponentDescriptionDTO[] list() {
/* 145 */     ComponentDescriptionDTO[] result = (ComponentDescriptionDTO[])this.scr.getComponentDescriptionDTOs(new Bundle[0]).toArray((Object[])new ComponentDescriptionDTO[0]);
/* 146 */     Arrays.sort(result, new Comparator<ComponentDescriptionDTO>()
/*     */         {
/*     */           public int compare(ComponentDescriptionDTO c1, ComponentDescriptionDTO c2) {
/* 149 */             return Long.compare(c1.bundle.id, c2.bundle.id);
/*     */           }
/*     */         });
/* 152 */     return result;
/*     */   }
/*     */   
/*     */   @Descriptor("List components of a specific bundle")
/*     */   public ComponentDescriptionDTO[] list(@Descriptor("ID of the bundle") long bundleId) {
/* 157 */     Bundle bundle = this.context.getBundle(bundleId);
/* 158 */     return (bundle != null) ? (ComponentDescriptionDTO[])this.scr.getComponentDescriptionDTOs(new Bundle[] { bundle }).toArray((Object[])new ComponentDescriptionDTO[0]) : null;
/*     */   }
/*     */   
/*     */   private List<ComponentDescriptionDTO> findComponents(String name) {
/* 162 */     String lowerName = name.toLowerCase();
/* 163 */     List<ComponentDescriptionDTO> matches = new LinkedList<>();
/* 164 */     for (ComponentDescriptionDTO dto : this.scr.getComponentDescriptionDTOs(new Bundle[0])) {
/* 165 */       if (dto.name.equalsIgnoreCase(name))
/*     */       {
/* 167 */         return Collections.singletonList(dto);
/*     */       }
/* 169 */       if (dto.name.toLowerCase().contains(lowerName))
/* 170 */         matches.add(dto); 
/*     */     } 
/* 172 */     return matches;
/*     */   }
/*     */   
/*     */   @Descriptor("Dump information of a component")
/*     */   public ComponentDescriptionDTO info(@Descriptor("Name of the component") String name) {
/* 177 */     List<ComponentDescriptionDTO> matches = findComponents(name);
/* 178 */     if (matches.isEmpty())
/* 179 */       throw new IllegalArgumentException(MessageFormat.format("No component description matching \"{0}\".", new Object[] { name })); 
/* 180 */     if (matches.size() > 1) {
/* 181 */       StringBuilder partialMatchesStr = new StringBuilder();
/* 182 */       for (Iterator<ComponentDescriptionDTO> iter = matches.iterator(); iter.hasNext(); ) {
/* 183 */         partialMatchesStr.append(((ComponentDescriptionDTO)iter.next()).name);
/* 184 */         if (iter.hasNext()) partialMatchesStr.append(", "); 
/*     */       } 
/* 186 */       throw new IllegalArgumentException(MessageFormat.format("Multiple components matching \"{0}\": [{1}]", new Object[] { name, partialMatchesStr }));
/*     */     } 
/* 188 */     return matches.get(0);
/*     */   }
/*     */   
/*     */   @Descriptor("Dump information of a component configuration")
/*     */   public ComponentConfigurationDTO info(@Descriptor("ID of the component configuration") long id) {
/* 193 */     for (ComponentDescriptionDTO descDto : this.scr.getComponentDescriptionDTOs(new Bundle[0])) {
/* 194 */       for (ComponentConfigurationDTO configDto : this.scr.getComponentConfigurationDTOs(descDto)) {
/* 195 */         if (configDto.id == id)
/* 196 */           return configDto; 
/*     */       } 
/*     */     } 
/* 199 */     return null;
/*     */   }
/*     */   
/*     */   @Descriptor("Enable a disabled component")
/*     */   public boolean enable(@Descriptor("Name of the component") String name) {
/* 204 */     boolean changed = false;
/* 205 */     for (ComponentDescriptionDTO comp : findComponents(name)) {
/* 206 */       if (!this.scr.isComponentEnabled(comp)) {
/* 207 */         this.scr.enableComponent(comp);
/* 208 */         changed = true;
/*     */       } 
/*     */     } 
/* 211 */     return changed;
/*     */   }
/*     */   
/*     */   @Descriptor("Disable an enabled component")
/*     */   public boolean disable(@Descriptor("Name of the component") String name) {
/* 216 */     boolean changed = false;
/* 217 */     for (ComponentDescriptionDTO comp : findComponents(name)) {
/* 218 */       if (this.scr.isComponentEnabled(comp)) {
/* 219 */         this.scr.disableComponent(comp);
/* 220 */         changed = true;
/*     */       } 
/*     */     } 
/* 223 */     return changed;
/*     */   }
/*     */ 
/*     */   
/*     */   @Descriptor("Show the current SCR configuration")
/*     */   public String config() {
/* 229 */     Map<String, String> out = new LinkedHashMap<>();
/* 230 */     out.put("Log Level", this.scrConfig.getLogLevel().toString());
/* 231 */     out.put("Obsolete Component Factory with Factory Configuration", Boolean.toString(this.scrConfig.isFactoryEnabled()));
/* 232 */     out.put("Keep instances with no references", this.scrConfig.keepInstances() ? "Supported" : "Unsupported");
/* 233 */     out.put("Lock timeout ms", Long.toString(this.scrConfig.lockTimeout()));
/* 234 */     out.put("Stop timeout ms", Long.toString(this.scrConfig.stopTimeout()));
/* 235 */     out.put("Global extender", Boolean.toString(this.scrConfig.globalExtender()));
/* 236 */     out.put("Info Service registered", this.scrConfig.infoAsService() ? "Supported" : "Unsupported");
/*     */     
/* 238 */     StringBuilder builder = new StringBuilder();
/* 239 */     printColumnsAligned("SCR Configuration", out, '=', builder);
/* 240 */     return builder.toString();
/*     */   }
/*     */   
/*     */   public Object convert(Class<?> desiredType, Object in) throws Exception {
/* 244 */     return null;
/*     */   }
/*     */   
/*     */   public CharSequence format(Object target, int level) throws Exception {
/*     */     CharSequence result;
/* 249 */     if (target instanceof ComponentDescriptionDTO[]) {
/* 250 */       result = format((ComponentDescriptionDTO[])target, level);
/* 251 */     } else if (target instanceof ComponentDescriptionDTO) {
/* 252 */       result = format((ComponentDescriptionDTO)target, level);
/* 253 */     } else if (target instanceof ComponentConfigurationDTO) {
/* 254 */       result = format((ComponentConfigurationDTO)target, level);
/*     */     } else {
/* 256 */       result = null;
/*     */     } 
/* 258 */     return result;
/*     */   }
/*     */   
/*     */   CharSequence format(ComponentDescriptionDTO[] dtoArray, int level) throws Exception {
/* 262 */     StringBuilder sb = new StringBuilder();
/* 263 */     if (dtoArray == null || dtoArray.length == 0) {
/* 264 */       sb.append("No component descriptions found");
/*     */     } else {
/* 266 */       for (int i = 0; i < dtoArray.length; i++) {
/* 267 */         if (i > 0) sb.append('\n'); 
/* 268 */         sb.append(format(dtoArray[i], 1));
/*     */       } 
/*     */     } 
/* 271 */     return sb;
/*     */   }
/*     */   CharSequence format(ComponentDescriptionDTO dto, int level) throws Exception {
/*     */     List<ComponentConfigurationDTO> children;
/* 275 */     StringBuilder builder = new StringBuilder();
/*     */ 
/*     */ 
/*     */     
/* 279 */     Collection<ComponentConfigurationDTO> childrenTmp = this.scr.getComponentConfigurationDTOs(dto);
/* 280 */     if (childrenTmp == null) {
/* 281 */       children = Collections.emptyList();
/*     */     } else {
/* 283 */       children = new ArrayList<>(childrenTmp);
/* 284 */       Collections.sort(children, this.configDtoComparator);
/*     */     } 
/*     */     
/* 287 */     switch (level) {
/*     */       case 1:
/* 289 */         builder.append(MessageFormat.format("{0} in bundle {1} ({2}:{3}) {4}, {5,choice,0#0 instances|1#1 instance|1<{5} instances}.", new Object[] { dto.name, 
/*     */                 
/* 291 */                 Long.valueOf(dto.bundle.id), dto.bundle.symbolicName, dto.bundle.version, 
/*     */ 
/*     */                 
/* 294 */                 dto.defaultEnabled ? "enabled" : "disabled", 
/* 295 */                 Integer.valueOf(children.size()) }));
/*     */ 
/*     */         
/* 298 */         for (ComponentConfigurationDTO child : children)
/* 299 */           builder.append("\n").append("    ").append(format(child, 1)); 
/*     */         break;
/*     */       case 0:
/* 302 */         printComponentDescriptionAndConfigs(dto, children.<ComponentConfigurationDTO>toArray(new ComponentConfigurationDTO[0]), builder);
/*     */         break;
/*     */     } 
/*     */ 
/*     */     
/* 307 */     return builder;
/*     */   }
/*     */   CharSequence format(ComponentConfigurationDTO dto, int level) throws Exception {
/*     */     String[] pids;
/* 311 */     StringBuilder builder = new StringBuilder();
/* 312 */     switch (level) {
/*     */       case 0:
/* 314 */         printComponentDescriptionAndConfigs(dto.description, new ComponentConfigurationDTO[] { dto }, builder);
/*     */         break;
/*     */       case 1:
/* 317 */         builder.append("Id: ").append(dto.id);
/* 318 */         builder.append(", ").append("State:").append(stateToString(dto.state));
/* 319 */         pids = getStringArray(dto.properties, "service.pid", null);
/* 320 */         if (pids != null && pids.length > 0) {
/* 321 */           builder.append(", ").append("PID(s): ").append(Arrays.toString((Object[])pids));
/*     */         }
/*     */         break;
/*     */     } 
/*     */ 
/*     */     
/* 327 */     return builder;
/*     */   }
/*     */   
/*     */   void printComponentDescriptionAndConfigs(ComponentDescriptionDTO descDto, ComponentConfigurationDTO[] configs, StringBuilder builder) {
/* 331 */     Map<String, String> out = new LinkedHashMap<>();
/*     */ 
/*     */     
/* 334 */     out.put("Class", descDto.implementationClass);
/* 335 */     out.put("Bundle", String.format("%d (%s:%s)", new Object[] { Long.valueOf(descDto.bundle.id), descDto.bundle.symbolicName, descDto.bundle.version }));
/* 336 */     out.put("Enabled", Boolean.toString(descDto.defaultEnabled));
/* 337 */     out.put("Immediate", Boolean.toString(descDto.immediate));
/* 338 */     out.put("Services", arrayToString(descDto.serviceInterfaces));
/* 339 */     if (descDto.scope != null) {
/* 340 */       out.put("Scope", descDto.scope);
/*     */     }
/* 342 */     out.put("Config PID(s)", String.format("%s, Policy: %s", new Object[] { arrayToString(descDto.configurationPid), descDto.configurationPolicy }));
/* 343 */     out.put("Base Props", printProperties(descDto.properties, "  "));
/* 344 */     if (descDto.factory != null) {
/* 345 */       out.put("Factory", descDto.factory);
/*     */       try {
/* 347 */         ServiceReference[] arrayOfServiceReference = this.context.getAllServiceReferences(ComponentFactory.class.getName(), String.format("(&(%s=%s)(%s=%d))", new Object[] { "component.name", descDto.name, "service.bundleid", Long.valueOf(descDto.bundle.id) }));
/* 348 */         if (arrayOfServiceReference != null && arrayOfServiceReference.length > 0) {
/* 349 */           out.put("Factory Service", printPublishedServices((ServiceReference<?>[])arrayOfServiceReference));
/*     */         }
/* 351 */       } catch (InvalidSyntaxException invalidSyntaxException) {}
/*     */     } 
/*     */ 
/*     */     
/* 355 */     printColumnsAligned(String.format("Component Description: %s", new Object[] { descDto.name }), out, '=', builder);
/*     */     
/* 357 */     if (configs != null) for (ComponentConfigurationDTO configDto : configs) {
/* 358 */         out.clear();
/*     */ 
/*     */         
/* 361 */         builder.append("\n\n");
/*     */ 
/*     */         
/* 364 */         String title = String.format("Component Configuration Id: %d", new Object[] { Long.valueOf(configDto.id) });
/* 365 */         out.put("State", stateToString(configDto.state));
/*     */ 
/*     */         
/*     */         try {
/* 369 */           ServiceReference[] arrayOfServiceReference = this.context.getAllServiceReferences(null, String.format("(%s=%d)", new Object[] { "component.id", Long.valueOf(configDto.id) }));
/* 370 */           if (arrayOfServiceReference != null && arrayOfServiceReference.length > 0) {
/* 371 */             out.put("Service", printPublishedServices((ServiceReference<?>[])arrayOfServiceReference));
/*     */           }
/* 373 */         } catch (InvalidSyntaxException invalidSyntaxException) {}
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 378 */         out.put("Config Props", printProperties(configDto.properties, "  "));
/*     */ 
/*     */         
/* 381 */         out.put("References", printServiceReferences(configDto.satisfiedReferences, configDto.unsatisfiedReferences, descDto.references));
/*     */ 
/*     */         
/* 384 */         if (configDto.failure != null) {
/* 385 */           out.put("Failure", configDto.failure);
/*     */         }
/* 387 */         printColumnsAligned(title, out, '-', builder);
/*     */       }  
/*     */   }
/*     */   
/*     */   String printPublishedServices(ServiceReference<?>[] serviceRefs) {
/* 392 */     StringBuilder sb = new StringBuilder();
/*     */     
/* 394 */     if (serviceRefs.length > 1) {
/* 395 */       sb.append("(total ").append(serviceRefs.length).append(')');
/* 396 */       sb.append('\n').append("  ");
/*     */     } 
/*     */     
/* 399 */     for (ServiceReference<?> serviceRef : serviceRefs) {
/* 400 */       sb.append(serviceRef.getProperty("service.id"));
/* 401 */       sb.append(' ').append(Arrays.toString((Object[])serviceRef.getProperty("objectClass")));
/* 402 */       Bundle[] consumers = serviceRef.getUsingBundles();
/* 403 */       if (consumers != null) for (Bundle consumer : consumers) {
/* 404 */           sb.append("\n").append("    ");
/* 405 */           sb.append(String.format("Used by bundle %d (%s:%s)", new Object[] { Long.valueOf(consumer.getBundleId()), consumer.getSymbolicName(), consumer.getVersion() }));
/*     */         } 
/*     */     
/*     */     } 
/* 409 */     return sb.toString();
/*     */   }
/*     */   
/*     */   private String arrayToString(String[] array) {
/* 413 */     return (array == null || array.length == 0) ? "<<none>>" : Arrays.toString((Object[])array);
/*     */   }
/*     */ 
/*     */   
/*     */   static final String stateToString(int state) {
/* 418 */     switch (state)
/*     */     { case 8:
/* 420 */         string = "ACTIVE";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 437 */         return string;case 4: string = "SATISFIED"; return string;case 1: string = "UNSATISFIED CONFIGURATION"; return string;case 2: string = "UNSATISFIED REFERENCE"; return string;case 16: string = "FAILED ACTIVATION"; return string; }  String string = String.format("<<UNKNOWN: %d>>", new Object[] { Integer.valueOf(state) }); return string;
/*     */   }
/*     */   
/*     */   static String printProperties(Map<String, ?> props, String indent) {
/* 441 */     StringBuilder builder = new StringBuilder();
/* 442 */     int size = props.size();
/* 443 */     builder.append('(').append(Integer.toString(size)).append(' ').append((size == 1) ? "entry" : "entries").append(')');
/* 444 */     if (size > 0) {
/* 445 */       SortedMap<String, ?> sortedMap = new TreeMap<>(props);
/* 446 */       for (Map.Entry<String, ?> e : sortedMap.entrySet()) {
/* 447 */         String typeName, valueStr; builder.append('\n').append(indent);
/*     */         
/* 449 */         Object value = e.getValue();
/*     */ 
/*     */ 
/*     */         
/* 453 */         if (value == null) {
/* 454 */           typeName = valueStr = "null";
/*     */         } else {
/* 456 */           typeName = value.getClass().getSimpleName();
/* 457 */           if (value instanceof int[]) {
/* 458 */             valueStr = Arrays.toString((int[])value);
/* 459 */           } else if (value instanceof long[]) {
/* 460 */             valueStr = Arrays.toString((long[])value);
/* 461 */           } else if (value instanceof byte[]) {
/* 462 */             valueStr = Arrays.toString((byte[])value);
/* 463 */           } else if (value instanceof short[]) {
/* 464 */             valueStr = Arrays.toString((short[])value);
/* 465 */           } else if (value instanceof byte[]) {
/* 466 */             valueStr = Arrays.toString((byte[])value);
/* 467 */           } else if (value instanceof char[]) {
/* 468 */             valueStr = Arrays.toString((char[])value);
/* 469 */           } else if (value instanceof boolean[]) {
/* 470 */             valueStr = Arrays.toString((boolean[])value);
/* 471 */           } else if (value instanceof float[]) {
/* 472 */             valueStr = Arrays.toString((boolean[])value);
/* 473 */           } else if (value instanceof double[]) {
/* 474 */             valueStr = Arrays.toString((boolean[])value);
/* 475 */           } else if (value instanceof Object[]) {
/* 476 */             valueStr = Arrays.deepToString((Object[])value);
/*     */           } else {
/* 478 */             valueStr = value.toString();
/*     */           } 
/* 480 */         }  builder.append(String.format("%s<%s> = %s", new Object[] { e.getKey(), typeName, valueStr }));
/*     */       } 
/*     */     } 
/* 483 */     return builder.toString();
/*     */   }
/*     */   
/*     */   String printServiceReferences(SatisfiedReferenceDTO[] satisfiedReferences, UnsatisfiedReferenceDTO[] unsatisfiedReferences, ReferenceDTO[] references) {
/* 487 */     StringBuilder builder = new StringBuilder();
/* 488 */     Map<String, ReferenceDTO> refDtoMap = new HashMap<>();
/* 489 */     if (references != null) {
/* 490 */       for (ReferenceDTO refDto : references) {
/* 491 */         refDtoMap.put(refDto.name, refDto);
/*     */       }
/*     */     }
/* 494 */     int refCount = ((satisfiedReferences != null) ? satisfiedReferences.length : 0) + ((unsatisfiedReferences != null) ? unsatisfiedReferences.length : 0);
/* 495 */     builder.append("(total ").append(Integer.toString(refCount)).append(")");
/* 496 */     if (unsatisfiedReferences != null)
/* 497 */       for (UnsatisfiedReferenceDTO refDto : unsatisfiedReferences) {
/* 498 */         printServiceReference(refDtoMap.get(refDto.name), "UNSATISFIED", null, builder);
/*     */       } 
/* 500 */     if (satisfiedReferences != null)
/* 501 */       for (SatisfiedReferenceDTO refDto : satisfiedReferences) {
/* 502 */         printServiceReference(refDtoMap.get(refDto.name), "SATISFIED", (refDto.boundServices != null) ? refDto.boundServices : new ServiceReferenceDTO[0], builder);
/*     */       } 
/* 504 */     return builder.toString();
/*     */   }
/*     */   
/*     */   void printServiceReference(ReferenceDTO reference, String state, ServiceReferenceDTO[] bindings, StringBuilder builder) {
/* 508 */     StringBuilder policyWithOption = (new StringBuilder()).append(reference.policy);
/* 509 */     if (!"reluctant".equals(reference.policyOption)) {
/* 510 */       policyWithOption.append('+').append(reference.policyOption);
/*     */     }
/* 512 */     builder.append(String.format("%n  - %s: %s %s %s %s", new Object[] { reference.name, reference.interfaceName, state, reference.cardinality, policyWithOption }));
/* 513 */     builder.append(String.format("%n    target=%s scope=%s", new Object[] { (reference.target == null) ? "(*)" : reference.target, (reference.scope == null) ? "bundle" : reference.scope }));
/* 514 */     if (reference.collectionType != null) {
/* 515 */       builder.append(" collectionType=").append(reference.collectionType);
/*     */     }
/*     */     
/* 518 */     if (bindings != null) {
/* 519 */       Arrays.sort(bindings, this.serviceRefDtoComparator);
/* 520 */       builder.append(MessageFormat.format(" {0,choice,0#(no active bindings)|1#(1 binding):|1<({0} bindings):}", new Object[] { Integer.valueOf(bindings.length) }));
/* 521 */       for (ServiceReferenceDTO svcDto : bindings) {
/* 522 */         Bundle provider = this.context.getBundle(svcDto.bundle);
/* 523 */         builder.append(String.format("%n    * Bound to [%d] from bundle %d (%s:%s)", new Object[] { Long.valueOf(svcDto.id), Long.valueOf(svcDto.bundle), provider.getSymbolicName(), provider.getVersion() }));
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   static void printColumnsAligned(String title, Map<String, String> properties, char underlineChar, StringBuilder builder) {
/* 529 */     builder.append(title);
/*     */ 
/*     */     
/* 532 */     char[] carray = new char[title.length()];
/* 533 */     Arrays.fill(carray, underlineChar);
/* 534 */     builder.append('\n');
/* 535 */     builder.append(carray);
/*     */     
/* 537 */     int widestKey = 0;
/* 538 */     for (String key : properties.keySet()) {
/* 539 */       widestKey = Math.max(widestKey, key.length());
/*     */     }
/*     */     
/* 542 */     for (Map.Entry<String, String> e : properties.entrySet()) {
/* 543 */       String key = e.getKey();
/* 544 */       int padLength = widestKey - key.length();
/* 545 */       char[] padding = new char[padLength];
/* 546 */       Arrays.fill(padding, ' ');
/*     */       
/* 548 */       builder.append('\n');
/* 549 */       builder.append(key).append(": ");
/* 550 */       builder.append(padding);
/* 551 */       builder.append(e.getValue());
/*     */     } 
/*     */   }
/*     */   
/*     */   private static String[] getStringArray(Map<String, ?> map, String name, String[] defaultValue) throws IllegalArgumentException {
/* 556 */     Object o = map.get(name);
/* 557 */     if (o instanceof String)
/* 558 */       return new String[] { (String)o }; 
/* 559 */     if (o instanceof String[])
/* 560 */       return (String[])o; 
/* 561 */     if (o instanceof Collection) {
/* 562 */       Collection<?> c = (Collection)o;
/* 563 */       if (c.isEmpty()) {
/* 564 */         return new String[0];
/*     */       }
/* 566 */       String[] a = new String[c.size()];
/* 567 */       Iterator<?> iter = c.iterator();
/* 568 */       for (int i = 0; i < a.length; i++) {
/* 569 */         Object elem = iter.next();
/* 570 */         if (!(elem instanceof String))
/* 571 */           throw new IllegalArgumentException(String.format("Collection value for field '%s' contains non-String element at index %d.", new Object[] { name, Integer.valueOf(i) })); 
/* 572 */         a[i] = (String)elem;
/*     */       } 
/* 574 */       return a;
/*     */     } 
/* 576 */     if (o == null) {
/* 577 */       return defaultValue;
/*     */     }
/* 579 */     throw new IllegalArgumentException(String.format("Value for field '%s' is not a String, String-array or Collection of String. Actual type was %s.", new Object[] { name, o.getClass().getName() }));
/*     */   }
/*     */ 
/*     */   
/*     */   private void safeUnregister(ServiceRegistration<?> registration) {
/*     */     try {
/* 585 */       if (registration != null) registration.unregister(); 
/* 586 */     } catch (Exception exception) {}
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ServiceRegistration<?> addingService(ServiceReference<Object> reference) {
/* 593 */     Bundle b = reference.getBundle();
/* 594 */     BundleRevision rev = (b == null) ? null : (BundleRevision)b.adapt(BundleRevision.class);
/* 595 */     if (rev != null) {
/* 596 */       Object converter = createConverter(b);
/* 597 */       if (converter != null) {
/* 598 */         Dictionary<String, Object> svcProps = new Hashtable<>();
/* 599 */         svcProps.put("osgi.converter.classes", new String[] { ComponentDescriptionDTO.class
/* 600 */               .getName(), ComponentConfigurationDTO.class
/* 601 */               .getName() });
/*     */         
/* 603 */         svcProps.put("service.description", "SCR Runtime DTO Converter");
/* 604 */         svcProps.put("service.vendor", "The Apache Software Foundation");
/*     */         
/* 606 */         return b.getBundleContext().registerService("org.apache.felix.service.command.Converter", converter, svcProps);
/*     */       } 
/*     */     } 
/* 609 */     return null;
/*     */   }
/*     */   
/*     */   private Object createConverter(Bundle bundle) {
/* 613 */     BundleWiring wiring = (BundleWiring)bundle.adapt(BundleWiring.class);
/* 614 */     if (wiring != null) {
/* 615 */       ClassLoader cl = wiring.getClassLoader();
/* 616 */       if (cl != null) {
/*     */         try {
/* 618 */           Class<?>[] types = new Class[] { cl.loadClass("org.apache.felix.service.command.Converter") };
/* 619 */           return Proxy.newProxyInstance(cl, types, new InvocationHandler()
/*     */               {
/*     */                 public Object invoke(Object proxy, Method method, Object[] args) throws Throwable
/*     */                 {
/* 623 */                   if ("convert".equals(method.getName())) {
/* 624 */                     return ComponentCommands.this.convert((Class)args[0], args[1]);
/*     */                   }
/* 626 */                   if ("format".equals(method.getName())) {
/* 627 */                     return ComponentCommands.this.format(args[0], ((Integer)args[1]).intValue());
/*     */                   }
/* 629 */                   return method.invoke(this, args);
/*     */                 }
/*     */               });
/* 632 */         } catch (ClassNotFoundException classNotFoundException) {}
/*     */       }
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 638 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void modifiedService(ServiceReference<Object> reference, ServiceRegistration<?> reg) {}
/*     */ 
/*     */ 
/*     */   
/*     */   public void removedService(ServiceReference<Object> reference, ServiceRegistration<?> reg) {
/* 648 */     safeUnregister(reg);
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.apache.felix.scr-2.2.6.jar!\org\apache\felix\scr\impl\ComponentCommands.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */