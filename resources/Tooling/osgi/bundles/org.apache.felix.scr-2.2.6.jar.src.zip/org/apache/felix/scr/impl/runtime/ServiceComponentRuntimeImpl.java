/*     */ package org.apache.felix.scr.impl.runtime;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.apache.felix.scr.impl.ComponentRegistry;
/*     */ import org.apache.felix.scr.impl.manager.ComponentHolder;
/*     */ import org.apache.felix.scr.impl.manager.ComponentManager;
/*     */ import org.apache.felix.scr.impl.manager.ReferenceManager;
/*     */ import org.apache.felix.scr.impl.metadata.ComponentMetadata;
/*     */ import org.apache.felix.scr.impl.metadata.ReferenceMetadata;
/*     */ import org.osgi.dto.DTO;
/*     */ import org.osgi.framework.Bundle;
/*     */ import org.osgi.framework.BundleContext;
/*     */ import org.osgi.framework.ServiceReference;
/*     */ import org.osgi.framework.dto.BundleDTO;
/*     */ import org.osgi.framework.dto.ServiceReferenceDTO;
/*     */ import org.osgi.service.component.runtime.ServiceComponentRuntime;
/*     */ import org.osgi.service.component.runtime.dto.ComponentConfigurationDTO;
/*     */ import org.osgi.service.component.runtime.dto.ComponentDescriptionDTO;
/*     */ import org.osgi.service.component.runtime.dto.ReferenceDTO;
/*     */ import org.osgi.service.component.runtime.dto.SatisfiedReferenceDTO;
/*     */ import org.osgi.service.component.runtime.dto.UnsatisfiedReferenceDTO;
/*     */ import org.osgi.util.promise.Promise;
/*     */ import org.osgi.util.promise.Promises;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ServiceComponentRuntimeImpl
/*     */   implements ServiceComponentRuntime
/*     */ {
/*  51 */   private static final String[] EMPTY = new String[0];
/*     */   
/*     */   private final BundleContext context;
/*     */   
/*     */   private final ComponentRegistry componentRegistry;
/*     */   
/*     */   public ServiceComponentRuntimeImpl(BundleContext context, ComponentRegistry componentRegistry) {
/*  58 */     this.context = context;
/*  59 */     this.componentRegistry = componentRegistry;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Collection<ComponentDescriptionDTO> getComponentDescriptionDTOs(Bundle... bundles) {
/*     */     List<ComponentHolder<?>> holders;
/*  69 */     if (bundles == null || bundles.length == 0) {
/*     */       
/*  71 */       holders = this.componentRegistry.getComponentHolders();
/*     */     }
/*     */     else {
/*     */       
/*  75 */       holders = this.componentRegistry.getComponentHolders(bundles);
/*     */     } 
/*     */     
/*  78 */     List<ComponentDescriptionDTO> result = new ArrayList<>(holders.size());
/*  79 */     for (ComponentHolder<?> holder : holders) {
/*     */       
/*  81 */       ComponentDescriptionDTO dto = holderToDescription(holder);
/*  82 */       if (dto != null)
/*     */       {
/*  84 */         result.add(dto);
/*     */       }
/*     */     } 
/*  87 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ComponentDescriptionDTO getComponentDescriptionDTO(Bundle bundle, String name) {
/*  96 */     ComponentHolder<?> holder = this.componentRegistry.getComponentHolder(bundle, name);
/*  97 */     if (holder != null)
/*     */     {
/*  99 */       return holderToDescription(holder);
/*     */     }
/*     */ 
/*     */     
/* 103 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Collection<ComponentConfigurationDTO> getComponentConfigurationDTOs(ComponentDescriptionDTO description) {
/* 113 */     if (description == null)
/*     */     {
/* 115 */       return Collections.emptyList();
/*     */     }
/*     */     
/*     */     try {
/* 119 */       ComponentHolder<?> holder = getHolderFromDescription(description);
/*     */       
/* 121 */       if (holder == null) {
/* 122 */         return Collections.emptyList();
/*     */       }
/*     */       
/* 125 */       description = holderToDescription(holder);
/* 126 */       if (description == null)
/*     */       {
/* 128 */         return Collections.emptyList();
/*     */       }
/* 130 */       List<? extends ComponentManager<?>> managers = holder.getComponents();
/* 131 */       List<ComponentConfigurationDTO> result = new ArrayList<>(managers.size());
/* 132 */       for (ComponentManager<?> manager : managers)
/*     */       {
/* 134 */         result.add(managerToConfiguration(manager, description));
/*     */       }
/* 136 */       return result;
/*     */     }
/* 138 */     catch (IllegalStateException ise) {
/*     */       
/* 140 */       return Collections.emptyList();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isComponentEnabled(ComponentDescriptionDTO description) {
/*     */     try {
/* 152 */       ComponentHolder<?> holder = getHolderFromDescription(description);
/* 153 */       if (holder == null) {
/* 154 */         return false;
/*     */       }
/* 156 */       return holder.isEnabled();
/*     */     }
/* 158 */     catch (IllegalStateException ise) {
/*     */       
/* 160 */       return false;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Promise<Void> enableComponent(ComponentDescriptionDTO description) {
/*     */     try {
/* 172 */       ComponentHolder<?> holder = getHolderFromDescription(description);
/* 173 */       if (holder == null) {
/* 174 */         throw new IllegalStateException("The component is not available in the runtime");
/*     */       }
/* 176 */       boolean doUpdate = !holder.isEnabled();
/* 177 */       Promise<Void> result = holder.enableComponents(true);
/* 178 */       if (doUpdate) {
/* 179 */         this.componentRegistry.updateChangeCount();
/*     */       }
/* 181 */       return result;
/*     */     }
/* 183 */     catch (IllegalStateException ise) {
/*     */       
/* 185 */       return Promises.failed(ise);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Promise<Void> disableComponent(ComponentDescriptionDTO description) {
/*     */     try {
/* 197 */       ComponentHolder<?> holder = getHolderFromDescription(description);
/* 198 */       if (holder == null) {
/* 199 */         throw new IllegalStateException("The component is not available in the runtime");
/*     */       }
/* 201 */       boolean doUpdate = holder.isEnabled();
/* 202 */       Promise<Void> result = holder.disableComponents(true);
/* 203 */       if (doUpdate) {
/* 204 */         this.componentRegistry.updateChangeCount();
/*     */       }
/* 206 */       return result;
/*     */     }
/* 208 */     catch (IllegalStateException ise) {
/*     */       
/* 210 */       return Promises.failed(ise);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private ComponentConfigurationDTO managerToConfiguration(ComponentManager<?> manager, ComponentDescriptionDTO description) {
/* 216 */     ComponentConfigurationDTO dto = new ComponentConfigurationDTO();
/* 217 */     dto.satisfiedReferences = satisfiedRefManagersToDTO(manager.getReferenceManagers());
/* 218 */     dto.unsatisfiedReferences = unsatisfiedRefManagersToDTO(manager.getReferenceManagers());
/* 219 */     dto.description = description;
/* 220 */     dto.id = manager.getId();
/* 221 */     dto.properties = new HashMap<>(manager.getProperties());
/* 222 */     dto.state = manager.getSpecState();
/*     */     
/* 224 */     if (dto.state == 8 || dto.state == 4)
/*     */     {
/*     */       
/* 227 */       dto.service = serviceReferenceToDTO(manager.getRegisteredServiceReference());
/*     */     }
/* 229 */     if (manager.getFailureReason() != null) {
/*     */       
/* 231 */       dto.state = 16;
/* 232 */       dto.failure = manager.getFailureReason();
/*     */     } 
/* 234 */     return dto;
/*     */   }
/*     */ 
/*     */   
/*     */   private SatisfiedReferenceDTO[] satisfiedRefManagersToDTO(List<? extends ReferenceManager<?, ?>> referenceManagers) {
/* 239 */     List<SatisfiedReferenceDTO> dtos = new ArrayList<>();
/* 240 */     for (ReferenceManager<?, ?> ref : referenceManagers) {
/*     */       
/* 242 */       if (ref.isSatisfied()) {
/*     */         
/* 244 */         SatisfiedReferenceDTO dto = new SatisfiedReferenceDTO();
/* 245 */         dto.name = ref.getName();
/* 246 */         dto.target = ref.getTarget();
/* 247 */         List<ServiceReference<?>> serviceRefs = ref.getServiceReferences();
/* 248 */         ServiceReferenceDTO[] srDTOs = new ServiceReferenceDTO[serviceRefs.size()];
/* 249 */         int j = 0;
/* 250 */         for (ServiceReference<?> serviceRef : serviceRefs) {
/*     */           
/* 252 */           ServiceReferenceDTO srefDTO = serviceReferenceToDTO(serviceRef);
/* 253 */           if (srefDTO != null)
/* 254 */             srDTOs[j++] = srefDTO; 
/*     */         } 
/* 256 */         dto.boundServices = srDTOs;
/* 257 */         dtos.add(dto);
/*     */       } 
/*     */     } 
/* 260 */     return dtos.<SatisfiedReferenceDTO>toArray(new SatisfiedReferenceDTO[dtos.size()]);
/*     */   }
/*     */ 
/*     */   
/*     */   private UnsatisfiedReferenceDTO[] unsatisfiedRefManagersToDTO(List<? extends ReferenceManager<?, ?>> referenceManagers) {
/* 265 */     List<UnsatisfiedReferenceDTO> dtos = new ArrayList<>();
/* 266 */     for (ReferenceManager<?, ?> ref : referenceManagers) {
/*     */       
/* 268 */       if (!ref.isSatisfied()) {
/*     */         
/* 270 */         UnsatisfiedReferenceDTO dto = new UnsatisfiedReferenceDTO();
/* 271 */         dto.name = ref.getName();
/* 272 */         dto.target = ref.getTarget();
/* 273 */         List<ServiceReference<?>> serviceRefs = ref.getServiceReferences();
/* 274 */         ServiceReferenceDTO[] srDTOs = new ServiceReferenceDTO[serviceRefs.size()];
/* 275 */         int j = 0;
/* 276 */         for (ServiceReference<?> serviceRef : serviceRefs) {
/*     */           
/* 278 */           ServiceReferenceDTO srefDTO = serviceReferenceToDTO(serviceRef);
/* 279 */           if (srefDTO != null)
/* 280 */             srDTOs[j++] = srefDTO; 
/*     */         } 
/* 282 */         dto.targetServices = srDTOs;
/* 283 */         dtos.add(dto);
/*     */       } 
/*     */     } 
/* 286 */     return dtos.<UnsatisfiedReferenceDTO>toArray(new UnsatisfiedReferenceDTO[dtos.size()]);
/*     */   }
/*     */ 
/*     */   
/*     */   private ServiceReferenceDTO serviceReferenceToDTO(ServiceReference<?> serviceRef) {
/* 291 */     if (serviceRef == null)
/* 292 */       return null; 
/* 293 */     return (ServiceReferenceDTO)serviceRef.adapt(ServiceReferenceDTO.class);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ComponentHolder<?> getHolderFromDescription(ComponentDescriptionDTO description) {
/* 304 */     if (description.bundle == null)
/*     */     {
/* 306 */       throw new IllegalArgumentException("No bundle supplied in ComponentDescriptionDTO named " + description.name);
/*     */     }
/* 308 */     long bundleId = description.bundle.id;
/* 309 */     Bundle b = this.context.getBundle(bundleId);
/* 310 */     if (b == null)
/*     */     {
/* 312 */       return null;
/*     */     }
/* 314 */     String name = description.name;
/* 315 */     return this.componentRegistry.getComponentHolder(b, name);
/*     */   }
/*     */ 
/*     */   
/*     */   private ComponentDescriptionDTO holderToDescription(ComponentHolder<?> holder) {
/* 320 */     ComponentDescriptionDTO dto = new ComponentDescriptionDTO();
/* 321 */     ComponentMetadata m = holder.getComponentMetadata();
/* 322 */     dto.activate = m.getActivate();
/* 323 */     dto.bundle = bundleToDTO(holder.getActivator().getBundleContext());
/*     */     
/* 325 */     if (dto.bundle == null)
/*     */     {
/* 327 */       return null;
/*     */     }
/* 329 */     dto.configurationPid = (String[])m.getConfigurationPid().toArray((Object[])new String[m.getConfigurationPid().size()]);
/* 330 */     dto.configurationPolicy = m.getConfigurationPolicy();
/* 331 */     dto.deactivate = m.getDeactivate();
/* 332 */     dto.defaultEnabled = m.isEnabled();
/* 333 */     dto.factory = m.getFactoryIdentifier();
/* 334 */     dto.immediate = m.isImmediate();
/* 335 */     dto.implementationClass = m.getImplementationClassName();
/* 336 */     dto.modified = m.getModified();
/* 337 */     dto.name = m.getName();
/* 338 */     dto.properties = deepCopy(m.getProperties());
/* 339 */     dto.references = refsToDTO(m.getDependencies());
/* 340 */     dto.scope = (m.getServiceMetadata() == null) ? null : m.getServiceMetadata().getScope().name();
/* 341 */     dto.serviceInterfaces = (m.getServiceMetadata() == null) ? EMPTY : m.getServiceMetadata().getProvides();
/*     */     
/* 343 */     dto.factoryProperties = m.isFactory() ? m.getFactoryProperties() : null;
/* 344 */     dto.activationFields = (m.getActivationFields() == null) ? EMPTY : (String[])m.getActivationFields().toArray((Object[])new String[m.getActivationFields().size()]);
/* 345 */     dto.init = m.getNumberOfConstructorParameters();
/* 346 */     return dto;
/*     */   }
/*     */ 
/*     */   
/*     */   private Map<String, Object> deepCopy(Map<String, Object> source) {
/* 351 */     HashMap<String, Object> result = new HashMap<>(source.size());
/* 352 */     for (Map.Entry<String, Object> entry : source.entrySet())
/*     */     {
/* 354 */       result.put(entry.getKey(), convert(entry.getValue()));
/*     */     }
/* 356 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   Object convert(Object source) {
/* 361 */     if (source.getClass().isArray()) {
/*     */       
/* 363 */       Class<?> type = source.getClass().getComponentType();
/* 364 */       if (checkType(type))
/*     */       {
/* 366 */         return source;
/*     */       }
/* 368 */       return String.valueOf(source);
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 379 */     if (checkType(source.getClass()))
/*     */     {
/* 381 */       return source;
/*     */     }
/* 383 */     return String.valueOf(source);
/*     */   }
/*     */ 
/*     */   
/*     */   boolean checkType(Class<?> type) {
/* 388 */     if (type == String.class) return true; 
/* 389 */     if (type == Boolean.class) return true; 
/* 390 */     if (Number.class.isAssignableFrom(type)) return true; 
/* 391 */     if (DTO.class.isAssignableFrom(type)) return true; 
/* 392 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   private ReferenceDTO[] refsToDTO(List<ReferenceMetadata> dependencies) {
/* 397 */     ReferenceDTO[] dtos = new ReferenceDTO[dependencies.size()];
/* 398 */     int i = 0;
/* 399 */     for (ReferenceMetadata r : dependencies) {
/*     */       
/* 401 */       ReferenceDTO dto = new ReferenceDTO();
/* 402 */       dto.bind = r.getBind();
/* 403 */       dto.cardinality = r.getCardinality();
/* 404 */       dto.field = r.getField();
/* 405 */       dto.fieldOption = r.getFieldOption();
/* 406 */       dto.interfaceName = r.getInterface();
/* 407 */       dto.name = r.getName();
/* 408 */       dto.policy = r.getPolicy();
/* 409 */       dto.policyOption = r.getPolicyOption();
/* 410 */       dto.scope = r.getScope().name();
/* 411 */       dto.target = r.getTarget();
/* 412 */       dto.unbind = r.getUnbind();
/* 413 */       dto.updated = r.getUpdated();
/*     */       
/* 415 */       dto.parameter = r.getParameterIndex();
/* 416 */       dto.collectionType = r.getCollectionType();
/* 417 */       dtos[i++] = dto;
/*     */     } 
/* 419 */     return dtos;
/*     */   }
/*     */ 
/*     */   
/*     */   private BundleDTO bundleToDTO(BundleContext bundleContext) {
/* 424 */     if (bundleContext == null)
/*     */     {
/* 426 */       return null;
/*     */     }
/*     */     
/*     */     try {
/* 430 */       Bundle bundle = bundleContext.getBundle();
/* 431 */       if (bundle == null)
/*     */       {
/* 433 */         return null;
/*     */       }
/* 435 */       BundleDTO b = new BundleDTO();
/* 436 */       b.id = bundle.getBundleId();
/* 437 */       b.lastModified = bundle.getLastModified();
/* 438 */       b.state = bundle.getState();
/* 439 */       b.symbolicName = bundle.getSymbolicName();
/* 440 */       b.version = bundle.getVersion().toString();
/* 441 */       return b;
/*     */     }
/* 443 */     catch (IllegalStateException e) {
/*     */       
/* 445 */       return null;
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.apache.felix.scr-2.2.6.jar!\org\apache\felix\scr\impl\runtime\ServiceComponentRuntimeImpl.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */