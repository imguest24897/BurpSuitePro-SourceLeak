/*     */ package org.apache.felix.scr.impl.logger;
/*     */ 
/*     */ import java.io.PrintStream;
/*     */ import java.io.PrintWriter;
/*     */ import java.io.StringWriter;
/*     */ import java.text.MessageFormat;
/*     */ import org.osgi.framework.Bundle;
/*     */ import org.osgi.framework.BundleContext;
/*     */ import org.osgi.framework.BundleEvent;
/*     */ import org.osgi.framework.ServiceReference;
/*     */ import org.osgi.service.log.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ScrLogManager
/*     */   extends LogManager
/*     */ {
/*     */   private final Bundle bundle;
/*     */   private final LogConfiguration config;
/*     */   
/*     */   ScrLogManager(BundleContext context, LogConfiguration config) {
/*  46 */     super(context, config);
/*  47 */     this.config = config;
/*  48 */     this.bundle = context.getBundle();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ScrLogger scr() {
/*  59 */     ScrLoggerFacade scrl = getLogger(this.bundle, "ROOT", ScrLoggerFacade.class);
/*     */     
/*  61 */     scrl.setPrefix(getBundleIdentifier(this.bundle));
/*  62 */     return scrl;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BundleLogger bundle(Bundle bundle) {
/*  75 */     ScrLoggerFacade logger = getLogger(bundle, "ROOT", ScrLoggerFacade.class);
/*     */     
/*  77 */     logger.setPrefix(getBundleIdentifier(bundle));
/*  78 */     return logger;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ComponentLogger component(Bundle bundle, String implementationClass, String name) {
/*  99 */     ScrLoggerFacade facade = getLogger(bundle, implementationClass, ScrLoggerFacade.class);
/*     */     
/* 101 */     facade.setComponentId(-1L);
/* 102 */     return facade;
/*     */   }
/*     */   
/*     */   class ScrLoggerFacade
/*     */     extends LogManager.LoggerFacade
/*     */     implements InternalLogger, ScrLogger, BundleLogger, ComponentLogger {
/*     */     ScrLoggerFacade(LogManager.LogDomain logDomain, String name) {
/* 109 */       super(logDomain, name);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void setComponentId(long id) {
/* 115 */       setPrefix(ScrLogManager.this.componentPrefix(this, id));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean isLogEnabled(InternalLogger.Level level) {
/* 123 */       Object checkLogger = getLogger();
/* 124 */       if (checkLogger != null) {
/*     */         
/* 126 */         Logger logger = (Logger)checkLogger;
/* 127 */         switch (level) {
/*     */           
/*     */           case AUDIT:
/* 130 */             return true;
/*     */           case ERROR:
/* 132 */             return logger.isErrorEnabled();
/*     */           case WARN:
/* 134 */             return logger.isWarnEnabled();
/*     */           case INFO:
/* 136 */             return logger.isInfoEnabled();
/*     */           case TRACE:
/* 138 */             return logger.isTraceEnabled();
/*     */         } 
/*     */         
/* 141 */         return logger.isDebugEnabled();
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 146 */       return ScrLogManager.this.getLogLevel().implies(level);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void log(InternalLogger.Level level, String format, Throwable ex, Object... arguments) {
/* 153 */       if (isLogEnabled(level)) {
/* 154 */         log0(level, ScrLogManager.this.format(format, arguments), ex);
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*     */     public void log(InternalLogger.Level level, String message, Throwable ex) {
/* 160 */       if (isLogEnabled(level)) {
/* 161 */         log0(level, message, ex);
/*     */       }
/*     */     }
/*     */     
/*     */     void log0(InternalLogger.Level level, String message, Throwable ex) {
/* 166 */       if (this.prefix != null && this.prefix.length() > 0)
/*     */       {
/* 168 */         message = this.prefix.concat(" ").concat(message);
/*     */       }
/* 170 */       Object checkLogger = getLogger();
/* 171 */       if (checkLogger != null) {
/*     */         
/* 173 */         Logger logger = (Logger)checkLogger;
/* 174 */         if (ex == null)
/*     */         {
/* 176 */           switch (level) {
/*     */             
/*     */             case AUDIT:
/* 179 */               logger.audit(message);
/*     */               return;
/*     */             case ERROR:
/* 182 */               logger.error(message);
/*     */               return;
/*     */             case WARN:
/* 185 */               logger.warn(message);
/*     */               return;
/*     */             case INFO:
/* 188 */               logger.info(message);
/*     */               return;
/*     */             case TRACE:
/* 191 */               logger.trace(message);
/*     */               return;
/*     */           } 
/*     */           
/* 195 */           logger.debug(message);
/*     */         
/*     */         }
/*     */         else
/*     */         {
/* 200 */           switch (level) {
/*     */             
/*     */             case AUDIT:
/* 203 */               logger.audit(message, ex);
/*     */               return;
/*     */             case ERROR:
/* 206 */               logger.error(message, ex);
/*     */               return;
/*     */             case WARN:
/* 209 */               logger.warn(message, ex);
/*     */               return;
/*     */             case INFO:
/* 212 */               logger.info(message, ex);
/*     */               return;
/*     */             case TRACE:
/* 215 */               logger.trace(message, ex);
/*     */               return;
/*     */           } 
/*     */           
/* 219 */           logger.debug(message, ex);
/*     */         }
/*     */       
/*     */       }
/*     */       else {
/*     */         
/* 225 */         StringWriter buf = new StringWriter();
/* 226 */         String l = String.format("%-5s", new Object[] { level });
/* 227 */         buf.append(l).append(" : ").append(message);
/* 228 */         if (ex != null) {
/*     */           
/* 230 */           PrintWriter pw = new PrintWriter(buf);
/*     */           
/* 232 */           try { pw.println();
/* 233 */             ex.printStackTrace(pw);
/* 234 */             pw.close(); } catch (Throwable throwable) { try { pw.close(); }
/*     */             catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }
/*     */              throw throwable; }
/*     */         
/* 238 */         }  PrintStream out = level.err() ? System.err : System.out;
/* 239 */         out.println(buf);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     void setPrefix(String prefix) {
/* 245 */       this.prefix = prefix;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ComponentLogger component(Bundle bundle, String implementationClassName, String name) {
/* 253 */       return ScrLogManager.this.component(bundle, implementationClassName, name);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public BundleLogger bundle(Bundle bundle) {
/* 260 */       return ScrLogManager.this.bundle(bundle);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void close() {
/* 267 */       ScrLogManager.this.close();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   LogManager.LoggerFacade createLoggerFacade(LogManager.LogDomain logDomain, String name) {
/* 274 */     return new ScrLoggerFacade(logDomain, name);
/*     */   }
/*     */ 
/*     */   
/*     */   InternalLogger.Level getLogLevel() {
/* 279 */     return this.config.getLogLevel();
/*     */   }
/*     */ 
/*     */   
/*     */   String getBundleIdentifier(Bundle bundle) {
/* 284 */     StringBuilder sb = new StringBuilder("bundle ");
/*     */     
/* 286 */     if (bundle.getSymbolicName() != null) {
/*     */       
/* 288 */       sb.append(bundle.getSymbolicName());
/* 289 */       sb.append(':');
/* 290 */       sb.append(bundle.getVersion());
/* 291 */       sb.append(" (");
/* 292 */       sb.append(bundle.getBundleId());
/* 293 */       sb.append(")");
/*     */     }
/*     */     else {
/*     */       
/* 297 */       sb.append(bundle.getBundleId());
/*     */     } 
/*     */     
/* 300 */     return sb.toString();
/*     */   }
/*     */ 
/*     */   
/*     */   String componentPrefix(ScrLoggerFacade slf, long id) {
/* 305 */     if (id >= 0L)
/*     */     {
/* 307 */       return getBundleIdentifier(slf.getBundle()) + "[" + slf.getName() + "(" + id + ")] :";
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 312 */     return getBundleIdentifier(slf.getBundle()) + "[" + slf.getName() + "] :";
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   String format(String pattern, Object... arguments) {
/* 318 */     if (arguments == null || arguments.length == 0)
/*     */     {
/* 320 */       return pattern;
/*     */     }
/*     */ 
/*     */     
/* 324 */     for (int i = 0; i < arguments.length; i++) {
/*     */       
/* 326 */       if (arguments[i] instanceof Bundle)
/*     */       {
/* 328 */         arguments[i] = getBundleIdentifier((Bundle)arguments[i]);
/*     */       }
/*     */     } 
/* 331 */     return MessageFormat.format(pattern, arguments);
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.apache.felix.scr-2.2.6.jar!\org\apache\felix\scr\impl\logger\ScrLogManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */