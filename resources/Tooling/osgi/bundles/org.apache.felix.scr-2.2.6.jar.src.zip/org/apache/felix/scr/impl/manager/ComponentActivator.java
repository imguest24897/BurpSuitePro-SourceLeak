package org.apache.felix.scr.impl.manager;

import org.apache.felix.scr.impl.logger.BundleLogger;
import org.osgi.framework.BundleContext;
import org.osgi.framework.ServiceReference;
import org.osgi.service.cm.ConfigurationAdmin;

public interface ComponentActivator extends ExtendedServiceListenerContext<ExtendedServiceEvent> {
  BundleLogger getLogger();
  
  BundleContext getBundleContext();
  
  boolean isActive();
  
  ScrConfiguration getConfiguration();
  
  void schedule(Runnable paramRunnable);
  
  long registerComponentId(AbstractComponentManager<?> paramAbstractComponentManager);
  
  void unregisterComponentId(AbstractComponentManager<?> paramAbstractComponentManager);
  
  <T> boolean enterCreate(ServiceReference<T> paramServiceReference);
  
  <T> void leaveCreate(ServiceReference<T> paramServiceReference);
  
  <S, T> void registerMissingDependency(DependencyManager<S, T> paramDependencyManager, ServiceReference<T> paramServiceReference, int paramInt);
  
  <T> void missingServicePresent(ServiceReference<T> paramServiceReference);
  
  void enableComponent(String paramString);
  
  void disableComponent(String paramString);
  
  RegionConfigurationSupport setRegionConfigurationSupport(ServiceReference<ConfigurationAdmin> paramServiceReference);
  
  void unsetRegionConfigurationSupport(RegionConfigurationSupport paramRegionConfigurationSupport);
  
  void updateChangeCount();
  
  ServiceReference<?> getTrueCondition();
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.apache.felix.scr-2.2.6.jar!\org\apache\felix\scr\impl\manager\ComponentActivator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */