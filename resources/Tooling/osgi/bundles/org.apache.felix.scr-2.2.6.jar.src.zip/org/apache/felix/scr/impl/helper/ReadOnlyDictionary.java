/*     */ package org.apache.felix.scr.impl.helper;
/*     */ 
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.Dictionary;
/*     */ import java.util.Enumeration;
/*     */ import java.util.Hashtable;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import org.osgi.framework.ServiceReference;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ReadOnlyDictionary
/*     */   extends Dictionary<String, Object>
/*     */   implements Map<String, Object>, Comparable<ReadOnlyDictionary>
/*     */ {
/*     */   private final Hashtable<String, Object> m_delegate;
/*     */   private final ServiceReference<?> m_serviceReference;
/*     */   
/*     */   public ReadOnlyDictionary(Map<String, Object> delegate) {
/*  50 */     if (delegate instanceof Hashtable) {
/*     */       
/*  52 */       this.m_delegate = (Hashtable<String, Object>)delegate;
/*     */     }
/*     */     else {
/*     */       
/*  56 */       this.m_delegate = new Hashtable<>();
/*  57 */       for (Map.Entry<String, Object> entry : delegate.entrySet())
/*     */       {
/*  59 */         this.m_delegate.put(entry.getKey(), entry.getValue());
/*     */       }
/*     */     } 
/*  62 */     this.m_serviceReference = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ReadOnlyDictionary(ServiceReference<?> serviceReference) {
/*  71 */     Hashtable<String, Object> properties = new Hashtable<>();
/*  72 */     String[] keys = serviceReference.getPropertyKeys();
/*  73 */     if (keys != null)
/*     */     {
/*  75 */       for (int j = 0; j < keys.length; j++) {
/*     */         
/*  77 */         String key = keys[j];
/*  78 */         properties.put(key, serviceReference.getProperty(key));
/*     */       } 
/*     */     }
/*  81 */     this.m_delegate = properties;
/*  82 */     this.m_serviceReference = serviceReference;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Enumeration<Object> elements() {
/*  91 */     return this.m_delegate.elements();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Object get(Object key) {
/*  97 */     return this.m_delegate.get(key);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isEmpty() {
/* 104 */     return this.m_delegate.isEmpty();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Enumeration<String> keys() {
/* 111 */     return this.m_delegate.keys();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object put(String key, Object value) {
/* 122 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object remove(Object key) {
/* 133 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int size() {
/* 140 */     return this.m_delegate.size();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 147 */     return this.m_delegate.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void clear() {
/* 155 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean containsKey(Object key) {
/* 161 */     return this.m_delegate.containsKey(key);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean containsValue(Object value) {
/* 167 */     return this.m_delegate.containsValue(value);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Set<Map.Entry<String, Object>> entrySet() {
/* 173 */     return Collections.unmodifiableSet(this.m_delegate.entrySet());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Set<String> keySet() {
/* 179 */     return Collections.unmodifiableSet(this.m_delegate.keySet());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void putAll(Map<? extends String, ? extends Object> m) {
/* 185 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Collection<Object> values() {
/* 191 */     return Collections.unmodifiableCollection(this.m_delegate.values());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int compareTo(ReadOnlyDictionary o) {
/* 197 */     if (this.m_serviceReference == null) {
/*     */       
/* 199 */       if (o.m_serviceReference == null)
/*     */       {
/* 201 */         return 0;
/*     */       }
/* 203 */       return 1;
/*     */     } 
/* 205 */     if (o.m_serviceReference == null)
/*     */     {
/* 207 */       return -1;
/*     */     }
/* 209 */     return this.m_serviceReference.compareTo(o.m_serviceReference);
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.apache.felix.scr-2.2.6.jar!\org\apache\felix\scr\impl\helper\ReadOnlyDictionary.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */