package org.apache.felix.scr.impl.inject;

import java.util.Map;
import org.apache.felix.scr.component.ExtComponentContext;
import org.apache.felix.scr.impl.helper.ComponentServiceObjectsHelper;
import org.apache.felix.scr.impl.logger.ComponentLogger;
import org.apache.felix.scr.impl.metadata.ComponentMetadata;

public interface ScrComponentContext extends ExtComponentContext {
  ComponentLogger getLogger();
  
  ComponentMetadata getComponentMetadata();
  
  ComponentServiceObjectsHelper getComponentServiceObjectsHelper();
  
  Map<RefPair<?, ?>, Object> getBoundValues(String paramString);
  
  Map<String, Object> getPropertiesMap();
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.apache.felix.scr-2.2.6.jar!\org\apache\felix\scr\impl\inject\ScrComponentContext.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */