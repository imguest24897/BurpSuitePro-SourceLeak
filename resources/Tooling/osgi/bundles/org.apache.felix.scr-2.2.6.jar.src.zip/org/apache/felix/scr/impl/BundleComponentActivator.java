/*     */ package org.apache.felix.scr.impl;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.net.URL;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.Enumeration;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.StringTokenizer;
/*     */ import java.util.concurrent.CountDownLatch;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ import java.util.concurrent.atomic.AtomicBoolean;
/*     */ import javax.xml.parsers.SAXParser;
/*     */ import javax.xml.parsers.SAXParserFactory;
/*     */ import org.apache.felix.scr.impl.helper.ConfigAdminTracker;
/*     */ import org.apache.felix.scr.impl.logger.BundleLogger;
/*     */ import org.apache.felix.scr.impl.logger.ComponentLogger;
/*     */ import org.apache.felix.scr.impl.logger.InternalLogger;
/*     */ import org.apache.felix.scr.impl.logger.ScrLogger;
/*     */ import org.apache.felix.scr.impl.manager.AbstractComponentManager;
/*     */ import org.apache.felix.scr.impl.manager.ComponentActivator;
/*     */ import org.apache.felix.scr.impl.manager.ComponentHolder;
/*     */ import org.apache.felix.scr.impl.manager.DependencyManager;
/*     */ import org.apache.felix.scr.impl.manager.ExtendedServiceEvent;
/*     */ import org.apache.felix.scr.impl.manager.ExtendedServiceListener;
/*     */ import org.apache.felix.scr.impl.manager.RegionConfigurationSupport;
/*     */ import org.apache.felix.scr.impl.manager.ScrConfiguration;
/*     */ import org.apache.felix.scr.impl.metadata.ComponentMetadata;
/*     */ import org.apache.felix.scr.impl.xml.XmlHandler;
/*     */ import org.osgi.framework.Bundle;
/*     */ import org.osgi.framework.BundleContext;
/*     */ import org.osgi.framework.InvalidSyntaxException;
/*     */ import org.osgi.framework.ServiceEvent;
/*     */ import org.osgi.framework.ServiceListener;
/*     */ import org.osgi.framework.ServiceReference;
/*     */ import org.osgi.service.cm.ConfigurationAdmin;
/*     */ import org.osgi.service.component.ComponentException;
/*     */ import org.xml.sax.helpers.DefaultHandler;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BundleComponentActivator
/*     */   implements ComponentActivator
/*     */ {
/*     */   private final ComponentRegistry m_componentRegistry;
/*     */   private final Bundle m_bundle;
/*     */   private final BundleContext m_context;
/*  80 */   private final List<ComponentHolder<?>> m_holders = new ArrayList<>();
/*     */ 
/*     */   
/*     */   private final ComponentActorThread m_componentActor;
/*     */ 
/*     */   
/*  86 */   private final AtomicBoolean m_active = new AtomicBoolean(true);
/*  87 */   private final CountDownLatch m_closeLatch = new CountDownLatch(1);
/*     */ 
/*     */   
/*     */   private final ScrConfiguration m_configuration;
/*     */   
/*     */   private final ConfigAdminTracker configAdminTracker;
/*     */   
/*  94 */   private final Map<String, ListenerInfo> listenerMap = new HashMap<>();
/*     */   
/*     */   private final BundleLogger logger;
/*     */   private final ServiceReference<?> m_trueCondition;
/*     */   
/*     */   private static class ListenerInfo
/*     */     implements ServiceListener
/*     */   {
/* 102 */     List<ExtendedServiceListener<ExtendedServiceEvent>> listeners = new ArrayList<>();
/*     */ 
/*     */     
/*     */     public void serviceChanged(ServiceEvent event) {
/*     */       List<ExtendedServiceListener<ExtendedServiceEvent>> listeners;
/* 107 */       ExtendedServiceEvent extEvent = new ExtendedServiceEvent(event);
/*     */       
/* 109 */       synchronized (this) {
/*     */         
/* 111 */         listeners = this.listeners;
/*     */       } 
/*     */       
/* 114 */       for (ExtendedServiceListener<ExtendedServiceEvent> forwardTo : listeners)
/*     */       {
/* 116 */         forwardTo.serviceChanged((ServiceEvent)extEvent);
/*     */       }
/*     */       
/* 119 */       if (extEvent != null)
/*     */       {
/* 121 */         extEvent.activateManagers();
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*     */     public synchronized void add(ExtendedServiceListener<ExtendedServiceEvent> listener) {
/* 127 */       this.listeners = new ArrayList<>(this.listeners);
/* 128 */       this.listeners.add(listener);
/*     */     }
/*     */ 
/*     */     
/*     */     public synchronized boolean remove(ExtendedServiceListener<ExtendedServiceEvent> listener) {
/* 133 */       this.listeners = new ArrayList<>(this.listeners);
/* 134 */       this.listeners.remove(listener);
/* 135 */       return this.listeners.isEmpty();
/*     */     }
/*     */ 
/*     */     
/*     */     private ListenerInfo() {}
/*     */   }
/*     */ 
/*     */   
/*     */   public void addServiceListener(String serviceFilterString, ExtendedServiceListener<ExtendedServiceEvent> listener) {
/* 144 */     synchronized (this.listenerMap) {
/*     */       
/* 146 */       this.logger.log(InternalLogger.Level.DEBUG, "serviceFilterString: " + serviceFilterString, null);
/*     */       
/* 148 */       ListenerInfo listenerInfo = this.listenerMap.get(serviceFilterString);
/* 149 */       if (listenerInfo == null) {
/*     */         
/* 151 */         listenerInfo = new ListenerInfo();
/* 152 */         this.listenerMap.put(serviceFilterString, listenerInfo);
/*     */         
/*     */         try {
/* 155 */           this.m_context.addServiceListener(listenerInfo, serviceFilterString);
/*     */         }
/* 157 */         catch (InvalidSyntaxException e) {
/*     */           
/* 159 */           throw (IllegalArgumentException)(new IllegalArgumentException("invalid class name filter"))
/* 160 */             .initCause(e);
/*     */         } 
/*     */       } 
/* 163 */       listenerInfo.add(listener);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void removeServiceListener(String serviceFilterString, ExtendedServiceListener<ExtendedServiceEvent> listener) {
/* 171 */     synchronized (this.listenerMap) {
/*     */       
/* 173 */       ListenerInfo listenerInfo = this.listenerMap.get(serviceFilterString);
/* 174 */       if (listenerInfo != null)
/*     */       {
/* 176 */         if (listenerInfo.remove(listener)) {
/* 177 */           this.listenerMap.remove(serviceFilterString);
/* 178 */           this.m_context.removeServiceListener(listenerInfo);
/*     */         } 
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BundleComponentActivator(ScrLogger scrLogger, ComponentRegistry componentRegistry, ComponentActorThread componentActor, BundleContext context, ScrConfiguration configuration, List<ComponentMetadata> cachedComponentMetadata, ServiceReference<?> trueConditiion) throws ComponentException {
/* 206 */     this.logger = scrLogger.bundle(context.getBundle());
/*     */     
/* 208 */     this.m_componentRegistry = componentRegistry;
/* 209 */     this.m_componentActor = componentActor;
/* 210 */     this.m_context = context;
/* 211 */     this.m_bundle = context.getBundle();
/*     */     
/* 213 */     this.m_configuration = configuration;
/* 214 */     this.m_trueCondition = trueConditiion;
/*     */     
/* 216 */     this.logger.log(InternalLogger.Level.DEBUG, "BundleComponentActivator : Bundle active", null);
/*     */     
/* 218 */     initialize(cachedComponentMetadata);
/* 219 */     ConfigAdminTracker tracker = null;
/* 220 */     for (ComponentHolder<?> holder : this.m_holders) {
/*     */       
/* 222 */       if (!holder.getComponentMetadata().isConfigurationIgnored()) {
/*     */         
/* 224 */         tracker = new ConfigAdminTracker(this);
/*     */         break;
/*     */       } 
/*     */     } 
/* 228 */     this.configAdminTracker = tracker;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void initialize(List<ComponentMetadata> cachedComponentMetadata) {
/* 240 */     if (cachedComponentMetadata != null) {
/*     */       
/* 242 */       for (ComponentMetadata metadata : cachedComponentMetadata)
/*     */       {
/* 244 */         validateAndRegister(metadata);
/*     */       
/*     */       }
/*     */     }
/*     */     else {
/*     */       
/* 250 */       String descriptorLocations = (String)this.m_bundle.getHeaders("").get("Service-Component");
/* 251 */       if (descriptorLocations == null)
/*     */       {
/* 253 */         throw new ComponentException("Service-Component entry not found in the manifest");
/*     */       }
/*     */ 
/*     */       
/* 257 */       this.logger.log(InternalLogger.Level.DEBUG, "BundleComponentActivator : Descriptor locations {0}", null, new Object[] { descriptorLocations });
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 262 */       StringTokenizer st = new StringTokenizer(descriptorLocations, ", ");
/*     */       
/* 264 */       while (st.hasMoreTokens()) {
/*     */         
/* 266 */         String descriptorLocation = st.nextToken();
/*     */         
/* 268 */         URL[] descriptorURLs = findDescriptors(this.m_bundle, descriptorLocation);
/* 269 */         if (descriptorURLs.length == 0) {
/*     */ 
/*     */ 
/*     */           
/* 273 */           this.logger.log(InternalLogger.Level.ERROR, "Component descriptor entry ''{0}'' not found", null, new Object[] { descriptorLocation });
/*     */ 
/*     */ 
/*     */           
/*     */           continue;
/*     */         } 
/*     */ 
/*     */         
/* 281 */         for (URL descriptorURL : descriptorURLs)
/*     */         {
/* 283 */           loadDescriptor(descriptorURL);
/*     */         }
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void initialEnable() {
/* 296 */     for (ComponentHolder<?> componentHolder : this.m_holders) {
/*     */       
/* 298 */       this.logger.log(InternalLogger.Level.DEBUG, "BundleComponentActivator : May enable component holder {0}", null, new Object[] { componentHolder
/*     */             
/* 300 */             .getComponentMetadata().getName() });
/*     */       
/* 302 */       if (componentHolder.getComponentMetadata().isEnabled()) {
/*     */         
/* 304 */         this.logger.log(InternalLogger.Level.DEBUG, "BundleComponentActivator :Enabling component holder {0}", null, new Object[] { componentHolder
/*     */               
/* 306 */               .getComponentMetadata().getName() });
/*     */ 
/*     */         
/*     */         try {
/* 310 */           componentHolder.enableComponents(false);
/*     */         }
/* 312 */         catch (Throwable t) {
/*     */ 
/*     */           
/*     */           try {
/*     */ 
/*     */ 
/*     */ 
/*     */             
/* 320 */             componentHolder.disableComponents(false);
/*     */           }
/* 322 */           catch (Throwable throwable) {}
/*     */ 
/*     */ 
/*     */           
/* 326 */           this.logger.log(InternalLogger.Level.ERROR, "BundleComponentActivator : Unexpected failure enabling component holder {0}", t, new Object[] { componentHolder
/*     */                 
/* 328 */                 .getComponentMetadata().getName() });
/*     */         } 
/*     */         
/*     */         continue;
/*     */       } 
/* 333 */       this.logger.log(InternalLogger.Level.DEBUG, "BundleComponentActivator : Will not enable component holder {0}", null, new Object[] { componentHolder
/*     */             
/* 335 */             .getComponentMetadata().getName() });
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static URL[] findDescriptors(Bundle bundle, String descriptorLocation) {
/*     */     String path, filePattern;
/* 349 */     if (bundle == null || descriptorLocation == null || descriptorLocation.trim().length() == 0)
/*     */     {
/* 351 */       return new URL[0];
/*     */     }
/*     */ 
/*     */     
/* 355 */     int lios = descriptorLocation.lastIndexOf("/");
/*     */ 
/*     */     
/* 358 */     if (lios > 0) {
/*     */       
/* 360 */       path = descriptorLocation.substring(0, lios);
/* 361 */       filePattern = descriptorLocation.substring(lios + 1);
/*     */     }
/*     */     else {
/*     */       
/* 365 */       path = "/";
/* 366 */       filePattern = descriptorLocation;
/*     */     } 
/*     */ 
/*     */     
/* 370 */     Enumeration<URL> entries = bundle.findEntries(path, filePattern, false);
/* 371 */     if (entries == null || !entries.hasMoreElements())
/*     */     {
/* 373 */       return new URL[0];
/*     */     }
/*     */ 
/*     */     
/* 377 */     List<URL> urls = new ArrayList<>();
/* 378 */     while (entries.hasMoreElements())
/*     */     {
/* 380 */       urls.add(entries.nextElement());
/*     */     }
/* 382 */     return urls.<URL>toArray(new URL[urls.size()]);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void loadDescriptor(URL descriptorURL) {
/* 388 */     String descriptorLocation = descriptorURL.getPath();
/*     */     
/* 390 */     InputStream stream = null;
/*     */     
/*     */     try {
/* 393 */       stream = descriptorURL.openStream();
/*     */ 
/*     */       
/* 396 */       XmlHandler handler = new XmlHandler(this.m_bundle, this.logger, getConfiguration().isFactoryEnabled(), getConfiguration().keepInstances(), this.m_trueCondition);
/* 397 */       SAXParserFactory factory = SAXParserFactory.newInstance();
/* 398 */       factory.setNamespaceAware(true);
/* 399 */       SAXParser parser = factory.newSAXParser();
/*     */       
/* 401 */       parser.parse(stream, (DefaultHandler)handler);
/*     */ 
/*     */ 
/*     */       
/* 405 */       for (ComponentMetadata metadata : handler.getComponentMetadataList())
/*     */       {
/* 407 */         validateAndRegister(metadata);
/*     */       }
/*     */     }
/* 410 */     catch (IOException ex) {
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 415 */       this.logger.log(InternalLogger.Level.ERROR, "Problem reading descriptor entry ''{0}''", ex, new Object[] { descriptorLocation });
/*     */     
/*     */     }
/* 418 */     catch (Exception ex) {
/*     */       
/* 420 */       this.logger.log(InternalLogger.Level.ERROR, "General problem with descriptor entry ''{0}''", ex, new Object[] { descriptorLocation });
/*     */     
/*     */     }
/*     */     finally {
/*     */       
/* 425 */       if (stream != null) {
/*     */         
/*     */         try {
/*     */           
/* 429 */           stream.close();
/*     */         }
/* 431 */         catch (IOException iOException) {}
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void validateAndRegister(ComponentMetadata metadata) {
/* 440 */     ComponentLogger componentLogger = this.logger.component(this.m_bundle, metadata.getImplementationClassName(), metadata.getName());
/* 441 */     ComponentRegistryKey key = null;
/*     */ 
/*     */     
/*     */     try {
/* 445 */       metadata.validate();
/*     */ 
/*     */       
/* 448 */       key = this.m_componentRegistry.checkComponentName(this.m_bundle, metadata.getName());
/*     */ 
/*     */       
/* 451 */       ComponentHolder<?> holder = this.m_componentRegistry.createComponentHolder(this, metadata, componentLogger);
/*     */ 
/*     */ 
/*     */       
/* 455 */       this.m_componentRegistry.registerComponentHolder(key, holder);
/* 456 */       this.m_holders.add(holder);
/*     */       
/* 458 */       componentLogger.log(InternalLogger.Level.DEBUG, "BundleComponentActivator : ComponentHolder created.", null);
/*     */ 
/*     */     
/*     */     }
/* 462 */     catch (Throwable t) {
/*     */ 
/*     */ 
/*     */       
/* 466 */       componentLogger.log(InternalLogger.Level.ERROR, "Cannot register component", t);
/*     */ 
/*     */       
/* 469 */       if (key != null)
/*     */       {
/* 471 */         this.m_componentRegistry.unregisterComponentHolder(key);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void dispose(int reason) {
/* 482 */     if (this.m_active.compareAndSet(true, false)) {
/*     */       
/* 484 */       this.logger.log(InternalLogger.Level.DEBUG, "BundleComponentActivator : Will destroy {0} instances", null, new Object[] {
/*     */             
/* 486 */             Integer.valueOf(this.m_holders.size())
/*     */           });
/* 488 */       for (ComponentHolder<?> holder : this.m_holders) {
/*     */ 
/*     */         
/*     */         try {
/* 492 */           holder.disposeComponents(reason);
/*     */         }
/* 494 */         catch (Exception e) {
/*     */           
/* 496 */           this.logger.log(InternalLogger.Level.ERROR, "BundleComponentActivator : Exception invalidating", e, new Object[] { holder
/*     */                 
/* 498 */                 .getComponentMetadata() });
/*     */         }
/*     */         finally {
/*     */           
/* 502 */           this.m_componentRegistry.unregisterComponentHolder(this.m_bundle, holder.getComponentMetadata().getName());
/*     */         } 
/*     */       } 
/*     */       
/* 506 */       if (this.configAdminTracker != null)
/*     */       {
/* 508 */         this.configAdminTracker.dispose();
/*     */       }
/*     */       
/* 511 */       this.logger.log(InternalLogger.Level.DEBUG, "BundleComponentActivator : Bundle STOPPED", null);
/*     */ 
/*     */       
/* 514 */       this.m_closeLatch.countDown();
/*     */     } else {
/*     */ 
/*     */       
/*     */       try {
/*     */         
/* 520 */         this.m_closeLatch.await(this.m_configuration.lockTimeout(), TimeUnit.MILLISECONDS);
/*     */       }
/* 522 */       catch (InterruptedException e) {
/*     */ 
/*     */         
/* 525 */         Thread.currentThread().interrupt();
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isActive() {
/* 541 */     return this.m_active.get();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BundleContext getBundleContext() {
/* 552 */     return this.m_context;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ScrConfiguration getConfiguration() {
/* 558 */     return this.m_configuration;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void enableComponent(String name) {
/* 573 */     List<ComponentHolder<?>> holder = getSelectedComponents(name);
/* 574 */     for (ComponentHolder<?> aHolder : holder) {
/*     */ 
/*     */       
/*     */       try {
/*     */         
/* 579 */         this.logger.log(InternalLogger.Level.DEBUG, "Enabling Component {0}", null, new Object[] { aHolder
/* 580 */               .getComponentMetadata().getName() });
/* 581 */         aHolder.enableComponents(true);
/*     */       }
/* 583 */       catch (Throwable t) {
/*     */ 
/*     */         
/* 586 */         this.logger.log(InternalLogger.Level.ERROR, "Cannot enable component {0}", t, new Object[] { aHolder
/* 587 */               .getComponentMetadata().getName() });
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void disableComponent(String name) {
/* 604 */     List<ComponentHolder<?>> holder = getSelectedComponents(name);
/* 605 */     for (ComponentHolder<?> aHolder : holder) {
/*     */ 
/*     */       
/*     */       try {
/*     */         
/* 610 */         this.logger.log(InternalLogger.Level.DEBUG, "Disabling Component {0}", null, new Object[] { aHolder
/* 611 */               .getComponentMetadata().getName() });
/* 612 */         aHolder.disableComponents(true);
/*     */       }
/* 614 */       catch (Throwable t) {
/*     */ 
/*     */         
/* 617 */         this.logger.log(InternalLogger.Level.ERROR, "Cannot disable component {0}", t, new Object[] { aHolder
/* 618 */               .getComponentMetadata().getName() });
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   List<ComponentHolder<?>> getSelectedComponents(String name) {
/* 641 */     if (name == null)
/*     */     {
/* 643 */       return this.m_holders;
/*     */     }
/*     */     
/* 646 */     ComponentHolder<?> componentHolder = this.m_componentRegistry.getComponentHolder(this.m_bundle, name);
/* 647 */     if (componentHolder != null)
/*     */     {
/* 649 */       return Collections.singletonList(componentHolder);
/*     */     }
/*     */ 
/*     */     
/* 653 */     return Collections.emptyList();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long registerComponentId(AbstractComponentManager<?> componentManager) {
/* 661 */     return this.m_componentRegistry.registerComponentId(componentManager);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void unregisterComponentId(AbstractComponentManager<?> componentManager) {
/* 667 */     this.m_componentRegistry.unregisterComponentId(componentManager.getId());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void schedule(Runnable task) {
/* 682 */     if (isActive()) {
/*     */       
/* 684 */       ComponentActorThread cat = this.m_componentActor;
/* 685 */       if (cat != null) {
/*     */         
/* 687 */         cat.schedule(task);
/*     */       }
/*     */       else {
/*     */         
/* 691 */         this.logger.log(InternalLogger.Level.DEBUG, "Component Actor Thread not running, calling synchronously", null);
/*     */ 
/*     */         
/*     */         try {
/* 695 */           synchronized (this)
/*     */           {
/* 697 */             task.run();
/*     */           }
/*     */         
/* 700 */         } catch (Throwable t) {
/*     */           
/* 702 */           this.logger.log(InternalLogger.Level.WARN, "Unexpected problem executing task", t);
/*     */         }
/*     */       
/*     */       } 
/*     */     } else {
/*     */       
/* 708 */       this.logger.log(InternalLogger.Level.WARN, "BundleComponentActivator is not active; not scheduling {0}", null, new Object[] { task });
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BundleLogger getLogger() {
/* 716 */     return this.logger;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public <T> boolean enterCreate(ServiceReference<T> serviceReference) {
/* 722 */     return this.m_componentRegistry.enterCreate(serviceReference);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public <T> void leaveCreate(ServiceReference<T> serviceReference) {
/* 728 */     this.m_componentRegistry.leaveCreate(serviceReference);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public <T> void missingServicePresent(ServiceReference<T> serviceReference) {
/* 734 */     this.m_componentRegistry.missingServicePresent(serviceReference, this.m_componentActor);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <S, T> void registerMissingDependency(DependencyManager<S, T> dependencyManager, ServiceReference<T> serviceReference, int trackingCount) {
/* 741 */     this.m_componentRegistry.registerMissingDependency(dependencyManager, serviceReference, trackingCount);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public RegionConfigurationSupport setRegionConfigurationSupport(ServiceReference<ConfigurationAdmin> reference) {
/* 747 */     RegionConfigurationSupport rcs = this.m_componentRegistry.registerRegionConfigurationSupport(reference);
/* 748 */     if (rcs != null) {
/* 749 */       for (ComponentHolder<?> holder : this.m_holders)
/*     */       {
/* 751 */         rcs.configureComponentHolder(holder);
/*     */       }
/*     */     }
/* 754 */     return rcs;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void unsetRegionConfigurationSupport(RegionConfigurationSupport rcs) {
/* 760 */     this.m_componentRegistry.unregisterRegionConfigurationSupport(rcs);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void updateChangeCount() {
/* 766 */     this.m_componentRegistry.updateChangeCount();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ServiceReference<?> getTrueCondition() {
/* 772 */     return this.m_trueCondition;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.apache.felix.scr-2.2.6.jar!\org\apache\felix\scr\impl\BundleComponentActivator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */