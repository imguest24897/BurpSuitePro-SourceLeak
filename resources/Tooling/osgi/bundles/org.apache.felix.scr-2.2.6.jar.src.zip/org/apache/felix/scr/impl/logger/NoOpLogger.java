/*    */ package org.apache.felix.scr.impl.logger;
/*    */ 
/*    */ import org.osgi.framework.Bundle;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NoOpLogger
/*    */   implements ScrLogger, BundleLogger, ComponentLogger
/*    */ {
/*    */   public void log(InternalLogger.Level level, String message, Throwable ex) {}
/*    */   
/*    */   public void log(InternalLogger.Level level, String message, Throwable ex, Object... args) {}
/*    */   
/*    */   public boolean isLogEnabled(InternalLogger.Level level) {
/* 44 */     return false;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setComponentId(long componentId) {}
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public ComponentLogger component(Bundle bundle, String implementationClassName, String name) {
/* 56 */     return this;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public BundleLogger bundle(Bundle bundle) {
/* 62 */     return this;
/*    */   }
/*    */   
/*    */   public void close() {}
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.apache.felix.scr-2.2.6.jar!\org\apache\felix\scr\impl\logger\NoOpLogger.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */