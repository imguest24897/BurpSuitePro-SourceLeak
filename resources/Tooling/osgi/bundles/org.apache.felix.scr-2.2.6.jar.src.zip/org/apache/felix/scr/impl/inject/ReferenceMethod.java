/*    */ package org.apache.felix.scr.impl.inject;
/*    */ 
/*    */ import org.osgi.framework.BundleContext;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface ReferenceMethod
/*    */ {
/* 48 */   public static final ReferenceMethod NOPReferenceMethod = new ReferenceMethod()
/*    */     {
/*    */ 
/*    */       
/*    */       public <S, T> MethodResult invoke(Object componentInstance, BindParameters parameters, MethodResult methodCallFailureResult)
/*    */       {
/* 54 */         return MethodResult.VOID;
/*    */       }
/*    */ 
/*    */ 
/*    */       
/*    */       public <S, T> boolean getServiceObject(BindParameters parameters, BundleContext context) {
/* 60 */         return true;
/*    */       }
/*    */     };
/*    */   
/*    */   <S, T> MethodResult invoke(Object paramObject, BindParameters paramBindParameters, MethodResult paramMethodResult);
/*    */   
/*    */   <S, T> boolean getServiceObject(BindParameters paramBindParameters, BundleContext paramBundleContext);
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.apache.felix.scr-2.2.6.jar!\org\apache\felix\scr\impl\inject\ReferenceMethod.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */