/*    */ package org.apache.felix.scr.impl.inject.methods;
/*    */ 
/*    */ import org.apache.felix.scr.impl.inject.InitReferenceMethod;
/*    */ import org.apache.felix.scr.impl.inject.ReferenceMethod;
/*    */ import org.apache.felix.scr.impl.inject.ReferenceMethods;
/*    */ import org.apache.felix.scr.impl.metadata.DSVersion;
/*    */ import org.apache.felix.scr.impl.metadata.ReferenceMetadata;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class BindMethods
/*    */   implements ReferenceMethods
/*    */ {
/*    */   private final ReferenceMethod m_bind;
/*    */   private final ReferenceMethod m_updated;
/*    */   private final ReferenceMethod m_unbind;
/*    */   
/*    */   public BindMethods(ReferenceMetadata m_dependencyMetadata, Class<?> instanceClass, DSVersion dsVersion, boolean configurableServiceProperties) {
/* 40 */     this
/*    */ 
/*    */       
/* 43 */       .m_bind = new BindMethod(m_dependencyMetadata.getBind(), instanceClass, m_dependencyMetadata.getInterface(), dsVersion, configurableServiceProperties);
/*    */ 
/*    */     
/* 46 */     this
/*    */ 
/*    */       
/* 49 */       .m_updated = new UpdatedMethod(m_dependencyMetadata.getUpdated(), instanceClass, m_dependencyMetadata.getInterface(), dsVersion, configurableServiceProperties);
/*    */ 
/*    */     
/* 52 */     this
/*    */ 
/*    */       
/* 55 */       .m_unbind = new UnbindMethod(m_dependencyMetadata.getUnbind(), instanceClass, m_dependencyMetadata.getInterface(), dsVersion, configurableServiceProperties);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public ReferenceMethod getBind() {
/* 62 */     return this.m_bind;
/*    */   }
/*    */ 
/*    */   
/*    */   public ReferenceMethod getUnbind() {
/* 67 */     return this.m_unbind;
/*    */   }
/*    */ 
/*    */   
/*    */   public ReferenceMethod getUpdated() {
/* 72 */     return this.m_updated;
/*    */   }
/*    */ 
/*    */   
/*    */   public InitReferenceMethod getInit() {
/* 77 */     return null;
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.apache.felix.scr-2.2.6.jar!\org\apache\felix\scr\impl\inject\methods\BindMethods.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */