/*     */ package org.apache.felix.scr.impl.helper;
/*     */ 
/*     */ import java.lang.reflect.Array;
/*     */ import java.util.Collection;
/*     */ import org.osgi.framework.Bundle;
/*     */ import org.osgi.service.component.ComponentException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Coercions
/*     */ {
/*     */   private static final byte byte0 = 0;
/*     */   private static final char char0 = '\000';
/*     */   private static final double double0 = 0.0D;
/*     */   private static final float float0 = 0.0F;
/*     */   private static final int int0 = 0;
/*     */   private static final long long0 = 0L;
/*     */   private static final short short0 = 0;
/*     */   
/*     */   public static Object coerce(Class<?> type, Object raw, Bundle bundle) {
/*  50 */     if (type == Byte.class || type == byte.class)
/*     */     {
/*  52 */       return Byte.valueOf(coerceToByte(raw));
/*     */     }
/*  54 */     if (type == Boolean.class || type == boolean.class)
/*     */     {
/*  56 */       return Boolean.valueOf(coerceToBoolean(raw));
/*     */     }
/*  58 */     if (type == Character.class || type == char.class)
/*     */     {
/*  60 */       return Character.valueOf(coerceToChar(raw));
/*     */     }
/*  62 */     if (type == Class.class)
/*     */     {
/*  64 */       return coerceToClass(raw, bundle);
/*     */     }
/*  66 */     if (type == Double.class || type == double.class)
/*     */     {
/*  68 */       return Double.valueOf(coerceToDouble(raw));
/*     */     }
/*  70 */     if (type.isEnum()) {
/*     */ 
/*     */       
/*  73 */       Class<?> clazz = type;
/*  74 */       return coerceToEnum(raw, clazz);
/*     */     } 
/*  76 */     if (type == Float.class || type == float.class)
/*     */     {
/*  78 */       return Float.valueOf(coerceToFloat(raw));
/*     */     }
/*  80 */     if (type == Integer.class || type == int.class)
/*     */     {
/*  82 */       return Integer.valueOf(coerceToInteger(raw));
/*     */     }
/*  84 */     if (type == Long.class || type == long.class)
/*     */     {
/*  86 */       return Long.valueOf(coerceToLong(raw));
/*     */     }
/*  88 */     if (type == Short.class || type == short.class)
/*     */     {
/*  90 */       return Short.valueOf(coerceToShort(raw));
/*     */     }
/*  92 */     if (type == String.class)
/*     */     {
/*  94 */       return coerceToString(raw);
/*     */     }
/*  96 */     if (raw != null) {
/*     */       
/*  98 */       raw = multipleToSingle(raw, null);
/*  99 */       if (raw != null) {
/*     */         
/* 101 */         if (type.isAssignableFrom(raw.getClass()))
/*     */         {
/* 103 */           return raw;
/*     */         }
/* 105 */         throw new ComponentException("unexpected output type " + type);
/*     */       } 
/*     */     } 
/* 108 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public static byte coerceToByte(Object o) {
/* 113 */     o = multipleToSingle(o, Byte.valueOf((byte)0));
/* 114 */     if (o instanceof Byte)
/*     */     {
/* 116 */       return ((Byte)o).byteValue();
/*     */     }
/* 118 */     if (o instanceof String) {
/*     */       
/*     */       try {
/*     */         
/* 122 */         return Byte.parseByte((String)o);
/*     */       }
/* 124 */       catch (NumberFormatException e) {
/*     */         
/* 126 */         throw new ComponentException(e);
/*     */       } 
/*     */     }
/* 129 */     if (o instanceof Boolean)
/*     */     {
/* 131 */       return ((Boolean)o).booleanValue() ? 1 : 0;
/*     */     }
/* 133 */     if (o instanceof Character)
/*     */     {
/* 135 */       return (byte)((Character)o).charValue();
/*     */     }
/* 137 */     if (o instanceof Number)
/*     */     {
/* 139 */       return ((Number)o).byteValue();
/*     */     }
/* 141 */     if (o == null)
/*     */     {
/* 143 */       return 0;
/*     */     }
/* 145 */     throw new ComponentException("Unrecognized input value: " + o + " of type: " + o.getClass());
/*     */   }
/*     */ 
/*     */   
/*     */   public static char coerceToChar(Object o) {
/* 150 */     o = multipleToSingle(o, Byte.valueOf((byte)0));
/* 151 */     if (o instanceof Character)
/*     */     {
/* 153 */       return ((Character)o).charValue();
/*     */     }
/* 155 */     if (o instanceof String) {
/*     */       
/* 157 */       if (((String)o).length() > 0)
/*     */       {
/* 159 */         return ((String)o).charAt(0);
/*     */       }
/* 161 */       return Character.MIN_VALUE;
/*     */     } 
/* 163 */     if (o instanceof Boolean)
/*     */     {
/* 165 */       return ((Boolean)o).booleanValue() ? '\001' : Character.MIN_VALUE;
/*     */     }
/* 167 */     if (o instanceof Number)
/*     */     {
/* 169 */       return (char)((Number)o).intValue();
/*     */     }
/* 171 */     if (o == null)
/*     */     {
/* 173 */       return Character.MIN_VALUE;
/*     */     }
/* 175 */     throw new ComponentException("Unrecognized input value: " + o + " of type: " + o.getClass());
/*     */   }
/*     */ 
/*     */   
/*     */   public static double coerceToDouble(Object o) {
/* 180 */     o = multipleToSingle(o, Double.valueOf(0.0D));
/* 181 */     if (o instanceof Double)
/*     */     {
/* 183 */       return ((Double)o).doubleValue();
/*     */     }
/* 185 */     if (o instanceof String) {
/*     */       
/*     */       try {
/*     */         
/* 189 */         return Double.parseDouble((String)o);
/*     */       }
/* 191 */       catch (NumberFormatException e) {
/*     */         
/* 193 */         throw new ComponentException(e);
/*     */       } 
/*     */     }
/* 196 */     if (o instanceof Boolean)
/*     */     {
/* 198 */       return ((Boolean)o).booleanValue() ? 1.0D : 0.0D;
/*     */     }
/* 200 */     if (o instanceof Character)
/*     */     {
/* 202 */       return ((Character)o).charValue();
/*     */     }
/* 204 */     if (o instanceof Number)
/*     */     {
/* 206 */       return ((Number)o).doubleValue();
/*     */     }
/* 208 */     if (o == null)
/*     */     {
/* 210 */       return 0.0D;
/*     */     }
/* 212 */     throw new ComponentException("Unrecognized input value: " + o + " of type: " + o.getClass());
/*     */   }
/*     */ 
/*     */   
/*     */   public static float coerceToFloat(Object o) {
/* 217 */     o = multipleToSingle(o, Float.valueOf(0.0F));
/* 218 */     if (o instanceof Float)
/*     */     {
/* 220 */       return ((Float)o).floatValue();
/*     */     }
/* 222 */     if (o instanceof String) {
/*     */       
/*     */       try {
/*     */         
/* 226 */         return Float.parseFloat((String)o);
/*     */       }
/* 228 */       catch (NumberFormatException e) {
/*     */         
/* 230 */         throw new ComponentException(e);
/*     */       } 
/*     */     }
/* 233 */     if (o instanceof Boolean)
/*     */     {
/* 235 */       return ((Boolean)o).booleanValue() ? 1.0F : 0.0F;
/*     */     }
/* 237 */     if (o instanceof Character)
/*     */     {
/* 239 */       return ((Character)o).charValue();
/*     */     }
/* 241 */     if (o instanceof Number)
/*     */     {
/* 243 */       return ((Number)o).floatValue();
/*     */     }
/* 245 */     if (o == null)
/*     */     {
/* 247 */       return 0.0F;
/*     */     }
/* 249 */     throw new ComponentException("Unrecognized input value: " + o + " of type: " + o.getClass());
/*     */   }
/*     */ 
/*     */   
/*     */   public static int coerceToInteger(Object o) {
/* 254 */     o = multipleToSingle(o, Integer.valueOf(0));
/* 255 */     if (o instanceof Integer)
/*     */     {
/* 257 */       return ((Integer)o).intValue();
/*     */     }
/* 259 */     if (o instanceof String) {
/*     */       
/*     */       try {
/*     */         
/* 263 */         return Integer.parseInt((String)o);
/*     */       }
/* 265 */       catch (NumberFormatException e) {
/*     */         
/* 267 */         throw new ComponentException(e);
/*     */       } 
/*     */     }
/* 270 */     if (o instanceof Boolean)
/*     */     {
/* 272 */       return ((Boolean)o).booleanValue() ? 1 : 0;
/*     */     }
/* 274 */     if (o instanceof Character)
/*     */     {
/* 276 */       return ((Character)o).charValue();
/*     */     }
/* 278 */     if (o instanceof Number)
/*     */     {
/* 280 */       return ((Number)o).intValue();
/*     */     }
/* 282 */     if (o == null)
/*     */     {
/* 284 */       return 0;
/*     */     }
/* 286 */     throw new ComponentException("Unrecognized input value: " + o + " of type: " + o.getClass());
/*     */   }
/*     */ 
/*     */   
/*     */   public static long coerceToLong(Object o) {
/* 291 */     o = multipleToSingle(o, Long.valueOf(0L));
/* 292 */     if (o instanceof Long)
/*     */     {
/* 294 */       return ((Long)o).longValue();
/*     */     }
/* 296 */     if (o instanceof String) {
/*     */       
/*     */       try {
/*     */         
/* 300 */         return Long.parseLong((String)o);
/*     */       }
/* 302 */       catch (NumberFormatException e) {
/*     */         
/* 304 */         throw new ComponentException(e);
/*     */       } 
/*     */     }
/* 307 */     if (o instanceof Boolean)
/*     */     {
/* 309 */       return ((Boolean)o).booleanValue() ? 1L : 0L;
/*     */     }
/* 311 */     if (o instanceof Character)
/*     */     {
/* 313 */       return ((Character)o).charValue();
/*     */     }
/* 315 */     if (o instanceof Number)
/*     */     {
/* 317 */       return ((Number)o).longValue();
/*     */     }
/* 319 */     if (o == null)
/*     */     {
/* 321 */       return 0L;
/*     */     }
/* 323 */     throw new ComponentException("Unrecognized input value: " + o + " of type: " + o.getClass());
/*     */   }
/*     */ 
/*     */   
/*     */   public static short coerceToShort(Object o) {
/* 328 */     o = multipleToSingle(o, Short.valueOf((short)0));
/* 329 */     if (o instanceof Short)
/*     */     {
/* 331 */       return ((Short)o).shortValue();
/*     */     }
/* 333 */     if (o instanceof String) {
/*     */       
/*     */       try {
/*     */         
/* 337 */         return Short.parseShort((String)o);
/*     */       }
/* 339 */       catch (NumberFormatException e) {
/*     */         
/* 341 */         throw new ComponentException(e);
/*     */       } 
/*     */     }
/* 344 */     if (o instanceof Boolean)
/*     */     {
/* 346 */       return ((Boolean)o).booleanValue() ? 1 : 0;
/*     */     }
/* 348 */     if (o instanceof Character)
/*     */     {
/* 350 */       return (short)((Character)o).charValue();
/*     */     }
/* 352 */     if (o instanceof Number)
/*     */     {
/* 354 */       return ((Number)o).shortValue();
/*     */     }
/* 356 */     if (o == null)
/*     */     {
/* 358 */       return 0;
/*     */     }
/* 360 */     throw new ComponentException("Unrecognized input value: " + o + " of type: " + o.getClass());
/*     */   }
/*     */ 
/*     */   
/*     */   public static String coerceToString(Object o) {
/* 365 */     o = multipleToSingle(o, null);
/* 366 */     if (o instanceof String)
/*     */     {
/* 368 */       return (String)o;
/*     */     }
/* 370 */     if (o == null)
/*     */     {
/* 372 */       return null;
/*     */     }
/*     */     
/* 375 */     return o.toString();
/*     */   }
/*     */ 
/*     */   
/*     */   public static boolean coerceToBoolean(Object o) {
/* 380 */     o = multipleToSingle(o, Boolean.valueOf(false));
/* 381 */     if (o instanceof Boolean)
/*     */     {
/* 383 */       return ((Boolean)o).booleanValue();
/*     */     }
/* 385 */     if (o instanceof String) {
/*     */       
/*     */       try {
/*     */         
/* 389 */         return Boolean.parseBoolean((String)o);
/*     */       }
/* 391 */       catch (NumberFormatException e) {
/*     */         
/* 393 */         throw new ComponentException(e);
/*     */       } 
/*     */     }
/* 396 */     if (o instanceof Character)
/*     */     {
/* 398 */       return (((Character)o).charValue() != '\000');
/*     */     }
/* 400 */     if (o instanceof Number)
/*     */     {
/* 402 */       return (((Number)o).doubleValue() != 0.0D);
/*     */     }
/* 404 */     if (o == null)
/*     */     {
/* 406 */       return false;
/*     */     }
/* 408 */     throw new ComponentException("Unrecognized input value: " + o + " of type: " + o.getClass());
/*     */   }
/*     */ 
/*     */   
/*     */   public static Class<?> coerceToClass(Object o, Bundle b) {
/* 413 */     o = multipleToSingle(o, null);
/* 414 */     if (o == null)
/*     */     {
/* 416 */       return null;
/*     */     }
/* 418 */     if (o instanceof String) {
/*     */       
/*     */       try {
/*     */         
/* 422 */         return b.loadClass((String)o);
/*     */       }
/* 424 */       catch (ClassNotFoundException e) {
/*     */         
/* 426 */         throw new ComponentException(e);
/*     */       } 
/*     */     }
/* 429 */     throw new ComponentException("Unrecognized input value: " + o + " of type: " + o.getClass());
/*     */   }
/*     */ 
/*     */   
/*     */   public static <T extends Enum<T>> T coerceToEnum(Object o, Class<T> clazz) {
/* 434 */     o = multipleToSingle(o, null);
/* 435 */     if (o instanceof String) {
/*     */       
/*     */       try {
/*     */         
/* 439 */         return Enum.valueOf(clazz, (String)o);
/*     */       }
/* 441 */       catch (IllegalArgumentException e) {
/*     */         
/* 443 */         throw new ComponentException(e);
/*     */       } 
/*     */     }
/* 446 */     if (o == null)
/*     */     {
/* 448 */       return null;
/*     */     }
/* 450 */     throw new ComponentException("Unrecognized input value: " + o + " of type: " + o.getClass());
/*     */   }
/*     */ 
/*     */   
/*     */   private static Object multipleToSingle(Object o, Object defaultValue) {
/* 455 */     if (o instanceof Collection)
/*     */     {
/* 457 */       return firstCollectionElement(o, defaultValue);
/*     */     }
/* 459 */     if (o != null && o.getClass().isArray())
/*     */     {
/* 461 */       return firstArrayElement(o, defaultValue);
/*     */     }
/* 463 */     return o;
/*     */   }
/*     */ 
/*     */   
/*     */   private static Object firstCollectionElement(Object raw, Object defaultValue) {
/* 468 */     if (!(raw instanceof Collection))
/*     */     {
/* 470 */       throw new ComponentException("Not a collection: " + raw);
/*     */     }
/* 472 */     Collection<?> c = (Collection)raw;
/* 473 */     if (c.isEmpty())
/*     */     {
/* 475 */       return defaultValue;
/*     */     }
/* 477 */     return c.iterator().next();
/*     */   }
/*     */ 
/*     */   
/*     */   private static Object firstArrayElement(Object o, Object defaultValue) {
/* 482 */     if (o == null || !o.getClass().isArray())
/*     */     {
/* 484 */       throw new ComponentException("Not an array: " + o);
/*     */     }
/* 486 */     if (Array.getLength(o) == 0)
/*     */     {
/* 488 */       return defaultValue;
/*     */     }
/* 490 */     return Array.get(o, 0);
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.apache.felix.scr-2.2.6.jar!\org\apache\felix\scr\impl\helper\Coercions.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */