/*     */ package org.apache.felix.scr.impl.manager;
/*     */ 
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Dictionary;
/*     */ import java.util.Enumeration;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.apache.felix.scr.impl.inject.ComponentMethods;
/*     */ import org.apache.felix.scr.impl.logger.ComponentLogger;
/*     */ import org.apache.felix.scr.impl.logger.InternalLogger;
/*     */ import org.apache.felix.scr.impl.metadata.ComponentMetadata;
/*     */ import org.apache.felix.scr.impl.metadata.ServiceMetadata;
/*     */ import org.apache.felix.scr.impl.metadata.TargetedPID;
/*     */ import org.osgi.util.promise.Deferred;
/*     */ import org.osgi.util.promise.Promise;
/*     */ import org.osgi.util.promise.Promises;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class ConfigurableComponentHolder<S>
/*     */   implements ComponentHolder<S>, ComponentContainer<S>
/*     */ {
/*     */   private final ComponentActivator m_activator;
/*     */   private final ComponentMetadata m_componentMetadata;
/*     */   private final TargetedPID[] m_targetedPids;
/*     */   private final Long[] m_changeCount;
/*  81 */   private final Map<String, Long> m_factoryChangeCount = new HashMap<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private volatile Integer m_factoryPidIndex;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final Dictionary<String, Object>[] m_configurations;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  98 */   private final Map<String, Dictionary<String, Object>> m_factoryConfigurations = new HashMap<>();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 103 */   private final Map<String, TargetedPID> m_factoryTargetedPids = new HashMap<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final Map<String, AbstractComponentManager<S>> m_components;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private volatile AbstractComponentManager<S> m_singleComponent;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private volatile boolean m_enabled;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 138 */   private final Object enableLock = new Object();
/*     */   private volatile Promise<Void> m_enablePromise;
/* 140 */   private volatile Promise<Void> m_disablePromise = Promises.resolved(null);
/*     */ 
/*     */   
/*     */   private final ComponentMethods<S> m_componentMethods;
/*     */ 
/*     */   
/*     */   private final ComponentLogger logger;
/*     */ 
/*     */   
/*     */   public ConfigurableComponentHolder(ComponentActivator activator, ComponentMetadata metadata, ComponentLogger logger) {
/* 150 */     this.logger = logger;
/* 151 */     this.m_activator = activator;
/* 152 */     this.m_componentMetadata = metadata;
/* 153 */     int pidCount = metadata.getConfigurationPid().size();
/* 154 */     this.m_targetedPids = new TargetedPID[pidCount];
/*     */     
/* 156 */     Dictionary[] arrayOfDictionary = new Dictionary[pidCount];
/* 157 */     this.m_configurations = (Dictionary<String, Object>[])arrayOfDictionary;
/* 158 */     this.m_changeCount = new Long[pidCount];
/* 159 */     this.m_components = new HashMap<>();
/* 160 */     this.m_componentMethods = createComponentMethods();
/* 161 */     this.m_enabled = false;
/*     */   }
/*     */   
/*     */   protected abstract ComponentMethods<S> createComponentMethods();
/*     */   
/*     */   protected ComponentMethods<S> getComponentMethods() {
/* 167 */     return this.m_componentMethods;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected AbstractComponentManager<S> createComponentManager(boolean factoryConfiguration) {
/*     */     AbstractComponentManager<S> manager;
/* 174 */     if (this.m_componentMetadata.isFactory()) {
/*     */ 
/*     */       
/* 177 */       if (!this.m_componentMetadata.isObsoleteFactoryComponentFactory() || !factoryConfiguration)
/*     */       {
/* 179 */         manager = new ComponentFactoryImpl<>(this, this.m_componentMethods);
/*     */       }
/*     */       else
/*     */       {
/* 183 */         manager = new SingleComponentManager<>(this, this.m_componentMethods, true);
/*     */       }
/*     */     
/* 186 */     } else if (this.m_componentMetadata.getServiceScope() == ServiceMetadata.Scope.bundle) {
/*     */       
/* 188 */       manager = new ServiceFactoryComponentManager<>(this, this.m_componentMethods);
/*     */     
/*     */     }
/* 191 */     else if (this.m_componentMetadata.getServiceScope() == ServiceMetadata.Scope.prototype) {
/*     */       
/* 193 */       manager = PSFLoader.newPSFComponentManager(this, this.m_componentMethods);
/*     */     
/*     */     }
/*     */     else {
/*     */ 
/*     */       
/* 199 */       manager = new SingleComponentManager<>(this, this.m_componentMethods);
/*     */     } 
/*     */     
/* 202 */     return manager;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static class PSFLoader
/*     */   {
/*     */     static <S> AbstractComponentManager<S> newPSFComponentManager(ConfigurableComponentHolder<S> holder, ComponentMethods<S> methods) {
/* 210 */       return new PrototypeServiceFactoryComponentManager<>(holder, methods);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ComponentActivator getActivator() {
/* 218 */     return this.m_activator;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ComponentMetadata getComponentMetadata() {
/* 225 */     return this.m_componentMetadata;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void configurationDeleted(TargetedPID pid, TargetedPID factoryPid) {
/* 252 */     this.logger.log(InternalLogger.Level.DEBUG, "ImmediateComponentHolder configuration deleted for pid {0}", null, new Object[] { pid });
/*     */ 
/*     */ 
/*     */     
/* 256 */     Map<AbstractComponentManager<S>, Map<String, Object>> scms = new HashMap<>();
/* 257 */     boolean reconfigure = false;
/*     */     
/* 259 */     synchronized (this.m_components) {
/*     */       
/* 261 */       if (factoryPid != null) {
/* 262 */         checkFactoryPidIndex(factoryPid);
/* 263 */         String servicePid = pid.getServicePid();
/* 264 */         this.m_factoryTargetedPids.remove(servicePid);
/* 265 */         this.m_factoryChangeCount.remove(servicePid);
/* 266 */         this.m_factoryConfigurations.remove(servicePid);
/* 267 */         AbstractComponentManager<S> scm = this.m_components.remove(servicePid);
/* 268 */         if (this.m_factoryConfigurations.isEmpty())
/*     */         {
/* 270 */           this.m_factoryPidIndex = null;
/*     */         }
/* 272 */         if (!this.m_enabled || scm == null) {
/*     */           return;
/*     */         }
/*     */         
/* 276 */         reconfigure = (this.m_componentMetadata.isConfigurationOptional() && this.m_components.isEmpty());
/* 277 */         if (reconfigure)
/*     */         {
/* 279 */           this.m_singleComponent = scm;
/* 280 */           scms.put(scm, mergeProperties(null));
/*     */         }
/*     */         else
/*     */         {
/* 284 */           scms.put(scm, null);
/*     */         }
/*     */       
/*     */       }
/*     */       else {
/*     */         
/* 290 */         int index = getSingletonPidIndex(pid);
/* 291 */         this.m_targetedPids[index] = null;
/* 292 */         this.m_changeCount[index] = null;
/* 293 */         this.m_configurations[index] = null;
/* 294 */         if (!this.m_enabled) {
/*     */           return;
/*     */         }
/*     */         
/* 298 */         reconfigure = this.m_componentMetadata.isConfigurationOptional();
/*     */         
/* 300 */         if (this.m_factoryPidIndex == null) {
/*     */           
/* 302 */           if (this.m_singleComponent != null) {
/* 303 */             if (reconfigure) {
/* 304 */               scms.put(this.m_singleComponent, mergeProperties(null));
/*     */             } else {
/* 306 */               scms.put(this.m_singleComponent, null);
/* 307 */               this.m_singleComponent = null;
/*     */             
/*     */             }
/*     */           
/*     */           }
/*     */         }
/* 313 */         else if (reconfigure) {
/* 314 */           for (Map.Entry<String, AbstractComponentManager<S>> entry : this.m_components.entrySet()) {
/* 315 */             scms.put(entry.getValue(), mergeProperties(entry.getKey()));
/*     */           }
/*     */         }
/*     */         else {
/*     */           
/* 320 */           for (Map.Entry<String, AbstractComponentManager<S>> entry : this.m_components.entrySet()) {
/* 321 */             scms.put(entry.getValue(), null);
/*     */           }
/* 323 */           this.m_components.clear();
/*     */         } 
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 330 */     for (Map.Entry<AbstractComponentManager<S>, Map<String, Object>> entry : scms.entrySet()) {
/*     */       
/* 332 */       if (reconfigure) {
/* 333 */         ((AbstractComponentManager)entry.getKey()).reconfigure(entry.getValue(), true, factoryPid); continue;
/*     */       } 
/* 335 */       ((AbstractComponentManager)entry.getKey()).dispose(4);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean configurationUpdated(TargetedPID pid, TargetedPID factoryPid, Dictionary<String, Object> props, long changeCount) {
/* 360 */     this.logger.log(InternalLogger.Level.DEBUG, "ConfigurableComponentHolder configuration updated for pid {0} with change count {1}", null, new Object[] { pid, 
/*     */           
/* 362 */           Long.valueOf(changeCount) });
/*     */ 
/*     */     
/* 365 */     Map<AbstractComponentManager<S>, Map<String, Object>> scms = new HashMap<>();
/* 366 */     boolean created = false;
/*     */     
/* 368 */     synchronized (this.m_components) {
/*     */       
/* 370 */       if (factoryPid != null) {
/* 371 */         checkFactoryPidIndex(factoryPid);
/* 372 */         Long oldChangeCount = this.m_factoryChangeCount.get(pid.getServicePid());
/* 373 */         TargetedPID oldTargetedPID = this.m_factoryTargetedPids.get(pid.getServicePid());
/* 374 */         if (oldChangeCount != null && changeCount <= oldChangeCount.longValue() && factoryPid.equals(oldTargetedPID)) {
/* 375 */           return false;
/*     */         }
/* 377 */         this.m_factoryChangeCount.put(pid.getServicePid(), Long.valueOf(changeCount));
/* 378 */         this.m_factoryConfigurations.put(pid.getServicePid(), props);
/* 379 */         this.m_factoryTargetedPids.put(pid.getServicePid(), factoryPid);
/* 380 */         if (this.m_enabled && isSatisfied()) {
/* 381 */           if (this.m_singleComponent != null && !this.m_componentMetadata.isObsoleteFactoryComponentFactory()) {
/* 382 */             AbstractComponentManager<S> scm = this.m_singleComponent;
/* 383 */             scms.put(scm, mergeProperties(pid.getServicePid()));
/* 384 */             this.m_singleComponent = null;
/* 385 */             this.m_components.put(pid.getServicePid(), scm);
/* 386 */           } else if (this.m_components.containsKey(pid.getServicePid())) {
/* 387 */             scms.put(this.m_components.get(pid.getServicePid()), mergeProperties(pid.getServicePid()));
/*     */           } else {
/* 389 */             AbstractComponentManager<S> scm = createComponentManager(true);
/* 390 */             this.m_components.put(pid.getServicePid(), scm);
/* 391 */             scms.put(scm, mergeProperties(pid.getServicePid()));
/* 392 */             created = true;
/*     */           } 
/*     */         } else {
/* 395 */           return false;
/*     */         }
/*     */       
/*     */       } else {
/*     */         
/* 400 */         int index = getSingletonPidIndex(pid);
/* 401 */         if (this.m_changeCount[index] != null && changeCount <= this.m_changeCount[index].longValue() && pid.equals(this.m_targetedPids[index])) {
/* 402 */           return false;
/*     */         }
/* 404 */         this.m_changeCount[index] = Long.valueOf(changeCount);
/* 405 */         this.m_targetedPids[index] = pid;
/* 406 */         this.m_configurations[index] = props;
/* 407 */         if (this.m_enabled && isSatisfied()) {
/* 408 */           if (this.m_singleComponent != null) {
/* 409 */             scms.put(this.m_singleComponent, mergeProperties(pid.getServicePid()));
/*     */           }
/* 411 */           else if (this.m_factoryPidIndex != null) {
/*     */             
/* 413 */             for (Map.Entry<String, AbstractComponentManager<S>> entry : this.m_components.entrySet())
/*     */             {
/* 415 */               scms.put(entry.getValue(), mergeProperties(entry.getKey()));
/*     */             }
/*     */           }
/*     */           else {
/*     */             
/* 420 */             this.m_singleComponent = createComponentManager(false);
/* 421 */             scms.put(this.m_singleComponent, mergeProperties(pid.getServicePid()));
/* 422 */             created = true;
/*     */           } 
/*     */         } else {
/* 425 */           return false;
/*     */         } 
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 436 */     boolean enable = (created && this.m_enabled);
/* 437 */     for (Map.Entry<AbstractComponentManager<S>, Map<String, Object>> entry : scms.entrySet()) {
/*     */ 
/*     */       
/* 440 */       ((AbstractComponentManager)entry.getKey()).reconfigure(entry.getValue(), false, factoryPid);
/* 441 */       this.logger.log(InternalLogger.Level.DEBUG, "ImmediateComponentHolder Finished configuring the dependency managers for component for pid {0} ", null, new Object[] { pid });
/*     */ 
/*     */       
/* 444 */       if (enable) {
/* 445 */         ((AbstractComponentManager)entry.getKey()).enable(false);
/* 446 */         this.logger.log(InternalLogger.Level.DEBUG, "ImmediateComponentHolder Finished enabling component for pid {0} ", null, new Object[] { pid });
/*     */         
/*     */         continue;
/*     */       } 
/* 450 */       this.logger.log(InternalLogger.Level.DEBUG, "ImmediateComponentHolder Will not enable component for pid {0}: holder enabled state: {1}, metadata enabled: {2} ", null, new Object[] { pid, 
/*     */             
/* 452 */             Boolean.valueOf(this.m_enabled), Boolean.valueOf(this.m_componentMetadata.isEnabled()) });
/*     */     } 
/*     */     
/* 455 */     return created;
/*     */   }
/*     */   
/*     */   private Map<String, Object> mergeProperties(String servicePid) {
/* 459 */     Map<String, Object> properties = new HashMap<>(this.m_componentMetadata.getProperties());
/* 460 */     List<String> pids = null;
/* 461 */     boolean isDS13 = this.m_componentMetadata.getDSVersion().isDS13();
/* 462 */     if (isDS13) {
/*     */       
/* 464 */       pids = new ArrayList<>();
/* 465 */       if (properties.get("service.pid") instanceof String)
/*     */       {
/* 467 */         pids.add((String)properties.get("service.pid"));
/*     */       }
/*     */     } 
/* 470 */     for (int i = 0; i < this.m_configurations.length; i++) {
/*     */       
/* 472 */       if (this.m_factoryPidIndex != null && i == this.m_factoryPidIndex.intValue() && (
/* 473 */         !this.m_componentMetadata.isObsoleteFactoryComponentFactory() || servicePid != null)) {
/*     */         
/* 475 */         copyTo(properties, this.m_factoryConfigurations.get(servicePid));
/* 476 */         if (isDS13)
/*     */         {
/* 478 */           pids.add((String)((Dictionary)this.m_factoryConfigurations.get(servicePid)).get("service.pid"));
/*     */         }
/*     */       }
/* 481 */       else if (this.m_configurations[i] != null) {
/*     */         
/* 483 */         copyTo(properties, this.m_configurations[i]);
/* 484 */         if (isDS13)
/*     */         {
/* 486 */           pids.add((String)this.m_configurations[i].get("service.pid"));
/*     */         }
/*     */       } 
/*     */     } 
/* 490 */     if (isDS13 && !pids.isEmpty())
/*     */     {
/* 492 */       if (pids.size() == 1) {
/*     */         
/* 494 */         properties.put("service.pid", pids.get(0));
/*     */       }
/*     */       else {
/*     */         
/* 498 */         properties.put("service.pid", pids);
/*     */       } 
/*     */     }
/* 501 */     return properties;
/*     */   }
/*     */   
/*     */   private int getSingletonPidIndex(TargetedPID pid) {
/* 505 */     int index = this.m_componentMetadata.getPidIndex(pid);
/* 506 */     if (index == -1) {
/* 507 */       this.logger.log(InternalLogger.Level.ERROR, "Unrecognized pid {0}, expected one of {1}", null, new Object[] { pid, this.m_componentMetadata
/*     */ 
/*     */             
/* 510 */             .getConfigurationPid() });
/* 511 */       throw new IllegalArgumentException("Unrecognized pid " + pid);
/*     */     } 
/*     */     
/* 514 */     if (this.m_factoryPidIndex != null && index == this.m_factoryPidIndex.intValue()) {
/* 515 */       this.logger.log(InternalLogger.Level.ERROR, "singleton pid {0} supplied, but matches an existing factory pid at index: {1}", null, new Object[] { pid, this.m_factoryPidIndex });
/*     */ 
/*     */       
/* 518 */       throw new IllegalStateException("Singleton pid supplied matching a previous factory pid " + pid);
/*     */     } 
/*     */ 
/*     */     
/* 522 */     return index;
/*     */   }
/*     */ 
/*     */   
/*     */   private void checkFactoryPidIndex(TargetedPID factoryPid) {
/* 527 */     int index = this.m_componentMetadata.getPidIndex(factoryPid);
/* 528 */     if (index == -1) {
/* 529 */       this.logger.log(InternalLogger.Level.ERROR, "Unrecognized factory pid {0}, expected one of {1}", null, new Object[] { factoryPid, this.m_componentMetadata
/*     */ 
/*     */             
/* 532 */             .getConfigurationPid() });
/* 533 */       throw new IllegalArgumentException("Unrecognized factory pid " + factoryPid);
/*     */     } 
/*     */     
/* 536 */     if (this.m_configurations[index] != null) {
/*     */       
/* 538 */       this.logger.log(InternalLogger.Level.ERROR, "factory pid {0}, but this pid is already supplied as a singleton: {1} at index {2}", null, new Object[] { factoryPid, 
/*     */             
/* 540 */             Arrays.asList(this.m_targetedPids), Integer.valueOf(index) });
/* 541 */       throw new IllegalStateException("Factory pid supplied after all non-factory configurations supplied " + factoryPid);
/*     */     } 
/*     */ 
/*     */     
/* 545 */     if (this.m_factoryPidIndex == null) {
/* 546 */       this.m_factoryPidIndex = Integer.valueOf(index);
/* 547 */     } else if (index != this.m_factoryPidIndex.intValue()) {
/* 548 */       this.logger.log(InternalLogger.Level.ERROR, "factory pid {0} supplied for index {1}, but a factory pid previously supplied at index {2}", null, new Object[] { factoryPid, 
/*     */             
/* 550 */             Integer.valueOf(index), this.m_factoryPidIndex });
/* 551 */       throw new IllegalStateException("Factory pid supplied at wrong index " + factoryPid);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static void copyTo(Map<String, Object> target, Dictionary<String, ?> source) {
/* 559 */     for (Enumeration<String> keys = source.keys(); keys.hasMoreElements(); ) {
/*     */       
/* 561 */       String key = keys.nextElement();
/* 562 */       Object value = source.get(key);
/* 563 */       target.put(key, value);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean isSatisfied() {
/* 572 */     if (this.m_componentMetadata.isConfigurationOptional() || this.m_componentMetadata.isConfigurationIgnored())
/*     */     {
/* 574 */       return true;
/*     */     }
/* 576 */     for (int i = 0; i < this.m_componentMetadata.getConfigurationPid().size(); i++) {
/*     */       
/* 578 */       if (this.m_configurations[i] == null)
/*     */       {
/*     */ 
/*     */         
/* 582 */         if (this.m_factoryPidIndex == null || this.m_factoryPidIndex.intValue() != i)
/*     */         {
/*     */ 
/*     */           
/* 586 */           return false; }  } 
/*     */     } 
/* 588 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public List<? extends ComponentManager<?>> getComponents() {
/* 594 */     synchronized (this.m_components) {
/*     */       
/* 596 */       return (List)getComponentManagers();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isEnabled() {
/* 603 */     return this.m_enabled;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void wait(Promise<Void> promise) {
/* 609 */     boolean waited = false;
/* 610 */     boolean interrupted = false;
/* 611 */     while (!waited) {
/*     */ 
/*     */       
/*     */       try {
/* 615 */         promise.getValue();
/* 616 */         waited = true;
/*     */       }
/* 618 */       catch (InterruptedException e) {
/*     */         
/* 620 */         interrupted = true;
/*     */       }
/* 622 */       catch (InvocationTargetException invocationTargetException) {}
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 627 */     if (interrupted)
/*     */     {
/* 629 */       Thread.currentThread().interrupt();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Promise<Void> enableComponents(boolean async) {
/* 636 */     synchronized (this.enableLock) {
/*     */       
/* 638 */       if (this.m_enablePromise != null)
/*     */       {
/* 640 */         return this.m_enablePromise;
/*     */       }
/* 642 */       wait(this.m_disablePromise);
/*     */       
/* 644 */       List<AbstractComponentManager<S>> cms = new ArrayList<>();
/* 645 */       synchronized (this.m_components) {
/*     */         
/* 647 */         if (isSatisfied()) {
/*     */           
/* 649 */           if (this.m_factoryPidIndex == null || (this.m_componentMetadata
/* 650 */             .isObsoleteFactoryComponentFactory() && !this.m_componentMetadata.isConfigurationRequired())) {
/*     */             
/* 652 */             this.m_singleComponent = createComponentManager(false);
/* 653 */             cms.add(this.m_singleComponent);
/* 654 */             this.m_singleComponent.reconfigure(mergeProperties(null), false, null);
/*     */           } 
/* 656 */           if (this.m_factoryPidIndex != null)
/*     */           {
/* 658 */             for (String pid : this.m_factoryConfigurations.keySet()) {
/* 659 */               AbstractComponentManager<S> scm = createComponentManager(true);
/* 660 */               this.m_components.put(pid, scm);
/* 661 */               scm.reconfigure(mergeProperties(pid), false, new TargetedPID(pid));
/* 662 */               cms.add(scm);
/*     */             } 
/*     */           }
/*     */         } 
/* 666 */         this.m_enabled = true;
/*     */       } 
/* 668 */       List<Promise<Void>> promises = new ArrayList<>();
/* 669 */       for (AbstractComponentManager<S> cm : cms)
/*     */       {
/* 671 */         promises.add(cm.enable(async));
/*     */       }
/* 673 */       this.m_enablePromise = (new Deferred()).resolveWith(Promises.all(promises));
/* 674 */       this.m_disablePromise = null;
/* 675 */       return this.m_enablePromise;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Promise<Void> disableComponents(boolean async) {
/* 683 */     synchronized (this.enableLock) {
/*     */       List<AbstractComponentManager<S>> cms;
/* 685 */       if (this.m_disablePromise != null)
/*     */       {
/* 687 */         return this.m_disablePromise;
/*     */       }
/* 689 */       wait(this.m_enablePromise);
/*     */ 
/*     */       
/* 692 */       synchronized (this.m_components) {
/*     */         
/* 694 */         this.m_enabled = false;
/*     */         
/* 696 */         cms = getDirectComponentManagers();
/* 697 */         clearComponents();
/*     */       } 
/* 699 */       List<Promise<Void>> promises = new ArrayList<>();
/* 700 */       for (AbstractComponentManager<S> cm : cms)
/*     */       {
/* 702 */         promises.add(cm.disable(async));
/*     */       }
/* 704 */       this.m_disablePromise = (new Deferred()).resolveWith(Promises.all(promises));
/* 705 */       this.m_enablePromise = null;
/* 706 */       return this.m_disablePromise;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void disposeComponents(int reason) {
/*     */     List<AbstractComponentManager<S>> cms;
/* 715 */     synchronized (this.m_components) {
/*     */       
/* 717 */       cms = getDirectComponentManagers();
/* 718 */       clearComponents();
/*     */     } 
/* 720 */     for (AbstractComponentManager<S> cm : cms)
/*     */     {
/* 722 */       cm.dispose(reason);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void disposed(SingleComponentManager<S> component) {
/* 731 */     synchronized (this.m_components) {
/*     */       
/* 733 */       if (!this.m_components.isEmpty())
/*     */       {
/* 735 */         for (Iterator<AbstractComponentManager<S>> vi = this.m_components.values().iterator(); vi.hasNext();) {
/*     */           
/* 737 */           if (component == vi.next()) {
/*     */             
/* 739 */             vi.remove();
/*     */             
/*     */             break;
/*     */           } 
/*     */         } 
/*     */       }
/* 745 */       if (component == this.m_singleComponent)
/*     */       {
/* 747 */         this.m_singleComponent = null;
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object object) {
/* 768 */     if (!(object instanceof ConfigurableComponentHolder))
/*     */     {
/* 770 */       return false;
/*     */     }
/*     */ 
/*     */     
/* 774 */     ConfigurableComponentHolder<S> other = (ConfigurableComponentHolder<S>)object;
/* 775 */     return (this.m_activator == other.m_activator && 
/* 776 */       getName().equals(other.getName()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 787 */     return getName().hashCode();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 793 */     return "[ImmediateComponentHolder:" + getName() + "]";
/*     */   }
/*     */ 
/*     */   
/*     */   String getName() {
/* 798 */     return this.m_componentMetadata.getName();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   List<AbstractComponentManager<S>> getComponentManagers() {
/* 810 */     List<AbstractComponentManager<S>> cms = new ArrayList<>();
/* 811 */     if (this.m_singleComponent != null)
/*     */     {
/* 813 */       this.m_singleComponent.getComponentManagers(cms);
/*     */     }
/*     */     
/* 816 */     for (AbstractComponentManager<S> cm : this.m_components.values())
/*     */     {
/* 818 */       cm.getComponentManagers(cms);
/*     */     }
/* 820 */     return cms;
/*     */   }
/*     */ 
/*     */   
/*     */   List<AbstractComponentManager<S>> getDirectComponentManagers() {
/* 825 */     List<AbstractComponentManager<S>> cms = new ArrayList<>();
/* 826 */     if (this.m_singleComponent != null)
/*     */     {
/* 828 */       cms.add(this.m_singleComponent);
/*     */     }
/* 830 */     cms.addAll(this.m_components.values());
/* 831 */     return cms;
/*     */   }
/*     */ 
/*     */   
/*     */   void clearComponents() {
/* 836 */     this.m_components.clear();
/* 837 */     this.m_singleComponent = null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ComponentLogger getLogger() {
/* 843 */     return this.logger;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public TargetedPID getConfigurationTargetedPID(TargetedPID pid, TargetedPID factoryPid) {
/* 849 */     if (factoryPid == null) {
/*     */       
/* 851 */       int index = this.m_componentMetadata.getPidIndex(pid);
/* 852 */       if (index != -1)
/*     */       {
/* 854 */         return this.m_targetedPids[index];
/*     */       }
/* 856 */       return null;
/*     */     } 
/*     */     
/* 859 */     synchronized (this.m_components) {
/*     */       
/* 861 */       return this.m_factoryTargetedPids.get(pid.getServicePid());
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.apache.felix.scr-2.2.6.jar!\org\apache\felix\scr\impl\manager\ConfigurableComponentHolder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */