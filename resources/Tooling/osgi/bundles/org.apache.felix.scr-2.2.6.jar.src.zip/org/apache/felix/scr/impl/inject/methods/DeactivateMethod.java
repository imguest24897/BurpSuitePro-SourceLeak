/*    */ package org.apache.felix.scr.impl.inject.methods;
/*    */ 
/*    */ import org.apache.felix.scr.impl.metadata.DSVersion;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DeactivateMethod
/*    */   extends ActivateMethod
/*    */ {
/*    */   boolean isDeactivate() {
/* 30 */     return true;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public DeactivateMethod(String methodName, boolean methodRequired, Class<?> componentClass, DSVersion dsVersion, boolean configurableServiceProperties, boolean supportsInterfaces) {
/* 36 */     super(methodName, methodRequired, componentClass, dsVersion, configurableServiceProperties, supportsInterfaces);
/*    */   }
/*    */ 
/*    */   
/*    */   protected String getMethodNamePrefix() {
/* 41 */     return "deactivate";
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.apache.felix.scr-2.2.6.jar!\org\apache\felix\scr\impl\inject\methods\DeactivateMethod.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */