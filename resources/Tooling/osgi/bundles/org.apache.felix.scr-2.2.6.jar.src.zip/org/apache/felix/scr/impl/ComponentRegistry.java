/*     */ package org.apache.felix.scr.impl;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Dictionary;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.Hashtable;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.Timer;
/*     */ import java.util.TimerTask;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import java.util.concurrent.ConcurrentMap;
/*     */ import java.util.concurrent.atomic.AtomicLong;
/*     */ import org.apache.felix.scr.impl.inject.ComponentMethods;
/*     */ import org.apache.felix.scr.impl.inject.internal.ComponentMethodsImpl;
/*     */ import org.apache.felix.scr.impl.logger.ComponentLogger;
/*     */ import org.apache.felix.scr.impl.logger.InternalLogger;
/*     */ import org.apache.felix.scr.impl.logger.ScrLogger;
/*     */ import org.apache.felix.scr.impl.manager.AbstractComponentManager;
/*     */ import org.apache.felix.scr.impl.manager.ComponentActivator;
/*     */ import org.apache.felix.scr.impl.manager.ComponentHolder;
/*     */ import org.apache.felix.scr.impl.manager.ConfigurableComponentHolder;
/*     */ import org.apache.felix.scr.impl.manager.DependencyManager;
/*     */ import org.apache.felix.scr.impl.manager.RegionConfigurationSupport;
/*     */ import org.apache.felix.scr.impl.manager.ScrConfiguration;
/*     */ import org.apache.felix.scr.impl.metadata.ComponentMetadata;
/*     */ import org.apache.felix.scr.impl.metadata.TargetedPID;
/*     */ import org.osgi.framework.Bundle;
/*     */ import org.osgi.framework.ServiceReference;
/*     */ import org.osgi.framework.ServiceRegistration;
/*     */ import org.osgi.service.cm.ConfigurationAdmin;
/*     */ import org.osgi.service.component.ComponentException;
/*     */ import org.osgi.service.component.runtime.ServiceComponentRuntime;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ComponentRegistry
/*     */ {
/*  71 */   private static String PROP_CHANGECOUNT = "service.changecount";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final Map<ComponentRegistryKey, ComponentHolder<?>> m_componentHoldersByName;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final Map<String, Set<ComponentHolder<?>>> m_componentHoldersByPid;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final Map<Long, AbstractComponentManager<?>> m_componentsById;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 125 */   private long m_componentCounter = -1L;
/*     */   
/* 127 */   private final Map<ServiceReference<?>, List<Entry<?, ?>>> m_missingDependencies = new HashMap<>();
/*     */ 
/*     */   
/*     */   private final ScrLogger m_logger;
/*     */ 
/*     */   
/*     */   private final ScrConfiguration m_configuration;
/*     */ 
/*     */   
/*     */   private final ThreadLocal<List<ServiceReference<?>>> circularInfos;
/*     */ 
/*     */   
/*     */   private final ConcurrentMap<Long, RegionConfigurationSupport> bundleToRcsMap;
/*     */ 
/*     */   
/*     */   private final AtomicLong changeCount;
/*     */ 
/*     */   
/*     */   private volatile Timer changeCountTimer;
/*     */ 
/*     */   
/*     */   private final Object changeCountTimerLock;
/*     */ 
/*     */   
/*     */   private volatile ServiceRegistration<ServiceComponentRuntime> registration;
/*     */ 
/*     */ 
/*     */   
/*     */   final long registerComponentId(AbstractComponentManager<?> componentManager) {
/*     */     long componentId;
/* 157 */     synchronized (this.m_componentsById) {
/*     */       
/* 159 */       componentId = ++this.m_componentCounter;
/*     */       
/* 161 */       this.m_componentsById.put(Long.valueOf(componentId), componentManager);
/*     */     } 
/*     */     
/* 164 */     return componentId;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final void unregisterComponentId(long componentId) {
/* 178 */     synchronized (this.m_componentsById) {
/*     */       
/* 180 */       this.m_componentsById.remove(Long.valueOf(componentId));
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final ComponentRegistryKey checkComponentName(Bundle bundle, String name) {
/*     */     boolean present;
/* 203 */     ComponentRegistryKey key = new ComponentRegistryKey(bundle, name);
/* 204 */     ComponentHolder<?> existingRegistration = null;
/*     */     
/* 206 */     synchronized (this.m_componentHoldersByName) {
/*     */       
/* 208 */       present = this.m_componentHoldersByName.containsKey(key);
/* 209 */       if (!present) {
/*     */         
/* 211 */         this.m_componentHoldersByName.put(key, null);
/*     */       }
/*     */       else {
/*     */         
/* 215 */         existingRegistration = this.m_componentHoldersByName.get(key);
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 221 */     if (present) {
/*     */       
/* 223 */       String message = "The component name '" + name + "' has already been registered";
/*     */       
/* 225 */       if (existingRegistration != null) {
/*     */         
/* 227 */         Bundle cBundle = existingRegistration.getActivator().getBundleContext().getBundle();
/* 228 */         ComponentMetadata cMeta = existingRegistration.getComponentMetadata();
/*     */         
/* 230 */         StringBuilder buf = new StringBuilder(message);
/* 231 */         buf.append(" by Bundle ").append(cBundle.getBundleId());
/* 232 */         if (cBundle.getSymbolicName() != null)
/*     */         {
/* 234 */           buf.append(" (").append(cBundle.getSymbolicName()).append(")");
/*     */         }
/* 236 */         buf.append(" as Component of Class ").append(cMeta.getImplementationClassName());
/* 237 */         message = buf.toString();
/*     */       } 
/*     */       
/* 240 */       throw new ComponentException(message);
/*     */     } 
/*     */     
/* 243 */     return key;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final void registerComponentHolder(ComponentRegistryKey key, ComponentHolder<?> componentHolder) {
/* 260 */     this.m_logger.log(InternalLogger.Level.DEBUG, "Registering component with pid {0} for bundle {1}", null, new Object[] { componentHolder
/*     */           
/* 262 */           .getComponentMetadata().getConfigurationPid(), Long.valueOf(key.getBundleId()) });
/* 263 */     synchronized (this.m_componentHoldersByName) {
/*     */ 
/*     */       
/* 266 */       if (this.m_componentHoldersByName.get(key) != null)
/*     */       {
/*     */         
/* 269 */         throw new ComponentException("The component name '{0}" + componentHolder.getComponentMetadata().getName() + "' has already been registered.");
/*     */       }
/*     */ 
/*     */       
/* 273 */       this.m_componentHoldersByName.put(key, componentHolder);
/*     */     } 
/*     */     
/* 276 */     synchronized (this.m_componentHoldersByPid) {
/*     */ 
/*     */       
/* 279 */       List<String> configurationPids = componentHolder.getComponentMetadata().getConfigurationPid();
/*     */       
/* 281 */       for (String configurationPid : configurationPids) {
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 286 */         Set<ComponentHolder<?>> set = this.m_componentHoldersByPid.get(configurationPid);
/* 287 */         if (set == null) {
/*     */           
/* 289 */           set = new HashSet<>();
/* 290 */           this.m_componentHoldersByPid.put(configurationPid, set);
/*     */         } 
/* 292 */         set.add(componentHolder);
/*     */       } 
/*     */     } 
/* 295 */     updateChangeCount();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ComponentHolder<?> getComponentHolder(Bundle bundle, String name) {
/* 304 */     synchronized (this.m_componentHoldersByName) {
/*     */       
/* 306 */       return this.m_componentHoldersByName.get(new ComponentRegistryKey(bundle, name));
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final Collection<ComponentHolder<?>> getComponentHoldersByPid(TargetedPID targetedPid) {
/* 318 */     String pid = targetedPid.getServicePid();
/* 319 */     Set<ComponentHolder<?>> componentHoldersUsingPid = new HashSet<>();
/* 320 */     synchronized (this.m_componentHoldersByPid) {
/*     */       
/* 322 */       Set<ComponentHolder<?>> set = this.m_componentHoldersByPid.get(pid);
/*     */       
/* 324 */       if (set != null)
/*     */       {
/* 326 */         for (ComponentHolder<?> holder : set) {
/*     */           
/* 328 */           Bundle bundle = holder.getActivator().getBundleContext().getBundle();
/* 329 */           if (targetedPid.matchesTarget(bundle))
/*     */           {
/* 331 */             componentHoldersUsingPid.add(holder);
/*     */           }
/*     */         } 
/*     */       }
/*     */     } 
/* 336 */     return componentHoldersUsingPid;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final List<ComponentHolder<?>> getComponentHolders() {
/* 347 */     List<ComponentHolder<?>> all = new ArrayList<>();
/* 348 */     synchronized (this.m_componentHoldersByName) {
/*     */       
/* 350 */       for (ComponentHolder<?> holder : this.m_componentHoldersByName.values()) {
/*     */ 
/*     */         
/* 353 */         if (holder != null)
/*     */         {
/* 355 */           all.add(holder);
/*     */         }
/*     */       } 
/*     */     } 
/* 359 */     return all;
/*     */   }
/*     */ 
/*     */   
/*     */   public final List<ComponentHolder<?>> getComponentHolders(Bundle... bundles) {
/* 364 */     List<ComponentHolder<?>> all = getComponentHolders();
/* 365 */     List<ComponentHolder<?>> holders = new ArrayList<>();
/* 366 */     for (ComponentHolder<?> holder : all) {
/*     */       
/* 368 */       ComponentActivator activator = holder.getActivator();
/* 369 */       if (activator != null) {
/*     */         
/*     */         try {
/*     */           
/* 373 */           Bundle holderBundle = activator.getBundleContext().getBundle();
/* 374 */           for (Bundle b : bundles)
/*     */           {
/* 376 */             if (b == holderBundle)
/*     */             {
/* 378 */               holders.add(holder);
/*     */             }
/*     */           }
/*     */         
/* 382 */         } catch (IllegalStateException illegalStateException) {}
/*     */       }
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 388 */     return holders;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final void unregisterComponentHolder(Bundle bundle, String name) {
/* 400 */     unregisterComponentHolder(new ComponentRegistryKey(bundle, name));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final void unregisterComponentHolder(ComponentRegistryKey key) {
/*     */     ComponentHolder<?> component;
/* 413 */     synchronized (this.m_componentHoldersByName) {
/*     */       
/* 415 */       component = this.m_componentHoldersByName.remove(key);
/*     */     } 
/*     */     
/* 418 */     if (component != null) {
/* 419 */       this.m_logger.log(InternalLogger.Level.DEBUG, "Unregistering component with pid {0} for bundle {1}", null, new Object[] { component
/*     */             
/* 421 */             .getComponentMetadata().getConfigurationPid(), Long.valueOf(key.getBundleId()) });
/* 422 */       synchronized (this.m_componentHoldersByPid) {
/*     */         
/* 424 */         List<String> configurationPids = component.getComponentMetadata().getConfigurationPid();
/* 425 */         for (String configurationPid : configurationPids) {
/*     */           
/* 427 */           Set<ComponentHolder<?>> componentsForPid = this.m_componentHoldersByPid.get(configurationPid);
/* 428 */           if (componentsForPid != null) {
/*     */             
/* 430 */             componentsForPid.remove(component);
/* 431 */             if (componentsForPid.size() == 0)
/*     */             {
/* 433 */               this.m_componentHoldersByPid.remove(configurationPid);
/*     */             }
/*     */           } 
/*     */         } 
/*     */       } 
/* 438 */       updateChangeCount();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <S> ComponentHolder<S> createComponentHolder(ComponentActivator activator, ComponentMetadata metadata, ComponentLogger logger) {
/* 450 */     return (ComponentHolder<S>)new DefaultConfigurableComponentHolder(activator, metadata, logger);
/*     */   }
/*     */   
/*     */   static class DefaultConfigurableComponentHolder<S>
/*     */     extends ConfigurableComponentHolder<S>
/*     */   {
/*     */     public DefaultConfigurableComponentHolder(ComponentActivator activator, ComponentMetadata metadata, ComponentLogger logger) {
/* 457 */       super(activator, metadata, logger);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     protected ComponentMethods<S> createComponentMethods() {
/* 463 */       return (ComponentMethods<S>)new ComponentMethodsImpl();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ComponentRegistry(ScrConfiguration scrConfiguration, ScrLogger logger) {
/* 472 */     this.circularInfos = new ThreadLocal<List<ServiceReference<?>>>()
/*     */       {
/*     */ 
/*     */         
/*     */         protected List<ServiceReference<?>> initialValue()
/*     */         {
/* 478 */           return new ArrayList<>();
/*     */         }
/*     */       };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 647 */     this.bundleToRcsMap = new ConcurrentHashMap<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 705 */     this.changeCount = new AtomicLong();
/*     */ 
/*     */ 
/*     */     
/* 709 */     this.changeCountTimerLock = new Object(); this.m_configuration = scrConfiguration; this.m_logger = logger; this.m_componentHoldersByName = new HashMap<>(); this.m_componentHoldersByPid = new HashMap<>(); this.m_componentsById = new HashMap<>();
/*     */   }
/*     */   public <T> boolean enterCreate(ServiceReference<T> serviceReference) { List<ServiceReference<?>> info = this.circularInfos.get(); if (info.contains(serviceReference)) { this.m_logger.log(InternalLogger.Level.ERROR, "Circular reference detected trying to get service {0}\n stack of references: {1}", new Exception("stack trace"), new Object[] { serviceReference, new Info(info) }); return true; }  this.m_logger.log(InternalLogger.Level.DEBUG, "getService  {0}: stack of references: {1}", null, new Object[] { serviceReference, info }); info.add(serviceReference); return false; }
/*     */   private class Info {
/*     */     private final List<ServiceReference<?>> info; public Info(List<ServiceReference<?>> info) { this.info = info; } public String toString() { StringBuilder sb = new StringBuilder(); for (ServiceReference<?> sr : this.info) { sb.append("ServiceReference: ").append(sr).append("\n"); List<ComponentRegistry.Entry<?, ?>> entries = (List<ComponentRegistry.Entry<?, ?>>)ComponentRegistry.this.m_missingDependencies.get(sr); if (entries != null) for (ComponentRegistry.Entry<?, ?> entry : entries) sb.append("    Dependency: ").append(entry.getDm()).append("\n");   }  return sb.toString(); }
/*     */   } public <T> void leaveCreate(ServiceReference<T> serviceReference) { List<ServiceReference<?>> info = this.circularInfos.get(); if (info != null) if (!info.isEmpty() && ((ServiceReference)info.iterator().next()).equals(serviceReference)) { this.circularInfos.remove(); } else { info.remove(serviceReference); }   } public synchronized <T> void missingServicePresent(final ServiceReference<T> serviceReference, ComponentActorThread actor) { final List<Entry<?, ?>> dependencyManagers = this.m_missingDependencies.remove(serviceReference); if (dependencyManagers != null) { Runnable runnable = new Runnable() { public void run() { for (ComponentRegistry.Entry<?, ?> entry : (Iterable<ComponentRegistry.Entry<?, ?>>)dependencyManagers) entry.getDm().invokeBindMethodLate(serviceReference, entry.getTrackingCount());  ComponentRegistry.this.m_logger.log(InternalLogger.Level.DEBUG, "Ran {0} asynchronously", null, new Object[] { this }); } public String toString() { return "Late binding task of reference " + serviceReference + " for dependencyManagers " + dependencyManagers; } }
/* 715 */         ; this.m_logger.log(InternalLogger.Level.DEBUG, "Scheduling runnable {0} asynchronously", null, new Object[] { runnable }); actor.schedule(runnable); }  } public Dictionary<String, Object> getServiceRegistrationProperties() { Dictionary<String, Object> props = new Hashtable<>();
/* 716 */     props.put(PROP_CHANGECOUNT, Long.valueOf(this.changeCount.get()));
/*     */     
/* 718 */     return props; }
/*     */   public synchronized <S, T> void registerMissingDependency(DependencyManager<S, T> dependencyManager, ServiceReference<T> serviceReference, int trackingCount) { if (serviceReference.getProperty("component.name") == null || serviceReference.getProperty("component.id") == null) { this.m_logger.log(InternalLogger.Level.DEBUG, "Missing service {0} for dependency manager {1} is not a DS service, cannot resolve circular dependency", null, new Object[] { serviceReference, dependencyManager }); return; }  List<Entry<?, ?>> dependencyManagers = this.m_missingDependencies.get(serviceReference); if (dependencyManagers == null) { dependencyManagers = new ArrayList<>(); this.m_missingDependencies.put(serviceReference, dependencyManagers); }  dependencyManagers.add(new Entry<>(dependencyManager, trackingCount)); this.m_logger.log(InternalLogger.Level.DEBUG, "Dependency managers {0} waiting for missing service {1}", null, new Object[] { dependencyManagers, serviceReference }); }
/*     */   private static class Entry<S, T> {
/*     */     private final DependencyManager<S, T> dm; private final int trackingCount; private Entry(DependencyManager<S, T> dm, int trackingCount) { this.dm = dm; this.trackingCount = trackingCount; } public DependencyManager<S, T> getDm() { return this.dm; } public int getTrackingCount() { return this.trackingCount; } public String toString() { return this.dm.toString() + "@" + this.trackingCount; }
/*     */   } public RegionConfigurationSupport registerRegionConfigurationSupport(ServiceReference<ConfigurationAdmin> reference) { Bundle bundle = reference.getBundle(); if (bundle == null) return null;  RegionConfigurationSupport trialRcs = new RegionConfigurationSupport(this.m_logger, reference, bundle) { protected Collection<ComponentHolder<?>> getComponentHolders(TargetedPID pid) { return ComponentRegistry.this.getComponentHoldersByPid(pid); } }
/* 723 */       ; return registerRegionConfigurationSupport(trialRcs); } public RegionConfigurationSupport registerRegionConfigurationSupport(RegionConfigurationSupport trialRcs) { Long bundleId = trialRcs.getBundleId(); RegionConfigurationSupport existing = null; RegionConfigurationSupport previous = null; while (true) { existing = this.bundleToRcsMap.putIfAbsent(bundleId, trialRcs); if (existing == null) { trialRcs.start(); return trialRcs; }  if (existing == previous) return existing;  if (existing.reference()) { previous = existing; continue; }  previous = null; }  } public void unregisterRegionConfigurationSupport(RegionConfigurationSupport rcs) { if (rcs.dereference()) this.bundleToRcsMap.remove(rcs.getBundleId());  } public void setRegistration(ServiceRegistration<ServiceComponentRuntime> reg) { this.registration = reg; }
/*     */ 
/*     */ 
/*     */   
/*     */   public void updateChangeCount() {
/* 728 */     if (this.registration != null) {
/*     */       Timer timer;
/* 730 */       final long count = this.changeCount.incrementAndGet();
/*     */ 
/*     */       
/* 733 */       synchronized (this.changeCountTimerLock) {
/* 734 */         if (this.changeCountTimer == null) {
/* 735 */           this.changeCountTimer = new Timer("SCR Component Registry", true);
/*     */         }
/* 737 */         timer = this.changeCountTimer;
/*     */       } 
/*     */       
/*     */       try {
/* 741 */         timer.schedule(new TimerTask()
/*     */             {
/*     */ 
/*     */               
/*     */               public void run()
/*     */               {
/* 747 */                 if (ComponentRegistry.this.changeCount.get() == count) {
/*     */ 
/*     */                   
/*     */                   try {
/* 751 */                     ComponentRegistry.this.registration.setProperties(ComponentRegistry.this.getServiceRegistrationProperties());
/*     */                   }
/* 753 */                   catch (IllegalStateException illegalStateException) {}
/*     */ 
/*     */ 
/*     */                   
/* 757 */                   synchronized (ComponentRegistry.this.changeCountTimerLock) {
/*     */                     
/* 759 */                     if (ComponentRegistry.this.changeCount.get() == count) {
/*     */                       
/* 761 */                       ComponentRegistry.this.changeCountTimer.cancel();
/* 762 */                       ComponentRegistry.this.changeCountTimer = null;
/*     */                     } 
/*     */                   } 
/*     */                 } 
/*     */               }
/*     */             }, 
/* 768 */             this.m_configuration.serviceChangecountTimeout());
/*     */       }
/* 770 */       catch (Exception e) {
/* 771 */         this.m_logger.log(InternalLogger.Level.WARN, "Service changecount Timer for {0} had a problem", e, new Object[] { this.registration
/*     */               
/* 773 */               .getReference() });
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   public void shutdown() {
/* 779 */     Timer timer = this.changeCountTimer;
/* 780 */     if (timer != null)
/* 781 */       timer.cancel(); 
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.apache.felix.scr-2.2.6.jar!\org\apache\felix\scr\impl\ComponentRegistry.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */