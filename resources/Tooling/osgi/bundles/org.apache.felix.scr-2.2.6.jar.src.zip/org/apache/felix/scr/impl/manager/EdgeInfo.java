/*     */ package org.apache.felix.scr.impl.manager;
/*     */ 
/*     */ import java.util.concurrent.CountDownLatch;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ import org.apache.felix.scr.impl.logger.InternalLogger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class EdgeInfo
/*     */ {
/*  51 */   private int open = -1;
/*  52 */   private int close = -1;
/*  53 */   private final CountDownLatch openLatch = new CountDownLatch(1);
/*  54 */   private final CountDownLatch closeLatch = new CountDownLatch(1);
/*     */ 
/*     */   
/*     */   public void setClose(int close) {
/*  58 */     this.close = close;
/*     */   }
/*     */ 
/*     */   
/*     */   public CountDownLatch getOpenLatch() {
/*  63 */     return this.openLatch;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void waitForOpen(AbstractComponentManager<?> m_componentManager, String componentName, String methodName) {
/*  69 */     CountDownLatch latch = getOpenLatch();
/*  70 */     String latchName = "open";
/*  71 */     waitForLatch(m_componentManager, latch, componentName, methodName, latchName);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void waitForClose(AbstractComponentManager<?> m_componentManager, String componentName, String methodName) {
/*  77 */     CountDownLatch latch = getCloseLatch();
/*  78 */     String latchName = "close";
/*  79 */     waitForLatch(m_componentManager, latch, componentName, methodName, latchName);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void waitForLatch(AbstractComponentManager<?> m_componentManager, CountDownLatch latch, String componentName, String methodName, String latchName) {
/*     */     try {
/*  87 */       if (!latch.await(m_componentManager.getLockTimeout(), TimeUnit.MILLISECONDS))
/*     */       {
/*  89 */         m_componentManager.getLogger().log(InternalLogger.Level.ERROR, "DependencyManager : {0} : timeout on {1} latch {2}", null, new Object[] { methodName, latchName, componentName });
/*     */         
/*  91 */         m_componentManager.dumpThreads();
/*     */       }
/*     */     
/*  94 */     } catch (InterruptedException e) {
/*     */ 
/*     */       
/*     */       try {
/*  98 */         if (!latch.await(m_componentManager.getLockTimeout(), TimeUnit.MILLISECONDS))
/*     */         {
/* 100 */           m_componentManager.getLogger().log(InternalLogger.Level.ERROR, "DependencyManager : {0} : timeout on {1} latch {2}", null, new Object[] { methodName, latchName, componentName });
/*     */           
/* 102 */           m_componentManager.dumpThreads();
/*     */         }
/*     */       
/* 105 */       } catch (InterruptedException e1) {
/*     */         
/* 107 */         m_componentManager.getLogger().log(InternalLogger.Level.ERROR, "DependencyManager : {0} : Interrupted twice on {1} latch {2}", null, new Object[] { methodName, latchName, componentName });
/*     */ 
/*     */         
/* 110 */         Thread.currentThread().interrupt();
/*     */       } 
/* 112 */       Thread.currentThread().interrupt();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public CountDownLatch getCloseLatch() {
/* 118 */     return this.closeLatch;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setOpen(int open) {
/* 123 */     this.open = open;
/*     */   }
/*     */ 
/*     */   
/*     */   public void ignore() {
/* 128 */     this.open = Integer.MAX_VALUE;
/* 129 */     this.close = 2147483646;
/* 130 */     this.openLatch.countDown();
/* 131 */     this.closeLatch.countDown();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean outOfRange(int trackingCount) {
/* 145 */     return (this.open == -1 || trackingCount < this.open || (this.close != -1 && trackingCount > this.close));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean beforeRange(int trackingCount) {
/* 152 */     return (this.open == -1 || trackingCount < this.open);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean afterRange(int trackingCount) {
/* 157 */     return (this.close != -1 && trackingCount > this.close);
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.apache.felix.scr-2.2.6.jar!\org\apache\felix\scr\impl\manager\EdgeInfo.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */