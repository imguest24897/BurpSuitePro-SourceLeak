/*     */ package org.apache.felix.scr.impl.metadata;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.StringTokenizer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PropertyMetadata
/*     */ {
/*     */   private final boolean m_referenceTarget;
/*     */   private String m_name;
/*     */   private String m_type;
/*     */   private Object m_value;
/*     */   private boolean m_validated = false;
/*     */   
/*     */   public PropertyMetadata() {
/*  50 */     this(false);
/*     */   }
/*     */ 
/*     */   
/*     */   public PropertyMetadata(boolean referenceTarget) {
/*  55 */     this.m_referenceTarget = referenceTarget;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setName(String name) {
/*  64 */     if (this.m_validated == true) {
/*     */       return;
/*     */     }
/*     */     
/*  68 */     this.m_name = name;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setType(String type) {
/*  78 */     if (this.m_validated == true) {
/*     */       return;
/*     */     }
/*  81 */     this.m_type = type;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setValue(String value) {
/*  90 */     if (this.m_validated == true) {
/*     */       return;
/*     */     }
/*  93 */     this.m_value = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setValues(String values) {
/* 103 */     if (this.m_validated == true) {
/*     */       return;
/*     */     }
/*     */     
/* 107 */     List<String> valueList = new ArrayList<>();
/* 108 */     StringTokenizer tokener = new StringTokenizer(values, "\r\n");
/* 109 */     while (tokener.hasMoreTokens()) {
/* 110 */       String value = tokener.nextToken().trim();
/* 111 */       if (value.length() > 0) {
/* 112 */         valueList.add(value);
/*     */       }
/*     */     } 
/* 115 */     this.m_value = valueList.toArray(new String[valueList.size()]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getName() {
/* 124 */     return this.m_name;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getType() {
/* 133 */     return this.m_type;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object getValue() {
/* 142 */     return this.m_value;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isReferenceTarget() {
/* 147 */     return this.m_referenceTarget;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void validate(ComponentMetadata componentMetadata) {
/* 154 */     if (this.m_name == null)
/*     */     {
/* 156 */       throw componentMetadata.validationFailure("Property name attribute is mandatory");
/*     */     }
/*     */ 
/*     */     
/* 160 */     if (this.m_type == null) {
/*     */       
/* 162 */       this.m_type = "String";
/*     */     } else {
/* 164 */       if (componentMetadata.getDSVersion().isDS11() && this.m_type.equals("Char"))
/*     */       {
/* 166 */         throw componentMetadata
/* 167 */           .validationFailure("Illegal property type 'Char' used for DS 1.1 descriptor, use 'Character' instead");
/*     */       }
/* 169 */       if (!componentMetadata.getDSVersion().isDS11() && this.m_type.equals("Character"))
/*     */       {
/* 171 */         throw componentMetadata
/* 172 */           .validationFailure("Illegal property type 'Character' used for DS 1.0 descriptor, use 'Char' instead");
/*     */       }
/*     */     } 
/*     */     
/* 176 */     if (this.m_value != null) {
/*     */       
/*     */       try {
/*     */         
/* 180 */         if (this.m_value instanceof String)
/*     */         {
/* 182 */           this.m_value = toType((String)this.m_value);
/*     */         }
/*     */         else
/*     */         {
/* 186 */           this.m_value = toTypeArray((String[])this.m_value);
/*     */         }
/*     */       
/* 189 */       } catch (NumberFormatException nfe) {
/*     */         
/* 191 */         throw componentMetadata.validationFailure(getName() + ": Cannot convert property value to " + 
/* 192 */             getType());
/*     */       }
/* 194 */       catch (IllegalArgumentException e) {
/*     */         
/* 196 */         throw componentMetadata.validationFailure(getName() + ": " + e.getMessage());
/*     */       } 
/*     */     }
/*     */     
/* 200 */     this.m_validated = true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Object toType(String value) {
/* 214 */     if (this.m_type.equals("String"))
/*     */     {
/* 216 */       return value;
/*     */     }
/* 218 */     if (this.m_type.equals("Long"))
/*     */     {
/* 220 */       return Long.valueOf(value);
/*     */     }
/* 222 */     if (this.m_type.equals("Double"))
/*     */     {
/* 224 */       return Double.valueOf(value);
/*     */     }
/* 226 */     if (this.m_type.equals("Float"))
/*     */     {
/* 228 */       return Float.valueOf(value);
/*     */     }
/* 230 */     if (this.m_type.equals("Integer"))
/*     */     {
/* 232 */       return Integer.valueOf(value);
/*     */     }
/* 234 */     if (this.m_type.equals("Byte"))
/*     */     {
/* 236 */       return Byte.valueOf(value);
/*     */     }
/* 238 */     if (this.m_type.equals("Char") || this.m_type.equals("Character"))
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 244 */       return Character.valueOf((char)Integer.parseInt(value));
/*     */     }
/* 246 */     if (this.m_type.equals("Boolean"))
/*     */     {
/* 248 */       return Boolean.valueOf(value);
/*     */     }
/* 250 */     if (this.m_type.equals("Short"))
/*     */     {
/* 252 */       return Short.valueOf(value);
/*     */     }
/*     */ 
/*     */     
/* 256 */     throw new IllegalArgumentException("Undefined property type '" + this.m_type + "'");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Object toTypeArray(String[] valueList) {
/* 270 */     if (this.m_type.equals("String"))
/*     */     {
/* 272 */       return valueList;
/*     */     }
/* 274 */     if (this.m_type.equals("Double")) {
/*     */       
/* 276 */       double[] array = new double[valueList.length];
/* 277 */       for (int i = 0; i < array.length; i++)
/*     */       {
/* 279 */         array[i] = Double.parseDouble(valueList[i]);
/*     */       }
/* 281 */       return array;
/*     */     } 
/* 283 */     if (this.m_type.equals("Float")) {
/*     */       
/* 285 */       float[] array = new float[valueList.length];
/* 286 */       for (int i = 0; i < array.length; i++)
/*     */       {
/* 288 */         array[i] = Float.parseFloat(valueList[i]);
/*     */       }
/* 290 */       return array;
/*     */     } 
/* 292 */     if (this.m_type.equals("Long")) {
/*     */       
/* 294 */       long[] array = new long[valueList.length];
/* 295 */       for (int i = 0; i < array.length; i++)
/*     */       {
/* 297 */         array[i] = Long.parseLong(valueList[i]);
/*     */       }
/* 299 */       return array;
/*     */     } 
/* 301 */     if (this.m_type.equals("Integer")) {
/*     */       
/* 303 */       int[] array = new int[valueList.length];
/* 304 */       for (int i = 0; i < array.length; i++)
/*     */       {
/* 306 */         array[i] = Integer.parseInt(valueList[i]);
/*     */       }
/* 308 */       return array;
/*     */     } 
/* 310 */     if (this.m_type.equals("Short")) {
/*     */       
/* 312 */       short[] array = new short[valueList.length];
/* 313 */       for (int i = 0; i < array.length; i++)
/*     */       {
/* 315 */         array[i] = Short.parseShort(valueList[i]);
/*     */       }
/* 317 */       return array;
/*     */     } 
/* 319 */     if (this.m_type.equals("Byte")) {
/*     */       
/* 321 */       byte[] array = new byte[valueList.length];
/* 322 */       for (int i = 0; i < array.length; i++)
/*     */       {
/* 324 */         array[i] = Byte.parseByte(valueList[i]);
/*     */       }
/* 326 */       return array;
/*     */     } 
/* 328 */     if (this.m_type.equals("Char") || this.m_type.equals("Character")) {
/*     */ 
/*     */       
/* 331 */       char[] array = new char[valueList.length];
/* 332 */       for (int i = 0; i < array.length; i++)
/*     */       {
/* 334 */         array[i] = (char)Integer.parseInt(valueList[i]);
/*     */       }
/* 336 */       return array;
/*     */     } 
/* 338 */     if (this.m_type.equals("Boolean")) {
/*     */       
/* 340 */       boolean[] array = new boolean[valueList.length];
/* 341 */       for (int i = 0; i < array.length; i++)
/*     */       {
/* 343 */         array[i] = Boolean.valueOf(valueList[i]).booleanValue();
/*     */       }
/* 345 */       return array;
/*     */     } 
/*     */ 
/*     */     
/* 349 */     throw new IllegalArgumentException("Undefined property type '" + this.m_type + "'");
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.apache.felix.scr-2.2.6.jar!\org\apache\felix\scr\impl\metadata\PropertyMetadata.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */