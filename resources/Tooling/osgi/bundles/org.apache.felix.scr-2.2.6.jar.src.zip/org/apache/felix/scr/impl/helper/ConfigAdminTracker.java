/*    */ package org.apache.felix.scr.impl.helper;
/*    */ 
/*    */ import org.apache.felix.scr.impl.logger.InternalLogger;
/*    */ import org.apache.felix.scr.impl.manager.ComponentActivator;
/*    */ import org.apache.felix.scr.impl.manager.RegionConfigurationSupport;
/*    */ import org.osgi.framework.ServiceReference;
/*    */ import org.osgi.service.cm.ConfigurationAdmin;
/*    */ import org.osgi.util.tracker.ServiceTracker;
/*    */ import org.osgi.util.tracker.ServiceTrackerCustomizer;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ConfigAdminTracker
/*    */ {
/*    */   public static final String CONFIGURATION_ADMIN = "org.osgi.service.cm.ConfigurationAdmin";
/*    */   private final ServiceTracker<ConfigurationAdmin, RegionConfigurationSupport> configAdminTracker;
/*    */   
/*    */   public ConfigAdminTracker(final ComponentActivator componentActivator) {
/* 38 */     this
/* 39 */       .configAdminTracker = new ServiceTracker(componentActivator.getBundleContext(), "org.osgi.service.cm.ConfigurationAdmin", new ServiceTrackerCustomizer<ConfigurationAdmin, RegionConfigurationSupport>()
/*    */         {
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */           
/*    */           public RegionConfigurationSupport addingService(ServiceReference<ConfigurationAdmin> reference)
/*    */           {
/* 48 */             boolean visible = false;
/*    */             
/*    */             try {
/* 51 */               ConfigurationAdmin ca = (ConfigurationAdmin)componentActivator.getBundleContext().getService(reference);
/* 52 */               if (ca != null)
/*    */               {
/* 54 */                 visible = true;
/* 55 */                 componentActivator.getBundleContext().ungetService(reference);
/*    */               }
/*    */             
/* 58 */             } catch (Exception ex) {
/*    */               
/* 60 */               componentActivator.getLogger().log(InternalLogger.Level.ERROR, "Configuration admin API visible to bundle " + componentActivator
/* 61 */                   .getBundleContext().getBundle() + " is not the same as the Configuration Admin API visible to the SCR implementation.", ex);
/*    */             } 
/*    */ 
/*    */             
/* 65 */             if (!visible)
/*    */             {
/* 67 */               return null;
/*    */             }
/* 69 */             return componentActivator.setRegionConfigurationSupport(reference);
/*    */           }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */           
/*    */           public void modifiedService(ServiceReference<ConfigurationAdmin> reference, RegionConfigurationSupport service) {}
/*    */ 
/*    */ 
/*    */ 
/*    */           
/*    */           public void removedService(ServiceReference<ConfigurationAdmin> reference, RegionConfigurationSupport rcs) {
/* 82 */             componentActivator.unsetRegionConfigurationSupport(rcs);
/*    */           }
/*    */         });
/*    */     
/* 86 */     this.configAdminTracker.open();
/*    */   }
/*    */ 
/*    */   
/*    */   public void dispose() {
/* 91 */     this.configAdminTracker.close();
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.apache.felix.scr-2.2.6.jar!\org\apache\felix\scr\impl\helper\ConfigAdminTracker.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */