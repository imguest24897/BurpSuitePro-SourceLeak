/*     */ package org.apache.felix.scr.impl.xml;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import org.apache.felix.scr.impl.metadata.DSVersion;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class XmlConstants
/*     */ {
/*     */   public static final String NAMESPACE_URI_EMPTY = "";
/*     */   public static final String NAMESPACE_URI = "http://www.osgi.org/xmlns/scr/v1.0.0";
/*     */   public static final String NAMESPACE_URI_1_1 = "http://www.osgi.org/xmlns/scr/v1.1.0";
/*     */   public static final String NAMESPACE_URI_1_1_FELIX = "http://felix.apache.org/xmlns/scr/v1.1.0-felix";
/*     */   public static final String NAMESPACE_URI_1_2 = "http://www.osgi.org/xmlns/scr/v1.2.0";
/*     */   public static final String NAMESPACE_URI_1_2_FELIX = "http://felix.apache.org/xmlns/scr/v1.2.0-felix";
/*     */   public static final String NAMESPACE_URI_1_3 = "http://www.osgi.org/xmlns/scr/v1.3.0";
/*     */   public static final String NAMESPACE_URI_1_0_FELIX_EXTENSIONS = "http://felix.apache.org/xmlns/scr/extensions/v1.0.0";
/*     */   public static final String NAMESPACE_URI_1_4 = "http://www.osgi.org/xmlns/scr/v1.4.0";
/*     */   public static final String NAMESPACE_URI_1_5 = "http://www.osgi.org/xmlns/scr/v1.5.0";
/*     */   public static final String EL_COMPONENT = "component";
/*     */   public static final String EL_COMPONENTS = "components";
/*     */   public static final String EL_FACTORY_PROPERTY = "factory-property";
/*     */   public static final String EL_FACTORY_PROPERTIES = "factory-properties";
/*     */   public static final String EL_IMPL = "implementation";
/*     */   public static final String EL_PROPERTY = "property";
/*     */   public static final String EL_PROPERTIES = "properties";
/*     */   public static final String EL_PROVIDE = "provide";
/*     */   public static final String EL_REF = "reference";
/*     */   public static final String EL_SERVICE = "service";
/*     */   public static final String ATTR_ACTIVATE = "activate";
/*     */   public static final String ATTR_ACTIVATION_FIELDS = "activation-fields";
/*     */   public static final String ATTR_CLASS = "class";
/*     */   public static final String ATTR_CONFIG_PID = "configuration-pid";
/*     */   public static final String ATTR_CONFIG_POLICY = "configuration-policy";
/*     */   public static final String ATTR_DEACTIVATE = "deactivate";
/*     */   public static final String ATTR_ENABLED = "enabled";
/*     */   public static final String ATTR_ENTRY = "entry";
/*     */   public static final String ATTR_FACTORY = "factory";
/*     */   public static final String ATTR_IMMEDIATE = "immediate";
/*     */   public static final String ATTR_INIT = "init";
/*     */   public static final String ATTR_INTERFACE = "interface";
/*     */   public static final String ATTR_MODIFIED = "modified";
/*     */   public static final String ATTR_NAME = "name";
/*     */   public static final String ATTR_TYPE = "type";
/*     */   public static final String ATTR_VALUE = "value";
/*     */   public static final String ATTR_CONFIGURABLE_SERVICE_PROPERTIES = "configurableServiceProperties";
/*     */   public static final String ATTR_PERSISTENT_FACTORY_COMPONENT = "persistentFactoryComponent";
/*     */   public static final String ATTR_DELETE_CALLS_MODIFY = "deleteCallsModify";
/*     */   public static final String ATTR_OBSOLETE_FACTORY_COMPONENT_FACTORY = "obsoleteFactoryComponentFactory";
/*     */   public static final String ATTR_CONFIGURE_WITH_INTERFACES = "configureWithInterfaces";
/*     */   public static final String ATTR_DELAYED_KEEP_INSTANCES = "delayedKeepInstances";
/* 110 */   public static final Map<String, DSVersion> NAMESPACE_CODE_MAP = new HashMap<>(); static {
/* 111 */     NAMESPACE_CODE_MAP.put("", DSVersion.DS10);
/* 112 */     NAMESPACE_CODE_MAP.put("http://www.osgi.org/xmlns/scr/v1.0.0", DSVersion.DS10);
/* 113 */     NAMESPACE_CODE_MAP.put("http://www.osgi.org/xmlns/scr/v1.1.0", DSVersion.DS11);
/* 114 */     NAMESPACE_CODE_MAP.put("http://felix.apache.org/xmlns/scr/v1.1.0-felix", DSVersion.DS11Felix);
/* 115 */     NAMESPACE_CODE_MAP.put("http://www.osgi.org/xmlns/scr/v1.2.0", DSVersion.DS12);
/* 116 */     NAMESPACE_CODE_MAP.put("http://felix.apache.org/xmlns/scr/v1.2.0-felix", DSVersion.DS12Felix);
/* 117 */     NAMESPACE_CODE_MAP.put("http://www.osgi.org/xmlns/scr/v1.3.0", DSVersion.DS13);
/* 118 */     NAMESPACE_CODE_MAP.put("http://www.osgi.org/xmlns/scr/v1.4.0", DSVersion.DS14);
/* 119 */     NAMESPACE_CODE_MAP.put("http://www.osgi.org/xmlns/scr/v1.5.0", DSVersion.DS15);
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.apache.felix.scr-2.2.6.jar!\org\apache\felix\scr\impl\xml\XmlConstants.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */