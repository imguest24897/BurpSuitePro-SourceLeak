/*    */ package org.apache.felix.scr.impl.inject;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface ReferenceMethods
/*    */ {
/* 61 */   public static final ReferenceMethods NOPReferenceMethod = new ReferenceMethods()
/*    */     {
/*    */       public ReferenceMethod getBind()
/*    */       {
/* 65 */         return ReferenceMethod.NOPReferenceMethod;
/*    */       }
/*    */ 
/*    */       
/*    */       public ReferenceMethod getUnbind() {
/* 70 */         return ReferenceMethod.NOPReferenceMethod;
/*    */       }
/*    */ 
/*    */       
/*    */       public ReferenceMethod getUpdated() {
/* 75 */         return ReferenceMethod.NOPReferenceMethod;
/*    */       }
/*    */ 
/*    */       
/*    */       public InitReferenceMethod getInit() {
/* 80 */         return null;
/*    */       }
/*    */     };
/*    */   
/*    */   ReferenceMethod getBind();
/*    */   
/*    */   ReferenceMethod getUnbind();
/*    */   
/*    */   ReferenceMethod getUpdated();
/*    */   
/*    */   InitReferenceMethod getInit();
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.apache.felix.scr-2.2.6.jar!\org\apache\felix\scr\impl\inject\ReferenceMethods.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */