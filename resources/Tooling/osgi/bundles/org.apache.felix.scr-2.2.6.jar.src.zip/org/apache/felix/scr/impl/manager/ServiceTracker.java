/*      */ package org.apache.felix.scr.impl.manager;
/*      */ 
/*      */ import java.lang.reflect.Array;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Collections;
/*      */ import java.util.HashMap;
/*      */ import java.util.LinkedList;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.SortedMap;
/*      */ import java.util.TreeMap;
/*      */ import java.util.concurrent.atomic.AtomicInteger;
/*      */ import org.osgi.framework.BundleContext;
/*      */ import org.osgi.framework.InvalidSyntaxException;
/*      */ import org.osgi.framework.ServiceEvent;
/*      */ import org.osgi.framework.ServiceReference;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class ServiceTracker<S, T, U extends ServiceEvent>
/*      */ {
/*      */   static final boolean DEBUG = false;
/*      */   protected final BundleContext context;
/*      */   final ServiceTrackerCustomizer<S, T, U> customizer;
/*      */   final String initialReferenceFilterString;
/*      */   private volatile Tracked tracked;
/*      */   private boolean active;
/*      */   private final ServiceReference<S> trackReference;
/*      */   private ExtendedServiceListenerContext<U> extendedServiceListenerContext;
/*      */   
/*      */   public Tracked tracked() {
/*  115 */     return this.tracked;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ServiceTracker(BundleContext context, ServiceTrackerCustomizer<S, T, U> customizer, boolean initialActive, ExtendedServiceListenerContext<U> bundleComponentActivator, String initialReferenceFilterString, ServiceReference<S> initialReference) {
/*  145 */     if (context == null)
/*      */     {
/*      */ 
/*      */       
/*  149 */       throw new NullPointerException("BundleContext");
/*      */     }
/*  151 */     this.context = context;
/*  152 */     this.trackReference = initialReference;
/*  153 */     this.initialReferenceFilterString = initialReferenceFilterString;
/*  154 */     this.customizer = customizer;
/*  155 */     this.active = initialActive;
/*  156 */     this.extendedServiceListenerContext = bundleComponentActivator;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void open(AtomicInteger trackingCount) {
/*  171 */     open(false, trackingCount);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void open(boolean trackAllServices, AtomicInteger trackingCount) {
/*      */     Tracked t;
/*  196 */     synchronized (this) {
/*  197 */       if (this.tracked != null) {
/*      */         return;
/*      */       }
/*      */ 
/*      */ 
/*      */       
/*  203 */       t = new Tracked(trackingCount);
/*  204 */       synchronized (t) {
/*      */         try {
/*  206 */           ServiceReference[] arrayOfServiceReference; this.extendedServiceListenerContext.addServiceListener(this.initialReferenceFilterString, t);
/*  207 */           ServiceReference<S>[] references = null;
/*  208 */           if (this.trackReference != null) {
/*      */             
/*  210 */             if (this.trackReference.getBundle() != null)
/*      */             {
/*      */               
/*  213 */               ServiceReference[] arrayOfServiceReference1 = { this.trackReference };
/*      */               
/*  215 */               arrayOfServiceReference = arrayOfServiceReference1;
/*      */             }
/*      */           
/*      */           } else {
/*      */             
/*  220 */             arrayOfServiceReference = (ServiceReference[])getInitialReferences(null, this.initialReferenceFilterString);
/*      */           } 
/*      */ 
/*      */           
/*  224 */           t.setInitial((ServiceReference<S>[])arrayOfServiceReference);
/*  225 */         } catch (InvalidSyntaxException e) {
/*  226 */           throw new RuntimeException("unexpected InvalidSyntaxException: " + e.getMessage(), e);
/*      */         } 
/*      */       } 
/*  229 */       this.tracked = t;
/*      */     } 
/*      */     
/*  232 */     t.trackInitial();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private ServiceReference<S>[] getInitialReferences(String className, String filterString) throws InvalidSyntaxException {
/*  248 */     return (ServiceReference<S>[])this.context.getServiceReferences(className, filterString);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public SortedMap<ServiceReference<S>, T> close(AtomicInteger trackingCount) {
/*      */     Tracked outgoing;
/*  268 */     SortedMap<ServiceReference<S>, T> map = new TreeMap<>(Collections.reverseOrder());
/*  269 */     synchronized (this) {
/*  270 */       outgoing = this.tracked;
/*  271 */       if (outgoing == null) {
/*  272 */         return map;
/*      */       }
/*      */ 
/*      */ 
/*      */       
/*  277 */       outgoing.close();
/*  278 */       synchronized (outgoing) {
/*      */         
/*  280 */         trackingCount.set(outgoing.getTrackingCount());
/*  281 */         outgoing.copyEntries(map);
/*      */       } 
/*      */ 
/*      */       
/*      */       try {
/*  286 */         this.extendedServiceListenerContext.removeServiceListener(this.initialReferenceFilterString, outgoing);
/*  287 */       } catch (IllegalStateException illegalStateException) {}
/*      */     } 
/*      */ 
/*      */     
/*  291 */     modified();
/*  292 */     synchronized (outgoing) {
/*  293 */       outgoing.notifyAll();
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  303 */     return map;
/*      */   }
/*      */   
/*      */   public void completeClose(Map<ServiceReference<S>, T> toUntrack) {
/*      */     Tracked outgoing;
/*  308 */     synchronized (this) {
/*  309 */       outgoing = this.tracked;
/*  310 */       if (outgoing == null) {
/*      */         return;
/*      */       }
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  317 */     for (ServiceReference<S> ref : toUntrack.keySet()) {
/*  318 */       outgoing.untrack(ref, null);
/*      */     }
/*  320 */     this.tracked = null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T addingService(ServiceReference<S> reference, int trackingCount) {
/*  351 */     T result = (T)this.context.getService(reference);
/*  352 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void modifiedService(ServiceReference<S> reference, T service, int trackingCount) {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void removedService(ServiceReference<S> reference, T service, int trackingCount) {
/*  396 */     this.context.ungetService(reference);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ServiceReference<S>[] getServiceReferences() {
/*  407 */     Tracked t = tracked();
/*  408 */     if (t == null) {
/*  409 */       return null;
/*      */     }
/*  411 */     synchronized (t) {
/*  412 */       int length = t.size();
/*  413 */       if (length == 0) {
/*  414 */         return null;
/*      */       }
/*      */       
/*  417 */       ServiceReference[] arrayOfServiceReference = new ServiceReference[length];
/*  418 */       return t.copyKeys((ServiceReference<S>[])arrayOfServiceReference);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T getService(ServiceReference<S> reference) {
/*  433 */     Tracked t = tracked();
/*  434 */     if (t == null) {
/*  435 */       return null;
/*      */     }
/*  437 */     synchronized (t) {
/*  438 */       return t.getCustomizedObject(reference);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object[] getServices() {
/*  456 */     Tracked t = tracked();
/*  457 */     if (t == null) {
/*  458 */       return null;
/*      */     }
/*  460 */     synchronized (t) {
/*  461 */       ServiceReference[] arrayOfServiceReference = (ServiceReference[])getServiceReferences();
/*  462 */       int length = (arrayOfServiceReference == null) ? 0 : arrayOfServiceReference.length;
/*  463 */       if (length == 0) {
/*  464 */         return null;
/*      */       }
/*  466 */       Object[] objects = new Object[length];
/*  467 */       for (int i = 0; i < length; i++) {
/*  468 */         objects[i] = getService(arrayOfServiceReference[i]);
/*      */       }
/*  470 */       return objects;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void remove(ServiceReference<S> reference) {
/*  486 */     Tracked t = tracked();
/*  487 */     if (t == null) {
/*      */       return;
/*      */     }
/*  490 */     t.untrack(reference, null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int size() {
/*  500 */     Tracked t = tracked();
/*  501 */     if (t == null) {
/*  502 */       return 0;
/*      */     }
/*  504 */     synchronized (t) {
/*  505 */       return t.size();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getTrackingCount() {
/*  529 */     Tracked t = tracked();
/*  530 */     if (t == null) {
/*  531 */       return -1;
/*      */     }
/*  533 */     synchronized (t) {
/*  534 */       return t.getTrackingCount();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void modified() {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public SortedMap<ServiceReference<S>, T> getTracked(Boolean activate, AtomicInteger trackingCount) {
/*  569 */     SortedMap<ServiceReference<S>, T> map = new TreeMap<>(Collections.reverseOrder());
/*  570 */     Tracked t = tracked();
/*  571 */     if (t == null) {
/*  572 */       return map;
/*      */     }
/*  574 */     synchronized (t) {
/*  575 */       if (activate != null)
/*      */       {
/*  577 */         this.active = activate.booleanValue();
/*      */       }
/*  579 */       trackingCount.set(t.getTrackingCount());
/*  580 */       return (SortedMap<ServiceReference<S>, T>)t.copyEntries(map);
/*      */     } 
/*      */   }
/*      */   
/*      */   void deactivate() {
/*  585 */     Tracked t = tracked();
/*  586 */     if (t == null) {
/*      */       return;
/*      */     }
/*  589 */     synchronized (t) {
/*  590 */       this.active = false;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isEmpty() {
/*  602 */     Tracked t = tracked();
/*  603 */     if (t == null) {
/*  604 */       return true;
/*      */     }
/*  606 */     synchronized (t) {
/*  607 */       return t.isEmpty();
/*      */     } 
/*      */   }
/*      */   
/*      */   public int getServiceCount() {
/*  612 */     Tracked t = tracked();
/*  613 */     if (t == null) {
/*  614 */       return 0;
/*      */     }
/*  616 */     synchronized (t) {
/*  617 */       return t.size();
/*      */     } 
/*      */   }
/*      */   
/*      */   public boolean isActive() {
/*  622 */     Tracked t = tracked();
/*  623 */     if (t == null) {
/*  624 */       return false;
/*      */     }
/*  626 */     synchronized (t) {
/*  627 */       return this.active;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T[] getServices(T[] array) {
/*  656 */     Tracked t = tracked();
/*  657 */     if (t == null) {
/*  658 */       if (array.length > 0) {
/*  659 */         array[0] = null;
/*      */       }
/*  661 */       return array;
/*      */     } 
/*  663 */     synchronized (t) {
/*  664 */       ServiceReference[] arrayOfServiceReference = (ServiceReference[])getServiceReferences();
/*  665 */       int length = (arrayOfServiceReference == null) ? 0 : arrayOfServiceReference.length;
/*  666 */       if (length == 0) {
/*  667 */         if (array.length > 0) {
/*  668 */           array[0] = null;
/*      */         }
/*  670 */         return array;
/*      */       } 
/*  672 */       if (length > array.length) {
/*  673 */         array = (T[])Array.newInstance(array.getClass().getComponentType(), length);
/*      */       }
/*  675 */       for (int i = 0; i < length; i++) {
/*  676 */         array[i] = getService(arrayOfServiceReference[i]);
/*      */       }
/*  678 */       if (array.length > length) {
/*  679 */         array[length] = null;
/*      */       }
/*  681 */       return array;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static abstract class AbstractTracked<S, T, R>
/*      */   {
/*      */     static final boolean DEBUG = false;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private final Map<S, T> tracked;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private final AtomicInteger trackingCount;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private final List<S> adding;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     volatile boolean closed;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private final LinkedList<S> initial;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     AbstractTracked(AtomicInteger trackingCount) {
/*  768 */       this.tracked = new HashMap<>();
/*  769 */       this.trackingCount = trackingCount;
/*  770 */       this.adding = new ArrayList<>(6);
/*  771 */       this.initial = new LinkedList<>();
/*  772 */       this.closed = false;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     void setInitial(S[] list) {
/*  787 */       if (list == null) {
/*      */         return;
/*      */       }
/*  790 */       for (S item : list) {
/*  791 */         if (item != null)
/*      */         {
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  797 */           this.initial.add(item);
/*      */         }
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     void trackInitial() {
/*      */       while (true) {
/*      */         S item;
/*  812 */         synchronized (this) {
/*  813 */           if (this.closed || this.initial.size() == 0) {
/*      */             return;
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  823 */           item = this.initial.removeFirst();
/*  824 */           if (this.tracked.get(item) != null) {
/*      */             continue;
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  831 */           if (this.adding.contains(item)) {
/*      */             continue;
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  840 */           this.adding.add(item);
/*      */         } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  850 */         trackAdding(item, null);
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     void close() {
/*  858 */       this.closed = true;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     void track(S item, R related) {
/*      */       boolean tracking;
/*      */       T object;
/*  870 */       int trackingCount = -1;
/*  871 */       synchronized (this) {
/*  872 */         if (this.closed) {
/*      */           return;
/*      */         }
/*  875 */         tracking = this.tracked.containsKey(item);
/*  876 */         object = this.tracked.get(item);
/*  877 */         if (!tracking) {
/*  878 */           if (this.adding.contains(item)) {
/*      */             return;
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  885 */           this.adding.add(item);
/*      */         
/*      */         }
/*      */         else {
/*      */           
/*  890 */           trackingCount = modified();
/*      */         } 
/*      */       } 
/*      */       
/*  894 */       if (!tracking) {
/*  895 */         trackAdding(item, related);
/*      */       } else {
/*      */         
/*  898 */         customizerModified(item, related, object, trackingCount);
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private void trackAdding(S item, R related) {
/*  918 */       T object = null;
/*  919 */       boolean becameUntracked = false;
/*  920 */       int trackingCount = -1;
/*  921 */       int serviceCount = -1;
/*      */       
/*      */       try {
/*  924 */         object = customizerAdding(item, related);
/*      */       
/*      */       }
/*      */       finally {
/*      */ 
/*      */         
/*  930 */         synchronized (this) {
/*  931 */           if (this.adding.remove(item) && !this.closed) {
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*  936 */             this.tracked.put(item, object);
/*  937 */             trackingCount = modified();
/*  938 */             serviceCount = this.tracked.size();
/*  939 */             notifyAll();
/*      */           } else {
/*  941 */             becameUntracked = true;
/*      */           } 
/*      */         } 
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/*  948 */       if (becameUntracked) {
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  953 */         customizerRemoved(item, related, object, trackingCount);
/*      */       
/*      */       }
/*      */       else {
/*      */ 
/*      */         
/*  959 */         customizerAdded(item, related, object, trackingCount, serviceCount);
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     void untrack(S item, R related) {
/*      */       T object;
/*      */       int trackingCount;
/*  972 */       synchronized (this) {
/*  973 */         if (this.initial.remove(item)) {
/*      */           return;
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  986 */         if (this.adding.remove(item)) {
/*      */           return;
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1000 */         object = this.tracked.remove(item);
/*      */ 
/*      */         
/* 1003 */         if (object == null) {
/*      */           return;
/*      */         }
/* 1006 */         trackingCount = modified();
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1012 */       customizerRemoved(item, related, object, trackingCount);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     int size() {
/* 1027 */       return this.tracked.size();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     boolean isEmpty() {
/* 1039 */       return this.tracked.isEmpty();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     T getCustomizedObject(S item) {
/* 1051 */       return this.tracked.get(item);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     S[] copyKeys(S[] list) {
/* 1063 */       return (S[])this.tracked.keySet().toArray((Object[])list);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     int modified() {
/* 1073 */       return this.trackingCount.incrementAndGet();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     int getTrackingCount() {
/* 1087 */       return this.trackingCount.get();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     <M extends Map<? super S, ? super T>> M copyEntries(M map) {
/* 1103 */       map.putAll(this.tracked);
/* 1104 */       return map;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     abstract T customizerAdding(S param1S, R param1R);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     abstract void customizerAdded(S param1S, R param1R, T param1T, int param1Int1, int param1Int2);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     abstract void customizerModified(S param1S, R param1R, T param1T, int param1Int);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     abstract void customizerRemoved(S param1S, R param1R, T param1T, int param1Int);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private class Tracked
/*      */     extends AbstractTracked<ServiceReference<S>, T, U>
/*      */     implements ExtendedServiceListener<U>
/*      */   {
/*      */     Tracked(AtomicInteger trackingCount) {
/* 1158 */       super(trackingCount);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final void serviceChanged(U event) {
/* 1172 */       if (this.closed) {
/*      */         return;
/*      */       }
/*      */       
/* 1176 */       ServiceReference<S> reference = event.getServiceReference();
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1181 */       switch (event.getType()) {
/*      */         case 1:
/*      */         case 2:
/* 1184 */           track(reference, event);
/*      */           return;
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         case 4:
/*      */         case 8:
/* 1192 */           untrack(reference, event);
/*      */           return;
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1199 */       System.out.println("Unrecognized event type: ServiceTracker.Tracked.serviceChanged[" + event.getType() + "]: " + reference);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     final int modified() {
/* 1211 */       int trackingCount = super.modified();
/* 1212 */       ServiceTracker.this.modified();
/* 1213 */       return trackingCount;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     final T customizerAdding(ServiceReference<S> item, U related) {
/* 1228 */       return (T)ServiceTracker.this.customizer.addingService(item);
/*      */     }
/*      */     
/*      */     final void customizerAdded(ServiceReference<S> item, U related, T object, int trackingCount, int serviceCount) {
/* 1232 */       ServiceTracker.this.customizer.addedService(item, object, trackingCount, serviceCount, related);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     final void customizerModified(ServiceReference<S> item, U related, T object, int trackingCount) {
/* 1245 */       ServiceTracker.this.customizer.modifiedService(item, object, trackingCount, related);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     final void customizerRemoved(ServiceReference<S> item, U related, T object, int trackingCount) {
/* 1258 */       ServiceTracker.this.customizer.removedService(item, object, trackingCount, related);
/*      */     }
/*      */   }
/*      */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.apache.felix.scr-2.2.6.jar!\org\apache\felix\scr\impl\manager\ServiceTracker.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */