/*    */ package org.apache.felix.scr.impl.inject;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class BaseParameter
/*    */ {
/*    */   private final ScrComponentContext m_componentContext;
/*    */   
/*    */   public BaseParameter(ScrComponentContext componentContext) {
/* 27 */     this.m_componentContext = componentContext;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public ScrComponentContext getComponentContext() {
/* 33 */     return this.m_componentContext;
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.apache.felix.scr-2.2.6.jar!\org\apache\felix\scr\impl\inject\BaseParameter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */