/*     */ package org.apache.felix.scr.impl.inject.field;
/*     */ 
/*     */ import java.lang.reflect.Field;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Modifier;
/*     */ import java.security.AccessController;
/*     */ import java.security.PrivilegedAction;
/*     */ import org.apache.felix.scr.impl.inject.internal.ClassUtils;
/*     */ import org.apache.felix.scr.impl.logger.ComponentLogger;
/*     */ import org.apache.felix.scr.impl.logger.InternalLogger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FieldUtils
/*     */ {
/*     */   public static final class FieldSearchResult
/*     */   {
/*     */     public final Field field;
/*     */     public final boolean usable;
/*     */     
/*     */     public FieldSearchResult(Field f, boolean usable) {
/*  46 */       this.field = f;
/*  47 */       this.usable = usable;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static FieldSearchResult searchField(Class<?> componentClass, String fieldName, ComponentLogger logger) {
/*  74 */     ClassLoader targetClasslLoader = componentClass.getClassLoader();
/*  75 */     String targetPackage = ClassUtils.getPackageName(componentClass);
/*  76 */     Class<?> theClass = componentClass;
/*  77 */     boolean acceptPrivate = true;
/*  78 */     boolean acceptPackage = true;
/*     */ 
/*     */     
/*     */     while (true) {
/*  82 */       logger.log(InternalLogger.Level.DEBUG, "Locating field {0} in class {1}", null, new Object[] { fieldName, theClass
/*  83 */             .getName() });
/*     */ 
/*     */       
/*     */       try {
/*  87 */         FieldSearchResult result = getField(componentClass, theClass, fieldName, acceptPrivate, acceptPackage, logger);
/*  88 */         if (result != null)
/*     */         {
/*  90 */           return result;
/*     */         }
/*     */       }
/*  93 */       catch (InvocationTargetException ex) {
/*     */         
/*  95 */         logger.log(InternalLogger.Level.ERROR, "Field {0} cannot be found in component class {1}. The field will be ignored.", ex
/*     */             
/*  97 */             .getTargetException(), new Object[] { fieldName, componentClass
/*  98 */               .getName() });
/*  99 */         return null;
/*     */       } 
/*     */ 
/*     */       
/* 103 */       theClass = theClass.getSuperclass();
/* 104 */       if (theClass == null) {
/*     */         break;
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 113 */       int i = acceptPackage & ((targetClasslLoader == theClass.getClassLoader() && targetPackage.equals(ClassUtils.getPackageName(theClass))) ? 1 : 0);
/*     */ 
/*     */       
/* 116 */       acceptPrivate = false;
/*     */     } 
/*     */ 
/*     */     
/* 120 */     logger.log(InternalLogger.Level.ERROR, "Field {0} cannot be found in component class {1}. The field will be ignored.", null, new Object[] { fieldName, componentClass
/*     */ 
/*     */           
/* 123 */           .getName() });
/* 124 */     return new FieldSearchResult(null, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static FieldSearchResult getField(Class<?> componentClass, Class<?> targetClass, String fieldName, boolean acceptPrivate, boolean acceptPackage, ComponentLogger logger) throws InvocationTargetException {
/*     */     try {
/* 157 */       Field field = targetClass.getDeclaredField(fieldName);
/*     */ 
/*     */       
/* 160 */       return accept(componentClass, field, acceptPrivate, acceptPackage, logger);
/*     */     }
/* 162 */     catch (NoSuchFieldException nsfe) {
/*     */ 
/*     */ 
/*     */       
/* 166 */       if (logger.isLogEnabled(InternalLogger.Level.DEBUG))
/*     */       {
/* 168 */         logger.log(InternalLogger.Level.DEBUG, "Declared Field {0}.{1} not found", null, new Object[] { targetClass
/* 169 */               .getName(), fieldName });
/*     */       }
/*     */     }
/* 172 */     catch (Throwable throwable) {
/*     */ 
/*     */ 
/*     */       
/* 176 */       throw new InvocationTargetException(throwable, "Unexpected problem trying to get field " + fieldName);
/*     */     } 
/*     */ 
/*     */     
/* 180 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static FieldSearchResult accept(Class<?> componentClass, Field field, boolean acceptPrivate, boolean acceptPackage, ComponentLogger logger) {
/* 214 */     int mod = field.getModifiers();
/*     */ 
/*     */     
/* 217 */     if (Modifier.isStatic(mod)) {
/*     */       
/* 219 */       logger.log(InternalLogger.Level.ERROR, "Field {0} must not be static", null, new Object[] {
/* 220 */             toString(componentClass, field) });
/* 221 */       return new FieldSearchResult(field, false);
/*     */     } 
/*     */ 
/*     */     
/* 225 */     if (Modifier.isPublic(mod) || Modifier.isProtected(mod)) {
/*     */       
/* 227 */       setAccessible(field);
/* 228 */       return new FieldSearchResult(field, true);
/*     */     } 
/*     */ 
/*     */     
/* 232 */     if (Modifier.isPrivate(mod)) {
/*     */       
/* 234 */       if (acceptPrivate)
/*     */       {
/* 236 */         setAccessible(field);
/* 237 */         return new FieldSearchResult(field, true);
/*     */       
/*     */       }
/*     */ 
/*     */     
/*     */     }
/* 243 */     else if (acceptPackage) {
/*     */       
/* 245 */       setAccessible(field);
/* 246 */       return new FieldSearchResult(field, true);
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 252 */     logger.log(InternalLogger.Level.ERROR, "findField: Suitable but non-accessible field {0}", null, new Object[] {
/* 253 */           toString(componentClass, field) });
/* 254 */     return new FieldSearchResult(field, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String toString(Class<?> componentClass, Field field) {
/* 266 */     if (componentClass.getName().equals(field.getDeclaringClass().getName()))
/*     */     {
/* 268 */       return field.getName() + " in component class " + componentClass.getName();
/*     */     }
/* 270 */     return field.getName() + " in class " + field.getDeclaringClass().getName() + ", subclass of component class " + componentClass.getName();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void setAccessible(final Field field) {
/* 279 */     AccessController.doPrivileged(new PrivilegedAction()
/*     */         {
/*     */           
/*     */           public Object run()
/*     */           {
/* 284 */             field.setAccessible(true);
/* 285 */             return null;
/*     */           }
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void setField(Field f, Object component, Object value, ComponentLogger logger) {
/*     */     try {
/* 304 */       f.set(component, value);
/*     */     }
/* 306 */     catch (IllegalArgumentException iae) {
/*     */       
/* 308 */       logger.log(InternalLogger.Level.ERROR, "Field {0} can't be set", iae, new Object[] { f.getName() });
/*     */     }
/* 310 */     catch (IllegalAccessException iae) {
/*     */       
/* 312 */       logger.log(InternalLogger.Level.ERROR, "Field {0} can't be set", iae, new Object[] { f.getName() });
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.apache.felix.scr-2.2.6.jar!\org\apache\felix\scr\impl\inject\field\FieldUtils.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */