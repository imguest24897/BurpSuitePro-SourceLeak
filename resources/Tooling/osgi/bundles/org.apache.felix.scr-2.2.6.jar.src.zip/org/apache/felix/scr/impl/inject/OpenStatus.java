package org.apache.felix.scr.impl.inject;

import java.util.Collection;
import java.util.concurrent.atomic.AtomicInteger;

public interface OpenStatus<S, T> {
  Collection<RefPair<S, T>> getRefs(AtomicInteger paramAtomicInteger);
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.apache.felix.scr-2.2.6.jar!\org\apache\felix\scr\impl\inject\OpenStatus.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */