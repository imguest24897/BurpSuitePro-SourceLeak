/*     */ package org.apache.felix.scr.impl.inject.internal;
/*     */ 
/*     */ import java.util.List;
/*     */ import org.apache.felix.scr.impl.inject.BindParameters;
/*     */ import org.apache.felix.scr.impl.inject.InitReferenceMethod;
/*     */ import org.apache.felix.scr.impl.inject.MethodResult;
/*     */ import org.apache.felix.scr.impl.inject.ReferenceMethod;
/*     */ import org.apache.felix.scr.impl.inject.ReferenceMethods;
/*     */ import org.apache.felix.scr.impl.logger.ComponentLogger;
/*     */ import org.osgi.framework.BundleContext;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DuplexReferenceMethods
/*     */   implements ReferenceMethods
/*     */ {
/*     */   private final ReferenceMethod bind;
/*     */   private final ReferenceMethod updated;
/*     */   private final ReferenceMethod unbind;
/*     */   private final InitReferenceMethod init;
/*     */   
/*     */   public DuplexReferenceMethods(final List<ReferenceMethods> methods) {
/*  40 */     ReferenceMethod[] bindList = new ReferenceMethod[methods.size()];
/*  41 */     ReferenceMethod[] updatedList = new ReferenceMethod[methods.size()];
/*  42 */     ReferenceMethod[] unbindList = new ReferenceMethod[methods.size()];
/*  43 */     int index = 0;
/*  44 */     for (ReferenceMethods m : methods) {
/*     */       
/*  46 */       bindList[index] = m.getBind();
/*  47 */       updatedList[index] = m.getUpdated();
/*  48 */       unbindList[index] = m.getUnbind();
/*  49 */       index++;
/*     */     } 
/*  51 */     this.bind = new DuplexReferenceMethod(bindList);
/*  52 */     this.updated = new DuplexReferenceMethod(updatedList);
/*  53 */     this.unbind = new DuplexReferenceMethod(unbindList);
/*  54 */     this.init = new InitReferenceMethod()
/*     */       {
/*     */         
/*     */         public boolean init(Object componentInstance, ComponentLogger logger)
/*     */         {
/*  59 */           boolean result = true;
/*  60 */           for (ReferenceMethods m : methods) {
/*     */             
/*  62 */             InitReferenceMethod init = m.getInit();
/*  63 */             if (init != null) {
/*     */               
/*  65 */               result = init.init(componentInstance, logger);
/*  66 */               if (!result) {
/*     */                 break;
/*     */               }
/*     */             } 
/*     */           } 
/*     */           
/*  72 */           return result;
/*     */         }
/*     */       };
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ReferenceMethod getBind() {
/*  80 */     return this.bind;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ReferenceMethod getUnbind() {
/*  86 */     return this.unbind;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ReferenceMethod getUpdated() {
/*  92 */     return this.updated;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public InitReferenceMethod getInit() {
/*  98 */     return this.init;
/*     */   }
/*     */ 
/*     */   
/*     */   private static final class DuplexReferenceMethod
/*     */     implements ReferenceMethod
/*     */   {
/*     */     private final ReferenceMethod[] methods;
/*     */     
/*     */     public DuplexReferenceMethod(ReferenceMethod[] methods) {
/* 108 */       this.methods = methods;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public MethodResult invoke(Object componentInstance, BindParameters parameters, MethodResult methodCallFailureResult) {
/* 116 */       MethodResult result = null;
/* 117 */       for (ReferenceMethod m : this.methods) {
/*     */         
/* 119 */         result = m.invoke(componentInstance, parameters, methodCallFailureResult);
/* 120 */         if (result == null) {
/*     */           break;
/*     */         }
/*     */       } 
/*     */       
/* 125 */       return result;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public <S, T> boolean getServiceObject(BindParameters parameters, BundleContext context) {
/* 134 */       boolean result = false;
/* 135 */       for (ReferenceMethod m : this.methods) {
/*     */         
/* 137 */         result = m.getServiceObject(parameters, context);
/* 138 */         if (!result) {
/*     */           break;
/*     */         }
/*     */       } 
/*     */       
/* 143 */       return result;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.apache.felix.scr-2.2.6.jar!\org\apache\felix\scr\impl\inject\internal\DuplexReferenceMethods.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */