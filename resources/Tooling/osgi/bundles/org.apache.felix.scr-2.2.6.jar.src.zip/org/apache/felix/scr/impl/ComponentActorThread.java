/*     */ package org.apache.felix.scr.impl;
/*     */ 
/*     */ import java.util.LinkedList;
/*     */ import org.apache.felix.scr.impl.logger.InternalLogger;
/*     */ import org.apache.felix.scr.impl.logger.ScrLogger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class ComponentActorThread
/*     */   implements Runnable
/*     */ {
/*  36 */   private static final Runnable TERMINATION_TASK = new Runnable()
/*     */     {
/*     */       public void run() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       public String toString() {
/*  47 */         return "Component Actor Terminator";
/*     */       }
/*     */     };
/*     */ 
/*     */   
/*  52 */   private final LinkedList<Runnable> tasks = new LinkedList<>();
/*     */ 
/*     */   
/*     */   private final ScrLogger logger;
/*     */ 
/*     */   
/*     */   ComponentActorThread(ScrLogger log) {
/*  59 */     this.logger = log;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void run() {
/*  71 */     this.logger.log(InternalLogger.Level.DEBUG, "Starting ComponentActorThread", null);
/*     */     
/*     */     while (true) {
/*     */       Runnable task;
/*     */       
/*  76 */       synchronized (this.tasks) {
/*     */         
/*  78 */         while (this.tasks.isEmpty()) {
/*     */           
/*  80 */           boolean interrupted = Thread.interrupted();
/*     */           
/*     */           try {
/*  83 */             this.tasks.wait();
/*     */           }
/*  85 */           catch (InterruptedException ie) {
/*     */             
/*  87 */             interrupted = true;
/*     */           
/*     */           }
/*     */           finally {
/*     */             
/*  92 */             if (interrupted)
/*     */             {
/*  94 */               Thread.currentThread().interrupt();
/*     */             }
/*     */           } 
/*     */         } 
/*     */         
/*  99 */         task = this.tasks.removeFirst();
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/*     */       try {
/* 105 */         if (task == TERMINATION_TASK) {
/*     */           
/* 107 */           this.logger.log(InternalLogger.Level.DEBUG, "Shutting down ComponentActorThread", null);
/*     */ 
/*     */           
/*     */           return;
/*     */         } 
/*     */         
/* 113 */         this.logger.log(InternalLogger.Level.DEBUG, "Running task: " + task, null);
/* 114 */         task.run();
/*     */       }
/* 116 */       catch (Throwable t) {
/*     */         
/* 118 */         this.logger.log(InternalLogger.Level.ERROR, "Unexpected problem executing task " + task, t);
/*     */       
/*     */       }
/*     */       finally {
/*     */         
/* 123 */         synchronized (this.tasks) {
/*     */           
/* 125 */           this.tasks.notifyAll();
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void terminate() {
/* 136 */     schedule(TERMINATION_TASK);
/* 137 */     synchronized (this.tasks) {
/*     */       
/* 139 */       while (!this.tasks.isEmpty()) {
/*     */         
/* 141 */         boolean interrupted = Thread.interrupted();
/*     */         
/*     */         try {
/* 144 */           this.tasks.wait();
/*     */         }
/* 146 */         catch (InterruptedException e) {
/*     */           
/* 148 */           interrupted = true;
/* 149 */           this.logger.log(InternalLogger.Level.ERROR, "Interrupted exception waiting for queue to empty", e);
/*     */         
/*     */         }
/*     */         finally {
/*     */           
/* 154 */           if (interrupted)
/*     */           {
/* 156 */             Thread.currentThread().interrupt();
/*     */           }
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void schedule(Runnable task) {
/* 167 */     synchronized (this.tasks) {
/*     */ 
/*     */       
/* 170 */       this.tasks.add(task);
/*     */       
/* 172 */       this.logger.log(InternalLogger.Level.DEBUG, "Adding task [{0}] as #{1} in the queue", null, new Object[] { task, 
/* 173 */             Integer.valueOf(this.tasks.size()) });
/*     */ 
/*     */       
/* 176 */       this.tasks.notifyAll();
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.apache.felix.scr-2.2.6.jar!\org\apache\felix\scr\impl\ComponentActorThread.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */