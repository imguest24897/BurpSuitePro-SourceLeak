/*     */ package org.apache.felix.scr.impl.inject.internal;
/*     */ 
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.lang.reflect.Array;
/*     */ import java.lang.reflect.Field;
/*     */ import java.lang.reflect.InvocationHandler;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Modifier;
/*     */ import java.lang.reflect.Proxy;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.regex.Matcher;
/*     */ import java.util.regex.Pattern;
/*     */ import org.apache.felix.scr.impl.helper.Coercions;
/*     */ import org.osgi.framework.Bundle;
/*     */ import org.osgi.service.component.ComponentException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Annotations
/*     */ {
/*  47 */   private static final Set<Method> ANNOTATION_METHODS = new HashSet<>(); private static final String VALUE_METHOD = "value"; private static final String PREFIX_CONSTANT = "PREFIX_";
/*     */   
/*     */   static {
/*  50 */     for (Method m : Annotation.class.getMethods())
/*     */     {
/*  52 */       ANNOTATION_METHODS.add(m);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isSingleElementAnnotation(Class<?> clazz) {
/*  71 */     boolean result = false;
/*  72 */     if (clazz.isAnnotation()) {
/*     */       
/*  74 */       result = true;
/*  75 */       boolean hasValue = false;
/*  76 */       for (Method method : clazz.getMethods()) {
/*     */ 
/*     */         
/*  79 */         boolean isFromAnnotation = false;
/*  80 */         for (Method objMethod : ANNOTATION_METHODS) {
/*     */           
/*  82 */           if (objMethod.getName().equals(method.getName()) && 
/*  83 */             Arrays.equals((Object[])objMethod.getParameterTypes(), (Object[])method.getParameterTypes())) {
/*     */             
/*  85 */             isFromAnnotation = true;
/*     */             break;
/*     */           } 
/*     */         } 
/*  89 */         if (!isFromAnnotation)
/*     */         {
/*     */ 
/*     */           
/*  93 */           if ("value".equals(method.getName())) {
/*     */             
/*  95 */             hasValue = true;
/*     */           
/*     */           }
/*  98 */           else if (method.getDefaultValue() == null) {
/*     */             
/* 100 */             result = false;
/*     */             break;
/*     */           } 
/*     */         }
/*     */       } 
/* 105 */       if (result)
/*     */       {
/* 107 */         result = hasValue;
/*     */       }
/*     */     } 
/*     */     
/* 111 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getPrefix(Class<?> clazz) {
/*     */     try {
/* 118 */       Field f = clazz.getField("PREFIX_");
/* 119 */       if (Modifier.isStatic(f.getModifiers()) && 
/* 120 */         Modifier.isPublic(f.getModifiers()) && 
/* 121 */         Modifier.isFinal(f.getModifiers()) && String.class
/* 122 */         .isAssignableFrom(f.getType()))
/*     */       {
/* 124 */         Object value = f.get(null);
/* 125 */         if (value != null)
/*     */         {
/* 127 */           return value.toString();
/*     */         }
/*     */       }
/*     */     
/* 131 */     } catch (Exception exception) {}
/*     */ 
/*     */ 
/*     */     
/* 135 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> T toObject(Class<T> clazz, Map<String, Object> props, Bundle b, boolean supportsInterfaces) {
/* 141 */     boolean isSingleElementAnn = isSingleElementAnnotation(clazz);
/* 142 */     String prefix = getPrefix(clazz);
/* 143 */     Map<String, Object> m = new HashMap<>();
/*     */     
/* 145 */     Map<String, Method> complexFields = new HashMap<>();
/* 146 */     for (Method method : clazz.getMethods()) {
/*     */       
/* 148 */       String mapped, name = method.getName();
/*     */       
/* 150 */       if (isSingleElementAnn && name.equals("value")) {
/*     */         
/* 152 */         mapped = mapTypeNameToKey(clazz.getSimpleName());
/*     */       }
/*     */       else {
/*     */         
/* 156 */         mapped = mapIdentifierToKey(name);
/*     */       } 
/* 158 */       String key = (prefix == null) ? mapped : prefix.concat(mapped);
/*     */       
/* 160 */       Object raw = props.get(key);
/* 161 */       Class<?> returnType = method.getReturnType();
/*     */       
/* 163 */       if (returnType.isInterface() || returnType.isAnnotation()) {
/*     */         
/* 165 */         complexFields.put(key, method);
/*     */       } else {
/*     */ 
/*     */ 
/*     */         
/*     */         try { 
/* 171 */           if (returnType.isArray())
/*     */           
/* 173 */           { Class<?> componentType = returnType.getComponentType();
/* 174 */             if (componentType.isInterface() || componentType.isAnnotation())
/*     */             
/* 176 */             { complexFields.put(key, method); }
/*     */             else
/*     */             
/* 179 */             { Object cooked = coerceToArray(componentType, raw, b);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */               
/* 190 */               m.put(name, cooked); }  } else { Object cooked = Coercions.coerce(returnType, raw, b); m.put(name, cooked); }  } catch (ComponentException e) { Object cooked = new Invalid(e); m.put(name, cooked); } 
/*     */       } 
/* 192 */     }  if (!complexFields.isEmpty())
/*     */     {
/* 194 */       if (supportsInterfaces) {
/*     */         
/* 196 */         Map<String, List<Map<String, Object>>> nested = extractSubMaps(complexFields.keySet(), props);
/* 197 */         for (Map.Entry<String, Method> entry : complexFields.entrySet())
/*     */         {
/* 199 */           List<Map<String, Object>> proplist = nested.get(entry.getKey());
/* 200 */           if (proplist == null)
/*     */           {
/* 202 */             proplist = Collections.emptyList();
/*     */           }
/* 204 */           Method method = entry.getValue();
/* 205 */           Class<?> returnType = method.getReturnType();
/* 206 */           if (returnType.isArray()) {
/*     */             
/* 208 */             Class<?> componentType = returnType.getComponentType();
/* 209 */             Object result = Array.newInstance(componentType, proplist.size());
/* 210 */             for (int i = 0; i < proplist.size(); i++) {
/*     */               
/* 212 */               Map<String, Object> rawElement = proplist.get(i);
/* 213 */               Object cooked = toObject(componentType, rawElement, b, supportsInterfaces);
/* 214 */               Array.set(result, i, cooked);
/*     */             } 
/* 216 */             m.put(method.getName(), result);
/*     */             
/*     */             continue;
/*     */           } 
/* 220 */           if (!proplist.isEmpty())
/*     */           {
/* 222 */             Object cooked = toObject(returnType, proplist.get(0), b, supportsInterfaces);
/* 223 */             m.put(method.getName(), cooked);
/*     */           }
/*     */         
/*     */         }
/*     */       
/*     */       } else {
/*     */         
/* 230 */         for (Method method : complexFields.values())
/*     */         {
/* 232 */           m.put(method.getName(), new Invalid("Invalid annotation member type" + method.getReturnType().getName() + " for member: " + method.getName()));
/*     */         }
/*     */       } 
/*     */     }
/*     */     
/* 237 */     InvocationHandler h = new Handler(m, clazz);
/* 238 */     return (T)Proxy.newProxyInstance(clazz.getClassLoader(), new Class[] { clazz }, h);
/*     */   }
/*     */ 
/*     */   
/*     */   private static Map<String, List<Map<String, Object>>> extractSubMaps(Collection<String> keys, Map<String, Object> map) {
/* 243 */     Map<String, List<Map<String, Object>>> result = new HashMap<>();
/*     */     
/* 245 */     StringBuilder b = new StringBuilder("(");
/* 246 */     for (String key : keys)
/*     */     {
/* 248 */       b.append(key).append("|");
/*     */     }
/* 250 */     b.deleteCharAt(b.length() - 1);
/* 251 */     b.append(")\\.([0-9]*)\\.(.*)");
/* 252 */     Pattern p = Pattern.compile(b.toString());
/* 253 */     for (Map.Entry<String, Object> entry : map.entrySet()) {
/*     */       
/* 255 */       String longKey = entry.getKey();
/* 256 */       Matcher m = p.matcher(longKey);
/* 257 */       if (m.matches()) {
/*     */         
/* 259 */         String key = m.group(1);
/* 260 */         int index = Integer.parseInt(m.group(2));
/* 261 */         String subkey = m.group(3);
/* 262 */         List<Map<String, Object>> subMapsForKey = result.get(key);
/* 263 */         if (subMapsForKey == null) {
/*     */           
/* 265 */           subMapsForKey = new ArrayList<>();
/* 266 */           result.put(key, subMapsForKey);
/*     */         } 
/*     */         
/* 269 */         for (int i = subMapsForKey.size(); i <= index; i++)
/*     */         {
/* 271 */           subMapsForKey.add(new HashMap<>());
/*     */         }
/* 273 */         Map<String, Object> subMap = subMapsForKey.get(index);
/* 274 */         subMap.put(subkey, entry.getValue());
/*     */       } 
/*     */     } 
/* 277 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   private static Object coerceToArray(Class<?> componentType, Object raw, Bundle bundle) {
/* 282 */     if (raw == null)
/*     */     {
/* 284 */       return Array.newInstance(componentType, 0);
/*     */     }
/* 286 */     if (raw.getClass().isArray()) {
/*     */       
/* 288 */       int size = Array.getLength(raw);
/* 289 */       Object object = Array.newInstance(componentType, size);
/* 290 */       for (int i = 0; i < size; i++) {
/*     */         
/* 292 */         Object rawElement = Array.get(raw, i);
/* 293 */         Object object1 = Coercions.coerce(componentType, rawElement, bundle);
/* 294 */         Array.set(object, i, object1);
/*     */       } 
/* 296 */       return object;
/*     */     } 
/* 298 */     if (raw instanceof Collection) {
/*     */ 
/*     */       
/* 301 */       Collection raws = (Collection)raw;
/* 302 */       int size = raws.size();
/* 303 */       Object object = Array.newInstance(componentType, size);
/* 304 */       int i = 0;
/* 305 */       for (Object rawElement : raws) {
/*     */         
/* 307 */         Object object1 = Coercions.coerce(componentType, rawElement, bundle);
/* 308 */         Array.set(object, i++, object1);
/*     */       } 
/* 310 */       return object;
/*     */     } 
/*     */     
/* 313 */     Object cooked = Coercions.coerce(componentType, raw, bundle);
/* 314 */     Object result = Array.newInstance(componentType, 1);
/* 315 */     Array.set(result, 0, cooked);
/* 316 */     return result;
/*     */   }
/*     */ 
/*     */   
/* 320 */   private static final Pattern p = Pattern.compile("(\\$_\\$)|(\\$\\$)|(\\$)|(__)|(_)");
/*     */ 
/*     */   
/*     */   static String mapIdentifierToKey(String name) {
/* 324 */     Matcher m = p.matcher(name);
/* 325 */     StringBuffer b = new StringBuffer();
/* 326 */     while (m.find()) {
/*     */       
/* 328 */       String replacement = "";
/* 329 */       if (m.group(1) != null) replacement = "-"; 
/* 330 */       if (m.group(2) != null) replacement = "\\$"; 
/* 331 */       if (m.group(3) != null) replacement = ""; 
/* 332 */       if (m.group(4) != null) replacement = "_"; 
/* 333 */       if (m.group(5) != null) replacement = ".";
/*     */       
/* 335 */       m.appendReplacement(b, replacement);
/*     */     } 
/* 337 */     m.appendTail(b);
/* 338 */     return b.toString();
/*     */   }
/*     */ 
/*     */   
/*     */   static String mapTypeNameToKey(String name) {
/* 343 */     StringBuilder sb = new StringBuilder();
/* 344 */     boolean lastLow = false;
/* 345 */     for (char c : name.toCharArray()) {
/*     */       
/* 347 */       if (lastLow && (Character.isLetter(c) || Character.isDigit(c)) && Character.isUpperCase(c))
/*     */       {
/* 349 */         sb.append('.');
/*     */       }
/* 351 */       lastLow = false;
/* 352 */       if ((Character.isLetter(c) || Character.isDigit(c)) && Character.isLowerCase(c))
/*     */       {
/* 354 */         lastLow = true;
/*     */       }
/* 356 */       sb.append(Character.toLowerCase(c));
/*     */     } 
/* 358 */     return sb.toString();
/*     */   }
/*     */ 
/*     */   
/*     */   private static final class Handler
/*     */     implements InvocationHandler
/*     */   {
/*     */     private final Map<String, Object> values;
/*     */     private final Class<?> type;
/*     */     
/*     */     public Handler(Map<String, Object> values, Class<?> type) {
/* 369 */       this.values = values;
/* 370 */       this.type = type;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public Object invoke(Object proxy, Method method, Object[] args) throws Throwable {
/* 376 */       Object<?> value = (Object<?>)this.values.get(method.getName());
/* 377 */       if (value instanceof Annotations.Invalid)
/*     */       {
/* 379 */         throw new ComponentException(((Annotations.Invalid)value).getMessage());
/*     */       }
/* 381 */       if (value == null)
/*     */       {
/*     */         
/* 384 */         if (method.getName().equals("hashCode") && (method
/* 385 */           .getParameterTypes()).length == 0) {
/*     */           
/* 387 */           int hashCode = 0;
/* 388 */           for (Map.Entry<String, Object> entry : this.values.entrySet()) {
/* 389 */             if (value instanceof Annotations.Invalid) {
/*     */               continue;
/*     */             }
/* 392 */             hashCode += 127 * ((String)entry.getKey()).hashCode() ^ entry.getValue().hashCode();
/*     */           } 
/* 394 */           value = (Object<?>)Integer.valueOf(hashCode);
/*     */         }
/* 396 */         else if (method.getName().equals("equals") && (method
/* 397 */           .getParameterTypes()).length == 1) {
/*     */           
/* 399 */           Object other = args[0];
/* 400 */           if (proxy == other) {
/*     */             
/* 402 */             value = (Object<?>)Boolean.valueOf(true);
/*     */           }
/*     */           else {
/*     */             
/* 406 */             value = (Object<?>)Boolean.valueOf(false);
/* 407 */             if (this.type.isInstance(other) && Proxy.isProxyClass(other.getClass()))
/*     */             {
/* 409 */               InvocationHandler ih = Proxy.getInvocationHandler(other);
/* 410 */               if (ih instanceof Handler) {
/* 411 */                 value = (Object<?>)Boolean.valueOf(((Handler)ih).values.equals(this.values));
/*     */               }
/*     */             }
/*     */           
/*     */           } 
/* 416 */         } else if (method.getName().equals("toString") && (method
/* 417 */           .getParameterTypes()).length == 0) {
/*     */           
/* 419 */           value = (Object<?>)(this.type.getName() + " : " + this.values);
/*     */         }
/* 421 */         else if (method.getName().equals("annotationType") && (method
/* 422 */           .getParameterTypes()).length == 0) {
/*     */           
/* 424 */           value = (Object<?>)this.type;
/*     */         } 
/*     */       }
/* 427 */       return value;
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private static final class Invalid
/*     */   {
/*     */     private final String message;
/*     */     
/*     */     public Invalid(ComponentException e) {
/* 437 */       this.message = e.getMessage();
/*     */     }
/*     */ 
/*     */     
/*     */     public Invalid(String message) {
/* 442 */       this.message = message;
/*     */     }
/*     */ 
/*     */     
/*     */     public String getMessage() {
/* 447 */       return this.message;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.apache.felix.scr-2.2.6.jar!\org\apache\felix\scr\impl\inject\internal\Annotations.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */