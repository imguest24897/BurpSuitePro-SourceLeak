/*    */ package org.apache.felix.scr.impl.manager;
/*    */ 
/*    */ import java.util.AbstractMap;
/*    */ import java.util.Collection;
/*    */ import java.util.Collections;
/*    */ import java.util.Map;
/*    */ import java.util.concurrent.atomic.AtomicReference;
/*    */ import org.apache.felix.scr.impl.inject.ScrComponentContext;
/*    */ import org.osgi.framework.ServiceReference;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SinglePrototypeRefPair<S, T>
/*    */   extends AbstractPrototypeRefPair<S, T>
/*    */ {
/* 38 */   private final AtomicReference<AbstractMap.SimpleImmutableEntry<ScrComponentContext, T>> instance = new AtomicReference<>();
/*    */ 
/*    */   
/*    */   public SinglePrototypeRefPair(ServiceReference<T> ref) {
/* 42 */     super(ref);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public String toString() {
/* 48 */     return "[SinglePrototypeRefPair: ref: [" + getRef() + "] service: [" + getServiceObject(null) + "]]";
/*    */   }
/*    */ 
/*    */   
/*    */   public T getServiceObject(ScrComponentContext key) {
/* 53 */     return internalGetServiceObject(key, false);
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean setServiceObject(ScrComponentContext key, T serviceObject) {
/* 58 */     return this.instance.compareAndSet(null, new AbstractMap.SimpleImmutableEntry<>(key, serviceObject));
/*    */   }
/*    */ 
/*    */   
/*    */   protected T remove(ScrComponentContext key) {
/* 63 */     return internalGetServiceObject(key, true);
/*    */   }
/*    */   
/*    */   private T internalGetServiceObject(ScrComponentContext key, boolean remove) {
/* 67 */     AbstractMap.SimpleImmutableEntry<ScrComponentContext, T> entry = this.instance.get();
/* 68 */     if (entry == null) {
/* 69 */       return null;
/*    */     }
/* 71 */     V v = (key == null || ((ScrComponentContext)entry.getKey()).equals(key)) ? (V)entry.getValue() : null;
/* 72 */     if (remove && v != null) {
/* 73 */       this.instance.compareAndSet(entry, null);
/*    */     }
/* 75 */     return (T)v;
/*    */   }
/*    */ 
/*    */   
/*    */   protected Collection<Map.Entry<ScrComponentContext, T>> clearEntries() {
/* 80 */     Map.Entry<ScrComponentContext, T> entry = this.instance.getAndSet(null);
/* 81 */     return (entry == null) ? Collections.<Map.Entry<ScrComponentContext, T>>emptyList() : Collections.<Map.Entry<ScrComponentContext, T>>singleton(entry);
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.apache.felix.scr-2.2.6.jar!\org\apache\felix\scr\impl\manager\SinglePrototypeRefPair.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */