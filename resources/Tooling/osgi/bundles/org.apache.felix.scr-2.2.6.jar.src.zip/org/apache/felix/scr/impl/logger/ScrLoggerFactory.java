/*    */ package org.apache.felix.scr.impl.logger;
/*    */ 
/*    */ import org.osgi.framework.BundleContext;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class ScrLoggerFactory
/*    */ {
/*    */   private ScrLoggerFactory() {
/* 32 */     throw new IllegalAccessError("Cannot be instantiated");
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static ScrLogger create(BundleContext context, LogConfiguration config) {
/* 51 */     if (!config.isLogEnabled())
/*    */     {
/* 53 */       return new NoOpLogger();
/*    */     }
/*    */ 
/*    */     
/* 57 */     ScrLogManager manager = null;
/* 58 */     if (config.isLogExtensionEnabled()) {
/*    */       
/* 60 */       manager = new ExtLogManager(context, config);
/*    */     }
/*    */     else {
/*    */       
/* 64 */       manager = new ScrLogManager(context, config);
/*    */     } 
/* 66 */     manager.init();
/* 67 */     return manager.scr();
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.apache.felix.scr-2.2.6.jar!\org\apache\felix\scr\impl\logger\ScrLoggerFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */