/*     */ package org.apache.felix.scr.impl.metadata;
/*     */ 
/*     */ import java.io.DataInputStream;
/*     */ import java.io.DataOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MetadataStoreHelper
/*     */ {
/*     */   static final int STORE_VERSION = 1;
/*     */   static final byte STRING_NULL = 0;
/*     */   static final byte STRING_OBJECT = 1;
/*     */   static final byte STRING_INDEX = 2;
/*     */   static final byte STRING_LONG = 3;
/*     */   
/*     */   public static class MetaDataReader
/*     */   {
/*  43 */     private final List<String> stringTable = new ArrayList<>();
/*     */ 
/*     */     
/*     */     public boolean isVersionSupported(DataInputStream in) throws IOException {
/*  47 */       return (1 == in.readInt());
/*     */     }
/*     */ 
/*     */     
/*     */     public String readIndexedString(DataInputStream in) throws IOException {
/*  52 */       String s = readString(in);
/*  53 */       addToStringTable(s, in.readInt());
/*  54 */       return s;
/*     */     }
/*     */     
/*     */     public String readString(DataInputStream in) throws IOException {
/*     */       String s;
/*  59 */       byte type = in.readByte();
/*  60 */       if (type == 2) {
/*     */         
/*  62 */         int index = in.readInt();
/*  63 */         return this.stringTable.get(index);
/*     */       } 
/*  65 */       if (type == 0)
/*     */       {
/*  67 */         return null;
/*     */       }
/*     */       
/*  70 */       if (type == 3) {
/*     */         
/*  72 */         int length = in.readInt();
/*  73 */         byte[] data = new byte[length];
/*  74 */         in.readFully(data);
/*  75 */         s = new String(data, "UTF-8");
/*     */       }
/*     */       else {
/*     */         
/*  79 */         s = in.readUTF();
/*     */       } 
/*  81 */       return s;
/*     */     }
/*     */ 
/*     */     
/*     */     private void addToStringTable(String s, int index) {
/*  86 */       if (index == this.stringTable.size()) {
/*     */         
/*  88 */         this.stringTable.add(s);
/*     */       }
/*  90 */       else if (index < this.stringTable.size()) {
/*     */         
/*  92 */         this.stringTable.set(index, s);
/*     */       }
/*     */       else {
/*     */         
/*  96 */         while (this.stringTable.size() < index)
/*     */         {
/*  98 */           this.stringTable.add(null);
/*     */         }
/* 100 */         this.stringTable.add(s);
/*     */       } 
/*     */     }
/*     */   }
/*     */   
/*     */   public static class MetaDataWriter
/*     */   {
/* 107 */     private final Map<String, Integer> stringTable = new HashMap<>();
/*     */ 
/*     */     
/*     */     public void writeVersion(DataOutputStream out) throws IOException {
/* 111 */       out.writeInt(1);
/*     */     }
/*     */ 
/*     */     
/*     */     public void writeIndexedString(String s, DataOutputStream out) throws IOException {
/* 116 */       writeString(s, out);
/* 117 */       out.writeInt(addToStringTable(s));
/*     */     }
/*     */ 
/*     */     
/*     */     public void writeString(String s, DataOutputStream out) throws IOException {
/* 122 */       Integer index = (s != null) ? this.stringTable.get(s) : null;
/* 123 */       if (index != null) {
/*     */         
/* 125 */         out.writeByte(2);
/* 126 */         out.writeInt(index.intValue());
/*     */         
/*     */         return;
/*     */       } 
/* 130 */       if (s == null) {
/* 131 */         out.writeByte(0);
/*     */       } else {
/*     */         
/* 134 */         byte[] data = s.getBytes("UTF-8");
/*     */         
/* 136 */         if (data.length > 65535) {
/*     */           
/* 138 */           out.writeByte(3);
/* 139 */           out.writeInt(data.length);
/* 140 */           out.write(data);
/*     */         }
/*     */         else {
/*     */           
/* 144 */           out.writeByte(1);
/* 145 */           out.writeUTF(s);
/*     */         } 
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     private int addToStringTable(String s) {
/* 152 */       if (s == null)
/*     */       {
/* 154 */         throw new NullPointerException();
/*     */       }
/* 156 */       Integer cur = this.stringTable.get(s);
/* 157 */       if (cur != null) {
/* 158 */         throw new IllegalStateException("String is already in the write table: " + s);
/*     */       }
/* 160 */       int index = this.stringTable.size();
/* 161 */       this.stringTable.put(s, Integer.valueOf(index));
/*     */       
/* 163 */       return index;
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public static void addString(String s, Set<String> strings) {
/* 169 */     if (s != null)
/*     */     {
/* 171 */       strings.add(s);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.apache.felix.scr-2.2.6.jar!\org\apache\felix\scr\impl\metadata\MetadataStoreHelper.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */