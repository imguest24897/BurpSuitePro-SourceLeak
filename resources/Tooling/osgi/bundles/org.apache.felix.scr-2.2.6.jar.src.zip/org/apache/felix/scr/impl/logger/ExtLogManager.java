/*    */ package org.apache.felix.scr.impl.logger;
/*    */ 
/*    */ import org.osgi.framework.Bundle;
/*    */ import org.osgi.framework.BundleContext;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class ExtLogManager
/*    */   extends ScrLogManager
/*    */ {
/* 39 */   public static String SCR_LOGGER_NAME = "org.apache.felix.scr.impl";
/* 40 */   public static String SCR_LOGGER_PREFIX = "org.apache.felix.scr.";
/*    */   
/*    */   private final Bundle bundle;
/*    */   
/*    */   ExtLogManager(BundleContext context, LogConfiguration config) {
/* 45 */     super(context, config);
/* 46 */     this.bundle = context.getBundle();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public ScrLogger scr() {
/* 53 */     return getLogger(this.bundle, SCR_LOGGER_NAME, (Class)ScrLogManager.ScrLoggerFacade.class);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public BundleLogger bundle(Bundle bundle) {
/* 61 */     return getLogger(this.bundle, SCR_LOGGER_PREFIX.concat(bundle.getSymbolicName()), (Class)ScrLogManager.ScrLoggerFacade.class);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public ComponentLogger component(Bundle bundle, String implementationClass, String componentName) {
/* 70 */     assert bundle != null;
/* 71 */     assert bundle.getSymbolicName() != null : "scr requires recent bundles";
/* 72 */     assert implementationClass != null;
/* 73 */     assert componentName != null;
/*    */ 
/*    */     
/* 76 */     String loggerName = SCR_LOGGER_PREFIX.concat(bundle.getSymbolicName()).concat(".").concat(componentName);
/*    */ 
/*    */ 
/*    */     
/* 80 */     ScrLogManager.ScrLoggerFacade logger = getLogger(this.bundle, loggerName, ScrLogManager.ScrLoggerFacade.class);
/* 81 */     logger.setPrefix("[" + componentName + "]");
/* 82 */     return logger;
/*    */   }
/*    */ 
/*    */   
/*    */   String componentPrefix(ScrLogManager.ScrLoggerFacade slf, long id) {
/* 87 */     assert slf.prefix != null;
/* 88 */     if (slf.prefix.indexOf(')') < 0) {
/* 89 */       return slf.prefix.replace("]", "(" + id + ")]");
/*    */     }
/* 91 */     return slf.prefix;
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.apache.felix.scr-2.2.6.jar!\org\apache\felix\scr\impl\logger\ExtLogManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */