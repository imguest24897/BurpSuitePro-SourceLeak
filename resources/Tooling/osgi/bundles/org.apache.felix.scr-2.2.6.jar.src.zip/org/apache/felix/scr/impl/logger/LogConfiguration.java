package org.apache.felix.scr.impl.logger;

public interface LogConfiguration {
  public static final String PROP_LOGLEVEL = "ds.loglevel";
  
  public static final String PROP_LOG_ENABLED = "ds.log.enabled";
  
  public static final String PROP_LOG_EXTENSION = "ds.log.extension";
  
  InternalLogger.Level getLogLevel();
  
  boolean isLogEnabled();
  
  boolean isLogExtensionEnabled();
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.apache.felix.scr-2.2.6.jar!\org\apache\felix\scr\impl\logger\LogConfiguration.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */