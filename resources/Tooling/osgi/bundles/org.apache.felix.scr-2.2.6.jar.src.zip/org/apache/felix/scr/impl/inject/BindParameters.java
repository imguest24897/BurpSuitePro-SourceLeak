/*    */ package org.apache.felix.scr.impl.inject;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class BindParameters
/*    */   extends BaseParameter
/*    */ {
/*    */   private final RefPair<?, ?> refPair;
/*    */   
/*    */   public BindParameters(ScrComponentContext componentContext, RefPair<?, ?> refPair) {
/* 28 */     super(componentContext);
/* 29 */     this.refPair = refPair;
/*    */   }
/*    */ 
/*    */   
/*    */   public RefPair<?, ?> getRefPair() {
/* 34 */     return this.refPair;
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.apache.felix.scr-2.2.6.jar!\org\apache\felix\scr\impl\inject\BindParameters.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */