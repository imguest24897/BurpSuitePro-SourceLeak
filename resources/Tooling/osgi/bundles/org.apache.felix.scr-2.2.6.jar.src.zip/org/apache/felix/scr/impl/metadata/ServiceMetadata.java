/*     */ package org.apache.felix.scr.impl.metadata;
/*     */ 
/*     */ import java.io.DataInputStream;
/*     */ import java.io.DataOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ServiceMetadata
/*     */ {
/*     */   private Boolean m_serviceFactory;
/*     */   private String m_scopeName;
/*     */   
/*     */   public enum Scope
/*     */   {
/*  40 */     singleton, bundle, prototype;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  46 */   private Scope m_scope = Scope.singleton;
/*     */ 
/*     */   
/*  49 */   private List<String> m_provides = new ArrayList<>();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean m_validated = false;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setServiceFactory(boolean serviceFactory) {
/*  60 */     if (this.m_validated) {
/*     */       return;
/*     */     }
/*     */     
/*  64 */     this.m_serviceFactory = Boolean.valueOf(serviceFactory);
/*     */   }
/*     */   
/*     */   public void setScope(String scopeName) {
/*  68 */     if (this.m_validated) {
/*     */       return;
/*     */     }
/*  71 */     this.m_scopeName = scopeName;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Scope getScope() {
/*  77 */     return this.m_scope;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addProvide(String provide) {
/*  86 */     if (this.m_validated) {
/*     */       return;
/*     */     }
/*     */     
/*  90 */     this.m_provides.add(provide);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String[] getProvides() {
/*  99 */     return this.m_provides.<String>toArray(new String[this.m_provides.size()]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void validate(ComponentMetadata componentMetadata) {
/* 108 */     if (this.m_provides.size() == 0)
/*     */     {
/* 110 */       throw componentMetadata
/* 111 */         .validationFailure("At least one provided interface must be declared in the service element");
/*     */     }
/* 113 */     for (String provide : this.m_provides) {
/*     */       
/* 115 */       if (provide == null)
/*     */       {
/* 117 */         throw componentMetadata
/* 118 */           .validationFailure("Null provides.  Possibly service is not specified as value of attribute 'interface'");
/*     */       }
/*     */     } 
/* 121 */     if (this.m_serviceFactory != null) {
/*     */       
/* 123 */       if (componentMetadata.getDSVersion().isDS13())
/*     */       {
/* 125 */         throw componentMetadata.validationFailure("service-factory can only be specified in version 1.2 and earlier");
/*     */       }
/* 127 */       this.m_scope = this.m_serviceFactory.booleanValue() ? Scope.bundle : Scope.singleton;
/*     */     } 
/* 129 */     if (this.m_scopeName != null) {
/*     */       
/* 131 */       if (!componentMetadata.getDSVersion().isDS13())
/*     */       {
/* 133 */         throw componentMetadata.validationFailure("service scope can only be specified in version 1.3 and later");
/*     */       }
/*     */       
/*     */       try {
/* 137 */         this.m_scope = Scope.valueOf(this.m_scopeName);
/*     */       }
/* 139 */       catch (IllegalArgumentException e) {
/*     */         
/* 141 */         throw componentMetadata.validationFailure("Service scope may be only 'singleton' 'bundle' or 'prototype' not " + this.m_scopeName);
/*     */       } 
/*     */     } 
/* 144 */     this.m_validated = true;
/*     */   }
/*     */ 
/*     */   
/*     */   void collectStrings(Set<String> strings) {
/* 149 */     for (String s : this.m_provides)
/*     */     {
/* 151 */       MetadataStoreHelper.addString(s, strings);
/*     */     }
/* 153 */     MetadataStoreHelper.addString(this.m_scopeName, strings);
/* 154 */     MetadataStoreHelper.addString(this.m_scope.toString(), strings);
/*     */   }
/*     */ 
/*     */   
/*     */   void store(DataOutputStream out, MetadataStoreHelper.MetaDataWriter metaDataWriter) throws IOException {
/* 159 */     out.writeInt(this.m_provides.size());
/* 160 */     for (String s : this.m_provides)
/*     */     {
/* 162 */       metaDataWriter.writeString(s, out);
/*     */     }
/* 164 */     metaDataWriter.writeString(this.m_scopeName, out);
/* 165 */     metaDataWriter.writeString(this.m_scope.toString(), out);
/* 166 */     out.writeBoolean((this.m_serviceFactory != null));
/* 167 */     if (this.m_serviceFactory != null)
/*     */     {
/* 169 */       out.writeBoolean(this.m_serviceFactory.booleanValue());
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   static ServiceMetadata load(DataInputStream in, MetadataStoreHelper.MetaDataReader metaDataReader) throws IOException {
/* 176 */     ServiceMetadata result = new ServiceMetadata();
/* 177 */     int providerSize = in.readInt();
/* 178 */     for (int i = 0; i < providerSize; i++)
/*     */     {
/* 180 */       result.addProvide(metaDataReader.readString(in));
/*     */     }
/* 182 */     result.m_scopeName = metaDataReader.readString(in);
/* 183 */     result.m_scope = Scope.valueOf(metaDataReader.readString(in));
/* 184 */     if (in.readBoolean())
/*     */     {
/* 186 */       result.m_serviceFactory = Boolean.valueOf(in.readBoolean());
/*     */     }
/*     */     
/* 189 */     result.m_validated = true;
/* 190 */     return result;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.apache.felix.scr-2.2.6.jar!\org\apache\felix\scr\impl\metadata\ServiceMetadata.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */