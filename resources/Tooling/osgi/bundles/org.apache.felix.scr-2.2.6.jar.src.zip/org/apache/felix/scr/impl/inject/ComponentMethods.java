package org.apache.felix.scr.impl.inject;

import org.apache.felix.scr.impl.logger.ComponentLogger;
import org.apache.felix.scr.impl.metadata.ComponentMetadata;

public interface ComponentMethods<T> {
  void initComponentMethods(ComponentMetadata paramComponentMetadata, Class<T> paramClass, ComponentLogger paramComponentLogger);
  
  ComponentConstructor<T> getConstructor();
  
  LifecycleMethod getActivateMethod();
  
  LifecycleMethod getDeactivateMethod();
  
  LifecycleMethod getModifiedMethod();
  
  ReferenceMethods getBindMethods(String paramString);
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.apache.felix.scr-2.2.6.jar!\org\apache\felix\scr\impl\inject\ComponentMethods.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */