/*    */ package org.apache.felix.scr.impl.config;
/*    */ 
/*    */ import org.osgi.framework.Bundle;
/*    */ import org.osgi.framework.ServiceFactory;
/*    */ import org.osgi.framework.ServiceRegistration;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ScrManagedServiceServiceFactory
/*    */   implements ServiceFactory
/*    */ {
/*    */   private final ScrConfigurationImpl scrConfiguration;
/*    */   
/*    */   public ScrManagedServiceServiceFactory(ScrConfigurationImpl scrConfiguration) {
/* 41 */     this.scrConfiguration = scrConfiguration;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public Object getService(Bundle bundle, ServiceRegistration registration) {
/* 47 */     return new ScrManagedService(this.scrConfiguration);
/*    */   }
/*    */   
/*    */   public void ungetService(Bundle bundle, ServiceRegistration registration, Object service) {}
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.apache.felix.scr-2.2.6.jar!\org\apache\felix\scr\impl\config\ScrManagedServiceServiceFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */