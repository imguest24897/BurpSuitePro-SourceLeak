/*     */ package org.apache.felix.scr.impl.config;
/*     */ 
/*     */ import java.io.InputStream;
/*     */ import java.util.ArrayList;
/*     */ import org.apache.felix.scr.impl.manager.ScrConfiguration;
/*     */ import org.osgi.service.metatype.AttributeDefinition;
/*     */ import org.osgi.service.metatype.MetaTypeProvider;
/*     */ import org.osgi.service.metatype.ObjectClassDefinition;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class ScrMetaTypeProvider
/*     */   implements MetaTypeProvider
/*     */ {
/*     */   private final ScrConfiguration configuration;
/*     */   
/*     */   public ScrMetaTypeProvider(ScrConfiguration scrConfiguration) {
/*  49 */     this.configuration = scrConfiguration;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String[] getLocales() {
/*  58 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ObjectClassDefinition getObjectClassDefinition(String id, String locale) {
/*  67 */     if (!"org.apache.felix.scr.ScrService".equals(id))
/*     */     {
/*  69 */       return null;
/*     */     }
/*     */     
/*  72 */     final ArrayList<AttributeDefinition> adList = new ArrayList<>();
/*     */     
/*  74 */     adList.add(new AttributeDefinitionImpl("ds.loglevel", "SCR Log Level", "Allows limiting the amount of logging information sent to the OSGi LogService. Supported values are DEBUG, INFO, WARN, and ERROR. This property is not used if a R7 LogService implementation is available as the log level can be configured through that service. Default is ERROR.", 3, new String[] {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */             
/*  80 */             String.valueOf(this.configuration.getLogLevel()) }, 0, new String[] { "Debug", "Information", "Warnings", "Error" }, new String[] { "4", "3", "2", "1" }));
/*     */ 
/*     */ 
/*     */     
/*  84 */     adList
/*  85 */       .add(new AttributeDefinitionImpl("ds.factory.enabled", "Extended Factory Components", "Whether or not to enable the support for creating Factory Component instances based on factory configuration. This is an Apache Felix SCR specific extension, explicitly not supported by the Declarative Services specification. Reliance on this feature prevent the component from being used with other Declarative Services implementations. The default value is false to disable this feature.", this.configuration
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/*  92 */           .isFactoryEnabled()));
/*     */     
/*  94 */     adList.add(new AttributeDefinitionImpl("ds.delayed.keepInstances", "Keep Component Instances", "Whether or not to keep instances of delayed components once they are not referred to any more. The Declarative Services specifications suggests that instances of delayed components are disposed off if there is not used any longer. Setting this flag causes the components to not be disposed off and thus prevent them from being constantly recreated if often used. Examples of such components may be EventHandler services. The default is to dispose of unused components.", this.configuration
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 102 */           .keepInstances()));
/*     */     
/* 104 */     adList.add(new AttributeDefinitionImpl("ds.lock.timeout.milliseconds", "Lock timeout milliseconds", "How long a lock is held before releasing due to suspected deadlock", 2, new String[] {
/*     */ 
/*     */ 
/*     */ 
/*     */             
/* 109 */             String.valueOf(this.configuration.lockTimeout()) }, 0, null, null));
/*     */ 
/*     */     
/* 112 */     adList.add(new AttributeDefinitionImpl("ds.stop.timeout.milliseconds", "Stop timeout milliseconds", "How long stopping a bundle is waited for before continuing due to suspected deadlock", 2, new String[] {
/*     */ 
/*     */ 
/*     */ 
/*     */             
/* 117 */             String.valueOf(this.configuration.stopTimeout()) }, 0, null, null));
/*     */ 
/*     */     
/* 120 */     adList.add(new AttributeDefinitionImpl("ds.global.extender", "Global Extender", "Whether to extend all bundles whether or not visible to this bundle.", false));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 126 */     return new ObjectClassDefinition()
/*     */       {
/*     */         
/* 129 */         private final AttributeDefinition[] attrs = (AttributeDefinition[])adList
/* 130 */           .toArray((Object[])new AttributeDefinition[adList.size()]);
/*     */ 
/*     */ 
/*     */         
/*     */         public String getName() {
/* 135 */           return "Apache Felix Declarative Service Implementation";
/*     */         }
/*     */ 
/*     */ 
/*     */         
/*     */         public InputStream getIcon(int arg0) {
/* 141 */           return null;
/*     */         }
/*     */ 
/*     */ 
/*     */         
/*     */         public String getID() {
/* 147 */           return "org.apache.felix.scr.ScrService";
/*     */         }
/*     */ 
/*     */ 
/*     */         
/*     */         public String getDescription() {
/* 153 */           return "Configuration for the Apache Felix Declarative Services Implementation. This configuration overwrites configuration defined in framework properties of the same names.";
/*     */         }
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         public AttributeDefinition[] getAttributeDefinitions(int filter) {
/* 160 */           return (filter == 2) ? null : this.attrs;
/*     */         }
/*     */       };
/*     */   }
/*     */ 
/*     */   
/*     */   private static class AttributeDefinitionImpl
/*     */     implements AttributeDefinition
/*     */   {
/*     */     private final String id;
/*     */     
/*     */     private final String name;
/*     */     private final String description;
/*     */     private final int type;
/*     */     private final String[] defaultValues;
/*     */     private final int cardinality;
/*     */     private final String[] optionLabels;
/*     */     private final String[] optionValues;
/*     */     
/*     */     AttributeDefinitionImpl(String id, String name, String description, boolean defaultValue) {
/* 180 */       this(id, name, description, 11, new String[] {
/* 181 */             String.valueOf(defaultValue) }, 0, null, null);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     AttributeDefinitionImpl(String id, String name, String description, int type, String[] defaultValues, int cardinality, String[] optionLabels, String[] optionValues) {
/* 188 */       this.id = id;
/* 189 */       this.name = name;
/* 190 */       this.description = description;
/* 191 */       this.type = type;
/* 192 */       this.defaultValues = defaultValues;
/* 193 */       this.cardinality = cardinality;
/* 194 */       this.optionLabels = optionLabels;
/* 195 */       this.optionValues = optionValues;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public int getCardinality() {
/* 202 */       return this.cardinality;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public String[] getDefaultValue() {
/* 209 */       return this.defaultValues;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public String getDescription() {
/* 216 */       return this.description;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public String getID() {
/* 223 */       return this.id;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public String getName() {
/* 230 */       return this.name;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public String[] getOptionLabels() {
/* 237 */       return this.optionLabels;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public String[] getOptionValues() {
/* 244 */       return this.optionValues;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public int getType() {
/* 251 */       return this.type;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public String validate(String arg0) {
/* 258 */       return null;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.apache.felix.scr-2.2.6.jar!\org\apache\felix\scr\impl\config\ScrMetaTypeProvider.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */