/*    */ package org.apache.felix.scr.impl.config;
/*    */ 
/*    */ import org.apache.felix.scr.impl.manager.ScrConfiguration;
/*    */ import org.osgi.framework.Bundle;
/*    */ import org.osgi.framework.ServiceFactory;
/*    */ import org.osgi.framework.ServiceRegistration;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ScrMetaTypeProviderServiceFactory
/*    */   implements ServiceFactory
/*    */ {
/*    */   private final ScrConfiguration scrConfiguration;
/*    */   
/*    */   public ScrMetaTypeProviderServiceFactory(ScrConfiguration scrConfiguration) {
/* 42 */     this.scrConfiguration = scrConfiguration;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public Object getService(Bundle bundle, ServiceRegistration registration) {
/* 48 */     return new ScrMetaTypeProvider(this.scrConfiguration);
/*    */   }
/*    */   
/*    */   public void ungetService(Bundle bundle, ServiceRegistration registration, Object service) {}
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.apache.felix.scr-2.2.6.jar!\org\apache\felix\scr\impl\config\ScrMetaTypeProviderServiceFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */