/*     */ package org.apache.felix.scr.impl.manager;
/*     */ 
/*     */ import java.util.Collection;
/*     */ import java.util.Map;
/*     */ import org.apache.felix.scr.impl.inject.RefPair;
/*     */ import org.apache.felix.scr.impl.inject.ScrComponentContext;
/*     */ import org.apache.felix.scr.impl.logger.InternalLogger;
/*     */ import org.osgi.framework.BundleContext;
/*     */ import org.osgi.framework.ServiceReference;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractPrototypeRefPair<S, T>
/*     */   extends RefPair<S, T>
/*     */ {
/*     */   public AbstractPrototypeRefPair(ServiceReference<T> ref) {
/*  40 */     super(ref);
/*     */   }
/*     */ 
/*     */   
/*     */   public abstract T getServiceObject(ScrComponentContext paramScrComponentContext);
/*     */ 
/*     */   
/*     */   public abstract boolean setServiceObject(ScrComponentContext paramScrComponentContext, T paramT);
/*     */ 
/*     */   
/*     */   protected abstract T remove(ScrComponentContext paramScrComponentContext);
/*     */ 
/*     */   
/*     */   protected abstract Collection<Map.Entry<ScrComponentContext, T>> clearEntries();
/*     */   
/*     */   public final T ungetServiceObject(ScrComponentContext key) {
/*  56 */     if (key == null) {
/*     */       
/*  58 */       Collection<Map.Entry<ScrComponentContext, T>> keys = clearEntries();
/*  59 */       for (Map.Entry<ScrComponentContext, T> e : keys)
/*     */       {
/*  61 */         doUngetService(e.getKey(), e.getValue());
/*     */       }
/*  63 */       return null;
/*     */     } 
/*  65 */     T service = remove(key);
/*  66 */     if (service != null) {
/*  67 */       doUngetService(key, service);
/*     */     }
/*  69 */     return service;
/*     */   }
/*     */ 
/*     */   
/*     */   public final void ungetServiceObjects(BundleContext bundleContext) {
/*  74 */     ungetServiceObject((ScrComponentContext)null);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract String toString();
/*     */ 
/*     */   
/*     */   public final boolean getServiceObject(ScrComponentContext key, BundleContext context) {
/*  83 */     T service = (T)key.getComponentServiceObjectsHelper().getPrototypeRefInstance(getRef());
/*  84 */     if (service == null) {
/*     */       
/*  86 */       markFailed();
/*  87 */       key.getLogger().log(InternalLogger.Level.WARN, "Could not get service from serviceobjects for ref {0}", null, new Object[] {
/*     */             
/*  89 */             getRef() });
/*  90 */       return false;
/*     */     } 
/*  92 */     if (!setServiceObject(key, service))
/*     */     {
/*     */       
/*  95 */       doUngetService(key, service);
/*     */     }
/*  97 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   private void doUngetService(ScrComponentContext key, T service) {
/*     */     try {
/* 103 */       key.getComponentServiceObjectsHelper().getServiceObjects(getRef()).ungetService(service);
/*     */     }
/* 105 */     catch (IllegalStateException illegalStateException) {}
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.apache.felix.scr-2.2.6.jar!\org\apache\felix\scr\impl\manager\AbstractPrototypeRefPair.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */