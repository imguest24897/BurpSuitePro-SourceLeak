/*     */ package org.apache.felix.scr.impl.inject;
/*     */ 
/*     */ import java.lang.reflect.Field;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Modifier;
/*     */ import java.util.Map;
/*     */ import java.util.Optional;
/*     */ import org.apache.felix.scr.impl.helper.ReadOnlyDictionary;
/*     */ import org.apache.felix.scr.impl.inject.internal.Annotations;
/*     */ import org.apache.felix.scr.impl.inject.internal.ClassUtils;
/*     */ import org.apache.felix.scr.impl.logger.ComponentLogger;
/*     */ import org.apache.felix.scr.impl.logger.InternalLogger;
/*     */ import org.apache.felix.scr.impl.metadata.ReferenceMetadata;
/*     */ import org.osgi.framework.Bundle;
/*     */ import org.osgi.framework.ServiceReference;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ValueUtils
/*     */ {
/*     */   public enum ValueType
/*     */   {
/*  47 */     ignore,
/*  48 */     componentContext,
/*  49 */     bundleContext,
/*  50 */     config_map,
/*  51 */     config_annotation,
/*  52 */     ref_logger,
/*  53 */     ref_formatterLogger,
/*  54 */     ref_serviceReference,
/*  55 */     ref_serviceObjects,
/*  56 */     ref_serviceType,
/*  57 */     ref_map,
/*  58 */     ref_tuple,
/*  59 */     ref_optional;
/*     */   }
/*     */ 
/*     */   
/*  63 */   public static final ValueType[] EMPTY_VALUE_TYPES = new ValueType[0];
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ValueType getValueType(Class<?> typeClass) {
/*  74 */     if (typeClass == ClassUtils.COMPONENT_CONTEXT_CLASS)
/*     */     {
/*  76 */       return ValueType.componentContext;
/*     */     }
/*  78 */     if (typeClass == ClassUtils.BUNDLE_CONTEXT_CLASS)
/*     */     {
/*  80 */       return ValueType.bundleContext;
/*     */     }
/*  82 */     if (typeClass == ClassUtils.MAP_CLASS)
/*     */     {
/*  84 */       return ValueType.config_map;
/*     */     }
/*  86 */     if (typeClass.isAnnotation())
/*     */     {
/*  88 */       return ValueType.config_annotation;
/*     */     }
/*  90 */     return ValueType.ignore;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ValueType getReferenceValueType(Class<?> componentClass, ReferenceMetadata metadata, Class<?> typeClass, Field field, ComponentLogger logger) {
/* 110 */     Class<?> referenceType = ClassUtils.getClassFromComponentClassLoader(componentClass, metadata
/* 111 */         .getInterface(), logger);
/*     */     
/* 113 */     ValueType valueType = ValueType.ignore;
/*     */ 
/*     */     
/* 116 */     if (!metadata.isMultiple()) {
/*     */ 
/*     */       
/* 119 */       if (typeClass.isAssignableFrom(referenceType)) {
/*     */         
/* 121 */         valueType = ValueType.ref_serviceType;
/*     */       
/*     */       }
/* 124 */       else if (typeClass == ClassUtils.SERVICE_REFERENCE_CLASS) {
/*     */         
/* 126 */         valueType = ValueType.ref_serviceReference;
/*     */       
/*     */       }
/* 129 */       else if (typeClass == ClassUtils.COMPONENTS_SERVICE_OBJECTS_CLASS) {
/*     */         
/* 131 */         valueType = ValueType.ref_serviceObjects;
/*     */       
/*     */       }
/* 134 */       else if (typeClass == ClassUtils.MAP_CLASS) {
/*     */         
/* 136 */         valueType = ValueType.ref_map;
/*     */       
/*     */       }
/* 139 */       else if (typeClass == ClassUtils.MAP_ENTRY_CLASS) {
/*     */         
/* 141 */         valueType = ValueType.ref_tuple;
/*     */       } else {
/*     */         
/* 144 */         if (typeClass.getName().equals("org.osgi.service.log.Logger") && metadata.getInterface().equals("org.osgi.service.log.LoggerFactory"))
/*     */         {
/* 146 */           return ValueType.ref_logger;
/*     */         }
/*     */         
/* 149 */         if (typeClass.getName().equals("org.osgi.service.log.FormatterLogger") && metadata.getInterface().equals("org.osgi.service.log.LoggerFactory"))
/*     */         {
/* 151 */           return ValueType.ref_formatterLogger;
/*     */         }
/*     */         
/* 154 */         if (typeClass == ClassUtils.OPTIONAL_CLASS) {
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 159 */           valueType = ValueType.ref_optional;
/*     */         }
/*     */         else {
/*     */           
/* 163 */           if (field != null) {
/*     */             
/* 165 */             logger.log(InternalLogger.Level.ERROR, "Field {0} in class {1} has unsupported type {2}", null, new Object[] { metadata
/*     */                   
/* 167 */                   .getField(), componentClass, typeClass.getName() });
/*     */           }
/*     */           else {
/*     */             
/* 171 */             logger.log(InternalLogger.Level.ERROR, "Constructor argument {0} in class {1} has unsupported type {2}", null, new Object[] { metadata
/*     */ 
/*     */                   
/* 174 */                   .getParameterIndex(), componentClass, typeClass.getName() });
/*     */           } 
/* 176 */           valueType = ValueType.ignore;
/*     */         } 
/*     */       } 
/*     */       
/* 180 */       if (field != null && !metadata.isStatic() && !Modifier.isVolatile(field.getModifiers())) {
/* 181 */         logger.log(InternalLogger.Level.ERROR, "Field {0} in class {1} must be declared volatile to handle a dynamic reference", null, new Object[] { metadata
/*     */ 
/*     */               
/* 184 */               .getField(), componentClass });
/* 185 */         valueType = ValueType.ignore;
/*     */       } 
/*     */ 
/*     */       
/* 189 */       if (field != null && Modifier.isFinal(field.getModifiers()))
/*     */       {
/* 191 */         logger.log(InternalLogger.Level.ERROR, "Field {0} in class {1} must not be declared as final", null, new Object[] { metadata
/*     */               
/* 193 */               .getField(), componentClass });
/* 194 */         valueType = ValueType.ignore;
/*     */       }
/*     */     
/*     */     } else {
/*     */       
/* 199 */       String colType = metadata.getCollectionType();
/* 200 */       valueType = getCollectionValueType(colType);
/*     */ 
/*     */       
/* 203 */       if (!ClassUtils.COLLECTION_CLASS.isAssignableFrom(typeClass)) {
/*     */         
/* 205 */         if (field != null) {
/*     */           
/* 207 */           logger.log(InternalLogger.Level.ERROR, "Field {0} in class {1} has unsupported type {2}", null, new Object[] { metadata
/*     */                 
/* 209 */                 .getField(), componentClass, typeClass.getName() });
/*     */         }
/*     */         else {
/*     */           
/* 213 */           logger.log(InternalLogger.Level.ERROR, "Constructor argument {0} in class {1} has unsupported type {2}", null, new Object[] { metadata
/*     */ 
/*     */                 
/* 216 */                 .getParameterIndex(), componentClass, typeClass.getName() });
/*     */         } 
/* 218 */         valueType = ValueType.ignore;
/*     */       } 
/*     */ 
/*     */       
/* 222 */       if (metadata.isReplace() && field != null) {
/*     */ 
/*     */         
/* 225 */         if (!metadata.isStatic() && !Modifier.isVolatile(field.getModifiers())) {
/*     */           
/* 227 */           logger.log(InternalLogger.Level.ERROR, "Field {0} in class {1} must be declared volatile to handle a dynamic reference", null, new Object[] { metadata
/*     */ 
/*     */                 
/* 230 */                 .getField(), componentClass });
/* 231 */           valueType = ValueType.ignore;
/*     */         } 
/*     */ 
/*     */ 
/*     */         
/* 236 */         if (typeClass != ClassUtils.LIST_CLASS && typeClass != ClassUtils.COLLECTION_CLASS) {
/*     */           
/* 238 */           logger.log(InternalLogger.Level.ERROR, "Field {0} in class {1} has unsupported type {2}. It must be one of java.util.Collection or java.util.List.", null, new Object[] { metadata
/*     */ 
/*     */                 
/* 241 */                 .getField(), componentClass, typeClass.getName() });
/* 242 */           valueType = ValueType.ignore;
/*     */         } 
/*     */         
/* 245 */         if (Modifier.isFinal(field.getModifiers())) {
/*     */           
/* 247 */           logger.log(InternalLogger.Level.ERROR, "Field {0} in class {1} must not be declared as final", null, new Object[] { metadata
/*     */                 
/* 249 */                 .getField(), componentClass });
/* 250 */           valueType = ValueType.ignore;
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 255 */     if (field != null && metadata.isStatic() && !metadata.isReplace()) {
/*     */       
/* 257 */       logger.log(InternalLogger.Level.ERROR, "Update strategy for field {0} in class {1} only allowed for non static field references.", null, new Object[] { metadata
/*     */ 
/*     */             
/* 260 */             .getField(), componentClass });
/* 261 */       valueType = ValueType.ignore;
/*     */     } 
/* 263 */     return valueType;
/*     */   }
/*     */ 
/*     */   
/*     */   public static ValueType getCollectionValueType(String colType) {
/* 268 */     if (colType == null)
/*     */     {
/* 270 */       return ValueType.ref_serviceType;
/*     */     }
/* 272 */     switch (colType) {
/*     */       
/*     */       case "service":
/* 275 */         return ValueType.ref_serviceType;
/*     */       case "reference":
/* 277 */         return ValueType.ref_serviceReference;
/*     */       case "serviceobjects":
/* 279 */         return ValueType.ref_serviceObjects;
/*     */       case "properties":
/* 281 */         return ValueType.ref_map;
/*     */       case "tuple":
/* 283 */         return ValueType.ref_tuple;
/*     */     } 
/* 285 */     return ValueType.ignore;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Object getValue(String componentType, ValueType type, Class<?> targetType, ScrComponentContext componentContext, RefPair<?, ?> refPair, ReferenceMetadata referenceMetaData) {
/*     */     Object tupleKey;
/*     */     Object tupleValue;
/*     */     String stringType;
/*     */     ValueType optionalValueType;
/*     */     Object value;
/* 307 */     switch (type) {
/*     */       
/*     */       case ignore:
/* 310 */         return null;
/*     */       case componentContext:
/* 312 */         return componentContext;
/*     */       case bundleContext:
/* 314 */         return componentContext.getBundleContext();
/*     */       
/*     */       case config_map:
/* 317 */         return componentContext.getProperties();
/*     */       case config_annotation:
/* 319 */         return Annotations.toObject(targetType, (Map)componentContext
/* 320 */             .getProperties(), componentContext
/* 321 */             .getBundleContext().getBundle(), componentContext
/* 322 */             .getComponentMetadata().isConfigureWithInterfaces());
/*     */       case ref_serviceType:
/* 324 */         return refPair.getServiceObject(componentContext);
/*     */       case ref_serviceReference:
/* 326 */         return refPair.getRef();
/*     */       case ref_serviceObjects:
/* 328 */         return componentContext.getComponentServiceObjectsHelper().getServiceObjects(refPair
/* 329 */             .getRef());
/*     */       case ref_map:
/* 331 */         return new ReadOnlyDictionary(refPair.getRef());
/*     */       case ref_tuple:
/* 333 */         tupleKey = new ReadOnlyDictionary(refPair.getRef());
/* 334 */         tupleValue = refPair.getServiceObject(componentContext);
/* 335 */         return new MapEntryImpl(tupleKey, tupleValue, refPair.getRef());
/*     */       case ref_logger:
/*     */       case ref_formatterLogger:
/* 338 */         return getLogger(componentType, targetType, componentContext, refPair);
/*     */ 
/*     */       
/*     */       case ref_optional:
/* 342 */         stringType = (referenceMetaData == null) ? "service" : referenceMetaData.getCollectionType();
/* 343 */         optionalValueType = getCollectionValueType(stringType);
/* 344 */         value = getValue(componentType, optionalValueType, targetType, componentContext, refPair, referenceMetaData);
/*     */         
/* 346 */         return Optional.ofNullable(value);
/*     */     } 
/* 348 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static Object getLogger(String componentType, Class<?> targetType, ScrComponentContext componentContext, RefPair<?, ?> refPair) {
/* 357 */     Object factory = refPair.getServiceObject(componentContext);
/* 358 */     if (factory != null) {
/*     */       
/* 360 */       Exception error = null;
/*     */       try {
/* 362 */         Method m = factory.getClass().getMethod("getLogger", new Class[] { Bundle.class, String.class, Class.class });
/*     */         
/* 364 */         m.setAccessible(true);
/* 365 */         return m.invoke(factory, new Object[] { componentContext.getBundleContext().getBundle(), componentType, targetType });
/* 366 */       } catch (NoSuchMethodException|SecurityException|IllegalAccessException|IllegalArgumentException|java.lang.reflect.InvocationTargetException e) {
/* 367 */         error = e;
/*     */         
/* 369 */         componentContext.getLogger().log(InternalLogger.Level.ERROR, "Unexpected error while trying to get logger.", null, new Object[] { error });
/*     */       } 
/*     */     } 
/* 372 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static final class MapEntryImpl
/*     */     implements Map.Entry, Comparable<Map.Entry<?, ?>>
/*     */   {
/*     */     private final Object key;
/*     */ 
/*     */     
/*     */     private final Object value;
/*     */ 
/*     */     
/*     */     private final ServiceReference<?> ref;
/*     */ 
/*     */     
/*     */     public MapEntryImpl(Object key, Object value, ServiceReference<?> ref) {
/* 390 */       this.key = key;
/* 391 */       this.value = value;
/* 392 */       this.ref = ref;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public Object getKey() {
/* 398 */       return this.key;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public Object getValue() {
/* 404 */       return this.value;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public Object setValue(Object value) {
/* 410 */       throw new UnsupportedOperationException();
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public int compareTo(Map.Entry<?, ?> o) {
/* 416 */       if (o == null)
/*     */       {
/* 418 */         return 1;
/*     */       }
/* 420 */       if (o instanceof MapEntryImpl) {
/*     */         
/* 422 */         MapEntryImpl other = (MapEntryImpl)o;
/* 423 */         return this.ref.compareTo(other.ref);
/*     */       } 
/*     */       
/* 426 */       return (new Integer(hashCode())).compareTo(Integer.valueOf(o.hashCode()));
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.apache.felix.scr-2.2.6.jar!\org\apache\felix\scr\impl\inject\ValueUtils.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */