/*    */ package org.apache.felix.scr.impl.inject;
/*    */ 
/*    */ import org.osgi.framework.BundleContext;
/*    */ import org.osgi.framework.ServiceReference;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class RefPair<S, T>
/*    */ {
/*    */   private final ServiceReference<T> ref;
/*    */   volatile boolean failed;
/*    */   volatile boolean deleted;
/*    */   
/*    */   public RefPair(ServiceReference<T> ref) {
/* 36 */     this.ref = ref;
/*    */   }
/*    */ 
/*    */   
/*    */   public ServiceReference<T> getRef() {
/* 41 */     return this.ref;
/*    */   }
/*    */ 
/*    */   
/*    */   public abstract boolean getServiceObject(ScrComponentContext paramScrComponentContext, BundleContext paramBundleContext);
/*    */   
/*    */   public abstract T getServiceObject(ScrComponentContext paramScrComponentContext);
/*    */   
/*    */   public abstract boolean setServiceObject(ScrComponentContext paramScrComponentContext, T paramT);
/*    */   
/*    */   public abstract void ungetServiceObjects(BundleContext paramBundleContext);
/*    */   
/*    */   public abstract T ungetServiceObject(ScrComponentContext paramScrComponentContext);
/*    */   
/*    */   public void markFailed() {
/* 56 */     this.failed = true;
/*    */   }
/*    */   
/*    */   public void clearFailed() {
/* 60 */     this.failed = false;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean isFailed() {
/* 65 */     return this.failed;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean isDeleted() {
/* 70 */     return this.deleted;
/*    */   }
/*    */ 
/*    */   
/*    */   public void markDeleted() {
/* 75 */     this.deleted = true;
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.apache.felix.scr-2.2.6.jar!\org\apache\felix\scr\impl\inject\RefPair.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */