/*     */ package org.apache.felix.scr.impl.manager;
/*     */ 
/*     */ import java.util.concurrent.atomic.AtomicReference;
/*     */ import org.apache.felix.scr.impl.inject.RefPair;
/*     */ import org.apache.felix.scr.impl.inject.ScrComponentContext;
/*     */ import org.apache.felix.scr.impl.logger.InternalLogger;
/*     */ import org.osgi.framework.BundleContext;
/*     */ import org.osgi.framework.ServiceReference;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SingleRefPair<S, T>
/*     */   extends RefPair<S, T>
/*     */ {
/*  36 */   private final AtomicReference<T> serviceObjectRef = new AtomicReference<>();
/*     */ 
/*     */   
/*     */   public SingleRefPair(ServiceReference<T> ref) {
/*  40 */     super(ref);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public T getServiceObject(ScrComponentContext key) {
/*  46 */     return this.serviceObjectRef.get();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean setServiceObject(ScrComponentContext key, T serviceObject) {
/*  52 */     boolean set = this.serviceObjectRef.compareAndSet(null, serviceObject);
/*  53 */     if (serviceObject != null)
/*     */     {
/*  55 */       clearFailed();
/*     */     }
/*  57 */     return set;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public T ungetServiceObject(ScrComponentContext key) {
/*  63 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void ungetServiceObjects(BundleContext bundleContext) {
/*  69 */     T service = this.serviceObjectRef.getAndSet(null);
/*  70 */     if (service != null)
/*     */     {
/*  72 */       if (bundleContext != null)
/*     */       {
/*  74 */         safeUngetService(bundleContext, getRef());
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/*  82 */     return "[RefPair: ref: [" + getRef() + "] service: [" + this.serviceObjectRef.get() + "]]";
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean getServiceObject(ScrComponentContext key, BundleContext context) {
/*  88 */     T service = (T)context.getService(getRef());
/*  89 */     if (service == null) {
/*     */       
/*  91 */       markFailed();
/*  92 */       key.getLogger().log(InternalLogger.Level.WARN, "Could not get service from ref {0}", null, new Object[] {
/*     */             
/*  94 */             getRef() });
/*  95 */       return false;
/*     */     } 
/*  97 */     if (!setServiceObject(key, service))
/*     */     {
/*     */       
/* 100 */       safeUngetService(context, getRef());
/*     */     }
/* 102 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static void safeUngetService(BundleContext context, ServiceReference<?> ref) {
/*     */     try {
/* 109 */       context.ungetService(ref);
/*     */     }
/* 111 */     catch (IllegalStateException illegalStateException) {}
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.apache.felix.scr-2.2.6.jar!\org\apache\felix\scr\impl\manager\SingleRefPair.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */