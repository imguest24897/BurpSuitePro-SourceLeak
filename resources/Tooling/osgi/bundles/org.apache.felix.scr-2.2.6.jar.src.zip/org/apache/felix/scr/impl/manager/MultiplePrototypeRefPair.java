/*    */ package org.apache.felix.scr.impl.manager;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.Collection;
/*    */ import java.util.Map;
/*    */ import java.util.concurrent.ConcurrentHashMap;
/*    */ import java.util.concurrent.ConcurrentMap;
/*    */ import org.apache.felix.scr.impl.inject.ScrComponentContext;
/*    */ import org.osgi.framework.ServiceReference;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MultiplePrototypeRefPair<S, T>
/*    */   extends AbstractPrototypeRefPair<S, T>
/*    */ {
/* 37 */   private final ConcurrentMap<ScrComponentContext, T> instances = new ConcurrentHashMap<>();
/*    */ 
/*    */   
/*    */   public MultiplePrototypeRefPair(ServiceReference<T> ref) {
/* 41 */     super(ref);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public String toString() {
/* 47 */     return "[MultiplePrototypeRefPair: ref: [" + getRef() + "] has service: [" + (!this.instances.isEmpty() ? 1 : 0) + "]]";
/*    */   }
/*    */ 
/*    */   
/*    */   public T getServiceObject(ScrComponentContext key) {
/* 52 */     return this.instances.get(key);
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean setServiceObject(ScrComponentContext key, T serviceObject) {
/* 57 */     return (this.instances.putIfAbsent(key, serviceObject) == null);
/*    */   }
/*    */ 
/*    */   
/*    */   protected T remove(ScrComponentContext key) {
/* 62 */     return this.instances.remove(key);
/*    */   }
/*    */ 
/*    */   
/*    */   protected Collection<Map.Entry<ScrComponentContext, T>> clearEntries() {
/* 67 */     Collection<Map.Entry<ScrComponentContext, T>> result = new ArrayList<>(this.instances.entrySet());
/* 68 */     this.instances.clear();
/* 69 */     return result;
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.apache.felix.scr-2.2.6.jar!\org\apache\felix\scr\impl\manager\MultiplePrototypeRefPair.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */