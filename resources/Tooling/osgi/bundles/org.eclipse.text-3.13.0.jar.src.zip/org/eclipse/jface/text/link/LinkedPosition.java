/*     */ package org.eclipse.jface.text.link;
/*     */ 
/*     */ import org.eclipse.core.runtime.Assert;
/*     */ import org.eclipse.jface.text.BadLocationException;
/*     */ import org.eclipse.jface.text.DocumentEvent;
/*     */ import org.eclipse.jface.text.IDocument;
/*     */ import org.eclipse.jface.text.Position;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LinkedPosition
/*     */   extends Position
/*     */ {
/*     */   private IDocument fDocument;
/*     */   private int fSequenceNumber;
/*     */   
/*     */   public LinkedPosition(IDocument document, int offset, int length, int sequence) {
/*  46 */     super(offset, length);
/*  47 */     Assert.isNotNull(document);
/*  48 */     this.fDocument = document;
/*  49 */     this.fSequenceNumber = sequence;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LinkedPosition(IDocument document, int offset, int length) {
/*  61 */     this(document, offset, length, -1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IDocument getDocument() {
/*  68 */     return this.fDocument;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object other) {
/*  73 */     if (other instanceof LinkedPosition) {
/*  74 */       LinkedPosition p = (LinkedPosition)other;
/*  75 */       return (p.offset == this.offset && p.length == this.length && p.fDocument == this.fDocument);
/*     */     } 
/*  77 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean overlapsWith(LinkedPosition position) {
/*  88 */     return (position.getDocument() == this.fDocument && overlapsWith(position.getOffset(), position.getLength()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean includes(DocumentEvent event) {
/*  99 */     return includes(event.getDocument(), event.getOffset(), event.getLength());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean includes(LinkedPosition position) {
/* 110 */     return includes(position.getDocument(), position.getOffset(), position.getLength());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean includes(int pOffset) {
/* 124 */     return (this.offset <= pOffset && pOffset <= this.offset + this.length);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean includes(IDocument doc, int off, int len) {
/* 142 */     return (doc == this.fDocument && off >= this.offset && len + off <= this.offset + this.length);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getContent() throws BadLocationException {
/* 153 */     return this.fDocument.get(this.offset, this.length);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getSequenceNumber() {
/* 162 */     return this.fSequenceNumber;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSequenceNumber(int sequence) {
/* 171 */     this.fSequenceNumber = sequence;
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 176 */     return this.fDocument.hashCode() | super.hashCode() | this.fSequenceNumber;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.text-3.13.0.jar!\org\eclipse\jface\text\link\LinkedPosition.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */