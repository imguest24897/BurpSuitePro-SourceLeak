/*     */ package org.eclipse.jface.text.templates;
/*     */ 
/*     */ import org.eclipse.core.runtime.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TemplateVariableResolver
/*     */ {
/*  31 */   private String fType = null;
/*     */ 
/*     */   
/*  34 */   private String fDescription = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected TemplateVariableResolver(String type, String description) {
/*  43 */     setType(type);
/*  44 */     setDescription(description);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TemplateVariableResolver() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getType() {
/*  65 */     return this.fType;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getDescription() {
/*  74 */     return this.fDescription;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String resolve(TemplateContext context) {
/*  88 */     return context.getVariable(getType());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String[] resolveAll(TemplateContext context) {
/* 101 */     String binding = resolve(context);
/* 102 */     if (binding == null)
/* 103 */       return new String[0]; 
/* 104 */     return new String[] { binding };
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void resolve(TemplateVariable variable, TemplateContext context) {
/* 117 */     String[] bindings = resolveAll(context);
/* 118 */     if (bindings.length != 0)
/* 119 */       variable.setValues(bindings); 
/* 120 */     if (bindings.length > 1) {
/* 121 */       variable.setUnambiguous(false);
/*     */     } else {
/* 123 */       variable.setUnambiguous(isUnambiguous(context));
/* 124 */     }  variable.setResolved(true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean isUnambiguous(TemplateContext context) {
/* 141 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void setDescription(String description) {
/* 155 */     Assert.isNotNull(description);
/* 156 */     Assert.isTrue((this.fDescription == null));
/* 157 */     this.fDescription = description;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void setType(String type) {
/* 171 */     Assert.isNotNull(type);
/* 172 */     Assert.isTrue((this.fType == null));
/* 173 */     this.fType = type;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.text-3.13.0.jar!\org\eclipse\jface\text\templates\TemplateVariableResolver.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */