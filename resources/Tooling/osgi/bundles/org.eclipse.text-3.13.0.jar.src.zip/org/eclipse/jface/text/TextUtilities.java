/*     */ package org.eclipse.jface.text;
/*     */ 
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.ListIterator;
/*     */ import java.util.Map;
/*     */ import java.util.Objects;
/*     */ import java.util.Set;
/*     */ import org.eclipse.core.runtime.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TextUtilities
/*     */ {
/*  45 */   public static final String[] DELIMITERS = new String[] { "\n", "\r", "\r\n" };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*  53 */   public static final String[] fgDelimiters = DELIMITERS;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String determineLineDelimiter(String text, String hint) {
/*  66 */     String delimiter = (nextDelimiter(text, 0)).delimiter;
/*  67 */     return (delimiter != null) ? delimiter : hint;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public static int[] indexOf(String[] searchStrings, String text, int offset) {
/*  99 */     Objects.requireNonNull(searchStrings); byte b; int i; String[] arrayOfString;
/* 100 */     for (i = (arrayOfString = searchStrings).length, b = 0; b < i; ) { String searchString = arrayOfString[b];
/* 101 */       Objects.requireNonNull(searchString); b++; }
/*     */     
/* 103 */     if (offset < 0) {
/* 104 */       offset = 0;
/*     */     }
/* 106 */     MultiStringMatcher.Match match = MultiStringMatcher.indexOf(text, offset, searchStrings);
/* 107 */     if (match != null) {
/* 108 */       for (int j = 0; j < searchStrings.length; j++) {
/* 109 */         if (match.getText().equals(searchStrings[j])) {
/* 110 */           return new int[] { match.getOffset(), j };
/*     */         }
/*     */       }
/*     */     
/*     */     } else {
/*     */       
/* 116 */       for (int j = searchStrings.length - 1; j >= 0; j--) {
/* 117 */         if (searchStrings[j].length() == 0) {
/* 118 */           return new int[] { 0, j };
/*     */         }
/*     */       } 
/*     */     } 
/* 122 */     return new int[] { -1, -1 };
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int endsWith(String[] searchStrings, String text) {
/* 135 */     int index = -1;
/*     */     
/* 137 */     for (int i = 0; i < searchStrings.length; i++) {
/* 138 */       if (text.endsWith(searchStrings[i]) && (
/* 139 */         index == -1 || searchStrings[i].length() > searchStrings[index].length())) {
/* 140 */         index = i;
/*     */       }
/*     */     } 
/*     */     
/* 144 */     return index;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int startsWith(String[] searchStrings, String text) {
/* 157 */     int index = -1;
/*     */     
/* 159 */     for (int i = 0; i < searchStrings.length; i++) {
/* 160 */       if (text.startsWith(searchStrings[i]) && (
/* 161 */         index == -1 || searchStrings[i].length() > searchStrings[index].length())) {
/* 162 */         index = i;
/*     */       }
/*     */     } 
/*     */     
/* 166 */     return index;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int equals(String[] compareStrings, String text) {
/* 178 */     for (int i = 0; i < compareStrings.length; i++) {
/* 179 */       if (text.equals(compareStrings[i]))
/* 180 */         return i; 
/*     */     } 
/* 182 */     return -1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static DocumentEvent mergeUnprocessedDocumentEvents(IDocument unprocessedDocument, List<? extends DocumentEvent> documentEvents) throws BadLocationException {
/* 197 */     if (documentEvents.isEmpty()) {
/* 198 */       return null;
/*     */     }
/* 200 */     Iterator<? extends DocumentEvent> iterator = documentEvents.iterator();
/* 201 */     DocumentEvent firstEvent = iterator.next();
/*     */ 
/*     */     
/* 204 */     IDocument document = unprocessedDocument;
/* 205 */     int offset = firstEvent.getOffset();
/* 206 */     int length = firstEvent.getLength();
/* 207 */     StringBuilder text = new StringBuilder((firstEvent.getText() == null) ? "" : firstEvent.getText());
/*     */     
/* 209 */     while (iterator.hasNext()) {
/*     */       
/* 211 */       int delta = text.length() - length;
/*     */       
/* 213 */       DocumentEvent event = iterator.next();
/* 214 */       int eventOffset = event.getOffset();
/* 215 */       int eventLength = event.getLength();
/* 216 */       String eventText = (event.getText() == null) ? "" : event.getText();
/*     */ 
/*     */       
/* 219 */       if (eventOffset > offset + length + delta) {
/* 220 */         String string = document.get(offset + length, eventOffset - delta - offset + length);
/* 221 */         text.append(string);
/* 222 */         text.append(eventText);
/*     */         
/* 224 */         length = eventOffset - delta + eventLength - offset;
/*     */         continue;
/*     */       } 
/* 227 */       if (eventOffset + eventLength < offset) {
/* 228 */         String string = document.get(eventOffset + eventLength, offset - eventOffset + eventLength);
/* 229 */         text.insert(0, string);
/* 230 */         text.insert(0, eventText);
/*     */         
/* 232 */         length = offset + length - eventOffset;
/* 233 */         offset = eventOffset;
/*     */         
/*     */         continue;
/*     */       } 
/* 237 */       int start = Math.max(0, eventOffset - offset);
/* 238 */       int end = Math.min(text.length(), eventLength + eventOffset - offset);
/* 239 */       text.replace(start, end, eventText);
/*     */       
/* 241 */       offset = Math.min(offset, eventOffset);
/* 242 */       int totalDelta = delta + eventText.length() - eventLength;
/* 243 */       length = text.length() - totalDelta;
/*     */     } 
/*     */ 
/*     */     
/* 247 */     return new DocumentEvent(document, offset, length, text.toString());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static DocumentEvent mergeProcessedDocumentEvents(List<? extends DocumentEvent> documentEvents) throws BadLocationException {
/* 262 */     if (documentEvents.isEmpty()) {
/* 263 */       return null;
/*     */     }
/* 265 */     ListIterator<? extends DocumentEvent> iterator = documentEvents.listIterator(documentEvents.size());
/* 266 */     DocumentEvent firstEvent = iterator.previous();
/*     */ 
/*     */     
/* 269 */     IDocument document = firstEvent.getDocument();
/* 270 */     int offset = firstEvent.getOffset();
/* 271 */     int length = firstEvent.getLength();
/* 272 */     int textLength = (firstEvent.getText() == null) ? 0 : firstEvent.getText().length();
/*     */     
/* 274 */     while (iterator.hasPrevious()) {
/*     */       
/* 276 */       int delta = length - textLength;
/*     */       
/* 278 */       DocumentEvent event = iterator.previous();
/* 279 */       int eventOffset = event.getOffset();
/* 280 */       int eventLength = event.getLength();
/* 281 */       int eventTextLength = (event.getText() == null) ? 0 : event.getText().length();
/*     */ 
/*     */       
/* 284 */       if (eventOffset > offset + textLength + delta) {
/* 285 */         length = eventOffset - delta - offset + textLength + length + eventLength;
/* 286 */         textLength = eventOffset - delta + eventTextLength - offset;
/*     */         continue;
/*     */       } 
/* 289 */       if (eventOffset + eventTextLength < offset) {
/* 290 */         length = offset - eventOffset + eventTextLength + length + eventLength;
/* 291 */         textLength = offset + textLength - eventOffset;
/* 292 */         offset = eventOffset;
/*     */         
/*     */         continue;
/*     */       } 
/* 296 */       int start = Math.max(0, eventOffset - offset);
/* 297 */       int end = Math.min(length, eventTextLength + eventOffset - offset);
/* 298 */       length += eventLength - end - start;
/*     */       
/* 300 */       offset = Math.min(offset, eventOffset);
/* 301 */       int totalDelta = delta + eventLength - eventTextLength;
/* 302 */       textLength = length - totalDelta;
/*     */     } 
/*     */ 
/*     */     
/* 306 */     String text = document.get(offset, textLength);
/* 307 */     return new DocumentEvent(document, offset, length, text);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Map<String, IDocumentPartitioner> removeDocumentPartitioners(IDocument document) {
/* 319 */     Map<String, IDocumentPartitioner> partitioners = new HashMap<>();
/* 320 */     if (document instanceof IDocumentExtension3) {
/* 321 */       IDocumentExtension3 extension3 = (IDocumentExtension3)document;
/* 322 */       String[] partitionings = extension3.getPartitionings(); byte b; int i; String[] arrayOfString1;
/* 323 */       for (i = (arrayOfString1 = partitionings).length, b = 0; b < i; ) { String partitioning = arrayOfString1[b];
/* 324 */         IDocumentPartitioner partitioner = extension3.getDocumentPartitioner(partitioning);
/* 325 */         if (partitioner != null) {
/* 326 */           extension3.setDocumentPartitioner(partitioning, null);
/* 327 */           partitioner.disconnect();
/* 328 */           partitioners.put(partitioning, partitioner);
/*     */         }  b++; }
/*     */     
/*     */     } else {
/* 332 */       IDocumentPartitioner partitioner = document.getDocumentPartitioner();
/* 333 */       if (partitioner != null) {
/* 334 */         document.setDocumentPartitioner(null);
/* 335 */         partitioner.disconnect();
/* 336 */         partitioners.put("__dftl_partitioning", partitioner);
/*     */       } 
/*     */     } 
/* 339 */     return partitioners;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void addDocumentPartitioners(IDocument document, Map<String, ? extends IDocumentPartitioner> partitioners) {
/* 351 */     if (document instanceof IDocumentExtension3) {
/* 352 */       IDocumentExtension3 extension3 = (IDocumentExtension3)document;
/* 353 */       for (Map.Entry<String, ? extends IDocumentPartitioner> entry : partitioners.entrySet()) {
/* 354 */         String partitioning = entry.getKey();
/* 355 */         IDocumentPartitioner partitioner = entry.getValue();
/* 356 */         partitioner.connect(document);
/* 357 */         extension3.setDocumentPartitioner(partitioning, partitioner);
/*     */       } 
/* 359 */       partitioners.clear();
/*     */     } else {
/* 361 */       IDocumentPartitioner partitioner = partitioners.get("__dftl_partitioning");
/* 362 */       partitioner.connect(document);
/* 363 */       document.setDocumentPartitioner(partitioner);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getContentType(IDocument document, String partitioning, int offset, boolean preferOpenPartitions) throws BadLocationException {
/* 381 */     if (document instanceof IDocumentExtension3) {
/* 382 */       IDocumentExtension3 extension3 = (IDocumentExtension3)document;
/*     */       try {
/* 384 */         return extension3.getContentType(partitioning, offset, preferOpenPartitions);
/* 385 */       } catch (BadPartitioningException badPartitioningException) {
/* 386 */         return "__dftl_partition_content_type";
/*     */       } 
/*     */     } 
/*     */     
/* 390 */     return document.getContentType(offset);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ITypedRegion getPartition(IDocument document, String partitioning, int offset, boolean preferOpenPartitions) throws BadLocationException {
/* 408 */     if (document instanceof IDocumentExtension3) {
/* 409 */       IDocumentExtension3 extension3 = (IDocumentExtension3)document;
/*     */       try {
/* 411 */         return extension3.getPartition(partitioning, offset, preferOpenPartitions);
/* 412 */       } catch (BadPartitioningException badPartitioningException) {
/* 413 */         return new TypedRegion(0, document.getLength(), "__dftl_partition_content_type");
/*     */       } 
/*     */     } 
/*     */     
/* 417 */     return document.getPartition(offset);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ITypedRegion[] computePartitioning(IDocument document, String partitioning, int offset, int length, boolean includeZeroLengthPartitions) throws BadLocationException {
/* 436 */     if (document instanceof IDocumentExtension3) {
/* 437 */       IDocumentExtension3 extension3 = (IDocumentExtension3)document;
/*     */       try {
/* 439 */         return extension3.computePartitioning(partitioning, offset, length, includeZeroLengthPartitions);
/* 440 */       } catch (BadPartitioningException badPartitioningException) {
/* 441 */         return new ITypedRegion[0];
/*     */       } 
/*     */     } 
/*     */     
/* 445 */     return document.computePartitioning(offset, length);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String[] computePartitionManagingCategories(IDocument document) {
/* 457 */     if (document instanceof IDocumentExtension3) {
/* 458 */       IDocumentExtension3 extension3 = (IDocumentExtension3)document;
/* 459 */       String[] partitionings = extension3.getPartitionings();
/* 460 */       if (partitionings != null) {
/* 461 */         Set<String> categories = new HashSet<>(); byte b; int i; String[] arrayOfString1;
/* 462 */         for (i = (arrayOfString1 = partitionings).length, b = 0; b < i; ) { String partitioning = arrayOfString1[b];
/* 463 */           IDocumentPartitioner p = extension3.getDocumentPartitioner(partitioning);
/* 464 */           if (p instanceof IDocumentPartitionerExtension2) {
/* 465 */             IDocumentPartitionerExtension2 extension2 = (IDocumentPartitionerExtension2)p;
/* 466 */             String[] c = extension2.getManagingPositionCategories();
/* 467 */             if (c != null)
/* 468 */               Collections.addAll(categories, c); 
/*     */           } 
/*     */           b++; }
/*     */         
/* 472 */         String[] result = new String[categories.size()];
/* 473 */         categories.toArray(result);
/* 474 */         return result;
/*     */       } 
/*     */     } 
/* 477 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getDefaultLineDelimiter(IDocument document) {
/* 492 */     String lineDelimiter = null;
/*     */     
/* 494 */     if (document instanceof IDocumentExtension4) {
/* 495 */       lineDelimiter = ((IDocumentExtension4)document).getDefaultLineDelimiter();
/* 496 */       if (lineDelimiter != null) {
/* 497 */         return lineDelimiter;
/*     */       }
/*     */     } 
/*     */     try {
/* 501 */       lineDelimiter = document.getLineDelimiter(0);
/* 502 */     } catch (BadLocationException badLocationException) {}
/*     */ 
/*     */ 
/*     */     
/* 506 */     if (lineDelimiter != null) {
/* 507 */       return lineDelimiter;
/*     */     }
/* 509 */     String sysLineDelimiter = System.lineSeparator();
/* 510 */     String[] delimiters = document.getLegalLineDelimiters();
/* 511 */     Assert.isTrue((delimiters.length > 0)); byte b; int i; String[] arrayOfString1;
/* 512 */     for (i = (arrayOfString1 = delimiters).length, b = 0; b < i; ) { String delimiter = arrayOfString1[b];
/* 513 */       if (delimiter.equals(sysLineDelimiter)) {
/* 514 */         lineDelimiter = sysLineDelimiter;
/*     */         break;
/*     */       } 
/*     */       b++; }
/*     */     
/* 519 */     if (lineDelimiter == null) {
/* 520 */       lineDelimiter = delimiters[0];
/*     */     }
/* 522 */     return lineDelimiter;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean overlaps(IRegion left, IRegion right) {
/* 536 */     if (left == null || right == null) {
/* 537 */       return false;
/*     */     }
/* 539 */     int rightEnd = right.getOffset() + right.getLength();
/* 540 */     int leftEnd = left.getOffset() + left.getLength();
/*     */     
/* 542 */     if (right.getLength() > 0) {
/* 543 */       if (left.getLength() > 0)
/* 544 */         return (left.getOffset() < rightEnd && right.getOffset() < leftEnd); 
/* 545 */       return (right.getOffset() <= left.getOffset() && left.getOffset() < rightEnd);
/*     */     } 
/*     */     
/* 548 */     if (left.getLength() > 0) {
/* 549 */       return (left.getOffset() <= right.getOffset() && right.getOffset() < leftEnd);
/*     */     }
/* 551 */     return (left.getOffset() == right.getOffset());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String[] copy(String[] array) {
/* 562 */     if (array != null) {
/* 563 */       String[] copy = new String[array.length];
/* 564 */       System.arraycopy(array, 0, copy, 0, array.length);
/* 565 */       return copy;
/*     */     } 
/* 567 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int[] copy(int[] array) {
/* 578 */     if (array != null) {
/* 579 */       int[] copy = new int[array.length];
/* 580 */       System.arraycopy(array, 0, copy, 0, array.length);
/* 581 */       return copy;
/*     */     } 
/* 583 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static AbstractLineTracker.DelimiterInfo nextDelimiter(CharSequence text, int offset) {
/* 602 */     AbstractLineTracker.DelimiterInfo info = new AbstractLineTracker.DelimiterInfo();
/*     */     
/* 604 */     int length = text.length();
/* 605 */     for (int i = offset; i < length; i++) {
/* 606 */       char ch = text.charAt(i);
/* 607 */       if (ch == '\r') {
/* 608 */         info.delimiterIndex = i;
/* 609 */         if (i + 1 < length && text.charAt(i + 1) == '\n') {
/* 610 */           info.delimiter = DELIMITERS[2];
/*     */           break;
/*     */         } 
/* 613 */         info.delimiter = DELIMITERS[1]; break;
/*     */       } 
/* 615 */       if (ch == '\n') {
/* 616 */         info.delimiterIndex = i;
/* 617 */         info.delimiter = DELIMITERS[0];
/*     */         break;
/*     */       } 
/*     */     } 
/* 621 */     if (info.delimiter == null) {
/* 622 */       info.delimiterIndex = -1;
/*     */     } else {
/* 624 */       info.delimiterLength = info.delimiter.length();
/*     */     } 
/* 626 */     return info;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.text-3.13.0.jar!\org\eclipse\jface\text\TextUtilities.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */