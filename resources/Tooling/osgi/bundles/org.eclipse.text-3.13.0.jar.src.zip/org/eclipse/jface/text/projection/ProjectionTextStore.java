/*     */ package org.eclipse.jface.text.projection;
/*     */ 
/*     */ import org.eclipse.jface.text.BadLocationException;
/*     */ import org.eclipse.jface.text.IDocument;
/*     */ import org.eclipse.jface.text.IRegion;
/*     */ import org.eclipse.jface.text.ITextStore;
/*     */ import org.eclipse.jface.text.Region;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class ProjectionTextStore
/*     */   implements ITextStore
/*     */ {
/*     */   private IDocument fMasterDocument;
/*     */   private IMinimalMapping fMapping;
/*     */   
/*     */   private static class ReusableRegion
/*     */     implements IRegion
/*     */   {
/*     */     private int fOffset;
/*     */     private int fLength;
/*     */     
/*     */     public int getLength() {
/*  43 */       return this.fLength;
/*     */     }
/*     */ 
/*     */     
/*     */     public int getOffset() {
/*  48 */       return this.fOffset;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void update(int offset, int length) {
/*  58 */       this.fOffset = offset;
/*  59 */       this.fLength = length;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  68 */   private ReusableRegion fReusableRegion = new ReusableRegion();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ProjectionTextStore(IDocument masterDocument, IMinimalMapping mapping) {
/*  79 */     this.fMasterDocument = masterDocument;
/*  80 */     this.fMapping = mapping;
/*     */   }
/*     */   
/*     */   private void internalError() {
/*  84 */     throw new IllegalStateException();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void set(String contents) {
/*  90 */     IRegion masterRegion = this.fMapping.getCoverage();
/*  91 */     if (masterRegion == null) {
/*  92 */       internalError();
/*     */     }
/*     */     try {
/*  95 */       this.fMasterDocument.replace(masterRegion.getOffset(), masterRegion.getLength(), contents);
/*  96 */     } catch (BadLocationException badLocationException) {
/*  97 */       internalError();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void replace(int offset, int length, String text) {
/* 103 */     this.fReusableRegion.update(offset, length);
/*     */     try {
/* 105 */       IRegion masterRegion = this.fMapping.toOriginRegion(this.fReusableRegion);
/* 106 */       this.fMasterDocument.replace(masterRegion.getOffset(), masterRegion.getLength(), text);
/* 107 */     } catch (BadLocationException badLocationException) {
/* 108 */       internalError();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public int getLength() {
/* 114 */     return this.fMapping.getImageLength();
/*     */   }
/*     */ 
/*     */   
/*     */   public char get(int offset) {
/*     */     try {
/* 120 */       int originOffset = this.fMapping.toOriginOffset(offset);
/* 121 */       return this.fMasterDocument.getChar(originOffset);
/* 122 */     } catch (BadLocationException badLocationException) {
/* 123 */       internalError();
/*     */ 
/*     */ 
/*     */       
/* 127 */       return Character.MIN_VALUE;
/*     */     } 
/*     */   }
/*     */   
/*     */   public String get(int offset, int length) {
/*     */     try {
/* 133 */       IRegion[] fragments = this.fMapping.toExactOriginRegions((IRegion)new Region(offset, length));
/* 134 */       StringBuilder buffer = new StringBuilder(); byte b; int i; IRegion[] arrayOfIRegion1;
/* 135 */       for (i = (arrayOfIRegion1 = fragments).length, b = 0; b < i; ) { IRegion fragment = arrayOfIRegion1[b];
/* 136 */         buffer.append(this.fMasterDocument.get(fragment.getOffset(), fragment.getLength())); b++; }
/*     */       
/* 138 */       return buffer.toString();
/* 139 */     } catch (BadLocationException badLocationException) {
/* 140 */       internalError();
/*     */ 
/*     */ 
/*     */       
/* 144 */       return null;
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.text-3.13.0.jar!\org\eclipse\jface\text\projection\ProjectionTextStore.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */