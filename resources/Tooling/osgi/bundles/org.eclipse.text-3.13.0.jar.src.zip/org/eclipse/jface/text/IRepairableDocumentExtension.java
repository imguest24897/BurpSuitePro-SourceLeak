package org.eclipse.jface.text;

public interface IRepairableDocumentExtension {
  boolean isLineInformationRepairNeeded(int paramInt1, int paramInt2, String paramString) throws BadLocationException;
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.text-3.13.0.jar!\org\eclipse\jface\text\IRepairableDocumentExtension.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */