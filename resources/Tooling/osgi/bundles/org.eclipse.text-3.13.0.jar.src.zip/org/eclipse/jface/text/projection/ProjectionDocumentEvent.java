/*     */ package org.eclipse.jface.text.projection;
/*     */ 
/*     */ import org.eclipse.jface.text.DocumentEvent;
/*     */ import org.eclipse.jface.text.IDocument;
/*     */ import org.eclipse.jface.text.SlaveDocumentEvent;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ProjectionDocumentEvent
/*     */   extends SlaveDocumentEvent
/*     */ {
/*  41 */   public static final Object PROJECTION_CHANGE = new Object();
/*     */   
/*  43 */   public static final Object CONTENT_CHANGE = new Object();
/*     */ 
/*     */   
/*     */   private Object fChangeType;
/*     */   
/*  48 */   private int fMasterOffset = -1;
/*     */   
/*  50 */   private int fMasterLength = -1;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ProjectionDocumentEvent(IDocument doc, int offset, int length, String text, DocumentEvent masterEvent) {
/*  66 */     super(doc, offset, length, text, masterEvent);
/*  67 */     this.fChangeType = CONTENT_CHANGE;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ProjectionDocumentEvent(IDocument doc, int offset, int length, String text, int masterOffset, int masterLength) {
/*  83 */     super(doc, offset, length, text, null);
/*  84 */     this.fChangeType = PROJECTION_CHANGE;
/*  85 */     this.fMasterOffset = masterOffset;
/*  86 */     this.fMasterLength = masterLength;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ProjectionDocumentEvent(IDocument doc, int offset, int length, String text, int masterOffset, int masterLength, DocumentEvent masterEvent) {
/* 106 */     super(doc, offset, length, text, masterEvent);
/* 107 */     this.fChangeType = PROJECTION_CHANGE;
/* 108 */     this.fMasterOffset = masterOffset;
/* 109 */     this.fMasterLength = masterLength;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object getChangeType() {
/* 119 */     return this.fChangeType;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getMasterOffset() {
/* 129 */     return this.fMasterOffset;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getMasterLength() {
/* 139 */     return this.fMasterLength;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.text-3.13.0.jar!\org\eclipse\jface\text\projection\ProjectionDocumentEvent.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */