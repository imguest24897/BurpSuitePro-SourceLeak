/*     */ package org.eclipse.jface.text.templates;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.eclipse.core.runtime.Assert;
/*     */ import org.eclipse.jface.text.BadLocationException;
/*     */ import org.eclipse.jface.text.Document;
/*     */ import org.eclipse.jface.text.IDocument;
/*     */ import org.eclipse.text.edits.MalformedTreeException;
/*     */ import org.eclipse.text.edits.MultiTextEdit;
/*     */ import org.eclipse.text.edits.RangeMarker;
/*     */ import org.eclipse.text.edits.ReplaceEdit;
/*     */ import org.eclipse.text.edits.TextEdit;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TemplateContextType
/*     */ {
/*  51 */   private String fId = null;
/*     */ 
/*     */   
/*  54 */   private final Map<String, TemplateVariableResolver> fResolvers = new HashMap<>();
/*     */ 
/*     */   
/*  57 */   private String fName = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TemplateContextType(String id) {
/*  66 */     this(id, id);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TemplateContextType(String id, String name) {
/*  76 */     Assert.isNotNull(id);
/*  77 */     Assert.isNotNull(name);
/*  78 */     this.fId = id;
/*  79 */     this.fName = name;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getId() {
/*  88 */     return this.fId;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getName() {
/*  98 */     return this.fName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TemplateContextType() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void setId(String id) throws RuntimeException {
/* 126 */     Assert.isNotNull(id);
/* 127 */     Assert.isTrue((this.fId == null));
/* 128 */     this.fId = id;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void setName(String name) {
/* 143 */     Assert.isTrue((this.fName == null));
/* 144 */     this.fName = name;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addResolver(TemplateVariableResolver resolver) {
/* 154 */     Assert.isNotNull(resolver);
/* 155 */     this.fResolvers.put(resolver.getType(), resolver);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void removeResolver(TemplateVariableResolver resolver) {
/* 164 */     Assert.isNotNull(resolver);
/* 165 */     this.fResolvers.remove(resolver.getType());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void removeAllResolvers() {
/* 172 */     this.fResolvers.clear();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Iterator<TemplateVariableResolver> resolvers() {
/* 181 */     return Collections.<String, TemplateVariableResolver>unmodifiableMap(this.fResolvers).values().iterator();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected TemplateVariableResolver getResolver(String type) {
/* 191 */     return this.fResolvers.get(type);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void validate(String pattern) throws TemplateException {
/* 202 */     TemplateTranslator translator = new TemplateTranslator();
/* 203 */     TemplateBuffer buffer = translator.translate(pattern);
/* 204 */     validateVariables(buffer.getVariables());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void validateVariables(TemplateVariable[] variables) throws TemplateException {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void resolve(TemplateBuffer buffer, TemplateContext context) throws MalformedTreeException, BadLocationException {
/* 232 */     Assert.isNotNull(context);
/* 233 */     TemplateVariable[] variables = buffer.getVariables();
/*     */     
/* 235 */     List<RangeMarker> positions = variablesToPositions(variables);
/* 236 */     List<ReplaceEdit> edits = new ArrayList<>(5);
/*     */ 
/*     */     
/* 239 */     for (int i = 0; i != variables.length; i++) {
/* 240 */       TemplateVariable variable = variables[i];
/*     */       
/* 242 */       if (!variable.isResolved()) {
/* 243 */         resolve(variable, context);
/*     */       }
/* 245 */       String value = variable.getDefaultValue();
/* 246 */       int[] offsets = variable.getOffsets();
/*     */       
/* 248 */       for (int k = 0; k != offsets.length; k++) {
/* 249 */         edits.add(new ReplaceEdit(offsets[k], variable.getInitialLength(), value));
/*     */       }
/*     */     } 
/*     */     
/* 253 */     Document document = new Document(buffer.getString());
/* 254 */     MultiTextEdit edit = new MultiTextEdit(0, document.getLength());
/* 255 */     edit.addChildren(positions.<TextEdit>toArray(new TextEdit[positions.size()]));
/* 256 */     edit.addChildren(edits.<TextEdit>toArray(new TextEdit[edits.size()]));
/* 257 */     edit.apply((IDocument)document, 2);
/*     */     
/* 259 */     positionsToVariables(positions, variables);
/*     */     
/* 261 */     buffer.setContent(document.get(), variables);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void resolve(TemplateVariable variable, TemplateContext context) {
/* 272 */     String type = variable.getType();
/* 273 */     TemplateVariableResolver resolver = this.fResolvers.get(type);
/* 274 */     if (resolver == null)
/* 275 */       resolver = new TemplateVariableResolver(type, ""); 
/* 276 */     resolver.resolve(variable, context);
/*     */   }
/*     */   
/*     */   private static List<RangeMarker> variablesToPositions(TemplateVariable[] variables) {
/* 280 */     List<RangeMarker> positions = new ArrayList<>(5);
/* 281 */     for (int i = 0; i != variables.length; i++) {
/* 282 */       int[] offsets = variables[i].getOffsets();
/* 283 */       for (int j = 0; j != offsets.length; j++) {
/* 284 */         positions.add(new RangeMarker(offsets[j], 0));
/*     */       }
/*     */     } 
/* 287 */     return positions;
/*     */   }
/*     */   
/*     */   private static void positionsToVariables(List<RangeMarker> positions, TemplateVariable[] variables) {
/* 291 */     Iterator<RangeMarker> iterator = positions.iterator();
/*     */     
/* 293 */     for (int i = 0; i != variables.length; i++) {
/* 294 */       TemplateVariable variable = variables[i];
/*     */       
/* 296 */       int[] offsets = new int[(variable.getOffsets()).length];
/* 297 */       for (int j = 0; j != offsets.length; j++) {
/* 298 */         offsets[j] = ((RangeMarker)iterator.next()).getOffset();
/*     */       }
/* 300 */       variable.setOffsets(offsets);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.text-3.13.0.jar!\org\eclipse\jface\text\templates\TemplateContextType.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */