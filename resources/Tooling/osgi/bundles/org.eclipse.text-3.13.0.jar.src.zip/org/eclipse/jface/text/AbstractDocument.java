/*      */ package org.eclipse.jface.text;
/*      */ 
/*      */ import java.util.ArrayList;
/*      */ import java.util.Arrays;
/*      */ import java.util.HashMap;
/*      */ import java.util.Iterator;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.concurrent.CopyOnWriteArrayList;
/*      */ import java.util.regex.PatternSyntaxException;
/*      */ import org.eclipse.core.runtime.Assert;
/*      */ import org.eclipse.core.runtime.ISafeRunnable;
/*      */ import org.eclipse.core.runtime.ListenerList;
/*      */ import org.eclipse.core.runtime.SafeRunner;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public abstract class AbstractDocument
/*      */   implements IDocument, IDocumentExtension, IDocumentExtension2, IDocumentExtension3, IDocumentExtension4, IRepairableDocument, IRepairableDocumentExtension
/*      */ {
/*      */   private static final boolean DEBUG = false;
/*      */   private ITextStore fStore;
/*      */   private ILineTracker fTracker;
/*      */   private ListenerList<IDocumentListener> fDocumentListeners;
/*      */   private ListenerList<IDocumentListener> fPrenotifiedDocumentListeners;
/*      */   private ListenerList<IDocumentPartitioningListener> fDocumentPartitioningListeners;
/*      */   private Map<String, List<Position>> fPositions;
/*      */   private Map<String, List<Position>> fEndPositions;
/*      */   private List<IPositionUpdater> fPositionUpdaters;
/*      */   private List<RegisteredReplace> fPostNotificationChanges;
/*      */   
/*      */   private static class RegisteredReplace
/*      */   {
/*      */     IDocumentListener fOwner;
/*      */     IDocumentExtension.IReplace fReplace;
/*      */     
/*      */     RegisteredReplace(IDocumentListener owner, IDocumentExtension.IReplace replace) {
/*   89 */       this.fOwner = owner;
/*   90 */       this.fReplace = replace;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  123 */   private int fReentranceCount = 0;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  128 */   private int fStoppedCount = 0;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean fAcceptPostNotificationReplaces = true;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  138 */   private int fStoppedListenerNotification = 0;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private DocumentEvent fDeferredDocumentEvent;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private Map<String, IDocumentPartitioner> fDocumentPartitioners;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private DocumentPartitioningChangedEvent fDocumentPartitioningChangedEvent;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private FindReplaceDocumentAdapter fFindReplaceDocumentAdapter;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private DocumentRewriteSession fDocumentRewriteSession;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private List<IDocumentRewriteSessionListener> fDocumentRewriteSessionListeners;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  173 */   private long fModificationStamp = -1L;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  178 */   private long fNextModificationStamp = -1L;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private String fInitialLineDelimiter;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected AbstractDocument() {
/*  193 */     this.fModificationStamp = getNextModificationStamp();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected ITextStore getStore() {
/*  204 */     Assert.isNotNull(this.fStore);
/*  205 */     return this.fStore;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected ILineTracker getTracker() {
/*  215 */     Assert.isNotNull(this.fTracker);
/*  216 */     return this.fTracker;
/*      */   }
/*      */   
/*      */   private static <T> List<T> asList(ListenerList<T> listenerList) {
/*  220 */     List<?> list = Arrays.asList(listenerList.getListeners());
/*      */     
/*  222 */     List<T> castList = (List)list;
/*  223 */     return castList;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected List<IDocumentListener> getDocumentListeners() {
/*  233 */     return asList(this.fDocumentListeners);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected List<IDocumentPartitioningListener> getDocumentPartitioningListeners() {
/*  242 */     return asList(this.fDocumentPartitioningListeners);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected Map<String, List<Position>> getDocumentManagedPositions() {
/*  251 */     return this.fPositions;
/*      */   }
/*      */ 
/*      */   
/*      */   public IDocumentPartitioner getDocumentPartitioner() {
/*  256 */     return getDocumentPartitioner("__dftl_partitioning");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void setTextStore(ITextStore store) {
/*  270 */     this.fStore = store;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void setLineTracker(ILineTracker tracker) {
/*  280 */     this.fTracker = tracker;
/*      */   }
/*      */ 
/*      */   
/*      */   public void setDocumentPartitioner(IDocumentPartitioner partitioner) {
/*  285 */     setDocumentPartitioner("__dftl_partitioning", partitioner);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void completeInitialization() {
/*  295 */     this.fPositions = new HashMap<>();
/*  296 */     this.fEndPositions = new HashMap<>();
/*  297 */     this.fPositionUpdaters = new CopyOnWriteArrayList<>();
/*  298 */     this.fDocumentListeners = new ListenerList(1);
/*  299 */     this.fPrenotifiedDocumentListeners = new ListenerList(1);
/*  300 */     this.fDocumentPartitioningListeners = new ListenerList(1);
/*  301 */     this.fDocumentRewriteSessionListeners = new ArrayList<>();
/*      */     
/*  303 */     addPositionCategory("__dflt_position_category");
/*  304 */     addPositionUpdater(new DefaultPositionUpdater("__dflt_position_category"));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void addDocumentListener(IDocumentListener listener) {
/*  312 */     Assert.isNotNull(listener);
/*  313 */     this.fDocumentListeners.add(listener);
/*      */   }
/*      */ 
/*      */   
/*      */   public void removeDocumentListener(IDocumentListener listener) {
/*  318 */     Assert.isNotNull(listener);
/*  319 */     this.fDocumentListeners.remove(listener);
/*      */   }
/*      */ 
/*      */   
/*      */   public void addPrenotifiedDocumentListener(IDocumentListener listener) {
/*  324 */     Assert.isNotNull(listener);
/*  325 */     this.fPrenotifiedDocumentListeners.add(listener);
/*      */   }
/*      */ 
/*      */   
/*      */   public void removePrenotifiedDocumentListener(IDocumentListener listener) {
/*  330 */     Assert.isNotNull(listener);
/*  331 */     this.fPrenotifiedDocumentListeners.remove(listener);
/*      */   }
/*      */ 
/*      */   
/*      */   public void addDocumentPartitioningListener(IDocumentPartitioningListener listener) {
/*  336 */     Assert.isNotNull(listener);
/*  337 */     this.fDocumentPartitioningListeners.add(listener);
/*      */   }
/*      */ 
/*      */   
/*      */   public void removeDocumentPartitioningListener(IDocumentPartitioningListener listener) {
/*  342 */     Assert.isNotNull(listener);
/*  343 */     this.fDocumentPartitioningListeners.remove(listener);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void addPosition(String category, Position position) throws BadLocationException, BadPositionCategoryException {
/*  349 */     if (position.offset < 0 || position.length < 0 || position.offset + position.length > getLength()) {
/*  350 */       throw new BadLocationException();
/*      */     }
/*  352 */     if (category == null) {
/*  353 */       throw new BadPositionCategoryException();
/*      */     }
/*  355 */     List<Position> list = this.fPositions.get(category);
/*  356 */     if (list == null)
/*  357 */       throw new BadPositionCategoryException(); 
/*  358 */     list.add(computeIndexInPositionList(list, position.offset), position);
/*      */     
/*  360 */     List<Position> endPositions = this.fEndPositions.get(category);
/*  361 */     if (endPositions == null)
/*  362 */       throw new BadPositionCategoryException(); 
/*  363 */     endPositions.add(computeIndexInPositionList(endPositions, position.offset + position.length - 1, false), position);
/*      */   }
/*      */ 
/*      */   
/*      */   public void addPosition(Position position) throws BadLocationException {
/*      */     try {
/*  369 */       addPosition("__dflt_position_category", position);
/*  370 */     } catch (BadPositionCategoryException badPositionCategoryException) {}
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void addPositionCategory(String category) {
/*  377 */     if (category == null) {
/*      */       return;
/*      */     }
/*  380 */     if (!containsPositionCategory(category)) {
/*  381 */       this.fPositions.put(category, new ArrayList<>());
/*  382 */       this.fEndPositions.put(category, new ArrayList<>());
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public void addPositionUpdater(IPositionUpdater updater) {
/*  388 */     insertPositionUpdater(updater, this.fPositionUpdaters.size());
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean containsPosition(String category, int offset, int length) {
/*  394 */     if (category == null) {
/*  395 */       return false;
/*      */     }
/*  397 */     List<Position> list = this.fPositions.get(category);
/*  398 */     if (list == null) {
/*  399 */       return false;
/*      */     }
/*  401 */     int size = list.size();
/*  402 */     if (size == 0) {
/*  403 */       return false;
/*      */     }
/*  405 */     int index = computeIndexInPositionList(list, offset);
/*  406 */     if (index < size) {
/*  407 */       Position p = list.get(index);
/*  408 */       while (p != null && p.offset == offset) {
/*  409 */         if (p.length == length)
/*  410 */           return true; 
/*  411 */         index++;
/*  412 */         p = (index < size) ? list.get(index) : null;
/*      */       } 
/*      */     } 
/*      */     
/*  416 */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean containsPositionCategory(String category) {
/*  421 */     if (category != null)
/*  422 */       return this.fPositions.containsKey(category); 
/*  423 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   protected int computeIndexInPositionList(List<? extends Position> positions, int offset) {
/*  441 */     return computeIndexInPositionList(positions, offset, true);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected int computeIndexInPositionList(List<? extends Position> positions, int offset, boolean orderedByOffset) {
/*  456 */     if (positions.isEmpty()) {
/*  457 */       return 0;
/*      */     }
/*  459 */     int left = 0;
/*  460 */     int right = positions.size() - 1;
/*  461 */     int mid = 0;
/*  462 */     Position p = null;
/*      */     
/*  464 */     while (left < right) {
/*      */       
/*  466 */       mid = (left + right) / 2;
/*      */       
/*  468 */       p = positions.get(mid);
/*  469 */       int pOffset = getOffset(orderedByOffset, p);
/*  470 */       if (offset < pOffset) {
/*  471 */         if (left == mid) {
/*  472 */           right = left; continue;
/*      */         } 
/*  474 */         right = mid - 1; continue;
/*  475 */       }  if (offset > pOffset) {
/*  476 */         if (right == mid) {
/*  477 */           left = right; continue;
/*      */         } 
/*  479 */         left = mid + 1; continue;
/*  480 */       }  if (offset == pOffset) {
/*  481 */         left = right = mid;
/*      */       }
/*      */     } 
/*      */ 
/*      */     
/*  486 */     int pos = left;
/*  487 */     p = positions.get(pos);
/*  488 */     int pPosition = getOffset(orderedByOffset, p);
/*  489 */     if (offset > pPosition) {
/*      */       
/*  491 */       pos++;
/*      */     }
/*      */     else {
/*      */       
/*  495 */       pos--;
/*  496 */       while (pos >= 0)
/*      */       
/*  498 */       { p = positions.get(pos);
/*  499 */         pPosition = getOffset(orderedByOffset, p);
/*  500 */         if (offset != pPosition)
/*  501 */           break;  }  pos++;
/*      */     } 
/*      */     
/*  504 */     Assert.isTrue((pos >= 0 && pos <= positions.size()));
/*      */     
/*  506 */     return pos;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private int getOffset(boolean orderedByOffset, Position position) {
/*  513 */     if (orderedByOffset || position.getLength() == 0)
/*  514 */       return position.getOffset(); 
/*  515 */     return position.getOffset() + position.getLength() - 1;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public int computeIndexInCategory(String category, int offset) throws BadLocationException, BadPositionCategoryException {
/*  521 */     if (offset < 0 || offset > getLength()) {
/*  522 */       throw new BadLocationException();
/*      */     }
/*  524 */     List<Position> c = this.fPositions.get(category);
/*  525 */     if (c == null) {
/*  526 */       throw new BadPositionCategoryException();
/*      */     }
/*  528 */     return computeIndexInPositionList(c, offset);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   protected void fireDocumentPartitioningChanged() {
/*  539 */     if (this.fDocumentPartitioningListeners == null) {
/*      */       return;
/*      */     }
/*  542 */     for (IDocumentPartitioningListener listener : this.fDocumentPartitioningListeners) {
/*  543 */       listener.documentPartitioningChanged(this);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   protected void fireDocumentPartitioningChanged(IRegion region) {
/*  561 */     if (this.fDocumentPartitioningListeners == null) {
/*      */       return;
/*      */     }
/*  564 */     for (IDocumentPartitioningListener l : this.fDocumentPartitioningListeners) {
/*      */       try {
/*  566 */         if (l instanceof IDocumentPartitioningListenerExtension) {
/*  567 */           ((IDocumentPartitioningListenerExtension)l).documentPartitioningChanged(this, region); continue;
/*      */         } 
/*  569 */         l.documentPartitioningChanged(this);
/*  570 */       } catch (Exception ex) {
/*  571 */         log(ex);
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void fireDocumentPartitioningChanged(DocumentPartitioningChangedEvent event) {
/*  586 */     if (this.fDocumentPartitioningListeners == null) {
/*      */       return;
/*      */     }
/*  589 */     for (IDocumentPartitioningListener l : this.fDocumentPartitioningListeners) {
/*      */       try {
/*  591 */         if (l instanceof IDocumentPartitioningListenerExtension2) {
/*  592 */           IDocumentPartitioningListenerExtension2 extension2 = (IDocumentPartitioningListenerExtension2)l;
/*  593 */           extension2.documentPartitioningChanged(event); continue;
/*  594 */         }  if (l instanceof IDocumentPartitioningListenerExtension) {
/*  595 */           IDocumentPartitioningListenerExtension extension = (IDocumentPartitioningListenerExtension)l;
/*  596 */           extension.documentPartitioningChanged(this, event.getCoverage()); continue;
/*      */         } 
/*  598 */         l.documentPartitioningChanged(this);
/*      */       }
/*  600 */       catch (Exception ex) {
/*  601 */         log(ex);
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void fireDocumentAboutToBeChanged(DocumentEvent event) {
/*  615 */     if (this.fReentranceCount == 0) {
/*  616 */       flushPostNotificationChanges();
/*      */     }
/*  618 */     if (this.fDocumentPartitioners != null) {
/*  619 */       Iterator<IDocumentPartitioner> e = this.fDocumentPartitioners.values().iterator();
/*  620 */       while (e.hasNext()) {
/*  621 */         IDocumentPartitioner p = e.next();
/*  622 */         if (p instanceof IDocumentPartitionerExtension3) {
/*  623 */           IDocumentPartitionerExtension3 extension = (IDocumentPartitionerExtension3)p;
/*  624 */           if (extension.getActiveRewriteSession() != null)
/*      */             continue; 
/*      */         } 
/*      */         try {
/*  628 */           p.documentAboutToBeChanged(event);
/*  629 */         } catch (Exception ex) {
/*  630 */           log(ex);
/*      */         } 
/*      */       } 
/*      */     } 
/*      */     
/*  635 */     for (IDocumentListener listener : this.fPrenotifiedDocumentListeners) {
/*      */       try {
/*  637 */         listener.documentAboutToBeChanged(event);
/*  638 */       } catch (Exception ex) {
/*  639 */         log(ex);
/*      */       } 
/*      */     } 
/*      */     
/*  643 */     for (IDocumentListener listener : this.fDocumentListeners) {
/*      */       try {
/*  645 */         listener.documentAboutToBeChanged(event);
/*  646 */       } catch (Exception ex) {
/*  647 */         log(ex);
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void updateDocumentStructures(DocumentEvent event) {
/*  661 */     if (this.fDocumentPartitioners != null) {
/*  662 */       this.fDocumentPartitioningChangedEvent = new DocumentPartitioningChangedEvent(this);
/*  663 */       for (Map.Entry<String, IDocumentPartitioner> entry : this.fDocumentPartitioners.entrySet()) {
/*      */         
/*  665 */         String partitioning = entry.getKey();
/*  666 */         IDocumentPartitioner partitioner = entry.getValue();
/*      */         
/*  668 */         if (partitioner instanceof IDocumentPartitionerExtension3) {
/*  669 */           IDocumentPartitionerExtension3 extension = (IDocumentPartitionerExtension3)partitioner;
/*  670 */           if (extension.getActiveRewriteSession() != null) {
/*      */             continue;
/*      */           }
/*      */         } 
/*  674 */         if (partitioner instanceof IDocumentPartitionerExtension) {
/*  675 */           IDocumentPartitionerExtension extension = (IDocumentPartitionerExtension)partitioner;
/*  676 */           IRegion r = extension.documentChanged2(event);
/*  677 */           if (r != null)
/*  678 */             this.fDocumentPartitioningChangedEvent.setPartitionChange(partitioning, r.getOffset(), r.getLength());  continue;
/*      */         } 
/*  680 */         if (partitioner.documentChanged(event)) {
/*  681 */           this.fDocumentPartitioningChangedEvent.setPartitionChange(partitioning, 0, event.getDocument().getLength());
/*      */         }
/*      */       } 
/*      */     } 
/*      */     
/*  686 */     if (!this.fPositions.isEmpty()) {
/*  687 */       updatePositions(event);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void doFireDocumentChanged(DocumentEvent event) {
/*  699 */     boolean changed = (this.fDocumentPartitioningChangedEvent != null && !this.fDocumentPartitioningChangedEvent.isEmpty());
/*  700 */     IRegion change = changed ? this.fDocumentPartitioningChangedEvent.getCoverage() : null;
/*  701 */     doFireDocumentChanged(event, changed, change);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   protected void doFireDocumentChanged(DocumentEvent event, boolean firePartitionChange, IRegion partitionChange) {
/*  717 */     doFireDocumentChanged2(event);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void doFireDocumentChanged2(DocumentEvent event) {
/*  733 */     DocumentPartitioningChangedEvent p = this.fDocumentPartitioningChangedEvent;
/*  734 */     this.fDocumentPartitioningChangedEvent = null;
/*  735 */     if (p != null && !p.isEmpty()) {
/*  736 */       fireDocumentPartitioningChanged(p);
/*      */     }
/*  738 */     for (IDocumentListener listener : this.fPrenotifiedDocumentListeners) {
/*      */       try {
/*  740 */         listener.documentChanged(event);
/*  741 */       } catch (Exception ex) {
/*  742 */         log(ex);
/*      */       } 
/*      */     } 
/*      */     
/*  746 */     for (IDocumentListener listener : this.fDocumentListeners) {
/*      */       try {
/*  748 */         listener.documentChanged(event);
/*  749 */       } catch (Exception ex) {
/*  750 */         log(ex);
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/*  755 */     this.fReentranceCount++;
/*      */     try {
/*  757 */       if (this.fReentranceCount == 1)
/*  758 */         executePostNotificationChanges(); 
/*      */     } finally {
/*  760 */       this.fReentranceCount--;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void fireDocumentChanged(DocumentEvent event) {
/*  772 */     updateDocumentStructures(event);
/*      */     
/*  774 */     if (this.fStoppedListenerNotification == 0) {
/*  775 */       doFireDocumentChanged(event);
/*      */     } else {
/*  777 */       this.fDeferredDocumentEvent = event;
/*      */     } 
/*      */   }
/*      */   
/*      */   public char getChar(int pos) throws BadLocationException {
/*  782 */     if (pos < 0 || pos >= getLength())
/*  783 */       throw new BadLocationException(); 
/*  784 */     return getStore().get(pos);
/*      */   }
/*      */ 
/*      */   
/*      */   public String getContentType(int offset) throws BadLocationException {
/*  789 */     String contentType = null;
/*      */     try {
/*  791 */       contentType = getContentType("__dftl_partitioning", offset, false);
/*  792 */       Assert.isNotNull(contentType);
/*  793 */     } catch (BadPartitioningException badPartitioningException) {
/*  794 */       Assert.isTrue(false);
/*      */     } 
/*  796 */     return contentType;
/*      */   }
/*      */ 
/*      */   
/*      */   public String[] getLegalContentTypes() {
/*  801 */     String[] contentTypes = null;
/*      */     try {
/*  803 */       contentTypes = getLegalContentTypes("__dftl_partitioning");
/*  804 */       Assert.isNotNull(contentTypes);
/*  805 */     } catch (BadPartitioningException badPartitioningException) {
/*  806 */       Assert.isTrue(false);
/*      */     } 
/*  808 */     return contentTypes;
/*      */   }
/*      */ 
/*      */   
/*      */   public int getLength() {
/*  813 */     return getStore().getLength();
/*      */   }
/*      */ 
/*      */   
/*      */   public String getLineDelimiter(int line) throws BadLocationException {
/*  818 */     return getTracker().getLineDelimiter(line);
/*      */   }
/*      */ 
/*      */   
/*      */   public String[] getLegalLineDelimiters() {
/*  823 */     return getTracker().getLegalLineDelimiters();
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public String getDefaultLineDelimiter() {
/*  829 */     String lineDelimiter = null;
/*      */     
/*      */     try {
/*  832 */       lineDelimiter = getLineDelimiter(0);
/*  833 */     } catch (BadLocationException badLocationException) {}
/*      */ 
/*      */     
/*  836 */     if (lineDelimiter != null) {
/*  837 */       return lineDelimiter;
/*      */     }
/*  839 */     if (this.fInitialLineDelimiter != null) {
/*  840 */       return this.fInitialLineDelimiter;
/*      */     }
/*  842 */     String sysLineDelimiter = System.lineSeparator();
/*  843 */     String[] delimiters = getLegalLineDelimiters();
/*  844 */     Assert.isTrue((delimiters.length > 0)); byte b; int i; String[] arrayOfString1;
/*  845 */     for (i = (arrayOfString1 = delimiters).length, b = 0; b < i; ) { String delimiter = arrayOfString1[b];
/*  846 */       if (delimiter.equals(sysLineDelimiter)) {
/*  847 */         lineDelimiter = sysLineDelimiter;
/*      */         break;
/*      */       } 
/*      */       b++; }
/*      */     
/*  852 */     if (lineDelimiter == null) {
/*  853 */       lineDelimiter = delimiters[0];
/*      */     }
/*  855 */     return lineDelimiter;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void setInitialLineDelimiter(String lineDelimiter) {
/*  861 */     Assert.isNotNull(lineDelimiter);
/*  862 */     this.fInitialLineDelimiter = lineDelimiter;
/*      */   }
/*      */ 
/*      */   
/*      */   public int getLineLength(int line) throws BadLocationException {
/*  867 */     return getTracker().getLineLength(line);
/*      */   }
/*      */ 
/*      */   
/*      */   public int getLineOfOffset(int pos) throws BadLocationException {
/*  872 */     return getTracker().getLineNumberOfOffset(pos);
/*      */   }
/*      */ 
/*      */   
/*      */   public int getLineOffset(int line) throws BadLocationException {
/*  877 */     return getTracker().getLineOffset(line);
/*      */   }
/*      */ 
/*      */   
/*      */   public IRegion getLineInformation(int line) throws BadLocationException {
/*  882 */     return getTracker().getLineInformation(line);
/*      */   }
/*      */ 
/*      */   
/*      */   public IRegion getLineInformationOfOffset(int offset) throws BadLocationException {
/*  887 */     return getTracker().getLineInformationOfOffset(offset);
/*      */   }
/*      */ 
/*      */   
/*      */   public int getNumberOfLines() {
/*  892 */     return getTracker().getNumberOfLines();
/*      */   }
/*      */ 
/*      */   
/*      */   public int getNumberOfLines(int offset, int length) throws BadLocationException {
/*  897 */     return getTracker().getNumberOfLines(offset, length);
/*      */   }
/*      */ 
/*      */   
/*      */   public int computeNumberOfLines(String text) {
/*  902 */     return getTracker().computeNumberOfLines(text);
/*      */   }
/*      */ 
/*      */   
/*      */   public ITypedRegion getPartition(int offset) throws BadLocationException {
/*  907 */     ITypedRegion partition = null;
/*      */     try {
/*  909 */       partition = getPartition("__dftl_partitioning", offset, false);
/*  910 */       Assert.isNotNull(partition);
/*  911 */     } catch (BadPartitioningException badPartitioningException) {
/*  912 */       Assert.isTrue(false);
/*      */     } 
/*  914 */     return partition;
/*      */   }
/*      */ 
/*      */   
/*      */   public ITypedRegion[] computePartitioning(int offset, int length) throws BadLocationException {
/*  919 */     ITypedRegion[] partitioning = null;
/*      */     try {
/*  921 */       partitioning = computePartitioning("__dftl_partitioning", offset, length, false);
/*  922 */       Assert.isNotNull(partitioning);
/*  923 */     } catch (BadPartitioningException badPartitioningException) {
/*  924 */       Assert.isTrue(false);
/*      */     } 
/*  926 */     return partitioning;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public Position[] getPositions(String category) throws BadPositionCategoryException {
/*  932 */     if (category == null) {
/*  933 */       throw new BadPositionCategoryException();
/*      */     }
/*  935 */     List<Position> c = this.fPositions.get(category);
/*  936 */     if (c == null) {
/*  937 */       throw new BadPositionCategoryException();
/*      */     }
/*  939 */     Position[] positions = new Position[c.size()];
/*  940 */     c.toArray(positions);
/*  941 */     return positions;
/*      */   }
/*      */ 
/*      */   
/*      */   public String[] getPositionCategories() {
/*  946 */     String[] categories = new String[this.fPositions.size()];
/*  947 */     Iterator<String> keys = this.fPositions.keySet().iterator();
/*  948 */     for (int i = 0; i < categories.length; i++)
/*  949 */       categories[i] = keys.next(); 
/*  950 */     return categories;
/*      */   }
/*      */ 
/*      */   
/*      */   public IPositionUpdater[] getPositionUpdaters() {
/*  955 */     return this.fPositionUpdaters.<IPositionUpdater>toArray(new IPositionUpdater[this.fPositionUpdaters.size()]);
/*      */   }
/*      */ 
/*      */   
/*      */   public String get() {
/*  960 */     return getStore().get(0, getLength());
/*      */   }
/*      */ 
/*      */   
/*      */   public String get(int pos, int length) throws BadLocationException {
/*  965 */     int myLength = getLength();
/*  966 */     if (pos < 0 || length < 0 || pos + length > myLength)
/*  967 */       throw new BadLocationException(); 
/*  968 */     return getStore().get(pos, length);
/*      */   }
/*      */ 
/*      */   
/*      */   public void insertPositionUpdater(IPositionUpdater updater, int index) {
/*  973 */     for (IPositionUpdater u : this.fPositionUpdaters) {
/*  974 */       if (u == updater) {
/*      */         return;
/*      */       }
/*      */     } 
/*  978 */     this.fPositionUpdaters.add(index, updater);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void removePosition(String category, Position position) throws BadPositionCategoryException {
/*  984 */     if (position == null) {
/*      */       return;
/*      */     }
/*  987 */     if (category == null) {
/*  988 */       throw new BadPositionCategoryException();
/*      */     }
/*  990 */     List<Position> c = this.fPositions.get(category);
/*  991 */     if (c == null)
/*  992 */       throw new BadPositionCategoryException(); 
/*  993 */     removeFromPositionsList(c, position, true);
/*      */     
/*  995 */     List<Position> endPositions = this.fEndPositions.get(category);
/*  996 */     if (endPositions == null)
/*  997 */       throw new BadPositionCategoryException(); 
/*  998 */     removeFromPositionsList(endPositions, position, false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void removeFromPositionsList(List<Position> positions, Position position, boolean orderedByOffset) {
/* 1010 */     int size = positions.size();
/*      */ 
/*      */     
/* 1013 */     int index = computeIndexInPositionList(positions, orderedByOffset ? position.offset : (position.offset + position.length - 1), orderedByOffset);
/* 1014 */     if (index < size && positions.get(index) == position) {
/* 1015 */       positions.remove(index);
/*      */       
/*      */       return;
/*      */     } 
/* 1019 */     int back = index - 1;
/* 1020 */     int forth = index + 1;
/* 1021 */     while (back >= 0 || forth < size) {
/* 1022 */       if (back >= 0) {
/* 1023 */         if (position == positions.get(back)) {
/* 1024 */           positions.remove(back);
/*      */           return;
/*      */         } 
/* 1027 */         back--;
/*      */       } 
/*      */       
/* 1030 */       if (forth < size) {
/* 1031 */         if (position == positions.get(forth)) {
/* 1032 */           positions.remove(forth);
/*      */           return;
/*      */         } 
/* 1035 */         forth++;
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public void removePosition(Position position) {
/*      */     try {
/* 1043 */       removePosition("__dflt_position_category", position);
/* 1044 */     } catch (BadPositionCategoryException badPositionCategoryException) {}
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void removePositionCategory(String category) throws BadPositionCategoryException {
/* 1051 */     if (category == null) {
/*      */       return;
/*      */     }
/* 1054 */     if (!containsPositionCategory(category)) {
/* 1055 */       throw new BadPositionCategoryException();
/*      */     }
/* 1057 */     this.fPositions.remove(category);
/* 1058 */     this.fEndPositions.remove(category);
/*      */   }
/*      */ 
/*      */   
/*      */   public void removePositionUpdater(IPositionUpdater updater) {
/* 1063 */     for (int i = this.fPositionUpdaters.size() - 1; i >= 0; i--) {
/* 1064 */       if (this.fPositionUpdaters.get(i) == updater) {
/* 1065 */         this.fPositionUpdaters.remove(i);
/*      */         return;
/*      */       } 
/*      */     } 
/*      */   }
/*      */   
/*      */   private long getNextModificationStamp() {
/* 1072 */     if (this.fNextModificationStamp == Long.MAX_VALUE || this.fNextModificationStamp == -1L) {
/* 1073 */       this.fNextModificationStamp = 0L;
/*      */     } else {
/* 1075 */       this.fNextModificationStamp++;
/*      */     } 
/* 1077 */     return this.fNextModificationStamp;
/*      */   }
/*      */ 
/*      */   
/*      */   public long getModificationStamp() {
/* 1082 */     return this.fModificationStamp;
/*      */   }
/*      */ 
/*      */   
/*      */   public void replace(int pos, int length, String text, long modificationStamp) throws BadLocationException {
/* 1087 */     if (pos < 0 || length < 0 || pos + length > getLength()) {
/* 1088 */       throw new BadLocationException();
/*      */     }
/* 1090 */     DocumentEvent e = new DocumentEvent(this, pos, length, text);
/* 1091 */     fireDocumentAboutToBeChanged(e);
/*      */     
/* 1093 */     getStore().replace(pos, length, text);
/* 1094 */     getTracker().replace(pos, length, text);
/*      */     
/* 1096 */     this.fModificationStamp = modificationStamp;
/* 1097 */     this.fNextModificationStamp = Math.max(this.fModificationStamp, this.fNextModificationStamp);
/* 1098 */     e.fModificationStamp = this.fModificationStamp;
/*      */     
/* 1100 */     fireDocumentChanged(e);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isLineInformationRepairNeeded(int offset, int length, String text) throws BadLocationException {
/* 1110 */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   public void replace(int pos, int length, String text) throws BadLocationException {
/* 1115 */     if (length == 0 && (text == null || text.isEmpty())) {
/* 1116 */       replace(pos, length, text, getModificationStamp());
/*      */     } else {
/* 1118 */       replace(pos, length, text, getNextModificationStamp());
/*      */     } 
/*      */   }
/*      */   
/*      */   public void set(String text) {
/* 1123 */     set(text, getNextModificationStamp());
/*      */   }
/*      */ 
/*      */   
/*      */   public void set(String text, long modificationStamp) {
/* 1128 */     int length = getStore().getLength();
/*      */     
/* 1130 */     DocumentEvent e = new DocumentEvent(this, 0, length, text);
/* 1131 */     fireDocumentAboutToBeChanged(e);
/*      */     
/* 1133 */     getStore().set(text);
/* 1134 */     getTracker().set(text);
/*      */     
/* 1136 */     this.fModificationStamp = modificationStamp;
/* 1137 */     this.fNextModificationStamp = Math.max(this.fModificationStamp, this.fNextModificationStamp);
/* 1138 */     e.fModificationStamp = this.fModificationStamp;
/*      */     
/* 1140 */     fireDocumentChanged(e);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void updatePositions(DocumentEvent event) {
/* 1152 */     for (IPositionUpdater u : this.fPositionUpdaters) {
/* 1153 */       u.update(event);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public int search(int startPosition, String findString, boolean forwardSearch, boolean caseSensitive, boolean wholeWord) throws BadLocationException {
/*      */     try {
/* 1166 */       IRegion region = getFindReplaceDocumentAdapter().find(startPosition, findString, forwardSearch, caseSensitive, wholeWord, false);
/* 1167 */       return (region == null) ? -1 : region.getOffset();
/* 1168 */     } catch (IllegalStateException illegalStateException) {
/* 1169 */       return -1;
/* 1170 */     } catch (PatternSyntaxException patternSyntaxException) {
/* 1171 */       return -1;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private FindReplaceDocumentAdapter getFindReplaceDocumentAdapter() {
/* 1182 */     if (this.fFindReplaceDocumentAdapter == null) {
/* 1183 */       this.fFindReplaceDocumentAdapter = new FindReplaceDocumentAdapter(this);
/*      */     }
/* 1185 */     return this.fFindReplaceDocumentAdapter;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void flushPostNotificationChanges() {
/* 1194 */     if (this.fPostNotificationChanges != null) {
/* 1195 */       this.fPostNotificationChanges.clear();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void executePostNotificationChanges() {
/* 1206 */     if (this.fStoppedCount > 0) {
/*      */       return;
/*      */     }
/* 1209 */     while (this.fPostNotificationChanges != null) {
/* 1210 */       List<RegisteredReplace> changes = this.fPostNotificationChanges;
/* 1211 */       this.fPostNotificationChanges = null;
/*      */       
/* 1213 */       Iterator<RegisteredReplace> e = changes.iterator();
/* 1214 */       while (e.hasNext()) {
/* 1215 */         RegisteredReplace replace = e.next();
/* 1216 */         replace.fReplace.perform(this, replace.fOwner);
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public void acceptPostNotificationReplaces() {
/* 1223 */     this.fAcceptPostNotificationReplaces = true;
/*      */   }
/*      */ 
/*      */   
/*      */   public void ignorePostNotificationReplaces() {
/* 1228 */     this.fAcceptPostNotificationReplaces = false;
/*      */   }
/*      */ 
/*      */   
/*      */   public void registerPostNotificationReplace(IDocumentListener owner, IDocumentExtension.IReplace replace) {
/* 1233 */     if (this.fAcceptPostNotificationReplaces) {
/* 1234 */       if (this.fPostNotificationChanges == null)
/* 1235 */         this.fPostNotificationChanges = new ArrayList<>(1); 
/* 1236 */       this.fPostNotificationChanges.add(new RegisteredReplace(owner, replace));
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public void stopPostNotificationProcessing() {
/* 1242 */     this.fStoppedCount++;
/*      */   }
/*      */ 
/*      */   
/*      */   public void resumePostNotificationProcessing() {
/* 1247 */     this.fStoppedCount--;
/* 1248 */     if (this.fStoppedCount == 0 && this.fReentranceCount == 0) {
/* 1249 */       executePostNotificationChanges();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public void startSequentialRewrite(boolean normalized) {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public void stopSequentialRewrite() {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void resumeListenerNotification() {
/* 1278 */     this.fStoppedListenerNotification--;
/* 1279 */     if (this.fStoppedListenerNotification == 0) {
/* 1280 */       resumeDocumentListenerNotification();
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   public void stopListenerNotification() {
/* 1286 */     this.fStoppedListenerNotification++;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void resumeDocumentListenerNotification() {
/* 1296 */     if (this.fDeferredDocumentEvent != null) {
/* 1297 */       DocumentEvent event = this.fDeferredDocumentEvent;
/* 1298 */       this.fDeferredDocumentEvent = null;
/* 1299 */       doFireDocumentChanged(event);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ITypedRegion[] computePartitioning(String partitioning, int offset, int length, boolean includeZeroLengthPartitions) throws BadLocationException, BadPartitioningException {
/* 1309 */     if (offset < 0 || length < 0 || offset + length > getLength()) {
/* 1310 */       throw new BadLocationException();
/*      */     }
/* 1312 */     IDocumentPartitioner partitioner = getDocumentPartitioner(partitioning);
/*      */     
/* 1314 */     if (partitioner instanceof IDocumentPartitionerExtension2) {
/* 1315 */       checkStateOfPartitioner(partitioner, partitioning);
/* 1316 */       return ((IDocumentPartitionerExtension2)partitioner).computePartitioning(offset, length, includeZeroLengthPartitions);
/* 1317 */     }  if (partitioner != null) {
/* 1318 */       checkStateOfPartitioner(partitioner, partitioning);
/* 1319 */       return partitioner.computePartitioning(offset, length);
/* 1320 */     }  if ("__dftl_partitioning".equals(partitioning)) {
/* 1321 */       return (ITypedRegion[])new TypedRegion[] { new TypedRegion(offset, length, "__dftl_partition_content_type") };
/*      */     }
/* 1323 */     throw new BadPartitioningException();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getContentType(String partitioning, int offset, boolean preferOpenPartitions) throws BadLocationException, BadPartitioningException {
/* 1332 */     if (offset < 0 || offset > getLength()) {
/* 1333 */       throw new BadLocationException();
/*      */     }
/* 1335 */     IDocumentPartitioner partitioner = getDocumentPartitioner(partitioning);
/*      */     
/* 1337 */     if (partitioner instanceof IDocumentPartitionerExtension2) {
/* 1338 */       checkStateOfPartitioner(partitioner, partitioning);
/* 1339 */       return ((IDocumentPartitionerExtension2)partitioner).getContentType(offset, preferOpenPartitions);
/* 1340 */     }  if (partitioner != null) {
/* 1341 */       checkStateOfPartitioner(partitioner, partitioning);
/* 1342 */       return partitioner.getContentType(offset);
/* 1343 */     }  if ("__dftl_partitioning".equals(partitioning)) {
/* 1344 */       return "__dftl_partition_content_type";
/*      */     }
/* 1346 */     throw new BadPartitioningException();
/*      */   }
/*      */ 
/*      */   
/*      */   public IDocumentPartitioner getDocumentPartitioner(String partitioning) {
/* 1351 */     return (this.fDocumentPartitioners != null) ? this.fDocumentPartitioners.get(partitioning) : null;
/*      */   }
/*      */ 
/*      */   
/*      */   public String[] getLegalContentTypes(String partitioning) throws BadPartitioningException {
/* 1356 */     IDocumentPartitioner partitioner = getDocumentPartitioner(partitioning);
/* 1357 */     if (partitioner != null)
/* 1358 */       return partitioner.getLegalContentTypes(); 
/* 1359 */     if ("__dftl_partitioning".equals(partitioning))
/* 1360 */       return new String[] { "__dftl_partition_content_type" }; 
/* 1361 */     throw new BadPartitioningException();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ITypedRegion getPartition(String partitioning, int offset, boolean preferOpenPartitions) throws BadLocationException, BadPartitioningException {
/* 1370 */     if (offset < 0 || offset > getLength()) {
/* 1371 */       throw new BadLocationException();
/*      */     }
/* 1373 */     IDocumentPartitioner partitioner = getDocumentPartitioner(partitioning);
/*      */     
/* 1375 */     if (partitioner instanceof IDocumentPartitionerExtension2) {
/* 1376 */       checkStateOfPartitioner(partitioner, partitioning);
/* 1377 */       return ((IDocumentPartitionerExtension2)partitioner).getPartition(offset, preferOpenPartitions);
/* 1378 */     }  if (partitioner != null) {
/* 1379 */       checkStateOfPartitioner(partitioner, partitioning);
/* 1380 */       return partitioner.getPartition(offset);
/* 1381 */     }  if ("__dftl_partitioning".equals(partitioning)) {
/* 1382 */       return new TypedRegion(0, getLength(), "__dftl_partition_content_type");
/*      */     }
/* 1384 */     throw new BadPartitioningException();
/*      */   }
/*      */ 
/*      */   
/*      */   public String[] getPartitionings() {
/* 1389 */     if (this.fDocumentPartitioners == null)
/* 1390 */       return new String[0]; 
/* 1391 */     String[] partitionings = new String[this.fDocumentPartitioners.size()];
/* 1392 */     this.fDocumentPartitioners.keySet().toArray((Object[])partitionings);
/* 1393 */     return partitionings;
/*      */   }
/*      */ 
/*      */   
/*      */   public void setDocumentPartitioner(String partitioning, IDocumentPartitioner partitioner) {
/* 1398 */     if (partitioner == null) {
/* 1399 */       if (this.fDocumentPartitioners != null) {
/* 1400 */         this.fDocumentPartitioners.remove(partitioning);
/* 1401 */         if (this.fDocumentPartitioners.isEmpty())
/* 1402 */           this.fDocumentPartitioners = null; 
/*      */       } 
/*      */     } else {
/* 1405 */       if (this.fDocumentPartitioners == null)
/* 1406 */         this.fDocumentPartitioners = new HashMap<>(); 
/* 1407 */       this.fDocumentPartitioners.put(partitioning, partitioner);
/*      */     } 
/* 1409 */     DocumentPartitioningChangedEvent event = new DocumentPartitioningChangedEvent(this);
/* 1410 */     event.setPartitionChange(partitioning, 0, getLength());
/* 1411 */     fireDocumentPartitioningChanged(event);
/*      */   }
/*      */ 
/*      */   
/*      */   public void repairLineInformation() {
/* 1416 */     getTracker().set(get());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void fireRewriteSessionChanged(DocumentRewriteSessionEvent event) {
/* 1426 */     if (!this.fDocumentRewriteSessionListeners.isEmpty()) {
/* 1427 */       List<IDocumentRewriteSessionListener> list = new ArrayList<>(this.fDocumentRewriteSessionListeners);
/* 1428 */       Iterator<IDocumentRewriteSessionListener> e = list.iterator();
/* 1429 */       while (e.hasNext()) {
/*      */         try {
/* 1431 */           IDocumentRewriteSessionListener l = e.next();
/* 1432 */           l.documentRewriteSessionChanged(event);
/* 1433 */         } catch (Exception ex) {
/* 1434 */           log(ex);
/*      */         } 
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public final DocumentRewriteSession getActiveRewriteSession() {
/* 1442 */     return this.fDocumentRewriteSession;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public DocumentRewriteSession startRewriteSession(DocumentRewriteSessionType sessionType) {
/* 1448 */     if (getActiveRewriteSession() != null) {
/* 1449 */       throw new IllegalStateException();
/*      */     }
/*      */     
/* 1452 */     this.fDocumentRewriteSession = new DocumentRewriteSession(sessionType);
/*      */ 
/*      */ 
/*      */     
/* 1456 */     fireRewriteSessionChanged(new DocumentRewriteSessionEvent(this, this.fDocumentRewriteSession, DocumentRewriteSessionEvent.SESSION_START));
/*      */     
/* 1458 */     startRewriteSessionOnPartitioners(this.fDocumentRewriteSession);
/*      */     
/* 1460 */     ILineTracker tracker = getTracker();
/* 1461 */     if (tracker instanceof ILineTrackerExtension) {
/* 1462 */       ILineTrackerExtension extension = (ILineTrackerExtension)tracker;
/* 1463 */       extension.startRewriteSession(this.fDocumentRewriteSession);
/*      */     } 
/*      */     
/* 1466 */     if (DocumentRewriteSessionType.SEQUENTIAL == sessionType) {
/* 1467 */       startSequentialRewrite(false);
/* 1468 */     } else if (DocumentRewriteSessionType.STRICTLY_SEQUENTIAL == sessionType) {
/* 1469 */       startSequentialRewrite(true);
/*      */     } 
/* 1471 */     return this.fDocumentRewriteSession;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final void startRewriteSessionOnPartitioners(DocumentRewriteSession session) {
/* 1481 */     if (this.fDocumentPartitioners != null) {
/* 1482 */       Iterator<IDocumentPartitioner> e = this.fDocumentPartitioners.values().iterator();
/* 1483 */       while (e.hasNext()) {
/* 1484 */         Object partitioner = e.next();
/* 1485 */         if (partitioner instanceof IDocumentPartitionerExtension3) {
/* 1486 */           IDocumentPartitionerExtension3 extension = (IDocumentPartitionerExtension3)partitioner;
/* 1487 */           extension.startRewriteSession(session);
/*      */         } 
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public void stopRewriteSession(DocumentRewriteSession session) {
/* 1495 */     if (this.fDocumentRewriteSession != null && this.fDocumentRewriteSession == session) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1500 */       DocumentRewriteSessionType sessionType = session.getSessionType();
/* 1501 */       if (DocumentRewriteSessionType.SEQUENTIAL == sessionType || DocumentRewriteSessionType.STRICTLY_SEQUENTIAL == sessionType) {
/* 1502 */         stopSequentialRewrite();
/*      */       }
/* 1504 */       ILineTracker tracker = getTracker();
/* 1505 */       if (tracker instanceof ILineTrackerExtension) {
/* 1506 */         ILineTrackerExtension extension = (ILineTrackerExtension)tracker;
/* 1507 */         extension.stopRewriteSession(session, get());
/*      */       } 
/*      */       
/* 1510 */       stopRewriteSessionOnPartitioners(this.fDocumentRewriteSession);
/*      */       
/* 1512 */       this.fDocumentRewriteSession = null;
/* 1513 */       fireRewriteSessionChanged(new DocumentRewriteSessionEvent(this, session, DocumentRewriteSessionEvent.SESSION_STOP));
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final void stopRewriteSessionOnPartitioners(DocumentRewriteSession session) {
/* 1524 */     if (this.fDocumentPartitioners != null) {
/* 1525 */       DocumentPartitioningChangedEvent event = new DocumentPartitioningChangedEvent(this);
/* 1526 */       for (Map.Entry<String, IDocumentPartitioner> entry : this.fDocumentPartitioners.entrySet()) {
/* 1527 */         String partitioning = entry.getKey();
/* 1528 */         IDocumentPartitioner partitioner = entry.getValue();
/* 1529 */         if (partitioner instanceof IDocumentPartitionerExtension3) {
/* 1530 */           IDocumentPartitionerExtension3 extension = (IDocumentPartitionerExtension3)partitioner;
/* 1531 */           extension.stopRewriteSession(session);
/* 1532 */           event.setPartitionChange(partitioning, 0, getLength());
/*      */         } 
/*      */       } 
/* 1535 */       if (!event.isEmpty()) {
/* 1536 */         fireDocumentPartitioningChanged(event);
/*      */       }
/*      */     } 
/*      */   }
/*      */   
/*      */   public void addDocumentRewriteSessionListener(IDocumentRewriteSessionListener listener) {
/* 1542 */     Assert.isNotNull(listener);
/* 1543 */     if (!this.fDocumentRewriteSessionListeners.contains(listener)) {
/* 1544 */       this.fDocumentRewriteSessionListeners.add(listener);
/*      */     }
/*      */   }
/*      */   
/*      */   public void removeDocumentRewriteSessionListener(IDocumentRewriteSessionListener listener) {
/* 1549 */     Assert.isNotNull(listener);
/* 1550 */     this.fDocumentRewriteSessionListeners.remove(listener);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final void checkStateOfPartitioner(IDocumentPartitioner partitioner, String partitioning) {
/* 1562 */     if (!(partitioner instanceof IDocumentPartitionerExtension3)) {
/*      */       return;
/*      */     }
/* 1565 */     IDocumentPartitionerExtension3 extension = (IDocumentPartitionerExtension3)partitioner;
/* 1566 */     DocumentRewriteSession session = extension.getActiveRewriteSession();
/* 1567 */     if (session != null) {
/* 1568 */       extension.stopRewriteSession(session);
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1573 */       DocumentPartitioningChangedEvent event = new DocumentPartitioningChangedEvent(this);
/* 1574 */       event.setPartitionChange(partitioning, 0, getLength());
/* 1575 */       fireDocumentPartitioningChanged(event);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Position[] getPositions(String category, int offset, int length, boolean canStartBefore, boolean canEndAfter) throws BadPositionCategoryException {
/* 1594 */     if ((canStartBefore && canEndAfter) || (!canStartBefore && !canEndAfter)) {
/*      */       List<Position> documentPositions;
/* 1596 */       if (canStartBefore && canEndAfter) {
/* 1597 */         if (offset < getLength() / 2) {
/* 1598 */           documentPositions = getStartingPositions(category, 0, offset + length);
/*      */         } else {
/* 1600 */           documentPositions = getEndingPositions(category, offset, getLength() - offset + 1);
/*      */         } 
/*      */       } else {
/* 1603 */         documentPositions = getStartingPositions(category, offset, length);
/*      */       } 
/*      */       
/* 1606 */       ArrayList<Position> arrayList = new ArrayList<>(documentPositions.size());
/*      */       
/* 1608 */       Position region = new Position(offset, length);
/*      */       
/* 1610 */       for (Position position : documentPositions) {
/* 1611 */         if (isWithinRegion(region, position, canStartBefore, canEndAfter)) {
/* 1612 */           arrayList.add(position);
/*      */         }
/*      */       } 
/*      */       
/* 1616 */       Position[] arrayOfPosition = new Position[arrayList.size()];
/* 1617 */       arrayList.toArray(arrayOfPosition);
/* 1618 */       return arrayOfPosition;
/* 1619 */     }  if (canStartBefore) {
/* 1620 */       List<Position> list1 = getEndingPositions(category, offset, length);
/* 1621 */       Position[] arrayOfPosition = new Position[list1.size()];
/* 1622 */       list1.toArray(arrayOfPosition);
/* 1623 */       return arrayOfPosition;
/*      */     } 
/* 1625 */     Assert.isLegal((canEndAfter && !canStartBefore));
/*      */     
/* 1627 */     List<Position> list = getStartingPositions(category, offset, length);
/* 1628 */     Position[] positions = new Position[list.size()];
/* 1629 */     list.toArray(positions);
/* 1630 */     return positions;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean isWithinRegion(Position region, Position position, boolean canStartBefore, boolean canEndAfter) {
/* 1638 */     if (canStartBefore && canEndAfter)
/* 1639 */       return region.overlapsWith(position.getOffset(), position.getLength()); 
/* 1640 */     if (canStartBefore)
/* 1641 */       return region.includes(position.getOffset() + position.getLength() - 1); 
/* 1642 */     if (canEndAfter) {
/* 1643 */       return region.includes(position.getOffset());
/*      */     }
/* 1645 */     int start = position.getOffset();
/* 1646 */     return (region.includes(start) && region.includes(start + position.getLength() - 1));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private List<Position> getStartingPositions(String category, int offset, int length) throws BadPositionCategoryException {
/* 1662 */     List<Position> positions = this.fPositions.get(category);
/* 1663 */     if (positions == null) {
/* 1664 */       throw new BadPositionCategoryException();
/*      */     }
/* 1666 */     int indexStart = computeIndexInPositionList(positions, offset, true);
/* 1667 */     int indexEnd = computeIndexInPositionList(positions, offset + length, true);
/*      */     
/* 1669 */     return positions.subList(indexStart, indexEnd);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private List<Position> getEndingPositions(String category, int offset, int length) throws BadPositionCategoryException {
/* 1684 */     List<Position> positions = this.fEndPositions.get(category);
/* 1685 */     if (positions == null) {
/* 1686 */       throw new BadPositionCategoryException();
/*      */     }
/* 1688 */     int indexStart = computeIndexInPositionList(positions, offset, false);
/* 1689 */     int indexEnd = computeIndexInPositionList(positions, offset + length, false);
/*      */     
/* 1691 */     return positions.subList(indexStart, indexEnd);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static void log(final Exception ex) {
/* 1701 */     SafeRunner.run(new ISafeRunnable()
/*      */         {
/*      */           public void run() throws Exception {
/* 1704 */             throw ex;
/*      */           }
/*      */           
/*      */           public void handleException(Throwable exception) {}
/*      */         });
/*      */   }
/*      */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.text-3.13.0.jar!\org\eclipse\jface\text\AbstractDocument.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */