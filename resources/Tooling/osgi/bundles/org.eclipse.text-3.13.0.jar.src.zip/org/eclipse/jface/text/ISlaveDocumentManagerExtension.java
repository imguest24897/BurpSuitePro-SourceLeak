package org.eclipse.jface.text;

public interface ISlaveDocumentManagerExtension {
  IDocument[] getSlaveDocuments(IDocument paramIDocument);
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.text-3.13.0.jar!\org\eclipse\jface\text\ISlaveDocumentManagerExtension.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */