/*     */ package org.eclipse.jface.text;
/*     */ 
/*     */ import java.util.regex.Matcher;
/*     */ import java.util.regex.Pattern;
/*     */ import java.util.regex.PatternSyntaxException;
/*     */ import org.eclipse.core.runtime.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FindReplaceDocumentAdapter
/*     */   implements CharSequence
/*     */ {
/*     */   private static class FindReplaceOperationCode {}
/*     */   
/*  43 */   private static final FindReplaceOperationCode FIND_FIRST = new FindReplaceOperationCode();
/*  44 */   private static final FindReplaceOperationCode FIND_NEXT = new FindReplaceOperationCode();
/*  45 */   private static final FindReplaceOperationCode REPLACE = new FindReplaceOperationCode();
/*  46 */   private static final FindReplaceOperationCode REPLACE_FIND_NEXT = new FindReplaceOperationCode();
/*     */ 
/*     */ 
/*     */   
/*     */   private static final int RC_MIXED = 0;
/*     */ 
/*     */ 
/*     */   
/*     */   private static final int RC_UPPER = 1;
/*     */ 
/*     */   
/*     */   private static final int RC_LOWER = 2;
/*     */ 
/*     */   
/*     */   private static final int RC_FIRSTUPPER = 3;
/*     */ 
/*     */   
/*     */   private IDocument fDocument;
/*     */ 
/*     */   
/*  66 */   private FindReplaceOperationCode fFindReplaceState = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Matcher fFindReplaceMatcher;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int fFindReplaceMatchOffset;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int fRetainCaseMode;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public FindReplaceDocumentAdapter(IDocument document) {
/*  89 */     Assert.isNotNull(document);
/*  90 */     this.fDocument = document;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IRegion find(int startOffset, String findString, boolean forwardSearch, boolean caseSensitive, boolean wholeWord, boolean regExSearch) throws BadLocationException {
/* 109 */     Assert.isTrue(!(regExSearch && wholeWord));
/*     */ 
/*     */     
/* 112 */     if (startOffset == -1 && forwardSearch)
/* 113 */       startOffset = 0; 
/* 114 */     if (startOffset == -1 && !forwardSearch) {
/* 115 */       startOffset = length() - 1;
/*     */     }
/* 117 */     return findReplace(FIND_FIRST, startOffset, findString, null, forwardSearch, caseSensitive, wholeWord, regExSearch);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private IRegion findReplace(FindReplaceOperationCode operationCode, int startOffset, String findString, String replaceText, boolean forwardSearch, boolean caseSensitive, boolean wholeWord, boolean regExSearch) throws BadLocationException {
/* 146 */     Assert.isTrue(!(regExSearch && wholeWord));
/*     */ 
/*     */     
/* 149 */     if ((operationCode == REPLACE || operationCode == REPLACE_FIND_NEXT) && this.fFindReplaceState != FIND_FIRST && this.fFindReplaceState != FIND_NEXT) {
/* 150 */       throw new IllegalStateException("illegal findReplace state: cannot replace without preceding find");
/*     */     }
/* 152 */     if (operationCode == FIND_FIRST) {
/*     */ 
/*     */       
/* 155 */       if (findString == null || findString.isEmpty()) {
/* 156 */         return null;
/*     */       }
/*     */       
/* 159 */       if (startOffset < 0 || startOffset > length()) {
/* 160 */         throw new BadLocationException();
/*     */       }
/* 162 */       int patternFlags = 0;
/*     */       
/* 164 */       if (regExSearch) {
/* 165 */         patternFlags |= 0x8;
/* 166 */         findString = substituteLinebreak(findString);
/*     */       } 
/*     */       
/* 169 */       if (!caseSensitive) {
/* 170 */         patternFlags |= 0x42;
/*     */       }
/* 172 */       if (!regExSearch) {
/* 173 */         findString = asRegPattern(findString);
/*     */       }
/* 175 */       if (wholeWord) {
/* 176 */         findString = "\\b" + findString + "\\b";
/*     */       }
/* 178 */       this.fFindReplaceMatchOffset = startOffset;
/* 179 */       if (this.fFindReplaceMatcher == null || !this.fFindReplaceMatcher.pattern().pattern().equals(findString) || this.fFindReplaceMatcher.pattern().flags() != patternFlags) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 186 */         Pattern pattern = Pattern.compile(findString, patternFlags);
/* 187 */         this.fFindReplaceMatcher = pattern.matcher(this);
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 192 */     this.fFindReplaceState = operationCode;
/*     */     
/* 194 */     if (operationCode == REPLACE || operationCode == REPLACE_FIND_NEXT) {
/* 195 */       if (regExSearch) {
/* 196 */         Pattern pattern = this.fFindReplaceMatcher.pattern();
/* 197 */         String prevMatch = this.fFindReplaceMatcher.group();
/*     */         try {
/* 199 */           replaceText = interpretReplaceEscapes(replaceText, prevMatch);
/* 200 */           Matcher replaceTextMatcher = pattern.matcher(prevMatch);
/* 201 */           replaceText = replaceTextMatcher.replaceFirst(replaceText);
/* 202 */         } catch (IndexOutOfBoundsException ex) {
/* 203 */           throw new PatternSyntaxException(ex.getLocalizedMessage(), replaceText, -1);
/*     */         } 
/*     */       } 
/*     */       
/* 207 */       int offset = this.fFindReplaceMatcher.start();
/* 208 */       int length = this.fFindReplaceMatcher.group().length();
/*     */       
/* 210 */       if (this.fDocument instanceof IRepairableDocumentExtension && (
/* 211 */         (IRepairableDocumentExtension)this.fDocument).isLineInformationRepairNeeded(offset, length, replaceText)) {
/* 212 */         String message = TextMessages.getString("FindReplaceDocumentAdapter.incompatibleLineDelimiter");
/* 213 */         throw new PatternSyntaxException(message, replaceText, offset);
/*     */       } 
/*     */       
/* 216 */       this.fDocument.replace(offset, length, replaceText);
/*     */       
/* 218 */       if (operationCode == REPLACE) {
/* 219 */         return new Region(offset, replaceText.length());
/*     */       }
/*     */     } 
/*     */     
/* 223 */     if (operationCode != REPLACE) {
/*     */       try {
/* 225 */         if (forwardSearch) {
/*     */           
/* 227 */           boolean bool = false;
/* 228 */           if (operationCode == FIND_FIRST) {
/* 229 */             bool = this.fFindReplaceMatcher.find(startOffset);
/*     */           } else {
/* 231 */             bool = this.fFindReplaceMatcher.find();
/*     */           } 
/* 233 */           if (operationCode == REPLACE_FIND_NEXT) {
/* 234 */             this.fFindReplaceState = FIND_NEXT;
/*     */           }
/* 236 */           if (bool && !this.fFindReplaceMatcher.group().isEmpty())
/* 237 */             return new Region(this.fFindReplaceMatcher.start(), this.fFindReplaceMatcher.group().length()); 
/* 238 */           return null;
/*     */         } 
/*     */         
/* 241 */         boolean found = this.fFindReplaceMatcher.find(0);
/* 242 */         int index = -1;
/* 243 */         int length = -1;
/* 244 */         while (found && this.fFindReplaceMatcher.start() + this.fFindReplaceMatcher.group().length() <= this.fFindReplaceMatchOffset + 1) {
/* 245 */           index = this.fFindReplaceMatcher.start();
/* 246 */           length = this.fFindReplaceMatcher.group().length();
/* 247 */           found = this.fFindReplaceMatcher.find(index + 1);
/*     */         } 
/* 249 */         this.fFindReplaceMatchOffset = index;
/* 250 */         if (index > -1) {
/*     */           
/* 252 */           this.fFindReplaceMatcher.find(index);
/* 253 */           return new Region(index, length);
/*     */         } 
/* 255 */         return null;
/* 256 */       } catch (StackOverflowError stackOverflowError) {
/* 257 */         String message = TextMessages.getString("FindReplaceDocumentAdapter.patternTooComplex");
/* 258 */         throw new PatternSyntaxException(message, findString, -1);
/*     */       } 
/*     */     }
/*     */     
/* 262 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String substituteLinebreak(String findString) throws PatternSyntaxException {
/* 274 */     int length = findString.length();
/* 275 */     StringBuilder buf = new StringBuilder(length);
/*     */     
/* 277 */     int inCharGroup = 0;
/* 278 */     int inBraces = 0;
/* 279 */     boolean inQuote = false;
/* 280 */     for (int i = 0; i < length; i++) {
/* 281 */       char ch = findString.charAt(i);
/* 282 */       switch (ch) {
/*     */         case '[':
/* 284 */           buf.append(ch);
/* 285 */           if (!inQuote) {
/* 286 */             inCharGroup++;
/*     */           }
/*     */           break;
/*     */         case ']':
/* 290 */           buf.append(ch);
/* 291 */           if (!inQuote) {
/* 292 */             inCharGroup--;
/*     */           }
/*     */           break;
/*     */         case '{':
/* 296 */           buf.append(ch);
/* 297 */           if (!inQuote && inCharGroup == 0) {
/* 298 */             inBraces++;
/*     */           }
/*     */           break;
/*     */         case '}':
/* 302 */           buf.append(ch);
/* 303 */           if (!inQuote && inCharGroup == 0) {
/* 304 */             inBraces--;
/*     */           }
/*     */           break;
/*     */         case '\\':
/* 308 */           if (i + 1 < length) {
/* 309 */             char ch1 = findString.charAt(i + 1);
/* 310 */             if (inQuote) {
/* 311 */               if (ch1 == 'E')
/* 312 */                 inQuote = false; 
/* 313 */               buf.append(ch).append(ch1);
/* 314 */               i++; break;
/*     */             } 
/* 316 */             if (ch1 == 'R') {
/* 317 */               if (inCharGroup > 0 || inBraces > 0) {
/* 318 */                 String msg = TextMessages.getString("FindReplaceDocumentAdapter.illegalLinebreak");
/* 319 */                 throw new PatternSyntaxException(msg, findString, i);
/*     */               } 
/* 321 */               buf.append("(?>\\r\\n?|\\n)");
/* 322 */               i++;
/*     */               break;
/*     */             } 
/* 325 */             if (ch1 == 'Q') {
/* 326 */               inQuote = true;
/*     */             }
/* 328 */             buf.append(ch).append(ch1);
/* 329 */             i++;
/*     */             break;
/*     */           } 
/* 332 */           buf.append(ch);
/*     */           break;
/*     */ 
/*     */         
/*     */         default:
/* 337 */           buf.append(ch);
/*     */           break;
/*     */       } 
/*     */     
/*     */     } 
/* 342 */     return buf.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void interpretRetainCase(StringBuilder buf, char ch) {
/* 354 */     if (this.fRetainCaseMode == 1) {
/* 355 */       buf.append(String.valueOf(ch).toUpperCase());
/* 356 */     } else if (this.fRetainCaseMode == 2) {
/* 357 */       buf.append(String.valueOf(ch).toLowerCase());
/* 358 */     } else if (this.fRetainCaseMode == 3) {
/* 359 */       buf.append(String.valueOf(ch).toUpperCase());
/* 360 */       this.fRetainCaseMode = 0;
/*     */     } else {
/* 362 */       buf.append(ch);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String interpretReplaceEscapes(String replaceText, String foundText) {
/* 374 */     int length = replaceText.length();
/* 375 */     boolean inEscape = false;
/* 376 */     StringBuilder buf = new StringBuilder(length);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 381 */     this.fRetainCaseMode = 0;
/*     */     
/* 383 */     for (int i = 0; i < length; i++) {
/* 384 */       char ch = replaceText.charAt(i);
/* 385 */       if (inEscape) {
/* 386 */         i = interpretReplaceEscape(ch, i, buf, replaceText, foundText);
/* 387 */         inEscape = false;
/*     */       }
/* 389 */       else if (ch == '\\') {
/* 390 */         inEscape = true;
/*     */       }
/* 392 */       else if (ch == '$') {
/* 393 */         buf.append(ch);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 405 */         if (i + 2 < length) {
/* 406 */           char ch1 = replaceText.charAt(i + 1);
/* 407 */           char ch2 = replaceText.charAt(i + 2);
/* 408 */           if (ch1 == '0' && '0' <= ch2 && ch2 <= '9') {
/* 409 */             buf.append("0\\");
/* 410 */             i++;
/*     */           } 
/*     */         } 
/*     */       } else {
/* 414 */         interpretRetainCase(buf, ch);
/*     */       } 
/*     */     } 
/*     */     
/* 418 */     if (inEscape)
/*     */     {
/* 420 */       buf.append('\\');
/*     */     }
/* 422 */     return buf.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int interpretReplaceEscape(char ch, int i, StringBuilder buf, String replaceText, String foundText) {
/* 438 */     int length = replaceText.length();
/* 439 */     switch (ch)
/*     */     { case 'r':
/* 441 */         buf.append('\r');
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 556 */         return i;case 'n': buf.append('\n'); return i;case 't': buf.append('\t'); return i;case 'f': buf.append('\f'); return i;case 'a': buf.append('\007'); return i;case 'e': buf.append('\033'); return i;case 'R': buf.append(TextUtilities.getDefaultLineDelimiter(this.fDocument)); return i;case '0': buf.append('$').append(ch); if (i + 1 < length) { char ch1 = replaceText.charAt(i + 1); if ('0' <= ch1 && ch1 <= '9') buf.append('\\');  }  return i;case '1': case '2': case '3': case '4': case '5': case '6': case '7': case '8': case '9': buf.append('$').append(ch); return i;case 'c': if (i + 1 < length) { char ch1 = replaceText.charAt(i + 1); interpretRetainCase(buf, (char)(ch1 ^ 0x40)); i++; } else { String msg = TextMessages.getFormattedString("FindReplaceDocumentAdapter.illegalControlEscape", "\\c"); throw new PatternSyntaxException(msg, replaceText, i); }  return i;case 'x': if (i + 2 < length) { int parsedInt; try { parsedInt = Integer.parseInt(replaceText.substring(i + 1, i + 3), 16); if (parsedInt < 0) throw new NumberFormatException();  } catch (NumberFormatException numberFormatException) { String msg = TextMessages.getFormattedString("FindReplaceDocumentAdapter.illegalHexEscape", replaceText.substring(i - 1, i + 3)); throw new PatternSyntaxException(msg, replaceText, i); }  interpretRetainCase(buf, (char)parsedInt); i += 2; } else { String msg = TextMessages.getFormattedString("FindReplaceDocumentAdapter.illegalHexEscape", replaceText.substring(i - 1, length)); throw new PatternSyntaxException(msg, replaceText, i); }  return i;case 'u': if (i + 4 < length) { int parsedInt; try { parsedInt = Integer.parseInt(replaceText.substring(i + 1, i + 5), 16); if (parsedInt < 0) throw new NumberFormatException();  } catch (NumberFormatException numberFormatException) { String msg = TextMessages.getFormattedString("FindReplaceDocumentAdapter.illegalUnicodeEscape", replaceText.substring(i - 1, i + 5)); throw new PatternSyntaxException(msg, replaceText, i); }  interpretRetainCase(buf, (char)parsedInt); i += 4; } else { String msg = TextMessages.getFormattedString("FindReplaceDocumentAdapter.illegalUnicodeEscape", replaceText.substring(i - 1, length)); throw new PatternSyntaxException(msg, replaceText, i); }  return i;case 'C': if (foundText.toUpperCase().equals(foundText)) { this.fRetainCaseMode = 1; } else if (foundText.toLowerCase().equals(foundText)) { this.fRetainCaseMode = 2; } else if (Character.isUpperCase(foundText.charAt(0))) { this.fRetainCaseMode = 3; } else { this.fRetainCaseMode = 0; }  return i; }  buf.append('\\').append(ch); return i;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String asRegPattern(String string) {
/* 567 */     StringBuilder out = new StringBuilder(string.length());
/* 568 */     boolean quoting = false;
/*     */     
/* 570 */     for (int i = 0, length = string.length(); i < length; i++) {
/* 571 */       char ch = string.charAt(i);
/* 572 */       if (ch == '\\') {
/* 573 */         if (quoting) {
/* 574 */           out.append("\\E");
/* 575 */           quoting = false;
/*     */         } 
/* 577 */         out.append("\\\\");
/*     */       } else {
/*     */         
/* 580 */         if (!quoting) {
/* 581 */           out.append("\\Q");
/* 582 */           quoting = true;
/*     */         } 
/* 584 */         out.append(ch);
/*     */       } 
/* 586 */     }  if (quoting) {
/* 587 */       out.append("\\E");
/*     */     }
/* 589 */     return out.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IRegion replace(String text, boolean regExReplace) throws BadLocationException {
/* 607 */     return findReplace(REPLACE, -1, null, text, false, false, false, regExReplace);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int length() {
/* 614 */     return this.fDocument.getLength();
/*     */   }
/*     */ 
/*     */   
/*     */   public char charAt(int index) {
/*     */     try {
/* 620 */       return this.fDocument.getChar(index);
/* 621 */     } catch (BadLocationException badLocationException) {
/* 622 */       throw new IndexOutOfBoundsException();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public CharSequence subSequence(int start, int end) {
/*     */     try {
/* 629 */       return this.fDocument.get(start, end - start);
/* 630 */     } catch (BadLocationException badLocationException) {
/* 631 */       throw new IndexOutOfBoundsException();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 637 */     return this.fDocument.get();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String escapeForRegExPattern(String string) {
/* 651 */     StringBuilder pattern = new StringBuilder(string.length() + 16);
/* 652 */     int length = string.length();
/* 653 */     for (int i = 0; i < length; i++) {
/* 654 */       char ch = string.charAt(i);
/* 655 */       switch (ch) {
/*     */         case '$':
/*     */         case '(':
/*     */         case ')':
/*     */         case '*':
/*     */         case '+':
/*     */         case '.':
/*     */         case '?':
/*     */         case '[':
/*     */         case '\\':
/*     */         case ']':
/*     */         case '^':
/*     */         case '{':
/*     */         case '|':
/*     */         case '}':
/* 670 */           pattern.append('\\').append(ch);
/*     */           break;
/*     */         
/*     */         case '\r':
/* 674 */           if (i + 1 < length && string.charAt(i + 1) == '\n') {
/* 675 */             i++;
/*     */           }
/*     */         case '\n':
/* 678 */           pattern.append("\\R");
/*     */           break;
/*     */         case '\t':
/* 681 */           pattern.append("\\t");
/*     */           break;
/*     */         case '\f':
/* 684 */           pattern.append("\\f");
/*     */           break;
/*     */         case '\007':
/* 687 */           pattern.append("\\a");
/*     */           break;
/*     */         case '\033':
/* 690 */           pattern.append("\\e");
/*     */           break;
/*     */         
/*     */         default:
/* 694 */           if (ch >= '\000' && ch < ' ') {
/* 695 */             pattern.append("\\x");
/* 696 */             String hexString = Integer.toHexString(ch).toUpperCase();
/* 697 */             if (hexString.length() == 1)
/* 698 */               pattern.append('0'); 
/* 699 */             pattern.append(hexString); break;
/*     */           } 
/* 701 */           pattern.append(ch);
/*     */           break;
/*     */       } 
/*     */     } 
/* 705 */     return pattern.toString();
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.text-3.13.0.jar!\org\eclipse\jface\text\FindReplaceDocumentAdapter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */