package org.eclipse.jface.text;

public interface IDocumentPartitioningListenerExtension2 {
  void documentPartitioningChanged(DocumentPartitioningChangedEvent paramDocumentPartitioningChangedEvent);
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.text-3.13.0.jar!\org\eclipse\jface\text\IDocumentPartitioningListenerExtension2.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */