/*     */ package org.eclipse.jface.text;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class Node
/*     */ {
/*     */   int line;
/*     */   int offset;
/*     */   int length;
/*     */   String delimiter;
/*     */   Node parent;
/*     */   Node left;
/*     */   Node right;
/*     */   byte balance;
/*     */   
/*     */   Node(int length, String delimiter) {
/*  98 */     this.length = length;
/*  99 */     this.delimiter = delimiter;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final String toString() {
/* 127 */     switch (this.balance)
/*     */     { case 0:
/* 129 */         bal = "=";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 146 */         return "[" + this.offset + "+" + pureLength() + "+" + this.delimiter.length() + "|" + this.line + "|" + bal + "]";case 1: bal = "+"; return "[" + this.offset + "+" + pureLength() + "+" + this.delimiter.length() + "|" + this.line + "|" + bal + "]";case 2: bal = "++"; return "[" + this.offset + "+" + pureLength() + "+" + this.delimiter.length() + "|" + this.line + "|" + bal + "]";case -1: bal = "-"; return "[" + this.offset + "+" + pureLength() + "+" + this.delimiter.length() + "|" + this.line + "|" + bal + "]";case -2: bal = "--"; return "[" + this.offset + "+" + pureLength() + "+" + this.delimiter.length() + "|" + this.line + "|" + bal + "]"; }  String bal = Byte.toString(this.balance); return "[" + this.offset + "+" + pureLength() + "+" + this.delimiter.length() + "|" + this.line + "|" + bal + "]";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   int pureLength() {
/* 155 */     return this.length - this.delimiter.length();
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.text-3.13.0.jar!\org\eclipse\jface\text\TreeLineTracker$Node.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */