package org.eclipse.jface.text;

public interface IDocumentExtension4 {
  public static final long UNKNOWN_MODIFICATION_STAMP = -1L;
  
  DocumentRewriteSession startRewriteSession(DocumentRewriteSessionType paramDocumentRewriteSessionType) throws IllegalStateException;
  
  void stopRewriteSession(DocumentRewriteSession paramDocumentRewriteSession);
  
  DocumentRewriteSession getActiveRewriteSession();
  
  void addDocumentRewriteSessionListener(IDocumentRewriteSessionListener paramIDocumentRewriteSessionListener);
  
  void removeDocumentRewriteSessionListener(IDocumentRewriteSessionListener paramIDocumentRewriteSessionListener);
  
  void replace(int paramInt1, int paramInt2, String paramString, long paramLong) throws BadLocationException;
  
  void set(String paramString, long paramLong);
  
  long getModificationStamp();
  
  String getDefaultLineDelimiter();
  
  void setInitialLineDelimiter(String paramString);
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.text-3.13.0.jar!\org\eclipse\jface\text\IDocumentExtension4.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */