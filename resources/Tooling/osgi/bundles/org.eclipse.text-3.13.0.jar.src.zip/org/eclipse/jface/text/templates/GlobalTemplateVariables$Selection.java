/*     */ package org.eclipse.jface.text.templates;
/*     */ 
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Selection
/*     */   extends SimpleTemplateVariableResolver
/*     */ {
/*     */   public Selection(String name, String description) {
/*  69 */     super(name, description);
/*     */   }
/*     */ 
/*     */   
/*     */   protected String resolve(TemplateContext context) {
/*  74 */     String selection = context.getVariable("selection");
/*  75 */     if (selection == null)
/*  76 */       return ""; 
/*  77 */     return selection;
/*     */   }
/*     */ 
/*     */   
/*     */   public void resolve(TemplateVariable variable, TemplateContext context) {
/*  82 */     List<String> params = variable.getVariableType().getParams();
/*  83 */     if (!params.isEmpty() && params.get(0) != null) {
/*  84 */       resolveWithParams(variable, context, params);
/*     */     } else {
/*     */       
/*  87 */       super.resolve(variable, context);
/*     */     } 
/*     */   }
/*     */   
/*     */   private void resolveWithParams(TemplateVariable variable, TemplateContext context, List<String> params) {
/*  92 */     String selection = context.getVariable("selection");
/*  93 */     if (selection != null && !selection.isEmpty()) {
/*  94 */       variable.setValue(selection);
/*     */     } else {
/*  96 */       String defaultValue = params.get(0);
/*  97 */       variable.setValue(defaultValue);
/*     */     } 
/*  99 */     variable.setUnambiguous(true);
/* 100 */     variable.setResolved(true);
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.text-3.13.0.jar!\org\eclipse\jface\text\templates\GlobalTemplateVariables$Selection.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */