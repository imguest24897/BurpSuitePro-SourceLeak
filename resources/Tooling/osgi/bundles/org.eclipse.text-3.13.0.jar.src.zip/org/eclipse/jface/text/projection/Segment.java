/*    */ package org.eclipse.jface.text.projection;
/*    */ 
/*    */ import org.eclipse.jface.text.Position;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Segment
/*    */   extends Position
/*    */ {
/*    */   public Fragment fragment;
/*    */   public boolean isMarkedForStretch;
/*    */   public boolean isMarkedForShift;
/*    */   
/*    */   public Segment(int offset, int length) {
/* 45 */     super(offset, length);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void markForStretch() {
/* 52 */     this.isMarkedForStretch = true;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean isMarkedForStretch() {
/* 60 */     return this.isMarkedForStretch;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void markForShift() {
/* 67 */     this.isMarkedForShift = true;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean isMarkedForShift() {
/* 75 */     return this.isMarkedForShift;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void clearMark() {
/* 82 */     this.isMarkedForStretch = false;
/* 83 */     this.isMarkedForShift = false;
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.text-3.13.0.jar!\org\eclipse\jface\text\projection\Segment.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */