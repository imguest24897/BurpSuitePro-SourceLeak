/*     */ package org.eclipse.jface.text.link;
/*     */ 
/*     */ import org.eclipse.jface.text.BadPositionCategoryException;
/*     */ import org.eclipse.jface.text.DocumentEvent;
/*     */ import org.eclipse.jface.text.IPositionUpdater;
/*     */ import org.eclipse.jface.text.Position;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class InclusivePositionUpdater
/*     */   implements IPositionUpdater
/*     */ {
/*     */   private final String fCategory;
/*     */   
/*     */   public InclusivePositionUpdater(String category) {
/*  41 */     this.fCategory = category;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void update(DocumentEvent event) {
/*  47 */     int eventOffset = event.getOffset();
/*  48 */     int eventOldLength = event.getLength();
/*  49 */     int eventNewLength = (event.getText() == null) ? 0 : event.getText().length();
/*  50 */     int deltaLength = eventNewLength - eventOldLength;
/*     */     
/*     */     try {
/*  53 */       Position[] positions = event.getDocument().getPositions(this.fCategory);
/*     */       
/*  55 */       for (int i = 0; i != positions.length; i++) {
/*     */         
/*  57 */         Position position = positions[i];
/*     */         
/*  59 */         if (!position.isDeleted()) {
/*     */ 
/*     */           
/*  62 */           int offset = position.getOffset();
/*  63 */           int length = position.getLength();
/*  64 */           int end = offset + length;
/*     */           
/*  66 */           if (offset > eventOffset + eventOldLength)
/*     */           
/*     */           { 
/*  69 */             position.setOffset(offset + deltaLength); }
/*  70 */           else if (end >= eventOffset)
/*     */           
/*     */           { 
/*  73 */             if (offset <= eventOffset && end >= eventOffset + eventOldLength)
/*     */             
/*  75 */             { position.setLength(length + deltaLength); }
/*  76 */             else if (offset < eventOffset)
/*     */             
/*  78 */             { int newEnd = eventOffset + eventNewLength;
/*  79 */               position.setLength(newEnd - offset); }
/*  80 */             else if (end > eventOffset + eventOldLength)
/*     */             
/*     */             { 
/*     */ 
/*     */               
/*  85 */               position.setOffset(eventOffset);
/*  86 */               int deleted = eventOffset + eventOldLength - offset;
/*  87 */               position.setLength(length - deleted + eventNewLength); }
/*     */             else
/*     */             
/*  90 */             { position.delete(); }  } 
/*     */         } 
/*     */       } 
/*  93 */     } catch (BadPositionCategoryException badPositionCategoryException) {}
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getCategory() {
/* 104 */     return this.fCategory;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.text-3.13.0.jar!\org\eclipse\jface\text\link\InclusivePositionUpdater.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */