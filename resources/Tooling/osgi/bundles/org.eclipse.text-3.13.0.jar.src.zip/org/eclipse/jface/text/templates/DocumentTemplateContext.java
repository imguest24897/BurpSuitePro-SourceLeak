/*     */ package org.eclipse.jface.text.templates;
/*     */ 
/*     */ import org.eclipse.core.runtime.Assert;
/*     */ import org.eclipse.jface.text.BadLocationException;
/*     */ import org.eclipse.jface.text.IDocument;
/*     */ import org.eclipse.jface.text.Position;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DocumentTemplateContext
/*     */   extends TemplateContext
/*     */ {
/*     */   private final IDocument fDocument;
/*     */   private final Position fPosition;
/*     */   private int fOriginalOffset;
/*     */   private int fOriginalLength;
/*     */   
/*     */   public DocumentTemplateContext(TemplateContextType type, IDocument document, int offset, int length) {
/*  63 */     this(type, document, new Position(offset, length));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DocumentTemplateContext(TemplateContextType type, IDocument document, Position position) {
/*  79 */     super(type);
/*     */     
/*  81 */     Assert.isNotNull(document);
/*  82 */     Assert.isNotNull(position);
/*  83 */     Assert.isTrue((position.getOffset() <= document.getLength()));
/*     */     
/*  85 */     this.fDocument = document;
/*  86 */     this.fPosition = position;
/*  87 */     this.fOriginalOffset = this.fPosition.getOffset();
/*  88 */     this.fOriginalLength = this.fPosition.getLength();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IDocument getDocument() {
/*  97 */     return this.fDocument;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getCompletionOffset() {
/* 106 */     return this.fOriginalOffset;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void setCompletionOffset(int newOffset) {
/* 115 */     this.fOriginalOffset = newOffset;
/* 116 */     this.fPosition.setOffset(newOffset);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getCompletionLength() {
/* 125 */     return this.fOriginalLength;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void setCompletionLength(int newLength) {
/* 134 */     this.fOriginalLength = newLength;
/* 135 */     this.fPosition.setLength(newLength);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getKey() {
/* 144 */     int offset = getStart();
/* 145 */     int length = getEnd() - offset;
/*     */     try {
/* 147 */       return this.fDocument.get(offset, length);
/* 148 */     } catch (BadLocationException badLocationException) {
/* 149 */       return "";
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getStart() {
/* 159 */     return this.fPosition.getOffset();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getEnd() {
/* 168 */     return this.fPosition.getOffset() + this.fPosition.getLength();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean canEvaluate(Template template) {
/* 173 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public TemplateBuffer evaluate(Template template) throws BadLocationException, TemplateException {
/* 178 */     if (!canEvaluate(template)) {
/* 179 */       return null;
/*     */     }
/* 181 */     TemplateTranslator translator = new TemplateTranslator();
/* 182 */     TemplateBuffer buffer = translator.translate(template);
/*     */     
/* 184 */     getContextType().resolve(buffer, this);
/*     */     
/* 186 */     return buffer;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.text-3.13.0.jar!\org\eclipse\jface\text\templates\DocumentTemplateContext.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */