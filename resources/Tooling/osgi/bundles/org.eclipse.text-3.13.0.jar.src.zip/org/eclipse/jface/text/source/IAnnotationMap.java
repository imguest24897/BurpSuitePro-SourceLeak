package org.eclipse.jface.text.source;

import java.util.Collection;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import org.eclipse.jface.text.ISynchronizable;
import org.eclipse.jface.text.Position;

public interface IAnnotationMap extends Map<Annotation, Position>, ISynchronizable {
  Iterator<Position> valuesIterator();
  
  Iterator<Annotation> keySetIterator();
  
  Set<Map.Entry<Annotation, Position>> entrySet();
  
  Set<Annotation> keySet();
  
  Collection<Position> values();
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.text-3.13.0.jar!\org\eclipse\jface\text\source\IAnnotationMap.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */