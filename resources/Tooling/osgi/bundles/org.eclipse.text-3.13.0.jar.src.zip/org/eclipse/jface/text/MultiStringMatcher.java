/*     */ package org.eclipse.jface.text;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Objects;
/*     */ import java.util.function.Consumer;
/*     */ import java.util.stream.Collectors;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MultiStringMatcher
/*     */ {
/*     */   private static class BuilderImpl
/*     */     implements Builder
/*     */   {
/*  95 */     private MultiStringMatcher m = new MultiStringMatcher();
/*     */ 
/*     */     
/*     */     private void check() {
/*  99 */       if (this.m == null) {
/* 100 */         throw new IllegalStateException("Builder.build() was already called");
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*     */     public MultiStringMatcher.Builder add(String... searchStrings) {
/* 106 */       check();
/* 107 */       this.m.add(searchStrings);
/* 108 */       return this;
/*     */     }
/*     */ 
/*     */     
/*     */     public MultiStringMatcher build() {
/* 113 */       check();
/* 114 */       MultiStringMatcher result = this.m;
/* 115 */       this.m = null;
/* 116 */       if (!result.root.hasChildren())
/*     */       {
/* 118 */         return new MultiStringMatcher()
/*     */           {
/*     */             public void find(CharSequence text, int offset, Consumer<MultiStringMatcher.Match> matches) {}
/*     */ 
/*     */ 
/*     */ 
/*     */             
/*     */             public MultiStringMatcher.Match indexOf(CharSequence text, int offset) {
/* 126 */               return null;
/*     */             }
/*     */           };
/*     */       }
/* 130 */       result.buildLinks();
/* 131 */       return result;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Builder builder() {
/* 141 */     return new BuilderImpl();
/*     */   }
/*     */   
/*     */   private static class MatchResult
/*     */     implements Match
/*     */   {
/*     */     private final String match;
/*     */     private final int offset;
/*     */     
/*     */     public MatchResult(String match, int offset) {
/* 151 */       this.match = match;
/* 152 */       this.offset = offset;
/*     */     }
/*     */ 
/*     */     
/*     */     public String getText() {
/* 157 */       return this.match;
/*     */     }
/*     */ 
/*     */     
/*     */     public int getOffset() {
/* 162 */       return this.offset;
/*     */     }
/*     */ 
/*     */     
/*     */     public int hashCode() {
/* 167 */       return Objects.hashCode(this.match) * 31 + Integer.hashCode(this.offset);
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean equals(Object obj) {
/* 172 */       if (this == obj) {
/* 173 */         return true;
/*     */       }
/* 175 */       if (obj == null || getClass() != obj.getClass()) {
/* 176 */         return false;
/*     */       }
/* 178 */       MatchResult other = (MatchResult)obj;
/* 179 */       return (this.offset == other.offset && Objects.equals(this.match, other.match));
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/* 184 */       return String.valueOf('[') + this.match + ", " + this.offset + ']';
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private static class Node
/*     */   {
/*     */     HashMap<Character, Node> children;
/*     */     
/*     */     String match;
/*     */     
/*     */     Node fail;
/*     */     
/*     */     Node output;
/*     */     final int depth;
/*     */     
/*     */     Node(int depth) {
/* 201 */       this.depth = depth;
/*     */     }
/*     */     
/*     */     Node next(Character c) {
/* 205 */       return (this.children == null) ? null : this.children.get(c);
/*     */     }
/*     */     
/*     */     Node add(char c) {
/* 209 */       if (this.children == null) {
/* 210 */         this.children = new HashMap<>();
/*     */       }
/* 212 */       return this.children.computeIfAbsent(Character.valueOf(c), key -> new Node(this.depth + 1));
/*     */     }
/*     */     
/*     */     boolean hasChildren() {
/* 216 */       return (this.children != null);
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/* 221 */       return "[depth=" + this.depth + ", match=" + this.match + 
/* 222 */         ", children=" + ((this.children == null) ? "<none>" : this.children.keySet().stream().map(c -> c.toString()).collect(Collectors.joining(", "))) + 
/* 223 */         ']';
/*     */     }
/*     */   }
/*     */ 
/*     */   
/* 228 */   private final Node root = new Node(0)
/*     */     {
/*     */       MultiStringMatcher.Node next(Character c)
/*     */       {
/* 232 */         MultiStringMatcher.Node child = super.next(c);
/* 233 */         return (child == null) ? this : child;
/*     */       }
/*     */     };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void add(String... searchStrings) {
/* 242 */     if (searchStrings != null) {
/* 243 */       byte b; int i; String[] arrayOfString; for (i = (arrayOfString = searchStrings).length, b = 0; b < i; ) { String searchString = arrayOfString[b];
/* 244 */         if (searchString != null && !searchString.isEmpty()) {
/*     */ 
/*     */           
/* 247 */           Node node = this.root; byte b1; int j; char[] arrayOfChar;
/* 248 */           for (j = (arrayOfChar = searchString.toCharArray()).length, b1 = 0; b1 < j; ) { char c = arrayOfChar[b1];
/* 249 */             node = node.add(c); b1++; }
/*     */           
/* 251 */           node.match = searchString;
/*     */         } 
/*     */         b++; }
/*     */     
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private void buildLinks() {
/* 260 */     List<Node> queue = new LinkedList<>();
/* 261 */     for (Node s : this.root.children.values()) {
/* 262 */       if (s.hasChildren())
/*     */       {
/*     */         
/* 265 */         queue.add(s);
/*     */       }
/* 267 */       s.fail = this.root;
/*     */     } 
/* 269 */     while (!queue.isEmpty()) {
/* 270 */       Node r = queue.remove(0);
/* 271 */       for (Map.Entry<Character, Node> entry : r.children.entrySet()) {
/* 272 */         Character c = entry.getKey();
/* 273 */         Node s = entry.getValue();
/* 274 */         if (s.hasChildren()) {
/* 275 */           queue.add(s);
/*     */         }
/* 277 */         Node state = r.fail;
/*     */         Node f;
/* 279 */         while ((f = state.next(c)) == null) {
/* 280 */           state = state.fail;
/*     */         }
/* 282 */         s.fail = f;
/* 283 */         if (f.match != null) {
/* 284 */           s.output = f; continue;
/* 285 */         }  if (f.output != null) {
/* 286 */           s.output = f.output;
/*     */         }
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void find(CharSequence text, int offset, Consumer<Match> matches) {
/* 304 */     int textEnd = text.length();
/* 305 */     Node node = this.root;
/* 306 */     for (int i = offset; i < textEnd; i++) {
/* 307 */       Character c = Character.valueOf(text.charAt(i));
/*     */       Node next;
/* 309 */       while ((next = node.next(c)) == null) {
/* 310 */         node = node.fail;
/*     */       }
/* 312 */       node = next;
/* 313 */       if (node.match != null) {
/* 314 */         matches.accept(new MatchResult(node.match, i - node.depth + 1));
/*     */       }
/* 316 */       Node out = node.output;
/* 317 */       while (out != null) {
/* 318 */         matches.accept(new MatchResult(out.match, i - out.depth + 1));
/* 319 */         out = out.output;
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<Match> find(CharSequence text, int offset) {
/* 333 */     List<Match> matches = new LinkedList<>();
/* 334 */     find(text, offset, matches::add);
/* 335 */     return matches;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Match indexOf(CharSequence text, int offset) {
/* 375 */     int textEnd = text.length();
/* 376 */     Match primaryMatch = null;
/* 377 */     Match subMatch = null;
/* 378 */     Node node = this.root;
/* 379 */     for (int i = offset; i < textEnd; i++) {
/* 380 */       Character c = Character.valueOf(text.charAt(i));
/* 381 */       Node next = node.next(c);
/* 382 */       if (next == null) {
/*     */         
/* 384 */         if (primaryMatch != null)
/*     */         {
/* 386 */           return primaryMatch;
/*     */         }
/*     */         
/*     */         do {
/* 390 */           node = node.fail;
/* 391 */         } while ((next = node.next(c)) == null);
/* 392 */         if (subMatch != null) {
/* 393 */           if (next == this.root)
/*     */           {
/*     */             
/* 396 */             return subMatch; } 
/* 397 */           if (subMatch.getOffset() < i - node.depth)
/*     */           {
/*     */ 
/*     */ 
/*     */             
/* 402 */             return subMatch;
/*     */           }
/*     */         } 
/*     */       } 
/* 406 */       node = next;
/* 407 */       if (node.match != null) {
/*     */ 
/*     */         
/* 410 */         primaryMatch = new MatchResult(node.match, i - node.depth + 1);
/* 411 */         if (!node.hasChildren())
/*     */         {
/* 413 */           return primaryMatch;
/*     */         }
/*     */       } 
/*     */ 
/*     */       
/* 418 */       if (primaryMatch == null) {
/* 419 */         Node out = node.output;
/* 420 */         if (out != null) {
/* 421 */           int newOffset = i - out.depth + 1;
/* 422 */           if (subMatch == null || 
/* 423 */             newOffset < subMatch.getOffset() || (
/* 424 */             newOffset == subMatch.getOffset() && out.depth > subMatch.getText().length())) {
/* 425 */             subMatch = new MatchResult(out.match, newOffset);
/*     */           }
/*     */         } 
/*     */       } 
/*     */     } 
/* 430 */     return (primaryMatch != null) ? primaryMatch : subMatch;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Match indexOf(CharSequence text, int offset, String... searchStrings) {
/* 448 */     return create(searchStrings).indexOf(text, offset);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static MultiStringMatcher create(String... searchStrings) {
/* 462 */     return builder().add(searchStrings).build();
/*     */   }
/*     */   
/*     */   public static interface Builder {
/*     */     Builder add(String... param1VarArgs);
/*     */     
/*     */     MultiStringMatcher build();
/*     */   }
/*     */   
/*     */   public static interface Match {
/*     */     String getText();
/*     */     
/*     */     int getOffset();
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.text-3.13.0.jar!\org\eclipse\jface\text\MultiStringMatcher.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */