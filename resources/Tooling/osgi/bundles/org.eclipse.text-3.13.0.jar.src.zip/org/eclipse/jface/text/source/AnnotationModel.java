/*     */ package org.eclipse.jface.text.source;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.IdentityHashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.NoSuchElementException;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import org.eclipse.core.runtime.Assert;
/*     */ import org.eclipse.jface.text.AbstractDocument;
/*     */ import org.eclipse.jface.text.BadLocationException;
/*     */ import org.eclipse.jface.text.BadPositionCategoryException;
/*     */ import org.eclipse.jface.text.DocumentEvent;
/*     */ import org.eclipse.jface.text.IDocument;
/*     */ import org.eclipse.jface.text.IDocumentListener;
/*     */ import org.eclipse.jface.text.ISynchronizable;
/*     */ import org.eclipse.jface.text.Position;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AnnotationModel
/*     */   implements IAnnotationModel, IAnnotationModelExtension, IAnnotationModelExtension2, ISynchronizable
/*     */ {
/*     */   @Deprecated
/*     */   protected Map<Annotation, Position> fAnnotations;
/*     */   private IdentityHashMap<Position, Annotation> fPositions;
/*     */   protected ArrayList<IAnnotationModelListener> fAnnotationModelListeners;
/*     */   protected IDocument fDocument;
/*     */   
/*     */   private static final class RegionIterator
/*     */     implements Iterator<Annotation>
/*     */   {
/*     */     private final Iterator<Annotation> fParentIterator;
/*     */     private final boolean fCanEndAfter;
/*     */     private final boolean fCanStartBefore;
/*     */     private final IAnnotationModel fModel;
/*     */     private Annotation fNext;
/*     */     private Position fRegion;
/*     */     
/*     */     public RegionIterator(Iterator<Annotation> parentIterator, IAnnotationModel model, int offset, int length, boolean canStartBefore, boolean canEndAfter) {
/*  83 */       this.fParentIterator = parentIterator;
/*  84 */       this.fModel = model;
/*  85 */       this.fRegion = new Position(offset, length);
/*  86 */       this.fCanEndAfter = canEndAfter;
/*  87 */       this.fCanStartBefore = canStartBefore;
/*  88 */       this.fNext = findNext();
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean hasNext() {
/*  93 */       return (this.fNext != null);
/*     */     }
/*     */ 
/*     */     
/*     */     public Annotation next() {
/*  98 */       if (!hasNext()) {
/*  99 */         throw new NoSuchElementException();
/*     */       }
/* 101 */       Annotation result = this.fNext;
/* 102 */       this.fNext = findNext();
/* 103 */       return result;
/*     */     }
/*     */ 
/*     */     
/*     */     public void remove() {
/* 108 */       throw new UnsupportedOperationException();
/*     */     }
/*     */     
/*     */     private Annotation findNext() {
/* 112 */       while (this.fParentIterator.hasNext()) {
/* 113 */         Annotation next = this.fParentIterator.next();
/* 114 */         Position position = this.fModel.getPosition(next);
/* 115 */         if (position != null) {
/* 116 */           int offset = position.getOffset();
/* 117 */           if (isWithinRegion(offset, position.getLength()))
/* 118 */             return next; 
/*     */         } 
/*     */       } 
/* 121 */       return null;
/*     */     }
/*     */     
/*     */     private boolean isWithinRegion(int start, int length) {
/* 125 */       if (this.fCanStartBefore && this.fCanEndAfter)
/* 126 */         return this.fRegion.overlapsWith(start, length); 
/* 127 */       if (this.fCanStartBefore)
/* 128 */         return this.fRegion.includes(start + length - ((length > 0) ? 1 : 0)); 
/* 129 */       if (this.fCanEndAfter) {
/* 130 */         return this.fRegion.includes(start);
/*     */       }
/* 132 */       return (this.fRegion.includes(start) && this.fRegion.includes(start + length - ((length > 0) ? 1 : 0)));
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static final class AnnotationsInterator
/*     */     implements Iterator<Annotation>
/*     */   {
/*     */     private Annotation fNext;
/*     */ 
/*     */     
/*     */     private final Position[] fPositions;
/*     */ 
/*     */     
/*     */     private int fIndex;
/*     */ 
/*     */     
/*     */     private final Map<Position, Annotation> fMap;
/*     */ 
/*     */     
/*     */     public AnnotationsInterator(Position[] positions, Map<Position, Annotation> map) {
/* 154 */       this.fPositions = positions;
/* 155 */       this.fIndex = 0;
/* 156 */       this.fMap = map;
/* 157 */       this.fNext = findNext();
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean hasNext() {
/* 162 */       return (this.fNext != null);
/*     */     }
/*     */ 
/*     */     
/*     */     public Annotation next() {
/* 167 */       Annotation result = this.fNext;
/* 168 */       this.fNext = findNext();
/* 169 */       return result;
/*     */     }
/*     */ 
/*     */     
/*     */     public void remove() {
/* 174 */       throw new UnsupportedOperationException();
/*     */     }
/*     */     
/*     */     private Annotation findNext() {
/* 178 */       while (this.fIndex < this.fPositions.length) {
/* 179 */         Position position = this.fPositions[this.fIndex];
/* 180 */         this.fIndex++;
/* 181 */         if (this.fMap.containsKey(position)) {
/* 182 */           return this.fMap.get(position);
/*     */         }
/*     */       } 
/* 185 */       return null;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static class MetaIterator<E>
/*     */     implements Iterator<E>
/*     */   {
/*     */     private Iterator<? extends Iterator<? extends E>> fSuperIterator;
/*     */ 
/*     */     
/*     */     private Iterator<? extends E> fCurrent;
/*     */ 
/*     */     
/*     */     private E fCurrentElement;
/*     */ 
/*     */ 
/*     */     
/*     */     public MetaIterator(Iterator<? extends Iterator<? extends E>> iterator) {
/* 206 */       this.fSuperIterator = iterator;
/* 207 */       this.fCurrent = this.fSuperIterator.next();
/*     */     }
/*     */ 
/*     */     
/*     */     public void remove() {
/* 212 */       throw new UnsupportedOperationException();
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean hasNext() {
/* 217 */       if (this.fCurrentElement != null) {
/* 218 */         return true;
/*     */       }
/* 220 */       if (this.fCurrent.hasNext()) {
/* 221 */         this.fCurrentElement = this.fCurrent.next();
/* 222 */         return true;
/* 223 */       }  if (this.fSuperIterator.hasNext()) {
/* 224 */         this.fCurrent = this.fSuperIterator.next();
/* 225 */         return hasNext();
/*     */       } 
/* 227 */       return false;
/*     */     }
/*     */ 
/*     */     
/*     */     public E next() {
/* 232 */       if (!hasNext()) {
/* 233 */         throw new NoSuchElementException();
/*     */       }
/* 235 */       E element = this.fCurrentElement;
/* 236 */       this.fCurrentElement = null;
/* 237 */       return element;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private class InternalModelListener
/*     */     implements IAnnotationModelListener, IAnnotationModelListenerExtension
/*     */   {
/*     */     public void modelChanged(IAnnotationModel model) {
/* 251 */       AnnotationModel.this.fireModelChanged(new AnnotationModelEvent(model, true));
/*     */     }
/*     */ 
/*     */     
/*     */     public void modelChanged(AnnotationModelEvent event) {
/* 256 */       AnnotationModel.this.fireModelChanged(event);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 276 */   private int fOpenConnections = 0;
/*     */ 
/*     */   
/*     */   private IDocumentListener fDocumentListener;
/*     */ 
/*     */   
/*     */   private boolean fDocumentChanged = true;
/*     */ 
/*     */   
/* 285 */   private Map<Object, IAnnotationModel> fAttachments = new ConcurrentHashMap<>();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 290 */   private IAnnotationModelListener fModelListener = new InternalModelListener();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private AnnotationModelEvent fModelEvent;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 300 */   private Object fModificationStamp = new Object();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AnnotationModel() {
/* 307 */     this.fAnnotations = new AnnotationMap(10);
/* 308 */     this.fPositions = new IdentityHashMap<>(10);
/* 309 */     this.fAnnotationModelListeners = new ArrayList<>(2);
/*     */     
/* 311 */     this.fDocumentListener = new IDocumentListener()
/*     */       {
/*     */         public void documentAboutToBeChanged(DocumentEvent event) {}
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         public void documentChanged(DocumentEvent event) {
/* 319 */           AnnotationModel.this.fDocumentChanged = true;
/*     */         }
/*     */       };
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected IAnnotationMap getAnnotationMap() {
/* 331 */     return (IAnnotationMap)this.fAnnotations;
/*     */   }
/*     */ 
/*     */   
/*     */   public Object getLockObject() {
/* 336 */     return getAnnotationMap().getLockObject();
/*     */   }
/*     */ 
/*     */   
/*     */   public void setLockObject(Object lockObject) {
/* 341 */     getAnnotationMap().setLockObject(lockObject);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final AnnotationModelEvent getAnnotationModelEvent() {
/* 352 */     synchronized (getLockObject()) {
/* 353 */       if (this.fModelEvent == null) {
/* 354 */         this.fModelEvent = createAnnotationModelEvent();
/* 355 */         this.fModelEvent.markWorldChange(false);
/* 356 */         this.fModificationStamp = new Object();
/*     */       } 
/* 358 */       return this.fModelEvent;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void addAnnotation(Annotation annotation, Position position) {
/*     */     try {
/* 365 */       addAnnotation(annotation, position, true);
/* 366 */     } catch (BadLocationException badLocationException) {}
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void replaceAnnotations(Annotation[] annotationsToRemove, Map<? extends Annotation, ? extends Position> annotationsToAdd) {
/*     */     try {
/* 374 */       replaceAnnotations(annotationsToRemove, annotationsToAdd, true);
/* 375 */     } catch (BadLocationException badLocationException) {}
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void replaceAnnotations(Annotation[] annotationsToRemove, Map<? extends Annotation, ? extends Position> annotationsToAdd, boolean fireModelChanged) throws BadLocationException {
/* 393 */     if (annotationsToRemove != null) {
/* 394 */       byte b; int i; Annotation[] arrayOfAnnotation; for (i = (arrayOfAnnotation = annotationsToRemove).length, b = 0; b < i; ) { Annotation element = arrayOfAnnotation[b];
/* 395 */         removeAnnotation(element, false); b++; }
/*     */     
/*     */     } 
/* 398 */     if (annotationsToAdd != null) {
/* 399 */       Iterator<? extends Map.Entry<? extends Annotation, ? extends Position>> iter = annotationsToAdd.entrySet().iterator();
/* 400 */       while (iter.hasNext()) {
/* 401 */         Map.Entry<? extends Annotation, ? extends Position> mapEntry = iter.next();
/* 402 */         Annotation annotation = mapEntry.getKey();
/* 403 */         Position position = mapEntry.getValue();
/* 404 */         addAnnotation(annotation, position, false);
/*     */       } 
/*     */     } 
/*     */     
/* 408 */     if (fireModelChanged) {
/* 409 */       fireModelChanged();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void addAnnotation(Annotation annotation, Position position, boolean fireModelChanged) throws BadLocationException {
/* 424 */     IAnnotationMap annotations = getAnnotationMap();
/* 425 */     if (!annotations.containsKey(annotation)) {
/*     */       
/* 427 */       addPosition(this.fDocument, position);
/* 428 */       annotations.put(annotation, position);
/* 429 */       this.fPositions.put(position, annotation);
/* 430 */       synchronized (getLockObject()) {
/* 431 */         getAnnotationModelEvent().annotationAdded(annotation);
/*     */       } 
/*     */       
/* 434 */       if (fireModelChanged) {
/* 435 */         fireModelChanged();
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   public void addAnnotationModelListener(IAnnotationModelListener listener) {
/* 441 */     if (!this.fAnnotationModelListeners.contains(listener)) {
/* 442 */       this.fAnnotationModelListeners.add(listener);
/* 443 */       if (listener instanceof IAnnotationModelListenerExtension) {
/* 444 */         IAnnotationModelListenerExtension extension = (IAnnotationModelListenerExtension)listener;
/* 445 */         AnnotationModelEvent event = createAnnotationModelEvent();
/* 446 */         event.markSealed();
/* 447 */         extension.modelChanged(event);
/*     */       } else {
/* 449 */         listener.modelChanged(this);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void addPosition(IDocument document, Position position) throws BadLocationException {
/* 462 */     if (document != null) {
/* 463 */       document.addPosition(position);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void removePosition(IDocument document, Position position) {
/* 476 */     if (document != null) {
/* 477 */       document.removePosition(position);
/*     */     }
/*     */   }
/*     */   
/*     */   public void connect(IDocument document) {
/* 482 */     Assert.isTrue(!(this.fDocument != null && this.fDocument != document));
/*     */     
/* 484 */     if (this.fDocument == null) {
/* 485 */       this.fDocument = document;
/* 486 */       Iterator<Position> e = getAnnotationMap().valuesIterator();
/* 487 */       while (e.hasNext()) {
/*     */         try {
/* 489 */           addPosition(document, e.next());
/* 490 */         } catch (BadLocationException badLocationException) {}
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 495 */     this.fOpenConnections++;
/* 496 */     if (this.fOpenConnections == 1) {
/* 497 */       document.addDocumentListener(this.fDocumentListener);
/* 498 */       connected();
/*     */     } 
/*     */     
/* 501 */     for (IAnnotationModel model : this.fAttachments.values()) {
/* 502 */       model.connect(document);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void connected() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void disconnected() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void disconnect(IDocument document) {
/* 523 */     Assert.isTrue((this.fDocument == document));
/*     */     
/* 525 */     for (IAnnotationModel model : this.fAttachments.values()) {
/* 526 */       model.disconnect(document);
/*     */     }
/*     */     
/* 529 */     this.fOpenConnections--;
/* 530 */     if (this.fOpenConnections == 0) {
/*     */       
/* 532 */       disconnected();
/* 533 */       document.removeDocumentListener(this.fDocumentListener);
/*     */       
/* 535 */       Iterator<Position> e = getAnnotationMap().valuesIterator();
/* 536 */       while (e.hasNext()) {
/* 537 */         Position p = e.next();
/* 538 */         removePosition(document, p);
/*     */       } 
/* 540 */       this.fDocument = null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void fireModelChanged() {
/* 548 */     AnnotationModelEvent modelEvent = null;
/*     */     
/* 550 */     synchronized (getLockObject()) {
/* 551 */       if (this.fModelEvent != null) {
/* 552 */         modelEvent = this.fModelEvent;
/* 553 */         this.fModelEvent = null;
/*     */       } 
/*     */     } 
/*     */     
/* 557 */     if (modelEvent != null) {
/* 558 */       fireModelChanged(modelEvent);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected AnnotationModelEvent createAnnotationModelEvent() {
/* 568 */     return new AnnotationModelEvent(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void fireModelChanged(AnnotationModelEvent event) {
/* 582 */     event.markSealed();
/*     */     
/* 584 */     if (event.isEmpty()) {
/*     */       return;
/*     */     }
/* 587 */     ArrayList<IAnnotationModelListener> v = new ArrayList<>(this.fAnnotationModelListeners);
/* 588 */     Iterator<IAnnotationModelListener> e = v.iterator();
/* 589 */     while (e.hasNext()) {
/* 590 */       IAnnotationModelListener l = e.next();
/* 591 */       if (l instanceof IAnnotationModelListenerExtension) {
/* 592 */         ((IAnnotationModelListenerExtension)l).modelChanged(event); continue;
/* 593 */       }  if (l != null) {
/* 594 */         l.modelChanged(this);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void removeAnnotations(List<? extends Annotation> annotations, boolean fireModelChanged, boolean modelInitiated) {
/* 609 */     if (!annotations.isEmpty()) {
/* 610 */       Iterator<? extends Annotation> e = annotations.iterator();
/* 611 */       while (e.hasNext()) {
/* 612 */         removeAnnotation(e.next(), false);
/*     */       }
/* 614 */       if (fireModelChanged) {
/* 615 */         fireModelChanged();
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void cleanup(boolean fireModelChanged) {
/* 626 */     cleanup(fireModelChanged, true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void cleanup(boolean fireModelChanged, boolean forkNotification) {
/* 639 */     if (this.fDocumentChanged) {
/* 640 */       this.fDocumentChanged = false;
/*     */       
/* 642 */       ArrayList<Annotation> deleted = new ArrayList<>();
/* 643 */       Iterator<Annotation> e = getAnnotationMap().keySetIterator();
/* 644 */       IAnnotationMap annotations = getAnnotationMap();
/* 645 */       while (e.hasNext()) {
/* 646 */         Annotation a = e.next();
/* 647 */         Position p = annotations.get(a);
/* 648 */         if (p == null || p.isDeleted()) {
/* 649 */           deleted.add(a);
/*     */         }
/*     */       } 
/* 652 */       if (fireModelChanged && forkNotification) {
/* 653 */         removeAnnotations(deleted, false, false);
/* 654 */         synchronized (getLockObject()) {
/* 655 */           if (this.fModelEvent != null)
/* 656 */             (new Thread()
/*     */               {
/*     */                 public void run() {
/* 659 */                   AnnotationModel.this.fireModelChanged();
/*     */                 }
/* 661 */               }).start(); 
/*     */         } 
/*     */       } else {
/* 664 */         removeAnnotations(deleted, fireModelChanged, false);
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   public Iterator<Annotation> getAnnotationIterator() {
/* 670 */     return getAnnotationIterator(true, true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Iterator<Annotation> getAnnotationIterator(int offset, int length, boolean canStartBefore, boolean canEndAfter) {
/* 680 */     Iterator<Annotation> regionIterator = getRegionAnnotationIterator(offset, length, canStartBefore, canEndAfter);
/*     */     
/* 682 */     if (this.fAttachments.isEmpty()) {
/* 683 */       return regionIterator;
/*     */     }
/* 685 */     List<Iterator<Annotation>> iterators = new ArrayList<>(this.fAttachments.size() + 1);
/* 686 */     iterators.add(regionIterator);
/* 687 */     Iterator<Object> it = this.fAttachments.keySet().iterator();
/* 688 */     while (it.hasNext()) {
/* 689 */       IAnnotationModel attachment = this.fAttachments.get(it.next());
/* 690 */       if (attachment instanceof IAnnotationModelExtension2) {
/* 691 */         iterators.add(((IAnnotationModelExtension2)attachment).getAnnotationIterator(offset, length, canStartBefore, canEndAfter)); continue;
/*     */       } 
/* 693 */       iterators.add(new RegionIterator(attachment.getAnnotationIterator(), attachment, offset, length, canStartBefore, canEndAfter));
/*     */     } 
/*     */     
/* 696 */     return new MetaIterator<>(iterators.iterator());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Iterator<Annotation> getRegionAnnotationIterator(int offset, int length, boolean canStartBefore, boolean canEndAfter) {
/* 711 */     if (!(this.fDocument instanceof AbstractDocument)) {
/* 712 */       return new RegionIterator(getAnnotationIterator(true), this, offset, length, canStartBefore, canEndAfter);
/*     */     }
/* 714 */     AbstractDocument document = (AbstractDocument)this.fDocument;
/* 715 */     cleanup(true);
/*     */     
/*     */     try {
/* 718 */       Position[] positions = document.getPositions("__dflt_position_category", offset, length, canStartBefore, canEndAfter);
/* 719 */       return new AnnotationsInterator(positions, this.fPositions);
/* 720 */     } catch (BadPositionCategoryException badPositionCategoryException) {
/*     */       
/* 722 */       return Collections.<Annotation>emptyList().iterator();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Iterator<Annotation> getAnnotationIterator(boolean cleanup, boolean recurse) {
/* 738 */     Iterator<Annotation> iter = getAnnotationIterator(cleanup);
/* 739 */     if (!recurse || this.fAttachments.isEmpty()) {
/* 740 */       return iter;
/*     */     }
/* 742 */     List<Iterator<Annotation>> iterators = new ArrayList<>(this.fAttachments.size() + 1);
/* 743 */     iterators.add(iter);
/* 744 */     Iterator<Object> it = this.fAttachments.keySet().iterator();
/* 745 */     while (it.hasNext()) {
/* 746 */       iterators.add(((IAnnotationModel)this.fAttachments.get(it.next())).getAnnotationIterator());
/*     */     }
/* 748 */     return new MetaIterator<>(iterators.iterator());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Iterator<Annotation> getAnnotationIterator(boolean cleanup) {
/* 760 */     if (cleanup) {
/* 761 */       cleanup(true);
/*     */     }
/* 763 */     return getAnnotationMap().keySetIterator();
/*     */   }
/*     */ 
/*     */   
/*     */   public Position getPosition(Annotation annotation) {
/* 768 */     Position position = getAnnotationMap().get(annotation);
/* 769 */     if (position != null) {
/* 770 */       return position;
/*     */     }
/* 772 */     Iterator<IAnnotationModel> it = this.fAttachments.values().iterator();
/* 773 */     while (position == null && it.hasNext())
/* 774 */       position = ((IAnnotationModel)it.next()).getPosition(annotation); 
/* 775 */     return position;
/*     */   }
/*     */ 
/*     */   
/*     */   public void removeAllAnnotations() {
/* 780 */     removeAllAnnotations(true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void removeAllAnnotations(boolean fireModelChanged) {
/* 790 */     IAnnotationMap annotations = getAnnotationMap();
/* 791 */     if (this.fDocument != null) {
/* 792 */       Iterator<Annotation> e = getAnnotationMap().keySetIterator();
/* 793 */       while (e.hasNext()) {
/* 794 */         Annotation a = e.next();
/* 795 */         Position p = annotations.get(a);
/* 796 */         removePosition(this.fDocument, p);
/*     */         
/* 798 */         synchronized (getLockObject()) {
/* 799 */           getAnnotationModelEvent().annotationRemoved(a, p);
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 804 */     annotations.clear();
/* 805 */     this.fPositions.clear();
/*     */     
/* 807 */     if (fireModelChanged) {
/* 808 */       fireModelChanged();
/*     */     }
/*     */   }
/*     */   
/*     */   public void removeAnnotation(Annotation annotation) {
/* 813 */     removeAnnotation(annotation, true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void removeAnnotation(Annotation annotation, boolean fireModelChanged) {
/* 824 */     IAnnotationMap annotations = getAnnotationMap();
/* 825 */     if (annotations.containsKey(annotation)) {
/*     */       
/* 827 */       Position p = null;
/* 828 */       p = annotations.get(annotation);
/* 829 */       if (this.fDocument != null) {
/* 830 */         removePosition(this.fDocument, p);
/*     */       }
/*     */ 
/*     */       
/* 834 */       annotations.remove(annotation);
/* 835 */       this.fPositions.remove(p);
/* 836 */       synchronized (getLockObject()) {
/* 837 */         getAnnotationModelEvent().annotationRemoved(annotation, p);
/*     */       } 
/*     */       
/* 840 */       if (fireModelChanged) {
/* 841 */         fireModelChanged();
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   public void modifyAnnotationPosition(Annotation annotation, Position position) {
/* 847 */     modifyAnnotationPosition(annotation, position, true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void modifyAnnotationPosition(Annotation annotation, Position position, boolean fireModelChanged) {
/* 867 */     if (position == null) {
/* 868 */       removeAnnotation(annotation, fireModelChanged);
/*     */     } else {
/* 870 */       Position p = getAnnotationMap().get(annotation);
/* 871 */       if (p != null) {
/*     */         
/* 873 */         if (position.getOffset() != p.getOffset() || position.getLength() != p.getLength()) {
/* 874 */           this.fDocument.removePosition(p);
/* 875 */           p.setOffset(position.getOffset());
/* 876 */           p.setLength(position.getLength());
/*     */           try {
/* 878 */             this.fDocument.addPosition(p);
/* 879 */           } catch (BadLocationException badLocationException) {}
/*     */         } 
/*     */ 
/*     */         
/* 883 */         synchronized (getLockObject()) {
/* 884 */           getAnnotationModelEvent().annotationChanged(annotation);
/*     */         } 
/* 886 */         if (fireModelChanged) {
/* 887 */           fireModelChanged();
/*     */         }
/*     */       } else {
/*     */         try {
/* 891 */           addAnnotation(annotation, position, fireModelChanged);
/* 892 */         } catch (BadLocationException badLocationException) {}
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void modifyAnnotation(Annotation annotation, boolean fireModelChanged) {
/* 911 */     if (getAnnotationMap().containsKey(annotation)) {
/* 912 */       synchronized (getLockObject()) {
/* 913 */         getAnnotationModelEvent().annotationChanged(annotation);
/*     */       } 
/* 915 */       if (fireModelChanged) {
/* 916 */         fireModelChanged();
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   public void removeAnnotationModelListener(IAnnotationModelListener listener) {
/* 922 */     this.fAnnotationModelListeners.remove(listener);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addAnnotationModel(Object key, IAnnotationModel attachment) {
/* 931 */     Assert.isNotNull(attachment);
/* 932 */     if (!this.fAttachments.containsValue(attachment)) {
/* 933 */       this.fAttachments.put(key, attachment);
/* 934 */       for (int i = 0; i < this.fOpenConnections; i++)
/* 935 */         attachment.connect(this.fDocument); 
/* 936 */       attachment.addAnnotationModelListener(this.fModelListener);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IAnnotationModel getAnnotationModel(Object key) {
/* 946 */     return this.fAttachments.get(key);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IAnnotationModel removeAnnotationModel(Object key) {
/* 955 */     IAnnotationModel ret = this.fAttachments.remove(key);
/* 956 */     if (ret != null) {
/* 957 */       for (int i = 0; i < this.fOpenConnections; i++)
/* 958 */         ret.disconnect(this.fDocument); 
/* 959 */       ret.removeAnnotationModelListener(this.fModelListener);
/*     */     } 
/* 961 */     return ret;
/*     */   }
/*     */ 
/*     */   
/*     */   public Object getModificationStamp() {
/* 966 */     return this.fModificationStamp;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.text-3.13.0.jar!\org\eclipse\jface\text\source\AnnotationModel.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */