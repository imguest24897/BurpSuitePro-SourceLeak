/*     */ package org.eclipse.jface.text;
/*     */ 
/*     */ import org.eclipse.core.runtime.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DocumentEvent
/*     */ {
/*  37 */   private static final boolean ASSERT_TEXT_NOT_NULL = Boolean.getBoolean("org.eclipse.text/debug/DocumentEvent/assertTextNotNull");
/*     */ 
/*     */   
/*     */   public IDocument fDocument;
/*     */   
/*     */   public int fOffset;
/*     */   
/*     */   public int fLength;
/*     */   
/*  46 */   public String fText = "";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long fModificationStamp;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DocumentEvent(IDocument doc, int offset, int length, String text) {
/*  63 */     Assert.isNotNull(doc);
/*  64 */     Assert.isTrue((offset >= 0));
/*  65 */     Assert.isTrue((length >= 0));
/*     */     
/*  67 */     if (ASSERT_TEXT_NOT_NULL) {
/*  68 */       Assert.isNotNull(text);
/*     */     }
/*  70 */     this.fDocument = doc;
/*  71 */     this.fOffset = offset;
/*  72 */     this.fLength = length;
/*  73 */     this.fText = text;
/*     */     
/*  75 */     if (this.fDocument instanceof IDocumentExtension4) {
/*  76 */       this.fModificationStamp = ((IDocumentExtension4)this.fDocument).getModificationStamp();
/*     */     } else {
/*  78 */       this.fModificationStamp = -1L;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DocumentEvent() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IDocument getDocument() {
/*  93 */     return this.fDocument;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getOffset() {
/* 102 */     return this.fOffset;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getLength() {
/* 111 */     return this.fLength;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getText() {
/* 120 */     return this.fText;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long getModificationStamp() {
/* 132 */     return this.fModificationStamp;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 137 */     StringBuilder buffer = new StringBuilder();
/* 138 */     buffer.append("offset: ");
/* 139 */     buffer.append(this.fOffset);
/* 140 */     buffer.append(", length: ");
/* 141 */     buffer.append(this.fLength);
/* 142 */     buffer.append(", timestamp: ");
/* 143 */     buffer.append(this.fModificationStamp);
/* 144 */     buffer.append("\ntext:>");
/* 145 */     buffer.append(this.fText);
/* 146 */     buffer.append("<\n");
/* 147 */     return buffer.toString();
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.text-3.13.0.jar!\org\eclipse\jface\text\DocumentEvent.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */