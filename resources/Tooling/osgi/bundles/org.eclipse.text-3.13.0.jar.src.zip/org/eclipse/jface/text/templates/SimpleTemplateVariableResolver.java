/*    */ package org.eclipse.jface.text.templates;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SimpleTemplateVariableResolver
/*    */   extends TemplateVariableResolver
/*    */ {
/*    */   private String fEvaluationString;
/*    */   
/*    */   protected SimpleTemplateVariableResolver(String type, String description) {
/* 34 */     super(type, description);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public final void setEvaluationString(String evaluationString) {
/* 43 */     this.fEvaluationString = evaluationString;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected String resolve(TemplateContext context) {
/* 51 */     return this.fEvaluationString;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected boolean isUnambiguous(TemplateContext context) {
/* 63 */     return true;
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.text-3.13.0.jar!\org\eclipse\jface\text\templates\SimpleTemplateVariableResolver.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */