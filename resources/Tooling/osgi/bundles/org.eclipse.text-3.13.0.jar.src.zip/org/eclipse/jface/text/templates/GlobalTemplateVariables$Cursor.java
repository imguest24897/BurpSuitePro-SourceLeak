/*    */ package org.eclipse.jface.text.templates;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Cursor
/*    */   extends SimpleTemplateVariableResolver
/*    */ {
/*    */   public static final String NAME = "cursor";
/*    */   
/*    */   public Cursor() {
/* 50 */     super("cursor", TextTemplateMessages.getString("GlobalVariables.variable.description.cursor"));
/* 51 */     setEvaluationString("");
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.text-3.13.0.jar!\org\eclipse\jface\text\templates\GlobalTemplateVariables$Cursor.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */