/*    */ package org.eclipse.jface.text.link;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class Listener
/*    */   implements ILinkedModeListener
/*    */ {
/*    */   public void left(LinkedModeModel model, int flags) {
/* 45 */     LinkedModeManager.this.left(model, flags);
/*    */   }
/*    */   
/*    */   public void suspend(LinkedModeModel model) {}
/*    */   
/*    */   public void resume(LinkedModeModel model, int flags) {}
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.text-3.13.0.jar!\org\eclipse\jface\text\link\LinkedModeManager$Listener.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */