package org.eclipse.jface.text;

public interface IDocumentExtension {
  void registerPostNotificationReplace(IDocumentListener paramIDocumentListener, IReplace paramIReplace) throws UnsupportedOperationException;
  
  void stopPostNotificationProcessing();
  
  void resumePostNotificationProcessing();
  
  @Deprecated
  void startSequentialRewrite(boolean paramBoolean);
  
  @Deprecated
  void stopSequentialRewrite();
  
  public static interface IReplace {
    void perform(IDocument param1IDocument, IDocumentListener param1IDocumentListener);
  }
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.text-3.13.0.jar!\org\eclipse\jface\text\IDocumentExtension.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */