/*    */ package org.eclipse.jface.text;
/*    */ 
/*    */ import org.eclipse.text.edits.CopyTargetEdit;
/*    */ import org.eclipse.text.edits.DeleteEdit;
/*    */ import org.eclipse.text.edits.InsertEdit;
/*    */ import org.eclipse.text.edits.MoveTargetEdit;
/*    */ import org.eclipse.text.edits.ReplaceEdit;
/*    */ import org.eclipse.text.edits.TextEditVisitor;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class SizeVisitor
/*    */   extends TextEditVisitor
/*    */ {
/* 40 */   int fSize = 0;
/*    */ 
/*    */   
/*    */   public boolean visit(CopyTargetEdit edit) {
/* 44 */     this.fSize += edit.getLength();
/* 45 */     return super.visit(edit);
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean visit(DeleteEdit edit) {
/* 50 */     this.fSize += edit.getLength();
/* 51 */     return super.visit(edit);
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean visit(InsertEdit edit) {
/* 56 */     this.fSize += edit.getText().length();
/* 57 */     return super.visit(edit);
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean visit(MoveTargetEdit edit) {
/* 62 */     this.fSize += edit.getLength();
/* 63 */     return super.visit(edit);
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean visit(ReplaceEdit edit) {
/* 68 */     this.fSize += Math.max(edit.getLength(), edit.getText().length());
/* 69 */     return super.visit(edit);
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.text-3.13.0.jar!\org\eclipse\jface\text\RewriteSessionEditProcessor$SizeVisitor.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */