/*     */ package org.eclipse.jface.text.templates;
/*     */ 
/*     */ import java.text.DateFormat;
/*     */ import java.text.SimpleDateFormat;
/*     */ import java.util.Calendar;
/*     */ import java.util.List;
/*     */ import java.util.Locale;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class GlobalTemplateVariables
/*     */ {
/*     */   public static final String SELECTION = "selection";
/*     */   
/*     */   public static class Cursor
/*     */     extends SimpleTemplateVariableResolver
/*     */   {
/*     */     public static final String NAME = "cursor";
/*     */     
/*     */     public Cursor() {
/*  50 */       super("cursor", TextTemplateMessages.getString("GlobalVariables.variable.description.cursor"));
/*  51 */       setEvaluationString("");
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class Selection
/*     */     extends SimpleTemplateVariableResolver
/*     */   {
/*     */     public Selection(String name, String description) {
/*  69 */       super(name, description);
/*     */     }
/*     */ 
/*     */     
/*     */     protected String resolve(TemplateContext context) {
/*  74 */       String selection = context.getVariable("selection");
/*  75 */       if (selection == null)
/*  76 */         return ""; 
/*  77 */       return selection;
/*     */     }
/*     */ 
/*     */     
/*     */     public void resolve(TemplateVariable variable, TemplateContext context) {
/*  82 */       List<String> params = variable.getVariableType().getParams();
/*  83 */       if (!params.isEmpty() && params.get(0) != null) {
/*  84 */         resolveWithParams(variable, context, params);
/*     */       } else {
/*     */         
/*  87 */         super.resolve(variable, context);
/*     */       } 
/*     */     }
/*     */     
/*     */     private void resolveWithParams(TemplateVariable variable, TemplateContext context, List<String> params) {
/*  92 */       String selection = context.getVariable("selection");
/*  93 */       if (selection != null && !selection.isEmpty()) {
/*  94 */         variable.setValue(selection);
/*     */       } else {
/*  96 */         String defaultValue = params.get(0);
/*  97 */         variable.setValue(defaultValue);
/*     */       } 
/*  99 */       variable.setUnambiguous(true);
/* 100 */       variable.setResolved(true);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class WordSelection
/*     */     extends Selection
/*     */   {
/*     */     public static final String NAME = "word_selection";
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public WordSelection() {
/* 117 */       super("word_selection", TextTemplateMessages.getString("GlobalVariables.variable.description.selectedWord"));
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class LineSelection
/*     */     extends Selection
/*     */   {
/*     */     public static final String NAME = "line_selection";
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public LineSelection() {
/* 134 */       super("line_selection", TextTemplateMessages.getString("GlobalVariables.variable.description.selectedLines"));
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class Dollar
/*     */     extends SimpleTemplateVariableResolver
/*     */   {
/*     */     public Dollar() {
/* 146 */       super("dollar", TextTemplateMessages.getString("GlobalVariables.variable.description.dollar"));
/* 147 */       setEvaluationString("$");
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class Date
/*     */     extends SimpleTemplateVariableResolver
/*     */   {
/*     */     public Date() {
/* 162 */       super("date", TextTemplateMessages.getString("GlobalVariables.variable.description.date"));
/*     */     }
/*     */ 
/*     */     
/*     */     public void resolve(TemplateVariable variable, TemplateContext context) {
/* 167 */       List<String> params = variable.getVariableType().getParams();
/* 168 */       if (!params.isEmpty() && params.get(0) != null) {
/* 169 */         resolveWithParams(variable, context, params);
/*     */       } else {
/*     */         
/* 172 */         super.resolve(variable, context);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     private void resolveWithParams(TemplateVariable variable, TemplateContext context, List<String> params) {
/*     */       try {
/*     */         DateFormat format;
/* 180 */         if (params.size() >= 2 && params.get(1) != null) {
/* 181 */           String localeString = params.get(1);
/* 182 */           if (localeString.contains("_")) {
/* 183 */             String[] localeData = localeString.split("_");
/* 184 */             format = new SimpleDateFormat(params.get(0), new Locale(localeData[0], localeData[1]));
/*     */           } else {
/* 186 */             format = new SimpleDateFormat(params.get(0), new Locale(localeString));
/*     */           } 
/*     */         } else {
/* 189 */           format = new SimpleDateFormat(params.get(0));
/*     */         } 
/*     */         
/* 192 */         variable.setValue(format.format(new java.util.Date()));
/* 193 */         variable.setUnambiguous(true);
/* 194 */         variable.setResolved(true);
/* 195 */       } catch (IllegalArgumentException illegalArgumentException) {
/*     */         
/* 197 */         super.resolve(variable, context);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     protected String resolve(TemplateContext context) {
/* 203 */       return DateFormat.getDateInstance().format(new java.util.Date());
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class Year
/*     */     extends SimpleTemplateVariableResolver
/*     */   {
/*     */     public Year() {
/* 215 */       super("year", TextTemplateMessages.getString("GlobalVariables.variable.description.year"));
/*     */     }
/*     */     
/*     */     protected String resolve(TemplateContext context) {
/* 219 */       return Integer.toString(Calendar.getInstance().get(1));
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class Time
/*     */     extends SimpleTemplateVariableResolver
/*     */   {
/*     */     public Time() {
/* 231 */       super("time", TextTemplateMessages.getString("GlobalVariables.variable.description.time"));
/*     */     }
/*     */ 
/*     */     
/*     */     protected String resolve(TemplateContext context) {
/* 236 */       return DateFormat.getTimeInstance().format(new java.util.Date());
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class User
/*     */     extends SimpleTemplateVariableResolver
/*     */   {
/*     */     public User() {
/* 248 */       super("user", TextTemplateMessages.getString("GlobalVariables.variable.description.user"));
/*     */     }
/*     */ 
/*     */     
/*     */     protected String resolve(TemplateContext context) {
/* 253 */       return System.getProperty("user.name");
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.text-3.13.0.jar!\org\eclipse\jface\text\templates\GlobalTemplateVariables.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */