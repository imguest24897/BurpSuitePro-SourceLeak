/*    */ package org.eclipse.jface.text.templates;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.Arrays;
/*    */ import java.util.Collections;
/*    */ import java.util.List;
/*    */ import org.eclipse.core.runtime.Assert;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class TemplateVariableType
/*    */ {
/*    */   private final String fName;
/*    */   private final List<String> fParams;
/*    */   
/*    */   TemplateVariableType(String name) {
/* 39 */     this(name, new String[0]);
/*    */   }
/*    */   
/*    */   TemplateVariableType(String name, String[] params) {
/* 43 */     Assert.isLegal((name != null));
/* 44 */     Assert.isLegal((params != null));
/* 45 */     this.fName = name;
/* 46 */     this.fParams = Collections.unmodifiableList(new ArrayList<>(Arrays.asList(params)));
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String getName() {
/* 55 */     return this.fName;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public List<String> getParams() {
/* 64 */     return this.fParams;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean equals(Object obj) {
/* 69 */     if (obj instanceof TemplateVariableType) {
/* 70 */       TemplateVariableType other = (TemplateVariableType)obj;
/* 71 */       return (other.fName.equals(this.fName) && other.fParams.equals(this.fParams));
/*    */     } 
/* 73 */     return false;
/*    */   }
/*    */ 
/*    */   
/*    */   public int hashCode() {
/* 78 */     return this.fName.hashCode() + this.fParams.hashCode();
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 83 */     return String.valueOf(this.fName) + this.fParams.toString();
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.text-3.13.0.jar!\org\eclipse\jface\text\templates\TemplateVariableType.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */