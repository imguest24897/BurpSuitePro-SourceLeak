/*    */ package org.eclipse.jface.text;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TypedRegion
/*    */   extends Region
/*    */   implements ITypedRegion
/*    */ {
/*    */   private String fType;
/*    */   
/*    */   public TypedRegion(int offset, int length, String type) {
/* 34 */     super(offset, length);
/* 35 */     this.fType = type;
/*    */   }
/*    */ 
/*    */   
/*    */   public String getType() {
/* 40 */     return this.fType;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean equals(Object o) {
/* 45 */     if (o instanceof TypedRegion) {
/* 46 */       TypedRegion r = (TypedRegion)o;
/* 47 */       return (super.equals(r) && ((this.fType == null && r.getType() == null) || this.fType.equals(r.getType())));
/*    */     } 
/* 49 */     return false;
/*    */   }
/*    */ 
/*    */   
/*    */   public int hashCode() {
/* 54 */     int type = (this.fType == null) ? 0 : this.fType.hashCode();
/* 55 */     return super.hashCode() | type;
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 60 */     return String.valueOf(this.fType) + " - " + super.toString();
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.text-3.13.0.jar!\org\eclipse\jface\text\TypedRegion.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */