/*     */ package org.eclipse.jface.text;
/*     */ 
/*     */ import org.eclipse.core.runtime.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Position
/*     */ {
/*     */   public int offset;
/*     */   public int length;
/*     */   public boolean isDeleted;
/*     */   
/*     */   public Position(int offset) {
/*  55 */     this(offset, 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Position(int offset, int length) {
/*  65 */     Assert.isTrue((offset >= 0));
/*  66 */     Assert.isTrue((length >= 0));
/*  67 */     this.offset = offset;
/*  68 */     this.length = length;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Position() {}
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/*  79 */     int deleted = this.isDeleted ? 0 : 1;
/*  80 */     return this.offset << 24 | this.length << 16 | deleted;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void delete() {
/*  87 */     this.isDeleted = true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void undelete() {
/*  96 */     this.isDeleted = false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object other) {
/* 101 */     if (other instanceof Position) {
/* 102 */       Position rp = (Position)other;
/* 103 */       return (rp.offset == this.offset && rp.length == this.length);
/*     */     } 
/* 105 */     return super.equals(other);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getLength() {
/* 114 */     return this.length;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getOffset() {
/* 123 */     return this.offset;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean includes(int index) {
/* 135 */     if (this.isDeleted) {
/* 136 */       return false;
/*     */     }
/* 138 */     return (this.offset <= index && index < this.offset + this.length);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean overlapsWith(int rangeOffset, int rangeLength) {
/* 152 */     if (this.isDeleted) {
/* 153 */       return false;
/*     */     }
/* 155 */     int end = rangeOffset + rangeLength;
/* 156 */     int thisEnd = this.offset + this.length;
/*     */     
/* 158 */     if (rangeLength > 0) {
/* 159 */       if (this.length > 0)
/* 160 */         return (this.offset < end && rangeOffset < thisEnd); 
/* 161 */       return (rangeOffset <= this.offset && this.offset < end);
/*     */     } 
/*     */     
/* 164 */     if (this.length > 0)
/* 165 */       return (this.offset <= rangeOffset && rangeOffset < thisEnd); 
/* 166 */     return (this.offset == rangeOffset);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isDeleted() {
/* 175 */     return this.isDeleted;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setLength(int length) {
/* 184 */     Assert.isTrue((length >= 0));
/* 185 */     this.length = length;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setOffset(int offset) {
/* 194 */     Assert.isTrue((offset >= 0));
/* 195 */     this.offset = offset;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 200 */     String position = "offset: " + this.offset + ", length: " + this.length;
/* 201 */     return this.isDeleted ? (String.valueOf(position) + " (deleted)") : position;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.text-3.13.0.jar!\org\eclipse\jface\text\Position.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */