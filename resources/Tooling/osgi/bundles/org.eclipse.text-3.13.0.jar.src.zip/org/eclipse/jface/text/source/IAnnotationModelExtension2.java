package org.eclipse.jface.text.source;

import java.util.Iterator;

public interface IAnnotationModelExtension2 {
  Iterator<Annotation> getAnnotationIterator(int paramInt1, int paramInt2, boolean paramBoolean1, boolean paramBoolean2);
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.text-3.13.0.jar!\org\eclipse\jface\text\source\IAnnotationModelExtension2.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */