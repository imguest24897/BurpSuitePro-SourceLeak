/*    */ package org.eclipse.jface.text;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class BadPartitioningException
/*    */   extends Exception
/*    */ {
/*    */   private static final long serialVersionUID = 3256439205327876408L;
/*    */   
/*    */   public BadPartitioningException() {}
/*    */   
/*    */   public BadPartitioningException(String message) {
/* 49 */     super(message);
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.text-3.13.0.jar!\org\eclipse\jface\text\BadPartitioningException.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */