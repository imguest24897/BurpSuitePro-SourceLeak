/*     */ package org.eclipse.jface.text;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class SessionData
/*     */ {
/*     */   private volatile DocumentRewriteSession fActiveRewriteSession;
/*     */   private List<AbstractLineTracker.Request> fPendingRequests;
/*     */   
/*     */   SessionData(DocumentRewriteSession activeRewriteSession) {
/* 115 */     this.fActiveRewriteSession = activeRewriteSession;
/* 116 */     if (activeRewriteSession != null) {
/* 117 */       this.fPendingRequests = new ArrayList<>(20);
/*     */     } else {
/* 119 */       this.fPendingRequests = Collections.emptyList();
/*     */     } 
/*     */   }
/*     */   
/*     */   boolean isSessionActive() {
/* 124 */     return (this.fActiveRewriteSession != null);
/*     */   }
/*     */   
/*     */   boolean setIfActive(String text) {
/* 128 */     if (isSessionActive()) {
/* 129 */       synchronized (this) {
/* 130 */         if (!isSessionActive()) {
/* 131 */           return false;
/*     */         }
/* 133 */         this.fPendingRequests.clear();
/* 134 */         this.fPendingRequests.add(new AbstractLineTracker.Request(text));
/*     */       } 
/* 136 */       return true;
/*     */     } 
/* 138 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   boolean addIfActive(int offset, int length, String text) {
/* 143 */     if (isSessionActive()) {
/* 144 */       synchronized (this) {
/* 145 */         if (!isSessionActive()) {
/* 146 */           return false;
/*     */         }
/* 148 */         this.fPendingRequests.add(new AbstractLineTracker.Request(offset, length, text));
/*     */       } 
/* 150 */       return true;
/*     */     } 
/* 152 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   Iterator<AbstractLineTracker.Request> flush() {
/* 157 */     synchronized (this) {
/* 158 */       this.fActiveRewriteSession = null;
/* 159 */       Iterator<AbstractLineTracker.Request> requests = this.fPendingRequests.iterator();
/* 160 */       this.fPendingRequests = Collections.emptyList();
/* 161 */       return requests;
/*     */     } 
/*     */   }
/*     */   
/*     */   boolean sameSession(DocumentRewriteSession session) {
/* 166 */     return (this.fActiveRewriteSession == session);
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 171 */     StringBuilder builder = new StringBuilder();
/* 172 */     builder.append("SessionData [");
/* 173 */     builder.append("activeRewriteSession=");
/* 174 */     builder.append(this.fActiveRewriteSession);
/* 175 */     builder.append(", ");
/* 176 */     builder.append("pendingRequests=");
/* 177 */     builder.append(this.fPendingRequests);
/* 178 */     builder.append("]");
/* 179 */     return builder.toString();
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.text-3.13.0.jar!\org\eclipse\jface\text\AbstractLineTracker$SessionData.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */