package org.eclipse.jface.text;

public interface ILineTracker {
  String[] getLegalLineDelimiters();
  
  String getLineDelimiter(int paramInt) throws BadLocationException;
  
  int computeNumberOfLines(String paramString);
  
  int getNumberOfLines();
  
  int getNumberOfLines(int paramInt1, int paramInt2) throws BadLocationException;
  
  int getLineOffset(int paramInt) throws BadLocationException;
  
  int getLineLength(int paramInt) throws BadLocationException;
  
  int getLineNumberOfOffset(int paramInt) throws BadLocationException;
  
  IRegion getLineInformationOfOffset(int paramInt) throws BadLocationException;
  
  IRegion getLineInformation(int paramInt) throws BadLocationException;
  
  void replace(int paramInt1, int paramInt2, String paramString) throws BadLocationException;
  
  void set(String paramString);
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.text-3.13.0.jar!\org\eclipse\jface\text\ILineTracker.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */