/*    */ package org.eclipse.jface.text;
/*    */ 
/*    */ import org.eclipse.core.runtime.Assert;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ConfigurableLineTracker
/*    */   extends AbstractLineTracker
/*    */ {
/*    */   private final String[] fDelimiters;
/* 40 */   private final AbstractLineTracker.DelimiterInfo fDelimiterInfo = new AbstractLineTracker.DelimiterInfo();
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   private final MultiStringMatcher fMatcher;
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public ConfigurableLineTracker(String[] legalLineDelimiters) {
/* 51 */     Assert.isTrue((legalLineDelimiters != null && legalLineDelimiters.length > 0));
/* 52 */     this.fDelimiters = TextUtilities.copy(legalLineDelimiters);
/* 53 */     this.fMatcher = (legalLineDelimiters.length > 1) ? MultiStringMatcher.create(legalLineDelimiters) : null;
/*    */   }
/*    */ 
/*    */   
/*    */   public String[] getLegalLineDelimiters() {
/* 58 */     return TextUtilities.copy(this.fDelimiters);
/*    */   }
/*    */ 
/*    */   
/*    */   protected AbstractLineTracker.DelimiterInfo nextDelimiterInfo(String text, int offset) {
/* 63 */     if (this.fMatcher != null) {
/* 64 */       MultiStringMatcher.Match m = this.fMatcher.indexOf(text, offset);
/* 65 */       if (m == null) {
/* 66 */         return null;
/*    */       }
/* 68 */       this.fDelimiterInfo.delimiterIndex = m.getOffset();
/* 69 */       this.fDelimiterInfo.delimiter = m.getText();
/*    */     } else {
/* 71 */       int index = text.indexOf(this.fDelimiters[0], offset);
/* 72 */       if (index == -1)
/* 73 */         return null; 
/* 74 */       this.fDelimiterInfo.delimiterIndex = index;
/* 75 */       this.fDelimiterInfo.delimiter = this.fDelimiters[0];
/*    */     } 
/*    */     
/* 78 */     this.fDelimiterInfo.delimiterLength = this.fDelimiterInfo.delimiter.length();
/* 79 */     return this.fDelimiterInfo;
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.text-3.13.0.jar!\org\eclipse\jface\text\ConfigurableLineTracker.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */