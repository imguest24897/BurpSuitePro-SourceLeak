/*     */ package org.eclipse.jface.text.projection;
/*     */ 
/*     */ import org.eclipse.core.runtime.Assert;
/*     */ import org.eclipse.jface.text.BadPositionCategoryException;
/*     */ import org.eclipse.jface.text.DefaultPositionUpdater;
/*     */ import org.eclipse.jface.text.DocumentEvent;
/*     */ import org.eclipse.jface.text.Position;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class SegmentUpdater
/*     */   extends DefaultPositionUpdater
/*     */ {
/*  36 */   private Segment fNextSegment = null;
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean fIsProjectionChange = false;
/*     */ 
/*     */ 
/*     */   
/*     */   protected SegmentUpdater(String segmentCategory) {
/*  45 */     super(segmentCategory);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void update(DocumentEvent event) {
/*  51 */     Assert.isTrue(event instanceof ProjectionDocumentEvent);
/*  52 */     this.fIsProjectionChange = (((ProjectionDocumentEvent)event).getChangeType() == ProjectionDocumentEvent.PROJECTION_CHANGE);
/*     */ 
/*     */     
/*     */     try {
/*  56 */       Position[] category = event.getDocument().getPositions(getCategory());
/*     */       
/*  58 */       this.fOffset = event.getOffset();
/*  59 */       this.fLength = event.getLength();
/*  60 */       this.fReplaceLength = (event.getText() == null) ? 0 : event.getText().length();
/*  61 */       this.fDocument = event.getDocument();
/*     */       
/*  63 */       for (int i = 0; i < category.length; i++)
/*     */       {
/*  65 */         this.fPosition = category[i];
/*  66 */         Assert.isTrue(this.fPosition instanceof Segment);
/*     */         
/*  68 */         if (i < category.length - 1) {
/*  69 */           this.fNextSegment = (Segment)category[i + 1];
/*     */         } else {
/*  71 */           this.fNextSegment = null;
/*     */         } 
/*  73 */         this.fOriginalPosition.offset = this.fPosition.offset;
/*  74 */         this.fOriginalPosition.length = this.fPosition.length;
/*     */         
/*  76 */         if (notDeleted()) {
/*  77 */           adaptToReplace();
/*     */         }
/*     */       }
/*     */     
/*  81 */     } catch (BadPositionCategoryException badPositionCategoryException) {}
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void adaptToInsert() {
/*  89 */     Segment segment = (Segment)this.fPosition;
/*  90 */     int myStart = segment.offset;
/*  91 */     int myEnd = segment.offset + segment.length - ((segment.isMarkedForStretch || this.fNextSegment == null || isAffectingReplace()) ? 0 : 1);
/*  92 */     myEnd = Math.max(myStart, myEnd);
/*  93 */     int yoursStart = this.fOffset;
/*     */ 
/*     */     
/*     */     try {
/*  97 */       if (myEnd < yoursStart) {
/*     */         return;
/*     */       }
/* 100 */       if (segment.isMarkedForStretch) {
/* 101 */         Assert.isTrue(this.fIsProjectionChange);
/* 102 */         segment.isMarkedForShift = false;
/* 103 */         if (this.fNextSegment != null) {
/* 104 */           this.fNextSegment.isMarkedForShift = true;
/* 105 */           this.fNextSegment.isMarkedForStretch = false;
/*     */         } 
/*     */       } 
/*     */       
/* 109 */       if (this.fLength <= 0) {
/*     */         
/* 111 */         if (myStart < yoursStart + (segment.isMarkedForShift ? 0 : 1)) {
/* 112 */           this.fPosition.length += this.fReplaceLength;
/*     */         } else {
/* 114 */           this.fPosition.offset += this.fReplaceLength;
/*     */         }
/*     */       
/*     */       }
/* 118 */       else if (myStart <= yoursStart && this.fOriginalPosition.offset <= yoursStart) {
/* 119 */         this.fPosition.length += this.fReplaceLength;
/*     */       } else {
/* 121 */         this.fPosition.offset += this.fReplaceLength;
/*     */       } 
/*     */     } finally {
/*     */       
/* 125 */       segment.clearMark();
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.text-3.13.0.jar!\org\eclipse\jface\text\projection\SegmentUpdater.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */