/*     */ package org.eclipse.jface.text.projection;
/*     */ 
/*     */ import org.eclipse.core.runtime.Assert;
/*     */ import org.eclipse.jface.text.BadLocationException;
/*     */ import org.eclipse.jface.text.BadPositionCategoryException;
/*     */ import org.eclipse.jface.text.IDocument;
/*     */ import org.eclipse.jface.text.IDocumentInformationMapping;
/*     */ import org.eclipse.jface.text.IDocumentInformationMappingExtension;
/*     */ import org.eclipse.jface.text.IDocumentInformationMappingExtension2;
/*     */ import org.eclipse.jface.text.IRegion;
/*     */ import org.eclipse.jface.text.Position;
/*     */ import org.eclipse.jface.text.Region;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ProjectionMapping
/*     */   implements IDocumentInformationMapping, IDocumentInformationMappingExtension, IDocumentInformationMappingExtension2, IMinimalMapping
/*     */ {
/*     */   private static final int LEFT = -1;
/*     */   private static final int NONE = 0;
/*     */   private static final int RIGHT = 1;
/*     */   private IDocument fMasterDocument;
/*     */   private String fFragmentsCategory;
/*     */   private IDocument fSlaveDocument;
/*     */   private String fSegmentsCategory;
/*     */   private Position[] fCachedSegments;
/*     */   private Position[] fCachedFragments;
/*     */   
/*     */   public ProjectionMapping(IDocument masterDocument, String fragmentsCategory, IDocument slaveDocument, String segmentsCategory) {
/*  67 */     this.fMasterDocument = masterDocument;
/*  68 */     this.fFragmentsCategory = fragmentsCategory;
/*  69 */     this.fSlaveDocument = slaveDocument;
/*  70 */     this.fSegmentsCategory = segmentsCategory;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void projectionChanged() {
/*  77 */     this.fCachedSegments = null;
/*  78 */     this.fCachedFragments = null;
/*     */   }
/*     */   
/*     */   private Position[] getSegments() {
/*  82 */     if (this.fCachedSegments == null) {
/*     */       try {
/*  84 */         this.fCachedSegments = this.fSlaveDocument.getPositions(this.fSegmentsCategory);
/*  85 */       } catch (BadPositionCategoryException badPositionCategoryException) {
/*  86 */         return new Position[0];
/*     */       } 
/*     */     }
/*  89 */     return this.fCachedSegments;
/*     */   }
/*     */   
/*     */   private Position[] getFragments() {
/*  93 */     if (this.fCachedFragments == null) {
/*     */       try {
/*  95 */         this.fCachedFragments = this.fMasterDocument.getPositions(this.fFragmentsCategory);
/*  96 */       } catch (BadPositionCategoryException badPositionCategoryException) {
/*  97 */         return new Position[0];
/*     */       } 
/*     */     }
/* 100 */     return this.fCachedFragments;
/*     */   }
/*     */   
/*     */   private int findSegmentIndex(int offset) throws BadLocationException {
/* 104 */     Position[] segments = getSegments();
/* 105 */     if (segments.length == 0) {
/* 106 */       if (offset > 0)
/* 107 */         throw new BadLocationException(); 
/* 108 */       return -1;
/*     */     } 
/*     */     
/*     */     try {
/* 112 */       int index = this.fSlaveDocument.computeIndexInCategory(this.fSegmentsCategory, offset);
/* 113 */       if (index == segments.length && offset > exclusiveEnd(segments[index - 1])) {
/* 114 */         throw new BadLocationException();
/*     */       }
/* 116 */       if (index < segments.length && offset == (segments[index]).offset) {
/* 117 */         return index;
/*     */       }
/* 119 */       if (index > 0) {
/* 120 */         index--;
/*     */       }
/* 122 */       return index;
/*     */     }
/* 124 */     catch (BadPositionCategoryException badPositionCategoryException) {
/* 125 */       throw new IllegalStateException();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private Segment findSegment(int offset) throws BadLocationException {
/* 131 */     checkImageOffset(offset);
/*     */     
/* 133 */     int index = findSegmentIndex(offset);
/* 134 */     if (index == -1) {
/*     */       
/* 136 */       Segment s = new Segment(0, 0);
/* 137 */       Fragment f = new Fragment(0, 0);
/* 138 */       s.fragment = f;
/* 139 */       f.segment = s;
/* 140 */       return s;
/*     */     } 
/*     */     
/* 143 */     Position[] segments = getSegments();
/* 144 */     return (Segment)segments[index];
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int findFragmentIndex(int offset, int extensionDirection) throws BadLocationException {
/*     */     try {
/* 173 */       Position[] fragments = getFragments();
/* 174 */       if (fragments.length == 0) {
/* 175 */         return -1;
/*     */       }
/* 177 */       int index = this.fMasterDocument.computeIndexInCategory(this.fFragmentsCategory, offset);
/*     */       
/* 179 */       if (index < fragments.length && offset == (fragments[index]).offset) {
/* 180 */         return index;
/*     */       }
/* 182 */       if (index > 0 && index <= fragments.length && fragments[index - 1].includes(offset)) {
/* 183 */         return index - 1;
/*     */       }
/* 185 */       switch (extensionDirection) {
/*     */         case -1:
/* 187 */           return index - 1;
/*     */         case 1:
/* 189 */           if (index < fragments.length)
/* 190 */             return index; 
/*     */           break;
/*     */       } 
/* 193 */       return -1;
/*     */     }
/* 195 */     catch (BadPositionCategoryException badPositionCategoryException) {
/* 196 */       throw new IllegalStateException();
/*     */     } 
/*     */   }
/*     */   
/*     */   private Fragment findFragment(int offset) throws BadLocationException {
/* 201 */     checkOriginOffset(offset);
/*     */     
/* 203 */     int index = findFragmentIndex(offset, 0);
/* 204 */     Position[] fragments = getFragments();
/* 205 */     if (index == -1) {
/* 206 */       if (fragments.length > 0) {
/* 207 */         Fragment last = (Fragment)fragments[fragments.length - 1];
/* 208 */         if (exclusiveEnd(last) == offset)
/* 209 */           return last; 
/*     */       } 
/* 211 */       return null;
/*     */     } 
/* 213 */     return (Fragment)fragments[index];
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private IRegion toImageRegion(IRegion originRegion, boolean exact, boolean takeClosestImage) throws BadLocationException {
/* 232 */     if (originRegion.getLength() == 0 && !takeClosestImage) {
/* 233 */       int i = toImageOffset(originRegion.getOffset());
/* 234 */       return (i == -1) ? null : (IRegion)new Region(i, 0);
/*     */     } 
/*     */     
/* 237 */     Fragment[] fragments = findFragments(originRegion, exact, takeClosestImage);
/* 238 */     if (fragments == null) {
/* 239 */       if (takeClosestImage) {
/*     */         
/* 241 */         Position[] allFragments = getFragments();
/* 242 */         if (allFragments.length > 0) {
/*     */           
/* 244 */           if (exclusiveEnd(originRegion) <= allFragments[0].getOffset()) {
/* 245 */             return (IRegion)new Region(0, 0);
/*     */           }
/* 247 */           Position last = allFragments[allFragments.length - 1];
/* 248 */           if (originRegion.getOffset() >= exclusiveEnd(last))
/* 249 */             return (IRegion)new Region(exclusiveEnd(((Fragment)last).segment), 0); 
/*     */         } 
/* 251 */         return (IRegion)new Region(0, 0);
/*     */       } 
/* 253 */       return null;
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 259 */     int relative = originRegion.getOffset() - fragments[0].getOffset();
/* 260 */     if (relative < 0) {
/* 261 */       Assert.isTrue(!exact);
/* 262 */       relative = 0;
/*     */     } 
/* 264 */     int imageOffset = (fragments[0]).segment.getOffset() + relative;
/*     */ 
/*     */     
/* 267 */     relative = exclusiveEnd(originRegion) - fragments[1].getOffset();
/* 268 */     if (relative > fragments[1].getLength()) {
/* 269 */       Assert.isTrue(!exact);
/* 270 */       relative = fragments[1].getLength();
/*     */     } 
/* 272 */     int exclusiveImageEndOffset = (fragments[1]).segment.getOffset() + relative;
/*     */     
/* 274 */     return (IRegion)new Region(imageOffset, exclusiveImageEndOffset - imageOffset);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Fragment[] findFragments(IRegion originRegion, boolean exact, boolean takeClosestImage) throws BadLocationException {
/* 295 */     Position[] fragments = getFragments();
/* 296 */     if (fragments.length == 0) {
/* 297 */       return null;
/*     */     }
/* 299 */     checkOriginRegion(originRegion);
/*     */     
/* 301 */     int startFragmentIdx = findFragmentIndex(originRegion.getOffset(), exact ? 0 : 1);
/* 302 */     if (startFragmentIdx == -1) {
/* 303 */       return null;
/*     */     }
/* 305 */     int endFragmentIdx = findFragmentIndex(inclusiveEnd(originRegion), exact ? 0 : -1);
/* 306 */     if ((!takeClosestImage && startFragmentIdx > endFragmentIdx) || endFragmentIdx == -1) {
/* 307 */       return null;
/*     */     }
/* 309 */     Fragment[] result = { (Fragment)fragments[startFragmentIdx], (Fragment)fragments[endFragmentIdx] };
/* 310 */     return result;
/*     */   }
/*     */   
/*     */   private IRegion createOriginStartRegion(Segment image, int offsetShift) {
/* 314 */     return (IRegion)new Region(image.fragment.getOffset() + offsetShift, image.fragment.getLength() - offsetShift);
/*     */   }
/*     */   
/*     */   private IRegion createOriginRegion(Segment image) {
/* 318 */     return (IRegion)new Region(image.fragment.getOffset(), image.fragment.getLength());
/*     */   }
/*     */   
/*     */   private IRegion createOriginEndRegion(Segment image, int lengthReduction) {
/* 322 */     return (IRegion)new Region(image.fragment.getOffset(), image.fragment.getLength() - lengthReduction);
/*     */   }
/*     */   
/*     */   private IRegion createImageStartRegion(Fragment origin, int offsetShift) {
/* 326 */     int shift = (offsetShift > 0) ? offsetShift : 0;
/* 327 */     return (IRegion)new Region(origin.segment.getOffset() + shift, origin.segment.getLength() - shift);
/*     */   }
/*     */   
/*     */   private IRegion createImageRegion(Fragment origin) {
/* 331 */     return (IRegion)new Region(origin.segment.getOffset(), origin.segment.getLength());
/*     */   }
/*     */   
/*     */   private IRegion createImageEndRegion(Fragment origin, int lengthReduction) {
/* 335 */     int reduction = (lengthReduction > 0) ? lengthReduction : 0;
/* 336 */     return (IRegion)new Region(origin.segment.getOffset(), origin.segment.getLength() - reduction);
/*     */   }
/*     */   
/*     */   private IRegion createOriginStartRegion(Fragment origin, int offsetShift) {
/* 340 */     int shift = (offsetShift > 0) ? offsetShift : 0;
/* 341 */     return (IRegion)new Region(origin.getOffset() + shift, origin.getLength() - shift);
/*     */   }
/*     */   
/*     */   private IRegion createOriginRegion(Fragment origin) {
/* 345 */     return (IRegion)new Region(origin.getOffset(), origin.getLength());
/*     */   }
/*     */   
/*     */   private IRegion createOriginEndRegion(Fragment origin, int lengthReduction) {
/* 349 */     int reduction = (lengthReduction > 0) ? lengthReduction : 0;
/* 350 */     return (IRegion)new Region(origin.getOffset(), origin.getLength() - reduction);
/*     */   }
/*     */   
/*     */   private IRegion getIntersectingRegion(IRegion left, IRegion right) {
/* 354 */     int offset = Math.max(left.getOffset(), right.getOffset());
/* 355 */     int exclusiveEndOffset = Math.min(exclusiveEnd(left), exclusiveEnd(right));
/* 356 */     if (exclusiveEndOffset < offset)
/* 357 */       return null; 
/* 358 */     return (IRegion)new Region(offset, exclusiveEndOffset - offset);
/*     */   }
/*     */ 
/*     */   
/*     */   public IRegion getCoverage() {
/* 363 */     Position[] fragments = getFragments();
/* 364 */     if (fragments != null && fragments.length > 0) {
/* 365 */       Position first = fragments[0];
/* 366 */       Position last = fragments[fragments.length - 1];
/* 367 */       return (IRegion)new Region(first.offset, exclusiveEnd(last) - first.offset);
/*     */     } 
/* 369 */     return (IRegion)new Region(0, 0);
/*     */   }
/*     */ 
/*     */   
/*     */   public int toOriginOffset(int imageOffset) throws BadLocationException {
/* 374 */     Segment segment = findSegment(imageOffset);
/* 375 */     int relative = imageOffset - segment.offset;
/* 376 */     return segment.fragment.offset + relative;
/*     */   }
/*     */ 
/*     */   
/*     */   public IRegion toOriginRegion(IRegion imageRegion) throws BadLocationException {
/* 381 */     int imageOffset = imageRegion.getOffset();
/* 382 */     int imageLength = imageRegion.getLength();
/*     */     
/* 384 */     if (imageLength == 0) {
/* 385 */       if (imageOffset == 0) {
/* 386 */         Position[] fragments = getFragments();
/* 387 */         if (fragments.length == 0 || (fragments.length == 1 && fragments[0].getOffset() == 0 && fragments[0].getLength() == 0))
/* 388 */           return (IRegion)new Region(0, this.fMasterDocument.getLength()); 
/*     */       } 
/* 390 */       return (IRegion)new Region(toOriginOffset(imageOffset), 0);
/*     */     } 
/*     */     
/* 393 */     int originOffset = toOriginOffset(imageOffset);
/* 394 */     int inclusiveImageEndOffset = imageOffset + imageLength - 1;
/* 395 */     int inclusiveOriginEndOffset = toOriginOffset(inclusiveImageEndOffset);
/*     */     
/* 397 */     return (IRegion)new Region(originOffset, inclusiveOriginEndOffset + 1 - originOffset);
/*     */   }
/*     */ 
/*     */   
/*     */   public IRegion toOriginLines(int imageLine) throws BadLocationException {
/* 402 */     IRegion imageRegion = this.fSlaveDocument.getLineInformation(imageLine);
/* 403 */     IRegion originRegion = toOriginRegion(imageRegion);
/*     */     
/* 405 */     int originStartLine = this.fMasterDocument.getLineOfOffset(originRegion.getOffset());
/* 406 */     if (originRegion.getLength() == 0) {
/* 407 */       return (IRegion)new Region(originStartLine, 1);
/*     */     }
/* 409 */     int originEndLine = this.fMasterDocument.getLineOfOffset(inclusiveEnd(originRegion));
/* 410 */     return (IRegion)new Region(originStartLine, originEndLine + 1 - originStartLine);
/*     */   }
/*     */ 
/*     */   
/*     */   public int toOriginLine(int imageLine) throws BadLocationException {
/* 415 */     IRegion lines = toOriginLines(imageLine);
/* 416 */     return (lines.getLength() > 1) ? -1 : lines.getOffset();
/*     */   }
/*     */ 
/*     */   
/*     */   public int toImageOffset(int originOffset) throws BadLocationException {
/* 421 */     Fragment fragment = findFragment(originOffset);
/* 422 */     if (fragment != null) {
/* 423 */       int relative = originOffset - fragment.offset;
/* 424 */       return fragment.segment.offset + relative;
/*     */     } 
/* 426 */     return -1;
/*     */   }
/*     */ 
/*     */   
/*     */   public IRegion toExactImageRegion(IRegion originRegion) throws BadLocationException {
/* 431 */     return toImageRegion(originRegion, true, false);
/*     */   }
/*     */ 
/*     */   
/*     */   public IRegion toImageRegion(IRegion originRegion) throws BadLocationException {
/* 436 */     return toImageRegion(originRegion, false, false);
/*     */   }
/*     */ 
/*     */   
/*     */   public IRegion toClosestImageRegion(IRegion originRegion) throws BadLocationException {
/* 441 */     return toImageRegion(originRegion, false, true);
/*     */   }
/*     */   
/*     */   public int toImageLine(int originLine) throws BadLocationException {
/*     */     Region region;
/* 446 */     IRegion originRegion = this.fMasterDocument.getLineInformation(originLine);
/* 447 */     IRegion imageRegion = toImageRegion(originRegion);
/* 448 */     if (imageRegion == null) {
/* 449 */       int imageOffset = toImageOffset(originRegion.getOffset());
/* 450 */       if (imageOffset > -1) {
/* 451 */         region = new Region(imageOffset, 0);
/*     */       } else {
/* 453 */         return -1;
/*     */       } 
/*     */     } 
/* 456 */     int startLine = this.fSlaveDocument.getLineOfOffset(region.getOffset());
/* 457 */     if (region.getLength() == 0) {
/* 458 */       return startLine;
/*     */     }
/* 460 */     int endLine = this.fSlaveDocument.getLineOfOffset(region.getOffset() + region.getLength());
/* 461 */     if (endLine != startLine) {
/* 462 */       throw new IllegalStateException("startLine (" + startLine + ") does not match endLine (" + endLine + ")");
/*     */     }
/* 464 */     return startLine;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int toClosestImageLine(int originLine) throws BadLocationException {
/*     */     try {
/* 471 */       int imageLine = toImageLine(originLine);
/* 472 */       if (imageLine > -1) {
/* 473 */         return imageLine;
/*     */       }
/* 475 */       Position[] fragments = getFragments();
/* 476 */       if (fragments.length == 0) {
/* 477 */         return -1;
/*     */       }
/* 479 */       IRegion originLineRegion = this.fMasterDocument.getLineInformation(originLine);
/* 480 */       int index = this.fMasterDocument.computeIndexInCategory(this.fFragmentsCategory, originLineRegion.getOffset());
/*     */       
/* 482 */       if (index > 0 && index < fragments.length) {
/* 483 */         Fragment left = (Fragment)fragments[index - 1];
/* 484 */         int leftDistance = originLineRegion.getOffset() - exclusiveEnd(left);
/* 485 */         Fragment right = (Fragment)fragments[index];
/* 486 */         int rightDistance = right.getOffset() - exclusiveEnd(originLineRegion);
/*     */         
/* 488 */         if (leftDistance <= rightDistance) {
/* 489 */           originLine = this.fMasterDocument.getLineOfOffset(left.getOffset() + Math.max(left.getLength() - 1, 0));
/*     */         } else {
/* 491 */           originLine = this.fMasterDocument.getLineOfOffset(right.getOffset());
/*     */         } 
/* 493 */       } else if (index == 0) {
/* 494 */         Fragment right = (Fragment)fragments[index];
/* 495 */         originLine = this.fMasterDocument.getLineOfOffset(right.getOffset());
/* 496 */       } else if (index == fragments.length) {
/* 497 */         Fragment left = (Fragment)fragments[index - 1];
/* 498 */         originLine = this.fMasterDocument.getLineOfOffset(exclusiveEnd(left));
/*     */       } 
/*     */       
/* 501 */       return toImageLine(originLine);
/*     */     }
/* 503 */     catch (BadPositionCategoryException badPositionCategoryException) {
/*     */ 
/*     */       
/* 506 */       return -1;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public IRegion[] toExactOriginRegions(IRegion imageRegion) throws BadLocationException {
/* 512 */     if (imageRegion.getLength() == 0) {
/* 513 */       return new IRegion[] { (IRegion)new Region(toOriginOffset(imageRegion.getOffset()), 0) };
/*     */     }
/* 515 */     int endOffset = exclusiveEnd(imageRegion);
/* 516 */     Position[] segments = getSegments();
/* 517 */     int firstIndex = findSegmentIndex(imageRegion.getOffset());
/* 518 */     int lastIndex = findSegmentIndex(endOffset - 1);
/*     */     
/* 520 */     int resultLength = lastIndex - firstIndex + 1;
/* 521 */     IRegion[] result = new IRegion[resultLength];
/*     */ 
/*     */     
/* 524 */     result[0] = createOriginStartRegion((Segment)segments[firstIndex], imageRegion.getOffset() - segments[firstIndex].getOffset());
/*     */     
/* 526 */     for (int i = 1; i < resultLength - 1; i++) {
/* 527 */       result[i] = createOriginRegion((Segment)segments[firstIndex + i]);
/*     */     }
/* 529 */     Segment last = (Segment)segments[lastIndex];
/* 530 */     int segmentEndOffset = exclusiveEnd(last);
/* 531 */     IRegion lastRegion = createOriginEndRegion(last, segmentEndOffset - endOffset);
/* 532 */     if (resultLength > 1) {
/*     */       
/* 534 */       result[resultLength - 1] = lastRegion;
/*     */     } else {
/*     */       
/* 537 */       IRegion intersection = getIntersectingRegion(result[0], lastRegion);
/* 538 */       if (intersection == null) {
/* 539 */         result = new IRegion[0];
/*     */       } else {
/* 541 */         result[0] = intersection;
/*     */       } 
/*     */     } 
/* 544 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getImageLength() {
/* 549 */     Position[] segments = getSegments();
/* 550 */     int length = 0; byte b; int i; Position[] arrayOfPosition1;
/* 551 */     for (i = (arrayOfPosition1 = segments).length, b = 0; b < i; ) { Position segment = arrayOfPosition1[b];
/* 552 */       length += segment.length; b++; }
/*     */     
/* 554 */     return length;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public IRegion[] toExactImageRegions(IRegion originRegion) throws BadLocationException {
/* 560 */     int offset = originRegion.getOffset();
/* 561 */     if (originRegion.getLength() == 0) {
/* 562 */       int imageOffset = toImageOffset(offset);
/* 563 */       (new IRegion[1])[0] = (IRegion)new Region(imageOffset, 0); return (imageOffset > -1) ? new IRegion[1] : null;
/*     */     } 
/*     */     
/* 566 */     int endOffset = exclusiveEnd(originRegion);
/* 567 */     Position[] fragments = getFragments();
/* 568 */     int firstIndex = findFragmentIndex(offset, 1);
/* 569 */     int lastIndex = findFragmentIndex(endOffset - 1, -1);
/*     */     
/* 571 */     if (firstIndex == -1 || firstIndex > lastIndex) {
/* 572 */       return null;
/*     */     }
/* 574 */     int resultLength = lastIndex - firstIndex + 1;
/* 575 */     IRegion[] result = new IRegion[resultLength];
/*     */ 
/*     */     
/* 578 */     result[0] = createImageStartRegion((Fragment)fragments[firstIndex], offset - fragments[firstIndex].getOffset());
/*     */     
/* 580 */     for (int i = 1; i < resultLength - 1; i++) {
/* 581 */       result[i] = createImageRegion((Fragment)fragments[firstIndex + i]);
/*     */     }
/* 583 */     Fragment last = (Fragment)fragments[lastIndex];
/* 584 */     int fragmentEndOffset = exclusiveEnd(last);
/* 585 */     IRegion lastRegion = createImageEndRegion(last, fragmentEndOffset - endOffset);
/* 586 */     if (resultLength > 1) {
/*     */       
/* 588 */       result[resultLength - 1] = lastRegion;
/*     */     } else {
/*     */       
/* 591 */       IRegion intersection = getIntersectingRegion(result[0], lastRegion);
/* 592 */       if (intersection == null)
/* 593 */         return null; 
/* 594 */       result[0] = intersection;
/*     */     } 
/*     */     
/* 597 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public IRegion[] getExactCoverage(IRegion originRegion) throws BadLocationException {
/* 603 */     int originOffset = originRegion.getOffset();
/* 604 */     int originLength = originRegion.getLength();
/*     */     
/* 606 */     if (originLength == 0) {
/* 607 */       int imageOffset = toImageOffset(originOffset);
/* 608 */       (new IRegion[1])[0] = (IRegion)new Region(originOffset, 0); return (imageOffset > -1) ? new IRegion[1] : null;
/*     */     } 
/*     */     
/* 611 */     int endOffset = originOffset + originLength;
/* 612 */     Position[] fragments = getFragments();
/* 613 */     int firstIndex = findFragmentIndex(originOffset, 1);
/* 614 */     int lastIndex = findFragmentIndex(endOffset - 1, -1);
/*     */     
/* 616 */     if (firstIndex == -1 || firstIndex > lastIndex) {
/* 617 */       return null;
/*     */     }
/* 619 */     int resultLength = lastIndex - firstIndex + 1;
/* 620 */     IRegion[] result = new IRegion[resultLength];
/*     */ 
/*     */     
/* 623 */     result[0] = createOriginStartRegion((Fragment)fragments[firstIndex], originOffset - fragments[firstIndex].getOffset());
/*     */     
/* 625 */     for (int i = 1; i < resultLength - 1; i++) {
/* 626 */       result[i] = createOriginRegion((Fragment)fragments[firstIndex + i]);
/*     */     }
/* 628 */     Fragment last = (Fragment)fragments[lastIndex];
/* 629 */     int fragmentEndOffset = exclusiveEnd(last);
/* 630 */     IRegion lastRegion = createOriginEndRegion(last, fragmentEndOffset - endOffset);
/* 631 */     if (resultLength > 1) {
/*     */       
/* 633 */       result[resultLength - 1] = lastRegion;
/*     */     } else {
/*     */       
/* 636 */       IRegion intersection = getIntersectingRegion(result[0], lastRegion);
/* 637 */       if (intersection == null)
/* 638 */         return null; 
/* 639 */       result[0] = intersection;
/*     */     } 
/*     */     
/* 642 */     return result;
/*     */   }
/*     */   
/*     */   private final void checkOriginRegion(IRegion originRegion) throws BadLocationException {
/* 646 */     int offset = originRegion.getOffset();
/* 647 */     int endOffset = inclusiveEnd(originRegion);
/* 648 */     int max = this.fMasterDocument.getLength();
/* 649 */     if (offset < 0 || offset > max || endOffset < 0 || endOffset > max)
/* 650 */       throw new BadLocationException(); 
/*     */   }
/*     */   
/*     */   private final void checkOriginOffset(int originOffset) throws BadLocationException {
/* 654 */     if (originOffset < 0 || originOffset > this.fMasterDocument.getLength())
/* 655 */       throw new BadLocationException(); 
/*     */   }
/*     */   
/*     */   private final void checkImageOffset(int imageOffset) throws BadLocationException {
/* 659 */     if (imageOffset < 0 || imageOffset > getImageLength())
/* 660 */       throw new BadLocationException(); 
/*     */   }
/*     */   
/*     */   private final int exclusiveEnd(Position position) {
/* 664 */     return position.offset + position.length;
/*     */   }
/*     */   
/*     */   private final int exclusiveEnd(IRegion region) {
/* 668 */     return region.getOffset() + region.getLength();
/*     */   }
/*     */   
/*     */   private final int inclusiveEnd(IRegion region) {
/* 672 */     int length = region.getLength();
/* 673 */     if (length == 0)
/* 674 */       return region.getOffset(); 
/* 675 */     return region.getOffset() + length - 1;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.text-3.13.0.jar!\org\eclipse\jface\text\projection\ProjectionMapping.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */