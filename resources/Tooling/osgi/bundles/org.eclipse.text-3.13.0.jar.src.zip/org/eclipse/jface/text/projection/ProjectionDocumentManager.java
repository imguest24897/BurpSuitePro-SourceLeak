/*     */ package org.eclipse.jface.text.projection;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.eclipse.jface.text.DocumentEvent;
/*     */ import org.eclipse.jface.text.IDocument;
/*     */ import org.eclipse.jface.text.IDocumentInformationMapping;
/*     */ import org.eclipse.jface.text.IDocumentListener;
/*     */ import org.eclipse.jface.text.ISlaveDocumentManager;
/*     */ import org.eclipse.jface.text.ISlaveDocumentManagerExtension;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ProjectionDocumentManager
/*     */   implements IDocumentListener, ISlaveDocumentManager, ISlaveDocumentManagerExtension
/*     */ {
/*  53 */   private Map<IDocument, List<ProjectionDocument>> fProjectionRegistry = new HashMap<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void add(IDocument master, ProjectionDocument projection) {
/*  62 */     List<ProjectionDocument> list = this.fProjectionRegistry.get(master);
/*  63 */     if (list == null) {
/*  64 */       list = new ArrayList<>(1);
/*  65 */       this.fProjectionRegistry.put(master, list);
/*     */     } 
/*  67 */     list.add(projection);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void remove(IDocument master, ProjectionDocument projection) {
/*  77 */     List<ProjectionDocument> list = this.fProjectionRegistry.get(master);
/*  78 */     if (list != null) {
/*  79 */       list.remove(projection);
/*  80 */       if (list.isEmpty()) {
/*  81 */         this.fProjectionRegistry.remove(master);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean hasProjection(IDocument master) {
/*  92 */     return (this.fProjectionRegistry.get(master) != null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Iterator<ProjectionDocument> getProjectionsIterator(IDocument master) {
/* 103 */     List<ProjectionDocument> list = this.fProjectionRegistry.get(master);
/* 104 */     if (list != null)
/* 105 */       return list.iterator(); 
/* 106 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void fireDocumentEvent(boolean about, DocumentEvent masterEvent) {
/* 116 */     IDocument master = masterEvent.getDocument();
/* 117 */     Iterator<ProjectionDocument> e = getProjectionsIterator(master);
/* 118 */     if (e == null) {
/*     */       return;
/*     */     }
/* 121 */     while (e.hasNext()) {
/* 122 */       ProjectionDocument document = e.next();
/* 123 */       if (about) {
/* 124 */         document.masterDocumentAboutToBeChanged(masterEvent); continue;
/*     */       } 
/* 126 */       document.masterDocumentChanged(masterEvent);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void documentChanged(DocumentEvent event) {
/* 132 */     fireDocumentEvent(false, event);
/*     */   }
/*     */ 
/*     */   
/*     */   public void documentAboutToBeChanged(DocumentEvent event) {
/* 137 */     fireDocumentEvent(true, event);
/*     */   }
/*     */ 
/*     */   
/*     */   public IDocumentInformationMapping createMasterSlaveMapping(IDocument slave) {
/* 142 */     if (slave instanceof ProjectionDocument) {
/* 143 */       ProjectionDocument projectionDocument = (ProjectionDocument)slave;
/* 144 */       return projectionDocument.getDocumentInformationMapping();
/*     */     } 
/* 146 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public IDocument createSlaveDocument(IDocument master) {
/* 151 */     if (!hasProjection(master))
/* 152 */       master.addDocumentListener(this); 
/* 153 */     ProjectionDocument slave = createProjectionDocument(master);
/* 154 */     add(master, slave);
/* 155 */     return (IDocument)slave;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected ProjectionDocument createProjectionDocument(IDocument master) {
/* 165 */     return new ProjectionDocument(master);
/*     */   }
/*     */ 
/*     */   
/*     */   public void freeSlaveDocument(IDocument slave) {
/* 170 */     if (slave instanceof ProjectionDocument) {
/* 171 */       ProjectionDocument projectionDocument = (ProjectionDocument)slave;
/* 172 */       IDocument master = projectionDocument.getMasterDocument();
/* 173 */       remove(master, projectionDocument);
/* 174 */       projectionDocument.dispose();
/* 175 */       if (!hasProjection(master)) {
/* 176 */         master.removeDocumentListener(this);
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   public IDocument getMasterDocument(IDocument slave) {
/* 182 */     if (slave instanceof ProjectionDocument)
/* 183 */       return ((ProjectionDocument)slave).getMasterDocument(); 
/* 184 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isSlaveDocument(IDocument document) {
/* 189 */     return document instanceof ProjectionDocument;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setAutoExpandMode(IDocument slave, boolean autoExpanding) {
/* 194 */     if (slave instanceof ProjectionDocument) {
/* 195 */       ((ProjectionDocument)slave).setAutoExpandMode(autoExpanding);
/*     */     }
/*     */   }
/*     */   
/*     */   public IDocument[] getSlaveDocuments(IDocument master) {
/* 200 */     List<ProjectionDocument> list = this.fProjectionRegistry.get(master);
/* 201 */     if (list != null) {
/* 202 */       IDocument[] result = new IDocument[list.size()];
/* 203 */       list.toArray(result);
/* 204 */       return result;
/*     */     } 
/* 206 */     return null;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.text-3.13.0.jar!\org\eclipse\jface\text\projection\ProjectionDocumentManager.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */