/*    */ package org.eclipse.jface.text;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DocumentRewriteSessionType
/*    */ {
/* 41 */   public static final DocumentRewriteSessionType UNRESTRICTED = new DocumentRewriteSessionType();
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 48 */   public static final DocumentRewriteSessionType UNRESTRICTED_SMALL = new DocumentRewriteSessionType();
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 53 */   public static final DocumentRewriteSessionType SEQUENTIAL = new DocumentRewriteSessionType();
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 58 */   public static final DocumentRewriteSessionType STRICTLY_SEQUENTIAL = new DocumentRewriteSessionType();
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.text-3.13.0.jar!\org\eclipse\jface\text\DocumentRewriteSessionType.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */