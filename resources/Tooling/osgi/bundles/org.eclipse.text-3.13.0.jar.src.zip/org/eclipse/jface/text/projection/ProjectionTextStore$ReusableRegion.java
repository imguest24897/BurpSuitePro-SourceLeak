/*    */ package org.eclipse.jface.text.projection;
/*    */ 
/*    */ import org.eclipse.jface.text.IRegion;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class ReusableRegion
/*    */   implements IRegion
/*    */ {
/*    */   private int fOffset;
/*    */   private int fLength;
/*    */   
/*    */   public int getLength() {
/* 43 */     return this.fLength;
/*    */   }
/*    */ 
/*    */   
/*    */   public int getOffset() {
/* 48 */     return this.fOffset;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void update(int offset, int length) {
/* 58 */     this.fOffset = offset;
/* 59 */     this.fLength = length;
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.text-3.13.0.jar!\org\eclipse\jface\text\projection\ProjectionTextStore$ReusableRegion.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */