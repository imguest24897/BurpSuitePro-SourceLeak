/*    */ package org.eclipse.jface.text;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TypedPosition
/*    */   extends Position
/*    */ {
/*    */   private String fType;
/*    */   
/*    */   public TypedPosition(int offset, int length, String type) {
/* 38 */     super(offset, length);
/* 39 */     this.fType = type;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public TypedPosition(ITypedRegion region) {
/* 48 */     super(region.getOffset(), region.getLength());
/* 49 */     this.fType = region.getType();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String getType() {
/* 58 */     return this.fType;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean equals(Object o) {
/* 63 */     if (o instanceof TypedPosition && 
/* 64 */       super.equals(o)) {
/* 65 */       TypedPosition p = (TypedPosition)o;
/* 66 */       return !((this.fType != null || p.getType() != null) && !this.fType.equals(p.getType()));
/*    */     } 
/*    */     
/* 69 */     return false;
/*    */   }
/*    */ 
/*    */   
/*    */   public int hashCode() {
/* 74 */     int type = (this.fType == null) ? 0 : this.fType.hashCode();
/* 75 */     return super.hashCode() | type;
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 80 */     return String.valueOf(this.fType) + " - " + super.toString();
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.text-3.13.0.jar!\org\eclipse\jface\text\TypedPosition.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */