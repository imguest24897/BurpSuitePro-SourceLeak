/*    */ package org.eclipse.jface.text.templates;
/*    */ 
/*    */ import org.eclipse.core.runtime.Assert;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class TemplateBuffer
/*    */ {
/*    */   private String fString;
/*    */   private TemplateVariable[] fVariables;
/*    */   
/*    */   public TemplateBuffer(String string, TemplateVariable[] variables) {
/* 40 */     setContent(string, variables);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public final void setContent(String string, TemplateVariable[] variables) {
/* 50 */     Assert.isNotNull(string);
/* 51 */     Assert.isNotNull(variables);
/*    */ 
/*    */ 
/*    */     
/* 55 */     this.fString = string;
/* 56 */     this.fVariables = copy(variables);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   private static TemplateVariable[] copy(TemplateVariable[] array) {
/* 67 */     if (array != null) {
/* 68 */       TemplateVariable[] copy = new TemplateVariable[array.length];
/* 69 */       System.arraycopy(array, 0, copy, 0, array.length);
/* 70 */       return copy;
/*    */     } 
/* 72 */     return null;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public final String getString() {
/* 81 */     return this.fString;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public final TemplateVariable[] getVariables() {
/* 91 */     return this.fVariables;
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.text-3.13.0.jar!\org\eclipse\jface\text\templates\TemplateBuffer.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */