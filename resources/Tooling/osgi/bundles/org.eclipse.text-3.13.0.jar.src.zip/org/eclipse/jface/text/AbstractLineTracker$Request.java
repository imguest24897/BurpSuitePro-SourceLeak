/*    */ package org.eclipse.jface.text;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Request
/*    */ {
/*    */   public final int offset;
/*    */   public final int length;
/*    */   public final String text;
/*    */   
/*    */   public Request(int offset, int length, String text) {
/* 69 */     this.offset = offset;
/* 70 */     this.length = length;
/* 71 */     this.text = text;
/*    */   }
/*    */   
/*    */   public Request(String text) {
/* 75 */     this.offset = -1;
/* 76 */     this.length = -1;
/* 77 */     this.text = text;
/*    */   }
/*    */   
/*    */   public boolean isReplaceRequest() {
/* 81 */     return (this.offset > -1 && this.length > -1);
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.text-3.13.0.jar!\org\eclipse\jface\text\AbstractLineTracker$Request.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */