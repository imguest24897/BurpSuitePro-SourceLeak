/*     */ package org.eclipse.jface.text.link;
/*     */ 
/*     */ import java.util.Map;
/*     */ import org.eclipse.jface.text.DocumentEvent;
/*     */ import org.eclipse.jface.text.IDocument;
/*     */ import org.eclipse.jface.text.IDocumentExtension;
/*     */ import org.eclipse.jface.text.IDocumentListener;
/*     */ import org.eclipse.text.edits.TextEdit;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class DocumentListener
/*     */   implements IDocumentListener
/*     */ {
/*     */   private boolean fExit = false;
/*     */   
/*     */   public void documentAboutToBeChanged(DocumentEvent event) {
/* 185 */     if (LinkedModeModel.this.fParentEnvironment != null && LinkedModeModel.this.fParentEnvironment.isChanging()) {
/*     */       return;
/*     */     }
/* 188 */     for (LinkedPositionGroup group : LinkedModeModel.this.fGroups) {
/* 189 */       if (!group.isLegalEvent(event)) {
/* 190 */         this.fExit = true;
/*     */         return;
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void documentChanged(DocumentEvent event) {
/* 203 */     if (this.fExit) {
/* 204 */       LinkedModeModel.this.exit(8);
/*     */       return;
/*     */     } 
/* 207 */     this.fExit = false;
/*     */ 
/*     */     
/* 210 */     if (LinkedModeModel.this.fParentEnvironment != null && LinkedModeModel.this.fParentEnvironment.isChanging()) {
/*     */       return;
/*     */     }
/*     */     
/* 214 */     Map<IDocument, TextEdit> result = null;
/* 215 */     for (LinkedPositionGroup group : LinkedModeModel.this.fGroups) {
/* 216 */       Map<IDocument, TextEdit> map = group.handleEvent(event);
/* 217 */       if (result != null && map != null) {
/*     */         
/* 219 */         LinkedModeModel.this.exit(8);
/*     */         return;
/*     */       } 
/* 222 */       if (map != null) {
/* 223 */         result = map;
/*     */       }
/*     */     } 
/* 226 */     if (result != null)
/*     */     {
/* 228 */       for (Map.Entry<IDocument, TextEdit> entry : result.entrySet()) {
/* 229 */         IDocument doc = entry.getKey();
/* 230 */         TextEdit edit = entry.getValue();
/* 231 */         LinkedModeModel.Replace replace = new LinkedModeModel.Replace(LinkedModeModel.this, edit);
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 236 */         if (doc == event.getDocument()) {
/* 237 */           if (doc instanceof IDocumentExtension) {
/* 238 */             ((IDocumentExtension)doc).registerPostNotificationReplace(this, replace);
/*     */           }
/*     */           
/*     */           continue;
/*     */         } 
/* 243 */         replace.perform(doc, this);
/*     */       } 
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.text-3.13.0.jar!\org\eclipse\jface\text\link\LinkedModeModel$DocumentListener.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */