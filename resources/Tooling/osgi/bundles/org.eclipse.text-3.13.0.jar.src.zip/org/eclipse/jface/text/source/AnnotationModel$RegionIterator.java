/*     */ package org.eclipse.jface.text.source;
/*     */ 
/*     */ import java.util.Iterator;
/*     */ import java.util.NoSuchElementException;
/*     */ import org.eclipse.jface.text.Position;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class RegionIterator
/*     */   implements Iterator<Annotation>
/*     */ {
/*     */   private final Iterator<Annotation> fParentIterator;
/*     */   private final boolean fCanEndAfter;
/*     */   private final boolean fCanStartBefore;
/*     */   private final IAnnotationModel fModel;
/*     */   private Annotation fNext;
/*     */   private Position fRegion;
/*     */   
/*     */   public RegionIterator(Iterator<Annotation> parentIterator, IAnnotationModel model, int offset, int length, boolean canStartBefore, boolean canEndAfter) {
/*  83 */     this.fParentIterator = parentIterator;
/*  84 */     this.fModel = model;
/*  85 */     this.fRegion = new Position(offset, length);
/*  86 */     this.fCanEndAfter = canEndAfter;
/*  87 */     this.fCanStartBefore = canStartBefore;
/*  88 */     this.fNext = findNext();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean hasNext() {
/*  93 */     return (this.fNext != null);
/*     */   }
/*     */ 
/*     */   
/*     */   public Annotation next() {
/*  98 */     if (!hasNext()) {
/*  99 */       throw new NoSuchElementException();
/*     */     }
/* 101 */     Annotation result = this.fNext;
/* 102 */     this.fNext = findNext();
/* 103 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   public void remove() {
/* 108 */     throw new UnsupportedOperationException();
/*     */   }
/*     */   
/*     */   private Annotation findNext() {
/* 112 */     while (this.fParentIterator.hasNext()) {
/* 113 */       Annotation next = this.fParentIterator.next();
/* 114 */       Position position = this.fModel.getPosition(next);
/* 115 */       if (position != null) {
/* 116 */         int offset = position.getOffset();
/* 117 */         if (isWithinRegion(offset, position.getLength()))
/* 118 */           return next; 
/*     */       } 
/*     */     } 
/* 121 */     return null;
/*     */   }
/*     */   
/*     */   private boolean isWithinRegion(int start, int length) {
/* 125 */     if (this.fCanStartBefore && this.fCanEndAfter)
/* 126 */       return this.fRegion.overlapsWith(start, length); 
/* 127 */     if (this.fCanStartBefore)
/* 128 */       return this.fRegion.includes(start + length - ((length > 0) ? 1 : 0)); 
/* 129 */     if (this.fCanEndAfter) {
/* 130 */       return this.fRegion.includes(start);
/*     */     }
/* 132 */     return (this.fRegion.includes(start) && this.fRegion.includes(start + length - ((length > 0) ? 1 : 0)));
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.text-3.13.0.jar!\org\eclipse\jface\text\source\AnnotationModel$RegionIterator.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */