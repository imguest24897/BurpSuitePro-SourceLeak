/*     */ package org.eclipse.jface.text.source;
/*     */ 
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import org.eclipse.jface.text.Position;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class AnnotationsInterator
/*     */   implements Iterator<Annotation>
/*     */ {
/*     */   private Annotation fNext;
/*     */   private final Position[] fPositions;
/*     */   private int fIndex;
/*     */   private final Map<Position, Annotation> fMap;
/*     */   
/*     */   public AnnotationsInterator(Position[] positions, Map<Position, Annotation> map) {
/* 154 */     this.fPositions = positions;
/* 155 */     this.fIndex = 0;
/* 156 */     this.fMap = map;
/* 157 */     this.fNext = findNext();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean hasNext() {
/* 162 */     return (this.fNext != null);
/*     */   }
/*     */ 
/*     */   
/*     */   public Annotation next() {
/* 167 */     Annotation result = this.fNext;
/* 168 */     this.fNext = findNext();
/* 169 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   public void remove() {
/* 174 */     throw new UnsupportedOperationException();
/*     */   }
/*     */   
/*     */   private Annotation findNext() {
/* 178 */     while (this.fIndex < this.fPositions.length) {
/* 179 */       Position position = this.fPositions[this.fIndex];
/* 180 */       this.fIndex++;
/* 181 */       if (this.fMap.containsKey(position)) {
/* 182 */         return this.fMap.get(position);
/*     */       }
/*     */     } 
/* 185 */     return null;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.text-3.13.0.jar!\org\eclipse\jface\text\source\AnnotationModel$AnnotationsInterator.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */