/*     */ package org.eclipse.jface.text.link;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.Stack;
/*     */ import org.eclipse.core.runtime.Assert;
/*     */ import org.eclipse.jface.text.IDocument;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class LinkedModeManager
/*     */ {
/*     */   private class Listener
/*     */     implements ILinkedModeListener
/*     */   {
/*     */     public void left(LinkedModeModel model, int flags) {
/*  45 */       LinkedModeManager.this.left(model, flags);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void suspend(LinkedModeModel model) {}
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void resume(LinkedModeModel model, int flags) {}
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*  61 */   private static Map<IDocument, LinkedModeManager> fgManagers = new HashMap<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean hasManager(IDocument document) {
/*  70 */     return (fgManagers.get(document) != null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean hasManager(IDocument[] documents) {
/*     */     byte b;
/*     */     int i;
/*     */     IDocument[] arrayOfIDocument;
/*  80 */     for (i = (arrayOfIDocument = documents).length, b = 0; b < i; ) { IDocument document = arrayOfIDocument[b];
/*  81 */       if (hasManager(document))
/*  82 */         return true;  b++; }
/*     */     
/*  84 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static LinkedModeManager getLinkedManager(IDocument[] documents, boolean force) {
/*  97 */     if (documents == null || documents.length == 0) {
/*  98 */       return null;
/*     */     }
/* 100 */     Set<LinkedModeManager> mgrs = new HashSet<>();
/* 101 */     LinkedModeManager mgr = null; byte b; int i; IDocument[] arrayOfIDocument;
/* 102 */     for (i = (arrayOfIDocument = documents).length, b = 0; b < i; ) { IDocument document = arrayOfIDocument[b];
/* 103 */       mgr = fgManagers.get(document);
/* 104 */       if (mgr != null)
/* 105 */         mgrs.add(mgr);  b++; }
/*     */     
/* 107 */     if (mgrs.size() > 1) {
/* 108 */       if (force) {
/* 109 */         for (LinkedModeManager m : mgrs) {
/* 110 */           m.closeAllEnvironments();
/*     */         }
/*     */       } else {
/* 113 */         return null;
/*     */       } 
/*     */     }
/* 116 */     if (mgrs.isEmpty()) {
/* 117 */       mgr = new LinkedModeManager();
/*     */     }
/* 119 */     for (i = (arrayOfIDocument = documents).length, b = 0; b < i; ) { IDocument document = arrayOfIDocument[b];
/* 120 */       fgManagers.put(document, mgr); b++; }
/*     */     
/* 122 */     return mgr;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void cancelManager(IDocument document) {
/* 131 */     LinkedModeManager mgr = fgManagers.get(document);
/* 132 */     if (mgr != null) {
/* 133 */       mgr.closeAllEnvironments();
/*     */     }
/*     */   }
/*     */   
/* 137 */   private Stack<LinkedModeModel> fEnvironments = new Stack<>();
/* 138 */   private Listener fListener = new Listener();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void left(LinkedModeModel model, int flags) {
/* 147 */     if (!this.fEnvironments.contains(model)) {
/*     */       return;
/*     */     }
/* 150 */     while (!this.fEnvironments.isEmpty()) {
/* 151 */       LinkedModeModel env = this.fEnvironments.pop();
/* 152 */       if (env == model)
/*     */         break; 
/* 154 */       env.exit(0);
/*     */     } 
/*     */     
/* 157 */     if (this.fEnvironments.isEmpty()) {
/* 158 */       removeManager();
/*     */     }
/*     */   }
/*     */   
/*     */   private void closeAllEnvironments() {
/* 163 */     while (!this.fEnvironments.isEmpty()) {
/* 164 */       LinkedModeModel env = this.fEnvironments.pop();
/* 165 */       env.exit(0);
/*     */     } 
/*     */     
/* 168 */     removeManager();
/*     */   }
/*     */   
/*     */   private void removeManager() {
/* 172 */     for (Iterator<LinkedModeManager> it = fgManagers.values().iterator(); it.hasNext();) {
/* 173 */       if (it.next() == this) {
/* 174 */         it.remove();
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean nestEnvironment(LinkedModeModel model, boolean force) {
/* 189 */     Assert.isNotNull(model);
/*     */     
/*     */     try {
/*     */       while (true) {
/* 193 */         if (this.fEnvironments.isEmpty()) {
/* 194 */           model.addLinkingListener(this.fListener);
/* 195 */           this.fEnvironments.push(model);
/* 196 */           return true;
/*     */         } 
/*     */         
/* 199 */         LinkedModeModel top = this.fEnvironments.peek();
/* 200 */         if (model.canNestInto(top)) {
/* 201 */           model.addLinkingListener(this.fListener);
/* 202 */           this.fEnvironments.push(model);
/* 203 */           return true;
/* 204 */         }  if (!force) {
/* 205 */           return false;
/*     */         }
/* 207 */         this.fEnvironments.pop();
/* 208 */         top.exit(0);
/*     */       }
/*     */     
/*     */     }
/*     */     finally {
/*     */       
/* 214 */       Assert.isTrue(!this.fEnvironments.isEmpty());
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LinkedModeModel getTopEnvironment() {
/* 225 */     if (this.fEnvironments.isEmpty())
/* 226 */       return null; 
/* 227 */     return this.fEnvironments.peek();
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.text-3.13.0.jar!\org\eclipse\jface\text\link\LinkedModeManager.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */