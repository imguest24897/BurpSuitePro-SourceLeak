/*     */ package org.eclipse.jface.text;
/*     */ 
/*     */ import java.util.Objects;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class MatchResult
/*     */   implements MultiStringMatcher.Match
/*     */ {
/*     */   private final String match;
/*     */   private final int offset;
/*     */   
/*     */   public MatchResult(String match, int offset) {
/* 151 */     this.match = match;
/* 152 */     this.offset = offset;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getText() {
/* 157 */     return this.match;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getOffset() {
/* 162 */     return this.offset;
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 167 */     return Objects.hashCode(this.match) * 31 + Integer.hashCode(this.offset);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object obj) {
/* 172 */     if (this == obj) {
/* 173 */       return true;
/*     */     }
/* 175 */     if (obj == null || getClass() != obj.getClass()) {
/* 176 */       return false;
/*     */     }
/* 178 */     MatchResult other = (MatchResult)obj;
/* 179 */     return (this.offset == other.offset && Objects.equals(this.match, other.match));
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 184 */     return String.valueOf('[') + this.match + ", " + this.offset + ']';
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.text-3.13.0.jar!\org\eclipse\jface\text\MultiStringMatcher$MatchResult.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */