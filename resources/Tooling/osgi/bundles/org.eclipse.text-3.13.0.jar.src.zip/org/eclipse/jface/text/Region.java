/*    */ package org.eclipse.jface.text;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Region
/*    */   implements IRegion
/*    */ {
/*    */   private int fOffset;
/*    */   private int fLength;
/*    */   
/*    */   public Region(int offset, int length) {
/* 34 */     this.fOffset = offset;
/* 35 */     this.fLength = length;
/*    */   }
/*    */ 
/*    */   
/*    */   public int getLength() {
/* 40 */     return this.fLength;
/*    */   }
/*    */ 
/*    */   
/*    */   public int getOffset() {
/* 45 */     return this.fOffset;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean equals(Object o) {
/* 50 */     if (o instanceof IRegion) {
/* 51 */       IRegion r = (IRegion)o;
/* 52 */       return (r.getOffset() == this.fOffset && r.getLength() == this.fLength);
/*    */     } 
/* 54 */     return false;
/*    */   }
/*    */ 
/*    */   
/*    */   public int hashCode() {
/* 59 */     return this.fOffset << 24 | this.fLength << 16;
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 64 */     return "offset: " + this.fOffset + ", length: " + this.fLength;
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.text-3.13.0.jar!\org\eclipse\jface\text\Region.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */