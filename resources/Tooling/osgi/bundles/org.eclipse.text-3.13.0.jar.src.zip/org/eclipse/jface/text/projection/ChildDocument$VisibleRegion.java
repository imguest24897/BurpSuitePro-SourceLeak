/*    */ package org.eclipse.jface.text.projection;
/*    */ 
/*    */ import org.eclipse.jface.text.Position;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class VisibleRegion
/*    */   extends Position
/*    */ {
/*    */   public VisibleRegion(int regionOffset, int regionLength) {
/* 47 */     super(regionOffset, regionLength);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean overlapsWith(int regionOffset, int regionLength) {
/* 58 */     boolean appending = (regionOffset == this.offset + this.length && regionLength == 0);
/* 59 */     return !(!appending && !super.overlapsWith(regionOffset, regionLength));
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.text-3.13.0.jar!\org\eclipse\jface\text\projection\ChildDocument$VisibleRegion.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */