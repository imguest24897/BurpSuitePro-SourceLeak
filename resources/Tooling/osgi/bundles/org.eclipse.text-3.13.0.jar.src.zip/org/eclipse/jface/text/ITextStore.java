package org.eclipse.jface.text;

public interface ITextStore {
  char get(int paramInt);
  
  String get(int paramInt1, int paramInt2);
  
  int getLength();
  
  void replace(int paramInt1, int paramInt2, String paramString);
  
  void set(String paramString);
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.text-3.13.0.jar!\org\eclipse\jface\text\ITextStore.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */