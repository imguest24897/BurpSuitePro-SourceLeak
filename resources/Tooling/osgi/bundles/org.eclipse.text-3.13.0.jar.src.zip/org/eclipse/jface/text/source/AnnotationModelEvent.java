/*     */ package org.eclipse.jface.text.source;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import org.eclipse.jface.text.Position;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AnnotationModelEvent
/*     */ {
/*     */   private IAnnotationModel fAnnotationModel;
/*  45 */   private Set<Annotation> fAddedAnnotations = new HashSet<>();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  50 */   private Map<Annotation, Position> fRemovedAnnotations = new HashMap<>();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  55 */   private Set<Annotation> fChangedAnnotations = new HashSet<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean fIsWorldChange;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Object fModificationStamp;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AnnotationModelEvent(IAnnotationModel model) {
/*  73 */     this(model, true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AnnotationModelEvent(IAnnotationModel model, boolean isWorldChange) {
/*  84 */     this.fAnnotationModel = model;
/*  85 */     this.fIsWorldChange = isWorldChange;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IAnnotationModel getAnnotationModel() {
/*  94 */     return this.fAnnotationModel;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void annotationAdded(Annotation annotation) {
/* 106 */     this.fAddedAnnotations.add(annotation);
/* 107 */     this.fIsWorldChange = false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Annotation[] getAddedAnnotations() {
/* 117 */     int size = this.fAddedAnnotations.size();
/* 118 */     Annotation[] added = new Annotation[size];
/* 119 */     this.fAddedAnnotations.toArray(added);
/* 120 */     return added;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void annotationRemoved(Annotation annotation) {
/* 132 */     annotationRemoved(annotation, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void annotationRemoved(Annotation annotation, Position position) {
/* 145 */     this.fRemovedAnnotations.put(annotation, position);
/* 146 */     this.fIsWorldChange = false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Annotation[] getRemovedAnnotations() {
/* 156 */     int size = this.fRemovedAnnotations.size();
/* 157 */     Annotation[] removed = new Annotation[size];
/* 158 */     this.fRemovedAnnotations.keySet().toArray((Object[])removed);
/* 159 */     return removed;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Position getPositionOfRemovedAnnotation(Annotation annotation) {
/* 171 */     return this.fRemovedAnnotations.get(annotation);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void annotationChanged(Annotation annotation) {
/* 183 */     this.fChangedAnnotations.add(annotation);
/* 184 */     this.fIsWorldChange = false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Annotation[] getChangedAnnotations() {
/* 194 */     int size = this.fChangedAnnotations.size();
/* 195 */     Annotation[] changed = new Annotation[size];
/* 196 */     this.fChangedAnnotations.toArray(changed);
/* 197 */     return changed;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isEmpty() {
/* 210 */     return (!this.fIsWorldChange && this.fAddedAnnotations.isEmpty() && this.fRemovedAnnotations.isEmpty() && this.fChangedAnnotations.isEmpty());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isWorldChange() {
/* 223 */     return this.fIsWorldChange;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void markWorldChange(boolean isWorldChange) {
/* 233 */     this.fIsWorldChange = isWorldChange;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isValid() {
/* 243 */     if (this.fModificationStamp != null && this.fAnnotationModel instanceof IAnnotationModelExtension) {
/* 244 */       IAnnotationModelExtension extension = (IAnnotationModelExtension)this.fAnnotationModel;
/* 245 */       return (this.fModificationStamp == extension.getModificationStamp());
/*     */     } 
/* 247 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void markSealed() {
/* 257 */     if (this.fAnnotationModel instanceof IAnnotationModelExtension) {
/* 258 */       IAnnotationModelExtension extension = (IAnnotationModelExtension)this.fAnnotationModel;
/* 259 */       this.fModificationStamp = extension.getModificationStamp();
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.text-3.13.0.jar!\org\eclipse\jface\text\source\AnnotationModelEvent.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */