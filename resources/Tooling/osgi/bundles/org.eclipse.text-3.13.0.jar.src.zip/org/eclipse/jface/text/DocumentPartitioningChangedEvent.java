/*     */ package org.eclipse.jface.text;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import org.eclipse.core.runtime.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DocumentPartitioningChangedEvent
/*     */ {
/*     */   private final IDocument fDocument;
/*  33 */   private final Map<String, Region> fMap = new HashMap<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DocumentPartitioningChangedEvent(IDocument document) {
/*  43 */     this.fDocument = document;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IDocument getDocument() {
/*  52 */     return this.fDocument;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IRegion getChangedRegion(String partitioning) {
/*  63 */     return this.fMap.get(partitioning);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String[] getChangedPartitionings() {
/*  72 */     String[] partitionings = new String[this.fMap.size()];
/*  73 */     this.fMap.keySet().toArray((Object[])partitionings);
/*  74 */     return partitionings;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setPartitionChange(String partitioning, int offset, int length) {
/*  85 */     Assert.isNotNull(partitioning);
/*  86 */     this.fMap.put(partitioning, new Region(offset, length));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isEmpty() {
/*  96 */     return this.fMap.isEmpty();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IRegion getCoverage() {
/* 106 */     if (this.fMap.isEmpty()) {
/* 107 */       return new Region(0, 0);
/*     */     }
/* 109 */     int offset = -1;
/* 110 */     int endOffset = -1;
/* 111 */     Iterator<Region> e = this.fMap.values().iterator();
/* 112 */     while (e.hasNext()) {
/* 113 */       IRegion r = e.next();
/*     */       
/* 115 */       if (offset < 0 || r.getOffset() < offset) {
/* 116 */         offset = r.getOffset();
/*     */       }
/* 118 */       int end = r.getOffset() + r.getLength();
/* 119 */       if (end > endOffset) {
/* 120 */         endOffset = end;
/*     */       }
/*     */     } 
/* 123 */     return new Region(offset, endOffset - offset);
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.text-3.13.0.jar!\org\eclipse\jface\text\DocumentPartitioningChangedEvent.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */