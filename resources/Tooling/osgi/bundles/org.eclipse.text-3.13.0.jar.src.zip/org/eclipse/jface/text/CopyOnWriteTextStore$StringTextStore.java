/*    */ package org.eclipse.jface.text;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class StringTextStore
/*    */   implements ITextStore
/*    */ {
/*    */   private static final int SMALL_TEXT_LIMIT = 1048576;
/*    */   private final String fText;
/*    */   private final int fCopyLimit;
/*    */   
/*    */   private StringTextStore() {
/* 55 */     this("");
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   private StringTextStore(String text) {
/* 65 */     this.fText = (text != null) ? text : "";
/* 66 */     this.fCopyLimit = (this.fText.length() > 1048576) ? (this.fText.length() / 2) : 0;
/*    */   }
/*    */ 
/*    */   
/*    */   public char get(int offset) {
/* 71 */     return this.fText.charAt(offset);
/*    */   }
/*    */ 
/*    */   
/*    */   public String get(int offset, int length) {
/* 76 */     if (length < this.fCopyLimit)
/*    */     {
/* 78 */       return new String(this.fText.substring(offset, offset + length).toCharArray());
/*    */     }
/* 80 */     return this.fText.substring(offset, offset + length);
/*    */   }
/*    */ 
/*    */   
/*    */   public int getLength() {
/* 85 */     return this.fText.length();
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void replace(int offset, int length, String text) {
/* 91 */     throw new UnsupportedOperationException();
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void set(String text) {
/* 97 */     throw new UnsupportedOperationException();
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.text-3.13.0.jar!\org\eclipse\jface\text\CopyOnWriteTextStore$StringTextStore.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */