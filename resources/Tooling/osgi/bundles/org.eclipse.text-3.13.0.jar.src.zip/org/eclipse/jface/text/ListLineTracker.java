/*     */ package org.eclipse.jface.text;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ abstract class ListLineTracker
/*     */   implements ILineTracker
/*     */ {
/*  40 */   private final List<Line> fLines = new ArrayList<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int fTextLength;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int findLine(int offset) {
/*  58 */     if (this.fLines.isEmpty()) {
/*  59 */       return -1;
/*     */     }
/*  61 */     int left = 0;
/*  62 */     int right = this.fLines.size() - 1;
/*  63 */     int mid = 0;
/*  64 */     Line line = null;
/*     */     
/*  66 */     while (left < right) {
/*     */       
/*  68 */       mid = (left + right) / 2;
/*     */       
/*  70 */       line = this.fLines.get(mid);
/*  71 */       if (offset < line.offset) {
/*  72 */         if (left == mid) {
/*  73 */           right = left; continue;
/*     */         } 
/*  75 */         right = mid - 1; continue;
/*  76 */       }  if (offset > line.offset) {
/*  77 */         if (right == mid) {
/*  78 */           left = right; continue;
/*     */         } 
/*  80 */         left = mid + 1; continue;
/*  81 */       }  if (offset == line.offset) {
/*  82 */         left = right = mid;
/*     */       }
/*     */     } 
/*     */     
/*  86 */     line = this.fLines.get(left);
/*  87 */     if (line.offset > offset)
/*  88 */       left--; 
/*  89 */     return left;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int getNumberOfLines(int startLine, int offset, int length) throws BadLocationException {
/* 103 */     if (length == 0) {
/* 104 */       return 1;
/*     */     }
/* 106 */     int target = offset + length;
/*     */     
/* 108 */     Line l = this.fLines.get(startLine);
/*     */     
/* 110 */     if (l.delimiter == null) {
/* 111 */       return 1;
/*     */     }
/* 113 */     if (l.offset + l.length > target) {
/* 114 */       return 1;
/*     */     }
/* 116 */     if (l.offset + l.length == target) {
/* 117 */       return 2;
/*     */     }
/* 119 */     return getLineNumberOfOffset(target) - startLine + 1;
/*     */   }
/*     */ 
/*     */   
/*     */   public final int getLineLength(int line) throws BadLocationException {
/* 124 */     int lines = this.fLines.size();
/*     */     
/* 126 */     if (line < 0 || line > lines) {
/* 127 */       throw new BadLocationException();
/*     */     }
/* 129 */     if (lines == 0 || lines == line) {
/* 130 */       return 0;
/*     */     }
/* 132 */     Line l = this.fLines.get(line);
/* 133 */     return l.length;
/*     */   }
/*     */ 
/*     */   
/*     */   public final int getLineNumberOfOffset(int position) throws BadLocationException {
/* 138 */     if (position < 0)
/* 139 */       throw new BadLocationException("Negative offset : " + position); 
/* 140 */     if (position > this.fTextLength) {
/* 141 */       throw new BadLocationException("Offset > length: " + position + " > " + this.fTextLength);
/*     */     }
/*     */     
/* 144 */     if (position == this.fTextLength) {
/*     */       
/* 146 */       int lastLine = this.fLines.size() - 1;
/* 147 */       if (lastLine < 0) {
/* 148 */         return 0;
/*     */       }
/* 150 */       Line l = this.fLines.get(lastLine);
/* 151 */       return (l.delimiter != null) ? (lastLine + 1) : lastLine;
/*     */     } 
/*     */     
/* 154 */     return findLine(position);
/*     */   }
/*     */ 
/*     */   
/*     */   public final IRegion getLineInformationOfOffset(int position) throws BadLocationException {
/* 159 */     if (position > this.fTextLength) {
/* 160 */       throw new BadLocationException("Offset > length: " + position + " > " + this.fTextLength);
/*     */     }
/* 162 */     if (position == this.fTextLength) {
/* 163 */       int size = this.fLines.size();
/* 164 */       if (size == 0)
/* 165 */         return new Region(0, 0); 
/* 166 */       Line l = this.fLines.get(size - 1);
/* 167 */       return (l.delimiter != null) ? new Line(this.fTextLength, 0) : new Line(this.fTextLength - l.length, l.length);
/*     */     } 
/*     */     
/* 170 */     return getLineInformation(findLine(position));
/*     */   }
/*     */ 
/*     */   
/*     */   public final IRegion getLineInformation(int line) throws BadLocationException {
/* 175 */     int lines = this.fLines.size();
/*     */     
/* 177 */     if (line < 0 || line > lines) {
/* 178 */       throw new BadLocationException();
/*     */     }
/* 180 */     if (lines == 0) {
/* 181 */       return new Line(0, 0);
/*     */     }
/* 183 */     if (line == lines) {
/* 184 */       Line line1 = this.fLines.get(line - 1);
/* 185 */       return new Line(line1.offset + line1.length, 0);
/*     */     } 
/*     */     
/* 188 */     Line l = this.fLines.get(line);
/* 189 */     return (l.delimiter != null) ? new Line(l.offset, l.length - l.delimiter.length()) : l;
/*     */   }
/*     */ 
/*     */   
/*     */   public final int getLineOffset(int line) throws BadLocationException {
/* 194 */     int lines = this.fLines.size();
/*     */     
/* 196 */     if (line < 0 || line > lines) {
/* 197 */       throw new BadLocationException();
/*     */     }
/* 199 */     if (lines == 0) {
/* 200 */       return 0;
/*     */     }
/* 202 */     if (line == lines) {
/* 203 */       Line line1 = this.fLines.get(line - 1);
/* 204 */       if (line1.delimiter != null)
/* 205 */         return line1.offset + line1.length; 
/* 206 */       throw new BadLocationException();
/*     */     } 
/*     */     
/* 209 */     Line l = this.fLines.get(line);
/* 210 */     return l.offset;
/*     */   }
/*     */ 
/*     */   
/*     */   public final int getNumberOfLines() {
/* 215 */     int lines = this.fLines.size();
/*     */     
/* 217 */     if (lines == 0) {
/* 218 */       return 1;
/*     */     }
/* 220 */     Line l = this.fLines.get(lines - 1);
/* 221 */     return (l.delimiter != null) ? (lines + 1) : lines;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public final int getNumberOfLines(int position, int length) throws BadLocationException {
/* 227 */     if (position < 0 || position + length > this.fTextLength) {
/* 228 */       throw new BadLocationException();
/*     */     }
/* 230 */     if (length == 0) {
/* 231 */       return 1;
/*     */     }
/* 233 */     return getNumberOfLines(getLineNumberOfOffset(position), position, length);
/*     */   }
/*     */ 
/*     */   
/*     */   public final int computeNumberOfLines(String text) {
/* 238 */     int count = 0;
/* 239 */     int start = 0;
/* 240 */     AbstractLineTracker.DelimiterInfo delimiterInfo = nextDelimiterInfo(text, start);
/* 241 */     while (delimiterInfo != null && delimiterInfo.delimiterIndex > -1) {
/* 242 */       count++;
/* 243 */       start = delimiterInfo.delimiterIndex + delimiterInfo.delimiterLength;
/* 244 */       delimiterInfo = nextDelimiterInfo(text, start);
/*     */     } 
/* 246 */     return count;
/*     */   }
/*     */ 
/*     */   
/*     */   public final String getLineDelimiter(int line) throws BadLocationException {
/* 251 */     int lines = this.fLines.size();
/*     */     
/* 253 */     if (line < 0 || line > lines) {
/* 254 */       throw new BadLocationException();
/*     */     }
/* 256 */     if (lines == 0) {
/* 257 */       return null;
/*     */     }
/* 259 */     if (line == lines) {
/* 260 */       return null;
/*     */     }
/* 262 */     Line l = this.fLines.get(line);
/* 263 */     return l.delimiter;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected abstract AbstractLineTracker.DelimiterInfo nextDelimiterInfo(String paramString, int paramInt);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int createLines(String text, int insertPosition, int offset) {
/* 288 */     int count = 0;
/* 289 */     int start = 0;
/* 290 */     AbstractLineTracker.DelimiterInfo delimiterInfo = nextDelimiterInfo(text, 0);
/*     */     
/* 292 */     while (delimiterInfo != null && delimiterInfo.delimiterIndex > -1) {
/*     */       
/* 294 */       int index = delimiterInfo.delimiterIndex + delimiterInfo.delimiterLength - 1;
/*     */       
/* 296 */       if (insertPosition + count >= this.fLines.size()) {
/* 297 */         this.fLines.add(new Line(offset + start, offset + index, delimiterInfo.delimiter));
/*     */       } else {
/* 299 */         this.fLines.add(insertPosition + count, new Line(offset + start, offset + index, delimiterInfo.delimiter));
/*     */       } 
/* 301 */       count++;
/* 302 */       start = index + 1;
/* 303 */       delimiterInfo = nextDelimiterInfo(text, start);
/*     */     } 
/*     */     
/* 306 */     if (start < text.length()) {
/* 307 */       if (insertPosition + count < this.fLines.size()) {
/*     */         
/* 309 */         Line l = this.fLines.get(insertPosition + count);
/* 310 */         int delta = text.length() - start;
/* 311 */         l.offset -= delta;
/* 312 */         l.length += delta;
/*     */       } else {
/* 314 */         this.fLines.add(new Line(offset + start, offset + text.length() - 1, null));
/* 315 */         count++;
/*     */       } 
/*     */     }
/*     */     
/* 319 */     return count;
/*     */   }
/*     */ 
/*     */   
/*     */   public final void replace(int position, int length, String text) throws BadLocationException {
/* 324 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   
/*     */   public final void set(String text) {
/* 329 */     this.fLines.clear();
/* 330 */     if (text != null) {
/* 331 */       this.fTextLength = text.length();
/* 332 */       createLines(text, 0, 0);
/*     */     } else {
/* 334 */       this.fTextLength = 0;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final List<Line> getLines() {
/* 345 */     return this.fLines;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.text-3.13.0.jar!\org\eclipse\jface\text\ListLineTracker.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */