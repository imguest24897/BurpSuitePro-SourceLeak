/*    */ package org.eclipse.jface.text;
/*    */ 
/*    */ import org.eclipse.core.runtime.Assert;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DocumentRewriteSessionEvent
/*    */ {
/* 29 */   public static final Object SESSION_START = new Object();
/* 30 */   public static final Object SESSION_STOP = new Object();
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public IDocument fDocument;
/*    */ 
/*    */ 
/*    */   
/*    */   public DocumentRewriteSession fSession;
/*    */ 
/*    */ 
/*    */   
/*    */   public Object fChangeType;
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public DocumentRewriteSessionEvent(IDocument doc, DocumentRewriteSession session, Object changeType) {
/* 49 */     Assert.isNotNull(doc);
/* 50 */     Assert.isNotNull(session);
/*    */     
/* 52 */     this.fDocument = doc;
/* 53 */     this.fSession = session;
/* 54 */     this.fChangeType = changeType;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public IDocument getDocument() {
/* 63 */     return this.fDocument;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Object getChangeType() {
/* 74 */     return this.fChangeType;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public DocumentRewriteSession getSession() {
/* 83 */     return this.fSession;
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.text-3.13.0.jar!\org\eclipse\jface\text\DocumentRewriteSessionEvent.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */