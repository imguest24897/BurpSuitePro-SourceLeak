/*     */ package org.eclipse.jface.text;
/*     */ 
/*     */ import java.util.LinkedList;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Deprecated
/*     */ public class SequentialRewriteTextStore
/*     */   implements ITextStore
/*     */ {
/*     */   private LinkedList<Replace> fReplaceList;
/*     */   private ITextStore fSource;
/*     */   private static final boolean ASSERT_SEQUENTIALITY = false;
/*     */   
/*     */   private static class Replace
/*     */   {
/*     */     public int newOffset;
/*     */     public final int offset;
/*     */     public final int length;
/*     */     public final String text;
/*     */     
/*     */     public Replace(int offset, int newOffset, int length, String text) {
/*  42 */       this.newOffset = newOffset;
/*  43 */       this.offset = offset;
/*  44 */       this.length = length;
/*  45 */       this.text = text;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SequentialRewriteTextStore(ITextStore source) {
/*  63 */     this.fReplaceList = new LinkedList<>();
/*  64 */     this.fSource = source;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ITextStore getSourceStore() {
/*  73 */     commit();
/*  74 */     return this.fSource;
/*     */   }
/*     */ 
/*     */   
/*     */   public void replace(int offset, int length, String text) {
/*  79 */     if (text == null) {
/*  80 */       text = "";
/*     */     }
/*  82 */     if (this.fReplaceList.isEmpty()) {
/*  83 */       this.fReplaceList.add(new Replace(offset, offset, length, text));
/*     */     } else {
/*     */       
/*  86 */       Replace firstReplace = this.fReplaceList.getFirst();
/*  87 */       Replace lastReplace = this.fReplaceList.getLast();
/*     */ 
/*     */       
/*  90 */       if (offset + length <= firstReplace.newOffset) {
/*  91 */         int delta = text.length() - length;
/*  92 */         if (delta != 0) {
/*  93 */           for (Replace replace : this.fReplaceList) {
/*  94 */             replace.newOffset += delta;
/*     */           }
/*     */         }
/*     */         
/*  98 */         this.fReplaceList.addFirst(new Replace(offset, offset, length, text));
/*     */       
/*     */       }
/* 101 */       else if (offset >= lastReplace.newOffset + lastReplace.text.length()) {
/* 102 */         int delta = getDelta(lastReplace);
/* 103 */         this.fReplaceList.add(new Replace(offset - delta, offset, length, text));
/*     */       
/*     */       }
/*     */       else {
/*     */ 
/*     */         
/* 109 */         commit();
/* 110 */         this.fSource.replace(offset, length, text);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void set(String text) {
/* 117 */     this.fSource.set(text);
/* 118 */     this.fReplaceList.clear();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String get(int offset, int length) {
/* 124 */     if (this.fReplaceList.isEmpty()) {
/* 125 */       return this.fSource.get(offset, length);
/*     */     }
/*     */     
/* 128 */     Replace firstReplace = this.fReplaceList.getFirst();
/* 129 */     Replace lastReplace = this.fReplaceList.getLast();
/*     */ 
/*     */     
/* 132 */     if (offset + length <= firstReplace.newOffset) {
/* 133 */       return this.fSource.get(offset, length);
/*     */     }
/*     */     
/* 136 */     if (offset >= lastReplace.newOffset + lastReplace.text.length()) {
/* 137 */       int i = getDelta(lastReplace);
/* 138 */       return this.fSource.get(offset - i, length);
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 145 */     int delta = 0;
/* 146 */     for (Replace replace : this.fReplaceList) {
/* 147 */       if (offset + length < replace.newOffset) {
/* 148 */         return this.fSource.get(offset - delta, length);
/*     */       }
/* 150 */       if (offset >= replace.newOffset && offset + length <= replace.newOffset + replace.text.length()) {
/* 151 */         return replace.text.substring(offset - replace.newOffset, offset - replace.newOffset + length);
/*     */       }
/* 153 */       if (offset >= replace.newOffset + replace.text.length()) {
/* 154 */         delta = getDelta(replace);
/*     */         
/*     */         continue;
/*     */       } 
/* 158 */       commit();
/* 159 */       return this.fSource.get(offset, length);
/*     */     } 
/*     */ 
/*     */     
/* 163 */     return this.fSource.get(offset - delta, length);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final int getDelta(Replace replace) {
/* 176 */     return replace.newOffset - replace.offset + replace.text.length() - replace.length;
/*     */   }
/*     */ 
/*     */   
/*     */   public char get(int offset) {
/* 181 */     if (this.fReplaceList.isEmpty()) {
/* 182 */       return this.fSource.get(offset);
/*     */     }
/* 184 */     Replace firstReplace = this.fReplaceList.getFirst();
/* 185 */     Replace lastReplace = this.fReplaceList.getLast();
/*     */ 
/*     */     
/* 188 */     if (offset < firstReplace.newOffset) {
/* 189 */       return this.fSource.get(offset);
/*     */     }
/*     */     
/* 192 */     if (offset >= lastReplace.newOffset + lastReplace.text.length()) {
/* 193 */       int i = getDelta(lastReplace);
/* 194 */       return this.fSource.get(offset - i);
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 201 */     int delta = 0;
/* 202 */     for (Replace replace : this.fReplaceList) {
/* 203 */       if (offset < replace.newOffset) {
/* 204 */         return this.fSource.get(offset - delta);
/*     */       }
/* 206 */       if (offset < replace.newOffset + replace.text.length()) {
/* 207 */         return replace.text.charAt(offset - replace.newOffset);
/*     */       }
/* 209 */       delta = getDelta(replace);
/*     */     } 
/*     */     
/* 212 */     return this.fSource.get(offset - delta);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int getLength() {
/* 218 */     if (this.fReplaceList.isEmpty()) {
/* 219 */       return this.fSource.getLength();
/*     */     }
/* 221 */     Replace lastReplace = this.fReplaceList.getLast();
/* 222 */     return this.fSource.getLength() + getDelta(lastReplace);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void dispose() {
/* 229 */     this.fReplaceList = null;
/* 230 */     this.fSource = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void commit() {
/* 238 */     if (this.fReplaceList.isEmpty()) {
/*     */       return;
/*     */     }
/* 241 */     StringBuilder buffer = new StringBuilder();
/*     */     
/* 243 */     int delta = 0;
/* 244 */     for (Replace replace : this.fReplaceList) {
/* 245 */       int i = buffer.length() - delta;
/* 246 */       buffer.append(this.fSource.get(i, replace.offset - i));
/* 247 */       buffer.append(replace.text);
/* 248 */       delta = getDelta(replace);
/*     */     } 
/*     */     
/* 251 */     int offset = buffer.length() - delta;
/* 252 */     buffer.append(this.fSource.get(offset, this.fSource.getLength() - offset));
/*     */     
/* 254 */     this.fSource.set(buffer.toString());
/* 255 */     this.fReplaceList.clear();
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.text-3.13.0.jar!\org\eclipse\jface\text\SequentialRewriteTextStore.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */