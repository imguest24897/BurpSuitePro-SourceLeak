/*      */ package org.eclipse.jface.text;
/*      */ 
/*      */ import java.util.Arrays;
/*      */ import java.util.LinkedList;
/*      */ import java.util.List;
/*      */ import java.util.ListIterator;
/*      */ import org.eclipse.core.runtime.Assert;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ abstract class TreeLineTracker
/*      */   implements ILineTracker
/*      */ {
/*      */   private static final boolean ASSERT = false;
/*      */   private static final String NO_DELIM = "";
/*      */   
/*      */   private static final class Node
/*      */   {
/*      */     int line;
/*      */     int offset;
/*      */     int length;
/*      */     String delimiter;
/*      */     Node parent;
/*      */     Node left;
/*      */     Node right;
/*      */     byte balance;
/*      */     
/*      */     Node(int length, String delimiter) {
/*   98 */       this.length = length;
/*   99 */       this.delimiter = delimiter;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final String toString() {
/*  127 */       switch (this.balance)
/*      */       { case 0:
/*  129 */           bal = "=";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  146 */           return "[" + this.offset + "+" + pureLength() + "+" + this.delimiter.length() + "|" + this.line + "|" + bal + "]";case 1: bal = "+"; return "[" + this.offset + "+" + pureLength() + "+" + this.delimiter.length() + "|" + this.line + "|" + bal + "]";case 2: bal = "++"; return "[" + this.offset + "+" + pureLength() + "+" + this.delimiter.length() + "|" + this.line + "|" + bal + "]";case -1: bal = "-"; return "[" + this.offset + "+" + pureLength() + "+" + this.delimiter.length() + "|" + this.line + "|" + bal + "]";case -2: bal = "--"; return "[" + this.offset + "+" + pureLength() + "+" + this.delimiter.length() + "|" + this.line + "|" + bal + "]"; }  String bal = Byte.toString(this.balance); return "[" + this.offset + "+" + pureLength() + "+" + this.delimiter.length() + "|" + this.line + "|" + bal + "]";
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     int pureLength() {
/*  155 */       return this.length - this.delimiter.length();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  162 */   private Node fRoot = new Node(0, "");
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected TreeLineTracker() {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   TreeLineTracker(ListLineTracker tracker) {
/*  176 */     List<Line> lines = tracker.getLines();
/*  177 */     int n = lines.size();
/*  178 */     if (n == 0) {
/*      */       return;
/*      */     }
/*  181 */     Line line = lines.get(0);
/*  182 */     String delim = line.delimiter;
/*  183 */     if (delim == null)
/*  184 */       delim = ""; 
/*  185 */     int length = line.length;
/*  186 */     this.fRoot = new Node(length, delim);
/*  187 */     Node node = this.fRoot;
/*      */     
/*  189 */     for (int i = 1; i < n; i++) {
/*  190 */       line = lines.get(i);
/*  191 */       delim = line.delimiter;
/*  192 */       if (delim == null)
/*  193 */         delim = ""; 
/*  194 */       length = line.length;
/*  195 */       node = insertAfter(node, length, delim);
/*      */     } 
/*      */     
/*  198 */     if (node.delimiter != "") {
/*  199 */       insertAfter(node, 0, "");
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private Node nodeByOffset(int offset) throws BadLocationException {
/*  228 */     int remaining = offset;
/*  229 */     Node node = this.fRoot;
/*      */     while (true) {
/*  231 */       if (node == null) {
/*  232 */         fail(offset);
/*      */       }
/*  234 */       if (remaining < node.offset) {
/*  235 */         node = node.left; continue;
/*      */       } 
/*  237 */       remaining -= node.offset;
/*  238 */       if (remaining < node.length || (
/*  239 */         remaining == node.length && node.right == null)) {
/*      */         break;
/*      */       }
/*  242 */       remaining -= node.length;
/*  243 */       node = node.right;
/*      */     } 
/*      */ 
/*      */     
/*  247 */     return node;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private int lineByOffset(int offset) throws BadLocationException {
/*  262 */     int remaining = offset;
/*  263 */     Node node = this.fRoot;
/*  264 */     int line = 0;
/*      */     
/*      */     while (true) {
/*  267 */       if (node == null) {
/*  268 */         fail(offset);
/*      */       }
/*  270 */       if (remaining < node.offset) {
/*  271 */         node = node.left; continue;
/*      */       } 
/*  273 */       remaining -= node.offset;
/*  274 */       line += node.line;
/*  275 */       if (remaining < node.length || (remaining == node.length && node.right == null)) {
/*  276 */         return line;
/*      */       }
/*  278 */       remaining -= node.length;
/*  279 */       line++;
/*  280 */       node = node.right;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private Node nodeByLine(int line) throws BadLocationException {
/*  297 */     int remaining = line;
/*  298 */     Node node = this.fRoot;
/*      */     
/*      */     while (true) {
/*  301 */       if (node == null) {
/*  302 */         fail(line);
/*      */       }
/*  304 */       if (remaining == node.line)
/*      */         break; 
/*  306 */       if (remaining < node.line) {
/*  307 */         node = node.left; continue;
/*      */       } 
/*  309 */       remaining -= node.line + 1;
/*  310 */       node = node.right;
/*      */     } 
/*      */ 
/*      */     
/*  314 */     return node;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private int offsetByLine(int line) throws BadLocationException {
/*  329 */     int remaining = line;
/*  330 */     int offset = 0;
/*  331 */     Node node = this.fRoot;
/*      */     
/*      */     while (true) {
/*  334 */       if (node == null) {
/*  335 */         fail(line);
/*      */       }
/*  337 */       if (remaining == node.line) {
/*  338 */         return offset + node.offset;
/*      */       }
/*  340 */       if (remaining < node.line) {
/*  341 */         node = node.left; continue;
/*      */       } 
/*  343 */       remaining -= node.line + 1;
/*  344 */       offset += node.offset + node.length;
/*  345 */       node = node.right;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void rotateLeft(Node node) {
/*  358 */     Node child = node.right;
/*      */     
/*  360 */     boolean leftChild = !(node.parent != null && node != node.parent.left);
/*      */ 
/*      */     
/*  363 */     setChild(node.parent, child, leftChild);
/*      */     
/*  365 */     setChild(node, child.left, false);
/*  366 */     setChild(child, node, true);
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  371 */     child.line += node.line + 1;
/*  372 */     child.offset += node.offset + node.length;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void rotateRight(Node node) {
/*  383 */     Node child = node.left;
/*      */     
/*  385 */     boolean leftChild = !(node.parent != null && node != node.parent.left);
/*      */     
/*  387 */     setChild(node.parent, child, leftChild);
/*      */     
/*  389 */     setChild(node, child.right, true);
/*  390 */     setChild(child, node, false);
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  395 */     node.line -= child.line + 1;
/*  396 */     node.offset -= child.offset + child.length;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void setChild(Node parent, Node child, boolean isLeftChild) {
/*  410 */     if (parent == null) {
/*  411 */       if (child == null) {
/*  412 */         this.fRoot = new Node(0, "");
/*      */       } else {
/*  414 */         this.fRoot = child;
/*      */       } 
/*  416 */     } else if (isLeftChild) {
/*  417 */       parent.left = child;
/*      */     } else {
/*  419 */       parent.right = child;
/*      */     } 
/*  421 */     if (child != null) {
/*  422 */       child.parent = parent;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void singleLeftRotation(Node node, Node parent) {
/*  433 */     rotateLeft(parent);
/*  434 */     node.balance = 0;
/*  435 */     parent.balance = 0;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void singleRightRotation(Node node, Node parent) {
/*  446 */     rotateRight(parent);
/*  447 */     node.balance = 0;
/*  448 */     parent.balance = 0;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void rightLeftRotation(Node node, Node parent) {
/*  459 */     Node child = node.left;
/*  460 */     rotateRight(node);
/*  461 */     rotateLeft(parent);
/*  462 */     if (child.balance == 1) {
/*  463 */       node.balance = 0;
/*  464 */       parent.balance = -1;
/*  465 */       child.balance = 0;
/*  466 */     } else if (child.balance == 0) {
/*  467 */       node.balance = 0;
/*  468 */       parent.balance = 0;
/*  469 */     } else if (child.balance == -1) {
/*  470 */       node.balance = 1;
/*  471 */       parent.balance = 0;
/*  472 */       child.balance = 0;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void leftRightRotation(Node node, Node parent) {
/*  484 */     Node child = node.right;
/*  485 */     rotateLeft(node);
/*  486 */     rotateRight(parent);
/*  487 */     if (child.balance == -1) {
/*  488 */       node.balance = 0;
/*  489 */       parent.balance = 1;
/*  490 */       child.balance = 0;
/*  491 */     } else if (child.balance == 0) {
/*  492 */       node.balance = 0;
/*  493 */       parent.balance = 0;
/*  494 */     } else if (child.balance == 1) {
/*  495 */       node.balance = -1;
/*  496 */       parent.balance = 0;
/*  497 */       child.balance = 0;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private Node insertAfter(Node node, int length, String delimiter) {
/*  515 */     Node added = new Node(length, delimiter);
/*      */     
/*  517 */     if (node.right == null) {
/*  518 */       setChild(node, added, false);
/*      */     } else {
/*  520 */       setChild(successorDown(node.right), added, true);
/*      */     } 
/*      */     
/*  523 */     updateParentChain(added, length, 1);
/*  524 */     updateParentBalanceAfterInsertion(added);
/*      */     
/*  526 */     return added;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void updateParentBalanceAfterInsertion(Node node) {
/*  536 */     Node parent = node.parent;
/*  537 */     while (parent != null) {
/*  538 */       if (node == parent.left) {
/*  539 */         parent.balance = (byte)(parent.balance - 1);
/*      */       } else {
/*  541 */         parent.balance = (byte)(parent.balance + 1);
/*      */       } 
/*  543 */       switch (parent.balance) {
/*      */         case -1:
/*      */         case 1:
/*  546 */           node = parent;
/*  547 */           parent = node.parent;
/*      */           continue;
/*      */         case -2:
/*  550 */           rebalanceAfterInsertionLeft(node);
/*      */           break;
/*      */         case 2:
/*  553 */           rebalanceAfterInsertionRight(node);
/*      */           break;
/*      */       } 
/*      */       return;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void rebalanceAfterInsertionRight(Node node) {
/*  571 */     Node parent = node.parent;
/*  572 */     if (node.balance == 1) {
/*  573 */       singleLeftRotation(node, parent);
/*  574 */     } else if (node.balance == -1) {
/*  575 */       rightLeftRotation(node, parent);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void rebalanceAfterInsertionLeft(Node node) {
/*  587 */     Node parent = node.parent;
/*  588 */     if (node.balance == -1) {
/*  589 */       singleRightRotation(node, parent);
/*  590 */     } else if (node.balance == 1) {
/*  591 */       leftRightRotation(node, parent);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void replace(int offset, int length, String text) throws BadLocationException {
/*      */     int firstNodeOffset;
/*      */     Node last;
/*  602 */     int remaining = offset;
/*  603 */     Node first = this.fRoot;
/*      */ 
/*      */     
/*      */     while (true) {
/*  607 */       if (first == null) {
/*  608 */         fail(offset);
/*      */       }
/*  610 */       if (remaining < first.offset) {
/*  611 */         first = first.left; continue;
/*      */       } 
/*  613 */       remaining -= first.offset;
/*  614 */       if (remaining < first.length || (
/*  615 */         remaining == first.length && first.right == null)) {
/*  616 */         firstNodeOffset = offset - remaining;
/*      */         break;
/*      */       } 
/*  619 */       remaining -= first.length;
/*  620 */       first = first.right;
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  627 */     if (offset + length < firstNodeOffset + first.length) {
/*  628 */       last = first;
/*      */     } else {
/*  630 */       last = nodeByOffset(offset + length);
/*      */     } 
/*      */     
/*  633 */     int firstLineDelta = firstNodeOffset + first.length - offset;
/*  634 */     if (first == last) {
/*  635 */       replaceInternal(first, text, length, firstLineDelta);
/*      */     } else {
/*  637 */       replaceFromTo(first, last, text, length, firstLineDelta);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void replaceInternal(Node node, String text, int length, int firstLineDelta) {
/*  654 */     AbstractLineTracker.DelimiterInfo info = (text == null) ? null : nextDelimiterInfo(text, 0);
/*      */     
/*  656 */     if (info == null || info.delimiter == null) {
/*      */       
/*  658 */       int added = (text == null) ? 0 : text.length();
/*  659 */       updateLength(node, added - length);
/*      */     }
/*      */     else {
/*      */       
/*  663 */       int remainder = firstLineDelta - length;
/*  664 */       String remDelim = node.delimiter;
/*      */ 
/*      */       
/*  667 */       int consumed = info.delimiterIndex + info.delimiterLength;
/*  668 */       int delta = consumed - firstLineDelta;
/*  669 */       updateLength(node, delta);
/*  670 */       node.delimiter = info.delimiter;
/*      */ 
/*      */       
/*  673 */       info = nextDelimiterInfo(text, consumed);
/*  674 */       while (info != null) {
/*  675 */         int lineLen = info.delimiterIndex - consumed + info.delimiterLength;
/*  676 */         node = insertAfter(node, lineLen, info.delimiter);
/*  677 */         consumed += lineLen;
/*  678 */         info = nextDelimiterInfo(text, consumed);
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/*  683 */       insertAfter(node, remainder + text.length() - consumed, remDelim);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void replaceFromTo(Node node, Node last, String text, int length, int firstLineDelta) {
/*  703 */     Node successor = successor(node);
/*  704 */     while (successor != last) {
/*  705 */       length -= successor.length;
/*  706 */       Node toDelete = successor;
/*  707 */       successor = successor(successor);
/*  708 */       updateLength(toDelete, -toDelete.length);
/*      */     } 
/*      */     
/*  711 */     AbstractLineTracker.DelimiterInfo info = (text == null) ? null : nextDelimiterInfo(text, 0);
/*      */     
/*  713 */     if (info == null || info.delimiter == null) {
/*  714 */       int added = (text == null) ? 0 : text.length();
/*      */ 
/*      */       
/*  717 */       join(node, last, added - length);
/*      */     
/*      */     }
/*      */     else {
/*      */       
/*  722 */       int consumed = info.delimiterIndex + info.delimiterLength;
/*  723 */       updateLength(node, consumed - firstLineDelta);
/*  724 */       node.delimiter = info.delimiter;
/*  725 */       length -= firstLineDelta;
/*      */ 
/*      */       
/*  728 */       info = nextDelimiterInfo(text, consumed);
/*  729 */       while (info != null) {
/*  730 */         int lineLen = info.delimiterIndex - consumed + info.delimiterLength;
/*  731 */         node = insertAfter(node, lineLen, info.delimiter);
/*  732 */         consumed += lineLen;
/*  733 */         info = nextDelimiterInfo(text, consumed);
/*      */       } 
/*      */ 
/*      */       
/*  737 */       updateLength(last, text.length() - consumed - length);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void join(Node one, Node two, int delta) {
/*  750 */     int oneLength = one.length;
/*  751 */     updateLength(one, -oneLength);
/*  752 */     updateLength(two, oneLength + delta);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void updateLength(Node node, int delta) {
/*      */     int lineDelta;
/*  767 */     node.length += delta;
/*      */ 
/*      */ 
/*      */     
/*  771 */     boolean delete = (node.length == 0 && node.delimiter != "");
/*  772 */     if (delete) {
/*  773 */       lineDelta = -1;
/*      */     } else {
/*  775 */       lineDelta = 0;
/*      */     } 
/*      */     
/*  778 */     if (delta != 0 || lineDelta != 0) {
/*  779 */       updateParentChain(node, delta, lineDelta);
/*      */     }
/*  781 */     if (delete) {
/*  782 */       delete(node);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void updateParentChain(Node node, int deltaLength, int deltaLines) {
/*  794 */     updateParentChain(node, null, deltaLength, deltaLines);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void updateParentChain(Node from, Node to, int deltaLength, int deltaLines) {
/*  807 */     Node parent = from.parent;
/*  808 */     while (parent != to) {
/*      */       
/*  810 */       if (from == parent.left) {
/*  811 */         parent.offset += deltaLength;
/*  812 */         parent.line += deltaLines;
/*      */       } 
/*  814 */       from = parent;
/*  815 */       parent = from.parent;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void delete(Node node) {
/*      */     Node toUpdate;
/*      */     boolean lostLeftChild;
/*  831 */     Node parent = node.parent;
/*      */ 
/*      */     
/*  834 */     boolean isLeftChild = !(parent != null && node != parent.left);
/*      */     
/*  836 */     if (node.left == null || node.right == null) {
/*      */ 
/*      */       
/*  839 */       Node replacement = (node.left == null) ? node.right : node.left;
/*  840 */       setChild(parent, replacement, isLeftChild);
/*  841 */       toUpdate = parent;
/*  842 */       lostLeftChild = isLeftChild;
/*      */     }
/*  844 */     else if (node.right.left == null) {
/*      */ 
/*      */       
/*  847 */       Node replacement = node.right;
/*  848 */       setChild(parent, replacement, isLeftChild);
/*  849 */       setChild(replacement, node.left, true);
/*  850 */       replacement.line = node.line;
/*  851 */       replacement.offset = node.offset;
/*  852 */       replacement.balance = node.balance;
/*  853 */       toUpdate = replacement;
/*  854 */       lostLeftChild = false;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     }
/*      */     else {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  865 */       Node successor = successor(node);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  878 */       toUpdate = successor.parent;
/*  879 */       lostLeftChild = true;
/*      */ 
/*      */       
/*  882 */       updateParentChain(successor, node, -successor.length, -1);
/*      */ 
/*      */       
/*  885 */       setChild(toUpdate, successor.right, true);
/*      */ 
/*      */       
/*  888 */       setChild(successor, node.right, false);
/*  889 */       setChild(successor, node.left, true);
/*      */ 
/*      */       
/*  892 */       setChild(parent, successor, isLeftChild);
/*      */ 
/*      */       
/*  895 */       successor.line = node.line;
/*  896 */       successor.offset = node.offset;
/*  897 */       successor.balance = node.balance;
/*      */     } 
/*      */     
/*  900 */     updateParentBalanceAfterDeletion(toUpdate, lostLeftChild);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void updateParentBalanceAfterDeletion(Node node, boolean wasLeftChild) {
/*  912 */     while (node != null) {
/*  913 */       if (wasLeftChild) {
/*  914 */         node.balance = (byte)(node.balance + 1);
/*      */       } else {
/*  916 */         node.balance = (byte)(node.balance - 1);
/*      */       } 
/*  918 */       Node parent = node.parent;
/*  919 */       if (parent != null) {
/*  920 */         wasLeftChild = (node == parent.left);
/*      */       }
/*  922 */       switch (node.balance) {
/*      */         case -1:
/*      */         case 1:
/*      */           return;
/*      */         case -2:
/*  927 */           if (rebalanceAfterDeletionRight(node.left))
/*      */             return; 
/*      */           break;
/*      */         case 2:
/*  931 */           if (rebalanceAfterDeletionLeft(node.right)) {
/*      */             return;
/*      */           }
/*      */           break;
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  941 */       node = parent;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean rebalanceAfterDeletionLeft(Node node) {
/*  953 */     Node parent = node.parent;
/*  954 */     if (node.balance == 1) {
/*  955 */       singleLeftRotation(node, parent);
/*  956 */       return false;
/*  957 */     }  if (node.balance == -1) {
/*  958 */       rightLeftRotation(node, parent);
/*  959 */       return false;
/*  960 */     }  if (node.balance == 0) {
/*  961 */       rotateLeft(parent);
/*  962 */       node.balance = -1;
/*  963 */       parent.balance = 1;
/*  964 */       return true;
/*      */     } 
/*      */     
/*  967 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean rebalanceAfterDeletionRight(Node node) {
/*  979 */     Node parent = node.parent;
/*  980 */     if (node.balance == -1) {
/*  981 */       singleRightRotation(node, parent);
/*  982 */       return false;
/*  983 */     }  if (node.balance == 1) {
/*  984 */       leftRightRotation(node, parent);
/*  985 */       return false;
/*  986 */     }  if (node.balance == 0) {
/*  987 */       rotateRight(parent);
/*  988 */       node.balance = 1;
/*  989 */       parent.balance = -1;
/*  990 */       return true;
/*      */     } 
/*      */     
/*  993 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private Node successor(Node node) {
/* 1004 */     if (node.right != null) {
/* 1005 */       return successorDown(node.right);
/*      */     }
/* 1007 */     return successorUp(node);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private Node successorUp(Node node) {
/* 1018 */     Node child = node;
/* 1019 */     Node parent = child.parent;
/* 1020 */     while (parent != null) {
/* 1021 */       if (child == parent.left)
/* 1022 */         return parent; 
/* 1023 */       child = parent;
/* 1024 */       parent = child.parent;
/*      */     } 
/*      */     
/* 1027 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private Node successorDown(Node node) {
/* 1037 */     Node child = node.left;
/* 1038 */     while (child != null) {
/* 1039 */       node = child;
/* 1040 */       child = node.left;
/*      */     } 
/* 1042 */     return node;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void fail(int offset) throws BadLocationException {
/* 1054 */     throw new BadLocationException();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected abstract AbstractLineTracker.DelimiterInfo nextDelimiterInfo(String paramString, int paramInt);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final String getLineDelimiter(int line) throws BadLocationException {
/* 1069 */     Node node = nodeByLine(line);
/* 1070 */     return (node.delimiter == "") ? null : node.delimiter;
/*      */   }
/*      */ 
/*      */   
/*      */   public final int computeNumberOfLines(String text) {
/* 1075 */     int count = 0;
/* 1076 */     int start = 0;
/* 1077 */     AbstractLineTracker.DelimiterInfo delimiterInfo = nextDelimiterInfo(text, start);
/* 1078 */     while (delimiterInfo != null && delimiterInfo.delimiterIndex > -1) {
/* 1079 */       count++;
/* 1080 */       start = delimiterInfo.delimiterIndex + delimiterInfo.delimiterLength;
/* 1081 */       delimiterInfo = nextDelimiterInfo(text, start);
/*      */     } 
/* 1083 */     return count;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public final int getNumberOfLines() {
/* 1089 */     Node node = this.fRoot;
/* 1090 */     int lines = 0;
/* 1091 */     while (node != null) {
/* 1092 */       lines += node.line + 1;
/* 1093 */       node = node.right;
/*      */     } 
/* 1095 */     return lines;
/*      */   }
/*      */ 
/*      */   
/*      */   public final int getNumberOfLines(int offset, int length) throws BadLocationException {
/* 1100 */     if (length == 0) {
/* 1101 */       return 1;
/*      */     }
/* 1103 */     int startLine = lineByOffset(offset);
/* 1104 */     int endLine = lineByOffset(offset + length);
/*      */     
/* 1106 */     return endLine - startLine + 1;
/*      */   }
/*      */ 
/*      */   
/*      */   public final int getLineOffset(int line) throws BadLocationException {
/* 1111 */     return offsetByLine(line);
/*      */   }
/*      */ 
/*      */   
/*      */   public final int getLineLength(int line) throws BadLocationException {
/* 1116 */     Node node = nodeByLine(line);
/* 1117 */     return node.length;
/*      */   }
/*      */ 
/*      */   
/*      */   public final int getLineNumberOfOffset(int offset) throws BadLocationException {
/* 1122 */     return lineByOffset(offset);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public final IRegion getLineInformationOfOffset(int offset) throws BadLocationException {
/* 1128 */     int lineOffset, remaining = offset;
/* 1129 */     Node node = this.fRoot;
/*      */ 
/*      */     
/*      */     while (true) {
/* 1133 */       if (node == null) {
/* 1134 */         fail(offset);
/*      */       }
/* 1136 */       if (remaining < node.offset) {
/* 1137 */         node = node.left; continue;
/*      */       } 
/* 1139 */       remaining -= node.offset;
/* 1140 */       if (remaining < node.length || (
/* 1141 */         remaining == node.length && node.right == null)) {
/* 1142 */         lineOffset = offset - remaining;
/*      */         break;
/*      */       } 
/* 1145 */       remaining -= node.length;
/* 1146 */       node = node.right;
/*      */     } 
/*      */ 
/*      */     
/* 1150 */     return new Region(lineOffset, node.pureLength());
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public final IRegion getLineInformation(int line) throws BadLocationException {
/*      */     try {
/* 1157 */       int remaining = line;
/* 1158 */       int offset = 0;
/* 1159 */       Node node = this.fRoot;
/*      */       
/*      */       while (true) {
/* 1162 */         if (node == null) {
/* 1163 */           fail(line);
/*      */         }
/* 1165 */         if (remaining == node.line) {
/* 1166 */           offset += node.offset;
/*      */           break;
/*      */         } 
/* 1169 */         if (remaining < node.line) {
/* 1170 */           node = node.left; continue;
/*      */         } 
/* 1172 */         remaining -= node.line + 1;
/* 1173 */         offset += node.offset + node.length;
/* 1174 */         node = node.right;
/*      */       } 
/*      */ 
/*      */       
/* 1178 */       return new Region(offset, node.pureLength());
/* 1179 */     } catch (BadLocationException x) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1185 */       if (line > 0 && line == getNumberOfLines()) {
/*      */ 
/*      */         
/* 1188 */         int remaining = --line;
/* 1189 */         int offset = 0;
/* 1190 */         Node node = this.fRoot;
/*      */         
/*      */         while (true) {
/* 1193 */           if (node == null) {
/* 1194 */             fail(line);
/*      */           }
/* 1196 */           if (remaining == node.line) {
/* 1197 */             offset += node.offset;
/*      */             break;
/*      */           } 
/* 1200 */           if (remaining < node.line) {
/* 1201 */             node = node.left; continue;
/*      */           } 
/* 1203 */           remaining -= node.line + 1;
/* 1204 */           offset += node.offset + node.length;
/* 1205 */           node = node.right;
/*      */         } 
/*      */         
/* 1208 */         Node last = node;
/*      */         
/* 1210 */         if (last.length > 0)
/* 1211 */           return new Region(offset + last.length, 0); 
/*      */       } 
/* 1213 */       throw x;
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public final void set(String text) {
/* 1219 */     this.fRoot = new Node(0, "");
/*      */     try {
/* 1221 */       replace(0, 0, text);
/* 1222 */     } catch (BadLocationException badLocationException) {
/* 1223 */       throw new InternalError();
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public String toString() {
/* 1229 */     int depth = computeDepth(this.fRoot);
/* 1230 */     int WIDTH = 30;
/* 1231 */     int leaves = (int)Math.pow(2.0D, (depth - 1));
/* 1232 */     int width = WIDTH * leaves;
/* 1233 */     String empty = ".";
/*      */     
/* 1235 */     List<Node> roots = new LinkedList<>();
/* 1236 */     roots.add(this.fRoot);
/* 1237 */     StringBuilder buf = new StringBuilder((width + 1) * depth);
/* 1238 */     int indents = leaves;
/* 1239 */     char[] space = new char[leaves * WIDTH / 2];
/* 1240 */     Arrays.fill(space, ' ');
/* 1241 */     for (int d = 0; d < depth; d++) {
/*      */       
/* 1243 */       indents /= 2;
/* 1244 */       int spaces = Math.max(0, indents * WIDTH - WIDTH / 2);
/*      */       
/* 1246 */       for (ListIterator<Node> it = roots.listIterator(); it.hasNext(); ) {
/*      */         String box;
/* 1248 */         buf.append(space, 0, spaces);
/*      */         
/* 1250 */         Node node = it.next();
/*      */ 
/*      */         
/* 1253 */         if (node == null) {
/* 1254 */           it.add(null);
/* 1255 */           box = empty;
/*      */         } else {
/* 1257 */           it.set(node.left);
/* 1258 */           it.add(node.right);
/* 1259 */           box = node.toString();
/*      */         } 
/*      */ 
/*      */         
/* 1263 */         int pad_left = (WIDTH - box.length() + 1) / 2;
/* 1264 */         int pad_right = WIDTH - box.length() - pad_left;
/* 1265 */         buf.append(space, 0, pad_left);
/* 1266 */         buf.append(box);
/* 1267 */         buf.append(space, 0, pad_right);
/*      */ 
/*      */         
/* 1270 */         buf.append(space, 0, spaces);
/*      */       } 
/*      */       
/* 1273 */       buf.append('\n');
/*      */     } 
/*      */     
/* 1276 */     return buf.toString();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private byte computeDepth(Node root) {
/* 1286 */     if (root == null) {
/* 1287 */       return 0;
/*      */     }
/* 1289 */     return (byte)(Math.max(computeDepth(root.left), computeDepth(root.right)) + 1);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void checkTree() {
/* 1296 */     checkTreeStructure(this.fRoot);
/*      */     
/*      */     try {
/* 1299 */       checkTreeOffsets(nodeByOffset(0), new int[2], null);
/* 1300 */     } catch (BadLocationException badLocationException) {
/* 1301 */       throw new AssertionError();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private byte checkTreeStructure(Node node) {
/* 1314 */     if (node == null) {
/* 1315 */       return 0;
/*      */     }
/* 1317 */     byte leftDepth = checkTreeStructure(node.left);
/* 1318 */     byte rightDepth = checkTreeStructure(node.right);
/* 1319 */     Assert.isTrue((node.balance == rightDepth - leftDepth));
/* 1320 */     Assert.isTrue(!(node.left != null && node.left.parent != node));
/* 1321 */     Assert.isTrue(!(node.right != null && node.right.parent != node));
/*      */     
/* 1323 */     return (byte)(Math.max(rightDepth, leftDepth) + 1);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private int[] checkTreeOffsets(Node node, int[] offLen, Node last) {
/* 1340 */     if (node == last) {
/* 1341 */       return offLen;
/*      */     }
/* 1343 */     Assert.isTrue((node.offset == offLen[0]));
/* 1344 */     Assert.isTrue((node.line == offLen[1]));
/*      */     
/* 1346 */     if (node.right != null) {
/* 1347 */       int[] result = checkTreeOffsets(successorDown(node.right), new int[2], node);
/* 1348 */       offLen[0] = offLen[0] + result[0];
/* 1349 */       offLen[1] = offLen[1] + result[1];
/*      */     } 
/*      */     
/* 1352 */     offLen[0] = offLen[0] + node.length;
/* 1353 */     offLen[1] = offLen[1] + 1;
/* 1354 */     return checkTreeOffsets(node.parent, offLen, last);
/*      */   }
/*      */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.text-3.13.0.jar!\org\eclipse\jface\text\TreeLineTracker.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */