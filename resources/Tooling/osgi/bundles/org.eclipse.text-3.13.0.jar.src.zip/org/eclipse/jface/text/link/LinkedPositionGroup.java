/*     */ package org.eclipse.jface.text.link;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.eclipse.core.runtime.Assert;
/*     */ import org.eclipse.jface.text.BadLocationException;
/*     */ import org.eclipse.jface.text.DocumentEvent;
/*     */ import org.eclipse.jface.text.IDocument;
/*     */ import org.eclipse.jface.text.IRegion;
/*     */ import org.eclipse.jface.text.Position;
/*     */ import org.eclipse.jface.text.Region;
/*     */ import org.eclipse.text.edits.MalformedTreeException;
/*     */ import org.eclipse.text.edits.MultiTextEdit;
/*     */ import org.eclipse.text.edits.ReplaceEdit;
/*     */ import org.eclipse.text.edits.TextEdit;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LinkedPositionGroup
/*     */ {
/*     */   public static final int NO_STOP = -1;
/*  69 */   private final List<LinkedPosition> fPositions = new LinkedList<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean fIsSealed = false;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean fHasCustomIteration = false;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private LinkedPosition fLastPosition;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private IRegion fLastRegion;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean fMustEnforceEqualContents = false;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addPosition(LinkedPosition position) throws BadLocationException {
/* 122 */     Assert.isNotNull(position);
/* 123 */     if (this.fIsSealed) {
/* 124 */       throw new IllegalStateException("cannot add positions after the group is added to an model");
/*     */     }
/* 126 */     if (!this.fPositions.contains(position)) {
/* 127 */       enforceDisjoint(position);
/* 128 */       checkContent(position);
/* 129 */       this.fPositions.add(position);
/* 130 */       this.fHasCustomIteration |= (position.getSequenceNumber() != -1) ? 1 : 0;
/*     */     } else {
/*     */       return;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void checkContent(LinkedPosition position) throws BadLocationException {
/* 143 */     if (!this.fPositions.isEmpty()) {
/* 144 */       LinkedPosition groupPosition = this.fPositions.get(0);
/* 145 */       String groupContent = groupPosition.getContent();
/* 146 */       String positionContent = position.getContent();
/* 147 */       if (!this.fMustEnforceEqualContents && !groupContent.equals(positionContent)) {
/* 148 */         this.fMustEnforceEqualContents = true;
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void enforceDisjoint(LinkedPosition position) throws BadLocationException {
/* 160 */     for (LinkedPosition p : this.fPositions) {
/* 161 */       if (p.overlapsWith(position)) {
/* 162 */         throw new BadLocationException();
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void enforceDisjoint(LinkedPositionGroup group) throws BadLocationException {
/* 173 */     Assert.isNotNull(group);
/* 174 */     for (LinkedPosition p : group.fPositions) {
/* 175 */       enforceDisjoint(p);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean isLegalEvent(DocumentEvent event) {
/* 188 */     this.fLastPosition = null;
/* 189 */     this.fLastRegion = null;
/*     */     
/* 191 */     for (LinkedPosition pos : this.fPositions) {
/* 192 */       if (overlapsOrTouches(pos, event)) {
/* 193 */         if (this.fLastPosition != null) {
/* 194 */           this.fLastPosition = null;
/* 195 */           this.fLastRegion = null;
/* 196 */           return false;
/*     */         } 
/*     */         
/* 199 */         this.fLastPosition = pos;
/* 200 */         this.fLastRegion = (IRegion)new Region(pos.getOffset(), pos.getLength());
/*     */       } 
/*     */     } 
/*     */     
/* 204 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean overlapsOrTouches(LinkedPosition position, DocumentEvent event) {
/* 218 */     return (position.getDocument().equals(event.getDocument()) && position.getOffset() <= event.getOffset() + event.getLength() && position.getOffset() + position.getLength() >= event.getOffset());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Map<IDocument, TextEdit> handleEvent(DocumentEvent event) {
/* 232 */     if (this.fLastPosition != null) {
/*     */       int length;
/* 234 */       Map<IDocument, List<ReplaceEdit>> map = new HashMap<>();
/*     */ 
/*     */       
/* 237 */       int relativeOffset = event.getOffset() - this.fLastRegion.getOffset();
/* 238 */       if (relativeOffset < 0) {
/* 239 */         relativeOffset = 0;
/*     */       }
/*     */       
/* 242 */       int eventEnd = event.getOffset() + event.getLength();
/* 243 */       int lastEnd = this.fLastRegion.getOffset() + this.fLastRegion.getLength();
/*     */       
/* 245 */       if (eventEnd > lastEnd) {
/* 246 */         length = lastEnd - relativeOffset - this.fLastRegion.getOffset();
/*     */       } else {
/* 248 */         length = eventEnd - relativeOffset - this.fLastRegion.getOffset();
/*     */       } 
/* 250 */       String text = event.getText();
/* 251 */       if (text == null) {
/* 252 */         text = "";
/*     */       }
/* 254 */       for (LinkedPosition p : this.fPositions) {
/* 255 */         if (p == this.fLastPosition || p.isDeleted()) {
/*     */           continue;
/*     */         }
/* 258 */         List<ReplaceEdit> edits = map.get(p.getDocument());
/* 259 */         if (edits == null) {
/* 260 */           edits = new ArrayList<>();
/* 261 */           map.put(p.getDocument(), edits);
/*     */         } 
/*     */         
/* 264 */         if (this.fMustEnforceEqualContents) {
/*     */           try {
/* 266 */             edits.add(new ReplaceEdit(p.getOffset(), p.getLength(), this.fLastPosition.getContent()));
/* 267 */           } catch (BadLocationException e) {
/* 268 */             throw new RuntimeException(e);
/*     */           }  continue;
/*     */         } 
/* 271 */         edits.add(new ReplaceEdit(p.getOffset() + relativeOffset, length, text));
/*     */       } 
/*     */       
/* 274 */       this.fMustEnforceEqualContents = false;
/*     */       
/*     */       try {
/* 277 */         Map<IDocument, TextEdit> result = new HashMap<>();
/* 278 */         for (Map.Entry<IDocument, List<ReplaceEdit>> edits : map.entrySet()) {
/* 279 */           MultiTextEdit multiTextEdit = new MultiTextEdit(0, ((IDocument)edits.getKey()).getLength());
/* 280 */           multiTextEdit.addChildren((TextEdit[])((List)edits.getValue()).toArray((Object[])new TextEdit[((List)edits.getValue()).size()]));
/* 281 */           result.put(edits.getKey(), multiTextEdit);
/*     */         } 
/*     */         
/* 284 */         return result;
/* 285 */       } catch (MalformedTreeException malformedTreeException) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 291 */         return null;
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 296 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void seal() {
/* 304 */     Assert.isTrue(!this.fIsSealed);
/* 305 */     this.fIsSealed = true;
/*     */     
/* 307 */     if (!this.fHasCustomIteration && !this.fPositions.isEmpty()) {
/* 308 */       ((LinkedPosition)this.fPositions.get(0)).setSequenceNumber(0);
/*     */     }
/*     */   }
/*     */   
/*     */   IDocument[] getDocuments() {
/* 313 */     IDocument[] docs = new IDocument[this.fPositions.size()];
/* 314 */     int i = 0;
/* 315 */     for (Iterator<LinkedPosition> it = this.fPositions.iterator(); it.hasNext(); i++) {
/* 316 */       LinkedPosition pos = it.next();
/* 317 */       docs[i] = pos.getDocument();
/*     */     } 
/* 319 */     return docs;
/*     */   }
/*     */   
/*     */   void register(LinkedModeModel model) throws BadLocationException {
/* 323 */     for (LinkedPosition pos : this.fPositions) {
/* 324 */       model.register(pos);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   LinkedPosition adopt(LinkedPositionGroup group) throws BadLocationException {
/* 339 */     LinkedPosition found = null;
/* 340 */     for (LinkedPosition pos : group.fPositions) {
/* 341 */       LinkedPosition localFound = null;
/* 342 */       for (LinkedPosition myPos : this.fPositions) {
/* 343 */         if (myPos.includes(pos)) {
/* 344 */           if (found == null) {
/* 345 */             found = myPos;
/* 346 */           } else if (found != myPos) {
/* 347 */             throw new BadLocationException();
/* 348 */           }  if (localFound == null) {
/* 349 */             localFound = myPos;
/*     */           }
/*     */         } 
/*     */       } 
/* 353 */       if (localFound != found)
/* 354 */         throw new BadLocationException(); 
/*     */     } 
/* 356 */     return found;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   LinkedPosition getPosition(LinkedPosition toFind) {
/* 366 */     for (LinkedPosition p : this.fPositions) {
/* 367 */       if (p.includes(toFind))
/* 368 */         return p; 
/*     */     } 
/* 370 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean contains(int offset) {
/* 381 */     for (LinkedPosition pos : this.fPositions) {
/* 382 */       if (pos.includes(offset)) {
/* 383 */         return true;
/*     */       }
/*     */     } 
/* 386 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isEmpty() {
/* 396 */     return this.fPositions.isEmpty();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public boolean isEmtpy() {
/* 407 */     return isEmpty();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LinkedPosition[] getPositions() {
/* 418 */     return this.fPositions.<LinkedPosition>toArray(new LinkedPosition[0]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean contains(Position position) {
/* 428 */     for (LinkedPosition p : this.fPositions) {
/* 429 */       if (position.equals(p))
/* 430 */         return true; 
/*     */     } 
/* 432 */     return false;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.text-3.13.0.jar!\org\eclipse\jface\text\link\LinkedPositionGroup.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */