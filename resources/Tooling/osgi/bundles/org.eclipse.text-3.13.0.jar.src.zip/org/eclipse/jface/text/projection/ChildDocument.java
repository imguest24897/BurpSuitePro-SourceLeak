/*     */ package org.eclipse.jface.text.projection;
/*     */ 
/*     */ import org.eclipse.jface.text.BadLocationException;
/*     */ import org.eclipse.jface.text.IDocument;
/*     */ import org.eclipse.jface.text.IRegion;
/*     */ import org.eclipse.jface.text.Position;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ChildDocument
/*     */   extends ProjectionDocument
/*     */ {
/*     */   private static class VisibleRegion
/*     */     extends Position
/*     */   {
/*     */     public VisibleRegion(int regionOffset, int regionLength) {
/*  47 */       super(regionOffset, regionLength);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean overlapsWith(int regionOffset, int regionLength) {
/*  58 */       boolean appending = (regionOffset == this.offset + this.length && regionLength == 0);
/*  59 */       return !(!appending && !super.overlapsWith(regionOffset, regionLength));
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ChildDocument(IDocument masterDocument) {
/*  69 */     super(masterDocument);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IDocument getParentDocument() {
/*  79 */     return getMasterDocument();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setParentDocumentRange(int offset, int length) throws BadLocationException {
/*  91 */     replaceMasterDocumentRanges(offset, length);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Position getParentDocumentRange() {
/* 100 */     IRegion coverage = getDocumentInformationMapping().getCoverage();
/* 101 */     return new VisibleRegion(coverage.getOffset(), coverage.getLength());
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.text-3.13.0.jar!\org\eclipse\jface\text\projection\ChildDocument.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */