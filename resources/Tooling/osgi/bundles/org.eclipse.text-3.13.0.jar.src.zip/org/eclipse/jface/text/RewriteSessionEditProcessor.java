/*     */ package org.eclipse.jface.text;
/*     */ 
/*     */ import org.eclipse.text.edits.CopyTargetEdit;
/*     */ import org.eclipse.text.edits.DeleteEdit;
/*     */ import org.eclipse.text.edits.InsertEdit;
/*     */ import org.eclipse.text.edits.MalformedTreeException;
/*     */ import org.eclipse.text.edits.MoveTargetEdit;
/*     */ import org.eclipse.text.edits.ReplaceEdit;
/*     */ import org.eclipse.text.edits.TextEdit;
/*     */ import org.eclipse.text.edits.TextEditProcessor;
/*     */ import org.eclipse.text.edits.TextEditVisitor;
/*     */ import org.eclipse.text.edits.UndoEdit;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class RewriteSessionEditProcessor
/*     */   extends TextEditProcessor
/*     */ {
/*     */   private static final int THRESHOLD = 1000;
/*     */   
/*     */   private static final class SizeVisitor
/*     */     extends TextEditVisitor
/*     */   {
/*  40 */     int fSize = 0;
/*     */ 
/*     */     
/*     */     public boolean visit(CopyTargetEdit edit) {
/*  44 */       this.fSize += edit.getLength();
/*  45 */       return super.visit(edit);
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean visit(DeleteEdit edit) {
/*  50 */       this.fSize += edit.getLength();
/*  51 */       return super.visit(edit);
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean visit(InsertEdit edit) {
/*  56 */       this.fSize += edit.getText().length();
/*  57 */       return super.visit(edit);
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean visit(MoveTargetEdit edit) {
/*  62 */       this.fSize += edit.getLength();
/*  63 */       return super.visit(edit);
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean visit(ReplaceEdit edit) {
/*  68 */       this.fSize += Math.max(edit.getLength(), edit.getText().length());
/*  69 */       return super.visit(edit);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RewriteSessionEditProcessor(IDocument document, TextEdit root, int style) {
/*  84 */     super(document, root, style);
/*     */   }
/*     */ 
/*     */   
/*     */   public UndoEdit performEdits() throws MalformedTreeException, BadLocationException {
/*  89 */     IDocument document = getDocument();
/*  90 */     if (!(document instanceof IDocumentExtension4)) {
/*  91 */       return super.performEdits();
/*     */     }
/*  93 */     IDocumentExtension4 extension = (IDocumentExtension4)document;
/*  94 */     boolean isLargeEdit = isLargeEdit(getRoot());
/*  95 */     DocumentRewriteSessionType type = isLargeEdit ? DocumentRewriteSessionType.UNRESTRICTED : DocumentRewriteSessionType.UNRESTRICTED_SMALL;
/*     */     
/*  97 */     DocumentRewriteSession session = extension.startRewriteSession(type);
/*     */     try {
/*  99 */       return super.performEdits();
/*     */     } finally {
/* 101 */       extension.stopRewriteSession(session);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isLargeEdit(TextEdit edit) {
/* 115 */     SizeVisitor sizeVisitor = new SizeVisitor();
/* 116 */     edit.accept(sizeVisitor);
/* 117 */     return (sizeVisitor.fSize > 1000);
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.text-3.13.0.jar!\org\eclipse\jface\text\RewriteSessionEditProcessor.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */