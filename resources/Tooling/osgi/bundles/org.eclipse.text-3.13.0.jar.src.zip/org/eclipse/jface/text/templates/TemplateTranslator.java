/*     */ package org.eclipse.jface.text.templates;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.SortedMap;
/*     */ import java.util.TreeMap;
/*     */ import java.util.regex.Matcher;
/*     */ import java.util.regex.Pattern;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TemplateTranslator
/*     */ {
/*     */   private static final String IDENTIFIER = "(?:[\\p{javaJavaIdentifierPart}&&[^\\$]]++)";
/*     */   private static final String QUALIFIED_NAME = "(?:(?:[\\p{javaJavaIdentifierPart}&&[^\\$]]++)\\.)*+(?:[\\p{javaJavaIdentifierPart}&&[^\\$]]++)";
/*     */   private static final String ARGUMENT_TEXT = "'(?:(?:'')|(?:[^']))*+'";
/*     */   private static final String ARGUMENT = "(?:(?:(?:[\\p{javaJavaIdentifierPart}&&[^\\$]]++)\\.)*+(?:[\\p{javaJavaIdentifierPart}&&[^\\$]]++))|(?:'(?:(?:'')|(?:[^']))*+')";
/*     */   private static final String SPACES = "\\s*+";
/*  88 */   private static final Pattern PARAM_PATTERN = Pattern.compile("(?:(?:(?:[\\p{javaJavaIdentifierPart}&&[^\\$]]++)\\.)*+(?:[\\p{javaJavaIdentifierPart}&&[^\\$]]++))|(?:'(?:(?:'')|(?:[^']))*+')");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  94 */   private static final Pattern ESCAPE_PATTERN = Pattern.compile(
/*  95 */       "\\$\\$|\\$\\{\\s*+((?:[\\p{javaJavaIdentifierPart}&&[^\\$]]++)?+)\\s*+(?::\\s*+((?:(?:[\\p{javaJavaIdentifierPart}&&[^\\$]]++)\\.)*+(?:[\\p{javaJavaIdentifierPart}&&[^\\$]]++))\\s*+(?:\\(\\s*+((?:(?:(?:(?:(?:[\\p{javaJavaIdentifierPart}&&[^\\$]]++)\\.)*+(?:[\\p{javaJavaIdentifierPart}&&[^\\$]]++))|(?:'(?:(?:'')|(?:[^']))*+'))\\s*+,\\s*+)*+(?:(?:(?:(?:[\\p{javaJavaIdentifierPart}&&[^\\$]]++)\\.)*+(?:[\\p{javaJavaIdentifierPart}&&[^\\$]]++))|(?:'(?:(?:'')|(?:[^']))*+')))\\s*+\\))?\\s*+)?\\}|\\$");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String fErrorMessage;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private TemplateVariableType fCurrentType;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final class VariableDescription
/*     */   {
/* 119 */     final List<Integer> fOffsets = new ArrayList<>(5);
/*     */     final String fName;
/*     */     TemplateVariableType fType;
/*     */     
/*     */     VariableDescription(String name, TemplateVariableType type) {
/* 124 */       this.fName = name;
/* 125 */       this.fType = type;
/*     */     }
/*     */     
/*     */     void mergeType(TemplateVariableType type) throws TemplateException {
/* 129 */       if (type == null)
/*     */         return; 
/* 131 */       if (this.fType == null)
/* 132 */         this.fType = type; 
/* 133 */       if (!type.equals(this.fType)) {
/* 134 */         TemplateTranslator.this.fail(TextTemplateMessages.getFormattedString("TemplateTranslator.error.incompatible.type", this.fName));
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getErrorMessage() {
/* 155 */     return this.fErrorMessage;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TemplateBuffer translate(Template template) throws TemplateException {
/* 168 */     return parse(template.getPattern());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TemplateBuffer translate(String string) throws TemplateException {
/* 182 */     return parse(string);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private TemplateBuffer parse(String string) throws TemplateException {
/* 194 */     this.fErrorMessage = null;
/* 195 */     StringBuilder buffer = new StringBuilder(string.length());
/* 196 */     Matcher matcher = ESCAPE_PATTERN.matcher(string);
/* 197 */     Map<String, VariableDescription> variables = new LinkedHashMap<>();
/*     */     
/* 199 */     int complete = 0;
/* 200 */     while (matcher.find()) {
/*     */       String name, typeName, params; TemplateVariableType type;
/* 202 */       buffer.append(string.substring(complete, matcher.start()));
/*     */       
/*     */       String str1;
/* 205 */       switch ((str1 = matcher.group()).hashCode()) { case 36: if (str1.equals("$")) {
/*     */             
/* 207 */             fail(TextTemplateMessages.getString("TemplateTranslator.error.incomplete.variable")); break;
/*     */           } 
/*     */         case 1152:
/*     */           if (str1.equals("$$")) {
/* 211 */             buffer.append('$');
/*     */             break;
/*     */           } 
/*     */         default:
/* 215 */           name = matcher.group(1);
/* 216 */           typeName = matcher.group(2);
/* 217 */           params = matcher.group(3);
/* 218 */           type = createType(typeName, params);
/* 219 */           updateOrCreateVariable(variables, name, type, buffer.length());
/* 220 */           buffer.append(name);
/*     */           break; }
/*     */       
/* 223 */       complete = matcher.end();
/*     */     } 
/*     */     
/* 226 */     buffer.append(string.substring(complete));
/*     */     
/* 228 */     TemplateVariable[] vars = createVariables(variables);
/* 229 */     fixOffsetsAndBuffer(buffer, vars);
/* 230 */     return new TemplateBuffer(buffer.toString(), vars);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void fixOffsetsAndBuffer(StringBuilder buffer, TemplateVariable[] vars) {
/* 242 */     SortedMap<Integer, TemplateVariable> varsByOffset = new TreeMap<>(); byte b; int i; TemplateVariable[] arrayOfTemplateVariable;
/* 243 */     for (i = (arrayOfTemplateVariable = vars).length, b = 0; b < i; ) { TemplateVariable var = arrayOfTemplateVariable[b]; byte b1; int j, arrayOfInt[];
/* 244 */       for (j = (arrayOfInt = var.getOffsets()).length, b1 = 0; b1 < j; ) { int offset = arrayOfInt[b1];
/* 245 */         varsByOffset.put(Integer.valueOf(offset), var); b1++; }
/*     */        b++; }
/*     */     
/* 248 */     int totalOffsetDelta = 0;
/* 249 */     Map<TemplateVariable, Collection<Integer>> fixedOffsets = new HashMap<>(vars.length, 1.0F);
/* 250 */     for (Map.Entry<Integer, TemplateVariable> entry : varsByOffset.entrySet()) {
/* 251 */       int initialOffset = ((Integer)entry.getKey()).intValue();
/* 252 */       TemplateVariable variable = entry.getValue();
/* 253 */       int fixedOffset = initialOffset + totalOffsetDelta;
/* 254 */       ((Collection<Integer>)fixedOffsets.computeIfAbsent(variable, v -> new ArrayList((v.getOffsets()).length))).add(Integer.valueOf(fixedOffset));
/* 255 */       int currentOffsetDelta = variable.getDefaultValue().length() - variable.getName().length();
/* 256 */       buffer.replace(fixedOffset, fixedOffset + variable.getName().length(), variable.getDefaultValue());
/* 257 */       totalOffsetDelta += currentOffsetDelta;
/*     */     } 
/* 259 */     fixedOffsets.forEach((variable, fixs) -> variable.setOffsets(fixs.stream().mapToInt(Integer::valueOf).toArray()));
/*     */   }
/*     */   
/*     */   private TemplateVariableType createType(String typeName, String paramString) {
/* 263 */     if (typeName == null) {
/* 264 */       return null;
/*     */     }
/* 266 */     if (paramString == null) {
/* 267 */       return new TemplateVariableType(typeName);
/*     */     }
/* 269 */     Matcher matcher = PARAM_PATTERN.matcher(paramString);
/* 270 */     List<String> params = new ArrayList<>(5);
/* 271 */     while (matcher.find()) {
/* 272 */       String argument = matcher.group();
/* 273 */       if (argument.charAt(0) == '\'')
/*     */       {
/* 275 */         argument = argument.substring(1, argument.length() - 1).replace("''", "'");
/*     */       }
/*     */       
/* 278 */       params.add(argument);
/*     */     } 
/*     */     
/* 281 */     return new TemplateVariableType(typeName, params.<String>toArray(new String[params.size()]));
/*     */   }
/*     */   
/*     */   private void fail(String message) throws TemplateException {
/* 285 */     this.fErrorMessage = message;
/* 286 */     throw new TemplateException(message);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private VariableDescription updateOrCreateVariable(Map<String, VariableDescription> variables, String name, TemplateVariableType type, int offset) throws TemplateException {
/* 303 */     VariableDescription varDesc = variables.get(name);
/* 304 */     if (varDesc == null) {
/* 305 */       varDesc = new VariableDescription(name, type);
/* 306 */       variables.put(name, varDesc);
/*     */     } else {
/* 308 */       varDesc.mergeType(type);
/*     */     } 
/* 310 */     varDesc.fOffsets.add(Integer.valueOf(offset));
/* 311 */     return varDesc;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private TemplateVariable[] createVariables(Map<String, VariableDescription> variables) {
/* 322 */     TemplateVariable[] result = new TemplateVariable[variables.size()];
/* 323 */     int idx = 0;
/* 324 */     for (Iterator<VariableDescription> it = variables.values().iterator(); it.hasNext(); idx++) {
/* 325 */       VariableDescription desc = it.next();
/* 326 */       TemplateVariableType type = (desc.fType == null) ? new TemplateVariableType(desc.fName) : desc.fType;
/* 327 */       int[] offsets = new int[desc.fOffsets.size()];
/* 328 */       int i = 0;
/* 329 */       for (Iterator<Integer> intIt = desc.fOffsets.iterator(); intIt.hasNext(); i++) {
/* 330 */         Integer offset = intIt.next();
/* 331 */         offsets[i] = offset.intValue();
/*     */       } 
/* 333 */       this.fCurrentType = type;
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 338 */       TemplateVariable var = createVariable(type.getName(), desc.fName, offsets);
/* 339 */       result[idx] = var;
/*     */     } 
/* 341 */     this.fCurrentType = null;
/* 342 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   protected TemplateVariable createVariable(String type, String name, int[] offsets) {
/* 360 */     return createVariable(this.fCurrentType, name, offsets);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected TemplateVariable createVariable(TemplateVariableType type, String name, int[] offsets) {
/* 377 */     return new TemplateVariable(type, name, name, offsets);
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.text-3.13.0.jar!\org\eclipse\jface\text\templates\TemplateTranslator.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */