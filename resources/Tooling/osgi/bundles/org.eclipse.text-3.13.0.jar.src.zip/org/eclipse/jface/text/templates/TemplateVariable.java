/*     */ package org.eclipse.jface.text.templates;
/*     */ 
/*     */ import org.eclipse.core.runtime.Assert;
/*     */ import org.eclipse.jface.text.TextUtilities;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TemplateVariable
/*     */ {
/*     */   private final TemplateVariableType fType;
/*     */   private final String fName;
/*     */   private final int fInitialLength;
/*     */   private int[] fOffsets;
/*     */   private boolean fIsUnambiguous;
/*     */   private boolean fIsResolved;
/*     */   private String[] fValues;
/*     */   
/*     */   public TemplateVariable(String type, String defaultValue, int[] offsets) {
/*  66 */     this(type, new String[] { defaultValue }, offsets);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TemplateVariable(String type, String name, String defaultValue, int[] offsets) {
/*  78 */     this(type, name, new String[] { defaultValue }, offsets);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TemplateVariable(TemplateVariableType type, String name, String defaultValue, int[] offsets) {
/*  91 */     this(type, name, new String[] { defaultValue }, offsets, defaultValue.length());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TemplateVariable(String type, String[] values, int[] offsets) {
/* 103 */     this(type, type, values, offsets);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TemplateVariable(String type, String name, String[] values, int[] offsets) {
/* 115 */     this(type, name, values, offsets, values[0].length());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TemplateVariable(String type, String name, String[] values, int[] offsets, int length) {
/* 129 */     this(new TemplateVariableType(type), name, values, offsets, length);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   TemplateVariable(TemplateVariableType type, String name, String[] values, int[] offsets, int initialLength) {
/* 143 */     Assert.isNotNull(type);
/* 144 */     Assert.isNotNull(name);
/* 145 */     this.fInitialLength = initialLength;
/* 146 */     this.fType = type;
/* 147 */     this.fName = name;
/* 148 */     setValues(values);
/* 149 */     setOffsets(offsets);
/* 150 */     setUnambiguous(false);
/* 151 */     setResolved(false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getType() {
/* 160 */     return this.fType.getName();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TemplateVariableType getVariableType() {
/* 170 */     return this.fType;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getName() {
/* 179 */     return this.fName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getDefaultValue() {
/* 189 */     return getValues()[0];
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String[] getValues() {
/* 199 */     return this.fValues;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getLength() {
/* 208 */     return getDefaultValue().length();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final int getInitialLength() {
/* 220 */     return this.fInitialLength;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setOffsets(int[] offsets) {
/* 229 */     this.fOffsets = TextUtilities.copy(offsets);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int[] getOffsets() {
/* 239 */     return this.fOffsets;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void setValue(String value) {
/* 249 */     setValues(new String[] { value });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setValues(String[] values) {
/* 259 */     Assert.isTrue((values.length > 0));
/* 260 */     this.fValues = TextUtilities.copy(values);
/* 261 */     setResolved(true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setUnambiguous(boolean unambiguous) {
/* 270 */     this.fIsUnambiguous = unambiguous;
/* 271 */     if (unambiguous) {
/* 272 */       setResolved(true);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isUnambiguous() {
/* 281 */     return this.fIsUnambiguous;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setResolved(boolean resolved) {
/* 291 */     this.fIsResolved = resolved;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isResolved() {
/* 302 */     return this.fIsResolved;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.text-3.13.0.jar!\org\eclipse\jface\text\templates\TemplateVariable.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */