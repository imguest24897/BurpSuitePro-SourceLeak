package org.eclipse.jface.text;

public interface Builder {
  Builder add(String... paramVarArgs);
  
  MultiStringMatcher build();
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.text-3.13.0.jar!\org\eclipse\jface\text\MultiStringMatcher$Builder.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */