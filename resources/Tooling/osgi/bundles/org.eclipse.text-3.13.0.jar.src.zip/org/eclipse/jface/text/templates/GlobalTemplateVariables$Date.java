/*     */ package org.eclipse.jface.text.templates;
/*     */ 
/*     */ import java.text.DateFormat;
/*     */ import java.text.SimpleDateFormat;
/*     */ import java.util.List;
/*     */ import java.util.Locale;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Date
/*     */   extends SimpleTemplateVariableResolver
/*     */ {
/*     */   public Date() {
/* 162 */     super("date", TextTemplateMessages.getString("GlobalVariables.variable.description.date"));
/*     */   }
/*     */ 
/*     */   
/*     */   public void resolve(TemplateVariable variable, TemplateContext context) {
/* 167 */     List<String> params = variable.getVariableType().getParams();
/* 168 */     if (!params.isEmpty() && params.get(0) != null) {
/* 169 */       resolveWithParams(variable, context, params);
/*     */     } else {
/*     */       
/* 172 */       super.resolve(variable, context);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private void resolveWithParams(TemplateVariable variable, TemplateContext context, List<String> params) {
/*     */     try {
/*     */       DateFormat format;
/* 180 */       if (params.size() >= 2 && params.get(1) != null) {
/* 181 */         String localeString = params.get(1);
/* 182 */         if (localeString.contains("_")) {
/* 183 */           String[] localeData = localeString.split("_");
/* 184 */           format = new SimpleDateFormat(params.get(0), new Locale(localeData[0], localeData[1]));
/*     */         } else {
/* 186 */           format = new SimpleDateFormat(params.get(0), new Locale(localeString));
/*     */         } 
/*     */       } else {
/* 189 */         format = new SimpleDateFormat(params.get(0));
/*     */       } 
/*     */       
/* 192 */       variable.setValue(format.format(new java.util.Date()));
/* 193 */       variable.setUnambiguous(true);
/* 194 */       variable.setResolved(true);
/* 195 */     } catch (IllegalArgumentException illegalArgumentException) {
/*     */       
/* 197 */       super.resolve(variable, context);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   protected String resolve(TemplateContext context) {
/* 203 */     return DateFormat.getDateInstance().format(new java.util.Date());
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.text-3.13.0.jar!\org\eclipse\jface\text\templates\GlobalTemplateVariables$Date.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */