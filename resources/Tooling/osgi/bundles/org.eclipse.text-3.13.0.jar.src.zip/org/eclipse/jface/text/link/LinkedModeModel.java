/*     */ package org.eclipse.jface.text.link;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import org.eclipse.core.runtime.Assert;
/*     */ import org.eclipse.jface.text.BadLocationException;
/*     */ import org.eclipse.jface.text.BadPositionCategoryException;
/*     */ import org.eclipse.jface.text.DocumentEvent;
/*     */ import org.eclipse.jface.text.IDocument;
/*     */ import org.eclipse.jface.text.IDocumentExtension;
/*     */ import org.eclipse.jface.text.IDocumentListener;
/*     */ import org.eclipse.jface.text.IPositionUpdater;
/*     */ import org.eclipse.jface.text.Position;
/*     */ import org.eclipse.text.edits.MalformedTreeException;
/*     */ import org.eclipse.text.edits.TextEdit;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LinkedModeModel
/*     */ {
/*     */   public static boolean hasInstalledModel(IDocument document) {
/*  83 */     return LinkedModeManager.hasManager(document);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean hasInstalledModel(IDocument[] documents) {
/*  96 */     return LinkedModeManager.hasManager(documents);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void closeAllModels(IDocument document) {
/* 107 */     LinkedModeManager.cancelManager(document);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static LinkedModeModel getModel(IDocument document, int offset) {
/* 122 */     if (!hasInstalledModel(document)) {
/* 123 */       return null;
/*     */     }
/* 125 */     LinkedModeManager mgr = LinkedModeManager.getLinkedManager(new IDocument[] { document }, false);
/* 126 */     if (mgr != null)
/* 127 */       return mgr.getTopEnvironment(); 
/* 128 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private class Replace
/*     */     implements IDocumentExtension.IReplace
/*     */   {
/*     */     private TextEdit fEdit;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Replace(TextEdit edit) {
/* 146 */       this.fEdit = edit;
/*     */     }
/*     */ 
/*     */     
/*     */     public void perform(IDocument document, IDocumentListener owner) throws RuntimeException, MalformedTreeException {
/* 151 */       document.removeDocumentListener(owner);
/* 152 */       LinkedModeModel.this.fIsChanging = true;
/*     */       try {
/* 154 */         this.fEdit.apply(document, 3);
/* 155 */       } catch (BadLocationException e) {
/*     */ 
/*     */ 
/*     */         
/* 159 */         throw new RuntimeException(e);
/*     */       } finally {
/* 161 */         document.addDocumentListener(owner);
/* 162 */         LinkedModeModel.this.fIsChanging = false;
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private class DocumentListener
/*     */     implements IDocumentListener
/*     */   {
/*     */     private boolean fExit = false;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void documentAboutToBeChanged(DocumentEvent event) {
/* 185 */       if (LinkedModeModel.this.fParentEnvironment != null && LinkedModeModel.this.fParentEnvironment.isChanging()) {
/*     */         return;
/*     */       }
/* 188 */       for (LinkedPositionGroup group : LinkedModeModel.this.fGroups) {
/* 189 */         if (!group.isLegalEvent(event)) {
/* 190 */           this.fExit = true;
/*     */           return;
/*     */         } 
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void documentChanged(DocumentEvent event) {
/* 203 */       if (this.fExit) {
/* 204 */         LinkedModeModel.this.exit(8);
/*     */         return;
/*     */       } 
/* 207 */       this.fExit = false;
/*     */ 
/*     */       
/* 210 */       if (LinkedModeModel.this.fParentEnvironment != null && LinkedModeModel.this.fParentEnvironment.isChanging()) {
/*     */         return;
/*     */       }
/*     */       
/* 214 */       Map<IDocument, TextEdit> result = null;
/* 215 */       for (LinkedPositionGroup group : LinkedModeModel.this.fGroups) {
/* 216 */         Map<IDocument, TextEdit> map = group.handleEvent(event);
/* 217 */         if (result != null && map != null) {
/*     */           
/* 219 */           LinkedModeModel.this.exit(8);
/*     */           return;
/*     */         } 
/* 222 */         if (map != null) {
/* 223 */           result = map;
/*     */         }
/*     */       } 
/* 226 */       if (result != null)
/*     */       {
/* 228 */         for (Map.Entry<IDocument, TextEdit> entry : result.entrySet()) {
/* 229 */           IDocument doc = entry.getKey();
/* 230 */           TextEdit edit = entry.getValue();
/* 231 */           LinkedModeModel.Replace replace = new LinkedModeModel.Replace(edit);
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 236 */           if (doc == event.getDocument()) {
/* 237 */             if (doc instanceof IDocumentExtension) {
/* 238 */               ((IDocumentExtension)doc).registerPostNotificationReplace(this, replace);
/*     */             }
/*     */             
/*     */             continue;
/*     */           } 
/* 243 */           replace.perform(doc, this);
/*     */         } 
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 252 */   private final List<LinkedPositionGroup> fGroups = new ArrayList<>();
/*     */   
/* 254 */   private final Set<IDocument> fDocuments = new HashSet<>();
/*     */   
/* 256 */   private final IPositionUpdater fUpdater = new InclusivePositionUpdater(getCategory());
/*     */   
/* 258 */   private final DocumentListener fDocumentListener = new DocumentListener();
/*     */ 
/*     */ 
/*     */   
/*     */   private LinkedModeModel fParentEnvironment;
/*     */ 
/*     */ 
/*     */   
/* 266 */   private LinkedPosition fParentPosition = null;
/*     */ 
/*     */   
/*     */   private boolean fIsSealed = false;
/*     */ 
/*     */   
/*     */   private boolean fIsChanging = false;
/*     */ 
/*     */   
/* 275 */   private final List<ILinkedModeListener> fListeners = new ArrayList<>();
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean fIsActive = true;
/*     */ 
/*     */   
/* 282 */   private List<LinkedPosition> fPositionSequence = new ArrayList<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean isChanging() {
/* 292 */     return !(!this.fIsChanging && (this.fParentEnvironment == null || !this.fParentEnvironment.isChanging()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void enforceDisjoint(LinkedPositionGroup group) throws BadLocationException {
/* 304 */     for (LinkedPositionGroup g : this.fGroups) {
/* 305 */       g.enforceDisjoint(group);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void exit(int flags) {
/* 316 */     if (!this.fIsActive) {
/*     */       return;
/*     */     }
/* 319 */     this.fIsActive = false;
/*     */     
/* 321 */     for (IDocument doc : this.fDocuments) {
/*     */       try {
/* 323 */         doc.removePositionCategory(getCategory());
/* 324 */       } catch (BadPositionCategoryException badPositionCategoryException) {
/*     */         
/* 326 */         Assert.isTrue(false);
/*     */       } 
/* 328 */       doc.removePositionUpdater(this.fUpdater);
/* 329 */       doc.removeDocumentListener(this.fDocumentListener);
/*     */     } 
/*     */     
/* 332 */     this.fDocuments.clear();
/* 333 */     this.fGroups.clear();
/*     */     
/* 335 */     List<ILinkedModeListener> listeners = new ArrayList<>(this.fListeners);
/* 336 */     this.fListeners.clear();
/* 337 */     for (ILinkedModeListener listener : listeners) {
/* 338 */       listener.left(this, flags);
/*     */     }
/*     */ 
/*     */     
/* 342 */     if (this.fParentEnvironment != null) {
/* 343 */       this.fParentEnvironment.resume(flags);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void stopForwarding(int flags) {
/* 355 */     this.fDocumentListener.fExit = true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void manageDocument(IDocument document) {
/* 366 */     if (!this.fDocuments.contains(document)) {
/* 367 */       this.fDocuments.add(document);
/* 368 */       document.addPositionCategory(getCategory());
/* 369 */       document.addPositionUpdater(this.fUpdater);
/* 370 */       document.addDocumentListener(this.fDocumentListener);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String getCategory() {
/* 381 */     return toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addGroup(LinkedPositionGroup group) throws BadLocationException {
/* 407 */     if (group == null)
/* 408 */       throw new IllegalArgumentException("group may not be null"); 
/* 409 */     if (this.fIsSealed)
/* 410 */       throw new IllegalStateException("model is already installed"); 
/* 411 */     if (this.fGroups.contains(group)) {
/*     */       return;
/*     */     }
/*     */     
/* 415 */     enforceDisjoint(group);
/* 416 */     group.seal();
/* 417 */     this.fGroups.add(group);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void forceInstall() throws BadLocationException {
/* 441 */     if (!install(true)) {
/* 442 */       Assert.isTrue(false);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean tryInstall() throws BadLocationException {
/* 462 */     return install(false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean install(boolean force) throws BadLocationException {
/* 482 */     if (this.fIsSealed)
/* 483 */       throw new IllegalStateException("model is already installed"); 
/* 484 */     enforceNotEmpty();
/*     */     
/* 486 */     IDocument[] documents = getDocuments();
/* 487 */     LinkedModeManager manager = LinkedModeManager.getLinkedManager(documents, force);
/*     */     
/* 489 */     Assert.isTrue(!(force && manager == null));
/* 490 */     if (manager == null) {
/* 491 */       return false;
/*     */     }
/* 493 */     if (!manager.nestEnvironment(this, force)) {
/* 494 */       if (force) {
/* 495 */         Assert.isTrue(false);
/*     */       } else {
/* 497 */         return false;
/*     */       } 
/*     */     }
/*     */     
/* 501 */     this.fIsSealed = true;
/* 502 */     if (this.fParentEnvironment != null) {
/* 503 */       this.fParentEnvironment.suspend();
/*     */     }
/*     */     
/*     */     try {
/* 507 */       for (LinkedPositionGroup group : this.fGroups) {
/* 508 */         group.register(this);
/*     */       }
/* 510 */       return true;
/* 511 */     } catch (BadLocationException e) {
/*     */       
/* 513 */       exit(0);
/* 514 */       throw e;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void enforceNotEmpty() {
/* 523 */     boolean hasPosition = false;
/* 524 */     for (LinkedPositionGroup linkedPositionGroup : this.fGroups) {
/* 525 */       if (!linkedPositionGroup.isEmpty()) {
/* 526 */         hasPosition = true; break;
/*     */       } 
/*     */     } 
/* 529 */     if (!hasPosition) {
/* 530 */       throw new IllegalStateException("must specify at least one linked position");
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private IDocument[] getDocuments() {
/* 539 */     Set<IDocument> docs = new HashSet<>();
/* 540 */     for (LinkedPositionGroup group : this.fGroups) {
/* 541 */       docs.addAll(Arrays.asList(group.getDocuments()));
/*     */     }
/* 543 */     return docs.<IDocument>toArray(new IDocument[docs.size()]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean canNestInto(LinkedModeModel parent) {
/* 555 */     for (LinkedPositionGroup group : this.fGroups) {
/* 556 */       if (!enforceNestability(group, parent)) {
/* 557 */         this.fParentPosition = null;
/* 558 */         return false;
/*     */       } 
/*     */     } 
/*     */     
/* 562 */     Assert.isNotNull(this.fParentPosition);
/* 563 */     this.fParentEnvironment = parent;
/* 564 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean enforceNestability(LinkedPositionGroup group, LinkedModeModel model) {
/* 577 */     Assert.isNotNull(model);
/* 578 */     Assert.isNotNull(group);
/*     */     
/*     */     try {
/* 581 */       for (LinkedPositionGroup pg : model.fGroups) {
/*     */         
/* 583 */         LinkedPosition pos = pg.adopt(group);
/* 584 */         if (pos != null && this.fParentPosition != null && this.fParentPosition != pos)
/* 585 */           return false; 
/* 586 */         if (this.fParentPosition == null && pos != null)
/* 587 */           this.fParentPosition = pos; 
/*     */       } 
/* 589 */     } catch (BadLocationException badLocationException) {
/* 590 */       return false;
/*     */     } 
/*     */ 
/*     */     
/* 594 */     return (this.fParentPosition != null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isNested() {
/* 609 */     return (this.fParentEnvironment != null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<LinkedPosition> getTabStopSequence() {
/* 625 */     return this.fPositionSequence;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addLinkingListener(ILinkedModeListener listener) {
/* 635 */     Assert.isNotNull(listener);
/* 636 */     if (!this.fListeners.contains(listener)) {
/* 637 */       this.fListeners.add(listener);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void removeLinkingListener(ILinkedModeListener listener) {
/* 647 */     this.fListeners.remove(listener);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LinkedPosition findPosition(LinkedPosition toFind) {
/* 665 */     LinkedPosition position = null;
/* 666 */     for (LinkedPositionGroup group : this.fGroups) {
/* 667 */       position = group.getPosition(toFind);
/* 668 */       if (position != null)
/*     */         break; 
/*     */     } 
/* 671 */     return position;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void register(LinkedPosition position) throws BadLocationException {
/* 683 */     Assert.isNotNull(position);
/*     */     
/* 685 */     IDocument document = position.getDocument();
/* 686 */     manageDocument(document);
/*     */     try {
/* 688 */       document.addPosition(getCategory(), position);
/* 689 */     } catch (BadPositionCategoryException badPositionCategoryException) {
/*     */       
/* 691 */       Assert.isTrue(false);
/*     */     } 
/* 693 */     int seqNr = position.getSequenceNumber();
/* 694 */     if (seqNr != -1) {
/* 695 */       this.fPositionSequence.add(position);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void suspend() {
/* 703 */     List<ILinkedModeListener> l = new ArrayList<>(this.fListeners);
/* 704 */     for (ILinkedModeListener listener : l) {
/* 705 */       listener.suspend(this);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void resume(int flags) {
/* 716 */     List<ILinkedModeListener> l = new ArrayList<>(this.fListeners);
/* 717 */     for (ILinkedModeListener listener : l) {
/* 718 */       listener.resume(this, flags);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean anyPositionContains(int offset) {
/* 732 */     for (LinkedPositionGroup group : this.fGroups) {
/* 733 */       if (group.contains(offset))
/*     */       {
/*     */         
/* 736 */         return true; } 
/*     */     } 
/* 738 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LinkedPositionGroup getGroupForPosition(Position position) {
/* 759 */     for (LinkedPositionGroup group : this.fGroups) {
/* 760 */       if (group.contains(position))
/* 761 */         return group; 
/*     */     } 
/* 763 */     return null;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.text-3.13.0.jar!\org\eclipse\jface\text\link\LinkedModeModel.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */