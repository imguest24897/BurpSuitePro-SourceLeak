/*    */ package org.eclipse.jface.text;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class Replace
/*    */ {
/*    */   public int newOffset;
/*    */   public final int offset;
/*    */   public final int length;
/*    */   public final String text;
/*    */   
/*    */   public Replace(int offset, int newOffset, int length, String text) {
/* 42 */     this.newOffset = newOffset;
/* 43 */     this.offset = offset;
/* 44 */     this.length = length;
/* 45 */     this.text = text;
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.text-3.13.0.jar!\org\eclipse\jface\text\SequentialRewriteTextStore$Replace.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */