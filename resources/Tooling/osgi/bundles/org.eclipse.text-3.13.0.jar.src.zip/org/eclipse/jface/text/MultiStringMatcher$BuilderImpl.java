/*     */ package org.eclipse.jface.text;
/*     */ 
/*     */ import java.util.function.Consumer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class BuilderImpl
/*     */   implements MultiStringMatcher.Builder
/*     */ {
/*  95 */   private MultiStringMatcher m = new MultiStringMatcher();
/*     */ 
/*     */   
/*     */   private void check() {
/*  99 */     if (this.m == null) {
/* 100 */       throw new IllegalStateException("Builder.build() was already called");
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public MultiStringMatcher.Builder add(String... searchStrings) {
/* 106 */     check();
/* 107 */     this.m.add(searchStrings);
/* 108 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public MultiStringMatcher build() {
/* 113 */     check();
/* 114 */     MultiStringMatcher result = this.m;
/* 115 */     this.m = null;
/* 116 */     if (!result.root.hasChildren())
/*     */     {
/* 118 */       return new MultiStringMatcher()
/*     */         {
/*     */           public void find(CharSequence text, int offset, Consumer<MultiStringMatcher.Match> matches) {}
/*     */ 
/*     */ 
/*     */ 
/*     */           
/*     */           public MultiStringMatcher.Match indexOf(CharSequence text, int offset) {
/* 126 */             return null;
/*     */           }
/*     */         };
/*     */     }
/* 130 */     result.buildLinks();
/* 131 */     return result;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.text-3.13.0.jar!\org\eclipse\jface\text\MultiStringMatcher$BuilderImpl.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */