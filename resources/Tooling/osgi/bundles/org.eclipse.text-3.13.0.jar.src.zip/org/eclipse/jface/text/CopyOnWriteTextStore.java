/*     */ package org.eclipse.jface.text;
/*     */ 
/*     */ import org.eclipse.core.runtime.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CopyOnWriteTextStore
/*     */   implements ITextStore
/*     */ {
/*     */   private static class StringTextStore
/*     */     implements ITextStore
/*     */   {
/*     */     private static final int SMALL_TEXT_LIMIT = 1048576;
/*     */     private final String fText;
/*     */     private final int fCopyLimit;
/*     */     
/*     */     private StringTextStore() {
/*  55 */       this("");
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private StringTextStore(String text) {
/*  65 */       this.fText = (text != null) ? text : "";
/*  66 */       this.fCopyLimit = (this.fText.length() > 1048576) ? (this.fText.length() / 2) : 0;
/*     */     }
/*     */ 
/*     */     
/*     */     public char get(int offset) {
/*  71 */       return this.fText.charAt(offset);
/*     */     }
/*     */ 
/*     */     
/*     */     public String get(int offset, int length) {
/*  76 */       if (length < this.fCopyLimit)
/*     */       {
/*  78 */         return new String(this.fText.substring(offset, offset + length).toCharArray());
/*     */       }
/*  80 */       return this.fText.substring(offset, offset + length);
/*     */     }
/*     */ 
/*     */     
/*     */     public int getLength() {
/*  85 */       return this.fText.length();
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void replace(int offset, int length, String text) {
/*  91 */       throw new UnsupportedOperationException();
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void set(String text) {
/*  97 */       throw new UnsupportedOperationException();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/* 103 */   protected ITextStore fTextStore = new StringTextStore();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final ITextStore fModifiableTextStore;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CopyOnWriteTextStore(ITextStore modifiableTextStore) {
/* 116 */     Assert.isNotNull(modifiableTextStore);
/* 117 */     this.fTextStore = new StringTextStore();
/* 118 */     this.fModifiableTextStore = modifiableTextStore;
/*     */   }
/*     */ 
/*     */   
/*     */   public char get(int offset) {
/* 123 */     return this.fTextStore.get(offset);
/*     */   }
/*     */ 
/*     */   
/*     */   public String get(int offset, int length) {
/* 128 */     return this.fTextStore.get(offset, length);
/*     */   }
/*     */ 
/*     */   
/*     */   public int getLength() {
/* 133 */     return this.fTextStore.getLength();
/*     */   }
/*     */ 
/*     */   
/*     */   public void replace(int offset, int length, String text) {
/* 138 */     if (this.fTextStore != this.fModifiableTextStore) {
/* 139 */       String content = this.fTextStore.get(0, this.fTextStore.getLength());
/* 140 */       this.fTextStore = this.fModifiableTextStore;
/* 141 */       this.fTextStore.set(content);
/*     */     } 
/* 143 */     this.fTextStore.replace(offset, length, text);
/*     */   }
/*     */ 
/*     */   
/*     */   public void set(String text) {
/* 148 */     this.fTextStore = new StringTextStore(text);
/* 149 */     this.fModifiableTextStore.set("");
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.text-3.13.0.jar!\org\eclipse\jface\text\CopyOnWriteTextStore.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */