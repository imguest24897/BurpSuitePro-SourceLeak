/*    */ package org.eclipse.jface.text.templates;
/*    */ 
/*    */ import java.text.MessageFormat;
/*    */ import java.util.MissingResourceException;
/*    */ import java.util.ResourceBundle;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class TextTemplateMessages
/*    */ {
/* 25 */   private static final String RESOURCE_BUNDLE = TextTemplateMessages.class.getName();
/* 26 */   private static ResourceBundle fgResourceBundle = ResourceBundle.getBundle(RESOURCE_BUNDLE);
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static String getString(String key) {
/*    */     try {
/* 33 */       return fgResourceBundle.getString(key);
/* 34 */     } catch (MissingResourceException missingResourceException) {
/* 35 */       return String.valueOf('!') + key + '!';
/*    */     } 
/*    */   }
/*    */   
/*    */   public static String getFormattedString(String key, Object arg) {
/* 40 */     return MessageFormat.format(getString(key), new Object[] { arg });
/*    */   }
/*    */ 
/*    */   
/*    */   public static String getFormattedString(String key, Object[] args) {
/* 45 */     return MessageFormat.format(getString(key), args);
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.text-3.13.0.jar!\org\eclipse\jface\text\templates\TextTemplateMessages.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */