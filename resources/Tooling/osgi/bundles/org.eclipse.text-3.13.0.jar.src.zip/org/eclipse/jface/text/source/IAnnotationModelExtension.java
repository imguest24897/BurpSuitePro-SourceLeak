package org.eclipse.jface.text.source;

import java.util.Map;
import org.eclipse.jface.text.Position;

public interface IAnnotationModelExtension {
  void addAnnotationModel(Object paramObject, IAnnotationModel paramIAnnotationModel);
  
  IAnnotationModel getAnnotationModel(Object paramObject);
  
  IAnnotationModel removeAnnotationModel(Object paramObject);
  
  void replaceAnnotations(Annotation[] paramArrayOfAnnotation, Map<? extends Annotation, ? extends Position> paramMap) throws ClassCastException;
  
  void modifyAnnotationPosition(Annotation paramAnnotation, Position paramPosition);
  
  void removeAllAnnotations();
  
  Object getModificationStamp();
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.text-3.13.0.jar!\org\eclipse\jface\text\source\IAnnotationModelExtension.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */