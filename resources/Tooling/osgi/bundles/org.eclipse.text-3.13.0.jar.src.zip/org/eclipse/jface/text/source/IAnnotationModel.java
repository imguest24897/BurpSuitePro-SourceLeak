package org.eclipse.jface.text.source;

import java.util.Iterator;
import org.eclipse.jface.text.IDocument;
import org.eclipse.jface.text.Position;

public interface IAnnotationModel {
  void addAnnotationModelListener(IAnnotationModelListener paramIAnnotationModelListener);
  
  void removeAnnotationModelListener(IAnnotationModelListener paramIAnnotationModelListener);
  
  void connect(IDocument paramIDocument);
  
  void disconnect(IDocument paramIDocument);
  
  void addAnnotation(Annotation paramAnnotation, Position paramPosition);
  
  void removeAnnotation(Annotation paramAnnotation);
  
  Iterator<Annotation> getAnnotationIterator();
  
  Position getPosition(Annotation paramAnnotation);
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.text-3.13.0.jar!\org\eclipse\jface\text\source\IAnnotationModel.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */