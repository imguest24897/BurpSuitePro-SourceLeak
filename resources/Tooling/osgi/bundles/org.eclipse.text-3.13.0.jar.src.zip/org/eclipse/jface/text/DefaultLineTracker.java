/*    */ package org.eclipse.jface.text;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DefaultLineTracker
/*    */   extends AbstractLineTracker
/*    */ {
/* 30 */   public static final String[] DELIMITERS = new String[] { "\r", "\n", "\r\n" };
/*    */   
/* 32 */   private AbstractLineTracker.DelimiterInfo fDelimiterInfo = new AbstractLineTracker.DelimiterInfo();
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String[] getLegalLineDelimiters() {
/* 43 */     return TextUtilities.copy(DELIMITERS);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected AbstractLineTracker.DelimiterInfo nextDelimiterInfo(String text, int offset) {
/* 50 */     int length = text.length();
/* 51 */     for (int i = offset; i < length; i++) {
/*    */       
/* 53 */       char ch = text.charAt(i);
/* 54 */       if (ch == '\r') {
/*    */         
/* 56 */         if (i + 1 < length && 
/* 57 */           text.charAt(i + 1) == '\n') {
/* 58 */           this.fDelimiterInfo.delimiter = DELIMITERS[2];
/* 59 */           this.fDelimiterInfo.delimiterIndex = i;
/* 60 */           this.fDelimiterInfo.delimiterLength = 2;
/* 61 */           return this.fDelimiterInfo;
/*    */         } 
/*    */ 
/*    */         
/* 65 */         this.fDelimiterInfo.delimiter = DELIMITERS[0];
/* 66 */         this.fDelimiterInfo.delimiterIndex = i;
/* 67 */         this.fDelimiterInfo.delimiterLength = 1;
/* 68 */         return this.fDelimiterInfo;
/*    */       } 
/* 70 */       if (ch == '\n') {
/*    */         
/* 72 */         this.fDelimiterInfo.delimiter = DELIMITERS[1];
/* 73 */         this.fDelimiterInfo.delimiterIndex = i;
/* 74 */         this.fDelimiterInfo.delimiterLength = 1;
/* 75 */         return this.fDelimiterInfo;
/*    */       } 
/*    */     } 
/*    */     
/* 79 */     return null;
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.text-3.13.0.jar!\org\eclipse\jface\text\DefaultLineTracker.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */