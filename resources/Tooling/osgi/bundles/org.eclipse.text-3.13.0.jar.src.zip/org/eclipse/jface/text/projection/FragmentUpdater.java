/*     */ package org.eclipse.jface.text.projection;
/*     */ 
/*     */ import org.eclipse.jface.text.BadLocationException;
/*     */ import org.eclipse.jface.text.BadPositionCategoryException;
/*     */ import org.eclipse.jface.text.DefaultPositionUpdater;
/*     */ import org.eclipse.jface.text.DocumentEvent;
/*     */ import org.eclipse.jface.text.IDocument;
/*     */ import org.eclipse.jface.text.Position;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class FragmentUpdater
/*     */   extends DefaultPositionUpdater
/*     */ {
/*     */   private boolean fIsLast = false;
/*     */   
/*     */   protected FragmentUpdater(String fragmentCategory) {
/*  44 */     super(fragmentCategory);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void update(DocumentEvent event) {
/*     */     try {
/*  52 */       Position[] category = event.getDocument().getPositions(getCategory());
/*     */       
/*  54 */       this.fOffset = event.getOffset();
/*  55 */       this.fLength = event.getLength();
/*  56 */       this.fReplaceLength = (event.getText() == null) ? 0 : event.getText().length();
/*  57 */       this.fDocument = event.getDocument();
/*     */       
/*  59 */       for (int i = 0; i < category.length; i++) {
/*     */         
/*  61 */         this.fPosition = category[i];
/*  62 */         this.fIsLast = (i == category.length - 1);
/*     */         
/*  64 */         this.fOriginalPosition.offset = this.fPosition.offset;
/*  65 */         this.fOriginalPosition.length = this.fPosition.length;
/*     */         
/*  67 */         if (notDeleted()) {
/*  68 */           adaptToReplace();
/*     */         }
/*     */       } 
/*  71 */     } catch (BadPositionCategoryException badPositionCategoryException) {}
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void adaptToInsert() {
/*  78 */     int myStart = this.fPosition.offset;
/*  79 */     int myEnd = Math.max(myStart, this.fPosition.offset + this.fPosition.length - ((this.fIsLast || isAffectingReplace()) ? 0 : 1));
/*     */     
/*  81 */     if (myEnd < this.fOffset) {
/*     */       return;
/*     */     }
/*  84 */     if (this.fLength <= 0) {
/*     */       
/*  86 */       if (myStart <= this.fOffset) {
/*  87 */         this.fPosition.length += this.fReplaceLength;
/*     */       } else {
/*  89 */         this.fPosition.offset += this.fReplaceLength;
/*     */       }
/*     */     
/*     */     }
/*  93 */     else if (myStart <= this.fOffset && this.fOriginalPosition.offset <= this.fOffset) {
/*  94 */       this.fPosition.length += this.fReplaceLength;
/*     */     } else {
/*  96 */       this.fPosition.offset += this.fReplaceLength;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean affectsPositions(DocumentEvent event) {
/* 109 */     IDocument document = event.getDocument();
/*     */ 
/*     */     
/* 112 */     try { int index = document.computeIndexInCategory(getCategory(), event.getOffset());
/* 113 */       Position[] fragments = document.getPositions(getCategory());
/*     */       
/* 115 */       if (index > 0) {
/* 116 */         Position fragment = fragments[index - 1];
/* 117 */         if (fragment.overlapsWith(event.getOffset(), event.getLength()))
/* 118 */           return true; 
/* 119 */         if (index == fragments.length && fragment.offset + fragment.length == event.getOffset()) {
/* 120 */           return true;
/*     */         }
/*     */       } 
/* 123 */       if (index < fragments.length) {
/* 124 */         Position fragment = fragments[index];
/* 125 */         return fragment.overlapsWith(event.getOffset(), event.getLength());
/*     */       }
/*     */        }
/* 128 */     catch (BadLocationException badLocationException) {  }
/* 129 */     catch (BadPositionCategoryException badPositionCategoryException) {}
/*     */ 
/*     */     
/* 132 */     return false;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.text-3.13.0.jar!\org\eclipse\jface\text\projection\FragmentUpdater.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */