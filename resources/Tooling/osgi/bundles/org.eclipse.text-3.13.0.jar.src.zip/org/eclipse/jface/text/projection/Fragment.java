/*    */ package org.eclipse.jface.text.projection;
/*    */ 
/*    */ import org.eclipse.jface.text.Position;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Fragment
/*    */   extends Position
/*    */ {
/*    */   public Segment segment;
/*    */   
/*    */   public Fragment(int offset, int length) {
/* 43 */     super(offset, length);
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.text-3.13.0.jar!\org\eclipse\jface\text\projection\Fragment.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */