package org.eclipse.jface.text.link;

public interface ILinkedModeListener {
  public static final int NONE = 0;
  
  public static final int EXIT_ALL = 1;
  
  public static final int UPDATE_CARET = 2;
  
  public static final int SELECT = 4;
  
  public static final int EXTERNAL_MODIFICATION = 8;
  
  void left(LinkedModeModel paramLinkedModeModel, int paramInt);
  
  void suspend(LinkedModeModel paramLinkedModeModel);
  
  void resume(LinkedModeModel paramLinkedModeModel, int paramInt);
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.text-3.13.0.jar!\org\eclipse\jface\text\link\ILinkedModeListener.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */