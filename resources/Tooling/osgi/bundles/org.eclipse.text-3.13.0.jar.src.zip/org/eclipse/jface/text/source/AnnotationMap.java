/*     */ package org.eclipse.jface.text.source;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import org.eclipse.jface.text.Position;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class AnnotationMap
/*     */   implements IAnnotationMap
/*     */ {
/*     */   private Object fLockObject;
/*  43 */   private final Object fInternalLockObject = new Object();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Map<Annotation, Position> fInternalMap;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AnnotationMap(int capacity) {
/*  54 */     this.fInternalMap = new HashMap<>(capacity);
/*     */   }
/*     */ 
/*     */   
/*     */   public synchronized void setLockObject(Object lockObject) {
/*  59 */     this.fLockObject = lockObject;
/*     */   }
/*     */ 
/*     */   
/*     */   public synchronized Object getLockObject() {
/*  64 */     if (this.fLockObject == null)
/*  65 */       return this.fInternalLockObject; 
/*  66 */     return this.fLockObject;
/*     */   }
/*     */ 
/*     */   
/*     */   public Iterator<Position> valuesIterator() {
/*  71 */     synchronized (getLockObject()) {
/*  72 */       return (new ArrayList<>(this.fInternalMap.values())).iterator();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public Iterator<Annotation> keySetIterator() {
/*  78 */     synchronized (getLockObject()) {
/*  79 */       return (new ArrayList<>(this.fInternalMap.keySet())).iterator();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean containsKey(Object annotation) {
/*  85 */     synchronized (getLockObject()) {
/*  86 */       return this.fInternalMap.containsKey(annotation);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public Position put(Annotation annotation, Position position) {
/*  92 */     synchronized (getLockObject()) {
/*  93 */       return this.fInternalMap.put(annotation, position);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public Position get(Object annotation) {
/*  99 */     synchronized (getLockObject()) {
/* 100 */       return this.fInternalMap.get(annotation);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void clear() {
/* 106 */     synchronized (getLockObject()) {
/* 107 */       this.fInternalMap.clear();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public Position remove(Object annotation) {
/* 113 */     synchronized (getLockObject()) {
/* 114 */       return this.fInternalMap.remove(annotation);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public int size() {
/* 120 */     synchronized (getLockObject()) {
/* 121 */       return this.fInternalMap.size();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isEmpty() {
/* 127 */     synchronized (getLockObject()) {
/* 128 */       return this.fInternalMap.isEmpty();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean containsValue(Object value) {
/* 134 */     synchronized (getLockObject()) {
/* 135 */       return this.fInternalMap.containsValue(value);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void putAll(Map<? extends Annotation, ? extends Position> map) {
/* 141 */     synchronized (getLockObject()) {
/* 142 */       this.fInternalMap.putAll(map);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public Set<Map.Entry<Annotation, Position>> entrySet() {
/* 148 */     synchronized (getLockObject()) {
/* 149 */       return this.fInternalMap.entrySet();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public Set<Annotation> keySet() {
/* 155 */     synchronized (getLockObject()) {
/* 156 */       return this.fInternalMap.keySet();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public Collection<Position> values() {
/* 162 */     synchronized (getLockObject()) {
/* 163 */       return this.fInternalMap.values();
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.text-3.13.0.jar!\org\eclipse\jface\text\source\AnnotationMap.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */