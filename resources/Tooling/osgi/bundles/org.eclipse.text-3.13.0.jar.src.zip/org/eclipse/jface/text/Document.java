/*     */ package org.eclipse.jface.text;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Document
/*     */   extends AbstractDocument
/*     */ {
/*     */   public Document() {
/*  52 */     setTextStore(new CopyOnWriteTextStore(new GapTextStore()));
/*  53 */     setLineTracker(new DefaultLineTracker());
/*  54 */     completeInitialization();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Document(String initialContent) {
/*  64 */     setTextStore(new CopyOnWriteTextStore(new GapTextStore()));
/*  65 */     setLineTracker(new DefaultLineTracker());
/*  66 */     getStore().set(initialContent);
/*  67 */     getTracker().set(initialContent);
/*  68 */     completeInitialization();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isLineInformationRepairNeeded(int offset, int length, String text) throws BadLocationException {
/*  73 */     if (offset < 0 || length < 0 || offset + length > getLength()) {
/*  74 */       throw new BadLocationException();
/*     */     }
/*  76 */     return !(!isLineInformationRepairNeeded(text) && !isLineInformationRepairNeeded(get(offset, length)));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean isLineInformationRepairNeeded(String text) {
/*  87 */     if (text == null) {
/*  88 */       return false;
/*     */     }
/*  90 */     int length = text.length();
/*  91 */     if (length == 0) {
/*  92 */       return false;
/*     */     }
/*  94 */     int rIndex = text.indexOf('\r');
/*  95 */     int nIndex = text.indexOf('\n');
/*  96 */     if (rIndex == -1 && nIndex == -1) {
/*  97 */       return false;
/*     */     }
/*  99 */     if (rIndex > 0 && rIndex < length - 1 && nIndex > 1 && rIndex < length - 2) {
/* 100 */       return false;
/*     */     }
/* 102 */     String defaultLD = null;
/*     */     try {
/* 104 */       defaultLD = getLineDelimiter(0);
/* 105 */     } catch (BadLocationException badLocationException) {
/* 106 */       return true;
/*     */     } 
/*     */     
/* 109 */     if (defaultLD == null) {
/* 110 */       return false;
/*     */     }
/* 112 */     defaultLD = getDefaultLineDelimiter();
/*     */     
/* 114 */     if (defaultLD.length() == 1) {
/* 115 */       if (rIndex != -1 && !"\r".equals(defaultLD))
/* 116 */         return true; 
/* 117 */       if (nIndex != -1 && !"\n".equals(defaultLD))
/* 118 */         return true; 
/* 119 */     } else if (defaultLD.length() == 2) {
/* 120 */       return !(rIndex != -1 && nIndex - rIndex == 1);
/*     */     } 
/* 122 */     return false;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.text-3.13.0.jar!\org\eclipse\jface\text\Document.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */