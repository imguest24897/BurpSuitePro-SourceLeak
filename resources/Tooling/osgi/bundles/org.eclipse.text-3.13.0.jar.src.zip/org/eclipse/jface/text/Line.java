/*    */ package org.eclipse.jface.text;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class Line
/*    */   implements IRegion
/*    */ {
/*    */   public int offset;
/*    */   public int length;
/*    */   public final String delimiter;
/*    */   
/*    */   public Line(int offset, int end, String delimiter) {
/* 39 */     this.offset = offset;
/* 40 */     this.length = end - offset + 1;
/* 41 */     this.delimiter = delimiter;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Line(int offset, int length) {
/* 51 */     this.offset = offset;
/* 52 */     this.length = length;
/* 53 */     this.delimiter = null;
/*    */   }
/*    */ 
/*    */   
/*    */   public int getOffset() {
/* 58 */     return this.offset;
/*    */   }
/*    */ 
/*    */   
/*    */   public int getLength() {
/* 63 */     return this.length;
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 68 */     return "Line [offset: " + this.offset + ", length: " + this.length + ", delimiter: '" + this.delimiter + "']";
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.text-3.13.0.jar!\org\eclipse\jface\text\Line.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */