package org.eclipse.jface.text;

public interface IDocumentExtension3 {
  public static final String DEFAULT_PARTITIONING = "__dftl_partitioning";
  
  String[] getPartitionings();
  
  String[] getLegalContentTypes(String paramString) throws BadPartitioningException;
  
  String getContentType(String paramString, int paramInt, boolean paramBoolean) throws BadLocationException, BadPartitioningException;
  
  ITypedRegion getPartition(String paramString, int paramInt, boolean paramBoolean) throws BadLocationException, BadPartitioningException;
  
  ITypedRegion[] computePartitioning(String paramString, int paramInt1, int paramInt2, boolean paramBoolean) throws BadLocationException, BadPartitioningException;
  
  void setDocumentPartitioner(String paramString, IDocumentPartitioner paramIDocumentPartitioner);
  
  IDocumentPartitioner getDocumentPartitioner(String paramString);
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.text-3.13.0.jar!\org\eclipse\jface\text\IDocumentExtension3.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */