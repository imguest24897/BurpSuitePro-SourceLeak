/*    */ package org.eclipse.jface.text;
/*    */ 
/*    */ import java.text.MessageFormat;
/*    */ import java.util.MissingResourceException;
/*    */ import java.util.ResourceBundle;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class TextMessages
/*    */ {
/*    */   private static final String BUNDLE_NAME = "org.eclipse.jface.text.TextMessages";
/* 28 */   private static final ResourceBundle RESOURCE_BUNDLE = ResourceBundle.getBundle("org.eclipse.jface.text.TextMessages");
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static String getString(String key) {
/*    */     try {
/* 35 */       return RESOURCE_BUNDLE.getString(key);
/* 36 */     } catch (MissingResourceException missingResourceException) {
/* 37 */       return String.valueOf('!') + key + '!';
/*    */     } 
/*    */   }
/*    */   
/*    */   public static String getFormattedString(String key, Object arg) {
/* 42 */     return getFormattedString(key, new Object[] { arg });
/*    */   }
/*    */   
/*    */   public static String getFormattedString(String key, Object[] args) {
/* 46 */     return MessageFormat.format(getString(key), args);
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.text-3.13.0.jar!\org\eclipse\jface\text\TextMessages.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */