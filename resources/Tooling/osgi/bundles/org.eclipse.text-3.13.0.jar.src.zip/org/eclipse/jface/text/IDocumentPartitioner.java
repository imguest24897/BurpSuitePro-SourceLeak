package org.eclipse.jface.text;

public interface IDocumentPartitioner {
  void connect(IDocument paramIDocument);
  
  void disconnect();
  
  void documentAboutToBeChanged(DocumentEvent paramDocumentEvent);
  
  boolean documentChanged(DocumentEvent paramDocumentEvent);
  
  String[] getLegalContentTypes();
  
  String getContentType(int paramInt);
  
  ITypedRegion[] computePartitioning(int paramInt1, int paramInt2);
  
  ITypedRegion getPartition(int paramInt);
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.text-3.13.0.jar!\org\eclipse\jface\text\IDocumentPartitioner.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */