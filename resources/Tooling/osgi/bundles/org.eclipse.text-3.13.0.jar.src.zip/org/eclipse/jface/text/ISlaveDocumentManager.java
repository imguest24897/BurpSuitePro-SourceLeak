package org.eclipse.jface.text;

public interface ISlaveDocumentManager {
  IDocument createSlaveDocument(IDocument paramIDocument);
  
  void freeSlaveDocument(IDocument paramIDocument);
  
  IDocumentInformationMapping createMasterSlaveMapping(IDocument paramIDocument);
  
  IDocument getMasterDocument(IDocument paramIDocument);
  
  boolean isSlaveDocument(IDocument paramIDocument);
  
  void setAutoExpandMode(IDocument paramIDocument, boolean paramBoolean);
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.text-3.13.0.jar!\org\eclipse\jface\text\ISlaveDocumentManager.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */