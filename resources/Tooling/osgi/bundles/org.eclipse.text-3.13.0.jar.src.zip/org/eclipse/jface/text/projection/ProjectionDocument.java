/*     */ package org.eclipse.jface.text.projection;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.eclipse.jface.text.AbstractDocument;
/*     */ import org.eclipse.jface.text.BadLocationException;
/*     */ import org.eclipse.jface.text.BadPositionCategoryException;
/*     */ import org.eclipse.jface.text.DefaultLineTracker;
/*     */ import org.eclipse.jface.text.DocumentEvent;
/*     */ import org.eclipse.jface.text.IDocument;
/*     */ import org.eclipse.jface.text.IDocumentExtension;
/*     */ import org.eclipse.jface.text.IDocumentInformationMapping;
/*     */ import org.eclipse.jface.text.IDocumentListener;
/*     */ import org.eclipse.jface.text.ILineTracker;
/*     */ import org.eclipse.jface.text.IPositionUpdater;
/*     */ import org.eclipse.jface.text.IRegion;
/*     */ import org.eclipse.jface.text.ITextStore;
/*     */ import org.eclipse.jface.text.Position;
/*     */ import org.eclipse.jface.text.Region;
/*     */ import org.eclipse.jface.text.TextUtilities;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ProjectionDocument
/*     */   extends AbstractDocument
/*     */ {
/*     */   private static final String FRAGMENTS_CATEGORY_PREFIX = "__fragmentsCategory";
/*     */   private static final String SEGMENTS_CATEGORY = "__segmentsCategory";
/*     */   private IDocument fMasterDocument;
/*     */   private IDocumentExtension fMasterDocumentExtension;
/*     */   private String fFragmentsCategory;
/*     */   private String fSegmentsCategory;
/*     */   private DocumentEvent fMasterEvent;
/*     */   private ProjectionDocumentEvent fSlaveEvent;
/*     */   private DocumentEvent fOriginalEvent;
/*     */   private boolean fIsUpdating = false;
/*     */   private boolean fIsAutoExpanding = false;
/*     */   private SegmentUpdater fSegmentUpdater;
/*     */   private FragmentUpdater fFragmentsUpdater;
/*     */   private ProjectionMapping fMapping;
/*     */   
/*     */   public ProjectionDocument(IDocument masterDocument) {
/* 117 */     this.fMasterDocument = masterDocument;
/* 118 */     if (this.fMasterDocument instanceof IDocumentExtension) {
/* 119 */       this.fMasterDocumentExtension = (IDocumentExtension)this.fMasterDocument;
/*     */     }
/* 121 */     this.fSegmentsCategory = "__segmentsCategory";
/* 122 */     this.fFragmentsCategory = "__fragmentsCategory" + hashCode();
/* 123 */     this.fMasterDocument.addPositionCategory(this.fFragmentsCategory);
/* 124 */     this.fFragmentsUpdater = new FragmentUpdater(this.fFragmentsCategory);
/* 125 */     this.fMasterDocument.addPositionUpdater((IPositionUpdater)this.fFragmentsUpdater);
/*     */     
/* 127 */     this.fMapping = new ProjectionMapping(masterDocument, this.fFragmentsCategory, (IDocument)this, this.fSegmentsCategory);
/*     */     
/* 129 */     ITextStore s = new ProjectionTextStore(masterDocument, this.fMapping);
/* 130 */     DefaultLineTracker defaultLineTracker = new DefaultLineTracker();
/*     */     
/* 132 */     setTextStore(s);
/* 133 */     setLineTracker((ILineTracker)defaultLineTracker);
/*     */     
/* 135 */     completeInitialization();
/*     */     
/* 137 */     initializeProjection();
/* 138 */     defaultLineTracker.set(s.get(0, s.getLength()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void dispose() {
/* 145 */     this.fMasterDocument.removePositionUpdater((IPositionUpdater)this.fFragmentsUpdater);
/*     */     try {
/* 147 */       this.fMasterDocument.removePositionCategory(this.fFragmentsCategory);
/* 148 */     } catch (BadPositionCategoryException badPositionCategoryException) {}
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void internalError() {
/* 154 */     throw new IllegalStateException();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final Position[] getFragments() {
/*     */     try {
/* 164 */       return this.fMasterDocument.getPositions(this.fFragmentsCategory);
/* 165 */     } catch (BadPositionCategoryException badPositionCategoryException) {
/* 166 */       internalError();
/*     */ 
/*     */       
/* 169 */       return null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final Position[] getSegments() {
/*     */     try {
/* 179 */       return getPositions(this.fSegmentsCategory);
/* 180 */     } catch (BadPositionCategoryException badPositionCategoryException) {
/* 181 */       internalError();
/*     */ 
/*     */       
/* 184 */       return null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public ProjectionMapping getProjectionMapping() {
/* 195 */     return this.fMapping;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IDocumentInformationMapping getDocumentInformationMapping() {
/* 205 */     return this.fMapping;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IDocument getMasterDocument() {
/* 214 */     return this.fMasterDocument;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getDefaultLineDelimiter() {
/* 219 */     return TextUtilities.getDefaultLineDelimiter(this.fMasterDocument);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void initializeProjection() {
/*     */     try {
/* 230 */       addPositionCategory(this.fSegmentsCategory);
/* 231 */       this.fSegmentUpdater = new SegmentUpdater(this.fSegmentsCategory);
/* 232 */       addPositionUpdater((IPositionUpdater)this.fSegmentUpdater);
/*     */       
/* 234 */       int offset = 0;
/* 235 */       Position[] fragments = getFragments(); byte b; int i; Position[] arrayOfPosition1;
/* 236 */       for (i = (arrayOfPosition1 = fragments).length, b = 0; b < i; ) { Position f = arrayOfPosition1[b];
/* 237 */         Fragment fragment = (Fragment)f;
/* 238 */         Segment segment = new Segment(offset, fragment.getLength());
/* 239 */         segment.fragment = fragment;
/* 240 */         addPosition(this.fSegmentsCategory, segment);
/* 241 */         offset += fragment.length;
/*     */         b++; }
/*     */     
/* 244 */     } catch (BadPositionCategoryException badPositionCategoryException) {
/* 245 */       internalError();
/* 246 */     } catch (BadLocationException badLocationException) {
/* 247 */       internalError();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Segment createSegmentFor(Fragment fragment, int index) throws BadLocationException, BadPositionCategoryException {
/* 262 */     int offset = 0;
/* 263 */     if (index > 0) {
/* 264 */       Position[] segments = getSegments();
/* 265 */       Segment segment1 = (Segment)segments[index - 1];
/* 266 */       offset = segment1.getOffset() + segment1.getLength();
/*     */     } 
/*     */     
/* 269 */     Segment segment = new Segment(offset, 0);
/* 270 */     segment.fragment = fragment;
/* 271 */     fragment.segment = segment;
/* 272 */     addPosition(this.fSegmentsCategory, segment);
/* 273 */     return segment;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void internalAddMasterDocumentRange(int offsetInMaster, int lengthInMaster, DocumentEvent masterDocumentEvent) throws BadLocationException {
/* 287 */     if (lengthInMaster == 0) {
/*     */       return;
/*     */     }
/*     */     
/*     */     try {
/* 292 */       Position[] fragments = getFragments();
/* 293 */       int index = this.fMasterDocument.computeIndexInCategory(this.fFragmentsCategory, offsetInMaster);
/*     */       
/* 295 */       Fragment left = null;
/* 296 */       Fragment right = null;
/*     */       
/* 298 */       if (index < fragments.length) {
/* 299 */         Fragment fragment = (Fragment)fragments[index];
/* 300 */         if (offsetInMaster == fragment.offset)
/* 301 */           if (fragment.length == 0) {
/* 302 */             left = fragment;
/*     */           } else {
/* 304 */             throw new IllegalArgumentException("overlaps with existing fragment");
/* 305 */           }   if (offsetInMaster + lengthInMaster == fragment.offset) {
/* 306 */           right = fragment;
/*     */         }
/*     */       } 
/* 309 */       if (index > 0 && index <= fragments.length) {
/* 310 */         Fragment fragment = (Fragment)fragments[index - 1];
/* 311 */         if (fragment.includes(offsetInMaster))
/* 312 */           throw new IllegalArgumentException("overlaps with existing fragment"); 
/* 313 */         if (fragment.getOffset() + fragment.getLength() == offsetInMaster) {
/* 314 */           left = fragment;
/*     */         }
/*     */       } 
/* 317 */       int offsetInSlave = 0;
/* 318 */       if (index > 0) {
/* 319 */         Fragment fragment = (Fragment)fragments[index - 1];
/* 320 */         Segment segment = fragment.segment;
/* 321 */         offsetInSlave = segment.getOffset() + segment.getLength();
/*     */       } 
/*     */       
/* 324 */       ProjectionDocumentEvent event = new ProjectionDocumentEvent((IDocument)this, offsetInSlave, 0, this.fMasterDocument.get(offsetInMaster, lengthInMaster), offsetInMaster, lengthInMaster, masterDocumentEvent);
/* 325 */       super.fireDocumentAboutToBeChanged((DocumentEvent)event);
/*     */ 
/*     */       
/* 328 */       if (left != null && right != null) {
/*     */         
/* 330 */         int endOffset = right.getOffset() + right.getLength();
/* 331 */         left.setLength(endOffset - left.getOffset());
/* 332 */         left.segment.setLength(left.segment.getLength() + right.segment.getLength());
/*     */         
/* 334 */         removePosition(this.fSegmentsCategory, right.segment);
/* 335 */         this.fMasterDocument.removePosition(this.fFragmentsCategory, right);
/*     */       }
/* 337 */       else if (left != null) {
/* 338 */         int endOffset = offsetInMaster + lengthInMaster;
/* 339 */         left.setLength(endOffset - left.getOffset());
/* 340 */         left.segment.markForStretch();
/*     */       }
/* 342 */       else if (right != null) {
/* 343 */         right.setOffset(right.getOffset() - lengthInMaster);
/* 344 */         right.setLength(right.getLength() + lengthInMaster);
/* 345 */         right.segment.markForStretch();
/*     */       }
/*     */       else {
/*     */         
/* 349 */         Fragment fragment = new Fragment(offsetInMaster, lengthInMaster);
/* 350 */         this.fMasterDocument.addPosition(this.fFragmentsCategory, fragment);
/* 351 */         Segment segment = createSegmentFor(fragment, index);
/* 352 */         segment.markForStretch();
/*     */       } 
/*     */       
/* 355 */       getTracker().replace(event.getOffset(), event.getLength(), event.getText());
/* 356 */       super.fireDocumentChanged((DocumentEvent)event);
/*     */     }
/* 358 */     catch (BadPositionCategoryException badPositionCategoryException) {
/* 359 */       internalError();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Fragment findFragment(int offsetInMaster, int lengthInMaster) {
/* 371 */     Position[] fragments = getFragments(); byte b; int i; Position[] arrayOfPosition1;
/* 372 */     for (i = (arrayOfPosition1 = fragments).length, b = 0; b < i; ) { Position fragment = arrayOfPosition1[b];
/* 373 */       Fragment f = (Fragment)fragment;
/* 374 */       if (f.getOffset() <= offsetInMaster && offsetInMaster + lengthInMaster <= f.getOffset() + f.getLength())
/* 375 */         return f;  b++; }
/*     */     
/* 377 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void internalRemoveMasterDocumentRange(int offsetInMaster, int lengthInMaster) throws BadLocationException {
/*     */     try {
/* 396 */       IRegion imageRegion = this.fMapping.toExactImageRegion((IRegion)new Region(offsetInMaster, lengthInMaster));
/* 397 */       if (imageRegion == null) {
/* 398 */         throw new IllegalArgumentException();
/*     */       }
/* 400 */       Fragment fragment = findFragment(offsetInMaster, lengthInMaster);
/* 401 */       if (fragment == null) {
/* 402 */         throw new IllegalArgumentException();
/*     */       }
/* 404 */       ProjectionDocumentEvent event = new ProjectionDocumentEvent((IDocument)this, imageRegion.getOffset(), imageRegion.getLength(), "", offsetInMaster, lengthInMaster);
/* 405 */       super.fireDocumentAboutToBeChanged((DocumentEvent)event);
/*     */       
/* 407 */       if (fragment.getOffset() == offsetInMaster) {
/* 408 */         fragment.setOffset(offsetInMaster + lengthInMaster);
/* 409 */         fragment.setLength(fragment.getLength() - lengthInMaster);
/*     */       
/*     */       }
/*     */       else {
/*     */         
/* 414 */         Fragment newFragment = new Fragment(offsetInMaster, lengthInMaster);
/* 415 */         Segment segment = new Segment(imageRegion.getOffset(), imageRegion.getLength());
/* 416 */         newFragment.segment = segment;
/* 417 */         segment.fragment = newFragment;
/* 418 */         this.fMasterDocument.addPosition(this.fFragmentsCategory, newFragment);
/* 419 */         addPosition(this.fSegmentsCategory, segment);
/*     */ 
/*     */         
/* 422 */         int offset = offsetInMaster + lengthInMaster;
/* 423 */         newFragment = new Fragment(offset, fragment.getOffset() + fragment.getLength() - offset);
/* 424 */         offset = imageRegion.getOffset() + imageRegion.getLength();
/* 425 */         segment = new Segment(offset, fragment.segment.getOffset() + fragment.segment.getLength() - offset);
/* 426 */         newFragment.segment = segment;
/* 427 */         segment.fragment = newFragment;
/* 428 */         this.fMasterDocument.addPosition(this.fFragmentsCategory, newFragment);
/* 429 */         addPosition(this.fSegmentsCategory, segment);
/*     */ 
/*     */         
/* 432 */         fragment.setLength(offsetInMaster - fragment.getOffset());
/* 433 */         fragment.segment.setLength(imageRegion.getOffset() - fragment.segment.getOffset());
/*     */       } 
/*     */       
/* 436 */       getTracker().replace(event.getOffset(), event.getLength(), event.getText());
/* 437 */       super.fireDocumentChanged((DocumentEvent)event);
/*     */     }
/* 439 */     catch (BadPositionCategoryException badPositionCategoryException) {
/* 440 */       internalError();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final IRegion[] computeUnprojectedMasterRegions(int offsetInMaster, int lengthInMaster) throws BadLocationException {
/* 458 */     IRegion[] fragments = null;
/* 459 */     IRegion imageRegion = this.fMapping.toImageRegion((IRegion)new Region(offsetInMaster, lengthInMaster));
/* 460 */     if (imageRegion != null) {
/* 461 */       fragments = this.fMapping.toExactOriginRegions(imageRegion);
/*     */     }
/* 463 */     if (fragments == null || fragments.length == 0) {
/* 464 */       return new IRegion[] { (IRegion)new Region(offsetInMaster, lengthInMaster) };
/*     */     }
/* 466 */     List<Region> gaps = new ArrayList<>();
/*     */     
/* 468 */     IRegion region = fragments[0];
/* 469 */     if (offsetInMaster < region.getOffset()) {
/* 470 */       gaps.add(new Region(offsetInMaster, region.getOffset() - offsetInMaster));
/*     */     }
/* 472 */     for (int i = 0; i < fragments.length - 1; i++) {
/* 473 */       IRegion left = fragments[i];
/* 474 */       IRegion right = fragments[i + 1];
/* 475 */       int j = left.getOffset() + left.getLength();
/* 476 */       if (j < right.getOffset()) {
/* 477 */         gaps.add(new Region(j, right.getOffset() - j));
/*     */       }
/*     */     } 
/* 480 */     region = fragments[fragments.length - 1];
/* 481 */     int leftEnd = region.getOffset() + region.getLength();
/* 482 */     int rightEnd = offsetInMaster + lengthInMaster;
/* 483 */     if (leftEnd < rightEnd) {
/* 484 */       gaps.add(new Region(leftEnd, rightEnd - leftEnd));
/*     */     }
/* 486 */     IRegion[] result = new IRegion[gaps.size()];
/* 487 */     gaps.toArray(result);
/* 488 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private IRegion computeFirstUnprojectedMasterRegion(int offsetInMaster, int lengthInMaster) throws BadLocationException {
/* 505 */     IRegion[] fragments = null;
/* 506 */     IRegion imageRegion = this.fMapping.toImageRegion((IRegion)new Region(offsetInMaster, lengthInMaster));
/* 507 */     if (imageRegion != null) {
/* 508 */       fragments = this.fMapping.toExactOriginRegions(imageRegion);
/*     */     }
/* 510 */     if (fragments == null || fragments.length == 0) {
/* 511 */       return (IRegion)new Region(offsetInMaster, lengthInMaster);
/*     */     }
/* 513 */     IRegion region = fragments[0];
/* 514 */     if (offsetInMaster < region.getOffset()) {
/* 515 */       return (IRegion)new Region(offsetInMaster, region.getOffset() - offsetInMaster);
/*     */     }
/* 517 */     for (int i = 0; i < fragments.length - 1; i++) {
/* 518 */       IRegion left = fragments[i];
/* 519 */       IRegion right = fragments[i + 1];
/* 520 */       int j = left.getOffset() + left.getLength();
/* 521 */       if (j < right.getOffset()) {
/* 522 */         return (IRegion)new Region(j, right.getOffset() - j);
/*     */       }
/*     */     } 
/* 525 */     region = fragments[fragments.length - 1];
/* 526 */     int leftEnd = region.getOffset() + region.getLength();
/* 527 */     int rightEnd = offsetInMaster + lengthInMaster;
/* 528 */     if (leftEnd < rightEnd) {
/* 529 */       return (IRegion)new Region(leftEnd, rightEnd - leftEnd);
/*     */     }
/* 531 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addMasterDocumentRange(int offsetInMaster, int lengthInMaster) throws BadLocationException {
/* 543 */     addMasterDocumentRange(offsetInMaster, lengthInMaster, (DocumentEvent)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void addMasterDocumentRange(int offsetInMaster, int lengthInMaster, DocumentEvent masterDocumentEvent) throws BadLocationException {
/* 566 */     int limit = Math.max((getFragments()).length * 2, 20);
/*     */     while (true) {
/* 568 */       if (limit-- < 0) {
/* 569 */         throw new IllegalArgumentException("safety loop termination");
/*     */       }
/* 571 */       IRegion gap = computeFirstUnprojectedMasterRegion(offsetInMaster, lengthInMaster);
/* 572 */       if (gap == null) {
/*     */         return;
/*     */       }
/* 575 */       internalAddMasterDocumentRange(gap.getOffset(), gap.getLength(), masterDocumentEvent);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void removeMasterDocumentRange(int offsetInMaster, int lengthInMaster) throws BadLocationException {
/* 588 */     IRegion[] fragments = computeProjectedMasterRegions(offsetInMaster, lengthInMaster);
/* 589 */     if (fragments == null || fragments.length == 0)
/*     */       return;  byte b; int i;
/*     */     IRegion[] arrayOfIRegion1;
/* 592 */     for (i = (arrayOfIRegion1 = fragments).length, b = 0; b < i; ) { IRegion fragment = arrayOfIRegion1[b];
/* 593 */       internalRemoveMasterDocumentRange(fragment.getOffset(), fragment.getLength());
/*     */       b++; }
/*     */   
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final IRegion[] computeProjectedMasterRegions(int offsetInMaster, int lengthInMaster) throws BadLocationException {
/* 608 */     IRegion imageRegion = this.fMapping.toImageRegion((IRegion)new Region(offsetInMaster, lengthInMaster));
/* 609 */     return (imageRegion != null) ? this.fMapping.toExactOriginRegions(imageRegion) : null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean isUpdating() {
/* 618 */     return this.fIsUpdating;
/*     */   }
/*     */ 
/*     */   
/*     */   public void replace(int offset, int length, String text) throws BadLocationException {
/*     */     try {
/* 624 */       this.fIsUpdating = true;
/* 625 */       if (this.fMasterDocumentExtension != null)
/* 626 */         this.fMasterDocumentExtension.stopPostNotificationProcessing(); 
/* 627 */       super.replace(offset, length, text);
/*     */     } finally {
/* 629 */       this.fIsUpdating = false;
/* 630 */       if (this.fMasterDocumentExtension != null) {
/* 631 */         this.fMasterDocumentExtension.resumePostNotificationProcessing();
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   public void set(String text) {
/*     */     try {
/* 638 */       this.fIsUpdating = true;
/* 639 */       if (this.fMasterDocumentExtension != null) {
/* 640 */         this.fMasterDocumentExtension.stopPostNotificationProcessing();
/*     */       }
/* 642 */       super.set(text);
/*     */     } finally {
/*     */       
/* 645 */       this.fIsUpdating = false;
/* 646 */       if (this.fMasterDocumentExtension != null) {
/* 647 */         this.fMasterDocumentExtension.resumePostNotificationProcessing();
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ProjectionDocumentEvent normalize(DocumentEvent masterEvent) throws BadLocationException {
/* 660 */     if (!isUpdating()) {
/* 661 */       IRegion imageRegion = this.fMapping.toExactImageRegion((IRegion)new Region(masterEvent.getOffset(), masterEvent.getLength()));
/* 662 */       if (imageRegion != null)
/* 663 */         return new ProjectionDocumentEvent((IDocument)this, imageRegion.getOffset(), imageRegion.getLength(), masterEvent.getText(), masterEvent); 
/* 664 */       return null;
/*     */     } 
/*     */     
/* 667 */     ProjectionDocumentEvent event = new ProjectionDocumentEvent((IDocument)this, this.fOriginalEvent.getOffset(), this.fOriginalEvent.getLength(), this.fOriginalEvent.getText(), masterEvent);
/* 668 */     this.fOriginalEvent = null;
/* 669 */     return event;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final boolean adaptProjectionToMasterChange(DocumentEvent masterEvent) throws BadLocationException {
/* 681 */     if ((!isUpdating() && this.fFragmentsUpdater.affectsPositions(masterEvent)) || (this.fIsAutoExpanding && masterEvent.getLength() > 0)) {
/*     */       
/* 683 */       addMasterDocumentRange(masterEvent.getOffset(), masterEvent.getLength(), masterEvent);
/* 684 */       return true;
/*     */     } 
/* 686 */     if (this.fMapping.getImageLength() == 0 && masterEvent.getLength() == 0) {
/*     */       
/* 688 */       Position[] fragments = getFragments();
/* 689 */       if (fragments.length == 0) {
/*     */         
/*     */         try {
/*     */           
/* 693 */           Fragment fragment = new Fragment(0, 0);
/* 694 */           this.fMasterDocument.addPosition(this.fFragmentsCategory, fragment);
/* 695 */           createSegmentFor(fragment, 0);
/* 696 */         } catch (BadPositionCategoryException badPositionCategoryException) {
/* 697 */           internalError();
/*     */         } 
/*     */       }
/*     */     } 
/*     */     
/* 702 */     return isUpdating();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void masterDocumentAboutToBeChanged(DocumentEvent masterEvent) {
/*     */     try {
/* 716 */       boolean assertNotNull = adaptProjectionToMasterChange(masterEvent);
/* 717 */       this.fSlaveEvent = normalize(masterEvent);
/* 718 */       if (assertNotNull && this.fSlaveEvent == null) {
/* 719 */         internalError();
/*     */       }
/* 721 */       this.fMasterEvent = masterEvent;
/* 722 */       if (this.fSlaveEvent != null) {
/* 723 */         delayedFireDocumentAboutToBeChanged();
/*     */       }
/* 725 */     } catch (BadLocationException badLocationException) {
/* 726 */       internalError();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void masterDocumentChanged(DocumentEvent masterEvent) {
/* 738 */     if (!isUpdating() && masterEvent == this.fMasterEvent) {
/* 739 */       if (this.fSlaveEvent != null) {
/*     */         try {
/* 741 */           getTracker().replace(this.fSlaveEvent.getOffset(), this.fSlaveEvent.getLength(), this.fSlaveEvent.getText());
/* 742 */           fireDocumentChanged((DocumentEvent)this.fSlaveEvent);
/* 743 */         } catch (BadLocationException badLocationException) {
/* 744 */           internalError();
/*     */         } 
/* 746 */       } else if (ensureWellFormedSegmentation(masterEvent.getOffset())) {
/* 747 */         this.fMapping.projectionChanged();
/*     */       } 
/*     */     }
/*     */   }
/*     */   
/*     */   protected void fireDocumentAboutToBeChanged(DocumentEvent event) {
/* 753 */     this.fOriginalEvent = event;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void delayedFireDocumentAboutToBeChanged() {
/* 762 */     super.fireDocumentAboutToBeChanged((DocumentEvent)this.fSlaveEvent);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void fireDocumentChanged(DocumentEvent event) {
/* 772 */     super.fireDocumentChanged((DocumentEvent)this.fSlaveEvent);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void updateDocumentStructures(DocumentEvent event) {
/* 777 */     super.updateDocumentStructures(event);
/* 778 */     ensureWellFormedSegmentation(computeAnchor(event));
/* 779 */     this.fMapping.projectionChanged();
/*     */   }
/*     */   
/*     */   private int computeAnchor(DocumentEvent event) {
/* 783 */     if (event instanceof ProjectionDocumentEvent) {
/* 784 */       ProjectionDocumentEvent slave = (ProjectionDocumentEvent)event;
/* 785 */       Object changeType = slave.getChangeType();
/* 786 */       if (ProjectionDocumentEvent.CONTENT_CHANGE == changeType) {
/* 787 */         DocumentEvent master = slave.getMasterEvent();
/* 788 */         if (master != null)
/* 789 */           return master.getOffset(); 
/* 790 */       } else if (ProjectionDocumentEvent.PROJECTION_CHANGE == changeType) {
/* 791 */         return slave.getMasterOffset();
/*     */       } 
/*     */     } 
/* 794 */     return -1;
/*     */   }
/*     */   
/*     */   private boolean ensureWellFormedSegmentation(int anchorOffset) {
/* 798 */     boolean changed = false;
/* 799 */     Position[] segments = getSegments();
/* 800 */     for (int i = 0; i < segments.length; i++) {
/* 801 */       Segment segment = (Segment)segments[i];
/* 802 */       if (segment.isDeleted() || (segment.getLength() == 0 && (i < segments.length - 1 || (i > 0 && segments[i - 1].isDeleted())))) {
/*     */         try {
/* 804 */           removePosition(this.fSegmentsCategory, segment);
/* 805 */           this.fMasterDocument.removePosition(this.fFragmentsCategory, segment.fragment);
/* 806 */           changed = true;
/* 807 */         } catch (BadPositionCategoryException badPositionCategoryException) {
/* 808 */           internalError();
/*     */         } 
/* 810 */       } else if (i < segments.length - 1) {
/* 811 */         Segment next = (Segment)segments[i + 1];
/* 812 */         if (!next.isDeleted() && next.getLength() != 0) {
/*     */           
/* 814 */           Fragment fragment = segment.fragment;
/* 815 */           if (fragment.getOffset() + fragment.getLength() == next.fragment.getOffset()) {
/*     */             
/* 817 */             segment.setLength(segment.getLength() + next.getLength());
/* 818 */             fragment.setLength(fragment.getLength() + next.fragment.getLength());
/* 819 */             next.delete();
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/* 824 */     if (changed && anchorOffset != -1) {
/* 825 */       Position[] changedSegments = getSegments();
/* 826 */       if (changedSegments == null || changedSegments.length == 0) {
/* 827 */         Fragment fragment = new Fragment(anchorOffset, 0);
/*     */         try {
/* 829 */           this.fMasterDocument.addPosition(this.fFragmentsCategory, fragment);
/* 830 */           createSegmentFor(fragment, 0);
/* 831 */         } catch (BadLocationException badLocationException) {
/* 832 */           internalError();
/* 833 */         } catch (BadPositionCategoryException badPositionCategoryException) {
/* 834 */           internalError();
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 839 */     return changed;
/*     */   }
/*     */ 
/*     */   
/*     */   public void registerPostNotificationReplace(IDocumentListener owner, IDocumentExtension.IReplace replace) {
/* 844 */     if (!isUpdating())
/* 845 */       throw new UnsupportedOperationException(); 
/* 846 */     super.registerPostNotificationReplace(owner, replace);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAutoExpandMode(boolean autoExpandMode) {
/* 855 */     this.fIsAutoExpanding = autoExpandMode;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void replaceMasterDocumentRanges(int offsetInMaster, int lengthInMaster) throws BadLocationException {
/*     */     try {
/* 868 */       ProjectionDocumentEvent event = new ProjectionDocumentEvent((IDocument)this, 0, this.fMapping.getImageLength(), this.fMasterDocument.get(offsetInMaster, lengthInMaster), offsetInMaster, lengthInMaster);
/* 869 */       super.fireDocumentAboutToBeChanged((DocumentEvent)event);
/*     */       
/* 871 */       Position[] fragments = getFragments(); byte b; int i; Position[] arrayOfPosition1;
/* 872 */       for (i = (arrayOfPosition1 = fragments).length, b = 0; b < i; ) { Position fragment1 = arrayOfPosition1[b];
/* 873 */         Fragment fragment2 = (Fragment)fragment1;
/* 874 */         this.fMasterDocument.removePosition(this.fFragmentsCategory, fragment2);
/* 875 */         removePosition(this.fSegmentsCategory, fragment2.segment);
/*     */         b++; }
/*     */       
/* 878 */       Fragment fragment = new Fragment(offsetInMaster, lengthInMaster);
/* 879 */       Segment segment = new Segment(0, 0);
/* 880 */       segment.fragment = fragment;
/* 881 */       fragment.segment = segment;
/* 882 */       this.fMasterDocument.addPosition(this.fFragmentsCategory, fragment);
/* 883 */       addPosition(this.fSegmentsCategory, segment);
/*     */       
/* 885 */       getTracker().set(this.fMasterDocument.get(offsetInMaster, lengthInMaster));
/* 886 */       super.fireDocumentChanged((DocumentEvent)event);
/*     */     }
/* 888 */     catch (BadPositionCategoryException badPositionCategoryException) {
/* 889 */       internalError();
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.text-3.13.0.jar!\org\eclipse\jface\text\projection\ProjectionDocument.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */