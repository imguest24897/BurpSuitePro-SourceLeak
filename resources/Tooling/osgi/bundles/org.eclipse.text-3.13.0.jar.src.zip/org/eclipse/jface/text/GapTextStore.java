/*     */ package org.eclipse.jface.text;
/*     */ 
/*     */ import org.eclipse.core.runtime.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class GapTextStore
/*     */   implements ITextStore
/*     */ {
/*     */   private final int fMinGapSize;
/*     */   private final int fMaxGapSize;
/*     */   private final float fSizeMultiplier;
/*  62 */   private char[] fContent = new char[0];
/*     */   
/*  64 */   private int fGapStart = 0;
/*     */   
/*  66 */   private int fGapEnd = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  72 */   private int fThreshold = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public GapTextStore(int lowWatermark, int highWatermark) {
/*  98 */     this(highWatermark / 2, highWatermark / 2, 0.0F);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public GapTextStore() {
/* 108 */     this(256, 4096, 0.1F);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public GapTextStore(int minSize, int maxSize, float maxGapFactor) {
/* 137 */     Assert.isLegal((0.0F <= maxGapFactor && maxGapFactor <= 1.0F));
/* 138 */     Assert.isLegal((minSize >= 0 && minSize <= maxSize));
/* 139 */     this.fMinGapSize = minSize;
/* 140 */     this.fMaxGapSize = maxSize;
/* 141 */     this.fSizeMultiplier = 1.0F / (1.0F - maxGapFactor / 2.0F);
/*     */   }
/*     */ 
/*     */   
/*     */   public final char get(int offset) {
/* 146 */     if (offset < this.fGapStart) {
/* 147 */       return this.fContent[offset];
/*     */     }
/* 149 */     return this.fContent[offset + gapSize()];
/*     */   }
/*     */ 
/*     */   
/*     */   public final String get(int offset, int length) {
/* 154 */     if (this.fGapStart <= offset) {
/* 155 */       return new String(this.fContent, offset + gapSize(), length);
/*     */     }
/* 157 */     int end = offset + length;
/*     */     
/* 159 */     if (end <= this.fGapStart) {
/* 160 */       return new String(this.fContent, offset, length);
/*     */     }
/* 162 */     StringBuilder buf = new StringBuilder(length);
/* 163 */     buf.append(this.fContent, offset, this.fGapStart - offset);
/* 164 */     buf.append(this.fContent, this.fGapEnd, end - this.fGapStart);
/* 165 */     return buf.toString();
/*     */   }
/*     */ 
/*     */   
/*     */   public final int getLength() {
/* 170 */     return this.fContent.length - gapSize();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void set(String text) {
/* 181 */     replace(0, getLength(), text);
/*     */   }
/*     */ 
/*     */   
/*     */   public final void replace(int offset, int length, String text) {
/* 186 */     if (text == null) {
/* 187 */       adjustGap(offset, length, 0);
/*     */     } else {
/* 189 */       int textLength = text.length();
/* 190 */       adjustGap(offset, length, textLength);
/* 191 */       if (textLength != 0) {
/* 192 */         text.getChars(0, textLength, this.fContent, offset);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void adjustGap(int offset, int remove, int add) {
/* 207 */     int newGapEnd, oldGapSize = gapSize();
/* 208 */     int newGapSize = oldGapSize - add + remove;
/* 209 */     boolean reuseArray = (newGapSize >= 0 && newGapSize <= this.fThreshold);
/*     */     
/* 211 */     int newGapStart = offset + add;
/*     */ 
/*     */     
/* 214 */     if (reuseArray) {
/* 215 */       newGapEnd = moveGap(offset, remove, oldGapSize, newGapSize, newGapStart);
/*     */     } else {
/* 217 */       newGapEnd = reallocate(offset, remove, oldGapSize, newGapSize, newGapStart);
/*     */     } 
/* 219 */     this.fGapStart = newGapStart;
/* 220 */     this.fGapEnd = newGapEnd;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int moveGap(int offset, int remove, int oldGapSize, int newGapSize, int newGapStart) {
/* 239 */     int newGapEnd = newGapStart + newGapSize;
/* 240 */     if (offset < this.fGapStart) {
/* 241 */       int afterRemove = offset + remove;
/* 242 */       if (afterRemove < this.fGapStart) {
/* 243 */         int betweenSize = this.fGapStart - afterRemove;
/* 244 */         arrayCopy(afterRemove, this.fContent, newGapEnd, betweenSize);
/*     */       } 
/*     */     } else {
/*     */       
/* 248 */       int offsetShifted = offset + oldGapSize;
/* 249 */       int betweenSize = offsetShifted - this.fGapEnd;
/* 250 */       arrayCopy(this.fGapEnd, this.fContent, this.fGapStart, betweenSize);
/*     */     } 
/* 252 */     return newGapEnd;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int reallocate(int offset, int remove, int oldGapSize, int newGapSize, int newGapStart) {
/* 268 */     int newLength = this.fContent.length - newGapSize;
/*     */     
/* 270 */     int newArraySize = (int)(newLength * this.fSizeMultiplier);
/* 271 */     newGapSize = newArraySize - newLength;
/*     */ 
/*     */     
/* 274 */     if (newGapSize < this.fMinGapSize) {
/* 275 */       newGapSize = this.fMinGapSize;
/* 276 */       newArraySize = newLength + newGapSize;
/* 277 */     } else if (newGapSize > this.fMaxGapSize) {
/* 278 */       newGapSize = this.fMaxGapSize;
/* 279 */       newArraySize = newLength + newGapSize;
/*     */     } 
/*     */ 
/*     */     
/* 283 */     this.fThreshold = newGapSize * 2;
/* 284 */     char[] newContent = allocate(newArraySize);
/* 285 */     int newGapEnd = newGapStart + newGapSize;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 294 */     if (offset < this.fGapStart) {
/*     */       
/* 296 */       arrayCopy(0, newContent, 0, offset);
/* 297 */       int afterRemove = offset + remove;
/* 298 */       if (afterRemove < this.fGapStart) {
/*     */         
/* 300 */         int betweenSize = this.fGapStart - afterRemove;
/* 301 */         arrayCopy(afterRemove, newContent, newGapEnd, betweenSize);
/* 302 */         int restSize = this.fContent.length - this.fGapEnd;
/* 303 */         arrayCopy(this.fGapEnd, newContent, newGapEnd + betweenSize, restSize);
/*     */       } else {
/*     */         
/* 306 */         afterRemove += oldGapSize;
/* 307 */         int restSize = this.fContent.length - afterRemove;
/* 308 */         arrayCopy(afterRemove, newContent, newGapEnd, restSize);
/*     */       } 
/*     */     } else {
/*     */       
/* 312 */       arrayCopy(0, newContent, 0, this.fGapStart);
/* 313 */       int offsetShifted = offset + oldGapSize;
/* 314 */       int betweenSize = offsetShifted - this.fGapEnd;
/* 315 */       arrayCopy(this.fGapEnd, newContent, this.fGapStart, betweenSize);
/* 316 */       int afterRemove = offsetShifted + remove;
/* 317 */       int restSize = this.fContent.length - afterRemove;
/* 318 */       arrayCopy(afterRemove, newContent, newGapEnd, restSize);
/*     */     } 
/*     */     
/* 321 */     this.fContent = newContent;
/* 322 */     return newGapEnd;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private char[] allocate(int size) {
/* 333 */     return new char[size];
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void arrayCopy(int srcPos, char[] dest, int destPos, int length) {
/* 342 */     if (length != 0) {
/* 343 */       System.arraycopy(this.fContent, srcPos, dest, destPos, length);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int gapSize() {
/* 353 */     return this.fGapEnd - this.fGapStart;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String getContentAsString() {
/* 363 */     return new String(this.fContent);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected int getGapStartIndex() {
/* 373 */     return this.fGapStart;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected int getGapEndIndex() {
/* 383 */     return this.fGapEnd;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.text-3.13.0.jar!\org\eclipse\jface\text\GapTextStore.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */