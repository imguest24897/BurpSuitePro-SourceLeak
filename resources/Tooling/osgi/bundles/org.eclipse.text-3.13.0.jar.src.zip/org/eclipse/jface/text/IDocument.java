package org.eclipse.jface.text;

public interface IDocument {
  public static final String DEFAULT_CATEGORY = "__dflt_position_category";
  
  public static final String DEFAULT_CONTENT_TYPE = "__dftl_partition_content_type";
  
  char getChar(int paramInt) throws BadLocationException;
  
  int getLength();
  
  String get();
  
  String get(int paramInt1, int paramInt2) throws BadLocationException;
  
  void set(String paramString);
  
  void replace(int paramInt1, int paramInt2, String paramString) throws BadLocationException;
  
  void addDocumentListener(IDocumentListener paramIDocumentListener);
  
  void removeDocumentListener(IDocumentListener paramIDocumentListener);
  
  void addPrenotifiedDocumentListener(IDocumentListener paramIDocumentListener);
  
  void removePrenotifiedDocumentListener(IDocumentListener paramIDocumentListener);
  
  void addPositionCategory(String paramString);
  
  void removePositionCategory(String paramString) throws BadPositionCategoryException;
  
  String[] getPositionCategories();
  
  boolean containsPositionCategory(String paramString);
  
  void addPosition(Position paramPosition) throws BadLocationException;
  
  void removePosition(Position paramPosition);
  
  void addPosition(String paramString, Position paramPosition) throws BadLocationException, BadPositionCategoryException;
  
  void removePosition(String paramString, Position paramPosition) throws BadPositionCategoryException;
  
  Position[] getPositions(String paramString) throws BadPositionCategoryException;
  
  boolean containsPosition(String paramString, int paramInt1, int paramInt2);
  
  int computeIndexInCategory(String paramString, int paramInt) throws BadLocationException, BadPositionCategoryException;
  
  void addPositionUpdater(IPositionUpdater paramIPositionUpdater);
  
  void removePositionUpdater(IPositionUpdater paramIPositionUpdater);
  
  void insertPositionUpdater(IPositionUpdater paramIPositionUpdater, int paramInt);
  
  IPositionUpdater[] getPositionUpdaters();
  
  String[] getLegalContentTypes();
  
  String getContentType(int paramInt) throws BadLocationException;
  
  ITypedRegion getPartition(int paramInt) throws BadLocationException;
  
  ITypedRegion[] computePartitioning(int paramInt1, int paramInt2) throws BadLocationException;
  
  void addDocumentPartitioningListener(IDocumentPartitioningListener paramIDocumentPartitioningListener);
  
  void removeDocumentPartitioningListener(IDocumentPartitioningListener paramIDocumentPartitioningListener);
  
  void setDocumentPartitioner(IDocumentPartitioner paramIDocumentPartitioner);
  
  IDocumentPartitioner getDocumentPartitioner();
  
  int getLineLength(int paramInt) throws BadLocationException;
  
  int getLineOfOffset(int paramInt) throws BadLocationException;
  
  int getLineOffset(int paramInt) throws BadLocationException;
  
  IRegion getLineInformation(int paramInt) throws BadLocationException;
  
  IRegion getLineInformationOfOffset(int paramInt) throws BadLocationException;
  
  int getNumberOfLines();
  
  int getNumberOfLines(int paramInt1, int paramInt2) throws BadLocationException;
  
  int computeNumberOfLines(String paramString);
  
  String[] getLegalLineDelimiters();
  
  String getLineDelimiter(int paramInt) throws BadLocationException;
  
  @Deprecated
  int search(int paramInt, String paramString, boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3) throws BadLocationException;
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.text-3.13.0.jar!\org\eclipse\jface\text\IDocument.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */