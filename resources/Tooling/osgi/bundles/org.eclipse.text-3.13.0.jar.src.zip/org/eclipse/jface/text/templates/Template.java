/*     */ package org.eclipse.jface.text.templates;
/*     */ 
/*     */ import org.eclipse.core.runtime.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Template
/*     */ {
/*     */   private String fName;
/*     */   private String fDescription;
/*     */   private String fContextTypeId;
/*     */   private String fPattern;
/*     */   private final boolean fIsAutoInsertable;
/*     */   
/*     */   public Template() {
/*  47 */     this("", "", "", "", true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Template(Template template) {
/*  56 */     this(template.getName(), template.getDescription(), template.getContextTypeId(), template.getPattern(), template.isAutoInsertable());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public Template(String name, String description, String contextTypeId, String pattern) {
/*  70 */     this(name, description, contextTypeId, pattern, true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Template(String name, String description, String contextTypeId, String pattern, boolean isAutoInsertable) {
/*  84 */     Assert.isNotNull(description);
/*  85 */     this.fDescription = description;
/*  86 */     this.fName = name;
/*  87 */     Assert.isNotNull(contextTypeId);
/*  88 */     this.fContextTypeId = contextTypeId;
/*  89 */     this.fPattern = pattern;
/*  90 */     this.fIsAutoInsertable = isAutoInsertable;
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/*  95 */     return this.fName.hashCode() ^ this.fPattern.hashCode() ^ this.fContextTypeId.hashCode();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public void setDescription(String description) {
/* 106 */     Assert.isNotNull(description);
/* 107 */     this.fDescription = description;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getDescription() {
/* 116 */     return this.fDescription;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public void setContextTypeId(String contextTypeId) {
/* 127 */     Assert.isNotNull(contextTypeId);
/* 128 */     this.fContextTypeId = contextTypeId;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getContextTypeId() {
/* 137 */     return this.fContextTypeId;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public void setName(String name) {
/* 148 */     this.fName = name;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getName() {
/* 157 */     return this.fName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public void setPattern(String pattern) {
/* 168 */     this.fPattern = pattern;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getPattern() {
/* 177 */     return this.fPattern;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean matches(String prefix, String contextTypeId) {
/* 190 */     return this.fContextTypeId.equals(contextTypeId);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object o) {
/* 195 */     if (!(o instanceof Template)) {
/* 196 */       return false;
/*     */     }
/* 198 */     Template t = (Template)o;
/* 199 */     if (t == this) {
/* 200 */       return true;
/*     */     }
/* 202 */     return (t.fName.equals(this.fName) && 
/* 203 */       t.fPattern.equals(this.fPattern) && 
/* 204 */       t.fContextTypeId.equals(this.fContextTypeId) && 
/* 205 */       t.fDescription.equals(this.fDescription) && 
/* 206 */       t.fIsAutoInsertable == this.fIsAutoInsertable);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isAutoInsertable() {
/* 216 */     return this.fIsAutoInsertable;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.text-3.13.0.jar!\org\eclipse\jface\text\templates\Template.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */