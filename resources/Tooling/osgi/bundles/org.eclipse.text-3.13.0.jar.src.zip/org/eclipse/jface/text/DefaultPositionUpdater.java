/*     */ package org.eclipse.jface.text;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DefaultPositionUpdater
/*     */   implements IPositionUpdater
/*     */ {
/*     */   private final String fCategory;
/*     */   protected Position fPosition;
/*  53 */   protected Position fOriginalPosition = new Position(0, 0);
/*     */ 
/*     */ 
/*     */   
/*     */   protected int fOffset;
/*     */ 
/*     */   
/*     */   protected int fLength;
/*     */ 
/*     */   
/*     */   protected int fReplaceLength;
/*     */ 
/*     */   
/*     */   protected IDocument fDocument;
/*     */ 
/*     */ 
/*     */   
/*     */   public DefaultPositionUpdater(String category) {
/*  71 */     this.fCategory = category;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String getCategory() {
/*  80 */     return this.fCategory;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean isAffectingReplace() {
/*  91 */     return (this.fLength > 0 && this.fReplaceLength > 0 && this.fPosition.length < this.fOriginalPosition.length);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void adaptToInsert() {
/*  99 */     int myStart = this.fPosition.offset;
/* 100 */     int myEnd = this.fPosition.offset + this.fPosition.length - 1;
/* 101 */     myEnd = Math.max(myStart, myEnd);
/*     */     
/* 103 */     int yoursStart = this.fOffset;
/*     */     
/* 105 */     if (myEnd < yoursStart) {
/*     */       return;
/*     */     }
/* 108 */     if (myStart < yoursStart) {
/* 109 */       this.fPosition.length += this.fReplaceLength;
/*     */     } else {
/* 111 */       this.fPosition.offset += this.fReplaceLength;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void adaptToRemove() {
/* 119 */     int myStart = this.fPosition.offset;
/* 120 */     int myEnd = this.fPosition.offset + this.fPosition.length - 1;
/* 121 */     myEnd = Math.max(myStart, myEnd);
/*     */     
/* 123 */     int yoursStart = this.fOffset;
/* 124 */     int yoursEnd = this.fOffset + this.fLength - 1;
/* 125 */     yoursEnd = Math.max(yoursStart, yoursEnd);
/*     */     
/* 127 */     if (myEnd < yoursStart) {
/*     */       return;
/*     */     }
/* 130 */     if (myStart <= yoursStart) {
/*     */       
/* 132 */       if (yoursEnd <= myEnd) {
/* 133 */         this.fPosition.length -= this.fLength;
/*     */       } else {
/* 135 */         this.fPosition.length -= myEnd - yoursStart + 1;
/*     */       } 
/* 137 */     } else if (yoursStart < myStart) {
/*     */       
/* 139 */       if (yoursEnd < myStart) {
/* 140 */         this.fPosition.offset -= this.fLength;
/*     */       } else {
/* 142 */         this.fPosition.offset -= myStart - yoursStart;
/* 143 */         this.fPosition.length -= yoursEnd - myStart + 1;
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 149 */     if (this.fPosition.offset < 0) {
/* 150 */       this.fPosition.offset = 0;
/*     */     }
/* 152 */     if (this.fPosition.length < 0) {
/* 153 */       this.fPosition.length = 0;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void adaptToReplace() {
/* 164 */     if (this.fLength > 0 && 
/* 165 */       this.fPosition.offset <= this.fOffset && 
/* 166 */       this.fOffset + this.fLength <= this.fPosition.offset + this.fPosition.length) {
/*     */       
/* 168 */       this.fPosition.length += this.fReplaceLength - this.fLength;
/*     */     }
/*     */     else {
/*     */       
/* 172 */       if (this.fLength > 0) {
/* 173 */         adaptToRemove();
/*     */       }
/* 175 */       if (this.fReplaceLength > 0) {
/* 176 */         adaptToInsert();
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean notDeleted() {
/* 189 */     if (this.fOffset < this.fPosition.offset && this.fPosition.offset + this.fPosition.length < this.fOffset + this.fLength) {
/*     */       
/* 191 */       this.fPosition.delete();
/*     */       
/*     */       try {
/* 194 */         this.fDocument.removePosition(this.fCategory, this.fPosition);
/* 195 */       } catch (BadPositionCategoryException badPositionCategoryException) {}
/*     */ 
/*     */       
/* 198 */       return false;
/*     */     } 
/*     */     
/* 201 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void update(DocumentEvent event) {
/*     */     try {
/* 210 */       this.fOffset = event.getOffset();
/* 211 */       this.fLength = event.getLength();
/* 212 */       this.fReplaceLength = (event.getText() == null) ? 0 : event.getText().length();
/* 213 */       this.fDocument = event.getDocument();
/*     */       
/* 215 */       Position[] category = this.fDocument.getPositions(this.fCategory); byte b; int i; Position[] arrayOfPosition1;
/* 216 */       for (i = (arrayOfPosition1 = category).length, b = 0; b < i; ) { Position element = arrayOfPosition1[b];
/*     */         
/* 218 */         this.fPosition = element;
/* 219 */         this.fOriginalPosition.offset = this.fPosition.offset;
/* 220 */         this.fOriginalPosition.length = this.fPosition.length;
/*     */         
/* 222 */         if (notDeleted())
/* 223 */           adaptToReplace(); 
/*     */         b++; }
/*     */     
/* 226 */     } catch (BadPositionCategoryException badPositionCategoryException) {
/*     */     
/*     */     } finally {
/* 229 */       this.fDocument = null;
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.text-3.13.0.jar!\org\eclipse\jface\text\DefaultPositionUpdater.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */