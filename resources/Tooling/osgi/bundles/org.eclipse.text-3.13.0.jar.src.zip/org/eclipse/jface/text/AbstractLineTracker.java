/*     */ package org.eclipse.jface.text;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractLineTracker
/*     */   implements ILineTracker, ILineTrackerExtension
/*     */ {
/*     */   private static final boolean DEBUG = false;
/*     */   private volatile SessionData sessionData;
/*     */   
/*     */   public static class DelimiterInfo
/*     */   {
/*     */     public int delimiterIndex;
/*     */     public int delimiterLength;
/*     */     public String delimiter;
/*     */   }
/*     */   
/*     */   protected static class Request
/*     */   {
/*     */     public final int offset;
/*     */     public final int length;
/*     */     public final String text;
/*     */     
/*     */     public Request(int offset, int length, String text) {
/*  69 */       this.offset = offset;
/*  70 */       this.length = length;
/*  71 */       this.text = text;
/*     */     }
/*     */     
/*     */     public Request(String text) {
/*  75 */       this.offset = -1;
/*  76 */       this.length = -1;
/*  77 */       this.text = text;
/*     */     }
/*     */     
/*     */     public boolean isReplaceRequest() {
/*  81 */       return (this.offset > -1 && this.length > -1);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static class SessionData
/*     */   {
/*     */     private volatile DocumentRewriteSession fActiveRewriteSession;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private List<AbstractLineTracker.Request> fPendingRequests;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     SessionData(DocumentRewriteSession activeRewriteSession) {
/* 115 */       this.fActiveRewriteSession = activeRewriteSession;
/* 116 */       if (activeRewriteSession != null) {
/* 117 */         this.fPendingRequests = new ArrayList<>(20);
/*     */       } else {
/* 119 */         this.fPendingRequests = Collections.emptyList();
/*     */       } 
/*     */     }
/*     */     
/*     */     boolean isSessionActive() {
/* 124 */       return (this.fActiveRewriteSession != null);
/*     */     }
/*     */     
/*     */     boolean setIfActive(String text) {
/* 128 */       if (isSessionActive()) {
/* 129 */         synchronized (this) {
/* 130 */           if (!isSessionActive()) {
/* 131 */             return false;
/*     */           }
/* 133 */           this.fPendingRequests.clear();
/* 134 */           this.fPendingRequests.add(new AbstractLineTracker.Request(text));
/*     */         } 
/* 136 */         return true;
/*     */       } 
/* 138 */       return false;
/*     */     }
/*     */ 
/*     */     
/*     */     boolean addIfActive(int offset, int length, String text) {
/* 143 */       if (isSessionActive()) {
/* 144 */         synchronized (this) {
/* 145 */           if (!isSessionActive()) {
/* 146 */             return false;
/*     */           }
/* 148 */           this.fPendingRequests.add(new AbstractLineTracker.Request(offset, length, text));
/*     */         } 
/* 150 */         return true;
/*     */       } 
/* 152 */       return false;
/*     */     }
/*     */ 
/*     */     
/*     */     Iterator<AbstractLineTracker.Request> flush() {
/* 157 */       synchronized (this) {
/* 158 */         this.fActiveRewriteSession = null;
/* 159 */         Iterator<AbstractLineTracker.Request> requests = this.fPendingRequests.iterator();
/* 160 */         this.fPendingRequests = Collections.emptyList();
/* 161 */         return requests;
/*     */       } 
/*     */     }
/*     */     
/*     */     boolean sameSession(DocumentRewriteSession session) {
/* 166 */       return (this.fActiveRewriteSession == session);
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/* 171 */       StringBuilder builder = new StringBuilder();
/* 172 */       builder.append("SessionData [");
/* 173 */       builder.append("activeRewriteSession=");
/* 174 */       builder.append(this.fActiveRewriteSession);
/* 175 */       builder.append(", ");
/* 176 */       builder.append("pendingRequests=");
/* 177 */       builder.append(this.fPendingRequests);
/* 178 */       builder.append("]");
/* 179 */       return builder.toString();
/*     */     }
/*     */   }
/*     */ 
/*     */   
/* 184 */   private final Object sessionLock = new Object();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 191 */   private volatile ILineTracker fDelegate = new ListLineTracker()
/*     */     {
/*     */       public String[] getLegalLineDelimiters() {
/* 194 */         return AbstractLineTracker.this.getLegalLineDelimiters();
/*     */       }
/*     */ 
/*     */       
/*     */       protected AbstractLineTracker.DelimiterInfo nextDelimiterInfo(String text, int offset) {
/* 199 */         return AbstractLineTracker.this.nextDelimiterInfo(text, offset);
/*     */       }
/*     */     };
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean fNeedsConversion = true;
/*     */ 
/*     */ 
/*     */   
/*     */   protected AbstractLineTracker() {
/* 211 */     this.sessionData = new SessionData(null);
/*     */   }
/*     */ 
/*     */   
/*     */   public int computeNumberOfLines(String text) {
/* 216 */     return this.fDelegate.computeNumberOfLines(text);
/*     */   }
/*     */ 
/*     */   
/*     */   public String getLineDelimiter(int line) throws BadLocationException {
/* 221 */     checkRewriteSession();
/* 222 */     return this.fDelegate.getLineDelimiter(line);
/*     */   }
/*     */ 
/*     */   
/*     */   public IRegion getLineInformation(int line) throws BadLocationException {
/* 227 */     checkRewriteSession();
/* 228 */     return this.fDelegate.getLineInformation(line);
/*     */   }
/*     */ 
/*     */   
/*     */   public IRegion getLineInformationOfOffset(int offset) throws BadLocationException {
/* 233 */     checkRewriteSession();
/* 234 */     return this.fDelegate.getLineInformationOfOffset(offset);
/*     */   }
/*     */ 
/*     */   
/*     */   public int getLineLength(int line) throws BadLocationException {
/* 239 */     checkRewriteSession();
/* 240 */     return this.fDelegate.getLineLength(line);
/*     */   }
/*     */ 
/*     */   
/*     */   public int getLineNumberOfOffset(int offset) throws BadLocationException {
/* 245 */     checkRewriteSession();
/* 246 */     return this.fDelegate.getLineNumberOfOffset(offset);
/*     */   }
/*     */ 
/*     */   
/*     */   public int getLineOffset(int line) throws BadLocationException {
/* 251 */     checkRewriteSession();
/* 252 */     return this.fDelegate.getLineOffset(line);
/*     */   }
/*     */ 
/*     */   
/*     */   public int getNumberOfLines() {
/*     */     try {
/* 258 */       checkRewriteSession();
/* 259 */     } catch (BadLocationException badLocationException) {}
/*     */ 
/*     */     
/* 262 */     return this.fDelegate.getNumberOfLines();
/*     */   }
/*     */ 
/*     */   
/*     */   public int getNumberOfLines(int offset, int length) throws BadLocationException {
/* 267 */     checkRewriteSession();
/* 268 */     return this.fDelegate.getNumberOfLines(offset, length);
/*     */   }
/*     */ 
/*     */   
/*     */   public void set(String text) {
/* 273 */     boolean hasActiveRewriteSession = this.sessionData.setIfActive(text);
/* 274 */     if (hasActiveRewriteSession) {
/*     */       return;
/*     */     }
/*     */     
/* 278 */     this.fDelegate.set(text);
/*     */   }
/*     */ 
/*     */   
/*     */   public void replace(int offset, int length, String text) throws BadLocationException {
/* 283 */     boolean hasActiveRewriteSession = this.sessionData.addIfActive(offset, length, text);
/* 284 */     if (hasActiveRewriteSession) {
/*     */       return;
/*     */     }
/*     */     
/* 288 */     checkImplementation();
/*     */     
/* 290 */     this.fDelegate.replace(offset, length, text);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private synchronized void checkImplementation() {
/* 299 */     if (this.fNeedsConversion) {
/* 300 */       this.fNeedsConversion = false;
/* 301 */       this.fDelegate = new TreeLineTracker((ListLineTracker)this.fDelegate)
/*     */         {
/*     */           protected AbstractLineTracker.DelimiterInfo nextDelimiterInfo(String text, int offset) {
/* 304 */             return AbstractLineTracker.this.nextDelimiterInfo(text, offset);
/*     */           }
/*     */ 
/*     */           
/*     */           public String[] getLegalLineDelimiters() {
/* 309 */             return AbstractLineTracker.this.getLegalLineDelimiters();
/*     */           }
/*     */         };
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected abstract DelimiterInfo nextDelimiterInfo(String paramString, int paramInt);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void startRewriteSession(DocumentRewriteSession session) {
/* 327 */     synchronized (this.sessionLock) {
/* 328 */       if (this.sessionData.isSessionActive()) {
/* 329 */         throw new IllegalStateException("Rewrite session is already active: " + this.sessionData);
/*     */       }
/* 331 */       this.sessionData = new SessionData(session);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public final void stopRewriteSession(DocumentRewriteSession session, String text) {
/* 337 */     synchronized (this.sessionLock) {
/* 338 */       if (this.sessionData.sameSession(session)) {
/* 339 */         this.sessionData = new SessionData(null);
/* 340 */         set(text);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final boolean hasActiveRewriteSession() {
/* 353 */     return this.sessionData.isSessionActive();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final void flushRewriteSession() throws BadLocationException {
/* 365 */     synchronized (this.sessionData) {
/* 366 */       Iterator<Request> e = this.sessionData.flush();
/* 367 */       while (e.hasNext()) {
/* 368 */         Request request = e.next();
/* 369 */         if (request.isReplaceRequest()) {
/* 370 */           replace(request.offset, request.length, request.text); continue;
/*     */         } 
/* 372 */         set(request.text);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final void checkRewriteSession() throws BadLocationException {
/* 384 */     if (hasActiveRewriteSession())
/* 385 */       flushRewriteSession(); 
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.text-3.13.0.jar!\org\eclipse\jface\text\AbstractLineTracker.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */