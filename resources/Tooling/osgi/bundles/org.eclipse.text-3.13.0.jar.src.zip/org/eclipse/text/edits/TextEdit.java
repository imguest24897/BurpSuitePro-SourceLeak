/*     */ package org.eclipse.text.edits;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.Comparator;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import org.eclipse.core.runtime.Assert;
/*     */ import org.eclipse.jface.text.BadLocationException;
/*     */ import org.eclipse.jface.text.IDocument;
/*     */ import org.eclipse.jface.text.IRegion;
/*     */ import org.eclipse.jface.text.Region;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class TextEdit
/*     */ {
/*     */   public static final int NONE = 0;
/*     */   public static final int CREATE_UNDO = 1;
/*     */   public static final int UPDATE_REGIONS = 2;
/*     */   
/*     */   private static class InsertionComparator
/*     */     implements Comparator<TextEdit>
/*     */   {
/*     */     public int compare(TextEdit edit1, TextEdit edit2) throws MalformedTreeException {
/* 111 */       int offset1 = edit1.getOffset();
/* 112 */       int length1 = edit1.getLength();
/*     */       
/* 114 */       int offset2 = edit2.getOffset();
/* 115 */       int length2 = edit2.getLength();
/*     */       
/* 117 */       if (offset1 == offset2 && length1 == 0 && length2 == 0) {
/* 118 */         return 0;
/*     */       }
/* 120 */       if (offset1 + length1 <= offset2) {
/* 121 */         return -1;
/*     */       }
/* 123 */       if (offset2 + length2 <= offset1) {
/* 124 */         return 1;
/*     */       }
/* 126 */       throw new MalformedTreeException(
/* 127 */           null, edit1, 
/* 128 */           TextEditMessages.getString("TextEdit.overlapping"));
/*     */     }
/*     */   }
/*     */   
/* 132 */   private static final TextEdit[] EMPTY_ARRAY = new TextEdit[0];
/* 133 */   private static final InsertionComparator INSERTION_COMPARATOR = new InsertionComparator();
/*     */ 
/*     */   
/*     */   private static final int DELETED_VALUE = -1;
/*     */ 
/*     */   
/*     */   private int fOffset;
/*     */ 
/*     */   
/*     */   private int fLength;
/*     */ 
/*     */   
/*     */   private TextEdit fParent;
/*     */   
/*     */   private List<TextEdit> fChildren;
/*     */   
/*     */   int fDelta;
/*     */ 
/*     */   
/*     */   protected TextEdit(int offset, int length) {
/* 153 */     Assert.isTrue((offset >= 0 && length >= 0));
/* 154 */     this.fOffset = offset;
/* 155 */     this.fLength = length;
/* 156 */     this.fDelta = 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected TextEdit(TextEdit source) {
/* 165 */     this.fOffset = source.fOffset;
/* 166 */     this.fLength = source.fLength;
/* 167 */     this.fDelta = 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final IRegion getRegion() {
/* 185 */     return (IRegion)new Region(getOffset(), getLength());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getOffset() {
/* 196 */     return this.fOffset;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getLength() {
/* 206 */     return this.fLength;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final int getInclusiveEnd() {
/* 221 */     return getOffset() + getLength() - 1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final int getExclusiveEnd() {
/* 236 */     return getOffset() + getLength();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final boolean isDeleted() {
/* 246 */     return (this.fOffset == -1 && this.fLength == -1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void moveTree(int delta) {
/* 257 */     Assert.isTrue((this.fParent == null));
/* 258 */     Assert.isTrue((getOffset() + delta >= 0));
/* 259 */     internalMoveTree(delta);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean covers(TextEdit other) {
/* 272 */     if (getLength() == 0 && !canZeroLengthCover()) {
/* 273 */       return false;
/*     */     }
/* 275 */     if (!other.isDefined()) {
/* 276 */       return true;
/*     */     }
/* 278 */     int thisOffset = getOffset();
/* 279 */     int otherOffset = other.getOffset();
/* 280 */     return (thisOffset <= otherOffset && otherOffset + other.getLength() <= thisOffset + getLength());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean canZeroLengthCover() {
/* 290 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean isDefined() {
/* 301 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final TextEdit getParent() {
/* 313 */     return this.fParent;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final TextEdit getRoot() {
/* 323 */     TextEdit result = this;
/* 324 */     while (result.fParent != null) {
/* 325 */       result = result.fParent;
/*     */     }
/* 327 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void addChild(TextEdit child) throws MalformedTreeException {
/* 340 */     internalAdd(child);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void addChildren(TextEdit[] edits) throws MalformedTreeException {
/*     */     byte b;
/*     */     int i;
/*     */     TextEdit[] arrayOfTextEdit;
/* 353 */     for (i = (arrayOfTextEdit = edits).length, b = 0; b < i; ) { TextEdit edit = arrayOfTextEdit[b];
/* 354 */       internalAdd(edit);
/*     */       b++; }
/*     */   
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final TextEdit removeChild(int index) {
/* 370 */     if (this.fChildren == null)
/* 371 */       throw new IndexOutOfBoundsException("Index: " + index + " Size: 0"); 
/* 372 */     TextEdit result = this.fChildren.remove(index);
/* 373 */     result.internalSetParent(null);
/* 374 */     if (this.fChildren.isEmpty())
/* 375 */       this.fChildren = null; 
/* 376 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final boolean removeChild(TextEdit child) {
/* 388 */     Assert.isNotNull(child);
/* 389 */     if (this.fChildren == null)
/* 390 */       return false; 
/* 391 */     boolean result = this.fChildren.remove(child);
/* 392 */     if (result) {
/* 393 */       child.internalSetParent(null);
/* 394 */       if (this.fChildren.isEmpty())
/* 395 */         this.fChildren = null; 
/*     */     } 
/* 397 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final TextEdit[] removeChildren() {
/* 407 */     if (this.fChildren == null)
/* 408 */       return EMPTY_ARRAY; 
/* 409 */     int size = this.fChildren.size();
/* 410 */     TextEdit[] result = new TextEdit[size];
/* 411 */     for (int i = 0; i < size; i++) {
/* 412 */       result[i] = this.fChildren.get(i);
/* 413 */       result[i].internalSetParent(null);
/*     */     } 
/* 415 */     this.fChildren = null;
/* 416 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final boolean hasChildren() {
/* 427 */     return (this.fChildren != null && !this.fChildren.isEmpty());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final TextEdit[] getChildren() {
/* 437 */     if (this.fChildren == null)
/* 438 */       return EMPTY_ARRAY; 
/* 439 */     return this.fChildren.<TextEdit>toArray(new TextEdit[this.fChildren.size()]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final int getChildrenSize() {
/* 448 */     if (this.fChildren == null)
/* 449 */       return 0; 
/* 450 */     return this.fChildren.size();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static IRegion getCoverage(TextEdit[] edits) {
/* 464 */     Assert.isTrue((edits != null && edits.length > 0));
/*     */     
/* 466 */     int offset = Integer.MAX_VALUE;
/* 467 */     int end = Integer.MIN_VALUE;
/* 468 */     int deleted = 0; byte b; int i; TextEdit[] arrayOfTextEdit;
/* 469 */     for (i = (arrayOfTextEdit = edits).length, b = 0; b < i; ) { TextEdit edit = arrayOfTextEdit[b];
/* 470 */       if (edit.isDeleted()) {
/* 471 */         deleted++;
/*     */       } else {
/* 473 */         offset = Math.min(offset, edit.getOffset());
/* 474 */         end = Math.max(end, edit.getExclusiveEnd());
/*     */       }  b++; }
/*     */     
/* 477 */     if (edits.length == deleted) {
/* 478 */       return null;
/*     */     }
/* 480 */     return (IRegion)new Region(offset, end - offset);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void aboutToBeAdded(TextEdit parent) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final boolean equals(Object obj) {
/* 505 */     return (this == obj);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final int hashCode() {
/* 519 */     return super.hashCode();
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 524 */     StringBuilder buffer = new StringBuilder();
/* 525 */     toStringWithChildren(buffer, 0);
/* 526 */     return buffer.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void internalToString(StringBuilder buffer, int indent) {
/* 538 */     for (int i = indent; i > 0; i--) {
/* 539 */       buffer.append("  ");
/*     */     }
/* 541 */     buffer.append("{");
/* 542 */     String name = getClass().getName();
/* 543 */     int index = name.lastIndexOf('.');
/* 544 */     if (index != -1) {
/* 545 */       buffer.append(name.substring(index + 1));
/*     */     } else {
/* 547 */       buffer.append(name);
/*     */     } 
/* 549 */     buffer.append("} ");
/* 550 */     if (isDeleted()) {
/* 551 */       buffer.append("[deleted]");
/*     */     } else {
/* 553 */       buffer.append("[");
/* 554 */       buffer.append(getOffset());
/* 555 */       buffer.append(",");
/* 556 */       buffer.append(getLength());
/* 557 */       buffer.append("]");
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void toStringWithChildren(StringBuilder buffer, int indent) {
/* 570 */     internalToString(buffer, indent);
/* 571 */     if (this.fChildren != null) {
/* 572 */       for (TextEdit child : this.fChildren) {
/* 573 */         buffer.append('\n');
/* 574 */         child.toStringWithChildren(buffer, indent + 1);
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final TextEdit copy() {
/* 589 */     TextEditCopier copier = new TextEditCopier(this);
/* 590 */     return copier.perform();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected abstract TextEdit doCopy();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void postProcessCopy(TextEditCopier copier) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void accept(TextEditVisitor visitor) {
/* 637 */     Assert.isNotNull(visitor);
/*     */     
/* 639 */     visitor.preVisit(this);
/*     */     
/* 641 */     accept0(visitor);
/*     */     
/* 643 */     visitor.postVisit(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected abstract void accept0(TextEditVisitor paramTextEditVisitor);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final void acceptChildren(TextEditVisitor visitor) {
/* 679 */     if (this.fChildren == null)
/*     */       return; 
/* 681 */     Iterator<TextEdit> iterator = this.fChildren.iterator();
/* 682 */     while (iterator.hasNext()) {
/* 683 */       TextEdit curr = iterator.next();
/* 684 */       curr.accept(visitor);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final UndoEdit apply(IDocument document, int style) throws MalformedTreeException, BadLocationException {
/*     */     try {
/* 713 */       TextEditProcessor processor = new TextEditProcessor(document, this, style);
/* 714 */       return processor.performEdits();
/*     */     } finally {
/*     */       
/* 717 */       this.fParent = null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final UndoEdit apply(IDocument document) throws MalformedTreeException, BadLocationException {
/* 738 */     return apply(document, 3);
/*     */   }
/*     */   
/*     */   UndoEdit dispatchPerformEdits(TextEditProcessor processor) throws BadLocationException {
/* 742 */     return processor.executeDo();
/*     */   }
/*     */   
/*     */   void dispatchCheckIntegrity(TextEditProcessor processor) throws MalformedTreeException {
/* 746 */     processor.checkIntegrityDo();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   void internalSetParent(TextEdit parent) {
/* 752 */     if (parent != null)
/* 753 */       Assert.isTrue((this.fParent == null)); 
/* 754 */     this.fParent = parent;
/*     */   }
/*     */   
/*     */   void internalSetOffset(int offset) {
/* 758 */     Assert.isTrue((offset >= 0));
/* 759 */     this.fOffset = offset;
/*     */   }
/*     */   
/*     */   void internalSetLength(int length) {
/* 763 */     Assert.isTrue((length >= 0));
/* 764 */     this.fLength = length;
/*     */   }
/*     */   
/*     */   List<TextEdit> internalGetChildren() {
/* 768 */     return this.fChildren;
/*     */   }
/*     */   
/*     */   void internalSetChildren(List<TextEdit> children) {
/* 772 */     this.fChildren = children;
/*     */   }
/*     */   
/*     */   void internalAdd(TextEdit child) throws MalformedTreeException {
/* 776 */     child.aboutToBeAdded(this);
/* 777 */     if (child.isDeleted())
/* 778 */       throw new MalformedTreeException(this, child, TextEditMessages.getString("TextEdit.deleted_edit")); 
/* 779 */     if (!covers(child))
/* 780 */       throw new MalformedTreeException(this, child, TextEditMessages.getString("TextEdit.range_outside")); 
/* 781 */     if (this.fChildren == null) {
/* 782 */       this.fChildren = new ArrayList<>(2);
/*     */     }
/* 784 */     int index = computeInsertionIndex(child);
/* 785 */     this.fChildren.add(index, child);
/* 786 */     child.internalSetParent(this);
/*     */   }
/*     */   
/*     */   private int computeInsertionIndex(TextEdit edit) throws MalformedTreeException {
/* 790 */     int size = this.fChildren.size();
/* 791 */     if (size == 0)
/* 792 */       return 0; 
/* 793 */     int lastIndex = size - 1;
/* 794 */     TextEdit last = this.fChildren.get(lastIndex);
/* 795 */     if (last.getExclusiveEnd() <= edit.getOffset()) {
/* 796 */       return size;
/*     */     }
/*     */     try {
/* 799 */       int index = Collections.binarySearch(this.fChildren, edit, INSERTION_COMPARATOR);
/*     */       
/* 801 */       if (index < 0)
/*     */       {
/* 803 */         return -index - 1;
/*     */       }
/*     */ 
/*     */       
/* 807 */       while (index < lastIndex && INSERTION_COMPARATOR.compare(this.fChildren.get(index), this.fChildren.get(index + 1)) == 0) {
/* 808 */         index++;
/*     */       }
/* 810 */       return index + 1;
/*     */     }
/* 812 */     catch (MalformedTreeException e) {
/* 813 */       e.setParent(this);
/* 814 */       throw e;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void adjustOffset(int delta) {
/* 827 */     if (isDeleted())
/*     */       return; 
/* 829 */     this.fOffset += delta;
/* 830 */     Assert.isTrue((this.fOffset >= 0));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void adjustLength(int delta) {
/* 840 */     if (isDeleted())
/*     */       return; 
/* 842 */     this.fLength += delta;
/* 843 */     Assert.isTrue((this.fLength >= 0));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void markAsDeleted() {
/* 851 */     this.fOffset = -1;
/* 852 */     this.fLength = -1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   int traverseConsistencyCheck(TextEditProcessor processor, IDocument document, List<List<TextEdit>> sourceEdits) {
/* 868 */     int result = 0;
/* 869 */     if (this.fChildren != null) {
/* 870 */       for (int i = this.fChildren.size() - 1; i >= 0; i--) {
/* 871 */         TextEdit child = this.fChildren.get(i);
/* 872 */         result = Math.max(result, child.traverseConsistencyCheck(processor, document, sourceEdits));
/*     */       } 
/*     */     }
/* 875 */     if (processor.considerEdit(this)) {
/* 876 */       performConsistencyCheck(processor, document);
/*     */     }
/* 878 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void performConsistencyCheck(TextEditProcessor processor, IDocument document) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void traverseSourceComputation(TextEditProcessor processor, IDocument document) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void performSourceComputation(TextEditProcessor processor, IDocument document) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   int traverseDocumentUpdating(TextEditProcessor processor, IDocument document) throws BadLocationException {
/* 909 */     int delta = 0;
/* 910 */     if (this.fChildren != null) {
/* 911 */       for (int i = this.fChildren.size() - 1; i >= 0; i--) {
/* 912 */         TextEdit child = this.fChildren.get(i);
/* 913 */         delta += child.traverseDocumentUpdating(processor, document);
/* 914 */         childDocumentUpdated();
/*     */       } 
/*     */     }
/* 917 */     if (processor.considerEdit(this)) {
/* 918 */       if (delta != 0)
/* 919 */         adjustLength(delta); 
/* 920 */       int r = performDocumentUpdating(document);
/* 921 */       if (r != 0)
/* 922 */         adjustLength(r); 
/* 923 */       delta += r;
/*     */     } 
/* 925 */     return delta;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void childDocumentUpdated() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   abstract int performDocumentUpdating(IDocument paramIDocument) throws BadLocationException;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   int traverseRegionUpdating(TextEditProcessor processor, IDocument document, int accumulatedDelta, boolean delete) {
/* 944 */     performRegionUpdating(accumulatedDelta, delete);
/* 945 */     if (this.fChildren != null) {
/* 946 */       boolean childDelete = !(!delete && !deleteChildren());
/* 947 */       for (TextEdit child : this.fChildren) {
/* 948 */         accumulatedDelta = child.traverseRegionUpdating(processor, document, accumulatedDelta, childDelete);
/* 949 */         childRegionUpdated();
/*     */       } 
/*     */     } 
/* 952 */     return accumulatedDelta + this.fDelta;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void childRegionUpdated() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void performRegionUpdating(int accumulatedDelta, boolean delete) {
/* 971 */     if (delete) {
/* 972 */       markAsDeleted();
/*     */     } else {
/* 974 */       adjustOffset(accumulatedDelta);
/*     */     } 
/*     */   }
/*     */   abstract boolean deleteChildren();
/*     */   
/*     */   void internalMoveTree(int delta) {
/* 980 */     adjustOffset(delta);
/* 981 */     if (this.fChildren != null) {
/* 982 */       for (TextEdit textEdit : this.fChildren) {
/* 983 */         textEdit.internalMoveTree(delta);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   void deleteTree() {
/* 989 */     markAsDeleted();
/* 990 */     if (this.fChildren != null)
/* 991 */       for (TextEdit child : this.fChildren)
/* 992 */         child.deleteTree();  
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.text-3.13.0.jar!\org\eclipse\text\edits\TextEdit.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */