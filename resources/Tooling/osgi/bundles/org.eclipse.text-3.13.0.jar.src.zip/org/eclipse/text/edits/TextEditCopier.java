/*    */ package org.eclipse.text.edits;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.HashMap;
/*    */ import java.util.List;
/*    */ import java.util.Map;
/*    */ import org.eclipse.core.runtime.Assert;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class TextEditCopier
/*    */ {
/*    */   private TextEdit fEdit;
/*    */   private Map<TextEdit, TextEdit> fCopies;
/*    */   
/*    */   public TextEditCopier(TextEdit edit) {
/* 47 */     Assert.isNotNull(edit);
/* 48 */     this.fEdit = edit;
/* 49 */     this.fCopies = new HashMap<>();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public TextEdit perform() {
/* 58 */     TextEdit result = doCopy(this.fEdit);
/* 59 */     if (result != null) {
/* 60 */       for (TextEdit edit : this.fCopies.keySet()) {
/* 61 */         edit.postProcessCopy(this);
/*    */       }
/*    */     }
/* 64 */     return result;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public TextEdit getCopy(TextEdit original) {
/* 76 */     Assert.isNotNull(original);
/* 77 */     return this.fCopies.get(original);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   private TextEdit doCopy(TextEdit edit) {
/* 83 */     TextEdit result = edit.doCopy();
/* 84 */     List<TextEdit> children = edit.internalGetChildren();
/* 85 */     if (children != null) {
/* 86 */       List<TextEdit> newChildren = new ArrayList<>(children.size());
/* 87 */       for (TextEdit textEdit : children) {
/* 88 */         TextEdit childCopy = doCopy(textEdit);
/* 89 */         childCopy.internalSetParent(result);
/* 90 */         newChildren.add(childCopy);
/*    */       } 
/* 92 */       result.internalSetChildren(newChildren);
/*    */     } 
/* 94 */     addCopy(edit, result);
/* 95 */     return result;
/*    */   }
/*    */   
/*    */   private void addCopy(TextEdit original, TextEdit copy) {
/* 99 */     this.fCopies.put(original, copy);
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.text-3.13.0.jar!\org\eclipse\text\edits\TextEditCopier.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */