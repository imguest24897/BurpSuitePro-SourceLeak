/*     */ package org.eclipse.text.edits;
/*     */ 
/*     */ import java.util.List;
/*     */ import org.eclipse.core.runtime.Assert;
/*     */ import org.eclipse.jface.text.BadLocationException;
/*     */ import org.eclipse.jface.text.IDocument;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class CopyTargetEdit
/*     */   extends TextEdit
/*     */ {
/*     */   private CopySourceEdit fSource;
/*     */   
/*     */   public CopyTargetEdit(int offset) {
/*  49 */     super(offset, 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CopyTargetEdit(int offset, CopySourceEdit source) {
/*  59 */     this(offset);
/*  60 */     setSourceEdit(source);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private CopyTargetEdit(CopyTargetEdit other) {
/*  67 */     super(other);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CopySourceEdit getSourceEdit() {
/*  77 */     return this.fSource;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSourceEdit(CopySourceEdit edit) throws MalformedTreeException {
/*  89 */     Assert.isNotNull(edit);
/*  90 */     if (this.fSource != edit) {
/*  91 */       this.fSource = edit;
/*  92 */       this.fSource.setTargetEdit(this);
/*  93 */       TextEdit parent = getParent();
/*  94 */       while (parent != null) {
/*  95 */         if (parent == this.fSource)
/*  96 */           throw new MalformedTreeException(parent, this, TextEditMessages.getString("CopyTargetEdit.wrong_parent")); 
/*  97 */         parent = parent.getParent();
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   protected TextEdit doCopy() {
/* 104 */     return new CopyTargetEdit(this);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void postProcessCopy(TextEditCopier copier) {
/* 109 */     if (this.fSource != null) {
/* 110 */       CopyTargetEdit target = (CopyTargetEdit)copier.getCopy(this);
/* 111 */       CopySourceEdit source = (CopySourceEdit)copier.getCopy(this.fSource);
/* 112 */       if (target != null && source != null) {
/* 113 */         target.setSourceEdit(source);
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   protected void accept0(TextEditVisitor visitor) {
/* 119 */     boolean visitChildren = visitor.visit(this);
/* 120 */     if (visitChildren) {
/* 121 */       acceptChildren(visitor);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   int traverseConsistencyCheck(TextEditProcessor processor, IDocument document, List<List<TextEdit>> sourceEdits) {
/* 127 */     return super.traverseConsistencyCheck(processor, document, sourceEdits) + 1;
/*     */   }
/*     */ 
/*     */   
/*     */   void performConsistencyCheck(TextEditProcessor processor, IDocument document) throws MalformedTreeException {
/* 132 */     if (this.fSource == null)
/* 133 */       throw new MalformedTreeException(getParent(), this, TextEditMessages.getString("CopyTargetEdit.no_source")); 
/* 134 */     if (this.fSource.getTargetEdit() != this) {
/* 135 */       throw new MalformedTreeException(getParent(), this, TextEditMessages.getString("CopyTargetEdit.different_target"));
/*     */     }
/*     */   }
/*     */   
/*     */   int performDocumentUpdating(IDocument document) throws BadLocationException {
/* 140 */     String source = this.fSource.getContent();
/* 141 */     document.replace(getOffset(), getLength(), source);
/* 142 */     this.fDelta = source.length() - getLength();
/* 143 */     this.fSource.clearContent();
/* 144 */     return this.fDelta;
/*     */   }
/*     */ 
/*     */   
/*     */   boolean deleteChildren() {
/* 149 */     return false;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.text-3.13.0.jar!\org\eclipse\text\edits\CopyTargetEdit.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */