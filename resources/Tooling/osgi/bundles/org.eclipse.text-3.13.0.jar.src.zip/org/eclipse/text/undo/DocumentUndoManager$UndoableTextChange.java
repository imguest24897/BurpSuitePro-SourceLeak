/*     */ package org.eclipse.text.undo;
/*     */ 
/*     */ import org.eclipse.core.commands.operations.AbstractOperation;
/*     */ import org.eclipse.core.commands.operations.IOperationHistory;
/*     */ import org.eclipse.core.commands.operations.IUndoContext;
/*     */ import org.eclipse.core.runtime.IAdaptable;
/*     */ import org.eclipse.core.runtime.IProgressMonitor;
/*     */ import org.eclipse.core.runtime.IStatus;
/*     */ import org.eclipse.core.runtime.Status;
/*     */ import org.eclipse.jface.text.BadLocationException;
/*     */ import org.eclipse.jface.text.IDocumentExtension4;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class UndoableTextChange
/*     */   extends AbstractOperation
/*     */ {
/*  83 */   protected int fStart = -1;
/*     */ 
/*     */   
/*  86 */   protected int fEnd = -1;
/*     */ 
/*     */   
/*     */   protected String fText;
/*     */ 
/*     */   
/*     */   protected String fPreservedText;
/*     */ 
/*     */   
/*  95 */   protected long fUndoModificationStamp = -1L;
/*     */ 
/*     */   
/*  98 */   protected long fRedoModificationStamp = -1L;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected DocumentUndoManager fDocumentUndoManager;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   UndoableTextChange(DocumentUndoManager manager) {
/* 109 */     super(UndoMessages.getString("DocumentUndoManager.operationLabel"));
/* 110 */     this.fDocumentUndoManager = manager;
/* 111 */     addContext(manager.getUndoContext());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void reinitialize() {
/* 118 */     this.fStart = this.fEnd = -1;
/* 119 */     this.fText = this.fPreservedText = null;
/* 120 */     this.fUndoModificationStamp = -1L;
/* 121 */     this.fRedoModificationStamp = -1L;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void set(int start, int end) {
/* 131 */     this.fStart = start;
/* 132 */     this.fEnd = end;
/* 133 */     this.fText = null;
/* 134 */     this.fPreservedText = null;
/*     */   }
/*     */ 
/*     */   
/*     */   public void dispose() {
/* 139 */     reinitialize();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void undoTextChange() {
/*     */     try {
/* 147 */       if (this.fDocumentUndoManager.fDocument instanceof IDocumentExtension4) {
/* 148 */         ((IDocumentExtension4)this.fDocumentUndoManager.fDocument).replace(this.fStart, this.fText
/* 149 */             .length(), this.fPreservedText, this.fUndoModificationStamp);
/*     */       } else {
/* 151 */         this.fDocumentUndoManager.fDocument.replace(this.fStart, this.fText.length(), 
/* 152 */             this.fPreservedText);
/*     */       } 
/* 154 */     } catch (BadLocationException badLocationException) {}
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean canUndo() {
/* 160 */     if (isValid()) {
/* 161 */       if (this.fDocumentUndoManager.fDocument instanceof IDocumentExtension4) {
/* 162 */         long docStamp = ((IDocumentExtension4)this.fDocumentUndoManager.fDocument)
/* 163 */           .getModificationStamp();
/*     */ 
/*     */ 
/*     */         
/* 167 */         boolean canUndo = !(docStamp != -1L && 
/* 168 */           docStamp < getRedoModificationStamp());
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 183 */         if (!canUndo && 
/* 184 */           this == this.fDocumentUndoManager.fHistory
/* 185 */           .getUndoOperation((IUndoContext)this.fDocumentUndoManager.fUndoContext))
/*     */         {
/* 187 */           if (this != this.fDocumentUndoManager.fCurrent)
/*     */           {
/* 189 */             if (!this.fDocumentUndoManager.fCurrent.isValid())
/*     */             {
/*     */               
/* 192 */               if (this.fDocumentUndoManager.fCurrent.fUndoModificationStamp != 
/*     */                 
/* 194 */                 -1L) {
/* 195 */                 canUndo = (this.fDocumentUndoManager.fCurrent.fRedoModificationStamp == docStamp);
/*     */               }
/*     */             }
/*     */           }
/*     */         }
/*     */ 
/*     */ 
/*     */         
/* 203 */         if (!canUndo && 
/* 204 */           this == this.fDocumentUndoManager.fHistory
/* 205 */           .getUndoOperation((IUndoContext)this.fDocumentUndoManager.fUndoContext))
/*     */         {
/* 207 */           if (this instanceof DocumentUndoManager.UndoableCompoundTextChange && 
/* 208 */             this == this.fDocumentUndoManager.fCurrent)
/*     */           {
/* 210 */             if (this.fStart == -1)
/*     */             {
/* 212 */               if (this.fDocumentUndoManager.fCurrent.fRedoModificationStamp != -1L)
/*     */               {
/* 214 */                 canUndo = (this.fDocumentUndoManager.fCurrent.fRedoModificationStamp == docStamp); }  }  } 
/*     */         }
/* 216 */         return canUndo;
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 221 */       return true;
/*     */     } 
/* 223 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean canRedo() {
/* 228 */     if (isValid()) {
/* 229 */       if (this.fDocumentUndoManager.fDocument instanceof IDocumentExtension4) {
/* 230 */         long docStamp = ((IDocumentExtension4)this.fDocumentUndoManager.fDocument)
/* 231 */           .getModificationStamp();
/* 232 */         return !(docStamp != -1L && 
/* 233 */           docStamp != getUndoModificationStamp());
/*     */       } 
/*     */ 
/*     */       
/* 237 */       return true;
/*     */     } 
/* 239 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean canExecute() {
/* 244 */     return this.fDocumentUndoManager.isConnected();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IStatus execute(IProgressMonitor monitor, IAdaptable uiInfo) {
/* 251 */     return Status.OK_STATUS;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IStatus undo(IProgressMonitor monitor, IAdaptable uiInfo) {
/* 260 */     if (isValid()) {
/* 261 */       this.fDocumentUndoManager.fireDocumentUndo(this.fStart, this.fPreservedText, this.fText, uiInfo, 1, false);
/* 262 */       undoTextChange();
/* 263 */       this.fDocumentUndoManager.resetProcessChangeState();
/* 264 */       this.fDocumentUndoManager.fireDocumentUndo(this.fStart, this.fPreservedText, this.fText, uiInfo, 4, false);
/* 265 */       return Status.OK_STATUS;
/*     */     } 
/* 267 */     return IOperationHistory.OPERATION_INVALID_STATUS;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void redoTextChange() {
/*     */     try {
/* 275 */       if (this.fDocumentUndoManager.fDocument instanceof IDocumentExtension4) {
/* 276 */         ((IDocumentExtension4)this.fDocumentUndoManager.fDocument).replace(this.fStart, this.fEnd - this.fStart, this.fText, this.fRedoModificationStamp);
/*     */       } else {
/* 278 */         this.fDocumentUndoManager.fDocument.replace(this.fStart, this.fEnd - this.fStart, this.fText);
/*     */       } 
/* 280 */     } catch (BadLocationException badLocationException) {}
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IStatus redo(IProgressMonitor monitor, IAdaptable uiInfo) {
/* 294 */     if (isValid()) {
/* 295 */       this.fDocumentUndoManager.fireDocumentUndo(this.fStart, this.fText, this.fPreservedText, uiInfo, 2, false);
/* 296 */       redoTextChange();
/* 297 */       this.fDocumentUndoManager.resetProcessChangeState();
/* 298 */       this.fDocumentUndoManager.fireDocumentUndo(this.fStart, this.fText, this.fPreservedText, uiInfo, 8, false);
/* 299 */       return Status.OK_STATUS;
/*     */     } 
/* 301 */     return IOperationHistory.OPERATION_INVALID_STATUS;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void updateTextChange() {
/* 309 */     this.fText = this.fDocumentUndoManager.fTextBuffer.toString();
/* 310 */     this.fDocumentUndoManager.fTextBuffer.setLength(0);
/* 311 */     this.fPreservedText = this.fDocumentUndoManager.fPreservedTextBuffer.toString();
/* 312 */     this.fDocumentUndoManager.fPreservedTextBuffer.setLength(0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected UndoableTextChange createCurrent() {
/* 322 */     if (this.fDocumentUndoManager.fFoldingIntoCompoundChange) {
/* 323 */       return new DocumentUndoManager.UndoableCompoundTextChange(this.fDocumentUndoManager);
/*     */     }
/* 325 */     return new UndoableTextChange(this.fDocumentUndoManager);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void commit() {
/* 332 */     if (this.fStart < 0) {
/* 333 */       if (this.fDocumentUndoManager.fFoldingIntoCompoundChange) {
/* 334 */         this.fDocumentUndoManager.fCurrent = createCurrent();
/*     */       } else {
/* 336 */         reinitialize();
/*     */       } 
/*     */     } else {
/* 339 */       updateTextChange();
/* 340 */       this.fDocumentUndoManager.fCurrent = createCurrent();
/*     */     } 
/* 342 */     this.fDocumentUndoManager.resetProcessChangeState();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void pretendCommit() {
/* 350 */     if (this.fStart > -1) {
/* 351 */       this.fText = this.fDocumentUndoManager.fTextBuffer.toString();
/* 352 */       this.fPreservedText = this.fDocumentUndoManager.fPreservedTextBuffer.toString();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean attemptCommit() {
/* 364 */     pretendCommit();
/* 365 */     if (isValid()) {
/* 366 */       this.fDocumentUndoManager.commit();
/* 367 */       return true;
/*     */     } 
/* 369 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean isValid() {
/* 378 */     return (this.fStart > -1 && this.fEnd > -1 && this.fText != null);
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 383 */     String delimiter = ", ";
/* 384 */     StringBuilder text = new StringBuilder(super.toString());
/* 385 */     text.append("\n");
/* 386 */     text.append(getClass().getName());
/* 387 */     text.append(" undo modification stamp: ");
/* 388 */     text.append(this.fUndoModificationStamp);
/* 389 */     text.append(" redo modification stamp: ");
/* 390 */     text.append(this.fRedoModificationStamp);
/* 391 */     text.append(" start: ");
/* 392 */     text.append(this.fStart);
/* 393 */     text.append(delimiter);
/* 394 */     text.append("end: ");
/* 395 */     text.append(this.fEnd);
/* 396 */     text.append(delimiter);
/* 397 */     text.append("text: '");
/* 398 */     text.append(this.fText);
/* 399 */     text.append('\'');
/* 400 */     text.append(delimiter);
/* 401 */     text.append("preservedText: '");
/* 402 */     text.append(this.fPreservedText);
/* 403 */     text.append('\'');
/* 404 */     return text.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected long getUndoModificationStamp() {
/* 413 */     return this.fUndoModificationStamp;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected long getRedoModificationStamp() {
/* 422 */     return this.fRedoModificationStamp;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.text-3.13.0.jar!\org\eclipse\tex\\undo\DocumentUndoManager$UndoableTextChange.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */