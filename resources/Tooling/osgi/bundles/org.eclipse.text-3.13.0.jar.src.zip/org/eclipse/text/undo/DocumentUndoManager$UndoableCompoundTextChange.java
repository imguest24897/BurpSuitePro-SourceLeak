/*     */ package org.eclipse.text.undo;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.eclipse.core.runtime.IAdaptable;
/*     */ import org.eclipse.core.runtime.IProgressMonitor;
/*     */ import org.eclipse.core.runtime.IStatus;
/*     */ import org.eclipse.core.runtime.Status;
/*     */ import org.eclipse.jface.text.DocumentRewriteSession;
/*     */ import org.eclipse.jface.text.DocumentRewriteSessionType;
/*     */ import org.eclipse.jface.text.IDocumentExtension4;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class UndoableCompoundTextChange
/*     */   extends DocumentUndoManager.UndoableTextChange
/*     */ {
/* 434 */   private List<DocumentUndoManager.UndoableTextChange> fChanges = new ArrayList<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   UndoableCompoundTextChange(DocumentUndoManager manager) {
/* 442 */     super(manager);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void add(DocumentUndoManager.UndoableTextChange change) {
/* 451 */     this.fChanges.add(change);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public IStatus undo(IProgressMonitor monitor, IAdaptable uiInfo) {
/* 457 */     int size = this.fChanges.size();
/* 458 */     if (size > 0) {
/*     */ 
/*     */       
/* 461 */       DocumentUndoManager.UndoableTextChange c = this.fChanges.get(0);
/* 462 */       this.fDocumentUndoManager.fireDocumentUndo(c.fStart, c.fPreservedText, c.fText, uiInfo, 1, (size > 1));
/*     */       
/* 464 */       DocumentRewriteSession rewriteSession = null;
/* 465 */       if (size > 25 && this.fDocumentUndoManager.fDocument instanceof IDocumentExtension4 && (
/* 466 */         (IDocumentExtension4)this.fDocumentUndoManager.fDocument).getActiveRewriteSession() == null) {
/* 467 */         DocumentRewriteSessionType sessionType = (size > 1000) ? DocumentRewriteSessionType.UNRESTRICTED : DocumentRewriteSessionType.UNRESTRICTED_SMALL;
/* 468 */         rewriteSession = ((IDocumentExtension4)this.fDocumentUndoManager.fDocument).startRewriteSession(sessionType);
/*     */       } 
/*     */       
/* 471 */       for (int i = size - 1; i >= 0; i--) {
/* 472 */         c = this.fChanges.get(i);
/* 473 */         c.undoTextChange();
/*     */       } 
/*     */       
/* 476 */       if (rewriteSession != null) {
/* 477 */         ((IDocumentExtension4)this.fDocumentUndoManager.fDocument).stopRewriteSession(rewriteSession);
/*     */       }
/* 479 */       this.fDocumentUndoManager.resetProcessChangeState();
/* 480 */       this.fDocumentUndoManager.fireDocumentUndo(c.fStart, c.fPreservedText, c.fText, uiInfo, 
/* 481 */           4, (size > 1));
/*     */     } 
/* 483 */     return Status.OK_STATUS;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public IStatus redo(IProgressMonitor monitor, IAdaptable uiInfo) {
/* 489 */     int size = this.fChanges.size();
/* 490 */     if (size > 0) {
/*     */ 
/*     */       
/* 493 */       DocumentUndoManager.UndoableTextChange c = this.fChanges.get(size - 1);
/* 494 */       this.fDocumentUndoManager.fireDocumentUndo(c.fStart, c.fText, c.fPreservedText, uiInfo, 2, (size > 1));
/*     */       
/* 496 */       DocumentRewriteSession rewriteSession = null;
/* 497 */       if (size > 25 && this.fDocumentUndoManager.fDocument instanceof IDocumentExtension4 && (
/* 498 */         (IDocumentExtension4)this.fDocumentUndoManager.fDocument).getActiveRewriteSession() == null) {
/* 499 */         DocumentRewriteSessionType sessionType = (size > 1000) ? DocumentRewriteSessionType.UNRESTRICTED : DocumentRewriteSessionType.UNRESTRICTED_SMALL;
/* 500 */         rewriteSession = ((IDocumentExtension4)this.fDocumentUndoManager.fDocument).startRewriteSession(sessionType);
/*     */       } 
/*     */       
/* 503 */       for (int i = 0; i < size; i++) {
/* 504 */         c = this.fChanges.get(i);
/* 505 */         c.redoTextChange();
/*     */       } 
/*     */       
/* 508 */       if (rewriteSession != null) {
/* 509 */         ((IDocumentExtension4)this.fDocumentUndoManager.fDocument).stopRewriteSession(rewriteSession);
/*     */       }
/* 511 */       this.fDocumentUndoManager.resetProcessChangeState();
/* 512 */       this.fDocumentUndoManager.fireDocumentUndo(c.fStart, c.fText, c.fPreservedText, uiInfo, 8, (size > 1));
/*     */     } 
/*     */     
/* 515 */     return Status.OK_STATUS;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void updateTextChange() {
/* 521 */     super.updateTextChange();
/*     */ 
/*     */     
/* 524 */     DocumentUndoManager.UndoableTextChange c = new DocumentUndoManager.UndoableTextChange(this.fDocumentUndoManager);
/* 525 */     c.fStart = this.fStart;
/* 526 */     c.fEnd = this.fEnd;
/* 527 */     c.fText = this.fText;
/* 528 */     c.fPreservedText = this.fPreservedText;
/* 529 */     c.fUndoModificationStamp = this.fUndoModificationStamp;
/* 530 */     c.fRedoModificationStamp = this.fRedoModificationStamp;
/* 531 */     add(c);
/*     */ 
/*     */     
/* 534 */     reinitialize();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected DocumentUndoManager.UndoableTextChange createCurrent() {
/* 540 */     if (!this.fDocumentUndoManager.fFoldingIntoCompoundChange) {
/* 541 */       return new DocumentUndoManager.UndoableTextChange(this.fDocumentUndoManager);
/*     */     }
/*     */     
/* 544 */     reinitialize();
/* 545 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void commit() {
/* 551 */     if (this.fStart > -1) {
/* 552 */       updateTextChange();
/*     */     }
/* 554 */     this.fDocumentUndoManager.fCurrent = createCurrent();
/* 555 */     this.fDocumentUndoManager.resetProcessChangeState();
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean isValid() {
/* 560 */     return !(this.fStart <= -1 && this.fChanges.isEmpty());
/*     */   }
/*     */ 
/*     */   
/*     */   protected long getUndoModificationStamp() {
/* 565 */     if (this.fStart > -1)
/* 566 */       return super.getUndoModificationStamp(); 
/* 567 */     if (!this.fChanges.isEmpty()) {
/* 568 */       return ((DocumentUndoManager.UndoableTextChange)this.fChanges.get(0))
/* 569 */         .getUndoModificationStamp();
/*     */     }
/*     */     
/* 572 */     return this.fUndoModificationStamp;
/*     */   }
/*     */ 
/*     */   
/*     */   protected long getRedoModificationStamp() {
/* 577 */     if (this.fStart > -1)
/* 578 */       return super.getRedoModificationStamp(); 
/* 579 */     if (!this.fChanges.isEmpty()) {
/* 580 */       return ((DocumentUndoManager.UndoableTextChange)this.fChanges.get(this.fChanges.size() - 1))
/* 581 */         .getRedoModificationStamp();
/*     */     }
/*     */     
/* 584 */     return this.fRedoModificationStamp;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.text-3.13.0.jar!\org\eclipse\tex\\undo\DocumentUndoManager$UndoableCompoundTextChange.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */