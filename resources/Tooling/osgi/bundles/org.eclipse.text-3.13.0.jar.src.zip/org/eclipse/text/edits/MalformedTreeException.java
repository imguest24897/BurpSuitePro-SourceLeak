/*    */ package org.eclipse.text.edits;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MalformedTreeException
/*    */   extends RuntimeException
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   private TextEdit fParent;
/*    */   private TextEdit fChild;
/*    */   
/*    */   public MalformedTreeException(TextEdit parent, TextEdit child, String message) {
/* 45 */     super(message);
/* 46 */     this.fParent = parent;
/* 47 */     this.fChild = child;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public TextEdit getParent() {
/* 56 */     return this.fParent;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public TextEdit getChild() {
/* 65 */     return this.fChild;
/*    */   }
/*    */   
/*    */   void setParent(TextEdit parent) {
/* 69 */     this.fParent = parent;
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.text-3.13.0.jar!\org\eclipse\text\edits\MalformedTreeException.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */