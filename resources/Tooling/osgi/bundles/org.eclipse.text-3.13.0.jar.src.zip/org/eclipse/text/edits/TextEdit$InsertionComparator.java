/*     */ package org.eclipse.text.edits;
/*     */ 
/*     */ import java.util.Comparator;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class InsertionComparator
/*     */   implements Comparator<TextEdit>
/*     */ {
/*     */   public int compare(TextEdit edit1, TextEdit edit2) throws MalformedTreeException {
/* 111 */     int offset1 = edit1.getOffset();
/* 112 */     int length1 = edit1.getLength();
/*     */     
/* 114 */     int offset2 = edit2.getOffset();
/* 115 */     int length2 = edit2.getLength();
/*     */     
/* 117 */     if (offset1 == offset2 && length1 == 0 && length2 == 0) {
/* 118 */       return 0;
/*     */     }
/* 120 */     if (offset1 + length1 <= offset2) {
/* 121 */       return -1;
/*     */     }
/* 123 */     if (offset2 + length2 <= offset1) {
/* 124 */       return 1;
/*     */     }
/* 126 */     throw new MalformedTreeException(
/* 127 */         null, edit1, 
/* 128 */         TextEditMessages.getString("TextEdit.overlapping"));
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.text-3.13.0.jar!\org\eclipse\text\edits\TextEdit$InsertionComparator.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */