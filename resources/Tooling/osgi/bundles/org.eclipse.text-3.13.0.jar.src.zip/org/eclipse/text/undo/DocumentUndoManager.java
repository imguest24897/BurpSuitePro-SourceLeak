/*      */ package org.eclipse.text.undo;
/*      */ 
/*      */ import java.util.ArrayList;
/*      */ import java.util.List;
/*      */ import org.eclipse.core.commands.ExecutionException;
/*      */ import org.eclipse.core.commands.operations.AbstractOperation;
/*      */ import org.eclipse.core.commands.operations.IContextReplacingOperation;
/*      */ import org.eclipse.core.commands.operations.IOperationHistory;
/*      */ import org.eclipse.core.commands.operations.IOperationHistoryListener;
/*      */ import org.eclipse.core.commands.operations.IUndoContext;
/*      */ import org.eclipse.core.commands.operations.IUndoableOperation;
/*      */ import org.eclipse.core.commands.operations.ObjectUndoContext;
/*      */ import org.eclipse.core.commands.operations.OperationHistoryEvent;
/*      */ import org.eclipse.core.commands.operations.OperationHistoryFactory;
/*      */ import org.eclipse.core.runtime.Assert;
/*      */ import org.eclipse.core.runtime.IAdaptable;
/*      */ import org.eclipse.core.runtime.IProgressMonitor;
/*      */ import org.eclipse.core.runtime.IStatus;
/*      */ import org.eclipse.core.runtime.ListenerList;
/*      */ import org.eclipse.core.runtime.Status;
/*      */ import org.eclipse.jface.text.BadLocationException;
/*      */ import org.eclipse.jface.text.DocumentEvent;
/*      */ import org.eclipse.jface.text.DocumentRewriteSession;
/*      */ import org.eclipse.jface.text.DocumentRewriteSessionType;
/*      */ import org.eclipse.jface.text.IDocument;
/*      */ import org.eclipse.jface.text.IDocumentExtension4;
/*      */ import org.eclipse.jface.text.IDocumentListener;
/*      */ import org.eclipse.jface.text.TextUtilities;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class DocumentUndoManager
/*      */   implements IDocumentUndoManager
/*      */ {
/*      */   private ObjectUndoContext fUndoContext;
/*      */   private IDocument fDocument;
/*      */   private UndoableTextChange fCurrent;
/*      */   private DocumentListener fDocumentListener;
/*      */   
/*      */   private static class UndoableTextChange
/*      */     extends AbstractOperation
/*      */   {
/*   83 */     protected int fStart = -1;
/*      */ 
/*      */     
/*   86 */     protected int fEnd = -1;
/*      */ 
/*      */     
/*      */     protected String fText;
/*      */ 
/*      */     
/*      */     protected String fPreservedText;
/*      */ 
/*      */     
/*   95 */     protected long fUndoModificationStamp = -1L;
/*      */ 
/*      */     
/*   98 */     protected long fRedoModificationStamp = -1L;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     protected DocumentUndoManager fDocumentUndoManager;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     UndoableTextChange(DocumentUndoManager manager) {
/*  109 */       super(UndoMessages.getString("DocumentUndoManager.operationLabel"));
/*  110 */       this.fDocumentUndoManager = manager;
/*  111 */       addContext(manager.getUndoContext());
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     protected void reinitialize() {
/*  118 */       this.fStart = this.fEnd = -1;
/*  119 */       this.fText = this.fPreservedText = null;
/*  120 */       this.fUndoModificationStamp = -1L;
/*  121 */       this.fRedoModificationStamp = -1L;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     protected void set(int start, int end) {
/*  131 */       this.fStart = start;
/*  132 */       this.fEnd = end;
/*  133 */       this.fText = null;
/*  134 */       this.fPreservedText = null;
/*      */     }
/*      */ 
/*      */     
/*      */     public void dispose() {
/*  139 */       reinitialize();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     protected void undoTextChange() {
/*      */       try {
/*  147 */         if (this.fDocumentUndoManager.fDocument instanceof IDocumentExtension4) {
/*  148 */           ((IDocumentExtension4)this.fDocumentUndoManager.fDocument).replace(this.fStart, this.fText
/*  149 */               .length(), this.fPreservedText, this.fUndoModificationStamp);
/*      */         } else {
/*  151 */           this.fDocumentUndoManager.fDocument.replace(this.fStart, this.fText.length(), 
/*  152 */               this.fPreservedText);
/*      */         } 
/*  154 */       } catch (BadLocationException badLocationException) {}
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public boolean canUndo() {
/*  160 */       if (isValid()) {
/*  161 */         if (this.fDocumentUndoManager.fDocument instanceof IDocumentExtension4) {
/*  162 */           long docStamp = ((IDocumentExtension4)this.fDocumentUndoManager.fDocument)
/*  163 */             .getModificationStamp();
/*      */ 
/*      */ 
/*      */           
/*  167 */           boolean canUndo = !(docStamp != -1L && 
/*  168 */             docStamp < getRedoModificationStamp());
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  183 */           if (!canUndo && 
/*  184 */             this == this.fDocumentUndoManager.fHistory
/*  185 */             .getUndoOperation((IUndoContext)this.fDocumentUndoManager.fUndoContext))
/*      */           {
/*  187 */             if (this != this.fDocumentUndoManager.fCurrent)
/*      */             {
/*  189 */               if (!this.fDocumentUndoManager.fCurrent.isValid())
/*      */               {
/*      */                 
/*  192 */                 if (this.fDocumentUndoManager.fCurrent.fUndoModificationStamp != 
/*      */                   
/*  194 */                   -1L) {
/*  195 */                   canUndo = (this.fDocumentUndoManager.fCurrent.fRedoModificationStamp == docStamp);
/*      */                 }
/*      */               }
/*      */             }
/*      */           }
/*      */ 
/*      */ 
/*      */           
/*  203 */           if (!canUndo && 
/*  204 */             this == this.fDocumentUndoManager.fHistory
/*  205 */             .getUndoOperation((IUndoContext)this.fDocumentUndoManager.fUndoContext))
/*      */           {
/*  207 */             if (this instanceof DocumentUndoManager.UndoableCompoundTextChange && 
/*  208 */               this == this.fDocumentUndoManager.fCurrent)
/*      */             {
/*  210 */               if (this.fStart == -1)
/*      */               {
/*  212 */                 if (this.fDocumentUndoManager.fCurrent.fRedoModificationStamp != -1L)
/*      */                 {
/*  214 */                   canUndo = (this.fDocumentUndoManager.fCurrent.fRedoModificationStamp == docStamp); }  }  } 
/*      */           }
/*  216 */           return canUndo;
/*      */         } 
/*      */ 
/*      */ 
/*      */         
/*  221 */         return true;
/*      */       } 
/*  223 */       return false;
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean canRedo() {
/*  228 */       if (isValid()) {
/*  229 */         if (this.fDocumentUndoManager.fDocument instanceof IDocumentExtension4) {
/*  230 */           long docStamp = ((IDocumentExtension4)this.fDocumentUndoManager.fDocument)
/*  231 */             .getModificationStamp();
/*  232 */           return !(docStamp != -1L && 
/*  233 */             docStamp != getUndoModificationStamp());
/*      */         } 
/*      */ 
/*      */         
/*  237 */         return true;
/*      */       } 
/*  239 */       return false;
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean canExecute() {
/*  244 */       return this.fDocumentUndoManager.isConnected();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public IStatus execute(IProgressMonitor monitor, IAdaptable uiInfo) {
/*  251 */       return Status.OK_STATUS;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public IStatus undo(IProgressMonitor monitor, IAdaptable uiInfo) {
/*  260 */       if (isValid()) {
/*  261 */         this.fDocumentUndoManager.fireDocumentUndo(this.fStart, this.fPreservedText, this.fText, uiInfo, 1, false);
/*  262 */         undoTextChange();
/*  263 */         this.fDocumentUndoManager.resetProcessChangeState();
/*  264 */         this.fDocumentUndoManager.fireDocumentUndo(this.fStart, this.fPreservedText, this.fText, uiInfo, 4, false);
/*  265 */         return Status.OK_STATUS;
/*      */       } 
/*  267 */       return IOperationHistory.OPERATION_INVALID_STATUS;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     protected void redoTextChange() {
/*      */       try {
/*  275 */         if (this.fDocumentUndoManager.fDocument instanceof IDocumentExtension4) {
/*  276 */           ((IDocumentExtension4)this.fDocumentUndoManager.fDocument).replace(this.fStart, this.fEnd - this.fStart, this.fText, this.fRedoModificationStamp);
/*      */         } else {
/*  278 */           this.fDocumentUndoManager.fDocument.replace(this.fStart, this.fEnd - this.fStart, this.fText);
/*      */         } 
/*  280 */       } catch (BadLocationException badLocationException) {}
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public IStatus redo(IProgressMonitor monitor, IAdaptable uiInfo) {
/*  294 */       if (isValid()) {
/*  295 */         this.fDocumentUndoManager.fireDocumentUndo(this.fStart, this.fText, this.fPreservedText, uiInfo, 2, false);
/*  296 */         redoTextChange();
/*  297 */         this.fDocumentUndoManager.resetProcessChangeState();
/*  298 */         this.fDocumentUndoManager.fireDocumentUndo(this.fStart, this.fText, this.fPreservedText, uiInfo, 8, false);
/*  299 */         return Status.OK_STATUS;
/*      */       } 
/*  301 */       return IOperationHistory.OPERATION_INVALID_STATUS;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     protected void updateTextChange() {
/*  309 */       this.fText = this.fDocumentUndoManager.fTextBuffer.toString();
/*  310 */       this.fDocumentUndoManager.fTextBuffer.setLength(0);
/*  311 */       this.fPreservedText = this.fDocumentUndoManager.fPreservedTextBuffer.toString();
/*  312 */       this.fDocumentUndoManager.fPreservedTextBuffer.setLength(0);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     protected UndoableTextChange createCurrent() {
/*  322 */       if (this.fDocumentUndoManager.fFoldingIntoCompoundChange) {
/*  323 */         return new DocumentUndoManager.UndoableCompoundTextChange(this.fDocumentUndoManager);
/*      */       }
/*  325 */       return new UndoableTextChange(this.fDocumentUndoManager);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     protected void commit() {
/*  332 */       if (this.fStart < 0) {
/*  333 */         if (this.fDocumentUndoManager.fFoldingIntoCompoundChange) {
/*  334 */           this.fDocumentUndoManager.fCurrent = createCurrent();
/*      */         } else {
/*  336 */           reinitialize();
/*      */         } 
/*      */       } else {
/*  339 */         updateTextChange();
/*  340 */         this.fDocumentUndoManager.fCurrent = createCurrent();
/*      */       } 
/*  342 */       this.fDocumentUndoManager.resetProcessChangeState();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     protected void pretendCommit() {
/*  350 */       if (this.fStart > -1) {
/*  351 */         this.fText = this.fDocumentUndoManager.fTextBuffer.toString();
/*  352 */         this.fPreservedText = this.fDocumentUndoManager.fPreservedTextBuffer.toString();
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     protected boolean attemptCommit() {
/*  364 */       pretendCommit();
/*  365 */       if (isValid()) {
/*  366 */         this.fDocumentUndoManager.commit();
/*  367 */         return true;
/*      */       } 
/*  369 */       return false;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     protected boolean isValid() {
/*  378 */       return (this.fStart > -1 && this.fEnd > -1 && this.fText != null);
/*      */     }
/*      */ 
/*      */     
/*      */     public String toString() {
/*  383 */       String delimiter = ", ";
/*  384 */       StringBuilder text = new StringBuilder(super.toString());
/*  385 */       text.append("\n");
/*  386 */       text.append(getClass().getName());
/*  387 */       text.append(" undo modification stamp: ");
/*  388 */       text.append(this.fUndoModificationStamp);
/*  389 */       text.append(" redo modification stamp: ");
/*  390 */       text.append(this.fRedoModificationStamp);
/*  391 */       text.append(" start: ");
/*  392 */       text.append(this.fStart);
/*  393 */       text.append(delimiter);
/*  394 */       text.append("end: ");
/*  395 */       text.append(this.fEnd);
/*  396 */       text.append(delimiter);
/*  397 */       text.append("text: '");
/*  398 */       text.append(this.fText);
/*  399 */       text.append('\'');
/*  400 */       text.append(delimiter);
/*  401 */       text.append("preservedText: '");
/*  402 */       text.append(this.fPreservedText);
/*  403 */       text.append('\'');
/*  404 */       return text.toString();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     protected long getUndoModificationStamp() {
/*  413 */       return this.fUndoModificationStamp;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     protected long getRedoModificationStamp() {
/*  422 */       return this.fRedoModificationStamp;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static class UndoableCompoundTextChange
/*      */     extends UndoableTextChange
/*      */   {
/*  434 */     private List<DocumentUndoManager.UndoableTextChange> fChanges = new ArrayList<>();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     UndoableCompoundTextChange(DocumentUndoManager manager) {
/*  442 */       super(manager);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     protected void add(DocumentUndoManager.UndoableTextChange change) {
/*  451 */       this.fChanges.add(change);
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public IStatus undo(IProgressMonitor monitor, IAdaptable uiInfo) {
/*  457 */       int size = this.fChanges.size();
/*  458 */       if (size > 0) {
/*      */ 
/*      */         
/*  461 */         DocumentUndoManager.UndoableTextChange c = this.fChanges.get(0);
/*  462 */         this.fDocumentUndoManager.fireDocumentUndo(c.fStart, c.fPreservedText, c.fText, uiInfo, 1, (size > 1));
/*      */         
/*  464 */         DocumentRewriteSession rewriteSession = null;
/*  465 */         if (size > 25 && this.fDocumentUndoManager.fDocument instanceof IDocumentExtension4 && (
/*  466 */           (IDocumentExtension4)this.fDocumentUndoManager.fDocument).getActiveRewriteSession() == null) {
/*  467 */           DocumentRewriteSessionType sessionType = (size > 1000) ? DocumentRewriteSessionType.UNRESTRICTED : DocumentRewriteSessionType.UNRESTRICTED_SMALL;
/*  468 */           rewriteSession = ((IDocumentExtension4)this.fDocumentUndoManager.fDocument).startRewriteSession(sessionType);
/*      */         } 
/*      */         
/*  471 */         for (int i = size - 1; i >= 0; i--) {
/*  472 */           c = this.fChanges.get(i);
/*  473 */           c.undoTextChange();
/*      */         } 
/*      */         
/*  476 */         if (rewriteSession != null) {
/*  477 */           ((IDocumentExtension4)this.fDocumentUndoManager.fDocument).stopRewriteSession(rewriteSession);
/*      */         }
/*  479 */         this.fDocumentUndoManager.resetProcessChangeState();
/*  480 */         this.fDocumentUndoManager.fireDocumentUndo(c.fStart, c.fPreservedText, c.fText, uiInfo, 
/*  481 */             4, (size > 1));
/*      */       } 
/*  483 */       return Status.OK_STATUS;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public IStatus redo(IProgressMonitor monitor, IAdaptable uiInfo) {
/*  489 */       int size = this.fChanges.size();
/*  490 */       if (size > 0) {
/*      */ 
/*      */         
/*  493 */         DocumentUndoManager.UndoableTextChange c = this.fChanges.get(size - 1);
/*  494 */         this.fDocumentUndoManager.fireDocumentUndo(c.fStart, c.fText, c.fPreservedText, uiInfo, 2, (size > 1));
/*      */         
/*  496 */         DocumentRewriteSession rewriteSession = null;
/*  497 */         if (size > 25 && this.fDocumentUndoManager.fDocument instanceof IDocumentExtension4 && (
/*  498 */           (IDocumentExtension4)this.fDocumentUndoManager.fDocument).getActiveRewriteSession() == null) {
/*  499 */           DocumentRewriteSessionType sessionType = (size > 1000) ? DocumentRewriteSessionType.UNRESTRICTED : DocumentRewriteSessionType.UNRESTRICTED_SMALL;
/*  500 */           rewriteSession = ((IDocumentExtension4)this.fDocumentUndoManager.fDocument).startRewriteSession(sessionType);
/*      */         } 
/*      */         
/*  503 */         for (int i = 0; i < size; i++) {
/*  504 */           c = this.fChanges.get(i);
/*  505 */           c.redoTextChange();
/*      */         } 
/*      */         
/*  508 */         if (rewriteSession != null) {
/*  509 */           ((IDocumentExtension4)this.fDocumentUndoManager.fDocument).stopRewriteSession(rewriteSession);
/*      */         }
/*  511 */         this.fDocumentUndoManager.resetProcessChangeState();
/*  512 */         this.fDocumentUndoManager.fireDocumentUndo(c.fStart, c.fText, c.fPreservedText, uiInfo, 8, (size > 1));
/*      */       } 
/*      */       
/*  515 */       return Status.OK_STATUS;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     protected void updateTextChange() {
/*  521 */       super.updateTextChange();
/*      */ 
/*      */       
/*  524 */       DocumentUndoManager.UndoableTextChange c = new DocumentUndoManager.UndoableTextChange(this.fDocumentUndoManager);
/*  525 */       c.fStart = this.fStart;
/*  526 */       c.fEnd = this.fEnd;
/*  527 */       c.fText = this.fText;
/*  528 */       c.fPreservedText = this.fPreservedText;
/*  529 */       c.fUndoModificationStamp = this.fUndoModificationStamp;
/*  530 */       c.fRedoModificationStamp = this.fRedoModificationStamp;
/*  531 */       add(c);
/*      */ 
/*      */       
/*  534 */       reinitialize();
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     protected DocumentUndoManager.UndoableTextChange createCurrent() {
/*  540 */       if (!this.fDocumentUndoManager.fFoldingIntoCompoundChange) {
/*  541 */         return new DocumentUndoManager.UndoableTextChange(this.fDocumentUndoManager);
/*      */       }
/*      */       
/*  544 */       reinitialize();
/*  545 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     protected void commit() {
/*  551 */       if (this.fStart > -1) {
/*  552 */         updateTextChange();
/*      */       }
/*  554 */       this.fDocumentUndoManager.fCurrent = createCurrent();
/*  555 */       this.fDocumentUndoManager.resetProcessChangeState();
/*      */     }
/*      */ 
/*      */     
/*      */     protected boolean isValid() {
/*  560 */       return !(this.fStart <= -1 && this.fChanges.isEmpty());
/*      */     }
/*      */ 
/*      */     
/*      */     protected long getUndoModificationStamp() {
/*  565 */       if (this.fStart > -1)
/*  566 */         return super.getUndoModificationStamp(); 
/*  567 */       if (!this.fChanges.isEmpty()) {
/*  568 */         return ((DocumentUndoManager.UndoableTextChange)this.fChanges.get(0))
/*  569 */           .getUndoModificationStamp();
/*      */       }
/*      */       
/*  572 */       return this.fUndoModificationStamp;
/*      */     }
/*      */ 
/*      */     
/*      */     protected long getRedoModificationStamp() {
/*  577 */       if (this.fStart > -1)
/*  578 */         return super.getRedoModificationStamp(); 
/*  579 */       if (!this.fChanges.isEmpty()) {
/*  580 */         return ((DocumentUndoManager.UndoableTextChange)this.fChanges.get(this.fChanges.size() - 1))
/*  581 */           .getRedoModificationStamp();
/*      */       }
/*      */       
/*  584 */       return this.fRedoModificationStamp;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private class DocumentListener
/*      */     implements IDocumentListener
/*      */   {
/*      */     private String fReplacedText;
/*      */ 
/*      */ 
/*      */     
/*      */     public void documentAboutToBeChanged(DocumentEvent event) {
/*      */       try {
/*  599 */         this.fReplacedText = event.getDocument().get(event.getOffset(), 
/*  600 */             event.getLength());
/*  601 */         DocumentUndoManager.this.fPreservedUndoModificationStamp = event.getModificationStamp();
/*  602 */       } catch (BadLocationException badLocationException) {
/*  603 */         this.fReplacedText = null;
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     public void documentChanged(DocumentEvent event) {
/*  609 */       long fPreservedRedoModificationStamp = event.getModificationStamp();
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  614 */       IUndoableOperation op = DocumentUndoManager.this.fHistory.getUndoOperation((IUndoContext)DocumentUndoManager.this.fUndoContext);
/*  615 */       boolean wasValid = false;
/*  616 */       if (op != null) {
/*  617 */         wasValid = op.canUndo();
/*      */       }
/*      */       
/*  620 */       DocumentUndoManager.this.processChange(event.getOffset(), event.getOffset() + 
/*  621 */           event.getLength(), event.getText(), this.fReplacedText, 
/*  622 */           DocumentUndoManager.this.fPreservedUndoModificationStamp, 
/*  623 */           fPreservedRedoModificationStamp);
/*      */ 
/*      */ 
/*      */       
/*  627 */       DocumentUndoManager.this.fCurrent.pretendCommit();
/*      */       
/*  629 */       if (op == DocumentUndoManager.this.fCurrent) {
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  634 */         if (wasValid != DocumentUndoManager.this.fCurrent.isValid()) {
/*  635 */           DocumentUndoManager.this.fHistory.operationChanged(op);
/*      */ 
/*      */         
/*      */         }
/*      */ 
/*      */       
/*      */       }
/*  642 */       else if (DocumentUndoManager.this.fCurrent != DocumentUndoManager.this.fLastAddedTextEdit && DocumentUndoManager.this.fCurrent.isValid()) {
/*  643 */         DocumentUndoManager.this.addToOperationHistory(DocumentUndoManager.this.fCurrent);
/*      */       } 
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private class HistoryListener
/*      */     implements IOperationHistoryListener
/*      */   {
/*      */     private IUndoableOperation fOperation;
/*      */ 
/*      */ 
/*      */     
/*      */     public void historyNotification(OperationHistoryEvent event) {
/*  658 */       int type = event.getEventType();
/*  659 */       switch (type) {
/*      */         
/*      */         case 2:
/*      */         case 3:
/*  663 */           if (event.getOperation().hasContext((IUndoContext)DocumentUndoManager.this.fUndoContext)) {
/*      */ 
/*      */ 
/*      */             
/*  667 */             if (event.getOperation() instanceof DocumentUndoManager.UndoableTextChange) {
/*  668 */               DocumentUndoManager.this.listenToTextChanges(false);
/*      */ 
/*      */               
/*  671 */               if (type == 3 && 
/*  672 */                 DocumentUndoManager.this.fFoldingIntoCompoundChange) {
/*  673 */                 DocumentUndoManager.this.endCompoundChange();
/*      */               
/*      */               }
/*      */             
/*      */             }
/*      */             else {
/*      */               
/*  680 */               DocumentUndoManager.this.commit();
/*  681 */               DocumentUndoManager.this.fLastAddedTextEdit = null;
/*      */             } 
/*  683 */             this.fOperation = event.getOperation();
/*      */           } 
/*      */           break;
/*      */         case 7:
/*      */         case 9:
/*      */         case 10:
/*  689 */           if (event.getOperation() == this.fOperation) {
/*  690 */             DocumentUndoManager.this.listenToTextChanges(true);
/*  691 */             this.fOperation = null;
/*      */           } 
/*      */           break;
/*      */       } 
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean fFoldingIntoCompoundChange = false;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private IOperationHistory fHistory;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private IOperationHistoryListener fHistoryListener;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  741 */   private UndoableTextChange fLastAddedTextEdit = null;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private StringBuilder fPreservedTextBuffer;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  751 */   private long fPreservedUndoModificationStamp = -1L;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private UndoableTextChange fPreviousDelete;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private StringBuilder fTextBuffer;
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean fInserting = false;
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean fOverwriting = false;
/*      */ 
/*      */ 
/*      */   
/*      */   private ListenerList<IDocumentUndoListener> fDocumentUndoListeners;
/*      */ 
/*      */ 
/*      */   
/*      */   private List<Object> fConnected;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public DocumentUndoManager(IDocument document) {
/*  783 */     Assert.isNotNull(document);
/*  784 */     this.fDocument = document;
/*  785 */     this.fHistory = OperationHistoryFactory.getOperationHistory();
/*  786 */     this.fUndoContext = new ObjectUndoContext(this.fDocument);
/*  787 */     this.fConnected = new ArrayList();
/*  788 */     this.fDocumentUndoListeners = new ListenerList(1);
/*      */   }
/*      */ 
/*      */   
/*      */   public void addDocumentUndoListener(IDocumentUndoListener listener) {
/*  793 */     this.fDocumentUndoListeners.add(listener);
/*      */   }
/*      */ 
/*      */   
/*      */   public void removeDocumentUndoListener(IDocumentUndoListener listener) {
/*  798 */     this.fDocumentUndoListeners.remove(listener);
/*      */   }
/*      */ 
/*      */   
/*      */   public IUndoContext getUndoContext() {
/*  803 */     return (IUndoContext)this.fUndoContext;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void commit() {
/*  811 */     if (this.fLastAddedTextEdit != this.fCurrent) {
/*  812 */       this.fCurrent.pretendCommit();
/*  813 */       if (this.fCurrent.isValid()) {
/*  814 */         addToOperationHistory(this.fCurrent);
/*      */       }
/*      */     } 
/*  817 */     this.fCurrent.commit();
/*      */   }
/*      */ 
/*      */   
/*      */   public void reset() {
/*  822 */     if (isConnected()) {
/*  823 */       shutdown();
/*  824 */       initialize();
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean redoable() {
/*  830 */     return OperationHistoryFactory.getOperationHistory().canRedo((IUndoContext)this.fUndoContext);
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean undoable() {
/*  835 */     return OperationHistoryFactory.getOperationHistory().canUndo((IUndoContext)this.fUndoContext);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void redo() throws ExecutionException {
/*  843 */     if (isConnected() && redoable()) {
/*  844 */       OperationHistoryFactory.getOperationHistory().redo(getUndoContext(), null, null);
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   public void undo() throws ExecutionException {
/*  850 */     if (undoable()) {
/*  851 */       OperationHistoryFactory.getOperationHistory().undo((IUndoContext)this.fUndoContext, null, null);
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   public void connect(Object client) {
/*  857 */     if (!isConnected()) {
/*  858 */       initialize();
/*      */     }
/*  860 */     if (!this.fConnected.contains(client)) {
/*  861 */       this.fConnected.add(client);
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   public void disconnect(Object client) {
/*  867 */     this.fConnected.remove(client);
/*  868 */     if (!isConnected()) {
/*  869 */       shutdown();
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   public void beginCompoundChange() {
/*  875 */     if (isConnected()) {
/*  876 */       this.fFoldingIntoCompoundChange = true;
/*  877 */       commit();
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public void endCompoundChange() {
/*  883 */     if (isConnected()) {
/*  884 */       this.fFoldingIntoCompoundChange = false;
/*  885 */       commit();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setMaximalUndoLevel(int undoLimit) {
/*  894 */     this.fHistory.setLimit((IUndoContext)this.fUndoContext, undoLimit);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void fireDocumentUndo(int offset, String text, String preservedText, Object source, int eventType, boolean isCompound) {
/*  910 */     eventType = isCompound ? (eventType | 0x10) : eventType;
/*  911 */     DocumentUndoEvent event = new DocumentUndoEvent(this.fDocument, offset, text, preservedText, eventType, source);
/*  912 */     for (IDocumentUndoListener listener : this.fDocumentUndoListeners) {
/*  913 */       listener.documentUndoNotification(event);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void addListeners() {
/*  922 */     this.fHistoryListener = new HistoryListener();
/*  923 */     this.fHistory.addOperationHistoryListener(this.fHistoryListener);
/*  924 */     listenToTextChanges(true);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void removeListeners() {
/*  931 */     listenToTextChanges(false);
/*  932 */     this.fHistory.removeOperationHistoryListener(this.fHistoryListener);
/*  933 */     this.fHistoryListener = null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void addToOperationHistory(UndoableTextChange edit) {
/*  942 */     if (!this.fFoldingIntoCompoundChange || 
/*  943 */       edit instanceof UndoableCompoundTextChange) {
/*  944 */       this.fHistory.add((IUndoableOperation)edit);
/*  945 */       this.fLastAddedTextEdit = edit;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void disposeUndoHistory() {
/*  953 */     this.fHistory.dispose((IUndoContext)this.fUndoContext, true, true, true);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void initializeUndoHistory() {
/*  960 */     if (this.fHistory != null && this.fUndoContext != null) {
/*  961 */       this.fHistory.dispose((IUndoContext)this.fUndoContext, true, true, false);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean isWhitespaceText(String text) {
/*  976 */     if (text == null || text.isEmpty()) {
/*  977 */       return false;
/*      */     }
/*      */     
/*  980 */     String[] delimiters = this.fDocument.getLegalLineDelimiters();
/*  981 */     int index = TextUtilities.startsWith(delimiters, text);
/*  982 */     if (index > -1) {
/*      */       
/*  984 */       int length = text.length();
/*  985 */       for (int i = delimiters[index].length(); i < length; i++) {
/*  986 */         char c = text.charAt(i);
/*  987 */         if (c != ' ' && c != '\t') {
/*  988 */           return false;
/*      */         }
/*      */       } 
/*  991 */       return true;
/*      */     } 
/*      */     
/*  994 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void listenToTextChanges(boolean listen) {
/* 1003 */     if (listen) {
/* 1004 */       if (this.fDocumentListener == null && this.fDocument != null) {
/* 1005 */         this.fDocumentListener = new DocumentListener();
/* 1006 */         this.fDocument.addDocumentListener(this.fDocumentListener);
/*      */       } 
/* 1008 */     } else if (!listen && 
/* 1009 */       this.fDocumentListener != null && this.fDocument != null) {
/* 1010 */       this.fDocument.removeDocumentListener(this.fDocumentListener);
/* 1011 */       this.fDocumentListener = null;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void processChange(int modelStart, int modelEnd, String insertedText, String replacedText, long beforeChangeModificationStamp, long afterChangeModificationStamp) {
/* 1021 */     if (insertedText == null)
/*      */     {
/* 1023 */       insertedText = "";
/*      */     }
/*      */     
/* 1026 */     if (replacedText == null)
/*      */     {
/* 1028 */       replacedText = "";
/*      */     }
/*      */     
/* 1031 */     int length = insertedText.length();
/* 1032 */     int diff = modelEnd - modelStart;
/*      */     
/* 1034 */     if (this.fCurrent.fUndoModificationStamp == -1L) {
/* 1035 */       this.fCurrent.fUndoModificationStamp = beforeChangeModificationStamp;
/*      */     }
/*      */ 
/*      */     
/* 1039 */     if (diff < 0) {
/* 1040 */       int tmp = modelEnd;
/* 1041 */       modelEnd = modelStart;
/* 1042 */       modelStart = tmp;
/*      */     } 
/*      */     
/* 1045 */     if (modelStart == modelEnd) {
/*      */       
/* 1047 */       if (length == 1 || isWhitespaceText(insertedText)) {
/*      */         
/* 1049 */         if (!this.fInserting || 
/* 1050 */           modelStart != this.fCurrent.fStart + 
/* 1051 */           this.fTextBuffer.length()) {
/* 1052 */           this.fCurrent.fRedoModificationStamp = beforeChangeModificationStamp;
/* 1053 */           if (this.fCurrent.attemptCommit()) {
/* 1054 */             this.fCurrent.fUndoModificationStamp = beforeChangeModificationStamp;
/*      */           }
/*      */           
/* 1057 */           this.fInserting = true;
/*      */         } 
/* 1059 */         if (this.fCurrent.fStart < 0) {
/* 1060 */           this.fCurrent.fStart = this.fCurrent.fEnd = modelStart;
/*      */         }
/* 1062 */         if (length > 0) {
/* 1063 */           this.fTextBuffer.append(insertedText);
/*      */         }
/* 1065 */       } else if (length > 0) {
/*      */         
/* 1067 */         this.fCurrent.fRedoModificationStamp = beforeChangeModificationStamp;
/* 1068 */         if (this.fCurrent.attemptCommit()) {
/* 1069 */           this.fCurrent.fUndoModificationStamp = beforeChangeModificationStamp;
/*      */         }
/*      */         
/* 1072 */         this.fCurrent.fStart = this.fCurrent.fEnd = modelStart;
/* 1073 */         this.fTextBuffer.append(insertedText);
/* 1074 */         this.fCurrent.fRedoModificationStamp = afterChangeModificationStamp;
/* 1075 */         if (this.fCurrent.attemptCommit()) {
/* 1076 */           this.fCurrent.fUndoModificationStamp = afterChangeModificationStamp;
/*      */         }
/*      */       }
/*      */     
/*      */     }
/* 1081 */     else if (length == 0) {
/*      */ 
/*      */       
/* 1084 */       length = replacedText.length();
/* 1085 */       String[] delimiters = this.fDocument.getLegalLineDelimiters();
/*      */       
/* 1087 */       if (length == 1 || 
/* 1088 */         TextUtilities.equals(delimiters, replacedText) > -1)
/*      */       {
/*      */ 
/*      */         
/* 1092 */         if (this.fPreviousDelete.fStart == modelStart && 
/* 1093 */           this.fPreviousDelete.fEnd == modelEnd) {
/*      */ 
/*      */ 
/*      */           
/* 1097 */           if (this.fCurrent.fStart == modelEnd && 
/* 1098 */             this.fCurrent.fEnd == modelStart) {
/* 1099 */             this.fCurrent.fStart = modelStart;
/* 1100 */             this.fCurrent.fEnd = modelEnd;
/*      */           } 
/*      */           
/* 1103 */           this.fPreservedTextBuffer.append(replacedText);
/* 1104 */           this.fCurrent.fEnd++;
/*      */         }
/* 1106 */         else if (this.fPreviousDelete.fStart == modelEnd) {
/*      */ 
/*      */ 
/*      */           
/* 1110 */           this.fPreservedTextBuffer.insert(0, replacedText);
/* 1111 */           this.fCurrent.fStart = modelStart;
/*      */         
/*      */         }
/*      */         else {
/*      */           
/* 1116 */           this.fCurrent.fRedoModificationStamp = beforeChangeModificationStamp;
/* 1117 */           if (this.fCurrent.attemptCommit()) {
/* 1118 */             this.fCurrent.fUndoModificationStamp = beforeChangeModificationStamp;
/*      */           }
/*      */ 
/*      */ 
/*      */           
/* 1123 */           this.fPreservedTextBuffer.append(replacedText);
/* 1124 */           this.fCurrent.fStart = modelStart;
/* 1125 */           this.fCurrent.fEnd = modelEnd;
/*      */         } 
/*      */         
/* 1128 */         this.fPreviousDelete.set(modelStart, modelEnd);
/*      */       }
/* 1130 */       else if (length > 0)
/*      */       {
/* 1132 */         this.fCurrent.fRedoModificationStamp = beforeChangeModificationStamp;
/* 1133 */         if (this.fCurrent.attemptCommit()) {
/* 1134 */           this.fCurrent.fUndoModificationStamp = beforeChangeModificationStamp;
/*      */         }
/*      */         
/* 1137 */         this.fCurrent.fStart = modelStart;
/* 1138 */         this.fCurrent.fEnd = modelEnd;
/* 1139 */         this.fPreservedTextBuffer.append(replacedText);
/*      */       }
/*      */     
/*      */     } else {
/*      */       
/* 1144 */       if (length == 1) {
/* 1145 */         length = replacedText.length();
/* 1146 */         String[] delimiters = this.fDocument.getLegalLineDelimiters();
/*      */         
/* 1148 */         if (length == 1 || 
/* 1149 */           TextUtilities.equals(delimiters, replacedText) > -1) {
/*      */           
/* 1151 */           if (!this.fOverwriting || 
/* 1152 */             modelStart != this.fCurrent.fStart + 
/* 1153 */             this.fTextBuffer.length()) {
/* 1154 */             this.fCurrent.fRedoModificationStamp = beforeChangeModificationStamp;
/* 1155 */             if (this.fCurrent.attemptCommit()) {
/* 1156 */               this.fCurrent.fUndoModificationStamp = beforeChangeModificationStamp;
/*      */             }
/*      */             
/* 1159 */             this.fOverwriting = true;
/*      */           } 
/*      */           
/* 1162 */           if (this.fCurrent.fStart < 0) {
/* 1163 */             this.fCurrent.fStart = modelStart;
/*      */           }
/*      */           
/* 1166 */           this.fCurrent.fEnd = modelEnd;
/* 1167 */           this.fTextBuffer.append(insertedText);
/* 1168 */           this.fPreservedTextBuffer.append(replacedText);
/* 1169 */           this.fCurrent.fRedoModificationStamp = afterChangeModificationStamp;
/*      */           
/*      */           return;
/*      */         } 
/*      */       } 
/* 1174 */       this.fCurrent.fRedoModificationStamp = beforeChangeModificationStamp;
/* 1175 */       if (this.fCurrent.attemptCommit()) {
/* 1176 */         this.fCurrent.fUndoModificationStamp = beforeChangeModificationStamp;
/*      */       }
/*      */       
/* 1179 */       this.fCurrent.fStart = modelStart;
/* 1180 */       this.fCurrent.fEnd = modelEnd;
/* 1181 */       this.fTextBuffer.append(insertedText);
/* 1182 */       this.fPreservedTextBuffer.append(replacedText);
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 1187 */     this.fCurrent.fRedoModificationStamp = afterChangeModificationStamp;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void initialize() {
/* 1194 */     initializeUndoHistory();
/*      */ 
/*      */     
/* 1197 */     this.fCurrent = new UndoableTextChange(this);
/* 1198 */     this.fPreviousDelete = new UndoableTextChange(this);
/* 1199 */     this.fTextBuffer = new StringBuilder();
/* 1200 */     this.fPreservedTextBuffer = new StringBuilder();
/*      */     
/* 1202 */     addListeners();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void resetProcessChangeState() {
/* 1211 */     this.fInserting = false;
/* 1212 */     this.fOverwriting = false;
/* 1213 */     this.fPreviousDelete.reinitialize();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void shutdown() {
/* 1220 */     removeListeners();
/*      */     
/* 1222 */     this.fCurrent = null;
/* 1223 */     this.fPreviousDelete = null;
/* 1224 */     this.fTextBuffer = null;
/* 1225 */     this.fPreservedTextBuffer = null;
/*      */     
/* 1227 */     disposeUndoHistory();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   boolean isConnected() {
/* 1237 */     if (this.fConnected == null) {
/* 1238 */       return false;
/*      */     }
/* 1240 */     return !this.fConnected.isEmpty();
/*      */   }
/*      */ 
/*      */   
/*      */   public void transferUndoHistory(IDocumentUndoManager manager) {
/* 1245 */     IUndoContext oldUndoContext = manager.getUndoContext();
/*      */     
/* 1247 */     IUndoableOperation[] operations = OperationHistoryFactory.getOperationHistory().getUndoHistory(oldUndoContext); byte b; int i; IUndoableOperation[] arrayOfIUndoableOperation1;
/* 1248 */     for (i = (arrayOfIUndoableOperation1 = operations).length, b = 0; b < i; ) { IUndoableOperation operation = arrayOfIUndoableOperation1[b];
/*      */       
/* 1250 */       IUndoableOperation iUndoableOperation1 = operation;
/* 1251 */       if (iUndoableOperation1 instanceof IContextReplacingOperation) {
/* 1252 */         ((IContextReplacingOperation)iUndoableOperation1).replaceContext(oldUndoContext, getUndoContext());
/*      */       } else {
/* 1254 */         iUndoableOperation1.addContext(getUndoContext());
/* 1255 */         iUndoableOperation1.removeContext(oldUndoContext);
/*      */       } 
/*      */       
/* 1258 */       if (iUndoableOperation1 instanceof UndoableTextChange) {
/* 1259 */         ((UndoableTextChange)iUndoableOperation1).fDocumentUndoManager = this;
/*      */       }
/*      */       b++; }
/*      */     
/* 1263 */     IUndoableOperation op = OperationHistoryFactory.getOperationHistory().getUndoOperation(getUndoContext());
/* 1264 */     if (op != null && !(op instanceof UndoableTextChange)) {
/*      */       return;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1273 */     UndoableTextChange cmd = new UndoableTextChange(this);
/* 1274 */     cmd.fStart = cmd.fEnd = 0;
/* 1275 */     cmd.fText = cmd.fPreservedText = "";
/* 1276 */     if (this.fDocument instanceof IDocumentExtension4) {
/* 1277 */       cmd.fRedoModificationStamp = ((IDocumentExtension4)this.fDocument).getModificationStamp();
/* 1278 */       if (op != null) {
/* 1279 */         cmd.fUndoModificationStamp = ((UndoableTextChange)op).fRedoModificationStamp;
/*      */       }
/*      */     } 
/* 1282 */     addToOperationHistory(cmd);
/*      */   }
/*      */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.text-3.13.0.jar!\org\eclipse\tex\\undo\DocumentUndoManager.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */