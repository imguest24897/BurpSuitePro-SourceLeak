/*     */ package org.eclipse.text.edits;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.eclipse.jface.text.BadLocationException;
/*     */ import org.eclipse.jface.text.IDocument;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class UndoEdit
/*     */   extends TextEdit
/*     */ {
/*     */   UndoEdit() {
/*  39 */     super(0, 2147483647);
/*     */   }
/*     */   
/*     */   private UndoEdit(UndoEdit other) {
/*  43 */     super(other);
/*     */   }
/*     */ 
/*     */   
/*     */   void internalAdd(TextEdit child) throws MalformedTreeException {
/*  48 */     throw new MalformedTreeException(null, this, TextEditMessages.getString("UndoEdit.no_children"));
/*     */   }
/*     */ 
/*     */   
/*     */   void aboutToBeAdded(TextEdit parent) {
/*  53 */     throw new MalformedTreeException(parent, this, TextEditMessages.getString("UndoEdit.can_not_be_added"));
/*     */   }
/*     */ 
/*     */   
/*     */   UndoEdit dispatchPerformEdits(TextEditProcessor processor) throws BadLocationException {
/*  58 */     return processor.executeUndo();
/*     */   }
/*     */ 
/*     */   
/*     */   void dispatchCheckIntegrity(TextEditProcessor processor) throws MalformedTreeException {
/*  63 */     processor.checkIntegrityUndo();
/*     */   }
/*     */ 
/*     */   
/*     */   protected TextEdit doCopy() {
/*  68 */     return new UndoEdit(this);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void accept0(TextEditVisitor visitor) {
/*  73 */     boolean visitChildren = visitor.visit(this);
/*  74 */     if (visitChildren) {
/*  75 */       acceptChildren(visitor);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   int performDocumentUpdating(IDocument document) throws BadLocationException {
/*  81 */     this.fDelta = 0;
/*  82 */     return this.fDelta;
/*     */   }
/*     */   
/*     */   void add(ReplaceEdit edit) {
/*  86 */     List<TextEdit> children = internalGetChildren();
/*  87 */     if (children == null) {
/*  88 */       children = new ArrayList<>(2);
/*  89 */       internalSetChildren(children);
/*     */     } 
/*  91 */     children.add(edit);
/*     */   }
/*     */   
/*     */   void defineRegion(int offset, int length) {
/*  95 */     internalSetOffset(offset);
/*  96 */     internalSetLength(length);
/*     */   }
/*     */ 
/*     */   
/*     */   boolean deleteChildren() {
/* 101 */     return false;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.text-3.13.0.jar!\org\eclipse\text\edits\UndoEdit.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */