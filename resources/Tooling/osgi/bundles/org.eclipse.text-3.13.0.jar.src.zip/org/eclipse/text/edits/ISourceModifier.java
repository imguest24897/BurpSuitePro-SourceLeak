package org.eclipse.text.edits;

public interface ISourceModifier {
  ReplaceEdit[] getModifications(String paramString);
  
  ISourceModifier copy();
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.text-3.13.0.jar!\org\eclipse\text\edits\ISourceModifier.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */