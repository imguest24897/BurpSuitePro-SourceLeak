/*     */ package org.eclipse.text.templates;
/*     */ 
/*     */ import java.util.Objects;
/*     */ import java.util.UUID;
/*     */ import org.eclipse.core.runtime.Assert;
/*     */ import org.eclipse.jface.text.templates.Template;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TemplatePersistenceData
/*     */ {
/*     */   private final Template fOriginalTemplate;
/*     */   private final String fId;
/*     */   private final boolean fOriginalIsEnabled;
/*  42 */   private Template fCustomTemplate = null;
/*     */ 
/*     */   
/*     */   private boolean fIsDeleted = false;
/*     */   
/*     */   private boolean fCustomIsEnabled = true;
/*     */   
/*  49 */   private final UUID uniqueIdForEquals = UUID.randomUUID();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TemplatePersistenceData(Template template, boolean enabled) {
/*  59 */     this(template, enabled, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TemplatePersistenceData(Template template, boolean enabled, String id) {
/*  73 */     Assert.isNotNull(template);
/*  74 */     this.fOriginalTemplate = template;
/*  75 */     this.fCustomTemplate = template;
/*  76 */     this.fOriginalIsEnabled = enabled;
/*  77 */     this.fCustomIsEnabled = enabled;
/*  78 */     this.fId = id;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getId() {
/*  87 */     return this.fId;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isDeleted() {
/*  97 */     return this.fIsDeleted;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDeleted(boolean isDeleted) {
/* 106 */     this.fIsDeleted = isDeleted;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Template getTemplate() {
/* 115 */     return this.fCustomTemplate;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setTemplate(Template template) {
/* 125 */     this.fCustomTemplate = template;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isCustom() {
/* 137 */     return !(this.fId != null && 
/* 138 */       !this.fIsDeleted && 
/* 139 */       this.fOriginalIsEnabled == this.fCustomIsEnabled && 
/* 140 */       this.fOriginalTemplate.equals(this.fCustomTemplate));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isModified() {
/* 150 */     return (isCustom() && !isUserAdded());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isUserAdded() {
/* 160 */     return (this.fId == null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void revert() {
/* 168 */     this.fCustomTemplate = this.fOriginalTemplate;
/* 169 */     this.fCustomIsEnabled = this.fOriginalIsEnabled;
/* 170 */     this.fIsDeleted = false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isEnabled() {
/* 180 */     return this.fCustomIsEnabled;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setEnabled(boolean isEnabled) {
/* 189 */     this.fCustomIsEnabled = isEnabled;
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 194 */     return Objects.hash(new Object[] { this.uniqueIdForEquals });
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object obj) {
/* 199 */     if (this == obj) {
/* 200 */       return true;
/*     */     }
/* 202 */     if (!(obj instanceof TemplatePersistenceData)) {
/* 203 */       return false;
/*     */     }
/* 205 */     TemplatePersistenceData other = (TemplatePersistenceData)obj;
/* 206 */     return Objects.equals(this.uniqueIdForEquals, other.getUniqueIdForEquals());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected UUID getUniqueIdForEquals() {
/* 215 */     return this.uniqueIdForEquals;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static final UUID getUniqueIdForEquals(TemplatePersistenceData data) {
/* 225 */     return data.getUniqueIdForEquals();
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.text-3.13.0.jar!\org\eclipse\text\templates\TemplatePersistenceData.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */