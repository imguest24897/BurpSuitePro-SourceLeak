/*     */ package org.eclipse.text.edits;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.eclipse.core.runtime.Assert;
/*     */ import org.eclipse.jface.text.BadLocationException;
/*     */ import org.eclipse.jface.text.IDocument;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class CopySourceEdit
/*     */   extends TextEdit
/*     */ {
/*     */   private CopyTargetEdit fTarget;
/*     */   private ISourceModifier fModifier;
/*     */   private String fSourceContent;
/*     */   private TextEdit fSourceRoot;
/*     */   
/*     */   private static class PartialCopier
/*     */     extends TextEditVisitor
/*     */   {
/*     */     TextEdit fResult;
/*  51 */     List<TextEdit> fParents = new ArrayList<>();
/*     */     TextEdit fCurrentParent;
/*     */     
/*     */     public static TextEdit perform(TextEdit source) {
/*  55 */       PartialCopier copier = new PartialCopier();
/*  56 */       source.accept(copier);
/*  57 */       return copier.fResult;
/*     */     }
/*     */     private void manageCopy(TextEdit copy) {
/*  60 */       if (this.fResult == null)
/*  61 */         this.fResult = copy; 
/*  62 */       if (this.fCurrentParent != null) {
/*  63 */         this.fCurrentParent.addChild(copy);
/*     */       }
/*  65 */       this.fParents.add(this.fCurrentParent);
/*  66 */       this.fCurrentParent = copy;
/*     */     }
/*     */     
/*     */     public void postVisit(TextEdit edit) {
/*  70 */       this.fCurrentParent = this.fParents.remove(this.fParents.size() - 1);
/*     */     }
/*     */     
/*     */     public boolean visitNode(TextEdit edit) {
/*  74 */       manageCopy(edit.doCopy());
/*  75 */       return true;
/*     */     }
/*     */     
/*     */     public boolean visit(CopySourceEdit edit) {
/*  79 */       manageCopy(new RangeMarker(edit.getOffset(), edit.getLength()));
/*  80 */       return true;
/*     */     }
/*     */     
/*     */     public boolean visit(CopyTargetEdit edit) {
/*  84 */       manageCopy(new InsertEdit(edit.getOffset(), edit.getSourceEdit().getContent()));
/*  85 */       return true;
/*     */     }
/*     */     
/*     */     public boolean visit(MoveSourceEdit edit) {
/*  89 */       manageCopy(new DeleteEdit(edit.getOffset(), edit.getLength()));
/*  90 */       return true;
/*     */     }
/*     */     
/*     */     public boolean visit(MoveTargetEdit edit) {
/*  94 */       manageCopy(new InsertEdit(edit.getOffset(), edit.getSourceEdit().getContent()));
/*  95 */       return true;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CopySourceEdit(int offset, int length) {
/* 106 */     super(offset, length);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CopySourceEdit(int offset, int length, CopyTargetEdit target) {
/* 117 */     this(offset, length);
/* 118 */     setTargetEdit(target);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private CopySourceEdit(CopySourceEdit other) {
/* 125 */     super(other);
/* 126 */     if (other.fModifier != null) {
/* 127 */       this.fModifier = other.fModifier.copy();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CopyTargetEdit getTargetEdit() {
/* 137 */     return this.fTarget;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setTargetEdit(CopyTargetEdit edit) throws MalformedTreeException {
/* 149 */     Assert.isNotNull(edit);
/* 150 */     if (this.fTarget != edit) {
/* 151 */       this.fTarget = edit;
/* 152 */       this.fTarget.setSourceEdit(this);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ISourceModifier getSourceModifier() {
/* 163 */     return this.fModifier;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSourceModifier(ISourceModifier modifier) {
/* 173 */     this.fModifier = modifier;
/*     */   }
/*     */ 
/*     */   
/*     */   protected TextEdit doCopy() {
/* 178 */     return new CopySourceEdit(this);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void accept0(TextEditVisitor visitor) {
/* 183 */     boolean visitChildren = visitor.visit(this);
/* 184 */     if (visitChildren) {
/* 185 */       acceptChildren(visitor);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   String getContent() {
/* 195 */     if (this.fSourceContent == null)
/* 196 */       return ""; 
/* 197 */     return this.fSourceContent;
/*     */   }
/*     */   
/*     */   void clearContent() {
/* 201 */     this.fSourceContent = null;
/*     */   }
/*     */ 
/*     */   
/*     */   protected void postProcessCopy(TextEditCopier copier) {
/* 206 */     if (this.fTarget != null) {
/* 207 */       CopySourceEdit source = (CopySourceEdit)copier.getCopy(this);
/* 208 */       CopyTargetEdit target = (CopyTargetEdit)copier.getCopy(this.fTarget);
/* 209 */       if (source != null && target != null) {
/* 210 */         source.setTargetEdit(target);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   int traverseConsistencyCheck(TextEditProcessor processor, IDocument document, List<List<TextEdit>> sourceEdits) {
/* 218 */     int result = super.traverseConsistencyCheck(processor, document, sourceEdits);
/*     */ 
/*     */ 
/*     */     
/* 222 */     if (this.fSourceContent == null) {
/* 223 */       if (sourceEdits.size() <= result) {
/* 224 */         List<TextEdit> list = new ArrayList<>();
/* 225 */         list.add(this);
/* 226 */         for (int i = sourceEdits.size(); i < result; i++)
/* 227 */           sourceEdits.add(null); 
/* 228 */         sourceEdits.add(list);
/*     */       } else {
/* 230 */         List<TextEdit> list = sourceEdits.get(result);
/* 231 */         if (list == null) {
/* 232 */           list = new ArrayList<>();
/* 233 */           sourceEdits.add(result, list);
/*     */         } 
/* 235 */         list.add(this);
/*     */       } 
/*     */     }
/* 238 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   void performConsistencyCheck(TextEditProcessor processor, IDocument document) throws MalformedTreeException {
/* 243 */     if (this.fTarget == null)
/* 244 */       throw new MalformedTreeException(getParent(), this, TextEditMessages.getString("CopySourceEdit.no_target")); 
/* 245 */     if (this.fTarget.getSourceEdit() != this) {
/* 246 */       throw new MalformedTreeException(getParent(), this, TextEditMessages.getString("CopySourceEdit.different_source"));
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void traverseSourceComputation(TextEditProcessor processor, IDocument document) {
/* 260 */     performSourceComputation(processor, document);
/*     */   }
/*     */ 
/*     */   
/*     */   void performSourceComputation(TextEditProcessor processor, IDocument document) {
/*     */     try {
/* 266 */       MultiTextEdit root = new MultiTextEdit(getOffset(), getLength());
/* 267 */       root.internalSetChildren(internalGetChildren());
/* 268 */       this.fSourceContent = document.get(getOffset(), getLength());
/* 269 */       this.fSourceRoot = PartialCopier.perform(root);
/* 270 */       this.fSourceRoot.internalMoveTree(-getOffset());
/* 271 */       if (this.fSourceRoot.hasChildren()) {
/* 272 */         EditDocument subDocument = new EditDocument(this.fSourceContent);
/* 273 */         TextEditProcessor subProcessor = TextEditProcessor.createSourceComputationProcessor(subDocument, this.fSourceRoot, 0);
/* 274 */         subProcessor.performEdits();
/* 275 */         if (needsTransformation())
/* 276 */           applyTransformation(subDocument); 
/* 277 */         this.fSourceContent = subDocument.get();
/* 278 */         this.fSourceRoot = null;
/*     */       }
/* 280 */       else if (needsTransformation()) {
/* 281 */         EditDocument subDocument = new EditDocument(this.fSourceContent);
/* 282 */         applyTransformation(subDocument);
/* 283 */         this.fSourceContent = subDocument.get();
/*     */       }
/*     */     
/* 286 */     } catch (BadLocationException badLocationException) {
/* 287 */       Assert.isTrue(false);
/*     */     } 
/*     */   }
/*     */   
/*     */   private boolean needsTransformation() {
/* 292 */     return (this.fModifier != null);
/*     */   }
/*     */   
/*     */   private void applyTransformation(IDocument document) throws MalformedTreeException {
/* 296 */     TextEdit newEdit = new MultiTextEdit(0, document.getLength());
/* 297 */     ReplaceEdit[] replaces = this.fModifier.getModifications(document.get()); byte b; int i; ReplaceEdit[] arrayOfReplaceEdit1;
/* 298 */     for (i = (arrayOfReplaceEdit1 = replaces).length, b = 0; b < i; ) { ReplaceEdit replace = arrayOfReplaceEdit1[b];
/* 299 */       newEdit.addChild(replace); b++; }
/*     */     
/*     */     try {
/* 302 */       newEdit.apply(document, 0);
/* 303 */     } catch (BadLocationException badLocationException) {
/* 304 */       Assert.isTrue(false);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   int performDocumentUpdating(IDocument document) throws BadLocationException {
/* 312 */     this.fDelta = 0;
/* 313 */     return this.fDelta;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean deleteChildren() {
/* 320 */     return false;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.text-3.13.0.jar!\org\eclipse\text\edits\CopySourceEdit.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */