/*     */ package org.eclipse.text.templates;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.Reader;
/*     */ import java.io.StringReader;
/*     */ import java.io.StringWriter;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.eclipse.core.runtime.Assert;
/*     */ import org.eclipse.core.runtime.preferences.IEclipsePreferences;
/*     */ import org.eclipse.jface.text.templates.Template;
/*     */ import org.eclipse.jface.text.templates.TemplateException;
/*     */ import org.osgi.service.prefs.BackingStoreException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TemplateStoreCore
/*     */ {
/*  42 */   private final List<TemplatePersistenceData> fTemplates = new ArrayList<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private IEclipsePreferences fPreferenceStore;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String fKey;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ContextTypeRegistry fRegistry;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean fIgnorePreferenceStoreChanges = false;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private IEclipsePreferences.IPreferenceChangeListener fPropertyListener;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TemplateStoreCore(IEclipsePreferences store, String key) {
/*  79 */     Assert.isNotNull(key);
/*  80 */     this.fPreferenceStore = store;
/*  81 */     this.fKey = key;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TemplateStoreCore(ContextTypeRegistry registry, IEclipsePreferences store, String key) {
/*  97 */     this(store, key);
/*  98 */     this.fRegistry = registry;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void load() throws IOException {
/* 107 */     this.fTemplates.clear();
/* 108 */     loadContributedTemplates();
/* 109 */     loadCustomTemplates();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void startListeningForPreferenceChanges() {
/* 121 */     if (this.fPropertyListener == null) {
/* 122 */       this.fPropertyListener = (event -> {
/*     */ 
/*     */ 
/*     */           
/*     */           if (!this.fIgnorePreferenceStoreChanges && this.fKey.equals(event.getKey()))
/*     */             
/*     */             try {
/*     */               
/*     */               load();
/* 131 */             } catch (IOException x) {
/*     */               handleException(x);
/*     */             }  
/*     */         });
/* 135 */       this.fPreferenceStore.addPreferenceChangeListener(this.fPropertyListener);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void stopListeningForPreferenceChanges() {
/* 147 */     if (this.fPropertyListener != null) {
/* 148 */       this.fPreferenceStore.removePreferenceChangeListener(this.fPropertyListener);
/* 149 */       this.fPropertyListener = null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void handleException(IOException x) {
/* 161 */     x.printStackTrace();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void loadContributedTemplates() throws IOException {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void internalAdd(TemplatePersistenceData data) {
/* 182 */     if (!data.isCustom()) {
/*     */       
/* 184 */       String id = data.getId();
/* 185 */       for (TemplatePersistenceData persistenceData : this.fTemplates) {
/* 186 */         if (persistenceData.getId() != null && persistenceData.getId().equals(id))
/*     */           return; 
/*     */       } 
/* 189 */       this.fTemplates.add(data);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void save() throws IOException {
/* 199 */     ArrayList<TemplatePersistenceData> custom = new ArrayList<>();
/* 200 */     for (TemplatePersistenceData data : this.fTemplates) {
/* 201 */       if (data.isCustom() && (!data.isUserAdded() || !data.isDeleted())) {
/* 202 */         custom.add(data);
/*     */       }
/*     */     } 
/* 205 */     StringWriter output = new StringWriter();
/* 206 */     TemplateReaderWriter writer = new TemplateReaderWriter();
/* 207 */     writer.save(custom.<TemplatePersistenceData>toArray(new TemplatePersistenceData[custom.size()]), output);
/*     */     
/* 209 */     this.fIgnorePreferenceStoreChanges = true;
/*     */     
/* 211 */     try { this.fPreferenceStore.put(this.fKey, output.toString());
/* 212 */       this.fPreferenceStore.flush(); }
/* 213 */     catch (BackingStoreException backingStoreException) {  }
/*     */     finally
/* 215 */     { this.fIgnorePreferenceStoreChanges = false; }
/*     */   
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void add(TemplatePersistenceData data) {
/* 226 */     if (!validateTemplate(data.getTemplate())) {
/*     */       return;
/*     */     }
/* 229 */     if (data.isUserAdded()) {
/* 230 */       this.fTemplates.add(data);
/*     */     } else {
/* 232 */       for (TemplatePersistenceData persistenceData : this.fTemplates) {
/* 233 */         if (persistenceData.getId() != null && persistenceData.getId().equals(data.getId())) {
/* 234 */           persistenceData.setTemplate(data.getTemplate());
/* 235 */           persistenceData.setDeleted(data.isDeleted());
/* 236 */           persistenceData.setEnabled(data.isEnabled());
/*     */           
/*     */           return;
/*     */         } 
/*     */       } 
/*     */       
/* 242 */       if (data.getTemplate() != null) {
/* 243 */         TemplatePersistenceData newData = new TemplatePersistenceData(data.getTemplate(), data.isEnabled(), data.getId());
/* 244 */         this.fTemplates.add(newData);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void delete(TemplatePersistenceData data) {
/* 255 */     if (data.isUserAdded()) {
/* 256 */       this.fTemplates.remove(data);
/*     */     } else {
/* 258 */       data.setDeleted(true);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void restoreDeleted() {
/* 265 */     for (TemplatePersistenceData data : this.fTemplates) {
/* 266 */       if (data.isDeleted()) {
/* 267 */         data.setDeleted(false);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void restoreDefaults(boolean doSave) {
/* 278 */     String oldValue = null;
/* 279 */     if (!doSave) {
/* 280 */       oldValue = this.fPreferenceStore.get(this.fKey, null);
/*     */     }
/*     */     try {
/* 283 */       this.fIgnorePreferenceStoreChanges = true;
/*     */       
/* 285 */       this.fPreferenceStore.put(this.fKey, "");
/*     */     } finally {
/* 287 */       this.fIgnorePreferenceStoreChanges = false;
/*     */     } 
/*     */     
/*     */     try {
/* 291 */       load();
/* 292 */     } catch (IOException x) {
/*     */       
/* 294 */       handleException(x);
/*     */     } 
/*     */     
/* 297 */     if (oldValue != null) {
/*     */       try {
/* 299 */         this.fIgnorePreferenceStoreChanges = true;
/* 300 */         this.fPreferenceStore.put(this.fKey, oldValue);
/*     */       } finally {
/* 302 */         this.fIgnorePreferenceStoreChanges = false;
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void restoreDefaults() {
/* 314 */     restoreDefaults(true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Template[] getTemplates() {
/* 323 */     return getTemplates(null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Template[] getTemplates(String contextTypeId) {
/* 333 */     List<Template> templates = new ArrayList<>();
/* 334 */     for (TemplatePersistenceData data : this.fTemplates) {
/* 335 */       if (data.isEnabled() && !data.isDeleted() && (contextTypeId == null || contextTypeId.equals(data.getTemplate().getContextTypeId()))) {
/* 336 */         templates.add(data.getTemplate());
/*     */       }
/*     */     } 
/* 339 */     return templates.<Template>toArray(new Template[templates.size()]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Template findTemplate(String name) {
/* 349 */     return findTemplate(name, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Template findTemplate(String name, String contextTypeId) {
/* 360 */     Assert.isNotNull(name);
/*     */     
/* 362 */     for (TemplatePersistenceData data : this.fTemplates) {
/* 363 */       Template template = data.getTemplate();
/* 364 */       if (data.isEnabled() && !data.isDeleted() && (
/* 365 */         contextTypeId == null || contextTypeId.equals(template.getContextTypeId())) && 
/* 366 */         name.equals(template.getName())) {
/* 367 */         return template;
/*     */       }
/*     */     } 
/* 370 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Template findTemplateById(String id) {
/* 381 */     TemplatePersistenceData data = getTemplateData(id);
/* 382 */     if (data != null && !data.isDeleted()) {
/* 383 */       return data.getTemplate();
/*     */     }
/* 385 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TemplatePersistenceData[] getTemplateData(boolean includeDeleted) {
/* 395 */     List<TemplatePersistenceData> datas = new ArrayList<>();
/* 396 */     for (TemplatePersistenceData data : this.fTemplates) {
/* 397 */       if (includeDeleted || !data.isDeleted()) {
/* 398 */         datas.add(data);
/*     */       }
/*     */     } 
/* 401 */     return datas.<TemplatePersistenceData>toArray(new TemplatePersistenceData[datas.size()]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TemplatePersistenceData getTemplateData(String id) {
/* 413 */     Assert.isNotNull(id);
/* 414 */     for (TemplatePersistenceData data : this.fTemplates) {
/* 415 */       if (id.equals(data.getId())) {
/* 416 */         return data;
/*     */       }
/*     */     } 
/* 419 */     return null;
/*     */   }
/*     */   
/*     */   private void loadCustomTemplates() throws IOException {
/* 423 */     String pref = this.fPreferenceStore.get(this.fKey, null);
/* 424 */     if (pref != null && !pref.trim().isEmpty()) {
/* 425 */       Reader input = new StringReader(pref);
/* 426 */       TemplateReaderWriter reader = new TemplateReaderWriter();
/* 427 */       TemplatePersistenceData[] datas = reader.read(input); byte b; int i; TemplatePersistenceData[] arrayOfTemplatePersistenceData1;
/* 428 */       for (i = (arrayOfTemplatePersistenceData1 = datas).length, b = 0; b < i; ) { TemplatePersistenceData data = arrayOfTemplatePersistenceData1[b];
/* 429 */         add(data);
/*     */         b++; }
/*     */     
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean validateTemplate(Template template) {
/* 445 */     String contextTypeId = template.getContextTypeId();
/* 446 */     if (contextExists(contextTypeId)) {
/* 447 */       if (this.fRegistry != null)
/*     */         try {
/* 449 */           this.fRegistry.getContextType(contextTypeId).validate(template.getPattern());
/* 450 */         } catch (TemplateException templateException) {
/* 451 */           return false;
/*     */         }  
/* 453 */       return true;
/*     */     } 
/*     */     
/* 456 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean contextExists(String contextTypeId) {
/* 469 */     return (contextTypeId != null && (this.fRegistry == null || this.fRegistry.getContextType(contextTypeId) != null));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected ContextTypeRegistry getRegistry() {
/* 478 */     return this.fRegistry;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final String getKey() {
/* 488 */     return this.fKey;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final List<TemplatePersistenceData> internalGetTemplates() {
/* 496 */     return this.fTemplates;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.text-3.13.0.jar!\org\eclipse\text\templates\TemplateStoreCore.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */