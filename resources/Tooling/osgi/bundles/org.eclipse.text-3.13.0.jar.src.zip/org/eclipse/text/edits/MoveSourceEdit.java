/*     */ package org.eclipse.text.edits;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.eclipse.core.runtime.Assert;
/*     */ import org.eclipse.jface.text.BadLocationException;
/*     */ import org.eclipse.jface.text.IDocument;
/*     */ import org.eclipse.jface.text.IRegion;
/*     */ import org.eclipse.jface.text.Region;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class MoveSourceEdit
/*     */   extends TextEdit
/*     */ {
/*     */   private MoveTargetEdit fTarget;
/*     */   private ISourceModifier fModifier;
/*     */   private String fSourceContent;
/*     */   private MultiTextEdit fSourceRoot;
/*     */   
/*     */   public MoveSourceEdit(int offset, int length) {
/*  63 */     super(offset, length);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MoveSourceEdit(int offset, int length, MoveTargetEdit target) {
/*  74 */     this(offset, length);
/*  75 */     setTargetEdit(target);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private MoveSourceEdit(MoveSourceEdit other) {
/*  82 */     super(other);
/*  83 */     if (other.fModifier != null) {
/*  84 */       this.fModifier = other.fModifier.copy();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MoveTargetEdit getTargetEdit() {
/*  94 */     return this.fTarget;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setTargetEdit(MoveTargetEdit edit) {
/* 106 */     this.fTarget = edit;
/* 107 */     this.fTarget.setSourceEdit(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ISourceModifier getSourceModifier() {
/* 117 */     return this.fModifier;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSourceModifier(ISourceModifier modifier) {
/* 127 */     this.fModifier = modifier;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   String getContent() {
/* 136 */     if (this.fSourceContent == null)
/* 137 */       return ""; 
/* 138 */     return this.fSourceContent;
/*     */   }
/*     */   
/*     */   MultiTextEdit getSourceRoot() {
/* 142 */     return this.fSourceRoot;
/*     */   }
/*     */   
/*     */   void clearContent() {
/* 146 */     this.fSourceContent = null;
/* 147 */     this.fSourceRoot = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected TextEdit doCopy() {
/* 154 */     return new MoveSourceEdit(this);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void postProcessCopy(TextEditCopier copier) {
/* 159 */     if (this.fTarget != null) {
/* 160 */       MoveSourceEdit source = (MoveSourceEdit)copier.getCopy(this);
/* 161 */       MoveTargetEdit target = (MoveTargetEdit)copier.getCopy(this.fTarget);
/* 162 */       if (source != null && target != null) {
/* 163 */         source.setTargetEdit(target);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void accept0(TextEditVisitor visitor) {
/* 171 */     boolean visitChildren = visitor.visit(this);
/* 172 */     if (visitChildren) {
/* 173 */       acceptChildren(visitor);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   int traverseConsistencyCheck(TextEditProcessor processor, IDocument document, List<List<TextEdit>> sourceEdits) {
/* 181 */     int result = super.traverseConsistencyCheck(processor, document, sourceEdits);
/*     */ 
/*     */ 
/*     */     
/* 185 */     if (this.fSourceContent == null) {
/* 186 */       if (sourceEdits.size() <= result) {
/* 187 */         List<TextEdit> list = new ArrayList<>();
/* 188 */         list.add(this);
/* 189 */         for (int i = sourceEdits.size(); i < result; i++)
/* 190 */           sourceEdits.add(null); 
/* 191 */         sourceEdits.add(list);
/*     */       } else {
/* 193 */         List<TextEdit> list = sourceEdits.get(result);
/* 194 */         if (list == null) {
/* 195 */           list = new ArrayList<>();
/* 196 */           sourceEdits.add(result, list);
/*     */         } 
/* 198 */         list.add(this);
/*     */       } 
/*     */     }
/* 201 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   void performConsistencyCheck(TextEditProcessor processor, IDocument document) throws MalformedTreeException {
/* 206 */     if (this.fTarget == null)
/* 207 */       throw new MalformedTreeException(getParent(), this, TextEditMessages.getString("MoveSourceEdit.no_target")); 
/* 208 */     if (this.fTarget.getSourceEdit() != this) {
/* 209 */       throw new MalformedTreeException(getParent(), this, TextEditMessages.getString("MoveSourceEdit.different_source"));
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void traverseSourceComputation(TextEditProcessor processor, IDocument document) {
/* 223 */     performSourceComputation(processor, document);
/*     */   }
/*     */ 
/*     */   
/*     */   void performSourceComputation(TextEditProcessor processor, IDocument document) {
/*     */     try {
/* 229 */       TextEdit[] children = removeChildren();
/* 230 */       if (children.length > 0) {
/* 231 */         String content = document.get(getOffset(), getLength());
/* 232 */         EditDocument subDocument = new EditDocument(content);
/* 233 */         this.fSourceRoot = new MultiTextEdit(getOffset(), getLength());
/* 234 */         this.fSourceRoot.addChildren(children);
/* 235 */         this.fSourceRoot.internalMoveTree(-getOffset());
/* 236 */         int processingStyle = getStyle(processor);
/* 237 */         TextEditProcessor subProcessor = TextEditProcessor.createSourceComputationProcessor(subDocument, this.fSourceRoot, processingStyle);
/* 238 */         subProcessor.performEdits();
/* 239 */         if (needsTransformation())
/* 240 */           applyTransformation(subDocument, processingStyle); 
/* 241 */         this.fSourceContent = subDocument.get();
/*     */       } else {
/* 243 */         this.fSourceContent = document.get(getOffset(), getLength());
/* 244 */         if (needsTransformation()) {
/* 245 */           EditDocument subDocument = new EditDocument(this.fSourceContent);
/* 246 */           applyTransformation(subDocument, getStyle(processor));
/* 247 */           this.fSourceContent = subDocument.get();
/*     */         } 
/*     */       } 
/* 250 */     } catch (BadLocationException badLocationException) {
/* 251 */       Assert.isTrue(false);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private int getStyle(TextEditProcessor processor) {
/* 257 */     if ((processor.getStyle() & 0x2) != 0)
/* 258 */       return 2; 
/* 259 */     return 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   int performDocumentUpdating(IDocument document) throws BadLocationException {
/* 266 */     document.replace(getOffset(), getLength(), "");
/* 267 */     this.fDelta = -getLength();
/* 268 */     return this.fDelta;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean deleteChildren() {
/* 275 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean needsTransformation() {
/* 281 */     return (this.fModifier != null);
/*     */   }
/*     */   
/*     */   private void applyTransformation(IDocument document, int style) throws MalformedTreeException {
/* 285 */     if ((style & 0x2) != 0 && this.fSourceRoot != null) {
/* 286 */       Map<TextEdit, TextEdit> editMap = new HashMap<>();
/* 287 */       TextEdit newEdit = createEdit(editMap);
/* 288 */       List<ReplaceEdit> replaces = new ArrayList<>(Arrays.asList(this.fModifier.getModifications(document.get())));
/* 289 */       insertEdits(newEdit, replaces);
/*     */       try {
/* 291 */         newEdit.apply(document, style);
/* 292 */       } catch (BadLocationException badLocationException) {
/* 293 */         Assert.isTrue(false);
/*     */       } 
/* 295 */       restorePositions(editMap);
/*     */     } else {
/* 297 */       MultiTextEdit newEdit = new MultiTextEdit(0, document.getLength());
/* 298 */       ReplaceEdit[] arrayOfReplaceEdit1 = this.fModifier.getModifications(document.get()); byte b; int i; ReplaceEdit[] arrayOfReplaceEdit2;
/* 299 */       for (i = (arrayOfReplaceEdit2 = arrayOfReplaceEdit1).length, b = 0; b < i; ) { TextEdit replace = arrayOfReplaceEdit2[b];
/* 300 */         newEdit.addChild(replace); b++; }
/*     */       
/*     */       try {
/* 303 */         newEdit.apply(document, style);
/* 304 */       } catch (BadLocationException badLocationException) {
/* 305 */         Assert.isTrue(false);
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private TextEdit createEdit(Map<TextEdit, TextEdit> editMap) {
/* 311 */     MultiTextEdit result = new MultiTextEdit(0, this.fSourceRoot.getLength());
/* 312 */     editMap.put(result, this.fSourceRoot);
/* 313 */     createEdit(this.fSourceRoot, result, editMap);
/* 314 */     return result;
/*     */   }
/*     */   
/*     */   private static void createEdit(TextEdit source, TextEdit target, Map<TextEdit, TextEdit> editMap) {
/* 318 */     TextEdit[] children = source.getChildren(); byte b; int i; TextEdit[] arrayOfTextEdit1;
/* 319 */     for (i = (arrayOfTextEdit1 = children).length, b = 0; b < i; ) { TextEdit child = arrayOfTextEdit1[b];
/*     */ 
/*     */       
/* 322 */       if (!child.isDeleted()) {
/*     */         
/* 324 */         RangeMarker marker = new RangeMarker(child.getOffset(), child.getLength());
/* 325 */         target.addChild(marker);
/* 326 */         editMap.put(marker, child);
/* 327 */         createEdit(child, marker, editMap);
/*     */       } 
/*     */       b++; }
/*     */   
/*     */   } private void insertEdits(TextEdit root, List<ReplaceEdit> edits) {
/* 332 */     while (!edits.isEmpty()) {
/* 333 */       ReplaceEdit edit = edits.remove(0);
/* 334 */       insert(root, edit, edits);
/*     */     } 
/*     */   }
/*     */   private static void insert(TextEdit parent, ReplaceEdit edit, List<ReplaceEdit> edits) {
/* 338 */     if (!parent.hasChildren()) {
/* 339 */       parent.addChild(edit);
/*     */       return;
/*     */     } 
/* 342 */     TextEdit[] children = parent.getChildren();
/*     */     
/* 344 */     int removed = 0;
/* 345 */     for (int i = 0; i < children.length; i++) {
/* 346 */       TextEdit child = children[i];
/* 347 */       if (child.covers(edit)) {
/* 348 */         insert(child, edit, edits); return;
/*     */       } 
/* 350 */       if (edit.covers(child)) {
/* 351 */         parent.removeChild(i - removed++);
/* 352 */         edit.addChild(child);
/*     */       } else {
/* 354 */         IRegion intersect = intersect(edit, child);
/* 355 */         if (intersect != null) {
/* 356 */           ReplaceEdit[] splits = splitEdit(edit, intersect);
/* 357 */           insert(child, splits[0], edits);
/* 358 */           edits.add(splits[1]);
/*     */           return;
/*     */         } 
/*     */       } 
/*     */     } 
/* 363 */     parent.addChild(edit);
/*     */   }
/*     */   
/*     */   public static IRegion intersect(TextEdit op1, TextEdit op2) {
/* 367 */     int offset1 = op1.getOffset();
/* 368 */     int length1 = op1.getLength();
/* 369 */     int end1 = offset1 + length1 - 1;
/* 370 */     int offset2 = op2.getOffset();
/* 371 */     if (end1 < offset2)
/* 372 */       return null; 
/* 373 */     int length2 = op2.getLength();
/* 374 */     int end2 = offset2 + length2 - 1;
/* 375 */     if (end2 < offset1) {
/* 376 */       return null;
/*     */     }
/* 378 */     int end = Math.min(end1, end2);
/* 379 */     if (offset1 < offset2) {
/* 380 */       return (IRegion)new Region(offset2, end - offset2 + 1);
/*     */     }
/* 382 */     return (IRegion)new Region(offset1, end - offset1 + 1);
/*     */   }
/*     */   
/*     */   private static ReplaceEdit[] splitEdit(ReplaceEdit edit, IRegion intersect) {
/* 386 */     if (edit.getOffset() != intersect.getOffset())
/* 387 */       return splitIntersectRight(edit, intersect); 
/* 388 */     return splitIntersectLeft(edit, intersect);
/*     */   }
/*     */   
/*     */   private static ReplaceEdit[] splitIntersectRight(ReplaceEdit edit, IRegion intersect) {
/* 392 */     ReplaceEdit[] result = new ReplaceEdit[2];
/*     */     
/* 394 */     result[0] = new ReplaceEdit(intersect.getOffset(), intersect.getLength(), "");
/* 395 */     result[1] = new ReplaceEdit(
/* 396 */         edit.getOffset(), 
/* 397 */         intersect.getOffset() - edit.getOffset(), 
/* 398 */         edit.getText());
/* 399 */     return result;
/*     */   }
/*     */   
/*     */   private static ReplaceEdit[] splitIntersectLeft(ReplaceEdit edit, IRegion intersect) {
/* 403 */     ReplaceEdit[] result = new ReplaceEdit[2];
/* 404 */     result[0] = new ReplaceEdit(intersect.getOffset(), intersect.getLength(), edit.getText());
/* 405 */     result[1] = new ReplaceEdit(
/* 406 */         intersect.getOffset() + intersect.getLength(), 
/* 407 */         edit.getLength() - intersect.getLength(), 
/* 408 */         "");
/* 409 */     return result;
/*     */   }
/*     */   
/*     */   private static void restorePositions(Map<TextEdit, TextEdit> editMap) {
/* 413 */     for (Map.Entry<TextEdit, TextEdit> entry : editMap.entrySet()) {
/* 414 */       TextEdit marker = entry.getKey();
/* 415 */       TextEdit edit = entry.getValue();
/* 416 */       if (marker.isDeleted()) {
/* 417 */         edit.markAsDeleted(); continue;
/*     */       } 
/* 419 */       edit.adjustOffset(marker.getOffset() - edit.getOffset());
/* 420 */       edit.adjustLength(marker.getLength() - edit.getLength());
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.text-3.13.0.jar!\org\eclipse\text\edits\MoveSourceEdit.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */