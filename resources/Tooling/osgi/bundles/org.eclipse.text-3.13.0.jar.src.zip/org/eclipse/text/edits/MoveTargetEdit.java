/*     */ package org.eclipse.text.edits;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.eclipse.jface.text.BadLocationException;
/*     */ import org.eclipse.jface.text.IDocument;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class MoveTargetEdit
/*     */   extends TextEdit
/*     */ {
/*     */   private MoveSourceEdit fSource;
/*     */   
/*     */   public MoveTargetEdit(int offset) {
/*  49 */     super(offset, 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MoveTargetEdit(int offset, MoveSourceEdit source) {
/*  59 */     this(offset);
/*  60 */     setSourceEdit(source);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private MoveTargetEdit(MoveTargetEdit other) {
/*  67 */     super(other);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MoveSourceEdit getSourceEdit() {
/*  77 */     return this.fSource;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSourceEdit(MoveSourceEdit edit) {
/*  89 */     if (this.fSource != edit) {
/*  90 */       this.fSource = edit;
/*  91 */       this.fSource.setTargetEdit(this);
/*  92 */       TextEdit parent = getParent();
/*  93 */       while (parent != null) {
/*  94 */         if (parent == this.fSource)
/*  95 */           throw new MalformedTreeException(parent, this, TextEditMessages.getString("MoveTargetEdit.wrong_parent")); 
/*  96 */         parent = parent.getParent();
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   protected TextEdit doCopy() {
/* 103 */     return new MoveTargetEdit(this);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void postProcessCopy(TextEditCopier copier) {
/* 108 */     if (this.fSource != null) {
/* 109 */       MoveTargetEdit target = (MoveTargetEdit)copier.getCopy(this);
/* 110 */       MoveSourceEdit source = (MoveSourceEdit)copier.getCopy(this.fSource);
/* 111 */       if (target != null && source != null) {
/* 112 */         target.setSourceEdit(source);
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   protected void accept0(TextEditVisitor visitor) {
/* 118 */     boolean visitChildren = visitor.visit(this);
/* 119 */     if (visitChildren) {
/* 120 */       acceptChildren(visitor);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   int traverseConsistencyCheck(TextEditProcessor processor, IDocument document, List<List<TextEdit>> sourceEdits) {
/* 128 */     return super.traverseConsistencyCheck(processor, document, sourceEdits) + 1;
/*     */   }
/*     */ 
/*     */   
/*     */   void performConsistencyCheck(TextEditProcessor processor, IDocument document) throws MalformedTreeException {
/* 133 */     if (this.fSource == null)
/* 134 */       throw new MalformedTreeException(getParent(), this, TextEditMessages.getString("MoveTargetEdit.no_source")); 
/* 135 */     if (this.fSource.getTargetEdit() != this) {
/* 136 */       throw new MalformedTreeException(getParent(), this, TextEditMessages.getString("MoveTargetEdit.different_target"));
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   int performDocumentUpdating(IDocument document) throws BadLocationException {
/* 146 */     String source = this.fSource.getContent();
/* 147 */     document.replace(getOffset(), getLength(), source);
/* 148 */     this.fDelta = source.length() - getLength();
/*     */     
/* 150 */     MultiTextEdit sourceRoot = this.fSource.getSourceRoot();
/* 151 */     if (sourceRoot != null) {
/* 152 */       sourceRoot.internalMoveTree(getOffset());
/* 153 */       TextEdit[] sourceChildren = sourceRoot.removeChildren();
/* 154 */       List<TextEdit> children = new ArrayList<>(sourceChildren.length); byte b; int i; TextEdit[] arrayOfTextEdit1;
/* 155 */       for (i = (arrayOfTextEdit1 = sourceChildren).length, b = 0; b < i; ) { TextEdit child = arrayOfTextEdit1[b];
/* 156 */         child.internalSetParent(this);
/* 157 */         children.add(child); b++; }
/*     */       
/* 159 */       internalSetChildren(children);
/*     */     } 
/* 161 */     this.fSource.clearContent();
/* 162 */     return this.fDelta;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   int traverseRegionUpdating(TextEditProcessor processor, IDocument document, int accumulatedDelta, boolean delete) {
/* 172 */     if (delete) {
/* 173 */       deleteTree();
/*     */     } else {
/* 175 */       internalMoveTree(accumulatedDelta);
/*     */     } 
/* 177 */     return accumulatedDelta + this.fDelta;
/*     */   }
/*     */ 
/*     */   
/*     */   boolean deleteChildren() {
/* 182 */     return false;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.text-3.13.0.jar!\org\eclipse\text\edits\MoveTargetEdit.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */