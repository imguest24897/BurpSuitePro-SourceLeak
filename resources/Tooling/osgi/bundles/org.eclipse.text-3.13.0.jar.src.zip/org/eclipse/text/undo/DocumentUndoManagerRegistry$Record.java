/*    */ package org.eclipse.text.undo;
/*    */ 
/*    */ import org.eclipse.jface.text.IDocument;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class Record
/*    */ {
/*    */   private int count;
/*    */   private IDocumentUndoManager undoManager;
/*    */   
/*    */   public Record(IDocument document) {
/* 43 */     this.count = 0;
/* 44 */     this.undoManager = new DocumentUndoManager(document);
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.text-3.13.0.jar!\org\eclipse\tex\\undo\DocumentUndoManagerRegistry$Record.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */