/*    */ package org.eclipse.text.templates;
/*    */ 
/*    */ import java.util.Iterator;
/*    */ import java.util.LinkedHashMap;
/*    */ import java.util.Map;
/*    */ import org.eclipse.jface.text.templates.TemplateContextType;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ContextTypeRegistry
/*    */ {
/* 35 */   private final Map<String, TemplateContextType> fContextTypes = new LinkedHashMap<>();
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void addContextType(TemplateContextType contextType) {
/* 44 */     this.fContextTypes.put(contextType.getId(), contextType);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public TemplateContextType getContextType(String id) {
/* 54 */     return this.fContextTypes.get(id);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Iterator<TemplateContextType> contextTypes() {
/* 63 */     return this.fContextTypes.values().iterator();
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.text-3.13.0.jar!\org\eclipse\text\templates\ContextTypeRegistry.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */