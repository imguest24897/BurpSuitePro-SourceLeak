/*     */ package org.eclipse.text.edits;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.eclipse.core.runtime.Assert;
/*     */ import org.eclipse.jface.text.BadLocationException;
/*     */ import org.eclipse.jface.text.IDocument;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TextEditProcessor
/*     */ {
/*     */   private IDocument fDocument;
/*     */   private TextEdit fRoot;
/*     */   private int fStyle;
/*     */   private boolean fChecked;
/*     */   private MalformedTreeException fException;
/*     */   private List<List<TextEdit>> fSourceEdits;
/*     */   
/*     */   public TextEditProcessor(IDocument document, TextEdit root, int style) {
/*  61 */     this(document, root, style, false);
/*     */   }
/*     */   
/*     */   private TextEditProcessor(IDocument document, TextEdit root, int style, boolean secondary) {
/*  65 */     Assert.isNotNull(document);
/*  66 */     Assert.isNotNull(root);
/*  67 */     this.fDocument = document;
/*  68 */     this.fRoot = root;
/*  69 */     if (this.fRoot instanceof MultiTextEdit)
/*  70 */       ((MultiTextEdit)this.fRoot).defineRegion(0); 
/*  71 */     this.fStyle = style;
/*  72 */     if (secondary) {
/*  73 */       this.fChecked = true;
/*  74 */       this.fSourceEdits = new ArrayList<>();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static TextEditProcessor createSourceComputationProcessor(IDocument document, TextEdit root, int style) {
/*  89 */     return new TextEditProcessor(document, root, style, true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IDocument getDocument() {
/*  98 */     return this.fDocument;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TextEdit getRoot() {
/* 107 */     return this.fRoot;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getStyle() {
/* 118 */     return this.fStyle;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean canPerformEdits() {
/*     */     try {
/* 131 */       this.fRoot.dispatchCheckIntegrity(this);
/* 132 */       this.fChecked = true;
/* 133 */     } catch (MalformedTreeException e) {
/* 134 */       this.fException = e;
/* 135 */       return false;
/*     */     } 
/* 137 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public UndoEdit performEdits() throws MalformedTreeException, BadLocationException {
/* 152 */     if (!this.fChecked) {
/* 153 */       this.fRoot.dispatchCheckIntegrity(this);
/*     */     }
/* 155 */     else if (this.fException != null) {
/* 156 */       throw this.fException;
/*     */     } 
/* 158 */     return this.fRoot.dispatchPerformEdits(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean considerEdit(TextEdit edit) {
/* 171 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   void checkIntegrityDo() throws MalformedTreeException {
/* 177 */     this.fSourceEdits = new ArrayList<>();
/* 178 */     this.fRoot.traverseConsistencyCheck(this, this.fDocument, this.fSourceEdits);
/* 179 */     if (this.fRoot.getExclusiveEnd() > this.fDocument.getLength())
/* 180 */       throw new MalformedTreeException(null, this.fRoot, TextEditMessages.getString("TextEditProcessor.invalid_length")); 
/*     */   }
/*     */   
/*     */   void checkIntegrityUndo() {
/* 184 */     if (this.fRoot.getExclusiveEnd() > this.fDocument.getLength()) {
/* 185 */       throw new MalformedTreeException(null, this.fRoot, TextEditMessages.getString("TextEditProcessor.invalid_length"));
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   UndoEdit executeDo() throws BadLocationException {
/* 191 */     UndoCollector collector = new UndoCollector(this.fRoot);
/*     */     try {
/* 193 */       if (createUndo())
/* 194 */         collector.connect(this.fDocument); 
/* 195 */       computeSources();
/* 196 */       this.fRoot.traverseDocumentUpdating(this, this.fDocument);
/* 197 */       if (updateRegions()) {
/* 198 */         this.fRoot.traverseRegionUpdating(this, this.fDocument, 0, false);
/*     */       }
/*     */     } finally {
/* 201 */       collector.disconnect(this.fDocument);
/*     */     } 
/* 203 */     return collector.undo;
/*     */   }
/*     */   
/*     */   private void computeSources() {
/* 207 */     for (List<TextEdit> list : this.fSourceEdits) {
/* 208 */       if (list != null) {
/* 209 */         for (TextEdit edit : list) {
/* 210 */           edit.traverseSourceComputation(this, this.fDocument);
/*     */         }
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   UndoEdit executeUndo() throws BadLocationException {
/* 217 */     UndoCollector collector = new UndoCollector(this.fRoot);
/*     */     try {
/* 219 */       if (createUndo())
/* 220 */         collector.connect(this.fDocument); 
/* 221 */       TextEdit[] edits = this.fRoot.getChildren();
/* 222 */       for (int i = edits.length - 1; i >= 0; i--) {
/* 223 */         edits[i].performDocumentUpdating(this.fDocument);
/*     */       }
/*     */     } finally {
/* 226 */       collector.disconnect(this.fDocument);
/*     */     } 
/* 228 */     return collector.undo;
/*     */   }
/*     */   
/*     */   private boolean createUndo() {
/* 232 */     return ((this.fStyle & 0x1) != 0);
/*     */   }
/*     */   
/*     */   private boolean updateRegions() {
/* 236 */     return ((this.fStyle & 0x2) != 0);
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.text-3.13.0.jar!\org\eclipse\text\edits\TextEditProcessor.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */