/*    */ package org.eclipse.text.undo;
/*    */ 
/*    */ import java.text.MessageFormat;
/*    */ import java.util.MissingResourceException;
/*    */ import java.util.ResourceBundle;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class UndoMessages
/*    */ {
/*    */   private static final String BUNDLE_NAME = "org.eclipse.text.undo.UndoMessages";
/* 29 */   private static final ResourceBundle RESOURCE_BUNDLE = ResourceBundle.getBundle("org.eclipse.text.undo.UndoMessages");
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static String getString(String key) {
/*    */     try {
/* 36 */       return RESOURCE_BUNDLE.getString(key);
/* 37 */     } catch (MissingResourceException missingResourceException) {
/* 38 */       return String.valueOf('!') + key + '!';
/*    */     } 
/*    */   }
/*    */   
/*    */   public static String getFormattedString(String key, Object arg) {
/* 43 */     return getFormattedString(key, new Object[] { arg });
/*    */   }
/*    */   
/*    */   public static String getFormattedString(String key, Object[] args) {
/* 47 */     return MessageFormat.format(getString(key), args);
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.text-3.13.0.jar!\org\eclipse\tex\\undo\UndoMessages.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */