/*     */ package org.eclipse.text.edits;
/*     */ 
/*     */ import java.util.List;
/*     */ import org.eclipse.core.runtime.Assert;
/*     */ import org.eclipse.jface.text.BadLocationException;
/*     */ import org.eclipse.jface.text.IDocument;
/*     */ import org.eclipse.jface.text.IRegion;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MultiTextEdit
/*     */   extends TextEdit
/*     */ {
/*     */   private boolean fDefined;
/*     */   
/*     */   public MultiTextEdit() {
/*  50 */     super(0, 2147483647);
/*  51 */     this.fDefined = false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MultiTextEdit(int offset, int length) {
/*  65 */     super(offset, length);
/*  66 */     this.fDefined = true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected MultiTextEdit(MultiTextEdit other) {
/*  73 */     super(other);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void checkIntegrity() throws MalformedTreeException {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final boolean isDefined() {
/*  94 */     if (this.fDefined)
/*  95 */       return true; 
/*  96 */     return hasChildren();
/*     */   }
/*     */ 
/*     */   
/*     */   public final int getOffset() {
/* 101 */     if (this.fDefined) {
/* 102 */       return super.getOffset();
/*     */     }
/* 104 */     List<TextEdit> children = internalGetChildren();
/* 105 */     if (children == null || children.isEmpty()) {
/* 106 */       return 0;
/*     */     }
/* 108 */     return ((TextEdit)children.get(0)).getOffset();
/*     */   }
/*     */ 
/*     */   
/*     */   public final int getLength() {
/* 113 */     if (this.fDefined) {
/* 114 */       return super.getLength();
/*     */     }
/* 116 */     List<TextEdit> children = internalGetChildren();
/* 117 */     if (children == null || children.isEmpty()) {
/* 118 */       return 0;
/*     */     }
/* 120 */     TextEdit first = children.get(0);
/* 121 */     TextEdit last = children.get(children.size() - 1);
/* 122 */     return last.getOffset() - first.getOffset() + last.getLength();
/*     */   }
/*     */ 
/*     */   
/*     */   public final boolean covers(TextEdit other) {
/* 127 */     if (this.fDefined) {
/* 128 */       return super.covers(other);
/*     */     }
/* 130 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean canZeroLengthCover() {
/* 135 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   protected TextEdit doCopy() {
/* 140 */     Assert.isTrue((MultiTextEdit.class == getClass()), "Subclasses must reimplement copy0");
/* 141 */     return new MultiTextEdit(this);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void accept0(TextEditVisitor visitor) {
/* 146 */     boolean visitChildren = visitor.visit(this);
/* 147 */     if (visitChildren) {
/* 148 */       acceptChildren(visitor);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   void adjustOffset(int delta) {
/* 154 */     if (this.fDefined) {
/* 155 */       super.adjustOffset(delta);
/*     */     }
/*     */   }
/*     */   
/*     */   void adjustLength(int delta) {
/* 160 */     if (this.fDefined) {
/* 161 */       super.adjustLength(delta);
/*     */     }
/*     */   }
/*     */   
/*     */   void performConsistencyCheck(TextEditProcessor processor, IDocument document) throws MalformedTreeException {
/* 166 */     checkIntegrity();
/*     */   }
/*     */ 
/*     */   
/*     */   int performDocumentUpdating(IDocument document) throws BadLocationException {
/* 171 */     this.fDelta = 0;
/* 172 */     return this.fDelta;
/*     */   }
/*     */ 
/*     */   
/*     */   boolean deleteChildren() {
/* 177 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   void aboutToBeAdded(TextEdit parent) {
/* 182 */     defineRegion(parent.getOffset());
/*     */   }
/*     */   
/*     */   void defineRegion(int parentOffset) {
/* 186 */     if (this.fDefined)
/*     */       return; 
/* 188 */     if (hasChildren()) {
/* 189 */       IRegion region = getCoverage(getChildren());
/* 190 */       internalSetOffset(region.getOffset());
/* 191 */       internalSetLength(region.getLength());
/*     */     } else {
/* 193 */       internalSetOffset(parentOffset);
/* 194 */       internalSetLength(0);
/*     */     } 
/* 196 */     this.fDefined = true;
/*     */   }
/*     */ 
/*     */   
/*     */   void internalToString(StringBuilder buffer, int indent) {
/* 201 */     super.internalToString(buffer, indent);
/* 202 */     if (!this.fDefined)
/* 203 */       buffer.append(" [undefined]"); 
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.text-3.13.0.jar!\org\eclipse\text\edits\MultiTextEdit.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */