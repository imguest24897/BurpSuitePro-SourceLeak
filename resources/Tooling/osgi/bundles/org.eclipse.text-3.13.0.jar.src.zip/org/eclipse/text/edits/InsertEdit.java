/*    */ package org.eclipse.text.edits;
/*    */ 
/*    */ import org.eclipse.core.runtime.Assert;
/*    */ import org.eclipse.jface.text.BadLocationException;
/*    */ import org.eclipse.jface.text.IDocument;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class InsertEdit
/*    */   extends TextEdit
/*    */ {
/*    */   private String fText;
/*    */   
/*    */   public InsertEdit(int offset, String text) {
/* 41 */     super(offset, 0);
/* 42 */     Assert.isNotNull(text);
/* 43 */     this.fText = text;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   private InsertEdit(InsertEdit other) {
/* 50 */     super(other);
/* 51 */     this.fText = other.fText;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String getText() {
/* 60 */     return this.fText;
/*    */   }
/*    */ 
/*    */   
/*    */   protected TextEdit doCopy() {
/* 65 */     return new InsertEdit(this);
/*    */   }
/*    */ 
/*    */   
/*    */   protected void accept0(TextEditVisitor visitor) {
/* 70 */     boolean visitChildren = visitor.visit(this);
/* 71 */     if (visitChildren) {
/* 72 */       acceptChildren(visitor);
/*    */     }
/*    */   }
/*    */ 
/*    */   
/*    */   int performDocumentUpdating(IDocument document) throws BadLocationException {
/* 78 */     document.replace(getOffset(), getLength(), this.fText);
/* 79 */     this.fDelta = this.fText.length() - getLength();
/* 80 */     return this.fDelta;
/*    */   }
/*    */ 
/*    */   
/*    */   boolean deleteChildren() {
/* 85 */     return false;
/*    */   }
/*    */ 
/*    */   
/*    */   void internalToString(StringBuilder buffer, int indent) {
/* 90 */     super.internalToString(buffer, indent);
/* 91 */     buffer.append(" <<").append(this.fText);
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.text-3.13.0.jar!\org\eclipse\text\edits\InsertEdit.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */