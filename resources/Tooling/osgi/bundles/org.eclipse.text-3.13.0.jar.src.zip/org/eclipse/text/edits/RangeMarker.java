/*    */ package org.eclipse.text.edits;
/*    */ 
/*    */ import org.eclipse.jface.text.BadLocationException;
/*    */ import org.eclipse.jface.text.IDocument;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class RangeMarker
/*    */   extends TextEdit
/*    */ {
/*    */   public RangeMarker(int offset, int length) {
/* 34 */     super(offset, length);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   private RangeMarker(RangeMarker other) {
/* 41 */     super(other);
/*    */   }
/*    */ 
/*    */   
/*    */   protected TextEdit doCopy() {
/* 46 */     return new RangeMarker(this);
/*    */   }
/*    */ 
/*    */   
/*    */   protected void accept0(TextEditVisitor visitor) {
/* 51 */     boolean visitChildren = visitor.visit(this);
/* 52 */     if (visitChildren) {
/* 53 */       acceptChildren(visitor);
/*    */     }
/*    */   }
/*    */ 
/*    */   
/*    */   int performDocumentUpdating(IDocument document) throws BadLocationException {
/* 59 */     this.fDelta = 0;
/* 60 */     return this.fDelta;
/*    */   }
/*    */ 
/*    */   
/*    */   boolean deleteChildren() {
/* 65 */     return false;
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.text-3.13.0.jar!\org\eclipse\text\edits\RangeMarker.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */