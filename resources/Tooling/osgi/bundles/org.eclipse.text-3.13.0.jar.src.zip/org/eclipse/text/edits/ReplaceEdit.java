/*    */ package org.eclipse.text.edits;
/*    */ 
/*    */ import org.eclipse.core.runtime.Assert;
/*    */ import org.eclipse.jface.text.BadLocationException;
/*    */ import org.eclipse.jface.text.IDocument;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class ReplaceEdit
/*    */   extends TextEdit
/*    */ {
/*    */   private String fText;
/*    */   
/*    */   public ReplaceEdit(int offset, int length, String text) {
/* 39 */     super(offset, length);
/* 40 */     Assert.isNotNull(text);
/* 41 */     this.fText = text;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   private ReplaceEdit(ReplaceEdit other) {
/* 50 */     super(other);
/* 51 */     this.fText = other.fText;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String getText() {
/* 61 */     return this.fText;
/*    */   }
/*    */ 
/*    */   
/*    */   protected TextEdit doCopy() {
/* 66 */     return new ReplaceEdit(this);
/*    */   }
/*    */ 
/*    */   
/*    */   protected void accept0(TextEditVisitor visitor) {
/* 71 */     boolean visitChildren = visitor.visit(this);
/* 72 */     if (visitChildren) {
/* 73 */       acceptChildren(visitor);
/*    */     }
/*    */   }
/*    */ 
/*    */   
/*    */   int performDocumentUpdating(IDocument document) throws BadLocationException {
/* 79 */     document.replace(getOffset(), getLength(), this.fText);
/* 80 */     this.fDelta = this.fText.length() - getLength();
/* 81 */     return this.fDelta;
/*    */   }
/*    */ 
/*    */   
/*    */   boolean deleteChildren() {
/* 86 */     return true;
/*    */   }
/*    */ 
/*    */   
/*    */   void internalToString(StringBuilder buffer, int indent) {
/* 91 */     super.internalToString(buffer, indent);
/* 92 */     buffer.append(" <<").append(this.fText);
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.text-3.13.0.jar!\org\eclipse\text\edits\ReplaceEdit.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */