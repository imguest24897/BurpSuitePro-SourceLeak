/*     */ package org.eclipse.text.templates;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.io.Reader;
/*     */ import java.io.Writer;
/*     */ import java.nio.charset.StandardCharsets;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.HashSet;
/*     */ import java.util.MissingResourceException;
/*     */ import java.util.ResourceBundle;
/*     */ import java.util.Set;
/*     */ import javax.xml.parsers.DocumentBuilder;
/*     */ import javax.xml.parsers.DocumentBuilderFactory;
/*     */ import javax.xml.parsers.ParserConfigurationException;
/*     */ import javax.xml.transform.Transformer;
/*     */ import javax.xml.transform.TransformerException;
/*     */ import javax.xml.transform.TransformerFactory;
/*     */ import javax.xml.transform.dom.DOMSource;
/*     */ import javax.xml.transform.stream.StreamResult;
/*     */ import org.eclipse.core.runtime.Assert;
/*     */ import org.eclipse.core.runtime.ILog;
/*     */ import org.eclipse.core.runtime.IStatus;
/*     */ import org.eclipse.core.runtime.Platform;
/*     */ import org.eclipse.core.runtime.Status;
/*     */ import org.eclipse.jface.text.templates.Template;
/*     */ import org.eclipse.osgi.util.NLS;
/*     */ import org.w3c.dom.Attr;
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.NamedNodeMap;
/*     */ import org.w3c.dom.Node;
/*     */ import org.w3c.dom.NodeList;
/*     */ import org.w3c.dom.Text;
/*     */ import org.xml.sax.InputSource;
/*     */ import org.xml.sax.SAXException;
/*     */ import org.xml.sax.helpers.DefaultHandler;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TemplateReaderWriter
/*     */ {
/*     */   private static final String TEMPLATE_ROOT = "templates";
/*     */   private static final String TEMPLATE_ELEMENT = "template";
/*     */   private static final String NAME_ATTRIBUTE = "name";
/*     */   private static final String ID_ATTRIBUTE = "id";
/*     */   private static final String DESCRIPTION_ATTRIBUTE = "description";
/*     */   private static final String CONTEXT_ATTRIBUTE = "context";
/*     */   private static final String ENABLED_ATTRIBUTE = "enabled";
/*     */   private static final String DELETED_ATTRIBUTE = "deleted";
/*     */   private static final String AUTO_INSERTABLE_ATTRIBUTE = "autoinsert";
/*     */   
/*     */   public TemplatePersistenceData[] read(Reader reader) throws IOException {
/* 100 */     return read(reader, (ResourceBundle)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TemplatePersistenceData readSingle(Reader reader, String id) throws IOException {
/* 116 */     TemplatePersistenceData[] datas = read(new InputSource(reader), null, id);
/* 117 */     if (datas.length > 0)
/* 118 */       return datas[0]; 
/* 119 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TemplatePersistenceData[] read(Reader reader, ResourceBundle bundle) throws IOException {
/* 131 */     return read(new InputSource(reader), bundle, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TemplatePersistenceData[] read(InputStream stream, ResourceBundle bundle) throws IOException {
/* 143 */     return read(new InputSource(stream), bundle, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private TemplatePersistenceData[] read(InputSource source, ResourceBundle bundle, String singleId) throws IOException {
/*     */     try {
/* 157 */       Collection<TemplatePersistenceData> templates = new ArrayList<>();
/* 158 */       Set<String> ids = new HashSet<>();
/*     */       
/* 160 */       DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
/* 161 */       DocumentBuilder parser = factory.newDocumentBuilder();
/* 162 */       parser.setErrorHandler(new DefaultHandler());
/* 163 */       Document document = parser.parse(source);
/*     */       
/* 165 */       NodeList elements = document.getElementsByTagName("template");
/*     */       
/* 167 */       int count = elements.getLength();
/* 168 */       for (int i = 0; i != count; i++) {
/* 169 */         Node node = elements.item(i);
/* 170 */         NamedNodeMap attributes = node.getAttributes();
/*     */         
/* 172 */         if (attributes != null) {
/*     */ 
/*     */           
/* 175 */           String id = getStringValue(attributes, "id", null);
/* 176 */           if (id != null && ids.contains(id)) {
/* 177 */             String PLUGIN_ID = "org.eclipse.jface.text";
/* 178 */             ILog log = Platform.getLog(Platform.getBundle(PLUGIN_ID));
/* 179 */             String message = NLS.bind(TextTemplateMessages.getString("TemplateReaderWriter.duplicate.id"), id);
/* 180 */             log.log((IStatus)new Status(2, PLUGIN_ID, 0, message, null));
/*     */           } else {
/* 182 */             ids.add(id);
/*     */           } 
/*     */           
/* 185 */           if (singleId == null || singleId.equals(id)) {
/*     */ 
/*     */             
/* 188 */             boolean deleted = getBooleanValue(attributes, "deleted", false);
/*     */             
/* 190 */             String name = getStringValue(attributes, "name");
/* 191 */             name = translateString(name, bundle);
/*     */             
/* 193 */             String description = getStringValue(attributes, "description", "");
/* 194 */             description = translateString(description, bundle);
/*     */             
/* 196 */             String context = getStringValue(attributes, "context");
/*     */             
/* 198 */             if (name == null || context == null) {
/* 199 */               throw new IOException(TextTemplateMessages.getString("TemplateReaderWriter.error.missing_attribute"));
/*     */             }
/* 201 */             boolean enabled = getBooleanValue(attributes, "enabled", true);
/* 202 */             boolean autoInsertable = getBooleanValue(attributes, "autoinsert", true);
/*     */             
/* 204 */             StringBuilder buffer = new StringBuilder();
/* 205 */             NodeList children = node.getChildNodes();
/* 206 */             for (int j = 0; j != children.getLength(); j++) {
/* 207 */               String value = children.item(j).getNodeValue();
/* 208 */               if (value != null)
/* 209 */                 buffer.append(value); 
/*     */             } 
/* 211 */             String pattern = buffer.toString();
/* 212 */             pattern = translateString(pattern, bundle);
/*     */             
/* 214 */             Template template = new Template(name, description, context, pattern, autoInsertable);
/* 215 */             TemplatePersistenceData data = new TemplatePersistenceData(template, enabled, id);
/* 216 */             data.setDeleted(deleted);
/*     */             
/* 218 */             templates.add(data);
/*     */             
/* 220 */             if (singleId != null && singleId.equals(id))
/*     */               break; 
/*     */           } 
/*     */         } 
/* 224 */       }  return templates.<TemplatePersistenceData>toArray(new TemplatePersistenceData[templates.size()]);
/*     */     }
/* 226 */     catch (ParserConfigurationException parserConfigurationException) {
/* 227 */       Assert.isTrue(false);
/* 228 */     } catch (SAXException e) {
/* 229 */       throw (IOException)(new IOException("Could not read template file")).initCause(e);
/*     */     } 
/*     */     
/* 232 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void save(TemplatePersistenceData[] templates, OutputStream stream) throws IOException {
/* 243 */     save(templates, new StreamResult(stream));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void save(TemplatePersistenceData[] templates, Writer writer) throws IOException {
/* 254 */     save(templates, new StreamResult(writer));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void save(TemplatePersistenceData[] templates, StreamResult result) throws IOException {
/*     */     try {
/* 266 */       DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
/* 267 */       DocumentBuilder builder = factory.newDocumentBuilder();
/* 268 */       Document document = builder.newDocument();
/*     */       
/* 270 */       Node root = document.createElement("templates");
/* 271 */       document.appendChild(root); byte b; int i;
/*     */       TemplatePersistenceData[] arrayOfTemplatePersistenceData;
/* 273 */       for (i = (arrayOfTemplatePersistenceData = templates).length, b = 0; b < i; ) { TemplatePersistenceData data = arrayOfTemplatePersistenceData[b];
/* 274 */         Template template = data.getTemplate();
/*     */         
/* 276 */         Node node = document.createElement("template");
/* 277 */         root.appendChild(node);
/*     */         
/* 279 */         NamedNodeMap attributes = node.getAttributes();
/*     */         
/* 281 */         String id = data.getId();
/* 282 */         if (id != null) {
/* 283 */           Attr idAttr = document.createAttribute("id");
/* 284 */           idAttr.setValue(id);
/* 285 */           attributes.setNamedItem(idAttr);
/*     */         } 
/*     */         
/* 288 */         if (template != null) {
/* 289 */           Attr name = document.createAttribute("name");
/* 290 */           name.setValue(validateXML(template.getName()));
/* 291 */           attributes.setNamedItem(name);
/*     */         } 
/*     */         
/* 294 */         if (template != null) {
/* 295 */           Attr description = document.createAttribute("description");
/* 296 */           description.setValue(validateXML(template.getDescription()));
/* 297 */           attributes.setNamedItem(description);
/*     */         } 
/*     */         
/* 300 */         if (template != null) {
/* 301 */           Attr context = document.createAttribute("context");
/* 302 */           context.setValue(validateXML(template.getContextTypeId()));
/* 303 */           attributes.setNamedItem(context);
/*     */         } 
/*     */         
/* 306 */         Attr enabled = document.createAttribute("enabled");
/* 307 */         enabled.setValue(data.isEnabled() ? Boolean.toString(true) : Boolean.toString(false));
/* 308 */         attributes.setNamedItem(enabled);
/*     */         
/* 310 */         Attr deleted = document.createAttribute("deleted");
/* 311 */         deleted.setValue(data.isDeleted() ? Boolean.toString(true) : Boolean.toString(false));
/* 312 */         attributes.setNamedItem(deleted);
/*     */         
/* 314 */         if (template != null) {
/* 315 */           Attr autoInsertable = document.createAttribute("autoinsert");
/* 316 */           autoInsertable.setValue(template.isAutoInsertable() ? Boolean.toString(true) : Boolean.toString(false));
/* 317 */           attributes.setNamedItem(autoInsertable);
/*     */         } 
/*     */         
/* 320 */         if (template != null) {
/* 321 */           Text pattern = document.createTextNode(validateXML(template.getPattern()));
/* 322 */           node.appendChild(pattern);
/*     */         } 
/*     */         
/*     */         b++; }
/*     */       
/* 327 */       Transformer transformer = TransformerFactory.newInstance().newTransformer();
/* 328 */       transformer.setOutputProperty("method", "xml");
/* 329 */       transformer.setOutputProperty("encoding", StandardCharsets.UTF_8.name());
/* 330 */       DOMSource source = new DOMSource(document);
/*     */       
/* 332 */       transformer.transform(source, result);
/*     */     }
/* 334 */     catch (ParserConfigurationException parserConfigurationException) {
/* 335 */       Assert.isTrue(false);
/* 336 */     } catch (TransformerException e) {
/* 337 */       if (e.getException() instanceof IOException)
/* 338 */         throw (IOException)e.getException(); 
/* 339 */       Assert.isTrue(false);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static String validateXML(String string) throws IOException {
/* 352 */     for (int i = 0; i < string.length(); i++) {
/* 353 */       char ch = string.charAt(i);
/* 354 */       if (ch != '\t' && ch != '\n' && ch != '\r' && ch < ' ')
/* 355 */         throw new IOException("Character reference \"&#" + Integer.toString(ch) + "\" is an invalid XML character."); 
/*     */     } 
/* 357 */     return string;
/*     */   }
/*     */   
/*     */   private boolean getBooleanValue(NamedNodeMap attributes, String attribute, boolean defaultValue) throws SAXException {
/* 361 */     Node enabledNode = attributes.getNamedItem(attribute);
/* 362 */     if (enabledNode == null)
/* 363 */       return defaultValue; 
/* 364 */     if (enabledNode.getNodeValue().equals(Boolean.toString(true)))
/* 365 */       return true; 
/* 366 */     if (enabledNode.getNodeValue().equals(Boolean.toString(false))) {
/* 367 */       return false;
/*     */     }
/* 369 */     throw new SAXException(TextTemplateMessages.getString("TemplateReaderWriter.error.illegal_boolean_attribute"));
/*     */   }
/*     */   
/*     */   private String getStringValue(NamedNodeMap attributes, String name) throws SAXException {
/* 373 */     String val = getStringValue(attributes, name, null);
/* 374 */     if (val == null)
/* 375 */       throw new SAXException(TextTemplateMessages.getString("TemplateReaderWriter.error.missing_attribute")); 
/* 376 */     return val;
/*     */   }
/*     */   
/*     */   private String getStringValue(NamedNodeMap attributes, String name, String defaultValue) {
/* 380 */     Node node = attributes.getNamedItem(name);
/* 381 */     return (node == null) ? defaultValue : node.getNodeValue();
/*     */   }
/*     */   
/*     */   private String translateString(String str, ResourceBundle bundle) {
/* 385 */     if (bundle == null) {
/* 386 */       return str;
/*     */     }
/* 388 */     int idx = str.indexOf('%');
/* 389 */     if (idx == -1) {
/* 390 */       return str;
/*     */     }
/* 392 */     StringBuilder buf = new StringBuilder();
/* 393 */     int k = 0;
/* 394 */     while (idx != -1) {
/* 395 */       buf.append(str.substring(k, idx));
/* 396 */       for (k = idx + 1; k < str.length() && !Character.isWhitespace(str.charAt(k)); k++);
/*     */ 
/*     */       
/* 399 */       String key = str.substring(idx + 1, k);
/* 400 */       buf.append(getBundleString(key, bundle));
/* 401 */       idx = str.indexOf('%', k);
/*     */     } 
/* 403 */     buf.append(str.substring(k));
/* 404 */     return buf.toString();
/*     */   }
/*     */   
/*     */   private String getBundleString(String key, ResourceBundle bundle) {
/* 408 */     if (bundle != null) {
/*     */       try {
/* 410 */         return bundle.getString(key);
/* 411 */       } catch (MissingResourceException missingResourceException) {
/* 412 */         return String.valueOf('!') + key + '!';
/*     */       } 
/*     */     }
/* 415 */     return TextTemplateMessages.getString(key);
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.text-3.13.0.jar!\org\eclipse\text\templates\TemplateReaderWriter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */