/*    */ package org.eclipse.text.edits;
/*    */ 
/*    */ import org.eclipse.core.runtime.Assert;
/*    */ import org.eclipse.jface.text.BadLocationException;
/*    */ import org.eclipse.jface.text.DocumentEvent;
/*    */ import org.eclipse.jface.text.IDocument;
/*    */ import org.eclipse.jface.text.IDocumentListener;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class UndoCollector
/*    */   implements IDocumentListener
/*    */ {
/*    */   protected UndoEdit undo;
/*    */   private int fOffset;
/*    */   private int fLength;
/*    */   private String fLastCurrentText;
/*    */   
/*    */   public UndoCollector(TextEdit root) {
/* 36 */     this.fOffset = root.getOffset();
/* 37 */     this.fLength = root.getLength();
/*    */   }
/*    */   
/*    */   public void connect(IDocument document) {
/* 41 */     document.addDocumentListener(this);
/* 42 */     this.undo = new UndoEdit();
/*    */   }
/*    */   
/*    */   public void disconnect(IDocument document) {
/* 46 */     if (this.undo != null) {
/* 47 */       document.removeDocumentListener(this);
/* 48 */       this.undo.defineRegion(this.fOffset, this.fLength);
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   public void documentChanged(DocumentEvent event) {
/* 54 */     this.fLength += getDelta(event);
/*    */   }
/*    */   
/*    */   private static int getDelta(DocumentEvent event) {
/* 58 */     String text = event.getText();
/* 59 */     return (text == null) ? -event.getLength() : (text.length() - event.getLength());
/*    */   }
/*    */ 
/*    */   
/*    */   public void documentAboutToBeChanged(DocumentEvent event) {
/* 64 */     int offset = event.getOffset();
/* 65 */     int currentLength = event.getLength();
/* 66 */     String currentText = null;
/*    */     try {
/* 68 */       currentText = event.getDocument().get(offset, currentLength);
/* 69 */     } catch (BadLocationException badLocationException) {
/* 70 */       Assert.isTrue(false, "Can't happen");
/*    */     } 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 80 */     if (this.fLastCurrentText != null && this.fLastCurrentText.equals(currentText)) {
/* 81 */       currentText = this.fLastCurrentText;
/*    */     } else {
/* 83 */       this.fLastCurrentText = currentText;
/*    */     } 
/* 85 */     String newText = event.getText();
/* 86 */     this.undo.add(new ReplaceEdit(offset, (newText != null) ? newText.length() : 0, currentText));
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.text-3.13.0.jar!\org\eclipse\text\edits\UndoCollector.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */