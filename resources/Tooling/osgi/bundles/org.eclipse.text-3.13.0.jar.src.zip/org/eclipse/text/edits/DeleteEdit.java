/*    */ package org.eclipse.text.edits;
/*    */ 
/*    */ import org.eclipse.jface.text.BadLocationException;
/*    */ import org.eclipse.jface.text.IDocument;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class DeleteEdit
/*    */   extends TextEdit
/*    */ {
/*    */   public DeleteEdit(int offset, int length) {
/* 36 */     super(offset, length);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   private DeleteEdit(DeleteEdit other) {
/* 43 */     super(other);
/*    */   }
/*    */ 
/*    */   
/*    */   protected TextEdit doCopy() {
/* 48 */     return new DeleteEdit(this);
/*    */   }
/*    */ 
/*    */   
/*    */   protected void accept0(TextEditVisitor visitor) {
/* 53 */     boolean visitChildren = visitor.visit(this);
/* 54 */     if (visitChildren) {
/* 55 */       acceptChildren(visitor);
/*    */     }
/*    */   }
/*    */ 
/*    */   
/*    */   int performDocumentUpdating(IDocument document) throws BadLocationException {
/* 61 */     document.replace(getOffset(), getLength(), "");
/* 62 */     this.fDelta = -getLength();
/* 63 */     return this.fDelta;
/*    */   }
/*    */ 
/*    */   
/*    */   boolean deleteChildren() {
/* 68 */     return true;
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.text-3.13.0.jar!\org\eclipse\text\edits\DeleteEdit.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */