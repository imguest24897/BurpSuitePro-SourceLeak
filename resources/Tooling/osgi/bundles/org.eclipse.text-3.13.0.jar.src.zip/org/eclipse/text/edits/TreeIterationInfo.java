/*    */ package org.eclipse.text.edits;
/*    */ 
/*    */ import org.eclipse.core.runtime.Assert;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class TreeIterationInfo
/*    */ {
/* 25 */   private int fMark = -1;
/* 26 */   private TextEdit[][] fEditStack = new TextEdit[10][];
/* 27 */   private int[] fIndexStack = new int[10];
/*    */   
/*    */   public int getSize() {
/* 30 */     return this.fMark + 1;
/*    */   }
/*    */   public void push(TextEdit[] edits) {
/* 33 */     if (++this.fMark == this.fEditStack.length) {
/* 34 */       TextEdit[][] t1 = new TextEdit[this.fEditStack.length * 2][];
/* 35 */       System.arraycopy(this.fEditStack, 0, t1, 0, this.fEditStack.length);
/* 36 */       this.fEditStack = t1;
/* 37 */       int[] t2 = new int[this.fEditStack.length];
/* 38 */       System.arraycopy(this.fIndexStack, 0, t2, 0, this.fIndexStack.length);
/* 39 */       this.fIndexStack = t2;
/*    */     } 
/* 41 */     this.fEditStack[this.fMark] = edits;
/* 42 */     this.fIndexStack[this.fMark] = -1;
/*    */   }
/*    */   public void setIndex(int index) {
/* 45 */     this.fIndexStack[this.fMark] = index;
/*    */   }
/*    */   public void pop() {
/* 48 */     this.fEditStack[this.fMark] = null;
/* 49 */     this.fIndexStack[this.fMark] = -1;
/* 50 */     this.fMark--;
/*    */   }
/*    */   public void accept(Visitor visitor) {
/* 53 */     for (int i = this.fMark; i >= 0; i--) {
/* 54 */       Assert.isTrue((this.fIndexStack[i] >= 0));
/* 55 */       int start = this.fIndexStack[i] + 1;
/* 56 */       TextEdit[] edits = this.fEditStack[i];
/* 57 */       for (int s = start; s < edits.length; s++)
/* 58 */         visitor.visit(edits[s]); 
/*    */     } 
/*    */   }
/*    */   
/*    */   static interface Visitor {
/*    */     void visit(TextEdit param1TextEdit);
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.text-3.13.0.jar!\org\eclipse\text\edits\TreeIterationInfo.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */