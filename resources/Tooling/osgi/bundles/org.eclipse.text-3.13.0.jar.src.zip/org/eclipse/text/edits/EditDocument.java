/*     */ package org.eclipse.text.edits;
/*     */ 
/*     */ import org.eclipse.jface.text.BadLocationException;
/*     */ import org.eclipse.jface.text.BadPositionCategoryException;
/*     */ import org.eclipse.jface.text.IDocument;
/*     */ import org.eclipse.jface.text.IDocumentListener;
/*     */ import org.eclipse.jface.text.IDocumentPartitioner;
/*     */ import org.eclipse.jface.text.IDocumentPartitioningListener;
/*     */ import org.eclipse.jface.text.IPositionUpdater;
/*     */ import org.eclipse.jface.text.IRegion;
/*     */ import org.eclipse.jface.text.ITypedRegion;
/*     */ import org.eclipse.jface.text.Position;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class EditDocument
/*     */   implements IDocument
/*     */ {
/*     */   private StringBuilder fBuffer;
/*     */   
/*     */   public EditDocument(String content) {
/*  33 */     this.fBuffer = new StringBuilder(content);
/*     */   }
/*     */ 
/*     */   
/*     */   public void addDocumentListener(IDocumentListener listener) {
/*  38 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   
/*     */   public void addDocumentPartitioningListener(IDocumentPartitioningListener listener) {
/*  43 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   
/*     */   public void addPosition(Position position) throws BadLocationException {
/*  48 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   
/*     */   public void addPosition(String category, Position position) throws BadLocationException, BadPositionCategoryException {
/*  53 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   
/*     */   public void addPositionCategory(String category) {
/*  58 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   
/*     */   public void addPositionUpdater(IPositionUpdater updater) {
/*  63 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   
/*     */   public void addPrenotifiedDocumentListener(IDocumentListener documentAdapter) {
/*  68 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   
/*     */   public int computeIndexInCategory(String category, int offset) throws BadLocationException, BadPositionCategoryException {
/*  73 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   
/*     */   public int computeNumberOfLines(String text) {
/*  78 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   
/*     */   public ITypedRegion[] computePartitioning(int offset, int length) throws BadLocationException {
/*  83 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean containsPosition(String category, int offset, int length) {
/*  88 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean containsPositionCategory(String category) {
/*  93 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   
/*     */   public String get() {
/*  98 */     return this.fBuffer.toString();
/*     */   }
/*     */ 
/*     */   
/*     */   public String get(int offset, int length) throws BadLocationException {
/* 103 */     return this.fBuffer.substring(offset, offset + length);
/*     */   }
/*     */ 
/*     */   
/*     */   public char getChar(int offset) throws BadLocationException {
/* 108 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   
/*     */   public String getContentType(int offset) throws BadLocationException {
/* 113 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   
/*     */   public IDocumentPartitioner getDocumentPartitioner() {
/* 118 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   
/*     */   public String[] getLegalContentTypes() {
/* 123 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   
/*     */   public String[] getLegalLineDelimiters() {
/* 128 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   
/*     */   public int getLength() {
/* 133 */     return this.fBuffer.length();
/*     */   }
/*     */ 
/*     */   
/*     */   public String getLineDelimiter(int line) throws BadLocationException {
/* 138 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   
/*     */   public IRegion getLineInformation(int line) throws BadLocationException {
/* 143 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   
/*     */   public IRegion getLineInformationOfOffset(int offset) throws BadLocationException {
/* 148 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   
/*     */   public int getLineLength(int line) throws BadLocationException {
/* 153 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   
/*     */   public int getLineOffset(int line) throws BadLocationException {
/* 158 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   
/*     */   public int getLineOfOffset(int offset) throws BadLocationException {
/* 163 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   
/*     */   public int getNumberOfLines() {
/* 168 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   
/*     */   public int getNumberOfLines(int offset, int length) throws BadLocationException {
/* 173 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   
/*     */   public ITypedRegion getPartition(int offset) throws BadLocationException {
/* 178 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   
/*     */   public String[] getPositionCategories() {
/* 183 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   
/*     */   public Position[] getPositions(String category) throws BadPositionCategoryException {
/* 188 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   
/*     */   public IPositionUpdater[] getPositionUpdaters() {
/* 193 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   
/*     */   public void insertPositionUpdater(IPositionUpdater updater, int index) {
/* 198 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   
/*     */   public void removeDocumentListener(IDocumentListener listener) {
/* 203 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   
/*     */   public void removeDocumentPartitioningListener(IDocumentPartitioningListener listener) {
/* 208 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   
/*     */   public void removePosition(Position position) {
/* 213 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   
/*     */   public void removePosition(String category, Position position) throws BadPositionCategoryException {
/* 218 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   
/*     */   public void removePositionCategory(String category) throws BadPositionCategoryException {
/* 223 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   
/*     */   public void removePositionUpdater(IPositionUpdater updater) {
/* 228 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   
/*     */   public void removePrenotifiedDocumentListener(IDocumentListener documentAdapter) {
/* 233 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   
/*     */   public void replace(int offset, int length, String text) throws BadLocationException {
/* 238 */     this.fBuffer.replace(offset, offset + length, text);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public int search(int startOffset, String findString, boolean forwardSearch, boolean caseSensitive, boolean wholeWord) throws BadLocationException {
/* 249 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   
/*     */   public void set(String text) {
/* 254 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   
/*     */   public void setDocumentPartitioner(IDocumentPartitioner partitioner) {
/* 259 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.text-3.13.0.jar!\org\eclipse\text\edits\EditDocument.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */