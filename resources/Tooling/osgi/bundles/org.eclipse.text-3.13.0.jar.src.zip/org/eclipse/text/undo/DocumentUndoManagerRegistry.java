/*     */ package org.eclipse.text.undo;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import org.eclipse.core.runtime.Assert;
/*     */ import org.eclipse.jface.text.IDocument;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class DocumentUndoManagerRegistry
/*     */ {
/*     */   private static final class Record
/*     */   {
/*     */     private int count;
/*     */     private IDocumentUndoManager undoManager;
/*     */     
/*     */     public Record(IDocument document) {
/*  43 */       this.count = 0;
/*  44 */       this.undoManager = new DocumentUndoManager(document);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*  50 */   private static Map<IDocument, Record> fgFactory = new HashMap<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static synchronized void connect(IDocument document) {
/*  67 */     Assert.isNotNull(document);
/*  68 */     Record record = fgFactory.get(document);
/*  69 */     if (record == null) {
/*  70 */       record = new Record(document);
/*  71 */       fgFactory.put(document, record);
/*     */     } 
/*  73 */     record.count++;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static synchronized void disconnect(IDocument document) {
/*  82 */     Assert.isNotNull(document);
/*  83 */     Record record = fgFactory.get(document);
/*  84 */     record.count--;
/*  85 */     if (record.count == 0) {
/*  86 */       fgFactory.remove(document);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static synchronized IDocumentUndoManager getDocumentUndoManager(IDocument document) {
/* 104 */     Assert.isNotNull(document);
/* 105 */     Record record = fgFactory.get(document);
/* 106 */     if (record == null)
/* 107 */       return null; 
/* 108 */     return record.undoManager;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.text-3.13.0.jar!\org\eclipse\tex\\undo\DocumentUndoManagerRegistry.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */