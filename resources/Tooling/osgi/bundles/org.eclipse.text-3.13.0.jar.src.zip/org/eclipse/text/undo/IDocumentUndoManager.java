package org.eclipse.text.undo;

import org.eclipse.core.commands.ExecutionException;
import org.eclipse.core.commands.operations.IUndoContext;

public interface IDocumentUndoManager {
  void addDocumentUndoListener(IDocumentUndoListener paramIDocumentUndoListener);
  
  void removeDocumentUndoListener(IDocumentUndoListener paramIDocumentUndoListener);
  
  IUndoContext getUndoContext();
  
  void commit();
  
  void connect(Object paramObject);
  
  void disconnect(Object paramObject);
  
  void beginCompoundChange();
  
  void endCompoundChange();
  
  void setMaximalUndoLevel(int paramInt);
  
  void reset();
  
  boolean undoable();
  
  boolean redoable();
  
  void undo() throws ExecutionException;
  
  void redo() throws ExecutionException;
  
  void transferUndoHistory(IDocumentUndoManager paramIDocumentUndoManager);
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.text-3.13.0.jar!\org\eclipse\tex\\undo\IDocumentUndoManager.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */