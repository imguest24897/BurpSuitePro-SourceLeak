/*     */ package org.eclipse.text.undo;
/*     */ 
/*     */ import org.eclipse.core.runtime.Assert;
/*     */ import org.eclipse.jface.text.IDocument;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DocumentUndoEvent
/*     */ {
/*     */   public static final int ABOUT_TO_UNDO = 1;
/*     */   public static final int ABOUT_TO_REDO = 2;
/*     */   public static final int UNDONE = 4;
/*     */   public static final int REDONE = 8;
/*     */   public static final int COMPOUND = 16;
/*     */   private IDocument fDocument;
/*     */   private int fOffset;
/*     */   private String fText;
/*     */   private String fPreservedText;
/*     */   private int fEventType;
/*     */   private Object fSource;
/*     */   
/*     */   DocumentUndoEvent(IDocument doc, int offset, String text, String preservedText, int eventType, Object source) {
/*  93 */     Assert.isNotNull(doc);
/*  94 */     Assert.isTrue((offset >= 0));
/*     */     
/*  96 */     this.fDocument = doc;
/*  97 */     this.fOffset = offset;
/*  98 */     this.fText = text;
/*  99 */     this.fPreservedText = preservedText;
/* 100 */     this.fEventType = eventType;
/* 101 */     this.fSource = source;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IDocument getDocument() {
/* 110 */     return this.fDocument;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getOffset() {
/* 119 */     return this.fOffset;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getText() {
/* 128 */     return this.fText;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getPreservedText() {
/* 137 */     return this.fPreservedText;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getEventType() {
/* 146 */     return this.fEventType;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object getSource() {
/* 155 */     return this.fSource;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isCompound() {
/* 165 */     return ((this.fEventType & 0x10) != 0);
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.text-3.13.0.jar!\org\eclipse\tex\\undo\DocumentUndoEvent.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */