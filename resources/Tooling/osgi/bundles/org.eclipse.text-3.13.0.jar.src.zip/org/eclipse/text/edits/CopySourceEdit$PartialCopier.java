/*    */ package org.eclipse.text.edits;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class PartialCopier
/*    */   extends TextEditVisitor
/*    */ {
/*    */   TextEdit fResult;
/* 51 */   List<TextEdit> fParents = new ArrayList<>();
/*    */   TextEdit fCurrentParent;
/*    */   
/*    */   public static TextEdit perform(TextEdit source) {
/* 55 */     PartialCopier copier = new PartialCopier();
/* 56 */     source.accept(copier);
/* 57 */     return copier.fResult;
/*    */   }
/*    */   private void manageCopy(TextEdit copy) {
/* 60 */     if (this.fResult == null)
/* 61 */       this.fResult = copy; 
/* 62 */     if (this.fCurrentParent != null) {
/* 63 */       this.fCurrentParent.addChild(copy);
/*    */     }
/* 65 */     this.fParents.add(this.fCurrentParent);
/* 66 */     this.fCurrentParent = copy;
/*    */   }
/*    */   
/*    */   public void postVisit(TextEdit edit) {
/* 70 */     this.fCurrentParent = this.fParents.remove(this.fParents.size() - 1);
/*    */   }
/*    */   
/*    */   public boolean visitNode(TextEdit edit) {
/* 74 */     manageCopy(edit.doCopy());
/* 75 */     return true;
/*    */   }
/*    */   
/*    */   public boolean visit(CopySourceEdit edit) {
/* 79 */     manageCopy(new RangeMarker(edit.getOffset(), edit.getLength()));
/* 80 */     return true;
/*    */   }
/*    */   
/*    */   public boolean visit(CopyTargetEdit edit) {
/* 84 */     manageCopy(new InsertEdit(edit.getOffset(), edit.getSourceEdit().getContent()));
/* 85 */     return true;
/*    */   }
/*    */   
/*    */   public boolean visit(MoveSourceEdit edit) {
/* 89 */     manageCopy(new DeleteEdit(edit.getOffset(), edit.getLength()));
/* 90 */     return true;
/*    */   }
/*    */   
/*    */   public boolean visit(MoveTargetEdit edit) {
/* 94 */     manageCopy(new InsertEdit(edit.getOffset(), edit.getSourceEdit().getContent()));
/* 95 */     return true;
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.text-3.13.0.jar!\org\eclipse\text\edits\CopySourceEdit$PartialCopier.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */