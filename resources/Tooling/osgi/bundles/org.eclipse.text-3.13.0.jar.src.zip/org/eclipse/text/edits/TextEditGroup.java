/*     */ package org.eclipse.text.edits;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ import org.eclipse.core.runtime.Assert;
/*     */ import org.eclipse.jface.text.IRegion;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TextEditGroup
/*     */ {
/*     */   private String fDescription;
/*     */   private List<TextEdit> fEdits;
/*     */   
/*     */   public TextEditGroup(String name) {
/*  50 */     Assert.isNotNull(name);
/*  51 */     this.fDescription = name;
/*  52 */     this.fEdits = new ArrayList<>(3);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TextEditGroup(String name, TextEdit edit) {
/*  64 */     Assert.isNotNull(name);
/*  65 */     Assert.isNotNull(edit);
/*  66 */     this.fDescription = name;
/*  67 */     this.fEdits = new ArrayList<>(1);
/*  68 */     this.fEdits.add(edit);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TextEditGroup(String name, TextEdit[] edits) {
/*  81 */     Assert.isNotNull(name);
/*  82 */     Assert.isNotNull(edits);
/*  83 */     this.fDescription = name;
/*  84 */     this.fEdits = new ArrayList<>(Arrays.asList(edits));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getName() {
/*  93 */     return this.fDescription;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addTextEdit(TextEdit edit) {
/* 102 */     this.fEdits.add(edit);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean removeTextEdit(TextEdit edit) {
/* 113 */     return this.fEdits.remove(edit);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void clearTextEdits() {
/* 122 */     this.fEdits.clear();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isEmpty() {
/* 136 */     return this.fEdits.isEmpty();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TextEdit[] getTextEdits() {
/* 146 */     return this.fEdits.<TextEdit>toArray(new TextEdit[this.fEdits.size()]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IRegion getRegion() {
/* 158 */     int size = this.fEdits.size();
/* 159 */     if (size == 0)
/* 160 */       return null; 
/* 161 */     if (size == 1) {
/* 162 */       return ((TextEdit)this.fEdits.get(0)).getRegion();
/*     */     }
/* 164 */     return TextEdit.getCoverage(this.fEdits.<TextEdit>toArray(new TextEdit[this.fEdits.size()]));
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.text-3.13.0.jar!\org\eclipse\text\edits\TextEditGroup.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */