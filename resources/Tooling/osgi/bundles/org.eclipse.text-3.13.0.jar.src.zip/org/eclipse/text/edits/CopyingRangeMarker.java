/*    */ package org.eclipse.text.edits;
/*    */ 
/*    */ import org.eclipse.jface.text.BadLocationException;
/*    */ import org.eclipse.jface.text.IDocument;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class CopyingRangeMarker
/*    */   extends TextEdit
/*    */ {
/*    */   private String fText;
/*    */   
/*    */   public CopyingRangeMarker(int offset, int length) {
/* 38 */     super(offset, length);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   private CopyingRangeMarker(CopyingRangeMarker other) {
/* 45 */     super(other);
/* 46 */     this.fText = other.fText;
/*    */   }
/*    */ 
/*    */   
/*    */   protected TextEdit doCopy() {
/* 51 */     return new CopyingRangeMarker(this);
/*    */   }
/*    */ 
/*    */   
/*    */   protected void accept0(TextEditVisitor visitor) {
/* 56 */     boolean visitChildren = visitor.visit(this);
/* 57 */     if (visitChildren) {
/* 58 */       acceptChildren(visitor);
/*    */     }
/*    */   }
/*    */ 
/*    */   
/*    */   int performDocumentUpdating(IDocument document) throws BadLocationException {
/* 64 */     this.fText = document.get(getOffset(), getLength());
/* 65 */     this.fDelta = 0;
/* 66 */     return this.fDelta;
/*    */   }
/*    */ 
/*    */   
/*    */   boolean deleteChildren() {
/* 71 */     return false;
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.text-3.13.0.jar!\org\eclipse\text\edits\CopyingRangeMarker.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */