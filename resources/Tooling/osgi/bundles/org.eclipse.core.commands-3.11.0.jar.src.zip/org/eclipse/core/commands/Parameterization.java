/*     */ package org.eclipse.core.commands;
/*     */ 
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import java.util.Objects;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class Parameterization
/*     */ {
/*     */   private static final int HASH_CODE_NOT_COMPUTED = -1;
/*     */   private static final int HASH_FACTOR = 89;
/*  49 */   private static final int HASH_INITIAL = Parameterization.class.getName().hashCode();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  55 */   private transient int hashCode = -1;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final IParameter parameter;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final String value;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Parameterization(IParameter parameter, String value) {
/*  79 */     if (parameter == null) {
/*  80 */       throw new NullPointerException("You cannot parameterize a null parameter");
/*     */     }
/*     */     
/*  83 */     this.parameter = parameter;
/*  84 */     this.value = value;
/*     */   }
/*     */ 
/*     */   
/*     */   public final boolean equals(Object object) {
/*  89 */     if (this == object) {
/*  90 */       return true;
/*     */     }
/*     */     
/*  93 */     if (!(object instanceof Parameterization)) {
/*  94 */       return false;
/*     */     }
/*     */     
/*  97 */     Parameterization parameterization = (Parameterization)object;
/*  98 */     if (!Objects.equals(this.parameter.getId(), parameterization.parameter.getId())) {
/*  99 */       return false;
/*     */     }
/*     */     
/* 102 */     return Objects.equals(this.value, parameterization.value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final IParameter getParameter() {
/* 111 */     return this.parameter;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final String getValue() {
/* 120 */     return this.value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final String getValueName() throws ParameterValuesException {
/* 133 */     Map<?, ?> parameterValues = this.parameter.getValues().getParameterValues();
/* 134 */     Iterator<?> parameterValueItr = parameterValues.entrySet().iterator();
/* 135 */     String returnValue = null;
/* 136 */     while (parameterValueItr.hasNext()) {
/* 137 */       Map.Entry<?, ?> entry = (Map.Entry<?, ?>)parameterValueItr.next();
/* 138 */       String currentValue = (String)entry.getValue();
/* 139 */       if (Objects.equals(this.value, currentValue)) {
/* 140 */         returnValue = (String)entry.getKey();
/*     */         
/*     */         break;
/*     */       } 
/*     */     } 
/* 145 */     if (returnValue == null) {
/* 146 */       return "";
/*     */     }
/*     */     
/* 149 */     return returnValue;
/*     */   }
/*     */ 
/*     */   
/*     */   public final int hashCode() {
/* 154 */     if (this.hashCode == -1) {
/* 155 */       this.hashCode = HASH_INITIAL * 89 + Objects.hashCode(this.parameter);
/* 156 */       this.hashCode = this.hashCode * 89 + Objects.hashCode(this.value);
/* 157 */       if (this.hashCode == -1) {
/* 158 */         this.hashCode++;
/*     */       }
/*     */     } 
/* 161 */     return this.hashCode;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.commands-3.11.0.jar!\org\eclipse\core\commands\Parameterization.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */