/*    */ package org.eclipse.core.commands;
/*    */ 
/*    */ import org.eclipse.core.commands.common.AbstractHandleObjectEvent;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class ParameterTypeEvent
/*    */   extends AbstractHandleObjectEvent
/*    */ {
/*    */   private final ParameterType parameterType;
/*    */   
/*    */   ParameterTypeEvent(ParameterType parameterType, boolean definedChanged) {
/* 47 */     super(definedChanged);
/*    */     
/* 49 */     if (parameterType == null) {
/* 50 */       throw new NullPointerException();
/*    */     }
/*    */     
/* 53 */     this.parameterType = parameterType;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public final ParameterType getParameterType() {
/* 63 */     return this.parameterType;
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.commands-3.11.0.jar!\org\eclipse\core\commands\ParameterTypeEvent.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */