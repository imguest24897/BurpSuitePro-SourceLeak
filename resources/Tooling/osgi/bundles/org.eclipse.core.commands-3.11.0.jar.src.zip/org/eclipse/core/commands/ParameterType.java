/*     */ package org.eclipse.core.commands;
/*     */ 
/*     */ import org.eclipse.core.commands.common.HandleObject;
/*     */ import org.eclipse.core.commands.common.NotDefinedException;
/*     */ import org.eclipse.core.internal.commands.util.Util;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ParameterType
/*     */   extends HandleObject
/*     */   implements Comparable
/*     */ {
/*     */   private transient AbstractParameterValueConverter parameterTypeConverter;
/*     */   
/*     */   private static final boolean isInstanceOf(Object element, String type) {
/*  67 */     if (element == null) {
/*  68 */       return false;
/*     */     }
/*  70 */     return isSubtype(element.getClass(), type);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final boolean isSubtype(Class<?> clazz, String type) {
/*  86 */     if (clazz.getName().equals(type)) {
/*  87 */       return true;
/*     */     }
/*  89 */     Class<?> superClass = clazz.getSuperclass();
/*  90 */     if (superClass != null && isSubtype(superClass, type))
/*  91 */       return true;  byte b; int i;
/*     */     Class[] arrayOfClass;
/*  93 */     for (i = (arrayOfClass = clazz.getInterfaces()).length, b = 0; b < i; ) { Class<?> classInterface = arrayOfClass[b];
/*  94 */       if (isSubtype(classInterface, type))
/*  95 */         return true; 
/*     */       b++; }
/*     */     
/*  98 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 112 */   private transient String type = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   ParameterType(String id) {
/* 126 */     super(id);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void addListener(IParameterTypeListener listener) {
/* 137 */     addListenerObject(listener);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final int compareTo(Object object) {
/* 152 */     ParameterType castedObject = (ParameterType)object;
/* 153 */     int compareTo = Util.compare(this.defined, castedObject.defined);
/* 154 */     if (compareTo == 0) {
/* 155 */       compareTo = Util.compare(this.id, castedObject.id);
/*     */     }
/* 157 */     return compareTo;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void define(String type, AbstractParameterValueConverter parameterTypeConverter) {
/* 181 */     boolean definedChanged = !this.defined;
/* 182 */     this.defined = true;
/*     */     
/* 184 */     this.type = (type == null) ? Object.class.getName() : type;
/* 185 */     this.parameterTypeConverter = parameterTypeConverter;
/*     */     
/* 187 */     fireParameterTypeChanged(new ParameterTypeEvent(this, definedChanged));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final void fireParameterTypeChanged(ParameterTypeEvent event) {
/* 199 */     if (event == null) {
/* 200 */       throw new NullPointerException(
/* 201 */           "Cannot send a null event to listeners.");
/*     */     }
/*     */     
/* 204 */     if (!isListenerAttached())
/*     */       return;  byte b;
/*     */     int i;
/*     */     Object[] arrayOfObject;
/* 208 */     for (i = (arrayOfObject = getListeners()).length, b = 0; b < i; ) { Object listener = arrayOfObject[b];
/* 209 */       IParameterTypeListener parameterTypeListener = (IParameterTypeListener)listener;
/* 210 */       parameterTypeListener.parameterTypeChanged(event);
/*     */       b++; }
/*     */   
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final AbstractParameterValueConverter getValueConverter() throws NotDefinedException {
/* 224 */     if (!isDefined()) {
/* 225 */       throw new NotDefinedException(
/* 226 */           "Cannot use getValueConverter() with an undefined ParameterType");
/*     */     }
/*     */     
/* 229 */     return this.parameterTypeConverter;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isCompatible(Object value) throws NotDefinedException {
/* 246 */     if (!isDefined()) {
/* 247 */       throw new NotDefinedException(
/* 248 */           "Cannot use isCompatible() with an undefined ParameterType");
/*     */     }
/* 250 */     return isInstanceOf(value, this.type);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void removeListener(IParameterTypeListener listener) {
/* 263 */     removeListenerObject(listener);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final String toString() {
/* 274 */     if (this.string == null) {
/* 275 */       StringBuilder stringBuffer = new StringBuilder("ParameterType(");
/* 276 */       stringBuffer.append(this.id);
/* 277 */       stringBuffer.append(',');
/* 278 */       stringBuffer.append(this.defined);
/* 279 */       stringBuffer.append(')');
/* 280 */       this.string = stringBuffer.toString();
/*     */     } 
/* 282 */     return this.string;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void undefine() {
/* 291 */     this.string = null;
/*     */     
/* 293 */     boolean definedChanged = this.defined;
/* 294 */     this.defined = false;
/*     */     
/* 296 */     this.type = null;
/* 297 */     this.parameterTypeConverter = null;
/*     */     
/* 299 */     fireParameterTypeChanged(new ParameterTypeEvent(this, definedChanged));
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.commands-3.11.0.jar!\org\eclipse\core\commands\ParameterType.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */