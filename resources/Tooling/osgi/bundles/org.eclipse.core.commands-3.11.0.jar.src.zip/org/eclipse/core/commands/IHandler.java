package org.eclipse.core.commands;

public interface IHandler {
  void addHandlerListener(IHandlerListener paramIHandlerListener);
  
  void dispose();
  
  Object execute(ExecutionEvent paramExecutionEvent) throws ExecutionException;
  
  boolean isEnabled();
  
  boolean isHandled();
  
  void removeHandlerListener(IHandlerListener paramIHandlerListener);
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.commands-3.11.0.jar!\org\eclipse\core\commands\IHandler.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */