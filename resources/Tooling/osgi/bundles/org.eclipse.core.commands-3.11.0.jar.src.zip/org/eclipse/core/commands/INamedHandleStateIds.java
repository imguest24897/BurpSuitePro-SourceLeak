package org.eclipse.core.commands;

public interface INamedHandleStateIds {
  public static final String DESCRIPTION = "DESCRIPTION";
  
  public static final String NAME = "NAME";
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.commands-3.11.0.jar!\org\eclipse\core\commands\INamedHandleStateIds.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */