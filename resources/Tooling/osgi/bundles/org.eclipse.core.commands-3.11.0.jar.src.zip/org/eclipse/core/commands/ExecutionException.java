/*    */ package org.eclipse.core.commands;
/*    */ 
/*    */ import org.eclipse.core.commands.common.CommandException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class ExecutionException
/*    */   extends CommandException
/*    */ {
/*    */   private static final long serialVersionUID = 3258130262767448120L;
/*    */   
/*    */   public ExecutionException(String message) {
/* 43 */     super(message);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public ExecutionException(String message, Throwable cause) {
/* 56 */     super(message, cause);
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.commands-3.11.0.jar!\org\eclipse\core\commands\ExecutionException.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */