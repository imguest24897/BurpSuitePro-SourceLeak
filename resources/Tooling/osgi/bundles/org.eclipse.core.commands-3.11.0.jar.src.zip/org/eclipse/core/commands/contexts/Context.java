/*     */ package org.eclipse.core.commands.contexts;
/*     */ 
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.Objects;
/*     */ import java.util.Set;
/*     */ import org.eclipse.core.commands.common.NamedHandleObject;
/*     */ import org.eclipse.core.commands.common.NotDefinedException;
/*     */ import org.eclipse.core.internal.commands.util.Util;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class Context
/*     */   extends NamedHandleObject
/*     */   implements Comparable
/*     */ {
/*     */   private Set<IContextListener> listeners;
/*     */   private String parentId;
/*     */   
/*     */   Context(String id) {
/*  77 */     super(id);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void addContextListener(IContextListener listener) {
/*  90 */     if (listener == null) {
/*  91 */       throw new NullPointerException();
/*     */     }
/*     */     
/*  94 */     if (this.listeners == null) {
/*  95 */       this.listeners = new HashSet<>();
/*     */     }
/*     */     
/*  98 */     this.listeners.add(listener);
/*     */   }
/*     */ 
/*     */   
/*     */   public final int compareTo(Object object) {
/* 103 */     Context scheme = (Context)object;
/* 104 */     int compareTo = Util.compare(this.id, scheme.id);
/* 105 */     if (compareTo == 0) {
/* 106 */       compareTo = Util.compare(this.name, scheme.name);
/* 107 */       if (compareTo == 0) {
/* 108 */         compareTo = Util.compare(this.parentId, scheme.parentId);
/* 109 */         if (compareTo == 0) {
/* 110 */           compareTo = Util.compare(this.description, scheme.description);
/* 111 */           if (compareTo == 0) {
/* 112 */             compareTo = Util.compare(this.defined, scheme.defined);
/*     */           }
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 118 */     return compareTo;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void define(String name, String description, String parentId) {
/* 140 */     if (name == null) {
/* 141 */       throw new NullPointerException("The name of a context cannot be null");
/*     */     }
/*     */     
/* 144 */     boolean definedChanged = !this.defined;
/* 145 */     this.defined = true;
/*     */     
/* 147 */     boolean nameChanged = !Objects.equals(this.name, name);
/* 148 */     this.name = name;
/*     */     
/* 150 */     boolean descriptionChanged = !Objects.equals(this.description, 
/* 151 */         description);
/* 152 */     this.description = description;
/*     */     
/* 154 */     boolean parentIdChanged = !Objects.equals(this.parentId, parentId);
/* 155 */     this.parentId = parentId;
/*     */     
/* 157 */     fireContextChanged(new ContextEvent(this, definedChanged, nameChanged, descriptionChanged, parentIdChanged));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final void fireContextChanged(ContextEvent event) {
/* 169 */     if (event == null) {
/* 170 */       throw new NullPointerException("Cannot send a null event to listeners.");
/*     */     }
/*     */     
/* 173 */     if (this.listeners == null) {
/*     */       return;
/*     */     }
/*     */     
/* 177 */     Iterator<IContextListener> listenerItr = this.listeners.iterator();
/* 178 */     while (listenerItr.hasNext()) {
/* 179 */       IContextListener listener = listenerItr.next();
/* 180 */       listener.contextChanged(event);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final String getParentId() throws NotDefinedException {
/* 197 */     if (!this.defined) {
/* 198 */       throw new NotDefinedException("Cannot get the parent identifier from an undefined context. " + 
/* 199 */           this.id);
/*     */     }
/*     */     
/* 202 */     return this.parentId;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void removeContextListener(IContextListener contextListener) {
/* 216 */     if (contextListener == null) {
/* 217 */       throw new NullPointerException("Cannot remove a null listener.");
/*     */     }
/*     */     
/* 220 */     if (this.listeners == null) {
/*     */       return;
/*     */     }
/*     */     
/* 224 */     this.listeners.remove(contextListener);
/*     */     
/* 226 */     if (this.listeners.isEmpty()) {
/* 227 */       this.listeners = null;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final String toString() {
/* 239 */     if (this.string == null) {
/* 240 */       StringBuilder stringBuffer = new StringBuilder("Context(");
/* 241 */       stringBuffer.append(this.id);
/* 242 */       stringBuffer.append(',');
/* 243 */       stringBuffer.append(this.name);
/* 244 */       stringBuffer.append(',');
/* 245 */       stringBuffer.append(this.description);
/* 246 */       stringBuffer.append(',');
/* 247 */       stringBuffer.append(this.parentId);
/* 248 */       stringBuffer.append(',');
/* 249 */       stringBuffer.append(this.defined);
/* 250 */       stringBuffer.append(')');
/* 251 */       this.string = stringBuffer.toString();
/*     */     } 
/* 253 */     return this.string;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void undefine() {
/* 263 */     this.string = null;
/*     */     
/* 265 */     boolean definedChanged = this.defined;
/* 266 */     this.defined = false;
/*     */     
/* 268 */     boolean nameChanged = (this.name != null);
/* 269 */     this.name = null;
/*     */     
/* 271 */     boolean descriptionChanged = (this.description != null);
/* 272 */     this.description = null;
/*     */     
/* 274 */     boolean parentIdChanged = (this.parentId != null);
/* 275 */     this.parentId = null;
/*     */     
/* 277 */     fireContextChanged(new ContextEvent(this, definedChanged, nameChanged, descriptionChanged, parentIdChanged));
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.commands-3.11.0.jar!\org\eclipse\core\commands\contexts\Context.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */