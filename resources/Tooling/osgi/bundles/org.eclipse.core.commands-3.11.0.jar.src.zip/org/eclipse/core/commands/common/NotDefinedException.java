/*    */ package org.eclipse.core.commands.common;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class NotDefinedException
/*    */   extends CommandException
/*    */ {
/*    */   private static final long serialVersionUID = 3257572788998124596L;
/*    */   
/*    */   public NotDefinedException(String s) {
/* 41 */     super(s);
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.commands-3.11.0.jar!\org\eclipse\core\commands\common\NotDefinedException.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */