/*     */ package org.eclipse.core.commands;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractHandlerWithState
/*     */   extends AbstractHandler
/*     */   implements IObjectWithState, IStateListener
/*     */ {
/*     */   private Map<String, State> states;
/*  43 */   private static final String[] EMPTY = new String[0];
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addState(String stateId, State state) {
/*  64 */     if (state == null) {
/*  65 */       throw new NullPointerException("Cannot add a null state");
/*     */     }
/*     */     
/*  68 */     if (this.states == null) {
/*  69 */       this.states = new HashMap<>(3);
/*     */     }
/*  71 */     this.states.put(stateId, state);
/*  72 */     state.addListener(this);
/*  73 */     handleStateChange(state, null);
/*     */   }
/*     */ 
/*     */   
/*     */   public final State getState(String stateId) {
/*  78 */     if (this.states == null || this.states.isEmpty()) {
/*  79 */       return null;
/*     */     }
/*     */     
/*  82 */     return this.states.get(stateId);
/*     */   }
/*     */ 
/*     */   
/*     */   public final String[] getStateIds() {
/*  87 */     if (this.states == null || this.states.isEmpty()) {
/*  88 */       return EMPTY;
/*     */     }
/*     */     
/*  91 */     Set<String> stateIds = this.states.keySet();
/*  92 */     return stateIds.<String>toArray(new String[stateIds.size()]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void removeState(String stateId) {
/* 112 */     if (stateId == null) {
/* 113 */       throw new NullPointerException("Cannot remove a null state");
/*     */     }
/* 115 */     if (this.states == null) {
/*     */       return;
/*     */     }
/* 118 */     State state = this.states.get(stateId);
/* 119 */     if (state != null) {
/* 120 */       state.removeListener(this);
/* 121 */       if (this.states != null) {
/* 122 */         this.states.remove(stateId);
/* 123 */         if (this.states.isEmpty())
/* 124 */           this.states = null; 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.commands-3.11.0.jar!\org\eclipse\core\commands\AbstractHandlerWithState.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */