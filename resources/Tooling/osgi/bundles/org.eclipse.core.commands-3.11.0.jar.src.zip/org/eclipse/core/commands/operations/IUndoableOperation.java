package org.eclipse.core.commands.operations;

import org.eclipse.core.commands.ExecutionException;
import org.eclipse.core.runtime.IAdaptable;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.core.runtime.IStatus;

public interface IUndoableOperation {
  void addContext(IUndoContext paramIUndoContext);
  
  boolean canExecute();
  
  boolean canRedo();
  
  boolean canUndo();
  
  void dispose();
  
  IStatus execute(IProgressMonitor paramIProgressMonitor, IAdaptable paramIAdaptable) throws ExecutionException;
  
  IUndoContext[] getContexts();
  
  String getLabel();
  
  boolean hasContext(IUndoContext paramIUndoContext);
  
  IStatus redo(IProgressMonitor paramIProgressMonitor, IAdaptable paramIAdaptable) throws ExecutionException;
  
  void removeContext(IUndoContext paramIUndoContext);
  
  IStatus undo(IProgressMonitor paramIProgressMonitor, IAdaptable paramIAdaptable) throws ExecutionException;
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.commands-3.11.0.jar!\org\eclipse\core\commands\operations\IUndoableOperation.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */