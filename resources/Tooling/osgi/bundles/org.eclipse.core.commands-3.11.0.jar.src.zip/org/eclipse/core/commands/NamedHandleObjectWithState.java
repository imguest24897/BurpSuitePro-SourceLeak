/*     */ package org.eclipse.core.commands;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import org.eclipse.core.commands.common.NamedHandleObject;
/*     */ import org.eclipse.core.commands.common.NotDefinedException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ abstract class NamedHandleObjectWithState
/*     */   extends NamedHandleObject
/*     */   implements IObjectWithState
/*     */ {
/*  42 */   private static final String[] NO_STATE = new String[0];
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Map<String, State> states;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected NamedHandleObjectWithState(String id) {
/*  57 */     super(id);
/*     */   }
/*     */ 
/*     */   
/*     */   public void addState(String stateId, State state) {
/*  62 */     if (state == null) {
/*  63 */       throw new NullPointerException("Cannot add a null state");
/*     */     }
/*     */     
/*  66 */     if (this.states == null) {
/*  67 */       this.states = new HashMap<>(3);
/*     */     }
/*  69 */     this.states.put(stateId, state);
/*     */   }
/*     */ 
/*     */   
/*     */   public final String getDescription() throws NotDefinedException {
/*  74 */     String description = super.getDescription();
/*     */     
/*  76 */     State descriptionState = getState("DESCRIPTION");
/*  77 */     if (descriptionState != null) {
/*  78 */       Object value = descriptionState.getValue();
/*  79 */       if (value != null) {
/*  80 */         return value.toString();
/*     */       }
/*     */     } 
/*     */     
/*  84 */     return description;
/*     */   }
/*     */ 
/*     */   
/*     */   public final String getName() throws NotDefinedException {
/*  89 */     String name = super.getName();
/*     */     
/*  91 */     State nameState = getState("NAME");
/*  92 */     if (nameState != null) {
/*  93 */       Object value = nameState.getValue();
/*  94 */       if (value != null) {
/*  95 */         return value.toString();
/*     */       }
/*     */     } 
/*     */     
/*  99 */     return name;
/*     */   }
/*     */ 
/*     */   
/*     */   public final State getState(String stateId) {
/* 104 */     if (this.states == null || this.states.isEmpty()) {
/* 105 */       return null;
/*     */     }
/*     */     
/* 108 */     return this.states.get(stateId);
/*     */   }
/*     */ 
/*     */   
/*     */   public final String[] getStateIds() {
/* 113 */     if (this.states == null || this.states.isEmpty()) {
/* 114 */       return NO_STATE;
/*     */     }
/*     */     
/* 117 */     Set<String> stateIds = this.states.keySet();
/* 118 */     return stateIds.<String>toArray(new String[stateIds.size()]);
/*     */   }
/*     */ 
/*     */   
/*     */   public void removeState(String id) {
/* 123 */     if (id == null) {
/* 124 */       throw new NullPointerException("Cannot remove a null id");
/*     */     }
/*     */     
/* 127 */     if (this.states != null) {
/* 128 */       this.states.remove(id);
/* 129 */       if (this.states.isEmpty())
/* 130 */         this.states = null; 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.commands-3.11.0.jar!\org\eclipse\core\commands\NamedHandleObjectWithState.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */