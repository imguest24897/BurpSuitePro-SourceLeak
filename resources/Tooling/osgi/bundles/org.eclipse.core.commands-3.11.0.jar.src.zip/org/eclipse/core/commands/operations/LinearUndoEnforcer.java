/*    */ package org.eclipse.core.commands.operations;
/*    */ 
/*    */ import org.eclipse.core.runtime.IAdaptable;
/*    */ import org.eclipse.core.runtime.IStatus;
/*    */ import org.eclipse.core.runtime.Status;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class LinearUndoEnforcer
/*    */   extends LinearUndoViolationDetector
/*    */ {
/*    */   protected IStatus allowLinearRedoViolation(IUndoableOperation operation, IUndoContext context, IOperationHistory history, IAdaptable uiInfo) {
/* 45 */     return Status.CANCEL_STATUS;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected IStatus allowLinearUndoViolation(IUndoableOperation operation, IUndoContext context, IOperationHistory history, IAdaptable uiInfo) {
/* 56 */     return Status.CANCEL_STATUS;
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.commands-3.11.0.jar!\org\eclipse\core\commands\operations\LinearUndoEnforcer.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */