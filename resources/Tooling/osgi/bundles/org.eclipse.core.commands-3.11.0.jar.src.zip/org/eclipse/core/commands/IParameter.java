package org.eclipse.core.commands;

public interface IParameter {
  String getId();
  
  String getName();
  
  IParameterValues getValues() throws ParameterValuesException;
  
  boolean isOptional();
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.commands-3.11.0.jar!\org\eclipse\core\commands\IParameter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */