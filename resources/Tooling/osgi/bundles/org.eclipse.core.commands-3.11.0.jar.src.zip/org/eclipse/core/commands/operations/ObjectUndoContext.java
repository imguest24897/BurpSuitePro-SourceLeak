/*     */ package org.eclipse.core.commands.operations;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ObjectUndoContext
/*     */   extends UndoContext
/*     */ {
/*     */   private Object object;
/*     */   private String label;
/*  34 */   private List<IUndoContext> children = new ArrayList<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ObjectUndoContext(Object object) {
/*  43 */     this(object, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ObjectUndoContext(Object object, String label) {
/*  57 */     this.object = object;
/*  58 */     this.label = label;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getLabel() {
/*  63 */     if (this.label != null) {
/*  64 */       return this.label;
/*     */     }
/*  66 */     if (this.object != null) {
/*  67 */       return this.object.toString();
/*     */     }
/*  69 */     return super.getLabel();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object getObject() {
/*  78 */     return this.object;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addMatch(IUndoContext context) {
/*  93 */     this.children.add(context);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void removeMatch(IUndoContext context) {
/* 107 */     this.children.remove(context);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean matches(IUndoContext context) {
/* 113 */     if (this.children.contains(context)) {
/* 114 */       return true;
/*     */     }
/*     */     
/* 117 */     if (context instanceof ObjectUndoContext && getObject() != null) {
/* 118 */       return getObject().equals(((ObjectUndoContext)context).getObject());
/*     */     }
/*     */     
/* 121 */     return super.matches(context);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 132 */     return getLabel();
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.commands-3.11.0.jar!\org\eclipse\core\commands\operations\ObjectUndoContext.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */