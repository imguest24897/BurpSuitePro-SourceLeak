/*    */ package org.eclipse.core.commands.util;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Deprecated
/*    */ public final class Tracing
/*    */ {
/*    */   public static final String SEPARATOR = " >>> ";
/*    */   
/*    */   public static final void printTrace(String component, String message) {
/* 57 */     StringBuilder buffer = new StringBuilder();
/* 58 */     if (component != null) {
/* 59 */       buffer.append(component);
/*    */     }
/* 61 */     if (component != null && message != null) {
/* 62 */       buffer.append(" >>> ");
/*    */     }
/* 64 */     if (message != null) {
/* 65 */       buffer.append(message);
/*    */     }
/* 67 */     System.out.println(buffer.toString());
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.commands-3.11.0.jar!\org\eclipse\core\command\\util\Tracing.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */