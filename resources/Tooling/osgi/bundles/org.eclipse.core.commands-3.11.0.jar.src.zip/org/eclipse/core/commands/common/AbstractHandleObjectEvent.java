/*    */ package org.eclipse.core.commands.common;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class AbstractHandleObjectEvent
/*    */   extends AbstractBitSetEvent
/*    */ {
/*    */   protected static final int CHANGED_DEFINED = 1;
/*    */   protected static final int LAST_BIT_USED_ABSTRACT_HANDLE = 1;
/*    */   
/*    */   protected AbstractHandleObjectEvent(boolean definedChanged) {
/* 45 */     if (definedChanged) {
/* 46 */       this.changedValues |= 0x1;
/*    */     }
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public final boolean isDefinedChanged() {
/* 56 */     return ((this.changedValues & 0x1) != 0);
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.commands-3.11.0.jar!\org\eclipse\core\commands\common\AbstractHandleObjectEvent.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */