/*      */ package org.eclipse.core.commands.operations;
/*      */ 
/*      */ import java.util.ArrayList;
/*      */ import java.util.Arrays;
/*      */ import java.util.Collections;
/*      */ import java.util.HashMap;
/*      */ import java.util.Iterator;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import org.eclipse.core.commands.ExecutionException;
/*      */ import org.eclipse.core.commands.internal.util.Tracing;
/*      */ import org.eclipse.core.runtime.Assert;
/*      */ import org.eclipse.core.runtime.IAdaptable;
/*      */ import org.eclipse.core.runtime.IProgressMonitor;
/*      */ import org.eclipse.core.runtime.ISafeRunnable;
/*      */ import org.eclipse.core.runtime.IStatus;
/*      */ import org.eclipse.core.runtime.ListenerList;
/*      */ import org.eclipse.core.runtime.OperationCanceledException;
/*      */ import org.eclipse.core.runtime.SafeRunner;
/*      */ import org.eclipse.core.runtime.Status;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public final class DefaultOperationHistory
/*      */   implements IOperationHistory
/*      */ {
/*      */   private static final String FOR_OPERATION = "for operation ";
/*      */   private static final String OPERATIONHISTORY = "OPERATIONHISTORY";
/*      */   public static boolean DEBUG_OPERATION_HISTORY_NOTIFICATION;
/*      */   public static boolean DEBUG_OPERATION_HISTORY_UNEXPECTED;
/*      */   public static boolean DEBUG_OPERATION_HISTORY_DISPOSE;
/*      */   public static boolean DEBUG_OPERATION_HISTORY_OPENOPERATION;
/*      */   public static boolean DEBUG_OPERATION_HISTORY_APPROVAL;
/*      */   static final int DEFAULT_LIMIT = 20;
/*  125 */   ListenerList<IOperationApprover> approvers = new ListenerList(1);
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  130 */   private Map<IUndoContext, Integer> limits = Collections.synchronizedMap(new HashMap<>());
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  135 */   ListenerList<IOperationHistoryListener> listeners = new ListenerList(1);
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  140 */   private List<IUndoableOperation> redoList = Collections.synchronizedList(new ArrayList<>());
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  145 */   private List<IUndoableOperation> undoList = Collections.synchronizedList(new ArrayList<>());
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  151 */   final Object undoRedoHistoryLock = new Object();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private ICompositeOperation openComposite;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  164 */   final Object openCompositeLock = new Object();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void add(IUndoableOperation operation) {
/*  175 */     Assert.isNotNull(operation);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  185 */     synchronized (this.openCompositeLock) {
/*  186 */       if (this.openComposite != null && this.openComposite != operation) {
/*  187 */         this.openComposite.add(operation);
/*      */         
/*      */         return;
/*      */       } 
/*      */     } 
/*  192 */     if (checkUndoLimit(operation)) {
/*  193 */       synchronized (this.undoRedoHistoryLock) {
/*  194 */         this.undoList.add(operation);
/*      */       } 
/*  196 */       notifyAdd(operation);
/*      */ 
/*      */       
/*  199 */       IUndoContext[] contexts = operation.getContexts(); byte b; int i; IUndoContext[] arrayOfIUndoContext1;
/*  200 */       for (i = (arrayOfIUndoContext1 = contexts).length, b = 0; b < i; ) { IUndoContext context = arrayOfIUndoContext1[b];
/*  201 */         flushRedo(context);
/*      */         b++; }
/*      */     
/*      */     } else {
/*  205 */       operation.dispose();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void addOperationApprover(IOperationApprover approver) {
/*  230 */     this.approvers.add(approver);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void addOperationHistoryListener(IOperationHistoryListener listener) {
/*  255 */     this.listeners.add(listener);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean canRedo(IUndoContext context) {
/*  261 */     IUndoableOperation operation = getRedoOperation(context);
/*  262 */     return (operation != null && operation.canRedo());
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean canUndo(IUndoContext context) {
/*  268 */     IUndoableOperation operation = getUndoOperation(context);
/*  269 */     return (operation != null && operation.canUndo());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean checkRedoLimit(IUndoableOperation operation) {
/*  282 */     IUndoContext[] contexts = operation.getContexts(); byte b; int i; IUndoContext[] arrayOfIUndoContext1;
/*  283 */     for (i = (arrayOfIUndoContext1 = contexts).length, b = 0; b < i; ) { IUndoContext context = arrayOfIUndoContext1[b];
/*  284 */       int limit = getLimit(context);
/*  285 */       if (limit > 0) {
/*  286 */         forceRedoLimit(context, limit - 1);
/*      */       } else {
/*      */         
/*  289 */         operation.removeContext(context);
/*      */       }  b++; }
/*      */     
/*  292 */     return ((operation.getContexts()).length > 0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean checkUndoLimit(IUndoableOperation operation) {
/*  300 */     IUndoContext[] contexts = operation.getContexts(); byte b; int i; IUndoContext[] arrayOfIUndoContext1;
/*  301 */     for (i = (arrayOfIUndoContext1 = contexts).length, b = 0; b < i; ) { IUndoContext context = arrayOfIUndoContext1[b];
/*  302 */       int limit = getLimit(context);
/*  303 */       if (limit > 0) {
/*  304 */         forceUndoLimit(context, limit - 1);
/*      */       } else {
/*      */         
/*  307 */         operation.removeContext(context);
/*      */       }  b++; }
/*      */     
/*  310 */     return ((operation.getContexts()).length > 0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void dispose(IUndoContext context, boolean flushUndo, boolean flushRedo, boolean flushContext) {
/*  317 */     if (flushContext) {
/*  318 */       if (DEBUG_OPERATION_HISTORY_DISPOSE) {
/*  319 */         Tracing.printTrace("OPERATIONHISTORY", "Flushing context " + context);
/*      */       }
/*  321 */       flushUndo(context);
/*  322 */       flushRedo(context);
/*  323 */       this.limits.remove(context);
/*      */       return;
/*      */     } 
/*  326 */     if (flushUndo) {
/*  327 */       flushUndo(context);
/*      */     }
/*  329 */     if (flushRedo) {
/*  330 */       flushRedo(context);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private IStatus doRedo(IProgressMonitor monitor, IAdaptable info, IUndoableOperation operation) throws ExecutionException {
/*  344 */     IStatus status = getRedoApproval(operation, info);
/*  345 */     if (status.isOK()) {
/*  346 */       notifyAboutToRedo(operation);
/*      */       try {
/*  348 */         status = operation.redo(monitor, info);
/*  349 */       } catch (OperationCanceledException operationCanceledException) {
/*  350 */         status = Status.CANCEL_STATUS;
/*  351 */       } catch (ExecutionException e) {
/*  352 */         notifyNotOK(operation);
/*  353 */         if (DEBUG_OPERATION_HISTORY_UNEXPECTED) {
/*  354 */           Tracing.printTrace("OPERATIONHISTORY", 
/*  355 */               "ExecutionException while redoing " + operation);
/*      */         }
/*  357 */         throw e;
/*  358 */       } catch (Exception e) {
/*  359 */         notifyNotOK(operation);
/*  360 */         if (DEBUG_OPERATION_HISTORY_UNEXPECTED) {
/*  361 */           Tracing.printTrace("OPERATIONHISTORY", 
/*  362 */               "Exception while redoing " + operation);
/*      */         }
/*  364 */         throw new ExecutionException("While redoing the operation, an exception occurred", e);
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  370 */     if (status.isOK()) {
/*  371 */       boolean addedToUndo = true;
/*  372 */       synchronized (this.undoRedoHistoryLock) {
/*  373 */         this.redoList.remove(operation);
/*  374 */         if (checkUndoLimit(operation)) {
/*  375 */           this.undoList.add(operation);
/*      */         } else {
/*  377 */           addedToUndo = false;
/*      */         } 
/*      */       } 
/*      */ 
/*      */       
/*  382 */       if (!addedToUndo) {
/*  383 */         operation.dispose();
/*      */       }
/*      */ 
/*      */       
/*  387 */       notifyRedone(operation);
/*      */     } else {
/*  389 */       notifyNotOK(operation, status);
/*      */     } 
/*      */     
/*  392 */     return status;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private IStatus doUndo(IProgressMonitor monitor, IAdaptable info, IUndoableOperation operation) throws ExecutionException {
/*  403 */     IStatus status = getUndoApproval(operation, info);
/*  404 */     if (status.isOK()) {
/*  405 */       notifyAboutToUndo(operation);
/*      */       try {
/*  407 */         status = operation.undo(monitor, info);
/*  408 */       } catch (OperationCanceledException operationCanceledException) {
/*  409 */         status = Status.CANCEL_STATUS;
/*  410 */       } catch (ExecutionException e) {
/*  411 */         notifyNotOK(operation);
/*  412 */         if (DEBUG_OPERATION_HISTORY_UNEXPECTED) {
/*  413 */           Tracing.printTrace("OPERATIONHISTORY", 
/*  414 */               "ExecutionException while undoing " + operation);
/*      */         }
/*  416 */         throw e;
/*  417 */       } catch (Exception e) {
/*  418 */         notifyNotOK(operation);
/*  419 */         if (DEBUG_OPERATION_HISTORY_UNEXPECTED) {
/*  420 */           Tracing.printTrace("OPERATIONHISTORY", 
/*  421 */               "Exception while undoing " + operation);
/*      */         }
/*  423 */         throw new ExecutionException(
/*  424 */             "While undoing the operation, an exception occurred", e);
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/*  429 */     if (status.isOK()) {
/*  430 */       boolean addedToRedo = true;
/*  431 */       synchronized (this.undoRedoHistoryLock) {
/*  432 */         this.undoList.remove(operation);
/*  433 */         if (checkRedoLimit(operation)) {
/*  434 */           this.redoList.add(operation);
/*      */         } else {
/*  436 */           addedToRedo = false;
/*      */         } 
/*      */       } 
/*      */ 
/*      */       
/*  441 */       if (!addedToRedo) {
/*  442 */         operation.dispose();
/*      */       }
/*      */ 
/*      */       
/*  446 */       notifyUndone(operation);
/*      */     } else {
/*  448 */       notifyNotOK(operation, status);
/*      */     } 
/*  450 */     return status;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public IStatus execute(IUndoableOperation operation, IProgressMonitor monitor, IAdaptable info) throws ExecutionException {
/*  456 */     Assert.isNotNull(operation);
/*      */ 
/*      */     
/*  459 */     if (!operation.canExecute()) {
/*  460 */       return IOperationHistory.OPERATION_INVALID_STATUS;
/*      */     }
/*      */ 
/*      */     
/*  464 */     IStatus status = getExecuteApproval(operation, info);
/*  465 */     if (!status.isOK())
/*      */     {
/*  467 */       return status;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  475 */     boolean merging = false;
/*  476 */     synchronized (this.openCompositeLock) {
/*  477 */       if (this.openComposite != null) {
/*      */ 
/*      */ 
/*      */         
/*  481 */         if (this.openComposite == operation) {
/*  482 */           return IOperationHistory.OPERATION_INVALID_STATUS;
/*      */         }
/*  484 */         this.openComposite.add(operation);
/*  485 */         merging = true;
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  492 */     if (!merging) {
/*  493 */       notifyAboutToExecute(operation);
/*      */     }
/*      */     try {
/*  496 */       status = operation.execute(monitor, info);
/*  497 */     } catch (OperationCanceledException operationCanceledException) {
/*  498 */       status = Status.CANCEL_STATUS;
/*  499 */     } catch (ExecutionException e) {
/*  500 */       notifyNotOK(operation);
/*  501 */       throw e;
/*  502 */     } catch (Exception e) {
/*  503 */       notifyNotOK(operation);
/*  504 */       throw new ExecutionException(
/*  505 */           "While executing the operation, an exception occurred", e);
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  510 */     if (!merging) {
/*  511 */       if (status.isOK()) {
/*  512 */         notifyDone(operation);
/*  513 */         add(operation);
/*      */       } else {
/*  515 */         notifyNotOK(operation, status);
/*      */ 
/*      */         
/*  518 */         operation.dispose();
/*      */       } 
/*      */     }
/*      */     
/*  522 */     return status;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private IUndoableOperation[] filter(List<IUndoableOperation> list, IUndoContext context) {
/*  538 */     List<IUndoableOperation> filtered = new ArrayList<>();
/*  539 */     synchronized (this.undoRedoHistoryLock) {
/*  540 */       Iterator<IUndoableOperation> iterator = list.iterator();
/*  541 */       while (iterator.hasNext()) {
/*  542 */         IUndoableOperation operation = iterator.next();
/*  543 */         if (operation.hasContext(context)) {
/*  544 */           filtered.add(operation);
/*      */         }
/*      */       } 
/*      */     } 
/*  548 */     return filtered.<IUndoableOperation>toArray(new IUndoableOperation[filtered.size()]);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void flushRedo(IUndoContext context) {
/*  555 */     if (DEBUG_OPERATION_HISTORY_DISPOSE) {
/*  556 */       Tracing.printTrace("OPERATIONHISTORY", "Flushing redo history for " + context);
/*      */     }
/*      */     
/*  559 */     synchronized (this.undoRedoHistoryLock) {
/*      */       
/*  561 */       IUndoableOperation[] arrayOfIUndoableOperation1 = filter(this.redoList, context); byte b; int i; IUndoableOperation[] arrayOfIUndoableOperation2;
/*  562 */       for (i = (arrayOfIUndoableOperation2 = arrayOfIUndoableOperation1).length, b = 0; b < i; ) { Object element = arrayOfIUndoableOperation2[b];
/*  563 */         IUndoableOperation operation = (IUndoableOperation)element;
/*  564 */         if (context == GLOBAL_UNDO_CONTEXT || (operation.getContexts()).length == 1) {
/*      */ 
/*      */           
/*  567 */           this.redoList.remove(operation);
/*  568 */           internalRemove(operation);
/*      */         } else {
/*      */           byte b1;
/*      */           
/*      */           int j;
/*      */           
/*      */           IUndoContext[] arrayOfIUndoContext;
/*  575 */           for (j = (arrayOfIUndoContext = operation.getContexts()).length, b1 = 0; b1 < j; ) { IUndoContext undoContext = arrayOfIUndoContext[b1];
/*  576 */             if (undoContext.matches(context))
/*  577 */               operation.removeContext(undoContext); 
/*      */             b1++; }
/*      */           
/*  580 */           if ((operation.getContexts()).length == 0) {
/*  581 */             this.redoList.remove(operation);
/*  582 */             internalRemove(operation);
/*      */           } 
/*      */         } 
/*      */         b++; }
/*      */     
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private void flushUndo(IUndoContext context) {
/*  593 */     if (DEBUG_OPERATION_HISTORY_DISPOSE) {
/*  594 */       Tracing.printTrace("OPERATIONHISTORY", "Flushing undo history for " + context);
/*      */     }
/*      */     
/*  597 */     synchronized (this.undoRedoHistoryLock) {
/*      */ 
/*      */       
/*  600 */       IUndoableOperation[] arrayOfIUndoableOperation1 = filter(this.undoList, context); byte b; int i; IUndoableOperation[] arrayOfIUndoableOperation2;
/*  601 */       for (i = (arrayOfIUndoableOperation2 = arrayOfIUndoableOperation1).length, b = 0; b < i; ) { Object element = arrayOfIUndoableOperation2[b];
/*  602 */         IUndoableOperation operation = (IUndoableOperation)element;
/*  603 */         if (context == GLOBAL_UNDO_CONTEXT || (operation.getContexts()).length == 1) {
/*      */ 
/*      */           
/*  606 */           this.undoList.remove(operation);
/*  607 */           internalRemove(operation);
/*      */         } else {
/*      */           byte b1;
/*      */           
/*      */           int j;
/*      */           
/*      */           IUndoContext[] arrayOfIUndoContext;
/*  614 */           for (j = (arrayOfIUndoContext = operation.getContexts()).length, b1 = 0; b1 < j; ) { IUndoContext undoContext = arrayOfIUndoContext[b1];
/*  615 */             if (undoContext.matches(context))
/*  616 */               operation.removeContext(undoContext); 
/*      */             b1++; }
/*      */           
/*  619 */           if ((operation.getContexts()).length == 0) {
/*  620 */             this.undoList.remove(operation);
/*  621 */             internalRemove(operation);
/*      */           } 
/*      */         } 
/*      */ 
/*      */ 
/*      */         
/*      */         b++; }
/*      */     
/*      */     } 
/*      */ 
/*      */     
/*  632 */     ICompositeOperation endedComposite = null;
/*  633 */     synchronized (this.openCompositeLock) {
/*  634 */       if (this.openComposite != null && 
/*  635 */         this.openComposite.hasContext(context)) {
/*  636 */         if (context == GLOBAL_UNDO_CONTEXT || (this.openComposite.getContexts()).length == 1) {
/*  637 */           endedComposite = this.openComposite;
/*  638 */           this.openComposite = null;
/*      */         } else {
/*  640 */           this.openComposite.removeContext(context);
/*      */         } 
/*      */       }
/*      */     } 
/*      */ 
/*      */     
/*  646 */     if (endedComposite != null) {
/*  647 */       notifyNotOK(endedComposite);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void forceRedoLimit(IUndoContext context, int max) {
/*  656 */     synchronized (this.undoRedoHistoryLock) {
/*  657 */       IUndoableOperation[] arrayOfIUndoableOperation = filter(this.redoList, context);
/*  658 */       int size = arrayOfIUndoableOperation.length;
/*  659 */       if (size > 0) {
/*  660 */         int index = 0;
/*  661 */         while (size > max) {
/*  662 */           IUndoableOperation removed = arrayOfIUndoableOperation[index];
/*  663 */           if (context == GLOBAL_UNDO_CONTEXT || (removed.getContexts()).length == 1) {
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*  668 */             this.redoList.remove(removed);
/*  669 */             internalRemove(removed);
/*      */ 
/*      */           
/*      */           }
/*      */           else {
/*      */ 
/*      */             
/*  676 */             removed.removeContext(context);
/*      */           } 
/*  678 */           size--;
/*  679 */           index++;
/*      */         } 
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void forceUndoLimit(IUndoContext context, int max) {
/*  690 */     synchronized (this.undoRedoHistoryLock) {
/*  691 */       IUndoableOperation[] arrayOfIUndoableOperation = filter(this.undoList, context);
/*  692 */       int size = arrayOfIUndoableOperation.length;
/*  693 */       if (size > 0) {
/*  694 */         int index = 0;
/*  695 */         while (size > max) {
/*  696 */           IUndoableOperation removed = arrayOfIUndoableOperation[index];
/*  697 */           if (context == GLOBAL_UNDO_CONTEXT || (removed.getContexts()).length == 1) {
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*  702 */             this.undoList.remove(removed);
/*  703 */             internalRemove(removed);
/*      */ 
/*      */           
/*      */           }
/*      */           else {
/*      */ 
/*      */             
/*  710 */             removed.removeContext(context);
/*      */           } 
/*  712 */           size--;
/*  713 */           index++;
/*      */         } 
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public int getLimit(IUndoContext context) {
/*  721 */     if (!this.limits.containsKey(context)) {
/*  722 */       return 20;
/*      */     }
/*  724 */     return ((Integer)this.limits.get(context)).intValue();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private IStatus getRedoApproval(IUndoableOperation operation, IAdaptable info) {
/*  733 */     for (IOperationApprover approver : this.approvers) {
/*  734 */       IStatus approval = approver.proceedRedoing(operation, this, info);
/*  735 */       if (!approval.isOK()) {
/*  736 */         if (DEBUG_OPERATION_HISTORY_APPROVAL) {
/*  737 */           Tracing.printTrace("OPERATIONHISTORY", 
/*  738 */               "Redo not approved by " + approver + 
/*  739 */               "for operation " + operation + 
/*  740 */               " approved by " + approval);
/*      */         }
/*  742 */         return approval;
/*      */       } 
/*      */     } 
/*  745 */     return Status.OK_STATUS;
/*      */   }
/*      */ 
/*      */   
/*      */   public IUndoableOperation[] getRedoHistory(IUndoContext context) {
/*  750 */     Assert.isNotNull(context);
/*  751 */     return filter(this.redoList, context);
/*      */   }
/*      */ 
/*      */   
/*      */   public IUndoableOperation getRedoOperation(IUndoContext context) {
/*  756 */     Assert.isNotNull(context);
/*  757 */     synchronized (this.undoRedoHistoryLock) {
/*  758 */       for (int i = this.redoList.size() - 1; i >= 0; i--) {
/*  759 */         IUndoableOperation operation = this.redoList.get(i);
/*  760 */         if (operation.hasContext(context)) {
/*  761 */           return operation;
/*      */         }
/*      */       } 
/*      */     } 
/*  765 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private IStatus getUndoApproval(IUndoableOperation operation, IAdaptable info) {
/*  774 */     for (IOperationApprover approver : this.approvers) {
/*  775 */       IStatus approval = approver.proceedUndoing(operation, this, info);
/*  776 */       if (!approval.isOK()) {
/*  777 */         if (DEBUG_OPERATION_HISTORY_APPROVAL) {
/*  778 */           Tracing.printTrace("OPERATIONHISTORY", 
/*  779 */               "Undo not approved by " + approver + 
/*  780 */               "for operation " + operation + 
/*  781 */               " with status " + approval);
/*      */         }
/*  783 */         return approval;
/*      */       } 
/*      */     } 
/*  786 */     return Status.OK_STATUS;
/*      */   }
/*      */ 
/*      */   
/*      */   public IUndoableOperation[] getUndoHistory(IUndoContext context) {
/*  791 */     Assert.isNotNull(context);
/*  792 */     return filter(this.undoList, context);
/*      */   }
/*      */ 
/*      */   
/*      */   public IUndoableOperation getUndoOperation(IUndoContext context) {
/*  797 */     Assert.isNotNull(context);
/*  798 */     synchronized (this.undoRedoHistoryLock) {
/*  799 */       for (int i = this.undoList.size() - 1; i >= 0; i--) {
/*  800 */         IUndoableOperation operation = this.undoList.get(i);
/*  801 */         if (operation.hasContext(context)) {
/*  802 */           return operation;
/*      */         }
/*      */       } 
/*      */     } 
/*  806 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private IStatus getExecuteApproval(IUndoableOperation operation, IAdaptable info) {
/*  817 */     for (IOperationApprover tmp : this.approvers) {
/*  818 */       if (tmp instanceof IOperationApprover2) {
/*  819 */         IOperationApprover2 approver = (IOperationApprover2)tmp;
/*  820 */         IStatus approval = approver.proceedExecuting(operation, this, info);
/*  821 */         if (!approval.isOK()) {
/*  822 */           if (DEBUG_OPERATION_HISTORY_APPROVAL) {
/*  823 */             Tracing.printTrace("OPERATIONHISTORY", 
/*  824 */                 "Execute not approved by " + approver + 
/*  825 */                 "for operation " + operation + 
/*  826 */                 " with status " + approval);
/*      */           }
/*  828 */           return approval;
/*      */         } 
/*      */       } 
/*      */     } 
/*  832 */     return Status.OK_STATUS;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void internalRemove(IUndoableOperation operation) {
/*  839 */     operation.dispose();
/*  840 */     notifyRemoved(operation);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void notifyListeners(final OperationHistoryEvent event) {
/*  847 */     if (event.getOperation() instanceof IAdvancedUndoableOperation) {
/*  848 */       final IAdvancedUndoableOperation advancedOp = (IAdvancedUndoableOperation)event.getOperation();
/*  849 */       SafeRunner.run(new ISafeRunnable()
/*      */           {
/*      */             public void handleException(Throwable exception) {
/*  852 */               if (DefaultOperationHistory.DEBUG_OPERATION_HISTORY_UNEXPECTED) {
/*  853 */                 Tracing.printTrace("OPERATIONHISTORY", 
/*  854 */                     "Exception during notification callback " + exception);
/*      */               }
/*      */             }
/*      */ 
/*      */             
/*      */             public void run() throws Exception {
/*  860 */               advancedOp.aboutToNotify(event);
/*      */             }
/*      */           });
/*      */     } 
/*  864 */     for (IOperationHistoryListener listener : this.listeners) {
/*  865 */       SafeRunner.run(new ISafeRunnable()
/*      */           {
/*      */             public void handleException(Throwable exception) {
/*  868 */               if (DefaultOperationHistory.DEBUG_OPERATION_HISTORY_UNEXPECTED) {
/*  869 */                 Tracing.printTrace("OPERATIONHISTORY", 
/*  870 */                     "Exception during notification callback " + exception);
/*      */               }
/*      */             }
/*      */ 
/*      */             
/*      */             public void run() throws Exception {
/*  876 */               listener.historyNotification(event);
/*      */             }
/*      */           });
/*      */     } 
/*      */   }
/*      */   
/*      */   private void notifyAboutToExecute(IUndoableOperation operation) {
/*  883 */     if (DEBUG_OPERATION_HISTORY_NOTIFICATION) {
/*  884 */       Tracing.printTrace("OPERATIONHISTORY", "ABOUT_TO_EXECUTE " + operation);
/*      */     }
/*      */     
/*  887 */     notifyListeners(new OperationHistoryEvent(1, this, operation));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void notifyAboutToRedo(IUndoableOperation operation) {
/*  894 */     if (DEBUG_OPERATION_HISTORY_NOTIFICATION) {
/*  895 */       Tracing.printTrace("OPERATIONHISTORY", "ABOUT_TO_REDO " + operation);
/*      */     }
/*      */     
/*  898 */     notifyListeners(new OperationHistoryEvent(2, this, operation));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void notifyAboutToUndo(IUndoableOperation operation) {
/*  905 */     if (DEBUG_OPERATION_HISTORY_NOTIFICATION) {
/*  906 */       Tracing.printTrace("OPERATIONHISTORY", "ABOUT_TO_UNDO " + operation);
/*      */     }
/*      */     
/*  909 */     notifyListeners(new OperationHistoryEvent(3, this, operation));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void notifyAdd(IUndoableOperation operation) {
/*  916 */     if (DEBUG_OPERATION_HISTORY_NOTIFICATION) {
/*  917 */       Tracing.printTrace("OPERATIONHISTORY", "OPERATION_ADDED " + operation);
/*      */     }
/*      */     
/*  920 */     notifyListeners(new OperationHistoryEvent(5, this, operation));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void notifyDone(IUndoableOperation operation) {
/*  927 */     if (DEBUG_OPERATION_HISTORY_NOTIFICATION) {
/*  928 */       Tracing.printTrace("OPERATIONHISTORY", "DONE " + operation);
/*      */     }
/*      */     
/*  931 */     notifyListeners(new OperationHistoryEvent(4, this, operation));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void notifyNotOK(IUndoableOperation operation) {
/*  939 */     notifyNotOK(operation, null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void notifyNotOK(IUndoableOperation operation, IStatus status) {
/*  950 */     if (DEBUG_OPERATION_HISTORY_NOTIFICATION) {
/*  951 */       Tracing.printTrace("OPERATIONHISTORY", "OPERATION_NOT_OK " + operation);
/*      */     }
/*      */     
/*  954 */     notifyListeners(new OperationHistoryEvent(7, this, operation, status));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void notifyRedone(IUndoableOperation operation) {
/*  961 */     if (DEBUG_OPERATION_HISTORY_NOTIFICATION) {
/*  962 */       Tracing.printTrace("OPERATIONHISTORY", "REDONE " + operation);
/*      */     }
/*      */     
/*  965 */     notifyListeners(new OperationHistoryEvent(9, this, operation));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void notifyRemoved(IUndoableOperation operation) {
/*  972 */     if (DEBUG_OPERATION_HISTORY_NOTIFICATION) {
/*  973 */       Tracing.printTrace("OPERATIONHISTORY", "OPERATION_REMOVED " + operation);
/*      */     }
/*      */     
/*  976 */     notifyListeners(new OperationHistoryEvent(8, this, operation));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void notifyUndone(IUndoableOperation operation) {
/*  983 */     if (DEBUG_OPERATION_HISTORY_NOTIFICATION) {
/*  984 */       Tracing.printTrace("OPERATIONHISTORY", "UNDONE " + operation);
/*      */     }
/*      */     
/*  987 */     notifyListeners(new OperationHistoryEvent(10, this, operation));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void notifyChanged(IUndoableOperation operation) {
/*  994 */     if (DEBUG_OPERATION_HISTORY_NOTIFICATION) {
/*  995 */       Tracing.printTrace("OPERATIONHISTORY", "OPERATION_CHANGED " + operation);
/*      */     }
/*      */     
/*  998 */     notifyListeners(new OperationHistoryEvent(6, this, operation));
/*      */   }
/*      */ 
/*      */   
/*      */   public IStatus redo(IUndoContext context, IProgressMonitor monitor, IAdaptable info) throws ExecutionException {
/* 1003 */     Assert.isNotNull(context);
/* 1004 */     IUndoableOperation operation = getRedoOperation(context);
/*      */ 
/*      */     
/* 1007 */     if (operation == null) {
/* 1008 */       return IOperationHistory.NOTHING_TO_REDO_STATUS;
/*      */     }
/*      */ 
/*      */     
/* 1012 */     if (!operation.canRedo()) {
/* 1013 */       if (DEBUG_OPERATION_HISTORY_UNEXPECTED) {
/* 1014 */         Tracing.printTrace("OPERATIONHISTORY", "Redo operation not valid - " + operation);
/*      */       }
/*      */       
/* 1017 */       return IOperationHistory.OPERATION_INVALID_STATUS;
/*      */     } 
/*      */     
/* 1020 */     return doRedo(monitor, info, operation);
/*      */   }
/*      */ 
/*      */   
/*      */   public IStatus redoOperation(IUndoableOperation operation, IProgressMonitor monitor, IAdaptable info) throws ExecutionException {
/*      */     IStatus status;
/* 1026 */     Assert.isNotNull(operation);
/*      */     
/* 1028 */     if (operation.canRedo()) {
/* 1029 */       status = doRedo(monitor, info, operation);
/*      */     } else {
/* 1031 */       if (DEBUG_OPERATION_HISTORY_UNEXPECTED) {
/* 1032 */         Tracing.printTrace("OPERATIONHISTORY", "Redo operation not valid - " + operation);
/*      */       }
/* 1034 */       status = IOperationHistory.OPERATION_INVALID_STATUS;
/*      */     } 
/* 1036 */     return status;
/*      */   }
/*      */ 
/*      */   
/*      */   public void removeOperationApprover(IOperationApprover approver) {
/* 1041 */     this.approvers.remove(approver);
/*      */   }
/*      */ 
/*      */   
/*      */   public void removeOperationHistoryListener(IOperationHistoryListener listener) {
/* 1046 */     this.listeners.remove(listener);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void replaceOperation(IUndoableOperation operation, IUndoableOperation[] replacements) {
/* 1052 */     boolean inUndo = false;
/* 1053 */     synchronized (this.undoRedoHistoryLock) {
/* 1054 */       int index = this.undoList.indexOf(operation);
/* 1055 */       if (index > -1) {
/* 1056 */         inUndo = true;
/* 1057 */         this.undoList.remove(operation);
/*      */         
/* 1059 */         ArrayList<IUndoContext> allContexts = new ArrayList<>(replacements.length); byte b1; int j; IUndoableOperation[] arrayOfIUndoableOperation1;
/* 1060 */         for (j = (arrayOfIUndoableOperation1 = replacements).length, b1 = 0; b1 < j; ) { IUndoableOperation replacement = arrayOfIUndoableOperation1[b1];
/* 1061 */           IUndoContext[] opContexts = replacement.getContexts();
/* 1062 */           allContexts.addAll(Arrays.asList(opContexts));
/* 1063 */           this.undoList.add(index, replacement);
/*      */ 
/*      */           
/*      */           b1++; }
/*      */ 
/*      */         
/* 1069 */         for (IUndoContext context : allContexts) {
/* 1070 */           forceUndoLimit(context, getLimit(context));
/*      */         }
/*      */       } 
/*      */     } 
/* 1074 */     if (inUndo) {
/*      */       
/* 1076 */       internalRemove(operation); byte b1; int j; IUndoableOperation[] arrayOfIUndoableOperation1;
/* 1077 */       for (j = (arrayOfIUndoableOperation1 = replacements).length, b1 = 0; b1 < j; ) { IUndoableOperation replacement = arrayOfIUndoableOperation1[b1];
/* 1078 */         notifyAdd(replacement);
/*      */         
/*      */         b1++; }
/*      */ 
/*      */       
/*      */       return;
/*      */     } 
/* 1085 */     synchronized (this.undoRedoHistoryLock) {
/* 1086 */       int index = this.redoList.indexOf(operation);
/* 1087 */       if (index == -1) {
/*      */         return;
/*      */       }
/* 1090 */       ArrayList<IUndoContext> allContexts = new ArrayList<>(replacements.length);
/* 1091 */       this.redoList.remove(operation); byte b1; int j;
/*      */       IUndoableOperation[] arrayOfIUndoableOperation1;
/* 1093 */       for (j = (arrayOfIUndoableOperation1 = replacements).length, b1 = 0; b1 < j; ) { IUndoableOperation replacement = arrayOfIUndoableOperation1[b1];
/* 1094 */         IUndoContext[] opContexts = replacement.getContexts();
/* 1095 */         allContexts.addAll(Arrays.asList(opContexts));
/* 1096 */         this.redoList.add(index, replacement);
/*      */         
/*      */         b1++; }
/*      */ 
/*      */       
/* 1101 */       for (IUndoContext context : allContexts) {
/* 1102 */         forceRedoLimit(context, getLimit(context));
/*      */       }
/*      */     } 
/*      */     
/* 1106 */     internalRemove(operation); byte b; int i; IUndoableOperation[] arrayOfIUndoableOperation;
/* 1107 */     for (i = (arrayOfIUndoableOperation = replacements).length, b = 0; b < i; ) { IUndoableOperation replacement = arrayOfIUndoableOperation[b];
/* 1108 */       notifyAdd(replacement);
/*      */       b++; }
/*      */   
/*      */   }
/*      */   
/*      */   public void setLimit(IUndoContext context, int limit) {
/* 1114 */     Assert.isTrue((limit >= 0));
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1122 */     Assert.isNotNull(context);
/* 1123 */     this.limits.put(context, Integer.valueOf(limit));
/* 1124 */     synchronized (this.undoRedoHistoryLock) {
/* 1125 */       forceUndoLimit(context, limit);
/* 1126 */       forceRedoLimit(context, limit);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public IStatus undo(IUndoContext context, IProgressMonitor monitor, IAdaptable info) throws ExecutionException {
/* 1133 */     Assert.isNotNull(context);
/* 1134 */     IUndoableOperation operation = getUndoOperation(context);
/*      */ 
/*      */     
/* 1137 */     if (operation == null) {
/* 1138 */       return IOperationHistory.NOTHING_TO_UNDO_STATUS;
/*      */     }
/*      */ 
/*      */     
/* 1142 */     if (!operation.canUndo()) {
/* 1143 */       if (DEBUG_OPERATION_HISTORY_UNEXPECTED) {
/* 1144 */         Tracing.printTrace("OPERATIONHISTORY", "Undo operation not valid - " + operation);
/*      */       }
/* 1146 */       return IOperationHistory.OPERATION_INVALID_STATUS;
/*      */     } 
/*      */     
/* 1149 */     return doUndo(monitor, info, operation);
/*      */   }
/*      */ 
/*      */   
/*      */   public IStatus undoOperation(IUndoableOperation operation, IProgressMonitor monitor, IAdaptable info) throws ExecutionException {
/*      */     IStatus status;
/* 1155 */     Assert.isNotNull(operation);
/*      */     
/* 1157 */     if (operation.canUndo()) {
/* 1158 */       status = doUndo(monitor, info, operation);
/*      */     } else {
/* 1160 */       if (DEBUG_OPERATION_HISTORY_UNEXPECTED) {
/* 1161 */         Tracing.printTrace("OPERATIONHISTORY", "Undo operation not valid - " + operation);
/*      */       }
/* 1163 */       status = IOperationHistory.OPERATION_INVALID_STATUS;
/*      */     } 
/* 1165 */     return status;
/*      */   }
/*      */ 
/*      */   
/*      */   public void openOperation(ICompositeOperation operation, int mode) {
/* 1170 */     synchronized (this.openCompositeLock) {
/* 1171 */       if (this.openComposite != null && this.openComposite != operation) {
/*      */         
/* 1173 */         if (DEBUG_OPERATION_HISTORY_UNEXPECTED) {
/* 1174 */           Tracing.printTrace("OPERATIONHISTORY", 
/* 1175 */               "Open operation called while another operation is open.  old: " + 
/* 1176 */               this.openComposite + "; new:  " + operation);
/*      */         }
/*      */         
/* 1179 */         throw new IllegalStateException(
/* 1180 */             "Cannot open an operation while one is already open");
/*      */       } 
/* 1182 */       this.openComposite = operation;
/*      */     } 
/* 1184 */     if (DEBUG_OPERATION_HISTORY_OPENOPERATION) {
/* 1185 */       Tracing.printTrace("OPERATIONHISTORY", "Opening operation " + this.openComposite);
/*      */     }
/*      */     
/* 1188 */     if (mode == 1) {
/* 1189 */       notifyAboutToExecute(this.openComposite);
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   public void closeOperation(boolean operationOK, boolean addToHistory, int mode) {
/* 1195 */     ICompositeOperation endedComposite = null;
/*      */     
/* 1197 */     synchronized (this.openCompositeLock) {
/* 1198 */       if (DEBUG_OPERATION_HISTORY_UNEXPECTED && 
/* 1199 */         this.openComposite == null) {
/* 1200 */         Tracing.printTrace("OPERATIONHISTORY", "Attempted to close operation when none was open");
/*      */         
/*      */         return;
/*      */       } 
/*      */       
/* 1205 */       if (this.openComposite != null) {
/* 1206 */         if (DEBUG_OPERATION_HISTORY_OPENOPERATION) {
/* 1207 */           Tracing.printTrace("OPERATIONHISTORY", "Closing operation " + this.openComposite);
/*      */         }
/* 1209 */         endedComposite = this.openComposite;
/* 1210 */         this.openComposite = null;
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 1216 */     if (endedComposite != null) {
/* 1217 */       if (operationOK) {
/* 1218 */         if (mode == 1) {
/* 1219 */           notifyDone(endedComposite);
/*      */         }
/* 1221 */         if (addToHistory) {
/* 1222 */           add(endedComposite);
/*      */         }
/* 1224 */       } else if (mode == 1) {
/* 1225 */         notifyNotOK(endedComposite);
/*      */       } 
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   public void operationChanged(IUndoableOperation operation) {
/* 1232 */     if (this.undoList.contains(operation) || this.redoList.contains(operation))
/* 1233 */       notifyChanged(operation); 
/*      */   }
/*      */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.commands-3.11.0.jar!\org\eclipse\core\commands\operations\DefaultOperationHistory.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */