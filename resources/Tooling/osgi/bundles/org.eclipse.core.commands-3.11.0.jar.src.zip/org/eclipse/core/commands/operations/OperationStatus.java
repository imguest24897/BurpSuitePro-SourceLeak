/*    */ package org.eclipse.core.commands.operations;
/*    */ 
/*    */ import org.eclipse.core.runtime.Status;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class OperationStatus
/*    */   extends Status
/*    */ {
/*    */   public static final int NOTHING_TO_REDO = 1;
/*    */   public static final int NOTHING_TO_UNDO = 2;
/*    */   public static final int OPERATION_INVALID = 3;
/* 54 */   static String DEFAULT_PLUGIN_ID = "org.eclipse.core.commands";
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public OperationStatus(int severity, String pluginId, int code, String message, Throwable exception) {
/* 72 */     super(severity, pluginId, code, message, exception);
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.commands-3.11.0.jar!\org\eclipse\core\commands\operations\OperationStatus.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */