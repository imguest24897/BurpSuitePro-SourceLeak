/*    */ package org.eclipse.core.commands.common;
/*    */ 
/*    */ import java.util.HashMap;
/*    */ import java.util.HashSet;
/*    */ import java.util.Iterator;
/*    */ import java.util.Map;
/*    */ import java.util.Set;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class HandleObjectManager
/*    */   extends EventManager
/*    */ {
/* 42 */   protected final Set definedHandleObjects = new HashSet();
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 50 */   protected final Map handleObjectsById = new HashMap<>();
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected final void checkId(String id) {
/* 60 */     if (id == null) {
/* 61 */       throw new IllegalArgumentException("A handle object may not have a null identifier");
/*    */     }
/*    */     
/* 64 */     if (id.length() < 1) {
/* 65 */       throw new IllegalArgumentException("The handle object must not have a zero-length identifier");
/*    */     }
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected final Set getDefinedHandleObjectIds() {
/* 77 */     HashSet<String> definedHandleObjectIds = new HashSet<>(this.definedHandleObjects.size());
/* 78 */     Iterator<NamedHandleObject> handleObjectItr = this.definedHandleObjects.iterator();
/* 79 */     while (handleObjectItr.hasNext()) {
/* 80 */       HandleObject handleObject = handleObjectItr.next();
/* 81 */       String id = handleObject.getId();
/* 82 */       definedHandleObjectIds.add(id);
/*    */     } 
/* 84 */     return definedHandleObjectIds;
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.commands-3.11.0.jar!\org\eclipse\core\commands\common\HandleObjectManager.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */