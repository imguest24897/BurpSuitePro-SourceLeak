/*     */ package org.eclipse.core.commands;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Objects;
/*     */ import org.eclipse.core.commands.common.NotDefinedException;
/*     */ import org.eclipse.core.internal.commands.util.Util;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ParameterizedCommand
/*     */   implements Comparable
/*     */ {
/*     */   private static final int HASH_CODE_NOT_COMPUTED = -1;
/*     */   private static final int HASH_FACTOR = 89;
/*  59 */   private static final int HASH_INITIAL = ParameterizedCommand.class.getName().hashCode();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public static final int INDEX_PARAMETER_ID = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public static final int INDEX_PARAMETER_NAME = 1;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public static final int INDEX_PARAMETER_VALUE_NAME = 2;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public static final int INDEX_PARAMETER_VALUE_VALUE = 3;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final Command command;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static String escape(String rawText) {
/* 115 */     StringBuilder buffer = null;
/*     */     
/* 117 */     for (int i = 0; i < rawText.length(); i++) {
/*     */       
/* 119 */       char c = rawText.charAt(i);
/* 120 */       switch (c) {
/*     */         case '%':
/*     */         case '(':
/*     */         case ')':
/*     */         case ',':
/*     */         case '=':
/* 126 */           if (buffer == null) {
/* 127 */             buffer = new StringBuilder(rawText.substring(0, i));
/*     */           }
/* 129 */           buffer.append('%');
/* 130 */           buffer.append(c);
/*     */           break;
/*     */         default:
/* 133 */           if (buffer != null) {
/* 134 */             buffer.append(c);
/*     */           }
/*     */           break;
/*     */       } 
/*     */ 
/*     */     
/*     */     } 
/* 141 */     if (buffer == null) {
/* 142 */       return rawText;
/*     */     }
/* 144 */     return buffer.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static Collection<?> expandParameters(int startIndex, IParameter[] parameters) {
/* 162 */     int nextIndex = startIndex + 1;
/* 163 */     boolean noMoreParameters = (nextIndex >= parameters.length);
/*     */     
/* 165 */     IParameter parameter = parameters[startIndex];
/* 166 */     List<Object> parameterizations = new ArrayList();
/* 167 */     if (parameter.isOptional()) {
/* 168 */       parameterizations.add(null);
/*     */     }
/*     */     
/* 171 */     IParameterValues values = null;
/*     */     try {
/* 173 */       values = parameter.getValues();
/* 174 */     } catch (ParameterValuesException parameterValuesException) {
/* 175 */       if (noMoreParameters) {
/* 176 */         return parameterizations;
/*     */       }
/*     */ 
/*     */       
/* 180 */       return expandParameters(nextIndex, parameters);
/*     */     } 
/* 182 */     Map<?, ?> parameterValues = values.getParameterValues();
/* 183 */     Iterator<?> parameterValueItr = parameterValues.entrySet().iterator();
/* 184 */     while (parameterValueItr.hasNext()) {
/* 185 */       Map.Entry<?, ?> entry = (Map.Entry<?, ?>)parameterValueItr.next();
/* 186 */       Parameterization parameterization = new Parameterization(parameter, (String)entry.getValue());
/* 187 */       parameterizations.add(parameterization);
/*     */     } 
/*     */ 
/*     */     
/* 191 */     int parameterizationCount = parameterizations.size();
/* 192 */     if (noMoreParameters) {
/*     */       
/* 194 */       for (int i = 0; i < parameterizationCount; i++) {
/* 195 */         Parameterization parameterization = (Parameterization)parameterizations.get(i);
/* 196 */         List<Parameterization> combination = new ArrayList<>(1);
/* 197 */         combination.add(parameterization);
/* 198 */         parameterizations.set(i, combination);
/*     */       } 
/* 200 */       return parameterizations;
/*     */     } 
/*     */ 
/*     */     
/* 204 */     Collection<?> suffixes = expandParameters(nextIndex, parameters); do {  }
/* 205 */     while (suffixes.remove(null));
/*     */ 
/*     */     
/* 208 */     if (suffixes.isEmpty()) {
/*     */       
/* 210 */       for (int i = 0; i < parameterizationCount; i++) {
/* 211 */         Parameterization parameterization = (Parameterization)parameterizations.get(i);
/* 212 */         List<Parameterization> combination = new ArrayList<>(1);
/* 213 */         combination.add(parameterization);
/* 214 */         parameterizations.set(i, combination);
/*     */       } 
/* 216 */       return parameterizations;
/*     */     } 
/* 218 */     Collection<List<?>> returnValue = new ArrayList<>();
/* 219 */     Iterator<?> suffixItr = suffixes.iterator();
/* 220 */     while (suffixItr.hasNext()) {
/* 221 */       List<?> combination = (List)suffixItr.next();
/* 222 */       int combinationSize = combination.size();
/* 223 */       for (int i = 0; i < parameterizationCount; i++) {
/* 224 */         Parameterization parameterization = (Parameterization)parameterizations.get(i);
/* 225 */         List<Object> newCombination = new ArrayList(combinationSize + 1);
/* 226 */         newCombination.add(parameterization);
/* 227 */         newCombination.addAll(combination);
/* 228 */         returnValue.add(newCombination);
/*     */       } 
/*     */     } 
/*     */     
/* 232 */     return returnValue;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Collection generateCombinations(Command command) throws NotDefinedException {
/* 258 */     IParameter[] parameters = command.getParameters();
/* 259 */     if (parameters == null) {
/* 260 */       return Collections.singleton(new ParameterizedCommand(command, null));
/*     */     }
/*     */     
/* 263 */     Collection<?> expansion = expandParameters(0, parameters);
/* 264 */     Collection<ParameterizedCommand> combinations = new ArrayList<>(expansion.size());
/* 265 */     Iterator<?> expansionItr = expansion.iterator();
/* 266 */     while (expansionItr.hasNext()) {
/* 267 */       List<?> combination = (List)expansionItr.next();
/* 268 */       if (combination == null) {
/* 269 */         combinations.add(new ParameterizedCommand(command, null)); continue;
/*     */       }  do {  }
/* 271 */       while (combination.remove((Object)null));
/*     */ 
/*     */       
/* 274 */       if (combination.isEmpty()) {
/* 275 */         combinations.add(new ParameterizedCommand(command, null)); continue;
/*     */       } 
/* 277 */       Parameterization[] parameterizations = combination
/* 278 */         .<Parameterization>toArray(new Parameterization[combination.size()]);
/* 279 */       combinations.add(new ParameterizedCommand(command, parameterizations));
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 284 */     return combinations;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ParameterizedCommand generateCommand(Command command, Map parameters) {
/* 302 */     if (parameters == null || parameters.isEmpty()) {
/* 303 */       return new ParameterizedCommand(command, null);
/*     */     }
/*     */     
/*     */     try {
/* 307 */       ArrayList<Parameterization> parms = new ArrayList<>();
/* 308 */       for (Map.Entry<?, ?> entry : (Iterable<Map.Entry<?, ?>>)parameters.entrySet()) {
/* 309 */         String key = (String)entry.getKey();
/*     */         
/* 311 */         IParameter parameter = command.getParameter(key);
/*     */         
/* 313 */         if (parameter == null) {
/* 314 */           return null;
/*     */         }
/* 316 */         ParameterType parameterType = command.getParameterType(key);
/* 317 */         if (parameterType == null) {
/* 318 */           parms.add(new Parameterization(parameter, (String)entry.getValue())); continue;
/*     */         } 
/* 320 */         AbstractParameterValueConverter valueConverter = parameterType
/* 321 */           .getValueConverter();
/* 322 */         if (valueConverter != null) {
/* 323 */           String val = valueConverter.convertToString(entry.getValue());
/* 324 */           parms.add(new Parameterization(parameter, val)); continue;
/*     */         } 
/* 326 */         parms.add(new Parameterization(parameter, (String)entry.getValue()));
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 333 */       return new ParameterizedCommand(command, parms.<Parameterization>toArray(new Parameterization[parms.size()]));
/* 334 */     } catch (NotDefinedException|ParameterValueConversionException notDefinedException) {
/*     */       
/* 336 */       return null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 349 */   private transient int hashCode = -1;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final Parameterization[] parameterizations;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String name;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ParameterizedCommand(Command command, Parameterization[] parameterizations) {
/* 371 */     if (command == null) {
/* 372 */       throw new NullPointerException(
/* 373 */           "A parameterized command cannot have a null command");
/*     */     }
/*     */     
/* 376 */     this.command = command;
/* 377 */     IParameter[] parms = null;
/*     */     try {
/* 379 */       parms = command.getParameters();
/* 380 */     } catch (NotDefinedException notDefinedException) {}
/*     */ 
/*     */     
/* 383 */     if (parameterizations != null && parameterizations.length > 0 && parms != null) {
/* 384 */       int parmIndex = 0;
/* 385 */       Parameterization[] params = new Parameterization[parameterizations.length]; byte b; int i; IParameter[] arrayOfIParameter;
/* 386 */       for (i = (arrayOfIParameter = parms).length, b = 0; b < i; ) { IParameter parm = arrayOfIParameter[b]; byte b1; int j; Parameterization[] arrayOfParameterization;
/* 387 */         for (j = (arrayOfParameterization = parameterizations).length, b1 = 0; b1 < j; ) { Parameterization pm = arrayOfParameterization[b1];
/* 388 */           if (parm.equals(pm.getParameter()))
/* 389 */             params[parmIndex++] = pm;  b1++; }
/*     */         
/*     */         b++; }
/*     */       
/* 393 */       this.parameterizations = params;
/*     */     } else {
/* 395 */       this.parameterizations = null;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public int compareTo(Object object) {
/* 401 */     ParameterizedCommand command = (ParameterizedCommand)object;
/* 402 */     boolean thisDefined = this.command.isDefined();
/* 403 */     boolean otherDefined = command.command.isDefined();
/* 404 */     if (!thisDefined || !otherDefined) {
/* 405 */       return Util.compare(thisDefined, otherDefined);
/*     */     }
/*     */     
/*     */     try {
/* 409 */       int compareTo = getName().compareTo(command.getName());
/* 410 */       if (compareTo == 0) {
/* 411 */         return getId().compareTo(command.getId());
/*     */       }
/* 413 */       return compareTo;
/* 414 */     } catch (NotDefinedException notDefinedException) {
/* 415 */       throw new Error(
/* 416 */           "Concurrent modification of a command's defined state");
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object object) {
/* 422 */     if (this == object) {
/* 423 */       return true;
/*     */     }
/*     */     
/* 426 */     if (!(object instanceof ParameterizedCommand)) {
/* 427 */       return false;
/*     */     }
/*     */     
/* 430 */     ParameterizedCommand command = (ParameterizedCommand)object;
/* 431 */     return (Objects.equals(this.command, command.command) && 
/* 432 */       Arrays.equals((Object[])this.parameterizations, (Object[])command.parameterizations));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public Object execute(Object trigger, Object applicationContext) throws ExecutionException, NotHandledException {
/* 457 */     return this.command.execute(new ExecutionEvent(this.command, getParameterMap(), trigger, applicationContext));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object executeWithChecks(Object trigger, Object applicationContext) throws ExecutionException, NotDefinedException, NotEnabledException, NotHandledException {
/* 485 */     return this.command.executeWithChecks(new ExecutionEvent(this.command, getParameterMap(), trigger, applicationContext));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Command getCommand() {
/* 495 */     return this.command;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getId() {
/* 505 */     return this.command.getId();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getName() throws NotDefinedException {
/* 518 */     return getName(this.command.getName());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getName(String baseName) throws NotDefinedException {
/* 535 */     if (this.name == null) {
/* 536 */       StringBuilder nameBuffer = new StringBuilder();
/* 537 */       nameBuffer.append(baseName);
/* 538 */       if (this.parameterizations != null) {
/* 539 */         StringBuilder parametersBuffer = new StringBuilder();
/* 540 */         int parameterizationCount = this.parameterizations.length;
/* 541 */         if (parameterizationCount == 1) {
/* 542 */           appendParameter(parametersBuffer, this.parameterizations[0], false);
/*     */         } else {
/* 544 */           for (int i = 0; i < parameterizationCount; i++) {
/*     */             
/* 546 */             appendParameter(parametersBuffer, this.parameterizations[i], true);
/*     */ 
/*     */             
/* 549 */             if (i + 1 < parameterizationCount) {
/* 550 */               parametersBuffer.append(", ");
/*     */             }
/*     */           } 
/*     */         } 
/* 554 */         if (parametersBuffer.length() > 0) {
/* 555 */           nameBuffer.append(" (");
/* 556 */           nameBuffer.append(parametersBuffer);
/* 557 */           nameBuffer.append(')');
/*     */         } 
/*     */       } 
/* 560 */       this.name = nameBuffer.toString();
/*     */     } 
/* 562 */     return this.name;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void appendParameter(StringBuilder nameBuffer, Parameterization parameterization, boolean shouldAppendName) {
/* 568 */     if (shouldAppendName) {
/* 569 */       nameBuffer.append(parameterization.getParameter().getName());
/* 570 */       nameBuffer.append(": ");
/*     */     } 
/*     */     try {
/* 573 */       nameBuffer.append(parameterization.getValueName());
/* 574 */     } catch (ParameterValuesException parameterValuesException) {}
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Map getParameterMap() {
/* 591 */     if (this.parameterizations == null || this.parameterizations.length == 0) {
/* 592 */       return Collections.EMPTY_MAP;
/*     */     }
/*     */     
/* 595 */     Map<String, String> parameterMap = new HashMap<>(); byte b; int i; Parameterization[] arrayOfParameterization;
/* 596 */     for (i = (arrayOfParameterization = this.parameterizations).length, b = 0; b < i; ) { Parameterization parameterization = arrayOfParameterization[b];
/* 597 */       parameterMap.put(parameterization.getParameter().getId(), parameterization.getValue()); b++; }
/*     */     
/* 599 */     return parameterMap;
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 604 */     if (this.hashCode == -1) {
/* 605 */       this.hashCode = HASH_INITIAL * 89 + Objects.hashCode(this.command);
/* 606 */       this.hashCode *= 89;
/* 607 */       if (this.parameterizations != null) {
/* 608 */         byte b; int i; Parameterization[] arrayOfParameterization; for (i = (arrayOfParameterization = this.parameterizations).length, b = 0; b < i; ) { Parameterization parameterization = arrayOfParameterization[b];
/* 609 */           this.hashCode += Objects.hashCode(parameterization); b++; }
/*     */       
/*     */       } 
/* 612 */       if (this.hashCode == -1) {
/* 613 */         this.hashCode++;
/*     */       }
/*     */     } 
/* 616 */     return this.hashCode;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String serialize() {
/* 677 */     String escapedId = escape(getId());
/*     */     
/* 679 */     if (this.parameterizations == null || this.parameterizations.length == 0) {
/* 680 */       return escapedId;
/*     */     }
/*     */     
/* 683 */     StringBuilder buffer = new StringBuilder(escapedId);
/* 684 */     buffer.append('(');
/*     */     
/* 686 */     for (int i = 0; i < this.parameterizations.length; i++) {
/*     */       
/* 688 */       if (i > 0)
/*     */       {
/* 690 */         buffer.append(',');
/*     */       }
/*     */       
/* 693 */       Parameterization parameterization = this.parameterizations[i];
/* 694 */       String parameterId = parameterization.getParameter().getId();
/* 695 */       String escapedParameterId = escape(parameterId);
/*     */       
/* 697 */       buffer.append(escapedParameterId);
/*     */       
/* 699 */       String parameterValue = parameterization.getValue();
/* 700 */       if (parameterValue != null) {
/* 701 */         String escapedParameterValue = escape(parameterValue);
/* 702 */         buffer.append('=');
/* 703 */         buffer.append(escapedParameterValue);
/*     */       } 
/*     */     } 
/*     */     
/* 707 */     buffer.append(')');
/*     */     
/* 709 */     return buffer.toString();
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 714 */     StringBuilder buffer = new StringBuilder("ParameterizedCommand(");
/* 715 */     buffer.append(this.command);
/* 716 */     buffer.append(',');
/* 717 */     buffer.append(Arrays.toString((Object[])this.parameterizations));
/* 718 */     buffer.append(')');
/* 719 */     return buffer.toString();
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.commands-3.11.0.jar!\org\eclipse\core\commands\ParameterizedCommand.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */