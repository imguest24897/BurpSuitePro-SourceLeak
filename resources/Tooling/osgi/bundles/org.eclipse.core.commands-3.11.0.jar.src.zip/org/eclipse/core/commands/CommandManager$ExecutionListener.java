/*     */ package org.eclipse.core.commands;
/*     */ 
/*     */ import org.eclipse.core.commands.common.NotDefinedException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class ExecutionListener
/*     */   implements IExecutionListenerWithChecks
/*     */ {
/*     */   public void notDefined(String commandId, NotDefinedException exception) {
/*  56 */     if (CommandManager.this.executionListeners != null) {
/*  57 */       for (IExecutionListener object : CommandManager.this.executionListeners) {
/*  58 */         if (object instanceof IExecutionListenerWithChecks) {
/*  59 */           IExecutionListenerWithChecks listener = (IExecutionListenerWithChecks)object;
/*  60 */           listener.notDefined(commandId, exception);
/*     */         } 
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void notEnabled(String commandId, NotEnabledException exception) {
/*  68 */     if (CommandManager.this.executionListeners != null) {
/*  69 */       for (IExecutionListener object : CommandManager.this.executionListeners) {
/*  70 */         if (object instanceof IExecutionListenerWithChecks) {
/*  71 */           IExecutionListenerWithChecks listener = (IExecutionListenerWithChecks)object;
/*  72 */           listener.notEnabled(commandId, exception);
/*     */         } 
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void notHandled(String commandId, NotHandledException exception) {
/*  81 */     if (CommandManager.this.executionListeners != null) {
/*  82 */       for (IExecutionListener listener : CommandManager.this.executionListeners) {
/*  83 */         listener.notHandled(commandId, exception);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void postExecuteFailure(String commandId, ExecutionException exception) {
/*  91 */     if (CommandManager.this.executionListeners != null) {
/*  92 */       for (IExecutionListener listener : CommandManager.this.executionListeners) {
/*  93 */         listener.postExecuteFailure(commandId, exception);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void postExecuteSuccess(String commandId, Object returnValue) {
/* 101 */     if (CommandManager.this.executionListeners != null) {
/* 102 */       for (IExecutionListener listener : CommandManager.this.executionListeners) {
/* 103 */         listener.postExecuteSuccess(commandId, returnValue);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void preExecute(String commandId, ExecutionEvent event) {
/* 111 */     if (CommandManager.this.executionListeners != null)
/* 112 */       for (IExecutionListener listener : CommandManager.this.executionListeners)
/* 113 */         listener.preExecute(commandId, event);  
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.commands-3.11.0.jar!\org\eclipse\core\commands\CommandManager$ExecutionListener.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */