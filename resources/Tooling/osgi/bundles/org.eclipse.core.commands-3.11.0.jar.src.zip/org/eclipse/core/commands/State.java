/*     */ package org.eclipse.core.commands;
/*     */ 
/*     */ import java.util.Objects;
/*     */ import org.eclipse.core.commands.common.EventManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class State
/*     */   extends EventManager
/*     */ {
/*     */   private String id;
/*     */   private Object value;
/*     */   
/*     */   public void addListener(IStateListener listener) {
/*  59 */     addListenerObject(listener);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void dispose() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final void fireStateChanged(Object oldValue) {
/*     */     byte b;
/*     */     int i;
/*     */     Object[] arrayOfObject;
/*  77 */     for (i = (arrayOfObject = getListeners()).length, b = 0; b < i; ) { Object listener = arrayOfObject[b];
/*  78 */       IStateListener stateListener = (IStateListener)listener;
/*  79 */       stateListener.handleStateChange(this, oldValue);
/*     */       b++; }
/*     */   
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final String getId() {
/*  89 */     return this.id;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object getValue() {
/* 101 */     return this.value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void removeListener(IStateListener listener) {
/* 112 */     removeListenerObject(listener);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setId(String id) {
/* 123 */     this.id = id;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setValue(Object value) {
/* 133 */     if (!Objects.equals(this.value, value)) {
/* 134 */       Object oldValue = this.value;
/* 135 */       this.value = value;
/* 136 */       fireStateChanged(oldValue);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.commands-3.11.0.jar!\org\eclipse\core\commands\State.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */