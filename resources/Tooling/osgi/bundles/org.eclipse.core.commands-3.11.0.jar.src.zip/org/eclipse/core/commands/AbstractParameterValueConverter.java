package org.eclipse.core.commands;

public abstract class AbstractParameterValueConverter {
  public abstract Object convertToObject(String paramString) throws ParameterValueConversionException;
  
  public abstract String convertToString(Object paramObject) throws ParameterValueConversionException;
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.commands-3.11.0.jar!\org\eclipse\core\commands\AbstractParameterValueConverter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */