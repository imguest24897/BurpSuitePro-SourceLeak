/*    */ package org.eclipse.core.internal.commands.operations;
/*    */ 
/*    */ import org.eclipse.core.commands.operations.IUndoContext;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class GlobalUndoContext
/*    */   implements IUndoContext
/*    */ {
/*    */   public String getLabel() {
/* 30 */     return "Global Undo Context";
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean matches(IUndoContext context) {
/* 35 */     return true;
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.commands-3.11.0.jar!\org\eclipse\core\internal\commands\operations\GlobalUndoContext.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */