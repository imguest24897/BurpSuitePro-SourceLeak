/*     */ package org.eclipse.core.commands.common;
/*     */ 
/*     */ import java.util.Objects;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class HandleObject
/*     */   extends EventManager
/*     */   implements IIdentifiable
/*     */ {
/*     */   private static final int HASH_CODE_NOT_COMPUTED = -1;
/*     */   private static final int HASH_FACTOR = 89;
/*  59 */   private static final int HASH_INITIAL = HandleObject.class.getName()
/*  60 */     .hashCode();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected transient boolean defined = false;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  72 */   private transient int hashCode = -1;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final String id;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  87 */   protected transient String string = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected HandleObject(String id) {
/*  96 */     if (id == null) {
/*  97 */       throw new NullPointerException(
/*  98 */           "Cannot create a handle with a null id");
/*     */     }
/*     */     
/* 101 */     this.id = id;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object object) {
/* 116 */     if (object == this) {
/* 117 */       return true;
/*     */     }
/*     */ 
/*     */     
/* 121 */     if (!(object instanceof HandleObject)) {
/* 122 */       return false;
/*     */     }
/*     */ 
/*     */     
/* 126 */     HandleObject handle = (HandleObject)object;
/* 127 */     return (Objects.equals(this.id, handle.id) && 
/* 128 */       getClass() == handle.getClass());
/*     */   }
/*     */ 
/*     */   
/*     */   public final String getId() {
/* 133 */     return this.id;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final int hashCode() {
/* 143 */     if (this.hashCode == -1) {
/* 144 */       this.hashCode = HASH_INITIAL * 89 + Objects.hashCode(this.id);
/* 145 */       if (this.hashCode == -1) {
/* 146 */         this.hashCode++;
/*     */       }
/*     */     } 
/* 149 */     return this.hashCode;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final boolean isDefined() {
/* 161 */     return this.defined;
/*     */   }
/*     */   
/*     */   public abstract String toString();
/*     */   
/*     */   public abstract void undefine();
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.commands-3.11.0.jar!\org\eclipse\core\commands\common\HandleObject.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */