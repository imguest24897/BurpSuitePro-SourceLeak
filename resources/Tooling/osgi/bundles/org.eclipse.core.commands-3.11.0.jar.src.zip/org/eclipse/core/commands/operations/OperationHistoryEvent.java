/*     */ package org.eclipse.core.commands.operations;
/*     */ 
/*     */ import org.eclipse.core.runtime.IStatus;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class OperationHistoryEvent
/*     */ {
/*     */   public static final int ABOUT_TO_EXECUTE = 1;
/*     */   public static final int ABOUT_TO_REDO = 2;
/*     */   public static final int ABOUT_TO_UNDO = 3;
/*     */   public static final int DONE = 4;
/*     */   public static final int OPERATION_ADDED = 5;
/*     */   public static final int OPERATION_CHANGED = 6;
/*     */   public static final int OPERATION_NOT_OK = 7;
/*     */   public static final int OPERATION_REMOVED = 8;
/*     */   public static final int REDONE = 9;
/*     */   public static final int UNDONE = 10;
/* 145 */   private int code = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private IOperationHistory history;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private IUndoableOperation operation;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private IStatus status;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public OperationHistoryEvent(int code, IOperationHistory history, IUndoableOperation operation) {
/* 166 */     this(code, history, operation, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public OperationHistoryEvent(int code, IOperationHistory history, IUndoableOperation operation, IStatus status) {
/* 186 */     if (history == null) {
/* 187 */       throw new NullPointerException();
/*     */     }
/* 189 */     if (operation == null) {
/* 190 */       throw new NullPointerException();
/*     */     }
/* 192 */     this.code = code;
/* 193 */     this.history = history;
/* 194 */     this.operation = operation;
/* 195 */     this.status = status;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getEventType() {
/* 204 */     return this.code;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IOperationHistory getHistory() {
/* 214 */     return this.history;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IUndoableOperation getOperation() {
/* 224 */     return this.operation;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IStatus getStatus() {
/* 236 */     return this.status;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.commands-3.11.0.jar!\org\eclipse\core\commands\operations\OperationHistoryEvent.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */