/*     */ package org.eclipse.core.commands;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Iterator;
/*     */ import java.util.Objects;
/*     */ import org.eclipse.core.commands.common.NamedHandleObject;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class Category
/*     */   extends NamedHandleObject
/*     */ {
/*     */   private Collection<ICategoryListener> categoryListeners;
/*     */   
/*     */   Category(String id) {
/*  52 */     super(id);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void addCategoryListener(ICategoryListener categoryListener) {
/*  64 */     if (categoryListener == null) {
/*  65 */       throw new NullPointerException();
/*     */     }
/*  67 */     if (this.categoryListeners == null) {
/*  68 */       this.categoryListeners = new ArrayList<>();
/*     */     }
/*  70 */     if (!this.categoryListeners.contains(categoryListener)) {
/*  71 */       this.categoryListeners.add(categoryListener);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void define(String name, String description) {
/*  90 */     if (name == null) {
/*  91 */       throw new NullPointerException("The name of a command cannot be null");
/*     */     }
/*     */     
/*  94 */     boolean definedChanged = !this.defined;
/*  95 */     this.defined = true;
/*     */     
/*  97 */     boolean nameChanged = !Objects.equals(this.name, name);
/*  98 */     this.name = name;
/*     */     
/* 100 */     boolean descriptionChanged = !Objects.equals(this.description, description);
/* 101 */     this.description = description;
/*     */     
/* 103 */     fireCategoryChanged(new CategoryEvent(this, definedChanged, descriptionChanged, nameChanged));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final void fireCategoryChanged(CategoryEvent categoryEvent) {
/* 114 */     if (categoryEvent == null) {
/* 115 */       throw new NullPointerException();
/*     */     }
/* 117 */     if (this.categoryListeners != null) {
/* 118 */       Iterator<ICategoryListener> listenerItr = this.categoryListeners.iterator();
/* 119 */       while (listenerItr.hasNext()) {
/* 120 */         ICategoryListener listener = listenerItr.next();
/* 121 */         listener.categoryChanged(categoryEvent);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void removeCategoryListener(ICategoryListener categoryListener) {
/* 135 */     if (categoryListener == null) {
/* 136 */       throw new NullPointerException();
/*     */     }
/*     */     
/* 139 */     if (this.categoryListeners != null) {
/* 140 */       this.categoryListeners.remove(categoryListener);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 146 */     if (this.string == null) {
/* 147 */       StringBuilder stringBuffer = new StringBuilder("Category(");
/* 148 */       stringBuffer.append(this.id);
/* 149 */       stringBuffer.append(',');
/* 150 */       stringBuffer.append(this.name);
/* 151 */       stringBuffer.append(',');
/* 152 */       stringBuffer.append(this.description);
/* 153 */       stringBuffer.append(',');
/* 154 */       stringBuffer.append(this.defined);
/* 155 */       stringBuffer.append(')');
/* 156 */       this.string = stringBuffer.toString();
/*     */     } 
/* 158 */     return this.string;
/*     */   }
/*     */ 
/*     */   
/*     */   public void undefine() {
/* 163 */     this.string = null;
/*     */     
/* 165 */     boolean definedChanged = this.defined;
/* 166 */     this.defined = false;
/*     */     
/* 168 */     boolean nameChanged = (this.name != null);
/* 169 */     this.name = null;
/*     */     
/* 171 */     boolean descriptionChanged = (this.description != null);
/* 172 */     this.description = null;
/*     */     
/* 174 */     fireCategoryChanged(new CategoryEvent(this, definedChanged, descriptionChanged, nameChanged));
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.commands-3.11.0.jar!\org\eclipse\core\commands\Category.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */