/*    */ package org.eclipse.core.commands;
/*    */ 
/*    */ import org.eclipse.core.commands.common.CommandException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ParameterValueConversionException
/*    */   extends CommandException
/*    */ {
/*    */   private static final long serialVersionUID = 4703077729505066104L;
/*    */   
/*    */   public ParameterValueConversionException(String message) {
/* 39 */     super(message);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public ParameterValueConversionException(String message, Throwable cause) {
/* 53 */     super(message, cause);
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.commands-3.11.0.jar!\org\eclipse\core\commands\ParameterValueConversionException.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */