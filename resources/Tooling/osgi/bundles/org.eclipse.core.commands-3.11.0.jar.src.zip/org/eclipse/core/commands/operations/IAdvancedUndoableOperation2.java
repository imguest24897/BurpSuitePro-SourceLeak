package org.eclipse.core.commands.operations;

import org.eclipse.core.commands.ExecutionException;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.core.runtime.IStatus;

public interface IAdvancedUndoableOperation2 {
  IStatus computeExecutionStatus(IProgressMonitor paramIProgressMonitor) throws ExecutionException;
  
  void setQuietCompute(boolean paramBoolean);
  
  boolean runInBackground();
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.commands-3.11.0.jar!\org\eclipse\core\commands\operations\IAdvancedUndoableOperation2.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */