/*    */ package org.eclipse.core.commands;
/*    */ 
/*    */ import org.eclipse.core.commands.common.AbstractBitSetEvent;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class HandlerEvent
/*    */   extends AbstractBitSetEvent
/*    */ {
/*    */   private static final int CHANGED_ENABLED = 1;
/*    */   private static final int CHANGED_HANDLED = 2;
/*    */   private final IHandler handler;
/*    */   
/*    */   public HandlerEvent(IHandler handler, boolean enabledChanged, boolean handledChanged) {
/* 60 */     if (handler == null) {
/* 61 */       throw new NullPointerException();
/*    */     }
/* 63 */     this.handler = handler;
/*    */     
/* 65 */     if (enabledChanged) {
/* 66 */       this.changedValues |= 0x1;
/*    */     }
/* 68 */     if (handledChanged) {
/* 69 */       this.changedValues |= 0x2;
/*    */     }
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public IHandler getHandler() {
/* 80 */     return this.handler;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean isEnabledChanged() {
/* 89 */     return ((this.changedValues & 0x1) != 0);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean isHandledChanged() {
/* 98 */     return ((this.changedValues & 0x2) != 0);
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.commands-3.11.0.jar!\org\eclipse\core\commands\HandlerEvent.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */