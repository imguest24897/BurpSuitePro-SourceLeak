/*     */ package org.eclipse.core.commands.contexts;
/*     */ 
/*     */ import java.util.Set;
/*     */ import org.eclipse.core.commands.common.AbstractBitSetEvent;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ContextManagerEvent
/*     */   extends AbstractBitSetEvent
/*     */ {
/*     */   private static final int CHANGED_CONTEXT_DEFINED = 2;
/*     */   private static final int CHANGED_CONTEXTS_ACTIVE = 1;
/*     */   private final String contextId;
/*     */   private final ContextManager contextManager;
/*     */   private final Set<String> previouslyActiveContextIds;
/*     */   
/*     */   public ContextManagerEvent(ContextManager contextManager, String contextId, boolean contextIdAdded, boolean activeContextsChanged, Set<String> previouslyActiveContextIds) {
/*  86 */     if (contextManager == null) {
/*  87 */       throw new NullPointerException();
/*     */     }
/*     */     
/*  90 */     this.contextManager = contextManager;
/*  91 */     this.contextId = contextId;
/*  92 */     this.previouslyActiveContextIds = previouslyActiveContextIds;
/*     */     
/*  94 */     if (contextIdAdded) {
/*  95 */       this.changedValues |= 0x2;
/*     */     }
/*  97 */     if (activeContextsChanged) {
/*  98 */       this.changedValues |= 0x1;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final String getContextId() {
/* 110 */     return this.contextId;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ContextManager getContextManager() {
/* 120 */     return this.contextManager;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final Set getPreviouslyActiveContextIds() {
/* 136 */     return this.previouslyActiveContextIds;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final boolean isActiveContextsChanged() {
/* 146 */     return ((this.changedValues & 0x1) != 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final boolean isContextChanged() {
/* 156 */     return (this.contextId != null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final boolean isContextDefined() {
/* 167 */     return ((this.changedValues & 0x2) != 0 && this.contextId != null);
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.commands-3.11.0.jar!\org\eclipse\core\commands\contexts\ContextManagerEvent.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */