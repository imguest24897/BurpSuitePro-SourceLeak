/*     */ package org.eclipse.core.commands;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class CommandManagerEvent
/*     */ {
/*     */   private static final int CHANGED_CATEGORY_DEFINED = 1;
/*     */   private static final int CHANGED_COMMAND_DEFINED = 2;
/*     */   private static final int CHANGED_PARAMETER_TYPE_DEFINED = 4;
/*     */   private final String categoryId;
/*     */   private final int changedValues;
/*     */   private final String commandId;
/*     */   private final String parameterTypeId;
/*     */   private final CommandManager commandManager;
/*     */   
/*     */   public CommandManagerEvent(CommandManager commandManager, String commandId, boolean commandIdAdded, boolean commandIdChanged, String categoryId, boolean categoryIdAdded, boolean categoryIdChanged) {
/* 117 */     if (commandManager == null) {
/* 118 */       throw new NullPointerException(
/* 119 */           "An event must refer to its command manager");
/*     */     }
/*     */     
/* 122 */     if (commandIdChanged && commandId == null) {
/* 123 */       throw new NullPointerException(
/* 124 */           "If the list of defined commands changed, then the added/removed command must be mentioned");
/*     */     }
/*     */     
/* 127 */     if (categoryIdChanged && categoryId == null) {
/* 128 */       throw new NullPointerException(
/* 129 */           "If the list of defined categories changed, then the added/removed category must be mentioned");
/*     */     }
/*     */     
/* 132 */     this.commandManager = commandManager;
/* 133 */     this.commandId = commandId;
/* 134 */     this.categoryId = categoryId;
/*     */ 
/*     */     
/* 137 */     this.parameterTypeId = null;
/*     */     
/* 139 */     int changedValues = 0;
/* 140 */     if (categoryIdChanged && categoryIdAdded) {
/* 141 */       changedValues |= 0x1;
/*     */     }
/* 143 */     if (commandIdChanged && commandIdAdded) {
/* 144 */       changedValues |= 0x2;
/*     */     }
/* 146 */     this.changedValues = changedValues;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CommandManagerEvent(CommandManager commandManager, String parameterTypeId, boolean parameterTypeIdAdded, boolean parameterTypeIdChanged) {
/* 173 */     if (commandManager == null) {
/* 174 */       throw new NullPointerException(
/* 175 */           "An event must refer to its command manager");
/*     */     }
/*     */     
/* 178 */     if (parameterTypeIdChanged && parameterTypeId == null) {
/* 179 */       throw new NullPointerException(
/* 180 */           "If the list of defined command parameter types changed, then the added/removed parameter type must be mentioned");
/*     */     }
/*     */     
/* 183 */     this.commandManager = commandManager;
/* 184 */     this.commandId = null;
/* 185 */     this.categoryId = null;
/*     */     
/* 187 */     this.parameterTypeId = parameterTypeId;
/*     */     
/* 189 */     int changedValues = 0;
/* 190 */     if (parameterTypeIdChanged && parameterTypeIdAdded) {
/* 191 */       changedValues |= 0x4;
/*     */     }
/*     */     
/* 194 */     this.changedValues = changedValues;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final String getCategoryId() {
/* 204 */     return this.categoryId;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final String getCommandId() {
/* 214 */     return this.commandId;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final CommandManager getCommandManager() {
/* 224 */     return this.commandManager;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final String getParameterTypeId() {
/* 236 */     return this.parameterTypeId;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final boolean isCategoryChanged() {
/* 246 */     return (this.categoryId != null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final boolean isCategoryDefined() {
/* 257 */     return ((this.changedValues & 0x1) != 0 && this.categoryId != null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final boolean isCommandChanged() {
/* 267 */     return (this.commandId != null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final boolean isCommandDefined() {
/* 278 */     return ((this.changedValues & 0x2) != 0 && this.commandId != null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final boolean isParameterTypeChanged() {
/* 291 */     return (this.parameterTypeId != null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final boolean isParameterTypeDefined() {
/* 305 */     return ((this.changedValues & 0x4) != 0 && this.parameterTypeId != null);
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.commands-3.11.0.jar!\org\eclipse\core\commands\CommandManagerEvent.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */