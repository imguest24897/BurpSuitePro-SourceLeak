/*     */ package org.eclipse.core.commands;
/*     */ 
/*     */ import java.util.Collections;
/*     */ import java.util.Map;
/*     */ import org.eclipse.core.commands.common.NotDefinedException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ExecutionEvent
/*     */ {
/*     */   private final Object applicationContext;
/*     */   private final Command command;
/*     */   private final Map<String, String> parameters;
/*     */   private final Object trigger;
/*     */   
/*     */   public ExecutionEvent() {
/*  73 */     this(null, Collections.EMPTY_MAP, null, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public ExecutionEvent(Map parameters, Object trigger, Object applicationContext) {
/*  95 */     this(null, parameters, trigger, applicationContext);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ExecutionEvent(Command command, Map<String, String> parameters, Object trigger, Object applicationContext) {
/* 118 */     if (parameters == null) {
/* 119 */       throw new NullPointerException("An execution event must have a non-null map of parameters");
/*     */     }
/*     */     
/* 122 */     this.command = command;
/* 123 */     this.parameters = parameters;
/* 124 */     this.trigger = trigger;
/* 125 */     this.applicationContext = applicationContext;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final Object getApplicationContext() {
/* 135 */     return this.applicationContext;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final Command getCommand() {
/* 145 */     return this.command;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final Object getObjectParameterForExecution(String parameterId) throws ExecutionException {
/* 166 */     if (this.command == null) {
/* 167 */       throw new ExecutionException("No command is associated with this execution event");
/*     */     }
/*     */     
/*     */     try {
/* 171 */       ParameterType parameterType = this.command.getParameterType(parameterId);
/* 172 */       if (parameterType == null) {
/* 173 */         throw new ExecutionException("Command does not have a parameter type for the given parameter");
/*     */       }
/* 175 */       AbstractParameterValueConverter valueConverter = parameterType.getValueConverter();
/* 176 */       if (valueConverter == null) {
/* 177 */         throw new ExecutionException("Command does not have a value converter");
/*     */       }
/* 179 */       String stringValue = getParameter(parameterId);
/* 180 */       return valueConverter.convertToObject(stringValue);
/* 181 */     } catch (NotDefinedException e) {
/* 182 */       throw new ExecutionException("Command is not defined", e);
/* 183 */     } catch (ParameterValueConversionException e) {
/* 184 */       throw new ExecutionException("The parameter string could not be converted to an object", e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final String getParameter(String parameterId) {
/* 197 */     return this.parameters.get(parameterId);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final Map getParameters() {
/* 207 */     return this.parameters;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final Object getTrigger() {
/* 216 */     return this.trigger;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final String toString() {
/* 227 */     StringBuilder stringBuffer = new StringBuilder("ExecutionEvent(");
/* 228 */     stringBuffer.append(this.command);
/* 229 */     stringBuffer.append(',');
/* 230 */     stringBuffer.append(this.parameters);
/* 231 */     stringBuffer.append(',');
/* 232 */     stringBuffer.append(this.trigger);
/* 233 */     stringBuffer.append(',');
/* 234 */     stringBuffer.append(this.applicationContext);
/* 235 */     stringBuffer.append(')');
/* 236 */     return stringBuffer.toString();
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.commands-3.11.0.jar!\org\eclipse\core\commands\ExecutionEvent.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */