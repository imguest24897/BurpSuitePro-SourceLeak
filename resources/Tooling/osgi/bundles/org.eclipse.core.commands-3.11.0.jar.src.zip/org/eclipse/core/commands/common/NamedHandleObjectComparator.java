/*    */ package org.eclipse.core.commands.common;
/*    */ 
/*    */ import java.util.Comparator;
/*    */ import org.eclipse.core.internal.commands.util.Util;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NamedHandleObjectComparator
/*    */   implements Comparator
/*    */ {
/*    */   public final int compare(Object left, Object right) {
/* 47 */     NamedHandleObject a = (NamedHandleObject)left;
/* 48 */     NamedHandleObject b = (NamedHandleObject)right;
/*    */     
/* 50 */     String aName = null;
/*    */     try {
/* 52 */       aName = a.getName();
/* 53 */     } catch (NotDefinedException notDefinedException) {}
/*    */ 
/*    */     
/* 56 */     String bName = null;
/*    */     try {
/* 58 */       bName = b.getName();
/* 59 */     } catch (NotDefinedException notDefinedException) {}
/*    */ 
/*    */ 
/*    */     
/* 63 */     return Util.compare(aName, bName);
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.commands-3.11.0.jar!\org\eclipse\core\commands\common\NamedHandleObjectComparator.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */