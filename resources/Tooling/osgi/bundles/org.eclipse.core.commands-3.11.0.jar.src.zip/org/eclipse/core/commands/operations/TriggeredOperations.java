/*     */ package org.eclipse.core.commands.operations;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import org.eclipse.core.commands.ExecutionException;
/*     */ import org.eclipse.core.runtime.IAdaptable;
/*     */ import org.eclipse.core.runtime.IProgressMonitor;
/*     */ import org.eclipse.core.runtime.IStatus;
/*     */ import org.eclipse.core.runtime.OperationCanceledException;
/*     */ import org.eclipse.core.runtime.Status;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class TriggeredOperations
/*     */   extends AbstractOperation
/*     */   implements ICompositeOperation, IAdvancedUndoableOperation, IAdvancedUndoableOperation2, IContextReplacingOperation
/*     */ {
/*     */   private IUndoableOperation triggeringOperation;
/*     */   private IOperationHistory history;
/*  53 */   private List<IUndoableOperation> children = new ArrayList<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TriggeredOperations(IUndoableOperation operation, IOperationHistory history) {
/*  66 */     super(operation.getLabel());
/*  67 */     this.triggeringOperation = operation;
/*  68 */     recomputeContexts();
/*  69 */     this.history = history;
/*     */   }
/*     */ 
/*     */   
/*     */   public void add(IUndoableOperation operation) {
/*  74 */     this.children.add(operation);
/*  75 */     recomputeContexts();
/*     */   }
/*     */ 
/*     */   
/*     */   public void remove(IUndoableOperation operation) {
/*  80 */     if (operation == this.triggeringOperation) {
/*     */ 
/*     */       
/*  83 */       this.triggeringOperation = null;
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*  88 */       List<IUndoableOperation> childrenToRestore = new ArrayList<>(this.children);
/*  89 */       if (childrenToRestore.size() > 1) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*  97 */         Set<IUndoableOperation> undoHistory = new HashSet<>(); byte b; int i; IUndoContext[] arrayOfIUndoContext;
/*  98 */         for (i = (arrayOfIUndoContext = getContexts()).length, b = 0; b < i; ) { IUndoContext context = arrayOfIUndoContext[b];
/*  99 */           if (context != null)
/* 100 */             undoHistory.addAll(Arrays.asList(this.history.getUndoHistory(context))); 
/*     */           b++; }
/*     */         
/* 103 */         if (undoHistory.contains(this)) {
/* 104 */           Collections.reverse(childrenToRestore);
/*     */         }
/*     */       } 
/* 107 */       this.children = new ArrayList<>(0);
/* 108 */       recomputeContexts();
/* 109 */       operation.dispose();
/*     */       
/* 111 */       this.history.replaceOperation(this, childrenToRestore.<IUndoableOperation>toArray(new IUndoableOperation[childrenToRestore.size()]));
/*     */     } else {
/* 113 */       this.children.remove(operation);
/* 114 */       operation.dispose();
/* 115 */       recomputeContexts();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void removeContext(IUndoContext context) {
/* 135 */     boolean recompute = false;
/*     */ 
/*     */     
/* 138 */     if (this.triggeringOperation != null && 
/* 139 */       this.triggeringOperation.hasContext(context)) {
/* 140 */       if ((this.triggeringOperation.getContexts()).length == 1) {
/* 141 */         remove(this.triggeringOperation);
/*     */         return;
/*     */       } 
/* 144 */       this.triggeringOperation.removeContext(context);
/* 145 */       recompute = true;
/*     */     } 
/*     */     
/* 148 */     ArrayList<IUndoableOperation> toBeRemoved = new ArrayList<>();
/* 149 */     for (IUndoableOperation child : this.children) {
/* 150 */       if (child.hasContext(context)) {
/* 151 */         if ((child.getContexts()).length == 1) {
/* 152 */           toBeRemoved.add(child);
/*     */         } else {
/* 154 */           child.removeContext(context);
/*     */         } 
/* 156 */         recompute = true;
/*     */       } 
/*     */     } 
/* 159 */     for (IUndoableOperation operation : toBeRemoved) {
/* 160 */       remove(operation);
/*     */     }
/* 162 */     if (recompute) {
/* 163 */       recomputeContexts();
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public IStatus execute(IProgressMonitor monitor, IAdaptable info) throws ExecutionException {
/* 169 */     if (this.triggeringOperation != null) {
/* 170 */       this.history.openOperation(this, 1);
/*     */       try {
/* 172 */         IStatus status = this.triggeringOperation.execute(monitor, info);
/* 173 */         this.history.closeOperation(status.isOK(), false, 1);
/* 174 */         return status;
/* 175 */       } catch (ExecutionException|RuntimeException e) {
/* 176 */         this.history.closeOperation(false, false, 1);
/* 177 */         throw e;
/*     */       } 
/*     */     } 
/*     */     
/* 181 */     return IOperationHistory.OPERATION_INVALID_STATUS;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public IStatus redo(IProgressMonitor monitor, IAdaptable info) throws ExecutionException {
/* 187 */     if (this.triggeringOperation != null) {
/* 188 */       this.history.openOperation(this, 3);
/* 189 */       List<IUndoableOperation> childrenToRestore = new ArrayList<>(this.children);
/*     */       try {
/* 191 */         removeAllChildren();
/* 192 */         IStatus status = this.triggeringOperation.redo(monitor, info);
/* 193 */         if (!status.isOK()) {
/* 194 */           this.children = childrenToRestore;
/*     */         }
/* 196 */         this.history.closeOperation(status.isOK(), false, 3);
/* 197 */         return status;
/* 198 */       } catch (ExecutionException|RuntimeException e) {
/* 199 */         this.children = childrenToRestore;
/* 200 */         this.history.closeOperation(false, false, 3);
/* 201 */         throw e;
/*     */       } 
/*     */     } 
/* 204 */     return IOperationHistory.OPERATION_INVALID_STATUS;
/*     */   }
/*     */ 
/*     */   
/*     */   public IStatus undo(IProgressMonitor monitor, IAdaptable info) throws ExecutionException {
/* 209 */     if (this.triggeringOperation != null) {
/* 210 */       this.history.openOperation(this, 2);
/* 211 */       List<IUndoableOperation> childrenToRestore = new ArrayList<>(this.children);
/*     */       try {
/* 213 */         removeAllChildren();
/* 214 */         IStatus status = this.triggeringOperation.undo(monitor, info);
/* 215 */         if (!status.isOK()) {
/* 216 */           this.children = childrenToRestore;
/*     */         }
/* 218 */         this.history.closeOperation(status.isOK(), false, 2);
/* 219 */         return status;
/* 220 */       } catch (ExecutionException|RuntimeException e) {
/* 221 */         this.children = childrenToRestore;
/* 222 */         this.history.closeOperation(false, false, 2);
/* 223 */         throw e;
/*     */       } 
/*     */     } 
/* 226 */     return IOperationHistory.OPERATION_INVALID_STATUS;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean canUndo() {
/* 231 */     if (this.triggeringOperation != null) {
/* 232 */       return this.triggeringOperation.canUndo();
/*     */     }
/* 234 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean canExecute() {
/* 239 */     if (this.triggeringOperation != null) {
/* 240 */       return this.triggeringOperation.canExecute();
/*     */     }
/* 242 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean canRedo() {
/* 247 */     if (this.triggeringOperation != null) {
/* 248 */       return this.triggeringOperation.canRedo();
/*     */     }
/* 250 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void dispose() {
/* 258 */     for (IUndoableOperation operation : this.children) {
/* 259 */       operation.dispose();
/*     */     }
/* 261 */     if (this.triggeringOperation != null) {
/* 262 */       this.triggeringOperation.dispose();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void recomputeContexts() {
/* 270 */     ArrayList<IUndoContext> allContexts = new ArrayList<>();
/* 271 */     if (this.triggeringOperation != null) {
/* 272 */       IUndoContext[] contexts = this.triggeringOperation.getContexts();
/* 273 */       allContexts.addAll(Arrays.asList(contexts));
/*     */     } 
/* 275 */     for (IUndoableOperation operation : this.children) {
/* 276 */       byte b; int i; IUndoContext[] arrayOfIUndoContext; for (i = (arrayOfIUndoContext = operation.getContexts()).length, b = 0; b < i; ) { IUndoContext context = arrayOfIUndoContext[b];
/* 277 */         if (!allContexts.contains(context))
/* 278 */           allContexts.add(context); 
/*     */         b++; }
/*     */     
/*     */     } 
/* 282 */     this.contexts = allContexts;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void removeAllChildren() {
/* 290 */     IUndoableOperation[] nonTriggers = this.children.<IUndoableOperation>toArray(new IUndoableOperation[this.children.size()]); byte b; int i; IUndoableOperation[] arrayOfIUndoableOperation1;
/* 291 */     for (i = (arrayOfIUndoableOperation1 = nonTriggers).length, b = 0; b < i; ) { IUndoableOperation nonTrigger = arrayOfIUndoableOperation1[b];
/* 292 */       this.children.remove(nonTrigger);
/* 293 */       nonTrigger.dispose();
/*     */       b++; }
/*     */   
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IUndoableOperation getTriggeringOperation() {
/* 304 */     return this.triggeringOperation;
/*     */   }
/*     */ 
/*     */   
/*     */   public Object[] getAffectedObjects() {
/* 309 */     if (this.triggeringOperation instanceof IAdvancedUndoableOperation) {
/* 310 */       return ((IAdvancedUndoableOperation)this.triggeringOperation).getAffectedObjects();
/*     */     }
/* 312 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public void aboutToNotify(OperationHistoryEvent event) {
/* 317 */     if (this.triggeringOperation instanceof IAdvancedUndoableOperation) {
/* 318 */       ((IAdvancedUndoableOperation)this.triggeringOperation).aboutToNotify(event);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public IStatus computeUndoableStatus(IProgressMonitor monitor) throws ExecutionException {
/* 324 */     if (this.triggeringOperation instanceof IAdvancedUndoableOperation) {
/*     */       try {
/* 326 */         return ((IAdvancedUndoableOperation)this.triggeringOperation).computeUndoableStatus(monitor);
/* 327 */       } catch (OperationCanceledException operationCanceledException) {
/* 328 */         return Status.CANCEL_STATUS;
/*     */       } 
/*     */     }
/* 331 */     return Status.OK_STATUS;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public IStatus computeRedoableStatus(IProgressMonitor monitor) throws ExecutionException {
/* 337 */     if (this.triggeringOperation instanceof IAdvancedUndoableOperation) {
/*     */       try {
/* 339 */         return ((IAdvancedUndoableOperation)this.triggeringOperation).computeRedoableStatus(monitor);
/* 340 */       } catch (OperationCanceledException operationCanceledException) {
/* 341 */         return Status.CANCEL_STATUS;
/*     */       } 
/*     */     }
/* 344 */     return Status.OK_STATUS;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void replaceContext(IUndoContext original, IUndoContext replacement) {
/* 367 */     if (this.triggeringOperation != null && 
/* 368 */       this.triggeringOperation.hasContext(original)) {
/* 369 */       if (this.triggeringOperation instanceof IContextReplacingOperation) {
/* 370 */         ((IContextReplacingOperation)this.triggeringOperation).replaceContext(original, replacement);
/*     */       } else {
/* 372 */         this.triggeringOperation.removeContext(original);
/* 373 */         this.triggeringOperation.addContext(replacement);
/*     */       } 
/*     */     }
/*     */     
/* 377 */     for (IUndoableOperation child : this.children) {
/* 378 */       if (child.hasContext(original)) {
/* 379 */         if (child instanceof IContextReplacingOperation) {
/* 380 */           ((IContextReplacingOperation)child).replaceContext(
/* 381 */               original, replacement); continue;
/*     */         } 
/* 383 */         child.removeContext(original);
/* 384 */         child.addContext(replacement);
/*     */       } 
/*     */     } 
/*     */     
/* 388 */     recomputeContexts();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addContext(IUndoContext context) {
/* 403 */     if (this.triggeringOperation != null) {
/* 404 */       this.triggeringOperation.addContext(context);
/* 405 */       recomputeContexts();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IStatus computeExecutionStatus(IProgressMonitor monitor) throws ExecutionException {
/* 414 */     if (this.triggeringOperation instanceof IAdvancedUndoableOperation2) {
/*     */       try {
/* 416 */         return ((IAdvancedUndoableOperation2)this.triggeringOperation).computeExecutionStatus(monitor);
/* 417 */       } catch (OperationCanceledException operationCanceledException) {
/* 418 */         return Status.CANCEL_STATUS;
/*     */       } 
/*     */     }
/* 421 */     return Status.OK_STATUS;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setQuietCompute(boolean quiet) {
/* 429 */     if (this.triggeringOperation instanceof IAdvancedUndoableOperation2) {
/* 430 */       ((IAdvancedUndoableOperation2)this.triggeringOperation).setQuietCompute(quiet);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean runInBackground() {
/* 439 */     if (this.triggeringOperation instanceof IAdvancedUndoableOperation2) {
/* 440 */       return ((IAdvancedUndoableOperation2)this.triggeringOperation).runInBackground();
/*     */     }
/* 442 */     return false;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.commands-3.11.0.jar!\org\eclipse\core\commands\operations\TriggeredOperations.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */