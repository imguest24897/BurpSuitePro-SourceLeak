/*    */ package org.eclipse.core.commands.common;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class AbstractNamedHandleEvent
/*    */   extends AbstractHandleObjectEvent
/*    */ {
/*    */   protected static final int CHANGED_DESCRIPTION = 2;
/*    */   protected static final int CHANGED_NAME = 2;
/*    */   protected static final int LAST_USED_BIT = 2;
/*    */   
/*    */   protected AbstractNamedHandleEvent(boolean definedChanged, boolean descriptionChanged, boolean nameChanged) {
/* 56 */     super(definedChanged);
/*    */     
/* 58 */     if (descriptionChanged) {
/* 59 */       this.changedValues |= 0x2;
/*    */     }
/* 61 */     if (nameChanged) {
/* 62 */       this.changedValues |= 0x2;
/*    */     }
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public final boolean isDescriptionChanged() {
/* 72 */     return ((this.changedValues & 0x2) != 0);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public final boolean isNameChanged() {
/* 81 */     return ((this.changedValues & 0x2) != 0);
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.commands-3.11.0.jar!\org\eclipse\core\commands\common\AbstractNamedHandleEvent.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */