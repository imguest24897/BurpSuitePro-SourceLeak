/*    */ package org.eclipse.core.commands.common;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class NamedHandleObject
/*    */   extends HandleObject
/*    */ {
/* 29 */   protected String description = null;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 35 */   protected String name = null;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected NamedHandleObject(String id) {
/* 44 */     super(id);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String getDescription() throws NotDefinedException {
/* 56 */     if (!isDefined()) {
/* 57 */       throw new NotDefinedException(
/* 58 */           "Cannot get a description from an undefined object. " + 
/* 59 */           this.id);
/*    */     }
/*    */     
/* 62 */     return this.description;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String getName() throws NotDefinedException {
/* 73 */     if (!isDefined()) {
/* 74 */       throw new NotDefinedException(
/* 75 */           "Cannot get the name from an undefined object. " + 
/* 76 */           this.id);
/*    */     }
/*    */     
/* 79 */     return this.name;
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.commands-3.11.0.jar!\org\eclipse\core\commands\common\NamedHandleObject.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */