package org.eclipse.core.commands.operations;

import org.eclipse.core.commands.ExecutionException;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.core.runtime.IStatus;

public interface IAdvancedUndoableOperation {
  void aboutToNotify(OperationHistoryEvent paramOperationHistoryEvent);
  
  Object[] getAffectedObjects();
  
  IStatus computeUndoableStatus(IProgressMonitor paramIProgressMonitor) throws ExecutionException;
  
  IStatus computeRedoableStatus(IProgressMonitor paramIProgressMonitor) throws ExecutionException;
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.commands-3.11.0.jar!\org\eclipse\core\commands\operations\IAdvancedUndoableOperation.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */