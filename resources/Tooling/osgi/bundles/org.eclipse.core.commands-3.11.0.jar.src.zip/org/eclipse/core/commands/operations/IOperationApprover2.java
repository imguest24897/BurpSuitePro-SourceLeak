package org.eclipse.core.commands.operations;

import org.eclipse.core.runtime.IAdaptable;
import org.eclipse.core.runtime.IStatus;

public interface IOperationApprover2 extends IOperationApprover {
  IStatus proceedExecuting(IUndoableOperation paramIUndoableOperation, IOperationHistory paramIOperationHistory, IAdaptable paramIAdaptable);
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.commands-3.11.0.jar!\org\eclipse\core\commands\operations\IOperationApprover2.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */