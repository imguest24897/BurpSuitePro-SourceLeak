package org.eclipse.core.commands;

public interface IStateListener {
  void handleStateChange(State paramState, Object paramObject);
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.commands-3.11.0.jar!\org\eclipse\core\commands\IStateListener.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */