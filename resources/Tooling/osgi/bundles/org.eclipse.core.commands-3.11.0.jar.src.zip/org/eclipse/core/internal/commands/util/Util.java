/*     */ package org.eclipse.core.internal.commands.util;
/*     */ 
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import org.eclipse.core.commands.Command;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class Util
/*     */ {
/*     */   public static final String ZERO_LENGTH_STRING = "";
/*     */   
/*     */   public static final void assertInstance(Object object, Class<?> c, boolean allowNull) {
/*  55 */     if (object == null && allowNull) {
/*     */       return;
/*     */     }
/*     */     
/*  59 */     if (object == null || c == null)
/*  60 */       throw new NullPointerException(); 
/*  61 */     if (!c.isInstance(object)) {
/*  62 */       throw new IllegalArgumentException();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final int compare(boolean left, boolean right) {
/*  81 */     return !left ? (right ? -1 : 0) : (right ? 0 : 1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final <T extends Comparable<? super T>> int compare(T left, T right) {
/* 100 */     if (left == null && right == null)
/* 101 */       return 0; 
/* 102 */     if (left == null)
/* 103 */       return -1; 
/* 104 */     if (right == null) {
/* 105 */       return 1;
/*     */     }
/* 107 */     return left.compareTo(right);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final int compare(int left, int right) {
/* 123 */     return left - right;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final int compare(Object left, Object right) {
/* 146 */     if (left == null && right == null)
/* 147 */       return 0; 
/* 148 */     if (left == null)
/* 149 */       return -1; 
/* 150 */     if (right == null) {
/* 151 */       return 1;
/*     */     }
/* 153 */     return left.toString().compareTo(right.toString());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final <K, V> Map<K, V> safeCopy(Map<K, V> map, Class<K> keyClass, Class<V> valueClass, boolean allowNullKeys, boolean allowNullValues) {
/* 178 */     if (map == null || keyClass == null || valueClass == null) {
/* 179 */       throw new NullPointerException();
/*     */     }
/*     */     
/* 182 */     Map<K, V> copy = Collections.unmodifiableMap(new HashMap<>(map));
/* 183 */     Iterator<Map.Entry<K, V>> iterator = copy.entrySet().iterator();
/*     */     
/* 185 */     while (iterator.hasNext()) {
/* 186 */       Map.Entry<K, V> entry = iterator.next();
/* 187 */       assertInstance(entry.getKey(), keyClass, allowNullKeys);
/* 188 */       assertInstance(entry.getValue(), valueClass, allowNullValues);
/*     */     } 
/* 190 */     return copy;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final <T> Set<T> safeCopy(Set<T> set, Class<T> c) {
/* 207 */     return safeCopy(set, c, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final <T> Set<T> safeCopy(Set<T> set, Class<T> c, boolean allowNullElements) {
/* 225 */     if (set == null || c == null) {
/* 226 */       throw new NullPointerException();
/*     */     }
/*     */     
/* 229 */     Set<T> copy = Collections.unmodifiableSet(new HashSet<>(set));
/* 230 */     Iterator<T> iterator = copy.iterator();
/*     */     
/* 232 */     while (iterator.hasNext()) {
/* 233 */       assertInstance(iterator.next(), c, allowNullElements);
/*     */     }
/*     */     
/* 236 */     return copy;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final String getHelpContextId(Command command) {
/* 249 */     Method method = null;
/*     */     try {
/* 251 */       method = Command.class.getDeclaredMethod("getHelpContextId", new Class[0]);
/* 252 */     } catch (Exception exception) {}
/*     */ 
/*     */ 
/*     */     
/* 256 */     String contextId = null;
/* 257 */     if (method != null) {
/* 258 */       boolean accessible = method.isAccessible();
/* 259 */       method.setAccessible(true);
/*     */       try {
/* 261 */         contextId = (String)method.invoke(command, new Object[0]);
/* 262 */       } catch (Exception exception) {}
/*     */ 
/*     */       
/* 265 */       method.setAccessible(accessible);
/*     */     } 
/* 267 */     return contextId;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.commands-3.11.0.jar!\org\eclipse\core\internal\command\\util\Util.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */