/*     */ package org.eclipse.core.commands.operations;
/*     */ 
/*     */ import org.eclipse.core.commands.ExecutionException;
/*     */ import org.eclipse.core.internal.commands.operations.GlobalUndoContext;
/*     */ import org.eclipse.core.runtime.IAdaptable;
/*     */ import org.eclipse.core.runtime.IProgressMonitor;
/*     */ import org.eclipse.core.runtime.IStatus;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public interface IOperationHistory
/*     */ {
/*     */   public static final int EXECUTE = 1;
/*     */   public static final int UNDO = 2;
/*     */   public static final int REDO = 3;
/*  95 */   public static final IUndoContext GLOBAL_UNDO_CONTEXT = (IUndoContext)new GlobalUndoContext();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 101 */   public static final IStatus NOTHING_TO_REDO_STATUS = (IStatus)new OperationStatus(
/* 102 */       1, OperationStatus.DEFAULT_PLUGIN_ID, 
/* 103 */       1, "No operation to redo", null);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 109 */   public static final IStatus NOTHING_TO_UNDO_STATUS = (IStatus)new OperationStatus(
/* 110 */       1, OperationStatus.DEFAULT_PLUGIN_ID, 
/* 111 */       2, "No operation to undo", null);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 118 */   public static final IStatus OPERATION_INVALID_STATUS = (IStatus)new OperationStatus(
/* 119 */       4, OperationStatus.DEFAULT_PLUGIN_ID, 
/* 120 */       3, "Operation is not valid", null);
/*     */   
/*     */   void add(IUndoableOperation paramIUndoableOperation);
/*     */   
/*     */   void addOperationApprover(IOperationApprover paramIOperationApprover);
/*     */   
/*     */   void addOperationHistoryListener(IOperationHistoryListener paramIOperationHistoryListener);
/*     */   
/*     */   void closeOperation(boolean paramBoolean1, boolean paramBoolean2, int paramInt);
/*     */   
/*     */   boolean canRedo(IUndoContext paramIUndoContext);
/*     */   
/*     */   boolean canUndo(IUndoContext paramIUndoContext);
/*     */   
/*     */   void dispose(IUndoContext paramIUndoContext, boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3);
/*     */   
/*     */   IStatus execute(IUndoableOperation paramIUndoableOperation, IProgressMonitor paramIProgressMonitor, IAdaptable paramIAdaptable) throws ExecutionException;
/*     */   
/*     */   int getLimit(IUndoContext paramIUndoContext);
/*     */   
/*     */   IUndoableOperation[] getRedoHistory(IUndoContext paramIUndoContext);
/*     */   
/*     */   IUndoableOperation getRedoOperation(IUndoContext paramIUndoContext);
/*     */   
/*     */   IUndoableOperation[] getUndoHistory(IUndoContext paramIUndoContext);
/*     */   
/*     */   void openOperation(ICompositeOperation paramICompositeOperation, int paramInt);
/*     */   
/*     */   void operationChanged(IUndoableOperation paramIUndoableOperation);
/*     */   
/*     */   IUndoableOperation getUndoOperation(IUndoContext paramIUndoContext);
/*     */   
/*     */   IStatus redo(IUndoContext paramIUndoContext, IProgressMonitor paramIProgressMonitor, IAdaptable paramIAdaptable) throws ExecutionException;
/*     */   
/*     */   IStatus redoOperation(IUndoableOperation paramIUndoableOperation, IProgressMonitor paramIProgressMonitor, IAdaptable paramIAdaptable) throws ExecutionException;
/*     */   
/*     */   void removeOperationApprover(IOperationApprover paramIOperationApprover);
/*     */   
/*     */   void removeOperationHistoryListener(IOperationHistoryListener paramIOperationHistoryListener);
/*     */   
/*     */   void replaceOperation(IUndoableOperation paramIUndoableOperation, IUndoableOperation[] paramArrayOfIUndoableOperation);
/*     */   
/*     */   void setLimit(IUndoContext paramIUndoContext, int paramInt);
/*     */   
/*     */   IStatus undo(IUndoContext paramIUndoContext, IProgressMonitor paramIProgressMonitor, IAdaptable paramIAdaptable) throws ExecutionException;
/*     */   
/*     */   IStatus undoOperation(IUndoableOperation paramIUndoableOperation, IProgressMonitor paramIProgressMonitor, IAdaptable paramIAdaptable) throws ExecutionException;
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.commands-3.11.0.jar!\org\eclipse\core\commands\operations\IOperationHistory.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */