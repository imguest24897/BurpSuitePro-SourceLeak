/*    */ package org.eclipse.core.commands;
/*    */ 
/*    */ import org.eclipse.core.commands.common.AbstractNamedHandleEvent;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class CategoryEvent
/*    */   extends AbstractNamedHandleEvent
/*    */ {
/*    */   private final Category category;
/*    */   
/*    */   public CategoryEvent(Category category, boolean definedChanged, boolean descriptionChanged, boolean nameChanged) {
/* 49 */     super(definedChanged, descriptionChanged, nameChanged);
/*    */     
/* 51 */     if (category == null) {
/* 52 */       throw new NullPointerException();
/*    */     }
/* 54 */     this.category = category;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public final Category getCategory() {
/* 64 */     return this.category;
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.commands-3.11.0.jar!\org\eclipse\core\commands\CategoryEvent.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */