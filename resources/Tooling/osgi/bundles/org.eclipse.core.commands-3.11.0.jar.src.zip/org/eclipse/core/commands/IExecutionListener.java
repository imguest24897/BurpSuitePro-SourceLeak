package org.eclipse.core.commands;

public interface IExecutionListener {
  void notHandled(String paramString, NotHandledException paramNotHandledException);
  
  void postExecuteFailure(String paramString, ExecutionException paramExecutionException);
  
  void postExecuteSuccess(String paramString, Object paramObject);
  
  void preExecute(String paramString, ExecutionEvent paramExecutionEvent);
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.commands-3.11.0.jar!\org\eclipse\core\commands\IExecutionListener.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */