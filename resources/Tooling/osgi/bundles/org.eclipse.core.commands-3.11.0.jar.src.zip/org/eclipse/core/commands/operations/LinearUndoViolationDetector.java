/*     */ package org.eclipse.core.commands.operations;
/*     */ 
/*     */ import org.eclipse.core.runtime.IAdaptable;
/*     */ import org.eclipse.core.runtime.IStatus;
/*     */ import org.eclipse.core.runtime.Status;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class LinearUndoViolationDetector
/*     */   implements IOperationApprover
/*     */ {
/*     */   protected abstract IStatus allowLinearRedoViolation(IUndoableOperation paramIUndoableOperation, IUndoContext paramIUndoContext, IOperationHistory paramIOperationHistory, IAdaptable paramIAdaptable);
/*     */   
/*     */   protected abstract IStatus allowLinearUndoViolation(IUndoableOperation paramIUndoableOperation, IUndoContext paramIUndoContext, IOperationHistory paramIOperationHistory, IAdaptable paramIAdaptable);
/*     */   
/*     */   public final IStatus proceedRedoing(IUndoableOperation operation, IOperationHistory history, IAdaptable info) {
/* 102 */     IUndoContext[] contexts = operation.getContexts(); byte b; int i; IUndoContext[] arrayOfIUndoContext1;
/* 103 */     for (i = (arrayOfIUndoContext1 = contexts).length, b = 0; b < i; ) { IUndoContext context = arrayOfIUndoContext1[b];
/* 104 */       if (history.getRedoOperation(context) != operation) {
/* 105 */         IStatus status = allowLinearRedoViolation(operation, context, 
/* 106 */             history, info);
/* 107 */         if (!status.isOK())
/* 108 */           return status; 
/*     */       } 
/*     */       b++; }
/*     */     
/* 112 */     return Status.OK_STATUS;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final IStatus proceedUndoing(IUndoableOperation operation, IOperationHistory history, IAdaptable info) {
/* 119 */     IUndoContext[] contexts = operation.getContexts(); byte b; int i; IUndoContext[] arrayOfIUndoContext1;
/* 120 */     for (i = (arrayOfIUndoContext1 = contexts).length, b = 0; b < i; ) { IUndoContext context = arrayOfIUndoContext1[b];
/* 121 */       if (history.getUndoOperation(context) != operation) {
/* 122 */         IStatus status = allowLinearUndoViolation(operation, context, 
/* 123 */             history, info);
/* 124 */         if (!status.isOK())
/* 125 */           return status; 
/*     */       } 
/*     */       b++; }
/*     */     
/* 129 */     return Status.OK_STATUS;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.commands-3.11.0.jar!\org\eclipse\core\commands\operations\LinearUndoViolationDetector.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */