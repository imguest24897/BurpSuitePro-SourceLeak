/*     */ package org.eclipse.core.commands;
/*     */ 
/*     */ import org.eclipse.core.commands.common.AbstractNamedHandleEvent;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class CommandEvent
/*     */   extends AbstractNamedHandleEvent
/*     */ {
/*     */   private static final int CHANGED_CATEGORY = 4;
/*     */   private static final int CHANGED_HANDLED = 8;
/*     */   private static final int CHANGED_PARAMETERS = 16;
/*     */   private static final int CHANGED_RETURN_TYPE = 32;
/*     */   private static final int CHANGED_HELP_CONTEXT_ID = 64;
/*     */   private static final int CHANGED_ENABLED = 128;
/*     */   private final Command command;
/*     */   
/*     */   public CommandEvent(Command command, boolean categoryChanged, boolean definedChanged, boolean descriptionChanged, boolean handledChanged, boolean nameChanged, boolean parametersChanged) {
/*  98 */     this(command, categoryChanged, definedChanged, descriptionChanged, handledChanged, nameChanged, parametersChanged, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CommandEvent(Command command, boolean categoryChanged, boolean definedChanged, boolean descriptionChanged, boolean handledChanged, boolean nameChanged, boolean parametersChanged, boolean returnTypeChanged) {
/* 130 */     this(command, categoryChanged, definedChanged, descriptionChanged, handledChanged, nameChanged, parametersChanged, returnTypeChanged, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CommandEvent(Command command, boolean categoryChanged, boolean definedChanged, boolean descriptionChanged, boolean handledChanged, boolean nameChanged, boolean parametersChanged, boolean returnTypeChanged, boolean helpContextIdChanged) {
/* 166 */     this(command, categoryChanged, definedChanged, descriptionChanged, handledChanged, nameChanged, parametersChanged, returnTypeChanged, helpContextIdChanged, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CommandEvent(Command command, boolean categoryChanged, boolean definedChanged, boolean descriptionChanged, boolean handledChanged, boolean nameChanged, boolean parametersChanged, boolean returnTypeChanged, boolean helpContextIdChanged, boolean enabledChanged) {
/* 203 */     super(definedChanged, descriptionChanged, nameChanged);
/*     */     
/* 205 */     if (command == null) {
/* 206 */       throw new NullPointerException();
/*     */     }
/* 208 */     this.command = command;
/*     */     
/* 210 */     if (categoryChanged) {
/* 211 */       this.changedValues |= 0x4;
/*     */     }
/* 213 */     if (handledChanged) {
/* 214 */       this.changedValues |= 0x8;
/*     */     }
/* 216 */     if (parametersChanged) {
/* 217 */       this.changedValues |= 0x10;
/*     */     }
/* 219 */     if (returnTypeChanged) {
/* 220 */       this.changedValues |= 0x20;
/*     */     }
/* 222 */     if (helpContextIdChanged) {
/* 223 */       this.changedValues |= 0x40;
/*     */     }
/* 225 */     if (enabledChanged) {
/* 226 */       this.changedValues |= 0x80;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final Command getCommand() {
/* 237 */     return this.command;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final boolean isCategoryChanged() {
/* 246 */     return ((this.changedValues & 0x4) != 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final boolean isHandledChanged() {
/* 255 */     return ((this.changedValues & 0x8) != 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final boolean isHelpContextIdChanged() {
/* 265 */     return ((this.changedValues & 0x40) != 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final boolean isParametersChanged() {
/* 274 */     return ((this.changedValues & 0x10) != 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final boolean isReturnTypeChanged() {
/* 284 */     return ((this.changedValues & 0x20) != 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final boolean isEnabledChanged() {
/* 294 */     return ((this.changedValues & 0x80) != 0);
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.commands-3.11.0.jar!\org\eclipse\core\commands\CommandEvent.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */