/*    */ package org.eclipse.core.commands.contexts;
/*    */ 
/*    */ import org.eclipse.core.commands.common.AbstractNamedHandleEvent;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class ContextEvent
/*    */   extends AbstractNamedHandleEvent
/*    */ {
/*    */   private static final int CHANGED_PARENT_ID = 4;
/*    */   private final Context context;
/*    */   
/*    */   public ContextEvent(Context context, boolean definedChanged, boolean nameChanged, boolean descriptionChanged, boolean parentIdChanged) {
/* 59 */     super(definedChanged, descriptionChanged, nameChanged);
/*    */     
/* 61 */     if (context == null) {
/* 62 */       throw new NullPointerException();
/*    */     }
/* 64 */     this.context = context;
/*    */     
/* 66 */     if (parentIdChanged) {
/* 67 */       this.changedValues |= 0x4;
/*    */     }
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public final Context getContext() {
/* 78 */     return this.context;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public final boolean isParentIdChanged() {
/* 87 */     return ((this.changedValues & 0x4) != 0);
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.commands-3.11.0.jar!\org\eclipse\core\commands\contexts\ContextEvent.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */