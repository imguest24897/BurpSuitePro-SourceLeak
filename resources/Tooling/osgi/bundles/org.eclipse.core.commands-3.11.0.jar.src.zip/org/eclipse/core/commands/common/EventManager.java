/*     */ package org.eclipse.core.commands.common;
/*     */ 
/*     */ import org.eclipse.core.runtime.ListenerList;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class EventManager
/*     */ {
/*  41 */   private static final Object[] EMPTY_ARRAY = new Object[0];
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  47 */   private volatile transient ListenerList<Object> listenerList = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final synchronized void addListenerObject(Object listener) {
/*  58 */     if (listener == null) {
/*  59 */       throw new IllegalArgumentException();
/*     */     }
/*     */     
/*  62 */     if (this.listenerList == null) {
/*  63 */       this.listenerList = new ListenerList(1);
/*     */     }
/*     */     
/*  66 */     this.listenerList.add(listener);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final void clearListeners() {
/*  73 */     this.listenerList = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final Object[] getListeners() {
/*  91 */     ListenerList<Object> list = this.listenerList;
/*  92 */     if (list == null) {
/*  93 */       return EMPTY_ARRAY;
/*     */     }
/*     */     
/*  96 */     return list.getListeners();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final boolean isListenerAttached() {
/* 106 */     return (this.listenerList != null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final synchronized void removeListenerObject(Object listener) {
/* 117 */     if (listener == null) {
/* 118 */       throw new IllegalArgumentException();
/*     */     }
/*     */     
/* 121 */     if (this.listenerList != null) {
/* 122 */       this.listenerList.remove(listener);
/*     */       
/* 124 */       if (this.listenerList.isEmpty())
/* 125 */         this.listenerList = null; 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.commands-3.11.0.jar!\org\eclipse\core\commands\common\EventManager.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */