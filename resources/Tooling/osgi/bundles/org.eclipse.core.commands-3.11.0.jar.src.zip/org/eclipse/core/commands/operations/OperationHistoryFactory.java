/*    */ package org.eclipse.core.commands.operations;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class OperationHistoryFactory
/*    */ {
/*    */   private static IOperationHistory operationHistory;
/*    */   
/*    */   public static IOperationHistory getOperationHistory() {
/* 41 */     if (operationHistory == null) {
/* 42 */       operationHistory = new DefaultOperationHistory();
/*    */     }
/* 44 */     return operationHistory;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static void setOperationHistory(IOperationHistory history) {
/* 60 */     if (operationHistory == null)
/* 61 */       operationHistory = history; 
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.commands-3.11.0.jar!\org\eclipse\core\commands\operations\OperationHistoryFactory.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */