/*     */ package org.eclipse.core.commands.operations;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.eclipse.core.commands.ExecutionException;
/*     */ import org.eclipse.core.runtime.Assert;
/*     */ import org.eclipse.core.runtime.IAdaptable;
/*     */ import org.eclipse.core.runtime.IProgressMonitor;
/*     */ import org.eclipse.core.runtime.IStatus;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractOperation
/*     */   implements IUndoableOperation
/*     */ {
/*  40 */   List<IUndoContext> contexts = new ArrayList<>();
/*     */   
/*  42 */   private String label = "";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AbstractOperation(String label) {
/*  52 */     Assert.isNotNull(label);
/*  53 */     this.label = label;
/*     */   }
/*     */ 
/*     */   
/*     */   public void addContext(IUndoContext context) {
/*  58 */     if (!this.contexts.contains(context)) {
/*  59 */       this.contexts.add(context);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean canExecute() {
/*  65 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean canRedo() {
/*  70 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean canUndo() {
/*  75 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void dispose() {}
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract IStatus execute(IProgressMonitor paramIProgressMonitor, IAdaptable paramIAdaptable) throws ExecutionException;
/*     */ 
/*     */   
/*     */   public final IUndoContext[] getContexts() {
/*  88 */     return this.contexts.<IUndoContext>toArray(new IUndoContext[this.contexts.size()]);
/*     */   }
/*     */ 
/*     */   
/*     */   public String getLabel() {
/*  93 */     return this.label;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setLabel(String name) {
/* 104 */     this.label = name;
/*     */   }
/*     */ 
/*     */   
/*     */   public final boolean hasContext(IUndoContext context) {
/* 109 */     Assert.isNotNull(context);
/* 110 */     for (IUndoContext otherContext : this.contexts) {
/*     */ 
/*     */ 
/*     */       
/* 114 */       if (context.matches(otherContext) || otherContext.matches(context)) {
/* 115 */         return true;
/*     */       }
/*     */     } 
/* 118 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract IStatus redo(IProgressMonitor paramIProgressMonitor, IAdaptable paramIAdaptable) throws ExecutionException;
/*     */ 
/*     */   
/*     */   public void removeContext(IUndoContext context) {
/* 127 */     this.contexts.remove(context);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract IStatus undo(IProgressMonitor paramIProgressMonitor, IAdaptable paramIAdaptable) throws ExecutionException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 141 */     StringBuilder stringBuffer = new StringBuilder();
/* 142 */     stringBuffer.append(getLabel());
/* 143 */     stringBuffer.append("(");
/* 144 */     IUndoContext[] contexts = getContexts();
/* 145 */     for (int i = 0; i < contexts.length; i++) {
/* 146 */       stringBuffer.append(contexts[i].toString());
/* 147 */       if (i != contexts.length - 1) {
/* 148 */         stringBuffer.append(',');
/*     */       }
/*     */     } 
/* 151 */     stringBuffer.append(')');
/* 152 */     return stringBuffer.toString();
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.commands-3.11.0.jar!\org\eclipse\core\commands\operations\AbstractOperation.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */