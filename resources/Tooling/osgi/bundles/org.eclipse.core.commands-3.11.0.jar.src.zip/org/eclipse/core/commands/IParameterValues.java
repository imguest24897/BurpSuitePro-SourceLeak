package org.eclipse.core.commands;

import java.util.Map;

public interface IParameterValues {
  Map getParameterValues();
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.commands-3.11.0.jar!\org\eclipse\core\commands\IParameterValues.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */