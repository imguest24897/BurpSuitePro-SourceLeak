/*     */ package org.eclipse.core.commands.contexts;
/*     */ 
/*     */ import java.util.Collections;
/*     */ import java.util.HashSet;
/*     */ import java.util.Objects;
/*     */ import java.util.Set;
/*     */ import org.eclipse.core.commands.common.HandleObjectManager;
/*     */ import org.eclipse.core.commands.internal.util.Tracing;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ContextManager
/*     */   extends HandleObjectManager
/*     */   implements IContextListener
/*     */ {
/*     */   public static boolean DEBUG;
/*  51 */   private Set<String> activeContextIds = new HashSet<>();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean caching;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int cachingRef;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean activeContextsChange;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Set<String> oldIds;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void deferUpdates(boolean defer) {
/*  77 */     if (defer) {
/*  78 */       this.cachingRef++;
/*  79 */       if (this.cachingRef == 1) {
/*  80 */         setEventCaching(true);
/*     */       }
/*     */     } else {
/*  83 */       this.cachingRef--;
/*  84 */       if (this.cachingRef == 0) {
/*  85 */         setEventCaching(false);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void addActiveContext(String contextId) {
/* 100 */     if (this.activeContextIds.contains(contextId)) {
/*     */       return;
/*     */     }
/* 103 */     this.activeContextsChange = true;
/*     */     
/* 105 */     if (this.caching) {
/* 106 */       this.activeContextIds.add(contextId);
/*     */     } else {
/* 108 */       Set<String> previouslyActiveContextIds = new HashSet<>(this.activeContextIds);
/* 109 */       this.activeContextIds.add(contextId);
/*     */       
/* 111 */       fireContextManagerChanged(new ContextManagerEvent(this, null, false, true, previouslyActiveContextIds));
/*     */     } 
/*     */     
/* 114 */     if (DEBUG) {
/* 115 */       Tracing.printTrace("CONTEXTS", this.activeContextIds.toString());
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void addContextManagerListener(IContextManagerListener listener) {
/* 129 */     addListenerObject(listener);
/*     */   }
/*     */ 
/*     */   
/*     */   public final void contextChanged(ContextEvent contextEvent) {
/* 134 */     if (contextEvent.isDefinedChanged()) {
/* 135 */       Context context = contextEvent.getContext();
/* 136 */       String contextId = context.getId();
/* 137 */       boolean contextIdAdded = context.isDefined();
/* 138 */       if (contextIdAdded) {
/* 139 */         this.definedHandleObjects.add(context);
/*     */       } else {
/* 141 */         this.definedHandleObjects.remove(context);
/*     */       } 
/* 143 */       if (isListenerAttached()) {
/* 144 */         fireContextManagerChanged(new ContextManagerEvent(this, contextId, contextIdAdded, false, null));
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final void fireContextManagerChanged(ContextManagerEvent event) {
/* 158 */     if (event == null)
/* 159 */       throw new NullPointerException();  byte b;
/*     */     int i;
/*     */     Object[] arrayOfObject;
/* 162 */     for (i = (arrayOfObject = getListeners()).length, b = 0; b < i; ) { Object listener = arrayOfObject[b];
/* 163 */       IContextManagerListener contextManagerListener = (IContextManagerListener)listener;
/* 164 */       contextManagerListener.contextManagerChanged(event);
/*     */       b++; }
/*     */   
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final Set getActiveContextIds() {
/* 178 */     return Collections.unmodifiableSet(this.activeContextIds);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final Context getContext(String contextId) {
/* 192 */     checkId(contextId);
/*     */     
/* 194 */     Context context = (Context)this.handleObjectsById.get(contextId);
/* 195 */     if (context == null) {
/* 196 */       context = new Context(contextId);
/* 197 */       this.handleObjectsById.put(contextId, context);
/* 198 */       context.addContextListener(this);
/*     */     } 
/*     */     
/* 201 */     return context;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final Set getDefinedContextIds() {
/* 212 */     return getDefinedHandleObjectIds();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final Context[] getDefinedContexts() {
/* 223 */     return (Context[])this.definedHandleObjects.toArray((Object[])new Context[this.definedHandleObjects.size()]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void removeActiveContext(String contextId) {
/* 234 */     if (!this.activeContextIds.contains(contextId)) {
/*     */       return;
/*     */     }
/*     */     
/* 238 */     this.activeContextsChange = true;
/* 239 */     if (this.caching) {
/* 240 */       this.activeContextIds.remove(contextId);
/*     */     } else {
/* 242 */       Set<String> previouslyActiveContextIds = new HashSet<>(this.activeContextIds);
/* 243 */       this.activeContextIds.remove(contextId);
/*     */       
/* 245 */       fireContextManagerChanged(new ContextManagerEvent(this, null, 
/* 246 */             false, true, previouslyActiveContextIds));
/*     */     } 
/*     */     
/* 249 */     if (DEBUG) {
/* 250 */       Tracing.printTrace("CONTEXTS", this.activeContextIds.toString());
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void removeContextManagerListener(IContextManagerListener listener) {
/* 261 */     removeListenerObject(listener);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void setActiveContextIds(Set<? extends String> activeContextIds) {
/* 275 */     if (Objects.equals(this.activeContextIds, activeContextIds)) {
/*     */       return;
/*     */     }
/*     */     
/* 279 */     this.activeContextsChange = true;
/*     */     
/* 281 */     Set<String> previouslyActiveContextIds = this.activeContextIds;
/* 282 */     if (activeContextIds != null) {
/* 283 */       this.activeContextIds = new HashSet<>();
/* 284 */       this.activeContextIds.addAll(activeContextIds);
/*     */     } else {
/* 286 */       this.activeContextIds = null;
/*     */     } 
/*     */     
/* 289 */     if (DEBUG) {
/* 290 */       Tracing.printTrace("CONTEXTS", (activeContextIds == null) ? "none" : 
/* 291 */           activeContextIds.toString());
/*     */     }
/*     */     
/* 294 */     if (!this.caching) {
/* 295 */       fireContextManagerChanged(new ContextManagerEvent(this, null, false, true, previouslyActiveContextIds));
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void setEventCaching(boolean cache) {
/* 308 */     if (this.caching == cache) {
/*     */       return;
/*     */     }
/* 311 */     this.caching = cache;
/* 312 */     boolean fireChange = this.activeContextsChange;
/* 313 */     Set<String> holdOldIds = (this.oldIds == null) ? Collections.EMPTY_SET : this.oldIds;
/*     */     
/* 315 */     if (this.caching) {
/* 316 */       this.oldIds = new HashSet<>(this.activeContextIds);
/*     */     } else {
/* 318 */       this.oldIds = null;
/*     */     } 
/* 320 */     this.activeContextsChange = false;
/*     */     
/* 322 */     if (!this.caching && fireChange)
/* 323 */       fireContextManagerChanged(new ContextManagerEvent(this, null, false, true, holdOldIds)); 
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.commands-3.11.0.jar!\org\eclipse\core\commands\contexts\ContextManager.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */