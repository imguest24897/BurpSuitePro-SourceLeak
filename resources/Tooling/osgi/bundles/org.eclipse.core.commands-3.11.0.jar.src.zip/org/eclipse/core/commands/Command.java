/*      */ package org.eclipse.core.commands;
/*      */ 
/*      */ import java.util.Arrays;
/*      */ import java.util.Objects;
/*      */ import org.eclipse.core.commands.common.NotDefinedException;
/*      */ import org.eclipse.core.commands.internal.util.Tracing;
/*      */ import org.eclipse.core.internal.commands.util.Util;
/*      */ import org.eclipse.core.runtime.ISafeRunnable;
/*      */ import org.eclipse.core.runtime.ListenerList;
/*      */ import org.eclipse.core.runtime.SafeRunner;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public final class Command
/*      */   extends NamedHandleObjectWithState
/*      */   implements Comparable
/*      */ {
/*      */   public static boolean DEBUG_COMMAND_EXECUTION;
/*      */   public static boolean DEBUG_HANDLERS;
/*      */   public static String DEBUG_HANDLERS_COMMAND_ID;
/*      */   private Category category;
/*      */   private transient ListenerList<IExecutionListener> executionListeners;
/*      */   boolean shouldFireEvents = true;
/*      */   private transient IHandler handler;
/*      */   private String helpContextId;
/*      */   private IParameter[] parameters;
/*      */   private ParameterType returnType;
/*      */   private IHandlerListener handlerListener;
/*      */   
/*      */   Command(String id) {
/*  140 */     super(id);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void addCommandListener(ICommandListener commandListener) {
/*  151 */     if (commandListener == null) {
/*  152 */       throw new NullPointerException("Cannot add a null command listener");
/*      */     }
/*  154 */     addListenerObject(commandListener);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void addExecutionListener(IExecutionListener executionListener) {
/*  165 */     if (executionListener == null) {
/*  166 */       throw new NullPointerException("Cannot add a null execution listener");
/*      */     }
/*      */     
/*  169 */     if (this.executionListeners == null) {
/*  170 */       this.executionListeners = new ListenerList(1);
/*      */     }
/*      */     
/*  173 */     this.executionListeners.add(executionListener);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void addState(String id, State state) {
/*  195 */     super.addState(id, state);
/*  196 */     state.setId(id);
/*  197 */     if (this.handler instanceof IObjectWithState) {
/*  198 */       ((IObjectWithState)this.handler).addState(id, state);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int compareTo(Object object) {
/*  214 */     Command castedObject = (Command)object;
/*  215 */     int compareTo = Util.compare(this.category, castedObject.category);
/*  216 */     if (compareTo == 0) {
/*  217 */       compareTo = Util.compare(this.defined, castedObject.defined);
/*  218 */       if (compareTo == 0) {
/*  219 */         compareTo = Util.compare(this.description, castedObject.description);
/*  220 */         if (compareTo == 0) {
/*  221 */           compareTo = Util.compare(this.handler, castedObject.handler);
/*  222 */           if (compareTo == 0) {
/*  223 */             compareTo = Util.compare(this.id, castedObject.id);
/*  224 */             if (compareTo == 0) {
/*  225 */               compareTo = Util.compare(this.name, castedObject.name);
/*  226 */               if (compareTo == 0) {
/*  227 */                 compareTo = Util.compare(this.parameters, castedObject.parameters);
/*      */               }
/*      */             } 
/*      */           } 
/*      */         } 
/*      */       } 
/*      */     } 
/*  234 */     return compareTo;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void define(String name, String description, Category category) {
/*  255 */     define(name, description, category, (IParameter[])null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void define(String name, String description, Category category, IParameter[] parameters) {
/*  280 */     define(name, description, category, parameters, (ParameterType)null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void define(String name, String description, Category category, IParameter[] parameters, ParameterType returnType) {
/*  311 */     define(name, description, category, parameters, returnType, (String)null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void define(String name, String description, Category category, IParameter[] parameters, ParameterType returnType, String helpContextId) {
/*  346 */     if (name == null) {
/*  347 */       throw new NullPointerException("The name of a command cannot be null");
/*      */     }
/*      */     
/*  350 */     if (category == null) {
/*  351 */       throw new NullPointerException("The category of a command cannot be null");
/*      */     }
/*      */     
/*  354 */     boolean definedChanged = !this.defined;
/*  355 */     this.defined = true;
/*      */     
/*  357 */     boolean nameChanged = !Objects.equals(this.name, name);
/*  358 */     this.name = name;
/*      */     
/*  360 */     boolean descriptionChanged = !Objects.equals(this.description, 
/*  361 */         description);
/*  362 */     this.description = description;
/*      */     
/*  364 */     boolean categoryChanged = !Objects.equals(this.category, category);
/*  365 */     this.category = category;
/*      */     
/*  367 */     boolean parametersChanged = !Arrays.equals((Object[])this.parameters, 
/*  368 */         (Object[])parameters);
/*  369 */     this.parameters = parameters;
/*      */     
/*  371 */     boolean returnTypeChanged = !Objects.equals(this.returnType, 
/*  372 */         returnType);
/*  373 */     this.returnType = returnType;
/*      */     
/*  375 */     boolean helpContextIdChanged = !Objects.equals(this.helpContextId, 
/*  376 */         helpContextId);
/*  377 */     this.helpContextId = helpContextId;
/*      */     
/*  379 */     fireCommandChanged(new CommandEvent(this, categoryChanged, 
/*  380 */           definedChanged, descriptionChanged, false, nameChanged, 
/*  381 */           parametersChanged, returnTypeChanged, helpContextIdChanged));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public Object execute(ExecutionEvent event) throws ExecutionException, NotHandledException {
/*  406 */     if (this.shouldFireEvents) {
/*  407 */       firePreExecute(event);
/*      */     }
/*  409 */     IHandler handler = this.handler;
/*      */ 
/*      */     
/*  412 */     if (handler != null && handler.isHandled()) {
/*      */       try {
/*  414 */         Object returnValue = handler.execute(event);
/*  415 */         if (this.shouldFireEvents) {
/*  416 */           firePostExecuteSuccess(returnValue);
/*      */         }
/*  418 */         return returnValue;
/*  419 */       } catch (ExecutionException executionException) {
/*  420 */         if (this.shouldFireEvents) {
/*  421 */           firePostExecuteFailure(executionException);
/*      */         }
/*  423 */         throw executionException;
/*      */       } 
/*      */     }
/*      */     
/*  427 */     NotHandledException e = new NotHandledException("There is no handler to execute. " + getId());
/*  428 */     if (this.shouldFireEvents) {
/*  429 */       fireNotHandled(e);
/*      */     }
/*  431 */     throw e;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object executeWithChecks(ExecutionEvent event) throws ExecutionException, NotDefinedException, NotEnabledException, NotHandledException {
/*  460 */     if (this.shouldFireEvents) {
/*  461 */       firePreExecute(event);
/*      */     }
/*  463 */     IHandler handler = this.handler;
/*      */     
/*  465 */     if (!isDefined()) {
/*  466 */       NotDefinedException exception = new NotDefinedException(
/*  467 */           "Trying to execute a command that is not defined. " + 
/*  468 */           getId());
/*  469 */       if (this.shouldFireEvents) {
/*  470 */         fireNotDefined(exception);
/*      */       }
/*  472 */       throw exception;
/*      */     } 
/*      */ 
/*      */     
/*  476 */     if (handler != null && handler.isHandled()) {
/*  477 */       setEnabled(event.getApplicationContext());
/*  478 */       if (!isEnabled()) {
/*  479 */         NotEnabledException exception = new NotEnabledException(
/*  480 */             "Trying to execute the disabled command " + getId());
/*  481 */         if (this.shouldFireEvents) {
/*  482 */           fireNotEnabled(exception);
/*      */         }
/*  484 */         throw exception;
/*      */       } 
/*      */       
/*      */       try {
/*  488 */         Object returnValue = handler.execute(event);
/*  489 */         if (this.shouldFireEvents) {
/*  490 */           firePostExecuteSuccess(returnValue);
/*      */         }
/*  492 */         return returnValue;
/*  493 */       } catch (ExecutionException executionException) {
/*  494 */         if (this.shouldFireEvents) {
/*  495 */           firePostExecuteFailure(executionException);
/*      */         }
/*  497 */         throw executionException;
/*      */       } 
/*      */     } 
/*      */     
/*  501 */     NotHandledException e = new NotHandledException("There is no handler to execute for command " + getId());
/*  502 */     if (this.shouldFireEvents) {
/*  503 */       fireNotHandled(e);
/*      */     }
/*  505 */     throw e;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void fireCommandChanged(final CommandEvent commandEvent) {
/*  516 */     if (commandEvent == null)
/*  517 */       throw new NullPointerException("Cannot fire a null event");  byte b;
/*      */     int i;
/*      */     Object[] arrayOfObject;
/*  520 */     for (i = (arrayOfObject = getListeners()).length, b = 0; b < i; ) { Object listener = arrayOfObject[b];
/*  521 */       final ICommandListener commandListener = (ICommandListener)listener;
/*  522 */       SafeRunner.run(new ISafeRunnable()
/*      */           {
/*      */             public void handleException(Throwable exception) {}
/*      */ 
/*      */ 
/*      */             
/*      */             public void run() throws Exception {
/*  529 */               commandListener.commandChanged(commandEvent);
/*      */             }
/*      */           });
/*      */       b++; }
/*      */   
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void fireNotDefined(NotDefinedException e) {
/*  546 */     if (DEBUG_COMMAND_EXECUTION) {
/*  547 */       Tracing.printTrace("COMMANDS", "execute >>> not defined: id=" + 
/*  548 */           getId() + "; exception=" + e);
/*      */     }
/*      */     
/*  551 */     if (this.executionListeners != null) {
/*  552 */       for (IExecutionListener object : this.executionListeners) {
/*  553 */         if (object instanceof IExecutionListenerWithChecks) {
/*  554 */           IExecutionListenerWithChecks listener = (IExecutionListenerWithChecks)object;
/*  555 */           listener.notDefined(getId(), e);
/*      */         } 
/*      */       } 
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void fireNotEnabled(NotEnabledException e) {
/*  572 */     if (DEBUG_COMMAND_EXECUTION) {
/*  573 */       Tracing.printTrace("COMMANDS", "execute >>> not enabled: id=" + 
/*  574 */           getId() + "; exception=" + e);
/*      */     }
/*      */     
/*  577 */     if (this.executionListeners != null) {
/*  578 */       for (IExecutionListener object : this.executionListeners) {
/*  579 */         if (object instanceof IExecutionListenerWithChecks) {
/*  580 */           IExecutionListenerWithChecks listener = (IExecutionListenerWithChecks)object;
/*  581 */           listener.notEnabled(getId(), e);
/*      */         } 
/*      */       } 
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void fireNotHandled(NotHandledException e) {
/*  597 */     if (DEBUG_COMMAND_EXECUTION) {
/*  598 */       Tracing.printTrace("COMMANDS", "execute >>> not handled: id=" + 
/*  599 */           getId() + "; exception=" + e);
/*      */     }
/*      */     
/*  602 */     if (this.executionListeners != null) {
/*  603 */       for (IExecutionListener listener : this.executionListeners) {
/*  604 */         listener.notHandled(getId(), e);
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void firePostExecuteFailure(ExecutionException e) {
/*  620 */     if (DEBUG_COMMAND_EXECUTION) {
/*  621 */       Tracing.printTrace("COMMANDS", "execute >>> failure: id=" + 
/*  622 */           getId() + "; exception=" + e);
/*      */     }
/*      */     
/*  625 */     if (this.executionListeners != null) {
/*  626 */       for (IExecutionListener listener : this.executionListeners) {
/*  627 */         listener.postExecuteFailure(getId(), e);
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void firePostExecuteSuccess(Object returnValue) {
/*  641 */     if (DEBUG_COMMAND_EXECUTION) {
/*  642 */       Tracing.printTrace("COMMANDS", "execute >>> success: id=" + 
/*  643 */           getId() + "; returnValue=" + 
/*  644 */           returnValue);
/*      */     }
/*      */     
/*  647 */     if (this.executionListeners != null) {
/*  648 */       for (IExecutionListener listener : this.executionListeners) {
/*  649 */         listener.postExecuteSuccess(getId(), returnValue);
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void firePreExecute(ExecutionEvent event) {
/*  663 */     if (DEBUG_COMMAND_EXECUTION) {
/*  664 */       Tracing.printTrace("COMMANDS", "execute >>> starting: id=" + 
/*  665 */           getId() + "; event=" + event);
/*      */     }
/*      */     
/*  668 */     if (this.executionListeners != null) {
/*  669 */       for (IExecutionListener listener : this.executionListeners) {
/*  670 */         listener.preExecute(getId(), event);
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Category getCategory() throws NotDefinedException {
/*  683 */     if (!isDefined()) {
/*  684 */       throw new NotDefinedException("Cannot get the category from an undefined command. " + 
/*  685 */           this.id);
/*      */     }
/*      */     
/*  688 */     return this.category;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public IHandler getHandler() {
/*  703 */     return this.handler;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   String getHelpContextId() {
/*  716 */     return this.helpContextId;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public IParameter getParameter(String parameterId) throws NotDefinedException {
/*  732 */     if (!isDefined()) {
/*  733 */       throw new NotDefinedException("Cannot get a parameter from an undefined command. " + 
/*  734 */           this.id);
/*      */     }
/*      */     
/*  737 */     if (this.parameters == null)
/*  738 */       return null;  byte b;
/*      */     int i;
/*      */     IParameter[] arrayOfIParameter;
/*  741 */     for (i = (arrayOfIParameter = this.parameters).length, b = 0; b < i; ) { IParameter parameter = arrayOfIParameter[b];
/*  742 */       if (parameter.getId().equals(parameterId)) {
/*  743 */         return parameter;
/*      */       }
/*      */       b++; }
/*      */     
/*  747 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public IParameter[] getParameters() throws NotDefinedException {
/*  760 */     if (!isDefined()) {
/*  761 */       throw new NotDefinedException("Cannot get the parameters from an undefined command. " + 
/*  762 */           this.id);
/*      */     }
/*      */     
/*  765 */     if (this.parameters == null || this.parameters.length == 0) {
/*  766 */       return null;
/*      */     }
/*      */     
/*  769 */     IParameter[] returnValue = new IParameter[this.parameters.length];
/*  770 */     System.arraycopy(this.parameters, 0, returnValue, 0, this.parameters.length);
/*  771 */     return returnValue;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ParameterType getParameterType(String parameterId) throws NotDefinedException {
/*  790 */     IParameter parameter = getParameter(parameterId);
/*  791 */     if (parameter instanceof ITypedParameter) {
/*  792 */       ITypedParameter parameterWithType = (ITypedParameter)parameter;
/*  793 */       return parameterWithType.getParameterType();
/*      */     } 
/*  795 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ParameterType getReturnType() throws NotDefinedException {
/*  811 */     if (!isDefined()) {
/*  812 */       throw new NotDefinedException("Cannot get the return type of an undefined command. " + 
/*  813 */           this.id);
/*      */     }
/*      */     
/*  816 */     return this.returnType;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isEnabled() {
/*  827 */     if (this.handler == null) {
/*  828 */       return false;
/*      */     }
/*      */     
/*      */     try {
/*  832 */       return this.handler.isEnabled();
/*  833 */     } catch (Exception e) {
/*  834 */       if (DEBUG_HANDLERS) {
/*      */ 
/*      */         
/*  837 */         Tracing.printTrace("HANDLERS", "Handler " + this.handler + " for " + 
/*  838 */             this.id + " threw unexpected exception");
/*  839 */         e.printStackTrace(System.out);
/*      */       } 
/*      */       
/*  842 */       return false;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setEnabled(Object evaluationContext) {
/*  855 */     if (this.handler instanceof IHandler2) {
/*  856 */       ((IHandler2)this.handler).setEnabled(evaluationContext);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isHandled() {
/*  868 */     if (this.handler == null) {
/*  869 */       return false;
/*      */     }
/*      */     
/*  872 */     return this.handler.isHandled();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void removeCommandListener(ICommandListener commandListener) {
/*  883 */     if (commandListener == null) {
/*  884 */       throw new NullPointerException("Cannot remove a null command listener");
/*      */     }
/*      */     
/*  887 */     removeListenerObject(commandListener);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void removeExecutionListener(IExecutionListener executionListener) {
/*  898 */     if (executionListener == null) {
/*  899 */       throw new NullPointerException("Cannot remove a null execution listener");
/*      */     }
/*      */     
/*  902 */     if (this.executionListeners != null) {
/*  903 */       this.executionListeners.remove(executionListener);
/*  904 */       if (this.executionListeners.isEmpty()) {
/*  905 */         this.executionListeners = null;
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void removeState(String stateId) {
/*  924 */     if (this.handler instanceof IObjectWithState) {
/*  925 */       ((IObjectWithState)this.handler).removeState(stateId);
/*      */     }
/*  927 */     super.removeState(stateId);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean setHandler(IHandler handler) {
/*  942 */     if (Objects.equals(handler, this.handler)) {
/*  943 */       return false;
/*      */     }
/*      */ 
/*      */     
/*  947 */     String[] stateIds = getStateIds();
/*  948 */     if (stateIds != null) {
/*  949 */       byte b; int i; String[] arrayOfString; for (i = (arrayOfString = stateIds).length, b = 0; b < i; ) { String stateId = arrayOfString[b];
/*  950 */         if (this.handler instanceof IObjectWithState) {
/*  951 */           ((IObjectWithState)this.handler).removeState(stateId);
/*      */         }
/*  953 */         if (handler instanceof IObjectWithState) {
/*  954 */           State stateToAdd = getState(stateId);
/*  955 */           ((IObjectWithState)handler).addState(stateId, stateToAdd);
/*      */         } 
/*      */         b++; }
/*      */     
/*      */     } 
/*  960 */     boolean enabled = isEnabled();
/*  961 */     if (this.handler != null) {
/*  962 */       this.handler.removeHandlerListener(getHandlerListener());
/*      */     }
/*      */ 
/*      */     
/*  966 */     this.handler = handler;
/*  967 */     if (this.handler != null) {
/*  968 */       this.handler.addHandlerListener(getHandlerListener());
/*      */     }
/*  970 */     this.string = null;
/*      */ 
/*      */     
/*  973 */     if (DEBUG_HANDLERS && (DEBUG_HANDLERS_COMMAND_ID == null || DEBUG_HANDLERS_COMMAND_ID.equals(this.id))) {
/*  974 */       StringBuilder buffer = new StringBuilder("Command('");
/*  975 */       buffer.append(this.id);
/*  976 */       buffer.append("') has changed to ");
/*  977 */       if (handler == null) {
/*  978 */         buffer.append("no handler");
/*      */       } else {
/*  980 */         buffer.append('\'');
/*  981 */         buffer.append(handler);
/*  982 */         buffer.append("' as its handler");
/*      */       } 
/*  984 */       Tracing.printTrace("HANDLERS", buffer.toString());
/*      */     } 
/*      */ 
/*      */     
/*  988 */     fireCommandChanged(new CommandEvent(this, false, false, false, true, 
/*  989 */           false, false, false, false, enabled ^ isEnabled()));
/*      */     
/*  991 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private IHandlerListener getHandlerListener() {
/*  998 */     if (this.handlerListener == null) {
/*  999 */       this.handlerListener = (handlerEvent -> {
/*      */           boolean enabledChanged = handlerEvent.isEnabledChanged();
/*      */           
/*      */           boolean handledChanged = handlerEvent.isHandledChanged();
/*      */           
/*      */           fireCommandChanged(new CommandEvent(this, false, false, false, handledChanged, false, false, false, false, enabledChanged));
/*      */         });
/*      */     }
/* 1007 */     return this.handlerListener;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String toString() {
/* 1018 */     if (this.string == null) {
/* 1019 */       String lineSeparator = System.lineSeparator();
/* 1020 */       StringBuilder builder = new StringBuilder();
/* 1021 */       builder.append("Command(");
/* 1022 */       builder.append(this.id);
/* 1023 */       builder.append(',');
/* 1024 */       builder.append((this.name == null) ? "" : this.name);
/* 1025 */       builder.append(',');
/* 1026 */       builder.append(lineSeparator);
/* 1027 */       builder.append("\t\t");
/* 1028 */       builder.append((this.description == null) ? "" : this.description);
/* 1029 */       builder.append(',');
/* 1030 */       builder.append(lineSeparator);
/* 1031 */       builder.append("\t\t");
/* 1032 */       builder.append((this.category == null) ? "" : this.category.toString());
/* 1033 */       builder.append(',');
/* 1034 */       builder.append(lineSeparator);
/* 1035 */       builder.append("\t\t");
/* 1036 */       builder.append((this.handler == null) ? "" : this.handler.toString());
/* 1037 */       builder.append(',');
/* 1038 */       builder.append(lineSeparator);
/* 1039 */       builder.append("\t\t");
/* 1040 */       builder.append((this.parameters == null) ? "" : Arrays.toString((Object[])this.parameters));
/* 1041 */       builder.append(',');
/* 1042 */       builder.append((this.returnType == null) ? "" : this.returnType.toString());
/* 1043 */       builder.append(',');
/* 1044 */       builder.append(this.defined);
/* 1045 */       builder.append(')');
/* 1046 */       this.string = builder.toString();
/*      */     } 
/* 1048 */     return this.string;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void undefine() {
/* 1058 */     boolean enabledChanged = isEnabled();
/*      */     
/* 1060 */     this.string = null;
/*      */     
/* 1062 */     boolean definedChanged = this.defined;
/* 1063 */     this.defined = false;
/*      */     
/* 1065 */     boolean nameChanged = (this.name != null);
/* 1066 */     this.name = null;
/*      */     
/* 1068 */     boolean descriptionChanged = (this.description != null);
/* 1069 */     this.description = null;
/*      */     
/* 1071 */     boolean categoryChanged = (this.category != null);
/* 1072 */     this.category = null;
/*      */     
/* 1074 */     boolean parametersChanged = (this.parameters != null);
/* 1075 */     this.parameters = null;
/*      */     
/* 1077 */     boolean returnTypeChanged = (this.returnType != null);
/* 1078 */     this.returnType = null;
/*      */     
/* 1080 */     String[] stateIds = getStateIds();
/* 1081 */     if (stateIds != null) {
/* 1082 */       if (this.handler instanceof IObjectWithState) {
/* 1083 */         IObjectWithState handlerWithState = (IObjectWithState)this.handler; byte b; int i; String[] arrayOfString;
/* 1084 */         for (i = (arrayOfString = stateIds).length, b = 0; b < i; ) { String stateId = arrayOfString[b];
/* 1085 */           handlerWithState.removeState(stateId);
/*      */           
/* 1087 */           State state = getState(stateId);
/* 1088 */           removeState(stateId);
/* 1089 */           state.dispose(); b++; }
/*      */       
/*      */       } else {
/* 1092 */         byte b; int i; String[] arrayOfString; for (i = (arrayOfString = stateIds).length, b = 0; b < i; ) { String stateId = arrayOfString[b];
/* 1093 */           State state = getState(stateId);
/* 1094 */           removeState(stateId);
/* 1095 */           state.dispose();
/*      */           b++; }
/*      */       
/*      */       } 
/*      */     }
/* 1100 */     fireCommandChanged(new CommandEvent(this, categoryChanged, 
/* 1101 */           definedChanged, descriptionChanged, false, nameChanged, 
/* 1102 */           parametersChanged, returnTypeChanged, false, enabledChanged));
/*      */   }
/*      */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.commands-3.11.0.jar!\org\eclipse\core\commands\Command.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */