/*     */ package org.eclipse.core.commands;
/*     */ 
/*     */ import org.eclipse.core.commands.common.EventManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractHandler
/*     */   extends EventManager
/*     */   implements IHandler2
/*     */ {
/*     */   private boolean baseEnabled = true;
/*     */   
/*     */   public void addHandlerListener(IHandlerListener handlerListener) {
/*  42 */     addListenerObject(handlerListener);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void dispose() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void fireHandlerChanged(HandlerEvent handlerEvent) {
/*  71 */     if (handlerEvent == null)
/*  72 */       throw new NullPointerException();  byte b;
/*     */     int i;
/*     */     Object[] arrayOfObject;
/*  75 */     for (i = (arrayOfObject = getListeners()).length, b = 0; b < i; ) { Object listener = arrayOfObject[b];
/*  76 */       IHandlerListener handlerListener = (IHandlerListener)listener;
/*  77 */       handlerListener.handlerChanged(handlerEvent);
/*     */       b++; }
/*     */   
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isEnabled() {
/*  93 */     return this.baseEnabled;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void setBaseEnabled(boolean state) {
/* 107 */     if (this.baseEnabled == state) {
/*     */       return;
/*     */     }
/* 110 */     this.baseEnabled = state;
/* 111 */     fireHandlerChanged(new HandlerEvent(this, true, false));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setEnabled(Object evaluationContext) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isHandled() {
/* 137 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean hasListeners() {
/* 158 */     return isListenerAttached();
/*     */   }
/*     */ 
/*     */   
/*     */   public void removeHandlerListener(IHandlerListener handlerListener) {
/* 163 */     removeListenerObject(handlerListener);
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.commands-3.11.0.jar!\org\eclipse\core\commands\AbstractHandler.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */