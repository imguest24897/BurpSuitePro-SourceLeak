package org.osgi.service.prefs;

public interface Preferences {
  void put(String paramString1, String paramString2);
  
  String get(String paramString1, String paramString2);
  
  void remove(String paramString);
  
  void clear() throws BackingStoreException;
  
  void putInt(String paramString, int paramInt);
  
  int getInt(String paramString, int paramInt);
  
  void putLong(String paramString, long paramLong);
  
  long getLong(String paramString, long paramLong);
  
  void putBoolean(String paramString, boolean paramBoolean);
  
  boolean getBoolean(String paramString, boolean paramBoolean);
  
  void putFloat(String paramString, float paramFloat);
  
  float getFloat(String paramString, float paramFloat);
  
  void putDouble(String paramString, double paramDouble);
  
  double getDouble(String paramString, double paramDouble);
  
  void putByteArray(String paramString, byte[] paramArrayOfbyte);
  
  byte[] getByteArray(String paramString, byte[] paramArrayOfbyte);
  
  String[] keys() throws BackingStoreException;
  
  String[] childrenNames() throws BackingStoreException;
  
  Preferences parent();
  
  Preferences node(String paramString);
  
  boolean nodeExists(String paramString) throws BackingStoreException;
  
  void removeNode() throws BackingStoreException;
  
  String name();
  
  String absolutePath();
  
  void flush() throws BackingStoreException;
  
  void sync() throws BackingStoreException;
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.osgi.service.prefs-1.1.2.jar!\org\osgi\service\prefs\Preferences.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */