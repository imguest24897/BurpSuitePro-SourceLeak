package org.osgi.service.prefs;

public interface PreferencesService {
  Preferences getSystemPreferences();
  
  Preferences getUserPreferences(String paramString);
  
  String[] getUsers();
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.osgi.service.prefs-1.1.2.jar!\org\osgi\service\prefs\PreferencesService.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */