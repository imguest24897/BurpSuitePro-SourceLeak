package org.osgi.service.prefs;

import org.osgi.annotation.versioning.Version;



/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.osgi.service.prefs-1.1.2.jar!\org\osgi\service\prefs\package-info.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */