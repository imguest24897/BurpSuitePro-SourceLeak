/*    */ package org.eclipse.debug.internal.core.groups;
/*    */ 
/*    */ import java.util.List;
/*    */ import org.eclipse.core.runtime.CoreException;
/*    */ import org.eclipse.debug.core.DebugPlugin;
/*    */ import org.eclipse.debug.core.ILaunchConfiguration;
/*    */ import org.eclipse.debug.core.ILaunchConfigurationListener;
/*    */ import org.eclipse.debug.core.ILaunchConfigurationType;
/*    */ import org.eclipse.debug.core.ILaunchConfigurationWorkingCopy;
/*    */ import org.eclipse.debug.core.ILaunchManager;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class GroupMemberChangeListener
/*    */   implements ILaunchConfigurationListener
/*    */ {
/*    */   private static final String GROUP_TYPE_ID = "org.eclipse.debug.core.groups.GroupLaunchConfigurationType";
/*    */   
/*    */   public void launchConfigurationAdded(ILaunchConfiguration configuration) {
/* 38 */     ILaunchManager launchManager = DebugPlugin.getDefault().getLaunchManager();
/* 39 */     ILaunchConfiguration original = launchManager.getMovedFrom(configuration);
/* 40 */     if (original != null) {
/* 41 */       ILaunchConfigurationType type = launchManager.getLaunchConfigurationType("org.eclipse.debug.core.groups.GroupLaunchConfigurationType");
/* 42 */       if (type == null) {
/* 43 */         DebugPlugin.logMessage("cannot find group launch configuration type", null); return;
/*    */       }  try {
/*    */         byte b; int i;
/*    */         ILaunchConfiguration[] arrayOfILaunchConfiguration;
/* 47 */         for (i = (arrayOfILaunchConfiguration = DebugPlugin.getDefault().getLaunchManager().getLaunchConfigurations(type, 3)).length, b = 0; b < i; ) { ILaunchConfiguration c = arrayOfILaunchConfiguration[b];
/* 48 */           List<GroupLaunchElement> elements = GroupLaunchConfigurationDelegate.createLaunchElements(c);
/* 49 */           boolean updated = false;
/* 50 */           for (GroupLaunchElement e : elements) {
/* 51 */             if (e.name.equals(original.getName())) {
/* 52 */               updated = true;
/* 53 */               e.name = configuration.getName();
/*    */             } 
/*    */           } 
/*    */           
/* 57 */           if (updated) {
/* 58 */             ILaunchConfigurationWorkingCopy workingCopy = c.getWorkingCopy();
/* 59 */             GroupLaunchConfigurationDelegate.storeLaunchElements(workingCopy, elements);
/* 60 */             workingCopy.doSave();
/*    */           }  b++; }
/*    */       
/* 63 */       } catch (CoreException e) {
/* 64 */         DebugPlugin.log((Throwable)e);
/*    */       } 
/*    */     } 
/*    */   }
/*    */   
/*    */   public void launchConfigurationChanged(ILaunchConfiguration configuration) {}
/*    */   
/*    */   public void launchConfigurationRemoved(ILaunchConfiguration configuration) {}
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.debug.core-3.21.0.jar!\org\eclipse\debug\internal\core\groups\GroupMemberChangeListener.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */