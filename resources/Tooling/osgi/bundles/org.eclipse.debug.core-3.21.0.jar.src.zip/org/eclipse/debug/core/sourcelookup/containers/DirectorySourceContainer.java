/*     */ package org.eclipse.debug.core.sourcelookup.containers;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import org.eclipse.core.runtime.CoreException;
/*     */ import org.eclipse.core.runtime.IPath;
/*     */ import org.eclipse.debug.core.DebugPlugin;
/*     */ import org.eclipse.debug.core.sourcelookup.ISourceContainer;
/*     */ import org.eclipse.debug.core.sourcelookup.ISourceContainerType;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DirectorySourceContainer
/*     */   extends CompositeSourceContainer
/*     */ {
/*     */   private File fDirectory;
/*     */   private boolean fSubfolders = false;
/*  48 */   public static final String TYPE_ID = String.valueOf(DebugPlugin.getUniqueIdentifier()) + ".containerType.directory";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DirectorySourceContainer(IPath dirPath, boolean subfolders) {
/*  59 */     this(dirPath.toFile(), subfolders);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DirectorySourceContainer(File dir, boolean subfolders) {
/*  71 */     this.fDirectory = dir;
/*  72 */     this.fSubfolders = subfolders;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getName() {
/*  77 */     return this.fDirectory.getName();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public File getDirectory() {
/*  88 */     return this.fDirectory;
/*     */   }
/*     */ 
/*     */   
/*     */   public ISourceContainerType getType() {
/*  93 */     return getSourceContainerType(TYPE_ID);
/*     */   }
/*     */ 
/*     */   
/*     */   public Object[] findSourceElements(String name) throws CoreException {
/*  98 */     ArrayList<Object> sources = new ArrayList();
/*  99 */     File directory = getDirectory();
/* 100 */     File file = new File(directory, name);
/* 101 */     if (file.exists() && file.isFile()) {
/* 102 */       sources.add(new LocalFileStorage(file));
/*     */     }
/*     */ 
/*     */     
/* 106 */     if ((isFindDuplicates() && this.fSubfolders) || (sources.isEmpty() && this.fSubfolders)) {
/* 107 */       ISourceContainer[] containers = getSourceContainers(); byte b; int i; ISourceContainer[] arrayOfISourceContainer1;
/* 108 */       for (i = (arrayOfISourceContainer1 = containers).length, b = 0; b < i; ) { ISourceContainer container = arrayOfISourceContainer1[b];
/* 109 */         Object[] objects = container.findSourceElements(name);
/* 110 */         if (objects != null && objects.length != 0)
/*     */         {
/*     */           
/* 113 */           if (isFindDuplicates()) {
/* 114 */             Collections.addAll(sources, objects);
/*     */           } else {
/* 116 */             sources.add(objects[0]);
/*     */             break;
/*     */           }  } 
/*     */         b++; }
/*     */     
/*     */     } 
/* 122 */     if (sources.isEmpty()) {
/* 123 */       return EMPTY;
/*     */     }
/* 125 */     return sources.toArray();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isComposite() {
/* 130 */     return this.fSubfolders;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object obj) {
/* 135 */     if (obj instanceof DirectorySourceContainer) {
/* 136 */       DirectorySourceContainer container = (DirectorySourceContainer)obj;
/* 137 */       return container.getDirectory().equals(getDirectory());
/*     */     } 
/* 139 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 144 */     return getDirectory().hashCode();
/*     */   }
/*     */ 
/*     */   
/*     */   protected ISourceContainer[] createSourceContainers() throws CoreException {
/* 149 */     if (isComposite()) {
/* 150 */       String[] files = this.fDirectory.list();
/* 151 */       if (files != null) {
/* 152 */         List<ISourceContainer> dirs = new ArrayList<>(); byte b; int i; String[] arrayOfString;
/* 153 */         for (i = (arrayOfString = files).length, b = 0; b < i; ) { String name = arrayOfString[b];
/* 154 */           File file = new File(getDirectory(), name);
/* 155 */           if (file.exists() && file.isDirectory())
/* 156 */             dirs.add(new DirectorySourceContainer(file, true)); 
/*     */           b++; }
/*     */         
/* 159 */         ISourceContainer[] containers = dirs.<ISourceContainer>toArray(new ISourceContainer[dirs.size()]); ISourceContainer[] arrayOfISourceContainer1;
/* 160 */         for (int j = (arrayOfISourceContainer1 = containers).length; i < j; ) { ISourceContainer container = arrayOfISourceContainer1[i];
/* 161 */           container.init(getDirector()); i++; }
/*     */         
/* 163 */         return containers;
/*     */       } 
/*     */     } 
/* 166 */     return new ISourceContainer[0];
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.debug.core-3.21.0.jar!\org\eclipse\debug\core\sourcelookup\containers\DirectorySourceContainer.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */