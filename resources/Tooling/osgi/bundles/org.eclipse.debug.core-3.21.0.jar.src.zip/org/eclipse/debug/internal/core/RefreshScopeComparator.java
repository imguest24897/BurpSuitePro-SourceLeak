/*    */ package org.eclipse.debug.internal.core;
/*    */ 
/*    */ import java.util.Arrays;
/*    */ import java.util.Comparator;
/*    */ import org.eclipse.core.resources.IResource;
/*    */ import org.eclipse.core.runtime.CoreException;
/*    */ import org.eclipse.debug.core.RefreshUtil;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RefreshScopeComparator
/*    */   implements Comparator<String>
/*    */ {
/*    */   private static final Comparator<IResource> RESOURCE;
/*    */   private static final Comparator<IResource[]> ARRAY;
/*    */   private static final Comparator<String> MEMENTO;
/*    */   
/*    */   private static IResource[] toResources(String memento) {
/*    */     try {
/* 33 */       return RefreshUtil.toResources(memento);
/* 34 */     } catch (CoreException coreException) {
/* 35 */       return null;
/*    */     } 
/*    */   }
/*    */   static {
/* 39 */     RESOURCE = Comparator.nullsFirst(Comparator.comparing(r -> r.toString()));
/* 40 */     ARRAY = Comparator.nullsFirst((s1, s2) -> Arrays.compare(s1, s2, RESOURCE));
/* 41 */     MEMENTO = Comparator.nullsFirst(Comparator.comparing(m -> toResources(m), (Comparator)ARRAY));
/*    */   }
/*    */   
/*    */   public int compare(String o1, String o2) {
/* 45 */     return MEMENTO.compare(o1, o2);
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.debug.core-3.21.0.jar!\org\eclipse\debug\internal\core\RefreshScopeComparator.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */