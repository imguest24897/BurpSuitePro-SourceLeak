package org.eclipse.debug.core.model;

import org.eclipse.debug.core.DebugException;

public interface IStep {
  boolean canStepInto();
  
  boolean canStepOver();
  
  boolean canStepReturn();
  
  boolean isStepping();
  
  void stepInto() throws DebugException;
  
  void stepOver() throws DebugException;
  
  void stepReturn() throws DebugException;
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.debug.core-3.21.0.jar!\org\eclipse\debug\core\model\IStep.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */