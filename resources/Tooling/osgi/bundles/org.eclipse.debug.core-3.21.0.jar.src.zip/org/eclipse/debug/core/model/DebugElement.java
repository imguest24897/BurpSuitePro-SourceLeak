/*     */ package org.eclipse.debug.core.model;
/*     */ 
/*     */ import org.eclipse.core.runtime.PlatformObject;
/*     */ import org.eclipse.core.runtime.Status;
/*     */ import org.eclipse.debug.core.DebugEvent;
/*     */ import org.eclipse.debug.core.DebugException;
/*     */ import org.eclipse.debug.core.DebugPlugin;
/*     */ import org.eclipse.debug.core.ILaunch;
/*     */ import org.eclipse.debug.core.ILaunchConfiguration;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class DebugElement
/*     */   extends PlatformObject
/*     */   implements IDebugElement
/*     */ {
/*     */   private IDebugTarget fTarget;
/*     */   
/*     */   public DebugElement(IDebugTarget target) {
/*  43 */     this.fTarget = target;
/*     */   }
/*     */ 
/*     */   
/*     */   public IDebugTarget getDebugTarget() {
/*  48 */     return this.fTarget;
/*     */   }
/*     */ 
/*     */   
/*     */   public ILaunch getLaunch() {
/*  53 */     return getDebugTarget().getLaunch();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public <T> T getAdapter(Class<T> adapter) {
/*  59 */     if (adapter == IDebugElement.class) {
/*  60 */       return (T)this;
/*     */     }
/*     */ 
/*     */     
/*  64 */     if (adapter == IStepFilters.class && 
/*  65 */       getDebugTarget() instanceof IStepFilters) {
/*  66 */       return (T)getDebugTarget();
/*     */     }
/*     */     
/*  69 */     if (adapter == IDebugTarget.class) {
/*  70 */       return (T)getDebugTarget();
/*     */     }
/*  72 */     if (adapter == ILaunch.class) {
/*  73 */       return (T)getLaunch();
/*     */     }
/*  75 */     if (adapter == IProcess.class) {
/*  76 */       return (T)getDebugTarget().getProcess();
/*     */     }
/*     */     
/*  79 */     if (adapter == ILaunchConfiguration.class) {
/*  80 */       return (T)getLaunch().getLaunchConfiguration();
/*     */     }
/*  82 */     return (T)super.getAdapter(adapter);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void fireEvent(DebugEvent event) {
/*  91 */     DebugPlugin.getDefault().fireDebugEventSet(new DebugEvent[] { event });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void fireChangeEvent(int detail) {
/* 102 */     fireEvent(new DebugEvent(this, 16, detail));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void fireCreationEvent() {
/* 109 */     fireEvent(new DebugEvent(this, 4));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void fireResumeEvent(int detail) {
/* 120 */     fireEvent(new DebugEvent(this, 1, detail));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void fireSuspendEvent(int detail) {
/* 131 */     fireEvent(new DebugEvent(this, 2, detail));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void fireTerminateEvent() {
/* 138 */     fireEvent(new DebugEvent(this, 8));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void requestFailed(String message, Throwable e) throws DebugException {
/* 149 */     throw new DebugException(new Status(4, DebugPlugin.getUniqueIdentifier(), 
/* 150 */           5010, message, e));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void notSupported(String message, Throwable e) throws DebugException {
/* 161 */     throw new DebugException(new Status(4, DebugPlugin.getUniqueIdentifier(), 
/* 162 */           5011, message, e));
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.debug.core-3.21.0.jar!\org\eclipse\debug\core\model\DebugElement.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */