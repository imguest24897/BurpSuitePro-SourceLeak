package org.eclipse.debug.core;

import org.eclipse.debug.core.model.IDebugTarget;
import org.eclipse.debug.core.model.IMemoryBlock;
import org.eclipse.debug.core.model.IMemoryBlockRetrieval;

public interface IMemoryBlockManager {
  void addMemoryBlocks(IMemoryBlock[] paramArrayOfIMemoryBlock);
  
  void removeMemoryBlocks(IMemoryBlock[] paramArrayOfIMemoryBlock);
  
  void addListener(IMemoryBlockListener paramIMemoryBlockListener);
  
  void removeListener(IMemoryBlockListener paramIMemoryBlockListener);
  
  IMemoryBlock[] getMemoryBlocks();
  
  IMemoryBlock[] getMemoryBlocks(IDebugTarget paramIDebugTarget);
  
  IMemoryBlock[] getMemoryBlocks(IMemoryBlockRetrieval paramIMemoryBlockRetrieval);
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.debug.core-3.21.0.jar!\org\eclipse\debug\core\IMemoryBlockManager.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */