/*      */ package org.eclipse.debug.internal.core;
/*      */ 
/*      */ import java.io.IOException;
/*      */ import java.text.MessageFormat;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Arrays;
/*      */ import java.util.Collections;
/*      */ import java.util.Comparator;
/*      */ import java.util.HashMap;
/*      */ import java.util.HashSet;
/*      */ import java.util.Iterator;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.Set;
/*      */ import java.util.TreeMap;
/*      */ import java.util.stream.Collectors;
/*      */ import javax.xml.parsers.ParserConfigurationException;
/*      */ import javax.xml.transform.TransformerException;
/*      */ import org.eclipse.core.runtime.CoreException;
/*      */ import org.eclipse.core.runtime.IStatus;
/*      */ import org.eclipse.core.runtime.Status;
/*      */ import org.eclipse.debug.core.DebugException;
/*      */ import org.eclipse.debug.core.DebugPlugin;
/*      */ import org.eclipse.debug.core.ILaunchConfiguration;
/*      */ import org.eclipse.debug.core.ILaunchConfigurationType;
/*      */ import org.w3c.dom.Document;
/*      */ import org.w3c.dom.Element;
/*      */ import org.w3c.dom.Node;
/*      */ import org.w3c.dom.NodeList;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class LaunchConfigurationInfo
/*      */ {
/*      */   private static final String KEY = "key";
/*      */   private static final String VALUE = "value";
/*      */   private static final String SET_ENTRY = "setEntry";
/*      */   private static final String LAUNCH_CONFIGURATION = "launchConfiguration";
/*      */   private static final String MAP_ENTRY = "mapEntry";
/*      */   private static final String LIST_ENTRY = "listEntry";
/*      */   private static final String SET_ATTRIBUTE = "setAttribute";
/*      */   private static final String MAP_ATTRIBUTE = "mapAttribute";
/*      */   private static final String LIST_ATTRIBUTE = "listAttribute";
/*      */   private static final String BOOLEAN_ATTRIBUTE = "booleanAttribute";
/*      */   private static final String INT_ATTRIBUTE = "intAttribute";
/*      */   private static final String STRING_ATTRIBUTE = "stringAttribute";
/*      */   private static final String TYPE = "type";
/*      */   private static final String PROTOTYPE = "prototype";
/*      */   private static final String VISIBLE_ATTRIBUTES = "visibleAttributes";
/*      */   private TreeMap<String, Object> fAttributes;
/*      */   private ILaunchConfigurationType fType;
/*      */   private boolean fIsPrototype = false;
/*      */   private ILaunchConfiguration fPrototype;
/*      */   private Set<String> fVisibleAttributes;
/*  104 */   private static LaunchManager fgLaunchManager = (LaunchManager)DebugPlugin.getDefault().getLaunchManager();
/*      */ 
/*      */   
/*      */   private static boolean fgIsSun14x = false;
/*      */ 
/*      */ 
/*      */   
/*      */   static {
/*  112 */     String vendor = System.getProperty("java.vm.vendor");
/*  113 */     if (vendor.startsWith("Sun Microsystems")) {
/*  114 */       String version = System.getProperty("java.vm.version");
/*  115 */       if (version.startsWith("1.4")) {
/*  116 */         fgIsSun14x = true;
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected LaunchConfigurationInfo() {
/*  125 */     setAttributeTable(new TreeMap<>());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private TreeMap<String, Object> getAttributeTable() {
/*  134 */     return this.fAttributes;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void setAttributeTable(TreeMap<String, Object> table) {
/*  144 */     this.fAttributes = table;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void setAttributes(Map<String, ?> map) {
/*  153 */     if (map == null) {
/*  154 */       setAttributeTable(new TreeMap<>());
/*      */       return;
/*      */     } 
/*  157 */     setAttributeTable(new TreeMap<>(map));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected String getStringAttribute(String key, String defaultValue) throws CoreException {
/*  172 */     Object attr = getAttributeTable().get(key);
/*  173 */     if (attr != null) {
/*  174 */       if (attr instanceof String) {
/*  175 */         return (String)attr;
/*      */       }
/*  177 */       throw new DebugException(
/*  178 */           new Status(
/*  179 */             4, DebugPlugin.getUniqueIdentifier(), 
/*  180 */             5012, MessageFormat.format(DebugCoreMessages.LaunchConfigurationInfo_Attribute__0__is_not_of_type_java_lang_String__1, new Object[] { key }), null));
/*      */     } 
/*      */ 
/*      */     
/*  184 */     return defaultValue;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected int getIntAttribute(String key, int defaultValue) throws CoreException {
/*  199 */     Object attr = getAttributeTable().get(key);
/*  200 */     if (attr != null) {
/*  201 */       if (attr instanceof Integer) {
/*  202 */         return ((Integer)attr).intValue();
/*      */       }
/*  204 */       throw new DebugException(
/*  205 */           new Status(
/*  206 */             4, DebugPlugin.getUniqueIdentifier(), 
/*  207 */             5012, MessageFormat.format(DebugCoreMessages.LaunchConfigurationInfo_Attribute__0__is_not_of_type_int__2, new Object[] { key }), null));
/*      */     } 
/*      */ 
/*      */     
/*  211 */     return defaultValue;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean getBooleanAttribute(String key, boolean defaultValue) throws CoreException {
/*  226 */     Object attr = getAttributeTable().get(key);
/*  227 */     if (attr != null) {
/*  228 */       if (attr instanceof Boolean) {
/*  229 */         return ((Boolean)attr).booleanValue();
/*      */       }
/*  231 */       throw new DebugException(
/*  232 */           new Status(
/*  233 */             4, DebugPlugin.getUniqueIdentifier(), 
/*  234 */             5012, MessageFormat.format(DebugCoreMessages.LaunchConfigurationInfo_Attribute__0__is_not_of_type_boolean__3, new Object[] { key }), null));
/*      */     } 
/*      */ 
/*      */     
/*  238 */     return defaultValue;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected List<String> getListAttribute(String key, List<String> defaultValue) throws CoreException {
/*  254 */     Object attr = getAttributeTable().get(key);
/*  255 */     if (attr != null) {
/*  256 */       if (attr instanceof List) {
/*  257 */         return (List<String>)attr;
/*      */       }
/*  259 */       throw new DebugException(
/*  260 */           new Status(
/*  261 */             4, DebugPlugin.getUniqueIdentifier(), 
/*  262 */             5012, MessageFormat.format(DebugCoreMessages.LaunchConfigurationInfo_Attribute__0__is_not_of_type_java_util_List__1, new Object[] { key }), null));
/*      */     } 
/*      */ 
/*      */     
/*  266 */     return defaultValue;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected Set<String> getSetAttribute(String key, Set<String> defaultValue) throws CoreException {
/*  285 */     Object attr = getAttributeTable().get(key);
/*  286 */     if (attr != null) {
/*  287 */       if (attr instanceof Set) {
/*  288 */         return (Set<String>)attr;
/*      */       }
/*  290 */       throw new DebugException(
/*  291 */           new Status(
/*  292 */             4, DebugPlugin.getUniqueIdentifier(), 
/*  293 */             5012, MessageFormat.format(DebugCoreMessages.LaunchConfigurationInfo_35, new Object[] { key }), null));
/*      */     } 
/*      */ 
/*      */     
/*  297 */     return defaultValue;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected Object getObjectAttribute(String key) {
/*  309 */     return getAttributeTable().get(key);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected Map<String, String> getMapAttribute(String key, Map<String, String> defaultValue) throws CoreException {
/*  325 */     Object attr = getAttributeTable().get(key);
/*  326 */     if (attr != null) {
/*  327 */       if (attr instanceof Map) {
/*  328 */         return (Map<String, String>)attr;
/*      */       }
/*  330 */       throw new DebugException(
/*  331 */           new Status(
/*  332 */             4, DebugPlugin.getUniqueIdentifier(), 
/*  333 */             5012, MessageFormat.format(DebugCoreMessages.LaunchConfigurationInfo_Attribute__0__is_not_of_type_java_util_Map__1, new Object[] { key }), null));
/*      */     } 
/*      */ 
/*      */     
/*  337 */     return defaultValue;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void setType(ILaunchConfigurationType type) {
/*  347 */     this.fType = type;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected ILaunchConfigurationType getType() {
/*  356 */     return this.fType;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void setPrototype(ILaunchConfiguration prototype) {
/*  368 */     this.fPrototype = prototype;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected ILaunchConfiguration getPrototype() {
/*  379 */     return this.fPrototype;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected LaunchConfigurationInfo getCopy() {
/*  388 */     LaunchConfigurationInfo copy = new LaunchConfigurationInfo();
/*  389 */     copy.setType(getType());
/*  390 */     copy.setAttributeTable(getAttributes());
/*  391 */     copy.setIsPrototype(isPrototype());
/*  392 */     copy.setPrototype(getPrototype());
/*  393 */     copy.setVisibleAttributes(getVisibleAttributes());
/*  394 */     return copy;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected TreeMap<String, Object> getAttributes() {
/*  403 */     return new TreeMap<>(getAttributeTable());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void setAttribute(String key, Object value) {
/*  416 */     if (value == null) {
/*  417 */       getAttributeTable().remove(key);
/*  418 */       setAttributeVisibility(key, false);
/*      */     } else {
/*  420 */       Object attribute = getAttributeTable().put(key, value);
/*      */ 
/*      */       
/*  423 */       if (attribute == null && this.fIsPrototype) {
/*  424 */         setAttributeVisibility(key, true);
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected String getAsXML(String lineDelimeter) throws CoreException, IOException, ParserConfigurationException, TransformerException {
/*  444 */     Document doc = LaunchManager.getDocument();
/*  445 */     Element configRootElement = doc.createElement("launchConfiguration");
/*  446 */     doc.appendChild(configRootElement);
/*      */     
/*  448 */     configRootElement.setAttribute("type", getType().getIdentifier());
/*      */     
/*  450 */     ILaunchConfiguration prototype = getPrototype();
/*  451 */     if (prototype != null) {
/*  452 */       configRootElement.setAttribute("prototype", prototype.getName());
/*  453 */     } else if (isPrototype()) {
/*  454 */       configRootElement.setAttribute("visibleAttributes", getVisibleAttributes().stream().collect(Collectors.joining(", ")));
/*      */     } 
/*      */     
/*  457 */     for (String key : getAttributeTable().keySet()) {
/*  458 */       if (key == null) {
/*  459 */         throw new DebugException(
/*  460 */             new Status(
/*  461 */               4, DebugPlugin.getUniqueIdentifier(), 
/*  462 */               5012, DebugCoreMessages.LaunchConfigurationInfo_36, null));
/*      */       }
/*      */ 
/*      */       
/*  466 */       Object value = getAttributeTable().get(key);
/*  467 */       if (value == null) {
/*      */         continue;
/*      */       }
/*  470 */       Element element = null;
/*  471 */       String valueString = null;
/*  472 */       if (value instanceof String) {
/*  473 */         valueString = (String)value;
/*  474 */         element = createKeyValueElement(doc, "stringAttribute", key, valueString);
/*  475 */       } else if (value instanceof Integer) {
/*  476 */         valueString = ((Integer)value).toString();
/*  477 */         element = createKeyValueElement(doc, "intAttribute", key, valueString);
/*  478 */       } else if (value instanceof Boolean) {
/*  479 */         valueString = ((Boolean)value).toString();
/*  480 */         element = createKeyValueElement(doc, "booleanAttribute", key, valueString);
/*  481 */       } else if (value instanceof List) {
/*  482 */         element = createListElement(doc, "listAttribute", key, (List<String>)value);
/*  483 */       } else if (value instanceof Map) {
/*  484 */         element = createMapElement(doc, "mapAttribute", key, (Map<String, String>)value);
/*  485 */       } else if (value instanceof Set) {
/*  486 */         element = createSetElement(doc, "setAttribute", key, (Set<String>)value);
/*      */       } 
/*  488 */       configRootElement.appendChild(element);
/*      */     } 
/*      */     
/*  491 */     return LaunchManager.serializeDocument(doc, lineDelimeter);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected Element createKeyValueElement(Document doc, String elementType, String key, String value) {
/*  504 */     Element element = doc.createElement(elementType);
/*  505 */     element.setAttribute("key", key);
/*  506 */     element.setAttribute("value", value);
/*  507 */     return element;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected Element createListElement(Document doc, String elementType, String listKey, List<String> list) {
/*  521 */     Element listElement = doc.createElement(elementType);
/*  522 */     listElement.setAttribute("key", listKey);
/*  523 */     for (String value : list) {
/*  524 */       Element element = doc.createElement("listEntry");
/*  525 */       element.setAttribute("value", value);
/*  526 */       listElement.appendChild(element);
/*      */     } 
/*  528 */     return listElement;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected Element createSetElement(Document doc, String elementType, String setKey, Set<String> set) {
/*  544 */     Element setElement = doc.createElement(elementType);
/*  545 */     setElement.setAttribute("key", setKey);
/*      */     
/*  547 */     List<String> list = new ArrayList<>(set);
/*  548 */     Collections.sort(list);
/*  549 */     Element element = null;
/*  550 */     for (String str : list) {
/*  551 */       element = doc.createElement("setEntry");
/*  552 */       element.setAttribute("value", str);
/*  553 */       setElement.appendChild(element);
/*      */     } 
/*  555 */     return setElement;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected Element createMapElement(Document doc, String elementType, String mapKey, Map<String, String> map) {
/*  570 */     Element mapElement = doc.createElement(elementType);
/*  571 */     mapElement.setAttribute("key", mapKey);
/*      */     
/*  573 */     List<String> keys = new ArrayList<>(map.keySet());
/*  574 */     Collections.sort(keys);
/*  575 */     for (String key : keys) {
/*  576 */       String value = map.get(key);
/*  577 */       Element element = doc.createElement("mapEntry");
/*  578 */       element.setAttribute("key", key);
/*  579 */       element.setAttribute("value", value);
/*  580 */       mapElement.appendChild(element);
/*      */     } 
/*  582 */     return mapElement;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void initializeFromXML(Element root) throws CoreException {
/*  591 */     initializeFromXML(root, false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void initializeFromXML(Element root, boolean isPrototype) throws CoreException {
/*  604 */     if (!root.getNodeName().equalsIgnoreCase("launchConfiguration")) {
/*  605 */       throw getInvalidFormatDebugException();
/*      */     }
/*      */ 
/*      */     
/*  609 */     String id = root.getAttribute("type");
/*  610 */     if (id == null) {
/*  611 */       throw getInvalidFormatDebugException();
/*      */     }
/*      */     
/*  614 */     ILaunchConfigurationType type = DebugPlugin.getDefault().getLaunchManager().getLaunchConfigurationType(id);
/*  615 */     if (type == null) {
/*  616 */       String message = MessageFormat.format(DebugCoreMessages.LaunchConfigurationInfo_missing_type, new Object[] { id });
/*  617 */       throw new DebugException(
/*  618 */           new Status(
/*  619 */             4, DebugPlugin.getUniqueIdentifier(), 
/*  620 */             5020, message, null));
/*      */     } 
/*      */     
/*  623 */     setType(type);
/*      */     
/*  625 */     NodeList list = root.getChildNodes();
/*  626 */     Node node = null;
/*  627 */     Element element = null;
/*  628 */     String nodeName = null;
/*  629 */     for (int i = 0; i < list.getLength(); i++) {
/*  630 */       node = list.item(i);
/*  631 */       short nodeType = node.getNodeType();
/*  632 */       if (nodeType == 1) {
/*  633 */         element = (Element)node;
/*  634 */         nodeName = element.getNodeName();
/*  635 */         if (nodeName.equalsIgnoreCase("stringAttribute")) {
/*  636 */           setStringAttribute(element);
/*  637 */         } else if (nodeName.equalsIgnoreCase("intAttribute")) {
/*  638 */           setIntegerAttribute(element);
/*  639 */         } else if (nodeName.equalsIgnoreCase("booleanAttribute")) {
/*  640 */           setBooleanAttribute(element);
/*  641 */         } else if (nodeName.equalsIgnoreCase("listAttribute")) {
/*  642 */           setListAttribute(element);
/*  643 */         } else if (nodeName.equalsIgnoreCase("mapAttribute")) {
/*  644 */           setMapAttribute(element);
/*  645 */         } else if (nodeName.equalsIgnoreCase("setAttribute")) {
/*  646 */           setSetAttribute(element);
/*      */         } 
/*      */       } 
/*      */     } 
/*      */     
/*  651 */     if (isPrototype) {
/*  652 */       setIsPrototype(true);
/*  653 */       String visibleAttributes = root.getAttribute("visibleAttributes");
/*  654 */       if (visibleAttributes != null && visibleAttributes.length() > 0) {
/*  655 */         String[] split = visibleAttributes.split(", ");
/*  656 */         setVisibleAttributes(new HashSet<>(Arrays.asList(split)));
/*      */       } 
/*      */     } else {
/*  659 */       setIsPrototype(false);
/*  660 */       String prototype = root.getAttribute("prototype");
/*  661 */       if (prototype != null && prototype.length() > 0) {
/*  662 */         ILaunchConfiguration[] launchConfigurations = DebugPlugin.getDefault().getLaunchManager().getLaunchConfigurations(2); byte b; int j; ILaunchConfiguration[] arrayOfILaunchConfiguration1;
/*  663 */         for (j = (arrayOfILaunchConfiguration1 = launchConfigurations).length, b = 0; b < j; ) { ILaunchConfiguration iLaunchConfiguration = arrayOfILaunchConfiguration1[b];
/*  664 */           if (prototype.equals(iLaunchConfiguration.getName())) {
/*  665 */             setPrototype(iLaunchConfiguration);
/*      */             break;
/*      */           } 
/*      */           b++; }
/*      */       
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void setStringAttribute(Element element) throws CoreException {
/*  679 */     setAttribute(getKeyAttribute(element), getValueAttribute(element));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void setIntegerAttribute(Element element) throws CoreException {
/*  688 */     setAttribute(getKeyAttribute(element), Integer.valueOf(getValueAttribute(element)));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void setBooleanAttribute(Element element) throws CoreException {
/*  697 */     setAttribute(getKeyAttribute(element), Boolean.valueOf(getValueAttribute(element)));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void setListAttribute(Element element) throws CoreException {
/*  708 */     String listKey = element.getAttribute("key");
/*  709 */     NodeList nodeList = element.getChildNodes();
/*  710 */     int entryCount = nodeList.getLength();
/*  711 */     List<String> list = new ArrayList<>(entryCount);
/*  712 */     Node node = null;
/*  713 */     Element selement = null;
/*  714 */     for (int i = 0; i < entryCount; i++) {
/*  715 */       node = nodeList.item(i);
/*  716 */       if (node.getNodeType() == 1) {
/*  717 */         selement = (Element)node;
/*  718 */         if (!selement.getNodeName().equalsIgnoreCase("listEntry")) {
/*  719 */           throw getInvalidFormatDebugException();
/*      */         }
/*  721 */         list.add(getValueAttribute(selement));
/*      */       } 
/*      */     } 
/*  724 */     setAttribute(listKey, list);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void setSetAttribute(Element element) throws CoreException {
/*  737 */     String setKey = element.getAttribute("key");
/*  738 */     NodeList nodeList = element.getChildNodes();
/*  739 */     int entryCount = nodeList.getLength();
/*  740 */     Set<String> set = new HashSet<>(entryCount);
/*  741 */     Node node = null;
/*  742 */     Element selement = null;
/*  743 */     for (int i = 0; i < entryCount; i++) {
/*  744 */       node = nodeList.item(i);
/*  745 */       if (node.getNodeType() == 1) {
/*  746 */         selement = (Element)node;
/*  747 */         if (!selement.getNodeName().equalsIgnoreCase("setEntry")) {
/*  748 */           throw getInvalidFormatDebugException();
/*      */         }
/*  750 */         set.add(getValueAttribute(selement));
/*      */       } 
/*      */     } 
/*  753 */     setAttribute(setKey, set);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void setMapAttribute(Element element) throws CoreException {
/*  764 */     String mapKey = element.getAttribute("key");
/*  765 */     NodeList nodeList = element.getChildNodes();
/*  766 */     int entryCount = nodeList.getLength();
/*  767 */     Map<String, String> map = new HashMap<>(entryCount);
/*  768 */     Node node = null;
/*  769 */     Element selement = null;
/*  770 */     for (int i = 0; i < entryCount; i++) {
/*  771 */       node = nodeList.item(i);
/*  772 */       if (node.getNodeType() == 1) {
/*  773 */         selement = (Element)node;
/*  774 */         if (!selement.getNodeName().equalsIgnoreCase("mapEntry")) {
/*  775 */           throw getInvalidFormatDebugException();
/*      */         }
/*  777 */         map.put(getKeyAttribute(selement), getValueAttribute(selement));
/*      */       } 
/*      */     } 
/*  780 */     setAttribute(mapKey, map);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected String getKeyAttribute(Element element) throws CoreException {
/*  790 */     String key = element.getAttribute("key");
/*  791 */     if (key == null) {
/*  792 */       throw getInvalidFormatDebugException();
/*      */     }
/*  794 */     return key;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected String getValueAttribute(Element element) throws CoreException {
/*  804 */     String value = element.getAttribute("value");
/*  805 */     if (value == null) {
/*  806 */       throw getInvalidFormatDebugException();
/*      */     }
/*  808 */     return value;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected DebugException getInvalidFormatDebugException() {
/*  816 */     return 
/*  817 */       new DebugException(
/*  818 */         (IStatus)new Status(
/*  819 */           4, DebugPlugin.getUniqueIdentifier(), 
/*  820 */           5012, DebugCoreMessages.LaunchConfigurationInfo_Invalid_launch_configuration_XML__10, null));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean equals(Object obj) {
/*  836 */     if (!(obj instanceof LaunchConfigurationInfo)) {
/*  837 */       return false;
/*      */     }
/*      */ 
/*      */     
/*  841 */     LaunchConfigurationInfo other = (LaunchConfigurationInfo)obj;
/*  842 */     if (!this.fType.getIdentifier().equals(other.getType().getIdentifier())) {
/*  843 */       return false;
/*      */     }
/*      */ 
/*      */     
/*  847 */     if (isPrototype() != other.isPrototype())
/*  848 */       return false; 
/*  849 */     if (isPrototype() && !getVisibleAttributes().equals(other.getVisibleAttributes())) {
/*  850 */       return false;
/*      */     }
/*      */ 
/*      */     
/*  854 */     return compareAttributes(this.fAttributes, other.getAttributeTable());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean compareAttributes(TreeMap<String, Object> map1, TreeMap<String, Object> map2) {
/*  866 */     if (map1.size() == map2.size()) {
/*  867 */       Iterator<String> attributes = map1.keySet().iterator();
/*  868 */       while (attributes.hasNext()) {
/*  869 */         String key = attributes.next();
/*  870 */         Object attr1 = map1.get(key);
/*  871 */         Object attr2 = map2.get(key);
/*  872 */         if (!compareAttribute(key, attr1, attr2)) {
/*  873 */           return false;
/*      */         }
/*      */       } 
/*  876 */       return true;
/*      */     } 
/*  878 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected static boolean compareAttribute(String key, Object attr1, Object attr2) {
/*  892 */     if (attr2 == null) {
/*  893 */       return false;
/*      */     }
/*  895 */     Comparator<Object> comp = fgLaunchManager.getComparator(key);
/*  896 */     if (comp == null) {
/*  897 */       String strAttr1 = null;
/*  898 */       String strAttr2 = null;
/*  899 */       if (fgIsSun14x && 
/*  900 */         attr2 instanceof String && attr1 instanceof String) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  907 */         strAttr1 = ((String)attr1).replaceAll("\\r", "");
/*  908 */         strAttr2 = ((String)attr2).replaceAll("\\r", "");
/*  909 */         if (!strAttr1.equals(strAttr2)) {
/*  910 */           return false;
/*      */         }
/*      */       } 
/*      */       
/*  914 */       if (strAttr1 == null && strAttr2 == null && !attr1.equals(attr2)) {
/*  915 */         return false;
/*      */       }
/*  917 */     } else if (comp.compare(attr1, attr2) != 0) {
/*  918 */       return false;
/*      */     } 
/*  920 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int hashCode() {
/*  928 */     return this.fType.hashCode() + this.fAttributes.size();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean hasAttribute(String attributeName) {
/*  939 */     return this.fAttributes.containsKey(attributeName);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected Object removeAttribute(String attributeName) {
/*  952 */     if (attributeName != null) {
/*  953 */       return this.fAttributes.remove(attributeName);
/*      */     }
/*  955 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void setIsPrototype(boolean isPrototype) {
/*  966 */     this.fIsPrototype = isPrototype;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean isPrototype() {
/*  977 */     return this.fIsPrototype;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected Set<String> getVisibleAttributes() {
/*  991 */     if (!isPrototype())
/*  992 */       return null; 
/*  993 */     if (this.fVisibleAttributes == null) {
/*  994 */       initializeVisibleAttributes();
/*      */     }
/*  996 */     return this.fVisibleAttributes;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void initializeVisibleAttributes() {
/* 1006 */     this.fVisibleAttributes = new HashSet<>(getAttributeTable().keySet());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void setVisibleAttributes(Set<String> visibleAttributes) {
/* 1018 */     if (visibleAttributes != null) {
/* 1019 */       this.fVisibleAttributes = new HashSet<>(visibleAttributes);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void setAttributeVisibility(String attribute, boolean visible) {
/* 1033 */     if (this.fVisibleAttributes != null)
/* 1034 */       if (visible) {
/* 1035 */         this.fVisibleAttributes.add(attribute);
/*      */       } else {
/* 1037 */         this.fVisibleAttributes.remove(attribute);
/*      */       }  
/*      */   }
/*      */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.debug.core-3.21.0.jar!\org\eclipse\debug\internal\core\LaunchConfigurationInfo.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */