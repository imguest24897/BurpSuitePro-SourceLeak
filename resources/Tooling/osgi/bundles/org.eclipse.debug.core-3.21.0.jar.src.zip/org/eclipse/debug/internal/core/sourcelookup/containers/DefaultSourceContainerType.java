/*    */ package org.eclipse.debug.internal.core.sourcelookup.containers;
/*    */ 
/*    */ import org.eclipse.core.runtime.CoreException;
/*    */ import org.eclipse.debug.core.sourcelookup.ISourceContainer;
/*    */ import org.eclipse.debug.core.sourcelookup.containers.AbstractSourceContainerTypeDelegate;
/*    */ import org.eclipse.debug.core.sourcelookup.containers.DefaultSourceContainer;
/*    */ import org.eclipse.debug.internal.core.sourcelookup.SourceLookupMessages;
/*    */ import org.w3c.dom.Document;
/*    */ import org.w3c.dom.Element;
/*    */ import org.w3c.dom.Node;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DefaultSourceContainerType
/*    */   extends AbstractSourceContainerTypeDelegate
/*    */ {
/*    */   public String getMemento(ISourceContainer container) throws CoreException {
/* 35 */     Document document = newDocument();
/* 36 */     Element element = document.createElement("default");
/* 37 */     document.appendChild(element);
/* 38 */     return serializeDocument(document);
/*    */   }
/*    */ 
/*    */   
/*    */   public ISourceContainer createSourceContainer(String memento) throws CoreException {
/* 43 */     Node node = parseDocument(memento);
/* 44 */     if (node.getNodeType() == 1) {
/* 45 */       Element element = (Element)node;
/* 46 */       if ("default".equals(element.getNodeName())) {
/* 47 */         return (ISourceContainer)new DefaultSourceContainer();
/*    */       }
/* 49 */       abort(SourceLookupMessages.DefaultSourceContainerType_6, null);
/*    */     } 
/* 51 */     abort(SourceLookupMessages.DefaultSourceContainerType_7, null);
/* 52 */     return null;
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.debug.core-3.21.0.jar!\org\eclipse\debug\internal\core\sourcelookup\containers\DefaultSourceContainerType.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */