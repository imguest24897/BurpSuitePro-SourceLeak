/*    */ package org.eclipse.debug.internal.core;
/*    */ 
/*    */ import org.eclipse.debug.core.DebugPlugin;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface IInternalDebugCoreConstants
/*    */ {
/*    */   public static final String EMPTY_STRING = "";
/* 38 */   public static final String PREF_ENABLE_STATUS_HANDLERS = String.valueOf(DebugPlugin.getUniqueIdentifier()) + ".PREF_ENABLE_STATUS_HANDLERS";
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 45 */   public static final String PREF_BREAKPOINT_MANAGER_ENABLED_STATE = String.valueOf(DebugPlugin.getUniqueIdentifier()) + ".PREF_BREAKPOINT_MANAGER_ENABLED_STATE";
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.debug.core-3.21.0.jar!\org\eclipse\debug\internal\core\IInternalDebugCoreConstants.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */