/*     */ package org.eclipse.debug.core.commands;
/*     */ 
/*     */ import org.eclipse.core.runtime.CoreException;
/*     */ import org.eclipse.core.runtime.IProgressMonitor;
/*     */ import org.eclipse.core.runtime.IStatus;
/*     */ import org.eclipse.core.runtime.Status;
/*     */ import org.eclipse.core.runtime.jobs.IJobChangeEvent;
/*     */ import org.eclipse.core.runtime.jobs.IJobChangeListener;
/*     */ import org.eclipse.core.runtime.jobs.Job;
/*     */ import org.eclipse.debug.internal.core.DebugOptions;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class UpdateJob
/*     */   extends Job
/*     */   implements IJobChangeListener
/*     */ {
/*     */   private IEnabledStateRequest request;
/*     */   private boolean run = false;
/*     */   
/*     */   UpdateJob(IEnabledStateRequest stateRequest) {
/*  62 */     super(paramAbstractDebugCommand.getEnabledStateTaskName());
/*  63 */     this.request = stateRequest;
/*  64 */     setSystem(true);
/*  65 */     setRule(paramAbstractDebugCommand.getEnabledStateSchedulingRule(this.request));
/*  66 */     getJobManager().addJobChangeListener(this);
/*     */   }
/*     */ 
/*     */   
/*     */   protected IStatus run(IProgressMonitor monitor) {
/*  71 */     this.run = true;
/*  72 */     if (DebugOptions.DEBUG_COMMANDS) {
/*  73 */       DebugOptions.trace("can execute command: " + AbstractDebugCommand.this);
/*     */     }
/*  75 */     if (monitor.isCanceled()) {
/*  76 */       if (DebugOptions.DEBUG_COMMANDS) {
/*  77 */         DebugOptions.trace(" >> *CANCELED* <<");
/*     */       }
/*  79 */       this.request.cancel();
/*     */     } 
/*  81 */     Object[] elements = this.request.getElements();
/*  82 */     Object[] targets = new Object[elements.length];
/*  83 */     if (!this.request.isCanceled()) {
/*  84 */       for (int i = 0; i < elements.length; i++) {
/*  85 */         targets[i] = AbstractDebugCommand.this.getTarget(elements[i]);
/*  86 */         if (targets[i] == null) {
/*  87 */           this.request.setEnabled(false);
/*  88 */           this.request.cancel();
/*  89 */           if (DebugOptions.DEBUG_COMMANDS) {
/*  90 */             DebugOptions.trace(" >> false (no adapter)");
/*     */           }
/*     */         } 
/*     */       } 
/*  94 */       if (monitor.isCanceled()) {
/*  95 */         this.request.cancel();
/*     */       }
/*     */     } 
/*  98 */     if (!this.request.isCanceled()) {
/*  99 */       targets = AbstractDebugCommand.this.coalesce(targets);
/* 100 */       monitor.beginTask(AbstractDebugCommand.this.getEnabledStateTaskName(), targets.length);
/*     */       try {
/* 102 */         boolean executable = AbstractDebugCommand.this.isExecutable(targets, monitor, this.request);
/* 103 */         if (DebugOptions.DEBUG_COMMANDS) {
/* 104 */           DebugOptions.trace(" >> " + executable);
/*     */         }
/* 106 */         this.request.setEnabled(executable);
/* 107 */       } catch (CoreException e) {
/* 108 */         this.request.setStatus(e.getStatus());
/* 109 */         this.request.setEnabled(false);
/* 110 */         if (DebugOptions.DEBUG_COMMANDS) {
/* 111 */           DebugOptions.trace(" >> ABORTED");
/* 112 */           DebugOptions.trace("\t" + e.getStatus().getMessage());
/*     */         } 
/*     */       } 
/*     */     } 
/* 116 */     monitor.setCanceled(this.request.isCanceled());
/* 117 */     this.request.done();
/* 118 */     monitor.done();
/* 119 */     return Status.OK_STATUS;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean belongsTo(Object family) {
/* 124 */     Object myFamily = AbstractDebugCommand.this.getEnabledStateJobFamily(this.request);
/* 125 */     if (myFamily != null) {
/* 126 */       return myFamily.equals(family);
/*     */     }
/* 128 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void aboutToRun(IJobChangeEvent event) {}
/*     */ 
/*     */ 
/*     */   
/*     */   public void awake(IJobChangeEvent event) {}
/*     */ 
/*     */   
/*     */   public void done(IJobChangeEvent event) {
/* 141 */     if (event.getJob() == this) {
/* 142 */       if (!this.run) {
/* 143 */         this.request.cancel();
/* 144 */         this.request.done();
/* 145 */         if (DebugOptions.DEBUG_COMMANDS) {
/* 146 */           DebugOptions.trace(" >> *CANCELED* <<" + AbstractDebugCommand.this);
/*     */         }
/*     */       } 
/* 149 */       getJobManager().removeJobChangeListener(this);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void running(IJobChangeEvent event) {}
/*     */ 
/*     */ 
/*     */   
/*     */   public void scheduled(IJobChangeEvent event) {}
/*     */ 
/*     */ 
/*     */   
/*     */   public void sleeping(IJobChangeEvent event) {}
/*     */ 
/*     */   
/*     */   public String toString() {
/* 167 */     return String.valueOf(getName()) + " on " + this.request;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.debug.core-3.21.0.jar!\org\eclipse\debug\core\commands\AbstractDebugCommand$UpdateJob.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */