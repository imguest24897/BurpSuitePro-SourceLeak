/*    */ package org.eclipse.debug.internal.core.sourcelookup.containers;
/*    */ 
/*    */ import org.eclipse.core.resources.IFile;
/*    */ import org.eclipse.core.resources.ResourcesPlugin;
/*    */ import org.eclipse.core.runtime.CoreException;
/*    */ import org.eclipse.core.runtime.IPath;
/*    */ import org.eclipse.core.runtime.Path;
/*    */ import org.eclipse.debug.core.sourcelookup.ISourceContainer;
/*    */ import org.eclipse.debug.core.sourcelookup.containers.AbstractSourceContainerTypeDelegate;
/*    */ import org.eclipse.debug.core.sourcelookup.containers.ArchiveSourceContainer;
/*    */ import org.eclipse.debug.internal.core.sourcelookup.SourceLookupMessages;
/*    */ import org.w3c.dom.Document;
/*    */ import org.w3c.dom.Element;
/*    */ import org.w3c.dom.Node;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ArchiveSourceContainerType
/*    */   extends AbstractSourceContainerTypeDelegate
/*    */ {
/*    */   public ISourceContainer createSourceContainer(String memento) throws CoreException {
/* 37 */     Node node = parseDocument(memento);
/* 38 */     if (node.getNodeType() == 1) {
/* 39 */       Element element = (Element)node;
/* 40 */       if ("archive".equals(element.getNodeName())) {
/* 41 */         String string = element.getAttribute("path");
/* 42 */         if (string == null || string.length() == 0) {
/* 43 */           abort(SourceLookupMessages.ExternalArchiveSourceContainerType_10, null);
/*    */         }
/* 45 */         String detect = element.getAttribute("detectRoot");
/* 46 */         boolean auto = "true".equals(detect);
/* 47 */         IFile file = ResourcesPlugin.getWorkspace().getRoot().getFile((IPath)new Path(string));
/* 48 */         return (ISourceContainer)new ArchiveSourceContainer(file, auto);
/*    */       } 
/* 50 */       abort(SourceLookupMessages.ExternalArchiveSourceContainerType_11, null);
/*    */     } 
/* 52 */     abort(SourceLookupMessages.ExternalArchiveSourceContainerType_12, null);
/* 53 */     return null;
/*    */   }
/*    */ 
/*    */   
/*    */   public String getMemento(ISourceContainer container) throws CoreException {
/* 58 */     ArchiveSourceContainer archive = (ArchiveSourceContainer)container;
/* 59 */     Document document = newDocument();
/* 60 */     Element element = document.createElement("archive");
/* 61 */     element.setAttribute("path", archive.getFile().getFullPath().toString());
/* 62 */     String detectRoot = "false";
/* 63 */     if (archive.isDetectRoot()) {
/* 64 */       detectRoot = "true";
/*    */     }
/* 66 */     element.setAttribute("detectRoot", detectRoot);
/* 67 */     document.appendChild(element);
/* 68 */     return serializeDocument(document);
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.debug.core-3.21.0.jar!\org\eclipse\debug\internal\core\sourcelookup\containers\ArchiveSourceContainerType.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */