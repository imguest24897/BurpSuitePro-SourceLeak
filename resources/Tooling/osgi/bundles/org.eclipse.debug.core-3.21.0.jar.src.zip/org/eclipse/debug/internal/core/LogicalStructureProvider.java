/*    */ package org.eclipse.debug.internal.core;
/*    */ 
/*    */ import org.eclipse.core.runtime.CoreException;
/*    */ import org.eclipse.core.runtime.IConfigurationElement;
/*    */ import org.eclipse.core.runtime.Status;
/*    */ import org.eclipse.debug.core.DebugPlugin;
/*    */ import org.eclipse.debug.core.ILogicalStructureProvider;
/*    */ import org.eclipse.debug.core.ILogicalStructureType;
/*    */ import org.eclipse.debug.core.model.IValue;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class LogicalStructureProvider
/*    */ {
/*    */   private IConfigurationElement fConfigurationElement;
/*    */   private String fModelIdentifier;
/*    */   private ILogicalStructureProvider fDelegate;
/*    */   
/*    */   public LogicalStructureProvider(IConfigurationElement element) throws CoreException {
/* 39 */     this.fConfigurationElement = element;
/* 40 */     this.fModelIdentifier = this.fConfigurationElement.getAttribute("modelIdentifier");
/* 41 */     if (this.fModelIdentifier == null) {
/* 42 */       throw new CoreException(new Status(4, DebugPlugin.getUniqueIdentifier(), 125, DebugCoreMessages.LogicalStructureProvider_0, null));
/*    */     }
/* 44 */     String className = this.fConfigurationElement.getAttribute("class");
/* 45 */     if (className == null) {
/* 46 */       throw new CoreException(new Status(4, DebugPlugin.getUniqueIdentifier(), 125, DebugCoreMessages.LogicalStructureProvider_1, null));
/*    */     }
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public ILogicalStructureType[] getLogicalStructures(IValue value) {
/* 58 */     if (this.fModelIdentifier.equals(value.getModelIdentifier())) {
/* 59 */       return getDelegate().getLogicalStructureTypes(value);
/*    */     }
/* 61 */     return new ILogicalStructureType[0];
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected ILogicalStructureProvider getDelegate() {
/* 69 */     if (this.fDelegate == null) {
/*    */       try {
/* 71 */         this.fDelegate = (ILogicalStructureProvider)this.fConfigurationElement.createExecutableExtension("class");
/* 72 */       } catch (CoreException e) {
/* 73 */         DebugPlugin.log((Throwable)e);
/*    */       } 
/*    */     }
/* 76 */     return this.fDelegate;
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.debug.core-3.21.0.jar!\org\eclipse\debug\internal\core\LogicalStructureProvider.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */