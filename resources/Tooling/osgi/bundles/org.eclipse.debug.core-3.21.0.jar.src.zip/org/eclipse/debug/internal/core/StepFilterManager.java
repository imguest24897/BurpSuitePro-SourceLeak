/*     */ package org.eclipse.debug.internal.core;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import org.eclipse.core.runtime.CoreException;
/*     */ import org.eclipse.core.runtime.IConfigurationElement;
/*     */ import org.eclipse.core.runtime.IExtensionPoint;
/*     */ import org.eclipse.core.runtime.Platform;
/*     */ import org.eclipse.debug.core.DebugPlugin;
/*     */ import org.eclipse.debug.core.ILaunch;
/*     */ import org.eclipse.debug.core.ILaunchListener;
/*     */ import org.eclipse.debug.core.commands.IDebugCommandRequest;
/*     */ import org.eclipse.debug.core.commands.IStepFiltersHandler;
/*     */ import org.eclipse.debug.core.model.IStepFilter;
/*     */ import org.eclipse.debug.internal.core.commands.DebugCommandRequest;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class StepFilterManager
/*     */   implements ILaunchListener
/*     */ {
/*  40 */   public static final String PREF_USE_STEP_FILTERS = String.valueOf(DebugPlugin.getUniqueIdentifier()) + ".USE_STEP_FILTERS";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private List<StepFilter> stepFilters;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected StepFilterManager() {
/* 114 */     this.stepFilters = null;
/*     */     DebugPlugin.getDefault().getLaunchManager().addLaunchListener(this);
/*     */   } private synchronized void initialize() {
/* 117 */     if (this.stepFilters == null) {
/* 118 */       IExtensionPoint point = Platform.getExtensionRegistry().getExtensionPoint(DebugPlugin.getUniqueIdentifier(), "stepFilters");
/* 119 */       IConfigurationElement[] extensions = point.getConfigurationElements();
/* 120 */       this.stepFilters = new ArrayList<>(); byte b; int i; IConfigurationElement[] arrayOfIConfigurationElement1;
/* 121 */       for (i = (arrayOfIConfigurationElement1 = extensions).length, b = 0; b < i; ) { IConfigurationElement extension = arrayOfIConfigurationElement1[b];
/*     */         try {
/* 123 */           this.stepFilters.add(new StepFilter(extension));
/* 124 */         } catch (CoreException e) {
/* 125 */           DebugPlugin.log((Throwable)e);
/*     */         } 
/*     */         b++; }
/*     */     
/*     */     } 
/*     */   }
/*     */   
/*     */   public void shutdown() {
/*     */     DebugPlugin.getDefault().getLaunchManager().removeLaunchListener(this);
/*     */   }
/*     */   
/*     */   public void launchAdded(ILaunch launch) {
/*     */     launchChanged(launch);
/*     */   }
/*     */   
/*     */   public void launchChanged(ILaunch launch) {
/*     */     IStepFiltersHandler command = (IStepFiltersHandler)launch.getAdapter(IStepFiltersHandler.class);
/*     */     if (command != null)
/*     */       command.execute((IDebugCommandRequest)new DebugCommandRequest(new Object[] { launch })); 
/*     */   }
/*     */   
/*     */   public boolean isUseStepFilters() {
/*     */     return Platform.getPreferencesService().getBoolean(DebugPlugin.getUniqueIdentifier(), PREF_USE_STEP_FILTERS, false, null);
/*     */   }
/*     */   
/*     */   public void setUseStepFilters(boolean useFilters) {
/*     */     Preferences.setBoolean(DebugPlugin.getUniqueIdentifier(), PREF_USE_STEP_FILTERS, useFilters, null);
/*     */     ILaunch[] launchs = DebugPlugin.getDefault().getLaunchManager().getLaunches();
/*     */     byte b;
/*     */     int i;
/*     */     ILaunch[] arrayOfILaunch1;
/*     */     for (i = (arrayOfILaunch1 = launchs).length, b = 0; b < i; ) {
/*     */       ILaunch launch = arrayOfILaunch1[b];
/*     */       launchChanged(launch);
/*     */       b++;
/*     */     } 
/*     */   }
/*     */   
/*     */   public void launchRemoved(ILaunch launch) {}
/*     */   
/*     */   public IStepFilter[] getStepFilters(String modelIdentifier) {
/*     */     initialize();
/*     */     List<IStepFilter> select = new ArrayList<>();
/*     */     for (StepFilter extension : this.stepFilters)
/*     */       Collections.addAll(select, extension.getStepFilters(modelIdentifier)); 
/*     */     return select.<IStepFilter>toArray(new IStepFilter[select.size()]);
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.debug.core-3.21.0.jar!\org\eclipse\debug\internal\core\StepFilterManager.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */