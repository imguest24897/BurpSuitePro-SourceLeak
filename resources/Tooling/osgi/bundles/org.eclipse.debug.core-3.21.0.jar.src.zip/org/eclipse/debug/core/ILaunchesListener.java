package org.eclipse.debug.core;

public interface ILaunchesListener {
  void launchesRemoved(ILaunch[] paramArrayOfILaunch);
  
  void launchesAdded(ILaunch[] paramArrayOfILaunch);
  
  void launchesChanged(ILaunch[] paramArrayOfILaunch);
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.debug.core-3.21.0.jar!\org\eclipse\debug\core\ILaunchesListener.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */