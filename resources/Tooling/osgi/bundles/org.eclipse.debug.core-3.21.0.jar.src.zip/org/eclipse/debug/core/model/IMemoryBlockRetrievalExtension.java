package org.eclipse.debug.core.model;

import org.eclipse.debug.core.DebugException;

public interface IMemoryBlockRetrievalExtension extends IMemoryBlockRetrieval {
  IMemoryBlockExtension getExtendedMemoryBlock(String paramString, Object paramObject) throws DebugException;
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.debug.core-3.21.0.jar!\org\eclipse\debug\core\model\IMemoryBlockRetrievalExtension.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */