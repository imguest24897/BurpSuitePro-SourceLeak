/*     */ package org.eclipse.debug.core.sourcelookup;
/*     */ 
/*     */ import java.text.MessageFormat;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.eclipse.core.runtime.CoreException;
/*     */ import org.eclipse.core.runtime.ISafeRunnable;
/*     */ import org.eclipse.core.runtime.IStatus;
/*     */ import org.eclipse.core.runtime.MultiStatus;
/*     */ import org.eclipse.core.runtime.SafeRunner;
/*     */ import org.eclipse.core.runtime.Status;
/*     */ import org.eclipse.debug.core.DebugPlugin;
/*     */ import org.eclipse.debug.core.ILaunch;
/*     */ import org.eclipse.debug.core.ILaunchConfiguration;
/*     */ import org.eclipse.debug.core.ILaunchConfigurationListener;
/*     */ import org.eclipse.debug.core.ILaunchListener;
/*     */ import org.eclipse.debug.core.ILaunchManager;
/*     */ import org.eclipse.debug.core.IStatusHandler;
/*     */ import org.eclipse.debug.core.model.IStackFrame;
/*     */ import org.eclipse.debug.core.sourcelookup.containers.DefaultSourceContainer;
/*     */ import org.eclipse.debug.internal.core.sourcelookup.SourceLookupMessages;
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.Element;
/*     */ import org.w3c.dom.Node;
/*     */ import org.w3c.dom.NodeList;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractSourceLookupDirector
/*     */   implements ISourceLookupDirector, ILaunchConfigurationListener, ILaunchListener
/*     */ {
/*     */   protected String fId;
/*  76 */   protected ArrayList<ISourceLookupParticipant> fParticipants = new ArrayList<>();
/*     */   
/*  78 */   protected ISourceContainer[] fSourceContainers = null;
/*     */   
/*     */   protected ILaunchConfiguration fConfig;
/*     */   
/*     */   protected boolean fDuplicates = false;
/*     */   
/*  84 */   protected ISourcePathComputer fComputer = null;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  89 */   protected Map<Object, Object> fResolvedElements = null;
/*     */   
/*     */   private ISourceLookupParticipant fCurrentParticipant;
/*     */   
/*  93 */   protected static final IStatus fPromptStatus = (IStatus)new Status(1, "org.eclipse.debug.ui", 200, "", null);
/*  94 */   protected static final IStatus fResolveDuplicatesStatus = (IStatus)new Status(1, "org.eclipse.debug.ui", 205, "", null);
/*     */   
/*     */   protected static final String DIRECTOR_ROOT_NODE = "sourceLookupDirector";
/*     */   protected static final String CONTAINERS_NODE = "sourceContainers";
/*     */   protected static final String DUPLICATES_ATTR = "duplicates";
/*     */   protected static final String CONTAINER_NODE = "container";
/*     */   protected static final String CONTAINER_TYPE_ATTR = "typeId";
/*     */   protected static final String CONTAINER_MEMENTO_ATTR = "memento";
/*     */   
/*     */   class SourceLookupQuery
/*     */     implements ISafeRunnable
/*     */   {
/* 106 */     private List<Object> fSourceElements = new ArrayList();
/* 107 */     private Object fElement = null;
/* 108 */     private Throwable fException = null;
/*     */     
/*     */     SourceLookupQuery(Object element) {
/* 111 */       this.fElement = element;
/*     */     }
/*     */ 
/*     */     
/*     */     public void handleException(Throwable exception) {
/* 116 */       this.fException = exception;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Throwable getException() {
/* 125 */       return this.fException;
/*     */     }
/*     */ 
/*     */     
/*     */     public void run() throws Exception {
/* 130 */       MultiStatus multiStatus = null;
/* 131 */       CoreException single = null;
/* 132 */       ISourceLookupParticipant[] participants = AbstractSourceLookupDirector.this.getParticipants(); try {
/*     */         byte b; int i; ISourceLookupParticipant[] arrayOfISourceLookupParticipant;
/* 134 */         for (i = (arrayOfISourceLookupParticipant = participants).length, b = 0; b < i; ) { ISourceLookupParticipant participant = arrayOfISourceLookupParticipant[b];
/* 135 */           AbstractSourceLookupDirector.this.setCurrentParticipant(participant);
/*     */           
/*     */           try {
/* 138 */             Object[] sourceArray = participant.findSourceElements(this.fElement);
/* 139 */             if (sourceArray != null && sourceArray.length > 0) {
/* 140 */               if (AbstractSourceLookupDirector.this.isFindDuplicates()) {
/* 141 */                 byte b1; int j; Object[] arrayOfObject; for (j = (arrayOfObject = sourceArray).length, b1 = 0; b1 < j; ) { Object s = arrayOfObject[b1];
/* 142 */                   if (!AbstractSourceLookupDirector.this.checkDuplicate(s, this.fSourceElements))
/* 143 */                     this.fSourceElements.add(s); 
/*     */                   b1++; }
/*     */               
/*     */               } else {
/* 147 */                 this.fSourceElements.add(sourceArray[0]);
/*     */                 return;
/*     */               } 
/*     */             }
/* 151 */           } catch (CoreException e) {
/* 152 */             if (single == null) {
/* 153 */               single = e;
/* 154 */             } else if (multiStatus == null) {
/* 155 */               multiStatus = new MultiStatus(DebugPlugin.getUniqueIdentifier(), 125, new IStatus[] { single.getStatus() }, SourceLookupMessages.Source_Lookup_Error, null);
/* 156 */               multiStatus.add(e.getStatus());
/*     */             } else {
/* 158 */               multiStatus.add(e.getStatus());
/*     */             } 
/*     */           }  b++; }
/*     */       
/*     */       } finally {
/* 163 */         AbstractSourceLookupDirector.this.setCurrentParticipant((ISourceLookupParticipant)null);
/*     */       } 
/* 165 */       if (this.fSourceElements.isEmpty())
/*     */       {
/* 167 */         if (multiStatus != null) {
/* 168 */           this.fException = (Throwable)new CoreException((IStatus)multiStatus);
/* 169 */         } else if (single != null) {
/* 170 */           this.fException = (Throwable)single;
/*     */         } 
/*     */       }
/*     */     }
/*     */     
/*     */     public List<Object> getSourceElements() {
/* 176 */       return this.fSourceElements;
/*     */     }
/*     */     
/*     */     public void dispose() {
/* 180 */       this.fElement = null;
/* 181 */       this.fSourceElements = null;
/* 182 */       this.fException = null;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setId(String id) {
/* 200 */     this.fId = id;
/*     */   }
/*     */ 
/*     */   
/*     */   public synchronized void dispose() {
/* 205 */     ILaunchManager launchManager = DebugPlugin.getDefault().getLaunchManager();
/* 206 */     launchManager.removeLaunchConfigurationListener(this);
/* 207 */     launchManager.removeLaunchListener(this);
/* 208 */     for (ISourceLookupParticipant participant : this.fParticipants) {
/*     */       
/* 210 */       if (participant != this) {
/* 211 */         participant.dispose();
/*     */       }
/*     */     } 
/* 214 */     this.fParticipants.clear();
/* 215 */     if (this.fSourceContainers != null) {
/* 216 */       byte b; int i; ISourceContainer[] arrayOfISourceContainer; for (i = (arrayOfISourceContainer = this.fSourceContainers).length, b = 0; b < i; ) { ISourceContainer container = arrayOfISourceContainer[b];
/* 217 */         container.dispose(); b++; }
/*     */     
/*     */     } 
/* 220 */     this.fSourceContainers = null;
/* 221 */     this.fResolvedElements = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void abort(String message, Throwable exception) throws CoreException {
/* 232 */     Status status = new Status(4, DebugPlugin.getUniqueIdentifier(), 125, message, exception);
/* 233 */     throw new CoreException(status);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private List<ISourceContainer> parseSourceContainers(NodeList list) throws CoreException {
/* 244 */     List<ISourceContainer> containers = new ArrayList<>();
/* 245 */     for (int i = 0; i < list.getLength(); i++) {
/* 246 */       if (list.item(i).getNodeType() == 1) {
/*     */ 
/*     */         
/* 249 */         Element element = (Element)list.item(i);
/* 250 */         String typeId = element.getAttribute("typeId");
/* 251 */         if (typeId == null || typeId.equals("")) {
/* 252 */           abort(SourceLookupMessages.AbstractSourceLookupDirector_11, (Throwable)null);
/*     */         }
/* 254 */         ISourceContainerType type = DebugPlugin.getDefault().getLaunchManager().getSourceContainerType(typeId);
/* 255 */         if (type != null) {
/* 256 */           String memento = element.getAttribute("memento");
/* 257 */           if (memento == null || memento.equals("")) {
/* 258 */             abort(SourceLookupMessages.AbstractSourceLookupDirector_13, (Throwable)null);
/*     */           }
/* 260 */           ISourceContainer container = type.createSourceContainer(memento);
/* 261 */           containers.add(container);
/*     */         } else {
/*     */           
/* 264 */           abort(MessageFormat.format(SourceLookupMessages.AbstractSourceLookupDirector_12, new Object[] { typeId }), (Throwable)null);
/*     */         } 
/*     */       } 
/* 267 */     }  return containers;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private synchronized void addSourceLookupParticipant(ISourceLookupParticipant participant) {
/* 278 */     if (!this.fParticipants.contains(participant)) {
/* 279 */       this.fParticipants.add(participant);
/* 280 */       participant.init(this);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public synchronized ISourceContainer[] getSourceContainers() {
/* 286 */     if (this.fSourceContainers == null) {
/* 287 */       return new ISourceContainer[0];
/*     */     }
/* 289 */     ISourceContainer[] copy = new ISourceContainer[this.fSourceContainers.length];
/* 290 */     System.arraycopy(this.fSourceContainers, 0, copy, 0, this.fSourceContainers.length);
/* 291 */     return copy;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isFindDuplicates() {
/* 296 */     return this.fDuplicates;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setFindDuplicates(boolean duplicates) {
/* 301 */     this.fDuplicates = duplicates;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private synchronized void removeSourceLookupParticipant(ISourceLookupParticipant participant) {
/* 311 */     if (this.fParticipants.remove(participant)) {
/* 312 */       participant.dispose();
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void launchConfigurationAdded(ILaunchConfiguration configuration) {
/* 318 */     ILaunchConfiguration from = DebugPlugin.getDefault().getLaunchManager().getMovedFrom(configuration);
/* 319 */     if (from != null && from.equals(getLaunchConfiguration())) {
/* 320 */       this.fConfig = configuration;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void launchConfigurationChanged(ILaunchConfiguration configuration) {
/* 332 */     if (this.fConfig == null || configuration.isWorkingCopy()) {
/*     */       return;
/*     */     }
/* 335 */     if (this.fConfig.equals(configuration)) {
/*     */       try {
/* 337 */         String locatorMemento = configuration.getAttribute(ILaunchConfiguration.ATTR_SOURCE_LOCATOR_MEMENTO, null);
/* 338 */         if (locatorMemento == null) {
/* 339 */           initializeDefaults(configuration);
/*     */         } else {
/* 341 */           initializeFromMemento(locatorMemento, configuration);
/*     */         } 
/* 343 */       } catch (CoreException coreException) {}
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void launchConfigurationRemoved(ILaunchConfiguration configuration) {
/* 351 */     if (configuration.equals(getLaunchConfiguration()) && 
/* 352 */       DebugPlugin.getDefault().getLaunchManager().getMovedTo(configuration) == null) {
/* 353 */       this.fConfig = null;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized String getMemento() throws CoreException {
/* 360 */     Document doc = DebugPlugin.newDocument();
/* 361 */     Element rootNode = doc.createElement("sourceLookupDirector");
/* 362 */     doc.appendChild(rootNode);
/*     */     
/* 364 */     Element pathNode = doc.createElement("sourceContainers");
/* 365 */     if (this.fDuplicates) {
/* 366 */       pathNode.setAttribute("duplicates", "true");
/*     */     } else {
/* 368 */       pathNode.setAttribute("duplicates", "false");
/*     */     } 
/* 370 */     rootNode.appendChild(pathNode);
/* 371 */     if (this.fSourceContainers != null) {
/* 372 */       byte b; int i; ISourceContainer[] arrayOfISourceContainer; for (i = (arrayOfISourceContainer = this.fSourceContainers).length, b = 0; b < i; ) { ISourceContainer container = arrayOfISourceContainer[b];
/* 373 */         Element node = doc.createElement("container");
/* 374 */         ISourceContainerType type = container.getType();
/* 375 */         node.setAttribute("typeId", type.getId());
/* 376 */         node.setAttribute("memento", type.getMemento(container));
/* 377 */         pathNode.appendChild(node); b++; }
/*     */     
/*     */     } 
/* 380 */     return DebugPlugin.serializeDocument(doc);
/*     */   }
/*     */ 
/*     */   
/*     */   public void initializeFromMemento(String memento) throws CoreException {
/* 385 */     doInitializeFromMemento(memento, true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void doInitializeFromMemento(String memento, boolean dispose) throws CoreException {
/* 399 */     if (dispose) {
/* 400 */       dispose();
/*     */     }
/* 402 */     Element rootElement = DebugPlugin.parseDocument(memento);
/* 403 */     if (!rootElement.getNodeName().equalsIgnoreCase("sourceLookupDirector")) {
/* 404 */       abort(SourceLookupMessages.AbstractSourceLookupDirector_14, (Throwable)null);
/*     */     }
/* 406 */     NodeList list = rootElement.getChildNodes();
/* 407 */     int length = list.getLength();
/* 408 */     for (int i = 0; i < length; i++) {
/* 409 */       Node node = list.item(i);
/* 410 */       short type = node.getNodeType();
/* 411 */       if (type == 1) {
/* 412 */         Element entry = (Element)node;
/* 413 */         if (entry.getNodeName().equalsIgnoreCase("sourceContainers")) {
/* 414 */           setFindDuplicates("true".equals(entry.getAttribute("duplicates")));
/* 415 */           NodeList children = entry.getChildNodes();
/* 416 */           List<ISourceContainer> containers = parseSourceContainers(children);
/* 417 */           setSourceContainers(containers.<ISourceContainer>toArray(new ISourceContainer[containers.size()]));
/*     */         } 
/*     */       } 
/*     */     } 
/* 421 */     initializeParticipants();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSourceContainers(ISourceContainer[] containers) {
/* 432 */     synchronized (this) {
/* 433 */       List<ISourceContainer> list = Arrays.asList(containers);
/* 434 */       ISourceContainer[] old = getSourceContainers(); byte b1; int j; ISourceContainer[] arrayOfISourceContainer1;
/* 435 */       for (j = (arrayOfISourceContainer1 = old).length, b1 = 0; b1 < j; ) { ISourceContainer container = arrayOfISourceContainer1[b1];
/*     */         
/* 437 */         if (!list.contains(container))
/* 438 */           container.dispose(); 
/*     */         b1++; }
/*     */       
/* 441 */       this.fSourceContainers = containers;
/* 442 */       for (j = (arrayOfISourceContainer1 = containers).length, b1 = 0; b1 < j; ) { ISourceContainer container = arrayOfISourceContainer1[b1];
/* 443 */         container.init(this);
/*     */         b1++; }
/*     */     
/*     */     } 
/* 447 */     this.fResolvedElements = null;
/*     */     
/* 449 */     ISourceLookupParticipant[] participants = getParticipants(); byte b; int i; ISourceLookupParticipant[] arrayOfISourceLookupParticipant1;
/* 450 */     for (i = (arrayOfISourceLookupParticipant1 = participants).length, b = 0; b < i; ) { ISourceLookupParticipant participant = arrayOfISourceLookupParticipant1[b];
/* 451 */       participant.sourceContainersChanged(this);
/*     */       b++; }
/*     */   
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object getSourceElement(IStackFrame stackFrame) {
/* 461 */     return getSourceElement(stackFrame);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected List<Object> doSourceLookup(Object element) {
/* 472 */     SourceLookupQuery query = new SourceLookupQuery(element);
/* 473 */     SafeRunner.run(query);
/* 474 */     List<Object> sources = query.getSourceElements();
/* 475 */     Throwable exception = query.getException();
/* 476 */     if (exception != null) {
/* 477 */       if (exception instanceof CoreException) {
/* 478 */         CoreException ce = (CoreException)exception;
/* 479 */         if (ce.getStatus().getSeverity() == 4) {
/* 480 */           DebugPlugin.log((Throwable)ce);
/*     */         }
/*     */       } else {
/* 483 */         DebugPlugin.log(exception);
/*     */       } 
/*     */     }
/* 486 */     query.dispose();
/* 487 */     return sources;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object resolveSourceElement(Object element, List<Object> sources) {
/* 505 */     for (Object dup : sources) {
/* 506 */       Object resolved = getCachedElement(dup);
/* 507 */       if (resolved != null) {
/* 508 */         return resolved;
/*     */       }
/*     */     } 
/*     */     
/* 512 */     IStatusHandler prompter = DebugPlugin.getDefault().getStatusHandler(fPromptStatus);
/* 513 */     if (prompter != null) {
/*     */       try {
/* 515 */         Object result = prompter.handleStatus(fResolveDuplicatesStatus, new Object[] { element, sources });
/* 516 */         if (result != null) {
/* 517 */           cacheResolvedElement(sources, result);
/* 518 */           return result;
/*     */         } 
/* 520 */       } catch (CoreException coreException) {}
/*     */     }
/*     */     
/* 523 */     return sources.get(0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean checkDuplicate(Object sourceToAdd, List<Object> sources) {
/* 533 */     if (sources.isEmpty()) {
/* 534 */       return false;
/*     */     }
/* 536 */     for (Object obj : sources) {
/* 537 */       if (equalSourceElements(obj, sourceToAdd)) {
/* 538 */         return true;
/*     */       }
/*     */     } 
/* 541 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public void initializeFromMemento(String memento, ILaunchConfiguration configuration) throws CoreException {
/* 546 */     dispose();
/* 547 */     setLaunchConfiguration(configuration);
/* 548 */     doInitializeFromMemento(memento, false);
/*     */   }
/*     */ 
/*     */   
/*     */   public void initializeDefaults(ILaunchConfiguration configuration) throws CoreException {
/* 553 */     dispose();
/* 554 */     setLaunchConfiguration(configuration);
/* 555 */     setSourceContainers(new ISourceContainer[] { (ISourceContainer)new DefaultSourceContainer() });
/* 556 */     initializeParticipants();
/*     */   }
/*     */ 
/*     */   
/*     */   public ILaunchConfiguration getLaunchConfiguration() {
/* 561 */     return this.fConfig;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void setLaunchConfiguration(ILaunchConfiguration configuration) {
/* 575 */     this.fConfig = configuration;
/* 576 */     ILaunchManager launchManager = DebugPlugin.getDefault().getLaunchManager();
/* 577 */     launchManager.addLaunchConfigurationListener(this);
/* 578 */     launchManager.addLaunchListener(this);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void launchAdded(ILaunch launch) {}
/*     */ 
/*     */ 
/*     */   
/*     */   public void launchChanged(ILaunch launch) {}
/*     */ 
/*     */   
/*     */   public void launchRemoved(ILaunch launch) {
/* 591 */     if (equals(launch.getSourceLocator())) {
/* 592 */       dispose();
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public synchronized ISourceLookupParticipant[] getParticipants() {
/* 598 */     return this.fParticipants.<ISourceLookupParticipant>toArray(new ISourceLookupParticipant[this.fParticipants.size()]);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean supportsSourceContainerType(ISourceContainerType type) {
/* 603 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void cacheResolvedElement(List<Object> duplicates, Object sourceElement) {
/* 615 */     if (this.fResolvedElements == null) {
/* 616 */       this.fResolvedElements = new HashMap<>(10);
/*     */     }
/* 618 */     for (Object dup : duplicates) {
/* 619 */       this.fResolvedElements.put(dup, sourceElement);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Object getCachedElement(Object duplicate) {
/* 631 */     if (this.fResolvedElements != null) {
/* 632 */       return this.fResolvedElements.get(duplicate);
/*     */     }
/* 634 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void clearCachedElement(Object duplicate) {
/* 645 */     if (this.fResolvedElements != null) {
/* 646 */       this.fResolvedElements.remove(duplicate);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void clearSourceElements(Object element) {
/* 652 */     List<Object> list = doSourceLookup(element);
/* 653 */     if (list.size() > 0)
/* 654 */       for (Object obj : list)
/* 655 */         clearCachedElement(obj);  
/*     */   }
/*     */   
/*     */   public void addParticipants(ISourceLookupParticipant[] participants) {
/*     */     byte b;
/*     */     int i;
/*     */     ISourceLookupParticipant[] arrayOfISourceLookupParticipant;
/* 662 */     for (i = (arrayOfISourceLookupParticipant = participants).length, b = 0; b < i; ) { ISourceLookupParticipant participant = arrayOfISourceLookupParticipant[b];
/* 663 */       addSourceLookupParticipant(participant);
/* 664 */       participant.sourceContainersChanged(this);
/*     */       b++; }
/*     */      } public void removeParticipants(ISourceLookupParticipant[] participants) {
/*     */     byte b;
/*     */     int i;
/*     */     ISourceLookupParticipant[] arrayOfISourceLookupParticipant;
/* 670 */     for (i = (arrayOfISourceLookupParticipant = participants).length, b = 0; b < i; ) { ISourceLookupParticipant participant = arrayOfISourceLookupParticipant[b];
/* 671 */       removeSourceLookupParticipant(participant);
/*     */       b++; }
/*     */   
/*     */   }
/*     */   
/*     */   public String getId() {
/* 677 */     return this.fId;
/*     */   }
/*     */ 
/*     */   
/*     */   public ISourcePathComputer getSourcePathComputer() {
/* 682 */     if (this.fComputer == null && getLaunchConfiguration() != null) {
/*     */       try {
/* 684 */         return DebugPlugin.getDefault().getLaunchManager().getSourcePathComputer(getLaunchConfiguration());
/* 685 */       } catch (CoreException coreException) {}
/*     */     }
/*     */     
/* 688 */     return this.fComputer;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setSourcePathComputer(ISourcePathComputer computer) {
/* 693 */     this.fComputer = computer;
/*     */   }
/*     */ 
/*     */   
/*     */   public Object[] findSourceElements(Object object) throws CoreException {
/* 698 */     SourceLookupQuery query = new SourceLookupQuery(object);
/* 699 */     SafeRunner.run(query);
/* 700 */     List<Object> sources = query.getSourceElements();
/* 701 */     Throwable exception = query.getException();
/* 702 */     query.dispose();
/* 703 */     if (exception != null && sources.isEmpty()) {
/* 704 */       if (exception instanceof CoreException) {
/* 705 */         throw (CoreException)exception;
/*     */       }
/* 707 */       abort(SourceLookupMessages.AbstractSourceLookupDirector_10, exception);
/*     */     } 
/* 709 */     return sources.toArray();
/*     */   }
/*     */ 
/*     */   
/*     */   public Object getSourceElement(Object element) {
/* 714 */     List<Object> sources = doSourceLookup(element);
/* 715 */     if (sources.size() == 1)
/* 716 */       return sources.get(0); 
/* 717 */     if (sources.size() > 1) {
/* 718 */       return resolveSourceElement(element, sources);
/*     */     }
/* 720 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void setCurrentParticipant(ISourceLookupParticipant participant) {
/* 730 */     this.fCurrentParticipant = participant;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ISourceLookupParticipant getCurrentParticipant() {
/* 742 */     return this.fCurrentParticipant;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.debug.core-3.21.0.jar!\org\eclipse\debug\core\sourcelookup\AbstractSourceLookupDirector.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */