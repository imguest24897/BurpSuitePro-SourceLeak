/*     */ package org.eclipse.debug.core.commands;
/*     */ 
/*     */ import java.util.Collections;
/*     */ import java.util.LinkedHashSet;
/*     */ import org.eclipse.core.runtime.CoreException;
/*     */ import org.eclipse.core.runtime.IProgressMonitor;
/*     */ import org.eclipse.core.runtime.IStatus;
/*     */ import org.eclipse.core.runtime.Status;
/*     */ import org.eclipse.core.runtime.jobs.IJobChangeEvent;
/*     */ import org.eclipse.core.runtime.jobs.IJobChangeListener;
/*     */ import org.eclipse.core.runtime.jobs.ISchedulingRule;
/*     */ import org.eclipse.core.runtime.jobs.Job;
/*     */ import org.eclipse.debug.core.DebugPlugin;
/*     */ import org.eclipse.debug.core.IRequest;
/*     */ import org.eclipse.debug.internal.core.DebugOptions;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractDebugCommand
/*     */   implements IDebugCommandHandler
/*     */ {
/*     */   private class UpdateJob
/*     */     extends Job
/*     */     implements IJobChangeListener
/*     */   {
/*     */     private IEnabledStateRequest request;
/*     */     private boolean run = false;
/*     */     
/*     */     UpdateJob(IEnabledStateRequest stateRequest) {
/*  62 */       super(AbstractDebugCommand.this.getEnabledStateTaskName());
/*  63 */       this.request = stateRequest;
/*  64 */       setSystem(true);
/*  65 */       setRule(AbstractDebugCommand.this.getEnabledStateSchedulingRule(this.request));
/*  66 */       getJobManager().addJobChangeListener(this);
/*     */     }
/*     */ 
/*     */     
/*     */     protected IStatus run(IProgressMonitor monitor) {
/*  71 */       this.run = true;
/*  72 */       if (DebugOptions.DEBUG_COMMANDS) {
/*  73 */         DebugOptions.trace("can execute command: " + AbstractDebugCommand.this);
/*     */       }
/*  75 */       if (monitor.isCanceled()) {
/*  76 */         if (DebugOptions.DEBUG_COMMANDS) {
/*  77 */           DebugOptions.trace(" >> *CANCELED* <<");
/*     */         }
/*  79 */         this.request.cancel();
/*     */       } 
/*  81 */       Object[] elements = this.request.getElements();
/*  82 */       Object[] targets = new Object[elements.length];
/*  83 */       if (!this.request.isCanceled()) {
/*  84 */         for (int i = 0; i < elements.length; i++) {
/*  85 */           targets[i] = AbstractDebugCommand.this.getTarget(elements[i]);
/*  86 */           if (targets[i] == null) {
/*  87 */             this.request.setEnabled(false);
/*  88 */             this.request.cancel();
/*  89 */             if (DebugOptions.DEBUG_COMMANDS) {
/*  90 */               DebugOptions.trace(" >> false (no adapter)");
/*     */             }
/*     */           } 
/*     */         } 
/*  94 */         if (monitor.isCanceled()) {
/*  95 */           this.request.cancel();
/*     */         }
/*     */       } 
/*  98 */       if (!this.request.isCanceled()) {
/*  99 */         targets = AbstractDebugCommand.this.coalesce(targets);
/* 100 */         monitor.beginTask(AbstractDebugCommand.this.getEnabledStateTaskName(), targets.length);
/*     */         try {
/* 102 */           boolean executable = AbstractDebugCommand.this.isExecutable(targets, monitor, this.request);
/* 103 */           if (DebugOptions.DEBUG_COMMANDS) {
/* 104 */             DebugOptions.trace(" >> " + executable);
/*     */           }
/* 106 */           this.request.setEnabled(executable);
/* 107 */         } catch (CoreException e) {
/* 108 */           this.request.setStatus(e.getStatus());
/* 109 */           this.request.setEnabled(false);
/* 110 */           if (DebugOptions.DEBUG_COMMANDS) {
/* 111 */             DebugOptions.trace(" >> ABORTED");
/* 112 */             DebugOptions.trace("\t" + e.getStatus().getMessage());
/*     */           } 
/*     */         } 
/*     */       } 
/* 116 */       monitor.setCanceled(this.request.isCanceled());
/* 117 */       this.request.done();
/* 118 */       monitor.done();
/* 119 */       return Status.OK_STATUS;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean belongsTo(Object family) {
/* 124 */       Object myFamily = AbstractDebugCommand.this.getEnabledStateJobFamily(this.request);
/* 125 */       if (myFamily != null) {
/* 126 */         return myFamily.equals(family);
/*     */       }
/* 128 */       return false;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void aboutToRun(IJobChangeEvent event) {}
/*     */ 
/*     */ 
/*     */     
/*     */     public void awake(IJobChangeEvent event) {}
/*     */ 
/*     */     
/*     */     public void done(IJobChangeEvent event) {
/* 141 */       if (event.getJob() == this) {
/* 142 */         if (!this.run) {
/* 143 */           this.request.cancel();
/* 144 */           this.request.done();
/* 145 */           if (DebugOptions.DEBUG_COMMANDS) {
/* 146 */             DebugOptions.trace(" >> *CANCELED* <<" + AbstractDebugCommand.this);
/*     */           }
/*     */         } 
/* 149 */         getJobManager().removeJobChangeListener(this);
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void running(IJobChangeEvent event) {}
/*     */ 
/*     */ 
/*     */     
/*     */     public void scheduled(IJobChangeEvent event) {}
/*     */ 
/*     */ 
/*     */     
/*     */     public void sleeping(IJobChangeEvent event) {}
/*     */ 
/*     */     
/*     */     public String toString() {
/* 167 */       return String.valueOf(getName()) + " on " + this.request;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static class SerialPerObjectRule
/*     */     implements ISchedulingRule
/*     */   {
/* 177 */     private Object fObject = null;
/*     */     
/*     */     public SerialPerObjectRule(Object lock) {
/* 180 */       this.fObject = lock;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean contains(ISchedulingRule rule) {
/* 185 */       return (rule == this);
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isConflicting(ISchedulingRule rule) {
/* 190 */       if (rule instanceof SerialPerObjectRule) {
/* 191 */         SerialPerObjectRule vup = (SerialPerObjectRule)rule;
/* 192 */         return (this.fObject == vup.fObject);
/*     */       } 
/* 194 */       return false;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean execute(final IDebugCommandRequest request) {
/* 201 */     Job job = new Job(getExecuteTaskName())
/*     */       {
/*     */         protected IStatus run(IProgressMonitor monitor) {
/* 204 */           if (DebugOptions.DEBUG_COMMANDS) {
/* 205 */             DebugOptions.trace("execute: " + AbstractDebugCommand.this);
/*     */           }
/* 207 */           Object[] elements = request.getElements();
/* 208 */           Object[] targets = new Object[elements.length];
/* 209 */           for (int i = 0; i < elements.length; i++) {
/* 210 */             targets[i] = AbstractDebugCommand.this.getTarget(elements[i]);
/*     */           }
/* 212 */           targets = AbstractDebugCommand.this.coalesce(targets);
/* 213 */           monitor.beginTask(AbstractDebugCommand.this.getExecuteTaskName(), targets.length);
/*     */           try {
/* 215 */             AbstractDebugCommand.this.doExecute(targets, monitor, request);
/* 216 */           } catch (CoreException e) {
/* 217 */             request.setStatus(e.getStatus());
/* 218 */             if (DebugOptions.DEBUG_COMMANDS) {
/* 219 */               DebugOptions.trace("\t" + e.getStatus().getMessage());
/*     */             }
/*     */           } 
/* 222 */           request.done();
/* 223 */           monitor.setCanceled(request.isCanceled());
/* 224 */           monitor.done();
/* 225 */           return Status.OK_STATUS;
/*     */         }
/*     */         
/*     */         public boolean belongsTo(Object family) {
/* 229 */           Object jobFamily = AbstractDebugCommand.this.getExecuteJobFamily(request);
/* 230 */           if (jobFamily != null) {
/* 231 */             return jobFamily.equals(family);
/*     */           }
/* 233 */           return false;
/*     */         }
/*     */       };
/* 236 */     job.setSystem(true);
/* 237 */     job.setRule(getExecuteSchedulingRule(request));
/* 238 */     job.schedule();
/* 239 */     return isRemainEnabled(request);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean isRemainEnabled(IDebugCommandRequest request) {
/* 249 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public void canExecute(IEnabledStateRequest request) {
/* 254 */     Job job = new UpdateJob(request);
/* 255 */     job.schedule();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String getEnabledStateTaskName() {
/* 266 */     return "Check Debug Command";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String getExecuteTaskName() {
/* 277 */     return "Execute Debug Command";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected abstract void doExecute(Object[] paramArrayOfObject, IProgressMonitor paramIProgressMonitor, IRequest paramIRequest) throws CoreException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected abstract boolean isExecutable(Object[] paramArrayOfObject, IProgressMonitor paramIProgressMonitor, IEnabledStateRequest paramIEnabledStateRequest) throws CoreException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected abstract Object getTarget(Object paramObject);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Object getAdapter(Object element, Class<?> type) {
/* 335 */     return DebugPlugin.getAdapter(element, type);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected ISchedulingRule getEnabledStateSchedulingRule(IDebugCommandRequest request) {
/* 349 */     return new SerialPerObjectRule(request.getElements()[0]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected ISchedulingRule getExecuteSchedulingRule(IDebugCommandRequest request) {
/* 362 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Object getEnabledStateJobFamily(IDebugCommandRequest request) {
/* 375 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Object getExecuteJobFamily(IDebugCommandRequest request) {
/* 388 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Object[] coalesce(Object[] objects) {
/* 398 */     if (objects.length == 1) {
/* 399 */       return objects;
/*     */     }
/* 401 */     LinkedHashSet<Object> set = new LinkedHashSet(objects.length);
/* 402 */     Collections.addAll(set, objects);
/* 403 */     return set.toArray();
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.debug.core-3.21.0.jar!\org\eclipse\debug\core\commands\AbstractDebugCommand.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */