/*     */ package org.eclipse.debug.internal.core.commands;
/*     */ 
/*     */ import org.eclipse.core.runtime.IAdapterFactory;
/*     */ import org.eclipse.debug.core.commands.IDisconnectHandler;
/*     */ import org.eclipse.debug.core.commands.IDropToFrameHandler;
/*     */ import org.eclipse.debug.core.commands.IResumeHandler;
/*     */ import org.eclipse.debug.core.commands.IStepFiltersHandler;
/*     */ import org.eclipse.debug.core.commands.IStepIntoHandler;
/*     */ import org.eclipse.debug.core.commands.IStepOverHandler;
/*     */ import org.eclipse.debug.core.commands.IStepReturnHandler;
/*     */ import org.eclipse.debug.core.commands.ISuspendHandler;
/*     */ import org.eclipse.debug.core.commands.ITerminateHandler;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CommandAdapterFactory
/*     */   implements IAdapterFactory
/*     */ {
/*  44 */   private static ITerminateHandler fgTerminateCommand = new TerminateCommand();
/*  45 */   private static IStepOverHandler fgStepOverCommand = new StepOverCommand();
/*  46 */   private static IStepIntoHandler fgStepIntoCommand = new StepIntoCommand();
/*  47 */   private static IStepReturnHandler fgStepReturnCommand = new StepReturnCommand();
/*  48 */   private static IDropToFrameHandler fgDropToFrameCommand = new DropToFrameCommand();
/*  49 */   private static IDisconnectHandler fgDisconnectCommand = new DisconnectCommand();
/*  50 */   private static ISuspendHandler fgSuspendCommand = new SuspendCommand();
/*  51 */   private static IResumeHandler fgResumeCommand = new ResumeCommand();
/*  52 */   private static IStepFiltersHandler fgStepFiltersCommand = new StepFiltersCommand();
/*     */ 
/*     */ 
/*     */   
/*     */   public <T> T getAdapter(Object adaptableObject, Class<T> adapterType) {
/*  57 */     if (IStepFiltersHandler.class.equals(adapterType) && (
/*  58 */       adaptableObject instanceof org.eclipse.debug.core.model.IDebugElement || 
/*  59 */       adaptableObject instanceof org.eclipse.debug.core.ILaunch || 
/*  60 */       adaptableObject instanceof org.eclipse.debug.core.model.IProcess)) {
/*  61 */       return (T)fgStepFiltersCommand;
/*     */     }
/*     */ 
/*     */     
/*  65 */     if (ITerminateHandler.class.equals(adapterType) && 
/*  66 */       adaptableObject instanceof org.eclipse.debug.core.model.ITerminate) {
/*  67 */       return (T)fgTerminateCommand;
/*     */     }
/*     */     
/*  70 */     if (IStepOverHandler.class.equals(adapterType) && 
/*  71 */       adaptableObject instanceof org.eclipse.debug.core.model.IStep) {
/*  72 */       return (T)fgStepOverCommand;
/*     */     }
/*     */     
/*  75 */     if (IStepIntoHandler.class.equals(adapterType) && 
/*  76 */       adaptableObject instanceof org.eclipse.debug.core.model.IStep) {
/*  77 */       return (T)fgStepIntoCommand;
/*     */     }
/*     */     
/*  80 */     if (IStepReturnHandler.class.equals(adapterType) && 
/*  81 */       adaptableObject instanceof org.eclipse.debug.core.model.IStep) {
/*  82 */       return (T)fgStepReturnCommand;
/*     */     }
/*     */     
/*  85 */     if (ISuspendHandler.class.equals(adapterType) && 
/*  86 */       adaptableObject instanceof org.eclipse.debug.core.model.ISuspendResume) {
/*  87 */       return (T)fgSuspendCommand;
/*     */     }
/*     */     
/*  90 */     if (IResumeHandler.class.equals(adapterType) && 
/*  91 */       adaptableObject instanceof org.eclipse.debug.core.model.ISuspendResume) {
/*  92 */       return (T)fgResumeCommand;
/*     */     }
/*     */     
/*  95 */     if (IDisconnectHandler.class.equals(adapterType) && 
/*  96 */       adaptableObject instanceof org.eclipse.debug.core.model.IDisconnect) {
/*  97 */       return (T)fgDisconnectCommand;
/*     */     }
/*     */     
/* 100 */     if (IDropToFrameHandler.class.equals(adapterType) && 
/* 101 */       adaptableObject instanceof org.eclipse.debug.core.model.IDropToFrame) {
/* 102 */       return (T)fgDropToFrameCommand;
/*     */     }
/*     */     
/* 105 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public Class<?>[] getAdapterList() {
/* 110 */     return new Class[] {
/* 111 */         ITerminateHandler.class, 
/* 112 */         IStepOverHandler.class, 
/* 113 */         IStepIntoHandler.class, 
/* 114 */         IStepReturnHandler.class, 
/* 115 */         ISuspendHandler.class, 
/* 116 */         IResumeHandler.class, 
/* 117 */         IDropToFrameHandler.class, 
/* 118 */         IDisconnectHandler.class, 
/* 119 */         IStepFiltersHandler.class
/*     */       };
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.debug.core-3.21.0.jar!\org\eclipse\debug\internal\core\commands\CommandAdapterFactory.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */