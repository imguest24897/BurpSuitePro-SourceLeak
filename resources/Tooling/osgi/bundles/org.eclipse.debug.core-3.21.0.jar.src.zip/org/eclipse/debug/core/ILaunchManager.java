/*    */ package org.eclipse.debug.core;
/*    */ 
/*    */ import java.util.Map;
/*    */ import org.eclipse.core.resources.IFile;
/*    */ import org.eclipse.core.runtime.CoreException;
/*    */ import org.eclipse.debug.core.model.IDebugTarget;
/*    */ import org.eclipse.debug.core.model.IPersistableSourceLocator;
/*    */ import org.eclipse.debug.core.model.IProcess;
/*    */ import org.eclipse.debug.core.sourcelookup.ISourceContainerType;
/*    */ import org.eclipse.debug.core.sourcelookup.ISourcePathComputer;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface ILaunchManager
/*    */ {
/*    */   public static final String RUN_MODE = "run";
/*    */   public static final String DEBUG_MODE = "debug";
/*    */   public static final String PROFILE_MODE = "profile";
/*    */   public static final String ATTR_PRIVATE = "org.eclipse.debug.ui.private";
/* 71 */   public static final String ATTR_ENVIRONMENT_VARIABLES = String.valueOf(DebugPlugin.getUniqueIdentifier()) + ".environmentVariables";
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 82 */   public static final String ATTR_APPEND_ENVIRONMENT_VARIABLES = String.valueOf(DebugPlugin.getUniqueIdentifier()) + ".appendEnvironmentVariables";
/*    */   
/*    */   void addLaunch(ILaunch paramILaunch);
/*    */   
/*    */   void addLaunchConfigurationListener(ILaunchConfigurationListener paramILaunchConfigurationListener);
/*    */   
/*    */   void addLaunches(ILaunch[] paramArrayOfILaunch);
/*    */   
/*    */   void addLaunchListener(ILaunchesListener paramILaunchesListener);
/*    */   
/*    */   void addLaunchListener(ILaunchListener paramILaunchListener);
/*    */   
/*    */   @Deprecated
/*    */   String generateUniqueLaunchConfigurationNameFrom(String paramString);
/*    */   
/*    */   String generateLaunchConfigurationName(String paramString);
/*    */   
/*    */   boolean isValidLaunchConfigurationName(String paramString) throws IllegalArgumentException;
/*    */   
/*    */   IDebugTarget[] getDebugTargets();
/*    */   
/*    */   String[] getEnvironment(ILaunchConfiguration paramILaunchConfiguration) throws CoreException;
/*    */   
/*    */   String getEncoding(ILaunchConfiguration paramILaunchConfiguration) throws CoreException;
/*    */   
/*    */   ILaunchConfiguration getLaunchConfiguration(IFile paramIFile);
/*    */   
/*    */   ILaunchConfiguration getLaunchConfiguration(String paramString) throws CoreException;
/*    */   
/*    */   ILaunchConfiguration[] getLaunchConfigurations() throws CoreException;
/*    */   
/*    */   ILaunchConfiguration[] getLaunchConfigurations(ILaunchConfigurationType paramILaunchConfigurationType) throws CoreException;
/*    */   
/*    */   ILaunchConfiguration[] getLaunchConfigurations(int paramInt) throws CoreException;
/*    */   
/*    */   ILaunchConfiguration[] getLaunchConfigurations(ILaunchConfigurationType paramILaunchConfigurationType, int paramInt) throws CoreException;
/*    */   
/*    */   ILaunchConfigurationType getLaunchConfigurationType(String paramString);
/*    */   
/*    */   ILaunchConfigurationType[] getLaunchConfigurationTypes();
/*    */   
/*    */   ILaunch[] getLaunches();
/*    */   
/*    */   ILaunchMode getLaunchMode(String paramString);
/*    */   
/*    */   ILaunchMode[] getLaunchModes();
/*    */   
/*    */   ILaunchConfiguration[] getMigrationCandidates() throws CoreException;
/*    */   
/*    */   ILaunchConfiguration getMovedFrom(ILaunchConfiguration paramILaunchConfiguration);
/*    */   
/*    */   ILaunchConfiguration getMovedTo(ILaunchConfiguration paramILaunchConfiguration);
/*    */   
/*    */   Map<String, String> getNativeEnvironment();
/*    */   
/*    */   Map<String, String> getNativeEnvironmentCasePreserved();
/*    */   
/*    */   IProcess[] getProcesses();
/*    */   
/*    */   ISourceContainerType getSourceContainerType(String paramString);
/*    */   
/*    */   ISourceContainerType[] getSourceContainerTypes();
/*    */   
/*    */   ISourcePathComputer getSourcePathComputer(ILaunchConfiguration paramILaunchConfiguration) throws CoreException;
/*    */   
/*    */   ISourcePathComputer getSourcePathComputer(String paramString);
/*    */   
/*    */   boolean isExistingLaunchConfigurationName(String paramString) throws CoreException;
/*    */   
/*    */   boolean isRegistered(ILaunch paramILaunch);
/*    */   
/*    */   IPersistableSourceLocator newSourceLocator(String paramString) throws CoreException;
/*    */   
/*    */   void removeLaunch(ILaunch paramILaunch);
/*    */   
/*    */   void removeLaunchConfigurationListener(ILaunchConfigurationListener paramILaunchConfigurationListener);
/*    */   
/*    */   void removeLaunches(ILaunch[] paramArrayOfILaunch);
/*    */   
/*    */   void removeLaunchListener(ILaunchesListener paramILaunchesListener);
/*    */   
/*    */   void removeLaunchListener(ILaunchListener paramILaunchListener);
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.debug.core-3.21.0.jar!\org\eclipse\debug\core\ILaunchManager.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */