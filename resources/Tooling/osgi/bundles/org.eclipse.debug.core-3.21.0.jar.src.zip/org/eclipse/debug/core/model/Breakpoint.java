/*     */ package org.eclipse.debug.core.model;
/*     */ 
/*     */ import java.util.Map;
/*     */ import org.eclipse.core.resources.IMarker;
/*     */ import org.eclipse.core.resources.IResource;
/*     */ import org.eclipse.core.resources.IResourceRuleFactory;
/*     */ import org.eclipse.core.resources.IWorkspace;
/*     */ import org.eclipse.core.resources.IWorkspaceRunnable;
/*     */ import org.eclipse.core.resources.ResourcesPlugin;
/*     */ import org.eclipse.core.runtime.CoreException;
/*     */ import org.eclipse.core.runtime.IProgressMonitor;
/*     */ import org.eclipse.core.runtime.PlatformObject;
/*     */ import org.eclipse.core.runtime.Status;
/*     */ import org.eclipse.core.runtime.jobs.ISchedulingRule;
/*     */ import org.eclipse.debug.core.DebugException;
/*     */ import org.eclipse.debug.core.DebugPlugin;
/*     */ import org.eclipse.debug.core.IBreakpointManager;
/*     */ import org.eclipse.debug.internal.core.BreakpointManager;
/*     */ import org.eclipse.debug.internal.core.DebugCoreMessages;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class Breakpoint
/*     */   extends PlatformObject
/*     */   implements IBreakpoint, ITriggerPoint
/*     */ {
/*     */   private IMarker fMarker;
/*     */   
/*     */   public Breakpoint() {
/*  61 */     this.fMarker = null;
/*     */     ((BreakpointManager)DebugPlugin.getDefault().getBreakpointManager()).ensureInitialized();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setMarker(IMarker marker) throws CoreException {
/*  68 */     this.fMarker = marker;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object item) {
/*  77 */     if (item instanceof IBreakpoint) {
/*  78 */       return getMarker().equals(((IBreakpoint)item).getMarker());
/*     */     }
/*  80 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/*  88 */     return getMarker().hashCode();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setEnabled(boolean enabled) throws CoreException {
/*  96 */     if (enabled != isEnabled()) {
/*  97 */       setAttribute("org.eclipse.debug.core.enabled", enabled);
/*  98 */       if (isTriggerPoint()) {
/*  99 */         DebugPlugin.getDefault().getBreakpointManager().refreshTriggerpointDisplay();
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isEnabled() throws CoreException {
/* 109 */     return getMarker().getAttribute("org.eclipse.debug.core.enabled", false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isRegistered() throws CoreException {
/* 117 */     IMarker marker = getMarker();
/* 118 */     return (marker.exists() && marker.getAttribute("org.eclipse.debug.core.registered", true));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setRegistered(boolean registered) throws CoreException {
/* 126 */     if (isRegistered() != registered) {
/* 127 */       setAttribute("org.eclipse.debug.core.registered", registered);
/* 128 */       IBreakpointManager mgr = DebugPlugin.getDefault().getBreakpointManager();
/* 129 */       if (registered) {
/* 130 */         mgr.addBreakpoint(this);
/*     */       } else {
/* 132 */         mgr.removeBreakpoint(this, false);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void delete() throws CoreException {
/* 142 */     DebugPlugin.getDefault().getBreakpointManager().removeBreakpoint(this, false);
/* 143 */     getMarker().delete();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IMarker getMarker() {
/* 151 */     return this.fMarker;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isPersisted() throws CoreException {
/* 159 */     return getMarker().getAttribute("org.eclipse.debug.core.persisted", true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setPersisted(boolean persisted) throws CoreException {
/* 167 */     if (isPersisted() != persisted) {
/* 168 */       setAttributes(new String[] { "org.eclipse.debug.core.persisted", "transient" }, new Object[] { Boolean.valueOf(persisted), Boolean.valueOf(!persisted) });
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isTriggerPoint() throws CoreException {
/* 178 */     return getMarker().getAttribute("org.eclipse.debug.core.triggerpoint", false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setTriggerPoint(boolean triggerPoint) throws CoreException {
/* 187 */     if (isTriggerPoint() != triggerPoint) {
/* 188 */       setAttribute("org.eclipse.debug.core.triggerpoint", triggerPoint);
/* 189 */       IBreakpointManager manager = DebugPlugin.getDefault().getBreakpointManager();
/* 190 */       if (triggerPoint) {
/* 191 */         manager.addTriggerPoint(this);
/*     */       } else {
/* 193 */         manager.removeTriggerPoint(this);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void setAttribute(String attributeName, boolean value) throws CoreException {
/* 210 */     IWorkspace workspace = ResourcesPlugin.getWorkspace();
/* 211 */     IWorkspaceRunnable runnable = monitor -> ensureMarker().setAttribute(paramString, paramBoolean);
/*     */     
/* 213 */     workspace.run(runnable, getMarkerRule(), 1, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void setAttribute(String attributeName, int value) throws CoreException {
/* 228 */     IWorkspace workspace = ResourcesPlugin.getWorkspace();
/* 229 */     IWorkspaceRunnable runnable = monitor -> ensureMarker().setAttribute(paramString, paramInt);
/*     */     
/* 231 */     workspace.run(runnable, getMarkerRule(), 1, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void setAttribute(String attributeName, Object value) throws CoreException {
/* 246 */     IWorkspace workspace = ResourcesPlugin.getWorkspace();
/* 247 */     IWorkspaceRunnable runnable = monitor -> ensureMarker().setAttribute(paramString, paramObject);
/*     */     
/* 249 */     workspace.run(runnable, getMarkerRule(), 1, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void setAttributes(String[] attributeNames, Object[] values) throws CoreException {
/* 264 */     IWorkspace workspace = ResourcesPlugin.getWorkspace();
/* 265 */     IWorkspaceRunnable runnable = monitor -> ensureMarker().setAttributes(paramArrayOfString, paramArrayOfObject);
/*     */     
/* 267 */     workspace.run(runnable, getMarkerRule(), 1, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void setAttributes(Map<String, ? extends Object> attributes) throws CoreException {
/* 281 */     IWorkspace workspace = ResourcesPlugin.getWorkspace();
/* 282 */     IWorkspaceRunnable runnable = monitor -> ensureMarker().setAttributes(paramMap);
/*     */     
/* 284 */     workspace.run(runnable, getMarkerRule(), 1, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected IMarker ensureMarker() throws DebugException {
/* 295 */     IMarker m = getMarker();
/* 296 */     if (m == null || !m.exists()) {
/* 297 */       throw new DebugException(new Status(4, DebugPlugin.getUniqueIdentifier(), 5012, 
/* 298 */             DebugCoreMessages.Breakpoint_no_associated_marker, null));
/*     */     }
/* 300 */     return m;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean markerExists() {
/* 310 */     IMarker m = getMarker();
/* 311 */     return (m != null && m.exists());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected ISchedulingRule getMarkerRule(IResource resource) {
/* 324 */     ISchedulingRule rule = null;
/* 325 */     if (resource != null) {
/* 326 */       IResourceRuleFactory ruleFactory = ResourcesPlugin.getWorkspace().getRuleFactory();
/* 327 */       rule = ruleFactory.markerRule(resource);
/*     */     } 
/* 329 */     return rule;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected ISchedulingRule getMarkerRule() {
/* 342 */     ISchedulingRule rule = null;
/* 343 */     IMarker marker = getMarker();
/* 344 */     if (marker != null) {
/* 345 */       IResource resource = marker.getResource();
/* 346 */       if (resource != null) {
/* 347 */         IResourceRuleFactory ruleFactory = ResourcesPlugin.getWorkspace().getRuleFactory();
/* 348 */         rule = ruleFactory.markerRule(resource);
/*     */       } 
/*     */     } 
/* 351 */     return rule;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void run(ISchedulingRule rule, IWorkspaceRunnable wr) throws DebugException {
/*     */     try {
/* 364 */       ResourcesPlugin.getWorkspace().run(wr, rule, 1, null);
/* 365 */     } catch (CoreException e) {
/* 366 */       throw new DebugException(e.getStatus());
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 372 */     StringBuilder builder = new StringBuilder(getClass().getSimpleName());
/* 373 */     builder.append(" on [");
/* 374 */     if (this.fMarker != null) {
/* 375 */       builder.append("marker=");
/* 376 */       builder.append(this.fMarker);
/*     */     } 
/* 378 */     builder.append("]");
/* 379 */     return builder.toString();
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.debug.core-3.21.0.jar!\org\eclipse\debug\core\model\Breakpoint.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */