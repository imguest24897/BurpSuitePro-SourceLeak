/*    */ package org.eclipse.debug.core.sourcelookup;
/*    */ 
/*    */ import org.eclipse.debug.core.DebugPlugin;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface ISourcePathComputer
/*    */   extends ISourcePathComputerDelegate
/*    */ {
/* 61 */   public static final String ATTR_SOURCE_PATH_COMPUTER_ID = String.valueOf(DebugPlugin.getUniqueIdentifier()) + ".SOURCE_PATH_COMPUTER_ID";
/*    */   
/*    */   String getId();
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.debug.core-3.21.0.jar!\org\eclipse\debug\core\sourcelookup\ISourcePathComputer.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */