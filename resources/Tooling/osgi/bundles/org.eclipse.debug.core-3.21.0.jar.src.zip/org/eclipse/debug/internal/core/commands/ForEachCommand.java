/*    */ package org.eclipse.debug.internal.core.commands;
/*    */ 
/*    */ import org.eclipse.core.runtime.CoreException;
/*    */ import org.eclipse.core.runtime.IProgressMonitor;
/*    */ import org.eclipse.core.runtime.jobs.ISchedulingRule;
/*    */ import org.eclipse.debug.core.IRequest;
/*    */ import org.eclipse.debug.core.commands.AbstractDebugCommand;
/*    */ import org.eclipse.debug.core.commands.IDebugCommandRequest;
/*    */ import org.eclipse.debug.core.commands.IEnabledStateRequest;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class ForEachCommand
/*    */   extends AbstractDebugCommand
/*    */ {
/* 31 */   private final ExclusiveRule exclusiveRule = new ExclusiveRule(); protected void doExecute(Object[] targets, IProgressMonitor monitor, IRequest request) throws CoreException {
/*    */     byte b;
/*    */     int i;
/*    */     Object[] arrayOfObject;
/* 35 */     for (i = (arrayOfObject = targets).length, b = 0; b < i; ) { Object target = arrayOfObject[b];
/* 36 */       execute(target);
/* 37 */       monitor.worked(1);
/*    */       b++; }
/*    */   
/*    */   }
/*    */   protected boolean isExecutable(Object[] targets, IProgressMonitor monitor, IEnabledStateRequest request) throws CoreException {
/*    */     byte b;
/*    */     int i;
/*    */     Object[] arrayOfObject;
/* 45 */     for (i = (arrayOfObject = targets).length, b = 0; b < i; ) { Object target = arrayOfObject[b];
/* 46 */       if (!isExecutable(target)) {
/* 47 */         return false;
/*    */       }
/* 49 */       monitor.worked(1); b++; }
/*    */     
/* 51 */     return true;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   protected abstract void execute(Object paramObject) throws CoreException;
/*    */ 
/*    */ 
/*    */   
/*    */   protected abstract boolean isExecutable(Object paramObject);
/*    */ 
/*    */ 
/*    */   
/*    */   protected ISchedulingRule getEnabledStateSchedulingRule(IDebugCommandRequest request) {
/* 65 */     return this.exclusiveRule;
/*    */   }
/*    */   
/*    */   static class ExclusiveRule
/*    */     implements ISchedulingRule
/*    */   {
/*    */     public boolean contains(ISchedulingRule rule) {
/* 72 */       return (rule == this);
/*    */     }
/*    */ 
/*    */     
/*    */     public boolean isConflicting(ISchedulingRule rule) {
/* 77 */       return contains(rule);
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.debug.core-3.21.0.jar!\org\eclipse\debug\internal\core\commands\ForEachCommand.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */