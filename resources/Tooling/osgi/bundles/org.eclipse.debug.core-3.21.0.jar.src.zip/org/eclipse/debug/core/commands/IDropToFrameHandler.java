package org.eclipse.debug.core.commands;

public interface IDropToFrameHandler extends IDebugCommandHandler {}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.debug.core-3.21.0.jar!\org\eclipse\debug\core\commands\IDropToFrameHandler.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */