package org.eclipse.debug.core;

import org.eclipse.core.runtime.IAdaptable;
import org.eclipse.debug.core.model.IDebugTarget;
import org.eclipse.debug.core.model.IProcess;
import org.eclipse.debug.core.model.ISourceLocator;
import org.eclipse.debug.core.model.ITerminate;

public interface ILaunch extends ITerminate, IAdaptable {
  Object[] getChildren();
  
  IDebugTarget getDebugTarget();
  
  IProcess[] getProcesses();
  
  IDebugTarget[] getDebugTargets();
  
  void addDebugTarget(IDebugTarget paramIDebugTarget);
  
  void removeDebugTarget(IDebugTarget paramIDebugTarget);
  
  void addProcess(IProcess paramIProcess);
  
  void removeProcess(IProcess paramIProcess);
  
  ISourceLocator getSourceLocator();
  
  void setSourceLocator(ISourceLocator paramISourceLocator);
  
  String getLaunchMode();
  
  ILaunchConfiguration getLaunchConfiguration();
  
  void setAttribute(String paramString1, String paramString2);
  
  String getAttribute(String paramString);
  
  boolean hasChildren();
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.debug.core-3.21.0.jar!\org\eclipse\debug\core\ILaunch.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */