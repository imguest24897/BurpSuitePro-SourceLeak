/*     */ package org.eclipse.debug.internal.core;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.eclipse.core.resources.IMarker;
/*     */ import org.eclipse.core.resources.IMarkerDelta;
/*     */ import org.eclipse.core.resources.IResource;
/*     */ import org.eclipse.core.resources.IResourceDelta;
/*     */ import org.eclipse.core.resources.IResourceDeltaVisitor;
/*     */ import org.eclipse.core.resources.IWorkspaceRunnable;
/*     */ import org.eclipse.core.runtime.CoreException;
/*     */ import org.eclipse.core.runtime.IProgressMonitor;
/*     */ import org.eclipse.debug.core.DebugPlugin;
/*     */ import org.eclipse.debug.core.model.IBreakpoint;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class BreakpointManagerVisitor
/*     */   implements IResourceDeltaVisitor
/*     */ {
/* 709 */   private List<IMarker> fMoved = new ArrayList<>();
/*     */ 
/*     */ 
/*     */   
/* 713 */   private List<IBreakpoint> fRemoved = new ArrayList<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 719 */   private List<IBreakpoint> fAdded = new ArrayList<>();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 724 */   private List<IBreakpoint> fChanged = new ArrayList<>();
/* 725 */   private List<IMarkerDelta> fChangedDeltas = new ArrayList<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void reset() {
/* 732 */     this.fMoved.clear();
/* 733 */     this.fRemoved.clear();
/* 734 */     this.fAdded.clear();
/* 735 */     this.fChanged.clear();
/* 736 */     this.fChangedDeltas.clear();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void update() {
/* 744 */     if (!this.fMoved.isEmpty()) {
/*     */       
/* 746 */       IWorkspaceRunnable wRunnable = monitor -> {
/*     */           for (IMarker marker : this.fMoved) {
/*     */             marker.delete();
/*     */           }
/*     */         };
/*     */       try {
/* 752 */         BreakpointManager.this.getWorkspace().run(wRunnable, null, 0, null);
/* 753 */       } catch (CoreException coreException) {}
/*     */     } 
/*     */     
/* 756 */     if (!this.fRemoved.isEmpty()) {
/*     */       try {
/* 758 */         BreakpointManager.this.removeBreakpoints(this.fRemoved.<IBreakpoint>toArray(new IBreakpoint[this.fRemoved.size()]), false);
/* 759 */       } catch (CoreException e) {
/* 760 */         DebugPlugin.log((Throwable)e);
/*     */       } 
/*     */     }
/* 763 */     if (!this.fAdded.isEmpty()) {
/*     */       try {
/* 765 */         IWorkspaceRunnable runnable = monitor -> {
/*     */             for (IBreakpoint breakpoint : this.fAdded) {
/*     */               breakpoint.getMarker().setAttribute("org.eclipse.debug.core.breakpointIsDeleted", false);
/*     */               breakpoint.setRegistered(true);
/*     */             } 
/*     */           };
/* 771 */         BreakpointManager.this.getWorkspace().run(runnable, null, 0, null);
/* 772 */         BreakpointManager.this.addBreakpoints(this.fAdded.<IBreakpoint>toArray(new IBreakpoint[this.fAdded.size()]), true);
/* 773 */       } catch (CoreException e) {
/* 774 */         DebugPlugin.log((Throwable)e);
/*     */       } 
/*     */     }
/* 777 */     if (!this.fChanged.isEmpty()) {
/* 778 */       BreakpointManager.this.fireUpdate(this.fChanged, this.fChangedDeltas, 2);
/*     */     }
/* 780 */     reset();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean visit(IResourceDelta delta) {
/* 788 */     if (delta == null) {
/* 789 */       return false;
/*     */     }
/* 791 */     if ((delta.getFlags() & 0x4000) != 0 && (delta.getFlags() & 0x1000) == 0) {
/* 792 */       handleProjectResourceOpenStateChange(delta.getResource());
/* 793 */       return false;
/*     */     }  byte b; int i; IMarkerDelta[] arrayOfIMarkerDelta;
/* 795 */     for (i = (arrayOfIMarkerDelta = delta.getMarkerDeltas()).length, b = 0; b < i; ) { IMarkerDelta markerDelta = arrayOfIMarkerDelta[b];
/* 796 */       if (markerDelta.isSubtypeOf(IBreakpoint.BREAKPOINT_MARKER)) {
/* 797 */         switch (markerDelta.getKind()) {
/*     */           case 1:
/* 799 */             handleAddBreakpoint(delta, markerDelta.getMarker(), markerDelta);
/*     */             break;
/*     */           case 2:
/* 802 */             handleRemoveBreakpoint(markerDelta.getMarker());
/*     */             break;
/*     */           case 4:
/* 805 */             handleChangeBreakpoint(markerDelta.getMarker(), markerDelta);
/*     */             break;
/*     */         } 
/*     */ 
/*     */       
/*     */       }
/*     */       b++; }
/*     */     
/* 813 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void handleAddBreakpoint(IResourceDelta rDelta, IMarker marker, IMarkerDelta mDelta) {
/* 823 */     if ((rDelta.getFlags() & 0x1000) != 0) {
/*     */ 
/*     */ 
/*     */       
/* 827 */       if (BreakpointManager.this.getBreakpoint(marker) == null) {
/* 828 */         this.fMoved.add(marker);
/*     */       }
/*     */     } else {
/*     */       
/* 832 */       synchronized (BreakpointManager.this.fPostChangMarkersChanged) {
/* 833 */         if (BreakpointManager.this.fPostChangMarkersChanged.contains(marker)) {
/* 834 */           handleChangeBreakpoint(marker, mDelta);
/* 835 */           BreakpointManager.this.fPostChangMarkersChanged.remove(marker);
/* 836 */         } else if (marker.getAttribute("org.eclipse.debug.core.breakpointIsDeleted", false) && BreakpointManager.this.getBreakpoint(marker) == null) {
/*     */ 
/*     */           
/*     */           try {
/*     */             
/* 841 */             IBreakpoint breakpoint = findMatchingBreakpoint(marker);
/* 842 */             if (breakpoint != null) {
/* 843 */               BreakpointManager.this.removeBreakpoint(breakpoint, true);
/*     */             }
/* 845 */             this.fAdded.add(BreakpointManager.this.createBreakpoint(marker));
/* 846 */           } catch (CoreException e) {
/* 847 */             DebugPlugin.log((Throwable)e);
/*     */           } 
/*     */         } 
/* 850 */         BreakpointManager.this.fPostBuildMarkersAdded.add(marker);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private IBreakpoint findMatchingBreakpoint(IMarker marker) {
/*     */     try {
/* 864 */       Integer line = (Integer)marker.getAttribute("lineNumber");
/* 865 */       for (IBreakpoint breakpoint : BreakpointManager.this.getBreakpoints0()) {
/* 866 */         IMarker bpMarker = breakpoint.getMarker();
/* 867 */         if (bpMarker != null && marker.getResource().equals(bpMarker.getResource()) && bpMarker.getAttribute("lineNumber", -1) == ((line == null) ? -1 : line.intValue())) {
/* 868 */           return breakpoint;
/*     */         }
/*     */       } 
/* 871 */     } catch (CoreException coreException) {}
/*     */ 
/*     */     
/* 874 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void handleRemoveBreakpoint(IMarker marker) {
/* 882 */     synchronized (BreakpointManager.this.fPostChangMarkersChanged) {
/* 883 */       BreakpointManager.this.fPostChangMarkersChanged.remove(marker);
/* 884 */       BreakpointManager.this.fPostBuildMarkersAdded.remove(marker);
/*     */     } 
/* 886 */     IBreakpoint breakpoint = BreakpointManager.this.getBreakpoint(marker);
/* 887 */     if (breakpoint != null) {
/* 888 */       this.fRemoved.add(breakpoint);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void handleChangeBreakpoint(IMarker marker, IMarkerDelta delta) {
/* 898 */     IBreakpoint breakpoint = BreakpointManager.this.getBreakpoint(marker);
/* 899 */     if (breakpoint != null && BreakpointManager.this.isRegistered(breakpoint) && !BreakpointManager.this.isChangeSuppressed(breakpoint)) {
/* 900 */       this.fChanged.add(breakpoint);
/* 901 */       this.fChangedDeltas.add(delta);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void handleProjectResourceOpenStateChange(IResource project) {
/* 911 */     if (!project.isAccessible()) {
/*     */       
/* 913 */       for (IBreakpoint breakpoint : BreakpointManager.this.getBreakpoints0().clone()) {
/* 914 */         IResource markerResource = breakpoint.getMarker().getResource();
/* 915 */         if (project.getFullPath().isPrefixOf(markerResource.getFullPath())) {
/* 916 */           this.fRemoved.add(breakpoint);
/*     */         }
/*     */       } 
/*     */       return;
/*     */     } 
/*     */     try {
/* 922 */       BreakpointManager.this.loadBreakpoints(project, true);
/* 923 */     } catch (CoreException e) {
/* 924 */       DebugPlugin.log((Throwable)e);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.debug.core-3.21.0.jar!\org\eclipse\debug\internal\core\BreakpointManager$BreakpointManagerVisitor.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */