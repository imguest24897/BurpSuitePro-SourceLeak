/*    */ package org.eclipse.debug.internal.core.sourcelookup;
/*    */ 
/*    */ import org.eclipse.core.runtime.CoreException;
/*    */ import org.eclipse.core.runtime.IConfigurationElement;
/*    */ import org.eclipse.core.runtime.Status;
/*    */ import org.eclipse.debug.core.DebugPlugin;
/*    */ import org.eclipse.debug.core.sourcelookup.ISourceContainer;
/*    */ import org.eclipse.debug.core.sourcelookup.ISourceContainerType;
/*    */ import org.eclipse.debug.core.sourcelookup.ISourceContainerTypeDelegate;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SourceContainerType
/*    */   implements ISourceContainerType
/*    */ {
/* 36 */   private ISourceContainerTypeDelegate fDelegate = null;
/*    */ 
/*    */   
/* 39 */   private IConfigurationElement fElement = null;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public SourceContainerType(IConfigurationElement element) {
/* 47 */     this.fElement = element;
/*    */   }
/*    */ 
/*    */   
/*    */   public ISourceContainer createSourceContainer(String memento) throws CoreException {
/* 52 */     return getDelegate().createSourceContainer(memento);
/*    */   }
/*    */ 
/*    */   
/*    */   public String getMemento(ISourceContainer container) throws CoreException {
/* 57 */     if (equals(container.getType())) {
/* 58 */       return getDelegate().getMemento(container);
/*    */     }
/* 60 */     Status status = new Status(4, DebugPlugin.getUniqueIdentifier(), 125, SourceLookupMessages.SourceContainerType_0, null);
/* 61 */     throw new CoreException(status);
/*    */   }
/*    */ 
/*    */   
/*    */   public String getName() {
/* 66 */     return this.fElement.getAttribute("name");
/*    */   }
/*    */ 
/*    */   
/*    */   public String getId() {
/* 71 */     return this.fElement.getAttribute("id");
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   private ISourceContainerTypeDelegate getDelegate() throws CoreException {
/* 80 */     if (this.fDelegate == null) {
/* 81 */       this.fDelegate = (ISourceContainerTypeDelegate)this.fElement.createExecutableExtension("class");
/*    */     }
/* 83 */     return this.fDelegate;
/*    */   }
/*    */ 
/*    */   
/*    */   public String getDescription() {
/* 88 */     return this.fElement.getAttribute("description");
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.debug.core-3.21.0.jar!\org\eclipse\debug\internal\core\sourcelookup\SourceContainerType.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */