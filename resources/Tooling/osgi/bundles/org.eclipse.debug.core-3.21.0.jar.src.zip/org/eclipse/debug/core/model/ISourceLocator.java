package org.eclipse.debug.core.model;

public interface ISourceLocator {
  Object getSourceElement(IStackFrame paramIStackFrame);
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.debug.core-3.21.0.jar!\org\eclipse\debug\core\model\ISourceLocator.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */