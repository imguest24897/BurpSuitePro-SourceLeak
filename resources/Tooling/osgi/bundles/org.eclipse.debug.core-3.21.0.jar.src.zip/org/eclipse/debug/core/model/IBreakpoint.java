/*    */ package org.eclipse.debug.core.model;
/*    */ 
/*    */ import org.eclipse.core.resources.IMarker;
/*    */ import org.eclipse.core.runtime.CoreException;
/*    */ import org.eclipse.core.runtime.IAdaptable;
/*    */ import org.eclipse.debug.core.DebugPlugin;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface IBreakpoint
/*    */   extends IAdaptable
/*    */ {
/* 79 */   public static final String BREAKPOINT_MARKER = String.valueOf(DebugPlugin.getUniqueIdentifier()) + ".breakpointMarker";
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 85 */   public static final String LINE_BREAKPOINT_MARKER = String.valueOf(DebugPlugin.getUniqueIdentifier()) + ".lineBreakpointMarker";
/*    */   public static final String ENABLED = "org.eclipse.debug.core.enabled";
/*    */   public static final String ID = "org.eclipse.debug.core.id";
/*    */   public static final String REGISTERED = "org.eclipse.debug.core.registered";
/*    */   public static final String PERSISTED = "org.eclipse.debug.core.persisted";
/*    */   
/*    */   void delete() throws CoreException;
/*    */   
/*    */   IMarker getMarker();
/*    */   
/*    */   void setMarker(IMarker paramIMarker) throws CoreException;
/*    */   
/*    */   String getModelIdentifier();
/*    */   
/*    */   boolean isEnabled() throws CoreException;
/*    */   
/*    */   void setEnabled(boolean paramBoolean) throws CoreException;
/*    */   
/*    */   boolean isRegistered() throws CoreException;
/*    */   
/*    */   void setRegistered(boolean paramBoolean) throws CoreException;
/*    */   
/*    */   boolean isPersisted() throws CoreException;
/*    */   
/*    */   void setPersisted(boolean paramBoolean) throws CoreException;
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.debug.core-3.21.0.jar!\org\eclipse\debug\core\model\IBreakpoint.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */