package org.eclipse.debug.core.model;

import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IAdaptable;

public interface ITriggerPoint extends IAdaptable {
  public static final String TRIGGERPOINT = "org.eclipse.debug.core.triggerpoint";
  
  boolean isTriggerPoint() throws CoreException;
  
  void setTriggerPoint(boolean paramBoolean) throws CoreException;
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.debug.core-3.21.0.jar!\org\eclipse\debug\core\model\ITriggerPoint.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */