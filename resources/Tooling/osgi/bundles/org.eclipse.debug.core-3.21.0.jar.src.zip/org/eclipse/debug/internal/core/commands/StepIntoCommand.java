/*    */ package org.eclipse.debug.internal.core.commands;
/*    */ 
/*    */ import org.eclipse.core.runtime.CoreException;
/*    */ import org.eclipse.debug.core.commands.IDebugCommandRequest;
/*    */ import org.eclipse.debug.core.commands.IStepIntoHandler;
/*    */ import org.eclipse.debug.core.model.IStep;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class StepIntoCommand
/*    */   extends StepCommand
/*    */   implements IStepIntoHandler
/*    */ {
/*    */   protected boolean isSteppable(Object target) {
/* 30 */     return ((IStep)target).canStepInto();
/*    */   }
/*    */ 
/*    */   
/*    */   protected void step(Object target) throws CoreException {
/* 35 */     ((IStep)target).stepInto();
/*    */   }
/*    */ 
/*    */   
/*    */   protected Object getEnabledStateJobFamily(IDebugCommandRequest request) {
/* 40 */     return IStepIntoHandler.class;
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.debug.core-3.21.0.jar!\org\eclipse\debug\internal\core\commands\StepIntoCommand.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */