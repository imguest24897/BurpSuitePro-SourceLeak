/*     */ package org.eclipse.debug.internal.core;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.text.MessageFormat;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Vector;
/*     */ import javax.xml.parsers.ParserConfigurationException;
/*     */ import javax.xml.transform.TransformerException;
/*     */ import org.eclipse.core.runtime.CoreException;
/*     */ import org.eclipse.core.runtime.IConfigurationElement;
/*     */ import org.eclipse.core.runtime.IExtensionPoint;
/*     */ import org.eclipse.core.runtime.ISafeRunnable;
/*     */ import org.eclipse.core.runtime.IStatus;
/*     */ import org.eclipse.core.runtime.ListenerList;
/*     */ import org.eclipse.core.runtime.Platform;
/*     */ import org.eclipse.core.runtime.PlatformObject;
/*     */ import org.eclipse.core.runtime.SafeRunner;
/*     */ import org.eclipse.core.runtime.Status;
/*     */ import org.eclipse.debug.core.DebugPlugin;
/*     */ import org.eclipse.debug.core.IExpressionListener;
/*     */ import org.eclipse.debug.core.IExpressionManager;
/*     */ import org.eclipse.debug.core.IExpressionsListener;
/*     */ import org.eclipse.debug.core.model.IExpression;
/*     */ import org.eclipse.debug.core.model.IWatchExpression;
/*     */ import org.eclipse.debug.core.model.IWatchExpressionDelegate;
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.Element;
/*     */ import org.w3c.dom.Node;
/*     */ import org.w3c.dom.NodeList;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ExpressionManager
/*     */   extends PlatformObject
/*     */   implements IExpressionManager
/*     */ {
/*  61 */   private Vector<IExpression> fExpressions = null;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  66 */   private ListenerList<IExpressionListener> fListeners = null;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  71 */   private ListenerList<IExpressionsListener> fExpressionsListeners = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  77 */   private Map<String, IConfigurationElement> fWatchExpressionDelegates = new HashMap<>();
/*     */   
/*     */   private static final int ADDED = 1;
/*     */   
/*     */   private static final int CHANGED = 2;
/*     */   
/*     */   private static final int REMOVED = 3;
/*     */   
/*     */   private static final int INSERTED = 4;
/*     */   
/*     */   private static final int MOVED = 5;
/*     */   
/*     */   private static final String PREF_WATCH_EXPRESSIONS = "prefWatchExpressions";
/*     */   private static final String WATCH_EXPRESSIONS_TAG = "watchExpressions";
/*     */   private static final String EXPRESSION_TAG = "expression";
/*     */   private static final String TEXT_TAG = "text";
/*     */   private static final String ENABLED_TAG = "enabled";
/*     */   private static final String TRUE_VALUE = "true";
/*     */   private static final String FALSE_VALUE = "false";
/*     */   
/*     */   public ExpressionManager() {
/*  98 */     loadPersistedExpressions();
/*  99 */     loadWatchExpressionDelegates();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void loadWatchExpressionDelegates() {
/* 108 */     IExtensionPoint extensionPoint = Platform.getExtensionRegistry().getExtensionPoint(DebugPlugin.getUniqueIdentifier(), "watchExpressionDelegates"); byte b; int i; IConfigurationElement[] arrayOfIConfigurationElement;
/* 109 */     for (i = (arrayOfIConfigurationElement = extensionPoint.getConfigurationElements()).length, b = 0; b < i; ) { IConfigurationElement element = arrayOfIConfigurationElement[b];
/* 110 */       if (element.getName().equals("watchExpressionDelegate")) {
/* 111 */         String debugModel = element.getAttribute("debugModel");
/* 112 */         if (debugModel != null && debugModel.length() != 0)
/*     */         {
/*     */           
/* 115 */           this.fWatchExpressionDelegates.put(debugModel, element); } 
/*     */       } 
/*     */       b++; }
/*     */   
/*     */   }
/*     */   
/*     */   public IWatchExpressionDelegate newWatchExpressionDelegate(String debugModel) {
/*     */     try {
/* 123 */       IConfigurationElement element = this.fWatchExpressionDelegates.get(debugModel);
/* 124 */       if (element != null) {
/* 125 */         return (IWatchExpressionDelegate)element.createExecutableExtension("delegateClass");
/*     */       }
/* 127 */       return null;
/* 128 */     } catch (CoreException e) {
/* 129 */       DebugPlugin.log((Throwable)e);
/* 130 */       return null;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean hasWatchExpressionDelegate(String id) {
/* 136 */     IConfigurationElement element = this.fWatchExpressionDelegates.get(id);
/* 137 */     return (element != null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void loadPersistedExpressions() {
/*     */     Element root;
/* 147 */     String expressionsString = Platform.getPreferencesService().getString(DebugPlugin.getUniqueIdentifier(), "prefWatchExpressions", "", null);
/* 148 */     if (expressionsString.length() == 0) {
/*     */       return;
/*     */     }
/*     */     
/*     */     try {
/* 153 */       root = DebugPlugin.parseDocument(expressionsString);
/* 154 */     } catch (CoreException e) {
/* 155 */       DebugPlugin.logMessage("An exception occurred while loading watch expressions.", (Throwable)e);
/*     */       return;
/*     */     } 
/* 158 */     if (!root.getNodeName().equals("watchExpressions")) {
/* 159 */       DebugPlugin.logMessage("Invalid format encountered while loading watch expressions.", null);
/*     */       return;
/*     */     } 
/* 162 */     NodeList list = root.getChildNodes();
/* 163 */     for (int i = 0, numItems = list.getLength(); i < numItems; i++) {
/* 164 */       Node node = list.item(i);
/* 165 */       if (node.getNodeType() == 1) {
/* 166 */         Element element = (Element)node;
/* 167 */         if (!element.getNodeName().equals("expression")) {
/* 168 */           DebugPlugin.logMessage(MessageFormat.format("Invalid XML element encountered while loading watch expressions: {0}", new Object[] { node.getNodeName() }), null);
/*     */         } else {
/*     */           
/* 171 */           String expressionText = element.getAttribute("text");
/* 172 */           if (expressionText.length() > 0) {
/* 173 */             boolean enabled = "true".equals(element.getAttribute("enabled"));
/* 174 */             IWatchExpression expression = newWatchExpression(expressionText, enabled);
/* 175 */             if (this.fExpressions == null) {
/* 176 */               this.fExpressions = new Vector<>(list.getLength());
/*     */             }
/* 178 */             this.fExpressions.add(expression);
/*     */           } else {
/* 180 */             DebugPlugin.logMessage("Invalid expression entry encountered while loading watch expressions. Expression text is empty.", null);
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private IWatchExpression newWatchExpression(String expressionText, boolean enabled) {
/* 195 */     return new WatchExpression(expressionText, enabled);
/*     */   }
/*     */ 
/*     */   
/*     */   public IWatchExpression newWatchExpression(String expressionText) {
/* 200 */     return new WatchExpression(expressionText);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void storeWatchExpressions() {
/* 208 */     String expressionString = "";
/*     */     try {
/* 210 */       expressionString = getWatchExpressionsAsXML();
/* 211 */     } catch (IOException e) {
/* 212 */       DebugPlugin.log(e);
/* 213 */     } catch (ParserConfigurationException e) {
/* 214 */       DebugPlugin.log(e);
/* 215 */     } catch (TransformerException e) {
/* 216 */       DebugPlugin.log(e);
/*     */     } 
/* 218 */     Preferences.setString(DebugPlugin.getUniqueIdentifier(), "prefWatchExpressions", expressionString, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String getWatchExpressionsAsXML() throws IOException, ParserConfigurationException, TransformerException {
/* 232 */     IExpression[] expressions = getExpressions();
/* 233 */     Document document = LaunchManager.getDocument();
/* 234 */     Element rootElement = document.createElement("watchExpressions");
/* 235 */     document.appendChild(rootElement); byte b; int i; IExpression[] arrayOfIExpression1;
/* 236 */     for (i = (arrayOfIExpression1 = expressions).length, b = 0; b < i; ) { IExpression expression = arrayOfIExpression1[b];
/* 237 */       if (expression instanceof IWatchExpression) {
/* 238 */         Element element = document.createElement("expression");
/* 239 */         element.setAttribute("text", expression.getExpressionText());
/* 240 */         element.setAttribute("enabled", ((IWatchExpression)expression).isEnabled() ? "true" : "false");
/* 241 */         rootElement.appendChild(element);
/*     */       }  b++; }
/*     */     
/* 244 */     return LaunchManager.serializeDocument(document);
/*     */   }
/*     */ 
/*     */   
/*     */   public void addExpression(IExpression expression) {
/* 249 */     addExpressions(new IExpression[] { expression });
/*     */   }
/*     */ 
/*     */   
/*     */   public void addExpressions(IExpression[] expressions) {
/* 254 */     List<IExpression> added = doAdd(expressions);
/* 255 */     if (!added.isEmpty()) {
/* 256 */       fireUpdate(added.<IExpression>toArray(new IExpression[added.size()]), 1);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private List<IExpression> doAdd(IExpression[] expressions) {
/* 269 */     List<IExpression> added = new ArrayList<>(expressions.length);
/* 270 */     synchronized (this) {
/* 271 */       if (this.fExpressions == null)
/* 272 */         this.fExpressions = new Vector<>(expressions.length);  byte b; int i;
/*     */       IExpression[] arrayOfIExpression;
/* 274 */       for (i = (arrayOfIExpression = expressions).length, b = 0; b < i; ) { IExpression expression = arrayOfIExpression[b];
/* 275 */         if (this.fExpressions.indexOf(expression) == -1) {
/* 276 */           added.add(expression);
/* 277 */           this.fExpressions.add(expression);
/*     */         }  b++; }
/*     */     
/*     */     } 
/* 281 */     return added;
/*     */   }
/*     */ 
/*     */   
/*     */   public synchronized IExpression[] getExpressions() {
/* 286 */     if (this.fExpressions == null) {
/* 287 */       return new IExpression[0];
/*     */     }
/* 289 */     IExpression[] temp = new IExpression[this.fExpressions.size()];
/* 290 */     this.fExpressions.copyInto((Object[])temp);
/* 291 */     return temp;
/*     */   }
/*     */ 
/*     */   
/*     */   public synchronized IExpression[] getExpressions(String modelIdentifier) {
/* 296 */     if (this.fExpressions == null) {
/* 297 */       return new IExpression[0];
/*     */     }
/* 299 */     ArrayList<IExpression> temp = new ArrayList<>(this.fExpressions.size());
/* 300 */     for (IExpression expression : this.fExpressions) {
/* 301 */       String id = expression.getModelIdentifier();
/* 302 */       if (id != null && id.equals(modelIdentifier)) {
/* 303 */         temp.add(expression);
/*     */       }
/*     */     } 
/* 306 */     return temp.<IExpression>toArray(new IExpression[temp.size()]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void insertExpressions(IExpression[] expressions, IExpression insertionLocation, boolean insertBefore) {
/* 323 */     List<IExpression> added = null;
/* 324 */     List<IExpression> inserted = null;
/* 325 */     int insertionIndex = -1;
/* 326 */     synchronized (this) {
/* 327 */       if (this.fExpressions == null || (insertionIndex = this.fExpressions.indexOf(insertionLocation)) < 0) {
/* 328 */         added = doAdd(expressions);
/*     */       } else {
/* 330 */         if (!insertBefore) {
/* 331 */           insertionIndex++;
/*     */         }
/* 333 */         inserted = new ArrayList<>(expressions.length); byte b; int i; IExpression[] arrayOfIExpression;
/* 334 */         for (i = (arrayOfIExpression = expressions).length, b = 0; b < i; ) { IExpression expression = arrayOfIExpression[b];
/* 335 */           if (this.fExpressions.indexOf(expression) == -1) {
/*     */             
/* 337 */             this.fExpressions.add(insertionIndex + inserted.size(), expression);
/* 338 */             inserted.add(expression);
/*     */           }  b++; }
/*     */       
/*     */       } 
/*     */     } 
/* 343 */     if (added != null) {
/* 344 */       if (!added.isEmpty()) {
/* 345 */         fireUpdate(added.<IExpression>toArray(new IExpression[added.size()]), 1);
/*     */       }
/*     */       return;
/*     */     } 
/* 349 */     if (inserted != null && 
/* 350 */       !inserted.isEmpty()) {
/* 351 */       fireUpdate(inserted.<IExpression>toArray(new IExpression[inserted.size()]), 4, insertionIndex);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void moveExpressions(IExpression[] expressions, IExpression insertionLocation, boolean insertBefore) {
/* 369 */     List<IExpression> movedExpressions = new ArrayList<>(expressions.length);
/* 370 */     int insertionIndex = -1;
/* 371 */     IExpression[] movedExpressionsArray = null;
/* 372 */     synchronized (this) {
/* 373 */       if (this.fExpressions == null) {
/*     */         return;
/*     */       }
/* 376 */       insertionIndex = this.fExpressions.indexOf(insertionLocation);
/* 377 */       if (insertionIndex < 0) {
/*     */         return;
/*     */       }
/* 380 */       if (!insertBefore)
/* 381 */         insertionIndex++;  byte b;
/*     */       int j;
/*     */       IExpression[] arrayOfIExpression;
/* 384 */       for (j = (arrayOfIExpression = expressions).length, b = 0; b < j; ) { IExpression expression = arrayOfIExpression[b];
/* 385 */         int removeIndex = this.fExpressions.indexOf(expression);
/* 386 */         if (removeIndex >= 0) {
/* 387 */           movedExpressions.add(expression);
/* 388 */           if (removeIndex < insertionIndex) {
/* 389 */             insertionIndex--;
/*     */           }
/* 391 */           this.fExpressions.remove(removeIndex);
/*     */         }  b++; }
/*     */       
/* 394 */       movedExpressionsArray = movedExpressions.<IExpression>toArray(new IExpression[movedExpressions.size()]);
/* 395 */       for (int i = 0; i < movedExpressionsArray.length; i++)
/*     */       {
/* 397 */         this.fExpressions.add(insertionIndex + i, movedExpressionsArray[i]);
/*     */       }
/*     */     } 
/*     */     
/* 401 */     if (!movedExpressions.isEmpty()) {
/* 402 */       fireUpdate(movedExpressionsArray, 5, insertionIndex);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void removeExpression(IExpression expression) {
/* 408 */     removeExpressions(new IExpression[] { expression });
/*     */   }
/*     */ 
/*     */   
/*     */   public void removeExpressions(IExpression[] expressions) {
/* 413 */     List<IExpression> removed = new ArrayList<>(expressions.length);
/* 414 */     synchronized (this) {
/* 415 */       if (this.fExpressions == null)
/*     */         return;  byte b; int i;
/*     */       IExpression[] arrayOfIExpression;
/* 418 */       for (i = (arrayOfIExpression = expressions).length, b = 0; b < i; ) { IExpression expression = arrayOfIExpression[b];
/* 419 */         if (this.fExpressions.remove(expression)) {
/* 420 */           removed.add(expression);
/*     */         }
/*     */         b++; }
/*     */     
/*     */     } 
/* 425 */     if (!removed.isEmpty()) {
/* 426 */       for (IExpression expression : removed) {
/* 427 */         expression.dispose();
/*     */       }
/* 429 */       fireUpdate(removed.<IExpression>toArray(new IExpression[removed.size()]), 3);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void addExpressionListener(IExpressionListener listener) {
/* 435 */     if (this.fListeners == null) {
/* 436 */       this.fListeners = new ListenerList();
/*     */     }
/* 438 */     this.fListeners.add(listener);
/*     */   }
/*     */ 
/*     */   
/*     */   public void removeExpressionListener(IExpressionListener listener) {
/* 443 */     if (this.fListeners == null) {
/*     */       return;
/*     */     }
/* 446 */     this.fListeners.remove(listener);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void watchExpressionChanged(IWatchExpression expression) {
/* 456 */     boolean notify = false;
/* 457 */     synchronized (this) {
/* 458 */       if (this.fExpressions != null && this.fExpressions.contains(expression)) {
/* 459 */         notify = true;
/*     */       }
/*     */     } 
/* 462 */     if (notify) {
/* 463 */       fireUpdate(new IExpression[] { (IExpression)expression }, 2);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void fireUpdate(IExpression[] expressions, int update) {
/* 474 */     fireUpdate(expressions, update, -1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void fireUpdate(IExpression[] expressions, int update, int index) {
/* 486 */     getExpressionNotifier().notify(expressions, update);
/*     */ 
/*     */     
/* 489 */     getExpressionsNotifier().notify(expressions, update, index);
/*     */   }
/*     */ 
/*     */   
/*     */   public synchronized boolean hasExpressions() {
/* 494 */     return (this.fExpressions != null && !this.fExpressions.isEmpty());
/*     */   }
/*     */ 
/*     */   
/*     */   public void addExpressionListener(IExpressionsListener listener) {
/* 499 */     if (this.fExpressionsListeners == null) {
/* 500 */       this.fExpressionsListeners = new ListenerList();
/*     */     }
/* 502 */     this.fExpressionsListeners.add(listener);
/*     */   }
/*     */ 
/*     */   
/*     */   public void removeExpressionListener(IExpressionsListener listener) {
/* 507 */     if (this.fExpressionsListeners == null) {
/*     */       return;
/*     */     }
/* 510 */     this.fExpressionsListeners.remove(listener);
/*     */   }
/*     */   
/*     */   private ExpressionNotifier getExpressionNotifier() {
/* 514 */     return new ExpressionNotifier();
/*     */   }
/*     */ 
/*     */   
/*     */   class ExpressionNotifier
/*     */     implements ISafeRunnable
/*     */   {
/*     */     private IExpressionListener fListener;
/*     */     
/*     */     private int fType;
/*     */     
/*     */     private IExpression fExpression;
/*     */ 
/*     */     
/*     */     public void handleException(Throwable exception) {
/* 529 */       Status status = new Status(4, DebugPlugin.getUniqueIdentifier(), 120, "An exception occurred during expression change notification.", exception);
/* 530 */       DebugPlugin.log((IStatus)status);
/*     */     }
/*     */ 
/*     */     
/*     */     public void run() throws Exception {
/* 535 */       switch (this.fType) {
/*     */         case 1:
/*     */         case 4:
/* 538 */           this.fListener.expressionAdded(this.fExpression);
/*     */           break;
/*     */         case 3:
/* 541 */           this.fListener.expressionRemoved(this.fExpression);
/*     */           break;
/*     */         case 2:
/* 544 */           this.fListener.expressionChanged(this.fExpression);
/*     */           break;
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void notify(IExpression[] expressions, int update) {
/* 558 */       if (ExpressionManager.this.fListeners != null) {
/* 559 */         this.fType = update;
/* 560 */         for (IExpressionListener iExpressionListener : ExpressionManager.this.fListeners) {
/* 561 */           this.fListener = iExpressionListener; byte b; int i; IExpression[] arrayOfIExpression;
/* 562 */           for (i = (arrayOfIExpression = expressions).length, b = 0; b < i; ) { IExpression expression = arrayOfIExpression[b];
/* 563 */             this.fExpression = expression;
/* 564 */             SafeRunner.run(this); b++; }
/*     */         
/*     */         } 
/*     */       } 
/* 568 */       this.fListener = null;
/* 569 */       this.fExpression = null;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ExpressionsNotifier getExpressionsNotifier() {
/* 578 */     return new ExpressionsNotifier();
/*     */   }
/*     */ 
/*     */   
/*     */   class ExpressionsNotifier
/*     */     implements ISafeRunnable
/*     */   {
/*     */     private IExpressionsListener fListener;
/*     */     
/*     */     private int fType;
/*     */     
/*     */     private int fIndex;
/*     */     
/*     */     private IExpression[] fNotifierExpressions;
/*     */     
/*     */     public void handleException(Throwable exception) {
/* 594 */       Status status = new Status(4, DebugPlugin.getUniqueIdentifier(), 120, "An exception occurred during expression change notification.", exception);
/* 595 */       DebugPlugin.log((IStatus)status);
/*     */     }
/*     */ 
/*     */     
/*     */     public void run() throws Exception {
/* 600 */       switch (this.fType) {
/*     */         
/*     */         case 5:
/* 603 */           if (this.fIndex >= 0 && this.fListener instanceof IExpressionsListener2) {
/* 604 */             ((IExpressionsListener2)this.fListener).expressionsMoved(this.fNotifierExpressions, this.fIndex);
/*     */           }
/*     */           break;
/*     */         
/*     */         case 4:
/* 609 */           if (this.fIndex >= 0 && this.fListener instanceof IExpressionsListener2) {
/* 610 */             ((IExpressionsListener2)this.fListener).expressionsInserted(this.fNotifierExpressions, this.fIndex); break;
/*     */           } 
/* 612 */           this.fListener.expressionsAdded(this.fNotifierExpressions);
/*     */           break;
/*     */         
/*     */         case 1:
/* 616 */           this.fListener.expressionsAdded(this.fNotifierExpressions);
/*     */           break;
/*     */         case 3:
/* 619 */           this.fListener.expressionsRemoved(this.fNotifierExpressions);
/*     */           break;
/*     */         case 2:
/* 622 */           this.fListener.expressionsChanged(this.fNotifierExpressions);
/*     */           break;
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void notify(IExpression[] expressions, int update, int index) {
/* 637 */       if (ExpressionManager.this.fExpressionsListeners != null) {
/* 638 */         this.fNotifierExpressions = expressions;
/* 639 */         this.fType = update;
/* 640 */         this.fIndex = index;
/* 641 */         for (IExpressionsListener iExpressionsListener : ExpressionManager.this.fExpressionsListeners) {
/* 642 */           this.fListener = iExpressionsListener;
/* 643 */           SafeRunner.run(this);
/*     */         } 
/*     */       } 
/* 646 */       this.fNotifierExpressions = null;
/* 647 */       this.fListener = null;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.debug.core-3.21.0.jar!\org\eclipse\debug\internal\core\ExpressionManager.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */