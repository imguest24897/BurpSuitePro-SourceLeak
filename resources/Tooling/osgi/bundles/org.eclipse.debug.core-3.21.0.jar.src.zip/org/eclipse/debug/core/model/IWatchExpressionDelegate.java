package org.eclipse.debug.core.model;

public interface IWatchExpressionDelegate {
  void evaluateExpression(String paramString, IDebugElement paramIDebugElement, IWatchExpressionListener paramIWatchExpressionListener);
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.debug.core-3.21.0.jar!\org\eclipse\debug\core\model\IWatchExpressionDelegate.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */