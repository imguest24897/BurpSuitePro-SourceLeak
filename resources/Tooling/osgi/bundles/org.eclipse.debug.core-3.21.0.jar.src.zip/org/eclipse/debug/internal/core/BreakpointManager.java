/*      */ package org.eclipse.debug.internal.core;
/*      */ 
/*      */ import java.text.MessageFormat;
/*      */ import java.util.ArrayList;
/*      */ import java.util.HashMap;
/*      */ import java.util.HashSet;
/*      */ import java.util.LinkedHashSet;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.Set;
/*      */ import java.util.Vector;
/*      */ import org.eclipse.core.resources.IMarker;
/*      */ import org.eclipse.core.resources.IMarkerDelta;
/*      */ import org.eclipse.core.resources.IProject;
/*      */ import org.eclipse.core.resources.IResource;
/*      */ import org.eclipse.core.resources.IResourceChangeEvent;
/*      */ import org.eclipse.core.resources.IResourceChangeListener;
/*      */ import org.eclipse.core.resources.IResourceDelta;
/*      */ import org.eclipse.core.resources.IResourceDeltaVisitor;
/*      */ import org.eclipse.core.resources.IWorkspace;
/*      */ import org.eclipse.core.resources.IWorkspaceRunnable;
/*      */ import org.eclipse.core.resources.ResourcesPlugin;
/*      */ import org.eclipse.core.runtime.CoreException;
/*      */ import org.eclipse.core.runtime.IConfigurationElement;
/*      */ import org.eclipse.core.runtime.IExtensionPoint;
/*      */ import org.eclipse.core.runtime.IProgressMonitor;
/*      */ import org.eclipse.core.runtime.ISafeRunnable;
/*      */ import org.eclipse.core.runtime.IStatus;
/*      */ import org.eclipse.core.runtime.ListenerList;
/*      */ import org.eclipse.core.runtime.Platform;
/*      */ import org.eclipse.core.runtime.SafeRunner;
/*      */ import org.eclipse.core.runtime.Status;
/*      */ import org.eclipse.core.runtime.jobs.Job;
/*      */ import org.eclipse.debug.core.DebugException;
/*      */ import org.eclipse.debug.core.DebugPlugin;
/*      */ import org.eclipse.debug.core.IBreakpointListener;
/*      */ import org.eclipse.debug.core.IBreakpointManager;
/*      */ import org.eclipse.debug.core.IBreakpointManagerListener;
/*      */ import org.eclipse.debug.core.IBreakpointsListener;
/*      */ import org.eclipse.debug.core.model.IBreakpoint;
/*      */ import org.eclipse.debug.core.model.IBreakpointImportParticipant;
/*      */ import org.eclipse.debug.core.model.ITriggerPoint;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class BreakpointManager
/*      */   implements IBreakpointManager, IResourceChangeListener
/*      */ {
/*      */   private static final int ADDED = 0;
/*      */   private static final int REMOVED = 1;
/*      */   private static final int CHANGED = 2;
/*      */   private Vector<IBreakpoint> fBreakpoints;
/*      */   private HashMap<String, ArrayList<BreakpointImportParticipantDelegate>> fImportParticipants;
/*      */   private IBreakpointImportParticipant fDefaultParticipant;
/*  105 */   private final Set<IMarker> fPostChangMarkersChanged = new HashSet<>();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  111 */   private final Set<IMarker> fPostBuildMarkersAdded = new HashSet<>();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  118 */   private final List<IBreakpoint> fSuppressChange = new ArrayList<>();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final HashMap<String, IConfigurationElement> fBreakpointExtensions;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final HashMap<IMarker, IBreakpoint> fMarkersToBreakpoints;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  138 */   private final ListenerList<IBreakpointListener> fBreakpointListeners = new ListenerList();
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  143 */   private ListenerList<IBreakpointsListener> fBreakpointsListeners = new ListenerList();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static BreakpointManagerVisitor fgVisitor;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  155 */   private final ListenerList<IBreakpointManagerListener> fBreakpointManagerListeners = new ListenerList();
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  160 */   private final Set<IBreakpoint> fTriggerPointBreakpointList = new LinkedHashSet<>();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  166 */   private final Set<IBreakpoint> fTriggerPointDisabledList = new LinkedHashSet<>();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   class PostChangeListener
/*      */     implements IResourceChangeListener
/*      */   {
/*  176 */     private BreakpointManager.PostChangeVisitor fVisitor = new BreakpointManager.PostChangeVisitor();
/*      */ 
/*      */     
/*      */     public void resourceChanged(IResourceChangeEvent event) {
/*  180 */       IResourceDelta delta = event.getDelta();
/*  181 */       if (delta != null) {
/*      */         try {
/*  183 */           delta.accept(this.fVisitor);
/*  184 */         } catch (CoreException ce) {
/*  185 */           DebugPlugin.log((Throwable)ce);
/*      */         } 
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static class DefaultImportParticipant
/*      */     implements IBreakpointImportParticipant
/*      */   {
/*      */     public boolean matches(Map<String, Object> attributes, IBreakpoint breakpoint) throws CoreException {
/*  202 */       IMarker marker = breakpoint.getMarker();
/*  203 */       String type = (String)attributes.get("type");
/*  204 */       Integer line = (Integer)attributes.get("lineNumber");
/*  205 */       Object localline = marker.getAttribute("lineNumber");
/*  206 */       String localtype = marker.getType();
/*  207 */       if (type.equals(localtype)) {
/*  208 */         if (line != null && line.equals(localline)) {
/*  209 */           return true;
/*      */         }
/*  211 */         if (line == null) {
/*  212 */           return true;
/*      */         }
/*      */       } 
/*  215 */       return false;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public void verify(IBreakpoint breakpoint) throws CoreException {}
/*      */   }
/*      */ 
/*      */   
/*  224 */   private PostChangeListener fPostChangeListener = new PostChangeListener();
/*      */   
/*      */   class PostChangeVisitor
/*      */     implements IResourceDeltaVisitor
/*      */   {
/*      */     public boolean visit(IResourceDelta delta) throws CoreException {
/*  230 */       if (delta == null)
/*  231 */         return false;  byte b; int i;
/*      */       IMarkerDelta[] arrayOfIMarkerDelta;
/*  233 */       for (i = (arrayOfIMarkerDelta = delta.getMarkerDeltas()).length, b = 0; b < i; ) { IMarkerDelta markerDelta = arrayOfIMarkerDelta[b];
/*  234 */         if (markerDelta.isSubtypeOf(IBreakpoint.BREAKPOINT_MARKER)) {
/*  235 */           IMarker marker; switch (markerDelta.getKind()) {
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*      */             case 4:
/*  241 */               marker = markerDelta.getMarker();
/*  242 */               synchronized (BreakpointManager.this.fPostChangMarkersChanged) {
/*  243 */                 if (!BreakpointManager.this.fPostBuildMarkersAdded.contains(marker)) {
/*  244 */                   BreakpointManager.this.fPostChangMarkersChanged.add(marker);
/*      */                 }
/*      */               } 
/*      */               break;
/*      */           } 
/*      */         
/*      */         } 
/*      */         b++; }
/*      */       
/*  253 */       return true;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public BreakpointManager() {
/*  262 */     this.fMarkersToBreakpoints = new HashMap<>(10);
/*  263 */     this.fBreakpointExtensions = new HashMap<>(15);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void loadBreakpoints(IResource resource, boolean notify) throws CoreException {
/*  274 */     initBreakpointExtensions();
/*  275 */     List<IBreakpoint> added = new ArrayList<>(); byte b; int i; IMarker[] arrayOfIMarker;
/*  276 */     for (i = (arrayOfIMarker = getPersistedMarkers(resource)).length, b = 0; b < i; ) { IMarker marker = arrayOfIMarker[b];
/*      */       try {
/*  278 */         IBreakpoint breakpoint = createBreakpoint(marker);
/*  279 */         synchronized (this.fPostChangMarkersChanged) {
/*  280 */           this.fPostBuildMarkersAdded.add(marker);
/*      */         } 
/*  282 */         if (breakpoint.isRegistered()) {
/*  283 */           added.add(breakpoint);
/*      */         }
/*      */         
/*  286 */         if (breakpoint instanceof ITriggerPoint && ((ITriggerPoint)breakpoint).isTriggerPoint()) {
/*  287 */           addTriggerPoint(breakpoint);
/*      */         }
/*  289 */       } catch (DebugException e) {
/*  290 */         DebugPlugin.log((Throwable)e);
/*      */       }  b++; }
/*      */     
/*  293 */     addBreakpoints(added.<IBreakpoint>toArray(new IBreakpoint[added.size()]), notify);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected IMarker[] getPersistedMarkers(IResource resource) throws CoreException {
/*  313 */     List<IMarker> delete = new ArrayList<>();
/*  314 */     List<IMarker> persisted = new ArrayList<>(); byte b; int i; IMarker[] arrayOfIMarker;
/*  315 */     for (i = (arrayOfIMarker = resource.findMarkers(IBreakpoint.BREAKPOINT_MARKER, true, 2)).length, b = 0; b < i; ) { IMarker marker = arrayOfIMarker[b];
/*      */ 
/*      */       
/*  318 */       String modelId = marker.getAttribute("org.eclipse.debug.core.id", null);
/*  319 */       if (modelId == null) {
/*      */         
/*  321 */         delete.add(marker);
/*  322 */       } else if (!marker.getAttribute("org.eclipse.debug.core.persisted", true)) {
/*      */ 
/*      */         
/*  325 */         delete.add(marker);
/*      */       } else {
/*  327 */         persisted.add(marker);
/*      */       } 
/*      */       b++; }
/*      */     
/*  331 */     if (!delete.isEmpty()) {
/*  332 */       IMarker[] delMarkers = delete.<IMarker>toArray(new IMarker[delete.size()]);
/*  333 */       IWorkspaceRunnable wr = pm -> {
/*      */           IMarker[] arrayOfIMarker; int i = (arrayOfIMarker = paramArrayOfIMarker).length; for (byte b = 0; b < i; b++) {
/*      */             IMarker marker = arrayOfIMarker[b]; marker.delete();
/*      */           } 
/*      */         };
/*  338 */       (new BreakpointManagerJob(wr)).schedule();
/*      */     } 
/*  340 */     return persisted.<IMarker>toArray(new IMarker[persisted.size()]);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void shutdown() {
/*  348 */     getWorkspace().removeResourceChangeListener(this);
/*  349 */     getWorkspace().removeResourceChangeListener(this.fPostChangeListener);
/*  350 */     this.fBreakpointListeners.clear();
/*  351 */     this.fBreakpointsListeners.clear();
/*  352 */     this.fBreakpointManagerListeners.clear();
/*  353 */     if (this.fImportParticipants != null) {
/*  354 */       this.fImportParticipants.clear();
/*  355 */       this.fImportParticipants = null;
/*  356 */       this.fDefaultParticipant = null;
/*      */     } 
/*  358 */     if (this.fBreakpoints != null) {
/*  359 */       this.fBreakpoints.clear();
/*  360 */       this.fBreakpoints = null;
/*      */     } 
/*  362 */     if (this.fMarkersToBreakpoints != null) {
/*  363 */       this.fMarkersToBreakpoints.clear();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void initBreakpointExtensions() {
/*  372 */     IExtensionPoint ep = Platform.getExtensionRegistry().getExtensionPoint(DebugPlugin.getUniqueIdentifier(), "breakpoints"); byte b; int i; IConfigurationElement[] arrayOfIConfigurationElement;
/*  373 */     for (i = (arrayOfIConfigurationElement = ep.getConfigurationElements()).length, b = 0; b < i; ) { IConfigurationElement element = arrayOfIConfigurationElement[b];
/*  374 */       String markerType = element.getAttribute("markerType");
/*  375 */       String className = element.getAttribute("class");
/*  376 */       if (markerType == null) {
/*  377 */         DebugPlugin.log((IStatus)new Status(4, DebugPlugin.getUniqueIdentifier(), 120, "Breakpoint extension " + element.getDeclaringExtension().getUniqueIdentifier() + " missing required attribute: markerType", null));
/*  378 */       } else if (className == null) {
/*  379 */         DebugPlugin.log((IStatus)new Status(4, DebugPlugin.getUniqueIdentifier(), 120, "Breakpoint extension " + element.getDeclaringExtension().getUniqueIdentifier() + " missing required attribute: class", null));
/*      */       } else {
/*  381 */         this.fBreakpointExtensions.put(markerType, element);
/*      */       } 
/*      */       b++; }
/*      */   
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private IWorkspace getWorkspace() {
/*  391 */     return ResourcesPlugin.getWorkspace();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public IBreakpoint getBreakpoint(IMarker marker) {
/*  400 */     getBreakpoints0();
/*  401 */     return this.fMarkersToBreakpoints.get(marker);
/*      */   }
/*      */ 
/*      */   
/*      */   public IBreakpoint[] getBreakpoints() {
/*  406 */     IBreakpoint[] temp = new IBreakpoint[0];
/*  407 */     Vector<IBreakpoint> breakpoints = getBreakpoints0();
/*  408 */     synchronized (breakpoints) {
/*  409 */       temp = new IBreakpoint[breakpoints.size()];
/*  410 */       breakpoints.copyInto((Object[])temp);
/*      */     } 
/*  412 */     return temp;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void ensureInitialized() {
/*  426 */     getBreakpoints0();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private synchronized Vector<IBreakpoint> getBreakpoints0() {
/*  436 */     if (this.fBreakpoints == null) {
/*  437 */       initializeBreakpoints();
/*      */     }
/*  439 */     return this.fBreakpoints;
/*      */   }
/*      */ 
/*      */   
/*      */   public IBreakpoint[] getBreakpoints(String modelIdentifier) {
/*  444 */     Vector<IBreakpoint> allBreakpoints = getBreakpoints0();
/*  445 */     synchronized (allBreakpoints) {
/*  446 */       ArrayList<IBreakpoint> temp = new ArrayList<>(allBreakpoints.size());
/*  447 */       for (IBreakpoint breakpoint : allBreakpoints) {
/*  448 */         String id = breakpoint.getModelIdentifier();
/*  449 */         if (id != null && id.equals(modelIdentifier)) {
/*  450 */           temp.add(breakpoint);
/*      */         }
/*      */       } 
/*  453 */       return temp.<IBreakpoint>toArray(new IBreakpoint[temp.size()]);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void initializeBreakpoints() {
/*  462 */     setBreakpoints(new Vector<>(10));
/*      */     try {
/*  464 */       loadBreakpoints((IResource)getWorkspace().getRoot(), false);
/*  465 */       getWorkspace().addResourceChangeListener(this, 16);
/*  466 */       getWorkspace().addResourceChangeListener(this.fPostChangeListener, 1);
/*  467 */     } catch (CoreException ce) {
/*  468 */       DebugPlugin.log((Throwable)ce);
/*  469 */       setBreakpoints(new Vector<>(0));
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isRegistered(IBreakpoint breakpoint) {
/*  478 */     return getBreakpoints0().contains(breakpoint);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void removeBreakpoint(IBreakpoint breakpoint, boolean delete) throws CoreException {
/*  487 */     removeBreakpoints(new IBreakpoint[] { breakpoint }, delete);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void removeBreakpoints(IBreakpoint[] breakpoints, boolean delete) throws CoreException {
/*  495 */     List<IBreakpoint> remove = new ArrayList<>(breakpoints.length);
/*  496 */     List<IBreakpoint> bps = getBreakpoints0(); byte b; int i; IBreakpoint[] arrayOfIBreakpoint;
/*  497 */     for (i = (arrayOfIBreakpoint = breakpoints).length, b = 0; b < i; ) { IBreakpoint breakpoint = arrayOfIBreakpoint[b];
/*  498 */       if (bps.contains(breakpoint))
/*  499 */         remove.add(breakpoint); 
/*      */       b++; }
/*      */     
/*  502 */     if (!remove.isEmpty()) {
/*  503 */       for (IBreakpoint breakpoint : remove) {
/*  504 */         bps.remove(breakpoint);
/*  505 */         this.fMarkersToBreakpoints.remove(breakpoint.getMarker());
/*      */         
/*  507 */         removeTriggerPoint(breakpoint);
/*      */       } 
/*  509 */       fireUpdate(remove, null, 1);
/*  510 */       refreshTriggerpointDisplay();
/*  511 */       IWorkspaceRunnable r = monitor -> {
/*      */           for (IBreakpoint breakpoint : paramList) {
/*      */             if (paramBoolean) {
/*      */               breakpoint.delete();
/*      */               
/*      */               continue;
/*      */             } 
/*      */             
/*      */             IMarker marker = breakpoint.getMarker();
/*      */             
/*      */             if (marker.exists()) {
/*      */               IProject project = breakpoint.getMarker().getResource().getProject();
/*      */               
/*      */               if (project == null || project.isOpen()) {
/*      */                 breakpoint.setRegistered(false);
/*      */               }
/*      */             } 
/*      */           } 
/*      */         };
/*  530 */       getWorkspace().run(r, null, 0, null);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public IBreakpoint createBreakpoint(IMarker marker) throws DebugException {
/*  550 */     IBreakpoint breakpoint = this.fMarkersToBreakpoints.get(marker);
/*  551 */     if (breakpoint != null) {
/*  552 */       return breakpoint;
/*      */     }
/*      */     try {
/*  555 */       IConfigurationElement config = this.fBreakpointExtensions.get(marker.getType());
/*  556 */       if (config == null) {
/*  557 */         throw new DebugException(new Status(4, DebugPlugin.getUniqueIdentifier(), 
/*  558 */               5014, MessageFormat.format(DebugCoreMessages.BreakpointManager_Missing_breakpoint_definition, new Object[] { marker.getType() }), null));
/*      */       }
/*  560 */       Object object = config.createExecutableExtension("class");
/*  561 */       if (object instanceof IBreakpoint) {
/*  562 */         breakpoint = (IBreakpoint)object;
/*  563 */         breakpoint.setMarker(marker);
/*      */       } else {
/*  565 */         DebugPlugin.log((IStatus)new Status(4, DebugPlugin.getUniqueIdentifier(), 120, "Breakpoint extension " + config.getDeclaringExtension().getUniqueIdentifier() + " missing required attribute: class", null));
/*      */       } 
/*  567 */       return breakpoint;
/*  568 */     } catch (CoreException e) {
/*  569 */       throw new DebugException(e.getStatus());
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void addBreakpoint(IBreakpoint breakpoint) throws CoreException {
/*  578 */     addBreakpoints(new IBreakpoint[] { breakpoint });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void addBreakpoints(IBreakpoint[] breakpoints) throws CoreException {
/*  586 */     addBreakpoints(breakpoints, true);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void addBreakpoints(IBreakpoint[] breakpoints, boolean notify) throws CoreException {
/*  597 */     List<IBreakpoint> added = new ArrayList<>(breakpoints.length);
/*  598 */     List<IBreakpoint> update = new ArrayList<>(); byte b; int i; IBreakpoint[] arrayOfIBreakpoint;
/*  599 */     for (i = (arrayOfIBreakpoint = breakpoints).length, b = 0; b < i; ) { IBreakpoint breakpoint = arrayOfIBreakpoint[b];
/*  600 */       if (!getBreakpoints0().contains(breakpoint)) {
/*  601 */         verifyBreakpoint(breakpoint);
/*  602 */         if (breakpoint.isRegistered()) {
/*      */           
/*  604 */           added.add(breakpoint);
/*  605 */           getBreakpoints0().add(breakpoint);
/*  606 */           this.fMarkersToBreakpoints.put(breakpoint.getMarker(), breakpoint);
/*  607 */           if (breakpoint instanceof ITriggerPoint && ((ITriggerPoint)breakpoint).isTriggerPoint()) {
/*  608 */             addTriggerPoint(breakpoint);
/*      */           }
/*      */         }
/*      */         else {
/*      */           
/*  613 */           update.add(breakpoint);
/*      */         } 
/*      */       }  b++; }
/*      */     
/*  617 */     if (notify) {
/*  618 */       fireUpdate(added, null, 0);
/*      */     }
/*  620 */     if (!update.isEmpty()) {
/*  621 */       IWorkspaceRunnable r = monitor -> {
/*      */           List<IBreakpoint> bps = getBreakpoints0();
/*      */           
/*      */           for (IBreakpoint breakpoint : paramList) {
/*      */             bps.add(breakpoint);
/*      */             
/*      */             breakpoint.setRegistered(true);
/*      */             this.fMarkersToBreakpoints.put(breakpoint.getMarker(), breakpoint);
/*      */           } 
/*      */         };
/*  631 */       this.fSuppressChange.addAll(update);
/*  632 */       getWorkspace().run(r, null, 0, null);
/*  633 */       this.fSuppressChange.removeAll(update);
/*  634 */       if (notify) {
/*  635 */         fireUpdate(update, null, 0);
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean isChangeSuppressed(IBreakpoint breakpoint) {
/*  648 */     return this.fSuppressChange.contains(breakpoint);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void fireBreakpointChanged(IBreakpoint breakpoint) {
/*  656 */     if (getBreakpoints0().contains(breakpoint)) {
/*  657 */       List<IBreakpoint> changed = new ArrayList<>();
/*  658 */       changed.add(breakpoint);
/*  659 */       fireUpdate(changed, null, 2);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void verifyBreakpoint(IBreakpoint breakpoint) throws DebugException {
/*      */     try {
/*  671 */       String id = breakpoint.getModelIdentifier();
/*  672 */       if (id == null) {
/*  673 */         throw new DebugException(new Status(4, DebugPlugin.getUniqueIdentifier(), 
/*  674 */               5014, DebugCoreMessages.BreakpointManager_Missing_model_identifier, null));
/*      */       }
/*  676 */     } catch (CoreException e) {
/*  677 */       throw new DebugException(e.getStatus());
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void resourceChanged(IResourceChangeEvent event) {
/*  688 */     IResourceDelta delta = event.getDelta();
/*  689 */     if (delta != null) {
/*      */       try {
/*  691 */         if (fgVisitor == null) {
/*  692 */           fgVisitor = new BreakpointManagerVisitor();
/*      */         }
/*  694 */         delta.accept(fgVisitor);
/*  695 */         fgVisitor.update();
/*  696 */       } catch (CoreException ce) {
/*  697 */         DebugPlugin.log((Throwable)ce);
/*      */       } 
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   class BreakpointManagerVisitor
/*      */     implements IResourceDeltaVisitor
/*      */   {
/*  709 */     private List<IMarker> fMoved = new ArrayList<>();
/*      */ 
/*      */ 
/*      */     
/*  713 */     private List<IBreakpoint> fRemoved = new ArrayList<>();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  719 */     private List<IBreakpoint> fAdded = new ArrayList<>();
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  724 */     private List<IBreakpoint> fChanged = new ArrayList<>();
/*  725 */     private List<IMarkerDelta> fChangedDeltas = new ArrayList<>();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     protected void reset() {
/*  732 */       this.fMoved.clear();
/*  733 */       this.fRemoved.clear();
/*  734 */       this.fAdded.clear();
/*  735 */       this.fChanged.clear();
/*  736 */       this.fChangedDeltas.clear();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void update() {
/*  744 */       if (!this.fMoved.isEmpty()) {
/*      */         
/*  746 */         IWorkspaceRunnable wRunnable = monitor -> {
/*      */             for (IMarker marker : this.fMoved) {
/*      */               marker.delete();
/*      */             }
/*      */           };
/*      */         try {
/*  752 */           BreakpointManager.this.getWorkspace().run(wRunnable, null, 0, null);
/*  753 */         } catch (CoreException coreException) {}
/*      */       } 
/*      */       
/*  756 */       if (!this.fRemoved.isEmpty()) {
/*      */         try {
/*  758 */           BreakpointManager.this.removeBreakpoints(this.fRemoved.<IBreakpoint>toArray(new IBreakpoint[this.fRemoved.size()]), false);
/*  759 */         } catch (CoreException e) {
/*  760 */           DebugPlugin.log((Throwable)e);
/*      */         } 
/*      */       }
/*  763 */       if (!this.fAdded.isEmpty()) {
/*      */         try {
/*  765 */           IWorkspaceRunnable runnable = monitor -> {
/*      */               for (IBreakpoint breakpoint : this.fAdded) {
/*      */                 breakpoint.getMarker().setAttribute("org.eclipse.debug.core.breakpointIsDeleted", false);
/*      */                 breakpoint.setRegistered(true);
/*      */               } 
/*      */             };
/*  771 */           BreakpointManager.this.getWorkspace().run(runnable, null, 0, null);
/*  772 */           BreakpointManager.this.addBreakpoints(this.fAdded.<IBreakpoint>toArray(new IBreakpoint[this.fAdded.size()]), true);
/*  773 */         } catch (CoreException e) {
/*  774 */           DebugPlugin.log((Throwable)e);
/*      */         } 
/*      */       }
/*  777 */       if (!this.fChanged.isEmpty()) {
/*  778 */         BreakpointManager.this.fireUpdate(this.fChanged, this.fChangedDeltas, 2);
/*      */       }
/*  780 */       reset();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public boolean visit(IResourceDelta delta) {
/*  788 */       if (delta == null) {
/*  789 */         return false;
/*      */       }
/*  791 */       if ((delta.getFlags() & 0x4000) != 0 && (delta.getFlags() & 0x1000) == 0) {
/*  792 */         handleProjectResourceOpenStateChange(delta.getResource());
/*  793 */         return false;
/*      */       }  byte b; int i; IMarkerDelta[] arrayOfIMarkerDelta;
/*  795 */       for (i = (arrayOfIMarkerDelta = delta.getMarkerDeltas()).length, b = 0; b < i; ) { IMarkerDelta markerDelta = arrayOfIMarkerDelta[b];
/*  796 */         if (markerDelta.isSubtypeOf(IBreakpoint.BREAKPOINT_MARKER)) {
/*  797 */           switch (markerDelta.getKind()) {
/*      */             case 1:
/*  799 */               handleAddBreakpoint(delta, markerDelta.getMarker(), markerDelta);
/*      */               break;
/*      */             case 2:
/*  802 */               handleRemoveBreakpoint(markerDelta.getMarker());
/*      */               break;
/*      */             case 4:
/*  805 */               handleChangeBreakpoint(markerDelta.getMarker(), markerDelta);
/*      */               break;
/*      */           } 
/*      */ 
/*      */         
/*      */         }
/*      */         b++; }
/*      */       
/*  813 */       return true;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     protected void handleAddBreakpoint(IResourceDelta rDelta, IMarker marker, IMarkerDelta mDelta) {
/*  823 */       if ((rDelta.getFlags() & 0x1000) != 0) {
/*      */ 
/*      */ 
/*      */         
/*  827 */         if (BreakpointManager.this.getBreakpoint(marker) == null) {
/*  828 */           this.fMoved.add(marker);
/*      */         }
/*      */       } else {
/*      */         
/*  832 */         synchronized (BreakpointManager.this.fPostChangMarkersChanged) {
/*  833 */           if (BreakpointManager.this.fPostChangMarkersChanged.contains(marker)) {
/*  834 */             handleChangeBreakpoint(marker, mDelta);
/*  835 */             BreakpointManager.this.fPostChangMarkersChanged.remove(marker);
/*  836 */           } else if (marker.getAttribute("org.eclipse.debug.core.breakpointIsDeleted", false) && BreakpointManager.this.getBreakpoint(marker) == null) {
/*      */ 
/*      */             
/*      */             try {
/*      */               
/*  841 */               IBreakpoint breakpoint = findMatchingBreakpoint(marker);
/*  842 */               if (breakpoint != null) {
/*  843 */                 BreakpointManager.this.removeBreakpoint(breakpoint, true);
/*      */               }
/*  845 */               this.fAdded.add(BreakpointManager.this.createBreakpoint(marker));
/*  846 */             } catch (CoreException e) {
/*  847 */               DebugPlugin.log((Throwable)e);
/*      */             } 
/*      */           } 
/*  850 */           BreakpointManager.this.fPostBuildMarkersAdded.add(marker);
/*      */         } 
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private IBreakpoint findMatchingBreakpoint(IMarker marker) {
/*      */       try {
/*  864 */         Integer line = (Integer)marker.getAttribute("lineNumber");
/*  865 */         for (IBreakpoint breakpoint : BreakpointManager.this.getBreakpoints0()) {
/*  866 */           IMarker bpMarker = breakpoint.getMarker();
/*  867 */           if (bpMarker != null && marker.getResource().equals(bpMarker.getResource()) && bpMarker.getAttribute("lineNumber", -1) == ((line == null) ? -1 : line.intValue())) {
/*  868 */             return breakpoint;
/*      */           }
/*      */         } 
/*  871 */       } catch (CoreException coreException) {}
/*      */ 
/*      */       
/*  874 */       return null;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     protected void handleRemoveBreakpoint(IMarker marker) {
/*  882 */       synchronized (BreakpointManager.this.fPostChangMarkersChanged) {
/*  883 */         BreakpointManager.this.fPostChangMarkersChanged.remove(marker);
/*  884 */         BreakpointManager.this.fPostBuildMarkersAdded.remove(marker);
/*      */       } 
/*  886 */       IBreakpoint breakpoint = BreakpointManager.this.getBreakpoint(marker);
/*  887 */       if (breakpoint != null) {
/*  888 */         this.fRemoved.add(breakpoint);
/*      */       }
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     protected void handleChangeBreakpoint(IMarker marker, IMarkerDelta delta) {
/*  898 */       IBreakpoint breakpoint = BreakpointManager.this.getBreakpoint(marker);
/*  899 */       if (breakpoint != null && BreakpointManager.this.isRegistered(breakpoint) && !BreakpointManager.this.isChangeSuppressed(breakpoint)) {
/*  900 */         this.fChanged.add(breakpoint);
/*  901 */         this.fChangedDeltas.add(delta);
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private void handleProjectResourceOpenStateChange(IResource project) {
/*  911 */       if (!project.isAccessible()) {
/*      */         
/*  913 */         for (IBreakpoint breakpoint : BreakpointManager.this.getBreakpoints0().clone()) {
/*  914 */           IResource markerResource = breakpoint.getMarker().getResource();
/*  915 */           if (project.getFullPath().isPrefixOf(markerResource.getFullPath())) {
/*  916 */             this.fRemoved.add(breakpoint);
/*      */           }
/*      */         } 
/*      */         return;
/*      */       } 
/*      */       try {
/*  922 */         BreakpointManager.this.loadBreakpoints(project, true);
/*  923 */       } catch (CoreException e) {
/*  924 */         DebugPlugin.log((Throwable)e);
/*      */       } 
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void addBreakpointListener(IBreakpointListener listener) {
/*  934 */     this.fBreakpointListeners.add(listener);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void removeBreakpointListener(IBreakpointListener listener) {
/*  942 */     this.fBreakpointListeners.remove(listener);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void fireUpdate(List<IBreakpoint> breakpoints, List<IMarkerDelta> deltas, int update) {
/*  953 */     if (breakpoints.isEmpty()) {
/*      */       return;
/*      */     }
/*  956 */     IBreakpoint[] bpArray = breakpoints.<IBreakpoint>toArray(new IBreakpoint[breakpoints.size()]);
/*  957 */     IMarkerDelta[] deltaArray = new IMarkerDelta[bpArray.length];
/*  958 */     if (deltas != null) {
/*  959 */       deltaArray = deltas.<IMarkerDelta>toArray(deltaArray);
/*      */     }
/*      */     
/*  962 */     getBreakpointNotifier().notify(bpArray, deltaArray, update);
/*      */ 
/*      */     
/*  965 */     getBreakpointsNotifier().notify(bpArray, deltaArray, update);
/*      */   }
/*      */   
/*      */   protected void setBreakpoints(Vector<IBreakpoint> breakpoints) {
/*  969 */     this.fBreakpoints = breakpoints;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean hasBreakpoints() {
/*  977 */     return !getBreakpoints0().isEmpty();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void addBreakpointListener(IBreakpointsListener listener) {
/*  985 */     this.fBreakpointsListeners.add(listener);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void removeBreakpointListener(IBreakpointsListener listener) {
/*  993 */     this.fBreakpointsListeners.remove(listener);
/*      */   }
/*      */   
/*      */   private BreakpointNotifier getBreakpointNotifier() {
/*  997 */     return new BreakpointNotifier();
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   class BreakpointNotifier
/*      */     implements ISafeRunnable
/*      */   {
/*      */     private IBreakpointListener fListener;
/*      */ 
/*      */     
/*      */     private int fType;
/*      */     
/*      */     private IMarkerDelta fDelta;
/*      */     
/*      */     private IBreakpoint fBreakpoint;
/*      */ 
/*      */     
/*      */     public void handleException(Throwable exception) {
/* 1016 */       Status status = new Status(4, DebugPlugin.getUniqueIdentifier(), 120, "An exception occurred during breakpoint change notification.", exception);
/* 1017 */       DebugPlugin.log((IStatus)status);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void run() throws Exception {
/* 1025 */       switch (this.fType) {
/*      */         case 0:
/* 1027 */           this.fListener.breakpointAdded(this.fBreakpoint);
/*      */           break;
/*      */         case 1:
/* 1030 */           this.fListener.breakpointRemoved(this.fBreakpoint, this.fDelta);
/*      */           break;
/*      */         case 2:
/* 1033 */           this.fListener.breakpointChanged(this.fBreakpoint, this.fDelta);
/*      */           break;
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void notify(IBreakpoint[] breakpoints, IMarkerDelta[] deltas, int update) {
/* 1048 */       this.fType = update;
/* 1049 */       for (IBreakpointListener iBreakpointListener : BreakpointManager.this.fBreakpointListeners) {
/* 1050 */         this.fListener = iBreakpointListener;
/* 1051 */         for (int j = 0; j < breakpoints.length; j++) {
/* 1052 */           this.fBreakpoint = breakpoints[j];
/* 1053 */           this.fDelta = deltas[j];
/* 1054 */           SafeRunner.run(this);
/*      */         } 
/*      */       } 
/* 1057 */       this.fListener = null;
/* 1058 */       this.fDelta = null;
/* 1059 */       this.fBreakpoint = null;
/*      */     }
/*      */   }
/*      */   
/*      */   private BreakpointsNotifier getBreakpointsNotifier() {
/* 1064 */     return new BreakpointsNotifier();
/*      */   }
/*      */ 
/*      */   
/*      */   class BreakpointsNotifier
/*      */     implements ISafeRunnable
/*      */   {
/*      */     private IBreakpointsListener fListener;
/*      */     
/*      */     private int fType;
/*      */     
/*      */     private IMarkerDelta[] fDeltas;
/*      */     
/*      */     private IBreakpoint[] fNotifierBreakpoints;
/*      */     
/*      */     public void handleException(Throwable exception) {
/* 1080 */       Status status = new Status(4, DebugPlugin.getUniqueIdentifier(), 120, "An exception occurred during breakpoint change notification.", exception);
/* 1081 */       DebugPlugin.log((IStatus)status);
/*      */     }
/*      */ 
/*      */     
/*      */     public void run() throws Exception {
/* 1086 */       switch (this.fType) {
/*      */         case 0:
/* 1088 */           this.fListener.breakpointsAdded(this.fNotifierBreakpoints);
/*      */           break;
/*      */         case 1:
/* 1091 */           this.fListener.breakpointsRemoved(this.fNotifierBreakpoints, this.fDeltas);
/*      */           break;
/*      */         case 2:
/* 1094 */           this.fListener.breakpointsChanged(this.fNotifierBreakpoints, this.fDeltas);
/*      */           break;
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void notify(IBreakpoint[] breakpoints, IMarkerDelta[] deltas, int update) {
/* 1109 */       this.fType = update;
/* 1110 */       this.fNotifierBreakpoints = breakpoints;
/* 1111 */       this.fDeltas = deltas;
/* 1112 */       for (IBreakpointsListener iBreakpointsListener : BreakpointManager.this.fBreakpointsListeners) {
/* 1113 */         this.fListener = iBreakpointsListener;
/* 1114 */         SafeRunner.run(this);
/*      */       } 
/* 1116 */       this.fDeltas = null;
/* 1117 */       this.fNotifierBreakpoints = null;
/* 1118 */       this.fListener = null;
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isEnabled() {
/* 1124 */     return Platform.getPreferencesService().getBoolean(DebugPlugin.getUniqueIdentifier(), IInternalDebugCoreConstants.PREF_BREAKPOINT_MANAGER_ENABLED_STATE, true, null);
/*      */   }
/*      */ 
/*      */   
/*      */   public void setEnabled(boolean enabled) {
/* 1129 */     if (isEnabled() != enabled) {
/* 1130 */       Preferences.setBoolean(DebugPlugin.getUniqueIdentifier(), IInternalDebugCoreConstants.PREF_BREAKPOINT_MANAGER_ENABLED_STATE, enabled, null);
/* 1131 */       touchAllBreakpoints();
/* 1132 */       (new BreakpointManagerNotifier()).notify(enabled);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public void addBreakpointManagerListener(IBreakpointManagerListener listener) {
/* 1138 */     this.fBreakpointManagerListeners.add(listener);
/*      */   }
/*      */ 
/*      */   
/*      */   public void removeBreakpointManagerListener(IBreakpointManagerListener listener) {
/* 1143 */     this.fBreakpointManagerListeners.remove(listener);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   class BreakpointManagerNotifier
/*      */     implements ISafeRunnable
/*      */   {
/*      */     private IBreakpointManagerListener fListener;
/*      */     
/*      */     private boolean fManagerEnabled;
/*      */ 
/*      */     
/*      */     public void handleException(Throwable exception) {
/* 1157 */       Status status = new Status(4, DebugPlugin.getUniqueIdentifier(), 120, "An exception occurred during breakpoint change notification.", exception);
/* 1158 */       DebugPlugin.log((IStatus)status);
/*      */     }
/*      */ 
/*      */     
/*      */     public void run() throws Exception {
/* 1163 */       this.fListener.breakpointManagerEnablementChanged(this.fManagerEnabled);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void notify(boolean enabled) {
/* 1172 */       this.fManagerEnabled = enabled;
/* 1173 */       for (IBreakpointManagerListener iBreakpointManagerListener : BreakpointManager.this.fBreakpointManagerListeners) {
/* 1174 */         this.fListener = iBreakpointManagerListener;
/* 1175 */         SafeRunner.run(this);
/*      */       } 
/* 1177 */       this.fListener = null;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   class BreakpointManagerTriggerPointNotifier
/*      */     implements ISafeRunnable
/*      */   {
/*      */     private IBreakpointManagerListener fListener;
/*      */     
/*      */     private IBreakpoint fManagerTriggerPoint;
/*      */ 
/*      */     
/*      */     public void handleException(Throwable exception) {
/* 1192 */       Status status = new Status(4, DebugPlugin.getUniqueIdentifier(), 120, "An exception occurred during breakpoint change notification.", exception);
/* 1193 */       DebugPlugin.log((IStatus)status);
/*      */     }
/*      */ 
/*      */     
/*      */     public void run() throws Exception {
/* 1198 */       this.fListener.breakpointManagerTriggerPointChanged(this.fManagerTriggerPoint);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void notify(IBreakpoint triggerBreakpoint) {
/* 1207 */       this.fManagerTriggerPoint = triggerBreakpoint;
/* 1208 */       for (IBreakpointManagerListener iBreakpointManagerListener : BreakpointManager.this.fBreakpointManagerListeners) {
/* 1209 */         this.fListener = iBreakpointManagerListener;
/* 1210 */         SafeRunner.run(this);
/*      */       } 
/* 1212 */       this.fListener = null;
/*      */     }
/*      */   }
/*      */   
/*      */   class BreakpointManagerJob
/*      */     extends Job {
/*      */     private final IWorkspaceRunnable fRunnable;
/*      */     
/*      */     public BreakpointManagerJob(IWorkspaceRunnable wRunnable) {
/* 1221 */       super("breakpoint manager job");
/* 1222 */       this.fRunnable = wRunnable;
/* 1223 */       setSystem(true);
/*      */     }
/*      */ 
/*      */     
/*      */     protected IStatus run(IProgressMonitor monitor) {
/*      */       try {
/* 1229 */         BreakpointManager.this.getWorkspace().run(this.fRunnable, null, 0, null);
/* 1230 */       } catch (CoreException ce) {
/* 1231 */         DebugPlugin.log((Throwable)ce);
/*      */       } 
/* 1233 */       return (IStatus)new Status(0, DebugPlugin.getUniqueIdentifier(), 0, "", null);
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   public String getTypeName(IBreakpoint breakpoint) {
/* 1239 */     String typeName = null;
/* 1240 */     IMarker marker = breakpoint.getMarker();
/* 1241 */     if (marker != null) {
/*      */       try {
/* 1243 */         IConfigurationElement element = this.fBreakpointExtensions.get(marker.getType());
/* 1244 */         if (element != null) {
/* 1245 */           typeName = element.getAttribute("name");
/*      */         }
/*      */       }
/* 1248 */       catch (CoreException coreException) {}
/*      */     }
/* 1250 */     return typeName;
/*      */   }
/*      */ 
/*      */   
/*      */   public IBreakpointImportParticipant[] getImportParticipants(String markertype) throws CoreException {
/* 1255 */     initializeImportParticipants();
/* 1256 */     ArrayList<BreakpointImportParticipantDelegate> list = this.fImportParticipants.get(markertype);
/* 1257 */     if (list == null) {
/* 1258 */       return new IBreakpointImportParticipant[] { this.fDefaultParticipant };
/*      */     }
/* 1260 */     IBreakpointImportParticipant[] participants = new IBreakpointImportParticipant[list.size()];
/* 1261 */     BreakpointImportParticipantDelegate delegate = null;
/* 1262 */     for (int i = 0; i < list.size(); i++) {
/* 1263 */       delegate = list.get(i);
/* 1264 */       participants[i] = delegate.getDelegate();
/*      */     } 
/* 1266 */     if (participants.length == 0) {
/* 1267 */       return new IBreakpointImportParticipant[] { this.fDefaultParticipant };
/*      */     }
/* 1269 */     return participants;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private synchronized void initializeImportParticipants() {
/* 1277 */     if (this.fImportParticipants == null) {
/* 1278 */       this.fImportParticipants = new HashMap<>();
/* 1279 */       this.fDefaultParticipant = new DefaultImportParticipant();
/* 1280 */       IExtensionPoint ep = Platform.getExtensionRegistry().getExtensionPoint(DebugPlugin.getUniqueIdentifier(), "breakpointImportParticipants");
/* 1281 */       String type = null;
/* 1282 */       ArrayList<BreakpointImportParticipantDelegate> list = null; byte b; int i; IConfigurationElement[] arrayOfIConfigurationElement;
/* 1283 */       for (i = (arrayOfIConfigurationElement = ep.getConfigurationElements()).length, b = 0; b < i; ) { IConfigurationElement element = arrayOfIConfigurationElement[b];
/* 1284 */         type = element.getAttribute("type");
/* 1285 */         if (type != null) {
/* 1286 */           list = this.fImportParticipants.get(type);
/* 1287 */           if (list == null) {
/* 1288 */             list = new ArrayList<>();
/* 1289 */             this.fImportParticipants.put(type, list);
/*      */           } 
/* 1291 */           list.add(new BreakpointImportParticipantDelegate(element));
/*      */         } 
/*      */         b++; }
/*      */     
/*      */     } 
/*      */   }
/*      */   
/*      */   public IBreakpoint[] getTriggerPoints() {
/* 1299 */     return this.fTriggerPointBreakpointList.<IBreakpoint>toArray(new IBreakpoint[0]);
/*      */   }
/*      */ 
/*      */   
/*      */   public void addTriggerPoint(IBreakpoint triggerPoint) throws CoreException {
/* 1304 */     if (triggerPoint == null) {
/*      */       return;
/*      */     }
/* 1307 */     this.fTriggerPointBreakpointList.add(triggerPoint);
/* 1308 */     (new BreakpointManagerTriggerPointNotifier()).notify(triggerPoint);
/*      */   }
/*      */ 
/*      */   
/*      */   public void removeTriggerPoint(IBreakpoint breakpoint) throws CoreException {
/* 1313 */     if (breakpoint != null) {
/* 1314 */       this.fTriggerPointBreakpointList.remove(breakpoint);
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   public void removeAllTriggerPoints() throws CoreException {
/* 1320 */     IBreakpoint[] triggerPointBreakpointList = getTriggerPoints(); byte b; int i; IBreakpoint[] arrayOfIBreakpoint1;
/* 1321 */     for (i = (arrayOfIBreakpoint1 = triggerPointBreakpointList).length, b = 0; b < i; ) { IBreakpoint iBreakpoint = arrayOfIBreakpoint1[b];
/* 1322 */       if (iBreakpoint instanceof ITriggerPoint)
/* 1323 */         ((ITriggerPoint)iBreakpoint).setTriggerPoint(false); 
/*      */       b++; }
/*      */     
/* 1326 */     refreshTriggerpointDisplay();
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean hasActiveTriggerPoints() {
/* 1331 */     if (this.fTriggerPointBreakpointList.isEmpty()) {
/* 1332 */       return false;
/*      */     }
/* 1334 */     for (IBreakpoint iBreakpoint : this.fTriggerPointBreakpointList) {
/*      */       try {
/* 1336 */         if (iBreakpoint.isEnabled()) {
/* 1337 */           return true;
/*      */         }
/* 1339 */       } catch (CoreException coreException) {}
/*      */     } 
/*      */ 
/*      */     
/* 1343 */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   public void enableTriggerPoints(IBreakpoint[] triggerPoints, boolean enable) {
/* 1348 */     IBreakpoint[] triggerPointArray = triggerPoints;
/* 1349 */     if (triggerPoints == null) {
/* 1350 */       if (enable) {
/* 1351 */         synchronized (this.fTriggerPointDisabledList) {
/* 1352 */           triggerPointArray = this.fTriggerPointDisabledList.<IBreakpoint>toArray(new IBreakpoint[0]);
/*      */         } 
/*      */       } else {
/* 1355 */         triggerPointArray = getTriggerPoints();
/*      */       } 
/*      */     }
/* 1358 */     List<IBreakpoint> toDisable = new ArrayList<>(); byte b; int i; IBreakpoint[] arrayOfIBreakpoint1;
/* 1359 */     for (i = (arrayOfIBreakpoint1 = triggerPointArray).length, b = 0; b < i; ) { IBreakpoint iBreakpoint = arrayOfIBreakpoint1[b];
/*      */       try {
/* 1361 */         IMarker m = iBreakpoint.getMarker();
/* 1362 */         if (m != null && m.exists()) {
/* 1363 */           if (!enable && iBreakpoint.isEnabled()) {
/* 1364 */             toDisable.add(iBreakpoint);
/*      */           }
/* 1366 */           iBreakpoint.setEnabled(enable);
/*      */         } 
/* 1368 */       } catch (CoreException coreException) {}
/*      */       
/*      */       b++; }
/*      */     
/* 1372 */     synchronized (this.fTriggerPointDisabledList) {
/* 1373 */       this.fTriggerPointDisabledList.clear();
/* 1374 */       if (!enable) {
/* 1375 */         this.fTriggerPointDisabledList.addAll(toDisable);
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public void refreshTriggerpointDisplay() {
/* 1382 */     touchAllBreakpoints();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void touchAllBreakpoints() {
/* 1389 */     IWorkspaceRunnable runnable = monitor -> {
/*      */         IBreakpoint[] arrayOfIBreakpoint;
/*      */         
/*      */         int i = (arrayOfIBreakpoint = getBreakpoints()).length;
/*      */         for (byte b = 0; b < i; b++) {
/*      */           IBreakpoint breakpoint = arrayOfIBreakpoint[b];
/*      */           try {
/*      */             breakpoint.getMarker().setAttribute("org.eclipse.debug.core.enabled", breakpoint.isEnabled());
/* 1397 */           } catch (CoreException coreException) {}
/*      */         } 
/*      */       };
/*      */ 
/*      */     
/*      */     try {
/* 1403 */       ResourcesPlugin.getWorkspace().run(runnable, null, 1, null);
/* 1404 */     } catch (CoreException e) {
/* 1405 */       DebugPlugin.log((Throwable)e);
/*      */     } 
/*      */   }
/*      */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.debug.core-3.21.0.jar!\org\eclipse\debug\internal\core\BreakpointManager.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */