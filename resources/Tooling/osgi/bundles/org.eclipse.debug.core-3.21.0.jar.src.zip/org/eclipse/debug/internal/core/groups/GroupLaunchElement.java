/*    */ package org.eclipse.debug.internal.core.groups;
/*    */ 
/*    */ import org.eclipse.debug.core.ILaunchConfiguration;
/*    */ import org.eclipse.debug.internal.core.DebugCoreMessages;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class GroupLaunchElement
/*    */ {
/*    */   public static final String MODE_INHERIT = "inherit";
/*    */   public int index;
/*    */   public boolean enabled;
/*    */   public String mode;
/*    */   public GroupElementPostLaunchAction action;
/*    */   public boolean adoptIfRunning;
/*    */   public Object actionParam;
/*    */   public String name;
/*    */   public ILaunchConfiguration data;
/*    */   
/*    */   public GroupLaunchElement() {
/* 64 */     this.enabled = true;
/* 65 */     this.mode = "inherit";
/* 66 */     this.action = GroupElementPostLaunchAction.NONE;
/* 67 */     this.adoptIfRunning = false;
/*    */   }
/*    */   
/*    */   public enum GroupElementPostLaunchAction {
/*    */     NONE(DebugCoreMessages.GroupLaunchConfigurationDelegate_None),
/*    */     WAIT_FOR_TERMINATION(DebugCoreMessages.GroupLaunchConfigurationDelegate_Wait_until_terminated),
/*    */     DELAY(DebugCoreMessages.GroupLaunchConfigurationDelegate_Delay),
/*    */     OUTPUT_REGEXP(DebugCoreMessages.GroupLaunchElement_outputRegexp);
/*    */     private final String description;
/*    */     
/*    */     GroupElementPostLaunchAction(String description) {
/*    */       this.description = description;
/*    */     }
/*    */     
/*    */     public String getDescription() {
/*    */       return this.description;
/*    */     }
/*    */     
/*    */     public static GroupElementPostLaunchAction valueOfDescription(String desc) {
/*    */       byte b;
/*    */       int i;
/*    */       GroupElementPostLaunchAction[] arrayOfGroupElementPostLaunchAction;
/*    */       for (i = (arrayOfGroupElementPostLaunchAction = values()).length, b = 0; b < i; ) {
/*    */         GroupElementPostLaunchAction e = arrayOfGroupElementPostLaunchAction[b];
/*    */         if (e.description.equals(desc))
/*    */           return e; 
/*    */         b++;
/*    */       } 
/*    */       return NONE;
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.debug.core-3.21.0.jar!\org\eclipse\debug\internal\core\groups\GroupLaunchElement.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */