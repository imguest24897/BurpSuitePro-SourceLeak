package org.eclipse.debug.core.model;

import org.eclipse.debug.core.DebugException;

public interface IValueModification {
  void setValue(String paramString) throws DebugException;
  
  void setValue(IValue paramIValue) throws DebugException;
  
  boolean supportsValueModification();
  
  boolean verifyValue(String paramString) throws DebugException;
  
  boolean verifyValue(IValue paramIValue) throws DebugException;
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.debug.core-3.21.0.jar!\org\eclipse\debug\core\model\IValueModification.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */