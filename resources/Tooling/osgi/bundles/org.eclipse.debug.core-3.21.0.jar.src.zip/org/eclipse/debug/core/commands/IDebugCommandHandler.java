package org.eclipse.debug.core.commands;

public interface IDebugCommandHandler {
  void canExecute(IEnabledStateRequest paramIEnabledStateRequest);
  
  boolean execute(IDebugCommandRequest paramIDebugCommandRequest);
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.debug.core-3.21.0.jar!\org\eclipse\debug\core\commands\IDebugCommandHandler.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */