/*     */ package org.eclipse.debug.internal.core;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import org.eclipse.core.runtime.ISafeRunnable;
/*     */ import org.eclipse.core.runtime.SafeRunner;
/*     */ import org.eclipse.debug.core.DebugEvent;
/*     */ import org.eclipse.debug.core.DebugException;
/*     */ import org.eclipse.debug.core.DebugPlugin;
/*     */ import org.eclipse.debug.core.IDebugEventSetListener;
/*     */ import org.eclipse.debug.core.IMemoryBlockListener;
/*     */ import org.eclipse.debug.core.IMemoryBlockManager;
/*     */ import org.eclipse.debug.core.model.IDebugTarget;
/*     */ import org.eclipse.debug.core.model.IMemoryBlock;
/*     */ import org.eclipse.debug.core.model.IMemoryBlockExtension;
/*     */ import org.eclipse.debug.core.model.IMemoryBlockRetrieval;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MemoryBlockManager
/*     */   implements IMemoryBlockManager, IDebugEventSetListener
/*     */ {
/*  43 */   private ArrayList<IMemoryBlockListener> listeners = new ArrayList<>();
/*  44 */   private ArrayList<IMemoryBlock> memoryBlocks = new ArrayList<>();
/*     */   
/*     */   private static final int ADDED = 0;
/*     */   
/*     */   private static final int REMOVED = 1;
/*     */ 
/*     */   
/*     */   class MemoryBlockNotifier
/*     */     implements ISafeRunnable
/*     */   {
/*     */     private IMemoryBlockListener fListener;
/*     */     
/*     */     private int fType;
/*     */     private IMemoryBlock[] fMemoryBlocks;
/*     */     
/*     */     public void handleException(Throwable exception) {
/*  60 */       DebugPlugin.log(exception);
/*     */     }
/*     */ 
/*     */     
/*     */     public void run() throws Exception {
/*  65 */       switch (this.fType) {
/*     */         case 0:
/*  67 */           this.fListener.memoryBlocksAdded(this.fMemoryBlocks);
/*     */           break;
/*     */         case 1:
/*  70 */           this.fListener.memoryBlocksRemoved(this.fMemoryBlocks);
/*     */           break;
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void notify(IMemoryBlock[] memBlocks, int update) {
/*  84 */       if (MemoryBlockManager.this.listeners != null) {
/*  85 */         this.fType = update;
/*  86 */         Object[] copiedListeners = MemoryBlockManager.this.listeners.toArray((Object[])new IMemoryBlockListener[MemoryBlockManager.this.listeners.size()]); byte b; int i; Object[] arrayOfObject1;
/*  87 */         for (i = (arrayOfObject1 = copiedListeners).length, b = 0; b < i; ) { Object copiedListener = arrayOfObject1[b];
/*  88 */           this.fListener = (IMemoryBlockListener)copiedListener;
/*  89 */           this.fMemoryBlocks = memBlocks;
/*  90 */           SafeRunner.run(this); b++; }
/*     */       
/*     */       } 
/*  93 */       this.fListener = null;
/*  94 */       this.fMemoryBlocks = null;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private MemoryBlockNotifier getMemoryBlockNotifier() {
/* 106 */     return new MemoryBlockNotifier();
/*     */   }
/*     */ 
/*     */   
/*     */   public void addMemoryBlocks(IMemoryBlock[] mem) {
/* 111 */     if (this.memoryBlocks == null) {
/*     */       return;
/*     */     }
/* 114 */     if (mem == null) {
/* 115 */       DebugPlugin.logMessage("Null argument passed into IMemoryBlockManager.addMemoryBlock", null);
/*     */       
/*     */       return;
/*     */     } 
/* 119 */     if (mem.length > 0) {
/* 120 */       ArrayList<IMemoryBlock> newMemoryBlocks = new ArrayList<>(); byte b; int i; IMemoryBlock[] arrayOfIMemoryBlock;
/* 121 */       for (i = (arrayOfIMemoryBlock = mem).length, b = 0; b < i; ) { IMemoryBlock m = arrayOfIMemoryBlock[b];
/*     */         
/* 123 */         if (!this.memoryBlocks.contains(m)) {
/* 124 */           newMemoryBlocks.add(m);
/* 125 */           this.memoryBlocks.add(m);
/*     */           
/* 127 */           if (this.memoryBlocks.size() == 1)
/* 128 */             DebugPlugin.getDefault().addDebugEventListener(this); 
/*     */         } 
/*     */         b++; }
/*     */       
/* 132 */       notifyListeners(newMemoryBlocks.<IMemoryBlock>toArray(new IMemoryBlock[newMemoryBlocks.size()]), 0);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void removeMemoryBlocks(IMemoryBlock[] memBlocks) {
/* 138 */     if (this.memoryBlocks == null) {
/*     */       return;
/*     */     }
/* 141 */     if (memBlocks == null) {
/* 142 */       DebugPlugin.logMessage("Null argument passed into IMemoryBlockManager.removeMemoryBlock", null);
/*     */       
/*     */       return;
/*     */     } 
/* 146 */     if (memBlocks.length > 0) {
/* 147 */       byte b; int i; IMemoryBlock[] arrayOfIMemoryBlock; for (i = (arrayOfIMemoryBlock = memBlocks).length, b = 0; b < i; ) { IMemoryBlock memBlock = arrayOfIMemoryBlock[b];
/* 148 */         this.memoryBlocks.remove(memBlock);
/*     */         
/* 150 */         if (this.memoryBlocks.isEmpty()) {
/* 151 */           DebugPlugin.getDefault().removeDebugEventListener(this);
/*     */         }
/* 153 */         if (memBlock instanceof IMemoryBlockExtension)
/*     */           try {
/* 155 */             ((IMemoryBlockExtension)memBlock).dispose();
/* 156 */           } catch (DebugException e) {
/* 157 */             DebugPlugin.log((Throwable)e);
/*     */           }  
/*     */         b++; }
/*     */       
/* 161 */       notifyListeners(memBlocks, 1);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void addListener(IMemoryBlockListener listener) {
/* 168 */     if (this.listeners == null) {
/*     */       return;
/*     */     }
/* 171 */     if (listener == null) {
/* 172 */       DebugPlugin.logMessage("Null argument passed into IMemoryBlockManager.addListener", null);
/*     */       return;
/*     */     } 
/* 175 */     if (!this.listeners.contains(listener)) {
/* 176 */       this.listeners.add(listener);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void removeListener(IMemoryBlockListener listener) {
/* 183 */     if (this.listeners == null) {
/*     */       return;
/*     */     }
/* 186 */     if (listener == null) {
/* 187 */       DebugPlugin.logMessage("Null argument passed into IMemoryBlockManager.removeListener", null);
/*     */       return;
/*     */     } 
/* 190 */     if (this.listeners.contains(listener)) {
/* 191 */       this.listeners.remove(listener);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public IMemoryBlock[] getMemoryBlocks() {
/* 197 */     return this.memoryBlocks.<IMemoryBlock>toArray(new IMemoryBlock[this.memoryBlocks.size()]);
/*     */   }
/*     */ 
/*     */   
/*     */   public IMemoryBlock[] getMemoryBlocks(IDebugTarget debugTarget) {
/* 202 */     ArrayList<IMemoryBlock> memoryBlocksList = new ArrayList<>();
/* 203 */     for (IMemoryBlock block : this.memoryBlocks) {
/* 204 */       if (block.getDebugTarget() == debugTarget) {
/* 205 */         memoryBlocksList.add(block);
/*     */       }
/*     */     } 
/* 208 */     return memoryBlocksList.<IMemoryBlock>toArray(new IMemoryBlock[memoryBlocksList.size()]);
/*     */   }
/*     */ 
/*     */   
/*     */   public IMemoryBlock[] getMemoryBlocks(IMemoryBlockRetrieval retrieve) {
/* 213 */     ArrayList<IMemoryBlock> memoryBlocksList = new ArrayList<>();
/* 214 */     for (IMemoryBlock block : this.memoryBlocks) {
/* 215 */       IDebugTarget iDebugTarget; if (block instanceof IMemoryBlockExtension) {
/* 216 */         if (((IMemoryBlockExtension)block).getMemoryBlockRetrieval() == retrieve) {
/* 217 */           memoryBlocksList.add(block);
/*     */         }
/*     */         continue;
/*     */       } 
/* 221 */       IMemoryBlockRetrieval mbRetrieval = (IMemoryBlockRetrieval)block.getAdapter(IMemoryBlockRetrieval.class);
/*     */       
/* 223 */       if (mbRetrieval == null) {
/* 224 */         iDebugTarget = block.getDebugTarget();
/*     */       }
/* 226 */       if (iDebugTarget == retrieve) {
/* 227 */         memoryBlocksList.add(block);
/*     */       }
/*     */     } 
/*     */     
/* 231 */     return memoryBlocksList.<IMemoryBlock>toArray(new IMemoryBlock[memoryBlocksList.size()]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void notifyListeners(IMemoryBlock[] memBlocks, int event) {
/* 240 */     getMemoryBlockNotifier().notify(memBlocks, event);
/*     */   } public void handleDebugEvents(DebugEvent[] events) {
/*     */     byte b;
/*     */     int i;
/*     */     DebugEvent[] arrayOfDebugEvent;
/* 245 */     for (i = (arrayOfDebugEvent = events).length, b = 0; b < i; ) { DebugEvent event = arrayOfDebugEvent[b];
/* 246 */       handleDebugEvent(event);
/*     */       b++; }
/*     */   
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void handleDebugEvent(DebugEvent event) {
/* 255 */     Object obj = event.getSource();
/* 256 */     IDebugTarget dt = null;
/*     */     
/* 258 */     if (event.getKind() == 8)
/*     */     {
/*     */       
/* 261 */       if (obj instanceof IDebugTarget) {
/* 262 */         dt = (IDebugTarget)obj;
/*     */ 
/*     */         
/* 265 */         IMemoryBlock[] deletedMemoryBlocks = getMemoryBlocks(dt);
/* 266 */         removeMemoryBlocks(deletedMemoryBlocks);
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void shutdown() {
/* 275 */     if (this.listeners != null) {
/* 276 */       this.listeners.clear();
/* 277 */       this.listeners = null;
/*     */     } 
/*     */     
/* 280 */     if (this.memoryBlocks != null) {
/* 281 */       this.memoryBlocks.clear();
/* 282 */       this.memoryBlocks = null;
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.debug.core-3.21.0.jar!\org\eclipse\debug\internal\core\MemoryBlockManager.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */