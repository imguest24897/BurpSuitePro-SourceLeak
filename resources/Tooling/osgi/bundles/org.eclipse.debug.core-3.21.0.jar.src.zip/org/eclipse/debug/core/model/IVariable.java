package org.eclipse.debug.core.model;

import org.eclipse.debug.core.DebugException;

public interface IVariable extends IDebugElement, IValueModification {
  IValue getValue() throws DebugException;
  
  String getName() throws DebugException;
  
  String getReferenceTypeName() throws DebugException;
  
  boolean hasValueChanged() throws DebugException;
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.debug.core-3.21.0.jar!\org\eclipse\debug\core\model\IVariable.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */