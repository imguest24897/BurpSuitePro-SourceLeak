package org.eclipse.debug.core;

import org.eclipse.core.resources.IMarker;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.debug.core.model.IBreakpoint;
import org.eclipse.debug.core.model.IBreakpointImportParticipant;

public interface IBreakpointManager {
  void addBreakpoint(IBreakpoint paramIBreakpoint) throws CoreException;
  
  void addBreakpoints(IBreakpoint[] paramArrayOfIBreakpoint) throws CoreException;
  
  IBreakpoint getBreakpoint(IMarker paramIMarker);
  
  IBreakpoint[] getBreakpoints();
  
  boolean hasBreakpoints();
  
  IBreakpoint[] getBreakpoints(String paramString);
  
  boolean isRegistered(IBreakpoint paramIBreakpoint);
  
  void fireBreakpointChanged(IBreakpoint paramIBreakpoint);
  
  void removeBreakpoint(IBreakpoint paramIBreakpoint, boolean paramBoolean) throws CoreException;
  
  void removeBreakpoints(IBreakpoint[] paramArrayOfIBreakpoint, boolean paramBoolean) throws CoreException;
  
  void addBreakpointListener(IBreakpointListener paramIBreakpointListener);
  
  void removeBreakpointListener(IBreakpointListener paramIBreakpointListener);
  
  void addBreakpointListener(IBreakpointsListener paramIBreakpointsListener);
  
  void removeBreakpointListener(IBreakpointsListener paramIBreakpointsListener);
  
  void addBreakpointManagerListener(IBreakpointManagerListener paramIBreakpointManagerListener);
  
  void removeBreakpointManagerListener(IBreakpointManagerListener paramIBreakpointManagerListener);
  
  boolean isEnabled();
  
  void setEnabled(boolean paramBoolean);
  
  String getTypeName(IBreakpoint paramIBreakpoint);
  
  IBreakpointImportParticipant[] getImportParticipants(String paramString) throws CoreException;
  
  IBreakpoint[] getTriggerPoints();
  
  void addTriggerPoint(IBreakpoint paramIBreakpoint) throws CoreException;
  
  void removeTriggerPoint(IBreakpoint paramIBreakpoint) throws CoreException;
  
  void removeAllTriggerPoints() throws CoreException;
  
  boolean hasActiveTriggerPoints();
  
  void enableTriggerPoints(IBreakpoint[] paramArrayOfIBreakpoint, boolean paramBoolean);
  
  void refreshTriggerpointDisplay();
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.debug.core-3.21.0.jar!\org\eclipse\debug\core\IBreakpointManager.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */