/*     */ package org.eclipse.debug.internal.core.variables;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.net.URI;
/*     */ import java.text.MessageFormat;
/*     */ import org.eclipse.core.filesystem.EFS;
/*     */ import org.eclipse.core.resources.IResource;
/*     */ import org.eclipse.core.resources.IWorkspaceRoot;
/*     */ import org.eclipse.core.resources.ResourcesPlugin;
/*     */ import org.eclipse.core.runtime.CoreException;
/*     */ import org.eclipse.core.runtime.IPath;
/*     */ import org.eclipse.core.runtime.Path;
/*     */ import org.eclipse.core.runtime.Status;
/*     */ import org.eclipse.core.variables.IDynamicVariable;
/*     */ import org.eclipse.core.variables.IDynamicVariableResolver;
/*     */ import org.eclipse.core.variables.IStringVariableManager;
/*     */ import org.eclipse.core.variables.VariablesPlugin;
/*     */ import org.eclipse.debug.core.DebugPlugin;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ResourceResolver
/*     */   implements IDynamicVariableResolver
/*     */ {
/*     */   public String resolveValue(IDynamicVariable variable, String argument) throws CoreException {
/*  45 */     IResource resource = null;
/*  46 */     if (argument == null) {
/*  47 */       resource = getSelectedResource(variable);
/*     */     } else {
/*  49 */       resource = getWorkspaceRoot().findMember((IPath)new Path(argument));
/*     */     } 
/*  51 */     if (resource != null && resource.exists()) {
/*  52 */       resource = translateSelectedResource(resource);
/*  53 */       if (resource != null && resource.exists()) {
/*  54 */         return translateToValue(resource, variable);
/*     */       }
/*     */     } 
/*  57 */     abort(MessageFormat.format(Messages.ResourceResolver_0, new Object[] { getReferenceExpression(variable, argument) }), null);
/*  58 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected IResource translateSelectedResource(IResource resource) {
/*  71 */     return resource;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected IWorkspaceRoot getWorkspaceRoot() {
/*  80 */     return ResourcesPlugin.getWorkspace().getRoot();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String getReferenceExpression(IDynamicVariable variable, String argument) {
/*  92 */     StringBuilder reference = new StringBuilder();
/*  93 */     reference.append("${");
/*  94 */     reference.append(variable.getName());
/*  95 */     if (argument != null) {
/*  96 */       reference.append(":");
/*  97 */       reference.append(argument);
/*     */     } 
/*  99 */     reference.append("}");
/* 100 */     return reference.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void abort(String message, Throwable exception) throws CoreException {
/* 111 */     throw new CoreException(new Status(4, DebugPlugin.getUniqueIdentifier(), 120, message, exception));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected IResource getSelectedResource(IDynamicVariable variable) throws CoreException {
/* 125 */     IStringVariableManager manager = VariablesPlugin.getDefault().getStringVariableManager();
/*     */     try {
/* 127 */       String pathString = manager.performStringSubstitution("${selected_resource_path}");
/* 128 */       return ResourcesPlugin.getWorkspace().getRoot().findMember((IPath)new Path(pathString));
/* 129 */     } catch (CoreException coreException) {
/*     */ 
/*     */       
/* 132 */       abort(MessageFormat.format(Messages.ResourceResolver_1, new Object[] { getReferenceExpression(variable, null) }), null);
/* 133 */       return null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String translateToValue(IResource resource, IDynamicVariable variable) throws CoreException {
/* 145 */     String name = variable.getName();
/* 146 */     IPath path = null;
/* 147 */     URI uri = null;
/* 148 */     if (name.endsWith("_loc")) {
/* 149 */       uri = resource.getLocationURI();
/* 150 */       if (uri != null) {
/* 151 */         File file = EFS.getStore(uri).toLocalFile(0, null);
/* 152 */         if (file != null) {
/* 153 */           return file.getAbsolutePath();
/*     */         }
/*     */       } 
/* 156 */     } else if (name.endsWith("_path")) {
/* 157 */       path = resource.getFullPath();
/* 158 */       if (path != null) {
/* 159 */         return path.toOSString();
/*     */       }
/* 161 */     } else if (name.endsWith("_name")) {
/* 162 */       return resource.getName();
/*     */     } 
/* 164 */     abort(MessageFormat.format(Messages.ResourceResolver_2, new Object[] { getReferenceExpression(variable, null) }), null);
/* 165 */     return null;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.debug.core-3.21.0.jar!\org\eclipse\debug\internal\core\variables\ResourceResolver.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */