/*    */ package org.eclipse.debug.internal.core.sourcelookup.containers;
/*    */ 
/*    */ import org.eclipse.core.resources.IContainer;
/*    */ import org.eclipse.core.resources.IFolder;
/*    */ import org.eclipse.core.resources.IWorkspace;
/*    */ import org.eclipse.core.resources.ResourcesPlugin;
/*    */ import org.eclipse.core.runtime.CoreException;
/*    */ import org.eclipse.core.runtime.IPath;
/*    */ import org.eclipse.core.runtime.Path;
/*    */ import org.eclipse.debug.core.sourcelookup.ISourceContainer;
/*    */ import org.eclipse.debug.core.sourcelookup.containers.AbstractSourceContainerTypeDelegate;
/*    */ import org.eclipse.debug.core.sourcelookup.containers.FolderSourceContainer;
/*    */ import org.eclipse.debug.internal.core.sourcelookup.SourceLookupMessages;
/*    */ import org.w3c.dom.Document;
/*    */ import org.w3c.dom.Element;
/*    */ import org.w3c.dom.Node;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FolderSourceContainerType
/*    */   extends AbstractSourceContainerTypeDelegate
/*    */ {
/*    */   public String getMemento(ISourceContainer container) throws CoreException {
/* 38 */     FolderSourceContainer folderSourceContainer = (FolderSourceContainer)container;
/* 39 */     Document document = newDocument();
/* 40 */     Element element = document.createElement("folder");
/* 41 */     element.setAttribute("path", folderSourceContainer.getContainer().getFullPath().toString());
/* 42 */     String nest = "false";
/* 43 */     if (folderSourceContainer.isComposite()) {
/* 44 */       nest = "true";
/*    */     }
/* 46 */     element.setAttribute("nest", nest);
/* 47 */     document.appendChild(element);
/* 48 */     return serializeDocument(document);
/*    */   }
/*    */ 
/*    */   
/*    */   public ISourceContainer createSourceContainer(String memento) throws CoreException {
/* 53 */     Node node = parseDocument(memento);
/* 54 */     if (node.getNodeType() == 1) {
/* 55 */       Element element = (Element)node;
/* 56 */       if ("folder".equals(element.getNodeName())) {
/* 57 */         String string = element.getAttribute("path");
/* 58 */         if (string == null || string.length() == 0) {
/* 59 */           abort(SourceLookupMessages.FolderSourceContainerType_10, null);
/*    */         }
/* 61 */         String nest = element.getAttribute("nest");
/* 62 */         boolean nested = "true".equals(nest);
/* 63 */         IWorkspace workspace = ResourcesPlugin.getWorkspace();
/* 64 */         IFolder folder = workspace.getRoot().getFolder((IPath)new Path(string));
/* 65 */         return (ISourceContainer)new FolderSourceContainer((IContainer)folder, nested);
/*    */       } 
/* 67 */       abort(SourceLookupMessages.FolderSourceContainerType_11, null);
/*    */     } 
/* 69 */     abort(SourceLookupMessages.FolderSourceContainerType_12, null);
/* 70 */     return null;
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.debug.core-3.21.0.jar!\org\eclipse\debug\internal\core\sourcelookup\containers\FolderSourceContainerType.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */