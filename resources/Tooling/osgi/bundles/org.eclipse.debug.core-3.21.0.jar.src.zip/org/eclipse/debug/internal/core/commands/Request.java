/*    */ package org.eclipse.debug.internal.core.commands;
/*    */ 
/*    */ import org.eclipse.core.runtime.IStatus;
/*    */ import org.eclipse.debug.core.IRequest;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Request
/*    */   implements IRequest
/*    */ {
/*    */   private IStatus fStatus;
/*    */   private boolean fCanceled = false;
/*    */   
/*    */   public void done() {}
/*    */   
/*    */   public IStatus getStatus() {
/* 34 */     return this.fStatus;
/*    */   }
/*    */ 
/*    */   
/*    */   public void setStatus(IStatus status) {
/* 39 */     this.fStatus = status;
/*    */   }
/*    */ 
/*    */   
/*    */   public synchronized void cancel() {
/* 44 */     this.fCanceled = true;
/*    */   }
/*    */ 
/*    */   
/*    */   public synchronized boolean isCanceled() {
/* 49 */     return this.fCanceled;
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.debug.core-3.21.0.jar!\org\eclipse\debug\internal\core\commands\Request.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */