/*     */ package org.eclipse.debug.core.model;
/*     */ 
/*     */ import java.text.MessageFormat;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import org.eclipse.core.resources.IMarker;
/*     */ import org.eclipse.core.resources.IProject;
/*     */ import org.eclipse.core.resources.IWorkspace;
/*     */ import org.eclipse.core.resources.IWorkspaceRunnable;
/*     */ import org.eclipse.core.resources.ResourcesPlugin;
/*     */ import org.eclipse.core.runtime.CoreException;
/*     */ import org.eclipse.core.runtime.IAdaptable;
/*     */ import org.eclipse.core.runtime.IProgressMonitor;
/*     */ import org.eclipse.core.runtime.IStatus;
/*     */ import org.eclipse.core.runtime.OperationCanceledException;
/*     */ import org.eclipse.core.runtime.Status;
/*     */ import org.eclipse.core.runtime.SubMonitor;
/*     */ import org.eclipse.debug.core.DebugPlugin;
/*     */ import org.eclipse.debug.core.IBreakpointManager;
/*     */ import org.eclipse.debug.core.ILaunch;
/*     */ import org.eclipse.debug.core.ILaunchConfiguration;
/*     */ import org.eclipse.debug.core.IStatusHandler;
/*     */ import org.eclipse.debug.internal.core.DebugCoreMessages;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class LaunchConfigurationDelegate
/*     */   implements ILaunchConfigurationDelegate2
/*     */ {
/*     */   private static final String DEBUG_CORE = "org.eclipse.debug.core";
/*     */   private static final String DEBUG_UI = "org.eclipse.debug.ui";
/*  79 */   protected static final IStatus promptStatus = (IStatus)new Status(1, "org.eclipse.debug.ui", 200, "", null);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  85 */   protected static final IStatus switchToDebugPromptStatus = (IStatus)new Status(1, "org.eclipse.debug.core", 201, "", null);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  91 */   protected static final IStatus complileErrorPromptStatus = (IStatus)new Status(1, "org.eclipse.debug.core", 202, "", null);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  99 */   protected static final IStatus saveScopedDirtyEditors = (IStatus)new Status(1, "org.eclipse.debug.core", 222, "", null);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 109 */   protected static final IStatus complileErrorProjectPromptStatus = (IStatus)new Status(1, "org.eclipse.debug.core", 203, "", null);
/*     */ 
/*     */   
/*     */   public ILaunch getLaunch(ILaunchConfiguration configuration, String mode) throws CoreException {
/* 113 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean buildForLaunch(ILaunchConfiguration configuration, String mode, IProgressMonitor monitor) throws CoreException {
/* 118 */     IProject[] projects = getBuildOrder(configuration, mode);
/* 119 */     if (projects == null) {
/* 120 */       return true;
/*     */     }
/* 122 */     buildProjects(projects, (IProgressMonitor)SubMonitor.convert(monitor, 1));
/* 123 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected IProject[] getBuildOrder(ILaunchConfiguration configuration, String mode) throws CoreException {
/* 137 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected IProject[] getProjectsForProblemSearch(ILaunchConfiguration configuration, String mode) throws CoreException {
/* 150 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean finalLaunchCheck(ILaunchConfiguration configuration, String mode, IProgressMonitor monitor) throws CoreException {
/* 155 */     monitor.beginTask("", 1);
/*     */     try {
/* 157 */       IProject[] projects = getProjectsForProblemSearch(configuration, mode);
/* 158 */       if (projects == null) {
/* 159 */         return true;
/*     */       }
/* 161 */       boolean continueLaunch = true;
/*     */       
/* 163 */       monitor.subTask(DebugCoreMessages.LaunchConfigurationDelegate_6);
/* 164 */       List<IAdaptable> errors = new ArrayList<>(); byte b; int i; IProject[] arrayOfIProject1;
/* 165 */       for (i = (arrayOfIProject1 = projects).length, b = 0; b < i; ) { IProject project = arrayOfIProject1[b];
/* 166 */         monitor.subTask(MessageFormat.format(DebugCoreMessages.LaunchConfigurationDelegate_7, new Object[] { project.getName() }));
/* 167 */         if (existsProblems(project))
/* 168 */           errors.add(project); 
/*     */         b++; }
/*     */       
/* 171 */       if (!errors.isEmpty()) {
/* 172 */         errors.add(0, configuration);
/* 173 */         IStatusHandler prompter = DebugPlugin.getDefault().getStatusHandler(promptStatus);
/* 174 */         if (prompter != null) {
/* 175 */           continueLaunch = ((Boolean)prompter.handleStatus(complileErrorProjectPromptStatus, errors)).booleanValue();
/*     */         }
/*     */       } 
/*     */       
/* 179 */       return continueLaunch;
/*     */     } finally {
/* 181 */       monitor.done();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean preLaunchCheck(ILaunchConfiguration configuration, String mode, IProgressMonitor monitor) throws CoreException {
/* 197 */     if (!saveBeforeLaunch(configuration, mode, monitor)) {
/* 198 */       return false;
/*     */     }
/* 200 */     if (mode.equals("run") && configuration.supportsMode("debug")) {
/* 201 */       IBreakpoint[] breakpoints = getBreakpoints(configuration);
/* 202 */       if (breakpoints == null)
/* 203 */         return true;  byte b; int i;
/*     */       IBreakpoint[] arrayOfIBreakpoint1;
/* 205 */       for (i = (arrayOfIBreakpoint1 = breakpoints).length, b = 0; b < i; ) { IBreakpoint breakpoint = arrayOfIBreakpoint1[b];
/* 206 */         if (breakpoint.isEnabled()) {
/* 207 */           IStatusHandler prompter = DebugPlugin.getDefault().getStatusHandler(promptStatus);
/* 208 */           if (prompter != null) {
/* 209 */             boolean launchInDebugModeInstead = ((Boolean)prompter.handleStatus(switchToDebugPromptStatus, configuration)).booleanValue();
/* 210 */             if (launchInDebugModeInstead) {
/* 211 */               return false;
/*     */             }
/*     */           } 
/*     */           
/* 215 */           return true;
/*     */         } 
/*     */         b++; }
/*     */     
/*     */     } 
/* 220 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean saveBeforeLaunch(ILaunchConfiguration configuration, String mode, IProgressMonitor monitor) throws CoreException {
/* 239 */     monitor.beginTask("", 1);
/*     */     try {
/* 241 */       IStatusHandler prompter = DebugPlugin.getDefault().getStatusHandler(promptStatus);
/* 242 */       if (prompter != null) {
/*     */         
/* 244 */         IProject[] buildOrder = getBuildOrder(configuration, mode);
/* 245 */         if (!((Boolean)prompter.handleStatus(saveScopedDirtyEditors, new Object[] { configuration, buildOrder })).booleanValue()) {
/* 246 */           return false;
/*     */         }
/*     */       } 
/* 249 */       return true;
/*     */     } finally {
/* 251 */       monitor.done();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected IBreakpoint[] getBreakpoints(ILaunchConfiguration configuration) {
/* 264 */     IBreakpointManager breakpointManager = DebugPlugin.getDefault().getBreakpointManager();
/* 265 */     if (!breakpointManager.isEnabled())
/*     */     {
/* 267 */       return null;
/*     */     }
/* 269 */     return breakpointManager.getBreakpoints();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected IProject[] computeReferencedBuildOrder(IProject[] baseProjects) throws CoreException {
/* 284 */     HashSet<IProject> unorderedProjects = new HashSet<>(); byte b; int i; IProject[] arrayOfIProject1;
/* 285 */     for (i = (arrayOfIProject1 = baseProjects).length, b = 0; b < i; ) { IProject baseProject = arrayOfIProject1[b];
/* 286 */       unorderedProjects.add(baseProject);
/* 287 */       addReferencedProjects(baseProject, unorderedProjects); b++; }
/*     */     
/* 289 */     IProject[] projectSet = unorderedProjects.<IProject>toArray(new IProject[unorderedProjects.size()]);
/* 290 */     return computeBuildOrder(projectSet);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void addReferencedProjects(IProject project, Set<IProject> references) throws CoreException {
/* 304 */     if (project.isOpen()) {
/* 305 */       byte b; int i; IProject[] arrayOfIProject; for (i = (arrayOfIProject = project.getReferencedProjects()).length, b = 0; b < i; ) { IProject refProject = arrayOfIProject[b];
/* 306 */         if (refProject.exists() && !references.contains(refProject)) {
/* 307 */           references.add(refProject);
/* 308 */           addReferencedProjects(refProject, references);
/*     */         } 
/*     */         b++; }
/*     */     
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected IProject[] computeBuildOrder(IProject[] projects) {
/* 323 */     String[] orderedNames = ResourcesPlugin.getWorkspace().getDescription().getBuildOrder();
/* 324 */     if (orderedNames != null) {
/* 325 */       List<IProject> orderedProjects = new ArrayList<>(projects.length);
/*     */       
/* 327 */       List<IProject> unorderedProjects = new ArrayList<>(projects.length);
/* 328 */       Collections.addAll(unorderedProjects, projects); byte b; int i;
/*     */       String[] arrayOfString;
/* 330 */       for (i = (arrayOfString = orderedNames).length, b = 0; b < i; ) { String projectName = arrayOfString[b];
/* 331 */         for (Iterator<IProject> iterator = unorderedProjects.iterator(); iterator.hasNext(); ) {
/* 332 */           IProject project = iterator.next();
/* 333 */           if (project.getName().equals(projectName)) {
/* 334 */             orderedProjects.add(project);
/* 335 */             iterator.remove();
/*     */             break;
/*     */           } 
/*     */         } 
/*     */         b++; }
/*     */       
/* 341 */       orderedProjects.addAll(unorderedProjects);
/* 342 */       return orderedProjects.<IProject>toArray(new IProject[orderedProjects.size()]);
/*     */     } 
/*     */ 
/*     */     
/* 346 */     IWorkspace.ProjectOrder po = ResourcesPlugin.getWorkspace().computeProjectOrder(projects);
/* 347 */     return po.projects;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean existsProblems(IProject proj) throws CoreException {
/* 361 */     IMarker[] markers = proj.findMarkers("org.eclipse.core.resources.problemmarker", true, 2);
/* 362 */     if (markers.length > 0) {
/* 363 */       byte b; int i; IMarker[] arrayOfIMarker; for (i = (arrayOfIMarker = markers).length, b = 0; b < i; ) { IMarker marker = arrayOfIMarker[b];
/* 364 */         if (isLaunchProblem(marker))
/* 365 */           return true; 
/*     */         b++; }
/*     */     
/*     */     } 
/* 369 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean isLaunchProblem(IMarker problemMarker) throws CoreException {
/*     */     try {
/* 384 */       Integer severity = (Integer)problemMarker.getAttribute("severity");
/* 385 */       if (severity != null) {
/* 386 */         return (severity.intValue() >= 2);
/*     */       }
/* 388 */     } catch (IllegalStateException e) {
/*     */ 
/*     */       
/* 391 */       if (problemMarker.exists()) {
/* 392 */         Status status = new Status(4, DebugPlugin.getUniqueIdentifier(), DebugCoreMessages.ErrorAccessingProblemMarker, e);
/* 393 */         throw new CoreException(status);
/*     */       } 
/*     */     } 
/*     */     
/* 397 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void buildProjects(IProject[] projects, IProgressMonitor monitor) throws CoreException {
/* 408 */     IWorkspaceRunnable build = pm -> {
/*     */         SubMonitor localmonitor = SubMonitor.convert(pm, DebugCoreMessages.LaunchConfigurationDelegate_scoped_incremental_build, paramArrayOfIProject.length); try {
/*     */           IProject[] arrayOfIProject; int i = (arrayOfIProject = paramArrayOfIProject).length;
/*     */           for (byte b = 0; b < i; b++) {
/*     */             IProject project = arrayOfIProject[b];
/*     */             if (localmonitor.isCanceled())
/*     */               throw new OperationCanceledException(); 
/*     */             project.build(10, (IProgressMonitor)localmonitor.newChild(1));
/*     */           } 
/*     */         } finally {
/*     */           localmonitor.done();
/*     */         } 
/*     */       };
/* 421 */     ResourcesPlugin.getWorkspace().run(build, monitor);
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.debug.core-3.21.0.jar!\org\eclipse\debug\core\model\LaunchConfigurationDelegate.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */