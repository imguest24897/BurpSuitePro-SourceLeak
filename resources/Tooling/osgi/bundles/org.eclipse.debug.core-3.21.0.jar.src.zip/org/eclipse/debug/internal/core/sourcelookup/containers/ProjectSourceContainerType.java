/*    */ package org.eclipse.debug.internal.core.sourcelookup.containers;
/*    */ 
/*    */ import org.eclipse.core.resources.IProject;
/*    */ import org.eclipse.core.resources.IWorkspace;
/*    */ import org.eclipse.core.resources.ResourcesPlugin;
/*    */ import org.eclipse.core.runtime.CoreException;
/*    */ import org.eclipse.debug.core.sourcelookup.ISourceContainer;
/*    */ import org.eclipse.debug.core.sourcelookup.containers.AbstractSourceContainerTypeDelegate;
/*    */ import org.eclipse.debug.core.sourcelookup.containers.ProjectSourceContainer;
/*    */ import org.eclipse.debug.internal.core.sourcelookup.SourceLookupMessages;
/*    */ import org.w3c.dom.Document;
/*    */ import org.w3c.dom.Element;
/*    */ import org.w3c.dom.Node;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ProjectSourceContainerType
/*    */   extends AbstractSourceContainerTypeDelegate
/*    */ {
/*    */   public String getMemento(ISourceContainer container) throws CoreException {
/* 37 */     ProjectSourceContainer project = (ProjectSourceContainer)container;
/* 38 */     Document document = newDocument();
/* 39 */     Element element = document.createElement("project");
/* 40 */     element.setAttribute("name", project.getContainer().getName());
/* 41 */     String referenced = "false";
/* 42 */     if (project.isSearchReferencedProjects()) {
/* 43 */       referenced = "true";
/*    */     }
/* 45 */     element.setAttribute("referencedProjects", referenced);
/* 46 */     document.appendChild(element);
/* 47 */     return serializeDocument(document);
/*    */   }
/*    */ 
/*    */   
/*    */   public ISourceContainer createSourceContainer(String memento) throws CoreException {
/* 52 */     Node node = parseDocument(memento);
/* 53 */     if (node.getNodeType() == 1) {
/* 54 */       Element element = (Element)node;
/* 55 */       if ("project".equals(element.getNodeName())) {
/* 56 */         String string = element.getAttribute("name");
/* 57 */         if (string == null || string.length() == 0) {
/* 58 */           abort(SourceLookupMessages.ProjectSourceContainerType_10, null);
/*    */         }
/* 60 */         String nest = element.getAttribute("referencedProjects");
/* 61 */         boolean ref = "true".equals(nest);
/* 62 */         IWorkspace workspace = ResourcesPlugin.getWorkspace();
/* 63 */         IProject project = workspace.getRoot().getProject(string);
/* 64 */         return (ISourceContainer)new ProjectSourceContainer(project, ref);
/*    */       } 
/* 66 */       abort(SourceLookupMessages.ProjectSourceContainerType_11, null);
/*    */     } 
/* 68 */     abort(SourceLookupMessages.ProjectSourceContainerType_12, null);
/* 69 */     return null;
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.debug.core-3.21.0.jar!\org\eclipse\debug\internal\core\sourcelookup\containers\ProjectSourceContainerType.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */