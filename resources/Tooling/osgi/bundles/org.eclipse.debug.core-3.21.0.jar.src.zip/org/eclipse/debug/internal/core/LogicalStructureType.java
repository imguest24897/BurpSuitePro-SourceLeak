/*     */ package org.eclipse.debug.internal.core;
/*     */ 
/*     */ import java.text.MessageFormat;
/*     */ import org.eclipse.core.runtime.CoreException;
/*     */ import org.eclipse.core.runtime.IConfigurationElement;
/*     */ import org.eclipse.core.runtime.Status;
/*     */ import org.eclipse.debug.core.DebugPlugin;
/*     */ import org.eclipse.debug.core.ILogicalStructureType;
/*     */ import org.eclipse.debug.core.model.ILogicalStructureTypeDelegate;
/*     */ import org.eclipse.debug.core.model.ILogicalStructureTypeDelegate2;
/*     */ import org.eclipse.debug.core.model.ILogicalStructureTypeDelegate3;
/*     */ import org.eclipse.debug.core.model.IValue;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LogicalStructureType
/*     */   implements ILogicalStructureType, ILogicalStructureTypeDelegate3
/*     */ {
/*     */   private IConfigurationElement fConfigurationElement;
/*     */   private ILogicalStructureTypeDelegate fDelegate;
/*     */   private String fModelId;
/*     */   private boolean fVerifiedDescription = false;
/*     */   
/*     */   public LogicalStructureType(IConfigurationElement element) throws CoreException {
/*  50 */     this.fConfigurationElement = element;
/*  51 */     verifyAttributes();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void verifyAttributes() throws CoreException {
/*  60 */     verifyAttributeExists("id");
/*  61 */     verifyAttributeExists("class");
/*  62 */     this.fModelId = this.fConfigurationElement.getAttribute("modelIdentifier");
/*  63 */     if (this.fModelId == null) {
/*  64 */       missingAttribute("modelIdentifier");
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void verifyAttributeExists(String name) throws CoreException {
/*  75 */     if (this.fConfigurationElement.getAttribute(name) == null) {
/*  76 */       missingAttribute(name);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void missingAttribute(String attrName) throws CoreException {
/*  86 */     throw new CoreException(new Status(4, DebugPlugin.getUniqueIdentifier(), 125, MessageFormat.format(DebugCoreMessages.LogicalStructureType_1, new Object[] { attrName }), null));
/*     */   }
/*     */ 
/*     */   
/*     */   public String getDescription() {
/*  91 */     return this.fConfigurationElement.getAttribute("description");
/*     */   }
/*     */ 
/*     */   
/*     */   public String getId() {
/*  96 */     return this.fConfigurationElement.getAttribute("id");
/*     */   }
/*     */ 
/*     */   
/*     */   public IValue getLogicalStructure(IValue value) throws CoreException {
/* 101 */     return getDelegate().getLogicalStructure(value);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean providesLogicalStructure(IValue value) {
/* 106 */     if (value.getModelIdentifier().equals(this.fModelId)) {
/* 107 */       return getDelegate().providesLogicalStructure(value);
/*     */     }
/* 109 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public void releaseValue(IValue logicalStructure) {
/* 114 */     ILogicalStructureTypeDelegate delegate = getDelegate();
/* 115 */     if (delegate instanceof ILogicalStructureTypeDelegate3) {
/* 116 */       ((ILogicalStructureTypeDelegate3)delegate).releaseValue(logicalStructure);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected ILogicalStructureTypeDelegate getDelegate() {
/* 125 */     if (this.fDelegate == null) {
/*     */       try {
/* 127 */         this.fDelegate = (ILogicalStructureTypeDelegate)this.fConfigurationElement.createExecutableExtension("class");
/* 128 */       } catch (CoreException e) {
/* 129 */         DebugPlugin.log((Throwable)e);
/*     */       } 
/*     */     }
/* 132 */     return this.fDelegate;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getDescription(IValue value) {
/* 137 */     ILogicalStructureTypeDelegate delegate = getDelegate();
/* 138 */     if (delegate instanceof ILogicalStructureTypeDelegate2) {
/* 139 */       ILogicalStructureTypeDelegate2 d2 = (ILogicalStructureTypeDelegate2)delegate;
/* 140 */       return d2.getDescription(value);
/*     */     } 
/* 142 */     if (!this.fVerifiedDescription) {
/* 143 */       this.fVerifiedDescription = true;
/*     */       try {
/* 145 */         verifyAttributeExists("description");
/* 146 */       } catch (CoreException e) {
/* 147 */         DebugPlugin.log((Throwable)e);
/*     */       } 
/*     */     } 
/* 150 */     String description = getDescription();
/* 151 */     if (description == null) {
/* 152 */       return DebugCoreMessages.LogicalStructureType_0;
/*     */     }
/* 154 */     return description;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.debug.core-3.21.0.jar!\org\eclipse\debug\internal\core\LogicalStructureType.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */