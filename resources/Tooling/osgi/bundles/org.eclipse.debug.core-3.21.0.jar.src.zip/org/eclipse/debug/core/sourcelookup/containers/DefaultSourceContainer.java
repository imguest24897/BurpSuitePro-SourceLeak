/*     */ package org.eclipse.debug.core.sourcelookup.containers;
/*     */ 
/*     */ import org.eclipse.core.runtime.CoreException;
/*     */ import org.eclipse.debug.core.DebugPlugin;
/*     */ import org.eclipse.debug.core.ILaunchConfiguration;
/*     */ import org.eclipse.debug.core.sourcelookup.ISourceContainer;
/*     */ import org.eclipse.debug.core.sourcelookup.ISourceContainerType;
/*     */ import org.eclipse.debug.core.sourcelookup.ISourceLookupDirector;
/*     */ import org.eclipse.debug.core.sourcelookup.ISourcePathComputer;
/*     */ import org.eclipse.debug.internal.core.sourcelookup.SourceLookupMessages;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DefaultSourceContainer
/*     */   extends CompositeSourceContainer
/*     */ {
/*  41 */   public static final String TYPE_ID = String.valueOf(DebugPlugin.getUniqueIdentifier()) + ".containerType.default";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object obj) {
/*  51 */     return obj instanceof DefaultSourceContainer;
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/*  56 */     return getClass().hashCode();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected ILaunchConfiguration getLaunchConfiguration() {
/*  67 */     ISourceLookupDirector director = getDirector();
/*  68 */     if (director != null) {
/*  69 */       return director.getLaunchConfiguration();
/*     */     }
/*  71 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public ISourceContainerType getType() {
/*  76 */     return getSourceContainerType(TYPE_ID);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ISourcePathComputer getSourcePathComputer() {
/*  87 */     ISourceLookupDirector director = getDirector();
/*  88 */     if (director != null) {
/*  89 */       return director.getSourcePathComputer();
/*     */     }
/*  91 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getName() {
/*  96 */     return SourceLookupMessages.DefaultSourceContainer_0;
/*     */   }
/*     */ 
/*     */   
/*     */   protected ISourceContainer[] createSourceContainers() throws CoreException {
/* 101 */     ISourcePathComputer sourcePathComputer = getSourcePathComputer();
/* 102 */     if (sourcePathComputer != null) {
/* 103 */       ILaunchConfiguration config = getLaunchConfiguration();
/* 104 */       if (config != null) {
/* 105 */         return sourcePathComputer.computeSourceContainers(config, null);
/*     */       }
/*     */     } 
/*     */     
/* 109 */     return new ISourceContainer[0];
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.debug.core-3.21.0.jar!\org\eclipse\debug\core\sourcelookup\containers\DefaultSourceContainer.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */