/*    */ package org.eclipse.debug.internal.core.variables;
/*    */ 
/*    */ import java.text.SimpleDateFormat;
/*    */ import java.util.Date;
/*    */ import org.eclipse.core.runtime.CoreException;
/*    */ import org.eclipse.core.runtime.IStatus;
/*    */ import org.eclipse.core.runtime.Status;
/*    */ import org.eclipse.core.variables.IDynamicVariable;
/*    */ import org.eclipse.core.variables.IDynamicVariableResolver;
/*    */ import org.eclipse.debug.core.DebugPlugin;
/*    */ import org.eclipse.osgi.util.NLS;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DateTimeResolver
/*    */   implements IDynamicVariableResolver
/*    */ {
/*    */   public String resolveValue(IDynamicVariable variable, String argument) throws CoreException {
/* 37 */     SimpleDateFormat format = null;
/* 38 */     if (argument != null && argument.trim().length() > 0) {
/*    */       try {
/* 40 */         format = new SimpleDateFormat(argument);
/* 41 */       } catch (IllegalArgumentException e) {
/* 42 */         DebugPlugin.log((IStatus)new Status(4, DebugPlugin.getUniqueIdentifier(), NLS.bind(Messages.DateTimeResolver_ProblemWithDateArgument, argument), e));
/*    */       } 
/*    */     }
/*    */     
/* 46 */     if (format == null) {
/* 47 */       format = new SimpleDateFormat("yyyyMMdd_HHmm");
/*    */     }
/*    */     
/* 50 */     return format.format(new Date());
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.debug.core-3.21.0.jar!\org\eclipse\debug\internal\core\variables\DateTimeResolver.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */