/*     */ package org.eclipse.debug.core;
/*     */ 
/*     */ import java.util.Collection;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import org.eclipse.core.resources.IFile;
/*     */ import org.eclipse.core.resources.IResource;
/*     */ import org.eclipse.core.runtime.CoreException;
/*     */ import org.eclipse.core.runtime.IAdaptable;
/*     */ import org.eclipse.core.runtime.IPath;
/*     */ import org.eclipse.core.runtime.IProgressMonitor;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public interface ILaunchConfiguration
/*     */   extends IAdaptable
/*     */ {
/*     */   public static final String LAUNCH_CONFIGURATION_FILE_EXTENSION = "launch";
/*     */   public static final String LAUNCH_CONFIGURATION_PROTOTYPE_FILE_EXTENSION = "prototype";
/*  90 */   public static final String ATTR_SOURCE_LOCATOR_ID = String.valueOf(DebugPlugin.getUniqueIdentifier()) + ".source_locator_id";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 102 */   public static final String ATTR_SOURCE_LOCATOR_MEMENTO = String.valueOf(DebugPlugin.getUniqueIdentifier()) + ".source_locator_memento";
/*     */   public static final int UPDATE_NONE = 0;
/*     */   public static final int UPDATE_PROTOTYPE_CHILDREN = 1;
/*     */   public static final int CONFIGURATION = 1;
/*     */   public static final int PROTOTYPE = 2;
/*     */   
/*     */   boolean contentsEqual(ILaunchConfiguration paramILaunchConfiguration);
/*     */   
/*     */   ILaunchConfigurationWorkingCopy copy(String paramString) throws CoreException;
/*     */   
/*     */   void delete() throws CoreException;
/*     */   
/*     */   void delete(int paramInt) throws CoreException;
/*     */   
/*     */   boolean exists();
/*     */   
/*     */   boolean getAttribute(String paramString, boolean paramBoolean) throws CoreException;
/*     */   
/*     */   int getAttribute(String paramString, int paramInt) throws CoreException;
/*     */   
/*     */   List<String> getAttribute(String paramString, List<String> paramList) throws CoreException;
/*     */   
/*     */   Set<String> getAttribute(String paramString, Set<String> paramSet) throws CoreException;
/*     */   
/*     */   Map<String, String> getAttribute(String paramString, Map<String, String> paramMap) throws CoreException;
/*     */   
/*     */   String getAttribute(String paramString1, String paramString2) throws CoreException;
/*     */   
/*     */   Map<String, Object> getAttributes() throws CoreException;
/*     */   
/*     */   String getCategory() throws CoreException;
/*     */   
/*     */   IFile getFile();
/*     */   
/*     */   @Deprecated
/*     */   IPath getLocation();
/*     */   
/*     */   IResource[] getMappedResources() throws CoreException;
/*     */   
/*     */   String getMemento() throws CoreException;
/*     */   
/*     */   String getName();
/*     */   
/*     */   Set<String> getModes() throws CoreException;
/*     */   
/*     */   ILaunchDelegate getPreferredDelegate(Set<String> paramSet) throws CoreException;
/*     */   
/*     */   ILaunchConfigurationType getType() throws CoreException;
/*     */   
/*     */   ILaunchConfigurationWorkingCopy getWorkingCopy() throws CoreException;
/*     */   
/*     */   boolean hasAttribute(String paramString) throws CoreException;
/*     */   
/*     */   boolean isLocal();
/*     */   
/*     */   boolean isMigrationCandidate() throws CoreException;
/*     */   
/*     */   boolean isWorkingCopy();
/*     */   
/*     */   ILaunch launch(String paramString, IProgressMonitor paramIProgressMonitor) throws CoreException;
/*     */   
/*     */   ILaunch launch(String paramString, IProgressMonitor paramIProgressMonitor, boolean paramBoolean) throws CoreException;
/*     */   
/*     */   ILaunch launch(String paramString, IProgressMonitor paramIProgressMonitor, boolean paramBoolean1, boolean paramBoolean2) throws CoreException;
/*     */   
/*     */   void migrate() throws CoreException;
/*     */   
/*     */   boolean supportsMode(String paramString) throws CoreException;
/*     */   
/*     */   boolean isReadOnly();
/*     */   
/*     */   ILaunchConfiguration getPrototype() throws CoreException;
/*     */   
/*     */   boolean isAttributeModified(String paramString) throws CoreException;
/*     */   
/*     */   boolean isPrototype();
/*     */   
/*     */   Collection<ILaunchConfiguration> getPrototypeChildren() throws CoreException;
/*     */   
/*     */   int getKind() throws CoreException;
/*     */   
/*     */   Set<String> getPrototypeVisibleAttributes() throws CoreException;
/*     */   
/*     */   void setPrototypeAttributeVisibility(String paramString, boolean paramBoolean) throws CoreException;
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.debug.core-3.21.0.jar!\org\eclipse\debug\core\ILaunchConfiguration.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */