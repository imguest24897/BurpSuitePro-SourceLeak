/*     */ package org.eclipse.debug.internal.core;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.PrintWriter;
/*     */ import java.io.Reader;
/*     */ import java.io.Writer;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import javax.xml.parsers.DocumentBuilder;
/*     */ import javax.xml.parsers.DocumentBuilderFactory;
/*     */ import javax.xml.parsers.ParserConfigurationException;
/*     */ import org.eclipse.debug.core.DebugPlugin;
/*     */ import org.w3c.dom.Attr;
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.Element;
/*     */ import org.w3c.dom.NamedNodeMap;
/*     */ import org.w3c.dom.Node;
/*     */ import org.w3c.dom.NodeList;
/*     */ import org.w3c.dom.Text;
/*     */ import org.xml.sax.InputSource;
/*     */ import org.xml.sax.SAXException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class XMLMemento
/*     */ {
/*     */   private Document factory;
/*     */   private Element element;
/*  47 */   private static String FILE_STRING = "file";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static XMLMemento createReadRoot(Reader reader) throws Exception {
/*  63 */     return createReadRoot(reader, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static String getAttributeNewValue(Object attributeOldValue) {
/*  75 */     StringBuffer strNewValue = new StringBuffer(FILE_STRING);
/*  76 */     if (attributeOldValue instanceof String && ((String)attributeOldValue).length() != 0) {
/*  77 */       String strOldValue = (String)attributeOldValue;
/*  78 */       boolean exists = Arrays.<String>asList(strOldValue.split(",")).stream().anyMatch(x -> x.trim().equals(FILE_STRING));
/*  79 */       if (!exists) {
/*  80 */         strNewValue.append(", ").append(strOldValue);
/*     */       } else {
/*  82 */         strNewValue = new StringBuffer(strOldValue);
/*     */       } 
/*     */     } 
/*  85 */     return strNewValue.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static XMLMemento createReadRoot(Reader reader, String baseDir) throws Exception {
/* 103 */     String errorMessage = null;
/* 104 */     Exception exception = null;
/* 105 */     DocumentBuilderFactory factory = null;
/* 106 */     Object attributeDTDOldValue = null;
/* 107 */     Object attributeSchemaOldValue = null;
/*     */     
/* 109 */     try { factory = DocumentBuilderFactory.newInstance();
/*     */       try {
/* 111 */         attributeDTDOldValue = factory.getAttribute("http://javax.xml.XMLConstants/property/accessExternalDTD");
/* 112 */         attributeSchemaOldValue = factory.getAttribute("http://javax.xml.XMLConstants/property/accessExternalSchema");
/* 113 */       } catch (NullPointerException|IllegalArgumentException nullPointerException) {}
/*     */ 
/*     */       
/* 116 */       factory.setAttribute("http://javax.xml.XMLConstants/property/accessExternalDTD", getAttributeNewValue(attributeDTDOldValue));
/* 117 */       factory.setAttribute("http://javax.xml.XMLConstants/property/accessExternalSchema", getAttributeNewValue(attributeSchemaOldValue));
/*     */       
/* 119 */       DocumentBuilder parser = factory.newDocumentBuilder();
/* 120 */       InputSource source = new InputSource(reader);
/* 121 */       if (baseDir != null) {
/* 122 */         source.setSystemId(baseDir);
/*     */       }
/* 124 */       Document document = parser.parse(source);
/* 125 */       NodeList list = document.getChildNodes();
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */        }
/*     */     
/* 132 */     catch (ParserConfigurationException e)
/* 133 */     { exception = e; }
/*     */     
/* 135 */     catch (IOException e)
/* 136 */     { exception = e; }
/*     */     
/* 138 */     catch (SAXException e)
/* 139 */     { exception = e; }
/*     */     finally
/*     */     
/* 142 */     { if (factory != null)
/* 143 */       { factory.setAttribute("http://javax.xml.XMLConstants/property/accessExternalDTD", attributeDTDOldValue);
/* 144 */         factory.setAttribute("http://javax.xml.XMLConstants/property/accessExternalSchema", attributeSchemaOldValue); }  }  if (factory != null) { factory.setAttribute("http://javax.xml.XMLConstants/property/accessExternalDTD", attributeDTDOldValue); factory.setAttribute("http://javax.xml.XMLConstants/property/accessExternalSchema", attributeSchemaOldValue); }
/*     */ 
/*     */ 
/*     */     
/* 148 */     String problemText = null;
/* 149 */     if (exception != null) {
/* 150 */       problemText = exception.getMessage();
/*     */     }
/* 152 */     if (problemText == null || problemText.length() == 0) {
/* 153 */       problemText = (errorMessage != null) ? errorMessage : 
/* 154 */         "ERROR";
/*     */     }
/* 156 */     throw new Exception(problemText, exception);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static XMLMemento createWriteRoot(String type) {
/*     */     try {
/* 168 */       Document document = DocumentBuilderFactory.newInstance()
/* 169 */         .newDocumentBuilder().newDocument();
/* 170 */       Element element = document.createElement(type);
/* 171 */       document.appendChild(element);
/* 172 */       return new XMLMemento(document, element);
/* 173 */     } catch (ParserConfigurationException e) {
/*     */       
/* 175 */       throw new Error(e.getMessage());
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public XMLMemento(Document document, Element element) {
/* 192 */     this.factory = document;
/* 193 */     this.element = element;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public XMLMemento createChild(String type) {
/* 200 */     Element child = this.factory.createElement(type);
/* 201 */     this.element.appendChild(child);
/* 202 */     return new XMLMemento(this.factory, child);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public XMLMemento createChild(String type, String id) {
/* 209 */     Element child = this.factory.createElement(type);
/* 210 */     child.setAttribute("id", (id == null) ? "" : id);
/* 211 */     this.element.appendChild(child);
/* 212 */     return new XMLMemento(this.factory, child);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public XMLMemento copyChild(XMLMemento child) {
/* 219 */     Element childElement = child.element;
/* 220 */     Element newElement = (Element)this.factory.importNode(childElement, true);
/* 221 */     this.element.appendChild(newElement);
/* 222 */     return new XMLMemento(this.factory, newElement);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public XMLMemento getChild(String type) {
/* 231 */     NodeList nodes = this.element.getChildNodes();
/* 232 */     int size = nodes.getLength();
/* 233 */     if (size == 0) {
/* 234 */       return null;
/*     */     }
/*     */ 
/*     */     
/* 238 */     for (int nX = 0; nX < size; nX++) {
/* 239 */       Node node = nodes.item(nX);
/* 240 */       if (node instanceof Element) {
/* 241 */         Element element1 = (Element)node;
/* 242 */         if (element1.getNodeName().equals(type)) {
/* 243 */           return new XMLMemento(this.factory, element1);
/*     */         }
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 249 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public XMLMemento[] getChildren(String type) {
/* 258 */     NodeList nodes = this.element.getChildNodes();
/* 259 */     int size = nodes.getLength();
/* 260 */     if (size == 0) {
/* 261 */       return new XMLMemento[0];
/*     */     }
/*     */ 
/*     */     
/* 265 */     ArrayList<Element> list = new ArrayList<>(size);
/* 266 */     for (int nX = 0; nX < size; nX++) {
/* 267 */       Node node = nodes.item(nX);
/* 268 */       if (node instanceof Element) {
/* 269 */         Element element1 = (Element)node;
/* 270 */         if (element1.getNodeName().equals(type)) {
/* 271 */           list.add(element1);
/*     */         }
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 277 */     size = list.size();
/* 278 */     XMLMemento[] results = new XMLMemento[size];
/* 279 */     for (int x = 0; x < size; x++) {
/* 280 */       results[x] = new XMLMemento(this.factory, list.get(x));
/*     */     }
/* 282 */     return results;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Float getFloat(String key) {
/* 289 */     Attr attr = this.element.getAttributeNode(key);
/* 290 */     if (attr == null) {
/* 291 */       return null;
/*     */     }
/* 293 */     String strValue = attr.getValue();
/*     */     try {
/* 295 */       return Float.valueOf(strValue);
/* 296 */     } catch (NumberFormatException e) {
/* 297 */       DebugPlugin.logMessage("Memento problem - Invalid float for key: " + 
/* 298 */           key + " value: " + strValue, e);
/* 299 */       return null;
/*     */     } 
/*     */   }
/*     */   
/*     */   public String getType() {
/* 304 */     return this.element.getNodeName();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getID() {
/* 311 */     return this.element.getAttribute("id");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Integer getInteger(String key) {
/* 318 */     Attr attr = this.element.getAttributeNode(key);
/* 319 */     if (attr == null) {
/* 320 */       return null;
/*     */     }
/* 322 */     String strValue = attr.getValue();
/*     */     try {
/* 324 */       return Integer.valueOf(strValue);
/* 325 */     } catch (NumberFormatException e) {
/*     */       
/* 327 */       DebugPlugin.logMessage("Memento problem - invalid integer for key: " + key + 
/* 328 */           " value: " + strValue, e);
/* 329 */       return null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getString(String key) {
/* 337 */     Attr attr = this.element.getAttributeNode(key);
/* 338 */     if (attr == null) {
/* 339 */       return null;
/*     */     }
/* 341 */     return attr.getValue();
/*     */   }
/*     */   
/*     */   public Boolean getBoolean(String key) {
/* 345 */     Attr attr = this.element.getAttributeNode(key);
/* 346 */     if (attr == null) {
/* 347 */       return null;
/*     */     }
/* 349 */     return Boolean.valueOf(attr.getValue());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getTextData() {
/* 356 */     Text textNode = getTextNode();
/* 357 */     if (textNode != null) {
/* 358 */       return textNode.getData();
/*     */     }
/* 360 */     return null;
/*     */   }
/*     */   
/*     */   public String[] getAttributeKeys() {
/* 364 */     NamedNodeMap map = this.element.getAttributes();
/* 365 */     int size = map.getLength();
/* 366 */     String[] attributes = new String[size];
/* 367 */     for (int i = 0; i < size; i++) {
/* 368 */       Node node = map.item(i);
/* 369 */       attributes[i] = node.getNodeName();
/*     */     } 
/* 371 */     return attributes;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Text getTextNode() {
/* 383 */     NodeList nodes = this.element.getChildNodes();
/* 384 */     int size = nodes.getLength();
/* 385 */     if (size == 0) {
/* 386 */       return null;
/*     */     }
/* 388 */     for (int nX = 0; nX < size; nX++) {
/* 389 */       Node node = nodes.item(nX);
/* 390 */       if (node instanceof Text) {
/* 391 */         return (Text)node;
/*     */       }
/*     */     } 
/*     */     
/* 395 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void putElement(Element element1, boolean copyText) {
/* 404 */     NamedNodeMap nodeMap = element1.getAttributes();
/* 405 */     int size = nodeMap.getLength();
/* 406 */     for (int i = 0; i < size; i++) {
/* 407 */       Attr attr = (Attr)nodeMap.item(i);
/* 408 */       putString(attr.getName(), attr.getValue());
/*     */     } 
/*     */     
/* 411 */     NodeList nodes = element1.getChildNodes();
/* 412 */     size = nodes.getLength();
/*     */ 
/*     */     
/* 415 */     boolean needToCopyText = copyText;
/* 416 */     for (int j = 0; j < size; j++) {
/* 417 */       Node node = nodes.item(j);
/* 418 */       if (node instanceof Element) {
/* 419 */         XMLMemento child = createChild(node.getNodeName());
/* 420 */         child.putElement((Element)node, true);
/* 421 */       } else if (node instanceof Text && needToCopyText) {
/* 422 */         putTextData(((Text)node).getData());
/* 423 */         needToCopyText = false;
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void putFloat(String key, float f) {
/* 432 */     this.element.setAttribute(key, String.valueOf(f));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void putInteger(String key, int n) {
/* 439 */     this.element.setAttribute(key, String.valueOf(n));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void putMemento(XMLMemento memento) {
/* 448 */     putElement(memento.element, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void putString(String key, String value) {
/* 455 */     if (value == null) {
/*     */       return;
/*     */     }
/* 458 */     this.element.setAttribute(key, value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void putBoolean(String key, boolean value) {
/* 467 */     this.element.setAttribute(key, value ? "true" : "false");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void putTextData(String data) {
/* 474 */     Text textNode = getTextNode();
/* 475 */     if (textNode == null) {
/* 476 */       textNode = this.factory.createTextNode(data);
/*     */       
/* 478 */       this.element.insertBefore(textNode, this.element.getFirstChild());
/*     */     } else {
/* 480 */       textNode.setData(data);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void save(Writer writer) throws IOException {
/* 492 */     Exception exception1 = null, exception2 = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final class DOMWriter
/*     */     extends PrintWriter
/*     */   {
/*     */     private static final String XML_VERSION = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public DOMWriter(Writer output) {
/* 514 */       super(output);
/*     */       
/* 516 */       println("<?xml version=\"1.0\" encoding=\"UTF-8\"?>");
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void print(Element element) {
/* 528 */       boolean hasChildren = element.hasChildNodes();
/* 529 */       startTag(element, hasChildren);
/* 530 */       if (hasChildren) {
/*     */         
/* 532 */         boolean prevWasText = false;
/* 533 */         NodeList children = element.getChildNodes();
/* 534 */         for (int i = 0; i < children.getLength(); i++) {
/* 535 */           Node node = children.item(i);
/* 536 */           if (node instanceof Element) {
/* 537 */             if (!prevWasText) {
/* 538 */               println();
/* 539 */               printTabulation();
/*     */             } 
/* 541 */             print((Element)children.item(i));
/* 542 */             prevWasText = false;
/*     */           }
/* 544 */           else if (node instanceof Text) {
/* 545 */             print(getEscaped(node.getNodeValue()));
/* 546 */             prevWasText = true;
/*     */           } 
/*     */         } 
/*     */         
/* 550 */         if (!prevWasText) {
/* 551 */           println();
/* 552 */           printTabulation();
/*     */         } 
/* 554 */         endTag(element);
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private void printTabulation() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private void startTag(Element element, boolean hasChildren) {
/* 569 */       StringBuilder sb = new StringBuilder();
/* 570 */       sb.append("<");
/* 571 */       sb.append(element.getTagName());
/* 572 */       NamedNodeMap attributes = element.getAttributes();
/* 573 */       for (int i = 0; i < attributes.getLength(); i++) {
/* 574 */         Attr attribute = (Attr)attributes.item(i);
/* 575 */         sb.append(" ");
/* 576 */         sb.append(attribute.getName());
/* 577 */         sb.append("=\"");
/* 578 */         sb.append(getEscaped(String.valueOf(attribute.getValue())));
/* 579 */         sb.append("\"");
/*     */       } 
/* 581 */       sb.append(hasChildren ? ">" : "/>");
/* 582 */       print(sb.toString());
/*     */     }
/*     */     
/*     */     private void endTag(Element element) {
/* 586 */       StringBuilder sb = new StringBuilder();
/* 587 */       sb.append("</");
/* 588 */       sb.append(element.getNodeName());
/* 589 */       sb.append(">");
/* 590 */       print(sb.toString());
/*     */     }
/*     */     
/*     */     private static void appendEscapedChar(StringBuilder buffer, char c) {
/* 594 */       String replacement = getReplacement(c);
/* 595 */       if (replacement != null) {
/* 596 */         buffer.append('&');
/* 597 */         buffer.append(replacement);
/* 598 */         buffer.append(';');
/* 599 */       } else if (c == '\t' || c == '\n' || c == '\r' || c >= ' ') {
/* 600 */         buffer.append(c);
/*     */       } 
/*     */     }
/*     */     
/*     */     private static String getEscaped(String s) {
/* 605 */       StringBuilder result = new StringBuilder(s.length() + 10);
/* 606 */       for (int i = 0; i < s.length(); i++) {
/* 607 */         appendEscapedChar(result, s.charAt(i));
/*     */       }
/* 609 */       return result.toString();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private static String getReplacement(char c) {
/* 618 */       switch (c) {
/*     */         case '<':
/* 620 */           return "lt";
/*     */         case '>':
/* 622 */           return "gt";
/*     */         case '"':
/* 624 */           return "quot";
/*     */         case '\'':
/* 626 */           return "apos";
/*     */         case '&':
/* 628 */           return "amp";
/*     */         case '\r':
/* 630 */           return "#x0D";
/*     */         case '\n':
/* 632 */           return "#x0A";
/*     */         case '\t':
/* 634 */           return "#x09";
/*     */       } 
/*     */ 
/*     */       
/* 638 */       return null;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.debug.core-3.21.0.jar!\org\eclipse\debug\internal\core\XMLMemento.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */