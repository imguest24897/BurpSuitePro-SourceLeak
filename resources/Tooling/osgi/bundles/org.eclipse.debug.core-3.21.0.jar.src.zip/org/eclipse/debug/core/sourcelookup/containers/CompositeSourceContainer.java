/*     */ package org.eclipse.debug.core.sourcelookup.containers;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import org.eclipse.core.runtime.CoreException;
/*     */ import org.eclipse.core.runtime.IStatus;
/*     */ import org.eclipse.core.runtime.MultiStatus;
/*     */ import org.eclipse.debug.core.DebugPlugin;
/*     */ import org.eclipse.debug.core.sourcelookup.ISourceContainer;
/*     */ import org.eclipse.debug.internal.core.sourcelookup.SourceLookupMessages;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class CompositeSourceContainer
/*     */   extends AbstractSourceContainer
/*     */ {
/*     */   private ISourceContainer[] fContainers;
/*     */   
/*     */   public boolean isComposite() {
/*  41 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public Object[] findSourceElements(String name) throws CoreException {
/*  46 */     return findSourceElements(name, getSourceContainers());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Object[] findSourceElements(String name, ISourceContainer[] containers) throws CoreException {
/*  70 */     List<Object> results = null;
/*  71 */     CoreException single = null;
/*  72 */     MultiStatus multiStatus = null;
/*  73 */     if (isFindDuplicates())
/*  74 */       results = new ArrayList();  byte b; int i;
/*     */     ISourceContainer[] arrayOfISourceContainer;
/*  76 */     for (i = (arrayOfISourceContainer = containers).length, b = 0; b < i; ) { ISourceContainer container = arrayOfISourceContainer[b];
/*     */       try {
/*  78 */         Object[] objects = container.findSourceElements(name);
/*  79 */         if (objects.length > 0)
/*     */         {
/*     */           
/*  82 */           if (results != null) {
/*  83 */             Collections.addAll(results, objects);
/*     */           } else {
/*  85 */             if (objects.length == 1) {
/*  86 */               return objects;
/*     */             }
/*  88 */             return new Object[] { objects[0] };
/*     */           } 
/*     */         }
/*  91 */       } catch (CoreException e) {
/*  92 */         if (single == null) {
/*  93 */           single = e;
/*  94 */         } else if (multiStatus == null) {
/*  95 */           multiStatus = new MultiStatus(DebugPlugin.getUniqueIdentifier(), 125, new IStatus[] { single.getStatus() }, SourceLookupMessages.Source_Lookup_Error, null);
/*  96 */           multiStatus.add(e.getStatus());
/*     */         } else {
/*  98 */           multiStatus.add(e.getStatus());
/*     */         } 
/*     */       }  b++; }
/*     */     
/* 102 */     if (results == null) {
/* 103 */       if (multiStatus != null)
/* 104 */         throw new CoreException(multiStatus); 
/* 105 */       if (single != null) {
/* 106 */         throw single;
/*     */       }
/* 108 */       return EMPTY;
/*     */     } 
/* 110 */     return results.toArray();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected abstract ISourceContainer[] createSourceContainers() throws CoreException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized ISourceContainer[] getSourceContainers() throws CoreException {
/* 124 */     if (this.fContainers == null) {
/* 125 */       this.fContainers = createSourceContainers(); byte b; int i; ISourceContainer[] arrayOfISourceContainer;
/* 126 */       for (i = (arrayOfISourceContainer = this.fContainers).length, b = 0; b < i; ) { ISourceContainer container = arrayOfISourceContainer[b];
/* 127 */         container.init(getDirector()); b++; }
/*     */     
/*     */     } 
/* 130 */     return this.fContainers;
/*     */   }
/*     */ 
/*     */   
/*     */   public void dispose() {
/* 135 */     super.dispose();
/* 136 */     if (this.fContainers != null) {
/* 137 */       byte b; int i; ISourceContainer[] arrayOfISourceContainer; for (i = (arrayOfISourceContainer = this.fContainers).length, b = 0; b < i; ) { ISourceContainer container = arrayOfISourceContainer[b];
/* 138 */         container.dispose(); b++; }
/*     */     
/*     */     } 
/* 141 */     this.fContainers = null;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.debug.core-3.21.0.jar!\org\eclipse\debug\core\sourcelookup\containers\CompositeSourceContainer.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */