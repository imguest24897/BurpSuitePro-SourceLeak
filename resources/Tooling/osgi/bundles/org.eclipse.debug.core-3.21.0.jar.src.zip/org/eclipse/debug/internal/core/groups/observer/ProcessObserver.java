/*    */ package org.eclipse.debug.internal.core.groups.observer;
/*    */ 
/*    */ import java.util.concurrent.Callable;
/*    */ import java.util.concurrent.CountDownLatch;
/*    */ import java.util.concurrent.TimeUnit;
/*    */ import org.eclipse.core.runtime.IProgressMonitor;
/*    */ import org.eclipse.debug.core.model.IProcess;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class ProcessObserver
/*    */   implements Callable<Integer>
/*    */ {
/*    */   private final IProcess p;
/*    */   private final IProgressMonitor pMonitor;
/*    */   private final CountDownLatch countDownLatch;
/*    */   
/*    */   public ProcessObserver(IProgressMonitor monitor, IProcess p, CountDownLatch countDownLatch) {
/* 33 */     this.p = p;
/* 34 */     this.pMonitor = monitor;
/* 35 */     this.countDownLatch = countDownLatch;
/*    */   }
/*    */ 
/*    */   
/*    */   public Integer call() throws Exception {
/*    */     try {
/* 41 */       while (!this.p.isTerminated() && !this.pMonitor.isCanceled()) {
/* 42 */         TimeUnit.MILLISECONDS.sleep(250L);
/*    */         
/* 44 */         if (this.countDownLatch.getCount() == 0L) {
/*    */           break;
/*    */         }
/*    */       } 
/*    */       
/* 49 */       if (this.p.isTerminated()) {
/* 50 */         return Integer.valueOf(this.p.getExitValue());
/*    */       }
/* 52 */       return Integer.valueOf(0);
/*    */     } finally {
/* 54 */       this.countDownLatch.countDown();
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.debug.core-3.21.0.jar!\org\eclipse\debug\internal\core\groups\observer\ProcessObserver.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */