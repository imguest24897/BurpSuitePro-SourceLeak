package org.eclipse.debug.core.model;

import org.eclipse.debug.core.DebugException;

public interface IDisconnect {
  boolean canDisconnect();
  
  void disconnect() throws DebugException;
  
  boolean isDisconnected();
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.debug.core-3.21.0.jar!\org\eclipse\debug\core\model\IDisconnect.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */