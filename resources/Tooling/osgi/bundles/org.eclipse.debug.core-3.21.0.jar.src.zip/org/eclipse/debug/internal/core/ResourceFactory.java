/*    */ package org.eclipse.debug.internal.core;
/*    */ 
/*    */ import org.eclipse.core.resources.IFile;
/*    */ import org.eclipse.core.resources.IFolder;
/*    */ import org.eclipse.core.resources.IProject;
/*    */ import org.eclipse.core.resources.IResource;
/*    */ import org.eclipse.core.resources.IWorkspaceRoot;
/*    */ import org.eclipse.core.resources.ResourcesPlugin;
/*    */ import org.eclipse.core.runtime.IAdaptable;
/*    */ import org.eclipse.core.runtime.IPath;
/*    */ import org.eclipse.core.runtime.Path;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ResourceFactory
/*    */ {
/*    */   public static final String TAG_PATH = "path";
/*    */   public static final String TAG_TYPE = "type";
/*    */   
/*    */   public static IAdaptable createElement(XMLMemento memento) {
/*    */     IFile iFile;
/* 44 */     String fileName = memento.getString("path");
/* 45 */     if (fileName == null) {
/* 46 */       return null;
/*    */     }
/*    */     
/* 49 */     IWorkspaceRoot root = ResourcesPlugin.getWorkspace().getRoot();
/* 50 */     String type = memento.getString("type");
/* 51 */     IResource res = null;
/* 52 */     if (type == null) {
/*    */ 
/*    */       
/* 55 */       res = root.findMember((IPath)new Path(fileName));
/*    */     } else {
/* 57 */       int resourceType = Integer.parseInt(type);
/*    */       
/* 59 */       if (resourceType == 8) {
/* 60 */         IWorkspaceRoot iWorkspaceRoot = root;
/* 61 */       } else if (resourceType == 4) {
/* 62 */         IProject iProject = root.getProject(fileName);
/* 63 */       } else if (resourceType == 2) {
/* 64 */         IFolder iFolder = root.getFolder((IPath)new Path(fileName));
/* 65 */       } else if (resourceType == 1) {
/* 66 */         iFile = root.getFile((IPath)new Path(fileName));
/*    */       } 
/*    */     } 
/* 69 */     return (IAdaptable)iFile;
/*    */   }
/*    */   
/*    */   public static void saveState(XMLMemento memento, IResource res) {
/* 73 */     memento.putString("path", res.getFullPath().toString());
/* 74 */     memento.putString("type", Integer.toString(res.getType()));
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.debug.core-3.21.0.jar!\org\eclipse\debug\internal\core\ResourceFactory.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */