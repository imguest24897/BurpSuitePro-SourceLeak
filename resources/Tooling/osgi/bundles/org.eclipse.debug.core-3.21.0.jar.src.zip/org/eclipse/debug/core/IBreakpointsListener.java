package org.eclipse.debug.core;

import org.eclipse.core.resources.IMarkerDelta;
import org.eclipse.debug.core.model.IBreakpoint;

public interface IBreakpointsListener {
  void breakpointsAdded(IBreakpoint[] paramArrayOfIBreakpoint);
  
  void breakpointsRemoved(IBreakpoint[] paramArrayOfIBreakpoint, IMarkerDelta[] paramArrayOfIMarkerDelta);
  
  void breakpointsChanged(IBreakpoint[] paramArrayOfIBreakpoint, IMarkerDelta[] paramArrayOfIMarkerDelta);
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.debug.core-3.21.0.jar!\org\eclipse\debug\core\IBreakpointsListener.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */