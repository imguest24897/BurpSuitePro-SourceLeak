/*     */ package org.eclipse.debug.core;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.concurrent.locks.Lock;
/*     */ import java.util.concurrent.locks.ReadWriteLock;
/*     */ import java.util.concurrent.locks.ReentrantReadWriteLock;
/*     */ import org.eclipse.core.runtime.IStatus;
/*     */ import org.eclipse.core.runtime.MultiStatus;
/*     */ import org.eclipse.core.runtime.PlatformObject;
/*     */ import org.eclipse.debug.core.model.IDebugTarget;
/*     */ import org.eclipse.debug.core.model.IDisconnect;
/*     */ import org.eclipse.debug.core.model.IProcess;
/*     */ import org.eclipse.debug.core.model.ISourceLocator;
/*     */ import org.eclipse.debug.internal.core.DebugCoreMessages;
/*     */ import org.eclipse.debug.internal.core.LaunchManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Launch
/*     */   extends PlatformObject
/*     */   implements ILaunch, IDisconnect, ILaunchListener, ILaunchConfigurationListener, IDebugEventSetListener
/*     */ {
/*  52 */   private final ReadWriteLock lock = new ReentrantReadWriteLock();
/*     */   
/*  54 */   private final Lock readLock = this.lock.readLock();
/*     */   
/*  56 */   private final Lock writeLock = this.lock.writeLock();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  64 */   private List<IDebugTarget> fTargets = new ArrayList<>();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  69 */   private ILaunchConfiguration fConfiguration = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  75 */   private List<IProcess> fProcesses = new ArrayList<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  81 */   private ISourceLocator fLocator = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String fMode;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private HashMap<String, String> fAttributes;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean fSuppressChange = true;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Launch(ILaunchConfiguration launchConfiguration, String mode, ISourceLocator locator) {
/* 110 */     this.fConfiguration = launchConfiguration;
/* 111 */     setSourceLocator(locator);
/* 112 */     this.fMode = mode;
/* 113 */     this.fSuppressChange = false;
/* 114 */     getLaunchManager().addLaunchListener(this);
/* 115 */     getLaunchManager().addLaunchConfigurationListener(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void addEventListener() {
/* 122 */     DebugPlugin.getDefault().addDebugEventListener(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void removeEventListener() {
/* 129 */     DebugPlugin.getDefault().removeDebugEventListener(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean canTerminate() {
/* 137 */     this.readLock.lock();
/*     */     
/* 139 */     try { for (IProcess process : getProcesses0()) {
/* 140 */         if (process.canTerminate()) {
/* 141 */           return true;
/*     */         
/*     */         }
/*     */       
/*     */       }
/*     */        }
/*     */     
/*     */     finally
/*     */     
/* 150 */     { this.readLock.unlock(); }  this.readLock.unlock();
/*     */     
/* 152 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object[] getChildren() {
/*     */     ArrayList<Object> children;
/* 160 */     this.readLock.lock();
/*     */     
/*     */     try {
/* 163 */       children = new ArrayList(getDebugTargets0());
/* 164 */       children.addAll(getProcesses0());
/*     */     } finally {
/* 166 */       this.readLock.unlock();
/*     */     } 
/* 168 */     return children.toArray();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IDebugTarget getDebugTarget() {
/* 176 */     this.readLock.lock();
/*     */     try {
/* 178 */       if (!getDebugTargets0().isEmpty()) {
/* 179 */         return getDebugTargets0().get(0);
/*     */       }
/*     */     } finally {
/* 182 */       this.readLock.unlock();
/*     */     } 
/* 184 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IProcess[] getProcesses() {
/* 192 */     this.readLock.lock();
/*     */     try {
/* 194 */       return getProcesses0().<IProcess>toArray(new IProcess[getProcesses0().size()]);
/*     */     } finally {
/* 196 */       this.readLock.unlock();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected List<IProcess> getProcesses0() {
/* 207 */     return this.fProcesses;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ISourceLocator getSourceLocator() {
/* 215 */     return this.fLocator;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSourceLocator(ISourceLocator sourceLocator) {
/* 223 */     this.fLocator = sourceLocator;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isTerminated() {
/* 231 */     this.readLock.lock();
/*     */     
/* 233 */     try { if (getProcesses0().isEmpty() && getDebugTargets0().isEmpty()) {
/* 234 */         return false;
/*     */       }
/* 236 */       for (IProcess process : getProcesses0()) {
/* 237 */         if (!process.isTerminated()) {
/* 238 */           return false;
/*     */         
/*     */         }
/*     */       
/*     */       }
/*     */        }
/*     */     
/*     */     finally
/*     */     
/* 247 */     { this.readLock.unlock(); }  this.readLock.unlock();
/*     */     
/* 249 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void terminate() throws DebugException {
/* 257 */     MultiStatus status = 
/* 258 */       new MultiStatus(DebugPlugin.getUniqueIdentifier(), 5012, DebugCoreMessages.Launch_terminate_failed, null);
/*     */ 
/*     */     
/* 261 */     IDebugTarget[] targets = getDebugTargets(); byte b; int i; IDebugTarget[] arrayOfIDebugTarget1;
/* 262 */     for (i = (arrayOfIDebugTarget1 = targets).length, b = 0; b < i; ) { IDebugTarget target = arrayOfIDebugTarget1[b];
/* 263 */       if (target != null) {
/* 264 */         if (target.canTerminate()) {
/*     */           try {
/* 266 */             target.terminate();
/* 267 */           } catch (DebugException e) {
/* 268 */             status.merge(e.getStatus());
/*     */           } 
/* 270 */         } else if (target.canDisconnect()) {
/*     */           try {
/* 272 */             target.disconnect();
/* 273 */           } catch (DebugException de) {
/* 274 */             status.merge(de.getStatus());
/*     */           } 
/*     */         } 
/*     */       }
/*     */       
/*     */       b++; }
/*     */     
/* 281 */     IProcess[] processes = getProcesses(); IProcess[] arrayOfIProcess1;
/* 282 */     for (int j = (arrayOfIProcess1 = processes).length; i < j; ) { IProcess process = arrayOfIProcess1[i];
/* 283 */       if (process.canTerminate())
/*     */         try {
/* 285 */           process.terminate();
/* 286 */         } catch (DebugException e) {
/* 287 */           status.merge(e.getStatus());
/*     */         }  
/*     */       i++; }
/*     */     
/* 291 */     if (status.isOK()) {
/*     */       return;
/*     */     }
/* 294 */     IStatus[] children = status.getChildren();
/* 295 */     if (children.length == 1) {
/* 296 */       throw new DebugException(children[0]);
/*     */     }
/* 298 */     throw new DebugException(status);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getLaunchMode() {
/* 306 */     return this.fMode;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ILaunchConfiguration getLaunchConfiguration() {
/* 314 */     return this.fConfiguration;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAttribute(String key, String value) {
/* 322 */     if (this.fAttributes == null) {
/* 323 */       this.fAttributes = new HashMap<>(5);
/*     */     }
/* 325 */     this.fAttributes.put(key, value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getAttribute(String key) {
/* 333 */     if (this.fAttributes == null) {
/* 334 */       return null;
/*     */     }
/* 336 */     return this.fAttributes.get(key);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IDebugTarget[] getDebugTargets() {
/* 344 */     this.readLock.lock();
/*     */     try {
/* 346 */       return this.fTargets.<IDebugTarget>toArray(new IDebugTarget[this.fTargets.size()]);
/*     */     } finally {
/* 348 */       this.readLock.unlock();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected List<IDebugTarget> getDebugTargets0() {
/* 359 */     return this.fTargets;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addDebugTarget(IDebugTarget target) {
/* 367 */     if (target != null) {
/* 368 */       this.writeLock.lock();
/* 369 */       boolean changed = false;
/*     */       try {
/* 371 */         if (!getDebugTargets0().contains(target)) {
/* 372 */           addEventListener();
/* 373 */           changed = getDebugTargets0().add(target);
/*     */         } 
/*     */       } finally {
/* 376 */         this.writeLock.unlock();
/* 377 */         if (changed) {
/* 378 */           fireChanged();
/*     */         }
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void removeDebugTarget(IDebugTarget target) {
/* 389 */     if (target != null) {
/* 390 */       this.writeLock.lock();
/* 391 */       boolean changed = false;
/*     */       try {
/* 393 */         changed = getDebugTargets0().remove(target);
/*     */       } finally {
/* 395 */         this.writeLock.unlock();
/* 396 */         if (changed) {
/* 397 */           fireChanged();
/*     */         }
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addProcess(IProcess process) {
/* 408 */     if (process != null) {
/* 409 */       this.writeLock.lock();
/* 410 */       boolean changed = false;
/*     */       try {
/* 412 */         if (!getProcesses0().contains(process)) {
/* 413 */           addEventListener();
/* 414 */           changed = getProcesses0().add(process);
/*     */         } 
/*     */       } finally {
/* 417 */         this.writeLock.unlock();
/* 418 */         if (changed) {
/* 419 */           fireChanged();
/*     */         }
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void removeProcess(IProcess process) {
/* 430 */     if (process != null) {
/* 431 */       this.writeLock.lock();
/* 432 */       boolean changed = false;
/*     */       try {
/* 434 */         changed = getProcesses0().remove(process);
/*     */       } finally {
/* 436 */         this.writeLock.unlock();
/* 437 */         if (changed) {
/* 438 */           fireChanged();
/*     */         }
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void addProcesses(IProcess[] processes) {
/* 450 */     if (processes != null) {
/* 451 */       byte b; int i; IProcess[] arrayOfIProcess; for (i = (arrayOfIProcess = processes).length, b = 0; b < i; ) { IProcess process = arrayOfIProcess[b];
/* 452 */         addProcess(process);
/* 453 */         fireChanged();
/*     */         b++; }
/*     */     
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void fireChanged() {
/* 464 */     if (!this.fSuppressChange) {
/* 465 */       ((LaunchManager)getLaunchManager()).fireUpdate(this, 2);
/* 466 */       ((LaunchManager)getLaunchManager()).fireUpdate(new ILaunch[] { this }, 2);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void fireTerminate() {
/* 476 */     setAttribute("org.eclipse.debug.core.terminate.timestamp", Long.toString(System.currentTimeMillis()));
/* 477 */     if (!this.fSuppressChange) {
/* 478 */       ((LaunchManager)getLaunchManager()).fireUpdate(this, 3);
/* 479 */       ((LaunchManager)getLaunchManager()).fireUpdate(new ILaunch[] { this }, 3);
/*     */     } 
/* 481 */     removeEventListener();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean hasChildren() {
/* 489 */     return !(getProcesses0().size() <= 0 && getDebugTargets0().size() <= 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean canDisconnect() {
/* 500 */     this.readLock.lock();
/*     */     
/* 502 */     try { for (IProcess process : getProcesses0()) {
/* 503 */         if (process instanceof IDisconnect && (
/* 504 */           (IDisconnect)process).canDisconnect()) {
/* 505 */           return true;
/*     */         
/*     */         }
/*     */       
/*     */       }
/*     */       
/*     */        }
/*     */     
/*     */     finally
/*     */     
/* 515 */     { this.readLock.unlock(); }  this.readLock.unlock();
/*     */     
/* 517 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void disconnect() throws DebugException {
/* 525 */     this.readLock.lock();
/*     */     try {
/* 527 */       for (IProcess process : getProcesses0()) {
/* 528 */         if (process instanceof IDisconnect) {
/* 529 */           IDisconnect dis = (IDisconnect)process;
/* 530 */           if (dis.canDisconnect()) {
/* 531 */             dis.disconnect();
/*     */           }
/*     */         } 
/*     */       } 
/* 535 */       for (IDebugTarget target : getDebugTargets0()) {
/* 536 */         if (target.canDisconnect()) {
/* 537 */           target.disconnect();
/*     */         }
/*     */       } 
/*     */     } finally {
/* 541 */       this.readLock.unlock();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isDisconnected() {
/* 554 */     this.readLock.lock();
/*     */     
/* 556 */     try { for (IProcess process : getProcesses0()) {
/* 557 */         if (process instanceof IDisconnect && 
/* 558 */           !((IDisconnect)process).isDisconnected()) {
/* 559 */           return false;
/*     */         
/*     */         }
/*     */       
/*     */       }
/*     */       
/*     */        }
/*     */     
/*     */     finally
/*     */     
/* 569 */     { this.readLock.unlock(); }  this.readLock.unlock();
/*     */ 
/*     */     
/* 572 */     return hasChildren();
/*     */   }
/*     */ 
/*     */   
/*     */   public void launchRemoved(ILaunch launch) {
/* 577 */     if (equals(launch)) {
/* 578 */       removeEventListener();
/* 579 */       getLaunchManager().removeLaunchListener(this);
/* 580 */       getLaunchManager().removeLaunchConfigurationListener(this);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected ILaunchManager getLaunchManager() {
/* 590 */     return DebugPlugin.getDefault().getLaunchManager();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void launchAdded(ILaunch launch) {}
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void launchChanged(ILaunch launch) {}
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void launchConfigurationAdded(ILaunchConfiguration configuration) {
/* 607 */     ILaunchConfiguration from = getLaunchManager().getMovedFrom(configuration);
/* 608 */     if (from != null && from.equals(getLaunchConfiguration())) {
/* 609 */       this.fConfiguration = configuration;
/* 610 */       fireChanged();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void launchConfigurationChanged(ILaunchConfiguration configuration) {}
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void launchConfigurationRemoved(ILaunchConfiguration configuration) {
/* 623 */     if (configuration.equals(getLaunchConfiguration()) && 
/* 624 */       getLaunchManager().getMovedTo(configuration) == null) {
/* 625 */       this.fConfiguration = null;
/* 626 */       fireChanged();
/*     */     } 
/*     */   }
/*     */   public void handleDebugEvents(DebugEvent[] events) {
/*     */     byte b;
/*     */     int i;
/*     */     DebugEvent[] arrayOfDebugEvent;
/* 633 */     for (i = (arrayOfDebugEvent = events).length, b = 0; b < i; ) { DebugEvent event = arrayOfDebugEvent[b];
/* 634 */       if (event.getKind() == 8) {
/* 635 */         Object object = event.getSource();
/* 636 */         ILaunch launch = null;
/* 637 */         if (object instanceof IProcess) {
/* 638 */           launch = ((IProcess)object).getLaunch();
/* 639 */         } else if (object instanceof IDebugTarget) {
/* 640 */           launch = ((IDebugTarget)object).getLaunch();
/*     */         } 
/* 642 */         if (equals(launch) && 
/* 643 */           isTerminated()) {
/* 644 */           fireTerminate();
/*     */         }
/*     */       } 
/*     */       b++; }
/*     */   
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public <T> T getAdapter(Class<T> adapter) {
/* 654 */     if (adapter.equals(ILaunch.class)) {
/* 655 */       return (T)this;
/*     */     }
/*     */     
/* 658 */     if (adapter.equals(ILaunchConfiguration.class)) {
/* 659 */       return (T)getLaunchConfiguration();
/*     */     }
/* 661 */     return (T)super.getAdapter(adapter);
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.debug.core-3.21.0.jar!\org\eclipse\debug\core\Launch.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */