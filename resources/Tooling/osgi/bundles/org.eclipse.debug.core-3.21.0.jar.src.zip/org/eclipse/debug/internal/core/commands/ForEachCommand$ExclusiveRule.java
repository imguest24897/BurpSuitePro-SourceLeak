/*    */ package org.eclipse.debug.internal.core.commands;
/*    */ 
/*    */ import org.eclipse.core.runtime.jobs.ISchedulingRule;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class ExclusiveRule
/*    */   implements ISchedulingRule
/*    */ {
/*    */   public boolean contains(ISchedulingRule rule) {
/* 72 */     return (rule == this);
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean isConflicting(ISchedulingRule rule) {
/* 77 */     return contains(rule);
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.debug.core-3.21.0.jar!\org\eclipse\debug\internal\core\commands\ForEachCommand$ExclusiveRule.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */