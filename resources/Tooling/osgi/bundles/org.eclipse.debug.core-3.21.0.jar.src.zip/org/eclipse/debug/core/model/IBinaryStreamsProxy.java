/*    */ package org.eclipse.debug.core.model;
/*    */ 
/*    */ import java.io.IOException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface IBinaryStreamsProxy
/*    */   extends IStreamsProxy2
/*    */ {
/*    */   IBinaryStreamMonitor getBinaryErrorStreamMonitor();
/*    */   
/*    */   IBinaryStreamMonitor getBinaryOutputStreamMonitor();
/*    */   
/*    */   default void write(byte[] data) throws IOException {
/* 79 */     write(data, 0, data.length);
/*    */   }
/*    */   
/*    */   void write(byte[] paramArrayOfbyte, int paramInt1, int paramInt2) throws IOException;
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.debug.core-3.21.0.jar!\org\eclipse\debug\core\model\IBinaryStreamsProxy.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */