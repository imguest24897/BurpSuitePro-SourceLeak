/*     */ package org.eclipse.debug.core.sourcelookup.containers;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import org.eclipse.core.resources.IContainer;
/*     */ import org.eclipse.core.resources.IProject;
/*     */ import org.eclipse.core.runtime.CoreException;
/*     */ import org.eclipse.debug.core.DebugPlugin;
/*     */ import org.eclipse.debug.core.sourcelookup.ISourceContainer;
/*     */ import org.eclipse.debug.core.sourcelookup.ISourceContainerType;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ProjectSourceContainer
/*     */   extends ContainerSourceContainer
/*     */ {
/*     */   boolean fReferencedProjects = false;
/*  46 */   public static final String TYPE_ID = String.valueOf(DebugPlugin.getUniqueIdentifier()) + ".containerType.project";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ProjectSourceContainer(IProject project, boolean referenced) {
/*  55 */     super((IContainer)project, true);
/*  56 */     this.fReferencedProjects = referenced;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isSearchReferencedProjects() {
/*  65 */     return this.fReferencedProjects;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IProject getProject() {
/*  74 */     return (IProject)getContainer();
/*     */   }
/*     */ 
/*     */   
/*     */   public ISourceContainerType getType() {
/*  79 */     return getSourceContainerType(TYPE_ID);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isComposite() {
/*  84 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   protected ISourceContainer[] createSourceContainers() throws CoreException {
/*  89 */     if (getProject().isOpen()) {
/*  90 */       if (isSearchReferencedProjects()) {
/*  91 */         IProject project = getProject();
/*  92 */         IProject[] projects = getAllReferencedProjects(project);
/*  93 */         ISourceContainer[] folders = super.createSourceContainers();
/*  94 */         List<ISourceContainer> all = new ArrayList<>(folders.length + projects.length);
/*  95 */         Collections.addAll(all, folders); byte b; int i; IProject[] arrayOfIProject1;
/*  96 */         for (i = (arrayOfIProject1 = projects).length, b = 0; b < i; ) { IProject p = arrayOfIProject1[b];
/*  97 */           if (project.exists() && project.isOpen()) {
/*  98 */             ProjectSourceContainer container = new ProjectSourceContainer(p, false);
/*  99 */             container.init(getDirector());
/* 100 */             all.add(container);
/*     */           }  b++; }
/*     */         
/* 103 */         return all.<ISourceContainer>toArray(new ISourceContainer[all.size()]);
/*     */       } 
/* 105 */       return super.createSourceContainers();
/*     */     } 
/* 107 */     return new ISourceContainer[0];
/*     */   }
/*     */   
/*     */   private IProject[] getAllReferencedProjects(IProject project) throws CoreException {
/* 111 */     Set<IProject> all = new HashSet<>();
/* 112 */     getAllReferencedProjects(all, project);
/* 113 */     return all.<IProject>toArray(new IProject[all.size()]);
/*     */   }
/*     */   
/*     */   private void getAllReferencedProjects(Set<IProject> all, IProject project) throws CoreException {
/* 117 */     IProject[] refs = project.getReferencedProjects(); byte b; int i; IProject[] arrayOfIProject1;
/* 118 */     for (i = (arrayOfIProject1 = refs).length, b = 0; b < i; ) { IProject ref = arrayOfIProject1[b];
/* 119 */       if (!all.contains(ref) && ref.exists() && ref.isOpen()) {
/* 120 */         all.add(ref);
/* 121 */         getAllReferencedProjects(all, ref);
/*     */       } 
/*     */       b++; }
/*     */   
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.debug.core-3.21.0.jar!\org\eclipse\debug\core\sourcelookup\containers\ProjectSourceContainer.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */