/*     */ package org.eclipse.debug.core.sourcelookup.containers;
/*     */ 
/*     */ import org.eclipse.core.runtime.CoreException;
/*     */ import org.eclipse.core.runtime.PlatformObject;
/*     */ import org.eclipse.core.runtime.Status;
/*     */ import org.eclipse.debug.core.DebugPlugin;
/*     */ import org.eclipse.debug.core.sourcelookup.AbstractSourceLookupDirector;
/*     */ import org.eclipse.debug.core.sourcelookup.AbstractSourceLookupParticipant;
/*     */ import org.eclipse.debug.core.sourcelookup.ISourceContainer;
/*     */ import org.eclipse.debug.core.sourcelookup.ISourceContainerType;
/*     */ import org.eclipse.debug.core.sourcelookup.ISourceLookupDirector;
/*     */ import org.eclipse.debug.core.sourcelookup.ISourceLookupParticipant;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractSourceContainer
/*     */   extends PlatformObject
/*     */   implements ISourceContainer
/*     */ {
/*  37 */   public static final Object[] EMPTY = new Object[0];
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ISourceLookupDirector fDirector;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void abort(String message, Throwable exception) throws CoreException {
/*  49 */     Status status = new Status(4, DebugPlugin.getUniqueIdentifier(), 125, message, exception);
/*  50 */     throw new CoreException(status);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void warn(String message, Throwable exception) throws CoreException {
/*  62 */     Status status = new Status(2, DebugPlugin.getUniqueIdentifier(), 125, message, exception);
/*  63 */     throw new CoreException(status);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void dispose() {
/*  72 */     this.fDirector = null;
/*     */   }
/*     */ 
/*     */   
/*     */   public ISourceContainer[] getSourceContainers() throws CoreException {
/*  77 */     return new ISourceContainer[0];
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isComposite() {
/*  82 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public void init(ISourceLookupDirector director) {
/*  87 */     this.fDirector = director;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected ISourceLookupDirector getDirector() {
/*  98 */     return this.fDirector;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean isFindDuplicates() {
/* 110 */     ISourceLookupDirector director = getDirector();
/* 111 */     if (director != null) {
/* 112 */       if (director instanceof AbstractSourceLookupDirector) {
/* 113 */         AbstractSourceLookupDirector asld = (AbstractSourceLookupDirector)director;
/* 114 */         ISourceLookupParticipant participant = asld.getCurrentParticipant();
/* 115 */         if (participant instanceof AbstractSourceLookupParticipant) {
/* 116 */           AbstractSourceLookupParticipant aslp = (AbstractSourceLookupParticipant)participant;
/* 117 */           return aslp.isFindDuplicates();
/*     */         } 
/*     */       } 
/* 120 */       return director.isFindDuplicates();
/*     */     } 
/* 122 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected ISourceContainerType getSourceContainerType(String id) {
/* 133 */     return DebugPlugin.getDefault().getLaunchManager().getSourceContainerType(id);
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.debug.core-3.21.0.jar!\org\eclipse\debug\core\sourcelookup\containers\AbstractSourceContainer.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */