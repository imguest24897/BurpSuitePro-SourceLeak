/*      */ package org.eclipse.debug.internal.core;
/*      */ 
/*      */ import java.io.File;
/*      */ import java.io.IOException;
/*      */ import java.io.StringReader;
/*      */ import java.net.URI;
/*      */ import java.text.MessageFormat;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Collection;
/*      */ import java.util.HashSet;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.Set;
/*      */ import javax.xml.parsers.DocumentBuilder;
/*      */ import javax.xml.parsers.DocumentBuilderFactory;
/*      */ import javax.xml.parsers.ParserConfigurationException;
/*      */ import javax.xml.transform.TransformerException;
/*      */ import org.eclipse.core.filesystem.EFS;
/*      */ import org.eclipse.core.filesystem.IFileStore;
/*      */ import org.eclipse.core.resources.IContainer;
/*      */ import org.eclipse.core.resources.IFile;
/*      */ import org.eclipse.core.resources.IFolder;
/*      */ import org.eclipse.core.resources.IProject;
/*      */ import org.eclipse.core.resources.IResource;
/*      */ import org.eclipse.core.resources.IWorkspaceRoot;
/*      */ import org.eclipse.core.resources.ResourcesPlugin;
/*      */ import org.eclipse.core.runtime.CoreException;
/*      */ import org.eclipse.core.runtime.IPath;
/*      */ import org.eclipse.core.runtime.IProgressMonitor;
/*      */ import org.eclipse.core.runtime.IStatus;
/*      */ import org.eclipse.core.runtime.Path;
/*      */ import org.eclipse.core.runtime.PlatformObject;
/*      */ import org.eclipse.core.runtime.Status;
/*      */ import org.eclipse.core.runtime.SubMonitor;
/*      */ import org.eclipse.debug.core.DebugException;
/*      */ import org.eclipse.debug.core.DebugPlugin;
/*      */ import org.eclipse.debug.core.ILaunch;
/*      */ import org.eclipse.debug.core.ILaunchConfiguration;
/*      */ import org.eclipse.debug.core.ILaunchConfigurationType;
/*      */ import org.eclipse.debug.core.ILaunchConfigurationWorkingCopy;
/*      */ import org.eclipse.debug.core.ILaunchDelegate;
/*      */ import org.eclipse.debug.core.IStatusHandler;
/*      */ import org.eclipse.debug.core.Launch;
/*      */ import org.eclipse.debug.core.model.ILaunchConfigurationDelegate;
/*      */ import org.eclipse.debug.core.model.ILaunchConfigurationDelegate2;
/*      */ import org.eclipse.debug.core.model.IPersistableSourceLocator;
/*      */ import org.eclipse.debug.core.model.ISourceLocator;
/*      */ import org.eclipse.debug.core.sourcelookup.IPersistableSourceLocator2;
/*      */ import org.w3c.dom.Document;
/*      */ import org.w3c.dom.Element;
/*      */ import org.xml.sax.InputSource;
/*      */ import org.xml.sax.SAXException;
/*      */ import org.xml.sax.helpers.DefaultHandler;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class LaunchConfiguration
/*      */   extends PlatformObject
/*      */   implements ILaunchConfiguration
/*      */ {
/*   86 */   public static final String ATTR_MAPPED_RESOURCE_PATHS = String.valueOf(DebugPlugin.getUniqueIdentifier()) + ".MAPPED_RESOURCE_PATHS";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*   95 */   public static final String ATTR_MAPPED_RESOURCE_TYPES = String.valueOf(DebugPlugin.getUniqueIdentifier()) + ".MAPPED_RESOURCE_TYPES";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  102 */   public static final String ATTR_LAUNCH_MODES = String.valueOf(DebugPlugin.getUniqueIdentifier()) + ".LAUNCH_MODES";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  112 */   public static final String ATTR_PREFERRED_LAUNCHERS = String.valueOf(DebugPlugin.getUniqueIdentifier()) + ".preferred_launchers";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  120 */   public static final String ATTR_PROTOTYPE = String.valueOf(DebugPlugin.getUniqueIdentifier()) + ".ATTR_PROTOTYPE";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  128 */   public static final String IS_PROTOTYPE = String.valueOf(DebugPlugin.getUniqueIdentifier()) + ".IS_PROTOTYPE";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  135 */   protected static final IStatus promptStatus = (IStatus)new Status(1, "org.eclipse.debug.ui", 200, "", null);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  141 */   protected static final IStatus delegateNotAvailable = (IStatus)new Status(1, "org.eclipse.debug.core", 226, "", null);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  148 */   protected static final IStatus duplicateDelegates = (IStatus)new Status(1, "org.eclipse.debug.core", 227, "", null);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private String fName;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private IContainer fContainer;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean fIsPrototype;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected LaunchConfiguration(String name, IContainer container) {
/*  179 */     this(name, container, false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected LaunchConfiguration(String name, IContainer container, boolean prototype) {
/*  193 */     initialize();
/*  194 */     setName(name);
/*  195 */     setContainer(container);
/*  196 */     this.fIsPrototype = prototype;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void initialize() {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected LaunchConfiguration(IFile file) {
/*  213 */     this(getSimpleName(file.getName()), file.getParent(), isPrototype(file));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected static String getSimpleName(String fileName) {
/*  224 */     Path path = new Path(fileName);
/*  225 */     if ("launch".equals(path.getFileExtension()))
/*  226 */       return path.removeFileExtension().toString(); 
/*  227 */     if ("prototype".equals(path.getFileExtension())) {
/*  228 */       return path.removeFileExtension().toString();
/*      */     }
/*  230 */     return fileName;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected LaunchConfiguration(String memento) throws CoreException {
/*  242 */     Exception ex = null;
/*      */     try {
/*  244 */       Element root = null;
/*  245 */       DocumentBuilder parser = DocumentBuilderFactory.newInstance().newDocumentBuilder();
/*  246 */       parser.setErrorHandler(new DefaultHandler());
/*  247 */       StringReader reader = new StringReader(memento);
/*  248 */       InputSource source = new InputSource(reader);
/*  249 */       root = parser.parse(source).getDocumentElement();
/*      */       
/*  251 */       String localString = root.getAttribute("local");
/*  252 */       String path = root.getAttribute("path");
/*      */       
/*  254 */       String message = null;
/*  255 */       if (path == null || "".equals(path)) {
/*  256 */         message = DebugCoreMessages.LaunchConfiguration_18;
/*  257 */       } else if (localString == null || "".equals(localString)) {
/*  258 */         message = DebugCoreMessages.LaunchConfiguration_19;
/*      */       } 
/*  260 */       if (message != null) {
/*  261 */         throw new CoreException(newStatus(message, 5013, null));
/*      */       }
/*      */ 
/*      */       
/*  265 */       boolean local = Boolean.parseBoolean(localString);
/*  266 */       Path path1 = new Path(path);
/*  267 */       String name = getSimpleName(path1.lastSegment());
/*  268 */       IContainer container = null;
/*  269 */       if (!local) {
/*  270 */         container = ResourcesPlugin.getWorkspace().getRoot().getFile((IPath)path1).getParent();
/*      */       }
/*  272 */       setName(name);
/*  273 */       setContainer(container);
/*      */       return;
/*  275 */     } catch (ParserConfigurationException e) {
/*  276 */       ex = e;
/*  277 */     } catch (SAXException e) {
/*  278 */       ex = e;
/*  279 */     } catch (IOException e) {
/*  280 */       ex = e;
/*      */     } 
/*  282 */     IStatus s = newStatus(DebugCoreMessages.LaunchConfiguration_17, 5013, ex);
/*  283 */     throw new CoreException(s);
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean contentsEqual(ILaunchConfiguration object) {
/*      */     try {
/*  289 */       if (object instanceof LaunchConfiguration) {
/*  290 */         LaunchConfiguration otherConfig = (LaunchConfiguration)object;
/*  291 */         return (getName().equals(otherConfig.getName()) && 
/*  292 */           getType().equals(otherConfig.getType()) && 
/*  293 */           equalOrNull(getContainer(), otherConfig.getContainer()) && 
/*  294 */           getInfo().equals(otherConfig.getInfo()));
/*      */       } 
/*  296 */       return false;
/*  297 */     } catch (CoreException coreException) {
/*  298 */       return false;
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public ILaunchConfigurationWorkingCopy copy(String name) throws CoreException {
/*  304 */     ILaunchConfigurationWorkingCopy copy = new LaunchConfigurationWorkingCopy(this, name);
/*  305 */     return copy;
/*      */   }
/*      */ 
/*      */   
/*      */   public void delete() throws CoreException {
/*  310 */     if (exists()) {
/*  311 */       IFile file = getFile();
/*  312 */       if (file == null) {
/*  313 */         IFileStore store = getFileStore();
/*  314 */         if (store != null) {
/*  315 */           store.delete(0, null);
/*  316 */           if (store.fetchInfo().exists()) {
/*  317 */             throw new DebugException(
/*  318 */                 new Status(4, DebugPlugin.getUniqueIdentifier(), 
/*  319 */                   5012, DebugCoreMessages.LaunchConfiguration_Failed_to_delete_launch_configuration__1, null));
/*      */           
/*      */           }
/*      */         }
/*      */       
/*      */       }
/*      */       else {
/*      */         
/*  327 */         if (file.isReadOnly()) {
/*  328 */           IStatus status = ResourcesPlugin.getWorkspace().validateEdit(new IFile[] { file }, null);
/*  329 */           if (!status.isOK()) {
/*  330 */             throw new CoreException(status);
/*      */           }
/*      */         } 
/*  333 */         file.delete(true, null);
/*      */       } 
/*      */       
/*  336 */       getLaunchManager().launchConfigurationDeleted(this);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public void delete(int flag) throws CoreException {
/*  342 */     if (flag == 1 && isPrototype()) {
/*      */       
/*  344 */       Collection<ILaunchConfiguration> children = getPrototypeChildren();
/*  345 */       for (ILaunchConfiguration child : children) {
/*  346 */         ILaunchConfigurationWorkingCopy childWC = child.getWorkingCopy();
/*  347 */         childWC.setPrototype(null, false);
/*  348 */         childWC.doSave();
/*      */       } 
/*      */     } 
/*  351 */     delete();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean equals(Object object) {
/*  366 */     if (object instanceof ILaunchConfiguration) {
/*  367 */       if (isWorkingCopy()) {
/*  368 */         return (this == object);
/*      */       }
/*  370 */       LaunchConfiguration config = (LaunchConfiguration)object;
/*  371 */       if (!config.isWorkingCopy()) {
/*  372 */         return (getName().equals(config.getName()) && 
/*  373 */           equalOrNull(getContainer(), config.getContainer()));
/*      */       }
/*      */     } 
/*  376 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean equalOrNull(Object o1, Object o2) {
/*  388 */     if (o1 == null)
/*  389 */       return (o2 == null); 
/*  390 */     if (o2 != null) {
/*  391 */       return o1.equals(o2);
/*      */     }
/*  393 */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean exists() {
/*  398 */     IFile file = getFile();
/*  399 */     if (file != null) {
/*  400 */       return file.exists();
/*      */     }
/*      */     try {
/*  403 */       IFileStore store = getFileStore();
/*  404 */       if (store != null) {
/*  405 */         return store.fetchInfo().exists();
/*      */       }
/*  407 */     } catch (CoreException coreException) {}
/*      */     
/*  409 */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean getAttribute(String attributeName, boolean defaultValue) throws CoreException {
/*  414 */     return getInfo().getBooleanAttribute(attributeName, defaultValue);
/*      */   }
/*      */ 
/*      */   
/*      */   public int getAttribute(String attributeName, int defaultValue) throws CoreException {
/*  419 */     return getInfo().getIntAttribute(attributeName, defaultValue);
/*      */   }
/*      */ 
/*      */   
/*      */   public List<String> getAttribute(String attributeName, List<String> defaultValue) throws CoreException {
/*  424 */     return getInfo().getListAttribute(attributeName, defaultValue);
/*      */   }
/*      */ 
/*      */   
/*      */   public Set<String> getAttribute(String attributeName, Set<String> defaultValue) throws CoreException {
/*  429 */     return getInfo().getSetAttribute(attributeName, defaultValue);
/*      */   }
/*      */ 
/*      */   
/*      */   public Map<String, String> getAttribute(String attributeName, Map<String, String> defaultValue) throws CoreException {
/*  434 */     return getInfo().getMapAttribute(attributeName, defaultValue);
/*      */   }
/*      */ 
/*      */   
/*      */   public String getAttribute(String attributeName, String defaultValue) throws CoreException {
/*  439 */     return getInfo().getStringAttribute(attributeName, defaultValue);
/*      */   }
/*      */ 
/*      */   
/*      */   public Map<String, Object> getAttributes() throws CoreException {
/*  444 */     LaunchConfigurationInfo info = getInfo();
/*  445 */     return info.getAttributes();
/*      */   }
/*      */ 
/*      */   
/*      */   public String getCategory() throws CoreException {
/*  450 */     return getType().getCategory();
/*      */   }
/*      */ 
/*      */   
/*      */   public IFile getFile() {
/*  455 */     IContainer container = getContainer();
/*  456 */     if (container != null) {
/*  457 */       return container.getFile((IPath)new Path(getFileName()));
/*      */     }
/*  459 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected String getFileName() {
/*  469 */     StringBuilder buf = new StringBuilder(getName());
/*  470 */     buf.append('.');
/*  471 */     if (isPrototype()) {
/*  472 */       buf.append("prototype");
/*      */     } else {
/*  474 */       buf.append("launch");
/*      */     } 
/*  476 */     return buf.toString();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected LaunchConfigurationInfo getInfo() throws CoreException {
/*  488 */     return getLaunchManager().getInfo(this);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected LaunchManager getLaunchManager() {
/*  497 */     return (LaunchManager)DebugPlugin.getDefault().getLaunchManager();
/*      */   }
/*      */ 
/*      */   
/*      */   public IPath getLocation() {
/*      */     try {
/*  503 */       IFileStore store = getFileStore();
/*  504 */       if (store != null) {
/*  505 */         File localFile = store.toLocalFile(0, null);
/*  506 */         if (localFile != null) {
/*  507 */           return (IPath)new Path(localFile.getAbsolutePath());
/*      */         }
/*      */       } 
/*  510 */     } catch (CoreException coreException) {}
/*      */     
/*  512 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public IFileStore getFileStore() throws CoreException {
/*  525 */     if (isLocal()) {
/*  526 */       return EFS.getLocalFileSystem().fromLocalFile(
/*  527 */           LaunchManager.LOCAL_LAUNCH_CONFIGURATION_CONTAINER_PATH.append(getFileName()).toFile());
/*      */     }
/*  529 */     URI uri = getFile().getLocationURI();
/*  530 */     if (uri != null) {
/*  531 */       return EFS.getStore(uri);
/*      */     }
/*  533 */     return null;
/*      */   }
/*      */ 
/*      */   
/*      */   public IResource[] getMappedResources() throws CoreException {
/*  538 */     List<String> paths = getAttribute(ATTR_MAPPED_RESOURCE_PATHS, (List<String>)null);
/*  539 */     if (paths == null || paths.isEmpty()) {
/*  540 */       return null;
/*      */     }
/*  542 */     List<String> types = getAttribute(ATTR_MAPPED_RESOURCE_TYPES, (List<String>)null);
/*  543 */     if (types == null || types.size() != paths.size()) {
/*  544 */       throw new CoreException(newStatus(DebugCoreMessages.LaunchConfiguration_0, 125, null));
/*      */     }
/*  546 */     ArrayList<IResource> list = new ArrayList<>();
/*  547 */     IWorkspaceRoot root = ResourcesPlugin.getWorkspace().getRoot();
/*  548 */     for (int i = 0; i < paths.size(); i++) {
/*  549 */       IFile iFile; IFolder iFolder; IWorkspaceRoot iWorkspaceRoot; String pathStr = paths.get(i);
/*  550 */       String typeStr = types.get(i);
/*  551 */       int type = -1;
/*      */       try {
/*  553 */         type = Integer.decode(typeStr).intValue();
/*  554 */       } catch (NumberFormatException e) {
/*  555 */         throw new CoreException(newStatus(DebugCoreMessages.LaunchConfiguration_0, 125, e));
/*      */       } 
/*  557 */       IPath path = Path.fromPortableString(pathStr);
/*  558 */       IResource res = null;
/*  559 */       switch (type) {
/*      */         case 1:
/*  561 */           iFile = root.getFile(path);
/*      */           break;
/*      */         case 4:
/*  564 */           pathStr = path.makeRelative().toPortableString();
/*  565 */           if (Path.ROOT.isValidSegment(pathStr)) {
/*  566 */             IProject iProject = root.getProject(pathStr);
/*      */           }
/*      */           break;
/*      */         case 2:
/*  570 */           iFolder = root.getFolder(path);
/*      */           break;
/*      */         case 8:
/*  573 */           iWorkspaceRoot = root;
/*      */           break;
/*      */         default:
/*  576 */           throw new CoreException(newStatus(DebugCoreMessages.LaunchConfiguration_0, 125, null));
/*      */       } 
/*  578 */       if (iWorkspaceRoot != null) {
/*  579 */         list.add(iWorkspaceRoot);
/*      */       }
/*      */     } 
/*  582 */     if (list.isEmpty()) {
/*  583 */       return null;
/*      */     }
/*  585 */     return list.<IResource>toArray(new IResource[list.size()]);
/*      */   }
/*      */ 
/*      */   
/*      */   public String getMemento() throws CoreException {
/*  590 */     IPath relativePath = null;
/*  591 */     IFile file = getFile();
/*  592 */     String lineDelimeter = getLineSeparator();
/*  593 */     boolean local = true;
/*  594 */     if (file == null) {
/*  595 */       Path path = new Path(getName());
/*      */     } else {
/*  597 */       local = false;
/*  598 */       relativePath = file.getFullPath();
/*      */     } 
/*  600 */     Exception e = null;
/*      */     try {
/*  602 */       Document doc = LaunchManager.getDocument();
/*  603 */       Element node = doc.createElement("launchConfiguration");
/*  604 */       doc.appendChild(node);
/*  605 */       node.setAttribute("local", Boolean.toString(local));
/*  606 */       node.setAttribute("path", relativePath.toString());
/*  607 */       return LaunchManager.serializeDocument(doc, lineDelimeter);
/*  608 */     } catch (IOException ioe) {
/*  609 */       e = ioe;
/*  610 */     } catch (ParserConfigurationException pce) {
/*  611 */       e = pce;
/*  612 */     } catch (TransformerException te) {
/*  613 */       e = te;
/*      */     } 
/*  615 */     IStatus status = newStatus(DebugCoreMessages.LaunchConfiguration_16, 5013, e);
/*  616 */     throw new CoreException(status);
/*      */   }
/*      */ 
/*      */   
/*      */   public String getName() {
/*  621 */     return this.fName;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected IContainer getContainer() {
/*  633 */     return this.fContainer;
/*      */   }
/*      */ 
/*      */   
/*      */   public Set<String> getModes() throws CoreException {
/*  638 */     Set<String> options = getAttribute(ATTR_LAUNCH_MODES, (Set<String>)null);
/*  639 */     return (options != null) ? new HashSet<>(options) : new HashSet<>(0);
/*      */   }
/*      */ 
/*      */   
/*      */   public ILaunchConfigurationType getType() throws CoreException {
/*  644 */     return getInfo().getType();
/*      */   }
/*      */ 
/*      */   
/*      */   public ILaunchConfigurationWorkingCopy getWorkingCopy() throws CoreException {
/*  649 */     return new LaunchConfigurationWorkingCopy(this);
/*      */   }
/*      */ 
/*      */   
/*      */   public int hashCode() {
/*  654 */     IContainer container = getContainer();
/*  655 */     if (container == null) {
/*  656 */       return getName().hashCode();
/*      */     }
/*  658 */     return getName().hashCode() + container.hashCode();
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean hasAttribute(String attributeName) throws CoreException {
/*  664 */     return getInfo().hasAttribute(attributeName);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void initializeSourceLocator(ILaunch launch) throws CoreException {
/*  675 */     if (launch.getSourceLocator() == null) {
/*  676 */       String type = getAttribute(ATTR_SOURCE_LOCATOR_ID, (String)null);
/*  677 */       if (type == null) {
/*  678 */         type = getType().getSourceLocatorId();
/*      */       }
/*  680 */       if (type != null) {
/*  681 */         IPersistableSourceLocator locator = getLaunchManager().newSourceLocator(type);
/*  682 */         String memento = getAttribute(ATTR_SOURCE_LOCATOR_MEMENTO, (String)null);
/*  683 */         if (memento == null) {
/*  684 */           locator.initializeDefaults(this);
/*  685 */         } else if (locator instanceof IPersistableSourceLocator2) {
/*  686 */           ((IPersistableSourceLocator2)locator).initializeFromMemento(memento, this);
/*      */         } else {
/*  688 */           locator.initializeFromMemento(memento);
/*      */         } 
/*  690 */         launch.setSourceLocator((ISourceLocator)locator);
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isLocal() {
/*  697 */     return (getContainer() == null);
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isMigrationCandidate() throws CoreException {
/*  702 */     return ((LaunchConfigurationType)getType()).isMigrationCandidate(this);
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isWorkingCopy() {
/*  707 */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   public ILaunch launch(String mode, IProgressMonitor monitor) throws CoreException {
/*  712 */     return launch(mode, monitor, false);
/*      */   }
/*      */ 
/*      */   
/*      */   public ILaunch launch(String mode, IProgressMonitor monitor, boolean build) throws CoreException {
/*  717 */     return launch(mode, monitor, build, true);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ILaunch launch(String mode, IProgressMonitor monitor, boolean build, boolean register) throws CoreException {
/*  730 */     SubMonitor lmonitor = SubMonitor.convert(monitor, DebugCoreMessages.LaunchConfiguration_9, 23);
/*      */     try {
/*      */       Launch launch1;
/*  733 */       ILaunchConfigurationDelegate delegate = getPreferredLaunchDelegate(mode);
/*      */       
/*  735 */       ILaunchConfigurationDelegate2 delegate2 = null;
/*  736 */       if (delegate instanceof ILaunchConfigurationDelegate2) {
/*  737 */         delegate2 = (ILaunchConfigurationDelegate2)delegate;
/*      */       }
/*      */       
/*  740 */       ILaunch launch = null;
/*      */       try {
/*  742 */         if (delegate2 != null) {
/*  743 */           launch = delegate2.getLaunch(this, mode);
/*      */         }
/*  745 */         if (launch == null) {
/*  746 */           launch1 = new Launch(this, mode, null);
/*      */         }
/*  748 */         else if (!mode.equals(launch1.getLaunchMode())) {
/*  749 */           Status status = new Status(4, DebugPlugin.getUniqueIdentifier(), 125, 
/*  750 */               MessageFormat.format(DebugCoreMessages.LaunchConfiguration_14, new Object[] { mode, launch1.getLaunchMode() }), null);
/*  751 */           throw new CoreException(status);
/*      */         } 
/*  753 */         launch1.setAttribute("org.eclipse.debug.core.launch.timestamp", Long.toString(System.currentTimeMillis()));
/*  754 */         boolean captureOutput = getAttribute("org.eclipse.debug.core.capture_output", true);
/*  755 */         if (!captureOutput) {
/*  756 */           launch1.setAttribute("org.eclipse.debug.core.capture_output", "false");
/*      */         } else {
/*  758 */           launch1.setAttribute("org.eclipse.debug.core.capture_output", null);
/*      */         } 
/*  760 */         if (!getAttribute("org.eclipse.debug.core.ATTR_FORCE_SYSTEM_CONSOLE_ENCODING", false)) {
/*  761 */           launch1.setAttribute("org.eclipse.debug.ui.ATTR_CONSOLE_ENCODING", getLaunchManager().getEncoding(this));
/*      */         }
/*  763 */         if (register) {
/*  764 */           getLaunchManager().addLaunch((ILaunch)launch1);
/*      */         }
/*      */         
/*  767 */         lmonitor.subTask(DebugCoreMessages.LaunchConfiguration_8);
/*      */         
/*  769 */         if (delegate2 != null && 
/*  770 */           !delegate2.preLaunchCheck(this, mode, (IProgressMonitor)lmonitor.split(1))) {
/*  771 */           getLaunchManager().removeLaunch((ILaunch)launch1);
/*  772 */           return (ILaunch)launch1;
/*      */         } 
/*      */         
/*  775 */         lmonitor.setWorkRemaining(22);
/*      */         
/*  777 */         if (build) {
/*  778 */           lmonitor.subTask(String.valueOf(DebugCoreMessages.LaunchConfiguration_7) + DebugCoreMessages.LaunchConfiguration_6);
/*  779 */           boolean tempbuild = build;
/*  780 */           if (delegate2 != null) {
/*  781 */             tempbuild = delegate2.buildForLaunch(this, mode, (IProgressMonitor)lmonitor.split(7));
/*      */           }
/*  783 */           if (tempbuild) {
/*  784 */             lmonitor.subTask(String.valueOf(DebugCoreMessages.LaunchConfiguration_7) + DebugCoreMessages.LaunchConfiguration_5);
/*  785 */             ResourcesPlugin.getWorkspace().build(10, (IProgressMonitor)lmonitor.split(3));
/*      */           } 
/*      */         } 
/*  788 */         lmonitor.setWorkRemaining(12);
/*      */         
/*  790 */         lmonitor.subTask(DebugCoreMessages.LaunchConfiguration_4);
/*  791 */         if (delegate2 != null && 
/*  792 */           !delegate2.finalLaunchCheck(this, mode, (IProgressMonitor)lmonitor.split(1))) {
/*  793 */           getLaunchManager().removeLaunch((ILaunch)launch1);
/*  794 */           return (ILaunch)launch1;
/*      */         } 
/*      */         
/*  797 */         lmonitor.setWorkRemaining(11);
/*      */ 
/*      */         
/*  800 */         lmonitor.subTask(DebugCoreMessages.LaunchConfiguration_3);
/*  801 */         initializeSourceLocator((ILaunch)launch1);
/*  802 */         lmonitor.worked(1);
/*      */ 
/*      */         
/*  805 */         lmonitor.subTask(DebugCoreMessages.LaunchConfiguration_2);
/*  806 */         delegate.launch(this, mode, (ILaunch)launch1, (IProgressMonitor)lmonitor.split(10));
/*  807 */       } catch (CoreException e) {
/*      */         
/*  809 */         if (launch1 != null && !launch1.hasChildren()) {
/*  810 */           getLaunchManager().removeLaunch((ILaunch)launch1);
/*      */         }
/*  812 */         throw e;
/*  813 */       } catch (RuntimeException e) {
/*      */         
/*  815 */         if (launch1 != null && !launch1.hasChildren()) {
/*  816 */           getLaunchManager().removeLaunch((ILaunch)launch1);
/*      */         }
/*  818 */         throw e;
/*      */       } 
/*  820 */       if (lmonitor.isCanceled()) {
/*  821 */         getLaunchManager().removeLaunch((ILaunch)launch1);
/*      */       }
/*  823 */       return (ILaunch)launch1;
/*      */     } finally {
/*      */       
/*  826 */       lmonitor.done();
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public void migrate() throws CoreException {
/*  832 */     ((LaunchConfigurationType)getType()).migrate(this);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected IStatus newStatus(String message, int code, Throwable e) {
/*  845 */     return (IStatus)new Status(4, DebugPlugin.getUniqueIdentifier(), code, message, e);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void setName(String name) {
/*  855 */     this.fName = name;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void setContainer(IContainer container) {
/*  866 */     this.fContainer = container;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean supportsMode(String mode) throws CoreException {
/*  871 */     return getType().supportsMode(mode);
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isReadOnly() {
/*      */     try {
/*  877 */       IFileStore fileStore = getFileStore();
/*  878 */       if (fileStore != null) {
/*  879 */         return fileStore.fetchInfo().getAttribute(2);
/*      */       }
/*  881 */     } catch (CoreException coreException) {}
/*      */     
/*  883 */     return true;
/*      */   }
/*      */ 
/*      */   
/*      */   public ILaunchDelegate getPreferredDelegate(Set<String> modes) throws CoreException {
/*  888 */     Map<String, String> delegates = getAttribute(ATTR_PREFERRED_LAUNCHERS, (Map<String, String>)null);
/*  889 */     if (delegates != null) {
/*  890 */       String id = delegates.get(modes.toString());
/*  891 */       if (id != null) {
/*  892 */         return getLaunchManager().getLaunchDelegate(id);
/*      */       }
/*      */     } 
/*  895 */     return null;
/*      */   }
/*      */ 
/*      */   
/*      */   public String toString() {
/*  900 */     return getName();
/*      */   }
/*      */ 
/*      */   
/*      */   public ILaunchConfiguration getPrototype() throws CoreException {
/*  905 */     String memento = getAttribute(ATTR_PROTOTYPE, (String)null);
/*  906 */     if (memento != null) {
/*  907 */       LaunchConfiguration prototype = new LaunchConfiguration(memento);
/*  908 */       prototype.setIsPrototype(true);
/*  909 */       return prototype;
/*      */     } 
/*  911 */     return null;
/*      */   }
/*      */ 
/*      */   
/*      */   public Collection<ILaunchConfiguration> getPrototypeChildren() throws CoreException {
/*  916 */     ILaunchConfiguration[] configurations = getLaunchManager().getLaunchConfigurations(getType());
/*  917 */     List<ILaunchConfiguration> proteges = new ArrayList<>(); byte b; int i; ILaunchConfiguration[] arrayOfILaunchConfiguration1;
/*  918 */     for (i = (arrayOfILaunchConfiguration1 = configurations).length, b = 0; b < i; ) { ILaunchConfiguration config = arrayOfILaunchConfiguration1[b];
/*  919 */       if (equals(config.getPrototype()))
/*  920 */         proteges.add(config); 
/*      */       b++; }
/*      */     
/*  923 */     return proteges;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isPrototype() {
/*  928 */     return this.fIsPrototype;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void setIsPrototype(boolean isPrototype) {
/*  939 */     this.fIsPrototype = isPrototype;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected static boolean isPrototype(IFile file) {
/*  952 */     if ("prototype".equals(file.getFileExtension())) {
/*  953 */       return true;
/*      */     }
/*  955 */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   public int getKind() throws CoreException {
/*  960 */     if (this.fIsPrototype) {
/*  961 */       return 2;
/*      */     }
/*  963 */     return 1;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isAttributeModified(String attribute) throws CoreException {
/*  968 */     ILaunchConfiguration prototype = getPrototype();
/*  969 */     if (prototype != null) {
/*  970 */       Object prototypeValue = prototype.getAttributes().get(attribute);
/*  971 */       Object attributeValue = getAttributes().get(attribute);
/*  972 */       return !LaunchConfigurationInfo.compareAttribute(attribute, prototypeValue, attributeValue);
/*      */     } 
/*  974 */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   public Set<String> getPrototypeVisibleAttributes() throws CoreException {
/*  979 */     return getInfo().getVisibleAttributes();
/*      */   }
/*      */ 
/*      */   
/*      */   public void setPrototypeAttributeVisibility(String attribute, boolean visible) throws CoreException {
/*  984 */     getInfo().setAttributeVisibility(attribute, visible);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public ILaunchConfigurationDelegate getPreferredLaunchDelegate(String mode) throws CoreException {
/*      */     IStatusHandler handler;
/*      */     Status status;
/*  992 */     Set<String> modes = getModes();
/*  993 */     modes.add(mode);
/*  994 */     ILaunchDelegate[] delegates = getType().getDelegates(modes);
/*  995 */     ILaunchConfigurationDelegate delegate = null;
/*  996 */     switch (delegates.length)
/*      */     { case 1:
/*  998 */         delegate = delegates[0].getDelegate();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1043 */         return delegate;case 0: handler = DebugPlugin.getDefault().getStatusHandler(promptStatus); if (handler != null) handler.handleStatus(delegateNotAvailable, new Object[] { this, mode });  status = new Status(8, DebugPlugin.getUniqueIdentifier(), 125, DebugCoreMessages.LaunchConfiguration_11, null); throw new CoreException(status); }  ILaunchDelegate del = getPreferredDelegate(modes); if (del == null) del = getType().getPreferredDelegate(modes);  if (del == null) { IStatusHandler iStatusHandler = DebugPlugin.getDefault().getStatusHandler(promptStatus); IStatus iStatus = null; if (iStatusHandler != null) iStatus = (IStatus)iStatusHandler.handleStatus(duplicateDelegates, new Object[] { this, mode });  if (iStatus != null && iStatus.isOK()) { del = getPreferredDelegate(modes); if (del == null) del = getType().getPreferredDelegate(modes);  if (del != null) { delegate = del.getDelegate(); } else { Status status1 = new Status(8, DebugPlugin.getUniqueIdentifier(), 125, DebugCoreMessages.LaunchConfiguration_13, null); throw new CoreException(status1); }  } else { Status status1 = new Status(8, DebugPlugin.getUniqueIdentifier(), 125, DebugCoreMessages.LaunchConfiguration_13, null); throw new CoreException(status1); }  } else { delegate = del.getDelegate(); }  return delegate;
/*      */   }
/*      */   
/*      */   protected String getLineSeparator() throws CoreException {
/* 1047 */     IFile file = getFile();
/* 1048 */     if (file != null)
/*      */     {
/* 1050 */       return file.getLineSeparator(true);
/*      */     }
/*      */ 
/*      */     
/* 1054 */     return System.lineSeparator();
/*      */   }
/*      */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.debug.core-3.21.0.jar!\org\eclipse\debug\internal\core\LaunchConfiguration.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */