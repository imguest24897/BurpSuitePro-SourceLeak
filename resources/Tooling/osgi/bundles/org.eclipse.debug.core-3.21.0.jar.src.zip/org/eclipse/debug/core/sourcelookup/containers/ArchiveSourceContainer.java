/*     */ package org.eclipse.debug.core.sourcelookup.containers;
/*     */ 
/*     */ import org.eclipse.core.resources.IFile;
/*     */ import org.eclipse.core.runtime.CoreException;
/*     */ import org.eclipse.debug.core.DebugPlugin;
/*     */ import org.eclipse.debug.core.sourcelookup.ISourceContainerType;
/*     */ import org.eclipse.debug.core.sourcelookup.ISourceLookupDirector;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ArchiveSourceContainer
/*     */   extends AbstractSourceContainer
/*     */ {
/*     */   private IFile fFile;
/*     */   private boolean fDetectRoot;
/*     */   private ExternalArchiveSourceContainer fDelegateContainer;
/*  41 */   public static final String TYPE_ID = String.valueOf(DebugPlugin.getUniqueIdentifier()) + ".containerType.archive";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ArchiveSourceContainer(IFile archive, boolean detectRootPath) {
/*  59 */     this.fFile = archive;
/*  60 */     this.fDetectRoot = detectRootPath;
/*  61 */     if (archive.exists() && archive.getLocation() != null) {
/*  62 */       this.fDelegateContainer = new ExternalArchiveSourceContainer(archive.getLocation().toOSString(), detectRootPath);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public String getName() {
/*  68 */     return this.fFile.getName();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IFile getFile() {
/*  77 */     return this.fFile;
/*     */   }
/*     */ 
/*     */   
/*     */   public ISourceContainerType getType() {
/*  82 */     return getSourceContainerType(TYPE_ID);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object obj) {
/*  87 */     return (obj instanceof ArchiveSourceContainer && (
/*  88 */       (ArchiveSourceContainer)obj).getName().equals(getName()));
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/*  93 */     return getName().hashCode();
/*     */   }
/*     */ 
/*     */   
/*     */   public Object[] findSourceElements(String name) throws CoreException {
/*  98 */     ExternalArchiveSourceContainer container = getDelegateContainer();
/*  99 */     if (container != null) {
/* 100 */       return container.findSourceElements(name);
/*     */     }
/* 102 */     return EMPTY;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ExternalArchiveSourceContainer getDelegateContainer() {
/* 112 */     return this.fDelegateContainer;
/*     */   }
/*     */   
/*     */   public void init(ISourceLookupDirector director) {
/* 116 */     super.init(director);
/* 117 */     if (this.fDelegateContainer != null) {
/* 118 */       this.fDelegateContainer.init(director);
/*     */     }
/*     */   }
/*     */   
/*     */   public void dispose() {
/* 123 */     super.dispose();
/* 124 */     if (this.fDelegateContainer != null) {
/* 125 */       this.fDelegateContainer.dispose();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isDetectRoot() {
/* 138 */     return this.fDetectRoot;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.debug.core-3.21.0.jar!\org\eclipse\debug\core\sourcelookup\containers\ArchiveSourceContainer.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */