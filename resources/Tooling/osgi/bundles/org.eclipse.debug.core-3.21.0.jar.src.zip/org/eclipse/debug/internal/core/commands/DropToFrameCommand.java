/*    */ package org.eclipse.debug.internal.core.commands;
/*    */ 
/*    */ import org.eclipse.core.runtime.CoreException;
/*    */ import org.eclipse.debug.core.commands.IDebugCommandRequest;
/*    */ import org.eclipse.debug.core.commands.IDropToFrameHandler;
/*    */ import org.eclipse.debug.core.model.IDropToFrame;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DropToFrameCommand
/*    */   extends StepCommand
/*    */   implements IDropToFrameHandler
/*    */ {
/*    */   protected Object getTarget(Object element) {
/* 30 */     return getAdapter(element, IDropToFrame.class);
/*    */   }
/*    */ 
/*    */   
/*    */   protected boolean isSteppable(Object target) throws CoreException {
/* 35 */     return ((IDropToFrame)target).canDropToFrame();
/*    */   }
/*    */ 
/*    */   
/*    */   protected void step(Object target) throws CoreException {
/* 40 */     ((IDropToFrame)target).dropToFrame();
/*    */   }
/*    */ 
/*    */   
/*    */   protected Object getEnabledStateJobFamily(IDebugCommandRequest request) {
/* 45 */     return IDropToFrameHandler.class;
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.debug.core-3.21.0.jar!\org\eclipse\debug\internal\core\commands\DropToFrameCommand.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */