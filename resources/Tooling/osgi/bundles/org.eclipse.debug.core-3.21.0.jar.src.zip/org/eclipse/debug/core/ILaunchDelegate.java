package org.eclipse.debug.core;

import java.util.List;
import java.util.Set;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.debug.core.model.ILaunchConfigurationDelegate;

public interface ILaunchDelegate {
  String getId();
  
  String getName();
  
  String getDescription();
  
  String getContributorName();
  
  ILaunchConfigurationDelegate getDelegate() throws CoreException;
  
  List<Set<String>> getModes();
  
  String getPluginIdentifier();
  
  String getPerspectiveId(Set<String> paramSet);
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.debug.core-3.21.0.jar!\org\eclipse\debug\core\ILaunchDelegate.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */