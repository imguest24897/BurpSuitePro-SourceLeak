/*     */ package org.eclipse.debug.internal.core.sourcelookup;
/*     */ 
/*     */ import org.eclipse.core.resources.IResourceChangeEvent;
/*     */ import org.eclipse.core.resources.IResourceChangeListener;
/*     */ import org.eclipse.debug.core.ILaunch;
/*     */ import org.eclipse.debug.core.ILaunchesListener2;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class ArchiveCleaner
/*     */   implements IResourceChangeListener, ILaunchesListener2
/*     */ {
/*     */   public void launchesRemoved(ILaunch[] launches) {
/*     */     byte b;
/*     */     int i;
/*     */     ILaunch[] arrayOfILaunch;
/* 111 */     for (i = (arrayOfILaunch = launches).length, b = 0; b < i; ) { ILaunch launch = arrayOfILaunch[b];
/* 112 */       if (!launch.isTerminated()) {
/* 113 */         SourceLookupUtils.closeArchives();
/*     */         return;
/*     */       } 
/*     */       b++; }
/*     */   
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void launchesAdded(ILaunch[] launches) {}
/*     */ 
/*     */   
/*     */   public void launchesChanged(ILaunch[] launches) {}
/*     */ 
/*     */   
/*     */   public void resourceChanged(IResourceChangeEvent event) {
/* 129 */     SourceLookupUtils.closeArchives();
/*     */   }
/*     */ 
/*     */   
/*     */   public void launchesTerminated(ILaunch[] launches) {
/* 134 */     SourceLookupUtils.closeArchives();
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.debug.core-3.21.0.jar!\org\eclipse\debug\internal\core\sourcelookup\SourceLookupUtils$ArchiveCleaner.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */