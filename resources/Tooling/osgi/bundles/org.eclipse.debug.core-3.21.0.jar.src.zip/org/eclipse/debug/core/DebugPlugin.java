/*      */ package org.eclipse.debug.core;
/*      */ 
/*      */ import java.io.ByteArrayInputStream;
/*      */ import java.io.File;
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import java.nio.charset.StandardCharsets;
/*      */ import java.text.MessageFormat;
/*      */ import java.util.ArrayList;
/*      */ import java.util.HashMap;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import javax.xml.parsers.DocumentBuilder;
/*      */ import javax.xml.parsers.DocumentBuilderFactory;
/*      */ import javax.xml.parsers.FactoryConfigurationError;
/*      */ import javax.xml.parsers.ParserConfigurationException;
/*      */ import javax.xml.transform.TransformerException;
/*      */ import org.eclipse.core.resources.ISaveContext;
/*      */ import org.eclipse.core.resources.ISaveParticipant;
/*      */ import org.eclipse.core.resources.ResourcesPlugin;
/*      */ import org.eclipse.core.runtime.CoreException;
/*      */ import org.eclipse.core.runtime.IAdaptable;
/*      */ import org.eclipse.core.runtime.IAdapterFactory;
/*      */ import org.eclipse.core.runtime.IAdapterManager;
/*      */ import org.eclipse.core.runtime.IConfigurationElement;
/*      */ import org.eclipse.core.runtime.IExtensionPoint;
/*      */ import org.eclipse.core.runtime.IProgressMonitor;
/*      */ import org.eclipse.core.runtime.ISafeRunnable;
/*      */ import org.eclipse.core.runtime.IStatus;
/*      */ import org.eclipse.core.runtime.ListenerList;
/*      */ import org.eclipse.core.runtime.Platform;
/*      */ import org.eclipse.core.runtime.Plugin;
/*      */ import org.eclipse.core.runtime.SafeRunner;
/*      */ import org.eclipse.core.runtime.Status;
/*      */ import org.eclipse.core.runtime.jobs.Job;
/*      */ import org.eclipse.debug.core.model.IDebugElement;
/*      */ import org.eclipse.debug.core.model.IDisconnect;
/*      */ import org.eclipse.debug.core.model.IDropToFrame;
/*      */ import org.eclipse.debug.core.model.IProcess;
/*      */ import org.eclipse.debug.core.model.IStep;
/*      */ import org.eclipse.debug.core.model.IStepFilter;
/*      */ import org.eclipse.debug.core.model.IStepFilters;
/*      */ import org.eclipse.debug.core.model.ISuspendResume;
/*      */ import org.eclipse.debug.core.model.ITerminate;
/*      */ import org.eclipse.debug.core.model.IValue;
/*      */ import org.eclipse.debug.core.model.RuntimeProcess;
/*      */ import org.eclipse.debug.internal.core.BreakpointManager;
/*      */ import org.eclipse.debug.internal.core.DebugCoreMessages;
/*      */ import org.eclipse.debug.internal.core.DebugOptions;
/*      */ import org.eclipse.debug.internal.core.ExpressionManager;
/*      */ import org.eclipse.debug.internal.core.IInternalDebugCoreConstants;
/*      */ import org.eclipse.debug.internal.core.LaunchManager;
/*      */ import org.eclipse.debug.internal.core.LogicalStructureManager;
/*      */ import org.eclipse.debug.internal.core.MemoryBlockManager;
/*      */ import org.eclipse.debug.internal.core.Preferences;
/*      */ import org.eclipse.debug.internal.core.StepFilterManager;
/*      */ import org.eclipse.debug.internal.core.commands.CommandAdapterFactory;
/*      */ import org.eclipse.debug.internal.core.groups.GroupMemberChangeListener;
/*      */ import org.eclipse.debug.internal.core.sourcelookup.SourceLookupUtils;
/*      */ import org.osgi.framework.BundleContext;
/*      */ import org.w3c.dom.Document;
/*      */ import org.w3c.dom.Element;
/*      */ import org.xml.sax.SAXException;
/*      */ import org.xml.sax.helpers.DefaultHandler;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class DebugPlugin
/*      */   extends Plugin
/*      */ {
/*      */   private static final String PI_DEBUG_CORE = "org.eclipse.debug.core";
/*      */   public static final String EXTENSION_POINT_LAUNCH_CONFIGURATION_TYPES = "launchConfigurationTypes";
/*      */   public static final String EXTENSION_POINT_LAUNCH_CONFIGURATION_COMPARATORS = "launchConfigurationComparators";
/*      */   public static final String EXTENSION_POINT_BREAKPOINTS = "breakpoints";
/*      */   public static final String EXTENSION_POINT_STATUS_HANDLERS = "statusHandlers";
/*      */   public static final String EXTENSION_POINT_SOURCE_LOCATORS = "sourceLocators";
/*      */   public static final String EXTENSION_POINT_LAUNCH_MODES = "launchModes";
/*      */   public static final String EXTENSION_POINT_LAUNCH_DELEGATES = "launchDelegates";
/*      */   public static final String EXTENSION_POINT_PROCESS_FACTORIES = "processFactories";
/*      */   public static final String EXTENSION_POINT_LOGICAL_STRUCTURE_TYPES = "logicalStructureTypes";
/*      */   public static final String EXTENSION_POINT_LOGICAL_STRUCTURE_PROVIDERS = "logicalStructureProviders";
/*      */   public static final String EXTENSION_POINT_SOURCE_CONTAINER_TYPES = "sourceContainerTypes";
/*      */   public static final String EXTENSION_POINT_SOURCE_PATH_COMPUTERS = "sourcePathComputers";
/*      */   public static final String EXTENSION_POINT_LAUNCH_OPTIONS = "launchOptions";
/*      */   public static final String EXTENSION_POINT_BREAKPOINT_IMPORT_PARTICIPANTS = "breakpointImportParticipants";
/*      */   public static final String EXTENSION_POINT_STEP_FILTERS = "stepFilters";
/*      */   public static final int ERROR = 125;
/*      */   public static final int INTERNAL_ERROR = 120;
/*      */   public static final int ERR_WORKING_DIRECTORY_NOT_SUPPORTED = 115;
/*      */   public static final String ATTR_PROCESS_FACTORY_ID = "process_factory_id";
/*      */   public static final String ATTR_CAPTURE_OUTPUT = "org.eclipse.debug.core.capture_output";
/*      */   public static final String ATTR_LAUNCH_TIMESTAMP = "org.eclipse.debug.core.launch.timestamp";
/*      */   public static final String ATTR_TERMINATE_TIMESTAMP = "org.eclipse.debug.core.terminate.timestamp";
/*      */   public static final String ATTR_CONSOLE_ENCODING = "org.eclipse.debug.ui.ATTR_CONSOLE_ENCODING";
/*      */   public static final String ATTR_FORCE_SYSTEM_CONSOLE_ENCODING = "org.eclipse.debug.core.ATTR_FORCE_SYSTEM_CONSOLE_ENCODING";
/*      */   public static final String ATTR_MERGE_OUTPUT = "org.eclipse.debug.core.ATTR_MERGE_OUTPUT";
/*      */   public static final String PREF_DELETE_CONFIGS_ON_PROJECT_DELETE = "org.eclipse.debug.core.PREF_DELETE_CONFIGS_ON_PROJECT_DELETE";
/*      */   public static final String ATTR_BREAKPOINT_IS_DELETED = "org.eclipse.debug.core.breakpointIsDeleted";
/*      */   public static final String ATTR_ENVIRONMENT = "org.eclipse.debug.core.ATTR_ENVIRONMENT";
/*      */   public static final String ATTR_WORKING_DIRECTORY = "org.eclipse.debug.core.ATTR_WORKING_DIRECTORY";
/*      */   public static final String ATTR_PATH = "org.eclipse.debug.core.ATTR_PATH";
/*      */   public static final String ATTR_TERMINATE_DESCENDANTS = "org.eclipse.debug.core.TERMINATE_DESCENDANTS";
/*  388 */   private static DebugPlugin fgDebugPlugin = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private BreakpointManager fBreakpointManager;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private ExpressionManager fExpressionManager;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private LaunchManager fLaunchManager;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private MemoryBlockManager fMemoryBlockManager;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  414 */   private ListenerList<IDebugEventSetListener> fEventListeners = new ListenerList();
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  419 */   private ListenerList<IDebugEventFilter> fEventFilters = new ListenerList();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean fShuttingDown = false;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  431 */   private HashMap<StatusHandlerKey, IConfigurationElement> fStatusHandlers = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  438 */   private HashMap<String, IConfigurationElement> fProcessFactories = null;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final int NOTIFY_FILTERS = 0;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final int NOTIFY_EVENTS = 1;
/*      */ 
/*      */ 
/*      */   
/*  452 */   private List<Object> fEventQueue = new ArrayList();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  458 */   private EventDispatchJob fEventDispatchJob = new EventDispatchJob();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   class EventDispatchJob
/*      */     extends Job
/*      */   {
/*  467 */     DebugPlugin.EventNotifier fNotifier = new DebugPlugin.EventNotifier();
/*  468 */     DebugPlugin.AsynchRunner fRunner = new DebugPlugin.AsynchRunner();
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public EventDispatchJob() {
/*  474 */       super(DebugCoreMessages.DebugPlugin_1);
/*  475 */       setPriority(10);
/*  476 */       setSystem(true);
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     protected IStatus run(IProgressMonitor monitor) {
/*  482 */       while (!DebugPlugin.this.fEventQueue.isEmpty()) {
/*  483 */         Object next = null;
/*  484 */         synchronized (DebugPlugin.this.fEventQueue) {
/*  485 */           if (!DebugPlugin.this.fEventQueue.isEmpty()) {
/*  486 */             next = DebugPlugin.this.fEventQueue.remove(0);
/*      */           }
/*      */         } 
/*  489 */         if (next instanceof Runnable) {
/*  490 */           this.fRunner.async((Runnable)next); continue;
/*  491 */         }  if (next != null) {
/*  492 */           this.fNotifier.dispatch((DebugEvent[])next);
/*      */         }
/*      */       } 
/*  495 */       return Status.OK_STATUS;
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean shouldRun() {
/*  500 */       return shouldSchedule();
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean shouldSchedule() {
/*  505 */       return !(DebugPlugin.this.isShuttingDown() || DebugPlugin.this.fEventListeners.isEmpty());
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static DebugPlugin getDefault() {
/*  516 */     return fgDebugPlugin;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static void setDefault(DebugPlugin plugin) {
/*  526 */     fgDebugPlugin = plugin;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String getUniqueIdentifier() {
/*  535 */     return "org.eclipse.debug.core";
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public DebugPlugin() {
/*  548 */     setDefault(this);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void addDebugEventListener(IDebugEventSetListener listener) {
/*  560 */     this.fEventListeners.add(listener);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void fireDebugEventSet(DebugEvent[] events) {
/*  574 */     if (isShuttingDown() || events == null || this.fEventListeners.isEmpty()) {
/*      */       return;
/*      */     }
/*  577 */     synchronized (this.fEventQueue) {
/*  578 */       this.fEventQueue.add(events);
/*      */     } 
/*  580 */     this.fEventDispatchJob.schedule();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void asyncExec(Runnable r) {
/*  593 */     synchronized (this.fEventQueue) {
/*  594 */       this.fEventQueue.add(r);
/*      */     } 
/*  596 */     this.fEventDispatchJob.schedule();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized IBreakpointManager getBreakpointManager() {
/*  606 */     if (this.fBreakpointManager == null) {
/*  607 */       this.fBreakpointManager = new BreakpointManager();
/*      */     }
/*  609 */     return (IBreakpointManager)this.fBreakpointManager;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized ILaunchManager getLaunchManager() {
/*  619 */     if (this.fLaunchManager == null) {
/*  620 */       this.fLaunchManager = new LaunchManager();
/*  621 */       this.fLaunchManager.getAllLaunchConfigurations();
/*      */       
/*  623 */       this.fLaunchManager.addLaunchConfigurationListener((ILaunchConfigurationListener)new GroupMemberChangeListener());
/*      */     } 
/*  625 */     return (ILaunchManager)this.fLaunchManager;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized IMemoryBlockManager getMemoryBlockManager() {
/*  635 */     if (this.fMemoryBlockManager == null) {
/*  636 */       this.fMemoryBlockManager = new MemoryBlockManager();
/*      */     }
/*  638 */     return (IMemoryBlockManager)this.fMemoryBlockManager;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public IStatusHandler getStatusHandler(IStatus status) {
/*  651 */     boolean enabled = Platform.getPreferencesService().getBoolean(getUniqueIdentifier(), IInternalDebugCoreConstants.PREF_ENABLE_STATUS_HANDLERS, true, null);
/*  652 */     if (!enabled) {
/*  653 */       return null;
/*      */     }
/*  655 */     StatusHandlerKey key = new StatusHandlerKey(status.getPlugin(), status.getCode());
/*  656 */     if (this.fStatusHandlers == null) {
/*  657 */       initializeStatusHandlers();
/*      */     }
/*  659 */     IConfigurationElement config = this.fStatusHandlers.get(key);
/*  660 */     if (config != null) {
/*      */       try {
/*  662 */         Object handler = config.createExecutableExtension("class");
/*  663 */         if (handler instanceof IStatusHandler) {
/*  664 */           return (IStatusHandler)handler;
/*      */         }
/*  666 */         invalidStatusHandler((Exception)null, MessageFormat.format("Registered status handler {0} does not implement required interface IStatusHandler.", new Object[] { config.getDeclaringExtension().getUniqueIdentifier() }));
/*  667 */       } catch (CoreException e) {
/*  668 */         log((Throwable)e);
/*      */       } 
/*      */     }
/*  671 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized IExpressionManager getExpressionManager() {
/*  682 */     if (this.fExpressionManager == null) {
/*  683 */       this.fExpressionManager = new ExpressionManager();
/*      */     }
/*  685 */     return (IExpressionManager)this.fExpressionManager;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void removeDebugEventListener(IDebugEventSetListener listener) {
/*  697 */     this.fEventListeners.remove(listener);
/*      */   }
/*      */ 
/*      */   
/*      */   public void stop(BundleContext context) throws Exception {
/*      */     try {
/*  703 */       setShuttingDown(true);
/*      */       
/*  705 */       if (this.fLaunchManager != null) {
/*  706 */         this.fLaunchManager.shutdown();
/*      */       }
/*  708 */       if (this.fBreakpointManager != null) {
/*  709 */         this.fBreakpointManager.shutdown();
/*      */       }
/*  711 */       if (this.fMemoryBlockManager != null) {
/*  712 */         this.fMemoryBlockManager.shutdown();
/*      */       }
/*      */       
/*  715 */       this.fEventListeners.clear();
/*  716 */       this.fEventFilters.clear();
/*      */       
/*  718 */       SourceLookupUtils.shutdown();
/*  719 */       Preferences.savePreferences(getUniqueIdentifier());
/*  720 */       ResourcesPlugin.getWorkspace().removeSaveParticipant(getUniqueIdentifier());
/*      */     } finally {
/*  722 */       super.stop(context);
/*  723 */       setDefault((DebugPlugin)null);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public void start(BundleContext context) throws Exception {
/*  729 */     super.start(context);
/*      */     
/*  731 */     ResourcesPlugin.getWorkspace().addSaveParticipant(getUniqueIdentifier(), 
/*  732 */         new ISaveParticipant()
/*      */         {
/*      */           public void saving(ISaveContext saveContext) throws CoreException {
/*  735 */             if (DebugPlugin.this.fExpressionManager != null) {
/*  736 */               DebugPlugin.this.fExpressionManager.storeWatchExpressions();
/*      */             }
/*  738 */             Preferences.savePreferences(DebugPlugin.getUniqueIdentifier());
/*      */           }
/*      */ 
/*      */           
/*      */           public void rollback(ISaveContext saveContext) {}
/*      */           
/*      */           public void prepareToSave(ISaveContext saveContext) throws CoreException {}
/*      */           
/*      */           public void doneSaving(ISaveContext saveContext) {}
/*      */         });
/*  748 */     IAdapterManager manager = Platform.getAdapterManager();
/*  749 */     CommandAdapterFactory actionFactory = new CommandAdapterFactory();
/*  750 */     manager.registerAdapters((IAdapterFactory)actionFactory, IDisconnect.class);
/*  751 */     manager.registerAdapters((IAdapterFactory)actionFactory, IDropToFrame.class);
/*  752 */     manager.registerAdapters((IAdapterFactory)actionFactory, IStep.class);
/*  753 */     manager.registerAdapters((IAdapterFactory)actionFactory, IStepFilters.class);
/*  754 */     manager.registerAdapters((IAdapterFactory)actionFactory, ISuspendResume.class);
/*  755 */     manager.registerAdapters((IAdapterFactory)actionFactory, ITerminate.class);
/*  756 */     manager.registerAdapters((IAdapterFactory)actionFactory, ILaunch.class);
/*  757 */     manager.registerAdapters((IAdapterFactory)actionFactory, IProcess.class);
/*  758 */     manager.registerAdapters((IAdapterFactory)actionFactory, IDebugElement.class);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static IProcess newProcess(ILaunch launch, Process process, String label) {
/*  779 */     return newProcess(launch, process, label, (Map<String, String>)null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static IProcess newProcess(ILaunch launch, Process process, String label, Map<String, String> attributes) {
/*  804 */     ILaunchConfiguration config = launch.getLaunchConfiguration();
/*  805 */     String processFactoryID = null;
/*  806 */     if (config != null) {
/*      */       try {
/*  808 */         processFactoryID = config.getAttribute("process_factory_id", (String)null);
/*  809 */       } catch (CoreException coreException) {}
/*      */     }
/*      */     
/*  812 */     if (processFactoryID != null) {
/*  813 */       DebugPlugin plugin = getDefault();
/*  814 */       if (plugin.fProcessFactories == null) {
/*  815 */         plugin.initializeProcessFactories();
/*      */       }
/*  817 */       IConfigurationElement element = plugin.fProcessFactories.get(processFactoryID);
/*  818 */       if (element == null) {
/*  819 */         return null;
/*      */       }
/*  821 */       IProcessFactory processFactory = null;
/*      */       try {
/*  823 */         processFactory = (IProcessFactory)element.createExecutableExtension("class");
/*  824 */       } catch (CoreException exception) {
/*  825 */         log((Throwable)exception);
/*  826 */         return null;
/*      */       } 
/*  828 */       return processFactory.newProcess(launch, process, label, attributes);
/*      */     } 
/*  830 */     return (IProcess)new RuntimeProcess(launch, process, label, attributes);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static ILogicalStructureType[] getLogicalStructureTypes(IValue value) {
/*  844 */     return LogicalStructureManager.getDefault().getLogicalStructureTypes(value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static ILogicalStructureType getDefaultStructureType(ILogicalStructureType[] types) {
/*  860 */     return LogicalStructureManager.getDefault().getSelectedStructureType(types);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void setDefaultStructureType(ILogicalStructureType[] types, ILogicalStructureType def) {
/*  876 */     LogicalStructureManager.getDefault().setEnabledType(types, def);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Process exec(String[] cmdLine, File workingDirectory) throws CoreException {
/*  897 */     return exec(cmdLine, workingDirectory, (String[])null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Process exec(String[] cmdLine, File workingDirectory, String[] envp) throws CoreException {
/*  919 */     return exec(cmdLine, workingDirectory, envp, false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Process exec(String[] cmdLine, File workingDirectory, String[] envp, boolean mergeOutput) throws CoreException {
/*  945 */     Process p = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     try {
/*  952 */       if (mergeOutput) {
/*  953 */         ProcessBuilder pb = new ProcessBuilder(cmdLine);
/*  954 */         pb.directory(workingDirectory);
/*  955 */         pb.redirectErrorStream(mergeOutput);
/*  956 */         if (envp != null) {
/*  957 */           Map<String, String> env = pb.environment();
/*  958 */           env.clear(); byte b; int i; String[] arrayOfString;
/*  959 */           for (i = (arrayOfString = envp).length, b = 0; b < i; ) { String e = arrayOfString[b];
/*  960 */             int index = e.indexOf('=');
/*  961 */             if (index != -1)
/*  962 */               env.put(e.substring(0, index), e.substring(index + 1)); 
/*      */             b++; }
/*      */         
/*      */         } 
/*  966 */         p = pb.start();
/*  967 */       } else if (workingDirectory == null) {
/*  968 */         p = Runtime.getRuntime().exec(cmdLine, envp);
/*      */       } else {
/*  970 */         p = Runtime.getRuntime().exec(cmdLine, envp, workingDirectory);
/*      */       } 
/*  972 */     } catch (IOException e) {
/*  973 */       Status status = new Status(4, getUniqueIdentifier(), 125, DebugCoreMessages.DebugPlugin_0, e);
/*  974 */       throw new CoreException(status);
/*  975 */     } catch (NoSuchMethodError e) {
/*      */       
/*  977 */       Status status = new Status(4, getUniqueIdentifier(), 115, DebugCoreMessages.DebugPlugin_Eclipse_runtime_does_not_support_working_directory_2, e);
/*  978 */       IStatusHandler handler = getDefault().getStatusHandler((IStatus)status);
/*      */       
/*  980 */       if (handler != null) {
/*  981 */         Object result = handler.handleStatus((IStatus)status, null);
/*  982 */         if (result instanceof Boolean && ((Boolean)result).booleanValue()) {
/*  983 */           p = exec(cmdLine, (File)null);
/*      */         }
/*      */       } 
/*      */     } 
/*  987 */     return p;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean isShuttingDown() {
/*  998 */     return this.fShuttingDown;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void setShuttingDown(boolean value) {
/* 1009 */     this.fShuttingDown = value;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void addDebugEventFilter(IDebugEventFilter filter) {
/* 1022 */     this.fEventFilters.add(filter);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void removeDebugEventFilter(IDebugEventFilter filter) {
/* 1034 */     this.fEventFilters.remove(filter);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void logDebugMessage(String message) {
/* 1044 */     if (getDefault().isDebugging())
/*      */     {
/*      */       
/* 1047 */       log((IStatus)new Status(4, getUniqueIdentifier(), 125, MessageFormat.format(DebugCoreMessages.DebugPlugin_2, new Object[] { message }), null));
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void logMessage(String message, Throwable throwable) {
/* 1058 */     log((IStatus)new Status(4, getUniqueIdentifier(), 125, message, throwable));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void log(IStatus status) {
/* 1068 */     getDefault().getLog().log(status);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void log(Throwable t) {
/* 1078 */     Status status = new Status(4, getUniqueIdentifier(), 125, DebugCoreMessages.DebugPlugin_3, t);
/* 1079 */     log((IStatus)status);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void initializeStatusHandlers() {
/* 1087 */     IExtensionPoint extensionPoint = Platform.getExtensionRegistry().getExtensionPoint("org.eclipse.debug.core", "statusHandlers");
/* 1088 */     IConfigurationElement[] infos = extensionPoint.getConfigurationElements();
/* 1089 */     this.fStatusHandlers = new HashMap<>(infos.length); byte b; int i; IConfigurationElement[] arrayOfIConfigurationElement1;
/* 1090 */     for (i = (arrayOfIConfigurationElement1 = infos).length, b = 0; b < i; ) { IConfigurationElement configurationElement = arrayOfIConfigurationElement1[b];
/* 1091 */       String id = configurationElement.getAttribute("plugin");
/* 1092 */       String code = configurationElement.getAttribute("code");
/*      */       
/* 1094 */       if (id != null && code != null) {
/*      */         try {
/* 1096 */           StatusHandlerKey key = new StatusHandlerKey(id, Integer.parseInt(code));
/* 1097 */           this.fStatusHandlers.put(key, configurationElement);
/* 1098 */         } catch (NumberFormatException e) {
/*      */           
/* 1100 */           invalidStatusHandler(e, configurationElement.getAttribute("id"));
/*      */         } 
/*      */       } else {
/*      */         
/* 1104 */         invalidStatusHandler((Exception)null, configurationElement.getAttribute("id"));
/*      */       } 
/*      */       b++; }
/*      */   
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void initializeProcessFactories() {
/* 1114 */     IExtensionPoint extensionPoint = Platform.getExtensionRegistry().getExtensionPoint("org.eclipse.debug.core", "processFactories");
/* 1115 */     IConfigurationElement[] infos = extensionPoint.getConfigurationElements();
/* 1116 */     this.fProcessFactories = new HashMap<>(infos.length); byte b; int i; IConfigurationElement[] arrayOfIConfigurationElement1;
/* 1117 */     for (i = (arrayOfIConfigurationElement1 = infos).length, b = 0; b < i; ) { IConfigurationElement configurationElement = arrayOfIConfigurationElement1[b];
/* 1118 */       String id = configurationElement.getAttribute("id");
/* 1119 */       String clss = configurationElement.getAttribute("class");
/* 1120 */       if (id != null && clss != null) {
/* 1121 */         this.fProcessFactories.put(id, configurationElement);
/*      */       } else {
/*      */         
/* 1124 */         String badDefiner = configurationElement.getContributor().getName();
/* 1125 */         log((IStatus)new Status(4, "org.eclipse.debug.core", 125, MessageFormat.format(DebugCoreMessages.DebugPlugin_4, new Object[] {
/* 1126 */                   badDefiner, id }), null));
/*      */       } 
/*      */       b++; }
/*      */   
/*      */   }
/*      */   private void invalidStatusHandler(Exception e, String id) {
/* 1132 */     log((IStatus)new Status(4, "org.eclipse.debug.core", 125, MessageFormat.format(DebugCoreMessages.DebugPlugin_5, new Object[] { id }), e));
/*      */   }
/*      */ 
/*      */   
/*      */   class StatusHandlerKey
/*      */   {
/*      */     String fPluginId;
/*      */     
/*      */     int fCode;
/*      */ 
/*      */     
/*      */     StatusHandlerKey(String pluginId, int code) {
/* 1144 */       this.fPluginId = pluginId;
/* 1145 */       this.fCode = code;
/*      */     }
/*      */ 
/*      */     
/*      */     public int hashCode() {
/* 1150 */       return this.fPluginId.hashCode() + this.fCode;
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean equals(Object obj) {
/* 1155 */       if (obj instanceof StatusHandlerKey) {
/* 1156 */         StatusHandlerKey s = (StatusHandlerKey)obj;
/* 1157 */         return (this.fCode == s.fCode && this.fPluginId.equals(s.fPluginId));
/*      */       } 
/* 1159 */       return false;
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   class AsynchRunner
/*      */     implements ISafeRunnable
/*      */   {
/*      */     private Runnable fRunnable;
/*      */     
/*      */     AsynchRunner() {
/* 1170 */       this.fRunnable = null;
/*      */     }
/*      */     void async(Runnable runnable) {
/* 1173 */       this.fRunnable = runnable;
/* 1174 */       SafeRunner.run(this);
/* 1175 */       this.fRunnable = null;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public void handleException(Throwable exception) {
/* 1181 */       Status status = new Status(4, DebugPlugin.getUniqueIdentifier(), 125, DebugCoreMessages.DebugPlugin_6, exception);
/* 1182 */       DebugPlugin.log((IStatus)status);
/*      */     }
/*      */ 
/*      */     
/*      */     public void run() throws Exception {
/* 1187 */       this.fRunnable.run();
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   class EventNotifier
/*      */     implements ISafeRunnable
/*      */   {
/*      */     private DebugEvent[] fEvents;
/*      */     
/*      */     private IDebugEventSetListener fListener;
/*      */     
/*      */     private IDebugEventFilter fFilter;
/*      */     private int fMode;
/*      */     
/*      */     public void handleException(Throwable exception) {
/*      */       Status status2;
/*      */       Status status1;
/* 1205 */       switch (this.fMode) {
/*      */         case 0:
/* 1207 */           status2 = new Status(4, DebugPlugin.getUniqueIdentifier(), 125, DebugCoreMessages.DebugPlugin_7, exception);
/* 1208 */           DebugPlugin.log((IStatus)status2);
/*      */           break;
/*      */         case 1:
/* 1211 */           status1 = new Status(4, DebugPlugin.getUniqueIdentifier(), 125, DebugCoreMessages.DebugPlugin_8, exception);
/* 1212 */           DebugPlugin.log((IStatus)status1);
/*      */           break;
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void run() throws Exception {
/* 1221 */       switch (this.fMode) {
/*      */         case 0:
/* 1223 */           this.fEvents = this.fFilter.filterDebugEvents(this.fEvents);
/*      */           break;
/*      */         case 1:
/* 1226 */           this.fListener.handleDebugEvents(this.fEvents);
/*      */           break;
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     void dispatch(DebugEvent[] events) {
/* 1240 */       this.fEvents = events;
/* 1241 */       if (!DebugPlugin.this.fEventFilters.isEmpty()) {
/* 1242 */         this.fMode = 0;
/* 1243 */         for (IDebugEventFilter iDebugEventFilter : DebugPlugin.this.fEventFilters) {
/* 1244 */           this.fFilter = iDebugEventFilter;
/* 1245 */           SafeRunner.run(this);
/* 1246 */           if (this.fEvents == null || this.fEvents.length == 0) {
/*      */             return;
/*      */           }
/*      */         } 
/*      */       } 
/*      */       
/* 1252 */       this.fMode = 1;
/* 1253 */       if (DebugOptions.DEBUG_EVENTS) {
/* 1254 */         byte b; int i; DebugEvent[] arrayOfDebugEvent; for (i = (arrayOfDebugEvent = this.fEvents).length, b = 0; b < i; ) { DebugEvent event = arrayOfDebugEvent[b];
/* 1255 */           DebugOptions.trace(event.toString()); b++; }
/*      */       
/*      */       } 
/* 1258 */       for (IDebugEventSetListener iDebugEventSetListener : DebugPlugin.this.fEventListeners) {
/* 1259 */         this.fListener = iDebugEventSetListener;
/* 1260 */         SafeRunner.run(this);
/*      */       } 
/* 1262 */       this.fEvents = null;
/* 1263 */       this.fFilter = null;
/* 1264 */       this.fListener = null;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Document newDocument() throws CoreException {
/*      */     try {
/* 1278 */       return LaunchManager.getDocument();
/* 1279 */     } catch (ParserConfigurationException e) {
/* 1280 */       abort("Unable to create new XML document.", e);
/*      */       
/* 1282 */       return null;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String serializeDocument(Document document) throws CoreException {
/*      */     try {
/* 1295 */       return LaunchManager.serializeDocument(document);
/* 1296 */     } catch (TransformerException e) {
/* 1297 */       abort("Unable to serialize XML document.", e);
/* 1298 */     } catch (IOException e) {
/* 1299 */       abort("Unable to serialize XML document.", e);
/*      */     } 
/* 1301 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Element parseDocument(String document) throws CoreException {
/* 1314 */     Element root = null;
/* 1315 */     InputStream stream = null;
/*      */     try {
/* 1317 */       DocumentBuilder parser = DocumentBuilderFactory.newInstance().newDocumentBuilder();
/* 1318 */       parser.setErrorHandler(new DefaultHandler());
/* 1319 */       stream = new ByteArrayInputStream(document.getBytes(StandardCharsets.UTF_8));
/* 1320 */       root = parser.parse(stream).getDocumentElement();
/* 1321 */     } catch (ParserConfigurationException e) {
/* 1322 */       abort("Unable to parse XML document.", e);
/* 1323 */     } catch (FactoryConfigurationError e) {
/* 1324 */       abort("Unable to parse XML document.", e);
/* 1325 */     } catch (SAXException e) {
/* 1326 */       abort("Unable to parse XML document.", e);
/* 1327 */     } catch (IOException e) {
/* 1328 */       abort("Unable to parse XML document.", e);
/*      */     } finally {
/*      */       try {
/* 1331 */         if (stream != null) {
/* 1332 */           stream.close();
/*      */         }
/* 1334 */       } catch (IOException e) {
/* 1335 */         abort("Unable to parse XML document.", e);
/*      */       } 
/*      */     } 
/* 1338 */     return root;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static void abort(String message, Throwable exception) throws CoreException {
/* 1349 */     Status status = new Status(4, getUniqueIdentifier(), 125, message, exception);
/* 1350 */     throw new CoreException(status);
/*      */   }
/*      */ 
/*      */   
/*      */   private static String[] parseArgumentsWindows(String args, boolean split) {
/* 1355 */     List<String> result = new ArrayList<>();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1361 */     int state = 0;
/* 1362 */     int backslashes = 0;
/* 1363 */     StringBuilder buf = new StringBuilder();
/* 1364 */     int len = args.length();
/* 1365 */     for (int i = 0; i < len; i++) {
/* 1366 */       char ch = args.charAt(i);
/* 1367 */       if (ch == '\\') {
/* 1368 */         backslashes++; continue;
/*      */       } 
/* 1370 */       if (backslashes != 0) {
/* 1371 */         if (ch == '"') {
/* 1372 */           for (; backslashes >= 2; backslashes -= 2) {
/* 1373 */             buf.append('\\');
/* 1374 */             if (split) {
/* 1375 */               buf.append('\\');
/*      */             }
/*      */           } 
/* 1378 */           if (backslashes == 1) {
/* 1379 */             if (state == 0) {
/* 1380 */               state = 1;
/*      */             }
/* 1382 */             if (split) {
/* 1383 */               buf.append('\\');
/*      */             }
/* 1385 */             buf.append('"');
/* 1386 */             backslashes = 0;
/*      */             
/*      */             continue;
/*      */           } 
/*      */         } else {
/* 1391 */           if (state == 0) {
/* 1392 */             state = 1;
/*      */           }
/* 1394 */           for (; backslashes > 0; backslashes--) {
/* 1395 */             buf.append('\\');
/*      */           }
/*      */         } 
/*      */       }
/*      */       
/* 1400 */       if (Character.isWhitespace(ch)) {
/* 1401 */         if (state == 0) {
/*      */           continue;
/*      */         }
/* 1404 */         if (state == 1) {
/* 1405 */           state = 0;
/* 1406 */           result.add(buf.toString());
/* 1407 */           buf.setLength(0);
/*      */           continue;
/*      */         } 
/*      */       } 
/* 1411 */       switch (state) {
/*      */         case 0:
/*      */         case 1:
/* 1414 */           if (ch == '"') {
/* 1415 */             state = 2;
/* 1416 */             if (split)
/* 1417 */               buf.append(ch); 
/*      */             break;
/*      */           } 
/* 1420 */           state = 1;
/* 1421 */           buf.append(ch);
/*      */           break;
/*      */ 
/*      */         
/*      */         case 2:
/* 1426 */           if (ch == '"') {
/* 1427 */             if (i + 1 < len && args.charAt(i + 1) == '"') {
/*      */ 
/*      */ 
/*      */ 
/*      */               
/* 1432 */               buf.append('"');
/* 1433 */               i++;
/* 1434 */               if (split)
/* 1435 */                 buf.append(ch);  break;
/*      */             } 
/* 1437 */             if (buf.length() == 0) {
/*      */               
/* 1439 */               result.add("\"\"");
/* 1440 */               state = 0; break;
/*      */             } 
/* 1442 */             state = 1;
/* 1443 */             if (split) {
/* 1444 */               buf.append(ch);
/*      */             }
/*      */             break;
/*      */           } 
/* 1448 */           buf.append(ch);
/*      */           break;
/*      */ 
/*      */         
/*      */         default:
/* 1453 */           throw new IllegalStateException();
/*      */       }  continue;
/*      */     } 
/* 1456 */     if (buf.length() > 0 || state != 0) {
/* 1457 */       result.add(buf.toString());
/*      */     }
/*      */     
/* 1460 */     return result.<String>toArray(new String[result.size()]);
/*      */   }
/*      */ 
/*      */   
/*      */   private static String[] parseArgumentsImpl(String args, boolean split) {
/* 1465 */     List<String> result = new ArrayList<>();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1472 */     int state = 0;
/* 1473 */     StringBuilder buf = new StringBuilder();
/* 1474 */     int len = args.length();
/* 1475 */     for (int i = 0; i < len; i++) {
/* 1476 */       char ch = args.charAt(i);
/* 1477 */       if (Character.isWhitespace(ch)) {
/* 1478 */         if (state == 0) {
/*      */           continue;
/*      */         }
/* 1481 */         if (state == 1) {
/* 1482 */           state = 0;
/* 1483 */           result.add(buf.toString());
/* 1484 */           buf.setLength(0);
/*      */           continue;
/*      */         } 
/*      */       } 
/* 1488 */       switch (state) {
/*      */         case 0:
/*      */         case 1:
/* 1491 */           if (ch == '"') {
/* 1492 */             if (split) {
/* 1493 */               buf.append(ch);
/*      */             }
/* 1495 */             state = 2; break;
/* 1496 */           }  if (ch == '\'') {
/* 1497 */             if (split) {
/* 1498 */               buf.append(ch);
/*      */             }
/* 1500 */             state = 3; break;
/* 1501 */           }  if (ch == '\\' && i + 1 < len) {
/* 1502 */             if (split) {
/* 1503 */               buf.append(ch);
/*      */             }
/* 1505 */             state = 1;
/* 1506 */             ch = args.charAt(++i);
/* 1507 */             buf.append(ch); break;
/*      */           } 
/* 1509 */           state = 1;
/* 1510 */           buf.append(ch);
/*      */           break;
/*      */ 
/*      */         
/*      */         case 2:
/* 1515 */           if (ch == '"') {
/* 1516 */             if (split) {
/* 1517 */               buf.append(ch);
/*      */             }
/* 1519 */             state = 1; break;
/* 1520 */           }  if (ch == '\\' && i + 1 < len && (
/* 1521 */             args.charAt(i + 1) == '\\' || args.charAt(i + 1) == '"')) {
/* 1522 */             if (split) {
/* 1523 */               buf.append(ch);
/*      */             }
/* 1525 */             ch = args.charAt(++i);
/* 1526 */             buf.append(ch); break;
/*      */           } 
/* 1528 */           buf.append(ch);
/*      */           break;
/*      */ 
/*      */         
/*      */         case 3:
/* 1533 */           if (ch == '\'') {
/* 1534 */             if (split) {
/* 1535 */               buf.append(ch);
/*      */             }
/* 1537 */             state = 1; break;
/*      */           } 
/* 1539 */           buf.append(ch);
/*      */           break;
/*      */ 
/*      */         
/*      */         default:
/* 1544 */           throw new IllegalStateException();
/*      */       }  continue;
/*      */     } 
/* 1547 */     if (buf.length() > 0 || state != 0) {
/* 1548 */       result.add(buf.toString());
/*      */     }
/*      */     
/* 1551 */     return result.<String>toArray(new String[result.size()]);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String[] parseArguments(String args) {
/* 1569 */     if (args == null) {
/* 1570 */       return new String[0];
/*      */     }
/*      */     
/* 1573 */     if ("win32".equals(Platform.getOS())) {
/* 1574 */       return parseArgumentsWindows(args, false);
/*      */     }
/*      */     
/* 1577 */     return parseArgumentsImpl(args, false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String[] splitArguments(String args) {
/* 1595 */     if (args == null) {
/* 1596 */       return new String[0];
/*      */     }
/*      */     
/* 1599 */     if ("win32".equals(Platform.getOS())) {
/* 1600 */       return parseArgumentsWindows(args, true);
/*      */     }
/*      */     
/* 1603 */     return parseArgumentsImpl(args, true);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String renderArguments(String[] arguments, int[] segments) {
/* 1626 */     boolean isWin32 = Platform.getOS().equals("win32");
/* 1627 */     StringBuilder buf = new StringBuilder();
/* 1628 */     int count = arguments.length;
/* 1629 */     for (int i = 0; i < count; i++) {
/* 1630 */       if (i > 0) {
/* 1631 */         buf.append(' ');
/*      */       }
/*      */       
/* 1634 */       boolean containsSpace = false;
/* 1635 */       char[] characters = arguments[i].toCharArray(); byte b; int k; char[] arrayOfChar1;
/* 1636 */       for (k = (arrayOfChar1 = characters).length, b = 0; b < k; ) { char ch = arrayOfChar1[b];
/* 1637 */         if (ch == ' ' || ch == '\t') {
/* 1638 */           containsSpace = true;
/* 1639 */           buf.append('"');
/*      */           break;
/*      */         } 
/*      */         b++; }
/*      */       
/* 1644 */       int backslashes = 0;
/* 1645 */       for (int j = 0; j < characters.length; j++) {
/* 1646 */         char ch = characters[j];
/* 1647 */         if (ch == '"') {
/* 1648 */           if (isWin32) {
/* 1649 */             if (j == 0 && characters.length == 2 && characters[1] == '"') {
/*      */               
/* 1651 */               buf.append("\"\"");
/*      */               break;
/*      */             } 
/* 1654 */             if (backslashes > 0)
/*      */             {
/* 1656 */               for (; backslashes > 0; backslashes--) {
/* 1657 */                 buf.append('\\');
/*      */               }
/*      */             }
/*      */           } 
/* 1661 */           buf.append('\\');
/* 1662 */         } else if (ch == '\\') {
/* 1663 */           if (isWin32) {
/* 1664 */             backslashes++;
/*      */           } else {
/* 1666 */             buf.append('\\');
/*      */           } 
/* 1668 */         } else if (isWin32) {
/* 1669 */           backslashes = 0;
/*      */         } 
/* 1671 */         buf.append(ch);
/*      */       } 
/* 1673 */       if (containsSpace) {
/* 1674 */         buf.append('"');
/* 1675 */       } else if (characters.length == 0) {
/* 1676 */         buf.append("\"\"");
/*      */       } 
/*      */       
/* 1679 */       if (segments != null && i < count - 1) {
/* 1680 */         segments[i] = buf.length() + 1;
/*      */       }
/*      */     } 
/* 1683 */     return buf.toString();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void setUseStepFilters(boolean useStepFilters) {
/* 1696 */     getStepFilterManager().setUseStepFilters(useStepFilters);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isUseStepFilters() {
/* 1708 */     return getStepFilterManager().isUseStepFilters();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static IStepFilter[] getStepFilters(String modelIdentifier) {
/* 1722 */     return getStepFilterManager().getStepFilters(modelIdentifier);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static StepFilterManager getStepFilterManager() {
/* 1731 */     return ((LaunchManager)getDefault().getLaunchManager()).getStepFilterManager();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Object getAdapter(Object element, Class<?> type) {
/* 1747 */     Object adapter = null;
/* 1748 */     if (element != null) {
/* 1749 */       if (type.isInstance(element)) {
/* 1750 */         return element;
/*      */       }
/* 1752 */       if (element instanceof IAdaptable) {
/* 1753 */         adapter = ((IAdaptable)element).getAdapter(type);
/*      */       }
/*      */       
/* 1756 */       if (adapter == null && !(element instanceof org.eclipse.core.runtime.PlatformObject)) {
/* 1757 */         adapter = Platform.getAdapterManager().getAdapter(element, type);
/*      */       }
/*      */       
/* 1760 */       if (adapter == null) {
/* 1761 */         adapter = Platform.getAdapterManager().loadAdapter(element, type.getName());
/*      */       }
/*      */     } 
/*      */     
/* 1765 */     return adapter;
/*      */   }
/*      */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.debug.core-3.21.0.jar!\org\eclipse\debug\core\DebugPlugin.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */