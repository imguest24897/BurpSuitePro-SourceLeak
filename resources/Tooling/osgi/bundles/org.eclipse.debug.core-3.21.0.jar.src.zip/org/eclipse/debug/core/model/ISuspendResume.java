package org.eclipse.debug.core.model;

import org.eclipse.debug.core.DebugException;

public interface ISuspendResume {
  boolean canResume();
  
  boolean canSuspend();
  
  boolean isSuspended();
  
  void resume() throws DebugException;
  
  void suspend() throws DebugException;
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.debug.core-3.21.0.jar!\org\eclipse\debug\core\model\ISuspendResume.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */