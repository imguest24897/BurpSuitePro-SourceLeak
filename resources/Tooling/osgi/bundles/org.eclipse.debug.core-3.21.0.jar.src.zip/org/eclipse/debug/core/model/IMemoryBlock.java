package org.eclipse.debug.core.model;

import org.eclipse.debug.core.DebugException;

public interface IMemoryBlock extends IDebugElement {
  long getStartAddress();
  
  long getLength();
  
  byte[] getBytes() throws DebugException;
  
  boolean supportsValueModification();
  
  void setValue(long paramLong, byte[] paramArrayOfbyte) throws DebugException;
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.debug.core-3.21.0.jar!\org\eclipse\debug\core\model\IMemoryBlock.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */