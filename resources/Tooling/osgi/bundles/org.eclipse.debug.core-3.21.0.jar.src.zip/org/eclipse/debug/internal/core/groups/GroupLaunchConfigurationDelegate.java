/*     */ package org.eclipse.debug.internal.core.groups;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.concurrent.Callable;
/*     */ import java.util.concurrent.CountDownLatch;
/*     */ import java.util.concurrent.ExecutorService;
/*     */ import java.util.concurrent.Executors;
/*     */ import java.util.concurrent.Future;
/*     */ import org.eclipse.core.resources.IProject;
/*     */ import org.eclipse.core.runtime.CoreException;
/*     */ import org.eclipse.core.runtime.IProgressMonitor;
/*     */ import org.eclipse.core.runtime.IStatus;
/*     */ import org.eclipse.core.runtime.Status;
/*     */ import org.eclipse.core.runtime.SubMonitor;
/*     */ import org.eclipse.debug.core.DebugPlugin;
/*     */ import org.eclipse.debug.core.ILaunch;
/*     */ import org.eclipse.debug.core.ILaunchConfiguration;
/*     */ import org.eclipse.debug.core.ILaunchConfigurationWorkingCopy;
/*     */ import org.eclipse.debug.core.ILaunchManager;
/*     */ import org.eclipse.debug.core.IStatusHandler;
/*     */ import org.eclipse.debug.core.model.ILaunchConfigurationDelegate2;
/*     */ import org.eclipse.debug.core.model.IProcess;
/*     */ import org.eclipse.debug.core.model.LaunchConfigurationDelegate;
/*     */ import org.eclipse.debug.internal.core.DebugCoreMessages;
/*     */ import org.eclipse.debug.internal.core.groups.observer.ProcessObserver;
/*     */ import org.eclipse.debug.internal.core.groups.observer.StreamObserver;
/*     */ import org.eclipse.osgi.util.NLS;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class GroupLaunchConfigurationDelegate
/*     */   extends LaunchConfigurationDelegate
/*     */   implements ILaunchConfigurationDelegate2
/*     */ {
/*     */   public static final int CODE_GROUP_LAUNCH_START = 233;
/*     */   public static final int CODE_GROUP_LAUNCH_DONE = 234;
/*     */   private static final int CODE_BUILD_BEFORE_LAUNCH = 206;
/*     */   private static final String NAME_PROP = "name";
/*     */   private static final String ENABLED_PROP = "enabled";
/*     */   private static final String ADOPT_PROP = "adoptIfRunning";
/*     */   private static final String MODE_PROP = "mode";
/*     */   private static final String ACTION_PROP = "action";
/*     */   private static final String ACTION_PARAM_PROP = "actionParam";
/*     */   private static final String MULTI_LAUNCH_CONSTANTS_PREFIX = "org.eclipse.debug.core.launchGroup";
/*     */   private static final String DEBUG_CORE = "org.eclipse.debug.core";
/*  73 */   private static final Status UNSUPPORTED_MODE = new Status(4, "org.eclipse.debug.core", 230, "", null);
/*  74 */   private static final Status GROUP_ELEMENT_STARTED = new Status(0, "org.eclipse.debug.core", 231, "", null);
/*  75 */   private static final Status GROUP_CYCLE = new Status(4, "org.eclipse.debug.core", 232, "", null);
/*     */   
/*  77 */   private static final Status GROUP_LAUNCH_START = new Status(1, "org.eclipse.debug.core", 233, "", null);
/*  78 */   private static final Status GROUP_LAUNCH_DONE = new Status(1, "org.eclipse.debug.core", 234, "", null);
/*     */   
/*  80 */   private static final Status BUILD_BEFORE_LAUNCH = new Status(1, "org.eclipse.debug.core", 206, "", null);
/*     */ 
/*     */   
/*     */   public ILaunch getLaunch(ILaunchConfiguration configuration, String mode) throws CoreException {
/*  84 */     return (ILaunch)new GroupLaunch(configuration, mode);
/*     */   }
/*     */ 
/*     */   
/*     */   public void launch(ILaunchConfiguration groupConfig, String mode, ILaunch groupLaunch, IProgressMonitor monitor) throws CoreException {
/*  89 */     GroupLaunch group = (GroupLaunch)groupLaunch;
/*     */     
/*  91 */     IStatusHandler groupStateHandler = DebugPlugin.getDefault().getStatusHandler((IStatus)GROUP_LAUNCH_START);
/*  92 */     groupStateHandler.handleStatus((IStatus)GROUP_LAUNCH_START, group);
/*     */     
/*     */     try {
/*  95 */       SubMonitor progress = SubMonitor.convert(monitor, NLS.bind(DebugCoreMessages.GroupLaunchConfigurationDelegate_Launching, groupConfig.getName()), 1000);
/*     */       
/*  97 */       List<GroupLaunchElement> launches = createLaunchElements(groupConfig);
/*  98 */       for (int i = 0; i < launches.size(); i++) {
/*  99 */         GroupLaunchElement le = launches.get(i);
/*     */         
/* 101 */         if (le.enabled) {
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 106 */           ILaunchConfiguration conf = findLaunchConfiguration(le.name);
/* 107 */           if (conf != null) {
/*     */             String localMode;
/*     */ 
/*     */ 
/*     */ 
/*     */             
/* 113 */             if (!le.mode.equals("inherit")) {
/* 114 */               localMode = le.mode;
/*     */             } else {
/* 116 */               localMode = mode;
/*     */             } 
/* 118 */             if (!conf.supportsMode(localMode)) {
/* 119 */               IStatusHandler handler = DebugPlugin.getDefault().getStatusHandler((IStatus)UNSUPPORTED_MODE);
/* 120 */               handler.handleStatus((IStatus)UNSUPPORTED_MODE, new String[] {
/* 121 */                     conf.getName(), localMode
/*     */                   });
/*     */             } else {
/*     */               
/* 125 */               if (groupConfig.getName().equals(conf.getName())) {
/*     */                 
/* 127 */                 IStatusHandler cycleHandler = DebugPlugin.getDefault().getStatusHandler((IStatus)GROUP_CYCLE);
/* 128 */                 cycleHandler.handleStatus((IStatus)GROUP_CYCLE, conf.getName());
/* 129 */               } else if (!launchChild(progress.newChild(1000 / launches.size()), group, le, conf, localMode, (i == launches.size() - 1))) {
/*     */                 break;
/*     */               } 
/*     */ 
/*     */ 
/*     */               
/* 135 */               if (group.isTerminated())
/*     */                 break; 
/*     */             } 
/*     */           } 
/*     */         } 
/*     */       } 
/* 141 */       if (!group.hasChildren()) {
/* 142 */         DebugPlugin.getDefault().getLaunchManager().removeLaunch((ILaunch)group);
/*     */       }
/*     */     } finally {
/*     */       
/* 146 */       group.markLaunched();
/* 147 */       groupStateHandler.handleStatus((IStatus)GROUP_LAUNCH_DONE, group);
/* 148 */       monitor.done();
/*     */     } 
/*     */   }
/*     */   
/*     */   private boolean launchChild(SubMonitor monitor, GroupLaunch group, GroupLaunchElement le, ILaunchConfiguration child, String localMode, boolean lastConfig) throws CoreException {
/* 153 */     Set<ILaunch> running = le.adoptIfRunning ? findRunningLaunch(le.name) : Collections.<ILaunch>emptySet();
/* 154 */     ILaunch subLaunch = running.stream().findFirst().orElse(null);
/* 155 */     boolean launched = false;
/* 156 */     if (subLaunch == null) {
/* 157 */       boolean build = true;
/* 158 */       IStatusHandler buildHandler = DebugPlugin.getDefault().getStatusHandler((IStatus)BUILD_BEFORE_LAUNCH);
/*     */       try {
/* 160 */         Object resolution = buildHandler.handleStatus((IStatus)BUILD_BEFORE_LAUNCH, child);
/* 161 */         if (resolution instanceof Boolean) {
/* 162 */           build = ((Boolean)resolution).booleanValue();
/*     */         }
/* 164 */       } catch (Exception exception) {}
/*     */ 
/*     */       
/* 167 */       subLaunch = child.launch(localMode, (IProgressMonitor)monitor, build);
/* 168 */       launched = true;
/*     */     } 
/*     */     
/* 171 */     group.addSubLaunch(subLaunch);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 177 */     group.launchChanged(subLaunch);
/*     */     
/* 179 */     if (launched) {
/*     */ 
/*     */       
/* 182 */       IStatusHandler postLaunchHandler = DebugPlugin.getDefault().getStatusHandler((IStatus)GROUP_ELEMENT_STARTED);
/* 183 */       postLaunchHandler.handleStatus((IStatus)GROUP_ELEMENT_STARTED, new ILaunch[] {
/* 184 */             (ILaunch)group, subLaunch
/*     */           });
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 190 */     if (lastConfig) {
/* 191 */       group.markLaunched();
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 196 */     if (launched) {
/* 197 */       return postLaunchAction(subLaunch, le, (IProgressMonitor)monitor);
/*     */     }
/* 199 */     return true;
/*     */   }
/*     */   private boolean postLaunchAction(ILaunch subLaunch, GroupLaunchElement le, IProgressMonitor monitor) {
/*     */     Integer waitSecs;
/*     */     String regexp;
/* 204 */     switch (le.action)
/*     */     { case NONE:
/* 206 */         return true;
/*     */       case WAIT_FOR_TERMINATION:
/* 208 */         monitor.subTask(NLS.bind(DebugCoreMessages.GroupLaunchConfigurationDelegate_Waiting_for_termination, subLaunch.getLaunchConfiguration().getName()));
/* 209 */         while (!subLaunch.isTerminated() && !monitor.isCanceled()) {
/*     */           try {
/* 211 */             Thread.sleep(1000L);
/* 212 */           } catch (InterruptedException interruptedException) {
/*     */             break;
/*     */           } 
/*     */         } 
/* 216 */         monitor.subTask("");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 245 */         return true;case null: waitSecs = (Integer)le.actionParam; if (waitSecs != null) { monitor.subTask(NLS.bind(DebugCoreMessages.GroupLaunchConfigurationDelegate_Delaying, waitSecs.toString())); try { Thread.sleep((waitSecs.intValue() * 1000)); } catch (InterruptedException interruptedException) {} }  return true;case OUTPUT_REGEXP: regexp = (String)le.actionParam; if (regexp != null) { monitor.subTask(NLS.bind(DebugCoreMessages.GroupLaunchConfigurationDelegate_waiting, regexp, subLaunch.getLaunchConfiguration().getName())); if (!waitForOutputMatching(subLaunch, monitor, regexp)) return false;  }  return true; }  assert false : "new post launch action type is missing logic"; return true;
/*     */   }
/*     */ 
/*     */   
/*     */   private boolean waitForOutputMatching(ILaunch launch, IProgressMonitor m, String regexp) {
/* 250 */     int processCount = (launch.getProcesses()).length;
/* 251 */     ExecutorService executor = Executors.newCachedThreadPool();
/* 252 */     CountDownLatch countDownLatch = new CountDownLatch(processCount);
/* 253 */     Future<Integer> process = null; byte b; int i; IProcess[] arrayOfIProcess;
/* 254 */     for (i = (arrayOfIProcess = launch.getProcesses()).length, b = 0; b < i; ) { IProcess p = arrayOfIProcess[b];
/* 255 */       process = executor.submit((Callable<Integer>)new ProcessObserver(m, p, countDownLatch));
/* 256 */       executor.submit((Runnable)new StreamObserver(m, p, regexp, countDownLatch)); b++; }
/*     */     
/*     */     try {
/* 259 */       countDownLatch.await();
/* 260 */     } catch (InterruptedException interruptedException) {}
/*     */ 
/*     */     
/* 263 */     executor.shutdown();
/*     */     
/* 265 */     if (process == null || process.isDone()) {
/* 266 */       return false;
/*     */     }
/*     */     
/* 269 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void buildProjects(IProject[] projects, IProgressMonitor monitor) throws CoreException {}
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean buildForLaunch(ILaunchConfiguration configuration, String mode, IProgressMonitor monitor) throws CoreException {
/* 280 */     return false;
/*     */   }
/*     */   
/*     */   protected static ILaunchConfiguration findLaunchConfiguration(String name) throws CoreException {
/* 284 */     ILaunchManager launchManager = DebugPlugin.getDefault().getLaunchManager();
/* 285 */     ILaunchConfiguration[] launchConfigurations = launchManager.getLaunchConfigurations(); byte b; int i; ILaunchConfiguration[] arrayOfILaunchConfiguration1;
/* 286 */     for (i = (arrayOfILaunchConfiguration1 = launchConfigurations).length, b = 0; b < i; ) { ILaunchConfiguration config = arrayOfILaunchConfiguration1[b];
/* 287 */       if (config.getName().equals(name))
/* 288 */         return config; 
/*     */       b++; }
/*     */     
/* 291 */     return null;
/*     */   }
/*     */   
/*     */   protected static Set<ILaunch> findRunningLaunch(String name) {
/* 295 */     Set<ILaunch> result = new HashSet<>();
/* 296 */     ILaunchManager launchManager = DebugPlugin.getDefault().getLaunchManager(); byte b; int i; ILaunch[] arrayOfILaunch;
/* 297 */     for (i = (arrayOfILaunch = launchManager.getLaunches()).length, b = 0; b < i; ) { ILaunch l = arrayOfILaunch[b];
/* 298 */       if (!l.isTerminated())
/*     */       {
/*     */         
/* 301 */         if (l.getLaunchConfiguration().getName().equals(name))
/* 302 */           result.add(l);  } 
/*     */       b++; }
/*     */     
/* 305 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static List<GroupLaunchElement> createLaunchElements(ILaunchConfiguration configuration) {
/* 319 */     List<GroupLaunchElement> result = new ArrayList<>();
/*     */     try {
/* 321 */       Map<String, Object> attrs = configuration.getAttributes();
/* 322 */       for (Map.Entry<String, Object> entry : attrs.entrySet()) {
/* 323 */         String attr = entry.getKey();
/*     */         try {
/* 325 */           if (attr.startsWith("org.eclipse.debug.core.launchGroup")) {
/* 326 */             String prop = attr.substring("org.eclipse.debug.core.launchGroup".length() + 1);
/* 327 */             int k = prop.indexOf('.');
/* 328 */             String num = prop.substring(0, k);
/* 329 */             int index = Integer.parseInt(num);
/* 330 */             String name = prop.substring(k + 1);
/* 331 */             if (name.equals("name")) {
/* 332 */               GroupLaunchElement.GroupElementPostLaunchAction action; GroupLaunchElement el = new GroupLaunchElement();
/* 333 */               el.index = index;
/* 334 */               el.name = (String)entry.getValue();
/*     */               
/* 336 */               Object actionParam = null;
/* 337 */               String actionStr = (String)attrs.get(getProp(index, "action"));
/*     */ 
/*     */               
/*     */               try {
/* 341 */                 action = GroupLaunchElement.GroupElementPostLaunchAction.valueOf(actionStr);
/* 342 */               } catch (Exception exception) {
/* 343 */                 action = GroupLaunchElement.GroupElementPostLaunchAction.NONE;
/*     */               } 
/* 345 */               if (action == GroupLaunchElement.GroupElementPostLaunchAction.DELAY) {
/*     */                 try {
/* 347 */                   actionParam = Integer.valueOf(Integer.parseInt((String)attrs.get(getProp(index, "actionParam"))));
/* 348 */                 } catch (NumberFormatException exc) {
/* 349 */                   DebugPlugin.log(exc);
/*     */                 } 
/*     */               }
/* 352 */               if (action == GroupLaunchElement.GroupElementPostLaunchAction.OUTPUT_REGEXP) {
/* 353 */                 actionParam = attrs.get(getProp(index, "actionParam"));
/*     */               }
/* 355 */               el.action = action;
/* 356 */               el.actionParam = actionParam;
/* 357 */               if (attrs.containsKey(getProp(index, "adoptIfRunning"))) {
/* 358 */                 el.adoptIfRunning = ((Boolean)attrs.get(getProp(index, "adoptIfRunning"))).booleanValue();
/*     */               }
/* 360 */               el.mode = (String)attrs.get(getProp(index, "mode"));
/* 361 */               el.enabled = ((Boolean)attrs.get(getProp(index, "enabled"))).booleanValue();
/*     */               try {
/* 363 */                 el.data = findLaunchConfiguration(el.name);
/* 364 */               } catch (Exception exception) {
/* 365 */                 el.data = null;
/*     */               } 
/* 367 */               while (index >= result.size()) {
/* 368 */                 result.add(null);
/*     */               }
/* 370 */               result.set(index, el);
/*     */             }
/*     */           
/*     */           } 
/* 374 */         } catch (Exception e) {
/* 375 */           DebugPlugin.log(e);
/*     */         } 
/*     */       } 
/* 378 */     } catch (CoreException e) {
/* 379 */       DebugPlugin.log((Throwable)e);
/*     */     } 
/* 381 */     return result;
/*     */   }
/*     */   
/*     */   public static void storeLaunchElements(ILaunchConfigurationWorkingCopy configuration, List<GroupLaunchElement> input) {
/* 385 */     int i = 0;
/* 386 */     removeLaunchElements(configuration);
/* 387 */     for (GroupLaunchElement el : input) {
/* 388 */       if (el == null) {
/*     */         continue;
/*     */       }
/* 391 */       configuration.setAttribute(getProp(i, "name"), el.name);
/* 392 */       configuration.setAttribute(getProp(i, "action"), el.action.toString());
/* 393 */       configuration.setAttribute(getProp(i, "adoptIfRunning"), el.adoptIfRunning);
/*     */ 
/*     */ 
/*     */       
/* 397 */       configuration.setAttribute(getProp(i, "actionParam"), (el.actionParam != null) ? el.actionParam.toString() : null);
/* 398 */       configuration.setAttribute(getProp(i, "mode"), el.mode);
/* 399 */       configuration.setAttribute(getProp(i, "enabled"), el.enabled);
/* 400 */       i++;
/*     */     } 
/*     */   }
/*     */   
/*     */   public static void removeLaunchElements(ILaunchConfigurationWorkingCopy configuration) {
/*     */     try {
/* 406 */       for (String attr : configuration.getAttributes().keySet()) {
/*     */         try {
/* 408 */           if (attr.startsWith("org.eclipse.debug.core.launchGroup")) {
/* 409 */             configuration.removeAttribute(attr);
/*     */           }
/* 411 */         } catch (Exception e) {
/* 412 */           DebugPlugin.log(e);
/*     */         } 
/*     */       } 
/* 415 */     } catch (CoreException e) {
/* 416 */       DebugPlugin.log((Throwable)e);
/*     */     } 
/*     */   }
/*     */   
/*     */   public static String getProp(int index, String string) {
/* 421 */     return "org.eclipse.debug.core.launchGroup." + index + "." + string;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.debug.core-3.21.0.jar!\org\eclipse\debug\internal\core\groups\GroupLaunchConfigurationDelegate.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */