/*    */ package org.eclipse.debug.core.model;
/*    */ 
/*    */ import org.eclipse.core.runtime.IAdaptable;
/*    */ import org.eclipse.debug.core.DebugException;
/*    */ import org.eclipse.debug.core.DebugPlugin;
/*    */ import org.eclipse.debug.core.ILaunch;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface IProcess
/*    */   extends IAdaptable, ITerminate
/*    */ {
/* 43 */   public static final String ATTR_CMDLINE = String.valueOf(DebugPlugin.getUniqueIdentifier()) + ".ATTR_CMDLINE";
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 53 */   public static final String ATTR_PROCESS_TYPE = String.valueOf(DebugPlugin.getUniqueIdentifier()) + ".ATTR_PROCESS_TYPE";
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 62 */   public static final String ATTR_PROCESS_LABEL = String.valueOf(DebugPlugin.getUniqueIdentifier()) + ".ATTR_PROCESS_LABEL";
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 71 */   public static final String ATTR_PROCESS_ID = String.valueOf(DebugPlugin.getUniqueIdentifier()) + ".ATTR_PROCESS_ID";
/*    */   
/*    */   String getLabel();
/*    */   
/*    */   ILaunch getLaunch();
/*    */   
/*    */   IStreamsProxy getStreamsProxy();
/*    */   
/*    */   void setAttribute(String paramString1, String paramString2);
/*    */   
/*    */   String getAttribute(String paramString);
/*    */   
/*    */   int getExitValue() throws DebugException;
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.debug.core-3.21.0.jar!\org\eclipse\debug\core\model\IProcess.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */