/*    */ package org.eclipse.debug.internal.core;
/*    */ 
/*    */ import java.net.URL;
/*    */ import org.eclipse.core.runtime.CoreException;
/*    */ import org.eclipse.core.runtime.IPath;
/*    */ import org.eclipse.core.runtime.Path;
/*    */ import org.eclipse.core.runtime.Platform;
/*    */ import org.eclipse.core.variables.IDynamicVariable;
/*    */ import org.eclipse.core.variables.IDynamicVariableResolver;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SystemVariableResolver
/*    */   implements IDynamicVariableResolver
/*    */ {
/*    */   public String resolveValue(IDynamicVariable variable, String argument) throws CoreException {
/* 40 */     if ("ARCH".equals(argument))
/* 41 */       return Platform.getOSArch(); 
/* 42 */     if ("ECLIPSE_HOME".equals(argument)) {
/* 43 */       URL installURL = Platform.getInstallLocation().getURL();
/* 44 */       IPath ppath = (new Path(installURL.getFile())).removeTrailingSeparator();
/* 45 */       return getCorrectPath(ppath.toOSString());
/* 46 */     }  if ("NL".equals(argument))
/* 47 */       return Platform.getNL(); 
/* 48 */     if ("OS".equals(argument))
/* 49 */       return Platform.getOS(); 
/* 50 */     if ("WS".equals(argument)) {
/* 51 */       return Platform.getWS();
/*    */     }
/* 53 */     return null;
/*    */   }
/*    */   
/*    */   private static String getCorrectPath(String path) {
/* 57 */     StringBuilder buf = new StringBuilder();
/* 58 */     for (int i = 0; i < path.length(); i++) {
/* 59 */       char c = path.charAt(i);
/* 60 */       if (Platform.getOS().equals("win32") && 
/* 61 */         i == 0 && c == '/') {
/*    */         continue;
/*    */       }
/*    */ 
/*    */       
/* 66 */       if (c == '%' && i + 2 < path.length()) {
/* 67 */         char c1 = path.charAt(i + 1);
/* 68 */         char c2 = path.charAt(i + 2);
/* 69 */         if (c1 == '2' && c2 == '0') {
/* 70 */           i += 2;
/* 71 */           buf.append(" ");
/*    */           continue;
/*    */         } 
/*    */       } 
/* 75 */       buf.append(c); continue;
/*    */     } 
/* 77 */     return buf.toString();
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.debug.core-3.21.0.jar!\org\eclipse\debug\internal\core\SystemVariableResolver.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */