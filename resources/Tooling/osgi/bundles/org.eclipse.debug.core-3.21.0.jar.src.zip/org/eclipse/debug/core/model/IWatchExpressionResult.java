package org.eclipse.debug.core.model;

import org.eclipse.debug.core.DebugException;

public interface IWatchExpressionResult {
  IValue getValue();
  
  boolean hasErrors();
  
  String[] getErrorMessages();
  
  String getExpressionText();
  
  DebugException getException();
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.debug.core-3.21.0.jar!\org\eclipse\debug\core\model\IWatchExpressionResult.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */