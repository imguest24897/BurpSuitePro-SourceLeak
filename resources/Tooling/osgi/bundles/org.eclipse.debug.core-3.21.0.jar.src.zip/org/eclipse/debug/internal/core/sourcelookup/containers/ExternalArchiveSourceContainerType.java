/*    */ package org.eclipse.debug.internal.core.sourcelookup.containers;
/*    */ 
/*    */ import org.eclipse.core.runtime.CoreException;
/*    */ import org.eclipse.debug.core.sourcelookup.ISourceContainer;
/*    */ import org.eclipse.debug.core.sourcelookup.containers.AbstractSourceContainerTypeDelegate;
/*    */ import org.eclipse.debug.core.sourcelookup.containers.ExternalArchiveSourceContainer;
/*    */ import org.eclipse.debug.internal.core.sourcelookup.SourceLookupMessages;
/*    */ import org.w3c.dom.Document;
/*    */ import org.w3c.dom.Element;
/*    */ import org.w3c.dom.Node;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ExternalArchiveSourceContainerType
/*    */   extends AbstractSourceContainerTypeDelegate
/*    */ {
/*    */   public ISourceContainer createSourceContainer(String memento) throws CoreException {
/* 34 */     Node node = parseDocument(memento);
/* 35 */     if (node.getNodeType() == 1) {
/* 36 */       Element element = (Element)node;
/* 37 */       if ("archive".equals(element.getNodeName())) {
/* 38 */         String string = element.getAttribute("path");
/* 39 */         if (string == null || string.length() == 0) {
/* 40 */           abort(SourceLookupMessages.ExternalArchiveSourceContainerType_10, null);
/*    */         }
/* 42 */         String detect = element.getAttribute("detectRoot");
/* 43 */         boolean auto = "true".equals(detect);
/* 44 */         return (ISourceContainer)new ExternalArchiveSourceContainer(string, auto);
/*    */       } 
/* 46 */       abort(SourceLookupMessages.ExternalArchiveSourceContainerType_11, null);
/*    */     } 
/* 48 */     abort(SourceLookupMessages.ExternalArchiveSourceContainerType_12, null);
/* 49 */     return null;
/*    */   }
/*    */ 
/*    */   
/*    */   public String getMemento(ISourceContainer container) throws CoreException {
/* 54 */     ExternalArchiveSourceContainer archive = (ExternalArchiveSourceContainer)container;
/* 55 */     Document document = newDocument();
/* 56 */     Element element = document.createElement("archive");
/* 57 */     element.setAttribute("path", archive.getName());
/* 58 */     String detectRoot = "false";
/* 59 */     if (archive.isDetectRoot()) {
/* 60 */       detectRoot = "true";
/*    */     }
/* 62 */     element.setAttribute("detectRoot", detectRoot);
/* 63 */     document.appendChild(element);
/* 64 */     return serializeDocument(document);
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.debug.core-3.21.0.jar!\org\eclipse\debug\internal\core\sourcelookup\containers\ExternalArchiveSourceContainerType.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */