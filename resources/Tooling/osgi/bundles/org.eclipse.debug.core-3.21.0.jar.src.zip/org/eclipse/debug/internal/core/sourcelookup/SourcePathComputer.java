/*    */ package org.eclipse.debug.internal.core.sourcelookup;
/*    */ 
/*    */ import org.eclipse.core.runtime.CoreException;
/*    */ import org.eclipse.core.runtime.IConfigurationElement;
/*    */ import org.eclipse.core.runtime.IProgressMonitor;
/*    */ import org.eclipse.debug.core.DebugPlugin;
/*    */ import org.eclipse.debug.core.ILaunchConfiguration;
/*    */ import org.eclipse.debug.core.sourcelookup.ISourceContainer;
/*    */ import org.eclipse.debug.core.sourcelookup.ISourcePathComputer;
/*    */ import org.eclipse.debug.core.sourcelookup.ISourcePathComputerDelegate;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SourcePathComputer
/*    */   implements ISourcePathComputer
/*    */ {
/* 34 */   private ISourcePathComputerDelegate fDelegate = null;
/*    */ 
/*    */   
/* 37 */   private IConfigurationElement fElement = null;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public SourcePathComputer(IConfigurationElement element) {
/* 45 */     this.fElement = element;
/*    */   }
/*    */ 
/*    */   
/*    */   public String getId() {
/* 50 */     return this.fElement.getAttribute("id");
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   private ISourcePathComputerDelegate getDelegate() throws CoreException {
/* 59 */     if (this.fDelegate == null) {
/* 60 */       this.fDelegate = (ISourcePathComputerDelegate)this.fElement.createExecutableExtension("class");
/*    */     }
/* 62 */     return this.fDelegate;
/*    */   }
/*    */ 
/*    */   
/*    */   public ISourceContainer[] computeSourceContainers(ILaunchConfiguration configuration, IProgressMonitor monitor) {
/*    */     try {
/* 68 */       return getDelegate().computeSourceContainers(configuration, monitor);
/* 69 */     } catch (CoreException e) {
/* 70 */       DebugPlugin.log((Throwable)e);
/*    */       
/* 72 */       return new ISourceContainer[0];
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.debug.core-3.21.0.jar!\org\eclipse\debug\internal\core\sourcelookup\SourcePathComputer.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */