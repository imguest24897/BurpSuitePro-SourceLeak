package org.eclipse.debug.core.model;

import java.math.BigInteger;
import org.eclipse.debug.core.DebugException;

public interface IMemoryBlockExtension extends IMemoryBlock {
  String getExpression();
  
  BigInteger getBigBaseAddress() throws DebugException;
  
  BigInteger getMemoryBlockStartAddress() throws DebugException;
  
  BigInteger getMemoryBlockEndAddress() throws DebugException;
  
  BigInteger getBigLength() throws DebugException;
  
  int getAddressSize() throws DebugException;
  
  boolean supportBaseAddressModification() throws DebugException;
  
  boolean supportsChangeManagement();
  
  void setBaseAddress(BigInteger paramBigInteger) throws DebugException;
  
  MemoryByte[] getBytesFromOffset(BigInteger paramBigInteger, long paramLong) throws DebugException;
  
  MemoryByte[] getBytesFromAddress(BigInteger paramBigInteger, long paramLong) throws DebugException;
  
  void setValue(BigInteger paramBigInteger, byte[] paramArrayOfbyte) throws DebugException;
  
  void connect(Object paramObject);
  
  void disconnect(Object paramObject);
  
  Object[] getConnections();
  
  void dispose() throws DebugException;
  
  IMemoryBlockRetrieval getMemoryBlockRetrieval();
  
  int getAddressableSize() throws DebugException;
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.debug.core-3.21.0.jar!\org\eclipse\debug\core\model\IMemoryBlockExtension.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */