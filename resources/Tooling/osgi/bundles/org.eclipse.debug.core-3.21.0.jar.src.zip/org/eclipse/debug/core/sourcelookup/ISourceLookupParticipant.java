package org.eclipse.debug.core.sourcelookup;

import org.eclipse.core.runtime.CoreException;

public interface ISourceLookupParticipant {
  void init(ISourceLookupDirector paramISourceLookupDirector);
  
  Object[] findSourceElements(Object paramObject) throws CoreException;
  
  String getSourceName(Object paramObject) throws CoreException;
  
  void dispose();
  
  void sourceContainersChanged(ISourceLookupDirector paramISourceLookupDirector);
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.debug.core-3.21.0.jar!\org\eclipse\debug\core\sourcelookup\ISourceLookupParticipant.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */