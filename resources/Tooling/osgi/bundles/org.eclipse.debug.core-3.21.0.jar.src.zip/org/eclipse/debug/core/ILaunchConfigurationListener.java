package org.eclipse.debug.core;

public interface ILaunchConfigurationListener {
  void launchConfigurationAdded(ILaunchConfiguration paramILaunchConfiguration);
  
  void launchConfigurationChanged(ILaunchConfiguration paramILaunchConfiguration);
  
  void launchConfigurationRemoved(ILaunchConfiguration paramILaunchConfiguration);
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.debug.core-3.21.0.jar!\org\eclipse\debug\core\ILaunchConfigurationListener.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */