package org.eclipse.debug.core.model;

import org.eclipse.debug.core.DebugException;
import org.eclipse.debug.core.IBreakpointListener;

public interface IDebugTarget extends IDebugElement, ITerminate, ISuspendResume, IBreakpointListener, IDisconnect, IMemoryBlockRetrieval {
  IProcess getProcess();
  
  IThread[] getThreads() throws DebugException;
  
  boolean hasThreads() throws DebugException;
  
  String getName() throws DebugException;
  
  boolean supportsBreakpoint(IBreakpoint paramIBreakpoint);
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.debug.core-3.21.0.jar!\org\eclipse\debug\core\model\IDebugTarget.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */