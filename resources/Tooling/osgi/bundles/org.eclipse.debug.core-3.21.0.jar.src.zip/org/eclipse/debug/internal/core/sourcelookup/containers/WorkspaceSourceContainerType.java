/*    */ package org.eclipse.debug.internal.core.sourcelookup.containers;
/*    */ 
/*    */ import org.eclipse.core.runtime.CoreException;
/*    */ import org.eclipse.debug.core.sourcelookup.ISourceContainer;
/*    */ import org.eclipse.debug.core.sourcelookup.containers.AbstractSourceContainerTypeDelegate;
/*    */ import org.eclipse.debug.core.sourcelookup.containers.WorkspaceSourceContainer;
/*    */ import org.eclipse.debug.internal.core.sourcelookup.SourceLookupMessages;
/*    */ import org.w3c.dom.Document;
/*    */ import org.w3c.dom.Element;
/*    */ import org.w3c.dom.Node;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class WorkspaceSourceContainerType
/*    */   extends AbstractSourceContainerTypeDelegate
/*    */ {
/*    */   public ISourceContainer createSourceContainer(String memento) throws CoreException {
/* 34 */     Node node = parseDocument(memento);
/* 35 */     if (node.getNodeType() == 1) {
/* 36 */       Element element = (Element)node;
/* 37 */       if ("workspace".equals(element.getNodeName())) {
/* 38 */         return (ISourceContainer)new WorkspaceSourceContainer();
/*    */       }
/* 40 */       abort(SourceLookupMessages.WorkspaceSourceContainerType_3, null);
/*    */     } 
/* 42 */     abort(SourceLookupMessages.WorkspaceSourceContainerType_4, null);
/* 43 */     return null;
/*    */   }
/*    */ 
/*    */   
/*    */   public String getMemento(ISourceContainer container) throws CoreException {
/* 48 */     Document document = newDocument();
/* 49 */     Element element = document.createElement("workspace");
/* 50 */     document.appendChild(element);
/* 51 */     return serializeDocument(document);
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.debug.core-3.21.0.jar!\org\eclipse\debug\internal\core\sourcelookup\containers\WorkspaceSourceContainerType.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */