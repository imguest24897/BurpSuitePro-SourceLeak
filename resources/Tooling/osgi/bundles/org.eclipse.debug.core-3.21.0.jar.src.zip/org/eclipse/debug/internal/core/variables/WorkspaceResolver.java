/*    */ package org.eclipse.debug.internal.core.variables;
/*    */ 
/*    */ import java.io.File;
/*    */ import java.net.URI;
/*    */ import org.eclipse.core.filesystem.EFS;
/*    */ import org.eclipse.core.resources.IResource;
/*    */ import org.eclipse.core.resources.IWorkspaceRoot;
/*    */ import org.eclipse.core.resources.ResourcesPlugin;
/*    */ import org.eclipse.core.runtime.CoreException;
/*    */ import org.eclipse.core.runtime.IPath;
/*    */ import org.eclipse.core.runtime.Path;
/*    */ import org.eclipse.core.runtime.Status;
/*    */ import org.eclipse.core.variables.IDynamicVariable;
/*    */ import org.eclipse.core.variables.IDynamicVariableResolver;
/*    */ import org.eclipse.core.variables.VariablesPlugin;
/*    */ import org.eclipse.osgi.util.NLS;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class WorkspaceResolver
/*    */   implements IDynamicVariableResolver
/*    */ {
/*    */   public String resolveValue(IDynamicVariable variable, String argument) throws CoreException {
/*    */     IResource resource;
/* 42 */     IWorkspaceRoot root = ResourcesPlugin.getWorkspace().getRoot();
/*    */ 
/*    */     
/* 45 */     if (argument == null) {
/* 46 */       IWorkspaceRoot iWorkspaceRoot = root;
/*    */     } else {
/* 48 */       resource = root.findMember((IPath)new Path(argument));
/*    */     } 
/*    */     
/* 51 */     if (resource != null && resource.exists()) {
/* 52 */       URI uri = resource.getLocationURI();
/*    */       
/* 54 */       if (uri != null) {
/* 55 */         File file = EFS.getStore(uri).toLocalFile(0, null);
/*    */         
/* 57 */         if (file != null) {
/* 58 */           return file.getAbsolutePath();
/*    */         }
/*    */       } 
/*    */     } 
/*    */     
/* 63 */     String expression = VariablesPlugin.getDefault().getStringVariableManager().generateVariableExpression(variable.getName(), argument);
/* 64 */     String message = NLS.bind(Messages.WorkspaceResolver_0, expression);
/*    */     
/* 66 */     throw new CoreException(new Status(4, "org.eclipse.core.resources", 368, message, null));
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.debug.core-3.21.0.jar!\org\eclipse\debug\internal\core\variables\WorkspaceResolver.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */