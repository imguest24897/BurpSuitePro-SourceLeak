package org.eclipse.debug.internal.core;

public interface IConfigurationElementConstants {
  public static final String ID = "id";
  
  public static final String NAME = "name";
  
  public static final String CATEGORY = "category";
  
  public static final String LOCAL = "local";
  
  public static final String LAUNCH_SHORTCUT_ID = "shortcutID";
  
  public static final String LAUNCH_PERSPECTIVES = "launchPerspectives";
  
  public static final String LAUNCH_PERSPECTIVE = "launchPerspective";
  
  public static final String MARKER_TYPE = "markerType";
  
  public static final String DELEGATE_CLASS = "delegateClass";
  
  public static final String LAUNCH_CONFIGURATION = "launchConfiguration";
  
  public static final String LAUNCH_MODE = "launchMode";
  
  public static final String LAST_LAUNCH = "lastLaunch";
  
  public static final String LAUNCH = "launch";
  
  public static final String LAUNCH_AS_LABEL = "launchAsLabel";
  
  public static final String LAUNCH_HISTORY = "launchHistory";
  
  public static final String LAUNCH_GROUP = "launchGroup";
  
  public static final String MRU_HISTORY = "mruHistory";
  
  public static final String FAVORITES = "favorites";
  
  public static final String AFTER = "after";
  
  public static final String PATH = "path";
  
  public static final String PLACEMENT = "placement";
  
  public static final String ASSOCIATED_DELEGATE = "associatedDelegate";
  
  public static final String LABEL = "label";
  
  public static final String DESCRIPTION = "description";
  
  public static final String HELP_CONTEXT_ID = "helpContextId";
  
  public static final String ICON = "icon";
  
  public static final String PUBLIC = "public";
  
  public static final String PERSPECTIVE = "perspective";
  
  public static final String PREFERRED_DELEGATES = "preferredDelegates";
  
  public static final String MODES = "modes";
  
  public static final String MODE_COMBINATION = "modeCombination";
  
  public static final String MODE = "mode";
  
  public static final String TYPE = "type";
  
  public static final String TYPE_ID = "typeid";
  
  public static final String OPTIONS = "options";
  
  public static final String DELEGATE = "delegate";
  
  public static final String PARTICIPANT = "participant";
  
  public static final String DEFAULT_LAUNCH_SHORTCUT = "defaultShortcut";
  
  public static final String DELEGATE_NAME = "delegateName";
  
  public static final String GROUP = "group";
  
  public static final String CLASS = "class";
  
  public static final String MODEL_IDENTIFIER = "modelIdentifier";
  
  public static final String CONFIGURATION_TYPES = "configurationType";
  
  public static final String CONTEXT_LABEL = "contextLabel";
  
  public static final String CONTEXTUAL_LAUNCH = "contextualLaunch";
  
  public static final String SOURCE_PATH_COMPUTER = "sourcePathComputerId";
  
  public static final String DELEGATE_DESCRIPTION = "delegateDescription";
  
  public static final String SOURCE_LOCATOR = "sourceLocatorId";
  
  public static final String MIGRATION_DELEGATE = "migrationDelegate";
  
  public static final String MEMENTO = "memento";
  
  public static final String SELECTION = "selection";
  
  public static final String DEBUG_CONTEXT = "debugContext";
  
  public static final String EDITOR_INPUT = "editorInput";
  
  public static final String ALLOW_PROTOTYPES = "allowPrototypes";
  
  public static final String ALLOW_COMMANDLINE = "allowCommandLine";
  
  public static final String ALLOW_OUTPUT_MERGING = "allowOutputMerging";
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.debug.core-3.21.0.jar!\org\eclipse\debug\internal\core\IConfigurationElementConstants.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */