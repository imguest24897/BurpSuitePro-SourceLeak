/*     */ package org.eclipse.debug.internal.core;
/*     */ 
/*     */ import org.eclipse.core.runtime.Platform;
/*     */ import org.eclipse.debug.core.DebugEvent;
/*     */ import org.eclipse.debug.core.DebugException;
/*     */ import org.eclipse.debug.core.DebugPlugin;
/*     */ import org.eclipse.debug.core.ILaunch;
/*     */ import org.eclipse.debug.core.ILaunchConfiguration;
/*     */ import org.eclipse.debug.core.model.IDebugElement;
/*     */ import org.eclipse.debug.core.model.IDebugTarget;
/*     */ import org.eclipse.debug.core.model.IValue;
/*     */ import org.eclipse.debug.core.model.IWatchExpression;
/*     */ import org.eclipse.debug.core.model.IWatchExpressionDelegate;
/*     */ import org.eclipse.debug.core.model.IWatchExpressionListener;
/*     */ import org.eclipse.debug.core.model.IWatchExpressionResult;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class WatchExpression
/*     */   implements IWatchExpression
/*     */ {
/*     */   protected String fExpressionText;
/*     */   protected IWatchExpressionResult fResult;
/*     */   protected IDebugElement fCurrentContext;
/*     */   private boolean fEnabled = true;
/*     */   private boolean fPending = false;
/*     */   
/*     */   public WatchExpression(String expression) {
/*  49 */     this.fExpressionText = expression;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public WatchExpression(String expressionText, boolean enabled) {
/*  60 */     this(expressionText);
/*  61 */     this.fEnabled = enabled;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void evaluate() {
/*  69 */     IDebugElement context = this.fCurrentContext;
/*  70 */     if (context == null) {
/*     */       return;
/*     */     }
/*     */     
/*  74 */     IWatchExpressionListener listener = this::setResult;
/*  75 */     setPending(true);
/*  76 */     IWatchExpressionDelegate delegate = DebugPlugin.getDefault().getExpressionManager().newWatchExpressionDelegate(context.getModelIdentifier());
/*  77 */     if (delegate != null) {
/*  78 */       delegate.evaluateExpression(getExpressionText(), context, listener);
/*     */     } else {
/*     */       
/*  81 */       listener.watchEvaluationFinished(new IWatchExpressionResult()
/*     */           {
/*     */             public IValue getValue() {
/*  84 */               return null;
/*     */             }
/*     */             
/*     */             public boolean hasErrors() {
/*  88 */               return true;
/*     */             }
/*     */             
/*     */             public String[] getErrorMessages() {
/*  92 */               return new String[] { DebugCoreMessages.WatchExpression_0 };
/*     */             }
/*     */             
/*     */             public String getExpressionText() {
/*  96 */               return WatchExpression.this.getExpressionText();
/*     */             }
/*     */             
/*     */             public DebugException getException() {
/* 100 */               return null;
/*     */             }
/*     */           });
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void setExpressionContext(IDebugElement context) {
/* 108 */     synchronized (this) {
/* 109 */       this.fCurrentContext = context;
/*     */     } 
/* 111 */     if (context == null) {
/* 112 */       setResult(null);
/*     */       return;
/*     */     } 
/* 115 */     if (!isEnabled()) {
/*     */       return;
/*     */     }
/*     */     
/* 119 */     evaluate();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setResult(IWatchExpressionResult result) {
/* 129 */     synchronized (this) {
/* 130 */       this.fResult = result;
/* 131 */       this.fPending = false;
/*     */     } 
/* 133 */     fireEvent(new DebugEvent(this, 16, 256));
/* 134 */     fireEvent(new DebugEvent(this, 16, 512));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void fireEvent(DebugEvent event) {
/* 142 */     DebugPlugin.getDefault().fireDebugEventSet(new DebugEvent[] { event });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void watchExpressionChanged() {
/* 151 */     ((ExpressionManager)DebugPlugin.getDefault().getExpressionManager()).watchExpressionChanged(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getExpressionText() {
/* 159 */     return this.fExpressionText;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized IValue getValue() {
/* 167 */     if (this.fResult == null) {
/* 168 */       return null;
/*     */     }
/* 170 */     return this.fResult.getValue();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IDebugTarget getDebugTarget() {
/* 178 */     IDebugElement element = this.fCurrentContext;
/* 179 */     if (element != null) {
/* 180 */       return element.getDebugTarget();
/*     */     }
/* 182 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void dispose() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getModelIdentifier() {
/* 197 */     synchronized (this) {
/* 198 */       IValue value = getValue();
/* 199 */       if (value != null) {
/* 200 */         return value.getModelIdentifier();
/*     */       }
/* 202 */       if (this.fCurrentContext != null) {
/* 203 */         return this.fCurrentContext.getModelIdentifier();
/*     */       }
/*     */     } 
/* 206 */     return DebugPlugin.getUniqueIdentifier();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ILaunch getLaunch() {
/* 214 */     IDebugTarget debugTarget = getDebugTarget();
/* 215 */     if (debugTarget != null) {
/* 216 */       return debugTarget.getLaunch();
/*     */     }
/* 218 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <T> T getAdapter(Class<T> adapter) {
/* 228 */     if (adapter.equals(ILaunchConfiguration.class)) {
/* 229 */       ILaunch launch = getLaunch();
/* 230 */       if (launch != null) {
/* 231 */         return (T)launch.getLaunchConfiguration();
/*     */       }
/*     */     } 
/* 234 */     return (T)Platform.getAdapterManager().getAdapter(this, adapter);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setEnabled(boolean enabled) {
/* 244 */     this.fEnabled = enabled;
/* 245 */     watchExpressionChanged();
/* 246 */     evaluate();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setExpressionText(String expression) {
/* 255 */     this.fExpressionText = expression;
/* 256 */     watchExpressionChanged();
/* 257 */     evaluate();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isEnabled() {
/* 267 */     return this.fEnabled;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized boolean isPending() {
/* 275 */     return this.fPending;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void setPending(boolean pending) {
/* 285 */     synchronized (this) {
/* 286 */       this.fPending = pending;
/*     */     } 
/* 288 */     fireEvent(new DebugEvent(this, 16, 256));
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean hasErrors() {
/* 293 */     return (this.fResult != null && this.fResult.hasErrors());
/*     */   }
/*     */ 
/*     */   
/*     */   public String[] getErrorMessages() {
/* 298 */     if (this.fResult == null) {
/* 299 */       return new String[0];
/*     */     }
/* 301 */     return this.fResult.getErrorMessages();
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.debug.core-3.21.0.jar!\org\eclipse\debug\internal\core\WatchExpression.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */