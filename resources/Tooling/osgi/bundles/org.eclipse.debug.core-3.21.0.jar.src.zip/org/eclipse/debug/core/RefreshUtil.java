/*     */ package org.eclipse.debug.core;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.StringReader;
/*     */ import java.io.StringWriter;
/*     */ import java.text.MessageFormat;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.eclipse.core.resources.IResource;
/*     */ import org.eclipse.core.resources.ResourcesPlugin;
/*     */ import org.eclipse.core.runtime.CoreException;
/*     */ import org.eclipse.core.runtime.IAdaptable;
/*     */ import org.eclipse.core.runtime.IPath;
/*     */ import org.eclipse.core.runtime.IProgressMonitor;
/*     */ import org.eclipse.core.runtime.MultiStatus;
/*     */ import org.eclipse.core.runtime.Path;
/*     */ import org.eclipse.core.runtime.Status;
/*     */ import org.eclipse.core.runtime.SubMonitor;
/*     */ import org.eclipse.core.variables.IStringVariableManager;
/*     */ import org.eclipse.core.variables.VariablesPlugin;
/*     */ import org.eclipse.debug.internal.core.DebugCoreMessages;
/*     */ import org.eclipse.debug.internal.core.ResourceFactory;
/*     */ import org.eclipse.debug.internal.core.XMLMemento;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RefreshUtil
/*     */ {
/*  57 */   public static final String ATTR_REFRESH_SCOPE = String.valueOf(DebugPlugin.getUniqueIdentifier()) + ".ATTR_REFRESH_SCOPE";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  65 */   public static final String ATTR_REFRESH_RECURSIVE = String.valueOf(DebugPlugin.getUniqueIdentifier()) + ".ATTR_REFRESH_RECURSIVE";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final String MEMENTO_SELECTED_PROJECT = "${project}";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final String MEMENTO_SELECTED_CONTAINER = "${container}";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final String MEMENTO_SELECTED_RESOURCE = "${resource}";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final String MEMENTO_WORKSPACE = "${workspace}";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final String NO_WORKING_SET = "NONE";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void refreshResources(IResource[] resources, int depth, IProgressMonitor monitor) throws CoreException {
/* 118 */     if (resources == null || resources.length == 0) {
/*     */       return;
/*     */     }
/* 121 */     SubMonitor lmonitor = SubMonitor.convert(monitor, DebugCoreMessages.RefreshingResources, resources.length);
/* 122 */     if (lmonitor.isCanceled()) {
/*     */       return;
/*     */     }
/* 125 */     MultiStatus status = new MultiStatus(DebugPlugin.getUniqueIdentifier(), 0, DebugCoreMessages.RefreshingResourcesError, null); try {
/*     */       byte b; int i; IResource[] arrayOfIResource;
/* 127 */       for (i = (arrayOfIResource = resources).length, b = 0; b < i; ) { IResource resource = arrayOfIResource[b];
/* 128 */         if (lmonitor.isCanceled()) {
/*     */           break;
/*     */         }
/* 131 */         if (resource != null && resource.isAccessible()) {
/*     */           try {
/* 133 */             resource.refreshLocal(depth, null);
/* 134 */           } catch (CoreException e) {
/* 135 */             status.merge(e.getStatus());
/*     */           } 
/*     */         }
/* 138 */         lmonitor.worked(1); b++; }
/*     */     
/*     */     } finally {
/* 141 */       lmonitor.done();
/*     */     } 
/* 143 */     if (!status.isOK()) {
/* 144 */       throw new CoreException(status);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static IResource[] toResources(String memento) throws CoreException {
/* 159 */     if (memento.startsWith("${resource:")) {
/*     */       
/* 161 */       String pathString = memento.substring(11, memento.length() - 1);
/* 162 */       Path path = new Path(pathString);
/* 163 */       IResource iResource = ResourcesPlugin.getWorkspace().getRoot().findMember((IPath)path);
/* 164 */       if (iResource == null) {
/* 165 */         throw new CoreException(new Status(4, DebugPlugin.getUniqueIdentifier(), 4, MessageFormat.format(DebugCoreMessages.RefreshUtil_1, new Object[] { pathString }), null));
/*     */       }
/* 167 */       return new IResource[] { iResource };
/* 168 */     }  if (memento.startsWith("${working_set:")) {
/* 169 */       String ws = memento.substring(14, memento.length() - 1);
/* 170 */       return getResources(ws);
/* 171 */     }  if (memento.equals("${workspace}")) {
/* 172 */       return new IResource[] { (IResource)ResourcesPlugin.getWorkspace().getRoot() };
/*     */     }
/*     */     
/* 175 */     IStringVariableManager manager = VariablesPlugin.getDefault().getStringVariableManager();
/* 176 */     IResource resource = null;
/*     */     try {
/* 178 */       String pathString = manager.performStringSubstitution("${selected_resource_path}");
/* 179 */       resource = ResourcesPlugin.getWorkspace().getRoot().findMember((IPath)new Path(pathString));
/* 180 */     } catch (CoreException coreException) {}
/*     */ 
/*     */     
/* 183 */     if (resource == null)
/*     */     {
/* 185 */       return new IResource[0]; } 
/* 186 */     if (memento.equals("${resource}"))
/* 187 */       return new IResource[] { resource }; 
/* 188 */     if (memento.equals("${container}"))
/* 189 */       return new IResource[] { (IResource)resource.getParent() }; 
/* 190 */     if (memento.equals("${project}")) {
/* 191 */       return new IResource[] { (IResource)resource.getProject() };
/*     */     }
/*     */     
/* 194 */     throw new CoreException(new Status(4, DebugPlugin.getUniqueIdentifier(), MessageFormat.format(DebugCoreMessages.RefreshUtil_0, new Object[] { memento })));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String toMemento(IResource[] resources) {
/* 205 */     XMLMemento memento = XMLMemento.createWriteRoot("resources"); byte b; int i; IResource[] arrayOfIResource;
/* 206 */     for (i = (arrayOfIResource = resources).length, b = 0; b < i; ) { IResource resource = arrayOfIResource[b];
/* 207 */       XMLMemento itemMemento = memento.createChild("item");
/* 208 */       ResourceFactory.saveState(itemMemento, resource); b++; }
/*     */     
/* 210 */     StringWriter writer = new StringWriter();
/*     */     try {
/* 212 */       memento.save(writer);
/* 213 */     } catch (IOException e) {
/* 214 */       DebugPlugin.log(e);
/*     */     } 
/* 216 */     StringBuilder buf = new StringBuilder();
/* 217 */     buf.append("${working_set:");
/* 218 */     buf.append(writer.toString());
/* 219 */     buf.append("}");
/* 220 */     return buf.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static IResource[] getResources(String wsMemento) {
/* 232 */     if ("NONE".equals(wsMemento)) {
/* 233 */       return null;
/*     */     }
/*     */     
/* 236 */     List<IAdaptable> resourcesList = new ArrayList<>();
/* 237 */     StringReader reader = new StringReader(wsMemento);
/*     */     
/* 239 */     XMLMemento memento = null;
/*     */     try {
/* 241 */       memento = XMLMemento.createReadRoot(reader);
/* 242 */     } catch (Exception e) {
/* 243 */       DebugPlugin.log(e);
/* 244 */       return null;
/*     */     } 
/*     */     
/* 247 */     XMLMemento[] mementos = memento.getChildren("item"); byte b; int i; XMLMemento[] arrayOfXMLMemento1;
/* 248 */     for (i = (arrayOfXMLMemento1 = mementos).length, b = 0; b < i; ) { XMLMemento m = arrayOfXMLMemento1[b];
/* 249 */       resourcesList.add(ResourceFactory.createElement(m));
/*     */       b++; }
/*     */     
/* 252 */     return resourcesList.<IResource>toArray(new IResource[resourcesList.size()]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isRefreshRecursive(ILaunchConfiguration configuration) throws CoreException {
/* 266 */     return configuration.getAttribute(ATTR_REFRESH_RECURSIVE, true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void refreshResources(ILaunchConfiguration configuration, IProgressMonitor monitor) throws CoreException {
/* 280 */     String scope = configuration.getAttribute(ATTR_REFRESH_SCOPE, (String)null);
/* 281 */     if (scope != null) {
/* 282 */       IResource[] resources = toResources(scope);
/* 283 */       if (resources != null && resources.length > 0) {
/* 284 */         int depth = 1;
/* 285 */         if (isRefreshRecursive(configuration)) {
/* 286 */           depth = 2;
/*     */         }
/* 288 */         refreshResources(resources, depth, monitor);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.debug.core-3.21.0.jar!\org\eclipse\debug\core\RefreshUtil.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */