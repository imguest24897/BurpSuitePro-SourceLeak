/*     */ package org.eclipse.debug.internal.core;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import org.eclipse.debug.core.IBinaryStreamListener;
/*     */ import org.eclipse.debug.core.IStreamListener;
/*     */ import org.eclipse.debug.core.model.IBinaryStreamMonitor;
/*     */ import org.eclipse.debug.core.model.IBinaryStreamsProxy;
/*     */ import org.eclipse.debug.core.model.IStreamMonitor;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class NullStreamsProxy
/*     */   implements IBinaryStreamsProxy
/*     */ {
/*     */   private NullStreamMonitor outputStreamMonitor;
/*     */   private NullStreamMonitor errorStreamMonitor;
/*     */   
/*     */   public NullStreamsProxy(Process process) {
/*  31 */     this.outputStreamMonitor = new NullStreamMonitor(process.getInputStream());
/*  32 */     this.errorStreamMonitor = new NullStreamMonitor(process.getErrorStream());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void closeInputStream() throws IOException {}
/*     */ 
/*     */   
/*     */   public IStreamMonitor getErrorStreamMonitor() {
/*  41 */     return (IStreamMonitor)this.errorStreamMonitor;
/*     */   }
/*     */ 
/*     */   
/*     */   public IStreamMonitor getOutputStreamMonitor() {
/*  46 */     return (IStreamMonitor)this.outputStreamMonitor;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void write(String input) throws IOException {}
/*     */ 
/*     */   
/*     */   public IBinaryStreamMonitor getBinaryErrorStreamMonitor() {
/*  55 */     return this.errorStreamMonitor;
/*     */   }
/*     */ 
/*     */   
/*     */   public IBinaryStreamMonitor getBinaryOutputStreamMonitor() {
/*  60 */     return this.outputStreamMonitor;
/*     */   }
/*     */   
/*     */   public void write(byte[] data, int offset, int length) throws IOException {}
/*     */   
/*     */   private static class NullStreamMonitor
/*     */     implements IBinaryStreamMonitor
/*     */   {
/*     */     private InputStream fStream;
/*     */     
/*     */     public NullStreamMonitor(InputStream stream) {
/*  71 */       this.fStream = stream;
/*  72 */       startReaderThread();
/*     */     }
/*     */     
/*     */     private void startReaderThread() {
/*  76 */       Thread thread = new Thread(() -> {
/*     */             byte[] bytes = new byte[1024];
/*     */             
/*     */             try {
/*     */               Exception exception2;
/*     */               Exception exception1 = null;
/*  82 */             } catch (IOException iOException) {}
/*     */           
/*  84 */           }DebugCoreMessages.NullStreamsProxy_0);
/*  85 */       thread.setDaemon(true);
/*  86 */       thread.start();
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void addListener(IStreamListener listener) {}
/*     */ 
/*     */ 
/*     */     
/*     */     public String getContents() {
/*  96 */       return "";
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void flushContents() {}
/*     */ 
/*     */ 
/*     */     
/*     */     public void setBuffered(boolean buffer) {}
/*     */ 
/*     */     
/*     */     public boolean isBuffered() {
/* 109 */       return false;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void removeListener(IStreamListener listener) {}
/*     */ 
/*     */ 
/*     */     
/*     */     public void addBinaryListener(IBinaryStreamListener listener) {}
/*     */ 
/*     */     
/*     */     public byte[] getData() {
/* 122 */       return new byte[0];
/*     */     }
/*     */     
/*     */     public void removeBinaryListener(IBinaryStreamListener listener) {}
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.debug.core-3.21.0.jar!\org\eclipse\debug\internal\core\NullStreamsProxy.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */