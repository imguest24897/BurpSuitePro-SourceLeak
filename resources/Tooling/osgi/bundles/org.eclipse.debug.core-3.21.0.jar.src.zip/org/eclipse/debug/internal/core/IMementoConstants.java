package org.eclipse.debug.internal.core;

public interface IMementoConstants {
  public static final String TAG_FACTORY_ID = "factoryID";
  
  public static final String TAG_EDITOR_STATE = "editorState";
  
  public static final String MEMENTO_ITEM = "item";
  
  public static final String TAG_EDIT_PAGE_ID = "editPageId";
  
  public static final String TAG_NAME = "name";
  
  public static final String TAG_LABEL = "label";
  
  public static final String TAG_ID = "id";
  
  public static final String TAG_LAUNCH_CONFIGURATION_WORKING_SET = "launchConfigurationWorkingSet";
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.debug.core-3.21.0.jar!\org\eclipse\debug\internal\core\IMementoConstants.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */