package org.eclipse.debug.core;

import org.eclipse.core.resources.IMarkerDelta;
import org.eclipse.debug.core.model.IBreakpoint;

public interface IBreakpointListener {
  void breakpointAdded(IBreakpoint paramIBreakpoint);
  
  void breakpointRemoved(IBreakpoint paramIBreakpoint, IMarkerDelta paramIMarkerDelta);
  
  void breakpointChanged(IBreakpoint paramIBreakpoint, IMarkerDelta paramIMarkerDelta);
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.debug.core-3.21.0.jar!\org\eclipse\debug\core\IBreakpointListener.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */