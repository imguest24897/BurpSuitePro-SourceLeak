/*     */ package org.eclipse.debug.core.sourcelookup;
/*     */ 
/*     */ import java.util.Objects;
/*     */ import org.eclipse.core.runtime.CoreException;
/*     */ import org.eclipse.debug.core.ILaunchConfiguration;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public interface ISourceLookupDirector
/*     */   extends IPersistableSourceLocator2
/*     */ {
/*     */   ILaunchConfiguration getLaunchConfiguration();
/*     */   
/*     */   ISourceLookupParticipant[] getParticipants();
/*     */   
/*     */   ISourceContainer[] getSourceContainers();
/*     */   
/*     */   void setSourceContainers(ISourceContainer[] paramArrayOfISourceContainer);
/*     */   
/*     */   boolean isFindDuplicates();
/*     */   
/*     */   void setFindDuplicates(boolean paramBoolean);
/*     */   
/*     */   void initializeParticipants();
/*     */   
/*     */   boolean supportsSourceContainerType(ISourceContainerType paramISourceContainerType);
/*     */   
/*     */   void clearSourceElements(Object paramObject);
/*     */   
/*     */   void addParticipants(ISourceLookupParticipant[] paramArrayOfISourceLookupParticipant);
/*     */   
/*     */   void removeParticipants(ISourceLookupParticipant[] paramArrayOfISourceLookupParticipant);
/*     */   
/*     */   String getId();
/*     */   
/*     */   ISourcePathComputer getSourcePathComputer();
/*     */   
/*     */   void setSourcePathComputer(ISourcePathComputer paramISourcePathComputer);
/*     */   
/*     */   Object[] findSourceElements(Object paramObject) throws CoreException;
/*     */   
/*     */   Object getSourceElement(Object paramObject);
/*     */   
/*     */   default boolean equalSourceElements(Object element1, Object element2) {
/* 200 */     return Objects.equals(element1, element2);
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.debug.core-3.21.0.jar!\org\eclipse\debug\core\sourcelookup\ISourceLookupDirector.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */