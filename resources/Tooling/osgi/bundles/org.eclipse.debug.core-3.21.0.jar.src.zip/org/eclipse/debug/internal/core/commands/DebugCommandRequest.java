/*    */ package org.eclipse.debug.internal.core.commands;
/*    */ 
/*    */ import java.util.Arrays;
/*    */ import org.eclipse.debug.core.commands.IDebugCommandRequest;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DebugCommandRequest
/*    */   extends Request
/*    */   implements IDebugCommandRequest
/*    */ {
/*    */   private Object[] fElements;
/*    */   
/*    */   public DebugCommandRequest(Object[] elements) {
/* 28 */     this.fElements = elements;
/*    */   }
/*    */ 
/*    */   
/*    */   public Object[] getElements() {
/* 33 */     return this.fElements;
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 38 */     return String.valueOf(getClass().getSimpleName()) + " on " + Arrays.toString(this.fElements);
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.debug.core-3.21.0.jar!\org\eclipse\debug\internal\core\commands\DebugCommandRequest.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */