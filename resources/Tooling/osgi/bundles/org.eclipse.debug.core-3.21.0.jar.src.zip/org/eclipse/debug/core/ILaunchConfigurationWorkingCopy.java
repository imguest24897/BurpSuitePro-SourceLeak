package org.eclipse.debug.core;

import java.util.List;
import java.util.Map;
import java.util.Set;
import org.eclipse.core.resources.IContainer;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IAdaptable;

public interface ILaunchConfigurationWorkingCopy extends ILaunchConfiguration, IAdaptable {
  boolean isDirty();
  
  ILaunchConfiguration doSave() throws CoreException;
  
  ILaunchConfiguration doSave(int paramInt) throws CoreException;
  
  void setAttribute(String paramString, int paramInt);
  
  void setAttribute(String paramString1, String paramString2);
  
  void setAttribute(String paramString, List<String> paramList);
  
  void setAttribute(String paramString, Map<String, String> paramMap);
  
  void setAttribute(String paramString, Set<String> paramSet);
  
  void setAttribute(String paramString, boolean paramBoolean);
  
  void setAttribute(String paramString, Object paramObject);
  
  ILaunchConfiguration getOriginal();
  
  void rename(String paramString);
  
  void setContainer(IContainer paramIContainer);
  
  void setAttributes(Map<String, ? extends Object> paramMap);
  
  void setMappedResources(IResource[] paramArrayOfIResource);
  
  void setModes(Set<String> paramSet);
  
  void setPreferredLaunchDelegate(Set<String> paramSet, String paramString);
  
  void addModes(Set<String> paramSet);
  
  void removeModes(Set<String> paramSet);
  
  Object removeAttribute(String paramString);
  
  ILaunchConfigurationWorkingCopy getParent();
  
  void copyAttributes(ILaunchConfiguration paramILaunchConfiguration) throws CoreException;
  
  void setPrototype(ILaunchConfiguration paramILaunchConfiguration, boolean paramBoolean) throws CoreException;
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.debug.core-3.21.0.jar!\org\eclipse\debug\core\ILaunchConfigurationWorkingCopy.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */