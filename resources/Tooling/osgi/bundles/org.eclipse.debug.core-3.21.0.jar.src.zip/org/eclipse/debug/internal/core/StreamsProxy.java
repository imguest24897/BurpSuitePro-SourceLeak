/*     */ package org.eclipse.debug.internal.core;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.nio.charset.Charset;
/*     */ import org.eclipse.debug.core.model.IBinaryStreamMonitor;
/*     */ import org.eclipse.debug.core.model.IBinaryStreamsProxy;
/*     */ import org.eclipse.debug.core.model.IStreamMonitor;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class StreamsProxy
/*     */   implements IBinaryStreamsProxy
/*     */ {
/*     */   private OutputStreamMonitor fOutputMonitor;
/*     */   private OutputStreamMonitor fErrorMonitor;
/*     */   private InputStreamMonitor fInputMonitor;
/*     */   private boolean fClosed;
/*     */   
/*     */   public StreamsProxy(Process process, Charset charset, String suffix) {
/*  62 */     if (process == null) {
/*     */       return;
/*     */     }
/*  65 */     this.fOutputMonitor = new OutputStreamMonitor(process.getInputStream(), charset);
/*  66 */     this.fErrorMonitor = new OutputStreamMonitor(process.getErrorStream(), charset);
/*  67 */     this.fInputMonitor = new InputStreamMonitor(process.getOutputStream(), charset);
/*  68 */     this.fOutputMonitor.startMonitoring("Output Stream Monitor" + suffix);
/*  69 */     this.fErrorMonitor.startMonitoring("Error Stream Monitor" + suffix);
/*  70 */     this.fInputMonitor.startMonitoring("Input Stream Monitor" + suffix);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public StreamsProxy(Process process, String encoding) {
/*  87 */     this(process, Charset.forName(encoding), "");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void close() {
/*  95 */     if (!isClosed(true)) {
/*  96 */       this.fOutputMonitor.close();
/*  97 */       this.fErrorMonitor.close();
/*  98 */       this.fInputMonitor.close();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private synchronized boolean isClosed(boolean setClosed) {
/* 112 */     boolean closed = this.fClosed;
/* 113 */     if (setClosed) {
/* 114 */       this.fClosed = true;
/*     */     }
/* 116 */     return closed;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void kill() {
/* 126 */     synchronized (this) {
/* 127 */       this.fClosed = true;
/*     */     } 
/* 129 */     this.fOutputMonitor.kill();
/* 130 */     this.fErrorMonitor.kill();
/* 131 */     this.fInputMonitor.close();
/*     */   }
/*     */ 
/*     */   
/*     */   public IStreamMonitor getErrorStreamMonitor() {
/* 136 */     return (IStreamMonitor)this.fErrorMonitor;
/*     */   }
/*     */ 
/*     */   
/*     */   public IStreamMonitor getOutputStreamMonitor() {
/* 141 */     return (IStreamMonitor)this.fOutputMonitor;
/*     */   }
/*     */ 
/*     */   
/*     */   public void write(String input) throws IOException {
/* 146 */     if (!isClosed(false)) {
/* 147 */       this.fInputMonitor.write(input);
/*     */     } else {
/* 149 */       throw new IOException();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void closeInputStream() throws IOException {
/* 155 */     if (!isClosed(false)) {
/* 156 */       this.fInputMonitor.closeInputStream();
/*     */     } else {
/* 158 */       throw new IOException();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public IBinaryStreamMonitor getBinaryErrorStreamMonitor() {
/* 165 */     return this.fErrorMonitor;
/*     */   }
/*     */ 
/*     */   
/*     */   public IBinaryStreamMonitor getBinaryOutputStreamMonitor() {
/* 170 */     return this.fOutputMonitor;
/*     */   }
/*     */ 
/*     */   
/*     */   public void write(byte[] data, int offset, int length) throws IOException {
/* 175 */     if (!isClosed(false)) {
/* 176 */       this.fInputMonitor.write(data, offset, length);
/*     */     } else {
/* 178 */       throw new IOException();
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.debug.core-3.21.0.jar!\org\eclipse\debug\internal\core\StreamsProxy.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */