/*    */ package org.eclipse.debug.internal.core.groups.observer;
/*    */ 
/*    */ import java.util.concurrent.CountDownLatch;
/*    */ import java.util.regex.Matcher;
/*    */ import java.util.regex.Pattern;
/*    */ import org.eclipse.core.runtime.IProgressMonitor;
/*    */ import org.eclipse.debug.core.IStreamListener;
/*    */ import org.eclipse.debug.core.model.IProcess;
/*    */ import org.eclipse.debug.core.model.IStreamMonitor;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class StreamObserver
/*    */   implements Runnable
/*    */ {
/*    */   private final String stringPattern;
/*    */   private final IProcess process;
/*    */   private final CountDownLatch countDownLatch;
/*    */   private final IProgressMonitor pMonitor;
/*    */   
/*    */   public StreamObserver(IProgressMonitor monitor, IProcess process, String pattern, CountDownLatch countDownLatch) {
/* 39 */     this.process = process;
/* 40 */     this.pMonitor = monitor;
/* 41 */     this.stringPattern = pattern;
/* 42 */     this.countDownLatch = countDownLatch;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void run() {
/* 48 */     StringBuilder patternBuilder = new StringBuilder();
/* 49 */     if (!this.stringPattern.startsWith(".*")) {
/* 50 */       patternBuilder.append(".*");
/*    */     }
/* 52 */     patternBuilder.append(this.stringPattern);
/* 53 */     if (!this.stringPattern.endsWith(".*")) {
/* 54 */       patternBuilder.append(".*");
/*    */     }
/*    */     
/* 57 */     final Pattern pattern = Pattern.compile(patternBuilder.toString(), 8);
/* 58 */     final IStreamMonitor outputStreamMonitor = this.process.getStreamsProxy()
/* 59 */       .getOutputStreamMonitor();
/* 60 */     outputStreamMonitor.addListener(new IStreamListener()
/*    */         {
/*    */           public void streamAppended(String text, IStreamMonitor monitor) {
/* 63 */             if (StreamObserver.this.countDownLatch.getCount() == 0L) {
/* 64 */               outputStreamMonitor.removeListener(this);
/*    */               
/*    */               return;
/*    */             } 
/* 68 */             Matcher matcher = pattern.matcher(text);
/* 69 */             if (!matcher.find() && !StreamObserver.this.pMonitor.isCanceled()) {
/*    */               return;
/*    */             }
/* 72 */             StreamObserver.this.countDownLatch.countDown();
/*    */           }
/*    */         });
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.debug.core-3.21.0.jar!\org\eclipse\debug\internal\core\groups\observer\StreamObserver.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */