package org.eclipse.debug.core.model;

import org.eclipse.debug.core.DebugException;

public interface IValue extends IDebugElement {
  String getReferenceTypeName() throws DebugException;
  
  String getValueString() throws DebugException;
  
  boolean isAllocated() throws DebugException;
  
  IVariable[] getVariables() throws DebugException;
  
  boolean hasVariables() throws DebugException;
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.debug.core-3.21.0.jar!\org\eclipse\debug\core\model\IValue.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */