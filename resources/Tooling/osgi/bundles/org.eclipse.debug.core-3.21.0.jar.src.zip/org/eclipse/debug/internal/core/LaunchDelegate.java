/*     */ package org.eclipse.debug.internal.core;
/*     */ 
/*     */ import java.text.MessageFormat;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import org.eclipse.core.runtime.CoreException;
/*     */ import org.eclipse.core.runtime.IConfigurationElement;
/*     */ import org.eclipse.core.runtime.Status;
/*     */ import org.eclipse.debug.core.DebugPlugin;
/*     */ import org.eclipse.debug.core.ILaunchDelegate;
/*     */ import org.eclipse.debug.core.model.ILaunchConfigurationDelegate;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class LaunchDelegate
/*     */   implements ILaunchDelegate
/*     */ {
/*  67 */   private IConfigurationElement fElement = null;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  72 */   private ILaunchConfigurationDelegate fDelegate = null;
/*     */ 
/*     */   
/*  75 */   private List<Set<String>> fLaunchModes = null;
/*  76 */   private String fType = null;
/*  77 */   private HashMap<Set<String>, String> fPerspectiveIds = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LaunchDelegate(IConfigurationElement element) {
/*  84 */     this.fElement = element;
/*     */   }
/*     */ 
/*     */   
/*     */   public ILaunchConfigurationDelegate getDelegate() throws CoreException {
/*  89 */     if (this.fDelegate == null) {
/*  90 */       Object obj = this.fElement.createExecutableExtension("delegate");
/*  91 */       if (obj instanceof ILaunchConfigurationDelegate) {
/*  92 */         this.fDelegate = (ILaunchConfigurationDelegate)obj;
/*     */       } else {
/*  94 */         throw new CoreException(new Status(4, DebugPlugin.getUniqueIdentifier(), 125, MessageFormat.format(DebugCoreMessages.LaunchDelegate_3, new Object[] { getId() }), null));
/*     */       } 
/*     */     } 
/*  97 */     return this.fDelegate;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getId() {
/* 102 */     return this.fElement.getAttribute("id");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getLaunchConfigurationTypeId() {
/* 110 */     if (this.fType == null) {
/*     */       
/* 112 */       this.fType = this.fElement.getAttribute("type");
/* 113 */       if (this.fType == null)
/*     */       {
/* 115 */         this.fType = this.fElement.getAttribute("id");
/*     */       }
/*     */     } 
/* 118 */     return this.fType;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Set<String> parseModes(IConfigurationElement element) {
/* 128 */     HashSet<String> set = new HashSet<>();
/* 129 */     String modes = element.getAttribute("modes");
/* 130 */     if (modes != null) {
/* 131 */       String[] strings = modes.split(","); byte b; int i; String[] arrayOfString1;
/* 132 */       for (i = (arrayOfString1 = strings).length, b = 0; b < i; ) { String string = arrayOfString1[b];
/* 133 */         set.add(string.trim()); b++; }
/*     */     
/*     */     } 
/* 136 */     return set;
/*     */   }
/*     */ 
/*     */   
/*     */   public List<Set<String>> getModes() {
/* 141 */     if (this.fLaunchModes == null) {
/* 142 */       this.fLaunchModes = new ArrayList<>();
/* 143 */       this.fPerspectiveIds = new HashMap<>();
/* 144 */       IConfigurationElement[] children = this.fElement.getChildren("modeCombination");
/* 145 */       Set<String> modeset = null; byte b; int i; IConfigurationElement[] arrayOfIConfigurationElement1;
/* 146 */       for (i = (arrayOfIConfigurationElement1 = children).length, b = 0; b < i; ) { IConfigurationElement child = arrayOfIConfigurationElement1[b];
/* 147 */         modeset = parseModes(child);
/* 148 */         this.fLaunchModes.add(modeset);
/* 149 */         this.fPerspectiveIds.put(modeset, child.getAttribute("perspective"));
/*     */         
/*     */         b++; }
/*     */       
/* 153 */       modeset = null;
/* 154 */       String modes = this.fElement.getAttribute("modes");
/* 155 */       if (modes != null) {
/* 156 */         String[] strings = modes.split(","); byte b1; int j; String[] arrayOfString1;
/* 157 */         for (j = (arrayOfString1 = strings).length, b1 = 0; b1 < j; ) { String string = arrayOfString1[b1];
/* 158 */           modeset = new HashSet<>();
/* 159 */           modeset.add(string.trim());
/* 160 */           this.fLaunchModes.add(modeset); b1++; }
/*     */       
/*     */       } 
/*     */     } 
/* 164 */     return this.fLaunchModes;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getName() {
/* 174 */     String name = this.fElement.getAttribute("delegateName");
/* 175 */     if (name == null) {
/* 176 */       name = this.fElement.getAttribute("name");
/* 177 */       if (name == null) {
/* 178 */         name = getContributorName();
/*     */       }
/* 180 */       name = name.trim();
/* 181 */       if (Character.isUpperCase(name.charAt(0))) {
/* 182 */         name = MessageFormat.format(DebugCoreMessages.LaunchDelegate_1, new Object[] { name });
/*     */       } else {
/* 184 */         name = MessageFormat.format(DebugCoreMessages.LaunchDelegate_2, new Object[] { name });
/*     */       } 
/*     */     } 
/* 187 */     return name;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getContributorName() {
/* 197 */     return this.fElement.getContributor().getName();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getSourceLocatorId() {
/* 205 */     return this.fElement.getAttribute("sourceLocatorId");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getSourcePathComputerId() {
/* 213 */     return this.fElement.getAttribute("sourcePathComputerId");
/*     */   }
/*     */ 
/*     */   
/*     */   public String getDescription() {
/* 218 */     String desc = this.fElement.getAttribute("delegateDescription");
/* 219 */     if (desc == null) {
/* 220 */       return DebugCoreMessages.LaunchDelegate_0;
/*     */     }
/* 222 */     return desc;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getPluginIdentifier() {
/* 227 */     return this.fElement.getContributor().getName();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object obj) {
/* 232 */     if (obj == null) {
/* 233 */       return false;
/*     */     }
/* 235 */     return (obj instanceof ILaunchDelegate && getId() != null && getId().equals(((ILaunchDelegate)obj).getId()));
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 240 */     String id = getId();
/* 241 */     return (id == null) ? 0 : id.hashCode();
/*     */   }
/*     */ 
/*     */   
/*     */   public String getPerspectiveId(Set<String> modes) {
/* 246 */     if (this.fPerspectiveIds == null) {
/* 247 */       getModes();
/*     */     }
/* 249 */     return this.fPerspectiveIds.get(modes);
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.debug.core-3.21.0.jar!\org\eclipse\debug\internal\core\LaunchDelegate.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */