/*    */ package org.eclipse.debug.internal.core;
/*    */ 
/*    */ import java.util.Comparator;
/*    */ import org.eclipse.core.runtime.CoreException;
/*    */ import org.eclipse.core.runtime.IConfigurationElement;
/*    */ import org.eclipse.debug.core.DebugPlugin;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class LaunchConfigurationComparator
/*    */   implements Comparator<Object>
/*    */ {
/*    */   private IConfigurationElement fConfigurationElement;
/*    */   private Comparator<Object> fDelegate;
/*    */   
/*    */   public LaunchConfigurationComparator(IConfigurationElement element) {
/* 41 */     this.fConfigurationElement = element;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected Comparator<Object> getComparator() {
/* 50 */     if (this.fDelegate == null) {
/*    */       
/*    */       try {
/* 53 */         Comparator<Object> delegate = (Comparator<Object>)this.fConfigurationElement.createExecutableExtension("class");
/* 54 */         this.fDelegate = delegate;
/* 55 */       } catch (CoreException e) {
/* 56 */         DebugPlugin.log((Throwable)e);
/*    */       } 
/*    */     }
/* 59 */     return this.fDelegate;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public int compare(Object o1, Object o2) {
/* 68 */     return getComparator().compare(o1, o2);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean equals(Object obj) {
/* 76 */     return getComparator().equals(obj);
/*    */   }
/*    */ 
/*    */   
/*    */   public int hashCode() {
/* 81 */     return getComparator().hashCode();
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.debug.core-3.21.0.jar!\org\eclipse\debug\internal\core\LaunchConfigurationComparator.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */