package org.eclipse.debug.core;

import java.util.Set;
import org.eclipse.core.resources.IContainer;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IAdaptable;
import org.eclipse.debug.core.model.ILaunchConfigurationDelegate;
import org.eclipse.debug.core.sourcelookup.ISourcePathComputer;

public interface ILaunchConfigurationType extends IAdaptable {
  String getAttribute(String paramString);
  
  String getCategory();
  
  @Deprecated
  ILaunchConfigurationDelegate getDelegate() throws CoreException;
  
  @Deprecated
  ILaunchConfigurationDelegate getDelegate(String paramString) throws CoreException;
  
  ILaunchDelegate[] getDelegates(Set<String> paramSet) throws CoreException;
  
  ILaunchDelegate getPreferredDelegate(Set<String> paramSet) throws CoreException;
  
  void setPreferredDelegate(Set<String> paramSet, ILaunchDelegate paramILaunchDelegate) throws CoreException;
  
  boolean supportsModeCombination(Set<String> paramSet);
  
  String getIdentifier();
  
  String getName();
  
  String getPluginIdentifier();
  
  String getSourceLocatorId();
  
  ISourcePathComputer getSourcePathComputer();
  
  @Deprecated
  Set<String> getSupportedModes();
  
  Set<Set<String>> getSupportedModeCombinations();
  
  boolean isPublic();
  
  ILaunchConfigurationWorkingCopy newInstance(IContainer paramIContainer, String paramString) throws CoreException;
  
  boolean supportsMode(String paramString);
  
  String getContributorName();
  
  ILaunchConfiguration[] getPrototypes() throws CoreException;
  
  ILaunchConfigurationWorkingCopy newPrototypeInstance(IContainer paramIContainer, String paramString) throws CoreException;
  
  boolean supportsPrototypes();
  
  boolean supportsCommandLine();
  
  boolean supportsOutputMerging();
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.debug.core-3.21.0.jar!\org\eclipse\debug\core\ILaunchConfigurationType.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */