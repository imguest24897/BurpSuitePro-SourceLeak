/*     */ package org.eclipse.debug.core.commands;
/*     */ 
/*     */ import org.eclipse.core.runtime.CoreException;
/*     */ import org.eclipse.core.runtime.IProgressMonitor;
/*     */ import org.eclipse.core.runtime.IStatus;
/*     */ import org.eclipse.core.runtime.Status;
/*     */ import org.eclipse.core.runtime.jobs.Job;
/*     */ import org.eclipse.debug.internal.core.DebugOptions;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class null
/*     */   extends Job
/*     */ {
/*     */   null(String $anonymous0) {
/* 201 */     super($anonymous0);
/*     */   }
/*     */   protected IStatus run(IProgressMonitor monitor) {
/* 204 */     if (DebugOptions.DEBUG_COMMANDS) {
/* 205 */       DebugOptions.trace("execute: " + AbstractDebugCommand.this);
/*     */     }
/* 207 */     Object[] elements = request.getElements();
/* 208 */     Object[] targets = new Object[elements.length];
/* 209 */     for (int i = 0; i < elements.length; i++) {
/* 210 */       targets[i] = AbstractDebugCommand.this.getTarget(elements[i]);
/*     */     }
/* 212 */     targets = AbstractDebugCommand.this.coalesce(targets);
/* 213 */     monitor.beginTask(AbstractDebugCommand.this.getExecuteTaskName(), targets.length);
/*     */     try {
/* 215 */       AbstractDebugCommand.this.doExecute(targets, monitor, request);
/* 216 */     } catch (CoreException e) {
/* 217 */       request.setStatus(e.getStatus());
/* 218 */       if (DebugOptions.DEBUG_COMMANDS) {
/* 219 */         DebugOptions.trace("\t" + e.getStatus().getMessage());
/*     */       }
/*     */     } 
/* 222 */     request.done();
/* 223 */     monitor.setCanceled(request.isCanceled());
/* 224 */     monitor.done();
/* 225 */     return Status.OK_STATUS;
/*     */   }
/*     */   
/*     */   public boolean belongsTo(Object family) {
/* 229 */     Object jobFamily = AbstractDebugCommand.this.getExecuteJobFamily(request);
/* 230 */     if (jobFamily != null) {
/* 231 */       return jobFamily.equals(family);
/*     */     }
/* 233 */     return false;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.debug.core-3.21.0.jar!\org\eclipse\debug\core\commands\AbstractDebugCommand$1.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */