/*    */ package org.eclipse.debug.internal.core.sourcelookup.containers;
/*    */ 
/*    */ import org.eclipse.core.runtime.CoreException;
/*    */ import org.eclipse.core.runtime.IPath;
/*    */ import org.eclipse.core.runtime.Path;
/*    */ import org.eclipse.debug.core.sourcelookup.ISourceContainer;
/*    */ import org.eclipse.debug.core.sourcelookup.containers.AbstractSourceContainerTypeDelegate;
/*    */ import org.eclipse.debug.core.sourcelookup.containers.DirectorySourceContainer;
/*    */ import org.eclipse.debug.internal.core.sourcelookup.SourceLookupMessages;
/*    */ import org.w3c.dom.Document;
/*    */ import org.w3c.dom.Element;
/*    */ import org.w3c.dom.Node;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DirectorySourceContainerType
/*    */   extends AbstractSourceContainerTypeDelegate
/*    */ {
/*    */   public ISourceContainer createSourceContainer(String memento) throws CoreException {
/* 35 */     Node node = parseDocument(memento);
/* 36 */     if (node.getNodeType() == 1) {
/* 37 */       Element element = (Element)node;
/* 38 */       if ("directory".equals(element.getNodeName())) {
/* 39 */         String string = element.getAttribute("path");
/* 40 */         if (string == null || string.length() == 0) {
/* 41 */           abort(SourceLookupMessages.DirectorySourceContainerType_10, null);
/*    */         }
/* 43 */         String nest = element.getAttribute("nest");
/* 44 */         boolean nested = "true".equals(nest);
/* 45 */         return (ISourceContainer)new DirectorySourceContainer((IPath)new Path(string), nested);
/*    */       } 
/* 47 */       abort(SourceLookupMessages.DirectorySourceContainerType_11, null);
/*    */     } 
/* 49 */     abort(SourceLookupMessages.DirectorySourceContainerType_12, null);
/* 50 */     return null;
/*    */   }
/*    */ 
/*    */   
/*    */   public String getMemento(ISourceContainer container) throws CoreException {
/* 55 */     DirectorySourceContainer folder = (DirectorySourceContainer)container;
/* 56 */     Document document = newDocument();
/* 57 */     Element element = document.createElement("directory");
/* 58 */     element.setAttribute("path", folder.getDirectory().getAbsolutePath());
/* 59 */     String nest = "false";
/* 60 */     if (folder.isComposite()) {
/* 61 */       nest = "true";
/*    */     }
/* 63 */     element.setAttribute("nest", nest);
/* 64 */     document.appendChild(element);
/* 65 */     return serializeDocument(document);
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.debug.core-3.21.0.jar!\org\eclipse\debug\internal\core\sourcelookup\containers\DirectorySourceContainerType.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */