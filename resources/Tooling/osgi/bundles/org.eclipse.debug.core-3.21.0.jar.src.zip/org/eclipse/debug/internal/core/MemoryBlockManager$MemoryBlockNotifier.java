/*    */ package org.eclipse.debug.internal.core;
/*    */ 
/*    */ import org.eclipse.core.runtime.ISafeRunnable;
/*    */ import org.eclipse.core.runtime.SafeRunner;
/*    */ import org.eclipse.debug.core.DebugPlugin;
/*    */ import org.eclipse.debug.core.IMemoryBlockListener;
/*    */ import org.eclipse.debug.core.model.IMemoryBlock;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class MemoryBlockNotifier
/*    */   implements ISafeRunnable
/*    */ {
/*    */   private IMemoryBlockListener fListener;
/*    */   private int fType;
/*    */   private IMemoryBlock[] fMemoryBlocks;
/*    */   
/*    */   public void handleException(Throwable exception) {
/* 60 */     DebugPlugin.log(exception);
/*    */   }
/*    */ 
/*    */   
/*    */   public void run() throws Exception {
/* 65 */     switch (this.fType) {
/*    */       case 0:
/* 67 */         this.fListener.memoryBlocksAdded(this.fMemoryBlocks);
/*    */         break;
/*    */       case 1:
/* 70 */         this.fListener.memoryBlocksRemoved(this.fMemoryBlocks);
/*    */         break;
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void notify(IMemoryBlock[] memBlocks, int update) {
/* 84 */     if (MemoryBlockManager.this.listeners != null) {
/* 85 */       this.fType = update;
/* 86 */       Object[] copiedListeners = MemoryBlockManager.this.listeners.toArray((Object[])new IMemoryBlockListener[MemoryBlockManager.this.listeners.size()]); byte b; int i; Object[] arrayOfObject1;
/* 87 */       for (i = (arrayOfObject1 = copiedListeners).length, b = 0; b < i; ) { Object copiedListener = arrayOfObject1[b];
/* 88 */         this.fListener = (IMemoryBlockListener)copiedListener;
/* 89 */         this.fMemoryBlocks = memBlocks;
/* 90 */         SafeRunner.run(this); b++; }
/*    */     
/*    */     } 
/* 93 */     this.fListener = null;
/* 94 */     this.fMemoryBlocks = null;
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.debug.core-3.21.0.jar!\org\eclipse\debug\internal\core\MemoryBlockManager$MemoryBlockNotifier.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */