/*     */ package org.eclipse.debug.core.sourcelookup.containers;
/*     */ 
/*     */ import java.net.URI;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import org.eclipse.core.filesystem.EFS;
/*     */ import org.eclipse.core.filesystem.IFileStore;
/*     */ import org.eclipse.core.resources.IContainer;
/*     */ import org.eclipse.core.resources.IFile;
/*     */ import org.eclipse.core.resources.IResource;
/*     */ import org.eclipse.core.resources.IWorkspaceRoot;
/*     */ import org.eclipse.core.resources.ResourcesPlugin;
/*     */ import org.eclipse.core.runtime.CoreException;
/*     */ import org.eclipse.core.runtime.IPath;
/*     */ import org.eclipse.core.runtime.Path;
/*     */ import org.eclipse.debug.core.sourcelookup.ISourceContainer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class ContainerSourceContainer
/*     */   extends CompositeSourceContainer
/*     */ {
/*  49 */   private IContainer fContainer = null;
/*     */   
/*     */   private boolean fSubfolders = false;
/*  52 */   private URI fRootURI = null;
/*  53 */   private IFileStore fRootFile = null;
/*  54 */   private IWorkspaceRoot fRoot = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ContainerSourceContainer(IContainer container, boolean subfolders) {
/*  64 */     this.fContainer = container;
/*  65 */     this.fSubfolders = subfolders;
/*  66 */     this.fRootURI = this.fContainer.getLocationURI();
/*  67 */     if (this.fRootURI != null) {
/*     */       try {
/*  69 */         this.fRootFile = EFS.getStore(this.fRootURI);
/*  70 */       } catch (CoreException coreException) {}
/*     */       
/*  72 */       this.fRoot = ResourcesPlugin.getWorkspace().getRoot();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IContainer getContainer() {
/*  84 */     return this.fContainer;
/*     */   }
/*     */ 
/*     */   
/*     */   public Object[] findSourceElements(String name) throws CoreException {
/*  89 */     ArrayList<Object> sources = new ArrayList();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  96 */     if (validateFile(name)) {
/*  97 */       IFile file = this.fContainer.getFile((IPath)new Path(name));
/*  98 */       if (file.exists()) {
/*  99 */         sources.add(file);
/*     */       } else {
/*     */         
/* 102 */         if (this.fRootURI == null) {
/* 103 */           return EMPTY;
/*     */         }
/*     */         
/* 106 */         if (this.fRootFile != null) {
/*     */           
/* 108 */           IFileStore target = this.fRootFile.getFileStore((IPath)new Path(name));
/* 109 */           if (target.fetchInfo().exists()) {
/*     */ 
/*     */             
/* 112 */             IFile[] files = this.fRoot.findFilesForLocationURI(target.toURI());
/* 113 */             if (isFindDuplicates() && files.length > 1) {
/* 114 */               Collections.addAll(sources, (Object[])files);
/* 115 */             } else if (files.length > 0) {
/* 116 */               sources.add(files[0]);
/*     */             } 
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 124 */     if ((isFindDuplicates() && this.fSubfolders) || (sources.isEmpty() && this.fSubfolders)) {
/* 125 */       byte b; int i; ISourceContainer[] arrayOfISourceContainer; for (i = (arrayOfISourceContainer = getSourceContainers()).length, b = 0; b < i; ) { ISourceContainer container = arrayOfISourceContainer[b];
/* 126 */         Object[] objects = container.findSourceElements(name);
/* 127 */         if (objects != null && objects.length != 0)
/*     */         {
/*     */           
/* 130 */           if (isFindDuplicates()) {
/* 131 */             Collections.addAll(sources, objects);
/*     */           } else {
/* 133 */             sources.add(objects[0]);
/*     */             break;
/*     */           }  } 
/*     */         b++; }
/*     */     
/*     */     } 
/* 139 */     if (sources.isEmpty()) {
/* 140 */       return EMPTY;
/*     */     }
/* 142 */     return sources.toArray();
/*     */   }
/*     */ 
/*     */   
/*     */   public String getName() {
/* 147 */     return getContainer().getName();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object obj) {
/* 152 */     if (obj != null && obj instanceof ContainerSourceContainer) {
/* 153 */       ContainerSourceContainer loc = (ContainerSourceContainer)obj;
/* 154 */       return loc.getContainer().equals(getContainer());
/*     */     } 
/* 156 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 161 */     return getContainer().hashCode();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isComposite() {
/* 166 */     return this.fSubfolders;
/*     */   }
/*     */ 
/*     */   
/*     */   protected ISourceContainer[] createSourceContainers() throws CoreException {
/* 171 */     if (this.fSubfolders) {
/* 172 */       IResource[] resources = getContainer().members();
/* 173 */       List<ISourceContainer> list = new ArrayList<>(resources.length); byte b; int i; IResource[] arrayOfIResource1;
/* 174 */       for (i = (arrayOfIResource1 = resources).length, b = 0; b < i; ) { IResource resource = arrayOfIResource1[b];
/* 175 */         if (resource.getType() == 2)
/* 176 */           list.add(new FolderSourceContainer((IContainer)resource, this.fSubfolders)); 
/*     */         b++; }
/*     */       
/* 179 */       ISourceContainer[] containers = list.<ISourceContainer>toArray(new ISourceContainer[list.size()]); ISourceContainer[] arrayOfISourceContainer1;
/* 180 */       for (int j = (arrayOfISourceContainer1 = containers).length; i < j; ) { ISourceContainer container = arrayOfISourceContainer1[i];
/* 181 */         container.init(getDirector()); i++; }
/*     */       
/* 183 */       return containers;
/*     */     } 
/* 185 */     return new ISourceContainer[0];
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean validateFile(String name) {
/* 195 */     IContainer container = getContainer();
/* 196 */     IPath path = container.getFullPath().append(name);
/* 197 */     return ResourcesPlugin.getWorkspace().validatePath(path.toOSString(), 1).isOK();
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.debug.core-3.21.0.jar!\org\eclipse\debug\core\sourcelookup\containers\ContainerSourceContainer.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */