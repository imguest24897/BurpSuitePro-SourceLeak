/*     */ package org.eclipse.debug.internal.core.groups;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import org.eclipse.core.runtime.IStatus;
/*     */ import org.eclipse.core.runtime.MultiStatus;
/*     */ import org.eclipse.debug.core.DebugException;
/*     */ import org.eclipse.debug.core.DebugPlugin;
/*     */ import org.eclipse.debug.core.ILaunch;
/*     */ import org.eclipse.debug.core.ILaunchConfiguration;
/*     */ import org.eclipse.debug.core.ILaunchesListener;
/*     */ import org.eclipse.debug.core.ILaunchesListener2;
/*     */ import org.eclipse.debug.core.Launch;
/*     */ import org.eclipse.debug.core.model.IProcess;
/*     */ import org.eclipse.debug.internal.core.DebugCoreMessages;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class GroupLaunch
/*     */   extends Launch
/*     */   implements ILaunchesListener2
/*     */ {
/*     */   private boolean fTerminated;
/*     */   private boolean fLaunched = false;
/*  55 */   private Map<ILaunch, IProcess[]> subLaunches = (Map)new HashMap<>();
/*     */   
/*     */   public GroupLaunch(ILaunchConfiguration launchConfiguration, String mode) {
/*  58 */     super(launchConfiguration, mode, null);
/*  59 */     getLaunchManager().addLaunchListener((ILaunchesListener)this);
/*     */   }
/*     */   
/*     */   public void markLaunched() {
/*  63 */     this.fLaunched = true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addSubLaunch(ILaunch subLaunch) {
/*  72 */     synchronized (this.subLaunches) {
/*  73 */       this.subLaunches.put(subLaunch, new IProcess[0]);
/*     */     } 
/*     */   }
/*     */   
/*     */   private boolean isChild(ILaunch launch) {
/*  78 */     synchronized (this.subLaunches) {
/*  79 */       for (ILaunch subLaunch : this.subLaunches.keySet()) {
/*  80 */         if (subLaunch == launch) {
/*  81 */           return true;
/*     */         }
/*     */       } 
/*  84 */       return false;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isTerminated() {
/*  96 */     if (this.fTerminated) {
/*  97 */       return true;
/*     */     }
/*     */     
/* 100 */     synchronized (this.subLaunches) {
/* 101 */       if (this.subLaunches.isEmpty()) {
/* 102 */         return this.fLaunched;
/*     */       }
/*     */ 
/*     */       
/* 106 */       for (ILaunch launch : this.subLaunches.keySet()) {
/* 107 */         if (!launch.isTerminated()) {
/* 108 */           return false;
/*     */         }
/*     */       } 
/*     */     } 
/* 112 */     return this.fLaunched;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean canTerminate() {
/* 125 */     synchronized (this.subLaunches) {
/* 126 */       if (this.subLaunches.isEmpty()) {
/* 127 */         return false;
/*     */       }
/*     */       
/* 130 */       for (ILaunch launch : this.subLaunches.keySet()) {
/* 131 */         if (launch.canTerminate()) {
/* 132 */           return true;
/*     */         }
/*     */       } 
/* 135 */       return false;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void terminate() throws DebugException {
/* 146 */     MultiStatus status = new MultiStatus(DebugPlugin.getUniqueIdentifier(), 5012, DebugCoreMessages.Launch_terminate_failed, null);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 151 */     markLaunched();
/*     */     
/* 153 */     synchronized (this.subLaunches) {
/* 154 */       for (ILaunch launch : this.subLaunches.keySet()) {
/* 155 */         if (launch.canTerminate()) {
/*     */           try {
/* 157 */             launch.terminate();
/* 158 */           } catch (DebugException e) {
/* 159 */             status.merge(e.getStatus());
/*     */           } 
/*     */         }
/*     */       } 
/*     */     } 
/*     */     
/* 165 */     if (status.isOK()) {
/*     */       return;
/*     */     }
/*     */     
/* 169 */     IStatus[] children = status.getChildren();
/* 170 */     if (children.length == 1) {
/* 171 */       throw new DebugException(children[0]);
/*     */     }
/*     */     
/* 174 */     throw new DebugException(status);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void launchTerminated(ILaunch launch) {
/* 183 */     if (this == launch) {
/*     */       return;
/*     */     }
/*     */     
/* 187 */     synchronized (this.subLaunches) {
/*     */ 
/*     */ 
/*     */       
/* 191 */       if (this.subLaunches.remove(launch) != null)
/*     */       {
/* 193 */         if (this.subLaunches.isEmpty() && this.fLaunched) {
/* 194 */           this.fTerminated = true;
/* 195 */           fireTerminate();
/*     */         } 
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void launchChanged(ILaunch launch) {
/* 203 */     if (this == launch) {
/*     */       return;
/*     */     }
/*     */     
/* 207 */     synchronized (this.subLaunches) {
/*     */       
/* 209 */       if (isChild(launch)) {
/*     */         
/* 211 */         IProcess[] oldProcesses = this.subLaunches.get(launch);
/* 212 */         IProcess[] newProcesses = launch.getProcesses();
/*     */ 
/*     */         
/* 215 */         if (!Arrays.equals((Object[])oldProcesses, (Object[])newProcesses)) {
/* 216 */           byte b; int i; IProcess[] arrayOfIProcess; for (i = (arrayOfIProcess = oldProcesses).length, b = 0; b < i; ) { IProcess oldProcess = arrayOfIProcess[b];
/* 217 */             removeProcess(oldProcess);
/*     */             
/*     */             b++; }
/*     */           
/* 221 */           for (i = (arrayOfIProcess = newProcesses).length, b = 0; b < i; ) { IProcess newProcess = arrayOfIProcess[b];
/* 222 */             addProcess(newProcess);
/*     */             
/*     */             b++; }
/*     */           
/* 226 */           this.subLaunches.put(launch, newProcesses);
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void launchRemoved(ILaunch launch) {
/* 234 */     if (this == launch) {
/* 235 */       super.launchRemoved(launch);
/*     */ 
/*     */       
/* 238 */       IProcess[] processes = getProcesses(); byte b; int i; IProcess[] arrayOfIProcess1;
/* 239 */       for (i = (arrayOfIProcess1 = processes).length, b = 0; b < i; ) { IProcess process = arrayOfIProcess1[b];
/* 240 */         removeProcess(process);
/*     */         b++; }
/*     */       
/* 243 */       getLaunchManager().removeLaunchListener((ILaunchesListener)this);
/*     */     } 
/*     */   }
/*     */   public void launchesTerminated(ILaunch[] launches) { byte b;
/*     */     int i;
/*     */     ILaunch[] arrayOfILaunch;
/* 249 */     for (i = (arrayOfILaunch = launches).length, b = 0; b < i; ) { ILaunch launch = arrayOfILaunch[b];
/* 250 */       launchTerminated(launch);
/*     */       b++; }
/*     */      }
/*     */   public void launchesAdded(ILaunch[] launches) { byte b;
/*     */     int i;
/*     */     ILaunch[] arrayOfILaunch;
/* 256 */     for (i = (arrayOfILaunch = launches).length, b = 0; b < i; ) { ILaunch launch = arrayOfILaunch[b];
/* 257 */       launchAdded(launch);
/*     */       b++; }
/*     */      }
/*     */   public void launchesChanged(ILaunch[] launches) { byte b;
/*     */     int i;
/*     */     ILaunch[] arrayOfILaunch;
/* 263 */     for (i = (arrayOfILaunch = launches).length, b = 0; b < i; ) { ILaunch launch = arrayOfILaunch[b];
/* 264 */       launchChanged(launch);
/*     */       b++; }
/*     */      } public void launchesRemoved(ILaunch[] launches) {
/*     */     byte b;
/*     */     int i;
/*     */     ILaunch[] arrayOfILaunch;
/* 270 */     for (i = (arrayOfILaunch = launches).length, b = 0; b < i; ) { ILaunch launch = arrayOfILaunch[b];
/* 271 */       launchRemoved(launch);
/*     */       b++; }
/*     */   
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.debug.core-3.21.0.jar!\org\eclipse\debug\internal\core\groups\GroupLaunch.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */