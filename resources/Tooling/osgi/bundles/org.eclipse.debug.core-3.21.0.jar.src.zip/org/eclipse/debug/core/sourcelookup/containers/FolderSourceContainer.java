/*    */ package org.eclipse.debug.core.sourcelookup.containers;
/*    */ 
/*    */ import org.eclipse.core.resources.IContainer;
/*    */ import org.eclipse.debug.core.DebugPlugin;
/*    */ import org.eclipse.debug.core.sourcelookup.ISourceContainerType;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FolderSourceContainer
/*    */   extends ContainerSourceContainer
/*    */ {
/* 34 */   public static final String TYPE_ID = String.valueOf(DebugPlugin.getUniqueIdentifier()) + ".containerType.folder";
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public FolderSourceContainer(IContainer folder, boolean subfolders) {
/* 44 */     super(folder, subfolders);
/*    */   }
/*    */ 
/*    */   
/*    */   public ISourceContainerType getType() {
/* 49 */     return getSourceContainerType(TYPE_ID);
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.debug.core-3.21.0.jar!\org\eclipse\debug\core\sourcelookup\containers\FolderSourceContainer.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */