/*    */ package org.eclipse.debug.internal.core.variables;
/*    */ 
/*    */ import org.eclipse.osgi.util.NLS;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Messages
/*    */   extends NLS
/*    */ {
/*    */   private static final String BUNDLE_NAME = "org.eclipse.debug.internal.core.variables.Messages";
/*    */   public static String DateTimeResolver_ProblemWithDateArgument;
/*    */   public static String ResourceResolver_0;
/*    */   public static String ResourceResolver_1;
/*    */   public static String ResourceResolver_2;
/*    */   public static String WorkspaceResolver_0;
/*    */   
/*    */   static {
/* 27 */     NLS.initializeMessages("org.eclipse.debug.internal.core.variables.Messages", Messages.class);
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.debug.core-3.21.0.jar!\org\eclipse\debug\internal\core\variables\Messages.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */