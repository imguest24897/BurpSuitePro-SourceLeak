/*     */ package org.eclipse.debug.core.sourcelookup.containers;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import org.eclipse.core.resources.IStorage;
/*     */ import org.eclipse.core.runtime.CoreException;
/*     */ import org.eclipse.core.runtime.IPath;
/*     */ import org.eclipse.core.runtime.Path;
/*     */ import org.eclipse.core.runtime.PlatformObject;
/*     */ import org.eclipse.core.runtime.Status;
/*     */ import org.eclipse.debug.core.DebugPlugin;
/*     */ import org.eclipse.debug.internal.core.sourcelookup.SourceLookupMessages;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LocalFileStorage
/*     */   extends PlatformObject
/*     */   implements IStorage
/*     */ {
/*     */   private File fFile;
/*     */   
/*     */   public LocalFileStorage(File file) {
/*  54 */     setFile(file);
/*     */   }
/*     */ 
/*     */   
/*     */   public InputStream getContents() throws CoreException {
/*     */     try {
/*  60 */       return new FileInputStream(getFile());
/*  61 */     } catch (IOException e) {
/*  62 */       throw new CoreException(new Status(4, DebugPlugin.getUniqueIdentifier(), 125, SourceLookupMessages.LocalFileStorage_0, e));
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public IPath getFullPath() {
/*     */     try {
/*  69 */       return (IPath)new Path(getFile().getCanonicalPath());
/*  70 */     } catch (IOException e) {
/*  71 */       DebugPlugin.log(e);
/*  72 */       return null;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public String getName() {
/*  78 */     return getFile().getName();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isReadOnly() {
/*  83 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void setFile(File file) {
/*  92 */     this.fFile = file;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public File getFile() {
/* 101 */     return this.fFile;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object object) {
/* 106 */     return (object instanceof LocalFileStorage && 
/* 107 */       getFile().equals(((LocalFileStorage)object).getFile()));
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 112 */     return getFile().hashCode();
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.debug.core-3.21.0.jar!\org\eclipse\debug\core\sourcelookup\containers\LocalFileStorage.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */