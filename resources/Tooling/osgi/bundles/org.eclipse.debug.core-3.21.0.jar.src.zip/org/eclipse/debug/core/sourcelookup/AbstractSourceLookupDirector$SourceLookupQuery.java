/*     */ package org.eclipse.debug.core.sourcelookup;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.eclipse.core.runtime.CoreException;
/*     */ import org.eclipse.core.runtime.ISafeRunnable;
/*     */ import org.eclipse.core.runtime.IStatus;
/*     */ import org.eclipse.core.runtime.MultiStatus;
/*     */ import org.eclipse.debug.core.DebugPlugin;
/*     */ import org.eclipse.debug.internal.core.sourcelookup.SourceLookupMessages;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class SourceLookupQuery
/*     */   implements ISafeRunnable
/*     */ {
/* 106 */   private List<Object> fSourceElements = new ArrayList();
/* 107 */   private Object fElement = null;
/* 108 */   private Throwable fException = null;
/*     */   
/*     */   SourceLookupQuery(Object element) {
/* 111 */     this.fElement = element;
/*     */   }
/*     */ 
/*     */   
/*     */   public void handleException(Throwable exception) {
/* 116 */     this.fException = exception;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Throwable getException() {
/* 125 */     return this.fException;
/*     */   }
/*     */ 
/*     */   
/*     */   public void run() throws Exception {
/* 130 */     MultiStatus multiStatus = null;
/* 131 */     CoreException single = null;
/* 132 */     ISourceLookupParticipant[] participants = AbstractSourceLookupDirector.this.getParticipants(); try {
/*     */       byte b; int i; ISourceLookupParticipant[] arrayOfISourceLookupParticipant;
/* 134 */       for (i = (arrayOfISourceLookupParticipant = participants).length, b = 0; b < i; ) { ISourceLookupParticipant participant = arrayOfISourceLookupParticipant[b];
/* 135 */         AbstractSourceLookupDirector.this.setCurrentParticipant(participant);
/*     */         
/*     */         try {
/* 138 */           Object[] sourceArray = participant.findSourceElements(this.fElement);
/* 139 */           if (sourceArray != null && sourceArray.length > 0) {
/* 140 */             if (AbstractSourceLookupDirector.this.isFindDuplicates()) {
/* 141 */               byte b1; int j; Object[] arrayOfObject; for (j = (arrayOfObject = sourceArray).length, b1 = 0; b1 < j; ) { Object s = arrayOfObject[b1];
/* 142 */                 if (!AbstractSourceLookupDirector.this.checkDuplicate(s, this.fSourceElements))
/* 143 */                   this.fSourceElements.add(s); 
/*     */                 b1++; }
/*     */             
/*     */             } else {
/* 147 */               this.fSourceElements.add(sourceArray[0]);
/*     */               return;
/*     */             } 
/*     */           }
/* 151 */         } catch (CoreException e) {
/* 152 */           if (single == null) {
/* 153 */             single = e;
/* 154 */           } else if (multiStatus == null) {
/* 155 */             multiStatus = new MultiStatus(DebugPlugin.getUniqueIdentifier(), 125, new IStatus[] { single.getStatus() }, SourceLookupMessages.Source_Lookup_Error, null);
/* 156 */             multiStatus.add(e.getStatus());
/*     */           } else {
/* 158 */             multiStatus.add(e.getStatus());
/*     */           } 
/*     */         }  b++; }
/*     */     
/*     */     } finally {
/* 163 */       AbstractSourceLookupDirector.this.setCurrentParticipant(null);
/*     */     } 
/* 165 */     if (this.fSourceElements.isEmpty())
/*     */     {
/* 167 */       if (multiStatus != null) {
/* 168 */         this.fException = (Throwable)new CoreException((IStatus)multiStatus);
/* 169 */       } else if (single != null) {
/* 170 */         this.fException = (Throwable)single;
/*     */       } 
/*     */     }
/*     */   }
/*     */   
/*     */   public List<Object> getSourceElements() {
/* 176 */     return this.fSourceElements;
/*     */   }
/*     */   
/*     */   public void dispose() {
/* 180 */     this.fElement = null;
/* 181 */     this.fSourceElements = null;
/* 182 */     this.fException = null;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.debug.core-3.21.0.jar!\org\eclipse\debug\core\sourcelookup\AbstractSourceLookupDirector$SourceLookupQuery.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */