/*    */ package org.eclipse.debug.internal.core;
/*    */ 
/*    */ import org.eclipse.core.runtime.preferences.IEclipsePreferences;
/*    */ import org.eclipse.core.runtime.preferences.IPreferenceNodeVisitor;
/*    */ import org.eclipse.core.runtime.preferences.PreferenceModifyListener;
/*    */ import org.eclipse.debug.core.DebugPlugin;
/*    */ import org.eclipse.debug.core.ILaunchConfigurationType;
/*    */ import org.osgi.service.prefs.BackingStoreException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PreferredDelegateModifyListener
/*    */   extends PreferenceModifyListener
/*    */ {
/*    */   static class Visitor
/*    */     implements IPreferenceNodeVisitor
/*    */   {
/*    */     public boolean visit(IEclipsePreferences node) throws BackingStoreException {
/* 34 */       if (node.name().equals(DebugPlugin.getUniqueIdentifier())) {
/*    */         
/* 36 */         LaunchManager manager = (LaunchManager)DebugPlugin.getDefault().getLaunchManager();
/* 37 */         manager.resetPreferredDelegates();
/* 38 */         ILaunchConfigurationType[] types = manager.getLaunchConfigurationTypes(); byte b; int i; ILaunchConfigurationType[] arrayOfILaunchConfigurationType1;
/* 39 */         for (i = (arrayOfILaunchConfigurationType1 = types).length, b = 0; b < i; ) { ILaunchConfigurationType type = arrayOfILaunchConfigurationType1[b];
/* 40 */           ((LaunchConfigurationType)type).resetPreferredDelegates(); b++; }
/*    */         
/* 42 */         return false;
/*    */       } 
/* 44 */       return true;
/*    */     }
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public IEclipsePreferences preApply(IEclipsePreferences node) {
/*    */     try {
/* 53 */       node.accept(new Visitor());
/* 54 */     } catch (BackingStoreException e) {
/* 55 */       DebugPlugin.log((Throwable)e);
/*    */     } 
/* 57 */     return node;
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.debug.core-3.21.0.jar!\org\eclipse\debug\internal\core\PreferredDelegateModifyListener.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */