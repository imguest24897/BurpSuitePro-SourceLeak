/*     */ package org.eclipse.debug.core.model;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MemoryByte
/*     */ {
/*     */   public static final byte WRITABLE = 1;
/*     */   public static final byte READABLE = 2;
/*     */   public static final byte CHANGED = 4;
/*     */   public static final byte HISTORY_KNOWN = 8;
/*     */   public static final byte BIG_ENDIAN = 16;
/*     */   public static final byte ENDIANESS_KNOWN = 32;
/*     */   protected byte value;
/*     */   protected byte flags;
/*     */   
/*     */   public MemoryByte() {
/*  91 */     this((byte)0, (byte)35);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MemoryByte(byte byteValue) {
/* 103 */     this(byteValue, (byte)35);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MemoryByte(byte byteValue, byte byteFlags) {
/* 113 */     this.value = byteValue;
/* 114 */     this.flags = byteFlags;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte getFlags() {
/* 123 */     return this.flags;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setFlags(byte flags) {
/* 131 */     this.flags = flags;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte getValue() {
/* 140 */     return this.value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setValue(byte value) {
/* 149 */     this.value = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setReadable(boolean readable) {
/* 160 */     this.flags = (byte)(this.flags | 0x2);
/* 161 */     if (!readable) {
/* 162 */       this.flags = (byte)(this.flags ^ 0x2);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isReadable() {
/* 173 */     return ((this.flags & 0x2) == 2);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setWritable(boolean writable) {
/* 182 */     this.flags = (byte)(this.flags | 0x1);
/* 183 */     if (!writable) {
/* 184 */       this.flags = (byte)(this.flags ^ 0x1);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isWritable() {
/* 193 */     return ((this.flags & 0x1) == 1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setChanged(boolean changed) {
/* 202 */     this.flags = (byte)(this.flags | 0x4);
/* 203 */     if (!changed) {
/* 204 */       this.flags = (byte)(this.flags ^ 0x4);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isChanged() {
/* 213 */     return ((this.flags & 0x4) == 4);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setHistoryKnown(boolean known) {
/* 223 */     this.flags = (byte)(this.flags | 0x8);
/* 224 */     if (!known) {
/* 225 */       this.flags = (byte)(this.flags ^ 0x8);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isHistoryKnown() {
/* 235 */     return ((this.flags & 0x8) == 8);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setBigEndian(boolean isBigEndian) {
/* 245 */     this.flags = (byte)(this.flags | 0x10);
/* 246 */     if (!isBigEndian) {
/* 247 */       this.flags = (byte)(this.flags ^ 0x10);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isBigEndian() {
/* 257 */     return ((this.flags & 0x10) == 16);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setEndianessKnown(boolean isEndianessKnown) {
/* 269 */     this.flags = (byte)(this.flags | 0x20);
/* 270 */     if (!isEndianessKnown) {
/* 271 */       this.flags = (byte)(this.flags ^ 0x20);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isEndianessKnown() {
/* 283 */     return ((this.flags & 0x20) == 32);
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.debug.core-3.21.0.jar!\org\eclipse\debug\core\model\MemoryByte.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */