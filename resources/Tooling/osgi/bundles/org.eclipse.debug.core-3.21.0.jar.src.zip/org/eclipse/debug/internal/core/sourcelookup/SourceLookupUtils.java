/*     */ package org.eclipse.debug.internal.core.sourcelookup;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.HashMap;
/*     */ import java.util.zip.ZipFile;
/*     */ import org.eclipse.core.resources.IResourceChangeEvent;
/*     */ import org.eclipse.core.resources.IResourceChangeListener;
/*     */ import org.eclipse.core.resources.ResourcesPlugin;
/*     */ import org.eclipse.debug.core.DebugPlugin;
/*     */ import org.eclipse.debug.core.ILaunch;
/*     */ import org.eclipse.debug.core.ILaunchesListener;
/*     */ import org.eclipse.debug.core.ILaunchesListener2;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SourceLookupUtils
/*     */ {
/*  43 */   private static HashMap<String, ZipFile> fgZipFileCache = new HashMap<>(5);
/*  44 */   private static ArchiveCleaner fgCleaner = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ZipFile getZipFile(String name) throws IOException {
/*  56 */     synchronized (fgZipFileCache) {
/*  57 */       if (fgCleaner == null) {
/*  58 */         fgCleaner = new ArchiveCleaner();
/*  59 */         DebugPlugin.getDefault().getLaunchManager().addLaunchListener((ILaunchesListener)fgCleaner);
/*  60 */         ResourcesPlugin.getWorkspace().addResourceChangeListener(fgCleaner, 6);
/*     */       } 
/*  62 */       ZipFile zip = fgZipFileCache.get(name);
/*  63 */       if (zip == null) {
/*  64 */         zip = new ZipFile(name);
/*  65 */         fgZipFileCache.put(name, zip);
/*     */       } 
/*  67 */       return zip;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void closeArchives() {
/*  78 */     synchronized (fgZipFileCache) {
/*  79 */       for (ZipFile file : fgZipFileCache.values()) {
/*  80 */         synchronized (file) {
/*     */           try {
/*  82 */             file.close();
/*  83 */           } catch (IOException e) {
/*  84 */             DebugPlugin.log(e);
/*     */           } 
/*     */         } 
/*     */       } 
/*  88 */       fgZipFileCache.clear();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void shutdown() {
/*  96 */     closeArchives();
/*  97 */     if (fgCleaner != null) {
/*  98 */       DebugPlugin.getDefault().getLaunchManager().removeLaunchListener((ILaunchesListener)fgCleaner);
/*  99 */       ResourcesPlugin.getWorkspace().removeResourceChangeListener(fgCleaner);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   static class ArchiveCleaner
/*     */     implements IResourceChangeListener, ILaunchesListener2
/*     */   {
/*     */     public void launchesRemoved(ILaunch[] launches) {
/*     */       byte b;
/*     */       int i;
/*     */       ILaunch[] arrayOfILaunch;
/* 111 */       for (i = (arrayOfILaunch = launches).length, b = 0; b < i; ) { ILaunch launch = arrayOfILaunch[b];
/* 112 */         if (!launch.isTerminated()) {
/* 113 */           SourceLookupUtils.closeArchives();
/*     */           return;
/*     */         } 
/*     */         b++; }
/*     */     
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void launchesAdded(ILaunch[] launches) {}
/*     */ 
/*     */     
/*     */     public void launchesChanged(ILaunch[] launches) {}
/*     */ 
/*     */     
/*     */     public void resourceChanged(IResourceChangeEvent event) {
/* 129 */       SourceLookupUtils.closeArchives();
/*     */     }
/*     */ 
/*     */     
/*     */     public void launchesTerminated(ILaunch[] launches) {
/* 134 */       SourceLookupUtils.closeArchives();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.debug.core-3.21.0.jar!\org\eclipse\debug\internal\core\sourcelookup\SourceLookupUtils.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */