/*     */ package org.eclipse.debug.internal.core;
/*     */ 
/*     */ import java.text.MessageFormat;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.Hashtable;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import org.eclipse.core.resources.IContainer;
/*     */ import org.eclipse.core.runtime.CoreException;
/*     */ import org.eclipse.core.runtime.IConfigurationElement;
/*     */ import org.eclipse.core.runtime.IStatus;
/*     */ import org.eclipse.core.runtime.Path;
/*     */ import org.eclipse.core.runtime.PlatformObject;
/*     */ import org.eclipse.core.runtime.Status;
/*     */ import org.eclipse.debug.core.DebugPlugin;
/*     */ import org.eclipse.debug.core.ILaunchConfiguration;
/*     */ import org.eclipse.debug.core.ILaunchConfigurationMigrationDelegate;
/*     */ import org.eclipse.debug.core.ILaunchConfigurationType;
/*     */ import org.eclipse.debug.core.ILaunchConfigurationWorkingCopy;
/*     */ import org.eclipse.debug.core.ILaunchDelegate;
/*     */ import org.eclipse.debug.core.ILaunchMode;
/*     */ import org.eclipse.debug.core.model.ILaunchConfigurationDelegate;
/*     */ import org.eclipse.debug.core.sourcelookup.ISourcePathComputer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LaunchConfigurationType
/*     */   extends PlatformObject
/*     */   implements ILaunchConfigurationType
/*     */ {
/*     */   private IConfigurationElement fElement;
/*  63 */   private Set<String> fModes = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  70 */   private Set<Set<String>> fModeCombinations = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  77 */   private ISourcePathComputer fSourcePathComputer = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  84 */   private ILaunchConfigurationMigrationDelegate fMigrationDelegate = null;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  89 */   private String fSourceLocator = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  97 */   private Map<Set<String>, Set<ILaunchDelegate>> fDelegates = null;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 102 */   private LaunchDelegate fSourceProvider = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 109 */   private Map<Set<String>, ILaunchDelegate> fPreferredDelegates = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected LaunchConfigurationType(IConfigurationElement element) {
/* 118 */     this.fElement = element;
/* 119 */     initializePreferredDelegates();
/*     */   }
/*     */ 
/*     */   
/*     */   public String getAttribute(String attributeName) {
/* 124 */     return this.fElement.getAttribute(attributeName);
/*     */   }
/*     */ 
/*     */   
/*     */   public String getCategory() {
/* 129 */     return this.fElement.getAttribute("category");
/*     */   }
/*     */ 
/*     */   
/*     */   public ILaunchConfigurationDelegate getDelegate() throws CoreException {
/* 134 */     return getDelegate("run");
/*     */   }
/*     */   
/*     */   public ILaunchConfigurationDelegate getDelegate(String mode) throws CoreException {
/*     */     Status status1;
/* 139 */     Set<String> modes = new HashSet<>();
/* 140 */     modes.add(mode);
/* 141 */     ILaunchDelegate[] delegates = getDelegates(modes);
/* 142 */     if (delegates.length > 0) {
/* 143 */       return delegates[0].getDelegate();
/*     */     }
/* 145 */     IStatus status = null;
/* 146 */     ILaunchMode launchMode = DebugPlugin.getDefault().getLaunchManager().getLaunchMode(mode);
/* 147 */     if (launchMode == null) {
/* 148 */       status1 = new Status(4, DebugPlugin.getUniqueIdentifier(), MessageFormat.format(DebugCoreMessages.LaunchConfigurationType_7, new Object[] { mode }));
/*     */     } else {
/* 150 */       status1 = new Status(4, DebugPlugin.getUniqueIdentifier(), MessageFormat.format(DebugCoreMessages.LaunchConfigurationType_7, new Object[] { ((LaunchManager)DebugPlugin.getDefault().getLaunchManager()).getLaunchModeName(mode) }));
/*     */     } 
/* 152 */     throw new CoreException(status1);
/*     */   }
/*     */ 
/*     */   
/*     */   public ILaunchDelegate[] getDelegates(Set<String> modes) throws CoreException {
/* 157 */     initializeDelegates();
/* 158 */     Set<ILaunchDelegate> delegates = this.fDelegates.get(modes);
/* 159 */     if (delegates == null) {
/* 160 */       delegates = Collections.EMPTY_SET;
/*     */     }
/* 162 */     return delegates.<ILaunchDelegate>toArray(new ILaunchDelegate[delegates.size()]);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setPreferredDelegate(Set<String> modes, ILaunchDelegate delegate) {
/* 167 */     if (this.fPreferredDelegates == null) {
/* 168 */       this.fPreferredDelegates = new HashMap<>();
/*     */     }
/* 170 */     if (delegate == null) {
/* 171 */       this.fPreferredDelegates.remove(modes);
/*     */     } else {
/* 173 */       this.fPreferredDelegates.put(modes, delegate);
/*     */     } 
/* 175 */     ((LaunchManager)DebugPlugin.getDefault().getLaunchManager()).persistPreferredLaunchDelegate(this);
/*     */   }
/*     */ 
/*     */   
/*     */   public ILaunchDelegate getPreferredDelegate(Set<String> modes) {
/* 180 */     initializePreferredDelegates();
/* 181 */     return this.fPreferredDelegates.get(modes);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<Set<String>, ILaunchDelegate> getPreferredDelegates() {
/* 197 */     initializePreferredDelegates();
/* 198 */     return this.fPreferredDelegates;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private synchronized void initializePreferredDelegates() {
/* 212 */     if (this.fPreferredDelegates == null) {
/* 213 */       this.fPreferredDelegates = new HashMap<>();
/* 214 */       initializeDelegates();
/* 215 */       LaunchManager lm = (LaunchManager)DebugPlugin.getDefault().getLaunchManager();
/* 216 */       ILaunchDelegate delegate = null;
/* 217 */       for (Set<String> modes : this.fDelegates.keySet()) {
/* 218 */         delegate = lm.getPreferredDelegate(getIdentifier(), modes);
/* 219 */         if (delegate != null) {
/* 220 */           this.fPreferredDelegates.put(modes, delegate);
/*     */         }
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private synchronized void initializeDelegates() {
/* 230 */     if (this.fDelegates == null) {
/*     */       
/* 232 */       this.fDelegates = new Hashtable<>();
/* 233 */       LaunchDelegate[] launchDelegates = getLaunchDelegateExtensions();
/* 234 */       LaunchDelegate delegate = null;
/* 235 */       List<Set<String>> modelist = null;
/* 236 */       Set<ILaunchDelegate> tmp = null; byte b; int i; LaunchDelegate[] arrayOfLaunchDelegate1;
/* 237 */       for (i = (arrayOfLaunchDelegate1 = launchDelegates).length, b = 0; b < i; ) { LaunchDelegate launchDelegate = arrayOfLaunchDelegate1[b];
/* 238 */         delegate = launchDelegate;
/* 239 */         modelist = delegate.getModes();
/* 240 */         for (Set<String> modes : modelist) {
/* 241 */           tmp = this.fDelegates.get(modes);
/* 242 */           if (tmp == null) {
/* 243 */             tmp = new HashSet<>();
/* 244 */             this.fDelegates.put(modes, tmp);
/*     */           } 
/* 246 */           tmp.add(delegate);
/*     */         } 
/*     */         b++; }
/*     */     
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private LaunchDelegate[] getLaunchDelegateExtensions() {
/* 258 */     return ((LaunchManager)DebugPlugin.getDefault().getLaunchManager()).getLaunchDelegates(getIdentifier());
/*     */   }
/*     */ 
/*     */   
/*     */   public String getIdentifier() {
/* 263 */     return this.fElement.getAttribute("id");
/*     */   }
/*     */ 
/*     */   
/*     */   public String getName() {
/* 268 */     return this.fElement.getAttribute("name");
/*     */   }
/*     */ 
/*     */   
/*     */   public String getPluginIdentifier() {
/* 273 */     return this.fElement.getContributor().getName();
/*     */   }
/*     */ 
/*     */   
/*     */   public String getSourceLocatorId() {
/* 278 */     if (this.fSourceLocator == null) {
/* 279 */       this.fSourceLocator = getAttribute("sourceLocatorId");
/*     */       
/* 281 */       if (this.fSourceProvider != null) {
/* 282 */         this.fSourceLocator = this.fSourceProvider.getSourceLocatorId();
/*     */       }
/*     */ 
/*     */       
/* 286 */       if (this.fSourceLocator == null) {
/* 287 */         LaunchDelegate[] delegates = getLaunchDelegateExtensions(); byte b; int i; LaunchDelegate[] arrayOfLaunchDelegate1;
/* 288 */         for (i = (arrayOfLaunchDelegate1 = delegates).length, b = 0; b < i; ) { LaunchDelegate delegate = arrayOfLaunchDelegate1[b];
/* 289 */           this.fSourceLocator = delegate.getSourceLocatorId();
/* 290 */           if (this.fSourceLocator != null) {
/* 291 */             this.fSourceProvider = delegate;
/* 292 */             return this.fSourceLocator;
/*     */           }  b++; }
/*     */         
/* 295 */         this.fSourceProvider = null;
/*     */       } 
/*     */     } 
/* 298 */     return this.fSourceLocator;
/*     */   }
/*     */ 
/*     */   
/*     */   public ISourcePathComputer getSourcePathComputer() {
/* 303 */     if (this.fSourcePathComputer == null) {
/*     */       
/* 305 */       String id = this.fElement.getAttribute("sourcePathComputerId");
/*     */       
/* 307 */       if (this.fSourceProvider != null) {
/* 308 */         id = this.fSourceProvider.getSourcePathComputerId();
/*     */       }
/* 310 */       if (id != null) {
/* 311 */         this.fSourcePathComputer = DebugPlugin.getDefault().getLaunchManager().getSourcePathComputer(id);
/*     */       
/*     */       }
/*     */       else {
/*     */         
/* 316 */         LaunchDelegate[] delegates = getLaunchDelegateExtensions(); byte b; int i; LaunchDelegate[] arrayOfLaunchDelegate1;
/* 317 */         for (i = (arrayOfLaunchDelegate1 = delegates).length, b = 0; b < i; ) { LaunchDelegate delegate = arrayOfLaunchDelegate1[b];
/* 318 */           id = delegate.getSourcePathComputerId();
/* 319 */           if (id != null) {
/* 320 */             this.fSourceProvider = delegate;
/* 321 */             this.fSourcePathComputer = DebugPlugin.getDefault().getLaunchManager().getSourcePathComputer(id);
/* 322 */             if (this.fSourcePathComputer != null)
/* 323 */               return this.fSourcePathComputer; 
/*     */           } 
/*     */           b++; }
/*     */         
/* 327 */         this.fSourceProvider = null;
/*     */       } 
/*     */     } 
/*     */     
/* 331 */     return this.fSourcePathComputer;
/*     */   }
/*     */ 
/*     */   
/*     */   public Set<String> getSupportedModes() {
/* 336 */     if (this.fModes == null) {
/* 337 */       this.fModes = new HashSet<>();
/* 338 */       LaunchDelegate[] delegates = getLaunchDelegateExtensions();
/* 339 */       List<Set<String>> modesets = null; byte b; int i; LaunchDelegate[] arrayOfLaunchDelegate1;
/* 340 */       for (i = (arrayOfLaunchDelegate1 = delegates).length, b = 0; b < i; ) { LaunchDelegate delegate = arrayOfLaunchDelegate1[b];
/* 341 */         modesets = delegate.getModes();
/* 342 */         for (Set<String> modes : modesets)
/* 343 */           this.fModes.addAll(modes); 
/*     */         b++; }
/*     */     
/*     */     } 
/* 347 */     return this.fModes;
/*     */   }
/*     */ 
/*     */   
/*     */   public Set<Set<String>> getSupportedModeCombinations() {
/* 352 */     if (this.fModeCombinations == null) {
/* 353 */       initializeDelegates();
/* 354 */       this.fModeCombinations = this.fDelegates.keySet();
/*     */     } 
/* 356 */     return Collections.unmodifiableSet(this.fModeCombinations);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isMigrationCandidate(ILaunchConfiguration candidate) throws CoreException {
/* 369 */     initializeMigrationDelegate();
/* 370 */     if (this.fMigrationDelegate != null) {
/* 371 */       return this.fMigrationDelegate.isCandidate(candidate);
/*     */     }
/* 373 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private synchronized void initializeMigrationDelegate() throws CoreException {
/* 381 */     if (this.fElement.getAttribute("migrationDelegate") != null && this.fMigrationDelegate == null) {
/* 382 */       this.fMigrationDelegate = (ILaunchConfigurationMigrationDelegate)this.fElement.createExecutableExtension("migrationDelegate");
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isPublic() {
/* 388 */     String publicString = this.fElement.getAttribute("public");
/* 389 */     if (publicString != null && 
/* 390 */       publicString.equalsIgnoreCase("false")) {
/* 391 */       return false;
/*     */     }
/*     */     
/* 394 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void migrate(ILaunchConfiguration candidate) throws CoreException {
/* 406 */     initializeMigrationDelegate();
/* 407 */     if (this.fMigrationDelegate != null) {
/* 408 */       this.fMigrationDelegate.migrate(candidate);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ILaunchConfigurationWorkingCopy newInstance(IContainer container, String name) throws CoreException {
/* 415 */     Path path = new Path(name);
/* 416 */     if (container == null)
/*     */     {
/* 418 */       if (path.segmentCount() > 1) {
/* 419 */         throw new CoreException(new Status(4, DebugPlugin.getUniqueIdentifier(), DebugCoreMessages.LaunchConfigurationType_2));
/*     */       }
/*     */     }
/*     */     
/*     */     try {
/* 424 */       DebugPlugin.getDefault().getLaunchManager().isValidLaunchConfigurationName(path.lastSegment());
/* 425 */     } catch (IllegalArgumentException e) {
/* 426 */       throw new CoreException(new Status(4, DebugPlugin.getUniqueIdentifier(), e.getMessage(), e));
/*     */     } 
/* 428 */     return new LaunchConfigurationWorkingCopy(container, name, this);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean supportsMode(String mode) {
/* 433 */     if (this.fModeCombinations == null) {
/* 434 */       getSupportedModeCombinations();
/*     */     }
/* 436 */     for (Set<String> modes : this.fModeCombinations) {
/* 437 */       if (modes.size() == 1 && modes.contains(mode)) {
/* 438 */         return true;
/*     */       }
/*     */     } 
/* 441 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getContributorName() {
/* 446 */     return this.fElement.getContributor().getName();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean supportsModeCombination(Set<String> modes) {
/* 451 */     if (this.fModeCombinations == null) {
/* 452 */       getSupportedModeCombinations();
/*     */     }
/* 454 */     return this.fModeCombinations.contains(modes);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void resetPreferredDelegates() {
/* 461 */     this.fPreferredDelegates = null;
/*     */   }
/*     */ 
/*     */   
/*     */   public ILaunchConfiguration[] getPrototypes() throws CoreException {
/* 466 */     return DebugPlugin.getDefault().getLaunchManager().getLaunchConfigurations(this, 2);
/*     */   }
/*     */ 
/*     */   
/*     */   public ILaunchConfigurationWorkingCopy newPrototypeInstance(IContainer container, String name) throws CoreException {
/* 471 */     LaunchConfigurationWorkingCopy wc = new LaunchConfigurationWorkingCopy(container, name, this, true);
/* 472 */     return wc;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean supportsPrototypes() {
/* 477 */     String allowPrototypesString = this.fElement.getAttribute("allowPrototypes");
/* 478 */     if (allowPrototypesString != null && 
/* 479 */       allowPrototypesString.equalsIgnoreCase("true")) {
/* 480 */       return true;
/*     */     }
/*     */     
/* 483 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean supportsCommandLine() {
/* 488 */     String allowPrototypesString = this.fElement.getAttribute("allowCommandLine");
/* 489 */     if (allowPrototypesString != null && 
/* 490 */       allowPrototypesString.equalsIgnoreCase("true")) {
/* 491 */       return true;
/*     */     }
/*     */     
/* 494 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean supportsOutputMerging() {
/* 499 */     String allowOutputMergingString = this.fElement.getAttribute("allowOutputMerging");
/* 500 */     if (allowOutputMergingString != null && 
/* 501 */       allowOutputMergingString.equalsIgnoreCase("true")) {
/* 502 */       return true;
/*     */     }
/*     */     
/* 505 */     return false;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.debug.core-3.21.0.jar!\org\eclipse\debug\internal\core\LaunchConfigurationType.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */