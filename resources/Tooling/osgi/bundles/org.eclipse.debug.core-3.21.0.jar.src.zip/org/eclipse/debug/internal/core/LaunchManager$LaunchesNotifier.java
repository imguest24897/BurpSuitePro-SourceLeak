/*     */ package org.eclipse.debug.internal.core;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.eclipse.core.runtime.ISafeRunnable;
/*     */ import org.eclipse.core.runtime.IStatus;
/*     */ import org.eclipse.core.runtime.SafeRunner;
/*     */ import org.eclipse.core.runtime.Status;
/*     */ import org.eclipse.debug.core.DebugPlugin;
/*     */ import org.eclipse.debug.core.ILaunch;
/*     */ import org.eclipse.debug.core.ILaunchesListener;
/*     */ import org.eclipse.debug.core.ILaunchesListener2;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class LaunchesNotifier
/*     */   implements ISafeRunnable
/*     */ {
/*     */   private ILaunchesListener fListener;
/*     */   private int fType;
/*     */   private ILaunch[] fNotifierLaunches;
/*     */   private ILaunch[] fRegistered;
/*     */   
/*     */   public void handleException(Throwable exception) {
/* 246 */     Status status = new Status(4, DebugPlugin.getUniqueIdentifier(), 120, "An exception occurred during launch change notification.", exception);
/* 247 */     DebugPlugin.log((IStatus)status);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void notify(ILaunch[] launches, int update) {
/* 257 */     this.fNotifierLaunches = launches;
/* 258 */     this.fType = update;
/* 259 */     this.fRegistered = null;
/* 260 */     for (ILaunchesListener iLaunchesListener : LaunchManager.this.fLaunchesListeners) {
/* 261 */       this.fListener = iLaunchesListener;
/* 262 */       SafeRunner.run(this);
/*     */     } 
/* 264 */     this.fNotifierLaunches = null;
/* 265 */     this.fRegistered = null;
/* 266 */     this.fListener = null;
/*     */   }
/*     */ 
/*     */   
/*     */   public void run() throws Exception {
/* 271 */     switch (this.fType) {
/*     */       case 0:
/* 273 */         this.fListener.launchesAdded(this.fNotifierLaunches);
/*     */         break;
/*     */       case 1:
/* 276 */         this.fListener.launchesRemoved(this.fNotifierLaunches);
/*     */         break;
/*     */       case 2:
/*     */       case 3:
/* 280 */         if (this.fRegistered == null) {
/* 281 */           List<ILaunch> registered = null;
/* 282 */           for (int j = 0; j < this.fNotifierLaunches.length; j++) {
/* 283 */             if (LaunchManager.this.isRegistered(this.fNotifierLaunches[j])) {
/* 284 */               if (registered != null) {
/* 285 */                 registered.add(this.fNotifierLaunches[j]);
/*     */               }
/* 287 */             } else if (registered == null) {
/* 288 */               registered = new ArrayList<>(this.fNotifierLaunches.length);
/* 289 */               for (int k = 0; k < j; k++) {
/* 290 */                 registered.add(this.fNotifierLaunches[k]);
/*     */               }
/*     */             } 
/*     */           } 
/* 294 */           if (registered == null) {
/* 295 */             this.fRegistered = this.fNotifierLaunches;
/*     */           } else {
/* 297 */             this.fRegistered = registered.<ILaunch>toArray(new ILaunch[registered.size()]);
/*     */           } 
/*     */         } 
/* 300 */         if (this.fRegistered.length > 0) {
/* 301 */           if (this.fType == 2) {
/* 302 */             this.fListener.launchesChanged(this.fRegistered);
/*     */           }
/* 304 */           if (this.fType == 3 && this.fListener instanceof ILaunchesListener2)
/* 305 */             ((ILaunchesListener2)this.fListener).launchesTerminated(this.fRegistered); 
/*     */         } 
/*     */         break;
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.debug.core-3.21.0.jar!\org\eclipse\debug\internal\core\LaunchManager$LaunchesNotifier.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */