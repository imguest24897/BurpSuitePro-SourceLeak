/*     */ package org.eclipse.debug.internal.core;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ import java.nio.charset.Charset;
/*     */ import java.util.Vector;
/*     */ import org.eclipse.debug.core.DebugPlugin;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class InputStreamMonitor
/*     */ {
/*     */   private OutputStream fStream;
/*     */   private Vector<byte[]> fQueue;
/*     */   private Thread fThread;
/*     */   private Object fLock;
/*     */   private boolean fClosed = false;
/*     */   private Charset fCharset;
/*     */   
/*     */   public InputStreamMonitor(OutputStream stream) {
/*  69 */     this(stream, (Charset)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public InputStreamMonitor(OutputStream stream, Charset charset) {
/*  80 */     this.fStream = stream;
/*  81 */     this.fQueue = (Vector)new Vector<>();
/*  82 */     this.fLock = new Object();
/*  83 */     this.fCharset = charset;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public InputStreamMonitor(OutputStream stream, String encoding) {
/*  97 */     this(stream, Charset.forName(encoding));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void write(String text) {
/* 107 */     synchronized (this.fLock) {
/* 108 */       this.fQueue.add((this.fCharset == null) ? text.getBytes() : text.getBytes(this.fCharset));
/* 109 */       this.fLock.notifyAll();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void write(byte[] data, int offset, int length) {
/* 122 */     synchronized (this.fLock) {
/* 123 */       byte[] copy = new byte[length];
/* 124 */       System.arraycopy(data, offset, copy, 0, length);
/* 125 */       this.fQueue.add(copy);
/* 126 */       this.fLock.notifyAll();
/*     */     } 
/*     */   }
/*     */   
/*     */   public void startMonitoring() {
/* 131 */     startMonitoring("Input Stream Monitor");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void startMonitoring(String threadName) {
/* 140 */     synchronized (this) {
/* 141 */       if (this.fThread == null) {
/* 142 */         this.fThread = new Thread(this::write, threadName);
/* 143 */         this.fThread.setDaemon(true);
/* 144 */         this.fThread.start();
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void close() {
/* 154 */     Thread thread = null;
/* 155 */     synchronized (this) {
/* 156 */       thread = this.fThread;
/* 157 */       this.fThread = null;
/*     */     } 
/* 159 */     if (thread != null) {
/* 160 */       thread.interrupt();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void write() {
/* 168 */     while (this.fThread != null) {
/* 169 */       writeNext();
/*     */     }
/* 171 */     if (!this.fClosed) {
/*     */       try {
/* 173 */         this.fStream.close();
/* 174 */       } catch (IOException e) {
/* 175 */         DebugPlugin.log(e);
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void writeNext() {
/* 184 */     while (!this.fQueue.isEmpty() && !this.fClosed) {
/* 185 */       byte[] data = this.fQueue.firstElement();
/* 186 */       this.fQueue.removeElementAt(0);
/*     */       try {
/* 188 */         this.fStream.write(data);
/* 189 */         this.fStream.flush();
/* 190 */       } catch (IOException e) {
/* 191 */         DebugPlugin.log(e);
/*     */       } 
/*     */     } 
/*     */     try {
/* 195 */       synchronized (this.fLock) {
/*     */ 
/*     */         
/* 198 */         if (this.fQueue.isEmpty()) {
/* 199 */           this.fLock.wait();
/*     */         }
/*     */       } 
/* 202 */     } catch (InterruptedException interruptedException) {}
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void closeInputStream() throws IOException {
/* 214 */     if (!this.fClosed) {
/* 215 */       this.fClosed = true;
/* 216 */       this.fStream.close();
/*     */     } else {
/* 218 */       throw new IOException();
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.debug.core-3.21.0.jar!\org\eclipse\debug\internal\core\InputStreamMonitor.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */