package org.eclipse.debug.core;

public interface IPrototypeAttributesLabelProvider {
  String getAttributeLabel(String paramString);
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.debug.core-3.21.0.jar!\org\eclipse\debug\core\IPrototypeAttributesLabelProvider.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */