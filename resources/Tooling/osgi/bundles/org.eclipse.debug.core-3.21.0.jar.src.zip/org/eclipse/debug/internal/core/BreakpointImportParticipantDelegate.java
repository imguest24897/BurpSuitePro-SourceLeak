/*    */ package org.eclipse.debug.internal.core;
/*    */ 
/*    */ import org.eclipse.core.runtime.CoreException;
/*    */ import org.eclipse.core.runtime.IConfigurationElement;
/*    */ import org.eclipse.debug.core.model.IBreakpointImportParticipant;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class BreakpointImportParticipantDelegate
/*    */ {
/* 45 */   private IConfigurationElement fElement = null;
/* 46 */   private IBreakpointImportParticipant fParticipant = null;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public BreakpointImportParticipantDelegate(IConfigurationElement element) {
/* 53 */     this.fElement = element;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public IBreakpointImportParticipant getDelegate() throws CoreException {
/* 64 */     if (this.fParticipant == null) {
/* 65 */       this.fParticipant = (IBreakpointImportParticipant)this.fElement.createExecutableExtension("participant");
/*    */     }
/* 67 */     return this.fParticipant;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String getType() throws CoreException {
/* 77 */     return this.fElement.getAttribute("type");
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.debug.core-3.21.0.jar!\org\eclipse\debug\internal\core\BreakpointImportParticipantDelegate.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */