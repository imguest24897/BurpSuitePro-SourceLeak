/*    */ package org.eclipse.debug.internal.core.groups.observer;
/*    */ 
/*    */ import java.util.regex.Matcher;
/*    */ import java.util.regex.Pattern;
/*    */ import org.eclipse.debug.core.IStreamListener;
/*    */ import org.eclipse.debug.core.model.IStreamMonitor;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class null
/*    */   implements IStreamListener
/*    */ {
/*    */   public void streamAppended(String text, IStreamMonitor monitor) {
/* 63 */     if (StreamObserver.this.countDownLatch.getCount() == 0L) {
/* 64 */       outputStreamMonitor.removeListener(this);
/*    */       
/*    */       return;
/*    */     } 
/* 68 */     Matcher matcher = pattern.matcher(text);
/* 69 */     if (!matcher.find() && !StreamObserver.this.pMonitor.isCanceled()) {
/*    */       return;
/*    */     }
/* 72 */     StreamObserver.this.countDownLatch.countDown();
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.debug.core-3.21.0.jar!\org\eclipse\debug\internal\core\groups\observer\StreamObserver$1.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */