package org.eclipse.debug.core.model;

import org.eclipse.core.runtime.CoreException;

public interface IWatchpoint extends IBreakpoint {
  boolean isAccess() throws CoreException;
  
  void setAccess(boolean paramBoolean) throws CoreException;
  
  boolean isModification() throws CoreException;
  
  void setModification(boolean paramBoolean) throws CoreException;
  
  boolean supportsAccess();
  
  boolean supportsModification();
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.debug.core-3.21.0.jar!\org\eclipse\debug\core\model\IWatchpoint.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */