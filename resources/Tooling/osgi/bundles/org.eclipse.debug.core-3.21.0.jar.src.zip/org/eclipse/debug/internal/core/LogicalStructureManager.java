/*     */ package org.eclipse.debug.internal.core;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.StringTokenizer;
/*     */ import org.eclipse.core.runtime.CoreException;
/*     */ import org.eclipse.core.runtime.IConfigurationElement;
/*     */ import org.eclipse.core.runtime.IExtensionPoint;
/*     */ import org.eclipse.core.runtime.Platform;
/*     */ import org.eclipse.debug.core.DebugPlugin;
/*     */ import org.eclipse.debug.core.ILogicalStructureType;
/*     */ import org.eclipse.debug.core.model.IValue;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LogicalStructureManager
/*     */ {
/*     */   private static LogicalStructureManager fgDefault;
/*  40 */   private List<LogicalStructureType> fTypes = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private List<LogicalStructureProvider> fTypeProviders;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  51 */   private Map<String, Integer> fStructureTypeSelections = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  58 */   private List<String> fStructureTypeIds = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final String PREF_STRUCTURE_SELECTIONS = "selectedStructures";
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final String PREF_STRUCTURE_IDS = "allStructures";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static LogicalStructureManager getDefault() {
/*  76 */     if (fgDefault == null) {
/*  77 */       fgDefault = new LogicalStructureManager();
/*     */     }
/*  79 */     return fgDefault;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ILogicalStructureType[] getLogicalStructureTypes(IValue value) {
/*  88 */     initialize();
/*     */     
/*  90 */     List<ILogicalStructureType> select = new ArrayList<>();
/*  91 */     for (ILogicalStructureType type : this.fTypes) {
/*  92 */       if (type.providesLogicalStructure(value)) {
/*  93 */         select.add(type);
/*     */       }
/*     */     } 
/*     */     
/*  97 */     for (LogicalStructureProvider provider : this.fTypeProviders) {
/*  98 */       ILogicalStructureType[] types = provider.getLogicalStructures(value);
/*  99 */       Collections.addAll(select, types);
/*     */     } 
/* 101 */     return select.<ILogicalStructureType>toArray(new ILogicalStructureType[select.size()]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void loadStructureTypeSelections() {
/* 108 */     this.fStructureTypeSelections = new HashMap<>();
/* 109 */     String selections = Platform.getPreferencesService().getString(DebugPlugin.getUniqueIdentifier(), "selectedStructures", "", null);
/*     */ 
/*     */     
/* 112 */     StringTokenizer tokenizer = new StringTokenizer(selections, "|");
/* 113 */     while (tokenizer.hasMoreTokens()) {
/* 114 */       String selection = tokenizer.nextToken();
/*     */ 
/*     */       
/* 117 */       int i = selection.lastIndexOf(',');
/* 118 */       if (i > 0 && i < selection.length() - 1) {
/* 119 */         String comboKey = selection.substring(0, i + 1);
/* 120 */         String selected = selection.substring(i + 1, selection.length());
/* 121 */         this.fStructureTypeSelections.put(comboKey, Integer.valueOf(Integer.parseInt(selected)));
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void storeStructureTypeSelections() {
/* 130 */     StringBuilder buffer = new StringBuilder();
/* 131 */     for (Map.Entry<String, Integer> entry : this.fStructureTypeSelections.entrySet()) {
/* 132 */       buffer.append(entry.getKey());
/* 133 */       buffer.append(entry.getValue());
/* 134 */       buffer.append('|');
/*     */     } 
/* 136 */     Preferences.setString(DebugPlugin.getUniqueIdentifier(), "selectedStructures", buffer.toString(), null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void loadStructureTypeIds() {
/* 143 */     this.fStructureTypeIds = new ArrayList<>();
/*     */     
/* 145 */     String types = Platform.getPreferencesService().getString(DebugPlugin.getUniqueIdentifier(), "allStructures", "", null);
/* 146 */     StringTokenizer tokenizer = new StringTokenizer(types, ",");
/* 147 */     while (tokenizer.hasMoreTokens()) {
/* 148 */       String id = tokenizer.nextToken();
/* 149 */       if (id.length() > 0) {
/* 150 */         this.fStructureTypeIds.add(id);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void storeStructureTypeIds() {
/* 159 */     StringBuilder buffer = new StringBuilder();
/* 160 */     for (String id : this.fStructureTypeIds) {
/* 161 */       buffer.append(id).append(',');
/*     */     }
/* 163 */     Preferences.setString(DebugPlugin.getUniqueIdentifier(), "allStructures", buffer.toString(), null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ILogicalStructureType getSelectedStructureType(ILogicalStructureType[] structureTypes) {
/* 175 */     if (structureTypes.length == 0) {
/* 176 */       return null;
/*     */     }
/* 178 */     String combo = getComboString(structureTypes);
/*     */     
/* 180 */     Integer index = this.fStructureTypeSelections.get(combo);
/* 181 */     if (index == null)
/*     */     {
/*     */       
/* 184 */       return structureTypes[0]; } 
/* 185 */     if (index.intValue() == -1)
/*     */     {
/* 187 */       return null;
/*     */     }
/*     */     
/* 190 */     String id = this.fStructureTypeIds.get(index.intValue()); byte b; int i; ILogicalStructureType[] arrayOfILogicalStructureType;
/* 191 */     for (i = (arrayOfILogicalStructureType = structureTypes).length, b = 0; b < i; ) { ILogicalStructureType type = arrayOfILogicalStructureType[b];
/* 192 */       if (type.getId().equals(id))
/*     */       {
/* 194 */         return type; } 
/*     */       b++; }
/*     */     
/* 197 */     return structureTypes[0];
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setEnabledType(ILogicalStructureType[] types, ILogicalStructureType selected) {
/* 207 */     String combo = getComboString(types);
/* 208 */     int index = -1;
/* 209 */     if (selected != null) {
/* 210 */       index = this.fStructureTypeIds.indexOf(selected.getId());
/*     */     }
/* 212 */     Integer integer = Integer.valueOf(index);
/* 213 */     this.fStructureTypeSelections.put(combo, integer);
/* 214 */     storeStructureTypeSelections();
/* 215 */     storeStructureTypeIds();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String getComboString(ILogicalStructureType[] types) {
/* 229 */     StringBuilder comboKey = new StringBuilder(); byte b; int i; ILogicalStructureType[] arrayOfILogicalStructureType;
/* 230 */     for (i = (arrayOfILogicalStructureType = types).length, b = 0; b < i; ) { ILogicalStructureType type = arrayOfILogicalStructureType[b];
/* 231 */       int typeIndex = this.fStructureTypeIds.indexOf(type.getId());
/* 232 */       if (typeIndex == -1) {
/* 233 */         typeIndex = this.fStructureTypeIds.size();
/* 234 */         this.fStructureTypeIds.add(type.getId());
/*     */       } 
/* 236 */       comboKey.append(typeIndex).append(','); b++; }
/*     */     
/* 238 */     return comboKey.toString();
/*     */   }
/*     */   
/*     */   private synchronized void initialize() {
/* 242 */     if (this.fTypes == null) {
/*     */       
/* 244 */       IExtensionPoint point = Platform.getExtensionRegistry().getExtensionPoint(DebugPlugin.getUniqueIdentifier(), "logicalStructureTypes");
/* 245 */       IConfigurationElement[] extensions = point.getConfigurationElements();
/* 246 */       this.fTypes = new ArrayList<>(extensions.length); byte b; int i; IConfigurationElement[] arrayOfIConfigurationElement1;
/* 247 */       for (i = (arrayOfIConfigurationElement1 = extensions).length, b = 0; b < i; ) { IConfigurationElement extension = arrayOfIConfigurationElement1[b];
/*     */         
/*     */         try {
/* 250 */           LogicalStructureType type = new LogicalStructureType(extension);
/* 251 */           this.fTypes.add(type);
/* 252 */         } catch (CoreException e) {
/* 253 */           DebugPlugin.log((Throwable)e);
/*     */         } 
/*     */         b++; }
/*     */       
/* 257 */       point = Platform.getExtensionRegistry().getExtensionPoint(DebugPlugin.getUniqueIdentifier(), "logicalStructureProviders");
/* 258 */       extensions = point.getConfigurationElements();
/* 259 */       this.fTypeProviders = new ArrayList<>(extensions.length);
/* 260 */       for (i = (arrayOfIConfigurationElement1 = extensions).length, b = 0; b < i; ) { IConfigurationElement extension = arrayOfIConfigurationElement1[b];
/*     */         try {
/* 262 */           this.fTypeProviders.add(new LogicalStructureProvider(extension));
/* 263 */         } catch (CoreException e) {
/* 264 */           DebugPlugin.log((Throwable)e);
/*     */         }  b++; }
/*     */     
/*     */     } 
/* 268 */     if (this.fStructureTypeSelections == null) {
/* 269 */       loadStructureTypeSelections();
/*     */     }
/* 271 */     if (this.fStructureTypeIds == null)
/* 272 */       loadStructureTypeIds(); 
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.debug.core-3.21.0.jar!\org\eclipse\debug\internal\core\LogicalStructureManager.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */