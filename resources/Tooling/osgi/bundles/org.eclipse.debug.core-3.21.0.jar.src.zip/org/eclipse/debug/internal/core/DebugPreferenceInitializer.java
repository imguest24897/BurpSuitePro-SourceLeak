/*    */ package org.eclipse.debug.internal.core;
/*    */ 
/*    */ import org.eclipse.core.runtime.preferences.AbstractPreferenceInitializer;
/*    */ import org.eclipse.debug.core.DebugPlugin;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DebugPreferenceInitializer
/*    */   extends AbstractPreferenceInitializer
/*    */ {
/*    */   public void initializeDefaultPreferences() {
/* 29 */     Preferences.setDefaultBoolean(DebugPlugin.getUniqueIdentifier(), StepFilterManager.PREF_USE_STEP_FILTERS, false);
/*    */     
/* 31 */     Preferences.setDefaultBoolean(DebugPlugin.getUniqueIdentifier(), "org.eclipse.debug.core.PREF_DELETE_CONFIGS_ON_PROJECT_DELETE", false);
/* 32 */     Preferences.setDefaultBoolean(DebugPlugin.getUniqueIdentifier(), IInternalDebugCoreConstants.PREF_ENABLE_STATUS_HANDLERS, true);
/* 33 */     Preferences.setDefaultBoolean(DebugPlugin.getUniqueIdentifier(), IInternalDebugCoreConstants.PREF_BREAKPOINT_MANAGER_ENABLED_STATE, true);
/* 34 */     Preferences.savePreferences(DebugPlugin.getUniqueIdentifier());
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.debug.core-3.21.0.jar!\org\eclipse\debug\internal\core\DebugPreferenceInitializer.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */