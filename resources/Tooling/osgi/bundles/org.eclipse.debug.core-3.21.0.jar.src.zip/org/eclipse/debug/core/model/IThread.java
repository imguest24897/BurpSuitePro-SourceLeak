package org.eclipse.debug.core.model;

import org.eclipse.debug.core.DebugException;

public interface IThread extends IDebugElement, ISuspendResume, IStep, ITerminate {
  IStackFrame[] getStackFrames() throws DebugException;
  
  boolean hasStackFrames() throws DebugException;
  
  int getPriority() throws DebugException;
  
  IStackFrame getTopStackFrame() throws DebugException;
  
  String getName() throws DebugException;
  
  IBreakpoint[] getBreakpoints();
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.debug.core-3.21.0.jar!\org\eclipse\debug\core\model\IThread.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */