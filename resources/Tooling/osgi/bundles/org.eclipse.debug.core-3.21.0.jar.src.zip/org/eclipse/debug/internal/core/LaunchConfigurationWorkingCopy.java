/*     */ package org.eclipse.debug.internal.core;
/*     */ 
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.IOException;
/*     */ import java.nio.charset.StandardCharsets;
/*     */ import java.text.MessageFormat;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Objects;
/*     */ import java.util.Set;
/*     */ import org.eclipse.core.filesystem.IFileStore;
/*     */ import org.eclipse.core.resources.IContainer;
/*     */ import org.eclipse.core.resources.IFile;
/*     */ import org.eclipse.core.resources.IResource;
/*     */ import org.eclipse.core.resources.IWorkspaceRunnable;
/*     */ import org.eclipse.core.resources.ResourcesPlugin;
/*     */ import org.eclipse.core.runtime.CoreException;
/*     */ import org.eclipse.core.runtime.IPath;
/*     */ import org.eclipse.core.runtime.IProgressMonitor;
/*     */ import org.eclipse.core.runtime.IStatus;
/*     */ import org.eclipse.core.runtime.NullProgressMonitor;
/*     */ import org.eclipse.core.runtime.OperationCanceledException;
/*     */ import org.eclipse.core.runtime.Status;
/*     */ import org.eclipse.core.runtime.SubMonitor;
/*     */ import org.eclipse.debug.core.DebugException;
/*     */ import org.eclipse.debug.core.DebugPlugin;
/*     */ import org.eclipse.debug.core.ILaunchConfiguration;
/*     */ import org.eclipse.debug.core.ILaunchConfigurationType;
/*     */ import org.eclipse.debug.core.ILaunchConfigurationWorkingCopy;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LaunchConfigurationWorkingCopy
/*     */   extends LaunchConfiguration
/*     */   implements ILaunchConfigurationWorkingCopy
/*     */ {
/*     */   private LaunchConfiguration fOriginal;
/*  67 */   private LaunchConfigurationWorkingCopy fParent = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private LaunchConfigurationInfo fInfo;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean fDirty;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean fRenamed;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean fSuppressChange;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected LaunchConfigurationWorkingCopy(LaunchConfiguration original) throws CoreException {
/* 100 */     super(original.getName(), original.getContainer(), original.isPrototype());
/* 101 */     copyFrom(original);
/* 102 */     setOriginal(original);
/* 103 */     this.fSuppressChange = false;
/*     */   }
/*     */ 
/*     */   
/*     */   protected void initialize() {
/* 108 */     this.fDirty = false;
/* 109 */     this.fRenamed = false;
/* 110 */     this.fSuppressChange = true;
/* 111 */     super.initialize();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected LaunchConfigurationWorkingCopy(LaunchConfigurationWorkingCopy parent) throws CoreException {
/* 123 */     super(parent.getName(), parent.getContainer(), parent.isPrototype());
/* 124 */     copyFrom(parent);
/* 125 */     setOriginal((LaunchConfiguration)parent.getOriginal());
/* 126 */     this.fParent = parent;
/* 127 */     this.fSuppressChange = false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected LaunchConfigurationWorkingCopy(LaunchConfiguration original, String name) throws CoreException {
/* 142 */     super(name, original.getContainer(), original.isPrototype());
/* 143 */     copyFrom(original);
/* 144 */     this.fSuppressChange = false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected LaunchConfigurationWorkingCopy(IContainer container, String name, ILaunchConfigurationType type) {
/* 157 */     this(container, name, type, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected LaunchConfigurationWorkingCopy(IContainer container, String name, ILaunchConfigurationType type, boolean prototype) {
/* 173 */     super(name, container, prototype);
/* 174 */     setInfo(new LaunchConfigurationInfo());
/* 175 */     getInfo().setType(type);
/* 176 */     getInfo().setIsPrototype(prototype);
/* 177 */     this.fSuppressChange = false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isDirty() {
/* 182 */     return this.fDirty;
/*     */   }
/*     */ 
/*     */   
/*     */   public synchronized ILaunchConfiguration doSave() throws CoreException {
/* 187 */     return doSave((IProgressMonitor)new NullProgressMonitor());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized ILaunchConfiguration doSave(IProgressMonitor monitor) throws CoreException {
/* 200 */     SubMonitor lmonitor = SubMonitor.convert(monitor, 1);
/*     */     
/* 202 */     try { if (getParent() != null) {
/*     */         
/* 204 */         LaunchConfigurationWorkingCopy wc = (LaunchConfigurationWorkingCopy)getParent();
/* 205 */         if (isMoved()) {
/* 206 */           wc.rename(getName());
/* 207 */           wc.setContainer(getContainer());
/*     */         } 
/* 209 */         wc.setAttributes(getInfo().getAttributes());
/* 210 */         updateMonitor((IProgressMonitor)lmonitor, 1);
/* 211 */         return wc;
/*     */       } 
/*     */       
/* 214 */       boolean useRunnable = true;
/* 215 */       if (isLocal()) {
/* 216 */         if (isMoved()) {
/*     */ 
/*     */           
/* 219 */           useRunnable = (!isNew() && !getOriginal().isLocal());
/*     */         } else {
/* 221 */           useRunnable = false;
/*     */         } 
/*     */       }
/* 224 */       if (useRunnable) {
/* 225 */         IWorkspaceRunnable wr = this::doSave0;
/* 226 */         ResourcesPlugin.getWorkspace().run(wr, null, 0, (IProgressMonitor)lmonitor.newChild(1));
/*     */       } else {
/*     */         
/* 229 */         doSave0((IProgressMonitor)lmonitor.newChild(1));
/*     */       }
/*     */        }
/*     */     
/*     */     finally
/*     */     
/* 235 */     { if (lmonitor != null)
/* 236 */         lmonitor.done();  }  if (lmonitor != null) lmonitor.done();
/*     */ 
/*     */     
/* 239 */     return new LaunchConfiguration(getName(), getContainer(), isPrototype());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void doSave0(IProgressMonitor monitor) throws CoreException {
/* 248 */     SubMonitor lmonitor = SubMonitor.convert(monitor, MessageFormat.format(DebugCoreMessages.LaunchConfigurationWorkingCopy_0, new Object[] { getName() }), 2);
/*     */     
/*     */     try {
/* 251 */       boolean moved = (!isNew() && isMoved());
/* 252 */       if (moved) {
/* 253 */         ILaunchConfiguration to = new LaunchConfiguration(getName(), getContainer(), isPrototype());
/* 254 */         ILaunchConfiguration from = getOriginal();
/* 255 */         getLaunchManager().setMovedFromTo(from, to);
/*     */       } 
/* 257 */       ILaunchConfiguration orig = getOriginal();
/* 258 */       updateMonitor((IProgressMonitor)lmonitor, 1);
/* 259 */       writeNewFile((IProgressMonitor)lmonitor.newChild(1));
/*     */ 
/*     */       
/* 262 */       if (moved) {
/* 263 */         orig.delete();
/*     */       }
/* 265 */       this.fDirty = false;
/*     */     } finally {
/*     */       
/* 268 */       if (lmonitor != null) {
/* 269 */         lmonitor.done();
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void writeNewFile(IProgressMonitor monitor) throws CoreException {
/* 281 */     String lineDelimeter = getLineSeparator();
/* 282 */     String xml = null;
/*     */     try {
/* 284 */       xml = getInfo().getAsXML(lineDelimeter);
/* 285 */     } catch (Exception e) {
/* 286 */       throw new DebugException(
/* 287 */           new Status(
/* 288 */             4, DebugPlugin.getUniqueIdentifier(), 
/* 289 */             5012, MessageFormat.format(DebugCoreMessages.LaunchConfigurationWorkingCopy__0__occurred_generating_launch_configuration_XML__1, new Object[] { e.toString() }), null));
/*     */     } 
/*     */ 
/*     */     
/* 293 */     SubMonitor lmonitor = SubMonitor.convert(monitor, "", 5);
/*     */     try {
/* 295 */       boolean added = false;
/* 296 */       if (isLocal()) {
/*     */         
/*     */         try {
/* 299 */           lmonitor.subTask(DebugCoreMessages.LaunchConfigurationWorkingCopy_1);
/* 300 */           IFileStore file = getFileStore();
/* 301 */           if (file == null) {
/* 302 */             throw new DebugException(
/* 303 */                 new Status(
/* 304 */                   4, DebugPlugin.getUniqueIdentifier(), 
/* 305 */                   5012, DebugCoreMessages.LaunchConfigurationWorkingCopy_4, null));
/*     */           }
/*     */ 
/*     */           
/* 309 */           IFileStore dir = file.getParent();
/* 310 */           dir.mkdir(4, null);
/* 311 */           if (!file.fetchInfo().exists()) {
/* 312 */             added = true;
/* 313 */             updateMonitor((IProgressMonitor)lmonitor, 1);
/*     */           } 
/* 315 */           Exception exception1 = null, exception2 = null;
/*     */ 
/*     */ 
/*     */         
/*     */         }
/* 320 */         catch (IOException ie) {
/* 321 */           lmonitor.done();
/* 322 */           throw new DebugException(
/* 323 */               new Status(
/* 324 */                 4, DebugPlugin.getUniqueIdentifier(), 
/* 325 */                 5012, MessageFormat.format(DebugCoreMessages.LaunchConfigurationWorkingCopy__0__occurred_generating_launch_configuration_XML__1, new Object[] { ie.toString() }), null));
/*     */         }
/*     */       
/*     */       }
/*     */       else {
/*     */         
/* 331 */         IFile file = getFile();
/* 332 */         if (file == null) {
/* 333 */           lmonitor.done();
/* 334 */           throw new DebugException(
/* 335 */               new Status(
/* 336 */                 4, DebugPlugin.getUniqueIdentifier(), 
/* 337 */                 5012, DebugCoreMessages.LaunchConfigurationWorkingCopy_5, null));
/*     */         } 
/*     */         
/* 340 */         IContainer dir = file.getParent();
/* 341 */         if (!dir.exists()) {
/* 342 */           lmonitor.done();
/* 343 */           throw new DebugException(
/* 344 */               new Status(
/* 345 */                 4, DebugPlugin.getUniqueIdentifier(), 
/* 346 */                 5012, DebugCoreMessages.LaunchConfigurationWorkingCopy_Specified_container_for_launch_configuration_does_not_exist_2, null));
/*     */         } 
/*     */ 
/*     */         
/* 350 */         ByteArrayInputStream stream = new ByteArrayInputStream(xml.getBytes(StandardCharsets.UTF_8));
/* 351 */         SubMonitor smonitor = null;
/* 352 */         if (!file.exists()) {
/* 353 */           added = true;
/*     */           
/* 355 */           smonitor = lmonitor.newChild(1);
/* 356 */           smonitor.setTaskName(MessageFormat.format(DebugCoreMessages.LaunchConfigurationWorkingCopy_2, new Object[] { getName() }));
/* 357 */           file.create(stream, false, (IProgressMonitor)smonitor);
/*     */         } else {
/*     */           
/* 360 */           if (file.isReadOnly()) {
/* 361 */             IStatus status = ResourcesPlugin.getWorkspace().validateEdit(new IFile[] { file }, null);
/* 362 */             if (!status.isOK()) {
/* 363 */               lmonitor.done();
/* 364 */               throw new CoreException(status);
/*     */             } 
/*     */           } 
/*     */           
/* 368 */           smonitor = lmonitor.newChild(1);
/* 369 */           smonitor.setTaskName(MessageFormat.format(DebugCoreMessages.LaunchConfigurationWorkingCopy_3, new Object[] { getName() }));
/* 370 */           file.setContents(stream, true, false, (IProgressMonitor)smonitor);
/*     */         } 
/*     */       } 
/*     */       
/* 374 */       if (added) {
/* 375 */         getLaunchManager().launchConfigurationAdded(new LaunchConfiguration(getName(), getContainer(), isPrototype()));
/*     */       } else {
/* 377 */         getLaunchManager().launchConfigurationChanged(new LaunchConfiguration(getName(), getContainer(), isPrototype()));
/*     */       } 
/*     */     } finally {
/*     */       
/* 381 */       if (lmonitor != null) {
/* 382 */         lmonitor.done();
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void updateMonitor(IProgressMonitor monitor, int ticks) throws OperationCanceledException {
/* 395 */     if (monitor != null) {
/* 396 */       monitor.worked(ticks);
/* 397 */       if (monitor.isCanceled()) {
/* 398 */         throw new OperationCanceledException();
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void setAttribute(String attributeName, int value) {
/* 405 */     getInfo().setAttribute(attributeName, Integer.valueOf(value));
/* 406 */     setDirty();
/*     */   }
/*     */ 
/*     */   
/*     */   public void setAttribute(String attributeName, String value) {
/* 411 */     getInfo().setAttribute(attributeName, value);
/* 412 */     setDirty();
/*     */   }
/*     */ 
/*     */   
/*     */   public void setAttribute(String attributeName, boolean value) {
/* 417 */     getInfo().setAttribute(attributeName, Boolean.valueOf(value));
/* 418 */     setDirty();
/*     */   }
/*     */ 
/*     */   
/*     */   public void setAttribute(String attributeName, List<String> value) {
/* 423 */     getInfo().setAttribute(attributeName, value);
/* 424 */     setDirty();
/*     */   }
/*     */ 
/*     */   
/*     */   public void setAttribute(String attributeName, Map<String, String> value) {
/* 429 */     getInfo().setAttribute(attributeName, value);
/* 430 */     setDirty();
/*     */   }
/*     */ 
/*     */   
/*     */   public void setAttribute(String attributeName, Set<String> value) {
/* 435 */     getInfo().setAttribute(attributeName, value);
/* 436 */     setDirty();
/*     */   }
/*     */ 
/*     */   
/*     */   public void setAttribute(String attributeName, Object value) {
/* 441 */     getInfo().setAttribute(attributeName, value);
/* 442 */     setDirty();
/*     */   }
/*     */ 
/*     */   
/*     */   public ILaunchConfiguration getOriginal() {
/* 447 */     ILaunchConfiguration config = this.fOriginal;
/* 448 */     ILaunchConfigurationWorkingCopy parent = this.fParent;
/* 449 */     while (parent != null) {
/* 450 */       config = parent.getOriginal();
/* 451 */       parent = parent.getParent();
/*     */     } 
/* 453 */     return config;
/*     */   }
/*     */ 
/*     */   
/*     */   public ILaunchConfigurationWorkingCopy getParent() {
/* 458 */     return this.fParent;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void copyFrom(LaunchConfiguration original) throws CoreException {
/* 474 */     LaunchConfigurationInfo info = original.getInfo();
/* 475 */     setInfo(info.getCopy());
/* 476 */     this.fDirty = false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void setOriginal(LaunchConfiguration original) {
/* 487 */     this.fOriginal = original;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void setInfo(LaunchConfigurationInfo info) {
/* 497 */     this.fInfo = info;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isWorkingCopy() {
/* 502 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected LaunchConfigurationInfo getInfo() {
/* 513 */     return this.fInfo;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void setDirty() {
/* 522 */     this.fDirty = true;
/* 523 */     if (!suppressChangeNotification()) {
/* 524 */       getLaunchManager().getConfigurationNotifier().notify(this, 2);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void setModes(Set<String> modes) {
/* 530 */     getInfo().setAttribute(ATTR_LAUNCH_MODES, (modes.size() > 0) ? modes : null);
/* 531 */     setDirty();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addModes(Set<String> modes) {
/*     */     try {
/* 540 */       Set<String> opts = getModes();
/* 541 */       if (opts.addAll(modes)) {
/* 542 */         getInfo().setAttribute(ATTR_LAUNCH_MODES, opts);
/* 543 */         setDirty();
/*     */       }
/*     */     
/* 546 */     } catch (CoreException e) {
/* 547 */       DebugPlugin.log((Throwable)e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void removeModes(Set<String> options) {
/*     */     try {
/* 557 */       Set<String> opts = getModes();
/* 558 */       if (opts.removeAll(options)) {
/* 559 */         getInfo().setAttribute(ATTR_LAUNCH_MODES, (opts.size() < 1) ? null : opts);
/* 560 */         setDirty();
/*     */       }
/*     */     
/* 563 */     } catch (CoreException e) {
/* 564 */       DebugPlugin.log((Throwable)e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void rename(String name) {
/* 573 */     if (!getName().equals(name)) {
/* 574 */       setName(name);
/* 575 */       this.fRenamed = !(!isNew() && getOriginal().getName().equals(name));
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void setName(String name) {
/* 586 */     super.setName(name);
/* 587 */     setDirty();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean isNew() {
/* 598 */     return (getOriginal() == null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean isMoved() {
/* 609 */     if (isNew() || this.fRenamed) {
/* 610 */       return true;
/*     */     }
/* 612 */     IContainer newContainer = getContainer();
/* 613 */     IContainer originalContainer = ((LaunchConfiguration)getOriginal()).getContainer();
/*     */     
/* 615 */     return !isSameContainerLocation(newContainer, originalContainer);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getMemento() {
/* 625 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean suppressChangeNotification() {
/* 634 */     return this.fSuppressChange;
/*     */   }
/*     */ 
/*     */   
/*     */   private boolean isSameContainerLocation(IContainer newContainer, IContainer originalContainer) {
/* 639 */     if (newContainer != null && originalContainer != null) {
/* 640 */       IPath newPath = newContainer.getLocation();
/* 641 */       IPath originalPath = originalContainer.getLocation();
/*     */       
/* 643 */       if (Objects.equals(newPath, originalPath)) {
/* 644 */         return true;
/*     */       }
/*     */     } 
/* 647 */     return Objects.equals(newContainer, originalContainer);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setContainer(IContainer container) {
/* 652 */     if (isSameContainerLocation(container, getContainer())) {
/*     */       return;
/*     */     }
/* 655 */     super.setContainer(container);
/* 656 */     setDirty();
/*     */   }
/*     */ 
/*     */   
/*     */   public void setAttributes(Map<String, ? extends Object> attributes) {
/* 661 */     getInfo().setAttributes(attributes);
/* 662 */     setDirty();
/*     */   }
/*     */ 
/*     */   
/*     */   public void setMappedResources(IResource[] resources) {
/* 667 */     ArrayList<String> paths = null;
/* 668 */     ArrayList<String> types = null;
/* 669 */     if (resources != null && resources.length > 0) {
/* 670 */       paths = new ArrayList<>(resources.length);
/* 671 */       types = new ArrayList<>(resources.length); byte b; int i; IResource[] arrayOfIResource;
/* 672 */       for (i = (arrayOfIResource = resources).length, b = 0; b < i; ) { IResource resource = arrayOfIResource[b];
/* 673 */         if (resource != null) {
/* 674 */           paths.add(resource.getFullPath().toPortableString());
/* 675 */           types.add(Integer.valueOf(resource.getType()).toString());
/*     */         }  b++; }
/*     */     
/*     */     } 
/* 679 */     setAttribute(LaunchConfiguration.ATTR_MAPPED_RESOURCE_PATHS, paths);
/* 680 */     setAttribute(LaunchConfiguration.ATTR_MAPPED_RESOURCE_TYPES, types);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setPreferredLaunchDelegate(Set<String> modes, String delegateId) {
/* 685 */     if (modes != null) {
/*     */       try {
/* 687 */         Map<String, String> delegates = getAttribute(LaunchConfiguration.ATTR_PREFERRED_LAUNCHERS, (Map<String, String>)null);
/*     */         
/* 689 */         Map<String, String> map = new HashMap<>();
/* 690 */         if (delegates != null) {
/* 691 */           map.putAll(delegates);
/*     */         }
/* 693 */         if (delegateId == null) {
/* 694 */           map.remove(modes.toString());
/*     */         } else {
/* 696 */           map.put(modes.toString(), delegateId);
/*     */         } 
/* 698 */         setAttribute(LaunchConfiguration.ATTR_PREFERRED_LAUNCHERS, map);
/*     */       } catch (CoreException ce) {
/* 700 */         DebugPlugin.log((Throwable)ce);
/*     */       } 
/*     */     }
/*     */   }
/*     */   
/*     */   public ILaunchConfigurationWorkingCopy getWorkingCopy() throws CoreException {
/* 706 */     return new LaunchConfigurationWorkingCopy(this);
/*     */   }
/*     */ 
/*     */   
/*     */   public Object removeAttribute(String attributeName) {
/* 711 */     return getInfo().removeAttribute(attributeName);
/*     */   }
/*     */ 
/*     */   
/*     */   public void copyAttributes(ILaunchConfiguration prototype) throws CoreException {
/* 716 */     Map<String, Object> map = prototype.getAttributes();
/* 717 */     LaunchConfigurationInfo info = getInfo();
/* 718 */     info.setPrototype(prototype);
/* 719 */     Set<String> prototypeVisibleAttributes = prototype.getPrototypeVisibleAttributes();
/* 720 */     if (prototypeVisibleAttributes != null) {
/* 721 */       prototypeVisibleAttributes.forEach(key -> {
/*     */             Object value = paramMap.get(key);
/*     */             if (value != null) {
/*     */               paramLaunchConfigurationInfo.setAttribute(key, value);
/*     */             }
/*     */           });
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void setPrototype(ILaunchConfiguration prototype, boolean copy) throws CoreException {
/* 732 */     if (prototype != null && !prototype.isPrototype()) {
/* 733 */       throw new CoreException(new Status(4, DebugPlugin.getUniqueIdentifier(), DebugCoreMessages.LaunchConfigurationWorkingCopy_6));
/*     */     }
/* 735 */     if (prototype != null && prototype.isWorkingCopy()) {
/* 736 */       throw new CoreException(new Status(4, DebugPlugin.getUniqueIdentifier(), DebugCoreMessages.LaunchConfigurationWorkingCopy_7));
/*     */     }
/* 738 */     if (prototype == null) {
/* 739 */       getInfo().setPrototype(null);
/* 740 */       removeAttribute(ATTR_PROTOTYPE);
/*     */     } else {
/* 742 */       if (isPrototype()) {
/* 743 */         throw new CoreException(new Status(4, DebugPlugin.getUniqueIdentifier(), DebugCoreMessages.LaunchConfigurationWorkingCopy_8));
/*     */       }
/* 745 */       getInfo().setPrototype(prototype);
/* 746 */       if (copy) {
/* 747 */         copyAttributes(prototype);
/*     */       }
/* 749 */       setAttribute(ATTR_PROTOTYPE, prototype.getMemento());
/* 750 */       setAttribute(IS_PROTOTYPE, false);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public ILaunchConfiguration doSave(int flag) throws CoreException {
/* 756 */     Collection<ILaunchConfiguration> children = null;
/* 757 */     if (1 == flag && 
/* 758 */       !isNew() && isMoved() && getParent() == null) {
/* 759 */       children = getOriginal().getPrototypeChildren();
/*     */     }
/*     */     
/* 762 */     ILaunchConfiguration saved = doSave();
/* 763 */     if (children != null) {
/* 764 */       for (ILaunchConfiguration child : children) {
/* 765 */         ILaunchConfigurationWorkingCopy wc = child.getWorkingCopy();
/* 766 */         wc.setPrototype(saved, false);
/* 767 */         wc.doSave();
/*     */       } 
/*     */     }
/* 770 */     return saved;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setPrototypeAttributeVisibility(String attribute, boolean visible) throws CoreException {
/* 775 */     super.setPrototypeAttributeVisibility(attribute, visible);
/* 776 */     setDirty();
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.debug.core-3.21.0.jar!\org\eclipse\debug\internal\core\LaunchConfigurationWorkingCopy.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */