package org.eclipse.debug.internal.core;

import org.eclipse.debug.core.IExpressionsListener;
import org.eclipse.debug.core.model.IExpression;

public interface IExpressionsListener2 extends IExpressionsListener {
  void expressionsMoved(IExpression[] paramArrayOfIExpression, int paramInt);
  
  void expressionsInserted(IExpression[] paramArrayOfIExpression, int paramInt);
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.debug.core-3.21.0.jar!\org\eclipse\debug\internal\core\IExpressionsListener2.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */