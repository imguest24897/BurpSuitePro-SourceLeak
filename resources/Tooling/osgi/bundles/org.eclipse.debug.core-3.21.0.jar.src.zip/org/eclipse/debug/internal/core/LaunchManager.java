/*      */ package org.eclipse.debug.internal.core;
/*      */ 
/*      */ import java.io.BufferedInputStream;
/*      */ import java.io.ByteArrayOutputStream;
/*      */ import java.io.File;
/*      */ import java.io.FileNotFoundException;
/*      */ import java.io.FilenameFilter;
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import java.nio.charset.StandardCharsets;
/*      */ import java.text.MessageFormat;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Arrays;
/*      */ import java.util.Collection;
/*      */ import java.util.Collections;
/*      */ import java.util.Comparator;
/*      */ import java.util.HashMap;
/*      */ import java.util.HashSet;
/*      */ import java.util.Iterator;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.Properties;
/*      */ import java.util.Set;
/*      */ import java.util.StringTokenizer;
/*      */ import javax.xml.parsers.DocumentBuilder;
/*      */ import javax.xml.parsers.DocumentBuilderFactory;
/*      */ import javax.xml.parsers.ParserConfigurationException;
/*      */ import javax.xml.transform.Transformer;
/*      */ import javax.xml.transform.TransformerException;
/*      */ import javax.xml.transform.TransformerFactory;
/*      */ import javax.xml.transform.dom.DOMSource;
/*      */ import javax.xml.transform.stream.StreamResult;
/*      */ import org.eclipse.core.filesystem.IFileStore;
/*      */ import org.eclipse.core.resources.IContainer;
/*      */ import org.eclipse.core.resources.IFile;
/*      */ import org.eclipse.core.resources.IProject;
/*      */ import org.eclipse.core.resources.IResource;
/*      */ import org.eclipse.core.resources.IResourceChangeEvent;
/*      */ import org.eclipse.core.resources.IResourceChangeListener;
/*      */ import org.eclipse.core.resources.IResourceDelta;
/*      */ import org.eclipse.core.resources.IResourceDeltaVisitor;
/*      */ import org.eclipse.core.resources.IResourceProxy;
/*      */ import org.eclipse.core.resources.IResourceProxyVisitor;
/*      */ import org.eclipse.core.resources.ResourcesPlugin;
/*      */ import org.eclipse.core.runtime.CoreException;
/*      */ import org.eclipse.core.runtime.IConfigurationElement;
/*      */ import org.eclipse.core.runtime.IExtensionPoint;
/*      */ import org.eclipse.core.runtime.IPath;
/*      */ import org.eclipse.core.runtime.IProgressMonitor;
/*      */ import org.eclipse.core.runtime.ISafeRunnable;
/*      */ import org.eclipse.core.runtime.IStatus;
/*      */ import org.eclipse.core.runtime.ListenerList;
/*      */ import org.eclipse.core.runtime.MultiStatus;
/*      */ import org.eclipse.core.runtime.Path;
/*      */ import org.eclipse.core.runtime.Platform;
/*      */ import org.eclipse.core.runtime.PlatformObject;
/*      */ import org.eclipse.core.runtime.SafeRunner;
/*      */ import org.eclipse.core.runtime.Status;
/*      */ import org.eclipse.core.runtime.SubMonitor;
/*      */ import org.eclipse.core.variables.VariablesPlugin;
/*      */ import org.eclipse.debug.core.DebugException;
/*      */ import org.eclipse.debug.core.DebugPlugin;
/*      */ import org.eclipse.debug.core.ILaunch;
/*      */ import org.eclipse.debug.core.ILaunchConfiguration;
/*      */ import org.eclipse.debug.core.ILaunchConfigurationListener;
/*      */ import org.eclipse.debug.core.ILaunchConfigurationType;
/*      */ import org.eclipse.debug.core.ILaunchDelegate;
/*      */ import org.eclipse.debug.core.ILaunchListener;
/*      */ import org.eclipse.debug.core.ILaunchManager;
/*      */ import org.eclipse.debug.core.ILaunchMode;
/*      */ import org.eclipse.debug.core.ILaunchesListener;
/*      */ import org.eclipse.debug.core.ILaunchesListener2;
/*      */ import org.eclipse.debug.core.model.IDebugTarget;
/*      */ import org.eclipse.debug.core.model.IDisconnect;
/*      */ import org.eclipse.debug.core.model.IPersistableSourceLocator;
/*      */ import org.eclipse.debug.core.model.IProcess;
/*      */ import org.eclipse.debug.core.sourcelookup.AbstractSourceLookupDirector;
/*      */ import org.eclipse.debug.core.sourcelookup.ISourceContainerType;
/*      */ import org.eclipse.debug.core.sourcelookup.ISourcePathComputer;
/*      */ import org.eclipse.debug.internal.core.sourcelookup.SourceContainerType;
/*      */ import org.eclipse.debug.internal.core.sourcelookup.SourcePathComputer;
/*      */ import org.w3c.dom.Document;
/*      */ import org.w3c.dom.Element;
/*      */ import org.w3c.dom.Node;
/*      */ import org.w3c.dom.NodeList;
/*      */ import org.xml.sax.InputSource;
/*      */ import org.xml.sax.SAXException;
/*      */ import org.xml.sax.helpers.DefaultHandler;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class LaunchManager
/*      */   extends PlatformObject
/*      */   implements ILaunchManager, IResourceChangeListener
/*      */ {
/*  145 */   protected static final String PREF_PREFERRED_DELEGATES = String.valueOf(DebugPlugin.getUniqueIdentifier()) + ".PREFERRED_DELEGATES";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final String DEBUG_UI = "org.eclipse.debug.ui";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  158 */   static final String[] UNSUPPORTED_WIN32_CONFIG_NAMES = new String[] { "aux", "clock$", "com1", "com2", "com3", "com4", 
/*  159 */       "com5", "com6", "com7", "com8", "com9", "con", "lpt1", "lpt2", 
/*  160 */       "lpt3", "lpt4", "lpt5", "lpt6", "lpt7", "lpt8", "lpt9", "nul", "prn" };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  168 */   static final char[] DISALLOWED_CONFIG_NAME_CHARS = new char[] { '@', '&', '\\', '/', ':', '*', '?', '"', '<', '>', '|' };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  175 */   protected static final IStatus promptStatus = (IStatus)new Status(1, "org.eclipse.debug.ui", 200, "", null);
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  180 */   private StepFilterManager fStepFilterManager = null;
/*      */   public static final int ADDED = 0;
/*      */   public static final int REMOVED = 1;
/*      */   public static final int CHANGED = 2;
/*      */   public static final int TERMINATE = 3;
/*      */   
/*      */   class ConfigurationNotifier
/*      */     implements ISafeRunnable
/*      */   {
/*      */     private ILaunchConfigurationListener fListener;
/*      */     private int fType;
/*      */     private ILaunchConfiguration fConfiguration;
/*      */     
/*      */     public void handleException(Throwable exception) {
/*  194 */       Status status = new Status(4, DebugPlugin.getUniqueIdentifier(), 120, "An exception occurred during launch configuration change notification.", exception);
/*  195 */       DebugPlugin.log((IStatus)status);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void notify(ILaunchConfiguration configuration, int update) {
/*  205 */       this.fConfiguration = configuration;
/*  206 */       this.fType = update;
/*  207 */       for (ILaunchConfigurationListener iLaunchConfigurationListener : LaunchManager.this.fLaunchConfigurationListeners) {
/*  208 */         this.fListener = iLaunchConfigurationListener;
/*  209 */         SafeRunner.run(this);
/*      */       } 
/*  211 */       this.fConfiguration = null;
/*  212 */       this.fListener = null;
/*      */     }
/*      */ 
/*      */     
/*      */     public void run() throws Exception {
/*  217 */       switch (this.fType) {
/*      */         case 0:
/*  219 */           this.fListener.launchConfigurationAdded(this.fConfiguration);
/*      */           break;
/*      */         case 1:
/*  222 */           this.fListener.launchConfigurationRemoved(this.fConfiguration);
/*      */           break;
/*      */         case 2:
/*  225 */           this.fListener.launchConfigurationChanged(this.fConfiguration);
/*      */           break;
/*      */       } 
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   class LaunchesNotifier
/*      */     implements ISafeRunnable
/*      */   {
/*      */     private ILaunchesListener fListener;
/*      */     
/*      */     private int fType;
/*      */     
/*      */     private ILaunch[] fNotifierLaunches;
/*      */     
/*      */     private ILaunch[] fRegistered;
/*      */ 
/*      */     
/*      */     public void handleException(Throwable exception) {
/*  246 */       Status status = new Status(4, DebugPlugin.getUniqueIdentifier(), 120, "An exception occurred during launch change notification.", exception);
/*  247 */       DebugPlugin.log((IStatus)status);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void notify(ILaunch[] launches, int update) {
/*  257 */       this.fNotifierLaunches = launches;
/*  258 */       this.fType = update;
/*  259 */       this.fRegistered = null;
/*  260 */       for (ILaunchesListener iLaunchesListener : LaunchManager.this.fLaunchesListeners) {
/*  261 */         this.fListener = iLaunchesListener;
/*  262 */         SafeRunner.run(this);
/*      */       } 
/*  264 */       this.fNotifierLaunches = null;
/*  265 */       this.fRegistered = null;
/*  266 */       this.fListener = null;
/*      */     }
/*      */ 
/*      */     
/*      */     public void run() throws Exception {
/*  271 */       switch (this.fType) {
/*      */         case 0:
/*  273 */           this.fListener.launchesAdded(this.fNotifierLaunches);
/*      */           break;
/*      */         case 1:
/*  276 */           this.fListener.launchesRemoved(this.fNotifierLaunches);
/*      */           break;
/*      */         case 2:
/*      */         case 3:
/*  280 */           if (this.fRegistered == null) {
/*  281 */             List<ILaunch> registered = null;
/*  282 */             for (int j = 0; j < this.fNotifierLaunches.length; j++) {
/*  283 */               if (LaunchManager.this.isRegistered(this.fNotifierLaunches[j])) {
/*  284 */                 if (registered != null) {
/*  285 */                   registered.add(this.fNotifierLaunches[j]);
/*      */                 }
/*  287 */               } else if (registered == null) {
/*  288 */                 registered = new ArrayList<>(this.fNotifierLaunches.length);
/*  289 */                 for (int k = 0; k < j; k++) {
/*  290 */                   registered.add(this.fNotifierLaunches[k]);
/*      */                 }
/*      */               } 
/*      */             } 
/*  294 */             if (registered == null) {
/*  295 */               this.fRegistered = this.fNotifierLaunches;
/*      */             } else {
/*  297 */               this.fRegistered = registered.<ILaunch>toArray(new ILaunch[registered.size()]);
/*      */             } 
/*      */           } 
/*  300 */           if (this.fRegistered.length > 0) {
/*  301 */             if (this.fType == 2) {
/*  302 */               this.fListener.launchesChanged(this.fRegistered);
/*      */             }
/*  304 */             if (this.fType == 3 && this.fListener instanceof ILaunchesListener2) {
/*  305 */               ((ILaunchesListener2)this.fListener).launchesTerminated(this.fRegistered);
/*      */             }
/*      */           } 
/*      */           break;
/*      */       } 
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   class MappedResourceVisitor
/*      */     implements IResourceDeltaVisitor
/*      */   {
/*      */     public boolean visit(IResourceDelta delta) throws CoreException {
/*  324 */       if ((delta.getFlags() & 0x4000) != 0) {
/*  325 */         return false;
/*      */       }
/*  327 */       if (delta.getKind() == 2 && delta.getFlags() != 8192) {
/*  328 */         ArrayList<ILaunchConfiguration> configs = LaunchManager.this.collectAssociatedLaunches(delta.getResource());
/*  329 */         for (ILaunchConfiguration config : configs) {
/*      */           try {
/*  331 */             config.delete();
/*  332 */           } catch (CoreException e) {
/*  333 */             DebugPlugin.log(e.getStatus());
/*      */           } 
/*      */         } 
/*  336 */         return false;
/*      */       } 
/*  338 */       return true;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   class LaunchManagerVisitor
/*      */     implements IResourceDeltaVisitor
/*      */   {
/*      */     public boolean visit(IResourceDelta delta) {
/*  349 */       if (delta == null) {
/*  350 */         return false;
/*      */       }
/*  352 */       if ((delta.getFlags() & 0x4000) != 0) {
/*  353 */         if (delta.getResource() instanceof IProject) {
/*  354 */           IProject project = (IProject)delta.getResource();
/*  355 */           if (project.isOpen()) {
/*  356 */             LaunchManager.this.projectOpened(project);
/*      */           } else {
/*  358 */             LaunchManager.this.projectClosed(project);
/*      */           } 
/*      */         } 
/*  361 */         return false;
/*      */       } 
/*  363 */       IResource resource = delta.getResource();
/*  364 */       if (resource instanceof IFile) {
/*  365 */         IFile file = (IFile)resource;
/*  366 */         if ("launch".equals(file.getFileExtension()) || "prototype".equals(file.getFileExtension())) {
/*  367 */           ILaunchConfiguration handle = new LaunchConfiguration(file);
/*  368 */           switch (delta.getKind()) {
/*      */             case 1:
/*  370 */               LaunchManager.this.launchConfigurationAdded(handle);
/*      */               break;
/*      */             case 2:
/*  373 */               LaunchManager.this.launchConfigurationDeleted(handle);
/*      */               break;
/*      */             case 4:
/*  376 */               LaunchManager.this.launchConfigurationChanged(handle);
/*      */               break;
/*      */           } 
/*      */ 
/*      */         
/*      */         } 
/*  382 */         return false;
/*      */       } 
/*  384 */       return true;
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   class LaunchNotifier
/*      */     implements ISafeRunnable
/*      */   {
/*      */     private ILaunchListener fListener;
/*      */     
/*      */     private int fType;
/*      */     
/*      */     private ILaunch fLaunch;
/*      */ 
/*      */     
/*      */     public void handleException(Throwable exception) {
/*  400 */       Status status = new Status(4, DebugPlugin.getUniqueIdentifier(), 120, "An exception occurred during launch change notification.", exception);
/*  401 */       DebugPlugin.log((IStatus)status);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void notify(ILaunch launch, int update) {
/*  411 */       this.fLaunch = launch;
/*  412 */       this.fType = update;
/*  413 */       for (ILaunchListener iLaunchListener : LaunchManager.this.fListeners) {
/*  414 */         this.fListener = iLaunchListener;
/*  415 */         SafeRunner.run(this);
/*      */       } 
/*  417 */       this.fLaunch = null;
/*  418 */       this.fListener = null;
/*      */     }
/*      */ 
/*      */     
/*      */     public void run() throws Exception {
/*  423 */       switch (this.fType) {
/*      */         case 0:
/*  425 */           this.fListener.launchAdded(this.fLaunch);
/*      */           break;
/*      */         case 1:
/*  428 */           this.fListener.launchRemoved(this.fLaunch);
/*      */           break;
/*      */         case 2:
/*  431 */           if (LaunchManager.this.isRegistered(this.fLaunch)) {
/*  432 */             this.fListener.launchChanged(this.fLaunch);
/*      */           }
/*      */           break;
/*      */       } 
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static class ResourceProxyVisitor
/*      */     implements IResourceProxyVisitor
/*      */   {
/*      */     private List<IResource> fList;
/*      */ 
/*      */ 
/*      */     
/*      */     protected ResourceProxyVisitor(List<IResource> list) {
/*  450 */       this.fList = list;
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean visit(IResourceProxy proxy) {
/*  455 */       if (proxy.getType() == 1) {
/*  456 */         if ("launch".equalsIgnoreCase(proxy.requestFullPath().getFileExtension()) || "prototype".equalsIgnoreCase(proxy.requestFullPath().getFileExtension())) {
/*  457 */           this.fList.add(proxy.requestResource());
/*      */         }
/*  459 */         return false;
/*      */       } 
/*  461 */       return true;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static class PreferredDelegate
/*      */   {
/*  471 */     private ILaunchDelegate fDelegate = null;
/*  472 */     private String fTypeid = null;
/*  473 */     private Set<String> fModes = null;
/*      */     
/*      */     public PreferredDelegate(ILaunchDelegate delegate, String typeid, Set<String> modes) {
/*  476 */       this.fDelegate = delegate;
/*  477 */       this.fTypeid = typeid;
/*  478 */       this.fModes = modes;
/*      */     }
/*      */     
/*      */     public String getTypeId() {
/*  482 */       return this.fTypeid;
/*      */     }
/*      */     
/*      */     public Set<String> getModes() {
/*  486 */       return this.fModes;
/*      */     }
/*      */     
/*      */     public ILaunchDelegate getDelegate() {
/*  490 */       return this.fDelegate;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  506 */   private static HashMap<String, String> fgNativeEnv = null;
/*  507 */   private static HashMap<String, String> fgNativeEnvCasePreserved = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  514 */   public static final IPath LOCAL_LAUNCH_CONFIGURATION_CONTAINER_PATH = DebugPlugin.getDefault().getStateLocation().append(".launches");
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Document getDocument() throws ParserConfigurationException {
/*  523 */     DocumentBuilderFactory dfactory = DocumentBuilderFactory.newInstance();
/*  524 */     DocumentBuilder docBuilder = dfactory.newDocumentBuilder();
/*  525 */     return docBuilder.newDocument();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String serializeDocument(Document doc) throws TransformerException, IOException {
/*  539 */     return serializeDocument(doc, System.lineSeparator());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String serializeDocument(Document doc, String lineDelimiter) throws TransformerException, IOException {
/*  554 */     ByteArrayOutputStream s = new ByteArrayOutputStream();
/*  555 */     TransformerFactory factory = TransformerFactory.newInstance();
/*  556 */     Transformer transformer = factory.newTransformer();
/*  557 */     transformer.setOutputProperty("method", "xml");
/*  558 */     transformer.setOutputProperty("indent", "yes");
/*  559 */     DOMSource source = new DOMSource(doc);
/*  560 */     StreamResult outputTarget = new StreamResult(s);
/*  561 */     transformer.transform(source, outputTarget);
/*  562 */     return s.toString(StandardCharsets.UTF_8).replace(System.lineSeparator(), lineDelimiter);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  569 */   private List<ILaunchConfigurationType> fLaunchConfigurationTypes = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  575 */   private Map<ILaunchConfiguration, LaunchConfigurationInfo> fLaunchConfigurations = new HashMap<>(10);
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  580 */   private volatile String[] fSortedConfigNames = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  586 */   private List<ILaunchConfiguration> fLaunchConfigurationIndex = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  592 */   private Map<String, LaunchConfigurationComparator> fComparators = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  598 */   private Map<String, ILaunchMode> fLaunchModes = null;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  603 */   private HashMap<String, LaunchDelegate> fLaunchDelegates = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  610 */   private Set<PreferredDelegate> fPreferredDelegates = null;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  615 */   private List<ILaunch> fLaunches = new ArrayList<>(10);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  621 */   private Set<ILaunch> fLaunchSet = new HashSet<>(10);
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  626 */   private ListenerList<ILaunchListener> fListeners = new ListenerList();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  632 */   private ListenerList<ILaunchesListener> fLaunchesListeners = new ListenerList();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private LaunchManagerVisitor fgVisitor;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private MappedResourceVisitor fgMRVisitor;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean fListening = false;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  657 */   private ListenerList<ILaunchConfigurationListener> fLaunchConfigurationListeners = new ListenerList();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  664 */   private Map<String, IConfigurationElement> fSourceLocators = null;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private ILaunchConfiguration fFrom;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private ILaunchConfiguration fTo;
/*      */ 
/*      */ 
/*      */   
/*      */   private Map<String, ISourceContainerType> sourceContainerTypes;
/*      */ 
/*      */ 
/*      */   
/*      */   private Map<String, ISourcePathComputer> sourcePathComputers;
/*      */ 
/*      */ 
/*      */   
/*      */   private Set<String> fActiveModes;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void addLaunch(ILaunch launch) {
/*  692 */     if (internalAddLaunch(launch)) {
/*  693 */       fireUpdate(launch, 0);
/*  694 */       fireUpdate(new ILaunch[] { launch }, 0);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public void addLaunchConfigurationListener(ILaunchConfigurationListener listener) {
/*  700 */     this.fLaunchConfigurationListeners.add(listener);
/*      */   }
/*      */ 
/*      */   
/*      */   public void addLaunches(ILaunch[] launches) {
/*  705 */     List<ILaunch> added = new ArrayList<>(launches.length); byte b; int i; ILaunch[] arrayOfILaunch;
/*  706 */     for (i = (arrayOfILaunch = launches).length, b = 0; b < i; ) { ILaunch launch = arrayOfILaunch[b];
/*  707 */       if (internalAddLaunch(launch))
/*  708 */         added.add(launch); 
/*      */       b++; }
/*      */     
/*  711 */     if (!added.isEmpty()) {
/*  712 */       ILaunch[] addedLaunches = added.<ILaunch>toArray(new ILaunch[added.size()]);
/*  713 */       fireUpdate(addedLaunches, 0);
/*  714 */       for (int j = 0; j < addedLaunches.length; j++) {
/*  715 */         fireUpdate(launches[j], 0);
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public void addLaunchListener(ILaunchesListener listener) {
/*  722 */     this.fLaunchesListeners.add(listener);
/*      */   }
/*      */ 
/*      */   
/*      */   public void addLaunchListener(ILaunchListener listener) {
/*  727 */     this.fListeners.add(listener);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void cacheNativeEnvironment(Map<String, String> cache) {
/*      */     try {
/*  746 */       String nativeCommand = null;
/*  747 */       boolean isWin9xME = false;
/*  748 */       String fileName = null;
/*  749 */       if (Platform.getOS().equals("win32")) {
/*  750 */         String osName = System.getProperty("os.name");
/*  751 */         isWin9xME = (osName != null && (osName.startsWith("Windows 9") || osName.startsWith("Windows ME")));
/*  752 */         if (isWin9xME) {
/*      */ 
/*      */           
/*  755 */           IPath stateLocation = DebugPlugin.getDefault().getStateLocation();
/*  756 */           fileName = String.valueOf(stateLocation.toOSString()) + File.separator + "env.txt";
/*  757 */           nativeCommand = "command.com /C set > " + fileName;
/*      */         } else {
/*      */           
/*  760 */           nativeCommand = "cmd.exe /C set";
/*      */         } 
/*  762 */       } else if (!Platform.getOS().equals("unknown")) {
/*  763 */         nativeCommand = "env";
/*      */       } 
/*  765 */       if (nativeCommand == null) {
/*      */         return;
/*      */       }
/*  768 */       Process process = Runtime.getRuntime().exec(nativeCommand);
/*  769 */       if (isWin9xME) {
/*      */         Exception exception2;
/*  771 */         Properties p = new Properties();
/*  772 */         File file = new File(fileName);
/*  773 */         Exception exception1 = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       }
/*      */       else {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  791 */         Exception exception2, exception1 = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     }
/*  847 */     catch (IOException iOException) {}
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void clearAllLaunchConfigurations() {
/*  857 */     if (this.fLaunchConfigurationTypes != null) {
/*  858 */       this.fLaunchConfigurationTypes.clear();
/*      */     }
/*  860 */     if (this.fLaunchConfigurationIndex != null) {
/*  861 */       this.fLaunchConfigurationIndex.clear();
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   public String getEncoding(ILaunchConfiguration configuration) throws CoreException {
/*  867 */     boolean forceSystemEncoding = configuration.getAttribute("org.eclipse.debug.core.ATTR_FORCE_SYSTEM_CONSOLE_ENCODING", false);
/*  868 */     if (forceSystemEncoding) {
/*  869 */       return Platform.getSystemCharset().name();
/*      */     }
/*  871 */     String encoding = configuration.getAttribute("org.eclipse.debug.ui.ATTR_CONSOLE_ENCODING", null);
/*  872 */     if (encoding == null) {
/*  873 */       IResource[] resources = configuration.getMappedResources();
/*  874 */       if (resources != null && resources.length > 0) {
/*  875 */         IResource res = resources[0];
/*  876 */         if (res instanceof IFile) {
/*  877 */           return ((IFile)res).getCharset();
/*      */         }
/*  879 */         if (res instanceof IContainer) {
/*  880 */           return ((IContainer)res).getDefaultCharset();
/*      */         }
/*      */       } else {
/*      */         
/*  884 */         return ResourcesPlugin.getEncoding();
/*      */       } 
/*      */     } 
/*  887 */     return encoding;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected synchronized void clearConfigNameCache() {
/*  894 */     this.fSortedConfigNames = null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected DebugException createDebugException(String message, Throwable throwable) {
/*  904 */     return new DebugException(
/*  905 */         (IStatus)new Status(
/*  906 */           4, DebugPlugin.getUniqueIdentifier(), 
/*  907 */           5012, message, throwable));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected LaunchConfigurationInfo createInfoFromXML(InputStream stream) throws CoreException, ParserConfigurationException, IOException, SAXException {
/*  929 */     return createInfoFromXML(stream, false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected LaunchConfigurationInfo createInfoFromXML(InputStream stream, boolean isPrototype) throws CoreException, ParserConfigurationException, IOException, SAXException {
/*  950 */     Element root = null;
/*  951 */     DocumentBuilder parser = DocumentBuilderFactory.newInstance().newDocumentBuilder();
/*  952 */     parser.setErrorHandler(new DefaultHandler());
/*  953 */     root = parser.parse(new InputSource(stream)).getDocumentElement();
/*  954 */     LaunchConfigurationInfo info = new LaunchConfigurationInfo();
/*  955 */     info.initializeFromXML(root, isPrototype);
/*  956 */     return info;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected List<ILaunchConfiguration> findLaunchConfigurations(IContainer container) {
/*  967 */     if (container instanceof IProject && !((IProject)container).isOpen()) {
/*  968 */       return Collections.emptyList();
/*      */     }
/*  970 */     List<IResource> list = new ArrayList<>(10);
/*  971 */     ResourceProxyVisitor visitor = new ResourceProxyVisitor(list);
/*      */     try {
/*  973 */       container.accept(visitor, 0);
/*  974 */     } catch (CoreException coreException) {}
/*      */ 
/*      */     
/*  977 */     List<ILaunchConfiguration> configs = new ArrayList<>(list.size());
/*  978 */     for (IResource resource : list) {
/*  979 */       ILaunchConfiguration config = getLaunchConfiguration((IFile)resource);
/*  980 */       if (config != null && config.exists()) {
/*  981 */         configs.add(config);
/*      */       }
/*      */     } 
/*  984 */     return configs;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ILaunchConfiguration findLaunchConfiguration(String name) {
/*  994 */     if (name != null) {
/*  995 */       byte b; int i; ILaunchConfiguration[] arrayOfILaunchConfiguration; for (i = (arrayOfILaunchConfiguration = getLaunchConfigurations()).length, b = 0; b < i; ) { ILaunchConfiguration config = arrayOfILaunchConfiguration[b];
/*  996 */         if (name.equals(config.getName()))
/*  997 */           return config; 
/*      */         b++; }
/*      */     
/*      */     } 
/* 1001 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected List<ILaunchConfiguration> findLocalLaunchConfigurations() {
/* 1010 */     IPath containerPath = LOCAL_LAUNCH_CONFIGURATION_CONTAINER_PATH;
/* 1011 */     File directory = containerPath.toFile();
/* 1012 */     if (directory.isDirectory()) {
/* 1013 */       List<ILaunchConfiguration> configs = new ArrayList<>();
/* 1014 */       FilenameFilter configFilter = (dir, name) -> (dir.equals(paramFile1) && name.endsWith("launch"));
/*      */       
/* 1016 */       File[] configFiles = directory.listFiles(configFilter);
/* 1017 */       if (configFiles != null && configFiles.length > 0) {
/* 1018 */         LaunchConfiguration config = null; byte b; int i; File[] arrayOfFile;
/* 1019 */         for (i = (arrayOfFile = configFiles).length, b = 0; b < i; ) { File configFile = arrayOfFile[b];
/* 1020 */           config = new LaunchConfiguration(LaunchConfiguration.getSimpleName(configFile.getName()), null, false);
/* 1021 */           configs.add(config); b++; }
/*      */       
/*      */       } 
/* 1024 */       FilenameFilter prototypeFilter = (dir, name) -> (dir.equals(paramFile1) && name.endsWith("prototype"));
/* 1025 */       File[] prototypeFiles = directory.listFiles(prototypeFilter);
/* 1026 */       if (prototypeFiles != null && prototypeFiles.length > 0) {
/* 1027 */         LaunchConfiguration config = null; byte b; int i; File[] arrayOfFile;
/* 1028 */         for (i = (arrayOfFile = prototypeFiles).length, b = 0; b < i; ) { File prototypeFile = arrayOfFile[b];
/* 1029 */           config = new LaunchConfiguration(LaunchConfiguration.getSimpleName(prototypeFile.getName()), null, true);
/* 1030 */           configs.add(config); b++; }
/*      */       
/*      */       } 
/* 1033 */       return configs;
/*      */     } 
/* 1035 */     return Collections.emptyList();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void fireUpdate(ILaunch launch, int update) {
/* 1046 */     (new LaunchNotifier()).notify(launch, update);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void fireUpdate(ILaunch[] launches, int update) {
/* 1057 */     (new LaunchesNotifier()).notify(launches, update);
/*      */   }
/*      */ 
/*      */   
/*      */   public String generateUniqueLaunchConfigurationNameFrom(String baseName) {
/* 1062 */     int index = 1;
/* 1063 */     int length = baseName.length();
/* 1064 */     int copyIndex = baseName.lastIndexOf(" (");
/* 1065 */     String base = baseName;
/* 1066 */     if (copyIndex > -1 && length > copyIndex + 2 && baseName.charAt(length - 1) == ')') {
/* 1067 */       String trailer = baseName.substring(copyIndex + 2, length - 1);
/* 1068 */       if (isNumber(trailer)) {
/*      */         try {
/* 1070 */           index = Integer.parseInt(trailer);
/* 1071 */           base = baseName.substring(0, copyIndex);
/*      */         }
/* 1073 */         catch (NumberFormatException numberFormatException) {}
/*      */       }
/*      */     } 
/* 1076 */     String newName = base;
/* 1077 */     while (isExistingLaunchConfigurationName(newName)) {
/* 1078 */       newName = MessageFormat.format(DebugCoreMessages.LaunchManager_31, new Object[] {
/* 1079 */             base, Integer.toString(index) });
/* 1080 */       index++;
/*      */     } 
/* 1082 */     return newName;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String generateUniqueLaunchConfigurationNameFrom(String basename, Set<String> reservednames) {
/* 1104 */     if (reservednames == null) {
/* 1105 */       return generateUniqueLaunchConfigurationNameFrom(basename);
/*      */     }
/* 1107 */     int index = 1;
/* 1108 */     int length = basename.length();
/* 1109 */     String base = basename;
/* 1110 */     int copyIndex = base.lastIndexOf(" (");
/* 1111 */     if (copyIndex > -1 && length > copyIndex + 2 && base.charAt(length - 1) == ')') {
/* 1112 */       String trailer = base.substring(copyIndex + 2, length - 1);
/* 1113 */       if (isNumber(trailer)) {
/*      */         try {
/* 1115 */           index = Integer.parseInt(trailer);
/* 1116 */           base = base.substring(0, copyIndex);
/*      */         }
/* 1118 */         catch (NumberFormatException numberFormatException) {}
/*      */       }
/*      */     } 
/* 1121 */     String newname = base;
/* 1122 */     StringBuilder buffer = null;
/* 1123 */     while (isExistingLaunchConfigurationName(newname) || reservednames.contains(newname)) {
/* 1124 */       buffer = new StringBuilder(base);
/* 1125 */       buffer.append(" (");
/* 1126 */       buffer.append(String.valueOf(index));
/* 1127 */       index++;
/* 1128 */       buffer.append(')');
/* 1129 */       newname = buffer.toString();
/*      */     } 
/* 1131 */     return newname;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized List<ILaunchConfiguration> getAllLaunchConfigurations() {
/* 1141 */     if (this.fLaunchConfigurationIndex == null) {
/*      */       try {
/* 1143 */         this.fLaunchConfigurationIndex = new ArrayList<>(20);
/* 1144 */         List<ILaunchConfiguration> configs = findLocalLaunchConfigurations();
/* 1145 */         verifyConfigurations(configs, this.fLaunchConfigurationIndex);
/* 1146 */         configs = findLaunchConfigurations((IContainer)ResourcesPlugin.getWorkspace().getRoot());
/* 1147 */         verifyConfigurations(configs, this.fLaunchConfigurationIndex);
/*      */       } finally {
/* 1149 */         hookResourceChangeListener();
/*      */       } 
/*      */     }
/* 1152 */     return this.fLaunchConfigurationIndex;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected synchronized String[] getAllSortedConfigNames() {
/* 1162 */     if (this.fSortedConfigNames == null) {
/* 1163 */       List<ILaunchConfiguration> collection = getAllLaunchConfigurations();
/* 1164 */       ILaunchConfiguration[] configs = collection.<ILaunchConfiguration>toArray(new ILaunchConfiguration[collection.size()]);
/* 1165 */       this.fSortedConfigNames = new String[configs.length];
/* 1166 */       for (int i = 0; i < configs.length; i++) {
/* 1167 */         this.fSortedConfigNames[i] = configs[i].getName();
/*      */       }
/* 1169 */       Arrays.sort((Object[])this.fSortedConfigNames);
/*      */     } 
/* 1171 */     return this.fSortedConfigNames;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected Comparator<Object> getComparator(String attributeName) {
/* 1182 */     Map<String, LaunchConfigurationComparator> map = getComparators();
/* 1183 */     return map.get(attributeName);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected Map<String, LaunchConfigurationComparator> getComparators() {
/* 1191 */     initializeComparators();
/* 1192 */     return this.fComparators;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected List<ILaunchConfiguration> getConfigsFromXML(Element root) throws CoreException {
/* 1204 */     DebugException invalidFormat = 
/* 1205 */       new DebugException(
/* 1206 */         (IStatus)new Status(
/* 1207 */           4, DebugPlugin.getUniqueIdentifier(), 
/* 1208 */           5012, DebugCoreMessages.LaunchManager_Invalid_launch_configuration_index__18, null));
/*      */ 
/*      */ 
/*      */     
/* 1212 */     if (!root.getNodeName().equalsIgnoreCase("launchConfigurations")) {
/* 1213 */       throw invalidFormat;
/*      */     }
/*      */ 
/*      */     
/* 1217 */     List<ILaunchConfiguration> configs = new ArrayList<>(4);
/* 1218 */     NodeList list = root.getChildNodes();
/* 1219 */     int length = list.getLength();
/* 1220 */     Node node = null;
/* 1221 */     Element entry = null;
/* 1222 */     String memento = null;
/* 1223 */     for (int i = 0; i < length; i++) {
/* 1224 */       node = list.item(i);
/* 1225 */       short type = node.getNodeType();
/* 1226 */       if (type == 1) {
/* 1227 */         entry = (Element)node;
/* 1228 */         if (!entry.getNodeName().equals("launchConfiguration")) {
/* 1229 */           throw invalidFormat;
/*      */         }
/* 1231 */         memento = entry.getAttribute("memento");
/* 1232 */         if (memento == null) {
/* 1233 */           throw invalidFormat;
/*      */         }
/* 1235 */         configs.add(getLaunchConfiguration(memento));
/*      */       } 
/*      */     } 
/* 1238 */     return configs;
/*      */   }
/*      */   
/*      */   protected ConfigurationNotifier getConfigurationNotifier() {
/* 1242 */     return new ConfigurationNotifier();
/*      */   }
/*      */ 
/*      */   
/*      */   public IDebugTarget[] getDebugTargets() {
/* 1247 */     synchronized (this.fLaunches) {
/* 1248 */       List<IDebugTarget> allTargets = new ArrayList<>(this.fLaunches.size());
/* 1249 */       IDebugTarget[] targets = null;
/* 1250 */       for (ILaunch launch : this.fLaunches) {
/* 1251 */         targets = launch.getDebugTargets();
/* 1252 */         Collections.addAll(allTargets, targets);
/*      */       } 
/* 1254 */       return allTargets.<IDebugTarget>toArray(new IDebugTarget[allTargets.size()]);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private LaunchManagerVisitor getDeltaVisitor() {
/* 1264 */     if (this.fgVisitor == null) {
/* 1265 */       this.fgVisitor = new LaunchManagerVisitor();
/*      */     }
/* 1267 */     return this.fgVisitor;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private MappedResourceVisitor getMappedResourceVisitor() {
/* 1277 */     if (this.fgMRVisitor == null) {
/* 1278 */       this.fgMRVisitor = new MappedResourceVisitor();
/*      */     }
/* 1280 */     return this.fgMRVisitor;
/*      */   }
/*      */ 
/*      */   
/*      */   public String[] getEnvironment(ILaunchConfiguration configuration) throws CoreException {
/* 1285 */     Map<String, String> configEnv = configuration.getAttribute(ATTR_ENVIRONMENT_VARIABLES, null);
/* 1286 */     if (configEnv == null) {
/* 1287 */       return null;
/*      */     }
/* 1289 */     Map<String, String> env = new HashMap<>();
/*      */     
/* 1291 */     boolean append = configuration.getAttribute(ATTR_APPEND_ENVIRONMENT_VARIABLES, true);
/* 1292 */     if (append) {
/* 1293 */       env.putAll(getNativeEnvironmentCasePreserved());
/*      */     }
/*      */ 
/*      */     
/* 1297 */     boolean win32 = Platform.getOS().equals("win32");
/* 1298 */     String key = null;
/* 1299 */     String value = null;
/* 1300 */     Object nativeValue = null;
/* 1301 */     String nativeKey = null;
/* 1302 */     for (Map.Entry<String, String> entry : configEnv.entrySet()) {
/* 1303 */       key = entry.getKey();
/* 1304 */       value = entry.getValue();
/*      */       
/* 1306 */       if (value != null) {
/* 1307 */         value = VariablesPlugin.getDefault().getStringVariableManager().performStringSubstitution(value);
/*      */       }
/* 1309 */       boolean added = false;
/* 1310 */       if (win32) {
/*      */         
/* 1312 */         nativeValue = env.get(key);
/* 1313 */         if (nativeValue != null) {
/*      */           
/* 1315 */           env.put(key, value);
/*      */         
/*      */         }
/*      */         else {
/*      */           
/* 1320 */           for (Map.Entry<String, String> nativeEntry : env.entrySet()) {
/* 1321 */             nativeKey = nativeEntry.getKey();
/* 1322 */             if (nativeKey.equalsIgnoreCase(key)) {
/* 1323 */               nativeEntry.setValue(value);
/* 1324 */               added = true;
/*      */               break;
/*      */             } 
/*      */           } 
/*      */         } 
/*      */       } 
/* 1330 */       if (!added) {
/* 1331 */         env.put(key, value);
/*      */       }
/*      */     } 
/* 1334 */     List<String> strings = new ArrayList<>(env.size());
/* 1335 */     StringBuilder buffer = null;
/* 1336 */     for (Map.Entry<String, String> entry : env.entrySet()) {
/* 1337 */       buffer = new StringBuilder(entry.getKey());
/* 1338 */       buffer.append('=').append(entry.getValue());
/* 1339 */       strings.add(buffer.toString());
/*      */     } 
/* 1341 */     return strings.<String>toArray(new String[strings.size()]);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected LaunchConfigurationInfo getInfo(LaunchConfiguration config) throws CoreException {
/* 1357 */     LaunchConfigurationInfo info = this.fLaunchConfigurations.get(config);
/* 1358 */     if (info == null) {
/* 1359 */       IFileStore store = config.getFileStore();
/* 1360 */       if (config.exists()) {
/* 1361 */         BufferedInputStream stream = null;
/*      */         try {
/* 1363 */           stream = new BufferedInputStream(store.openInputStream(0, null));
/* 1364 */           info = createInfoFromXML(stream, isPrototype(store));
/* 1365 */           synchronized (this) {
/* 1366 */             this.fLaunchConfigurations.put(config, info);
/*      */           } 
/* 1368 */         } catch (FileNotFoundException e) {
/* 1369 */           throwException(config, e);
/* 1370 */         } catch (SAXException e) {
/* 1371 */           throwException(config, e);
/* 1372 */         } catch (ParserConfigurationException e) {
/* 1373 */           throwException(config, e);
/* 1374 */         } catch (IOException e) {
/* 1375 */           throwException(config, e);
/*      */         } finally {
/* 1377 */           if (stream != null) {
/*      */             try {
/* 1379 */               stream.close();
/* 1380 */             } catch (IOException e) {
/* 1381 */               throwException(config, e);
/*      */             } 
/*      */           }
/*      */         } 
/*      */       } else {
/* 1386 */         if (store != null) {
/* 1387 */           throw createDebugException(MessageFormat.format(DebugCoreMessages.LaunchManager_does_not_exist, new Object[] {
/* 1388 */                   config.getName(), store.toURI().toString() }), null);
/*      */         }
/* 1390 */         throw createDebugException(MessageFormat.format(DebugCoreMessages.LaunchManager_does_not_exist_no_store_found, new Object[] { config.getName() }), null);
/*      */       } 
/*      */     } 
/* 1393 */     return info;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean isPrototype(IFileStore store) {
/* 1406 */     if (store.getName().endsWith(".prototype")) {
/* 1407 */       return true;
/*      */     }
/* 1409 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean isPrototype(File file) {
/* 1422 */     if (file.getName().endsWith(".prototype")) {
/* 1423 */       return true;
/*      */     }
/* 1425 */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   public ILaunchConfiguration getLaunchConfiguration(IFile file) {
/* 1430 */     hookResourceChangeListener();
/* 1431 */     return new LaunchConfiguration(file);
/*      */   }
/*      */ 
/*      */   
/*      */   public ILaunchConfiguration getLaunchConfiguration(String memento) throws CoreException {
/* 1436 */     hookResourceChangeListener();
/* 1437 */     return new LaunchConfiguration(memento);
/*      */   }
/*      */ 
/*      */   
/*      */   public synchronized ILaunchConfiguration[] getLaunchConfigurations() {
/* 1442 */     return getLaunchConfigurations(1);
/*      */   }
/*      */ 
/*      */   
/*      */   public ILaunchConfiguration[] getLaunchConfigurations(int kinds) {
/* 1447 */     List<ILaunchConfiguration> allConfigs = getAllLaunchConfigurations();
/* 1448 */     if ((kinds & 0x1) > 0 && (kinds & 0x2) > 0)
/*      */     {
/* 1450 */       return allConfigs.<ILaunchConfiguration>toArray(new ILaunchConfiguration[allConfigs.size()]);
/*      */     }
/* 1452 */     List<ILaunchConfiguration> select = new ArrayList<>(allConfigs.size());
/* 1453 */     Iterator<ILaunchConfiguration> iterator = allConfigs.iterator();
/* 1454 */     while (iterator.hasNext()) {
/* 1455 */       ILaunchConfiguration config = iterator.next();
/*      */       try {
/* 1457 */         if ((config.getKind() & kinds) > 0) {
/* 1458 */           select.add(config);
/*      */         }
/* 1460 */       } catch (CoreException e) {
/* 1461 */         DebugPlugin.log((Throwable)e);
/*      */       } 
/*      */     } 
/* 1464 */     return select.<ILaunchConfiguration>toArray(new ILaunchConfiguration[select.size()]);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized ILaunchConfiguration[] getLaunchConfigurations(ILaunchConfigurationType type) throws CoreException {
/* 1470 */     return getLaunchConfigurations(type, 1);
/*      */   }
/*      */ 
/*      */   
/*      */   public synchronized ILaunchConfiguration[] getLaunchConfigurations(ILaunchConfigurationType type, int kinds) throws CoreException {
/* 1475 */     List<ILaunchConfiguration> configs = new ArrayList<>();
/* 1476 */     for (ILaunchConfiguration config : getAllLaunchConfigurations()) {
/* 1477 */       if (config.getType().equals(type) && (config.getKind() & kinds) > 0) {
/* 1478 */         configs.add(config);
/*      */       }
/*      */     } 
/* 1481 */     return configs.<ILaunchConfiguration>toArray(new ILaunchConfiguration[configs.size()]);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected synchronized List<ILaunchConfiguration> getLaunchConfigurations(IProject project) {
/* 1493 */     List<ILaunchConfiguration> configs = new ArrayList<>();
/* 1494 */     for (ILaunchConfiguration config : getAllLaunchConfigurations()) {
/* 1495 */       IFile file = config.getFile();
/* 1496 */       if (file != null && file.getProject().equals(project)) {
/* 1497 */         configs.add(config);
/*      */       }
/*      */     } 
/* 1500 */     return configs;
/*      */   } public ILaunchConfigurationType getLaunchConfigurationType(String id) {
/*      */     byte b;
/*      */     int i;
/*      */     ILaunchConfigurationType[] arrayOfILaunchConfigurationType;
/* 1505 */     for (i = (arrayOfILaunchConfigurationType = getLaunchConfigurationTypes()).length, b = 0; b < i; ) { ILaunchConfigurationType type = arrayOfILaunchConfigurationType[b];
/* 1506 */       if (type.getIdentifier().equals(id))
/* 1507 */         return type; 
/*      */       b++; }
/*      */     
/* 1510 */     return null;
/*      */   }
/*      */ 
/*      */   
/*      */   public ILaunchConfigurationType[] getLaunchConfigurationTypes() {
/* 1515 */     initializeLaunchConfigurationTypes();
/* 1516 */     return this.fLaunchConfigurationTypes.<ILaunchConfigurationType>toArray(new ILaunchConfigurationType[this.fLaunchConfigurationTypes.size()]);
/*      */   }
/*      */ 
/*      */   
/*      */   public ILaunch[] getLaunches() {
/* 1521 */     synchronized (this.fLaunches) {
/* 1522 */       return this.fLaunches.<ILaunch>toArray(new ILaunch[this.fLaunches.size()]);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public ILaunchMode getLaunchMode(String mode) {
/* 1528 */     initializeLaunchModes();
/* 1529 */     return this.fLaunchModes.get(mode);
/*      */   }
/*      */ 
/*      */   
/*      */   public ILaunchMode[] getLaunchModes() {
/* 1534 */     initializeLaunchModes();
/* 1535 */     Collection<ILaunchMode> collection = this.fLaunchModes.values();
/* 1536 */     return collection.<ILaunchMode>toArray(new ILaunchMode[collection.size()]);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ILaunchDelegate[] getLaunchDelegates() {
/* 1548 */     initializeLaunchDelegates();
/* 1549 */     Collection<LaunchDelegate> col = this.fLaunchDelegates.values();
/* 1550 */     return col.<ILaunchDelegate>toArray(new ILaunchDelegate[col.size()]);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public LaunchDelegate[] getLaunchDelegates(String typeid) {
/* 1563 */     initializeLaunchDelegates();
/* 1564 */     ArrayList<LaunchDelegate> list = new ArrayList<>();
/* 1565 */     for (Map.Entry<String, LaunchDelegate> entry : this.fLaunchDelegates.entrySet()) {
/* 1566 */       LaunchDelegate ld = entry.getValue();
/* 1567 */       if (ld.getLaunchConfigurationTypeId().equals(typeid)) {
/* 1568 */         list.add(ld);
/*      */       }
/*      */     } 
/* 1571 */     return list.<LaunchDelegate>toArray(new LaunchDelegate[list.size()]);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ILaunchDelegate getLaunchDelegate(String id) {
/* 1583 */     if (id != null) {
/* 1584 */       byte b; int i; ILaunchDelegate[] arrayOfILaunchDelegate; for (i = (arrayOfILaunchDelegate = getLaunchDelegates()).length, b = 0; b < i; ) { ILaunchDelegate delegate = arrayOfILaunchDelegate[b];
/* 1585 */         if (id.equals(delegate.getId()))
/* 1586 */           return delegate; 
/*      */         b++; }
/*      */     
/*      */     } 
/* 1590 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private synchronized void initializeLaunchDelegates() {
/* 1599 */     if (this.fLaunchDelegates == null) {
/* 1600 */       this.fLaunchDelegates = new HashMap<>();
/*      */       
/* 1602 */       IExtensionPoint extensionPoint = Platform.getExtensionRegistry().getExtensionPoint(DebugPlugin.getUniqueIdentifier(), "launchDelegates");
/* 1603 */       LaunchDelegate delegate = null; byte b; int i; IConfigurationElement[] arrayOfIConfigurationElement;
/* 1604 */       for (i = (arrayOfIConfigurationElement = extensionPoint.getConfigurationElements()).length, b = 0; b < i; ) { IConfigurationElement info = arrayOfIConfigurationElement[b];
/* 1605 */         delegate = new LaunchDelegate(info);
/* 1606 */         this.fLaunchDelegates.put(delegate.getId(), delegate);
/*      */         b++; }
/*      */       
/* 1609 */       extensionPoint = Platform.getExtensionRegistry().getExtensionPoint(DebugPlugin.getUniqueIdentifier(), "launchConfigurationTypes");
/* 1610 */       for (i = (arrayOfIConfigurationElement = extensionPoint.getConfigurationElements()).length, b = 0; b < i; ) { IConfigurationElement info = arrayOfIConfigurationElement[b];
/*      */         
/* 1612 */         if (info.getAttribute("delegate") != null) {
/* 1613 */           delegate = new LaunchDelegate(info);
/* 1614 */           this.fLaunchDelegates.put(delegate.getId(), delegate);
/*      */         } 
/*      */         b++; }
/*      */     
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private synchronized void initializePreferredDelegates() {
/* 1631 */     if (this.fPreferredDelegates == null) {
/* 1632 */       this.fPreferredDelegates = new HashSet<>();
/* 1633 */       String preferred = Platform.getPreferencesService().getString(DebugPlugin.getUniqueIdentifier(), PREF_PREFERRED_DELEGATES, "", null);
/* 1634 */       if (!"".equals(preferred)) {
/*      */         try {
/* 1636 */           Element root = DebugPlugin.parseDocument(preferred);
/* 1637 */           NodeList nodes = root.getElementsByTagName("delegate");
/* 1638 */           Element element = null;
/* 1639 */           String typeid = null;
/* 1640 */           Set<String> modeset = null;
/* 1641 */           for (int i = 0; i < nodes.getLength(); i++) {
/* 1642 */             element = (Element)nodes.item(i);
/* 1643 */             String delegateid = element.getAttribute("id");
/* 1644 */             typeid = element.getAttribute("typeid");
/* 1645 */             String[] modes = element.getAttribute("modes").split(",");
/* 1646 */             modeset = new HashSet<>(Arrays.asList(modes));
/* 1647 */             LaunchDelegate delegate = getLaunchDelegateExtension(typeid, delegateid, modeset);
/* 1648 */             if (delegate != null)
/*      */             {
/* 1650 */               if (!"".equals(typeid) && modeset != null) {
/* 1651 */                 this.fPreferredDelegates.add(new PreferredDelegate(delegate, typeid, modeset));
/*      */               }
/*      */             }
/*      */           } 
/*      */         } catch (CoreException e) {
/* 1656 */           DebugPlugin.log((Throwable)e);
/*      */         } 
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void resetPreferredDelegates() {
/* 1668 */     this.fPreferredDelegates = null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected ILaunchDelegate getPreferredDelegate(String typeid, Set<String> modes) {
/* 1682 */     initializePreferredDelegates();
/* 1683 */     for (PreferredDelegate pd : this.fPreferredDelegates) {
/* 1684 */       if (pd.getModes().equals(modes) && pd.getTypeId().equals(typeid)) {
/* 1685 */         return pd.getDelegate();
/*      */       }
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1692 */     String preferred = Platform.getPreferencesService().getString(DebugPlugin.getUniqueIdentifier(), "//" + PREF_PREFERRED_DELEGATES + '/' + typeid, "", null);
/* 1693 */     if (preferred != null && preferred.length() != 0) {
/* 1694 */       StringTokenizer tokenizer = new StringTokenizer(preferred, ";");
/* 1695 */       while (tokenizer.hasMoreTokens()) {
/* 1696 */         StringTokenizer tokenizer2 = new StringTokenizer(tokenizer.nextToken(), ",");
/* 1697 */         String delegateId = tokenizer2.nextToken();
/* 1698 */         HashSet<String> modeset = new HashSet<>();
/* 1699 */         while (tokenizer2.hasMoreTokens()) {
/* 1700 */           modeset.add(tokenizer2.nextToken());
/*      */         }
/* 1702 */         LaunchDelegate delegate = getLaunchDelegateExtension(typeid, delegateId, modeset);
/* 1703 */         if (delegate != null && modeset.equals(modes)) {
/* 1704 */           return delegate;
/*      */         }
/*      */       } 
/*      */     } 
/*      */     
/* 1709 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private LaunchDelegate getLaunchDelegateExtension(String typeId, String id, Set<String> modeset) {
/*      */     byte b;
/*      */     int i;
/*      */     LaunchDelegate[] arrayOfLaunchDelegate;
/* 1725 */     for (i = (arrayOfLaunchDelegate = getLaunchDelegates(typeId)).length, b = 0; b < i; ) { LaunchDelegate extension = arrayOfLaunchDelegate[b];
/* 1726 */       if (id.equals(extension.getId())) {
/* 1727 */         List<Set<String>> modesets = extension.getModes();
/* 1728 */         if (modesets.contains(modeset))
/* 1729 */           return extension; 
/*      */       } 
/*      */       b++; }
/*      */     
/* 1733 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected synchronized List<ILaunchConfiguration> getLocalLaunchConfigurations() {
/* 1742 */     List<ILaunchConfiguration> configs = new ArrayList<>();
/* 1743 */     for (ILaunchConfiguration config : getAllLaunchConfigurations()) {
/* 1744 */       if (config.isLocal()) {
/* 1745 */         configs.add(config);
/*      */       }
/*      */     } 
/* 1748 */     return configs;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ILaunchConfiguration[] getMappedConfigurations(IResource resource) {
/* 1758 */     List<ILaunchConfiguration> configurations = new ArrayList<>();
/* 1759 */     for (ILaunchConfiguration config : getAllLaunchConfigurations()) {
/*      */       try {
/* 1761 */         IResource[] resources = config.getMappedResources();
/* 1762 */         if (resources != null) {
/* 1763 */           byte b; int i; IResource[] arrayOfIResource; for (i = (arrayOfIResource = resources).length, b = 0; b < i; ) { IResource res = arrayOfIResource[b];
/* 1764 */             if (res.equals(resource)) {
/* 1765 */               configurations.add(config); break;
/*      */             } 
/* 1767 */             if (resource.getType() == 4 && res.getType() == 1 && 
/* 1768 */               res.getProject().equals(resource)) {
/* 1769 */               configurations.add(config);
/*      */               break;
/*      */             } 
/*      */             b++; }
/*      */         
/*      */         } 
/* 1775 */       } catch (CoreException ce) {
/* 1776 */         DebugPlugin.log((Throwable)ce);
/*      */       } 
/*      */     } 
/* 1779 */     return configurations.<ILaunchConfiguration>toArray(new ILaunchConfiguration[configurations.size()]);
/*      */   }
/*      */ 
/*      */   
/*      */   public ILaunchConfiguration[] getMigrationCandidates() throws CoreException {
/* 1784 */     List<ILaunchConfiguration> configs = new ArrayList<>();
/* 1785 */     for (ILaunchConfiguration config : getAllLaunchConfigurations()) {
/* 1786 */       if (!config.isReadOnly() && config.isMigrationCandidate()) {
/* 1787 */         configs.add(config);
/*      */       }
/*      */     } 
/* 1790 */     return configs.<ILaunchConfiguration>toArray(new ILaunchConfiguration[configs.size()]);
/*      */   }
/*      */ 
/*      */   
/*      */   public ILaunchConfiguration getMovedFrom(ILaunchConfiguration addedConfiguration) {
/* 1795 */     if (addedConfiguration.equals(this.fTo)) {
/* 1796 */       return this.fFrom;
/*      */     }
/* 1798 */     return null;
/*      */   }
/*      */ 
/*      */   
/*      */   public ILaunchConfiguration getMovedTo(ILaunchConfiguration removedConfiguration) {
/* 1803 */     if (removedConfiguration.equals(this.fFrom)) {
/* 1804 */       return this.fTo;
/*      */     }
/* 1806 */     return null;
/*      */   }
/*      */ 
/*      */   
/*      */   public synchronized Map<String, String> getNativeEnvironment() {
/* 1811 */     if (fgNativeEnv == null) {
/* 1812 */       Map<String, String> casePreserved = getNativeEnvironmentCasePreserved();
/* 1813 */       if (Platform.getOS().equals("win32")) {
/* 1814 */         fgNativeEnv = new HashMap<>();
/* 1815 */         for (Map.Entry<String, String> entry : casePreserved.entrySet()) {
/* 1816 */           fgNativeEnv.put(((String)entry.getKey()).toUpperCase(), entry.getValue());
/*      */         }
/*      */       } else {
/* 1819 */         fgNativeEnv = new HashMap<>(casePreserved);
/*      */       } 
/*      */     } 
/* 1822 */     return new HashMap<>(fgNativeEnv);
/*      */   }
/*      */ 
/*      */   
/*      */   public synchronized Map<String, String> getNativeEnvironmentCasePreserved() {
/* 1827 */     if (fgNativeEnvCasePreserved == null) {
/* 1828 */       fgNativeEnvCasePreserved = new HashMap<>();
/* 1829 */       cacheNativeEnvironment(fgNativeEnvCasePreserved);
/*      */     } 
/* 1831 */     return new HashMap<>(fgNativeEnvCasePreserved);
/*      */   }
/*      */ 
/*      */   
/*      */   public IProcess[] getProcesses() {
/* 1836 */     synchronized (this.fLaunches) {
/* 1837 */       List<IProcess> allProcesses = new ArrayList<>(this.fLaunches.size());
/* 1838 */       IProcess[] processes = null;
/* 1839 */       for (ILaunch launch : this.fLaunches) {
/* 1840 */         processes = launch.getProcesses();
/* 1841 */         Collections.addAll(allProcesses, processes);
/*      */       } 
/* 1843 */       return allProcesses.<IProcess>toArray(new IProcess[allProcesses.size()]);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public ISourceContainerType getSourceContainerType(String id) {
/* 1849 */     initializeSourceContainerTypes();
/* 1850 */     return this.sourceContainerTypes.get(id);
/*      */   }
/*      */ 
/*      */   
/*      */   public ISourceContainerType[] getSourceContainerTypes() {
/* 1855 */     initializeSourceContainerTypes();
/* 1856 */     Collection<ISourceContainerType> containers = this.sourceContainerTypes.values();
/* 1857 */     return containers.<ISourceContainerType>toArray(new ISourceContainerType[containers.size()]);
/*      */   }
/*      */ 
/*      */   
/*      */   public ISourcePathComputer getSourcePathComputer(ILaunchConfiguration configuration) throws CoreException {
/* 1862 */     String id = null;
/* 1863 */     id = configuration.getAttribute(ISourcePathComputer.ATTR_SOURCE_PATH_COMPUTER_ID, null);
/*      */     
/* 1865 */     if (id == null)
/*      */     {
/* 1867 */       return configuration.getType().getSourcePathComputer();
/*      */     }
/* 1869 */     return getSourcePathComputer(id);
/*      */   }
/*      */ 
/*      */   
/*      */   public ISourcePathComputer getSourcePathComputer(String id) {
/* 1874 */     initializeSourceContainerTypes();
/* 1875 */     return this.sourcePathComputers.get(id);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private synchronized void hookResourceChangeListener() {
/* 1882 */     if (!this.fListening) {
/* 1883 */       ResourcesPlugin.getWorkspace().addResourceChangeListener(this, 5);
/* 1884 */       this.fListening = true;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private synchronized void initializeComparators() {
/* 1892 */     if (this.fComparators == null) {
/* 1893 */       IExtensionPoint extensionPoint = Platform.getExtensionRegistry().getExtensionPoint(DebugPlugin.getUniqueIdentifier(), "launchConfigurationComparators");
/* 1894 */       IConfigurationElement[] infos = extensionPoint.getConfigurationElements();
/* 1895 */       this.fComparators = new HashMap<>(infos.length);
/* 1896 */       IConfigurationElement configurationElement = null;
/* 1897 */       String attr = null; byte b; int i; IConfigurationElement[] arrayOfIConfigurationElement1;
/* 1898 */       for (i = (arrayOfIConfigurationElement1 = infos).length, b = 0; b < i; ) { IConfigurationElement info = arrayOfIConfigurationElement1[b];
/* 1899 */         configurationElement = info;
/* 1900 */         attr = configurationElement.getAttribute("attribute");
/* 1901 */         if (attr != null) {
/* 1902 */           this.fComparators.put(attr, new LaunchConfigurationComparator(configurationElement));
/*      */         } else {
/*      */           
/* 1905 */           Status status = new Status(4, DebugPlugin.getUniqueIdentifier(), 5013, 
/* 1906 */               MessageFormat.format("Invalid launch configuration comparator extension defined by plug-in {0} - attribute not specified.", new Object[] { configurationElement.getContributor().getName() }), null);
/* 1907 */           DebugPlugin.log((IStatus)status);
/*      */         } 
/*      */         b++; }
/*      */     
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private synchronized void initializeLaunchConfigurationTypes() {
/* 1917 */     if (this.fLaunchConfigurationTypes == null) {
/* 1918 */       hookResourceChangeListener();
/* 1919 */       IExtensionPoint extensionPoint = Platform.getExtensionRegistry().getExtensionPoint(DebugPlugin.getUniqueIdentifier(), "launchConfigurationTypes");
/* 1920 */       IConfigurationElement[] infos = extensionPoint.getConfigurationElements();
/* 1921 */       this.fLaunchConfigurationTypes = new ArrayList<>(infos.length); byte b; int i; IConfigurationElement[] arrayOfIConfigurationElement1;
/* 1922 */       for (i = (arrayOfIConfigurationElement1 = infos).length, b = 0; b < i; ) { IConfigurationElement info = arrayOfIConfigurationElement1[b];
/* 1923 */         this.fLaunchConfigurationTypes.add(new LaunchConfigurationType(info));
/*      */         b++; }
/*      */     
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private synchronized void initializeLaunchModes() {
/* 1932 */     if (this.fLaunchModes == null) {
/*      */       try {
/* 1934 */         IExtensionPoint extensionPoint = Platform.getExtensionRegistry().getExtensionPoint(DebugPlugin.getUniqueIdentifier(), "launchModes");
/* 1935 */         IConfigurationElement[] infos = extensionPoint.getConfigurationElements();
/* 1936 */         this.fLaunchModes = new HashMap<>();
/* 1937 */         ILaunchMode mode = null; byte b; int i; IConfigurationElement[] arrayOfIConfigurationElement1;
/* 1938 */         for (i = (arrayOfIConfigurationElement1 = infos).length, b = 0; b < i; ) { IConfigurationElement info = arrayOfIConfigurationElement1[b];
/* 1939 */           mode = new LaunchMode(info);
/* 1940 */           this.fLaunchModes.put(mode.getIdentifier(), mode); b++; }
/*      */       
/*      */       } catch (CoreException e) {
/* 1943 */         DebugPlugin.log((Throwable)e);
/*      */       } 
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private synchronized void initializeSourceContainerTypes() {
/* 1951 */     if (this.sourceContainerTypes == null) {
/* 1952 */       IExtensionPoint extensionPoint = Platform.getExtensionRegistry().getExtensionPoint(DebugPlugin.getUniqueIdentifier(), "sourceContainerTypes");
/* 1953 */       IConfigurationElement[] extensions = extensionPoint.getConfigurationElements();
/* 1954 */       this.sourceContainerTypes = new HashMap<>(); byte b; int i; IConfigurationElement[] arrayOfIConfigurationElement1;
/* 1955 */       for (i = (arrayOfIConfigurationElement1 = extensions).length, b = 0; b < i; ) { IConfigurationElement extension = arrayOfIConfigurationElement1[b];
/* 1956 */         this.sourceContainerTypes.put(
/* 1957 */             extension.getAttribute("id"), 
/* 1958 */             new SourceContainerType(extension)); b++; }
/*      */       
/* 1960 */       extensionPoint = Platform.getExtensionRegistry().getExtensionPoint(DebugPlugin.getUniqueIdentifier(), "sourcePathComputers");
/* 1961 */       extensions = extensionPoint.getConfigurationElements();
/* 1962 */       this.sourcePathComputers = new HashMap<>();
/* 1963 */       for (i = (arrayOfIConfigurationElement1 = extensions).length, b = 0; b < i; ) { IConfigurationElement extension = arrayOfIConfigurationElement1[b];
/* 1964 */         this.sourcePathComputers.put(
/* 1965 */             extension.getAttribute("id"), 
/* 1966 */             new SourcePathComputer(extension));
/*      */         b++; }
/*      */     
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private synchronized void initializeSourceLocators() {
/* 1975 */     if (this.fSourceLocators == null) {
/* 1976 */       IExtensionPoint extensionPoint = Platform.getExtensionRegistry().getExtensionPoint(DebugPlugin.getUniqueIdentifier(), "sourceLocators");
/* 1977 */       IConfigurationElement[] infos = extensionPoint.getConfigurationElements();
/* 1978 */       this.fSourceLocators = new HashMap<>(infos.length);
/* 1979 */       IConfigurationElement configurationElement = null;
/* 1980 */       String id = null; byte b; int i; IConfigurationElement[] arrayOfIConfigurationElement1;
/* 1981 */       for (i = (arrayOfIConfigurationElement1 = infos).length, b = 0; b < i; ) { IConfigurationElement info = arrayOfIConfigurationElement1[b];
/* 1982 */         configurationElement = info;
/* 1983 */         id = configurationElement.getAttribute("id");
/* 1984 */         if (id != null) {
/* 1985 */           this.fSourceLocators.put(id, configurationElement);
/*      */         } else {
/*      */           
/* 1988 */           Status status = new Status(4, DebugPlugin.getUniqueIdentifier(), 5013, 
/* 1989 */               MessageFormat.format("Invalid source locator extension defined by plug-in \"{0}\": \"id\" not specified.", new Object[] { configurationElement.getContributor().getName() }), null);
/* 1990 */           DebugPlugin.log((IStatus)status);
/*      */         } 
/*      */         b++; }
/*      */     
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean internalAddLaunch(ILaunch launch) {
/* 2005 */     getStepFilterManager();
/* 2006 */     synchronized (this.fLaunches) {
/* 2007 */       if (this.fLaunches.contains(launch)) {
/* 2008 */         return false;
/*      */       }
/* 2010 */       this.fLaunches.add(launch);
/* 2011 */       this.fLaunchSet.add(launch);
/* 2012 */       return true;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean internalRemoveLaunch(ILaunch launch) {
/* 2024 */     if (launch == null) {
/* 2025 */       return false;
/*      */     }
/* 2027 */     synchronized (this.fLaunches) {
/* 2028 */       this.fLaunchSet.remove(launch);
/* 2029 */       return this.fLaunches.remove(launch);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isExistingLaunchConfigurationName(String name) {
/* 2035 */     String[] sortedConfigNames = getAllSortedConfigNames();
/* 2036 */     int index = Arrays.binarySearch((Object[])sortedConfigNames, name);
/* 2037 */     if (index < 0) {
/* 2038 */       return false;
/*      */     }
/* 2040 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean isNumber(String string) {
/* 2049 */     int numChars = string.length();
/* 2050 */     if (numChars == 0) {
/* 2051 */       return false;
/*      */     }
/* 2053 */     for (int i = 0; i < numChars; i++) {
/* 2054 */       if (!Character.isDigit(string.charAt(i))) {
/* 2055 */         return false;
/*      */       }
/*      */     } 
/* 2058 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean isDeleteConfigurations() {
/* 2068 */     return Platform.getPreferencesService().getBoolean(DebugPlugin.getUniqueIdentifier(), "org.eclipse.debug.core.PREF_DELETE_CONFIGS_ON_PROJECT_DELETE", true, null);
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isRegistered(ILaunch launch) {
/* 2073 */     synchronized (this.fLaunches) {
/* 2074 */       return this.fLaunchSet.contains(launch);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean isValid(ILaunchConfiguration config) {
/*      */     try {
/* 2087 */       config.getType();
/* 2088 */     } catch (CoreException e) {
/* 2089 */       if (e.getStatus().getCode() != 5020)
/*      */       {
/*      */         
/* 2092 */         DebugPlugin.log((Throwable)e);
/*      */       }
/* 2094 */       return false;
/*      */     } 
/* 2096 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void launchConfigurationAdded(ILaunchConfiguration config) {
/* 2107 */     if (config.isWorkingCopy()) {
/*      */       return;
/*      */     }
/* 2110 */     if (isValid(config)) {
/* 2111 */       boolean added = false;
/* 2112 */       synchronized (this) {
/* 2113 */         List<ILaunchConfiguration> allConfigs = getAllLaunchConfigurations();
/* 2114 */         if (!allConfigs.contains(config)) {
/* 2115 */           allConfigs.add(config);
/* 2116 */           added = true;
/*      */         } 
/*      */       } 
/* 2119 */       if (added) {
/* 2120 */         getConfigurationNotifier().notify(config, 0);
/* 2121 */         clearConfigNameCache();
/*      */       } 
/*      */     } else {
/* 2124 */       launchConfigurationDeleted(config);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void launchConfigurationChanged(ILaunchConfiguration config) {
/* 2138 */     synchronized (this) {
/* 2139 */       this.fLaunchConfigurations.remove(config);
/*      */     } 
/* 2141 */     clearConfigNameCache();
/* 2142 */     if (isValid(config)) {
/*      */ 
/*      */ 
/*      */       
/* 2146 */       launchConfigurationAdded(config);
/* 2147 */       getConfigurationNotifier().notify(config, 2);
/*      */     } else {
/* 2149 */       launchConfigurationDeleted(config);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void launchConfigurationDeleted(ILaunchConfiguration config) {
/* 2162 */     boolean removed = false;
/* 2163 */     synchronized (this) {
/* 2164 */       Object key = this.fLaunchConfigurations.remove(config);
/* 2165 */       removed = (key != null);
/* 2166 */       getAllLaunchConfigurations().remove(config);
/*      */     } 
/* 2168 */     if (removed) {
/* 2169 */       getConfigurationNotifier().notify(config, 1);
/* 2170 */       clearConfigNameCache();
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public IPersistableSourceLocator newSourceLocator(String identifier) throws CoreException {
/* 2176 */     initializeSourceLocators();
/* 2177 */     IConfigurationElement config = this.fSourceLocators.get(identifier);
/* 2178 */     if (config == null) {
/* 2179 */       throw new CoreException(new Status(4, DebugPlugin.getUniqueIdentifier(), 5013, 
/* 2180 */             MessageFormat.format(DebugCoreMessages.LaunchManager_Source_locator_does_not_exist___0__13, new Object[] { identifier }), null));
/*      */     }
/* 2182 */     IPersistableSourceLocator sourceLocator = (IPersistableSourceLocator)config.createExecutableExtension("class");
/* 2183 */     if (sourceLocator instanceof AbstractSourceLookupDirector) {
/* 2184 */       ((AbstractSourceLookupDirector)sourceLocator).setId(identifier);
/*      */     }
/* 2186 */     return sourceLocator;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void projectClosed(IProject project) {
/* 2197 */     terminateMappedConfigurations((IResource)project);
/* 2198 */     for (ILaunchConfiguration config : getLaunchConfigurations(project)) {
/* 2199 */       launchConfigurationDeleted(config);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void projectOpened(IProject project) {
/* 2211 */     for (ILaunchConfiguration config : findLaunchConfigurations((IContainer)project)) {
/* 2212 */       launchConfigurationAdded(config);
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   public void removeLaunch(ILaunch launch) {
/* 2218 */     if (internalRemoveLaunch(launch)) {
/* 2219 */       fireUpdate(launch, 1);
/* 2220 */       fireUpdate(new ILaunch[] { launch }, 1);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public void removeLaunchConfigurationListener(ILaunchConfigurationListener listener) {
/* 2226 */     this.fLaunchConfigurationListeners.remove(listener);
/*      */   }
/*      */ 
/*      */   
/*      */   public void removeLaunches(ILaunch[] launches) {
/* 2231 */     List<ILaunch> removed = new ArrayList<>(launches.length); byte b; int i; ILaunch[] arrayOfILaunch;
/* 2232 */     for (i = (arrayOfILaunch = launches).length, b = 0; b < i; ) { ILaunch launch = arrayOfILaunch[b];
/* 2233 */       if (internalRemoveLaunch(launch))
/* 2234 */         removed.add(launch); 
/*      */       b++; }
/*      */     
/* 2237 */     if (!removed.isEmpty()) {
/* 2238 */       ILaunch[] removedLaunches = removed.<ILaunch>toArray(new ILaunch[removed.size()]);
/* 2239 */       fireUpdate(removedLaunches, 1); ILaunch[] arrayOfILaunch1;
/* 2240 */       for (int j = (arrayOfILaunch1 = removedLaunches).length; i < j; ) { ILaunch launch = arrayOfILaunch1[i];
/* 2241 */         fireUpdate(launch, 1);
/*      */         i++; }
/*      */     
/*      */     } 
/*      */   }
/*      */   
/*      */   public void removeLaunchListener(ILaunchesListener listener) {
/* 2248 */     this.fLaunchesListeners.remove(listener);
/*      */   }
/*      */ 
/*      */   
/*      */   public void removeLaunchListener(ILaunchListener listener) {
/* 2253 */     this.fListeners.remove(listener);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void resourceChanged(IResourceChangeEvent event) {
/* 2264 */     IResourceDelta delta = event.getDelta();
/* 2265 */     if (delta != null) {
/* 2266 */       LaunchManagerVisitor visitor = getDeltaVisitor();
/* 2267 */       MappedResourceVisitor v = null;
/* 2268 */       if (isDeleteConfigurations()) {
/* 2269 */         v = getMappedResourceVisitor();
/*      */       }
/*      */       try {
/* 2272 */         delta.accept(visitor);
/* 2273 */         if (v != null) {
/* 2274 */           delta.accept(v);
/*      */         }
/* 2276 */       } catch (CoreException e) {
/* 2277 */         DebugPlugin.log(e.getStatus());
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private ArrayList<ILaunchConfiguration> collectAssociatedLaunches(IResource resource) {
/* 2291 */     ArrayList<ILaunchConfiguration> list = new ArrayList<>();
/*      */     try {
/* 2293 */       ILaunchConfiguration[] configs = DebugPlugin.getDefault().getLaunchManager().getLaunchConfigurations();
/* 2294 */       IResource[] resources = null; byte b; int i; ILaunchConfiguration[] arrayOfILaunchConfiguration1;
/* 2295 */       for (i = (arrayOfILaunchConfiguration1 = configs).length, b = 0; b < i; ) { ILaunchConfiguration config = arrayOfILaunchConfiguration1[b];
/* 2296 */         if (config.isLocal()) {
/* 2297 */           resources = config.getMappedResources();
/* 2298 */           if (resources != null) {
/* 2299 */             byte b1; int j; IResource[] arrayOfIResource; for (j = (arrayOfIResource = resources).length, b1 = 0; b1 < j; ) { IResource res = arrayOfIResource[b1];
/* 2300 */               if (resource.equals(res) || 
/* 2301 */                 resource.getFullPath().isPrefixOf(res.getFullPath())) {
/* 2302 */                 list.add(config); break;
/*      */               }  b1++; }
/*      */           
/*      */           } 
/*      */         } 
/*      */         b++; }
/*      */     
/* 2309 */     } catch (CoreException e) {
/* 2310 */       DebugPlugin.log((Throwable)e);
/*      */     } 
/* 2312 */     return list;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void setMovedFromTo(ILaunchConfiguration from, ILaunchConfiguration to) {
/* 2325 */     this.fFrom = from;
/* 2326 */     this.fTo = to;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void shutdown() {
/* 2333 */     this.fListeners = new ListenerList();
/* 2334 */     this.fLaunchesListeners = new ListenerList();
/* 2335 */     this.fLaunchConfigurationListeners = new ListenerList(); byte b; int i; ILaunch[] arrayOfILaunch;
/* 2336 */     for (i = (arrayOfILaunch = getLaunches()).length, b = 0; b < i; ) { ILaunch launch = arrayOfILaunch[b];
/* 2337 */       if (launch != null) {
/*      */         try {
/* 2339 */           if (launch instanceof IDisconnect) {
/* 2340 */             IDisconnect disconnect = (IDisconnect)launch;
/* 2341 */             if (disconnect.canDisconnect()) {
/* 2342 */               disconnect.disconnect();
/*      */             }
/*      */           } 
/* 2345 */           if (launch.canTerminate()) {
/* 2346 */             launch.terminate();
/*      */           }
/* 2348 */         } catch (DebugException e) {
/* 2349 */           DebugPlugin.log((Throwable)e);
/*      */         } 
/*      */       }
/*      */       b++; }
/*      */     
/* 2354 */     persistPreferredLaunchDelegates();
/* 2355 */     clearAllLaunchConfigurations();
/* 2356 */     this.fStepFilterManager = null;
/* 2357 */     ResourcesPlugin.getWorkspace().removeResourceChangeListener(this);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void persistPreferredLaunchDelegates() {
/* 2366 */     ILaunchConfigurationType[] types = getLaunchConfigurationTypes(); byte b; int i; ILaunchConfigurationType[] arrayOfILaunchConfigurationType1;
/* 2367 */     for (i = (arrayOfILaunchConfigurationType1 = types).length, b = 0; b < i; ) { ILaunchConfigurationType type = arrayOfILaunchConfigurationType1[b];
/* 2368 */       persistPreferredLaunchDelegate((LaunchConfigurationType)type);
/*      */       b++; }
/*      */   
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void persistPreferredLaunchDelegate(LaunchConfigurationType type) {
/* 2379 */     String preferenceName = String.valueOf(PREF_PREFERRED_DELEGATES) + '/' + type.getIdentifier();
/* 2380 */     Map<Set<String>, ILaunchDelegate> preferred = type.getPreferredDelegates();
/* 2381 */     if (preferred != null && preferred.size() > 0) {
/* 2382 */       StringBuilder str = new StringBuilder();
/* 2383 */       for (Map.Entry<Set<String>, ILaunchDelegate> entry : preferred.entrySet()) {
/* 2384 */         Set<String> modes = entry.getKey();
/* 2385 */         ILaunchDelegate delegate = entry.getValue();
/* 2386 */         if (delegate != null) {
/* 2387 */           str.append(delegate.getId());
/* 2388 */           str.append(',');
/* 2389 */           for (String mode : modes) {
/* 2390 */             str.append(mode).append(',');
/*      */           }
/* 2392 */           str.append(';');
/*      */         } 
/*      */       } 
/* 2395 */       Preferences.setString(DebugPlugin.getUniqueIdentifier(), preferenceName, str.toString(), null);
/*      */     } else {
/* 2397 */       Preferences.setToDefault(DebugPlugin.getUniqueIdentifier(), preferenceName);
/*      */     } 
/*      */ 
/*      */     
/* 2401 */     Preferences.setToDefault(DebugPlugin.getUniqueIdentifier(), PREF_PREFERRED_DELEGATES);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void terminateMappedConfigurations(IResource resource) {
/* 2410 */     ILaunch[] launches = getLaunches();
/* 2411 */     ILaunchConfiguration[] configs = getMappedConfigurations(resource); try {
/*      */       byte b; int i; ILaunch[] arrayOfILaunch;
/* 2413 */       for (i = (arrayOfILaunch = launches).length, b = 0; b < i; ) { ILaunch launch = arrayOfILaunch[b]; byte b1; int j; ILaunchConfiguration[] arrayOfILaunchConfiguration;
/* 2414 */         for (j = (arrayOfILaunchConfiguration = configs).length, b1 = 0; b1 < j; ) { ILaunchConfiguration config = arrayOfILaunchConfiguration[b1];
/* 2415 */           if (config.equals(launch.getLaunchConfiguration()) && launch.canTerminate())
/* 2416 */             launch.terminate();  b1++; }
/*      */         
/*      */         b++; }
/*      */     
/*      */     } catch (CoreException e) {
/* 2421 */       DebugPlugin.log((Throwable)e);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void throwException(LaunchConfiguration config, Throwable e) throws DebugException {
/* 2433 */     String uri = config.getName();
/*      */     try {
/* 2435 */       IFileStore store = config.getFileStore();
/* 2436 */       if (store != null) {
/* 2437 */         uri = store.toString();
/*      */       }
/* 2439 */     } catch (CoreException coreException) {}
/*      */     
/* 2441 */     throw createDebugException(MessageFormat.format(DebugCoreMessages.LaunchManager__0__occurred_while_reading_launch_configuration_file__1___1, new Object[] {
/* 2442 */             e.toString(), uri }), e);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void verifyConfigurations(List<ILaunchConfiguration> verify, List<ILaunchConfiguration> valid) {
/* 2454 */     for (ILaunchConfiguration config : verify) {
/* 2455 */       if (!valid.contains(config) && isValid(config)) {
/* 2456 */         valid.add(config);
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getLaunchModeName(String id) {
/* 2469 */     ILaunchMode launchMode = getLaunchMode(id);
/* 2470 */     if (launchMode != null) {
/* 2471 */       return removeAccelerators(launchMode.getLabel());
/*      */     }
/* 2473 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String removeAccelerators(String label) {
/* 2482 */     String title = label;
/* 2483 */     if (title != null) {
/*      */       
/* 2485 */       int index = title.indexOf('&');
/* 2486 */       if (index == 0) {
/* 2487 */         title = title.substring(1);
/* 2488 */       } else if (index > 0) {
/*      */         
/* 2490 */         if (title.charAt(index - 1) == '(' && title.length() >= index + 3 && title.charAt(index + 2) == ')') {
/* 2491 */           String first = title.substring(0, index - 1);
/* 2492 */           String last = title.substring(index + 3);
/* 2493 */           title = String.valueOf(first) + last;
/* 2494 */         } else if (index < title.length() - 1) {
/* 2495 */           String first = title.substring(0, index);
/* 2496 */           String last = title.substring(index + 1);
/* 2497 */           title = String.valueOf(first) + last;
/*      */         } 
/*      */       } 
/*      */     } 
/* 2501 */     return title;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized StepFilterManager getStepFilterManager() {
/* 2510 */     if (this.fStepFilterManager == null) {
/* 2511 */       this.fStepFilterManager = new StepFilterManager();
/*      */     }
/* 2513 */     return this.fStepFilterManager;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void importConfigurations(File[] files, IProgressMonitor monitor) throws CoreException {
/* 2530 */     Map<String, ILaunchConfiguration> sharedConfigs = new HashMap<>();
/* 2531 */     for (ILaunchConfiguration config : getAllLaunchConfigurations()) {
/* 2532 */       if (!config.isLocal()) {
/* 2533 */         StringBuilder buf = new StringBuilder(config.getName());
/* 2534 */         buf.append('.');
/* 2535 */         if (config.isPrototype()) {
/* 2536 */           buf.append("prototype");
/*      */         } else {
/* 2538 */           buf.append("launch");
/*      */         } 
/* 2540 */         sharedConfigs.put(buf.toString(), config);
/*      */       } 
/*      */     } 
/* 2543 */     List<Status> stati = null;
/* 2544 */     SubMonitor lmonitor = SubMonitor.convert(monitor, DebugCoreMessages.LaunchManager_29, files.length); byte b; int i; File[] arrayOfFile;
/* 2545 */     for (i = (arrayOfFile = files).length, b = 0; b < i; ) { File source = arrayOfFile[b];
/* 2546 */       if (lmonitor.isCanceled()) {
/*      */         break;
/*      */       }
/* 2549 */       lmonitor.subTask(MessageFormat.format(DebugCoreMessages.LaunchManager_28, new Object[] { source.getName() }));
/* 2550 */       IPath location = (new Path(LOCAL_LAUNCH_CONFIGURATION_CONTAINER_PATH.toOSString())).append(source.getName());
/* 2551 */       File target = location.toFile();
/* 2552 */       IPath locationdir = location.removeLastSegments(1);
/* 2553 */       if (!locationdir.toFile().exists()) {
/* 2554 */         locationdir.toFile().mkdirs();
/*      */       }
/* 2556 */       boolean added = !target.exists();
/*      */       try {
/* 2558 */         copyFile(source, target);
/* 2559 */         ILaunchConfiguration configuration = new LaunchConfiguration(LaunchConfiguration.getSimpleName(source.getName()), null, isPrototype(source));
/* 2560 */         ILaunchConfiguration shared = sharedConfigs.get(target.getName());
/* 2561 */         if (shared != null) {
/* 2562 */           setMovedFromTo(shared, configuration);
/* 2563 */           shared.delete();
/* 2564 */           launchConfigurationChanged(configuration);
/* 2565 */         } else if (added) {
/* 2566 */           launchConfigurationAdded(configuration);
/*      */         } else {
/* 2568 */           launchConfigurationChanged(configuration);
/*      */         } 
/* 2570 */       } catch (IOException e) {
/* 2571 */         if (stati == null) {
/* 2572 */           stati = new ArrayList<>();
/*      */         }
/* 2574 */         stati.add(new Status(4, DebugPlugin.getUniqueIdentifier(), 125, 
/* 2575 */               MessageFormat.format(DebugCoreMessages.LaunchManager_27, new Object[] { source.getPath() }), e));
/*      */       } 
/* 2577 */       lmonitor.worked(1); b++; }
/*      */     
/* 2579 */     if (!lmonitor.isCanceled()) {
/* 2580 */       lmonitor.done();
/*      */     }
/* 2582 */     if (stati != null) {
/* 2583 */       if (stati.size() > 1) {
/* 2584 */         MultiStatus multi = new MultiStatus(DebugPlugin.getUniqueIdentifier(), 125, DebugCoreMessages.LaunchManager_26, null);
/* 2585 */         for (Status status : stati) {
/* 2586 */           multi.add((IStatus)status);
/*      */         }
/* 2588 */         throw new CoreException(multi);
/*      */       } 
/* 2590 */       throw new CoreException((IStatus)stati.get(0));
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void copyFile(File in, File out) throws IOException {
/* 2604 */     Exception exception1 = null, exception2 = null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized boolean launchModeAvailable(String mode) {
/* 2620 */     if (this.fActiveModes == null) {
/* 2621 */       this.fActiveModes = new HashSet<>(3); byte b; int i; ILaunchConfigurationType[] arrayOfILaunchConfigurationType;
/* 2622 */       for (i = (arrayOfILaunchConfigurationType = getLaunchConfigurationTypes()).length, b = 0; b < i; ) { ILaunchConfigurationType type = arrayOfILaunchConfigurationType[b]; byte b1; int j; ILaunchMode[] arrayOfILaunchMode;
/* 2623 */         for (j = (arrayOfILaunchMode = getLaunchModes()).length, b1 = 0; b1 < j; ) { ILaunchMode launchMode = arrayOfILaunchMode[b1];
/* 2624 */           if (type.supportsMode(launchMode.getIdentifier()))
/* 2625 */             this.fActiveModes.add(launchMode.getIdentifier());  b1++; }
/*      */         
/*      */         b++; }
/*      */     
/*      */     } 
/* 2630 */     return this.fActiveModes.contains(mode);
/*      */   }
/*      */ 
/*      */   
/*      */   public String generateLaunchConfigurationName(String namePrefix) {
/* 2635 */     String name = generateUniqueLaunchConfigurationNameFrom(namePrefix);
/*      */     try {
/* 2637 */       isValidLaunchConfigurationName(name);
/* 2638 */       return name;
/*      */     }
/* 2640 */     catch (IllegalArgumentException illegalArgumentException) {
/*      */       
/* 2642 */       if ("win32".equals(Platform.getOS())) {
/* 2643 */         byte b1; int j; String[] arrayOfString; for (j = (arrayOfString = UNSUPPORTED_WIN32_CONFIG_NAMES).length, b1 = 0; b1 < j; ) { String element = arrayOfString[b1];
/* 2644 */           if (element.equals(name))
/* 2645 */             name = "launch_configuration";  b1++; }
/*      */       
/*      */       }  byte b;
/*      */       int i;
/*      */       char[] arrayOfChar;
/* 2650 */       for (i = (arrayOfChar = DISALLOWED_CONFIG_NAME_CHARS).length, b = 0; b < i; ) { char element = arrayOfChar[b];
/* 2651 */         name = name.replace(element, '_');
/*      */         
/*      */         b++; }
/*      */       
/* 2655 */       return generateUniqueLaunchConfigurationNameFrom(name);
/*      */     } 
/*      */   }
/*      */   
/*      */   public boolean isValidLaunchConfigurationName(String configname) throws IllegalArgumentException {
/* 2660 */     if ("win32".equals(Platform.getOS())) {
/* 2661 */       byte b1; int j; String[] arrayOfString; for (j = (arrayOfString = UNSUPPORTED_WIN32_CONFIG_NAMES).length, b1 = 0; b1 < j; ) { String element = arrayOfString[b1];
/* 2662 */         if (configname.equals(element))
/* 2663 */           throw new IllegalArgumentException(MessageFormat.format(DebugCoreMessages.LaunchManager_invalid_config_name, new Object[] { configname }));  b1++; }
/*      */     
/*      */     }  byte b; int i;
/*      */     char[] arrayOfChar;
/* 2667 */     for (i = (arrayOfChar = DISALLOWED_CONFIG_NAME_CHARS).length, b = 0; b < i; ) { char element = arrayOfChar[b];
/* 2668 */       if (configname.indexOf(element) > -1)
/* 2669 */         throw new IllegalArgumentException(MessageFormat.format(DebugCoreMessages.LaunchManager_invalid_config_name_char, new Object[] { String.valueOf(element) })); 
/*      */       b++; }
/*      */     
/* 2672 */     return true;
/*      */   }
/*      */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.debug.core-3.21.0.jar!\org\eclipse\debug\internal\core\LaunchManager.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */