/*    */ package org.eclipse.debug.internal.core.groups;
/*    */ 
/*    */ import org.eclipse.debug.internal.core.DebugCoreMessages;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum GroupElementPostLaunchAction
/*    */ {
/* 38 */   NONE(DebugCoreMessages.GroupLaunchConfigurationDelegate_None),
/* 39 */   WAIT_FOR_TERMINATION(DebugCoreMessages.GroupLaunchConfigurationDelegate_Wait_until_terminated),
/* 40 */   DELAY(DebugCoreMessages.GroupLaunchConfigurationDelegate_Delay),
/* 41 */   OUTPUT_REGEXP(DebugCoreMessages.GroupLaunchElement_outputRegexp);
/*    */   
/*    */   private final String description;
/*    */   
/*    */   GroupElementPostLaunchAction(String description) {
/* 46 */     this.description = description;
/*    */   }
/*    */   
/*    */   public String getDescription() {
/* 50 */     return this.description; } public static GroupElementPostLaunchAction valueOfDescription(String desc) {
/*    */     byte b;
/*    */     int i;
/*    */     GroupElementPostLaunchAction[] arrayOfGroupElementPostLaunchAction;
/* 54 */     for (i = (arrayOfGroupElementPostLaunchAction = values()).length, b = 0; b < i; ) { GroupElementPostLaunchAction e = arrayOfGroupElementPostLaunchAction[b];
/* 55 */       if (e.description.equals(desc))
/* 56 */         return e; 
/*    */       b++; }
/*    */     
/* 59 */     return NONE;
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.debug.core-3.21.0.jar!\org\eclipse\debug\internal\core\groups\GroupLaunchElement$GroupElementPostLaunchAction.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */