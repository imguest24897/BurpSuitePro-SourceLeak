/*     */ package org.eclipse.debug.internal.core;
/*     */ 
/*     */ import org.eclipse.debug.core.DebugException;
/*     */ import org.eclipse.debug.core.model.IValue;
/*     */ import org.eclipse.debug.core.model.IWatchExpressionResult;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class null
/*     */   implements IWatchExpressionResult
/*     */ {
/*     */   public IValue getValue() {
/*  84 */     return null;
/*     */   }
/*     */   
/*     */   public boolean hasErrors() {
/*  88 */     return true;
/*     */   }
/*     */   
/*     */   public String[] getErrorMessages() {
/*  92 */     return new String[] { DebugCoreMessages.WatchExpression_0 };
/*     */   }
/*     */   
/*     */   public String getExpressionText() {
/*  96 */     return WatchExpression.this.getExpressionText();
/*     */   }
/*     */   
/*     */   public DebugException getException() {
/* 100 */     return null;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.debug.core-3.21.0.jar!\org\eclipse\debug\internal\core\WatchExpression$1.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */