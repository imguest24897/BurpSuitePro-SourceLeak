/*    */ package org.eclipse.debug.internal.core;
/*    */ 
/*    */ import java.util.Hashtable;
/*    */ import org.eclipse.debug.core.DebugPlugin;
/*    */ import org.eclipse.osgi.service.debug.DebugOptionsListener;
/*    */ import org.eclipse.osgi.service.debug.DebugTrace;
/*    */ import org.osgi.framework.BundleContext;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DebugOptions
/*    */   implements DebugOptionsListener
/*    */ {
/*    */   public static boolean DEBUG = false;
/*    */   public static boolean DEBUG_COMMANDS = false;
/*    */   public static boolean DEBUG_EVENTS = false;
/*    */   static final String DEBUG_FLAG = "org.eclipse.debug.core/debug";
/*    */   static final String DEBUG_FLAG_COMMANDS = "org.eclipse.debug.core/debug/commands";
/*    */   static final String DEBUG_FLAG_EVENTS = "org.eclipse.debug.core/debug/events";
/*    */   private static DebugTrace fgDebugTrace;
/*    */   
/*    */   public DebugOptions(BundleContext context) {
/* 50 */     Hashtable<String, String> props = new Hashtable<>(2);
/* 51 */     props.put("listener.symbolic.name", DebugPlugin.getUniqueIdentifier());
/* 52 */     context.registerService(DebugOptionsListener.class.getName(), this, props);
/*    */   }
/*    */ 
/*    */   
/*    */   public void optionsChanged(org.eclipse.osgi.service.debug.DebugOptions options) {
/* 57 */     fgDebugTrace = options.newDebugTrace(DebugPlugin.getUniqueIdentifier());
/* 58 */     DEBUG = options.getBooleanOption("org.eclipse.debug.core/debug", false);
/* 59 */     DEBUG_COMMANDS = (DEBUG && options.getBooleanOption("org.eclipse.debug.core/debug/commands", false));
/* 60 */     DEBUG_EVENTS = (DEBUG && options.getBooleanOption("org.eclipse.debug.core/debug/events", false));
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static void trace(String option, String message, Throwable throwable) {
/* 71 */     System.out.println(message);
/* 72 */     if (fgDebugTrace != null) {
/* 73 */       fgDebugTrace.trace(option, message, throwable);
/*    */     }
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static void trace(String message) {
/* 84 */     trace(null, message, null);
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.debug.core-3.21.0.jar!\org\eclipse\debug\internal\core\DebugOptions.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */