package org.eclipse.debug.core;

import org.eclipse.debug.core.model.IExpression;
import org.eclipse.debug.core.model.IWatchExpression;
import org.eclipse.debug.core.model.IWatchExpressionDelegate;

public interface IExpressionManager {
  void addExpression(IExpression paramIExpression);
  
  void addExpressions(IExpression[] paramArrayOfIExpression);
  
  IWatchExpression newWatchExpression(String paramString);
  
  IExpression[] getExpressions();
  
  boolean hasExpressions();
  
  IExpression[] getExpressions(String paramString);
  
  void removeExpression(IExpression paramIExpression);
  
  void removeExpressions(IExpression[] paramArrayOfIExpression);
  
  void addExpressionListener(IExpressionListener paramIExpressionListener);
  
  void removeExpressionListener(IExpressionListener paramIExpressionListener);
  
  void addExpressionListener(IExpressionsListener paramIExpressionsListener);
  
  void removeExpressionListener(IExpressionsListener paramIExpressionsListener);
  
  IWatchExpressionDelegate newWatchExpressionDelegate(String paramString);
  
  boolean hasWatchExpressionDelegate(String paramString);
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.debug.core-3.21.0.jar!\org\eclipse\debug\core\IExpressionManager.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */