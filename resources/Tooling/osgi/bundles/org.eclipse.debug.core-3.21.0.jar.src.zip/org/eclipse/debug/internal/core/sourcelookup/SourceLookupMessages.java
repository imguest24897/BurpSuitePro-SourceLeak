/*    */ package org.eclipse.debug.internal.core.sourcelookup;
/*    */ 
/*    */ import org.eclipse.osgi.util.NLS;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SourceLookupMessages
/*    */   extends NLS
/*    */ {
/*    */   private static final String BUNDLE_NAME = "org.eclipse.debug.internal.core.sourcelookup.SourceLookupMessages";
/*    */   public static String AbstractSourceLookupDirector_11;
/*    */   public static String AbstractSourceLookupDirector_12;
/*    */   public static String AbstractSourceLookupDirector_13;
/*    */   public static String AbstractSourceLookupDirector_14;
/*    */   public static String Source_Lookup_Error;
/*    */   public static String ExternalArchiveSourceContainer_1;
/*    */   public static String ExternalArchiveSourceContainer_2;
/*    */   public static String ExternalArchiveSourceContainerType_10;
/*    */   public static String ExternalArchiveSourceContainerType_11;
/*    */   public static String ExternalArchiveSourceContainerType_12;
/*    */   public static String DefaultSourceContainer_0;
/*    */   public static String DefaultSourceContainerType_6;
/*    */   public static String DefaultSourceContainerType_7;
/*    */   public static String DirectorySourceContainerType_10;
/*    */   public static String DirectorySourceContainerType_11;
/*    */   public static String DirectorySourceContainerType_12;
/*    */   public static String FolderSourceContainerType_10;
/*    */   public static String FolderSourceContainerType_11;
/*    */   public static String FolderSourceContainerType_12;
/*    */   public static String LocalFileStorage_0;
/*    */   public static String ProjectSourceContainerType_10;
/*    */   public static String ProjectSourceContainerType_11;
/*    */   public static String ProjectSourceContainerType_12;
/*    */   public static String SourceContainerType_0;
/*    */   public static String WorkspaceSourceContainer_0;
/*    */   public static String WorkspaceSourceContainerType_3;
/*    */   public static String WorkspaceSourceContainerType_4;
/*    */   public static String ZipEntryStorage_0;
/*    */   public static String AbstractSourceLookupDirector_10;
/*    */   
/*    */   static {
/* 65 */     NLS.initializeMessages("org.eclipse.debug.internal.core.sourcelookup.SourceLookupMessages", SourceLookupMessages.class);
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.debug.core-3.21.0.jar!\org\eclipse\debug\internal\core\sourcelookup\SourceLookupMessages.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */