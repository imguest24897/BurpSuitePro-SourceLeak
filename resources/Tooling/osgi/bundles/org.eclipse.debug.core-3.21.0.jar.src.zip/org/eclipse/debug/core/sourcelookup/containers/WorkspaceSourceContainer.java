/*    */ package org.eclipse.debug.core.sourcelookup.containers;
/*    */ 
/*    */ import org.eclipse.core.resources.IProject;
/*    */ import org.eclipse.core.resources.ResourcesPlugin;
/*    */ import org.eclipse.core.runtime.CoreException;
/*    */ import org.eclipse.debug.core.DebugPlugin;
/*    */ import org.eclipse.debug.core.sourcelookup.ISourceContainer;
/*    */ import org.eclipse.debug.core.sourcelookup.ISourceContainerType;
/*    */ import org.eclipse.debug.internal.core.sourcelookup.SourceLookupMessages;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class WorkspaceSourceContainer
/*    */   extends CompositeSourceContainer
/*    */ {
/* 38 */   public static final String TYPE_ID = String.valueOf(DebugPlugin.getUniqueIdentifier()) + ".containerType.workspace";
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String getName() {
/* 45 */     return SourceLookupMessages.WorkspaceSourceContainer_0;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean equals(Object obj) {
/* 50 */     return obj instanceof WorkspaceSourceContainer;
/*    */   }
/*    */ 
/*    */   
/*    */   public int hashCode() {
/* 55 */     return ResourcesPlugin.getWorkspace().hashCode();
/*    */   }
/*    */ 
/*    */   
/*    */   public ISourceContainerType getType() {
/* 60 */     return getSourceContainerType(TYPE_ID);
/*    */   }
/*    */ 
/*    */   
/*    */   protected ISourceContainer[] createSourceContainers() throws CoreException {
/* 65 */     IProject[] projects = ResourcesPlugin.getWorkspace().getRoot().getProjects();
/* 66 */     ISourceContainer[] containers = new ISourceContainer[projects.length];
/* 67 */     for (int i = 0; i < projects.length; i++) {
/* 68 */       ISourceContainer container = new ProjectSourceContainer(projects[i], false);
/* 69 */       container.init(getDirector());
/* 70 */       containers[i] = container;
/*    */     } 
/* 72 */     return containers;
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.debug.core-3.21.0.jar!\org\eclipse\debug\core\sourcelookup\containers\WorkspaceSourceContainer.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */