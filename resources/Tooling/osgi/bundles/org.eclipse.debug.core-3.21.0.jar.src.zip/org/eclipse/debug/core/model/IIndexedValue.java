package org.eclipse.debug.core.model;

import org.eclipse.debug.core.DebugException;

public interface IIndexedValue extends IValue {
  IVariable getVariable(int paramInt) throws DebugException;
  
  IVariable[] getVariables(int paramInt1, int paramInt2) throws DebugException;
  
  int getSize() throws DebugException;
  
  int getInitialOffset();
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.debug.core-3.21.0.jar!\org\eclipse\debug\core\model\IIndexedValue.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */