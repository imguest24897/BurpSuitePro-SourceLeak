/*     */ package org.eclipse.debug.internal.core;
/*     */ 
/*     */ import org.eclipse.core.resources.IMarker;
/*     */ import org.eclipse.core.resources.IMarkerDelta;
/*     */ import org.eclipse.core.resources.IResourceDelta;
/*     */ import org.eclipse.core.resources.IResourceDeltaVisitor;
/*     */ import org.eclipse.core.runtime.CoreException;
/*     */ import org.eclipse.debug.core.model.IBreakpoint;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class PostChangeVisitor
/*     */   implements IResourceDeltaVisitor
/*     */ {
/*     */   public boolean visit(IResourceDelta delta) throws CoreException {
/* 230 */     if (delta == null)
/* 231 */       return false;  byte b; int i;
/*     */     IMarkerDelta[] arrayOfIMarkerDelta;
/* 233 */     for (i = (arrayOfIMarkerDelta = delta.getMarkerDeltas()).length, b = 0; b < i; ) { IMarkerDelta markerDelta = arrayOfIMarkerDelta[b];
/* 234 */       if (markerDelta.isSubtypeOf(IBreakpoint.BREAKPOINT_MARKER)) {
/* 235 */         IMarker marker; switch (markerDelta.getKind()) {
/*     */ 
/*     */ 
/*     */ 
/*     */           
/*     */           case 4:
/* 241 */             marker = markerDelta.getMarker();
/* 242 */             synchronized (BreakpointManager.this.fPostChangMarkersChanged) {
/* 243 */               if (!BreakpointManager.this.fPostBuildMarkersAdded.contains(marker)) {
/* 244 */                 BreakpointManager.this.fPostChangMarkersChanged.add(marker);
/*     */               }
/*     */             } 
/*     */             break;
/*     */         } 
/*     */       
/*     */       } 
/*     */       b++; }
/*     */     
/* 253 */     return true;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.debug.core-3.21.0.jar!\org\eclipse\debug\internal\core\BreakpointManager$PostChangeVisitor.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */