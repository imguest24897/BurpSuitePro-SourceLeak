/*    */ package org.eclipse.debug.internal.core.commands;
/*    */ 
/*    */ import org.eclipse.core.runtime.CoreException;
/*    */ import org.eclipse.debug.core.commands.IDebugCommandRequest;
/*    */ import org.eclipse.debug.core.commands.IResumeHandler;
/*    */ import org.eclipse.debug.core.model.ISuspendResume;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ResumeCommand
/*    */   extends SuspendCommand
/*    */   implements IResumeHandler
/*    */ {
/*    */   protected void execute(Object target) throws CoreException {
/* 30 */     ((ISuspendResume)target).resume();
/*    */   }
/*    */ 
/*    */   
/*    */   protected boolean isExecutable(Object target) {
/* 35 */     return ((ISuspendResume)target).canResume();
/*    */   }
/*    */ 
/*    */   
/*    */   protected Object getEnabledStateJobFamily(IDebugCommandRequest request) {
/* 40 */     return IResumeHandler.class;
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.debug.core-3.21.0.jar!\org\eclipse\debug\internal\core\commands\ResumeCommand.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */