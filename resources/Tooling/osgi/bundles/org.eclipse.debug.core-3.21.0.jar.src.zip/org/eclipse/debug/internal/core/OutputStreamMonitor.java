/*     */ package org.eclipse.debug.internal.core;
/*     */ 
/*     */ import java.io.BufferedInputStream;
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.nio.charset.Charset;
/*     */ import java.util.concurrent.atomic.AtomicBoolean;
/*     */ import org.eclipse.core.runtime.ISafeRunnable;
/*     */ import org.eclipse.core.runtime.ListenerList;
/*     */ import org.eclipse.core.runtime.SafeRunner;
/*     */ import org.eclipse.debug.core.DebugPlugin;
/*     */ import org.eclipse.debug.core.IBinaryStreamListener;
/*     */ import org.eclipse.debug.core.IStreamListener;
/*     */ import org.eclipse.debug.core.model.IBinaryStreamMonitor;
/*     */ import org.eclipse.debug.core.model.IStreamMonitor;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class OutputStreamMonitor
/*     */   implements IBinaryStreamMonitor
/*     */ {
/*     */   private static final int BUFFER_SIZE = 8192;
/*     */   private InputStream fStream;
/*  53 */   private ListenerList<IStreamListener> fListeners = new ListenerList();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  58 */   private ListenerList<IBinaryStreamListener> fBinaryListeners = new ListenerList();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ByteArrayOutputStream fContents;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private StreamDecoder fBufferedDecoder;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String fCachedDecodedContents;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Thread fThread;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean fKilled = false;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Charset fCharset;
/*     */ 
/*     */ 
/*     */   
/*     */   private StreamDecoder fDecoder;
/*     */ 
/*     */ 
/*     */   
/*     */   private final AtomicBoolean fDone;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public OutputStreamMonitor(InputStream stream, Charset charset) {
/* 102 */     this.fStream = (stream instanceof BufferedInputStream) ? stream : new BufferedInputStream(stream);
/* 103 */     this.fCharset = charset;
/* 104 */     this.fDecoder = new StreamDecoder((charset == null) ? Charset.defaultCharset() : charset);
/* 105 */     this.fDone = new AtomicBoolean(false);
/* 106 */     setBuffered(true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public OutputStreamMonitor(InputStream stream, String encoding) {
/* 120 */     this(stream, Charset.forName(encoding));
/*     */   }
/*     */ 
/*     */   
/*     */   public synchronized void addListener(IStreamListener listener) {
/* 125 */     this.fListeners.add(listener);
/*     */   }
/*     */ 
/*     */   
/*     */   public synchronized void addBinaryListener(IBinaryStreamListener listener) {
/* 130 */     this.fBinaryListeners.add(listener);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void close() {
/* 138 */     Thread thread = null;
/*     */     
/* 140 */     synchronized (this) {
/* 141 */       thread = this.fThread;
/* 142 */       this.fThread = null;
/*     */     } 
/*     */     
/* 145 */     if (thread != null) {
/*     */       try {
/* 147 */         thread.join();
/* 148 */       } catch (InterruptedException interruptedException) {}
/*     */ 
/*     */       
/* 151 */       this.fListeners.clear();
/* 152 */       this.fBinaryListeners.clear();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void fireStreamAppended(byte[] data, int offset, int length) {
/* 165 */     if (!this.fListeners.isEmpty()) {
/* 166 */       final String text = this.fDecoder.decode(data, offset, length);
/* 167 */       for (IStreamListener listener : this.fListeners) {
/* 168 */         SafeRunner.run(new ISafeRunnable()
/*     */             {
/*     */               public void run() throws Exception {
/* 171 */                 listener.streamAppended(text, (IStreamMonitor)OutputStreamMonitor.this);
/*     */               }
/*     */ 
/*     */               
/*     */               public void handleException(Throwable exception) {
/* 176 */                 DebugPlugin.log(exception);
/*     */               }
/*     */             });
/*     */       } 
/*     */     } 
/* 181 */     if (!this.fBinaryListeners.isEmpty()) {
/*     */       final byte[] validData;
/* 183 */       if (offset > 0 || length < data.length) {
/* 184 */         validData = new byte[length];
/* 185 */         System.arraycopy(data, offset, validData, 0, length);
/*     */       } else {
/* 187 */         validData = data;
/*     */       } 
/* 189 */       for (IBinaryStreamListener listener : this.fBinaryListeners) {
/* 190 */         SafeRunner.run(new ISafeRunnable()
/*     */             {
/*     */               public void run() throws Exception {
/* 193 */                 listener.streamAppended(validData, OutputStreamMonitor.this);
/*     */               }
/*     */ 
/*     */               
/*     */               public void handleException(Throwable exception) {
/* 198 */                 DebugPlugin.log(exception);
/*     */               }
/*     */             });
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public synchronized String getContents() {
/* 207 */     if (!isBuffered()) {
/* 208 */       return "";
/*     */     }
/* 210 */     if (this.fCachedDecodedContents != null) {
/* 211 */       return this.fCachedDecodedContents;
/*     */     }
/* 213 */     byte[] data = getData();
/* 214 */     this.fCachedDecodedContents = this.fBufferedDecoder.decode(data, 0, data.length);
/* 215 */     return this.fCachedDecodedContents;
/*     */   }
/*     */ 
/*     */   
/*     */   public synchronized byte[] getData() {
/* 220 */     return isBuffered() ? this.fContents.toByteArray() : new byte[0];
/*     */   }
/*     */   
/*     */   private void read() {
/*     */     try {
/* 225 */       internalRead();
/*     */     } finally {
/* 227 */       this.fDone.set(true);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void internalRead() {
/* 239 */     long lastSleep = System.currentTimeMillis();
/* 240 */     long currentTime = lastSleep;
/* 241 */     byte[] buffer = new byte[8192];
/* 242 */     int read = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     try {  }
/*     */     finally
/*     */     { 
/* 282 */       try { this.fStream.close(); }
/* 283 */       catch (IOException e)
/* 284 */       { DebugPlugin.log(e); }  }  try { this.fStream.close(); } catch (IOException e) { DebugPlugin.log(e); }
/*     */   
/*     */   }
/*     */ 
/*     */   
/*     */   protected void kill() {
/* 290 */     this.fKilled = true;
/*     */   }
/*     */ 
/*     */   
/*     */   public synchronized void removeListener(IStreamListener listener) {
/* 295 */     this.fListeners.remove(listener);
/*     */   }
/*     */ 
/*     */   
/*     */   public synchronized void removeBinaryListener(IBinaryStreamListener listener) {
/* 300 */     this.fBinaryListeners.remove(listener);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void startMonitoring(String name) {
/* 309 */     synchronized (this) {
/* 310 */       if (this.fThread == null) {
/* 311 */         this.fDone.set(false);
/* 312 */         this.fThread = new Thread(this::read, name);
/* 313 */         this.fThread.setDaemon(true);
/* 314 */         this.fThread.setPriority(1);
/* 315 */         this.fThread.start();
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public synchronized void setBuffered(boolean buffer) {
/* 322 */     if (isBuffered() != buffer) {
/* 323 */       this.fCachedDecodedContents = null;
/* 324 */       if (buffer) {
/* 325 */         this.fContents = new ByteArrayOutputStream();
/* 326 */         this.fBufferedDecoder = new StreamDecoder((this.fCharset == null) ? Charset.defaultCharset() : this.fCharset);
/*     */       } else {
/* 328 */         this.fContents = null;
/* 329 */         this.fBufferedDecoder = null;
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public synchronized void flushContents() {
/* 336 */     if (isBuffered()) {
/* 337 */       this.fCachedDecodedContents = null;
/* 338 */       this.fContents.reset();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public synchronized boolean isBuffered() {
/* 344 */     return (this.fContents != null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isReadingDone() {
/* 353 */     return this.fDone.get();
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.debug.core-3.21.0.jar!\org\eclipse\debug\internal\core\OutputStreamMonitor.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */