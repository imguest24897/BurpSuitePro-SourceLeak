/*    */ package org.eclipse.debug.internal.core.commands;
/*    */ 
/*    */ import org.eclipse.core.runtime.CoreException;
/*    */ import org.eclipse.debug.core.commands.IDebugCommandRequest;
/*    */ import org.eclipse.debug.core.commands.IStepOverHandler;
/*    */ import org.eclipse.debug.core.model.IStep;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class StepOverCommand
/*    */   extends StepCommand
/*    */   implements IStepOverHandler
/*    */ {
/*    */   protected void step(Object target) throws CoreException {
/* 31 */     ((IStep)target).stepOver();
/*    */   }
/*    */ 
/*    */   
/*    */   protected boolean isSteppable(Object target) {
/* 36 */     return ((IStep)target).canStepOver();
/*    */   }
/*    */ 
/*    */   
/*    */   protected Object getEnabledStateJobFamily(IDebugCommandRequest request) {
/* 41 */     return IStepOverHandler.class;
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.debug.core-3.21.0.jar!\org\eclipse\debug\internal\core\commands\StepOverCommand.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */