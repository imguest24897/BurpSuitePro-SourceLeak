package org.eclipse.debug.core.sourcelookup;

public interface ISourceContainerType extends ISourceContainerTypeDelegate {
  String getName();
  
  String getId();
  
  String getDescription();
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.debug.core-3.21.0.jar!\org\eclipse\debug\core\sourcelookup\ISourceContainerType.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */