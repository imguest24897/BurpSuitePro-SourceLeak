/*    */ package org.eclipse.debug.internal.core.commands;
/*    */ 
/*    */ import org.eclipse.core.runtime.CoreException;
/*    */ import org.eclipse.debug.core.commands.IDebugCommandRequest;
/*    */ import org.eclipse.debug.core.commands.ITerminateHandler;
/*    */ import org.eclipse.debug.core.model.ITerminate;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TerminateCommand
/*    */   extends ForEachCommand
/*    */   implements ITerminateHandler
/*    */ {
/*    */   protected Object getTarget(Object element) {
/* 30 */     return getAdapter(element, ITerminate.class);
/*    */   }
/*    */ 
/*    */   
/*    */   protected void execute(Object target) throws CoreException {
/* 35 */     ((ITerminate)target).terminate();
/*    */   }
/*    */ 
/*    */   
/*    */   protected boolean isExecutable(Object target) {
/* 40 */     return ((ITerminate)target).canTerminate();
/*    */   }
/*    */ 
/*    */   
/*    */   protected Object getEnabledStateJobFamily(IDebugCommandRequest request) {
/* 45 */     return ITerminateHandler.class;
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.debug.core-3.21.0.jar!\org\eclipse\debug\internal\core\commands\TerminateCommand.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */