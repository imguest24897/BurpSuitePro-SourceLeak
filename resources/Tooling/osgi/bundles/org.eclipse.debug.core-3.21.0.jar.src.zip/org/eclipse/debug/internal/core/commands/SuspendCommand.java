/*    */ package org.eclipse.debug.internal.core.commands;
/*    */ 
/*    */ import org.eclipse.core.runtime.CoreException;
/*    */ import org.eclipse.debug.core.commands.IDebugCommandRequest;
/*    */ import org.eclipse.debug.core.commands.ISuspendHandler;
/*    */ import org.eclipse.debug.core.model.ISuspendResume;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SuspendCommand
/*    */   extends ForEachCommand
/*    */   implements ISuspendHandler
/*    */ {
/*    */   protected Object getTarget(Object element) {
/* 30 */     return getAdapter(element, ISuspendResume.class);
/*    */   }
/*    */ 
/*    */   
/*    */   protected void execute(Object target) throws CoreException {
/* 35 */     ((ISuspendResume)target).suspend();
/*    */   }
/*    */ 
/*    */   
/*    */   protected boolean isExecutable(Object target) {
/* 40 */     return ((ISuspendResume)target).canSuspend();
/*    */   }
/*    */ 
/*    */   
/*    */   protected Object getEnabledStateJobFamily(IDebugCommandRequest request) {
/* 45 */     return ISuspendHandler.class;
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.debug.core-3.21.0.jar!\org\eclipse\debug\internal\core\commands\SuspendCommand.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */