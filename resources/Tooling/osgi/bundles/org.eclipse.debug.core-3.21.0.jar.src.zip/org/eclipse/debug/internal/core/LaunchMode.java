/*    */ package org.eclipse.debug.internal.core;
/*    */ 
/*    */ import java.text.MessageFormat;
/*    */ import org.eclipse.core.runtime.CoreException;
/*    */ import org.eclipse.core.runtime.IConfigurationElement;
/*    */ import org.eclipse.core.runtime.Status;
/*    */ import org.eclipse.debug.core.DebugPlugin;
/*    */ import org.eclipse.debug.core.ILaunchMode;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class LaunchMode
/*    */   implements ILaunchMode
/*    */ {
/*    */   private IConfigurationElement fConfigurationElement;
/*    */   
/*    */   public LaunchMode(IConfigurationElement element) throws CoreException {
/* 41 */     this.fConfigurationElement = element;
/* 42 */     verifyAttributes();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   private void verifyAttributes() throws CoreException {
/* 51 */     verifyAttributeExists("mode");
/* 52 */     verifyAttributeExists("label");
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   private void verifyAttributeExists(String name) throws CoreException {
/* 62 */     if (this.fConfigurationElement.getAttribute(name) == null) {
/* 63 */       missingAttribute(name);
/*    */     }
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   private void missingAttribute(String attrName) throws CoreException {
/* 74 */     throw new CoreException(new Status(4, DebugPlugin.getUniqueIdentifier(), 125, MessageFormat.format(DebugCoreMessages.LaunchMode_1, new Object[] { attrName }), null));
/*    */   }
/*    */ 
/*    */   
/*    */   public String getIdentifier() {
/* 79 */     return this.fConfigurationElement.getAttribute("mode");
/*    */   }
/*    */   
/*    */   public String getLabel() {
/* 83 */     return this.fConfigurationElement.getAttribute("label");
/*    */   }
/*    */ 
/*    */   
/*    */   public String getLaunchAsLabel() {
/* 88 */     String label = this.fConfigurationElement.getAttribute("launchAsLabel");
/* 89 */     if (label == null) {
/* 90 */       return MessageFormat.format(DebugCoreMessages.LaunchMode_0, new Object[] { getLabel() });
/*    */     }
/* 92 */     return label;
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.debug.core-3.21.0.jar!\org\eclipse\debug\internal\core\LaunchMode.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */