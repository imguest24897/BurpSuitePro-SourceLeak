/*     */ package org.eclipse.debug.core.model;
/*     */ 
/*     */ import java.nio.charset.Charset;
/*     */ import java.nio.charset.UnsupportedCharsetException;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.concurrent.ExecutionException;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ import java.util.concurrent.TimeoutException;
/*     */ import java.util.stream.Collector;
/*     */ import java.util.stream.Collectors;
/*     */ import org.eclipse.core.runtime.CoreException;
/*     */ import org.eclipse.core.runtime.Platform;
/*     */ import org.eclipse.core.runtime.PlatformObject;
/*     */ import org.eclipse.core.runtime.Status;
/*     */ import org.eclipse.debug.core.DebugEvent;
/*     */ import org.eclipse.debug.core.DebugException;
/*     */ import org.eclipse.debug.core.DebugPlugin;
/*     */ import org.eclipse.debug.core.ILaunch;
/*     */ import org.eclipse.debug.core.ILaunchConfiguration;
/*     */ import org.eclipse.debug.internal.core.DebugCoreMessages;
/*     */ import org.eclipse.debug.internal.core.NullStreamsProxy;
/*     */ import org.eclipse.debug.internal.core.StreamsProxy;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RuntimeProcess
/*     */   extends PlatformObject
/*     */   implements IProcess
/*     */ {
/*     */   private static final int TERMINATION_TIMEOUT = 5000;
/*     */   private ILaunch fLaunch;
/*     */   private Process fProcess;
/*     */   private int fExitValue;
/*     */   private final ProcessMonitorThread fMonitor;
/*     */   private IStreamsProxy fStreamsProxy;
/*     */   private String fName;
/*     */   private boolean fTerminated;
/*     */   private Map<String, String> fAttributes;
/*     */   private boolean fCaptureOutput = true;
/*     */   private boolean fTerminateDescendants = true;
/*     */   private final String fThreadNameSuffix;
/*     */   
/*     */   public RuntimeProcess(ILaunch launch, Process process, String name, Map<String, String> attributes) {
/* 125 */     setLaunch(launch);
/* 126 */     initializeAttributes(attributes);
/* 127 */     this.fProcess = process;
/*     */     try {
/* 129 */       setAttribute(IProcess.ATTR_PROCESS_ID, Long.toString(process.pid()));
/* 130 */     } catch (UnsupportedOperationException unsupportedOperationException) {}
/*     */ 
/*     */     
/* 133 */     this.fName = name;
/* 134 */     this.fTerminated = true;
/*     */     try {
/* 136 */       this.fExitValue = process.exitValue();
/* 137 */     } catch (IllegalThreadStateException illegalThreadStateException) {
/* 138 */       this.fTerminated = false;
/*     */     } 
/*     */     
/* 141 */     String captureOutput = launch.getAttribute("org.eclipse.debug.core.capture_output");
/* 142 */     this.fCaptureOutput = !"false".equals(captureOutput);
/*     */     
/*     */     try {
/* 145 */       ILaunchConfiguration launchConfiguration = launch.getLaunchConfiguration();
/* 146 */       if (launchConfiguration != null) {
/* 147 */         this.fTerminateDescendants = launchConfiguration.getAttribute("org.eclipse.debug.core.TERMINATE_DESCENDANTS", true);
/*     */       }
/* 149 */     } catch (CoreException e) {
/* 150 */       DebugPlugin.log((Throwable)e);
/*     */     } 
/* 152 */     this.fThreadNameSuffix = getPidInfo(process, launch);
/*     */     
/* 154 */     this.fStreamsProxy = createStreamsProxy();
/* 155 */     this.fMonitor = new ProcessMonitorThread(this.fThreadNameSuffix);
/* 156 */     this.fMonitor.start();
/* 157 */     launch.addProcess(this);
/* 158 */     fireCreationEvent();
/*     */   }
/*     */   
/*     */   private static String getPidInfo(Process process, ILaunch launch) {
/*     */     String pid;
/* 163 */     ILaunchConfiguration lc = (launch == null) ? null : launch.getLaunchConfiguration();
/* 164 */     String name = (lc == null) ? "" : (" " + lc.getName());
/*     */     try {
/* 166 */       pid = " for PID " + process.pid();
/* 167 */     } catch (Exception exception) {
/* 168 */       pid = "";
/*     */     } 
/* 170 */     return String.valueOf(pid) + name;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void initializeAttributes(Map<String, String> attributes) {
/* 178 */     if (attributes != null) {
/* 179 */       attributes.forEach(this::setAttribute);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized boolean canTerminate() {
/* 188 */     return !this.fTerminated;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getLabel() {
/* 196 */     return this.fName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void setLaunch(ILaunch launch) {
/* 205 */     this.fLaunch = launch;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ILaunch getLaunch() {
/* 213 */     return this.fLaunch;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Process getSystemProcess() {
/* 222 */     return this.fProcess;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized boolean isTerminated() {
/* 230 */     return this.fTerminated;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void terminate() throws DebugException {
/* 238 */     if (!isTerminated()) {
/*     */       
/* 240 */       try { Process process = getSystemProcess();
/* 241 */         if (process == null) {
/*     */           return;
/*     */         }
/*     */         
/* 245 */         List<ProcessHandle> descendants = Collections.emptyList();
/* 246 */         if (this.fTerminateDescendants) {
/*     */           try {
/* 248 */             descendants = process.descendants().collect((Collector)Collectors.toList());
/* 249 */           } catch (UnsupportedOperationException unsupportedOperationException) {}
/*     */         }
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 255 */         process.destroy();
/* 256 */         descendants.forEach(ProcessHandle::destroy);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */          }
/*     */       
/*     */       finally
/*     */       
/*     */       { 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 271 */         if (this.fStreamsProxy instanceof StreamsProxy)
/* 272 */           ((StreamsProxy)this.fStreamsProxy).kill();  }  if (this.fStreamsProxy instanceof StreamsProxy) ((StreamsProxy)this.fStreamsProxy).kill();
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 277 */       this.fMonitor.killThread();
/* 278 */       Status status = new Status(4, DebugPlugin.getUniqueIdentifier(), 5010, DebugCoreMessages.RuntimeProcess_terminate_failed, null);
/* 279 */       throw new DebugException(status);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean waitFor(List<ProcessHandle> descendants, long waitStart) throws InterruptedException {
/*     */     try {
/* 300 */       for (ProcessHandle handle : descendants) {
/* 301 */         long remainingTime = 5000L - System.currentTimeMillis() - waitStart;
/*     */         
/* 303 */         handle.onExit().get(remainingTime, TimeUnit.MILLISECONDS);
/*     */       } 
/* 305 */       return true;
/* 306 */     } catch (ExecutionException e) {
/* 307 */       throw new IllegalStateException(e.getCause());
/* 308 */     } catch (TimeoutException timeoutException) {
/* 309 */       return false;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void terminated() {
/* 318 */     setAttribute("org.eclipse.debug.core.terminate.timestamp", Long.toString(System.currentTimeMillis()));
/*     */     
/* 320 */     if (this.fStreamsProxy instanceof StreamsProxy) {
/* 321 */       ((StreamsProxy)this.fStreamsProxy).close();
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 326 */     int exitValue = -1;
/* 327 */     boolean running = false;
/*     */     try {
/* 329 */       exitValue = this.fProcess.exitValue();
/* 330 */     } catch (IllegalThreadStateException illegalThreadStateException) {
/* 331 */       running = true;
/*     */     } 
/*     */     
/* 334 */     synchronized (this) {
/* 335 */       this.fTerminated = true;
/* 336 */       if (!running) {
/* 337 */         this.fExitValue = exitValue;
/*     */       }
/* 339 */       this.fProcess = null;
/*     */     } 
/* 341 */     fireTerminateEvent();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IStreamsProxy getStreamsProxy() {
/* 349 */     if (!this.fCaptureOutput) {
/* 350 */       return null;
/*     */     }
/* 352 */     return this.fStreamsProxy;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected IStreamsProxy createStreamsProxy() {
/* 361 */     if (!this.fCaptureOutput) {
/* 362 */       return (IStreamsProxy)new NullStreamsProxy(getSystemProcess());
/*     */     }
/* 364 */     String encoding = getLaunch().getAttribute("org.eclipse.debug.ui.ATTR_CONSOLE_ENCODING");
/* 365 */     Charset charset = null;
/* 366 */     if (encoding != null) {
/*     */       try {
/* 368 */         charset = Charset.forName(encoding);
/* 369 */       } catch (UnsupportedCharsetException|java.nio.charset.IllegalCharsetNameException e) {
/* 370 */         DebugPlugin.log(e);
/*     */       } 
/*     */     }
/* 373 */     if (charset == null) {
/* 374 */       charset = Platform.getSystemCharset();
/*     */     }
/* 376 */     return (IStreamsProxy)new StreamsProxy(getSystemProcess(), charset, this.fThreadNameSuffix);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void fireCreationEvent() {
/* 383 */     fireEvent(new DebugEvent(this, 4));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void fireEvent(DebugEvent event) {
/* 392 */     DebugPlugin manager = DebugPlugin.getDefault();
/* 393 */     if (manager != null) {
/* 394 */       manager.fireDebugEventSet(new DebugEvent[] { event });
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void fireTerminateEvent() {
/* 402 */     fireEvent(new DebugEvent(this, 8));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void fireChangeEvent() {
/* 409 */     fireEvent(new DebugEvent(this, 16));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAttribute(String key, String value) {
/* 417 */     if (this.fAttributes == null) {
/* 418 */       this.fAttributes = new HashMap<>(5);
/*     */     }
/* 420 */     Object origVal = this.fAttributes.get(key);
/* 421 */     if (origVal != null && origVal.equals(value)) {
/*     */       return;
/*     */     }
/*     */     
/* 425 */     this.fAttributes.put(key, value);
/* 426 */     fireChangeEvent();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getAttribute(String key) {
/* 434 */     if (this.fAttributes == null) {
/* 435 */       return null;
/*     */     }
/* 437 */     return this.fAttributes.get(key);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public <T> T getAdapter(Class<T> adapter) {
/* 443 */     if (adapter.equals(IProcess.class)) {
/* 444 */       return (T)this;
/*     */     }
/* 446 */     if (adapter.equals(IDebugTarget.class)) {
/* 447 */       ILaunch launch = getLaunch();
/* 448 */       IDebugTarget[] targets = launch.getDebugTargets(); byte b; int i; IDebugTarget[] arrayOfIDebugTarget1;
/* 449 */       for (i = (arrayOfIDebugTarget1 = targets).length, b = 0; b < i; ) { IDebugTarget target = arrayOfIDebugTarget1[b];
/* 450 */         if (equals(target.getProcess()))
/* 451 */           return (T)target; 
/*     */         b++; }
/*     */       
/* 454 */       return null;
/*     */     } 
/* 456 */     if (adapter.equals(ILaunch.class)) {
/* 457 */       return (T)getLaunch();
/*     */     }
/*     */     
/* 460 */     if (adapter.equals(ILaunchConfiguration.class)) {
/* 461 */       return (T)getLaunch().getLaunchConfiguration();
/*     */     }
/* 463 */     return (T)super.getAdapter(adapter);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized int getExitValue() throws DebugException {
/* 471 */     if (isTerminated()) {
/* 472 */       return this.fExitValue;
/*     */     }
/* 474 */     throw new DebugException(new Status(4, DebugPlugin.getUniqueIdentifier(), 5010, DebugCoreMessages.RuntimeProcess_Exit_value_not_available_until_process_terminates__1, null));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private class ProcessMonitorThread
/*     */     extends Thread
/*     */   {
/*     */     private volatile boolean fExit;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void run() {
/* 493 */       Process fOSProcess = RuntimeProcess.this.getSystemProcess();
/* 494 */       if (!this.fExit && fOSProcess != null) {
/*     */         try {
/* 496 */           fOSProcess.waitFor();
/* 497 */         } catch (InterruptedException interruptedException) {
/*     */           
/* 499 */           Thread.interrupted();
/*     */         } finally {
/* 501 */           RuntimeProcess.this.terminated();
/*     */         } 
/*     */       }
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private ProcessMonitorThread(String suffix) {
/* 513 */       super(String.valueOf(DebugCoreMessages.ProcessMonitorJob_0) + suffix);
/* 514 */       setDaemon(true);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private void killThread() {
/* 525 */       this.fExit = true;
/* 526 */       interrupt();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.debug.core-3.21.0.jar!\org\eclipse\debug\core\model\RuntimeProcess.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */