package org.eclipse.debug.core;

import org.eclipse.debug.core.model.IStreamMonitor;

public interface IStreamListener {
  void streamAppended(String paramString, IStreamMonitor paramIStreamMonitor);
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.debug.core-3.21.0.jar!\org\eclipse\debug\core\IStreamListener.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */