/*    */ package org.eclipse.debug.internal.core.sourcelookup;
/*    */ 
/*    */ import java.util.Comparator;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SourceLocatorMementoComparator
/*    */   implements Comparator<String>
/*    */ {
/*    */   public int compare(String o1, String o2) {
/* 27 */     if (o1 == null && o2 == null) {
/* 28 */       return 0;
/*    */     }
/* 30 */     if (o1 == null) {
/* 31 */       return -1;
/*    */     }
/* 33 */     if (o2 == null) {
/* 34 */       return 1;
/*    */     }
/* 36 */     String m1 = o1;
/* 37 */     String m2 = o2;
/* 38 */     int i1 = 0, i2 = 0;
/* 39 */     while (i1 < m1.length()) {
/* 40 */       i1 = skipWhitespace(m1, i1);
/* 41 */       i2 = skipWhitespace(m2, i2);
/* 42 */       if (i1 < m1.length() && i2 < m2.length()) {
/* 43 */         if (m1.charAt(i1) != m2.charAt(i2)) {
/* 44 */           return m1.charAt(i1) - m2.charAt(i2);
/*    */         }
/* 46 */         i1++;
/* 47 */         i2++; continue;
/*    */       } 
/* 49 */       if (i2 < m2.length()) {
/* 50 */         return -1;
/*    */       }
/* 52 */       if (i1 < m1.length()) {
/* 53 */         return 1;
/*    */       }
/* 55 */       return 0;
/*    */     } 
/*    */     
/* 58 */     return 0;
/*    */   }
/*    */   
/*    */   private int skipWhitespace(String string, int offset) {
/* 62 */     int off = offset;
/* 63 */     while (off < string.length() && Character.isWhitespace(string.charAt(off))) {
/* 64 */       off++;
/*    */     }
/* 66 */     return off;
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.debug.core-3.21.0.jar!\org\eclipse\debug\internal\core\sourcelookup\SourceLocatorMementoComparator.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */