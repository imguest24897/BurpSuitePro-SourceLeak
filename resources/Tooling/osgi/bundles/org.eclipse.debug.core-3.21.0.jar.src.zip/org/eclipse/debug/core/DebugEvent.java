/*     */ package org.eclipse.debug.core;
/*     */ 
/*     */ import java.util.EventObject;
/*     */ import org.eclipse.debug.internal.core.DebugCoreMessages;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class DebugEvent
/*     */   extends EventObject
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   public static final int RESUME = 1;
/*     */   public static final int SUSPEND = 2;
/*     */   public static final int CREATE = 4;
/*     */   public static final int TERMINATE = 8;
/*     */   public static final int CHANGE = 16;
/*     */   public static final int MODEL_SPECIFIC = 32;
/*     */   public static final int STEP_INTO = 1;
/*     */   public static final int STEP_OVER = 2;
/*     */   public static final int STEP_RETURN = 4;
/*     */   public static final int STEP_END = 8;
/*     */   public static final int BREAKPOINT = 16;
/*     */   public static final int CLIENT_REQUEST = 32;
/*     */   public static final int EVALUATION = 64;
/*     */   public static final int EVALUATION_IMPLICIT = 128;
/*     */   public static final int STATE = 256;
/*     */   public static final int CONTENT = 512;
/*     */   public static final int UNSPECIFIED = 0;
/* 282 */   private int fKind = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 288 */   private int fDetail = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 295 */   private Object fData = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DebugEvent(Object eventSource, int kind) {
/* 306 */     this(eventSource, kind, 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DebugEvent(Object eventSource, int kind, int detail) {
/* 319 */     super(eventSource);
/* 320 */     if ((kind & 0x3F) == 0) {
/* 321 */       throw new IllegalArgumentException(DebugCoreMessages.DebugEvent_illegal_kind);
/*     */     }
/* 323 */     if (kind != 32 && detail != 0 && (detail & 0x3FF) == 0) {
/* 324 */       throw new IllegalArgumentException(DebugCoreMessages.DebugEvent_illegal_detail);
/*     */     }
/* 326 */     this.fKind = kind;
/* 327 */     this.fDetail = detail;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getDetail() {
/* 338 */     return this.fDetail;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getKind() {
/* 347 */     return this.fKind;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isStepStart() {
/* 361 */     return ((getDetail() & 0x7) > 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isEvaluation() {
/* 373 */     return ((getDetail() & 0xC0) > 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setData(Object data) {
/* 383 */     this.fData = data;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object getData() {
/* 393 */     return this.fData;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 401 */     StringBuilder buf = new StringBuilder("DebugEvent[");
/* 402 */     if (getSource() != null) {
/* 403 */       buf.append(getSource().toString());
/*     */     } else {
/* 405 */       buf.append("null");
/*     */     } 
/* 407 */     buf.append(", ");
/* 408 */     switch (getKind()) {
/*     */       case 4:
/* 410 */         buf.append("CREATE");
/*     */         break;
/*     */       case 8:
/* 413 */         buf.append("TERMINATE");
/*     */         break;
/*     */       case 1:
/* 416 */         buf.append("RESUME");
/*     */         break;
/*     */       case 2:
/* 419 */         buf.append("SUSPEND");
/*     */         break;
/*     */       case 16:
/* 422 */         buf.append("CHANGE");
/*     */         break;
/*     */       case 0:
/* 425 */         buf.append("UNSPECIFIED");
/*     */         break;
/*     */       case 32:
/* 428 */         buf.append("MODEL_SPECIFIC");
/*     */         break;
/*     */     } 
/*     */ 
/*     */     
/* 433 */     buf.append(", ");
/* 434 */     switch (getDetail())
/*     */     { case 16:
/* 436 */         buf.append("BREAKPOINT");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 473 */         buf.append("]");
/* 474 */         return buf.toString();case 32: buf.append("CLIENT_REQUEST"); buf.append("]"); return buf.toString();case 8: buf.append("STEP_END"); buf.append("]"); return buf.toString();case 1: buf.append("STEP_INTO"); buf.append("]"); return buf.toString();case 2: buf.append("STEP_OVER"); buf.append("]"); return buf.toString();case 4: buf.append("STEP_RETURN"); buf.append("]"); return buf.toString();case 64: buf.append("EVALUATION"); buf.append("]"); return buf.toString();case 128: buf.append("EVALUATION_IMPLICIT"); buf.append("]"); return buf.toString();case 256: buf.append("STATE"); buf.append("]"); return buf.toString();case 512: buf.append("CONTENT"); buf.append("]"); return buf.toString();case 0: buf.append("UNSPECIFIED"); buf.append("]"); return buf.toString(); }  buf.append(getDetail()); buf.append("]"); return buf.toString();
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.debug.core-3.21.0.jar!\org\eclipse\debug\core\DebugEvent.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */