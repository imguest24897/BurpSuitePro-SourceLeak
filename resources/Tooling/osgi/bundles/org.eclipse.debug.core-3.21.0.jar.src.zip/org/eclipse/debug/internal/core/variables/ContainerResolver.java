/*    */ package org.eclipse.debug.internal.core.variables;
/*    */ 
/*    */ import org.eclipse.core.resources.IResource;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ContainerResolver
/*    */   extends ResourceResolver
/*    */ {
/*    */   protected IResource translateSelectedResource(IResource resource) {
/* 30 */     return (IResource)resource.getParent();
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.debug.core-3.21.0.jar!\org\eclipse\debug\internal\core\variables\ContainerResolver.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */