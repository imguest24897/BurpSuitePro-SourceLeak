package org.eclipse.debug.core;

import org.eclipse.debug.core.model.IBinaryStreamMonitor;

public interface IBinaryStreamListener {
  void streamAppended(byte[] paramArrayOfbyte, IBinaryStreamMonitor paramIBinaryStreamMonitor);
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.debug.core-3.21.0.jar!\org\eclipse\debug\core\IBinaryStreamListener.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */