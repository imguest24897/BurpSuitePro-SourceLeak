/*    */ package org.eclipse.debug.internal.core.commands;
/*    */ 
/*    */ import java.util.HashSet;
/*    */ import java.util.Set;
/*    */ import org.eclipse.core.runtime.CoreException;
/*    */ import org.eclipse.core.runtime.IAdaptable;
/*    */ import org.eclipse.core.runtime.IProgressMonitor;
/*    */ import org.eclipse.debug.core.IRequest;
/*    */ import org.eclipse.debug.core.commands.AbstractDebugCommand;
/*    */ import org.eclipse.debug.core.commands.IEnabledStateRequest;
/*    */ import org.eclipse.debug.core.model.IStackFrame;
/*    */ import org.eclipse.debug.core.model.IStep;
/*    */ import org.eclipse.debug.core.model.IThread;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class StepCommand
/*    */   extends AbstractDebugCommand
/*    */ {
/*    */   protected void doExecute(Object[] targets, IProgressMonitor monitor, IRequest request) throws CoreException {
/*    */     byte b;
/*    */     int i;
/*    */     Object[] arrayOfObject;
/* 38 */     for (i = (arrayOfObject = targets).length, b = 0; b < i; ) { Object target = arrayOfObject[b];
/* 39 */       step(target);
/*    */       b++; }
/*    */   
/*    */   }
/*    */   
/*    */   protected abstract void step(Object paramObject) throws CoreException;
/*    */   
/*    */   protected boolean isExecutable(Object[] targets, IProgressMonitor monitor, IEnabledStateRequest collector) throws CoreException {
/* 47 */     if (isThreadCompatible(targets)) {
/* 48 */       byte b; int i; Object[] arrayOfObject; for (i = (arrayOfObject = targets).length, b = 0; b < i; ) { Object target = arrayOfObject[b];
/* 49 */         if (!isSteppable(target))
/* 50 */           return false; 
/*    */         b++; }
/*    */       
/* 53 */       return true;
/*    */     } 
/* 55 */     return false;
/*    */   }
/*    */ 
/*    */   
/*    */   protected abstract boolean isSteppable(Object paramObject) throws CoreException;
/*    */   
/*    */   protected boolean isThreadCompatible(Object[] targets) {
/* 62 */     if (targets.length == 1) {
/* 63 */       return true;
/*    */     }
/*    */     
/* 66 */     Set<IThread> threads = new HashSet<>(targets.length); byte b; int i; Object[] arrayOfObject;
/* 67 */     for (i = (arrayOfObject = targets).length, b = 0; b < i; ) { Object object = arrayOfObject[b];
/* 68 */       IStackFrame frame = null;
/* 69 */       if (object instanceof IStackFrame) {
/* 70 */         frame = (IStackFrame)object;
/* 71 */       } else if (object instanceof IAdaptable) {
/* 72 */         frame = (IStackFrame)((IAdaptable)object).getAdapter(IStackFrame.class);
/*    */       } 
/* 74 */       if (frame != null && 
/* 75 */         !threads.add(frame.getThread())) {
/* 76 */         return false;
/*    */       }
/*    */       b++; }
/*    */     
/* 80 */     return true;
/*    */   }
/*    */ 
/*    */   
/*    */   protected Object getTarget(Object element) {
/* 85 */     return getAdapter(element, IStep.class);
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.debug.core-3.21.0.jar!\org\eclipse\debug\internal\core\commands\StepCommand.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */