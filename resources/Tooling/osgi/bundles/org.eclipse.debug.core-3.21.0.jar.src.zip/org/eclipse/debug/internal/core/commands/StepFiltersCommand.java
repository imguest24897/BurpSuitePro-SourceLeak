/*    */ package org.eclipse.debug.internal.core.commands;
/*    */ 
/*    */ import org.eclipse.core.runtime.CoreException;
/*    */ import org.eclipse.debug.core.DebugPlugin;
/*    */ import org.eclipse.debug.core.ILaunch;
/*    */ import org.eclipse.debug.core.commands.IDebugCommandRequest;
/*    */ import org.eclipse.debug.core.commands.IStepFiltersHandler;
/*    */ import org.eclipse.debug.core.model.IDebugElement;
/*    */ import org.eclipse.debug.core.model.IDebugTarget;
/*    */ import org.eclipse.debug.core.model.IProcess;
/*    */ import org.eclipse.debug.core.model.IStepFilters;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class StepFiltersCommand
/*    */   extends ForEachCommand
/*    */   implements IStepFiltersHandler
/*    */ {
/*    */   protected Object getTarget(Object element) {
/* 35 */     IDebugTarget[] targets = getDebugTargets(element);
/* 36 */     if (targets.length > 0) {
/* 37 */       IStepFilters[] filters = new IStepFilters[targets.length];
/* 38 */       for (int i = 0; i < targets.length; i++) {
/* 39 */         IDebugTarget target = targets[i];
/* 40 */         if (target instanceof IStepFilters) {
/* 41 */           filters[i] = (IStepFilters)target;
/*    */         } else {
/* 43 */           filters[i] = (IStepFilters)getAdapter(element, IStepFilters.class);
/*    */         } 
/* 45 */         if (filters[i] == null) {
/* 46 */           return null;
/*    */         }
/*    */       } 
/* 49 */       return filters;
/*    */     } 
/* 51 */     return null;
/*    */   }
/*    */   
/*    */   private IDebugTarget[] getDebugTargets(Object element) {
/* 55 */     if (element instanceof IDebugElement) {
/* 56 */       IDebugElement debugElement = (IDebugElement)element;
/* 57 */       return new IDebugTarget[] { debugElement.getDebugTarget() };
/* 58 */     }  if (element instanceof ILaunch) {
/* 59 */       ILaunch launch = (ILaunch)element;
/* 60 */       return launch.getDebugTargets();
/* 61 */     }  if (element instanceof IProcess) {
/* 62 */       IProcess process = (IProcess)element;
/* 63 */       return process.getLaunch().getDebugTargets();
/*    */     } 
/* 65 */     return new IDebugTarget[0];
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   protected void execute(Object target) throws CoreException {
/* 71 */     if (target == null) {
/*    */       return;
/*    */     }
/* 74 */     IStepFilters[] filters = (IStepFilters[])target; byte b; int i; IStepFilters[] arrayOfIStepFilters1;
/* 75 */     for (i = (arrayOfIStepFilters1 = filters).length, b = 0; b < i; ) { IStepFilters filter = arrayOfIStepFilters1[b];
/* 76 */       filter.setStepFiltersEnabled(DebugPlugin.isUseStepFilters());
/*    */       b++; }
/*    */   
/*    */   }
/*    */   
/*    */   protected boolean isExecutable(Object target) {
/* 82 */     IStepFilters[] filters = (IStepFilters[])target; byte b; int i; IStepFilters[] arrayOfIStepFilters1;
/* 83 */     for (i = (arrayOfIStepFilters1 = filters).length, b = 0; b < i; ) { IStepFilters filter = arrayOfIStepFilters1[b];
/* 84 */       if (filter == null || !filter.supportsStepFilters())
/* 85 */         return false; 
/*    */       b++; }
/*    */     
/* 88 */     return true;
/*    */   }
/*    */ 
/*    */   
/*    */   protected Object getEnabledStateJobFamily(IDebugCommandRequest request) {
/* 93 */     return IStepFiltersHandler.class;
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.debug.core-3.21.0.jar!\org\eclipse\debug\internal\core\commands\StepFiltersCommand.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */