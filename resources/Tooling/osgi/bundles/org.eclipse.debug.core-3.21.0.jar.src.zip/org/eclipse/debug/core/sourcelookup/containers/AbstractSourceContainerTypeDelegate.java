/*    */ package org.eclipse.debug.core.sourcelookup.containers;
/*    */ 
/*    */ import org.eclipse.core.runtime.CoreException;
/*    */ import org.eclipse.core.runtime.Status;
/*    */ import org.eclipse.debug.core.DebugPlugin;
/*    */ import org.eclipse.debug.core.sourcelookup.ISourceContainerTypeDelegate;
/*    */ import org.w3c.dom.Document;
/*    */ import org.w3c.dom.Element;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class AbstractSourceContainerTypeDelegate
/*    */   implements ISourceContainerTypeDelegate
/*    */ {
/*    */   protected void abort(String message, Throwable exception) throws CoreException {
/* 41 */     Status status = new Status(4, DebugPlugin.getUniqueIdentifier(), 125, message, exception);
/* 42 */     throw new CoreException(status);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected Document newDocument() throws CoreException {
/* 52 */     return DebugPlugin.newDocument();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected String serializeDocument(Document document) throws CoreException {
/* 63 */     return DebugPlugin.serializeDocument(document);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected Element parseDocument(String document) throws CoreException {
/* 74 */     return DebugPlugin.parseDocument(document);
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.debug.core-3.21.0.jar!\org\eclipse\debug\core\sourcelookup\containers\AbstractSourceContainerTypeDelegate.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */