/*     */ package org.eclipse.debug.internal.core;
/*     */ 
/*     */ import java.nio.ByteBuffer;
/*     */ import java.nio.CharBuffer;
/*     */ import java.nio.charset.Charset;
/*     */ import java.nio.charset.CharsetDecoder;
/*     */ import java.nio.charset.CoderResult;
/*     */ import java.nio.charset.CodingErrorAction;
/*     */ import java.util.Set;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class StreamDecoder
/*     */ {
/*     */   private static final int INPUT_BUFFER_SIZE = 8192;
/*     */   private final Charset charset;
/*     */   private final CharsetDecoder decoder;
/*     */   private final ByteBuffer inputBuffer;
/*     */   private final CharBuffer outputBuffer;
/*     */   private volatile boolean finished;
/*  46 */   Set<String> singlebyteCharsetNames = Set.of(new String[] { "ISO_8859_1", "US_ASCII", "windows-1250", "windows-1251", "windows-1252", "windows-1253", "windows-1254", "windows-1255", "windows-1256", "windows-1257", "windows-1258" });
/*     */   
/*     */   public StreamDecoder(Charset charset) {
/*  49 */     this.charset = charset;
/*  50 */     CharsetDecoder d = charset.newDecoder();
/*  51 */     d.onMalformedInput(CodingErrorAction.REPLACE);
/*  52 */     d.onUnmappableCharacter(CodingErrorAction.REPLACE);
/*  53 */     boolean unbuffered = this.singlebyteCharsetNames.contains(charset.name());
/*  54 */     this.decoder = unbuffered ? null : d;
/*  55 */     this.inputBuffer = unbuffered ? null : ByteBuffer.allocate(8192).flip();
/*  56 */     this.outputBuffer = unbuffered ? null : CharBuffer.allocate((int)(8192.0F * d.maxCharsPerByte()));
/*  57 */     this.finished = false;
/*     */   }
/*     */   
/*     */   private void consume(StringBuilder consumer) {
/*  61 */     this.outputBuffer.flip();
/*  62 */     consumer.append(this.outputBuffer);
/*  63 */     this.outputBuffer.clear();
/*     */   }
/*     */   
/*     */   private void internalDecode(StringBuilder consumer, byte[] buffer, int offset, int length) {
/*  67 */     assert offset >= 0;
/*  68 */     assert length >= 0;
/*  69 */     int position = offset;
/*  70 */     int end = offset + length;
/*  71 */     assert end <= buffer.length;
/*  72 */     boolean finishedReading = false;
/*     */     do {
/*  74 */       CoderResult result = this.decoder.decode(this.inputBuffer, this.outputBuffer, false);
/*  75 */       if (result.isOverflow()) {
/*  76 */         consume(consumer);
/*  77 */       } else if (result.isUnderflow()) {
/*  78 */         this.inputBuffer.compact();
/*  79 */         int remaining = this.inputBuffer.remaining();
/*  80 */         assert remaining > 0;
/*  81 */         int read = Math.min(remaining, end - position);
/*  82 */         if (read > 0) {
/*  83 */           this.inputBuffer.put(buffer, position, read);
/*  84 */           position += read;
/*     */         } else {
/*  86 */           finishedReading = true;
/*     */         } 
/*  88 */         this.inputBuffer.flip();
/*     */       } else {
/*     */         assert false;
/*     */       } 
/*  92 */     } while (!finishedReading);
/*     */   }
/*     */   
/*     */   public String decode(byte[] buffer, int offset, int length) {
/*  96 */     if (this.decoder == null)
/*     */     {
/*  98 */       return new String(buffer, offset, length, this.charset);
/*     */     }
/* 100 */     StringBuilder builder = new StringBuilder();
/* 101 */     decode(builder, buffer, offset, length);
/* 102 */     return builder.toString();
/*     */   }
/*     */   
/*     */   private void decode(StringBuilder consumer, byte[] buffer, int offset, int length) {
/* 106 */     internalDecode(consumer, buffer, offset, length);
/* 107 */     consume(consumer);
/*     */   }
/*     */   
/*     */   public String finish() {
/* 111 */     if (this.decoder == null) {
/* 112 */       return "";
/*     */     }
/* 114 */     StringBuilder builder = new StringBuilder();
/* 115 */     finish(builder);
/* 116 */     return builder.toString();
/*     */   }
/*     */   
/*     */   private void finish(StringBuilder consumer) {
/* 120 */     if (this.finished) {
/*     */       return;
/*     */     }
/* 123 */     this.finished = true;
/*     */     
/* 125 */     CoderResult result = this.decoder.decode(this.inputBuffer, this.outputBuffer, true);
/* 126 */     assert result.isOverflow() || result.isUnderflow();
/*     */     while (true) {
/* 128 */       result = this.decoder.flush(this.outputBuffer);
/* 129 */       if (result.isOverflow()) {
/* 130 */         consume(consumer);
/*     */       } else {
/* 132 */         assert result.isUnderflow();
/*     */       } 
/* 134 */       if (result.isUnderflow()) {
/* 135 */         consume(consumer);
/*     */         return;
/*     */       } 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.debug.core-3.21.0.jar!\org\eclipse\debug\internal\core\StreamDecoder.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */