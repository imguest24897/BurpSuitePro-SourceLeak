/*     */ package org.eclipse.debug.internal.core;
/*     */ 
/*     */ import org.eclipse.core.runtime.preferences.DefaultScope;
/*     */ import org.eclipse.core.runtime.preferences.IEclipsePreferences;
/*     */ import org.eclipse.core.runtime.preferences.IScopeContext;
/*     */ import org.eclipse.core.runtime.preferences.InstanceScope;
/*     */ import org.eclipse.debug.core.DebugPlugin;
/*     */ import org.osgi.service.prefs.BackingStoreException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class Preferences
/*     */ {
/*  33 */   static final IScopeContext[] contexts = new IScopeContext[] { DefaultScope.INSTANCE, InstanceScope.INSTANCE };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static final int DEFAULT_CONTEXT = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static final int INSTANCE_CONTEXT = 1;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static synchronized void setString(String qualifier, String key, String value, IScopeContext context) {
/*  54 */     if (context != null) {
/*     */       try {
/*  56 */         IEclipsePreferences node = context.getNode(qualifier);
/*  57 */         node.put(key, value);
/*  58 */         node.flush();
/*     */       }
/*  60 */       catch (BackingStoreException bse) {
/*  61 */         DebugPlugin.log((Throwable)bse);
/*     */       } 
/*     */     } else {
/*     */       
/*  65 */       contexts[1].getNode(qualifier).put(key, value);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static synchronized void setBoolean(String qualifier, String key, boolean value, IScopeContext context) {
/*  78 */     if (context != null) {
/*     */       try {
/*  80 */         IEclipsePreferences node = context.getNode(qualifier);
/*  81 */         node.putBoolean(key, value);
/*  82 */         node.flush();
/*     */       }
/*  84 */       catch (BackingStoreException bse) {
/*  85 */         DebugPlugin.log((Throwable)bse);
/*     */       } 
/*     */     } else {
/*     */       
/*  89 */       contexts[1].getNode(qualifier).putBoolean(key, value);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static synchronized void setInt(String qualifier, String key, int value, IScopeContext context) {
/* 102 */     if (context != null) {
/*     */       try {
/* 104 */         IEclipsePreferences node = context.getNode(qualifier);
/* 105 */         node.putInt(key, value);
/* 106 */         node.flush();
/*     */       }
/* 108 */       catch (BackingStoreException bse) {
/* 109 */         DebugPlugin.log((Throwable)bse);
/*     */       } 
/*     */     } else {
/*     */       
/* 113 */       contexts[1].getNode(qualifier).putInt(key, value);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static synchronized void setLong(String qualifier, String key, long value, IScopeContext context) {
/* 126 */     if (context != null) {
/*     */       try {
/* 128 */         IEclipsePreferences node = context.getNode(qualifier);
/* 129 */         node.putLong(key, value);
/* 130 */         node.flush();
/*     */       }
/* 132 */       catch (BackingStoreException bse) {
/* 133 */         DebugPlugin.log((Throwable)bse);
/*     */       } 
/*     */     } else {
/*     */       
/* 137 */       contexts[1].getNode(qualifier).putLong(key, value);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static synchronized void setByteArray(String qualifier, String key, byte[] value, IScopeContext context) {
/* 150 */     if (context != null) {
/*     */       try {
/* 152 */         IEclipsePreferences node = context.getNode(qualifier);
/* 153 */         node.putByteArray(key, value);
/* 154 */         node.flush();
/*     */       }
/* 156 */       catch (BackingStoreException bse) {
/* 157 */         DebugPlugin.log((Throwable)bse);
/*     */       } 
/*     */     } else {
/*     */       
/* 161 */       contexts[1].getNode(qualifier).putByteArray(key, value);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static synchronized void setDouble(String qualifier, String key, double value, IScopeContext context) {
/* 174 */     if (context != null) {
/*     */       try {
/* 176 */         IEclipsePreferences node = context.getNode(qualifier);
/* 177 */         node.putDouble(key, value);
/* 178 */         node.flush();
/*     */       }
/* 180 */       catch (BackingStoreException bse) {
/* 181 */         DebugPlugin.log((Throwable)bse);
/*     */       } 
/*     */     } else {
/*     */       
/* 185 */       contexts[1].getNode(qualifier).putDouble(key, value);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static synchronized void setFloat(String qualifier, String key, float value, IScopeContext context) {
/* 198 */     if (context != null) {
/*     */       try {
/* 200 */         IEclipsePreferences node = context.getNode(qualifier);
/* 201 */         node.putFloat(key, value);
/* 202 */         node.flush();
/*     */       }
/* 204 */       catch (BackingStoreException bse) {
/* 205 */         DebugPlugin.log((Throwable)bse);
/*     */       } 
/*     */     } else {
/*     */       
/* 209 */       contexts[1].getNode(qualifier).putFloat(key, value);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static synchronized void setDefaultString(String qualifier, String key, String value) {
/* 220 */     contexts[0].getNode(qualifier).put(key, value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static synchronized void setDefaultBoolean(String qualifier, String key, boolean value) {
/* 230 */     contexts[0].getNode(qualifier).putBoolean(key, value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static synchronized void setDefaultByteArray(String qualifier, String key, byte[] value) {
/* 240 */     contexts[0].getNode(qualifier).putByteArray(key, value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static synchronized void setDefaultDouble(String qualifier, String key, double value) {
/* 250 */     contexts[0].getNode(qualifier).putDouble(key, value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static synchronized void setDefaultFloat(String qualifier, String key, float value) {
/* 260 */     contexts[0].getNode(qualifier).putFloat(key, value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static synchronized void setDefaultInt(String qualifier, String key, int value) {
/* 270 */     contexts[0].getNode(qualifier).putInt(key, value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static synchronized void setDefaultLong(String qualifier, String key, long value) {
/* 280 */     contexts[0].getNode(qualifier).putLong(key, value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static synchronized void setToDefault(String qualifier, String key) {
/* 290 */     if (key != null) {
/* 291 */       contexts[1].getNode(qualifier).remove(key);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static synchronized boolean getDefaultBoolean(String qualifier, String key, boolean defaultvalue) {
/* 305 */     return contexts[0].getNode(qualifier).getBoolean(key, defaultvalue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static synchronized String getDefaultString(String qualifier, String key, String defaultvalue) {
/* 318 */     return contexts[0].getNode(qualifier).get(key, defaultvalue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static synchronized byte[] getDefaultByteArray(String qualifier, String key, byte[] defaultvalue) {
/* 331 */     return contexts[0].getNode(qualifier).getByteArray(key, defaultvalue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static synchronized int getDefaultInt(String qualifier, String key, int defaultvalue) {
/* 344 */     return contexts[0].getNode(qualifier).getInt(key, defaultvalue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static synchronized long getDefaultLong(String qualifier, String key, long defaultvalue) {
/* 357 */     return contexts[0].getNode(qualifier).getLong(key, defaultvalue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static synchronized double getDefaultDouble(String qualifier, String key, double defaultvalue) {
/* 370 */     return contexts[0].getNode(qualifier).getDouble(key, defaultvalue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static synchronized float getDefaultFloat(String qualifier, String key, float defaultvalue) {
/* 383 */     return contexts[0].getNode(qualifier).getFloat(key, defaultvalue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static synchronized void savePreferences(String qualifier) {
/*     */     try {
/* 393 */       contexts[0].getNode(qualifier).flush();
/* 394 */       contexts[1].getNode(qualifier).flush();
/*     */     }
/* 396 */     catch (BackingStoreException bse) {
/* 397 */       DebugPlugin.log((Throwable)bse);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void addPreferenceListener(String qualifier, IEclipsePreferences.IPreferenceChangeListener listener) {
/* 407 */     contexts[0].getNode(qualifier).addPreferenceChangeListener(listener);
/* 408 */     contexts[1].getNode(qualifier).addPreferenceChangeListener(listener);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void removePreferenceListener(String qualifier, IEclipsePreferences.IPreferenceChangeListener listener) {
/* 417 */     contexts[0].getNode(qualifier).removePreferenceChangeListener(listener);
/* 418 */     contexts[1].getNode(qualifier).removePreferenceChangeListener(listener);
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.debug.core-3.21.0.jar!\org\eclipse\debug\internal\core\Preferences.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */