/*    */ package org.eclipse.debug.internal.core;
/*    */ 
/*    */ import org.eclipse.core.runtime.CoreException;
/*    */ import org.eclipse.core.runtime.IConfigurationElement;
/*    */ import org.eclipse.core.runtime.Status;
/*    */ import org.eclipse.debug.core.DebugPlugin;
/*    */ import org.eclipse.debug.core.model.IStepFilter;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class StepFilter
/*    */ {
/*    */   private IConfigurationElement fConfigurationElement;
/*    */   private String fModelIdentifier;
/*    */   private IStepFilter fDelegate;
/*    */   
/*    */   public StepFilter(IConfigurationElement element) throws CoreException {
/* 35 */     this.fConfigurationElement = element;
/* 36 */     this.fModelIdentifier = this.fConfigurationElement.getAttribute("modelIdentifier");
/* 37 */     if (this.fModelIdentifier == null) {
/* 38 */       throw new CoreException(new Status(4, DebugPlugin.getUniqueIdentifier(), 125, DebugCoreMessages.StepFilter_0, null));
/*    */     }
/* 40 */     String className = this.fConfigurationElement.getAttribute("class");
/* 41 */     if (className == null) {
/* 42 */       throw new CoreException(new Status(4, DebugPlugin.getUniqueIdentifier(), 125, DebugCoreMessages.StepFilter_1, null));
/*    */     }
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public IStepFilter[] getStepFilters(String modelIdentifier) {
/* 54 */     if (this.fModelIdentifier.equals(modelIdentifier)) {
/* 55 */       IStepFilter delegate = getDelegate();
/* 56 */       return new IStepFilter[] { delegate };
/*    */     } 
/* 58 */     return new IStepFilter[0];
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected IStepFilter getDelegate() {
/* 67 */     if (this.fDelegate == null) {
/*    */       try {
/* 69 */         this.fDelegate = (IStepFilter)this.fConfigurationElement.createExecutableExtension("class");
/* 70 */       } catch (CoreException e) {
/* 71 */         DebugPlugin.log((Throwable)e);
/*    */       } 
/*    */     }
/* 74 */     return this.fDelegate;
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.debug.core-3.21.0.jar!\org\eclipse\debug\internal\core\StepFilter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */