package org.eclipse.debug.core.model;

public interface IWatchExpression extends IErrorReportingExpression {
  void evaluate();
  
  void setExpressionContext(IDebugElement paramIDebugElement);
  
  void setExpressionText(String paramString);
  
  boolean isPending();
  
  boolean isEnabled();
  
  void setEnabled(boolean paramBoolean);
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.debug.core-3.21.0.jar!\org\eclipse\debug\core\model\IWatchExpression.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */