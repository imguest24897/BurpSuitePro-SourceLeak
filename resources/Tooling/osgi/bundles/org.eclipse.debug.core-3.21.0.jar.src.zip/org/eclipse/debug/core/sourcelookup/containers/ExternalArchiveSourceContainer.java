/*     */ package org.eclipse.debug.core.sourcelookup.containers;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.text.MessageFormat;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Enumeration;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import java.util.zip.ZipEntry;
/*     */ import java.util.zip.ZipFile;
/*     */ import org.eclipse.core.runtime.CoreException;
/*     */ import org.eclipse.core.runtime.Status;
/*     */ import org.eclipse.debug.core.DebugPlugin;
/*     */ import org.eclipse.debug.core.sourcelookup.ISourceContainerType;
/*     */ import org.eclipse.debug.internal.core.sourcelookup.SourceLookupMessages;
/*     */ import org.eclipse.debug.internal.core.sourcelookup.SourceLookupUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ExternalArchiveSourceContainer
/*     */   extends AbstractSourceContainer
/*     */ {
/*     */   private boolean fDisposed;
/*     */   private boolean fDetectRoots;
/*     */   private Set<String> fPotentialRoots;
/*  50 */   private List<String> fRoots = new ArrayList<>();
/*     */ 
/*     */   
/*     */   private String fArchivePath;
/*     */ 
/*     */   
/*  56 */   public static final String TYPE_ID = String.valueOf(DebugPlugin.getUniqueIdentifier()) + ".containerType.externalArchive";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ExternalArchiveSourceContainer(String archivePath, boolean detectRootPaths) {
/*  76 */     this.fArchivePath = archivePath;
/*  77 */     this.fDetectRoots = detectRootPaths;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object[] findSourceElements(String name) throws CoreException {
/*  85 */     String newname = name.replace('\\', '/');
/*  86 */     ZipFile file = getArchive();
/*  87 */     if (file == null) {
/*  88 */       return EMPTY;
/*     */     }
/*     */     
/*  91 */     synchronized (file) {
/*  92 */       boolean isQualfied = (newname.indexOf('/') > 0);
/*  93 */       if (this.fDetectRoots && isQualfied) {
/*  94 */         ZipEntry entry = searchRoots(file, newname);
/*  95 */         if (entry != null) {
/*  96 */           (new Object[1])[0] = new ZipEntryStorage(file, entry); return new Object[1];
/*     */         } 
/*     */       } else {
/*     */         
/* 100 */         ZipEntry entry = null;
/*     */         try {
/* 102 */           entry = file.getEntry(newname);
/* 103 */         } catch (IllegalStateException e) {
/*     */           
/* 105 */           throw new CoreException(new Status(4, DebugPlugin.getUniqueIdentifier(), 
/* 106 */                 e.getMessage(), e));
/*     */         } 
/* 108 */         if (entry != null) {
/*     */           
/* 110 */           (new Object[1])[0] = new ZipEntryStorage(file, entry); return new Object[1];
/*     */         } 
/*     */         
/* 113 */         Enumeration<? extends ZipEntry> entries = file.entries();
/* 114 */         List<ZipEntryStorage> matches = null;
/*     */         try {
/* 116 */           File zipFile = new File(this.fArchivePath);
/* 117 */           String zipFileCanonical = zipFile.getCanonicalPath();
/* 118 */           while (entries.hasMoreElements()) {
/* 119 */             entry = entries.nextElement();
/* 120 */             String entryName = entry.getName();
/* 121 */             if (entryName.endsWith(newname)) {
/* 122 */               String zipEntryCanonical = (new File(zipFile, entryName)).getCanonicalPath();
/* 123 */               if (!zipEntryCanonical.startsWith(String.valueOf(zipFileCanonical) + File.separator)) {
/* 124 */                 throw new CoreException(new Status(4, DebugPlugin.getUniqueIdentifier(), "Invalid path: " + zipEntryCanonical));
/*     */               }
/* 126 */               if (isQualfied || entryName.length() == newname.length() || entryName.charAt(entryName.length() - newname.length() - 1) == '/') {
/* 127 */                 if (isFindDuplicates()) {
/* 128 */                   if (matches == null) {
/* 129 */                     matches = new ArrayList<>();
/*     */                   }
/* 131 */                   matches.add(new ZipEntryStorage(file, entry)); continue;
/*     */                 } 
/* 133 */                 (new Object[1])[0] = 
/* 134 */                   new ZipEntryStorage(file, entry);
/*     */                 return new Object[1];
/*     */               } 
/*     */             } 
/*     */           } 
/* 139 */         } catch (IOException iOException) {
/* 140 */           throw new CoreException(new Status(4, DebugPlugin.getUniqueIdentifier(), "Invalid path: " + this.fArchivePath));
/*     */         } 
/* 142 */         if (matches != null) {
/* 143 */           return matches.toArray();
/*     */         }
/*     */       } 
/*     */     } 
/* 147 */     return EMPTY;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private synchronized ZipEntry searchRoots(ZipFile file, String name) throws CoreException {
/* 161 */     if (this.fDisposed) {
/* 162 */       return null;
/*     */     }
/* 164 */     if (this.fPotentialRoots == null) {
/* 165 */       this.fPotentialRoots = new HashSet<>();
/* 166 */       this.fPotentialRoots.add("");
/*     */       
/*     */       try {
/* 169 */         Enumeration<? extends ZipEntry> entries = file.entries();
/* 170 */         while (entries.hasMoreElements()) {
/* 171 */           ZipEntry entry = entries.nextElement();
/* 172 */           if (entry.isDirectory()) {
/* 173 */             this.fPotentialRoots.add(entry.getName()); continue;
/*     */           } 
/* 175 */           String entryName = entry.getName();
/* 176 */           int index = entryName.lastIndexOf('/');
/* 177 */           while (index > 0 && 
/* 178 */             this.fPotentialRoots.add(entryName.substring(0, index + 1))) {
/* 179 */             entryName = entryName.substring(0, index);
/* 180 */             index = entryName.lastIndexOf('/');
/*     */           
/*     */           }
/*     */         
/*     */         }
/*     */       
/*     */       }
/* 187 */       catch (IllegalStateException e) {
/*     */         
/* 189 */         throw new CoreException(new Status(4, DebugPlugin.getUniqueIdentifier(), 
/* 190 */               e.getMessage(), e));
/*     */       } 
/*     */     } 
/* 193 */     int i = 0;
/* 194 */     while (i < this.fRoots.size()) {
/* 195 */       String root = this.fRoots.get(i);
/* 196 */       ZipEntry entry = file.getEntry(String.valueOf(root) + name);
/* 197 */       if (entry != null) {
/* 198 */         return entry;
/*     */       }
/* 200 */       i++;
/*     */     } 
/* 202 */     if (!this.fPotentialRoots.isEmpty()) {
/* 203 */       for (String root : this.fPotentialRoots) {
/* 204 */         ZipEntry entry = file.getEntry(String.valueOf(root) + name);
/* 205 */         if (entry != null) {
/* 206 */           if (root != null) {
/* 207 */             this.fRoots.add(root);
/* 208 */             this.fPotentialRoots.remove(root);
/*     */ 
/*     */ 
/*     */             
/* 212 */             Iterator<String> rs = this.fPotentialRoots.iterator();
/* 213 */             while (rs.hasNext()) {
/* 214 */               String r = rs.next();
/* 215 */               if (r.startsWith(root)) {
/* 216 */                 rs.remove();
/*     */               }
/*     */             } 
/*     */           } 
/* 220 */           return entry;
/*     */         } 
/*     */       } 
/*     */     }
/* 224 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private synchronized ZipFile getArchive() throws CoreException {
/* 234 */     if (this.fDisposed) {
/* 235 */       return null;
/*     */     }
/*     */     try {
/* 238 */       return SourceLookupUtils.getZipFile(this.fArchivePath);
/* 239 */     } catch (IOException e) {
/* 240 */       File file = new File(this.fArchivePath);
/* 241 */       if (file.exists()) {
/* 242 */         abort(MessageFormat.format(SourceLookupMessages.ExternalArchiveSourceContainer_2, new Object[] { this.fArchivePath }), e);
/*     */       } else {
/* 244 */         warn(MessageFormat.format(SourceLookupMessages.ExternalArchiveSourceContainer_1, new Object[] { this.fArchivePath }), e);
/*     */       } 
/*     */       
/* 247 */       return null;
/*     */     } 
/*     */   }
/*     */   
/*     */   public String getName() {
/* 252 */     return this.fArchivePath;
/*     */   }
/*     */ 
/*     */   
/*     */   public ISourceContainerType getType() {
/* 257 */     return getSourceContainerType(TYPE_ID);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isDetectRoot() {
/* 268 */     return this.fDetectRoots;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object obj) {
/* 273 */     return (obj instanceof ExternalArchiveSourceContainer && (
/* 274 */       (ExternalArchiveSourceContainer)obj).getName().equals(getName()));
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 279 */     return getName().hashCode();
/*     */   }
/*     */ 
/*     */   
/*     */   public synchronized void dispose() {
/* 284 */     super.dispose();
/* 285 */     if (this.fPotentialRoots != null) {
/* 286 */       this.fPotentialRoots.clear();
/*     */     }
/* 288 */     this.fRoots.clear();
/* 289 */     this.fDisposed = true;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.debug.core-3.21.0.jar!\org\eclipse\debug\core\sourcelookup\containers\ExternalArchiveSourceContainer.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */