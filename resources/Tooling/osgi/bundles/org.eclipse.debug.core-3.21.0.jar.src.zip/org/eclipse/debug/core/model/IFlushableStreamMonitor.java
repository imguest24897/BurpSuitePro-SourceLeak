package org.eclipse.debug.core.model;

public interface IFlushableStreamMonitor extends IStreamMonitor {
  void flushContents();
  
  void setBuffered(boolean paramBoolean);
  
  boolean isBuffered();
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.debug.core-3.21.0.jar!\org\eclipse\debug\core\model\IFlushableStreamMonitor.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */