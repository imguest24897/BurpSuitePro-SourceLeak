package org.eclipse.debug.core;

import org.eclipse.debug.core.model.IExpression;

public interface IExpressionListener {
  void expressionAdded(IExpression paramIExpression);
  
  void expressionRemoved(IExpression paramIExpression);
  
  void expressionChanged(IExpression paramIExpression);
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.debug.core-3.21.0.jar!\org\eclipse\debug\core\IExpressionListener.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */