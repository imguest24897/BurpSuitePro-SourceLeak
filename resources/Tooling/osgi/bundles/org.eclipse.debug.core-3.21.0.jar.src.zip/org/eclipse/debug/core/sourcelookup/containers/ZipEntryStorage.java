/*     */ package org.eclipse.debug.core.sourcelookup.containers;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.util.zip.ZipEntry;
/*     */ import java.util.zip.ZipFile;
/*     */ import org.eclipse.core.resources.IStorage;
/*     */ import org.eclipse.core.runtime.CoreException;
/*     */ import org.eclipse.core.runtime.IPath;
/*     */ import org.eclipse.core.runtime.Path;
/*     */ import org.eclipse.core.runtime.PlatformObject;
/*     */ import org.eclipse.core.runtime.Status;
/*     */ import org.eclipse.debug.core.DebugPlugin;
/*     */ import org.eclipse.debug.internal.core.sourcelookup.SourceLookupMessages;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ZipEntryStorage
/*     */   extends PlatformObject
/*     */   implements IStorage
/*     */ {
/*     */   private ZipFile fArchive;
/*     */   private ZipEntry fZipEntry;
/*     */   
/*     */   public ZipEntryStorage(ZipFile archive, ZipEntry entry) {
/*  62 */     setArchive(archive);
/*  63 */     setZipEntry(entry);
/*     */   }
/*     */ 
/*     */   
/*     */   public InputStream getContents() throws CoreException {
/*     */     try {
/*  69 */       return getArchive().getInputStream(getZipEntry());
/*  70 */     } catch (IOException e) {
/*  71 */       throw new CoreException(new Status(4, DebugPlugin.getUniqueIdentifier(), 125, SourceLookupMessages.ZipEntryStorage_0, e));
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public IPath getFullPath() {
/*  77 */     return (new Path(getArchive().getName())).append(getZipEntry().getName());
/*     */   }
/*     */ 
/*     */   
/*     */   public String getName() {
/*  82 */     int index = getZipEntry().getName().lastIndexOf('\\');
/*  83 */     if (index == -1) {
/*  84 */       index = getZipEntry().getName().lastIndexOf('/');
/*     */     }
/*  86 */     if (index == -1) {
/*  87 */       return getZipEntry().getName();
/*     */     }
/*  89 */     return getZipEntry().getName().substring(index + 1);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isReadOnly() {
/*  94 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void setArchive(ZipFile archive) {
/* 103 */     this.fArchive = archive;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ZipFile getArchive() {
/* 112 */     return this.fArchive;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void setZipEntry(ZipEntry entry) {
/* 121 */     this.fZipEntry = entry;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ZipEntry getZipEntry() {
/* 130 */     return this.fZipEntry;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object object) {
/* 135 */     return (object instanceof ZipEntryStorage && 
/* 136 */       getArchive().equals(((ZipEntryStorage)object).getArchive()) && 
/* 137 */       getZipEntry().getName().equals(((ZipEntryStorage)object).getZipEntry().getName()));
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 142 */     return getZipEntry().getName().hashCode();
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.debug.core-3.21.0.jar!\org\eclipse\debug\core\sourcelookup\containers\ZipEntryStorage.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */