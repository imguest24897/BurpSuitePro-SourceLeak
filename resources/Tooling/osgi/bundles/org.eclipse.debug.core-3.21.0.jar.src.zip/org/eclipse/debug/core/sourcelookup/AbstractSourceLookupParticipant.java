/*     */ package org.eclipse.debug.core.sourcelookup;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import org.eclipse.core.runtime.CoreException;
/*     */ import org.eclipse.core.runtime.IStatus;
/*     */ import org.eclipse.core.runtime.MultiStatus;
/*     */ import org.eclipse.debug.core.DebugPlugin;
/*     */ import org.eclipse.debug.internal.core.sourcelookup.SourceLookupMessages;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractSourceLookupParticipant
/*     */   implements ISourceLookupParticipant
/*     */ {
/*     */   private ISourceLookupDirector fDirector;
/*  38 */   protected static final Object[] EMPTY = new Object[0];
/*     */ 
/*     */   
/*     */   public void init(ISourceLookupDirector director) {
/*  42 */     this.fDirector = director;
/*     */   }
/*     */ 
/*     */   
/*     */   public void dispose() {
/*  47 */     this.fDirector = null;
/*     */   }
/*     */ 
/*     */   
/*     */   public Object[] findSourceElements(Object object) throws CoreException {
/*  52 */     List<Object> results = null;
/*  53 */     CoreException single = null;
/*  54 */     MultiStatus multiStatus = null;
/*  55 */     if (isFindDuplicates()) {
/*  56 */       results = new ArrayList();
/*     */     }
/*  58 */     String name = getSourceName(object);
/*  59 */     if (name != null) {
/*  60 */       ISourceContainer[] containers = getSourceContainers(); byte b; int i; ISourceContainer[] arrayOfISourceContainer1;
/*  61 */       for (i = (arrayOfISourceContainer1 = containers).length, b = 0; b < i; ) { ISourceContainer c = arrayOfISourceContainer1[b];
/*     */         try {
/*  63 */           ISourceContainer container = getDelegateContainer(c);
/*  64 */           if (container != null) {
/*  65 */             Object[] objects = container.findSourceElements(name);
/*  66 */             if (objects.length > 0)
/*     */             {
/*     */               
/*  69 */               if (results != null) {
/*  70 */                 Collections.addAll(results, objects);
/*     */               } else {
/*  72 */                 if (objects.length == 1) {
/*  73 */                   return objects;
/*     */                 }
/*  75 */                 return new Object[] { objects[0] };
/*     */               } 
/*     */             }
/*     */           } 
/*  79 */         } catch (CoreException e) {
/*  80 */           if (single == null) {
/*  81 */             single = e;
/*  82 */           } else if (multiStatus == null) {
/*  83 */             multiStatus = new MultiStatus(DebugPlugin.getUniqueIdentifier(), 125, new IStatus[] { single.getStatus() }, SourceLookupMessages.Source_Lookup_Error, null);
/*  84 */             multiStatus.add(e.getStatus());
/*     */           } else {
/*  86 */             multiStatus.add(e.getStatus());
/*     */           } 
/*     */         }  b++; }
/*     */     
/*     */     } 
/*  91 */     if (results == null) {
/*  92 */       if (multiStatus != null)
/*  93 */         throw new CoreException(multiStatus); 
/*  94 */       if (single != null) {
/*  95 */         throw single;
/*     */       }
/*  97 */       return EMPTY;
/*     */     } 
/*  99 */     return results.toArray();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected ISourceContainer getDelegateContainer(ISourceContainer container) {
/* 113 */     return container;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected ISourceLookupDirector getDirector() {
/* 124 */     return this.fDirector;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isFindDuplicates() {
/* 136 */     ISourceLookupDirector director = getDirector();
/* 137 */     if (director != null) {
/* 138 */       return director.isFindDuplicates();
/*     */     }
/* 140 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected ISourceContainer[] getSourceContainers() {
/* 151 */     ISourceLookupDirector director = getDirector();
/* 152 */     if (director != null) {
/* 153 */       return director.getSourceContainers();
/*     */     }
/* 155 */     return new ISourceContainer[0];
/*     */   }
/*     */   
/*     */   public void sourceContainersChanged(ISourceLookupDirector director) {}
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.debug.core-3.21.0.jar!\org\eclipse\debug\core\sourcelookup\AbstractSourceLookupParticipant.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */