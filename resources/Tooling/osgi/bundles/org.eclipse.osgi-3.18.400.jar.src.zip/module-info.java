open module org.eclipse.osgi {
  requires j9stubs;
  requires java.base;
  requires java.xml;
  requires jdk.unsupported;
  
  exports org.eclipse.core.runtime.adaptor;
  exports org.eclipse.core.runtime.internal.adaptor;
  exports org.eclipse.equinox.log;
  exports org.eclipse.osgi.container;
  exports org.eclipse.osgi.container.builders;
  exports org.eclipse.osgi.container.namespaces;
  exports org.eclipse.osgi.framework.console;
  exports org.eclipse.osgi.framework.eventmgr;
  exports org.eclipse.osgi.framework.internal.reliablefile;
  exports org.eclipse.osgi.framework.log;
  exports org.eclipse.osgi.framework.util;
  exports org.eclipse.osgi.internal.debug;
  exports org.eclipse.osgi.internal.framework;
  exports org.eclipse.osgi.internal.hookregistry;
  exports org.eclipse.osgi.internal.loader;
  exports org.eclipse.osgi.internal.loader.buddy;
  exports org.eclipse.osgi.internal.loader.classpath;
  exports org.eclipse.osgi.internal.loader.sources;
  exports org.eclipse.osgi.internal.location;
  exports org.eclipse.osgi.internal.messages;
  exports org.eclipse.osgi.internal.provisional.service.security;
  exports org.eclipse.osgi.internal.provisional.verifier;
  exports org.eclipse.osgi.internal.service.security;
  exports org.eclipse.osgi.internal.serviceregistry;
  exports org.eclipse.osgi.internal.signedcontent;
  exports org.eclipse.osgi.internal.url;
  exports org.eclipse.osgi.launch;
  exports org.eclipse.osgi.report.resolution;
  exports org.eclipse.osgi.service.datalocation;
  exports org.eclipse.osgi.service.debug;
  exports org.eclipse.osgi.service.environment;
  exports org.eclipse.osgi.service.localization;
  exports org.eclipse.osgi.service.pluginconversion;
  exports org.eclipse.osgi.service.resolver;
  exports org.eclipse.osgi.service.runnable;
  exports org.eclipse.osgi.service.security;
  exports org.eclipse.osgi.service.urlconversion;
  exports org.eclipse.osgi.signedcontent;
  exports org.eclipse.osgi.storage;
  exports org.eclipse.osgi.storage.bundlefile;
  exports org.eclipse.osgi.storage.url.reference;
  exports org.eclipse.osgi.storagemanager;
  exports org.eclipse.osgi.util;
  exports org.osgi.dto;
  exports org.osgi.framework;
  exports org.osgi.framework.connect;
  exports org.osgi.framework.dto;
  exports org.osgi.framework.hooks.bundle;
  exports org.osgi.framework.hooks.resolver;
  exports org.osgi.framework.hooks.service;
  exports org.osgi.framework.hooks.weaving;
  exports org.osgi.framework.launch;
  exports org.osgi.framework.namespace;
  exports org.osgi.framework.startlevel;
  exports org.osgi.framework.startlevel.dto;
  exports org.osgi.framework.wiring;
  exports org.osgi.framework.wiring.dto;
  exports org.osgi.resource;
  exports org.osgi.resource.dto;
  exports org.osgi.service.condition;
  exports org.osgi.service.condpermadmin;
  exports org.osgi.service.log;
  exports org.osgi.service.log.admin;
  exports org.osgi.service.packageadmin;
  exports org.osgi.service.permissionadmin;
  exports org.osgi.service.resolver;
  exports org.osgi.service.startlevel;
  exports org.osgi.service.url;
  exports org.osgi.util.tracker;
  
  uses org.osgi.framework.connect.FrameworkUtilHelper;
  
  provides org.osgi.framework.connect.ConnectFrameworkFactory with org.eclipse.osgi.launch.EquinoxFactory;
  provides org.osgi.framework.launch.FrameworkFactory with org.eclipse.osgi.launch.EquinoxFactory;
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.osgi-3.18.400.jar!\module-info.class
 * Java compiler version: 9 (53.0)
 * JD-Core Version:       1.1.3
 */