package org.eclipse.equinox.log;

import org.osgi.framework.ServiceReference;
import org.osgi.service.log.Logger;

public interface Logger extends Logger {
  void log(int paramInt, String paramString);
  
  void log(int paramInt, String paramString, Throwable paramThrowable);
  
  void log(ServiceReference<?> paramServiceReference, int paramInt, String paramString);
  
  void log(ServiceReference<?> paramServiceReference, int paramInt, String paramString, Throwable paramThrowable);
  
  void log(Object paramObject, int paramInt, String paramString);
  
  void log(Object paramObject, int paramInt, String paramString, Throwable paramThrowable);
  
  boolean isLoggable(int paramInt);
  
  String getName();
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.osgi-3.18.400.jar!\org\eclipse\equinox\log\Logger.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */