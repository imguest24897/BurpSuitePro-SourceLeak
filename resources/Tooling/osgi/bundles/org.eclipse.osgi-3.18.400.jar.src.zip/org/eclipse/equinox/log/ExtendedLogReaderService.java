package org.eclipse.equinox.log;

import org.osgi.service.log.LogListener;
import org.osgi.service.log.LogReaderService;

public interface ExtendedLogReaderService extends LogReaderService {
  void addLogListener(LogListener paramLogListener, LogFilter paramLogFilter);
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.osgi-3.18.400.jar!\org\eclipse\equinox\log\ExtendedLogReaderService.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */