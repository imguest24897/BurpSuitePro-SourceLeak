/*    */ package org.eclipse.equinox.log;
/*    */ 
/*    */ import java.security.Permission;
/*    */ import java.security.PermissionCollection;
/*    */ import java.util.Collections;
/*    */ import java.util.Enumeration;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class LogPermissionCollection
/*    */   extends PermissionCollection
/*    */ {
/*    */   private static final long serialVersionUID = -1955409691185916778L;
/*    */   LogPermission logPermission;
/*    */   
/*    */   public void add(Permission permission) {
/* 33 */     if (!(permission instanceof LogPermission))
/* 34 */       throw new IllegalArgumentException("invalid permission: " + permission); 
/* 35 */     if (isReadOnly())
/* 36 */       throw new SecurityException("attempt to add a LogPermission to a readonly LogPermissionCollection"); 
/* 37 */     if (permission != null) {
/* 38 */       this.logPermission = (LogPermission)permission;
/*    */     }
/*    */   }
/*    */   
/*    */   public Enumeration<Permission> elements() {
/* 43 */     return (this.logPermission != null) ? Collections.<Permission>enumeration(Collections.singleton(this.logPermission)) : Collections.<Permission>emptyEnumeration();
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean implies(Permission permission) {
/* 48 */     return (this.logPermission != null && this.logPermission.implies(permission));
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.osgi-3.18.400.jar!\org\eclipse\equinox\log\LogPermissionCollection.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */