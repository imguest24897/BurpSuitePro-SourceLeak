/*     */ package org.eclipse.core.runtime.internal.adaptor;
/*     */ 
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.Map;
/*     */ import java.util.concurrent.Semaphore;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ import org.eclipse.core.runtime.adaptor.EclipseStarter;
/*     */ import org.eclipse.osgi.framework.log.FrameworkLog;
/*     */ import org.eclipse.osgi.framework.log.FrameworkLogEntry;
/*     */ import org.eclipse.osgi.internal.debug.Debug;
/*     */ import org.eclipse.osgi.internal.framework.EquinoxConfiguration;
/*     */ import org.eclipse.osgi.internal.messages.Msg;
/*     */ import org.eclipse.osgi.service.runnable.ApplicationLauncher;
/*     */ import org.eclipse.osgi.service.runnable.ApplicationRunnable;
/*     */ import org.eclipse.osgi.service.runnable.ParameterizedRunnable;
/*     */ import org.osgi.framework.Bundle;
/*     */ import org.osgi.framework.BundleContext;
/*     */ import org.osgi.framework.InvalidSyntaxException;
/*     */ import org.osgi.framework.ServiceReference;
/*     */ import org.osgi.framework.launch.Framework;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class EclipseAppLauncher
/*     */   implements ApplicationLauncher
/*     */ {
/*  32 */   private volatile ParameterizedRunnable runnable = null;
/*  33 */   private Object appContext = null;
/*  34 */   private final Semaphore runningLock = new Semaphore(1);
/*  35 */   private final Semaphore waitForAppLock = new Semaphore(0);
/*     */   private final BundleContext context;
/*     */   private boolean relaunch = false;
/*     */   private final boolean failOnNoDefault;
/*     */   private final FrameworkLog log;
/*     */   private final EquinoxConfiguration equinoxConfig;
/*     */   
/*     */   public EclipseAppLauncher(BundleContext context, boolean relaunch, boolean failOnNoDefault, FrameworkLog log, EquinoxConfiguration equinoxConfig) {
/*  43 */     this.context = context;
/*  44 */     this.relaunch = relaunch;
/*  45 */     this.failOnNoDefault = failOnNoDefault;
/*  46 */     this.log = log;
/*  47 */     this.equinoxConfig = equinoxConfig;
/*  48 */     findRunnableService();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void findRunnableService() {
/*  56 */     String appClass = ParameterizedRunnable.class.getName();
/*  57 */     ServiceReference[] runRefs = null;
/*     */     try {
/*  59 */       runRefs = this.context.getServiceReferences(ParameterizedRunnable.class.getName(), "(&(objectClass=" + appClass + ")(eclipse.application=*))");
/*  60 */     } catch (InvalidSyntaxException invalidSyntaxException) {}
/*     */ 
/*     */     
/*  63 */     if (runRefs != null && runRefs.length > 0) {
/*     */       
/*  65 */       this.runnable = (ParameterizedRunnable)this.context.getService(runRefs[0]);
/*     */       
/*  67 */       this.relaunch = false;
/*  68 */       this.waitForAppLock.release();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object start(Object defaultContext) throws Exception {
/*  80 */     if (this.failOnNoDefault && this.runnable == null)
/*  81 */       throw new IllegalStateException(Msg.ECLIPSE_STARTUP_ERROR_NO_APPLICATION); 
/*  82 */     Object result = null;
/*     */     
/*  84 */     Bundle b = this.context.getBundle();
/*     */     while (true) {
/*     */       try {
/*  87 */         if (this.relaunch) {
/*     */           
/*  89 */           Thread mainThread = Thread.currentThread();
/*  90 */           BundleContext mainContext = this.context;
/*  91 */           (new Thread(() -> {
/*     */                 Framework framework = (Framework)paramBundleContext.getBundle("System Bundle");
/*     */                 
/*     */                 try {
/*     */                   framework.waitForStop(0L);
/*     */                   paramThread.interrupt();
/*  97 */                 } catch (InterruptedException interruptedException) {
/*     */                   
/*     */                   Thread.interrupted();
/*     */                 } 
/* 101 */               }"Framework watcher")).start();
/*     */         } 
/*     */         
/* 104 */         result = runApplication(defaultContext);
/*     */         
/* 106 */         this.relaunch = Boolean.valueOf(this.equinoxConfig.getConfiguration("eclipse.allowAppRelaunch")).booleanValue();
/* 107 */       } catch (Exception e) {
/* 108 */         if (!this.relaunch || (b.getState() & 0x20) == 0)
/* 109 */           throw e; 
/* 110 */         if (this.log != null)
/* 111 */           this.log.log(new FrameworkLogEntry("org.eclipse.osgi", 4, 0, Msg.ECLIPSE_STARTUP_APP_ERROR, 1, e, null)); 
/*     */       } 
/* 113 */       boolean doRelaunch = (this.relaunch && (b.getState() & 0x20) != 0);
/* 114 */       if (!doRelaunch) {
/* 115 */         return result;
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Object runApplication(Object defaultContext) throws Exception {
/*     */     try {
/* 125 */       this.waitForAppLock.acquire();
/*     */ 
/*     */       
/* 128 */       this.runningLock.acquire();
/* 129 */       if (EclipseStarter.debug) {
/* 130 */         String timeString = this.equinoxConfig.getConfiguration("eclipse.startTime");
/* 131 */         long time = (timeString == null) ? 0L : Long.parseLong(timeString);
/* 132 */         Debug.println("Starting application: " + (System.currentTimeMillis() - time));
/*     */       } 
/*     */       
/*     */       try {
/* 136 */         return this.runnable.run((this.appContext != null) ? this.appContext : defaultContext);
/*     */       } finally {
/*     */         
/* 139 */         this.runnable = null;
/* 140 */         this.appContext = null;
/* 141 */         this.runningLock.release();
/*     */       } 
/* 143 */     } catch (InterruptedException interruptedException) {
/*     */       
/* 145 */       Thread.interrupted();
/*     */       
/* 147 */       return null;
/*     */     } 
/*     */   }
/*     */   
/*     */   public void launch(ParameterizedRunnable app, Object applicationContext) {
/* 152 */     this.waitForAppLock.tryAcquire();
/* 153 */     if (!this.runningLock.tryAcquire())
/* 154 */       throw new IllegalStateException("An application is aready running."); 
/* 155 */     this.runnable = app;
/* 156 */     this.appContext = applicationContext;
/* 157 */     this.waitForAppLock.release();
/* 158 */     this.runningLock.release();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void shutdown() {
/* 165 */     if (this.runningLock.tryAcquire())
/*     */       return; 
/* 167 */     ParameterizedRunnable currentRunnable = this.runnable;
/* 168 */     if (currentRunnable instanceof ApplicationRunnable) {
/* 169 */       ((ApplicationRunnable)currentRunnable).stop();
/*     */       try {
/* 171 */         this.runningLock.tryAcquire(1L, TimeUnit.MINUTES);
/* 172 */       } catch (InterruptedException interruptedException) {
/*     */         
/* 174 */         Thread.interrupted();
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object reStart(Object argument) throws Exception {
/* 185 */     ServiceReference[] ref = null;
/* 186 */     ref = this.context.getServiceReferences("org.osgi.service.application.ApplicationDescriptor", "(eclipse.application.default=true)");
/* 187 */     if (ref != null && ref.length > 0) {
/* 188 */       Object defaultApp = this.context.getService(ref[0]);
/* 189 */       Method launch = defaultApp.getClass().getMethod("launch", new Class[] { Map.class });
/* 190 */       launch.invoke(defaultApp, new Object[1]);
/* 191 */       return start(argument);
/*     */     } 
/* 193 */     throw new IllegalStateException(Msg.ECLIPSE_STARTUP_ERROR_NO_APPLICATION);
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.osgi-3.18.400.jar!\org\eclipse\core\runtime\internal\adaptor\EclipseAppLauncher.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */