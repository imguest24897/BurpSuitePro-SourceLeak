/*    */ package org.eclipse.core.runtime.internal.adaptor;
/*    */ 
/*    */ import org.eclipse.osgi.internal.framework.EquinoxConfiguration;
/*    */ import org.osgi.framework.Bundle;
/*    */ import org.osgi.framework.BundleContext;
/*    */ import org.osgi.framework.BundleException;
/*    */ import org.osgi.framework.ServiceReference;
/*    */ import org.osgi.service.packageadmin.PackageAdmin;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ConsoleManager
/*    */ {
/*    */   public static final String PROP_CONSOLE = "osgi.console";
/*    */   public static final String CONSOLE_BUNDLE = "org.eclipse.equinox.console";
/*    */   public static final String PROP_CONSOLE_ENABLED = "osgi.console.enable.builtin";
/*    */   private final BundleContext context;
/*    */   private final String consoleBundle;
/*    */   private final String consolePort;
/*    */   
/*    */   public ConsoleManager(BundleContext context, EquinoxConfiguration equinoxConfig) {
/* 33 */     String port = null;
/* 34 */     String consolePropValue = equinoxConfig.getConfiguration("osgi.console");
/* 35 */     if (consolePropValue != null) {
/* 36 */       int index = consolePropValue.lastIndexOf(":");
/* 37 */       port = consolePropValue.substring(index + 1);
/*    */     } 
/* 39 */     this.consolePort = (port != null) ? port.trim() : port;
/* 40 */     String enabled = equinoxConfig.getConfiguration("osgi.console.enable.builtin", "org.eclipse.equinox.console").trim();
/* 41 */     if ("true".equals(enabled) || "false".equals(enabled))
/*    */     {
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */       
/* 48 */       enabled = "org.eclipse.equinox.console";
/*    */     }
/* 50 */     this.consoleBundle = enabled;
/* 51 */     this.context = context;
/*    */   }
/*    */   
/*    */   public static ConsoleManager startConsole(BundleContext context, EquinoxConfiguration equinoxConfig) {
/* 55 */     ConsoleManager consoleManager = new ConsoleManager(context, equinoxConfig);
/* 56 */     return consoleManager;
/*    */   }
/*    */ 
/*    */   
/*    */   public void checkForConsoleBundle() throws BundleException {
/* 61 */     if ("none".equals(this.consolePort)) {
/*    */       return;
/*    */     }
/* 64 */     ServiceReference<PackageAdmin> paRef = this.context.getServiceReference(PackageAdmin.class);
/* 65 */     PackageAdmin pa = (paRef == null) ? null : (PackageAdmin)this.context.getService(paRef);
/* 66 */     Bundle[] consoles = pa.getBundles(this.consoleBundle, null);
/* 67 */     if (consoles == null || consoles.length == 0) {
/* 68 */       if (this.consolePort != null)
/* 69 */         throw new BundleException("Could not find bundle: " + this.consoleBundle, 1); 
/*    */       return;
/*    */     } 
/*    */     try {
/* 73 */       consoles[0].start(1);
/* 74 */     } catch (BundleException e) {
/* 75 */       throw new BundleException("Could not start bundle: " + this.consoleBundle, 1, e);
/*    */     } 
/*    */   }
/*    */   
/*    */   public void stopConsole() {}
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.osgi-3.18.400.jar!\org\eclipse\core\runtime\internal\adaptor\ConsoleManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */