/*    */ package org.eclipse.osgi.internal.log;
/*    */ 
/*    */ import org.osgi.framework.ServiceReference;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Arguments
/*    */ {
/*    */   private final Object[] arguments;
/*    */   private final ServiceReference<?> serviceReference;
/*    */   private final Throwable throwable;
/*    */   
/*    */   public Arguments(Object... arguments) {
/* 21 */     if (arguments == null || arguments.length == 0) {
/* 22 */       this.arguments = new Object[0];
/* 23 */       this.serviceReference = null;
/* 24 */       this.throwable = null;
/*    */       return;
/*    */     } 
/* 27 */     int length = arguments.length;
/* 28 */     ServiceReference<?> context = null;
/* 29 */     Throwable exception = null;
/* 30 */     Object object = arguments[arguments.length - 1];
/* 31 */     if (object instanceof Throwable || object instanceof ServiceReference) {
/* 32 */       length--;
/* 33 */       if (object instanceof Throwable) {
/* 34 */         exception = (Throwable)object;
/*    */       } else {
/* 36 */         context = (ServiceReference)object;
/*    */       } 
/* 38 */       if (arguments.length > 1) {
/* 39 */         object = arguments[arguments.length - 2];
/* 40 */         if ((object instanceof ServiceReference && context == null) || (object instanceof Throwable && exception == null)) {
/* 41 */           length--;
/* 42 */           if (object instanceof Throwable) {
/* 43 */             exception = (Throwable)object;
/*    */           } else {
/* 45 */             context = (ServiceReference)object;
/*    */           } 
/*    */         } 
/*    */       } 
/*    */     } 
/* 50 */     this.serviceReference = context;
/* 51 */     this.throwable = exception;
/* 52 */     this.arguments = new Object[length];
/* 53 */     System.arraycopy(arguments, 0, this.arguments, 0, length);
/*    */   }
/*    */   
/*    */   public Object[] arguments() {
/* 57 */     return this.arguments;
/*    */   }
/*    */   
/*    */   public boolean isEmpty() {
/* 61 */     return !(this.arguments != null && this.arguments.length != 0);
/*    */   }
/*    */   
/*    */   public ServiceReference<?> serviceReference() {
/* 65 */     return this.serviceReference;
/*    */   }
/*    */   
/*    */   public Throwable throwable() {
/* 69 */     return this.throwable;
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.osgi-3.18.400.jar!\org\eclipse\osgi\internal\log\Arguments.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */