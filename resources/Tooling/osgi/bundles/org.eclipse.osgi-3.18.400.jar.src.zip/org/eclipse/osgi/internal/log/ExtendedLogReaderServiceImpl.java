/*    */ package org.eclipse.osgi.internal.log;
/*    */ 
/*    */ import java.util.Enumeration;
/*    */ import java.util.HashSet;
/*    */ import java.util.Set;
/*    */ import org.eclipse.equinox.log.ExtendedLogReaderService;
/*    */ import org.eclipse.equinox.log.LogFilter;
/*    */ import org.osgi.service.log.LogEntry;
/*    */ import org.osgi.service.log.LogListener;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ExtendedLogReaderServiceImpl
/*    */   implements ExtendedLogReaderService
/*    */ {
/*    */   private final ExtendedLogReaderServiceFactory factory;
/* 22 */   private Set<LogListener> listeners = new HashSet<>();
/*    */   
/*    */   ExtendedLogReaderServiceImpl(ExtendedLogReaderServiceFactory factory) {
/* 25 */     this.factory = factory;
/*    */   }
/*    */ 
/*    */   
/*    */   public synchronized void addLogListener(LogListener listener, LogFilter filter) {
/* 30 */     checkShutdown();
/* 31 */     if (listener == null) {
/* 32 */       throw new IllegalArgumentException("LogListener must not be null");
/*    */     }
/* 34 */     if (filter == null) {
/* 35 */       throw new IllegalArgumentException("LogFilter must not be null");
/*    */     }
/* 37 */     this.listeners.add(listener);
/* 38 */     this.factory.addLogListener(listener, filter);
/*    */   }
/*    */ 
/*    */   
/*    */   public void addLogListener(LogListener listener) {
/* 43 */     addLogListener(listener, ExtendedLogReaderServiceFactory.NULL_LOGGER_FILTER);
/*    */   }
/*    */ 
/*    */   
/*    */   public Enumeration<LogEntry> getLog() {
/* 48 */     checkShutdown();
/* 49 */     return this.factory.getLog();
/*    */   }
/*    */ 
/*    */   
/*    */   public synchronized void removeLogListener(LogListener listener) {
/* 54 */     checkShutdown();
/* 55 */     if (listener == null) {
/* 56 */       throw new IllegalArgumentException("LogListener must not be null");
/*    */     }
/* 58 */     this.factory.removeLogListener(listener);
/* 59 */     this.listeners.remove(listener);
/*    */   }
/*    */   
/*    */   private synchronized void checkShutdown() {
/* 63 */     if (this.listeners == null)
/* 64 */       throw new IllegalStateException("LogReaderService is shutdown."); 
/*    */   }
/*    */   
/*    */   synchronized void shutdown() {
/* 68 */     for (LogListener listener : this.listeners) {
/* 69 */       this.factory.removeLogListener(listener);
/*    */     }
/* 71 */     this.listeners = null;
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.osgi-3.18.400.jar!\org\eclipse\osgi\internal\log\ExtendedLogReaderServiceImpl.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */