/*    */ package org.eclipse.osgi.container;
/*    */ 
/*    */ import java.util.Collections;
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ import org.osgi.framework.wiring.BundleCapability;
/*    */ import org.osgi.framework.wiring.BundleRevision;
/*    */ import org.osgi.resource.Resource;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class ModuleCapability
/*    */   implements BundleCapability
/*    */ {
/*    */   private final String namespace;
/*    */   private final Map<String, String> directives;
/*    */   private final Map<String, Object> attributes;
/*    */   private final Map<String, Object> transientAttrs;
/*    */   private final ModuleRevision revision;
/*    */   
/*    */   ModuleCapability(String namespace, Map<String, String> directives, Map<String, Object> attributes, ModuleRevision revision) {
/* 34 */     this.namespace = namespace;
/* 35 */     this.directives = directives;
/* 36 */     this.attributes = attributes;
/* 37 */     this.transientAttrs = "osgi.native".equals(namespace) ? new HashMap<>(0) : null;
/* 38 */     this.revision = revision;
/*    */   }
/*    */ 
/*    */   
/*    */   public ModuleRevision getRevision() {
/* 43 */     return this.revision;
/*    */   }
/*    */ 
/*    */   
/*    */   public String getNamespace() {
/* 48 */     return this.namespace;
/*    */   }
/*    */ 
/*    */   
/*    */   public Map<String, String> getDirectives() {
/* 53 */     return this.directives;
/*    */   }
/*    */ 
/*    */   
/*    */   public Map<String, Object> getAttributes() {
/* 58 */     if (this.transientAttrs == null)
/* 59 */       return this.attributes; 
/* 60 */     Map<String, Object> result = new HashMap<>(this.transientAttrs);
/* 61 */     result.putAll(this.attributes);
/* 62 */     return Collections.unmodifiableMap(result);
/*    */   }
/*    */   
/*    */   Map<String, Object> getPersistentAttributes() {
/* 66 */     return this.attributes;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setTransientAttrs(Map<String, ?> transientAttrs) {
/* 75 */     if (this.transientAttrs == null) {
/* 76 */       throw new UnsupportedOperationException(String.valueOf(this.namespace) + ": namespace does not support transient attributes.");
/*    */     }
/* 78 */     if (!(getResource().getRevisions().getModule() instanceof SystemModule)) {
/* 79 */       throw new UnsupportedOperationException("Only allowed to set transient attributes for the system module: " + getResource());
/*    */     }
/* 81 */     this.transientAttrs.clear();
/* 82 */     this.transientAttrs.putAll(transientAttrs);
/*    */   }
/*    */ 
/*    */   
/*    */   public ModuleRevision getResource() {
/* 87 */     return this.revision;
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 92 */     return String.valueOf(this.namespace) + ModuleRevision.<Object>toString(this.attributes, false) + ModuleRevision.<String>toString(this.directives, true);
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.osgi-3.18.400.jar!\org\eclipse\osgi\container\ModuleCapability.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */