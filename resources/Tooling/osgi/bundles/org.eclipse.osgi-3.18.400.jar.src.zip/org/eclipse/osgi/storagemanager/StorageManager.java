/*     */ package org.eclipse.osgi.storagemanager;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.io.SyncFailedException;
/*     */ import java.util.Collection;
/*     */ import java.util.Enumeration;
/*     */ import java.util.Map;
/*     */ import java.util.Properties;
/*     */ import java.util.Set;
/*     */ import org.eclipse.osgi.framework.internal.reliablefile.ReliableFile;
/*     */ import org.eclipse.osgi.framework.internal.reliablefile.ReliableFileInputStream;
/*     */ import org.eclipse.osgi.framework.internal.reliablefile.ReliableFileOutputStream;
/*     */ import org.eclipse.osgi.internal.location.LocationHelper;
/*     */ import org.eclipse.osgi.internal.location.Locker;
/*     */ import org.eclipse.osgi.internal.messages.Msg;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class StorageManager
/*     */ {
/*     */   private static final int FILETYPE_STANDARD = 0;
/*     */   private static final int FILETYPE_RELIABLEFILE = 1;
/*     */   private static final String MANAGER_FOLDER = ".manager";
/*     */   private static final String TABLE_FILE = ".fileTable";
/*     */   private static final String LOCK_FILE = ".fileTableLock";
/*     */   private static final int MAX_LOCK_WAIT = 5000;
/* 108 */   private final boolean useReliableFiles = Boolean.valueOf(System.getProperty("osgi.useReliableFiles")).booleanValue();
/* 109 */   private final boolean tempCleanup = Boolean.valueOf(System.getProperty("osgi.embedded.cleanTempFiles")).booleanValue();
/* 110 */   private final boolean openCleanup = Boolean.valueOf(System.getProperty("osgi.embedded.cleanupOnOpen")).booleanValue();
/* 111 */   private final boolean saveCleanup = Boolean.valueOf(System.getProperty("osgi.embedded.cleanupOnSave")).booleanValue(); private final File base; private final File managerRoot; private final String lockMode; private final File tableFile;
/*     */   private final File lockFile;
/*     */   private Locker locker;
/*     */   private File instanceFile;
/*     */   
/*     */   private class Entry { int readId;
/*     */     
/*     */     Entry(int readId, int writeId, int type) {
/* 119 */       this.readId = readId;
/* 120 */       this.writeId = writeId;
/* 121 */       this.fileType = type;
/*     */     }
/*     */     int writeId; int fileType;
/*     */     int getReadId() {
/* 125 */       return this.readId;
/*     */     }
/*     */     
/*     */     int getWriteId() {
/* 129 */       return this.writeId;
/*     */     }
/*     */     
/*     */     int getFileType() {
/* 133 */       return this.fileType;
/*     */     }
/*     */     
/*     */     void setReadId(int value) {
/* 137 */       this.readId = value;
/*     */     }
/*     */     
/*     */     void setWriteId(int value) {
/* 141 */       this.writeId = value;
/*     */     }
/*     */     
/*     */     void setFileType(int type) {
/* 145 */       this.fileType = type;
/*     */     } }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 158 */   private Locker instanceLocker = null;
/*     */   
/*     */   private final boolean readOnly;
/*     */   
/*     */   private boolean open;
/* 163 */   private int tableStamp = -1;
/*     */   
/* 165 */   private final Properties table = new Properties();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public StorageManager(File base, String lockMode) {
/* 176 */     this(base, lockMode, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public StorageManager(File base, String lockMode, boolean readOnly) {
/* 189 */     this.base = base;
/* 190 */     this.lockMode = lockMode;
/* 191 */     this.managerRoot = new File(base, ".manager");
/* 192 */     this.tableFile = new File(this.managerRoot, ".fileTable");
/* 193 */     this.lockFile = new File(this.managerRoot, ".fileTableLock");
/* 194 */     this.readOnly = readOnly;
/* 195 */     this.open = false;
/*     */   }
/*     */   
/*     */   private void initializeInstanceFile() throws IOException {
/* 199 */     if (this.instanceFile != null || this.readOnly)
/*     */       return; 
/* 201 */     this.instanceFile = ReliableFile.createTempFile(".tmp", ".instance", this.managerRoot);
/* 202 */     this.instanceFile.deleteOnExit();
/* 203 */     this.instanceLocker = LocationHelper.createLocker(this.instanceFile, this.lockMode, false);
/* 204 */     this.instanceLocker.lock();
/*     */   }
/*     */   
/*     */   private String getAbsolutePath(String file) {
/* 208 */     return (new File(this.base, file)).getAbsolutePath();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void add(String managedFile) throws IOException {
/* 218 */     add(managedFile, 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void add(String managedFile, int fileType) throws IOException {
/* 229 */     if (!this.open)
/* 230 */       throw new IOException(Msg.fileManager_notOpen); 
/* 231 */     if (this.readOnly)
/* 232 */       throw new IOException(Msg.fileManager_illegalInReadOnlyMode); 
/* 233 */     if (!lock(true))
/* 234 */       throw new IOException(Msg.fileManager_cannotLock); 
/*     */     try {
/* 236 */       updateTable();
/* 237 */       Entry entry = (Entry)this.table.get(managedFile);
/* 238 */       if (entry == null) {
/* 239 */         entry = new Entry(0, 1, fileType);
/* 240 */         this.table.put(managedFile, entry);
/*     */ 
/*     */ 
/*     */         
/* 244 */         int oldestGeneration = findOldestGeneration(managedFile);
/* 245 */         if (oldestGeneration != 0)
/* 246 */           entry.setWriteId(oldestGeneration + 1); 
/* 247 */         save();
/*     */       }
/* 249 */       else if (entry.getFileType() != fileType) {
/* 250 */         entry.setFileType(fileType);
/* 251 */         updateTable();
/* 252 */         save();
/*     */       } 
/*     */     } finally {
/*     */       
/* 256 */       release();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int findOldestGeneration(String managedFile) {
/* 267 */     String[] files = this.base.list();
/* 268 */     int oldestGeneration = 0;
/* 269 */     if (files != null) {
/* 270 */       String name = String.valueOf(managedFile) + '.';
/* 271 */       int len = name.length(); byte b; int i; String[] arrayOfString;
/* 272 */       for (i = (arrayOfString = files).length, b = 0; b < i; ) { String file = arrayOfString[b];
/* 273 */         if (file.startsWith(name)) {
/*     */           
/*     */           try {
/*     */             
/* 277 */             int generation = Integer.parseInt(file.substring(len));
/* 278 */             if (generation > oldestGeneration)
/* 279 */               oldestGeneration = generation; 
/* 280 */           } catch (NumberFormatException numberFormatException) {}
/*     */         }
/*     */         b++; }
/*     */     
/*     */     } 
/* 285 */     return oldestGeneration;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void update(String[] managedFiles, String[] sources) throws IOException {
/* 301 */     if (!this.open)
/* 302 */       throw new IOException(Msg.fileManager_notOpen); 
/* 303 */     if (this.readOnly)
/* 304 */       throw new IOException(Msg.fileManager_illegalInReadOnlyMode); 
/* 305 */     if (!lock(true))
/* 306 */       throw new IOException(Msg.fileManager_cannotLock); 
/*     */     try {
/* 308 */       updateTable();
/* 309 */       int[] originalReadIDs = new int[managedFiles.length];
/* 310 */       boolean error = false; int i;
/* 311 */       for (i = 0; i < managedFiles.length; i++) {
/* 312 */         originalReadIDs[i] = getId(managedFiles[i]);
/* 313 */         if (!update(managedFiles[i], sources[i]))
/* 314 */           error = true; 
/*     */       } 
/* 316 */       if (error) {
/*     */         
/* 318 */         for (i = 0; i < managedFiles.length; i++) {
/* 319 */           Entry entry = (Entry)this.table.get(managedFiles[i]);
/* 320 */           entry.setReadId(originalReadIDs[i]);
/*     */         } 
/* 322 */         throw new IOException(Msg.fileManager_updateFailed);
/*     */       } 
/* 324 */       save();
/*     */     } finally {
/* 326 */       release();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String[] getManagedFiles() {
/* 336 */     if (!this.open)
/* 337 */       return null; 
/* 338 */     Set<Object> set = this.table.keySet();
/*     */     
/* 340 */     String[] keys = set.<String>toArray(new String[set.size()]);
/* 341 */     String[] result = new String[keys.length];
/* 342 */     for (int i = 0; i < keys.length; i++)
/* 343 */       result[i] = new String(keys[i]); 
/* 344 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public File getBase() {
/* 354 */     return this.base;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getId(String managedFile) {
/* 366 */     if (!this.open)
/* 367 */       return -1; 
/* 368 */     Entry entry = (Entry)this.table.get(managedFile);
/* 369 */     if (entry == null)
/* 370 */       return -1; 
/* 371 */     return entry.getReadId();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isReadOnly() {
/* 380 */     return this.readOnly;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean lock(boolean wait) throws IOException {
/* 396 */     if (this.readOnly)
/* 397 */       return false; 
/* 398 */     if (this.locker == null) {
/* 399 */       this.locker = LocationHelper.createLocker(this.lockFile, this.lockMode, false);
/* 400 */       if (this.locker == null)
/* 401 */         throw new IOException(Msg.fileManager_cannotLock); 
/*     */     } 
/* 403 */     boolean locked = this.locker.lock();
/* 404 */     if (locked || !wait) {
/* 405 */       return locked;
/*     */     }
/* 407 */     long start = System.currentTimeMillis();
/*     */     while (true) {
/*     */       try {
/* 410 */         Thread.sleep(200L);
/* 411 */       } catch (InterruptedException interruptedException) {}
/*     */       
/* 413 */       locked = this.locker.lock();
/* 414 */       if (locked) {
/* 415 */         return true;
/*     */       }
/* 417 */       long time = System.currentTimeMillis() - start;
/* 418 */       if (time > 5000L) {
/* 419 */         return false;
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public File lookup(String managedFile, boolean add) throws IOException {
/* 439 */     if (!this.open)
/* 440 */       throw new IOException(Msg.fileManager_notOpen); 
/* 441 */     Entry entry = (Entry)this.table.get(managedFile);
/* 442 */     if (entry == null) {
/* 443 */       if (add) {
/* 444 */         add(managedFile);
/* 445 */         entry = (Entry)this.table.get(managedFile);
/*     */       } else {
/* 447 */         return null;
/*     */       } 
/*     */     }
/* 450 */     return new File(getAbsolutePath(String.valueOf(managedFile) + '.' + entry.getReadId()));
/*     */   }
/*     */   
/*     */   private boolean move(String source, String managedFile) {
/* 454 */     File original = new File(source);
/* 455 */     File targetFile = new File(managedFile);
/*     */ 
/*     */     
/* 458 */     if (!original.exists() || targetFile.exists())
/* 459 */       return false; 
/* 460 */     return original.renameTo(targetFile);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void release() {
/* 467 */     if (this.locker == null)
/*     */       return; 
/* 469 */     this.locker.release();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void remove(String managedFile) throws IOException {
/* 479 */     if (!this.open)
/* 480 */       throw new IOException(Msg.fileManager_notOpen); 
/* 481 */     if (this.readOnly) {
/* 482 */       throw new IOException(Msg.fileManager_illegalInReadOnlyMode);
/*     */     }
/*     */     
/* 485 */     if (!lock(true))
/* 486 */       throw new IOException(Msg.fileManager_cannotLock); 
/*     */     try {
/* 488 */       updateTable();
/* 489 */       this.table.remove(managedFile);
/* 490 */       save();
/*     */     } finally {
/* 492 */       release();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private void updateTable() throws IOException {
/* 498 */     int stamp = ReliableFile.lastModifiedVersion(this.tableFile);
/* 499 */     if (stamp == this.tableStamp || stamp == -1)
/*     */       return; 
/* 501 */     Properties diskTable = new Properties();
/* 502 */     ReliableFileInputStream reliableFileInputStream = new ReliableFileInputStream(this.tableFile);
/*     */     try {
/* 504 */       diskTable.load((InputStream)reliableFileInputStream);
/*     */     } finally {
/*     */       try {
/* 507 */         reliableFileInputStream.close();
/* 508 */       } catch (IOException iOException) {}
/*     */     } 
/*     */ 
/*     */     
/* 512 */     this.tableStamp = stamp;
/* 513 */     for (Enumeration<Object> e = diskTable.keys(); e.hasMoreElements(); ) {
/* 514 */       String file = (String)e.nextElement();
/* 515 */       String value = diskTable.getProperty(file);
/* 516 */       if (value != null) {
/* 517 */         int id, fileType; Entry entry = (Entry)this.table.get(file);
/*     */ 
/*     */ 
/*     */         
/* 521 */         int idx = value.indexOf(',');
/* 522 */         if (idx != -1) {
/* 523 */           id = Integer.parseInt(value.substring(0, idx));
/* 524 */           fileType = Integer.parseInt(value.substring(idx + 1));
/*     */         } else {
/* 526 */           id = Integer.parseInt(value);
/* 527 */           fileType = 0;
/*     */         } 
/* 529 */         if (entry == null) {
/* 530 */           this.table.put(file, new Entry(id, id + 1, fileType)); continue;
/*     */         } 
/* 532 */         entry.setWriteId(id + 1);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void save() throws IOException {
/* 543 */     if (this.readOnly) {
/*     */       return;
/*     */     }
/*     */     
/* 547 */     updateTable();
/*     */     
/* 549 */     Properties props = new Properties();
/* 550 */     for (Enumeration<Object> e = this.table.keys(); e.hasMoreElements(); ) {
/* 551 */       String value, file = (String)e.nextElement();
/* 552 */       Entry entry = (Entry)this.table.get(file);
/*     */       
/* 554 */       if (entry.getFileType() != 0) {
/* 555 */         value = String.valueOf(Integer.toString(entry.getWriteId() - 1)) + ',' + 
/* 556 */           entry.getFileType();
/*     */       } else {
/* 558 */         value = Integer.toString(entry.getWriteId() - 1);
/*     */       } 
/* 560 */       props.put(file, value);
/*     */     } 
/* 562 */     ReliableFileOutputStream fileStream = new ReliableFileOutputStream(this.tableFile);
/* 563 */     boolean error = true;
/*     */     try {
/* 565 */       props.store((OutputStream)fileStream, "safe table");
/* 566 */       fileStream.close();
/* 567 */       error = false;
/*     */     } finally {
/* 569 */       if (error) {
/* 570 */         fileStream.abort();
/*     */       }
/*     */     } 
/* 573 */     if (this.saveCleanup) {
/*     */       try {
/* 575 */         cleanup(false);
/* 576 */       } catch (IOException ex) {
/*     */ 
/*     */         
/* 579 */         System.out.println("Unexpected IOException is thrown inside cleanupWithLock. Please look below for stacktrace");
/* 580 */         ex.printStackTrace(System.out);
/*     */       } 
/*     */     }
/* 583 */     this.tableStamp = ReliableFile.lastModifiedVersion(this.tableFile);
/*     */   }
/*     */   
/*     */   private boolean update(String managedFile, String source) throws IOException {
/* 587 */     Entry entry = (Entry)this.table.get(managedFile);
/* 588 */     if (entry == null)
/* 589 */       add(managedFile); 
/* 590 */     int newId = entry.getWriteId();
/*     */     
/* 592 */     boolean success = move(getAbsolutePath(source), String.valueOf(getAbsolutePath(managedFile)) + '.' + newId);
/* 593 */     if (!success) {
/*     */ 
/*     */       
/* 596 */       newId = findOldestGeneration(managedFile) + 1;
/* 597 */       success = move(getAbsolutePath(source), String.valueOf(getAbsolutePath(managedFile)) + '.' + newId);
/*     */     } 
/* 599 */     if (!success) {
/* 600 */       return false;
/*     */     }
/*     */     
/* 603 */     entry.setReadId(newId);
/* 604 */     entry.setWriteId(newId + 1);
/* 605 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void cleanup(boolean doLock) throws IOException {
/* 614 */     if (this.readOnly) {
/*     */       return;
/*     */     }
/* 617 */     if (doLock && !lock(true)) {
/* 618 */       throw new IOException(Msg.fileManager_cannotLock);
/*     */     }
/*     */     
/* 621 */     try { String[] files = this.managerRoot.list();
/* 622 */       if (files != null) {
/* 623 */         byte b; int i; String[] arrayOfString; for (i = (arrayOfString = files).length, b = 0; b < i; ) { String file = arrayOfString[b];
/* 624 */           if (file.endsWith(".instance") && (this.instanceFile == null || !file.equalsIgnoreCase(this.instanceFile.getName()))) {
/* 625 */             Locker tmpLocker = LocationHelper.createLocker(new File(this.managerRoot, file), this.lockMode, false);
/* 626 */             if (tmpLocker.lock()) {
/*     */               
/* 628 */               tmpLocker.release();
/* 629 */               (new File(this.managerRoot, file)).delete();
/*     */             } else {
/* 631 */               tmpLocker.release();
/*     */               
/*     */               return;
/*     */             } 
/*     */           } 
/*     */           b++; }
/*     */       
/*     */       } 
/* 639 */       updateTable();
/* 640 */       Collection<Map.Entry<Object, Object>> managedFiles = this.table.entrySet();
/* 641 */       for (Map.Entry<Object, Object> fileEntry : managedFiles) {
/* 642 */         String fileName = (String)fileEntry.getKey();
/* 643 */         Entry info = (Entry)fileEntry.getValue();
/* 644 */         if (info.getFileType() == 1) {
/* 645 */           ReliableFile.cleanupGenerations(new File(this.base, fileName));
/*     */           continue;
/*     */         } 
/* 648 */         String readId = Integer.toString(info.getWriteId() - 1);
/* 649 */         deleteCopies(fileName, readId);
/*     */ 
/*     */ 
/*     */       
/*     */       }
/*     */ 
/*     */ 
/*     */       
/*     */        }
/*     */     
/*     */     finally
/*     */     
/*     */     { 
/*     */ 
/*     */       
/* 664 */       if (doLock)
/* 665 */         release();  }  if (doLock) release();
/*     */   
/*     */   }
/*     */   
/*     */   private void deleteCopies(String fileName, String exceptionNumber) {
/* 670 */     String notToDelete = String.valueOf(fileName) + '.' + exceptionNumber;
/* 671 */     String[] files = this.base.list();
/* 672 */     if (files == null)
/*     */       return;  byte b; int i; String[] arrayOfString1;
/* 674 */     for (i = (arrayOfString1 = files).length, b = 0; b < i; ) { String file = arrayOfString1[b];
/* 675 */       if (file.startsWith(String.valueOf(fileName) + '.') && !file.equals(notToDelete)) {
/* 676 */         (new File(this.base, file)).delete();
/*     */       }
/*     */       b++; }
/*     */   
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void close() {
/* 686 */     if (!this.open)
/*     */       return; 
/* 688 */     this.open = false;
/* 689 */     if (this.readOnly)
/*     */       return; 
/*     */     try {
/* 692 */       cleanup(true);
/* 693 */     } catch (IOException iOException) {}
/*     */ 
/*     */     
/* 696 */     if (this.instanceLocker != null) {
/* 697 */       this.instanceLocker.release();
/*     */     }
/* 699 */     if (this.instanceFile != null) {
/* 700 */       this.instanceFile.delete();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void open(boolean wait) throws IOException {
/* 710 */     if (!this.readOnly) {
/* 711 */       this.managerRoot.mkdirs();
/* 712 */       if (!this.managerRoot.isDirectory())
/* 713 */         throw new IOException(Msg.fileManager_cannotLock); 
/* 714 */       if (this.openCleanup)
/* 715 */         cleanup(true); 
/* 716 */       boolean locked = lock(wait);
/* 717 */       if (!locked && wait) {
/* 718 */         throw new IOException(Msg.fileManager_cannotLock);
/*     */       }
/*     */     } 
/*     */     try {
/* 722 */       initializeInstanceFile();
/* 723 */       updateTable();
/* 724 */       this.open = true;
/*     */     } finally {
/* 726 */       release();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public File createTempFile(String file) throws IOException {
/* 742 */     if (this.readOnly)
/* 743 */       throw new IOException(Msg.fileManager_illegalInReadOnlyMode); 
/* 744 */     File tmpFile = ReliableFile.createTempFile(file, ".tmp", this.base);
/*     */ 
/*     */     
/* 747 */     return tmpFile;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public InputStream getInputStream(String managedFile) throws IOException {
/* 760 */     return getInputStream(managedFile, 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public InputStream[] getInputStreamSet(String[] managedFiles) throws IOException {
/* 774 */     InputStream[] streams = new InputStream[managedFiles.length];
/* 775 */     for (int i = 0; i < streams.length; i++)
/* 776 */       streams[i] = getInputStream(managedFiles[i], 1); 
/* 777 */     return streams;
/*     */   }
/*     */   
/*     */   private InputStream getInputStream(String managedFiles, int openMask) throws IOException {
/* 781 */     if (this.useReliableFiles) {
/* 782 */       int id = getId(managedFiles);
/* 783 */       if (id == -1)
/* 784 */         return null; 
/* 785 */       return (InputStream)new ReliableFileInputStream(new File(getBase(), managedFiles), id, openMask);
/*     */     } 
/* 787 */     File lookup = lookup(managedFiles, false);
/* 788 */     if (lookup == null)
/* 789 */       return null; 
/* 790 */     return new FileInputStream(lookup);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ManagedOutputStream getOutputStream(String managedFile) throws IOException {
/* 803 */     if (this.useReliableFiles) {
/* 804 */       ReliableFileOutputStream out = new ReliableFileOutputStream(new File(getBase(), managedFile));
/* 805 */       return new ManagedOutputStream((OutputStream)out, this, managedFile, null);
/*     */     } 
/* 807 */     File tmpFile = createTempFile(managedFile);
/* 808 */     return new ManagedOutputStream(new FileOutputStream(tmpFile), this, managedFile, tmpFile);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ManagedOutputStream[] getOutputStreamSet(String[] managedFiles) throws IOException {
/* 823 */     int count = managedFiles.length;
/* 824 */     ManagedOutputStream[] streams = new ManagedOutputStream[count];
/* 825 */     int idx = 0;
/*     */     try {
/* 827 */       for (; idx < count; idx++) {
/* 828 */         ManagedOutputStream newStream = getOutputStream(managedFiles[idx]);
/* 829 */         newStream.setStreamSet(streams);
/* 830 */         streams[idx] = newStream;
/*     */       } 
/* 832 */     } catch (IOException e) {
/*     */       
/* 834 */       for (int jdx = 0; jdx < idx; jdx++)
/* 835 */         streams[jdx].abort(); 
/* 836 */       throw e;
/*     */     } 
/* 838 */     return streams;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void abortOutputStream(ManagedOutputStream out) {
/* 852 */     ManagedOutputStream[] streamset = out.getStreamSet();
/* 853 */     if (streamset == null) {
/* 854 */       streamset = new ManagedOutputStream[] { out };
/*     */     }
/* 856 */     synchronized (streamset) {
/* 857 */       byte b; int i; ManagedOutputStream[] arrayOfManagedOutputStream; for (i = (arrayOfManagedOutputStream = streamset).length, b = 0; b < i; ) { ManagedOutputStream stream = arrayOfManagedOutputStream[b];
/* 858 */         out = stream;
/* 859 */         if (out.getOutputFile() == null) {
/*     */           
/* 861 */           ReliableFileOutputStream rfos = (ReliableFileOutputStream)out.getOutputStream();
/* 862 */           rfos.abort();
/*     */         } else {
/*     */           
/* 865 */           if (out.getState() == 0) {
/*     */             try {
/* 867 */               out.getOutputStream().close();
/* 868 */             } catch (IOException iOException) {}
/*     */           }
/*     */           
/* 871 */           out.getOutputFile().delete();
/*     */         } 
/* 873 */         out.setState(1);
/*     */         b++; }
/*     */     
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void closeOutputStream(ManagedOutputStream smos) throws IOException {
/* 889 */     if (smos.getState() != 0)
/*     */       return; 
/* 891 */     ManagedOutputStream[] streamSet = smos.getStreamSet();
/* 892 */     if (smos.getOutputFile() == null) {
/*     */       
/* 894 */       ReliableFileOutputStream rfos = (ReliableFileOutputStream)smos.getOutputStream();
/*     */       
/* 896 */       File file = rfos.closeIntermediateFile();
/* 897 */       smos.setState(1);
/* 898 */       String target = smos.getTarget();
/* 899 */       if (streamSet == null) {
/* 900 */         add(target, 1);
/* 901 */         update(new String[] { smos.getTarget() }, new String[] { file.getName() });
/* 902 */         ReliableFile.fileUpdated(new File(getBase(), smos.getTarget()));
/*     */       } 
/*     */     } else {
/*     */       
/* 906 */       OutputStream out = smos.getOutputStream();
/* 907 */       out.flush();
/*     */       try {
/* 909 */         ((FileOutputStream)out).getFD().sync();
/* 910 */       } catch (SyncFailedException syncFailedException) {}
/*     */       
/* 912 */       out.close();
/* 913 */       smos.setState(1);
/* 914 */       String target = smos.getTarget();
/* 915 */       if (streamSet == null) {
/* 916 */         add(target, 0);
/* 917 */         update(new String[] { target }, new String[] { smos.getOutputFile().getName() });
/*     */       } 
/*     */     } 
/*     */     
/* 921 */     if (streamSet != null)
/* 922 */       synchronized (streamSet) {
/*     */         byte b; int i; ManagedOutputStream[] arrayOfManagedOutputStream;
/* 924 */         for (i = (arrayOfManagedOutputStream = streamSet).length, b = 0; b < i; ) { ManagedOutputStream stream = arrayOfManagedOutputStream[b];
/* 925 */           if (stream.getState() == 0) {
/*     */             return;
/*     */           }
/*     */           b++; }
/*     */         
/* 930 */         String[] targets = new String[streamSet.length];
/* 931 */         String[] sources = new String[streamSet.length];
/* 932 */         for (int idx = 0; idx < streamSet.length; idx++) {
/* 933 */           smos = streamSet[idx];
/* 934 */           targets[idx] = smos.getTarget();
/* 935 */           File outputFile = smos.getOutputFile();
/* 936 */           if (outputFile == null) {
/*     */             
/* 938 */             add(smos.getTarget(), 1);
/* 939 */             ReliableFileOutputStream rfos = (ReliableFileOutputStream)smos.getOutputStream();
/* 940 */             File file = rfos.closeIntermediateFile();
/* 941 */             sources[idx] = file.getName();
/* 942 */             ReliableFile.fileUpdated(new File(getBase(), smos.getTarget()));
/*     */           } else {
/* 944 */             add(smos.getTarget(), 0);
/* 945 */             sources[idx] = outputFile.getName();
/*     */           } 
/*     */         } 
/* 948 */         update(targets, sources);
/*     */       }  
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.osgi-3.18.400.jar!\org\eclipse\osgi\storagemanager\StorageManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */