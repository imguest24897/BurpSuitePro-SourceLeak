/*    */ package org.eclipse.osgi.service.resolver;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class StateWire
/*    */ {
/*    */   private final BundleDescription requirementHost;
/*    */   private final VersionConstraint declaredRequirement;
/*    */   private final BundleDescription capabilityHost;
/*    */   private final BaseDescription declaredCapability;
/*    */   
/*    */   public StateWire(BundleDescription requirementHost, VersionConstraint declaredRequirement, BundleDescription capabilityHost, BaseDescription declaredCapability) {
/* 46 */     this.requirementHost = requirementHost;
/* 47 */     this.declaredRequirement = declaredRequirement;
/* 48 */     this.capabilityHost = capabilityHost;
/* 49 */     this.declaredCapability = declaredCapability;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public BundleDescription getRequirementHost() {
/* 58 */     return this.requirementHost;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public VersionConstraint getDeclaredRequirement() {
/* 66 */     return this.declaredRequirement;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public BundleDescription getCapabilityHost() {
/* 74 */     return this.capabilityHost;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public BaseDescription getDeclaredCapability() {
/* 82 */     return this.declaredCapability;
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.osgi-3.18.400.jar!\org\eclipse\osgi\service\resolver\StateWire.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */