/*      */ package org.eclipse.osgi.internal.framework;
/*      */ 
/*      */ import java.io.File;
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import java.net.URL;
/*      */ import java.security.AccessControlContext;
/*      */ import java.security.AccessController;
/*      */ import java.security.InvalidKeyException;
/*      */ import java.security.Permission;
/*      */ import java.security.PrivilegedAction;
/*      */ import java.security.ProtectionDomain;
/*      */ import java.security.cert.Certificate;
/*      */ import java.security.cert.X509Certificate;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Arrays;
/*      */ import java.util.Collection;
/*      */ import java.util.Collections;
/*      */ import java.util.Dictionary;
/*      */ import java.util.EnumSet;
/*      */ import java.util.Enumeration;
/*      */ import java.util.HashMap;
/*      */ import java.util.HashSet;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.Set;
/*      */ import org.eclipse.osgi.container.Module;
/*      */ import org.eclipse.osgi.container.ModuleContainer;
/*      */ import org.eclipse.osgi.container.ModuleContainerAdaptor;
/*      */ import org.eclipse.osgi.container.ModuleLoader;
/*      */ import org.eclipse.osgi.container.ModuleRevision;
/*      */ import org.eclipse.osgi.container.ModuleWire;
/*      */ import org.eclipse.osgi.container.ModuleWiring;
/*      */ import org.eclipse.osgi.container.SystemModule;
/*      */ import org.eclipse.osgi.internal.container.InternalUtils;
/*      */ import org.eclipse.osgi.internal.debug.Debug;
/*      */ import org.eclipse.osgi.internal.loader.BundleLoader;
/*      */ import org.eclipse.osgi.internal.loader.ModuleClassLoader;
/*      */ import org.eclipse.osgi.internal.loader.classpath.ClasspathManager;
/*      */ import org.eclipse.osgi.internal.messages.Msg;
/*      */ import org.eclipse.osgi.internal.serviceregistry.ServiceReferenceImpl;
/*      */ import org.eclipse.osgi.report.resolution.ResolutionReport;
/*      */ import org.eclipse.osgi.signedcontent.SignedContent;
/*      */ import org.eclipse.osgi.signedcontent.SignedContentFactory;
/*      */ import org.eclipse.osgi.signedcontent.SignerInfo;
/*      */ import org.eclipse.osgi.storage.BundleInfo;
/*      */ import org.eclipse.osgi.storage.Storage;
/*      */ import org.osgi.framework.AdaptPermission;
/*      */ import org.osgi.framework.Bundle;
/*      */ import org.osgi.framework.BundleContext;
/*      */ import org.osgi.framework.BundleException;
/*      */ import org.osgi.framework.BundleReference;
/*      */ import org.osgi.framework.FrameworkEvent;
/*      */ import org.osgi.framework.FrameworkListener;
/*      */ import org.osgi.framework.ServiceReference;
/*      */ import org.osgi.framework.Version;
/*      */ import org.osgi.framework.dto.BundleDTO;
/*      */ import org.osgi.framework.dto.FrameworkDTO;
/*      */ import org.osgi.framework.dto.ServiceReferenceDTO;
/*      */ import org.osgi.framework.launch.Framework;
/*      */ import org.osgi.framework.startlevel.BundleStartLevel;
/*      */ import org.osgi.framework.startlevel.FrameworkStartLevel;
/*      */ import org.osgi.framework.startlevel.dto.BundleStartLevelDTO;
/*      */ import org.osgi.framework.startlevel.dto.FrameworkStartLevelDTO;
/*      */ import org.osgi.framework.wiring.BundleRevision;
/*      */ import org.osgi.framework.wiring.BundleRevisions;
/*      */ import org.osgi.framework.wiring.BundleWiring;
/*      */ import org.osgi.framework.wiring.FrameworkWiring;
/*      */ import org.osgi.framework.wiring.dto.BundleRevisionDTO;
/*      */ import org.osgi.framework.wiring.dto.BundleWiringDTO;
/*      */ import org.osgi.framework.wiring.dto.FrameworkWiringDTO;
/*      */ import org.osgi.resource.Resource;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class EquinoxBundle
/*      */   implements Bundle, BundleReference
/*      */ {
/*      */   private final EquinoxContainer equinoxContainer;
/*      */   private final Module module;
/*      */   
/*      */   static class SystemBundle
/*      */     extends EquinoxBundle
/*      */     implements Framework
/*      */   {
/*      */     class SystemBundleHeaders
/*      */       extends Dictionary<String, String>
/*      */     {
/*      */       private final Dictionary<String, String> headers;
/*      */       
/*      */       public SystemBundleHeaders(Dictionary<String, String> headers) {
/*  106 */         this.headers = headers;
/*      */       }
/*      */ 
/*      */       
/*      */       public Enumeration<String> elements() {
/*  111 */         return this.headers.elements();
/*      */       }
/*      */ 
/*      */       
/*      */       public String get(Object key) {
/*  116 */         if (!(key instanceof String)) {
/*  117 */           return null;
/*      */         }
/*  119 */         String sKey = (String)key;
/*  120 */         if ("Export-Package".equalsIgnoreCase(sKey) || "Provide-Capability".equalsIgnoreCase(sKey)) {
/*  121 */           String systemProvideHeader = EquinoxBundle.SystemBundle.this.getEquinoxContainer().getConfiguration().getConfiguration("equinox.system.provide.header", "system.extra");
/*  122 */           boolean useSystemExtra = systemProvideHeader.equals("system.extra");
/*  123 */           boolean useSystem = !(!systemProvideHeader.equals("system") && !useSystemExtra);
/*  124 */           String systemProp = useSystem ? ("Export-Package".equalsIgnoreCase(sKey) ? "org.osgi.framework.system.packages" : "org.osgi.framework.system.capabilities") : null;
/*  125 */           String systemExtraProp = useSystemExtra ? ("Export-Package".equalsIgnoreCase(sKey) ? "org.osgi.framework.system.packages.extra" : "org.osgi.framework.system.capabilities.extra") : null;
/*  126 */           return getExtra(sKey, systemProp, systemExtraProp);
/*      */         } 
/*      */         
/*  129 */         return this.headers.get(key);
/*      */       }
/*      */       
/*      */       private String getExtra(String header, String systemProp, String systemExtraProp) {
/*  133 */         String systemValue = (systemProp != null) ? EquinoxBundle.SystemBundle.this.getEquinoxContainer().getConfiguration().getConfiguration(systemProp) : null;
/*  134 */         String systemExtraValue = (systemExtraProp != null) ? EquinoxBundle.SystemBundle.this.getEquinoxContainer().getConfiguration().getConfiguration(systemExtraProp) : null;
/*  135 */         if (systemValue == null) {
/*  136 */           systemValue = systemExtraValue;
/*  137 */         } else if (systemExtraValue != null && systemExtraValue.trim().length() > 0) {
/*  138 */           systemValue = String.valueOf(systemValue) + ", " + systemExtraValue;
/*  139 */         }  String result = this.headers.get(header);
/*  140 */         if (systemValue != null && systemValue.trim().length() > 0)
/*  141 */           if (result != null) {
/*  142 */             result = String.valueOf(result) + ", " + systemValue;
/*      */           } else {
/*  144 */             result = systemValue;
/*      */           }  
/*  146 */         return result;
/*      */       }
/*      */ 
/*      */       
/*      */       public boolean isEmpty() {
/*  151 */         return this.headers.isEmpty();
/*      */       }
/*      */ 
/*      */       
/*      */       public Enumeration<String> keys() {
/*  156 */         return this.headers.keys();
/*      */       }
/*      */ 
/*      */       
/*      */       public String put(String key, String value) {
/*  161 */         return this.headers.put(key, value);
/*      */       }
/*      */ 
/*      */       
/*      */       public String remove(Object key) {
/*  166 */         return this.headers.remove(key);
/*      */       }
/*      */ 
/*      */       
/*      */       public int size() {
/*  171 */         return this.headers.size();
/*      */       }
/*      */     }
/*      */ 
/*      */     
/*  176 */     final List<FrameworkListener> initListeners = new ArrayList<>(0);
/*      */     
/*      */     class EquinoxSystemModule extends SystemModule {
/*      */       public EquinoxSystemModule(ModuleContainer container) {
/*  180 */         super(container);
/*      */       }
/*      */ 
/*      */       
/*      */       public Bundle getBundle() {
/*  185 */         return EquinoxBundle.SystemBundle.this;
/*      */       }
/*      */ 
/*      */ 
/*      */       
/*      */       protected void cleanup(ModuleRevision revision) {}
/*      */ 
/*      */ 
/*      */       
/*      */       protected void initWorker() throws BundleException {
/*  195 */         EquinoxConfiguration config = EquinoxBundle.SystemBundle.this.getEquinoxContainer().getConfiguration();
/*  196 */         String initUUID = config.setConfiguration("equinox.init.uuid", Boolean.TRUE.toString());
/*  197 */         if (initUUID != null)
/*      */         {
/*  199 */           config.setConfiguration("org.osgi.framework.uuid", InternalUtils.newUUID(config));
/*      */         }
/*  201 */         EquinoxBundle.SystemBundle.this.getEquinoxContainer().init();
/*  202 */         EquinoxBundle.SystemBundle.this.addInitFrameworkListeners();
/*  203 */         EquinoxBundle.SystemBundle.this.startWorker0();
/*      */       }
/*      */ 
/*      */       
/*      */       protected void stopWorker() throws BundleException {
/*  208 */         super.stopWorker();
/*  209 */         EquinoxBundle.SystemBundle.this.stopWorker0();
/*  210 */         EquinoxBundle.SystemBundle.this.getEquinoxContainer().close();
/*      */       }
/*      */       
/*      */       void asyncStop() throws BundleException {
/*  214 */         if ((EquinoxBundle.SystemBundle.this.getEquinoxContainer().getConfiguration().getDebug()).DEBUG_SYSTEM_BUNDLE) {
/*  215 */           Debug.printStackTrace(new Exception("Framework has been requested to stop."));
/*      */         }
/*  217 */         lockStateChange(ModuleContainerAdaptor.ModuleEvent.STOPPED);
/*      */         try {
/*  219 */           if (Module.ACTIVE_SET.contains(getState())) {
/*      */ 
/*      */             
/*  222 */             Thread t = new Thread(new Runnable()
/*      */                 {
/*      */                   public void run() {
/*      */                     try {
/*  226 */                       EquinoxBundle.SystemBundle.EquinoxSystemModule.this.stop(new Module.StopOptions[0]);
/*  227 */                     } catch (Throwable e) {
/*  228 */                       EquinoxBundle.SystemBundle.EquinoxSystemModule.access$0(EquinoxBundle.SystemBundle.EquinoxSystemModule.this).getEquinoxContainer().getLogServices().log("org.eclipse.osgi", 4, "Error stopping the framework.", e);
/*      */                     } 
/*      */                   }
/*  231 */                 }"Framework stop - " + EquinoxBundle.SystemBundle.this.getEquinoxContainer().toString());
/*  232 */             t.start();
/*      */           } 
/*      */         } finally {
/*  235 */           unlockStateChange(ModuleContainerAdaptor.ModuleEvent.STOPPED);
/*      */         } 
/*      */       }
/*      */       
/*      */       void asyncUpdate() throws BundleException {
/*  240 */         if ((EquinoxBundle.SystemBundle.this.getEquinoxContainer().getConfiguration().getDebug()).DEBUG_SYSTEM_BUNDLE) {
/*  241 */           Debug.printStackTrace(new Exception("Framework has been requested to update (restart)."));
/*      */         }
/*  243 */         lockStateChange(ModuleContainerAdaptor.ModuleEvent.UPDATED);
/*      */         try {
/*  245 */           if (Module.ACTIVE_SET.contains(getState())) {
/*  246 */             Thread t = new Thread(new Runnable()
/*      */                 {
/*      */                   public void run() {
/*      */                     try {
/*  250 */                       EquinoxBundle.SystemBundle.EquinoxSystemModule.this.update();
/*  251 */                     } catch (Throwable e) {
/*  252 */                       EquinoxBundle.SystemBundle.EquinoxSystemModule.access$0(EquinoxBundle.SystemBundle.EquinoxSystemModule.this).getEquinoxContainer().getLogServices().log("org.eclipse.osgi", 4, "Error updating the framework.", e);
/*      */                     } 
/*      */                   }
/*  255 */                 }"Framework update - " + EquinoxBundle.SystemBundle.this.getEquinoxContainer().toString());
/*  256 */             t.start();
/*      */           } 
/*      */         } finally {
/*  259 */           unlockStateChange(ModuleContainerAdaptor.ModuleEvent.UPDATED);
/*      */         } 
/*      */       }
/*      */     }
/*      */     
/*      */     SystemBundle(ModuleContainer moduleContainer, EquinoxContainer equinoxContainer) {
/*  265 */       super(moduleContainer, equinoxContainer);
/*      */     }
/*      */ 
/*      */     
/*      */     public void init() throws BundleException {
/*  270 */       init((FrameworkListener[])null);
/*      */     }
/*      */ 
/*      */     
/*      */     public void init(FrameworkListener... listeners) throws BundleException {
/*  275 */       if (listeners != null) {
/*  276 */         if ((getEquinoxContainer().getConfiguration().getDebug()).DEBUG_SYSTEM_BUNDLE) {
/*  277 */           Debug.println("Initializing framework with framework listeners: " + listeners);
/*      */         }
/*  279 */         this.initListeners.addAll(Arrays.asList(listeners));
/*      */       }
/*  281 */       else if ((getEquinoxContainer().getConfiguration().getDebug()).DEBUG_SYSTEM_BUNDLE) {
/*  282 */         Debug.println("Initializing framework with framework no listeners");
/*      */       } 
/*      */       
/*      */       try {
/*  286 */         ((SystemModule)getModule()).init();
/*      */       } finally {
/*  288 */         if (!this.initListeners.isEmpty()) {
/*  289 */           getEquinoxContainer().getEventPublisher().flushFrameworkEvents();
/*  290 */           removeInitListeners();
/*      */         } 
/*      */       } 
/*      */     }
/*      */     
/*      */     void addInitFrameworkListeners() {
/*  296 */       BundleContext context = createBundleContext();
/*  297 */       for (FrameworkListener initListener : this.initListeners) {
/*  298 */         context.addFrameworkListener(initListener);
/*      */       }
/*      */     }
/*      */     
/*      */     void removeInitListeners() {
/*  303 */       BundleContext context = createBundleContext();
/*  304 */       for (FrameworkListener initListener : this.initListeners) {
/*  305 */         context.removeFrameworkListener(initListener);
/*      */       }
/*  307 */       this.initListeners.clear();
/*      */     }
/*      */ 
/*      */     
/*      */     public FrameworkEvent waitForStop(long timeout) throws InterruptedException {
/*  312 */       ModuleContainerAdaptor.ContainerEvent event = ((SystemModule)getModule()).waitForStop(timeout);
/*  313 */       return new FrameworkEvent(EquinoxContainerAdaptor.getType(event), this, null);
/*      */     }
/*      */ 
/*      */     
/*      */     Module createSystemModule(ModuleContainer moduleContainer) {
/*  318 */       return (Module)new EquinoxSystemModule(moduleContainer);
/*      */     }
/*      */ 
/*      */     
/*      */     public void stop(int options) throws BundleException {
/*  323 */       getEquinoxContainer().checkAdminPermission(this, "execute");
/*  324 */       ((EquinoxSystemModule)getModule()).asyncStop();
/*      */     }
/*      */ 
/*      */     
/*      */     public void stop() throws BundleException {
/*  329 */       stop(0);
/*      */     }
/*      */ 
/*      */     
/*      */     public void update(InputStream input) throws BundleException {
/*  334 */       getEquinoxContainer().checkAdminPermission(this, "lifecycle");
/*      */       try {
/*  336 */         if (input != null)
/*  337 */           input.close(); 
/*  338 */       } catch (IOException iOException) {}
/*      */ 
/*      */       
/*  341 */       ((EquinoxSystemModule)getModule()).asyncUpdate();
/*      */     }
/*      */ 
/*      */     
/*      */     public void update() throws BundleException {
/*  346 */       update((InputStream)null);
/*      */     }
/*      */ 
/*      */     
/*      */     public void uninstall() throws BundleException {
/*  351 */       getEquinoxContainer().checkAdminPermission(this, "lifecycle");
/*  352 */       throw new BundleException(Msg.BUNDLE_SYSTEMBUNDLE_UNINSTALL_EXCEPTION, 2);
/*      */     }
/*      */ 
/*      */     
/*      */     public Dictionary<String, String> getHeaders(String locale) {
/*  357 */       return new SystemBundleHeaders(super.getHeaders(locale));
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*  363 */   private final Object monitor = new Object();
/*      */   private BundleContextImpl context;
/*      */   private volatile SignedContent signedContent;
/*      */   
/*      */   private class EquinoxModule
/*      */     extends Module
/*      */   {
/*      */     protected void startWorker() throws BundleException {
/*  371 */       EquinoxBundle.this.startWorker0();
/*      */     }
/*      */ 
/*      */     
/*      */     protected void stopWorker() throws BundleException {
/*  376 */       EquinoxBundle.this.stopWorker0();
/*      */     }
/*      */     
/*      */     public EquinoxModule(Long id, String location, ModuleContainer container, EnumSet<Module.Settings> settings, int startlevel) {
/*  380 */       super(id, location, container, settings, startlevel);
/*      */     }
/*      */ 
/*      */     
/*      */     public Bundle getBundle() {
/*  385 */       return EquinoxBundle.this;
/*      */     }
/*      */ 
/*      */     
/*      */     protected void cleanup(ModuleRevision revision) {
/*  390 */       BundleInfo.Generation generation = (BundleInfo.Generation)revision.getRevisionInfo();
/*  391 */       generation.delete();
/*  392 */       if (revision.equals(getCurrentRevision()))
/*      */       {
/*  394 */         generation.getBundleInfo().delete();
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   EquinoxBundle(ModuleContainer moduleContainer, EquinoxContainer equinoxContainer) {
/*  400 */     this.equinoxContainer = equinoxContainer;
/*  401 */     this.module = createSystemModule(moduleContainer);
/*      */   }
/*      */   
/*      */   public EquinoxBundle(Long id, String location, ModuleContainer moduleContainer, EnumSet<Module.Settings> settings, int startlevel, EquinoxContainer equinoxContainer) {
/*  405 */     this.equinoxContainer = equinoxContainer;
/*  406 */     this.module = new EquinoxModule(id, location, moduleContainer, settings, startlevel);
/*      */   }
/*      */   
/*      */   Module createSystemModule(ModuleContainer moduleContainer) {
/*  410 */     throw new UnsupportedOperationException();
/*      */   }
/*      */ 
/*      */   
/*      */   public int compareTo(Bundle bundle) {
/*  415 */     long idcomp = getBundleId() - bundle.getBundleId();
/*  416 */     return (idcomp < 0L) ? -1 : ((idcomp > 0L) ? 1 : 0);
/*      */   }
/*      */ 
/*      */   
/*      */   public int getState() {
/*  421 */     switch (this.module.getState()) {
/*      */       case INSTALLED:
/*  423 */         return 2;
/*      */       case RESOLVED:
/*  425 */         return 4;
/*      */       case LAZY_STARTING:
/*      */       case STARTING:
/*  428 */         return 8;
/*      */       case null:
/*  430 */         return 32;
/*      */       case STOPPING:
/*  432 */         return 16;
/*      */       case UNINSTALLED:
/*  434 */         return 1;
/*      */     } 
/*  436 */     throw new IllegalStateException("No valid bundle state for module state: " + this.module.getState());
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void start(int options) throws BundleException {
/*  442 */     if (options == 0 && (this.equinoxContainer.getConfiguration().getDebug()).MONITOR_ACTIVATION) {
/*  443 */       Debug.printStackTrace(new Exception("A persistent start has been called on bundle: " + this));
/*      */     }
/*  445 */     this.module.start(getStartOptions(options));
/*      */   }
/*      */   
/*      */   private static Module.StartOptions[] getStartOptions(int options) {
/*  449 */     if (options == 0) {
/*  450 */       return new Module.StartOptions[0];
/*      */     }
/*  452 */     Collection<Module.StartOptions> result = new ArrayList<>(2);
/*  453 */     if ((options & 0x1) != 0) {
/*  454 */       result.add(Module.StartOptions.TRANSIENT);
/*      */     }
/*  456 */     if ((options & 0x2) != 0) {
/*  457 */       result.add(Module.StartOptions.USE_ACTIVATION_POLICY);
/*      */     }
/*  459 */     return result.<Module.StartOptions>toArray(new Module.StartOptions[result.size()]);
/*      */   }
/*      */ 
/*      */   
/*      */   public void start() throws BundleException {
/*  464 */     start(0);
/*      */   }
/*      */ 
/*      */   
/*      */   public void stop(int options) throws BundleException {
/*  469 */     if (options == 0 && (this.equinoxContainer.getConfiguration().getDebug()).MONITOR_ACTIVATION) {
/*  470 */       Debug.printStackTrace(new Exception("A persistent stop has been called on bundle: " + this));
/*      */     }
/*  472 */     this.module.stop(getStopOptions(options));
/*      */   }
/*      */   
/*      */   private Module.StopOptions[] getStopOptions(int options) {
/*  476 */     if ((options & 0x1) == 0) {
/*  477 */       return new Module.StopOptions[0];
/*      */     }
/*  479 */     return new Module.StopOptions[] { Module.StopOptions.TRANSIENT };
/*      */   }
/*      */ 
/*      */   
/*      */   public void stop() throws BundleException {
/*  484 */     stop(0);
/*      */   }
/*      */ 
/*      */   
/*      */   public void update(InputStream input) throws BundleException {
/*  489 */     Storage storage = this.equinoxContainer.getStorage();
/*  490 */     storage.update(this.module, input);
/*  491 */     this.signedContent = null;
/*      */   }
/*      */ 
/*      */   
/*      */   public void update() throws BundleException {
/*  496 */     update(null);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void uninstall() throws BundleException {
/*  502 */     privGetHeaders(null);
/*  503 */     Storage storage = this.equinoxContainer.getStorage();
/*  504 */     storage.getModuleContainer().uninstall(this.module);
/*      */   }
/*      */ 
/*      */   
/*      */   public Dictionary<String, String> getHeaders() {
/*  509 */     return getHeaders(null);
/*      */   }
/*      */ 
/*      */   
/*      */   public Dictionary<String, String> getHeaders(String locale) {
/*  514 */     this.equinoxContainer.checkAdminPermission(this, "metadata");
/*  515 */     return privGetHeaders(locale);
/*      */   }
/*      */   
/*      */   private Dictionary<String, String> privGetHeaders(String locale) {
/*  519 */     BundleInfo.Generation current = (BundleInfo.Generation)this.module.getCurrentRevision().getRevisionInfo();
/*  520 */     return current.getHeaders(locale);
/*      */   }
/*      */ 
/*      */   
/*      */   public long getBundleId() {
/*  525 */     return this.module.getId().longValue();
/*      */   }
/*      */ 
/*      */   
/*      */   public String getLocation() {
/*  530 */     this.equinoxContainer.checkAdminPermission(getBundle(), "metadata");
/*  531 */     return this.module.getLocation();
/*      */   }
/*      */ 
/*      */   
/*      */   public ServiceReference<?>[] getRegisteredServices() {
/*  536 */     checkValid();
/*  537 */     BundleContextImpl current = getBundleContextImpl();
/*  538 */     return (current == null) ? null : (ServiceReference<?>[])this.equinoxContainer.getServiceRegistry().getRegisteredServices(current);
/*      */   }
/*      */ 
/*      */   
/*      */   public ServiceReference<?>[] getServicesInUse() {
/*  543 */     checkValid();
/*  544 */     BundleContextImpl current = getBundleContextImpl();
/*  545 */     return (current == null) ? null : (ServiceReference<?>[])this.equinoxContainer.getServiceRegistry().getServicesInUse(current);
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean hasPermission(Object permission) {
/*  550 */     BundleInfo.Generation current = (BundleInfo.Generation)this.module.getCurrentRevision().getRevisionInfo();
/*  551 */     ProtectionDomain domain = current.getDomain();
/*  552 */     if (domain != null) {
/*  553 */       if (permission instanceof Permission) {
/*  554 */         SecurityManager sm = System.getSecurityManager();
/*  555 */         if (sm instanceof org.eclipse.osgi.internal.permadmin.EquinoxSecurityManager) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  561 */           AccessControlContext acc = new AccessControlContext(new ProtectionDomain[] { domain });
/*      */           try {
/*  563 */             sm.checkPermission((Permission)permission, acc);
/*  564 */             return true;
/*  565 */           } catch (Exception exception) {
/*  566 */             return false;
/*      */           } 
/*      */         } 
/*  569 */         return domain.implies((Permission)permission);
/*      */       } 
/*  571 */       return false;
/*      */     } 
/*  573 */     return true;
/*      */   }
/*      */ 
/*      */   
/*      */   public URL getResource(String name) {
/*      */     try {
/*  579 */       this.equinoxContainer.checkAdminPermission(this, "resource");
/*  580 */     } catch (SecurityException securityException) {
/*  581 */       return null;
/*      */     } 
/*  583 */     checkValid();
/*  584 */     if (isFragment()) {
/*  585 */       return null;
/*      */     }
/*      */     
/*  588 */     ModuleClassLoader classLoader = getModuleClassLoader(false);
/*  589 */     if (classLoader != null) {
/*  590 */       return classLoader.getResource(name);
/*      */     }
/*      */     
/*  593 */     return (new ClasspathManager((BundleInfo.Generation)this.module.getCurrentRevision().getRevisionInfo(), null)).findLocalResource(name);
/*      */   }
/*      */ 
/*      */   
/*      */   public String getSymbolicName() {
/*  598 */     return this.module.getCurrentRevision().getSymbolicName();
/*      */   }
/*      */ 
/*      */   
/*      */   public Version getVersion() {
/*  603 */     return this.module.getCurrentRevision().getVersion();
/*      */   }
/*      */ 
/*      */   
/*      */   public Class<?> loadClass(String name) throws ClassNotFoundException {
/*      */     try {
/*  609 */       this.equinoxContainer.checkAdminPermission(this, "class");
/*  610 */     } catch (SecurityException e) {
/*  611 */       throw new ClassNotFoundException(name, e);
/*      */     } 
/*  613 */     checkValid();
/*  614 */     if (isFragment()) {
/*  615 */       throw new ClassNotFoundException("Can not load a class from a fragment bundle: " + this);
/*      */     }
/*      */     try {
/*  618 */       ModuleClassLoader classLoader = getModuleClassLoader(true);
/*  619 */       if (classLoader != null) {
/*  620 */         if (name.length() > 0 && name.charAt(0) == '[')
/*  621 */           return Class.forName(name, false, (ClassLoader)classLoader); 
/*  622 */         return classLoader.loadClass(name);
/*      */       } 
/*  624 */     } catch (ClassNotFoundException e) {
/*      */       
/*  626 */       boolean compatibilityLazyTrigger = (this.equinoxContainer.getConfiguration()).compatibilityLazyTriggerOnFailLoad;
/*      */       
/*  628 */       if (compatibilityLazyTrigger && Module.State.LAZY_STARTING.equals(this.module.getState())) {
/*      */         try {
/*  630 */           this.module.start(new Module.StartOptions[] { Module.StartOptions.LAZY_TRIGGER });
/*  631 */         } catch (BundleException bundleException) {
/*  632 */           this.equinoxContainer.getLogServices().log("org.eclipse.osgi", 2, e.getMessage(), e);
/*      */         } 
/*      */       }
/*  635 */       throw e;
/*      */     } 
/*  637 */     throw new ClassNotFoundException("No class loader available for the bundle: " + this);
/*      */   }
/*      */   
/*      */   private ModuleClassLoader getModuleClassLoader(boolean logResolveError) {
/*  641 */     ResolutionReport report = resolve();
/*  642 */     if (logResolveError && !Module.RESOLVED_SET.contains(this.module.getState())) {
/*  643 */       String reportMessage = report.getResolutionReportMessage((Resource)this.module.getCurrentRevision());
/*  644 */       this.equinoxContainer.getEventPublisher().publishFrameworkEvent(2, this, (Throwable)new BundleException(reportMessage, 4));
/*      */     } 
/*  646 */     return AccessController.<ModuleClassLoader>doPrivileged(new PrivilegedAction<ModuleClassLoader>()
/*      */         {
/*      */           public ModuleClassLoader run() {
/*  649 */             ModuleWiring wiring = EquinoxBundle.this.getModule().getCurrentRevision().getWiring();
/*  650 */             if (wiring != null) {
/*  651 */               ModuleLoader moduleLoader = wiring.getModuleLoader();
/*  652 */               if (moduleLoader instanceof BundleLoader) {
/*  653 */                 return ((BundleLoader)moduleLoader).getModuleClassLoader();
/*      */               }
/*      */             } 
/*  656 */             return null;
/*      */           }
/*      */         });
/*      */   }
/*      */ 
/*      */   
/*      */   public Enumeration<URL> getResources(String name) throws IOException {
/*      */     try {
/*  664 */       this.equinoxContainer.checkAdminPermission(this, "resource");
/*  665 */     } catch (SecurityException securityException) {
/*  666 */       return null;
/*      */     } 
/*  668 */     checkValid();
/*  669 */     if (isFragment()) {
/*  670 */       return null;
/*      */     }
/*  672 */     ModuleClassLoader classLoader = getModuleClassLoader(false);
/*  673 */     Enumeration<URL> result = null;
/*  674 */     if (classLoader != null) {
/*  675 */       result = classLoader.getResources(name);
/*      */     } else {
/*  677 */       result = (new ClasspathManager((BundleInfo.Generation)this.module.getCurrentRevision().getRevisionInfo(), null)).findLocalResources(name);
/*      */     } 
/*  679 */     return (result != null && result.hasMoreElements()) ? result : null;
/*      */   }
/*      */ 
/*      */   
/*      */   public Enumeration<String> getEntryPaths(String path) {
/*      */     try {
/*  685 */       this.equinoxContainer.checkAdminPermission(this, "resource");
/*  686 */     } catch (SecurityException securityException) {
/*  687 */       return null;
/*      */     } 
/*  689 */     checkValid();
/*  690 */     BundleInfo.Generation current = (BundleInfo.Generation)getModule().getCurrentRevision().getRevisionInfo();
/*  691 */     return current.getBundleFile().getEntryPaths(path);
/*      */   }
/*      */ 
/*      */   
/*      */   public URL getEntry(String path) {
/*      */     try {
/*  697 */       this.equinoxContainer.checkAdminPermission(this, "resource");
/*  698 */     } catch (SecurityException securityException) {
/*  699 */       return null;
/*      */     } 
/*  701 */     checkValid();
/*  702 */     BundleInfo.Generation current = (BundleInfo.Generation)getModule().getCurrentRevision().getRevisionInfo();
/*  703 */     return current.getEntry(path);
/*      */   }
/*      */ 
/*      */   
/*      */   public long getLastModified() {
/*  708 */     return this.module.getLastModified();
/*      */   }
/*      */ 
/*      */   
/*      */   public Enumeration<URL> findEntries(String path, String filePattern, boolean recurse) {
/*      */     try {
/*  714 */       this.equinoxContainer.checkAdminPermission(this, "resource");
/*  715 */     } catch (SecurityException securityException) {
/*  716 */       return null;
/*      */     } 
/*  718 */     checkValid();
/*  719 */     resolve();
/*  720 */     return Storage.findEntries(getGenerations(), path, filePattern, recurse ? 1 : 0);
/*      */   }
/*      */ 
/*      */   
/*      */   public BundleContext getBundleContext() {
/*  725 */     this.equinoxContainer.checkAdminPermission(this, "context");
/*  726 */     return createBundleContext();
/*      */   }
/*      */   
/*      */   BundleContextImpl createBundleContext() {
/*  730 */     if (isFragment())
/*      */     {
/*  732 */       return null;
/*      */     }
/*  734 */     synchronized (this.monitor) {
/*  735 */       if (this.context == null)
/*      */       {
/*      */         
/*  738 */         if (Module.ACTIVE_SET.contains(this.module.getState())) {
/*  739 */           this.context = new BundleContextImpl(this, this.equinoxContainer);
/*      */         }
/*      */       }
/*  742 */       return this.context;
/*      */     } 
/*      */   }
/*      */   
/*      */   private BundleContextImpl getBundleContextImpl() {
/*  747 */     synchronized (this.monitor) {
/*  748 */       return this.context;
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public Map<X509Certificate, List<X509Certificate>> getSignerCertificates(int signersType) {
/*      */     try {
/*  755 */       SignedContent current = getSignedContent();
/*  756 */       SignerInfo[] infos = (current == null) ? null : current.getSignerInfos();
/*  757 */       if (infos.length == 0)
/*  758 */         return Collections.emptyMap(); 
/*  759 */       Map<X509Certificate, List<X509Certificate>> results = new HashMap<>(infos.length); byte b; int i; SignerInfo[] arrayOfSignerInfo1;
/*  760 */       for (i = (arrayOfSignerInfo1 = infos).length, b = 0; b < i; ) { SignerInfo info = arrayOfSignerInfo1[b];
/*  761 */         if (signersType != 2 || info.isTrusted()) {
/*      */ 
/*      */           
/*  764 */           Certificate[] certs = info.getCertificateChain();
/*  765 */           if (certs != null && certs.length != 0)
/*      */           
/*  767 */           { List<X509Certificate> certChain = new ArrayList<>(); byte b1; int j; Certificate[] arrayOfCertificate;
/*  768 */             for (j = (arrayOfCertificate = certs).length, b1 = 0; b1 < j; ) { Certificate cert = arrayOfCertificate[b1];
/*  769 */               certChain.add((X509Certificate)cert); b1++; }
/*      */             
/*  771 */             results.put((X509Certificate)certs[0], certChain); } 
/*      */         }  b++; }
/*  773 */        return results;
/*  774 */     } catch (Exception exception) {
/*  775 */       return Collections.emptyMap();
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public final <A> A adapt(Class<A> adapterType) {
/*  781 */     checkAdaptPermission(adapterType);
/*  782 */     return adapt0(adapterType);
/*      */   }
/*      */   
/*      */   private void readLock() {
/*  786 */     this.equinoxContainer.getStorage().getModuleDatabase().readLock();
/*      */   }
/*      */   
/*      */   private void readUnlock() {
/*  790 */     this.equinoxContainer.getStorage().getModuleDatabase().readUnlock();
/*      */   }
/*      */ 
/*      */   
/*      */   private <A> A adapt0(Class<A> adapterType) {
/*  795 */     if (AccessControlContext.class.equals(adapterType)) {
/*  796 */       BundleInfo.Generation current = (BundleInfo.Generation)this.module.getCurrentRevision().getRevisionInfo();
/*  797 */       ProtectionDomain domain = current.getDomain();
/*  798 */       return (domain == null) ? null : (A)new AccessControlContext(new ProtectionDomain[] { domain });
/*      */     } 
/*      */     
/*  801 */     if (BundleContext.class.equals(adapterType)) {
/*      */       try {
/*  803 */         return (A)getBundleContext();
/*  804 */       } catch (SecurityException securityException) {
/*  805 */         return null;
/*      */       } 
/*      */     }
/*      */     
/*  809 */     if (BundleRevision.class.equals(adapterType)) {
/*  810 */       if (this.module.getState().equals(Module.State.UNINSTALLED)) {
/*  811 */         return null;
/*      */       }
/*  813 */       return (A)this.module.getCurrentRevision();
/*      */     } 
/*      */     
/*  816 */     if (BundleRevisions.class.equals(adapterType)) {
/*  817 */       return (A)this.module.getRevisions();
/*      */     }
/*      */     
/*  820 */     if (BundleStartLevel.class.equals(adapterType)) {
/*  821 */       return (A)this.module;
/*      */     }
/*      */     
/*  824 */     if (BundleWiring.class.equals(adapterType)) {
/*  825 */       if (this.module.getState().equals(Module.State.UNINSTALLED)) {
/*  826 */         return null;
/*      */       }
/*  828 */       ModuleRevision revision = this.module.getCurrentRevision();
/*  829 */       if (revision == null) {
/*  830 */         return null;
/*      */       }
/*  832 */       return (A)revision.getWiring();
/*      */     } 
/*      */     
/*  835 */     if (BundleDTO.class.equals(adapterType)) {
/*      */ 
/*      */       
/*  838 */       readLock();
/*      */       try {
/*  840 */         return (A)DTOBuilder.newBundleDTO(this);
/*      */       } finally {
/*  842 */         readUnlock();
/*      */       } 
/*      */     } 
/*      */     
/*  846 */     if (BundleStartLevelDTO.class.equals(adapterType)) {
/*  847 */       if (this.module.getState().equals(Module.State.UNINSTALLED)) {
/*  848 */         return null;
/*      */       }
/*  850 */       return (A)DTOBuilder.newBundleStartLevelDTO(this, (BundleStartLevel)this.module);
/*      */     } 
/*      */     
/*  853 */     if (BundleRevisionDTO.class.equals(adapterType)) {
/*  854 */       if (this.module.getState().equals(Module.State.UNINSTALLED)) {
/*  855 */         return null;
/*      */       }
/*  857 */       return (A)DTOBuilder.newBundleRevisionDTO((BundleRevision)this.module.getCurrentRevision());
/*      */     } 
/*      */     
/*  860 */     if (BundleRevisionDTO[].class.equals(adapterType)) {
/*  861 */       if (this.module.getState().equals(Module.State.UNINSTALLED)) {
/*  862 */         return null;
/*      */       }
/*      */ 
/*      */       
/*  866 */       return (A)DTOBuilder.newArrayBundleRevisionDTO((BundleRevisions)this.module.getRevisions());
/*      */     } 
/*      */     
/*  869 */     if (BundleWiringDTO.class.equals(adapterType)) {
/*  870 */       if (this.module.getState().equals(Module.State.UNINSTALLED)) {
/*  871 */         return null;
/*      */       }
/*  873 */       readLock();
/*      */       try {
/*  875 */         return (A)DTOBuilder.newBundleWiringDTO((BundleRevision)this.module.getCurrentRevision());
/*      */       } finally {
/*  877 */         readUnlock();
/*      */       } 
/*      */     } 
/*      */     
/*  881 */     if (BundleWiringDTO[].class.equals(adapterType)) {
/*  882 */       if (this.module.getState().equals(Module.State.UNINSTALLED)) {
/*  883 */         return null;
/*      */       }
/*  885 */       readLock();
/*      */       try {
/*  887 */         return (A)DTOBuilder.newArrayBundleWiringDTO((BundleRevisions)this.module.getRevisions());
/*      */       } finally {
/*  889 */         readUnlock();
/*      */       } 
/*      */     } 
/*      */     
/*  893 */     if (ServiceReferenceDTO[].class.equals(adapterType)) {
/*  894 */       if (this.module.getState().equals(Module.State.UNINSTALLED)) {
/*  895 */         return null;
/*      */       }
/*  897 */       BundleContextImpl current = getBundleContextImpl();
/*  898 */       ServiceReferenceImpl[] arrayOfServiceReferenceImpl = (current == null) ? null : this.equinoxContainer.getServiceRegistry().getRegisteredServices(current);
/*  899 */       return (A)DTOBuilder.newArrayServiceReferenceDTO((ServiceReference<?>[])arrayOfServiceReferenceImpl);
/*      */     } 
/*      */     
/*  902 */     if (getBundleId() == 0L) {
/*  903 */       if (Framework.class.equals(adapterType)) {
/*  904 */         return (A)this;
/*      */       }
/*      */       
/*  907 */       if (FrameworkStartLevel.class.equals(adapterType)) {
/*  908 */         return (A)this.module.getContainer().getFrameworkStartLevel();
/*      */       }
/*      */       
/*  911 */       if (FrameworkWiring.class.equals(adapterType)) {
/*  912 */         return (A)this.module.getContainer().getFrameworkWiring();
/*      */       }
/*      */       
/*  915 */       if (FrameworkDTO.class.equals(adapterType)) {
/*  916 */         BundleContextImpl current = getBundleContextImpl();
/*  917 */         Map<String, String> configuration = this.equinoxContainer.getConfiguration().getConfiguration();
/*  918 */         readLock();
/*      */         try {
/*  920 */           return (A)DTOBuilder.newFrameworkDTO(current, configuration);
/*      */         } finally {
/*  922 */           readUnlock();
/*      */         } 
/*      */       } 
/*      */       
/*  926 */       if (FrameworkStartLevelDTO.class.equals(adapterType)) {
/*  927 */         return (A)DTOBuilder.newFrameworkStartLevelDTO(this.module.getContainer().getFrameworkStartLevel());
/*      */       }
/*      */       
/*  930 */       if (FrameworkWiringDTO.class.equals(adapterType)) {
/*  931 */         readLock();
/*      */         try {
/*  933 */           Set<ModuleWiring> allWirings = new HashSet<>();
/*  934 */           for (Module m : this.module.getContainer().getModules()) {
/*  935 */             for (ModuleRevision revision : m.getRevisions().getModuleRevisions()) {
/*  936 */               ModuleWiring wiring = revision.getWiring();
/*  937 */               if (wiring != null) {
/*  938 */                 allWirings.add(wiring);
/*      */               }
/*      */             } 
/*      */           } 
/*  942 */           for (ModuleRevision revision : this.module.getContainer().getRemovalPending()) {
/*  943 */             ModuleWiring wiring = revision.getWiring();
/*  944 */             if (wiring != null) {
/*  945 */               allWirings.add(wiring);
/*      */             }
/*      */           } 
/*  948 */           return (A)DTOBuilder.newFrameworkWiringDTO(allWirings);
/*      */         } finally {
/*  950 */           readUnlock();
/*      */         } 
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/*  956 */     if (Module.class.equals(adapterType)) {
/*  957 */       return (A)this.module;
/*      */     }
/*  959 */     if (ProtectionDomain.class.equals(adapterType)) {
/*  960 */       BundleInfo.Generation current = (BundleInfo.Generation)this.module.getCurrentRevision().getRevisionInfo();
/*  961 */       return (A)current.getDomain();
/*      */     } 
/*  963 */     if (SignedContent.class.equals(adapterType)) {
/*  964 */       return (A)getSignedContent();
/*      */     }
/*  966 */     if (File.class.equals(adapterType)) {
/*  967 */       BundleInfo.Generation current = (BundleInfo.Generation)this.module.getCurrentRevision().getRevisionInfo();
/*  968 */       return (A)current.getContent();
/*      */     } 
/*  970 */     return null;
/*      */   }
/*      */   
/*      */   private SignedContent getSignedContent() {
/*  974 */     SignedContent current = this.signedContent;
/*  975 */     if (current == null) {
/*  976 */       SignedContentFactory factory = this.equinoxContainer.getSignedContentFactory();
/*  977 */       if (factory == null) {
/*  978 */         return null;
/*      */       }
/*      */       try {
/*  981 */         this.signedContent = current = factory.getSignedContent(this);
/*      */       }
/*  983 */       catch (InvalidKeyException|java.security.SignatureException|java.security.cert.CertificateException|java.security.NoSuchAlgorithmException|java.security.NoSuchProviderException|IOException invalidKeyException) {
/*  984 */         return null;
/*      */       } 
/*      */     } 
/*  987 */     return current;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private <A> void checkAdaptPermission(Class<A> adapterType) {
/*  994 */     SecurityManager sm = System.getSecurityManager();
/*  995 */     if (sm == null) {
/*      */       return;
/*      */     }
/*  998 */     sm.checkPermission((Permission)new AdaptPermission(adapterType.getName(), this, "adapt"));
/*      */   }
/*      */ 
/*      */   
/*      */   public File getDataFile(String filename) {
/* 1003 */     checkValid();
/* 1004 */     BundleInfo.Generation current = (BundleInfo.Generation)this.module.getCurrentRevision().getRevisionInfo();
/* 1005 */     return current.getBundleInfo().getDataFile(filename);
/*      */   }
/*      */ 
/*      */   
/*      */   public Bundle getBundle() {
/* 1010 */     return this;
/*      */   }
/*      */   
/*      */   public Module getModule() {
/* 1014 */     return this.module;
/*      */   }
/*      */   
/*      */   private final void checkValid() {
/* 1018 */     if (this.module.getState().equals(Module.State.UNINSTALLED))
/* 1019 */       throw new IllegalStateException("Bundle has been uninstalled: " + this); 
/*      */   }
/*      */   
/*      */   public boolean isFragment() {
/* 1023 */     return ((getModule().getCurrentRevision().getTypes() & 0x1) != 0);
/*      */   }
/*      */   
/*      */   void startWorker0() throws BundleException {
/* 1027 */     BundleContextImpl current = createBundleContext();
/* 1028 */     if (current == null) {
/* 1029 */       throw new BundleException("Unable to create bundle context! " + this);
/*      */     }
/*      */     try {
/* 1032 */       current.start();
/* 1033 */     } catch (BundleException e) {
/* 1034 */       current.close();
/* 1035 */       synchronized (this.monitor) {
/* 1036 */         this.context = null;
/*      */       } 
/* 1038 */       throw e;
/*      */     } 
/*      */   }
/*      */   
/*      */   void stopWorker0() throws BundleException {
/* 1043 */     BundleContextImpl current = getBundleContextImpl();
/* 1044 */     if (current != null) {
/*      */       try {
/* 1046 */         current.stop();
/*      */       } finally {
/* 1048 */         current.close();
/*      */       } 
/* 1050 */       synchronized (this.monitor) {
/* 1051 */         this.context = null;
/*      */       } 
/*      */     } 
/*      */   }
/*      */   
/*      */   ResolutionReport resolve() {
/* 1057 */     if (!Module.RESOLVED_SET.contains(this.module.getState())) {
/* 1058 */       return this.module.getContainer().resolve(Collections.singletonList(this.module), true);
/*      */     }
/* 1060 */     return null;
/*      */   }
/*      */   
/*      */   List<BundleInfo.Generation> getGenerations() {
/* 1064 */     List<BundleInfo.Generation> result = new ArrayList<>();
/* 1065 */     ModuleRevision current = getModule().getCurrentRevision();
/* 1066 */     result.add((BundleInfo.Generation)current.getRevisionInfo());
/* 1067 */     ModuleWiring wiring = current.getWiring();
/* 1068 */     if (wiring != null) {
/* 1069 */       List<ModuleWire> hostWires = wiring.getProvidedModuleWires("osgi.wiring.host");
/* 1070 */       if (hostWires != null) {
/* 1071 */         for (ModuleWire hostWire : hostWires) {
/* 1072 */           result.add((BundleInfo.Generation)hostWire.getRequirer().getRevisionInfo());
/*      */         }
/*      */       }
/*      */     } 
/* 1076 */     return result;
/*      */   }
/*      */   
/*      */   EquinoxContainer getEquinoxContainer() {
/* 1080 */     return this.equinoxContainer;
/*      */   }
/*      */ 
/*      */   
/*      */   public String toString() {
/* 1085 */     String name = getSymbolicName();
/* 1086 */     if (name == null)
/* 1087 */       name = "unknown"; 
/* 1088 */     return String.valueOf(name) + '_' + getVersion() + " [" + getBundleId() + "]";
/*      */   }
/*      */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.osgi-3.18.400.jar!\org\eclipse\osgi\internal\framework\EquinoxBundle.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */