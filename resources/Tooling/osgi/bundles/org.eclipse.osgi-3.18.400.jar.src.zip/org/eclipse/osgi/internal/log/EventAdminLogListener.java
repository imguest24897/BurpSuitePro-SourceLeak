/*     */ package org.eclipse.osgi.internal.log;
/*     */ 
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.security.AccessController;
/*     */ import java.security.PrivilegedActionException;
/*     */ import java.util.Dictionary;
/*     */ import java.util.Hashtable;
/*     */ import org.eclipse.equinox.log.SynchronousLogListener;
/*     */ import org.osgi.framework.Bundle;
/*     */ import org.osgi.framework.ServiceReference;
/*     */ import org.osgi.service.log.LogEntry;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class EventAdminLogListener
/*     */   implements SynchronousLogListener
/*     */ {
/*     */   public static final String TOPIC = "org/osgi/service/log/LogEntry";
/*     */   public static final char TOPIC_SEPARATOR = '/';
/*     */   public static final String LOG_ERROR = "LOG_ERROR";
/*     */   public static final String LOG_WARNING = "LOG_WARNING";
/*     */   public static final String LOG_INFO = "LOG_INFO";
/*     */   public static final String LOG_DEBUG = "LOG_DEBUG";
/*     */   public static final String LOG_OTHER = "LOG_OTHER";
/*     */   public static final String TIMESTAMP = "timestamp";
/*     */   public static final String MESSAGE = "message";
/*     */   public static final String LOG_LEVEL = "log.level";
/*     */   public static final String LOG_ENTRY = "log.entry";
/*     */   public static final String SERVICE = "service";
/*     */   public static final String SERVICE_ID = "service.id";
/*     */   public static final String SERVICE_OBJECTCLASS = "service.objectClass";
/*     */   public static final String SERVICE_PID = "service.pid";
/*     */   public static final String BUNDLE = "bundle";
/*     */   public static final String BUNDLE_ID = "bundle.id";
/*     */   public static final String BUNDLE_SYMBOLICNAME = "bundle.symbolicName";
/*     */   public static final String EVENT = "event";
/*     */   public static final String EXCEPTION = "exception";
/*     */   public static final String EXCEPTION_CLASS = "exception.class";
/*     */   public static final String EXCEPTION_MESSAGE = "exception.message";
/*     */   final Object eventAdmin;
/*     */   final Method postEvent;
/*     */   private final Constructor<?> event;
/*     */   
/*     */   public EventAdminLogListener(Object eventAdmin) throws ClassNotFoundException, NoSuchMethodException {
/*  60 */     this.eventAdmin = eventAdmin;
/*  61 */     Class<?> eventAdminClass = eventAdmin.getClass();
/*  62 */     ClassLoader cl = eventAdminClass.getClassLoader();
/*  63 */     Class<?> eventClass = cl.loadClass("org.osgi.service.event.Event");
/*     */     
/*  65 */     this.postEvent = eventAdminClass.getMethod("postEvent", new Class[] { eventClass });
/*  66 */     this.event = eventClass.getConstructor(new Class[] { String.class, Dictionary.class });
/*     */   }
/*     */ 
/*     */   
/*     */   public void logged(LogEntry entry) {
/*     */     try {
/*  72 */       AccessController.doPrivileged(() -> {
/*     */             Object convertedEvent = convertEvent(paramLogEntry);
/*     */             this.postEvent.invoke(this.eventAdmin, new Object[] { convertedEvent });
/*     */             return null;
/*     */           });
/*  77 */     } catch (PrivilegedActionException e) {
/*  78 */       Throwable cause = e.getCause();
/*  79 */       if (cause instanceof InvocationTargetException) {
/*  80 */         Throwable t = ((InvocationTargetException)cause).getTargetException();
/*  81 */         if (t instanceof RuntimeException)
/*  82 */           throw (RuntimeException)t; 
/*  83 */         if (t instanceof Error) {
/*  84 */           throw (Error)t;
/*     */         }
/*  86 */         throw new RuntimeException(t);
/*     */       } 
/*  88 */       throw new RuntimeException(cause);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   Object convertEvent(LogEntry entry) throws InstantiationException, IllegalAccessException, InvocationTargetException {
/*  95 */     String topic = "org/osgi/service/log/LogEntry";
/*  96 */     int level = entry.getLevel();
/*  97 */     switch (level) {
/*     */       case 1:
/*  99 */         topic = String.valueOf(topic) + "/LOG_ERROR";
/*     */         break;
/*     */       case 2:
/* 102 */         topic = String.valueOf(topic) + "/LOG_WARNING";
/*     */         break;
/*     */       case 3:
/* 105 */         topic = String.valueOf(topic) + "/LOG_INFO";
/*     */         break;
/*     */       case 4:
/* 108 */         topic = String.valueOf(topic) + "/LOG_DEBUG";
/*     */         break;
/*     */       default:
/* 111 */         topic = String.valueOf(topic) + "/LOG_OTHER"; break;
/*     */     } 
/* 113 */     Hashtable<String, Object> properties = new Hashtable<>();
/* 114 */     Bundle bundle = entry.getBundle();
/* 115 */     if (bundle == null) {
/* 116 */       throw new RuntimeException("LogEntry.getBundle() returns null");
/*     */     }
/* 118 */     putBundleProperties(properties, bundle);
/* 119 */     Throwable t = entry.getException();
/* 120 */     if (t != null) {
/* 121 */       putExceptionProperties(properties, t);
/*     */     }
/* 123 */     ServiceReference<?> ref = entry.getServiceReference();
/* 124 */     if (ref != null) {
/* 125 */       putServiceReferenceProperties(properties, ref);
/*     */     }
/* 127 */     properties.put("log.entry", entry);
/* 128 */     properties.put("log.level", Integer.valueOf(entry.getLevel()));
/* 129 */     if (entry.getMessage() != null)
/* 130 */       properties.put("message", entry.getMessage()); 
/* 131 */     properties.put("timestamp", Long.valueOf(entry.getTime()));
/* 132 */     return this.event.newInstance(new Object[] { topic, properties });
/*     */   }
/*     */   
/*     */   public static void putServiceReferenceProperties(Hashtable<String, Object> properties, ServiceReference<?> ref) {
/* 136 */     properties.put("service", ref);
/* 137 */     properties.put("service.id", ref.getProperty("service.id"));
/* 138 */     Object o = ref.getProperty("service.pid");
/* 139 */     if (o != null && o instanceof String) {
/* 140 */       properties.put("service.pid", o);
/*     */     }
/* 142 */     Object o2 = ref.getProperty("objectClass");
/* 143 */     if (o2 != null && o2 instanceof String[]) {
/* 144 */       properties.put("service.objectClass", o2);
/*     */     }
/*     */   }
/*     */   
/*     */   public static void putBundleProperties(Hashtable<String, Object> properties, Bundle bundle) {
/* 149 */     properties.put("bundle.id", Long.valueOf(bundle.getBundleId()));
/* 150 */     String symbolicName = bundle.getSymbolicName();
/* 151 */     if (symbolicName != null) {
/* 152 */       properties.put("bundle.symbolicName", symbolicName);
/*     */     }
/* 154 */     properties.put("bundle", bundle);
/*     */   }
/*     */   
/*     */   public static void putExceptionProperties(Hashtable<String, Object> properties, Throwable t) {
/* 158 */     properties.put("exception", t);
/* 159 */     properties.put("exception.class", t.getClass().getName());
/* 160 */     String message = t.getMessage();
/* 161 */     if (message != null)
/* 162 */       properties.put("exception.message", t.getMessage()); 
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.osgi-3.18.400.jar!\org\eclipse\osgi\internal\log\EventAdminLogListener.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */