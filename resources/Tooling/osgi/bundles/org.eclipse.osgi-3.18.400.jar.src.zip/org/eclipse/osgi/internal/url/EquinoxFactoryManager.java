/*     */ package org.eclipse.osgi.internal.url;
/*     */ 
/*     */ import java.lang.reflect.Field;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Modifier;
/*     */ import java.net.ContentHandlerFactory;
/*     */ import java.net.URL;
/*     */ import java.net.URLConnection;
/*     */ import java.net.URLStreamHandlerFactory;
/*     */ import java.util.Collections;
/*     */ import java.util.Hashtable;
/*     */ import org.eclipse.osgi.internal.framework.EquinoxContainer;
/*     */ import org.osgi.framework.BundleContext;
/*     */ import org.osgi.framework.FrameworkUtil;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class EquinoxFactoryManager
/*     */ {
/*     */   private final EquinoxContainer container;
/*     */   private volatile URLStreamHandlerFactoryImpl urlStreamHandlerFactory;
/*     */   private volatile ContentHandlerFactoryImpl contentHandlerFactory;
/*     */   
/*     */   public EquinoxFactoryManager(EquinoxContainer container) {
/*  36 */     this.container = container;
/*     */   }
/*     */   
/*     */   public void installHandlerFactories(BundleContext context) {
/*  40 */     installURLStreamHandlerFactory(context);
/*  41 */     installContentHandlerFactory(context);
/*     */   }
/*     */   
/*     */   private void installURLStreamHandlerFactory(BundleContext context) {
/*  45 */     URLStreamHandlerFactoryImpl shf = new URLStreamHandlerFactoryImpl(context, this.container);
/*     */     
/*     */     try {
/*  48 */       URL.setURLStreamHandlerFactory(shf);
/*  49 */     } catch (Error error) {
/*     */       
/*     */       try {
/*  52 */         forceURLStreamHandlerFactory(shf);
/*  53 */       } catch (Throwable ex) {
/*  54 */         this.container.getLogServices().log("org.eclipse.osgi", 4, ex.getMessage(), ex);
/*  55 */         this.urlStreamHandlerFactory = null;
/*     */         return;
/*     */       } 
/*     */     } 
/*  59 */     this.urlStreamHandlerFactory = shf;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static void forceURLStreamHandlerFactory(URLStreamHandlerFactoryImpl shf) throws Exception {
/*  65 */     FrameworkUtil.asDictionary(Collections.emptyMap());
/*  66 */     Field factoryField = getField(URL.class, URLStreamHandlerFactory.class, false);
/*  67 */     if (factoryField == null) {
/*  68 */       throw new Exception("Could not find URLStreamHandlerFactory field");
/*     */     }
/*  70 */     Object lock = getURLStreamHandlerFactoryLock();
/*  71 */     synchronized (lock) {
/*  72 */       URLStreamHandlerFactory factory = (URLStreamHandlerFactory)factoryField.get(null);
/*     */ 
/*     */       
/*  75 */       if (factory != null) {
/*     */         try {
/*  77 */           factory.getClass().getMethod("isMultiplexing", null);
/*  78 */           Method register = factory.getClass().getMethod("register", new Class[] { Object.class });
/*  79 */           register.invoke(factory, new Object[] { shf });
/*  80 */         } catch (NoSuchMethodException noSuchMethodException) {
/*     */           
/*  82 */           shf.setParentFactory(factory);
/*  83 */           factory = shf;
/*     */         } 
/*     */       }
/*  86 */       factoryField.set(null, null);
/*     */ 
/*     */       
/*  89 */       resetURLStreamHandlers();
/*  90 */       URL.setURLStreamHandlerFactory(factory);
/*     */     } 
/*     */   }
/*     */   
/*     */   private static void resetURLStreamHandlers() throws IllegalAccessException {
/*  95 */     Field handlersField = getField(URL.class, Hashtable.class, false);
/*  96 */     if (handlersField != null) {
/*     */       
/*  98 */       Hashtable<?, ?> handlers = (Hashtable<?, ?>)handlersField.get(null);
/*  99 */       if (handlers != null)
/* 100 */         handlers.clear(); 
/*     */     } 
/*     */   }
/*     */   
/*     */   private static Object getURLStreamHandlerFactoryLock() throws IllegalAccessException {
/*     */     Object<URL> lock;
/*     */     try {
/* 107 */       Field streamHandlerLockField = URL.class.getDeclaredField("streamHandlerLock");
/* 108 */       MultiplexingFactory.setAccessible(streamHandlerLockField);
/* 109 */       lock = (Object<URL>)streamHandlerLockField.get(null);
/* 110 */     } catch (NoSuchFieldException noSuchFieldException) {
/*     */       
/* 112 */       lock = (Object<URL>)URL.class;
/*     */     } 
/* 114 */     return lock;
/*     */   }
/*     */   
/*     */   private void installContentHandlerFactory(BundleContext context) {
/* 118 */     ContentHandlerFactoryImpl chf = new ContentHandlerFactoryImpl(context, this.container);
/*     */     
/*     */     try {
/* 121 */       URLConnection.setContentHandlerFactory(chf);
/* 122 */     } catch (Error error) {
/*     */       
/*     */       try {
/* 125 */         forceContentHandlerFactory(chf);
/* 126 */       } catch (Throwable ex) {
/*     */         
/* 128 */         this.container.getLogServices().log("org.eclipse.osgi", 4, ex.getMessage(), ex);
/* 129 */         this.contentHandlerFactory = null;
/*     */         return;
/*     */       } 
/*     */     } 
/* 133 */     this.contentHandlerFactory = chf;
/*     */   }
/*     */   
/*     */   private static void forceContentHandlerFactory(ContentHandlerFactoryImpl chf) throws Exception {
/* 137 */     Field factoryField = getField(URLConnection.class, ContentHandlerFactory.class, false);
/* 138 */     if (factoryField == null)
/* 139 */       throw new Exception("Could not find ContentHandlerFactory field"); 
/* 140 */     synchronized (URLConnection.class) {
/* 141 */       ContentHandlerFactory factory = (ContentHandlerFactory)factoryField.get(null);
/*     */ 
/*     */ 
/*     */       
/* 145 */       if (factory != null) {
/*     */         try {
/* 147 */           factory.getClass().getMethod("isMultiplexing", null);
/* 148 */           Method register = factory.getClass().getMethod("register", new Class[] { Object.class });
/* 149 */           register.invoke(factory, new Object[] { chf });
/* 150 */         } catch (NoSuchMethodException noSuchMethodException) {
/*     */           
/* 152 */           chf.setParentFactory(factory);
/* 153 */           factory = chf;
/*     */         } 
/*     */       }
/*     */       
/* 157 */       factoryField.set(null, null);
/*     */ 
/*     */       
/* 160 */       resetContentHandlers();
/* 161 */       URLConnection.setContentHandlerFactory(factory);
/*     */     } 
/*     */   }
/*     */   
/*     */   private static void resetContentHandlers() throws IllegalAccessException {
/* 166 */     Field handlersField = getField(URLConnection.class, Hashtable.class, false);
/* 167 */     if (handlersField != null) {
/*     */       
/* 169 */       Hashtable<?, ?> handlers = (Hashtable<?, ?>)handlersField.get(null);
/* 170 */       if (handlers != null)
/* 171 */         handlers.clear(); 
/*     */     } 
/*     */   }
/*     */   
/*     */   public void uninstallHandlerFactories() {
/* 176 */     uninstallURLStreamHandlerFactory();
/* 177 */     uninstallContentHandlerFactory();
/*     */   }
/*     */   
/*     */   private void uninstallURLStreamHandlerFactory() {
/* 181 */     if (this.urlStreamHandlerFactory == null) {
/*     */       return;
/*     */     }
/*     */     try {
/* 185 */       Field factoryField = getField(URL.class, URLStreamHandlerFactory.class, false);
/* 186 */       if (factoryField == null)
/*     */         return; 
/* 188 */       Object lock = getURLStreamHandlerFactoryLock();
/* 189 */       synchronized (lock) {
/* 190 */         URLStreamHandlerFactory factory = (URLStreamHandlerFactory)factoryField.get(null);
/* 191 */         if (factory == this.urlStreamHandlerFactory) {
/* 192 */           factory = (URLStreamHandlerFactory)this.urlStreamHandlerFactory.designateSuccessor();
/*     */         } else {
/* 194 */           Method unregister = factory.getClass().getMethod("unregister", new Class[] { Object.class });
/* 195 */           unregister.invoke(factory, new Object[] { this.urlStreamHandlerFactory });
/*     */         } 
/* 197 */         factoryField.set(null, null);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 203 */         resetURLStreamHandlers();
/* 204 */         if (factory != null)
/* 205 */           URL.setURLStreamHandlerFactory(factory); 
/*     */       } 
/* 207 */     } catch (Throwable throwable) {}
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void uninstallContentHandlerFactory() {
/* 213 */     if (this.contentHandlerFactory == null) {
/*     */       return;
/*     */     }
/*     */     try {
/* 217 */       Field factoryField = getField(URLConnection.class, ContentHandlerFactory.class, false);
/* 218 */       if (factoryField == null)
/*     */         return; 
/* 220 */       synchronized (URLConnection.class) {
/* 221 */         ContentHandlerFactory factory = (ContentHandlerFactory)factoryField.get(null);
/*     */         
/* 223 */         if (factory == this.contentHandlerFactory) {
/* 224 */           factory = (ContentHandlerFactory)this.contentHandlerFactory.designateSuccessor();
/*     */         } else {
/* 226 */           Method unregister = factory.getClass().getMethod("unregister", new Class[] { Object.class });
/* 227 */           unregister.invoke(factory, new Object[] { this.contentHandlerFactory });
/*     */         } 
/*     */         
/* 230 */         factoryField.set(null, null);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 238 */         resetContentHandlers();
/* 239 */         if (factory != null)
/* 240 */           URLConnection.setContentHandlerFactory(factory); 
/*     */       } 
/* 242 */     } catch (Throwable throwable) {}
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static Field getField(Class<?> clazz, Class<?> type, boolean instance) {
/* 248 */     Field[] fields = clazz.getDeclaredFields(); byte b; int i; Field[] arrayOfField1;
/* 249 */     for (i = (arrayOfField1 = fields).length, b = 0; b < i; ) { Field field = arrayOfField1[b];
/* 250 */       boolean isStatic = Modifier.isStatic(field.getModifiers());
/* 251 */       if (instance != isStatic && field.getType().equals(type)) {
/* 252 */         MultiplexingFactory.setAccessible(field);
/* 253 */         return field;
/*     */       }  b++; }
/*     */     
/* 256 */     return null;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.osgi-3.18.400.jar!\org\eclipse\osgi\interna\\url\EquinoxFactoryManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */