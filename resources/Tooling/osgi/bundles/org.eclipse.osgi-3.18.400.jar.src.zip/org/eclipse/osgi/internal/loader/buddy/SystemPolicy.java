/*    */ package org.eclipse.osgi.internal.loader.buddy;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.net.URL;
/*    */ import java.security.AccessController;
/*    */ import java.util.Enumeration;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SystemPolicy
/*    */   implements IBuddyPolicy
/*    */ {
/*    */   public static final byte BOOT = 0;
/*    */   public static final byte EXT = 1;
/*    */   public static final byte APP = 2;
/* 28 */   private static SystemPolicy[] instances = new SystemPolicy[3];
/*    */   
/*    */   private ClassLoader classLoader;
/*    */   
/*    */   public static SystemPolicy getInstance(byte type, ClassLoader bootLoader) {
/* 33 */     if (instances[type] == null) {
/* 34 */       instances[type] = new SystemPolicy();
/* 35 */       (instances[type]).classLoader = AccessController.<ClassLoader>doPrivileged(() -> createClassLoader(paramByte, paramClassLoader));
/*    */     } 
/* 37 */     return instances[type];
/*    */   }
/*    */ 
/*    */   
/*    */   public SystemPolicy() {}
/*    */ 
/*    */   
/*    */   public SystemPolicy(ClassLoader parent) {
/* 45 */     this.classLoader = parent;
/*    */   }
/*    */   
/*    */   static ClassLoader createClassLoader(byte type, ClassLoader bootLoader) {
/* 49 */     switch (type) {
/*    */       case 2:
/* 51 */         if (ClassLoader.getSystemClassLoader() != null)
/* 52 */           return ClassLoader.getSystemClassLoader(); 
/* 53 */         return bootLoader;
/*    */       
/*    */       case 0:
/* 56 */         return bootLoader;
/*    */       
/*    */       case 1:
/* 59 */         if (ClassLoader.getSystemClassLoader() != null)
/* 60 */           return ClassLoader.getSystemClassLoader().getParent(); 
/* 61 */         return bootLoader;
/*    */     } 
/* 63 */     return null;
/*    */   }
/*    */ 
/*    */   
/*    */   public Class<?> loadClass(String name) {
/*    */     try {
/* 69 */       return this.classLoader.loadClass(name);
/* 70 */     } catch (ClassNotFoundException classNotFoundException) {
/* 71 */       return null;
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   public URL loadResource(String name) {
/* 77 */     return this.classLoader.getResource(name);
/*    */   }
/*    */ 
/*    */   
/*    */   public Enumeration<URL> loadResources(String name) {
/*    */     try {
/* 83 */       return this.classLoader.getResources(name);
/* 84 */     } catch (IOException iOException) {
/* 85 */       return null;
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.osgi-3.18.400.jar!\org\eclipse\osgi\internal\loader\buddy\SystemPolicy.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */