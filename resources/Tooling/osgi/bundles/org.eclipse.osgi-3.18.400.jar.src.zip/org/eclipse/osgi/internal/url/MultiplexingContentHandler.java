/*    */ package org.eclipse.osgi.internal.url;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.net.ContentHandler;
/*    */ import java.net.URLConnection;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MultiplexingContentHandler
/*    */   extends ContentHandler
/*    */ {
/*    */   private String contentType;
/*    */   private ContentHandlerFactoryImpl factory;
/*    */   
/*    */   public MultiplexingContentHandler(String contentType, ContentHandlerFactoryImpl factory) {
/* 24 */     this.contentType = contentType;
/* 25 */     this.factory = factory;
/*    */   }
/*    */ 
/*    */   
/*    */   public Object getContent(URLConnection uConn) throws IOException {
/* 30 */     ContentHandler handler = this.factory.findAuthorizedContentHandler(this.contentType);
/* 31 */     if (handler != null) {
/* 32 */       return handler.getContent(uConn);
/*    */     }
/* 34 */     return uConn.getInputStream();
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.osgi-3.18.400.jar!\org\eclipse\osgi\interna\\url\MultiplexingContentHandler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */