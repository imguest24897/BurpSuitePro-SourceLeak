/*      */ package org.eclipse.osgi.internal.framework;
/*      */ 
/*      */ import java.io.File;
/*      */ import java.io.InputStream;
/*      */ import java.lang.reflect.InvocationTargetException;
/*      */ import java.security.AccessController;
/*      */ import java.security.PrivilegedAction;
/*      */ import java.security.PrivilegedActionException;
/*      */ import java.security.PrivilegedExceptionAction;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Collection;
/*      */ import java.util.Collections;
/*      */ import java.util.Dictionary;
/*      */ import java.util.HashMap;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import org.eclipse.osgi.container.Module;
/*      */ import org.eclipse.osgi.container.ModuleWiring;
/*      */ import org.eclipse.osgi.framework.eventmgr.EventDispatcher;
/*      */ import org.eclipse.osgi.internal.debug.Debug;
/*      */ import org.eclipse.osgi.internal.loader.BundleLoader;
/*      */ import org.eclipse.osgi.internal.messages.Msg;
/*      */ import org.eclipse.osgi.internal.serviceregistry.ServiceReferenceImpl;
/*      */ import org.eclipse.osgi.internal.serviceregistry.ServiceRegistrationImpl;
/*      */ import org.eclipse.osgi.internal.serviceregistry.ServiceRegistry;
/*      */ import org.eclipse.osgi.internal.serviceregistry.ServiceUse;
/*      */ import org.eclipse.osgi.internal.serviceregistry.ShrinkableCollection;
/*      */ import org.eclipse.osgi.storage.BundleInfo;
/*      */ import org.eclipse.osgi.util.NLS;
/*      */ import org.osgi.framework.Bundle;
/*      */ import org.osgi.framework.BundleActivator;
/*      */ import org.osgi.framework.BundleContext;
/*      */ import org.osgi.framework.BundleEvent;
/*      */ import org.osgi.framework.BundleException;
/*      */ import org.osgi.framework.BundleListener;
/*      */ import org.osgi.framework.Filter;
/*      */ import org.osgi.framework.FrameworkEvent;
/*      */ import org.osgi.framework.FrameworkListener;
/*      */ import org.osgi.framework.InvalidSyntaxException;
/*      */ import org.osgi.framework.ServiceEvent;
/*      */ import org.osgi.framework.ServiceFactory;
/*      */ import org.osgi.framework.ServiceListener;
/*      */ import org.osgi.framework.ServiceObjects;
/*      */ import org.osgi.framework.ServiceReference;
/*      */ import org.osgi.framework.ServiceRegistration;
/*      */ import org.osgi.framework.hooks.bundle.FindHook;
/*      */ import org.osgi.resource.Capability;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class BundleContextImpl
/*      */   implements BundleContext, EventDispatcher<Object, Object, Object>
/*      */ {
/*      */   private volatile boolean valid;
/*      */   final EquinoxBundle bundle;
/*      */   final EquinoxContainer container;
/*      */   final Debug debug;
/*      */   private HashMap<ServiceRegistrationImpl<?>, ServiceUse<?>> servicesInUse;
/*      */   private BundleActivator activator;
/*   97 */   private final Object contextLock = new Object();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public BundleContextImpl(EquinoxBundle bundle, EquinoxContainer container) {
/*  106 */     this.bundle = bundle;
/*  107 */     this.container = container;
/*  108 */     this.debug = container.getConfiguration().getDebug();
/*  109 */     this.valid = true;
/*  110 */     synchronized (this.contextLock) {
/*  111 */       this.servicesInUse = null;
/*      */     } 
/*  113 */     this.activator = null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void close() {
/*  121 */     this.valid = false;
/*      */     
/*  123 */     ServiceRegistry registry = this.container.getServiceRegistry();
/*      */     
/*  125 */     registry.removeAllServiceListeners(this);
/*  126 */     this.container.getEventPublisher().removeAllListeners(this);
/*      */ 
/*      */     
/*  129 */     registry.unregisterServices(this);
/*      */ 
/*      */     
/*  132 */     registry.releaseServicesInUse(this);
/*      */     
/*  134 */     synchronized (this.contextLock) {
/*  135 */       this.servicesInUse = null;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getProperty(String key) {
/*  148 */     SecurityManager sm = System.getSecurityManager();
/*      */     
/*  150 */     if (sm != null) {
/*  151 */       sm.checkPropertyAccess(key);
/*      */     }
/*      */     
/*  154 */     return this.container.getConfiguration().getProperty(key);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Bundle getBundle() {
/*  164 */     checkValid();
/*      */     
/*  166 */     return getBundleImpl();
/*      */   }
/*      */   
/*      */   public EquinoxBundle getBundleImpl() {
/*  170 */     return this.bundle;
/*      */   }
/*      */ 
/*      */   
/*      */   public Bundle installBundle(String location) throws BundleException {
/*  175 */     return installBundle(location, null);
/*      */   }
/*      */ 
/*      */   
/*      */   public Bundle installBundle(String location, InputStream in) throws BundleException {
/*  180 */     checkValid();
/*      */     
/*  182 */     BundleInfo.Generation generation = this.container.getStorage().install(this.bundle.getModule(), location, in);
/*  183 */     return generation.getRevision().getBundle();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Bundle getBundle(long id) {
/*  195 */     Module m = this.container.getStorage().getModuleContainer().getModule(id);
/*  196 */     if (m == null) {
/*  197 */       return null;
/*      */     }
/*      */     
/*  200 */     List<Bundle> bundles = new ArrayList<>(1);
/*  201 */     bundles.add(m.getBundle());
/*  202 */     notifyFindHooks(this, bundles);
/*  203 */     if (bundles.isEmpty()) {
/*  204 */       return null;
/*      */     }
/*  206 */     return m.getBundle();
/*      */   }
/*      */ 
/*      */   
/*      */   public Bundle getBundle(String location) {
/*  211 */     Module m = this.container.getStorage().getModuleContainer().getModule(location);
/*  212 */     return (m == null) ? null : m.getBundle();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Bundle[] getBundles() {
/*  226 */     List<Module> modules = this.container.getStorage().getModuleContainer().getModules();
/*  227 */     List<Bundle> bundles = new ArrayList<>(modules.size());
/*  228 */     for (Module module : modules) {
/*  229 */       bundles.add(module.getBundle());
/*      */     }
/*      */     
/*  232 */     notifyFindHooks(this, bundles);
/*  233 */     return bundles.<Bundle>toArray(new Bundle[bundles.size()]);
/*      */   }
/*      */   
/*      */   private void notifyFindHooks(final BundleContextImpl context, List<Bundle> allBundles) {
/*  237 */     if (context.getBundleImpl().getBundleId() == 0L)
/*      */     {
/*      */       
/*  240 */       allBundles = new ArrayList<>(allBundles);
/*      */     }
/*  242 */     final ShrinkableCollection shrinkable = new ShrinkableCollection(allBundles);
/*  243 */     if (System.getSecurityManager() == null) {
/*  244 */       notifyFindHooksPriviledged(context, (Collection<Bundle>)shrinkableCollection);
/*      */     } else {
/*  246 */       AccessController.doPrivileged(new PrivilegedAction<Void>()
/*      */           {
/*      */             public Void run() {
/*  249 */               BundleContextImpl.this.notifyFindHooksPriviledged(context, shrinkable);
/*  250 */               return null;
/*      */             }
/*      */           });
/*      */     } 
/*      */   }
/*      */   
/*      */   void notifyFindHooksPriviledged(BundleContextImpl context, Collection<Bundle> allBundles) {
/*  257 */     if (this.debug.DEBUG_HOOKS) {
/*  258 */       Debug.println("notifyBundleFindHooks(" + allBundles + ")");
/*      */     }
/*  260 */     ServiceRegistry sr = this.container.getServiceRegistry();
/*  261 */     if (sr == null) {
/*  262 */       allBundles.clear();
/*      */     } else {
/*  264 */       sr.notifyHooksPrivileged(FindHook.class, "find", (hook, hookRegistration) -> hook.find(paramBundleContextImpl, paramCollection));
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void addServiceListener(ServiceListener listener, String filter) throws InvalidSyntaxException {
/*  271 */     checkValid();
/*      */     
/*  273 */     if (listener == null) {
/*  274 */       throw new IllegalArgumentException();
/*      */     }
/*  276 */     this.container.getServiceRegistry().addServiceListener(this, listener, filter);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void addServiceListener(ServiceListener listener) {
/*      */     try {
/*  291 */       addServiceListener(listener, null);
/*  292 */     } catch (InvalidSyntaxException e) {
/*  293 */       if (this.debug.DEBUG_GENERAL) {
/*  294 */         Debug.println("InvalidSyntaxException w/ null filter" + e.getMessage());
/*  295 */         Debug.printStackTrace((Throwable)e);
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void removeServiceListener(ServiceListener listener) {
/*  315 */     checkValid();
/*      */     
/*  317 */     if (listener == null) {
/*  318 */       throw new IllegalArgumentException();
/*      */     }
/*  320 */     this.container.getServiceRegistry().removeServiceListener(this, listener);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void addBundleListener(BundleListener listener) {
/*  339 */     checkValid();
/*  340 */     if (listener == null) {
/*  341 */       throw new IllegalArgumentException();
/*      */     }
/*      */     
/*  344 */     if (this.debug.DEBUG_EVENTS) {
/*  345 */       String listenerName = String.valueOf(listener.getClass().getName()) + "@" + Integer.toHexString(System.identityHashCode(listener));
/*  346 */       Debug.println("addBundleListener[" + this.bundle + "](" + listenerName + ")");
/*      */     } 
/*      */     
/*  349 */     this.container.getEventPublisher().addBundleListener(listener, this);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void removeBundleListener(BundleListener listener) {
/*  367 */     checkValid();
/*  368 */     if (listener == null) {
/*  369 */       throw new IllegalArgumentException();
/*      */     }
/*      */     
/*  372 */     if (this.debug.DEBUG_EVENTS) {
/*  373 */       String listenerName = String.valueOf(listener.getClass().getName()) + "@" + Integer.toHexString(System.identityHashCode(listener));
/*  374 */       Debug.println("removeBundleListener[" + this.bundle + "](" + listenerName + ")");
/*      */     } 
/*      */     
/*  377 */     this.container.getEventPublisher().removeBundleListener(listener, this);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void addFrameworkListener(FrameworkListener listener) {
/*  395 */     checkValid();
/*  396 */     if (listener == null) {
/*  397 */       throw new IllegalArgumentException();
/*      */     }
/*      */     
/*  400 */     if (this.debug.DEBUG_EVENTS) {
/*  401 */       String listenerName = String.valueOf(listener.getClass().getName()) + "@" + Integer.toHexString(System.identityHashCode(listener));
/*  402 */       Debug.println("addFrameworkListener[" + this.bundle + "](" + listenerName + ")");
/*      */     } 
/*      */     
/*  405 */     this.container.getEventPublisher().addFrameworkListener(listener, this);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void removeFrameworkListener(FrameworkListener listener) {
/*  423 */     checkValid();
/*  424 */     if (listener == null) {
/*  425 */       throw new IllegalArgumentException();
/*      */     }
/*      */     
/*  428 */     if (this.debug.DEBUG_EVENTS) {
/*  429 */       String listenerName = String.valueOf(listener.getClass().getName()) + "@" + Integer.toHexString(System.identityHashCode(listener));
/*  430 */       Debug.println("removeFrameworkListener[" + this.bundle + "](" + listenerName + ")");
/*      */     } 
/*      */     
/*  433 */     this.container.getEventPublisher().removeFrameworkListener(listener, this);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ServiceRegistration<?> registerService(String[] clazzes, Object service, Dictionary<String, ?> properties) {
/*  499 */     checkValid();
/*  500 */     return (ServiceRegistration<?>)this.container.getServiceRegistry().registerService(this, clazzes, service, properties);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ServiceRegistration<?> registerService(String clazz, Object service, Dictionary<String, ?> properties) {
/*  517 */     String[] clazzes = { clazz };
/*      */     
/*  519 */     return registerService(clazzes, service, properties);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ServiceReference<?>[] getServiceReferences(String clazz, String filter) throws InvalidSyntaxException {
/*  567 */     checkValid();
/*  568 */     return (ServiceReference<?>[])this.container.getServiceRegistry().getServiceReferences(this, clazz, filter, false);
/*      */   }
/*      */ 
/*      */   
/*      */   public ServiceReference<?>[] getAllServiceReferences(String clazz, String filter) throws InvalidSyntaxException {
/*  573 */     checkValid();
/*  574 */     return (ServiceReference<?>[])this.container.getServiceRegistry().getServiceReferences(this, clazz, filter, true);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ServiceReference<?> getServiceReference(String clazz) {
/*  599 */     checkValid();
/*      */     
/*  601 */     return (ServiceReference<?>)this.container.getServiceRegistry().getServiceReference(this, clazz);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <S> S getService(ServiceReference<S> reference) {
/*  656 */     checkValid();
/*  657 */     if (reference == null)
/*  658 */       throw new NullPointerException("A null service reference is not allowed."); 
/*  659 */     provisionServicesInUseMap();
/*  660 */     S service = (S)this.container.getServiceRegistry().getService(this, (ServiceReferenceImpl)reference);
/*  661 */     return service;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean ungetService(ServiceReference<?> reference) {
/*  701 */     checkValid();
/*      */     
/*  703 */     return this.container.getServiceRegistry().ungetService(this, (ServiceReferenceImpl)reference);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public File getDataFile(String filename) {
/*  732 */     checkValid();
/*      */     
/*  734 */     BundleInfo.Generation generation = (BundleInfo.Generation)this.bundle.getModule().getCurrentRevision().getRevisionInfo();
/*  735 */     return generation.getBundleInfo().getDataFile(filename);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void start() throws BundleException {
/*  748 */     long start = 0L;
/*      */     try {
/*  750 */       if (this.debug.DEBUG_BUNDLE_TIME) {
/*  751 */         start = System.currentTimeMillis();
/*      */       }
/*  753 */       this.activator = loadBundleActivator();
/*  754 */       if (this.debug.DEBUG_BUNDLE_TIME) {
/*  755 */         Debug.println(String.valueOf(System.currentTimeMillis() - start) + " ms to load the activator of " + this.bundle);
/*      */       }
/*  757 */     } catch (Exception e) {
/*  758 */       if (e instanceof RuntimeException) {
/*  759 */         throw (RuntimeException)e;
/*      */       }
/*  761 */       throw new BundleException(String.valueOf(Msg.BundleContextImpl_LoadActivatorError) + ' ' + this.bundle, 
/*  762 */           5, e);
/*      */     } 
/*      */     
/*  765 */     if (this.activator != null) {
/*      */       try {
/*  767 */         startActivator(this.activator);
/*  768 */       } catch (BundleException be) {
/*  769 */         this.activator = null;
/*  770 */         throw be;
/*      */       } finally {
/*  772 */         if (this.debug.DEBUG_BUNDLE_TIME) {
/*  773 */           Debug.println(String.valueOf(System.currentTimeMillis() - start) + " ms to load and start the activator of " + this.bundle);
/*      */         }
/*      */       } 
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private BundleActivator loadBundleActivator() throws ClassNotFoundException, InstantiationException, IllegalAccessException, InvocationTargetException, NoSuchMethodException {
/*  783 */     ModuleWiring wiring = this.bundle.getModule().getCurrentRevision().getWiring();
/*  784 */     if (wiring == null) {
/*  785 */       return null;
/*      */     }
/*  787 */     BundleLoader loader = (BundleLoader)wiring.getModuleLoader();
/*  788 */     if (loader == null) {
/*  789 */       return null;
/*      */     }
/*  791 */     List<Capability> metadata = wiring.getRevision().getCapabilities("equinox.module.data");
/*  792 */     if (metadata.isEmpty()) {
/*  793 */       return null;
/*      */     }
/*      */     
/*  796 */     String activatorName = (String)((Capability)metadata.get(0)).getAttributes().get("activator");
/*  797 */     if (activatorName == null) {
/*  798 */       return null;
/*      */     }
/*  800 */     Class<?> activatorClass = loader.findClass(activatorName);
/*  801 */     return activatorClass.getConstructor(new Class[0]).newInstance(new Object[0]);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void startActivator(final BundleActivator bundleActivator) throws BundleException {
/*      */     try {
/*  810 */       AccessController.doPrivileged(new PrivilegedExceptionAction<Void>()
/*      */           {
/*      */             public Void run() throws Exception {
/*  813 */               if (bundleActivator != null) {
/*      */                 
/*  815 */                 Object previousTCCL = BundleContextImpl.this.setContextFinder();
/*      */                 
/*      */                 try {
/*  818 */                   bundleActivator.start(BundleContextImpl.this);
/*      */                 } finally {
/*  820 */                   if (previousTCCL != Boolean.FALSE)
/*  821 */                     Thread.currentThread().setContextClassLoader((ClassLoader)previousTCCL); 
/*      */                 } 
/*      */               } 
/*  824 */               return null;
/*      */             }
/*      */           });
/*  827 */     } catch (Throwable t) {
/*  828 */       if (t instanceof PrivilegedActionException) {
/*  829 */         t = ((PrivilegedActionException)t).getException();
/*      */       }
/*      */       
/*  832 */       if (this.debug.DEBUG_GENERAL) {
/*  833 */         Debug.printStackTrace(t);
/*      */       }
/*      */       
/*  836 */       String clazz = null;
/*  837 */       clazz = bundleActivator.getClass().getName();
/*      */       
/*  839 */       throw new BundleException(NLS.bind(Msg.BUNDLE_ACTIVATOR_EXCEPTION, new Object[] { clazz, "start", (this.bundle.getSymbolicName() == null) ? this.bundle.getBundleId() : this.bundle.getSymbolicName() }), 5, t);
/*      */     } 
/*      */   }
/*      */   
/*      */   Object setContextFinder() {
/*  844 */     if (!(this.container.getConfiguration()).BUNDLE_SET_TCCL)
/*  845 */       return Boolean.FALSE; 
/*  846 */     Thread currentThread = Thread.currentThread();
/*  847 */     ClassLoader previousTCCL = currentThread.getContextClassLoader();
/*  848 */     ClassLoader contextFinder = this.container.getContextFinder();
/*  849 */     if (previousTCCL != contextFinder) {
/*  850 */       currentThread.setContextClassLoader(this.container.getContextFinder());
/*  851 */       return previousTCCL;
/*      */     } 
/*  853 */     return Boolean.FALSE;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void stop() throws BundleException {
/*      */     try {
/*  866 */       final BundleActivator bundleActivator = this.activator;
/*  867 */       AccessController.doPrivileged(new PrivilegedExceptionAction<Void>()
/*      */           {
/*      */             public Void run() throws Exception {
/*  870 */               if (bundleActivator != null) {
/*      */                 
/*  872 */                 Object previousTCCL = BundleContextImpl.this.setContextFinder();
/*      */                 
/*      */                 try {
/*  875 */                   bundleActivator.stop(BundleContextImpl.this);
/*      */                 } finally {
/*  877 */                   if (previousTCCL != Boolean.FALSE)
/*  878 */                     Thread.currentThread().setContextClassLoader((ClassLoader)previousTCCL); 
/*      */                 } 
/*      */               } 
/*  881 */               return null;
/*      */             }
/*      */           });
/*  884 */     } catch (Throwable t) {
/*  885 */       if (t instanceof PrivilegedActionException) {
/*  886 */         t = ((PrivilegedActionException)t).getException();
/*      */       }
/*      */       
/*  889 */       if (this.debug.DEBUG_GENERAL) {
/*  890 */         Debug.printStackTrace(t);
/*      */       }
/*      */       
/*  893 */       String clazz = (this.activator == null) ? "" : this.activator.getClass().getName();
/*      */       
/*  895 */       throw new BundleException(NLS.bind(Msg.BUNDLE_ACTIVATOR_EXCEPTION, new Object[] { clazz, "stop", (this.bundle.getSymbolicName() == null) ? this.bundle.getBundleId() : this.bundle.getSymbolicName() }), 5, t);
/*      */     } finally {
/*  897 */       this.activator = null;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Map<ServiceRegistrationImpl<?>, ServiceUse<?>> getServicesInUseMap() {
/*  908 */     synchronized (this.contextLock) {
/*  909 */       return this.servicesInUse;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void provisionServicesInUseMap() {
/*  918 */     synchronized (this.contextLock) {
/*  919 */       if (this.servicesInUse == null)
/*      */       {
/*  921 */         this.servicesInUse = new HashMap<>(10);
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void dispatchEvent(Object originalListener, Object l, int action, Object object) {
/*  935 */     Object previousTCCL = setContextFinder();
/*      */ 
/*      */     
/*  938 */     try { if (isValid() || this.bundle.getBundleId() == 0L) {
/*  939 */         BundleListener bundleListener; ServiceEvent event; FrameworkListener listener; ServiceListener serviceListener; switch (action) {
/*      */           case 1:
/*      */           case 2:
/*  942 */             bundleListener = (BundleListener)l;
/*      */             
/*  944 */             if (this.debug.DEBUG_EVENTS) {
/*  945 */               String listenerName = String.valueOf(bundleListener.getClass().getName()) + "@" + Integer.toHexString(System.identityHashCode(bundleListener));
/*  946 */               Debug.println("dispatchBundleEvent[" + this.bundle + "](" + listenerName + ")");
/*      */             } 
/*      */             
/*  949 */             bundleListener.bundleChanged((BundleEvent)object);
/*      */             break;
/*      */ 
/*      */           
/*      */           case 3:
/*  954 */             event = (ServiceEvent)object;
/*      */             
/*  956 */             serviceListener = (ServiceListener)l;
/*  957 */             if (this.debug.DEBUG_EVENTS) {
/*  958 */               String listenerName = String.valueOf(serviceListener.getClass().getName()) + "@" + Integer.toHexString(System.identityHashCode(serviceListener));
/*  959 */               Debug.println("dispatchServiceEvent[" + this.bundle + "](" + listenerName + ")");
/*      */             } 
/*  961 */             serviceListener.serviceChanged(event);
/*      */             break;
/*      */ 
/*      */           
/*      */           case 4:
/*  966 */             listener = (FrameworkListener)l;
/*      */             
/*  968 */             if (this.debug.DEBUG_EVENTS) {
/*  969 */               String listenerName = String.valueOf(listener.getClass().getName()) + "@" + Integer.toHexString(System.identityHashCode(listener));
/*  970 */               Debug.println("dispatchFrameworkEvent[" + this.bundle + "](" + listenerName + ")");
/*      */             } 
/*      */             
/*  973 */             listener.frameworkEvent((FrameworkEvent)object);
/*      */             break;
/*      */           
/*      */           default:
/*  977 */             throw new InternalError();
/*      */         } 
/*      */       
/*      */       }  }
/*  981 */     catch (Throwable t)
/*  982 */     { if (this.debug.DEBUG_GENERAL) {
/*  983 */         Debug.println("Exception in bottom level event dispatcher: " + t.getMessage());
/*  984 */         Debug.printStackTrace(t);
/*      */       } 
/*      */       
/*  987 */       this.container.handleRuntimeError(t);
/*      */       
/*  989 */       if (action == 4)
/*  990 */       { FrameworkEvent event = (FrameworkEvent)object;
/*  991 */         if (event.getType() == 2)
/*      */         {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  999 */           if (previousTCCL != Boolean.FALSE)
/* 1000 */             Thread.currentThread().setContextClassLoader((ClassLoader)previousTCCL);  }  }  this.container.getEventPublisher().publishFrameworkEvent(2, this.bundle, t); } finally { if (previousTCCL != Boolean.FALSE) Thread.currentThread().setContextClassLoader((ClassLoader)previousTCCL);
/*      */        }
/*      */   
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Filter createFilter(String filter) throws InvalidSyntaxException {
/* 1017 */     checkValid();
/*      */     
/* 1019 */     return FilterImpl.newInstance(filter, (this.container.getConfiguration().getDebug()).DEBUG_FILTER);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void checkValid() {
/* 1030 */     if (!isValid()) {
/* 1031 */       throw new IllegalStateException(String.valueOf(Msg.BUNDLE_CONTEXT_INVALID_EXCEPTION) + ' ' + this.bundle);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean isValid() {
/* 1041 */     return this.valid;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public <S> ServiceRegistration<S> registerService(Class<S> clazz, S service, Dictionary<String, ?> properties) {
/* 1047 */     ServiceRegistration<S> registration = (ServiceRegistration)registerService(clazz.getName(), service, properties);
/* 1048 */     return registration;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public <S> ServiceRegistration<S> registerService(Class<S> clazz, ServiceFactory<S> factory, Dictionary<String, ?> properties) {
/* 1054 */     ServiceRegistration<S> registration = (ServiceRegistration)registerService(clazz.getName(), factory, properties);
/* 1055 */     return registration;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public <S> ServiceReference<S> getServiceReference(Class<S> clazz) {
/* 1061 */     ServiceReference<S> reference = (ServiceReference)getServiceReference(clazz.getName());
/* 1062 */     return reference;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public <S> Collection<ServiceReference<S>> getServiceReferences(Class<S> clazz, String filter) throws InvalidSyntaxException {
/* 1068 */     ServiceReference[] refs = (ServiceReference[])getServiceReferences(clazz.getName(), filter);
/* 1069 */     if (refs == null) {
/* 1070 */       return Collections.emptyList();
/*      */     }
/* 1072 */     List<ServiceReference<S>> result = new ArrayList<>(refs.length);
/* 1073 */     Collections.addAll(result, (ServiceReference<S>[])refs);
/* 1074 */     return result;
/*      */   }
/*      */   
/*      */   public EquinoxContainer getContainer() {
/* 1078 */     return this.container;
/*      */   }
/*      */ 
/*      */   
/*      */   public <S> ServiceObjects<S> getServiceObjects(ServiceReference<S> reference) {
/* 1083 */     checkValid();
/* 1084 */     if (reference == null)
/* 1085 */       throw new NullPointerException("A null service reference is not allowed."); 
/* 1086 */     provisionServicesInUseMap();
/* 1087 */     return (ServiceObjects<S>)this.container.getServiceRegistry().getServiceObjects(this, (ServiceReferenceImpl)reference);
/*      */   }
/*      */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.osgi-3.18.400.jar!\org\eclipse\osgi\internal\framework\BundleContextImpl.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */