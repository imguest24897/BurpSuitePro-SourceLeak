package org.eclipse.osgi.internal.hookregistry;

import org.eclipse.osgi.storage.BundleInfo;
import org.eclipse.osgi.storage.bundlefile.BundleFile;
import org.eclipse.osgi.storage.bundlefile.BundleFileWrapper;

public interface BundleFileWrapperFactoryHook {
  BundleFileWrapper wrapBundleFile(BundleFile paramBundleFile, BundleInfo.Generation paramGeneration, boolean paramBoolean);
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.osgi-3.18.400.jar!\org\eclipse\osgi\internal\hookregistry\BundleFileWrapperFactoryHook.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */