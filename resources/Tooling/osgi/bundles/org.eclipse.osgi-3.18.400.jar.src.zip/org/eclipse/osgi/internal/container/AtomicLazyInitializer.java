/*    */ package org.eclipse.osgi.internal.container;
/*    */ 
/*    */ import java.util.concurrent.Callable;
/*    */ import java.util.concurrent.atomic.AtomicReference;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AtomicLazyInitializer<V>
/*    */ {
/* 25 */   private final AtomicReference<V> holder = new AtomicReference<>();
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public final V get() {
/* 33 */     return this.holder.get();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public final V getInitialized(Callable<V> initializer) {
/* 43 */     V result = this.holder.get();
/* 44 */     if (result != null) {
/* 45 */       return result;
/*    */     }
/*    */     
/* 48 */     synchronized (this.holder) {
/* 49 */       result = this.holder.get();
/* 50 */       if (result != null) {
/* 51 */         return result;
/*    */       }
/*    */       try {
/* 54 */         result = initializer.call();
/* 55 */       } catch (Exception e) {
/* 56 */         unchecked(e);
/*    */       } 
/* 58 */       this.holder.set(result);
/* 59 */       return result;
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public final V getAndClear() {
/* 68 */     return this.holder.getAndSet(null);
/*    */   }
/*    */   
/*    */   private static <T> T unchecked(Exception exception) {
/* 72 */     return unchecked0(exception);
/*    */   }
/*    */ 
/*    */   
/*    */   private static <T, E extends Exception> T unchecked0(Exception exception) throws E {
/* 77 */     throw (E)exception;
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.osgi-3.18.400.jar!\org\eclipse\osgi\internal\container\AtomicLazyInitializer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */