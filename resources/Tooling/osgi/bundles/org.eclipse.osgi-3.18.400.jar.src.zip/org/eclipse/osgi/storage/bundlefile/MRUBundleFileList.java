/*     */ package org.eclipse.osgi.storage.bundlefile;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.Collections;
/*     */ import java.util.Map;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ import java.util.concurrent.atomic.AtomicInteger;
/*     */ import java.util.concurrent.locks.Condition;
/*     */ import java.util.concurrent.locks.ReentrantLock;
/*     */ import org.eclipse.osgi.framework.eventmgr.EventDispatcher;
/*     */ import org.eclipse.osgi.framework.eventmgr.EventManager;
/*     */ import org.eclipse.osgi.framework.eventmgr.ListenerQueue;
/*     */ import org.eclipse.osgi.internal.debug.Debug;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MRUBundleFileList
/*     */   implements EventDispatcher<Object, Object, BundleFile>
/*     */ {
/*     */   private static final int MIN = 10;
/*  37 */   private static final ThreadLocal<BundleFile> closingBundleFile = new ThreadLocal<>();
/*     */   
/*     */   private final BundleFile[] bundleFileList;
/*     */   
/*     */   private final long[] useStampList;
/*     */   
/*     */   private final int fileLimit;
/*     */   
/*  45 */   private EventManager bundleFileCloserManager = null;
/*     */   
/*     */   private final Map<Object, Object> bundleFileCloser;
/*  48 */   private int numOpen = 0;
/*     */   
/*  50 */   private long curUseStamp = 0L;
/*     */   
/*     */   private boolean firstDispatch = true;
/*     */   
/*  54 */   private final ReentrantLock pendingLock = new ReentrantLock();
/*  55 */   private final Condition pendingCond = this.pendingLock.newCondition();
/*  56 */   private final AtomicInteger pending = new AtomicInteger();
/*     */   
/*     */   private final Debug debug;
/*     */   
/*     */   public MRUBundleFileList(int fileLimit, Debug debug) {
/*  61 */     this.fileLimit = fileLimit;
/*  62 */     this.debug = debug;
/*  63 */     if (fileLimit >= 10) {
/*  64 */       this.bundleFileList = new BundleFile[fileLimit];
/*  65 */       this.useStampList = new long[fileLimit];
/*  66 */       this.bundleFileCloser = Collections.singletonMap(this, this);
/*     */     } else {
/*  68 */       this.bundleFileList = null;
/*  69 */       this.useStampList = null;
/*  70 */       this.bundleFileCloser = null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean add(BundleFile bundleFile) {
/*  82 */     if (this.fileLimit < 10)
/*  83 */       return false; 
/*  84 */     BundleFile toRemove = null;
/*  85 */     EventManager manager = null;
/*  86 */     boolean backpressureNeeded = false;
/*  87 */     synchronized (this) {
/*  88 */       if (bundleFile.getMruIndex() >= 0)
/*  89 */         return false; 
/*  90 */       int index = 0;
/*  91 */       if (this.numOpen < this.fileLimit) {
/*     */ 
/*     */         
/*  94 */         for (int i = 0; i < this.fileLimit; i++) {
/*  95 */           if (this.bundleFileList[i] == null) {
/*  96 */             index = i;
/*     */ 
/*     */             
/*     */             break;
/*     */           } 
/*     */         } 
/*     */       } else {
/* 103 */         index = 0;
/* 104 */         for (int i = 1; i < this.fileLimit; i++) {
/* 105 */           if (this.useStampList[i] < this.useStampList[index])
/* 106 */             index = i; 
/* 107 */         }  toRemove = this.bundleFileList[index];
/* 108 */         if (toRemove.getMruIndex() != index)
/* 109 */           throw new IllegalStateException("The BundleFile has the incorrect mru index: " + index + " != " + toRemove.getMruIndex()); 
/* 110 */         removeInternal(toRemove);
/* 111 */         backpressureNeeded = isBackPressureNeeded();
/*     */       } 
/*     */       
/* 114 */       this.bundleFileList[index] = bundleFile;
/* 115 */       bundleFile.setMruIndex(index);
/* 116 */       incUseStamp(index);
/* 117 */       this.numOpen++;
/* 118 */       if (toRemove != null) {
/* 119 */         if (this.bundleFileCloserManager == null)
/* 120 */           this.bundleFileCloserManager = new EventManager("Bundle File Closer"); 
/* 121 */         manager = this.bundleFileCloserManager;
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 127 */     closeBundleFile(toRemove, manager);
/*     */     
/* 129 */     return backpressureNeeded;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean remove(BundleFile bundleFile) {
/* 138 */     if (this.fileLimit < 10)
/* 139 */       return false; 
/* 140 */     synchronized (this) {
/* 141 */       int index = bundleFile.getMruIndex();
/* 142 */       if (index >= 0 && index < this.fileLimit && this.bundleFileList[index] == bundleFile) {
/* 143 */         removeInternal(bundleFile);
/* 144 */         return true;
/*     */       } 
/*     */     } 
/* 147 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   private void removeInternal(BundleFile bundleFile) {
/* 152 */     int index = bundleFile.getMruIndex();
/* 153 */     bundleFile.setMruIndex(-1);
/* 154 */     this.bundleFileList[index] = null;
/* 155 */     this.useStampList[index] = -1L;
/* 156 */     this.numOpen--;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void use(BundleFile bundleFile) {
/* 164 */     if (this.fileLimit < 10)
/*     */       return; 
/* 166 */     synchronized (this) {
/* 167 */       int index = bundleFile.getMruIndex();
/* 168 */       if (index >= 0 && index < this.fileLimit && this.bundleFileList[index] == bundleFile) {
/* 169 */         incUseStamp(index);
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   private void incUseStamp(int index) {
/* 175 */     if (this.curUseStamp == Long.MAX_VALUE) {
/*     */       
/* 177 */       for (int i = 0; i < this.fileLimit; i++)
/* 178 */         this.useStampList[i] = 0L; 
/* 179 */       this.curUseStamp = 0L;
/*     */     } 
/* 181 */     this.useStampList[index] = ++this.curUseStamp;
/*     */   }
/*     */ 
/*     */   
/*     */   public final void dispatchEvent(Object eventListener, Object listenerObject, int eventAction, BundleFile eventObject) {
/* 186 */     if (this.firstDispatch) {
/*     */       
/* 188 */       Thread.currentThread().setContextClassLoader(null);
/* 189 */       this.firstDispatch = false;
/*     */     } 
/*     */     
/* 192 */     try { closingBundleFile.set(eventObject);
/* 193 */       eventObject.close(); }
/* 194 */     catch (IOException iOException)
/*     */     
/*     */     { 
/* 197 */       closingBundleFile.set(null); } finally { closingBundleFile.set(null);
/* 198 */       this.pendingLock.lock();
/*     */       try {
/* 200 */         if (this.pending.decrementAndGet() < this.fileLimit) {
/* 201 */           this.pendingCond.signalAll();
/*     */         }
/*     */       } finally {
/* 204 */         this.pendingLock.unlock();
/*     */       }  }
/*     */   
/*     */   }
/*     */   
/*     */   private boolean isBackPressureNeeded() {
/* 210 */     this.pendingLock.lock();
/*     */     try {
/* 212 */       return (this.pending.incrementAndGet() > this.fileLimit);
/*     */     } finally {
/* 214 */       this.pendingLock.unlock();
/*     */     } 
/*     */   }
/*     */   
/*     */   public void applyBackpressure() {
/* 219 */     this.pendingLock.lock();
/*     */     try {
/* 221 */       int pendingNum = this.pending.get();
/* 222 */       if (pendingNum > this.fileLimit) {
/* 223 */         if (this.debug.DEBUG_BUNDLE_FILE) {
/* 224 */           Debug.println("MRUBundleFileList: Applying back pressure before opening: " + toString());
/*     */         }
/*     */         
/*     */         try {
/* 228 */           this.pendingCond.await(Math.min(500, pendingNum), TimeUnit.MILLISECONDS);
/* 229 */         } catch (InterruptedException interruptedException) {
/* 230 */           Thread.currentThread().interrupt();
/*     */         } 
/*     */       } 
/*     */     } finally {
/* 234 */       this.pendingLock.unlock();
/*     */     } 
/*     */   }
/*     */   
/*     */   private void closeBundleFile(BundleFile toRemove, EventManager manager) {
/* 239 */     if (toRemove == null)
/*     */       return; 
/* 241 */     if (this.debug.DEBUG_BUNDLE_FILE) {
/* 242 */       Debug.println("MRUBundleFileList: about to close bundle file: " + toRemove);
/*     */     }
/*     */     
/*     */     try {
/* 246 */       ListenerQueue<Object, Object, BundleFile> queue = new ListenerQueue(manager);
/*     */       
/* 248 */       queue.queueListeners(this.bundleFileCloser.entrySet(), this);
/*     */       
/* 250 */       queue.dispatchEventAsynchronous(0, toRemove);
/* 251 */     } catch (Throwable t) {
/*     */ 
/*     */ 
/*     */       
/* 255 */       if (this.debug.DEBUG_BUNDLE_FILE) {
/* 256 */         Debug.printStackTrace(t);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void shutdown() {
/* 265 */     synchronized (this) {
/* 266 */       if (this.bundleFileCloserManager != null)
/* 267 */         this.bundleFileCloserManager.close(); 
/* 268 */       this.bundleFileCloserManager = null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isClosing(BundleFile bundleFile) {
/* 278 */     if (this.fileLimit < 10) {
/* 279 */       return false;
/*     */     }
/* 281 */     return (closingBundleFile.get() == bundleFile);
/*     */   }
/*     */   
/*     */   public boolean isEnabled() {
/* 285 */     return (this.fileLimit >= 10);
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.osgi-3.18.400.jar!\org\eclipse\osgi\storage\bundlefile\MRUBundleFileList.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */