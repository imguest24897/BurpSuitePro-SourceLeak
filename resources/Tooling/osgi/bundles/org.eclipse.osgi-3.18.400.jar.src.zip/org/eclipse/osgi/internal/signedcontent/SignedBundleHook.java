/*     */ package org.eclipse.osgi.internal.signedcontent;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.lang.reflect.Field;
/*     */ import java.net.MalformedURLException;
/*     */ import java.net.URL;
/*     */ import java.security.AccessController;
/*     */ import java.security.InvalidKeyException;
/*     */ import java.security.NoSuchAlgorithmException;
/*     */ import java.security.NoSuchProviderException;
/*     */ import java.security.SignatureException;
/*     */ import java.security.cert.Certificate;
/*     */ import java.security.cert.CertificateException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Dictionary;
/*     */ import java.util.Hashtable;
/*     */ import java.util.List;
/*     */ import java.util.StringTokenizer;
/*     */ import org.eclipse.osgi.framework.util.SecureAction;
/*     */ import org.eclipse.osgi.internal.framework.EquinoxBundle;
/*     */ import org.eclipse.osgi.internal.framework.EquinoxContainer;
/*     */ import org.eclipse.osgi.internal.hookregistry.ActivatorHookFactory;
/*     */ import org.eclipse.osgi.internal.hookregistry.HookConfigurator;
/*     */ import org.eclipse.osgi.internal.hookregistry.HookRegistry;
/*     */ import org.eclipse.osgi.internal.service.security.KeyStoreTrustEngine;
/*     */ import org.eclipse.osgi.service.security.TrustEngine;
/*     */ import org.eclipse.osgi.signedcontent.SignedContent;
/*     */ import org.eclipse.osgi.signedcontent.SignedContentFactory;
/*     */ import org.eclipse.osgi.signedcontent.SignerInfo;
/*     */ import org.eclipse.osgi.storage.BundleInfo;
/*     */ import org.osgi.framework.Bundle;
/*     */ import org.osgi.framework.BundleActivator;
/*     */ import org.osgi.framework.BundleContext;
/*     */ import org.osgi.framework.Filter;
/*     */ import org.osgi.framework.InvalidSyntaxException;
/*     */ import org.osgi.framework.ServiceReference;
/*     */ import org.osgi.framework.ServiceRegistration;
/*     */ import org.osgi.util.tracker.ServiceTracker;
/*     */ import org.osgi.util.tracker.ServiceTrackerCustomizer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SignedBundleHook
/*     */   implements ActivatorHookFactory, HookConfigurator, SignedContentFactory
/*     */ {
/*  63 */   static final SecureAction secureAction = AccessController.<SecureAction>doPrivileged(SecureAction.createSecureAction());
/*     */ 
/*     */   
/*  66 */   private static final String CACERTS_PATH = String.valueOf(System.getProperty("java.home")) + File.separatorChar + "lib" + File.separatorChar + "security" + File.separatorChar + "cacerts";
/*     */   
/*     */   private static final String CACERTS_TYPE = "JKS";
/*     */   private static final String OSGI_KEYSTORE = "osgi.framework.keystore";
/*     */   private int supportSignedBundles;
/*     */   TrustEngineListener trustEngineListener;
/*     */   private String trustEngineNameProp;
/*     */   private ServiceRegistration<?> signedContentFactoryReg;
/*     */   private ServiceRegistration<?> systemTrustEngineReg;
/*     */   private List<ServiceRegistration<?>> osgiTrustEngineReg;
/*     */   private ServiceTracker<TrustEngine, TrustEngine> trustEngineTracker;
/*     */   private BundleContext context;
/*     */   private EquinoxContainer container;
/*     */   
/*     */   public BundleActivator createActivator() {
/*  81 */     return new BundleActivator()
/*     */       {
/*     */         public void start(BundleContext bc) throws Exception
/*     */         {
/*  85 */           SignedBundleHook.this.frameworkStart(bc);
/*     */         }
/*     */ 
/*     */         
/*     */         public void stop(BundleContext bc) throws Exception {
/*  90 */           SignedBundleHook.this.frameworkStop(bc);
/*     */         }
/*     */       };
/*     */   }
/*     */   
/*     */   BundleContext getContext() {
/*  96 */     return this.context;
/*     */   }
/*     */   
/*     */   void frameworkStart(BundleContext bc) {
/* 100 */     this.context = bc;
/* 101 */     if ((this.supportSignedBundles & 0x2) != 0)
/*     */     {
/* 103 */       this.trustEngineListener = new TrustEngineListener(this.context, this);
/*     */     }
/* 105 */     Dictionary<String, Object> trustEngineProps = new Hashtable<>(7);
/* 106 */     trustEngineProps.put("service.ranking", Integer.valueOf(-2147483648));
/* 107 */     trustEngineProps.put("osgi.signedcontent.trust.engine", SignedContentConstants.DEFAULT_TRUST_ENGINE);
/* 108 */     KeyStoreTrustEngine systemTrustEngine = new KeyStoreTrustEngine(CACERTS_PATH, "JKS", null, "System", this);
/* 109 */     this.systemTrustEngineReg = this.context.registerService(TrustEngine.class.getName(), systemTrustEngine, trustEngineProps);
/* 110 */     String osgiTrustPath = this.context.getProperty("osgi.framework.keystore");
/* 111 */     if (osgiTrustPath != null) {
/*     */       try {
/* 113 */         URL url = new URL(osgiTrustPath);
/* 114 */         if ("file".equals(url.getProtocol())) {
/* 115 */           trustEngineProps.put("osgi.signedcontent.trust.engine", "osgi.framework.keystore");
/* 116 */           String path = url.getPath();
/* 117 */           this.osgiTrustEngineReg = new ArrayList<>(1);
/* 118 */           this.osgiTrustEngineReg.add(this.context.registerService(TrustEngine.class.getName(), new KeyStoreTrustEngine(path, "JKS", null, "osgi.framework.keystore", this), trustEngineProps));
/*     */         } 
/* 120 */       } catch (MalformedURLException e) {
/* 121 */         log("Invalid setting for osgi.framework.keystore", 2, e);
/*     */       } 
/*     */     } else {
/* 124 */       String osgiTrustRepoPaths = this.context.getProperty("org.osgi.framework.trust.repositories");
/* 125 */       if (osgiTrustRepoPaths != null) {
/* 126 */         trustEngineProps.put("osgi.signedcontent.trust.engine", "org.osgi.framework.trust.repositories");
/* 127 */         StringTokenizer st = new StringTokenizer(osgiTrustRepoPaths, File.pathSeparator);
/* 128 */         this.osgiTrustEngineReg = new ArrayList<>(1);
/* 129 */         while (st.hasMoreTokens()) {
/* 130 */           String trustRepoPath = st.nextToken();
/* 131 */           this.osgiTrustEngineReg.add(this.context.registerService(TrustEngine.class.getName(), new KeyStoreTrustEngine(trustRepoPath, "JKS", null, "osgi.framework.keystore", this), trustEngineProps));
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 136 */     this.signedContentFactoryReg = this.context.registerService(SignedContentFactory.class.getName(), this, null);
/*     */   }
/*     */   
/*     */   void frameworkStop(BundleContext bc) {
/* 140 */     if (this.signedContentFactoryReg != null) {
/* 141 */       this.signedContentFactoryReg.unregister();
/* 142 */       this.signedContentFactoryReg = null;
/*     */     } 
/* 144 */     if (this.systemTrustEngineReg != null) {
/* 145 */       this.systemTrustEngineReg.unregister();
/* 146 */       this.systemTrustEngineReg = null;
/*     */     } 
/* 148 */     if (this.osgiTrustEngineReg != null) {
/* 149 */       for (ServiceRegistration<?> serviceRegistration : this.osgiTrustEngineReg)
/* 150 */         serviceRegistration.unregister(); 
/* 151 */       this.osgiTrustEngineReg = null;
/*     */     } 
/* 153 */     if (this.trustEngineTracker != null) {
/* 154 */       this.trustEngineTracker.close();
/* 155 */       this.trustEngineTracker = null;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void addHooks(HookRegistry hookRegistry) {
/* 161 */     this.container = hookRegistry.getContainer();
/* 162 */     hookRegistry.addActivatorHookFactory(this);
/* 163 */     this.supportSignedBundles = (hookRegistry.getConfiguration()).supportSignedBundles;
/* 164 */     this.trustEngineNameProp = hookRegistry.getConfiguration().getConfiguration("osgi.signedcontent.trust.engine");
/*     */   }
/*     */ 
/*     */   
/*     */   public SignedContent getSignedContent(File content) throws IOException, InvalidKeyException, SignatureException, CertificateException, NoSuchAlgorithmException, NoSuchProviderException {
/* 169 */     SignedContentFromBundleFile signedContent = new SignedContentFromBundleFile(content, 
/* 170 */         this.container.getConfiguration().getDebug());
/* 171 */     determineTrust(signedContent, 2);
/* 172 */     return signedContent;
/*     */   }
/*     */ 
/*     */   
/*     */   public SignedContent getSignedContent(Bundle bundle) throws IOException, InvalidKeyException, SignatureException, CertificateException, NoSuchAlgorithmException, NoSuchProviderException {
/* 177 */     BundleInfo.Generation generation = (BundleInfo.Generation)((EquinoxBundle)bundle).getModule().getCurrentRevision()
/* 178 */       .getRevisionInfo();
/* 179 */     SignedContentFromBundleFile signedContent = new SignedContentFromBundleFile(generation.getBundleFile());
/* 180 */     determineTrust(signedContent, 2);
/* 181 */     return signedContent;
/*     */   }
/*     */   
/*     */   public void log(String msg, int severity, Throwable t) {
/* 185 */     this.container.getLogServices().log("org.eclipse.osgi", severity, msg, t);
/*     */   }
/*     */ 
/*     */   
/*     */   private TrustEngine[] getTrustEngines() {
/* 190 */     if (this.context == null)
/* 191 */       return new TrustEngine[0]; 
/* 192 */     if (this.trustEngineTracker == null) {
/*     */       
/* 194 */       Filter filter = null;
/* 195 */       if (this.trustEngineNameProp != null)
/*     */         try {
/* 197 */           filter = this.context.createFilter("(&(objectClass=" + TrustEngine.class.getName() + ")(" + "osgi.signedcontent.trust.engine" + "=" + this.trustEngineNameProp + "))");
/* 198 */         } catch (InvalidSyntaxException e) {
/* 199 */           log("Invalid trust engine filter", 2, (Throwable)e);
/*     */         }  
/* 201 */       if (filter != null) {
/* 202 */         this.trustEngineTracker = new ServiceTracker(this.context, filter, new TrustEngineCustomizer());
/*     */       } else {
/* 204 */         this.trustEngineTracker = new ServiceTracker(this.context, TrustEngine.class.getName(), new TrustEngineCustomizer());
/* 205 */       }  this.trustEngineTracker.open();
/*     */     } 
/* 207 */     Object[] services = this.trustEngineTracker.getServices();
/* 208 */     if (services != null) {
/* 209 */       TrustEngine[] engines = new TrustEngine[services.length];
/* 210 */       System.arraycopy(services, 0, engines, 0, services.length);
/* 211 */       return engines;
/*     */     } 
/* 213 */     return new TrustEngine[0];
/*     */   }
/*     */   
/*     */   class TrustEngineCustomizer
/*     */     implements ServiceTrackerCustomizer<TrustEngine, TrustEngine>
/*     */   {
/*     */     public TrustEngine addingService(ServiceReference<TrustEngine> reference) {
/* 220 */       TrustEngine engine = (TrustEngine)SignedBundleHook.this.getContext().getService(reference);
/* 221 */       if (engine != null) {
/*     */         try {
/* 223 */           Field trustEngineListenerField = TrustEngine.class.getDeclaredField("trustEngineListener");
/* 224 */           trustEngineListenerField.setAccessible(true);
/* 225 */           trustEngineListenerField.set(engine, SignedBundleHook.this.trustEngineListener);
/* 226 */         } catch (Exception e) {
/* 227 */           SignedBundleHook.this.log("Unable to set the trust engine listener.", 4, e);
/*     */         } 
/*     */       }
/*     */       
/* 231 */       return engine;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void modifiedService(ServiceReference<TrustEngine> reference, TrustEngine service) {}
/*     */ 
/*     */ 
/*     */     
/*     */     public void removedService(ServiceReference<TrustEngine> reference, TrustEngine service) {}
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   void determineTrust(SignedContentFromBundleFile trustedContent, int supportFlags) {
/* 247 */     TrustEngine[] engines = null;
/* 248 */     SignerInfo[] signers = trustedContent.getSignerInfos(); byte b; int i; SignerInfo[] arrayOfSignerInfo1;
/* 249 */     for (i = (arrayOfSignerInfo1 = signers).length, b = 0; b < i; ) { SignerInfo signer = arrayOfSignerInfo1[b];
/*     */       
/* 251 */       if (signer.getTrustAnchor() == null) {
/*     */         
/* 253 */         if (engines == null) {
/* 254 */           engines = getTrustEngines();
/*     */         }
/* 256 */         Certificate[] signerCerts = signer.getCertificateChain();
/* 257 */         ((SignedContentFromBundleFile.BaseSignerInfo)signer).setTrustAnchor(findTrustAnchor(signerCerts, engines, supportFlags));
/*     */         
/* 259 */         SignerInfo tsaSignerInfo = trustedContent.getTSASignerInfo(signer);
/* 260 */         if (tsaSignerInfo != null) {
/* 261 */           Certificate[] tsaCerts = tsaSignerInfo.getCertificateChain();
/* 262 */           ((SignedContentFromBundleFile.BaseSignerInfo)tsaSignerInfo).setTrustAnchor(findTrustAnchor(tsaCerts, engines, supportFlags));
/*     */         } 
/*     */       } 
/*     */       b++; }
/*     */   
/*     */   }
/*     */   private Certificate findTrustAnchor(Certificate[] certs, TrustEngine[] engines, int supportFlags) {
/* 269 */     if ((supportFlags & 0x2) == 0)
/*     */     {
/* 271 */       return (certs != null && certs.length > 0) ? certs[certs.length - 1] : null; }  byte b; int i; TrustEngine[] arrayOfTrustEngine;
/* 272 */     for (i = (arrayOfTrustEngine = engines).length, b = 0; b < i; ) { TrustEngine engine = arrayOfTrustEngine[b];
/*     */       try {
/* 274 */         Certificate anchor = engine.findTrustAnchor(certs);
/* 275 */         if (anchor != null)
/*     */         {
/* 277 */           return anchor; } 
/* 278 */       } catch (IOException e) {
/*     */         
/* 280 */         log("TrustEngine failure: " + engine.getName(), 2, e);
/*     */       }  b++; }
/*     */     
/* 283 */     return null;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.osgi-3.18.400.jar!\org\eclipse\osgi\internal\signedcontent\SignedBundleHook.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */