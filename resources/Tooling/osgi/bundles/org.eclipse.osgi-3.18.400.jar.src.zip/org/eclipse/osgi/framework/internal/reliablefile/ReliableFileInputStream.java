/*     */ package org.eclipse.osgi.framework.internal.reliablefile;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.FilterInputStream;
/*     */ import java.io.IOException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ReliableFileInputStream
/*     */   extends FilterInputStream
/*     */ {
/*     */   private ReliableFile reliable;
/*     */   private int sigSize;
/*     */   private long readPos;
/*     */   private long length;
/*     */   
/*     */   public ReliableFileInputStream(String name) throws IOException {
/*  58 */     this(ReliableFile.getReliableFile(name), 0, 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ReliableFileInputStream(File file) throws IOException {
/*  69 */     this(ReliableFile.getReliableFile(file), 0, 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ReliableFileInputStream(File file, int generation, int openMask) throws IOException {
/*  83 */     this(ReliableFile.getReliableFile(file), generation, openMask);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ReliableFileInputStream(ReliableFile reliable, int generation, int openMask) throws IOException {
/*  95 */     super(reliable.getInputStream(generation, openMask));
/*     */     
/*  97 */     this.reliable = reliable;
/*  98 */     this.sigSize = reliable.getSignatureSize();
/*  99 */     this.readPos = 0L;
/* 100 */     this.length = reliable.getInputLength();
/* 101 */     if (this.sigSize > this.length) {
/* 102 */       this.length = 0L;
/*     */     } else {
/* 104 */       this.length -= this.sigSize;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized void close() throws IOException {
/* 115 */     if (this.reliable != null) {
/*     */       try {
/* 117 */         super.close();
/*     */       } finally {
/* 119 */         this.reliable.closeInputFile();
/* 120 */         this.reliable = null;
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized int read(byte[] b, int off, int len) throws IOException {
/* 131 */     if (this.readPos >= this.length) {
/* 132 */       return -1;
/*     */     }
/* 134 */     int num = super.read(b, off, len);
/*     */     
/* 136 */     if (num != -1) {
/* 137 */       if (num + this.readPos > this.length) {
/* 138 */         num = (int)(this.length - this.readPos);
/*     */       }
/* 140 */       this.readPos += num;
/*     */     } 
/* 142 */     return num;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized int read(byte[] b) throws IOException {
/* 151 */     return read(b, 0, b.length);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized int read() throws IOException {
/* 160 */     if (this.readPos >= this.length) {
/* 161 */       return -1;
/*     */     }
/* 163 */     int num = super.read();
/*     */     
/* 165 */     if (num != -1) {
/* 166 */       this.readPos++;
/*     */     }
/* 168 */     return num;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized int available() throws IOException {
/* 178 */     if (this.readPos < this.length)
/* 179 */       return (int)(this.length - this.readPos); 
/* 180 */     return 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized long skip(long n) throws IOException {
/* 189 */     long len = super.skip(n);
/* 190 */     if (this.readPos + len > this.length)
/* 191 */       len = this.length - this.readPos; 
/* 192 */     this.readPos += len;
/* 193 */     return len;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean markSupported() {
/* 202 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void mark(int readlimit) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void reset() throws IOException {
/* 220 */     throw new IOException("reset not supported.");
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.osgi-3.18.400.jar!\org\eclipse\osgi\framework\internal\reliablefile\ReliableFileInputStream.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */