/*     */ package org.eclipse.osgi.internal.permadmin;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.FilePermission;
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.security.AccessController;
/*     */ import java.security.AllPermission;
/*     */ import java.security.Permission;
/*     */ import java.security.PermissionCollection;
/*     */ import java.security.PrivilegedActionException;
/*     */ import java.util.Collections;
/*     */ import java.util.Enumeration;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import org.osgi.service.permissionadmin.PermissionInfo;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class PermissionInfoCollection
/*     */   extends PermissionCollection
/*     */ {
/*     */   private static final long serialVersionUID = 3140511562980923957L;
/*  34 */   private static final Class<?>[] twoStringClassArray = new Class[] { String.class, String.class };
/*  35 */   private static final Class<?>[] oneStringClassArray = new Class[] { String.class };
/*  36 */   private static final Class<?>[] noArgClassArray = new Class[0];
/*  37 */   private static final Class<?>[][] permClassArrayArgs = new Class[][] { noArgClassArray, oneStringClassArray, twoStringClassArray };
/*  38 */   private static final String ALL_PERMISSION_NAME = AllPermission.class.getName();
/*  39 */   static final String FILE_PERMISSION_NAME = FilePermission.class.getName();
/*     */   
/*     */   static final String ALL_FILES = "<<ALL FILES>>";
/*     */   
/*  43 */   private final Map<Class<? extends Permission>, PermissionCollection> cachedPermissionCollections = new HashMap<>();
/*     */   private final Map<BundlePermissions, PermissionCollection> cachedRelativeFilePermissionCollections;
/*     */   private final boolean hasAllPermission;
/*     */   private final PermissionInfo[] permInfos;
/*     */   
/*     */   public PermissionInfoCollection(PermissionInfo[] permInfos) {
/*  49 */     this.permInfos = permInfos;
/*  50 */     boolean tempAllPermissions = false;
/*  51 */     boolean allAbsolutePaths = true; byte b; int i; PermissionInfo[] arrayOfPermissionInfo;
/*  52 */     for (i = (arrayOfPermissionInfo = permInfos).length, b = 0; b < i; ) { PermissionInfo info = arrayOfPermissionInfo[b];
/*  53 */       if (ALL_PERMISSION_NAME.equals(info.getType())) {
/*  54 */         tempAllPermissions = true;
/*  55 */       } else if (FILE_PERMISSION_NAME.equals(info.getType()) && 
/*  56 */         !(new File(info.getActions())).isAbsolute()) {
/*  57 */         allAbsolutePaths = false;
/*     */       } 
/*     */       b++; }
/*     */     
/*  61 */     this.hasAllPermission = tempAllPermissions;
/*  62 */     this.cachedRelativeFilePermissionCollections = allAbsolutePaths ? null : new HashMap<>();
/*  63 */     setReadOnly();
/*     */   }
/*     */ 
/*     */   
/*     */   public void add(Permission arg0) {
/*  68 */     throw new SecurityException();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Enumeration<Permission> elements() {
/*  74 */     return Collections.emptyEnumeration();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean implies(Permission perm) {
/*  79 */     return implies(null, perm);
/*     */   }
/*     */   
/*     */   boolean implies(BundlePermissions bundlePermissions, Permission perm) {
/*  83 */     if (this.hasAllPermission)
/*  84 */       return true; 
/*  85 */     Class<? extends Permission> permClass = (Class)perm.getClass();
/*  86 */     PermissionCollection collection = getCachedCollection(bundlePermissions, permClass);
/*     */     
/*  88 */     if (collection == null) {
/*  89 */       collection = perm.newPermissionCollection();
/*  90 */       if (collection == null) {
/*  91 */         collection = new PermissionsHash();
/*     */       }
/*     */       try {
/*  94 */         PermissionCollection targetCollection = collection;
/*  95 */         AccessController.doPrivileged(() -> {
/*     */               addPermissions(paramBundlePermissions, paramPermissionCollection, paramClass);
/*     */               
/*     */               return null;
/*     */             });
/* 100 */       } catch (Exception e) {
/* 101 */         if (e instanceof PrivilegedActionException) {
/* 102 */           e = ((PrivilegedActionException)e).getException();
/*     */         }
/* 104 */         throw new SecurityException("Exception creating permissions: " + permClass + ": " + e.getMessage(), e);
/*     */       } 
/* 106 */       collection = cacheCollection(bundlePermissions, permClass, collection);
/*     */     } 
/* 108 */     return collection.implies(perm);
/*     */   }
/*     */   
/*     */   PermissionCollection getCachedCollection(BundlePermissions bundlePermissions, Class<? extends Permission> permClass) {
/* 112 */     synchronized (this.cachedPermissionCollections) {
/* 113 */       if (bundlePermissions != null && this.cachedRelativeFilePermissionCollections != null && FILE_PERMISSION_NAME.equals(permClass.getName())) {
/* 114 */         return this.cachedRelativeFilePermissionCollections.get(bundlePermissions);
/*     */       }
/* 116 */       return this.cachedPermissionCollections.get(permClass);
/*     */     } 
/*     */   }
/*     */   
/*     */   private PermissionCollection cacheCollection(BundlePermissions bundlePermissions, Class<? extends Permission> permClass, PermissionCollection collection) {
/* 121 */     synchronized (this.cachedPermissionCollections) {
/*     */       
/* 123 */       boolean relativeFiles = (bundlePermissions != null && this.cachedRelativeFilePermissionCollections != null && FILE_PERMISSION_NAME.equals(permClass.getName()));
/* 124 */       PermissionCollection exists = relativeFiles ? this.cachedRelativeFilePermissionCollections.get(bundlePermissions) : this.cachedPermissionCollections.get(permClass);
/* 125 */       if (exists != null) {
/* 126 */         collection = exists;
/*     */       }
/* 128 */       else if (relativeFiles) {
/* 129 */         this.cachedRelativeFilePermissionCollections.put(bundlePermissions, collection);
/*     */       } else {
/* 131 */         this.cachedPermissionCollections.put(permClass, collection);
/*     */       } 
/*     */       
/* 134 */       return collection;
/*     */     } 
/*     */   }
/*     */   
/*     */   PermissionInfo[] getPermissionInfos() {
/* 139 */     return this.permInfos;
/*     */   }
/*     */   
/*     */   void addPermissions(BundlePermissions bundlePermissions, PermissionCollection collection, Class<? extends Permission> permClass) throws Exception {
/* 143 */     String permClassName = permClass.getName();
/* 144 */     Constructor<? extends Permission> constructor = null;
/* 145 */     int numArgs = -1;
/* 146 */     for (int i = permClassArrayArgs.length - 1; i >= 0; i--) {
/*     */       try {
/* 148 */         constructor = permClass.getConstructor(permClassArrayArgs[i]);
/* 149 */         numArgs = i;
/*     */         break;
/* 151 */       } catch (NoSuchMethodException noSuchMethodException) {}
/*     */     } 
/*     */ 
/*     */     
/* 155 */     if (constructor == null) {
/* 156 */       throw new NoSuchMethodException(String.valueOf(permClass.getName()) + ".<init>()");
/*     */     }
/*     */     byte b;
/*     */     int j;
/*     */     PermissionInfo[] arrayOfPermissionInfo;
/* 161 */     for (j = (arrayOfPermissionInfo = this.permInfos).length, b = 0; b < j; ) { PermissionInfo permInfo = arrayOfPermissionInfo[b];
/* 162 */       if (permInfo.getType().equals(permClassName)) {
/* 163 */         String[] args = new String[numArgs];
/* 164 */         if (numArgs > 0) {
/* 165 */           args[0] = permInfo.getName();
/*     */         }
/* 167 */         if (numArgs > 1) {
/* 168 */           args[1] = permInfo.getActions();
/*     */         }
/* 170 */         if (permInfo.getType().equals(FILE_PERMISSION_NAME))
/*     */         {
/* 172 */           if (!args[0].equals("<<ALL FILES>>")) {
/* 173 */             File file = new File(args[0]);
/* 174 */             if (!file.isAbsolute()) {
/* 175 */               File target = (bundlePermissions == null) ? null : bundlePermissions.getBundle().getDataFile(permInfo.getName());
/* 176 */               if (target == null) {
/*     */                 continue;
/*     */               }
/*     */               
/* 180 */               args[0] = target.getPath();
/*     */             } 
/*     */           } 
/*     */         }
/* 184 */         collection.add(constructor.newInstance((Object[])args));
/*     */       } 
/*     */       continue;
/*     */       b++; }
/*     */   
/*     */   } void clearPermissionCache() {
/* 190 */     synchronized (this.cachedPermissionCollections) {
/* 191 */       this.cachedPermissionCollections.clear();
/* 192 */       if (this.cachedRelativeFilePermissionCollections != null)
/* 193 */         this.cachedRelativeFilePermissionCollections.clear(); 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.osgi-3.18.400.jar!\org\eclipse\osgi\internal\permadmin\PermissionInfoCollection.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */