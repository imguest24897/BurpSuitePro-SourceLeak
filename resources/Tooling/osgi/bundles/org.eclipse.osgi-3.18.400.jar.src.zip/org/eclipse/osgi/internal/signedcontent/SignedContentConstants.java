/*    */ package org.eclipse.osgi.internal.signedcontent;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface SignedContentConstants
/*    */ {
/*    */   public static final String SHA1_STR = "SHA1";
/*    */   public static final String SHA256_STR = "SHA256";
/*    */   public static final String SHA384_STR = "SHA384";
/*    */   public static final String SHA512_STR = "SHA512";
/*    */   public static final String SHA224_STR = "SHA224";
/*    */   public static final String SHA512_224_STR = "SHA512-224";
/*    */   public static final String SHA512_256_STR = "SHA512-256";
/*    */   public static final String MD5_STR = "MD5";
/*    */   public static final String MD2_STR = "MD2";
/*    */   public static final String DOT_DSA = ".DSA";
/*    */   public static final String DOT_RSA = ".RSA";
/*    */   public static final String DOT_SF = ".SF";
/*    */   public static final String SIG_DASH = "SIG-";
/*    */   public static final String META_INF = "META-INF/";
/*    */   public static final String META_INF_MANIFEST_MF = "META-INF/MANIFEST.MF";
/* 34 */   public static final String[] EMPTY_STRING = new String[0];
/*    */   
/*    */   public static final String MF_ENTRY_NEWLN_NAME = "\nName: ";
/*    */   
/*    */   public static final String MF_ENTRY_NAME = "Name: ";
/*    */   
/*    */   public static final String MF_DIGEST_PART = "-Digest: ";
/*    */   
/*    */   public static final String digestManifestSearch = "-Digest-Manifest: ";
/*    */   
/* 44 */   public static final int digestManifestSearchLen = "-Digest-Manifest: ".length();
/*    */   
/* 46 */   public static final int[] SIGNEDDATA_OID = new int[] { 1, 2, 840, 113549, 1, 7, 2 };
/* 47 */   public static final int[] MD5_OID = new int[] { 1, 2, 840, 113549, 2, 5 };
/* 48 */   public static final int[] MD2_OID = new int[] { 1, 2, 840, 113549, 2, 2 };
/*    */   
/* 50 */   public static final int[] SHA1_OID = new int[] { 1, 3, 14, 3, 2, 26 };
/*    */   
/* 52 */   public static final int[] SHA256_OID = new int[] { 2, 16, 840, 1, 101, 3, 4, 2, 1 };
/* 53 */   public static final int[] SHA384_OID = new int[] { 2, 16, 840, 1, 101, 3, 4, 2, 2 };
/* 54 */   public static final int[] SHA512_OID = new int[] { 2, 16, 840, 1, 101, 3, 4, 2, 3 };
/* 55 */   public static final int[] SHA224_OID = new int[] { 2, 16, 840, 1, 101, 3, 4, 2, 4 };
/* 56 */   public static final int[] SHA512_224_OID = new int[] { 2, 16, 840, 1, 101, 3, 4, 2, 5 };
/* 57 */   public static final int[] SHA512_256_OID = new int[] { 2, 16, 840, 1, 101, 3, 4, 2, 6 };
/*    */   
/* 59 */   public static final int[] DSA_OID = new int[] { 1, 2, 840, 10040, 4, 1 };
/* 60 */   public static final int[] RSA_OID = new int[] { 1, 2, 840, 113549, 1, 1, 1 };
/*    */   
/*    */   public static final String TRUST_ENGINE = "osgi.signedcontent.trust.engine";
/*    */   
/* 64 */   public static final Object DEFAULT_TRUST_ENGINE = "org.eclipse.osgi";
/*    */ 
/*    */   
/* 67 */   public static final int[] TIMESTAMP_OID = new int[] { 1, 2, 840, 113549, 1, 9, 16, 2, 14 };
/* 68 */   public static final int[] TIMESTAMP_TST_OID = new int[] { 1, 2, 840, 113549, 1, 9, 16, 1, 4 };
/* 69 */   public static final int[] SIGNING_TIME = new int[] { 1, 2, 840, 113549, 1, 9, 5 };
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.osgi-3.18.400.jar!\org\eclipse\osgi\internal\signedcontent\SignedContentConstants.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */