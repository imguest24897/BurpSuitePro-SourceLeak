package org.eclipse.osgi.framework.console;

import java.util.Dictionary;
import org.osgi.framework.Bundle;

public interface CommandInterpreter {
  String nextArgument();
  
  Object execute(String paramString);
  
  void print(Object paramObject);
  
  void println();
  
  void println(Object paramObject);
  
  void printStackTrace(Throwable paramThrowable);
  
  void printDictionary(Dictionary<?, ?> paramDictionary, String paramString);
  
  void printBundleResource(Bundle paramBundle, String paramString);
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.osgi-3.18.400.jar!\org\eclipse\osgi\framework\console\CommandInterpreter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */