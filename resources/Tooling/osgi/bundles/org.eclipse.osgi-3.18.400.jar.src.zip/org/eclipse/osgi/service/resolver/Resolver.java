package org.eclipse.osgi.service.resolver;

import java.util.Comparator;
import java.util.Dictionary;

public interface Resolver {
  void resolve(BundleDescription[] paramArrayOfBundleDescription, Dictionary<Object, Object>[] paramArrayOfDictionary);
  
  void flush();
  
  State getState();
  
  void setState(State paramState);
  
  void bundleAdded(BundleDescription paramBundleDescription);
  
  void bundleRemoved(BundleDescription paramBundleDescription, boolean paramBoolean);
  
  void bundleUpdated(BundleDescription paramBundleDescription1, BundleDescription paramBundleDescription2, boolean paramBoolean);
  
  ExportPackageDescription resolveDynamicImport(BundleDescription paramBundleDescription, String paramString);
  
  void setSelectionPolicy(Comparator<BaseDescription> paramComparator);
  
  Comparator<BaseDescription> getSelectionPolicy();
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.osgi-3.18.400.jar!\org\eclipse\osgi\service\resolver\Resolver.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */