/*     */ package org.eclipse.osgi.internal.serviceregistry;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ShrinkableCollection<E>
/*     */   implements Collection<E>
/*     */ {
/*     */   private final Collection<? extends E> collection;
/*     */   private final List<Collection<? extends E>> list;
/*     */   
/*     */   public ShrinkableCollection(Collection<? extends E> c) {
/*  44 */     if (c == null) {
/*  45 */       throw new NullPointerException();
/*     */     }
/*  47 */     List<Collection<? extends E>> empty = Collections.emptyList();
/*  48 */     this.list = empty;
/*  49 */     this.collection = c;
/*     */   }
/*     */   
/*     */   public ShrinkableCollection(Collection<? extends E> c1, Collection<? extends E> c2) {
/*  53 */     this.list = new ArrayList<>(2);
/*  54 */     this.list.add(c1);
/*  55 */     this.list.add(c2);
/*  56 */     this.collection = initComposite(this.list);
/*     */   }
/*     */   
/*     */   public ShrinkableCollection(List<Collection<? extends E>> l) {
/*  60 */     this.list = new ArrayList<>(l);
/*  61 */     this.collection = initComposite(this.list);
/*     */   }
/*     */   
/*     */   private static <E> Collection<? extends E> initComposite(List<Collection<? extends E>> collections) {
/*  65 */     int size = 0;
/*  66 */     for (Collection<? extends E> c : collections) {
/*  67 */       assert verifyNoDuplicates(c);
/*  68 */       size += c.size();
/*     */     } 
/*  70 */     Collection<E> result = new ArrayList<>(size);
/*  71 */     for (Collection<? extends E> c : collections) {
/*  72 */       for (E e : c) {
/*  73 */         if (!result.contains(e)) {
/*  74 */           result.add(e);
/*     */         }
/*     */       } 
/*     */     } 
/*  78 */     return result;
/*     */   }
/*     */   
/*     */   private static <E> boolean verifyNoDuplicates(Collection<? extends E> c) {
/*  82 */     for (E e : c) {
/*  83 */       int count = 0;
/*  84 */       for (E f : c) {
/*  85 */         if (e == null) {
/*  86 */           if (f == null)
/*  87 */             count++; 
/*     */           continue;
/*     */         } 
/*  90 */         if (e.equals(f)) {
/*  91 */           count++;
/*     */         }
/*     */       } 
/*     */       
/*  95 */       if (count != 1) {
/*  96 */         return false;
/*     */       }
/*     */     } 
/*  99 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean add(E e) {
/* 104 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean addAll(Collection<? extends E> c) {
/* 109 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   
/*     */   public void clear() {
/* 114 */     this.collection.clear();
/* 115 */     for (Collection<? extends E> c : this.list) {
/* 116 */       c.clear();
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean contains(Object o) {
/* 122 */     return this.collection.contains(o);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean containsAll(Collection<?> c) {
/* 127 */     return this.collection.containsAll(c);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isEmpty() {
/* 132 */     return this.collection.isEmpty();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Iterator<E> iterator() {
/* 138 */     final Iterator<E> iter = (Iterator)this.collection.iterator();
/* 139 */     final List<Collection<? extends E>> collections = this.list;
/* 140 */     if (collections.isEmpty()) {
/* 141 */       return iter;
/*     */     }
/* 143 */     return new Iterator<E>()
/*     */       {
/*     */         private E last;
/*     */         
/*     */         public boolean hasNext() {
/* 148 */           return iter.hasNext();
/*     */         }
/*     */ 
/*     */         
/*     */         public E next() {
/* 153 */           this.last = iter.next();
/* 154 */           return this.last;
/*     */         }
/*     */ 
/*     */         
/*     */         public void remove() {
/* 159 */           iter.remove();
/* 160 */           for (Collection<? extends E> c : (Iterable<Collection<? extends E>>)collections) {
/* 161 */             c.remove(this.last);
/*     */           }
/*     */         }
/*     */       };
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean remove(Object o) {
/* 169 */     boolean result = this.collection.remove(o);
/* 170 */     if (result) {
/* 171 */       for (Collection<? extends E> c : this.list) {
/* 172 */         c.remove(o);
/*     */       }
/*     */     }
/* 175 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean removeAll(Collection<?> c) {
/* 180 */     boolean result = this.collection.removeAll(c);
/* 181 */     if (result) {
/* 182 */       for (Collection<? extends E> cc : this.list) {
/* 183 */         cc.removeAll(c);
/*     */       }
/*     */     }
/* 186 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean retainAll(Collection<?> c) {
/* 191 */     boolean result = this.collection.retainAll(c);
/* 192 */     if (result) {
/* 193 */       for (Collection<? extends E> cc : this.list) {
/* 194 */         cc.retainAll(c);
/*     */       }
/*     */     }
/* 197 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   public int size() {
/* 202 */     return this.collection.size();
/*     */   }
/*     */ 
/*     */   
/*     */   public Object[] toArray() {
/* 207 */     return this.collection.toArray();
/*     */   }
/*     */ 
/*     */   
/*     */   public <T> T[] toArray(Object[] var0) {
/* 212 */     return this.collection.toArray((T[])var0);
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 217 */     return this.collection.toString();
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.osgi-3.18.400.jar!\org\eclipse\osgi\internal\serviceregistry\ShrinkableCollection.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */