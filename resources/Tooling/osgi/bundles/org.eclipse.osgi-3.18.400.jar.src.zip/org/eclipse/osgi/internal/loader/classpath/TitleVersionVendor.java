/*    */ package org.eclipse.osgi.internal.loader.classpath;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class TitleVersionVendor
/*    */ {
/* 24 */   static final TitleVersionVendor NONE = new TitleVersionVendor(null, null, null);
/*    */ 
/*    */   
/*    */   private final String title;
/*    */ 
/*    */   
/*    */   private final String version;
/*    */ 
/*    */   
/*    */   private final String vendor;
/*    */ 
/*    */ 
/*    */   
/*    */   static TitleVersionVendor of(String title, String version, String vendor) {
/* 38 */     if (title == null && version == null && vendor == null) {
/* 39 */       return NONE;
/*    */     }
/* 41 */     return new TitleVersionVendor(title, version, vendor);
/*    */   }
/*    */   
/*    */   private TitleVersionVendor(String title, String version, String vendor) {
/* 45 */     this.title = title;
/* 46 */     this.version = version;
/* 47 */     this.vendor = vendor;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   String getTitle() {
/* 55 */     return this.title;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   String getVersion() {
/* 63 */     return this.version;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   String getVendor() {
/* 71 */     return this.vendor;
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.osgi-3.18.400.jar!\org\eclipse\osgi\internal\loader\classpath\TitleVersionVendor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */