package org.eclipse.osgi.signedcontent;

import java.io.File;
import java.io.IOException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.NoSuchProviderException;
import java.security.SignatureException;
import java.security.cert.CertificateException;
import org.osgi.framework.Bundle;

public interface SignedContentFactory {
  SignedContent getSignedContent(File paramFile) throws IOException, InvalidKeyException, SignatureException, CertificateException, NoSuchAlgorithmException, NoSuchProviderException;
  
  SignedContent getSignedContent(Bundle paramBundle) throws IOException, InvalidKeyException, SignatureException, CertificateException, NoSuchAlgorithmException, NoSuchProviderException;
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.osgi-3.18.400.jar!\org\eclipse\osgi\signedcontent\SignedContentFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */