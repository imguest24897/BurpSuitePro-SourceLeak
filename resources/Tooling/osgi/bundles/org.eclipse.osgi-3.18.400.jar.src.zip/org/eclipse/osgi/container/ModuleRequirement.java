/*     */ package org.eclipse.osgi.container;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import org.eclipse.osgi.internal.container.Capabilities;
/*     */ import org.eclipse.osgi.internal.framework.FilterImpl;
/*     */ import org.osgi.framework.Filter;
/*     */ import org.osgi.framework.InvalidSyntaxException;
/*     */ import org.osgi.framework.wiring.BundleCapability;
/*     */ import org.osgi.framework.wiring.BundleRequirement;
/*     */ import org.osgi.framework.wiring.BundleRevision;
/*     */ import org.osgi.resource.Capability;
/*     */ import org.osgi.resource.Resource;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ModuleRequirement
/*     */   implements BundleRequirement
/*     */ {
/*     */   private final String namespace;
/*     */   private final Map<String, String> directives;
/*     */   private final Map<String, Object> attributes;
/*     */   private final ModuleRevision revision;
/*     */   private static final String PACKAGENAME_FILTER_COMPONENT = "osgi.wiring.package=";
/*     */   
/*     */   ModuleRequirement(String namespace, Map<String, String> directives, Map<String, ?> attributes, ModuleRevision revision) {
/*  40 */     this.namespace = namespace;
/*  41 */     this.directives = ModuleRevisionBuilder.unmodifiableMap(directives);
/*  42 */     this.attributes = ModuleRevisionBuilder.unmodifiableMap(attributes);
/*  43 */     this.revision = revision;
/*     */   }
/*     */ 
/*     */   
/*     */   public ModuleRevision getRevision() {
/*  48 */     return this.revision;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean matches(BundleCapability capability) {
/*  53 */     if (!this.namespace.equals(capability.getNamespace()))
/*  54 */       return false; 
/*  55 */     String filterSpec = this.directives.get("filter");
/*  56 */     FilterImpl f = null;
/*  57 */     if (filterSpec != null) {
/*     */       try {
/*  59 */         f = FilterImpl.newInstance(filterSpec);
/*  60 */       } catch (InvalidSyntaxException invalidSyntaxException) {
/*  61 */         return false;
/*     */       } 
/*     */     }
/*  64 */     boolean matchMandatory = !(!"osgi.wiring.package".equals(this.namespace) && !"osgi.wiring.bundle".equals(this.namespace) && !"osgi.wiring.host".equals(this.namespace));
/*  65 */     return Capabilities.matches((Filter)f, (Capability)capability, matchMandatory);
/*     */   }
/*     */ 
/*     */   
/*     */   public String getNamespace() {
/*  70 */     return this.namespace;
/*     */   }
/*     */ 
/*     */   
/*     */   public Map<String, String> getDirectives() {
/*  75 */     return this.directives;
/*     */   }
/*     */ 
/*     */   
/*     */   public Map<String, Object> getAttributes() {
/*  80 */     return this.attributes;
/*     */   }
/*     */ 
/*     */   
/*     */   public ModuleRevision getResource() {
/*  85 */     return this.revision;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/*  90 */     return String.valueOf(this.namespace) + ModuleRevision.<Object>toString(this.attributes, false) + ModuleRevision.<String>toString(this.directives, true);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   DynamicModuleRequirement getDynamicPackageRequirement(ModuleRevision host, String dynamicPkgName) {
/*  96 */     if (!"osgi.wiring.package".equals(this.namespace)) {
/*  97 */       return null;
/*     */     }
/*  99 */     if (!"dynamic".equals(this.directives.get("resolution")))
/*     */     {
/* 101 */       return null;
/*     */     }
/* 103 */     String dynamicFilter = this.directives.get("filter");
/*     */     
/* 105 */     int packageNameBegin = dynamicFilter.indexOf("osgi.wiring.package=");
/* 106 */     if (packageNameBegin == -1)
/*     */     {
/* 108 */       return null;
/*     */     }
/* 110 */     packageNameBegin += "osgi.wiring.package=".length();
/* 111 */     int packageNameEnd = dynamicFilter.indexOf(')', packageNameBegin);
/* 112 */     if (packageNameEnd == -1)
/*     */     {
/* 114 */       return null;
/*     */     }
/* 116 */     String filterPackageName = dynamicFilter.substring(packageNameBegin, packageNameEnd);
/* 117 */     String specificPackageFilter = null;
/* 118 */     if ("*".equals(filterPackageName)) {
/*     */       
/* 120 */       specificPackageFilter = dynamicFilter.replace("osgi.wiring.package=" + filterPackageName, "osgi.wiring.package=" + dynamicPkgName);
/* 121 */     } else if (filterPackageName.endsWith(".*")) {
/* 122 */       if (dynamicPkgName.startsWith(filterPackageName.substring(0, filterPackageName.length() - 1))) {
/* 123 */         specificPackageFilter = dynamicFilter.replace("osgi.wiring.package=" + filterPackageName, "osgi.wiring.package=" + dynamicPkgName);
/*     */       }
/* 125 */     } else if (dynamicPkgName.equals(filterPackageName)) {
/* 126 */       specificPackageFilter = dynamicFilter;
/*     */     } 
/*     */     
/* 129 */     if (specificPackageFilter != null) {
/* 130 */       Map<String, String> dynamicDirectives = new HashMap<>(this.directives);
/* 131 */       dynamicDirectives.put("filter", specificPackageFilter);
/* 132 */       return new DynamicModuleRequirement(host, dynamicDirectives);
/*     */     } 
/* 134 */     return null;
/*     */   }
/*     */   
/*     */   class DynamicModuleRequirement
/*     */     extends ModuleRequirement {
/*     */     DynamicModuleRequirement(ModuleRevision host, Map<String, String> directives) {
/* 140 */       super(ModuleRequirement.this.getNamespace(), directives, ModuleRequirement.this.getAttributes(), host);
/*     */     }
/*     */     
/*     */     ModuleRequirement getOriginal() {
/* 144 */       return ModuleRequirement.this;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.osgi-3.18.400.jar!\org\eclipse\osgi\container\ModuleRequirement.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */