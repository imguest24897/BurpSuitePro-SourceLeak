/*    */ package org.eclipse.osgi.storage.url.bundleentry;
/*    */ 
/*    */ import java.io.FileNotFoundException;
/*    */ import java.io.IOException;
/*    */ import java.net.URL;
/*    */ import org.eclipse.osgi.container.Module;
/*    */ import org.eclipse.osgi.container.ModuleContainer;
/*    */ import org.eclipse.osgi.container.ModuleRevision;
/*    */ import org.eclipse.osgi.internal.location.LocationHelper;
/*    */ import org.eclipse.osgi.storage.BundleInfo;
/*    */ import org.eclipse.osgi.storage.bundlefile.BundleEntry;
/*    */ import org.eclipse.osgi.storage.url.BundleResourceHandler;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Handler
/*    */   extends BundleResourceHandler
/*    */ {
/*    */   public Handler(ModuleContainer container, BundleEntry bundleEntry) {
/* 35 */     super(container, bundleEntry);
/*    */   }
/*    */ 
/*    */   
/*    */   protected BundleEntry findBundleEntry(URL url, Module module) throws IOException {
/* 40 */     ModuleRevision revision = module.getCurrentRevision();
/* 41 */     BundleInfo.Generation revisionInfo = (BundleInfo.Generation)revision.getRevisionInfo();
/* 42 */     BundleEntry entry = (revisionInfo == null) ? null : revisionInfo.getBundleFile().getEntry(url.getPath());
/* 43 */     if (entry == null) {
/* 44 */       String path = url.getPath();
/* 45 */       if (revisionInfo != null && (path.indexOf('%') >= 0 || path.indexOf('+') >= 0)) {
/* 46 */         entry = revisionInfo.getBundleFile().getEntry(LocationHelper.decode(path, true));
/* 47 */         if (entry != null) {
/* 48 */           return entry;
/*    */         }
/* 50 */         entry = revisionInfo.getBundleFile().getEntry(LocationHelper.decode(path, false));
/* 51 */         if (entry != null) {
/* 52 */           return entry;
/*    */         }
/*    */       } 
/* 55 */       throw new FileNotFoundException(url.getPath());
/*    */     } 
/* 57 */     return entry;
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.osgi-3.18.400.jar!\org\eclipse\osgi\storag\\url\bundleentry\Handler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */