/*     */ package org.eclipse.osgi.internal.loader.classpath;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.net.URL;
/*     */ import java.security.ProtectionDomain;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.jar.Attributes;
/*     */ import java.util.jar.Manifest;
/*     */ import org.eclipse.osgi.container.Module;
/*     */ import org.eclipse.osgi.framework.util.KeyedElement;
/*     */ import org.eclipse.osgi.storage.BundleInfo;
/*     */ import org.eclipse.osgi.storage.Storage;
/*     */ import org.eclipse.osgi.storage.bundlefile.BundleEntry;
/*     */ import org.eclipse.osgi.storage.bundlefile.BundleFile;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ClasspathEntry
/*     */ {
/*     */   private final BundleFile bundlefile;
/*     */   private final ProtectionDomain domain;
/*     */   private final ManifestPackageAttributes mainManifestPackageAttributes;
/*     */   private final Map<String, ManifestPackageAttributes> perPackageManifestAttributes;
/*     */   private final List<BundleFile> mrBundleFiles;
/*     */   private HashMap<Object, KeyedElement> userObjects;
/*     */   private final PDEData data;
/*     */   
/*     */   static final class PDEData
/*     */   {
/*     */     final String fileName;
/*     */     final String symbolicName;
/*     */     
/*     */     PDEData(File baseFile, String symbolicName) {
/*  52 */       this.fileName = (baseFile == null) ? null : baseFile.getAbsolutePath();
/*  53 */       this.symbolicName = symbolicName;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ClasspathEntry(BundleFile bundlefile, ProtectionDomain domain, BundleInfo.Generation generation) {
/*     */     boolean isMRJar;
/*  62 */     this.userObjects = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  74 */     this.bundlefile = bundlefile;
/*  75 */     this.domain = domain;
/*  76 */     this.data = new PDEData(generation.getBundleFile().getBaseFile(), generation.getRevision().getSymbolicName());
/*  77 */     Manifest manifest = loadManifest(bundlefile, generation);
/*  78 */     if (manifest != null && (generation.getBundleInfo().getStorage().getConfiguration()).DEFINE_PACKAGE_ATTRIBUTES) {
/*  79 */       this.mainManifestPackageAttributes = manifestPackageAttributesFor(manifest.getMainAttributes(), null);
/*  80 */       this.perPackageManifestAttributes = manifestPackageAttributesMapFor(manifest.getEntries().entrySet(), this.mainManifestPackageAttributes);
/*     */     } else {
/*  82 */       this.mainManifestPackageAttributes = ManifestPackageAttributes.NONE;
/*  83 */       this.perPackageManifestAttributes = null;
/*     */     } 
/*     */ 
/*     */     
/*  87 */     if (bundlefile == generation.getBundleFile()) {
/*     */       
/*  89 */       isMRJar = generation.isMRJar();
/*     */     } else {
/*  91 */       isMRJar = (manifest != null) ? Boolean.parseBoolean(manifest.getMainAttributes().getValue("Multi-Release")) : false;
/*     */     } 
/*  93 */     if (isMRJar) {
/*  94 */       this.mrBundleFiles = getMRBundleFiles(bundlefile, generation);
/*     */     } else {
/*  96 */       this.mrBundleFiles = Collections.emptyList();
/*     */     } 
/*     */   }
/*     */   
/*     */   private static List<BundleFile> getMRBundleFiles(BundleFile bundlefile, BundleInfo.Generation generation) {
/* 101 */     Storage storage = generation.getBundleInfo().getStorage();
/* 102 */     if (storage.getRuntimeVersion().getMajor() < 9) {
/* 103 */       return Collections.emptyList();
/*     */     }
/* 105 */     List<BundleFile> mrBundleFiles = new ArrayList<>();
/* 106 */     for (int i = storage.getRuntimeVersion().getMajor(); i > 8; i--) {
/* 107 */       String versionPath = "META-INF/versions/" + i + '/';
/* 108 */       BundleEntry versionEntry = bundlefile.getEntry(versionPath);
/* 109 */       if (versionEntry != null) {
/* 110 */         mrBundleFiles.add(storage.createNestedBundleFile(versionPath, bundlefile, generation, BundleInfo.MULTI_RELEASE_FILTER_PREFIXES));
/*     */       }
/*     */     } 
/* 113 */     return Collections.unmodifiableList(mrBundleFiles);
/*     */   }
/*     */   
/*     */   private static ManifestPackageAttributes manifestPackageAttributesFor(Attributes attributes, ManifestPackageAttributes defaultAttributes) {
/* 117 */     return ManifestPackageAttributes.of(attributes.getValue(Attributes.Name.SPECIFICATION_TITLE), 
/* 118 */         attributes.getValue(Attributes.Name.SPECIFICATION_VERSION), 
/* 119 */         attributes.getValue(Attributes.Name.SPECIFICATION_VENDOR), 
/* 120 */         attributes.getValue(Attributes.Name.IMPLEMENTATION_TITLE), 
/* 121 */         attributes.getValue(Attributes.Name.IMPLEMENTATION_VERSION), 
/* 122 */         attributes.getValue(Attributes.Name.IMPLEMENTATION_VENDOR), 
/* 123 */         defaultAttributes);
/*     */   }
/*     */   
/*     */   private static Map<String, ManifestPackageAttributes> manifestPackageAttributesMapFor(Set<Map.Entry<String, Attributes>> entries, ManifestPackageAttributes defaultAttributes) {
/* 127 */     Map<String, ManifestPackageAttributes> result = null;
/* 128 */     for (Map.Entry<String, Attributes> entry : entries) {
/* 129 */       String name = entry.getKey();
/* 130 */       Attributes attributes = entry.getValue();
/* 131 */       if (name != null && name.endsWith("/")) {
/* 132 */         String packageName = name.substring(0, name.length() - 1).replace('/', '.');
/* 133 */         if (result == null) {
/* 134 */           result = new HashMap<>(4);
/*     */         }
/* 136 */         result.put(packageName, manifestPackageAttributesFor(attributes, defaultAttributes));
/*     */       } 
/*     */     } 
/* 139 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BundleFile getBundleFile() {
/* 147 */     return this.bundlefile;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ProtectionDomain getDomain() {
/* 155 */     return this.domain;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized Object getUserObject(Object key) {
/* 164 */     if (this.userObjects == null)
/* 165 */       return null; 
/* 166 */     return this.userObjects.get(key);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized void addUserObject(KeyedElement userObject) {
/* 175 */     if (this.userObjects == null)
/* 176 */       this.userObjects = new HashMap<>(5); 
/* 177 */     if (!this.userObjects.containsKey(userObject.getKey())) {
/* 178 */       this.userObjects.put(userObject.getKey(), userObject);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BundleEntry findEntry(String path) {
/* 189 */     for (BundleFile mrFile : this.mrBundleFiles) {
/* 190 */       BundleEntry mrEntry = mrFile.getEntry(path);
/* 191 */       if (mrEntry != null) {
/* 192 */         return mrEntry;
/*     */       }
/*     */     } 
/* 195 */     return this.bundlefile.getEntry(path);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public URL findResource(String name, Module m, int index) {
/* 207 */     for (BundleFile mrFile : this.mrBundleFiles) {
/* 208 */       URL mrURL = mrFile.getResourceURL(name, m, index);
/* 209 */       if (mrURL != null) {
/* 210 */         return mrURL;
/*     */       }
/*     */     } 
/* 213 */     return this.bundlefile.getResourceURL(name, m, index);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addBundleFiles(List<BundleFile> bundlefiles) {
/* 222 */     bundlefiles.addAll(this.mrBundleFiles);
/* 223 */     bundlefiles.add(this.bundlefile);
/*     */   }
/*     */   
/*     */   private static Manifest loadManifest(BundleFile cpBundleFile, BundleInfo.Generation generation) {
/* 227 */     if (!generation.hasPackageInfo() && generation.getBundleFile() == cpBundleFile) {
/* 228 */       return null;
/*     */     }
/* 230 */     BundleEntry mfEntry = cpBundleFile.getEntry("META-INF/MANIFEST.MF");
/* 231 */     if (mfEntry != null) {
/* 232 */       InputStream manIn = null;
/*     */       try {
/*     */         try {
/* 235 */           manIn = mfEntry.getInputStream();
/* 236 */           return new Manifest(manIn);
/*     */         } finally {
/* 238 */           if (manIn != null)
/* 239 */             manIn.close(); 
/*     */         } 
/* 241 */       } catch (IOException iOException) {}
/*     */     } 
/*     */ 
/*     */     
/* 245 */     return null;
/*     */   }
/*     */   
/*     */   ManifestPackageAttributes manifestPackageAttributesFor(String packageName) {
/* 249 */     ManifestPackageAttributes perPackage = (this.perPackageManifestAttributes == null) ? null : this.perPackageManifestAttributes.get(packageName);
/* 250 */     if (perPackage != null) {
/* 251 */       return perPackage;
/*     */     }
/* 253 */     return this.mainManifestPackageAttributes;
/*     */   }
/*     */   
/*     */   public void close() throws IOException {
/* 257 */     this.bundlefile.close();
/* 258 */     for (BundleFile bf : this.mrBundleFiles)
/* 259 */       bf.close(); 
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.osgi-3.18.400.jar!\org\eclipse\osgi\internal\loader\classpath\ClasspathEntry.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */