/*     */ package org.eclipse.osgi.internal.weaving;
/*     */ 
/*     */ import java.security.AccessController;
/*     */ import java.security.Permission;
/*     */ import java.security.PrivilegedActionException;
/*     */ import java.security.ProtectionDomain;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.eclipse.osgi.container.ModuleRevision;
/*     */ import org.eclipse.osgi.internal.framework.EquinoxContainer;
/*     */ import org.eclipse.osgi.internal.hookregistry.ClassLoaderHook;
/*     */ import org.eclipse.osgi.internal.loader.BundleLoader;
/*     */ import org.eclipse.osgi.internal.loader.classpath.ClasspathEntry;
/*     */ import org.eclipse.osgi.internal.permadmin.BundlePermissions;
/*     */ import org.eclipse.osgi.internal.serviceregistry.HookContext;
/*     */ import org.eclipse.osgi.internal.serviceregistry.ServiceRegistry;
/*     */ import org.eclipse.osgi.storage.BundleInfo;
/*     */ import org.eclipse.osgi.storage.StorageUtil;
/*     */ import org.eclipse.osgi.storage.bundlefile.BundleEntry;
/*     */ import org.eclipse.osgi.util.ManifestElement;
/*     */ import org.osgi.framework.AdminPermission;
/*     */ import org.osgi.framework.BundleException;
/*     */ import org.osgi.framework.PackagePermission;
/*     */ import org.osgi.framework.ServiceRegistration;
/*     */ import org.osgi.framework.hooks.weaving.WeavingException;
/*     */ import org.osgi.framework.hooks.weaving.WeavingHook;
/*     */ import org.osgi.framework.hooks.weaving.WovenClass;
/*     */ import org.osgi.framework.hooks.weaving.WovenClassListener;
/*     */ import org.osgi.framework.wiring.BundleWiring;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class WovenClassImpl
/*     */   implements WovenClass, HookContext<WeavingHook>
/*     */ {
/*     */   private static final byte FLAG_HOOKCALLED = 1;
/*     */   private static final byte FLAG_HOOKSCOMPLETE = 2;
/*     */   private static final byte FLAG_WEAVINGCOMPLETE = 4;
/*     */   private final String className;
/*     */   private final BundleEntry entry;
/*     */   private final List<String> dynamicImports;
/*     */   private final ClasspathEntry classpathEntry;
/*     */   private final BundleLoader loader;
/*     */   final ServiceRegistry registry;
/*     */   private final Map<ServiceRegistration<?>, Boolean> deniedHooks;
/*     */   private byte[] validBytes;
/*     */   private byte[] resultBytes;
/*  60 */   private byte hookFlags = 0;
/*     */   
/*     */   private Throwable error;
/*     */   private ServiceRegistration<?> errorHook;
/*     */   private Class<?> clazz;
/*     */   private int state;
/*     */   final EquinoxContainer container;
/*     */   
/*     */   public WovenClassImpl(String className, byte[] bytes, BundleEntry entry, ClasspathEntry classpathEntry, BundleLoader loader, EquinoxContainer container, Map<ServiceRegistration<?>, Boolean> deniedHooks) {
/*  69 */     this.className = className;
/*  70 */     this.validBytes = this.resultBytes = bytes;
/*  71 */     this.entry = entry;
/*  72 */     this.dynamicImports = new DynamicImportList(this);
/*  73 */     this.classpathEntry = classpathEntry;
/*  74 */     this.loader = loader;
/*  75 */     this.registry = container.getServiceRegistry();
/*  76 */     this.container = container;
/*  77 */     this.deniedHooks = deniedHooks;
/*  78 */     setState(1);
/*     */   }
/*     */ 
/*     */   
/*     */   public byte[] getBytes() {
/*  83 */     if ((this.hookFlags & 0x2) == 0) {
/*  84 */       checkPermission();
/*  85 */       return this.validBytes;
/*     */     } 
/*     */ 
/*     */     
/*  89 */     byte[] current = this.validBytes;
/*  90 */     byte[] results = new byte[current.length];
/*  91 */     System.arraycopy(current, 0, results, 0, current.length);
/*  92 */     return results;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setBytes(byte[] newBytes) {
/*  97 */     checkPermission();
/*  98 */     if (newBytes == null)
/*  99 */       throw new NullPointerException("newBytes cannot be null."); 
/* 100 */     if ((this.hookFlags & 0x2) != 0)
/*     */     {
/* 102 */       throw new IllegalStateException("Weaving has completed already."); } 
/* 103 */     this.resultBytes = this.validBytes = newBytes;
/*     */   }
/*     */   
/*     */   void checkPermission() {
/* 107 */     SecurityManager sm = System.getSecurityManager();
/* 108 */     if (sm != null) {
/* 109 */       sm.checkPermission((Permission)new AdminPermission(this.loader.getWiring().getBundle(), "weave"));
/*     */     }
/*     */   }
/*     */   
/*     */   public List<String> getDynamicImports() {
/* 114 */     if ((this.hookFlags & 0x2) == 0) {
/* 115 */       return this.dynamicImports;
/*     */     }
/* 117 */     return Collections.unmodifiableList(this.dynamicImports);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isWeavingComplete() {
/* 122 */     return ((this.hookFlags & 0x4) != 0);
/*     */   }
/*     */ 
/*     */   
/*     */   private void setHooksComplete() {
/* 127 */     byte[] original = this.validBytes;
/* 128 */     this.validBytes = new byte[original.length];
/* 129 */     System.arraycopy(original, 0, this.validBytes, 0, original.length);
/* 130 */     this.hookFlags = (byte)(this.hookFlags | 0x2);
/*     */   }
/*     */ 
/*     */   
/*     */   void setWeavingCompleted(Class<?> clazz) {
/* 135 */     this.clazz = clazz;
/* 136 */     this.hookFlags = (byte)(this.hookFlags | 0x4);
/*     */     
/* 138 */     if ((this.hookFlags & 0x1) == 0) {
/*     */       return;
/*     */     }
/*     */     
/* 142 */     if (this.error != null) {
/*     */       return;
/*     */     }
/* 145 */     setState((clazz == null) ? 16 : 4);
/* 146 */     notifyWovenClassListeners();
/*     */   }
/*     */ 
/*     */   
/*     */   public String getClassName() {
/* 151 */     return this.className;
/*     */   }
/*     */ 
/*     */   
/*     */   public ProtectionDomain getProtectionDomain() {
/* 156 */     return this.classpathEntry.getDomain();
/*     */   }
/*     */ 
/*     */   
/*     */   public Class<?> getDefinedClass() {
/* 161 */     return this.clazz;
/*     */   }
/*     */ 
/*     */   
/*     */   public BundleWiring getBundleWiring() {
/* 166 */     return (BundleWiring)this.loader.getWiring();
/*     */   }
/*     */ 
/*     */   
/*     */   public void call(WeavingHook hook, ServiceRegistration<WeavingHook> hookRegistration) throws Exception {
/* 171 */     if (this.error != null) {
/*     */       return;
/*     */     }
/* 174 */     if (skipRegistration(hookRegistration)) {
/*     */       return;
/*     */     }
/*     */ 
/*     */     
/* 179 */     if ((this.hookFlags & 0x1) == 0) {
/* 180 */       this.hookFlags = (byte)(this.hookFlags | 0x1);
/*     */       
/* 182 */       if (!validBytes(this.validBytes)) {
/* 183 */         this.validBytes = StorageUtil.getBytes(this.entry.getInputStream(), (int)this.entry.getSize(), 8192);
/*     */       }
/*     */     } 
/*     */     try {
/* 187 */       hook.weave(this);
/* 188 */     } catch (WeavingException e) {
/* 189 */       this.error = (Throwable)e;
/* 190 */       this.errorHook = hookRegistration;
/*     */     }
/* 192 */     catch (Throwable t) {
/* 193 */       this.error = t;
/* 194 */       this.errorHook = hookRegistration;
/*     */       
/* 196 */       this.deniedHooks.put(hookRegistration, Boolean.TRUE);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean skipRegistration(ServiceRegistration<?> hookRegistration) {
/* 202 */     return this.deniedHooks.containsKey(hookRegistration);
/*     */   }
/*     */   
/*     */   private boolean validBytes(byte[] checkBytes) {
/* 206 */     if (checkBytes == null || checkBytes.length < 4)
/* 207 */       return false; 
/* 208 */     if ((checkBytes[0] & 0xCA) != 202)
/* 209 */       return false; 
/* 210 */     if ((checkBytes[1] & 0xFE) != 254)
/* 211 */       return false; 
/* 212 */     if ((checkBytes[2] & 0xBA) != 186)
/* 213 */       return false; 
/* 214 */     if ((checkBytes[3] & 0xBE) != 190)
/* 215 */       return false; 
/* 216 */     return true;
/*     */   }
/*     */   
/*     */   private void notifyWovenClassListeners() {
/* 220 */     HookContext<WovenClassListener> context = (hook, hookRegistration) -> {
/*     */         try {
/*     */           hook.modified(this);
/* 223 */         } catch (Exception e) {
/*     */           this.container.getEventPublisher().publishFrameworkEvent(2, hookRegistration.getReference().getBundle(), e);
/*     */         } 
/*     */       };
/*     */     
/* 228 */     if (System.getSecurityManager() == null) {
/* 229 */       this.registry.notifyHooksPrivileged(WovenClassListener.class, "modified", context);
/*     */     } else {
/*     */       try {
/* 232 */         AccessController.doPrivileged(() -> {
/*     */               this.registry.notifyHooksPrivileged(WovenClassListener.class, "modified", paramHookContext);
/*     */               return null;
/*     */             });
/* 236 */       } catch (PrivilegedActionException e) {
/* 237 */         throw (RuntimeException)e.getException();
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   byte[] callHooks() throws Throwable {
/* 243 */     SecurityManager sm = System.getSecurityManager();
/* 244 */     byte[] wovenBytes = null;
/* 245 */     List<String> newImports = null;
/* 246 */     boolean rejected = false;
/*     */     try {
/* 248 */       if (sm == null) {
/* 249 */         this.registry.notifyHooksPrivileged(WeavingHook.class, "weave", this);
/*     */       } else {
/*     */         try {
/* 252 */           AccessController.doPrivileged(() -> {
/*     */                 this.registry.notifyHooksPrivileged(WeavingHook.class, "weave", this);
/*     */                 return null;
/*     */               });
/* 256 */         } catch (PrivilegedActionException e) {
/* 257 */           throw (RuntimeException)e.getException();
/*     */         } 
/*     */       } 
/*     */     } finally {
/* 261 */       if ((this.hookFlags & 0x1) != 0) {
/* 262 */         for (ClassLoaderHook classLoaderHook : this.container.getConfiguration().getHookRegistry().getClassLoaderHooks()) {
/* 263 */           rejected |= classLoaderHook.rejectTransformation(this.className, this.resultBytes, this.classpathEntry, this.entry, this.loader.getModuleClassLoader().getClasspathManager());
/*     */         }
/* 265 */         if (!rejected) {
/* 266 */           wovenBytes = this.resultBytes;
/* 267 */           newImports = this.dynamicImports;
/*     */         } 
/* 269 */         setHooksComplete();
/*     */ 
/*     */ 
/*     */         
/* 273 */         setState((this.error == null) ? 2 : 8);
/*     */         
/* 275 */         if (!rejected) {
/* 276 */           notifyWovenClassListeners();
/*     */         }
/*     */       } 
/*     */     } 
/*     */     
/* 281 */     if (this.error != null) {
/* 282 */       throw this.error;
/*     */     }
/* 284 */     if (newImports != null)
/*     */     {
/* 286 */       for (String newImport : newImports) {
/*     */         try {
/* 288 */           ManifestElement[] importElements = ManifestElement.parseHeader("Import-Package", newImport);
/*     */ 
/*     */           
/* 291 */           addImpliedImportPackagePermissions(importElements);
/* 292 */           this.loader.addDynamicImportPackage(importElements);
/* 293 */         } catch (BundleException bundleException) {}
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 299 */     return wovenBytes;
/*     */   }
/*     */   
/*     */   private void addImpliedImportPackagePermissions(ManifestElement[] importElements) {
/* 303 */     ProtectionDomain wovenDomain = ((BundleInfo.Generation)((ModuleRevision)getBundleWiring().getRevision()).getRevisionInfo()).getDomain();
/* 304 */     if (wovenDomain != null) {
/*     */       byte b; int i; ManifestElement[] arrayOfManifestElement;
/* 306 */       for (i = (arrayOfManifestElement = importElements).length, b = 0; b < i; ) { ManifestElement clause = arrayOfManifestElement[b]; byte b1; int j; String[] arrayOfString;
/* 307 */         for (j = (arrayOfString = clause.getValueComponents()).length, b1 = 0; b1 < j; ) { String pkg = arrayOfString[b1];
/* 308 */           ((BundlePermissions)wovenDomain.getPermissions()).addWovenPermission(new PackagePermission(pkg, "import"));
/*     */           b1++; }
/*     */         
/*     */         b++; }
/*     */     
/*     */     }  } public String toString() {
/* 314 */     return this.className;
/*     */   }
/*     */   
/*     */   public ServiceRegistration<?> getErrorHook() {
/* 318 */     return this.errorHook;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getState() {
/* 323 */     return this.state;
/*     */   }
/*     */   
/*     */   private void setState(int value) {
/* 327 */     this.state = value;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.osgi-3.18.400.jar!\org\eclipse\osgi\internal\weaving\WovenClassImpl.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */