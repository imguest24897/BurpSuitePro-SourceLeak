package org.eclipse.osgi.service.resolver;

import java.util.Map;
import org.osgi.framework.Version;
import org.osgi.framework.wiring.BundleCapability;

public interface BaseDescription {
  String getName();
  
  Version getVersion();
  
  BundleDescription getSupplier();
  
  Map<String, String> getDeclaredDirectives();
  
  Map<String, Object> getDeclaredAttributes();
  
  BundleCapability getCapability();
  
  Object getUserObject();
  
  void setUserObject(Object paramObject);
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.osgi-3.18.400.jar!\org\eclipse\osgi\service\resolver\BaseDescription.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */