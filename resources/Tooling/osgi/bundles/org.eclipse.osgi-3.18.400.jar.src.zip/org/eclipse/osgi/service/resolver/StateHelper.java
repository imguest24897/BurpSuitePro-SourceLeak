package org.eclipse.osgi.service.resolver;

public interface StateHelper {
  public static final int ACCESS_ENCOURAGED = 1;
  
  public static final int ACCESS_DISCOURAGED = 2;
  
  public static final int VISIBLE_INCLUDE_EE_PACKAGES = 1;
  
  public static final int VISIBLE_INCLUDE_ALL_HOST_WIRES = 2;
  
  BundleDescription[] getDependentBundles(BundleDescription[] paramArrayOfBundleDescription);
  
  BundleDescription[] getPrerequisites(BundleDescription[] paramArrayOfBundleDescription);
  
  VersionConstraint[] getUnsatisfiedConstraints(BundleDescription paramBundleDescription);
  
  VersionConstraint[] getUnsatisfiedLeaves(BundleDescription[] paramArrayOfBundleDescription);
  
  boolean isResolvable(ImportPackageSpecification paramImportPackageSpecification);
  
  boolean isResolvable(BundleSpecification paramBundleSpecification);
  
  boolean isResolvable(HostSpecification paramHostSpecification);
  
  Object[][] sortBundles(BundleDescription[] paramArrayOfBundleDescription);
  
  ExportPackageDescription[] getVisiblePackages(BundleDescription paramBundleDescription);
  
  ExportPackageDescription[] getVisiblePackages(BundleDescription paramBundleDescription, int paramInt);
  
  int getAccessCode(BundleDescription paramBundleDescription, ExportPackageDescription paramExportPackageDescription);
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.osgi-3.18.400.jar!\org\eclipse\osgi\service\resolver\StateHelper.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */