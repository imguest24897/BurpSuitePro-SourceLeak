/*     */ package org.eclipse.osgi.internal.framework;
/*     */ 
/*     */ import java.io.BufferedReader;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.InputStreamReader;
/*     */ import java.nio.charset.StandardCharsets;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import org.eclipse.osgi.internal.debug.Debug;
/*     */ import org.eclipse.osgi.internal.util.Tokenizer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AliasMapper
/*     */ {
/*  27 */   private static final Map<String, Collection<String>> processorAliasTable = new HashMap<>();
/*  28 */   private static final Map<String, String> processorCanonicalTable = new HashMap<>();
/*  29 */   private static final Map<String, Collection<String>> osnameAliasTable = new HashMap<>();
/*  30 */   private static final Map<String, String> osnameCanonicalTable = new HashMap<>();
/*     */   static {
/*  32 */     getTables("osname.aliases", osnameAliasTable, osnameCanonicalTable);
/*  33 */     getTables("processor.aliases", processorAliasTable, processorCanonicalTable);
/*     */   }
/*     */   
/*     */   private static void getTables(String resourceName, Map<String, Collection<String>> aliasTable, Map<String, String> canonicalTable) {
/*  37 */     InputStream in = AliasMapper.class.getResourceAsStream(resourceName);
/*  38 */     if (in != null) {
/*     */       try {
/*  40 */         initAliases(in, aliasTable, canonicalTable);
/*     */       } finally {
/*     */         try {
/*  43 */           in.close();
/*  44 */         } catch (IOException iOException) {}
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Collection<String> getProcessorAliases(String processor) {
/*  58 */     return getAlias(processor.toLowerCase(), processorAliasTable);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Collection<String> getOSNameAliases(String osname) {
/*  68 */     return getAlias(osname.toLowerCase(), osnameAliasTable);
/*     */   }
/*     */   
/*     */   public String getCanonicalOSName(String osname) {
/*  72 */     String lowerName = osname.toLowerCase();
/*  73 */     String result = osnameCanonicalTable.get(lowerName);
/*  74 */     if (result == null && 
/*  75 */       lowerName.startsWith("windows")) {
/*  76 */       return "win32";
/*     */     }
/*     */     
/*  79 */     return (result == null) ? osname : result;
/*     */   }
/*     */   
/*     */   public String getCanonicalProcessor(String processor) {
/*  83 */     String result = processorCanonicalTable.get(processor.toLowerCase());
/*  84 */     return (result == null) ? processor : result;
/*     */   }
/*     */   
/*     */   private Collection<String> getAlias(String name, Map<String, Collection<String>> aliasMap) {
/*  88 */     if (name == null) {
/*  89 */       return Collections.emptyList();
/*     */     }
/*  91 */     Collection<String> aliases = (aliasMap == null) ? null : aliasMap.get(name);
/*  92 */     if (aliases != null) {
/*  93 */       return Collections.unmodifiableCollection(aliases);
/*     */     }
/*  95 */     return Collections.singletonList(name.toLowerCase());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static Map<String, Collection<String>> initAliases(InputStream in, Map<String, Collection<String>> aliasTable, Map<String, String> canonicalTable) {
/*     */     try {
/* 106 */       BufferedReader br = new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8));
/* 107 */       Map<String, Set<String>> multiMaster = new HashMap<>();
/*     */       while (true) {
/* 109 */         String line = br.readLine();
/* 110 */         if (line == null) {
/*     */           break;
/*     */         }
/* 113 */         Tokenizer tokenizer = new Tokenizer(line);
/* 114 */         String master = tokenizer.getString("# \t");
/* 115 */         if (master != null) {
/* 116 */           String masterLower = master.toLowerCase();
/* 117 */           canonicalTable.put(masterLower, master);
/* 118 */           Collection<String> aliasLine = new ArrayList<>(1);
/* 119 */           aliasLine.add(master);
/*     */           while (true) {
/* 121 */             String alias = tokenizer.getString("# \t");
/* 122 */             if (alias == null) {
/*     */               break;
/*     */             }
/* 125 */             aliasLine.add(alias);
/* 126 */             String aliasLower = alias.toLowerCase();
/* 127 */             if (!canonicalTable.containsKey(aliasLower)) {
/* 128 */               canonicalTable.put(aliasLower, master);
/*     */               continue;
/*     */             } 
/* 131 */             String existingMaster = canonicalTable.put(aliasLower, alias);
/* 132 */             Set<String> masters = multiMaster.get(aliasLower);
/* 133 */             if (masters == null) {
/* 134 */               masters = new HashSet<>();
/* 135 */               multiMaster.put(aliasLower, masters);
/* 136 */               masters.add(existingMaster.toLowerCase());
/*     */             } 
/* 138 */             masters.add(masterLower);
/*     */           } 
/*     */           
/* 141 */           aliasTable.put(masterLower, aliasLine);
/*     */         } 
/*     */       } 
/* 144 */       Map<String, Set<String>> multiMasterAliases = new HashMap<>(multiMaster.size());
/* 145 */       for (Map.Entry<String, Set<String>> entry : multiMaster.entrySet()) {
/* 146 */         Set<String> aliases = new HashSet<>();
/* 147 */         for (String master : entry.getValue()) {
/* 148 */           aliases.addAll(aliasTable.get(master));
/*     */         }
/* 150 */         multiMasterAliases.put(entry.getKey(), aliases);
/*     */       } 
/* 152 */       aliasTable.putAll((Map)multiMasterAliases);
/* 153 */     } catch (IOException e) {
/* 154 */       Debug.printStackTrace(e);
/*     */     } 
/* 156 */     return aliasTable;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.osgi-3.18.400.jar!\org\eclipse\osgi\internal\framework\AliasMapper.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */