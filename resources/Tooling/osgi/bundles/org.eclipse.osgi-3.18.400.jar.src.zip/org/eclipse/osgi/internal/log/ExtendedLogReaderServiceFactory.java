/*     */ package org.eclipse.osgi.internal.log;
/*     */ 
/*     */ import java.io.PrintStream;
/*     */ import java.security.AccessController;
/*     */ import java.security.PrivilegedAction;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.Enumeration;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import java.util.concurrent.locks.ReentrantReadWriteLock;
/*     */ import org.eclipse.equinox.log.LogFilter;
/*     */ import org.eclipse.osgi.framework.util.ArrayMap;
/*     */ import org.eclipse.osgi.internal.framework.EquinoxContainer;
/*     */ import org.osgi.framework.Bundle;
/*     */ import org.osgi.framework.ServiceFactory;
/*     */ import org.osgi.framework.ServiceReference;
/*     */ import org.osgi.framework.ServiceRegistration;
/*     */ import org.osgi.service.log.LogEntry;
/*     */ import org.osgi.service.log.LogLevel;
/*     */ import org.osgi.service.log.LogListener;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ExtendedLogReaderServiceFactory
/*     */   implements ServiceFactory<ExtendedLogReaderServiceImpl>
/*     */ {
/*     */   static final int MAX_RECURSIONS = 50;
/*     */   
/*     */   static final class LogTask
/*     */     implements Runnable
/*     */   {
/*     */     private final LogEntry logEntry;
/*     */     private final LogListener listener;
/*     */     
/*     */     LogTask(LogEntry logEntry, LogListener listener) {
/*  50 */       this.logEntry = logEntry;
/*  51 */       this.listener = listener;
/*     */     }
/*     */ 
/*     */     
/*     */     public void run() {
/*  56 */       ExtendedLogReaderServiceFactory.safeLogged(this.listener, this.logEntry);
/*     */     }
/*     */   }
/*     */   
/*  60 */   static final LogFilter NULL_LOGGER_FILTER = new LogFilter()
/*     */     {
/*     */       public boolean isLoggable(Bundle b, String loggerName, int logLevel) {
/*  63 */         return true;
/*     */       }
/*     */     };
/*     */   
/*  67 */   private static final LogFilter[] ALWAYS_LOG = new LogFilter[0];
/*     */   
/*     */   private static PrintStream errorStream;
/*     */   
/*  71 */   private final ReentrantReadWriteLock listenersLock = new ReentrantReadWriteLock();
/*  72 */   private ArrayMap<LogListener, Object[]> listeners = new ArrayMap(5);
/*  73 */   private LogFilter[] filters = null;
/*  74 */   private final ThreadLocal<int[]> nestedCallCount = (ThreadLocal)new ThreadLocal<>();
/*     */   
/*     */   private final LinkedList<LogEntry> history;
/*     */   private final int maxHistory;
/*     */   private final LogLevel defaultLevel;
/*     */   private OrderedExecutor executor;
/*     */   
/*     */   static boolean safeIsLoggable(LogFilter filter, Bundle bundle, String name, int level) {
/*     */     try {
/*  83 */       return filter.isLoggable(bundle, name, level);
/*  84 */     } catch (RuntimeException|LinkageError e) {
/*     */ 
/*     */ 
/*     */       
/*  88 */       getErrorStream().println("LogFilter.isLoggable threw a non-fatal unchecked exception as follows:");
/*  89 */       e.printStackTrace(getErrorStream());
/*     */       
/*  91 */       return false;
/*     */     } 
/*     */   }
/*     */   private static synchronized PrintStream getErrorStream() {
/*  95 */     if (errorStream == null) {
/*  96 */       return System.err;
/*     */     }
/*  98 */     return errorStream;
/*     */   }
/*     */   
/*     */   public static synchronized void setErrorStream(PrintStream ps) {
/* 102 */     errorStream = ps;
/*     */   }
/*     */   
/*     */   static void safeLogged(LogListener listener, LogEntry logEntry) {
/*     */     try {
/* 107 */       listener.logged(logEntry);
/* 108 */     } catch (RuntimeException|LinkageError e) {
/*     */ 
/*     */ 
/*     */       
/* 112 */       getErrorStream().println("LogListener.logged threw a non-fatal unchecked exception as follows:");
/* 113 */       e.printStackTrace(getErrorStream());
/*     */     } 
/*     */   }
/*     */   
/*     */   public ExtendedLogReaderServiceFactory(int maxHistory, LogLevel defaultLevel) {
/* 118 */     this.defaultLevel = defaultLevel;
/* 119 */     this.maxHistory = maxHistory;
/* 120 */     if (maxHistory > 0) {
/* 121 */       this.history = new LinkedList<>();
/*     */     } else {
/* 123 */       this.history = null;
/*     */     } 
/*     */   }
/*     */   
/*     */   public void start(EquinoxContainer equinoxContainer) {
/* 128 */     this.executor = new OrderedExecutor(equinoxContainer);
/*     */   }
/*     */   
/*     */   public void stop() {
/* 132 */     this.executor.shutdown();
/*     */   }
/*     */   
/*     */   public LogLevel getDefaultLogLevel() {
/* 136 */     return this.defaultLevel;
/*     */   }
/*     */ 
/*     */   
/*     */   public ExtendedLogReaderServiceImpl getService(Bundle bundle, ServiceRegistration<ExtendedLogReaderServiceImpl> registration) {
/* 141 */     return new ExtendedLogReaderServiceImpl(this);
/*     */   }
/*     */ 
/*     */   
/*     */   public void ungetService(Bundle bundle, ServiceRegistration<ExtendedLogReaderServiceImpl> registration, ExtendedLogReaderServiceImpl service) {
/* 146 */     service.shutdown();
/*     */   }
/*     */   
/*     */   boolean isLoggable(final Bundle bundle, final String name, final int level) {
/* 150 */     if (System.getSecurityManager() != null) {
/* 151 */       return ((Boolean)AccessController.<Boolean>doPrivileged(new PrivilegedAction<Boolean>()
/*     */           {
/*     */             public Boolean run() {
/* 154 */               return Boolean.valueOf(ExtendedLogReaderServiceFactory.this.isLoggablePrivileged(bundle, name, level));
/*     */             }
/*     */           })).booleanValue();
/*     */     }
/* 158 */     return isLoggablePrivileged(bundle, name, level);
/*     */   }
/*     */   
/*     */   boolean isLoggablePrivileged(Bundle bundle, String name, int level) {
/*     */     LogFilter[] filtersCopy;
/* 163 */     this.listenersLock.readLock().lock();
/*     */     try {
/* 165 */       filtersCopy = this.filters;
/*     */     } finally {
/* 167 */       this.listenersLock.readLock().unlock();
/*     */     } 
/*     */     
/* 170 */     try { if (incrementNestedCount() == 50)
/* 171 */         return false; 
/* 172 */       if (filtersCopy == null) {
/* 173 */         return false;
/*     */       }
/* 175 */       if (filtersCopy == ALWAYS_LOG) {
/* 176 */         return true;
/*     */       }
/* 178 */       int filtersLength = filtersCopy.length;
/*     */       
/*     */        }
/*     */     
/*     */     finally
/*     */     
/*     */     { 
/* 185 */       decrementNestedCount(); }  decrementNestedCount();
/*     */     
/* 187 */     return false;
/*     */   }
/*     */   
/*     */   private int incrementNestedCount() {
/* 191 */     int[] count = getCount();
/* 192 */     count[0] = count[0] + 1;
/* 193 */     return count[0];
/*     */   }
/*     */   
/*     */   private void decrementNestedCount() {
/* 197 */     int[] count = getCount();
/* 198 */     if (count[0] == 0)
/*     */       return; 
/* 200 */     count[0] = count[0] - 1;
/*     */   }
/*     */   
/*     */   private int[] getCount() {
/* 204 */     int[] count = this.nestedCallCount.get();
/* 205 */     if (count == null) {
/* 206 */       count = new int[1];
/* 207 */       this.nestedCallCount.set(count);
/*     */     } 
/* 209 */     return count;
/*     */   }
/*     */   
/*     */   void log(final Bundle bundle, final String name, final StackTraceElement stackTraceElement, final Object context, final LogLevel logLevelEnum, final int level, final String message, final ServiceReference<?> ref, final Throwable exception) {
/* 213 */     if (System.getSecurityManager() != null) {
/* 214 */       AccessController.doPrivileged(new PrivilegedAction<Void>()
/*     */           {
/*     */             public Void run() {
/* 217 */               ExtendedLogReaderServiceFactory.this.logPrivileged(bundle, name, stackTraceElement, context, logLevelEnum, level, message, ref, exception);
/* 218 */               return null;
/*     */             }
/*     */           });
/*     */     } else {
/* 222 */       logPrivileged(bundle, name, stackTraceElement, context, logLevelEnum, level, message, ref, exception);
/*     */     } 
/*     */   }
/*     */   void logPrivileged(Bundle bundle, String name, StackTraceElement stackTraceElement, Object context, LogLevel logLevelEnum, int level, String message, ServiceReference<?> ref, Throwable exception) {
/*     */     ArrayMap<LogListener, Object[]> listenersCopy;
/* 227 */     LogEntry logEntry = new ExtendedLogEntryImpl(bundle, name, stackTraceElement, context, logLevelEnum, level, message, ref, exception);
/* 228 */     storeEntry(logEntry);
/*     */     
/* 230 */     this.listenersLock.readLock().lock();
/*     */     try {
/* 232 */       listenersCopy = this.listeners;
/*     */     } finally {
/* 234 */       this.listenersLock.readLock().unlock();
/*     */     } 
/*     */     try {
/* 237 */       if (incrementNestedCount() >= 50)
/*     */         return; 
/* 239 */       int size = listenersCopy.size();
/* 240 */       for (int i = 0; i < size; i++) {
/* 241 */         Object[] listenerObjects = (Object[])listenersCopy.getValue(i);
/* 242 */         LogFilter filter = (LogFilter)listenerObjects[0];
/* 243 */         if (safeIsLoggable(filter, bundle, name, level)) {
/* 244 */           LogListener listener = (LogListener)listenersCopy.getKey(i);
/* 245 */           OrderedExecutor.OrderedTaskQueue orderedTaskQueue = (OrderedExecutor.OrderedTaskQueue)listenerObjects[1];
/* 246 */           if (orderedTaskQueue != null) {
/* 247 */             orderedTaskQueue.execute(new LogTask(logEntry, listener), size);
/*     */           } else {
/*     */             
/* 250 */             safeLogged(listener, logEntry);
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } finally {
/* 255 */       decrementNestedCount();
/*     */     } 
/*     */   }
/*     */   
/*     */   private void storeEntry(LogEntry logEntry) {
/* 260 */     if (this.history != null) {
/* 261 */       synchronized (this.history) {
/* 262 */         if (this.history.size() == this.maxHistory) {
/* 263 */           this.history.removeLast();
/*     */         }
/* 265 */         this.history.addFirst(logEntry);
/*     */       } 
/*     */     }
/*     */   }
/*     */   
/*     */   void addLogListener(LogListener listener, LogFilter filter) {
/* 271 */     this.listenersLock.writeLock().lock();
/*     */     try {
/* 273 */       ArrayMap<LogListener, Object[]> listenersCopy = new ArrayMap(this.listeners.getKeys(), this.listeners.getValues());
/* 274 */       Object[] listenerObjects = (Object[])listenersCopy.get(listener);
/* 275 */       if (listenerObjects == null) {
/*     */         
/* 277 */         OrderedExecutor.OrderedTaskQueue taskQueue = (listener instanceof org.eclipse.equinox.log.SynchronousLogListener) ? null : this.executor.createQueue();
/* 278 */         listenerObjects = new Object[] { filter, taskQueue };
/* 279 */       } else if (filter != listenerObjects[0]) {
/*     */         
/* 281 */         listenerObjects[0] = filter;
/*     */       } 
/* 283 */       listenersCopy.put(listener, listenerObjects);
/* 284 */       recalculateFilters(listenersCopy);
/* 285 */       this.listeners = listenersCopy;
/*     */     } finally {
/* 287 */       this.listenersLock.writeLock().unlock();
/*     */     } 
/*     */   }
/*     */   
/*     */   private void recalculateFilters(ArrayMap<LogListener, Object[]> listenersCopy) {
/* 292 */     List<LogFilter> filtersList = new ArrayList<>();
/* 293 */     int size = listenersCopy.size();
/* 294 */     for (int i = 0; i < size; i++) {
/* 295 */       Object[] listenerObjects = (Object[])listenersCopy.getValue(i);
/* 296 */       LogFilter filter = (LogFilter)listenerObjects[0];
/* 297 */       if (filter == NULL_LOGGER_FILTER) {
/* 298 */         this.filters = ALWAYS_LOG;
/*     */         return;
/*     */       } 
/* 301 */       filtersList.add(filter);
/*     */     } 
/*     */     
/* 304 */     if (filtersList.isEmpty()) {
/* 305 */       this.filters = null;
/*     */     }
/* 307 */     this.filters = filtersList.<LogFilter>toArray(new LogFilter[filtersList.size()]);
/*     */   }
/*     */   
/*     */   void removeLogListener(LogListener listener) {
/* 311 */     this.listenersLock.writeLock().lock();
/*     */     try {
/* 313 */       ArrayMap<LogListener, Object[]> listenersCopy = new ArrayMap(this.listeners.getKeys(), this.listeners.getValues());
/* 314 */       listenersCopy.remove(listener);
/* 315 */       recalculateFilters(listenersCopy);
/* 316 */       this.listeners = listenersCopy;
/*     */     } finally {
/* 318 */       this.listenersLock.writeLock().unlock();
/*     */     } 
/*     */   }
/*     */   
/*     */   Enumeration<LogEntry> getLog() {
/* 323 */     if (this.history == null) {
/* 324 */       return Collections.emptyEnumeration();
/*     */     }
/* 326 */     synchronized (this.history) {
/* 327 */       return Collections.enumeration(new ArrayList<>(this.history));
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.osgi-3.18.400.jar!\org\eclipse\osgi\internal\log\ExtendedLogReaderServiceFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */