/*     */ package org.eclipse.osgi.internal.log;
/*     */ 
/*     */ import java.io.BufferedWriter;
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStreamReader;
/*     */ import java.io.OutputStream;
/*     */ import java.io.OutputStreamWriter;
/*     */ import java.io.PrintWriter;
/*     */ import java.io.Reader;
/*     */ import java.io.StringWriter;
/*     */ import java.io.Writer;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.nio.charset.StandardCharsets;
/*     */ import java.util.Calendar;
/*     */ import java.util.Date;
/*     */ import java.util.Map;
/*     */ import org.eclipse.equinox.log.ExtendedLogEntry;
/*     */ import org.eclipse.equinox.log.LogFilter;
/*     */ import org.eclipse.equinox.log.SynchronousLogListener;
/*     */ import org.eclipse.osgi.framework.log.FrameworkLogEntry;
/*     */ import org.eclipse.osgi.internal.framework.EquinoxConfiguration;
/*     */ import org.osgi.framework.Bundle;
/*     */ import org.osgi.framework.BundleException;
/*     */ import org.osgi.service.log.LogEntry;
/*     */ import org.osgi.service.log.LogLevel;
/*     */ import org.osgi.service.log.admin.LoggerAdmin;
/*     */ import org.osgi.service.log.admin.LoggerContext;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class EquinoxLogWriter
/*     */   implements SynchronousLogListener, LogFilter
/*     */ {
/*     */   private static final String PASSWORD = "-password";
/*     */   private static final String SESSION = "!SESSION";
/*     */   private static final String ENTRY = "!ENTRY";
/*     */   private static final String SUBENTRY = "!SUBENTRY";
/*     */   private static final String MESSAGE = "!MESSAGE";
/*     */   private static final String STACK = "!STACK";
/*     */   private static final String LINE_SEPARATOR;
/*     */   private static final int DEFAULT_LOG_SIZE = 1000;
/*     */   private static final int DEFAULT_LOG_FILES = 10;
/*     */   private static final int LOG_SIZE_MIN = 10;
/*     */   private static final String PROP_LOG_LEVEL = "eclipse.log.level";
/*     */   private static final String PROP_LOG_SIZE_MAX = "eclipse.log.size.max";
/*     */   private static final String PROP_LOG_FILE_MAX = "eclipse.log.backup.max";
/*     */   private static final String LOG_EXT = ".log";
/*     */   private static final String BACKUP_MARK = ".bak_";
/*     */   private static final String PROP_LOG_INCLUDE_COMMAND_LINE = "eclipse.log.include.commandline";
/*     */   
/*     */   static {
/*  62 */     String s = System.lineSeparator();
/*  63 */     LINE_SEPARATOR = (s == null) ? "\n" : s;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean consoleLog = false;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean newSession = true;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private File outFile;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Writer writer;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final String loggerName;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final boolean enabled;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final EquinoxConfiguration environmentInfo;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 105 */   int maxLogSize = 1000;
/* 106 */   int maxLogFiles = 10;
/* 107 */   int backupIdx = 0;
/*     */   
/* 109 */   private int logLevel = 0;
/*     */   
/*     */   private boolean includeCommandLine = true;
/* 112 */   private LoggerAdmin loggerAdmin = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public EquinoxLogWriter(File outFile, String loggerName, boolean enabled, EquinoxConfiguration environmentInfo) {
/* 119 */     this.outFile = outFile;
/* 120 */     this.writer = null;
/* 121 */     this.loggerName = loggerName;
/* 122 */     this.enabled = enabled;
/* 123 */     this.environmentInfo = environmentInfo;
/* 124 */     readLogProperties();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public EquinoxLogWriter(Writer writer, String loggerName, boolean enabled, EquinoxConfiguration environmentInfo) {
/* 132 */     if (writer == null) {
/*     */       
/* 134 */       this.writer = logForErrorStream();
/*     */     } else {
/* 136 */       this.writer = writer;
/* 137 */     }  this.loggerName = loggerName;
/* 138 */     this.enabled = enabled;
/* 139 */     this.environmentInfo = environmentInfo;
/*     */   }
/*     */   
/*     */   private Throwable getRoot(Throwable t) {
/* 143 */     Throwable root = null;
/* 144 */     if (t instanceof BundleException)
/* 145 */       root = ((BundleException)t).getNestedException(); 
/* 146 */     if (t instanceof InvocationTargetException) {
/* 147 */       root = ((InvocationTargetException)t).getTargetException();
/*     */     }
/* 149 */     if (root instanceof InvocationTargetException || root instanceof BundleException) {
/* 150 */       Throwable deeplyNested = getRoot(root);
/* 151 */       if (deeplyNested != null)
/*     */       {
/* 153 */         root = deeplyNested; } 
/*     */     } 
/* 155 */     return root;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void writeArgs(String header, String[] args) throws IOException {
/* 164 */     if (args == null || args.length == 0)
/*     */       return; 
/* 166 */     write(header);
/* 167 */     for (int i = 0; i < args.length; i++) {
/*     */       
/* 169 */       if (i > 0 && "-password".equals(args[i - 1])) {
/* 170 */         write(" (omitted)");
/*     */       } else {
/* 172 */         write(" " + args[i]);
/*     */       } 
/* 174 */     }  writeln();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String getSessionTimestamp() {
/* 184 */     String ts = this.environmentInfo.getConfiguration("eclipse.startTime");
/* 185 */     if (ts != null) {
/*     */       try {
/* 187 */         return getDate(new Date(Long.parseLong(ts)));
/* 188 */       } catch (NumberFormatException numberFormatException) {}
/*     */     }
/*     */ 
/*     */     
/* 192 */     return getDate(new Date());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void writeSession() throws IOException {
/* 200 */     write("!SESSION");
/* 201 */     writeSpace();
/* 202 */     String date = getSessionTimestamp();
/* 203 */     write(date);
/* 204 */     writeSpace();
/* 205 */     for (int i = "!SESSION".length() + date.length(); i < 78; i++) {
/* 206 */       write("-");
/*     */     }
/* 208 */     writeln();
/*     */     
/*     */     try {
/* 211 */       String key = "eclipse.buildId";
/* 212 */       String value = this.environmentInfo.getConfiguration(key, "unknown");
/* 213 */       writeln(String.valueOf(key) + "=" + value);
/*     */       
/* 215 */       key = "java.fullversion";
/* 216 */       value = System.getProperty(key);
/* 217 */       if (value == null) {
/* 218 */         key = "java.version";
/* 219 */         value = System.getProperty(key);
/* 220 */         writeln(String.valueOf(key) + "=" + value);
/* 221 */         key = "java.vendor";
/* 222 */         value = System.getProperty(key);
/* 223 */         writeln(String.valueOf(key) + "=" + value);
/*     */       } else {
/* 225 */         writeln(String.valueOf(key) + "=" + value);
/*     */       } 
/* 227 */     } catch (Exception exception) {}
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 232 */     write("BootLoader constants: OS=" + this.environmentInfo.getOS());
/* 233 */     write(", ARCH=" + this.environmentInfo.getOSArch());
/* 234 */     write(", WS=" + this.environmentInfo.getWS());
/* 235 */     writeln(", NL=" + this.environmentInfo.getNL());
/*     */ 
/*     */     
/* 238 */     if (this.includeCommandLine) {
/* 239 */       writeArgs("Framework arguments: ", this.environmentInfo.getNonFrameworkArgs());
/* 240 */       writeArgs("Command-line arguments: ", this.environmentInfo.getCommandLineArgs());
/*     */     } 
/*     */   }
/*     */   
/*     */   public void close() {
/*     */     try {
/* 246 */       if (this.writer != null) {
/* 247 */         Writer tmpWriter = this.writer;
/* 248 */         this.writer = null;
/* 249 */         tmpWriter.close();
/*     */       } 
/* 251 */     } catch (IOException e) {
/* 252 */       e.printStackTrace();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void openFile() {
/* 261 */     if (this.writer == null) {
/* 262 */       if (this.outFile != null) {
/*     */         try {
/* 264 */           this.writer = logForStream(ExtendedLogServiceFactory.secureAction.getFileOutputStream(this.outFile, true));
/* 265 */         } catch (IOException iOException) {
/* 266 */           this.writer = logForErrorStream();
/*     */         } 
/*     */       } else {
/* 269 */         this.writer = logForErrorStream();
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void closeFile() {
/* 278 */     if (this.outFile != null && 
/* 279 */       this.writer != null) {
/*     */       try {
/* 281 */         this.writer.close();
/* 282 */       } catch (IOException e) {
/*     */         
/* 284 */         e.printStackTrace();
/*     */       } 
/* 286 */       this.writer = null;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private synchronized void log(FrameworkLogEntry logEntry) {
/* 292 */     if (logEntry == null)
/*     */       return; 
/* 294 */     if (!isLoggable(logEntry.getSeverity()))
/*     */       return; 
/*     */     try {
/* 297 */       checkLogFileSize();
/* 298 */       openFile();
/* 299 */       if (this.newSession) {
/* 300 */         writeSession();
/* 301 */         this.newSession = false;
/*     */       } 
/* 303 */       writeLog(0, logEntry);
/* 304 */       this.writer.flush();
/* 305 */     } catch (Exception e) {
/*     */       
/* 307 */       System.err.println("An exception occurred while writing to the platform log:");
/* 308 */       e.printStackTrace(System.err);
/* 309 */       System.err.println("Logging to the console instead.");
/*     */       
/*     */       try {
/* 312 */         this.writer = logForErrorStream();
/* 313 */         writeLog(0, logEntry);
/* 314 */         this.writer.flush();
/* 315 */       } catch (Exception e2) {
/* 316 */         System.err.println("An exception occurred while logging to the console:");
/* 317 */         e2.printStackTrace(System.err);
/*     */       } 
/*     */     } finally {
/* 320 */       closeFile();
/*     */     } 
/*     */   }
/*     */   
/*     */   public synchronized void setWriter(Writer newWriter, boolean append) {
/* 325 */     setOutput(null, newWriter, append);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized void setFile(File newFile, boolean append) throws IOException {
/* 332 */     if (newFile != null && !newFile.equals(this.outFile)) {
/*     */       
/* 334 */       readLogProperties();
/* 335 */       this.backupIdx = 0;
/*     */     } 
/* 337 */     setOutput(newFile, null, append);
/* 338 */     this.environmentInfo.setConfiguration("osgi.logfile", (newFile == null) ? "" : newFile.getAbsolutePath());
/*     */   }
/*     */   
/*     */   synchronized void setLoggerAdmin(LoggerAdmin loggerAdmin) {
/* 342 */     this.loggerAdmin = loggerAdmin;
/* 343 */     applyLogLevel();
/*     */   }
/*     */   
/*     */   public synchronized File getFile() {
/* 347 */     return this.outFile;
/*     */   }
/*     */   
/*     */   public void setConsoleLog(boolean consoleLog) {
/* 351 */     this.consoleLog = consoleLog;
/*     */   }
/*     */   
/*     */   private void setOutput(File newOutFile, Writer newWriter, boolean append) {
/* 355 */     if (newOutFile == null || !newOutFile.equals(this.outFile)) {
/* 356 */       if (this.writer != null) {
/*     */         try {
/* 358 */           this.writer.close();
/* 359 */         } catch (IOException e) {
/* 360 */           e.printStackTrace();
/*     */         } 
/* 362 */         this.writer = null;
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 367 */       File oldOutFile = this.outFile;
/* 368 */       this.outFile = newOutFile;
/* 369 */       this.writer = newWriter;
/* 370 */       boolean copyFailed = false;
/* 371 */       if (append && oldOutFile != null && oldOutFile.isFile()) {
/* 372 */         Reader fileIn = null;
/*     */         try {
/* 374 */           openFile();
/* 375 */           fileIn = new InputStreamReader(ExtendedLogServiceFactory.secureAction.getFileInputStream(oldOutFile), StandardCharsets.UTF_8);
/* 376 */           copyReader(fileIn, this.writer);
/* 377 */         } catch (IOException e) {
/* 378 */           copyFailed = true;
/* 379 */           e.printStackTrace();
/*     */         } finally {
/* 381 */           if (fileIn != null) {
/*     */             try {
/* 383 */               fileIn.close();
/* 384 */             } catch (IOException e) {
/* 385 */               e.printStackTrace();
/*     */             } 
/*     */             
/* 388 */             if (!copyFailed)
/* 389 */               oldOutFile.delete(); 
/*     */           } 
/* 391 */           closeFile();
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private void copyReader(Reader reader, Writer aWriter) throws IOException {
/* 398 */     char[] buffer = new char[1024];
/*     */     int count;
/* 400 */     while ((count = reader.read(buffer, 0, buffer.length)) > 0) {
/* 401 */       aWriter.write(buffer, 0, count);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String getDate(Date date) {
/* 411 */     Calendar c = Calendar.getInstance();
/* 412 */     c.setTime(date);
/* 413 */     StringBuilder sb = new StringBuilder();
/* 414 */     appendPaddedInt(c.get(1), 4, sb).append('-');
/* 415 */     appendPaddedInt(c.get(2) + 1, 2, sb).append('-');
/* 416 */     appendPaddedInt(c.get(5), 2, sb).append(' ');
/* 417 */     appendPaddedInt(c.get(11), 2, sb).append(':');
/* 418 */     appendPaddedInt(c.get(12), 2, sb).append(':');
/* 419 */     appendPaddedInt(c.get(13), 2, sb).append('.');
/* 420 */     appendPaddedInt(c.get(14), 3, sb);
/* 421 */     return sb.toString();
/*     */   }
/*     */   
/*     */   private StringBuilder appendPaddedInt(int value, int pad, StringBuilder buffer) {
/* 425 */     pad--;
/* 426 */     if (pad == 0)
/* 427 */       return buffer.append(Integer.toString(value)); 
/* 428 */     int padding = (int)Math.pow(10.0D, pad);
/* 429 */     if (value >= padding)
/* 430 */       return buffer.append(Integer.toString(value)); 
/* 431 */     while (padding > value && padding > 1) {
/* 432 */       buffer.append('0');
/* 433 */       padding /= 10;
/*     */     } 
/* 435 */     buffer.append(value);
/* 436 */     return buffer;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String getStackTrace(Throwable t) {
/* 445 */     if (t == null) {
/* 446 */       return null;
/*     */     }
/* 448 */     StringWriter sw = new StringWriter();
/* 449 */     PrintWriter pw = new PrintWriter(sw);
/*     */     
/* 451 */     t.printStackTrace(pw);
/*     */     
/* 453 */     Throwable root = getRoot(t);
/* 454 */     if (root != null) {
/* 455 */       pw.println("Root exception:");
/* 456 */       root.printStackTrace(pw);
/*     */     } 
/* 458 */     return sw.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Writer logForStream(OutputStream output) {
/* 467 */     return new BufferedWriter(new OutputStreamWriter(output, StandardCharsets.UTF_8));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Writer logForErrorStream() {
/* 474 */     return new BufferedWriter(new OutputStreamWriter(System.err));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void writeLog(int depth, FrameworkLogEntry entry) throws IOException {
/* 486 */     writeEntry(depth, entry);
/* 487 */     writeMessage(entry);
/* 488 */     writeStack(entry);
/*     */     
/* 490 */     FrameworkLogEntry[] children = entry.getChildren();
/* 491 */     if (children != null) {
/* 492 */       byte b; int i; FrameworkLogEntry[] arrayOfFrameworkLogEntry; for (i = (arrayOfFrameworkLogEntry = children).length, b = 0; b < i; ) { FrameworkLogEntry child = arrayOfFrameworkLogEntry[b];
/* 493 */         writeLog(depth + 1, child);
/*     */         b++; }
/*     */     
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void writeEntry(int depth, FrameworkLogEntry entry) throws IOException {
/* 507 */     if (depth == 0) {
/* 508 */       writeln();
/* 509 */       write("!ENTRY");
/*     */     } else {
/* 511 */       write("!SUBENTRY");
/* 512 */       writeSpace();
/* 513 */       write(Integer.toString(depth));
/*     */     } 
/* 515 */     writeSpace();
/* 516 */     write(entry.getEntry());
/* 517 */     writeSpace();
/* 518 */     write(Integer.toString(entry.getSeverity()));
/* 519 */     writeSpace();
/* 520 */     write(Integer.toString(entry.getBundleCode()));
/* 521 */     writeSpace();
/* 522 */     write(getDate(new Date()));
/* 523 */     writeln();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void writeMessage(FrameworkLogEntry entry) throws IOException {
/* 532 */     write("!MESSAGE");
/* 533 */     writeSpace();
/* 534 */     writeln(entry.getMessage());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void writeStack(FrameworkLogEntry entry) throws IOException {
/* 543 */     Throwable t = entry.getThrowable();
/* 544 */     if (t != null) {
/* 545 */       String stack = getStackTrace(t);
/* 546 */       write("!STACK");
/* 547 */       writeSpace();
/* 548 */       write(Integer.toString(entry.getStackCode()));
/* 549 */       writeln();
/* 550 */       write(stack);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void write(String message) throws IOException {
/* 560 */     if (message != null) {
/* 561 */       this.writer.write(message);
/* 562 */       if (this.consoleLog) {
/* 563 */         System.out.print(message);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void writeln(String s) throws IOException {
/* 573 */     write(s);
/* 574 */     writeln();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void writeln() throws IOException {
/* 582 */     write(LINE_SEPARATOR);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void writeSpace() throws IOException {
/* 590 */     write(" ");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean checkLogFileSize() {
/* 599 */     if (this.maxLogSize == 0) {
/* 600 */       return true;
/*     */     }
/* 602 */     boolean isBackupOK = true;
/* 603 */     if (this.outFile != null && 
/* 604 */       ExtendedLogServiceFactory.secureAction.length(this.outFile) >> 10L > this.maxLogSize) {
/* 605 */       String logFilename = this.outFile.getAbsolutePath();
/*     */ 
/*     */       
/* 608 */       String backupFilename = "";
/* 609 */       if (logFilename.toLowerCase().endsWith(".log")) {
/* 610 */         backupFilename = String.valueOf(logFilename.substring(0, logFilename.length() - ".log".length())) + ".bak_" + this.backupIdx + ".log";
/*     */       } else {
/* 612 */         backupFilename = String.valueOf(logFilename) + ".bak_" + this.backupIdx;
/*     */       } 
/* 614 */       File backupFile = new File(backupFilename);
/* 615 */       if (backupFile.exists() && 
/* 616 */         !backupFile.delete()) {
/* 617 */         System.err.println("Error when trying to delete old log file: " + backupFile.getName());
/* 618 */         if (backupFile.renameTo(new File(String.valueOf(backupFile.getAbsolutePath()) + System.currentTimeMillis()))) {
/* 619 */           System.err.println("So we rename it to filename: " + backupFile.getName());
/*     */         } else {
/* 621 */           System.err.println("And we also cannot rename it!");
/* 622 */           isBackupOK = false;
/*     */         } 
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 628 */       boolean isRenameOK = this.outFile.renameTo(backupFile);
/* 629 */       if (!isRenameOK) {
/* 630 */         System.err.println("Error when trying to rename log file to backup one.");
/* 631 */         isBackupOK = false;
/*     */       } 
/* 633 */       File newFile = new File(logFilename);
/* 634 */       setOutput(newFile, null, false);
/*     */ 
/*     */       
/* 637 */       openFile();
/*     */       try {
/* 639 */         writeSession();
/* 640 */         writeln();
/* 641 */         writeln("This is a continuation of log file " + backupFile.getAbsolutePath());
/* 642 */         writeln("Created Time: " + getDate(new Date(System.currentTimeMillis())));
/* 643 */         this.writer.flush();
/* 644 */       } catch (IOException ioe) {
/* 645 */         ioe.printStackTrace(System.err);
/*     */       } 
/* 647 */       closeFile();
/* 648 */       this.backupIdx = ++this.backupIdx % this.maxLogFiles;
/*     */     } 
/*     */     
/* 651 */     return isBackupOK;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void readLogProperties() {
/* 658 */     String newMaxLogSize = this.environmentInfo.getConfiguration("eclipse.log.size.max");
/* 659 */     if (newMaxLogSize != null) {
/* 660 */       this.maxLogSize = Integer.parseInt(newMaxLogSize);
/* 661 */       if (this.maxLogSize != 0 && this.maxLogSize < 10)
/*     */       {
/*     */         
/* 664 */         this.maxLogSize = 10;
/*     */       }
/*     */     } 
/*     */     
/* 668 */     String newMaxLogFiles = this.environmentInfo.getConfiguration("eclipse.log.backup.max");
/* 669 */     if (newMaxLogFiles != null) {
/* 670 */       this.maxLogFiles = Integer.parseInt(newMaxLogFiles);
/* 671 */       if (this.maxLogFiles < 1)
/*     */       {
/* 673 */         this.maxLogFiles = 10;
/*     */       }
/*     */     } 
/*     */     
/* 677 */     String newLogLevel = this.environmentInfo.getConfiguration("eclipse.log.level");
/* 678 */     if (newLogLevel != null) {
/* 679 */       if (newLogLevel.equals("ERROR")) {
/* 680 */         this.logLevel = 4;
/* 681 */       } else if (newLogLevel.equals("WARNING")) {
/* 682 */         this.logLevel = 6;
/* 683 */       } else if (newLogLevel.equals("INFO")) {
/* 684 */         this.logLevel = 15;
/*     */       } else {
/* 686 */         this.logLevel = 0;
/*     */       } 
/*     */     }
/* 689 */     this.includeCommandLine = "true".equals(this.environmentInfo.getConfiguration("eclipse.log.include.commandline", "true"));
/* 690 */     applyLogLevel();
/*     */   }
/*     */   
/*     */   void applyLogLevel() {
/* 694 */     if (this.loggerAdmin == null) {
/*     */       return;
/*     */     }
/* 697 */     LoggerContext rootContext = this.loggerAdmin.getLoggerContext(null);
/* 698 */     Map<String, LogLevel> rootLevels = rootContext.getLogLevels();
/* 699 */     rootLevels.put(this.loggerName, getLogLevel());
/* 700 */     rootContext.setLogLevels(rootLevels);
/*     */   }
/*     */   
/*     */   private LogLevel getLogLevel() {
/* 704 */     if (this.logLevel == 0) {
/* 705 */       return LogLevel.TRACE;
/*     */     }
/* 707 */     if ((this.logLevel & 0x1) != 0) {
/* 708 */       return LogLevel.INFO;
/*     */     }
/* 710 */     if ((this.logLevel & 0x2) != 0) {
/* 711 */       return LogLevel.WARN;
/*     */     }
/* 713 */     if ((this.logLevel & 0x4) != 0) {
/* 714 */       return LogLevel.ERROR;
/*     */     }
/*     */     
/* 717 */     return LogLevel.AUDIT;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean isLoggable(int fwkEntrySeverity) {
/* 724 */     if (this.logLevel == 0)
/* 725 */       return true; 
/* 726 */     return ((fwkEntrySeverity & this.logLevel) != 0);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isLoggable(Bundle bundle, String loggableName, int loggableLevel) {
/* 732 */     if (!this.enabled)
/* 733 */       return false; 
/* 734 */     if (this.loggerName.equals(loggableName))
/* 735 */       return isLoggable(convertSeverity(loggableLevel)); 
/* 736 */     if ("org.eclipse.performance.logger".equals(loggableName))
/*     */     {
/*     */       
/* 739 */       return false; } 
/* 740 */     if (!"org.eclipse.equinox.logger".equals(this.loggerName))
/*     */     {
/* 742 */       return false;
/*     */     }
/* 744 */     return (loggableLevel == 1);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void logged(LogEntry entry) {
/* 750 */     if (!(entry instanceof ExtendedLogEntry)) {
/*     */       return;
/*     */     }
/* 753 */     ExtendedLogEntry extended = (ExtendedLogEntry)entry;
/* 754 */     Object context = extended.getContext();
/* 755 */     if (context instanceof FrameworkLogEntry) {
/* 756 */       log((FrameworkLogEntry)context);
/*     */       
/*     */       return;
/*     */     } 
/* 760 */     log(new FrameworkLogEntry(getFwkEntryTag(entry), convertSeverity(entry.getLevel()), 0, entry.getMessage(), 0, entry.getException(), null));
/*     */   }
/*     */   
/*     */   private static String getFwkEntryTag(LogEntry entry) {
/* 764 */     Bundle b = entry.getBundle();
/* 765 */     if (b != null && b.getSymbolicName() != null)
/* 766 */       return b.getSymbolicName(); 
/* 767 */     return "unknown";
/*     */   }
/*     */ 
/*     */   
/*     */   private static int convertSeverity(int entryLevel) {
/* 772 */     switch (entryLevel) {
/*     */       case 1:
/* 774 */         return 4;
/*     */       case 2:
/* 776 */         return 2;
/*     */       case 3:
/* 778 */         return 1;
/*     */       case 4:
/* 780 */         return 0;
/*     */     } 
/* 782 */     return 32;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getLoggerName() {
/* 787 */     return this.loggerName;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.osgi-3.18.400.jar!\org\eclipse\osgi\internal\log\EquinoxLogWriter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */