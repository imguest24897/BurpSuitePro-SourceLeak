/*     */ package org.eclipse.osgi.internal.loader.sources;
/*     */ 
/*     */ import java.net.URL;
/*     */ import java.util.Collection;
/*     */ import java.util.Enumeration;
/*     */ import java.util.Iterator;
/*     */ import org.eclipse.osgi.internal.loader.BundleLoader;
/*     */ import org.eclipse.osgi.util.ManifestElement;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FilteredSourcePackage
/*     */   extends SingleSourcePackage
/*     */ {
/*     */   private static final char ALL = '*';
/*     */   private final String[] includes;
/*     */   private final String[] excludes;
/*     */   
/*     */   public FilteredSourcePackage(String name, BundleLoader supplier, String includes, String excludes) {
/*  27 */     super(name, supplier);
/*  28 */     this.includes = (includes != null) ? ManifestElement.getArrayFromList(includes) : null;
/*  29 */     this.excludes = (excludes != null) ? ManifestElement.getArrayFromList(excludes) : null;
/*     */   }
/*     */ 
/*     */   
/*     */   public URL getResource(String name) {
/*  34 */     if (isFiltered(name, getId()))
/*  35 */       return null; 
/*  36 */     return super.getResource(name);
/*     */   }
/*     */ 
/*     */   
/*     */   public Enumeration<URL> getResources(String name) {
/*  41 */     if (isFiltered(name, getId()))
/*  42 */       return null; 
/*  43 */     return super.getResources(name);
/*     */   }
/*     */ 
/*     */   
/*     */   public Class<?> loadClass(String name) throws ClassNotFoundException {
/*  48 */     if (isFiltered(name, getId()))
/*  49 */       return null; 
/*  50 */     return super.loadClass(name);
/*     */   }
/*     */   
/*     */   private boolean isFiltered(String name, String pkgName) {
/*  54 */     String lastName = getName(name, pkgName);
/*  55 */     return !(isIncluded(lastName) && !isExcluded(lastName));
/*     */   }
/*     */   
/*     */   private String getName(String name, String pkgName) {
/*  59 */     if (!".".equals(pkgName) && pkgName.length() + 1 <= name.length())
/*  60 */       return name.substring(pkgName.length() + 1); 
/*  61 */     return name;
/*     */   }
/*     */   
/*     */   private boolean isIncluded(String name) {
/*  65 */     if (this.includes == null)
/*  66 */       return true; 
/*  67 */     return isInList(name, this.includes);
/*     */   }
/*     */   
/*     */   private boolean isExcluded(String name) {
/*  71 */     if (this.excludes == null)
/*  72 */       return false; 
/*  73 */     return isInList(name, this.excludes); } private boolean isInList(String name, String[] list) {
/*     */     byte b;
/*     */     int i;
/*     */     String[] arrayOfString;
/*  77 */     for (i = (arrayOfString = list).length, b = 0; b < i; ) { String s = arrayOfString[b];
/*  78 */       int len = s.length();
/*  79 */       if (len != 0) {
/*     */         
/*  81 */         if (s.charAt(0) == '*' && len == 1) {
/*  82 */           return true;
/*     */         }
/*  84 */         if (s.charAt(len - 1) == '*' && 
/*  85 */           name.startsWith(s.substring(0, len - 1))) {
/*  86 */           return true;
/*     */         }
/*     */         
/*  89 */         if (name.equals(s))
/*  90 */           return true; 
/*     */       }  b++; }
/*     */     
/*  93 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public Collection<String> listResources(String path, String filePattern) {
/*  98 */     Collection<String> result = super.listResources(path, filePattern);
/*  99 */     for (Iterator<String> resources = result.iterator(); resources.hasNext(); ) {
/* 100 */       String resource = resources.next();
/* 101 */       int lastSlash = resource.lastIndexOf('/');
/* 102 */       String fileName = (lastSlash >= 0) ? resource.substring(lastSlash + 1) : resource;
/* 103 */       if (!isIncluded(fileName) || isExcluded(fileName))
/* 104 */         resources.remove(); 
/*     */     } 
/* 106 */     return result;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.osgi-3.18.400.jar!\org\eclipse\osgi\internal\loader\sources\FilteredSourcePackage.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */