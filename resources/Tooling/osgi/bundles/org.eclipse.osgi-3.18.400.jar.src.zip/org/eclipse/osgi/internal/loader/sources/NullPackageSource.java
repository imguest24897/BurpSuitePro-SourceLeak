/*    */ package org.eclipse.osgi.internal.loader.sources;
/*    */ 
/*    */ import java.net.URL;
/*    */ import java.util.Collection;
/*    */ import java.util.Collections;
/*    */ import java.util.Enumeration;
/*    */ import java.util.HashMap;
/*    */ import java.util.List;
/*    */ import java.util.Map;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NullPackageSource
/*    */   extends PackageSource
/*    */ {
/* 30 */   static Map<String, NullPackageSource> sources = new HashMap<>();
/*    */   
/*    */   private NullPackageSource(String name) {
/* 33 */     super(name);
/*    */   }
/*    */ 
/*    */   
/*    */   public SingleSourcePackage[] getSuppliers() {
/* 38 */     return null;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean isNullSource() {
/* 43 */     return true;
/*    */   }
/*    */ 
/*    */   
/*    */   public Class<?> loadClass(String name) {
/* 48 */     return null;
/*    */   }
/*    */ 
/*    */   
/*    */   public URL getResource(String name) {
/* 53 */     return null;
/*    */   }
/*    */ 
/*    */   
/*    */   public Enumeration<URL> getResources(String name) {
/* 58 */     return null;
/*    */   }
/*    */   
/*    */   public static synchronized NullPackageSource getNullPackageSource(String name) {
/* 62 */     NullPackageSource result = sources.get(name);
/* 63 */     if (result != null)
/* 64 */       return result; 
/* 65 */     result = new NullPackageSource(name);
/* 66 */     sources.put(name, result);
/* 67 */     return result;
/*    */   }
/*    */ 
/*    */   
/*    */   public List<String> listResources(String path, String filePattern) {
/* 72 */     return Collections.emptyList();
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.osgi-3.18.400.jar!\org\eclipse\osgi\internal\loader\sources\NullPackageSource.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */