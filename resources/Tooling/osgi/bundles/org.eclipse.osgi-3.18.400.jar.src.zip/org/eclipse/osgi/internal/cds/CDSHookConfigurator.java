/*    */ package org.eclipse.osgi.internal.cds;
/*    */ 
/*    */ import org.eclipse.osgi.internal.framework.EquinoxContainer;
/*    */ import org.eclipse.osgi.internal.hookregistry.HookConfigurator;
/*    */ import org.eclipse.osgi.internal.hookregistry.HookRegistry;
/*    */ import org.eclipse.osgi.internal.log.EquinoxLogServices;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CDSHookConfigurator
/*    */   implements HookConfigurator
/*    */ {
/*    */   private static final String REPORT_ERRORS = "j9.cds.reporterrors";
/*    */   private static final String DISABLE_CDS = "j9.cds.disable";
/*    */   private static final String OLD_CDS_CONFIGURATOR = "com.ibm.cds.CDSHookConfigurator";
/*    */   private static final String J9_SHARED_CLASS_HELPER_CLASS = "com.ibm.oti.shared.SharedClassHelperFactory";
/*    */   
/*    */   public void addHooks(HookRegistry hookRegistry) {
/* 40 */     boolean disableCDS = Boolean.valueOf(hookRegistry.getConfiguration().getProperty("j9.cds.disable")).booleanValue();
/* 41 */     if (disableCDS) {
/*    */       return;
/*    */     }
/*    */     
/*    */     try {
/* 46 */       Class.forName("com.ibm.cds.CDSHookConfigurator");
/*    */       
/*    */       return;
/* 49 */     } catch (ClassNotFoundException classNotFoundException) {
/*    */ 
/*    */       
/*    */       try {
/* 53 */         Class.forName("com.ibm.oti.shared.SharedClassHelperFactory");
/* 54 */       } catch (ClassNotFoundException classNotFoundException1) {
/* 55 */         boolean reportErrors = Boolean.valueOf(hookRegistry.getConfiguration().getProperty("j9.cds.reporterrors")).booleanValue();
/*    */         
/* 57 */         if (reportErrors) {
/* 58 */           EquinoxContainer container = hookRegistry.getContainer();
/* 59 */           EquinoxLogServices logServices = container.getLogServices();
/* 60 */           logServices.log("org.eclipse.osgi", 2, "The J9 Class Sharing Adaptor will not work in this configuration. You are not running on a J9 Java VM.", null);
/*    */         } 
/*    */         
/*    */         return;
/*    */       } 
/* 65 */       (new CDSHookImpls()).registerHooks(hookRegistry);
/*    */       return;
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.osgi-3.18.400.jar!\org\eclipse\osgi\internal\cds\CDSHookConfigurator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */