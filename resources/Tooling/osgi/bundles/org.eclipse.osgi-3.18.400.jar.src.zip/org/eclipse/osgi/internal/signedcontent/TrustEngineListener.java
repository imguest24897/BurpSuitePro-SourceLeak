/*    */ package org.eclipse.osgi.internal.signedcontent;
/*    */ 
/*    */ import java.security.cert.Certificate;
/*    */ import java.util.HashSet;
/*    */ import java.util.Set;
/*    */ import org.eclipse.osgi.signedcontent.SignedContent;
/*    */ import org.eclipse.osgi.signedcontent.SignerInfo;
/*    */ import org.osgi.framework.Bundle;
/*    */ import org.osgi.framework.BundleContext;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TrustEngineListener
/*    */ {
/*    */   private final BundleContext context;
/*    */   private final SignedBundleHook signedBundleHook;
/*    */   
/*    */   TrustEngineListener(BundleContext context, SignedBundleHook signedBundleHook) {
/* 30 */     this.context = context;
/* 31 */     this.signedBundleHook = signedBundleHook;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void addedTrustAnchor(Certificate anchor) {
/* 37 */     Bundle[] bundles = this.context.getBundles(); byte b; int i; Bundle[] arrayOfBundle1;
/* 38 */     for (i = (arrayOfBundle1 = bundles).length, b = 0; b < i; ) { Bundle bundle = arrayOfBundle1[b];
/* 39 */       SignedContentFromBundleFile signedContent = getSignedContent(bundle);
/* 40 */       if (signedContent != null && signedContent.isSigned()) {
/*    */         
/* 42 */         SignerInfo[] infos = signedContent.getSignerInfos(); byte b1; int j; SignerInfo[] arrayOfSignerInfo1;
/* 43 */         for (j = (arrayOfSignerInfo1 = infos).length, b1 = 0; b1 < j; ) { SignerInfo info = arrayOfSignerInfo1[b1];
/* 44 */           if (info.getTrustAnchor() == null) {
/*    */             
/* 46 */             this.signedBundleHook.determineTrust(signedContent, 
/* 47 */                 2);
/*    */           } else {
/* 49 */             SignerInfo tsa = signedContent.getTSASignerInfo(info);
/* 50 */             if (tsa != null && tsa.getTrustAnchor() == null)
/*    */             {
/* 52 */               this.signedBundleHook.determineTrust(signedContent, 
/* 53 */                   2); } 
/*    */           } 
/*    */           b1++; }
/*    */       
/*    */       } 
/*    */       b++; }
/*    */   
/*    */   }
/*    */   
/*    */   public void removedTrustAnchor(Certificate anchor) {
/* 63 */     Bundle[] bundles = this.context.getBundles();
/* 64 */     Set<Bundle> usingAnchor = new HashSet<>();
/* 65 */     Set<SignerInfo> untrustedSigners = new HashSet<>(); byte b; int i; Bundle[] arrayOfBundle1;
/* 66 */     for (i = (arrayOfBundle1 = bundles).length, b = 0; b < i; ) { Bundle bundle = arrayOfBundle1[b];
/* 67 */       SignedContentFromBundleFile signedContent = getSignedContent(bundle);
/* 68 */       if (signedContent != null && signedContent.isSigned()) {
/*    */         
/* 70 */         SignerInfo[] infos = signedContent.getSignerInfos(); byte b1; int j; SignerInfo[] arrayOfSignerInfo1;
/* 71 */         for (j = (arrayOfSignerInfo1 = infos).length, b1 = 0; b1 < j; ) { SignerInfo info = arrayOfSignerInfo1[b1];
/* 72 */           if (anchor.equals(info.getTrustAnchor())) {
/*    */             
/* 74 */             untrustedSigners.add(info);
/* 75 */             usingAnchor.add(bundle);
/*    */           } 
/* 77 */           SignerInfo tsa = signedContent.getTSASignerInfo(info);
/* 78 */           if (tsa != null && anchor.equals(tsa.getTrustAnchor())) {
/*    */             
/* 80 */             usingAnchor.add(bundle);
/* 81 */             untrustedSigners.add(tsa);
/*    */           }  b1++; }
/*    */       
/*    */       } 
/*    */       b++; }
/*    */     
/* 87 */     for (SignerInfo untrustedSigner : untrustedSigners) {
/* 88 */       ((SignedContentFromBundleFile.BaseSignerInfo)untrustedSigner).setTrustAnchor(null);
/*    */     }
/* 90 */     for (Bundle bundle : usingAnchor) {
/* 91 */       SignedContentFromBundleFile signedContent = getSignedContent(bundle);
/*    */       
/* 93 */       this.signedBundleHook.determineTrust(signedContent, 2);
/*    */     } 
/*    */   }
/*    */   
/*    */   private SignedContentFromBundleFile getSignedContent(Bundle bundle) {
/* 98 */     return (SignedContentFromBundleFile)bundle.adapt(SignedContent.class);
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.osgi-3.18.400.jar!\org\eclipse\osgi\internal\signedcontent\TrustEngineListener.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */