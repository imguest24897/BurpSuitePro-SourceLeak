/*     */ package org.eclipse.osgi.internal.container;
/*     */ 
/*     */ import java.security.Permission;
/*     */ import java.security.SecureRandom;
/*     */ import java.util.AbstractList;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Enumeration;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Random;
/*     */ import java.util.RandomAccess;
/*     */ import java.util.UUID;
/*     */ import org.eclipse.osgi.internal.framework.EquinoxConfiguration;
/*     */ import org.osgi.framework.Bundle;
/*     */ import org.osgi.framework.BundlePermission;
/*     */ import org.osgi.framework.CapabilityPermission;
/*     */ import org.osgi.framework.PackagePermission;
/*     */ import org.osgi.framework.wiring.BundleCapability;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class InternalUtils
/*     */ {
/*     */   public static <T> List<T> asCopy(List<? extends T> list) {
/*  51 */     if (list == null) {
/*  52 */       return null;
/*     */     }
/*  54 */     if (!(list instanceof RandomAccess)) {
/*  55 */       throw new IllegalArgumentException("Only RandomAccess lists are supported");
/*     */     }
/*  57 */     return new CopyOnFirstWriteList<>(list);
/*     */   }
/*     */   
/*     */   private static final class CopyOnFirstWriteList<T> extends AbstractList<T> implements RandomAccess {
/*     */     private List<T> copy;
/*     */     private boolean copied = false;
/*     */     
/*     */     CopyOnFirstWriteList(List<? extends T> list) {
/*  65 */       this.copy = InternalUtils.asList(list);
/*     */     }
/*     */ 
/*     */     
/*     */     public T get(int index) {
/*  70 */       return this.copy.get(index);
/*     */     }
/*     */ 
/*     */     
/*     */     public int size() {
/*  75 */       return this.copy.size();
/*     */     }
/*     */ 
/*     */     
/*     */     public void add(int index, T element) {
/*  80 */       ensureCopied();
/*  81 */       this.copy.add(index, element);
/*  82 */       this.modCount++;
/*     */     }
/*     */ 
/*     */     
/*     */     public T remove(int index) {
/*  87 */       ensureCopied();
/*  88 */       T removed = this.copy.remove(index);
/*  89 */       this.modCount++;
/*  90 */       return removed;
/*     */     }
/*     */ 
/*     */     
/*     */     public T set(int index, T element) {
/*  95 */       ensureCopied();
/*  96 */       T set = this.copy.set(index, element);
/*  97 */       this.modCount++;
/*  98 */       return set;
/*     */     }
/*     */     
/*     */     private void ensureCopied() {
/* 102 */       if (!this.copied) {
/* 103 */         this.copy = new ArrayList<>(this.copy);
/* 104 */         this.copied = true;
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> List<T> asList(List<? extends T> l) {
/* 117 */     return (List)l;
/*     */   }
/*     */   
/*     */   public static void filterCapabilityPermissions(Collection<? extends BundleCapability> capabilities) {
/* 121 */     if (System.getSecurityManager() == null) {
/*     */       return;
/*     */     }
/* 124 */     for (Iterator<? extends BundleCapability> iCapabilities = capabilities.iterator(); iCapabilities.hasNext(); ) {
/* 125 */       BundleCapability capability = iCapabilities.next();
/* 126 */       Permission permission = getProvidePermission(capability);
/* 127 */       Bundle provider = capability.getRevision().getBundle();
/* 128 */       if (provider != null && !provider.hasPermission(permission)) {
/* 129 */         iCapabilities.remove();
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   public static Permission getRequirePermission(BundleCapability candidate) {
/* 135 */     String name = candidate.getNamespace();
/* 136 */     if ("osgi.wiring.package".equals(name)) {
/* 137 */       return (Permission)new PackagePermission(getPermisionName(candidate), candidate.getRevision().getBundle(), "import");
/*     */     }
/* 139 */     if ("osgi.wiring.host".equals(name)) {
/* 140 */       return (Permission)new BundlePermission(getPermisionName(candidate), "fragment");
/*     */     }
/* 142 */     if ("osgi.wiring.bundle".equals(name)) {
/* 143 */       return (Permission)new BundlePermission(getPermisionName(candidate), "require");
/*     */     }
/* 145 */     return (Permission)new CapabilityPermission(name, candidate.getAttributes(), candidate.getRevision().getBundle(), "require");
/*     */   }
/*     */   
/*     */   public static Permission getProvidePermission(BundleCapability candidate) {
/* 149 */     String name = candidate.getNamespace();
/* 150 */     if ("osgi.wiring.package".equals(name)) {
/* 151 */       return (Permission)new PackagePermission(getPermisionName(candidate), "exportonly");
/*     */     }
/* 153 */     if ("osgi.wiring.host".equals(name)) {
/* 154 */       return (Permission)new BundlePermission(getPermisionName(candidate), "host");
/*     */     }
/* 156 */     if ("osgi.wiring.bundle".equals(name)) {
/* 157 */       return (Permission)new BundlePermission(getPermisionName(candidate), "provide");
/*     */     }
/* 159 */     return (Permission)new CapabilityPermission(name, "provide");
/*     */   }
/*     */   
/*     */   private static String getPermisionName(BundleCapability candidate) {
/* 163 */     Object name = candidate.getAttributes().get(candidate.getNamespace());
/* 164 */     if (name instanceof String) {
/* 165 */       return (String)name;
/*     */     }
/* 167 */     if (name instanceof Collection) {
/* 168 */       Collection<?> names = (Collection)name;
/* 169 */       return names.isEmpty() ? "unknown" : names.iterator().next().toString();
/*     */     } 
/* 171 */     return "unknown";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String newUUID(EquinoxConfiguration config) {
/* 178 */     boolean useSecureRandom = "true".equals(config.getConfiguration("equinox.uuid.secure"));
/* 179 */     byte[] uuidBytes = new byte[16];
/* 180 */     if (useSecureRandom) {
/* 181 */       (new SecureRandom()).nextBytes(uuidBytes);
/*     */     } else {
/* 183 */       (new Random()).nextBytes(uuidBytes);
/*     */     } 
/*     */     
/* 186 */     uuidBytes[6] = (byte)(uuidBytes[6] & 0xF);
/* 187 */     uuidBytes[6] = (byte)(uuidBytes[6] | 0x40);
/*     */     
/* 189 */     uuidBytes[8] = (byte)(uuidBytes[8] & 0x3F);
/* 190 */     uuidBytes[8] = (byte)(uuidBytes[8] | 0x80);
/*     */     
/* 192 */     long mostSignificantBits = 0L;
/* 193 */     long leastSignificantBits = 0L; int i;
/* 194 */     for (i = 0; i < 8; i++) {
/* 195 */       mostSignificantBits = mostSignificantBits << 8L | (uuidBytes[i] & 0xFF);
/*     */     }
/* 197 */     for (i = 8; i < 16; i++) {
/* 198 */       leastSignificantBits = leastSignificantBits << 8L | (uuidBytes[i] & 0xFF);
/*     */     }
/* 200 */     return (new UUID(mostSignificantBits, leastSignificantBits)).toString();
/*     */   }
/*     */   
/*     */   public static <E> Enumeration<E> asEnumeration(final Iterator<E> it) {
/* 204 */     return new Enumeration<E>()
/*     */       {
/*     */         public boolean hasMoreElements() {
/* 207 */           return it.hasNext();
/*     */         }
/*     */ 
/*     */         
/*     */         public E nextElement() {
/* 212 */           return it.next();
/*     */         }
/*     */       };
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.osgi-3.18.400.jar!\org\eclipse\osgi\internal\container\InternalUtils.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */