/*      */ package org.eclipse.osgi.storage;
/*      */ 
/*      */ import java.io.BufferedInputStream;
/*      */ import java.io.ByteArrayOutputStream;
/*      */ import java.io.DataInputStream;
/*      */ import java.io.DataOutputStream;
/*      */ import java.io.File;
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import java.lang.reflect.Method;
/*      */ import java.net.MalformedURLException;
/*      */ import java.net.URL;
/*      */ import java.net.URLConnection;
/*      */ import java.net.URLStreamHandler;
/*      */ import java.nio.charset.StandardCharsets;
/*      */ import java.nio.file.Files;
/*      */ import java.nio.file.Path;
/*      */ import java.nio.file.attribute.FileAttribute;
/*      */ import java.security.AccessController;
/*      */ import java.security.PrivilegedActionException;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Arrays;
/*      */ import java.util.Collection;
/*      */ import java.util.Collections;
/*      */ import java.util.Dictionary;
/*      */ import java.util.Enumeration;
/*      */ import java.util.HashMap;
/*      */ import java.util.Hashtable;
/*      */ import java.util.Iterator;
/*      */ import java.util.LinkedHashSet;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.Objects;
/*      */ import java.util.Properties;
/*      */ import java.util.Set;
/*      */ import java.util.StringTokenizer;
/*      */ import java.util.concurrent.atomic.AtomicBoolean;
/*      */ import java.util.stream.Stream;
/*      */ import org.eclipse.osgi.container.Module;
/*      */ import org.eclipse.osgi.container.ModuleCapability;
/*      */ import org.eclipse.osgi.container.ModuleContainer;
/*      */ import org.eclipse.osgi.container.ModuleContainerAdaptor;
/*      */ import org.eclipse.osgi.container.ModuleDatabase;
/*      */ import org.eclipse.osgi.container.ModuleRevision;
/*      */ import org.eclipse.osgi.container.ModuleRevisionBuilder;
/*      */ import org.eclipse.osgi.container.ModuleWire;
/*      */ import org.eclipse.osgi.container.ModuleWiring;
/*      */ import org.eclipse.osgi.container.builders.OSGiManifestBuilderFactory;
/*      */ import org.eclipse.osgi.framework.util.FilePath;
/*      */ import org.eclipse.osgi.framework.util.ObjectPool;
/*      */ import org.eclipse.osgi.framework.util.SecureAction;
/*      */ import org.eclipse.osgi.internal.connect.ConnectBundleFile;
/*      */ import org.eclipse.osgi.internal.container.InternalUtils;
/*      */ import org.eclipse.osgi.internal.debug.Debug;
/*      */ import org.eclipse.osgi.internal.framework.EquinoxConfiguration;
/*      */ import org.eclipse.osgi.internal.framework.EquinoxContainer;
/*      */ import org.eclipse.osgi.internal.framework.EquinoxContainerAdaptor;
/*      */ import org.eclipse.osgi.internal.framework.FilterImpl;
/*      */ import org.eclipse.osgi.internal.hookregistry.BundleFileWrapperFactoryHook;
/*      */ import org.eclipse.osgi.internal.hookregistry.StorageHookFactory;
/*      */ import org.eclipse.osgi.internal.location.BasicLocation;
/*      */ import org.eclipse.osgi.internal.location.LocationHelper;
/*      */ import org.eclipse.osgi.internal.log.EquinoxLogServices;
/*      */ import org.eclipse.osgi.internal.messages.Msg;
/*      */ import org.eclipse.osgi.internal.permadmin.SecurityAdmin;
/*      */ import org.eclipse.osgi.service.datalocation.Location;
/*      */ import org.eclipse.osgi.storage.bundlefile.BundleEntry;
/*      */ import org.eclipse.osgi.storage.bundlefile.BundleFile;
/*      */ import org.eclipse.osgi.storage.bundlefile.BundleFileWrapper;
/*      */ import org.eclipse.osgi.storage.bundlefile.BundleFileWrapperChain;
/*      */ import org.eclipse.osgi.storage.bundlefile.DirBundleFile;
/*      */ import org.eclipse.osgi.storage.bundlefile.MRUBundleFileList;
/*      */ import org.eclipse.osgi.storage.bundlefile.NestedDirBundleFile;
/*      */ import org.eclipse.osgi.storage.bundlefile.ZipBundleFile;
/*      */ import org.eclipse.osgi.storage.url.reference.Handler;
/*      */ import org.eclipse.osgi.storagemanager.ManagedOutputStream;
/*      */ import org.eclipse.osgi.storagemanager.StorageManager;
/*      */ import org.eclipse.osgi.util.ManifestElement;
/*      */ import org.eclipse.osgi.util.NLS;
/*      */ import org.osgi.framework.Bundle;
/*      */ import org.osgi.framework.BundleContext;
/*      */ import org.osgi.framework.BundleException;
/*      */ import org.osgi.framework.Filter;
/*      */ import org.osgi.framework.InvalidSyntaxException;
/*      */ import org.osgi.framework.Version;
/*      */ import org.osgi.framework.connect.ConnectModule;
/*      */ import org.osgi.framework.wiring.BundleCapability;
/*      */ import org.osgi.resource.Requirement;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class Storage
/*      */ {
/*      */   public static final int VERSION = 6;
/*      */   private static final int CONTENT_TYPE_VERSION = 6;
/*      */   private static final int CACHED_SYSTEM_CAPS_VERION = 5;
/*      */   private static final int MR_JAR_VERSION = 4;
/*      */   private static final int LOWEST_VERSION_SUPPORTED = 3;
/*      */   public static final String BUNDLE_DATA_DIR = "data";
/*      */   public static final String BUNDLE_FILE_NAME = "bundleFile";
/*      */   public static final String FRAMEWORK_INFO = "framework.info";
/*      */   public static final String ECLIPSE_SYSTEMBUNDLE = "Eclipse-SystemBundle";
/*      */   public static final String DELETE_FLAG = ".delete";
/*      */   public static final String LIB_TEMP = "libtemp";
/*      */   private static final String JAVASE = "JavaSE";
/*      */   private static final String PROFILE_EXT = ".profile";
/*      */   
/*      */   public static class StorageException
/*      */     extends RuntimeException
/*      */   {
/*      */     private static final long serialVersionUID = 1L;
/*      */     
/*      */     public StorageException() {}
/*      */     
/*      */     public StorageException(String message, Throwable cause) {
/*  131 */       super(message, cause);
/*      */     }
/*      */     
/*      */     public StorageException(String message) {
/*  135 */       super(message);
/*      */     }
/*      */     
/*      */     public StorageException(Throwable cause) {
/*  139 */       super(cause);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  158 */   private static final String NUL = new String(new byte[1]);
/*      */   
/*      */   private static final String INITIAL_LOCATION = "initial@";
/*  161 */   static final SecureAction secureAction = AccessController.<SecureAction>doPrivileged(SecureAction.createSecureAction());
/*      */   
/*      */   private final EquinoxContainer equinoxContainer;
/*      */   private final String installPath;
/*      */   private final Location osgiLocation;
/*      */   private final File childRoot;
/*      */   private final File parentRoot;
/*      */   private final PermissionData permissionData;
/*      */   private final SecurityAdmin securityAdmin;
/*      */   private final EquinoxContainerAdaptor adaptor;
/*      */   private final ModuleDatabase moduleDatabase;
/*      */   private final ModuleContainer moduleContainer;
/*  173 */   private final Object saveMonitor = new Object();
/*  174 */   private long lastSavedTimestamp = -1L;
/*      */   private final MRUBundleFileList mruList;
/*      */   private final FrameworkExtensionInstaller extensionInstaller;
/*  177 */   private final List<String> cachedHeaderKeys = Arrays.asList(new String[] { "Bundle-SymbolicName", "Bundle-ActivationPolicy", "Service-Component" });
/*      */   private final boolean allowRestrictedProvides;
/*  179 */   private final AtomicBoolean refreshMRBundles = new AtomicBoolean(false);
/*      */   private final Version runtimeVersion;
/*      */   private final String javaSpecVersion;
/*      */   
/*      */   public static Storage createStorage(EquinoxContainer container) throws IOException, BundleException {
/*  184 */     String[] cachedInfo = new String[3];
/*  185 */     Storage storage = new Storage(container, cachedInfo);
/*      */     
/*  187 */     storage.checkSystemBundle(cachedInfo);
/*  188 */     storage.refreshStaleBundles();
/*  189 */     storage.installExtensions();
/*      */ 
/*      */     
/*  192 */     storage.getModuleContainer().setInitialModuleStates();
/*  193 */     return storage;
/*      */   }
/*      */ 
/*      */   
/*      */   private Storage(EquinoxContainer container, String[] cachedInfo) throws IOException {
/*  198 */     Version defaultVersion = Version.valueOf("1.8");
/*  199 */     Version javaVersion = defaultVersion;
/*      */     
/*  201 */     String javaSpecVersionProp = System.getProperty("java.specification.version");
/*  202 */     StringTokenizer st = new StringTokenizer(javaSpecVersionProp, " _-");
/*  203 */     javaSpecVersionProp = st.nextToken();
/*      */     try {
/*  205 */       String[] vComps = javaSpecVersionProp.split("\\.");
/*      */       
/*  207 */       int major = (vComps.length > 0) ? Integer.parseInt(vComps[0]) : 0;
/*  208 */       int minor = (vComps.length > 1) ? Integer.parseInt(vComps[1]) : 0;
/*  209 */       int micro = (vComps.length > 2) ? Integer.parseInt(vComps[2]) : 0;
/*  210 */       javaVersion = new Version(major, minor, micro);
/*  211 */     } catch (IllegalArgumentException illegalArgumentException) {}
/*      */ 
/*      */     
/*  214 */     if (javaVersion.compareTo(defaultVersion) < 0)
/*      */     {
/*      */ 
/*      */       
/*  218 */       javaVersion = defaultVersion;
/*      */     }
/*  220 */     this.runtimeVersion = javaVersion;
/*  221 */     this.javaSpecVersion = javaSpecVersionProp;
/*  222 */     this.mruList = new MRUBundleFileList(getBundleFileLimit(container.getConfiguration()), container.getConfiguration().getDebug());
/*  223 */     this.equinoxContainer = container;
/*  224 */     this.extensionInstaller = new FrameworkExtensionInstaller(container.getConfiguration());
/*  225 */     this.allowRestrictedProvides = Boolean.parseBoolean(container.getConfiguration().getConfiguration("osgi.equinox.allow.restricted.provides"));
/*      */ 
/*      */ 
/*      */     
/*  229 */     BasicLocation basicLocation1 = container.getLocations().getInstallLocation();
/*  230 */     URL installURL = basicLocation1.getURL();
/*      */     
/*  232 */     this.installPath = installURL.getPath();
/*      */     
/*  234 */     BasicLocation basicLocation2 = container.getLocations().getConfigurationLocation();
/*  235 */     Location parentConfigLocation = basicLocation2.getParentLocation();
/*  236 */     Location osgiParentLocation = null;
/*  237 */     if (parentConfigLocation != null) {
/*  238 */       osgiParentLocation = parentConfigLocation.createLocation(null, parentConfigLocation.getDataArea("org.eclipse.osgi"), true);
/*      */     }
/*  240 */     this.osgiLocation = basicLocation2.createLocation(osgiParentLocation, basicLocation2.getDataArea("org.eclipse.osgi"), basicLocation2.isReadOnly());
/*  241 */     this.childRoot = new File(this.osgiLocation.getURL().getPath());
/*      */     
/*  243 */     if (Boolean.valueOf(container.getConfiguration().getConfiguration("osgi.clean")).booleanValue()) {
/*  244 */       cleanOSGiStorage(this.osgiLocation, this.childRoot);
/*      */     }
/*  246 */     if (!this.osgiLocation.isReadOnly()) {
/*  247 */       this.childRoot.mkdirs();
/*      */     }
/*  249 */     Location parent = this.osgiLocation.getParentLocation();
/*  250 */     this.parentRoot = (parent == null) ? null : new File(parent.getURL().getPath());
/*      */     
/*  252 */     if (container.getConfiguration().getConfiguration("org.osgi.framework.storage") == null)
/*      */     {
/*      */       
/*  255 */       container.getConfiguration().setConfiguration("org.osgi.framework.storage", this.childRoot.getParentFile().getAbsolutePath());
/*      */     }
/*      */     
/*  258 */     InputStream info = getInfoInputStream();
/*  259 */     DataInputStream data = (info == null) ? null : new DataInputStream(new BufferedInputStream(info));
/*      */     try {
/*      */       Map<Long, BundleInfo.Generation> generations;
/*      */       try {
/*  263 */         generations = loadGenerations(data, cachedInfo);
/*  264 */       } catch (IllegalArgumentException e) {
/*  265 */         this.equinoxContainer.getLogServices().log("org.eclipse.osgi", 2, "The persistent format for the framework data has changed.  The framework will be reinitialized: " + e.getMessage(), null);
/*  266 */         generations = new HashMap<>(0);
/*  267 */         data = null;
/*  268 */         cleanOSGiStorage(this.osgiLocation, this.childRoot);
/*      */       } 
/*  270 */       this.permissionData = loadPermissionData(data);
/*  271 */       this.securityAdmin = new SecurityAdmin(null, this.permissionData);
/*  272 */       this.adaptor = new EquinoxContainerAdaptor(this.equinoxContainer, this, generations);
/*  273 */       this.moduleDatabase = new ModuleDatabase((ModuleContainerAdaptor)this.adaptor);
/*  274 */       this.moduleContainer = new ModuleContainer((ModuleContainerAdaptor)this.adaptor, this.moduleDatabase);
/*  275 */       if (data != null) {
/*      */         try {
/*  277 */           this.moduleDatabase.load(data);
/*  278 */           this.lastSavedTimestamp = this.moduleDatabase.getTimestamp();
/*  279 */         } catch (IllegalArgumentException e) {
/*  280 */           this.equinoxContainer.getLogServices().log("org.eclipse.osgi", 2, "Incompatible version.  Starting with empty framework.", e);
/*      */ 
/*      */           
/*  283 */           cleanOSGiStorage(this.osgiLocation, this.childRoot);
/*      */           
/*  285 */           generations.clear();
/*      */         } 
/*      */       }
/*      */     } finally {
/*  289 */       if (data != null) {
/*      */         try {
/*  291 */           data.close();
/*  292 */         } catch (IOException iOException) {}
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public Version getRuntimeVersion() {
/*  300 */     return this.runtimeVersion;
/*      */   }
/*      */   
/*      */   public MRUBundleFileList getMRUBundleFileList() {
/*  304 */     return this.mruList;
/*      */   }
/*      */   
/*      */   private int getBundleFileLimit(EquinoxConfiguration configuration) {
/*  308 */     int propValue = 100;
/*      */     try {
/*  310 */       String prop = configuration.getConfiguration("osgi.bundlefile.limit");
/*  311 */       if (prop != null)
/*  312 */         propValue = Integer.parseInt(prop); 
/*  313 */     } catch (NumberFormatException numberFormatException) {}
/*      */ 
/*      */     
/*  316 */     return propValue;
/*      */   }
/*      */   
/*      */   private void installExtensions() {
/*  320 */     Module systemModule = this.moduleContainer.getModule(0L);
/*  321 */     ModuleRevision systemRevision = (systemModule == null) ? null : systemModule.getCurrentRevision();
/*  322 */     ModuleWiring systemWiring = (systemRevision == null) ? null : systemRevision.getWiring();
/*  323 */     if (systemWiring == null) {
/*      */       return;
/*      */     }
/*  326 */     Collection<ModuleRevision> fragments = new ArrayList<>();
/*  327 */     for (ModuleWire hostWire : systemWiring.getProvidedModuleWires("osgi.wiring.host")) {
/*  328 */       fragments.add(hostWire.getRequirer());
/*      */     }
/*      */     try {
/*  331 */       getExtensionInstaller().addExtensionContent(fragments, null);
/*  332 */     } catch (BundleException e) {
/*  333 */       getLogServices().log("org.eclipse.osgi", 4, e.getMessage(), (Throwable)e);
/*      */     } 
/*      */   }
/*      */   
/*      */   private static PermissionData loadPermissionData(DataInputStream in) throws IOException {
/*  338 */     PermissionData permData = new PermissionData();
/*  339 */     if (in != null) {
/*  340 */       permData.readPermissionData(in);
/*      */     }
/*  342 */     return permData;
/*      */   }
/*      */   
/*      */   private void refreshStaleBundles() throws BundleException {
/*  346 */     Collection<Module> needsRefresh = new ArrayList<>(0);
/*      */ 
/*      */     
/*  349 */     for (Module module : this.moduleContainer.getModules()) {
/*  350 */       if (module.getId().longValue() == 0L)
/*      */         continue; 
/*  352 */       ModuleRevision revision = module.getCurrentRevision();
/*  353 */       BundleInfo.Generation generation = (BundleInfo.Generation)revision.getRevisionInfo();
/*  354 */       if (needsDiscarding(generation)) {
/*  355 */         needsRefresh.add(module);
/*  356 */         this.moduleContainer.uninstall(module);
/*  357 */         generation.delete();
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/*  362 */     if (this.refreshMRBundles.get()) {
/*  363 */       needsRefresh.addAll(refreshMRJarBundles());
/*      */     }
/*      */ 
/*      */     
/*  367 */     if (!needsRefresh.isEmpty()) {
/*  368 */       this.moduleContainer.refresh(needsRefresh);
/*      */     }
/*      */   }
/*      */   
/*      */   private boolean needsDiscarding(BundleInfo.Generation generation) {
/*  373 */     for (StorageHookFactory.StorageHook<?, ?> hook : generation.getStorageHooks()) {
/*      */       try {
/*  375 */         hook.validate();
/*  376 */       } catch (IllegalStateException e) {
/*  377 */         this.equinoxContainer.getLogServices().log("org.eclipse.osgi", 2, "Error validating installed bundle.", e);
/*  378 */         return true;
/*      */       } 
/*      */     } 
/*  381 */     File content = generation.getContent();
/*  382 */     if (content == null) {
/*  383 */       return false;
/*      */     }
/*  385 */     if (getConfiguration().inCheckConfigurationMode()) {
/*  386 */       if (generation.isDirectory()) {
/*  387 */         content = new File(content, "META-INF/MANIFEST.MF");
/*      */       }
/*  389 */       return (generation.getLastModified() != secureAction.lastModified(content));
/*      */     } 
/*  391 */     if (!content.exists())
/*      */     {
/*  393 */       return true;
/*      */     }
/*  395 */     return false;
/*      */   }
/*      */   
/*      */   private void checkSystemBundle(String[] cachedInfo) {
/*  399 */     Module systemModule = this.moduleContainer.getModule(0L);
/*  400 */     BundleInfo.Generation newGeneration = null;
/*      */     try {
/*  402 */       if (systemModule == null) {
/*  403 */         BundleInfo info = new BundleInfo(this, 0L, "System Bundle", 0L);
/*  404 */         newGeneration = info.createGeneration();
/*      */         
/*  406 */         File contentFile = getSystemContent();
/*  407 */         newGeneration.setContent(contentFile, ContentProvider.Type.DEFAULT);
/*      */ 
/*      */         
/*  410 */         loadVMProfile(newGeneration);
/*      */         
/*  412 */         String extraCapabilities = getSystemExtraCapabilities();
/*  413 */         String extraExports = getSystemExtraPackages();
/*      */         
/*  415 */         ModuleRevisionBuilder builder = getBuilder(newGeneration, extraCapabilities, extraExports);
/*  416 */         systemModule = this.moduleContainer.install(null, "System Bundle", builder, newGeneration);
/*  417 */         this.moduleContainer.resolve(Collections.singletonList(systemModule), false);
/*      */       } else {
/*  419 */         ModuleRevision moduleRevision = systemModule.getCurrentRevision();
/*  420 */         BundleInfo.Generation currentGeneration = (moduleRevision == null) ? null : (BundleInfo.Generation)moduleRevision.getRevisionInfo();
/*  421 */         if (currentGeneration == null) {
/*  422 */           throw new IllegalStateException("No current revision for system bundle.");
/*      */         }
/*      */         
/*      */         try {
/*  426 */           loadVMProfile(currentGeneration);
/*      */           
/*  428 */           String extraCapabilities = getSystemExtraCapabilities();
/*  429 */           String extraExports = getSystemExtraPackages();
/*  430 */           File contentFile = currentGeneration.getContent();
/*  431 */           if (systemNeedsUpdate(contentFile, moduleRevision, currentGeneration, extraCapabilities, extraExports, cachedInfo)) {
/*  432 */             newGeneration = currentGeneration.getBundleInfo().createGeneration();
/*  433 */             newGeneration.setContent(contentFile, ContentProvider.Type.DEFAULT);
/*  434 */             ModuleRevisionBuilder newBuilder = getBuilder(newGeneration, extraCapabilities, extraExports);
/*  435 */             this.moduleContainer.update(systemModule, newBuilder, newGeneration);
/*  436 */             this.moduleContainer.refresh(Collections.singleton(systemModule));
/*      */           }
/*  438 */           else if (moduleRevision.getWiring() == null) {
/*      */             
/*  440 */             this.moduleContainer.resolve(Collections.singleton(systemModule), true);
/*      */           }
/*      */         
/*  443 */         } catch (BundleException e) {
/*  444 */           throw new IllegalStateException("Could not create a builder for the system bundle.", e);
/*      */         } 
/*      */       } 
/*  447 */       ModuleRevision currentRevision = systemModule.getCurrentRevision();
/*  448 */       List<ModuleCapability> nativeEnvironments = currentRevision.getModuleCapabilities("osgi.native");
/*  449 */       Map<String, Object> configMap = this.equinoxContainer.getConfiguration().getInitialConfig();
/*  450 */       for (ModuleCapability nativeEnvironment : nativeEnvironments) {
/*  451 */         nativeEnvironment.setTransientAttrs(configMap);
/*      */       }
/*  453 */       Version frameworkVersion = null;
/*  454 */       if (newGeneration != null) {
/*  455 */         frameworkVersion = findFrameworkVersion();
/*      */       } else {
/*  457 */         String sVersion = cachedInfo[0];
/*  458 */         frameworkVersion = (sVersion == null) ? findFrameworkVersion() : Version.parseVersion(sVersion);
/*      */       } 
/*  460 */       if (frameworkVersion != null) {
/*  461 */         this.equinoxContainer.getConfiguration().setConfiguration("org.osgi.framework.version", frameworkVersion.toString());
/*      */       }
/*  463 */     } catch (Exception e) {
/*  464 */       if (e instanceof RuntimeException) {
/*  465 */         throw (RuntimeException)e;
/*      */       }
/*  467 */       throw new RuntimeException("Error occurred while checking the system module.", e);
/*      */     } finally {
/*  469 */       if (newGeneration != null) {
/*  470 */         newGeneration.getBundleInfo().unlockGeneration(newGeneration);
/*      */       }
/*      */     } 
/*      */   }
/*      */   
/*      */   private Version findFrameworkVersion() {
/*  476 */     Requirement osgiPackageReq = ModuleContainer.createRequirement("osgi.wiring.package", Collections.singletonMap("filter", "(osgi.wiring.package=org.osgi.framework)"), Collections.emptyMap());
/*  477 */     Collection<BundleCapability> osgiPackages = this.moduleContainer.getFrameworkWiring().findProviders(osgiPackageReq);
/*  478 */     for (BundleCapability packageCapability : osgiPackages) {
/*  479 */       if (packageCapability.getRevision().getBundle().getBundleId() == 0L) {
/*  480 */         Version v = (Version)packageCapability.getAttributes().get("version");
/*  481 */         if (v != null) {
/*  482 */           return v;
/*      */         }
/*      */       } 
/*      */     } 
/*  486 */     return null;
/*      */   }
/*      */   
/*      */   private Collection<Module> refreshMRJarBundles() throws BundleException {
/*  490 */     Collection<Module> mrJarBundles = new ArrayList<>();
/*  491 */     for (Module m : this.moduleContainer.getModules()) {
/*  492 */       BundleInfo.Generation generation = (BundleInfo.Generation)m.getCurrentRevision().getRevisionInfo();
/*      */       
/*  494 */       if (Boolean.parseBoolean(generation.getRawHeaders().get("Multi-Release"))) {
/*  495 */         refresh(m);
/*  496 */         mrJarBundles.add(m);
/*      */       } 
/*      */     } 
/*  499 */     return mrJarBundles;
/*      */   }
/*      */   
/*      */   public void close() {
/*      */     try {
/*  504 */       save();
/*  505 */     } catch (IOException e) {
/*  506 */       getLogServices().log("org.eclipse.osgi", 4, "Error saving on shutdown", e);
/*      */     } 
/*      */ 
/*      */     
/*  510 */     List<Module> modules = this.moduleContainer.getModules();
/*  511 */     for (Module module : modules) {
/*  512 */       for (ModuleRevision revision : module.getRevisions().getModuleRevisions()) {
/*  513 */         BundleInfo.Generation generation = (BundleInfo.Generation)revision.getRevisionInfo();
/*  514 */         if (generation != null) {
/*  515 */           generation.close();
/*      */         }
/*      */       } 
/*      */     } 
/*  519 */     for (ModuleRevision removalPending : this.moduleContainer.getRemovalPending()) {
/*  520 */       BundleInfo.Generation generation = (BundleInfo.Generation)removalPending.getRevisionInfo();
/*  521 */       if (generation != null) {
/*  522 */         generation.close();
/*      */       }
/*      */     } 
/*  525 */     this.mruList.shutdown();
/*  526 */     this.adaptor.shutdownExecutors();
/*      */   }
/*      */   
/*      */   private boolean systemNeedsUpdate(File systemContent, ModuleRevision currentRevision, BundleInfo.Generation existing, String extraCapabilities, String extraExports, String[] cachedInfo) throws BundleException {
/*  530 */     if (!extraCapabilities.equals(cachedInfo[1])) {
/*  531 */       return true;
/*      */     }
/*  533 */     if (!extraExports.equals(cachedInfo[2])) {
/*  534 */       return true;
/*      */     }
/*  536 */     if (systemContent == null) {
/*      */       
/*  538 */       ModuleRevisionBuilder newBuilder = getBuilder(existing, extraCapabilities, extraExports);
/*  539 */       return !currentRevision.getVersion().equals(newBuilder.getVersion());
/*      */     } 
/*  541 */     if (existing.isDirectory()) {
/*  542 */       systemContent = new File(systemContent, "META-INF/MANIFEST.MF");
/*      */     }
/*  544 */     return (existing.getLastModified() != secureAction.lastModified(systemContent));
/*      */   }
/*      */ 
/*      */   
/*      */   private void cleanOSGiStorage(Location location, File root) {
/*  549 */     if (location.isReadOnly() || !StorageUtil.rm(root, (getConfiguration().getDebug()).DEBUG_STORAGE)) {
/*  550 */       this.equinoxContainer.getLogServices().log("org.eclipse.osgi", 4, "The -clean (osgi.clean) option was not successful. Unable to clean the storage area: " + root.getAbsolutePath(), null);
/*      */     }
/*  552 */     if (!location.isReadOnly())
/*      */     {
/*  554 */       root.mkdirs();
/*      */     }
/*      */   }
/*      */   
/*      */   public ModuleDatabase getModuleDatabase() {
/*  559 */     return this.moduleDatabase;
/*      */   }
/*      */   
/*      */   public ModuleContainerAdaptor getAdaptor() {
/*  563 */     return (ModuleContainerAdaptor)this.adaptor;
/*      */   }
/*      */   
/*      */   public ModuleContainer getModuleContainer() {
/*  567 */     return this.moduleContainer;
/*      */   }
/*      */   
/*      */   public EquinoxConfiguration getConfiguration() {
/*  571 */     return this.equinoxContainer.getConfiguration();
/*      */   }
/*      */   
/*      */   public EquinoxLogServices getLogServices() {
/*  575 */     return this.equinoxContainer.getLogServices();
/*      */   }
/*      */   
/*      */   public FrameworkExtensionInstaller getExtensionInstaller() {
/*  579 */     return this.extensionInstaller;
/*      */   }
/*      */   
/*      */   public boolean isReadOnly() {
/*  583 */     return this.osgiLocation.isReadOnly();
/*      */   }
/*      */ 
/*      */   
/*      */   public URLConnection getContentConnection(Module module, String bundleLocation, final InputStream in) throws BundleException {
/*      */     try {
/*  589 */       List<StorageHookFactory<?, ?, ?>> storageHooks = getConfiguration().getHookRegistry()
/*  590 */         .getStorageHookFactories();
/*  591 */       for (StorageHookFactory<?, ?, ?> storageHook : storageHooks) {
/*  592 */         URLConnection hookContent = storageHook.handleContentConnection(module, bundleLocation, in);
/*  593 */         if (hookContent != null) {
/*  594 */           return hookContent;
/*      */         }
/*      */       } 
/*      */       
/*  598 */       if (in != null) {
/*  599 */         return new URLConnection(null)
/*      */           {
/*      */ 
/*      */             
/*      */             public void connect() throws IOException
/*      */             {
/*  605 */               this.connected = true;
/*      */             }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*      */             public InputStream getInputStream() throws IOException {
/*  613 */               return in;
/*      */             }
/*      */           };
/*      */       }
/*  617 */       if (module == null) {
/*  618 */         if (bundleLocation == null) {
/*  619 */           throw new IllegalArgumentException("Module and location cannot be null");
/*      */         }
/*  621 */         return getContentConnection(bundleLocation);
/*      */       } 
/*  623 */       return getContentConnection(getUpdateLocation(module));
/*  624 */     } catch (IOException e) {
/*  625 */       throw new BundleException("Error reading bundle content.", e);
/*      */     } 
/*      */   }
/*      */   
/*      */   private String getUpdateLocation(Module module) {
/*  630 */     if (System.getSecurityManager() == null)
/*  631 */       return getUpdateLocation0(module); 
/*  632 */     return AccessController.<String>doPrivileged(() -> getUpdateLocation0(paramModule));
/*      */   }
/*      */   
/*      */   String getUpdateLocation0(Module module) {
/*  636 */     ModuleRevision current = module.getCurrentRevision();
/*  637 */     BundleInfo.Generation generation = (BundleInfo.Generation)current.getRevisionInfo();
/*  638 */     String updateLocation = generation.getHeaders().get("Bundle-UpdateLocation");
/*  639 */     if (updateLocation == null) {
/*  640 */       updateLocation = module.getLocation();
/*      */     }
/*  642 */     if (updateLocation.startsWith("initial@")) {
/*  643 */       updateLocation = updateLocation.substring("initial@".length());
/*      */     }
/*  645 */     return updateLocation;
/*      */   }
/*      */   
/*      */   private URLConnection getContentConnection(String spec) throws IOException {
/*  649 */     if (System.getSecurityManager() == null) {
/*  650 */       return LocationHelper.getConnection(createURL(spec));
/*      */     }
/*      */     try {
/*  653 */       return AccessController.<URLConnection>doPrivileged(() -> LocationHelper.getConnection(createURL(paramString)));
/*  654 */     } catch (PrivilegedActionException e) {
/*  655 */       if (e.getException() instanceof IOException)
/*  656 */         throw (IOException)e.getException(); 
/*  657 */       throw (RuntimeException)e.getException();
/*      */     } 
/*      */   }
/*      */   
/*      */   URL createURL(String spec) throws MalformedURLException {
/*  662 */     if (spec.startsWith("reference")) {
/*  663 */       return new URL(null, spec, (URLStreamHandler)new Handler(this.equinoxContainer.getConfiguration().getConfiguration("osgi.install.area")));
/*      */     }
/*  665 */     return new URL(spec);
/*      */   }
/*      */   public BundleInfo.Generation install(Module origin, String bundleLocation, InputStream toInstall) throws BundleException {
/*      */     InputStream in;
/*  669 */     URLConnection content = getContentConnection(null, bundleLocation, toInstall);
/*  670 */     if (this.osgiLocation.isReadOnly()) {
/*  671 */       throw new BundleException("The framework storage area is read only.", 2);
/*      */     }
/*  673 */     URL sourceURL = content.getURL();
/*      */     
/*      */     try {
/*  676 */       in = content.getInputStream();
/*  677 */     } catch (Throwable e) {
/*  678 */       throw new BundleException("Error reading bundle content.", e);
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  685 */     Module existingLocation = this.moduleContainer.getModule(bundleLocation);
/*  686 */     if (existingLocation != null) {
/*      */ 
/*      */       
/*      */       try {
/*      */         
/*  691 */         in.close();
/*  692 */       } catch (IOException iOException) {}
/*      */ 
/*      */       
/*  695 */       if (origin != null) {
/*      */         
/*  697 */         Bundle bundle = origin.getBundle();
/*  698 */         BundleContext context = (bundle == null) ? null : bundle.getBundleContext();
/*  699 */         if (context != null && context.getBundle(existingLocation.getId().longValue()) == null) {
/*  700 */           Bundle b = existingLocation.getBundle();
/*  701 */           throw new BundleException(NLS.bind(Msg.ModuleContainer_NameCollisionWithLocation, new Object[] { b.getSymbolicName(), b.getVersion(), bundleLocation }), 12);
/*      */         } 
/*      */       } 
/*  704 */       return (BundleInfo.Generation)existingLocation.getCurrentRevision().getRevisionInfo();
/*      */     } 
/*      */     
/*  707 */     ContentProvider contentProvider = getContentProvider(in, sourceURL);
/*  708 */     ContentProvider.Type contentType = contentProvider.getType();
/*  709 */     File staged = contentProvider.getContent();
/*      */     
/*  711 */     BundleInfo.Generation generation = null;
/*      */     try {
/*  713 */       Long nextID = Long.valueOf(this.moduleDatabase.getAndIncrementNextId());
/*  714 */       BundleInfo info = new BundleInfo(this, nextID.longValue(), bundleLocation, 0L);
/*  715 */       generation = info.createGeneration();
/*      */       
/*  717 */       File contentFile = getContentFile(staged, contentType, nextID.longValue(), generation.getGenerationId());
/*  718 */       generation.setContent(contentFile, contentType);
/*      */       
/*  720 */       generation.getBundleFile().open();
/*  721 */       setStorageHooks(generation);
/*      */       
/*  723 */       ModuleRevisionBuilder builder = getBuilder(generation);
/*  724 */       builder.setId(nextID.longValue());
/*      */       
/*  726 */       Module m = this.moduleContainer.install(origin, bundleLocation, builder, generation);
/*  727 */       if (!nextID.equals(m.getId())) {
/*      */         
/*  729 */         generation.delete();
/*  730 */         return (BundleInfo.Generation)m.getCurrentRevision().getRevisionInfo();
/*      */       } 
/*  732 */       return generation;
/*  733 */     } catch (Throwable t) {
/*  734 */       if (contentType == ContentProvider.Type.DEFAULT) {
/*      */         try {
/*  736 */           delete(staged);
/*  737 */         } catch (IOException iOException) {}
/*      */       }
/*      */ 
/*      */       
/*  741 */       if (generation != null) {
/*  742 */         generation.delete();
/*  743 */         generation.getBundleInfo().delete();
/*      */       } 
/*  745 */       if (t instanceof SecurityException) {
/*      */ 
/*      */         
/*  748 */         if (t.getCause() instanceof BundleException) {
/*  749 */           throw (BundleException)t.getCause();
/*      */         }
/*  751 */         throw (SecurityException)t;
/*      */       } 
/*  753 */       if (t instanceof BundleException) {
/*  754 */         throw (BundleException)t;
/*      */       }
/*  756 */       throw new BundleException("Error occurred installing a bundle.", t);
/*      */     } finally {
/*  758 */       if (generation != null) {
/*  759 */         generation.getBundleInfo().unlockGeneration(generation);
/*      */       }
/*      */     } 
/*      */   }
/*      */   
/*      */   ContentProvider getContentProvider(final InputStream in, final URL sourceURL) {
/*  765 */     if (in instanceof ContentProvider) {
/*  766 */       return (ContentProvider)in;
/*      */     }
/*  768 */     return new ContentProvider()
/*      */       {
/*      */         public ContentProvider.Type getType()
/*      */         {
/*  772 */           return ContentProvider.Type.DEFAULT;
/*      */         }
/*      */ 
/*      */         
/*      */         public File getContent() throws BundleException {
/*  777 */           return Storage.this.stageContent(in, sourceURL);
/*      */         }
/*      */       };
/*      */   }
/*      */   
/*      */   private void setStorageHooks(BundleInfo.Generation generation) throws BundleException {
/*  783 */     if (generation.getBundleInfo().getBundleId() == 0L) {
/*      */       return;
/*      */     }
/*  786 */     List<StorageHookFactory<?, ?, ?>> factories = new ArrayList<>(getConfiguration().getHookRegistry().getStorageHookFactories());
/*  787 */     List<StorageHookFactory.StorageHook<?, ?>> hooks = new ArrayList<>(factories.size());
/*  788 */     for (StorageHookFactory<?, ?, ?> storageHookFactory : factories) {
/*      */       
/*  790 */       StorageHookFactory<?, ?, ?> storageHookFactory1 = storageHookFactory;
/*  791 */       StorageHookFactory.StorageHook<Object, Object> hook = storageHookFactory1.createStorageHookAndValidateFactoryClass(generation);
/*  792 */       if (hook != null) {
/*  793 */         hooks.add(hook);
/*      */       }
/*      */     } 
/*  796 */     generation.setStorageHooks(Collections.unmodifiableList(hooks), true);
/*  797 */     for (StorageHookFactory.StorageHook<?, ?> hook : hooks) {
/*  798 */       hook.initialize(generation.getHeaders());
/*      */     }
/*      */   }
/*      */   
/*      */   public ModuleRevisionBuilder getBuilder(BundleInfo.Generation generation) throws BundleException {
/*  803 */     return getBuilder(generation, null, null);
/*      */   }
/*      */   public ModuleRevisionBuilder getBuilder(BundleInfo.Generation generation, String extraCapabilities, String extraExports) throws BundleException {
/*      */     Map<String, String> mapHeaders;
/*  807 */     Dictionary<String, String> headers = generation.getHeaders();
/*      */     
/*  809 */     if (headers instanceof Map) {
/*      */       
/*  811 */       Map<String, String> unchecked = (Map<String, String>)headers;
/*  812 */       mapHeaders = unchecked;
/*      */     } else {
/*  814 */       mapHeaders = new HashMap<>();
/*  815 */       for (Enumeration<String> eKeys = headers.keys(); eKeys.hasMoreElements(); ) {
/*  816 */         String key = eKeys.nextElement();
/*  817 */         mapHeaders.put(key, headers.get(key));
/*      */       } 
/*      */     } 
/*  820 */     if (generation.getBundleInfo().getBundleId() != 0L) {
/*  821 */       ModuleRevisionBuilder builder = OSGiManifestBuilderFactory.createBuilder(mapHeaders, null, 
/*  822 */           (generation.getContentType() == ContentProvider.Type.CONNECT) ? "" : null, 
/*  823 */           this.allowRestrictedProvides ? "" : null);
/*  824 */       if ((builder.getTypes() & 0x1) != 0) {
/*  825 */         for (ModuleRevisionBuilder.GenericInfo reqInfo : builder.getRequirements("osgi.wiring.host")) {
/*  826 */           if ("bootclasspath".equals(reqInfo.getDirectives().get("extension"))) {
/*  827 */             throw new BundleException("Boot classpath extensions are not supported.", 
/*  828 */                 1, new UnsupportedOperationException());
/*      */           }
/*      */         } 
/*      */       }
/*  832 */       return builder;
/*      */     } 
/*      */     
/*  835 */     return OSGiManifestBuilderFactory.createBuilder(mapHeaders, "system.bundle", extraExports, extraCapabilities);
/*      */   }
/*      */   
/*      */   private String getSystemExtraCapabilities() {
/*  839 */     EquinoxConfiguration equinoxConfig = this.equinoxContainer.getConfiguration();
/*  840 */     StringBuilder result = new StringBuilder();
/*      */     
/*  842 */     String systemCapabilities = equinoxConfig.getConfiguration("org.osgi.framework.system.capabilities");
/*  843 */     if (systemCapabilities != null && systemCapabilities.trim().length() > 0) {
/*  844 */       result.append(systemCapabilities).append(", ");
/*      */     }
/*      */     
/*  847 */     String extraSystemCapabilities = equinoxConfig.getConfiguration("org.osgi.framework.system.capabilities.extra");
/*  848 */     if (extraSystemCapabilities != null && extraSystemCapabilities.trim().length() > 0) {
/*  849 */       result.append(extraSystemCapabilities).append(", ");
/*      */     }
/*      */     
/*  852 */     result.append("eclipse.platform").append("; ");
/*  853 */     result.append("osgi.os").append("=").append(equinoxConfig.getOS()).append("; ");
/*  854 */     result.append("osgi.ws").append("=").append(equinoxConfig.getWS()).append("; ");
/*  855 */     result.append("osgi.arch").append("=").append(equinoxConfig.getOSArch()).append("; ");
/*  856 */     result.append("osgi.nl").append("=").append(equinoxConfig.getNL());
/*      */     
/*  858 */     String osName = equinoxConfig.getConfiguration("org.osgi.framework.os.name");
/*  859 */     osName = (osName == null) ? null : osName.toLowerCase();
/*  860 */     String processor = equinoxConfig.getConfiguration("org.osgi.framework.processor");
/*  861 */     processor = (processor == null) ? null : processor.toLowerCase();
/*  862 */     String osVersion = equinoxConfig.getConfiguration("org.osgi.framework.os.version");
/*  863 */     osVersion = (osVersion == null) ? null : osVersion.toLowerCase();
/*  864 */     String language = equinoxConfig.getConfiguration("org.osgi.framework.language");
/*  865 */     language = (language == null) ? null : language.toLowerCase();
/*      */     
/*  867 */     result.append(", ");
/*  868 */     result.append("osgi.native").append("; ");
/*  869 */     if (osName != null) {
/*  870 */       osName = getAliasList(equinoxConfig.getAliasMapper().getOSNameAliases(osName));
/*  871 */       result.append("osgi.native.osname").append(":List<String>=").append(osName).append("; ");
/*      */     } 
/*  873 */     if (processor != null) {
/*  874 */       processor = getAliasList(equinoxConfig.getAliasMapper().getProcessorAliases(processor));
/*  875 */       result.append("osgi.native.processor").append(":List<String>=").append(processor).append("; ");
/*      */     } 
/*  877 */     result.append("osgi.native.osversion").append(":Version").append("=\"").append(osVersion).append("\"; ");
/*  878 */     result.append("osgi.native.language").append("=\"").append(language).append('"');
/*  879 */     return result.toString();
/*      */   }
/*      */   
/*      */   String getAliasList(Collection<String> aliases) {
/*  883 */     if (aliases.isEmpty()) {
/*  884 */       return null;
/*      */     }
/*  886 */     StringBuilder builder = new StringBuilder();
/*  887 */     builder.append('"');
/*  888 */     for (String alias : aliases) {
/*  889 */       builder.append(alias).append(',');
/*      */     }
/*  891 */     builder.setLength(builder.length() - 1);
/*  892 */     builder.append('"');
/*  893 */     return builder.toString();
/*      */   }
/*      */   
/*      */   private String getSystemExtraPackages() {
/*  897 */     EquinoxConfiguration equinoxConfig = this.equinoxContainer.getConfiguration();
/*  898 */     StringBuilder result = new StringBuilder();
/*      */     
/*  900 */     String systemPackages = equinoxConfig.getConfiguration("org.osgi.framework.system.packages");
/*  901 */     if (systemPackages != null) {
/*  902 */       result.append(systemPackages);
/*      */     }
/*      */     
/*  905 */     String extraSystemPackages = equinoxConfig.getConfiguration("org.osgi.framework.system.packages.extra");
/*  906 */     if (extraSystemPackages != null && extraSystemPackages.trim().length() > 0) {
/*  907 */       if (result.length() > 0) {
/*  908 */         result.append(", ");
/*      */       }
/*  910 */       result.append(extraSystemPackages);
/*      */     } 
/*      */     
/*  913 */     return result.toString();
/*      */   }
/*      */   private void refresh(Module module) throws BundleException {
/*      */     URLConnection contentConn;
/*  917 */     ModuleRevision current = module.getCurrentRevision();
/*  918 */     BundleInfo.Generation currentGen = (BundleInfo.Generation)current.getRevisionInfo();
/*  919 */     File content = currentGen.getContent();
/*  920 */     if (content == null) {
/*      */       return;
/*      */     }
/*      */     
/*  924 */     String spec = String.valueOf((currentGen.getContentType() == ContentProvider.Type.REFERENCE) ? "reference:" : "") + content.toURI().toString();
/*      */     
/*      */     try {
/*  927 */       contentConn = getContentConnection(spec);
/*  928 */     } catch (IOException e) {
/*  929 */       throw new BundleException("Error reading bundle content.", e);
/*      */     } 
/*  931 */     update(module, contentConn);
/*      */   }
/*      */   
/*      */   public BundleInfo.Generation update(Module module, InputStream updateIn) throws BundleException {
/*  935 */     return update(module, getContentConnection(module, null, updateIn));
/*      */   }
/*      */   
/*      */   private BundleInfo.Generation update(Module module, URLConnection content) throws BundleException {
/*      */     InputStream in;
/*  940 */     if (this.osgiLocation.isReadOnly()) {
/*  941 */       throw new BundleException("The framework storage area is read only.", 2);
/*      */     }
/*  943 */     URL sourceURL = content.getURL();
/*      */     
/*      */     try {
/*  946 */       in = content.getInputStream();
/*  947 */     } catch (Throwable e) {
/*  948 */       throw new BundleException("Error reading bundle content.", e);
/*      */     } 
/*      */     
/*  951 */     ContentProvider contentProvider = getContentProvider(in, sourceURL);
/*  952 */     ContentProvider.Type contentType = contentProvider.getType();
/*  953 */     File staged = contentProvider.getContent();
/*      */     
/*  955 */     ModuleRevision current = module.getCurrentRevision();
/*  956 */     BundleInfo.Generation currentGen = (BundleInfo.Generation)current.getRevisionInfo();
/*      */     
/*  958 */     BundleInfo bundleInfo = currentGen.getBundleInfo();
/*  959 */     BundleInfo.Generation newGen = bundleInfo.createGeneration();
/*      */     
/*      */     try {
/*  962 */       File contentFile = getContentFile(staged, contentType, bundleInfo.getBundleId(), newGen.getGenerationId());
/*  963 */       newGen.setContent(contentFile, contentType);
/*      */       
/*  965 */       newGen.getBundleFile().open();
/*  966 */       setStorageHooks(newGen);
/*      */       
/*  968 */       ModuleRevisionBuilder builder = getBuilder(newGen);
/*  969 */       this.moduleContainer.update(module, builder, newGen);
/*  970 */     } catch (Throwable t) {
/*  971 */       if (contentType == ContentProvider.Type.DEFAULT) {
/*      */         try {
/*  973 */           delete(staged);
/*  974 */         } catch (IOException iOException) {}
/*      */       }
/*      */ 
/*      */       
/*  978 */       newGen.delete();
/*  979 */       if (t instanceof SecurityException) {
/*      */ 
/*      */         
/*  982 */         if (t.getCause() instanceof BundleException) {
/*  983 */           throw (BundleException)t.getCause();
/*      */         }
/*  985 */         throw (SecurityException)t;
/*      */       } 
/*  987 */       if (t instanceof BundleException) {
/*  988 */         throw (BundleException)t;
/*      */       }
/*  990 */       throw new BundleException("Error occurred updating a bundle.", t);
/*      */     } finally {
/*  992 */       bundleInfo.unlockGeneration(newGen);
/*      */     } 
/*  994 */     return newGen;
/*      */   }
/*      */   
/*      */   private File getContentFile(File staged, ContentProvider.Type contentType, long bundleID, long generationID) throws BundleException {
/*  998 */     if (System.getSecurityManager() == null)
/*  999 */       return getContentFile0(staged, contentType, bundleID, generationID); 
/*      */     try {
/* 1001 */       return AccessController.<File>doPrivileged(() -> getContentFile0(paramFile, paramType, paramLong1, paramLong2));
/* 1002 */     } catch (PrivilegedActionException e) {
/* 1003 */       if (e.getException() instanceof BundleException)
/* 1004 */         throw (BundleException)e.getException(); 
/* 1005 */       throw (RuntimeException)e.getException();
/*      */     } 
/*      */   }
/*      */   
/*      */   File getContentFile0(File staged, ContentProvider.Type contentType, long bundleID, long generationID) throws BundleException {
/* 1010 */     File contentFile = staged;
/*      */     
/* 1012 */     if (contentType == ContentProvider.Type.DEFAULT) {
/* 1013 */       File generationRoot = new File(this.childRoot, String.valueOf(bundleID) + "/" + generationID);
/* 1014 */       generationRoot.mkdirs();
/* 1015 */       if (!generationRoot.isDirectory()) {
/* 1016 */         throw new BundleException("Could not create generation directory: " + generationRoot.getAbsolutePath());
/*      */       }
/* 1018 */       contentFile = new File(generationRoot, "bundleFile");
/*      */       try {
/* 1020 */         StorageUtil.move(staged, contentFile, (getConfiguration().getDebug()).DEBUG_STORAGE);
/* 1021 */       } catch (IOException e) {
/* 1022 */         throw new BundleException("Error while renaming bundle file to final location: " + contentFile, 
/* 1023 */             11, e);
/*      */       } 
/*      */     } 
/* 1026 */     return contentFile;
/*      */   }
/*      */   
/*      */   private static String getBundleFilePath(long bundleID, long generationID) {
/* 1030 */     return String.valueOf(bundleID) + "/" + generationID + "/" + "bundleFile";
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public File getFile(String path, boolean checkParent) throws StorageException {
/* 1045 */     return getFile((String)null, path, checkParent);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public File getFile(String base, String path, boolean checkParent) throws StorageException {
/* 1064 */     File childPath = getFile(this.childRoot, base, path);
/*      */     
/* 1066 */     if (checkParent && this.parentRoot != null) {
/* 1067 */       if (childPath.exists()) {
/* 1068 */         return childPath;
/*      */       }
/* 1070 */       File parentPath = getFile(this.parentRoot, base, path);
/* 1071 */       if (parentPath.exists())
/*      */       {
/* 1073 */         return parentPath;
/*      */       }
/*      */     } 
/*      */     
/* 1077 */     return childPath;
/*      */   }
/*      */   
/*      */   private static File getFile(File root, String base, String path) {
/* 1081 */     if (base == null)
/*      */     {
/* 1083 */       return new File(root, path);
/*      */     }
/*      */ 
/*      */     
/* 1087 */     File rootBase = new File(root, base);
/* 1088 */     File result = new File(rootBase, path);
/* 1089 */     if (path.contains("..")) {
/*      */       
/* 1091 */       Path resultNormalized = result.toPath().normalize();
/* 1092 */       Path rootBaseNormalized = rootBase.toPath().normalize();
/* 1093 */       if (!resultNormalized.startsWith(rootBaseNormalized)) {
/* 1094 */         throw new StorageException("Invalid path: " + path);
/*      */       }
/*      */     } 
/*      */     
/* 1098 */     if (StorageUtil.isReservedFileName(result)) {
/* 1099 */       throw new StorageException("Invalid filename: " + path);
/*      */     }
/* 1101 */     return result;
/*      */   }
/*      */   
/*      */   File stageContent(InputStream in, URL sourceURL) throws BundleException {
/* 1105 */     if (System.getSecurityManager() == null)
/* 1106 */       return stageContent0(in, sourceURL); 
/*      */     try {
/* 1108 */       return AccessController.<File>doPrivileged(() -> stageContent0(paramInputStream, paramURL));
/* 1109 */     } catch (PrivilegedActionException e) {
/* 1110 */       if (e.getException() instanceof BundleException)
/* 1111 */         throw (BundleException)e.getException(); 
/* 1112 */       throw (RuntimeException)e.getException();
/*      */     } 
/*      */   }
/*      */   
/*      */   File stageContent0(InputStream in, URL sourceURL) throws BundleException {
/* 1117 */     File outFile = null; 
/* 1118 */     try { Exception exception1 = null, exception2 = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       try {  }
/*      */       finally
/* 1134 */       { exception2 = null; if (exception1 == null) { exception1 = exception2; } else if (exception1 != exception2) { exception1.addSuppressed(exception2); }  }  } catch (IOException e)
/* 1135 */     { if (outFile != null) {
/* 1136 */         outFile.delete();
/*      */       }
/* 1138 */       throw new BundleException(Msg.BUNDLE_READ_EXCEPTION, 11, e); }
/*      */   
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setPermissions(File file) {
/* 1147 */     String commandProp = getConfiguration().getConfiguration("osgi.filepermissions.command");
/* 1148 */     if (commandProp == null)
/* 1149 */       commandProp = getConfiguration().getConfiguration("org.osgi.framework.command.execpermission"); 
/* 1150 */     if (commandProp == null)
/*      */       return; 
/* 1152 */     String[] commandComponents = ManifestElement.getArrayFromList(commandProp, " ");
/* 1153 */     List<String> command = new ArrayList<>(commandComponents.length + 1);
/* 1154 */     boolean foundFullPath = false; byte b; int i; String[] arrayOfString1;
/* 1155 */     for (i = (arrayOfString1 = commandComponents).length, b = 0; b < i; ) { String commandComponent = arrayOfString1[b];
/* 1156 */       if ("[fullpath]".equals(commandComponent) || "${abspath}".equals(commandComponent)) {
/* 1157 */         command.add(file.getAbsolutePath());
/* 1158 */         foundFullPath = true;
/*      */       } else {
/* 1160 */         command.add(commandComponent);
/*      */       }  b++; }
/*      */     
/* 1163 */     if (!foundFullPath)
/* 1164 */       command.add(file.getAbsolutePath()); 
/*      */     try {
/* 1166 */       Runtime.getRuntime().exec(command.<String>toArray(new String[command.size()])).waitFor();
/* 1167 */     } catch (Exception e) {
/* 1168 */       e.printStackTrace();
/*      */     } 
/*      */   }
/*      */   public BundleFile createBundleFile(File content, BundleInfo.Generation generation, boolean isDirectory, boolean isBase) {
/*      */     ZipBundleFile zipBundleFile;
/* 1173 */     BundleFile result = null;
/* 1174 */     ConnectModule connectModule = null;
/* 1175 */     if (generation.getContentType() == ContentProvider.Type.CONNECT) {
/* 1176 */       connectModule = this.equinoxContainer.getConnectModules().getConnectModule(generation.getBundleInfo().getLocation());
/*      */     }
/*      */     try {
/* 1179 */       if (connectModule != null && isBase) {
/* 1180 */         ConnectBundleFile connectBundleFile = this.equinoxContainer.getConnectModules().getConnectBundleFile(connectModule, content, generation, 
/* 1181 */             this.mruList, getConfiguration().getDebug());
/* 1182 */       } else if (isDirectory) {
/* 1183 */         boolean strictPath = Boolean.parseBoolean(getConfiguration().getConfiguration(
/* 1184 */               "osgi.strictBundleEntryPath", Boolean.FALSE.toString()));
/* 1185 */         DirBundleFile dirBundleFile = new DirBundleFile(content, strictPath);
/*      */       } else {
/* 1187 */         zipBundleFile = new ZipBundleFile(content, generation, this.mruList, getConfiguration().getDebug(), 
/* 1188 */             (getConfiguration()).runtimeVerifySignedBundles);
/*      */       } 
/* 1190 */     } catch (IOException e) {
/* 1191 */       throw new RuntimeException("Could not create bundle file.", e);
/*      */     } 
/* 1193 */     return wrapBundleFile((BundleFile)zipBundleFile, generation, isBase);
/*      */   }
/*      */   
/*      */   public BundleFile createNestedBundleFile(String nestedDir, BundleFile bundleFile, BundleInfo.Generation generation) {
/* 1197 */     return createNestedBundleFile(nestedDir, bundleFile, generation, Collections.emptyList());
/*      */   }
/*      */ 
/*      */   
/*      */   public BundleFile createNestedBundleFile(String nestedDir, BundleFile bundleFile, BundleInfo.Generation generation, Collection<String> filterPrefixes) {
/* 1202 */     return wrapBundleFile((BundleFile)new NestedDirBundleFile(bundleFile, nestedDir, filterPrefixes), generation, false);
/*      */   }
/*      */   
/*      */   public BundleFile wrapBundleFile(BundleFile bundleFile, BundleInfo.Generation generation, boolean isBase) {
/*      */     BundleFileWrapperChain bundleFileWrapperChain1;
/* 1207 */     List<BundleFileWrapperFactoryHook> wrapperFactories = getConfiguration().getHookRegistry().getBundleFileWrapperFactoryHooks();
/* 1208 */     BundleFileWrapperChain wrapped = wrapperFactories.isEmpty() ? null : new BundleFileWrapperChain(bundleFile, null);
/* 1209 */     for (BundleFileWrapperFactoryHook wrapperFactory : wrapperFactories) {
/* 1210 */       BundleFileWrapper wrapperBundle = wrapperFactory.wrapBundleFile(bundleFile, generation, isBase);
/* 1211 */       if (wrapperBundle != null && wrapperBundle != bundleFile) {
/* 1212 */         bundleFileWrapperChain1 = wrapped = new BundleFileWrapperChain((BundleFile)wrapperBundle, wrapped);
/*      */       }
/*      */     } 
/* 1215 */     return (BundleFile)bundleFileWrapperChain1;
/*      */   }
/*      */   
/*      */   public void compact() {
/* 1219 */     if (!this.osgiLocation.isReadOnly()) {
/* 1220 */       compact(this.childRoot);
/*      */     }
/*      */   }
/*      */   
/*      */   private void compact(File directory) {
/* 1225 */     if ((getConfiguration().getDebug()).DEBUG_STORAGE)
/* 1226 */       Debug.println("compact(" + directory.getPath() + ")"); 
/* 1227 */     String[] list = directory.list();
/* 1228 */     if (list == null) {
/*      */       return;
/*      */     }
/* 1231 */     int len = list.length;
/* 1232 */     for (int i = 0; i < len; i++) {
/* 1233 */       if (!"data".equals(list[i])) {
/*      */         
/* 1235 */         File target = new File(directory, list[i]);
/*      */         
/* 1237 */         if (target.isDirectory()) {
/*      */           
/* 1239 */           File delete = new File(target, ".delete");
/*      */           
/* 1241 */           if (delete.exists()) {
/*      */             try {
/* 1243 */               deleteFlaggedDirectory(target);
/* 1244 */             } catch (IOException e) {
/* 1245 */               if ((getConfiguration().getDebug()).DEBUG_STORAGE) {
/* 1246 */                 Debug.println("Unable to write " + delete.getPath() + ": " + e.getMessage());
/*      */               }
/*      */             } 
/*      */           } else {
/* 1250 */             compact(target);
/*      */           } 
/*      */         } 
/*      */       } 
/*      */     } 
/*      */   } void delete(File delete) throws IOException {
/* 1256 */     if (System.getSecurityManager() == null) {
/* 1257 */       deleteFlaggedDirectory(delete);
/*      */     } else {
/*      */       try {
/* 1260 */         AccessController.doPrivileged(() -> {
/*      */               deleteFlaggedDirectory(paramFile);
/*      */               return null;
/*      */             });
/* 1264 */       } catch (PrivilegedActionException e) {
/* 1265 */         if (e.getException() instanceof IOException)
/* 1266 */           throw (IOException)e.getException(); 
/* 1267 */         throw (RuntimeException)e.getException();
/*      */       } 
/*      */     } 
/*      */   }
/*      */   
/*      */   private void deleteFlaggedDirectory(File delete) throws IOException {
/* 1273 */     if (!StorageUtil.rm(delete, (getConfiguration().getDebug()).DEBUG_STORAGE)) {
/* 1274 */       ensureDeleteFlagFileExists(delete.toPath());
/*      */     }
/*      */   }
/*      */   
/*      */   public void save() throws IOException {
/* 1279 */     if (isReadOnly()) {
/*      */       return;
/*      */     }
/* 1282 */     if (System.getSecurityManager() == null) {
/* 1283 */       save0();
/*      */     } else {
/*      */       try {
/* 1286 */         AccessController.doPrivileged(() -> {
/*      */               save0();
/*      */               return null;
/*      */             });
/* 1290 */       } catch (PrivilegedActionException e) {
/* 1291 */         if (e.getException() instanceof IOException)
/* 1292 */           throw (IOException)e.getException(); 
/* 1293 */         throw (RuntimeException)e.getException();
/*      */       } 
/*      */     } 
/*      */   }
/*      */   
/*      */   void save0() throws IOException {
/* 1299 */     StorageManager childStorageManager = null;
/* 1300 */     ManagedOutputStream mos = null;
/* 1301 */     DataOutputStream out = null;
/* 1302 */     boolean success = false;
/* 1303 */     this.moduleDatabase.readLock();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     try {  }
/*      */     finally
/* 1318 */     { if (!success && 
/* 1319 */         mos != null) {
/* 1320 */         mos.abort();
/*      */       }
/*      */       
/* 1323 */       if (out != null) {
/*      */         try {
/* 1325 */           out.close();
/* 1326 */         } catch (IOException iOException) {}
/*      */       }
/*      */ 
/*      */       
/* 1330 */       if (childStorageManager != null) {
/* 1331 */         childStorageManager.close();
/*      */       }
/* 1333 */       this.moduleDatabase.readUnlock(); }  if (!success && mos != null) mos.abort();  if (out != null) try { out.close(); } catch (IOException iOException) {}  if (childStorageManager != null) childStorageManager.close();  this.moduleDatabase.readUnlock();
/*      */   }
/*      */ 
/*      */   
/*      */   private void savePermissionData(DataOutputStream out) throws IOException {
/* 1338 */     this.permissionData.savePermissionData(out);
/*      */   }
/*      */   
/*      */   private void saveGenerations(DataOutputStream out) throws IOException {
/* 1342 */     List<Module> modules = this.moduleContainer.getModules();
/* 1343 */     List<BundleInfo.Generation> generations = new ArrayList<>();
/* 1344 */     for (Module module : modules) {
/* 1345 */       ModuleRevision revision = module.getCurrentRevision();
/* 1346 */       if (revision != null) {
/* 1347 */         BundleInfo.Generation generation = (BundleInfo.Generation)revision.getRevisionInfo();
/* 1348 */         if (generation != null) {
/* 1349 */           generations.add(generation);
/*      */         }
/*      */       } 
/*      */     } 
/* 1353 */     out.writeInt(6);
/*      */     
/* 1355 */     out.writeUTF(this.runtimeVersion.toString());
/*      */     
/* 1357 */     Version curFrameworkVersion = findFrameworkVersion();
/* 1358 */     out.writeUTF((curFrameworkVersion == null) ? Version.emptyVersion.toString() : curFrameworkVersion.toString());
/*      */     
/* 1360 */     saveLongString(out, getSystemExtraCapabilities());
/* 1361 */     saveLongString(out, getSystemExtraPackages());
/*      */     
/* 1363 */     out.writeInt(this.cachedHeaderKeys.size());
/* 1364 */     for (String headerKey : this.cachedHeaderKeys) {
/* 1365 */       out.writeUTF(headerKey);
/*      */     }
/*      */     
/* 1368 */     out.writeInt(generations.size());
/* 1369 */     for (BundleInfo.Generation generation : generations) {
/* 1370 */       BundleInfo bundleInfo = generation.getBundleInfo();
/* 1371 */       out.writeLong(bundleInfo.getBundleId());
/* 1372 */       out.writeUTF(bundleInfo.getLocation());
/* 1373 */       out.writeLong(bundleInfo.getNextGenerationId());
/* 1374 */       out.writeLong(generation.getGenerationId());
/* 1375 */       out.writeBoolean(generation.isDirectory());
/* 1376 */       ContentProvider.Type contentType = generation.getContentType();
/* 1377 */       out.writeInt(contentType.ordinal());
/* 1378 */       out.writeBoolean(generation.hasPackageInfo());
/* 1379 */       if (bundleInfo.getBundleId() == 0L || contentType == ContentProvider.Type.CONNECT) {
/*      */         
/* 1381 */         out.writeUTF("");
/*      */       }
/* 1383 */       else if (contentType == ContentProvider.Type.REFERENCE) {
/*      */         
/* 1385 */         out.writeUTF((new FilePath(this.installPath)).makeRelative(new FilePath(generation.getContent().getAbsolutePath())));
/*      */       } else {
/*      */         
/* 1388 */         out.writeUTF(getBundleFilePath(bundleInfo.getBundleId(), generation.getGenerationId()));
/*      */       } 
/*      */       
/* 1391 */       out.writeLong(generation.getLastModified());
/*      */       
/* 1393 */       Dictionary<String, String> headers = generation.getHeaders();
/* 1394 */       for (String headerKey : this.cachedHeaderKeys) {
/* 1395 */         String value = headers.get(headerKey);
/* 1396 */         if (value != null) {
/* 1397 */           out.writeUTF(value); continue;
/*      */         } 
/* 1399 */         out.writeUTF(NUL);
/*      */       } 
/*      */ 
/*      */       
/* 1403 */       out.writeBoolean(generation.isMRJar());
/*      */     } 
/*      */     
/* 1406 */     saveStorageHookData(out, generations);
/*      */   }
/*      */   
/*      */   private void saveLongString(DataOutputStream out, String value) throws IOException {
/* 1410 */     if (value == null) {
/* 1411 */       out.writeInt(0);
/*      */     } else {
/*      */       
/* 1414 */       byte[] data = value.getBytes(StandardCharsets.UTF_8);
/* 1415 */       out.writeInt(data.length);
/* 1416 */       out.write(data);
/*      */     } 
/*      */   }
/*      */   
/*      */   private String readLongString(DataInputStream in) throws IOException {
/* 1421 */     int length = in.readInt();
/* 1422 */     byte[] data = new byte[length];
/* 1423 */     in.readFully(data);
/* 1424 */     return new String(data, StandardCharsets.UTF_8);
/*      */   }
/*      */   
/*      */   private void saveStorageHookData(DataOutputStream out, List<BundleInfo.Generation> generations) throws IOException {
/* 1428 */     List<StorageHookFactory<?, ?, ?>> factories = getConfiguration().getHookRegistry().getStorageHookFactories();
/* 1429 */     out.writeInt(factories.size());
/* 1430 */     for (StorageHookFactory<?, ?, ?> factory : factories) {
/* 1431 */       out.writeUTF(factory.getKey());
/* 1432 */       out.writeInt(factory.getStorageVersion());
/*      */ 
/*      */       
/* 1435 */       ByteArrayOutputStream tempBytes = new ByteArrayOutputStream();
/* 1436 */       Exception exception1 = null, exception2 = null; try { DataOutputStream temp = new DataOutputStream(tempBytes); 
/* 1437 */         try { Object saveContext = factory.createSaveContext();
/* 1438 */           for (BundleInfo.Generation generation : generations) {
/* 1439 */             if (generation.getBundleInfo().getBundleId() == 0L) {
/*      */               continue;
/*      */             }
/*      */             
/* 1443 */             StorageHookFactory.StorageHook<Object, Object> hook = generation.getStorageHook((Class)factory.getClass());
/* 1444 */             if (hook != null)
/* 1445 */               hook.save(saveContext, temp); 
/*      */           }  }
/*      */         finally
/* 1448 */         { if (temp != null) temp.close();  }  } finally { exception2 = null; if (exception1 == null) { exception1 = exception2; } else if (exception1 != exception2) { exception1.addSuppressed(exception2); }
/*      */          }
/*      */     
/*      */     } 
/*      */   }
/*      */   
/*      */   private Map<Long, BundleInfo.Generation> loadGenerations(DataInputStream in, String[] cachedInfo) throws IOException {
/* 1455 */     if (in == null) {
/* 1456 */       return new HashMap<>(0);
/*      */     }
/* 1458 */     int version = in.readInt();
/* 1459 */     if (version > 6 || version < 3) {
/* 1460 */       throw new IllegalArgumentException("Found persistent version \"" + version + "\" expecting \"" + '\006' + "\"");
/*      */     }
/* 1462 */     Version savedRuntimeVersion = (version >= 4) ? Version.parseVersion(in.readUTF()) : null;
/* 1463 */     if (savedRuntimeVersion == null || !savedRuntimeVersion.equals(this.runtimeVersion)) {
/* 1464 */       this.refreshMRBundles.set(true);
/*      */     }
/*      */     
/* 1467 */     cachedInfo[0] = (version >= 5) ? in.readUTF() : null;
/* 1468 */     cachedInfo[1] = (version >= 5) ? readLongString(in) : null;
/* 1469 */     cachedInfo[2] = (version >= 5) ? readLongString(in) : null;
/*      */     
/* 1471 */     int numCachedHeaders = in.readInt();
/* 1472 */     List<String> storedCachedHeaderKeys = new ArrayList<>(numCachedHeaders);
/* 1473 */     for (int i = 0; i < numCachedHeaders; i++) {
/* 1474 */       storedCachedHeaderKeys.add((String)ObjectPool.intern(in.readUTF()));
/*      */     }
/*      */     
/* 1477 */     int numInfos = in.readInt();
/* 1478 */     Map<Long, BundleInfo.Generation> result = new HashMap<>(numInfos);
/* 1479 */     List<BundleInfo.Generation> generations = new ArrayList<>(numInfos);
/* 1480 */     ContentProvider.Type[] contentTypes = ContentProvider.Type.values();
/* 1481 */     for (int j = 0; j < numInfos; j++) {
/* 1482 */       long infoId = in.readLong();
/* 1483 */       String infoLocation = (String)ObjectPool.intern(in.readUTF());
/* 1484 */       long nextGenId = in.readLong();
/* 1485 */       long generationId = in.readLong();
/* 1486 */       boolean isDirectory = in.readBoolean();
/*      */       
/* 1488 */       ContentProvider.Type contentType = ContentProvider.Type.DEFAULT;
/* 1489 */       if (version >= 6) {
/* 1490 */         contentType = contentTypes[in.readInt()];
/*      */       }
/* 1492 */       else if (in.readBoolean()) {
/* 1493 */         contentType = ContentProvider.Type.REFERENCE;
/*      */       } 
/*      */ 
/*      */       
/* 1497 */       boolean hasPackageInfo = in.readBoolean();
/* 1498 */       String contentPath = in.readUTF();
/* 1499 */       long lastModified = in.readLong();
/*      */       
/* 1501 */       Map<String, String> cachedHeaders = new HashMap<>(storedCachedHeaderKeys.size());
/* 1502 */       for (String headerKey : storedCachedHeaderKeys) {
/* 1503 */         String value = in.readUTF();
/* 1504 */         if (NUL.equals(value)) {
/* 1505 */           value = null;
/*      */         } else {
/* 1507 */           value = (String)ObjectPool.intern(value);
/*      */         } 
/* 1509 */         cachedHeaders.put(headerKey, value);
/*      */       } 
/* 1511 */       boolean isMRJar = (version >= 4) ? in.readBoolean() : false;
/*      */       
/* 1513 */       File content = null;
/* 1514 */       if (contentType != ContentProvider.Type.CONNECT) {
/* 1515 */         if (infoId == 0L) {
/* 1516 */           content = getSystemContent();
/* 1517 */           isDirectory = (content != null) ? content.isDirectory() : false;
/*      */         
/*      */         }
/*      */         else {
/*      */           
/* 1522 */           content = new File(contentPath);
/* 1523 */           if (!content.isAbsolute())
/*      */           {
/* 1525 */             switch (contentType) {
/*      */               
/*      */               case REFERENCE:
/* 1528 */                 content = new File(this.installPath, contentPath);
/*      */                 break;
/*      */               
/*      */               case DEFAULT:
/* 1532 */                 content = getFile(contentPath, true);
/*      */                 break;
/*      */               default:
/* 1535 */                 throw new IllegalArgumentException("Unknown type: " + contentType);
/*      */             } 
/*      */           }
/*      */         } 
/*      */       }
/* 1540 */       BundleInfo info = new BundleInfo(this, infoId, infoLocation, nextGenId);
/* 1541 */       BundleInfo.Generation generation = info.restoreGeneration(generationId, content, isDirectory, contentType, hasPackageInfo, cachedHeaders, lastModified, isMRJar);
/* 1542 */       result.put(Long.valueOf(infoId), generation);
/* 1543 */       generations.add(generation);
/*      */     } 
/*      */     
/* 1546 */     connectPersistentBundles(generations);
/* 1547 */     loadStorageHookData(generations, in);
/* 1548 */     return result;
/*      */   }
/*      */   
/*      */   private void connectPersistentBundles(List<BundleInfo.Generation> generations) {
/* 1552 */     generations.forEach(g -> {
/*      */           try {
/*      */             if (g.getContentType() == ContentProvider.Type.CONNECT) {
/*      */               this.equinoxContainer.getConnectModules().connect(g.getBundleInfo().getLocation());
/*      */             }
/* 1557 */           } catch (IllegalStateException e) {
/*      */             if (!(e.getCause() instanceof BundleException)) {
/*      */               throw e;
/*      */             }
/*      */           } 
/*      */         });
/*      */   }
/*      */   
/*      */   private void loadStorageHookData(List<BundleInfo.Generation> generations, DataInputStream in) throws IOException {
/* 1566 */     List<StorageHookFactory<?, ?, ?>> factories = new ArrayList<>(getConfiguration().getHookRegistry().getStorageHookFactories());
/* 1567 */     Map<BundleInfo.Generation, List<StorageHookFactory.StorageHook<?, ?>>> hookMap = new HashMap<>();
/* 1568 */     int numFactories = in.readInt();
/* 1569 */     for (int i = 0; i < numFactories; i++) {
/* 1570 */       String factoryName = in.readUTF();
/* 1571 */       int version = in.readInt();
/* 1572 */       StorageHookFactory<Object, Object, StorageHookFactory.StorageHook<Object, Object>> factory = null;
/* 1573 */       for (Iterator<StorageHookFactory<?, ?, ?>> iFactories = factories.iterator(); iFactories.hasNext(); ) {
/*      */         
/* 1575 */         StorageHookFactory<Object, Object, StorageHookFactory.StorageHook<Object, Object>> next = (StorageHookFactory<Object, Object, StorageHookFactory.StorageHook<Object, Object>>)iFactories.next();
/* 1576 */         if (next.getKey().equals(factoryName)) {
/* 1577 */           factory = next;
/* 1578 */           iFactories.remove();
/*      */           break;
/*      */         } 
/*      */       } 
/* 1582 */       int dataSize = in.readInt();
/* 1583 */       byte[] bytes = new byte[dataSize];
/* 1584 */       in.readFully(bytes);
/* 1585 */       if (factory != null) {
/* 1586 */         try { Exception exception2, exception1 = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */            }
/*      */         
/* 1612 */         catch (BundleException e)
/* 1613 */         { throw new IOException(e); }
/*      */       
/*      */       }
/*      */     } 
/*      */     
/* 1618 */     for (StorageHookFactory<?, ?, ?> storageHookFactory : factories) {
/*      */       
/* 1620 */       StorageHookFactory<?, ?, ?> storageHookFactory1 = storageHookFactory;
/*      */       
/* 1622 */       for (BundleInfo.Generation generation : generations) {
/* 1623 */         if (generation.getBundleInfo().getBundleId() == 0L) {
/*      */           continue;
/*      */         }
/* 1626 */         StorageHookFactory.StorageHook<Object, Object> hook = storageHookFactory1.createStorageHookAndValidateFactoryClass(generation);
/* 1627 */         if (hook != null) {
/*      */           try {
/* 1629 */             hook.initialize(generation.getHeaders());
/* 1630 */             getHooks(hookMap, generation).add(hook);
/* 1631 */           } catch (BundleException e) {
/* 1632 */             throw new IOException(e);
/*      */           } 
/*      */         }
/*      */       } 
/*      */     } 
/*      */     
/* 1638 */     for (BundleInfo.Generation generation : generations) {
/* 1639 */       generation.setStorageHooks(Collections.unmodifiableList(getHooks(hookMap, generation)), false);
/*      */     }
/*      */   }
/*      */   
/*      */   private static List<StorageHookFactory.StorageHook<?, ?>> getHooks(Map<BundleInfo.Generation, List<StorageHookFactory.StorageHook<?, ?>>> hookMap, BundleInfo.Generation generation) {
/* 1644 */     List<StorageHookFactory.StorageHook<?, ?>> result = hookMap.get(generation);
/* 1645 */     if (result == null) {
/* 1646 */       result = new ArrayList<>();
/* 1647 */       hookMap.put(generation, result);
/*      */     } 
/* 1649 */     return result;
/*      */   }
/*      */   
/*      */   private File getSystemContent() {
/* 1653 */     String frameworkValue = this.equinoxContainer.getConfiguration().getConfiguration("osgi.framework");
/* 1654 */     if (frameworkValue == null || !frameworkValue.startsWith("file:")) {
/* 1655 */       return null;
/*      */     }
/*      */     
/* 1658 */     File result = (new File(frameworkValue.substring(5))).getAbsoluteFile();
/* 1659 */     if (!result.exists()) {
/* 1660 */       throw new IllegalStateException("Configured framework location does not exist: " + result.getAbsolutePath());
/*      */     }
/* 1662 */     return result;
/*      */   }
/*      */ 
/*      */   
/*      */   private void loadVMProfile(BundleInfo.Generation systemGeneration) {
/* 1667 */     EquinoxConfiguration equinoxConfig = this.equinoxContainer.getConfiguration();
/* 1668 */     Properties profileProps = findVMProfile(systemGeneration);
/* 1669 */     String systemExports = equinoxConfig.getConfiguration("org.osgi.framework.system.packages");
/*      */     
/* 1671 */     if (systemExports == null) {
/* 1672 */       systemExports = profileProps.getProperty("org.osgi.framework.system.packages");
/* 1673 */       if (systemExports != null) {
/* 1674 */         equinoxConfig.setConfiguration("org.osgi.framework.system.packages", systemExports);
/*      */       }
/*      */     } 
/*      */     
/* 1678 */     String type = equinoxConfig.getConfiguration("osgi.java.profile.bootdelegation");
/* 1679 */     String profileBootDelegation = profileProps.getProperty("org.osgi.framework.bootdelegation");
/* 1680 */     if ("override".equals(type)) {
/* 1681 */       if (profileBootDelegation == null)
/* 1682 */       { equinoxConfig.clearConfiguration("org.osgi.framework.bootdelegation"); }
/*      */       else
/* 1684 */       { equinoxConfig.setConfiguration("org.osgi.framework.bootdelegation", profileBootDelegation); } 
/* 1685 */     } else if ("none".equals(type)) {
/* 1686 */       equinoxConfig.clearConfiguration("org.osgi.framework.bootdelegation");
/*      */     } 
/* 1688 */     if (equinoxConfig.getConfiguration("org.osgi.framework.executionenvironment") == null) {
/*      */       
/* 1690 */       String ee = profileProps.getProperty("org.osgi.framework.executionenvironment", profileProps.getProperty("osgi.java.profile.name"));
/* 1691 */       if (ee != null) {
/* 1692 */         equinoxConfig.setConfiguration("org.osgi.framework.executionenvironment", ee);
/*      */       }
/*      */     } 
/* 1695 */     if (equinoxConfig.getConfiguration("org.osgi.framework.system.capabilities") == null) {
/* 1696 */       String systemCapabilities = profileProps.getProperty("org.osgi.framework.system.capabilities");
/* 1697 */       if (systemCapabilities != null)
/* 1698 */         equinoxConfig.setConfiguration("org.osgi.framework.system.capabilities", systemCapabilities); 
/*      */     } 
/*      */   }
/*      */   
/*      */   private Properties findVMProfile(BundleInfo.Generation systemGeneration) {
/* 1703 */     Properties result = readConfiguredJavaProfile(systemGeneration);
/* 1704 */     String vmProfile = null;
/*      */     
/* 1706 */     try { if (result != null) {
/* 1707 */         return result;
/*      */       }
/*      */       
/* 1710 */       if (Version.valueOf("9").compareTo(this.runtimeVersion) <= 0) {
/* 1711 */         result = calculateVMProfile(this.runtimeVersion);
/* 1712 */         if (result != null) {
/* 1713 */           return result;
/*      */         }
/*      */       } 
/*      */ 
/*      */       
/* 1718 */       String embeddedProfileName = "-";
/*      */       
/* 1720 */       if (this.runtimeVersion != null && Version.valueOf("1.8").compareTo(this.runtimeVersion) <= 0) {
/* 1721 */         String javaHome = System.getProperty("java.home");
/* 1722 */         if (javaHome != null) {
/* 1723 */           File release = new File(javaHome, "release");
/* 1724 */           if (release.exists()) {
/* 1725 */             Properties releaseProps = new Properties(); try {
/* 1726 */               Exception exception2, exception1 = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*      */             }
/* 1734 */             catch (IOException iOException) {}
/*      */           } 
/*      */         } 
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/* 1741 */       result = new Properties();
/* 1742 */       vmProfile = "JavaSE" + embeddedProfileName + this.javaSpecVersion;
/* 1743 */       InputStream profileIn = null;
/* 1744 */       if (vmProfile != null) {
/*      */         
/* 1746 */         String javaProfile = String.valueOf(vmProfile) + ".profile";
/* 1747 */         profileIn = findInSystemBundle(systemGeneration, javaProfile);
/* 1748 */         if (profileIn == null)
/* 1749 */           profileIn = getNextBestProfile(systemGeneration, "JavaSE", this.runtimeVersion, embeddedProfileName); 
/*      */       } 
/* 1751 */       if (profileIn == null)
/*      */       {
/* 1753 */         profileIn = findInSystemBundle(systemGeneration, "JavaSE-1.8.profile");
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       }
/*      */ 
/*      */ 
/*      */       
/*      */        }
/*      */     
/*      */     finally
/*      */     
/*      */     { 
/*      */ 
/*      */       
/* 1769 */       if (result != null && result.getProperty("osgi.java.profile.name") == null)
/* 1770 */         if (vmProfile != null)
/* 1771 */         { result.put("osgi.java.profile.name", vmProfile.replace('_', '/')); }
/*      */         else
/*      */         
/* 1774 */         { result.put("osgi.java.profile.name", "JavaSE-1.7"); }   }  if (result != null && result.getProperty("osgi.java.profile.name") == null) if (vmProfile != null) { result.put("osgi.java.profile.name", vmProfile.replace('_', '/')); } else { result.put("osgi.java.profile.name", "JavaSE-1.7"); }
/*      */     
/*      */ 
/*      */     
/* 1778 */     return result;
/*      */   }
/*      */ 
/*      */   
/*      */   private Properties readConfiguredJavaProfile(BundleInfo.Generation systemGeneration) {
/* 1783 */     String propJavaProfile = this.equinoxContainer.getConfiguration().getConfiguration("osgi.java.profile");
/* 1784 */     if (propJavaProfile != null) {
/* 1785 */       InputStream profileIn = null;
/*      */       
/*      */       try {
/* 1788 */         profileIn = (new URL(propJavaProfile)).openStream();
/* 1789 */       } catch (IOException iOException) {
/*      */         
/* 1791 */         profileIn = findInSystemBundle(systemGeneration, propJavaProfile);
/*      */       } 
/* 1793 */       if (profileIn != null) {
/* 1794 */         Properties result = new Properties();
/*      */         
/* 1796 */         try { result.load(new BufferedInputStream(profileIn)); }
/* 1797 */         catch (IOException iOException)
/*      */         
/*      */         { 
/*      */           try {
/* 1801 */             profileIn.close();
/* 1802 */           } catch (IOException iOException1) {} } finally { try { profileIn.close(); } catch (IOException iOException) {} }
/*      */ 
/*      */ 
/*      */         
/* 1806 */         return result;
/*      */       } 
/*      */     } 
/* 1809 */     return null;
/*      */   }
/*      */ 
/*      */   
/*      */   private Properties calculateVMProfile(Version javaVersion) {
/* 1814 */     String systemPackages = calculateVMPackages();
/* 1815 */     if (systemPackages == null) {
/* 1816 */       return null;
/*      */     }
/* 1818 */     String executionEnvs = calculateVMExecutionEnvs(javaVersion);
/* 1819 */     String eeCapabilities = calculateEECapabilities(javaVersion);
/*      */     
/* 1821 */     Properties result = new Properties();
/* 1822 */     result.put("org.osgi.framework.system.packages", systemPackages);
/* 1823 */     result.put("org.osgi.framework.executionenvironment", executionEnvs);
/* 1824 */     result.put("org.osgi.framework.system.capabilities", eeCapabilities);
/* 1825 */     return result;
/*      */   }
/*      */   
/*      */   private String calculateVMExecutionEnvs(Version javaVersion) {
/* 1829 */     StringBuilder result = new StringBuilder("OSGi/Minimum-1.0, OSGi/Minimum-1.1, OSGi/Minimum-1.2, JavaSE/compact1-1.8, JavaSE/compact2-1.8, JavaSE/compact3-1.8, JRE-1.1, J2SE-1.2, J2SE-1.3, J2SE-1.4, J2SE-1.5, JavaSE-1.6, JavaSE-1.7, JavaSE-1.8");
/* 1830 */     Version v = new Version(9, 0, 0);
/* 1831 */     while (v.compareTo(javaVersion) <= 0) {
/* 1832 */       result.append(',').append(' ').append("JavaSE").append('-').append(v.getMajor());
/* 1833 */       if (v.getMinor() > 0) {
/* 1834 */         result.append('.').append(v.getMinor());
/*      */       }
/* 1836 */       if (v.getMajor() == javaVersion.getMajor()) {
/* 1837 */         v = new Version(v.getMajor(), v.getMinor() + 1, 0); continue;
/*      */       } 
/* 1839 */       v = new Version(v.getMajor() + 1, 0, 0);
/*      */     } 
/*      */     
/* 1842 */     return result.toString();
/*      */   }
/*      */   
/*      */   private String calculateEECapabilities(Version javaVersion) {
/* 1846 */     Version v = new Version(9, 0, 0);
/* 1847 */     StringBuilder versionsBulder = new StringBuilder();
/* 1848 */     while (v.compareTo(javaVersion) <= 0) {
/* 1849 */       versionsBulder.append(',').append(' ').append(v.getMajor()).append('.').append(v.getMinor());
/* 1850 */       if (v.getMajor() == javaVersion.getMajor()) {
/* 1851 */         v = new Version(v.getMajor(), v.getMinor() + 1, 0); continue;
/*      */       } 
/* 1853 */       v = new Version(v.getMajor() + 1, 0, 0);
/*      */     } 
/*      */     
/* 1856 */     String versionsList = versionsBulder.toString();
/*      */     
/* 1858 */     StringBuilder result = new StringBuilder("osgi.ee; osgi.ee=\"OSGi/Minimum\"; version:List<Version>=\"1.0, 1.1, 1.2\", osgi.ee; osgi.ee=\"JRE\"; version:List<Version>=\"1.0, 1.1\", osgi.ee; osgi.ee=\"JavaSE\"; version:List<Version>=\"1.0, 1.1, 1.2, 1.3, 1.4, 1.5, 1.6, 1.7, 1.8");
/* 1859 */     result.append(versionsList).append("\"");
/* 1860 */     result.append(",osgi.ee; osgi.ee=\"JavaSE/compact1\"; version:List<Version>=\"1.8");
/* 1861 */     result.append(versionsList).append("\"");
/* 1862 */     result.append(",osgi.ee; osgi.ee=\"JavaSE/compact2\"; version:List<Version>=\"1.8");
/* 1863 */     result.append(versionsList).append("\"");
/* 1864 */     result.append(",osgi.ee; osgi.ee=\"JavaSE/compact3\"; version:List<Version>=\"1.8");
/* 1865 */     result.append(versionsList).append("\"");
/*      */     
/* 1867 */     return result.toString();
/*      */   }
/*      */ 
/*      */   
/*      */   private String calculateVMPackages() {
/*      */     try {
/* 1873 */       List<String> packages = new ArrayList<>();
/* 1874 */       Method classGetModule = Class.class.getMethod("getModule", new Class[0]);
/* 1875 */       Object thisModule = classGetModule.invoke(getClass(), new Object[0]);
/* 1876 */       Class<?> moduleLayerClass = Class.forName("java.lang.ModuleLayer");
/* 1877 */       Method boot = moduleLayerClass.getMethod("boot", new Class[0]);
/* 1878 */       Method modules = moduleLayerClass.getMethod("modules", new Class[0]);
/* 1879 */       Class<?> moduleClass = Class.forName("java.lang.Module");
/* 1880 */       Method getDescriptor = moduleClass.getMethod("getDescriptor", new Class[0]);
/* 1881 */       Class<?> moduleDescriptorClass = Class.forName("java.lang.module.ModuleDescriptor");
/* 1882 */       Method exports = moduleDescriptorClass.getMethod("exports", new Class[0]);
/* 1883 */       Method isAutomatic = moduleDescriptorClass.getMethod("isAutomatic", new Class[0]);
/* 1884 */       Method packagesMethod = moduleDescriptorClass.getMethod("packages", new Class[0]);
/* 1885 */       Class<?> exportsClass = Class.forName("java.lang.module.ModuleDescriptor$Exports");
/* 1886 */       Method isQualified = exportsClass.getMethod("isQualified", new Class[0]);
/* 1887 */       Method source = exportsClass.getMethod("source", new Class[0]);
/*      */       
/* 1889 */       Object bootLayer = boot.invoke(null, new Object[0]);
/* 1890 */       Set<?> bootModules = (Set)modules.invoke(bootLayer, new Object[0]);
/* 1891 */       for (Object m : bootModules) {
/* 1892 */         if (m.equals(thisModule)) {
/*      */           continue;
/*      */         }
/*      */ 
/*      */ 
/*      */         
/* 1898 */         Object descriptor = getDescriptor.invoke(m, new Object[0]);
/* 1899 */         if (((Boolean)isAutomatic.invoke(descriptor, new Object[0])).booleanValue()) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 1906 */           packages.addAll((Set)packagesMethod.invoke(descriptor, new Object[0])); continue;
/*      */         } 
/* 1908 */         for (Object export : exports.invoke(descriptor, new Object[0])) {
/* 1909 */           String pkg = (String)source.invoke(export, new Object[0]);
/* 1910 */           if (!((Boolean)isQualified.invoke(export, new Object[0])).booleanValue()) {
/* 1911 */             packages.add(pkg);
/*      */           }
/*      */         } 
/*      */       } 
/*      */       
/* 1916 */       Collections.sort(packages);
/* 1917 */       StringBuilder result = new StringBuilder();
/* 1918 */       for (String pkg : packages) {
/* 1919 */         if (result.length() != 0) {
/* 1920 */           result.append(',').append(' ');
/*      */         }
/* 1922 */         result.append(pkg);
/*      */       } 
/* 1924 */       return result.toString();
/* 1925 */     } catch (Exception e) {
/* 1926 */       this.equinoxContainer.getLogServices().log("org.eclipse.osgi", 4, "Error determining system packages.", e);
/* 1927 */       return null;
/*      */     } 
/*      */   }
/*      */   
/*      */   private InputStream getNextBestProfile(BundleInfo.Generation systemGeneration, String javaEdition, Version javaVersion, String embeddedProfileName) {
/* 1932 */     if (javaVersion == null || javaEdition != "JavaSE")
/* 1933 */       return null; 
/* 1934 */     InputStream bestProfile = findNextBestProfile(systemGeneration, javaEdition, javaVersion, embeddedProfileName);
/* 1935 */     if (bestProfile == null && !"-".equals(embeddedProfileName))
/*      */     {
/* 1937 */       return getNextBestProfile(systemGeneration, javaEdition, javaVersion, "-");
/*      */     }
/* 1939 */     return bestProfile;
/*      */   }
/*      */   
/*      */   private InputStream findNextBestProfile(BundleInfo.Generation systemGeneration, String javaEdition, Version javaVersion, String embeddedProfileName) {
/* 1943 */     InputStream result = null;
/* 1944 */     int major = javaVersion.getMajor();
/* 1945 */     int minor = javaVersion.getMinor();
/*      */     
/*      */     do {
/* 1948 */       String profileResourceName = String.valueOf(javaEdition) + embeddedProfileName + major + ((minor > 0) ? ("." + minor) : "") + ".profile";
/* 1949 */       result = findInSystemBundle(systemGeneration, profileResourceName);
/* 1950 */       if (minor > 0) {
/* 1951 */         minor--;
/* 1952 */       } else if (major > 9) {
/* 1953 */         major--;
/* 1954 */       } else if (major <= 9 && major > 1) {
/* 1955 */         minor = 8;
/* 1956 */         major = 1;
/*      */       } else {
/*      */         
/* 1959 */         return result;
/*      */       } 
/* 1961 */     } while (result == null && minor >= 0);
/* 1962 */     return result;
/*      */   }
/*      */   
/*      */   private InputStream findInSystemBundle(BundleInfo.Generation systemGeneration, String entry) {
/* 1966 */     BundleFile systemContent = systemGeneration.getBundleFile();
/* 1967 */     BundleEntry systemEntry = (systemContent != null) ? systemContent.getEntry(entry) : null;
/* 1968 */     InputStream result = null;
/* 1969 */     if (systemEntry != null) {
/*      */       try {
/* 1971 */         result = systemEntry.getInputStream();
/* 1972 */       } catch (IOException iOException) {}
/*      */     }
/*      */ 
/*      */     
/* 1976 */     if (result == null) {
/*      */       
/* 1978 */       ClassLoader loader = getClass().getClassLoader();
/* 1979 */       result = (loader == null) ? ClassLoader.getSystemResourceAsStream(entry) : loader.getResourceAsStream(entry);
/*      */     } 
/* 1981 */     return result;
/*      */   }
/*      */   
/*      */   public static Enumeration<URL> findEntries(List<BundleInfo.Generation> generations, String path, String filePattern, int options) {
/* 1985 */     List<BundleFile> bundleFiles = new ArrayList<>(generations.size());
/* 1986 */     for (BundleInfo.Generation generation : generations) {
/* 1987 */       bundleFiles.add(generation.getBundleFile());
/*      */     }
/* 1989 */     List<String> pathList = listEntryPaths(bundleFiles, path, filePattern, options);
/*      */     
/* 1991 */     if (pathList.size() == 0) {
/* 1992 */       return null;
/*      */     }
/* 1994 */     Stream<URL> entries = pathList.stream().flatMap(p -> paramList.stream().map(()))
/* 1995 */       .filter(Objects::nonNull);
/* 1996 */     return InternalUtils.asEnumeration(entries.iterator());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static List<String> listEntryPaths(List<BundleFile> bundleFiles, String path, String filePattern, int options) {
/*      */     FilterImpl filterImpl;
/* 2014 */     LinkedHashSet<String> pathList = new LinkedHashSet<>();
/* 2015 */     Filter patternFilter = null;
/* 2016 */     Hashtable<String, String> patternProps = null;
/* 2017 */     if (filePattern != null) {
/*      */ 
/*      */       
/* 2020 */       if ((options & 0x1) == 0 && filePattern.indexOf('*') == -1 && filePattern.indexOf('\\') == -1) {
/* 2021 */         if (path.length() == 0) {
/* 2022 */           path = filePattern;
/*      */         } else {
/* 2024 */           path = String.valueOf(path) + ((path.charAt(path.length() - 1) == '/') ? filePattern : (String.valueOf('/') + filePattern));
/* 2025 */         }  for (BundleFile bundleFile : bundleFiles) {
/* 2026 */           if (bundleFile.getEntry(path) != null && !pathList.contains(path))
/* 2027 */             pathList.add(path); 
/*      */         } 
/* 2029 */         return new ArrayList<>(pathList);
/*      */       } 
/*      */ 
/*      */       
/*      */       try {
/* 2034 */         filterImpl = FilterImpl.newInstance("(filename=" + sanitizeFilterInput(filePattern) + ")");
/*      */         
/* 2036 */         patternProps = new Hashtable<>(2);
/* 2037 */       } catch (InvalidSyntaxException invalidSyntaxException) {
/*      */ 
/*      */ 
/*      */         
/* 2041 */         return new ArrayList<>(pathList);
/*      */       } 
/*      */     } 
/*      */     
/* 2045 */     for (BundleFile bundleFile : bundleFiles) {
/* 2046 */       listEntryPaths(bundleFile, path, (Filter)filterImpl, patternProps, options, pathList);
/*      */     }
/* 2048 */     return new ArrayList<>(pathList);
/*      */   }
/*      */   
/*      */   public static String sanitizeFilterInput(String filePattern) throws InvalidSyntaxException {
/* 2052 */     StringBuilder buffer = null;
/* 2053 */     boolean foundEscape = false;
/* 2054 */     for (int i = 0; i < filePattern.length(); i++) {
/* 2055 */       char c = filePattern.charAt(i);
/* 2056 */       switch (c) {
/*      */         
/*      */         case '\\':
/* 2059 */           foundEscape = !foundEscape;
/* 2060 */           if (buffer != null)
/* 2061 */             buffer.append(c); 
/*      */           break;
/*      */         case '(':
/*      */         case ')':
/* 2065 */           if (!foundEscape) {
/* 2066 */             if (buffer == null) {
/* 2067 */               buffer = new StringBuilder(filePattern.length() + 16);
/* 2068 */               buffer.append(filePattern.substring(0, i));
/*      */             } 
/*      */             
/* 2071 */             buffer.append('\\');
/*      */           } else {
/* 2073 */             foundEscape = false;
/*      */           } 
/* 2075 */           if (buffer != null) {
/* 2076 */             buffer.append(c);
/*      */           }
/*      */           break;
/*      */         default:
/* 2080 */           foundEscape = false;
/* 2081 */           if (buffer != null)
/* 2082 */             buffer.append(c); 
/*      */           break;
/*      */       } 
/*      */     } 
/* 2086 */     if (foundEscape)
/* 2087 */       throw new InvalidSyntaxException("Trailing escape characters must be escaped.", filePattern); 
/* 2088 */     return (buffer == null) ? filePattern : buffer.toString();
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private static LinkedHashSet<String> listEntryPaths(BundleFile bundleFile, String path, Filter patternFilter, Hashtable<String, String> patternProps, int options, LinkedHashSet<String> pathList) {
/* 2094 */     if (pathList == null)
/* 2095 */       pathList = new LinkedHashSet<>(); 
/* 2096 */     boolean recurse = ((options & 0x1) != 0);
/* 2097 */     Enumeration<String> entryPaths = bundleFile.getEntryPaths(path, recurse);
/* 2098 */     if (entryPaths == null)
/* 2099 */       return pathList; 
/* 2100 */     while (entryPaths.hasMoreElements()) {
/* 2101 */       String entry = entryPaths.nextElement();
/* 2102 */       int lastSlash = entry.lastIndexOf('/');
/* 2103 */       if (patternProps != null) {
/* 2104 */         int fileStart, secondToLastSlash = entry.lastIndexOf('/', lastSlash - 1);
/*      */         
/* 2106 */         int fileEnd = entry.length();
/* 2107 */         if (lastSlash < 0) {
/* 2108 */           fileStart = 0;
/* 2109 */         } else if (lastSlash != entry.length() - 1) {
/* 2110 */           fileStart = lastSlash + 1;
/*      */         } else {
/* 2112 */           fileEnd = lastSlash;
/* 2113 */           if (secondToLastSlash < 0) {
/* 2114 */             fileStart = 0;
/*      */           } else {
/* 2116 */             fileStart = secondToLastSlash + 1;
/*      */           } 
/* 2118 */         }  String fileName = entry.substring(fileStart, fileEnd);
/*      */         
/* 2120 */         patternProps.put("filename", fileName);
/*      */       } 
/*      */       
/* 2123 */       if (!pathList.contains(entry) && (patternFilter == null || patternFilter.matchCase(patternProps)))
/* 2124 */         pathList.add(entry); 
/*      */     } 
/* 2126 */     return pathList;
/*      */   }
/*      */   
/*      */   public String copyToTempLibrary(BundleInfo.Generation generation, String absolutePath) {
/* 2130 */     File libTempDir = new File(this.childRoot, "libtemp");
/*      */     
/* 2132 */     File realLib = new File(absolutePath);
/* 2133 */     String libName = realLib.getName();
/*      */     
/* 2135 */     File bundleTempDir = null;
/* 2136 */     File libTempFile = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2145 */     Long bundleID = Long.valueOf(generation.getBundleInfo().getBundleId());
/* 2146 */     for (int i = 0; i < Integer.MAX_VALUE; ) {
/* 2147 */       bundleTempDir = new File(libTempDir, String.valueOf(bundleID.toString()) + "_" + Integer.valueOf(i).toString());
/* 2148 */       libTempFile = new File(bundleTempDir, libName);
/* 2149 */       if (bundleTempDir.exists() && 
/* 2150 */         libTempFile.exists()) {
/*      */         i++;
/*      */         continue;
/*      */       } 
/*      */       break;
/*      */     } 
/* 2156 */     if (!bundleTempDir.isDirectory()) {
/* 2157 */       bundleTempDir.mkdirs();
/* 2158 */       bundleTempDir.deleteOnExit();
/*      */ 
/*      */       
/*      */       try {
/* 2162 */         ensureDeleteFlagFileExists(libTempDir.toPath());
/* 2163 */       } catch (IOException iOException) {}
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*      */     try {
/* 2169 */       StorageUtil.copy(realLib, libTempFile);
/*      */       
/* 2171 */       setPermissions(libTempFile);
/* 2172 */       libTempFile.deleteOnExit();
/*      */       
/* 2174 */       return libTempFile.getAbsolutePath();
/* 2175 */     } catch (IOException e) {
/* 2176 */       this.equinoxContainer.getLogServices().log("org.eclipse.osgi", 4, e.getMessage(), e);
/* 2177 */       return null;
/*      */     } 
/*      */   }
/*      */   
/*      */   private static void ensureDeleteFlagFileExists(Path directory) throws IOException {
/* 2182 */     Path deleteFlag = directory.resolve(".delete");
/* 2183 */     if (!Files.exists(deleteFlag, new java.nio.file.LinkOption[0])) {
/* 2184 */       Files.createFile(deleteFlag, (FileAttribute<?>[])new FileAttribute[0]);
/*      */     }
/*      */   }
/*      */   
/*      */   public SecurityAdmin getSecurityAdmin() {
/* 2189 */     return this.securityAdmin;
/*      */   }
/*      */   
/*      */   protected StorageManager getChildStorageManager() throws IOException {
/* 2193 */     String locking = getConfiguration().getConfiguration("osgi.locking", "java.nio");
/* 2194 */     StorageManager sManager = new StorageManager(this.childRoot, isReadOnly() ? "none" : locking, isReadOnly());
/*      */     try {
/* 2196 */       sManager.open(!isReadOnly());
/* 2197 */     } catch (IOException ex) {
/* 2198 */       if ((getConfiguration().getDebug()).DEBUG_STORAGE) {
/* 2199 */         Debug.println("Error reading framework.info: " + ex.getMessage());
/* 2200 */         Debug.printStackTrace(ex);
/*      */       } 
/* 2202 */       String message = NLS.bind(Msg.ECLIPSE_STARTUP_FILEMANAGER_OPEN_ERROR, ex.getMessage());
/* 2203 */       this.equinoxContainer.getLogServices().log("org.eclipse.osgi", 4, message, ex);
/* 2204 */       getConfiguration().setProperty("eclipse.exitcode", "15");
/* 2205 */       String errorDialog = "<title>" + Msg.ADAPTOR_STORAGE_INIT_FAILED_TITLE + "</title>" + NLS.bind(Msg.ADAPTOR_STORAGE_INIT_FAILED_MSG, this.childRoot) + "\n" + ex.getMessage();
/* 2206 */       getConfiguration().setProperty("eclipse.exitdata", errorDialog);
/* 2207 */       throw ex;
/*      */     } 
/* 2209 */     return sManager;
/*      */   }
/*      */   
/*      */   private InputStream getInfoInputStream() throws IOException {
/* 2213 */     StorageManager storageManager = getChildStorageManager();
/* 2214 */     InputStream storageStream = null;
/*      */     try {
/* 2216 */       storageStream = storageManager.getInputStream("framework.info");
/* 2217 */     } catch (IOException ex) {
/* 2218 */       if ((getConfiguration().getDebug()).DEBUG_STORAGE) {
/* 2219 */         Debug.println("Error reading framework.info: " + ex.getMessage());
/* 2220 */         Debug.printStackTrace(ex);
/*      */       } 
/*      */     } finally {
/* 2223 */       storageManager.close();
/*      */     } 
/* 2225 */     if (storageStream == null && this.parentRoot != null) {
/* 2226 */       StorageManager parentStorageManager = null;
/*      */       try {
/* 2228 */         parentStorageManager = new StorageManager(this.parentRoot, "none", true);
/* 2229 */         parentStorageManager.open(false);
/* 2230 */         storageStream = parentStorageManager.getInputStream("framework.info");
/* 2231 */       } catch (IOException iOException) {
/*      */       
/*      */       } finally {
/* 2234 */         if (parentStorageManager != null) {
/* 2235 */           parentStorageManager.close();
/*      */         }
/*      */       } 
/*      */     } 
/* 2239 */     return storageStream;
/*      */   }
/*      */   
/*      */   EquinoxContainer getEquinoxContainer() {
/* 2243 */     return this.equinoxContainer;
/*      */   }
/*      */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.osgi-3.18.400.jar!\org\eclipse\osgi\storage\Storage.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */