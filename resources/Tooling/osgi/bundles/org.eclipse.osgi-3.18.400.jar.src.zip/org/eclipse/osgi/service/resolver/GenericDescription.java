package org.eclipse.osgi.service.resolver;

import java.util.Dictionary;
import org.osgi.framework.Version;

public interface GenericDescription extends BaseDescription {
  public static final String DEFAULT_TYPE = "generic";
  
  Dictionary<String, Object> getAttributes();
  
  String getType();
  
  String getName();
  
  Version getVersion();
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.osgi-3.18.400.jar!\org\eclipse\osgi\service\resolver\GenericDescription.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */