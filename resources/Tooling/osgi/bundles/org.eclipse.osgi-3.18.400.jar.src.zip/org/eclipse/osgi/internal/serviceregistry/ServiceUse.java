/*     */ package org.eclipse.osgi.internal.serviceregistry;
/*     */ 
/*     */ import java.lang.management.ManagementFactory;
/*     */ import java.lang.management.ThreadInfo;
/*     */ import java.lang.management.ThreadMXBean;
/*     */ import java.util.concurrent.ConcurrentMap;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ import java.util.concurrent.locks.ReentrantLock;
/*     */ import org.eclipse.osgi.internal.debug.Debug;
/*     */ import org.eclipse.osgi.internal.framework.BundleContextImpl;
/*     */ import org.eclipse.osgi.internal.messages.Msg;
/*     */ import org.eclipse.osgi.util.NLS;
/*     */ import org.osgi.framework.ServiceException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ServiceUse<S>
/*     */ {
/*     */   public static final int DEADLOCK = 1001;
/*     */   final BundleContextImpl context;
/*     */   final ServiceRegistrationImpl<S> registration;
/*     */   final Debug debug;
/*     */   private int useCount;
/*  61 */   private final ServiceUseLock lock = new ServiceUseLock();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   ServiceUse(BundleContextImpl context, ServiceRegistrationImpl<S> registration) {
/*  70 */     this.useCount = 0;
/*  71 */     this.registration = registration;
/*  72 */     this.context = context;
/*  73 */     this.debug = context.getContainer().getConfiguration().getDebug();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   S getService() {
/*  83 */     assert getLock().isHeldByCurrentThread();
/*  84 */     if (this.debug.DEBUG_SERVICES) {
/*  85 */       Debug.println("[" + Thread.currentThread().getName() + "] getService[factory=" + this.registration.getBundle() + 
/*  86 */           "](" + this.context.getBundleImpl() + "," + this.registration + ")");
/*     */     }
/*     */     
/*  89 */     incrementUse();
/*  90 */     return this.registration.getServiceObject();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean ungetService() {
/* 103 */     assert getLock().isHeldByCurrentThread();
/* 104 */     if (!inUse()) {
/* 105 */       return false;
/*     */     }
/* 107 */     if (this.debug.DEBUG_SERVICES) {
/* 108 */       Debug.println("[" + Thread.currentThread().getName() + "] ungetService[factory=" + this.registration.getBundle() + 
/* 109 */           "](" + this.context.getBundleImpl() + "," + this.registration + ")");
/*     */     }
/* 111 */     decrementUse();
/* 112 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   S getCachedService() {
/* 122 */     return this.registration.getServiceObject();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   S newServiceObject() {
/* 135 */     return getService();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean releaseServiceObject(S service) {
/* 151 */     if (service == null || service != getCachedService()) {
/* 152 */       throw new IllegalArgumentException(Msg.SERVICE_OBJECTS_UNGET_ARGUMENT_EXCEPTION);
/*     */     }
/* 154 */     if (this.debug.DEBUG_SERVICES) {
/* 155 */       Debug.println("[" + Thread.currentThread().getName() + "] releaseServiceObject[factory=" + 
/* 156 */           this.registration.getBundle() + "](" + this.context.getBundleImpl() + "," + this.registration + ")");
/*     */     }
/* 158 */     return ungetService();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void release() {
/* 166 */     assert getLock().isHeldByCurrentThread();
/* 167 */     resetUse();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean isEmpty() {
/* 177 */     assert getLock().isHeldByCurrentThread();
/* 178 */     return !inUse();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean inUse() {
/* 188 */     return (this.useCount > 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void incrementUse() {
/* 196 */     if (this.useCount == Integer.MAX_VALUE) {
/* 197 */       throw new ServiceException(Msg.SERVICE_USE_OVERFLOW);
/*     */     }
/* 199 */     this.useCount++;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void decrementUse() {
/* 207 */     assert inUse();
/* 208 */     this.useCount--;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void resetUse() {
/* 216 */     this.useCount = 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   ServiceUseLock getLock() {
/* 228 */     return this.lock;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   ServiceUseLock lock() {
/* 243 */     Thread awaitingThread = null;
/* 244 */     boolean interrupted = false;
/*     */     try {
/* 246 */       ServiceUseLock useLock = getLock();
/*     */       while (true) {
/*     */         try {
/* 249 */           if (useLock.tryLock(100000000L, TimeUnit.NANOSECONDS)) {
/* 250 */             return useLock;
/*     */           }
/* 252 */           awaitingThread = Thread.currentThread();
/* 253 */           checkDeadLock(awaitingThread, useLock);
/* 254 */         } catch (InterruptedException interruptedException) {
/* 255 */           interrupted = true;
/*     */         }
/*     */       
/*     */       } 
/*     */     } finally {
/*     */       
/* 261 */       if (awaitingThread != null) {
/* 262 */         this.registration.getAwaitedUseLocks().remove(awaitingThread);
/*     */       }
/* 264 */       if (interrupted) {
/* 265 */         Thread.currentThread().interrupt();
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   private void checkDeadLock(Thread currentThread, ServiceUseLock currentLock) {
/* 271 */     ConcurrentMap<Thread, ServiceUseLock> awaitedUseLocks = this.registration.getAwaitedUseLocks();
/* 272 */     awaitedUseLocks.put(currentThread, currentLock);
/* 273 */     ServiceUseLock useLock = currentLock;
/*     */ 
/*     */ 
/*     */     
/* 277 */     int maxLocks = awaitedUseLocks.size();
/* 278 */     for (int i = 0; i < maxLocks; i++) {
/* 279 */       Thread owner = useLock.getOwner();
/* 280 */       if (owner == currentThread) {
/* 281 */         throw new ServiceException(NLS.bind(Msg.SERVICE_USE_DEADLOCK, currentLock), 1001);
/*     */       }
/* 283 */       if (owner == null || (useLock = awaitedUseLocks.get(owner)) == null) {
/*     */         break;
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static class ServiceUseLock
/*     */     extends ReentrantLock
/*     */     implements AutoCloseable
/*     */   {
/*     */     private static final long serialVersionUID = 1L;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void close() {
/* 318 */       unlock();
/*     */     }
/*     */ 
/*     */     
/*     */     protected Thread getOwner() {
/* 323 */       return super.getOwner();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public String toString() {
/* 335 */       Thread o = getOwner();
/* 336 */       if (o != null) {
/*     */         try {
/* 338 */           ThreadMXBean threadMXBean = ManagementFactory.getThreadMXBean();
/* 339 */           ThreadInfo threadInfo = threadMXBean.getThreadInfo(o.getId(), 2147483647);
/* 340 */           StackTraceElement[] trace = threadInfo.getStackTrace();
/* 341 */           StringBuilder sb = (new StringBuilder(super.toString())).append(", Details:\n");
/* 342 */           if (o.isDaemon()) {
/* 343 */             sb.append("daemon ");
/*     */           }
/* 345 */           sb.append("prio=").append(o.getPriority()).append(" id=").append(o.getId()).append(" ")
/* 346 */             .append(o.getState()); byte b; int i; StackTraceElement[] arrayOfStackTraceElement1;
/* 347 */           for (i = (arrayOfStackTraceElement1 = trace).length, b = 0; b < i; ) { StackTraceElement traceElement = arrayOfStackTraceElement1[b];
/* 348 */             sb.append("\tat ").append(traceElement).append("\n"); b++; }
/*     */           
/* 350 */           return sb.toString();
/* 351 */         } catch (Exception exception) {}
/*     */       }
/*     */ 
/*     */       
/* 355 */       return super.toString();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.osgi-3.18.400.jar!\org\eclipse\osgi\internal\serviceregistry\ServiceUse.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */