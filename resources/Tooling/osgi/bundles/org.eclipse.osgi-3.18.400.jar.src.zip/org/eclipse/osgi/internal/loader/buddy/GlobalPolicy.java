/*    */ package org.eclipse.osgi.internal.loader.buddy;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.net.URL;
/*    */ import java.util.ArrayList;
/*    */ import java.util.Collection;
/*    */ import java.util.Collections;
/*    */ import java.util.Enumeration;
/*    */ import java.util.Map;
/*    */ import org.eclipse.osgi.container.ModuleContainer;
/*    */ import org.eclipse.osgi.container.ModuleWire;
/*    */ import org.eclipse.osgi.container.ModuleWiring;
/*    */ import org.eclipse.osgi.internal.loader.BundleLoader;
/*    */ import org.osgi.framework.wiring.BundleCapability;
/*    */ import org.osgi.framework.wiring.FrameworkWiring;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class GlobalPolicy
/*    */   implements IBuddyPolicy
/*    */ {
/*    */   private FrameworkWiring frameworkWiring;
/*    */   
/*    */   public GlobalPolicy(FrameworkWiring frameworkWiring) {
/* 45 */     this.frameworkWiring = frameworkWiring;
/*    */   }
/*    */ 
/*    */   
/*    */   public Class<?> loadClass(String name) {
/* 50 */     return getExportingBundles(BundleLoader.getPackageName(name))
/* 51 */       .stream().findFirst().map(b -> b.findClassNoParentNoException(paramString)).orElse(null);
/*    */   }
/*    */ 
/*    */   
/*    */   public URL loadResource(String name) {
/* 56 */     return getExportingBundles(BundleLoader.getResourcePackageName(name))
/* 57 */       .stream().findFirst().map(b -> b.findResource(paramString)).orElse(null);
/*    */   }
/*    */ 
/*    */   
/*    */   public Enumeration<URL> loadResources(String name) {
/* 62 */     Enumeration<URL> results = null;
/* 63 */     Collection<BundleLoader> exporters = getExportingBundles(name);
/* 64 */     for (BundleLoader exporter : exporters) {
/*    */       try {
/* 66 */         results = BundleLoader.compoundEnumerations(results, exporter.findResources(name));
/* 67 */       } catch (IOException iOException) {}
/*    */     } 
/*    */ 
/*    */     
/* 71 */     return results;
/*    */   }
/*    */   
/*    */   private Collection<BundleLoader> getExportingBundles(String pkgName) {
/* 75 */     Collection<BundleLoader> result = new ArrayList<>();
/* 76 */     String filter = "(osgi.wiring.package=" + pkgName + ")";
/* 77 */     Map<String, String> directives = Collections.singletonMap("filter", filter);
/* 78 */     Map<String, Boolean> attributes = Collections.singletonMap("org.eclipse.osgi.container.synthetic", Boolean.TRUE);
/* 79 */     Collection<BundleCapability> packages = this.frameworkWiring.findProviders(
/* 80 */         ModuleContainer.createRequirement("osgi.wiring.package", directives, attributes));
/* 81 */     for (BundleCapability pkg : packages) {
/* 82 */       ModuleWiring wiring = (ModuleWiring)pkg.getRevision().getWiring();
/* 83 */       if (wiring != null) {
/* 84 */         if ((pkg.getRevision().getTypes() & 0x1) != 0) {
/*    */           
/* 86 */           if (wiring != null)
/* 87 */             for (ModuleWire hostWire : wiring.getRequiredModuleWires("osgi.wiring.host")) {
/* 88 */               result.add((BundleLoader)hostWire.getProviderWiring().getModuleLoader());
/*    */             } 
/*    */           continue;
/*    */         } 
/* 92 */         result.add((BundleLoader)wiring.getModuleLoader());
/*    */       } 
/*    */     } 
/*    */     
/* 96 */     return result;
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.osgi-3.18.400.jar!\org\eclipse\osgi\internal\loader\buddy\GlobalPolicy.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */