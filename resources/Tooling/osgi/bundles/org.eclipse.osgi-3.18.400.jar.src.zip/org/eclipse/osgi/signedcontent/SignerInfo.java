package org.eclipse.osgi.signedcontent;

import java.security.cert.Certificate;

public interface SignerInfo {
  Certificate[] getCertificateChain();
  
  Certificate getTrustAnchor();
  
  boolean isTrusted();
  
  String getMessageDigestAlgorithm();
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.osgi-3.18.400.jar!\org\eclipse\osgi\signedcontent\SignerInfo.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */