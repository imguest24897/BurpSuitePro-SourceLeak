package org.eclipse.osgi.container.namespaces;

import org.osgi.resource.Namespace;

public class EquinoxFragmentNamespace extends Namespace {
  public static final String FRAGMENT_NAMESPACE = "equinox.fragment";
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.osgi-3.18.400.jar!\org\eclipse\osgi\container\namespaces\EquinoxFragmentNamespace.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */