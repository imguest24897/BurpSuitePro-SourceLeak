/*     */ package org.eclipse.osgi.internal.log;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.osgi.framework.Bundle;
/*     */ import org.osgi.framework.Version;
/*     */ import org.osgi.service.log.admin.LoggerContext;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LoggerContextTargetMap
/*     */ {
/*  28 */   private final Map<Bundle, ExtendedLogServiceImpl> logServices = new HashMap<>();
/*  29 */   private final Map<String, ExtendedLogServiceFactory.EquinoxLoggerContext> loggerContexts = new HashMap<>();
/*  30 */   private final Map<Bundle, List<String>> targetToQualifiedNames = new HashMap<>();
/*  31 */   private final Map<String, Collection<Bundle>> qualifiedNameToTargets = new HashMap<>();
/*     */   
/*     */   List<String> add(Bundle b) {
/*  34 */     String bsn = b.getSymbolicName();
/*  35 */     if (bsn == null) {
/*  36 */       bsn = "";
/*     */     }
/*  38 */     Version v = b.getVersion();
/*  39 */     String version = (v == null) ? "" : v.toString();
/*  40 */     String location = ExtendedLogServiceFactory.secureAction.getLocation(b);
/*     */     
/*  42 */     List<String> result = new ArrayList<>(3);
/*     */     
/*  44 */     StringBuilder sb = new StringBuilder(bsn);
/*  45 */     getTargetsInternal(bsn).add(b);
/*     */     
/*  47 */     sb.append('|').append(version);
/*  48 */     String bsnVersion = sb.toString();
/*  49 */     getTargetsInternal(bsnVersion).add(b);
/*     */     
/*  51 */     sb.append('|').append(location);
/*  52 */     String bsnVersionLocation = sb.toString();
/*  53 */     getTargetsInternal(bsnVersionLocation).add(b);
/*     */     
/*  55 */     result.add(bsnVersionLocation);
/*  56 */     result.add(bsnVersion);
/*  57 */     result.add(bsn);
/*     */     
/*  59 */     List<String> unmodifiable = Collections.unmodifiableList(result);
/*  60 */     this.targetToQualifiedNames.put(b, unmodifiable);
/*  61 */     return unmodifiable;
/*     */   }
/*     */   
/*     */   void remove(Bundle b) {
/*  65 */     List<String> qualifiedNames = this.targetToQualifiedNames.remove(b);
/*  66 */     if (qualifiedNames != null) {
/*  67 */       for (String qualifiedName : qualifiedNames) {
/*  68 */         Collection<Bundle> targets = this.qualifiedNameToTargets.get(qualifiedName);
/*  69 */         if (targets != null) {
/*  70 */           targets.remove(b);
/*  71 */           if (targets.isEmpty()) {
/*  72 */             this.qualifiedNameToTargets.remove(qualifiedName);
/*     */           }
/*     */         } 
/*     */       } 
/*     */     }
/*  77 */     this.logServices.remove(b);
/*     */   }
/*     */   
/*     */   private Collection<Bundle> getTargetsInternal(String pid) {
/*  81 */     Collection<Bundle> targets = this.qualifiedNameToTargets.get(pid);
/*  82 */     if (targets == null) {
/*  83 */       targets = new ArrayList<>(1);
/*  84 */       this.qualifiedNameToTargets.put(pid, targets);
/*     */     } 
/*  86 */     return targets;
/*     */   }
/*     */   
/*     */   ExtendedLogServiceImpl getLogService(Bundle bundle, ExtendedLogServiceFactory factory) {
/*  90 */     ExtendedLogServiceImpl logService = this.logServices.get(bundle);
/*  91 */     if (logService == null) {
/*     */       
/*  93 */       add(bundle);
/*  94 */       logService = new ExtendedLogServiceImpl(factory, bundle);
/*  95 */       if (bundle != null && bundle.getState() != 1)
/*  96 */         this.logServices.put(bundle, logService); 
/*     */     } 
/*  98 */     return logService;
/*     */   }
/*     */   
/*     */   void replaceSystemBundleLogService(Bundle previousBundle, Bundle currentBundle) {
/* 102 */     ExtendedLogServiceImpl existing = this.logServices.get(previousBundle);
/* 103 */     if (existing != null) {
/* 104 */       remove(previousBundle);
/* 105 */       add(currentBundle);
/* 106 */       this.logServices.put(currentBundle, existing);
/* 107 */       existing.applyLogLevels(getEffectiveLoggerContext(currentBundle));
/*     */     } 
/*     */   }
/*     */   
/*     */   void clear() {
/* 112 */     this.logServices.clear();
/* 113 */     this.qualifiedNameToTargets.clear();
/* 114 */     this.targetToQualifiedNames.clear();
/* 115 */     this.loggerContexts.clear();
/*     */   }
/*     */   
/*     */   LoggerContext createLoggerContext(String name, ExtendedLogServiceFactory factory) {
/* 119 */     ExtendedLogServiceFactory.EquinoxLoggerContext loggerContext = this.loggerContexts.get(name);
/* 120 */     if (loggerContext == null) {
/* 121 */       loggerContext = factory.createEquinoxLoggerContext(name);
/* 122 */       this.loggerContexts.put(name, loggerContext);
/*     */     } 
/* 124 */     return loggerContext;
/*     */   }
/*     */   
/*     */   ExtendedLogServiceFactory.EquinoxLoggerContext getRootLoggerContext() {
/* 128 */     return this.loggerContexts.get(null);
/*     */   }
/*     */   
/*     */   void applyLogLevels(ExtendedLogServiceFactory.EquinoxLoggerContext loggerContext) {
/*     */     Collection<Bundle> matching;
/* 133 */     boolean isRoot = (loggerContext.getName() == null);
/* 134 */     if (isRoot) {
/*     */       
/* 136 */       matching = this.logServices.keySet();
/*     */     } else {
/* 138 */       matching = this.qualifiedNameToTargets.get(loggerContext.getName());
/*     */     } 
/* 140 */     if (matching == null) {
/*     */       return;
/*     */     }
/* 143 */     for (Bundle bundle : matching) {
/* 144 */       ExtendedLogServiceImpl logService = this.logServices.get(bundle);
/* 145 */       if (logService != null)
/*     */       {
/*     */ 
/*     */         
/* 149 */         logService.applyLogLevels(getEffectiveLoggerContext(bundle));
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   ExtendedLogServiceFactory.EquinoxLoggerContext getEffectiveLoggerContext(Bundle bundle) {
/* 155 */     List<String> qualifiedNames = this.targetToQualifiedNames.get(bundle);
/* 156 */     if (qualifiedNames != null) {
/* 157 */       for (String qualifiedName : qualifiedNames) {
/* 158 */         ExtendedLogServiceFactory.EquinoxLoggerContext loggerContext = this.loggerContexts.get(qualifiedName);
/* 159 */         if (loggerContext != null && !loggerContext.isEmpty()) {
/* 160 */           return loggerContext;
/*     */         }
/*     */       } 
/*     */     }
/* 164 */     return getRootLoggerContext();
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.osgi-3.18.400.jar!\org\eclipse\osgi\internal\log\LoggerContextTargetMap.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */