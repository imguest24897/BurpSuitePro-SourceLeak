/*     */ package org.eclipse.osgi.internal.hookregistry;
/*     */ 
/*     */ import java.io.DataInputStream;
/*     */ import java.io.DataOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.net.URLConnection;
/*     */ import java.util.Dictionary;
/*     */ import org.eclipse.osgi.container.Module;
/*     */ import org.eclipse.osgi.container.ModuleContainerAdaptor;
/*     */ import org.eclipse.osgi.container.ModuleRevisionBuilder;
/*     */ import org.eclipse.osgi.storage.BundleInfo;
/*     */ import org.osgi.framework.BundleException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class StorageHookFactory<S, L, H extends StorageHookFactory.StorageHook<S, L>>
/*     */ {
/*  41 */   protected final String KEY = getClass().getName().intern();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getStorageVersion() {
/*  51 */     return 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final String getKey() {
/*  59 */     return this.KEY;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isCompatibleWith(int version) {
/*  73 */     return (getStorageVersion() == version);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public S createSaveContext() {
/*  83 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public L createLoadContext(int version) {
/*  95 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected H createStorageHook(BundleInfo.Generation generation) {
/* 104 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final H createStorageHookAndValidateFactoryClass(BundleInfo.Generation generation) {
/* 120 */     H result = createStorageHook(generation);
/* 121 */     if (result == null) {
/* 122 */       return result;
/*     */     }
/* 124 */     Class<?> factoryClass = getClass();
/* 125 */     Class<?> factoryClassOfStorageHook = result.getFactoryClass();
/* 126 */     if (!factoryClass.equals(factoryClassOfStorageHook))
/* 127 */       throw new IllegalStateException(String.format("The factory class '%s' of storage hook '%s' does not match the creating factory class of '%s'", new Object[] { factoryClassOfStorageHook.getName(), result, factoryClass.getName() })); 
/* 128 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public URLConnection handleContentConnection(Module module, String location, InputStream in) throws IOException {
/* 142 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class StorageHook<S, L>
/*     */   {
/*     */     private final Class<? extends StorageHookFactory<S, L, ? extends StorageHook<S, L>>> factoryClass;
/*     */ 
/*     */     
/*     */     private final BundleInfo.Generation generation;
/*     */ 
/*     */ 
/*     */     
/*     */     public StorageHook(BundleInfo.Generation generation, Class<? extends StorageHookFactory<S, L, ? extends StorageHook<S, L>>> factoryClass) {
/* 158 */       this.generation = generation;
/* 159 */       this.factoryClass = factoryClass;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public BundleInfo.Generation getGeneration() {
/* 167 */       return this.generation;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void initialize(Dictionary<String, String> manifest) throws BundleException {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ModuleRevisionBuilder adaptModuleRevisionBuilder(ModuleContainerAdaptor.ModuleEvent operation, Module origin, ModuleRevisionBuilder builder) {
/* 197 */       return null;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void load(L loadContext, DataInputStream is) throws IOException {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void save(S saveContext, DataOutputStream os) throws IOException {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void deletingGeneration() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void validate() throws IllegalStateException {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Class<? extends StorageHookFactory<S, L, ? extends StorageHook<S, L>>> getFactoryClass() {
/* 251 */       return this.factoryClass;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.osgi-3.18.400.jar!\org\eclipse\osgi\internal\hookregistry\StorageHookFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */