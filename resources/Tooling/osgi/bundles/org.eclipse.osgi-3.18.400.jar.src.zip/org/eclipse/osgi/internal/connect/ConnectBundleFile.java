/*     */ package org.eclipse.osgi.internal.connect;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.net.MalformedURLException;
/*     */ import java.net.URL;
/*     */ import java.util.Collections;
/*     */ import java.util.Map;
/*     */ import java.util.Optional;
/*     */ import org.eclipse.osgi.internal.debug.Debug;
/*     */ import org.eclipse.osgi.storage.BundleInfo;
/*     */ import org.eclipse.osgi.storage.bundlefile.BundleEntry;
/*     */ import org.eclipse.osgi.storage.bundlefile.CloseableBundleFile;
/*     */ import org.eclipse.osgi.storage.bundlefile.MRUBundleFileList;
/*     */ import org.osgi.framework.connect.ConnectContent;
/*     */ import org.osgi.framework.connect.ConnectModule;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ConnectBundleFile
/*     */   extends CloseableBundleFile<ConnectContent.ConnectEntry>
/*     */ {
/*     */   private final ConnectContent content;
/*     */   
/*     */   public class ConnectBundleEntry
/*     */     extends BundleEntry
/*     */   {
/*     */     private final ConnectContent.ConnectEntry connectEntry;
/*     */     
/*     */     public ConnectBundleEntry(ConnectContent.ConnectEntry entry) {
/*  38 */       this.connectEntry = entry;
/*     */     }
/*     */ 
/*     */     
/*     */     public InputStream getInputStream() throws IOException {
/*  43 */       return ConnectBundleFile.this.getInputStream(this.connectEntry);
/*     */     }
/*     */ 
/*     */     
/*     */     public byte[] getBytes() throws IOException {
/*  48 */       return this.connectEntry.getBytes();
/*     */     }
/*     */ 
/*     */     
/*     */     public long getSize() {
/*  53 */       return this.connectEntry.getContentLength();
/*     */     }
/*     */ 
/*     */     
/*     */     public String getName() {
/*  58 */       return this.connectEntry.getName();
/*     */     }
/*     */ 
/*     */     
/*     */     public long getTime() {
/*  63 */       return this.connectEntry.getLastModified();
/*     */     }
/*     */ 
/*     */     
/*     */     public URL getFileURL() {
/*  68 */       File file = ConnectBundleFile.this.getFile(getName(), false);
/*  69 */       if (file != null) {
/*     */         try {
/*  71 */           return file.toURI().toURL();
/*  72 */         } catch (MalformedURLException malformedURLException) {}
/*     */       }
/*     */ 
/*     */       
/*  76 */       return null;
/*     */     }
/*     */ 
/*     */     
/*     */     public URL getLocalURL() {
/*  81 */       return ConnectBundleFile.this.getClassLoader().<URL>map(cl -> cl.getResource(getName())).orElse(null);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ConnectBundleFile(ConnectModule module, File basefile, BundleInfo.Generation generation, MRUBundleFileList mruList, Debug debug) throws IOException {
/*  88 */     super(basefile, generation, mruList, debug);
/*  89 */     this.content = module.getContent();
/*     */   }
/*     */ 
/*     */   
/*     */   protected void doOpen() throws IOException {
/*  94 */     this.content.open();
/*     */   }
/*     */ 
/*     */   
/*     */   protected Iterable<String> getPaths() {
/*     */     try {
/* 100 */       return this.content.getEntries();
/* 101 */     } catch (IOException iOException) {
/* 102 */       return Collections.emptyList();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   protected BundleEntry findEntry(String path) {
/* 108 */     if (path.length() > 0 && path.charAt(0) == '/') {
/* 109 */       path = path.substring(1);
/*     */     }
/* 111 */     return this.content.getEntry(path).map( arg0 -> new ConnectBundleEntry( arg0)).orElse(null);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void doClose() throws IOException {
/* 116 */     this.content.close();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void postClose() {}
/*     */ 
/*     */ 
/*     */   
/*     */   protected InputStream doGetInputStream(ConnectContent.ConnectEntry entry) throws IOException {
/* 126 */     return entry.getInputStream();
/*     */   }
/*     */   
/*     */   public Map<String, String> getConnectHeaders() {
/* 130 */     if (!lockOpen()) {
/* 131 */       return null;
/*     */     }
/*     */     try {
/* 134 */       return this.content.getHeaders().orElse(null);
/*     */     } finally {
/* 136 */       releaseOpen();
/*     */     } 
/*     */   }
/*     */   
/*     */   Optional<ClassLoader> getClassLoader() {
/* 141 */     return this.content.getClassLoader();
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 146 */     return this.content.toString();
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.osgi-3.18.400.jar!\org\eclipse\osgi\internal\connect\ConnectBundleFile.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */