/*     */ package org.eclipse.osgi.util;
/*     */ 
/*     */ import java.io.BufferedInputStream;
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.Enumeration;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.StringTokenizer;
/*     */ import org.eclipse.osgi.internal.messages.Msg;
/*     */ import org.eclipse.osgi.internal.util.SupplementDebug;
/*     */ import org.eclipse.osgi.internal.util.Tokenizer;
/*     */ import org.osgi.framework.BundleException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ManifestElement
/*     */ {
/*     */   private final String mainValue;
/*     */   private final String[] valueComponents;
/*     */   private HashMap<String, Object> attributes;
/*     */   private HashMap<String, Object> directives;
/*     */   
/*     */   private ManifestElement(String value, String[] valueComponents) {
/* 116 */     this.mainValue = value;
/* 117 */     this.valueComponents = valueComponents;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getValue() {
/* 134 */     return this.mainValue;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String[] getValueComponents() {
/* 154 */     return this.valueComponents;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getAttribute(String key) {
/* 174 */     return getTableValue(this.attributes, key);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String[] getAttributes(String key) {
/* 186 */     return getTableValues(this.attributes, key);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Enumeration<String> getKeys() {
/* 196 */     return getTableKeys(this.attributes);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void addAttribute(String key, String value) {
/* 206 */     this.attributes = addTableValue(this.attributes, key, value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getDirective(String key) {
/* 225 */     return getTableValue(this.directives, key);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String[] getDirectives(String key) {
/* 237 */     return getTableValues(this.directives, key);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Enumeration<String> getDirectiveKeys() {
/* 247 */     return getTableKeys(this.directives);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void addDirective(String key, String value) {
/* 257 */     this.directives = addTableValue(this.directives, key, value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String getTableValue(HashMap<String, Object> table, String key) {
/* 264 */     if (table == null) {
/* 265 */       return null;
/*     */     }
/* 267 */     Object result = table.get(key);
/* 268 */     if (result == null) {
/* 269 */       return null;
/*     */     }
/* 271 */     if (result instanceof String) {
/* 272 */       return (String)result;
/*     */     }
/*     */     
/* 275 */     List<String> valueList = (List<String>)result;
/*     */     
/* 277 */     return valueList.get(valueList.size() - 1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String[] getTableValues(HashMap<String, Object> table, String key) {
/* 284 */     if (table == null) {
/* 285 */       return null;
/*     */     }
/* 287 */     Object result = table.get(key);
/* 288 */     if (result == null) {
/* 289 */       return null;
/*     */     }
/* 291 */     if (result instanceof String) {
/* 292 */       return new String[] { (String)result };
/*     */     }
/* 294 */     List<String> valueList = (List<String>)result;
/* 295 */     return valueList.<String>toArray(new String[valueList.size()]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Enumeration<String> getTableKeys(HashMap<String, Object> table) {
/* 302 */     if (table == null)
/* 303 */       return null; 
/* 304 */     return Collections.enumeration(table.keySet());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private HashMap<String, Object> addTableValue(HashMap<String, Object> table, String key, String value) {
/* 314 */     if (table == null) {
/* 315 */       table = new HashMap<>(7);
/*     */     }
/* 317 */     Object curValue = table.get(key);
/* 318 */     if (curValue != null) {
/*     */       List<String> newList;
/*     */       
/* 321 */       if (curValue instanceof List) {
/* 322 */         newList = (List<String>)curValue;
/*     */       } else {
/* 324 */         newList = new ArrayList<>(5);
/* 325 */         newList.add((String)curValue);
/*     */       } 
/* 327 */       newList.add(value);
/* 328 */       table.put(key, newList);
/*     */     } else {
/* 330 */       table.put(key, value);
/*     */     } 
/* 332 */     return table;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ManifestElement[] parseHeader(String header, String value) throws BundleException {
/*     */     char c;
/* 348 */     if (value == null)
/* 349 */       return null; 
/* 350 */     List<ManifestElement> headerElements = new ArrayList<>(10);
/* 351 */     Tokenizer tokenizer = new Tokenizer(value);
/*     */     while (true) {
/* 353 */       String next = tokenizer.getString(";,");
/* 354 */       if (next == null)
/* 355 */         throw new BundleException(NLS.bind(Msg.MANIFEST_INVALID_HEADER_EXCEPTION, header, value), 3); 
/* 356 */       List<String> headerValues = new ArrayList<>();
/* 357 */       StringBuilder headerValue = new StringBuilder(next);
/* 358 */       headerValues.add(next);
/*     */       
/* 360 */       if (SupplementDebug.STATIC_DEBUG_MANIFEST)
/* 361 */         System.out.print("parseHeader: " + next); 
/* 362 */       boolean directive = false;
/* 363 */       c = tokenizer.getChar();
/*     */       
/* 365 */       while (c == ';') {
/* 366 */         next = tokenizer.getString(";,=:");
/* 367 */         if (next == null)
/* 368 */           throw new BundleException(NLS.bind(Msg.MANIFEST_INVALID_HEADER_EXCEPTION, header, value), 3); 
/* 369 */         c = tokenizer.getChar();
/* 370 */         while (c == ':') {
/* 371 */           c = tokenizer.getChar();
/* 372 */           if (c != '=') {
/* 373 */             String restOfNext = tokenizer.getToken(";,=:");
/* 374 */             if (restOfNext == null)
/* 375 */               throw new BundleException(NLS.bind(Msg.MANIFEST_INVALID_HEADER_EXCEPTION, header, value), 3); 
/* 376 */             next = String.valueOf(next) + ":" + c + restOfNext;
/* 377 */             c = tokenizer.getChar(); continue;
/*     */           } 
/* 379 */           directive = true;
/*     */         } 
/* 381 */         if (c == ';' || c == ',' || c == '\000') {
/* 382 */           headerValues.add(next);
/* 383 */           headerValue.append(";").append(next);
/* 384 */           if (SupplementDebug.STATIC_DEBUG_MANIFEST) {
/* 385 */             System.out.print(";" + next);
/*     */           }
/*     */         } 
/*     */       } 
/* 389 */       ManifestElement manifestElement = new ManifestElement(headerValue.toString(), headerValues.<String>toArray(new String[headerValues.size()]));
/*     */ 
/*     */       
/* 392 */       while (c == '=' || c == ':') {
/* 393 */         while (c == ':') {
/* 394 */           c = tokenizer.getChar();
/* 395 */           if (c != '=') {
/* 396 */             String restOfNext = tokenizer.getToken("=:");
/* 397 */             if (restOfNext == null)
/* 398 */               throw new BundleException(NLS.bind(Msg.MANIFEST_INVALID_HEADER_EXCEPTION, header, value), 3); 
/* 399 */             next = String.valueOf(next) + ":" + c + restOfNext;
/* 400 */             c = tokenizer.getChar(); continue;
/*     */           } 
/* 402 */           directive = true;
/*     */         } 
/*     */         
/* 405 */         String preserveEscapes = null;
/* 406 */         if (!directive && next.indexOf("List") > 0) {
/* 407 */           Tokenizer listTokenizer = new Tokenizer(next);
/* 408 */           String attrKey = listTokenizer.getToken(":");
/* 409 */           if (attrKey != null && listTokenizer.getChar() == ':' && "List".equals(listTokenizer.getToken("<")))
/*     */           {
/* 411 */             preserveEscapes = "\\,";
/*     */           }
/*     */         } 
/* 414 */         String val = tokenizer.getString(";,", preserveEscapes);
/* 415 */         if (val == null) {
/* 416 */           throw new BundleException(NLS.bind(Msg.MANIFEST_INVALID_HEADER_EXCEPTION, header, value), 3);
/*     */         }
/* 418 */         if (SupplementDebug.STATIC_DEBUG_MANIFEST)
/* 419 */           System.out.print(";" + next + "=" + val); 
/*     */         try {
/* 421 */           if (directive) {
/* 422 */             manifestElement.addDirective(next, val);
/*     */           } else {
/* 424 */             manifestElement.addAttribute(next, val);
/* 425 */           }  directive = false;
/* 426 */         } catch (Exception e) {
/* 427 */           throw new BundleException(NLS.bind(Msg.MANIFEST_INVALID_HEADER_EXCEPTION, header, value), 3, e);
/*     */         } 
/* 429 */         c = tokenizer.getChar();
/* 430 */         if (c == ';') {
/* 431 */           next = tokenizer.getToken("=:");
/* 432 */           if (next == null)
/* 433 */             throw new BundleException(NLS.bind(Msg.MANIFEST_INVALID_HEADER_EXCEPTION, header, value), 3); 
/* 434 */           c = tokenizer.getChar();
/*     */         } 
/*     */       } 
/* 437 */       headerElements.add(manifestElement);
/* 438 */       if (SupplementDebug.STATIC_DEBUG_MANIFEST)
/* 439 */         System.out.println(""); 
/* 440 */       if (c == ',')
/*     */         continue;  break;
/* 442 */     }  if (c == '\000') {
/*     */ 
/*     */ 
/*     */       
/* 446 */       int size = headerElements.size();
/* 447 */       if (size == 0) {
/* 448 */         return null;
/*     */       }
/* 450 */       ManifestElement[] result = headerElements.<ManifestElement>toArray(new ManifestElement[size]);
/* 451 */       return result;
/*     */     } 
/*     */     throw new BundleException(NLS.bind(Msg.MANIFEST_INVALID_HEADER_EXCEPTION, header, value), 3);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String[] getArrayFromList(String stringList) {
/* 461 */     String[] result = getArrayFromList(stringList, ",");
/* 462 */     return (result.length == 0) ? null : result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String[] getArrayFromList(String stringList, String separator) {
/* 476 */     if (stringList == null || stringList.trim().length() == 0)
/* 477 */       return new String[0]; 
/* 478 */     List<String> list = new ArrayList<>();
/* 479 */     StringTokenizer tokens = new StringTokenizer(stringList, separator);
/* 480 */     while (tokens.hasMoreTokens()) {
/* 481 */       String token = tokens.nextToken().trim();
/* 482 */       if (token.length() != 0)
/* 483 */         list.add(token); 
/*     */     } 
/* 485 */     return list.<String>toArray(new String[list.size()]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Map<String, String> parseBundleManifest(InputStream manifest, Map<String, String> headers) throws IOException, BundleException {
/* 504 */     if (headers == null) {
/* 505 */       headers = new HashMap<>();
/*     */     }
/* 507 */     manifest = new BufferedInputStream(manifest);
/*     */     
/*     */     try {
/* 510 */       ByteArrayOutputStream buffer = new ByteArrayOutputStream(256);
/*     */       while (true) {
/* 512 */         String line = readLine(manifest, buffer);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 519 */         if (line == null || line.length() == 0) {
/*     */           break;
/*     */         }
/*     */ 
/*     */         
/* 524 */         int colon = line.indexOf(':');
/* 525 */         if (colon == -1)
/*     */         {
/* 527 */           throw new BundleException(NLS.bind(Msg.MANIFEST_INVALID_LINE_NOCOLON, line), 3);
/*     */         }
/* 529 */         String header = line.substring(0, colon).trim();
/* 530 */         String value = line.substring(colon + 1).trim();
/*     */         
/* 532 */         headers.put(header.intern(), value);
/*     */       } 
/*     */     } finally {
/*     */       try {
/* 536 */         manifest.close();
/* 537 */       } catch (IOException iOException) {}
/*     */     } 
/*     */ 
/*     */     
/* 541 */     return headers;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static String readLine(InputStream input, ByteArrayOutputStream buffer) throws IOException {
/*     */     while (true) {
/* 553 */       int c = input.read();
/* 554 */       if (c == 10) {
/*     */         
/* 556 */         input.mark(1);
/* 557 */         c = input.read();
/* 558 */         if (c != 32) {
/*     */           
/* 560 */           input.reset();
/*     */           
/*     */           break;
/*     */         } 
/* 564 */         c = input.read();
/* 565 */       } else if (c == 13) {
/*     */         
/* 567 */         input.mark(1);
/* 568 */         c = input.read();
/* 569 */         if (c == 10) {
/*     */           
/* 571 */           input.mark(1);
/* 572 */           c = input.read();
/*     */         } 
/* 574 */         if (c != 32) {
/*     */           
/* 576 */           input.reset();
/*     */           break;
/*     */         } 
/* 579 */         c = input.read();
/*     */       } 
/* 581 */       if (c == -1) {
/*     */         break;
/*     */       }
/* 584 */       buffer.write(c);
/*     */     } 
/* 586 */     String result = buffer.toString("UTF8");
/* 587 */     buffer.reset();
/* 588 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 593 */     Enumeration<String> attrKeys = getKeys();
/* 594 */     Enumeration<String> directiveKeys = getDirectiveKeys();
/* 595 */     if (attrKeys == null && directiveKeys == null)
/* 596 */       return this.mainValue; 
/* 597 */     StringBuilder result = new StringBuilder(this.mainValue);
/* 598 */     if (attrKeys != null) {
/* 599 */       while (attrKeys.hasMoreElements()) {
/* 600 */         String key = attrKeys.nextElement();
/* 601 */         addValues(false, key, getAttributes(key), result);
/*     */       } 
/*     */     }
/* 604 */     if (directiveKeys != null) {
/* 605 */       while (directiveKeys.hasMoreElements()) {
/* 606 */         String key = directiveKeys.nextElement();
/* 607 */         addValues(true, key, getDirectives(key), result);
/*     */       } 
/*     */     }
/* 610 */     return result.toString();
/*     */   }
/*     */   
/*     */   private void addValues(boolean directive, String key, String[] values, StringBuilder result) {
/* 614 */     if (values == null)
/*     */       return;  byte b; int i; String[] arrayOfString;
/* 616 */     for (i = (arrayOfString = values).length, b = 0; b < i; ) { String value = arrayOfString[b];
/* 617 */       result.append(';').append(key);
/* 618 */       if (directive)
/* 619 */         result.append(':'); 
/* 620 */       result.append("=\"").append(value).append('"');
/*     */       b++; }
/*     */   
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.osgi-3.18.400.jar!\org\eclipse\osg\\util\ManifestElement.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */