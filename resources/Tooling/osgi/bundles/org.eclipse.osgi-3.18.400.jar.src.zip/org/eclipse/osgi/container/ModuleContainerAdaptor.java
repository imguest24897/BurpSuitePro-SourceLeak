/*     */ package org.eclipse.osgi.container;
/*     */ 
/*     */ import java.util.EnumSet;
/*     */ import java.util.concurrent.Executor;
/*     */ import java.util.concurrent.ScheduledExecutorService;
/*     */ import org.eclipse.osgi.service.debug.DebugOptions;
/*     */ import org.osgi.framework.FrameworkListener;
/*     */ import org.osgi.framework.hooks.resolver.ResolverHookFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class ModuleContainerAdaptor
/*     */ {
/*  32 */   private static Executor defaultExecutor = new Executor()
/*     */     {
/*     */       public void execute(Runnable command) {
/*  35 */         command.run();
/*     */       }
/*     */     };
/*     */   public abstract ModuleCollisionHook getModuleCollisionHook();
/*     */   public abstract ResolverHookFactory getResolverHookFactory();
/*     */   
/*     */   public abstract void publishContainerEvent(ContainerEvent paramContainerEvent, Module paramModule, Throwable paramThrowable, FrameworkListener... paramVarArgs);
/*     */   
/*     */   public abstract void publishModuleEvent(ModuleEvent paramModuleEvent, Module paramModule1, Module paramModule2);
/*     */   
/*  45 */   public enum ContainerEvent { REFRESH,
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  50 */     START_LEVEL,
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  55 */     STARTED,
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  60 */     STOPPED,
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  66 */     STOPPED_UPDATE,
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  73 */     STOPPED_REFRESH,
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  80 */     STOPPED_TIMEOUT,
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  86 */     ERROR,
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  91 */     WARNING,
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  96 */     INFO; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public enum ModuleEvent
/*     */   {
/* 107 */     INSTALLED,
/*     */ 
/*     */ 
/*     */     
/* 111 */     LAZY_ACTIVATION,
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 116 */     RESOLVED,
/*     */ 
/*     */ 
/*     */     
/* 120 */     STARTED,
/*     */ 
/*     */ 
/*     */     
/* 124 */     STARTING,
/*     */ 
/*     */ 
/*     */     
/* 128 */     STOPPED,
/*     */ 
/*     */ 
/*     */     
/* 132 */     STOPPING,
/*     */ 
/*     */ 
/*     */     
/* 136 */     UNINSTALLED,
/*     */ 
/*     */ 
/*     */     
/* 140 */     UNRESOLVED,
/*     */ 
/*     */ 
/*     */     
/* 144 */     UPDATED;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getProperty(String key) {
/* 190 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ModuleLoader createModuleLoader(ModuleWiring wiring) {
/* 199 */     throw new UnsupportedOperationException("Container adaptor does not support module class loaders.");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract Module createModule(String paramString, long paramLong, EnumSet<Module.Settings> paramEnumSet, int paramInt);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract SystemModule createSystemModule();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object getRevisionInfo(String location, long id) {
/* 232 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void associateRevision(ModuleRevision revision, Object revisionInfo) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void invalidateWiring(ModuleWiring moduleWiring, ModuleLoader current) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void refreshedSystemModule() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void updatedDatabase() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void initBegin() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void initEnd() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DebugOptions getDebugOptions() {
/* 293 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Executor getResolverExecutor() {
/* 302 */     return defaultExecutor;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Executor getStartLevelExecutor() {
/* 314 */     return defaultExecutor;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ModuleRevisionBuilder adaptModuleRevisionBuilder(ModuleEvent operation, Module origin, ModuleRevisionBuilder builder, Object revisionInfo) {
/* 337 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ScheduledExecutorService getScheduledExecutor() {
/* 347 */     return null;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.osgi-3.18.400.jar!\org\eclipse\osgi\container\ModuleContainerAdaptor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */