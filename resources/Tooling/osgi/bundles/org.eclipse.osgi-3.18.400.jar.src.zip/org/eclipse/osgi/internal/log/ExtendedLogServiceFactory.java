/*     */ package org.eclipse.osgi.internal.log;
/*     */ 
/*     */ import java.security.AccessController;
/*     */ import java.security.Permission;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.concurrent.locks.ReentrantReadWriteLock;
/*     */ import org.eclipse.equinox.log.ExtendedLogService;
/*     */ import org.eclipse.equinox.log.LogPermission;
/*     */ import org.eclipse.osgi.framework.util.SecureAction;
/*     */ import org.osgi.framework.Bundle;
/*     */ import org.osgi.framework.BundleEvent;
/*     */ import org.osgi.framework.BundleListener;
/*     */ import org.osgi.framework.ServiceFactory;
/*     */ import org.osgi.framework.ServiceReference;
/*     */ import org.osgi.framework.ServiceRegistration;
/*     */ import org.osgi.service.log.LogLevel;
/*     */ import org.osgi.service.log.admin.LoggerAdmin;
/*     */ import org.osgi.service.log.admin.LoggerContext;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ExtendedLogServiceFactory
/*     */   implements ServiceFactory<ExtendedLogService>, BundleListener
/*     */ {
/*  34 */   static final SecureAction secureAction = AccessController.<SecureAction>doPrivileged(SecureAction.createSecureAction());
/*  35 */   final ReentrantReadWriteLock contextsLock = new ReentrantReadWriteLock();
/*  36 */   final LoggerContextTargetMap loggerContextTargetMap = new LoggerContextTargetMap();
/*  37 */   private final Permission logPermission = (Permission)new LogPermission("*", "log");
/*     */   final ExtendedLogReaderServiceFactory logReaderServiceFactory;
/*  39 */   private final LoggerAdmin loggerAdmin = new EquinoxLoggerAdmin();
/*     */   private final boolean captureLogEntryLocation;
/*     */   
/*     */   public ExtendedLogServiceFactory(ExtendedLogReaderServiceFactory logReaderServiceFactory, boolean captureLogEntryLocation) {
/*  43 */     this.logReaderServiceFactory = logReaderServiceFactory;
/*  44 */     this.captureLogEntryLocation = captureLogEntryLocation;
/*     */   }
/*     */   
/*     */   boolean captureLogEntryLocation() {
/*  48 */     return this.captureLogEntryLocation;
/*     */   }
/*     */ 
/*     */   
/*     */   public ExtendedLogServiceImpl getService(Bundle bundle, ServiceRegistration<ExtendedLogService> registration) {
/*  53 */     return getLogService(bundle);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void ungetService(Bundle bundle, ServiceRegistration<ExtendedLogService> registration, ExtendedLogService service) {}
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void bundleChanged(BundleEvent event) {
/*  65 */     if (event.getType() == 16)
/*  66 */       removeLogService(event.getBundle()); 
/*     */   }
/*     */   
/*     */   ExtendedLogServiceImpl getLogService(Bundle bundle) {
/*  70 */     this.contextsLock.writeLock().lock();
/*     */     try {
/*  72 */       return this.loggerContextTargetMap.getLogService(bundle, this);
/*     */     } finally {
/*  74 */       this.contextsLock.writeLock().unlock();
/*     */     } 
/*     */   }
/*     */   
/*     */   void shutdown() {
/*  79 */     this.contextsLock.writeLock().lock();
/*     */     try {
/*  81 */       this.loggerContextTargetMap.clear();
/*     */     } finally {
/*  83 */       this.contextsLock.writeLock().unlock();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   void removeLogService(Bundle bundle) {
/*  89 */     this.contextsLock.writeLock().lock();
/*     */     try {
/*  91 */       this.loggerContextTargetMap.remove(bundle);
/*     */     } finally {
/*  93 */       this.contextsLock.writeLock().unlock();
/*     */     } 
/*     */   }
/*     */   
/*     */   boolean isLoggable(Bundle bundle, String name, int level) {
/*  98 */     return this.logReaderServiceFactory.isLoggable(bundle, name, level);
/*     */   }
/*     */   
/*     */   void log(Bundle bundle, String name, StackTraceElement stackTraceElement, Object context, LogLevel logLevelEnum, int level, String message, ServiceReference<?> ref, Throwable exception) {
/* 102 */     this.logReaderServiceFactory.log(bundle, name, stackTraceElement, context, logLevelEnum, level, message, ref, exception);
/*     */   }
/*     */   
/*     */   void checkLogPermission() throws SecurityException {
/* 106 */     SecurityManager sm = System.getSecurityManager();
/* 107 */     if (sm != null)
/* 108 */       sm.checkPermission(this.logPermission); 
/*     */   }
/*     */   
/*     */   EquinoxLoggerContext createEquinoxLoggerContext(String name) {
/* 112 */     return new EquinoxLoggerContext(name);
/*     */   }
/*     */   
/*     */   LoggerAdmin getLoggerAdmin() {
/* 116 */     return this.loggerAdmin;
/*     */   }
/*     */   
/*     */   class EquinoxLoggerAdmin
/*     */     implements LoggerAdmin {
/*     */     public LoggerContext getLoggerContext(String name) {
/* 122 */       ExtendedLogServiceFactory.this.contextsLock.writeLock().lock();
/*     */       try {
/* 124 */         return ExtendedLogServiceFactory.this.loggerContextTargetMap.createLoggerContext(name, ExtendedLogServiceFactory.this);
/*     */       } finally {
/* 126 */         ExtendedLogServiceFactory.this.contextsLock.writeLock().unlock();
/*     */       } 
/*     */     }
/*     */   }
/*     */   
/*     */   class EquinoxLoggerContext
/*     */     implements LoggerContext {
/*     */     final String contextName;
/* 134 */     final Map<String, LogLevel> contextLogLevels = new HashMap<>();
/*     */     
/*     */     EquinoxLoggerContext(String name) {
/* 137 */       this.contextName = name;
/*     */     }
/*     */ 
/*     */     
/*     */     public String getName() {
/* 142 */       return this.contextName;
/*     */     }
/*     */ 
/*     */     
/*     */     public LogLevel getEffectiveLogLevel(String name) {
/* 147 */       ExtendedLogServiceFactory.this.contextsLock.readLock().lock();
/*     */       try {
/* 149 */         LogLevel level = null;
/* 150 */         String lookupName = name;
/* 151 */         while ((level = this.contextLogLevels.get(lookupName)) == null) {
/* 152 */           int lastDot = lookupName.lastIndexOf('.');
/* 153 */           if (lastDot >= 0) {
/* 154 */             lookupName = lookupName.substring(0, lastDot);
/*     */             continue;
/*     */           } 
/*     */           break;
/*     */         } 
/* 159 */         if (level == null) {
/* 160 */           level = this.contextLogLevels.get("ROOT");
/*     */         }
/* 162 */         if (level == null && this.contextName != null) {
/*     */ 
/*     */           
/* 165 */           EquinoxLoggerContext rootContext = ExtendedLogServiceFactory.this.loggerContextTargetMap.getRootLoggerContext();
/* 166 */           if (rootContext != null) {
/* 167 */             level = rootContext.getEffectiveLogLevel(name);
/*     */           }
/*     */         } 
/* 170 */         if (level == null) {
/* 171 */           level = ExtendedLogServiceFactory.this.logReaderServiceFactory.getDefaultLogLevel();
/*     */         }
/* 173 */         return level;
/*     */       } finally {
/* 175 */         ExtendedLogServiceFactory.this.contextsLock.readLock().unlock();
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public Map<String, LogLevel> getLogLevels() {
/* 181 */       ExtendedLogServiceFactory.this.contextsLock.readLock().lock();
/*     */       try {
/* 183 */         return new HashMap<>(this.contextLogLevels);
/*     */       } finally {
/* 185 */         ExtendedLogServiceFactory.this.contextsLock.readLock().unlock();
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void setLogLevels(Map<String, LogLevel> logLevels) {
/* 191 */       boolean readLocked = false;
/*     */       try {
/* 193 */         ExtendedLogServiceFactory.this.contextsLock.writeLock().lock();
/*     */         try {
/* 195 */           this.contextLogLevels.clear();
/* 196 */           this.contextLogLevels.putAll(logLevels);
/*     */           
/* 198 */           ExtendedLogServiceFactory.this.contextsLock.readLock().lock();
/* 199 */           readLocked = true;
/*     */         } finally {
/* 201 */           ExtendedLogServiceFactory.this.contextsLock.writeLock().unlock();
/*     */         } 
/* 203 */         ExtendedLogServiceFactory.this.loggerContextTargetMap.applyLogLevels(this);
/*     */       } finally {
/* 205 */         if (readLocked) {
/* 206 */           ExtendedLogServiceFactory.this.contextsLock.readLock().unlock();
/*     */         }
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void clear() {
/* 213 */       setLogLevels(Collections.emptyMap());
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isEmpty() {
/* 218 */       ExtendedLogServiceFactory.this.contextsLock.readLock().lock();
/*     */       try {
/* 220 */         return this.contextLogLevels.isEmpty();
/*     */       } finally {
/* 222 */         ExtendedLogServiceFactory.this.contextsLock.readLock().unlock();
/*     */       } 
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.osgi-3.18.400.jar!\org\eclipse\osgi\internal\log\ExtendedLogServiceFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */