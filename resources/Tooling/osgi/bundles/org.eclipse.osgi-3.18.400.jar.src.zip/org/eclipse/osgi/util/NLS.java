/*     */ package org.eclipse.osgi.util;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.lang.reflect.Field;
/*     */ import java.security.AccessController;
/*     */ import java.security.PrivilegedAction;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import java.util.Properties;
/*     */ import org.eclipse.osgi.framework.log.FrameworkLog;
/*     */ import org.eclipse.osgi.framework.log.FrameworkLogEntry;
/*     */ import org.eclipse.osgi.internal.util.SupplementDebug;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class NLS
/*     */ {
/*  62 */   private static final Object[] EMPTY_ARGS = new Object[0]; private static final String EXTENSION = ".properties";
/*     */   private static String[] nlSuffixes;
/*     */   private static final String PROP_WARNINGS = "osgi.nls.warnings";
/*     */   private static final String IGNORE = "ignore";
/*     */   
/*  67 */   private static final boolean ignoreWarnings = ((Boolean)AccessController.<Boolean>doPrivileged(new PrivilegedAction<Boolean>()
/*     */       {
/*     */         public Boolean run() {
/*  70 */           return Boolean.valueOf("ignore".equals(System.getProperty("osgi.nls.warnings")));
/*     */         }
/*     */       })).booleanValue();
/*     */ 
/*     */ 
/*     */   
/*     */   private static FrameworkLog frameworkLog;
/*     */ 
/*     */   
/*     */   static final int SEVERITY_ERROR = 4;
/*     */ 
/*     */   
/*     */   static final int SEVERITY_WARNING = 2;
/*     */ 
/*     */   
/*  85 */   static final Object ASSIGNED = new Object();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String bind(String message, Object binding) {
/* 103 */     return internalBind(message, null, String.valueOf(binding), null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String bind(String message, Object binding1, Object binding2) {
/* 116 */     return internalBind(message, null, String.valueOf(binding1), String.valueOf(binding2));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String bind(String message, Object[] bindings) {
/* 128 */     return internalBind(message, bindings, null, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void initializeMessages(final String baseName, final Class<?> clazz) {
/* 151 */     if (System.getSecurityManager() == null) {
/* 152 */       load(baseName, clazz);
/*     */       return;
/*     */     } 
/* 155 */     AccessController.doPrivileged(new PrivilegedAction<Void>()
/*     */         {
/*     */           public Void run() {
/* 158 */             NLS.load(baseName, clazz);
/* 159 */             return null;
/*     */           }
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static String internalBind(String message, Object[] args, String argZero, String argOne) {
/* 169 */     if (message == null)
/* 170 */       return "No message available."; 
/* 171 */     if (args == null || args.length == 0) {
/* 172 */       args = EMPTY_ARGS;
/*     */     }
/* 174 */     int length = message.length();
/*     */     
/* 176 */     int bufLen = length + args.length * 5;
/* 177 */     if (argZero != null)
/* 178 */       bufLen += argZero.length() - 3; 
/* 179 */     if (argOne != null)
/* 180 */       bufLen += argOne.length() - 3; 
/* 181 */     StringBuilder buffer = new StringBuilder((bufLen < 0) ? 0 : bufLen);
/* 182 */     for (int i = 0; i < length; i++) {
/* 183 */       int index, number, nextIndex; char next, c = message.charAt(i);
/* 184 */       switch (c) {
/*     */         case '{':
/* 186 */           index = message.indexOf('}', i);
/*     */           
/* 188 */           if (index == -1) {
/* 189 */             buffer.append(c);
/*     */             break;
/*     */           } 
/* 192 */           i++;
/* 193 */           if (i >= length) {
/* 194 */             buffer.append(c);
/*     */             
/*     */             break;
/*     */           } 
/* 198 */           number = -1;
/*     */           try {
/* 200 */             number = Integer.parseInt(message.substring(i, index));
/* 201 */           } catch (NumberFormatException e) {
/* 202 */             throw new IllegalArgumentException(e);
/*     */           } 
/* 204 */           if (number == 0 && argZero != null) {
/* 205 */             buffer.append(argZero);
/* 206 */           } else if (number == 1 && argOne != null) {
/* 207 */             buffer.append(argOne);
/*     */           } else {
/* 209 */             if (number >= args.length || number < 0) {
/* 210 */               buffer.append("<missing argument>");
/* 211 */               i = index;
/*     */               break;
/*     */             } 
/* 214 */             buffer.append(args[number]);
/*     */           } 
/* 216 */           i = index;
/*     */           break;
/*     */         
/*     */         case '\'':
/* 220 */           nextIndex = i + 1;
/* 221 */           if (nextIndex >= length) {
/* 222 */             buffer.append(c);
/*     */             break;
/*     */           } 
/* 225 */           next = message.charAt(nextIndex);
/*     */           
/* 227 */           if (next == '\'') {
/* 228 */             i++;
/* 229 */             buffer.append(c);
/*     */             
/*     */             break;
/*     */           } 
/* 233 */           index = message.indexOf('\'', nextIndex);
/*     */           
/* 235 */           if (index == -1) {
/* 236 */             buffer.append(c);
/*     */             
/*     */             break;
/*     */           } 
/* 240 */           buffer.append(message, nextIndex, index);
/* 241 */           i = index;
/*     */           break;
/*     */         default:
/* 244 */           buffer.append(c); break;
/*     */       } 
/*     */     } 
/* 247 */     return buffer.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static String[] buildVariants(String root) {
/* 257 */     if (nlSuffixes == null) {
/*     */       
/* 259 */       String nl = Locale.getDefault().toString();
/* 260 */       List<String> result = new ArrayList<>(4);
/*     */       
/*     */       while (true) {
/* 263 */         result.add(String.valueOf('_') + nl + ".properties");
/* 264 */         String additional = getAdditionalSuffix(nl);
/* 265 */         if (additional != null) {
/* 266 */           result.add(String.valueOf('_') + additional + ".properties");
/*     */         }
/* 268 */         int lastSeparator = nl.lastIndexOf('_');
/* 269 */         if (lastSeparator == -1)
/*     */           break; 
/* 271 */         nl = nl.substring(0, lastSeparator);
/*     */       } 
/*     */       
/* 274 */       result.add(".properties");
/* 275 */       nlSuffixes = result.<String>toArray(new String[result.size()]);
/*     */     } 
/* 277 */     root = root.replace('.', '/');
/* 278 */     String[] variants = new String[nlSuffixes.length];
/* 279 */     for (int i = 0; i < variants.length; i++)
/* 280 */       variants[i] = String.valueOf(root) + nlSuffixes[i]; 
/* 281 */     return variants;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static String getAdditionalSuffix(String nl) {
/* 289 */     String additional = null;
/* 290 */     if (nl != null) {
/* 291 */       if ("he".equals(nl)) {
/* 292 */         additional = "iw";
/* 293 */       } else if (nl.startsWith("he_")) {
/* 294 */         additional = "iw_" + nl.substring(3);
/*     */       } 
/*     */     }
/*     */     
/* 298 */     return additional;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void computeMissingMessages(String bundleName, Class<?> clazz, Map<Object, Object> fieldMap, Field[] fieldArray, boolean isAccessible) {
/* 305 */     int numFields = fieldArray.length;
/* 306 */     for (int i = 0; i < numFields; i++) {
/* 307 */       Field field = fieldArray[i];
/* 308 */       if ((field.getModifiers() & 0x19) == 9)
/*     */       {
/*     */         
/* 311 */         if (fieldMap.get(field.getName()) != ASSIGNED) {
/*     */           
/*     */           try {
/*     */ 
/*     */ 
/*     */ 
/*     */             
/* 318 */             String value = "NLS missing message: " + field.getName() + " in: " + bundleName;
/* 319 */             if (SupplementDebug.STATIC_DEBUG_MESSAGE_BUNDLES)
/* 320 */               System.out.println(value); 
/* 321 */             log(2, value, null);
/* 322 */             if (!isAccessible)
/* 323 */               field.setAccessible(true); 
/* 324 */             field.set(null, value);
/* 325 */           } catch (Exception e) {
/* 326 */             log(4, "Error setting the missing message value for: " + field.getName(), e);
/*     */           } 
/*     */         }
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   static void load(String bundleName, Class<?> clazz) {
/* 335 */     long start = System.currentTimeMillis();
/* 336 */     Field[] fieldArray = clazz.getDeclaredFields();
/* 337 */     ClassLoader loader = clazz.getClassLoader();
/*     */     
/* 339 */     boolean isAccessible = ((clazz.getModifiers() & 0x1) != 0);
/*     */ 
/*     */     
/* 342 */     int len = fieldArray.length;
/* 343 */     Map<Object, Object> fields = new HashMap<>(len * 2);
/* 344 */     for (int i = 0; i < len; i++) {
/* 345 */       fields.put(fieldArray[i].getName(), fieldArray[i]);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 350 */     String[] variants = buildVariants(bundleName); byte b; int j; String[] arrayOfString1;
/* 351 */     for (j = (arrayOfString1 = variants).length, b = 0; b < j; ) { String variant = arrayOfString1[b];
/*     */       
/* 353 */       InputStream input = (loader == null) ? ClassLoader.getSystemResourceAsStream(variant) : loader.getResourceAsStream(variant);
/* 354 */       if (input != null)
/*     */         
/*     */         try {
/* 357 */           MessagesProperties properties = new MessagesProperties(fields, bundleName, isAccessible);
/* 358 */           properties.load(input);
/* 359 */         } catch (IOException e) {
/* 360 */           log(4, "Error loading " + variant, e);
/*     */         } finally {
/* 362 */           if (input != null) {
/*     */             try {
/* 364 */               input.close();
/* 365 */             } catch (IOException iOException) {}
/*     */           }
/*     */         }  
/*     */       b++; }
/*     */     
/* 370 */     computeMissingMessages(bundleName, clazz, fields, fieldArray, isAccessible);
/* 371 */     if (SupplementDebug.STATIC_DEBUG_MESSAGE_BUNDLES) {
/* 372 */       System.out.println("Time to load message bundle: " + bundleName + " was " + (System.currentTimeMillis() - start) + "ms.");
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static void log(int severity, String message, Exception e) {
/*     */     String statusMsg;
/* 388 */     if (severity == 2 && ignoreWarnings)
/*     */       return; 
/* 390 */     if (frameworkLog != null) {
/* 391 */       frameworkLog.log(new FrameworkLogEntry("org.eclipse.osgi", severity, 1, message, 0, e, null));
/*     */       
/*     */       return;
/*     */     } 
/* 395 */     switch (severity) {
/*     */       case 4:
/* 397 */         statusMsg = "Error: ";
/*     */         break;
/*     */ 
/*     */       
/*     */       default:
/* 402 */         statusMsg = "Warning: "; break;
/*     */     } 
/* 404 */     if (message != null)
/* 405 */       statusMsg = String.valueOf(statusMsg) + message; 
/* 406 */     if (e != null)
/* 407 */       statusMsg = String.valueOf(statusMsg) + ": " + e.getMessage(); 
/* 408 */     System.err.println(statusMsg);
/* 409 */     if (e != null) {
/* 410 */       e.printStackTrace();
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private static class MessagesProperties
/*     */     extends Properties
/*     */   {
/*     */     private static final int MOD_EXPECTED = 9;
/*     */     
/*     */     private static final int MOD_MASK = 25;
/*     */     
/*     */     private static final long serialVersionUID = 1L;
/*     */     
/*     */     private final String bundleName;
/*     */     private final Map<Object, Object> fields;
/*     */     private final boolean isAccessible;
/*     */     
/*     */     public MessagesProperties(Map<Object, Object> fieldMap, String bundleName, boolean isAccessible) {
/* 429 */       this.fields = fieldMap;
/* 430 */       this.bundleName = bundleName;
/* 431 */       this.isAccessible = isAccessible;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public synchronized Object put(Object key, Object value) {
/* 439 */       Object fieldObject = this.fields.put(key, NLS.ASSIGNED);
/*     */       
/* 441 */       if (fieldObject == NLS.ASSIGNED)
/* 442 */         return null; 
/* 443 */       if (fieldObject == null) {
/* 444 */         String msg = "NLS unused message: " + key + " in: " + this.bundleName;
/* 445 */         if (SupplementDebug.STATIC_DEBUG_MESSAGE_BUNDLES) {
/* 446 */           System.out.println(msg);
/*     */         }
/* 448 */         if (key instanceof String && ((String)key).indexOf('.') < 0) {
/* 449 */           NLS.log(2, msg, null);
/*     */         }
/* 451 */         return null;
/*     */       } 
/* 453 */       Field field = (Field)fieldObject;
/*     */       
/* 455 */       if ((field.getModifiers() & 0x19) != 9) {
/* 456 */         return null;
/*     */       }
/*     */ 
/*     */       
/*     */       try {
/* 461 */         if (!this.isAccessible) {
/* 462 */           field.setAccessible(true);
/*     */         }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 470 */         field.set(null, new String(((String)value).toCharArray()));
/* 471 */       } catch (Exception e) {
/* 472 */         NLS.log(4, "Exception setting field value.", e);
/*     */       } 
/* 474 */       return null;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.osgi-3.18.400.jar!\org\eclipse\osg\\util\NLS.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */