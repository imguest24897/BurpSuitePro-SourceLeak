/*     */ package org.eclipse.osgi.internal.loader.buddy;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.net.URL;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Enumeration;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import org.eclipse.osgi.container.ModuleWire;
/*     */ import org.eclipse.osgi.container.ModuleWiring;
/*     */ import org.eclipse.osgi.internal.loader.BundleLoader;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DependentPolicy
/*     */   implements IBuddyPolicy
/*     */ {
/*     */   BundleLoader buddyRequester;
/*  36 */   int lastDependentOfAdded = -1;
/*  37 */   List<ModuleWiring> allDependents = null;
/*     */   
/*     */   public DependentPolicy(BundleLoader requester) {
/*  40 */     this.buddyRequester = requester;
/*     */ 
/*     */     
/*  43 */     this.allDependents = new ArrayList<>();
/*  44 */     basicAddImmediateDependents(requester.getWiring());
/*     */     
/*  46 */     if (this.allDependents.size() == 0) {
/*  47 */       this.allDependents = null;
/*     */     }
/*     */   }
/*     */   
/*     */   public Class<?> loadClass(String name) {
/*  52 */     if (this.allDependents == null) {
/*  53 */       return null;
/*     */     }
/*     */     
/*  56 */     for (int i = 0; i < this.allDependents.size(); i++) {
/*  57 */       ModuleWiring searchWiring = this.allDependents.get(i);
/*  58 */       BundleLoader searchLoader = (BundleLoader)searchWiring.getModuleLoader();
/*  59 */       if (searchLoader != null) {
/*  60 */         Class<?> result = searchLoader.findClassNoParentNoException(name);
/*  61 */         if (result != null) {
/*  62 */           return result;
/*     */         }
/*  64 */         addDependent(i, searchWiring);
/*     */       } 
/*     */     } 
/*  67 */     return null;
/*     */   }
/*     */   
/*     */   private synchronized void addDependent(int i, ModuleWiring searchedWiring) {
/*  71 */     if (i > this.lastDependentOfAdded) {
/*  72 */       this.lastDependentOfAdded = i;
/*  73 */       basicAddImmediateDependents(searchedWiring);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public URL loadResource(String name) {
/*  79 */     if (this.allDependents == null) {
/*  80 */       return null;
/*     */     }
/*  82 */     URL result = null;
/*     */     
/*  84 */     for (int i = 0; i < this.allDependents.size() && result == null; i++) {
/*  85 */       ModuleWiring searchWiring = this.allDependents.get(i);
/*  86 */       BundleLoader searchLoader = (BundleLoader)searchWiring.getModuleLoader();
/*  87 */       if (searchLoader != null) {
/*  88 */         result = searchLoader.findResource(name);
/*  89 */         if (result == null) {
/*  90 */           addDependent(i, searchWiring);
/*     */         }
/*     */       } 
/*     */     } 
/*  94 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   public Enumeration<URL> loadResources(String name) {
/*  99 */     if (this.allDependents == null) {
/* 100 */       return null;
/*     */     }
/* 102 */     Enumeration<URL> results = null;
/*     */     
/* 104 */     for (int i = 0; i < this.allDependents.size(); i++) {
/* 105 */       ModuleWiring searchWiring = this.allDependents.get(i);
/* 106 */       BundleLoader searchLoader = (BundleLoader)searchWiring.getModuleLoader();
/* 107 */       if (searchLoader != null) {
/*     */         try {
/* 109 */           results = BundleLoader.compoundEnumerations(results, searchLoader.findResources(name));
/* 110 */           addDependent(i, searchWiring);
/* 111 */         } catch (IOException iOException) {}
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 116 */     return results;
/*     */   }
/*     */ 
/*     */   
/*     */   public void addListResources(Set<String> results, String path, String filePattern, int options) {
/* 121 */     if (this.allDependents == null) {
/*     */       return;
/*     */     }
/*     */     
/* 125 */     for (int i = 0; i < this.allDependents.size(); i++) {
/* 126 */       ModuleWiring searchWiring = this.allDependents.get(i);
/* 127 */       results.addAll(searchWiring.listResources(path, filePattern, options));
/* 128 */       addDependent(i, searchWiring);
/*     */     } 
/*     */   }
/*     */   
/*     */   private void basicAddImmediateDependents(ModuleWiring wiring) {
/* 133 */     List<ModuleWire> providedWires = wiring.getProvidedModuleWires(null);
/* 134 */     if (providedWires != null)
/* 135 */       for (ModuleWire wire : providedWires) {
/* 136 */         String namespace = wire.getRequirement().getNamespace();
/* 137 */         if ("osgi.wiring.package".equals(namespace) || "osgi.wiring.bundle".equals(namespace)) {
/* 138 */           ModuleWiring dependent = wire.getRequirerWiring();
/* 139 */           if (!this.allDependents.contains(dependent))
/* 140 */             this.allDependents.add(dependent); 
/*     */         } 
/*     */       }  
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.osgi-3.18.400.jar!\org\eclipse\osgi\internal\loader\buddy\DependentPolicy.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */