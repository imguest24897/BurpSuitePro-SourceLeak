/*     */ package org.eclipse.osgi.framework.util;
/*     */ 
/*     */ import java.util.AbstractSet;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.Dictionary;
/*     */ import java.util.Enumeration;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import java.util.Objects;
/*     */ import java.util.Set;
/*     */ import org.eclipse.osgi.internal.messages.Msg;
/*     */ import org.eclipse.osgi.util.NLS;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CaseInsensitiveDictionaryMap<K, V>
/*     */   extends Dictionary<K, V>
/*     */   implements Map<K, V>
/*     */ {
/*  45 */   private static final CaseInsensitiveKey KEY_SERVICE_OBJECTCLASS = new CaseInsensitiveKey("objectClass");
/*  46 */   private static final CaseInsensitiveKey KEY_SERVICE_BUNDLE_ID = new CaseInsensitiveKey("service.bundleid");
/*  47 */   private static final CaseInsensitiveKey KEY_SERVICE_CHANGECOUNT = new CaseInsensitiveKey("service.changecount");
/*  48 */   private static final CaseInsensitiveKey KEY_SERVICE_DESCRIPTION = new CaseInsensitiveKey("service.description");
/*  49 */   private static final CaseInsensitiveKey KEY_SERVICE_ID = new CaseInsensitiveKey("service.id");
/*  50 */   private static final CaseInsensitiveKey KEY_SERVICE_PID = new CaseInsensitiveKey("service.pid");
/*  51 */   private static final CaseInsensitiveKey KEY_SERVICE_RANKING = new CaseInsensitiveKey("service.ranking");
/*  52 */   private static final CaseInsensitiveKey KEY_SERVICE_SCOPE = new CaseInsensitiveKey("service.scope");
/*  53 */   private static final CaseInsensitiveKey KEY_SERVICE_VENDER = new CaseInsensitiveKey("service.vendor");
/*     */ 
/*     */   
/*  56 */   private static final CaseInsensitiveKey KEY_COMPONENT_NAME = new CaseInsensitiveKey("component.name");
/*  57 */   private static final CaseInsensitiveKey KEY_COMPONENT_ID = new CaseInsensitiveKey("component.id");
/*     */ 
/*     */   
/*  60 */   private static final CaseInsensitiveKey KEY_METATYPE_PID = new CaseInsensitiveKey("metatype.pid");
/*  61 */   private static final CaseInsensitiveKey KEY_METATYPE_FACTORY_PID = new CaseInsensitiveKey("metatype.factory.pid");
/*     */ 
/*     */   
/*  64 */   private static final CaseInsensitiveKey KEY_EVENT_TOPICS = new CaseInsensitiveKey("event.topics");
/*  65 */   private static final CaseInsensitiveKey KEY_EVENT_FILTER = new CaseInsensitiveKey("event.filter");
/*     */ 
/*     */   
/*  68 */   private static final CaseInsensitiveKey KEY_JMX_OBJECTNAME = new CaseInsensitiveKey("jmx.objectname");
/*     */ 
/*     */   
/*  71 */   private static final CaseInsensitiveKey KEY_JAR_MANIFESTVERSION = new CaseInsensitiveKey("Manifest-Version");
/*  72 */   private static final CaseInsensitiveKey KEY_BUNDLE_ACTIVATIONPOLICY = new CaseInsensitiveKey("Bundle-ActivationPolicy");
/*  73 */   private static final CaseInsensitiveKey KEY_BUNDLE_ACTIVATOR = new CaseInsensitiveKey("Bundle-Activator");
/*  74 */   private static final CaseInsensitiveKey KEY_BUNDLE_CLASSPATH = new CaseInsensitiveKey("Bundle-ClassPath");
/*  75 */   private static final CaseInsensitiveKey KEY_BUNDLE_DESCRIPTION = new CaseInsensitiveKey("Bundle-Description");
/*  76 */   private static final CaseInsensitiveKey KEY_BUNDLE_LICENSE = new CaseInsensitiveKey("Bundle-License");
/*  77 */   private static final CaseInsensitiveKey KEY_BUNDLE_LOCALIZATION = new CaseInsensitiveKey("Bundle-Localization");
/*  78 */   private static final CaseInsensitiveKey KEY_BUNDLE_MANIFESTVERSION = new CaseInsensitiveKey("Bundle-ManifestVersion");
/*  79 */   private static final CaseInsensitiveKey KEY_BUNDLE_NAME = new CaseInsensitiveKey("Bundle-Name");
/*  80 */   private static final CaseInsensitiveKey KEY_BUNDLE_NATIVECODE = new CaseInsensitiveKey("Bundle-NativeCode");
/*     */   
/*  82 */   private static final CaseInsensitiveKey KEY_BUNDLE_REQUIREDEXECUTIONENVIRONMENT = new CaseInsensitiveKey("Bundle-RequiredExecutionEnvironment");
/*  83 */   private static final CaseInsensitiveKey KEY_BUNDLE_SCM = new CaseInsensitiveKey("Bundle-SCM");
/*  84 */   private static final CaseInsensitiveKey KEY_BUNDLE_SYMBOLICNAME = new CaseInsensitiveKey("Bundle-SymbolicName");
/*  85 */   private static final CaseInsensitiveKey KEY_BUNDLE_VENDOR = new CaseInsensitiveKey("Bundle-Vendor");
/*  86 */   private static final CaseInsensitiveKey KEY_BUNDLE_VERSION = new CaseInsensitiveKey("Bundle-Version");
/*  87 */   private static final CaseInsensitiveKey KEY_BUNDLE_DYNAMICIMPORT_PACKAGE = new CaseInsensitiveKey("DynamicImport-Package");
/*  88 */   private static final CaseInsensitiveKey KEY_BUNDLE_EXPORT_PACKAGE = new CaseInsensitiveKey("Export-Package");
/*  89 */   private static final CaseInsensitiveKey KEY_BUNDLE_FRAGMENT_HOST = new CaseInsensitiveKey("Fragment-Host");
/*  90 */   private static final CaseInsensitiveKey KEY_BUNDLE_IMPORT_PACKAGE = new CaseInsensitiveKey("Import-Package");
/*  91 */   private static final CaseInsensitiveKey KEY_BUNDLE_REQUIRE_BUNDLE = new CaseInsensitiveKey("Require-Bundle");
/*  92 */   private static final CaseInsensitiveKey KEY_BUNDLE_REQUIRE_CAPABILITY = new CaseInsensitiveKey("Require-Capability");
/*  93 */   private static final CaseInsensitiveKey KEY_BUNDLE_PROVIDE_CAPABILITY = new CaseInsensitiveKey("Provide-Capability"); final Map<Object, V> map; private transient Set<Map.Entry<K, V>> entrySet; private transient Set<K> keySet;
/*     */   
/*     */   public static CaseInsensitiveKey findCommonKeyIndex(String key) {
/*     */     String str;
/*  97 */     switch ((str = key).hashCode()) { case -1929511214: if (!str.equals("service.pid")) {
/*     */           break;
/*     */         }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 110 */         return KEY_SERVICE_PID;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       case -1833433211:
/*     */         if (!str.equals("Bundle-RequiredExecutionEnvironment")) {
/*     */           break;
/*     */         }
/* 162 */         return KEY_BUNDLE_REQUIREDEXECUTIONENVIRONMENT;
/*     */       case -1724810508:
/*     */         if (!str.equals("service.id")) {
/*     */           break;
/*     */         }
/*     */         return KEY_SERVICE_ID;
/*     */       case -1678684163:
/*     */         if (!str.equals("DynamicImport-Package")) {
/*     */           break;
/*     */         }
/* 172 */         return KEY_BUNDLE_DYNAMICIMPORT_PACKAGE;case -1348515261: if (!str.equals("jmx.objectname"))
/*     */           break;  return KEY_JMX_OBJECTNAME;case -1303296647: if (!str.equals("objectClass"))
/*     */           break;  return KEY_SERVICE_OBJECTCLASS;
/*     */       case -1145946660: if (!str.equals("metatype.pid"))
/*     */           break;  return KEY_METATYPE_PID;
/*     */       case -1094655793: if (!str.equals("Bundle-NativeCode"))
/*     */           break;  return KEY_BUNDLE_NATIVECODE;
/*     */       case -1045885898: if (!str.equals("service.bundleid"))
/*     */           break;  return KEY_SERVICE_BUNDLE_ID;
/*     */       case -1004550464: if (!str.equals("Require-Capability"))
/* 182 */           break;  return KEY_BUNDLE_REQUIRE_CAPABILITY;case -925454254: if (!str.equals("Bundle-SCM")) break;  return KEY_BUNDLE_SCM;case -823307170: if (!str.equals("Bundle-ManifestVersion")) break;  return KEY_BUNDLE_MANIFESTVERSION;case -699448782: if (!str.equals("Bundle-ClassPath")) break;  return KEY_BUNDLE_CLASSPATH;case -694237965: if (!str.equals("Bundle-Vendor")) break;  return KEY_BUNDLE_VENDOR;case -589830614: if (!str.equals("Require-Bundle"))
/*     */           break;  return KEY_BUNDLE_REQUIRE_BUNDLE;case -550921212: if (!str.equals("Provide-Capability"))
/* 184 */           break;  return KEY_BUNDLE_PROVIDE_CAPABILITY;case -499179604: if (!str.equals("component.id")) break;  return KEY_COMPONENT_ID;case -485226614: if (!str.equals("Bundle-Activator")) break;  return KEY_BUNDLE_ACTIVATOR;case -227255818: if (!str.equals("Bundle-License")) break;  return KEY_BUNDLE_LICENSE;case -107361531: if (!str.equals("Fragment-Host")) break;  return KEY_BUNDLE_FRAGMENT_HOST;case -42405235: if (!str.equals("Bundle-Version")) break;  return KEY_BUNDLE_VERSION;case -24498221: if (!str.equals("Bundle-ActivationPolicy")) break;  return KEY_BUNDLE_ACTIVATIONPOLICY;case 139574604: if (!str.equals("event.filter")) break;  return KEY_EVENT_FILTER;case 142449453: if (!str.equals("Export-Package")) break;  return KEY_BUNDLE_EXPORT_PACKAGE;case 512727619: if (!str.equals("service.description")) break;  return KEY_SERVICE_DESCRIPTION;case 546032376: if (!str.equals("event.topics")) break;  return KEY_EVENT_TOPICS;case 586359206: if (!str.equals("service.changecount")) break;  return KEY_SERVICE_CHANGECOUNT;case 709041661: if (!str.equals("service.ranking")) break;  return KEY_SERVICE_RANKING;case 1003645754: if (!str.equals("Manifest-Version")) break;  return KEY_JAR_MANIFESTVERSION;case 1168201179: if (!str.equals("service.scope")) break;  return KEY_SERVICE_SCOPE;case 1270708017: if (!str.equals("Bundle-Description")) break;  return KEY_BUNDLE_DESCRIPTION;case 1297888712: if (!str.equals("Bundle-SymbolicName")) break;  return KEY_BUNDLE_SYMBOLICNAME;case 1324887260: if (!str.equals("component.name")) break;  return KEY_COMPONENT_NAME;case 1347648030: if (!str.equals("Import-Package")) break;  return KEY_BUNDLE_IMPORT_PACKAGE;case 1375570166: if (!str.equals("Bundle-Name")) break;  return KEY_BUNDLE_NAME;case 1721360888: if (!str.equals("metatype.factory.pid")) break;  return KEY_METATYPE_FACTORY_PID;case 1846557188: if (!str.equals("Bundle-Localization"))
/*     */           break;  return KEY_BUNDLE_LOCALIZATION;case 1942191777: if (!str.equals("service.vendor"))
/* 186 */           break;  return KEY_SERVICE_VENDER; }  return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CaseInsensitiveDictionaryMap()
/*     */   {
/* 396 */     this.entrySet = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 410 */     this.keySet = null; this.map = new HashMap<>(); } public CaseInsensitiveDictionaryMap(int initialCapacity) { this.entrySet = null; this.keySet = null; this.map = new HashMap<>(initialCapacity); }
/*     */   public CaseInsensitiveDictionaryMap(Dictionary<? extends K, ? extends V> dictionary) { this(initialCapacity(dictionary.size())); Enumeration<? extends K> keys = dictionary.keys(); while (keys.hasMoreElements()) { K key = keys.nextElement(); if (key != null) { V value = dictionary.get(key); if (value != null && put(key, value) != null) throw new IllegalArgumentException(NLS.bind(Msg.HEADER_DUPLICATE_KEY_EXCEPTION, key));  }  }  }
/*     */   public CaseInsensitiveDictionaryMap(Map<? extends K, ? extends V> map) { this(initialCapacity(map.size())); for (Map.Entry<? extends K, ? extends V> e : map.entrySet()) { K key = e.getKey(); if (key != null) { V value = e.getValue(); if (value != null && put(key, value) != null) throw new IllegalArgumentException(NLS.bind(Msg.HEADER_DUPLICATE_KEY_EXCEPTION, key));  }  }  }
/*     */   protected static int initialCapacity(int size) { return Math.max((int)(size / 0.75F) + 1, 16); }
/*     */   public Enumeration<K> keys() { return Collections.enumeration(keySet()); }
/*     */   public Enumeration<V> elements() { return Collections.enumeration(values()); }
/*     */   public V get(Object key) { return this.map.get(keyWrap(key)); }
/* 417 */   private Object keyWrap(Object key) { if (key instanceof String) { CaseInsensitiveKey commonKey = findCommonKeyIndex((String)key); if (commonKey != null) return commonKey;  return new CaseInsensitiveKey((String)key); }  return key; } public int size() { return this.map.size(); } public Set<K> keySet() { Set<K> ks = this.keySet;
/* 418 */     if (ks == null) {
/* 419 */       return this.keySet = new KeySet();
/*     */     }
/* 421 */     return ks; }
/*     */   public boolean isEmpty() { return this.map.isEmpty(); }
/*     */   public V put(K key, V value) { Objects.requireNonNull(value); if (key instanceof String) { Object wrappedKey = keyWrap(key); V existing = this.map.put(wrappedKey, value); if (existing != null) { this.map.remove(wrappedKey); this.map.put(wrappedKey, value); }  return existing; }  return this.map.put(Objects.requireNonNull(key), value); }
/*     */   public V remove(Object key) { return this.map.remove(keyWrap(key)); }
/*     */   public String toString() { return this.map.toString(); }
/*     */   public void clear() { this.map.clear(); }
/*     */   public boolean containsKey(Object key) { return this.map.containsKey(keyWrap(key)); }
/*     */   public boolean containsValue(Object value) { return this.map.containsValue(value); }
/* 429 */   public Set<Map.Entry<K, V>> entrySet() { Set<Map.Entry<K, V>> es = this.entrySet; if (es == null) return this.entrySet = new EntrySet();  return es; } public Collection<V> values() { return this.map.values(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void putAll(Map<? extends K, ? extends V> m) {
/* 440 */     for (Map.Entry<? extends K, ? extends V> e : m.entrySet()) {
/* 441 */       put(e.getKey(), e.getValue());
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 450 */     return this.map.hashCode();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object obj) {
/* 458 */     if (this == obj) {
/* 459 */       return true;
/*     */     }
/* 461 */     return this.map.equals(obj);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<K, V> asUnmodifiableMap() {
/* 470 */     return Collections.unmodifiableMap(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Dictionary<K, V> asUnmodifiableDictionary() {
/* 479 */     return unmodifiableDictionary(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <K, V> Dictionary<K, V> unmodifiableDictionary(Dictionary<? extends K, ? extends V> d) {
/* 488 */     return new UnmodifiableDictionary<>(d);
/*     */   }
/*     */   
/*     */   private static final class UnmodifiableDictionary<K, V> extends Dictionary<K, V> {
/*     */     private final Dictionary<? extends K, ? extends V> d;
/*     */     
/*     */     UnmodifiableDictionary(Dictionary<? extends K, ? extends V> d) {
/* 495 */       this.d = Objects.<Dictionary<? extends K, ? extends V>>requireNonNull(d);
/*     */     }
/*     */ 
/*     */     
/*     */     public int size() {
/* 500 */       return this.d.size();
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isEmpty() {
/* 505 */       return this.d.isEmpty();
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public Enumeration<K> keys() {
/* 511 */       return (Enumeration)this.d.keys();
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public Enumeration<V> elements() {
/* 517 */       return (Enumeration)this.d.elements();
/*     */     }
/*     */ 
/*     */     
/*     */     public V get(Object key) {
/* 522 */       return this.d.get(key);
/*     */     }
/*     */ 
/*     */     
/*     */     public V put(K key, V value) {
/* 527 */       throw new UnsupportedOperationException();
/*     */     }
/*     */ 
/*     */     
/*     */     public V remove(Object key) {
/* 532 */       throw new UnsupportedOperationException();
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/* 537 */       return this.d.toString();
/*     */     }
/*     */ 
/*     */     
/*     */     public int hashCode() {
/* 542 */       return this.d.hashCode();
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean equals(Object obj) {
/* 547 */       if (this == obj) {
/* 548 */         return true;
/*     */       }
/* 550 */       return this.d.equals(obj);
/*     */     }
/*     */   }
/*     */   
/*     */   static int computeHashCode(String key) {
/* 555 */     int h = 1; byte b; int i; char[] arrayOfChar;
/* 556 */     for (i = (arrayOfChar = key.toCharArray()).length, b = 0; b < i; ) { char c = arrayOfChar[b];
/* 557 */       if (c < '') {
/* 558 */         if (c >= 'A' && c <= 'Z') {
/* 559 */           c = (char)(c + 32);
/*     */         }
/*     */       } else {
/* 562 */         c = Character.toLowerCase(Character.toUpperCase(c));
/*     */       } 
/* 564 */       h = 31 * h + c; b++; }
/*     */     
/* 566 */     return h;
/*     */   }
/*     */   
/*     */   private static final class CaseInsensitiveKey {
/*     */     final String key;
/*     */     private final int hashCode;
/*     */     
/*     */     CaseInsensitiveKey(String key) {
/* 574 */       this.key = key;
/* 575 */       this.hashCode = CaseInsensitiveDictionaryMap.computeHashCode(key);
/*     */     }
/*     */ 
/*     */     
/*     */     public int hashCode() {
/* 580 */       return this.hashCode;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean equals(Object obj) {
/* 585 */       if (this == obj) {
/* 586 */         return true;
/*     */       }
/* 588 */       if (obj instanceof CaseInsensitiveKey) {
/* 589 */         return this.key.equalsIgnoreCase(((CaseInsensitiveKey)obj).key);
/*     */       }
/* 591 */       return false;
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/* 596 */       return this.key;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private final class KeySet
/*     */     extends AbstractSet<K>
/*     */   {
/*     */     public int size() {
/* 606 */       return CaseInsensitiveDictionaryMap.this.size();
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isEmpty() {
/* 611 */       return CaseInsensitiveDictionaryMap.this.isEmpty();
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean contains(Object o) {
/* 616 */       return CaseInsensitiveDictionaryMap.this.containsKey(o);
/*     */     }
/*     */ 
/*     */     
/*     */     public Iterator<K> iterator() {
/* 621 */       return new CaseInsensitiveDictionaryMap.KeyIterator<>(CaseInsensitiveDictionaryMap.this.map.keySet());
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean remove(Object o) {
/* 626 */       return (CaseInsensitiveDictionaryMap.this.remove(o) != null);
/*     */     }
/*     */ 
/*     */     
/*     */     public void clear() {
/* 631 */       CaseInsensitiveDictionaryMap.this.clear();
/*     */     }
/*     */   }
/*     */   
/*     */   private static final class KeyIterator<K> implements Iterator<K> {
/*     */     private final Iterator<Object> i;
/*     */     
/*     */     KeyIterator(Collection<Object> c) {
/* 639 */       this.i = c.iterator();
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean hasNext() {
/* 644 */       return this.i.hasNext();
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public K next() {
/* 650 */       Object k = this.i.next();
/* 651 */       if (k instanceof CaseInsensitiveDictionaryMap.CaseInsensitiveKey) {
/* 652 */         k = ((CaseInsensitiveDictionaryMap.CaseInsensitiveKey)k).key;
/*     */       }
/* 654 */       return (K)k;
/*     */     }
/*     */ 
/*     */     
/*     */     public void remove() {
/* 659 */       this.i.remove();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private final class EntrySet
/*     */     extends AbstractSet<Map.Entry<K, V>>
/*     */   {
/*     */     public int size() {
/* 669 */       return CaseInsensitiveDictionaryMap.this.size();
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isEmpty() {
/* 674 */       return CaseInsensitiveDictionaryMap.this.isEmpty();
/*     */     }
/*     */ 
/*     */     
/*     */     public Iterator<Map.Entry<K, V>> iterator() {
/* 679 */       return new CaseInsensitiveDictionaryMap.EntryIterator<>(CaseInsensitiveDictionaryMap.this.map.entrySet());
/*     */     }
/*     */ 
/*     */     
/*     */     public void clear() {
/* 684 */       CaseInsensitiveDictionaryMap.this.clear();
/*     */     }
/*     */   }
/*     */   
/*     */   private static final class EntryIterator<K, V> implements Iterator<Map.Entry<K, V>> {
/*     */     private final Iterator<Map.Entry<Object, V>> i;
/*     */     
/*     */     EntryIterator(Collection<Map.Entry<Object, V>> c) {
/* 692 */       this.i = c.iterator();
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean hasNext() {
/* 697 */       return this.i.hasNext();
/*     */     }
/*     */ 
/*     */     
/*     */     public Map.Entry<K, V> next() {
/* 702 */       return new CaseInsensitiveDictionaryMap.CaseInsentiveEntry<>(this.i.next());
/*     */     }
/*     */ 
/*     */     
/*     */     public void remove() {
/* 707 */       this.i.remove();
/*     */     }
/*     */   }
/*     */   
/*     */   private static final class CaseInsentiveEntry<K, V> implements Map.Entry<K, V> {
/*     */     private final Map.Entry<Object, V> entry;
/*     */     
/*     */     CaseInsentiveEntry(Map.Entry<Object, V> entry) {
/* 715 */       this.entry = entry;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public K getKey() {
/* 721 */       Object k = this.entry.getKey();
/* 722 */       if (k instanceof CaseInsensitiveDictionaryMap.CaseInsensitiveKey) {
/* 723 */         k = ((CaseInsensitiveDictionaryMap.CaseInsensitiveKey)k).key;
/*     */       }
/* 725 */       return (K)k;
/*     */     }
/*     */ 
/*     */     
/*     */     public V getValue() {
/* 730 */       return this.entry.getValue();
/*     */     }
/*     */ 
/*     */     
/*     */     public V setValue(V value) {
/* 735 */       return this.entry.setValue(Objects.requireNonNull(value));
/*     */     }
/*     */ 
/*     */     
/*     */     public int hashCode() {
/* 740 */       return Objects.hashCode(this.entry.getKey()) ^ Objects.hashCode(this.entry.getValue());
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean equals(Object obj) {
/* 745 */       if (obj instanceof Map.Entry) {
/* 746 */         Map.Entry<?, ?> other = (Map.Entry<?, ?>)obj;
/* 747 */         Object k1 = this.entry.getKey();
/*     */         
/* 749 */         Object k2 = (other instanceof CaseInsentiveEntry) ? ((CaseInsentiveEntry)other).entry.getKey() : other.getKey();
/* 750 */         return (Objects.equals(k1, k2) && Objects.equals(this.entry.getValue(), other.getValue()));
/*     */       } 
/* 752 */       return false;
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/* 757 */       return this.entry.toString();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.osgi-3.18.400.jar!\org\eclipse\osgi\framewor\\util\CaseInsensitiveDictionaryMap.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */