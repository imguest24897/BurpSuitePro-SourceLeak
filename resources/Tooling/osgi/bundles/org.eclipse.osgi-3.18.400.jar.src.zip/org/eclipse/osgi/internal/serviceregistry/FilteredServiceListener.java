/*     */ package org.eclipse.osgi.internal.serviceregistry;
/*     */ 
/*     */ import org.eclipse.osgi.internal.debug.Debug;
/*     */ import org.eclipse.osgi.internal.framework.BundleContextImpl;
/*     */ import org.eclipse.osgi.internal.framework.FilterImpl;
/*     */ import org.osgi.framework.BundleContext;
/*     */ import org.osgi.framework.Filter;
/*     */ import org.osgi.framework.InvalidSyntaxException;
/*     */ import org.osgi.framework.ServiceEvent;
/*     */ import org.osgi.framework.ServiceListener;
/*     */ import org.osgi.framework.ServiceReference;
/*     */ import org.osgi.framework.hooks.service.ListenerHook;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class FilteredServiceListener
/*     */   implements ServiceListener, ListenerHook.ListenerInfo
/*     */ {
/*     */   private final FilterImpl filter;
/*     */   private final ServiceListener listener;
/*     */   private final BundleContextImpl context;
/*     */   private final boolean allservices;
/*     */   private final boolean unfiltered;
/*     */   private final String objectClass;
/*     */   private volatile boolean removed;
/*     */   private final Debug debug;
/*     */   
/*     */   FilteredServiceListener(BundleContextImpl context, ServiceListener listener, String filterstring) throws InvalidSyntaxException {
/*  59 */     this.debug = context.getContainer().getConfiguration().getDebug();
/*  60 */     this.unfiltered = listener instanceof org.osgi.framework.UnfilteredServiceListener;
/*  61 */     if (filterstring == null) {
/*  62 */       this.filter = null;
/*  63 */       this.objectClass = null;
/*     */     } else {
/*  65 */       FilterImpl filterImpl = FilterImpl.newInstance(filterstring, (context.getContainer().getConfiguration().getDebug()).DEBUG_FILTER);
/*  66 */       String clazz = filterImpl.getRequiredObjectClass();
/*  67 */       if (this.unfiltered || clazz == null) {
/*  68 */         this.objectClass = null;
/*  69 */         this.filter = filterImpl;
/*     */       } else {
/*  71 */         this.objectClass = clazz.intern();
/*     */ 
/*     */ 
/*     */         
/*  75 */         this.filter = filterImpl.getChildren().isEmpty() ? null : filterImpl;
/*     */       } 
/*     */     } 
/*  78 */     this.removed = false;
/*  79 */     this.listener = listener;
/*  80 */     this.context = context;
/*  81 */     this.allservices = listener instanceof org.osgi.framework.AllServiceListener;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void serviceChanged(ServiceEvent event) {
/*  91 */     ServiceReferenceImpl<?> reference = (ServiceReferenceImpl)event.getServiceReference();
/*     */ 
/*     */     
/*  94 */     if (this.objectClass != null) {
/*  95 */       String[] classes = reference.getClasses();
/*  96 */       int size = classes.length;
/*  97 */       int i = 0; while (true) { if (i >= size)
/*  98 */           return;  if (classes[i] == this.objectClass) {
/*     */           break;
/*     */         }
/*     */         
/*     */         i++; }
/*     */     
/*     */     } 
/* 105 */     if (!ServiceRegistry.hasListenServicePermission(event, this.context)) {
/*     */       return;
/*     */     }
/* 108 */     if (this.debug.DEBUG_EVENTS) {
/* 109 */       String listenerName = String.valueOf(getClass().getName()) + "@" + Integer.toHexString(System.identityHashCode(this));
/* 110 */       Debug.println("filterServiceEvent(" + listenerName + ", \"" + getFilter() + "\", " + reference.getRegistration().getProperties() + ")");
/*     */     } 
/*     */     
/* 113 */     event = filterMatch(event);
/* 114 */     if (event == null) {
/*     */       return;
/*     */     }
/* 117 */     if (this.allservices || ServiceRegistry.isAssignableTo(this.context, this.objectClass, reference)) {
/* 118 */       if (this.debug.DEBUG_EVENTS) {
/* 119 */         String listenerName = String.valueOf(this.listener.getClass().getName()) + "@" + Integer.toHexString(System.identityHashCode(this.listener));
/* 120 */         Debug.println("dispatchFilteredServiceEvent(" + listenerName + ")");
/*     */       } 
/*     */       
/* 123 */       this.listener.serviceChanged(event);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ServiceEvent filterMatch(ServiceEvent delivered) {
/* 135 */     boolean modified = (delivered.getType() == 2);
/* 136 */     ServiceEvent event = modified ? ((ModifiedServiceEvent)delivered).getModifiedEvent() : delivered;
/* 137 */     if (this.unfiltered || this.filter == null) {
/* 138 */       return event;
/*     */     }
/* 140 */     ServiceReference<?> reference = event.getServiceReference();
/* 141 */     if (this.filter.match(reference)) {
/* 142 */       return event;
/*     */     }
/* 144 */     if (modified) {
/* 145 */       ModifiedServiceEvent modifiedServiceEvent = (ModifiedServiceEvent)delivered;
/* 146 */       if (modifiedServiceEvent.matchPreviousProperties((Filter)this.filter)) {
/* 147 */         return modifiedServiceEvent.getModifiedEndMatchEvent();
/*     */       }
/*     */     } 
/*     */     
/* 151 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 161 */     String filterString = getFilter();
/* 162 */     if (filterString == null) {
/* 163 */       filterString = "";
/*     */     }
/* 165 */     return String.valueOf(this.listener.getClass().getName()) + "@" + Integer.toHexString(System.identityHashCode(this.listener)) + filterString;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BundleContext getBundleContext() {
/* 175 */     return (BundleContext)this.context;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getFilter() {
/* 186 */     if (this.filter != null) {
/* 187 */       return this.filter.toString();
/*     */     }
/* 189 */     return getObjectClassFilterString(this.objectClass);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isRemoved() {
/* 204 */     return this.removed;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void markRemoved() {
/* 211 */     this.removed = true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static String getObjectClassFilterString(String className) {
/* 220 */     if (className == null) {
/* 221 */       return null;
/*     */     }
/* 223 */     return "(objectClass=" + className + ")";
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.osgi-3.18.400.jar!\org\eclipse\osgi\internal\serviceregistry\FilteredServiceListener.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */