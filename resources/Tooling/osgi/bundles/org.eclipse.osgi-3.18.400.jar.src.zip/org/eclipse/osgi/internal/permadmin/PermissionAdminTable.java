/*    */ package org.eclipse.osgi.internal.permadmin;
/*    */ 
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ import org.osgi.service.permissionadmin.PermissionInfo;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PermissionAdminTable
/*    */ {
/* 21 */   private final Map<String, PermissionInfoCollection> locations = new HashMap<>();
/*    */   
/*    */   String[] getLocations() {
/* 24 */     return (String[])this.locations.keySet().toArray((Object[])new String[this.locations.size()]);
/*    */   }
/*    */   
/*    */   PermissionInfo[] getPermissions(String location) {
/* 28 */     PermissionInfoCollection collection = this.locations.get(location);
/* 29 */     if (collection != null)
/* 30 */       return collection.getPermissionInfos(); 
/* 31 */     return null;
/*    */   }
/*    */   
/*    */   void setPermissions(String location, PermissionInfo[] permissions) {
/* 35 */     if (permissions == null) {
/* 36 */       this.locations.remove(location);
/*    */       return;
/*    */     } 
/* 39 */     this.locations.put(location, new PermissionInfoCollection(permissions));
/*    */   }
/*    */   
/*    */   PermissionInfoCollection getCollection(String location) {
/* 43 */     return this.locations.get(location);
/*    */   }
/*    */   
/*    */   PermissionInfoCollection[] getCollections() {
/* 47 */     String[] currentLocations = getLocations();
/* 48 */     PermissionInfoCollection[] results = new PermissionInfoCollection[currentLocations.length];
/* 49 */     for (int i = 0; i < results.length; i++)
/* 50 */       results[i] = getCollection(currentLocations[i]); 
/* 51 */     return results;
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.osgi-3.18.400.jar!\org\eclipse\osgi\internal\permadmin\PermissionAdminTable.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */