/*    */ package org.eclipse.osgi.internal.framework;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.util.concurrent.ScheduledExecutorService;
/*    */ import java.util.concurrent.ScheduledFuture;
/*    */ import java.util.concurrent.TimeUnit;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class StorageSaver
/*    */ {
/*    */   private final EquinoxContainer container;
/*    */   private final long delay;
/*    */   private final ScheduledFuture<?> future;
/*    */   private final Thread hook;
/*    */   private final StorageSaverTask task;
/*    */   
/*    */   private static class StorageSaverTask
/*    */     implements Runnable
/*    */   {
/*    */     private final EquinoxContainer container;
/*    */     
/*    */     public StorageSaverTask(EquinoxContainer container) {
/* 25 */       this.container = container;
/*    */     }
/*    */ 
/*    */     
/*    */     public void run() {
/*    */       try {
/* 31 */         this.container.getStorage().save();
/* 32 */       } catch (IOException e) {
/* 33 */         this.container.getLogServices().log("org.eclipse.osgi", 4, "Error saving on update", e);
/*    */       } 
/*    */     }
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public StorageSaver(EquinoxContainer container) {
/* 45 */     this.container = container;
/* 46 */     this.task = new StorageSaverTask(container);
/* 47 */     this.delay = computeDelay();
/* 48 */     this.future = scheduleTask();
/* 49 */     this.hook = registerShutdownHook();
/*    */   }
/*    */   
/*    */   public void close() {
/* 53 */     unregisterShutdownHook();
/* 54 */     unscheduleTask();
/*    */   }
/*    */   
/*    */   public void save() {
/* 58 */     if (this.delay != 0L) {
/*    */       return;
/*    */     }
/*    */     
/* 62 */     this.task.run();
/*    */   }
/*    */   
/*    */   private Thread registerShutdownHook() {
/* 66 */     Thread thread = new Thread(this.task, "Equinox Shutdown Hook");
/* 67 */     Runtime.getRuntime().addShutdownHook(thread);
/* 68 */     return thread;
/*    */   }
/*    */   
/*    */   private long computeDelay() {
/* 72 */     EquinoxConfiguration configuration = this.container.getConfiguration();
/*    */     
/* 74 */     String delayProp = configuration.getConfiguration("eclipse.stateSaveDelayInterval");
/*    */     
/* 76 */     return Long.parseLong(delayProp);
/*    */   }
/*    */ 
/*    */   
/*    */   private ScheduledFuture<?> scheduleTask() {
/* 81 */     if (this.delay <= 0L)
/* 82 */       return null; 
/* 83 */     ScheduledExecutorService executor = this.container.getScheduledExecutor();
/* 84 */     return executor.scheduleWithFixedDelay(this.task, this.delay, this.delay, TimeUnit.MILLISECONDS);
/*    */   }
/*    */   
/*    */   private void unregisterShutdownHook() {
/*    */     try {
/* 89 */       Runtime.getRuntime().removeShutdownHook(this.hook);
/* 90 */     } catch (IllegalStateException illegalStateException) {}
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   private void unscheduleTask() {
/* 96 */     if (this.future != null)
/* 97 */       this.future.cancel(false); 
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.osgi-3.18.400.jar!\org\eclipse\osgi\internal\framework\StorageSaver.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */