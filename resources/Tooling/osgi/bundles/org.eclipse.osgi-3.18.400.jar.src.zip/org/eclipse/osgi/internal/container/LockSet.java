/*     */ package org.eclipse.osgi.internal.container;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ import java.util.concurrent.atomic.AtomicInteger;
/*     */ import java.util.concurrent.locks.ReentrantLock;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LockSet<T>
/*     */ {
/*     */   static final class LockHolder
/*     */   {
/*  36 */     private final AtomicInteger useCount = new AtomicInteger(0);
/*  37 */     private final ReentrantLock lock = new ReentrantLock();
/*     */     
/*     */     int incrementUseCount() {
/*  40 */       return this.useCount.incrementAndGet();
/*     */     }
/*     */     
/*     */     int decremementUseCount() {
/*  44 */       return this.useCount.decrementAndGet();
/*     */     }
/*     */     
/*     */     boolean tryLock(long time, TimeUnit unit) throws InterruptedException {
/*  48 */       return (!this.lock.isHeldByCurrentThread() && this.lock.tryLock(time, unit));
/*     */     }
/*     */     
/*     */     void unlock() {
/*  52 */       this.lock.unlock();
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/*  57 */       return this.lock.toString();
/*     */     }
/*     */   }
/*     */   
/*  61 */   private final Map<T, LockHolder> locks = new HashMap<>();
/*     */   
/*     */   public boolean tryLock(T t, long time, TimeUnit unit) throws InterruptedException {
/*  64 */     boolean previousInterruption = Thread.interrupted();
/*     */     try {
/*     */       LockHolder lock;
/*  67 */       synchronized (this.locks) {
/*  68 */         lock = this.locks.get(t);
/*  69 */         if (lock == null) {
/*  70 */           lock = new LockHolder();
/*  71 */           this.locks.put(t, lock);
/*     */         } 
/*  73 */         lock.incrementUseCount();
/*     */       } 
/*     */       
/*  76 */       boolean acquired = false;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     }
/*     */     finally {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*  91 */       if (previousInterruption) {
/*  92 */         Thread.currentThread().interrupt();
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   public void unlock(T t) {
/*  98 */     synchronized (this.locks) {
/*  99 */       LockHolder lock = this.locks.get(t);
/* 100 */       if (lock == null)
/* 101 */         throw new IllegalStateException("No lock found: " + t); 
/* 102 */       lock.unlock();
/*     */       
/* 104 */       if (lock.decremementUseCount() == 0) {
/* 105 */         this.locks.remove(t);
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   public String getLockInfo(T t) {
/* 111 */     synchronized (this.locks) {
/* 112 */       return String.valueOf(this.locks.get(t));
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.osgi-3.18.400.jar!\org\eclipse\osgi\internal\container\LockSet.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */