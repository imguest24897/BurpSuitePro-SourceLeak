/*     */ package org.eclipse.osgi.storage.bundlefile;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.util.Collections;
/*     */ import java.util.Enumeration;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.Map;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import org.eclipse.osgi.internal.messages.Msg;
/*     */ import org.eclipse.osgi.util.NLS;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DirBundleFile
/*     */   extends BundleFile
/*     */ {
/*     */   private static final String POINTER_SAME_DIRECTORY_1 = "/.";
/*     */   private static final String POINTER_SAME_DIRECTORY_2 = "//";
/*     */   private static final String POINTER_UPPER_DIRECTORY = "..";
/*     */   private final boolean enableStrictBundleEntryPath;
/*  37 */   private final Map<File, Boolean> doesNotExistCache = new ConcurrentHashMap<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DirBundleFile(File basefile, boolean enableStrictBundleEntryPath) throws IOException {
/*  45 */     super(getBaseFile(basefile, enableStrictBundleEntryPath));
/*  46 */     if (!BundleFile.secureAction.exists(basefile) || !BundleFile.secureAction.isDirectory(basefile)) {
/*  47 */       throw new IOException(NLS.bind(Msg.ADAPTOR_DIRECTORY_EXCEPTION, basefile));
/*     */     }
/*  49 */     this.enableStrictBundleEntryPath = enableStrictBundleEntryPath;
/*     */   }
/*     */   
/*     */   private static File getBaseFile(File basefile, boolean enableStrictBundleEntryPath) throws IOException {
/*  53 */     return enableStrictBundleEntryPath ? secureAction.getCanonicalFile(basefile) : basefile;
/*     */   }
/*     */ 
/*     */   
/*     */   public File getFile(String path, boolean nativeCode) {
/*  58 */     boolean checkInBundle = (path != null && path.indexOf("..") >= 0);
/*  59 */     File file = new File(this.basefile, path);
/*  60 */     File parentFile = file.getParentFile();
/*  61 */     if (!parentExists(parentFile)) {
/*  62 */       return null;
/*     */     }
/*  64 */     if (!BundleFile.secureAction.exists(file)) {
/*  65 */       cacheIfParentExists(parentFile);
/*  66 */       return null;
/*     */     } 
/*     */     
/*  69 */     if (!this.enableStrictBundleEntryPath) {
/*     */       
/*  71 */       if (checkInBundle && !isInBundle(file)) {
/*  72 */         return null;
/*     */       }
/*  74 */       return file;
/*     */     } 
/*  76 */     boolean normalize = false;
/*  77 */     boolean isBundleRoot = false;
/*  78 */     if (path != null) {
/*  79 */       isBundleRoot = path.equals("/");
/*  80 */       if (!isBundleRoot) {
/*  81 */         normalize = !(!checkInBundle && path.indexOf("/.") < 0 && path.indexOf("//") < 0);
/*     */       }
/*     */     } 
/*     */     
/*     */     try {
/*  86 */       File canonicalFile = BundleFile.secureAction.getCanonicalFile(file);
/*  87 */       if (!isBundleRoot) {
/*  88 */         String canonicalPath, absolutePath; File absoluteFile = BundleFile.secureAction.getAbsoluteFile(file);
/*     */ 
/*     */         
/*  91 */         if (normalize) {
/*  92 */           canonicalPath = canonicalFile.toURI().getPath();
/*  93 */           absolutePath = absoluteFile.toURI().normalize().getPath();
/*     */         } else {
/*  95 */           canonicalPath = canonicalFile.getPath();
/*  96 */           absolutePath = absoluteFile.getPath();
/*     */         } 
/*  98 */         if (!canonicalPath.equals(absolutePath)) {
/*  99 */           return null;
/*     */         }
/*     */       } 
/*     */       
/* 103 */       if (checkInBundle && !isInBundle(file)) {
/* 104 */         return null;
/*     */       }
/* 106 */     } catch (IOException iOException) {
/* 107 */       return null;
/*     */     } 
/*     */     
/* 110 */     return file;
/*     */   }
/*     */   
/*     */   boolean isInBundle(File file) {
/*     */     try {
/* 115 */       String canonicalizedRoot = BundleFile.secureAction.getCanonicalPath(this.basefile);
/* 116 */       if (!canonicalizedRoot.endsWith(File.separator)) {
/* 117 */         canonicalizedRoot = String.valueOf(canonicalizedRoot) + File.separator;
/*     */       }
/* 119 */       String canonicalizedChild = BundleFile.secureAction.getCanonicalPath(file);
/* 120 */       if (BundleFile.secureAction.isDirectory(file) && !canonicalizedChild.endsWith(File.separator)) {
/* 121 */         canonicalizedChild = String.valueOf(canonicalizedChild) + File.separator;
/*     */       }
/* 123 */       if (!canonicalizedChild.startsWith(canonicalizedRoot)) {
/* 124 */         return false;
/*     */       }
/* 126 */     } catch (IOException iOException) {
/* 127 */       return false;
/*     */     } 
/* 129 */     return true;
/*     */   }
/*     */   
/*     */   private void cacheIfParentExists(File parentFile) {
/* 133 */     this.doesNotExistCache.computeIfAbsent(parentFile, secureAction::isDirectory);
/*     */   }
/*     */   
/*     */   private boolean parentExists(File parentFile) {
/* 137 */     Boolean exists = this.doesNotExistCache.get(parentFile);
/* 138 */     return !(exists != null && !exists.booleanValue());
/*     */   }
/*     */ 
/*     */   
/*     */   public BundleEntry getEntry(String path) {
/* 143 */     File filePath = getFile(path, false);
/* 144 */     if (filePath == null)
/* 145 */       return null; 
/* 146 */     return new FileBundleEntry(filePath, path);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean containsDir(String dir) {
/* 151 */     File dirPath = getFile(dir, false);
/* 152 */     return (dirPath != null && BundleFile.secureAction.isDirectory(dirPath));
/*     */   }
/*     */ 
/*     */   
/*     */   public Enumeration<String> getEntryPaths(String path, boolean recurse) {
/* 157 */     if (path.length() > 0 && path.charAt(0) == '/')
/* 158 */       path = path.substring(1); 
/* 159 */     File pathFile = getFile(path, false);
/* 160 */     if (pathFile == null || !BundleFile.secureAction.isDirectory(pathFile))
/* 161 */       return null; 
/* 162 */     String[] fileList = BundleFile.secureAction.list(pathFile);
/* 163 */     if (fileList == null || fileList.length == 0)
/* 164 */       return null; 
/* 165 */     String dirPath = (path.length() == 0 || path.charAt(path.length() - 1) == '/') ? path : (String.valueOf(path) + '/');
/*     */     
/* 167 */     LinkedHashSet<String> entries = new LinkedHashSet<>(); byte b; int i; String[] arrayOfString1;
/* 168 */     for (i = (arrayOfString1 = fileList).length, b = 0; b < i; ) { String s = arrayOfString1[b];
/* 169 */       File childFile = new File(pathFile, s);
/* 170 */       StringBuilder sb = (new StringBuilder(dirPath)).append(s);
/* 171 */       if (BundleFile.secureAction.isDirectory(childFile)) {
/* 172 */         sb.append("/");
/* 173 */         if (recurse) {
/* 174 */           Enumeration<String> e = getEntryPaths(sb.toString(), true);
/* 175 */           if (e != null)
/* 176 */             entries.addAll(Collections.list(e)); 
/*     */         } 
/*     */       } 
/* 179 */       entries.add(sb.toString()); b++; }
/*     */     
/* 181 */     return Collections.enumeration(entries);
/*     */   }
/*     */   
/*     */   public void close() {}
/*     */   
/*     */   public void open() {}
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.osgi-3.18.400.jar!\org\eclipse\osgi\storage\bundlefile\DirBundleFile.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */