/*    */ package org.eclipse.osgi.framework.console;
/*    */ 
/*    */ import java.io.InputStream;
/*    */ import java.io.OutputStream;
/*    */ import org.osgi.framework.Bundle;
/*    */ import org.osgi.framework.ServiceFactory;
/*    */ import org.osgi.framework.ServiceRegistration;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class ConsoleSession
/*    */   implements ServiceFactory<Object>
/*    */ {
/*    */   private volatile ServiceRegistration<Object> sessionRegistration;
/*    */   
/*    */   public final void close() {
/* 44 */     doClose();
/* 45 */     ServiceRegistration<Object> current = this.sessionRegistration;
/* 46 */     if (current != null) {
/* 47 */       this.sessionRegistration = null;
/*    */       try {
/* 49 */         current.unregister();
/* 50 */       } catch (IllegalStateException illegalStateException) {}
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected abstract void doClose();
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public abstract InputStream getInput();
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public abstract OutputStream getOutput();
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public final Object getService(Bundle bundle, ServiceRegistration<Object> registration) {
/* 87 */     if (this.sessionRegistration == null)
/* 88 */       this.sessionRegistration = registration; 
/* 89 */     return this;
/*    */   }
/*    */   
/*    */   public final void ungetService(Bundle bundle, ServiceRegistration<Object> registration, Object service) {}
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.osgi-3.18.400.jar!\org\eclipse\osgi\framework\console\ConsoleSession.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */