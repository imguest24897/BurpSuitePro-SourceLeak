/*      */ package org.eclipse.osgi.container;
/*      */ 
/*      */ import java.security.Permission;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Arrays;
/*      */ import java.util.Collection;
/*      */ import java.util.Collections;
/*      */ import java.util.Comparator;
/*      */ import java.util.HashMap;
/*      */ import java.util.HashSet;
/*      */ import java.util.Iterator;
/*      */ import java.util.LinkedHashSet;
/*      */ import java.util.LinkedList;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.Set;
/*      */ import java.util.concurrent.Executor;
/*      */ import java.util.concurrent.RejectedExecutionException;
/*      */ import java.util.concurrent.ScheduledExecutorService;
/*      */ import java.util.concurrent.ScheduledFuture;
/*      */ import java.util.concurrent.TimeUnit;
/*      */ import java.util.concurrent.atomic.AtomicBoolean;
/*      */ import java.util.concurrent.atomic.AtomicReference;
/*      */ import org.apache.felix.resolver.Logger;
/*      */ import org.apache.felix.resolver.ResolutionError;
/*      */ import org.apache.felix.resolver.ResolverImpl;
/*      */ import org.eclipse.osgi.internal.container.InternalUtils;
/*      */ import org.eclipse.osgi.internal.container.NamespaceList;
/*      */ import org.eclipse.osgi.internal.debug.Debug;
/*      */ import org.eclipse.osgi.internal.messages.Msg;
/*      */ import org.eclipse.osgi.report.resolution.ResolutionReport;
/*      */ import org.eclipse.osgi.service.debug.DebugOptions;
/*      */ import org.osgi.framework.BundleException;
/*      */ import org.osgi.framework.Version;
/*      */ import org.osgi.framework.hooks.resolver.ResolverHook;
/*      */ import org.osgi.framework.wiring.BundleCapability;
/*      */ import org.osgi.framework.wiring.BundleRequirement;
/*      */ import org.osgi.resource.Capability;
/*      */ import org.osgi.resource.Requirement;
/*      */ import org.osgi.resource.Resource;
/*      */ import org.osgi.resource.Wire;
/*      */ import org.osgi.resource.Wiring;
/*      */ import org.osgi.service.resolver.HostedCapability;
/*      */ import org.osgi.service.resolver.ResolutionException;
/*      */ import org.osgi.service.resolver.ResolveContext;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ final class ModuleResolver
/*      */ {
/*   82 */   static final String SEPARATOR = System.lineSeparator();
/*      */   
/*      */   static final char TAB = '\t';
/*      */   
/*      */   private static final String OPTION_RESOLVER = "org.eclipse.osgi/resolver";
/*      */   
/*      */   private static final String OPTION_ROOTS = "org.eclipse.osgi/resolver/roots";
/*      */   private static final String OPTION_PROVIDERS = "org.eclipse.osgi/resolver/providers";
/*      */   private static final String OPTION_HOOKS = "org.eclipse.osgi/resolver/hooks";
/*      */   private static final String OPTION_USES = "org.eclipse.osgi/resolver/uses";
/*      */   private static final String OPTION_WIRING = "org.eclipse.osgi/resolver/wiring";
/*      */   private static final String OPTION_REPORT = "org.eclipse.osgi/resolver/report";
/*      */   boolean DEBUG_ROOTS = false;
/*      */   boolean DEBUG_PROVIDERS = false;
/*      */   boolean DEBUG_HOOKS = false;
/*      */   boolean DEBUG_USES = false;
/*      */   boolean DEBUG_WIRING = false;
/*      */   boolean DEBUG_REPORT = false;
/*      */   private static final int DEFAULT_BATCH_SIZE = 2147483647;
/*  101 */   private static final int BATCH_MIN_TIMEOUT = (int)TimeUnit.SECONDS.toMillis(5L);
/*  102 */   private static final int DEFAULT_BATCH_TIMEOUT = (int)TimeUnit.MINUTES.toMillis(2L);
/*      */   final int resolverRevisionBatchSize;
/*      */   final int resolverBatchTimeout;
/*      */   
/*      */   void setDebugOptions() {
/*  107 */     DebugOptions options = this.adaptor.getDebugOptions();
/*      */     
/*  109 */     if (options == null)
/*      */       return; 
/*  111 */     boolean debugAll = options.getBooleanOption("org.eclipse.osgi/resolver", false);
/*  112 */     this.DEBUG_ROOTS = !(!debugAll && !options.getBooleanOption("org.eclipse.osgi/resolver/roots", false));
/*  113 */     this.DEBUG_PROVIDERS = !(!debugAll && !options.getBooleanOption("org.eclipse.osgi/resolver/providers", false));
/*  114 */     this.DEBUG_HOOKS = !(!debugAll && !options.getBooleanOption("org.eclipse.osgi/resolver/hooks", false));
/*  115 */     this.DEBUG_USES = !(!debugAll && !options.getBooleanOption("org.eclipse.osgi/resolver/uses", false));
/*  116 */     this.DEBUG_WIRING = !(!debugAll && !options.getBooleanOption("org.eclipse.osgi/resolver/wiring", false));
/*  117 */     this.DEBUG_REPORT = !(!debugAll && !options.getBooleanOption("org.eclipse.osgi/resolver/report", false));
/*      */   }
/*      */   
/*  120 */   static final Collection<String> NON_PAYLOAD_CAPABILITIES = Arrays.asList(new String[] { "osgi.identity" });
/*  121 */   static final Collection<String> NON_PAYLOAD_REQUIREMENTS = Arrays.asList(new String[] { "osgi.wiring.host", "osgi.ee" });
/*  122 */   static final Collection<String> NON_SUBSTITUTED_REQUIREMENTS = Arrays.asList(new String[] { "osgi.wiring.package", "osgi.wiring.bundle" });
/*      */   
/*  124 */   final ThreadLocal<Boolean> threadResolving = new ThreadLocal<>();
/*      */ 
/*      */ 
/*      */   
/*      */   final ModuleContainerAdaptor adaptor;
/*      */ 
/*      */ 
/*      */   
/*      */   ModuleResolver(ModuleContainerAdaptor adaptor) {
/*  133 */     this.adaptor = adaptor;
/*      */     
/*  135 */     setDebugOptions();
/*      */     
/*  137 */     String batchSizeConfig = this.adaptor.getProperty("equinox.resolver.revision.batch.size");
/*  138 */     this.resolverRevisionBatchSize = parseInteger(batchSizeConfig, 2147483647, 1);
/*  139 */     String batchTimeoutConfig = this.adaptor.getProperty("equinox.resolver.batch.timeout");
/*  140 */     this.resolverBatchTimeout = parseInteger(batchTimeoutConfig, DEFAULT_BATCH_TIMEOUT, BATCH_MIN_TIMEOUT);
/*      */   }
/*      */ 
/*      */   
/*      */   private static int parseInteger(String sInteger, int defaultValue, int minValue) {
/*      */     try {
/*  146 */       int result = (sInteger == null) ? defaultValue : Integer.parseInt(sInteger);
/*  147 */       return (result < minValue) ? minValue : result;
/*  148 */     } catch (NumberFormatException numberFormatException) {
/*  149 */       return defaultValue;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   ModuleResolutionReport resolveDelta(Collection<ModuleRevision> triggers, boolean triggersMandatory, Collection<ModuleRevision> unresolved, Map<ModuleRevision, ModuleWiring> wiringCopy, ModuleDatabase moduleDatabase) {
/*  171 */     if (!triggersMandatory)
/*      */     {
/*  173 */       triggers = unresolved;
/*      */     }
/*  175 */     ResolveProcess resolveProcess = new ResolveProcess(unresolved, triggers, triggersMandatory, wiringCopy, moduleDatabase);
/*  176 */     return resolveProcess.resolve();
/*      */   }
/*      */   
/*      */   ModuleResolutionReport resolveDynamicDelta(ModuleRequirement.DynamicModuleRequirement dynamicReq, Collection<ModuleRevision> unresolved, Map<ModuleRevision, ModuleWiring> wiringCopy, ModuleDatabase moduleDatabase) {
/*  180 */     ResolveProcess resolveProcess = new ResolveProcess(unresolved, dynamicReq, wiringCopy, moduleDatabase);
/*  181 */     return resolveProcess.resolve();
/*      */   }
/*      */   
/*      */   Map<ModuleRevision, ModuleWiring> generateDelta(Map<Resource, List<Wire>> result, Map<ModuleRevision, ModuleWiring> wiringCopy) {
/*  185 */     Map<ModuleRevision, Map<ModuleCapability, List<ModuleWire>>> provided = new HashMap<>();
/*  186 */     Map<ModuleRevision, NamespaceList<ModuleWire>> required = new HashMap<>(result.size() * 4 / 3 + 1);
/*      */ 
/*      */     
/*  189 */     for (Map.Entry<Resource, List<Wire>> resultEntry : result.entrySet()) {
/*  190 */       ModuleRevision revision = (ModuleRevision)resultEntry.getKey();
/*  191 */       NamespaceList.Builder<ModuleWire> requiredWires = NamespaceList.Builder.create(NamespaceList.WIRE);
/*  192 */       for (Wire wire : resultEntry.getValue()) {
/*  193 */         ModuleWire moduleWire = new ModuleWire((ModuleCapability)wire.getCapability(), (ModuleRevision)wire.getProvider(), (ModuleRequirement)wire.getRequirement(), (ModuleRevision)wire.getRequirer());
/*  194 */         requiredWires.add(moduleWire);
/*  195 */         Map<ModuleCapability, List<ModuleWire>> providedWiresMap = provided.get(moduleWire.getProvider());
/*  196 */         if (providedWiresMap == null) {
/*  197 */           providedWiresMap = new HashMap<>();
/*  198 */           provided.put(moduleWire.getProvider(), providedWiresMap);
/*      */         } 
/*  200 */         List<ModuleWire> providedWires = providedWiresMap.get(moduleWire.getCapability());
/*  201 */         if (providedWires == null) {
/*  202 */           providedWires = new ArrayList<>();
/*  203 */           providedWiresMap.put(moduleWire.getCapability(), providedWires);
/*      */         } 
/*  205 */         providedWires.add(moduleWire);
/*      */       } 
/*  207 */       required.put(revision, requiredWires.build());
/*      */     } 
/*      */     
/*  210 */     Map<ModuleRevision, ModuleWiring> delta = new HashMap<>();
/*      */     
/*  212 */     for (ModuleRevision revision : required.keySet()) {
/*  213 */       ModuleWiring existingWiring = wiringCopy.get(revision);
/*  214 */       if (existingWiring == null) {
/*  215 */         delta.put(revision, createNewWiring(revision, provided, required));
/*      */         continue;
/*      */       } 
/*  218 */       delta.put(revision, createWiringDelta(revision, existingWiring, provided.get(revision), required.get(revision)));
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  224 */     for (ModuleRevision revision : provided.keySet()) {
/*  225 */       ModuleWiring existingWiring = wiringCopy.get(revision);
/*  226 */       if (existingWiring != null && !delta.containsKey(revision)) {
/*  227 */         delta.put(revision, createWiringDelta(revision, existingWiring, provided.get(revision), required.get(revision)));
/*      */       }
/*      */     } 
/*  230 */     return delta;
/*      */   }
/*      */ 
/*      */   
/*      */   private ModuleWiring createNewWiring(ModuleRevision revision, Map<ModuleRevision, Map<ModuleCapability, List<ModuleWire>>> provided, Map<ModuleRevision, NamespaceList<ModuleWire>> required) {
/*  235 */     Map<ModuleCapability, List<ModuleWire>> providedWireMap = provided.getOrDefault(revision, Collections.emptyMap());
/*  236 */     NamespaceList<ModuleWire> requiredWires = required.getOrDefault(revision, NamespaceList.empty(NamespaceList.WIRE));
/*      */     
/*  238 */     NamespaceList.Builder<ModuleCapability> capabilities = revision.getCapabilities().createBuilder();
/*  239 */     NamespaceList.Builder<ModuleRequirement> requirements = revision.getRequirements().createBuilder();
/*      */ 
/*      */     
/*  242 */     if ((0x1 & revision.getTypes()) != 0) {
/*  243 */       removePayloadContent(capabilities, requirements);
/*      */     } else {
/*      */       
/*  246 */       List<ModuleCapability> hostCapabilities = revision.getModuleCapabilities("osgi.wiring.host");
/*  247 */       ModuleCapability hostCapability = hostCapabilities.isEmpty() ? null : hostCapabilities.get(0);
/*  248 */       if (hostCapability != null) {
/*  249 */         addPayloadContent(providedWireMap.get(hostCapability), capabilities, requirements);
/*      */       }
/*      */     } 
/*      */     
/*  253 */     removeNonEffectiveCapabilities((Collection<ModuleCapability>)capabilities);
/*  254 */     removeNonEffectiveRequirements(requirements, requiredWires);
/*  255 */     Collection<String> substituted = removeSubstitutedCapabilities(capabilities, requiredWires);
/*      */     
/*  257 */     NamespaceList.Builder<ModuleWire> providedWires = NamespaceList.Builder.create(NamespaceList.WIRE);
/*  258 */     addProvidedWires(providedWireMap, providedWires, capabilities);
/*      */     
/*  260 */     InternalUtils.filterCapabilityPermissions((Collection)capabilities);
/*  261 */     return new ModuleWiring(revision, capabilities.build(), requirements.build(), providedWires.build(), 
/*  262 */         requiredWires, substituted);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static void removePayloadContent(NamespaceList.Builder<ModuleCapability> capabilities, NamespaceList.Builder<ModuleRequirement> requirements) {
/*  269 */     capabilities.removeNamespaceIf(namespace -> !NON_PAYLOAD_CAPABILITIES.contains(namespace));
/*  270 */     requirements.removeNamespaceIf(namespace -> !NON_PAYLOAD_REQUIREMENTS.contains(namespace));
/*      */   }
/*      */   
/*      */   private static Collection<String> removeSubstitutedCapabilities(NamespaceList.Builder<ModuleCapability> capabilities, NamespaceList<ModuleWire> requiredWires) {
/*  274 */     Collection<String> substituted = new ArrayList<>();
/*  275 */     for (ModuleWire moduleWire : requiredWires.getList("osgi.wiring.package")) {
/*  276 */       String packageName = (String)moduleWire.getCapability().getAttributes().get("osgi.wiring.package");
/*  277 */       capabilities.removeElementsOfNamespaceIf("osgi.wiring.package", capability -> {
/*      */             if (paramString.equals(capability.getAttributes().get("osgi.wiring.package"))) {
/*      */               if (!paramCollection.contains(paramString)) {
/*      */                 paramCollection.add(paramString);
/*      */               }
/*      */               
/*      */               return true;
/*      */             } 
/*      */             
/*      */             return false;
/*      */           });
/*      */     } 
/*  289 */     return substituted.isEmpty() ? Collections.<String>emptyList() : substituted;
/*      */   }
/*      */ 
/*      */   
/*      */   private static void removeNonEffectiveRequirements(NamespaceList.Builder<ModuleRequirement> requirements, NamespaceList<ModuleWire> requiredWires) {
/*  294 */     Set<ModuleRequirement> wireRequirements = new HashSet<>();
/*  295 */     for (ModuleWire mw : requiredWires.getList(null)) {
/*  296 */       wireRequirements.add(mw.getRequirement());
/*      */     }
/*  298 */     requirements.removeIf(requirement -> {
/*      */           Object effective = requirement.getDirectives().get("effective");
/*      */           if (effective != null && !"resolve".equals(effective)) {
/*      */             return true;
/*      */           }
/*      */           if (!paramSet.contains(requirement)) {
/*      */             if (!"osgi.wiring.package".equals(requirement.getNamespace())) {
/*      */               return true;
/*      */             }
/*      */             Object resolution = requirement.getDirectives().get("resolution");
/*      */             if (!"dynamic".equals(resolution)) {
/*      */               return true;
/*      */             }
/*      */           } 
/*      */           return false;
/*      */         });
/*      */   }
/*      */ 
/*      */   
/*      */   void removeNonEffectiveCapabilities(Collection<ModuleCapability> capabilities) {
/*  318 */     capabilities.removeIf(capability -> {
/*      */           Object effective = capability.getDirectives().get("effective");
/*      */           if (effective != null && !"resolve".equals(effective)) {
/*      */             if (this.DEBUG_PROVIDERS) {
/*      */               Debug.println("RESOLVER: Capability filtered because it was not effective" + SEPARATOR + '\t' + capability + SEPARATOR + '\t' + '\t' + "of resource" + SEPARATOR + '\t' + '\t' + '\t' + capability.getResource());
/*      */             }
/*      */             return true;
/*      */           } 
/*      */           return false;
/*      */         });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static void addPayloadContent(List<ModuleWire> hostWires, NamespaceList.Builder<ModuleCapability> capabilities, NamespaceList.Builder<ModuleRequirement> requirements) {
/*  338 */     if (hostWires == null)
/*      */       return; 
/*  340 */     for (ModuleWire hostWire : hostWires) {
/*      */ 
/*      */       
/*  343 */       NamespaceList<ModuleCapability> fragmentCapabilities = hostWire.getRequirer().getCapabilities();
/*  344 */       capabilities.addAllFiltered(fragmentCapabilities, n -> !NON_PAYLOAD_CAPABILITIES.contains(n), fc -> {
/*      */             Object effective = fc.getDirectives().get("effective");
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*  350 */             return !(effective != null && !"resolve".equals(effective));
/*      */           });
/*      */ 
/*      */       
/*  354 */       NamespaceList<ModuleRequirement> fragmentRequriements = hostWire.getRequirer().getRequirements();
/*  355 */       requirements.addAllFilteredAfterLastMatch(fragmentRequriements, n -> !NON_PAYLOAD_REQUIREMENTS.contains(n), fr -> {
/*      */             Object effective = fr.getDirectives().get("effective");
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*  361 */             return !(effective != null && !"resolve".equals(effective));
/*      */ 
/*      */           
/*  364 */           }(fr, r) -> !("osgi.wiring.package".equals(fr.getNamespace()) && !isDynamic((Requirement)fr) && isDynamic((Requirement)r)));
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   static boolean isDynamic(Requirement requirement) {
/*  370 */     return ("osgi.wiring.package".equals(requirement.getNamespace()) && "dynamic".equals(requirement.getDirectives().get("resolution")));
/*      */   }
/*      */ 
/*      */   
/*      */   private static void addProvidedWires(Map<ModuleCapability, List<ModuleWire>> toAdd, NamespaceList.Builder<ModuleWire> existing, NamespaceList.Builder<ModuleCapability> capabilities) {
/*  375 */     if (toAdd == null)
/*      */       return; 
/*  377 */     for (ModuleCapability capability : capabilities) {
/*  378 */       List<ModuleWire> newWires = toAdd.get(capability);
/*  379 */       if (newWires != null) {
/*  380 */         existing.addAll(newWires);
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   private static ModuleWiring createWiringDelta(ModuleRevision revision, ModuleWiring existingWiring, Map<ModuleCapability, List<ModuleWire>> providedWireMap, NamespaceList<ModuleWire> requiredWires) {
/*  387 */     NamespaceList.Builder<ModuleWire> existingProvidedWires = existingWiring.getProvidedWires().createBuilder();
/*  388 */     NamespaceList.Builder<ModuleCapability> existingCapabilities = existingWiring.getCapabilities().createBuilder();
/*  389 */     NamespaceList.Builder<ModuleWire> existingRequiredWires = existingWiring.getRequiredWires().createBuilder();
/*  390 */     NamespaceList.Builder<ModuleRequirement> existingRequirements = existingWiring.getRequirements().createBuilder();
/*      */ 
/*      */     
/*  393 */     if (providedWireMap != null) {
/*  394 */       List<ModuleCapability> hostCapabilities = revision.getModuleCapabilities("osgi.wiring.host");
/*  395 */       ModuleCapability hostCapability = hostCapabilities.isEmpty() ? null : hostCapabilities.get(0);
/*  396 */       List<ModuleWire> newHostWires = (hostCapability == null) ? null : providedWireMap.get(hostCapability);
/*  397 */       if (newHostWires != null) {
/*  398 */         addPayloadContent(newHostWires, existingCapabilities, existingRequirements);
/*      */       }
/*      */     } 
/*      */ 
/*      */     
/*  403 */     addProvidedWires(providedWireMap, existingProvidedWires, existingCapabilities);
/*      */ 
/*      */ 
/*      */     
/*  407 */     if (requiredWires != null) {
/*  408 */       existingRequiredWires.addAll(requiredWires);
/*      */     }
/*      */     
/*  411 */     InternalUtils.filterCapabilityPermissions((Collection)existingCapabilities);
/*  412 */     return new ModuleWiring(revision, existingCapabilities.build(), existingRequirements.build(), 
/*  413 */         existingProvidedWires.build(), existingRequiredWires.build(), existingWiring.getSubstitutedNames());
/*      */   }
/*      */   
/*      */   static boolean isSingleton(ModuleRevision revision) {
/*  417 */     List<Capability> identities = revision.getCapabilities("osgi.identity");
/*  418 */     if (identities.isEmpty())
/*  419 */       return false; 
/*  420 */     return "true".equals(((Capability)identities.get(0)).getDirectives().get("singleton"));
/*      */   }
/*      */   
/*      */   static Version getVersion(Capability c) {
/*  424 */     String versionAttr = null;
/*  425 */     String namespace = c.getNamespace();
/*  426 */     if ("osgi.identity".equals(namespace)) {
/*  427 */       versionAttr = "version";
/*  428 */     } else if ("osgi.wiring.package".equals(namespace)) {
/*  429 */       versionAttr = "version";
/*  430 */     } else if ("osgi.wiring.bundle".equals(namespace)) {
/*  431 */       versionAttr = "bundle-version";
/*  432 */     } else if ("osgi.wiring.host".equals(namespace)) {
/*  433 */       versionAttr = "bundle-version";
/*      */     } else {
/*      */       
/*  436 */       versionAttr = "version";
/*      */     } 
/*  438 */     Object version = c.getAttributes().get(versionAttr);
/*  439 */     return (version instanceof Version) ? (Version)version : Version.emptyVersion;
/*      */   }
/*      */   
/*      */   class ResolveProcess
/*      */     extends ResolveContext implements Comparator<Capability>, Executor {
/*      */     class ResolveLogger extends Logger {
/*  445 */       private Map<Resource, ResolutionException> errors = null;
/*      */       
/*      */       public ResolveLogger() {
/*  448 */         super((ModuleResolver.ResolveProcess.access$1(ModuleResolver.ResolveProcess.this)).DEBUG_USES ? 4 : 0);
/*      */       }
/*      */ 
/*      */       
/*      */       public void logUsesConstraintViolation(Resource resource, ResolutionError error) {
/*  453 */         if (this.errors == null) {
/*  454 */           this.errors = new HashMap<>();
/*      */         }
/*  456 */         this.errors.put(resource, error.toException());
/*  457 */         if ((ModuleResolver.ResolveProcess.access$1(ModuleResolver.ResolveProcess.this)).DEBUG_USES) {
/*  458 */           Debug.println("RESOLVER: Uses constraint violation" + 
/*  459 */               ModuleResolver.SEPARATOR + '\t' + 
/*  460 */               "Resource" + 
/*  461 */               ModuleResolver.SEPARATOR + '\t' + '\t' + 
/*  462 */               resource + 
/*  463 */               ModuleResolver.SEPARATOR + '\t' + 
/*  464 */               "Error" + 
/*  465 */               ModuleResolver.SEPARATOR + '\t' + '\t' + 
/*  466 */               error.getMessage());
/*      */         }
/*      */       }
/*      */ 
/*      */       
/*      */       Map<Resource, ResolutionException> getUsesConstraintViolations() {
/*  472 */         return (this.errors == null) ? Collections.<Resource, ResolutionException>emptyMap() : this.errors;
/*      */       }
/*      */ 
/*      */       
/*      */       public boolean isDebugEnabled() {
/*  477 */         return (ModuleResolver.ResolveProcess.access$1(ModuleResolver.ResolveProcess.this)).DEBUG_USES;
/*      */       }
/*      */ 
/*      */       
/*      */       protected void doLog(int level, String msg, Throwable throwable) {
/*  482 */         Debug.println("RESOLVER: " + msg + ModuleResolver.SEPARATOR + ((throwable != null) ? (String.valueOf(18) + throwable.getMessage()) : ""));
/*      */       }
/*      */     }
/*      */ 
/*      */     
/*  487 */     private final ModuleResolutionReport.Builder reportBuilder = new ModuleResolutionReport.Builder();
/*      */ 
/*      */     
/*      */     private final Collection<ModuleRevision> unresolved;
/*      */ 
/*      */     
/*      */     private final Collection<ModuleRevision> disabled;
/*      */ 
/*      */     
/*      */     private final Collection<ModuleRevision> triggers;
/*      */ 
/*      */     
/*      */     private final boolean triggersMandatory;
/*      */ 
/*      */     
/*      */     final ModuleDatabase moduleDatabase;
/*      */     
/*      */     final Map<ModuleRevision, ModuleWiring> wirings;
/*      */     
/*      */     private final Set<ModuleRevision> previouslyResolved;
/*      */     
/*      */     private final ModuleRequirement.DynamicModuleRequirement dynamicReq;
/*      */     
/*  510 */     private volatile ResolverHook hook = null;
/*  511 */     private volatile Map<String, Collection<ModuleRevision>> byName = null;
/*  512 */     private volatile List<Resource> currentlyResolving = null;
/*      */     private volatile boolean currentlyResolvingMandatory = false;
/*  514 */     private final Set<Resource> transitivelyResolveFailures = new LinkedHashSet<>();
/*  515 */     private final Set<Resource> failedToResolve = new HashSet<>();
/*  516 */     private AtomicBoolean scheduleTimeout = new AtomicBoolean(true);
/*  517 */     private AtomicReference<ScheduledFuture<?>> timoutFuture = new AtomicReference<>();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  527 */     private final Map<Resource, Map<Requirement, Set<Capability>>> unresolvedProviders = new HashMap<>();
/*      */     
/*      */     ResolveProcess(Collection<ModuleRevision> unresolved, Collection<ModuleRevision> triggers, boolean triggersMandatory, Map<ModuleRevision, ModuleWiring> wirings, ModuleDatabase moduleDatabase) {
/*  530 */       this.unresolved = unresolved;
/*  531 */       this.disabled = new HashSet<>(unresolved);
/*  532 */       this.triggers = new ArrayList<>(triggers);
/*  533 */       this.triggersMandatory = triggersMandatory;
/*  534 */       this.wirings = new HashMap<>(wirings);
/*  535 */       this.previouslyResolved = new HashSet<>(wirings.keySet());
/*  536 */       this.moduleDatabase = moduleDatabase;
/*  537 */       this.dynamicReq = null;
/*      */     }
/*      */     
/*      */     ResolveProcess(Collection<ModuleRevision> unresolved, ModuleRequirement.DynamicModuleRequirement dynamicReq, Map<ModuleRevision, ModuleWiring> wirings, ModuleDatabase moduleDatabase) {
/*  541 */       this.unresolved = unresolved;
/*  542 */       this.disabled = new HashSet<>(unresolved);
/*  543 */       ModuleRevision revision = dynamicReq.getRevision();
/*  544 */       this.triggers = new ArrayList<>(1);
/*  545 */       this.triggers.add(revision);
/*  546 */       this.triggersMandatory = false;
/*  547 */       this.wirings = wirings;
/*  548 */       this.previouslyResolved = new HashSet<>(wirings.keySet());
/*  549 */       this.moduleDatabase = moduleDatabase;
/*  550 */       this.dynamicReq = dynamicReq;
/*      */     }
/*      */ 
/*      */     
/*      */     public List<Capability> findProviders(Requirement requirement) {
/*  555 */       Requirement origReq = requirement;
/*  556 */       Requirement lookupReq = (this.dynamicReq == null || this.dynamicReq.getOriginal() != requirement) ? requirement : (Requirement)this.dynamicReq;
/*  557 */       return findProviders0(origReq, lookupReq);
/*      */     }
/*      */     
/*      */     private List<Capability> findProviders0(Requirement origReq, Requirement lookupReq) {
/*  561 */       if (ModuleResolver.this.DEBUG_PROVIDERS) {
/*  562 */         Debug.println("RESOLVER: Finding capabilities for requirement" + 
/*  563 */             ModuleResolver.SEPARATOR + '\t' + 
/*  564 */             origReq + 
/*  565 */             ModuleResolver.SEPARATOR + '\t' + '\t' + 
/*  566 */             "of resource" + 
/*  567 */             ModuleResolver.SEPARATOR + '\t' + '\t' + '\t' + 
/*  568 */             origReq.getResource());
/*      */       }
/*      */       
/*  571 */       List<ModuleCapability> candidates = this.moduleDatabase.findCapabilities(lookupReq);
/*  572 */       List<Capability> result = filterProviders(origReq, candidates);
/*  573 */       if (ModuleResolver.this.DEBUG_PROVIDERS) {
/*  574 */         StringBuilder builder = new StringBuilder("RESOLVER: Capabilities being returned to the resolver");
/*  575 */         int i = 0;
/*  576 */         for (Capability capability : result) {
/*  577 */           builder.append(ModuleResolver.SEPARATOR).append('\t')
/*  578 */             .append("[").append(++i).append("] ")
/*  579 */             .append(capability)
/*  580 */             .append(ModuleResolver.SEPARATOR).append('\t').append('\t')
/*  581 */             .append("of resource")
/*  582 */             .append(ModuleResolver.SEPARATOR).append('\t').append('\t').append('\t')
/*  583 */             .append(capability.getResource());
/*      */         }
/*  585 */         Debug.println(builder.toString());
/*      */       } 
/*  587 */       return result;
/*      */     }
/*      */     
/*      */     private List<Capability> filterProviders(Requirement requirement, List<ModuleCapability> candidates) {
/*  591 */       return filterProviders(requirement, candidates, true);
/*      */     }
/*      */     
/*      */     List<Capability> filterProviders(Requirement requirement, List<ModuleCapability> candidates, boolean filterResolvedHosts) {
/*  595 */       filterDisabled(candidates);
/*  596 */       ModuleResolver.this.removeNonEffectiveCapabilities(candidates);
/*  597 */       removeSubstituted(candidates);
/*  598 */       filterPermissions((BundleRequirement)requirement, candidates);
/*      */       
/*  600 */       List<ModuleCapability> filteredMatches = null;
/*  601 */       if (ModuleResolver.this.DEBUG_PROVIDERS || ModuleResolver.this.DEBUG_HOOKS) {
/*  602 */         filteredMatches = new ArrayList<>(candidates);
/*      */       }
/*  604 */       this.hook.filterMatches((BundleRequirement)requirement, InternalUtils.asList(candidates));
/*  605 */       if (ModuleResolver.this.DEBUG_PROVIDERS || ModuleResolver.this.DEBUG_HOOKS) {
/*  606 */         filteredMatches.removeAll(candidates);
/*  607 */         if (!filteredMatches.isEmpty()) {
/*  608 */           StringBuilder builder = new StringBuilder("RESOLVER: Capabilities filtered by ResolverHook.filterMatches");
/*  609 */           int i = 0;
/*  610 */           for (Capability capability : filteredMatches) {
/*  611 */             builder.append(ModuleResolver.SEPARATOR).append('\t')
/*  612 */               .append("[").append(++i).append("] ")
/*  613 */               .append(capability)
/*  614 */               .append(ModuleResolver.SEPARATOR).append('\t').append('\t')
/*  615 */               .append("of resource")
/*  616 */               .append(ModuleResolver.SEPARATOR).append('\t').append('\t').append('\t')
/*  617 */               .append(capability.getResource());
/*      */           }
/*  619 */           Debug.println(builder.toString());
/*      */         } 
/*      */       } 
/*      */ 
/*      */       
/*  624 */       filterResolvedHosts(requirement, candidates, filterResolvedHosts);
/*      */       
/*  626 */       if (candidates.isEmpty()) {
/*  627 */         if (!this.wirings.containsKey(requirement.getResource()) || ModuleResolver.isDynamic(requirement)) {
/*  628 */           this.reportBuilder.addEntry(requirement.getResource(), ResolutionReport.Entry.Type.MISSING_CAPABILITY, requirement);
/*  629 */           String resolution = (String)requirement.getDirectives().get("resolution");
/*  630 */           if (resolution == null || "mandatory".equals(resolution)) {
/*  631 */             this.transitivelyResolveFailures.add(requirement.getResource());
/*      */           }
/*      */         } 
/*      */       } else {
/*  635 */         computeUnresolvedProviders(requirement, (Collection)candidates);
/*      */       } 
/*      */       
/*  638 */       filterFailedToResolve(candidates);
/*      */       
/*  640 */       Collections.sort(candidates, this);
/*  641 */       return InternalUtils.asList(candidates);
/*      */     }
/*      */     
/*      */     private void filterFailedToResolve(List<ModuleCapability> candidates) {
/*  645 */       for (Iterator<ModuleCapability> iCandidates = candidates.iterator(); iCandidates.hasNext(); ) {
/*  646 */         ModuleCapability capability = iCandidates.next();
/*  647 */         if (this.failedToResolve.contains(capability.getRevision())) {
/*  648 */           iCandidates.remove();
/*  649 */           if (ModuleResolver.this.DEBUG_PROVIDERS) {
/*  650 */             Debug.println("RESOLVER: Capability filtered because its resource was not resolved" + 
/*  651 */                 ModuleResolver.SEPARATOR + '\t' + 
/*  652 */                 capability + 
/*  653 */                 ModuleResolver.SEPARATOR + '\t' + '\t' + 
/*  654 */                 "of resource" + 
/*  655 */                 ModuleResolver.SEPARATOR + '\t' + '\t' + '\t' + 
/*  656 */                 capability.getResource());
/*      */           }
/*      */         } 
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     private void filterResolvedHosts(Requirement requirement, List<ModuleCapability> candidates, boolean filterResolvedHosts) {
/*  664 */       if (filterResolvedHosts && "osgi.wiring.host".equals(requirement.getNamespace())) {
/*  665 */         for (Iterator<ModuleCapability> iCandidates = candidates.iterator(); iCandidates.hasNext();) {
/*  666 */           if (this.wirings.containsKey(((ModuleCapability)iCandidates.next()).getRevision())) {
/*  667 */             iCandidates.remove();
/*      */           }
/*      */         } 
/*      */       }
/*      */     }
/*      */     
/*      */     private void filterPermissions(BundleRequirement requirement, List<ModuleCapability> candidates) {
/*  674 */       if (System.getSecurityManager() == null) {
/*      */         return;
/*      */       }
/*      */       
/*  678 */       if (requirement.getRevision().getBundle() == null) {
/*      */         return;
/*      */       }
/*      */ 
/*      */       
/*  683 */       candidates.removeIf(candidate -> {
/*      */             if ("osgi.wiring.package".equals(param1BundleRequirement.getNamespace()) && param1BundleRequirement.getRevision().equals(candidate.getRevision())) {
/*      */               return false;
/*      */             }
/*      */             Permission requirePermission = InternalUtils.getRequirePermission(candidate);
/*      */             Permission providePermission = InternalUtils.getProvidePermission(candidate);
/*      */             if (!param1BundleRequirement.getRevision().getBundle().hasPermission(requirePermission)) {
/*      */               if (ModuleResolver.this.DEBUG_PROVIDERS) {
/*      */                 Debug.println("RESOLVER: Capability filtered because requirer did not have permission" + ModuleResolver.SEPARATOR + '\t' + candidate + ModuleResolver.SEPARATOR + '\t' + '\t' + "of resource" + ModuleResolver.SEPARATOR + '\t' + '\t' + '\t' + candidate.getResource());
/*      */               }
/*      */               return true;
/*      */             } 
/*      */             if (!candidate.getRevision().getBundle().hasPermission(providePermission)) {
/*      */               if (ModuleResolver.this.DEBUG_PROVIDERS) {
/*      */                 Debug.println("RESOLVER: Capability filtered because provider did not have permission" + ModuleResolver.SEPARATOR + '\t' + candidate + ModuleResolver.SEPARATOR + '\t' + '\t' + "of resource" + ModuleResolver.SEPARATOR + '\t' + '\t' + '\t' + candidate.getResource());
/*      */               }
/*      */               return true;
/*      */             } 
/*      */             return false;
/*      */           });
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private void filterDisabled(List<ModuleCapability> candidates) {
/*  722 */       candidates.removeIf(capability -> {
/*      */             if (this.disabled.contains(capability.getResource())) {
/*      */               if (ModuleResolver.this.DEBUG_PROVIDERS) {
/*      */                 Debug.println("RESOLVER: Capability filtered because it was disabled" + ModuleResolver.SEPARATOR + '\t' + capability + ModuleResolver.SEPARATOR + '\t' + '\t' + "of resource" + ModuleResolver.SEPARATOR + '\t' + '\t' + '\t' + capability.getResource());
/*      */               }
/*      */               return true;
/*      */             } 
/*      */             return false;
/*      */           });
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private void removeSubstituted(List<ModuleCapability> capabilities) {
/*  741 */       capabilities.removeIf(capability -> {
/*      */             ModuleWiring wiring = this.wirings.get(capability.getRevision());
/*      */             if (wiring != null && wiring.isSubtituted(capability)) {
/*      */               if (ModuleResolver.this.DEBUG_PROVIDERS) {
/*      */                 Debug.println("RESOLVER: Capability filtered because it was substituted" + ModuleResolver.SEPARATOR + '\t' + capability + ModuleResolver.SEPARATOR + '\t' + '\t' + "of resource" + ModuleResolver.SEPARATOR + '\t' + '\t' + '\t' + capability.getResource());
/*      */               }
/*      */               return true;
/*      */             } 
/*      */             return false;
/*      */           });
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public int insertHostedCapability(List<Capability> capabilities, HostedCapability hostedCapability) {
/*  762 */       int index = Collections.binarySearch(capabilities, hostedCapability, this);
/*  763 */       if (index < 0)
/*  764 */         index = -index - 1; 
/*  765 */       capabilities.add(index, hostedCapability);
/*  766 */       return index;
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean isEffective(Requirement requirement) {
/*  771 */       String effective = (String)requirement.getDirectives().get("effective");
/*  772 */       return !(effective != null && !"resolve".equals(effective));
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public Map<Resource, Wiring> getWirings() {
/*  778 */       Map<?, ?> raw = this.wirings;
/*  779 */       return (Map)Collections.unmodifiableMap(raw);
/*      */     }
/*      */ 
/*      */     
/*      */     public Collection<Resource> getMandatoryResources() {
/*  784 */       if (this.currentlyResolvingMandatory) {
/*  785 */         return Collections.unmodifiableList(this.currentlyResolving);
/*      */       }
/*  787 */       return Collections.emptyList();
/*      */     }
/*      */ 
/*      */     
/*      */     public Collection<Resource> getOptionalResources() {
/*  792 */       if (!this.currentlyResolvingMandatory) {
/*  793 */         return Collections.unmodifiableList(this.currentlyResolving);
/*      */       }
/*  795 */       return Collections.emptyList();
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public Collection<Resource> findRelatedResources(Resource host) {
/*  801 */       List<ModuleCapability> hostCaps = ((ModuleRevision)host).getModuleCapabilities("osgi.wiring.host");
/*  802 */       if (hostCaps.isEmpty()) {
/*  803 */         return Collections.emptyList();
/*      */       }
/*      */       
/*  806 */       Collection<Resource> relatedFragments = new ArrayList<>();
/*  807 */       for (String hostBSN : getHostBSNs(hostCaps)) {
/*  808 */         String matchFilter = "(equinox.fragment=" + hostBSN + ")";
/*  809 */         Requirement fragmentRequirement = ModuleContainer.createRequirement("equinox.fragment", Collections.singletonMap("filter", matchFilter), Collections.emptyMap());
/*  810 */         List<ModuleCapability> candidates = this.moduleDatabase.findCapabilities(fragmentRequirement);
/*      */         
/*  812 */         filterDisabled(candidates);
/*  813 */         for (ModuleCapability candidate : candidates) {
/*  814 */           ModuleRequirement hostReq = candidate.getRevision().getModuleRequirements("osgi.wiring.host").get(0);
/*  815 */           for (ModuleCapability hostCap : hostCaps) {
/*  816 */             if (hostReq.matches(hostCap)) {
/*  817 */               relatedFragments.add(candidate.getResource());
/*      */               
/*      */               break;
/*      */             } 
/*      */           } 
/*      */         } 
/*      */       } 
/*  824 */       return relatedFragments;
/*      */     }
/*      */     
/*      */     private Collection<String> getHostBSNs(List<ModuleCapability> hostCaps) {
/*  828 */       if (hostCaps.size() == 1)
/*      */       {
/*  830 */         return getHostBSNs(hostCaps.get(0));
/*      */       }
/*  832 */       Set<String> result = new HashSet<>();
/*  833 */       for (ModuleCapability hostCap : hostCaps) {
/*  834 */         result.addAll(getHostBSNs(hostCap));
/*      */       }
/*  836 */       return result;
/*      */     }
/*      */ 
/*      */     
/*      */     private Collection<String> getHostBSNs(ModuleCapability moduleCapability) {
/*  841 */       Object namesAttr = moduleCapability.getAttributes().get("osgi.wiring.host");
/*  842 */       if (namesAttr instanceof String) {
/*  843 */         return Collections.singletonList((String)namesAttr);
/*      */       }
/*  845 */       if (namesAttr instanceof String[]) {
/*  846 */         return Arrays.asList((String[])namesAttr);
/*      */       }
/*  848 */       if (namesAttr instanceof Collection) {
/*  849 */         return (Collection<String>)namesAttr;
/*      */       }
/*  851 */       return Collections.emptyList();
/*      */     }
/*      */     
/*      */     ModuleResolutionReport resolve() {
/*  855 */       if (ModuleResolver.this.threadResolving())
/*      */       {
/*      */         
/*  858 */         throw new IllegalStateException(Msg.ModuleResolver_RecursiveError);
/*      */       }
/*  860 */       ModuleResolver.this.threadResolving.set(Boolean.TRUE); try {
/*      */         ModuleResolutionReport report; ScheduledFuture<?> f;
/*      */         try {
/*  863 */           this.hook = ModuleResolver.this.adaptor.getResolverHookFactory().begin(InternalUtils.asList((List)this.triggers));
/*  864 */         } catch (RuntimeException e) {
/*  865 */           if (e.getCause() instanceof BundleException) {
/*  866 */             BundleException be = (BundleException)e.getCause();
/*  867 */             if (be.getType() == 12) {
/*  868 */               return new ModuleResolutionReport(null, Collections.emptyMap(), new ResolutionException((Throwable)be));
/*      */             }
/*      */           } 
/*  871 */           throw e;
/*      */         } 
/*  873 */         Map<Resource, List<Wire>> result = null;
/*  874 */         ResolutionException re = null;
/*      */         
/*  876 */         ResolveLogger logger = new ResolveLogger();
/*      */         try {
/*  878 */           filterResolvable();
/*  879 */           selectSingletons();
/*      */           
/*  881 */           if (this.triggers.removeAll(this.disabled) && this.triggersMandatory) {
/*  882 */             throw new ResolutionException(String.valueOf(Msg.ModuleResolver_SingletonDisabledError) + this.disabled);
/*      */           }
/*  884 */           if (this.dynamicReq != null) {
/*  885 */             result = resolveDynamic();
/*      */           } else {
/*  887 */             result = new HashMap<>();
/*  888 */             Map<Resource, List<Wire>> dynamicAttachWirings = resolveNonPayLoadFragments();
/*  889 */             applyInterimResultToWiringCopy(dynamicAttachWirings);
/*  890 */             if (!dynamicAttachWirings.isEmpty()) {
/*      */ 
/*      */               
/*  893 */               Set<Resource> fragmentResources = dynamicAttachWirings.keySet();
/*  894 */               this.triggers.removeAll(fragmentResources);
/*      */               
/*  896 */               result.putAll(dynamicAttachWirings);
/*      */             } 
/*  898 */             resolveRevisionsInBatch(this.triggers, this.triggersMandatory, logger, result);
/*      */           } 
/*  900 */         } catch (ResolutionException e) {
/*  901 */           re = e;
/*      */         } finally {
/*  903 */           ScheduledFuture<?> scheduledFuture = this.timoutFuture.getAndSet(null);
/*  904 */           if (scheduledFuture != null) {
/*  905 */             scheduledFuture.cancel(true);
/*      */           }
/*  907 */           computeUnresolvedProviderResolutionReportEntries(result);
/*  908 */           computeUsesConstraintViolations(logger.getUsesConstraintViolations());
/*  909 */           if (ModuleResolver.this.DEBUG_WIRING) {
/*  910 */             printWirings(result);
/*      */           }
/*  912 */           ModuleResolutionReport moduleResolutionReport = this.reportBuilder.build(result, re);
/*  913 */           if (ModuleResolver.this.DEBUG_REPORT) {
/*  914 */             if (moduleResolutionReport.getResolutionException() != null) {
/*  915 */               Debug.printStackTrace((Throwable)moduleResolutionReport.getResolutionException());
/*      */             }
/*  917 */             Set<Resource> resources = moduleResolutionReport.getEntries().keySet();
/*  918 */             if (!resources.isEmpty()) {
/*  919 */               Debug.println("RESOLVER: Resolution report");
/*  920 */               for (Resource resource : moduleResolutionReport.getEntries().keySet()) {
/*  921 */                 Debug.println(moduleResolutionReport.getResolutionReportMessage(resource));
/*      */               }
/*      */             } 
/*      */           } 
/*  925 */           if (this.hook instanceof ResolutionReport.Listener)
/*  926 */             ((ResolutionReport.Listener)this.hook).handleResolutionReport(moduleResolutionReport); 
/*  927 */           this.hook.end();
/*      */         } 
/*  929 */         return report;
/*      */       } finally {
/*  931 */         ModuleResolver.this.threadResolving.set(Boolean.FALSE);
/*      */       } 
/*      */     }
/*      */     
/*      */     private void printWirings(Map<Resource, List<Wire>> wires) {
/*  936 */       StringBuilder builder = new StringBuilder("RESOLVER: Wirings for resolved bundles:");
/*  937 */       if (wires == null) {
/*  938 */         Debug.println(" null wires!");
/*      */         return;
/*      */       } 
/*  941 */       for (Map.Entry<Resource, List<Wire>> entry : wires.entrySet()) {
/*  942 */         builder.append(ModuleResolver.SEPARATOR).append('\t')
/*  943 */           .append("Resource")
/*  944 */           .append(ModuleResolver.SEPARATOR).append('\t').append('\t')
/*  945 */           .append(entry.getKey())
/*  946 */           .append(ModuleResolver.SEPARATOR).append('\t')
/*  947 */           .append("Wiring");
/*  948 */         int i = 0;
/*  949 */         for (Wire wire : entry.getValue()) {
/*  950 */           builder.append(ModuleResolver.SEPARATOR).append('\t').append('\t')
/*  951 */             .append('[').append(++i).append("] ")
/*  952 */             .append(wire);
/*      */         }
/*      */       } 
/*      */       
/*  956 */       Debug.println(builder);
/*      */     }
/*      */     
/*      */     private void resolveRevisionsInBatch(Collection<ModuleRevision> revisions, boolean isMandatory, ResolveLogger logger, Map<Resource, List<Wire>> result) throws ResolutionException {
/*  960 */       long startTime = System.currentTimeMillis();
/*  961 */       long initialFreeMemory = Runtime.getRuntime().freeMemory();
/*  962 */       long maxUsedMemory = 0L;
/*      */ 
/*      */       
/*  965 */       revisions = new LinkedList<>(revisions);
/*  966 */       List<Resource> toResolve = new ArrayList<>();
/*      */       try {
/*  968 */         for (Iterator<ModuleRevision> iResources = revisions.iterator(); iResources.hasNext(); ) {
/*  969 */           ModuleRevision single = iResources.next();
/*  970 */           iResources.remove();
/*  971 */           if (!this.wirings.containsKey(single) && !this.failedToResolve.contains(single)) {
/*  972 */             toResolve.add(single);
/*      */           }
/*  974 */           if (toResolve.size() == ModuleResolver.this.resolverRevisionBatchSize || !iResources.hasNext()) {
/*  975 */             if (ModuleResolver.this.DEBUG_ROOTS) {
/*  976 */               Debug.println("Resolver: resolving " + toResolve.size() + " in batch.");
/*  977 */               for (Resource root : toResolve) {
/*  978 */                 Debug.println("    Resolving root bundle: " + root);
/*      */               }
/*      */             } 
/*  981 */             resolveRevisions(toResolve, isMandatory, logger, result);
/*  982 */             toResolve.clear();
/*      */           } 
/*  984 */           maxUsedMemory = Math.max(maxUsedMemory, Runtime.getRuntime().freeMemory() - initialFreeMemory);
/*      */         } 
/*  986 */       } catch (ResolutionException resolutionException) {
/*  987 */         if (resolutionException.getCause() instanceof java.util.concurrent.CancellationException) {
/*      */           
/*  989 */           resolveRevisionsIndividually(isMandatory, logger, result, toResolve, revisions);
/*      */         } else {
/*  991 */           throw resolutionException;
/*      */         } 
/*  993 */       } catch (OutOfMemoryError outOfMemoryError) {
/*      */         
/*  995 */         resolveRevisionsIndividually(isMandatory, logger, result, toResolve, revisions);
/*      */       } 
/*      */       
/*  998 */       if (ModuleResolver.this.DEBUG_ROOTS) {
/*  999 */         Debug.println("Resolver: resolve batch size:  " + ModuleResolver.this.resolverRevisionBatchSize);
/* 1000 */         Debug.println("Resolver: time to resolve:  " + (System.currentTimeMillis() - startTime) + "ms");
/* 1001 */         Debug.println("Resolver: max used memory: " + (maxUsedMemory / 1048576L) + "Mo");
/*      */       } 
/*      */     }
/*      */     
/*      */     private void resolveRevisionsIndividually(boolean isMandatory, ResolveLogger logger, Map<Resource, List<Wire>> result, Collection<Resource> toResolve, Collection<ModuleRevision> revisions) throws ResolutionException {
/* 1006 */       this.scheduleTimeout.set(false);
/* 1007 */       for (Resource resource : toResolve) {
/* 1008 */         if (!this.wirings.containsKey(resource) && !this.failedToResolve.contains(resource)) {
/* 1009 */           resolveRevisions(Collections.singletonList(resource), isMandatory, logger, result);
/*      */         }
/*      */       } 
/* 1012 */       for (Resource resource : revisions) {
/* 1013 */         if (!this.wirings.containsKey(resource) && !this.failedToResolve.contains(resource)) {
/* 1014 */           resolveRevisions(Collections.singletonList(resource), isMandatory, logger, result);
/*      */         }
/*      */       } 
/*      */     }
/*      */     
/*      */     private void resolveRevisions(List<Resource> revisions, boolean isMandatory, ResolveLogger logger, Map<Resource, List<Wire>> result) throws ResolutionException {
/* 1020 */       boolean applyTransitiveFailures = true;
/* 1021 */       this.currentlyResolving = revisions;
/* 1022 */       this.currentlyResolvingMandatory = isMandatory;
/* 1023 */       this.transitivelyResolveFailures.clear();
/* 1024 */       Map<Resource, List<Wire>> interimResults = null;
/*      */       try {
/* 1026 */         this.transitivelyResolveFailures.addAll(revisions);
/* 1027 */         interimResults = (new ResolverImpl(logger, this)).resolve(this);
/* 1028 */         applyInterimResultToWiringCopy(interimResults);
/* 1029 */         if (ModuleResolver.this.DEBUG_ROOTS) {
/* 1030 */           Debug.println("Resolver: resolved " + interimResults.size() + " bundles.");
/*      */         }
/*      */         
/* 1033 */         for (Map.Entry<Resource, List<Wire>> interimResultEntry : interimResults.entrySet()) {
/* 1034 */           if (ModuleResolver.this.DEBUG_ROOTS) {
/* 1035 */             Debug.println("    Resolved bundle: " + interimResultEntry.getKey());
/*      */           }
/* 1037 */           List<Wire> existingWires = result.get(interimResultEntry.getKey());
/* 1038 */           if (existingWires != null) {
/* 1039 */             existingWires.addAll(interimResultEntry.getValue()); continue;
/*      */           } 
/* 1041 */           result.put(interimResultEntry.getKey(), interimResultEntry.getValue());
/*      */         }
/*      */       
/* 1044 */       } catch (ResolutionException resolutionException) {
/* 1045 */         if (resolutionException.getCause() instanceof java.util.concurrent.CancellationException) {
/* 1046 */           applyTransitiveFailures = false;
/*      */         }
/* 1048 */         throw resolutionException;
/* 1049 */       } catch (OutOfMemoryError memoryError) {
/* 1050 */         applyTransitiveFailures = false;
/* 1051 */         throw memoryError;
/*      */       } finally {
/* 1053 */         if (applyTransitiveFailures) {
/* 1054 */           this.transitivelyResolveFailures.addAll(logger.getUsesConstraintViolations().keySet());
/* 1055 */           if (interimResults != null) {
/* 1056 */             this.transitivelyResolveFailures.removeAll(interimResults.keySet());
/*      */           }
/*      */           
/* 1059 */           if (!this.transitivelyResolveFailures.isEmpty()) {
/* 1060 */             this.failedToResolve.addAll(this.transitivelyResolveFailures);
/*      */           }
/*      */         } 
/* 1063 */         this.currentlyResolving = null;
/* 1064 */         this.currentlyResolvingMandatory = false;
/*      */       } 
/*      */     }
/*      */     
/*      */     private void applyInterimResultToWiringCopy(Map<Resource, List<Wire>> interimResult) {
/* 1069 */       if (!interimResult.isEmpty()) {
/*      */         
/* 1071 */         Map<ModuleRevision, ModuleWiring> updatedWirings = ModuleResolver.this.generateDelta(interimResult, this.wirings);
/* 1072 */         for (Map.Entry<ModuleRevision, ModuleWiring> updatedWiring : updatedWirings.entrySet()) {
/* 1073 */           this.wirings.put(updatedWiring.getKey(), updatedWiring.getValue());
/*      */         }
/*      */       } 
/*      */     }
/*      */     
/*      */     private void computeUsesConstraintViolations(Map<Resource, ResolutionException> usesConstraintViolations) {
/* 1079 */       for (Map.Entry<Resource, ResolutionException> usesConstraintViolation : usesConstraintViolations.entrySet()) {
/* 1080 */         this.reportBuilder.addEntry(usesConstraintViolation.getKey(), ResolutionReport.Entry.Type.USES_CONSTRAINT_VIOLATION, usesConstraintViolation.getValue());
/*      */       }
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private void computeUnresolvedProviderResolutionReportEntries(Map<Resource, List<Wire>> resolution) {
/* 1093 */       Collection<Resource> shouldHaveResolvedResources = new ArrayList(this.unresolved);
/*      */       
/* 1095 */       shouldHaveResolvedResources.removeAll(this.disabled);
/*      */ 
/*      */ 
/*      */       
/* 1099 */       if (resolution != null) {
/* 1100 */         shouldHaveResolvedResources.removeAll(resolution.keySet());
/*      */       }
/*      */ 
/*      */       
/* 1104 */       for (Resource shouldHaveResolvedResource : shouldHaveResolvedResources) {
/* 1105 */         Map<Requirement, Set<Capability>> requirementToCapabilities = this.unresolvedProviders.get(shouldHaveResolvedResource);
/* 1106 */         if (requirementToCapabilities == null) {
/*      */           continue;
/*      */         }
/*      */         
/* 1110 */         if (resolution != null)
/*      */         {
/* 1112 */           for (Iterator<Set<Capability>> values = requirementToCapabilities.values().iterator(); values.hasNext(); ) {
/* 1113 */             Set<Capability> value = values.next();
/* 1114 */             for (Iterator<Capability> capabilities = value.iterator(); capabilities.hasNext();) {
/* 1115 */               if (resolution.containsKey(((Capability)capabilities.next()).getResource()))
/*      */               {
/* 1117 */                 capabilities.remove(); } 
/* 1118 */             }  if (value.isEmpty())
/*      */             {
/*      */               
/* 1121 */               values.remove();
/*      */             }
/*      */           } 
/*      */         }
/*      */         
/* 1126 */         if (!requirementToCapabilities.isEmpty()) {
/* 1127 */           this.reportBuilder.addEntry(shouldHaveResolvedResource, ResolutionReport.Entry.Type.UNRESOLVED_PROVIDER, requirementToCapabilities);
/*      */         }
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private void computeUnresolvedProviders(Requirement requirement, Collection<? extends Capability> capabilities) {
/* 1138 */       Resource requirer = requirement.getResource();
/* 1139 */       Map<Requirement, Set<Capability>> requirementToCapabilities = this.unresolvedProviders.get(requirer);
/* 1140 */       if (requirementToCapabilities == null) {
/* 1141 */         requirementToCapabilities = new HashMap<>();
/* 1142 */         this.unresolvedProviders.put(requirer, requirementToCapabilities);
/*      */       } 
/* 1144 */       Set<Capability> value = requirementToCapabilities.get(requirement);
/* 1145 */       if (value == null) {
/* 1146 */         value = new HashSet<>(capabilities.size());
/* 1147 */         requirementToCapabilities.put(requirement, value);
/*      */       } 
/* 1149 */       for (Capability capability : capabilities) {
/* 1150 */         if (!this.wirings.containsKey(capability.getResource()))
/* 1151 */           value.add(capability); 
/*      */       } 
/*      */     }
/*      */     
/*      */     class DynamicFragments { private final ModuleCapability hostCapability;
/* 1156 */       private final Map<String, ModuleRevision> fragments = new HashMap<>();
/* 1157 */       private final Set<ModuleRevision> validProviders = new HashSet<>();
/*      */       boolean fragmentAdded = false;
/*      */       
/*      */       DynamicFragments(ModuleWiring hostWiring, ModuleCapability hostCapability) {
/* 1161 */         this.hostCapability = hostCapability;
/* 1162 */         this.validProviders.add(hostWiring.getRevision());
/* 1163 */         for (ModuleWire hostWire : hostWiring.getProvidedModuleWires("osgi.wiring.host")) {
/* 1164 */           this.validProviders.add(hostWire.getRequirer());
/* 1165 */           this.fragments.put(hostWire.getRequirer().getSymbolicName(), hostWire.getRequirer());
/*      */         } 
/*      */       }
/*      */       
/*      */       void addFragment(ModuleRevision fragment) {
/* 1170 */         ModuleRevision existing = this.fragments.get(fragment.getSymbolicName());
/* 1171 */         if (existing == null) {
/* 1172 */           this.fragments.put(fragment.getSymbolicName(), fragment);
/* 1173 */           this.validProviders.add(fragment);
/* 1174 */           this.fragmentAdded = true;
/*      */         } 
/*      */       }
/*      */       
/*      */       Map<Resource, List<Wire>> getNewWires() {
/* 1179 */         if (!this.fragmentAdded) {
/* 1180 */           return Collections.emptyMap();
/*      */         }
/* 1182 */         Map<Resource, List<Wire>> result = new HashMap<>();
/*      */         
/*      */         while (true) {
/* 1185 */           boolean retry = false;
/* 1186 */           result.clear(); Iterator<Map.Entry<String, ModuleRevision>> iFragments;
/* 1187 */           label29: for (iFragments = this.fragments.entrySet().iterator(); iFragments.hasNext(); ) {
/* 1188 */             Map.Entry<String, ModuleRevision> fragmentEntry = iFragments.next();
/* 1189 */             if (ModuleResolver.ResolveProcess.this.wirings.get(fragmentEntry.getValue()) == null) {
/* 1190 */               for (ModuleRequirement req : ((ModuleRevision)fragmentEntry.getValue()).getModuleRequirements(null)) {
/* 1191 */                 ModuleRevision requirer = ModuleResolver.NON_PAYLOAD_REQUIREMENTS.contains(req.getNamespace()) ? req.getRevision() : this.hostCapability.getRevision();
/* 1192 */                 List<Wire> newWires = result.get(requirer);
/* 1193 */                 if (newWires == null) {
/* 1194 */                   newWires = new ArrayList<>();
/* 1195 */                   result.put(requirer, newWires);
/*      */                 } 
/* 1197 */                 if ("osgi.wiring.host".equals(req.getNamespace())) {
/* 1198 */                   newWires.add(new ModuleWire(this.hostCapability, this.hostCapability.getRevision(), req, requirer)); continue;
/*      */                 } 
/* 1200 */                 if (failToWire(req, requirer, newWires)) {
/* 1201 */                   iFragments.remove();
/* 1202 */                   this.validProviders.remove(req.getRevision());
/* 1203 */                   retry = true;
/*      */                   
/*      */                   break label29;
/*      */                 } 
/*      */               } 
/*      */             }
/*      */           } 
/* 1210 */           if (!retry)
/* 1211 */             return result; 
/*      */         } 
/*      */       }
/*      */       private boolean failToWire(ModuleRequirement requirement, ModuleRevision requirer, List<Wire> wires) {
/* 1215 */         if (!ModuleResolver.ResolveProcess.this.isEffective((Requirement)requirement)) {
/* 1216 */           return false;
/*      */         }
/* 1218 */         List<ModuleCapability> matching = ModuleResolver.ResolveProcess.this.moduleDatabase.findCapabilities((Requirement)requirement);
/* 1219 */         List<Wire> newWires = new ArrayList<>(0);
/* 1220 */         ModuleResolver.ResolveProcess.this.filterProviders((Requirement)requirement, matching, false);
/* 1221 */         for (ModuleCapability candidate : matching) {
/*      */ 
/*      */ 
/*      */           
/* 1225 */           if (requirer.equals(requirement.getRevision()) || this.validProviders.contains(candidate.getRevision())) {
/* 1226 */             ModuleRevision provider = ModuleResolver.NON_PAYLOAD_CAPABILITIES.contains(candidate.getNamespace()) ? candidate.getRevision() : this.hostCapability.getRevision();
/*      */             
/* 1228 */             if (newWires.isEmpty() || "multiple".equals(requirement.getDirectives().get("cardinality"))) {
/* 1229 */               newWires.add(new ModuleWire(candidate, provider, requirement, requirer));
/*      */             }
/*      */           } 
/*      */         } 
/* 1233 */         if (newWires.isEmpty() && 
/* 1234 */           !"optional".equals(requirement.getDirectives().get("resolution")))
/*      */         {
/* 1236 */           return true;
/*      */         }
/*      */ 
/*      */         
/* 1240 */         if (!ModuleResolver.NON_SUBSTITUTED_REQUIREMENTS.contains(requirement.getNamespace())) {
/* 1241 */           wires.addAll(newWires);
/*      */         }
/* 1243 */         return false;
/*      */       } }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private Map<Resource, List<Wire>> resolveNonPayLoadFragments() {
/* 1254 */       List<ModuleRevision> dynamicAttachableFrags = new ArrayList<>();
/*      */ 
/*      */       
/* 1257 */       for (ModuleRevision moduleRevision : this.unresolved) {
/* 1258 */         if ((moduleRevision.getTypes() & 0x1) != 0 && 
/* 1259 */           !this.disabled.contains(moduleRevision)) {
/* 1260 */           dynamicAttachableFrags.add(moduleRevision);
/*      */         }
/*      */       } 
/*      */       
/* 1264 */       if (dynamicAttachableFrags.isEmpty()) {
/* 1265 */         return Collections.emptyMap();
/*      */       }
/*      */       
/* 1268 */       Collections.sort(dynamicAttachableFrags, Comparator.<ModuleRevision, Comparable>comparing(ModuleRevision::getVersion).reversed());
/*      */       
/* 1270 */       Map<ModuleCapability, DynamicFragments> hostDynamicFragments = new HashMap<>();
/*      */       
/* 1272 */       for (ModuleRevision dynamicAttachableFragment : dynamicAttachableFrags) {
/* 1273 */         List<ModuleRequirement> requirements = dynamicAttachableFragment.getModuleRequirements(null);
/* 1274 */         for (ModuleRequirement requirement : requirements) {
/* 1275 */           if ("osgi.wiring.host".equals(requirement.getNamespace())) {
/* 1276 */             List<ModuleCapability> matchingHosts = this.moduleDatabase.findCapabilities((Requirement)requirement);
/* 1277 */             filterProviders((Requirement)requirement, matchingHosts, false);
/* 1278 */             for (ModuleCapability hostCandidate : matchingHosts) {
/* 1279 */               ModuleWiring hostWiring = this.wirings.get(hostCandidate.getRevision());
/* 1280 */               String attachDirective = hostCandidate.getDirectives().get("fragment-attachment");
/* 1281 */               boolean attachAlways = !(attachDirective != null && !"always".equals(attachDirective));
/*      */               
/* 1283 */               if (!attachAlways || hostWiring == null) {
/*      */                 continue;
/*      */               }
/* 1286 */               DynamicFragments dynamicFragments = hostDynamicFragments.get(hostCandidate);
/* 1287 */               if (dynamicFragments == null) {
/* 1288 */                 dynamicFragments = new DynamicFragments(hostWiring, hostCandidate);
/* 1289 */                 hostDynamicFragments.put(hostCandidate, dynamicFragments);
/*      */               } 
/* 1291 */               dynamicFragments.addFragment(requirement.getRevision());
/*      */             } 
/*      */           } 
/*      */         } 
/*      */       } 
/*      */       
/* 1297 */       Map<Resource, List<Wire>> dynamicWires = new HashMap<>();
/* 1298 */       for (DynamicFragments dynamicFragments : hostDynamicFragments.values()) {
/* 1299 */         dynamicWires.putAll(dynamicFragments.getNewWires());
/*      */       }
/* 1301 */       return dynamicWires;
/*      */     }
/*      */     
/*      */     private Map<Resource, List<Wire>> resolveDynamic() throws ResolutionException {
/* 1305 */       return (new ResolverImpl(new Logger(0), null)).resolveDynamic(this, (Wiring)this.wirings.get(this.dynamicReq.getResource()), 
/* 1306 */           (Requirement)this.dynamicReq.getOriginal());
/*      */     }
/*      */     
/*      */     private void filterResolvable() {
/* 1310 */       Collection<ModuleRevision> enabledCandidates = new ArrayList<>(this.unresolved);
/* 1311 */       this.hook.filterResolvable(InternalUtils.asList((List)enabledCandidates));
/*      */       
/* 1313 */       for (ModuleRevision enabledRevision : enabledCandidates) {
/* 1314 */         this.disabled.remove(enabledRevision);
/*      */       }
/* 1316 */       for (ModuleRevision revision : this.disabled) {
/* 1317 */         this.reportBuilder.addEntry((Resource)revision, ResolutionReport.Entry.Type.FILTERED_BY_RESOLVER_HOOK, null);
/* 1318 */         if (ModuleResolver.this.DEBUG_HOOKS) {
/* 1319 */           Debug.println("RESOLVER: Resource filtered by ResolverHook.filterResolvable: " + revision);
/*      */         }
/*      */       } 
/*      */     }
/*      */     
/*      */     private void selectSingletons() {
/* 1325 */       Map<String, Collection<ModuleRevision>> selectedSingletons = new HashMap<>();
/* 1326 */       for (ModuleRevision revision : this.unresolved) {
/* 1327 */         if (!ModuleResolver.isSingleton(revision) || this.disabled.contains(revision))
/*      */           continue; 
/* 1329 */         String bsn = revision.getSymbolicName();
/* 1330 */         Collection<ModuleRevision> selected = selectedSingletons.get(bsn);
/* 1331 */         if (selected != null)
/*      */           continue; 
/* 1333 */         selected = new ArrayList<>(1);
/* 1334 */         selectedSingletons.put(bsn, selected);
/*      */         
/* 1336 */         Collection<ModuleRevision> sameBSN = getRevisions(bsn);
/* 1337 */         if (sameBSN.size() < 2) {
/* 1338 */           selected.add(revision);
/*      */           
/*      */           continue;
/*      */         } 
/* 1342 */         for (ModuleRevision singleton : sameBSN) {
/* 1343 */           if (ModuleResolver.isSingleton(singleton) && this.wirings.containsKey(singleton)) {
/* 1344 */             selected.add(singleton);
/*      */           }
/*      */         } 
/* 1347 */         Map<ModuleRevision, Collection<ModuleRevision>> collisionMap = getCollisionMap(sameBSN);
/*      */         
/* 1349 */         for (ModuleRevision singleton : sameBSN) {
/* 1350 */           if (selected.contains(singleton))
/*      */             continue; 
/* 1352 */           Collection<ModuleRevision> collisions = collisionMap.get(singleton);
/* 1353 */           if (collisions == null || this.disabled.contains(singleton))
/*      */             continue; 
/* 1355 */           Collection<ModuleRevision> pickOneToResolve = new ArrayList<>();
/* 1356 */           for (ModuleRevision collision : collisions) {
/* 1357 */             if (selected.contains(collision)) {
/*      */               
/* 1359 */               this.disabled.add(singleton);
/* 1360 */               this.reportBuilder.addEntry((Resource)singleton, ResolutionReport.Entry.Type.SINGLETON_SELECTION, collision);
/*      */               break;
/*      */             } 
/* 1363 */             if (!pickOneToResolve.contains(collision))
/* 1364 */               pickOneToResolve.add(collision); 
/*      */           } 
/* 1366 */           if (!this.disabled.contains(singleton))
/*      */           {
/* 1368 */             for (Map.Entry<ModuleRevision, Collection<ModuleRevision>> collisionEntry : collisionMap.entrySet()) {
/* 1369 */               if (collisionEntry.getKey() != singleton && ((Collection)collisionEntry.getValue()).contains(singleton)) {
/* 1370 */                 if (selected.contains(collisionEntry.getKey())) {
/*      */                   
/* 1372 */                   this.disabled.add(singleton);
/* 1373 */                   this.reportBuilder.addEntry((Resource)singleton, ResolutionReport.Entry.Type.SINGLETON_SELECTION, collisionEntry.getKey());
/*      */                   break;
/*      */                 } 
/* 1376 */                 if (!pickOneToResolve.contains(collisionEntry.getKey()))
/* 1377 */                   pickOneToResolve.add(collisionEntry.getKey()); 
/*      */               } 
/*      */             } 
/*      */           }
/* 1381 */           if (!this.disabled.contains(singleton)) {
/* 1382 */             pickOneToResolve.add(singleton);
/* 1383 */             selected.add(pickOneToResolve(pickOneToResolve));
/*      */           } 
/*      */         } 
/*      */       } 
/*      */     }
/*      */     
/*      */     private Collection<ModuleRevision> getRevisions(String name) {
/* 1390 */       Map<String, Collection<ModuleRevision>> current = this.byName;
/* 1391 */       if (current == null) {
/*      */ 
/*      */         
/* 1394 */         Set<ModuleRevision> revisions = new HashSet<>();
/* 1395 */         revisions.addAll(this.unresolved);
/* 1396 */         revisions.addAll(this.previouslyResolved);
/* 1397 */         current = new HashMap<>();
/* 1398 */         for (ModuleRevision revision : revisions) {
/* 1399 */           Collection<ModuleRevision> sameName = current.get(revision.getSymbolicName());
/* 1400 */           if (sameName == null) {
/* 1401 */             sameName = new ArrayList<>();
/* 1402 */             current.put(revision.getSymbolicName(), sameName);
/*      */           } 
/* 1404 */           sameName.add(revision);
/*      */         } 
/* 1406 */         this.byName = current;
/*      */       } 
/* 1408 */       Collection<ModuleRevision> result = current.get(name);
/* 1409 */       if (result == null) {
/* 1410 */         return Collections.emptyList();
/*      */       }
/* 1412 */       return result;
/*      */     }
/*      */     
/*      */     private ModuleRevision pickOneToResolve(Collection<ModuleRevision> pickOneToResolve) {
/* 1416 */       ModuleRevision selectedVersion = null;
/* 1417 */       for (ModuleRevision singleton : pickOneToResolve) {
/* 1418 */         if (selectedVersion == null)
/* 1419 */           selectedVersion = singleton; 
/* 1420 */         boolean higherVersion = (selectedVersion.getVersion().compareTo(singleton.getVersion()) < 0);
/* 1421 */         if (higherVersion) {
/* 1422 */           selectedVersion = singleton;
/*      */         }
/*      */       } 
/* 1425 */       for (ModuleRevision singleton : pickOneToResolve) {
/* 1426 */         if (singleton != selectedVersion) {
/* 1427 */           this.disabled.add(singleton);
/* 1428 */           this.reportBuilder.addEntry((Resource)singleton, ResolutionReport.Entry.Type.SINGLETON_SELECTION, selectedVersion);
/*      */         } 
/*      */       } 
/* 1431 */       return selectedVersion;
/*      */     }
/*      */     
/*      */     private Map<ModuleRevision, Collection<ModuleRevision>> getCollisionMap(Collection<ModuleRevision> sameBSN) {
/* 1435 */       Map<ModuleRevision, Collection<ModuleRevision>> result = new HashMap<>();
/* 1436 */       for (ModuleRevision singleton : sameBSN) {
/* 1437 */         if (!ModuleResolver.isSingleton(singleton) || this.disabled.contains(singleton))
/*      */           continue; 
/* 1439 */         List<BundleCapability> capabilities = new ArrayList<>(sameBSN.size() - 1);
/* 1440 */         for (ModuleRevision collision : sameBSN) {
/* 1441 */           if (collision == singleton || !ModuleResolver.isSingleton(collision) || this.disabled.contains(collision))
/*      */             continue; 
/* 1443 */           capabilities.add(getIdentity(collision));
/*      */         } 
/* 1445 */         this.hook.filterSingletonCollisions(getIdentity(singleton), capabilities);
/* 1446 */         Collection<ModuleRevision> collisionCandidates = new ArrayList<>(capabilities.size());
/* 1447 */         for (BundleCapability identity : capabilities) {
/* 1448 */           collisionCandidates.add((ModuleRevision)identity.getRevision());
/*      */         }
/* 1450 */         if (ModuleResolver.this.DEBUG_HOOKS) {
/* 1451 */           Collection<ModuleRevision> filteredSingletons = new ArrayList<>(sameBSN);
/* 1452 */           filteredSingletons.removeAll(collisionCandidates);
/* 1453 */           filteredSingletons.remove(singleton);
/* 1454 */           if (!filteredSingletons.isEmpty()) {
/* 1455 */             StringBuilder builder = (new StringBuilder("RESOLVER: Resources filtered by ResolverHook.filterSingletonCollisions"))
/* 1456 */               .append(ModuleResolver.SEPARATOR).append('\t')
/* 1457 */               .append("Singleton")
/* 1458 */               .append(ModuleResolver.SEPARATOR).append('\t').append('\t')
/* 1459 */               .append(singleton)
/* 1460 */               .append(" [id=")
/* 1461 */               .append(singleton.getRevisions().getModule().getId())
/* 1462 */               .append(", location=")
/* 1463 */               .append(singleton.getRevisions().getModule().getLocation())
/* 1464 */               .append(']')
/* 1465 */               .append(ModuleResolver.SEPARATOR).append('\t')
/* 1466 */               .append("Collisions");
/* 1467 */             int i = 0;
/* 1468 */             for (ModuleRevision revision : filteredSingletons) {
/* 1469 */               builder.append(ModuleResolver.SEPARATOR).append('\t').append('\t')
/* 1470 */                 .append("[").append(++i).append("] ")
/* 1471 */                 .append(revision)
/* 1472 */                 .append(" [id=")
/* 1473 */                 .append(revision.getRevisions().getModule().getId())
/* 1474 */                 .append(", location=")
/* 1475 */                 .append(revision.getRevisions().getModule().getLocation())
/* 1476 */                 .append(']');
/*      */             }
/* 1478 */             Debug.println(builder.toString());
/*      */           } 
/*      */         } 
/* 1481 */         result.put(singleton, collisionCandidates);
/*      */       } 
/* 1483 */       return result;
/*      */     }
/*      */     
/*      */     private BundleCapability getIdentity(ModuleRevision bundle) {
/* 1487 */       List<BundleCapability> identities = bundle.getDeclaredCapabilities("osgi.identity");
/* 1488 */       return identities.isEmpty() ? null : identities.get(0);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public int compare(Capability c1, Capability c2) {
/* 1496 */       boolean resolved1 = this.previouslyResolved.contains(c1.getResource());
/* 1497 */       boolean resolved2 = this.previouslyResolved.contains(c2.getResource());
/* 1498 */       if (resolved1 != resolved2) {
/* 1499 */         return resolved1 ? -1 : 1;
/*      */       }
/* 1501 */       Version v1 = ModuleResolver.getVersion(c1);
/* 1502 */       Version v2 = ModuleResolver.getVersion(c2);
/* 1503 */       int versionCompare = -v1.compareTo(v2);
/* 1504 */       if (versionCompare != 0) {
/* 1505 */         return versionCompare;
/*      */       }
/* 1507 */       ModuleRevision m1 = getModuleRevision(c1);
/* 1508 */       ModuleRevision m2 = getModuleRevision(c2);
/* 1509 */       Long id1 = m1.getRevisions().getModule().getId();
/* 1510 */       Long id2 = m2.getRevisions().getModule().getId();
/*      */       
/* 1512 */       if (id1.equals(id2) && !m1.equals(m2)) {
/*      */         
/* 1514 */         List<ModuleRevision> revisions = m1.getRevisions().getModuleRevisions();
/* 1515 */         int index1 = revisions.indexOf(m1);
/* 1516 */         int index2 = revisions.indexOf(m2);
/*      */         
/* 1518 */         return index2 - index1;
/*      */       } 
/* 1520 */       return id1.compareTo(id2);
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     ModuleRevision getModuleRevision(Capability c) {
/* 1526 */       if (c instanceof HostedCapability) {
/* 1527 */         c = ((HostedCapability)c).getDeclaredCapability();
/*      */       }
/* 1529 */       if (c instanceof ModuleCapability) {
/* 1530 */         return ((ModuleCapability)c).getRevision();
/*      */       }
/*      */       
/* 1533 */       return null;
/*      */     }
/*      */ 
/*      */     
/*      */     public void execute(Runnable command) {
/* 1538 */       ModuleResolver.this.adaptor.getResolverExecutor().execute(command);
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public void onCancel(Runnable callback) {
/* 1544 */       if (this.scheduleTimeout.compareAndSet(true, false)) {
/* 1545 */         ScheduledExecutorService scheduledExecutor = ModuleResolver.this.adaptor.getScheduledExecutor();
/* 1546 */         if (scheduledExecutor != null) {
/*      */           try {
/* 1548 */             this.timoutFuture.set(scheduledExecutor.schedule(callback, ModuleResolver.this.resolverBatchTimeout, TimeUnit.MILLISECONDS));
/* 1549 */           } catch (RejectedExecutionException rejectedExecutionException) {}
/*      */         }
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public List<Wire> getSubstitutionWires(Wiring wiring) {
/* 1558 */       return ((ModuleWiring)wiring).getSubstitutionWires();
/*      */     }
/*      */   }
/*      */   
/*      */   protected boolean threadResolving() {
/* 1563 */     Boolean resolvingValue = this.threadResolving.get();
/* 1564 */     if (resolvingValue == null) {
/* 1565 */       return false;
/*      */     }
/* 1567 */     return resolvingValue.booleanValue();
/*      */   }
/*      */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.osgi-3.18.400.jar!\org\eclipse\osgi\container\ModuleResolver.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */