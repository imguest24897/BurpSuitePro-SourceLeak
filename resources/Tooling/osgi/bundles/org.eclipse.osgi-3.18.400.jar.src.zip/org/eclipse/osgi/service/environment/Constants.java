package org.eclipse.osgi.service.environment;

public interface Constants {
  public static final String OS_WIN32 = "win32";
  
  public static final String OS_LINUX = "linux";
  
  public static final String OS_AIX = "aix";
  
  public static final String OS_SOLARIS = "solaris";
  
  public static final String OS_HPUX = "hpux";
  
  public static final String OS_QNX = "qnx";
  
  public static final String OS_MACOSX = "macosx";
  
  public static final String OS_EPOC32 = "epoc32";
  
  public static final String OS_OS400 = "os/400";
  
  public static final String OS_OS390 = "os/390";
  
  public static final String OS_ZOS = "z/os";
  
  public static final String OS_FREEBSD = "freebsd";
  
  public static final String OS_UNKNOWN = "unknown";
  
  public static final String ARCH_X86 = "x86";
  
  public static final String ARCH_PA_RISC = "PA_RISC";
  
  public static final String ARCH_PPC = "ppc";
  
  public static final String ARCH_PPC64 = "ppc64";
  
  public static final String ARCH_SPARC = "sparc";
  
  public static final String ARCH_X86_64 = "x86_64";
  
  public static final String ARCH_AMD64 = "x86_64";
  
  public static final String ARCH_IA64 = "ia64";
  
  public static final String ARCH_IA64_32 = "ia64_32";
  
  public static final String WS_WIN32 = "win32";
  
  public static final String WS_WPF = "wpf";
  
  public static final String WS_MOTIF = "motif";
  
  public static final String WS_GTK = "gtk";
  
  public static final String WS_PHOTON = "photon";
  
  public static final String WS_CARBON = "carbon";
  
  public static final String WS_COCOA = "cocoa";
  
  public static final String WS_S60 = "s60";
  
  public static final String WS_UNKNOWN = "unknown";
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.osgi-3.18.400.jar!\org\eclipse\osgi\service\environment\Constants.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */