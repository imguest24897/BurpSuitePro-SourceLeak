/*     */ package org.eclipse.osgi.internal.weaving;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.WeakHashMap;
/*     */ import org.eclipse.osgi.internal.framework.EquinoxContainer;
/*     */ import org.eclipse.osgi.internal.hookregistry.ClassLoaderHook;
/*     */ import org.eclipse.osgi.internal.loader.BundleLoader;
/*     */ import org.eclipse.osgi.internal.loader.ModuleClassLoader;
/*     */ import org.eclipse.osgi.internal.loader.classpath.ClasspathEntry;
/*     */ import org.eclipse.osgi.internal.loader.classpath.ClasspathManager;
/*     */ import org.eclipse.osgi.internal.serviceregistry.ServiceRegistry;
/*     */ import org.eclipse.osgi.storage.bundlefile.BundleEntry;
/*     */ import org.osgi.framework.Bundle;
/*     */ import org.osgi.framework.ServiceRegistration;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class WeavingHookConfigurator
/*     */   extends ClassLoaderHook
/*     */ {
/*     */   static class WovenClassContext
/*     */   {
/*  35 */     List<WovenClassImpl> wovenClassStack = new ArrayList<>(6);
/*  36 */     List<String> processClassNameStack = new ArrayList<>(6);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  42 */   private final Map<ServiceRegistration<?>, Boolean> deniedHooks = Collections.synchronizedMap(new WeakHashMap<>());
/*     */   
/*  44 */   private final ThreadLocal<WovenClassContext> wovenClassContext = new ThreadLocal<>();
/*     */   
/*     */   private final EquinoxContainer container;
/*     */   
/*     */   public WeavingHookConfigurator(EquinoxContainer container) {
/*  49 */     this.container = container;
/*     */   }
/*     */   
/*     */   private ServiceRegistry getRegistry() {
/*  53 */     return this.container.getServiceRegistry();
/*     */   }
/*     */ 
/*     */   
/*     */   public byte[] processClass(String name, byte[] classbytes, ClasspathEntry classpathEntry, BundleEntry entry, ClasspathManager manager) {
/*  58 */     ServiceRegistry registry = getRegistry();
/*  59 */     if (registry == null)
/*  60 */       return null; 
/*  61 */     ModuleClassLoader classLoader = manager.getClassLoader();
/*  62 */     BundleLoader loader = classLoader.getBundleLoader();
/*     */     
/*  64 */     WovenClassImpl wovenClass = new WovenClassImpl(name, classbytes, entry, classpathEntry, loader, this.container, 
/*  65 */         this.deniedHooks);
/*  66 */     WovenClassContext context = this.wovenClassContext.get();
/*  67 */     if (context == null) {
/*  68 */       context = new WovenClassContext();
/*  69 */       this.wovenClassContext.set(context);
/*     */     } 
/*  71 */     context.wovenClassStack.add(wovenClass);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  76 */     if (!context.processClassNameStack.contains(name)) {
/*  77 */       context.processClassNameStack.add(name);
/*     */       
/*     */       try {
/*  80 */         return wovenClass.callHooks();
/*  81 */       } catch (Throwable t) {
/*  82 */         ServiceRegistration<?> errorHook = wovenClass.getErrorHook();
/*  83 */         Bundle errorBundle = (errorHook != null) ? errorHook.getReference().getBundle() : manager.getGeneration().getRevision().getBundle();
/*  84 */         this.container.getEventPublisher().publishFrameworkEvent(2, errorBundle, t);
/*     */         
/*  86 */         ClassFormatError error = new ClassFormatError("Unexpected error from weaving hook.");
/*  87 */         error.initCause(t);
/*  88 */         throw error;
/*     */       } finally {
/*  90 */         context.processClassNameStack.remove(name);
/*     */       } 
/*     */     } 
/*  93 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void recordClassDefine(String name, Class<?> clazz, byte[] classbytes, ClasspathEntry classpathEntry, BundleEntry entry, ClasspathManager manager) {
/*  99 */     WovenClassContext context = this.wovenClassContext.get();
/* 100 */     if (context == null || context.wovenClassStack.size() == 0)
/*     */       return; 
/* 102 */     WovenClassImpl wovenClass = context.wovenClassStack.remove(context.wovenClassStack.size() - 1);
/*     */     
/* 104 */     wovenClass.setWeavingCompleted(clazz);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isProcessClassRecursionSupported() {
/* 109 */     return true;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.osgi-3.18.400.jar!\org\eclipse\osgi\internal\weaving\WeavingHookConfigurator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */