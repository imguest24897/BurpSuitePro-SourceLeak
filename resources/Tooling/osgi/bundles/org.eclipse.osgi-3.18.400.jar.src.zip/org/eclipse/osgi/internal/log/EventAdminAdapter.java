/*     */ package org.eclipse.osgi.internal.log;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.HashSet;
/*     */ import org.osgi.framework.BundleContext;
/*     */ import org.osgi.framework.ServiceReference;
/*     */ import org.osgi.service.log.LogListener;
/*     */ import org.osgi.util.tracker.ServiceTracker;
/*     */ import org.osgi.util.tracker.ServiceTrackerCustomizer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class EventAdminAdapter
/*     */   implements ServiceTrackerCustomizer<Object, Object>
/*     */ {
/*     */   public static final String EVENT_TOPIC = "event.topics";
/*  27 */   private static final String[] LOG_TOPICS_ARRAY = new String[] { "*", "org/*", "org/osgi/*", "org/osgi/service/*", "org/osgi/service/log/*", "org/osgi/service/log/LogEntry/*", "org/osgi/service/log/LogEntry/LOG_ERROR", "org/osgi/service/log/LogEntry/LOG_WARNING", "org/osgi/service/log/LogEntry/LOG_INFO", "org/osgi/service/log/LogEntry/LOG_DEBUG", "org/osgi/service/log/LogEntry/LOG_OTHER" };
/*  28 */   private static final Object LOG_TOPIC_TOKEN = new Object();
/*  29 */   private static Collection<String> logTopics = new HashSet<>(Arrays.asList(LOG_TOPICS_ARRAY));
/*  30 */   private static Collection<String> eventAdminObjectClass = Arrays.asList(new String[] { "org.osgi.service.event.EventAdmin" });
/*  31 */   private static Collection<String> eventHandlerObjectClass = Arrays.asList(new String[] { "org.osgi.service.event.EventHandler" });
/*     */   
/*     */   private ServiceTracker<Object, Object> eventAdminTracker;
/*     */   private ServiceTracker<Object, Object> eventHandlerTracker;
/*     */   private BundleContext context;
/*     */   private ServiceReference<Object> eventAdmin;
/*     */   private int logEventHandlers;
/*     */   private ExtendedLogReaderServiceFactory logReaderServiceFactory;
/*     */   private EventAdminLogListener logListener;
/*     */   
/*     */   public EventAdminAdapter(BundleContext context, ExtendedLogReaderServiceFactory logReaderServiceFactory) {
/*  42 */     this.context = context;
/*  43 */     this.logReaderServiceFactory = logReaderServiceFactory;
/*  44 */     this.eventAdminTracker = new ServiceTracker(context, "org.osgi.service.event.EventAdmin", this);
/*  45 */     this.eventHandlerTracker = new ServiceTracker(context, "org.osgi.service.event.EventHandler", this);
/*     */   }
/*     */   
/*     */   public void start() {
/*  49 */     this.eventAdminTracker.open(true);
/*  50 */     this.eventHandlerTracker.open(true);
/*     */   }
/*     */   
/*     */   public void stop() {
/*  54 */     this.eventAdminTracker.close();
/*  55 */     this.eventHandlerTracker.close();
/*     */   }
/*     */ 
/*     */   
/*     */   public Object addingService(ServiceReference<Object> reference) {
/*  60 */     Object<Object> toTrack = null;
/*  61 */     Object objectClass = reference.getProperty("objectClass");
/*  62 */     Object topics = reference.getProperty("event.topics");
/*  63 */     if (checkServiceProp(objectClass, eventAdminObjectClass) && this.eventAdmin == null) {
/*  64 */       toTrack = (Object<Object>)reference;
/*  65 */       this.eventAdmin = reference;
/*  66 */     } else if (checkServiceProp(objectClass, eventHandlerObjectClass) && checkServiceProp(topics, logTopics)) {
/*  67 */       this.logEventHandlers++;
/*  68 */       toTrack = (Object<Object>)LOG_TOPIC_TOKEN;
/*     */     } 
/*     */     
/*  71 */     if (this.eventAdmin != null && this.logEventHandlers > 0 && this.logListener == null) {
/*     */       try {
/*  73 */         this.logListener = new EventAdminLogListener(this.context.getService(this.eventAdmin));
/*  74 */       } catch (ClassNotFoundException|NoSuchMethodException e) {
/*     */         
/*  76 */         e.printStackTrace();
/*     */       } 
/*  78 */       this.logReaderServiceFactory.addLogListener((LogListener)this.logListener, ExtendedLogReaderServiceFactory.NULL_LOGGER_FILTER);
/*     */     } 
/*     */     
/*  81 */     return toTrack;
/*     */   }
/*     */ 
/*     */   
/*     */   public void modifiedService(ServiceReference<Object> reference, Object tracked) {
/*  86 */     removedService(reference, tracked);
/*  87 */     addingService(reference);
/*     */   }
/*     */ 
/*     */   
/*     */   public void removedService(ServiceReference<Object> reference, Object tracked) {
/*  92 */     if (tracked == this.eventAdmin) {
/*  93 */       this.eventAdmin = null;
/*  94 */       this.context.ungetService(reference);
/*  95 */     } else if (LOG_TOPIC_TOKEN == tracked) {
/*  96 */       this.logEventHandlers--;
/*     */     } 
/*     */     
/*  99 */     if (this.logListener != null && (this.eventAdmin == null || this.logEventHandlers == 0)) {
/* 100 */       this.logReaderServiceFactory.removeLogListener((LogListener)this.logListener);
/* 101 */       this.logListener = null;
/*     */     } 
/*     */   }
/*     */   
/*     */   private static boolean checkServiceProp(Object property, Collection<String> check) {
/* 106 */     if (property instanceof String) {
/* 107 */       return check.contains(property);
/*     */     }
/* 109 */     if (property instanceof String[]) {
/* 110 */       String[] topics = (String[])property; byte b; int i; String[] arrayOfString1;
/* 111 */       for (i = (arrayOfString1 = topics).length, b = 0; b < i; ) { String topic = arrayOfString1[b];
/* 112 */         if (check.contains(topic)) {
/* 113 */           return true;
/*     */         }
/*     */         b++; }
/*     */     
/*     */     } 
/* 118 */     if (property instanceof Collection)
/* 119 */       for (Object prop : property) {
/* 120 */         if (check.contains(prop))
/* 121 */           return true; 
/*     */       }  
/* 123 */     return false;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.osgi-3.18.400.jar!\org\eclipse\osgi\internal\log\EventAdminAdapter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */