/*     */ package org.eclipse.osgi.service.resolver;
/*     */ 
/*     */ import java.io.DataInputStream;
/*     */ import java.io.DataOutputStream;
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.util.Dictionary;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.osgi.framework.BundleException;
/*     */ import org.osgi.framework.InvalidSyntaxException;
/*     */ import org.osgi.framework.Version;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public interface StateObjectFactory
/*     */ {
/*  44 */   public static final StateObjectFactory defaultFactory = new StateObjectFactoryProxy();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   State createState();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   State createState(boolean paramBoolean);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   State createState(State paramState);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   BundleDescription createBundleDescription(long paramLong, String paramString1, Version paramVersion, String paramString2, BundleSpecification[] paramArrayOfBundleSpecification, HostSpecification paramHostSpecification, ImportPackageSpecification[] paramArrayOfImportPackageSpecification, ExportPackageDescription[] paramArrayOfExportPackageDescription, String[] paramArrayOfString, boolean paramBoolean);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   BundleDescription createBundleDescription(long paramLong, String paramString1, Version paramVersion, String paramString2, BundleSpecification[] paramArrayOfBundleSpecification, HostSpecification paramHostSpecification, ImportPackageSpecification[] paramArrayOfImportPackageSpecification, ExportPackageDescription[] paramArrayOfExportPackageDescription, String[] paramArrayOfString, boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3, String paramString3, String paramString4, GenericSpecification[] paramArrayOfGenericSpecification, GenericDescription[] paramArrayOfGenericDescription);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   BundleDescription createBundleDescription(long paramLong, String paramString1, Version paramVersion, String paramString2, BundleSpecification[] paramArrayOfBundleSpecification, HostSpecification paramHostSpecification, ImportPackageSpecification[] paramArrayOfImportPackageSpecification, ExportPackageDescription[] paramArrayOfExportPackageDescription, boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3, String paramString3, String[] paramArrayOfString, GenericSpecification[] paramArrayOfGenericSpecification, GenericDescription[] paramArrayOfGenericDescription);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   BundleDescription createBundleDescription(long paramLong, String paramString1, Version paramVersion, String paramString2, BundleSpecification[] paramArrayOfBundleSpecification, HostSpecification paramHostSpecification, ImportPackageSpecification[] paramArrayOfImportPackageSpecification, ExportPackageDescription[] paramArrayOfExportPackageDescription, boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3, String paramString3, String[] paramArrayOfString, GenericSpecification[] paramArrayOfGenericSpecification, GenericDescription[] paramArrayOfGenericDescription, NativeCodeSpecification paramNativeCodeSpecification);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   BundleDescription createBundleDescription(long paramLong, String paramString1, Version paramVersion, String paramString2, BundleSpecification[] paramArrayOfBundleSpecification, HostSpecification paramHostSpecification, ImportPackageSpecification[] paramArrayOfImportPackageSpecification, ExportPackageDescription[] paramArrayOfExportPackageDescription, String paramString3, String[] paramArrayOfString, GenericSpecification[] paramArrayOfGenericSpecification, GenericDescription[] paramArrayOfGenericDescription, NativeCodeSpecification paramNativeCodeSpecification);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   BundleDescription createBundleDescription(State paramState, Dictionary<String, String> paramDictionary, String paramString, long paramLong) throws BundleException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   BundleDescription createBundleDescription(Dictionary<String, String> paramDictionary, String paramString, long paramLong) throws BundleException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   BundleDescription createBundleDescription(BundleDescription paramBundleDescription);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   BundleSpecification createBundleSpecification(String paramString, VersionRange paramVersionRange, boolean paramBoolean1, boolean paramBoolean2);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   BundleSpecification createBundleSpecification(BundleSpecification paramBundleSpecification);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   List<BundleSpecification> createBundleSpecifications(String paramString);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   HostSpecification createHostSpecification(String paramString, VersionRange paramVersionRange);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   List<HostSpecification> createHostSpecifications(String paramString);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   HostSpecification createHostSpecification(HostSpecification paramHostSpecification);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   ImportPackageSpecification createImportPackageSpecification(String paramString1, VersionRange paramVersionRange1, String paramString2, VersionRange paramVersionRange2, Map<String, ?> paramMap1, Map<String, ?> paramMap2, BundleDescription paramBundleDescription);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   ImportPackageSpecification createImportPackageSpecification(ImportPackageSpecification paramImportPackageSpecification);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   List<ImportPackageSpecification> createImportPackageSpecifications(String paramString);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   ExportPackageDescription createExportPackageDescription(String paramString, Version paramVersion, Map<String, ?> paramMap1, Map<String, ?> paramMap2, boolean paramBoolean, BundleDescription paramBundleDescription);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   GenericDescription createGenericDescription(String paramString1, String paramString2, Version paramVersion, Map<String, ?> paramMap);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   GenericDescription createGenericDescription(String paramString, Map<String, ?> paramMap, Map<String, String> paramMap1, BundleDescription paramBundleDescription);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   List<GenericDescription> createGenericDescriptions(String paramString);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   GenericSpecification createGenericSpecification(String paramString1, String paramString2, String paramString3, boolean paramBoolean1, boolean paramBoolean2) throws InvalidSyntaxException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   List<GenericSpecification> createGenericSpecifications(String paramString);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   NativeCodeSpecification createNativeCodeSpecification(NativeCodeDescription[] paramArrayOfNativeCodeDescription, boolean paramBoolean);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   NativeCodeDescription createNativeCodeDescription(String[] paramArrayOfString1, String[] paramArrayOfString2, String[] paramArrayOfString3, VersionRange[] paramArrayOfVersionRange, String[] paramArrayOfString4, String paramString) throws InvalidSyntaxException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   ExportPackageDescription createExportPackageDescription(ExportPackageDescription paramExportPackageDescription);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   List<ExportPackageDescription> createExportPackageDescriptions(String paramString);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void writeState(State paramState, OutputStream paramOutputStream) throws IOException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void writeState(State paramState, DataOutputStream paramDataOutputStream) throws IOException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void writeState(State paramState, File paramFile) throws IOException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   State readState(InputStream paramInputStream) throws IOException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   State readState(DataInputStream paramDataInputStream) throws IOException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   State readState(File paramFile) throws IOException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class StateObjectFactoryProxy
/*     */     implements StateObjectFactory
/*     */   {
/*     */     private static final String IMPL_NAME = "org.eclipse.osgi.internal.resolver.StateObjectFactoryImpl";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 501 */     private Object monitor = new Object();
/*     */     private StateObjectFactory implementation;
/*     */     
/*     */     private StateObjectFactory getImplementation() {
/* 505 */       synchronized (this.monitor) {
/* 506 */         if (this.implementation == null) {
/*     */           try {
/* 508 */             Class<?> implClass = Class.forName("org.eclipse.osgi.internal.resolver.StateObjectFactoryImpl");
/* 509 */             this.implementation = implClass.getConstructor(new Class[0]).newInstance(new Object[0]);
/* 510 */           } catch (Throwable t) {
/* 511 */             throw new UnsupportedOperationException("Not able to create StateObjectFactory implementation: org.eclipse.osgi.internal.resolver.StateObjectFactoryImpl", t);
/*     */           } 
/*     */         }
/* 514 */         return this.implementation;
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     @Deprecated
/*     */     public State createState() {
/* 521 */       return getImplementation().createState();
/*     */     }
/*     */ 
/*     */     
/*     */     public State createState(boolean resolver) {
/* 526 */       return getImplementation().createState(resolver);
/*     */     }
/*     */ 
/*     */     
/*     */     public State createState(State state) {
/* 531 */       return getImplementation().createState(state);
/*     */     }
/*     */ 
/*     */     
/*     */     @Deprecated
/*     */     public BundleDescription createBundleDescription(long id, String symbolicName, Version version, String location, BundleSpecification[] required, HostSpecification host, ImportPackageSpecification[] imports, ExportPackageDescription[] exports, String[] providedPackages, boolean singleton) {
/* 537 */       return getImplementation().createBundleDescription(id, symbolicName, version, location, required, host, imports, exports, providedPackages, singleton);
/*     */     }
/*     */ 
/*     */     
/*     */     @Deprecated
/*     */     public BundleDescription createBundleDescription(long id, String symbolicName, Version version, String location, BundleSpecification[] required, HostSpecification host, ImportPackageSpecification[] imports, ExportPackageDescription[] exports, String[] providedPackages, boolean singleton, boolean attachFragments, boolean dynamicFragments, String platformFilter, String executionEnvironment, GenericSpecification[] genericRequires, GenericDescription[] genericCapabilities) {
/* 543 */       return getImplementation().createBundleDescription(id, symbolicName, version, location, required, host, imports, exports, providedPackages, singleton, attachFragments, dynamicFragments, platformFilter, executionEnvironment, genericRequires, genericCapabilities);
/*     */     }
/*     */ 
/*     */     
/*     */     public BundleDescription createBundleDescription(long id, String symbolicName, Version version, String location, BundleSpecification[] required, HostSpecification host, ImportPackageSpecification[] imports, ExportPackageDescription[] exports, boolean singleton, boolean attachFragments, boolean dynamicFragments, String platformFilter, String[] executionEnvironments, GenericSpecification[] genericRequires, GenericDescription[] genericCapabilities) {
/* 548 */       return getImplementation().createBundleDescription(id, symbolicName, version, location, required, host, imports, exports, singleton, attachFragments, dynamicFragments, platformFilter, executionEnvironments, genericRequires, genericCapabilities);
/*     */     }
/*     */ 
/*     */     
/*     */     public BundleDescription createBundleDescription(long id, String symbolicName, Version version, String location, BundleSpecification[] required, HostSpecification host, ImportPackageSpecification[] imports, ExportPackageDescription[] exports, boolean singleton, boolean attachFragments, boolean dynamicFragments, String platformFilter, String[] executionEnvironments, GenericSpecification[] genericRequires, GenericDescription[] genericCapabilities, NativeCodeSpecification nativeCode) {
/* 553 */       return getImplementation().createBundleDescription(id, symbolicName, version, location, required, host, imports, exports, singleton, attachFragments, dynamicFragments, platformFilter, executionEnvironments, genericRequires, genericCapabilities, nativeCode);
/*     */     }
/*     */ 
/*     */     
/*     */     public BundleDescription createBundleDescription(long id, String symbolicName, Version version, String location, BundleSpecification[] required, HostSpecification host, ImportPackageSpecification[] imports, ExportPackageDescription[] exports, String platformFilter, String[] executionEnvironments, GenericSpecification[] genericRequires, GenericDescription[] genericCapabilities, NativeCodeSpecification nativeCode) {
/* 558 */       return getImplementation().createBundleDescription(id, symbolicName, version, location, required, host, imports, exports, platformFilter, executionEnvironments, genericRequires, genericCapabilities, nativeCode);
/*     */     }
/*     */ 
/*     */     
/*     */     public BundleDescription createBundleDescription(State state, Dictionary<String, String> manifest, String location, long id) throws BundleException {
/* 563 */       return getImplementation().createBundleDescription(state, manifest, location, id);
/*     */     }
/*     */ 
/*     */     
/*     */     @Deprecated
/*     */     public BundleDescription createBundleDescription(Dictionary<String, String> manifest, String location, long id) throws BundleException {
/* 569 */       return getImplementation().createBundleDescription(manifest, location, id);
/*     */     }
/*     */ 
/*     */     
/*     */     public BundleDescription createBundleDescription(BundleDescription original) {
/* 574 */       return getImplementation().createBundleDescription(original);
/*     */     }
/*     */ 
/*     */     
/*     */     public BundleSpecification createBundleSpecification(String requiredSymbolicName, VersionRange requiredVersionRange, boolean export, boolean optional) {
/* 579 */       return getImplementation().createBundleSpecification(requiredSymbolicName, requiredVersionRange, export, optional);
/*     */     }
/*     */ 
/*     */     
/*     */     public BundleSpecification createBundleSpecification(BundleSpecification original) {
/* 584 */       return getImplementation().createBundleSpecification(original);
/*     */     }
/*     */ 
/*     */     
/*     */     public List<BundleSpecification> createBundleSpecifications(String declaration) {
/* 589 */       return getImplementation().createBundleSpecifications(declaration);
/*     */     }
/*     */ 
/*     */     
/*     */     public HostSpecification createHostSpecification(String hostSymbolicName, VersionRange hostVersionRange) {
/* 594 */       return getImplementation().createHostSpecification(hostSymbolicName, hostVersionRange);
/*     */     }
/*     */ 
/*     */     
/*     */     public List<HostSpecification> createHostSpecifications(String declaration) {
/* 599 */       return getImplementation().createHostSpecifications(declaration);
/*     */     }
/*     */ 
/*     */     
/*     */     public HostSpecification createHostSpecification(HostSpecification original) {
/* 604 */       return getImplementation().createHostSpecification(original);
/*     */     }
/*     */ 
/*     */     
/*     */     public ImportPackageSpecification createImportPackageSpecification(String packageName, VersionRange versionRange, String bundleSymbolicName, VersionRange bundleVersionRange, Map<String, ?> directives, Map<String, ?> attributes, BundleDescription importer) {
/* 609 */       return getImplementation().createImportPackageSpecification(packageName, versionRange, bundleSymbolicName, bundleVersionRange, directives, attributes, importer);
/*     */     }
/*     */ 
/*     */     
/*     */     public ImportPackageSpecification createImportPackageSpecification(ImportPackageSpecification original) {
/* 614 */       return getImplementation().createImportPackageSpecification(original);
/*     */     }
/*     */ 
/*     */     
/*     */     public List<ImportPackageSpecification> createImportPackageSpecifications(String declaration) {
/* 619 */       return getImplementation().createImportPackageSpecifications(declaration);
/*     */     }
/*     */ 
/*     */     
/*     */     public ExportPackageDescription createExportPackageDescription(String packageName, Version version, Map<String, ?> directives, Map<String, ?> attributes, boolean root, BundleDescription exporter) {
/* 624 */       return getImplementation().createExportPackageDescription(packageName, version, directives, attributes, root, exporter);
/*     */     }
/*     */ 
/*     */     
/*     */     @Deprecated
/*     */     public GenericDescription createGenericDescription(String name, String type, Version version, Map<String, ?> attributes) {
/* 630 */       return getImplementation().createGenericDescription(name, type, version, attributes);
/*     */     }
/*     */ 
/*     */     
/*     */     public GenericDescription createGenericDescription(String type, Map<String, ?> attributes, Map<String, String> directives, BundleDescription supplier) {
/* 635 */       return getImplementation().createGenericDescription(type, attributes, directives, supplier);
/*     */     }
/*     */ 
/*     */     
/*     */     public List<GenericDescription> createGenericDescriptions(String declaration) {
/* 640 */       return getImplementation().createGenericDescriptions(declaration);
/*     */     }
/*     */ 
/*     */     
/*     */     public GenericSpecification createGenericSpecification(String name, String type, String matchingFilter, boolean optional, boolean multiple) throws InvalidSyntaxException {
/* 645 */       return getImplementation().createGenericSpecification(name, type, matchingFilter, optional, multiple);
/*     */     }
/*     */ 
/*     */     
/*     */     public List<GenericSpecification> createGenericSpecifications(String declaration) {
/* 650 */       return getImplementation().createGenericSpecifications(declaration);
/*     */     }
/*     */ 
/*     */     
/*     */     public NativeCodeSpecification createNativeCodeSpecification(NativeCodeDescription[] nativeCodeDescriptions, boolean optional) {
/* 655 */       return getImplementation().createNativeCodeSpecification(nativeCodeDescriptions, optional);
/*     */     }
/*     */ 
/*     */     
/*     */     public NativeCodeDescription createNativeCodeDescription(String[] nativePaths, String[] processors, String[] osNames, VersionRange[] osVersions, String[] languages, String filter) throws InvalidSyntaxException {
/* 660 */       return getImplementation().createNativeCodeDescription(nativePaths, processors, osNames, osVersions, languages, filter);
/*     */     }
/*     */ 
/*     */     
/*     */     public ExportPackageDescription createExportPackageDescription(ExportPackageDescription original) {
/* 665 */       return getImplementation().createExportPackageDescription(original);
/*     */     }
/*     */ 
/*     */     
/*     */     public List<ExportPackageDescription> createExportPackageDescriptions(String declaration) {
/* 670 */       return getImplementation().createExportPackageDescriptions(declaration);
/*     */     }
/*     */ 
/*     */     
/*     */     @Deprecated
/*     */     public void writeState(State state, OutputStream stream) throws IOException {
/* 676 */       getImplementation().writeState(state, stream);
/*     */     }
/*     */ 
/*     */     
/*     */     @Deprecated
/*     */     public void writeState(State state, DataOutputStream stream) throws IOException {
/* 682 */       getImplementation().writeState(state, stream);
/*     */     }
/*     */ 
/*     */     
/*     */     public void writeState(State state, File stateDirectory) throws IOException {
/* 687 */       getImplementation().writeState(state, stateDirectory);
/*     */     }
/*     */ 
/*     */     
/*     */     @Deprecated
/*     */     public State readState(InputStream stream) throws IOException {
/* 693 */       return getImplementation().readState(stream);
/*     */     }
/*     */ 
/*     */     
/*     */     @Deprecated
/*     */     public State readState(DataInputStream stream) throws IOException {
/* 699 */       return getImplementation().readState(stream);
/*     */     }
/*     */ 
/*     */     
/*     */     public State readState(File stateDirectory) throws IOException {
/* 704 */       return getImplementation().readState(stateDirectory);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.osgi-3.18.400.jar!\org\eclipse\osgi\service\resolver\StateObjectFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */