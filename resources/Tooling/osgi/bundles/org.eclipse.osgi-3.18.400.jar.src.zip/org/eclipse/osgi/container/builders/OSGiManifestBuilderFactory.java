/*      */ package org.eclipse.osgi.container.builders;
/*      */ 
/*      */ import java.util.ArrayList;
/*      */ import java.util.Arrays;
/*      */ import java.util.Collection;
/*      */ import java.util.Collections;
/*      */ import java.util.Enumeration;
/*      */ import java.util.HashMap;
/*      */ import java.util.HashSet;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.Set;
/*      */ import org.eclipse.osgi.container.ModuleRevisionBuilder;
/*      */ import org.eclipse.osgi.internal.framework.FilterImpl;
/*      */ import org.eclipse.osgi.internal.messages.Msg;
/*      */ import org.eclipse.osgi.internal.util.Tokenizer;
/*      */ import org.eclipse.osgi.util.ManifestElement;
/*      */ import org.eclipse.osgi.util.NLS;
/*      */ import org.osgi.framework.BundleException;
/*      */ import org.osgi.framework.FrameworkUtil;
/*      */ import org.osgi.framework.InvalidSyntaxException;
/*      */ import org.osgi.framework.Version;
/*      */ import org.osgi.framework.VersionRange;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public final class OSGiManifestBuilderFactory
/*      */ {
/*      */   private static final String ATTR_TYPE_STRING = "string";
/*      */   private static final String ATTR_TYPE_VERSION = "version";
/*      */   private static final String ATTR_TYPE_URI = "uri";
/*      */   private static final String ATTR_TYPE_LONG = "long";
/*      */   private static final String ATTR_TYPE_DOUBLE = "double";
/*      */   private static final String ATTR_TYPE_SET = "set";
/*      */   private static final String ATTR_TYPE_LIST = "List";
/*      */   private static final String ATTR_OLD_REPRIVIDE = "reprovide";
/*      */   private static final String HEADER_OLD_PROVIDE_PACKAGE = "Provide-Package";
/*   67 */   private static final String[] DEFINED_OSGI_VALIDATE_HEADERS = new String[] { "Import-Package", "DynamicImport-Package", "Export-Package", "Fragment-Host", "Bundle-SymbolicName", "Require-Bundle" };
/*   68 */   private static final Collection<String> SYSTEM_CAPABILITIES = Collections.unmodifiableCollection(Arrays.asList(new String[] { "osgi.ee", "osgi.native" }));
/*   69 */   private static final Collection<String> PROHIBITED_CAPABILITIES = Collections.unmodifiableCollection(Arrays.asList(new String[] { "osgi.identity" }));
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static ModuleRevisionBuilder createBuilder(Map<String, String> manifest) throws BundleException {
/*   78 */     return createBuilder(manifest, null, null, null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static ModuleRevisionBuilder createBuilder(Map<String, String> manifest, String symbolicNameAlias, String extraExports, String extraCapabilities) throws BundleException {
/*   96 */     ModuleRevisionBuilder builder = new ModuleRevisionBuilder();
/*      */     
/*   98 */     int manifestVersion = getManifestVersion(manifest);
/*   99 */     if (manifestVersion >= 2) {
/*  100 */       validateHeaders(manifest, (extraExports != null));
/*      */     }
/*      */     
/*  103 */     Object symbolicName = getSymbolicNameAndVersion(builder, manifest, symbolicNameAlias, manifestVersion);
/*      */     
/*  105 */     Collection<Map<String, Object>> exportedPackages = new ArrayList<>();
/*  106 */     getPackageExports(builder, ManifestElement.parseHeader("Export-Package", manifest.get("Export-Package")), symbolicName, exportedPackages);
/*  107 */     getPackageExports(builder, ManifestElement.parseHeader("Provide-Package", manifest.get("Provide-Package")), symbolicName, exportedPackages);
/*  108 */     if (extraExports != null && !extraExports.isEmpty()) {
/*  109 */       getPackageExports(builder, ManifestElement.parseHeader("Export-Package", extraExports), symbolicName, exportedPackages);
/*      */     }
/*  111 */     getPackageImports(builder, manifest, exportedPackages, manifestVersion);
/*      */     
/*  113 */     getRequireBundle(builder, ManifestElement.parseHeader("Require-Bundle", manifest.get("Require-Bundle")));
/*      */     
/*  115 */     getProvideCapabilities(builder, ManifestElement.parseHeader("Provide-Capability", manifest.get("Provide-Capability")), (extraCapabilities == null));
/*  116 */     if (extraCapabilities != null && !extraCapabilities.isEmpty()) {
/*  117 */       getProvideCapabilities(builder, ManifestElement.parseHeader("Provide-Capability", extraCapabilities), false);
/*      */     }
/*  119 */     getRequireCapabilities(builder, ManifestElement.parseHeader("Require-Capability", manifest.get("Require-Capability")));
/*      */     
/*  121 */     addRequireEclipsePlatform(builder, manifest);
/*      */     
/*  123 */     getEquinoxDataCapability(builder, manifest);
/*      */     
/*  125 */     getFragmentHost(builder, ManifestElement.parseHeader("Fragment-Host", manifest.get("Fragment-Host")));
/*      */     
/*  127 */     convertBREEs(builder, manifest);
/*      */     
/*  129 */     getNativeCode(builder, manifest);
/*  130 */     return builder; } private static void validateHeaders(Map<String, String> manifest, boolean allowJavaExports) throws BundleException {
/*      */     byte b;
/*      */     int i;
/*      */     String[] arrayOfString;
/*  134 */     for (i = (arrayOfString = DEFINED_OSGI_VALIDATE_HEADERS).length, b = 0; b < i; ) { String definedOSGiValidateHeader = arrayOfString[b];
/*  135 */       String header = manifest.get(definedOSGiValidateHeader);
/*  136 */       if (header != null) {
/*  137 */         ManifestElement[] elements = ManifestElement.parseHeader(definedOSGiValidateHeader, header);
/*  138 */         checkForDuplicateDirectivesAttributes(definedOSGiValidateHeader, elements);
/*  139 */         if (definedOSGiValidateHeader == "Import-Package") {
/*  140 */           checkImportExportSyntax(definedOSGiValidateHeader, elements, false, false, false);
/*      */         }
/*  142 */         if (definedOSGiValidateHeader == "DynamicImport-Package") {
/*  143 */           checkImportExportSyntax(definedOSGiValidateHeader, elements, false, true, false);
/*      */         }
/*  145 */         if (definedOSGiValidateHeader == "Export-Package") {
/*  146 */           checkImportExportSyntax(definedOSGiValidateHeader, elements, true, false, allowJavaExports);
/*      */         }
/*  148 */         if (definedOSGiValidateHeader == "Fragment-Host") {
/*  149 */           checkExtensionBundle(definedOSGiValidateHeader, elements, manifest);
/*      */         }
/*  151 */       } else if (definedOSGiValidateHeader == "Bundle-SymbolicName") {
/*  152 */         throw new BundleException("Bundle-SymbolicName header is required.", 3);
/*      */       } 
/*      */       b++; }
/*      */   
/*      */   }
/*      */ 
/*      */   
/*      */   private static void checkImportExportSyntax(String headerKey, ManifestElement[] elements, boolean export, boolean dynamic, boolean allowJavaExports) throws BundleException {
/*  160 */     if (elements == null)
/*      */       return; 
/*  162 */     int length = elements.length;
/*  163 */     Set<String> packages = new HashSet<>(length);
/*  164 */     for (int i = 0; i < length; i++) {
/*      */       
/*  166 */       String[] packageNames = elements[i].getValueComponents(); byte b; int j; String[] arrayOfString1;
/*  167 */       for (j = (arrayOfString1 = packageNames).length, b = 0; b < j; ) { String packageName = arrayOfString1[b];
/*  168 */         if (!export && !dynamic && packages.contains(packageName)) {
/*  169 */           String message = NLS.bind(Msg.MANIFEST_INVALID_HEADER_EXCEPTION, headerKey, elements[i].toString());
/*  170 */           throw new BundleException(String.valueOf(message) + " : " + NLS.bind(Msg.HEADER_PACKAGE_DUPLICATES, packageName), 3);
/*      */         } 
/*      */         
/*  173 */         if (export && !allowJavaExports && packageName.startsWith("java.")) {
/*  174 */           String message = NLS.bind(Msg.MANIFEST_INVALID_HEADER_EXCEPTION, headerKey, elements[i].toString());
/*  175 */           throw new BundleException(String.valueOf(message) + " : " + NLS.bind(Msg.HEADER_PACKAGE_JAVA, packageName), 3);
/*      */         } 
/*  177 */         packages.add(packageName);
/*      */         b++; }
/*      */       
/*  180 */       String version = elements[i].getAttribute("version");
/*  181 */       if (version != null) {
/*  182 */         String specVersion = elements[i].getAttribute("specification-version");
/*  183 */         if (specVersion != null && !specVersion.equals(version)) {
/*  184 */           throw new BundleException(NLS.bind(Msg.HEADER_VERSION_ERROR, "version", "specification-version"), 3);
/*      */         }
/*      */       } 
/*      */       
/*  188 */       if (export) {
/*  189 */         if (elements[i].getAttribute("bundle-symbolic-name") != null) {
/*  190 */           String message = NLS.bind(Msg.MANIFEST_INVALID_HEADER_EXCEPTION, headerKey, elements[i].toString());
/*  191 */           throw new BundleException(String.valueOf(message) + " : " + NLS.bind(Msg.HEADER_EXPORT_ATTR_ERROR, "bundle-symbolic-name", "Export-Package"), 3);
/*      */         } 
/*  193 */         if (elements[i].getAttribute("bundle-version") != null) {
/*  194 */           String message = NLS.bind(Msg.MANIFEST_INVALID_HEADER_EXCEPTION, headerKey, elements[i].toString());
/*  195 */           throw new BundleException(NLS.bind(String.valueOf(message) + " : " + Msg.HEADER_EXPORT_ATTR_ERROR, "bundle-version", "Export-Package"), 3);
/*      */         } 
/*      */       } 
/*      */     } 
/*      */   } private static void checkForDuplicateDirectivesAttributes(String headerKey, ManifestElement[] elements) throws BundleException {
/*      */     byte b;
/*      */     int i;
/*      */     ManifestElement[] arrayOfManifestElement;
/*  203 */     for (i = (arrayOfManifestElement = elements).length, b = 0; b < i; ) { ManifestElement element = arrayOfManifestElement[b];
/*  204 */       Enumeration<String> directiveKeys = element.getDirectiveKeys();
/*  205 */       if (directiveKeys != null) {
/*  206 */         while (directiveKeys.hasMoreElements()) {
/*  207 */           String key = directiveKeys.nextElement();
/*  208 */           String[] directives = element.getDirectives(key);
/*  209 */           if (directives.length > 1) {
/*  210 */             String message = NLS.bind(Msg.MANIFEST_INVALID_HEADER_EXCEPTION, headerKey, element.toString());
/*  211 */             throw new BundleException(NLS.bind(String.valueOf(message) + " : " + Msg.HEADER_DIRECTIVE_DUPLICATES, key), 3);
/*      */           } 
/*      */         } 
/*      */       }
/*  215 */       Enumeration<String> attrKeys = element.getKeys();
/*  216 */       if (attrKeys != null)
/*  217 */         while (attrKeys.hasMoreElements()) {
/*  218 */           String key = attrKeys.nextElement();
/*  219 */           String[] attrs = element.getAttributes(key);
/*  220 */           if (attrs.length > 1) {
/*  221 */             String message = NLS.bind(Msg.MANIFEST_INVALID_HEADER_EXCEPTION, headerKey, element.toString());
/*  222 */             throw new BundleException(String.valueOf(message) + " : " + NLS.bind(Msg.HEADER_ATTRIBUTE_DUPLICATES, key), 3);
/*      */           } 
/*      */         }  
/*      */       b++; }
/*      */   
/*      */   }
/*      */   
/*      */   private static void checkExtensionBundle(String headerKey, ManifestElement[] elements, Map<String, String> manifest) throws BundleException {
/*  230 */     if (elements.length == 0)
/*      */       return; 
/*  232 */     String hostName = elements[0].getValue();
/*      */     
/*  234 */     if (!hostName.equals("system.bundle") && !hostName.equals("org.eclipse.osgi")) {
/*  235 */       if (elements[0].getDirective("extension") != null) {
/*  236 */         String message = NLS.bind(Msg.MANIFEST_INVALID_HEADER_EXCEPTION, headerKey, elements[0].toString());
/*  237 */         throw new BundleException(String.valueOf(message) + " : " + NLS.bind(Msg.HEADER_EXTENSION_ERROR, hostName), 3);
/*      */       } 
/*      */     } else {
/*  240 */       if (manifest.get("Require-Bundle") != null)
/*  241 */         throw new BundleException(Msg.OSGiManifestBuilderFactory_ExtensionReqBundleError, 3); 
/*  242 */       if (manifest.get("Bundle-NativeCode") != null) {
/*  243 */         throw new BundleException(Msg.OSGiManifestBuilderFactory_ExtensionNativeError, 3);
/*      */       }
/*      */     } 
/*      */   }
/*      */   
/*      */   private static int getManifestVersion(Map<String, String> manifest) {
/*  249 */     String manifestVersionHeader = manifest.get("Bundle-ManifestVersion");
/*  250 */     return (manifestVersionHeader == null) ? 1 : Integer.parseInt(manifestVersionHeader);
/*      */   }
/*      */   
/*      */   private static Object getSymbolicNameAndVersion(ModuleRevisionBuilder builder, Map<String, String> manifest, String symbolicNameAlias, int manifestVersion) throws BundleException {
/*  254 */     boolean isFragment = (manifest.get("Fragment-Host") != null);
/*  255 */     builder.setTypes(isFragment ? 1 : 0);
/*  256 */     String version = manifest.get("Bundle-Version");
/*      */     try {
/*  258 */       builder.setVersion((version != null) ? Version.parseVersion(version) : Version.emptyVersion);
/*  259 */     } catch (IllegalArgumentException ex) {
/*  260 */       if (manifestVersion >= 2) {
/*  261 */         String message = NLS.bind(Msg.OSGiManifestBuilderFactory_InvalidManifestError, "Bundle-Version", version);
/*  262 */         throw new BundleException(message, 3, ex);
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  268 */     Object<String> symbolicName = null;
/*  269 */     String symbolicNameHeader = manifest.get("Bundle-SymbolicName");
/*  270 */     if (symbolicNameHeader != null) {
/*  271 */       ManifestElement[] symbolicNameElements = ManifestElement.parseHeader("Bundle-SymbolicName", symbolicNameHeader);
/*  272 */       if (symbolicNameElements.length > 0) {
/*  273 */         ManifestElement bsnElement = symbolicNameElements[0];
/*  274 */         builder.setSymbolicName(bsnElement.getValue());
/*  275 */         if (symbolicNameAlias != null) {
/*  276 */           List<String> result = new ArrayList<>();
/*  277 */           result.add(builder.getSymbolicName());
/*  278 */           result.add(symbolicNameAlias);
/*  279 */           symbolicName = (Object<String>)result;
/*      */         } else {
/*  281 */           symbolicName = (Object<String>)builder.getSymbolicName();
/*      */         } 
/*  283 */         Map<String, String> directives = getDirectives(bsnElement);
/*  284 */         directives.remove("uses");
/*  285 */         directives.remove("effective");
/*  286 */         Map<String, Object> attributes = getAttributes(bsnElement);
/*  287 */         if (!directives.containsKey("singleton")) {
/*      */           
/*  289 */           Object singletonAttr = attributes.get("singleton");
/*  290 */           if ("true".equals(singletonAttr)) {
/*  291 */             directives.put("singleton", (String)singletonAttr);
/*      */           }
/*      */         } 
/*  294 */         if (!isFragment) {
/*      */           
/*  296 */           Map<String, Object> bundleAttributes = new HashMap<>(attributes);
/*  297 */           bundleAttributes.put("osgi.wiring.bundle", symbolicName);
/*  298 */           bundleAttributes.put("bundle-version", builder.getVersion());
/*  299 */           builder.addCapability("osgi.wiring.bundle", directives, bundleAttributes);
/*      */ 
/*      */ 
/*      */           
/*  303 */           if (!"never".equals(directives.get("fragment-attachment"))) {
/*  304 */             Map<String, Object> hostAttributes = new HashMap<>(attributes);
/*  305 */             hostAttributes.put("osgi.wiring.host", symbolicName);
/*  306 */             hostAttributes.put("bundle-version", builder.getVersion());
/*  307 */             builder.addCapability("osgi.wiring.host", directives, hostAttributes);
/*      */           } 
/*      */         } 
/*      */ 
/*      */         
/*  312 */         Map<String, Object> identityAttributes = new HashMap<>(attributes);
/*  313 */         identityAttributes.put("osgi.identity", builder.getSymbolicName());
/*  314 */         identityAttributes.put("version", builder.getVersion());
/*  315 */         identityAttributes.put("type", isFragment ? "osgi.fragment" : "osgi.bundle");
/*  316 */         builder.addCapability("osgi.identity", directives, identityAttributes);
/*      */       } 
/*      */     } 
/*      */     
/*  320 */     return (symbolicName == null) ? symbolicNameAlias : symbolicName;
/*      */   }
/*      */   
/*      */   private static void getPackageExports(ModuleRevisionBuilder builder, ManifestElement[] exportElements, Object symbolicName, Collection<Map<String, Object>> exportedPackages) throws BundleException {
/*  324 */     if (exportElements == null)
/*      */       return;  byte b; int i; ManifestElement[] arrayOfManifestElement;
/*  326 */     for (i = (arrayOfManifestElement = exportElements).length, b = 0; b < i; ) { ManifestElement exportElement = arrayOfManifestElement[b];
/*  327 */       String[] packageNames = exportElement.getValueComponents();
/*  328 */       Map<String, Object> attributes = getAttributes(exportElement);
/*  329 */       Map<String, String> directives = getDirectives(exportElement);
/*  330 */       directives.remove("effective");
/*  331 */       String versionAttr = (String)attributes.remove("version");
/*      */       
/*  333 */       String specVersionAttr = (String)attributes.remove("specification-version");
/*  334 */       Version version = (versionAttr == null) ? parsePackageVersion(packageNames, specVersionAttr) : 
/*  335 */         parsePackageVersion(packageNames, versionAttr);
/*  336 */       attributes.put("version", version);
/*  337 */       if (symbolicName != null) {
/*  338 */         attributes.put("bundle-symbolic-name", symbolicName);
/*      */       }
/*  340 */       attributes.put("bundle-version", builder.getVersion()); byte b1; int j; String[] arrayOfString1;
/*  341 */       for (j = (arrayOfString1 = packageNames).length, b1 = 0; b1 < j; ) { String packageName = arrayOfString1[b1];
/*  342 */         Map<String, Object> packageAttrs = new HashMap<>(attributes);
/*  343 */         packageAttrs.put("osgi.wiring.package", packageName);
/*  344 */         builder.addCapability("osgi.wiring.package", directives, packageAttrs);
/*  345 */         exportedPackages.add(packageAttrs);
/*      */         b1++; }
/*      */       
/*      */       b++; }
/*      */   
/*      */   } private static Version parsePackageVersion(String[] packageNames, String versionSpec) throws BundleException {
/*      */     try {
/*  352 */       return (versionSpec == null) ? Version.emptyVersion : Version.parseVersion(versionSpec);
/*  353 */     } catch (IllegalArgumentException e) {
/*  354 */       throw new BundleException(
/*  355 */           "Invalid value for version specified for package(s) " + Arrays.toString(packageNames), 
/*  356 */           3, e);
/*      */     } 
/*      */   }
/*      */   
/*      */   private static void getPackageImports(ModuleRevisionBuilder builder, Map<String, String> manifest, Collection<Map<String, Object>> exportedPackages, int manifestVersion) throws BundleException {
/*  361 */     Collection<String> importPackageNames = new ArrayList<>();
/*  362 */     ManifestElement[] importElements = ManifestElement.parseHeader("Import-Package", manifest.get("Import-Package"));
/*  363 */     ManifestElement[] dynamicImportElements = ManifestElement.parseHeader("DynamicImport-Package", manifest.get("DynamicImport-Package"));
/*  364 */     addPackageImports(builder, importElements, importPackageNames, false);
/*  365 */     addPackageImports(builder, dynamicImportElements, importPackageNames, true);
/*  366 */     if (manifestVersion < 2)
/*  367 */       addImplicitImports(builder, exportedPackages, importPackageNames); 
/*      */   }
/*      */   
/*      */   private static void addPackageImports(ModuleRevisionBuilder builder, ManifestElement[] importElements, Collection<String> importPackageNames, boolean dynamic) throws BundleException {
/*  371 */     if (importElements == null)
/*      */       return;  byte b; int i; ManifestElement[] arrayOfManifestElement;
/*  373 */     for (i = (arrayOfManifestElement = importElements).length, b = 0; b < i; ) { ManifestElement importElement = arrayOfManifestElement[b];
/*  374 */       String[] packageNames = importElement.getValueComponents();
/*  375 */       Map<String, Object> attributes = getAttributes(importElement);
/*  376 */       Map<String, String> directives = getDirectives(importElement);
/*  377 */       directives.remove("effective");
/*  378 */       directives.remove("cardinality");
/*  379 */       if (dynamic) {
/*  380 */         directives.put("resolution", "dynamic");
/*      */       }
/*  382 */       String versionRangeAttr = (String)attributes.remove("version");
/*      */       
/*  384 */       String specVersionRangeAttr = (String)attributes.remove("specification-version");
/*  385 */       VersionRange versionRange = (versionRangeAttr == null) ? ((specVersionRangeAttr == null) ? null : new VersionRange(specVersionRangeAttr)) : new VersionRange(versionRangeAttr);
/*  386 */       String bundleVersionRangeAttr = (String)attributes.remove("bundle-version");
/*  387 */       VersionRange bundleVersionRange = (bundleVersionRangeAttr == null) ? null : new VersionRange(bundleVersionRangeAttr);
/*      */ 
/*      */       
/*  390 */       Object optionalAttr = attributes.remove("optional"); byte b1; int j; String[] arrayOfString1;
/*  391 */       for (j = (arrayOfString1 = packageNames).length, b1 = 0; b1 < j; ) { String packageName = arrayOfString1[b1];
/*  392 */         if (!dynamic) {
/*  393 */           importPackageNames.add(packageName);
/*      */         }
/*      */         
/*  396 */         Map<String, String> packageDirectives = new HashMap<>(directives);
/*  397 */         StringBuilder filter = new StringBuilder();
/*  398 */         filter.append('(').append("osgi.wiring.package").append('=').append(packageName).append(')');
/*  399 */         int size = filter.length();
/*  400 */         for (Map.Entry<String, Object> attribute : attributes.entrySet())
/*  401 */           filter.append('(').append(attribute.getKey()).append('=').append(attribute.getValue()).append(')'); 
/*  402 */         if (versionRange != null)
/*  403 */           filter.append(versionRange.toFilterString("version")); 
/*  404 */         if (bundleVersionRange != null)
/*  405 */           filter.append(bundleVersionRange.toFilterString("bundle-version")); 
/*  406 */         if (size != filter.length())
/*      */         {
/*  408 */           filter.insert(0, "(&").append(')'); } 
/*  409 */         packageDirectives.put("filter", filter.toString());
/*      */ 
/*      */         
/*  412 */         if (dynamic && packageName.indexOf('*') >= 0) {
/*  413 */           packageDirectives.put("cardinality", "multiple");
/*      */         }
/*      */         
/*  416 */         if ("true".equals(optionalAttr) && packageDirectives.get("resolution") == null) {
/*  417 */           packageDirectives.put("resolution", "optional");
/*      */         }
/*  419 */         builder.addRequirement("osgi.wiring.package", packageDirectives, new HashMap<>(0));
/*      */         b1++; }
/*      */       
/*      */       b++; }
/*      */   
/*      */   } private static void addImplicitImports(ModuleRevisionBuilder builder, Collection<Map<String, Object>> exportedPackages, Collection<String> importPackageNames) {
/*  425 */     for (Map<String, Object> exportAttributes : exportedPackages) {
/*  426 */       String packageName = (String)exportAttributes.get("osgi.wiring.package");
/*  427 */       if (importPackageNames.contains(packageName))
/*      */         continue; 
/*  429 */       importPackageNames.add(packageName);
/*  430 */       Version packageVersion = (Version)exportAttributes.get("version");
/*  431 */       StringBuilder filter = new StringBuilder();
/*  432 */       filter.append("(&(").append("osgi.wiring.package").append('=').append(packageName).append(')');
/*  433 */       filter.append('(').append("version").append(">=").append(packageVersion).append("))");
/*  434 */       Map<String, String> directives = new HashMap<>(1);
/*  435 */       directives.put("filter", filter.toString());
/*  436 */       builder.addRequirement("osgi.wiring.package", directives, new HashMap<>(0));
/*      */     } 
/*      */   }
/*      */   
/*      */   private static Map<String, String> getDirectives(ManifestElement element) {
/*  441 */     Map<String, String> directives = new HashMap<>();
/*  442 */     Enumeration<String> keys = element.getDirectiveKeys();
/*  443 */     if (keys == null)
/*  444 */       return directives; 
/*  445 */     while (keys.hasMoreElements()) {
/*  446 */       String key = keys.nextElement();
/*  447 */       directives.put(key, element.getDirective(key));
/*      */     } 
/*  449 */     return directives;
/*      */   }
/*      */   
/*      */   private static void getRequireBundle(ModuleRevisionBuilder builder, ManifestElement[] requireBundles) throws BundleException {
/*  453 */     if (requireBundles == null)
/*      */       return;  byte b; int i; ManifestElement[] arrayOfManifestElement;
/*  455 */     for (i = (arrayOfManifestElement = requireBundles).length, b = 0; b < i; ) { ManifestElement requireElement = arrayOfManifestElement[b];
/*  456 */       String[] bundleNames = requireElement.getValueComponents();
/*  457 */       Map<String, Object> attributes = getAttributes(requireElement);
/*  458 */       Map<String, String> directives = getDirectives(requireElement);
/*  459 */       directives.remove("cardinality");
/*  460 */       directives.remove("effective");
/*  461 */       String versionRangeAttr = (String)attributes.remove("bundle-version");
/*  462 */       VersionRange versionRange = (versionRangeAttr == null) ? null : new VersionRange(versionRangeAttr);
/*      */ 
/*      */       
/*  465 */       Object optionalAttr = attributes.remove("optional");
/*  466 */       Object reprovideAttr = attributes.remove("reprovide"); byte b1; int j; String[] arrayOfString1;
/*  467 */       for (j = (arrayOfString1 = bundleNames).length, b1 = 0; b1 < j; ) { String bundleName = arrayOfString1[b1];
/*  468 */         if (!bundleName.equals(builder.getSymbolicName())) {
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  473 */           Map<String, String> bundleDirectives = new HashMap<>(directives);
/*  474 */           StringBuilder filter = new StringBuilder();
/*  475 */           filter.append('(').append("osgi.wiring.bundle").append('=').append(bundleName).append(')');
/*  476 */           int size = filter.length();
/*  477 */           for (Map.Entry<String, Object> attribute : attributes.entrySet())
/*  478 */             filter.append('(').append(attribute.getKey()).append('=').append(attribute.getValue()).append(')'); 
/*  479 */           if (versionRange != null)
/*  480 */             filter.append(versionRange.toFilterString("bundle-version")); 
/*  481 */           if (size != filter.length())
/*      */           {
/*  483 */             filter.insert(0, "(&").append(')'); } 
/*  484 */           bundleDirectives.put("filter", filter.toString());
/*      */           
/*  486 */           if ("true".equals(optionalAttr) && bundleDirectives.get("resolution") == null) {
/*  487 */             bundleDirectives.put("resolution", "optional");
/*      */           }
/*  489 */           if ("true".equals(reprovideAttr) && bundleDirectives.get("visibility") == null) {
/*  490 */             bundleDirectives.put("visibility", "reexport");
/*      */           }
/*  492 */           builder.addRequirement("osgi.wiring.bundle", bundleDirectives, new HashMap<>(0));
/*      */         } 
/*      */         b1++; }
/*      */       
/*      */       b++; }
/*      */      } private static void getFragmentHost(ModuleRevisionBuilder builder, ManifestElement[] fragmentHosts) throws BundleException {
/*  498 */     if (fragmentHosts == null || fragmentHosts.length == 0) {
/*      */       return;
/*      */     }
/*  501 */     ManifestElement fragmentHost = fragmentHosts[0];
/*  502 */     String hostName = fragmentHost.getValue();
/*  503 */     Map<String, Object> attributes = getAttributes(fragmentHost);
/*  504 */     Map<String, String> directives = getDirectives(fragmentHost);
/*  505 */     directives.remove("cardinality");
/*  506 */     directives.remove("effective");
/*      */     
/*  508 */     String versionRangeAttr = (String)attributes.remove("bundle-version");
/*  509 */     VersionRange versionRange = (versionRangeAttr == null) ? null : new VersionRange(versionRangeAttr);
/*      */ 
/*      */     
/*  512 */     StringBuilder filter = new StringBuilder();
/*  513 */     filter.append('(').append("osgi.wiring.host").append('=').append(hostName).append(')');
/*  514 */     int size = filter.length();
/*  515 */     for (Map.Entry<String, Object> attribute : attributes.entrySet())
/*  516 */       filter.append('(').append(attribute.getKey()).append('=').append(attribute.getValue()).append(')'); 
/*  517 */     if (versionRange != null)
/*  518 */       filter.append(versionRange.toFilterString("bundle-version")); 
/*  519 */     if (size != filter.length())
/*      */     {
/*  521 */       filter.insert(0, "(&").append(')'); } 
/*  522 */     directives.put("filter", filter.toString());
/*  523 */     builder.addRequirement("osgi.wiring.host", directives, new HashMap<>(0));
/*      */     
/*  525 */     directives = Collections.singletonMap("effective", "information");
/*  526 */     builder.addCapability("equinox.fragment", directives, Collections.singletonMap("equinox.fragment", hostName));
/*      */   }
/*      */   
/*      */   private static void getProvideCapabilities(ModuleRevisionBuilder builder, ManifestElement[] provideElements, boolean checkSystemCapabilities) throws BundleException {
/*  530 */     if (provideElements == null)
/*      */       return;  byte b; int i; ManifestElement[] arrayOfManifestElement;
/*  532 */     for (i = (arrayOfManifestElement = provideElements).length, b = 0; b < i; ) { ManifestElement provideElement = arrayOfManifestElement[b];
/*  533 */       String[] namespaces = provideElement.getValueComponents();
/*  534 */       Map<String, Object> attributes = getAttributes(provideElement);
/*  535 */       Map<String, String> directives = getDirectives(provideElement); byte b1; int j; String[] arrayOfString1;
/*  536 */       for (j = (arrayOfString1 = namespaces).length, b1 = 0; b1 < j; ) { String namespace = arrayOfString1[b1];
/*  537 */         if (PROHIBITED_CAPABILITIES.contains(namespace) || (checkSystemCapabilities && SYSTEM_CAPABILITIES.contains(namespace))) {
/*  538 */           throw new BundleException("A bundle is not allowed to define a capability in the " + namespace + " name space.", 3);
/*      */         }
/*      */         
/*  541 */         builder.addCapability(namespace, directives, attributes);
/*      */         b1++; }
/*      */       
/*      */       b++; }
/*      */   
/*      */   } private static void getRequireCapabilities(ModuleRevisionBuilder builder, ManifestElement[] requireElements) throws BundleException {
/*  547 */     if (requireElements == null)
/*      */       return;  byte b; int i; ManifestElement[] arrayOfManifestElement;
/*  549 */     for (i = (arrayOfManifestElement = requireElements).length, b = 0; b < i; ) { ManifestElement requireElement = arrayOfManifestElement[b];
/*  550 */       String[] namespaces = requireElement.getValueComponents();
/*  551 */       Map<String, Object> attributes = getAttributes(requireElement);
/*  552 */       Map<String, String> directives = getDirectives(requireElement); byte b1; int j; String[] arrayOfString1;
/*  553 */       for (j = (arrayOfString1 = namespaces).length, b1 = 0; b1 < j; ) { String namespace = arrayOfString1[b1];
/*  554 */         builder.addRequirement(namespace, directives, attributes);
/*      */         b1++; }
/*      */       
/*      */       b++; }
/*      */   
/*      */   } private static void addRequireEclipsePlatform(ModuleRevisionBuilder builder, Map<String, String> manifest) {
/*  560 */     String platformFilter = manifest.get("Eclipse-PlatformFilter");
/*  561 */     if (platformFilter == null) {
/*      */       return;
/*      */     }
/*      */     
/*  565 */     HashMap<String, String> directives = new HashMap<>();
/*  566 */     directives.put("filter", platformFilter);
/*  567 */     builder.addRequirement("eclipse.platform", directives, Collections.emptyMap());
/*      */   }
/*      */ 
/*      */   
/*      */   private static void getEquinoxDataCapability(ModuleRevisionBuilder builder, Map<String, String> manifest) throws BundleException {
/*  572 */     Map<String, Object> attributes = new HashMap<>();
/*      */ 
/*      */     
/*  575 */     ManifestElement[] policyElements = ManifestElement.parseHeader("Bundle-ActivationPolicy", manifest.get("Bundle-ActivationPolicy"));
/*  576 */     if (policyElements != null) {
/*  577 */       ManifestElement policy = policyElements[0];
/*  578 */       String policyName = policy.getValue();
/*  579 */       if ("lazy".equals(policyName)) {
/*  580 */         attributes.put("activation.policy", policyName);
/*  581 */         String includeSpec = policy.getDirective("include");
/*  582 */         if (includeSpec != null) {
/*  583 */           attributes.put("lazy.include", convertValueWithNoWhitespace("List<String>", includeSpec));
/*      */         }
/*  585 */         String excludeSpec = policy.getDirective("exclude");
/*  586 */         if (excludeSpec != null) {
/*  587 */           attributes.put("lazy.exclude", convertValueWithNoWhitespace("List<String>", excludeSpec));
/*      */         }
/*      */       } 
/*      */     } else {
/*  591 */       policyElements = ManifestElement.parseHeader("Eclipse-LazyStart", manifest.get("Eclipse-LazyStart"));
/*  592 */       if (policyElements == null) {
/*  593 */         policyElements = ManifestElement.parseHeader("Eclipse-AutoStart", manifest.get("Eclipse-AutoStart"));
/*      */       }
/*  595 */       if (policyElements != null) {
/*  596 */         ManifestElement policy = policyElements[0];
/*  597 */         String excludeSpec = policy.getAttribute("exceptions");
/*  598 */         if ("true".equals(policy.getValue())) {
/*  599 */           attributes.put("activation.policy", "lazy");
/*  600 */           if (excludeSpec != null) {
/*  601 */             attributes.put("lazy.exclude", convertValueWithNoWhitespace("List<String>", excludeSpec));
/*      */           
/*      */           }
/*      */         }
/*  605 */         else if (excludeSpec != null) {
/*  606 */           attributes.put("activation.policy", "lazy");
/*  607 */           attributes.put("lazy.include", convertValueWithNoWhitespace("List<String>", excludeSpec));
/*      */         } 
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  614 */     String activator = manifest.get("Bundle-Activator");
/*  615 */     if (activator == null && manifest.get("Fragment-Host") != null)
/*      */     {
/*      */ 
/*      */       
/*  619 */       activator = manifest.get("ExtensionBundle-Activator");
/*      */     }
/*  621 */     if (activator != null) {
/*  622 */       attributes.put("activator", activator);
/*      */     }
/*      */ 
/*      */     
/*  626 */     ManifestElement[] classpathElements = ManifestElement.parseHeader("Bundle-ClassPath", manifest.get("Bundle-ClassPath"));
/*  627 */     if (classpathElements != null) {
/*  628 */       List<String> classpath = new ArrayList<>(); byte b; int i; ManifestElement[] arrayOfManifestElement;
/*  629 */       for (i = (arrayOfManifestElement = classpathElements).length, b = 0; b < i; ) { ManifestElement element = arrayOfManifestElement[b];
/*  630 */         String[] components = element.getValueComponents();
/*  631 */         Collections.addAll(classpath, components); b++; }
/*      */       
/*  633 */       attributes.put("classpath", classpath);
/*      */     } 
/*      */ 
/*      */     
/*  637 */     ManifestElement[] buddyPolicies = ManifestElement.parseHeader("Eclipse-BuddyPolicy", manifest.get("Eclipse-BuddyPolicy"));
/*  638 */     if (buddyPolicies != null) {
/*  639 */       List<String> policies = new ArrayList<>(); byte b; int i; ManifestElement[] arrayOfManifestElement;
/*  640 */       for (i = (arrayOfManifestElement = buddyPolicies).length, b = 0; b < i; ) { ManifestElement element = arrayOfManifestElement[b];
/*  641 */         Collections.addAll(policies, element.getValueComponents()); b++; }
/*      */       
/*  643 */       attributes.put("buddy.policy", policies);
/*      */     } 
/*      */ 
/*      */     
/*  647 */     ManifestElement[] registeredBuddies = ManifestElement.parseHeader("Eclipse-RegisterBuddy", manifest.get("Eclipse-RegisterBuddy"));
/*  648 */     if (registeredBuddies != null) {
/*  649 */       List<String> buddies = new ArrayList<>(); byte b; int i; ManifestElement[] arrayOfManifestElement;
/*  650 */       for (i = (arrayOfManifestElement = registeredBuddies).length, b = 0; b < i; ) { ManifestElement element = arrayOfManifestElement[b];
/*  651 */         Collections.addAll(buddies, element.getValueComponents()); b++; }
/*      */       
/*  653 */       attributes.put("buddy.registered", buddies);
/*      */     } 
/*      */ 
/*      */     
/*  657 */     if (!attributes.isEmpty()) {
/*  658 */       Map<String, String> directives = Collections.singletonMap("effective", "information");
/*  659 */       builder.addCapability("equinox.module.data", directives, attributes);
/*      */     } 
/*      */   }
/*      */   
/*      */   private static Map<String, Object> getAttributes(ManifestElement element) throws BundleException {
/*  664 */     Enumeration<String> keys = element.getKeys();
/*  665 */     Map<String, Object> attributes = new HashMap<>();
/*  666 */     if (keys == null)
/*  667 */       return attributes; 
/*  668 */     while (keys.hasMoreElements()) {
/*  669 */       String key = keys.nextElement();
/*  670 */       String value = element.getAttribute(key);
/*  671 */       int colonIndex = key.indexOf(':');
/*  672 */       String type = "string";
/*  673 */       if (colonIndex > 0) {
/*  674 */         type = key.substring(colonIndex + 1).trim();
/*  675 */         key = key.substring(0, colonIndex).trim();
/*      */       } 
/*  677 */       attributes.put(key, convertValue(type, value));
/*      */     } 
/*  679 */     return attributes;
/*      */   }
/*      */   
/*      */   private static Object convertValueWithNoWhitespace(String type, String value) throws BundleException {
/*  683 */     value = value.replaceAll("\\s", "");
/*  684 */     return convertValue(type, value);
/*      */   }
/*      */   
/*      */   private static Object convertValue(String type, String value) throws BundleException {
/*  688 */     if ("string".equalsIgnoreCase(type)) {
/*  689 */       return value;
/*      */     }
/*      */     
/*  692 */     String trimmed = value.trim();
/*  693 */     if ("double".equalsIgnoreCase(type))
/*  694 */       return Double.valueOf(trimmed); 
/*  695 */     if ("long".equalsIgnoreCase(type))
/*  696 */       return Long.valueOf(trimmed); 
/*  697 */     if ("uri".equalsIgnoreCase(type))
/*      */     {
/*  699 */       return trimmed; } 
/*  700 */     if ("version".equalsIgnoreCase(type))
/*  701 */       return new Version(trimmed); 
/*  702 */     if ("set".equalsIgnoreCase(type))
/*      */     {
/*  704 */       return Collections.unmodifiableList(Arrays.asList((Object[])ManifestElement.getArrayFromList(trimmed, ",")));
/*      */     }
/*      */     
/*  707 */     Tokenizer listTokenizer = new Tokenizer(type);
/*  708 */     String listType = listTokenizer.getToken("<");
/*  709 */     if (!"List".equalsIgnoreCase(listType))
/*  710 */       throw new BundleException("Unsupported type: " + type, 3); 
/*  711 */     char c = listTokenizer.getChar();
/*  712 */     String componentType = "string";
/*  713 */     if (c == '<') {
/*  714 */       componentType = listTokenizer.getToken(">");
/*  715 */       if (listTokenizer.getChar() != '>')
/*  716 */         throw new BundleException("Invalid type, missing ending '>' : " + type, 3); 
/*      */     } 
/*  718 */     List<String> tokens = (new Tokenizer(value)).getEscapedTokens(",");
/*  719 */     List<Object> components = new ArrayList();
/*  720 */     for (String component : tokens) {
/*  721 */       components.add(convertValue(componentType, component));
/*      */     }
/*  723 */     return Collections.unmodifiableList(components);
/*      */   }
/*      */ 
/*      */   
/*      */   private static void convertBREEs(ModuleRevisionBuilder builder, Map<String, String> manifest) throws BundleException {
/*  728 */     String filterSpec, brees[] = ManifestElement.getArrayFromList(manifest.get("Bundle-RequiredExecutionEnvironment"));
/*  729 */     if (brees == null || brees.length == 0)
/*      */       return; 
/*  731 */     List<String> breeFilters = new ArrayList<>(); byte b; int i; String[] arrayOfString1;
/*  732 */     for (i = (arrayOfString1 = brees).length, b = 0; b < i; ) { String bree = arrayOfString1[b];
/*  733 */       breeFilters.add(createOSGiEERequirementFilter(bree)); b++; }
/*      */     
/*  735 */     if (breeFilters.size() == 1) {
/*  736 */       filterSpec = breeFilters.get(0);
/*      */     } else {
/*  738 */       StringBuilder filterBuf = new StringBuilder("(|");
/*  739 */       for (String breeFilter : breeFilters) {
/*  740 */         filterBuf.append(breeFilter);
/*      */       }
/*  742 */       filterSpec = filterBuf.append(")").toString();
/*      */     } 
/*      */     
/*  745 */     Map<String, String> directives = new HashMap<>(1);
/*  746 */     directives.put("filter", filterSpec);
/*  747 */     builder.addRequirement("osgi.ee", directives, new HashMap<>(0));
/*      */   }
/*      */   
/*      */   static String escapeFilterInput(String value) {
/*  751 */     boolean escaped = false;
/*  752 */     int inlen = value.length();
/*  753 */     int outlen = inlen << 1;
/*      */     
/*  755 */     char[] output = new char[outlen];
/*  756 */     value.getChars(0, inlen, output, inlen);
/*      */     
/*  758 */     int cursor = 0;
/*  759 */     for (int i = inlen; i < outlen; i++) {
/*  760 */       char c = output[i];
/*  761 */       switch (c) {
/*      */         case '(':
/*      */         case ')':
/*      */         case '*':
/*      */         case '\\':
/*  766 */           output[cursor] = '\\';
/*  767 */           cursor++;
/*  768 */           escaped = true;
/*      */           break;
/*      */       } 
/*      */       
/*  772 */       output[cursor] = c;
/*  773 */       cursor++;
/*      */     } 
/*      */     
/*  776 */     return escaped ? new String(output, 0, cursor) : value;
/*      */   }
/*      */   
/*      */   private static String createOSGiEERequirementFilter(String bree) throws BundleException {
/*  780 */     String filterSpec, nameVersion[] = getOSGiEENameVersion(bree);
/*  781 */     String eeName = nameVersion[0];
/*  782 */     String v = nameVersion[1];
/*      */     
/*  784 */     if (v == null) {
/*  785 */       filterSpec = "(osgi.ee=" + eeName + ")";
/*      */     } else {
/*  787 */       filterSpec = "(&(osgi.ee=" + eeName + ")(version=" + v + "))";
/*      */     } 
/*      */     try {
/*  790 */       FilterImpl.newInstance(filterSpec);
/*  791 */     } catch (InvalidSyntaxException invalidSyntaxException) {
/*  792 */       filterSpec = "(osgi.ee=" + bree + ")";
/*      */       
/*      */       try {
/*  795 */         FilterImpl.newInstance(filterSpec);
/*  796 */       } catch (InvalidSyntaxException e1) {
/*  797 */         throw new BundleException("Error converting required execution environment.", 3, e1);
/*      */       } 
/*      */     } 
/*  800 */     return filterSpec;
/*      */   }
/*      */   
/*      */   private static String[] getOSGiEENameVersion(String bree) {
/*  804 */     String ee1 = null;
/*  805 */     String ee2 = null;
/*  806 */     String v1 = null;
/*  807 */     String v2 = null;
/*  808 */     int separator = bree.indexOf('/');
/*  809 */     if (separator <= 0 || separator == bree.length() - 1) {
/*  810 */       ee1 = bree;
/*      */     } else {
/*  812 */       ee1 = bree.substring(0, separator);
/*  813 */       ee2 = bree.substring(separator + 1);
/*      */     } 
/*  815 */     int v1idx = ee1.indexOf('-');
/*  816 */     if (v1idx > 0 && v1idx < ee1.length() - 1) {
/*      */       
/*      */       try {
/*      */         
/*  820 */         v1 = ee1.substring(v1idx + 1);
/*      */         
/*  822 */         Version.parseVersion(v1);
/*  823 */         ee1 = ee1.substring(0, v1idx);
/*  824 */       } catch (IllegalArgumentException illegalArgumentException) {
/*  825 */         v1 = null;
/*      */       } 
/*      */     }
/*      */     
/*  829 */     int v2idx = (ee2 == null) ? -1 : ee2.indexOf('-');
/*  830 */     if (v2idx > 0 && v2idx < ee2.length() - 1) {
/*      */       
/*      */       try {
/*      */         
/*  834 */         v2 = ee2.substring(v2idx + 1);
/*  835 */         Version.parseVersion(v2);
/*  836 */         ee2 = ee2.substring(0, v2idx);
/*  837 */       } catch (IllegalArgumentException illegalArgumentException) {
/*  838 */         v2 = null;
/*      */       } 
/*      */     }
/*      */     
/*  842 */     if (v1 == null)
/*  843 */       v1 = v2; 
/*  844 */     if (v1 != null && v2 != null && !v1.equals(v2)) {
/*  845 */       ee1 = bree;
/*  846 */       ee2 = null;
/*  847 */       v1 = null;
/*  848 */       v2 = null;
/*      */     } 
/*  850 */     if ("J2SE".equals(ee1))
/*  851 */       ee1 = "JavaSE"; 
/*  852 */     if ("J2SE".equals(ee2)) {
/*  853 */       ee2 = "JavaSE";
/*      */     }
/*  855 */     String eeName = String.valueOf(ee1) + ((ee2 == null) ? "" : (String.valueOf('/') + ee2));
/*      */     
/*  857 */     return new String[] { escapeFilterInput(eeName), v1 };
/*      */   }
/*      */   
/*      */   static class NativeClause implements Comparable<NativeClause> {
/*      */     private final int manifestIndex;
/*      */     final List<String> nativePaths;
/*      */     final String filter;
/*      */     private final Version highestFloor;
/*      */     private final boolean hasLanguage;
/*      */     
/*      */     NativeClause(int manifestIndex, ManifestElement clause) throws BundleException {
/*  868 */       this.manifestIndex = manifestIndex;
/*  869 */       this.nativePaths = new ArrayList<>(Arrays.asList(clause.getValueComponents()));
/*  870 */       StringBuilder sb = new StringBuilder();
/*  871 */       sb.append("(&");
/*  872 */       addToNativeCodeFilter(sb, clause, "osname");
/*  873 */       addToNativeCodeFilter(sb, clause, "processor");
/*  874 */       this.highestFloor = (Version)addToNativeCodeFilter(sb, clause, "osversion");
/*  875 */       this.hasLanguage = ((Boolean)addToNativeCodeFilter(sb, clause, "language")).booleanValue();
/*  876 */       String selectionFilter = clause.getAttribute("selection-filter");
/*  877 */       if (selectionFilter != null) {
/*      */         
/*      */         try {
/*  880 */           FrameworkUtil.createFilter(selectionFilter);
/*  881 */         } catch (InvalidSyntaxException e) {
/*  882 */           throw new BundleException("Bad native code selection-filter.", 3, e);
/*      */         } 
/*  884 */         sb.append(selectionFilter);
/*      */       } 
/*  886 */       sb.append(')');
/*  887 */       String filterResult = sb.toString();
/*  888 */       if (filterResult.equals("(&)"))
/*      */       {
/*  890 */         filterResult = "(osgi.native.osname=*)";
/*      */       }
/*  892 */       this.filter = filterResult;
/*      */     }
/*      */     
/*      */     private static Object addToNativeCodeFilter(StringBuilder filter, ManifestElement nativeCode, String attribute) {
/*  896 */       Boolean hasLanguage = Boolean.FALSE;
/*  897 */       Version highestFloor = null;
/*  898 */       String[] attrValues = nativeCode.getAttributes(attribute);
/*  899 */       if (attrValues != null) {
/*      */         
/*  901 */         String filterAttribute = attribute;
/*  902 */         if ("osname".equals(attribute)) {
/*  903 */           filterAttribute = "osgi.native.osname";
/*  904 */         } else if ("processor".equals(attribute)) {
/*  905 */           filterAttribute = "osgi.native.processor";
/*  906 */         } else if ("language".equals(attribute)) {
/*  907 */           filterAttribute = "osgi.native.language";
/*  908 */           hasLanguage = Boolean.valueOf((attrValues.length > 0));
/*  909 */         } else if ("osversion".equals(attribute)) {
/*  910 */           filterAttribute = "osgi.native.osversion";
/*      */         } 
/*      */         
/*  913 */         if (attrValues.length > 1)
/*  914 */           filter.append("(|");  byte b; int i;
/*      */         String[] arrayOfString;
/*  916 */         for (i = (arrayOfString = attrValues).length, b = 0; b < i; ) { String attrAlias = arrayOfString[b];
/*  917 */           if ("osgi.native.osversion".equals(filterAttribute)) {
/*  918 */             VersionRange range = new VersionRange(attrAlias);
/*  919 */             if (highestFloor == null || highestFloor.compareTo(range.getLeft()) < 0) {
/*  920 */               highestFloor = range.getLeft();
/*      */             }
/*  922 */             filter.append(range.toFilterString(filterAttribute));
/*      */           } else {
/*  924 */             filter.append('(').append(filterAttribute).append("~=").append(OSGiManifestBuilderFactory.escapeFilterInput(attrAlias)).append(')');
/*      */           }  b++; }
/*      */         
/*  927 */         if (attrValues.length > 1) {
/*  928 */           filter.append(')');
/*      */         }
/*      */       } 
/*  931 */       return "language".equals(attribute) ? hasLanguage : highestFloor;
/*      */     }
/*      */ 
/*      */     
/*      */     public int compareTo(NativeClause other) {
/*  936 */       if (this.highestFloor != null) {
/*  937 */         if (other == null) {
/*  938 */           return -1;
/*      */         }
/*  940 */         if (other.highestFloor == null) {
/*  941 */           return -1;
/*      */         }
/*  943 */         int compareVersions = this.highestFloor.compareTo(other.highestFloor);
/*  944 */         if (compareVersions != 0) {
/*  945 */           return -compareVersions;
/*      */         }
/*  947 */       } else if (other.highestFloor != null) {
/*  948 */         return 1;
/*      */       } 
/*  950 */       if (this.hasLanguage) {
/*  951 */         return other.hasLanguage ? (this.manifestIndex - other.manifestIndex) : 1;
/*      */       }
/*  953 */       return other.hasLanguage ? -1 : (this.manifestIndex - other.manifestIndex);
/*      */     }
/*      */   }
/*      */   
/*      */   private static void getNativeCode(ModuleRevisionBuilder builder, Map<String, String> manifest) throws BundleException {
/*  958 */     ManifestElement[] elements = ManifestElement.parseHeader("Bundle-NativeCode", manifest.get("Bundle-NativeCode"));
/*  959 */     if (elements == null) {
/*      */       return;
/*      */     }
/*      */     
/*  963 */     boolean optional = false;
/*      */     
/*  965 */     List<NativeClause> nativeClauses = new ArrayList<>();
/*  966 */     for (int i = 0; i < elements.length; i++) {
/*  967 */       if (i == elements.length - 1) {
/*  968 */         optional = elements[i].getValue().equals("*");
/*      */       }
/*  970 */       if (!optional) {
/*  971 */         nativeClauses.add(new NativeClause(i, elements[i]));
/*      */       }
/*      */     } 
/*  974 */     Collections.sort(nativeClauses);
/*      */     
/*  976 */     int numNativePaths = nativeClauses.size();
/*  977 */     if (numNativePaths == 0) {
/*  978 */       String msg = "No native code clauses found in the value of Bundle-NativeCode: " + (String)manifest.get("Bundle-NativeCode");
/*  979 */       throw new BundleException(msg, 3);
/*      */     } 
/*  981 */     StringBuilder allNativeFilters = new StringBuilder();
/*  982 */     if (numNativePaths > 1) {
/*  983 */       allNativeFilters.append("(|");
/*      */     }
/*  985 */     Map<String, Object> attributes = new HashMap<>(2);
/*  986 */     for (int j = 0; j < numNativePaths; j++) {
/*  987 */       NativeClause nativeClause = nativeClauses.get(j);
/*  988 */       if (numNativePaths == 1) {
/*  989 */         attributes.put("native.paths", nativeClause.nativePaths);
/*      */       } else {
/*  991 */         attributes.put("native.paths." + j, nativeClause.nativePaths);
/*      */       } 
/*  993 */       allNativeFilters.append(((NativeClause)nativeClauses.get(j)).filter);
/*      */     } 
/*  995 */     if (numNativePaths > 1) {
/*  996 */       allNativeFilters.append(')');
/*      */     }
/*      */     
/*  999 */     Map<String, String> directives = new HashMap<>(2);
/* 1000 */     directives.put("filter", allNativeFilters.toString());
/* 1001 */     if (optional) {
/* 1002 */       directives.put("resolution", "optional");
/*      */     }
/*      */     
/* 1005 */     builder.addRequirement("osgi.native", directives, attributes);
/*      */   }
/*      */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.osgi-3.18.400.jar!\org\eclipse\osgi\container\builders\OSGiManifestBuilderFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */