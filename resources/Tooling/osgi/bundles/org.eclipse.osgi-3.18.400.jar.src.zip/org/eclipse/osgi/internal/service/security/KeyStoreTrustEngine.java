/*     */ package org.eclipse.osgi.internal.service.security;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.security.GeneralSecurityException;
/*     */ import java.security.InvalidKeyException;
/*     */ import java.security.KeyStore;
/*     */ import java.security.KeyStoreException;
/*     */ import java.security.NoSuchAlgorithmException;
/*     */ import java.security.NoSuchProviderException;
/*     */ import java.security.SignatureException;
/*     */ import java.security.cert.Certificate;
/*     */ import java.security.cert.CertificateException;
/*     */ import java.security.cert.X509Certificate;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Enumeration;
/*     */ import java.util.List;
/*     */ import org.eclipse.osgi.internal.signedcontent.SignedBundleHook;
/*     */ import org.eclipse.osgi.internal.signedcontent.SignedContentMessages;
/*     */ import org.eclipse.osgi.service.security.TrustEngine;
/*     */ import org.eclipse.osgi.util.NLS;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class KeyStoreTrustEngine
/*     */   extends TrustEngine
/*     */ {
/*     */   private KeyStore keyStore;
/*     */   private final String type;
/*     */   private final String path;
/*     */   private final char[] password;
/*     */   private final String name;
/*     */   private final SignedBundleHook signedBundleHook;
/*     */   
/*     */   public KeyStoreTrustEngine(String path, String type, char[] password, String name, SignedBundleHook signedBundleHook) {
/*  55 */     this.path = path;
/*  56 */     this.type = type;
/*  57 */     this.password = password;
/*  58 */     this.name = name;
/*  59 */     this.signedBundleHook = signedBundleHook;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String getType() {
/*  67 */     return this.type;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String getPath() {
/*  75 */     return this.path;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private char[] getPassword() {
/*  83 */     return this.password;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private synchronized KeyStore getKeyStore() throws IOException, GeneralSecurityException {
/*  92 */     if (this.keyStore == null) {
/*  93 */       this.keyStore = KeyStore.getInstance(getType());
/*  94 */       InputStream in = getInputStream();
/*     */       try {
/*  96 */         loadStore(this.keyStore, in);
/*     */       } finally {
/*     */         try {
/*  99 */           in.close();
/* 100 */         } catch (IOException iOException) {}
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 106 */     if (this.keyStore == null) {
/* 107 */       throw new KeyStoreException(NLS.bind(SignedContentMessages.Default_Trust_Keystore_Load_Failed, getPath()));
/*     */     }
/* 109 */     return this.keyStore;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Certificate findTrustAnchor(Certificate[] certChain) throws IOException {
/* 115 */     if (certChain == null || certChain.length == 0) {
/* 116 */       throw new IllegalArgumentException("Certificate chain is required");
/*     */     }
/*     */     try {
/* 119 */       Certificate rootCert = null;
/* 120 */       KeyStore store = getKeyStore();
/* 121 */       for (int i = 0; i < certChain.length; i++) {
/* 122 */         if (certChain[i] instanceof X509Certificate) {
/* 123 */           if (i == certChain.length - 1) {
/*     */ 
/*     */             
/* 126 */             X509Certificate cert = (X509Certificate)certChain[i];
/* 127 */             if (cert.getSubjectDN().equals(cert.getIssuerDN())) {
/* 128 */               cert.verify(cert.getPublicKey());
/* 129 */               rootCert = cert;
/*     */             } else {
/*     */               
/* 132 */               return findAlternativeRoot(cert, store);
/*     */             } 
/*     */           } else {
/* 135 */             X509Certificate nextX509Cert = (X509Certificate)certChain[i + 1];
/* 136 */             certChain[i].verify(nextX509Cert.getPublicKey());
/*     */           } 
/*     */         }
/*     */         
/* 140 */         synchronized (store) {
/* 141 */           String alias = (rootCert == null) ? null : store.getCertificateAlias(rootCert);
/* 142 */           if (alias != null)
/* 143 */             return store.getCertificate(alias); 
/* 144 */           if (rootCert != certChain[i]) {
/* 145 */             alias = store.getCertificateAlias(certChain[i]);
/* 146 */             if (alias != null) {
/* 147 */               return store.getCertificate(alias);
/*     */             }
/*     */           } 
/*     */           
/* 151 */           if (certChain.length > 1 && i == certChain.length - 1 && certChain[i - 1] instanceof X509Certificate)
/* 152 */             return findAlternativeRoot((X509Certificate)certChain[i - 1], store); 
/*     */         } 
/*     */       } 
/* 155 */     } catch (KeyStoreException e) {
/* 156 */       throw new IOException(e.getMessage(), e);
/* 157 */     } catch (GeneralSecurityException e) {
/* 158 */       if (this.signedBundleHook != null) {
/* 159 */         this.signedBundleHook.log(e.getMessage(), 2, e);
/*     */       }
/* 161 */       return null;
/*     */     } 
/* 163 */     return null;
/*     */   }
/*     */   
/*     */   private Certificate findAlternativeRoot(X509Certificate cert, KeyStore store) throws InvalidKeyException, KeyStoreException, NoSuchAlgorithmException, NoSuchProviderException, SignatureException, CertificateException {
/* 167 */     synchronized (store) {
/* 168 */       for (Enumeration<String> e = store.aliases(); e.hasMoreElements(); ) {
/* 169 */         Certificate nextCert = store.getCertificate(e.nextElement());
/* 170 */         if (nextCert instanceof X509Certificate && ((X509Certificate)nextCert).getSubjectDN().equals(cert.getIssuerDN())) {
/* 171 */           cert.verify(nextCert.getPublicKey());
/* 172 */           return nextCert;
/*     */         } 
/*     */       } 
/* 175 */       return null;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   protected String doAddTrustAnchor(Certificate cert, String alias) throws IOException, GeneralSecurityException {
/* 181 */     if (isReadOnly())
/* 182 */       throw new IOException(SignedContentMessages.Default_Trust_Read_Only); 
/* 183 */     if (cert == null) {
/* 184 */       throw new IllegalArgumentException("Certificate must be specified");
/*     */     }
/*     */     try {
/* 187 */       KeyStore store = getKeyStore();
/* 188 */       synchronized (store) {
/* 189 */         String oldAlias = store.getCertificateAlias(cert);
/* 190 */         if (oldAlias != null)
/* 191 */           throw new CertificateException(SignedContentMessages.Default_Trust_Existing_Cert); 
/* 192 */         Certificate oldCert = store.getCertificate(alias);
/* 193 */         if (oldCert != null)
/* 194 */           throw new CertificateException(SignedContentMessages.Default_Trust_Existing_Alias); 
/* 195 */         store.setCertificateEntry(alias, cert);
/* 196 */         OutputStream out = getOutputStream();
/*     */         try {
/* 198 */           saveStore(store, out);
/*     */         } finally {
/* 200 */           safeClose(out);
/*     */         } 
/*     */       } 
/* 203 */     } catch (KeyStoreException ke) {
/* 204 */       throw (CertificateException)(new CertificateException(ke.getMessage())).initCause(ke);
/*     */     } 
/* 206 */     return alias;
/*     */   }
/*     */ 
/*     */   
/*     */   protected void doRemoveTrustAnchor(Certificate cert) throws IOException, GeneralSecurityException {
/* 211 */     if (isReadOnly())
/* 212 */       throw new IOException(SignedContentMessages.Default_Trust_Read_Only); 
/* 213 */     if (cert == null) {
/* 214 */       throw new IllegalArgumentException("Certificate must be specified");
/*     */     }
/*     */     try {
/* 217 */       KeyStore store = getKeyStore();
/* 218 */       synchronized (store) {
/* 219 */         String alias = store.getCertificateAlias(cert);
/* 220 */         if (alias == null) {
/* 221 */           throw new CertificateException(SignedContentMessages.Default_Trust_Cert_Not_Found);
/*     */         }
/* 223 */         removeTrustAnchor(alias);
/*     */       } 
/* 225 */     } catch (KeyStoreException ke) {
/* 226 */       throw (CertificateException)(new CertificateException(ke.getMessage())).initCause(ke);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void doRemoveTrustAnchor(String alias) throws IOException, GeneralSecurityException {
/* 233 */     if (alias == null) {
/* 234 */       throw new IllegalArgumentException("Alias must be specified");
/*     */     }
/*     */     try {
/* 237 */       KeyStore store = getKeyStore();
/* 238 */       synchronized (store) {
/* 239 */         Certificate oldCert = store.getCertificate(alias);
/* 240 */         if (oldCert == null)
/* 241 */           throw new CertificateException(SignedContentMessages.Default_Trust_Cert_Not_Found); 
/* 242 */         store.deleteEntry(alias);
/* 243 */         OutputStream out = getOutputStream();
/*     */         try {
/* 245 */           saveStore(store, out);
/*     */         } finally {
/* 247 */           safeClose(out);
/*     */         } 
/*     */       } 
/* 250 */     } catch (KeyStoreException ke) {
/* 251 */       throw (CertificateException)(new CertificateException(ke.getMessage())).initCause(ke);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Certificate getTrustAnchor(String alias) throws IOException, GeneralSecurityException {
/* 258 */     if (alias == null) {
/* 259 */       throw new IllegalArgumentException("Alias must be specified");
/*     */     }
/*     */     
/*     */     try {
/* 263 */       KeyStore store = getKeyStore();
/* 264 */       synchronized (store) {
/* 265 */         return store.getCertificate(alias);
/*     */       } 
/* 267 */     } catch (KeyStoreException ke) {
/* 268 */       throw (CertificateException)(new CertificateException(ke.getMessage())).initCause(ke);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String[] getAliases() throws IOException, GeneralSecurityException {
/* 275 */     List<String> returnList = new ArrayList<>();
/*     */     try {
/* 277 */       KeyStore store = getKeyStore();
/* 278 */       synchronized (store) {
/* 279 */         for (Enumeration<String> aliases = store.aliases(); aliases.hasMoreElements(); ) {
/* 280 */           String currentAlias = aliases.nextElement();
/* 281 */           if (store.isCertificateEntry(currentAlias)) {
/* 282 */             returnList.add(currentAlias);
/*     */           }
/*     */         } 
/*     */       } 
/* 286 */     } catch (KeyStoreException ke) {
/* 287 */       throw (CertificateException)(new CertificateException(ke.getMessage())).initCause(ke);
/*     */     } 
/* 289 */     return returnList.<String>toArray(new String[0]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void loadStore(KeyStore store, InputStream is) throws IOException, GeneralSecurityException {
/* 296 */     store.load(is, getPassword());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void saveStore(KeyStore store, OutputStream os) throws IOException, GeneralSecurityException {
/* 303 */     store.store(os, getPassword());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void safeClose(OutputStream out) {
/*     */     try {
/* 313 */       if (out != null)
/* 314 */         out.close(); 
/* 315 */     } catch (IOException iOException) {}
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private InputStream getInputStream() throws IOException {
/* 326 */     return new FileInputStream(new File(getPath()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private OutputStream getOutputStream() throws IOException {
/* 336 */     File file = new File(getPath());
/* 337 */     if (!file.exists()) {
/* 338 */       file.createNewFile();
/*     */     }
/* 340 */     return new FileOutputStream(file);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isReadOnly() {
/* 345 */     return !(getPassword() != null && (new File(this.path)).canWrite());
/*     */   }
/*     */ 
/*     */   
/*     */   public String getName() {
/* 350 */     return this.name;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.osgi-3.18.400.jar!\org\eclipse\osgi\internal\service\security\KeyStoreTrustEngine.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */