/*     */ package org.eclipse.osgi.internal.log;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.InputStream;
/*     */ import java.net.URL;
/*     */ import java.security.cert.X509Certificate;
/*     */ import java.util.Dictionary;
/*     */ import java.util.Enumeration;
/*     */ import java.util.HashMap;
/*     */ import java.util.Hashtable;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.eclipse.equinox.log.ExtendedLogReaderService;
/*     */ import org.eclipse.equinox.log.ExtendedLogService;
/*     */ import org.eclipse.equinox.log.LogFilter;
/*     */ import org.eclipse.osgi.internal.framework.BundleContextImpl;
/*     */ import org.osgi.framework.AllServiceListener;
/*     */ import org.osgi.framework.Bundle;
/*     */ import org.osgi.framework.BundleContext;
/*     */ import org.osgi.framework.BundleEvent;
/*     */ import org.osgi.framework.BundleListener;
/*     */ import org.osgi.framework.FrameworkEvent;
/*     */ import org.osgi.framework.FrameworkListener;
/*     */ import org.osgi.framework.ServiceEvent;
/*     */ import org.osgi.framework.ServiceListener;
/*     */ import org.osgi.framework.ServiceReference;
/*     */ import org.osgi.framework.ServiceRegistration;
/*     */ import org.osgi.framework.SynchronousBundleListener;
/*     */ import org.osgi.framework.Version;
/*     */ import org.osgi.service.log.LogLevel;
/*     */ import org.osgi.service.log.LogListener;
/*     */ import org.osgi.service.log.LogReaderService;
/*     */ import org.osgi.service.log.LogService;
/*     */ import org.osgi.service.log.LoggerFactory;
/*     */ import org.osgi.service.log.admin.LoggerAdmin;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LogServiceManager
/*     */   implements SynchronousBundleListener, FrameworkListener, AllServiceListener
/*     */ {
/*     */   private static final String LOGGER_FRAMEWORK_EVENT = "Events.Framework";
/*     */   private static final String LOGGER_BUNDLE_EVENT = "Events.Bundle";
/*     */   private static final String LOGGER_SERVICE_EVENT = "Events.Service";
/*  52 */   private static final String[] LOGSERVICE_CLASSES = new String[] { LogService.class.getName(), LoggerFactory.class.getName(), ExtendedLogService.class.getName() };
/*  53 */   private static final String[] LOGREADERSERVICE_CLASSES = new String[] { LogReaderService.class.getName(), ExtendedLogReaderService.class.getName() };
/*     */   
/*     */   private ServiceRegistration<?> logReaderServiceRegistration;
/*     */   private ServiceRegistration<?> logServiceRegistration;
/*     */   private ServiceRegistration<LoggerAdmin> loggerAdminRegistration;
/*     */   private final ExtendedLogReaderServiceFactory logReaderServiceFactory;
/*     */   private final ExtendedLogServiceFactory logServiceFactory;
/*     */   private final ExtendedLogServiceImpl systemBundleLog;
/*     */   private EventAdminAdapter eventAdminAdapter;
/*     */   private ConfigAdminListener configAdminListener;
/*     */   
/*     */   public LogServiceManager(int maxHistory, LogLevel defaultLevel, boolean captureLogEntryLocation, LogListener... systemListeners) {
/*  65 */     this.logReaderServiceFactory = new ExtendedLogReaderServiceFactory(maxHistory, defaultLevel);
/*  66 */     this.logServiceFactory = new ExtendedLogServiceFactory(this.logReaderServiceFactory, captureLogEntryLocation);
/*  67 */     this.systemBundleLog = this.logServiceFactory.getLogService(new MockSystemBundle()); byte b; int i; LogListener[] arrayOfLogListener;
/*  68 */     for (i = (arrayOfLogListener = systemListeners).length, b = 0; b < i; ) { LogListener logListener = arrayOfLogListener[b];
/*  69 */       if (logListener instanceof LogFilter) {
/*  70 */         this.logReaderServiceFactory.addLogListener(logListener, (LogFilter)logListener);
/*     */       } else {
/*  72 */         this.logReaderServiceFactory.addLogListener(logListener, ExtendedLogReaderServiceFactory.NULL_LOGGER_FILTER);
/*     */       } 
/*     */       b++; }
/*     */   
/*     */   }
/*     */   public void start(BundleContext context) {
/*  78 */     this.logReaderServiceFactory.start(((BundleContextImpl)context).getContainer());
/*  79 */     this.systemBundleLog.setBundle(context.getBundle());
/*  80 */     context.addBundleListener((BundleListener)this);
/*  81 */     context.addServiceListener((ServiceListener)this);
/*  82 */     context.addFrameworkListener(this);
/*     */     
/*  84 */     context.addBundleListener(this.logServiceFactory);
/*  85 */     this.logReaderServiceRegistration = context.registerService(LOGREADERSERVICE_CLASSES, this.logReaderServiceFactory, null);
/*  86 */     this.logServiceRegistration = context.registerService(LOGSERVICE_CLASSES, this.logServiceFactory, null);
/*  87 */     Hashtable<String, Object> loggerAdminProps = new Hashtable<>();
/*     */     
/*  89 */     loggerAdminProps.put("osgi.log.service.id", this.logServiceRegistration.getReference().getProperty("service.id"));
/*  90 */     this.loggerAdminRegistration = context.registerService(LoggerAdmin.class, this.logServiceFactory.getLoggerAdmin(), loggerAdminProps);
/*     */     
/*  92 */     this.eventAdminAdapter = new EventAdminAdapter(context, this.logReaderServiceFactory);
/*  93 */     this.eventAdminAdapter.start();
/*  94 */     this.configAdminListener = new ConfigAdminListener(context, this.logServiceFactory);
/*  95 */     this.configAdminListener.start();
/*     */   }
/*     */   
/*     */   public void stop(BundleContext context) {
/*  99 */     this.configAdminListener.stop();
/* 100 */     this.configAdminListener = null;
/* 101 */     this.eventAdminAdapter.stop();
/* 102 */     this.eventAdminAdapter = null;
/* 103 */     this.loggerAdminRegistration.unregister();
/* 104 */     this.loggerAdminRegistration = null;
/* 105 */     this.logServiceRegistration.unregister();
/* 106 */     this.logServiceRegistration = null;
/* 107 */     this.logReaderServiceRegistration.unregister();
/* 108 */     this.logReaderServiceRegistration = null;
/* 109 */     this.logServiceFactory.shutdown();
/* 110 */     context.removeFrameworkListener(this);
/* 111 */     context.removeServiceListener((ServiceListener)this);
/* 112 */     context.removeBundleListener((BundleListener)this);
/* 113 */     this.logReaderServiceFactory.stop();
/*     */   }
/*     */   
/*     */   public ExtendedLogService getSystemBundleLog() {
/* 117 */     return this.systemBundleLog;
/*     */   }
/*     */   
/*     */   LoggerAdmin getLoggerAdmin() {
/* 121 */     return this.logServiceFactory.getLoggerAdmin();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void bundleChanged(BundleEvent event) {
/* 131 */     Bundle bundle = event.getBundle();
/* 132 */     String bsn = (bundle == null) ? null : bundle.getSymbolicName();
/* 133 */     String loggerName = (bsn == null) ? "Events.Bundle" : ("Events.Bundle." + bsn);
/* 134 */     if (this.logReaderServiceFactory.isLoggable(bundle, loggerName, 3)) {
/* 135 */       LoggerImpl logger = (LoggerImpl)this.systemBundleLog.getLogger(loggerName);
/* 136 */       int eventType = event.getType();
/* 137 */       logger.log(bundle, event, null, 3, getBundleEventTypeName(eventType), null, null);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void serviceChanged(ServiceEvent event) {
/* 147 */     ServiceReference<?> reference = event.getServiceReference();
/* 148 */     Bundle bundle = reference.getBundle();
/* 149 */     int eventType = event.getType();
/* 150 */     String bsn = (bundle == null) ? null : bundle.getSymbolicName();
/* 151 */     String loggerName = (bsn == null) ? "Events.Service" : ("Events.Service." + bsn);
/*     */     
/* 153 */     int logType = (eventType == 2) ? 4 : 3;
/* 154 */     if (this.logReaderServiceFactory.isLoggable(bundle, loggerName, logType)) {
/* 155 */       LoggerImpl logger = (LoggerImpl)this.systemBundleLog.getLogger(loggerName);
/* 156 */       logger.log(bundle, event, null, logType, getServiceEventTypeName(eventType), reference, null);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void frameworkEvent(FrameworkEvent event) {
/*     */     int logType;
/* 167 */     Bundle bundle = event.getBundle();
/* 168 */     int eventType = event.getType();
/*     */     
/* 170 */     switch (eventType) {
/*     */       case 2:
/* 172 */         logType = 1;
/*     */         break;
/*     */       case 16:
/* 175 */         logType = 2;
/*     */         break;
/*     */       default:
/* 178 */         logType = 3;
/*     */         break;
/*     */     } 
/* 181 */     String bsn = (bundle == null) ? null : bundle.getSymbolicName();
/* 182 */     String loggerName = (bsn == null) ? "Events.Framework" : ("Events.Framework." + bsn);
/* 183 */     if (this.logReaderServiceFactory.isLoggable(bundle, loggerName, logType)) {
/* 184 */       LoggerImpl logger = (LoggerImpl)this.systemBundleLog.getLogger(loggerName);
/* 185 */       logger.log(bundle, event, null, logType, getFrameworkEventTypeName(eventType), null, event.getThrowable());
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static String getBundleEventTypeName(int type) {
/* 194 */     switch (type) {
/*     */       case 1:
/* 196 */         return "BundleEvent INSTALLED";
/*     */       
/*     */       case 32:
/* 199 */         return "BundleEvent RESOLVED";
/*     */       
/*     */       case 2:
/* 202 */         return "BundleEvent STARTED";
/*     */       
/*     */       case 128:
/* 205 */         return "BundleEvent STARTING";
/*     */       
/*     */       case 4:
/* 208 */         return "BundleEvent STOPPED";
/*     */       
/*     */       case 256:
/* 211 */         return "BundleEvent STOPPING";
/*     */       
/*     */       case 16:
/* 214 */         return "BundleEvent UNINSTALLED";
/*     */       
/*     */       case 64:
/* 217 */         return "BundleEvent UNRESOLVED";
/*     */       
/*     */       case 8:
/* 220 */         return "BundleEvent UPDATED";
/*     */     } 
/*     */     
/* 223 */     return "BundleEvent " + Integer.toHexString(type);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static String getServiceEventTypeName(int type) {
/* 232 */     switch (type) {
/*     */       case 1:
/* 234 */         return "ServiceEvent REGISTERED";
/*     */       
/*     */       case 2:
/* 237 */         return "ServiceEvent MODIFIED";
/*     */       
/*     */       case 4:
/* 240 */         return "ServiceEvent UNREGISTERING";
/*     */     } 
/*     */     
/* 243 */     return "ServiceEvent " + Integer.toHexString(type);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static String getFrameworkEventTypeName(int type) {
/* 252 */     switch (type) {
/*     */       case 2:
/* 254 */         return "FrameworkEvent ERROR";
/*     */       
/*     */       case 32:
/* 257 */         return "FrameworkEvent INFO";
/*     */       
/*     */       case 4:
/* 260 */         return "FrameworkEvent PACKAGES REFRESHED";
/*     */       
/*     */       case 1:
/* 263 */         return "FrameworkEvent STARTED";
/*     */       
/*     */       case 8:
/* 266 */         return "FrameworkEvent STARTLEVEL CHANGED";
/*     */       
/*     */       case 16:
/* 269 */         return "FrameworkEvent WARNING";
/*     */     } 
/*     */     
/* 272 */     return "FrameworkEvent " + Integer.toHexString(type);
/*     */   }
/*     */ 
/*     */   
/*     */   static class MockSystemBundle
/*     */     implements Bundle
/*     */   {
/*     */     public int compareTo(Bundle o) {
/* 280 */       long idcomp = getBundleId() - o.getBundleId();
/* 281 */       return (idcomp < 0L) ? -1 : ((idcomp > 0L) ? 1 : 0);
/*     */     }
/*     */ 
/*     */     
/*     */     public int getState() {
/* 286 */       return 4;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void start(int options) {}
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void start() {}
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void stop(int options) {}
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void stop() {}
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void update(InputStream input) {}
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void update() {}
/*     */ 
/*     */ 
/*     */     
/*     */     public void uninstall() {}
/*     */ 
/*     */ 
/*     */     
/*     */     public Dictionary<String, String> getHeaders() {
/* 326 */       return new Hashtable<>();
/*     */     }
/*     */ 
/*     */     
/*     */     public long getBundleId() {
/* 331 */       return 0L;
/*     */     }
/*     */ 
/*     */     
/*     */     public String getLocation() {
/* 336 */       return "System Bundle";
/*     */     }
/*     */ 
/*     */     
/*     */     public ServiceReference<?>[] getRegisteredServices() {
/* 341 */       return null;
/*     */     }
/*     */ 
/*     */     
/*     */     public ServiceReference<?>[] getServicesInUse() {
/* 346 */       return null;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean hasPermission(Object permission) {
/* 351 */       return true;
/*     */     }
/*     */ 
/*     */     
/*     */     public URL getResource(String name) {
/* 356 */       return null;
/*     */     }
/*     */ 
/*     */     
/*     */     public Dictionary<String, String> getHeaders(String locale) {
/* 361 */       return null;
/*     */     }
/*     */ 
/*     */     
/*     */     public String getSymbolicName() {
/* 366 */       return "org.eclipse.osgi";
/*     */     }
/*     */ 
/*     */     
/*     */     public Class<?> loadClass(String name) throws ClassNotFoundException {
/* 371 */       throw new ClassNotFoundException();
/*     */     }
/*     */ 
/*     */     
/*     */     public Enumeration<URL> getResources(String name) {
/* 376 */       return null;
/*     */     }
/*     */ 
/*     */     
/*     */     public Enumeration<String> getEntryPaths(String path) {
/* 381 */       return null;
/*     */     }
/*     */ 
/*     */     
/*     */     public URL getEntry(String path) {
/* 386 */       return null;
/*     */     }
/*     */ 
/*     */     
/*     */     public long getLastModified() {
/* 391 */       return System.currentTimeMillis();
/*     */     }
/*     */ 
/*     */     
/*     */     public Enumeration<URL> findEntries(String path, String filePattern, boolean recurse) {
/* 396 */       return null;
/*     */     }
/*     */ 
/*     */     
/*     */     public BundleContext getBundleContext() {
/* 401 */       return null;
/*     */     }
/*     */ 
/*     */     
/*     */     public Map<X509Certificate, List<X509Certificate>> getSignerCertificates(int signersType) {
/* 406 */       return new HashMap<>();
/*     */     }
/*     */ 
/*     */     
/*     */     public Version getVersion() {
/* 411 */       return new Version(0, 0, 0);
/*     */     }
/*     */ 
/*     */     
/*     */     public <A> A adapt(Class<A> type) {
/* 416 */       return null;
/*     */     }
/*     */ 
/*     */     
/*     */     public File getDataFile(String filename) {
/* 421 */       return null;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.osgi-3.18.400.jar!\org\eclipse\osgi\internal\log\LogServiceManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */