/*     */ package org.eclipse.osgi.storage;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.net.MalformedURLException;
/*     */ import java.net.URL;
/*     */ import java.nio.file.CopyOption;
/*     */ import java.nio.file.FileVisitResult;
/*     */ import java.nio.file.Files;
/*     */ import java.nio.file.Path;
/*     */ import java.nio.file.SimpleFileVisitor;
/*     */ import java.nio.file.StandardCopyOption;
/*     */ import java.nio.file.attribute.BasicFileAttributes;
/*     */ import java.nio.file.attribute.FileAttribute;
/*     */ import java.util.Arrays;
/*     */ import java.util.Dictionary;
/*     */ import java.util.HashSet;
/*     */ import java.util.Hashtable;
/*     */ import java.util.Set;
/*     */ import org.eclipse.osgi.framework.internal.reliablefile.ReliableFile;
/*     */ import org.eclipse.osgi.internal.debug.Debug;
/*     */ import org.osgi.framework.BundleContext;
/*     */ import org.osgi.framework.ServiceRegistration;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class StorageUtil
/*     */ {
/*     */   public static void copy(File inFile, File outFile) throws IOException {
/*  55 */     Path source = inFile.toPath();
/*  56 */     Path target = outFile.toPath();
/*  57 */     if (Files.exists(source, new java.nio.file.LinkOption[0])) {
/*  58 */       Exception exception2; Files.createDirectories(target.getParent(), (FileAttribute<?>[])new FileAttribute[0]);
/*  59 */       Exception exception1 = null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void readFile(InputStream in, File file) throws IOException {
/*  76 */     Exception exception1 = null, exception2 = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean rm(File file, final boolean DEBUG) {
/*  88 */     Path path = file.toPath();
/*  89 */     if (!Files.exists(path, new java.nio.file.LinkOption[0])) {
/*  90 */       return true;
/*     */     }
/*     */     try {
/*  93 */       Files.walkFileTree(path, new SimpleFileVisitor<Path>()
/*     */           {
/*     */             public FileVisitResult visitFile(Path f, BasicFileAttributes attrs) {
/*  96 */               return delete(f, DEBUG);
/*     */             }
/*     */ 
/*     */             
/*     */             public FileVisitResult postVisitDirectory(Path dir, IOException exc) {
/* 101 */               return delete(dir, DEBUG);
/*     */             }
/*     */             
/*     */             private FileVisitResult delete(Path pathToDelete, boolean debug) {
/*     */               try {
/* 106 */                 if (debug) {
/* 107 */                   Debug.println("rm " + pathToDelete);
/*     */                 }
/* 109 */                 Files.delete(pathToDelete);
/* 110 */               } catch (IOException e) {
/* 111 */                 if (debug) {
/* 112 */                   Debug.println("  rm failed:" + e.getMessage());
/*     */                 }
/*     */               } 
/* 115 */               return FileVisitResult.CONTINUE;
/*     */             }
/*     */           });
/* 118 */       return !Files.exists(path, new java.nio.file.LinkOption[0]);
/* 119 */     } catch (IOException iOException) {
/* 120 */       return false;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ServiceRegistration<?> register(String name, Object service, BundleContext context) {
/* 132 */     Dictionary<String, Object> properties = new Hashtable<>();
/* 133 */     properties.put("service.ranking", Integer.valueOf(2147483647));
/* 134 */     properties.put("service.pid", String.valueOf(context.getBundle().getBundleId()) + "." + service.getClass().getName());
/* 135 */     return context.registerService(name, service, properties);
/*     */   }
/*     */   
/*     */   public static boolean canWrite(File installDir) {
/* 139 */     if (!installDir.isDirectory()) {
/* 140 */       return false;
/*     */     }
/* 142 */     if (Files.isWritable(installDir.toPath())) {
/* 143 */       return true;
/*     */     }
/* 145 */     File fileTest = null;
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/* 150 */       fileTest = ReliableFile.createTempFile("writableArea", ".dll", installDir);
/* 151 */     } catch (IOException iOException) {
/*     */ 
/*     */       
/* 154 */       return false;
/*     */     } finally {
/* 156 */       if (fileTest != null)
/* 157 */         fileTest.delete(); 
/*     */     } 
/* 159 */     return true;
/*     */   }
/*     */   
/*     */   public static URL encodeFileURL(File file) throws MalformedURLException {
/* 163 */     return file.toURI().toURL();
/*     */   }
/*     */   
/*     */   public static byte[] getBytes(InputStream in, int length, int BUF_SIZE) throws IOException {
/*     */     byte[] classbytes;
/* 168 */     int bytesread = 0;
/*     */     
/*     */     try {
/* 171 */       if (length > 0) {
/* 172 */         classbytes = new byte[length];
/* 173 */         for (; bytesread < length; bytesread += readcount) {
/* 174 */           int readcount = in.read(classbytes, bytesread, length - bytesread);
/* 175 */           if (readcount <= 0)
/*     */             break; 
/*     */         } 
/*     */       } else {
/* 179 */         length = BUF_SIZE;
/* 180 */         classbytes = new byte[length];
/*     */         while (true) {
/* 182 */           while (bytesread >= length)
/*     */           
/*     */           { 
/*     */ 
/*     */             
/* 187 */             byte[] oldbytes = classbytes;
/* 188 */             length += BUF_SIZE;
/* 189 */             classbytes = new byte[length];
/* 190 */             System.arraycopy(oldbytes, 0, classbytes, 0, bytesread); }  int readcount = in.read(classbytes, bytesread, length - bytesread); if (readcount <= 0)
/*     */             break;  bytesread += readcount;
/*     */         } 
/* 193 */       }  if (classbytes.length > bytesread) {
/* 194 */         byte[] oldbytes = classbytes;
/* 195 */         classbytes = new byte[bytesread];
/* 196 */         System.arraycopy(oldbytes, 0, classbytes, 0, bytesread);
/*     */       } 
/*     */     } finally {
/*     */       try {
/* 200 */         in.close();
/* 201 */       } catch (IOException iOException) {}
/*     */     } 
/*     */ 
/*     */     
/* 205 */     return classbytes;
/*     */   }
/*     */   
/*     */   public static void move(File from, File to, boolean DEBUG) throws IOException {
/*     */     try {
/* 210 */       Files.move(from.toPath(), to.toPath(), new CopyOption[] { StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE });
/* 211 */     } catch (IOException iOException) {
/* 212 */       if (DEBUG) {
/* 213 */         Debug.println("Failed to move atomically: " + from + " to " + to);
/*     */       }
/*     */ 
/*     */       
/* 217 */       rm(to, DEBUG);
/*     */       
/* 219 */       Files.move(from.toPath(), to.toPath(), new CopyOption[] { StandardCopyOption.REPLACE_EXISTING });
/*     */     } 
/* 221 */     if (DEBUG) {
/* 222 */       Debug.println("Successfully moved file: " + from + " to " + to);
/*     */     }
/*     */   }
/*     */   
/* 226 */   private static final boolean IS_WINDOWS = (File.separatorChar == '\\');
/*     */ 
/*     */ 
/*     */   
/* 230 */   private static final Set<String> RESERVED_NAMES = new HashSet<>(Arrays.asList(new String[] { "aux", "com1", "com2", "com3", "com4", 
/* 231 */           "com5", "com6", "com7", "com8", "com9", "con", "lpt1", "lpt2", 
/* 232 */           "lpt3", "lpt4", "lpt5", "lpt6", "lpt7", "lpt8", "lpt9", "nul", "prn" }));
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isReservedFileName(File file) {
/* 238 */     if (!IS_WINDOWS) {
/* 239 */       return false;
/*     */     }
/* 241 */     String fileName = file.getName();
/*     */ 
/*     */ 
/*     */     
/* 245 */     int dot = fileName.indexOf('.');
/*     */     
/* 247 */     String basename = (dot == -1) ? fileName : fileName.substring(0, dot);
/* 248 */     return RESERVED_NAMES.contains(basename.toLowerCase());
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.osgi-3.18.400.jar!\org\eclipse\osgi\storage\StorageUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */