/*      */ package org.eclipse.osgi.internal.framework;
/*      */ 
/*      */ import java.lang.reflect.AccessibleObject;
/*      */ import java.lang.reflect.Constructor;
/*      */ import java.lang.reflect.Method;
/*      */ import java.lang.reflect.Modifier;
/*      */ import java.security.AccessController;
/*      */ import java.util.AbstractMap;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Arrays;
/*      */ import java.util.Collection;
/*      */ import java.util.Collections;
/*      */ import java.util.Dictionary;
/*      */ import java.util.HashMap;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.Objects;
/*      */ import java.util.Set;
/*      */ import java.util.function.Function;
/*      */ import org.eclipse.osgi.framework.util.CaseInsensitiveDictionaryMap;
/*      */ import org.eclipse.osgi.internal.debug.Debug;
/*      */ import org.eclipse.osgi.internal.messages.Msg;
/*      */ import org.eclipse.osgi.internal.serviceregistry.ServiceReferenceImpl;
/*      */ import org.eclipse.osgi.util.NLS;
/*      */ import org.osgi.framework.Filter;
/*      */ import org.osgi.framework.InvalidSyntaxException;
/*      */ import org.osgi.framework.ServiceReference;
/*      */ import org.osgi.framework.Version;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public abstract class FilterImpl
/*      */   implements Filter
/*      */ {
/*      */   private transient String filterString;
/*      */   
/*      */   public static FilterImpl newInstance(String filterString) throws InvalidSyntaxException {
/*  177 */     return newInstance(filterString, false);
/*      */   }
/*      */   
/*      */   public static FilterImpl newInstance(String filterString, boolean debug) throws InvalidSyntaxException {
/*  181 */     return (new Parser(filterString, debug)).parse();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean match(ServiceReference<?> reference) {
/*  202 */     return matches0((reference != null) ? ServiceReferenceMap.asMap(reference) : Collections.emptyMap());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean match(Dictionary<String, ?> dictionary) {
/*  219 */     return matches0((dictionary != null) ? (Map<String, ?>)new CaseInsensitiveDictionaryMap(dictionary) : Collections.emptyMap());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean matchCase(Dictionary<String, ?> dictionary) {
/*  235 */     return matches0((dictionary != null) ? DictionaryMap.asMap(dictionary) : Collections.emptyMap());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean matches(Map<String, ?> map) {
/*  252 */     return matches0((map != null) ? map : Collections.emptyMap());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   abstract boolean matches0(Map<String, ?> paramMap);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String toString() {
/*  267 */     String result = this.filterString;
/*  268 */     if (result == null) {
/*  269 */       this.filterString = result = normalize(new StringBuilder()).toString();
/*      */     }
/*  271 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   abstract StringBuilder normalize(StringBuilder paramStringBuilder);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean equals(Object obj) {
/*  297 */     if (obj == this) {
/*  298 */       return true;
/*      */     }
/*      */     
/*  301 */     if (!(obj instanceof Filter)) {
/*  302 */       return false;
/*      */     }
/*      */     
/*  305 */     return toString().equals(obj.toString());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int hashCode() {
/*  318 */     return toString().hashCode();
/*      */   }
/*      */   
/*      */   static final class And extends FilterImpl {
/*      */     private final FilterImpl[] operands;
/*      */     
/*      */     And(FilterImpl[] operands) {
/*  325 */       this.operands = operands;
/*      */     } boolean matches0(Map<String, ?> map) {
/*      */       byte b;
/*      */       int i;
/*      */       FilterImpl[] arrayOfFilterImpl;
/*  330 */       for (i = (arrayOfFilterImpl = this.operands).length, b = 0; b < i; ) { FilterImpl operand = arrayOfFilterImpl[b];
/*  331 */         if (!operand.matches0(map))
/*  332 */           return false; 
/*      */         b++; }
/*      */       
/*  335 */       return true;
/*      */     }
/*      */ 
/*      */     
/*      */     StringBuilder normalize(StringBuilder sb) {
/*  340 */       sb.append('(').append('&'); byte b; int i; FilterImpl[] arrayOfFilterImpl;
/*  341 */       for (i = (arrayOfFilterImpl = this.operands).length, b = 0; b < i; ) { FilterImpl operand = arrayOfFilterImpl[b];
/*  342 */         operand.normalize(sb); b++; }
/*      */       
/*  344 */       return sb.append(')');
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public String getPrimaryKeyValue(String primaryKey) {
/*      */       byte b;
/*      */       int i;
/*      */       FilterImpl[] arrayOfFilterImpl;
/*  355 */       for (i = (arrayOfFilterImpl = this.operands).length, b = 0; b < i; ) { FilterImpl operand = arrayOfFilterImpl[b];
/*  356 */         if (operand instanceof FilterImpl.Equal) {
/*  357 */           String result = operand.getPrimaryKeyValue(primaryKey);
/*  358 */           if (result != null)
/*  359 */             return result; 
/*      */         } 
/*      */         b++; }
/*      */       
/*  363 */       return null;
/*      */     }
/*      */ 
/*      */     
/*      */     public List<FilterImpl> getChildren() {
/*  368 */       return new ArrayList<>(Arrays.asList(this.operands));
/*      */     }
/*      */     void getAttributesInternal(List<String> results) { byte b;
/*      */       int i;
/*      */       FilterImpl[] arrayOfFilterImpl;
/*  373 */       for (i = (arrayOfFilterImpl = this.operands).length, b = 0; b < i; ) { FilterImpl operand = arrayOfFilterImpl[b];
/*  374 */         operand.getAttributesInternal(results);
/*      */         b++; }
/*      */        } void addAttributes(Map<String, String> attributes, Map<String, FilterImpl.Range> versionAttrs, boolean not) {
/*      */       byte b;
/*      */       int i;
/*      */       FilterImpl[] arrayOfFilterImpl;
/*  380 */       for (i = (arrayOfFilterImpl = this.operands).length, b = 0; b < i; ) { FilterImpl operand = arrayOfFilterImpl[b];
/*  381 */         operand.addAttributes(attributes, versionAttrs, false);
/*      */         b++; }
/*      */     
/*      */     } }
/*      */   
/*      */   static final class Or extends FilterImpl {
/*      */     private final FilterImpl[] operands;
/*      */     
/*      */     Or(FilterImpl[] operands) {
/*  390 */       this.operands = operands;
/*      */     } boolean matches0(Map<String, ?> map) {
/*      */       byte b;
/*      */       int i;
/*      */       FilterImpl[] arrayOfFilterImpl;
/*  395 */       for (i = (arrayOfFilterImpl = this.operands).length, b = 0; b < i; ) { FilterImpl operand = arrayOfFilterImpl[b];
/*  396 */         if (operand.matches0(map))
/*  397 */           return true; 
/*      */         b++; }
/*      */       
/*  400 */       return false;
/*      */     }
/*      */ 
/*      */     
/*      */     StringBuilder normalize(StringBuilder sb) {
/*  405 */       sb.append('(').append('|'); byte b; int i; FilterImpl[] arrayOfFilterImpl;
/*  406 */       for (i = (arrayOfFilterImpl = this.operands).length, b = 0; b < i; ) { FilterImpl operand = arrayOfFilterImpl[b];
/*  407 */         operand.normalize(sb); b++; }
/*      */       
/*  409 */       return sb.append(')');
/*      */     }
/*      */ 
/*      */     
/*      */     public List<FilterImpl> getChildren() {
/*  414 */       return new ArrayList<>(Arrays.asList(this.operands));
/*      */     } void getAttributesInternal(List<String> results) {
/*      */       byte b;
/*      */       int i;
/*      */       FilterImpl[] arrayOfFilterImpl;
/*  419 */       for (i = (arrayOfFilterImpl = this.operands).length, b = 0; b < i; ) { FilterImpl operand = arrayOfFilterImpl[b];
/*  420 */         operand.getAttributesInternal(results);
/*      */         b++; }
/*      */     
/*      */     }
/*      */     
/*      */     public Map<String, String> getStandardOSGiAttributes(String... versions) {
/*  426 */       throw new IllegalArgumentException("Invalid filter for standard OSGi Attributes: OR");
/*      */     }
/*      */ 
/*      */     
/*      */     void addAttributes(Map<String, String> attributes, Map<String, FilterImpl.Range> versionAttrs, boolean not) {
/*  431 */       throw new IllegalStateException("Invalid filter for standard OSGi requirements: OR");
/*      */     }
/*      */   }
/*      */   
/*      */   static final class Not extends FilterImpl {
/*      */     private final FilterImpl operand;
/*      */     
/*      */     Not(FilterImpl operand) {
/*  439 */       this.operand = operand;
/*      */     }
/*      */ 
/*      */     
/*      */     boolean matches0(Map<String, ?> map) {
/*  444 */       return !this.operand.matches0(map);
/*      */     }
/*      */ 
/*      */     
/*      */     StringBuilder normalize(StringBuilder sb) {
/*  449 */       sb.append('(').append('!');
/*  450 */       this.operand.normalize(sb);
/*  451 */       return sb.append(')');
/*      */     }
/*      */ 
/*      */     
/*      */     void getAttributesInternal(List<String> results) {
/*  456 */       this.operand.getAttributesInternal(results);
/*      */     }
/*      */ 
/*      */     
/*      */     public Map<String, String> getStandardOSGiAttributes(String... versions) {
/*  461 */       throw new IllegalArgumentException("Invalid filter for standard OSGi Attributes: NOT");
/*      */     }
/*      */ 
/*      */     
/*      */     void addAttributes(Map<String, String> attributes, Map<String, FilterImpl.Range> versionAttrs, boolean not) {
/*  466 */       this.operand.addAttributes(attributes, versionAttrs, true);
/*      */     }
/*      */   }
/*      */   
/*      */   static abstract class Item
/*      */     extends FilterImpl {
/*      */     final boolean debug;
/*      */     final String attr;
/*      */     
/*      */     Item(String attr, boolean debug) {
/*  476 */       this.attr = attr;
/*  477 */       this.debug = debug;
/*      */     }
/*      */ 
/*      */     
/*      */     boolean matches0(Map<String, ?> map) {
/*  482 */       return compare(map.get(this.attr));
/*      */     }
/*      */     
/*      */     abstract String operation();
/*      */     
/*      */     abstract String value();
/*      */     
/*      */     private boolean compare(Object value1) {
/*  490 */       if (this.debug) {
/*  491 */         if (value1 == null) {
/*  492 */           Debug.println("compare(" + value1 + "," + value() + ")");
/*  493 */         } else if (!value1.getClass().isArray() && !(value1 instanceof Collection)) {
/*  494 */           Debug.println(String.valueOf(operation()) + "(" + value1 + "," + value() + ")");
/*      */         } 
/*      */       }
/*  497 */       if (value1 == null) {
/*  498 */         return false;
/*      */       }
/*  500 */       if (value1 instanceof String) {
/*  501 */         return compare_String((String)value1);
/*      */       }
/*  503 */       if (value1 instanceof Version) {
/*  504 */         return compare_Version((Version)value1);
/*      */       }
/*      */       
/*  507 */       Class<?> clazz = value1.getClass();
/*  508 */       if (clazz.isArray()) {
/*  509 */         Class<?> type = clazz.getComponentType();
/*  510 */         if (type.isPrimitive()) {
/*  511 */           return compare_PrimitiveArray(type, value1);
/*      */         }
/*  513 */         return compare_ObjectArray((Object[])value1);
/*      */       } 
/*  515 */       if (value1 instanceof Collection) {
/*  516 */         return compare_Collection((Collection)value1);
/*      */       }
/*  518 */       if (value1 instanceof Integer || value1 instanceof Long || value1 instanceof Byte || 
/*  519 */         value1 instanceof Short) {
/*  520 */         return compare_Long(((Number)value1).longValue());
/*      */       }
/*  522 */       if (value1 instanceof Character) {
/*  523 */         return compare_Character(((Character)value1).charValue());
/*      */       }
/*  525 */       if (value1 instanceof Float) {
/*  526 */         return compare_Float(((Float)value1).floatValue());
/*      */       }
/*  528 */       if (value1 instanceof Double) {
/*  529 */         return compare_Double(((Double)value1).doubleValue());
/*      */       }
/*  531 */       if (value1 instanceof Boolean) {
/*  532 */         return compare_Boolean(((Boolean)value1).booleanValue());
/*      */       }
/*  534 */       if (value1 instanceof Comparable) {
/*      */         
/*  536 */         Comparable<Object> comparable = (Comparable<Object>)value1;
/*  537 */         return compare_Comparable(comparable);
/*      */       } 
/*  539 */       return compare_Unknown(value1);
/*      */     }
/*      */     
/*      */     private boolean compare_Collection(Collection<?> collection) {
/*  543 */       for (Object value1 : collection) {
/*  544 */         if (compare(value1)) {
/*  545 */           return true;
/*      */         }
/*      */       } 
/*  548 */       return false; } private boolean compare_ObjectArray(Object[] array) {
/*      */       byte b;
/*      */       int i;
/*      */       Object[] arrayOfObject;
/*  552 */       for (i = (arrayOfObject = array).length, b = 0; b < i; ) { Object value1 = arrayOfObject[b];
/*  553 */         if (compare(value1))
/*  554 */           return true; 
/*      */         b++; }
/*      */       
/*  557 */       return false;
/*      */     }
/*      */     
/*      */     private boolean compare_PrimitiveArray(Class<?> type, Object primarray) {
/*  561 */       if (int.class.isAssignableFrom(type)) {
/*  562 */         int[] array = (int[])primarray; byte b; int i, arrayOfInt1[];
/*  563 */         for (i = (arrayOfInt1 = array).length, b = 0; b < i; ) { int value1 = arrayOfInt1[b];
/*  564 */           if (this.debug) {
/*  565 */             Debug.println(String.valueOf(operation()) + "(" + value1 + "," + value() + ")");
/*      */           }
/*  567 */           if (compare_Long(value1))
/*  568 */             return true; 
/*      */           b++; }
/*      */         
/*  571 */         return false;
/*      */       } 
/*  573 */       if (long.class.isAssignableFrom(type)) {
/*  574 */         long[] array = (long[])primarray; byte b; int i; long[] arrayOfLong1;
/*  575 */         for (i = (arrayOfLong1 = array).length, b = 0; b < i; ) { long value1 = arrayOfLong1[b];
/*  576 */           if (this.debug) {
/*  577 */             Debug.println(String.valueOf(operation()) + "(" + value1 + "," + value() + ")");
/*      */           }
/*  579 */           if (compare_Long(value1))
/*  580 */             return true; 
/*      */           b++; }
/*      */         
/*  583 */         return false;
/*      */       } 
/*  585 */       if (byte.class.isAssignableFrom(type)) {
/*  586 */         byte[] array = (byte[])primarray; byte b; int i; byte[] arrayOfByte1;
/*  587 */         for (i = (arrayOfByte1 = array).length, b = 0; b < i; ) { byte value1 = arrayOfByte1[b];
/*  588 */           if (this.debug) {
/*  589 */             Debug.println(String.valueOf(operation()) + "(" + value1 + "," + value() + ")");
/*      */           }
/*  591 */           if (compare_Long(value1))
/*  592 */             return true; 
/*      */           b++; }
/*      */         
/*  595 */         return false;
/*      */       } 
/*  597 */       if (short.class.isAssignableFrom(type)) {
/*  598 */         short[] array = (short[])primarray; byte b; int i; short[] arrayOfShort1;
/*  599 */         for (i = (arrayOfShort1 = array).length, b = 0; b < i; ) { short value1 = arrayOfShort1[b];
/*  600 */           if (this.debug) {
/*  601 */             Debug.println(String.valueOf(operation()) + "(" + value1 + "," + value() + ")");
/*      */           }
/*  603 */           if (compare_Long(value1))
/*  604 */             return true; 
/*      */           b++; }
/*      */         
/*  607 */         return false;
/*      */       } 
/*  609 */       if (char.class.isAssignableFrom(type)) {
/*  610 */         char[] array = (char[])primarray; byte b; int i; char[] arrayOfChar1;
/*  611 */         for (i = (arrayOfChar1 = array).length, b = 0; b < i; ) { char value1 = arrayOfChar1[b];
/*  612 */           if (this.debug) {
/*  613 */             Debug.println(String.valueOf(operation()) + "(" + value1 + "," + value() + ")");
/*      */           }
/*  615 */           if (compare_Character(value1))
/*  616 */             return true; 
/*      */           b++; }
/*      */         
/*  619 */         return false;
/*      */       } 
/*  621 */       if (float.class.isAssignableFrom(type)) {
/*  622 */         float[] array = (float[])primarray; byte b; int i; float[] arrayOfFloat1;
/*  623 */         for (i = (arrayOfFloat1 = array).length, b = 0; b < i; ) { float value1 = arrayOfFloat1[b];
/*  624 */           if (this.debug) {
/*  625 */             Debug.println(String.valueOf(operation()) + "(" + value1 + "," + value() + ")");
/*      */           }
/*  627 */           if (compare_Float(value1))
/*  628 */             return true; 
/*      */           b++; }
/*      */         
/*  631 */         return false;
/*      */       } 
/*  633 */       if (double.class.isAssignableFrom(type)) {
/*  634 */         double[] array = (double[])primarray; byte b; int i; double[] arrayOfDouble1;
/*  635 */         for (i = (arrayOfDouble1 = array).length, b = 0; b < i; ) { double value1 = arrayOfDouble1[b];
/*  636 */           if (this.debug) {
/*  637 */             Debug.println(String.valueOf(operation()) + "(" + value1 + "," + value() + ")");
/*      */           }
/*  639 */           if (compare_Double(value1))
/*  640 */             return true; 
/*      */           b++; }
/*      */         
/*  643 */         return false;
/*      */       } 
/*  645 */       if (boolean.class.isAssignableFrom(type)) {
/*  646 */         boolean[] array = (boolean[])primarray; byte b; int i; boolean[] arrayOfBoolean1;
/*  647 */         for (i = (arrayOfBoolean1 = array).length, b = 0; b < i; ) { boolean value1 = arrayOfBoolean1[b];
/*  648 */           if (this.debug) {
/*  649 */             Debug.println(String.valueOf(operation()) + "(" + value1 + "," + value() + ")");
/*      */           }
/*  651 */           if (compare_Boolean(value1))
/*  652 */             return true; 
/*      */           b++; }
/*      */         
/*  655 */         return false;
/*      */       } 
/*  657 */       return false;
/*      */     }
/*      */     
/*      */     boolean compare_String(String string) {
/*  661 */       return false;
/*      */     }
/*      */     
/*      */     boolean compare_Version(Version value1) {
/*  665 */       return false;
/*      */     }
/*      */     
/*      */     boolean compare_Comparable(Comparable<Object> value1) {
/*  669 */       return false;
/*      */     }
/*      */     
/*      */     boolean compare_Unknown(Object value1) {
/*  673 */       return false;
/*      */     }
/*      */     
/*      */     boolean compare_Boolean(boolean boolval) {
/*  677 */       return false;
/*      */     }
/*      */     
/*      */     boolean compare_Character(char charval) {
/*  681 */       return false;
/*      */     }
/*      */     
/*      */     boolean compare_Double(double doubleval) {
/*  685 */       return false;
/*      */     }
/*      */     
/*      */     boolean compare_Float(float floatval) {
/*  689 */       return false;
/*      */     }
/*      */     
/*      */     boolean compare_Long(long longval) {
/*  693 */       return false;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     static StringBuilder encodeValue(StringBuilder sb, String value) {
/*  702 */       for (int i = 0, len = value.length(); i < len; i++) {
/*  703 */         char c = value.charAt(i);
/*  704 */         switch (c) {
/*      */           case '(':
/*      */           case ')':
/*      */           case '*':
/*      */           case '\\':
/*  709 */             sb.append('\\');
/*      */             break;
/*      */         } 
/*  712 */         sb.append(c);
/*      */       } 
/*      */ 
/*      */       
/*  716 */       return sb;
/*      */     }
/*      */ 
/*      */     
/*      */     void getAttributesInternal(List<String> results) {
/*  721 */       results.add(this.attr);
/*      */     }
/*      */ 
/*      */     
/*      */     void addAttributes(Map<String, String> attributes, Map<String, FilterImpl.Range> versionAttrs, boolean not) {
/*  726 */       attributes.put(this.attr, value());
/*      */     }
/*      */   }
/*      */   
/*      */   static final class Present extends Item {
/*      */     Present(String attr, boolean debug) {
/*  732 */       super(attr, debug);
/*      */     }
/*      */ 
/*      */     
/*      */     boolean matches0(Map<String, ?> map) {
/*  737 */       if (this.debug) {
/*  738 */         Debug.println("PRESENT(" + this.attr + ")");
/*      */       }
/*  740 */       return (map.get(this.attr) != null);
/*      */     }
/*      */ 
/*      */     
/*      */     String operation() {
/*  745 */       return "PRESENT";
/*      */     }
/*      */ 
/*      */     
/*      */     String value() {
/*  750 */       return "*";
/*      */     }
/*      */ 
/*      */     
/*      */     StringBuilder normalize(StringBuilder sb) {
/*  755 */       return sb.append('(').append(this.attr).append('=').append('*').append(')');
/*      */     }
/*      */   }
/*      */   
/*      */   static final class Substring extends Item {
/*      */     final String[] substrings;
/*      */     
/*      */     Substring(String attr, String[] substrings, boolean debug) {
/*  763 */       super(attr, debug);
/*  764 */       this.substrings = substrings;
/*      */     }
/*      */ 
/*      */     
/*      */     String operation() {
/*  769 */       return "SUBSTRING";
/*      */     }
/*      */ 
/*      */     
/*      */     String value() {
/*  774 */       return value(new StringBuilder()).toString();
/*      */     }
/*      */ 
/*      */     
/*      */     boolean compare_String(String string) {
/*  779 */       int pos = 0;
/*  780 */       for (int i = 0, size = this.substrings.length; i < size; i++) {
/*  781 */         String substr = this.substrings[i];
/*  782 */         if (i + 1 < size) {
/*  783 */           if (substr == null)
/*  784 */           { String substr2 = this.substrings[i + 1];
/*  785 */             if (substr2 != null) {
/*      */ 
/*      */               
/*  788 */               if (this.debug) {
/*  789 */                 Debug.println("indexOf(\"" + substr2 + "\"," + pos + ")");
/*      */               }
/*  791 */               int index = string.indexOf(substr2, pos);
/*  792 */               if (index == -1) {
/*  793 */                 return false;
/*      */               }
/*  795 */               pos = index + substr2.length();
/*  796 */               if (i + 2 < size)
/*      */               {
/*      */ 
/*      */ 
/*      */ 
/*      */                 
/*  802 */                 i++; } 
/*      */             }  }
/*  804 */           else { int len = substr.length();
/*  805 */             if (this.debug) {
/*  806 */               Debug.println("regionMatches(" + pos + ",\"" + substr + "\")");
/*      */             }
/*  808 */             if (string.regionMatches(pos, substr, 0, len)) {
/*  809 */               pos += len;
/*      */             } else {
/*  811 */               return false;
/*      */             }  }
/*      */         
/*      */         } else {
/*  815 */           if (substr == null) {
/*  816 */             return true;
/*      */           }
/*      */           
/*  819 */           if (this.debug) {
/*  820 */             Debug.println("regionMatches(" + pos + "," + substr + ")");
/*      */           }
/*  822 */           return string.endsWith(substr);
/*      */         } 
/*      */       } 
/*  825 */       return true;
/*      */     }
/*      */     
/*      */     StringBuilder normalize(StringBuilder sb)
/*      */     {
/*  830 */       sb.append('(').append(this.attr).append('=');
/*  831 */       return value(sb).append(')'); } private StringBuilder value(StringBuilder sb) {
/*      */       byte b;
/*      */       int i;
/*      */       String[] arrayOfString;
/*  835 */       for (i = (arrayOfString = this.substrings).length, b = 0; b < i; ) { String substr = arrayOfString[b];
/*  836 */         if (substr == null) {
/*  837 */           sb.append('*');
/*      */         } else {
/*  839 */           encodeValue(sb, substr);
/*      */         }  b++; }
/*      */       
/*  842 */       return sb;
/*      */     }
/*      */   }
/*      */   
/*      */   static class Equal extends Item {
/*      */     final String value;
/*      */     private Object cached;
/*      */     
/*      */     Equal(String attr, String value, boolean debug) {
/*  851 */       super(attr, debug);
/*  852 */       this.value = value;
/*      */     }
/*      */ 
/*      */     
/*      */     private <T> T convert(Class<T> type, Function<String, ? extends T> converter) {
/*  857 */       T converted = (T)this.cached;
/*  858 */       if (converted != null && type.isInstance(converted)) {
/*  859 */         return converted;
/*      */       }
/*  861 */       this.cached = converted = (T)converter.apply(this.value.trim());
/*  862 */       return converted;
/*      */     }
/*      */ 
/*      */     
/*      */     String operation() {
/*  867 */       return "EQUAL";
/*      */     }
/*      */ 
/*      */     
/*      */     String value() {
/*  872 */       return this.value;
/*      */     }
/*      */     
/*      */     boolean comparison(int compare) {
/*  876 */       return (compare == 0);
/*      */     }
/*      */ 
/*      */     
/*      */     boolean compare_String(String string) {
/*  881 */       return comparison((string == this.value) ? 0 : string.compareTo(this.value));
/*      */     }
/*      */ 
/*      */     
/*      */     boolean compare_Version(Version value1) {
/*      */       try {
/*  887 */         Version version2 = convert(Version.class, Version::valueOf);
/*  888 */         return comparison(value1.compareTo(version2));
/*  889 */       } catch (Exception exception) {
/*      */         
/*  891 */         return false;
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     boolean compare_Boolean(boolean boolval) {
/*  897 */       boolean boolval2 = ((Boolean)convert(Boolean.class, Boolean::valueOf)).booleanValue();
/*  898 */       return comparison(Boolean.compare(boolval, boolval2));
/*      */     }
/*      */ 
/*      */     
/*      */     boolean compare_Character(char charval) {
/*      */       char charval2;
/*      */       try {
/*  905 */         charval2 = this.value.charAt(0);
/*  906 */       } catch (IndexOutOfBoundsException indexOutOfBoundsException) {
/*  907 */         return false;
/*      */       } 
/*  909 */       return comparison(Character.compare(charval, charval2));
/*      */     }
/*      */ 
/*      */     
/*      */     boolean compare_Double(double doubleval) {
/*      */       double doubleval2;
/*      */       try {
/*  916 */         doubleval2 = ((Double)convert(Double.class, Double::valueOf)).doubleValue();
/*  917 */       } catch (IllegalArgumentException illegalArgumentException) {
/*  918 */         return false;
/*      */       } 
/*  920 */       return comparison(Double.compare(doubleval, doubleval2));
/*      */     }
/*      */ 
/*      */     
/*      */     boolean compare_Float(float floatval) {
/*      */       float floatval2;
/*      */       try {
/*  927 */         floatval2 = ((Float)convert(Float.class, Float::valueOf)).floatValue();
/*  928 */       } catch (IllegalArgumentException illegalArgumentException) {
/*  929 */         return false;
/*      */       } 
/*  931 */       return comparison(Float.compare(floatval, floatval2));
/*      */     }
/*      */ 
/*      */     
/*      */     boolean compare_Long(long longval) {
/*      */       long longval2;
/*      */       try {
/*  938 */         longval2 = ((Long)convert(Long.class, Long::valueOf)).longValue();
/*  939 */       } catch (IllegalArgumentException illegalArgumentException) {
/*  940 */         return false;
/*      */       } 
/*  942 */       return comparison(Long.compare(longval, longval2));
/*      */     }
/*      */ 
/*      */     
/*      */     boolean compare_Comparable(Comparable<Object> value1) {
/*  947 */       Object value2 = valueOf(value1.getClass());
/*  948 */       if (value2 == null) {
/*  949 */         return false;
/*      */       }
/*      */       try {
/*  952 */         return comparison(value1.compareTo(value2));
/*  953 */       } catch (Exception exception) {
/*      */         
/*  955 */         return false;
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     boolean compare_Unknown(Object value1) {
/*  961 */       Object value2 = valueOf(value1.getClass());
/*  962 */       if (value2 == null) {
/*  963 */         return false;
/*      */       }
/*      */       try {
/*  966 */         return value1.equals(value2);
/*  967 */       } catch (Exception exception) {
/*      */         
/*  969 */         return false;
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     StringBuilder normalize(StringBuilder sb) {
/*  975 */       sb.append('(').append(this.attr).append('=');
/*  976 */       return encodeValue(sb, this.value).append(')');
/*      */     }
/*      */     
/*      */     Object valueOf(Class<?> target) {
/*      */       Method method;
/*      */       Constructor<?> constructor;
/*      */       try {
/*  983 */         method = target.getMethod("valueOf", new Class[] { String.class });
/*  984 */       } catch (NoSuchMethodException noSuchMethodException) {}
/*      */ 
/*      */       
/*  987 */       if (Modifier.isStatic(method.getModifiers()) && target.isAssignableFrom(method.getReturnType())) {
/*  988 */         setAccessible(method);
/*      */         try {
/*  990 */           return method.invoke(null, new Object[] { this.value.trim() });
/*  991 */         } catch (Error e) {
/*  992 */           throw e;
/*  993 */         } catch (Throwable throwable) {
/*  994 */           return null;
/*      */         } 
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       try {
/* 1002 */         constructor = target.getConstructor(new Class[] { String.class });
/* 1003 */       } catch (NoSuchMethodException noSuchMethodException) {}
/*      */ 
/*      */       
/* 1006 */       setAccessible(constructor);
/*      */       try {
/* 1008 */         return constructor.newInstance(new Object[] { this.value.trim() });
/* 1009 */       } catch (Error e) {
/* 1010 */         throw e;
/* 1011 */       } catch (Throwable throwable) {
/* 1012 */         return null;
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private static void setAccessible(AccessibleObject accessible) {
/* 1020 */       if (!accessible.isAccessible()) {
/* 1021 */         AccessController.doPrivileged(() -> {
/*      */               param1AccessibleObject.setAccessible(true);
/*      */               return null;
/*      */             });
/*      */       }
/*      */     }
/*      */ 
/*      */     
/*      */     public String getPrimaryKeyValue(String primaryKey) {
/* 1030 */       if (this.attr.equalsIgnoreCase(primaryKey)) {
/* 1031 */         return this.value;
/*      */       }
/* 1033 */       return null;
/*      */     }
/*      */ 
/*      */     
/*      */     void addAttributes(Map<String, String> attributes, Map<String, FilterImpl.Range> versionAttrs, boolean not) {
/* 1038 */       if (!versionAttrs.containsKey(this.attr)) {
/* 1039 */         attributes.put(this.attr, this.value);
/*      */       } else {
/*      */         
/* 1042 */         FilterImpl.Range currentRange = versionAttrs.get(this.attr);
/* 1043 */         if (currentRange != null) {
/* 1044 */           if (not) {
/*      */ 
/*      */             
/* 1047 */             currentRange.addExclude(Version.valueOf(this.value));
/*      */           } else {
/* 1049 */             throw new IllegalStateException("Invalid range for: " + this.attr);
/*      */           } 
/*      */         } else {
/* 1052 */           currentRange = new FilterImpl.Range();
/* 1053 */           Version version = Version.valueOf(this.value);
/* 1054 */           currentRange.setLeft('[', version);
/* 1055 */           currentRange.setRight(']', version);
/* 1056 */           versionAttrs.put(this.attr, currentRange);
/*      */         } 
/*      */       } 
/*      */     }
/*      */   }
/*      */   
/*      */   static final class LessEqual extends Equal {
/*      */     LessEqual(String attr, String value, boolean debug) {
/* 1064 */       super(attr, value, debug);
/*      */     }
/*      */ 
/*      */     
/*      */     String operation() {
/* 1069 */       return "LESS";
/*      */     }
/*      */ 
/*      */     
/*      */     boolean comparison(int compare) {
/* 1074 */       return (compare <= 0);
/*      */     }
/*      */ 
/*      */     
/*      */     StringBuilder normalize(StringBuilder sb) {
/* 1079 */       sb.append('(').append(this.attr).append('<').append('=');
/* 1080 */       return encodeValue(sb, this.value).append(')');
/*      */     }
/*      */ 
/*      */     
/*      */     public String getPrimaryKeyValue(String primaryKey) {
/* 1085 */       return null;
/*      */     }
/*      */ 
/*      */     
/*      */     public Map<String, String> getStandardOSGiAttributes(String... versions) {
/* 1090 */       throw new IllegalArgumentException("Invalid filter for standard OSGi Attributes: " + operation());
/*      */     }
/*      */ 
/*      */     
/*      */     void addAttributes(Map<String, String> attributes, Map<String, FilterImpl.Range> versionAttrs, boolean not) {
/* 1095 */       if (!versionAttrs.containsKey(this.attr)) {
/* 1096 */         throw new IllegalStateException("Invalid attribute: " + this.attr);
/*      */       }
/* 1098 */       FilterImpl.Range currentRange = versionAttrs.get(this.attr);
/* 1099 */       if (currentRange == null) {
/* 1100 */         currentRange = new FilterImpl.Range();
/* 1101 */         versionAttrs.put(this.attr, currentRange);
/*      */       } 
/* 1103 */       if (not) {
/*      */         
/* 1105 */         if (!currentRange.setLeft('(', Version.valueOf(this.value))) {
/* 1106 */           throw new IllegalStateException("range start is already processed for attribute: " + this.attr);
/*      */         
/*      */         }
/*      */       }
/* 1110 */       else if (!currentRange.setRight(']', Version.valueOf(this.value))) {
/* 1111 */         throw new IllegalStateException("range end is already processed for attribute: " + this.attr);
/*      */       } 
/*      */     }
/*      */   }
/*      */   
/*      */   static final class GreaterEqual
/*      */     extends Equal {
/*      */     GreaterEqual(String attr, String value, boolean debug) {
/* 1119 */       super(attr, value, debug);
/*      */     }
/*      */ 
/*      */     
/*      */     String operation() {
/* 1124 */       return "GREATER";
/*      */     }
/*      */ 
/*      */     
/*      */     boolean comparison(int compare) {
/* 1129 */       return (compare >= 0);
/*      */     }
/*      */ 
/*      */     
/*      */     StringBuilder normalize(StringBuilder sb) {
/* 1134 */       sb.append('(').append(this.attr).append('>').append('=');
/* 1135 */       return encodeValue(sb, this.value).append(')');
/*      */     }
/*      */ 
/*      */     
/*      */     public String getPrimaryKeyValue(String primaryKey) {
/* 1140 */       return null;
/*      */     }
/*      */ 
/*      */     
/*      */     public Map<String, String> getStandardOSGiAttributes(String... versions) {
/* 1145 */       throw new IllegalArgumentException("Invalid filter for standard OSGi Attributes: " + operation());
/*      */     }
/*      */ 
/*      */     
/*      */     void addAttributes(Map<String, String> attributes, Map<String, FilterImpl.Range> versionAttrs, boolean not) {
/* 1150 */       if (!versionAttrs.containsKey(this.attr)) {
/* 1151 */         throw new IllegalStateException("Invalid attribute: " + this.attr);
/*      */       }
/* 1153 */       FilterImpl.Range currentRange = versionAttrs.get(this.attr);
/* 1154 */       if (currentRange == null) {
/* 1155 */         currentRange = new FilterImpl.Range();
/* 1156 */         versionAttrs.put(this.attr, currentRange);
/*      */       } 
/* 1158 */       if (not) {
/*      */         
/* 1160 */         if (!currentRange.setRight(')', Version.valueOf(this.value))) {
/* 1161 */           throw new IllegalStateException("range end is already processed for attribute: " + this.attr);
/*      */         
/*      */         }
/*      */       }
/* 1165 */       else if (!currentRange.setLeft('[', Version.valueOf(this.value))) {
/* 1166 */         throw new IllegalStateException("range start is already processed for attribute: " + this.attr);
/*      */       } 
/*      */     }
/*      */   }
/*      */   
/*      */   static final class Approx
/*      */     extends Equal {
/*      */     final String approx;
/*      */     
/*      */     Approx(String attr, String value, boolean debug) {
/* 1176 */       super(attr, value, debug);
/* 1177 */       this.approx = approxString(value);
/*      */     }
/*      */ 
/*      */     
/*      */     String operation() {
/* 1182 */       return "APPROX";
/*      */     }
/*      */ 
/*      */     
/*      */     String value() {
/* 1187 */       return this.approx;
/*      */     }
/*      */ 
/*      */     
/*      */     boolean compare_String(String string) {
/* 1192 */       string = approxString(string);
/* 1193 */       return string.equalsIgnoreCase(this.approx);
/*      */     }
/*      */ 
/*      */     
/*      */     boolean compare_Character(char charval) {
/*      */       char charval2;
/*      */       try {
/* 1200 */         charval2 = this.approx.charAt(0);
/* 1201 */       } catch (IndexOutOfBoundsException indexOutOfBoundsException) {
/* 1202 */         return false;
/*      */       } 
/* 1204 */       return !(charval != charval2 && Character.toUpperCase(charval) != Character.toUpperCase(charval2) && Character.toLowerCase(charval) != Character.toLowerCase(charval2));
/*      */     }
/*      */ 
/*      */     
/*      */     StringBuilder normalize(StringBuilder sb) {
/* 1209 */       sb.append('(').append(this.attr).append('~').append('=');
/* 1210 */       return encodeValue(sb, this.approx).append(')');
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     static String approxString(String input) {
/* 1222 */       boolean changed = false;
/* 1223 */       char[] output = input.toCharArray();
/* 1224 */       int cursor = 0; byte b; int i; char[] arrayOfChar1;
/* 1225 */       for (i = (arrayOfChar1 = output).length, b = 0; b < i; ) { char c = arrayOfChar1[b];
/* 1226 */         if (Character.isWhitespace(c)) {
/* 1227 */           changed = true;
/*      */         }
/*      */         else {
/*      */           
/* 1231 */           output[cursor] = c;
/* 1232 */           cursor++;
/*      */         }  b++; }
/*      */       
/* 1235 */       return changed ? new String(output, 0, cursor) : input;
/*      */     }
/*      */ 
/*      */     
/*      */     public String getPrimaryKeyValue(String primaryKey) {
/* 1240 */       return null;
/*      */     }
/*      */ 
/*      */     
/*      */     public Map<String, String> getStandardOSGiAttributes(String... versions) {
/* 1245 */       throw new IllegalArgumentException("Invalid filter for standard OSGi Attributes: " + operation());
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getRequiredObjectClass() {
/* 1255 */     return getPrimaryKeyValue("objectClass");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getPrimaryKeyValue(String primaryKey) {
/* 1271 */     return null;
/*      */   }
/*      */   
/*      */   public List<FilterImpl> getChildren() {
/* 1275 */     return Collections.emptyList();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String[] getAttributes() {
/* 1283 */     List<String> results = new ArrayList<>();
/* 1284 */     getAttributesInternal(results);
/* 1285 */     return results.<String>toArray(new String[0]);
/*      */   }
/*      */   
/*      */   abstract void getAttributesInternal(List<String> paramList);
/*      */   
/*      */   public Map<String, String> getStandardOSGiAttributes(String... versions) {
/* 1291 */     Map<String, String> result = new HashMap<>();
/* 1292 */     Map<String, Range> versionAttrs = new HashMap<>();
/* 1293 */     if (versions != null) {
/* 1294 */       byte b; int i; String[] arrayOfString; for (i = (arrayOfString = versions).length, b = 0; b < i; ) { String versionAttr = arrayOfString[b];
/* 1295 */         versionAttrs.put(versionAttr, null); b++; }
/*      */     
/*      */     } 
/* 1298 */     addAttributes(result, versionAttrs, false);
/* 1299 */     for (Map.Entry<String, Range> entry : versionAttrs.entrySet()) {
/* 1300 */       Range range = entry.getValue();
/* 1301 */       if (range != null) {
/* 1302 */         result.put(entry.getKey(), range.toString());
/*      */       }
/*      */     } 
/*      */     
/* 1306 */     return result;
/*      */   }
/*      */ 
/*      */   
/*      */   abstract void addAttributes(Map<String, String> paramMap, Map<String, Range> paramMap1, boolean paramBoolean);
/*      */ 
/*      */   
/*      */   private static final class Parser
/*      */   {
/*      */     private final boolean debug;
/*      */     
/*      */     private final String filterstring;
/*      */     
/*      */     private final char[] filterChars;
/*      */     private int pos;
/*      */     
/*      */     Parser(String filterstring, boolean debug) {
/* 1323 */       this.debug = debug;
/* 1324 */       this.filterstring = filterstring;
/* 1325 */       this.filterChars = filterstring.toCharArray();
/* 1326 */       this.pos = 0;
/*      */     }
/*      */     
/*      */     FilterImpl parse() throws InvalidSyntaxException {
/*      */       FilterImpl filter;
/*      */       try {
/* 1332 */         filter = parse_filter();
/* 1333 */       } catch (ArrayIndexOutOfBoundsException e) {
/* 1334 */         throw new InvalidSyntaxException(Msg.FILTER_TERMINATED_ABRUBTLY, this.filterstring, e);
/*      */       } 
/*      */       
/* 1337 */       if (this.pos != this.filterChars.length) {
/* 1338 */         throw new InvalidSyntaxException(NLS.bind(Msg.FILTER_TRAILING_CHARACTERS, this.filterstring.substring(this.pos)), this.filterstring);
/*      */       }
/* 1340 */       return filter;
/*      */     }
/*      */ 
/*      */     
/*      */     private FilterImpl parse_filter() throws InvalidSyntaxException {
/* 1345 */       skipWhiteSpace();
/*      */       
/* 1347 */       if (this.filterChars[this.pos] != '(') {
/* 1348 */         throw new InvalidSyntaxException(NLS.bind(Msg.FILTER_MISSING_LEFTPAREN, this.filterstring.substring(this.pos)), this.filterstring);
/*      */       }
/*      */       
/* 1351 */       this.pos++;
/*      */       
/* 1353 */       FilterImpl filter = parse_filtercomp();
/*      */       
/* 1355 */       skipWhiteSpace();
/*      */       
/* 1357 */       if (this.filterChars[this.pos] != ')') {
/* 1358 */         throw new InvalidSyntaxException(NLS.bind(Msg.FILTER_MISSING_RIGHTPAREN, this.filterstring.substring(this.pos)), this.filterstring);
/*      */       }
/*      */       
/* 1361 */       this.pos++;
/*      */       
/* 1363 */       skipWhiteSpace();
/*      */       
/* 1365 */       return filter;
/*      */     }
/*      */     
/*      */     private FilterImpl parse_filtercomp() throws InvalidSyntaxException {
/* 1369 */       skipWhiteSpace();
/*      */       
/* 1371 */       char c = this.filterChars[this.pos];
/*      */       
/* 1373 */       switch (c) {
/*      */         case '&':
/* 1375 */           this.pos++;
/* 1376 */           return parse_and();
/*      */         
/*      */         case '|':
/* 1379 */           this.pos++;
/* 1380 */           return parse_or();
/*      */         
/*      */         case '!':
/* 1383 */           this.pos++;
/* 1384 */           return parse_not();
/*      */       } 
/*      */       
/* 1387 */       return parse_item();
/*      */     }
/*      */     
/*      */     private FilterImpl parse_and() throws InvalidSyntaxException {
/* 1391 */       int lookahead = this.pos;
/* 1392 */       skipWhiteSpace();
/*      */       
/* 1394 */       if (this.filterChars[this.pos] != '(') {
/* 1395 */         this.pos = lookahead - 1;
/* 1396 */         return parse_item();
/*      */       } 
/*      */       
/* 1399 */       List<FilterImpl> operands = new ArrayList<>(10);
/*      */       
/* 1401 */       while (this.filterChars[this.pos] == '(') {
/* 1402 */         FilterImpl child = parse_filter();
/* 1403 */         operands.add(child);
/*      */       } 
/*      */       
/* 1406 */       return new FilterImpl.And(operands.<FilterImpl>toArray(new FilterImpl[0]));
/*      */     }
/*      */     
/*      */     private FilterImpl parse_or() throws InvalidSyntaxException {
/* 1410 */       int lookahead = this.pos;
/* 1411 */       skipWhiteSpace();
/*      */       
/* 1413 */       if (this.filterChars[this.pos] != '(') {
/* 1414 */         this.pos = lookahead - 1;
/* 1415 */         return parse_item();
/*      */       } 
/*      */       
/* 1418 */       List<FilterImpl> operands = new ArrayList<>(10);
/*      */       
/* 1420 */       while (this.filterChars[this.pos] == '(') {
/* 1421 */         FilterImpl child = parse_filter();
/* 1422 */         operands.add(child);
/*      */       } 
/*      */       
/* 1425 */       return new FilterImpl.Or(operands.<FilterImpl>toArray(new FilterImpl[0]));
/*      */     }
/*      */     
/*      */     private FilterImpl parse_not() throws InvalidSyntaxException {
/* 1429 */       int lookahead = this.pos;
/* 1430 */       skipWhiteSpace();
/*      */       
/* 1432 */       if (this.filterChars[this.pos] != '(') {
/* 1433 */         this.pos = lookahead - 1;
/* 1434 */         return parse_item();
/*      */       } 
/*      */       
/* 1437 */       FilterImpl child = parse_filter();
/*      */       
/* 1439 */       return new FilterImpl.Not(child);
/*      */     } private FilterImpl parse_item() throws InvalidSyntaxException {
/*      */       String[] substrings;
/*      */       int length;
/* 1443 */       String attr = parse_attr();
/*      */       
/* 1445 */       skipWhiteSpace();
/*      */       
/* 1447 */       switch (this.filterChars[this.pos]) {
/*      */         case '~':
/* 1449 */           if (this.filterChars[this.pos + 1] == '=') {
/* 1450 */             this.pos += 2;
/* 1451 */             return new FilterImpl.Approx(attr, parse_value(), this.debug);
/*      */           } 
/*      */           break;
/*      */         
/*      */         case '>':
/* 1456 */           if (this.filterChars[this.pos + 1] == '=') {
/* 1457 */             this.pos += 2;
/* 1458 */             return new FilterImpl.GreaterEqual(attr, parse_value(), this.debug);
/*      */           } 
/*      */           break;
/*      */         
/*      */         case '<':
/* 1463 */           if (this.filterChars[this.pos + 1] == '=') {
/* 1464 */             this.pos += 2;
/* 1465 */             return new FilterImpl.LessEqual(attr, parse_value(), this.debug);
/*      */           } 
/*      */           break;
/*      */         
/*      */         case '=':
/* 1470 */           if (this.filterChars[this.pos + 1] == '*') {
/* 1471 */             int oldpos = this.pos;
/* 1472 */             this.pos += 2;
/* 1473 */             skipWhiteSpace();
/* 1474 */             if (this.filterChars[this.pos] == ')') {
/* 1475 */               return new FilterImpl.Present(attr, this.debug);
/*      */             }
/* 1477 */             this.pos = oldpos;
/*      */           } 
/*      */           
/* 1480 */           this.pos++;
/* 1481 */           substrings = parse_substring();
/*      */           
/* 1483 */           length = substrings.length;
/* 1484 */           if (length == 0) {
/* 1485 */             return new FilterImpl.Equal(attr, "", this.debug);
/*      */           }
/* 1487 */           if (length == 1) {
/* 1488 */             String single = substrings[0];
/* 1489 */             if (single != null) {
/* 1490 */               return new FilterImpl.Equal(attr, single, this.debug);
/*      */             }
/*      */           } 
/* 1493 */           return new FilterImpl.Substring(attr, substrings, this.debug);
/*      */       } 
/*      */ 
/*      */       
/* 1497 */       throw new InvalidSyntaxException(NLS.bind(Msg.FILTER_INVALID_OPERATOR, this.filterstring.substring(this.pos)), this.filterstring);
/*      */     }
/*      */     
/*      */     private String parse_attr() throws InvalidSyntaxException {
/* 1501 */       skipWhiteSpace();
/*      */       
/* 1503 */       int begin = this.pos;
/* 1504 */       int end = this.pos;
/*      */       
/* 1506 */       char c = this.filterChars[this.pos];
/*      */       
/* 1508 */       while (c != '~' && c != '<' && c != '>' && c != '=' && c != '(' && c != ')') {
/* 1509 */         this.pos++;
/*      */         
/* 1511 */         if (!Character.isWhitespace(c)) {
/* 1512 */           end = this.pos;
/*      */         }
/*      */         
/* 1515 */         c = this.filterChars[this.pos];
/*      */       } 
/*      */       
/* 1518 */       int length = end - begin;
/*      */       
/* 1520 */       if (length == 0) {
/* 1521 */         throw new InvalidSyntaxException(NLS.bind(Msg.FILTER_MISSING_ATTR, this.filterstring.substring(this.pos)), this.filterstring);
/*      */       }
/*      */       
/* 1524 */       return new String(this.filterChars, begin, length);
/*      */     }
/*      */     
/*      */     private String parse_value() throws InvalidSyntaxException {
/* 1528 */       StringBuilder sb = new StringBuilder(this.filterChars.length - this.pos);
/*      */       
/*      */       while (true) {
/* 1531 */         char c = this.filterChars[this.pos];
/*      */         
/* 1533 */         switch (c) {
/*      */           case ')':
/*      */             break;
/*      */ 
/*      */           
/*      */           case '(':
/* 1539 */             throw new InvalidSyntaxException(NLS.bind(Msg.FILTER_INVALID_VALUE, this.filterstring.substring(this.pos)), this.filterstring);
/*      */ 
/*      */           
/*      */           case '\\':
/* 1543 */             this.pos++;
/* 1544 */             c = this.filterChars[this.pos];
/*      */             break;
/*      */         } 
/*      */ 
/*      */         
/* 1549 */         sb.append(c);
/* 1550 */         this.pos++;
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1556 */       if (sb.length() == 0) {
/* 1557 */         throw new InvalidSyntaxException(NLS.bind(Msg.FILTER_MISSING_VALUE, this.filterstring.substring(this.pos)), this.filterstring);
/*      */       }
/*      */       
/* 1560 */       return sb.toString();
/*      */     }
/*      */     
/*      */     private String[] parse_substring() throws InvalidSyntaxException {
/* 1564 */       StringBuilder sb = new StringBuilder(this.filterChars.length - this.pos);
/*      */       
/* 1566 */       List<String> operands = new ArrayList<>(10);
/*      */       
/*      */       while (true) {
/* 1569 */         char c = this.filterChars[this.pos];
/*      */         
/* 1571 */         switch (c) {
/*      */           case ')':
/* 1573 */             if (sb.length() > 0) {
/* 1574 */               operands.add(sb.toString());
/*      */             }
/*      */             break;
/*      */ 
/*      */ 
/*      */           
/*      */           case '(':
/* 1581 */             throw new InvalidSyntaxException(NLS.bind(Msg.FILTER_INVALID_VALUE, this.filterstring.substring(this.pos)), this.filterstring);
/*      */ 
/*      */           
/*      */           case '*':
/* 1585 */             if (sb.length() > 0) {
/* 1586 */               operands.add(sb.toString());
/*      */             }
/*      */             
/* 1589 */             sb.setLength(0);
/*      */             
/* 1591 */             operands.add(null);
/* 1592 */             this.pos++;
/*      */             continue;
/*      */ 
/*      */ 
/*      */           
/*      */           case '\\':
/* 1598 */             this.pos++;
/* 1599 */             c = this.filterChars[this.pos];
/*      */             break;
/*      */         } 
/*      */ 
/*      */         
/* 1604 */         sb.append(c);
/* 1605 */         this.pos++;
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1611 */       return operands.<String>toArray(new String[0]);
/*      */     }
/*      */     
/*      */     private void skipWhiteSpace() {
/* 1615 */       for (int length = this.filterChars.length; this.pos < length && Character.isWhitespace(this.filterChars[this.pos]);) {
/* 1616 */         this.pos++;
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   private static final class DictionaryMap
/*      */     extends AbstractMap<String, Object>
/*      */     implements Map<String, Object>
/*      */   {
/*      */     private final Dictionary<String, ?> dictionary;
/*      */     
/*      */     static Map<String, ?> asMap(Dictionary<String, ?> dictionary) {
/* 1629 */       if (dictionary instanceof Map) {
/*      */         
/* 1631 */         Map<String, ?> coerced = (Map<String, ?>)dictionary;
/* 1632 */         return coerced;
/*      */       } 
/* 1634 */       return new DictionaryMap(dictionary);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     DictionaryMap(Dictionary<String, ?> dictionary) {
/* 1647 */       this.dictionary = Objects.<Dictionary<String, ?>>requireNonNull(dictionary);
/*      */     }
/*      */ 
/*      */     
/*      */     public Object get(Object key) {
/* 1652 */       return this.dictionary.get(key);
/*      */     }
/*      */ 
/*      */     
/*      */     public Set<Map.Entry<String, Object>> entrySet() {
/* 1657 */       throw new UnsupportedOperationException();
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   private static final class ServiceReferenceMap
/*      */     extends AbstractMap<String, Object>
/*      */     implements Map<String, Object>
/*      */   {
/*      */     private final ServiceReference<?> reference;
/*      */     
/*      */     static Map<String, ?> asMap(ServiceReference<?> reference) {
/* 1669 */       if (reference instanceof ServiceReferenceImpl) {
/* 1670 */         return ((ServiceReferenceImpl)reference).getRegistration().getProperties();
/*      */       }
/* 1672 */       return new ServiceReferenceMap(reference);
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     ServiceReferenceMap(ServiceReference<?> reference) {
/* 1678 */       this.reference = Objects.<ServiceReference>requireNonNull(reference);
/*      */     }
/*      */ 
/*      */     
/*      */     public Object get(Object key) {
/* 1683 */       return this.reference.getProperty((String)key);
/*      */     }
/*      */ 
/*      */     
/*      */     public Set<Map.Entry<String, Object>> entrySet() {
/* 1688 */       throw new UnsupportedOperationException();
/*      */     } }
/*      */   static class Range { private char leftRule; private Version leftVersion;
/*      */     
/*      */     Range() {
/* 1693 */       this.leftRule = Character.MIN_VALUE;
/*      */ 
/*      */       
/* 1696 */       this.rightRule = Character.MIN_VALUE;
/* 1697 */       this.excludes = new ArrayList<>(0);
/*      */     }
/*      */     private Version rightVersion; private char rightRule; private Collection<Version> excludes;
/*      */     public String toString() {
/* 1701 */       if (this.rightVersion == null) {
/* 1702 */         return this.leftVersion.toString();
/*      */       }
/* 1704 */       return String.valueOf(this.leftRule) + this.leftVersion.toString() + ',' + this.rightVersion.toString() + this.rightRule;
/*      */     }
/*      */     
/*      */     void addExclude(Version exclude) {
/* 1708 */       this.excludes.add(exclude);
/* 1709 */       setLeft(this.leftRule, this.leftVersion);
/* 1710 */       setRight(this.rightRule, this.rightVersion);
/*      */     }
/*      */     
/*      */     boolean setLeft(char leftRule, Version leftVersion) {
/* 1714 */       if (this.leftVersion != null && this.leftVersion != leftVersion)
/* 1715 */         return false; 
/* 1716 */       this.leftRule = this.excludes.contains(leftVersion) ? '(' : leftRule;
/* 1717 */       this.leftVersion = leftVersion;
/* 1718 */       return true;
/*      */     }
/*      */     
/*      */     boolean setRight(char rightRule, Version rightVersion) {
/* 1722 */       if (this.rightVersion != null && this.rightVersion != rightVersion)
/* 1723 */         return false; 
/* 1724 */       this.rightRule = this.excludes.contains(rightVersion) ? ')' : rightRule;
/* 1725 */       this.rightVersion = rightVersion;
/* 1726 */       return true;
/*      */     } }
/*      */ 
/*      */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.osgi-3.18.400.jar!\org\eclipse\osgi\internal\framework\FilterImpl.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */