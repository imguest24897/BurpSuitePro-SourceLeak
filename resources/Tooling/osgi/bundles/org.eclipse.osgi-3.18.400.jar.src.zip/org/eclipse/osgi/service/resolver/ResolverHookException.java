/*    */ package org.eclipse.osgi.service.resolver;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ResolverHookException
/*    */   extends RuntimeException
/*    */ {
/*    */   private static final long serialVersionUID = 5686047743173396286L;
/*    */   
/*    */   public ResolverHookException(String message, Throwable cause) {
/* 30 */     super(message, cause);
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.osgi-3.18.400.jar!\org\eclipse\osgi\service\resolver\ResolverHookException.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */