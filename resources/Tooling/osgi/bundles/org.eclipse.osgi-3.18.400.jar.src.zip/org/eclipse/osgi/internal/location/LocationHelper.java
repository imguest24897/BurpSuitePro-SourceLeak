/*     */ package org.eclipse.osgi.internal.location;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import java.net.MalformedURLException;
/*     */ import java.net.URL;
/*     */ import java.net.URLConnection;
/*     */ import java.net.URLDecoder;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LocationHelper
/*     */ {
/*     */   public static final String PROP_OSGI_LOCKING = "osgi.locking";
/*     */   public static final String LOCKING_NONE = "none";
/*     */   public static final String LOCKING_IO = "java.io";
/*     */   public static final String LOCKING_NIO = "java.nio";
/*     */   
/*     */   public static URL buildURL(String spec, boolean trailingSlash) {
/*  37 */     if (spec == null)
/*  38 */       return null; 
/*  39 */     if (File.separatorChar == '\\')
/*  40 */       spec = spec.trim(); 
/*  41 */     boolean isFile = spec.startsWith("file:");
/*     */     try {
/*  43 */       if (isFile)
/*  44 */         return adjustTrailingSlash((new File(spec.substring(5))).toURL(), trailingSlash); 
/*  45 */       return new URL(spec);
/*  46 */     } catch (MalformedURLException malformedURLException) {
/*     */ 
/*     */       
/*  49 */       if (isFile)
/*  50 */         return null; 
/*     */       try {
/*  52 */         return adjustTrailingSlash((new File(spec)).toURL(), trailingSlash);
/*  53 */       } catch (MalformedURLException malformedURLException1) {
/*  54 */         return null;
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private static URL adjustTrailingSlash(URL url, boolean trailingSlash) throws MalformedURLException {
/*  60 */     String file = url.getPath();
/*  61 */     if (trailingSlash == file.endsWith("/"))
/*  62 */       return url; 
/*  63 */     file = trailingSlash ? (String.valueOf(file) + "/") : file.substring(0, file.length() - 1);
/*  64 */     return new URL(url.getProtocol(), url.getHost(), file);
/*     */   }
/*     */   
/*     */   public static Locker createLocker(File lock, String lockMode, boolean debug) {
/*  68 */     if (lockMode == null)
/*     */     {
/*  70 */       lockMode = System.getProperty("osgi.locking");
/*     */     }
/*  72 */     if ("none".equals(lockMode)) {
/*  73 */       return new Locker.MockLocker();
/*     */     }
/*  75 */     if ("java.io".equals(lockMode)) {
/*  76 */       return new Locker_JavaIo(lock);
/*     */     }
/*  78 */     if ("java.nio".equals(lockMode)) {
/*  79 */       return new Locker_JavaNio(lock, debug);
/*     */     }
/*     */ 
/*     */     
/*  83 */     return new Locker_JavaNio(lock, debug);
/*     */   }
/*     */   
/*     */   public static InputStream getStream(URL location) throws IOException {
/*  87 */     if ("file".equalsIgnoreCase(location.getProtocol())) {
/*     */       
/*  89 */       File f = new File(location.getPath());
/*  90 */       if (f.exists()) {
/*  91 */         return new FileInputStream(f);
/*     */       }
/*     */     } 
/*  94 */     return location.openStream();
/*     */   }
/*     */   
/*     */   public static URLConnection getConnection(URL url) throws IOException {
/*  98 */     if ("file".equalsIgnoreCase(url.getProtocol())) {
/*     */       try {
/* 100 */         return url.openConnection();
/* 101 */       } catch (IllegalArgumentException illegalArgumentException) {
/*     */         
/* 103 */         File f = new File(url.getPath());
/* 104 */         if (f.exists()) {
/* 105 */           return f.toURI().toURL().openConnection();
/*     */         }
/*     */       } 
/*     */     }
/* 109 */     return url.openConnection();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static File decodePath(File file) {
/* 115 */     if (!file.exists() && (file.getPath().indexOf('%') >= 0 || file.getPath().indexOf('+') >= 0)) {
/* 116 */       String absolute = file.getAbsolutePath();
/* 117 */       String decodePath = decode(absolute, true);
/* 118 */       File f = new File(decodePath);
/* 119 */       if (f.exists()) {
/* 120 */         return f;
/*     */       }
/* 122 */       decodePath = decode(absolute, false);
/* 123 */       f = new File(decodePath);
/* 124 */       if (f.exists()) {
/* 125 */         return f;
/*     */       }
/*     */     } 
/* 128 */     return file;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static String decode(String urlString, boolean plusEncoded) {
/* 134 */     if (plusEncoded && urlString.indexOf('+') >= 0) {
/* 135 */       int len = urlString.length();
/* 136 */       StringBuilder buf = new StringBuilder(len);
/* 137 */       for (int i = 0; i < len; i++) {
/* 138 */         char c = urlString.charAt(i);
/* 139 */         if (c == '+') {
/* 140 */           buf.append("%2B");
/*     */         } else {
/* 142 */           buf.append(c);
/*     */         } 
/* 144 */       }  urlString = buf.toString();
/*     */     } 
/*     */     try {
/* 147 */       return URLDecoder.decode(urlString, "UTF-8");
/* 148 */     } catch (UnsupportedEncodingException|RuntimeException unsupportedEncodingException) {
/*     */ 
/*     */ 
/*     */       
/* 152 */       return urlString;
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.osgi-3.18.400.jar!\org\eclipse\osgi\internal\location\LocationHelper.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */