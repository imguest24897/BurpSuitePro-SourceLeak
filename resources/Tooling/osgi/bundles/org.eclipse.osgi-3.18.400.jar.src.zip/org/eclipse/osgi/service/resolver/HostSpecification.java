package org.eclipse.osgi.service.resolver;

public interface HostSpecification extends VersionConstraint {
  BundleDescription[] getHosts();
  
  boolean isMultiHost();
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.osgi-3.18.400.jar!\org\eclipse\osgi\service\resolver\HostSpecification.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */